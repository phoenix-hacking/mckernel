from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, re, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-irq-transport-final-retained-20260907-1'
out.mkdir()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            value.update(data)
    return value.hexdigest()

record = dict(created_utc=datetime.now(timezone.utc).isoformat(), artifacts=[], references=[],
              production_gate_credit=False, mckernel_boot_proven=False,
              passed=['Declared staging, pinned Linux kernel and all three native modules',
                      'Native Rust link closure, exact staged source, ELF64 and no-SIMD checks',
                      'Native-selected McKernel image: 56 image and 56 startup-table readbacks, 64 forced allocation failures, both ABIs and two module cycles',
                      'CPU/memory/OS-resource regressions and restoration before all module unloads',
                      'Complete repository suite from clean source 772ae63d'],
              limitations=['Direct IRQ prototype retains mock guest boot/allocator context; no executing McKernel CPU or cross-kernel IKC',
                           'Earlier intermittent Linux default-idle timer/RCU stall remains unresolved',
                           'Historical broad-equivalence prerequisites remain unavailable in pinned IHK; original failure is preserved',
                           'Owned trampoline/boot parameters, CPU wakeup, IKC, workloads, full Rust/assembly completion and independent production acceptance remain open'])

for name in ('native-irq-transport-checkpoint-20260907.json',
             'native-irq-transport-staging-integration-20260907.json'):
    path = repo / 'docs/verification' / name
    value = json.loads(path.read_text())
    for row in value['artifacts']:
        artifact = repo / row['path']
        assert artifact.stat().st_size == row['size'] and digest(artifact) == row['sha256']
        unpacked, size = hashlib.sha256(), 0
        with gzip.open(artifact, 'rb') as stream:
            for data in iter(lambda: stream.read(1 << 20), b''):
                unpacked.update(data)
                size += len(data)
        if 'unpacked_sha256' in row:
            assert unpacked.hexdigest() == row['unpacked_sha256'] and size == row['unpacked_size']
    record['references'].append(dict(path=str(path.relative_to(repo)), size=path.stat().st_size,
        sha256=digest(path), verified_artifacts=len(value['artifacts'])))

stage = work / 'native-irq-transport-exact-stage-20260907-1'
guest = work / 'native-irq-transport-image-guest-20260907-1'
stage_record = json.loads((stage / 'record.json').read_text())
artifact_checks = json.loads((stage / 'module-artifact-checks.json').read_text())
guest_record = json.loads((guest / 'local-run.json').read_text())
suite = work / 'native-irq-transport-full-suite-20260907-1.json'
suite_record = json.loads(suite.read_text())
assert stage_record['status'] == artifact_checks['status'] == 'PASS'
assert guest_record['status'] == 'technical-capture-passed'
assert suite_record['exit_code'] == 0 and suite_record['changed_inputs'] == []
record['source_parent'] = suite_record['source_parent']
for item in stage_record['outputs'] + guest_record['inputs']:
    path = Path(item['path'])
    assert path.stat().st_size == item['size'] and digest(path) == item['sha256'], path
exports = (stage / 'Module.symvers').read_text()
for symbol in ('raised_list', 'per_cpu_ptr_to_phys', 'irq_work_sync', '__SCT__apic_call_send_IPI_mask'):
    assert re.search(r'\t' + re.escape(symbol) + r'\tvmlinux\tEXPORT_(?:PER_CPU_)?SYMBOL_GPL\t', exports), symbol
record['kernel_exports'] = ['raised_list', 'per_cpu_ptr_to_phys', 'irq_work_sync', '__SCT__apic_call_send_IPI_mask']
record['prototype_artifact_comparison'] = []
for name in ('bzImage', 'resolved.config', 'ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
    current = stage / name
    prior = work / 'native-irq-transport-kernel-20260907-1' / name
    record['prototype_artifact_comparison'].append(dict(name=name, sha256=digest(current),
        prototype_sha256=digest(prior), identical=digest(current) == digest(prior)))
log = suite.with_suffix('.log').read_text()
count, seconds = re.findall(r'Ran (\d+) tests in ([0-9.]+)s', log)[-1]
skipped = int(re.findall(r'OK \(skipped=(\d+)\)', log)[-1])
record['full_suite'] = dict(total=int(count), passed=int(count)-skipped, skipped=skipped,
    seconds=float(seconds), source_parent=suite_record['source_parent'],
    started_utc=suite_record['started_utc'], finished_utc=suite_record['finished_utc'])
serial = (guest / 'serial.log').read_text()
rows = re.findall(r'startup-memory-kib before=(\d+) after=(\d+) cached-before=(\d+) cached-after=(\d+)', serial)
assert len(rows) == 4
record['startup_cleanup_loss_kib'] = [int(a)+int(c)-int(b)-int(d) for a,b,c,d in rows]
assert all(loss <= 4096 for loss in record['startup_cleanup_loss_kib'])
record['image_readbacks'] = len(guest_record['physical_image_readbacks'])
record['startup_readbacks'] = len(guest_record['physical_startup_table_readbacks'])
record['startup_allocation_failures'] = guest_record['startup_allocation_failures']

def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''):
                stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name,
        source=str(path), size=target.stat().st_size, sha256=digest(target),
        unpacked_size=path.stat().st_size, unpacked_sha256=digest(path)))

for path in (stage, guest, work / 'native-irq-transport-declared-validation-20260907-1'):
    target = out / (path.name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        archive.add(path, arcname=path.name)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
        source=str(path), size=target.stat().st_size, sha256=digest(target)))
for path in (stage / 'record.json', stage / 'module-artifact-checks.json', stage / 'kbuild-link-closure.json',
             guest / 'local-run.json', guest / 'serial.log', suite, suite.with_suffix('.log')):
    add(path, 'native-irq-transport-final-20260907-' + path.parent.name + '-' + path.name + '.gz')
for name in ('build-native-irq-transport-exact-stage.py', 'check-native-irq-transport-exact-stage-modules.py',
             'run-native-irq-image-load-guest.py', 'run-native-irq-transport-full-tests.py',
             'run-native-irq-transport-declared-validation.py', 'retain-native-irq-transport-final.py'):
    add(work / name, 'native-irq-transport-final-20260907-' + name + '.gz')
for row in record['artifacts']:
    unpacked, size = hashlib.sha256(), 0
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            unpacked.update(data)
            size += len(data)
    if 'unpacked_sha256' in row:
        assert size == row['unpacked_size'] and unpacked.hexdigest() == row['unpacked_sha256']
(out / 'native-irq-transport-final-validation-20260907.json').write_text(
    json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Verified earlier artifacts:', sum(row['verified_artifacts'] for row in record['references']))
print('Retained final transport artifacts:', len(record['artifacts']), flush=True)
