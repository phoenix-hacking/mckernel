"""Requested host storage maintenance; remove only old, disposable caches."""
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import hashlib
import json
import os
import shutil
import stat
import sys

HOME_ROOT = Path('/home/holden')
WORK = HOME_ROOT / 'mckernel-work/scratch'
PLAN = WORK / 'storage-stale-caches-20260908-3-private-plan.json'
REPORT = WORK / 'storage-stale-caches-20260908-3-report.json'
CUTOFF = datetime(2026, 6, 1, tzinfo=timezone.utc).timestamp()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    with path.open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def identity(root):
    """Fingerprint all metadata without following links or reading cache data."""
    root_stat = root.lstat()
    entries = [root]
    if stat.S_ISDIR(root_stat.st_mode):
        for parent, dirs, files in os.walk(root, followlinks=False):
            entries.extend(Path(parent) / n for n in dirs + files)
    digest = hashlib.sha256()
    blocks = files = 0
    newest = oldest = root_stat.st_mtime_ns
    for path in sorted(entries):
        s = path.lstat()
        if (s.st_dev != root_stat.st_dev or s.st_uid != os.getuid()
                or s.st_mtime >= CUTOFF
                or (stat.S_ISREG(s.st_mode) and s.st_atime >= CUTOFF)
                or stat.S_ISLNK(s.st_mode)
                or not (stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode))
                or (stat.S_ISREG(s.st_mode) and s.st_nlink != 1)):
            return None
        row = [str(path.relative_to(root)), s.st_mode, s.st_dev, s.st_ino,
               s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_blocks,
               s.st_nlink, s.st_uid]
        digest.update(json.dumps(row, separators=(',', ':')).encode() + b'\n')
        blocks += s.st_blocks * 512
        files += int(stat.S_ISREG(s.st_mode))
        newest = max(newest, s.st_mtime_ns)
        oldest = min(oldest, s.st_mtime_ns)
    return dict(metadata_sha256=digest.hexdigest(), entries=len(entries),
                files=files, allocated_bytes=blocks,
                oldest_mtime_ns=oldest, newest_mtime_ns=newest)


def visible_open_paths():
    paths = set()
    inaccessible = 0
    for process in Path('/proc').iterdir():
        if not process.name.isdecimal():
            continue
        try:
            links = list((process / 'fd').iterdir())
            links.extend(process / n for n in ('cwd', 'exe'))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            inaccessible += 1
            continue
        for link in links:
            try:
                value = os.readlink(link).removesuffix(' (deleted)')
                if value.startswith('/'):
                    paths.add(value)
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                pass
        try:
            for line in (process / 'maps').read_text().splitlines():
                fields = line.split(maxsplit=5)
                if len(fields) == 6 and fields[5].startswith('/'):
                    paths.add(fields[5].removesuffix(' (deleted)'))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    return paths, inaccessible


def in_use(root, paths):
    value = str(root)
    return any(p == value or p.startswith(value + '/') for p in paths)


CACHE_ROOTS = {
    'old_coursier_download_cache': HOME_ROOT / '.cache/coursier/v1',
    'old_poetry_download_artifacts': HOME_ROOT / '.cache/pypoetry/artifacts',
    'old_poetry_repository_cache': HOME_ROOT / '.cache/pypoetry/cache',
}


def allowed(path, group):
    return (CACHE_ROOTS.get(group) == path and path.is_dir()
            and not any(p.is_symlink() for p in (path, *path.parents)))


def audit():
    assert not PLAN.exists() and not REPORT.exists()
    candidates = list(CACHE_ROOTS.items())
    open_paths, inaccessible = visible_open_paths()
    targets = []
    skipped = 0
    for group, path in candidates:
        if not path.exists() or not allowed(path, group) or in_use(path, open_paths):
            skipped += 1
            continue
        state = identity(path)
        if state is None:
            skipped += 1
            continue
        targets.append(dict(group=group, path=str(path), identity=state))
    plan = dict(started_utc=now(), cutoff_utc='2026-06-01T00:00:00+00:00',
                targets=targets, skipped_candidates=skipped,
                inaccessible_process_fd_directories=inaccessible)
    save(PLAN, plan)
    groups = defaultdict(lambda: dict(targets=0, files=0, allocated_bytes=0))
    for row in targets:
        value = groups[row['group']]
        value['targets'] += 1
        for key in ('files', 'allocated_bytes'):
            value[key] += row['identity'][key]
    print(json.dumps(dict(status='AUDITED', groups=groups,
                          skipped_candidates=skipped), sort_keys=True))


def apply():
    assert not REPORT.exists()
    plan = json.loads(PLAN.read_text())
    open_paths, inaccessible = visible_open_paths()
    for row in plan['targets']:
        path = Path(row['path'])
        assert allowed(path, row['group']), 'target outside cache allowlist'
        assert not in_use(path, open_paths), 'cache acquired by a visible process'
        assert identity(path) == row['identity'], 'cache changed after audit'
    groups = defaultdict(lambda: dict(targets=0, files=0, allocated_bytes=0))
    report = dict(started_utc=now(), status='running', groups=groups,
                  criterion='Only Coursier and Poetry download/repository caches; all files last modified and accessed before 2026-06-01; no links or visible open use; installed environments excluded',
                  personal_paths_or_contents_recorded=False,
                  inaccessible_process_fd_directories=inaccessible,
                  root_available_before_bytes=shutil.disk_usage('/').free)
    try:
        for row in plan['targets']:
            path = Path(row['path'])
            assert identity(path) == row['identity'], 'cache changed before deletion'
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            assert not path.exists()
            value = groups[row['group']]
            value['targets'] += 1
            for key in ('files', 'allocated_bytes'):
                value[key] += row['identity'][key]
        report['status'] = 'PASS'
    except BaseException as error:
        report['status'] = 'FAIL'
        report['error_type'] = type(error).__name__
        raise
    finally:
        report['finished_utc'] = now()
        report['root_available_after_bytes'] = shutil.disk_usage('/').free
        report['removed_allocated_bytes'] = sum(g['allocated_bytes'] for g in groups.values())
        save(REPORT, report)
    PLAN.unlink()
    print(json.dumps(report, sort_keys=True))


if __name__ == '__main__':
    assert os.getuid() == 1000
    assert len(sys.argv) == 2 and sys.argv[1] in ('audit', 'apply')
    (audit if sys.argv[1] == 'audit' else apply)()
