/work/native-sysfs-os-module-20260907-1/fixture/mckernel_os_device_verify.o
