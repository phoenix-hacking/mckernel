"""Build the actual native boot adapter; declared integration remains pending."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
kernel = Path('/work/native-vdso-kernel-20260907-3')
out = Path('/work/native-sysfs-os-module-20260907-' + sys.argv[1])
assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
out.mkdir()
stage = source / 'drivers/misc/mckernel'
modules = build / 'drivers/misc/mckernel'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), commands=[], overlay=[], production_gate_credit=False, mckernel_boot_proven=False,
              scope='Native boot implementation prototype; live declared graph, FFI review and downstream bindings pending')

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-14000:])

try:
    shutil.copytree(stage, out / 'prior-stage')
    shutil.copytree(modules, out / 'prior-module-build')
    shutil.copyfile(__file__, out / 'helper.py')
    stage.rename(source / ('drivers/misc/mckernel-before-sysfs-os-20260907-' + sys.argv[1]))
    shutil.copytree(out / 'prior-stage', stage)
    if (stage / 'stage-lock.json').exists():
        (stage / 'stage-lock.json').rename(stage / 'prior-stage-lock.json')
    inputs = ['smp_resource.rs', 'os_runtime.rs', 'os_registry.rs', 'ihk_ioctl.rs', 'smp_cpu.rs', 'smp_memory.rs', 'ihk_smp_x86_64.rs', 'ihk_mapping.rs', 'smp_image.rs', 'smp_loader.rs', 'smp_startup.rs', 'smp_trampoline.rs', 'smp_boot_code.rs', 'smp_ikc.rs', 'smp_vdso.rs', 'sysfs_objects.rs', 'sysfs_os.rs', 'abi/vdso.rs', 'ikc_queue.rs', 'ikc_master.rs', 'smp_trampoline.S', 'smp_startup_entry.S']
    original = out / 'original-inputs'; original.mkdir()
    for name in inputs:
        saved = original / name; saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, saved)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, stage / name)
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format-source', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + [str(stage / name) for name in inputs if name.endswith('.rs')])
    record['overlay'] = [identity(stage / name) for name in inputs]
    shutil.copytree(stage, out / 'staged-source')
    # Exact API and boot layout witnesses live outside the module link path.
    witness = out / 'witness/scripts/tests/fixtures'
    witness.mkdir(parents=True)
    for name in ['native_smp_boot_layout.c']:
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, witness / name)
    shutil.copyfile(witness / 'native_smp_boot_layout.c', witness / 'native_smp_boot_layout_no_perf.c')
    ihk_headers = out / 'witness/ihk/cokernel/smp/x86_64'
    ihk_headers.mkdir(parents=True)
    for name in ['bootparam.h', 'perf_event.h']:
        shutil.copyfile(repo / 'ihk/cokernel/smp/x86_64' / name, ihk_headers / name)
    (witness / 'config.h').write_text('#ifndef RHEL_RELEASE_VERSION\n#define RHEL_RELEASE_VERSION(a,b) (((a) << 8) + (b))\n#endif\n')
    (witness / 'Kbuild').write_text('ccflags-y += -I$(src)\nCFLAGS_native_smp_boot_layout_no_perf.o += -DBOOT_WITHOUT_PERF\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('layout-witness', base + ['M=' + str(witness), 'native_smp_boot_layout.o', 'native_smp_boot_layout_no_perf.o'])
    expected_tail = [8, 0, 8, 16, 24, 32, 40, 48, 56, 64, 128, 136, 152, 160, 168, 176, 184, 192, 4288, 4296, 4300, 6348, 6604, 6608, 6612, 6616, 6620, 6624, 6628, 6632, 16, 8, 24, 16, 24, 4, 8, 16]
    for name, size in [('native_smp_boot_layout', 7616), ('native_smp_boot_layout_no_perf', 6656)]:
        binary = out / (name + '.bin')
        run(name, ['objcopy', '--dump-section', '.mckernel_native_boot_layout=' + str(binary), str(witness / (name + '.o')), str(out / (name + '-copy.o'))])
        actual = list(struct.unpack('<' + str(binary.stat().st_size // 8) + 'Q', binary.read_bytes()))
        assert actual == [size] + expected_tail, (name, actual)
    run('module-build', shlex.split((prior / 'module-build.command').read_text()))
    shutil.copytree(modules, out / 'module-build')
    for name in ['ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko']:
        shutil.copyfile(modules / name, out / name)
        disassembly = subprocess.check_output(['objdump', '-d', str(out / name)], text=True)
        (out / (name + '-disassembly.txt')).write_text(disassembly)
        assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', disassembly), name
        (out / (name + '-undefined.txt')).write_bytes(subprocess.check_output(['nm', '-u', str(out / name)]))
    defined = subprocess.check_output(['nm', '--defined-only', str(out / 'ihk.ko')], text=True)
    for version in (1, 2, 3):
        assert ' T ihk_os_create_unbooted_v' + str(version) + '\n' in defined
    smp_imports = (out / 'ihk-smp-x86_64.ko-undefined.txt').read_text()
    for name in ['ihk_os_create_unbooted_v3', 'wakeup_secondary_cpu_via_init', 'init_top_pgt', 'per_cpu_ptr_to_phys', 'apic', '__SCT__apic_call_send_IPI_mask']:
        assert ' U ' + name + '\n' in smp_imports, name
    assert ' T ihk_os_with_kobject_v1\n' in defined
    assert ' U ihk_os_with_kobject_v1\n' in smp_imports
    for name in ['drivers/base/core.c', 'include/linux/device.h']:
        saved = out / 'linux-reference' / name; saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, saved)
    fixture = out / 'fixture'; fixture.mkdir()
    fixture_names = ['mckernel_os_device_verify.rs', 'native_os_device_layout.c']
    for name in fixture_names:
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, original / name)
        shutil.copyfile(original / name, fixture / name)
    run('fixture-format', ['rustfmt', '--edition', '2021', str(fixture / fixture_names[0])])
    (fixture / 'Kbuild').write_text('obj-m += mckernel_os_device_verify.o\n')
    run('device-layout-witness', base + ['M=' + str(fixture), 'native_os_device_layout.o'])
    run('device-fixture-build', base + ['M=' + str(fixture), 'KBUILD_EXTRA_SYMBOLS=' + str(modules / 'Module.symvers'), 'modules'])
    for category, object_name in [('c', 'native_os_device_layout.o'), ('rust', 'mckernel_os_device_verify.ko')]:
        run(category + '-device-layout', ['objcopy', '--dump-section', '.mckernel_os_device_layout=' + str(out / (category + '-device-layout.bin')), str(fixture / object_name), str(out / (category + '-device-copy.o'))])
    assert (out / 'c-device-layout.bin').read_bytes() == (out / 'rust-device-layout.bin').read_bytes()
    record['device_layout'] = list(struct.unpack('<3Q', (out / 'c-device-layout.bin').read_bytes()))
    shutil.copyfile(fixture / 'mckernel_os_device_verify.ko', out / 'mckernel_os_device_verify.ko')
    disassembly = subprocess.check_output(['objdump', '-d', str(out / 'mckernel_os_device_verify.ko')], text=True)
    (out / 'device-fixture-disassembly.txt').write_text(disassembly)
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', disassembly)
    record['fixture_inputs'] = [identity(fixture / name) for name in fixture_names]
    for name in ['bzImage', 'resolved.config']:
        shutil.copyfile(kernel / name, out / name)
    for name in ['Module.symvers', 'rust/bindings/bindings_generated.rs']:
        shutil.copyfile(build / name, out / Path(name).name)
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json', 'phase')]
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
