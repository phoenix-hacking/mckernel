#!/usr/bin/env python3
"""Source-bound PendingFreeBatch focused oracle; never a runtime acceptance."""
from pathlib import Path
import argparse, hashlib, json, platform, subprocess, tempfile

ROOT=Path(__file__).resolve().parents[3]; ABI=ROOT/'kernel/rust/abi.rs'; MEM=ROOT/'kernel/rust/mem_helpers.rs'
RUST=ROOT/'kernel/rust/tests/pending_free_batch_vectors.rs'; C=ROOT/'kernel/rust/tests/pending_free_batch_vectors.c'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,x): p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def slice_(p,a,b):
 s=p.read_text(); assert s.count(a)==1 and s.count(b)==1,(p,a,b); i=s.index(a);j=s.index(b,i);x=s[i:j]
 return x,{'path':str(p.relative_to(ROOT)),'begin':a,'end':b,'start':i,'end_offset':j,'sha256':hashlib.sha256(x.encode()).hexdigest()}
def line(p,a):
 q=[x for x in p.read_text().splitlines(True) if x.startswith(a)];assert len(q)==1,(p,a,len(q));return q[0],{'path':str(p.relative_to(ROOT)),'line_prefix':a,'sha256':hashlib.sha256(q[0].encode()).hexdigest()}
def call(argv,out,label,ledger):
 r=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True);(out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 ledger.append({'label':label,'argv':argv,'returncode':r.returncode,'stdout_sha256':digest(out/(label+'.stdout')),'stderr_sha256':digest(out/(label+'.stderr'))});return r
def prelude():
 out=['#![feature(raw_ref_op, let_else)]\n#![allow(dead_code,unsafe_op_in_unsafe_fn)]\nuse core::marker::{PhantomData,PhantomPinned};use core::pin::Pin;use core::ptr::null_mut;use std::cell::RefCell;\n'];m=[]
 for p,a,b in [(ABI,'pub type CInt = i32;','pub const MCK_RLIM_MAX'),(ABI,'#[repr(C)]\n#[derive(Clone, Copy)]\npub struct AbiListHead','#[repr(C)]\n#[derive(Clone, Copy)]\npub struct AbiRbNode'),(ABI,'#[repr(C)]\n#[derive(Clone, Copy)]\npub struct IhkAtomic','#[repr(C)]\n#[derive(Clone, Copy)]\npub struct IhkSpinlock'),(MEM,'#[repr(C)]\npub struct MemPage','#[repr(C)]\npub struct KmallocTrackAddrEntry'),(MEM,'type MemPendingFreeFn =','type MemBeginFreePagesPendingFn ='),(MEM,'#[inline(always)]\nunsafe fn list_add(','#[inline(always)]\nunsafe fn kmalloc_track_hash'),(MEM,'#[derive(Clone, Copy, PartialEq, Eq)]\nenum PendingFreeBatchState','#[no_mangle]\npub extern "C" fn round_up')]:
  x,z=slice_(p,a,b);out.append(x);m.append(z)
 for a in ('const EINVAL:','const IHK_MC_PG_USER:','const PM_NONE:','const PM_PENDING_FREE:','const LIST_POISON1:','const LIST_POISON2:'):
  x,z=line(MEM,a);out.insert(1,x);m.append(z)
 return ''.join(out),m
EXPECT=[
 ('empty',0,0,[],'null','null'),('one',0,1,[[11,1,1]],'null','null'),('three-order',0,3,[[12,2,1],[13,3,1],[14,4,1]],'null','null'),('later-invalid',0,-22,[],'null','ring'),('later-invalid-repair',0,2,[[20,2,1],[21,3,1]],'null','null'),('missing-callback',0,-22,[],'null','ring'),('wrong-source',0,-22,[],'null','ring'),('wrong-source-recovery',0,1,[[30,1,1]],'null','null'),('repeated-detach-drain',-22,1,[[31,1,1]],'null','null'),('null-source',-22,0,[],'invalid','vacant'),('inactive-empty',0,0,[],'null','ring'),('alias-destination',-22,0,[],'ring','vacant'),('mixed-destination-links',-22,0,[],'ring','vacant'),('mixed-destination-state',-22,0,[],'ring','retained'),('two-head-isolation',0,1,[[40,5,1]],'null','null')]
def rows(s):return [json.loads(x[5:]) for x in s.splitlines() if x.startswith('JSON|')]
def compact(x):return [(r['case'],r['detach'],r['drain'],r['callbacks'],r['source'],r['batch']) for r in x]
def output(arg):
 if not arg:return Path(tempfile.mkdtemp(prefix='mckernel-pending-candidate8-'))
 p=Path(arg).resolve();
 if p.exists() and any(p.iterdir()):raise RuntimeError('refusing nonempty output '+str(p))
 p.mkdir(parents=True,exist_ok=True);return p
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir');a=ap.parse_args();o=output(a.output_dir);ledger=[]
 try:
  base,items=prelude();fixture=RUST.read_text();actual=o/'actual_extracted_and_vectors.rs';actual.write_text(base+'\n// fixture appended verbatim\n'+fixture)
  js(o/'source-extraction.json',{'abi_sha256':digest(ABI),'mem_helpers_sha256':digest(MEM),'fixture_sha256':digest(RUST),'items':items})
  for argv,label in [(['rustc','+nightly','--version','--verbose'],'rustc-identity'),(['cc','--version'],'cc-identity'),(['python3','--version'],'python-identity')]:
   if call(argv,o,label,ledger).returncode:raise RuntimeError(label+' failed')
  rb=o/'actual';assert call(['rustc','+nightly','--edition=2021','-D','warnings',str(actual),'-o',str(rb)],o,'rust-compile',ledger).returncode==0
  rr=call([str(rb)],o,'rust-run',ledger);assert rr.returncode==0;rs=rows(rr.stdout)
  cb=o/'reference-c';assert call(['cc','-std=c11','-Wall','-Wextra','-Werror',str(C),'-o',str(cb)],o,'c-compile',ledger).returncode==0
  cr=call([str(cb)],o,'c-run',ledger);assert cr.returncode==0;cs=rows(cr.stdout)
  assert compact(rs)==EXPECT,'Rust differs from separately authored expectations';assert compact(cs)==EXPECT,'C differs from separately authored expectations';assert rs==cs,'schemas differ'
  # The mutant is explicitly partial: it frees valid prefix 20 before seeing invalid 21.
  mutant=o/'partial-release-mutant.rs';needle='let drain = drain_pending_free_batch(source,batch.as_mut(),Some(free_page));';replacement='let drain = if name=="later-invalid" { partial_release_mutant(batch.as_ref().get_ref().head.next,&raw mut batch.as_mut().get_unchecked_mut().head,free_page) } else { drain_pending_free_batch(source,batch.as_mut(),Some(free_page)) };'
  assert needle in fixture;mutant.write_text(base+'\nunsafe fn partial_release_mutant(mut n:*mut AbiListHead,h:*mut AbiListHead,f:MemPendingFreeFn)->CInt{let mut c=0;while n!=h{let q=(*n).next;let p=page_from_list(n);if (*p).mode!=PM_PENDING_FREE{return -EINVAL;}(*p).mode=PM_NONE;list_del_poison(n);f((*p).phys,(*p).offset as CInt,IHK_MC_PG_USER);c+=1;n=q;}c}\n'+fixture.replace(needle,replacement))
  mb=o/'partial-release-mutant';assert call(['rustc','+nightly','--edition=2021','-D','warnings',str(mutant),'-o',str(mb)],o,'mutant-compile',ledger).returncode==0
  mr=call([str(mb)],o,'mutant-run',ledger);mrow=next(r for r in rows(mr.stdout) if r['case']=='later-invalid');assert mrow['callbacks']==[[20,2,1]] and mrow!=next(r for r in rs if r['case']=='later-invalid'),'mutant not detected'
  # Negative trait probes compile the extracted production type, not a stand-in.
  for trait in ('Copy','Clone','Unpin','Send','Sync'):
   probe=o/(trait+'.rs');probe.write_text(base+f'\nfn need<T:{trait}>(){{}} fn main(){{need::<PendingFreeBatch>();}}\n');r=call(['rustc','+nightly','--edition=2021','-D','warnings',str(probe),'-o',str(o/trait)],o,'trait-'+trait,ledger);assert r.returncode!=0,trait+' unexpectedly accepted'
  js(o/'manifest.json',{'status':'PASS_PENDING_FREE_BATCH_FOCUSED_EQUIVALENCE_ONLY','scope':'source-bound fixture only; no runtime or production credit','platform':platform.platform(),'inputs':{str(x.relative_to(ROOT)):digest(x) for x in (ABI,MEM,RUST,C,Path(__file__))},'commands':ledger,'expected':EXPECT,'rust_rows':rs,'c_rows':cs,'mutant_detected':True,'trait_negatives':['Copy','Clone','Unpin','Send','Sync']})
  js(o/'artifact-manifest.json',{p.name:digest(p) for p in sorted(o.iterdir()) if p.is_file()});print('PASS_PENDING_FREE_BATCH_FOCUSED_EQUIVALENCE_ONLY output='+str(o))
 except Exception as e:js(o/'failure.json',{'status':'FAIL','error':str(e),'commands':ledger});raise
if __name__=='__main__':main()
