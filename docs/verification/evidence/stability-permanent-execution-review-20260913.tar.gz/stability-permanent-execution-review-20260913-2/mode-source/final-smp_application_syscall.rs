// SPDX-License-Identifier: GPL-2.0
//! Owned bounded mailbox within one existing application registration.

use super::{
    application_rpc::Token,
    application_syscall::{Completion, Delivery, Request, Response, ResponseMemory, Worker},
};
use kernel::prelude::{Vec, VecExt, GFP_KERNEL};

type Result<T = ()> = core::result::Result<T, i32>;
pub(crate) const CAPACITY: usize = 64;

pub(crate) fn cyclic(start: usize, capacity: usize) -> impl Iterator<Item = usize> {
    (0..capacity).map(move |offset| (start % capacity + offset) % capacity)
}

struct WorkerState {
    worker: Worker,
    delivery: Option<Token>,
    completed: Option<Token>,
}

struct Call<M: ResponseMemory> {
    delivery: Delivery,
    response: Option<Response<M>>,
    completion: Option<Completion<M>>,
    worker: Option<Worker>,
    cancelled: bool,
    kernel: bool,
    service: bool,
    transferred: bool,
    publication_since: Option<u64>,
}

pub(crate) struct Mailbox<M: ResponseMemory> {
    calls: Vec<Option<Call<M>>>,
    workers: Vec<Option<WorkerState>>,
    closed: bool,
    quarantined: bool,
    completion_cursor: usize,
}

impl<M: ResponseMemory> Mailbox<M> {
    pub(crate) fn new() -> Result<Self> {
        // The pinned kernel maps its payload-free AllocError to ENOMEM.
        let mut calls = Vec::with_capacity(CAPACITY, GFP_KERNEL).map_err(|_| -12)?;
        let mut workers = Vec::with_capacity(CAPACITY, GFP_KERNEL).map_err(|_| -12)?;
        for _ in 0..CAPACITY {
            calls.push(None, GFP_KERNEL).map_err(|_| -12)?;
            workers.push(None, GFP_KERNEL).map_err(|_| -12)?;
        }
        Ok(Self {
            calls,
            workers,
            closed: false,
            quarantined: false,
            completion_cursor: 0,
        })
    }

    pub(crate) fn open_worker(&mut self, tid: i32) -> Result<u64> {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        // Only the referenced Linux identity owner can retire the old record.
        // Reusing a numeric TID cannot bind to its old opaque worker token.
        if self
            .workers
            .iter()
            .flatten()
            .any(|state| state.worker.tid() == tid)
        {
            return Err(-16);
        }
        let slot = self
            .workers
            .iter_mut()
            .find(|slot| slot.is_none())
            .ok_or(-11)?;
        let worker = Worker::new(tid)?;
        let handle = worker.wire();
        *slot = Some(WorkerState {
            worker,
            delivery: None,
            completed: None,
        });
        Ok(handle)
    }

    pub(crate) fn close_worker(&mut self, handle: u64) -> Result {
        if self.quarantined {
            return Err(-71);
        }
        let slot = self
            .workers
            .iter_mut()
            .find(|slot| {
                slot.as_ref()
                    .is_some_and(|state| state.worker.wire() == handle)
            })
            .ok_or(-2)?;
        if let Some(serial) = slot.as_ref().unwrap().delivery {
            let call = self
                .calls
                .iter_mut()
                .flatten()
                .find(|call| call.delivery.serial() == serial)
                .ok_or(-71)?;
            if let Err(error) = Self::cancel_call(call) {
                self.quarantined = true;
                return Err(error);
            }
            // The Linux PID/MM owner retries retirement after publication;
            // numeric TID reuse remains excluded until then.
            return Err(-16);
        }
        *slot = None;
        Ok(())
    }

    /// The caller serializes admission with scheduling and process close.
    /// Capacity failure occurs before taking a response claim, allowing retry
    /// of the same retained transport packet without a second host responder.
    pub(crate) fn admit(
        &mut self,
        request: Request,
        claim: impl FnOnce(&Request) -> Result<M>,
    ) -> Result<bool> {
        self.admit_inner(request, claim, None::<fn(&Request) -> i64>)
    }

    /// Only continuing-service operations that require no caller file table.
    /// The effect runs once, after a response claim, and survives process close.
    pub(crate) fn admit_serviced(
        &mut self,
        request: Request,
        claim: impl FnOnce(&Request) -> Result<M>,
        service: impl FnOnce(&Request) -> i64,
    ) -> Result<bool> {
        self.admit_inner(request, claim, Some(service))
    }

    fn admit_inner(
        &mut self,
        request: Request,
        claim: impl FnOnce(&Request) -> Result<M>,
        service: Option<impl FnOnce(&Request) -> i64>,
    ) -> Result<bool> {
        if self.quarantined {
            return Err(-71);
        }
        if self
            .calls
            .iter()
            .flatten()
            .any(|call| call.delivery.request() == &request)
        {
            return Ok(false);
        }
        if self
            .calls
            .iter()
            .flatten()
            .any(|call| call.delivery.request().response() == request.response())
        {
            return Err(-71);
        }
        let slot = self
            .calls
            .iter_mut()
            .find(|slot| slot.is_none())
            .ok_or(-11)?;
        let delivery = Delivery::new(request)?;
        let memory = claim(delivery.request())?;
        let response = match Response::from_memory(delivery.request(), memory) {
            Ok(response) => response,
            Err(error) => {
                self.quarantined = true;
                return Err(error);
            }
        };
        let mut call = Call {
            delivery,
            response: Some(response),
            completion: None,
            worker: None,
            cancelled: false,
            kernel: false,
            service: false,
            transferred: false,
            publication_since: None,
        };
        if let Some(service) = service {
            call.delivery.begin_service()?;
            let value = service(call.delivery.request());
            match call.response.take().ok_or(-71)?.prepare(0, value) {
                Ok(completion) => call.completion = Some(completion),
                Err(error) => {
                    self.quarantined = true;
                    return Err(error);
                }
            }
            call.service = true;
        }
        *slot = Some(call);
        if self.closed {
            self.cancel_pending()?;
        }
        Ok(true)
    }

    pub(crate) fn reserve(&mut self, handle: u64) -> Result<Option<(u64, [u8; 80])>> {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        let worker = self
            .workers
            .iter_mut()
            .flatten()
            .find(|state| state.worker.wire() == handle)
            .ok_or(-2)?;
        if let Some(serial) = worker.delivery {
            if self
                .calls
                .iter()
                .flatten()
                .any(|call| call.delivery.serial() == serial && call.completion.is_some())
            {
                return Ok(None);
            }
            return Err(-16);
        }
        // Preserve targeted priority and arrival order even after a newer
        // request reuses an earlier array slot. Tokens never wrap or repeat.
        let Some(index) = self
            .calls
            .iter()
            .enumerate()
            .filter_map(|(index, slot)| {
                let call = slot.as_ref()?;
                call.delivery
                    .eligible(worker.worker)
                    .then_some((index, call))
            })
            .min_by_key(|(_, call)| {
                (
                    call.delivery.request().target() != worker.worker.tid(),
                    call.delivery.serial().wire(),
                )
            })
            .map(|(index, _)| index)
        else {
            return Ok(None);
        };
        let call = self.calls[index].as_mut().unwrap();
        let bytes = call.delivery.reserve(worker.worker)?;
        worker.delivery = Some(call.delivery.serial());
        call.worker = Some(worker.worker);
        Ok(Some((call.delivery.serial().wire(), bytes)))
    }

    pub(crate) fn copied(&mut self, handle: u64, serial: u64, success: bool) -> Result {
        if self.quarantined {
            return Err(-71);
        }
        let worker = self
            .workers
            .iter_mut()
            .flatten()
            .find(|state| state.worker.wire() == handle)
            .ok_or(-2)?;
        if worker.delivery.map(Token::wire) != Some(serial) {
            return Err(-16);
        }
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        call.delivery.copied(worker.worker, success)?;
        if !success {
            worker.delivery = None;
            call.worker = None;
        }
        Ok(())
    }

    /// Copy a running settid payload while the caller holds the application
    /// mutex. The callback uses only kernel bytes and retains its payload claim
    /// in the response until the ordinary launcher RET is actually published.
    pub(crate) fn transfer_tids(
        &mut self,
        handle: u64,
        serial: u64,
        physical: u64,
        bytes: &mut [u8],
        direction: u64,
        copy: impl FnOnce(&Request, &mut M, &mut [u8]) -> Result,
    ) -> Result {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        let worker = self
            .workers
            .iter()
            .flatten()
            .find(|state| state.worker.wire() == handle)
            .ok_or(-2)?;
        if worker.delivery.map(Token::wire) != Some(serial) {
            return Err(-16);
        }
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        if call.kernel
            || call.service
            || call.cancelled
            || call.transferred
            || call.completion.is_some()
        {
            return Err(-16);
        }
        let request = call.delivery.request();
        call.delivery
            .check_return(worker.worker, request.cpu() as i64)?;
        if direction != 0 || request.tid_buffer()? != (physical, bytes.len() as u64) {
            return Err(-22);
        }
        copy(
            request,
            call.response.as_mut().ok_or(-71)?.memory_mut(),
            bytes,
        )?;
        call.transferred = true;
        Ok(())
    }

    /// Convert the exact reserved WAIT delivery into in-kernel work. Close
    /// cannot complete or reuse its response while that work accesses memory.
    pub(crate) fn begin_kernel(&mut self, handle: u64, serial: u64) -> Result<Request> {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        self.copied(handle, serial, true)?;
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        call.kernel = true;
        Ok(call.delivery.request().clone())
    }

    pub(crate) fn begin_invalidation(&mut self, handle: u64, serial: u64) -> Result<(u64, u64)> {
        let range = self
            .calls
            .iter()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?
            .delivery
            .request()
            .invalidation_range()?;
        self.begin_kernel(handle, serial)?;
        Ok(range)
    }

    /// This result comes only from the retained worker's completed Mirror
    /// operation. A close during that operation defers its cancellation here.
    pub(crate) fn finish_invalidation(
        &mut self,
        handle: u64,
        serial: u64,
        value: i64,
    ) -> Result<i64> {
        if !(-4095..=0).contains(&value) {
            return Err(-22);
        }
        self.calls
            .iter()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?
            .delivery
            .request()
            .invalidation_range()?;
        let mut completed = -512;
        self.finish_kernel(handle, serial, |_, _| {
            completed = value;
            Ok(value)
        })?;
        Ok(completed)
    }

    pub(crate) fn with_kernel_memory<T>(
        &mut self,
        handle: u64,
        serial: u64,
        use_memory: impl FnOnce(&Request, &mut M) -> Result<T>,
    ) -> Result<T> {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        let worker = call.worker.ok_or(-71)?;
        if !call.kernel || call.cancelled || worker.wire() != handle || call.completion.is_some() {
            return Err(-16);
        }
        use_memory(
            call.delivery.request(),
            call.response.as_mut().ok_or(-71)?.memory_mut(),
        )
    }

    pub(crate) fn finish_kernel(
        &mut self,
        handle: u64,
        serial: u64,
        result: impl FnOnce(&Request, &mut M) -> Result<i64>,
    ) -> Result {
        if self.quarantined {
            return Err(-71);
        }
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        let worker = call.worker.ok_or(-71)?;
        if !call.kernel || worker.wire() != handle || call.completion.is_some() {
            return Err(-16);
        }
        call.kernel = false;
        if self.closed || call.cancelled {
            return Self::cancel_call(call);
        }
        let value = result(
            call.delivery.request(),
            call.response.as_mut().ok_or(-71)?.memory_mut(),
        )
        .unwrap_or_else(|error| error as i64);
        call.delivery
            .begin_return(worker, call.delivery.request().cpu() as i64)?;
        match call.response.take().ok_or(-71)?.prepare(0, value) {
            Ok(completion) => call.completion = Some(completion),
            Err(error) => {
                self.quarantined = true;
                return Err(error);
            }
        }
        Ok(())
    }

    pub(crate) fn return_value(
        &mut self,
        handle: u64,
        serial: u64,
        cpu: i64,
        value: i64,
        copy: impl FnOnce(&Request) -> Result,
    ) -> Result {
        if self.closed || self.quarantined {
            return Err(-32);
        }
        let worker = self
            .workers
            .iter()
            .flatten()
            .find(|state| state.worker.wire() == handle)
            .ok_or(-2)?;
        if worker.delivery.map(Token::wire) != Some(serial) {
            return Err(-16);
        }
        let call = self
            .calls
            .iter_mut()
            .flatten()
            .find(|call| call.delivery.serial().wire() == serial)
            .ok_or(-2)?;
        if call.kernel {
            return Err(-16);
        }
        call.delivery.check_return(worker.worker, cpu)?;
        let request = call.delivery.request();
        if value == 0 && request.number() == 186 && request.arguments()[4] != 0 {
            request.tid_buffer()?;
            if !call.transferred {
                return Err(-22);
            }
        }
        // Only an already copied kernel buffer is used here, never user access.
        // Failed validation/copy leaves Delivered available for a proper retry.
        copy(call.delivery.request())?;
        call.delivery.begin_return(worker.worker, cpu)?;
        let response = call.response.take().ok_or(-71)?;
        match response.prepare(worker.worker.tid(), value) {
            Ok(completion) => call.completion = Some(completion),
            Err(error) => {
                self.quarantined = true;
                return Err(error);
            }
        }
        stability_fault_accepted(
            call.delivery.request(),
            call.delivery.serial().wire(),
            !call.cancelled && !call.kernel && !call.service,
            call.completion
                .as_ref()
                .and_then(Completion::verification_owner),
        );
        Ok(())
    }

    pub(crate) fn returned(&self, handle: u64, serial: u64) -> Result<bool> {
        if self.quarantined {
            return Err(-71);
        }
        let worker = self
            .workers
            .iter()
            .flatten()
            .find(|state| state.worker.wire() == handle)
            .ok_or(-2)?;
        if worker.completed.map(Token::wire) == Some(serial) {
            return Ok(true);
        }
        if worker.delivery.map(Token::wire) != Some(serial) {
            return Err(-16);
        }
        Ok(false)
    }

    pub(crate) fn queued_cpu(&self) -> Option<i32> {
        if self.quarantined {
            return None;
        }
        self.next_completion(None)
            .map(|index| self.calls[index].as_ref().unwrap().delivery.request().cpu())
    }

    fn next_completion(&self, cpu: Option<i32>) -> Option<usize> {
        cyclic(self.completion_cursor, self.calls.len()).find(|&index| {
            self.calls[index].as_ref().is_some_and(|call| {
                call.completion.is_some()
                    && cpu.is_none_or(|cpu| call.delivery.request().cpu() == cpu)
            })
        })
    }

    /// Queue publication and final status happen under the outer application's
    /// short mutex. The caller notifies the guest and Linux waiters afterwards.
    pub(crate) fn publish(
        &mut self,
        cpu: i32,
        send: impl FnOnce(&[u8; 128]) -> Result,
    ) -> Result<bool> {
        if self.quarantined {
            return Err(-71);
        }
        let Some(index) = self.next_completion(Some(cpu)) else {
            return Ok(false);
        };
        self.completion_cursor = (index + 1) % self.calls.len();
        let slot = &mut self.calls[index];
        let call = slot.as_mut().unwrap();
        let stability_request = call.delivery.request().clone();
        let stability_serial = call.delivery.serial().wire();
        let stability_eligible = !call.cancelled && !call.kernel && !call.service;
        let stability_owner = call
            .completion
            .as_ref()
            .and_then(Completion::verification_owner);
        call.completion.as_mut().unwrap().publish(|packet| {
            stability_fault_send(
                &stability_request,
                stability_serial,
                stability_eligible,
                stability_owner,
                packet,
                send,
            )
        })?;
        if call.service {
            call.delivery.serviced()?;
        } else if call.cancelled {
            call.delivery.cancelled()?;
        } else {
            call.delivery.completed(call.worker.ok_or(-71)?)?;
        }
        if let Some(owner) = call.worker {
            let worker = self
                .workers
                .iter_mut()
                .flatten()
                .find(|state| state.worker == owner)
                .ok_or(-71)?;
            if worker.delivery != Some(call.delivery.serial()) {
                return Err(-71);
            }
            worker.delivery = None;
            worker.completed = Some(call.delivery.serial());
        }
        *slot = None;
        Ok(true)
    }

    pub(crate) fn close(&mut self) -> Result {
        if self.quarantined {
            return Err(-71);
        }
        self.closed = true;
        self.cancel_pending()
    }

    /// A failed transport cannot acknowledge or cancel an unfinished response.
    /// Retain every call and its exact memory claim; in-flight kernel work may
    /// finish its independent I/O, but may no longer copy or publish peer data.
    pub(crate) fn quarantine(&mut self) {
        self.closed = true;
        self.quarantined = true;
    }

    /// The independent packet owner supplies CLOCK_MONOTONIC seconds. Each
    /// committed completion has its own deadline, so progress by another call
    /// cannot indefinitely reset a blocked response's publication lifetime.
    pub(crate) fn publication_expired(&mut self, now: u64, timeout: u64) -> bool {
        if self.quarantined {
            return false;
        }
        self.calls.iter_mut().flatten().any(|call| {
            if call.completion.is_none() {
                return false;
            }
            let since = call.publication_since.get_or_insert(now);
            now.saturating_sub(*since) >= timeout
        })
    }

    fn cancel_pending(&mut self) -> Result {
        for call in self.calls.iter_mut().flatten() {
            if let Err(error) = Self::cancel_call(call) {
                self.quarantined = true;
                return Err(error);
            }
        }
        Ok(())
    }

    fn cancel_call(call: &mut Call<M>) -> Result {
        if call.completion.is_some() {
            return Ok(());
        }
        if call.kernel {
            call.cancelled = true;
            return Ok(());
        }
        call.delivery.cancel()?;
        let response = call.response.take().ok_or(-71)?;
        call.completion = Some(response.prepare(0, -512)?);
        call.cancelled = true;
        Ok(())
    }

    pub(crate) fn drained(&self) -> bool {
        !self.quarantined && self.calls.iter().all(Option::is_none)
    }

    pub(crate) fn quarantined(&self) -> bool {
        self.quarantined
    }
}
// VERIFICATION OVERLAY ONLY. The caller holds this mailbox's existing owner lock.
impl<M: ResponseMemory> Mailbox<M> {
    pub(crate) fn verification_read16(
        &self,
        pid: Option<i32>,
        application: u64,
    ) -> Result<Option<crate::stability_observer::Selection>> {
        use crate::stability_observer as observer;
        if self.closed || self.quarantined {
            return Err(-71);
        }
        let mut selected = None;
        for call in self.calls.iter().flatten() {
            let delivery = call.delivery.verification_delivery();
            if delivery.phase != "delivered"
                || call.cancelled
                || call.kernel
                || call.service
                || call.completion.is_some()
                || delivery.number != 0
                || delivery.arguments[0] != 0
                || delivery.arguments[2] != 16
                || pid.is_some_and(|pid| pid != delivery.pid)
            {
                continue;
            }
            let claim = call
                .response
                .as_ref()
                .and_then(Response::verification_owner)
                .ok_or(-95)?;
            let worker = call.worker.ok_or(-71)?;
            if claim.response.physical != delivery.response
                || claim.response.serial.is_none()
                || claim.response.end.checked_sub(claim.response.physical) != Some(40)
            {
                return Err(-71);
            }
            if selected.is_some() {
                return Err(-16);
            }
            selected = Some(observer::Selection {
                os: claim.os,
                generation: claim.generation,
                pid: delivery.pid,
                cpu: delivery.cpu,
                requester: delivery.requester,
                application,
                worker: worker.wire(),
                delivery: delivery.serial,
                ledger_serial: claim.response.serial.unwrap(),
                ledger_index: claim.response.index,
                response: claim.response.physical,
                response_end: claim.response.end,
            });
        }
        Ok(selected)
    }

    pub(crate) fn verification_mailbox(
        &self,
        calls: &mut crate::stability_observer::Rows<
            crate::stability_observer::Call,
            { crate::stability_observer::CALLS },
        >,
        workers: &mut crate::stability_observer::Rows<
            crate::stability_observer::Worker,
            { crate::stability_observer::WORKERS },
        >,
    ) -> crate::stability_observer::Mailbox {
        use crate::stability_observer as observer;
        for (index, call) in self
            .calls
            .iter()
            .enumerate()
            .filter_map(|(index, call)| call.as_ref().map(|call| (index, call)))
        {
            let (completion_response, completion_wake) = call
                .completion
                .as_ref()
                .map(Completion::verification_state)
                .unwrap_or((false, false));
            let owner = match call.response.as_ref() {
                Some(response) => response.verification_owner(),
                None => call
                    .completion
                    .as_ref()
                    .and_then(Completion::verification_owner),
            };
            calls.push(observer::Call {
                index,
                delivery: call.delivery.verification_delivery(),
                response: call.response.is_some(),
                completion: call.completion.is_some(),
                completion_response,
                completion_wake,
                owner,
                worker: call.worker.map(|worker| (worker.wire(), worker.tid())),
                cancelled: call.cancelled,
                kernel: call.kernel,
                service: call.service,
                transferred: call.transferred,
                publication_since: call.publication_since,
            });
        }
        for (index, worker) in self
            .workers
            .iter()
            .enumerate()
            .filter_map(|(index, worker)| worker.as_ref().map(|worker| (index, worker)))
        {
            workers.push(observer::Worker {
                index,
                handle: worker.worker.wire(),
                tid: worker.worker.tid(),
                delivery: worker.delivery.map(Token::wire),
                completed: worker.completed.map(Token::wire),
            });
        }
        observer::Mailbox {
            call_slots: self.calls.len(),
            worker_slots: self.workers.len(),
            closed: self.closed,
            quarantined: self.quarantined,
            completion_cursor: self.completion_cursor,
        }
    }
}
// VERIFICATION OVERLAY ONLY. Caller owns the existing mailbox lock.
impl<M: ResponseMemory> Mailbox<M> {
    pub(crate) fn verification_phase_completion(
        &self,
        key: crate::stability_observer::Selection,
    ) -> Result<bool> {
        let Some(call) = self
            .calls
            .iter()
            .flatten()
            .find(|call| call.delivery.serial().wire() == key.delivery)
        else {
            return Ok(false);
        };
        let delivery = call.delivery.verification_delivery();
        if delivery.pid != key.pid
            || delivery.cpu != key.cpu
            || delivery.requester != key.requester
            || delivery.response != key.response
            || delivery.number != 0
            || delivery.arguments[0] != 0
            || delivery.arguments[2] != 16
            || call.worker.map(|worker| worker.wire()) != Some(key.worker)
        {
            return Err(-71);
        }
        let Some(completion) = call.completion.as_ref() else {
            return Ok(false);
        };
        let claim = completion.verification_owner().ok_or(-71)?;
        if call.cancelled
            || call.kernel
            || call.service
            || call.response.is_some()
            || delivery.phase != "returning"
            || completion.verification_state() != (true, true)
            || claim.os != key.os
            || claim.generation != key.generation
            || claim.response.serial != Some(key.ledger_serial)
            || claim.response.index != key.ledger_index
            || claim.response.physical != key.response
            || claim.response.end != key.response_end
        {
            return Err(-71);
        }
        Ok(true)
    }
}

// SPDX-License-Identifier: GPL-2.0-only
// VERIFICATION OVERLAY ONLY: appended to smp_application_syscall.rs.
// 4 is replaced with the frozen mode 1..4 by the isolated stager.
const STABILITY_FAULT_MODE: u32 = 4;
static STABILITY_FAULT_ATTEMPTS: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);
static STABILITY_FAULT_BARRIERS: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);
static STABILITY_FAULT_SINCE: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
static STABILITY_FAULT_PUBLISHED: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);
static STABILITY_FAULT_NOTIFICATION: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);
static STABILITY_FAULT_REAL_SENDS: core::sync::atomic::AtomicU64 =
    core::sync::atomic::AtomicU64::new(0);

fn stability_fault_publish(packet: &[u8; 128], send: impl FnOnce(&[u8; 128]) -> Result) -> Result {
    use core::sync::atomic::Ordering;
    let attempt = STABILITY_FAULT_REAL_SENDS
        .fetch_update(Ordering::AcqRel, Ordering::Acquire, |old| {
            Some(old.saturating_add(1))
        })
        .unwrap()
        .saturating_add(1);
    if attempt > 32 {
        crate::stability_phase::invalid(-75);
    }
    let begin = unsafe { kernel::bindings::ktime_get() };
    let result = send(packet);
    let end = unsafe { kernel::bindings::ktime_get() };
    if result.is_ok() {
        STABILITY_FAULT_PUBLISHED.store(1, Ordering::Release);
    }
    if attempt <= 32 {
        kernel::pr_info!("STABILITY_FAULT_REAL_SEND version=1 mode={} attempt={} errno={} begin_ns={} end_ns={}\n",
            STABILITY_FAULT_MODE, attempt, result.as_ref().map_or_else(|error| *error, |_| 0), begin, end);
    }
    result
}

fn stability_fault_owner_matches(
    owner: Option<crate::stability_observer::Claim>,
    selected: crate::stability_observer::Selection,
) -> bool {
    owner.is_some_and(|claim| {
        claim.os == selected.os
            && claim.generation == selected.generation
            && claim.response.serial == Some(selected.ledger_serial)
            && claim.response.index == selected.ledger_index
            && claim.response.physical == selected.response
            && claim.response.end == selected.response_end
    })
}

fn stability_fault_accepted(
    request: &Request,
    delivery: u64,
    eligible: bool,
    owner: Option<crate::stability_observer::Claim>,
) {
    let Some(selected) = crate::stability_observer::selected() else {
        return;
    };
    let args = request.arguments();
    if stability_fault_owner_matches(owner, selected)
        && eligible
        && request.number() == 0
        && args[0] == 0
        && args[2] == 16
        && request.pid() == selected.pid
        && request.cpu() == selected.cpu
        && request.requester() == selected.requester
        && delivery == selected.delivery
        && request.response() == selected.response
    {
        crate::stability_phase::accepted_selected();
    }
}

fn stability_fault_send(
    request: &Request,
    delivery: u64,
    eligible: bool,
    owner: Option<crate::stability_observer::Claim>,
    packet: &[u8; 128],
    send: impl FnOnce(&[u8; 128]) -> Result,
) -> Result {
    use core::sync::atomic::Ordering;
    let Some(selected) = crate::stability_observer::selected() else {
        return send(packet);
    };
    let args = request.arguments();
    if !stability_fault_owner_matches(owner, selected)
        || !eligible
        || request.number() != 0
        || args[0] != 0
        || args[2] != 16
        || request.pid() != selected.pid
        || request.cpu() != selected.cpu
        || request.requester() != selected.requester
        || delivery != selected.delivery
        || request.response() != selected.response
    {
        return send(packet);
    }
    // The initial selected key was bound to real OS-generation/ledger/worker
    // owners while this request was Delivered. The selection never resets.
    // A scalar-only barrier can defer publication until the unlocked pump has
    // emitted AcceptedReturn. It never resets the production completion clock.
    if let Err(error) = crate::stability_phase::before_selected_send() {
        STABILITY_FAULT_BARRIERS.fetch_add(1, Ordering::AcqRel);
        return Err(error);
    }
    if STABILITY_FAULT_PUBLISHED.load(Ordering::Acquire) != 0 {
        kernel::pr_info!("STABILITY_FAULT_INVALID version=1 reason=duplicate_selected_send\n");
        return Err(-71);
    }
    let now = unsafe { kernel::bindings::ktime_get() };
    if now <= 0 {
        return Err(-71);
    }
    let now = now as u64;
    let old = STABILITY_FAULT_ATTEMPTS
        .fetch_update(Ordering::AcqRel, Ordering::Acquire, |old| {
            old.checked_add(1)
        })
        .map_err(|_| -75)?;
    if old == 0 {
        STABILITY_FAULT_SINCE.store(now, Ordering::Release);
        kernel::pr_info!("STABILITY_FAULT_SELECTED version=1 mode={} selection={:?} buffer={:x} bytes=16 mono_ns={}\n",
            STABILITY_FAULT_MODE, selected, args[1], now);
    }
    match STABILITY_FAULT_MODE {
        1 => {
            kernel::pr_info!(
                "STABILITY_FAULT_PREPUBLICATION version=1 errno=-5 attempts={} mono_ns={}\n",
                old + 1,
                now
            );
            Err(-5)
        }
        2 => {
            // This is the real unchanged ControlChannel::publish callback.
            stability_fault_publish(packet, send)?;
            kernel::pr_info!(
                "STABILITY_FAULT_PUBLISHED version=1 mode=2 attempts={} mono_ns={}\n",
                old + 1,
                unsafe { kernel::bindings::ktime_get() }
            );
            Ok(())
        }
        3 if now.saturating_sub(STABILITY_FAULT_SINCE.load(Ordering::Acquire)) >= 2_000_000_000 => {
            stability_fault_publish(packet, send)?;
            kernel::pr_info!(
                "STABILITY_FAULT_RECOVERED version=1 mode=3 attempts={} mono_ns={}\n",
                old + 1,
                unsafe { kernel::bindings::ktime_get() }
            );
            Ok(())
        }
        3 | 4 => Err(-11),
        _ => Err(-22),
    }
}

pub(crate) fn stability_fault_notify(
    os: u32,
    generation: u64,
    application: u64,
    cpu: i32,
    notify: impl FnOnce() -> Result,
) -> Result {
    use core::sync::atomic::Ordering;
    if STABILITY_FAULT_MODE == 2
        && crate::stability_observer::selected().is_some_and(|key| {
            key.os == os
                && key.generation == generation
                && key.application == application
                && key.cpu == cpu
        })
        && STABILITY_FAULT_PUBLISHED.load(Ordering::Acquire) == 1
        && STABILITY_FAULT_NOTIFICATION
            .compare_exchange(0, 1, Ordering::AcqRel, Ordering::Acquire)
            .is_ok()
    {
        kernel::pr_info!(
            "STABILITY_FAULT_NOTIFICATION version=1 errno=-5 published=1 mono_ns={}\n",
            unsafe { kernel::bindings::ktime_get() }
        );
        return Err(-5);
    }
    notify()
}

pub(crate) fn stability_fault_observe() {
    use core::sync::atomic::Ordering;
    kernel::pr_info!("STABILITY_FAULT_COUNTS version=1 mode={} attempts={} barrier_attempts={} published={} notification_failures={} real_sends={} since_ns={} mono_ns={}\n",
        STABILITY_FAULT_MODE, STABILITY_FAULT_ATTEMPTS.load(Ordering::Acquire),
        STABILITY_FAULT_BARRIERS.load(Ordering::Acquire), STABILITY_FAULT_PUBLISHED.load(Ordering::Acquire),
        STABILITY_FAULT_NOTIFICATION.load(Ordering::Acquire), STABILITY_FAULT_REAL_SENDS.load(Ordering::Acquire), STABILITY_FAULT_SINCE.load(Ordering::Acquire),
        unsafe { kernel::bindings::ktime_get() });
}
