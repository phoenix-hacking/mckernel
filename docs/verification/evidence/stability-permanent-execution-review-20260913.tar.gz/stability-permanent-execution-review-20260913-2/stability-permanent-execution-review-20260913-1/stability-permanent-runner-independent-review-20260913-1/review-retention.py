import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/home/holden/mckernel')
CANDIDATE = Path('/tmp/stability-permanent-runner-source-20260913-eeby9pq2')
OUT = Path('/tmp/stability-permanent-runner-independent-review-20260913-1')
OUT.mkdir()
shutil.copy2(__file__, OUT / 'review-retention.py')
shutil.copytree(CANDIDATE, OUT / 'candidate')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())


record = json.loads((CANDIDATE / 'record.json').read_bytes())
diffs = []
for row in record['inputs']:
    old = CANDIDATE / (row['name'] + '.original')
    new = CANDIDATE / row['name']
    assert identity(old)['sha256'] == row['original_sha256']
    assert identity(new)['sha256'] == row['candidate_sha256']
    generated = ''.join(difflib.unified_diff(old.read_text().splitlines(True),
                        new.read_text().splitlines(True), fromfile=old.name, tofile=new.name)).encode()
    assert generated == (CANDIDATE / (row['name'] + '.diff')).read_bytes()
    assert old.read_bytes() == (ROOT / 'scripts/tests' / row['name']).read_bytes()
    diffs.append(dict(original=identity(old), candidate=identity(new),
                      exact_diff=identity(CANDIDATE / (row['name'] + '.diff')),
                      current_hard_source_matches_original=True))

paths = [
    'scripts/application-tests/contracts/stability-prepublish-hard-20260913-v1.json',
    'scripts/application-tests/contracts/drafts/stability-permanent-backpressure-20260913-v1.json',
    'scripts/application-tests/phase_observations.py',
    'scripts/application-tests/owner_observations.py',
    'scripts/application-tests/fault_control.py',
    'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/controller.c',
    'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/phase_client.h',
    'scripts/tests/fixtures/stability-transport-fault/send.append.rs',
    'scripts/tests/fixtures/stability-ret-observer.rs',
    'scripts/tests/fixtures/stability-owner-phase/smp_service.append.rs',
    'scripts/tests/prepare_stability_transport_fault.py',
    'host-kernel/native-rust/smp_application_syscall.rs',
    'host-kernel/native-rust/smp_application.rs',
    'docs/verification/stability-remaining-fault-contracts-draft-20260913.md',
]
inputs = []
for relative in paths:
    source = ROOT / relative
    dest = OUT / 'source' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    assert source.read_bytes() == dest.read_bytes()
    inputs.append(dict(original=identity(source), retained=identity(dest)))
result = dict(schema_version=1, status='PASS_BOUNDED_PERMANENT_MODE_DELTA_SOURCE_REVIEW_ONLY',
    definite_findings=[], source_deltas=diffs, reviewed_inputs=inputs,
    confirmed=[
      'Both original hard-mode sources match current files and the guest6 freezes; exact diff bytes reproduced. Hard-mode hash025ffc, mode strings, raw-wait outcomes, admission5 and all physical/native comparison paths are preserved.',
      'Only prepublish-hard and permanent-backpressure pass the preparer and runner mode guards. Mode4 also requires owner-phase-v2 and runnable-thread-v1. Preparer independently binds the same-mode PASS_BUILD_ONLY module and existing source-bound controller/payload outputs.',
      'Mode4 binds exact draft bytes fa5bbb142f3842908eb0a71f9834f1f1477e57049feddeb6dbc6c717b4649f8c. The parser maps permanent-backpressure to the owner contract permanent-pressure and requires address0/1/1/1, payload0/0, release0 and unchanged post-release counters.',
      'Existing parser requires all four complete phases, selected original immutable request and worker/claim, retained Returning completion and original publication timer, stable Terminal/+5 inventories/counters, mode4 runtime and application transport errno-110, attempts>=1 and real_sends/published/notification_failures0.',
      'The source-frozen mode4 send branch always returns -11 before real send or publication. Existing Remote advance expires the original per-completion CLOCK_MONOTONIC-seconds timer after5seconds; publication retries do not reset it.',
      'RET remains actual errno-71/accepted1/value16 within15seconds. The added check requires RET leave_ns >=(retained original publication_since+5)*1e9, in the same host-kernel monotonic clock as the recorded RET and phase observations. It does not substitute fault-attempt since_ns.',
      'Terminal controller admission already expects ETIMEDOUT110 for mode4; runner now matches it. Owner v2 still waits for actual WNOWAIT launcher identity and bothEOF before Terminal; full inventory equality is unchanged.',
      'Normal physical capture remains gated on exact complete prefix, release0/releasedfalse/address0-before-input or1-terminal, and selected original response range. It requires wake2/status0 before input and wake1/status0/value16/stidselected afterward. Emergency collection does not read the selected response.',
      'Modes2/3 stay disabled. No automatic acceptance or physical-full-ring credit is added. The generic remaining-modes wording does not change numerical scores or gate state.',
    ],
    prerequisite_limits=[
      'The mode4 draft must be separately released as the exact hash-bound contract named by the runner; this source review does not copy or release it.',
      'A matching mode4 module, pinned preparation and controlled guest capture are separate requirements. This reviewer did not compile or execute the candidate.',
      'Physical original-request/ring binding, allowed response-byte changes, complete terminal/+5 byte equality, actual provenance and final independent fault review remain separate acceptance inputs.',
      'Injected EAGAIN is not proof of an actually full physical ring. No postpublication-response-read path is authorized; modes2/3 require separate reviewed collectors.',
    ],
    builds_executed=False, tests_executed=False, guest_execution=False,
    application_acceptance=False, transport_acceptance=False, production_gate_credit=False)
with (OUT / 'review.json').open('x') as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(identity(OUT / 'review.json'), indent=2))
