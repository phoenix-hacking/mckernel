"""Publish source-bound prerequisite authorization; no reviewed code executes."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import stat
import tarfile

ROOT = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
OUT = Path('/tmp/stability-permanent-execution-review-20260913-1')
NAME = 'stability-permanent-execution-review-20260913'
OUT.mkdir()
shutil.copy2(__file__, OUT / 'retention.py')


def identity(path):
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        while True:
            data = stream.read(1024 * 1024)
            if not data: break
            digest.update(data)
            count += len(data)
    return dict(path=str(path), size=count, sha256=digest.hexdigest())


def local(path):
    return WORK / path[6:] if path.startswith('/work/') else Path(path)


def retain(path, relative):
    dest = OUT / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)
    before, after = identity(path), identity(dest)
    assert all(before[k] == after[k] for k in ('size', 'sha256'))
    return dict(original=before, retained=relative)


def tree(path):
    rows = []
    for p in [path] + sorted(path.rglob('*')):
        st = p.lstat()
        row = dict(path=str(p.relative_to(path.parent)), mode=stat.S_IMODE(st.st_mode))
        if stat.S_ISDIR(st.st_mode): row['kind'] = 'directory'
        else:
            assert stat.S_ISREG(st.st_mode)
            row.update(kind='file', **{k:v for k,v in identity(p).items() if k != 'path'})
        rows.append(row)
    return rows


review_trees = []
for original in [Path('/tmp/stability-permanent-runner-source-20260913-eeby9pq2'),
                 Path('/tmp/stability-permanent-runner-independent-review-20260913-1'),
                 Path('/tmp/stability-permanent-reused-proof-source-20260913-7_n3p96y')]:
    before = tree(original)
    shutil.copytree(original, OUT / original.name)
    assert tree(original) == tree(OUT / original.name) == before
    review_trees.append(dict(path=str(original), complete_tree=True, members=before))

sources = []
for relative, expected in [
    ('scripts/tests/prepare_stability_fault_guest.py', '0b45f00a6ed72b8b55b25f27261650e14b32e43e398ee2005ffeb5a16ac78d82'),
    ('scripts/tests/run_stability_transport_guest.py', '35095ee65a57638c93179e20433c68ce9688978f201317a0b1cd98ab591ec50e'),
    ('scripts/application-tests/contracts/stability-permanent-backpressure-20260913-v1.json', 'fa5bbb142f3842908eb0a71f9834f1f1477e57049feddeb6dbc6c717b4649f8c'),
    ('scripts/application-tests/contracts/drafts/stability-permanent-backpressure-20260913-v1.json', 'fa5bbb142f3842908eb0a71f9834f1f1477e57049feddeb6dbc6c717b4649f8c')]:
    assert identity(ROOT / relative)['sha256'] == expected
    sources.append(retain(ROOT / relative, 'final-source/' + relative))
correction = Path('/tmp/stability-permanent-reused-proof-source-20260913-7_n3p96y')
old, new = correction / 'prepare_stability_fault_guest.py.original', correction / 'prepare_stability_fault_guest.py'
expected_diff = ''.join(difflib.unified_diff(old.read_text().splitlines(True), new.read_text().splitlines(True),
                       fromfile=old.name, tofile=new.name)).encode()
assert expected_diff == (correction / 'forward.diff').read_bytes()
assert new.read_bytes() == (ROOT / 'scripts/tests/prepare_stability_fault_guest.py').read_bytes()

build_path = WORK / 'stability-transport-fault-module-20260913-permanent-backpressure-1/record.json'
build = json.loads(build_path.read_bytes())
assert identity(build_path)['sha256'] == '7483584353e881946f3d6e5635f3fd6b5d2b6d0a52d2351b99d8c5bf8106ed21'
assert build['status'] == 'PASS_BUILD_ONLY' and build['mode'] == 'permanent-backpressure'
assert build['verification_only'] is True and build['shared_production_trees_restored'] is True
retained = [retain(build_path, 'build/module-record.json')]
compiled = []
for row in build['compiled_modules']:
    got = identity(local(row['path']))
    assert all(got[k] == row[k] for k in ('size', 'sha256'))
    compiled.append(dict(declared=row, independently_rehashed=got))

reuse = build['reused_owner_parser_tests']
prior_path = local(reuse['record']['path'])
assert all(identity(prior_path)[k] == reuse['record'][k] for k in ('size', 'sha256'))
prior = json.loads(prior_path.read_bytes())
assert prior['status'] == 'PASS_BUILD_ONLY' and prior['owner_parser_tests'] == reuse['passed_cases'] == 19 and reuse['rerun'] is False
retained.append(retain(prior_path, 'parser-proof/original-module3-record.json'))
checks = [r for r in prior['commands'] if r['label'] == 'owner-parser-tests']
assert len(checks) == 1
collection = checks[0]['collection']
assert collection['status'] == 'COMPLETED' and collection['raw_wait_status'] == 0 and collection['cleanup_complete'] is True
assert set(collection['streams']) == {'stdout', 'stderr'}
for name, stream in collection['streams'].items():
    assert stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes'] == 0
    got = identity(local(stream['artifact']['path']))
    assert all(got[k] == stream['artifact'][k] for k in ('size', 'sha256'))
    retained.append(retain(local(stream['artifact']['path']), 'parser-proof/' + name + '.bin'))
parser_rows = []
for relative in ['scripts/tests/test_owner_observations.py', 'scripts/application-tests/owner_observations.py']:
    pair = []
    for name, data in [('module3', prior), ('mode4', build)]:
        rows = [r for r in data['fixture_inputs'] if r['path'].endswith('/source/' + relative)]
        assert len(rows) == 1
        row = rows[0]
        got = identity(local(row['path']))
        assert all(got[k] == row[k] for k in ('size', 'sha256'))
        pair.append(row)
        retained.append(retain(local(row['path']), 'parser-proof/' + name + '/' + relative))
    assert all(pair[0][k] == pair[1][k] for k in ('size', 'sha256'))
    parser_rows.append(pair)

# Recheck retained compiler-source identity and the only mode1-to-mode4 change.
previous = {r['retained']['path'].split('/staged-source/', 1)[1]: r for r in prior['retained_compiler_bindings']}
source_changes, compiled_sources = [], []
for row in build['retained_compiler_bindings']:
    path = local(row['retained']['path'])
    got = identity(path)
    assert all(got[k] == row['retained'][k] for k in ('size', 'sha256'))
    compiled_sources.append(got)
    old_row = previous[row['retained']['path'].split('/staged-source/', 1)[1]]['retained']
    if old_row['sha256'] != got['sha256']:
        old_path = local(old_row['path'])
        before, after = old_path.read_bytes(), path.read_bytes()
        assert before.count(b'const STABILITY_FAULT_MODE: u32 = 1;') == 1
        assert before.replace(b'const STABILITY_FAULT_MODE: u32 = 1;', b'const STABILITY_FAULT_MODE: u32 = 4;') == after
        source_changes.append(dict(original=old_row, final=row['retained'], only_change='STABILITY_FAULT_MODE 1 to 4'))
        retained.append(retain(old_path, 'mode-source/original-' + path.name))
        retained.append(retain(path, 'mode-source/final-' + path.name))
assert len(source_changes) == 1 and len(compiled_sources) == 63

for role, name in [('controller', 'stability-owner-terminal-controller-build-20260913-1'),
                   ('payload', 'stability-runnable-thread-payload-build-20260913-1')]:
    path = WORK / name / 'record.json'
    data = json.loads(path.read_bytes())
    assert data['status'] == 'PASS_BUILD_ONLY'
    expected_source = {'controller': '7b1115f4c744d32bb085f23b515e35bcfab4cf0efa6f2e3cb5827742876511e2',
                       'payload': 'dbc68dc4e981c0ed3433491747b4dcd7a031548fbd84bddbd8e98361d4681491'}[role]
    assert data[role + '_source']['sha256'] == expected_source
    assert identity(local(data[role + '_source']['path']))['sha256'] == expected_source
    retained.append(retain(path, 'build/' + role + '-record.json'))
    retained.append(retain(local(data[role + '_source']['path']), 'build/' + role + '.c'))
    for row in data['compiled_outputs']:
        got = identity(local(row['path']))
        assert all(got[k] == row[k] for k in ('size', 'sha256'))
        compiled.append(dict(declared=row, independently_rehashed=got))

baseline_inputs = []
for relative, expected in [
    ('native-ultra-module-20260909-2026091301/bzImage', 'b6cbd689108f499d37ba8d3768f2cdd6cb0f3422d93a4e091af93680686e94eb'),
    ('native-ultra-baseline-memory-guest-20260909-stability-service-failure-20260913-1/initramfs.cpio.gz', 'f74beb4861f2118b5cdb12ec03f304be9d7cb5a281eb7e689d948f02bd8d496a'),
    ('native-ultra-baseline-memory-guest-20260909-stability-service-failure-20260913-1/root/bin/mcexec', 'b786e9c98ecc3d429c5ce4d683f1ef4ebca7b3ea132b8435ed6026fc9e984639'),
    ('native-ultra-baseline-memory-guest-20260909-stability-service-failure-20260913-1/root/images/mckernel.img', 'eb58a8b064212d7fa3ca6949778fd811f985433a54aaf26e7f3e2a0f373a4fd8')]:
    got = identity(WORK / relative)
    assert got['sha256'] == expected
    baseline_inputs.append(got)

failure_path = WORK / 'stability-fault-guest-preparation-20260913-permanent-1/record.json'
failure = json.loads(failure_path.read_bytes())
assert failure['status'] == 'FAIL'
retained.append(retain(failure_path, 'original-failure/preparation-record.json'))
for name, stream in failure['collection']['streams'].items():
    retained.append(retain(local(stream['artifact']['path']), 'original-failure/' + name + '.bin'))
retained.append(retain(WORK / 'stability-fault-guest-root-20260913-permanent-backpressure-1/record.json', 'original-failure/prepared-root-record.json'))

frame_path = ROOT / 'docs/verification/stability-permanent-stack-review-20260913-1.json'
frame = json.loads(frame_path.read_bytes())
retained.append(retain(frame_path, 'stack/root-frame-review.json'))
archive = Path(frame['archive']['path'])
assert identity(archive) == frame['archive']
observed = []
with tarfile.open(str(archive), 'r:gz') as tf:
    for member in tf.getmembers():
        row = dict(path=member.name, mode=member.mode)
        if member.isdir(): row['kind'] = 'directory'
        else:
            assert member.isfile()
            data = tf.extractfile(member).read()
            row.update(kind='file', size=len(data), sha256=hashlib.sha256(data).hexdigest())
        observed.append(row)
assert observed == frame['archive_members']
assert all(v['bytes'] == v['prior_bytes'] for v in frame['chains'].values())
assert frame['full_linux_stack_bound_verified'] is False

document = ROOT / 'docs/verification' / (NAME + '.md')
retain(document, document.name)
review = dict(schema_version=1, status='REVIEWED_FOR_CONTROLLED_MODE4_PREREQUISITE_EXECUTION',
    record_kind='fault_prerequisite_execution_review', execution_authorized=True,
    authorized_mode='permanent-backpressure', mode_id=4,
    controller_profile='owner-phase-v2', payload_profile='runnable-thread-v1',
    catalog_execution_authorized=False, other_fault_modes_authorized_by_this_record=False,
    required_source_bound_preparation_and_preflight=True,
    acceptance_requires_independent_actual_capture_review=True,
    reviewed_sources=sources, original_review_trees=review_trees,
    original_preparation_failure=identity(failure_path),
    corrected_preparer_delta=identity(correction / 'forward.diff'),
    corrected_preparer_source_review='PASS; exact reuse reference/status/19/raw0/cleanup/stream hashes and unchanged prior/mode4 parser-test bytes; fresh-count branch unchanged.',
    release_equals_original_draft=True,
    reused_parser_evidence=dict(reference=reuse['record'], passed_cases=19, rerun=False, exact_source_pairs=parser_rows),
    module_build=identity(build_path), compiled_outputs=compiled, baseline_inputs=baseline_inputs,
    compiler_source_identities=compiled_sources, mode_source_changes=source_changes,
    root_stack_review=identity(frame_path), root_stack_archive=identity(archive),
    root_stack_archive_all_nine_members_rehashed=len(observed) == 9,
    measured_module_paths={k:v['bytes'] for k,v in frame['chains'].items()},
    linux_formatting_context=frame['linux_formatting_context'],
    stack_residuals=frame['residuals'], full_linux_stack_bound_verified=False,
    retained_inputs=retained,
    tests_executed_by_this_lane=False, builds_executed_by_this_lane=False, guest_execution=False,
    application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
    physical_full_ring_verified=False,
    limitations='The source-bound execution authorization permits collecting the specific prerequisite evidence. It supplies no guest result, actual owner safety, runtime stack watermark or full Linux stack bound. Physical/provenance/exit/inventory oracles and all original deadlines remain mandatory.')
with (OUT / 'review.json').open('x') as stream:
    json.dump(review, stream, indent=2, sort_keys=True); stream.write('\n')
members = tree(OUT)
target = ROOT / 'docs/verification/evidence' / (NAME + '.tar.gz')
assert not target.exists()
with tarfile.open(str(target), 'x:gz', format=tarfile.PAX_FORMAT) as tf:
    tf.add(str(OUT), arcname=OUT.name)
found = []
with tarfile.open(str(target), 'r:gz') as tf:
    for member in tf.getmembers():
        row = dict(path=member.name, mode=member.mode)
        if member.isdir(): row['kind'] = 'directory'
        else:
            assert member.isfile()
            data = tf.extractfile(member).read()
            row.update(kind='file', size=len(data), sha256=hashlib.sha256(data).hexdigest())
        found.append(row)
assert sorted(found, key=lambda r:r['path']) == sorted(members, key=lambda r:r['path']) == sorted(tree(OUT), key=lambda r:r['path'])
review.update(document=identity(document), source_capture=str(OUT), archive=identity(target),
              archive_member_count=len(members), archive_members=members,
              all_archive_members_rehashed=True)
published = ROOT / 'docs/verification' / (NAME + '.json')
with published.open('x') as stream:
    json.dump(review, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps(dict(record=identity(published), archive=identity(target), members=len(members)), indent=2))
