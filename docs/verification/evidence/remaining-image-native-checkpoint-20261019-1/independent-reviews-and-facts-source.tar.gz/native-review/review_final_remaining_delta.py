"""Read-only final delta review; proof modes never publish execution authority."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

R = Path(__file__).resolve().parent
N = Path('/home/holden/mckernel-work/host-preparation/evening-fourleaf-native-continuation-20261019-1/remaining-image-fpthread-preparation-1/native-final-preparation-1')
SAVED = {
    'machine': ('machine-execution-release-1.json', '5aaac3c0988ff8f014fc93922c9dce0fbce08b612af9988e642aba20f1f53ef3'),
    'snapshot': ('root-live-preflight-1.json', '40dce685cebc9e434b509318f75867fd7e6afca1fb74b5dbb1edd4037a609af4'),
    'publication': ('root-snapshot-publication-1.json', 'ca6d1ddcb298df137aaf118f1989bad0eef0d38b7271c4a760c151799c7e4188'),
}
REVIEW1_SHA = '4cde3086aa1927b4aead6ab64cb116125f8e666e94f6aa45f5801fd32522404e'
FINAL_SCHEMA = 'mckernel.independent-remaining-fpthread-native-exact-machine-release-review.v1'
FINAL_DECISION = 'PASS_EXACT_REMAINING_FPTHREAD_MACHINE_RELEASE_AND_OWNER_INVOCATION'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def checked(path, expected_sha, root=False):
    path = Path(path)
    assert path.resolve(strict=True) == path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        assert before.st_size <= 1024 * 1024
        if root:
            assert before.st_uid == before.st_gid == 0
            assert stat.S_IMODE(before.st_mode) == 0o644
        chunks = []
        while chunk := os.read(fd, 65536):
            chunks.append(chunk)
        raw = b''.join(chunks)
        assert before == os.fstat(fd)
    finally:
        os.close(fd)
    assert digest(raw) == expected_sha
    return json.loads(raw), raw, before


def saved():
    values = {k: checked(N / name, sha, k != 'machine') for k, (name, sha) in SAVED.items()}
    review, _, _ = checked(R / 'FINAL-REMAINING-FPTHREAD-NATIVE-MACHINE-REVIEW.json', REVIEW1_SHA)
    assert review['schema'] == FINAL_SCHEMA and review['decision'] == FINAL_DECISION
    assert review['machine_release']['sha256'] == SAVED['machine'][1]
    assert review['machine_projection_sha256'] == digest(canonical(values['machine'][0]))
    return values, review


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def validate(values, baseline, paths):
    machine, _, _ = values['machine']
    snapshot, snapshot_raw, snapshot_stat = values['snapshot']
    publication, _, _ = values['publication']
    old_machine, _, _ = baseline['machine']
    old_snapshot, _, _ = baseline['snapshot']
    snapshot_ref = {'path': str(paths['snapshot']), 'sha256': digest(snapshot_raw)}
    publication_ref = {'path': str(paths['publication']), 'sha256': digest(values['publication'][1])}
    expected = copy.deepcopy(old_machine)
    expected.update(fresh_live_preflight=snapshot_ref, snapshot_publication=publication_ref,
                    unprivileged_snapshot_readback={'uid': 1000, 'snapshot_device': snapshot_stat.st_dev,
                        'snapshot_inode': snapshot_stat.st_ino, 'root_owned_readable0644': True})
    assert machine == expected, 'whole machine differs beyond exact three fresh-data fields'
    dynamic = {'time_epoch', 'capacity', 'mem_available_bytes', 'included_usage_percent'}
    assert set(snapshot) == set(old_snapshot)
    assert {k: v for k, v in snapshot.items() if k not in dynamic} == {
        k: v for k, v in old_snapshot.items() if k not in dynamic}
    assert snapshot['time_epoch'] >= old_snapshot['time_epoch']
    assert type(snapshot['included_usage_percent']) in (int, float) and 0 <= snapshot['included_usage_percent'] < 97
    assert type(snapshot['mem_available_bytes']) is int and snapshot['mem_available_bytes'] >= 16 * 2**30
    assert set(snapshot['capacity']) == set(old_snapshot['capacity'])
    for path, row in snapshot['capacity'].items():
        old = old_snapshot['capacity'][path]
        assert set(row) == set(old) == {'available_bytes', 'floor_bytes', 'reserve_bytes'}
        assert row['floor_bytes'] == old['floor_bytes'] and row['reserve_bytes'] == old['reserve_bytes']
        assert type(row['available_bytes']) is int and row['available_bytes'] >= row['floor_bytes'] + row['reserve_bytes']
    assert publication['status'] == 'PASS_ROOT_FD_PUBLISHED_READABLE_SNAPSHOT'
    assert publication['root_readback_bytes_equal'] is True and publication['dispatcher_other_read_bit'] is True
    assert publication['owner_or_guest_invoked'] is False
    descriptor = publication['snapshot']
    assert descriptor['path'] == snapshot_ref['path'] and descriptor['sha256'] == snapshot_ref['sha256']
    assert (descriptor['device'], descriptor['inode'], descriptor['uid'], descriptor['gid'],
            descriptor['mode'], descriptor['nlink']) == (snapshot_stat.st_dev, snapshot_stat.st_ino, 0, 0, 0o644, 1)
    assert descriptor.get('bytes', descriptor.get('size')) == len(snapshot_raw)
    return machine, snapshot


def require_fresh(snapshot):
    age = time.time() - snapshot['time_epoch']
    if not 0 <= age <= 60:
        raise TimeoutError('original snapshot outside unchanged 0..60 second freshness window')
    return age


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    sub = parser.add_subparsers(dest='mode', required=True)
    sub.add_parser('saved-structure')
    sub.add_parser('saved-expiry')
    live = sub.add_parser('review')
    for role in ['machine', 'snapshot', 'publication']:
        live.add_argument('--' + role, required=True)
        live.add_argument('--' + role + '-sha256', required=True)
    live.add_argument('--output', required=True)
    args = parser.parse_args()
    assert os.getuid() == os.geteuid() == 1000
    baseline, old_review = saved()
    if args.mode != 'review':
        paths = {k: N / v[0] for k, v in SAVED.items()}
        _, snapshot = validate(baseline, baseline, paths)
        if args.mode == 'saved-expiry':
            require_fresh(snapshot)
            raise AssertionError('saved snapshot unexpectedly fresh; expiry refusal not demonstrated')
        print(json.dumps({'status': 'PASS_SAVED_CLOSED_STRUCTURAL_DELTA_ONLY', 'runtime_release': False,
                          'report_written': False, 'saved_snapshot_is_expired': time.time() - snapshot['time_epoch'] > 60}))
        return
    paths = {k: Path(getattr(args, k)) for k in SAVED}
    expected_names = {'machine': 'machine-execution-release-2.json', 'snapshot': 'root-live-preflight-2.json',
                      'publication': 'root-snapshot-publication-2.json'}
    assert all(paths[k] == N / expected_names[k] for k in paths)
    output = Path(args.output)
    assert output == R / 'FINAL-REMAINING-FPTHREAD-NATIVE-MACHINE-REVIEW-2.json'
    assert not os.path.lexists(output)
    values = {k: checked(paths[k], getattr(args, k + '_sha256'), k != 'machine') for k in paths}
    machine, snapshot = validate(values, baseline, paths)
    require_fresh(snapshot)
    machine_raw = values['machine'][1]
    report = copy.deepcopy(old_review)
    report.update(machine_release={'path': str(paths['machine']), 'sha256': digest(machine_raw), 'bytes': len(machine_raw)},
                  machine_projection_sha256=digest(canonical(machine)),
                  allowed_argv=['/home/holden/anaconda3/bin/python3', '-I', '-B', str(N / 'dispatch-runtime.py'),
                                '--release', str(paths['machine']), '--release-sha256', digest(machine_raw)],
                  snapshot_time_epoch=snapshot['time_epoch'], snapshot_age_seconds_at_review=require_fresh(snapshot),
                  genuine_root_snapshot=machine['fresh_live_preflight'], snapshot_publication=machine['snapshot_publication'],
                  prior_expired_machine_review={'path': str(R / 'FINAL-REMAINING-FPTHREAD-NATIVE-MACHINE-REVIEW.json'),
                                                'sha256': REVIEW1_SHA},
                  temporal_checker_sha256=digest(Path(__file__).read_bytes()),
                  checker_scope='Only exact saved accepted machine baseline and fresh snapshot/publication/readback delta; unchanged60s.')
    require_fresh(snapshot)
    with output.open('x') as stream:
        stream.write(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': 'PASS_EXACT_REMAINING_FPTHREAD_MACHINE_RELEASE_AND_OWNER_INVOCATION',
                      'path': str(output), 'sha256': digest(output.read_bytes()),
                      'snapshot_age_seconds': time.time() - snapshot['time_epoch']}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except TimeoutError as error:
        print(json.dumps({'status': 'REFUSED_EXPIRED_OR_FUTURE_SNAPSHOT', 'reason': str(error),
                          'report_written': False, 'runtime_release': False}), file=sys.stderr)
        raise SystemExit(2)
