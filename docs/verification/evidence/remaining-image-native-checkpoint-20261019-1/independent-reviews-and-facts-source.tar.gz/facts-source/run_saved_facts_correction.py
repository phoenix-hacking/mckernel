from pathlib import Path
import hashlib,json,os,subprocess,sys,time
F=Path(__file__).resolve().parent;run=F/'affected-saved-facts-run-4'
avail=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'));v=os.statvfs('/home/holden/mckernel-work/scratch');free=v.f_bavail*v.f_frsize
assert avail>16*(1<<30)+(640<<20)+(64<<20) and free>12*(1<<30)+(640<<20)+(64<<20)
assert not run.exists()
for row in json.loads((F/'facts-correction-source-pins.json').read_bytes()).values():assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
assert not (F/'actual-saved-capture-fixture-1').exists()
run.mkdir();start=time.monotonic();argv=[sys.executable,'-I','-B',str(F/'test_saved_facts_correction.py')]
with (run/'stdout').open('xb') as out,(run/'stderr').open('xb') as err:
 child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'});pid=child.pid;rc=child.wait();out.flush();err.flush()
status=dict(argv=argv,returncode=rc,direct_child_joined=True,pid=pid,elapsed_seconds=time.monotonic()-start,host_available=avail,scratch_available=free,root_executed=False)
(run/'status.json').write_text(json.dumps(status,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(returncode=rc,direct_child_joined=True,elapsed_seconds=status['elapsed_seconds'],capture=str(run))));sys.exit(rc)
