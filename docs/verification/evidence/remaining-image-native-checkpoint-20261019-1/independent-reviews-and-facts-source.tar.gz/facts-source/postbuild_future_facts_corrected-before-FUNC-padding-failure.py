"""Actual future fifteen-capture consumer, with late section-aware descriptors."""
from pathlib import Path
import argparse,ast,hashlib,json,re,types
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from terminal_contract import need,checked_bytes,cleanup_canonical,digest
BASE=Path('/home/holden/mckernel-work/host-preparation/evening-four-leaf-production-20261019-1/postbuild-consumer-v2/postbuild_four_leaf_facts_v2.py')
SYMBOLS=('process_current_resource_set_bridge','process_release_hash_detach_bridge','process_release_sibling_detach_bridge','process_release_final_cleanup_bridge')
ARGUMENT_INDICES=(8,9,10,17)  # frozen zero-based Rust body-result argument convention
DESCRIPTORS=('RELEASE_TID_DEBUG','REPLACE_TID_DEBUG')

def base_adapter(ref,receipt_producer):
 need(Path(ref['path'])==BASE,'accepted facts source path')
 raw=checked_bytes(ref);source=raw.decode();m=types.ModuleType('_accepted_fourleaf_facts');m.__file__=receipt_producer['path'];exec(compile(raw,str(BASE),'exec'),m.__dict__)
 node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='validate_completion')
 fn=ast.get_source_segment(source,node)
 old="operations=plan['operations'];need(len(operations)==14 and len({o['index'] for o in operations})==14,'exact fourteen DECLARED operation receipts required')"
 new="operations=plan['operations'];need(len(operations)==15 and len({o['index'] for o in operations})==15,'exact fifteen DECLARED operation receipts required')"
 need(fn.count(old)==1,'frozen completion adaptation point');fn=fn.replace(old,new).replace('range(1,15)','range(1,16)')
 m.REQUIRED_FACT_INDICES=set(range(1,16));m.__file__=receipt_producer['path'];exec(compile(fn,str(Path(__file__).resolve()),'exec'),m.__dict__)
 return m

def symbol_sections(text,tag):
 rows=[line.split() for line in text.splitlines() if line.split() and tag in line.split()[-1]]
 need(len(rows)==1,'one exact descriptor symbol '+tag);r=rows[0]
 need(len(r)>=8 and r[0].endswith(':') and r[6].isdigit(),'numeric actual ELF symbol Ndx')
 need(int(r[2],0)==32,'descriptor size32');return dict(symbol=r[-1],address=int(r[1],16),size=32,ndx=int(r[6]))

def descriptor_facts(m,captures,ops):
 # Each Rust capture is independently section-qualified. Equal address zero in
 # two different sections is valid and must never share one byte dictionary.
 rust=[symbol_sections(captures[9],tag) for tag in DESCRIPTORS]
 image=[symbol_sections(captures[12],tag) for tag in DESCRIPTORS]
 need(rust[0]['ndx']!=rust[1]['ndx'],'distinct actual Rust descriptor sections')
 out={}
 for n,row in enumerate(rust):
  index=13+n;argv=ops[index]['actual_artifact_argv'];need(argv[-3:-1]==['-x',str(row['ndx'])] and argv[0]=='/usr/bin/readelf','late exact Rust section argv')
  names=re.findall(r"Hex dump of section '([^']+)'",captures[index]);need(len(names)==1 and DESCRIPTORS[n] in names[0],'unique descriptor section header')
  bytes_by_address=m.section_bytes(re.sub(r'(?m)^(\s*)0x([0-9a-fA-F]+)',r'\1\2',captures[index]));need(set(bytes_by_address)==set(range(row['address'],row['address']+32)),'exact distinct32B Rust section capture')
  data=bytes(bytes_by_address[row['address']+i] for i in range(32));out['rust_'+DESCRIPTORS[n]]=check_descriptor(row,data)
 start=min(row['address'] for row in image);stop=start+64
 need(sorted(row['address'] for row in image)==[start,start+32],'two exact adjacent32B linked descriptors')
 need(image[0]['ndx']==image[1]['ndx'],'one actual linked descriptor output section')
 argv=ops[15]['actual_artifact_argv'];need(argv[:2]==['/usr/bin/objdump','-s'] and '--start-address='+hex(start) in argv and '--stop-address='+hex(stop) in argv,'late exact64B linked range argv')
 need('-j' not in argv and '__verbose' not in argv,'no invented output section')
 need(len(re.findall(r'Contents of section \S+:',captures[15]))==1,'one actual output section capture')
 raw=m.section_bytes(captures[15]);need(set(raw)==set(range(start,stop)),'exact linked64B bytes')
 for tag,row in zip(DESCRIPTORS,image):out['image_'+tag]=check_descriptor(row,bytes(raw[row['address']+i] for i in range(32)))
 return out

def check_descriptor(row,data):
 need(row['address']%8==0 and len(data)==32,'descriptor size/alignment');need(int.from_bytes(data[:8],'little') and int.from_bytes(data[8:16],'little'),'live file/func pointers')
 flags=int.from_bytes(data[24:28],'little');need(flags>>24==0 and flags&0xffffff and data[16:24]==bytes(8),'default-disabled logger flags/fmt')
 return dict(**row,bytes_hex=data.hex(),line=flags&0xffffff,flags=flags>>24,fmt_null=True)

def actual_callback_facts(m,captures):
 nms={k:m.nm_rows(captures[i]) for k,i in [('process',1),('fallback',4),('rust',7),('image',10)]};facts=[]
 for symbol,index in zip(SYMBOLS,ARGUMENT_INDICES):
  for kind,rows in nms.items():
   need(len([r for r in rows if r[1]=='T' and r[2]==symbol])==(0 if kind=='process' else 1),'selected/fallback unique definition '+kind+':'+symbol);need(not [r for r in rows if r[1]=='U' and r[2]==symbol],'no obsolete C callback dependency '+kind+':'+symbol)
  need(not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|xsave\w*|xrstor\w*)\b',m.body(captures[8],symbol)),'no FP '+symbol)
  facts.append(dict(symbol=symbol,consumer='release_process',argument_index_from_frozen_Rust_source=index,index_convention='zero-based-body-result-argument',machine_default_body_form='INLINED_PHASES_PROVEN_BY_COMPLETE_RELOCATION_PROJECTION',machine_argument_slot_independently_decoded=False))
 for kind in ('process','rust','image'):
  need(len([r for r in nms[kind] if r[1]=='T' and r[2]=='release_process'])==(0 if kind=='process' else 1),'unique actual default Rust release_process owner '+kind)
 return facts


def old_four_leaf_facts(m,captures):
 nm_rows=m.nm_rows;body=m.body
 nms={k:nm_rows(captures[i]) for k,i in [('process',1),('fallback',4),('rust',7),('image',10)]}
 for kind in nms:
  defs=[r for r in nms[kind] if r[1]=='T' and r[2]=='__release_tid'];unresolved=[r for r in nms[kind] if r[1]=='U' and r[2]=='__release_tid']
  assert len(defs)==(0 if kind=='process' else 1),(kind,defs)
  assert len(unresolved)==(1 if kind=='process' else 0),(kind,unresolved)
 for kind in nms:
  for normal_symbol in ['process_destroy_thread_time_account_bridge','process_destroy_thread_hash_detach_bridge']:
   defined=[v for v in nms[kind] if v[1]=='T' and v[2]==normal_symbol]
   unresolved=[v for v in nms[kind] if v[1]=='U' and v[2]==normal_symbol]
   assert len(defined)==(0 if kind=='process' else 1),(kind,normal_symbol,defined)
   assert not unresolved,(kind,normal_symbol,unresolved)
 timebody=body(captures[8],'process_destroy_thread_time_account_bridge')
 hashbody=body(captures[8],'process_destroy_thread_hash_detach_bridge')
 for normal_body in [timebody,hashbody]:
  assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|xsave\w*|xrstor\w*)\b',normal_body)
 for kind in ['process','image']:
  assert len([r for r in nms[kind] if r[1]=='T' and r[2]=='process_destroy_thread_release_tid_bridge'])==1
 assert '__release_tid' in body(captures[2],'process_destroy_thread_release_tid_bridge')
 projected_body(m,captures,'process_destroy_thread_release_tid_bridge',2,3,12,1)
 actualbody=body(captures[8],'__release_tid');assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|xsave\w*|xrstor\w*)\b',actualbody)
 for kind in nms:
  defined=[r for r in nms[kind] if r[1]=='T' and r[2]=='__find_and_replace_tid'];unresolved=[r for r in nms[kind] if r[1]=='U' and r[2]=='__find_and_replace_tid']
  assert len(defined)==(0 if kind=='process' else 1),(kind,defined)
  assert len(unresolved)==(1 if kind=='process' else 0),(kind,unresolved)
 for kind in ['process','image']:
  assert len([r for r in nms[kind] if r[1]=='T' and r[2]=='process_destroy_thread_replace_tid_bridge'])==1
 assert '__find_and_replace_tid' in body(captures[2],'process_destroy_thread_replace_tid_bridge')
 projected_body(m,captures,'process_destroy_thread_replace_tid_bridge',2,3,12,1)
 replacebody=body(captures[8],'__find_and_replace_tid');assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|xsave\w*|xrstor\w*)\b',replacebody)
 return dict(status="PASS_OLD_FOUR_LEAF_MECHANICAL_FACTS_FROM_THIS_FIFTEEN_CAPTURE_SET",native_acceptance=False)


ANALYSIS_REF=dict(path='/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-review-20261019-1/REMAINING-SAVED-MACHINE-ENTRY-ANALYSIS.json',sha256='4883f3635ded142a3ae0d116cfcc557338c15e9d734975598f29b38d36b40299')

def function_symbol(text,name):
 rows=[l.split() for l in text.splitlines() if l.split() and l.split()[-1]==name and len(l.split())>=8 and l.split()[3]=='FUNC']
 need(len(rows)==1,'unique actual FUNC '+name);r=rows[0];need(r[6].isdigit(),'actual FUNC section '+name)
 return int(r[1],16),int(r[2],0)

def raw_function(m,text,name,start,size):
 body=m.body(text,name);data={};instructions={};relocations=[]
 for line in body.splitlines():
  relocation=re.match(r'\s*([0-9a-f]+):\s+R_(\S+)\s+(\S+)',line)
  if relocation:
   relocations.append((int(relocation[1],16)-start,relocation[2],relocation[3]));continue
  parts=line.split('\t');addr=re.match(r'^\s*([0-9a-f]+):$',parts[0])
  if not addr or len(parts)<2:continue
  tokens=parts[1].strip().split()
  if not tokens or any(re.fullmatch('[0-9a-f]{2}',t) is None for t in tokens):continue
  offset=int(addr[1],16)-start
  for i,token in enumerate(tokens):need(offset+i not in data,'no overlapping function bytes');data[offset+i]=int(token,16)
  if len(parts)>2 and parts[2].strip():instructions[offset]=' '.join(parts[2].split())
 need(set(data)==set(range(size)),'complete exact function byte bounds '+name)
 return bytearray(data[i] for i in range(size)),relocations,instructions

def projected_body(m,captures,symbol,object_disasm,object_symbols,expected_size,expected_relocations):
 start,size=function_symbol(captures[object_symbols],symbol);image_start,image_size=function_symbol(captures[12],symbol);need(size==image_size==expected_size,'exact object/image FUNC size '+symbol)
 raw,relocs,instructions=raw_function(m,captures[object_disasm],symbol,start,size);image,linked_relocs,_=raw_function(m,captures[11],symbol,image_start,size);need(not linked_relocs,'linked FUNC has no unresolved relocation')
 need(len(relocs)==expected_relocations,'all exact relocations '+symbol);providers=m.nm_rows(captures[10]);covered=set();joined=[]
 for offset,kind,target in relocs:
  need(kind=='X86_64_64' and offset>=0 and offset+8<=size and not covered.intersection(range(offset,offset+8)),'exact nonoverlapping ABS64 relocations');covered.update(range(offset,offset+8))
  match=re.fullmatch(r'(.+?)(?:([+-])0x([0-9a-f]+))?',target);need(match is not None,'explicit relocation target');name=match[1];addend=(int(match[3],16)*(1 if match[2]=='+' else -1)) if match[3] else 0
  defined=[r for r in providers if r[2]==name and r[1]!='U'];need(len(defined)==1,'unique linked relocation provider '+name);address=int(defined[0][0],16)+addend
  raw[offset:offset+8]=(address&((1<<64)-1)).to_bytes(8,'little');joined.append(dict(offset=offset,kind=kind,provider=name,address=address,addend=addend))
 need(bytes(raw)==bytes(image),'all relocated object bytes equal exact linked default body '+symbol)
 return dict(symbol=symbol,object_start=start,image_start=image_start,size=size,relocations=joined,relocation_count=len(joined),linked_bytes_sha256=digest(bytes(image)),all_bytes_matched=True),instructions

def phase_witnesses(instructions,order=('current_resource_set','hash_detach','sibling_detach','final_cleanup')):
 need(order==('current_resource_set','hash_detach','sibling_detach','final_cleanup'),'source/default phase order')
 patterns={0x91:r'mov 0x1ee8\(%rcx,%rax,1\),%rbx',0x102:r'callq? \*%r13',0x139:r'callq? \*%r12',0x151:r'callq? \*%r13',0x19d:r'callq? \*%r12',0x25e:r'mov %rbx,%r12',0x34d:r'callq? \*%r8',0x36c:r'callq? \*%rax',0x37d:r'cmp',0x390:r'callq? \*%rax',0x3b0:r'callq? \*%rax'}
 for offset,pattern in patterns.items():need(re.search(pattern,instructions.get(offset,'')) is not None,'typed inline phase witness '+hex(offset))
 # Independent high-review analysis supplies the exact additional lock/list/poison fields,
 # all covered by the independently recomputed full996byte/21relocation projection.
 analysis=__import__('json').loads(checked_bytes(ANALYSIS_REF));return dict(order=list(order),configuration='ACTUAL_NON_TOFU_ONLY',instruction_witnesses={hex(k):instructions[k] for k in patterns},typed_phase_fields=analysis['selected_inline_phase_witnesses'],analysis=ANALYSIS_REF)

def source_consumer(known):
 request=__import__('json').loads(checked_bytes(known['request'],64<<20));manifest=__import__('json').loads(checked_bytes(known['actual_source_manifest'],64<<20));p=Path(request['source_root'])/'kernel/rust/process_helpers.rs';source=checked_bytes(dict(path=str(p),sha256=manifest['materialized_repository_files']['kernel/rust/process_helpers.rs']),4<<20).decode()
 match=re.search(r'pub unsafe extern "C" fn release_process\(proc: \*mut Process\) \{\n(.*?)\n\}',source,re.S);need(match is not None,'frozen default exported Rust consumer');body=match[1]
 arguments=body.split('process_release_process_body_result(',1)[1].rsplit(');',1)[0];lines=[l.strip().rstrip(',') for l in arguments.splitlines() if l.strip()]
 need(len(lines)==18 and {name:lines[index] for name,index in zip(SYMBOLS,ARGUMENT_INDICES)}=={name:'Some('+name+')' for name in SYMBOLS},'exact frozen Some callback source argument indices')
 return dict(path=str(p),sha256=manifest['materialized_repository_files']['kernel/rust/process_helpers.rs'],function='release_process',argument_indices=dict(zip(SYMBOLS,ARGUMENT_INDICES)),default_Rust_source=True,actual_machine_named_callback_calls=False,machine_argument_slots_independently_decoded=False,retained_fullcrate_C109_provenance=known['retained_prebuild_acceptance'])


def evaluate_saved(known,plan_ref,release_ref,completion_ref):
 original_release=__import__('json').loads(checked_bytes(release_ref,16<<20));receipt_producer=original_release['descriptor_facts_producer'];checked_bytes(receipt_producer,4<<20)
 m=base_adapter(known['engines']['facts'],receipt_producer);plan,captures,completion=m.validate_completion(Path(plan_ref['path']),plan_ref['sha256'],Path(release_ref['path']),release_ref['sha256'],Path(completion_ref['path']),completion_ref['sha256'])
 old=old_four_leaf_facts(m,captures);callbacks=actual_callback_facts(m,captures);machine,instructions=projected_body(m,captures,'release_process',8,9,996,21);phases=phase_witnesses(instructions);source=source_consumer(known);ops={o['index']:o for o in plan['operations']};descriptors=descriptor_facts(m,captures,ops)
 return dict(schema='mckernel.future-four-callback.postbuild-additive-facts.v1',status='PASS_ADDITIVE_MECHANICAL_FACTS_ONLY',completion=completion,original_receipt_producer=receipt_producer,old_four_leaf_facts=old,callbacks=callbacks,default_Rust_consumer=source,actual_default_machine_projection=machine,actual_inline_phase_witnesses=phases,descriptors=descriptors,derived_pointer_windows=[dict(tag=tag,field=field,address=int.from_bytes(bytes.fromhex(value['bytes_hex'])[offset:offset+8],'little'),extent=extent,artifact=plan['paths']['image']) for tag,value in descriptors.items() if tag.startswith('image_') for field,offset,extent in [('file',0,256),('func',8,64)]],pending=['four actual image file/func pointer windows','independent canonical/physical/native acceptance'],original_full_syscall_DWARF_gap='OPEN_NO_REPLAY_NO_WAIVER',production_or_native_acceptance=False),m,captures,instructions

def main():
 a=argparse.ArgumentParser()
 for name in ('known','plan','release','completion','facts-authorization'):a.add_argument('--'+name,required=True);a.add_argument('--'+name+'-sha256',required=True)
 a.add_argument('--output',required=True);x=a.parse_args();refs={name:dict(path=getattr(x,name),sha256=getattr(x,name+'_sha256')) for name in ('known','plan','release','completion','facts_authorization')};authorization=__import__('json').loads(checked_bytes(refs['facts_authorization'],4<<20))
 need(authorization['decision']=='PASS_REMAINING_FACTS_ONLY_SOURCE_CORRECTION_USING_PRESERVED_15' and authorization['implementation_ownership'] is False and authorization['reviewer']!=authorization['author'],'independent facts-only authorization')
 need(authorization['facts_producer']==dict(path=str(Path(__file__).resolve()),sha256=digest(Path(__file__).read_bytes())),'exact corrected producer authorization')
 for key in ('known','plan','release','completion'):need(authorization[key]==refs[key],'unchanged original observation identity '+key)
 known=__import__('json').loads(checked_bytes(refs['known'],4<<20));result,_,_,_=evaluate_saved(known,refs['plan'],refs['release'],refs['completion']);result['facts_only_authorization']=refs['facts_authorization']
 with Path(x.output).open('x') as f:__import__('json').dump(result,f,sort_keys=True,indent=2);f.write('\n')
 print('PASS corrected facts from preserved15; exact default996B/21relocations +typedphase witnesses; no native acceptance')
if __name__=='__main__':main()
