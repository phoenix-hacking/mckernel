import hashlib,json,subprocess,os,time
from pathlib import Path
N=Path(__file__).resolve().parent;p=N/'fresh2-additive-output-and-argv-1.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a30e872fd268f05f628ecf6d36e3f43ec09275a04d11a939e99f1ec8ce7b5265'
d=json.loads(p.read_bytes());os.umask(0o077);root=N/'actual-finalization-2';root.mkdir(mode=0o700)
def run(role,argv):
 assert not any(x=='PENDING' for x in argv)
 (root/(role+'.command.json')).write_text(json.dumps(dict(argv=argv))+'\n');t=time.monotonic()
 with (root/(role+'.stdout')).open('xb') as out,(root/(role+'.stderr')).open('xb') as err:
  c=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);start=Path('/proc/%d/stat'%c.pid).read_text().rsplit(')',1)[1].split()[19];rc=c.wait();out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
 (root/(role+'.status.json')).write_text(json.dumps(dict(returncode=rc,direct_child_joined=True,pid=c.pid,start=start,elapsed_seconds=time.monotonic()-t))+'\n');assert rc==0,role
run('root-snapshot',d['root_snapshot_argv']);argv=d['UID1000_assembler_argv']
s=Path(argv[argv.index('--snapshot')+1]);p=Path(argv[argv.index('--publication')+1]);sh=hashlib.sha256(s.read_bytes()).hexdigest();ph=hashlib.sha256(p.read_bytes()).hexdigest();argv[argv.index('--snapshot-sha256')+1]=sh;argv[argv.index('--publication-sha256')+1]=ph
run('machine-assembly',argv);m=Path(argv[argv.index('--output')+1]);result=dict(snapshot=str(s),snapshot_sha256=sh,publication=str(p),publication_sha256=ph,machine=str(m),machine_sha256=hashlib.sha256(m.read_bytes()).hexdigest());(root/'completed-output-notification.json').write_text(json.dumps(result)+'\n');print(json.dumps(result))
