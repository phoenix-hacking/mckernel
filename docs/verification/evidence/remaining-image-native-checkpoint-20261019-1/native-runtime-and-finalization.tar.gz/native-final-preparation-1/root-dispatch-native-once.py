import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--review',required=True);p.add_argument('--sha256',required=True);p.add_argument('--capture',required=True);a=p.parse_args()
N=Path(__file__).resolve().parent;r=Path(a.review);assert hashlib.sha256(r.read_bytes()).hexdigest()==a.sha256
argv=['/home/holden/anaconda3/bin/python3','-I','-B',str(N/'coordinator-final-launch-guard.py'),str(r),a.sha256]
root=N/a.capture;root.mkdir(mode=0o700);os.umask(0o077)
(root/'command.json').write_text(json.dumps(dict(argv=argv))+'\n');t=time.monotonic()
with (root/'stdout').open('xb') as out,(root/'stderr').open('xb') as err:
 c=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 start=Path('/proc/%d/stat'%c.pid).read_text().rsplit(')',1)[1].split()[19]
 (root/'child.json').write_text(json.dumps(dict(pid=c.pid,start=start,pgid=c.pid))+'\n')
 rc=c.wait();out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
status=dict(returncode=rc,direct_child_joined=True,pid=c.pid,start=start,elapsed_seconds=time.monotonic()-t)
(root/'status.json').write_text(json.dumps(status)+'\n');print(json.dumps(status))
