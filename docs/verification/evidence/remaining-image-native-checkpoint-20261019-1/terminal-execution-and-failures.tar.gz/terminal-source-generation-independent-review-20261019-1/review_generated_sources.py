from pathlib import Path
import json,ast,hashlib,time
r=Path(__file__).parent
l=Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/remaining-only-late-binding-1')
proofp=l/'generated-terminal-source-literal-proof.json';proof=json.loads(proofp.read_text());pinp=l/'generated-terminal-helper-pins.json';pins=json.loads(pinp.read_text())
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def funcs(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
readbacks=[]
for row in proof['readback_literal_proofs']:
 a=Path(row['accepted_source']['path']).read_bytes();b=Path(row['generated_source']['path']).read_bytes()
 assert hashlib.sha256(a).hexdigest()==row['accepted_source']['sha256'];assert hashlib.sha256(b).hexdigest()==row['generated_source']['sha256'];assert funcs(a)==funcs(b)
 ta=ast.parse(a);tb=ast.parse(b);allowed=set(row['allowed_case_global_names'])
 old={n.targets[0].id:n for n in ta.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
 new={n.targets[0].id:n for n in tb.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
 changed=[]
 for name in allowed&set(old)&set(new):
  v=new[name].value
  assert isinstance(v,ast.Constant) and isinstance(v.value,str) or isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id=='Path' and not v.keywords and len(v.args)==1 and isinstance(v.args[0],ast.Constant) and isinstance(v.args[0].value,str)
  if ast.dump(old[name].value)!=ast.dump(v):changed.append(name)
  old[name].value=v
 assert ast.dump(ta,include_attributes=False)==ast.dump(tb,include_attributes=False),row['role']
 readbacks.append({'role':row['role'],'functions_unchanged':len(funcs(b)),'only_changed_case_globals':sorted(changed)})
expected={'cleanup':{'configure','image_request_binding'},'observer':{'main'}}
for row in proof['engine_function_inventory']:
 a=Path(row['accepted_source']['path']).read_bytes();b=Path(row['generated_source']['path']).read_bytes();fa=funcs(a);fb=funcs(b)
 assert set(fa)==set(fb);assert {k for k in fa if fa[k]!=fb[k]}==expected[row['role']]
 assert hashlib.sha256(b).hexdigest()==row['generated_source']['sha256']
statusp=l/'source-generation-run-1/status.json';status=json.loads(statusp.read_text())
assert status['returncode']==0 and status['direct_children_joined'] is True and status['root_executed'] is False and len(status['commands'])==3
for v in pins.values():assert hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256']
report={'schema':'mckernel.independent-generated-terminal-source-review.v1','status':'PASS','reviewer':'clone_thread_affinity_rust_repair','implementation_ownership':False,'scope':'SOURCE_PUBLICATION_AND_LITERAL_BOUNDARY_ONLY_NO_TERMINAL_EXECUTION','reviewed_unix':int(time.time()),'observer_sha256':pins['observe_four_leaf_image_retirement.py']['sha256'],'cleanup_source_sha256':pins['cleanup_fourleaf.py']['sha256'],'cleanup_tests_sha256':'2fba315ad96f271124cf78f7441faa306f58ea03ae35cdbe78bba5be6488d630','helper_pins':ref(pinp),'source_owner_literal_proof':ref(proofp),'genuine_generation_status':ref(statusp),'independent_readback_analysis':readbacks,'independent_changed_function_analysis':{'cleanup':['configure: exact actualguard stem literals only','image_request_binding: exact actualmaterialized source root premise'],'observer':['main: exact actualsource/control paths and additional9+3 control/import digest checks']},'source11_control_contract':{'source11':11,'remaining_control_sources':9,'separate_accepted_imports':3,'declared_host_owner_sha256':'96d17547bfc71454d54e95a705138cc9b26faa1e2cafc34105c9ed8d5a68f4d1','actual_remaining_owner_sha256':'abe9e169889f055269a78b105e0e42cf7b221853f6cfabec425e3700d1a1a325','scope_not_conflated':True},'canonical_rules':{'cleanup_release_and_observation':'sortedcompact_NO_newline','observation_and_raw5_release':'sortedcompact_ONE_newline'},'source_acceptance_does_not_authorize':['rootobserver','raw5export','cleanup','nativeguest','imageacceptance'],'remaining_gates':['Publish exact updated allowlist genuine sixsource+generatedbindings and fetchedblobproof','Independent exact observation payload binding commit/tree/fetch/sourcecaps/CID66a','Actual observer+distinctsummary direct0 and actual5FDmetadata before raw5','Cleanup actual5/42FDrows/source/owner review, noLFrelease and freshcriticaladmission','ExactCID66a/journaledremainingcommon+shared only; preserveallsources/seeds/failedtrees'],'raw5_external_fd_gate_caveat':'Accepted raw5helper enforces5hashes+observer/summarydirect0+independentpayloadreview, but does not itself consume extra original_five_fd_metadata fields. Independent mechanical payload/runner review must positively bind genuine actual5FDmetadata status+rows before export; declarations are insufficient.','reused_path_review':'441f82b0624ffb50afd53ca27e68cc4efaca81aad74644309699d55e534c5f96/7actualconsumerchecks_not_rerun','analysis_failure_preserved':'generated-source-review-write.stderr: initial reviewer script incorrectly required each helper to contain every allowed global; allowed set is a shared superset. Corrected analysis intersects present globals and still compares entire module AST exactly. No source or test failure.','reviewer_tests':0,'reviewer_source_edits':0,'reviewer_root_runtime_operations':0}
p=r/'GENERATED-TERMINAL-SOURCE-REVIEW.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');(r/'generated-review-sha.txt').write_text(ref(p)['sha256']+'\n')
