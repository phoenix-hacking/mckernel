from pathlib import Path
import os,stat,json,hashlib,errno
r=Path(__file__).parent;b=Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/remaining-only-late-binding-1/terminal-handoff-preparation-1');d=b/'actual-root-readonly-1';l=b.parent
NAMES=['observer-result.json','observation.json','cleanup-release-draft.json','new-object-metadata.json','ownership.json'];OUTPUT=l/'root-observation-future-four-callback-remaining-observation-1'
def sha(x):return hashlib.sha256(x).hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes())}
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def stream(v):
 p=Path(v['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  before=os.fstat(fd);assert stat.S_ISREG(before.st_mode) and ident(before)==v['metadata'];assert before.st_uid==1000 and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600 and 0<=before.st_size<33554432
  with os.fdopen(os.dup(fd),'rb') as f:raw=f.read(before.st_size+1)
  after=os.fstat(fd);assert ident(before)==ident(after)==ident(os.stat(p,follow_symlinks=False));assert len(raw)==before.st_size and sha(raw)==v['sha256'];return raw
 finally:os.close(fd)
ops=json.loads((b/'first-four-readonly-capture-bindings-PUBLISHED-DATA.json').read_text());policy=ref(b/'first-four-readonly-capture-bindings-PUBLISHED-DATA.json');assert policy['sha256']=='b7a11000a9546a1c13b954c71233f17ee7ad5600ac3e8ec3acf096954b36977c'
hashfile=b/'actual-original-five-hashes.json';hs=hashfile.stat();assert hs.st_uid==1000 and hs.st_nlink==1 and stat.S_IMODE(hs.st_mode)==0o600;hashes=json.loads(hashfile.read_bytes());assert set(hashes)==set(NAMES);hashref=ref(hashfile)
expectedrelease='4f8d3c718ae273366145d08bcbab44d5913ff0004e94db9c2f1c5527e73183e4';assert sha((b/'observation-execution-release.json').read_bytes())==expectedrelease
rows=[];outputs={};groups=[]
for i,label in enumerate(['observer','summary','original-five-FD-metadata']):
 p=d/(label+'.status.json');s=json.loads(p.read_bytes());assert s['returncode']==0 and s['direct_child_joined'] is True and s['observer_error'] is None
 expected=[expectedrelease if x=='BIND_EXACT_INDEPENDENT_OBSERVER_RELEASE_SHA256' else hashref['sha256'] if x=='BIND_GENUINE_SUMMARY_FIVE_HASHFILE_SHA256' else x for x in ops['operations'][i]['argv']];assert s['argv']==expected
 command=json.loads(Path(str(p)+'.command.json').read_bytes());child=json.loads(Path(str(p)+'.child.json').read_bytes());assert command['argv']==expected and command['role']==s['role'] and command['policy']==policy
 assert child['argv']==expected and child['pid']==s['pid']==child['pgid'] and str(child['start'])==str(s['start']) and int(s['start'])>0
 try:os.killpg(child['pgid'],0)
 except ProcessLookupError:groups.append({'pgid':child['pgid'],'result':'ESRCH'})
 else:raise AssertionError(('groupstillpresent',label))
 stdout=stream(s['streams']['stdout']);assert stream(s['streams']['stderr'])==b'';outputs[label]=json.loads(stdout)
 rows.append({'role':label,'status':ref(p),'command':ref(Path(str(p)+'.command.json')),'child':ref(Path(str(p)+'.child.json')),'pid':s['pid'],'start':s['start'],'streams':s['streams']})
assert len({x['pid'] for x in rows})==3
observer=outputs['observer'];summary=outputs['summary'];meta=outputs['original-five-FD-metadata']
assert observer['status']=='PASS_READ_ONLY_OBSERVATION_ONLY' and observer['cleanup_executed'] is False and observer['output']==str(OUTPUT)
assert summary['status']=='PASS_EXACT_FINITE_OBSERVER_READBACK_ONLY' and summary['application_acceptance'] is False and summary['cleanup_authorized'] is False and summary['file_sha256']==hashes
assert summary['nonce']=='future-four-callback-remaining-observation-1'
assert meta['status']=='PASS_EXACT_ORIGINAL_FIVE_FD_METADATA_ONLY' and meta['members']==5 and meta['output']==str(OUTPUT) and meta['nonce']==summary['nonce'] and meta['file_sha256']==hashes
assert all(meta[k] is False for k in ['observer_replayed','export_executed','cleanup_authorized','application_acceptance'])
pins=json.loads((l/'generated-terminal-helper-pins.json').read_text());assert meta['summary_source_sha256']==pins['readback_observer.py']['sha256'];objects=meta['objects'];assert len(objects)==5 and {Path(x['path']).name for x in objects}==set(NAMES)
for v in objects:
 assert set(v)=={'path','device','inode','uid','gid','mode','nlink','size','mtime_ns','ctime_ns','sha256'};p=Path(v['path']);assert p.parent==OUTPUT and p.name in NAMES
 assert all(type(v[k]) is int for k in ['device','inode','uid','gid','nlink','size','mtime_ns','ctime_ns']);assert v['device']==66306 and v['inode']>0 and v['uid']==v['gid']==0 and v['mode']=='0o600' and v['nlink']==1 and 0<v['size']<=134217728 and v['mtime_ns']>0 and v['ctime_ns']>=v['mtime_ns'];assert v['sha256']==hashes[p.name]
assert len({(x['device'],x['inode']) for x in objects})==5
archive_upper=sum(x['size']+1024 for x in objects)+10240;assert archive_upper<33554432
report={'status':'PASS_ACTUAL_DISTINCT_FIRST3_AND_ORIGINAL5_FD_EXTERNAL_GATE','reviewer':'clone_thread_affinity_rust_repair','implementation_ownership':False,'operation_bindings':policy,'capture_implementation':ref(b/'root-case-capture-primitive-1.py'),'actual_status_records':rows,'positive_direct_joins':3,'all_groups_absent':groups,'file_sha256':hashes,'hashfile':hashref,'original_five_fd_metadata':ref(d/'original-five-FD-metadata.stdout'),'original_five_fd_metadata_status':ref(d/'original-five-FD-metadata.status.json'),'original_five_fd_objects':objects,'observer_status':ref(d/'observer.status.json'),'summary_status':ref(d/'summary.status.json'),'summary_source_sha256':meta['summary_source_sha256'],'fixed_output':str(OUTPUT),'nonce':meta['nonce'],'raw5_archive_upper_bound':archive_upper,'raw5_cap_bytes':33554432,'reviewer_root_actions':0,'signal_zero_checks_only':True,'cleanup_authorized':False}
(r/'ACTUAL-FIRST3-ORIGINAL5-FD-GATE-REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
