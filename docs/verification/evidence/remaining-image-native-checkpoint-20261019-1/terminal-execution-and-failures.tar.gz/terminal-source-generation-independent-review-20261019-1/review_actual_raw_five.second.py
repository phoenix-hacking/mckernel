from pathlib import Path
import os,stat,json,hashlib,tarfile,io
r=Path(__file__).parent;b=Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/remaining-only-late-binding-1/terminal-handoff-preparation-1');d=b/'actual-root-readonly-1'
sha=lambda x:hashlib.sha256(x).hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes())}
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def stream(v):
 p=Path(v['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  before=os.fstat(fd);assert stat.S_ISREG(before.st_mode) and ident(before)==v['metadata'] and before.st_uid==1000 and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600 and before.st_size<33554432
  with os.fdopen(os.dup(fd),'rb') as f:raw=f.read(before.st_size+1)
  assert ident(before)==ident(os.fstat(fd))==ident(os.stat(p,follow_symlinks=False));assert len(raw)==before.st_size and sha(raw)==v['sha256'];return raw
 finally:os.close(fd)
g=json.loads((r/'ACTUAL-FIRST3-ORIGINAL5-FD-GATE-REVIEW.json').read_text());p=d/'raw-five-export.status.json';s=json.loads(p.read_text());assert s['returncode']==0 and s['direct_child_joined'] is True and s['observer_error'] is None
command=json.loads(Path(str(p)+'.command.json').read_text());child=json.loads(Path(str(p)+'.child.json').read_text());assert command['argv']==s['argv']==child['argv'] and child['pid']==s['pid']==child['pgid'] and str(child['start'])==str(s['start'])
ops=json.loads((b/'first-four-readonly-capture-bindings-PUBLISHED-DATA.json').read_text());template=ops['operations'][3]['argv'];assert template[-2]=='--release-sha256' and template[-1].startswith('BIND_');expected=template[:-1]+['313f4a4bf1160384fd2c36cd6ab4549f287f2c6eb996f3cefcd4d2da9c238eb2']
assert s['argv']==expected
try:os.killpg(child['pgid'],0)
except ProcessLookupError:group='ESRCH'
else:raise AssertionError('raw5groupnotretired')
raw=stream(s['streams']['stdout']);assert stream(s['streams']['stderr'])==b'' and len(raw)==614400
names=['observer-result.json','observation.json','cleanup-release-draft.json','new-object-metadata.json','ownership.json'];parsed={};memberrows=[]
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
 members=tar.getmembers();assert [x.name for x in members]==names
 for m in members:
  assert m.isreg() and not m.pax_headers and not m.linkname and m.mode==0o600 and m.uid==m.gid==0
  f=tar.extractfile(m);data=f.read(m.size+1);assert len(data)==m.size and sha(data)==g['file_sha256'][m.name]
  fdrow=next(v for v in g['original_five_fd_objects'] if Path(v['path']).name==m.name);assert m.size==fdrow['size'] and m.mtime==fdrow['mtime_ns']//10**9
  assert raw[m.offset+257:m.offset+263]==b'ustar\x00'
  parsed[m.name]=json.loads(data);memberrows.append({'name':m.name,'size':m.size,'sha256':sha(data),'mtime':m.mtime,'offset':m.offset})
summary=json.loads((d/'summary.stdout').read_text());assert parsed['observer-result.json']==summary['result'] and parsed['observation.json']==summary['observation'] and parsed['cleanup-release-draft.json']==summary['cleanup_draft'] and parsed['new-object-metadata.json']==summary['new_object_metadata'] and parsed['ownership.json']==summary['ownership']
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
assert sha(canonical(parsed['observation.json']))==parsed['cleanup-release-draft.json']['observation_canonical_sha256']
objects=parsed['new-object-metadata.json']['objects'];assert len(objects)==42
(r/'ACTUAL-RAW5-ARCHIVE-REVIEW.json').write_text(json.dumps({'status':'PASS_ACTUAL_EXACT_RAW_FIVE_ARCHIVE','reviewer':'clone_thread_affinity_rust_repair','implementation_ownership':False,'status_record':ref(p),'command_record':ref(Path(str(p)+'.command.json')),'child_record':ref(Path(str(p)+'.child.json')),'streams':s['streams'],'pid':s['pid'],'start':s['start'],'direct_child_joined':True,'returncode':0,'group':group,'exact_archive_bytes':len(raw),'format':'GNU_ustar','members':memberrows,'original_five_fd_gate':ref(r/'ACTUAL-FIRST3-ORIGINAL5-FD-GATE-REVIEW.json'),'raw_values_match_distinct_summary':True,'observation_sorted_compact_no_LF_hash':sha(canonical(parsed['observation.json'])),'actual_object_rows':len(objects),'cleanup_authorized':False,'root_actions':0,'signal_zero_only':True},indent=2,sort_keys=True)+'\n')
(r/'actual-original-five-parsed.json').write_text(json.dumps(parsed,indent=2,sort_keys=True)+'\n')
