from pathlib import Path
import os,stat,json,hashlib,tarfile,io,collections,time
r=Path(__file__).parent;b=Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/remaining-only-late-binding-1/terminal-handoff-preparation-1');d=b/'actual-root-cleanup-correction-1';sha=lambda x:hashlib.sha256(x).hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes())}
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def stream(v):
 p=Path(v['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  before=os.fstat(fd);assert stat.S_ISREG(before.st_mode) and ident(before)==v['metadata'] and before.st_uid==1000 and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600 and before.st_size<134217728
  with os.fdopen(os.dup(fd),'rb') as f:raw=f.read(before.st_size+1)
  assert ident(before)==ident(os.fstat(fd))==ident(os.stat(p,follow_symlinks=False));assert len(raw)==before.st_size and sha(raw)==v['sha256'];return raw
 finally:os.close(fd)
releasep=r/'physical-cleanup-correction-1-release.json';release=json.loads(releasep.read_bytes());release_sha=sha(releasep.read_bytes());assert release_sha=='404f02d3a3c33b7964c1e6fee1fed1e70c41ea0472a40de7f7a175ce5ce0ed74'
policyfile=b/'cleanup-and-postjoin-LAYOUT-CORRECTION-DATA.json';policy=ref(policyfile);ops=json.loads(policyfile.read_bytes());results=[];bytes_by_role={};groups=[]
for i,label in enumerate(['cleanup','postjoin-readback']):
 p=d/(label+'.status.json');s=json.loads(p.read_bytes());assert s['returncode']==0 and s['direct_child_joined'] is True and s['observer_error'] is None
 expected=[release_sha if x=='BIND_EXACT_INDEPENDENT_CLEANUP_RELEASE_SHA256' else x for x in ops['exact_operations'][i]['argv']];assert s['argv']==expected
 command=json.loads(Path(str(p)+'.command.json').read_bytes());child=json.loads(Path(str(p)+'.child.json').read_bytes());assert command['argv']==s['argv']==child['argv'] and command['policy']==policy and child['pid']==s['pid']==child['pgid'] and str(child['start'])==str(s['start']) and int(s['start'])>0
 try:os.killpg(child['pgid'],0)
 except ProcessLookupError:groups.append({'pgid':child['pgid'],'result':'ESRCH'})
 else:raise AssertionError('criticalgroupnotretired')
 out=stream(s['streams']['stdout']);err=stream(s['streams']['stderr']);bytes_by_role[label]=(out,err)
 if label=='cleanup':assert err==b''
 results.append({'role':label,'status':ref(p),'command':ref(Path(str(p)+'.command.json')),'child':ref(Path(str(p)+'.child.json')),'pid':s['pid'],'start':s['start'],'elapsed_seconds':s['elapsed_seconds'],'streams':s['streams']})
assert results[0]['pid']!=results[1]['pid'];result=json.loads(bytes_by_role['cleanup'][0]);assert result==json.loads((b/'actual-cleanup-correction-1-result.json').read_bytes())
assert result['status']=='PASS_EXECUTED' and result['terminal'] is True and result['container_absent'] is True and result['container_id']=='66a9804b7f655f4251d31692f28b8b323eaef3895e4202e79e4deba7da7a99b6' and result['release_sha256']==release_sha
assert result['boot_id']=='7bfc5687-6c04-4d15-84eb-b92ab9a55dcb' and result['filesystem_uuid']=='2a5768c8-718d-4914-bdc0-6b32c5a92a52'
post=json.loads(bytes_by_role['postjoin-readback'][1]);assert post['status']=='PASS_CLEANUP_POSTJOIN_READBACK_ONLY' and post['members']==5 and post['application_acceptance'] is False
old=json.loads((r/'actual-original-five-parsed.json').read_bytes());expect42={x['path']:x for x in old['new-object-metadata.json']['objects']};actual42={x['path']:x for x in post['actual_object_rows']};assert len(expect42)==len(actual42)==42 and expect42==actual42
metadata=[result['plan'],result['journal'],result['capture'],*result['archives']];assert len(metadata)==5;expected_names=[Path(x['path']).name for x in metadata];memberrows=[];parts={}
with tarfile.open(fileobj=io.BytesIO(bytes_by_role['postjoin-readback'][0]),mode='r:') as tar:
 members=tar.getmembers();assert [m.name for m in members]==expected_names
 for m,v in zip(members,metadata):
  assert m.isreg() and not m.linkname and not m.pax_headers and m.size==v['size'] and m.uid==v['uid'] and m.gid==v['gid'] and m.mode==(int(v['mode'],8) if isinstance(v['mode'],str) else v['mode']);raw=tar.extractfile(m).read(m.size+1);assert len(raw)==m.size and sha(raw)==v['sha256'];parts[m.name]=raw;memberrows.append({'name':m.name,'size':m.size,'sha256':sha(raw)})
plan=json.loads(parts[expected_names[0]]);canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode();assert sha(canonical(plan))==result['plan_sha256'];assert plan['release_sha256']==release_sha and plan['filesystem_uuid']==result['filesystem_uuid'] and plan['publisher_contract']==result['publisher_contract']==release['publisher_contract']
assert collections.Counter(sha(parts[x['name']]) for x in memberrows[-2:])==collections.Counter(x['sha256'] for x in release['observation']['retained_exclusions'])
assert all(not os.path.lexists(x['path']) for x in release['observation']['retained_exclusions']);assert not os.path.lexists(release['transaction_paths'][4])
whole=json.loads((d/'wholejoin.json').read_bytes());assert whole['status']=='PASS_TWO_DIRECT_JOINS_ONLY' and whole['physical_acceptance'] is False
report={'schema':'mckernel.independent-remaining-terminal.actual-physical-release-acceptance.v1','status':'PASS_ACTUAL_CORRECTED_CLEANUP_AND_POSTJOIN_PHYSICAL_RELEASE','reviewer':'clone_thread_affinity_rust_repair','implementation_ownership':False,'reviewed_unix':int(time.time()),'physical_release':True,'cleanup_accepted':True,'container_absent':True,'container_id':result['container_id'],'boot_id':result['boot_id'],'filesystem_uuid':result['filesystem_uuid'],'exact_corrected_release':ref(releasep),'corrected_execution_review':ref(r/'CORRECTED-CLEANUP-EXECUTION-REVIEW.json'),'completed_records':results,'all_direct_children_joined':True,'all_groups_ESRCH':groups,'cleanup_terminal_result':ref(b/'actual-cleanup-correction-1-result.json'),'postjoin_archive':{'stream':results[1]['streams']['stdout'],'bytes':len(bytes_by_role['postjoin-readback'][0]),'members':memberrows},'actual42_postjoin_fd_rows_exactly_equal_precleanup':True,'both_original_coordination_records_archived_byte_exact_and_absent':True,'quarantine_absent':True,'plan_canonical_sha256':result['plan_sha256'],'plan_release_and_publisher_contract_match':True,'accepted_intentional_postjoin_stderr':True,'old_source_05076_pre_effect_refusal_preserved':ref(r/'PRE-EFFECT-CLEANUP-REFUSAL-REVIEW.json'),'corrected_source_delta_and_explicit_old_observation_reuse':ref(r/'CORRECTED-LAYOUT-SOURCE-AND-OBSERVATION-REUSE-REVIEW.json'),'original_raw5_review':ref(r/'ACTUAL-RAW5-ARCHIVE-REVIEW.json'),'scope':'Exact retired remaining-build container and two journaled coordination records; all42 artifacts/source/seeds/oldfailure evidence preserved. This unblocks next eligible work, not application/native or full OS acceptance.','application_acceptance':False,'new_guest_apps':0,'new_current_candidate_builds':0,'reviewer_root_runtime_actions':0,'signal_zero_checks_only':True,'first_invocation_failure_history':'Original7f20 release/direct1 refused reviewed-container-profile before effects; preserved. One authenticated e728 layout correction,16focusedchecks,explicitreuse+newpub19b and404f release thendirect0cleanup/postjoin. No reobservation/export replay.'}
p=r/'PHYSICAL-RELEASE-ACCEPTANCE.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');(r/'physical-acceptance-sha.txt').write_text(sha(p.read_bytes())+'\n')
