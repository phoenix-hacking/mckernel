import argparse,fcntl,hashlib,json,os,stat,time,types
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--release',required=True);p.add_argument('--sha256',required=True);args=p.parse_args()
B=Path(__file__).resolve().parent
policy=B/'first-four-readonly-capture-bindings-PUBLISHED-DATA.json'
assert hashlib.sha256(policy.read_bytes()).hexdigest()=='b7a11000a9546a1c13b954c71233f17ee7ad5600ac3e8ec3acf096954b36977c'
release=Path(args.release);raw=release.read_bytes();assert hashlib.sha256(raw).hexdigest()==args.sha256
rd=json.loads(raw);assert rd['status']=='PASS_EXECUTION_RELEASE' and rd['cleanup_authorized'] is False
ops=json.loads(policy.read_bytes())['operations'];op=ops[0];assert op['role']=='observer'
source=B/'root-case-capture-primitive-1.py';assert hashlib.sha256(source.read_bytes()).hexdigest()=='a1bc2d9d7506deea0d151a2e6bea9321e0edb66a385523d27f5f4928d0f4e063'
m=types.ModuleType('_case_capture');m.__file__=str(source);exec(compile(source.read_bytes(),str(source),'exec'),m.__dict__)
m.a=types.SimpleNamespace(policy=str(policy));m.results=[]
os.umask(0o077);os.sched_setaffinity(0,{6});assert os.getuid()==1000
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7bfc5687-6c04-4d15-84eb-b92ab9a55dcb'
state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_bytes());assert state.get('stop_reason') is None and state['last_rate_limits']['primary']['usedPercent']<97
capacity={}
for path,floor in [('/home/holden',17179869184),('/home/holden/mckernel-work/scratch',12884901888)]:
 v=os.statvfs(path);free=v.f_bavail*v.f_frsize;assert free>=floor+671088640
 capacity[path]=dict(available_bytes=free,required_bytes=floor+671088640)
fd=os.open('/run/lock/mckernel-development.lock',os.O_RDONLY|os.O_NOFOLLOW)
try:
 st=os.fstat(fd);assert (st.st_dev,st.st_ino)==(27,4);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(fd,fcntl.LOCK_UN)
finally:os.close(fd)
root=Path(op['status_path']).parent;root.mkdir(mode=0o700)
m.write(root/'outer-admission.json',dict(timestamp=time.time(),capacity=capacity,used_percent=state['last_rate_limits']['primary']['usedPercent'],boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),pid=os.getpid(),start=m.start(os.getpid()),source=m.ref(source),release=m.ref(release)))
dest=Path(op['argv'][op['argv'].index('--observation-release')+1]);assert not dest.exists();m.put(dest,raw)
assert op['argv'][-1]=='BIND_EXACT_INDEPENDENT_OBSERVER_RELEASE_SHA256';op['argv'][-1]=args.sha256
row=m.run(op)
print(json.dumps(dict(role=row['role'],returncode=row['returncode'],direct_child_joined=row['direct_child_joined'],elapsed_seconds=row['elapsed_seconds'],status_path=op['status_path'])))
