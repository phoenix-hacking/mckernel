/work/native-sysfs-service-module-20260908-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.o
