/work/native-sysfs-objects-module-20260907-5/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o
