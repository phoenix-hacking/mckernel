#!/usr/bin/env python3
"""Retain source-review bytes only; never import or execute reviewed helpers."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tarfile

ROOT = Path('/home/holden/mckernel')
CAPTURE = Path('/tmp/stability-owner-v2-integration-publication-20260913-1')
NAME = 'stability-owner-phase-v2-integration-review-20260913'
TREES = [
    Path('/tmp/stability-owner-phase-v2-independent-review-20260913-zkpc9um8'),
    Path('/tmp/stability-owner-v2-wiring-review-20260913-8jefwpo7'),
]
EXPECTED = {
    'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/controller.c':
    '7b1115f4c744d32bb085f23b515e35bcfab4cf0efa6f2e3cb5827742876511e2',
    'scripts/tests/prepare_stability_fault_guest.py':
    '6b7135c77f1c9bc5f82c5de3626aad1f86b72e5b72b9d803e99f32bc615ad67f',
    'scripts/tests/run_stability_transport_guest.py':
    '3215065d832d18638bd3901c530d5a6bdd89569b6643ea6cd6c0162a804a0d7d',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=sha(data))


def dump(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write('\n')


def tree(path):
    result = []
    for item in [path] + sorted(path.rglob('*')):
        st = item.lstat()
        row = dict(path=str(item.relative_to(path.parent)), mode=stat.S_IMODE(st.st_mode))
        if stat.S_ISDIR(st.st_mode):
            row['type'] = 'directory'
        else:
            assert stat.S_ISREG(st.st_mode), str(item)
            row.update(type='file', size=st.st_size, sha256=sha(item.read_bytes()))
        result.append(row)
    return result


def diff(before, after, old, new):
    return ''.join(difflib.unified_diff(before.decode().splitlines(True),
                   after.decode().splitlines(True), fromfile=old, tofile=new)).encode()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


CAPTURE.mkdir()
shutil.copy2(__file__, CAPTURE / 'retention.py')
before_trees = [tree(p) for p in TREES]
for p in TREES:
    shutil.copytree(p, CAPTURE / p.name)

controller_review = json.loads((TREES[0] / 'review.json').read_bytes())
wiring_review = json.loads((TREES[1] / 'review.json').read_bytes())
verified = []
for base, review in zip(TREES, [controller_review, wiring_review]):
    for row in review['reviewed_inputs']:
        relative = row.get('retained', row['path'])
        retained = base / 'source' / relative
        info = identity(retained)
        assert info['size'] == row['size'] and info['sha256'] == row['sha256'], info
        verified.append(dict(declared=row, retained=info))

current = []
for relative, expected in EXPECTED.items():
    info = identity(ROOT / relative)
    assert info['sha256'] == expected, info
    matches = [v for v in verified if v['retained']['sha256'] == expected]
    assert len(matches) == 1
    assert (ROOT / relative).read_bytes() == Path(matches[0]['retained']['path']).read_bytes()
    destination = CAPTURE / 'current' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / relative, destination)
    current.append(info)

v2 = TREES[0] / 'source/scripts/tests/fixtures/stability-transport-fault/owner-phase-v2'
v1 = ROOT / 'scripts/tests/fixtures/stability-transport-fault/owner-phase-v1'
original = (v2 / 'controller.original.c').read_bytes()
final = (v2 / 'controller.c').read_bytes()
assert original == (v1 / 'controller.c').read_bytes()
assert (v2 / 'phase_client.h').read_bytes() == (v1 / 'phase_client.h').read_bytes()
for name in ('controller.c', 'phase_client.h'):
    destination = CAPTURE / 'current-v1' / name
    destination.parent.mkdir(exist_ok=True)
    shutil.copy2(v1 / name, destination)
assert (v2 / 'controller.forward.patch').read_bytes() == diff(original, final, 'controller.original.c', 'controller.c')
assert (v2 / 'controller.inverse.patch').read_bytes() == diff(final, original, 'controller.c', 'controller.original.c')
reconstructed = (TREES[0] / 'controller.reviewed1059.reconstructed.c').read_bytes()
assert sha(reconstructed) == '1059db6e3bc721332feea0a030a0b76fb700a1f52cc625bfbfa6e0787af485b1'
assert (TREES[0] / 'diagnostic-delta.diff').read_bytes() == diff(reconstructed, final, 'reviewed1059', 'final7b1115')

wiring = bytearray()
prior_versions = []
for relative in list(EXPECTED)[1:]:
    old = TREES[1] / 'checkpoint-original' / relative
    new = TREES[1] / 'source' / relative
    a, b = old.read_bytes(), new.read_bytes()
    wiring.extend(('diff --git a/{0} b/{0}\nindex {1}..{2} 100644\n'.format(
        relative, git_blob(a)[:8], git_blob(b)[:8])).encode())
    wiring.extend(diff(a, b, 'a/' + relative, 'b/' + relative))
    prior_versions.append(identity(old))
assert bytes(wiring) == (TREES[1] / 'wiring.diff').read_bytes()
build_record = identity(TREES[1] / 'controller-build-record.json')
assert build_record['sha256'] == wiring_review['controller_build_record']['sha256']

doc = ROOT / 'docs/verification' / (NAME + '.md')
shutil.copy2(doc, CAPTURE / doc.name)
checkpoint = ROOT / 'docs/verification/stability-terminal-integration-20260913-1.json'
shutil.copy2(checkpoint, CAPTURE / checkpoint.name)
published = json.loads(checkpoint.read_bytes())
harness = [r for r in published['captures'] if '/stability-terminal-boundary-tests-20260913-1' in r['source']]
assert len(harness) == 1 and harness[0]['status'] == 'PASS'
checks = dict(
    status='SOURCE_IDENTITIES_AND_DIFFS_MATCH', reviewed_inputs=verified,
    final_current_sources=current, prior_checkpoint_versions=prior_versions,
    current_v1=[identity(v1 / p) for p in ('controller.c', 'phase_client.h')],
    exact_v1_preserved=True, exact_header_preserved=True,
    forward_inverse_diffs_match=True, diagnostic_reconstruction_diff_matches=True,
    wiring_diff_matches_original_and_final_bytes=True,
    checkpoint_membership_independently_verified=False,
    reconstruction_identity=identity(TREES[0] / 'controller.reviewed1059.reconstructed.c'),
    reconstruction_is_original_copied_file=False,
    original_capture_failure=controller_review['initial_retention_attempt'],
    retained_build_record=build_record,
    build_binary_independently_revalidated=False,
    separate_root_checkpoint=identity(checkpoint),
    root_reported_harness_capture=harness[0],
    tests_executed_by_this_lane=False, guest_execution=False,
    application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
)
dump(CAPTURE / 'source-identity-verification.json', checks)
for p, expected in zip(TREES, before_trees):
    assert tree(p) == expected
    assert tree(CAPTURE / p.name) == expected
members = tree(CAPTURE)
archive = ROOT / 'docs/verification/evidence' / (NAME + '.tar.gz')
assert not archive.exists()
with tarfile.open(str(archive), 'x:gz', format=tarfile.PAX_FORMAT) as tf:
    tf.add(str(CAPTURE), arcname=CAPTURE.name)
observed = []
with tarfile.open(str(archive), 'r:gz') as tf:
    for member in tf.getmembers():
        row = dict(path=member.name, mode=member.mode)
        if member.isdir():
            row['type'] = 'directory'
        else:
            assert member.isfile()
            data = tf.extractfile(member).read()
            row.update(type='file', size=len(data), sha256=sha(data))
        observed.append(row)
assert sorted(observed, key=lambda x: x['path']) == sorted(members, key=lambda x: x['path'])
assert tree(CAPTURE) == members
record = dict(schema_version=1, status='PASS_SOURCE_REVIEW_AND_RETENTION_ONLY',
    record_kind='owner_phase_v2_integration_source_review',
    document=identity(doc), source_capture=str(CAPTURE), source_checks=checks,
    original_review_trees=[dict(path=str(p), complete_tree=True,
       review=identity(p / 'review.json'), members=rows) for p, rows in zip(TREES, before_trees)],
    archive=identity(archive), archive_member_count=len(members),
    archive_members=members, complete_archive_byte_and_mode_comparison=True,
    no_source_helpers_imported_or_executed=True,
    scope='Source review and evidence retention; separately linked root harness PASS is infrastructure only.',
    tests_executed_by_this_lane=False, builds_executed_by_this_lane=False,
    guest_execution=False, application_acceptance=False,
    transport_acceptance=False, production_gate_credit=False)
out = ROOT / 'docs/verification' / (NAME + '.json')
dump(out, record)
print(json.dumps(dict(record=identity(out), document=identity(doc), archive=identity(archive),
                     members=len(members), capture=str(CAPTURE)), indent=2))
