from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-trampoline-region-retained-20260907-1'
out.mkdir()

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            result.update(data)
    return result.hexdigest()

record = dict(created_utc=datetime.now(timezone.utc).isoformat(), artifacts=[], captures=[],
              production_gate_credit=False, mckernel_boot_proven=False,
              passed=['Exact pinned E820/resource/mapping API witness and native Rust module ELF/no-SIMD checks',
                      'Invalid geometry rejection before memory effects',
                      'Normal-map and ordinary reserved-map rejection, with zero writes, across two module lifetimes each',
                      'Explicit memmap carve-out: 128 repeated exclusive mapped leases, overlapping-lease rejection and complete 4096-byte pattern readbacks',
                      'Claim-only cleanup, final retained mapping through init, and actual unmap/release before both unload markers',
                      'All four Linux CPUs remain online in each isolated two-NUMA guest'],
              limitations=['This memory-region fixture does not execute the trampoline or start any McKernel CPU',
                           'Native SMP integration must attach the owner to the exact OS generation, CPU and IRQ lifetimes',
                           'Boot parameters, preserved assembly, INIT/SIPI, readiness, IKC, applications and complete Rust/assembly ownership remain open',
                           'The carved page is tested only in isolated QEMU; firmware/hardware acceptance is not established',
                           'Earlier intermittent Linux idle/RCU stall remains unresolved',
                           'The 2315-test full-suite record covers the preceding transport checkpoint, before this new fixture'])

def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''):
                stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name, source=str(path),
        size=target.stat().st_size, sha256=digest(target), unpacked_size=path.stat().st_size,
        unpacked_sha256=digest(path)))

directories = ['native-trampoline-region-module-20260907-1'] + [
    'native-trampoline-region-guest-20260907-' + mode + '-1' for mode in ('normal', 'reserved', 'hole')
] + ['native-trampoline-region-validation-20260907-1']
for name in directories:
    path = work / name
    metadata = json.loads((path / 'record.json').read_text())
    assert metadata.get('status', metadata.get('exit_code')) in ('PASS', 0), name
    for row in metadata.get('inputs', []) + metadata.get('outputs', []):
        item = Path(row['path'])
        assert item.stat().st_size == row['size'] and digest(item) == row['sha256'], item
    record['captures'].append(dict(directory=name, status=metadata.get('status', metadata.get('exit_code')),
        source_parent=metadata.get('source_parent'), started_utc=metadata['started_utc'],
        finished_utc=metadata.get('finished_utc', metadata.get('updated_utc'))))
    target = out / (name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        archive.add(path, arcname=name)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
        source=str(path), size=target.stat().st_size, sha256=digest(target)))
    add(path / 'record.json', name + '-record.json.gz')
    if (path / 'serial.log').exists():
        add(path / 'serial.log', name + '-serial.log.gz')

for name in ('build-native-trampoline-region-module.py', 'run-native-trampoline-region-guest.py',
             'run-native-trampoline-region-validation.py', 'retain-native-trampoline-region.py'):
    add(work / name, 'native-trampoline-region-20260907-' + name + '.gz')
for relative in ('scripts/tests/fixtures/mckernel_trampoline_region_verify.rs',
                 'scripts/tests/fixtures/mckernel_trampoline_region_layout.c',
                 'scripts/native-trampoline-region-init.sh',
                 'docs/verification/native-trampoline-region-plan.md'):
    path = repo / relative
    record.setdefault('source_inputs', []).append(dict(path=relative,
        size=path.stat().st_size, sha256=digest(path)))
reference = repo / 'docs/verification/native-irq-transport-final-validation-20260907.json'
record['kernel_build_reference'] = dict(path=str(reference.relative_to(repo)),
    size=reference.stat().st_size, sha256=digest(reference))
for row in record['artifacts']:
    unpacked, size = hashlib.sha256(), 0
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            unpacked.update(data)
            size += len(data)
    if 'unpacked_sha256' in row:
        assert size == row['unpacked_size'] and unpacked.hexdigest() == row['unpacked_sha256']
(out / 'native-trampoline-region-checkpoint-20260907.json').write_text(
    json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained and verified', len(record['artifacts']), 'trampoline-region artifacts', flush=True)
