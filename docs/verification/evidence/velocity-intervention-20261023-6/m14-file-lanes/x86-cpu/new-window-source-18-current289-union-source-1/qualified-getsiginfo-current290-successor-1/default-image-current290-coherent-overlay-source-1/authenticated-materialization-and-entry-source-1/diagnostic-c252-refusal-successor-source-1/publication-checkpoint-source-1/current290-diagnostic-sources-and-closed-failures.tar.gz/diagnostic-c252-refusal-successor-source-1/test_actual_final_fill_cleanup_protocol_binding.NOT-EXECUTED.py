"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual final fill/caller/cleanup/protocol source-data integration only.
No configure, Transaction, observer, owner, live query, root, Git mutation or cleanup.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,stat,unittest
P=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/default-image-current290-coherent-overlay-source-1/authenticated-materialization-and-entry-source-1/diagnostic-c252-refusal-successor-source-1')
READY=P/'cleanup-successor-source-1/READY-CLEANUP-SUCCESSOR.SOURCE-ONLY.json'
READY_SHA='0433f04c84d4ad2f5a55cedc13ab4b7eb7b982d33a942e9978664f5da5cb9bc0'
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for raw in iter(lambda:f.read(1<<20),b''):h.update(raw)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=p.stat().st_size)
def module(row,name):
 assert ref(row['path'])==row;spec=importlib.util.spec_from_file_location(name,row['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def selected(row):
 p=Path(row['path']);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and ref(p)==row
 return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=oct(stat.S_IMODE(s.st_mode)),uid=s.st_uid,gid=s.st_gid,size=s.st_size,nlink=s.st_nlink,sha256=row['sha256'])
assert ref(READY)['sha256']==READY_SHA
r=json.loads(READY.read_bytes());f=module(r['fill'],'actual_final_diagnostic_fill');caller=module(r['caller'],'actual_final_diagnostic_caller');cleanup=module(r['cleanup'],'actual_final_diagnostic_cleanup');protocol=cleanup.current230_contract();c=protocol.contract();cfg=json.loads(Path(r['config']['path']).read_bytes());proof=json.loads(Path(r['origin_proof']['path']).read_bytes())
class BindingTests(unittest.TestCase):
 def test_1_actual_final_fill_genuine_original69(self):
  actual,rows=f.fetched(Path(r['origin_proof']['path']),r['origin_proof']['sha256']);self.assertEqual(actual,proof);self.assertEqual(len(rows),69);self.assertEqual(f.FETCHED_ORIGIN_MEMBERS,proof['members'])
 def test_2_actual_cleanup_protocol_exact_final_static_refs(self):
  self.assertEqual(cleanup.CURRENT230_TYPED_PROTOCOL,r['protocol']);self.assertEqual(ref(protocol.CONTRACT),r['contract']);self.assertEqual(protocol.CONTRACT_SHA,r['contract']['sha256'])
  for key,expected in [('caller',r['caller']),('caller_base_config',r['config']),('metadata_fill',r['fill']),('observer',r['census_observer'])]:self.assertEqual(c['static'][key],expected)
  self.assertEqual(c['caller_capture_root'],r['runtime_capture_root']);self.assertEqual(str(cleanup.CURRENT230_CALLER_CAPTURE),r['runtime_capture_root']);self.assertEqual(cleanup.CURRENT230_OWNER_ARGV,c['owner_argv'])
  self.assertEqual(cleanup.PUBLISHED_SCRIPT,str(Path(r['cleanup']['path']).relative_to('/home/holden/mckernel')));self.assertFalse(os.path.lexists(r['runtime_capture_root']))
 def test_3_actual_caller_config_source_data_and_namespace(self):
  self.assertEqual(caller.actual_config(Path(r['config']['path']),r['config']['sha256']),cfg);self.assertEqual(cfg['fill'],r['fill']);self.assertEqual(cfg['pins']['request'],c['static']['request']);self.assertEqual(cfg['publication'],r['origin_proof'])
  s=c['source_identity'];n=c['namespace'][0];obs=dict(candidate_root=dict(path=s['path'],device=s['dev'],inode=s['inode'],mode=oct(s['mode']),uid=s['uid'],gid=s['gid']),namespace_binding=dict(device=n['device'],inode=n['inode'],mode=stat.S_IFDIR|n['mode'],uid=n['uid'],gid=n['gid']));protocol._source_identity(c,obs)
 def test_4_actual_cleanup_wrong_protocol_source_hash_refused(self):
  old=cleanup.CURRENT230_TYPED_PROTOCOL
  try:
   cleanup.CURRENT230_TYPED_PROTOCOL=dict(old,sha256='0'*64)
   with self.assertRaises(cleanup.Refusal):cleanup.current230_contract()
  finally:cleanup.CURRENT230_TYPED_PROTOCOL=old
 def test_5_actual_protocol_wrong_contract_hash_refused(self):
  old=protocol.CONTRACT_SHA
  try:
   protocol.CONTRACT_SHA='0'*64
   with self.assertRaises(RuntimeError):protocol.contract()
  finally:protocol.CONTRACT_SHA=old
 def test_6_actual_selected_wrong_origin_path_refused(self):
  old=c['private_static_origin_map']['metadata_fill']['published_origin'];wanted=c['static']['metadata_fill'];selection={wanted['path']:selected(old)}
  with self.assertRaises(RuntimeError):protocol.selected_bytes(wanted['path'],selection,wanted)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BindingTests));print(json.dumps(dict(scope=__doc__.splitlines()[0],status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),actual_fill_cleanup_protocol_imports=True,configure_Transaction_owner_livequery_root_cleanup_called=False,runtime_capture_absent=not os.path.lexists(r['runtime_capture_root'])),sort_keys=True));raise SystemExit(0 if result.wasSuccessful() else 1)
