"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual production fill.fetched regression with genuine immutable69 proof; no mocks,
live query, owner, lock, census, root, Git mutation or cleanup.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,unittest
P=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/default-image-current290-coherent-overlay-source-1/authenticated-materialization-and-entry-source-1/diagnostic-c252-refusal-successor-source-1')
READY=P/'READY-C252-FRESH-DIAGNOSTIC-EXACT-ORIGIN69-CORRECTION.NOT-EXECUTION.json'
READY_SHA='1b5668b72488ef42c2597e90f06bc154adc351f14f22ca698744b395e664e738'
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for raw in iter(lambda:f.read(1<<20),b''):h.update(raw)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=p.stat().st_size)
assert ref(READY)['sha256']==READY_SHA
r=json.loads(READY.read_bytes());assert ref(r['fill']['path'])==r['fill'];spec=importlib.util.spec_from_file_location('actual_production_fresh_fill',r['fill']['path']);f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);proof=json.loads(Path(r['origin_proof']['path']).read_bytes());cfg=json.loads(Path(r['config']['path']).read_bytes());before=[os.path.lexists(path) for path in r['unused_runtime_paths_remain_absent']];assert before==[False]*len(before)
class ActualOriginTests(unittest.TestCase):
 def test_1_real_production_fetched_genuine69(self):
  actual,rows=f.fetched(Path(r['origin_proof']['path']),r['origin_proof']['sha256']);self.assertEqual(actual,proof);self.assertEqual(len(rows),69);self.assertEqual(f.FETCHED_ORIGIN_MEMBERS,proof['members']);self.assertEqual(cfg['fill'],r['fill'])
  for key in ['fill','config','caller','census_observer']:self.assertEqual(ref(r[key]['path']),r[key])
  self.assertEqual([os.path.lexists(path) for path in r['unused_runtime_paths_remain_absent']],before)
 def test_2_equal_hash_wrong_compact_origin_refused(self):
  bad=copy.deepcopy(proof);row=bad['members'][49];row['source']['path']=row['source']['path'].replace('COMPACT-C252-CENSUS-REQUEST.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.json','COMPACT-C252-CENSUS-REQUEST.FRESH-DIAGNOSTIC.TEMPLATE.NOT-GRANTED.json');row['repository']=row['repository'].replace('COMPACT-C252-CENSUS-REQUEST.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.json','COMPACT-C252-CENSUS-REQUEST.FRESH-DIAGNOSTIC.TEMPLATE.NOT-GRANTED.json');self.assertEqual(row['sha256'],proof['members'][49]['sha256'])
  with self.assertRaisesRegex(RuntimeError,'all69 exact published-origin members'):f.origin69_rows(bad)
 def test_3_equal_hash_wrong_payload_origin_refused(self):
  bad=copy.deepcopy(proof);row=bad['members'][50];row['source']['path']=row['source']['path'].replace('ROOT-CURRENT290-IMAGE-ONLY-PAYLOAD.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.json','ROOT-CURRENT290-IMAGE-ONLY-PAYLOAD.FRESH-DIAGNOSTIC.TEMPLATE.NOT-GRANTED.json');row['repository']=row['repository'].replace('ROOT-CURRENT290-IMAGE-ONLY-PAYLOAD.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.json','ROOT-CURRENT290-IMAGE-ONLY-PAYLOAD.FRESH-DIAGNOSTIC.TEMPLATE.NOT-GRANTED.json');self.assertEqual(row['sha256'],proof['members'][50]['sha256'])
  with self.assertRaisesRegex(RuntimeError,'all69 exact published-origin members'):f.origin69_rows(bad)
 def test_4_missing_origin_member_refused(self):
  bad=copy.deepcopy(proof);bad['members'].pop()
  with self.assertRaises(RuntimeError):f.origin69_rows(bad)
 def test_5_wrong_genuine_proof_hash_refused(self):
  with self.assertRaisesRegex(RuntimeError,'exact root actual69 fetched-proof bytes'):f.fetched(Path(r['origin_proof']['path']),'0'*64)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ActualOriginTests));print(json.dumps(dict(scope=__doc__.splitlines()[0],status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),real_fill_fetched_called=True,immutable_proof_sha256=r['origin_proof']['sha256'],all69_literal_equals_genuine_proof=f.FETCHED_ORIGIN_MEMBERS==proof['members'],runtime_capture_paths_still_absent=[os.path.lexists(path) for path in r['unused_runtime_paths_remain_absent']]==before,no_live_query_owner_lock_census_root_cleanup=True),sort_keys=True));raise SystemExit(0 if result.wasSuccessful() else 1)
