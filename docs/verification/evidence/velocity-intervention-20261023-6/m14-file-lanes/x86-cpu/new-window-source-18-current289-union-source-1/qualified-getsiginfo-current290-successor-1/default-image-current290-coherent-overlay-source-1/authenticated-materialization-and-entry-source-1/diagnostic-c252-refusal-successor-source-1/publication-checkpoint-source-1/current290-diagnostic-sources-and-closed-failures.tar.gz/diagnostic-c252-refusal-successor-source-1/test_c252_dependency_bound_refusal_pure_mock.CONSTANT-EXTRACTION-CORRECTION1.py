"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure/mock census refusal regressions. Only owned tempfile JSON/FDs are touched;
all live process/container/lease/resource observers are replaced by test doubles.
"""
from pathlib import Path
import ast,copy,contextlib,hashlib,io,json,os,tempfile,types,unittest
from unittest import mock
P=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/default-image-current290-coherent-overlay-source-1/authenticated-materialization-and-entry-source-1/diagnostic-c252-refusal-successor-source-1')
READY=P/'READY-C252-DEPENDENCY-BOUND-DIAGNOSTIC.NOT-EXECUTION.json'
READY_SHA='9388bf28b61f75197e7df2089e12acd5593bfbeaad83affaa62037876083f803'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(READY)==READY_SHA
ready=json.loads(READY.read_bytes());source=Path(ready['diagnostic_census']['path']);baseline=Path(ready['baseline']['path']);assert digest(source)==ready['diagnostic_census']['sha256'] and digest(baseline)==ready['baseline']['sha256']
FUNCTIONS={'_request_hash','_strict_json','_aggregate_argument','_dispatcher_reconcile','_validate_census_domains','census_request','_encode_census_report','_bounded_census_refusal','_historical_lease_observation','_stable_file_bytes','main'}
ASSIGNMENTS={'LAUNCHER_AGGREGATE_GIB','LAUNCHER_AGGREGATE_BYTES','EXPECTED_LIMITS','OPERATIONAL_EXCLUSION_PATH','MAX_REPORT_BYTES','MAX_HEAVY_ROWS','MAX_PROC_ENTRIES','MAX_ARG_BYTES','DISPATCHER_EMERGENCY_BYTES','HISTORICAL_OBSERVER_SHA256','PYTHON_SCRIPT_PARSER_SOURCE','PRIVILEGED_PROCESS_OBSERVER_SOURCE','PRIVILEGED_PROCESS_OBSERVER_SHA256','RETRY2_RELEASE_PATH'}
def load(path):
 ns={'__file__':str(path),'__name__':'pure_census_fixture'};body=[]
 for n in ast.parse(path.read_bytes(),str(path)).body:
  if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in FUNCTIONS or isinstance(n,ast.ClassDef) and n.name=='AdmissionError' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ASSIGNMENTS for t in n.targets):body.append(n)
 exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),ns)
 def forbidden(*args,**kwargs):raise AssertionError('live observer forbidden in pure fixture')
 for name in ['_dispatcher_processes','_dispatcher_containers','_dispatcher_leases','_dispatcher_resources','validate_request','run_request']:ns[name]=forbidden
 return ns
BOOT='11111111-2222-3333-4444-555555555555'
class RefusalTests(unittest.TestCase):
 def setUp(self):
  self.m=load(source);self.temp=tempfile.TemporaryDirectory(prefix='c252-pure-');self.addCleanup(self.temp.cleanup);self.request=Path(self.temp.name)/'request.json';self.request.write_text(json.dumps(dict(operational_exclusion_path=self.m['OPERATIONAL_EXCLUSION_PATH'],host_floor=0,scratch_floor=0)))
 def domains(self):return dict(processes=[],containers=[],leases=[],resources=dict(host_free=100<<30,scratch_free=100<<30,memory_available=100<<30,cpus=[2,3,4,5]))
 def main(self,callback=None,checksum=None):
  ns=self.m
  if callback is not None:ns['_dispatcher_reconcile']=callback
  original=Path.read_text
  def text(path,*args,**kwargs):return BOOT if str(path)=='/proc/sys/kernel/random/boot_id' else original(path,*args,**kwargs)
  out=io.StringIO()
  with mock.patch.object(Path,'read_text',text),contextlib.redirect_stdout(out):rc=ns['main']([str(self.request),'--census-only','--request-sha256',checksum or digest(self.request)])
  self.assertLessEqual(len(out.getvalue().encode()),4096);return rc,json.loads(out.getvalue())
 def assert_refused(self,rc,row,message):
  self.assertEqual(rc,1);self.assertEqual(row['status'],'REFUSED');self.assertEqual(row['diagnostic']['admission_error'],message);self.assertNotIn('resources',row);self.assertNotIn('execution_released',row)
 def test_01_all_original_admission_functions_exact(self):
  def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  old=functions(baseline);new=functions(source);self.assertEqual([k for k in old if old[k]!=new[k]],['main'])
 def test_02_live_process_refusal_stage_rc_preserved(self):
  ns=self.m;ns['_dispatcher_processes']=lambda:[dict(pid=123)]
  rc,row=self.main();self.assert_refused(rc,row,'live or unresolved heavy process present');self.assertIn('_dispatcher_reconcile',[f['function'] for cause in row['diagnostic']['causes'] for f in cause['stages']])
 def refused_component(self,name,message):
  ns=self.m;ns['_dispatcher_processes']=lambda:[];ns['_dispatcher_containers']=lambda:[];ns['_dispatcher_leases']=lambda request:[];ns['_dispatcher_resources']=lambda request:self.domains()['resources']
  def fail(*args):raise ns['AdmissionError'](message)
  ns[name]=fail;rc,row=self.main();self.assert_refused(rc,row,message)
 def test_03_container_refusal_preserved(self):self.refused_component('_dispatcher_containers','container census unavailable')
 def test_04_lease_refusal_preserved(self):self.refused_component('_dispatcher_leases','unknown lease identity')
 def test_05_resource_refusal_preserved(self):self.refused_component('_dispatcher_resources','required build CPUs unavailable')
 def test_06_actual_floor_predicate_still_refuses(self):
  d=self.domains();d['resources']['memory_available']=(12<<30)-1;rc,row=self.main(lambda request:d);self.assert_refused(rc,row,'recovery resource floors unavailable')
 def test_07_actual_domain_predicate_still_refuses(self):
  d=self.domains();d['processes']=[dict(pid=123)];rc,row=self.main(lambda request:d);self.assert_refused(rc,row,'recovery census is not idle or is malformed')
 def test_08_bad_request_hash_refuses_before_observer(self):
  rc,row=self.main(checksum='0'*64);self.assert_refused(rc,row,'census request binding changed')
 def test_09_mock_success_unchanged_rc0_shape(self):
  rc,row=self.main(lambda request:self.domains());self.assertEqual(rc,0);self.assertEqual(row['status'],'PASS_READ_ONLY');self.assertFalse(row['execution_released']);self.assertNotIn('diagnostic',row)
 def test_10_bounded_printable_admission_message(self):
  error=self.m['AdmissionError']('x'*10000+'\n\u2603');row=json.loads(self.m['_bounded_census_refusal'](error));self.assertEqual(len(row['diagnostic']['admission_error']),240);self.assertTrue(row['diagnostic']['bounded'])
 def test_11_nonadmission_cause_text_not_echoed(self):
  try:
   try:raise ValueError('UNRELATED_OBSERVER_BYTES_MUST_NOT_BE_ECHOED')
   except ValueError as cause:raise self.m['AdmissionError']('read-only recovery census unavailable') from cause
  except self.m['AdmissionError'] as error:raw=self.m['_bounded_census_refusal'](error)
  self.assertNotIn('UNRELATED_OBSERVER_BYTES',raw);self.assertIn('ValueError',raw);self.assertLessEqual(len(raw.encode())+1,4096)
 def test_12_original_domain_negative_vectors_match(self):
  old=load(baseline)
  for mutate in [lambda x:x.update(processes=[1]),lambda x:x.update(containers=[1]),lambda x:x.update(leases={}),lambda x:x['resources'].update(cpus=[7]),lambda x:x['resources'].update(memory_available=-1)]:
   a=self.domains();mutate(a);messages=[]
   for ns in [old,self.m]:
    with self.assertRaises(ns['AdmissionError']) as caught:ns['_validate_census_domains'](copy.deepcopy(a))
    messages.append(str(caught.exception))
   self.assertEqual(messages[0],messages[1])
 def embedded_caller(self,script):
  program=self.m['PRIVILEGED_PROCESS_OBSERVER_SOURCE'];nodes=ast.parse(program).body
  body=[n for n in nodes if isinstance(n,ast.FunctionDef) and n.name in ['python_script','caller'] or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in {'MAX_ARG_COUNT','MAX_ARG_BYTES','RETRY2_RELEASE_PATH'} for t in n.targets)]
  ns=dict(self.m);ns.update(os=types.SimpleNamespace(getppid=lambda:12345,readlink=lambda path:'/usr/bin/python3'),st=lambda pid:'76500000',cmdline=lambda pid:['/usr/bin/python3','-I','-B',script])
  exec(compile(ast.Module(body=body,type_ignores=[]),'<exact-embedded-observer-caller-fixture>','exec'),ns)
  old=Path.read_text
  def text(path,*args,**kwargs):return 'Name:\ttest\nPPid:\t1\n' if str(path).endswith('/status') else old(path,*args,**kwargs)
  with mock.patch.object(Path,'read_text',text):return ns['caller']()
 def test_13_embedded_caller_original_basename_accepts_private_path(self):
  self.assertEqual(source.name,'native_rust_exact_disk_build_wrapper.py');self.assertEqual(self.embedded_caller(str(source)),(12345,'76500000'))
 def test_14_embedded_caller_renamed_script_still_refused(self):
  with self.assertRaisesRegex(RuntimeError,'calling wrapper identity unavailable'):self.embedded_caller(str(P/'native_rust_exact_disk_build_wrapper.C252-BOUNDED-REFUSAL-DIAGNOSTIC.py'))
 def test_15_embedded_caller_exact_RETRY2_boundary_preserved(self):
  self.assertEqual(self.embedded_caller(self.m['RETRY2_RELEASE_PATH']),(12345,'76500000'))
 def historical(self,ns):
  calls=[];rows=[dict(path='/fixture/lease-'+str(k),sha256='a'*64,device=1,inode=k+1,size=1,pid=k+100,starttime='1',evidence_sha256='b'*64) for k in range(7)]
  def observer(argv,data,env,timeout):
   calls.append((argv,data,timeout));return types.SimpleNamespace(returncode=0,stdout=json.dumps(dict(schema='mckernel.historical-lease-observation.v1',status='PASS_READ_ONLY',boot_id=BOOT,leases=rows)).encode())
  ns['_run_bounded_observer']=observer;ns['_sudo_environment']=lambda:{};old=Path.read_text
  def text(path,*args,**kwargs):return BOOT if str(path)=='/proc/sys/kernel/random/boot_id' else old(path,*args,**kwargs)
  with mock.patch.object(Path,'read_text',text):result=ns['_historical_lease_observation']()
  return result,calls
 def test_16_exact_real_sibling_stable_FD_auth_then_mock_transport(self):
  helper=Path(ready['historical_observer']['path']);self.assertEqual(helper.parent,source.parent);self.assertEqual(digest(helper),self.m['HISTORICAL_OBSERVER_SHA256'])
  result,calls=self.historical(self.m);self.assertEqual(len(result),7);self.assertEqual(len(calls),1);self.assertEqual(calls[0][1],helper.read_bytes());self.assertEqual(calls[0][0],['/usr/bin/sudo','-A','/usr/bin/python3','-I','-B','-']);self.assertEqual(calls[0][2],30)
 def test_17_missing_sibling_refuses_before_mock_transport(self):
  ns=self.m;ns['__file__']=str(Path(self.temp.name)/'native_rust_exact_disk_build_wrapper.py')
  with self.assertRaises(ns['AdmissionError']):self.historical(ns)
 def test_18_tampered_sibling_refuses_before_mock_transport(self):
  ns=self.m;ns['__file__']=str(Path(self.temp.name)/'native_rust_exact_disk_build_wrapper.py');(Path(self.temp.name)/'native_exact_historical_lease_observer.py').write_bytes(b'wrong helper')
  with self.assertRaises(ns['AdmissionError']):self.historical(ns)
 def test_19_stage_allowlist_and_file_dependencies_exact(self):
  raw=source.read_text();self.assertIn("'_privileged_process_observation'",raw);self.assertNotIn("'_privileged_processes'",raw)
  tree=ast.parse(baseline.read_bytes());users=[n.name for n in tree.body if isinstance(n,ast.FunctionDef) and any(isinstance(x,ast.Name) and x.id=='__file__' for x in ast.walk(n))];self.assertEqual(users,['_historical_lease_observation'])
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RefusalTests));print(json.dumps(dict(scope=__doc__.splitlines()[0],status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),live_observers_called=False,baseline_sha256=ready['baseline']['sha256'],diagnostic_sha256=ready['diagnostic_census']['sha256']),sort_keys=True));raise SystemExit(0 if result.wasSuccessful() else 1)
