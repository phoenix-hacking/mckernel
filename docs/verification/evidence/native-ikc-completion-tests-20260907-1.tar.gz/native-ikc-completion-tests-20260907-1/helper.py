from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-ikc-completion-tests-20260907-' + sys.argv[1])
out.mkdir()
source = out / 'source'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', commands=[], production_gate_credit=False)
files = ['kernel/rust/ikc_queue.rs', 'kernel/rust/abi.rs', 'kernel/rust/list_helpers.rs',
         'kernel/rust/x86_setup.rs', 'host-kernel/native-rust/ikc_queue.rs',
         'host-kernel/native-rust/ikc_master.rs', 'host-kernel/native-rust/abi/x86_64.rs',
         'host-kernel/native-rust/ihk_mapping.rs', 'host-kernel/native-rust/smp_resource.rs',
         'host-kernel/native-rust/smp_image.rs', 'host-kernel/native-rust/smp_memory.rs',
         'scripts/tests/fixtures/ihk_native_queue_compile.rs', 'scripts/tests/fixtures/ihk_native_master_compile.rs',
         'scripts/tests/fixtures/ihk_smp_image_compile.rs', 'scripts/tests/fixtures/mckernel_ikc_queue_compile.rs',
         'scripts/tests/test_mckernel_ikc_queue.py', 'ihk/ikc/queue.c', 'ihk/ikc/include/ikc/queue.h']
formatted = ['kernel/rust/ikc_queue.rs', 'kernel/rust/x86_setup.rs', 'host-kernel/native-rust/ikc_queue.rs',
             'host-kernel/native-rust/smp_image.rs', 'host-kernel/native-rust/smp_memory.rs',
             'scripts/tests/fixtures/ihk_smp_image_compile.rs', 'scripts/tests/fixtures/mckernel_ikc_queue_compile.rs']
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def run(label, command):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=source, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-14000:])
try:
    shutil.copyfile(__file__, out / 'helper.py')
    for relative in files:
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / relative, target)
    record['input_sources'] = [identity(source / relative) for relative in files]
    run('format', ['rustfmt', '--edition=2021', '--config', 'skip_children=true,reorder_modules=false'] + formatted)
    record['compiled_sources'] = [identity(source / relative) for relative in files]
    run('format-check', ['rustfmt', '--edition=2021', '--check', '--config', 'skip_children=true,reorder_modules=false'] + formatted)
    run('actual-queue-peers', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_mckernel_ikc_queue.py', '-v', '-f'])
    for fixture in ('ihk_native_queue_compile', 'ihk_native_master_compile', 'ihk_smp_image_compile'):
        run(fixture + '-compile', ['rustc', '--edition=2021', '--test', str(source / 'scripts/tests/fixtures' / (fixture + '.rs')), '-o', str(out / fixture)])
        run(fixture + '-run', [str(out / fixture), '--test-threads=4'])
    for entry in record['compiled_sources']:
        assert identity(Path(entry['path'])) == entry
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
