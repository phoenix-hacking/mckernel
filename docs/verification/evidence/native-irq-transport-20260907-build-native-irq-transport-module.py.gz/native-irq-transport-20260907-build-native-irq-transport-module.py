from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace')
mode,attempt=sys.argv[1:]
assert mode in ('remote','default')
out=Path('/work/native-irq-transport-module-20260907-'+mode+'-'+attempt)
source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build=Path('/work/native-build-base-24a151fe')
kernel=Path('/work/native-irq-transport-kernel-20260907-1')
prior=Path('/work/native-startup-exact-stage-20260907-1')
assert json.loads((kernel/'record.json').read_text())['status']=='PASS'
assert (build/'.config').read_bytes()==(kernel/'resolved.config').read_bytes()
assert (build/'Module.symvers').read_bytes()==(kernel/'Module.symvers').read_bytes()
out.mkdir()
def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),mode=mode,inputs=[],production_gate_credit=False,mckernel_boot_proven=False)
for relative in ['kernel/rust/smp_ikc.rs','kernel/rust/llist.rs','scripts/tests/fixtures/mckernel_irq_work_verify.rs','scripts/tests/fixtures/mckernel_irq_work_layout.c']:
    path=out/'source'/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/relative,path)
    record['inputs'].append(identity(path))
for path in [build/'.config',build/'Module.symvers',build/'rust/bindings/bindings_generated.rs',source/'include/linux/irq_work.h',source/'include/linux/smp_types.h',source/'arch/x86/include/asm/apic.h',source/'kernel/irq_work.c',source/'mm/percpu.c']:
    record['inputs'].append(identity(path))
    shutil.copyfile(path,out/path.name.lstrip('.'))
shutil.copyfile(__file__,out/'build-helper.py')
module=out/'source/scripts/tests/fixtures'
remote_flags=' --cfg native_linux_irq_work_remote_queue' if mode=='remote' else ''
(module/'Kbuild').write_text("obj-m += mckernel_irq_work_verify.o\nRUSTFLAGS_mckernel_irq_work_verify.o += --cfg native_linux_irq_work_v6_12"+remote_flags+" --check-cfg='cfg(native_linux_irq_work_v6_12,native_linux_irq_work_remote_queue,MODULE)'\nCFLAGS_mckernel_irq_work_layout.o += -DMCKERNEL_IRQ_REMOTE_WITNESS\n")
base=shlex.split((prior/'module-build.command').read_text())[:-3]+['M='+str(module)]
commands=[base+['mckernel_irq_work_layout.o'],base+['modules']]
record['commands']=commands
try:
    with (out/'module-build.log').open('wb') as log:
        for command in commands:
            print('RUN',shlex.join(command),flush=True)
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    for section,name,count,expected in [('.mckernel_irq_layout','layout',12,[32,8,0,8,12,14,16,24,4,1,2,32]),
                                        ('.mckernel_irq_transport','transport-layout',6,[8,8,1024,0,20,246])]:
        subprocess.run(['objcopy','--dump-section',section+'='+str(out/(name+'.bin')),str(module/'mckernel_irq_work_layout.o')],check=True)
        actual=list(struct.unpack('<'+str(count)+'Q',(out/(name+'.bin')).read_bytes()))
        assert actual==expected,(name,actual)
        record[name]=actual
    for name in ['mckernel_irq_work_verify.ko','mckernel_irq_work_layout.o']:
        shutil.copyfile(module/name,out/name)
    for command,name in [(['readelf','-h',str(out/'mckernel_irq_work_verify.ko')],'module-elf-header.txt'),
                         (['nm','-u',str(out/'mckernel_irq_work_verify.ko')],'module-undefined.txt'),
                         (['objdump','-d',str(out/'mckernel_irq_work_verify.ko')],'module-disassembly.txt')]:
        (out/name).write_bytes(subprocess.check_output(command))
    imports=(out/'module-undefined.txt').read_text()
    if mode=='remote':
        assert ' U irq_work_queue\n' not in imports
        for symbol in ['raised_list','per_cpu_ptr_to_phys','irq_work_sync','__SCT__apic_call_send_IPI_mask','cpus_read_lock','cpus_read_unlock','smp_call_function_single']:
            assert ' U '+symbol+'\n' in imports,symbol
    else: assert ' U irq_work_queue\n' in imports
    elf=(out/'module-elf-header.txt').read_text()
    assert 'ELF64' in elf and 'Advanced Micro Devices X86-64' in elf
    assembly=(out/'module-disassembly.txt').read_text()
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b',assembly), 'SIMD/x87 register in fixture module'
    record['outputs']=[identity(out/name) for name in ['mckernel_irq_work_verify.ko','mckernel_irq_work_layout.o','layout.bin','transport-layout.bin','module-elf-header.txt','module-undefined.txt','module-disassembly.txt']]
    for item in record['inputs']: assert identity(Path(item['path']))==item
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record.get('status','FAIL'),out,flush=True)
    if record.get('status')!='PASS': print((out/'module-build.log').read_text()[-12000:],flush=True)
