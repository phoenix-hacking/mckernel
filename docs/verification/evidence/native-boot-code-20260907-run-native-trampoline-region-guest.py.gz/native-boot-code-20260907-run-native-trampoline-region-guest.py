from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
mode, module_attempt, guest_attempt = sys.argv[1:]
assert mode in ('normal', 'reserved', 'hole')
compiled = Path('/work/native-trampoline-region-module-20260907-' + module_attempt)
out = Path('/work/native-trampoline-region-guest-20260907-' + mode + '-' + guest_attempt)
kernel = Path('/work/native-irq-transport-exact-stage-20260907-1')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
compiled_record = json.loads((compiled / 'record.json').read_text())
assert compiled_record['status'] == 'PASS'
for item in compiled_record['outputs'] + compiled_record['inputs']:
    assert identity(Path(item['path'])) == item
for item in compiled_record['inputs']:
    path = Path(item['path'])
    if path.is_relative_to(compiled / 'source'):
        current = repo / path.relative_to(compiled / 'source')
        assert current.read_bytes() == path.read_bytes(), current
config = (kernel / 'resolved.config').read_text()
for required in ['CONFIG_IRQ_WORK=y\n', 'CONFIG_X86_LOCAL_APIC=y\n', 'CONFIG_MODULE_UNLOAD=y\n', '# CONFIG_PREEMPT_RT is not set\n']:
    assert required in config, required
assert (compiled / 'config').read_text() == config
out.mkdir()
shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), out / 'root')
shutil.copyfile(repo / 'scripts/native-trampoline-region-init.sh', out / 'root/init')
(out / 'root/init').chmod(0o755)
shutil.copyfile(compiled / 'mckernel_trampoline_region_verify.ko', out / 'root/modules/mckernel_trampoline_region_verify.ko')
shutil.copyfile(__file__, out / 'run-helper.py')
subprocess.run(['bash', '-n', str(out / 'root/init')], check=True)
environment = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(out / 'root'))
subprocess.run(['python3', '-B', '/work/write-native-cpio-spec.py'], env=environment, check=True)
with (out / 'initramfs.cpio.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
        process = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
        shutil.copyfileobj(process.stdout, output)
        process.stdout.close()
        assert process.wait() == 0
args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
        '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
        '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
        '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
        '-kernel', str(kernel / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
        '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1' + ({'normal': '', 'reserved': ' memmap=4K$0x80000', 'hole': ' memmap=4K%0x80000-1'}[mode]),
        '-display', 'none', '-monitor', 'none', '-serial', 'file:' + str(out / 'serial.log'), '-no-reboot', '-nic', 'none']
record = dict(source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), started_utc=datetime.now(timezone.utc).isoformat(), status='running', qemu_args=args,
              inputs=[identity(path) for path in [Path(__file__), out / 'initramfs.cpio.gz', kernel / 'bzImage', kernel / 'resolved.config', compiled / 'record.json', compiled / 'mckernel_trampoline_region_verify.ko']],
              cpus=4, numa_nodes=2, memory_mib=8192, container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)),
              production_gate_credit=False, mckernel_boot_proven=False, linux_idle='default', reservation_mode=mode, scope='actual Linux exclusive resource and WB mapping; no CPU executes tested page')
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
save()
try:
    with (out / 'qemu.log').open('wb') as log:
        result = subprocess.run(['/usr/bin/timeout', '--signal=TERM', '--kill-after=30s', '300'] + args, stdout=log, stderr=subprocess.STDOUT)
    record['qemu_exit_code'] = result.returncode
    assert result.returncode == 0, result.returncode
    serial = (out / 'serial.log').read_text(errors='replace')
    for marker in ['MCKERNEL_TRAMPOLINE_REGION_GUEST PASS', 'MCKERNEL_TRAMPOLINE_REGION_GUEST cycle=1 complete', 'MCKERNEL_TRAMPOLINE_REGION_GUEST cycle=2 complete']:
        assert marker in serial, marker
    # dmesg repeats the two live module cycles once at guest exit.
    prefix = 'MCKERNEL_TRAMPOLINE_REGION '
    expected = ('PASS physical=80000 cycles=64 bytes=4096 exclusive=1 mckernel_boot=0'
                if mode == 'hole' else 'REJECT mapped=1 writes=0 mckernel_boot=0')
    unload = 'UNLOAD released=1' if mode == 'hole' else 'UNLOAD released=0 writes=0'
    assert serial.count(prefix + expected) == 4
    assert serial.count(prefix + unload) == 4
    assert serial.count(prefix + ('REJECT' if mode == 'hole' else 'PASS')) == 0
    for forbidden in ['MCKERNEL_TRAMPOLINE_REGION_GUEST FAIL', 'Kernel panic', 'BUG:', 'WARNING:', 'Oops:', 'error:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
        assert forbidden not in serial, forbidden
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item
    record.update(status='PASS', module_cycles=2, lease_cycles=(128 if mode=='hole' else 0), mapped_ram_bytes=(4096 if mode=='hole' else 0))
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
