"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing."""
from pathlib import Path
import os,json,hashlib,importlib.util,signal,resource
D=Path(__file__).parent
P=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-6/m14-file-lanes/kernel-mem/consolidate-three-CPU-read-order-source-probe-request-1/EXACT-ROOT-COMPILER-PROBE.REQUEST.json')
assert hashlib.sha256(P.read_bytes()).hexdigest()=='58575e68e185f5b766bd507b8006bb407575a24952cb92bb45bb5498378a2cf7'
d=json.loads(P.read_text()); r=d['profile_reference']; prof=Path(r['path']);assert hashlib.sha256(prof.read_bytes()).hexdigest()==r['sha256']
# Only consumed GCC/header inputs plus explicitly selected source/providers are authority for this probe.
refs=[d['source'],d['original_source']]+d['providers']
frozen=json.loads(prof.read_text())['frozen_inputs']
refs += [r for r in frozen if '/include/' in r['path'] or r['path'].endswith('/gcc-9')]
for row in refs:
 q=Path(row['path']);b=q.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],str(q)
a=d['proposed_command']['argv']; out=Path(a[a.index('-o')+1]);assert not out.exists()
assert os.getuid()==1000 and os.sched_getaffinity(0)=={0}
m=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
assert m>=25501368320
for loc,floor in [('/home/holden/mckernel',16<<30),('/home/holden/mckernel-work/scratch',12<<30)]:
 v=os.statvfs(loc);assert v.f_bavail*v.f_frsize>=floor
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
assert hashlib.sha256(H.read_bytes()).hexdigest()=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
spec=importlib.util.spec_from_file_location('owned',H);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,h.stop)
for key,val in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]:resource.setrlimit(key,(val,val))
os.environ['RUST_MIN_STACK']='2097152'
os.chdir(d['proposed_command']['cwd'])
c={'argv':['/usr/bin/taskset','-c','6']+a,'purpose':d['proposed_command']['purpose']}
h.write(D/'ROOT-GRANT.json',dict(scope=__doc__,command=c,MemAvailable=m,ordinary_CPU=6,physical_acceptance='b4d186797b71a25ddb9ae0117c06c1b5bb1c2127f062365736eb0b19ba587776',execution_count=1))
signal.setitimer(signal.ITIMER_REAL,96)
r=h.owned_capture(c,D,90,lambda:None);h.write(D/'WHOLE-JOIN.json',r);signal.setitimer(signal.ITIMER_REAL,0)
print(json.dumps({k:r.get(k) for k in ['returncode','seconds','direct_child_joined','group_absent','closed_streams','error','retirement_error','timed_out']}))
assert r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and r['error'] is None and r['retirement_error'] is None and not r['timed_out']
