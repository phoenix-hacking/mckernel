"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One ordinary UID1000 metadata publication: exclusive empty HOST candidate and
exact completed request/11-source map. No owner import/API/query/release execution.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,uuid
D=Path(__file__).resolve().parent
REQUEST = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/REQUEST.MOUNTPOINT-BOUND.FINAL.NAMESPACE-PENDING.json', 'sha256': '1688f430342328ea8763dff97fb24d5dab66d752603d587d55d7d4487bbded2d', 'bytes': 3018}
RELEASE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/RELEASE.MOUNTPOINT-SCHEMA-FINAL.NO-CLOCK-NO-APPROVAL.json', 'sha256': 'b7196f795a6abed967e1d7529aaf98d714418daa67fffc4b3d675d8fbadc834d', 'bytes': 4598}
OWNER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/target_tools_sdk_owner.MOUNTPOINT-SCHEMA-FINAL.py', 'sha256': '22bc0cd21fd998737dfadba299aad52111857498d99c70f6dae66e9c27d761ad', 'bytes': 176167}
DRIVER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/target_tools_sdk_driver.LIBDWARF-BOUND.py', 'sha256': 'd984255ef5900b37ca6293ead05b7e4018a3d547f6fa0895cc1937148e23e651', 'bytes': 16613}
MATERIAL={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/source-materialization-1/MATERIALIZATION-RESULT.json', 'sha256': '6e60ae59f0b3a5fa87bc612380dae7788c1756c386d7669c3331f428c1263b0b', 'bytes': 3542}
PROOF = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/ACTUAL-STATIC-MOUNT-AND-412-MODE-115-CMAKE-PATH-JOIN.json', 'sha256': 'd54aef6cf68a2a31257a179aaedf245ac1a7ed603b303b90a704bd8e3a6ae130', 'bytes': 112444}

PREPARATION = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/preparation.LIBDWARF-BOUND.IDENTICAL.json', 'sha256': '8bf2d79df19bcb5daa567175dab0948d3dbc5fcef2a3e37d18c596f7bfb67d2d', 'bytes': 129089}
CONFIGURATION = {'bytes': 122557, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/TARGET-DRIVER.LIBDWARF-BOUND-INPUTS.json', 'sha256': 'b2353e7e8d41209296e3c8504a2d5fe35778bdac4bb6a58188feeb6c2842512c'}

def need(ok,message):
 if not ok:raise ValueError(message)
def read(ref):
 p=Path(ref['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=32<<20,'bounded regular input');blocks=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   blocks.append(b)
  raw=b''.join(blocks);z=os.fstat(fd);n=p.lstat();keys=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(a,k)==getattr(z,k)==getattr(n,k) for k in keys) and len(raw)==z.st_size and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'stable9 pinned input');return raw
 finally:os.close(fd)
def node(path):
 p=Path(path);need(p.is_dir() and not p.is_symlink(),'owned directory');s=p.stat();need(s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700,'private directory identity');return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
def publish(path,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 parent=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(parent)
 finally:os.close(parent)
 return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
MOUNTPOINT = '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf/libdwarf'
MOUNTPOINT_PARENT = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf', 'device': 66306, 'inode': 56518804, 'uid': 1000, 'gid': 1000, 'mode': 448}

def create_vendor_mountpoint():
 path=Path(MOUNTPOINT);parent=path.parent
 need(parent.resolve()==parent,'literal non-symlink mountpoint parent')
 fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);expected=MOUNTPOINT_PARENT
  actual=dict(path=str(parent),device=a.st_dev,inode=a.st_ino,uid=a.st_uid,gid=a.st_gid,mode=stat.S_IMODE(a.st_mode))
  need(actual==expected and a.st_uid==a.st_gid==1000,'exact retained mountpoint parent')
  need(not os.path.lexists(path),'mountpoint absent before exclusive creation')
  os.mkdir(path.name,mode=0o700,dir_fd=fd)
  child=os.open(path.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
  try:
   s=os.fstat(child);n=path.lstat()
   need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700 and s.st_dev==a.st_dev,'owned mountpoint mode/device')
   need(s.st_dev==n.st_dev and s.st_ino==n.st_ino and os.listdir(child)==[],'empty exact created mountpoint inode')
   identity=dict(path=str(path),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
   os.fsync(child)
  finally:os.close(child)
  z=os.fstat(fd);need(z.st_dev==a.st_dev and z.st_ino==a.st_ino and os.stat(parent).st_ino==a.st_ino,'parent identity retained');os.fsync(fd)
  return identity
 finally:os.close(fd)

def main():
 need(sys.argv[1:]==['--publish-metadata-once'] and os.getuid()==os.geteuid()==os.getgid()==1000,'exact ordinary UID1000 metadata invocation')
 request=json.loads(read(REQUEST));release=json.loads(read(RELEASE));read(OWNER);read(DRIVER);read(PREPARATION);read(CONFIGURATION);material=json.loads(read(MATERIAL));proof=json.loads(read(PROOF));need(proof['missing']==[],'complete static read-path join')
 need(material['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and node(material['source_root'])==material['source_identity'],'actual materialized source identity')
 need(not (D/'workspace').exists() and not (D/'REQUEST.ROOT.FINAL.json').exists(),'fresh finite namespace/publication')
 mountpoint_identity=create_vendor_mountpoint()
 nonce=uuid.uuid4().hex;parent=D/'workspace';parent.mkdir(mode=0o700);candidate=parent/('native-running-modules-candidate-'+nonce);candidate.mkdir(mode=0o700);evidence=parent/('native-running-modules-owner-'+nonce)
 request.update(libdwarf_mountpoint_identity=mountpoint_identity,nonce=nonce,candidate_root=str(candidate),candidate_identity=node(candidate),owner_evidence_root=str(evidence),input_root=str(D),input_identity=node(D),output_parent_identity=node(parent))
 need(request['request_path']==str(D/'REQUEST.ROOT.FINAL.json') and not evidence.exists() and list(candidate.iterdir())==[],'exact nonce-bound request/freshness')
 rq=publish(D/'REQUEST.ROOT.FINAL.json',request);release.update(nonce=nonce,request=dict(path=rq['path'],sha256=rq['sha256']),status='PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW')
 rl=publish(D/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json',release)
 finalmap=publish(D/'ACTUAL-FINAL-ELEVEN-SOURCE-MAP.json',dict(source_sha256=release['source_sha256'],owner=OWNER,driver=DRIVER,preparation=PREPARATION,configuration=CONFIGURATION,request=rq,nonce=nonce,source_materialization=MATERIAL,execution_release=False))
 result=dict(libdwarf_mountpoint_identity=mountpoint_identity,mountpoint_parent_identity=MOUNTPOINT_PARENT,original_copy_result_preserved=MATERIAL,status='PASS_EXCLUSIVE_TARGET_METADATA_NAMESPACE_AND_REQUEST_ONLY',request=rq,release_pending=rl,final_eleven_source_map=finalmap,nonce=nonce,owner=OWNER,driver=DRIVER,source_sha256=release['source_sha256'],candidate_identity=node(candidate),output_parent_identity=node(parent),input_identity=node(D),actual_source_materialization=MATERIAL,read_path_proof=PROOF,execution_release=False)
 rr=publish(D/'ACTUAL-METADATA-PUBLICATION-RECEIPT.json',result);print(json.dumps(dict(receipt=rr,**result),sort_keys=True))
if __name__=='__main__':main()
