"""Retain a source-only design and original evidence; never execute reviewed code."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import stat
import tarfile

ROOT = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
NAME = 'stability-accepted-prefix-hold-draft-20260913'
OUT = Path('/tmp/stability-accepted-prefix-hold-retention-20260913-1')
PEER = Path('/tmp/stability-accepted-prefix-design-peer-20260913-lhz6dk_u')
FIRST = Path('/tmp/stability-accepted-prefix-hold-draft-20260913-1')
OUT.mkdir()
shutil.copy2(__file__, OUT / 'retention.py')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())


def tree(path):
    rows = []
    for item in [path] + sorted(path.rglob('*')):
        mode = item.lstat().st_mode
        row = dict(path=str(item.relative_to(path.parent)), mode=stat.S_IMODE(mode))
        if stat.S_ISDIR(mode): row['kind'] = 'directory'
        else:
            assert stat.S_ISREG(mode)
            row.update(kind='file', **{k:v for k,v in identity(item).items() if k != 'path'})
        rows.append(row)
    return rows


sources = []
def retain(path, relative):
    dest = OUT / 'source' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)
    assert path.read_bytes() == dest.read_bytes()
    sources.append(dict(original=identity(path), retained='source/' + relative))


for directory in (FIRST, PEER):
    original = tree(directory)
    shutil.copytree(directory, OUT / directory.name)
    assert tree(directory) == tree(OUT / directory.name) == original
assert identity(PEER / 'review.json')['sha256'] == '0236379dafd3578cc9153b8fffecb7972f111c1b6facc43921bb6bde02c17a4e'
doc = ROOT / 'docs/verification' / (NAME + '.md')
assert identity(doc)['sha256'] == '7137a605b8794b3f49725c0d2a06c1c1682244c4c6ca7555d8312d12944b1c7d'
relative_paths = [
    'docs/verification/' + NAME + '.md',
    'scripts/tests/fixtures/stability-owner-phase/stability_phase.rs',
    'scripts/tests/fixtures/stability-owner-phase/smp_service.append.rs',
    'scripts/tests/fixtures/stability-owner-phase/smp_memory.append.rs',
    'scripts/tests/fixtures/stability-owner-phase/smp_application.append.rs',
    'scripts/tests/fixtures/stability-owner-phase/smp_application_syscall.append.rs',
    'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/controller.c',
    'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/phase_client.h',
    'scripts/tests/fixtures/stability-transport-fault/send.append.rs',
    'scripts/tests/fixtures/stability-ret-observer.rs',
    'scripts/tests/prepare_stability_owner_phase.py',
    'scripts/tests/prepare_stability_transport_fault.py',
    'scripts/application-tests/fault_control.py',
    'scripts/application-tests/phase_observations.py',
    'scripts/application-tests/owner_observations.py',
    'host-kernel/native-rust/smp_application.rs',
    'host-kernel/native-rust/smp_application_syscall.rs',
    'host-kernel/native-rust/smp_service.rs',
]
for relative in relative_paths:
    retain(ROOT / relative, relative)
linux = WORK / 'native-source/linux-6.12.0-211.44.1.el10_2/fs/proc/base.c'
retain(linux, 'pinned-linux/fs/proc/base.c')
guest = WORK / 'stability-transport-fault-guest-20260913-permanent-backpressure-2'
for relative in ['record.json', 'guest-artifacts/files/mckernel/events.jsonl',
                 'guest-artifacts/files/mckernel/report.json', 'guest-artifacts/files/native-dmesg.txt']:
    retain(guest / relative, 'original-permanent-guest2/' + relative)

events = guest / 'guest-artifacts/files/mckernel/events.jsonl'
raw_lines = events.read_bytes().splitlines(keepends=True)
selected = []
for number in (4, 11, 22):
    raw = raw_lines[number - 1]
    row = json.loads(raw)
    assert row['event'] == 'worker-syscall'
    decoded = bytes.fromhex(row['raw_hex'])
    selected.append(dict(original_artifact=identity(events), line=number,
                         original_line_sha256=hashlib.sha256(raw).hexdigest(), event=row,
                         raw_syscall_bytes_hex=decoded.hex(), raw_syscall_bytes_repr=repr(decoded)))
assert bytes.fromhex(selected[2]['raw_syscall_bytes_hex']) == b'running\n'
assert selected[2]['event']['monotonic_ns'] == 35745933935
native = guest / 'guest-artifacts/files/native-dmesg.txt'
ret_lines = [dict(line=i, raw_hex=line.hex(), sha256=hashlib.sha256(line).hexdigest())
             for i,line in enumerate(native.read_bytes().splitlines(keepends=True), 1)
             if b'STABILITY_RET_ENTER ' in line or b'STABILITY_RET_LEAVE ' in line]
assert len(ret_lines) == 2
evidence = dict(status='ORIGINAL_BYTES_RETAINED_NOT_A_NEW_TEST',
                raw_worker_samples=selected, original_native_ret_lines=ret_lines,
                native_ret_artifact=identity(native),
                note='Sample chronology remains original. running is UNKNOWN in the proposed correction. Root owns the separate polling candidate and regression vectors; this design creates none.')
with (OUT / 'original-sampling-evidence.json').open('x') as stream:
    json.dump(evidence, stream, indent=2, sort_keys=True); stream.write('\n')
old_doc = FIRST / (NAME + '.md')
delta = ''.join(difflib.unified_diff(old_doc.read_text().splitlines(True), doc.read_text().splitlines(True),
                 fromfile='original-reviewed-draft', tofile='final-ack-wording-draft'))
with (OUT / 'peer-ack-wording-correction.diff').open('x') as stream: stream.write(delta)
review = dict(schema_version=1, status='SOURCE_BOUND_DESIGN_DRAFT_ONLY',
    record_kind='published_modes_accepted_prefix_hold_design',
    implementation_present=False, execution_authorized=False,
    proposed_modes=['postpublish-notify', 'recoverable-backpressure'],
    original_modes_1_and_4_unchanged=True, public_production_abi_changes=False,
    design=identity(doc), reviewed_inputs=sources,
    independent_design_review=identity(PEER / 'review.json'),
    full_independent_review_tree=str(PEER), original_draft_tree=str(FIRST),
    corrected_finding='Latch release-possible before first host ACK send attempt and before native release ioctl submission; all later emergency/final response reads forbidden even on short/error/timeout outcomes.',
    selected_mechanism=[
      'New published-only private command/profile, HELD stage after exactly one complete AcceptedReturn snapshot and observed original publication_since Some.',
      'Controller queries held state before observe_return, obtains new ACCEPTED_RETURN host physical capture+verified-continue ACK, then submits one ACK-bound RELEASE.',
      'No host wait under production locks or verification Permit. Existing brief slots lock copies/validates original completion/timer and commits only scalar release state.',
      'Host-hold retries are distinct from original pre-snapshot barrier and fault attempts; no production timer reset or new guest-memory ownership.',
      'Native release rechecks the unchanged original5second deadline; recovery retains its original2second post-release backpressure interval and actual successful-callback deadline proof.',
    ],
    sampling_correction=evidence,
    unresolved_before_execution=[
      'Implementation and independent source review of new phase/client/controller/UART/host validator graph.',
      'Separately root-owned corrected polling candidate freeze and integration.',
      'Bounded negative protocol/lifetime/copyout/identity/deadline/counter tests and combined artifact budget.',
      'Pinned native/controller compilation, actual new compiled stack measurement and explicit unchanged Linux/dynamic residuals.',
      'Reviewed fresh execution packet and actual physical/provenance/owner/raw-return review; no feasibility or acceptance inferred from design.',
    ],
    tests_executed=False, builds_executed=False, guest_execution=False,
    physical_prefix_verified=False, application_acceptance=False,
    transport_acceptance=False, production_gate_credit=False)
with (OUT / 'design-review.json').open('x') as stream:
    json.dump(review, stream, sort_keys=True, indent=2); stream.write('\n')
members = tree(OUT)
archive = ROOT / 'docs/verification/evidence' / (NAME + '.tar.gz')
assert not archive.exists()
with tarfile.open(str(archive), 'x:gz', format=tarfile.PAX_FORMAT) as tf:
    tf.add(str(OUT), arcname=OUT.name)
found = []
with tarfile.open(str(archive), 'r:gz') as tf:
    for member in tf.getmembers():
        row = dict(path=member.name, mode=member.mode)
        if member.isdir(): row['kind'] = 'directory'
        else:
            assert member.isfile()
            data = tf.extractfile(member).read()
            row.update(kind='file', size=len(data), sha256=hashlib.sha256(data).hexdigest())
        found.append(row)
assert sorted(found, key=lambda r:r['path']) == sorted(members, key=lambda r:r['path']) == sorted(tree(OUT), key=lambda r:r['path'])
review.update(source_capture=str(OUT), archive=identity(archive), archive_members=members,
              archive_member_count=len(members), all_archive_members_rehashed=True)
published = ROOT / 'docs/verification' / (NAME + '.json')
with published.open('x') as stream:
    json.dump(review, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps(dict(record=identity(published), archive=identity(archive),
                     source_inputs=len(sources), archive_members=len(members)), indent=2))
