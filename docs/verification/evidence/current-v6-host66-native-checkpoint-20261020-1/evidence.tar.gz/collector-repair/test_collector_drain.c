#define ND_PAIR_LAUNCH_EXPANSION 1
#define PAIR_ROOT "."
#define klogctl fixture_klogctl
#define nanosleep fixture_nanosleep
#define clock_gettime fixture_clock_gettime
#define main fixture_unused_collector_main
#include "candidate/pair_collector.c"
#undef main
#undef klogctl
#undef nanosleep
#undef clock_gettime
#include <assert.h>
#include <stdlib.h>
static uint64_t fixture_clock;
static unsigned fixture_reads,fixture_sleeps;
static int fixture_progress,fixture_full;
static char fixture_pending[16384],fixture_complete[16384],fixture_bad[16384];
static const char *fixture_fixed;
int fixture_clock_gettime(clockid_t ignored,struct timespec *t)
{(void)ignored;t->tv_sec=(time_t)(fixture_clock/1000000000);t->tv_nsec=(long)(fixture_clock%1000000000);return 0;}
int fixture_nanosleep(const struct timespec *t,struct timespec *rest)
{(void)rest;fixture_clock+=(uint64_t)t->tv_sec*1000000000+(uint64_t)t->tv_nsec;fixture_sleeps++;return 0;}
int fixture_klogctl(int operation,char *out,int limit)
{
 assert(operation==3);fixture_reads++;
 if(fixture_full){memset(out,'x',(size_t)limit);return limit;}
 const char *text=fixture_fixed?fixture_fixed:(fixture_progress && fixture_clock>=2000000000?fixture_complete:fixture_pending);
 size_t n=strlen(text);assert(n<(size_t)limit);memcpy(out,text,n);return (int)n;
}
static void fixture_add(char *out,const char *format,...)
{size_t n=strlen(out);va_list a;va_start(a,format);int r=vsnprintf(out+n,16384-n,format,a);va_end(a);assert(r>0 && (size_t)r<16384-n);}
static void fixture_logs(void)
{
 for(int i=0;i<2;i++){
  int pid=1001+i,worker=10+i,serial=20+i*10,token=100+i*10;
  fixture_add(fixture_pending,"application SCHEDULE os=0 generation=1 pid=%d cpu=%d\n",pid,i);
  fixture_add(fixture_pending,"application procfs published os=0 generation=1 pid=%d tid=%d\n",pid,pid);
  fixture_add(fixture_pending,"application_syscall=delivered os=0 generation=1 pid=%d worker=%d delivery=%d cpu=%d number=1\n",pid,worker,serial,i);
  fixture_add(fixture_pending,"application_syscall=returned os=0 generation=1 pid=%d worker=%d delivery=%d cpu=%d value=0\n",pid,worker,serial,i);
  fixture_add(fixture_pending,"application_syscall=delivered os=0 generation=1 pid=%d worker=%d delivery=%d cpu=%d number=231\n",pid,worker,serial+1,i);
  fixture_add(fixture_pending,"application retirement os=0 generation=1 pid=%d token=%d errno=-11\n",pid,token);
  fixture_add(fixture_pending,"application procfs deleted os=0 generation=1 pid=%d tid=%d\n",pid,pid);
 }
 strcpy(fixture_complete,fixture_pending);
 for(int i=0;i<2;i++){
  fixture_add(fixture_complete,"application retirement os=0 generation=1 pid=%d token=%d errno=0\n",1001+i,101+i*10);
  fixture_add(fixture_complete,"application_process=release os=0 generation=1 pid=%d cleanup_errno=0\n",1001+i);
 }
 assert(!strncmp(fixture_complete,fixture_pending,strlen(fixture_pending)));
}
static void fixture_reset(const char *root,const char *name)
{
 assert(chdir(root)==0);assert(mkdir(name,0700)==0);assert(chdir(name)==0);
 assert(mkdir("evidence",0700)==0 && mkdir("evidence/round0",0700)==0);
 strcpy(pair_evidence_dir,"./evidence/round0");pair_active_round=0;pair_rounds_initialized=1;
 collector_deadline=0;fixture_clock=1000000000;fixture_reads=fixture_sleeps=0;fixture_progress=fixture_full=0;fixture_fixed=NULL;
 pair_gate_valid=0;pair_gate_bytes=0;pair_trace_total=0;pair_seen_pid_count=0;pair_seen_token_count=1;pair_seen_tokens[0]=9999;
 for(unsigned i=0;i<10;i++)pair_trace_records[i].fd=-1;
 pair_os=0;pair_generation=1;pair_host_cpus[0]=1;pair_host_cpus[1]=2;
 memset(pair_results,0,sizeof pair_results);
 const unsigned char *expected[]={pair_round_stdout_0,pair_round_stdout_1};
 const size_t lengths[]={sizeof pair_round_stdout_0,sizeof pair_round_stdout_1};
 for(int i=0;i<2;i++){
  struct result *r=&pair_results[i];r->pid=1001+i;r->clean=1;r->started=1;r->reaped=3;r->finished=4;
  r->out.eof=r->err.eof=1;r->out.eof_ns=r->err.eof_ns=2;
  r->out.observed=r->out.kept=lengths[i];memcpy(r->out.data,expected[i],lengths[i]);
 }
}
static void fixture_replace(const char *from,const char *to)
{
 strcpy(fixture_bad,fixture_pending);char *p=strstr(fixture_bad,from);assert(p);
 size_t a=strlen(from),b=strlen(to);assert(strlen(fixture_bad)-a+b<sizeof fixture_bad);
 memmove(p+b,p+a,strlen(p+a)+1);memcpy(p,to,b);fixture_fixed=fixture_bad;
}
static void fixture_hard(const char *root,const char *name,const char *from,const char *to)
{
 fixture_reset(root,name);fixture_replace(from,to);
 assert(pair_round_gate(fixture_clock+50000000)==-1 && fixture_sleeps==0 && pair_seen_token_count==1);
 printf("%s PASS immediate_refusal\n",name);
}
int main(int argc,char **argv)
{
 assert(argc==2);char root[PATH_MAX];assert(realpath(argv[1],root));fixture_logs();
 fixture_reset(root,"pending_then_real_completion");fixture_progress=1;
 assert(pair_round_gate(fixture_clock+1500000000)==0 && fixture_reads==101 && fixture_sleeps==100);
 assert(pair_seen_token_count==5 && pair_seen_tokens[0]==9999 && pair_seen_pid_count==2);
 assert(pair_gate_bytes==strlen(fixture_complete) && !memcmp(pair_gate_log,fixture_complete,pair_gate_bytes));
 assert(pair_trace_records[0].fd>=0);assert(close(pair_trace_records[0].fd)==0);pair_trace_records[0].fd=-1;
 puts("pending_then_real_completion PASS strict_actual_completion_required");
 fixture_reset(root,"pending_deadline");
 assert(pair_round_gate(fixture_clock+20000000)==-1 && fixture_sleeps==2 && fixture_reads==2);
 assert(!strcmp(pair_fail_phase,"retirement_drain_deadline") && pair_seen_token_count==1);
 assert(pair_gate_bytes==strlen(fixture_pending) && !memcmp(pair_gate_log,fixture_pending,pair_gate_bytes));
 const char fresh[]="FRESH-POSTFAIL-READ\n";assert(save_file("./evidence/kernel.log",fresh,sizeof fresh-1)==0);
 int fd=open("diagnostic.stdout",O_RDWR|O_CREAT|O_EXCL|O_CLOEXEC,0600);assert(fd>=0);
 assert(pair_failure_export(fd,fresh,sizeof fresh-1)==0);
 off_t size=lseek(fd,0,SEEK_END);assert(size>0 && size<16384);assert(lseek(fd,0,SEEK_SET)==0);
 char output[16384]={0};assert(read(fd,output,(size_t)size)==size);
 assert(strstr(output,"\"kind\":\"gate_raw\"") && strstr(output,"\"pids\":[1001,1002]") && strstr(output,"\"cpus\":[0,1]"));
 assert(!strstr(output,"46524553482d504f53544641494c"));
 assert(pair_failure_export(fd,fresh,sizeof fresh-1)==-1 && lseek(fd,0,SEEK_END)==size);assert(close(fd)==0);
 puts("pending_deadline PASS no_waiver_exact_gate_context_immutable");
 fixture_hard(root,"wrong_cpu","cpu=0","cpu=9");
 fixture_hard(root,"wrong_generation","generation=1","generation=2");
 fixture_hard(root,"terminal_error","errno=-11","errno=-5");
 fixture_hard(root,"wrong_order","application SCHEDULE","application_syscall=returned os=0 generation=1 pid=1001 worker=10 delivery=20 cpu=0 value=0\napplication SCHEDULE");
 fixture_reset(root,"foreign_pid");strcpy(fixture_bad,fixture_pending);fixture_add(fixture_bad,"application SCHEDULE os=0 generation=1 pid=2000 cpu=0\n");fixture_fixed=fixture_bad;
 assert(pair_round_gate(fixture_clock+50000000)==-1 && fixture_sleeps==0 && !strcmp(pair_fail_phase,"application_membership"));puts("foreign_pid PASS immediate_refusal");
 fixture_reset(root,"reused_prior_token");pair_seen_tokens[0]=100;
 assert(pair_round_gate(fixture_clock+50000000)==-1 && fixture_sleeps==0 && pair_seen_token_count==1);puts("reused_prior_token PASS immediate_refusal");
 fixture_reset(root,"full_snapshot");fixture_full=1;
 assert(pair_round_gate(fixture_clock+50000000)==-1 && fixture_sleeps==0 && !pair_gate_valid && !strcmp(pair_fail_phase,"kernel_snapshot"));puts("full_snapshot PASS cap_unchanged");
 fixture_reset(root,"global_deadline");collector_deadline=fixture_clock+10000000;
 assert(pair_round_gate(bounded_deadline(fixture_clock+50000000,0))==-1 && fixture_sleeps==1 && !strcmp(pair_fail_phase,"retirement_drain_deadline"));puts("global_deadline PASS existing_logger_limit");
 fixture_reset(root,"expired_deadline");
 assert(pair_round_gate(fixture_clock)==-1 && fixture_reads==0 && fixture_sleeps==0 && !pair_gate_valid);puts("expired_deadline PASS no_late_acceptance");
 return 0;
}
