"""Source/data preparation for two ordinary commands; no materialization."""
from pathlib import Path
import ast,hashlib,json,os,stat
N=Path(__file__).resolve().parent;D=N/'stage-preparation-1';ROOT=N.parent;O=ROOT/'stage-preparation-correction-1';OWNER=ROOT/'consumer-readonly-correction-1'
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def dump(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
def assignment(s,name,v):
 node=next(n for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));ls=s.splitlines(True);ls[node.lineno-1:node.end_lineno]=[name+' = '+repr(v)+'\n'];return ''.join(ls)
b=json.loads((D/'COMPOSITE-MODULE-BINDING.json').read_text());stage=json.loads((D/'STAGE-INPUTS.json').read_text());cfg=json.loads((D/'variant-settings.json').read_text());oldcfg=json.loads((O/'variant-settings.json').read_text())
p=json.loads((D/'prospective-full-argv-NOT-PREFLIGHT.json').read_text());p['AF_UNIX']=[dict(option='-qmp',path=str(Path(cfg['parent'])/('attempt-'+cfg['nonce'])/'qmp.sock'),encoded_bytes=cfg['prospective_qmp_encoded_bytes'])];(D/'prospective-full-argv-NOT-PREFLIGHT.json').write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
owner=(OWNER/'native_diagnostic_container_owner.py').read_text();tree=ast.parse(owner)
def value(name):return ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)))
mp=value('SOURCE_HASHES');ro=value('EXTRA_READONLY')
refs=[b[k] for k in ['actual_artifact_review','actual_physical_review','compiler_receipt','request','prior_ordinary_abi_review']]+[b['additive_application_abi'][k] for k in ['old','new']]
refs += [dict(path=r['path'],sha256=r['sha256'],bytes=r['size']) for r in stage['sources'].values()]
for r in refs:mp[r['path']]=r['sha256']
for path in sorted((ROOT/'collector-drain-correction-1/candidate').iterdir()):
 if path.suffix in ('.c','.h','.inc'):mp[str(path)]=ref(path)['sha256']
for name in ['native_diagnostic.py','native_diagnostic_runner.py','native_diagnostic_backend.py','qmp_capture.py','repaired_image_authority.py','composite_module_binding.py','COMPOSITE-MODULE-BINDING.json','stage_launch_init.py','STAGE-INPUTS.json']:mp[str(D/name)]=ref(D/name)['sha256']
mp[str(D/'stage-launches-1/pair-init-0755')]=stage['sources']['compiled_collector']['sha256']
# Literal immutable files are the minimum added mounts; existing broad roots
# remain historical accepted source provenance, never a current module selector.
for r in refs:
 path=Path(r['path']);roots=[Path('/home/holden/mckernel'),Path('/home/holden/mckernel-work/scratch'),*[Path(v) for v in ro]]
 if not any(path==p or (p.is_dir() and path.is_relative_to(p)) for p in roots):ro.append(str(path))
owner=assignment(owner,'SOURCE_HASHES',mp);owner=assignment(owner,'EXTRA_READONLY',list(dict.fromkeys(ro)));owner=assignment(owner,'SELF',str(D/'native_diagnostic_container_owner.py'));owner=assignment(owner,'RUNNER',str(D/'native_diagnostic_runner.py'))
old='    source = '+repr(str(OWNER/'native_diagnostic.py'));assert owner.count(old)==1;owner=owner.replace(old,'    source = '+repr(str(D/'native_diagnostic.py')));(D/'native_diagnostic_container_owner.py').write_text(owner)
replace={str(O):str(D),'v6np-261020-1':'h66rx-261020-1','v6npm-261020-1':'h66rm-261020-1','v6npf-261020-1':'h66rf-261020-1',oldcfg['nonce']:cfg['nonce']}
def sub(v):
 if isinstance(v,str):
  for a,b in replace.items():v=v.replace(a,b)
  return v
 if isinstance(v,list):return [sub(x) for x in v]
 if isinstance(v,dict):return {k:sub(x) for k,x in v.items()}
 return v
base=Path('/home/holden/mckernel-work/host-preparation/current-host-pair-205-launch-expansion-20261020-1/failure-diagnostic-1/route-proof-correction-1/stage-preparation-1')
known={r['path']:r for r in json.loads((base/'source-pins-v2.json').read_text())}
for r in refs:known[r['path']]=r
for path in sorted(D.iterdir()):
 if path.is_file():known[str(path)]=ref(path)
for path in sorted((ROOT/'collector-drain-correction-1/candidate').iterdir()):
 if path.suffix in ('.c','.h','.inc'):known[str(path)]=ref(path)
for path in [ROOT/'collector-drain-correction-1/check-2/actual-body-fixture/stdout',ROOT/'collector-drain-correction-1/check-2/whole.json']:known[str(path)]=ref(path)
pins=list(known.values());dump(D/'source-pins-v2.json',pins);authorities={}
for r in pins:
 p=Path(r['path']);s=p.stat();authorities[str(p)]=dict(path=str(p),sha256=r['sha256'],device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
dump(D/'pinned-source-authorities-v2.json',authorities)
profile=sub(json.loads((O/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json').read_text()));profile['source_pins']=ref(D/'source-pins-v2.json');profile['per_command'][0]['role']='metadata-preserving-HOST66-three-modules-and-collector-stage';profile['rationale']='One explicit HOST66 module ABI/regression probe with accepted205image/apps and reviewedcollector retirement-drain correction. Exact accepted header engine3BASEmodules+1overlayinit, all untouched order/metadata/bytes preserved; no recompilation. Reuse existing55CPU60wall whole/1GiB/CPU7/32MiBstreams64MiBstage/8MiBdiagnosticreserve. Existing same full consumer/preflight; no native/root.';dump(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json',profile)
s=(O/'run_two_commands_source_bound_corrected.py').read_text();s=assignment(s,'PROFILE_SHA',ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json')['sha256']);s=assignment(s,'SOURCE_AUTHORITIES_SHA',ref(D/'pinned-source-authorities-v2.json')['sha256']);s=s.replace('len(rows)==61','len(rows)=='+str(len(pins)));(D/'run_two_commands_source_bound.py').write_text(s)
commands=sub(json.loads((O/'COMMAND-SET-v2.json').read_text()));commands['argv'][-1]=str(D/'run_two_commands_source_bound.py');commands.update(execution_profile=ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json'),executor=ref(D/'run_two_commands_source_bound.py'),fixed_commands=profile['per_command'],required_absent_paths=profile['required_absent_paths']);dump(D/'COMMAND-SET-v2.json',commands)
packet=dict(status='SOURCE_ONLY_PENDING_AFFECTED_TWO_ORDINARY_REVIEW_AND_ROOT_GRANT',functional_scope='Functional OS/apps plus Rust/reviewedassembly cutover',variant='Explicit complete HOST66 module ABI/ordinary VMA+strict20 regression, necessarycollector drain fix; no optionalbenchmark variation or newbehaviorcredit',module_binding=ref(D/'COMPOSITE-MODULE-BINDING.json'),collector_source_acceptance=ref(stage['sources']['collector_source_review']['path']),collector_actual_checks=ref(ROOT/'collector-drain-correction-1/check-2/whole.json'),original_collector=stage['sources']['compiled_collector'],parent_manifest=stage['sources']['parent_manifest'],parent_stage_review=stage['sources']['actual_parent_stage'],only_changed_members=['modules/ihk.ko','modules/ihk-smp-x86_64.ko','modules/mcctrl.ko','init'],source_refs=[ref(p) for p in sorted(D.glob('*.py'))],source_pins=ref(D/'source-pins-v2.json'),pin_count=len(pins),commands=ref(D/'COMMAND-SET-v2.json'),profile=ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json'),executor=ref(D/'run_two_commands_source_bound.py'),prospective_qmp_bytes=cfg['prospective_qmp_encoded_bytes'],full_prospective_argv=ref(D/'prospective-full-argv-NOT-PREFLIGHT.json'),runtime_authority=False,stage_runs=0,guest_runs=0,strict_rounds=10,strict_apps=20,app_timeout_ms=10000,collector_alarm_seconds=120,positive_CREATE_PPD=False,parent_close_or_ACK_acceptance=False,phase4_default_enabled=False,retained_evidence_export_limit='Unavailable/full/empty later maincapture may suppress exactgate export; no output cap broadened',next_action='Only2fixedordinary stage+completeconsumer/preflight commands after independentrelease androotfreshCPU7admission; nativefullreview+snapshotLAST later')
dump(D/'REVIEW-PACKET.json',packet)
print(json.dumps(dict(packet=ref(D/'REVIEW-PACKET.json'),pins=len(pins),prospective_qmp_bytes=cfg['prospective_qmp_encoded_bytes'],stage_runs=0)))
