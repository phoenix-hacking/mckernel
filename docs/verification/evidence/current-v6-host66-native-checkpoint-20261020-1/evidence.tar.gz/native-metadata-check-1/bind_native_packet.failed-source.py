"""Finite source/data binding only. Pending outputs cannot authorize execution.
One final invocation binds the independent full static decision; no snapshot,
root, compiler, owner, backend, socket or workload is invoked by this program.
"""
from pathlib import Path
import ast,copy,hashlib,json,os,stat,sys
N=Path(__file__).resolve().parent;D=N/'stage-preparation-1';Q=D/'native-packet-1';OLD=Path('/home/holden/mckernel-work/host-preparation/current-host-pair-205-launch-expansion-20261020-1/failure-diagnostic-1/route-proof-correction-1/stage-preparation-1');OQ=OLD/'native-packet-1';H=Path('/home/holden/mckernel-work/host-preparation')
OR=OQ
def load(p):return json.loads(Path(p).read_bytes())
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def need(v,s):
 if not v:raise ValueError(s)
need(len(sys.argv) in (5,7),'usage: bind_native_packet.py ACTUAL_STAGE_REVIEW SHA256 LATEST_CRATE_PHYSICAL_OR_PENDING SHA256_OR_PENDING [STATIC_DECISION SHA256]')
A=Path(sys.argv[1]);need(ref(A)['sha256']==sys.argv[2],'actual stage decision bytes')
physical_pending=sys.argv[3:5]==['PENDING','PENDING']
P=Path('/home/holden/mckernel-work/host-preparation/phase4-host-sdk-independent-review-20261020-1/HOST66-ACTUAL-PHYSICAL-RETIREMENT-REVIEW.json') if physical_pending else Path(sys.argv[3])
if not physical_pending:need(ref(P)['sha256']==sys.argv[4],'genuine latest full physical descriptor')
def physical_ref():return dict(path=None,sha256=None,bytes=None) if physical_pending else ref(P)
final=len(sys.argv)==7
need(not(final and physical_pending),'cannot publish final data without latest genuine physical predecessor')
if final:
 static=ref(sys.argv[5]);need(static['sha256']==sys.argv[6],'actual static hash');review=load(sys.argv[5]);need(review['status']=='PASS' and review['implementation_ownership'] is False,'independent exact static source/data decision')
else:static=dict(path=str(H/'current-v6-composite-native-probe-independent-review-20261020-1/HOST66-DRAIN-NATIVE-SOURCE-AND-NONTEMPORAL-RELEASE.json'),sha256=None,bytes=None)
accept=load(A);facts=accept['facts'];pre=load(accept['actual_full_preflight']['path']);consumer=load(accept['actual_consumer_result']['path']);oldsettings=load(OLD/'variant-settings.json');settings=load(D/'variant-settings.json');nonce=settings['nonce'];stage=Path(settings['stage_directory']);parent=Path(settings['parent']);attempt=parent/('attempt-'+nonce);evidence=Path(str(parent)+'.owner-'+nonce)
replacements={str(OLD):str(D),str(OR):str(Q),'r205r-261020-1':'h66rx-261020-1','r205rm-261020-1':'h66rm-261020-1','r205rf-261020-1':'h66rf-261020-1',oldsettings['nonce']:nonce}
def subst(s):
 for a,b in replacements.items():s=s.replace(a,b)
 return s
def transform(v):
 if isinstance(v,str):return subst(v)
 if isinstance(v,list):return [transform(x) for x in v]
 if isinstance(v,dict):return {k:transform(x) for k,x in v.items()}
 return v
outputs={}
def add(path,v):
 b=(json.dumps(v,indent=2,sort_keys=True)+'\n').encode();outputs[Path(path)]=b;return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def add_source(path,s):outputs[Path(path)]=s.encode();return dict(path=str(path),sha256=hashlib.sha256(s.encode()).hexdigest(),bytes=len(s.encode()))
owner=D/'native_diagnostic_container_owner.py';tree=ast.parse(owner.read_text());runtime=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCE_HASHES' for t in n.targets)))
s=parent.stat();five=dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)));full=dict(path=str(parent),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
need(five==facts['parent_identity']==pre['parent_identity'] and not list(parent.iterdir()),'accepted exact empty parent')
need(all(facts['parent_nine_field_identity'][k]==getattr(s,k) for k in facts['parent_nine_field_identity']),'full accepted actual parent metadata')
physical=load(P)
import importlib.util
spec=importlib.util.spec_from_file_location('exact_host66_physical_projection',N/'sdk_physical_projection.py');decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
predecessor=decoder.project(physical,ref(P))
if physical_pending:predecessor={key:(value if key=='filesystem_uuid' else None) for key,value in predecessor.items()}
need(physical_pending or all(not os.path.lexists(predecessor[k]) for k in ['lease_path','common_exclusion','shared_heavy']),'released predecessor records absent')
prop=transform(load(OQ/'proposal.json'));prop.update(actual_full_argument_preflight=ref(D/'actual-native-preflight-fresh8b.json'),actual_ordinary_acceptance=ref(A),actual_stage_review=ref(A),actual_owner_sha256=ref(owner)['sha256'],argv=pre['owner_argv'],effective_current_controller_stop_percent=100,latest_exclusive_operation_physical_predecessor=physical_ref(),normalized_manifest=consumer['normalized_manifest'],parent=dict(path=str(parent),identity=five),parent_full_ninefield_identity=full,stage_manifest=ref(stage/'manifest.json'),scope='Fixed ten sequential strict387/254 Rust pairs in one accepted205 OS; changed Linux userland failure diagnostics only;20actual strict successes required; no partial acceptance',status='PENDING_LAST_SNAPSHOT_AND_FINAL_MACHINE')
composite=load(D/'COMPOSITE-MODULE-BINDING.json')
prop['component_ABI']=ref(D/'COMPOSITE-MODULE-BINDING.json')
prop['component_artifact']=ref(composite['actual_artifact_review']['path'])
prop['new_throughput_or_behavior_credit']=False
prop['scope']='Complete HOST66 module ABI/load with corrected bounded collector readiness and ordinary VMA/app regression on unchanged accepted205 image; ten strict pairs; no new benchmark/count/positive CREATE_PPD/parentclose/ACK credit'
prop['native_throughput_measurement'].update(minimum_ratio=4,owner_seconds_target=110.4008175)
prop['diagnostic_extra_capture_growth_bytes']=8388608;prop['physical_predecessor_is_not_module_artifact_acceptance']=True
pref=add(Q/'proposal.json',prop)
meta=transform(load(OQ/'conditional-metadata.json'));meta.update(accepted_stage_manifest=prop['stage_manifest'],actual_metadata_review=ref(A),effective_current_controller_stop_percent=100,independent_static_execution_decision=static,normalized_manifest=prop['normalized_manifest'],parent_full_ninefield_identity=full,parent_identity=five,proposal=pref)
meta['status']='PASS_NONTEMPORAL_DATA_ONLY' if final else 'PENDING_INDEPENDENT_STATIC_DATA_REVIEW'
mref=add(Q/'conditional-metadata.json',meta)
base=transform(load(OQ/'machine-base.json'));base.update(accepted_actual_stage_fixture_parent_review=ref(A),conditional_metadata_release=mref,exclusive_queue_predecessor=physical_ref(),independent_static_execution_decision=static,parent_identity=five,terminal_cleanup_and_common_shared_release=dict(status='PASS',ref=physical_ref()))
baseref=add(Q/'machine-base.json',base)
freeze=transform(load(OQ/'non-temporal-freeze.json'));freeze.update(actual_consumer_result=ref(D/'actual-fresh8b-consumer-parent-result.json'),actual_mandatory_consumer_review=ref(A),actual_preflight=ref(D/'actual-native-preflight-fresh8b.json'),actual_stage_review=ref(A),conditional_metadata=mref,current_snapshot_producer=ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),effective_current_controller_stop_percent=100,independent_static_execution_decision=static,latest_exclusive_operation_physical_predecessor=physical_ref(),latest_predecessor_note='Exact HOST66 SDK positive physical retirement bound; source/module compile authority separate from later module-load/native proof',machine_base=baseref,native_manifest=prop['normalized_manifest'],native_target=prop['native_throughput_measurement'],owner_argv=pre['owner_argv'],inside_argv=pre['inside_argv'],qemu_argv=pre['qemu_argv'],AF_UNIX_endpoints=pre['AF_UNIX_endpoints'],parent_full_ninefield_identity=full,parent_legacy_fivefield_identity=five,proposal=pref,readonly_roots=pre['readonly_roots'],runtime_owner=ref(owner),runtime_runner=ref(D/'native_diagnostic_runner.py'),runtime_observer=ref(D/'qmp_capture.py'),runtime_source_hashes=runtime,runtime_source_count=len(runtime),entire_consumed_paths=pre['consumed_paths'],consumed_path_count=len(pre['consumed_paths']),stage_native_manifest=prop['stage_manifest'])
freeze['diagnostic_extra_capture_growth_bytes']=8388608
freeze['status']='PASS_ACTUAL_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT' if final else 'PENDING_INDEPENDENT_STATIC_DATA_REVIEW'
fref=add(Q/'non-temporal-freeze.json',freeze)
b=transform(load(OLD/'fresh-snapshot-bindings.json'));b.update(conditional_metadata=mref,effective_current_controller_stop_percent=100,entire_consumed_paths=pre['consumed_paths'],machine_pending=baseref,mandatory_consumer_review=ref(A),manifest=prop['normalized_manifest'],non_temporal_freeze=fref,parent_full_identity=full,parent_identity=five,parent_review_identity=facts['parent_nine_field_identity'],physical_predecessor=predecessor,physical_review=physical_ref(),runtime_source_hashes=runtime,crate_request=(dict(path=None,sha256=None,bytes=None) if physical_pending else physical['request']),stage_review=ref(A),static_review=static,qemu_argv=pre['qemu_argv'],inside_argv=pre['inside_argv'])
scratch=Path('/home/holden/mckernel-work/scratch').stat();b['scratch_identity']=[scratch.st_dev,scratch.st_ino]
b['sdk_request']=b.pop('crate_request')
b['future_policy_source_preserved']=load(OLD/'fresh-snapshot-bindings.json')['future_policy_source_preserved']
b['source_pins']=[ref(D/name) for name in ['native_diagnostic_container_owner.py','native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py','repaired_image_authority.py']]
b['source_pins'] += [ref(N/'sdk_physical_projection.py'),ref(D/'composite_module_binding.py'),ref(D/'COMPOSITE-MODULE-BINDING.json')]
bref=add(D/'fresh-snapshot-bindings.json',b)
index=dict(status='PASS_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT' if final else 'PENDING_INDEPENDENT_STATIC_DATA_DECISION',proposal=pref,conditional_metadata=mref,machine_base=baseref,non_temporal_freeze=fref,snapshot_bindings=bref,snapshot_source=ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),snapshot_OUTPUT=str(D/'root-live-preflight-1.json'),static_review=static,actual_stage_review=ref(A),actual_mandatory_consumer_review=ref(A),actual_sdk_physical=physical_ref(),effective_current_controller_stop_percent=100,actual_snapshot=None,final_release=None,runtime_release=False)
iref=add(Q/'FINAL-NONTEMPORAL-DATA-INDEX.json',index)
projection=transform(load(OR/'SNAPSHOT-STATIC-EQUALITY-AND-CAPPED-ARGV.json'))
snapshot_argv=projection['root_snapshot_argv'];snapshot_argv[snapshot_argv.index('--bindings-sha256')+1]=bref['sha256'];snapshot_argv[snapshot_argv.index('--terminal')+1]=(None if physical_pending else str(P));snapshot_argv[snapshot_argv.index('--terminal-sha256')+1]=physical_ref()['sha256']
# Rebind every static equality to the full current authoritative descriptor.
equal=projection['snapshot_equal'];equal.update(accepted_actual_stage_fixture_parent_review=static,independent_static_execution_decision=static,non_temporal_join_result=fref,parent_identity=five,terminal_acceptance=physical_ref(),boot_id=predecessor['boot_id'],released_paths_absent=[predecessor[k] for k in ['common_exclusion','shared_heavy']])
projection.update(snapshot_equal=equal,root_snapshot_argv=snapshot_argv,OUTPUT=str(D/'root-live-preflight-1.json'),actual_static_review=static,bindings=bref,latest_physical=physical_ref(),non_temporal_freeze=fref,producer=ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),schema='mckernel.selected205.twenty-launch-current100-static-snapshot-projection.v1',status='PASS_SOURCE_DERIVED_STATIC_DATA_ONLY_NO_SNAPSHOT' if final else 'PENDING_INDEPENDENT_STATIC_DATA_REVIEW')
# The exact capped snapshot stdout/stderr/status names stay in the new packet.
for k in ['stdout_path','stderr_path','status_path']:
 projection[k]=str(Q/Path(projection[k]).name)
projection['current100percent_included_only']=True
projectionref=add(Q/'SNAPSHOT-STATIC-EQUALITY-AND-CAPPED-ARGV.json',projection)
cfg=transform(load(OR/'FINAL-IHK-LOGGING-CHECK-CONFIG.json'));cfg.update(actual_scope=prop['scope'],actual_typed_composition=ref(A),attempt=str(attempt),effective_current_controller_stop_percent=100,future100policy_parked=False,latest_physical=physical_ref(),launch_argv=pre['owner_argv'],machine_base=baseref,machine_base_object=base,machine_index=fref,manifest=prop['normalized_manifest'],owner=ref(owner),owner_evidence=str(evidence),parent=prop['parent'],postjoin_readback=meta['postjoin_readback'],released_paths_absent=[predecessor[k] for k in ['common_exclusion','shared_heavy']],snapshot_adapter=ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),snapshot_argv=snapshot_argv,snapshot_bindings=bref,snapshot_config=bref,snapshot_equal=equal,snapshot_packet=projectionref,snapshot_projection=projectionref,stage_acceptance=ref(A),static_review=static,throughput_target=prop['native_throughput_measurement'])
cfg['module_authority']=prop['component_ABI']
cfg['component_artifact']=prop['component_artifact']
cfg['runtime_source_refs']=b['source_pins']+[ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),bref];cfg['diagnostic_extra_capture_growth_bytes']=8388608;cfg['capacity_reserve_bytes']=679477248
cfg['status']='PASS_NON_TEMPORAL_CURRENT_IHK_LOGGING_NATIVE_CHECK_CONFIG' if final else 'PENDING_INDEPENDENT_STATIC_DATA_REVIEW'
cfgref=add(Q/'FINAL-IHK-LOGGING-CHECK-CONFIG.json',cfg)
oldx=load(OQ/'FINAL-SEVEN-ROOT-CALL-DATA.json');x=transform(oldx);x['historical_template_ancestry']=oldx['historical_template_ancestry'];x.update(machine_base=baseref,non_temporal_index=iref,snapshot_projection=projectionref,final_config=cfgref,native_allowed_argv=pre['owner_argv'],snapshot_output=str(D/'root-live-preflight-1.json'),required_caller=ref(Q/'root-run-exact-readonly-stage.py'))
rows=x['steps'];rows[0]['argv_template']=snapshot_argv;rows[1]['argv_template'][-2]=baseref['sha256'];rows[1]['argv_template'][rows[1]['argv_template'].index('-c')+1]=rows[1]['argv_template'][rows[1]['argv_template'].index('-c')+1].replace("{k:base['exclusive_queue_predecessor'][k] for k in ['path','sha256']}","base['exclusive_queue_predecessor']")
rows[2]['argv_template'][rows[2]['argv_template'].index('--config-sha256')+1]=cfgref['sha256'];rows[3]['argv_template']=pre['owner_argv']
for row,actual in zip(rows[4:],meta['postjoin_readback']['argv']):
 argv=row['argv_template'];at=argv.index('/usr/bin/tar') if '/usr/bin/tar' in argv else argv.index('/usr/bin/cat');row['argv_template']=argv[:at]+actual[2:]
for k in ['stdout','stderr','status']:rows[0][k]=projection[k+'_path']
rows[0]['capture_outputs']=[rows[0]['stdout'],rows[0]['stderr'],rows[0]['status']]+[rows[0]['status']+v for v in ['.command.json','.child.json','.direct-join.json']]
parents=list(dict.fromkeys([Q/'actual-command-data']+[Path(row['status']).parent for row in rows[1:]]+[Q]))
for p in parents+[Q/'capture-templates']:
 if not p.exists():p.mkdir(parents=True,mode=0o700)
 need(p.is_dir() and stat.S_IMODE(p.stat().st_mode)==0o700,'private fresh capture parent')
x['capture_parents']=[]
for p in parents:
 st=p.stat();x['capture_parents'].append(dict(path=str(p),identity=dict(device=st.st_dev,inode=st.st_ino,uid=st.st_uid,gid=st.st_gid,mode=oct(stat.S_IMODE(st.st_mode)))))
for row,oldrow in zip(rows,oldx['steps']):
 row['caller_argv_template'][3]=str(Q/'root-run-exact-readonly-stage.py')
 template=transform(load(oldrow['template']['path']));template['operations'][1]['argv_template']=row['argv_template']
 for k in ['stdout','stderr','status']:template['operations'][1][k+'_path']=row[k]
 template['release']=static;template['root_installed_release_path']=static['path'];row['template']=add(Q/'capture-templates'/Path(oldrow['template']['path']).name,template)
x['fresh_capture_and_actual_command_paths']=[v for row in rows for v in row['capture_outputs']+[row['materialized_command_data']]];need(len(x['fresh_capture_and_actual_command_paths'])==49,'exact seven rows49 outputs')
for p in x['fresh_capture_and_actual_command_paths']:need(not os.path.lexists(p),'fresh capture absent '+p)
need(not Path(x['snapshot_output']).exists() and not Path(x['final_machine_output']).exists() and not Path(x['final_guard_output']).exists(),'no snapshot/release/guard minted')
xref=add(Q/'FINAL-SEVEN-ROOT-CALL-DATA.json',x)
executor=subst((OQ/'root-execute-seven-1.py').read_text()).replace(ref(OQ/'FINAL-SEVEN-ROOT-CALL-DATA.json')['sha256'],xref['sha256']).replace("usedPercent']<97","usedPercent']<100").replace('floor+671088640','floor+679477248').replace('current SDK66 physical c253 predecessor, buildFAIL not artifact acceptance','current HOST66 SDK physical predecessor, compile not native acceptance')
eref=add_source(Q/'root-execute-seven-1.py',executor);ast.parse(executor)
# All non-temporal authority before LAST-snapshot is bound here; only the declared
# temporal machine/snapshot hash slots are null. Pending static nulls fail closed.
packet=dict(status='BOUND_NON_TEMPORAL_PENDING_ROOT_ADMISSION' if final else 'PENDING_ONE_INDEPENDENT_SOURCE_DATA_MAPPING_REVIEW',scope='Functional OS/apps plus Rust/reviewed assembly compute cutover. Complete HOST66 module ABI/load with bounded collector readiness and ordinary VMA/app regression on unchanged accepted205; same strict20 payload; no new throughput/behavior or positive CREATE_PPD/parentclose/ACK credit. No workload by packet author.',actual_stage_acceptance=ref(A),latest_exclusive_physical=physical_ref(),module_authority=prop['component_ABI'],strict_oracles=ref(OLD.parent.parent.parent/'FROZEN-LAUNCH-ORACLE.json'),diagnostic_source_acceptance=ref(H/'current-v6-composite-native-probe-independent-review-20261020-1/COLLECTOR-DRAIN-CORRECTION1-SOURCE-AND-ACTUAL-ELEVEN-CASES-REVIEW.json'),proposal=pref,conditional_metadata=mref,machine_base=baseref,freeze=fref,bindings=bref,index=iref,projection=projectionref,final_config=cfgref,seven_rows=xref,root_executor=eref,root_caller=ref(Q/'root-run-exact-readonly-stage.py'),snapshot_source=ref(D/'root_manual_snapshot_twenty_launches_sdk.py'),final_guard_source=ref(Q/'review_final_205_release.py'),static_decision=static,full_authoritative_descriptors=True,caller_guard100included_only=True,native_runtime_authority=False,actual_guest_runs=0,diagnostic_extra_capture_growth_bytes=8388608,capacity_reserve_bytes=679477248,source_change_summary=['Exact HOST66 SDK physical schema and genuine stage/consumer contract; full authoritative descriptors; current100 included guard; same rootlock/currentUUID and648MiB diagnostic reserve','Accepted seven-row mapping/capture/executor semantics retained; current full terminal descriptor assembly equality, exact new owner/nonce/manifest/parent; only declared temporal slots late-bound','No workload/source recompilation/stage replay/new image; genuine complete HOST66 module artifact authority and separate physical retirement; accepted205 image/apps unchanged; collector bounded readiness/evidence correction independently accepted'])
packet['latest_physical_unresolved']=physical_pending
packet['actual_stage_expected_namespace']=str(stage/'manifest.json')
packet['binding_source']=ref(Path(__file__))
add(Q/'ROOT-SEVEN-REVIEW-REF-1.json',static)
packetref=add(Q/'NATIVE-COHERENT-REVIEW-PACKET.json',packet)
for path,raw in outputs.items():
 out=path if final else path.with_name(path.name+('.PENDING-PHYSICAL' if physical_pending else '.PENDING-STATIC-CORRECTED'));need(not os.path.lexists(out),'fresh one-time data binding '+str(out))
 with out.open('xb') as f:os.fchmod(f.fileno(),0o600);f.write(raw);f.flush();os.fsync(f.fileno())
print(json.dumps({'packet':packetref,'pending':not final,'outputs':len(outputs),'rows':7,'fresh_capture_paths':49,'snapshots':0,'guest_runs':0}))
