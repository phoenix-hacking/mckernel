"""Pure, exact-kind HOST66 physical receipt decoder.
No snapshot/root/guest operations. Full authoritative descriptors retained.
"""
from pathlib import Path
import hashlib,json,os
SCHEMA='mckernel.independent-current-v6-sdk.actual-physical-retirement.v1'
def need(ok,why):
 if not ok:raise ValueError(why)
def checked(r):
 compact={'path','sha256','bytes'}
 identity={'path','sha256','size','device','inode','uid','gid','mode','nlink','mtime_ns','ctime_ns'}
 need(set(r) in (compact,identity),'known full authoritative descriptor shape')
 p=Path(r['path']);need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),'canonical physical descriptor')
 before=p.stat();raw=p.read_bytes();after=p.stat()
 fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
 need(all(getattr(before,k)==getattr(after,k) for k in fields),'stable physical descriptor read')
 expected=r['bytes'] if set(r)==compact else r['size']
 need(len(raw)==expected and len(raw)<=4<<20 and hashlib.sha256(raw).hexdigest()==r['sha256'],'exact physical descriptor bytes')
 if set(r)==identity:
  actual=dict(device=after.st_dev,inode=after.st_ino,uid=after.st_uid,gid=after.st_gid,mode=oct(after.st_mode&0o7777),nlink=after.st_nlink,size=after.st_size,mtime_ns=after.st_mtime_ns,ctime_ns=after.st_ctime_ns)
  need(all(r[k]==v for k,v in actual.items()),'full actual raw record identity')
 return json.loads(raw)

def project(t,physical_ref):
 need(t==checked(physical_ref),'whole independent physical report')
 need(t['schema']==SCHEMA and t['decision']=='PASS_CURRENT_V6_PHASE4_HOST66_POSITIVE_PHYSICAL_RETIREMENT_ONLY' and t['status']=='PASS','known HOST66 SDK physical contract')
 for k in ['physical_release','retired','outer_direct_joined','outer_group_absent','container_absent','all_owned_groups_empty','current_owned_records_absent','root_development_lock_reacquired_before_owner_return']:
  need(t[k] is True,'positive physical fact '+k)
 outer=checked(t['outer_status'])
 need(outer['returncode']==0 and outer['observer_error'] is None and outer['direct_child_joined'] is True and outer['process_group_absent'] is True and t['cleanup_separately_required'] is False,'closed HOST66 outer owner')
 for k in ['module_load_acceptance','native_acceptance','production_artifact_acceptance','application_acceptance']:
  need(t[k] is False,'no runtime credit from SDK retirement '+k)
 request=checked(t['request']);owner=checked(t['owner_receipt']);post=checked(t['postflight']);archive=checked(t['ownership_archive']);release=checked(t['record_release_complete']);authorize=checked(t['record_release_authorized'])
 need(t['container_id']==owner['container_id'] and t['container_name']==owner['container_name'] and t['request_owner_nonce']==request['nonce']==owner['owner_nonce']==archive['nonce']==release['nonce'],'actual SDK request/CID/nonce')
 need(owner['request']==request and owner['status']=='PASS' and owner['retired'] is True and owner['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE' and owner['cleanup_separately_required'] is False and owner['terminal_container_retained'] is False,'actual owner cleanup receipt')
 need(owner['postflight']==post and post['all_clients_reaped'] is True and post['container_absent'] is True and post['absence']['absent'] is True,'whole owner/postflight positive absence')
 groups=post['client_group_checks']+post['admission_client_group_checks']
 need(len(groups)==t['owned_group_checks'] and all(g['empty'] is True and g['surviving_members']==[] for g in groups),'all genuine SDK owned group checks')
 unique={g['status_path'] for g in groups};need(len(unique)==t['client_count']==t['admission_clients']+t['build_clients']==owner['client_count']+owner['admission_client_count'],'derived full SDK client counts')
 evidence={row['status']['path']:row for row in t['client_statuses']};need(set(evidence)==unique and len(evidence)==len(t['client_statuses']),'complete HOST66 client evidence list')
 for path in unique:
  row=evidence[path];client=checked(row['status'])
  need(client['state']==row['state']=='exited' and client['exit_code']==row['exit_code']==0 and client['pid']==row['pid'] and all(g['pid']==client['pid'] for g in groups if g['status_path']==path),'actual SDK client status/PID/group')
 records={r['path']:r for r in archive['records']};need(len(records)==t['record_count']==3,'exact3archived SDK records')
 need(release['status']=='OWNED_RECORDS_RELEASED' and release['archive_sha256']==t['ownership_archive']['sha256'] and authorize['status']=='POSTFLIGHT_RELEASE_AUTHORIZED' and authorize['archive_sha256']==t['ownership_archive']['sha256'],'actual record release authorization/completion')
 paths=set(records);shared=paths-{request['lease_path'],request['common_exclusion_path']};need(len(shared)==1,'actual shared heavy path')
 roles={'lease':(request['lease_path'],'operation_lease'),'common':(request['common_exclusion_path'],'common_record'),'shared':(next(iter(shared)),'shared_record')}
 need(set(t['archived_record_FDs'])==set(roles),'exact raw archived3record descriptors')
 for role,(path,field) in roles.items():
  r=records[path];raw=t['archived_record_FDs'][role];value=checked(raw)
  need(raw['sha256']==r['sha256'] and raw['size']==r['size'] and value==r['record']==owner[field],'whole raw/archive/owner record '+role)
  need(any(x['path']==path and x['sha256']==r['sha256'] and x['size']==r['size'] and x['device']==r['device'] and x['inode']==r['inode'] for x in t['released_record_identities']),'released exact record identity '+role)
 need(owner['operation_lease']['nonce']==t['internal_operation_lease_nonce'],'distinct internal operation lease')
 inspect=checked(t['terminal_inspect']);terminal=inspect['State'];need(inspect['Id']==t['container_id'] and owner['terminal_container_info_current'] is True and owner['terminal_container_info'] is None,'actual HOST66 terminal descriptor/owner')
 need(terminal['Status']=='exited' and terminal['Running'] is False and terminal['Pid']==0 and terminal['ExitCode']==owner['wait_exit_code']==0 and terminal['OOMKilled'] is False,'actual SDK terminal state/wait')
 mutex=t['mutex_observation'];need(mutex['device']==27 and mutex['inode']==4 and mutex['exclusive_nonblocking_acquired_and_released'] is True and mutex['unlinked'] is False and t['live_proc_groups_and_owner_matches']==[],'genuine HOST66 mutex and live group observation')
 need(owner['common_record']['boot_id']==owner['shared_record']['boot_id'],'one genuine current boot')
 for path in paths:need(not os.path.lexists(path),'released SDK record remains absent')
 return dict(boot_id=owner['common_record']['boot_id'],filesystem_uuid='2a5768c8-718d-4914-bdc0-6b32c5a92a52',container_id=t['container_id'],owner_nonce=request['nonce'],lease_path=request['lease_path'],common_exclusion=request['common_exclusion_path'],shared_heavy=next(iter(shared)),owned_group_checks=len(groups),client_count=len(unique),build_status=owner['status'],lease_nonce=owner['operation_lease']['nonce'])
