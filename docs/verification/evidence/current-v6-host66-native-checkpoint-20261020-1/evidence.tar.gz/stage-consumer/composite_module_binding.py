"""Exact HOST66 artifact/source ABI binding; no build->native promotion."""
from pathlib import Path
import hashlib,json,stat
D=Path(__file__).resolve().parent
NAMES=('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko')
IMAGE='ff4fca457e9ffe50dc4eca930c5f91faf317eeee15bf0c2907067cffa77b23bb'
def need(ok,why):
 if not ok:raise ValueError(why)
def read(r):
 p=Path(r['path']);need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),'canonical full descriptor')
 raw=p.read_bytes();need(set(r)=={'path','sha256','bytes'} and len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],'complete authoritative descriptor drift');return raw
def validate_module_binding(base):
 b=json.loads((D/'COMPOSITE-MODULE-BINDING.json').read_bytes())
 need(b['schema']=='mckernel.HOST66-normal-ABI-module-binding.v1','explicit HOST66 binding')
 need(base['artifacts']['mckernel_image']['sha256']==IMAGE and base['modules']==b['modules'],'unchanged205 image and complete HOST66 tuple')
 need(tuple(Path(r['path']).name for r in b['modules'])==NAMES,'exact three module names/order')
 a=json.loads(read(b['actual_artifact_review']));p=json.loads(read(b['actual_physical_review']));receipt=json.loads(read(b['compiler_receipt']));request=json.loads(read(b['request']))
 need(a['schema']=='mckernel.independent-phase4-host-sdk.actual-three-module-artifact-review.v1' and a['status']=='PASS_BUILD_ARTIFACTS_ONLY_NO_ACTIVATION' and a['decision']=='ACCEPT_ACTUAL_CURRENT_V6_PHASE4_HOST66_THREE_MODULE_SOURCE_FFI_AND_CONTROL_EXPORT_LINK_ARTIFACTS_ONLY','exact HOST66 artifact kind')
 need(p['schema']=='mckernel.independent-current-v6-sdk.actual-physical-retirement.v1' and p['status']=='PASS' and p['decision']=='PASS_CURRENT_V6_PHASE4_HOST66_POSITIVE_PHYSICAL_RETIREMENT_ONLY','exact HOST66 physical kind')
 for key in ('physical_release','retired','container_absent','all_owned_groups_empty','current_owned_records_absent','outer_direct_joined','outer_group_absent','root_development_lock_reacquired_before_owner_return'):need(p[key] is True,'positive physical fact '+key)
 for key in ('ACK_acceptance','application_acceptance','native_acceptance','default_consumer_acceptance','production_acceptance'):need(a[key] is False,'no build activation credit '+key)
 need(a['actual_request']==p['request']==b['request'] and a['compiler_receipt']==b['compiler_receipt'] and a['physical_retirement_review']==b['actual_physical_review'],'complete report/request/receipt/physical joins')
 need(a['counts']['sources']==66 and a['counts']['modules']==3 and receipt['status']=='BUILD_ARTIFACT_CHECKS_PASS' and receipt['make_returncode']==0,'actual66 source/3module compiler')
 need(a['source_identity']==receipt['source_candidate_sha']==b['source_identity'] and a['artifacts']==receipt['artifacts'],'exact source and complete artifact map')
 for r in b['modules']:
  f=Path(r['path']);s=f.stat();name=f.stem;row=a['artifacts'][name]
  need(f==Path(request['candidate_root'])/'modules'/(name+'.ko') and stat.S_ISREG(s.st_mode) and s.st_mode==r['mode'] and s.st_size==r['size']==row['bytes'],'actual module path/type/mode/size')
  need(hashlib.sha256(f.read_bytes()).hexdigest()==r['sha256']==row['sha256'],'actual module hash')
  need(row['modinfo']['vermagic']=='6.12.0-211.44.1.el10_2.mckernel1.x86_64 SMP preempt mod_unload ','accepted Linux SDK release')
 prior=json.loads(read(b['prior_ordinary_abi_review']))
 for name,sha in b['unchanged_ordinary_abi'].items():need(prior['public_source_ABI_unchanged'][name]==receipt['source_sha256'][name]==sha,'unchanged public ABI '+name)
 ad=b['additive_application_abi'];old=read(ad['old']);new=read(ad['new']);pos=ad['offset']
 need(new==old[:pos]+bytes.fromhex(ad['insertion_hex'])+old[pos:]+bytes.fromhex(ad['suffix_hex']),'existing ordinary ABI definitions preserved exactly')
 need(ad['old']['sha256']==prior['public_source_ABI_unchanged']['abi/application.rs'] and ad['new']['sha256']==receipt['source_sha256']['abi/application.rs'],'compiled ABI source identity')
