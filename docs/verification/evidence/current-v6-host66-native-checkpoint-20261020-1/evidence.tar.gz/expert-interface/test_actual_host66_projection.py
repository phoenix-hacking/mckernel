"""Read genuine full HOST66 authority; negative controls alter private metadata only."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import os

HERE = Path(__file__).resolve().parent
ACTUAL = Path('/home/holden/mckernel-work/host-preparation/phase4-host-sdk-independent-review-20261020-1/HOST66-ACTUAL-PHYSICAL-RETIREMENT-REVIEW.json')
SHA = 'a6614e9c584912790423266097f898badfe4014a6c82a13a0ea0004b5c366672'
OUT = HERE / 'actual-check-1'


def ref(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def write_metadata(name, value):
    path = OUT / name
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
    return ref(path)


def main():
    OUT.mkdir(mode=0o700)
    spec = importlib.util.spec_from_file_location('candidate', HERE / 'sdk_physical_projection.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    original_ref = ref(ACTUAL)
    assert original_ref['sha256'] == SHA and original_ref['bytes'] == 26946
    original = json.loads(ACTUAL.read_bytes())
    result = module.project(original, original_ref)
    expected = {'boot_id', 'filesystem_uuid', 'container_id', 'owner_nonce', 'lease_path',
                'common_exclusion', 'shared_heavy', 'owned_group_checks', 'client_count',
                'build_status', 'lease_nonce'}
    assert set(result) == expected
    assert result['owned_group_checks'] == 42 and result['client_count'] == 15
    assert result['build_status'] == 'PASS'
    assert result['filesystem_uuid'] == '2a5768c8-718d-4914-bdc0-6b32c5a92a52'
    assert result['owner_nonce'] == original['request_owner_nonce']
    assert all(not os.path.lexists(result[k]) for k in ('lease_path', 'common_exclusion', 'shared_heavy'))
    outcomes = [dict(case='complete-genuine-HOST66', status='PASS', record_count=3,
                     client_count=15, group_checks=42)]

    def reject(name, changed, expected_error, predicate):
        changed_ref = write_metadata(name + '.json', changed)
        try:
            module.project(changed, changed_ref)
        except expected_error as error:
            assert predicate in str(error), (name, str(error))
            outcomes.append(dict(case=name, status='REJECTED', predicate=predicate))
        else:
            raise AssertionError('negative control accepted: ' + name)

    changed = copy.deepcopy(original)
    changed['archived_record_FDs']['lease']['inode'] += 1
    reject('changed-raw-copy-inode', changed, ValueError, 'full actual raw record identity')

    changed = copy.deepcopy(original)
    authorized = json.loads(Path(original['record_release_authorized']['path']).read_bytes())
    authorized['records'][0]['inode'] += 1
    changed['record_release_authorized'] = write_metadata('changed-authorization.json', authorized)
    reject('changed-authorized-original-inode', changed, ValueError,
           'authorized exact original record identities')

    changed = copy.deepcopy(original)
    del changed['record_release_complete']
    reject('missing-positive-release-completion', changed, KeyError, 'record_release_complete')

    changed = copy.deepcopy(original)
    owner = json.loads(Path(original['owner_receipt']['path']).read_bytes())
    owner['retired'] = False
    changed['owner_receipt'] = write_metadata('unretired-owner.json', owner)
    reject('owner-not-retired', changed, ValueError, 'actual owner cleanup receipt')

    summary = dict(status='PASS', candidate=ref(HERE / 'sdk_physical_projection.py'),
                   actual=original_ref, tests=outcomes, positive=1, rejected_controls=4,
                   actual_root_commands=0, actual_compilers=0, actual_guest_runs=0)
    write_metadata('result.json', summary)
    print(json.dumps({'status': 'PASS', 'positive': 1, 'rejected_controls': 4,
                      'record_count': 3, 'client_count': 15, 'group_checks': 42,
                      'predicates': [x.get('predicate') for x in outcomes[1:]]}, sort_keys=True))


if __name__ == '__main__':
    main()
