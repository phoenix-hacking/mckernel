Private expert correction: functional OS/apps and active compute-C retirement into Rust/reviewed assembly. No execution authority.

Preserved failures: native-metadata-check-1 rejected genuine 11-field raw descriptors; check-2 guessed old64 released_record_identities absent from genuine HOST66. No shared files changed.

Complete genuine HOST66 is pinned by SHA a6614e9c584912790423266097f898badfe4014a6c82a13a0ea0004b5c366672, 26946 bytes. Candidate binds authorization.records exactly to archive.records and the archive request/postflight ancestry; nonce/archive hash/status link authorization and completion. Raw file copy identity remains a separate full11-field check. Stable FD before/after/final-path identity and bounded regular-file reading preserve exact bytes and ownership observations. No PID absence substitutes for positive retirement. Returned caller contract unchanged.

Ordinary tests await root CPU7/1job/1GiB/55CPU/60wall/32MiB grant. No compiler/root/Docker/guest/staging/cleanup.

Granted execution-1 completed: rc0, direct child joined, process group absent, CPU7 released, 0.064870595 seconds, stdout274 bytes/stderr0. Full genuine report passed with 3records/15clients/42group checks. Four private metadata controls rejected at specific identity/release/owner predicates; unchanged protected evidence was read only. Result: actual-check-1/result.json. Whole command/status/streams: execution-1/. Candidate SHA f78ebae768b62395844aa6714b871075d32d8742c1f838df746a11bd76b832df (8613B), unchanged after the run. Independent affected review requested from /root/resume20_physical. Integration remains the parent/medium author's responsibility; no runtime authority is granted here.
