/candidate/modules/.mcctrl_rust.o.d: /candidate/modules/mcctrl_rust.rs /candidate/modules/mcctrl_exec.rs /candidate/modules/mcctrl_process.rs /candidate/modules/current_fork_host.rs /candidate/modules/mcctrl_vm.rs /candidate/modules/user_string.rs /candidate/modules/application_image.rs /candidate/modules/abi/x86_64.rs /candidate/modules/abi/os_service.rs /candidate/modules/abi/application.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/candidate/modules/mcctrl_rust.o: /candidate/modules/mcctrl_rust.rs /candidate/modules/mcctrl_exec.rs /candidate/modules/mcctrl_process.rs /candidate/modules/current_fork_host.rs /candidate/modules/mcctrl_vm.rs /candidate/modules/user_string.rs /candidate/modules/application_image.rs /candidate/modules/abi/x86_64.rs /candidate/modules/abi/os_service.rs /candidate/modules/abi/application.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/candidate/modules/mcctrl_rust.rs:
/candidate/modules/mcctrl_exec.rs:
/candidate/modules/mcctrl_process.rs:
/candidate/modules/current_fork_host.rs:
/candidate/modules/mcctrl_vm.rs:
/candidate/modules/user_string.rs:
/candidate/modules/application_image.rs:
/candidate/modules/abi/x86_64.rs:
/candidate/modules/abi/os_service.rs:
/candidate/modules/abi/application.rs:
./rust/libcore.rmeta:
./rust/libkernel.rmeta:
./rust/liballoc.rmeta:
./rust/libcompiler_builtins.rmeta:
./rust/libmacros.so:
./rust/libbindings.rmeta:
./rust/libuapi.rmeta:
./rust/libbuild_error.rmeta:
