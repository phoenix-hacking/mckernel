#!/usr/bin/env python3
"""Hold the development lock around the unchanged authority3 image owner."""
import argparse
import importlib.util
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

sys.path.insert(0, '/home/holden/mckernel-work/scratch/native-fp-copy-image-preparation-20261018-1/preparation-commands-1/request-schema-correction-1/adapters')
sys.path.insert(0, '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters')

# Import the entire exact current private owner, including its authenticated
# private host owner/provenance. Never resolve the retired settid owner by name.
_CURRENT_OWNER = Path('/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/native_rust_exact_mckernel_image_container_owner.py')
if hashlib.sha256(_CURRENT_OWNER.read_bytes()).hexdigest() != '3c6f79631ad7de19ed15e40eb87c4426150bc904b4b9379fa3fadba10c7edf28':
    raise RuntimeError('current private image owner hash differs')
_spec = importlib.util.spec_from_file_location('native_rust_exact_mckernel_image_container_owner', str(_CURRENT_OWNER))
image = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = image
_spec.loader.exec_module(image)
CliSignals, Docker = image._HOST_OWNER.CliSignals, image._HOST_OWNER.Docker
digest, inspect = image._HOST_OWNER.digest, image._HOST_OWNER.inspect
# Bind helper transitive imports to this same authenticated private runtime.
sys.modules['native_rust_exact_build_container_owner'] = image._HOST_OWNER
sys.modules['native_rust_exact_build_offline'] = image._HOST_OWNER.provenance
from native_rust_exact_build_image_rebind_probe import (
    _development_lock, _read_json_snapshot, _write_json, DEFERRED_SIGNALS,
    DEVELOPMENT_LOCK, DEVELOPMENT_LOCK_IDENTITY, quarantine_root_lock,
)

REPO = Path('/home/holden/mckernel')
ROOT = Path('/home/holden/mckernel-work/scratch')
CANDIDATE = '942c927b1ec93cc31284ff498455909d9bb2d0fc'
UUID = '2a5768c8-718d-4914-bdc0-6b32c5a92a52'
SELF = '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/guest-runtime-admission-preparation-2/native_exact_current_optin_image_guard.py'
TEST = '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/affinity-full-syscall-include-correction-1/fresh-full-attempt-1/heavy-proposal-1/test_fresh_full_metadata_joins.py'
SOURCES = ('/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/guest-runtime-admission-preparation-2/native_exact_current_optin_image_guard.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/affinity-full-syscall-include-correction-1/fresh-full-attempt-1/heavy-proposal-1/test_fresh_full_metadata_joins.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_build_container_owner.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_build_image_prepare.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_build_image_rebind.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_build_image_rebind_probe.py', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/native_rust_exact_build_offline.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_disk_build_wrapper.py', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/native_rust_exact_mckernel_image_container_owner.py', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/native_rust_exact_mckernel_image_offline.py', '/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_mckernel_image_request_prepare.py')


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def mount_records(value):
    """Docker may reorder Mounts; preserve every complete record and count."""
    if not isinstance(value, list) or any(not isinstance(row, dict) for row in value):
        raise RuntimeError('fresh exact stopped image container has invalid mounts')
    destinations = [row.get('Destination') for row in value]
    if (any(not isinstance(path, str) or not path.startswith('/') for path in destinations) or
            len(set(destinations)) != len(destinations)):
        raise RuntimeError('fresh exact stopped image container has ambiguous mounts')
    return sorted(canonical(row) for row in value)


def bound(pointer):
    if not re.fullmatch('[0-9a-f]{64}', str(pointer.get('sha256', ''))):
        raise RuntimeError('exact external SHA256 required')
    return _read_json_snapshot(pointer['path'], 'bound image guard input', pointer['sha256'])[0]


SOURCE_REF = None
GATES_REF = None
RESULT_REF = {'path': '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/WHOLE-ACTUAL-SOURCE-VALIDATOR-RESULT.json', 'bytes': 1166, 'sha256': 'd4007e89ffe5d0a3794b18af511020d0f1ffc91e8a80dcc0d469e5252b5b409e'}
VALIDATOR_CAPTURE_REF = None
MATERIAL_CAPTURE_REF = None
RECEIPT_REF = {'path': '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/source-materialization-1/materialization-receipt.json', 'bytes': 501, 'sha256': '1db0d4169a803d4996b4ac4ebd193779f372961d3fd354ecdc45a7d24e78f413'}

# Deliberately unresolved. Only bind_guard_source.py may fill these two exact
# externally reviewed references; None can never authorize even source admission.
BINDINGS = {'runtime_ref': None, 'basis_ref': None}


def require_actual_ordinary(request, request_sha, release, ordinary, acceptance, identity):
    """Genuine new6959 receipt and whole source gates; no compile/image acceptance."""
    if not isinstance(BINDINGS, dict) or set(BINDINGS) != {'runtime_ref', 'basis_ref'}:
        raise RuntimeError('new runtime review and source-bound request remain unbound')
    source_ref = SOURCE_REF
    gates_ref = GATES_REF
    runtime_ref, basis_ref = BINDINGS['runtime_ref'], BINDINGS['basis_ref']
    if (release.get('source_materialization_acceptance') != source_ref or
            release.get('whole_source_gate_acceptance') != gates_ref or
            release.get('runtime_binding_acceptance') != runtime_ref or
            release.get('bound_request_basis') != basis_ref):
        raise RuntimeError('exact new source/whole-gate/runtime/request authority required')
    source, gates, runtime = bound(source_ref), bound(gates_ref), bound(runtime_ref)
    if (acceptance != gates or
            source.get('status') != 'PASS_ACTUAL6959_PRIVATE_SOURCE_RECEIPT_JOURNAL_CLOSED_CAPTURE_ONLY' or
            gates.get('schema') != 'mckernel.root-recorded-independent-whole-source-gate-acceptance.v1' or
            gates.get('status') != 'PASS_WHOLE_OWNED_VALIDATOR_AND_ACTUAL_AFFINITY_SOURCE_GATES_ONLY' or
            gates.get('actual_source_acceptance') != source_ref or
            gates.get('result') != RESULT_REF or gates.get('closed_capture') != VALIDATOR_CAPTURE_REF or
            runtime.get('status') != 'PASS_EXACT_FULL_RUNTIME_ADAPTER_OWNER_AND_REQUEST_BINDINGS_ONLY' or
            runtime.get('implementation_ownership') is not False or not runtime.get('reviewer') or
            runtime.get('reviewed_request_proposal') != basis_ref or
            runtime.get('actual_source_materialization_acceptance') != source_ref or
            runtime.get('actual_coupled_source_gate_acceptance') != gates_ref):
        raise RuntimeError('genuine independent new source/runtime review differs')
    if (release.get('ordinary_result_acceptance') != gates_ref or
            release.get('prerequisites', {}).get('ordinary') != VALIDATOR_CAPTURE_REF or
            ordinary != bound(VALIDATOR_CAPTURE_REF)):
        raise RuntimeError('actual whole-validator closed result required')
    receipt = bound(source['receipt'])
    if (source.get('receipt') != RECEIPT_REF or source.get('closed_capture') != MATERIAL_CAPTURE_REF or
            receipt.get('status') != 'PASS_SOURCE_MATERIALIZATION_ONLY' or
            receipt.get('source') != request.get('source_root') or
            source.get('source_entries') != 6959 or receipt.get('source_entries') != 6959 or
            source.get('tracked_symlinks') != 49 or receipt.get('tracked_symlinks') != 49 or
            source.get('regular_files') != 6910 or receipt.get('regular_files') != 6910):
        raise RuntimeError('exact new source receipt/counts/path differ')
    for key in ('source_derivative_sha256', 'materialization_sha256'):
        if not (source.get(key) == receipt.get(key) == gates.get(key) == request.get(key)):
            raise RuntimeError('reviewed new source derivation/materialization differs')
    accepted = source['source_identity']
    expected_identity = {'path': receipt['source'], 'dev': accepted['device'],
        'inode': accepted['inode'], 'uid': accepted['uid'], 'gid': accepted['gid'],
        'mode': int(accepted['mode'], 8), 'file_type': 16384}
    if (gates.get('source_identity') != accepted or request.get('source_identity') != expected_identity or
            [expected_identity[k] for k in ('dev', 'inode', 'uid', 'gid', 'mode')] != identity):
        raise RuntimeError('actual new source identity differs')
    result = bound(RESULT_REF)
    if (result.get('status') != gates['status'] or result.get('same_current_source') != receipt['source'] or
            any(result.get(k) is not True for k in ('whole_owned_current_positive',
                'whole_owned_genuine_old_pin_refusal', 'whole_affinity_current_source_gates_completed',
                'whole_affinity_genuine_old_pin_refusal', 'entire_modules_imported')) or
            any(result.get(k) is not False for k in ('whole_affinity_function_PASS',
                'whole_affinity_compiler_output_acceptance', 'function_extraction_or_monkeypatch_or_stubs',
                'compiler_root_Docker_lock_lease_materialization'))):
        raise RuntimeError('actual whole source-only validator observations differ')
    # Journal and both actual single-command captures are authenticated by their
    # independently accepted exact references; no synthetic two-command schema.
    journal = source['journal']
    journal_raw = Path(journal['path']).read_bytes()
    if len(journal_raw) != journal['bytes'] or hashlib.sha256(journal_raw).hexdigest() != journal['sha256']:
        raise RuntimeError('actual materialization journal drift')
    for row in (bound(MATERIAL_CAPTURE_REF), ordinary):
        if (row.get('returncode') != 0 or row.get('direct_child_joined') is not True or
                row.get('group_absent') is not True or row.get('closed_streams') is not True or
                row.get('timed_out') is not False or row.get('remaining_group_members') != [] or
                row.get('unexpected_group_members') != [] or row.get('error') is not None or
                row.get('retirement_error') is not None):
            raise RuntimeError('actual source/validator directjoin retirement differs')
        if set(row.get('captures', {})) != {'stdout', 'stderr'}:
            raise RuntimeError('actual source/validator streams differ')
        for stream in row['captures'].values():
            raw = Path(stream['path']).read_bytes()
            if len(raw) != stream['size'] or hashlib.sha256(raw).hexdigest() != stream['sha256']:
                raise RuntimeError('actual source/validator closed capture drift')
    basis = bound(basis_ref)
    # Preserve original finite late backup/device identity boundary.
    expected = dict(basis)
    expected['backup_identity'] = request.get('backup_identity')
    expected['disk_admission'] = dict(basis['disk_admission'])
    for key in ('host_device', 'scratch_device'):
        expected['disk_admission'][key] = request['disk_admission'].get(key)
    if request != expected:
        raise RuntimeError('current request changed outside exact late identity fields')


def authenticate(request_path, request_sha, release_path, release_sha):
    release = bound({'path': str(release_path), 'sha256': release_sha})
    request = bound({'path': str(request_path), 'sha256': request_sha})
    if (os.geteuid() != 1000 or release.get('schema') != 'fp-save-thin.image-guard-release.v1' or
            release.get('status') != 'PASS_EXECUTION_RELEASE' or
            type(release.get('execution_count')) is not int or release['execution_count'] != 1 or
            release.get('request') != {'path': str(request_path), 'sha256': request_sha} or
            request.get('candidate_sha') != CANDIDATE or
            request.get('candidate_identity_scope') != 'base_git_commit_only' or
            request.get('source_derivative_sha256') != '5cffcc1b23dc5ca377baa055aab0417b0daac7ddcac0e2281903260f0ebd79e3' or
            release.get('source_derivative_sha256') != request.get('source_derivative_sha256') or
            request.get('materialization_sha256') != 'd7e24b4c0d3174b3479e33796d712d439444bae82902482448890b9d8142d43d' or
            release.get('boot_id') != Path('/proc/sys/kernel/random/boot_id').read_text().strip() or
            release.get('scratch_binding') != {'uuid': UUID, 'device': ROOT.stat().st_dev}):
        raise RuntimeError('fresh exact authority3 image release required')
    review = bound(release['execution_review'])
    payload = {key: value for key, value in release.items() if key != 'execution_review'}
    if (review.get('decision') != 'PASS_EXECUTION' or review.get('implementation_ownership') is not False or
            not review.get('reviewer') or not release.get('author') or review['reviewer'] == release['author'] or
            review.get('reviewed_release_payload_sha256') != hashlib.sha256(canonical(payload)).hexdigest()):
        raise RuntimeError('independent exact release review required')
    if set(release.get('source_sha256', {})) != set(SOURCES):
        raise RuntimeError('exact guard source closure required')
    for name in SOURCES:
        if digest(REPO / name) != release['source_sha256'][name]:
            raise RuntimeError('guard source drift: ' + name)
    for key, status in (('preparation', 'PASS'), ('cleanup', 'PASS_EXECUTED'),
                        ('native_baseline', 'PASS_DIAGNOSTIC_REVALIDATION'), ('ordinary', None)):
        prerequisite = bound(release['prerequisites'][key])
        if key!='ordinary' and prerequisite.get('status') != status:
            raise RuntimeError('unaccepted image prerequisite: ' + key)
        if key == 'preparation' and (prerequisite.get('candidate_sha') != CANDIDATE or
                                    prerequisite.get('image_id') != request['image_id']):
            raise RuntimeError('tool preparation candidate/image differs')
    ordinary=bound(release['prerequisites']['ordinary'])
    acceptance=bound(release['ordinary_result_acceptance'])
    source_stat=os.lstat(request['source_root'])
    identity=[source_stat.st_dev,source_stat.st_ino,source_stat.st_uid,source_stat.st_gid,source_stat.st_mode&4095]
    require_actual_ordinary(request,request_sha,release,ordinary,acceptance,identity)
    mounted = subprocess.run(['/usr/bin/findmnt', '--json', '--output', 'UUID,MAJ:MIN,TARGET',
                              '--target', str(ROOT)], capture_output=True, text=True,
                             timeout=30, check=True)
    rows = json.loads(mounted.stdout)['filesystems']; device = ROOT.stat().st_dev
    if (len(rows) != 1 or rows[0] != {'uuid': UUID, 'maj:min': '%d:%d' %
            (os.major(device), os.minor(device)), 'target': str(ROOT)}):
        raise RuntimeError('live scratch UUID/device differs')
    capture = Path(release['guard_capture'])
    nonce = release.get('nonce', '')
    if (not re.fullmatch('[0-9a-f]{32}', str(nonce)) or capture.parent != ROOT or
            not capture.name.startswith('native-rust-phase5-current-optin-image-guard-') or
            not capture.name.endswith(nonce) or os.path.lexists(capture)):
        raise RuntimeError('fresh nonce-bound guard capture required')
    return request, release


def prove_retired(request, result, docker, capture):
    receipt_path = Path(request['owner_evidence_root']) / image.OWNER_RECEIPT_NAME
    recorded, receipt_sha = _read_json_snapshot(receipt_path, 'actual image owner receipt')
    if (recorded != result or result.get('retired') is not True or
            result.get('terminal_container_retained') is not True or
            result.get('cleanup_separately_required') is not True or
            result.get('client_retirement_unproven', False) or docker.client_retirement_unproven or
            os.path.lexists(request['lease_path'])):
        raise RuntimeError('image owner retirement/publication is unproven')
    shared = result['shared_heavy_operation']
    if shared['path'] != image._SHARED_HEAVY_ENTRY_CONTRACT.SHARED_HEAVY_LOCK_PATH:
        raise RuntimeError('shared image ownership path differs')
    common_path = Path(request['common_exclusion_path'])
    common, common_sha = _read_json_snapshot(common_path, 'retained common record')
    stored, shared_sha = _read_json_snapshot(shared['path'], 'retained shared record')
    meta, shared_meta = common_path.stat(), Path(shared['path']).stat()
    if (stored != shared['record'] or (shared_meta.st_dev, shared_meta.st_ino) !=
            (stored['device'], stored['inode']) or
            (meta.st_dev, meta.st_ino) != (common['dev'], common['inode']) or
            common['request_sha256'] != hashlib.sha256(json.dumps(request, sort_keys=True).encode()).hexdigest() or
            common['pid'] != os.getpid() or common['boot_id'] != Path(
                '/proc/sys/kernel/random/boot_id').read_text().strip() or
            common['starttime'] != image._proc_starttime(os.getpid())):
        raise RuntimeError('retained image ownership records differ')
    name = result['container_name']
    if not re.fullmatch('mckernel-image-[0-9a-f]{32}', str(name)):
        raise RuntimeError('exact image container name missing')
    fresh = inspect(docker, name)
    old = result['terminal_container_info']
    state, config, host = fresh['State'], fresh['Config'], fresh['HostConfig']
    if (not re.fullmatch('[0-9a-f]{64}', str(result.get('container_id', ''))) or
            fresh.get('Id') != result['container_id'] or fresh.get('Id') != old.get('Id') or
            fresh.get('Name') != '/' + result['container_name'] or
            fresh.get('Image') != request['image_id'] or
            config.get('Labels', {}).get('mckernel.owner') != result['owner_nonce'] or
            state.get('Running') is not False or state.get('Pid') != 0 or
            state.get('Status') not in ('exited', 'created') or state.get('OOMKilled') is not False or
            any(fresh.get(key) != old.get(key) for key in ('HostConfig', 'Config')) or
            mount_records(fresh.get('Mounts')) != mount_records(old.get('Mounts')) or
            any(host.get(key) != value for key, value in image.LIMITS.items()) or
            host.get('Privileged') is not False or host.get('ReadonlyRootfs') is not True or
            host.get('CapDrop') != ['ALL'] or host.get('SecurityOpt') != ['no-new-privileges'] or
            host.get('Init') is not True or host.get('IpcMode') != 'private' or
            host.get('PidMode', '') != '' or host.get('Devices') or host.get('DeviceRequests') or
            host.get('Binds') or host.get('CapAdd') or host.get('CgroupParent', '') != '' or
            config.get('User') != '%d:%d' % (os.getuid(), os.getgid()) or
            docker.client_retirement_unproven):
        raise RuntimeError('fresh exact stopped image container is unproven')
    image._check_identity(Path(request['source_root']), request['source_identity'], 'retained source')
    image._check_identity(Path(request['backup_root']), request['backup_identity'], 'retained backup')
    _read_json_snapshot(common_path, 'retained common record after inspection', common_sha)
    _read_json_snapshot(shared['path'], 'retained shared record after inspection', shared_sha)
    if (os.path.lexists(request['lease_path']) or
            (common_path.stat().st_dev, common_path.stat().st_ino) != (meta.st_dev, meta.st_ino) or
            (Path(shared['path']).stat().st_dev, Path(shared['path']).stat().st_ino) !=
            (shared_meta.st_dev, shared_meta.st_ino)):
        raise RuntimeError('ownership identities changed during inspection')
    _write_json(capture / 'inspect-terminal-fresh.json', fresh)
    return {'owner_status': result['status'], 'owner_receipt_sha256': receipt_sha,
            'container_id': fresh['Id'], 'retired': True, 'retained_for_separate_cleanup': True}


def guarded_execute(request_path, request_sha, release_path, release_sha,
                    lock_path=DEVELOPMENT_LOCK, lock_identity=DEVELOPMENT_LOCK_IDENTITY,
                    lock_owner=(0, 0)):
    if digest(request_path) != request_sha:
        raise RuntimeError('deterministic preflight request hash differs')
    image.preflight_request_crossrefs(_read_json_snapshot(request_path, 'preflight request')[0])
    mask = signal.pthread_sigmask(signal.SIG_BLOCK, DEFERRED_SIGNALS)
    handlers = {number: signal.getsignal(number) for number in DEFERRED_SIGNALS}
    latch = CliSignals()
    fd = None
    entered = core_entered = safe = False
    try:
        latch.__enter__(); entered = True
        for number in DEFERRED_SIGNALS:
            signal.signal(number, latch.receive)
        signal.pthread_sigmask(signal.SIG_SETMASK, mask)
        fd = _development_lock(lock_path, lock_identity, lock_owner)
        latch.check()
        request, release = authenticate(request_path, request_sha, release_path, release_sha)
        capture = Path(release['guard_capture']); capture.mkdir(mode=0o700)
        _write_json(capture / 'consumed-release.json', {'release_sha256': release_sha,
                    'request_sha256': request_sha, 'nonce': release['nonce']})
        docker = Docker(capture / 'docker.log', signals=latch, sudo=True)
        core_entered = True
        result = image.ImageOwner(request, docker=docker, signals=latch).run()
        proof = prove_retired(request, result, docker, capture)
        proof['interrupted_signal'] = latch.requested
        _write_json(capture / 'guard-result.json', proof)
        if _read_json_snapshot(capture / 'guard-result.json', 'published guard proof')[0] != proof:
            raise RuntimeError('guard proof publication differs')
        _development_lock(lock_path, lock_identity, lock_owner, held_fd=fd)
        safe = True
        return proof
    except BaseException as exc:
        try:
            _write_json(Path(str(release_path) + '.pre-quarantine-exception.json'),
                        {'status': 'CURRENT_IMAGE_GUARD_EXCEPTION', 'pid': os.getpid(),
                         'exception_type': type(exc).__name__[:256],
                         'message': str(exc)[:4096], 'entered': entered,
                         'core_entered': core_entered, 'retirement_proved': safe})
        except BaseException:
            pass
        raise
    finally:
        if fd is not None:
            if core_entered and not safe:
                quarantine_root_lock(fd, release_path)
            fcntl.flock(fd, fcntl.LOCK_UN); os.close(fd)
        signal.pthread_sigmask(signal.SIG_BLOCK, DEFERRED_SIGNALS)
        if entered:
            latch.__exit__(None, None, None)
        for number, handler in handlers.items():
            signal.signal(number, handler)
        signal.pthread_sigmask(signal.SIG_SETMASK, mask)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('request', 'request-sha256', 'release', 'release-sha256'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args(argv)
    proof = guarded_execute(Path(args.request), args.request_sha256,
                            Path(args.release), args.release_sha256)
    print(json.dumps(proof, sort_keys=True))
    return 0 if proof['owner_status'] == 'PASS' and proof['interrupted_signal'] is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
