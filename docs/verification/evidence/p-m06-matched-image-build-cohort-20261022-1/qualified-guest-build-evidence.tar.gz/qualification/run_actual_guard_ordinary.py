from pathlib import Path
import json,os,signal,subprocess,time
O=Path(__file__).resolve().parent;D=O/'actual-guard-ordinary-capture-1';D.mkdir(mode=0o700)
assert os.sched_getaffinity(0)=={6}
argv=['/home/holden/anaconda3/bin/python3','-I','-B',str(O/'check_actual_guard_ordinary.py')]
def put(n,v):
    with (D/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
start=time.monotonic()
with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=O,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1'},stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 ident={'pid':p.pid,'start_ticks':Path('/proc/'+str(p.pid)+'/stat').read_text().rsplit(')',1)[1].split()[19]};put('child.json',{'argv':argv,'identity':ident,'process_group':p.pid});timeout=False
 while os.waitid(os.P_PID,p.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
  if time.monotonic()-start>=27:timeout=True;break
  time.sleep(.02)
 try:os.killpg(p.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 rc=p.wait(timeout=1)
try:os.killpg(p.pid,0);absent=False
except ProcessLookupError:absent=True
status={'argv':argv,'identity':ident,'returncode':rc,'direct_child_joined':True,'process_group_absent':absent,'timed_out':timeout,'closed_streams':True,'elapsed_seconds':time.monotonic()-start,'stdout_bytes':(D/'stdout').stat().st_size,'stderr_bytes':(D/'stderr').stat().st_size,'profile':{'cpu':[6],'AS_bytes':512<<20,'CPU_seconds':30,'wall_seconds':30,'output_bytes':8<<20}}
put('status.json',status);assert rc==0 and absent and not timeout;print(json.dumps(status))
