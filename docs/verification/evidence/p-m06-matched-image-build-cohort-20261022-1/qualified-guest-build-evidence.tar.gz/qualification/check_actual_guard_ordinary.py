from pathlib import Path
import hashlib,importlib.util,json,os,sys
O=Path(__file__).resolve().parent
assert os.sched_getaffinity(0)=={6} and sys.dont_write_bytecode
p=O/'native_exact_current_optin_image_guard.py'
spec=importlib.util.spec_from_file_location('_actual_matched_guest_guard_qualification',str(p));guard=importlib.util.module_from_spec(spec);sys.modules[spec.name]=guard;spec.loader.exec_module(guard)
inputs=json.loads((O/'ORDINARY-QUALIFICATION-INPUTS.json').read_bytes())
request=json.loads((O/'image-request.FINAL.json').read_bytes())
release={'source_materialization_acceptance':guard.SOURCE_REF,'whole_source_gate_acceptance':guard.GATES_REF,'runtime_binding_acceptance':guard.BINDINGS['runtime_ref'],'bound_request_basis':guard.BINDINGS['basis_ref'],'ordinary_result_acceptance':guard.GATES_REF,'prerequisites':{'ordinary':guard.VALIDATOR_CAPTURE_REF}}
ordinary=guard.bound(guard.VALIDATOR_CAPTURE_REF);acceptance=guard.bound(guard.GATES_REF)
root=json.loads((O/'ROOT-ORDINARY-IDENTITIES-AND-CAPACITY-1.json').read_bytes());identity=[root['source_identity'][k] for k in ['dev','inode','uid','gid','mode']]
assert request['source_identity']==root['source_identity'] and request['disk_identity']==root['disk_identity']
request_sha=hashlib.sha256((O/'image-request.FINAL.json').read_bytes()).hexdigest()
guard.require_actual_ordinary(request,request_sha,release,ordinary,acceptance,identity)
static=guard.image.preflight_request_crossrefs(request)
assert static['status']=='PASS_DETERMINISTIC_REQUEST_CROSSREFS_ONLY'
stale=dict(release);stale['whole_source_gate_acceptance']=dict(guard.GATES_REF,sha256='0'*64)
try:guard.require_actual_ordinary(request,request_sha,stale,ordinary,acceptance,identity)
except RuntimeError as e:assert str(e)=='exact new source/whole-gate/runtime/request authority required';refusal=str(e)
else:raise AssertionError('stale-gate-ref accepted')
result={'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','status':'PASS_ACTUAL_GUARD_ORDINARY_QUALIFIED_PROJECTIONS_AND_STATIC_CROSSREFS_ONLY','actual_entire_guard_module_imported':True,'actual_require_actual_ordinary_positive':True,'actual_outer_static_crossrefs':static,'actual_stale_reference_refusal':refusal,'source_hash_or_original_test_runs_repeated':False,'capture_projection_inferences_explicit':True,'additive_basis_schema':'exacthashboundbase + exactsource/diskidentitysnapshot only; allotherrequestguardsunchanged','root_ordinary_snapshot':inputs['root_ordinary_identity_snapshot'],'root_runtime_admission':False,'fresh_resource_release_or_compiler_guest_operations':False,'guard_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'request_sha256':request_sha,'positive_count':2,'stale_ref_refusals':1}
with (O/'ACTUAL-GUARD-ORDINARY-QUALIFICATION-RESULT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
