/work/mckernel-native-irq-images-20260907-7/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-irq-images-20260907-7/invalid-abi/tmp.resolve_MODULES_END/driver.o

