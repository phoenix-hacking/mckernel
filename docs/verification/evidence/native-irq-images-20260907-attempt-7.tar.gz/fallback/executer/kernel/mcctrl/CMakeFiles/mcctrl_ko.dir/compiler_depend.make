# Empty custom commands generated dependencies file for mcctrl_ko.
# This may be replaced when dependencies are built.
