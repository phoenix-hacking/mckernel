file(REMOVE_RECURSE
  "CMakeFiles/gennames.dir/libdwarf/libdwarf/dwgetopt.c.o"
  "CMakeFiles/gennames.dir/libdwarf/libdwarf/dwgetopt.c.o.d"
  "CMakeFiles/gennames.dir/libdwarf/libdwarf/gennames.c.o"
  "CMakeFiles/gennames.dir/libdwarf/libdwarf/gennames.c.o.d"
  "gennames"
  "gennames.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/gennames.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
