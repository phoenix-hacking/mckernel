# Empty dependencies file for gennames.
# This may be replaced when dependencies are built.
