file(REMOVE_RECURSE
  "CMakeFiles/eclair.dir/arch/x86_64/arch-eclair.c.o"
  "CMakeFiles/eclair.dir/arch/x86_64/arch-eclair.c.o.d"
  "CMakeFiles/eclair.dir/eclair.c.o"
  "CMakeFiles/eclair.dir/eclair.c.o.d"
  "eclair"
  "eclair.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/eclair.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
