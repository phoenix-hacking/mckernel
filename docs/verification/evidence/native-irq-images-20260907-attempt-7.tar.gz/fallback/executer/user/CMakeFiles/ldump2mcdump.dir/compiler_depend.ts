# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for ldump2mcdump.
