file(REMOVE_RECURSE
  "CMakeFiles/mcinspect.dir/mcinspect.c.o"
  "CMakeFiles/mcinspect.dir/mcinspect.c.o.d"
  "mcinspect"
  "mcinspect.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mcinspect.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
