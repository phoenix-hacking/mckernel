file(REMOVE_RECURSE
  "CMakeFiles/libmcexec.dir/arch/x86_64/archdep.S.o"
  "libmcexec.a"
  "libmcexec.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang ASM)
  include(CMakeFiles/libmcexec.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
