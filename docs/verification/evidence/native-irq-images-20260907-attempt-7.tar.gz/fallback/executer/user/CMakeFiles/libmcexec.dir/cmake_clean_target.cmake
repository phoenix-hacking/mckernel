file(REMOVE_RECURSE
  "libmcexec.a"
)
