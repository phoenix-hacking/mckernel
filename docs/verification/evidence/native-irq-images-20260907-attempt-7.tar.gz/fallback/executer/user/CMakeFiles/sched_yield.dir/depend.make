# Empty dependencies file for sched_yield.
# This may be replaced when dependencies are built.
