# Empty dependencies file for mcinspect.
# This may be replaced when dependencies are built.
