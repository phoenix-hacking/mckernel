file(REMOVE_RECURSE
  "CMakeFiles/sched_yield.dir/libsched_yield.c.o"
  "CMakeFiles/sched_yield.dir/libsched_yield.c.o.d"
  "libsched_yield.pdb"
  "libsched_yield.so"
  "libsched_yield.so.1.0.0"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sched_yield.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
