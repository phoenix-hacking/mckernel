# Empty compiler generated dependencies file for mcexec.
# This may be replaced when dependencies are built.
