
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/mckernel-native-irq-images-20260907-7/source/executer/user/arch/x86_64/arch-eclair.c" "executer/user/CMakeFiles/eclair.dir/arch/x86_64/arch-eclair.c.o" "gcc" "executer/user/CMakeFiles/eclair.dir/arch/x86_64/arch-eclair.c.o.d"
  "/work/mckernel-native-irq-images-20260907-7/source/executer/user/eclair.c" "executer/user/CMakeFiles/eclair.dir/eclair.c.o" "gcc" "executer/user/CMakeFiles/eclair.dir/eclair.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
