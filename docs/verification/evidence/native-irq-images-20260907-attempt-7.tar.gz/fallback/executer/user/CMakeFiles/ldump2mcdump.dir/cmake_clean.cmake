file(REMOVE_RECURSE
  "CMakeFiles/ldump2mcdump.dir/ldump2mcdump.c.o"
  "CMakeFiles/ldump2mcdump.dir/ldump2mcdump.c.o.d"
  "libldump2mcdump.pdb"
  "libldump2mcdump.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ldump2mcdump.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
