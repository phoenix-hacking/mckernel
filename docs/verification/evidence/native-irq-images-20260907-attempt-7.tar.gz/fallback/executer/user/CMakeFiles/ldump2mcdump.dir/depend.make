# Empty dependencies file for ldump2mcdump.
# This may be replaced when dependencies are built.
