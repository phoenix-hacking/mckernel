# Empty custom commands generated dependencies file for ihk_ko.
# This may be replaced when dependencies are built.
