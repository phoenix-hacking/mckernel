file(REMOVE_RECURSE
  "../../ikc/.linux.o.cmd"
  "../../ikc/.master.o.cmd"
  "../../ikc/.queue.o.cmd"
  "../../ikc/linux.o"
  "../../ikc/master.o"
  "../../ikc/queue.o"
  ".host_driver.o.cmd"
  ".ihk.ko.cmd"
  ".ihk.mod.o.cmd"
  ".ihk.o.cmd"
  ".mem_alloc.o.cmd"
  ".mikc.o.cmd"
  ".mm.o.cmd"
  ".tmp_versions"
  ".tmp_versions/ihk.mod"
  "CMakeFiles/ihk_ko"
  "Module.symvers"
  "host_driver.o"
  "ihk.ko"
  "ihk.mod.c"
  "ihk.mod.o"
  "ihk.o"
  "kmod_always_rebuild"
  "mem_alloc.o"
  "mikc.o"
  "mm.o"
  "modules.order"
  "old_timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ihk_ko.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
