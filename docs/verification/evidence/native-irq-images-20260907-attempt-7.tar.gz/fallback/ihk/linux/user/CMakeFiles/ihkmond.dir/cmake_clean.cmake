file(REMOVE_RECURSE
  "CMakeFiles/ihkmond.dir/ihkmond.c.o"
  "CMakeFiles/ihkmond.dir/ihkmond.c.o.d"
  "ihkmond"
  "ihkmond.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ihkmond.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
