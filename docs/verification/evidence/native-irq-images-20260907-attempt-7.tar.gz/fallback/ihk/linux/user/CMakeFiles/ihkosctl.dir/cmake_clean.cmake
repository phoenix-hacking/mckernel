file(REMOVE_RECURSE
  "CMakeFiles/ihkosctl.dir/ihkosctl.c.o"
  "CMakeFiles/ihkosctl.dir/ihkosctl.c.o.d"
  "ihkosctl"
  "ihkosctl.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ihkosctl.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
