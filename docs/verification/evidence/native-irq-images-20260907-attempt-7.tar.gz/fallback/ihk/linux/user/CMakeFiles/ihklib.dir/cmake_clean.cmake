file(REMOVE_RECURSE
  "CMakeFiles/ihklib.dir/ihklib.c.o"
  "CMakeFiles/ihklib.dir/ihklib.c.o.d"
  "libihk.pdb"
  "libihk.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ihklib.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
