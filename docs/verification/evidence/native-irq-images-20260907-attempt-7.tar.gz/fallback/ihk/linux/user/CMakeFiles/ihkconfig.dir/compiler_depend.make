# Empty compiler generated dependencies file for ihkconfig.
# This may be replaced when dependencies are built.
