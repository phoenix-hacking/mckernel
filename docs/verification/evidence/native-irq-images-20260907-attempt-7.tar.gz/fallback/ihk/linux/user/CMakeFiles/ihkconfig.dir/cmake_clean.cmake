file(REMOVE_RECURSE
  "CMakeFiles/ihkconfig.dir/ihkconfig.c.o"
  "CMakeFiles/ihkconfig.dir/ihkconfig.c.o.d"
  "ihkconfig"
  "ihkconfig.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ihkconfig.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
