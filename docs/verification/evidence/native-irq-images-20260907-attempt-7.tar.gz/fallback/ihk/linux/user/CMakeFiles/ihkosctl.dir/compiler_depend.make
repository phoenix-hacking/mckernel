# Empty compiler generated dependencies file for ihkosctl.
# This may be replaced when dependencies are built.
