file(REMOVE_RECURSE
  ".ihk-smp-x86_64.ko.cmd"
  ".ihk-smp-x86_64.mod.o.cmd"
  ".ihk-smp-x86_64.o.cmd"
  ".smp-driver.o.cmd"
  ".tmp_versions"
  ".tmp_versions/ihk-smp-x86_64.mod"
  "CMakeFiles/ihk-smp-x86_64_ko"
  "Module.symvers"
  "arch/x86_64/.smp-arch-driver.o.cmd"
  "arch/x86_64/.smp-x86_64-startup.o.cmd"
  "arch/x86_64/.smp-x86_64-trampoline.o.cmd"
  "arch/x86_64/smp-arch-driver.o"
  "arch/x86_64/smp-x86_64-startup.o"
  "arch/x86_64/smp-x86_64-trampoline.o"
  "ihk-smp-x86_64.ko"
  "ihk-smp-x86_64.mod.c"
  "ihk-smp-x86_64.mod.o"
  "ihk-smp-x86_64.o"
  "kmod_always_rebuild"
  "modules.order"
  "old_timestamp"
  "smp-driver.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ihk-smp-x86_64_ko.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
