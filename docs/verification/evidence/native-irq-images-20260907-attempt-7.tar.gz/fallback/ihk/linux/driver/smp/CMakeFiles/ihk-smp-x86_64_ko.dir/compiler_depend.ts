# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for ihk-smp-x86_64_ko.
