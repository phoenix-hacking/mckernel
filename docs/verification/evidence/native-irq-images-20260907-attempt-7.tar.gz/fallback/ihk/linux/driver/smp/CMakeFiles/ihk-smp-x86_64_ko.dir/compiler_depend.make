# Empty custom commands generated dependencies file for ihk-smp-x86_64_ko.
# This may be replaced when dependencies are built.
