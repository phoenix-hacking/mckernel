# Empty compiler generated dependencies file for mcstat.
# This may be replaced when dependencies are built.
