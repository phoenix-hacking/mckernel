file(REMOVE_RECURSE
  "CMakeFiles/mcstat.dir/mcstat.c.o"
  "CMakeFiles/mcstat.dir/mcstat.c.o.d"
  "mcstat"
  "mcstat.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mcstat.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
