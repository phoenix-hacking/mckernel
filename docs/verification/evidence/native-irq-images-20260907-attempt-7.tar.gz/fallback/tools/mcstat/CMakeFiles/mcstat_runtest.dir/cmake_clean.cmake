file(REMOVE_RECURSE
  "CMakeFiles/mcstat_runtest.dir/runtest.c.o"
  "CMakeFiles/mcstat_runtest.dir/runtest.c.o.d"
  "mcstat_runtest"
  "mcstat_runtest.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mcstat_runtest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
