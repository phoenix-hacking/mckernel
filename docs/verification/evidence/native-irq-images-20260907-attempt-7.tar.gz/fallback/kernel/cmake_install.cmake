# Install script for directory: /work/mckernel-native-irq-images-20260907-7/source/kernel

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/work/mckernel-native-irq-images-20260907-7/fallback-prefix")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Debug")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel" TYPE EXECUTABLE FILES "/work/mckernel-native-irq-images-20260907-7/fallback/kernel/mckernel.img")
  if(EXISTS "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/work/mckernel-native-irq-images-20260907-7/fallback-prefix/smp-x86/kernel/mckernel.img")
    endif()
  endif()
endif()

