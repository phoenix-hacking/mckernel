kernel/CMakeFiles/mckernel.img.dir/__/lib/bitops.c.o: \
 /work/mckernel-native-irq-images-20260907-7/source/lib/bitops.c \
 /work/mckernel-native-irq-images-20260907-7/source/lib/include/bitops.h \
 /work/mckernel-native-irq-images-20260907-7/source/lib/include/types.h \
 /work/mckernel-native-irq-images-20260907-7/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-irq-images-20260907-7/source/lib/include/bitops-test_bit.h \
 /work/mckernel-native-irq-images-20260907-7/source/arch/x86_64/kernel/include/arch-bitops.h
