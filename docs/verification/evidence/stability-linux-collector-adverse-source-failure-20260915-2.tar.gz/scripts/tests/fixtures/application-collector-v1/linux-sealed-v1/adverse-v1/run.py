#!/usr/bin/env python3
"""Record a bounded runtime request; actual execution remains disabled."""
import argparse,json,hashlib
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument("--case",choices=("control","missing-setup","partial-setup","interrupt-completed-wait"),required=True); p.add_argument("--attempt-root",type=Path,required=True); p.add_argument("--prepared",type=Path,required=True); a=p.parse_args()
 if not a.attempt_root.is_dir() or not a.prepared.is_file(): raise ValueError("bound prepared attempt required")
 out=a.attempt_root/"runtime-request.json"; out.open("x").write(json.dumps({"schema_version":1,"case":a.case,"prepared_sha256":hashlib.sha256(a.prepared.read_bytes()).hexdigest(),"status":"PREPARED_NOT_EXECUTED","application_acceptance":False,"execution_permitted":False},sort_keys=True)+"\n")
if __name__=="__main__": main()
