#!/usr/bin/env python3
"""Hash-bound description of the isolated root profile."""
import argparse,json,hashlib
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument("--packet",type=Path,required=True); p.add_argument("--attempt-root",type=Path,required=True); a=p.parse_args(); a.attempt_root.mkdir(mode=0o700,parents=False)
 rec={"schema_version":1,"kind":"linux-sealed-adverse-root-profile","packet_sha256":hashlib.sha256(a.packet.read_bytes()).hexdigest(),"status":"PREPARED_NOT_EXECUTED","user":"0:0","group_add":[0],"cap_drop":"ALL","network":"none","cpu_limit":4,"memory_limit_bytes":12*1024**3,"watchdog_seconds":300,"cleanup":"verified-container-absence","execution_permitted":False}
 (a.attempt_root/"profile.json").open("x").write(json.dumps(rec,sort_keys=True)+"\n")
if __name__=="__main__": main()
