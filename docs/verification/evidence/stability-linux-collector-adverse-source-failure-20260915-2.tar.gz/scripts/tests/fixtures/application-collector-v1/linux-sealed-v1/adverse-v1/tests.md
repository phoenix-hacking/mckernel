# Linux collector adverse-v1 source packet

This packet is source-only until an independently reviewed build and root
execution packet enables it. It generates separately named guarded binaries
from the released collector source. Selector 0 is the unchanged control;
selectors 1, 2 and 3 are missing setup, 383-byte setup and completed-wait
interruption respectively. No production collector is replaced or modified.

Every attempt must retain the exact source and SHA, unique-match patch,
generated diff, compiler/dependency/ELF bindings, request, diagnostic witness,
setup bytes, both streams, event/report files, raw waits, PID/startticks,
deadlines, container/watchdog observations and verified final absence.
