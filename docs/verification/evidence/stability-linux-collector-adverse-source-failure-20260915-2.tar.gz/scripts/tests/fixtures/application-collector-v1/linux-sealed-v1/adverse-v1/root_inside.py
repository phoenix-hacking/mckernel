#!/usr/bin/env python3
"""Container entrypoint contract; it only emits an execution-disabled marker."""
import json,os
print(json.dumps({"status":"PREPARED_NOT_EXECUTED","uid":os.getuid(),"euid":os.geteuid(),"execution_permitted":False,"cleanup_required":True},sort_keys=True))
