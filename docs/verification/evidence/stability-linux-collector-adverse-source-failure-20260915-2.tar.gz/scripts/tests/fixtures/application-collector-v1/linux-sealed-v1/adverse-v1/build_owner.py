#!/usr/bin/env python3
"""Hash-bound, non-executing C11 build-owner plan."""
import argparse,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(); p.add_argument("--packet",type=Path,required=True); p.add_argument("--attempt-root",type=Path,required=True); a=p.parse_args()
 if a.attempt_root.exists(): raise ValueError("fresh build attempt required")
 packet=json.loads(a.packet.read_text()); a.attempt_root.mkdir(mode=0o700,parents=False)
 cases={x["id"]:x["selector"] for x in packet["cases"]}
 record={"schema_version":2,"kind":"linux-sealed-collector-adverse-build-plan","status":"PREPARED_NOT_EXECUTED","application_acceptance":False,"backend_enabled":False,"packet_sha256":sha(a.packet),"source_sha256":packet["source"]["sha256"],"patch_sha256":sha(HERE/"collector.patch"),"header_sha256":sha(HERE/"inject.h"),"compiler":{"language":"c11","flags":["-std=c11","-D_GNU_SOURCE","-DM02_ADVERSE_TEST_ONLY=1","-Wall","-Wextra","-Werror"],"case_flags":{k:["-DM02_ADVERSE_CASE=%d"%v] for k,v in cases.items()},"objects":["request.c","sha256.c","collector.c","adverse-collector.c"],"distinct_binaries":True,"dependency_bindings":"complete"},"cases":cases,"execution_permitted":False}
 (a.attempt_root/"build-record.json").write_text(json.dumps(record,indent=2,sort_keys=True)+"\n")
if __name__=="__main__": main()
