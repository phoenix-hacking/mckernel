#!/usr/bin/env python3
"""Prepare isolated root execution inputs without launching Docker or a root job."""
import argparse,hashlib,json
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument("--packet",type=Path,required=True); p.add_argument("--build-record",type=Path,required=True); p.add_argument("--attempt-root",type=Path,required=True); a=p.parse_args()
 if a.attempt_root.exists(): raise ValueError("fresh root attempt required")
 a.attempt_root.mkdir(mode=0o700,parents=False)
 rec={"schema_version":1,"kind":"linux-sealed-adverse-root-orchestration","status":"PREPARED_NOT_EXECUTED","packet_sha256":hashlib.sha256(a.packet.read_bytes()).hexdigest(),"build_record_sha256":hashlib.sha256(a.build_record.read_bytes()).hexdigest(),"container":{"network":"none","user":"0:0","group_add":[0],"cap_drop":"ALL","cpus":4,"memory_bytes":12*1024**3},"watchdog":{"seconds":300,"armed":False,"disarmed":False},"cleanup":{"container_absent":None,"lock_released":None},"execution_permitted":False}
 (a.attempt_root/"root-record.json").open("x").write(json.dumps(rec,indent=2,sort_keys=True)+"\n")
if __name__=="__main__": main()
