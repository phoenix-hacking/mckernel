import importlib.util, json, tempfile, unittest
from pathlib import Path
HERE=Path(__file__).parent/"fixtures/application-collector-v1/linux-sealed-v1/adverse-v1"
def load(name):
    s=importlib.util.spec_from_file_location(name,HERE/(name+".py")); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
prepare=load("prepare"); oracle=load("oracle")
NAMES=("request.bin","selected-inputs.bin","argv.nul","env.nul","events.jsonl","executable.verified.bin","stdin.verified.bin","stdout.bin","stderr.bin","setup.bin")
def report(case,n):
    ready=case=="interrupt-completed-wait"; signal=15 if ready else 0
    return {"schema_version":1,"kind":"linux-sealed-infrastructure-collection","status":"INTERRUPTED" if ready else "SETUP_ERROR","first_failure":"collector-interrupted" if ready else "setup-pipe-incomplete","first_failure_errno":4 if ready else 71,"collector_interruption_signal":signal,"application_acceptance":False,"transport_acceptance":False,"backend_enabled":False,"setup_ready_record":ready,"setup_error_record":False,"setup_validated":ready,"setup_words":[0,0,1,1,0]+[0]*43 if ready else [0]*48,"cleanup_complete":True,"group_identity_pinned":True,"streams":{"setup_eof":True,"stdout_eof":True,"stderr_eof":True},"linux_child":{"raw_wait_status":0,"wait":{"exited":True,"exit_code":0}},"artifacts":[{"attempted_name":x,"seen_bytes":n if x=="setup.bin" else 0,"stored_bytes":n if x=="setup.bin" else 0,"truncated":False,"io_error":False} for x in NAMES]}
class AdversePacketTests(unittest.TestCase):
    def test_packet_is_non_acceptance_and_cases_are_exact(self):
        p=json.loads((HERE/"packet.json").read_text()); self.assertEqual(p["status"],"SOURCE_PACKET_ONLY"); self.assertFalse(p["application_acceptance"]); self.assertFalse(p["backend_enabled"]); self.assertEqual([x["id"] for x in p["cases"]],["missing-setup","partial-setup","interrupt-completed-wait"]); self.assertEqual([x["setup_length"] for x in p["cases"]],[0,383,384])
    def test_generation_has_unique_guarded_sites(self):
        g=prepare.generate(prepare.SOURCE.read_bytes()).decode(); self.assertEqual(g.count('#include "inject.h"'),1); self.assertEqual(g.count("m02_adverse_child_boundary(setup_fd, words);"),1); self.assertEqual(g.count("m02_adverse_completed_wait_hook"),2); self.assertNotIn("#define M02_ADVERSE_CASE",g); self.assertIn("interrupted_latch",(HERE/"inject.h").read_text())
    def test_prepare_writes_fresh_source_bound_record(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/"attempt"; import sys; old=sys.argv; sys.argv=["prepare.py","--packet",str(HERE/"packet.json"),"--attempt-root",str(out)]
            try: prepare.main()
            finally: sys.argv=old
            r=json.loads((out/"prepare.json").read_text()); self.assertEqual(r["status"],"PREPARED_NOT_EXECUTED"); self.assertEqual(r["source"]["sha256"],prepare.EXPECTED_SOURCE); self.assertTrue((out/"generated.diff").read_bytes())
    def test_oracle_negative_matrix(self):
        for case,n in (("missing-setup",0),("partial-setup",383)): self.assertTrue(oracle.validate(report(case,n),case)); bad=report(case,n); bad["status"]="COMPLETED"; self.assertFalse(oracle.validate(bad,case)); bad=report(case,n); bad["first_failure_errno"]=0; self.assertFalse(oracle.validate(bad,case))
        good=report("interrupt-completed-wait",384); self.assertTrue(oracle.validate(good,"interrupt-completed-wait"));
        for field in ("cleanup_complete","group_identity_pinned"): bad=report("interrupt-completed-wait",384); bad[field]=False; self.assertFalse(oracle.validate(bad,"interrupt-completed-wait"))
if __name__=="__main__": unittest.main()
