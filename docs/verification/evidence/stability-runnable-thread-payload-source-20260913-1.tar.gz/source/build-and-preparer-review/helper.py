from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shlex,shutil
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work');out=work/'stability-runnable-thread-payload-build-20260913-1';out.mkdir();(out/'tmp').mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],compiler_dependencies=[],compiled_outputs=[],application_acceptance=False,transport_acceptance=False,production_gate_credit=False,scope='Compile additive runnable pthread payload with unchanged C flags, capture exact compiler inputs and inspect actual helper loop; no payload execution')
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 assert shutil.disk_usage(work).free>3*1024**3
 shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(out/'tmp'))
 def run(label,argv,timeout=120):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0],path=env['PATH'])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=15,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['raw_wait_status']==0 and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  return (out/(label+'-collection')/'stdout.bin').read_text()
 source=repo/'scripts/tests/fixtures/stability-transport-fault/payload-runnable-thread-v1.c'
 assert identity(source)['sha256']=='dbc68dc4e981c0ed3433491747b4dcd7a031548fbd84bddbd8e98361d4681491'
 shutil.copyfile(source,out/'payload.c')
 record['inputs'].append(dict(original=identity(source),retained=identity(out/'payload.c')))
 record['payload_source']=identity(out/'payload.c');record['payload_profile']='runnable-thread-v1'
 assert identity(out/'supervisor.py')['sha256']=='8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
 record['inputs'].append(dict(original=identity(repo/'scripts/application-tests/supervisor.py'),retained=identity(out/'supervisor.py')))
 run('compiler-version',['gcc','--version'])
 for label,p in [('payload',out/'payload.c')]:
  obj=out/(label+'.o');elf=out/(label+'.elf');deps=out/(label+'.d')
  run(label+'-compile',['gcc','-std=c11','-D_GNU_SOURCE','-O2','-g','-Wall','-Wextra','-Werror','-fno-pie','-pthread','-MD','-MF',str(deps),'-I',str(repo/'executer/include'),'-c',str(p),'-o',str(obj)])
  run(label+'-link',['gcc','-no-pie','-pthread',str(obj),'-Wl,-Map='+str(out/(label+'.map')),'-o',str(elf)])
  run(label+'-elf',['readelf','-h','-l','-d',str(elf)])
  data=run(label+'-loader-trace',['ldd',str(elf)])
  for line in data.splitlines():
   for part in line.split():
    if part.startswith('/') and Path(part).is_file():record.setdefault('loader_dependencies',[]).append(identity(Path(part)))
  deptext=deps.read_text().replace('\\\n',' ');_,items=deptext.split(':',1)
  for item in shlex.split(items):
   p=Path(item)
   if not p.is_absolute():p=out/p
   row=identity(p)
   if row not in record['compiler_dependencies']:record['compiler_dependencies'].append(row)
  record['compiled_outputs'] += [identity(p) for p in (obj,elf,deps,out/(label+'.map'))]
 emitted=run('spinner-disassembly',['objdump','-d','--disassemble=spin_until_done',str(out/'payload.elf')])
 assert '<spin_until_done>:' in emitted
 import re
 assert not re.search(r'\b(?:callq?|syscall|sysenter|int|lock)\b',emitted), 'helper loop contains forbidden calls/system operation'
 record['spinner_disassembly']=identity(out/'spinner-disassembly-collection/stdout.bin')
 for row in record['compiler_dependencies'] + record['compiled_outputs']:
  assert identity(Path(row['path']))==row
 for row in record['inputs']:
  assert identity(Path(row['original']['path']))==row['original'] and identity(Path(row['retained']['path']))==row['retained']
 record.update(status='PASS_BUILD_ONLY',guest_execution=False,controller_executed=False,exporter_executed=False,payload_executed=False)
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
