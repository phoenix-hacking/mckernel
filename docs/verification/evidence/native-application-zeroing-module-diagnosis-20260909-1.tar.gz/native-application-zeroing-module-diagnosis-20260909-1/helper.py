from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
out=Path('/work/native-application-zeroing-module-diagnosis-20260909-'+sys.argv[1]);out.mkdir()
build=Path('/work/native-build-base-24a151fe/drivers/misc/mckernel')
shutil.copyfile(__file__,out/'helper.py');shutil.copytree(build,out/'failed-module-build')
obj=out/'failed-module-build/ihk_smp_x86_64.o'
for name,args in [('symbols',['nm','-S',str(obj)]),('relocations',['readelf','-rW',str(obj)]),('disassembly',['objdump','-dr',str(obj)])]:
    (out/(name+'.txt')).write_bytes(subprocess.check_output(args))
record=dict(status='PASS',utc=datetime.now(timezone.utc).isoformat(),scope='Preserve exact raw failed Rust object and emitted flow/relocations; diagnostic only',source_failure='/work/native-application-zeroing-module-20260909-1',files=[])
for path in sorted(out.rglob('*')):
    if path.is_file():record['files'].append(dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print('PASS',out,flush=True)
