"""Fresh, source-bound real launchers and an ordinary ELF application fixture."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-application-launcher-20260908-' + sys.argv[1])
out.mkdir()
source = out / 'source'
assert shutil.disk_usage('/work').free > 3 * 1024**3
environment = dict(os.environ, PATH='/opt/mckernel/cargo/bin:' + os.environ['PATH'],
                   RUSTC='/opt/mckernel/cargo/bin/rustc', PYTHONDONTWRITEBYTECODE='1')
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], universal_newlines=True).strip(),
              commands=[], source_overlays=[], inputs=[], outputs=[], runtime_libraries=[],
              cpuset=sorted(os.sched_getaffinity(0)), memory_mib=12288,
              mckernel_application_executed=False, production_gate_credit=False)

def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), size=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command, expected=0, stdin=None):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=str(source) if source.exists() else str(repo),
                                env=environment, input=stdin, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode, expected=expected))
    save()
    assert result.returncode == expected, (label, result.returncode, (out / (label + '.log')).read_text()[-6000:])
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'build-helper.py')
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('clone-source', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo), str(source)])
    run('sparse-init', ['git', '-C', str(source), 'sparse-checkout', 'init', '--no-cone'])
    run('sparse-patterns', ['git', '-C', str(source), 'sparse-checkout', 'set', '--no-cone', '--stdin'],
        stdin=b'/*\n!/docs/verification/evidence/\n')
    run('checkout-source', ['git', '-C', str(source), 'checkout', '--detach', record['source_parent']])
    omitted = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-r', '-l', record['source_parent'], '--', 'docs/verification/evidence'])
    (out / 'sparse-omitted-git-objects.txt').write_bytes(omitted)
    record['sparse_exclusion'] = dict(prefix='docs/verification/evidence/', objects=len(omitted.splitlines()),
                                     inventory=identity(out / 'sparse-omitted-git-objects.txt'), source_code_excluded=False)
    assert not (source / 'docs/verification/evidence').exists()
    submodules = subprocess.check_output(['git', '-C', str(repo), 'submodule', 'status', '--recursive'], universal_newlines=True)
    record['recursive_submodules'] = submodules.splitlines()
    for index, line in enumerate(submodules.splitlines()):
        assert line.startswith(' '), line
        revision, relative = line[1:].split()[:2]
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        run('clone-submodule-' + str(index), ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / relative), str(target)])
        run('checkout-submodule-' + str(index), ['git', '-C', str(target), 'checkout', '--detach', revision])
    assert subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain']) == b''
    overlays = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', 'HEAD', '-z']).split(b'\0')
    overlays += subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    for raw in sorted(set(overlays)):
        if not raw:
            continue
        relative = os.fsdecode(raw)
        assert not relative.startswith('docs/verification/evidence/')
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / relative, target)
        record['source_overlays'].append(identity(target))
    record['compiler'] = run('rust-compiler', ['/opt/mckernel/cargo/bin/rustc', '--version', '--verbose'])
    record['c_compiler'] = run('c-compiler', ['cc', '--version'])
    record['phase'] = 'bind-build-sources'
    save()
    build_sources = ['CMakeLists.txt', 'executer/user/CMakeLists.txt',
                     'executer/user/mcexec.c', 'executer/user/rust/mcexec_helpers.rs',
                     'executer/user/arch/x86_64/archdep.S', 'executer/include/uprotocol.h',
                     'scripts/tests/fixtures/native-application-hello.S']
    record['inputs'] = [identity(source / p) for p in build_sources]
    common = ['cmake', '-S', str(source), '-DCMAKE_BUILD_TYPE=Debug', '-DBUILD_TARGET=smp-x86',
              '-DKERNEL_DIR=/usr/src/kernels/4.18.0-553.159.1.el8_10.x86_64',
              '-DENABLE_PERF=ON', '-DENABLE_RUSAGE=ON', '-DENABLE_LINUX_WORK_IRQ_FOR_IKC=ON',
              '-DENABLE_RUST_KERNEL=ON', '-DENABLE_RUST_IHK_MODULE_HELPERS=ON',
              '-DMCKERNEL_HOST_IRQ_ABI=linux-6.12', '-DENABLE_NATIVE_SYSFS_VERIFY=OFF',
              '-DRUSTC=/opt/mckernel/cargo/bin/rustc', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    record['launchers'] = []
    for label, enabled in [('rust', 'ON'), ('fallback', 'OFF')]:
        build = out / label
        run(label + '-configure', common + ['-B', str(build), '-DENABLE_RUST_USER_TOOLS=' + enabled,
                                          '-DCMAKE_INSTALL_PREFIX=' + str(out / (label + '-prefix'))])
        run(label + '-build', ['cmake', '--build', str(build), '--target', 'mcexec', '-j4'])
        binary = build / 'executer/user/mcexec'
        header = run(label + '-elf-header', ['readelf', '-h', str(binary)])
        assert 'ELF64' in header and 'Advanced Micro Devices X86-64' in header and 'DYN' in header
        symbols = run(label + '-symbols', ['nm', '-n', str(binary)])
        assert (' T mcexec_finish_main_image_body\n' in symbols) == (enabled == 'ON')
        assert ('ENABLE_RUST_USER_TOOLS:BOOL=ON' in (build / 'CMakeCache.txt').read_text()) == (enabled == 'ON')
        link = build / 'executer/user/CMakeFiles/mcexec.dir/link.txt'
        assert ('rust/mcexec_helpers.o' in link.read_text()) == (enabled == 'ON')
        paths = [binary, build / 'CMakeCache.txt', build / 'compile_commands.json', link,
                 build / 'executer/user/CMakeFiles/mcexec.dir/build.make',
                 build / 'executer/user/CMakeFiles/mcexec.dir/flags.make']
        if enabled == 'ON':
            paths += [build / 'executer/user/rust/mcexec_helpers.o',
                      build / 'executer/user/CMakeFiles/mcexec_rust_helpers.dir/build.make']
        dependencies = run(label + '-runtime-libraries', ['ldd', str(binary)])
        assert 'not found' not in dependencies
        runtime = out / (label + '-runtime')
        runtime.mkdir()
        libraries = []
        for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', dependencies))):
            original = Path(name)
            target = runtime / name.lstrip('/')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
            row = dict(original=identity(original), captured=identity(target))
            assert row['original']['sha256'] == row['captured']['sha256']
            libraries.append(row)
        assert any('ld-linux' in p['original']['path'] for p in libraries)
        assert any('libnuma' in p['original']['path'] for p in libraries)
        record['runtime_libraries'] += libraries
        record['launchers'].append(dict(selection=label, rust_enabled=enabled == 'ON',
                                       outputs=[identity(p) for p in paths]))
        save()
    hello = out / 'native-application-hello'
    run('application-build', ['cc', '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack',
                              str(source / 'scripts/tests/fixtures/native-application-hello.S'), '-o', str(hello)])
    application_header = run('application-elf-header', ['readelf', '-h', '-l', str(hello)])
    assert 'EXEC' in application_header and 'INTERP' not in application_header
    run('application-disassembly', ['objdump', '-d', str(hello)])
    output = run('linux-reference-application', [str(hello)], expected=37)
    assert output == 'NATIVE_APPLICATION_HELLO\n', repr(output)
    record['linux_reference'] = dict(exit_code=37, stdout=output, kernel='container Linux', mckernel=False)
    record['outputs'].append(identity(hello))
    record['compiler_dependencies'] = []
    dependency_paths = set()
    for label in ('rust', 'fallback'):
        for path in (out / label).rglob('*.o.d'):
            dependency_paths.add(path)
            raw = path.read_text().replace('\\\n', ' ')
            for item in raw.split()[1:]:
                candidate = Path(item)
                if candidate.is_absolute() and candidate.is_file():
                    dependency_paths.add(candidate)
    for path in sorted(dependency_paths):
        record['compiler_dependencies'].append(identity(path))
    assert record['compiler_dependencies']
    for row in record['inputs'] + record['source_overlays']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS', phase='complete')
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
