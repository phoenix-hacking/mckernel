use crate::abi::*;
use core::{ffi::c_void,mem::size_of,ptr::write_volatile};
const EINVAL: CInt = 22;
const SCD_MSG_CLEANUP_PROCESS_RESP: CInt = 0x0a;
pub type HostIkcPacketSendFn =
    Option<unsafe extern "C" fn(channel: *mut c_void, packet: *mut IkcScdPacket)>;
pub type HostCleanupProcessFn = Option<unsafe extern "C" fn(pid: CInt) -> CInt>;
pub type HostTerminateHostFn = Option<unsafe extern "C" fn(pid: CInt, thread: *mut c_void)>;
pub type HostCleanupProcessLogFn = Option<unsafe extern "C" fn(pid: CInt, thread_arg: CULong)>;
unsafe fn zero_ikc_scd_packet(packet: *mut IkcScdPacket) {
    let words = size_of::<IkcScdPacket>() / size_of::<CULong>();
    let bytes = size_of::<IkcScdPacket>() % size_of::<CULong>();
    let wordp = packet.cast::<CULong>();
    let mut index = 0;

    while index < words {
        write_volatile(wordp.add(index), 0);
        index += 1;
    }

    let bytep = wordp.add(words).cast::<u8>();
    let mut byte = 0;
    while byte < bytes {
        write_volatile(bytep.add(byte), 0);
        byte += 1;
    }
}
pub unsafe extern "C" fn host_ikc_packet_send_result(
    channel: *mut c_void,
    packet: *mut IkcScdPacket,
    send_fn: HostIkcPacketSendFn,
) -> CInt {
    let send = match send_fn {
        Some(send) => send,
        None => return -EINVAL,
    };
    if packet.is_null() {
        return -EINVAL;
    }

    send(channel, packet);
    0
}
pub unsafe extern "C" fn host_cleanup_process_result(
    pid: CInt,
    cleanup_fn: HostCleanupProcessFn,
) -> CInt {
    let cleanup = match cleanup_fn {
        Some(cleanup) => cleanup,
        None => return -EINVAL,
    };

    cleanup(pid)
}
pub unsafe extern "C" fn host_cleanup_process_log_result(
    pid: CInt,
    thread_arg: CULong,
    log_fn: HostCleanupProcessLogFn,
) -> CInt {
    let log = match log_fn {
        Some(log) => log,
        None => return -EINVAL,
    };

    log(pid, thread_arg);
    0
}
pub unsafe extern "C" fn host_terminate_host_result(
    pid: CInt,
    thread: *mut c_void,
    terminate_fn: HostTerminateHostFn,
) -> CInt {
    let terminate = match terminate_fn {
        Some(terminate) => terminate,
        None => return -EINVAL,
    };

    terminate(pid, thread);
    0
}
pub unsafe extern "C" fn host_traditional_reply_result(
    channel: *mut c_void,
    request: *mut IkcScdPacket,
    msg: CInt,
    err: CInt,
    send_fn: HostIkcPacketSendFn,
) -> CInt {
    if request.is_null() || send_fn.is_none() {
        return -EINVAL;
    }

    let mut packet = core::mem::MaybeUninit::<IkcScdPacket>::uninit();
    zero_ikc_scd_packet(packet.as_mut_ptr());
    let reply = packet.as_mut_ptr();
    let request_body = (&raw mut (*request).body).cast::<IkcScdPacketTraditional>();
    let reply_body = (&raw mut (*reply).body).cast::<IkcScdPacketTraditional>();

    (*reply).msg = msg;
    (*reply).err = err;
    (*reply_body).ref_ = (*request_body).ref_;
    (*reply_body).arg = (*request_body).arg;
    (*reply).reply = (*request).reply;
    let _ = host_ikc_packet_send_result(channel, reply, send_fn);
    0
}
pub unsafe extern "C" fn host_cleanup_process_request_result(
    channel: *mut c_void,
    request: *mut IkcScdPacket,
    cleanup_fn: HostCleanupProcessFn,
    terminate_fn: HostTerminateHostFn,
    log_fn: HostCleanupProcessLogFn,
    send_fn: HostIkcPacketSendFn,
) -> CInt {
    if request.is_null() || cleanup_fn.is_none() || terminate_fn.is_none() || send_fn.is_none() {
        return -EINVAL;
    }

    let request_body = (&raw mut (*request).body).cast::<IkcScdPacketTraditional>();
    if log_fn.is_some() {
        let _ = host_cleanup_process_log_result((*request_body).pid, (*request_body).arg, log_fn);
    }
    let ret = host_cleanup_process_result((*request_body).pid, cleanup_fn);
    let _ =
        host_traditional_reply_result(channel, request, SCD_MSG_CLEANUP_PROCESS_RESP, ret, send_fn);
    let _ = host_terminate_host_result(
        (*request_body).pid,
        (*request_body).arg as *mut c_void,
        terminate_fn,
    );
    0
}
