/work/native-irq-work-module-20260907-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.o
