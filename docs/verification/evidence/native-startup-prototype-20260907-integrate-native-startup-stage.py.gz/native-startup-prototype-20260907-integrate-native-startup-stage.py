from pathlib import Path
import ast,hashlib,json,pprint
root=Path('/home/holden/mckernel')
changes={}
def read(path): return changes.get(path,(root/path).read_text())
def put(path,text): changes[path]=text
def sha(path): return hashlib.sha256((root/path).read_bytes()).hexdigest()
def assignment(path,name,value):
 text=read(path);node=next(n.value for n in ast.parse(text).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
 lines=text.splitlines(keepends=True);a=sum(map(len,lines[:node.lineno-1]))+node.col_offset;b=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
 put(path,text[:a]+pprint.pformat(value,width=100,sort_dicts=False)+text[b:])
def replace(path,old,new,count):
 text=read(path)
 if text.count(old)!=count: raise SystemExit(f'Unexpected edit anchor: {path}: {old!r}, count={text.count(old)}')
 put(path,text.replace(old,new))
def append_line(path,old,new,count):
 text=read(path);out=[];found=0
 for line in text.splitlines(keepends=True):
  out.append(line)
  if line.strip()==old:
   out.append(line[:len(line)-len(line.lstrip())]+new+'\n');found+=1
 if found!=count: raise SystemExit(f'Unexpected line anchor: {path}: {old!r}, count={found}')
 put(path,''.join(out))
manifest_path='host-kernel/kbuild/stage-manifest.json';manifest=json.loads(read(manifest_path))
for row in manifest['inputs']:
 if row['destination']=='smp_memory.rs':
  old=row['sha256'];row['sha256']=sha(row['repository_path'])
  replace('scripts/rocky_rust_staging.py',old,row['sha256'],1)
  replace('scripts/ihk_smp_native_lifecycle_check.py',old,row['sha256'],1)
for module in manifest['modules']:
 if module['crate']=='ihk_smp_x86_64':
  old=module['source']['sha256'];module['source']['sha256']=sha(module['source']['repository_path'])
  replace('scripts/rocky_rust_staging.py',old,module['source']['sha256'],1)
startup=dict(destination='smp_startup.rs',kind='rust_support_module',repository_path='host-kernel/native-rust/smp_startup.rs',sha256=sha('host-kernel/native-rust/smp_startup.rs'))
manifest['inputs'].append(startup)
put(manifest_path,json.dumps(manifest,indent=2,sort_keys=True)+'\n')
assignment('scripts/rocky_rust_staging.py','EXPECTED_INPUTS',manifest['inputs'])
for path,count in [('scripts/rocky_rust_staging.py',2),('scripts/native_rust_host_audit.py',1),('scripts/native_rust_kbuild_link_closure.py',1),('scripts/tests/test_rocky_rust_staging.py',2)]:
 append_line(path,'"smp_loader.rs",','"smp_startup.rs",',count)
append_line('scripts/rocky_rust_staging.py','"mod smp_loader;",','"mod smp_startup;",',1)
replace('scripts/rocky_rust_staging.py','smp_image.rs, smp_loader.rs"','smp_image.rs, smp_loader.rs, smp_startup.rs"',1)
append_line('scripts/native_rust_build_surface_audit.py','"smp_loader.rs": "host-kernel/native-rust/smp_loader.rs",','"smp_startup.rs": "host-kernel/native-rust/smp_startup.rs",',1)
replace('scripts/native_rust_kbuild_link_closure.py','"ihk_mapping.rs", "smp_image.rs", "smp_loader.rs",','"ihk_mapping.rs", "smp_image.rs", "smp_loader.rs", "smp_startup.rs",',1)
path='scripts/rocky_rust_staging.py'
replace(path,'"bindings::__alloc_pages_noprof", "bindings::__free_pages",','"bindings::__alloc_pages_noprof", "bindings::alloc_pages_noprof",\n                      "struct StartupTables {", "tables: StartupTables,",\n                      "let tables = StartupTables::new(layout, direct_map)?;",\n                      "bindings::__free_pages",',1)
replace(path,'    elif item["destination"] == "smp_loader.rs":','''    elif item["destination"] == "smp_startup.rs":
        for token in ("pub(crate) struct PageTablePlan", "pub(crate) fn fill",
                      "pub(crate) const TABLE_PAGES: usize = 260;",
                      "end > 1_u64 << 32", "StartupError::StorageSize"):
            if text.count(token) < 1:
                raise ValidationError("{0} lacks startup table boundary: {1}".format(label, token))
        for forbidden in ("unsafe", "kernel::", "bindings::", "module!"):
            if forbidden in text.lower():
                raise ValidationError("{0} contains forbidden boundary: {1}".format(label, forbidden))
    elif item["destination"] == "smp_loader.rs":''',1)
path='host-kernel/native-rust/ihk-smp-lifecycle-contract-v1.json';contract=json.loads(read(path))
for row in contract['crate_modules']:
 if row['destination']=='smp_memory.rs': row['sha256']=sha(row['path'])
contract['crate_modules'].append(dict(destination='smp_startup.rs',path=startup['repository_path'],sha256=startup['sha256']))
contract['os_resource_bridge']['image_loading']['startup_tables']={
 'root_limit_exclusive':1<<32,'useful_pages':260,'original_compound_order':9,
 'allocation':'GFP_KERNEL, ZERO, COMP, NORETRY, NOWARN and DMA32; Linux alloc_pages_noprof resolves node selection',
 'mapping':'256 GiB identity and straight-map windows share a subtree; checked 8 MiB kernel window',
 'ownership':'noncopy Linux allocation owner retained inside exact-generation LoadedImage',
 'cleanup':'failed/replaced load, memory resource changes and unbooted destruction release the original compound allocation',
 'preflight':'allocate and fill tables before first image write; no capability or CPU starts',
 'readback':'volatile physical table bytes checked by an independent x86 guest capture model',
 'native_boot_proven':False,'tracker_credit':False}
put(path,json.dumps(contract,indent=2,sort_keys=True)+'\n')
assignment('scripts/ihk_smp_native_lifecycle_check.py','EXPECTED_CRATE_MODULES',contract['crate_modules'])
assignment('scripts/ihk_smp_native_lifecycle_check.py','EXPECTED_OS_RESOURCE_BRIDGE',contract['os_resource_bridge'])
append_line('scripts/ihk_smp_native_lifecycle_check.py','_require_active_count(text, code, "mod smp_loader;", 1, "Rust SMP bounded image file edge")','_require_active_count(text, code, "mod smp_startup;", 1, "Rust SMP startup page-table edge")',1)
path='scripts/tests/test_native_rust_kbuild_link_closure.py'
text=read(path);lines=text.splitlines(keepends=True);out=[];found=0
for line in lines:
 out.append(line)
 if '/build/native-rust-source/linux/drivers/misc/mckernel/smp_loader.rs ' in line:
  out.append(line.replace('smp_loader.rs','smp_startup.rs'));found+=1
assert found==1;put(path,''.join(out))
replace(path,'"ihk_mapping.rs", "smp_image.rs", "smp_loader.rs"','"ihk_mapping.rs", "smp_image.rs", "smp_loader.rs", "smp_startup.rs"',3)
replace(path,'# capture in native-image-recovery-20260907-build-source-compiler.tar.gz after','# and the owned startup-table prototype module-build/.ihk_smp_x86_64.o.cmd after',1)
append_line('scripts/tests/test_native_rust_unsafe_ffi_ledger.py','ledger.NATIVE_SOURCE_ROOT + "/smp_loader.rs",','ledger.NATIVE_SOURCE_ROOT + "/smp_startup.rs",',1)
replace('scripts/tests/test_native_rust_unsafe_ffi_ledger.py','len(discovery["inputs"]), 18','len(discovery["inputs"]), 19',1)
replace('scripts/tests/test_native_rust_unsafe_ffi_ledger.py','len(discovery["sites"]), 154','len(discovery["sites"]), 156',1)
for path,text in changes.items():
 (root/path).write_text(text)
print('Integrated reviewed startup source and graph in',len(changes),'files; gate flags remain false')
