from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
out=Path('/work/native-application-zeroing-objtool-review-20260909-'+sys.argv[1]);out.mkdir()
source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2');build=Path('/work/native-build-base-24a151fe')
shutil.copyfile(__file__,out/'helper.py')
root=Path(subprocess.check_output(['rustc','--print','sysroot'],text=True).strip())
for path,name in [(root/'lib/rustlib/src/rust/library/alloc/src/vec/mod.rs','vec-mod.rs'),(build/'rust/alloc.o','alloc.o'),(build/'rust/.alloc.o.cmd','alloc-command.txt'),(source/'tools/objtool/check.c','check-before.c'),(build/'tools/objtool/objtool','objtool-before')]:shutil.copyfile(path,out/name)
(out/'rustc-version.txt').write_bytes(subprocess.check_output(['rustc','--version','--verbose']))
(out/'alloc-symbols.txt').write_bytes(subprocess.check_output(['nm','-S',str(out/'alloc.o')]))
(out/'alloc-disassembly.txt').write_bytes(subprocess.check_output(['objdump','-dr',str(out/'alloc.o')]))
data=(out/'vec-mod.rs').read_text();start=data.index('pub fn swap_remove(');end=data.index('\n    }',start)+6
print(data[start:end],flush=True)
assert re.search(r'fn assert_failed\(index: usize, len: usize\) -> !',data[start:end])
record=dict(status='PASS',utc=datetime.now(timezone.utc).isoformat(),scope='Exact compiler library source/alloc object and old objtool before adapting its noreturn classifier',files=[])
for path in sorted(out.iterdir()):
    if path.is_file():record['files'].append(dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print('PASS',out,flush=True)
