from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-return-adapter-20260908-'+sys.argv[1]);out.mkdir()
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),status='RUNNING',commands=[],extracted_bodies=[],source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Actual native WAIT/RET adapter methods with controlled user copy and backend effects. Real PID/MM/transport require independent guest evidence.',production_gate_credit=False)
def identity(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,args):
 print('RUN',label,flush=True)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append(dict(label=label,command=args,exit_code=r.returncode));assert r.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])
try:
 shutil.copyfile(__file__,out/'helper.py')
 inputs=['host-kernel/native-rust/mcctrl_process.rs','scripts/tests/fixtures/native-application-return-adapter.rs','executer/user/rust/mcexec_helpers.rs','executer/user/mcexec.c','executer/kernel/mcctrl/rust/mcctrl_helpers.rs','executer/kernel/mcctrl/control.c','executer/kernel/mcctrl/syscall.c','executer/include/uprotocol.h']
 for name in inputs:
  p=out/'original-inputs'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,p)
 record['inputs']=[identity(out/'original-inputs'/name) for name in inputs]
 data=(repo/inputs[0]).read_text();bodies=[]
 for name in ['wait_syscall','return_syscall']:
  m=re.search(r'^    fn '+name+r'\(',data,re.M);assert m,name
  start=m.start();end=data.index('{',start)+1;depth=1
  while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
  body=data[start:end];bodies.append(body);record['extracted_bodies'].append(dict(name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
 (out/'native-application-return-adapter-methods.rs').write_text('impl Registration {\n'+'\n'.join(bodies)+'\n}\n')
 shutil.copyfile(repo/inputs[1],out/'native-application-return-adapter.rs')
 run('diff-check',['git','-C',str(repo),'diff','--check'])
 run('format',['rustfmt','--edition','2021',str(out/'native-application-return-adapter.rs')])
 run('build',['rustc','--edition','2021','-D','warnings','--test',str(out/'native-application-return-adapter.rs'),'-o',str(out/'adapter-tests')])
 run('tests',[str(out/'adapter-tests'),'--nocapture'])
 record.update(status='PASS',tests=5,compiler_inputs=[identity(out/'native-application-return-adapter.rs'),identity(out/'native-application-return-adapter-methods.rs')])
except BaseException as e:record.update(status='FAIL',error=str(e));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(p) for p in out.iterdir() if p.is_file() and p.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
