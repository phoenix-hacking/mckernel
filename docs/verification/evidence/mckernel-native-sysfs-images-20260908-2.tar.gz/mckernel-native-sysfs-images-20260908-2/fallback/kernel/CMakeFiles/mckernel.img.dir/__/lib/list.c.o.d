kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o: \
 /work/mckernel-native-sysfs-images-20260908-2/source/lib/list.c \
 /work/mckernel-native-sysfs-images-20260908-2/source/lib/include/list.h
