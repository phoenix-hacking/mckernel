kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-sysfs-images-20260908-2/source/kernel/copy.c
