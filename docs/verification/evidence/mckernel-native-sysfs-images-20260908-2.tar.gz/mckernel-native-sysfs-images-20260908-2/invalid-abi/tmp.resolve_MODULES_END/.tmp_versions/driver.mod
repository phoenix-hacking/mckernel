/work/mckernel-native-sysfs-images-20260908-2/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-sysfs-images-20260908-2/invalid-abi/tmp.resolve_MODULES_END/driver.o

