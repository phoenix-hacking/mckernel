"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual new selected metadata bytes and allocated RELA; old anonymous debt stays open.
"""
from pathlib import Path
import ast
import hashlib
import json
import struct
D = Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-10-current-union-successor-source-1')
O = D / "output-1"
P = json.loads((D / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
C = json.loads((D / "PROVIDER-CONTRACT.FROZEN78-PLUS-F04100.json").read_bytes())
row = P["Elf_source"]
raw = Path(row["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
t = ast.parse(raw)
nodes = [n for n in t.body if isinstance(n, (ast.Import, ast.ImportFrom)) or isinstance(n, ast.ClassDef) and n.name == "Elf" or isinstance(n, ast.FunctionDef) and n.name in {"object_bytes", "owning_relocations"}]
ns = dict(Path=Path, struct=struct)
exec(compile(ast.Module(body=nodes, type_ignores=[]), row["path"], "exec"), ns)
Elf = ns["Elf"]
object_bytes = ns["object_bytes"]
owning_relocations = ns["owning_relocations"]
rust = Elf(O / "mckernel_rust.cpu37.o")
process = Elf(O / "process.selected.o")
partial = Elf(O / "CPU37.partial.o")
reference_row = C["source10_actual_fixture"]
reference_raw = Path(reference_row["path"]).read_bytes()
assert hashlib.sha256(reference_raw).hexdigest() == reference_row["sha256"]
reference = Elf(Path(reference_row["path"]))
def defined(elf, predicate):
    rows = [r for r in elf.symbols if r["type"] == 1 and 0 < r["shndx"] < len(elf.sections) and predicate(r)]
    assert len(rows) == 1, rows
    return rows[0]
DECLARED_DEBUG_SYMBOLS = {'ENTER_DEBUG': '_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy26f06_full_do_kill_candidate11ENTER_DEBUG', 'IPI_DEBUG': '_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy28f06_do_kill_wakeup_candidate9IPI_DEBUG'}
def exact_declared_debug(elf, marker):
    name = DECLARED_DEBUG_SYMBOLS[marker]
    rows = [row for row in elf.symbols if row["name"] == name]
    assert len(rows) == 1, (marker, name, rows)
    symbol = rows[0]
    assert symbol["bind"] == 1 and symbol["type"] == 1, symbol
    assert 0 < symbol["shndx"] < len(elf.sections), symbol
    assert 0 <= symbol["index"] < len(elf.symbols), symbol
    other_offset = elf.table["offset"] + symbol["index"] * elf.table["entsize"] + 5
    # Exact retained Rust/partial records expose GLOBAL OBJECT / DEFAULT0.
    assert elf.raw[other_offset] == 0, (marker, "unexpected symbol visibility")
    return symbol

def cstring(elf, relocation):
    target = relocation["target"]
    assert relocation["type"] == 1 and 0 < target["shndx"] < len(elf.sections)
    section = elf.sections[target["shndx"]]
    assert section["flags"] & 2
    payload = elf.payload(section)
    start = target["value"] + relocation["addend"]
    assert 0 <= start < len(payload)
    return payload[start:payload.index(b"\0", start)].decode()
def descriptor(elf, symbol, filename, function, line):
    section = elf.sections[symbol["shndx"]]
    assert symbol["size"] == 32 and symbol["value"] % 8 == 0
    assert section["name"] == "__verbose" and section["flags"] & 3 == 3 and not section["flags"] & 4
    assert section["align"] >= 8
    initial = object_bytes(elf, symbol)
    assert initial[:24] == bytes(24) and initial[28:] == bytes(4)
    assert int.from_bytes(initial[24:28], "little") == line
    relas = owning_relocations(elf, symbol)
    assert len(relas) == 2 and {r["offset"] for r in relas} == {0, 8}
    for rela in relas:
        assert cstring(elf, rela) == (filename if rela["offset"] == 0 else function)
    return dict(symbol=symbol, initial_hex=initial.hex(), relocations=relas, filename=filename, function=function, line=line)
def allocated_edges(elf, symbol=None, external=None):
    edges = []
    for section in elf.sections:
        if section["type"] != 4 or not elf.sections[section["info"]]["flags"] & 2:
            continue
        assert section["link"] == elf.table["index"] and section["entsize"] == 24
        for at in range(section["offset"], section["offset"] + section["size"], 24):
            offset, info, addend = struct.unpack_from("<QQq", elf.raw, at)
            assert offset < elf.sections[section["info"]]["size"] and info >> 32 < len(elf.symbols)
            target = elf.symbols[info >> 32]
            owns = external is not None and target["name"] == external
            if symbol is not None and target["shndx"] == symbol["shndx"]:
                where = target["value"] + addend
                owns = owns or symbol["value"] <= where < symbol["value"] + symbol["size"]
            if owns:
                edges.append(dict(owner=section["info"], offset=offset, relocation_type=info & 0xffffffff, target=target, addend=addend))
    assert edges, (symbol, external, "no actual allocated consumer edge")
    return edges
reference_symbol = defined(reference, lambda r: r["name"] == "process_create_cpu_debug")
expected_initial = object_bytes(reference, reference_symbol)
assert expected_initial[24:28] == struct.pack("<I", 276)
process_proof = {}
for label, elf in (("selected_C", process), ("partial", partial)):
    symbol = defined(elf, lambda r: r["name"] == "process_create_cpu_debug")
    assert symbol["bind"] == 1 and object_bytes(elf, symbol) == expected_initial
    process_proof[label] = descriptor(elf, symbol, str(D / "source/kernel/process.c"), "process_create_cpu_log_bridge", 276)
    line = defined(elf, lambda r: r["name"] == "process_create_thread_alloc_pages_source_line")
    assert line["bind"] == 1 and line["size"] == 4
    assert object_bytes(elf, line) == struct.pack("<i", 788)
    assert elf.sections[line["shndx"]]["flags"] & 2 and not elf.sections[line["shndx"]]["flags"] & 5
    assert not owning_relocations(elf, line)
process_edges = {name: allocated_edges(rust, external=name) for name in ("process_create_cpu_debug", "process_create_thread_alloc_pages_source_line")}
policy = D / "source/kernel/rust/syscall_policy.rs"
lines = policy.read_text().splitlines()
arch_proof = {}
for marker in ("ENTER_DEBUG", "IPI_DEBUG"):
    starts = [i for i, line in enumerate(lines) if "static mut " + marker + ":" in line]
    assert len(starts) == 1
    start = starts[0]
    line_numbers = [i + 1 for i in range(start, min(start + 10, len(lines))) if "line_flags: line!()" in lines[i]]
    assert len(line_numbers) == 1
    pair = {}
    for label, elf in (("Rust", rust), ("partial", partial)):
        symbol = exact_declared_debug(elf, marker)
        pair[label] = descriptor(elf, symbol, str(policy), "do_kill", line_numbers[0])
        if label == "Rust":
            pair["actual_allocated_consumer_edges"] = allocated_edges(elf, symbol=symbol)
    assert pair["Rust"]["initial_hex"] == pair["partial"]["initial_hex"]
    arch_proof[marker] = pair
f03 = Elf(O / "F03.selected.o")
scheduler_row = C["scheduler_fixture"]
assert hashlib.sha256(Path(scheduler_row["path"]).read_bytes()).hexdigest() == scheduler_row["sha256"]
scheduler_reference = Elf(Path(scheduler_row["path"]))
expected_debug = defined(scheduler_reference, lambda r: r["name"] == "f03_sched_setparam_debug_v1")
expected_bytes = object_bytes(scheduler_reference, expected_debug)
assert expected_bytes[24:28] == struct.pack("<I", 26052)
scheduler_proof = {}
for label, elf in (("selected_C", f03), ("partial", partial)):
    symbol = defined(elf, lambda r: r["name"] == "f03_sched_setparam_debug_v1")
    assert symbol["bind"] == 1 and object_bytes(elf, symbol) == expected_bytes
    scheduler_proof[label] = descriptor(elf, symbol, str(D / "source/kernel/syscall.c"), "sched_setparam_log_bridge", 26052)
scheduler_edges = allocated_edges(rust, external="f03_sched_setparam_debug_v1")

# New exact named arrays: use the accepted 32-byte descriptor checker for each member.
def array_descriptors(elf, name, filename, function, expected_lines):
    symbol = defined(elf, lambda row: row["name"] == name)
    assert symbol["bind"] == 1 and symbol["size"] == 32 * len(expected_lines)
    records = []
    for index, expected_line in enumerate(expected_lines):
        member = dict(symbol, value=symbol["value"] + index * 32, size=32)
        records.append(descriptor(elf, member, filename, function, expected_line))
    assert len(owning_relocations(elf, symbol)) == len(expected_lines) * 2
    return dict(symbol=symbol, records=records)
process36_metadata = {label: array_descriptors(elf, "process_ptrace_traceme_debug", str(D / "source/kernel/process.c"), "process_ptrace_traceme_log_bridge", [236,240,243]) for label, elf in (("selected_C",process),("partial",partial))}
process36_edges = allocated_edges(rust, external="process_ptrace_traceme_debug")
signal_metadata = {label: array_descriptors(elf, "f03_kill_log_debug_v1", str(D / "source/kernel/syscall.c"), "syscall_kill_log_bridge", [8313,8315]) for label, elf in (("selected_C",f03),("partial",partial))}
signal_edges = allocated_edges(rust, external="f03_kill_log_debug_v1")
ptrace_start = next(i for i,line in enumerate(lines) if "pub static mut arch_ptrace_user_log_debug_v1:" in line)
ptrace_lines = [i+1 for i in range(ptrace_start,ptrace_start+20) if "line_flags: line!()" in lines[i]]
assert len(ptrace_lines) == 2
ptrace_metadata = {label: array_descriptors(elf, "arch_ptrace_user_log_debug_v1", str(policy), "arch_ptrace_user_log_bridge", ptrace_lines) for label,elf in (("Rust",rust),("partial",partial))}
ptrace_edges = allocated_edges(rust, symbol=defined(rust, lambda row: row["name"] == "arch_ptrace_user_log_debug_v1"))

def verify_tracked_free_line_cell(symbol, section, initial, relas):
    assert symbol["bind"] == 1 and symbol["type"] == 1 and symbol["size"] == 4
    assert section["flags"] & 2 and not section["flags"] & 5
    assert symbol["value"] % 4 == 0 and section["align"] >= 4
    assert initial == struct.pack("<i", 3501)
    assert not relas
    return dict(symbol=symbol, section=section, initial_hex=initial.hex(), relocations=relas)
tracked_free_line = {}
for label, elf in (("selected_C",process),("partial",partial)):
    symbol = defined(elf, lambda row: row["name"] == "process_free_thread_pages_source_line")
    tracked_free_line[label] = verify_tracked_free_line_cell(symbol, elf.sections[symbol["shndx"]], object_bytes(elf,symbol), owning_relocations(elf,symbol))
assert tracked_free_line["selected_C"]["initial_hex"] == tracked_free_line["partial"]["initial_hex"]
tracked_free_line_edges = allocated_edges(rust, external="process_free_thread_pages_source_line")

# New process debug descriptors retain genuine C identities; no filename normalization.
new_process = {}
for record in C["process_new3_metadata"]["descriptor_records"]:
    name=record["symbol"]
    if name=="process_free_range_body_debug":
        continue  # The genuine three-record array is checked below with per-record functions.
    pair={}
    for label,elf in (("selected_C",process),("partial",partial)):
        symbol=defined(elf,lambda row:row["name"]==name)
        assert symbol["bind"]==1
        pair[label]=descriptor(elf,symbol,str(D/"source/kernel/process.c"),record["func"],record["line"])
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,external=name)
    new_process[name]=pair
free_records=[]
for label,elf in (("selected_C",process),("partial",partial)):
    symbol=defined(elf,lambda row:row["name"]=="process_free_range_body_debug")
    assert symbol["bind"]==1 and symbol["size"]==96
    values=[]
    for index,(function,line) in enumerate((("process_free_range_log_bridge",1947),("process_free_range_log_bridge",1955),("free_process_memory_range",1964))):
        values.append(descriptor(elf,dict(symbol,value=symbol["value"]+index*32,size=32),str(D/"source/kernel/process.c"),function,line))
    assert len(owning_relocations(elf,symbol))==6
    free_records.append(dict(label=label,symbol=symbol,records=values))
free_record_edges=allocated_edges(rust,external="process_free_range_body_debug")
new_readonly={}
for name,value in (("process_free_range_pages_source_line",1873),("process_page_fault_anon_clear_profile_event",4002)):
    pair={}
    for label,elf in (("selected_C",process),("partial",partial)):
        symbol=defined(elf,lambda row:row["name"]==name);section=elf.sections[symbol["shndx"]]
        assert symbol["bind"]==1 and symbol["size"]==4 and symbol["value"]%4==0
        assert section["flags"]&2 and not section["flags"]&5 and section["align"]>=4
        initial=object_bytes(elf,symbol);assert initial==struct.pack("<i",value) and not owning_relocations(elf,symbol)
        pair[label]=dict(symbol=symbol,initial_hex=initial.hex())
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,external=name);new_readonly[name]=pair
# Profile constant is meaningful only for this exact paired current profile.
recipe=json.loads((D/"EXACT-CURRENT230-COMMANDS.NOT-GRANTED.json").read_bytes())
assert "-DPROFILE_ENABLE" in recipe["commands"][0]["argv"]
assert "enable_profile" in recipe["commands"][8]["argv"]
new_arch={}
for name,count in (("arch_mmap_log_debug_v1",2),("arch_shmget_log_debug_v1",2),("arch_vdso_public_log_debug_v1",4)):
    start=next(i for i,line in enumerate(lines) if "pub static mut "+name+":" in line)
    end=next(i for i in range(start+1,len(lines)) if lines[i].strip()=="];")
    expected_lines=[i+1 for i in range(start,end) if "line_flags: line!()" in lines[i]]
    assert len(expected_lines)==count
    function=name.replace("_debug_v1","_bridge")
    pair={label:array_descriptors(elf,name,str(policy),function,expected_lines) for label,elf in (("Rust",rust),("partial",partial))}
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,symbol=defined(rust,lambda row:row["name"]==name))
    new_arch[name]=pair
# Dispatch descriptor and unchanged genuine sparse C table are independently bound.
reference_row=C["F03_dispatch_reference"]
assert hashlib.sha256(Path(reference_row["path"]).read_bytes()).hexdigest()==reference_row["sha256"]
dispatch_reference=Elf(Path(reference_row["path"]))
expected_table=defined(dispatch_reference,lambda row:row["name"]=="syscall_table")
expected_edges=owning_relocations(dispatch_reference,expected_table)
expected_slots={(r["offset"],r["type"],r["target"]["name"],r["addend"]) for r in expected_edges}
assert len(expected_slots)==117 and expected_table["size"]==4025*8
dispatch_proof={}
for label,elf in (("selected_C",f03),("partial",partial)):
    symbol=defined(elf,lambda row:row["name"]=="f03_syscall_dispatch_binding_v1")
    section=elf.sections[symbol["shndx"]]
    assert symbol["bind"]==1 and symbol["size"]==16 and symbol["value"]%8==0 and section["align"]>=8
    # Genuine GCC const relocation-bearing descriptor uses this precise RELRO input section.
    # Its ELF SHF_WRITE remains set before final linking; physical readonly protection is OPEN.
    assert section["name"]==".data.rel.ro.local" and section["flags"]==3
    assert object_bytes(elf,symbol)==bytes(8)+struct.pack("<Q",4025)
    relas=owning_relocations(elf,symbol);assert len(relas)==1
    rela=relas[0];target=rela["target"]
    assert rela["offset"]==0 and rela["type"]==1
    assert target["type"]==3 and target["bind"]==0 and 0<target["shndx"]<len(elf.sections)
    tables=[row for row in elf.symbols if row["name"]=="syscall_table" and row["type"]==1 and row["bind"]==0 and row["size"]==4025*8 and row["shndx"]==target["shndx"] and row["value"]==target["value"]+rela["addend"]]
    assert len(tables)==1,tables
    table=tables[0]
    assert 0<table["shndx"]<len(elf.sections) and elf.sections[table["shndx"]]["flags"]&2 and not elf.sections[table["shndx"]]["flags"]&4
    initial=object_bytes(elf,table);assert initial==bytes(4025*8)
    table_relas=owning_relocations(elf,table)
    assert len(table_relas)==117 and {(r["offset"],r["type"],r["target"]["name"],r["addend"]) for r in table_relas}==expected_slots
    dispatch_proof[label]=dict(descriptor=symbol,descriptor_relocations=relas,table=table,table_relocations=table_relas)
dispatch_edges=allocated_edges(rust,external="f03_syscall_dispatch_binding_v1")

result = dict(new_process=new_process,free_range_records=free_records,free_range_edges=free_record_edges,new_readonly=new_readonly,new_arch=new_arch,dispatch=dispatch_proof,dispatch_edges=dispatch_edges,tracked_free_line=tracked_free_line, tracked_free_line_edges=tracked_free_line_edges, process36=process36_metadata, process36_edges=process36_edges, signal_process=signal_metadata, signal_process_edges=signal_edges, ptrace_log=ptrace_metadata, ptrace_edges=ptrace_edges, status="PASS_NEW_SOURCE10_AND_F06_METADATA_ALLOCATED_RELA_ONLY", source10=process_proof, source10_allocated_edges=process_edges, F06=arch_proof, scheduler=scheduler_proof, scheduler_edges=scheduler_edges, historical_23_anonymous_edges="OPEN", SDK=False, native=False, production_default=False)
with (Path(__file__).parent / "ACTUAL-NEW-METADATA-RELA.EXACT-SYMBOLS.json").open("x") as out:
    json.dump(result, out, sort_keys=True, indent=2)
    out.write("\n")
print(json.dumps(dict(status=result["status"], source10_descriptors=1, F06_descriptors=2)))
