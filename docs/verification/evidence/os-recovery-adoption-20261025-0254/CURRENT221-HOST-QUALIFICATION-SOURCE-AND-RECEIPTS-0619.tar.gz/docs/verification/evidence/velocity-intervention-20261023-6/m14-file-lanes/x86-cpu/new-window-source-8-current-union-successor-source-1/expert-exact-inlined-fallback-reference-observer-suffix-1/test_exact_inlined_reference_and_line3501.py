"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure exact O2 fallback caller and readonly3501 controls; no ELF/compiler.
"""
from pathlib import Path
import ast,copy,json,struct
N=Path(__file__).parent
main=ast.parse((N/'observe_current221.EXPERT-INLINED-REFERENCE.py').read_text())
nodes=[n for n in main.body if isinstance(n,ast.FunctionDef) and n.name in {'definitions','verify_free_thread_pages_reference'} or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FREE_THREAD_PAGES_REFERENCE_BYTES' for t in n.targets)]
ns={'ns':{'object_bytes':lambda elf,row:elf.blob,'owning_relocations':lambda elf,row:elf.relas}}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-caller-helper>','exec'),ns)
class Fake:
 def payload(self,section):return self.filename
x=Fake();x.sections=[{},dict(name='.text',flags=6),dict(name='.rodata',flags=2)]
x.symbols=[dict(name='process_free_thread_pages_bridge',bind=1,type=2,shndx=1,value=0,size=79)]
x.blob=ns['FREE_THREAD_PAGES_REFERENCE_BYTES'];x.filename=b'/private/current/process.c\0'
x.relas=[dict(offset=24,type=29,target=dict(name='_GLOBAL_OFFSET_TABLE_',bind=1,type=0,shndx=0),addend=20),dict(offset=34,type=25,target=dict(name='.LC0',bind=0,type=0,shndx=2,value=0),addend=0),dict(offset=63,type=31,target=dict(name='_ihk_mc_free_pages',bind=1,type=0,shndx=0),addend=0)]
check=ns['verify_free_thread_pages_reference'];check(x,'/private/current/process.c')
cases=[]
def reject(label,change):
 y=copy.deepcopy(x);change(y)
 try:check(y,'/private/current/process.c')
 except AssertionError:cases.append(label)
 else:raise AssertionError(label)
reject('missing public bridge',lambda y:y.symbols.clear())
reject('duplicate public bridge',lambda y:y.symbols.append(dict(y.symbols[0])))
reject('local bridge',lambda y:y.symbols[0].update(bind=0))
reject('nonFUNCTION bridge',lambda y:y.symbols[0].update(type=1))
reject('helperintroduced',lambda y:y.symbols.append(dict(name='free_thread_pages',bind=0,type=2,shndx=1,value=100,size=1)))
reject('wrong79byte size',lambda y:y.symbols[0].update(size=78))
reject('line3501 instruction drift',lambda y:setattr(y,'blob',y.blob[:11]+b'\x00'+y.blob[12:]))
reject('pages32 instruction drift',lambda y:setattr(y,'blob',y.blob[:18]+b'\x01'+y.blob[19:]))
reject('codebyte drift',lambda y:setattr(y,'blob',b'\x00'+y.blob[1:]))
reject('wrongcallee target',lambda y:y.relas[2]['target'].update(name='wrong_free'))
reject('missing callerRELA',lambda y:y.relas.pop())
reject('wrong callerRELA type',lambda y:y.relas[2].update(type=1))
reject('wrong callerRELA addend',lambda y:y.relas[0].update(addend=0))
reject('wrongfilename bytes',lambda y:setattr(y,'filename',b'/private/other/process.c\0'))
reject('filename notterminated',lambda y:setattr(y,'filename',b'/private/current/process.cX'))
reject('writable filename section',lambda y:y.sections[2].update(flags=3))
meta=ast.parse((N/'observe_new_metadata.TRACKED-LINE3501.py').read_text());node=next(n for n in meta.body if isinstance(n,ast.FunctionDef) and n.name=='verify_tracked_free_line_cell');m={'struct':struct};exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-cell-helper>','exec'),m)
cell=m['verify_tracked_free_line_cell'];base=[dict(bind=1,type=1,size=4,value=0),dict(flags=2,align=4),struct.pack('<i',3501),[]];cell(*base)
for label,change in [('celllocalbinding',lambda a:a[0].update(bind=0)),('cellwrongtype',lambda a:a[0].update(type=2)),('cellwrongsize',lambda a:a[0].update(size=8)),('cellwritable',lambda a:a[1].update(flags=3)),('cellunallocated',lambda a:a[1].update(flags=0)),('cellunaligned',lambda a:a[0].update(value=1)),('cellwrongline',lambda a:a.__setitem__(2,struct.pack('<i',3502))),('cellunexpectedRELA',lambda a:a[3].append({}))]:
 a=copy.deepcopy(base);change(a)
 try:cell(*a)
 except AssertionError:cases.append(label)
 else:raise AssertionError(label)
# The accepted allocated-edge helper's rejection behavior is unchanged, and is exercised directly.
nodes=[n for n in meta.body if isinstance(n,ast.FunctionDef) and n.name=='allocated_edges'];m={'struct':struct};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<unchanged-edge-helper>','exec'),m)
y=Fake();y.sections=[]
try:m['allocated_edges'](y,external='process_free_thread_pages_source_line')
except AssertionError:cases.append('missing actual allocated consumer edge')
else:raise AssertionError('missing consumer accepted')
with (N/'ACTUAL-PURE-INLINED-REFERENCE-AND-LINE3501.json').open('x') as f:json.dump(dict(status='PASS_PURE_ACTUAL_NEW_HELPERS',positive=2,negative=len(cases),negative_labels=cases,ELF=False,compiler=False),f,indent=2)
print(json.dumps(dict(status='PASS_PURE_ACTUAL_NEW_HELPERS',positive=2,negative=len(cases))))
