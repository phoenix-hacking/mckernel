"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read fresh selected architecture ELF against its exact retained COMMON inventory.
"""
from pathlib import Path
import ast
import hashlib
import json
import struct
D = Path(__file__).parent
C = json.loads((D / "PROVIDER-CONTRACT.FROZEN78-PLUS-F04100.json").read_bytes())
P = json.loads((D / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
r = P["Elf_source"]
raw = Path(r["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == r["sha256"]
t = ast.parse(raw)
nodes = [n for n in t.body if isinstance(n, (ast.Import, ast.ImportFrom)) or isinstance(n, ast.ClassDef) and n.name == "Elf"]
ns = dict(Path=Path, struct=struct)
exec(compile(ast.Module(body=nodes, type_ignores=[]), r["path"], "exec"), ns)
e = ns["Elf"](D / "output-1/f06-arch-selected.o")
common = [r for r in e.symbols if r["shndx"] == 0xfff2]
assert C["F06_COMMON"] == {} and common == [], common
result = dict(status="PASS_FRESH_SELECTED_ARCH_EXACT_COMMON_EMPTY_BEFORE_LINK", expected=C["F06_COMMON"], actual=common, historical=C["F06_COMMON_receipt"])
with (D / "output-1/ACTUAL-SELECTED-ARCH-COMMON.json").open("x") as out:
    json.dump(result, out, sort_keys=True, indent=2)
    out.write("\n")
print(json.dumps(result))
