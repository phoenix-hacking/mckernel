"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read actual final-union ELF symbols; no compiler or runtime operation.
"""
from pathlib import Path
import ast
import hashlib
import json
import struct
D = Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1')
P = json.loads((D / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
C = json.loads(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/bounded-exact-C-filename-observer-suffix-1/PROVIDER-CONTRACT.EXACT-C-FILENAME.json').read_bytes())
def verify_exact_filename_binding(filename, producer_argv, frozen_filename):
    # Do not normalize: C __FILE__ string bytes follow the actual -c argv spelling.
    assert producer_argv.count("-c") == 1
    source_argument = producer_argv[producer_argv.index("-c") + 1]
    assert filename == source_argument == frozen_filename, (filename, source_argument, frozen_filename)
    return source_argument

producer = json.loads((D / "actual-current221-attempt-1/00/command.json").read_bytes())
verify_exact_filename_binding(C["trace_filename"], producer["argv"], str(D / "source/kernel/process.c"))

row = P["Elf_source"]
raw = Path(row["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
tree = ast.parse(raw)
nodes = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom)) or isinstance(n, ast.ClassDef) and n.name == "Elf" or isinstance(n, ast.FunctionDef) and n.name in {"owning_relocations", "object_bytes"}]
ns = {"Path": Path, "struct": struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), row["path"], "exec"), ns)
Elf = ns["Elf"]
O = D / "output-1"
def definitions(elf, name):
    return [r for r in elf.symbols if r["name"] == name and 0 < r["shndx"] < len(elf.sections)]
def globals_of(elf):
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and r["type"] == 2 and 0 < r["shndx"] < len(elf.sections)}
def unresolved(elf):
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and r["shndx"] == 0}
rust = Elf(O / "mckernel_rust.cpu37.o")
partial = Elf(O / "CPU37.partial.o")
process = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/output-1/process.selected.o'))
f03 = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/output-1/F03.selected.o'))
f04 = Elf(Path("/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-3/ordinary-HOST-qualification-preparation-1/bounded-C-include-namespace-transport-correction-1/output-1/F04.selected.o"))
arch = Elf(O / "f06-arch-selected.o")
proof = {}
for name in C["combined55"] + C["F04_100"]:
    result = {}
    for label, elf in (("Rust", rust), ("combined_partial", partial)):
        rows = definitions(elf, name)
        assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2, (label, name, rows)
        assert name not in unresolved(elf), (label, name, "unresolved provider")
        result[label] = rows
    for label, elf in (("process_C", process), ("F03_C", f03), ("F04_C", f04), ("F06_C", arch)):
        assert not definitions(elf, name), (label, name, "C definition remains")
    proof[name] = result
components = [rust, process, f03, f04, arch]
# Include all global defined symbols when calculating undefined resolution;
# defined data and assembly symbols can resolve ordinary C/Rust externals.
COMMON_PROCESS = {"resource_set_list": 16, "resource_set_lock": 64, "runq_reservation_lock": 4}
COMMON_F03 = {"linux_clock_gettime": 8, "linux_printk": 8, "linux_wait_event": 8,
              "shmid_index": 4096, "uti_desc": 8}
COMMON_EXPECTED = {id(rust): {}, id(process): COMMON_PROCESS, id(f03): COMMON_F03,
                   id(f04): {}, id(arch): C["F06_COMMON"], id(partial): {**COMMON_PROCESS, **COMMON_F03, **C["F06_COMMON"]}}
def global_defs(elf):
    common = [r for r in elf.symbols if r["shndx"] == 0xfff2]
    expected = COMMON_EXPECTED[id(elf)]
    assert len(common) == len(expected), ("COMMON cardinality", common, expected)
    assert {r["name"]: r["size"] for r in common} == expected, ("COMMON names/sizes", common, expected)
    for row in common:
        alignment = row["value"]
        assert row["bind"] == 1 and row["type"] == 1 and row["size"] > 0, row
        assert alignment > 0 and alignment & (alignment - 1) == 0, row
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and
            (0 < r["shndx"] < len(elf.sections) or
             r["shndx"] == 0xfff2 and r["type"] == 1)}
# SHN_COMMON stores alignment in st_value; it is never a section-table index.
global_defs(partial)
all_defined = set().union(*(global_defs(e) for e in components))
all_undefined = set().union(*(unresolved(e) for e in components))
assert globals_of(partial) == set().union(*(globals_of(e) for e in components))
assert unresolved(partial) == all_undefined - all_defined
fallback = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/output-1/process.fallback.o'))
for name, expected in C["process_fallback_expected"].items():
    rows = definitions(fallback, name)
    assert len(rows) == 1 and rows[0]["type"] == 2, (name, rows)
    assert rows[0]["bind"] == (1 if expected == ["T"] else 0), (name, expected, rows)
for label in ("mincore_real_C_ABI_object", "mincore_fallback_C"):
    row = C[label]
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
real_abi = Elf(Path(C["mincore_real_C_ABI_object"]["path"]))
expected_abi = real_abi.data("f03_mincore_C_ABI")
assert len(expected_abi) == 21 * 8
assert rust.data("f03_mincore_Rust_ABI") == partial.data("f03_mincore_Rust_ABI") == expected_abi
mincore_fallback = Elf(Path(C["mincore_fallback_C"]["path"]))
rows = definitions(mincore_fallback, "sys_mincore")
assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2
source8_reference = Elf(Path(C["source8_actual_C_fixture"]["path"]))
expected_source8_abi = source8_reference.data("C_ABI")
assert len(expected_source8_abi) == 12 * 8
assert rust.data("SOURCE8_RUST_ABI") == partial.data("SOURCE8_RUST_ABI") == expected_source8_abi
trace_row = C["trace_observer"]
trace_raw = Path(trace_row["path"]).read_bytes()
assert hashlib.sha256(trace_raw).hexdigest() == trace_row["sha256"]
trace_ns = {}
exec(compile(trace_raw, trace_row["path"], "exec"), trace_ns)
trace_proof = {label: trace_ns["observe"](path, C["trace_lines"], C["trace_filename"]) for label, elf, path in (("selected_C",process,Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/output-1/process.selected.o')),("partial",partial,O/"CPU37.partial.o"))}


# Exact new export and six own C callbacks, with real readonly C/Rust 30-word ABI.
move_fallback = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1/output-1/F03.fallback.o'))
move_abi = f03.data("f03_move_pages_C_ABI")
assert len(move_abi) == 30 * 8
assert move_fallback.data("f03_move_pages_C_ABI") == move_abi
assert rust.data("f03_move_pages_Rust_ABI") == partial.data("f03_move_pages_Rust_ABI") == move_abi
for name in ["move_pages_verify_bridge", "move_pages_get_nr_nodes_bridge", "move_pages_page_table_lock_bridge", "move_pages_page_table_unlock_bridge", "move_pages_smp_call_bridge", "move_pages_log_bridge"]:
    assert not definitions(f03,name), name
    rows=definitions(move_fallback,name)
    assert len(rows)==1 and rows[0]["type"]==2 and rows[0]["bind"]==0, (name,rows)
rows=definitions(move_fallback,"sys_move_pages")
assert len(rows)==1 and rows[0]["bind"]==1 and rows[0]["type"]==2

# Exact Source10 leaves: the allocation adapter was selector-only in original C.
for name, expected in C["source10_fallback_expected"].items():
    rows = definitions(fallback, name)
    if not expected:
        assert not rows, (name, rows)
    else:
        assert len(rows) == 1 and rows[0]["type"] == 2 and rows[0]["bind"] == 1, (name, rows)
for name in ("process_create_cpu_debug", "process_create_thread_alloc_pages_source_line"):
    assert not definitions(fallback, name), (name, "metadata unexpectedly selected under RustOFF")
source10_reference_row = C["source10_actual_fixture"]
assert hashlib.sha256(Path(source10_reference_row["path"]).read_bytes()).hexdigest() == source10_reference_row["sha256"]
source10_reference = Elf(Path(source10_reference_row["path"]))
source10_abi = source10_reference.data("C_ABI")
assert len(source10_abi) == 12 * 8
assert rust.data("SOURCE10_RUST_ABI") == partial.data("SOURCE10_RUST_ABI") == source10_abi
arch_abi = Elf(Path(C["F06_ABI45_reused"]["path"]))
assert hashlib.sha256(Path(C["F06_ABI45_reused"]["path"]).read_bytes()).hexdigest() == C["F06_ABI45_reused"]["sha256"]
arch_abi_bytes = arch_abi.data("F06_DO_KILL_C_ABI45")
assert len(arch_abi_bytes) == 45 * 8
assert rust.data("F06_DO_KILL_RUST_ABI45") == partial.data("F06_DO_KILL_RUST_ABI45") == arch_abi_bytes
arch_fallback = Elf(O / "f06-arch-fallback.o")
rows = definitions(arch_fallback, "do_kill")
assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2
for name in C["source6_arch_new8"]:
    assert not definitions(arch, name)
    if name != "do_kill":
        assert not definitions(arch_fallback, name), (name, "new Rust helper has no original C function")

# Scheduler actual full-TU typed-address witnesses and real nine ABI words.
scheduler_ref_row = C["scheduler_fixture"]
assert hashlib.sha256(Path(scheduler_ref_row["path"]).read_bytes()).hexdigest() == scheduler_ref_row["sha256"]
scheduler_reference = Elf(Path(scheduler_ref_row["path"]))
scheduler_abi = scheduler_reference.data("f03_sched_C_ABI")
assert len(scheduler_abi) == 9 * 8
assert f03.data("f03_sched_C_ABI") == move_fallback.data("f03_sched_C_ABI") == scheduler_abi
assert rust.data("f03_sched_Rust_ABI") == partial.data("f03_sched_Rust_ABI") == scheduler_abi
scheduler_addresses = {}
for name in C["source6_scheduler_new7"]:
    assert not definitions(f03, name)
    rows = definitions(move_fallback, name)
    assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2, (name, rows)
    address_proof = {}
    for label, elf in (("selected_C", f03), ("partial", partial)):
        row = elf.sym("f03_actual_address_" + name)
        assert row["bind"] == 1 and row["type"] == 1 and row["size"] == 8
        assert 0 < row["shndx"] < len(elf.sections) and elf.sections[row["shndx"]]["flags"] & 2
        assert ns["object_bytes"](elf, row) == bytes(8)
        relas = ns["owning_relocations"](elf, row)
        assert len(relas) == 1 and relas[0]["offset"] == 0 and relas[0]["type"] == 1 and relas[0]["addend"] == 0
        assert relas[0]["target"]["name"] == name
        address_proof[label] = dict(symbol=row, relocations=relas)
    scheduler_addresses[name] = address_proof
assert not definitions(move_fallback, "f03_sched_setparam_debug_v1")

ptrace6 = arch.data("F06_PTRACE_C_ABI6")
assert len(ptrace6) == 48
assert arch_fallback.data("F06_PTRACE_C_ABI6") == rust.data("F06_PTRACE_RUST_ABI6") == partial.data("F06_PTRACE_RUST_ABI6") == ptrace6

# New process36 original fallback scopes and exact genuine owning Page ABI.
for name in C["process_new36"]:
    rows = definitions(fallback, name)
    absent = name.startswith("process_ptrace_")
    if absent:
        assert not rows, (name, "historically selector-only fallback")
    else:
        assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2, (name, rows)
FREE_THREAD_PAGES_REFERENCE_BYTES = bytes.fromhex('f30f1efaf30f1efa5541b8ad0d000031d2be2000000049bb000000000000000048b800000000000000004889e541574c8d3dceffffff4d01df498d0c0748b800000000000000004c01f8415f5dffe0')
def verify_free_thread_pages_reference(elf, expected_filename):
    # This finite O2 reference intentionally inlines the source-only static helper.
    assert not [r for r in elf.symbols if r["name"] == "free_thread_pages"], "unexpected emitted helper"
    rows = definitions(elf, "process_free_thread_pages_bridge")
    assert len(rows) == 1
    row = rows[0]
    assert row["bind"] == 1 and row["type"] == 2 and row["size"] == 79
    section = elf.sections[row["shndx"]]
    assert section["name"] == ".text" and section["flags"] & 7 == 6
    assert ns["object_bytes"](elf, row) == FREE_THREAD_PAGES_REFERENCE_BYTES
    relas = ns["owning_relocations"](elf, row)
    expected = [(24,29,"_GLOBAL_OFFSET_TABLE_",20),(34,25,".LC0",0),(63,31,"_ihk_mc_free_pages",0)]
    assert len(relas) == 3
    assert [(r["offset"],r["type"],r["target"]["name"],r["addend"]) for r in relas] == expected
    for index in (0,2):
        target = relas[index]["target"]
        assert target["bind"] == 1 and target["type"] == 0 and target["shndx"] == 0
    target = relas[1]["target"]
    assert target["bind"] == 0 and target["type"] == 0 and 0 < target["shndx"] < len(elf.sections)
    string_section = elf.sections[target["shndx"]]
    assert string_section["flags"] & 2 and not string_section["flags"] & 5
    payload = elf.payload(string_section)
    start = target["value"] + relas[1]["addend"]
    expected_bytes = expected_filename.encode() + b"\0"
    assert start >= 0 and payload[start:start+len(expected_bytes)] == expected_bytes
    return dict(symbol=row, bytes_hex=FREE_THREAD_PAGES_REFERENCE_BYTES.hex(), relocations=relas, filename=expected_filename)

fallback_producer = json.loads((D / "actual-current221-attempt-1/01/command.json").read_bytes())
assert "-O2" in fallback_producer["argv"] and "-DMCKERNEL_RUST_PROCESS_HELPERS" not in fallback_producer["argv"]
assert fallback_producer["argv"][fallback_producer["argv"].index("-c")+1] == str(D / "source/kernel/process.c")
assert hashlib.sha256((D / "actual-current221-attempt-1/01/command.json").read_bytes()).hexdigest() == '061d4ab21745ec00dc4fe39a5b06f605d720178f55046d44572c5dfba1583a09'
assert hashlib.sha256((D / "runtime/kernel/process.c").read_bytes()).hexdigest() == '8c7508f418f6fe66c83d08c8d70a7ed78db302c489474084fb3f527a1263bfbe'
free_reference = verify_free_thread_pages_reference(fallback, str(D / "source/kernel/process.c"))
page7 = process.data("PROCESS_PAGE7_C_ABI")
assert len(page7) == 56 and list(struct.unpack("<7Q", page7)) == [80,8,64,8,8,40,48]
assert fallback.data("PROCESS_PAGE7_C_ABI") == rust.data("PROCESS_PAGE7_RUST_ABI") == partial.data("PROCESS_PAGE7_RUST_ABI") == page7
assert not definitions(fallback, "process_ptrace_traceme_debug")
signal_abi = f03.data("f03_signal_process_C_ABI")
assert len(signal_abi) == 96
assert move_fallback.data("f03_signal_process_C_ABI") == rust.data("f03_signal_process_Rust_ABI") == partial.data("f03_signal_process_Rust_ABI") == signal_abi
for name in C["signal_process_new6"]:
    rows = definitions(move_fallback, name)
    assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2, (name, rows)
    for elf in (f03, partial):
        row = elf.sym("f03_actual_address_" + name)
        assert row["bind"] == 1 and row["type"] == 1 and row["size"] == 8
        assert 0 < row["shndx"] < len(elf.sections) and elf.sections[row["shndx"]]["flags"] & 2
        assert ns["object_bytes"](elf, row) == bytes(8)
        relas = ns["owning_relocations"](elf, row)
        assert len(relas) == 1 and relas[0]["offset"] == 0 and relas[0]["type"] == 1 and relas[0]["addend"] == 0
        assert relas[0]["target"]["name"] == name
assert not definitions(move_fallback, "f03_kill_log_debug_v1")
rows = definitions(arch_fallback, "arch_ptrace_user_log_bridge")
assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2
assert not definitions(arch, "arch_ptrace_user_log_bridge")
assert not definitions(arch_fallback, "arch_ptrace_user_log_debug_v1")

out = dict(free_thread_pages_reference=free_reference, status="PASS_CURRENT121_PLUS_F04100_PROVIDERS_ABI_AND_TRACE_ONLY", providers=proof, count=len(proof), scheduler_address_witnesses=scheduler_addresses, source8_ABI_hex=expected_source8_abi.hex(), trace_metadata=trace_proof, SDK=False, native=False, production_default=False)
with (Path(__file__).parent / "ACTUAL-UNION-PROVIDERS.COMMON-CORRECTED.json").open("x") as f:
    json.dump(out, f, indent=2, sort_keys=True)
    f.write("\n")
print(json.dumps(dict(status=out["status"], providers=len(proof))))
