"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure exact compiler-filename transport regression; no ELF or compiler operation.
"""
from pathlib import Path
import ast,json
E=Path(__file__).parent
T=ast.parse((E/'observe_current221.EXACT-C-FILENAME.py').read_text())
node=next(n for n in T.body if isinstance(n,ast.FunctionDef) and n.name=='verify_exact_filename_binding')
ns={};exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-filename-helper>','exec'),ns)
check=ns['verify_exact_filename_binding']
expected='/private/current/source/kernel/process.c'
assert check(expected,['gcc','-c',expected],expected)==expected
negatives=[('prior qualifier path','/private/old/source/kernel/process.c',['gcc','-c',expected]),('relativepath','source/kernel/process.c',['gcc','-c',expected]),('equivalent normalizedpath','/private/current/source/kernel/../kernel/process.c',['gcc','-c',expected]),('different filename',expected+'.other',['gcc','-c',expected]),('producer argv drift',expected,['gcc','-c','/private/other/process.c']),('missing source flag',expected,['gcc',expected]),('duplicate source flag',expected,['gcc','-c',expected,'-c',expected])]
for label,filename,argv in negatives:
 try:check(filename,argv,expected)
 except AssertionError:pass
 else:raise AssertionError(label)
with (E/'ACTUAL-EXACT-FILENAME-PURE-CASES.json').open('x') as f:json.dump(dict(status='PASS_PURE_EXACT_FILENAME_BINDING',positive=1,negative_labels=[x[0] for x in negatives],normalization=False,ELF_read=False,compiler=False),f,indent=2)
print('PASS exactfilename: onepositive sevennegatives; no ELF/compiler')
