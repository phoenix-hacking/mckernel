"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
ONE retained-only three-observer suffix, no compiler/link/prefix replay.
"""
from pathlib import Path
import json,hashlib,os,resource,signal,sys,time,math,importlib.util
E=Path(__file__).resolve().parent
D=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-8-current-union-successor-source-1')
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
assert os.getuid()==os.geteuid()==1000 and os.sched_getaffinity(0)=={6}
assert Path(sys.executable).resolve()==Path('/home/holden/anaconda3/bin/python3').resolve()
assert pin(H)['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
R=E/'EXACT-RETAINED-OBSERVER-SUFFIX10-12.NOT-GRANTED.json'
F=E/'FROZEN-RETAINED-SUFFIX-INPUTS.json'
assert pin(R)['sha256']=='1ad5476f29a82c5c45c6232d274d691c080cdf4bc0b18ee85a97b9c2f1072f14' and pin(F)['sha256']=='30d01b9a3af9d57fee58eaeeeeb35a971bdda160a23434c8cc1ddce397c3caef'
ready=E/'EXECUTABLE-READY.NOT-GRANTED.json'
grant=json.loads((E/'ROOT-GRANT.json').read_bytes())
assert grant['CPU']==6 and grant['ordinary_jobs']==1 and grant['ready_sha256']==pin(ready)['sha256']
assert json.loads(ready.read_bytes())['driver']==pin(Path(__file__))
recipe=json.loads(R.read_bytes());inputs=json.loads(F.read_bytes())
assert len(recipe['commands'])==4 and len(inputs['rows'])==inputs['count']
for row in inputs['rows']:
 assert pin(Path(row['path']))=={k:row[k] for k in ['path','sha256','bytes']}
 st=Path(row['path']).stat();assert all(getattr(st,k)==v for k,v in row['identity'].items())
O=E/'actual-retained-observer-suffix-attempt-1';assert not os.path.lexists(O)
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
host=os.statvfs(E);scratch=os.statvfs('/home/holden/mckernel-work/scratch');back=Path('/home/holden/mckernel-work/scratch.ext4').stat();gap=max(0,back.st_size-back.st_blocks*512)
facts=dict(MemAvailable=mem,HOST_available=host.f_bavail*host.f_frsize,scratch_available=scratch.f_bavail*scratch.f_frsize,full_sparse_gap=gap)
assert mem>=25501368320 and back.st_size==110<<30
assert facts['HOST_available']>=(16<<30)+gap+(128<<20)+679477248 and facts['scratch_available']>=(12<<30)+679477248
spec=importlib.util.spec_from_file_location('accepted_capture',H);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(sig,h.stop)
for key,value in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_STACK,2<<20),(resource.RLIMIT_CORE,0)]:resource.setrlimit(key,(value,value))
os.environ['RUST_MIN_STACK']='2097152';os.environ['PYTHONDONTWRITEBYTECODE']='1';os.umask(0o077)
O.mkdir(mode=0o700);h.write(O/'FRESH-ADMISSION.json',dict(inputs=pin(F),recipe=pin(R),facts=facts,grant=pin(E/'ROOT-GRANT.json')))
begin=time.monotonic();results=[];active=None
previous=os.open('.',os.O_RDONLY|os.O_DIRECTORY)
os.chdir(D)
signal.setitimer(signal.ITIMER_REAL,96)
try:
 for i,command in enumerate(recipe['commands']):
  assert command['cwd']==str(D) and command['argv'][0]=='/home/holden/anaconda3/bin/python3'
  step=O/('09b-pure' if i==0 else '%02d'%(i+9));step.mkdir(mode=0o700);h.write(step/'command.json',command)
  remaining=90-(time.monotonic()-begin);cpu=60-h.cpu_used();assert remaining>0 and cpu>0
  def limits():
   limit=max(1,int(math.ceil(cpu)));resource.setrlimit(resource.RLIMIT_CPU,(limit,limit))
  active=str(step);result=h.owned_capture(command,step,remaining,limits);h.write(step/'WHOLE-JOIN.json',result);results.append(result);active=None
  assert result['returncode']==0 and result['direct_child_joined'] and result['group_absent'] and result['closed_streams'] and not result['timed_out'] and result['error'] is None and result['retirement_error'] is None
 for row in inputs['rows']:
  st=Path(row['path']).stat();assert all(getattr(st,k)==v for k,v in row['identity'].items())
 h.write(O/'WHOLE-JOIN.json',dict(status='PASS_RETAINED_THREE_OBSERVERS_ONLY',captures=results,CPU_seconds=h.cpu_used(),wall_seconds=time.monotonic()-begin,peak_RSS_measured=False,CPU6_released=True,prefix_replayed=False,SDK=False,native=False))
 print(json.dumps(dict(status='PASS_RETAINED_THREE_OBSERVERS_ONLY',CPU_seconds=h.cpu_used(),wall_seconds=time.monotonic()-begin,CPU6_released=True)))
except BaseException as error:
 joined=active is None and all(x['direct_child_joined'] and x['group_absent'] and x['closed_streams'] and x['error'] is None and x['retirement_error'] is None for x in results)
 h.write(O/'FAILURE.STOP.json',dict(error=repr(error),captures=results,active_capture=active,CPU_seconds=h.cpu_used(),wall_seconds=time.monotonic()-begin,peak_RSS_measured=False,CPU6_released=joined,STOP_no_retry=True));raise
finally:
 signal.setitimer(signal.ITIMER_REAL,0)
 os.fchdir(previous)
 os.close(previous)
