/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <affinity.h>
#include <process.h>
#include <syscall.h>
#include <cls.h>
#include <kmalloc.h>
#include <errno.h>
#include <string.h>
#include <ihk/debug.h>
_Static_assert(sizeof(long)==8 && sizeof(int)==4 && sizeof(void *)==8,"x86 LP64");
_Static_assert(__builtin_types_compatible_p(__typeof__(&do_kill),unsigned long (*)(struct thread *,int,int,int,siginfo_t *,int)),"public do_kill ABI");
_Static_assert(sizeof(struct mcs_rwlock_node)==64,"noirq node extent");
_Static_assert(_Alignof(struct mcs_rwlock_node)==64,"noirq node alignment");
_Static_assert(offsetof(struct mcs_rwlock_node,count)==0,"noirq node count");
_Static_assert(offsetof(struct mcs_rwlock_node,type)==4,"noirq node kind");
_Static_assert(offsetof(struct mcs_rwlock_node,locked)==5,"noirq node locked");
_Static_assert(offsetof(struct mcs_rwlock_node,next)==8,"noirq node next");
_Static_assert(sizeof(mcs_rwlock_lock_t)==64 && _Alignof(mcs_rwlock_lock_t)==64,"real lock layout");
_Static_assert(sizeof(siginfo_t)==128,"signal-info full bytes");
_Static_assert(HASH_SIZE==73 && SI_KERNEL==0x80,"retained header constants");
const unsigned long F06_DO_KILL_C_ABI45[45] = {sizeof(struct thread),_Alignof(struct thread),sizeof(struct process),_Alignof(struct process),sizeof(struct process_hash),sizeof(struct thread_hash),offsetof(struct process_hash,lock),offsetof(struct thread,proc),offsetof(struct thread,sigmask),offsetof(struct thread,sigpending),offsetof(struct thread,sigpendinglock),offsetof(struct thread,sigcommon),offsetof(struct thread,sigevent),offsetof(struct thread,status),offsetof(struct thread,refcount),offsetof(struct thread,cpu_id),offsetof(struct process,threads_list),offsetof(struct process,threads_lock),offsetof(struct process,update_lock),offsetof(struct process,pid),offsetof(struct process,pgid),offsetof(struct process,parent),offsetof(struct process,main_thread),offsetof(struct process,ruid),offsetof(struct process,euid),offsetof(struct process,suid),offsetof(struct process,status),sizeof(struct sig_common),offsetof(struct sig_common,sigpending),sizeof(struct sig_pending),offsetof(struct sig_pending,info),offsetof(struct sig_pending,ptracecont),sizeof(siginfo_t),sizeof(struct resource_set),offsetof(struct resource_set,process_hash),offsetof(struct resource_set,thread_hash),sizeof(struct cpu_local_var),offsetof(struct cpu_local_var,resource_set),offsetof(struct cpu_local_var,no_preempt),sizeof(struct kmalloc_header),offsetof(struct kmalloc_header,list),offsetof(struct kmalloc_header,size),sizeof(mcs_rwlock_lock_t),_Alignof(mcs_rwlock_lock_t),sizeof(struct mcs_rwlock_node_irqsave)};
