"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Data-only successor; no owner import, admission, namespace creation or subprocess.
"""
from pathlib import Path
import ast,copy,hashlib,json,os
A=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/default-image-current290-coherent-overlay-source-1/authenticated-materialization-and-entry-source-1')
P=A/'owner-release-data-successor-source-1';P.mkdir(mode=0o700)
SCOPE=__doc__.splitlines()[0]
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=p.stat().st_size)
def load(p):return json.loads(Path(p).read_bytes())
def put(name,value,compact=False):
 p=P/name;raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode() if compact else (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(raw)
 return ref(p)
def assign(raw,key,value):
 lines=raw.splitlines(keepends=True);n=next(n for n in ast.parse(raw).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id==key);lines[n.lineno-1:n.end_lineno]=[key+' = '+value+'\n'];return ''.join(lines)
oldowner=A/'native_rust_exact_mckernel_image_container_owner.CURRENT290.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.py';oldrequest=A/'image-request.CURRENT290.IMAGE-ONLY.ENV22_0485.COMPACT.NEW18H.SOURCE-ONLY.json';assert ref(oldowner)['sha256']=='97edeab73e705772ab5ed34bf55f21e5f1c1954b9d55795194ab33de24b97aec';assert ref(oldrequest)['sha256']=='586f157112403f08d570dfb078bba8e6c6709020b793ea01ac2d788c07c97737'
q=load(oldrequest);originalq=copy.deepcopy(q);raw=oldowner.read_text();tree=ast.parse(raw);hostpath=next(n.value.args[0].value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_HOST_OWNER_PATH' for t in n.targets));hostref=ref(hostpath);assert hostref['sha256']=='96d17547bfc71454d54e95a705138cc9b26faa1e2cafc34105c9ed8d5a68f4d1'
planned=P/'actual-current290-default-image-attempt-2';assert not os.path.lexists(planned)
q['host_owner_path']=hostref['path'];q['host_owner_sha256']=hostref['sha256']
for key,suffix in {'common_exclusion_path':'common-exclusion.json','lease_path':'lease.json','work_root':'owner-work','output_root':'owner-work/output','evidence_root':'owner-work/evidence','owner_evidence_root':'owner-evidence','attempt_root':'owner-evidence/attempt'}.items():q[key]=str(planned/suffix)
raw=assign(raw,'EXPECTED_PROVENANCE_SHA256',repr(q['provenance_sha256']));raw=assign(raw,'COMMON_EXCLUSION',repr(q['common_exclusion_path']))
# Global loader data only. All validator bodies, including imports and release predicates, remain exact.
raw=assign(raw,'_HOST_OWNER',"_load_reviewed_host_owner(\n    _HOST_OWNER_PATH, EXPECTED_HOST_OWNER_SHA256,\n    Path("+repr(q['provenance_path'])+"), EXPECTED_PROVENANCE_SHA256)")
newowner=P/'native_rust_exact_mckernel_image_container_owner.CURRENT290.RELEASE-DATA-SUCCESSOR.py';ast.parse(raw)
with newowner.open('x') as f:f.write(raw)
qref=put('image-request.CURRENT290.RELEASE-DATA-SUCCESSOR.PLANNED-NAMESPACE.NOT-GRANTED.json',q,compact=True);assert qref['bytes']<32<<20
oldfunctions={n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};newfunctions={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};assert oldfunctions==newfunctions
argv=['/usr/bin/taskset','-c','7','/usr/bin/prlimit','--fsize=33554432','--as=2147483648:2147483648','--core=0:0','--','/home/holden/anaconda3/bin/python3','-I','-B',str(newowner),qref['path']]
changedkeys=sorted(k for k in q if q[k]!=originalq[k]);expected=['attempt_root','common_exclusion_path','evidence_root','host_owner_path','host_owner_sha256','lease_path','output_root','owner_evidence_root','work_root'];assert changedkeys==expected
# Static effect-boundary report; never call these functions or load the module.
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
validate=functions['_validate_request'];calls=sorted({ast.unparse(n.func) for n in ast.walk(validate) if isinstance(n,ast.Call)})
run=next(n for n in next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ImageOwner').body if isinstance(n,ast.FunctionDef) and n.name=='run');runcalls=[dict(line=n.lineno,call=ast.unparse(n.func)) for n in ast.walk(run) if isinstance(n,ast.Call) and ast.unparse(n.func) in ['_SHARED_HEAVY_ENTRY_CONTRACT.acquire_heavy_operation','self.validate']];assert sorted(runcalls,key=lambda x:x['line'])[0]['call']=='_SHARED_HEAVY_ENTRY_CONTRACT.acquire_heavy_operation'
effect=put('ACTUAL-OWNER-VALIDATION-EFFECT-BOUNDARY.SOURCE-INSPECTION-ONLY.json',dict(scope=SCOPE,owner=ref(oldowner),module_top_level_executes_authenticated_owner_and_shared_contract_imports=True,ImageOwner_run_order=sorted(runcalls,key=lambda x:x['line']),validate_direct_calls=calls,not_effect_free=['_validate_request reads filesystem/capacity/toolchain and imports authenticated host owner; transitive Git/source/measurement paths can invoke subprocesses.','ImageOwner.run acquires shared durable heavy record BEFORE validate; validation failure is precompiler but not pre-effect.'],owner_imported=False,validate_called=False,subprocesses=0,no_hold_clearance=True))
ready=dict(scope=SCOPE,status='DATA_ONLY_CORRECTED_OWNER_REQUEST_SUCCESSOR_PLANNED_NOT_ADMITTED',failed_owner=ref(oldowner),failed_request=ref(oldrequest),owner=ref(newowner),request=qref,host_control_owner=hostref,provenance=ref(q['provenance_path']),driver=ref(q['driver_path']),full_source_manifest=ref(q['source_manifest']),execution_argv=argv,planned_namespace=str(planned),planned_namespace_created=False,planned_namespace_actual_identities=None,all_FunctionDef_ClassDef_AST_identical=True,changed_owner_global_data=['EXPECTED_PROVENANCE_SHA256 d584→7b0b','_HOST_OWNER loader provenance Path old230→selected290','COMMON_EXCLUSION old230→planned fresh attempt2'],changed_request_fields=changedkeys,unchanged_profile=dict(container_Memory=12884901888,cpuset='2-5',jobs=4,aggregate='22.0485'),effect_boundary=effect,actual_shared_record_or_hold_untouched=True,requires_positive_retirement_before_any_future_admission=True,new_execution_grant=None,builds=0,queries=0,owners=0,cleanup_runs=0)
print(json.dumps(put('READY-CURRENT290-OWNER-RELEASE-DATA-SUCCESSOR.NOT-EXECUTION.json',ready),sort_keys=True))
