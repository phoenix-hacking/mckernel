"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read/parse/hash real owner/request/source release data. Never import an owner,
call _validate_request, run a subprocess/probe or inspect live ownership state.
"""
from pathlib import Path
import ast,copy,hashlib,json
P=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/default-image-current290-coherent-overlay-source-1/authenticated-materialization-and-entry-source-1/owner-release-data-successor-source-1')
READY=P/'READY-CURRENT290-OWNER-RELEASE-DATA-SUCCESSOR.NOT-EXECUTION.json'
READY_SHA='32e7938e742a7d40dc45574c4737a70c487ac79dc6c3da1c2301130364e25455'
def ref(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=p.stat().st_size)
def literal(node):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='Path' and len(node.args)==1:return ast.literal_eval(node.args[0])
 return ast.literal_eval(node)
def assignments(tree):return {n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def command_value(node,request):
 if isinstance(node,ast.Index):return command_value(node.value,request)
 if isinstance(node,ast.Constant):return node.value
 if isinstance(node,ast.List):return [command_value(x,request) for x in node.elts]
 if isinstance(node,ast.Name):
  if node.id=='r':return request
  if node.id=='bound':return {'output':Path(request['output_root'])}
  if node.id=='evidence':return Path(request['evidence_root'])
 if isinstance(node,ast.Subscript):return command_value(node.value,request)[command_value(node.slice,request)]
 if isinstance(node,ast.Attribute) and node.attr=='name':return command_value(node.value,request).name
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return command_value(node.left,request)+command_value(node.right,request)
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='str' and len(node.args)==1:return str(command_value(node.args[0],request))
 raise ValueError('unsupported non-data command AST')
def check(owner_path,request_path,execution_argv,planned_namespace,request_override=None,owner_text_override=None):
 q=json.loads(Path(request_path).read_bytes()) if request_override is None else copy.deepcopy(request_override);raw=Path(owner_path).read_text() if owner_text_override is None else owner_text_override;tree=ast.parse(raw);data=assignments(tree);issues=[];bindings={}
 def require(ok,code):
  if not ok:issues.append(code)
 def file(path,expected,label):
  require(isinstance(path,str) and Path(path).is_absolute() and '..' not in Path(path).parts,label+': exact absolute path')
  try:actual=ref(path)
  except (OSError,TypeError):issues.append(label+': source unavailable');return None
  bindings[label]=actual;require(actual['sha256']==expected,label+': actual bytes hash');return actual
 driver=file(q['driver_path'],q['driver_sha256'],'driver');prov=file(q['provenance_path'],q['provenance_sha256'],'provenance');host=file(q['host_owner_path'],q['host_owner_sha256'],'host-control-owner');manifest=file(q['source_manifest'],q['source_manifest_sha256'],'full-source-manifest');supp=file(q['gitlink_manifest'],q['gitlink_manifest_sha256'],'gitlink-manifest');toolchain=file(q['toolchain_manifest'],q['toolchain_manifest_sha256'],'toolchain-manifest')
 require(literal(data['EXPECTED_DRIVER_SHA256'])==q['driver_sha256'],'owner expected driver release')
 require(literal(data['EXPECTED_PROVENANCE_SHA256'])==q['provenance_sha256'],'owner expected provenance release')
 require(literal(data['EXPECTED_HOST_OWNER_SHA256'])==q['host_owner_sha256'],'owner expected host-control release')
 require(literal(data['_HOST_OWNER_PATH'])==q['host_owner_path'],'owner host-control loader path')
 hostload=data['_HOST_OWNER'];require(isinstance(hostload,ast.Call) and isinstance(hostload.func,ast.Name) and hostload.func.id=='_load_reviewed_host_owner','global host loader expression');require(literal(hostload.args[2])==q['provenance_path'],'owner global provenance loader path')
 require(q['host_owner_path']!=str(owner_path),'host-control role must differ from image-owner executable')
 require(literal(data['COMMON_EXCLUSION'])==q['common_exclusion_path'],'owner common-exclusion release path')
 require(literal(data['LAUNCHER_AGGREGATE_GIB'])==q['launcher_aggregate_memory_gib']=='22.0485','exact aggregate release data')
 require(q['jobs']==4 and q['aggregate_memory_required']==12884901888 and q['memory_backed_bytes']==0,'unchanged container/job/memory data')
 if manifest and prov:
  doc=json.loads(Path(q['source_manifest']).read_bytes());pdata=assignments(ast.parse(Path(q['provenance_path']).read_bytes()))
  require(literal(pdata['EXPECTED_SUCCESSOR_CANONICAL_SHA256'])==q['source_manifest_sha256'],'provenance selected full manifest release')
  require(literal(pdata['BASE_CANDIDATE'])==doc['candidate_sha']==q['candidate_sha'],'candidate identities')
  require(literal(pdata['BASE_IHK'])==doc['ihk_sha']==q['ihk_sha'],'selected IHK identities')
  require(doc['source_derivative_sha256']==q['source_derivative_sha256'] and doc['materialization_sha256']==q['materialization_sha256'],'source derivative/materialization data')
  require(q['source_identity']==q['disk_identity'] and q['source_root']==q['source_identity']['path'],'separate copied source identity data')
  supplement=json.loads(Path(q['gitlink_manifest']).read_bytes());require(supplement['base_manifest_sha256']==q['source_manifest_sha256'],'gitlink full manifest link')
  tools=json.loads(Path(q['toolchain_manifest']).read_bytes());rust=(tools.get('mounted_tools') or tools.get('tools') or {})['rustc']['version'];require(q['nightly']['rustc_version']==rust==literal(data['EXPECTED_V2_RUSTC_VERSION']),'exact Rust version release data')
 for key,suffix in {'common_exclusion_path':'common-exclusion.json','lease_path':'lease.json','work_root':'owner-work','output_root':'owner-work/output','evidence_root':'owner-work/evidence','owner_evidence_root':'owner-evidence','attempt_root':'owner-evidence/attempt'}.items():require(q[key]==str(Path(planned_namespace)/suffix),'planned namespace '+key)
 require(len(execution_argv)>=2 and execution_argv[-2]==str(owner_path) and execution_argv[-1]==str(request_path),'host execution argv exact image-owner/request paths')
 require(execution_argv[:3]==['/usr/bin/taskset','-c','7'] and execution_argv[3:9]==['/usr/bin/prlimit','--fsize=33554432','--as=2147483648:2147483648','--core=0:0','--','/home/holden/anaconda3/bin/python3'],'host execution profile argv')
 # Decode only the unchanged AST command-list data; never execute ImageOwner.run.
 ownerclass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ImageOwner');run=next(n for n in ownerclass.body if isinstance(n,ast.FunctionDef) and n.name=='run');command_node=next(n.value for n in ast.walk(run) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='command' for t in n.targets));command=command_value(command_node,q)
 if q.get('gitlink_manifest') is not None:command+=['--gitlink-manifest','/libdwarf-inputs.json']
 if q.get('native_fork_owned_transaction',False):command+=['--native-fork-owned-transaction']
 require(command[0]=='/driver.py' and command[command.index('--source-root')+1]=='/src' and command[command.index('--manifest')+1]=='/inputs.json' and command[command.index('--toolchain')+1]=='/toolchain.json','container source/driver/manifest/toolchain argv')
 require(q['mounts']['driver']=='/driver.py' and q['mounts']['provenance']=='/native_rust_exact_build_offline.py' and q['mounts']['manifest']=='/inputs.json','container exact mount roles')
 require(any(isinstance(n,ast.Import) and any(a.name=='native_rust_exact_build_offline' and a.asname=='provenance' for a in n.names) for n in ast.parse(Path(q['driver_path']).read_bytes()).body),'driver actual provenance import name')
 return dict(status='PASS_STATIC_RELEASE_DATA_ONLY' if not issues else 'REFUSED_STATIC_RELEASE_DATA',issues=issues,bindings=bindings,container_driver_argv=command,owner_imported=False,validate_called=False,subprocesses=0,planned_runtime_not_admitted=True)
def main():
 assert ref(READY)['sha256']==READY_SHA;r=json.loads(READY.read_bytes());correct=check(r['owner']['path'],r['request']['path'],r['execution_argv'],r['planned_namespace']);assert correct['status']=='PASS_STATIC_RELEASE_DATA_ONLY',correct['issues']
 oldq=json.loads(Path(r['failed_request']['path']).read_bytes());oldargv=list(r['execution_argv']);oldargv[-2:]=[r['failed_owner']['path'],r['failed_request']['path']];old=check(r['failed_owner']['path'],r['failed_request']['path'],oldargv,str(Path(oldq['work_root']).parent));expected={'owner expected provenance release','owner expected host-control release','owner host-control loader path','owner global provenance loader path','owner common-exclusion release path','host-control role must differ from image-owner executable'};assert expected.issubset(set(old['issues'])),old['issues']
 q=json.loads(Path(r['request']['path']).read_bytes());raw=Path(r['owner']['path']).read_text();negative=[]
 for label,changed in [('stale provenance literal',raw.replace(q['provenance_sha256'],'d584be0f5c0f92102a20b567520cc827dfd038b55d1366e5c528103d0a650513',1)),('stale global loader path',raw.replace("Path("+repr(q['provenance_path'])+")","Path('/fixture/stale-provenance.py')",1))]:
  result=check(r['owner']['path'],r['request']['path'],r['execution_argv'],r['planned_namespace'],owner_text_override=changed);assert result['status']=='REFUSED_STATIC_RELEASE_DATA';negative.append(dict(case=label,issues=result['issues']))
 for label,key,value in [('self image owner as host-control','host_owner_path',r['owner']['path']),('stale common exclusion','common_exclusion_path',oldq['common_exclusion_path']),('wrong full-manifest hash','source_manifest_sha256','0'*64)]:
  bad=copy.deepcopy(q);bad[key]=value;result=check(r['owner']['path'],r['request']['path'],r['execution_argv'],r['planned_namespace'],request_override=bad);assert result['status']=='REFUSED_STATIC_RELEASE_DATA';negative.append(dict(case=label,issues=result['issues']))
 badargv=list(r['execution_argv']);badargv[-2]=q['host_owner_path'];result=check(r['owner']['path'],r['request']['path'],badargv,r['planned_namespace']);assert result['status']=='REFUSED_STATIC_RELEASE_DATA';negative.append(dict(case='host-control substituted into image-owner argv',issues=result['issues']))
 report=dict(scope=__doc__.splitlines()[0],status='PASS_ACTUAL_STATIC_RELEASE_CROSS_BINDINGS_ONLY',successor=correct,failed_actual_97_586=old,negative_cases=negative,all_actual_files_read_hash_checked=True,all_owner_validator_AST_unchanged=r['all_FunctionDef_ClassDef_AST_identical'],no_owner_import_validate_subprocess_observer_or_admission=True,namespace_created=False,actual_shared_record_or_parent_hold_touched=False)
 print(json.dumps(report,sort_keys=True));return report
if __name__=='__main__':main()
