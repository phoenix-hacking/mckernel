"""Pure F02 allocated-data predicates; no compiler, launcher, cleanup or runtime entry.
Functional OS/apps and Rust/assembly migration only; no security testing.
The caller supplies the existing admitted ELF parser and relocation helpers.
"""
import collections
import hashlib
import json
import math
import re
import struct


def _f02_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _f02_data_symbols(elf):
    rows = [s for s in elf.symbols if s['type'] == 1 and
            (s['shndx'] == 0xfff2 or 0 < s['shndx'] < len(elf.sections) and
             elf.sections[s['shndx']]['flags'] & 2)]
    assert len({s['name'] for s in rows}) == len(rows), 'duplicate F02 data owner'
    return rows


def _f02_bytes(elf, row, helpers):
    return bytes(row['size']) if row['shndx'] == 0xfff2 else helpers['object_bytes'](elf, row)


def _f02_family(name):
    for family in ('ddebug', '__func__', '__FUNCTION__', 'mcexec_v10_scheduler_logs'):
        if re.fullmatch(re.escape(family) + r'\.[0-9]+', name):
            return family
    return None


def _f02_target(elf, relocation, helpers, aliases):
    target = relocation['target']
    name = target['name']
    index = target['shndx']
    value = target['value'] + relocation['addend']
    if target['bind'] == 1 and name:
        return dict(kind='named', name=name, addend=relocation['addend'])
    assert 0 < index < len(elf.sections), ('unclassified target', target)
    section = elf.sections[index]
    containing = [s for s in _f02_data_symbols(elf) if s['shndx'] == index and
                  s['value'] <= value < s['value'] + s['size']]
    if containing:
        assert len(containing) == 1, 'ambiguous target data owner'
        owner = containing[0]
        family = _f02_family(owner['name'])
        if family in ('__func__', '__FUNCTION__'):
            raw = _f02_bytes(elf, owner, helpers)[value - owner['value']:]
            assert b'\0' in raw, 'unterminated function metadata'
            return dict(kind='string', bytes=raw[:raw.index(b'\0') + 1].hex())
        assert family is None, ('unclassified local-data pointer', owner['name'])
        return dict(kind='object', name=owner['name'], interior=value - owner['value'])
    assert section['flags'] & 2 and not section['flags'] & 5, 'non-immutable anonymous target'
    assert '.str' in section['name'], ('unclassified section target', section['name'])
    raw = elf.payload(section)
    assert 0 <= value < len(raw), 'string relocation bounds'
    end = raw.find(b'\0', value, min(len(raw), value + 4096))
    assert end >= 0, 'bounded pointer string'
    content = raw[value:end + 1]
    text = content[:-1].decode()
    return dict(kind='source' if text in aliases else 'string',
                bytes=(b'@EXACT_PROCESS_SOURCE@\0' if text in aliases else content).hex(),
                **({'literal': content.hex()} if text in aliases else {}))


def _f02_semantic(elf, row, helpers, aliases):
    raw = _f02_bytes(elf, row, helpers)
    refs = [] if row['shndx'] == 0xfff2 else helpers['owning_relocations'](elf, row)
    decoded = []
    for ref in refs:
        assert ref['type'] == 1 and 0 <= ref['offset'] <= row['size'] - 8, 'data pointer ABI'
        target = _f02_target(elf, ref, helpers, aliases)
        target.pop('literal', None)  # Only the two exact admitted source-path aliases normalize.
        decoded.append(dict(offset=ref['offset'], type=ref['type'], target=target))
    semantic = dict(bind=row['bind'], type=row['type'], size=row['size'], raw=raw.hex(),
                    relocations=decoded)
    family = _f02_family(row['name'])
    key = row['name'] if family is None else family + ':' + _f02_digest(semantic)
    return key, semantic


def _f02_map_contributions(text, elf):
    required = {elf.sections[s['shndx']]['name'] for s in _f02_data_symbols(elf)
                if s['shndx'] != 0xfff2}
    assert not required & {'.rodata.str1.1', '.rodata.str1.8'}, 'merged owner needs explicit proof'
    rows = {}
    pattern = r'^\s+(\S+)\s+(0x[0-9a-f]+)\s+(0x[0-9a-f]+) CMakeFiles/mckernel\.img\.dir/process\.c\.o$'
    for line in text.splitlines():
        match = re.fullmatch(pattern, line)
        if not match or match[1] not in required:
            continue
        assert match[1] not in rows, 'duplicate exact input contribution'
        rows[match[1]] = dict(address=int(match[2], 16), size=int(match[3], 16))
    assert set(rows) == required, ('missing current process input section', required - set(rows))
    for name in required:
        selected = [s for s in elf.sections if s['name'] == name]
        assert len(selected) == 1 and selected[0]['size'] == rows[name]['size']
    return rows


def _f02_final_owner(elf, row, helpers, final, contributions, aliases):
    section = elf.sections[row['shndx']]
    address = contributions[section['name']]['address'] + row['value']
    matches = [s for s in final['symbols'] if s['name'] == row['name'] and
               s['value'] == address and s['size'] == row['size'] and
               s['bind'] == row['bind'] and s['type'] == 1 and
               s['visibility'] == elf.raw[elf.table['offset'] + 24 * row['index'] + 5] and
               0 < s['shndx'] < len(final['sections'])]
    assert len(matches) == 1, ('unique exact final C data owner', row['name'])
    resolved = matches[0]
    target_section = final['sections'][resolved['shndx']]
    assert target_section['flags'] & 2 and not target_section['flags'] & 4
    expected = bytearray(helpers['object_bytes'](elf, row))
    fields = []
    for ref in helpers['owning_relocations'](elf, row):
        assert ref['type'] == 1 and 0 <= ref['offset'] <= row['size'] - 8
        stored_bytes = final['read'](address + ref['offset'], 8)
        stored = int.from_bytes(stored_bytes, 'little')
        target = ref['target']
        decoded = _f02_target(elf, ref, helpers, aliases)
        if target['bind'] == 1 and target['name']:
            named = final['defined'](target['name'])
            assert named['bind'] == 1 and stored == named['value'] + ref['addend']
        elif decoded['kind'] in ('source', 'string'):
            content = bytes.fromhex(decoded.get('literal', decoded['bytes']))
            assert final['read'](stored, len(content)) == content, 'final string pointee identity'
            owners = [s for s in final['sections'] if s['flags'] & 2 and
                      s['addr'] <= stored and stored + len(content) <= s['addr'] + s['size']]
            assert len(owners) == 1 and not owners[0]['flags'] & 5, 'immutable final string target'
        else:
            source_section = elf.sections[target['shndx']]['name']
            assert source_section in contributions, 'unclassified final target contribution'
            assert stored == contributions[source_section]['address'] + target['value'] + ref['addend']
        expected[ref['offset']:ref['offset'] + 8] = stored_bytes
        fields.append(dict(offset=ref['offset'], type=ref['type'], stored=stored, target=decoded))
    actual = final['read'](address, row['size'])
    assert actual == bytes(expected), ('final whole data bytes', row['name'])
    return dict(address=address, size=row['size'], bind=resolved['bind'], type=resolved['type'],
                visibility=resolved['visibility'],
                section_type=target_section['type'], section_flags=target_section['flags'],
                bytes=actual.hex(), pointer_fields=fields)


def _f02_collect(elf, helpers, aliases, final=None, link_map=None):
    owners = {}
    semantics = {}
    details = {}
    contributions = _f02_map_contributions(link_map, elf) if final else None
    for row in _f02_data_symbols(elf):
        common = row['shndx'] == 0xfff2
        key, semantic = _f02_semantic(elf, row, helpers, aliases)
        assert key not in semantics, ('duplicate semantic identity', key)
        semantics[key] = _f02_digest(semantic)
        section = None if common else elf.sections[row['shndx']]
        other = elf.raw[elf.table['offset'] + 24 * row['index'] + 5]
        exact = dict(bind=row['bind'], type=row['type'], visibility=other, size=row['size'],
                     storage='COMMON' if common else 'ALLOC', value=row['value'],
                     section=None if common else {k: section[k] for k in ('name','type','flags','align')},
                     alignment_guarantee=row['value'] if common else
                         math.gcd(section['align'], row['value']),
                     semantic_key=key, semantic=semantic,
                     raw_relocations=[] if common else helpers['owning_relocations'](elf, row))
        if final:
            exact['final'] = _f02_final_owner(elf, row, helpers, final, contributions, aliases)
        owners[row['name']] = _f02_digest(exact)
        details[row['name']] = exact
    return dict(allocated_names=sorted(s['name'] for s in _f02_data_symbols(elf)
                if s['shndx'] != 0xfff2), common_names=sorted(s['name'] for s in
                _f02_data_symbols(elf) if s['shndx'] == 0xfff2), owners=owners,
                semantics=semantics, details=details, contributions=contributions)


def _f02_rust_edges(rust, helpers, names):
    edges = []
    for section in rust.sections:
        if section['type'] != 4 or not rust.sections[section['info']]['flags'] & 2:
            continue
        assert section['link'] == rust.table['index'] and section['entsize'] == 24
        for index in range(section['size'] // 24):
            offset, info, addend = struct.unpack_from('<QQq', rust.raw, section['offset'] + 24 * index)
            target = rust.symbols[info >> 32]
            if target['name'] in names:
                assert target['shndx'] == 0 and target['bind'] == 1, 'Rust imports genuine C data'
                edges.append(dict(owner_section=rust.sections[section['info']]['name'],
                                  offset=offset, type=info & 0xffffffff,
                                  target=target['name'], addend=addend))
    assert set(row['target'] for row in edges) == set(names), 'all three genuine C data imports'
    return edges


def _f02_require_profile(actual, expected):
    for field in ('allocated_names', 'common_names', 'owners', 'semantics', 'contributions'):
        assert actual[field] == expected[field], ('exact F02 data profile', field)
    return dict(classification='GENUINE_C_RUNTIME_DATA_NOT_RUST_RETIREMENT',
                allocated=len(actual['allocated_names']), common=len(actual['common_names']),
                semantic_owners=len(actual['semantics']))


def _f02_fail(ok, message):
    if not ok:
        raise ValueError(str(message))


def _f02_final_view(image):
    """Resolve the new image's stored pointer bytes, never reuse 8b9 addresses.

    The accepted ET_REL parser is used for the object. The final image view is
    supplied separately with address-to-allocated-section reads. Named targets
    resolve through this exact image's symbol table. Anonymous string objects
    retain exact immutable string bytes, not a guessed address or lifetime.
    """
    import struct
    raw = image.read_bytes()
    h = struct.unpack_from('<16sHHIQQQIHHHHHH', raw)
    _f02_fail(h[0][:6] == b'\x7fELF\x02\x01' and h[1] == 2 and h[2] == 62 and h[11] == 64,
          'current81 final ELF64 x86_64 EXEC')
    sections = [dict(zip(('name_off', 'type', 'flags', 'addr', 'offset', 'size', 'link',
                         'info', 'align', 'entsize'),
                        struct.unpack_from('<IIQQQQIIQQ', raw, h[6] + 64 * i)))
                for i in range(h[12])]
    def payload(s):
        _f02_fail(s['offset'] + s['size'] <= len(raw), 'final section file extent')
        return raw[s['offset']:s['offset'] + s['size']]
    def string(table, offset):
        return table[offset:table.index(b'\0', offset)].decode()
    table = [s for s in sections if s['type'] == 2]
    _f02_fail(len(table) == 1 and table[0]['entsize'] == 24, 'final unique full symtab')
    table = table[0]
    strings = payload(sections[table['link']])
    symbols = []
    for i in range(table['size'] // 24):
        n, info, other, index, value, size = struct.unpack_from(
            '<IBBHQQ', raw, table['offset'] + 24 * i)
        symbols.append(dict(name=string(strings, n), bind=info >> 4, type=info & 15,
                            shndx=index, value=value, size=size, visibility=other))
    def defined(name, typ=None):
        rows = [s for s in symbols if s['name'] == name and
                0 < s['shndx'] < len(sections)]
        _f02_fail(len(rows) == 1, ('final unique owner', name, rows))
        if typ is not None:
            _f02_fail(rows[0]['type'] == typ, ('final symbol type', name))
        return rows[0]
    def read(address, count):
        rows = [s for s in sections if s['flags'] & 2 and
                s['addr'] <= address and address + count <= s['addr'] + s['size']]
        _f02_fail(len(rows) == 1, ('final allocated address extent', address, count))
        s = rows[0]
        return bytes(count) if s['type'] == 8 else payload(s)[
            address - s['addr']:address - s['addr'] + count]
    return dict(sections=sections, symbols=symbols, defined=defined, read=read)
