#include "/src/kernel/process.c"
/* Include only through the owner's genuine selected kernel/process.c ABI TU.
 * Functional OS/apps and Rust/assembly migration only; no security testing.
 * Nonruntime witness proposal. No compiler execution or ABI acceptance here. */
_Static_assert(sizeof(runq_reservation_lock) == 4, "current spinlock size");
_Static_assert(__alignof__(__typeof__(runq_reservation_lock)) == 4, "current spinlock ABI align");
_Static_assert(sizeof(resource_set_lock) == 64, "current rwlock size");
_Static_assert(__alignof__(__typeof__(resource_set_lock)) == 64, "current rwlock ABI align");
_Static_assert(sizeof(resource_set_list) == 16, "current list size");
_Static_assert(__alignof__(__typeof__(resource_set_list)) == 8, "current list ABI align");
_Static_assert(__builtin_types_compatible_p(__typeof__(resource_set_list), struct list_head),
    "genuine C list type; no Rust ownership relabel");
_Static_assert(__builtin_types_compatible_p(__typeof__(resource_set_lock), mcs_rwlock_lock_t),
    "genuine C rwlock type");
_Static_assert(__builtin_types_compatible_p(__typeof__(runq_reservation_lock), ihk_spinlock_t),
    "genuine C spinlock type");
