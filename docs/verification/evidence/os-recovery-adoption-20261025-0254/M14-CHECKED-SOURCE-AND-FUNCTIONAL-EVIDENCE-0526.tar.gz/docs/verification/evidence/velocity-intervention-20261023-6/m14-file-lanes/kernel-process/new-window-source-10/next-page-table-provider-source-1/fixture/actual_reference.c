/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <process.h>
#include <page.h>
#include <ihk/mm.h>
extern int printf(const char*,...);extern void abort(void);
#define CHECK(t) do{if(!(t)){printf("FAIL line=%d\n",__LINE__);abort();}}while(0)
/* Same actual original architecture computation, symbol-renamed only. */
int pgsize_to_tbllv(size_t) __asm__("reference_pgsize_to_tbllv");
size_t tbllv_to_contpgsize(int) __asm__("reference_tbllv_to_contpgsize");
int pgsize_to_tbllv(size_t pgsize)
{
	switch (pgsize) {
	case PTL1_SIZE:	return 1;
	case PTL2_SIZE:	return 2;
	case PTL3_SIZE:	return 3;
	case PTL4_SIZE:	return 4;
	default:
		return 0;
	}
}

size_t tbllv_to_contpgsize(int level)
{
	return 0;
}


static int count,unmap_result;static unsigned long tlb_address;static struct page *unmap_page;
void fixture_tlb(unsigned long address){CHECK(count==0);++count;tlb_address=address;}
int fixture_unmap(struct page *page){CHECK(count==0);++count;unmap_page=page;return unmap_result;}
#define flush_tlb_single fixture_tlb
#define page_unmap fixture_unmap
void process_flush_tlb_single_bridge(unsigned long) __asm__("reference_process_flush_tlb_single_bridge");
int process_pgsize_to_tbllv_bridge(size_t) __asm__("reference_process_pgsize_to_tbllv_bridge");
size_t process_tbllv_to_contpgsize_bridge(int) __asm__("reference_process_tbllv_to_contpgsize_bridge");
int process_page_unmap_bridge(void*) __asm__("reference_process_page_unmap_bridge");
void process_flush_tlb_single_bridge(unsigned long addr)
{
	flush_tlb_single(addr);
}

int process_pgsize_to_tbllv_bridge(size_t pgsize)
{
	return pgsize_to_tbllv(pgsize);
}

size_t process_tbllv_to_contpgsize_bridge(int level)
{
	return tbllv_to_contpgsize(level);
}

int process_page_unmap_bridge(void *page)
{
	return page_unmap(page);
}


extern void rust_tlb(unsigned long) __asm__("process_flush_tlb_single_bridge");
extern int rust_pgsize(size_t) __asm__("process_pgsize_to_tbllv_bridge");
extern size_t rust_level(int) __asm__("process_tbllv_to_contpgsize_bridge");
extern int rust_unmap(void*) __asm__("process_page_unmap_bridge");
extern const unsigned long SOURCE_NEXT_RUST_ABI[12];
static const unsigned long C_ABI[12]={sizeof(struct page),__alignof__(struct page),
 __builtin_offsetof(struct page,count),__builtin_offsetof(struct page,mapped),
 __builtin_offsetof(struct page,offset),__builtin_offsetof(struct page,pgshift),
 PTL1_SIZE,PTL2_SIZE,PTL3_SIZE,PTL4_SIZE,sizeof(size_t),sizeof(struct page*)};
int main(void){
 for(int i=0;i<12;++i){CHECK(C_ABI[i]==SOURCE_NEXT_RUST_ABI[i]);printf("ABI row=%d value=%lu\n",i,C_ABI[i]);}
 const size_t sizes[]={0,1,4095,4096,4097,PTL2_SIZE,PTL3_SIZE,PTL4_SIZE,~(size_t)0};int comparisons=0;
 for(int i=0;i<9;++i){CHECK(process_pgsize_to_tbllv_bridge(sizes[i])==rust_pgsize(sizes[i]));++comparisons;}
 const int levels[]={(-2147483647-1),-1,0,1,2,3,4,5,2147483647};
 for(int i=0;i<9;++i){CHECK(process_tbllv_to_contpgsize_bridge(levels[i])==rust_level(levels[i]));++comparisons;}
 const unsigned long addresses[]={0,1,0x1234,~0UL};
 for(int i=0;i<4;++i){count=0;process_flush_tlb_single_bridge(addresses[i]);CHECK(count==1 && tlb_address==addresses[i]);count=0;rust_tlb(addresses[i]);CHECK(count==1 && tlb_address==addresses[i]);++comparisons;}
 static struct page pages[2];void*ptrs[]={NULL,&pages[0],&pages[1]};const int returns[]={-12,0,1};
 for(int i=0;i<3;++i)for(int j=0;j<3;++j){unmap_result=returns[j];count=0;int expected=process_page_unmap_bridge(ptrs[i]);CHECK(count==1 && unmap_page==ptrs[i]);count=0;CHECK(rust_unmap(ptrs[i])==expected && count==1 && unmap_page==ptrs[i]);++comparisons;}
 CHECK(comparisons==31);printf("PASS actual-original-C/Rust page-table providers: 31 comparisons, 12 genuine ABI rows, actual mapping computations and controlled TLB/page forwarding\n");return 0;
}
