use crate::abi::{CInt,CULong,OffT};
#[repr(C)]
pub struct ListHead {
    next: *mut ListHead,
    prev: *mut ListHead,
}
#[repr(C)]
struct IhkAtomic {
    counter: CInt,
}
#[repr(C)]
struct IhkAtomic64 {
    counter64: i64,
}
#[repr(C)]
pub struct Page {
    list: ListHead,
    hash: ListHead,
    mode: u8,
    phys: CULong,
    count: IhkAtomic,
    mapped: IhkAtomic64,
    offset: OffT,
    pgshift: CInt,
}
