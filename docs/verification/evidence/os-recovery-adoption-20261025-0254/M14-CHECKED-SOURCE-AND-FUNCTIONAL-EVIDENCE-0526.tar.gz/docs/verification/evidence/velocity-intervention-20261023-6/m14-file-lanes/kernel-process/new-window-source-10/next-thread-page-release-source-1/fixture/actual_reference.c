/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <process.h>
#include <ihk/mm.h>
extern int printf(const char *,...);extern void abort(void);
#define CHECK(t) do {if(!(t)){printf("FAIL line=%d\n",__LINE__);abort();}}while(0)
static int equal(const char*a,const char*b){while(*a && *a==*b){++a;++b;}return *a==*b;}
struct event{void*ptr;int pages,kind,line,count;const char*file;};static struct event current,expected;
void fixture_free(void*ptr,int pages,int kind,char*file,int line){++current.count;current.ptr=ptr;current.pages=pages;current.kind=kind;current.file=file;current.line=line;}
void _ihk_mc_free_pages(void*ptr,int pages,int kind,char*file,int line){fixture_free(ptr,pages,kind,file,line);}
void process_free_thread_pages_bridge(void*) __asm__("reference_process_free_thread_pages_bridge");

#line 3499 "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-thread-page-release-source-1/candidate/kernel/process.c"
static void free_thread_pages(struct thread *thread)
{
	_ihk_mc_free_pages(thread, KERNEL_STACK_NR_PAGES, IHK_MC_PG_KERNEL, __FILE__, __LINE__);
}

void process_free_thread_pages_bridge(void *thread)
{
	free_thread_pages(thread);
}

#line 30 "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-thread-page-release-source-1/fixture/actual_reference.c"

extern void rust_free(void*) __asm__("process_free_thread_pages_bridge");
const char *const process_tracked_allocator_source_file="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-thread-page-release-source-1/candidate/kernel/process.c";
const int process_free_thread_pages_source_line=3501;
extern const unsigned long SOURCE_NEXT_RUST_ABI[5];
static const unsigned long C_ABI[5]={KERNEL_STACK_NR_PAGES,IHK_MC_PG_KERNEL,sizeof(int),sizeof(void*),3501};
int main(void){
 for(int i=0;i<5;++i){CHECK(C_ABI[i]==SOURCE_NEXT_RUST_ABI[i]);printf("ABI row=%d value=%lu\n",i,C_ABI[i]);}
 static char storage[2];void *cases[]={NULL,&storage[0],&storage[1]};
 for(int i=0;i<3;++i){
  current=(struct event){0};process_free_thread_pages_bridge(cases[i]);expected=current;
  CHECK(expected.count==1 && expected.line==3501 && equal(expected.file,"/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-thread-page-release-source-1/candidate/kernel/process.c"));
  current=(struct event){0};rust_free(cases[i]);
  CHECK(current.count==expected.count && current.ptr==expected.ptr && current.pages==expected.pages);
  CHECK(current.kind==expected.kind && current.line==expected.line && equal(current.file,expected.file));
 }
 printf("PASS actual-original-C/Rust thread-page release: 3 exact forwarding cases, 5 genuine ABI rows, once-only tracked pointer/page/type/file/line parity\n");return 0;
}
