"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Cheap source/hash/descriptor preflight. Starts no compiler, fixture, or subprocess.
"""
from pathlib import Path
import hashlib,json,os,stat,time
D=Path(__file__).resolve().parent
P=D/'EXACT-3472-45ABI-07d803.NOT-GRANTED.json'
K=Path('/home/holden/mckernel')

def need(ok,msg):
    if not ok:raise ValueError(msg)

def pin(path):
    path=Path(path);a=path.stat();need(stat.S_ISREG(a.st_mode) and a.st_size<=4<<20,'bounded regular source/tool input')
    raw=path.read_bytes();b=path.stat()
    need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns),'source stable while hashing')
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def git_head():
    text=(K/'.git/HEAD').read_text().strip()
    if not text.startswith('ref: '):return text
    ref=text[5:];path=K/'.git'/ref
    if path.exists():return path.read_text().strip()
    rows=[x.split() for x in (K/'.git/packed-refs').read_text().splitlines() if x and not x.startswith(('#','^'))]
    found=[row[0] for row in rows if len(row)==2 and row[1]==ref]
    need(len(found)==1,'unique packed HEAD');return found[0]

def check():
    started=time.monotonic();j=json.loads(P.read_text())
    need(git_head()==j['reconciled_git_head'],'exact fetched checkpoint HEAD')
    rows=j['sources']+j['headers']+j['canonical_runtime_guards']+j['canonical_header_guards']+j['selection_inputs']+j['preparation_receipts']
    for row in rows:need(pin(row['path'])==row,'genuine source pin '+row['path'])
    need(pin(Path(__file__))==j['preflight'],'preflight self-binding')
    need((len(j['sources']),len(j['headers']),len(j['commands']))==(22,79,7),'source/header/command tuple')
    need(j['expected_cases']==dict(direct=2816,group=640,invalid=16,total=3472,ABI=45),'exact matrix counts')
    need(11*2*4*2*2*2*2*2==2816 and 5*4*2*2*2*2*2==640 and 2*2*2*2==16,'static loop products')
    S=Path(j['fixture_source_root']);canonical=(K/'arch/x86_64/kernel/syscall.c').read_text()
    need((S/'original-do-kill.ACTUAL.inc').read_text() in canonical,'byte-extracted full original C body')
    body=(S/'whole-compare.c').read_text()
    for text in ('scenario<11','route<2','sig<4','pc<2','provided<2','caller<2','sends<=2','debug<2','g<5','sig<2','i<45'):
        need(text in body,'matrix/ABI source clause '+text)
    need(j['commands'][2]['argv'][1:3]==['--redefine-sym','do_kill=fixture_original_do_kill'],'genuine objcopy original-name/recursion mapping')
    need(all('-DMCKERNEL_NATIVE_FORK_OWNED_TRANSACTION' not in c['argv'] for c in j['commands']),'held fork work excluded')
    cmake=(K/'kernel/CMakeLists.txt').read_text()
    for pair in j['selected_pairs']:
        for source in pair['sources']:
            marker='"'+source+'"';at=cmake.index(marker);fragment=cmake[at:cmake.index(')',at)+1]
            need(pair['selector'] in fragment,'paired existing source selector '+source)
    old=json.loads(Path(j['prior_queue']['path']).read_text())
    for i,c in enumerate(j['commands']):
        expected=[arg.replace(old['output_root']+'/',j['output_root']+'/') for arg in old['commands'][i]['argv']]
        need(c['argv']==expected,'only fresh output paths changed in command '+str(i))
    need(not Path(j['output_root']).exists() and not Path(j['capture_root']).exists(),'no workload/output admitted')
    need(time.monotonic()-started<5,'cheap preflight elapsed bound')
    return dict(scope=__doc__,status='PASS_SOURCE_HASH_DESCRIPTOR_ONLY_NO_WORKLOAD',git_head=git_head(),
                canonical_policy=j['named_runtime_tuple']['policy'],canonical_process=j['named_runtime_tuple']['process'],
                canonical_mem=j['named_runtime_tuple']['mem'],kernel_CMake=j['named_runtime_tuple']['kernel_CMake'],
                source_count=22,header_count=79,commands_prepared=7,expected_cases=j['expected_cases'],
                seconds=time.monotonic()-started,compiler_or_fixture_commands=0,CPU_slot_reserved=False)

if __name__=='__main__':
    result=check();raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
    need(len(raw)<=16384,'small preflight receipt')
    fd=os.open(D/'PREFLIGHT-SOURCE-ONLY.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as stream:stream.write(raw)
    print(json.dumps(result,sort_keys=True))
