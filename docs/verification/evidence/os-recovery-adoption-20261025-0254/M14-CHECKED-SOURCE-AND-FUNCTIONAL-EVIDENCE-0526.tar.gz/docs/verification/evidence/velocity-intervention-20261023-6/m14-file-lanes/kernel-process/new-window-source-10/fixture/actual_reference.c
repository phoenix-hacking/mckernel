/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Actual original C leaf bodies, real headers, controlled allocator/log effects. */
#include <process.h>
#include <ihk/debug.h>
#include <ihk/mm.h>
extern int printf(const char *,...);
extern void abort(void);
#define CHECK(t) do { if (!(t)) { printf("FAIL line=%d: %s\n",__LINE__,#t); abort(); } } while(0)
static int same(const char *a,const char *b) { while (*a && *a==*b) {++a;++b;} return *a==*b; }
struct event { int kind; unsigned long value[8]; const char *file; const char *format; const char *name; };
static struct event actual,expected;
static void *alloc_result;
void *fixture_alloc(int n,int a,unsigned long f,int node,int k,unsigned long v,char *file,int line) {
 CHECK(actual.kind==0); actual.kind=1; actual.value[0]=(unsigned long)n;actual.value[1]=(unsigned long)a;
 actual.value[2]=f;actual.value[3]=(unsigned long)node;actual.value[4]=(unsigned long)k;
 actual.value[5]=v;actual.value[6]=(unsigned long)line;actual.file=file;return alloc_result;
}
void *_ihk_mc_alloc_aligned_pages_node(int n,int a,unsigned long f,int node,int k,unsigned long v,char *file,int line) {
 return fixture_alloc(n,a,f,node,k,v,file,line);
}
int kprintf(const char *format,...) {
 CHECK(actual.kind==0);actual.kind=2;actual.format=format;
 __builtin_va_list args;__builtin_va_start(args,format);actual.name=__builtin_va_arg(args,const char *);
 if (same(format,"%s: pid: %d, CPU: %d\n")) {
  actual.value[0]=(unsigned long)__builtin_va_arg(args,int);actual.value[1]=(unsigned long)__builtin_va_arg(args,int);
 } else CHECK(same(format,"%s: invalid CPU requested in initial cpu_set\n"));
 __builtin_va_end(args);return 0;
}
#define PROCESS_CREATE_CPU_LOG_INVALID 1
#define PROCESS_CREATE_CPU_LOG_REQUESTED 2
void *process_create_thread_alloc_pages_bridge(int,unsigned long) __asm__("reference_process_create_thread_alloc_pages_bridge");
void process_create_cpu_log_bridge(int,int,int) __asm__("reference_process_create_cpu_log_bridge");

#line 785 "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c"
void *process_create_thread_alloc_pages_bridge(int npages,
					      unsigned long flags)
{
	return _ihk_mc_alloc_aligned_pages_node(npages, PAGE_P2ALIGN, flags, -1, IHK_MC_PG_KERNEL, -1, __FILE__, __LINE__);
}

#line 268 "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c"
void process_create_cpu_log_bridge(int event, int pid, int cpu)
{
	switch (event) {
	case PROCESS_CREATE_CPU_LOG_INVALID:
		kprintf("%s: invalid CPU requested in initial cpu_set\n",
			"create_thread");
		break;
	case PROCESS_CREATE_CPU_LOG_REQUESTED:
		dkprintf("%s: pid: %d, CPU: %d\n",
			"create_thread", pid, cpu);
		break;
	default:
		break;
	}
}

#line 60 "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/fixture/actual_reference.c"

extern void *rust_alloc(int,unsigned long) __asm__("process_create_thread_alloc_pages_bridge");
extern void rust_log(int,int,int) __asm__("process_create_cpu_log_bridge");
const char *const process_tracked_allocator_source_file="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c";
const int process_create_thread_alloc_pages_source_line=788;
struct ddebug __aligned(8) __attribute__((section("__verbose"))) process_create_cpu_debug={
 .file="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c",.func="process_create_cpu_log_bridge",.line=276,.flags=DDEBUG_DEFAULT,
};
extern struct ddebug __start___verbose[],__stop___verbose[];
extern const unsigned long SOURCE10_RUST_ABI[12];
static const unsigned long C_ABI[12]={sizeof(struct ddebug),__alignof__(struct ddebug),
 __builtin_offsetof(struct ddebug,file),__builtin_offsetof(struct ddebug,func),
 __builtin_offsetof(struct ddebug,fmt),__builtin_offsetof(struct ddebug,fmt)+sizeof(void *),
 sizeof(int),sizeof(unsigned long),sizeof(void *),PAGE_P2ALIGN,IHK_MC_PG_KERNEL,788};
static void reset(void) { actual=(struct event){0}; }
static void save(void) {expected=actual;reset();}
static void compare(void) {
 CHECK(actual.kind==expected.kind);
 for(int i=0;i<8;++i) CHECK(actual.value[i]==expected.value[i]);
 if(actual.kind==1) {CHECK(same(actual.file,expected.file));CHECK(same(actual.file,"/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c"));}
 if(actual.kind==2) {CHECK(same(actual.format,expected.format));CHECK(same(actual.name,expected.name));}
 reset();
}
int main(void) {
 for(int i=0;i<12;++i){CHECK(C_ABI[i]==SOURCE10_RUST_ABI[i]);printf("ABI row=%d value=%lu\n",i,C_ABI[i]);}
 struct ddebug bits={.line=0xabcdef,.flags=0x5a};
 CHECK(*(unsigned int *)((char *)&bits+24)==0x5aabcdefU);
 int descriptors=0;
 for(struct ddebug *d=__start___verbose;d<__stop___verbose;++d) {
  CHECK(same(d->file,"/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/candidate/kernel/process.c"));CHECK(same(d->func,"process_create_cpu_log_bridge"));
  CHECK(d->line==276 && d->flags==0 && d->fmt==NULL);++descriptors;
 }
 CHECK(descriptors==2);
 const int pages[]={(-2147483647-1),-1,0,1,2,2147483647};
 const unsigned long flags[]={0,1,~0UL};int comparisons=0;static char storage;
 for(int n=0;n<6;++n)for(int f=0;f<3;++f)for(int ok=0;ok<2;++ok) {
  alloc_result=ok?&storage:NULL;reset();
  void *reference=process_create_thread_alloc_pages_bridge(pages[n],flags[f]);
  CHECK(reference==alloc_result);CHECK(actual.value[6]==788);save();
  void *result=rust_alloc(pages[n],flags[f]);CHECK(result==reference);compare();++comparisons;
 }
 const int events[]={(-2147483647-1),1,2,3,2147483647};
 const unsigned int debug_flags[]={0,1,2,255};
 const int pairs[3][2]={{-1,(-2147483647-1)},{0,0},{2147483647,2147483647}};
 for(int e=0;e<5;++e)for(int f=0;f<4;++f)for(int pair=0;pair<3;++pair) {
  for(struct ddebug *d=__start___verbose;d<__stop___verbose;++d)d->flags=debug_flags[f];
  reset();process_create_cpu_log_bridge(events[e],pairs[pair][0],pairs[pair][1]);
  CHECK(actual.kind==((events[e]==1 || (events[e]==2 && debug_flags[f]))?2:0));save();
  rust_log(events[e],pairs[pair][0],pairs[pair][1]);compare();++comparisons;
 }
 CHECK(comparisons==96);
 printf("PASS actual-original-C/Rust create leaves: 96 comparisons, 12 genuine ABI rows, tracked allocation bytes/line and dynamic-debug selector/output parity\n");
 return 0;
}
