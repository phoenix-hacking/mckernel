// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="actual_abi.rs"] pub mod abi;
#[path="actual_ddebug.rs"] pub mod debug;
const PROCESS_CREATE_CPU_LOG_INVALID: abi::CInt=1;
const PROCESS_CREATE_CPU_LOG_REQUESTED: abi::CInt=2;
unsafe extern "C" { fn kprintf(format:*const i8,...)->abi::CInt; }
mod mem_helpers {
    use core::ffi::c_void;
    use crate::abi::{CInt,CULong};
    unsafe extern "C" { fn fixture_alloc(n:CInt,a:CInt,f:CULong,node:CInt,k:CInt,v:CULong,file:*mut i8,line:CInt)->*mut c_void; }
    pub unsafe fn _ihk_mc_alloc_aligned_pages_node(n:CInt,a:CInt,f:CULong,node:CInt,k:CInt,v:CULong,file:*mut i8,line:CInt)->*mut c_void {
        unsafe { fixture_alloc(n,a,f,node,k,v,file,line) }
    }
}
include!("create_leafs.ACTUAL-RUST.inc");
#[no_mangle] pub static SOURCE10_RUST_ABI:[usize;12]=[
    core::mem::size_of::<debug::Ddebug>(),core::mem::align_of::<debug::Ddebug>(),
    core::mem::offset_of!(debug::Ddebug,file),core::mem::offset_of!(debug::Ddebug,func),
    core::mem::offset_of!(debug::Ddebug,fmt),core::mem::offset_of!(debug::Ddebug,line_flags),
    core::mem::size_of::<abi::CInt>(),core::mem::size_of::<abi::CULong>(),
    core::mem::size_of::<*mut core::ffi::c_void>(),0,0,788,
];
