// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="actual_abi.rs"] pub mod abi;
mod pte_helpers {
 use crate::abi::{CInt,SizeT};
const PTL4_SHIFT: u32 = 39;
const PTL3_SHIFT: u32 = 30;
const PTL2_SHIFT: u32 = 21;
const PTL1_SHIFT: u32 = 12;
const PTL4_SIZE: SizeT = 1 << PTL4_SHIFT;
const PTL3_SIZE: SizeT = 1 << PTL3_SHIFT;
const PTL2_SIZE: SizeT = 1 << PTL2_SHIFT;
const PTL1_SIZE: SizeT = 1 << PTL1_SHIFT;
pub extern "C" fn pgsize_to_tbllv(pgsize: SizeT) -> CInt {
    match pgsize {
        PTL1_SIZE => 1,
        PTL2_SIZE => 2,
        PTL3_SIZE => 3,
        PTL4_SIZE => 4,
        _ => 0,
    }
}

pub extern "C" fn tbllv_to_contpgsize(_level: CInt) -> SizeT {
    0
}

}
mod x86_memory_helpers {
 use crate::abi::CULong;
 unsafe extern "C" {fn fixture_tlb(addr:CULong);}
 pub unsafe fn flush_tlb_single(addr:CULong){unsafe{fixture_tlb(addr)}}
}
mod page_helpers {
 include!("actual_page_types.rs");
 unsafe extern "C" {fn fixture_unmap(page:*mut Page)->CInt;}
 pub unsafe fn page_unmap(page:*mut Page)->CInt{unsafe{fixture_unmap(page)}}
 pub const LAYOUT:[usize;6]=[core::mem::size_of::<Page>(),core::mem::align_of::<Page>(),
 core::mem::offset_of!(Page,count),core::mem::offset_of!(Page,mapped),
 core::mem::offset_of!(Page,offset),core::mem::offset_of!(Page,pgshift)];
}
include!("page_table_providers.ACTUAL-RUST.inc");
#[no_mangle]pub static SOURCE_NEXT_RUST_ABI:[usize;12]=[
 page_helpers::LAYOUT[0],page_helpers::LAYOUT[1],page_helpers::LAYOUT[2],
 page_helpers::LAYOUT[3],page_helpers::LAYOUT[4],page_helpers::LAYOUT[5],
 1<<12,1<<21,1<<30,1<<39,core::mem::size_of::<abi::SizeT>(),core::mem::size_of::<*mut page_helpers::Page>()];
