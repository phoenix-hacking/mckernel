/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include "source/arch/x86_64/kernel/syscall.c"
_Static_assert(sizeof(long)==8 && sizeof(int)==4 && sizeof(void *)==8,"x86 LP64");
_Static_assert(__builtin_types_compatible_p(__typeof__(&do_kill),unsigned long (*)(struct thread *,int,int,int,siginfo_t *,int)),"public do_kill ABI");
_Static_assert(sizeof(struct mcs_rwlock_node)==64,"noirq node extent");
_Static_assert(_Alignof(struct mcs_rwlock_node)==64,"noirq node alignment");
_Static_assert(offsetof(struct mcs_rwlock_node,count)==0,"noirq node count");
_Static_assert(offsetof(struct mcs_rwlock_node,type)==4,"noirq node kind");
_Static_assert(offsetof(struct mcs_rwlock_node,locked)==5,"noirq node locked");
_Static_assert(offsetof(struct mcs_rwlock_node,next)==8,"noirq node next");
_Static_assert(sizeof(mcs_rwlock_lock_t)==64 && _Alignof(mcs_rwlock_lock_t)==64,"real lock layout");
_Static_assert(sizeof(siginfo_t)==128,"signal-info full bytes");
_Static_assert(HASH_SIZE==73 && SI_KERNEL==0x80,"retained header constants");
