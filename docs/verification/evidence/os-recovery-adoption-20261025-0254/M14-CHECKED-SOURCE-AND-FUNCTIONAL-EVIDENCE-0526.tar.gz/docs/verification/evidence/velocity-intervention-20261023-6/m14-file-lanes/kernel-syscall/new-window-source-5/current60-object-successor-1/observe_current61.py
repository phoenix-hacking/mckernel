"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read actual final-union ELF symbols; no compiler or runtime operation.
"""
from pathlib import Path
import ast
import hashlib
import json
import struct
D = Path(__file__).parent
P = json.loads((D / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
C = json.loads((D / "PROVIDER-CONTRACT.FROZEN55.json").read_bytes())
row = P["Elf_source"]
raw = Path(row["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
tree = ast.parse(raw)
nodes = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom)) or isinstance(n, ast.ClassDef) and n.name == "Elf"]
ns = {"Path": Path, "struct": struct}
exec(compile(ast.Module(body=nodes, type_ignores=[]), row["path"], "exec"), ns)
Elf = ns["Elf"]
O = D / "output-1"
def definitions(elf, name):
    return [r for r in elf.symbols if r["name"] == name and 0 < r["shndx"] < len(elf.sections)]
def globals_of(elf):
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and r["type"] == 2 and 0 < r["shndx"] < len(elf.sections)}
def unresolved(elf):
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and r["shndx"] == 0}
rust = Elf(O / "mckernel_rust.cpu37.o")
partial = Elf(O / "CPU37.partial.o")
process = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-8/object-successor-1/output-1/process.selected.o'))
f03 = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-5/current60-object-successor-1/output-1/F03.selected.o'))
f04 = Elf(Path("/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-3/ordinary-HOST-qualification-preparation-1/bounded-C-include-namespace-transport-correction-1/output-1/F04.selected.o"))
proof = {}
for name in C["combined55"] + C["F04_100"]:
    result = {}
    for label, elf in (("Rust", rust), ("combined_partial", partial)):
        rows = definitions(elf, name)
        assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2, (label, name, rows)
        assert name not in unresolved(elf), (label, name, "unresolved provider")
        result[label] = rows
    for label, elf in (("process_C", process), ("F03_C", f03), ("F04_C", f04)):
        assert not definitions(elf, name), (label, name, "C definition remains")
    proof[name] = result
components = [rust, process, f03, f04]
# Include all global defined symbols when calculating undefined resolution;
# defined data and assembly symbols can resolve ordinary C/Rust externals.
COMMON_PROCESS = {"resource_set_list": 16, "resource_set_lock": 64, "runq_reservation_lock": 4}
COMMON_F03 = {"linux_clock_gettime": 8, "linux_printk": 8, "linux_wait_event": 8,
              "shmid_index": 4096, "uti_desc": 8}
COMMON_EXPECTED = {id(rust): {}, id(process): COMMON_PROCESS, id(f03): COMMON_F03,
                   id(f04): {}, id(partial): {**COMMON_PROCESS, **COMMON_F03}}
def global_defs(elf):
    common = [r for r in elf.symbols if r["shndx"] == 0xfff2]
    expected = COMMON_EXPECTED[id(elf)]
    assert len(common) == len(expected), ("COMMON cardinality", common, expected)
    assert {r["name"]: r["size"] for r in common} == expected, ("COMMON names/sizes", common, expected)
    for row in common:
        alignment = row["value"]
        assert row["bind"] == 1 and row["type"] == 1 and row["size"] > 0, row
        assert alignment > 0 and alignment & (alignment - 1) == 0, row
    return {r["name"] for r in elf.symbols if r["bind"] == 1 and
            (0 < r["shndx"] < len(elf.sections) or
             r["shndx"] == 0xfff2 and r["type"] == 1)}
# SHN_COMMON stores alignment in st_value; it is never a section-table index.
global_defs(partial)
all_defined = set().union(*(global_defs(e) for e in components))
all_undefined = set().union(*(unresolved(e) for e in components))
assert globals_of(partial) == set().union(*(globals_of(e) for e in components))
assert unresolved(partial) == all_undefined - all_defined
fallback = Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-8/object-successor-1/output-1/process.fallback.o'))
for name, expected in C["process_fallback_expected"].items():
    rows = definitions(fallback, name)
    assert len(rows) == 1 and rows[0]["type"] == 2, (name, rows)
    assert rows[0]["bind"] == (1 if expected == ["T"] else 0), (name, expected, rows)
for label in ("mincore_real_C_ABI_object", "mincore_fallback_C"):
    row = C[label]
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
real_abi = Elf(Path(C["mincore_real_C_ABI_object"]["path"]))
expected_abi = real_abi.data("f03_mincore_C_ABI")
assert len(expected_abi) == 21 * 8
assert rust.data("f03_mincore_Rust_ABI") == partial.data("f03_mincore_Rust_ABI") == expected_abi
mincore_fallback = Elf(Path(C["mincore_fallback_C"]["path"]))
rows = definitions(mincore_fallback, "sys_mincore")
assert len(rows) == 1 and rows[0]["bind"] == 1 and rows[0]["type"] == 2
source8_reference = Elf(Path(C["source8_actual_C_fixture"]["path"]))
expected_source8_abi = source8_reference.data("C_ABI")
assert len(expected_source8_abi) == 12 * 8
assert rust.data("SOURCE8_RUST_ABI") == partial.data("SOURCE8_RUST_ABI") == expected_source8_abi
trace_row = C["trace_observer"]
trace_raw = Path(trace_row["path"]).read_bytes()
assert hashlib.sha256(trace_raw).hexdigest() == trace_row["sha256"]
trace_ns = {}
exec(compile(trace_raw, trace_row["path"], "exec"), trace_ns)
trace_proof = {label: trace_ns["observe"](path, C["trace_lines"], C["trace_filename"]) for label, elf, path in (("selected_C",process,Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-8/object-successor-1/output-1/process.selected.o')),("partial",partial,O/"CPU37.partial.o"))}


# Exact new export and six own C callbacks, with real readonly C/Rust 30-word ABI.
move_fallback = Elf(O / "F03.fallback.o")
move_abi = f03.data("f03_move_pages_C_ABI")
assert len(move_abi) == 30 * 8
assert move_fallback.data("f03_move_pages_C_ABI") == move_abi
assert rust.data("f03_move_pages_Rust_ABI") == partial.data("f03_move_pages_Rust_ABI") == move_abi
for name in ["move_pages_verify_bridge", "move_pages_get_nr_nodes_bridge", "move_pages_page_table_lock_bridge", "move_pages_page_table_unlock_bridge", "move_pages_smp_call_bridge", "move_pages_log_bridge"]:
    assert not definitions(f03,name), name
    rows=definitions(move_fallback,name)
    assert len(rows)==1 and rows[0]["type"]==2 and rows[0]["bind"]==0, (name,rows)
rows=definitions(move_fallback,"sys_move_pages")
assert len(rows)==1 and rows[0]["bind"]==1 and rows[0]["type"]==2

out = dict(status="PASS_CURRENT55_PLUS_SOURCE8_FIVE_PLUS_F04100_PROVIDERS_ABI_AND_TRACE_ONLY", providers=proof, count=len(proof), source8_ABI_hex=expected_source8_abi.hex(), trace_metadata=trace_proof, SDK=False, native=False, production_default=False)
with (Path(__file__).parent / "ACTUAL-UNION-PROVIDERS.COMMON-CORRECTED.json").open("x") as f:
    json.dump(out, f, indent=2, sort_keys=True)
    f.write("\n")
print(json.dumps(dict(status=out["status"], providers=len(proof))))
