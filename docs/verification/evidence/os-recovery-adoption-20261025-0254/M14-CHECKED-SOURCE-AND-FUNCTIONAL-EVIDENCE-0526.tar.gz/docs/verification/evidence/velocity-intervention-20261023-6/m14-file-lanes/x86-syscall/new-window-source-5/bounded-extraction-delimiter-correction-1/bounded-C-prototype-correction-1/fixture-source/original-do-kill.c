/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * The entire original function include is byte-extracted unchanged. Build its
 * object first, then objcopy-renames do_kill and its recursive relocations; this
 * preserves actual __FUNCTION__ diagnostic bytes and original recursive C path.
 */
#include <types.h>
#include <affinity.h>
#include <process.h>
#include <syscall.h>
#include <cls.h>
#include <kmalloc.h>
#include <errno.h>
#include <string.h>
#include <ihk/debug.h>
extern void interrupt_syscall(struct thread *, int sig);
extern struct cpu_local_var *fixture_cpu(void);
#undef get_this_cpu_local_var
#define get_this_cpu_local_var fixture_cpu
#include "original-do-kill.ACTUAL.inc"
