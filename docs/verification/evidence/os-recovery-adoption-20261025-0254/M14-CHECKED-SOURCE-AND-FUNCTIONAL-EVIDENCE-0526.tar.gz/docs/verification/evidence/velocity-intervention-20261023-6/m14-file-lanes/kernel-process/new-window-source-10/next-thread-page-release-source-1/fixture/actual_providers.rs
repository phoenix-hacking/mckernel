// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="actual_abi.rs"] pub mod abi;
const KERNEL_STACK_NR_PAGES:abi::CULong=32;
mod mem_helpers {
 use core::ffi::c_void;
 unsafe extern "C" { fn fixture_free(ptr:*mut c_void,pages:i32,kind:i32,file:*mut i8,line:i32); }
 pub unsafe fn _ihk_mc_free_pages(ptr:*mut c_void,pages:i32,kind:i32,file:*mut i8,line:i32) {unsafe {fixture_free(ptr,pages,kind,file,line)}}
}
include!("thread_page_release.ACTUAL-RUST.inc");
#[no_mangle] pub static SOURCE_NEXT_RUST_ABI:[usize;5]=[32,0,core::mem::size_of::<abi::CInt>(),core::mem::size_of::<*mut core::ffi::c_void>(),3501];
