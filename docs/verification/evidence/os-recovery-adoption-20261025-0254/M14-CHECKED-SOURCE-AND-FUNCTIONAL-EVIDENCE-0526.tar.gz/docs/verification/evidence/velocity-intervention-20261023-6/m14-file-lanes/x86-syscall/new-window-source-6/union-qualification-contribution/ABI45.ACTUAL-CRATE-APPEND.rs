// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Append this witness module to the private actual full compute crate only.
mod f06_actual_union_abi45_witness {
 use core::mem::{size_of,align_of,offset_of};
 use crate::abi::{self,Thread,Process,SigInfo};
 use crate::lock_helpers::McsRwlockNodeIrqsave;
 #[used]
 #[no_mangle]
 pub static F06_DO_KILL_RUST_ABI45: [usize;45] = [size_of::<Thread>(),align_of::<Thread>(),size_of::<Process>(),align_of::<Process>(),
 size_of::<abi::ProcessHash>(),size_of::<abi::ThreadHash>(),offset_of!(abi::ProcessHash,lock),
 offset_of!(Thread,proc),offset_of!(Thread,sigmask),offset_of!(Thread,sigpending),
 offset_of!(Thread,sigpendinglock),offset_of!(Thread,sigcommon),offset_of!(Thread,sigevent),
 offset_of!(Thread,status),offset_of!(Thread,refcount),offset_of!(Thread,cpu_id),
 offset_of!(Process,threads_list),offset_of!(Process,threads_lock),offset_of!(Process,update_lock),
 offset_of!(Process,pid),offset_of!(Process,pgid),offset_of!(Process,parent),offset_of!(Process,main_thread),
 offset_of!(Process,ruid),offset_of!(Process,euid),offset_of!(Process,suid),offset_of!(Process,status),
 size_of::<abi::SigCommon>(),offset_of!(abi::SigCommon,sigpending),size_of::<abi::SigPending>(),
 offset_of!(abi::SigPending,info),offset_of!(abi::SigPending,ptracecont),size_of::<SigInfo>(),
 size_of::<abi::ResourceSet>(),offset_of!(abi::ResourceSet,process_hash),offset_of!(abi::ResourceSet,thread_hash),
 size_of::<abi::CpuLocalVar>(),offset_of!(abi::CpuLocalVar,resource_set),offset_of!(abi::CpuLocalVar,no_preempt),
 size_of::<abi::KmallocHeader>(),offset_of!(abi::KmallocHeader,link),offset_of!(abi::KmallocHeader,size),
 size_of::<abi::McsRwlockLock>(),align_of::<abi::McsRwlockLock>(),size_of::<McsRwlockNodeIrqsave>()];
}
