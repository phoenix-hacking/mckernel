// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// SOURCE ONLY: actual C bridge bodies and existing Rust scheduler body, controlled providers.
#![allow(dead_code)]
use core::mem::{size_of,offset_of,MaybeUninit};
use std::sync::Mutex;
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt,CULong,SizeT,Thread,SchedParam};
const EINVAL:CInt=22;const SCHED_NORMAL:CInt=0;const SCHED_FIFO:CInt=1;
const SCHED_RR:CInt=2;const SCHED_BATCH:CInt=3;const SCHED_IDLE:CInt=5;
const MAX_USER_RT_PRIO:CInt=100;
include!("backend.ACTUAL-RUST.rs.inc");
mod debug {
 #[repr(C)] pub struct Ddebug {pub file:*const i8,pub func:*const i8,pub fmt:*const i8,pub line_flags:u32}
}
unsafe extern "C" {
 fn kprintf(format:*const i8,...)->CInt;
 fn fixture_set_flags(flag:u32);
 static f03_sched_C_ABI:[usize;9];
 fn original_sched_find_thread_bridge(pid:CInt)->usize;
 fn original_sched_thread_unlock_bridge(t:usize);
 fn original_sched_apply_scheduler_bridge(t:usize,p:CInt,a:usize)->CInt;
 fn original_sched_hold_thread_bridge(t:usize)->CInt;
 fn original_sched_release_thread_bridge(t:usize);
 fn original_sched_request_migrate_bridge(cpu:CInt,t:usize);
 fn original_sched_setparam_log_bridge(pid:CInt,a:CULong);
}
static TRACE:Mutex<Vec<(u8,[u64;2])>>=Mutex::new(Vec::new());
static FORMATS:Mutex<Vec<Vec<u8>>>=Mutex::new(Vec::new());
fn event(n:u8,a:u64,b:u64){TRACE.lock().unwrap().push((n,[a,b]));}
#[no_mangle] unsafe extern "C" fn fixture_format(p:*const i8,n:usize){FORMATS.lock().unwrap().push(core::slice::from_raw_parts(p.cast(),n).to_vec())}
#[no_mangle] pub unsafe extern "C" fn find_thread(pid:CInt,tid:CInt)->*mut Thread{event(1,pid as u64,tid as u64);0x12000usize as *mut Thread}
#[no_mangle] pub unsafe extern "C" fn thread_unlock(t:*mut Thread){event(2,t as u64,0)}
#[no_mangle] pub unsafe extern "C" fn hold_thread(t:*mut Thread)->CInt{event(3,t as u64,0);-7}
#[no_mangle] pub unsafe extern "C" fn release_thread(t:*mut Thread){event(4,t as u64,0)}
#[no_mangle] pub unsafe extern "C" fn sched_request_migrate(cpu:CInt,t:*mut Thread){event(5,cpu as u64,t as u64)}
mod process_helpers {pub use super::{find_thread,thread_unlock,hold_thread,release_thread};}
mod sched_helpers {pub use super::{setscheduler_body_result,sched_request_migrate};}
include!("candidate.FROZEN.rs.inc");
fn take()->Vec<(u8,[u64;2])>{std::mem::take(&mut *TRACE.lock().unwrap())}
fn bytes()->Vec<Vec<u8>>{std::mem::take(&mut *FORMATS.lock().unwrap())}
unsafe fn forwarding(selected:bool,pid:CInt,cpu:CInt,addr:usize)->(usize,CInt,Vec<(u8,[u64;2])>) {
 assert!(take().is_empty());
 let found;if selected {
  found=f03_sched_bridges_candidate::find(pid);f03_sched_bridges_candidate::unlock(addr);
  let held=f03_sched_bridges_candidate::hold(addr);f03_sched_bridges_candidate::release(addr);
  f03_sched_bridges_candidate::migrate(cpu,addr);(found,held,take())
 } else {
  found=original_sched_find_thread_bridge(pid);original_sched_thread_unlock_bridge(addr);
  let held=original_sched_hold_thread_bridge(addr);original_sched_release_thread_bridge(addr);
  original_sched_request_migrate_bridge(cpu,addr);(found,held,take())
 }
}
fn main(){unsafe {
 let abi=[size_of::<SchedParam>(),core::mem::align_of::<SchedParam>(),offset_of!(SchedParam,sched_priority),size_of::<Thread>(),offset_of!(Thread,sched_param),offset_of!(Thread,sched_policy),size_of::<abi::Process>(),size_of::<CULong>(),size_of::<CInt>()];
 assert_eq!(abi,f03_sched_C_ABI);
 let mut forwards=0;for pid in [i32::MIN,-1,0,1,i32::MAX] {for cpu in [-1,0,7] {for addr in [0usize,0x1000,usize::MAX] {
  let old=forwarding(false,pid,cpu,addr);let new=forwarding(true,pid,cpu,addr);assert_eq!(old,new);
  assert_eq!(new.0,0x12000);assert_eq!(new.1,-7);
  assert_eq!(new.2,vec![(1,[0,pid as u64]),(2,[addr as u64,0]),(3,[addr as u64,0]),(4,[addr as u64,0]),(5,[cpu as u64,addr as u64])]);forwards+=1;
 }}}
 let mut apply=0;for policy in [-1,0,1,2,3,5,6,999] {for priority in [i32::MIN,-1,0,1,99,100,i32::MAX] {
  let mut a=Box::new(MaybeUninit::<Thread>::zeroed());let mut b=Box::new(MaybeUninit::<Thread>::zeroed());
  let ap=a.as_mut_ptr();let bp=b.as_mut_ptr();(*ap).sched_policy=43;(*bp).sched_policy=43;
  (*ap).sched_param.sched_priority=44;(*bp).sched_param.sched_priority=44;
  let param=SchedParam{sched_priority:priority};
  let old=original_sched_apply_scheduler_bridge(ap as usize,policy,&param as *const _ as usize);
  let new=f03_sched_bridges_candidate::apply(bp as usize,policy,&param as *const _ as usize);
  let valid=match policy {1|2=>(1..=99).contains(&priority),0|3|5=>priority==0,_=>true};
  assert_eq!(old,new);assert_eq!(new,if valid{0}else{-22});
  assert_eq!((*ap).sched_policy,(*bp).sched_policy);assert_eq!((*ap).sched_param.sched_priority,(*bp).sched_param.sched_priority);
  assert_eq!((*bp).sched_policy,if valid{policy}else{43});assert_eq!((*bp).sched_param.sched_priority,if valid{priority}else{44});apply+=1;
 }}
 let mut logs=0;for flag in [0u32,1,128,255] {fixture_set_flags(flag);for pid in [i32::MIN,-1,0,i32::MAX] {for addr in [0usize,0x1234,usize::MAX] {
  original_sched_setparam_log_bridge(pid,addr as CULong);let old=bytes();f03_sched_bridges_candidate::log(pid,addr as CULong);let new=bytes();assert_eq!(old,new);
  let expected=if flag==0{vec![]}else{vec![format!("sched_setparam: pid: {}, uparam: 0x{:x}\n",pid,addr).into_bytes()]};assert_eq!(new,expected);logs+=1;
 }}}
 println!("PASS scheduler actual-C/Rust forwarding {} cases, actual scheduler-body validation/store {} cases, gated exact-byte log {} cases, real ABI 9 words",forwards,apply,logs);
}}
