Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Minimal paired normal move_pages producer selector is prepared over canonicaled663442. Existing Rust/x86 producer gets f03_move_pages_candidate; existing syscall.c source property under RUST_KERNEL_ENABLED gets MCKERNEL_RUST_F03_MOVE_PAGES. Existing F03 IO/mincore pairs, F04 SSE1/header/filename producer and all flags/fallback remain unchanged. Copy-error candidate remains absent/defaultOFF.

Reused the previous three-case LANGUAGES NONE CMake helper with normal move_pages pair and explicit copy-error exclusion. Descriptor is ready under the same proposed CPU6/onejob512MiB15CPU25wall+6/F4MiB/FD256/core0 profile. No checker/configure/compiler executed. Root must pair this producer with the reviewed private F03 runtime successor before SDK/default qualification; selector-only source is not retirement.
