"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepared CPU6 ordinary fixture wrapper; do not invoke before coordinator slot grant.
"""
from pathlib import Path
import ast,hashlib,json,os,resource,signal,time
D=Path(__file__).resolve().parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(row):assert pin(Path(row['path']))==row,row

def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True);f.write('\n')
recipe_path=D/'PROPOSED-COMMANDS.NOT-GRANTED.json';manifest_path=D/'FIXTURE-SOURCE-HANDOFF.NOT-GRANTED.json'
assert pin(recipe_path)['sha256']=='bf58a32c57e0b4115a0c33fcc6eff84bc10527a58dccf2341a6fed635dedf8de'
assert pin(manifest_path)['sha256']=='f7ceab63f1f4947d6ebc7df999e64f1caf96177ba111d17f90168a8bfc7ab8e7'
manifest=json.loads(manifest_path.read_text());recipe=json.loads(recipe_path.read_text())
for row in manifest['fixture_sources']+manifest['actual_provider_headers']:check(row)
for key in ['actual_abi','frozen_runtime_fragment','real_30_C_ABI','real_30_Rust_ABI']:check(manifest[key])
tools=[('/home/holden/mckernel-work/toolchains/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc','028fd60b0e0add5505c661cd3ccde91393d615c8729bd95d94ab1e91409b36a1'),('/usr/bin/gcc-9','6cb2d84ccd9fd3485d4e47ba032e626be65692601c38fad46866a6b565f3100f'),('/usr/bin/cc','6cb2d84ccd9fd3485d4e47ba032e626be65692601c38fad46866a6b565f3100f')]
for path,sha in tools:assert pin(Path(path))['sha256']==sha
helper=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
assert pin(helper)['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(helper.read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
ns={'__file__':str(helper)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'),ns)
O=D/'actual-output-first-1';O.mkdir(mode=0o700);CAP=D/'actual-capture-first-1';CAP.mkdir(mode=0o700)
os.environ['TMPDIR']=str(O);os.environ['RUST_MIN_STACK']='2097152';os.sched_setaffinity(0,{6});os.chdir(O)
for sig in ns['STOP_SIGNALS']:signal.signal(sig,ns['stop'])
records=[];begin=time.monotonic()
try:
 write(D/'ACTUAL-READSET-AND-PROFILE-1.json',dict(scope=SCOPE,authority='Requires actual root CPU6 onejob grant before invocation; prepared descriptor itself supplies no admission.',manifest=pin(manifest_path),recipe=pin(recipe_path),driver=pin(Path(__file__)),tools=[pin(Path(p)) for p,_ in tools],helper=pin(helper),sources=manifest['fixture_sources'],actual_provider_headers=manifest['actual_provider_headers'],actualABI=manifest['actual_abi'],CPU=6,jobs=1,AS=2<<30,shared_CPU=60,shared_wall=90,retirement=6,FSIZE=32<<20,FD=256,core=0,stack=2<<20,output_namespace=str(O),capture_namespace=str(CAP),legacy_failed_copy_replayed=False))
 for original in recipe['commands']:
  command=json.loads(json.dumps(original));command['argv']=[a.replace(str(D/'PROPOSED-output'),str(O)) for a in command['argv']];command['cwd']=str(O);command['purpose']=SCOPE+' '+command['label']
  label=command['label'];cap=CAP/label;cap.mkdir(mode=0o700);write(cap/'command.json',command)
  remaining=90-(time.monotonic()-begin);cpu_remaining=max(1,int(60-ns['cpu_used']()));assert remaining>0 and ns['cpu_used']()<60
  def limits():
   os.sched_setaffinity(0,{6})
   for key,value in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,cpu_remaining),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]:resource.setrlimit(key,(value,value))
  joined=ns['owned_capture'](command,cap,remaining,limits);write(cap/'whole-join.json',joined);records.append(dict(label=label,command=pin(cap/'command.json'),join=joined))
  assert joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent'] and joined['closed_streams'] and joined['error'] is None and joined['retirement_error'] is None and not joined['timed_out'],joined
  if label=='02-legacy-defined-domain-only':assert (cap/'stdout').read_text()=='PASS move_pages actual C-entry/Rust defined-domain parity 20 cases; independent guarded Rust copy-failure cases 0\n'
  if label=='04-checked-normal-and-independent-guarded-copyfault':assert (cap/'stdout').read_text()=='PASS move_pages actual C-entry/Rust defined-domain parity 20 cases; independent guarded Rust copy-failure cases 12\n'
 result=dict(scope=SCOPE,status='PASS_20_LEGACY_20_CHECKED_DEFINED_DOMAIN_AND_12_RUST_ONLY_GUARDED_COPYFAULT_CASES',records=records,readset=pin(D/'ACTUAL-READSET-AND-PROFILE-1.json'),outputs=[pin(p) for p in sorted(O.iterdir()) if p.is_file()],CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,CPU6_released=True,canonical_edits=False,legacy_failed_copy_replayed=False,default_cfg_changed=False,production_default_image=False,native=False)
 write(D/'ACTUAL-RESULT-FIRST-1.json',result);print(json.dumps(dict(status=result['status'],receipt=pin(D/'ACTUAL-RESULT-FIRST-1.json'),CPU6_released=True)))
except BaseException as exc:
 result=dict(scope=SCOPE,status='STOP_FIRST_UNEXPECTED_RESULT',error=type(exc).__name__+': '+str(exc),records=records,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,CPU6_released=all(r['join']['direct_child_joined'] and r['join']['group_absent'] and r['join']['closed_streams'] for r in records))
 write(D/'ACTUAL-FIRST-FAILURE-1.json',result);print(json.dumps(dict(status=result['status'],error=result['error'],receipt=pin(D/'ACTUAL-FIRST-FAILURE-1.json'),CPU6_released=result['CPU6_released'])));raise
