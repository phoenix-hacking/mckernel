/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
#include <lwk/stddef.h>
extern int vsnprintf(char *,size_t,const char *,va_list);
extern void fixture_format(const char *,size_t);
int kprintf(const char *format,...) {
 char bytes[512];va_list args;va_start(args,format);
 int n=vsnprintf(bytes,sizeof(bytes),format,args);va_end(args);
 if(n>=0 && (size_t)n<sizeof(bytes)) fixture_format(bytes,(size_t)n);
 return n;
}
extern int setscheduler_body_result(unsigned long,int,unsigned long,size_t,size_t,size_t,size_t);
#define MCKERNEL_RUST_SCHED_POLICY_HELPERS 1
#define sched_find_thread_bridge original_sched_find_thread_bridge
#define sched_thread_unlock_bridge original_sched_thread_unlock_bridge
#define sched_apply_scheduler_bridge original_sched_apply_scheduler_bridge
#define sched_hold_thread_bridge original_sched_hold_thread_bridge
#define sched_release_thread_bridge original_sched_release_thread_bridge
#define sched_request_migrate_bridge original_sched_request_migrate_bridge
#define sched_setparam_log_bridge original_sched_setparam_log_bridge
static int setscheduler(struct thread *thread, int policy, struct sched_param *param)
{
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
	return setscheduler_body_result((unsigned long)thread, policy,
			(unsigned long)param, sizeof(*param),
			__builtin_offsetof(struct sched_param, sched_priority),
			__builtin_offsetof(struct thread, sched_param),
			__builtin_offsetof(struct thread, sched_policy));
#else
	int ret;

	ret = setscheduler_validate(policy, param->sched_priority);
	if (ret) {
		return ret;
	}

	memcpy(&thread->sched_param, param, sizeof(*param));
	thread->sched_policy = policy;

	return 0;
#endif
}

unsigned long
sched_find_thread_bridge(int pid)
{
	return (unsigned long)find_thread(0, pid);
}

void
sched_thread_unlock_bridge(unsigned long thread_addr)
{
	thread_unlock((struct thread *)thread_addr);
}

int
sched_apply_scheduler_bridge(unsigned long thread_addr, int policy,
		unsigned long param_addr)
{
	return setscheduler((struct thread *)thread_addr, policy,
			(struct sched_param *)param_addr);
}

int
sched_hold_thread_bridge(unsigned long thread_addr)
{
	return hold_thread((struct thread *)thread_addr);
}

void
sched_release_thread_bridge(unsigned long thread_addr)
{
	release_thread((struct thread *)thread_addr);
}

void
sched_request_migrate_bridge(int cpu_id, unsigned long thread_addr)
{
	sched_request_migrate(cpu_id, (struct thread *)thread_addr);
}

void
sched_setparam_log_bridge(int pid, unsigned long uparam_addr)
{
	dkprintf("sched_setparam: pid: %d, uparam: 0x%lx\n", pid,
			uparam_addr);
}

/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_find_thread_bridge),unsigned long (*)(int)),"sched_find_thread_bridge actual ABI");
__typeof__(&sched_find_thread_bridge) f03_actual_address_sched_find_thread_bridge = &sched_find_thread_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_thread_unlock_bridge),void (*)(unsigned long)),"sched_thread_unlock_bridge actual ABI");
__typeof__(&sched_thread_unlock_bridge) f03_actual_address_sched_thread_unlock_bridge = &sched_thread_unlock_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_apply_scheduler_bridge),int (*)(unsigned long,int,unsigned long)),"sched_apply_scheduler_bridge actual ABI");
__typeof__(&sched_apply_scheduler_bridge) f03_actual_address_sched_apply_scheduler_bridge = &sched_apply_scheduler_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_hold_thread_bridge),int (*)(unsigned long)),"sched_hold_thread_bridge actual ABI");
__typeof__(&sched_hold_thread_bridge) f03_actual_address_sched_hold_thread_bridge = &sched_hold_thread_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_release_thread_bridge),void (*)(unsigned long)),"sched_release_thread_bridge actual ABI");
__typeof__(&sched_release_thread_bridge) f03_actual_address_sched_release_thread_bridge = &sched_release_thread_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_request_migrate_bridge),void (*)(int,unsigned long)),"sched_request_migrate_bridge actual ABI");
__typeof__(&sched_request_migrate_bridge) f03_actual_address_sched_request_migrate_bridge = &sched_request_migrate_bridge;
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_setparam_log_bridge),void (*)(int,unsigned long)),"sched_setparam_log_bridge actual ABI");
__typeof__(&sched_setparam_log_bridge) f03_actual_address_sched_setparam_log_bridge = &sched_setparam_log_bridge;
const unsigned long f03_sched_C_ABI[9] = {sizeof(struct sched_param),__alignof__(struct sched_param),__builtin_offsetof(struct sched_param,sched_priority),sizeof(struct thread),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),sizeof(struct process),sizeof(unsigned long),sizeof(int)};

struct ddebug __attribute__((aligned(8),section("__verbose"))) f03_sched_setparam_debug_v1 = {
 .file=__FILE__,.func="sched_setparam_log_bridge",.line=26052,.flags=DDEBUG_DEFAULT
};
extern struct ddebug __start___verbose[], __stop___verbose[];
void fixture_set_flags(unsigned int flag) {
 for(struct ddebug *r=__start___verbose;r<__stop___verbose;r++) r->flags=flag;
}
