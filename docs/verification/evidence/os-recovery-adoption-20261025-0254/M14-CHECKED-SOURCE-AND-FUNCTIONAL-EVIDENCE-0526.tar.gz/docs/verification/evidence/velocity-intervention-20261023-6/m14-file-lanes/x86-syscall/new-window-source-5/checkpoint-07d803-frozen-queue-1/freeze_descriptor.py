"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Immutable checkpoint-only descriptor successor; no implementation or workload.
"""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;B=D.parent;K=Path('/home/holden/mckernel')
def pin(path):
 p=Path(path);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
P=B/'EXACT-CURRENT-UNION-WHOLE-PARITY.NOT-GRANTED.json';old=json.loads(P.read_text());j=json.loads(P.read_text());rebase=json.loads((B/'CURRENT-UNION-SOURCE-REBASE.json').read_text())
expected_head='07d803c4c7c5b0a6945becb746ca71ab5ca1df3e'
# Verify old source snapshots against exact new runtime, without regenerating any.
for row in rebase['canonical_union_bindings']:assert pin(row['path'])==row
for row in old['sources']+old['headers']:assert pin(row['path'])==row
selection=D/'selection-evidence';selection.mkdir(exist_ok=True)
selected=[]
for path in ['CMakeLists.txt','kernel/CMakeLists.txt']:
 p=K/path;q=selection/path;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();q.write_bytes(p.read_bytes());selected += [pin(p),pin(q)]
assert pin(K/'kernel/CMakeLists.txt')['sha256']=='ed663442300a0482a219381f0936152a5080941b59a3eb86f082b42272764aa8'
out=D/'output-1'
for command in j['commands']:command['argv']=[arg.replace(old['output_root']+'/',str(out)+'/') for arg in command['argv']]
j.update(status='IMMUTABLE_07d803_SOURCE_QUEUE_NO_COMPILER_GRANT',prior_queue=pin(P),reconciled_git_head=expected_head,reconciliation='Git checkpoint changed7b56->07d803 while every sampled runtime/source/header byte is unchanged. Existing candidate/fixture implementation reused without regeneration. This is a source/selector reconciliation, not runtime acceptance.',output_root=str(out),capture_root=str(D/'actual-whole-parity-capture-1'),fixture_source_root=str(B/'fixture-source'),canonical_runtime_guards=rebase['canonical_union_bindings'],canonical_header_guards=[r['origin'] for r in j['current_header_copies'] if r['kind']=='current_canonical'],selection_inputs=selected,preparation_receipts=[pin(B/'CURRENT-UNION-SOURCE-REBASE.json'),pin(B/'CURRENT-FIXTURE-ALLOCATOR-ABI.json'),pin(B/'SOURCE-HANDOFF.json')],preflight=pin(D/'preflight_sources_only.py'),selected_pairs=[dict(sources=['${CMAKE_CURRENT_SOURCE_DIR}/process.c','${CMAKE_CURRENT_SOURCE_DIR}/process_helpers.c'],selector='MCKERNEL_RUST_PROCESS_HELPERS'),dict(sources=['${CMAKE_CURRENT_SOURCE_DIR}/syscall.c','${PROJECT_SOURCE_DIR}/arch/${ARCH}/kernel/syscall.c'],selector='MCKERNEL_RUST_SYSCALL_POLICY_HELPERS')],named_runtime_tuple=dict(policy=pin(K/'kernel/rust/syscall_policy.rs'),process=pin(K/'kernel/rust/process_helpers.rs'),mem=pin(K/'kernel/rust/mem_helpers.rs'),kernel_CMake=pin(K/'kernel/CMakeLists.txt')),root_grant=None)
j['proposed_profile']['CPU_assignment']=0
Q=D/'EXACT-3472-45ABI-07d803.NOT-GRANTED.json';Q.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(dict(descriptor=pin(Q),preflight=pin(D/'preflight_sources_only.py')),sort_keys=True))
