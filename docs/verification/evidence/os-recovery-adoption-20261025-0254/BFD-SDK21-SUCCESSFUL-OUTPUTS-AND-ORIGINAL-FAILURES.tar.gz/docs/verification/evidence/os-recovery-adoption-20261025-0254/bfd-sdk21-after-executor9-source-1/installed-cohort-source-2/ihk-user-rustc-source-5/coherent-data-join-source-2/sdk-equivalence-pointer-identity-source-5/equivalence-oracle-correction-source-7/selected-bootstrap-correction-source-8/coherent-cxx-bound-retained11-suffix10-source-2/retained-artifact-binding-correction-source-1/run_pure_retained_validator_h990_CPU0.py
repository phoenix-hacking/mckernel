"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One granted CPU0 pure retained-validator regression through existing h990 owned_capture.
"""
import ast,hashlib,json,os,resource,signal,time
from pathlib import Path
D=Path(__file__).parent
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
raw=H.read_bytes();assert hashlib.sha256(raw).hexdigest()=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'};assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
h={'__file__':str(H)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(H),'exec'),h)
assert os.getuid()==os.geteuid()==1000 and 0 in os.sched_getaffinity(0)
C=D/'actual-retained-validator-pure-regression-1';assert not C.exists();C.mkdir(mode=0o700)
os.sched_setaffinity(0,{0});os.environ['LANG']=os.environ['LC_ALL']='C';os.environ['OMP_NUM_THREADS']=os.environ['RAYON_NUM_THREADS']='1'
for k,v in ((resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_STACK,2<<20),(resource.RLIMIT_CORE,0)):resource.setrlimit(k,(v,v))
for sig in h['STOP_SIGNALS']:signal.signal(sig,h['stop'])
begin=time.monotonic();h['write'](C/'profile.json',dict(CPU=0,jobs=1,AS=2<<30,CPU_seconds=60,wall=90,retirement=6,FSIZE=32<<20,FD=256,stack=2<<20,core=0,purpose=__doc__))
step=C/'step0';step.mkdir();command=dict(argv=['/usr/bin/python3','-I','-B',str(D/'test_retained_bfd_validator.py')],purpose=__doc__)
h['write'](step/'command.json',command)
def limits():resource.setrlimit(resource.RLIMIT_CPU,(59,59))
signal.setitimer(signal.ITIMER_REAL,96)
try:
 joined=h['owned_capture'](command,step,90,limits);h['write'](step/'whole-join.json',joined)
 assert joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent'] and joined['closed_streams'] and not joined['error'] and not joined['retirement_error'] and not joined['timed_out']
 controls=json.loads(Path(joined['captures']['stdout']['path']).read_bytes());assert controls['status']=='PASS_COMPLETE_RETAINED_VALIDATOR_REGRESSION'
 result=dict(scope=__doc__.splitlines()[0],status='PASS_OWNED_PURE_RETAINED_VALIDATOR_REGRESSION',join=joined,checks=controls,seconds=time.monotonic()-begin,CPU_seconds=h['cpu_used'](),CPU0_released=True,SDK_acceptance=False,native_acceptance=False)
 h['write'](C/'RESULT.json',result);print(json.dumps(dict(status=result['status'],seconds=result['seconds'],CPU_seconds=result['CPU_seconds'],result=str(C/'RESULT.json'))))
finally:signal.setitimer(signal.ITIMER_REAL,0)
