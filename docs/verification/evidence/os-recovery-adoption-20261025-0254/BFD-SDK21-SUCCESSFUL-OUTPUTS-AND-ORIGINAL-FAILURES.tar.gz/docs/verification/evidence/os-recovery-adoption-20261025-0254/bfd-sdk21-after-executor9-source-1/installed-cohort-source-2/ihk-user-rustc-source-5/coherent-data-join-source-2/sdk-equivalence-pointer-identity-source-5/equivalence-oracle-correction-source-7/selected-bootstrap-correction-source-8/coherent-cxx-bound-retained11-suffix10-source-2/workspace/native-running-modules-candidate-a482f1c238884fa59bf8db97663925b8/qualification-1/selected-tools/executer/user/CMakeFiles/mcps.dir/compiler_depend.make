# Empty compiler generated dependencies file for mcps.
# This may be replaced when dependencies are built.
