"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure retained HOST validator regression; no binary/helper/compiler/container execution.
"""
import importlib.util,json,copy,hashlib,struct,re
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).parent
validator=D/'validate_retained_bfd_artifacts.py'
assert hashlib.sha256(validator.read_bytes()).hexdigest()=='aa476ec4849ce63e17fbe2eeea6cf2ec595094f2e7e5e365f4aeac3f8353bab8'
spec=importlib.util.spec_from_file_location('retained_pure_verifier',validator);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
def reject(name,call):
 try:call()
 except (m.OwnerError,m.Refusal,AssertionError,OSError):rows.append(dict(case=name,actual='REJECT'))
 else:raise AssertionError('negative accepted '+name)
actual=m.check_retained();rows.append(dict(case='complete-retained-checker',actual='PASS'))
q=Path(m.REQUEST['candidate_root'])/'qualification-1'
# Read ELF64 x86_64 header bytes only, never execute any artifact.
for relative in ['bfd_accessors.o','selected-tools/executer/user/mcinspect','selected-tools/executer/user/eclair']:
 raw=(q/relative).read_bytes();assert raw[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',raw,18)[0]==62
 assert struct.unpack_from('<H',raw,16)[0]==(1 if relative.endswith('.o') else 3)
for tool in ['mcinspect','eclair']:
 symbols=(q/(tool+'-symbols.stdout')).read_text()
 for fn in ['get_symtab_upper_bound','canonicalize_symtab']:
  assert re.search(r'\bT\s+'+tool+'_bfd_'+fn+'_bridge\b',symbols)
 assert not re.search(r'\bU\s+(?:mcinspect|eclair)_bfd_',symbols)
 assert 'Flags: PIE' in (q/(tool+'-dynamic.stdout')).read_text()
rows.append(dict(case='current-ELF64-x86_64-PIE-and-bridge-symbols',actual='PASS'))
original=m._artifact_path
m._artifact_path=lambda output,relative:output/relative
reject('original-missing-equivalence-failure-reproduced',m.check_retained);m._artifact_path=original
saved=copy.deepcopy(m.ARTIFACT_MAP)
def mapmutation(label,edit):
 m.ARTIFACT_MAP=copy.deepcopy(saved);edit(m.ARTIFACT_MAP)
 reject(label,m.check_retained);m.ARTIFACT_MAP=copy.deepcopy(saved)
mapmutation('retained-origin-path-change',lambda v:v['equivalence']['actual'].update(path=str(q/'equivalence')))
mapmutation('retained-origin-sha-change',lambda v:v['equivalence']['actual'].update(sha256='0'*64))
mapmutation('retained-origin-size-change',lambda v:v['equivalence']['actual'].update(bytes=1))
mapmutation('retained-provenance-relabel',lambda v:v['equivalence'].update(provenance='CURRENT_OUTPUT'))
mapmutation('current-artifact-path-change',lambda v:v['bfd_accessors.o']['actual'].update(path=v['equivalence']['actual']['path']))
realbytes=Path.read_bytes
resultpath=q/'RESULT.json'
def resultmutation(label,edit):
 def altered(path):
  raw=realbytes(path)
  if path==resultpath:
   obj=json.loads(raw);edit(obj);return json.dumps(obj).encode()
  return raw
 with patch.object(Path,'read_bytes',altered):reject(label,m.check_retained)
resultmutation('ABI-pins-mismatch',lambda v:v['pins']['header'].update(sha256='0'*64))
resultmutation('comparison-match-false',lambda v:v['comparisons'][0].update(matched=False))
resultmutation('comparison-missing',lambda v:v['comparisons'].pop())
resultmutation('provenance-count-wrong',lambda v:v.update(actual_suffix_count=9))
realtext=Path.read_text
def textmutation(label,target,edit):
 def altered(path,*args,**kwargs):
  raw=realtext(path,*args,**kwargs)
  return edit(raw) if path==q/target else raw
 with patch.object(Path,'read_text',altered):reject(label,m.check_retained)
textmutation('four-Rust-definitions-missing','rust-symbols.stdout',lambda raw:'')
textmutation('command21-rc-failure','commands.json',lambda raw:json.dumps([dict(row,rc=1) if i==0 else row for i,row in enumerate(json.loads(raw))]))
def badstream(path):
 raw=realbytes(path)
 return raw+b'changed' if path==q/'mcinspect-0-rust.stdout' else raw
with patch.object(Path,'read_bytes',badstream):reject('behavior-stream-mismatch',m.check_retained)
print(json.dumps(dict(scope=__doc__.splitlines()[0],status='PASS_COMPLETE_RETAINED_VALIDATOR_REGRESSION',validator_sha256=hashlib.sha256(validator.read_bytes()).hexdigest(),positive=2,negative=len(rows)-2,rows=rows,checked=actual,binary_executions=0,compiler_calls=0,query_calls=0,cleanup_calls=0),indent=2))
