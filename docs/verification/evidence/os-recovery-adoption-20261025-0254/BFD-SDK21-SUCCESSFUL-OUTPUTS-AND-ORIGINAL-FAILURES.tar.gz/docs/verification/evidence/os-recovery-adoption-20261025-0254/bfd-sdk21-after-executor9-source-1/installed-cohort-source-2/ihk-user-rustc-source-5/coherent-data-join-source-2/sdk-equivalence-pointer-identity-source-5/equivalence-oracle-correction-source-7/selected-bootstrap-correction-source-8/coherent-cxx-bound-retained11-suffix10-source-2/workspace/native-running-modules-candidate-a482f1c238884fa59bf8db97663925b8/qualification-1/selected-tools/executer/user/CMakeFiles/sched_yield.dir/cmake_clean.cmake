file(REMOVE_RECURSE
  ".1.0.0"
  "CMakeFiles/sched_yield.dir/link.d"
  "libsched_yield.pdb"
  "libsched_yield.so"
  "libsched_yield.so.1.0.0"
  "rust/libsched_yield.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sched_yield.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
