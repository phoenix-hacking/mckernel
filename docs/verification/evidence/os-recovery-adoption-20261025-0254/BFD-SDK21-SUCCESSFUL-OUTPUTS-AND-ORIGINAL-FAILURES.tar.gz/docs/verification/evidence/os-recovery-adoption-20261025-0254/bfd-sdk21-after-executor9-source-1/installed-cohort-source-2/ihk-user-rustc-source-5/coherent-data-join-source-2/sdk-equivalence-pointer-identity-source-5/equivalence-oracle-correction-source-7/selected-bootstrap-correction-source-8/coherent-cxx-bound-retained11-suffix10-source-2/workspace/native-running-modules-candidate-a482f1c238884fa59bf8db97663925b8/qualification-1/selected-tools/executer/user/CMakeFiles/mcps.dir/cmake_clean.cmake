file(REMOVE_RECURSE
  "CMakeFiles/mcps.dir/link.d"
  "mcps"
  "mcps.pdb"
  "rust/mcps.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcps.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
