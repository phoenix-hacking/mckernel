file(REMOVE_RECURSE
  "CMakeFiles/eclair.dir/link.d"
  "eclair"
  "eclair.pdb"
  "rust/arch_eclair_x86_64.o"
  "rust/bfd_accessors.o"
  "rust/eclair_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/eclair.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
