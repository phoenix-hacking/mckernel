file(REMOVE_RECURSE
  "CMakeFiles/mcps_rust_main"
  "rust/mcps.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcps_rust_main.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
