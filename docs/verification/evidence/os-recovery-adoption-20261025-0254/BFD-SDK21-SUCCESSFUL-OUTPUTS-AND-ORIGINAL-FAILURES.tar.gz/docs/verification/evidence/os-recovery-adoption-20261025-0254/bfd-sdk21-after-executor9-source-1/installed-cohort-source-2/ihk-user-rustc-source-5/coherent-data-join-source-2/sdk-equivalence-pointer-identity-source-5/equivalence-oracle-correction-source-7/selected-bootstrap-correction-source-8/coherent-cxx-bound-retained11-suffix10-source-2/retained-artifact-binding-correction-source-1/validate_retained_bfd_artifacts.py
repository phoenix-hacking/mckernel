"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Retained-only HOST verifier. No subprocess, SDK/compiler/query/container/cleanup calls.
Original full strict support checker and owner provenance verifier; only exact equivalence artifact origin is mapped.
"""
from pathlib import Path
import json,hashlib,os,stat,re,types,ast
class OwnerError(RuntimeError):pass
class Refusal(RuntimeError):pass
SUPPORT_SOURCE = {'path': '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-8/m15-bfd-owner-successor/compile_image_owner.py', 'bytes': 95385, 'sha256': '71381de806c21b7487e1515927543b376199a021a08b965a60d68063241bc794'}
OWNER_SOURCE = {'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/bfd_cxx_bound_retained11_suffix10_owner.py', 'bytes': 94697, 'sha256': '542a78c4e5fca1ef0bfed6d41ea70d689c1a7284390ee4f858c705efaf4f0491'}
MAP_SOURCE = {'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/retained-artifact-binding-correction-source-1/EXACT-RETAINED-ARTIFACT-MAP.json', 'bytes': 12080, 'sha256': '28bffceb7c0ed12a3e31f6fb708eff3cdc8ca390f5b32cd6e63a7bcbe0c77e80'}
REQUEST_SOURCE = {'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/REQUEST.PENDING-NO-AUTHORITY.json', 'bytes': 5490, 'sha256': '8613ce19963839c180868761b29b692d2e0aa4ade82cc4a78ea841b5ea4bf9c6'}
PREPARATION_SOURCE = {'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/BFD-PREPARATION.json', 'bytes': 16660, 'sha256': 'd68fdaf5153477a9f6cfedc86e17ad10f503a077635cb3ad6d0dc73000a78cfc'}
def _fail(condition, message):
    if not condition:
        raise OwnerError(message)

def _no_symlink_parents(path, label):
    path = Path(path)
    _fail(path.is_absolute(), label + " must be absolute")
    current = Path(path.anchor)
    for component in path.parts[1:]:
        current /= component
        _fail(not current.is_symlink(), label + " has symlink parent")

def _safe_regular(path, label):
    """Validate a regular file without following a leaf or ancestor link."""
    path = Path(path)
    _no_symlink_parents(path, label)
    try:
        info = os.lstat(path)
    except OSError as exc:
        raise OwnerError(label + " missing") from exc
    _fail(stat.S_ISREG(info.st_mode), label + " must be a regular file")
    return path

def _safe_directory(path, label):
    """Validate a directory and every path component without following links."""
    path = Path(path)
    _no_symlink_parents(path, label)
    try:
        info = os.lstat(path)
    except OSError as exc:
        raise OwnerError(label + " missing") from exc
    _fail(stat.S_ISDIR(info.st_mode), label + " must be a directory")
    return path

def _load_json(path, label):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise OwnerError("malformed " + label) from exc
    _fail(isinstance(value, dict), label + " must be an object")
    return value

def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def bound(ref):
 path=_safe_regular(ref['path'],'exact source/artifact binding')
 _fail(path.stat().st_size==ref['bytes'] and _sha256(path)==ref['sha256'],'source/artifact bytes changed')
 return path
for source in (SUPPORT_SOURCE,OWNER_SOURCE,MAP_SOURCE,REQUEST_SOURCE,PREPARATION_SOURCE):bound(source)
LIBRARY_PREPARATION=json.loads(bound(PREPARATION_SOURCE).read_bytes())
PREPARATION_SHA=PREPARATION_SOURCE['sha256']
COMMANDS_PATH=Path(REQUEST_SOURCE['path']).parent/'EXACT-BFD-COMMANDS.json'
REQUEST=json.loads(bound(REQUEST_SOURCE).read_bytes())
ARTIFACT_MAP=json.loads(bound(MAP_SOURCE).read_bytes())
SEMANTIC=json.loads(bound(LIBRARY_PREPARATION['retained_semantic_manifest']).read_bytes())
_fail(ARTIFACT_MAP['equivalence']['actual']==SEMANTIC['equivalence_binary'],'exact authenticated semantic origin required')
def _artifact_path(output,relative):
 _fail(relative in ARTIFACT_MAP,'unbound artifact role')
 row=ARTIFACT_MAP[relative]
 _fail(row['logical_path']==str(output/relative),'artifact logical path changed')
 if relative=='equivalence':
  _fail(row['provenance']=='AUTHENTICATED_RETAINED_SEMANTIC_PREFIX' and row['actual']==SEMANTIC['equivalence_binary'],'retained origin binding differs')
 else:
  _fail(row['provenance']=='CURRENT_OUTPUT' and row['actual']['path']==str(output/relative),'current artifact must remain at exact path')
 return bound(row['actual'])
SCOPE=LIBRARY_PREPARATION['scope']
COMPILE_PROFILE=dict(candidate_root=LIBRARY_PREPARATION['candidate_root'])
def _validate_driver_result(evidence, output, result, request):
    output = _safe_directory(output, "BFD qualification output")
    _fail(evidence == output, "BFD evidence/output contract differs")
    _fail(result.get("status") == "PASS_PINNED_ABI_AND_SELECTED_USER_TOOL_ARTIFACTS" and
          result.get("scope") == SCOPE and result.get("native_acceptance") is False and
          result.get("M15_file_closure") is False, "BFD qualifier result contract differs")
    pins = _load_json(Path(COMPILE_PROFILE["candidate_root"]) / "PINNED-ABI.json", "BFD pins")
    _fail(result.get("pins") == pins and isinstance(result.get("layout"), str) and result["layout"], "BFD pin/layout result differs")
    _fail(not (output / "FAILURE.json").exists(), "BFD failure evidence present")
    comparisons = result.get("comparisons")
    _fail(isinstance(comparisons, list) and len(comparisons) == 8, "BFD comparison set incomplete")
    cases = {"mcinspect": [["--help"], [], ["--kernel=/work/qualification-1/absent.img", "--ps"],
                           ["--kernel=/work/qualification-1/stripped.o", "--ps"]],
             "eclair": [["-h"], ["-k", "/work/qualification-1/absent.img", "-d", "/work/qualification-1/absent.dump"],
                        ["-k", "/work/qualification-1/stripped.o", "-d", "/work/qualification-1/absent.dump"],
                        ["-k", "/work/qualification-1/fixture.o", "-d", "/work/qualification-1/absent.dump"]]}
    expected = [(tool, args) for tool in ("mcinspect", "eclair") for args in cases[tool]]
    _fail([(row.get("tool"), row.get("args")) for row in comparisons] == expected and
          all(row.get("matched") is True and type(row.get("rc")) is int for row in comparisons), "BFD behavior comparisons differ")
    for tool in ("mcinspect", "eclair"):
        for i in range(4):
            for stream in ("stdout", "stderr"):
                original = _safe_regular(output / f"{tool}-{i}-original.{stream}", "BFD baseline stream")
                rust = _safe_regular(output / f"{tool}-{i}-rust.{stream}", "BFD Rust stream")
                _fail(original.read_bytes() == rust.read_bytes(), "BFD retained behavior streams differ")
    commands = json.loads(_safe_regular(output / "commands.json", "BFD command capture").read_text())
    names = ["witness-build", "witness-run", "witness-preprocessed", "rust-build", "mcinspect-original-compile",
             "eclair-original-compile", "equivalence-link", "fixture-compile", "fixture-strip", "equivalence-run",
             "rust-symbols", "selected-configure", "selected-build", "mcinspect-baseline-compile", "mcinspect-baseline-link",
             "mcinspect-dynamic", "mcinspect-symbols", "eclair-baseline-compile", "eclair-baseline-link", "eclair-dynamic", "eclair-symbols"]
    _fail(isinstance(commands, list) and [row.get("log") for row in commands] == names and
          all(type(row.get("rc")) is int and row["rc"] == 0 for row in commands), "BFD command capture incomplete/failing")
    for name in names:
        for stream in ("stdout", "stderr"):
            _safe_regular(output / (name + "." + stream), "BFD command stream")
    symbols = (output / "rust-symbols.stdout").read_text()
    names = re.findall(r"\bT\s+((?:mcinspect|eclair)_bfd_(?:get_symtab_upper_bound|canonicalize_symtab)_bridge)\b", symbols)
    expected_symbols = {tool + "_bfd_" + function + "_bridge" for tool in ("mcinspect", "eclair")
                        for function in ("get_symtab_upper_bound", "canonicalize_symtab")}
    _fail(len(names) == 4 and set(names) == expected_symbols and not re.search(r"\bU\s+(?:mcinspect|eclair)_bfd_", symbols),
          "BFD four-definition/no-old-wrapper result differs")
    for relative in ("bfd_accessors.o", "bfd_layout.rs", "equivalence", "layout-witness", "fixture.o", "stripped.o",
                     "selected-tools/executer/user/mcinspect", "selected-tools/executer/user/eclair",
                     "selected-tools/executer/user/CMakeFiles/mcinspect.dir/link.txt",
                     "selected-tools/executer/user/CMakeFiles/eclair.dir/link.txt"):
        _fail(_safe_regular(_artifact_path(output, relative), "BFD qualification artifact").stat().st_size > 0, "BFD artifact empty")

def safe_path(value, directory=True):
    path = Path(value)
    need(path.is_absolute() and str(path) == value and '..' not in path.parts,
         'canonical absolute path required')
    need(all(not p.is_symlink() for p in (path, *path.parents)), 'symlink path refused')
    if directory:
        need(path.is_dir(), 'existing directory required')
    else:
        need(path.is_file() and stat.S_ISREG(path.stat().st_mode), 'regular file required')
    return path

def need(ok, message):
    if not ok:
        raise Refusal(message)

def validate_library_receipt(receipt, request):
    need(receipt.get('schema')=='mckernel.bfd-retained-prefix-sdk-suffix-receipt.v1' and receipt.get('status')=='PASS_BFD_PREFIX_REUSED_SUFFIX_CAPTURE' and receipt.get('scope')==LIBRARY_PREPARATION['scope'], 'exact BFD capture receipt')
    need(receipt.get('preparation_sha256')==PREPARATION_SHA and receipt.get('command')==json.loads(COMMANDS_PATH.read_bytes())['command'], 'exact BFD command/preparation receipt')
    need(receipt.get('native_acceptance') is False and receipt.get('M15_file_closure') is False, 'BFD qualification scope only')
    capture=receipt['capture']
    need(capture['returncode']==0 and capture['direct_child_joined'] and capture['group_absent'] and capture['closed_streams'] and capture['error'] is None and capture['retirement_error'] is None and not capture['timed_out'] and capture['captures']['stderr']['size']==0, 'BFD qualifier positive owned join')
    output=safe_path(str(Path(request['candidate_root'])/'qualification-1'))
    result_file=safe_path(str(output/'RESULT.json'),False)
    need(host.digest(result_file)==receipt.get('qualifier_result_sha256'), 'durable BFD result hash')
    result=json.loads(result_file.read_bytes())
    # Invoke the unchanged exact 21-command/eight-pair BFD result checker.
    support=bfd_support()
    support.COMPILE_PROFILE=dict(support.COMPILE_PROFILE,candidate_root=LIBRARY_PREPARATION['candidate_root'])
    support._validate_driver_result(output,output,result,{})
    # Keep the original 21-command/eight-pair checker and independently require truthful execution provenance.
    prefix_ref=LIBRARY_PREPARATION['retained_prefix_manifest']
    manifest_path=safe_path(prefix_ref['path'],False)
    need(manifest_path.stat().st_size==prefix_ref['bytes'] and host.digest(manifest_path)==prefix_ref['sha256'],'exact retained SDK prefix manifest')
    reused=json.loads(manifest_path.read_bytes())
    need(json.loads((output/'PREFIX-REUSE.json').read_bytes())==reused and result.get('retained_prefix_manifest_sha256')==prefix_ref['sha256'],'durable authenticated prefix reuse')
    semantic_ref=LIBRARY_PREPARATION['retained_semantic_manifest']
    semantic_file=safe_path(semantic_ref['path'],False)
    need(semantic_file.stat().st_size==semantic_ref['bytes'] and host.digest(semantic_file)==semantic_ref['sha256'],'exact semantic prefix manifest')
    semantic=json.loads(semantic_file.read_bytes())
    need(json.loads((output/'SEMANTIC-PREFIX-REUSE.json').read_bytes())==semantic,'durable semantic prefix reuse')
    need(result.get('retained_prefix_count')==11 and result.get('retained_original_prefix_count')==8 and result.get('retained_semantic_prefix_count')==3 and result.get('actual_suffix_count')==10 and result.get('logical_contract_count')==21,'eight original plus three semantic retained/ten new')
    retained=json.loads((output/'retained-commands.json').read_bytes())
    expected_retained=[dict(row,execution_provenance='RETAINED_PREVIOUS_SDK_SUCCESS') for row in reused['retained_commands']]+[dict(row,execution_provenance='RETAINED_SEMANTIC_SDK_SUCCESS') for row in semantic['retained_commands']]
    original_order=['witness-build', 'witness-run', 'witness-preprocessed', 'rust-build', 'mcinspect-original-compile', 'eclair-original-compile', 'equivalence-link', 'fixture-compile', 'fixture-strip', 'equivalence-run', 'rust-symbols', 'selected-configure', 'selected-build', 'mcinspect-baseline-compile', 'mcinspect-baseline-link', 'mcinspect-dynamic', 'mcinspect-symbols', 'eclair-baseline-compile', 'eclair-baseline-link', 'eclair-dynamic', 'eclair-symbols']
    expected_retained.sort(key=lambda row:original_order.index(row['log']))
    need(retained==expected_retained and len(retained)==11,'exact eight original and three semantic successes')
    actual=json.loads((output/'actual-commands.json').read_bytes())
    expected_names=['selected-configure', 'selected-build', 'mcinspect-baseline-compile', 'mcinspect-baseline-link', 'mcinspect-dynamic', 'mcinspect-symbols', 'eclair-baseline-compile', 'eclair-baseline-link', 'eclair-dynamic', 'eclair-symbols']
    need(len(actual)==10 and [row.get('log') for row in actual]==expected_names and all(row.get('execution_provenance')=='CURRENT_SDK_SUFFIX' and row.get('rc')==0 for row in actual),'exact ten actual current SDK suffix successes')
    need(actual[0]['argv']==semantic['preserved_failure']['argv'],'unchanged selected configure argv with corrected bootstrap only')
    logical=json.loads((output/'commands.json').read_bytes())
    need(len(logical)==21 and [row['log'] for row in logical]==original_order,'fixed original logical package')
    byname={row['log']:row for row in retained+actual}
    need(len(byname)==21 and all(row==byname.get(row['log']) for row in logical),'every logical row has exact retained or actual provenance')
    for name,row in semantic['streams'].items():
        stream=safe_path(str(output/name),False)
        need(stream.stat().st_size==row['bytes'] and host.digest(stream)==row['sha256'],'copied retained semantic stream identity')
    for name,row in reused['retained_files'].items():
        actual_file=safe_path(str(output/name),False)
        need(actual_file.stat().st_size==row['bytes'] and host.digest(actual_file)==row['sha256'],'copied retained byte identity')
    for stream in ('stdout','stderr'):
        logical=Path(capture['captures'][stream]['path'])
        need(logical==Path('/work/evidence')/stream, 'exact BFD capture stream path')
        actual=safe_path(str(Path(request['candidate_root'])/logical.relative_to('/work')),False)
        need(actual.stat().st_size==capture['captures'][stream]['size'] and host.digest(actual)==capture['captures'][stream]['sha256'], 'durable BFD capture stream')

host=types.SimpleNamespace(digest=_sha256)
support=types.SimpleNamespace(COMPILE_PROFILE=COMPILE_PROFILE,_validate_driver_result=_validate_driver_result)
def bfd_support():return support

def check_retained():
 receipt=json.loads((Path(REQUEST['candidate_root'])/'evidence/receipt.json').read_bytes())
 validate_library_receipt(receipt,REQUEST)
 return dict(scope=SCOPE,status='PASS_RETAINED_HOST_ARTIFACT_AND_PROVENANCE_CHECKS',logical_commands=21,retained_successes=11,new_successes=10,behavior_pairs=8,stream_pairs=16,mapped_retained_artifacts=1,native_acceptance=False,SDK_acceptance=False,M15_file_closure=False)
if __name__=='__main__':
 import sys
 assert sys.argv[1:]==['--check-retained-only']
 print(json.dumps(check_retained(),sort_keys=True))
