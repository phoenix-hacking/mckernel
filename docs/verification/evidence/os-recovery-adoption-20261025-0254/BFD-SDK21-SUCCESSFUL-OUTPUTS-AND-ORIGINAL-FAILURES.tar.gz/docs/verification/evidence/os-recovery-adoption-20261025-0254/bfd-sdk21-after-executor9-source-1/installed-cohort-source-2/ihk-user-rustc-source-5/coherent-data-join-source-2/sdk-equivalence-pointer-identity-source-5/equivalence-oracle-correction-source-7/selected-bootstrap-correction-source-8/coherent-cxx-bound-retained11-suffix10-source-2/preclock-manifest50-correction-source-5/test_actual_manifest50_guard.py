"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure local regression executes only the actual corrected manifest AST assertion.
"""
import ast,copy,hashlib,json,sys
from pathlib import Path
FILL={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/preclock-manifest50-correction-source-5/fill_CXX_BFD_review_payload.COUNT50-CORRECTED.py', 'bytes': 284372, 'sha256': '9409e82b8d121c17bbfbf80e59f4e2e4642c693a0897b108b228213c83c37d50'}
SPEC={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/bfd-sdk21-after-executor9-source-1/installed-cohort-source-2/ihk-user-rustc-source-5/coherent-data-join-source-2/sdk-equivalence-pointer-identity-source-5/equivalence-oracle-correction-source-7/selected-bootstrap-correction-source-8/coherent-cxx-bound-retained11-suffix10-source-2/EXACT-CXX-BOUND-SOURCE50-SPEC.json', 'bytes': 30964, 'sha256': 'b4054e053694cab3d5e14cc39a2d6fd19fd6e0a345c5f63891d9a128392228c2'}
PROOF={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/ACTUAL-FETCHED-CXX-SOURCE50-537944C1.json', 'bytes': 134792, 'sha256': '3ee7076a81155a2ae18db4e6db6934b222efabb11ed738749e5f77bd58cb8676'}
source=Path(FILL['path']).read_bytes();assert hashlib.sha256(source).hexdigest()==FILL['sha256']
tree=ast.parse(source);nodes=[n for n in tree.body if isinstance(n,ast.Assert) and "manifest['member_count']" in ast.unparse(n)]
assert len(nodes)==1
code=compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'actual-corrected-manifest-guard','exec')
manifest=json.loads(Path(SPEC['path']).read_bytes());fetched=json.loads(Path(PROOF['path']).read_bytes())
for ref in [SPEC,PROOF]:assert hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest()==ref['sha256']
def check(m,f):exec(code,{'manifest':m,'fetched':f})
check(manifest,fetched);rows=[dict(case='genuine50-fullmap',expected='PASS',actual='PASS')]
mutations=[]
def add(label,edit):
 m=copy.deepcopy(manifest);f=copy.deepcopy(fetched);edit(m,f);mutations.append((label,m,f))
key=next(iter(manifest['files']))
add('manifest-count32',lambda m,f:m.update(member_count=32))
add('manifest-count49',lambda m,f:m.update(member_count=49))
add('proof-count32',lambda m,f:f.update(source_member_count=32))
add('proof-count49',lambda m,f:f.update(source_member_count=49))
add('manifest-omission',lambda m,f:m['files'].pop(key))
add('proof-omission',lambda m,f:f['source_members'].pop(key))
add('manifest-extra',lambda m,f:m['files'].update(extra=m['files'][key]))
add('proof-extra',lambda m,f:f['source_members'].update(extra=f['source_members'][key]))
add('manifest-tuple-change',lambda m,f:m['files'][key].update(sha256='0'*64))
add('proof-tuple-change',lambda m,f:f['source_members'][key].update(sha256='0'*64))
add('both-omit-count50',lambda m,f:(m['files'].pop(key),f['source_members'].pop(key)))
add('both-extra-count50',lambda m,f:(m['files'].update(extra=m['files'][key]),f['source_members'].update(extra=f['source_members'][key])))
for label,m,f in mutations:
 try:check(m,f)
 except AssertionError:rows.append(dict(case=label,expected='REJECT',actual='REJECT'))
 else:raise AssertionError('negative unexpectedly accepted '+label)
print(json.dumps(dict(scope=__doc__.splitlines()[0],status='PASS_ACTUAL_MANIFEST50_GUARD_REGRESSION',positive=1,negative=len(mutations),source=FILL,assertion_AST=ast.dump(nodes[0],include_attributes=False),rows=rows,privileged_calls=0,query_calls=0),indent=2))
