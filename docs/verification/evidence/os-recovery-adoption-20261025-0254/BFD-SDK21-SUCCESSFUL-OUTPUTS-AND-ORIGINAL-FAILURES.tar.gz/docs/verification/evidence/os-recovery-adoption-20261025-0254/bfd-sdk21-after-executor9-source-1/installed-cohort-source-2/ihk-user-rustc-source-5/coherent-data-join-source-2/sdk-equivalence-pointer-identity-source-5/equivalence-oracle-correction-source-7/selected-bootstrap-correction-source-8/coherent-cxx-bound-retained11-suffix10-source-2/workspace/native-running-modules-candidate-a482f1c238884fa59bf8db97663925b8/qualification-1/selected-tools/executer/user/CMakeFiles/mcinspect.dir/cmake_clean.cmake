file(REMOVE_RECURSE
  "CMakeFiles/mcinspect.dir/link.d"
  "mcinspect"
  "mcinspect.pdb"
  "rust/bfd_accessors.o"
  "rust/mcinspect_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcinspect.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
