"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Explicit PURE STATIC MOCK mode: execute complete actual static cohort AST before modebranch.
No UID spoof, no TTL evaluation/bypass, no export/release/write/helper/owner calls.
"""
import ast,copy,hashlib,json
from pathlib import Path
D=Path(__file__).parent
fill=D/'fill_CXX_BFD_review_payload.COUNT50-CORRECTED.py'
source=fill.read_bytes();assert hashlib.sha256(source).hexdigest()=='9409e82b8d121c17bbfbf80e59f4e2e4642c693a0897b108b228213c83c37d50'
tree=ast.parse(source)
start=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='base')
end=next(i for i,n in enumerate(tree.body[start:],start) if isinstance(n,ast.If) and n.lineno>tree.body[start].lineno)
prefix=[n for n in tree.body[:start] if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign)) or isinstance(n,ast.FunctionDef) and n.name in {'canonical','load_raw','read','pinned'}]
static=tree.body[start:end]
assert len(static)>25 and not any(isinstance(n,ast.If) for n in static)
precode=compile(ast.fix_missing_locations(ast.Module(body=prefix,type_ignores=[])),'actual-static-read-definitions','exec')
code=compile(ast.fix_missing_locations(ast.Module(body=static,type_ignores=[])),'complete-actual-static-cohort-block','exec')
rows=[]
def run(label,mutation=None):
 env={'__file__':str(fill)};exec(precode,env);realread=env['read'];co=env['COHORT_AUTHORITY']
 def mockread(path,expected=None):
  value,ref,meta=realread(path,expected)
  if mutation is not None:mutation(str(path),value,co)
  return value,ref,meta
 env['read']=mockread
 try:exec(code,env)
 except AssertionError:
  assert mutation is not None,label
  rows.append(dict(case=label,actual='REJECT'));return
 assert mutation is None,'negative accepted '+label
 # Genuine full source50 bytes bound by actual specification, additional read-only check.
 files=env['manifest']['files'];assert len(files)==50
 for ref in files.values():
  raw,actual,_=env['load_raw'](ref['path'],ref['sha256']);assert len(raw)==ref['bytes']
 assert len(env['source_map'])==11
 rows.append(dict(case=label,actual='PASS',source50_bytes_verified=50,runtime_map_entries=11))
run('complete-genuine-static-cohort-and-all50bytes')
def edit_manifest(edit):
 return lambda path,value,co: edit(value) if path.endswith('/EXACT-CXX-BOUND-SOURCE50-SPEC.json') else None
run('complete-manifest-count32',edit_manifest(lambda v:v.update(member_count=32)))
run('complete-manifest-omission',edit_manifest(lambda v:v['files'].pop(next(iter(v['files'])))))
run('complete-manifest-extra',edit_manifest(lambda v:v['files'].update(extra=next(iter(v['files'].values())))))
run('complete-manifest-tuple-change',edit_manifest(lambda v:next(iter(v['files'].values())).update(sha256='0'*64)))
run('complete-runtime-map-change',lambda path,v,co:v.update({next(iter(v)):'0'*64}) if path.endswith('/EXACT-ELEVEN-CXX-BOUND-RUNTIME-SOURCE-MAP.json') else None)
run('complete-source-proof-count32',lambda path,v,co:v.update(source_member_count=32) if path==co['fetched_source_proof']['path'] else None)
run('complete-overlay-query-mismatch',lambda path,v,co:v['query_source'].update(sha256='0'*64) if path==co['overlay_fetched_proof']['path'] else None)
run('complete-physical-not-free',lambda path,v,co:v.update(container_absent=False) if path==co['current_whole']['path'] else None)
run('complete-current-join-unjoined',lambda path,v,co:v.update(direct_child_joined=False) if path==co['current_join']['path'] else None)
print(json.dumps(dict(scope=__doc__.splitlines()[0],mode='PURE_STATIC_MOCK_NO_MODEBRANCH_EXECUTION',status='PASS_COMPLETE_ACTUAL_STATIC_COHORT_BLOCK',actual_AST_nodes=len(static),positive=1,negative=len(rows)-1,rows=rows,write_calls=0,query_calls=0,TTL_calls=0,owner_calls=0,production_source_changed=False),indent=2))
