/* Functional OS fixture: real selected layout must reject inherited prefix. */
#include <bfd.h>
#include <stddef.h>
_Static_assert(offsetof(asection,vma)==40,"obsolete vma offset");
_Static_assert(sizeof(asection)==64,"obsolete section prefix size");
