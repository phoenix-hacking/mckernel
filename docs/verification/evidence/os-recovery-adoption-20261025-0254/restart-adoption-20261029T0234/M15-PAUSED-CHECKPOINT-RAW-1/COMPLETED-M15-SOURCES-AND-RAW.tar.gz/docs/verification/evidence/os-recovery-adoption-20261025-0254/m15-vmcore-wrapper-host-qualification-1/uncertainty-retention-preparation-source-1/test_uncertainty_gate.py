"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure regression evidence for an unresolved custody gate. No real effect calls.
"""
from pathlib import Path
import importlib.util,json,subprocess,tempfile,unittest
from unittest.mock import patch
D=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('TEST_ONLY_unapproved_owner',D/'snapshot/fixture/owned_process.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Stream:
 def __init__(self):self.closed=False
 def close(self):self.closed=True
class Fake:
 pid=111
 def __init__(self,kind):self.kind=kind;self.returncode=None;self.stdin=None;self.stdout=Stream();self.stderr=Stream();self.events=[];self.count=0
 def communicate(self,timeout):
  self.count+=1;self.events.append('communicate')
  if self.count==1:
   if self.kind=='interrupt-reaped':self.returncode=-15;raise KeyboardInterrupt()
   if self.kind=='runtime':raise RuntimeError('TEST_ONLY stream failure')
   raise subprocess.TimeoutExpired(['TEST_ONLY'],timeout,output=b'partial')
  if self.kind=='runtime':raise RuntimeError('TEST_ONLY incomplete final capture')
  return b'complete',b''
 def wait(self,timeout):
  self.events.append('wait')
  if self.kind=='unknown':raise subprocess.TimeoutExpired(['TEST_ONLY'],timeout)
  if self.returncode is None:self.returncode=-9
  return self.returncode
class Tests(unittest.TestCase):
 def invoke(self,kind):
  tmp=tempfile.TemporaryDirectory(dir=D);self.addCleanup(tmp.cleanup);o=m.Owner.__new__(m.Owner);o.output=Path(tmp.name);o.records=[];f=Fake(kind);realread=Path.read_text
  def read(p,*a,**k):return ('111' if kind=='unknown' else '') if str(p).startswith('/proc/self/task/') else realread(p,*a,**k)
  with patch.object(m.subprocess,'Popen',return_value=f),patch.object(m.os,'killpg',side_effect=lambda *a:f.events.append('killgroup')) as kg,patch.object(m.os,'kill') as kill,patch.object(m.os,'waitpid'),patch.object(m.time,'monotonic',return_value=0),patch.object(Path,'read_text',read):
   with self.assertRaises(RuntimeError):o.run(['TEST_ONLY'],{},D,1,'test')
   self.assertFalse(kill.called)
  return json.loads((o.output/'ownership.json').read_text())[0],f,kg
 def test_reproduced_unknown_owner_can_exit_is_blocking(self):
  r,f,kg=self.invoke('unknown');self.assertFalse(r['leader_parent_joined']);self.assertFalse(r['whole_descendants_joined']);self.assertEqual(r['status'],'UNKNOWN');self.assertEqual(r['remaining_direct_children'],[111]);self.assertTrue(r['streams_closed'])
  # run() has raised and returned control with an unreaped child: this is the
  # reproduced defect, never a retained-owner or approved execution result.
  self.assertNotIn('owner_retained',r)
 def test_keyboardinterrupt_internal_reap_never_signals_reused_group(self):
  r,f,kg=self.invoke('interrupt-reaped');self.assertFalse(kg.called);self.assertTrue(r['leader_parent_joined']);self.assertTrue(r['whole_descendants_joined']);self.assertIn('KeyboardInterrupt',r['error'])
 def test_runtimeerror_signals_before_leader_wait_and_capture_not_complete(self):
  r,f,kg=self.invoke('runtime');self.assertLess(f.events.index('killgroup'),f.events.index('wait'));self.assertTrue(r['streams_closed']);self.assertIn('incomplete final capture',r['error']);self.assertNotIn('capture_complete',r)
if __name__=='__main__':unittest.main()
