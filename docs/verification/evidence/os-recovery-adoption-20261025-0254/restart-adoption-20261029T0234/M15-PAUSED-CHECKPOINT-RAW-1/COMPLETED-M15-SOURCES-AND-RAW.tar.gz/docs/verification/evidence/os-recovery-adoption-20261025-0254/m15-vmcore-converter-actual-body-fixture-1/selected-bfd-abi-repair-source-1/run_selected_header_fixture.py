"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bounded ordinary HOST compilation/full-command callback fixture; no actual dumps.
"""
import hashlib,json,os,re,resource,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/holden/mckernel')
SRC=ROOT/'docs/verification/evidence/velocity-intervention-20261023-11/m15-vmcore2mckdump'
RUSTC=Path('/home/holden/mckernel-work/toolchains/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc')
SCOPE=__doc__.splitlines()[0]
PIN={'candidate':(SRC/'ldump2mcdump_helpers.ack-candidate.rs','5205663e825abfb26d8eb0e01c225c1eb7cecd95051832b7234890dba5f3de78'),'reference':(SRC/'reference/ldump2mcdump_helpers.rs','4e036420cd4f3e62694c33d235747d23dabc4ac54236fe46b9cdf0290c93a9f0'),'contract':(SRC/'converter-ack-contract.json','971cccbdd9d351e24ca81a5aeeb35008c606421bb72eaeea61d671e54bacbde5'),'patch':(SRC/'converter-ack.patch','a3c14d0f3474c101a6c80505e5fb33df45950c4a7df72c8c23658afdfa32e7f5')}
def ref(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(p,value):
 with p.open('x')as f:f.write(json.dumps(value,indent=2)+'\n')
def birth(pid):
 try:return int(Path('/proc/%d/stat'%pid).read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError:return None

def limits():
 os.sched_setaffinity(0,{0})
 resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30))
 resource.setrlimit(resource.RLIMIT_CPU,(60,60))
 resource.setrlimit(resource.RLIMIT_FSIZE,(64<<20,64<<20))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def run(argv,label,out,start,expected_failure=False):
 assert time.monotonic()-start<85,'original90second envelope nearing cutoff; no new dispatch'
 d=out/label;d.mkdir()
 epoch=time.time();mono=time.monotonic()
 with (d/'stdout').open('xb')as so,(d/'stderr').open('xb')as se:
  child=subprocess.Popen([str(x)for x in argv],cwd=HERE,stdout=so,stderr=se,preexec_fn=limits)
  childbirth=birth(child.pid)
  got,status,usage=os.wait4(child.pid,0)
  assert got==child.pid
  code=os.WEXITSTATUS(status)if os.WIFEXITED(status)else -os.WTERMSIG(status)
  child.returncode=code
 receipt=dict(scope=SCOPE,argv=[str(x)for x in argv],cwd=str(HERE),pid=child.pid,birth=childbirth,parent_pid=os.getpid(),positive_direct_wait4=True,wait4_pid=got,wait_status=status,returncode=code,streams_closed=True,start_epoch=epoch,finish_epoch=time.time(),wall_seconds=time.monotonic()-mono,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,maxrss_KiB=usage.ru_maxrss,stdout=ref(d/'stdout'),stderr=ref(d/'stderr'),limits=dict(CPU=[0],AS_bytes=2<<30,CPU_seconds=60,FSIZE_bytes=64<<20,CORE_bytes=0,jobs=1,aggregate_wall_seconds=90))
 put(d/'JOIN-WAIT4.json',receipt)
 receipt['expected_failure']=expected_failure
 if (expected_failure and code!=1) or (not expected_failure and code!=0):raise RuntimeError('Unexpected command result: '+label+' rc='+str(code)+' retained in '+str(d))
 return receipt



def main():
 start=time.monotonic();limits()
 out=HERE/'actual-selected-header-run-1';out.mkdir()
 put(out/'PARENT-START.json',dict(scope=SCOPE,parent_pid=os.getpid(),birth=birth(os.getpid()),outer_parent_pid=os.getppid(),outer_parent_birth=birth(os.getppid()),start_epoch=time.time(),start_monotonic=start,allowed_seconds=90,affinity=sorted(os.sched_getaffinity(0)),rlimits={str(k):list(resource.getrlimit(k))for k in [resource.RLIMIT_AS,resource.RLIMIT_CPU,resource.RLIMIT_FSIZE,resource.RLIMIT_CORE]}))
 pins={}
 for key,(path,sha)in PIN.items():pins[key]=ref(path);assert pins[key]['sha256']==sha
 pins['selected_header']=ref(HERE/'selected-include/bfd.h');assert pins['selected_header']['sha256']=='de900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432'
 pins['header_dependencies']={f.name:ref(f)for f in sorted((HERE/'selected-include').iterdir())if f.name!='bfd.h'}
 pins['prior_owned_candidate']=ref(HERE.parent/'ownership-repair-source-1/ldump2mcdump_helpers.ownership-candidate.rs');assert pins['prior_owned_candidate']['sha256']=='dc0d6f75f0d6fbc648223a4b75da6419f4e7d8fbbdacb77a6056daceafd22cac'
 pins['ABI_checklist']=ref(HERE.parent/'ownership-repair-source-1/independent-ownership-review-1/SELECTED-BFD-ABI-BLOCKER-AND-CHECKLIST.json');assert pins['ABI_checklist']['sha256']=='c779e8c163a6bfe89e491ce9aa4caaf19b02035ebd9f8d4ed4b1f6c6e34c3d3f'
 pins['new_candidate']=ref(HERE/'ldump2mcdump_helpers.selected-bfd-candidate.rs');pins['fixture']=ref(HERE/'selected_header_fixture.c');pins['witness']=ref(HERE/'section_layout_witness.c');pins['rustc']=ref(RUSTC)
 put(out/'INPUTS.json',pins)
 include=['-I'+str(HERE/'selected-include')]
 receipts=[];witness=out/'section-layout-witness';layout=out/'section_layout.rs'
 receipts.append(run(['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror',*include,HERE/'section_layout_witness.c','-o',witness],'witness-compile',out,start))
 receipts.append(run([witness],'witness-run',out,start));layout.write_bytes(Path(receipts[-1]['stdout']['path']).read_bytes())
 for source,label in [('negative_obsolete_setters.c','negative-arity'),('negative_obsolete_layout.c','negative-layout')]:
  receipts.append(run(['/usr/bin/cc','-std=c11','-Wall','-Wextra','-Werror',*include,'-fsyntax-only',HERE/source],label,out,start,expected_failure=True))
  err=Path(receipts[-1]['stderr']['path']).read_text()
  assert ('too many arguments' in err and 'bfd_set_section' in err)if label=='negative-arity'else('static assertion failed' in err)
 obj=out/'selected-bfd-candidate.o';binary=out/'selected-header-fixture'
 receipts.append(run(['/usr/bin/env','MCKERNEL_LDUMP2_BFD_LAYOUT_RS='+str(layout),RUSTC,'--crate-name','ldump2mcdump_selected_bfd','--crate-type','lib','--edition=2021','--cfg','ldump2_full_body','-C','panic=abort','-C','opt-level=2','-C','codegen-units=1','--emit=obj='+str(obj),HERE/'ldump2mcdump_helpers.selected-bfd-candidate.rs'],'candidate-compile',out,start))
 receipts.append(run(['/usr/bin/nm','-u',obj],'undefined-symbols',out,start))
 undefined={line.split()[-1]for line in Path(receipts[-1]['stdout']['path']).read_text().splitlines()}
 allowed={'argcnt','args','asctime','bfd_close','bfd_close_all_done','bfd_fopen','bfd_get_section_by_name','bfd_init','bfd_make_section_anyway','bfd_perror','bfd_set_format','bfd_set_section_contents','bfd_set_section_flags','bfd_set_section_size','calloc','fflush','fp','fprintf','free','fwrite','gethostname','getopt','getpwuid','getuid','localtime','machdep','malloc','memset','memcpy','optarg','perror','readmem','register_extension','stderr','strcpy','strlen','symbol_value','time'}
 assert undefined<=allowed,'exact observed import family includes unexpected symbol'
 wraps=['malloc','calloc','free','fwrite','fprintf','fflush','getopt','gethostname','getuid','getpwuid','time','localtime','asctime','perror']
 receipts.append(run(['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-DEXPECT_ACK=1',*include,HERE/'selected_header_fixture.c',obj,*['-Wl,--wrap='+x for x in wraps],'-o',binary],'selected-header-link',out,start))
 original=[('success',0)]+[('metadata',i)for i in range(1,8)]+[('physical',i)for i in range(1,4)]+[('write',i)for i in range(1,8)]+[('close',1),('physchunks-null',1)]+[('allocation',i)for i in range(1,8)]
 extra=[('open',1),('format',1),('time',1),('localtime',1)]+[(kind,i)for kind in ('make','size','flags')for i in range(1,8)]+[('get-phys',i)for i in range(1,4)]+[('abort-false',1)]
 observations=[];preserved=[]
 stable=['ack','flushes','read_calls','physical_reads','physical_writes','physical_read_mask','physical_write_mask','writes','read_diagnostics','bfd_errors','map_buffers_freed','map_buffers_live','live_allocations','live_bytes','ownership_complete']
 for kind,pos in original+extra:
  label='selected-%s-%d'%(kind,pos);receipt=run([binary,kind,str(pos)],label,out,start);receipts.append(receipt)
  lines=Path(receipt['stdout']['path']).read_text().splitlines();assert len(lines)==2 and lines[0].startswith('STRICT_OWNERSHIP ')
  row=json.loads(lines[1]);ownership=dict(token.split('=',1)for token in lines[0].split()[1:]);assert ownership['handles']==ownership['destroyed'] and ownership['live_project']=='0' and row['ownership_complete']is True
  oldpath=HERE.parent/'ownership-repair-source-1/actual-strict-run-1'/('strict-%s-%d'%(kind,pos))/'stdout';old=json.loads(oldpath.read_text().splitlines()[1]);assert all(old[k]==row[k]for k in stable),'preserved functional/ownership effect divergence '+label
  observations.append(dict(case=[kind,pos],body=row,ownership=ownership,join=ref(out/label/'JOIN-WAIT4.json')))
  preserved.append(dict(case=[kind,pos],prior_observation=ref(oldpath),compared_fields=stable))
 result=dict(scope=SCOPE,status='PASS_PRIVATE_SELECTED_HEADER_CORRECT_BFD_ABI_AND_FULL56_BODY_OWNERSHIP_HOST_ONLY',candidate=pins['new_candidate'],selected_header=pins['selected_header'],generated_Rust_layout=ref(layout),C_witness_all_imports_and_constants=True,obsolete_three_arg_API_compile_rejected=True,obsolete_section_layout_compile_rejected=True,real_selected_asection_used_in_fixture=True,whole_asection_compared_to_selected_inline_set_vma=True,packed_bit_and_unrelated_fields_preserved=True,actual_cases=len(observations),observations=observations,preserved_prior56_effects=preserved,all_tested_returns_zero_project_allocations_and_owned_mock_handles=True,names_alive_through_terminal_mock_teardown=True,terminal_FALSE_no_retry=True,commands=len(receipts),expected_negative_compile_status1=2,all_direct_children_positive_wait4=True,wall_seconds=time.monotonic()-start,sum_command_wall_seconds=sum(x['wall_seconds']for x in receipts),child_CPU_seconds=sum(x['user_seconds']+x['system_seconds']for x in receipts),peak_command_RSS_KiB=max(x['maxrss_KiB']for x in receipts),selected_SDK_compiler_or_static_archive_binding=False,real_BFD_SDK_native_whole_file_acceptance=False,runtime_authority=None)
 assert result['wall_seconds']<90
 put(out/'COMMANDS.json',receipts);put(out/'RESULT.json',result)
 put(out/'PARENT-FINISH.json',dict(parent_pid=os.getpid(),birth=birth(os.getpid()),finish_epoch=time.time(),direct_children=len(receipts),all_direct_children_positive_wait4=True,unjoined_children=[],streams_closed=True,wall_seconds=time.monotonic()-start))
 for key,(path,sha)in PIN.items():assert ref(path)==pins[key]
 print(json.dumps({k:v for k,v in result.items()if k not in ('observations','preserved_prior56_effects')}))

if __name__=='__main__':main()
