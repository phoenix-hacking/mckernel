Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Complete private joint19 postimages/patch extend the frozen16/conditional17 with
selected-header ABI converter5aab8a42, exact nonshipped typed witness and exact
Ldump2SelectedBfdLayout fragment78bc5d6f under executer/user/cmake/ldump2-selected-bfd/.
The actual default Rust ldump producer branch includes the fragment regardless
of vmcore wrapper selection, passes LDUMP2_BFD_LAYOUT_ENV to its existing cmake-E-env
Rust command and LDUMP2_BFD_LAYOUT_DEPENDS to that object's DEPENDS. All other
producer flags, RUSTC selection and target/install behavior remain. Runtime program
selectors default OFF; their separate explicit compiler and dependencies remain.
Only the new5aab converter matches the vmcore hash gate; old520566/dc0d refuse.
The full patch passes git apply --check against current canonical; no canonical,
frozen16/17, installedconsumer or other owner files changed.

Production fragment is byte-identical78bc5d6f: headerde900/compiler2092 pins,
selected native witness and crosscompile refusal are unchanged. Five actual
LANGUAGES NONE generation tests used explicit TEST_ONLY file-SHA/try_run effect
leaves to inspect wiring without any SDK probe/compiler execution. They cover
layout required with vmcoreOFF, new5aab vmcoreON, both stalehash refusals and
crosscompile refusal. Generated ldump object rules contain the layout environment,
layout data, witness and selected header dependencies. First fixture provided a
normal compiler variable instead of the actual recipe's cache binding; the
selector cleared it under old CMake policy. Failure retained in generation-checks-1;
one bounded harness correction passed explicit FILEPATH in argv, and all five
checks pass in generation-checks-2. No Rust/body tests were rerun.

Independent selected-ABI source/exact-header HOST reviewe1f92370 and actual56case/
63join evidence are bound at their true scopes. Actual SDK GCC14 witness generation,
archive2324byte/FFI link binding, current admission, production compile/link,
installed default/native and real valid-dump publication remain OPEN. A focused
joint integration source review remains pending. Test effect leaves are not SDK
qualification. No execution authority or acceptance supplied.
