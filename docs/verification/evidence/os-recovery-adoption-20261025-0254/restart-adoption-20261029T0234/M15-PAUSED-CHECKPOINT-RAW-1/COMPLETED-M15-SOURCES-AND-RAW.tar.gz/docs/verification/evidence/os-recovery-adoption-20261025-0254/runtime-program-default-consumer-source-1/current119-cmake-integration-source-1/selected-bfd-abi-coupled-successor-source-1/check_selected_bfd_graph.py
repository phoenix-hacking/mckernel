"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
LANGUAGES NONE graph checks; explicit TEST_ONLY SHA/witness leaves, no probe run.
"""
from pathlib import Path
import hashlib,json,os,resource,shutil,subprocess
D=Path(__file__).resolve().parent;P=D.parent;M=json.loads((D/'FILEMAP.SOURCE-ONLY.json').read_text());O=D/'generation-checks-2';assert not O.exists();O.mkdir()
user=(D/'postimage/executer/user/CMakeLists.txt').read_text();start=user.index('set(LDUMP2MCDUMP_SRCS ldump2mcdump.c)');end=user.index('\nadd_library(ldump2mcdump',start);producer=user[start:end]
ready=json.loads(Path(M['selected_ABI_ready']['path']).read_text());fragment=D/'postimage/executer/user/cmake/ldump2-selected-bfd/Ldump2SelectedBfdLayout.cmake';assert hashlib.sha256(fragment.read_bytes()).hexdigest()==ready['future_CMake_fragment']['sha256']
def limits():
 os.sched_setaffinity(0,{0})
 for k,v in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0)]:resource.setrlimit(k,(v,v))
results=[]
for name,vmcore,stale,success,cross in [('default-rust-ldump-vmcore-OFF',False,None,True,False),('selected5aab-vmcore-ON',True,None,True,False),('old520566-refused',True,'520566',False,False),('olddc0d-refused',True,'dc0d',False,False),('crosscompile-refused',False,None,False,True)]:
 c=O/name;s=c/'source';b=c/'build';shutil.copytree(D/'postimage',s)
 if stale:
  old=Path(json.loads((P.parent/'EXACT-PREIMAGE-RUST-CONSUMER-DELTA.NOT-QUALIFIED.json').read_text())['vmcore_joint_dependency']['ACK_candidate']['path']) if stale=='520566' else Path(json.loads((P/'ownership-coupled-successor-source-1/FILEMAP.SOURCE-ONLY.json').read_text())['vmcore_required_producer']['path'])
  shutil.copyfile(old,s/'executer/user/rust/ldump2mcdump_helpers.rs')
 fake=s/'TEST_ONLY_NONEXECUTABLE_COMPILER';fake.write_text('TEST_ONLY not executable; never invoked\n')
 (s/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.10)
project(TEST_ONLY_SELECTED_BFD_GRAPH LANGUAGES NONE)
set(prefix /opt/mckernel)
set(ARCH x86_64)
set(ENABLE_RUST_USER_TOOLS ON)
set(RUSTC "${PROJECT_SOURCE_DIR}/TEST_ONLY_NONEXECUTABLE_COMPILER")
set(CMAKE_C_COMPILER "${RUSTC}")
# TEST_ONLY effect leaves. Production fragment remains exact and cannot qualify SDK.
macro(file action)
 if("${action}" STREQUAL "SHA256" AND "${ARGV1}" STREQUAL "/usr/include/bfd.h")
  set(${ARGV2} de900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432)
 elseif("${action}" STREQUAL "SHA256" AND "${ARGV1}" STREQUAL "${CMAKE_C_COMPILER}")
  set(${ARGV2} 2092e32fa9abee9ccbf777a5f893b9cc608582b660c93e742a17c3eb7da109c2)
 else()
  _file(${ARGV})
 endif()
endmacro()
macro(try_run run_result compile_result)
 set(${run_result} 0)
 set(${compile_result} TRUE)
 set(_ldump2_bfd_layout "// TEST_ONLY noncompiled witness output\\n")
 set(_ldump2_bfd_compile_log "TEST_ONLY no compiler invoked")
 set(TEST_ONLY_WITNESS_REQUIRED TRUE CACHE INTERNAL "graph observation")
endmacro()
add_subdirectory(executer/user)
''')
 # Exact real producer branch (including include/env/dependencies), with no language link leaf.
 (s/'executer/user/CMakeLists.txt').write_text(producer+'\nadd_custom_target(ldump2mcdump)\ninclude("${CMAKE_CURRENT_SOURCE_DIR}/cmake/SelectRustVmcore2mckdump.cmake")\n')
 # OFF reference template is a data-only configure input.
 shutil.copyfile('/home/holden/mckernel/executer/user/vmcore2mckdump.in',s/'executer/user/vmcore2mckdump.in')
 if cross:
  with (s/'CMakeLists.txt').open('a') as f:pass
  text=(s/'CMakeLists.txt').read_text().replace('add_subdirectory(executer/user)','set(CMAKE_CROSSCOMPILING TRUE)\nadd_subdirectory(executer/user)');(s/'CMakeLists.txt').write_text(text)
 argv=['/usr/bin/cmake','-S',str(s),'-B',str(b),'-G','Unix Makefiles','-DMCKERNEL_RUNTIME_TOOL_RUSTC:FILEPATH='+str(fake),'-DENABLE_RUST_VMCORE2MCKDUMP='+('ON' if vmcore else 'OFF')]
 r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,preexec_fn=limits,env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='1',MAKEFLAGS='-j1',OMP_NUM_THREADS='1'));(c/'stdout').write_bytes(r.stdout);(c/'stderr').write_bytes(r.stderr);assert (r.returncode==0)==success,(name,r.stderr.decode())
 if success:
  rule=(b/'executer/user/CMakeFiles/ldump2mcdump_rust_helpers.dir/build.make').read_text();assert 'MCKERNEL_LDUMP2_BFD_LAYOUT_RS=' in rule and 'ldump2_bfd_section_layout.rs' in rule and '/usr/include/bfd.h' in rule and 'section_layout_witness.c' in rule
  assert 'TEST_ONLY_WITNESS_REQUIRED:INTERNAL=TRUE' in (b/'CMakeCache.txt').read_text()
 elif cross:assert b'separately qualified native witness' in r.stderr
 else:assert b'exact jointly reviewed ACK producer' in r.stderr
 results.append(dict(name=name,argv=argv,returncode=r.returncode,expected_success=success,TEST_ONLY_effect_leaves=['file SHA256 selected SDK header/compiler','try_run witness compile/run'],production_fragment_exact=True,actual_compiler_or_probe_calls=0))
(O/'RESULT.json').write_text(json.dumps(dict(scope=M['scope'],status='PASS_FOCUSED_GENERATOR_GRAPH_ONLY_TEST_ONLY_EFFECT_LEAVES',runtime_authority=None,cases=results,production_fragment=ready['future_CMake_fragment'],SDK_qualification=False,body_Rust_test_reruns=0),indent=2)+'\n')
print('PASS five focused actual CMake graph cases, no compiler/probe execution')
