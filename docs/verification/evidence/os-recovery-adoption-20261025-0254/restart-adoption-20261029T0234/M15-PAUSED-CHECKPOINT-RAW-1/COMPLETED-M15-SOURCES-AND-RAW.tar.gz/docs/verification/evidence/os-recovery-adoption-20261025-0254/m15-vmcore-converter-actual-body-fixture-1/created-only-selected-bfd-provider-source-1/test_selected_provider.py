"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Small substituted-effects transaction and exact adaptation refusals. No Docker calls.
"""
from pathlib import Path
import ast,copy,hashlib,io,json,os,shutil,subprocess,tempfile,time,unittest
import created_only_selected_bfd_adapter as m
D=Path(__file__).resolve().parent
B=m.bindings();API=m.interfaces(B);MANIFEST=m.provider_manifest(B)
IMAGE=json.loads(m.checked(B['immutable_image_reply']))[0]
CID='b'*64

def request(out):
 return dict(author='/root',operation='CREATED_ONLY_41778_SELECTED_BFD_PROVIDER_EXPORT',maximum_invocations=1,image=m.IMAGE,nonce='a'*32,name='m15-bfd-provider-extract-'+'a'*32,output_root=str(out),targets={key:str(out/name)for key,_,name in m.FIXED_PROVIDERS},native_or_build_authority=False)

def container(q):
 h=dict(API['LIMITS'],Privileged=False,ReadonlyRootfs=True,CapDrop=['ALL'],SecurityOpt=['no-new-privileges'],Init=True,PidMode='',IpcMode='private',Devices=[],DeviceRequests=None,Binds=None,CapAdd=None,CgroupParent='',Tmpfs={'/tmp':'rw,nodev,nosuid,size=256m'},RestartPolicy={'Name':'no','MaximumRetryCount':0})
 labels=dict(B['pinned_image_labels']);labels['mckernel.owner']=q['nonce']
 return dict(Id=CID,Name='/'+q['name'],Image=m.IMAGE,Mounts=[],HostConfig=h,Config=dict(User='%d:%d'%(os.getuid(),os.getgid()),Entrypoint=['/usr/bin/sleep'],Cmd=['infinity'],Labels=labels,Env=B['pinned_image_env']),State=dict(Status='created',Running=False,Pid=0,Paused=False,Restarting=False,Dead=False,OOMKilled=False))

class Effects:
 def __init__(self,q):
  self.q=q;self.info=container(q);self.calls=[];self.events=[];self.published={};self.retained=[];self.admissions=[];self.client_retirement_unproven=False;self.before_popen=self.hook;self.bad_created_cid=False;self.start_during_cp=False;self.mismatch=None;self.stale_at=None
 def admit(self,q):
  if self.stale_at==len(self.calls)+1:raise m.Refusal('TEST_ONLY stale actual owner admission')
  self.events.append('admit');self.admissions.append(q['nonce'])
 def hook(self,argv):self.events.append('before_popen')
 def publish(self,name,value):self.published[name]=value
 def retain(self,value):self.retained.append(value)
 def exact(self,argv,timeout,check=True):
  assert argv[:4]==m.PREFIX and timeout==30;self.before_popen(argv);self.events.append('spawn');args=argv[4:];self.calls.append(args)
  if args[:2]==['image','inspect']:out=json.dumps([IMAGE])
  elif args[0]=='create':
   assert args==API['create_args'](self.q['name'],m.IMAGE,self.q['nonce']);out=(m.FORBIDDEN_CID if self.bad_created_cid else CID)+'\n'
  elif args[:3]==['inspect','--type','container']:assert args[-1]==CID;out=json.dumps([self.info])
  elif args[:2]==['cp','-L']:
   match=[(key,source,name)for key,source,name in m.FIXED_PROVIDERS if args==['cp','-L',CID+':'+source,self.q['targets'][key]]];assert len(match)==1
   key,source,name=match[0];row=MANIFEST['providers'][key];raw=m.checked(row['official_reference']);Path(self.q['targets'][key]).write_bytes(raw)
   if key==self.mismatch:
    target=Path(self.q['targets'][key]);data=bytearray(target.read_bytes());data[-1]^=1;target.write_bytes(data)
   if self.start_during_cp:self.info['State'].update(Status='running',Running=True,Pid=777)
   out=''
  elif args==['rm','--',CID]:out=CID+'\n'
  elif args[:5]==['ps','--all','--quiet','--no-trunc','--filter']:out=''
  else:raise AssertionError('unexpected extra/start/probe command '+repr(args))
  return subprocess.CompletedProcess(argv,0,out,'')
 def run(self):return m.execute_created_only(self.q,commands=self,admit=self.admit,publish=self.publish,retain_uncertainty=self.retain)

class SelectedProviders(unittest.TestCase):
 def temp(self):return tempfile.TemporaryDirectory(prefix='actual-selected-bfd-export-TEST_ONLY_',dir=D)
 def test_exact_three_copy_transaction_matches_direct_archive_bytes(self):
  with self.temp()as name:
   e=Effects(request(Path(name)));result=e.run()
   self.assertEqual([x[0]for x in e.calls],['image','create','inspect','cp','cp','cp','inspect','rm','ps','ps'])
   self.assertEqual(result['command_count'],10);self.assertEqual(len(e.admissions),10);self.assertEqual(e.events,['admit','before_popen','spawn']*10)
   self.assertEqual(set(result['providers']),{'archive','linker_script','header'})
   self.assertEqual(result['providers']['archive']['file']['sha256'],'2324c3f9557b3387126123659badf4cccdbbd272104aec42a21c709c31bf6d4e')
   for key in result['providers']:
    self.assertTrue(result['providers'][key]['exact_official_bytes_match']);self.assertEqual(result['providers'][key]['file']['bytes'],MANIFEST['providers'][key]['bytes'])
   self.assertFalse(result['SDK_compile_link_or_native_acceptance']);self.assertEqual(e.retained,[])
 def test_CID_start_extra_path_and_args_refuse_before_effect(self):
  with self.temp()as name:
   for change in [dict(cid=m.FORBIDDEN_CID),dict(start=True),dict(argv=['exec']),dict(source='/arbitrary'),dict(targets={'archive':str(Path(name)/'other')}),dict(maximum_invocations=True)]:
    q=request(Path(name));q.update(change);e=Effects(q)
    with self.assertRaises(m.Refusal):e.run()
    self.assertEqual(e.calls,[])
   e=Effects(request(Path(name)));e.bad_created_cid=True
   with self.assertRaisesRegex(m.Refusal,'retired2460'):e.run()
   self.assertEqual([x[0]for x in e.calls],['image','create']);self.assertTrue(e.retained)
 def test_each_provider_mismatch_retains_without_remove_or_retry(self):
  for key in MANIFEST['order']:
   with self.temp()as name:
    e=Effects(request(Path(name)));e.mismatch=key
    with self.assertRaisesRegex(m.Refusal,'SHA256'):e.run()
    self.assertNotIn('rm',[x[0]for x in e.calls]);self.assertEqual(sum(x[0]=='cp'for x in e.calls),MANIFEST['order'].index(key)+1)
    self.assertTrue(e.retained[-1]['created_confirmed']);self.assertFalse(e.retained[-1]['removed_confirmed']);self.assertTrue(e.retained[-1]['no_automatic_cleanup_or_retry'])
 def test_started_state_and_profile_mismatch_preserve_owner(self):
  with self.temp()as name:
   e=Effects(request(Path(name)));e.info['State'].update(Status='running',Running=True,Pid=777)
   with self.assertRaises(RuntimeError):e.run()
   self.assertEqual([x[0]for x in e.calls],['image','create','inspect'])
   e=Effects(request(Path(name)));e.info['HostConfig']['NetworkMode']='host'
   with self.assertRaises(RuntimeError):e.run()
   self.assertEqual([x[0]for x in e.calls],['image','create','inspect'])
 def test_stale_admission_prevents_first_and_copy_spawn(self):
  with self.temp()as name:
   for at,wanted in [(1,[]),(4,['image','create','inspect'])]:
    e=Effects(request(Path(name)));e.stale_at=at
    with self.assertRaisesRegex(m.Refusal,'stale'):e.run()
    self.assertEqual([x[0]for x in e.calls],wanted);self.assertNotIn('cp',[x[0]for x in e.calls]);self.assertTrue(e.retained)
 def test_profile_AST_and_portable_converter_provenance_unchanged(self):
  oldpath=Path(B['created_only_libelf_source_provenance']['path']);old=ast.parse(oldpath.read_bytes());new=ast.parse(Path(m.__file__).read_bytes())
  functions=lambda tree:{n.name:ast.dump(n,include_attributes=False)for n in tree.body if isinstance(n,ast.FunctionDef)}
  a=functions(old);b=functions(new)
  for key in ['interfaces','reference','checked','bindings']:self.assertEqual(a[key],b[key],key)
  helper=m.checked(B['wait_status_helper']);self.assertEqual(hashlib.sha256(helper).hexdigest(),'c895898a0a0162d78e521f4ded5ea7c75b46bd47d7764003f31c09d2d2f31d0a')
  original=Path(B['reviewed_owner_snapshot']['path']).read_bytes();self.assertEqual(hashlib.sha256(original).hexdigest(),'9634b56f251857141c67b70ce7a0c058470d6ef000a5f041898a91e3a71f6679')

if __name__=='__main__':
 start=time.monotonic();stream=io.StringIO();r=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SelectedProviders));(D/'PURE-TESTS.stdout').write_text(stream.getvalue());result=dict(scope=__doc__.splitlines()[0],status='PASS'if r.wasSuccessful()else'FAIL',groups=r.testsRun,failures=len(r.failures),errors=len(r.errors),seconds=time.monotonic()-start,actual_Docker_guard_current_free_export_or_signal_calls=0,substituted_Docker_effects_only=True,SDK_provider_qualified=False,runtime_authority=None);(D/'PURE-RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(stream.getvalue(),end='');print(json.dumps(result));raise SystemExit(0 if r.wasSuccessful()else 1)
