Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This private source-only package copies the exact wrapper44329596, all22 original
cases, driver, crash/uname stubs and consumed shell reference. Original sources
remain unchanged. COPIED-SOURCE-MAP.json records the initial exact copies; the
only subsequent fixture change is owned_process.py, bound separately by
SOURCE_READY.NOT-EXECUTED.json. Unused converter reference body is not copied.
No Rust compilation, actual process fixture, PTY, prctl, signal or native test ran.

A concrete Python3.8 lifecycle defect was reproduced through fake effect leaves:
communicate(timeout=3) after the first timeout can fail again while a separate
session descendant holds capture pipes, bypassing old descendant cleanup and
ownership evidence. /usr/lib/python3.8/subprocess.py confirms its POSIX communicate
reads pipe EOF before joining. Original helper and failure shape are retained.
The private correction joins the exact original leader before draining pipes,
then checks only this sole-threaded subreaper's unreaped direct children using
WNOHANG before signals. No poll/reap occurs before the original group signal.
Only original per-command session group and unreaped owned direct children are
targeted. Leader wait, adopted retirement and final pipe drain share one six-second
budget. Streams close and partial evidence is written on failure; failed leader
wait remains UNKNOWN. Timeout/live adopted cleanup always fails the test, even
when retirement succeeds. No silent retry or global cleanup capability exists.
Four actual Python3.8 pure tests PASS in0.014s: original bypass reproduction,
fixed join/adopt/drain ordering and full captures, nonchild refusal without signal,
and UNKNOWN leader/partial output/closed streams. All Popen/prctl/wait/signal
leaves are fake in these tests. No recovery framework was added.

EXECUTION-PROFILE.PROPOSED.NOT-AUTHORITY.json contains the exact single argv:
taskset CPU0, prlimit AS1GiB CORE0 FSIZE64MiB, /usr/bin/python3 -I -B driver
--execute --rustc explicit existing1.92.0 toolchain. The old driver1.85 default
is never selected. Driver work envelope150s plus retirement6s fits outer160s;
Root's existing parent capture must enforce total wall160 and retain actual direct
join, streams and failure evidence. Jobs1; ordinary /dev/ptmx only, no root,
Docker, SDK, custom devices or real dump. This proposal does not start anything.
Source/profile independent approval, Root release and current finitewatcher/
account/hold conditions remain required. It cannot clear actual controls or
native custody. Do not add --with-reference-protocol: /usr/bin/expect is absent.
No installation or substitute Expect parser is permitted or proposed.

The22 cases cover CLI, fragmented prompts, exact ACK/fresh output, failure
preservation of old bytes, command failures/signals, prompt timeout and child
retirement. Intended success requires clean prompts/exit, exact staging ACK,
fresh nonempty staging and atomic publication. The original shell's false success
on an old output is an observation only. CLI checks before Expect are distinct
from unavailable real Expect protocol parity. This HOST fixture uses synthetic
bytes and a crash PTY stub; it cannot establish dump format, selected converter
ABI/SDK linkage, installed/native behavior or full-file acceptance.
