Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Do not execute the22case package. The original60ea/80f3 source/profile is frozen
in snapshot/. The Owner UNKNOWN path can still unwind into the driver and lose
custody. Three pure fake-effect tests reproduce this exact blocked condition and
check KeyboardInterrupt/RuntimeError ordering; they do not claim the required
retention behavior passes. No compiler, PTY, prctl, Popen, wait or signal ran.

No source-compatible ordinaryHOST retention primitive was found in the bounded
existing sources. The accepted critical capture parent is CPU7/no-outer-kill and
waits its own direct child; it supplies no ordinary fixture subreaper custody
transfer API. Scratch quarantine_hold uses27:4 and an unbounded hold, both outside
this fixture profile. Copying either would create unsupported authority or a new
recovery design. No placeholder callback, JSON attestation, automatic owner exit
or deadline-triggered hidden kill is presented as a correction.

The precise missing gate is a genuine reviewed Root direct-parent contingency
plus a source-bound owner retention primitive. On UNKNOWN it must stop all new
fixture work and keep the owning process visible without unwinding, while Root
handles the actual children/parentjoin under the same finite06:00Z/MONO/BOOT,
cumulativecredit and externalstop controls. Normal work150+sharedcleanup6 fits
original total160; that160 bound cannot be used as authority to kill an UNKNOWN
owner. Retention cannot silently extend the window. Root must resolve its exact
boundary handling before dispatch. The blocked successor profile lists these
requirements; no new leases/controllers/recovery framework or27:4 action exists.

Python3.8 communicate can reap on KeyboardInterrupt before rethrow; the current
returncode check correctly prevents later killpg. RuntimeError with unreaped
leader signals only the original group before parentwait. Closed stream handles
are not a complete-capture claim: the failed drain path records error and lacks
capture_complete. A future reviewed correction should make capture_complete
explicit rather than infer it from streams_closed. Fully joined failures may
raise; unjoined failures must stay in the reviewed retention path. Until those
semantics are implemented and independently reviewed, all22cases remain UNRUN.
