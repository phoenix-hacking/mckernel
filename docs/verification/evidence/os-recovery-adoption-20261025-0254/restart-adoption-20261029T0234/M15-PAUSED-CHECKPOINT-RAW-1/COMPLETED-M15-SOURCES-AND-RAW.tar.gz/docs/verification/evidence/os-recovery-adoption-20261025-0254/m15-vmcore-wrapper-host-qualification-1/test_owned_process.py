"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure fake effect leaves only: no Popen, prctl, PTY, signals or actual wait calls.
"""
from pathlib import Path
import importlib.util,json,subprocess,tempfile,unittest
from unittest.mock import patch
D=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
class Stream:
 closed=False
 def close(self):self.closed=True
class Fake:
 pid=111
 def __init__(self,repeated=False,timeout=False):self.stdin=None;self.stdout=Stream();self.stderr=Stream();self.returncode=None;self.count=0;self.repeated=repeated;self.timeout=timeout;self.events=[]
 def communicate(self,timeout):
  self.count+=1;self.events.append('communicate')
  if self.count==1 or self.repeated:raise subprocess.TimeoutExpired(['TEST_ONLY'],timeout,output=b'partial',stderr=b'partialerr')
  return b'complete',b'completeerr'
 def wait(self,timeout):
  self.events.append('leaderwait')
  if self.timeout:raise subprocess.TimeoutExpired(['TEST_ONLY'],timeout)
  self.returncode=-9;return -9
class Tests(unittest.TestCase):
 def invoke(self,old=False,child_error=False,wait_timeout=False):
  m=load('TEST_ONLY_owner',D/('original-owned_process.py' if old else 'fixture/owned_process.py'));f=Fake(repeated=old,timeout=wait_timeout);events=f.events
  tmp=tempfile.TemporaryDirectory(dir=D);self.addCleanup(tmp.cleanup);out=Path(tmp.name);o=m.Owner.__new__(m.Owner);o.output=out;o.records=[]
  child_values=iter(['222','222','',''] if not child_error and not wait_timeout else ['222','222'])
  realread=Path.read_text
  def read(p,*a,**k):return next(child_values) if str(p).startswith('/proc/self/task/') else realread(p,*a,**k)
  waits=iter([(0,0),(222,9)])
  def waitpid(pid,flags):
   events.append('adoptedwait')
   if child_error:raise ChildProcessError('TEST_ONLY not owned')
   return next(waits)
  with patch.object(m.subprocess,'Popen',return_value=f) as popen,patch.object(m.os,'killpg',side_effect=lambda *a:events.append(('group',a))) as kg,patch.object(m.os,'kill',side_effect=lambda *a:events.append(('child',a))) as kill,patch.object(m.os,'waitpid',side_effect=waitpid),patch.object(m.time,'monotonic',return_value=0),patch.object(m.time,'sleep'),patch.object(Path,'read_text',read):
   with self.assertRaises((RuntimeError,subprocess.TimeoutExpired)):o.run(['TEST_ONLY'],{},D,1,'test')
   self.assertTrue(popen.call_args.kwargs['start_new_session']);self.assertEqual(kg.call_args.args[0],111)
  return out,f,events,kill
 def test_original_second_communicate_timeout_bypasses_cleanup_and_evidence(self):
  out,f,e,k=self.invoke(old=True);self.assertFalse((out/'ownership.json').exists());self.assertNotIn('adoptedwait',e)
 def test_fixed_join_before_adopted_cleanup_then_pipe_drain(self):
  out,f,e,k=self.invoke();record=json.loads((out/'ownership.json').read_text())[0];self.assertTrue(record['leader_parent_joined']);self.assertTrue(record['whole_descendants_joined']);self.assertTrue(record['streams_closed']);self.assertTrue(record['timed_out']);self.assertEqual(record['status'],-9);self.assertEqual(record['adopted_reaps'],[dict(pid=222,status=9)]);self.assertLess(e.index('leaderwait'),e.index('adoptedwait'));self.assertEqual(e[-1],'communicate');self.assertEqual((out/'test.stdout').read_bytes(),b'complete')
 def test_nonchild_wait_refusal_never_signals_that_pid(self):
  out,f,e,k=self.invoke(child_error=True);self.assertFalse(k.called);record=json.loads((out/'ownership.json').read_text())[0];self.assertFalse(record['whole_descendants_joined']);self.assertTrue(record['streams_closed']);self.assertIn('ChildProcessError',record['error'])
 def test_unknown_leader_wait_remains_unknown_with_partial_streams(self):
  out,f,e,k=self.invoke(wait_timeout=True);record=json.loads((out/'ownership.json').read_text())[0];self.assertEqual(record['status'],'UNKNOWN');self.assertFalse(record['leader_parent_joined']);self.assertFalse(record['whole_descendants_joined']);self.assertTrue(record['streams_closed']);self.assertEqual((out/'test.stdout').read_bytes(),b'partial');self.assertFalse(k.called)
if __name__=='__main__':unittest.main()
