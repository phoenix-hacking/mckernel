Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Private fixed three-provider adapterf1127467 is source-ready for independent
review. It extends the existing reviewed created-only41778 libelf adapter and
its immediate c895 portable-wait4 compatibility source. No Docker/guard/grant/
lease/current-free/SDK export ran. The actual selected SDK archive hash remains
unobserved; source unit tests use retained official package bytes only.

PROVIDERS.json pins exactly three source/target pairs from immutable image41778:
/usr/lib64/libbfd.a -> libbfd.a,18,504,828B/SHA2324c3f9557b3387126123659badf4cccdbbd272104aec42a21c709c31bf6d4e;
/usr/lib64/libbfd.so -> libbfd.so,382B/SHA6cfd31804974c248c9512879e7b77a94862f92150c2171d901140464ea936ab3;
/usr/include/bfd.h -> bfd.h,252,810B/SHAde900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432.
Official package/source facts3db997f0 bind each expected reference. Archive,
GNU ld script and C header shapes are separately checked. The script is explicitly
not assumed to be an ELF DSO; header/script matches cannot substitute for direct
archive bytes. All three expected size/hash checks must pass in the adapter.

Root supplies one exact request and the existing ordinary owner bridge through
execute_created_only. Request keys/operation/image/three targets are fixed;
CID/start/extra argv/arbitrary source or destination fields are refused. Fresh
namespace is confined here as actual-selected-bfd-export-*; nonce/name remain
Root-owned future values. No actual nonce is reserved by this source. The caller
cannot substitute the provider inspector. The original exact resource/profile/
labels/env/UID checks are reused through unchanged reviewed AST units.

The future transaction has exactly10 commands: image inspect, reviewed create,
created-container inspect, three fixed cp -L operations, created-state inspect,
exact owned rm and ID/name absence queries. Never start, probe, exec or reuse
retired2460. Each command must use existing admission plus the transport's final
immediate-before-Popen hook. Parent transport retains c895 wait4 conversion,
positive joins, no-signal uncertainty handling and durable raw receipts. Output
UID0/1000 is recorded unchanged; no chown/permissions change occurs. Any mismatch,
uncertain client, stale admission or changed state keeps container/outputs/lease/
global custody and performs no automatic cleanup or retry.

The historical guardian4889 reference in inherited BINDINGS is lineage only.
This adapter does not invoke it. Root must supply genuine new current guardian/
armed controls/account/window/identity/operation admission, actual CURRENT118
container cleanup and fresh independent current-free, sole resource reservation/
exclusivity and new exact source/publication/execution review. The separate Root
bridge template leaves all those actual fields null. Reusing the portable
transport means its transport(b) API only; never call the old retirement main,
Actual owner or stopped-container release against retired metadata.

Six focused actual Python3.8/CPU0 pure groups pass in0.379990s. The substituted
transaction copies retained official files into TEST_ONLY temporary namespaces,
validates all expected bytes/shapes and exact ten argv/callback ordering. Refusals
cover retired CID, start/extra argv/path fields, each of3mismatches, stale admit
before first/copy spawn and running/profile mismatch. AST source checks preserve
the original profile/interface units and c895 provenance. Original8tests/ed980
source provenance are reused without a redundant rerun. No actual container or
SDK provider is observed in these tests.

PROFILE-AND-EXACT-FUTURE-INTERFACE.json contains the ten command suffixes, owner
entrypoint and all inherited resource/custody requirements. After genuine entry,
Root must bind the actual archive/header/script BYTE outputs and all10client
receipts to the new created CID/image, positively join the owner and obtain fresh
independent current-free. That result can close this direct provider-byte gap;
it does not qualify compiler/link/behavior/native or close M15.

Queued CURRENT119 or installed-M15 firstheavy retains priority. This source
creates no extra heavy slot and no dependency delaying those ready workloads.
Only after the real controls/current-free frontier permits it may Root admit a
new one-shot extraction using the existing ordinary owner. No extraction was
performed here; independent source review is the next action.
