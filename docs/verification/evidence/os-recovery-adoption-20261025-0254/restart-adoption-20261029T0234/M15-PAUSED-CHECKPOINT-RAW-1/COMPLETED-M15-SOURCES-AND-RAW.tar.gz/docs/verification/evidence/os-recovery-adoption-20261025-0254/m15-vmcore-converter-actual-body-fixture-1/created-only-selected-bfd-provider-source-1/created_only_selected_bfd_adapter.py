"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Narrow created-only successor to the reviewed ordinary41778 image owner.
No CLI/release/lease framework. Root supplies existing reviewed owner/admission bridge.
"""
from pathlib import Path
import ast,hashlib,json,os,re,stat,struct
D=Path(__file__).resolve().parent
IMAGE='sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5'
PREFIX=['/usr/bin/sudo','-A','/usr/bin/docker','--host=unix:///var/run/docker.sock']
FORBIDDEN_CID='2460c49fbbbf8be6ee5ae931e7e769eec2f26e352937e7f4a4dcf5d2ebec8008'
BINDINGS_SHA='3d7e1fcfcd9e3705ade0ffd9bf80e0a995713438dbdbbfe1b0cf765a78aae834'

class Refusal(RuntimeError):pass

def need(ok,why):
 if not ok:raise Refusal(why)
def reference(p):
 p=Path(p);need(p.is_absolute() and not p.is_symlink() and p.is_file(),'ordinary absolute input')
 a=p.stat();raw=p.read_bytes();z=p.stat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'stable input bytes')
 return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def checked(r):
 need(type(r)is dict and set(r)=={'path','bytes','sha256'} and reference(r['path'])==r,'exact source/data reference');return Path(r['path']).read_bytes()
def bindings():
 need(reference(D/'BINDINGS.json')['sha256']==BINDINGS_SHA,'sealed extraction source binding');return json.loads((D/'BINDINGS.json').read_bytes())
def interfaces(b):
 """Import only exact reviewed AST units; never import/execute the full owner."""
 old=checked(b['reviewed_owner_snapshot']);backend=checked(b['ordinary_backend']);review=json.loads(checked(b['reviewed_source_record']))
 need(review['status']=='PASS_SOURCE_ONLY' and review['source']['sha256']==hashlib.sha256(old).hexdigest() and IMAGE in review['actual_read_only_checks']['image_identity'],'exact reviewed41778 lineage')
 ns=dict(os=os,RebindProbeError=Refusal)
 tree=ast.parse(backend)
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(n,ast.Name) and n.id in ('LIMITS','RESOURCE_ARGS') for n in node.targets):exec(compile(ast.Module(body=[node],type_ignores=[]),b['ordinary_backend']['path'],'exec'),ns)
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='check_profile');exec(compile(ast.Module(body=[node],type_ignores=[]),b['ordinary_backend']['path'],'exec'),ns)
 names={'create_args','validate_image_inspect','validate_container'};nodes=[n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name in names];need(len(nodes)==3,'three unchanged reviewed profile units')
 exec(compile(ast.Module(body=nodes,type_ignores=[]),b['reviewed_owner_snapshot']['path'],'exec'),ns)
 return ns

FIXED_PROVIDERS=(('archive','/usr/lib64/libbfd.a','libbfd.a'),('linker_script','/usr/lib64/libbfd.so','libbfd.so'),('header','/usr/include/bfd.h','bfd.h'))

def provider_manifest(b):
 manifest=json.loads(checked(b['selected_provider_manifest']))
 need(manifest['image']==IMAGE and manifest['order']==[r[0]for r in FIXED_PROVIDERS] and set(manifest['providers'])==set(manifest['order']),'exact three fixed provider subjects')
 for key,source,target in FIXED_PROVIDERS:
  row=manifest['providers'][key];need(row['source']==source and row['target_basename']==target,'no arbitrary provider path')
 return manifest

def validate_request(q):
 need(type(q)is dict and set(q)=={'author','operation','maximum_invocations','image','nonce','name','output_root','targets','native_or_build_authority'},'exact selected-BFD request keys; no CID/start/extra argv')
 need(q['author']=='/root' and q['operation']=='CREATED_ONLY_41778_SELECTED_BFD_PROVIDER_EXPORT' and type(q['maximum_invocations'])is int and q['maximum_invocations']==1,'exact new Root extraction request')
 need(q['image']==IMAGE,'one fixed immutable image')
 need(type(q['nonce'])is str and re.fullmatch('[0-9a-f]{32}',q['nonce']),'Root fresh32hex owner nonce')
 need(q['name']=='m15-bfd-provider-extract-'+q['nonce'],'exact fresh extraction name')
 out=Path(q['output_root']);need(out.is_absolute() and out.parent==D and re.fullmatch('actual-selected-bfd-export-[A-Za-z0-9_-]+',out.name),'fresh confined Root-owned output namespace')
 need(q['targets']=={key:str(out/name)for key,_,name in FIXED_PROVIDERS} and q['native_or_build_authority']is False,'exact three fresh confined outputs; no runtime authority')
 return out

def inspect_provider(path,row):
 """Direct selected SDK bytes must match official archive/script/header separately."""
 r=reference(path);p=Path(path);st=p.stat()
 need(st.st_nlink==1 and st.st_uid in (0,1000) and st.st_size<=32<<20 and os.access(p,os.R_OK),'bounded readable single-link Root-mediated or ordinary export')
 need(r['bytes']==row['bytes'] and r['sha256']==row['sha256'],'exact expected provider SHA256 and byte count')
 raw=p.read_bytes();shape=row['format']
 if shape=='regular_ar_archive':need(raw.startswith(b'!<arch>\n'),'ordinary ar archive, not thin archive or ELF assumption')
 elif shape=='GNU_ld_script':need(raw.startswith(b'/* GNU ld script */') and b'OUTPUT_FORMAT(elf64-x86-64)'in raw and b'INPUT ( /usr/lib64/libbfd.a'in raw,'exact GNU ld script provider shape; not ELF DSO')
 elif shape=='selected_BFD_header':need(b'#ifndef __BFD_H_SEEN__'in raw and b'bool bfd_close_all_done (bfd *);'in raw,'selected BFD C header shape')
 else:raise Refusal('unknown provider format')
 return dict(file=r,format=shape,official_reference=row['official_reference'],exact_official_bytes_match=True,owner=dict(uid=st.st_uid,gid=st.st_gid,mode=oct(stat.S_IMODE(st.st_mode)),metadata_rewritten=False),SDK_compile_link_or_native_accepted=False)

def execute_created_only(q,*,commands,admit,publish,retain_uncertainty):
 """Root's existing ordinary owner must hold custody and install before_popen.
 admit authenticates new Root grant/reviews/current controls/currentfree/resources/
 exclusive27:4 + lease and output ownership. No historical rebind release is used.
 Commands is the existing no-signal wait4 transport; no arbitrary argv is exposed.
 """
 out=validate_request(q);b=bindings();manifest=provider_manifest(b);api=interfaces(b);need(callable(getattr(commands,'before_popen',None)),'actual final pre-Popen control/clock hook required')
 need(all(not os.path.lexists(path)for path in q['targets'].values()),'all three fresh provider destinations absent')
 cid=None;create_attempted=False;created=False;removed=False;count=0
 def call(args,check=True):
  nonlocal count
  admit(q);result=commands.exact(PREFIX+args,timeout=30,check=check);count+=1
  need(not commands.client_retirement_unproven,'every actual export client positively joined')
  return result
 def container():
  rows=json.loads(call(['inspect','--type','container',cid]).stdout);need(type(rows)is list and len(rows)==1,'one exact fresh container inspect');info=rows[0]
  need(info['Id']==cid and info['Name']=='/'+q['name'],'exact newly created CID/name')
  api['validate_container'](info,IMAGE,q['nonce'])
  state=info['State'];need(state['Status']=='created' and state['Running'] is False and state['Pid']==0 and not any(state.get(k,False) for k in ('Paused','Restarting','Dead','OOMKilled')),'created-only; no running PID/state')
  labels=dict(b['pinned_image_labels']);labels['mckernel.owner']=q['nonce']
  need(info['Config']['Labels']==labels and info['Config']['Env']==b['pinned_image_env'],'exact inherited metadata plus only explicit fresh owner label')
  return info
 try:
  image_rows=json.loads(call(['image','inspect',IMAGE]).stdout);image=api['validate_image_inspect'](image_rows,IMAGE)
  need(image['Config']['Labels']==b['pinned_image_labels'] and image['Config']['Env']==b['pinned_image_env'],'exact pinned image environment/labels')
  publish('PREPARED.json',dict(operation=q['operation'],nonce=q['nonce'],image=IMAGE,providers=b['selected_provider_manifest'],targets=q['targets'],no_start=True))
  # Same reviewed create args/resource profile; sleep is configured but NEVER started.
  create_attempted=True;result=call(api['create_args'](q['name'],IMAGE,q['nonce']));cid=result.stdout.strip()
  need(re.fullmatch('[0-9a-f]{64}',cid) and cid!=FORBIDDEN_CID,'actual fresh created CID; retired2460 forbidden');created=True
  before=container();publish('CREATED.json',before)
  exported={}
  for key,source,target in FIXED_PROVIDERS:
   call(['cp','-L',cid+':'+source,q['targets'][key]])
   exported[key]=inspect_provider(Path(q['targets'][key]),manifest['providers'][key]);publish('EXPORTED-'+key+'.json',exported[key])
  after=container();need(after['State']==before['State'],'container was never started during export')
  publish('PRE-REMOVE.json',dict(cid=cid,created_only=True,exported=exported))
  result=call(['rm','--',cid]);need(result.returncode==0 and result.stdout.strip()==cid and result.stderr=='','exact owned created-container removal');removed=True
  for query in ('id='+cid,'name=^/'+q['name']+'$'):
   result=call(['ps','--all','--quiet','--no-trunc','--filter',query]);need(result.stdout==result.stderr=='','exact created-container ID/name absence')
  result=dict(status='PASS_CREATED_ONLY_SELECTED_BFD_EXACT_PROVIDER_BYTES_PENDING_PARENT_JOIN_AND_CURRENT',nonce=q['nonce'],cid=cid,image=IMAGE,providers=exported,created_only=True,container_absent=True,command_count=count,signals_sent=0,container_starts=0,builds=0,native_cases=0,owner_parentjoin_and_fresh_current_required=True,SDK_compile_link_or_native_acceptance=False,file_closure=False)
  publish('RESULT.json',result);return result
 except BaseException as exc:
  # No failure cleanup, signals or retry. Root retains its lease/global custody.
  retain_uncertainty(dict(error=repr(exc),cid=cid,create_attempt_may_have_occurred=create_attempted,created_confirmed=created,removed_confirmed=removed,commands_completed=count,signals_sent=0,no_automatic_cleanup_or_retry=True))
  raise
