Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Private selected-BFD ABI successor5aab8a42/32826B is ready for independent review.
It preserves frozen dc0d6f75 ownership guards and all originals/failures/40and56
case evidence. No canonical or frozen joint17/CMake packet was edited. Earlier
wrong-prefix fixtures remain scoped historical HOST mocks, never SDK ABI proof.

All11 BFD imports were checked together against exact selected bfd.hde900a9f.
Corrected declarations: bfd_init returns unsigned; set_format, contents, setters
and close return bool; section-size and section-flags take only(section,value).
Selected flagword/u32, bfd_vma/u64, bfd_size_type/u64, file_ptr/i64 and Cenum32
constants are witnessed. Existing pointer/const/arity declarations for fopen,
perror, make/get-section and close_all_done agree. No new BFD import was added.

ASection is now opaque. Its VMA helper includes genuine generated Rust constants
from MCKERNEL_LDUMP2_BFD_LAYOUT_RS and uses raw writes matching the selected
inline bfd_set_section_vma. Nonshipped section_layout_witness.c includes the
exact header and checks all prototypes/types/constants. It measures actual
asection size280/align8, name0/flags36/VMA48/LMA56/size64, user_set_vma byte40/
mask1. It sets the real packed bit and measures changed bytes, rather than
inventing a bitfield prefix or assuming offsetof on a C bitfield.

HOST header materialization is exact bfd.h from the retained official devel RPM;
ansidecl/symcat/diagnostics dependencies come from the same retained source RPM's
binutils2.41 archive. Their exact bytes are bound in actual INPUTS/contract. No
new libraries, Docker, SDK or real dump were used. Existing bfd_accessors.rs/
BfdRustAccessors.cmake four-xvec pattern is reused for witness/data orchestration;
it does not itself supply these section offsets.

The derivative fixture includes real selected bfd.h and allocates actual header
asection objects. Its BFD callbacks satisfy those real prototypes, including
2argument setters and bool results; no old section mirror remains. At every BFD
call, the entire280B section is compared to a same-header inline-set_vma oracle,
with unrelated pointer/id/section_id/index/packed-field canaries. It retains all
borrowed-name checks, zero-project-allocation checks, explicit mock-handle
ownership, consuming terminal FALSE semantics and original body/data/ACK oracles.

All56 coherent cases pass and preserve their prior56 ACK/read/write/diagnostic/
allocation/handle results. Positive typed C witness compiles/runs; negative old
3argument APIs and old40offset/64byte-prefix assertions each correctly fail
compile1.63direct children are positive wait4 joined:2witness commands,
2expected-negative compiles,1Rust compile,1undefined-symbol inventory,1C fixture
link and56body calls. No unexpected compiler/runtime failure or bounded retry was
needed. Wall0.570905s, childCPU0.497464s, peakRSS105580KiB under CPU0/jobs1,
AS2GiB,CPU60,FSIZE64MiB,CORE0/90s. All exact argv/statuses/stdout/stderr/envelopes/
joins are in actual-selected-header-run-1; both expected failures are preserved.

Ldump2SelectedBfdLayout.FUTURE.cmake is an explicit UNRUN private integration
fragment. It follows the existing native selected-header witness pattern, pins
the known Rocky header/compiler selection for future execution, writes genuine
Rust layout DATA and exports LDUMP2_BFD_LAYOUT_ENV/DEPENDS. Root's future producer
must add that environment and dependencies to the existing full-body Rust object.
The HOST-generated DATA is evidence for this HOST/header fixture only; do not
present it as an actual SDK-GCC14 witness. cleanup_bindings owns future shared
integration and must not edit frozen joint17 or substitute this source without
its actual review/producer dependencies.

Actual selected SDK GCC14 qualification and libbfd.a byte binding remain OPEN.
The selected .so is a linker script; neither that script/header match nor this
HOST callback matrix proves the real selected library implementation, real BFD
heap/descriptor/file cleanup, SDK link, valid crashdump, native or M15 whole-file
acceptance. Source close/name facts remain3db997f0; normal/abort FALSE destroys the
handle, names stay live through final teardown and no terminal call is retried.
ACK-sink errors and repeated real sessions remain outside this matrix.

Next: independent review of the complete11-import/opaque-section correction,
new exact typed C witness/header oracle, generated layout and actual56 results.
Then Root can prepare a coherent future source/CMake consumer successor after
actual SDK provider/compiler bindings and existing runtime controls are ready.
