/* Functional OS fixture: selected header must reject inherited three-arg API. */
#include <bfd.h>
void reject_obsolete_setters(bfd *b,asection *s){
    (void)bfd_set_section_size(b,s,4096);
    (void)bfd_set_section_flags(b,s,SEC_ALLOC);
}
