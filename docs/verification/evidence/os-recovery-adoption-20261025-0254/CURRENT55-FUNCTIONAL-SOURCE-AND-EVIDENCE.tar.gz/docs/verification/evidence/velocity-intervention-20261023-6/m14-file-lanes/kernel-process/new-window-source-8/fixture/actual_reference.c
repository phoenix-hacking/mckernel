/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Actual production header types and original adapters, controlled lifecycle effects.
 */
#include <process.h>
#include <cls.h>
#include <ihk/cpu.h>
extern int printf(const char *, ...);
extern void abort(void);
#define CHECK(test) do { if (!(test)) { printf("FAIL line=%d: %s\n",__LINE__,#test); abort(); } } while (0)
_Static_assert(__builtin_types_compatible_p(__typeof__(&ihk_mc_init_user_process),
    void (*)(ihk_mc_kernel_context_t *, ihk_mc_user_context_t **,void *,unsigned long,unsigned long)),
    "actual context initialization ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&release_address_space),
    void (*)(struct address_space *)), "actual address-space release ABI");
extern const unsigned long SOURCE8_RUST_ABI[12];
static const unsigned long C_ABI[12] = {
    __builtin_offsetof(struct cpu_local_var,resource_set),
    __builtin_offsetof(struct thread,ctx), __builtin_offsetof(struct thread,uctx),
    sizeof(ihk_mc_kernel_context_t), __alignof__(ihk_mc_kernel_context_t),
    sizeof(ihk_mc_user_context_t), __alignof__(ihk_mc_user_context_t),
    sizeof(struct resource_set *), sizeof(struct process *), sizeof(int),
    sizeof(unsigned long), sizeof(void *),
};
struct event { int kind; unsigned long fields[5]; };
static struct event events[4],expected[4];
static int count,expected_count,vm_result;
static struct cpu_local_var cpu;
static struct resource_set resources[2];
static struct address_space spaces[2],*create_result;
static struct process processes[2];
static struct process_vm vms[2];
static struct thread threads[2];
static ihk_mc_user_context_t user_context;
static void record(int kind,unsigned long a,unsigned long b,unsigned long c,
                   unsigned long d,unsigned long e)
{
    CHECK(count<4); events[count++]=(struct event){kind,{a,b,c,d,e}};
}
struct cpu_local_var *fixture_current_cpu(void)
{ record(1,(unsigned long)&cpu,0,0,0,0); return &cpu; }
struct address_space *fixture_create(struct resource_set *res,int slots)
{ record(2,(unsigned long)res,(unsigned long)slots,0,0,0); return create_result; }
void fixture_release(struct address_space *asp)
{ record(3,(unsigned long)asp,0,0,0,0); }
void fixture_init_process(struct process *proc,struct process *parent)
{ record(4,(unsigned long)proc,(unsigned long)parent,0,0,0); }
int fixture_init_vm(struct process *owner,struct address_space *asp,struct process_vm *vm)
{ record(5,(unsigned long)owner,(unsigned long)asp,(unsigned long)vm,0,0); return vm_result; }
void fixture_user_context(ihk_mc_kernel_context_t *ctx,ihk_mc_user_context_t **uctx,
                          void *stack,unsigned long pc,unsigned long sp)
{
    record(6,(unsigned long)ctx,(unsigned long)uctx,(unsigned long)stack,pc,sp);
    *uctx=&user_context;
}
/* The new Rust adapter reaches the unchanged exported architecture ABI. */
void ihk_mc_init_user_process(ihk_mc_kernel_context_t *ctx,ihk_mc_user_context_t **uctx,
                              void *stack,unsigned long pc,unsigned long sp)
{ fixture_user_context(ctx,uctx,stack,pc,sp); }

#undef get_this_cpu_local_var
#define get_this_cpu_local_var fixture_current_cpu
#define create_address_space fixture_create
#define release_address_space fixture_release
#define init_process fixture_init_process
#define init_process_vm fixture_init_vm
#define ihk_mc_init_user_process fixture_user_context
#include "original_bodies.ACTUAL-C.inc"
#undef get_this_cpu_local_var
#undef create_address_space
#undef release_address_space
#undef init_process
#undef init_process_vm
#undef ihk_mc_init_user_process
extern void *process_create_thread_address_space_bridge(int);
extern void process_create_thread_release_address_space_bridge(void *);
extern int process_create_thread_init_process_bridge(void *,void *);
extern int process_create_thread_init_vm_bridge(void *,void *,void *);
extern void process_create_thread_init_user_bridge(void *,unsigned long,unsigned long,unsigned long);

static void save(void)
{
    expected_count=count; for (int i=0;i<count;++i) expected[i]=events[i]; count=0;
}
static void compare(void)
{
    CHECK(count==expected_count);
    for (int i=0;i<count;++i) {
        CHECK(events[i].kind==expected[i].kind);
        for (int j=0;j<5;++j) CHECK(events[i].fields[j]==expected[i].fields[j]);
    }
    count=0;
}
int main(void)
{
    for (int i=0;i<12;++i) { CHECK(C_ABI[i]==SOURCE8_RUST_ABI[i]); printf("ABI row=%d value=%lu\n",i,C_ABI[i]); }
    CHECK(C_ABI[0]==7912);
    int comparisons=0;
    const int slots[]={1,2,4};
    for (int res=0;res<2;++res) for (int n=0;n<3;++n) for (int output=0;output<3;++output) {
        cpu.resource_set=&resources[res]; create_result=output ? &spaces[output-1] : NULL;
        void *result=reference_process_create_thread_address_space_bridge(slots[n]);
        CHECK(result==create_result && count==2 && events[0].kind==1 && events[1].kind==2);
        CHECK(events[1].fields[0]==(unsigned long)&resources[res]); save();
        CHECK(process_create_thread_address_space_bridge(slots[n])==result);
        compare(); ++comparisons;
    }
    for (int asp=0;asp<2;++asp) {
        reference_process_create_thread_release_address_space_bridge(&spaces[asp]);
        CHECK(count==1); save(); process_create_thread_release_address_space_bridge(&spaces[asp]);
        compare(); ++comparisons;
    }
    for (int proc=0;proc<2;++proc) for (int parent=0;parent<2;++parent) {
        CHECK(reference_process_create_thread_init_process_bridge(&processes[proc],&processes[parent])==0);
        CHECK(count==1); save();
        CHECK(process_create_thread_init_process_bridge(&processes[proc],&processes[parent])==0);
        compare(); ++comparisons;
    }
    const int results[]={0,-12,-22};
    for (int proc=0;proc<2;++proc) for (int asp=0;asp<2;++asp)
    for (int vm=0;vm<2;++vm) for (int result=0;result<3;++result) {
        vm_result=results[result];
        CHECK(reference_process_create_thread_init_vm_bridge(&processes[proc],&spaces[asp],&vms[vm])==vm_result);
        CHECK(count==1); save();
        CHECK(process_create_thread_init_vm_bridge(&processes[proc],&spaces[asp],&vms[vm])==vm_result);
        compare(); ++comparisons;
    }
    for (int thread=0;thread<2;++thread) for (int example=0;example<2;++example) {
        unsigned long stack=example ? 0xc000 : 0x8000;
        unsigned long pc=example ? 0x500000 : 0x400000;
        unsigned long sp=example ? 0x7fffe000 : 0x7ffff000;
        threads[thread].uctx=NULL;
        reference_process_create_thread_init_user_bridge(&threads[thread],stack,pc,sp);
        CHECK(threads[thread].uctx==&user_context && count==1);
        CHECK(events[0].fields[0]==(unsigned long)&threads[thread].ctx &&
              events[0].fields[1]==(unsigned long)&threads[thread].uctx);
        save(); threads[thread].uctx=NULL;
        process_create_thread_init_user_bridge(&threads[thread],stack,pc,sp);
        CHECK(threads[thread].uctx==&user_context); compare(); ++comparisons;
    }
    CHECK(comparisons==52);
    printf("PASS actual-original-C/Rust create-thread providers: 52 comparisons, 12 genuine ABI rows, resource/create order, results and raw context/output forwarding\n");
    return 0;
}
