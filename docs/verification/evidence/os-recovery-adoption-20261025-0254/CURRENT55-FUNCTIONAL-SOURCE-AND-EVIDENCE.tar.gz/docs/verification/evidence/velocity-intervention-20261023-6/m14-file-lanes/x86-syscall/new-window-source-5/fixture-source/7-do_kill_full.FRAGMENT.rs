// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Complete public do_kill orchestration, composing the separately retained bodies.
mod f06_full_do_kill_candidate {
    use core::ffi::c_void;
    use core::mem::{align_of, offset_of, size_of, MaybeUninit};
    use core::ptr::{addr_of, null_mut, read_volatile};

    use crate::abi::{AbiListHead, CInt, CLong, CULong, IhkAtomic, McsRwlockLock,
        Process, ProcessHash, SigInfo, Thread, ThreadHash};

    // Actual arch-lock.h struct mcs_rwlock_node under selected !ENABLE_UBSAN.
    // Noirq helpers ignore contents, but keep its actual type geometry/identity.
    #[repr(C, align(64))]
    struct NoirqNode {
        count: IhkAtomic,
        kind: u8,
        locked: u8,
        padding: [u8; 2],
        next: *mut NoirqNode,
    }
    const _: () = {
        assert!(size_of::<NoirqNode>() == 64);
        assert!(align_of::<NoirqNode>() == 64);
        assert!(offset_of!(NoirqNode, count) == 0);
        assert!(offset_of!(NoirqNode, kind) == 4);
        assert!(offset_of!(NoirqNode, locked) == 5);
        assert!(offset_of!(NoirqNode, next) == 8);
    };

    // Exact exported provider ABIs, including nested private source2/source3/
    // corrected-wakeup modules. No new bridge or alternate implementation.
    unsafe extern "C" {
        fn arch_do_kill_prepare_info_result(
            sig: CInt, provided: *mut SigInfo, fallback: *mut SigInfo,
            selected: *mut *mut SigInfo,
        ) -> CInt;
        fn arch_do_kill_process_group_result(
            thread: *mut Thread, pid: CInt, sig: CInt, info: *mut SigInfo,
            ptracecont: CInt, hash: *mut ProcessHash,
        ) -> CInt;
        fn arch_do_kill_process_target_result(
            table: *mut ProcessHash, pid: CInt, mask: CULong,
            hash_node: *mut c_void, update_node: *mut c_void, threads_node: *mut c_void,
            process: *mut *mut Process, thread: *mut *mut Thread,
            pending_lock: *mut *mut McsRwlockLock, pending_head: *mut *mut AbiListHead,
        ) -> CInt;
        fn arch_do_kill_thread_target_result(
            table: *mut ThreadHash, pid: CInt, tid: CInt, sig: CInt,
            node: *mut c_void, update_node: *mut c_void,
            process: *mut *mut Process, thread: *mut *mut Thread,
            pending_lock: *mut *mut McsRwlockLock, pending_head: *mut *mut AbiListHead,
        ) -> CInt;
        fn arch_do_kill_direct_target_gate_result(
            caller: *mut Process, process: *mut Process, thread: *mut Thread,
            sig: CInt, irqstate: CULong, result: *mut CULong,
        ) -> CInt;
        fn arch_do_kill_pending_enqueue_result(
            thread: *mut Thread, head: *mut AbiListHead, mask: CULong, sig: CInt,
            info: *const SigInfo, ptracecont: CInt, doint: *mut CInt,
        ) -> CInt;
        fn arch_do_kill_wakeup_result(
            caller: *mut Thread, target: *mut Thread, process: *mut Process,
            sig: CInt, ptracecont: CInt, mask: CULong, doint: CInt, rc: CInt,
        ) -> CInt;
    }

    #[used]
    #[link_section = "__verbose"]
    static mut ENTER_DEBUG: crate::debug::Ddebug = crate::debug::Ddebug {
        file: concat!(file!(), "\0").as_ptr().cast(),
        func: b"do_kill\0".as_ptr().cast(),
        fmt: core::ptr::null(),
        line_flags: line!() & 0x00ff_ffff,
    };

    /// Existing public architecture signal-delivery entry, with unchanged ABI.
    ///
    /// # Safety
    /// Caller supplies original live current/borrowed thread (or NULL), valid
    /// signal-info bytes/lifetime when nonnull, and the existing CPU resource-set
    /// lifetime/migration contract. Process/thread tables obey genuine lock and
    /// reference ownership. Thread/process links needed after selection retain the
    /// original lifetime assumptions. This implementation intentionally preserves
    /// the Linux-UTI terminal gate's lack of an explicit IRQ restore.
    ///
    /// Defined-domain limits are retained: original C __sigmask(0) shifts by -1,
    /// negative non-sentinel TIDs may index before the hash and INT_MIN PID may
    /// overflow group negation. The corresponding old executions were undefined;
    /// no new acceptance/policy promise for them is made by this port. The wrapping
    /// mask below matches selected x86 shift lowering and is identical to C for
    /// signals 1..64; it must not be treated as proof of original signal0 policy.
    #[no_mangle]
    pub unsafe extern "C" fn do_kill(
        thread: *mut Thread, pid: CInt, tid: CInt, sig: CInt,
        provided: *mut SigInfo, ptracecont: CInt,
    ) -> CULong {
        // SAFETY: retained actual debug metadata; preserve entry diagnostic before
        // snapshots, including potentially externally visible kprintf ordering.
        if unsafe { read_volatile(addr_of!(ENTER_DEBUG.line_flags)) } >> 24 != 0 {
            unsafe {
                super::kprintf(
                    b"do_kill,pid=%d,tid=%d,sig=%d\n\0".as_ptr().cast(), pid, tid, sig,
                );
            }
        }
        // SAFETY: preserve original caller-process snapshot BEFORE current-CPU
        // resource-set and thread/process hash snapshots, even on invalid signal.
        let caller_process = if thread.is_null() {
            null_mut()
        } else {
            unsafe { (*thread).proc }
        };
        let (thread_hash, process_hash) = unsafe {
            let resource = (*super::get_this_cpu_local_var()).resource_set;
            ((*resource).thread_hash, (*resource).process_hash)
        };
        let mut fallback = MaybeUninit::<SigInfo>::uninit();
        let mut info = provided;
        // SAFETY: the entire original caller-frame lifetime is now this Rust frame;
        // info fallback remains alive across all synchronous recursive deliveries.
        let rc = unsafe {
            arch_do_kill_prepare_info_result(sig, provided, fallback.as_mut_ptr(), &mut info)
        };
        if rc != 0 {
            return rc as CLong as CULong;
        }
        if tid == -1 && pid <= 0 {
            // SAFETY: same resource snapshot and initialized or borrowed info;
            // group provider dispatches back to THIS public entry after unlock.
            return unsafe {
                arch_do_kill_process_group_result(thread, pid, sig, info, ptracecont, process_hash)
            } as CLong as CULong;
        }
        // SAFETY: existing privileged endpoint and original saved IRQ ownership.
        let irqstate = unsafe { super::cpu_disable_interrupt_save() };
        let mask = 1u64.wrapping_shl(sig.wrapping_sub(1) as u32);
        let mut process: *mut Process = null_mut();
        let mut target: *mut Thread = null_mut();
        let mut pending_lock: *mut McsRwlockLock = null_mut();
        let mut pending_head: *mut AbiListHead = null_mut();
        let mut node = MaybeUninit::<NoirqNode>::uninit();
        let mut update_node = MaybeUninit::<NoirqNode>::uninit();
        let rc = if tid == -1 {
            let mut hash_node = MaybeUninit::<NoirqNode>::uninit();
            // SAFETY: three distinct original node roles, retained until all three
            // actual noirq guards are released. Outputs are distinct stack locals.
            unsafe {
                arch_do_kill_process_target_result(
                    process_hash, pid, mask, hash_node.as_mut_ptr().cast(),
                    update_node.as_mut_ptr().cast(), node.as_mut_ptr().cast(),
                    &mut process, &mut target, &mut pending_lock, &mut pending_head,
                )
            }
        } else {
            // SAFETY: individual-TID provider deliberately reuses node for outer
            // hash and inner threads lock, matching original C and actual noirq ABI.
            unsafe {
                arch_do_kill_thread_target_result(
                    thread_hash, pid, tid, sig, node.as_mut_ptr().cast(),
                    update_node.as_mut_ptr().cast(), &mut process, &mut target,
                    &mut pending_lock, &mut pending_head,
                )
            }
        };
        if rc != 0 {
            // SAFETY: selection returned with all locks released and no target ref.
            unsafe { super::cpu_restore_interrupt(irqstate) };
            return rc as CLong as CULong;
        }
        let mut terminal_result = 0;
        // SAFETY: gate consumes any held target reference only on its terminal
        // branches; otherwise it leaves reference and disabled IRQ ownership here.
        if unsafe {
            arch_do_kill_direct_target_gate_result(
                caller_process, process, target, sig, irqstate, &mut terminal_result,
            )
        } != 0 {
            return terminal_result;
        }
        let mut doint = 0;
        let mut pending_node = MaybeUninit::<NoirqNode>::uninit();
        // SAFETY: continuing gate guarantees live held target and selected pending
        // lock/head. The exact writer critical section wraps only pending enqueue;
        // unlock precedes IRQ restore, which precedes scheduler/notification/IPI.
        let rc = unsafe {
            crate::lock_helpers::__mcs_rwlock_writer_lock_noirq(
                pending_lock.cast(), pending_node.as_mut_ptr().cast(),
            );
            let rc = arch_do_kill_pending_enqueue_result(
                target, pending_head, mask, sig, info, ptracecont, &mut doint,
            );
            crate::lock_helpers::__mcs_rwlock_writer_unlock_noirq(
                pending_lock.cast(), pending_node.as_mut_ptr().cast(),
            );
            super::cpu_restore_interrupt(irqstate);
            rc
        };
        // SAFETY: full tail consumes target exactly once after all effects, even
        // when enqueue failed. No target pointer or pending-node access follows.
        (unsafe {
            arch_do_kill_wakeup_result(thread, target, process, sig, ptracecont, mask, doint, rc)
        }) as CLong as CULong
    }
}
