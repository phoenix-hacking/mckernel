// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// SOURCE ONLY. Current original C entry delegates to the genuine existing Rust
// backend. Failed node-copy tests run only the separately selected Rust successor.
#![allow(dead_code)]
use core::ffi::c_void;
use core::mem::{size_of, MaybeUninit};
use core::ptr::{addr_of_mut, null_mut, read_volatile};
use std::sync::{Mutex, atomic::{AtomicPtr, Ordering}};
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt, CLong, CULong, CpuSet, MovePagesSmpReq, ProcessVm, SizeT, X86UserContext};
const EINVAL:CInt=22;
const EFAULT:CInt=14;
const ENOMEM:CInt=12;
const ENODEV:CInt=19;
const MPOL_MF_MOVE:CInt=2;
const MPOL_MF_MOVE_ALL:CInt=4;
const IHK_MC_AP_NOWAIT:CULong=2;
const MOVE_PAGES_LOG_UNSUPPORTED_PID:CInt=1;
const MOVE_PAGES_LOG_UNSUPPORTED_MOVE_ALL:CInt=2;
const MOVE_PAGES_LOG_INIT_MALLOC:CInt=3;
const MOVE_PAGES_LOG_INIT_VERIFY:CInt=4;
const MOVE_PAGES_LOG_PARALLEL:CInt=5;
include!("callbacks.ACTUAL-RUST.rs.inc");
include!("backend.ACTUAL-RUST.rs.inc");
include!("getters.ACTUAL-RUST.rs.inc");
unsafe extern "C" {
 fn original_sys_move_pages(n:CInt,ctx:*mut X86UserContext)->CLong;
 fn kprintf(format:*const i8,...)->CInt;
 fn mmap(address:*mut c_void,length:usize,protection:i32,flags:i32,fd:i32,offset:i64)->*mut c_void;
 fn mprotect(address:*mut c_void,length:usize,protection:i32)->i32;
 fn munmap(address:*mut c_void,length:usize)->i32;
}
static CURRENT:AtomicPtr<abi::CpuLocalVar>=AtomicPtr::new(null_mut());
#[no_mangle]
pub unsafe extern "C" fn get_this_cpu_local_var()->*mut abi::CpuLocalVar {CURRENT.load(Ordering::Relaxed)}
unsafe fn current_thread_ptr()->*mut abi::Thread {(*get_this_cpu_local_var()).current}
mod x86_cpu_helpers {
 pub use super::{ihk_mc_syscall_arg0,ihk_mc_syscall_arg1,ihk_mc_syscall_arg2,
     ihk_mc_syscall_arg3,ihk_mc_syscall_arg4,ihk_mc_syscall_arg5};
 pub unsafe extern "C" fn rdtsc()->u64 {super::syscall_rdtsc_bridge()}
}
mod x86_memory_helpers {
 pub unsafe fn verify_process_vm(vm:*mut super::abi::ProcessVm,p:*const core::ffi::c_void,n:usize)->i32 {
     super::fixture_verify(vm,p,n)
 }
}
mod spinlock_helpers {
 pub unsafe fn __ihk_mc_spinlock_lock_noirq(p:*mut super::abi::IhkSpinlock){super::fixture_lock(1,p.cast())}
 pub unsafe fn __ihk_mc_spinlock_unlock_noirq(p:*mut super::abi::IhkSpinlock){super::fixture_lock(2,p.cast())}
}
mod ap {
 pub unsafe fn smp_call_func(p:*mut super::abi::CpuSet,f:Option<super::MovePagesSmpHandlerFn>,a:*mut core::ffi::c_void)->i32 {
     super::fixture_smp(p,f,a)
 }
}
include!("candidate.FROZEN.rs.inc");
#[derive(Clone,Debug,PartialEq,Eq)]
struct Observation { events:Vec<(u8,[u64;4])>, formats:Vec<Vec<u8>>, allocations:usize,
    verifies:usize,node_counts:usize,copy_from:usize,copy_to:usize,smp:usize,handlers:usize,
    freed_nonnull:usize,freed_null:usize,protected_nodes:usize }
#[derive(Clone)]
struct Case { name:&'static str,pid:i32,flags:i32,count:usize,query:bool,nodes:[i32;2],
    fail_alloc:usize,fail_verify:usize,smp_error:i32,status_copy_error:i64,
    node_copy_error:i64,partial_node_bytes:usize,expected_rc:i64 }
struct Slot {pointer:usize,logical:usize,freed:bool}
struct State {case:Case,observed:Observation,slots:Vec<Slot>,locked:bool,tick:u64,
    vm:usize,lock:usize,cpus:usize,proc:usize,user_addresses:usize,user_nodes:usize,user_status:usize}
static STATE:Mutex<Option<State>>=Mutex::new(None);
fn state<T>(f:impl FnOnce(&mut State)->T)->T {f(STATE.lock().unwrap().as_mut().unwrap())}
fn event(s:&mut State,tag:u8,a:u64,b:u64,c:u64,d:u64){s.observed.events.push((tag,[a,b,c,d]));}
fn slot(s:&State,p:usize)->usize {if p==0{0}else{s.slots.iter().position(|b|b.pointer==p).expect("owned allocation")+1}}
#[no_mangle]
pub unsafe extern "C" fn syscall_alloc_bridge(n:usize,flags:u64)->*mut c_void {state(|s|{
 s.observed.allocations+=1;let id=s.observed.allocations;assert_eq!(flags,2);
 let widths=[8,4,4,4,8,8];assert!(id<=6);assert_eq!(n,widths[id-1]*s.case.count);
 event(s,1,id as u64,n as u64,flags,0);
 if s.case.fail_alloc==id{return null_mut();}
 assert!(n<=4096);let p=mmap(null_mut(),4096,3,0x22,-1,0);assert_ne!(p as usize,usize::MAX);
 // Fresh mapped storage has a valid lifetime but no node-input ownership yet.
 core::ptr::write_bytes(p.cast::<u8>(),0xcc,4096);
 s.slots.push(Slot{pointer:p as usize,logical:n,freed:false});p
})}
#[no_mangle]
pub unsafe extern "C" fn syscall_mckfd_free_bridge(p:*mut c_void){state(|s|{
 assert!(!s.locked);let id=slot(s,p as usize);event(s,2,id as u64,0,0,0);
 if id==0{s.observed.freed_null+=1;return;}
 let at=&mut s.slots[id-1];assert!(!at.freed,"allocation freed twice");at.freed=true;
 assert_eq!(munmap(p,4096),0);s.observed.freed_nonnull+=1;
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_verify(vm:*mut ProcessVm,p:*const c_void,n:usize)->i32{state(|s|{
 assert!(!s.locked);assert_eq!(vm as usize,s.vm);s.observed.verifies+=1;
 let kind=if p as usize==s.user_addresses{1}else if p as usize==s.user_nodes{2}else{assert_eq!(p as usize,s.user_status);3};
 assert_eq!(n,if kind==1{8*s.case.count}else{4*s.case.count});event(s,3,kind,n as u64,0,0);
 if s.case.fail_verify==s.observed.verifies{-1}else{0}
})}
#[no_mangle]
pub unsafe extern "C" fn syscall_copy_from_user_bridge(dst:*mut u8,src:u64,n:usize)->i64{state(|s|{
 assert!(!s.locked);assert_eq!(src as usize,s.user_nodes);assert_eq!(slot(s,dst as usize),3);
 assert_eq!(n,4*s.case.count);s.observed.copy_from+=1;
 let copy_error=s.case.node_copy_error;let partial_bytes=s.case.partial_node_bytes;
 event(s,4,n as u64,copy_error as u64,partial_bytes as u64,0);
 if s.case.node_copy_error!=0 {
  assert!(cfg!(f03_move_pages_copy_error_candidate),"failed copy never reaches legacy/C lane");
  let copied=s.case.partial_node_bytes.min(n);core::ptr::copy_nonoverlapping(src as *const u8,dst,copied);
  // Any actual node read after this return would fault before reclamation. This
  // is a functional lifetime/read-initialization oracle, not a native OS claim.
  assert_eq!(mprotect(dst.cast(),4096,0),0);s.observed.protected_nodes+=1;
  s.case.node_copy_error
 }else{core::ptr::copy_nonoverlapping(src as *const u8,dst,n);0}
})}
#[no_mangle]
pub unsafe extern "C" fn ihk_mc_get_nr_numa_nodes()->i32{state(|s|{
 assert_eq!(s.case.node_copy_error,0,"no node parse/count after failed copy");
 s.observed.node_counts+=1;event(s,5,4,0,0,0);4
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_lock(kind:i32,p:*mut c_void){state(|s|{
 assert_eq!(p as usize,s.lock);match kind{1=>{assert!(!s.locked);s.locked=true;},2=>{assert!(s.locked);s.locked=false;},_=>panic!("lock event")};event(s,6,kind as u64,0,0,0);
})}
#[no_mangle]
pub unsafe extern "C" fn move_pages_smp_handler(cpu:i32,ncpus:i32,arg:*mut c_void)->i32{state(|s|{
 assert!(s.locked);assert_eq!((cpu,ncpus),(0,1));let r=&mut *arg.cast::<MovePagesSmpReq>();
 assert_eq!(r.count,s.case.count as u64);assert_eq!(r.user_virt_addr as usize,s.user_addresses);
 assert_eq!(r.user_nodes as usize,if s.case.query{0}else{s.user_nodes});assert_eq!(r.user_status as usize,s.user_status);
 assert_eq!(r.proc as usize,s.proc);assert_eq!(r.nodes_ready,0);assert_eq!(r.phase_done.counter,0);assert_eq!(r.phase_ret,0);
 for (id,p) in [(1,r.virt_addr as usize),(2,r.nr_pages as usize),(3,r.nodes as usize),(4,r.status as usize),(5,r.ptep as usize),(6,r.dst_phys as usize)]{assert_eq!(slot(s,p),id);}
 for i in 0..s.case.count{r.status.add(i).write(2+i as i32);}
 s.observed.handlers+=1;event(s,8,cpu as u64,ncpus as u64,r.count,0);0
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_smp(cpus:*mut CpuSet,handler:Option<MovePagesSmpHandlerFn>,arg:*mut c_void)->i32 {
 let rc=state(|s|{assert!(s.locked);assert_eq!(cpus as usize,s.cpus);assert_eq!(handler.unwrap() as usize,move_pages_smp_handler as *const () as usize);s.observed.smp+=1;let count=s.case.count;let error=s.case.smp_error;event(s,7,count as u64,error as u64,0,0);error});
 if rc!=0{rc}else{handler.unwrap()(0,1,arg)}
}
#[no_mangle]
pub unsafe extern "C" fn syscall_copy_to_user_bridge(dst:u64,src:*const u8,n:usize)->i64{state(|s|{
 assert!(!s.locked,"status copy must follow unlock");assert_eq!(dst as usize,s.user_status);assert_eq!(slot(s,src as usize),4);
 assert_eq!(n,4*s.case.count);s.observed.copy_to+=1;let error=s.case.status_copy_error;event(s,9,n as u64,error as u64,0,0);
 if s.case.status_copy_error!=0{s.case.status_copy_error}else{core::ptr::copy_nonoverlapping(src,dst as *mut u8,n);0}
})}
#[no_mangle]
pub unsafe extern "C" fn syscall_rdtsc_bridge()->u64{state(|s|{s.tick+=10;s.tick})}
#[no_mangle]
pub unsafe extern "C" fn fixture_format(p:*const i8,n:usize){state(|s|{s.observed.formats.push(core::slice::from_raw_parts(p.cast(),n).to_vec());})}
unsafe fn zero<T>()->*mut T{let p=std::alloc::alloc_zeroed(std::alloc::Layout::new::<T>()).cast::<T>();assert!(!p.is_null());p}
fn make_observation()->Observation{Observation{events:Vec::new(),formats:Vec::new(),allocations:0,verifies:0,node_counts:0,copy_from:0,copy_to:0,smp:0,handlers:0,freed_nonnull:0,freed_null:0,protected_nodes:0}}
fn main(){unsafe{
 let cpu=zero::<abi::CpuLocalVar>();let thread=zero::<abi::Thread>();let vm=zero::<ProcessVm>();let proc=zero::<abi::Process>();(*cpu).current=thread;(*thread).vm=vm;(*thread).proc=proc;CURRENT.store(cpu,Ordering::Relaxed);
 let base=Case{name:"success",pid:0,flags:2,count:2,query:false,nodes:[0,1],fail_alloc:0,fail_verify:0,smp_error:0,status_copy_error:0,node_copy_error:0,partial_node_bytes:0,expected_rc:0};
 let mut normal=vec![base.clone()];
 for (name,pid,flags) in [("other-pid",1,2),("move-all",0,4),("unknown-flags",0,8)]{let mut c=base.clone();c.name=name;c.pid=pid;c.flags=flags;c.expected_rc=-22;normal.push(c);}
 for fail in 1..=6{let mut c=base.clone();c.name="allocation-failure";c.fail_alloc=fail;c.expected_rc=-12;normal.push(c);}
 for fail in 1..=3{let mut c=base.clone();c.name="verify-failure";c.fail_verify=fail;c.expected_rc=-14;normal.push(c);}
 for nodes in [[0,-1],[0,4]]{let mut c=base.clone();c.name="node-range";c.nodes=nodes;c.expected_rc=-19;normal.push(c);}
 for (name,query,count) in [("query",true,2),("empty-query",true,0),("one-node",false,1)]{let mut c=base.clone();c.name=name;c.query=query;c.count=count;normal.push(c);}
 let mut c=base.clone();c.name="smp-error";c.smp_error=-5;c.expected_rc=-5;normal.push(c);
 let mut c=base.clone();c.name="status-copy-error";c.status_copy_error=-14;c.expected_rc=-14;normal.push(c);
 let mut run=|case:&Case,original:bool| {
  assert!(!original||case.node_copy_error==0,"never execute old uninitialized-node path");
  let addresses=[0x4000u64,0x8000];let nodes=case.nodes;let mut status=[-99i32;2];
  let mut ctx:X86UserContext=core::mem::zeroed();ctx.gpr.rdi=case.pid as u64;ctx.gpr.rsi=case.count as u64;ctx.gpr.rdx=addresses.as_ptr() as u64;ctx.gpr.r10=if case.query{0}else{nodes.as_ptr() as u64};ctx.gpr.r8=status.as_mut_ptr() as u64;ctx.gpr.r9=case.flags as u64;
  *STATE.lock().unwrap()=Some(State{case:case.clone(),observed:make_observation(),slots:Vec::new(),locked:false,tick:100,vm:vm as usize,lock:core::ptr::addr_of_mut!((*vm).page_table_lock) as usize,cpus:core::ptr::addr_of_mut!((*thread).cpu_set) as usize,proc:proc as usize,user_addresses:addresses.as_ptr() as usize,user_nodes:nodes.as_ptr() as usize,user_status:status.as_mut_ptr() as usize});
  let rc=if original{original_sys_move_pages(279,&mut ctx)}else{f03_move_pages_candidate::sys_move_pages(279,&mut ctx)};
  assert_eq!(rc,case.expected_rc,"case {}",case.name);
  let obs=state(|s|{assert!(!s.locked);assert!(s.slots.iter().all(|p|p.freed));assert_eq!(s.observed.freed_nonnull,s.slots.len());s.observed.clone()});
  if rc==0{for i in 0..case.count{assert_eq!(status[i],2+i as i32);}for i in case.count..2{assert_eq!(status[i],-99);}}else{assert_eq!(status,[-99;2]);}
  if case.node_copy_error!=0{assert_eq!((obs.allocations,obs.copy_from,obs.freed_nonnull),(6,1,6));assert_eq!((obs.protected_nodes,obs.node_counts,obs.smp,obs.handlers,obs.copy_to),(1,0,0,0,0));}
  (obs,status,rc)
 };
 let mut parity=0;for case in &normal{let reference=run(case,true);let candidate=run(case,false);assert_eq!(candidate,reference,"case {}",case.name);parity+=1;}
 let mut corrected_only=0;
 if cfg!(f03_move_pages_copy_error_candidate){for bytes in [0,1,4,7]{for error in [-14,-5,1]{let mut c=base.clone();c.name="failed-node-copy-guarded";c.node_copy_error=error;c.partial_node_bytes=bytes;c.expected_rc=-14;run(&c,false);corrected_only+=1;}}}
 println!("PASS move_pages actual C-entry/Rust defined-domain parity {parity} cases; independent guarded Rust copy-failure cases {corrected_only}");
}}
