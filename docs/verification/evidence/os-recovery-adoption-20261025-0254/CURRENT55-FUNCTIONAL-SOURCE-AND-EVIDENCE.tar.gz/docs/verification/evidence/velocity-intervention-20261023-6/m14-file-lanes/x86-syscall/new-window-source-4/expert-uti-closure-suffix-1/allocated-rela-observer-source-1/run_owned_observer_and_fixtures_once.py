"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Root granted three genuine fixture cases and one retained-object observer. CPU0.
"""
from pathlib import Path
import ast,builtins,dis,hashlib,json,os,resource,signal,time
D=Path(__file__).resolve().parent;P=D/'EXACT-ALLOCATED-RELA-OBSERVER.NOT-GRANTED.json'
EXPECTED='b63b4c985d36a43f68354e977f1db46631fe3fa4ae2872d902b700508cc1a66c'
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py');raw=H.read_bytes();need(hashlib.sha256(raw).hexdigest()=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8','h990')
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'};assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(raw,str(H)).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
ns={'__file__':str(H)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(H),'exec'),ns)
def globals_used(code):
 used={i.argval for i in dis.get_instructions(code) if i.opname=='LOAD_GLOBAL'}
 for v in code.co_consts:
  if isinstance(v,type(code)):used.update(globals_used(v))
 return used
used=set()
for name in functions:used.update(globals_used(ns[name].__code__))
need(not used-set(ns)-set(vars(builtins)),'helper globals')
need(os.getuid()==os.geteuid()==1000,'ordinary uid');need(pin(P)['sha256']==EXPECTED,'exact root granted manifest')
m=json.loads(P.read_text());F=D/'fixture-proposal';proposal=json.loads((F/'GENUINE-FIXTURE-PROPOSAL.NOT-RUN.json').read_text())
A=D/'actual-observer-attempt-1';O=A/'output';C=A/'capture';need(not A.exists() and not Path(m['result_path']).exists(),'fresh fixture/output/retained result');A.mkdir(mode=0o700);C.mkdir(mode=0o700)
rows=[];failure=None;cases=[];retained=None;start=time.monotonic()
try:
 ns['write'](C/'ROOT-GRANT.json',dict(scope=__doc__,source='Parent collaboration current invocation',manifest_sha256=EXPECTED,observer_sha256='e714ec9247ca187c00feaee8d158ad13a702162266eb5cf97302f46b74f1fac0',CPU_assignment=0,limits='1job AS2GiB CPU30 wall45+6 FSIZE32MiB FD256 stack2MiB core0',allowed='3genuine AS/ld fixture cases + exact retained4object observer, no prefixrecompile or dump',semantics='Only named8 allocated RELA scope, anonymous/fullbehavior/currentunion OPEN'))
 for row in m['inputs']+[m['accepted_primitives'],m['observer']]+proposal['sources']:
  need(pin(row['path'])==row,'frozen observer/object/fixture '+row['path'])
 compile(Path(m['observer']['path']).read_text(),m['observer']['path'],'exec')
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024;h=os.statvfs('/home/holden/mckernel-work');s=os.statvfs('/home/holden/mckernel-work/scratch')
 cap=dict(MemAvailable=mem,HOST_available=h.f_frsize*h.f_bavail,scratch_available=s.f_frsize*s.f_bavail);ns['write'](C/'CAPACITY.json',cap);need(mem>=2<<30 and cap['HOST_available']>=(16<<30)+(128<<20) and cap['scratch_available']>=(12<<30)+(128<<20),'ordinary floors')
 O.mkdir(mode=0o700);os.chdir(D);os.sched_setaffinity(0,{0})
 for sig in ns['STOP_SIGNALS']:signal.signal(sig,ns['stop'])
 for lim,val in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,30),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_STACK,2<<20),(resource.RLIMIT_CORE,0)]:resource.setrlimit(lim,(val,val))
 signal.setitimer(signal.ITIMER_REAL,51)
 def command(label,argv,expected_rc=0):
  remaining=45-(time.monotonic()-start);need(remaining>0 and ns['cpu_used']()<30,'shared CPU/wall budget')
  out=C/str(len(rows)).zfill(2);out.mkdir(mode=0o700);cmd=dict(name=label,argv=argv);ns['write'](out/'command.json',cmd)
  result=ns['owned_capture'](cmd,out,remaining,lambda:None);ns['write'](out/'RESULT.json',result);rows.append(dict(name=label,capture=str(out),result=result))
  need(result['returncode']==expected_rc and result['direct_child_joined'] and result['group_absent'] and result['closed_streams'] and result['error'] is None and result['retirement_error'] is None and not result['timed_out'],'unexpected '+label)
  need(result['captures']['stderr']['size']==0,'unexpected stderr '+label)
  return out
 # Genuine as/ld commands from the unchanged proposed source recipe, with fresh
 # outputs bound before each observer call. No fixture instruction executes.
 commands=proposal['commands']
 for i,c in enumerate(commands):command('fixture-build-'+str(i),[arg.replace('<fresh>',str(O)) for arg in c])
 variants=[('positive','provider.o','positive-partial.o',0,None),('missing','missing-provider.o','missing-partial.o',1,'ValueError: unique global function arch_do_kill_wakeup_result'),('nonallocated','nonallocated-provider.o','nonallocated-partial.o',1,'ValueError: allocated executable nonempty provider arch_do_kill_wakeup_result')]
 for name,provider,partial,rc,error in variants:
  case=O/name;case.mkdir(mode=0o700);observer=case/'observe_allocated_providers.py';observer.write_bytes(Path(m['observer']['path']).read_bytes())
  desc=dict(m);desc['observer']=pin(observer);desc['objects']=dict(Rust=str(O/provider),kernel_C=str(O/'consumer.o'),arch_C=str(O/'empty.o'),partial=str(O/partial));desc['inputs']=[pin(p) for p in desc['objects'].values()];desc['result_path']=str(case/'ALLOCATED-RELA-RESULT.json');ns['write'](case/'EXACT-ALLOCATED-RELA-OBSERVER.NOT-GRANTED.json',desc)
  command('fixture-observer-'+name,['/home/holden/anaconda3/bin/python3',str(observer)],rc)
  result=json.loads(Path(desc['result_path']).read_text());need((result.get('error')==error) if error else result['status']=='PASS_EXACT_PRIVATE_EIGHT_PROVIDERS_ALLOCATED_RELA_ONLY','exact fixture semantic outcome '+name)
  if not error:need(sum(g['excluded_nonallocated_relocations'] for g in result['geometry'].values())>=2,'positive real debug exclusion')
  cases.append(dict(name=name,expected_returncode=rc,actual_result=pin(Path(desc['result_path'])),error=result.get('error')))
 command('retained-four-object-observer',m['proposed_argv'])
 retained=json.loads(Path(m['result_path']).read_text());need(retained['status']=='PASS_EXACT_PRIVATE_EIGHT_PROVIDERS_ALLOCATED_RELA_ONLY','exact retained allocated RELA success')
 for row in m['inputs']+[m['accepted_primitives'],m['observer']]+proposal['sources']:need(pin(row['path'])==row,'post immutable input '+row['path'])
 need(ns['cpu_used']()<=30,'whole CPU cap')
except BaseException as exc:failure=type(exc).__name__+': '+str(exc)
finally:signal.setitimer(signal.ITIMER_REAL,0)
joined=all(r['result']['direct_child_joined'] and r['result']['group_absent'] and r['result']['closed_streams'] for r in rows)
report=dict(scope=__doc__,status='PASS_THREE_GENUINE_FIXTURES_AND_RETAINED_ALLOCATED_RELA_ONLY' if failure is None else 'FAIL_STOP_FIRST_UNEXPECTED_PRESERVE_NO_RETRY',manifest=pin(P),driver=pin(Path(__file__)),commands=rows,error=failure,fixture_cases=cases,retained_result=pin(Path(m['result_path'])) if Path(m['result_path']).exists() else None,seconds=time.monotonic()-start,CPU_seconds=ns['cpu_used'](),CPU_assignment=0,CPU0_released=joined,whole_joined_group_absent_closed=joined,Rust_C_prefix_recompilations=0,current_union=False,full_behavior_native=False)
ns['write'](C/'ACTUAL-WHOLE-JOIN.json',report);print(json.dumps(dict(status=report['status'],commands=len(rows),fixture_cases=len(cases),error=failure,seconds=report['seconds'],CPU_seconds=report['CPU_seconds'],CPU0_released=joined),sort_keys=True));raise SystemExit(0 if failure is None else 1)
