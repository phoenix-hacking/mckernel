// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private isolated positive-PID process target selection; not yet compiler tested.
mod f06_do_kill_process_target_candidate {
    use core::ffi::c_void;
    use core::mem::offset_of;
    use core::ptr::{addr_of_mut, null_mut};

    use crate::abi::{AbiListHead, CInt, CULong, McsRwlockLock, Process, ProcessHash,
        SigCommon, Thread};

    use super::{ESRCH, PS_EXITED, PS_ZOMBIE};

    /// Select the original process-directed do_kill target under the actual locks.
    /// Return -ESRCH only for absent PID; otherwise return zero, including an
    /// exited/zombie process or process with no eligible thread. IRQs stay disabled.
    ///
    /// # Safety
    /// Caller enters the existing tid==-1, pid>0 branch with IRQs disabled. `table`
    /// is the original live resource-set process hash. Its circular lists and
    /// process/thread membership obey existing hash/update/threads lock ownership.
    /// The three node pointers designate distinct original C stack lock nodes,
    /// alive until corresponding noirq unlock; actual noirq helpers ignore their
    /// contents. Output slots are valid writable distinct C locals with no alias
    /// into traversed graph. The target/lock/head slots initially contain NULL.
    /// The held target reference transfers to the original caller's gate/enqueue/
    /// wakeup/release path; no process or list lock escapes this function.
    #[no_mangle]
    pub unsafe extern "C" fn arch_do_kill_process_target_result(
        table: *mut ProcessHash,
        pid: CInt,
        mask: CULong,
        hash_node: *mut c_void,
        update_node: *mut c_void,
        threads_node: *mut c_void,
        selected_process: *mut *mut Process,
        selected_thread: *mut *mut Thread,
        pending_lock: *mut *mut McsRwlockLock,
        pending_head: *mut *mut AbiListHead,
    ) -> CInt {
        let hash = crate::process_helpers::process_hash(pid) as usize;
        // SAFETY: actual process_hash returns a valid index for the positive PID;
        // raw array pointers preserve genuine ABI lock/list strides without a
        // reference spanning a lock or externally visible lifecycle operation.
        let (hash_lock, head) = unsafe {
            (
                addr_of_mut!((*table).lock).cast::<McsRwlockLock>().add(hash),
                addr_of_mut!((*table).list).cast::<AbiListHead>().add(hash),
            )
        };
        // SAFETY: borrowed hash lock and node satisfy original noirq contract.
        unsafe {
            crate::lock_helpers::__mcs_rwlock_reader_lock_noirq(hash_lock.cast(), hash_node);
        }
        let mut process: *mut Process = null_mut();
        // SAFETY: hash lock protects membership throughout this traversal. Only
        // non-sentinel entries are converted to the containing Process pointer.
        unsafe {
            let mut entry = (*head).next;
            while entry != head {
                let candidate = entry.cast::<u8>().sub(offset_of!(Process, hash_list))
                    .cast::<Process>();
                if (*candidate).pid == pid {
                    process = candidate;
                    break;
                }
                entry = (*entry).next;
            }
        }
        if process.is_null() {
            // SAFETY: match original absent-PID unlock before caller restores IRQs.
            unsafe {
                crate::lock_helpers::__mcs_rwlock_reader_unlock_noirq(
                    hash_lock.cast(), hash_node,
                );
            }
            return -ESRCH;
        }
        // SAFETY: process remains protected by hash membership; output reflects
        // original tproc even if its status below makes target selection terminal.
        let update_lock = unsafe {
            *selected_process = process;
            addr_of_mut!((*process).update_lock)
        };
        unsafe {
            // SAFETY: acquire process update lock inside retained hash lock.
            crate::lock_helpers::__mcs_rwlock_reader_lock_noirq(
                update_lock.cast(), update_node,
            );
        }
        // SAFETY: status read remains inside original process update lock scope.
        if unsafe { (*process).status != PS_EXITED && (*process).status != PS_ZOMBIE } {
            // SAFETY: process and thread-membership list remain live under the
            // outer hash/update guards; thread list gets its own original guard.
            let (threads_lock, threads_head) = unsafe {
                (addr_of_mut!((*process).threads_lock), addr_of_mut!((*process).threads_list))
            };
            unsafe {
                // SAFETY: same third original stack node, no recursive node alias.
                crate::lock_helpers::__mcs_rwlock_reader_lock_noirq(
                    threads_lock.cast(), threads_node,
                );
            }
            let mut target: *mut Thread = null_mut();
            let mut masked_fallback: *mut Thread = null_mut();
            // SAFETY: threads lock protects intrusive membership until hold_thread
            // obtains original retained ownership; sigmask/status use the original
            // locked plain reads. No new status/permission policy is introduced.
            unsafe {
                let mut entry = (*threads_head).next;
                while entry != threads_head {
                    let candidate = entry.cast::<u8>().sub(offset_of!(Thread, siblings_list))
                        .cast::<Thread>();
                    if ((*candidate).tid == pid || target.is_null())
                        && (*candidate).status != PS_EXITED
                    {
                        if mask & (*candidate).sigmask.val[0] == 0 {
                            target = candidate;
                        } else if target.is_null() && masked_fallback.is_null() {
                            masked_fallback = candidate;
                        }
                    }
                    entry = (*entry).next;
                }
                if target.is_null() {
                    target = masked_fallback;
                }
                if !target.is_null() && (*target).status != PS_EXITED {
                    let common = (*target).sigcommon.cast::<SigCommon>();
                    *pending_lock = addr_of_mut!((*common).lock);
                    *pending_head = addr_of_mut!((*common).sigpending);
                    // The selected process branch ignores hold_thread's int result,
                    // exactly as original C; do not borrow direct-TID error policy.
                    let _ = crate::process_helpers::hold_thread(target);
                    *selected_thread = target;
                } else {
                    *selected_thread = null_mut();
                }
                crate::lock_helpers::__mcs_rwlock_reader_unlock_noirq(
                    threads_lock.cast(), threads_node,
                );
            }
        }
        // SAFETY: release in reverse original order. The caller receives only
        // output pointers and any held thread reference, never a held lock/node.
        unsafe {
            crate::lock_helpers::__mcs_rwlock_reader_unlock_noirq(
                update_lock.cast(), update_node,
            );
            crate::lock_helpers::__mcs_rwlock_reader_unlock_noirq(hash_lock.cast(), hash_node);
        }
        0
    }
}
