/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Controlled whole-entry functional parity. No actual scheduler/IPI, task teardown,
 * credential variation, Linux-UTI, fork/ACK, physical allocation or guest execution.
 */
#include <types.h>
#include <affinity.h>
#include <process.h>
#include <syscall.h>
#include <cls.h>
#include <kmalloc.h>
#include <errno.h>
#include <string.h>
#include <ihk/debug.h>
extern int printf(const char *,...);
extern unsigned long fixture_original_do_kill(struct thread *,int,int,int,siginfo_t *,int);
extern size_t fixture_whole_abi(size_t);
extern void fixture_reset_genuine_arena(void);
extern size_t fixture_genuine_free_bytes(void);
extern struct ddebug __start___verbose[],__stop___verbose[];
#define NP 3
#define NT 6
#define MAX_EVENTS 2048
#define MAX_PENDING 4
struct event {int kind,a,b,c,irq,locks,refs;};
struct pending_row {unsigned long mask;int pc,interrupted;unsigned char info[128];};
struct outcome {
 struct event events[MAX_EVENTS];int events_n,error,rc,irq,locks,holds,releases;
 int refs[NT],status[NT],sigevent[NT],flags[NT],pstatus[NP],nodes[NP+NT];
 struct pending_row pending[NP+NT][MAX_PENDING];size_t restored_free_bytes;
};
static struct outcome observed;
static struct cpu_local_var cpu;
static struct resource_set resources;
static struct process_hash phash;
static struct thread_hash thash;
static struct process procs[NP];
static struct sigcommon commons[NP];
static struct thread threads[NT];
static unsigned char arena[65536] __attribute__((aligned(64)));
static int recording,irqdepth,lockdepth,preemptdepth,refs[NT],holdfail,configured_route;
static mcs_rwlock_lock_t *held_locks[5];static void *held_nodes[5];
static size_t baseline_free;
static void zero(void *p,size_t n){unsigned char *b=p;while(n--)*b++=0;}
static int equal(const void *p,const void *q,size_t n){const unsigned char *a=p,*b=q;while(n--)if(*a++!=*b++)return 0;return 1;}
static int same_string(const char *a,const char *b){while(*a && *a==*b){a++;b++;}return *a==*b;}
static int thread_index(struct thread *t){int i;for(i=0;i<NT;i++)if(t==&threads[i])return i;return -1;}
static int refsum(void){int i,n=0;for(i=0;i<NT;i++)n+=refs[i]-1;return n;}
static void event(int k,int a,int b,int c){
 struct event *e;if(!recording)return;
 if(observed.events_n==MAX_EVENTS){observed.error=1;return;}
 e=&observed.events[observed.events_n++];e->kind=k;e->a=a;e->b=b;e->c=c;
 e->irq=irqdepth;e->locks=lockdepth;e->refs=refsum();
}
struct cpu_local_var *fixture_cpu(void){event(1,0,0,0);return &cpu;}
void *fixture_arena(void){return arena;}
int ihk_mc_get_processor_id(void){return 0;}
void fixture_provider_error(void){observed.error=1;}
void *fixture_pages_exhausted(int n,unsigned long f,int u){(void)n;(void)f;(void)u;observed.error=1;return NULL;}
void *fixture_remote_cpu(int cpu_id){(void)cpu_id;observed.error=1;return NULL;}
void fixture_corruption(void *p){(void)p;observed.error=1;}
void panic(const char *s){(void)s;observed.error=1;}
void preempt_disable(void){++preemptdepth;cpu.no_preempt.counter=preemptdepth;}
void preempt_enable(void){if(preemptdepth<=0)observed.error=1;--preemptdepth;cpu.no_preempt.counter=preemptdepth;}
void cpu_pause(void){observed.error=1;}
unsigned long cpu_disable_interrupt_save(void){unsigned long old=(unsigned long)irqdepth;event(2,(int)old,0,0);++irqdepth;return old;}
void cpu_restore_interrupt(unsigned long flags){event(3,(int)flags,0,0);if(irqdepth!=(int)flags+1)observed.error=1;irqdepth=(int)flags;}
static int lock_id(mcs_rwlock_lock_t *l){
 int i;for(i=0;i<HASH_SIZE;i++){if(l==&phash.lock[i])return 100+i;if(l==&thash.lock[i])return 200+i;}
 for(i=0;i<NP;i++){if(l==&procs[i].update_lock)return 300+i;if(l==&procs[i].threads_lock)return 400+i;if(l==&commons[i].lock)return 500+i;}
 for(i=0;i<NT;i++)if(l==&threads[i].sigpendinglock)return 600+i;return -1;
}
static void acquire(mcs_rwlock_lock_t *l,void *node,int writer){
 int id=lock_id(l);event(writer?5:4,id,0,0);
 if(irqdepth<=0 || lockdepth==5 || id<0)observed.error=1;
 if(lockdepth==1 && id>=300 && id<400 && node==held_nodes[0])observed.error=1;
 if(lockdepth==2 && id>=400 && id<500){
  int outer=lock_id(held_locks[0]);
  if(outer>=200 && outer<300){if(node!=held_nodes[0])observed.error=1;}
  else if(node==held_nodes[0] || node==held_nodes[1])observed.error=1;
 }
 if(lockdepth<5){held_locks[lockdepth]=l;held_nodes[lockdepth]=node;++lockdepth;}
 preempt_disable();
}
static void release(mcs_rwlock_lock_t *l,void *node,int writer){
 event(writer?7:6,lock_id(l),0,0);
 if(lockdepth<=0 || held_locks[lockdepth-1]!=l || held_nodes[lockdepth-1]!=node)observed.error=1;
 else --lockdepth;preempt_enable();
}
void __mcs_rwlock_reader_lock_noirq(struct mcs_rwlock_lock *l,struct mcs_rwlock_node *n){acquire(l,n,0);}
void __mcs_rwlock_reader_unlock_noirq(struct mcs_rwlock_lock *l,struct mcs_rwlock_node *n){release(l,n,0);}
void __mcs_rwlock_writer_lock_noirq(struct mcs_rwlock_lock *l,struct mcs_rwlock_node *n){acquire(l,n,1);}
void __mcs_rwlock_writer_unlock_noirq(struct mcs_rwlock_lock *l,struct mcs_rwlock_node *n){release(l,n,1);}
void __mcs_rwlock_reader_lock(struct mcs_rwlock_lock *l,struct mcs_rwlock_node_irqsave *n){n->irqsave=cpu_disable_interrupt_save();acquire(l,n,0);}
void __mcs_rwlock_reader_unlock(struct mcs_rwlock_lock *l,struct mcs_rwlock_node_irqsave *n){release(l,n,0);cpu_restore_interrupt(n->irqsave);}
int hold_thread(struct thread *t){
 int i=thread_index(t);event(8,i,0,0);if(i<0 || lockdepth!=3 || irqdepth<=0)observed.error=1;
 if(holdfail && configured_route)return -5;
 if(i>=0)++refs[i];++observed.holds;return 0;
}
void release_thread(struct thread *t){
 int i=thread_index(t);event(9,i,0,0);if(i<0 || lockdepth || irqdepth || refs[i]<=1)observed.error=1;
 if(i>=0)--refs[i];++observed.releases;
}
int sched_wakeup_thread(struct thread *t,int states){
 int i=thread_index(t);event(10,i,states,t->status);if(i<0 || lockdepth || irqdepth)observed.error=1;
 if(t->status&states){t->status=PS_RUNNING;return 0;}return -1;
}
int ihk_mc_get_vector(enum ihk_mc_gv_type type){event(11,(int)type,0,0);if(type!=IHK_GV_IKC || lockdepth || irqdepth)observed.error=1;return 209;}
int ihk_mc_interrupt_cpu(int cpu_id,int vector){event(12,cpu_id,vector,0);if(vector!=209 || lockdepth || irqdepth)observed.error=1;return 0;}
void interrupt_syscall(struct thread *t,int sig){(void)t;(void)sig;observed.error=1;}
int kprintf(const char *fmt,...){
 __builtin_va_list ap;__builtin_va_start(ap,fmt);
 if(same_string(fmt,"do_kill,pid=%d,tid=%d,sig=%d\n")){
  int pid=__builtin_va_arg(ap,int),tid=__builtin_va_arg(ap,int),sig=__builtin_va_arg(ap,int);event(13,pid,tid,sig);
 }else if(same_string(fmt,"do_kill,ipi,pid=%d,cpu_id=%d\n")){
  int pid=__builtin_va_arg(ap,int),cpu_id=__builtin_va_arg(ap,int);event(14,pid,cpu_id,0);
 }else if(same_string(fmt,"%s: ERROR hold_thread returned %d,tid=%d\n")){
  const char *fn=__builtin_va_arg(ap,const char *);int rc=__builtin_va_arg(ap,int),tid=__builtin_va_arg(ap,int);
  if(!same_string(fn,"do_kill") || rc!=-5)observed.error=1;event(15,rc,tid,0);
 }else{observed.error=1;}
 __builtin_va_end(ap);return 0;
}
static void setup(int scenario,int route,int debug){
 int i;struct ddebug *d;recording=0;zero(&observed,sizeof(observed));zero(&cpu,sizeof(cpu));zero(&resources,sizeof(resources));zero(&phash,sizeof(phash));zero(&thash,sizeof(thash));zero(procs,sizeof(procs));zero(commons,sizeof(commons));zero(threads,sizeof(threads));
 irqdepth=lockdepth=preemptdepth=0;holdfail=scenario==10;configured_route=route;
 for(i=0;i<HASH_SIZE;i++){INIT_LIST_HEAD(&phash.list[i]);INIT_LIST_HEAD(&thash.list[i]);}
 for(i=0;i<NP;i++){
  procs[i].pid=i==2?201:101+i;procs[i].pgid=i==2?9:7;procs[i].status=PS_RUNNING;
  procs[i].ruid=procs[i].euid=procs[i].suid=1000;
  procs[i].parent=&procs[2];procs[i].main_thread=&threads[2*i];
  INIT_LIST_HEAD(&procs[i].hash_list);INIT_LIST_HEAD(&procs[i].threads_list);INIT_LIST_HEAD(&commons[i].sigpending);
  list_add_tail(&procs[i].hash_list,&phash.list[procs[i].pid%HASH_SIZE]);
 }
 for(i=0;i<NT;i++){
  struct process *p=&procs[i/2];threads[i].proc=p;threads[i].tid=(i%2)?1000+p->pid:p->pid;threads[i].cpu_id=i+1;
  threads[i].status=PS_RUNNING;threads[i].sigcommon=&commons[i/2];refs[i]=1;
  INIT_LIST_HEAD(&threads[i].hash_list);INIT_LIST_HEAD(&threads[i].siblings_list);INIT_LIST_HEAD(&threads[i].sigpending);
  list_add_tail(&threads[i].hash_list,&thash.list[threads[i].tid%HASH_SIZE]);list_add_tail(&threads[i].siblings_list,&p->threads_list);
 }
 if(scenario==1)threads[0].sigmask.__val[0]=~0UL;
 if(scenario==2){list_del_init(&threads[1].siblings_list);list_add(&threads[1].siblings_list,&procs[0].threads_list);}
 if(scenario==3)threads[0].status=PS_EXITED;
 if(scenario==4)procs[0].status=PS_ZOMBIE;
 if(scenario==5){threads[0].sigmask.__val[0]=~0UL;threads[1].sigmask.__val[0]=~0UL;}
 if(scenario==7)threads[0].status=PS_STOPPED;
 if(scenario==8){for(i=0;i<2;i++){list_del_init(&threads[i].hash_list);list_del_init(&threads[i].siblings_list);}}
 resources.process_hash=&phash;resources.thread_hash=&thash;cpu.resource_set=&resources;cpu.current=&threads[0];
 fixture_reset_genuine_arena();baseline_free=fixture_genuine_free_bytes();
 for(d=__start___verbose;d<__stop___verbose;d++)d->flags=debug;
 recording=1;
}
static void snapshot(struct list_head *head,int index){
 struct list_head *p;int n=0;
 for(p=head->next;p!=head;p=p->next){
  struct sig_pending *q=list_entry(p,struct sig_pending,list);struct pending_row *r;
  if(n==MAX_PENDING || p->next->prev!=p || p->prev->next!=p){observed.error=1;break;}
  r=&observed.pending[index][n++];r->mask=q->sigmask.__val[0];r->pc=q->ptracecont;r->interrupted=q->interrupted;
  {size_t k;for(k=0;k<128;k++)r->info[k]=((unsigned char*)&q->info)[k];}
 }observed.nodes[index]=n;
}
static void drain(struct list_head *head,mcs_rwlock_lock_t *l){
 struct mcs_rwlock_node node;unsigned long irq=cpu_disable_interrupt_save();mcs_rwlock_writer_lock_noirq(l,&node);
 while(!list_empty(head)){struct sig_pending *p=list_entry(head->next,struct sig_pending,list);list_del_init(&p->list);kfree_tracked(p,__FILE__,__LINE__);}
 mcs_rwlock_writer_unlock_noirq(l,&node);cpu_restore_interrupt(irq);
}
static int expected_rc(int scenario,int route,int caller,int sig,int group){
 (void)caller;if(sig<0 || sig>64)return -EINVAL;
 if(group)return (group==-99 || (group==1 && !caller))?-ESRCH:0; /* group==1 denotes pid0 */
 if(scenario==6 || (route && (scenario==3 || scenario==8 || scenario==9)))return -ESRCH;
 return 0;
}
static int run(int rust,int scenario,int route,int group,int sig,int pc,int provided,int caller,int sends,int debug,struct outcome *out){
 siginfo_t info;unsigned long rc=0;int i,pid=101,tid=route?101:-1;
 setup(scenario,route,debug);for(i=0;i<128;i++)((unsigned char*)&info)[i]=(unsigned char)(i*17+29);info.si_signo=sig;info.si_code=SI_USER;
 if(scenario==6){pid=999;tid=route?999:-1;}if(scenario==9)pid=102;
 if(group){pid=group==1?0:group;tid=-1;}
 for(i=0;i<sends;i++)rc=rust?do_kill(caller?&threads[0]:NULL,pid,tid,sig,provided?&info:NULL,pc):fixture_original_do_kill(caller?&threads[0]:NULL,pid,tid,sig,provided?&info:NULL,pc);
 observed.rc=(int)rc;
 if(rc!=(unsigned long)expected_rc(scenario,route,caller,sig,group))observed.error=1;
 for(i=0;i<NP;i++){observed.pstatus[i]=procs[i].status;snapshot(&commons[i].sigpending,i);}
 for(i=0;i<NT;i++){
  observed.refs[i]=refs[i];observed.status[i]=threads[i].status;observed.sigevent[i]=threads[i].sigevent;observed.flags[i]=threads[i].signal_flags;snapshot(&threads[i].sigpending,NP+i);
  if(refs[i]!=1)observed.error=1;
 }
 if(observed.holds!=observed.releases || lockdepth || irqdepth || preemptdepth)observed.error=1;
 for(i=0;i<NP;i++)drain(&commons[i].sigpending,&commons[i].lock);
 for(i=0;i<NT;i++)drain(&threads[i].sigpending,&threads[i].sigpendinglock);
 observed.restored_free_bytes=fixture_genuine_free_bytes();if(observed.restored_free_bytes!=baseline_free)observed.error=1;
 observed.irq=irqdepth;observed.locks=lockdepth;if(irqdepth || lockdepth || preemptdepth)observed.error=1;
 *out=observed;return observed.error;
}
int main(void){
 static struct outcome a,b;int scenario,route,sig,pc,provided,caller,sends,debug,g,i;unsigned long cases=0,groups=0,invalid=0;
 const int sigs[]={12,SIGKILL,SIGCONT,33},group_pids[]={1,-7,-9,-1,-99},bad[]={-1,65};
 size_t abi[]={sizeof(struct thread),_Alignof(struct thread),sizeof(struct process),_Alignof(struct process),sizeof(struct process_hash),sizeof(struct thread_hash),offsetof(struct process_hash,lock),offsetof(struct thread,proc),offsetof(struct thread,sigmask),offsetof(struct thread,sigpending),offsetof(struct thread,sigpendinglock),offsetof(struct thread,sigcommon),offsetof(struct thread,sigevent),offsetof(struct thread,status),offsetof(struct thread,refcount),offsetof(struct thread,cpu_id),offsetof(struct process,threads_list),offsetof(struct process,threads_lock),offsetof(struct process,update_lock),offsetof(struct process,pid),offsetof(struct process,pgid),offsetof(struct process,parent),offsetof(struct process,main_thread),offsetof(struct process,ruid),offsetof(struct process,euid),offsetof(struct process,suid),offsetof(struct process,status),sizeof(struct sigcommon),offsetof(struct sigcommon,sigpending),sizeof(struct sig_pending),offsetof(struct sig_pending,info),offsetof(struct sig_pending,ptracecont),sizeof(siginfo_t),sizeof(struct resource_set),offsetof(struct resource_set,process_hash),offsetof(struct resource_set,thread_hash),sizeof(struct cpu_local_var),offsetof(struct cpu_local_var,resource_set),offsetof(struct cpu_local_var,no_preempt),sizeof(struct kmalloc_header),offsetof(struct kmalloc_header,list),offsetof(struct kmalloc_header,size),sizeof(mcs_rwlock_lock_t),_Alignof(mcs_rwlock_lock_t),sizeof(struct mcs_rwlock_node_irqsave)};
 for(i=0;i<45;i++)if(abi[i]!=fixture_whole_abi((size_t)i)){printf("FAIL ABI %d\n",i);return 1;}
 for(scenario=0;scenario<11;scenario++)for(route=0;route<2;route++)for(sig=0;sig<4;sig++)for(pc=0;pc<2;pc++)for(provided=0;provided<2;provided++)for(caller=0;caller<2;caller++)for(sends=1;sends<=2;sends++)for(debug=0;debug<2;debug++){
  int x=run(0,scenario,route,0,sigs[sig],pc,provided,caller,sends,debug,&a),y=run(1,scenario,route,0,sigs[sig],pc,provided,caller,sends,debug,&b);
  if(x || y || !equal(&a,&b,sizeof(a))){printf("FAIL whole %lu scenario%d route%d sig%d pc%d provided%d caller%d sends%d debug%d err%d/%d\n",cases,scenario,route,sig,pc,provided,caller,sends,debug,x,y);return 1;}++cases;
 }
 for(g=0;g<5;g++)for(sig=0;sig<4;sig++)for(pc=0;pc<2;pc++)for(provided=0;provided<2;provided++)for(caller=0;caller<2;caller++)for(sends=1;sends<=2;sends++)for(debug=0;debug<2;debug++){
  int x=run(0,0,0,group_pids[g],sigs[sig],pc,provided,caller,sends,debug,&a),y=run(1,0,0,group_pids[g],sigs[sig],pc,provided,caller,sends,debug,&b);
  if(x || y || !equal(&a,&b,sizeof(a))){printf("FAIL group %lu g%d err%d/%d\n",groups,g,x,y);return 1;}++groups;
 }
 for(sig=0;sig<2;sig++)for(provided=0;provided<2;provided++)for(caller=0;caller<2;caller++)for(debug=0;debug<2;debug++){
  int x=run(0,0,0,0,bad[sig],0,provided,caller,1,debug,&a),y=run(1,0,0,0,bad[sig],0,provided,caller,1,debug,&b);
  if(x || y || !equal(&a,&b,sizeof(a))){printf("FAIL invalid %lu\n",invalid);return 1;}++invalid;
 }
 printf("PASS actual_C_Rust_whole_do_kill direct=%lu group=%lu invalid=%lu ABI=45 controlled_effect_order=1 refs_balanced=1 genuine_arena_restored=1\n",cases,groups,invalid);return 0;
}
