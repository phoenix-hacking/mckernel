Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Private two-hunk kernel/CMakeLists.txt successor is based on exact F04 canonical66239c57. It adds the two already implemented F03 Rust cfgs inside the existing Rust/x86 producer and appends their paired Cdefs solely to syscall.c under existing RUST_KERNEL_ENABLED. All F04 SSE1/headerSHA/Cfilename, FP/runtime flags and fallback code remain exact. No runtime implementation is copied or renamed.

Proposed source/three-case CMake producer-fragment check is ready but unexecuted. It uses project(LANGUAGES NONE), genuine extracted selection guards/statements and exact source-delta reconstruction. It proves only paired selector generation and non-Rust/non-x86 exclusion; full root compiler discovery/default graph, actual SDK build/link and matching native I/O/mincore proof remain open. No configure, compiler, SDK, root, Docker or guest ran.
