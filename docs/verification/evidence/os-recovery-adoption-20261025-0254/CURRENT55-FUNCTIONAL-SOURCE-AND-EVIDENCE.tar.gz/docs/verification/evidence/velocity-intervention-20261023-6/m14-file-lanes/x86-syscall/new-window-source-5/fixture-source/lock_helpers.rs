use core::ffi::c_void;
use crate::abi::CULong;
use crate::spinlock_helpers;
#[repr(C, align(64))]
pub struct McsRwlockNodeIrqsave {
    irqsave: CULong,
}

#[repr(C, align(64))]
pub struct McsRwlockLock {
    slock: spinlock_helpers::IhkSpinlock,
}

unsafe extern "C" {
 pub fn __mcs_rwlock_reader_lock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_reader_unlock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_writer_lock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_writer_unlock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_reader_lock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
 pub fn __mcs_rwlock_reader_unlock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
}
