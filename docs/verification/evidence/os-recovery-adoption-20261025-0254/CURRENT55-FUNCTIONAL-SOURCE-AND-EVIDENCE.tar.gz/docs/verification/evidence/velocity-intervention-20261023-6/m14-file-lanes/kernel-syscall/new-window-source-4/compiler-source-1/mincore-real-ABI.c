/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-4/compiler-source-1/kernel/syscall.c"
/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
/* Append after the actual selected or fallback whole syscall.c inclusion. */
_Static_assert(__builtin_types_compatible_p(__typeof__(&sys_mincore),long (*)(int,ihk_mc_user_context_t *)),"actual mincore syscall ABI");
_Static_assert(PAGE_P2ALIGN==0,"actual x86 lookup alignment");
_Static_assert(__builtin_types_compatible_p(__typeof__(&memobj_lookup_page),int (*)(struct memobj *,off_t,int,unsigned long *,unsigned long *)),"actual memobj lookup ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&copy_to_user),int (*)(void *,const void *,size_t)),"actual byte-copy return ABI");
__typeof__(&sys_mincore) f03_mincore_actual_syscall_address = &sys_mincore;
const unsigned long f03_mincore_C_ABI[] = {
 sizeof(struct process_vm), __alignof__(struct process_vm),
 __builtin_offsetof(struct process_vm,address_space),
 __builtin_offsetof(struct process_vm,memory_range_lock),
 __builtin_offsetof(struct process_vm,page_table_lock),
 __builtin_offsetof(struct process_vm,region),
 __builtin_offsetof(struct thread,vm), __builtin_offsetof(struct cpu_local_var,current),
 __builtin_offsetof(struct address_space,page_table),
 __builtin_offsetof(struct vm_regions,user_start), __builtin_offsetof(struct vm_regions,user_end),
 __builtin_offsetof(struct vm_range,start), __builtin_offsetof(struct vm_range,end),
 __builtin_offsetof(struct vm_range,memobj), __builtin_offsetof(struct vm_range,objoff),
 sizeof(ihk_rwspinlock_t), __alignof__(ihk_rwspinlock_t),
 sizeof(ihk_spinlock_t), __alignof__(ihk_spinlock_t), sizeof(off_t), sizeof(uintptr_t)
};
