// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![allow(dead_code,unused_imports)]
mod abi;mod debug;mod spinlock_helpers;mod lock_helpers;mod list_helpers;mod string;mod mem_helpers;
mod process_helpers {
 use crate::abi::{CInt,Thread};const HASH_SIZE:CInt=73;
 include!("hashes.ACTUAL.rs");
 unsafe extern "C" {pub fn hold_thread(t:*mut Thread)->CInt;pub fn release_thread(t:*mut Thread);}
}
mod sched_helpers {unsafe extern "C" {
 pub fn sched_wakeup_thread(t:*mut crate::abi::Thread,states:crate::abi::CInt)->crate::abi::CInt;
}}
use core::mem::{size_of,align_of,offset_of,MaybeUninit};
use core::ptr::null_mut;
use abi::{AbiListHead,CInt,CLong,CULong,SizeT,Thread,Process,SigInfo};
use lock_helpers::McsRwlockNodeIrqsave;
const ESRCH:CInt=3;const EINVAL:CInt=22;const ENOMEM:CInt=12;const EPERM:CInt=1;
const SIGKILL:CInt=9;const SIGSTOP:CInt=19;const SIGCHLD:CInt=17;const SIGCONT:CInt=18;
const PS_RUNNING:CInt=1;const PS_INTERRUPTIBLE:CInt=2;const PS_ZOMBIE:CInt=8;const PS_EXITED:CInt=16;
const PS_STOPPED:CInt=32;const PS_TRACED:CInt=64;const SIGNAL_STOP_CONTINUED:CInt=2;
const CLD_CONTINUED:CInt=6;const IHK_MC_AP_NOWAIT:CULong=2;
unsafe extern "C" {
 fn kprintf(format:*const i8,...)->CInt;
}
include!("sigmask.ACTUAL.rs");
include!("arena_bindings.rs");
include!("0-syscall_policy.do_kill_process_group.ABI-CAST.FRAGMENT.rs");
include!("1-syscall_policy.do_kill_direct_target_gate.FRAGMENT.rs");
include!("2-syscall_policy.do_kill_pending_enqueue.FRAGMENT.rs");
include!("3-wakeup.FRAGMENT.rs");
include!("4-do_kill_process_target.FRAGMENT.rs");
include!("5-do_kill_thread_target.FRAGMENT.rs");
include!("6-do_kill_prepare_info.FRAGMENT.rs");
include!("7-do_kill_full.FRAGMENT.rs");

#[no_mangle] pub extern "C" fn fixture_whole_abi(i:usize)->usize {
 let v=[size_of::<Thread>(),align_of::<Thread>(),size_of::<Process>(),align_of::<Process>(),
 size_of::<abi::ProcessHash>(),size_of::<abi::ThreadHash>(),offset_of!(abi::ProcessHash,lock),
 offset_of!(Thread,proc),offset_of!(Thread,sigmask),offset_of!(Thread,sigpending),
 offset_of!(Thread,sigpendinglock),offset_of!(Thread,sigcommon),offset_of!(Thread,sigevent),
 offset_of!(Thread,status),offset_of!(Thread,refcount),offset_of!(Thread,cpu_id),
 offset_of!(Process,threads_list),offset_of!(Process,threads_lock),offset_of!(Process,update_lock),
 offset_of!(Process,pid),offset_of!(Process,pgid),offset_of!(Process,parent),offset_of!(Process,main_thread),
 offset_of!(Process,ruid),offset_of!(Process,euid),offset_of!(Process,suid),offset_of!(Process,status),
 size_of::<abi::SigCommon>(),offset_of!(abi::SigCommon,sigpending),size_of::<abi::SigPending>(),
 offset_of!(abi::SigPending,info),offset_of!(abi::SigPending,ptracecont),size_of::<SigInfo>(),
 size_of::<abi::ResourceSet>(),offset_of!(abi::ResourceSet,process_hash),offset_of!(abi::ResourceSet,thread_hash),
 size_of::<abi::CpuLocalVar>(),offset_of!(abi::CpuLocalVar,resource_set),offset_of!(abi::CpuLocalVar,no_preempt),
 size_of::<abi::KmallocHeader>(),offset_of!(abi::KmallocHeader,link),offset_of!(abi::KmallocHeader,size),
 size_of::<abi::McsRwlockLock>(),align_of::<abi::McsRwlockLock>(),size_of::<McsRwlockNodeIrqsave>()];v[i]
}
