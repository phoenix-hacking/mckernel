Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source8 retires five remaining selected C thread-creation adapters. It layers on
source7 C213eedcf/Rust03e6d567, which explicitly includes source6; neither overlay
is silently accepted as canonical. Reconcile exact bases before applying its
private C/Rust diffs, retaining the current F03/policy module set.

The address-space adapter reads the same current CPU resource set and invokes
the existing Rust builder. Release and process/VM adapters invoke unchanged Rust
lifecycle entries. Context initialization forwards the exact raw thread ctx/uctx
field addresses and stack/PC/SP to the same exported architecture entry. No FP,
allocator, fork/ACK, credential, UTI, policy, profile or shared-data implementation
is modified. Creator ownership and every existing backend rollback/error policy
remain unchanged.

The original five adapter bodies were in a Rust-selector-only C block. This
candidate leaves its allocation-pages helper under that original gate and makes
the five unchanged old bodies the explicit C fallback. The complete existing C
create_thread fallback remains unchanged. No new C computation is written; all
old logical __LINE__ positions and existing nine metadata values are preserved.

First obtain a root grant and check actual full-crate types with the three
process overlays and current F03 intact. No compilation is authorized by this
source packet. `NEXT-EXACT-PARITY.NOT-GRANTED.json` supplies four precise argv
arrays for the focused genuine-header C/actual-Rust adapter fixture. It has not
compiled or run. Expected final stdout:

```
PASS actual-original-C/Rust create-thread providers: 52 comparisons, 12 genuine ABI rows, resource/create order, results and raw context/output forwarding
```

The fixture checks getter-before-builder order, exact resource set/slot count and
nullable allocation return; one release/initializer invocation; unchanged zero
process-init result and VM error propagation; exact context/output-slot addresses
and output-slot writes for two normal user contexts. Twelve actual C/Rust layout
rows include canonical CPU-local7912 and real thread/context geometry. Backend
effects remain controlled: real allocation/refcount cleanup, actual initialized
process/VM state, stack frames, FP/assembly and native execution are not proved.

Then, under a separate root grant, compile selected/fallback process objects and
the coherent current Rust object, requiring five unique Rust/partial definitions
and no selected C definitions. Preserve existing provider debt and obtain the
independent creator/stack/output-lifetime review before canonical integration.
Default-image/native proof remains open.
