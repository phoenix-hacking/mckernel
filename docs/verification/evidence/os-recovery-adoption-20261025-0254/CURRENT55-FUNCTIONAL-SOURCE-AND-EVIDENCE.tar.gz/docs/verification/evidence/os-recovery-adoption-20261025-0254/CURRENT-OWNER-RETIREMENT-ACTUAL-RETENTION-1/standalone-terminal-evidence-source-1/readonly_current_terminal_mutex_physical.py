"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Standalone current terminal evidence readback. No configure/recover/Transaction/capture_logs.
"""
from pathlib import Path
import ast,fcntl,hashlib,json,os,stat,types
ENGINE_REF={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/namespace-path-correction-source-1/cleanup_current_retained_F03_image.SOURCE-ONLY.NOT-RELEASED.py', 'bytes': 119427, 'sha256': '0521202446ae694b90b5a80b57bd030f883af73f81fc32c2dcf92ad7c734f844'}
RELEASE_REF={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/namespace-path-correction-source-1/ROOT-NORMAL-CLEANUP-0521-RELEASE.ACTUAL.RELEASED.json', 'bytes': 305255, 'sha256': '110b6191dc0bf3172835657923f07aa68fc86d3e66d302464555c8ae6a063c35'}
ORIGINAL_EXECUTION_SUMMARY_REF={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/namespace-path-correction-source-1/actual-terminal-evidence-readable-readback-1/ROOT-TOOL-TERMINAL-AND-EXACT-RECORD-READBACK.json', 'bytes': 4698, 'sha256': 'f1b8582041aafa2c056d72e5dc0ae5a7cc48541d05959adf15abf390e7c17f2b'}
def need(v,message):
 if not v:raise RuntimeError(message)
def pinned(ref):
 path=Path(ref['path']);need(not any(q.is_symlink() for q in (path,*path.parents)),'nonsymlink pinned path')
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_size==ref['bytes'] and first.st_size<=4<<20,'bounded pinned regular file')
  chunks=[];size=0
  while True:
   part=os.read(fd,65536)
   if not part:break
   size+=len(part);need(size<=ref['bytes'],'bounded pin read');chunks.append(part)
  last=os.fstat(fd);named=path.lstat();keys=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in keys),'stable exact pin')
  raw=b''.join(chunks);need(len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'exact pin bytes');return raw
 finally:os.close(fd)
need(os.getuid()==os.geteuid()==0,'authenticated read-only root observer')
m=types.ModuleType('_current_terminal_readonly');m.__file__=ENGINE_REF['path'];exec(compile(pinned(ENGINE_REF),m.__file__,'exec'),m.__dict__)
release=json.loads(pinned(RELEASE_REF));summary=json.loads(pinned(ORIGINAL_EXECUTION_SUMMARY_REF));obs=release['observation'];original=summary['original_tool']
need(summary['status']=='PASS_EXACT_CURRENT_TERMINAL_RECORD_READBACK_MATCHES_TOOL_OBSERVED_HASHES' and summary['container_id']=='8755eabd5b130d062687e8de762089e1757ddce2503184a2d576496c2cba7d8b','exact current evidence summary')
need(original['session_id']==94729 and original['exit']==0 and original['observed_status']=='PASS_EXECUTED' and original['observed_terminal'] is True and original['observed_container_absent'] is True,'actual tool terminal summary only')
need(original['full_stdout_retained'] is False and original['original_cleanup_pid_birth'] is None,'honest missing original capture/birth')
need(release['status']=='PASS_EXECUTION_RELEASE' and release['script_sha256']==ENGINE_REF['sha256'] and m.digest(m.canonical(release))==summary['observed_canonical_release_sha256']=='96a67386603babca7fcef7719cc8db517f6a4b133f46f891b90c4814e2851072','actual released source/raw and canonical release binding')
need(obs['target']['owner_pid']==502711 and obs['target']['owner_starttime']=='69818461' and obs['target']['container_id']==summary['container_id'] and obs['target']['owner_nonce']=='376e6cf1b5d046fdaaa32fc23192c757','current owner/container scope')
m.RELEASE=release;m.BOOT_ID=obs['boot_id'];m.OWNER_PID=502711;m.OWNER_START='69818461';m.WAITER_PIDS=m.KNOWN_CLIENT_PIDS
m.CONTAINER=obs['target']['container_id'];m.CONTAINER_NAME=obs['target']['container_name'];m.OWNER_NONCE=obs['target']['owner_nonce'];m.CANDIDATE=Path(obs['candidate_root']['path']);m.PROTECTED=obs['selected_files']
need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==m.BOOT_ID,'same boot')
need(len(m.PROTECTED)==67 and sum(len(rows) for rows in obs['inventories'].values())==622,'exact preserved inventory/selected counts')
ORIGINAL_CLEANUP_ARGV=['/home/holden/anaconda3/bin/python3','-I','-B',ENGINE_REF['path'],'--release',RELEASE_REF['path'],'--release-sha256',RELEASE_REF['sha256'],'--execute']
# Add exact current engine path recognition; preserve every original publisher predicate and unfiltered acquisition.
anchor='def publisher(exe,argv):\n';need(m.PROC_CODE.count(anchor)==1,'exact publisher source anchor')
m.PROC_CODE=m.PROC_CODE.replace(anchor,anchor+'    if '+repr(ENGINE_REF['path'])+' in argv: return True\n')
ptree=ast.parse(m.PROC_CODE);selected=[n for n in ptree.body if isinstance(n,ast.FunctionDef) and n.name=='publisher' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='heavy' for t in n.targets)]
predicate={'os':os};exec(compile(ast.Module(body=selected,type_ignores=[]),'<unchanged-publisher-plus-exact-current-path>','exec'),predicate)
need(predicate['publisher'](ORIGINAL_CLEANUP_ARGV[0],ORIGINAL_CLEANUP_ARGV) is True,'exact original cleanup argv covered by complete current process scan')
need(len(summary['records'])==5,'five exact observed terminal records')
records={}
for row in summary['records']:
 need(set(row)=={'path','readback_path','sha256','size','device','inode','mode','uid','gid','nlink'},'finite terminal record shape')
 expected={k:v for k,v in row.items() if k!='readback_path'}
 need(m.observe_identity(Path(row['path']))==expected,'immutable original terminal record ID/hash')
 readback=dict(path=row['readback_path'],sha256=row['sha256'],bytes=row['size']);pinned(readback)
 records[row['path']]=expected
need(set(records)=={str(m.PLAN),str(m.JOURNAL),str(m.CAPTURE),*(str(q) for q in m.archive_paths())},'exact current plan/journal/capture/twoarchive paths')
plan=json.loads(m.read_bounded(m.PLAN));canonical_plan=m.digest(m.canonical(plan))
need(canonical_plan==summary['observed_canonical_plan_sha256']=='847f788a4e073dd32af5cb6bd0ff82959e8423aa0125e2fcd9fa8ce2e211a85f' and plan['release_sha256']==summary['observed_canonical_release_sha256'],'canonical plan and release distinct from raw hashes')
need(plan['owner']==[m.BOOT_ID,502711,'69818461'] and plan['waiters']==list(m.KNOWN_CLIENT_PIDS),'exact original sourceowner and seven clients')
journal=[json.loads(line) for line in m.read_bounded(m.JOURNAL).splitlines()]
need([(row['event'],row['index']) for row in journal]==[(event,i) for i in (0,1) for event in ('before_exchange','after_exchange','release','after_release')]+[('complete',2)],'nine exact legal terminal journal events')
previous=canonical_plan
for i,row in enumerate(journal):
 need(row['sequence']==i and row['previous']==previous and row['plan_sha256']==canonical_plan and row['plan_identity']==[records[str(m.PLAN)]['device'],records[str(m.PLAN)]['inode']],'exact journal chain/plan identity')
 need(m.digest(m.canonical({k:v for k,v in row.items() if k!='hash'}))==row['hash'],'journal hash');previous=row['hash']
for index,(path,parent,name,digest,inode,size) in enumerate(plan['records']):
 archive=Path(parent)/name;record=records[str(archive)]
 need(path==str((m.ATTEMPT,m.SHARED)[index]) and record['sha256']==digest and record['inode']==inode and record['size']==size,'original owned record archive proof')
reader_identity=dict(pid=os.getpid(),starttime=Path('/proc/self/stat').read_text().rpartition(') ')[2].split()[19],boot_id=m.BOOT_ID)
def result(phase):
 return dict(schema='mckernel.m14.current-retained-normal-retirement.terminal-readback.v1',status='PASS_READONLY_CURRENT_TERMINAL_VALIDATION',phase=phase,scope=__doc__,original_execution_summary=ORIGINAL_EXECUTION_SUMMARY_REF,original_execution=original,original_cleanup_identity=None,original_full_stdout=None,stdout_capture_complete=False,current_reader_identity=reader_identity,consumed_cleanup_release=RELEASE_REF,source_engine=ENGINE_REF,observed_terminal_records=list(records.values()),canonical_plan_sha256=canonical_plan,canonical_release_sha256=summary['observed_canonical_release_sha256'],journal_events=len(journal),preserved_inventory_rows=622,preserved_selected_files=67,exact_original_cleanup_argv=ORIGINAL_CLEANUP_ARGV,exact_cleanup_argv_in_full_process_scan=True,proc=m.PROCESS_REPORTS[-1],artifact_native_acceptance=False,cleanup_replayed=False)
lock=m.observe_identity(m.ROOT_LOCK);need((lock['device'],lock['inode'],lock['uid'],lock['gid'],lock['mode'],lock['nlink'],lock['size'])==(27,4,0,0,'0o644',1,0),'permanent mutex27:4')
key=f"{os.major(lock['device']):02x}:{os.minor(lock['device']):02x}:{lock['inode']}";need(not [line for line in Path('/proc/locks').read_text().splitlines() if key in line.split()],'root mutex free')
fd=os.open(m.ROOT_LOCK,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
 need((os.fstat(fd).st_dev,os.fstat(fd).st_ino)==(27,4),'held stable27:4FD');fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m.validate_mount();need(m.namespace_ancestry()==obs['namespace_ancestry'],'namespace ancestry retained')
 paths=['/home/holden/mckernel-work/scratch/native-running-external-modules.lease.json', '/home/holden/mckernel-work/scratch/native-running-external-modules-operational-exclusion.json', '/home/holden/mckernel-work/scratch/native-exact-candidate-operational-exclusion-scratch18-image-1.json', '/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/lease.json', '/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/image-lease.json']+[str(q) for q in (m.ATTEMPT,m.SHARED,m.LEASE,m.QUARANTINE)]
 for path in paths:need(not os.path.lexists(path),'active owned/quarantine path reappeared:'+path)
 need(not m.census(),'exact source container/name/nonce still present')
 m.protected_files()
 transaction_mutex=m.observe_identity(m.MUTEX)
 need([transaction_mutex['device'],transaction_mutex['inode']]==plan['mutex'] and transaction_mutex['mode']=='0o600' and transaction_mutex['uid']==transaction_mutex['gid']==1000 and transaction_mutex['nlink']==1 and transaction_mutex['size']==0 and transaction_mutex['sha256']==m.digest(b''),'retained exact transaction mutex')
 for expected in records.values():need(m.observe_identity(Path(expected['path']))==expected,'terminal records changed during physical read')
 for path in paths:need(not os.path.lexists(path),'active owned/quarantine postflight:'+path)
 need(m.observe_identity(m.ROOT_LOCK)==lock,'permanent mutex unchanged')
 report=result('mutex-held-current-terminal-physical-observation');report.update(root_lock=lock,transaction_mutex=transaction_mutex,absence_paths=paths,container_absent=dict(id=m.CONTAINER,name=m.CONTAINER_NAME,runtime_nonce=m.OWNER_NONCE),controller_lease_nonce='10c01a3e8c7b48a8984aec14fe3762c3')
 print(json.dumps(report,sort_keys=True))
finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
