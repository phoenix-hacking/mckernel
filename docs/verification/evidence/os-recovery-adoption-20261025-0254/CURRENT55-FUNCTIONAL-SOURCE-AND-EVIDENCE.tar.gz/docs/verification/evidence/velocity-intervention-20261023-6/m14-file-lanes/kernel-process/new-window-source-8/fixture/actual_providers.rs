// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path = "actual_abi.rs"]
pub mod abi;
unsafe extern "C" {
    fn fixture_current_cpu() -> *mut abi::CpuLocalVar;
    fn fixture_create(res: *mut abi::ResourceSet, slots: abi::CInt) -> *mut abi::AddressSpace;
    fn fixture_release(asp: *mut abi::AddressSpace);
    fn fixture_init_process(proc: *mut abi::Process, parent: *mut abi::Process);
    fn fixture_init_vm(owner: *mut abi::Process, asp: *mut abi::AddressSpace, vm: *mut abi::ProcessVm) -> abi::CInt;
}
unsafe fn get_this_cpu_local_var() -> *mut abi::CpuLocalVar {
    unsafe { fixture_current_cpu() }
}
unsafe fn create_address_space(res: *mut abi::ResourceSet, slots: abi::CInt) -> *mut abi::AddressSpace {
    unsafe { fixture_create(res, slots) }
}
unsafe fn release_address_space(asp: *mut abi::AddressSpace) {
    unsafe { fixture_release(asp) };
}
unsafe fn init_process(proc: *mut abi::Process, parent: *mut abi::Process) {
    unsafe { fixture_init_process(proc, parent) };
}
unsafe fn init_process_vm(owner: *mut abi::Process, asp: *mut abi::AddressSpace, vm: *mut abi::ProcessVm) -> abi::CInt {
    unsafe { fixture_init_vm(owner, asp, vm) }
}
include!("create_thread_providers.ACTUAL-RUST.inc");

#[no_mangle]
pub static SOURCE8_RUST_ABI: [usize; 12] = [
    core::mem::offset_of!(abi::CpuLocalVar, resource_set),
    core::mem::offset_of!(abi::Thread, ctx),
    core::mem::offset_of!(abi::Thread, uctx),
    core::mem::size_of::<abi::X86KernelContext>(),
    core::mem::align_of::<abi::X86KernelContext>(),
    core::mem::size_of::<abi::X86UserContext>(),
    core::mem::align_of::<abi::X86UserContext>(),
    core::mem::size_of::<*mut abi::ResourceSet>(),
    core::mem::size_of::<*mut abi::Process>(),
    core::mem::size_of::<abi::CInt>(),
    core::mem::size_of::<abi::CULong>(),
    core::mem::size_of::<*mut core::ffi::c_void>(),
];
