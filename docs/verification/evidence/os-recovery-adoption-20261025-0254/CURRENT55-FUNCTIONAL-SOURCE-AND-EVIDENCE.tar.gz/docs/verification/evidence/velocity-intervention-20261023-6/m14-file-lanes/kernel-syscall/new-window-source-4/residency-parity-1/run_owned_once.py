"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Root CPU0 focused actual C/Rust mincore parity; controlled providers, no native claim.
"""
from pathlib import Path
import ast,hashlib,json,os,resource,signal,time
D=Path(__file__).resolve().parent;P=D.parent;B=P.parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True);f.write('\n')
rustc=Path('/home/holden/mckernel-work/toolchains/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc')
assert pin(rustc)['sha256']=='028fd60b0e0add5505c661cd3ccde91393d615c8729bd95d94ab1e91409b36a1'
assert pin(Path('/usr/bin/gcc-9'))['sha256']=='6cb2d84ccd9fd3485d4e47ba032e626be65692601c38fad46866a6b565f3100f'
helper=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
assert pin(helper)['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(helper.read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
ns={'__file__':str(helper)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'),ns)
O=D/'output-1';O.mkdir(mode=0o700);CAP=D/'capture-1';CAP.mkdir(mode=0o700)
recipe=json.loads((B/'new-window-source-3/PROPOSED-FULLCRATE-C-TU-COMMANDS.NOT-GRANTED.json').read_text())
c=recipe['commands'][1]['argv'];c=c[:c.index('-c')]
c=[a for a in c if a!='-DMCKERNEL_RUST_F03_IO_DIAGNOSTICS']
c+=['-c',str(D/'reference.c'),'-o',str(O/'reference.o')]
commands=[('00-real-header-original-C-fixture',c),('01-actual-Rust-fixture-link',[str(rustc),'--edition=2021','--cfg','f03_mincore_candidate','--cfg','enable_profile','--cfg','enable_perf','--cfg','enable_rusage','-C','opt-level=1','-C','panic=abort','-C','link-arg='+str(O/'reference.o'),str(D/'main.rs'),'-o',str(O/'parity')]),('02-actual-C-Rust-residency-parity',[str(O/'parity')])]
os.environ['TMPDIR']=str(O);os.environ['RUST_MIN_STACK']='2097152';os.sched_setaffinity(0,{0});os.chdir(O)
for sig in ns['STOP_SIGNALS']:signal.signal(sig,ns['stop'])
records=[];begin=time.monotonic()
try:
 write(D/'ACTUAL-SOURCE-AND-PROFILE.json',dict(scope=SCOPE,authority='Root explicit CPU0 focused parity ordinary grant.',sources=[pin(p) for p in sorted(D.iterdir()) if p.is_file()],actualABI=pin(Path('/home/holden/mckernel/kernel/rust/abi.rs')),frozenProductionFragment=pin(P/'mincore.RUST-FRAGMENT.rs.inc'),tools=[pin(rustc),pin(Path('/usr/bin/gcc-9'))],helper=pin(helper),CPU=0,jobs=1,AS=2<<30,CPU_seconds=60,wall_seconds=90,retirement=6,FSIZE=32<<20,FD=256,core=0,stack=2<<20,provider_scope='Original C algorithm+entry vs actual Rust algorithm+entry, real ABI allocations. Controlled endpoints observe actual callback forwarding/arguments and lock/copy order; no real native page walk or privileged locks executed.'))
 for label,argv in commands:
  cap=CAP/label;cap.mkdir(mode=0o700);cmd=dict(scope=SCOPE,purpose=SCOPE+' '+label,argv=argv,cwd=str(O));write(cap/'command.json',cmd)
  remaining=90-(time.monotonic()-begin);assert remaining>0
  def limits():
   os.sched_setaffinity(0,{0})
   for k,v in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]:resource.setrlimit(k,(v,v))
  joined=ns['owned_capture'](cmd,cap,remaining,limits);write(cap/'whole-join.json',joined);records.append(dict(label=label,command=pin(cap/'command.json'),join=joined))
  assert joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent'] and joined['closed_streams'] and joined['error'] is None and joined['retirement_error'] is None and not joined['timed_out'],joined
 stdout=(CAP/'02-actual-C-Rust-residency-parity/stdout').read_text();assert stdout.startswith('PASS mincore actual C/Rust residency parity 69 cases;'),stdout
 result=dict(scope=SCOPE,status='PASS_69_CONTROLLED_ACTUAL_C_RUST_MINCORE_RESIDENCY_AND_FORWARDING_CASES',records=records,sourceProfile=pin(D/'ACTUAL-SOURCE-AND-PROFILE.json'),stdout=stdout,cases=69,CPU0_released=True,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,canonical_edits=False,native=False,production_image=False,real_native_page_walk=False)
 write(D/'ACTUAL-PARITY-RESULT.json',result);print(json.dumps(dict(status=result['status'],receipt=pin(D/'ACTUAL-PARITY-RESULT.json'),CPU0_released=True)))
except BaseException as exc:
 result=dict(scope=SCOPE,status='STOP_FIRST_UNEXPECTED_RESULT',error=type(exc).__name__+': '+str(exc),records=records,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,CPU0_released=all(r['join']['direct_child_joined'] and r['join']['group_absent'] and r['join']['closed_streams'] for r in records))
 write(D/'ACTUAL-PARITY-FIRST-FAILURE.json',result);print(json.dumps(dict(status=result['status'],error=result['error'],receipt=pin(D/'ACTUAL-PARITY-FIRST-FAILURE.json'),CPU0_released=result['CPU0_released'])));raise
