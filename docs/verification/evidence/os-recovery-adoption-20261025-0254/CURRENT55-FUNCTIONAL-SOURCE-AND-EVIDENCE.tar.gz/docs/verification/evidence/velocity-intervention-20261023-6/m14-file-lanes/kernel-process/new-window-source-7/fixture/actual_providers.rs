// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path = "actual_abi.rs"]
pub mod abi;
mod spinlock_helpers {
    use core::sync::atomic::AtomicU32;
    include!("actual_spin_type.inc");
}
mod lock_helpers {
    use core::ffi::c_void;
    use crate::abi::CULong;
    use crate::spinlock_helpers;
    include!("actual_mcs_types.inc");
    pub const LOCK_OFFSET: usize = core::mem::offset_of!(McsRwlockLock, slock);
    pub const NODE_OFFSET: usize = core::mem::offset_of!(McsRwlockNodeIrqsave, irqsave);
    unsafe extern "C" {
        fn fixture_mcs_lock(lock: *mut c_void, node: *mut c_void, kind: i32);
        fn fixture_mcs_unlock(lock: *mut c_void, node: *mut c_void, kind: i32);
    }
    pub unsafe fn __mcs_rwlock_writer_lock(lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave) {
        unsafe { fixture_mcs_lock(lock.cast(), node.cast(), 1) };
    }
    pub unsafe fn __mcs_rwlock_writer_unlock(lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave) {
        unsafe { fixture_mcs_unlock(lock.cast(), node.cast(), 1) };
    }
    pub unsafe fn __mcs_rwlock_reader_lock(lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave) {
        unsafe { fixture_mcs_lock(lock.cast(), node.cast(), 2) };
    }
    pub unsafe fn __mcs_rwlock_reader_unlock(lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave) {
        unsafe { fixture_mcs_unlock(lock.cast(), node.cast(), 2) };
    }
}
unsafe extern "C" {
    fn fixture_hold(thread: *mut abi::Thread) -> abi::CInt;
    fn fixture_release(proc: *mut abi::Process, thread: *mut abi::Thread);
    fn fixture_replace(proc: *mut abi::Process, thread: *mut abi::Thread, tid: abi::CInt);
}
unsafe fn hold_thread(thread: *mut abi::Thread) -> abi::CInt {
    unsafe { fixture_hold(thread) }
}
unsafe fn __release_tid(proc: *mut abi::Process, thread: *mut abi::Thread) {
    unsafe { fixture_release(proc, thread) };
}
unsafe fn __find_and_replace_tid(proc: *mut abi::Process, thread: *mut abi::Thread, tid: abi::CInt) {
    unsafe { fixture_replace(proc, thread, tid) };
}
include!("lock_and_tid_providers.ACTUAL-RUST.inc");

#[no_mangle]
pub static SOURCE7_RUST_ABI: [usize; 12] = [
    core::mem::size_of::<abi::McsRwlockLock>(),
    core::mem::align_of::<abi::McsRwlockLock>(),
    core::mem::offset_of!(abi::McsRwlockLock, slock),
    core::mem::size_of::<lock_helpers::McsRwlockLock>(),
    core::mem::align_of::<lock_helpers::McsRwlockLock>(),
    lock_helpers::LOCK_OFFSET,
    core::mem::size_of::<lock_helpers::McsRwlockNodeIrqsave>(),
    core::mem::align_of::<lock_helpers::McsRwlockNodeIrqsave>(),
    lock_helpers::NODE_OFFSET,
    core::mem::size_of::<*mut abi::Thread>(),
    core::mem::size_of::<abi::CInt>(),
    core::mem::offset_of!(abi::CpuLocalVar, resource_set),
];
