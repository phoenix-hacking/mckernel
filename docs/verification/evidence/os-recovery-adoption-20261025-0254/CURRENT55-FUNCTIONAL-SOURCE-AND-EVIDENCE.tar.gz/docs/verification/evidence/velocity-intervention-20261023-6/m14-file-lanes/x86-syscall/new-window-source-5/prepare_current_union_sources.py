"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Current canonical rebase and controlled whole-entry fixture source derivation only.
"""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
D=Path(__file__).resolve().parent;A=D.parent;K=Path('/home/holden/mckernel');S=D/'fixture-source';S.mkdir(exist_ok=True);C=D/'candidate';C.mkdir(exist_ok=True);F=C/'fragments';F.mkdir(exist_ok=True)
def pin(path):
 p=Path(path);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=K,text=True).strip()
paths=sorted((K/'kernel/rust').glob('*.rs'))+[K/'kernel/syscall.c',K/'arch/x86_64/kernel/syscall.c',K/'host-kernel/native-rust/abi/vdso.rs',K/'host-kernel/native-rust/zero_pages.rs']
blobs={str(p):p.read_bytes() for p in paths};bindings=[dict(path=str(p),bytes=len(blobs[str(p)]),sha256=hashlib.sha256(blobs[str(p)]).hexdigest()) for p in paths]
policy=(K/'kernel/rust/syscall_policy.rs');process=K/'kernel/rust/process_helpers.rs'
assert hashlib.sha256(blobs[str(policy)]).hexdigest().startswith('ac129c81')
assert hashlib.sha256(blobs[str(process)]).hexdigest().startswith('03e6d567')
fragments=[A/'next-do-kill-process-group-source-1/candidate/syscall_policy.do_kill_process_group.ABI-CAST.FRAGMENT.rs',A/'next-do-kill-direct-target-gate-source-1/candidate/syscall_policy.do_kill_direct_target_gate.FRAGMENT.rs',A/'next-do-kill-pending-enqueue-source-1/candidate/syscall_policy.do_kill_pending_enqueue.FRAGMENT.rs',A/'new-window-source-1/bounded-field-name-correction-1/fixture-source/wakeup.FRAGMENT.rs',A/'new-window-source-2/candidate/do_kill_process_target.FRAGMENT.rs',A/'new-window-source-3/candidate/do_kill_thread_target.FRAGMENT.rs',A/'new-window-source-3/candidate/do_kill_prepare_info.FRAGMENT.rs',A/'new-window-source-4/bounded-unsafe-cast-correction-1/candidate/do_kill_full.FRAGMENT.rs']
fb=[]
for i,p in enumerate(fragments):
 dst=F/(str(i)+'-'+p.name);dst.write_bytes(p.read_bytes());(S/dst.name).write_bytes(p.read_bytes());fb.append(dict(retained=pin(p),candidate_copy=pin(dst),fixture_copy=pin(S/dst.name)))
pre=blobs[str(policy)].decode();post=pre+'\n'+''.join('\n'+p.read_text()+'\n' for p in fragments);(C/'syscall_policy.rs').write_text(post)
(D/'syscall_policy.CURRENT-UNION.diff').write_text(''.join(difflib.unified_diff(pre.splitlines(True),post.splitlines(True),fromfile='current-canonical/kernel/rust/syscall_policy.rs',tofile='private-current-union/kernel/rust/syscall_policy.rs')))
arch=K/'arch/x86_64/kernel/syscall.c';pre=blobs[str(arch)].decode();a=pre.index('unsigned long\ndo_kill(struct thread *thread');b=pre.index('\n#ifndef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS\nvoid\nset_signal',a);original=pre[a:b]
(S/'original-do-kill.ACTUAL.inc').write_text(original);post=pre[:a]+'#ifndef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS\n'+original+'#endif\n'+pre[b:];(C/'arch-syscall.c').write_text(post)
(D/'arch-syscall.CURRENT-UNION.diff').write_text(''.join(difflib.unified_diff(pre.splitlines(True),post.splitlines(True),fromfile='current-canonical/arch/x86_64/kernel/syscall.c',tofile='private-current-union/arch/x86_64/kernel/syscall.c')))
# Reuse exact accepted extraction functions without executing its preparation main.
prep=A/'group-pending-actual-consumer-preparation-1/prepare_sources.py';tree=ast.parse(prep.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'items','closure'}];ns={'re':re,'hashlib':hashlib};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(prep),'exec'),ns);closure=ns['closure'];items=ns['items']
for name in ('abi','spinlock_helpers','list_helpers'):(S/(name+'.rs')).write_bytes(blobs[str(K/'kernel/rust'/f'{name}.rs')])
string,sp=closure(K/'kernel/rust/string.rs',['__inline_memset','memset','memcpy','__inline_memcpy','strcmp','strcpy','strlen'],'''use core::ffi::c_void;
use core::ptr::{null_mut,read_volatile,write_volatile};
use crate::abi::{CInt,CLong,CULong,SizeT};''');(S/'string.rs').write_text(string)
m=blobs[str(K/'kernel/rust/mem_helpers.rs')].decode();types='\n'.join(re.findall(r'(?m)^type MemKmalloc(?:IrqSave|IrqRestore|AllocPages|GetCpuLocalVar|SpinLock|SpinUnlock|Corruption|BaseAlloc|BaseFree|SpinInit|TrackLog|InvalidFree)Fn =[^;]+;',m));start=m.index('#[repr(C)]\npub struct KmallocTrackAddrEntry');end=m.index('#[repr(C)]\npub struct PageallocTrackAddrEntry',start)
oldmem=(A/'group-pending-actual-consumer-preparation-1/source/mem_helpers.rs').read_text();e=oldmem.index('unsafe extern "C" {');z=oldmem.index('\n}',e)+2;extern=oldmem[e:z]
mem,mp=closure(K/'kernel/rust/mem_helpers.rs',['kmalloc_tracked','kfree_tracked','___kmalloc_body_result','___kfree_body_result','___kmalloc_init_chunk_result','___kmalloc_insert_chunk_result'],'''use core::ffi::c_void;
use core::mem::{size_of,offset_of};
use core::ptr::null_mut;
use core::sync::atomic::{AtomicI32,Ordering};
use crate::abi::{AbiListHead,CInt,CULong,CpuLocalVar,IhkAtomic,IhkSpinlock,KmallocHeader,SizeT};
use crate::string::{strcmp,strcpy,strlen};
'''+types+'\n'+m[start:end]+extern);(S/'mem_helpers.rs').write_text(mem)
(S/'arena_bindings.rs').write_bytes((A/'group-pending-actual-consumer-preparation-1/source/arena_bindings.rs').read_bytes())
# Actual hash/mask bodies are byte-extracted from THIS union, not rewritten.
p=blobs[str(process)].decode();sel=items(p);(S/'hashes.ACTUAL.rs').write_text(sel['process_hash'][2]+'\n'+sel['thread_hash'][2]);sel=items(blobs[str(policy)].decode());(S/'sigmask.ACTUAL.rs').write_text(sel['__sigmask'][2])
debug=blobs[str(K/'kernel/rust/debug.rs')].decode();a=debug.index('#[repr(C)]\npub struct Ddebug');b=debug.index('\n}\n',a)+3;(S/'debug.rs').write_text(debug[a:b])
# Genuine lock type bytes; effect endpoints deliberately controlled in fixture.
lock=blobs[str(K/'kernel/rust/lock_helpers.rs')].decode();types=[]
for name in ('McsRwlockNodeIrqsave','McsRwlockLock'):
 a=lock.index('#[repr(C, align(64))]\npub struct '+name);b=lock.index('\n}\n',a)+3;types.append(lock[a:b])
(S/'lock_helpers.rs').write_text('use core::ffi::c_void;\nuse crate::abi::CULong;\nuse crate::spinlock_helpers;\n'+'\n'.join(types)+'''\nunsafe extern "C" {
 pub fn __mcs_rwlock_reader_lock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_reader_unlock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_writer_lock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_writer_unlock_noirq(lock:*mut McsRwlockLock,node:*mut c_void);
 pub fn __mcs_rwlock_reader_lock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
 pub fn __mcs_rwlock_reader_unlock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
}\n''')
# Require all sampled canonical bytes to remain exact through the derivation.
for row in bindings:assert pin(row['path'])==row,'canonical changed during source rebase'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=K,text=True).strip()==head
record=dict(scope=__doc__,status='CURRENT_UNION_SOURCE_REBASE_ONLY_NO_COMPILER',git_head=head,canonical_union_bindings=bindings,current_policy=pin(policy),current_process=pin(process),candidate_policy=pin(C/'syscall_policy.rs'),candidate_arch=pin(C/'arch-syscall.c'),reused_fragments=fb,original_C_body=pin(S/'original-do-kill.ACTUAL.inc'),actual_mem_function_extractions=mp,actual_string_function_extractions=sp,extraction_helper=pin(prep),sampler='Every canonical file exact before/after preparation and same Git head; source-only sampled union, not compiler/native proof.',historical_acceptance='4bb5b663 Rust/14fa0bac partial remain historical8d42/f2e only and are not relabeled current-union.',fixture_controlled='Real ABI/hash/mask/list/string/allocator bodies; lock/hold/release/IRQ/preempt/scheduler/IPI endpoints controlled, actual process teardown/native concurrency not claimed.',no_new_default_flag=True,canonical_writes=0,actual_compiler_commands=0)
(D/'CURRENT-UNION-SOURCE-REBASE.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(policy=record['current_policy']['sha256'],process=record['current_process']['sha256'],mem_functions=len(mp),string_functions=len(sp),git_head=head),sort_keys=True))
