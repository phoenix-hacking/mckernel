// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path = "../source/kernel/rust/abi.rs"]
pub mod abi;
mod spinlock_helpers {
    use core::ffi::c_void;
    use core::sync::atomic::AtomicU32;
    include!("actual_spinlock_type.inc");
    pub const FIELD_OFFSET: usize = core::mem::offset_of!(IhkSpinlock, head_tail);
    unsafe extern "C" {
        fn fixture_lock(lock: *mut c_void);
        fn fixture_unlock(lock: *mut c_void);
    }
    pub unsafe fn __ihk_mc_spinlock_lock_noirq(lock: *mut IhkSpinlock) {
        unsafe { fixture_lock(lock.cast()) };
    }
    pub unsafe fn __ihk_mc_spinlock_unlock_noirq(lock: *mut IhkSpinlock) {
        unsafe { fixture_unlock(lock.cast()) };
    }
}
mod x86_memory_helpers {
    use core::ffi::c_void;
    use crate::abi::{CInt, CULong, Memobj, ProcessVm, SizeT};
    unsafe extern "C" {
        fn fixture_smaller(args: *mut c_void, current: SizeT, next: *mut SizeT, align: *mut CInt) -> CInt;
        fn fixture_translate(phys: CULong) -> *mut c_void;
        fn fixture_clear(pt: *mut c_void, vm: *mut ProcessVm, start: *mut c_void, end: *mut c_void) -> CInt;
        fn fixture_free(pt: *mut c_void, vm: *mut ProcessVm, start: *mut c_void, end: *mut c_void, obj: *mut Memobj) -> CInt;
    }
    pub unsafe fn arch_get_smaller_page_size(args: *mut c_void, current: SizeT, next: *mut SizeT, align: *mut CInt) -> CInt {
        unsafe { fixture_smaller(args, current, next, align) }
    }
    pub unsafe fn phys_to_virt(phys: CULong) -> *mut c_void {
        unsafe { fixture_translate(phys) }
    }
    pub unsafe fn ihk_mc_pt_clear_range(pt: *mut c_void, vm: *mut ProcessVm, start: *mut c_void, end: *mut c_void) -> CInt {
        unsafe { fixture_clear(pt, vm, start, end) }
    }
    pub unsafe fn ihk_mc_pt_free_range(pt: *mut c_void, vm: *mut ProcessVm, start: *mut c_void, end: *mut c_void, obj: *mut Memobj) -> CInt {
        unsafe { fixture_free(pt, vm, start, end, obj) }
    }
}
include!("free_range_providers.ACTUAL-RUST.inc");

#[no_mangle]
pub static SOURCE6_RUST_ABI: [usize; 16] = [
    core::mem::size_of::<abi::IhkSpinlock>(),
    core::mem::align_of::<abi::IhkSpinlock>(),
    core::mem::offset_of!(abi::IhkSpinlock, head_tail),
    core::mem::size_of::<spinlock_helpers::IhkSpinlock>(),
    core::mem::align_of::<spinlock_helpers::IhkSpinlock>(),
    spinlock_helpers::FIELD_OFFSET,
    core::mem::offset_of!(abi::ProcessVm, page_table_lock),
    core::mem::offset_of!(abi::ProcessVm, address_space),
    core::mem::offset_of!(abi::AddressSpace, page_table),
    core::mem::offset_of!(abi::VmRange, memobj),
    core::mem::offset_of!(abi::Memobj, flags),
    core::mem::size_of::<u32>(),
    0x10000,
    core::mem::size_of::<usize>(),
    core::mem::size_of::<i32>(),
    core::mem::offset_of!(abi::CpuLocalVar, resource_set),
];
