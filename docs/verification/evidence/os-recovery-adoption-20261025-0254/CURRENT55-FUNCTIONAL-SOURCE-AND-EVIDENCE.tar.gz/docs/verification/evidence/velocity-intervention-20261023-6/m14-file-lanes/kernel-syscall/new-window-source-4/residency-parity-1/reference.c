/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <page.h>
#include <ihk/lock.h>
#include <memobj.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
#include <lwk/stddef.h>
extern int vsnprintf(char *,size_t,const char *,va_list);
extern void fixture_format(const char *,size_t);
extern void fixture_lock(int,void *);
extern void *fixture_lookup(void *,unsigned long,unsigned long);
extern void *fixture_pte(void *,unsigned long,int,void *,void *,void *);
extern int fixture_present(void *);
extern int fixture_memobj(void *,off_t,int,void *,void *);
extern int fixture_copy(void *,const void *,size_t);
struct ddebug __attribute__((aligned(8),section("__verbose"))) f03_mincore_debug_v1[4];
extern struct ddebug __start___verbose[],__stop___verbose[];
void fixture_debug_flags(unsigned int flags) {
 for(struct ddebug *p=__start___verbose;p<__stop___verbose;p++) p->flags=flags;
}
int kprintf(const char *format,...) {
 char bytes[512];va_list args;va_start(args,format);
 int n=vsnprintf(bytes,sizeof(bytes),format,args);va_end(args);
 if(n>=0 && (size_t)n<sizeof(bytes)) fixture_format(bytes,(size_t)n);
 return n;
}
typedef void (*syscall_rwlock_fn_t)(void *);
typedef struct vm_range *(*syscall_lookup_range_fn_t)(struct process_vm *,unsigned long,unsigned long);
typedef void *(*mincore_pte_lookup_fn_t)(void *,unsigned long);
typedef int (*mincore_pte_present_fn_t)(void *);
typedef int (*mincore_memobj_lookup_fn_t)(void *,unsigned long);
typedef long (*mincore_copy_byte_fn_t)(unsigned long,unsigned char);
typedef void (*mincore_log_fn_t)(int,unsigned long,size_t,unsigned long,int);
#define MINCORE_LOG_INVALID 1
#define MINCORE_LOG_LOOKUP_FAILED 2
#define MINCORE_LOG_COPY_FAILED 3
#define MINCORE_LOG_EXIT 4
#include "reference-body.ACTUAL-C.inc"
static void fixture_range_lock(void *p) { fixture_lock(1,p); }
static void fixture_range_unlock(void *p) { fixture_lock(2,p); }
static void fixture_table_lock(void *p) { fixture_lock(3,p); }
static void fixture_table_unlock(void *p) { fixture_lock(4,p); }
static struct vm_range *fixture_range(struct process_vm *vm,unsigned long a,unsigned long b) { return fixture_lookup(vm,a,b); }
static void *fixture_page(void *p,void *a,int s,void *b,void *z,void *q) { return fixture_pte(p,(unsigned long)a,s,b,z,q); }
static int fixture_present_typed(pte_t *p) { return fixture_present(p); }
static int fixture_object(struct memobj *p,off_t off,int align,uintptr_t *out,unsigned long *flags) { return fixture_memobj(p,off,align,out,flags); }
#undef ihk_rwspinlock_read_lock_noirq
#define ihk_rwspinlock_read_lock_noirq fixture_range_lock
#undef ihk_rwspinlock_read_unlock_noirq
#define ihk_rwspinlock_read_unlock_noirq fixture_range_unlock
#undef ihk_mc_spinlock_lock_noirq
#define ihk_mc_spinlock_lock_noirq fixture_table_lock
#undef ihk_mc_spinlock_unlock_noirq
#define ihk_mc_spinlock_unlock_noirq fixture_table_unlock
#undef lookup_process_memory_range
#define lookup_process_memory_range fixture_range
#undef ihk_mc_pt_lookup_pte
#define ihk_mc_pt_lookup_pte fixture_page
#undef pte_is_present
#define pte_is_present fixture_present_typed
#undef memobj_lookup_page
#define memobj_lookup_page fixture_object
#undef copy_to_user
#define copy_to_user fixture_copy
#undef mincore_body_result
#define mincore_body_result reference_mincore_body_result
#undef sys_mincore
#define sys_mincore original_sys_mincore
#include "entry.ACTUAL-C.inc"
