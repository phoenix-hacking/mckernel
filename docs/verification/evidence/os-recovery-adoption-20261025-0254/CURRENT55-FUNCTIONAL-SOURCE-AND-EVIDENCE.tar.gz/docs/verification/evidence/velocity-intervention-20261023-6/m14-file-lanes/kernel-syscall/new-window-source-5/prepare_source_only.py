"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Reuse existing move-pages body/entry ports over explicit mincore source; no compiler.
"""
from pathlib import Path
import difflib,hashlib,json
R=Path('/home/holden/mckernel');D=Path(__file__).resolve().parent;B=D.parent
P=B/'new-window-source-4';OLD=B/'next-move-pages-source-1'
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(n,s):
 with (D/n).open('x') as f:f.write(s)
def block(text,start):
 a=text.index(start);at=text.index('{',a);depth=1;e=at+1
 while depth:
  depth+=(text[e]=='{')-(text[e]=='}');e+=1
 return text[a:e]
cbase=P/'syscall.PRIVATE-MINCORE.c';rbase=P/'syscall_policy.PRIVATE-MINCORE.rs'
c=cbase.read_text();policy=rbase.read_text()
assert 'fn sys_move_pages(' not in policy
start=c.index('static int\nmove_pages_verify_bridge(');original=block(c,'long sys_move_pages(int n, ihk_mc_user_context_t *ctx)')
stop=c.index(original,start)+len(original);whole=c[start:stop]
replacement='#if defined(MCKERNEL_RUST_SYSCALL_POLICY_HELPERS) && defined(MCKERNEL_RUST_F03_MOVE_PAGES)\nextern long sys_move_pages(int n, ihk_mc_user_context_t *ctx);\n#else\n'+whole+'\n#endif /* MCKERNEL_RUST_F03_MOVE_PAGES */'
newc=c[:start]+replacement+c[stop:]
old_fragment=(OLD/'move_pages.RUST-FRAGMENT.rs.inc').read_text();thin=old_fragment[old_fragment.index('unsafe extern "C" fn f03_move_pages_verify'):]
thin=thin.replace('    move_pages_body_result(\n','    selected_body(\n')
# Keep the original ABI getter path; ordinary source preparation does not replace
# CPU sampling, acquire another owner, or alter the existing SMP handler ABI.
header='''// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#[cfg(f03_move_pages_candidate)]
mod f03_move_pages_candidate {
    use core::ffi::c_void;
    use core::mem::{size_of, MaybeUninit};
    use core::ptr::{addr_of_mut, null_mut, read_volatile};

    use crate::abi::{CInt, CLong, CULong, CpuSet, MovePagesSmpReq, ProcessVm, SizeT,
        X86UserContext};

    use super::{current_thread_ptr, ihk_mc_get_nr_numa_nodes, kprintf,
        move_pages_free_arrays, move_pages_log_delta, move_pages_policy_result,
        move_pages_smp_req_prepare_result, syscall_alloc_bridge, syscall_copy_from_user_bridge,
        syscall_copy_to_user_bridge, syscall_mckfd_free_bridge, MovePagesGetNrNodesFn,
        MovePagesLogFn, MovePagesSmpCallFn, MovePagesSmpHandlerFn, MovePagesVerifyFn,
        SyscallCopyFromUserFn, SyscallCopyToUserFn, SyscallMckfdFreeFn, SyscallPolicyAllocFn,
        SyscallRdtscFn, SyscallRwlockFn, EFAULT, ENODEV, ENOMEM, IHK_MC_AP_NOWAIT,
        MOVE_PAGES_LOG_INIT_MALLOC, MOVE_PAGES_LOG_INIT_VERIFY, MOVE_PAGES_LOG_PARALLEL,
        MOVE_PAGES_LOG_UNSUPPORTED_MOVE_ALL, MOVE_PAGES_LOG_UNSUPPORTED_PID, MPOL_MF_MOVE_ALL};

    #[cfg(not(f03_move_pages_copy_error_candidate))]
    use super::move_pages_body_result as selected_body;
    #[cfg(f03_move_pages_copy_error_candidate)]
    use self::f03_move_pages_checked_body as selected_body;

    unsafe extern "C" {
        #[link_name = "move_pages_smp_handler"]
        fn f03_move_pages_smp_handler(cpu: CInt, nr_cpus: CInt, arg: *mut c_void) -> CInt;
    }

'''
# The old complete diagnostic port is reused, without an exported adapter symbol:
# it is called synchronously only by the existing body policy callback.
log=(B/'next-move-pages-log-source-1/move_pages_log.RUST-FRAGMENT.rs.inc')
if not log.exists():
 candidates=list((B/'next-move-pages-log-source-1').glob('*.rs.inc'));assert len(candidates)==1;log=candidates[0]
logtext=log.read_text();logbody=block(logtext,'pub unsafe extern "C" fn move_pages_log_bridge(')
logbody=logbody.replace('pub unsafe extern "C" fn move_pages_log_bridge(', 'unsafe extern "C" fn f03_move_pages_log(')
# Existing wrapper statements are preserved; safety contracts are supplied once
# for this unselected module and the actual kernel caller is not generalized.
contracts='''// SAFETY CONTRACT: current CPU/thread/VM/proc/cpu_set remain genuine and stable
// throughout these non-scheduling owner samples and the synchronous body call.
// The page-table lock and original SMP provider retain the stack request until
// real completion, then unlock precedes status copy and tracked array reclamation.
// Every callback uses the exact existing ABI. No callback creates a reference,
// allocation ownership token, publication ACK or scheduler authority.
'''
fragment=header+contracts+logbody+'\n\n'+thin+'\n'
# Explicit independent correctness successor: retain the original body unchanged
# for equivalence; only the separate selector prevents a failed node-copy read.
body=block(policy,'pub unsafe extern "C" fn move_pages_body_result(')
old='''            let _ = copy_from(nodes.cast::<u8>(), user_nodes_addr, int_bytes);
            let nr_nodes = get_nr_nodes();
            let nodes_i32 = nodes.cast::<CInt>();
            let mut i = 0usize;
            while i < count_size {
                let node = read_volatile(nodes_i32.add(i));
                if node < 0 || node >= nr_nodes {
                    ret = -ENODEV;
                    break;
                }
                i += 1;
            }'''
new='''            let copy_error = copy_from(nodes.cast::<u8>(), user_nodes_addr, int_bytes);
            if copy_error != 0 {
                // A partial/failed copy defines no readable node array. Preserve
                // the existing EFAULT domain and common six-array cleanup path.
                ret = -EFAULT;
            } else {
                let nr_nodes = get_nr_nodes();
                let nodes_i32 = nodes.cast::<CInt>();
                let mut i = 0usize;
                while i < count_size {
                    let node = read_volatile(nodes_i32.add(i));
                    if node < 0 || node >= nr_nodes {
                        ret = -ENODEV;
                        break;
                    }
                    i += 1;
                }
            }'''
assert body.count(old)==1
checked=body.replace('pub unsafe extern "C" fn move_pages_body_result(', 'unsafe extern "C" fn f03_move_pages_checked_body(',1).replace(old,new,1)
fragment+='''// Separate source behavior refinement, never an unchanged-C equivalence claim.
// Failure returns EFAULT without node reads/get_nr_nodes/SMP/copy-to; the existing
// common path still frees each successfully owned array exactly once.
#[cfg(f03_move_pages_copy_error_candidate)]
'''+checked+'\n}\n'
put('move_pages.RUST-FRAGMENT.rs.inc',fragment)
put('move_pages.ACTUAL-ORIGINAL-C.inc',whole+'\n')
put('move_pages_body_result.ACTUAL-PREIMAGE.rs.inc',body+'\n')
put('move_pages_copy_error.SEPARATE-CORRECTION.rs.inc',checked+'\n')
put('syscall.PRIVATE-MOVE-PAGES.c',newc)
put('syscall_policy.PRIVATE-MOVE-PAGES.rs',policy+'\n'+fragment)
for name,a,b in [('C',c,newc),('POLICY',policy,policy+'\n'+fragment)]:put('MOVE-PAGES-'+name+'.patch',''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+('kernel/syscall.c' if name=='C' else 'kernel/rust/syscall_policy.rs'),tofile='b/'+('kernel/syscall.c' if name=='C' else 'kernel/rust/syscall_policy.rs'))))
record=dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',status='WHOLE_MOVE_PAGES_REUSED_ENTRY_PROVIDERS_LOG_PLUS_SEPARATE_COPY_FAILURE_REPAIR_SOURCE_UNQUALIFIED',base_C=pin(cbase),base_policy=pin(rbase),reused_entry_port=pin(OLD/'move_pages.RUST-FRAGMENT.rs.inc'),reused_log_port=pin(log),C=pin(D/'syscall.PRIVATE-MOVE-PAGES.c'),policy=pin(D/'syscall_policy.PRIVATE-MOVE-PAGES.rs'),fragment=pin(D/'move_pages.RUST-FRAGMENT.rs.inc'),original_C=pin(D/'move_pages.ACTUAL-ORIGINAL-C.inc'),new_exports=['sys_move_pages'],C_selector='MCKERNEL_RUST_F03_MOVE_PAGES',Rust_selector='f03_move_pages_candidate',separate_behavior_correction_selector='f03_move_pages_copy_error_candidate',default_behavior_correction=False,retired_own_C_bodies=['sys_move_pages','move_pages_verify_bridge','move_pages_get_nr_nodes_bridge','move_pages_page_table_lock_bridge','move_pages_page_table_unlock_bridge','move_pages_smp_call_bridge','move_pages_log_bridge'],preserved_C_fallback_byte_exact=True,new_C_compute=False,concrete_source_defect='Existing canonical move_pages_body_result ignores copy_from nodes return then reads potentially uninitialized allocated nodes. This is a source correctness counterexample, not observed guest failure. Proposed repair is separately selected and never replays indeterminate original-C bytes.',original_copy_failure_domain='Unqualified: do not run original body when failed node copy leaves any consumed int uninitialized.',next_check='Full current Rust metadata/object in base and separate-copy-error configurations; selected/fallback whole C TU and actual C/Rust owner/SMP ABI; strict sys_move_pages definition once and no six own C callback definitions. Controlled original C/Rust defined-domain parity and independent copy-fault successor oracle follow.',parity_domains=['pid!=0 and unsupported MOVE_ALL reject before allocations','six allocation failures, earlier arrays freed once with exact sizes/flags/order','verify failures before copying; valid query nodes NULL and migration nodes non-NULL','successfully initialized node array with node -1/nr_nodes bounds','same SMP handler/address/cpu_set/request under lock and real completion obligation','status-copy failure -EFAULT, normal status bytes and reclaim after unlock','five diagnostic event formats retain exact spaces before newline and unknown silence'],copy_fault_successor_oracle='Inject nonzero copy result and partial/no writes: no node read/get_nr_nodes/SMP/status-copy; EFAULT; all six allocated arrays reclaimed once. No original-C equivalence assertion in this invalid-read domain.',provider_dependencies=['Actual architecture move_pages_smp_handler and synchronous ap::smp_call_func remain production providers, not migrated here.','Current thread/VM/proc/cpu_set and locked request publication/completion lifetimes remain original requirements.'],excluded=['held fork ACK','credential response fill','UTI mapped ownership','f02 profile/data'],compiler_jobs=0,canonical_edits=False,execution_grant=None,default=False,native=False,file_retired=False)
put('SOURCE-HANDOFF.HOLD.json',json.dumps(record,indent=2,sort_keys=True)+'\n');print(json.dumps(pin(D/'SOURCE-HANDOFF.HOLD.json')))
