/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Actual kernel headers and original bodies, controlled backend/lock effects.
 */
#include <process.h>
#include <page.h>
#include <memobj.h>
#include <cls.h>
extern int printf(const char *, ...);
extern void abort(void);
#define CHECK(test) do { if (!(test)) { printf("FAIL line=%d: %s\n", __LINE__, #test); abort(); } } while (0)

_Static_assert(__builtin_types_compatible_p(__typeof__(&ihk_mc_pt_clear_range),
    int (*)(page_table_t, struct process_vm *, void *, void *)), "actual clear ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ihk_mc_pt_free_range),
    int (*)(page_table_t, struct process_vm *, void *, void *, struct memobj *)), "actual free ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&arch_get_smaller_page_size),
    int (*)(void *, size_t, size_t *, int *)), "actual page-size ABI");
_Static_assert(sizeof(ihk_spinlock_t)==4 && __alignof__(ihk_spinlock_t)==4,
    "actual four-byte C ticket-lock representation");

extern const unsigned long SOURCE6_RUST_ABI[16];
static const unsigned long C_ABI[16] = {
    sizeof(ihk_spinlock_t), __alignof__(ihk_spinlock_t), __builtin_offsetof(ihk_spinlock_t, head_tail),
    sizeof(ihk_spinlock_t), __alignof__(ihk_spinlock_t), __builtin_offsetof(ihk_spinlock_t, head_tail),
    __builtin_offsetof(struct process_vm, page_table_lock),
    __builtin_offsetof(struct process_vm, address_space),
    __builtin_offsetof(struct address_space, page_table),
    __builtin_offsetof(struct vm_range, memobj), __builtin_offsetof(struct memobj, flags),
    sizeof(((struct memobj *)0)->flags), MF_XPMEM, sizeof(size_t), sizeof(int),
    __builtin_offsetof(struct cpu_local_var, resource_set),
};

struct event { int kind; unsigned long fields[5]; };
static struct event events[8];
static int count, backend_error, require_lock;
static ihk_spinlock_t *held;
static struct process_vm vm;
static struct address_space address_space;
static struct vm_range range;
static struct memobj memobj;

static void record(int kind, unsigned long a, unsigned long b, unsigned long c,
                   unsigned long d, unsigned long e)
{
    CHECK(count<8);
    events[count++] = (struct event){ kind, {a,b,c,d,e} };
}
void fixture_lock(ihk_spinlock_t *lock)
{
    CHECK(!held);
    held=lock;
    record(1,(unsigned long)lock,0,0,0,0);
}
void fixture_unlock(ihk_spinlock_t *lock)
{
    CHECK(held==lock);
    record(3,(unsigned long)lock,0,0,0,0);
    held=NULL;
}
int fixture_clear(void *pt, struct process_vm *target, void *start, void *end)
{
    CHECK((!require_lock && !held) || (require_lock && held==&target->page_table_lock));
    record(2,(unsigned long)pt,(unsigned long)target,(unsigned long)start,(unsigned long)end,0);
    return backend_error;
}
int fixture_free(void *pt, struct process_vm *target, void *start, void *end, void *obj)
{
    CHECK(!held);
    record(4,(unsigned long)pt,(unsigned long)target,(unsigned long)start,(unsigned long)end,(unsigned long)obj);
    return backend_error;
}
void *fixture_translate(unsigned long phys)
{
    record(5,phys,0,0,0,0);
    return (void *)(phys ^ 0x100000000UL);
}
int fixture_smaller(void *args, size_t current, size_t *next, int *alignment)
{
    CHECK(args==NULL && alignment==NULL && next!=NULL);
    record(6,current,(unsigned long)next,0,0,0);
    if (!backend_error) *next=current>>1;
    return backend_error;
}

#undef ihk_mc_spinlock_lock_noirq
#undef ihk_mc_spinlock_unlock_noirq
#define ihk_mc_spinlock_lock_noirq fixture_lock
#define ihk_mc_spinlock_unlock_noirq fixture_unlock
#define ihk_mc_pt_clear_range fixture_clear
#define ihk_mc_pt_free_range fixture_free
#define arch_get_smaller_page_size fixture_smaller
#undef phys_to_virt
#define phys_to_virt fixture_translate
#include "original_bodies.ACTUAL-C.inc"
#undef ihk_mc_spinlock_lock_noirq
#undef ihk_mc_spinlock_unlock_noirq
#undef ihk_mc_pt_clear_range
#undef ihk_mc_pt_free_range
#undef arch_get_smaller_page_size
#undef phys_to_virt

extern int process_free_range_page_size_bridge(size_t, size_t *);
extern void *process_free_range_phys_to_virt_bridge(unsigned long);
extern int process_free_range_clear_main_bridge(struct process_vm *, unsigned long, unsigned long);
extern void process_free_range_noirq_lock_bridge(unsigned long);
extern void process_free_range_noirq_unlock_bridge(unsigned long);
extern int process_free_range_pt_free_bridge(void *,struct process_vm *,unsigned long,unsigned long,void *);
extern int process_free_range_pt_clear_bridge(void *,struct process_vm *,unsigned long,unsigned long);
extern void process_add_range_mark_xpmem_bridge(struct vm_range *);

static struct event expected[8];
static int expected_count;
static void save(void)
{
    CHECK(!held);
    expected_count=count;
    for (int i=0;i<count;++i) expected[i]=events[i];
    count=0;
}
static void compare(void)
{
    CHECK(!held && count==expected_count);
    for (int i=0;i<count;++i) {
        CHECK(events[i].kind==expected[i].kind);
        for (int j=0;j<5;++j) CHECK(events[i].fields[j]==expected[i].fields[j]);
    }
    count=0;
}

int main(void)
{
    for (int i=0;i<16;++i) {
        CHECK(C_ABI[i]==SOURCE6_RUST_ABI[i]);
        printf("ABI row=%d value=%lu\n",i,C_ABI[i]);
    }
    CHECK(C_ABI[15]==7912);
    vm.address_space=&address_space;
    address_space.page_table=(page_table_t)0x8000;
    range.memobj=&memobj;
    int comparisons=0;
    const int errors[]={0,-5,-12};
    const unsigned long starts[]={0x1000,0x400000};
    for (int error=0;error<3;++error) for (int span=0;span<2;++span) {
        backend_error=errors[error];
        unsigned long start=starts[span], end=start+0x1000;
        require_lock=1;
        int result=reference_process_free_range_clear_main_bridge(&vm,start,end);
        CHECK(result==backend_error && count==3 && events[0].kind==1 &&
              events[1].kind==2 && events[2].kind==3);
        save();
        CHECK(process_free_range_clear_main_bridge(&vm,start,end)==result);
        compare(); ++comparisons;
        require_lock=0;
        result=reference_process_free_range_pt_clear_bridge(address_space.page_table,&vm,start,end);
        save();
        CHECK(process_free_range_pt_clear_bridge(address_space.page_table,&vm,start,end)==result);
        compare(); ++comparisons;
        for (int obj=0;obj<2;++obj) {
            void *pointer=obj ? &memobj : NULL;
            result=reference_process_free_range_pt_free_bridge(address_space.page_table,&vm,start,end,pointer);
            save();
            CHECK(process_free_range_pt_free_bridge(address_space.page_table,&vm,start,end,pointer)==result);
            compare(); ++comparisons;
        }
    }
    const size_t sizes[]={4096,2097152,1073741824};
    for (int error=0;error<2;++error) for (int size=0;size<3;++size) {
        backend_error=error ? -22 : 0;
        size_t next=123;
        int result=reference_process_free_range_page_size_bridge(sizes[size],&next);
        size_t expected_next=next;
        save(); next=123;
        CHECK(process_free_range_page_size_bridge(sizes[size],&next)==result && next==expected_next);
        compare(); ++comparisons;
    }
    for (int i=0;i<3;++i) {
        void *pointer=reference_process_free_range_phys_to_virt_bridge(sizes[i]);
        save(); CHECK(process_free_range_phys_to_virt_bridge(sizes[i])==pointer);
        compare(); ++comparisons;
    }
    reference_process_free_range_noirq_lock_bridge((unsigned long)&vm.page_table_lock);
    reference_process_free_range_noirq_unlock_bridge((unsigned long)&vm.page_table_lock);
    save();
    process_free_range_noirq_lock_bridge((unsigned long)&vm.page_table_lock);
    process_free_range_noirq_unlock_bridge((unsigned long)&vm.page_table_lock);
    compare(); ++comparisons;
    const unsigned int flags[]={0,1,MF_XPMEM,0x50003};
    for (int i=0;i<4;++i) {
        memobj.flags=flags[i]; reference_process_add_range_mark_xpmem_bridge(&range);
        unsigned int expected_flags=memobj.flags;
        memobj.flags=flags[i]; process_add_range_mark_xpmem_bridge(&range);
        CHECK(memobj.flags==expected_flags && memobj.flags==(flags[i]|MF_XPMEM));
        CHECK(range.memobj==&memobj && count==0); ++comparisons;
    }
    CHECK(comparisons==38);
    printf("PASS actual-original-C/Rust free-range providers: 38 comparisons, 16 genuine ABI rows, success/error lock-clear-unlock order and flag preservation\n");
    return 0;
}
