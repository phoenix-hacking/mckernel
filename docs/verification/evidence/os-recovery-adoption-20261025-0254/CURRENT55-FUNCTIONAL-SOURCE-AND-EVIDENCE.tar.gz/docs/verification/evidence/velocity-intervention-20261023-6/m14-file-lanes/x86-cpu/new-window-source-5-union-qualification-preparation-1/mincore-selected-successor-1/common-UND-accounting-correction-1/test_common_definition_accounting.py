"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure synthetic ELF-symbol fixtures for only the corrected global_defs helper.
"""
from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import json
D = Path(__file__).parent
p = D / "observe_union55_fallback15_ABI21.COMMON-CORRECTED.py"
t = ast.parse(p.read_bytes())
f = next(n for n in t.body if isinstance(n, ast.FunctionDef) and n.name == "global_defs")
code = compile(ast.Module(body=[f], type_ignores=[]), str(p), "exec")
rows = []
def symbol(name="common", bind=1, typ=1, index=0xfff2, value=8, size=8):
    return dict(name=name, bind=bind, type=typ, shndx=index, value=value, size=size)
def apply(symbols, expected):
    elf = SimpleNamespace(symbols=symbols, sections=[None] * 4)
    ns = dict(COMMON_EXPECTED={id(elf): expected})
    exec(code, ns)
    return ns["global_defs"](elf)
def rejected(name, symbols, expected):
    try:
        apply(symbols, expected)
    except AssertionError:
        rows.append(dict(case=name, status="PASS_REJECTED"))
    else:
        raise AssertionError(name + " unexpectedly accepted")
assert apply([symbol(), symbol("ordinary_function", typ=2, index=1), symbol("ordinary_data", index=2)], {"common": 8}) == {"common", "ordinary_function", "ordinary_data"}
rows.append(dict(case="ordinary section definitions plus exact global COMMON object resolve", status="PASS"))
assert apply([symbol("undefined", index=0), symbol("local_ordinary", bind=0, index=1), symbol("wrong_reserved", index=0xfff1)], {}) == set()
rows.append(dict(case="UND local ordinary and other reserved symbols cannot resolve", status="PASS"))
for name, row in [("local COMMON", symbol(bind=0)), ("FUNC COMMON", symbol(typ=2)), ("zero COMMON size", symbol(size=0)), ("zero COMMON alignment", symbol(value=0)), ("nonpower2 COMMON alignment", symbol(value=3)), ("COMMON size drift", symbol(size=16)), ("COMMON name drift", symbol(name="wrong"))]:
    rejected(name, [row], {"common": 8})
rejected("missing COMMON inventory", [], {"common": 8})
rejected("extra COMMON inventory", [symbol(), symbol("extra")], {"common": 8})
rejected("duplicate COMMON inventory", [symbol(), symbol()], {"common": 8})
rejected("UND cannot impersonate expected COMMON", [symbol(index=0)], {"common": 8})
rejected("reserved cannot impersonate expected COMMON", [symbol(index=0xfff1)], {"common": 8})
result = dict(scope="Functional McKernel OS/apps and Rust/assembly migration only; no security testing.", status="PASS_PURE_COMMON_DEFINITION_ACCOUNTING_ONLY", cases=rows, count=len(rows), ELF_objects_read=False, runtime=False)
with (D / "ACTUAL-PURE-COMMON-ACCOUNTING-CASES.json").open("x") as out:
    json.dump(result, out, indent=2, sort_keys=True)
    out.write("\n")
print(json.dumps(dict(status=result["status"], count=len(rows))))
