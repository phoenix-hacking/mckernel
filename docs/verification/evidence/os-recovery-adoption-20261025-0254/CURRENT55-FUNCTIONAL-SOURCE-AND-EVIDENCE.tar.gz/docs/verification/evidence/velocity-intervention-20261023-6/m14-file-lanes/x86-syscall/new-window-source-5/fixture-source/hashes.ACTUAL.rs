#[no_mangle]
pub extern "C" fn process_hash(pid: CInt) -> CInt {
    pid % HASH_SIZE
}

#[no_mangle]
pub extern "C" fn thread_hash(tid: CInt) -> CInt {
    tid % HASH_SIZE
}
