"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Narrow helper postjoin + current evidence/mutex FREE observation; no Docker/cleanup.
"""
from pathlib import Path
import ast,hashlib,json,os,stat,types
ENGINE_REF={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/namespace-path-correction-source-1/cleanup_current_retained_F03_image.SOURCE-ONLY.NOT-RELEASED.py', 'bytes': 119427, 'sha256': '0521202446ae694b90b5a80b57bd030f883af73f81fc32c2dcf92ad7c734f844'}
PRIOR={'proc_stdout': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/standalone-terminal-evidence-source-1/0/stdout', 'bytes': 45483, 'sha256': 'f14b880ce62c7a71ddc40a9bf20dda6833054ed23ba72beb4359bbcb2646678f'}, 'proc_join': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/standalone-terminal-evidence-source-1/0/WHOLE-JOIN.json', 'bytes': 1300, 'sha256': '415c62ac1572ce4d2af32c16df7a9a60868e8068f63761b9dd8578101a3e10be'}, 'physical_stdout': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/standalone-terminal-evidence-source-1/1/stdout', 'bytes': 47837, 'sha256': '26ca1a73e6c4c77f6aaa84ebee645538d56e5fea0b4639efaa42396fcdf74f10'}, 'physical_join': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261024-2/m14-f02-contract-source-1/retained-validation-queue-source-1/current-retained-validator-postflight-source-1/standalone-terminal-evidence-source-1/1/WHOLE-JOIN.json', 'bytes': 1301, 'sha256': '53390efec0fa57c254f4f04cb47bc4c2da8370693742528d2ea56ca761a6f2ea'}}
KNOWN_PRIOR_HELPERS=[{'role':'proc-python','pid':519211,'starttime':'70039029'},{'role':'physical-python','pid':519216,'starttime':'70039056'},{'role':'proc-sudo','pid':519208,'starttime':'70039022'},{'role':'physical-sudo','pid':519213,'starttime':'70039049'}]
def need(v,message):
 if not v:raise RuntimeError(message)

def pinned(ref):
 path=Path(ref['path']);need(not any(q.is_symlink() for q in (path,*path.parents)),'nonsymlink pinned path')
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_size==ref['bytes'] and first.st_size<=4<<20,'bounded pinned regular file')
  chunks=[];size=0
  while True:
   part=os.read(fd,65536)
   if not part:break
   size+=len(part);need(size<=ref['bytes'],'bounded pin read');chunks.append(part)
  last=os.fstat(fd);named=path.lstat();keys=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in keys),'stable exact pin')
  raw=b''.join(chunks);need(len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'exact pin bytes');return raw
 finally:os.close(fd)
need(os.getuid()==os.geteuid()==0,'authenticated root readonly postjoin')
prior={key:json.loads(pinned(ref)) for key,ref in PRIOR.items()}
for label,pid,start,sudo,sudo_start in [('proc',519211,'70039029',519208,'70039022'),('physical',519216,'70039056',519213,'70039049')]:
 report=prior[label+'_stdout'];join=prior[label+'_join']
 need(report['schema']=='mckernel.m14.current-retained-normal-retirement.terminal-readback.v1' and report['status']=='PASS_READONLY_CURRENT_TERMINAL_VALIDATION','prior accepted readback scope')
 need(report['current_reader_identity']['pid']==pid and report['current_reader_identity']['starttime']==start,'exact prior Python identity')
 need(report['original_cleanup_identity'] is None and report['original_full_stdout'] is None and report['stdout_capture_complete'] is False,'retain original unknown PID/fullstdout limitations')
 need(join['pid']==sudo and str(join['start'])==sudo_start,'exact prior sudo direct child birth')
 need(join['returncode']==0 and join['direct_child_joined'] and join['group_absent'] and join['closed_streams'] and join['error'] is None and join['retirement_error'] is None and join['timed_out'] is False and join['remaining_group_members']==join['unexpected_group_members']==[],'prior exact joined capture')
 stdout=join['captures']['stdout'];need(stdout['path']==PRIOR[label+'_stdout']['path'] and stdout['sha256']==PRIOR[label+'_stdout']['sha256'] and stdout['size']==PRIOR[label+'_stdout']['bytes'],'prior stdout bound by clean join')
 stderr=join['captures']['stderr'];need(stderr['size']==0,'prior empty stderr');pinned(dict(path=stderr['path'],bytes=stderr['size'],sha256=stderr['sha256']))
physical=prior['physical_stdout'];m=types.ModuleType('_narrow_current_postjoin');m.__file__=ENGINE_REF['path'];exec(compile(pinned(ENGINE_REF),m.__file__,'exec'),m.__dict__)
need(physical['source_engine']==ENGINE_REF and physical['preserved_inventory_rows']==622 and physical['preserved_selected_files']==67 and physical['journal_events']==9,'exact prior current physical scope')
m.BOOT_ID=physical['current_reader_identity']['boot_id'];m.OWNER_PID=502711;m.OWNER_START='69818461';m.WAITER_PIDS=m.KNOWN_CLIENT_PIDS+tuple(r['pid'] for r in KNOWN_PRIOR_HELPERS)
need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==m.BOOT_ID,'same boot')
anchor='def publisher(exe,argv):\n';need(m.PROC_CODE.count(anchor)==1,'exact accepted publisher anchor')
m.PROC_CODE=m.PROC_CODE.replace(anchor,anchor+'    if '+repr(ENGINE_REF['path'])+' in argv: return True\n')
ptree=ast.parse(m.PROC_CODE);nodes=[n for n in ptree.body if isinstance(n,ast.FunctionDef) and n.name=='publisher' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='heavy' for t in n.targets)];check={'os':os};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<same-complete-publisher-predicate>','exec'),check)
need(check['publisher'](physical['exact_original_cleanup_argv'][0],physical['exact_original_cleanup_argv']) is True,'original unknown helper covered by complete process scan')
def current_evidence_and_free_mutex():
 lock=m.observe_identity(m.ROOT_LOCK);need(lock==physical['root_lock'],'permanent root mutex exact identity/hash')
 need((lock['device'],lock['inode'],lock['uid'],lock['gid'],lock['mode'],lock['nlink'],lock['size'])==(27,4,0,0,'0o644',1,0),'exact27:4')
 key=f"{os.major(lock['device']):02x}:{os.minor(lock['device']):02x}:{lock['inode']}"
 need(not [line for line in Path('/proc/locks').read_text().splitlines() if key in line.split()],'permanent mutex must be FREE; no flock acquired')
 need(m.observe_identity(m.MUTEX)==physical['transaction_mutex'],'exact retained transaction mutex')
 need((physical['transaction_mutex']['device'],physical['transaction_mutex']['inode'])==(1828,116852),'transaction mutex1828:116852')
 for row in physical['observed_terminal_records']:need(m.observe_identity(Path(row['path']))==row,'terminal evidence stable')
 for path in physical['absence_paths']:need(not os.path.lexists(path),'current owned/quarantine path reappeared:'+path)
 return lock
before=current_evidence_and_free_mutex()
m.process_absent()
after=current_evidence_and_free_mutex();need(before==after,'permanent mutex FREE/stable before and after')
for key,ref in PRIOR.items():need(json.loads(pinned(ref))==prior[key],'prior capture/join changed')
identity=dict(pid=os.getpid(),starttime=Path('/proc/self/stat').read_text().rpartition(') ')[2].split()[19],boot_id=m.BOOT_ID)
print(json.dumps(dict(schema='mckernel.m14.current-retained-normal-retirement.postjoin-readback.v1',status='PASS_READONLY_CURRENT_HELPERS_POSTJOIN_MUTEX_FREE',scope=__doc__,current_reader_identity=identity,known_prior_helpers=KNOWN_PRIOR_HELPERS,prior_captures=PRIOR,source_engine=ENGINE_REF,root_lock=after,permanent_mutex_free_before=True,permanent_mutex_free_after=True,flock_acquired=False,transaction_mutex=physical['transaction_mutex'],terminal_evidence_unchanged=True,absence_paths=physical['absence_paths'],original_execution_summary=physical['original_execution_summary'],original_cleanup_identity=None,original_full_stdout=None,stdout_capture_complete=False,proc=m.PROCESS_REPORTS[-1],artifact_native_acceptance=False,cleanup_replayed=False),sort_keys=True))
