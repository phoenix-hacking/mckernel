"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Independent expert-directed --crate-name correction; frozen Rust/C bytes, suffix only.
"""
from pathlib import Path
import ast,hashlib,json,os,resource,signal,time
D=Path(__file__).resolve().parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True);f.write('\n')
assert pin(D/'main.TYPE-CORRECTED.rs')['sha256']=='d2fa4cdd0d01c7159653e5ea33b8138650bfb0e5f9fc1d1148ed77b7130be640'
assert pin(D/'output-1/reference.o')['sha256'].startswith('7a3bd430')
helper=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
assert pin(helper)['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(helper.read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
ns={'__file__':str(helper)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'),ns)
previous_cmd=D/'capture-correction-driverfix-1/01-actual-Rust-fixture-link/command.json'
argv=json.loads(previous_cmd.read_text())['argv']
assert pin(Path(argv[0]))['sha256']=='028fd60b0e0add5505c661cd3ccde91393d615c8729bd95d94ab1e91409b36a1'
O=D/'output-expert-1';O.mkdir(mode=0o700);CAP=D/'capture-expert-1';CAP.mkdir(mode=0o700)
argv[1:1]=['--crate-name','mincore_parity'];argv[-1]=str(O/'parity')
commands=[('00-expert-name-Rust-fixture-link',argv),('01-actual-C-Rust-residency-parity',[str(O/'parity')])]
os.environ['TMPDIR']=str(O);os.environ['RUST_MIN_STACK']='2097152';os.sched_setaffinity(0,{0});os.chdir(O)
for sig in ns['STOP_SIGNALS']:signal.signal(sig,ns['stop'])
records=[];begin=time.monotonic()
try:
 write(D/'EXPERT-CRATE-NAME-DECISION-AND-PROFILE.json',dict(scope=SCOPE,authority='Independent f02_review expert diagnosis plus root explicit one suffix grant; sole argv addition --crate-name mincore_parity.',sources=[pin(D/n) for n in ['main.TYPE-CORRECTED.rs','mincore.FROZEN.rs.inc','body.ACTUAL-RUST.rs.inc','getters.ACTUAL-RUST.rs.inc','reference-body.ACTUAL-C.inc','entry.ACTUAL-C.inc','reference.c']],Cprefix=pin(D/'output-1/reference.o'),actualABI=pin(Path('/home/holden/mckernel/kernel/rust/abi.rs')),previous_command=pin(previous_cmd),failures=[pin(D/n) for n in ['ACTUAL-PARITY-FIRST-FAILURE.json','ACTUAL-PARITY-CORRECTION-FAILURE.json','CORRECTION-DRIVER-PREADMISSION-FAILURE.json']],CPU=0,jobs=1,AS=2<<30,CPU_seconds=60,wall_seconds=90,retirement=6,FSIZE=32<<20,FD=256,core=0,stack=2<<20))
 for label,args in commands:
  cap=CAP/label;cap.mkdir(mode=0o700);cmd=dict(scope=SCOPE,purpose=SCOPE+' '+label,argv=args,cwd=str(O));write(cap/'command.json',cmd)
  remaining=90-(time.monotonic()-begin);assert remaining>0
  def limits():
   os.sched_setaffinity(0,{0})
   for k,v in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]:resource.setrlimit(k,(v,v))
  joined=ns['owned_capture'](cmd,cap,remaining,limits);write(cap/'whole-join.json',joined);records.append(dict(label=label,command=pin(cap/'command.json'),join=joined))
  assert joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent'] and joined['closed_streams'] and joined['error'] is None and joined['retirement_error'] is None and not joined['timed_out'],joined
 stdout=(CAP/'01-actual-C-Rust-residency-parity/stdout').read_text();assert stdout.startswith('PASS mincore actual C/Rust residency parity 69 cases;'),stdout
 result=dict(scope=SCOPE,status='PASS_69_CONTROLLED_ACTUAL_C_RUST_MINCORE_RESIDENCY_AND_FORWARDING_CASES',records=records,sourceProfile=pin(D/'EXPERT-CRATE-NAME-DECISION-AND-PROFILE.json'),stdout=stdout,cases=69,CPU0_released=True,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,canonical_edits=False,native=False,production_image=False,real_native_page_walk=False,controlled_provider_endpoints=True)
 write(D/'ACTUAL-PARITY-EXPERT-RESULT.json',result);print(json.dumps(dict(status=result['status'],receipt=pin(D/'ACTUAL-PARITY-EXPERT-RESULT.json'),CPU0_released=True)))
except BaseException as exc:
 result=dict(scope=SCOPE,status='STOP_EXPERT_SUFFIX_UNEXPECTED_RESULT_ESCALATE',error=type(exc).__name__+': '+str(exc),records=records,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin,CPU0_released=all(r['join']['direct_child_joined'] and r['join']['group_absent'] and r['join']['closed_streams'] for r in records))
 write(D/'ACTUAL-PARITY-EXPERT-FAILURE.json',result);print(json.dumps(dict(status=result['status'],error=result['error'],receipt=pin(D/'ACTUAL-PARITY-EXPERT-FAILURE.json'),CPU0_released=result['CPU0_released'])));raise
