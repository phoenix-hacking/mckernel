"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare literal original C entry and existing Rust backend with independent fault oracle.
No compiler or executable is invoked by this preparation helper.
"""
from pathlib import Path
import re,json,hashlib
D=Path(__file__).resolve().parent;P=D.parent;R=Path('/home/holden/mckernel')
c=(R/'kernel/syscall.c').read_text();r=(R/'kernel/rust/syscall_policy.rs').read_text()
def block(text,start):
 a=text.index(start);b=text.index('{',a);depth=1;e=b+1
 while depth:
  depth+=(text[e]=='{')-(text[e]=='}');e+=1
 return text[a:e]
def put(n,s):
 with (D/n).open('x') as f:f.write(s)
names=['MovePagesVerifyFn','MovePagesGetNrNodesFn','MovePagesSmpHandlerFn','MovePagesSmpCallFn','MovePagesLogFn','SyscallCopyFromUserFn','SyscallCopyToUserFn','SyscallPolicyAllocFn','SyscallMckfdFreeFn','SyscallRwlockFn','SyscallRdtscFn']
types=[]
for name in names:
 m=re.search(r'type '+name+r'\s*=.*?;',r,re.S);assert m,name;types.append(m.group())
put('callbacks.ACTUAL-RUST.rs.inc','\n'.join(types)+'\n')
functions=[('pub extern "C" fn move_pages_policy_result(',False),('pub unsafe extern "C" fn move_pages_smp_req_prepare_result(',False),('unsafe fn move_pages_log_delta(',False),('unsafe fn move_pages_free_arrays(',False),('pub unsafe extern "C" fn move_pages_body_result(',True)]
put('backend.ACTUAL-RUST.rs.inc','\n\n'.join(('#[no_mangle]\n' if exported else '')+block(r,name) for name,exported in functions)+'\n')
x=(R/'kernel/rust/x86_cpu_helpers.rs').read_text()
put('getters.ACTUAL-RUST.rs.inc',block(x,'unsafe fn x86_syscall_read(')+'\n'+'\n'.join('#[no_mangle]\n'+block(x,'pub unsafe extern "C" fn ihk_mc_syscall_arg'+str(i)+'(') for i in range(6))+'\n')
put('candidate.FROZEN.rs.inc',(P/'move_pages.RUST-FRAGMENT.rs.inc').read_text())
put('entry.ACTUAL-C.inc',(P/'move_pages.ACTUAL-ORIGINAL-C.inc').read_text())
typenames=['move_pages_verify_fn_t','move_pages_get_nr_nodes_fn_t','move_pages_smp_call_fn_t','move_pages_log_fn_t','syscall_copy_from_user_fn_t','syscall_copy_to_user_fn_t','syscall_policy_alloc_fn_t','syscall_mckfd_free_fn_t','syscall_rwlock_fn_t','syscall_rdtsc_fn_t']
ctypes=[]
for name in typenames:
 m=re.search(r'typedef[^;]*\b'+name+r'\b[^;]*;',c,re.S);assert m,name;ctypes.append(m.group())
proto=re.search(r'extern long move_pages_body_result\(.*?;',c,re.S);assert proto
put('reference.c','''/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <page.h>
#include <ihk/lock.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
#include <lwk/stddef.h>
extern int vsnprintf(char *,size_t,const char *,va_list);
extern void fixture_format(const char *,size_t);
extern int fixture_verify(struct process_vm *,const void *,size_t);
extern void fixture_lock(int,void *);
extern int fixture_smp(cpu_set_t *,smp_func_t,void *);
extern long syscall_copy_from_user_bridge(void *,unsigned long,size_t);
extern long syscall_copy_to_user_bridge(unsigned long,const void *,size_t);
extern void *syscall_alloc_bridge(size_t,unsigned long);
extern void syscall_mckfd_free_bridge(void *);
extern unsigned long syscall_rdtsc_bridge(void);
int kprintf(const char *format,...) {
 char bytes[512];va_list args;va_start(args,format);
 int n=vsnprintf(bytes,sizeof(bytes),format,args);va_end(args);
 if(n>=0 && (size_t)n<sizeof(bytes)) fixture_format(bytes,(size_t)n);
 return n;
}
static void fixture_table_lock(void *p){fixture_lock(1,p);}
static void fixture_table_unlock(void *p){fixture_lock(2,p);}
'''+ '\n'.join(ctypes)+'\n'+proto.group()+'''
#undef verify_process_vm
#define verify_process_vm fixture_verify
#undef ihk_mc_spinlock_lock_noirq
#define ihk_mc_spinlock_lock_noirq fixture_table_lock
#undef ihk_mc_spinlock_unlock_noirq
#define ihk_mc_spinlock_unlock_noirq fixture_table_unlock
#undef smp_call_func
#define smp_call_func fixture_smp
#define sys_move_pages original_sys_move_pages
#define MOVE_PAGES_LOG_UNSUPPORTED_PID 1
#define MOVE_PAGES_LOG_UNSUPPORTED_MOVE_ALL 2
#define MOVE_PAGES_LOG_INIT_MALLOC 3
#define MOVE_PAGES_LOG_INIT_VERIFY 4
#define MOVE_PAGES_LOG_PARALLEL 5
#include "entry.ACTUAL-C.inc"
''')
print('Literal source/actual callback ABI preparation only; no execution.')
