/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Real production headers and original bodies; controlled lock/TID effects.
 */
#include <process.h>
#include <cls.h>
extern int printf(const char *, ...);
extern void abort(void);
#define CHECK(test) do { if (!(test)) { printf("FAIL line=%d: %s\n",__LINE__,#test); abort(); } } while (0)
_Static_assert(__builtin_types_compatible_p(__typeof__(&__mcs_rwlock_writer_lock),
    void (*)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)), "actual writer lock ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&__mcs_rwlock_writer_unlock),
    void (*)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)), "actual writer unlock ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&__mcs_rwlock_reader_lock),
    void (*)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)), "actual reader lock ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&__mcs_rwlock_reader_unlock),
    void (*)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)), "actual reader unlock ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&hold_thread),
    int (*)(struct thread *)), "actual thread hold ABI");
extern const unsigned long SOURCE7_RUST_ABI[12];
static const unsigned long C_ABI[12] = {
    sizeof(struct mcs_rwlock_lock), __alignof__(struct mcs_rwlock_lock),
    __builtin_offsetof(struct mcs_rwlock_lock,slock),
    sizeof(struct mcs_rwlock_lock), __alignof__(struct mcs_rwlock_lock),
    __builtin_offsetof(struct mcs_rwlock_lock,slock),
    sizeof(struct mcs_rwlock_node_irqsave), __alignof__(struct mcs_rwlock_node_irqsave),
    __builtin_offsetof(struct mcs_rwlock_node_irqsave,irqsave),
    sizeof(struct thread *), sizeof(int), __builtin_offsetof(struct cpu_local_var,resource_set),
};
struct event { int kind; unsigned long a,b,c; };
static struct event events[8], expected[8];
static int count, expected_count, held_kind, hold_result;
static void *held_lock, *held_node;
static unsigned long irq;
static struct mcs_rwlock_lock locks[2];
static struct mcs_rwlock_node_irqsave nodes[2];
static struct process processes[2];
static struct thread threads[2];
static void record(int kind,unsigned long a,unsigned long b,unsigned long c)
{
    CHECK(count<8); events[count++]=(struct event){kind,a,b,c};
}
void fixture_mcs_lock(void *lock,void *node,int kind)
{
    CHECK(!held_lock && !held_node);
    struct mcs_rwlock_node_irqsave *saved=node;
    saved->irqsave=irq;
    held_lock=lock; held_node=node; held_kind=kind;
    record(kind,(unsigned long)lock,(unsigned long)node,irq);
    irq=0;
}
void fixture_mcs_unlock(void *lock,void *node,int kind)
{
    CHECK(held_lock==lock && held_node==node && held_kind==kind && irq==0);
    struct mcs_rwlock_node_irqsave *saved=node;
    irq=saved->irqsave;
    record(kind+10,(unsigned long)lock,(unsigned long)node,irq);
    held_lock=held_node=NULL; held_kind=0;
}
static void writer_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node)
{ fixture_mcs_lock(lock,node,1); }
static void writer_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node)
{ fixture_mcs_unlock(lock,node,1); }
static void reader_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node)
{ fixture_mcs_lock(lock,node,2); }
static void reader_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node)
{ fixture_mcs_unlock(lock,node,2); }
int fixture_hold(struct thread *thread)
{ record(20,(unsigned long)thread,0,0); return hold_result; }
void fixture_release(struct process *proc,struct thread *thread)
{ record(21,(unsigned long)proc,(unsigned long)thread,0); }
void fixture_replace(struct process *proc,struct thread *thread,int tid)
{ record(22,(unsigned long)proc,(unsigned long)thread,(unsigned long)(long)tid); }

#undef mcs_rwlock_writer_lock
#undef mcs_rwlock_writer_unlock
#undef mcs_rwlock_reader_lock
#undef mcs_rwlock_reader_unlock
#define mcs_rwlock_writer_lock writer_lock
#define mcs_rwlock_writer_unlock writer_unlock
#define mcs_rwlock_reader_lock reader_lock
#define mcs_rwlock_reader_unlock reader_unlock
#define hold_thread fixture_hold
#define __release_tid fixture_release
#define __find_and_replace_tid fixture_replace
#include "original_bodies.ACTUAL-C.inc"
#undef mcs_rwlock_writer_lock
#undef mcs_rwlock_writer_unlock
#undef mcs_rwlock_reader_lock
#undef mcs_rwlock_reader_unlock
#undef hold_thread
#undef __release_tid
#undef __find_and_replace_tid

extern void process_mcs_writer_lock_bridge(unsigned long,void *);
extern void process_mcs_writer_unlock_bridge(unsigned long,void *);
extern void process_mcs_reader_lock_bridge(unsigned long,void *);
extern void process_mcs_reader_unlock_bridge(unsigned long,void *);
extern void process_hold_thread_bridge(void *);
extern void process_destroy_thread_release_tid_bridge(void *,void *);
extern void process_destroy_thread_replace_tid_bridge(void *,void *,int);
static void save(void)
{
    CHECK(!held_lock && !held_node); expected_count=count;
    for (int i=0;i<count;++i) expected[i]=events[i];
    count=0;
}
static void compare(void)
{
    CHECK(!held_lock && !held_node && count==expected_count);
    for (int i=0;i<count;++i)
        CHECK(events[i].kind==expected[i].kind && events[i].a==expected[i].a &&
              events[i].b==expected[i].b && events[i].c==expected[i].c);
    count=0;
}
int main(void)
{
    for (int i=0;i<12;++i) { CHECK(C_ABI[i]==SOURCE7_RUST_ABI[i]); printf("ABI row=%d value=%lu\n",i,C_ABI[i]); }
    CHECK(C_ABI[11]==7912);
    int comparisons=0;
    const unsigned long flags[]={0,0x202};
    for (int writer=0;writer<2;++writer) for (int index=0;index<2;++index)
    for (int saved=0;saved<2;++saved) {
        unsigned long lock=(unsigned long)&locks[index]; void *node=&nodes[index];
        irq=flags[saved];
        if (writer) {
            reference_process_mcs_writer_lock_bridge(lock,node);
            CHECK(held_lock==(void *)lock && held_node==node && irq==0);
            reference_process_mcs_writer_unlock_bridge(lock,node);
        } else {
            reference_process_mcs_reader_lock_bridge(lock,node);
            CHECK(held_lock==(void *)lock && held_node==node && irq==0);
            reference_process_mcs_reader_unlock_bridge(lock,node);
        }
        CHECK(irq==flags[saved] && count==2); save();
        irq=flags[saved];
        if (writer) {
            process_mcs_writer_lock_bridge(lock,node);
            CHECK(held_lock==(void *)lock && held_node==node && irq==0);
            process_mcs_writer_unlock_bridge(lock,node);
        } else {
            process_mcs_reader_lock_bridge(lock,node);
            CHECK(held_lock==(void *)lock && held_node==node && irq==0);
            process_mcs_reader_unlock_bridge(lock,node);
        }
        CHECK(irq==flags[saved]); compare(); ++comparisons;
    }
    const int results[]={-22,0,1};
    for (int thread=0;thread<2;++thread) for (int result=0;result<3;++result) {
        hold_result=results[result]; reference_process_hold_thread_bridge(&threads[thread]);
        CHECK(count==1); save(); process_hold_thread_bridge(&threads[thread]); compare(); ++comparisons;
    }
    const int tids[]={7,42,1024};
    for (int proc=0;proc<2;++proc) for (int thread=0;thread<2;++thread) {
        reference_process_destroy_thread_release_tid_bridge(&processes[proc],&threads[thread]);
        CHECK(count==1); save(); process_destroy_thread_release_tid_bridge(&processes[proc],&threads[thread]);
        compare(); ++comparisons;
        for (int tid=0;tid<3;++tid) {
            reference_process_destroy_thread_replace_tid_bridge(&processes[proc],&threads[thread],tids[tid]);
            CHECK(count==1); save(); process_destroy_thread_replace_tid_bridge(&processes[proc],&threads[thread],tids[tid]);
            compare(); ++comparisons;
        }
    }
    CHECK(comparisons==30);
    printf("PASS actual-original-C/Rust MCS/TID providers: 30 comparisons, 12 genuine ABI rows, matching lock/node/IRQ state and lifecycle forwarding\n");
    return 0;
}
