#![feature(c_variadic)]
#![feature(core_intrinsics)]
#![no_std]

use core::panic::PanicInfo;

#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/abi.rs"]
pub mod abi;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/abort.rs"]
mod abort;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/affinity.rs"]
mod affinity;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/ap.rs"]
mod ap;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/atomic_helpers.rs"]
mod atomic_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/bitmap.rs"]
mod bitmap;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/bitops.rs"]
mod bitops;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/builtin_dma.rs"]
mod builtin_dma;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/cls.rs"]
mod cls;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/cls_helpers.rs"]
mod cls_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/debug.rs"]
mod debug;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/devobj.rs"]
mod devobj;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/fileobj.rs"]
mod fileobj;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/fork_control_guest.rs"]
mod fork_control_guest;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/fork_control_registry.rs"]
mod fork_control_registry;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/freeze.rs"]
mod freeze;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/futex.rs"]
mod futex;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/gencore.rs"]
mod gencore;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/hash.rs"]
mod hash;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/host_helpers.rs"]
mod host_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/hugefileobj.rs"]
mod hugefileobj;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/ikc_manycore.rs"]
mod ikc_manycore;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/ikc_master.rs"]
mod ikc_master;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/ikc_queue.rs"]
mod ikc_queue;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/init.rs"]
mod init;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/list_helpers.rs"]
mod list_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/listeners.rs"]
mod listeners;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/llist.rs"]
mod llist;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/lock_helpers.rs"]
mod lock_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/mem_helpers.rs"]
mod mem_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/mikc.rs"]
mod mikc;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/numparse.rs"]
mod numparse;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/object_helpers.rs"]
mod object_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/page_alloc.rs"]
mod page_alloc;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/page_helpers.rs"]
mod page_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/pager.rs"]
mod pager;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/plist.rs"]
mod plist;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/process_helpers.rs"]
mod process_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/procfs.rs"]
mod procfs;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/profile.rs"]
mod profile;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/pte_helpers.rs"]
mod pte_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/rbtree.rs"]
mod rbtree;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/refcount_helpers.rs"]
mod refcount_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/rlimit_helpers.rs"]
mod rlimit_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/sched_helpers.rs"]
mod sched_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/shmid_helpers.rs"]
mod shmid_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/shmobj.rs"]
mod shmobj;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/smp_ikc.rs"]
mod smp_ikc;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/spinlock_helpers.rs"]
mod spinlock_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/string.rs"]
mod string;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/syscall_policy.rs"]
mod syscall_policy;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/native_signal.rs"]
mod native_signal;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/native_fault.rs"]
mod native_fault;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/native_futex.rs"]
mod native_futex;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/native_xstate.rs"]
mod native_xstate;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/sysfs.rs"]
mod sysfs;
#[cfg(native_sysfs_verify)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/scripts/tests/fixtures/mckernel_guest_sysfs.rs"]
mod sysfs_verify;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/timer.rs"]
mod timer;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/tofu_uapi.rs"]
mod tofu_uapi;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/ubsan.rs"]
mod ubsan;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/waitq.rs"]
mod waitq;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_coredump.rs"]
mod x86_coredump;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_cpu_helpers.rs"]
mod x86_cpu_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_cpu_log_providers.rs"]
mod x86_cpu_log_providers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_local.rs"]
mod x86_local;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_memory_helpers.rs"]
mod x86_memory_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_memory_loggers.rs"]
mod x86_memory_loggers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_memory_logger_bridges.rs"]
mod x86_memory_logger_bridges;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_perfctr.rs"]
mod x86_perfctr;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_setup.rs"]
mod x86_setup;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/x86_vsyscall.rs"]
mod x86_vsyscall;
#[cfg(native_linux_irq_work_v6_12)]
#[allow(dead_code)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/host-kernel/native-rust/abi/vdso.rs"]
mod vdso_protocol;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/native_vdso.rs"]
mod native_vdso;
#[cfg(native_linux_irq_work_v6_12)]
#[allow(dead_code)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/host-kernel/native-rust/zero_pages.rs"]
mod zero_pages;
#[cfg(native_linux_irq_work_v6_12)]
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/clone3.rs"]
mod clone3;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/xpmem_helpers.rs"]
mod xpmem_helpers;
#[path = "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-5-union-qualification-preparation-1/mincore-selected-successor-1/final-source/kernel/rust/zeroobj.rs"]
mod zeroobj;

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    unsafe {
        x86_setup::early_panic();
    }
    loop {
        core::hint::spin_loop();
    }
}

#[no_mangle]
pub extern "C" fn mckernel_rust_probe() -> u32 {
    0x5255_5354
}

// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Future object witness in the actual crate; reuse the real existing AP type.
#[no_mangle]
pub static M14_REAL_RUST_CPU_INFO_LAYOUT: [crate::abi::CULong; 8] = [
    core::mem::size_of::<crate::ap::IhkMcCpuInfo>() as crate::abi::CULong,
    core::mem::align_of::<crate::ap::IhkMcCpuInfo>() as crate::abi::CULong,
    core::mem::offset_of!(crate::ap::IhkMcCpuInfo, ncpus) as crate::abi::CULong,
    core::mem::offset_of!(crate::ap::IhkMcCpuInfo, hw_ids) as crate::abi::CULong,
    core::mem::offset_of!(crate::ap::IhkMcCpuInfo, nodes) as crate::abi::CULong,
    core::mem::offset_of!(crate::ap::IhkMcCpuInfo, linux_cpu_ids) as crate::abi::CULong,
    core::mem::offset_of!(crate::ap::IhkMcCpuInfo, ikc_cpus) as crate::abi::CULong,
    core::mem::size_of::<crate::abi::CInt>() as crate::abi::CULong,
];

// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Compiler-only append to the real crate root, alongside selected mincore cfg.
#[no_mangle]
#[used]
pub static f03_mincore_Rust_ABI: [u64; 21] = [
    core::mem::size_of::<abi::ProcessVm>() as u64,
    core::mem::align_of::<abi::ProcessVm>() as u64,
    core::mem::offset_of!(abi::ProcessVm, address_space) as u64,
    core::mem::offset_of!(abi::ProcessVm, memory_range_lock) as u64,
    core::mem::offset_of!(abi::ProcessVm, page_table_lock) as u64,
    core::mem::offset_of!(abi::ProcessVm, region) as u64,
    core::mem::offset_of!(abi::Thread, vm) as u64,
    core::mem::offset_of!(abi::CpuLocalVar, current) as u64,
    core::mem::offset_of!(abi::AddressSpace, page_table) as u64,
    core::mem::offset_of!(abi::VmRegions, user_start) as u64,
    core::mem::offset_of!(abi::VmRegions, user_end) as u64,
    core::mem::offset_of!(abi::VmRange, start) as u64,
    core::mem::offset_of!(abi::VmRange, end) as u64,
    core::mem::offset_of!(abi::VmRange, memobj) as u64,
    core::mem::offset_of!(abi::VmRange, objoff) as u64,
    core::mem::size_of::<abi::IhkRwSpinlock>() as u64,
    core::mem::align_of::<abi::IhkRwSpinlock>() as u64,
    core::mem::size_of::<abi::IhkSpinlock>() as u64,
    core::mem::align_of::<abi::IhkSpinlock>() as u64,
    core::mem::size_of::<abi::OffT>() as u64,
    core::mem::size_of::<abi::CULong>() as u64,
];
