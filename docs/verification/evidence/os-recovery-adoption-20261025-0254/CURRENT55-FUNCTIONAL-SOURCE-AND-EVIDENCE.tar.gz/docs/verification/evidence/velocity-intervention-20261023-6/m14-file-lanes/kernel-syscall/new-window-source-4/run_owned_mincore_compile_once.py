"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Root CPU0 ordinary compiler diagnostics: frozen39 union plus own mincore overlay.
"""
from pathlib import Path
import ast
import hashlib
import json
import os
import resource
import shutil
import signal
import time

D=Path(__file__).resolve().parent;B=D.parent;P=B/'new-window-source-3';R=Path('/home/holden/mckernel')
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(row):assert pin(Path(row['path']))['sha256']==row['sha256'],row

def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True);f.write('\n')
def need(value,message):
 if not value:raise ValueError(message)
assert pin(D/'SOURCE-HANDOFF.HOLD.json')['sha256']=='9773640e55c5dfd0535d241aef3e24293f472c6a5226b07e72da0d7188d84125'
m=json.loads((D/'SOURCE-HANDOFF.HOLD.json').read_text())
for key in ['current_C','current_policy','C','policy','fragment','original','ABI','Rust_ABI']:check(m[key])
for row in m['actual_provider_sources']+m['actual_provider_headers']:check(row)
previous=P/'current-process8-union-1';union=json.loads((previous/'ACTUAL-CURRENT-UNION-RESULT.json').read_text());check(union['bindings'])
oldbindings=json.loads(Path(union['bindings']['path']).read_text())
for row in oldbindings['source_bindings']:check(row)
source=D/'compiler-source-1';shutil.copytree(previous/'source',source)
shutil.copyfile(D/'syscall_policy.PRIVATE-MINCORE.rs',source/'kernel/rust/syscall_policy.rs')
shutil.copyfile(D/'syscall.PRIVATE-MINCORE.c',source/'kernel/syscall.c')
with (source/'kernel/rust/lib.rs').open('ab') as f:f.write(b'\n'+(D/'REAL-RUST-MINCORE-ABI.rs.inc').read_bytes())
abi_source=source/'mincore-real-ABI.c'
abi_source.write_text('/* '+SCOPE+' */\n#include "'+str(source/'kernel/syscall.c')+'"\n'+(D/'REAL-HEADER-MINCORE-ABI.c.inc').read_text())
recipe=json.loads((P/'PROPOSED-FULLCRATE-C-TU-COMMANDS.NOT-GRANTED.json').read_text());check(recipe['tool_profile_reference'])
prior=json.loads(Path(recipe['tool_profile_reference']['path']).read_text());check(prior['tools_metadata'])
tools=json.loads(Path(prior['tools_metadata']['path']).read_text())
for row in tools['tools']+prior['extra_tool_bindings']:check(row['resolved'])
helper=Path(tools['capture_helper']['path']);check(tools['capture_helper'])
functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(helper.read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in functions or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
ns={'__file__':str(helper)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'),ns)
check(prior['exact_ABI_reader']);abi_ns={'Path':Path,'_fail':need};exec(Path(prior['exact_ABI_reader']['path']).read_text(),abi_ns)
O=D/'actual-compiler-output-1';O.mkdir(mode=0o700);CAP=D/'actual-compiler-capture-1';CAP.mkdir(mode=0o700)
def remap(argv):
 return [arg.replace(str(P/'source'),str(source)).replace(str(P/'output-proposed-1'),str(O)) for arg in argv]
rust=remap(recipe['commands'][0]['argv']);at=rust.index('--crate-name');rust[at:at]=['--cfg','f03_mincore_candidate']
metadata=[a.replace('--emit=obj='+str(O/'mckernel_rust.o'),'--emit=metadata='+str(O/'mckernel_rust.rmeta')) for a in rust]
selected=remap(recipe['commands'][1]['argv']);selected.insert(1,'-DMCKERNEL_RUST_F03_MINCORE');selected[-1]=str(O/'F03.mincore-selected.o')
fallback=selected.copy();fallback.remove('-DMCKERNEL_RUST_F03_MINCORE');fallback[-1]=str(O/'F03.mincore-fallback.o')
ABI=selected.copy();ABI[-3]=str(abi_source);ABI[-1]=str(O/'mincore-ABI.o')
process_obj=Path(oldbindings['selected_process_object']['path']);check(oldbindings['selected_process_object'])
commands=[('00-current39-mincore-fullcrate-metadata',metadata),('01-current39-mincore-fullcrate-object',rust),('02-whole-selected-C',selected),('03-whole-fallback-C',fallback),('04-real21ABI-C',ABI),('05-strict-mincore-current39-partial',['/usr/bin/ld','-r',str(O/'mckernel_rust.o'),str(O/'F03.mincore-selected.o'),str(process_obj),'-o',str(O/'mincore-current39.partial.o')])]
for label,path in [('Rust',O/'mckernel_rust.o'),('Cselected',O/'F03.mincore-selected.o'),('Cfallback',O/'F03.mincore-fallback.o'),('partial',O/'mincore-current39.partial.o')]:commands.append(('06-symbols-'+label,['/usr/bin/nm','-S',str(path)]))
os.environ['TMPDIR']=str(O);os.environ['RUST_MIN_STACK']='2097152';os.sched_setaffinity(0,{0});os.chdir(O)
for sig in ns['STOP_SIGNALS']:signal.signal(sig,ns['stop'])
records=[];symbols={};begin=time.monotonic()
try:
 write(D/'ACTUAL-EXACT-COMPILER-BINDINGS-1.json',dict(scope=SCOPE,authority='Root CPU0 ordinary HOST compiler/ABI diagnostics only, frozen current39+ownoverlay.',manifest=pin(D/'SOURCE-HANDOFF.HOLD.json'),frozen39=pin(previous/'ACTUAL-CURRENT-UNION-RESULT.json'),private_sources=[pin(source/Path(row['path']).relative_to(previous/'source')) for row in oldbindings['source_bindings']],C=pin(source/'kernel/syscall.c'),lib=pin(source/'kernel/rust/lib.rs'),ABI=pin(abi_source),process_obj=pin(process_obj),tools=tools,helper=pin(helper),CPU=0,jobs=1,AS=2<<30,individual_CPU=120,shared_wall=180,retirement=6,FSIZE=32<<20,FD=256,core=0,stack=2<<20))
 for label,argv in commands:
  cap=CAP/label;cap.mkdir(mode=0o700);command=dict(scope=SCOPE,purpose=SCOPE+' '+label,argv=argv,cwd=str(O));write(cap/'command.json',command)
  remaining=180-(time.monotonic()-begin);assert remaining>0
  def limits():
   os.sched_setaffinity(0,{0})
   for k,v in [(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,120),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]:resource.setrlimit(k,(v,v))
  joined=ns['owned_capture'](command,cap,remaining,limits);write(cap/'whole-join.json',joined);records.append(dict(label=label,command=pin(cap/'command.json'),join=joined))
  assert joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent'] and joined['closed_streams'] and joined['error'] is None and joined['retirement_error'] is None and not joined['timed_out'],joined
  if label.startswith('06-symbols-'):
   table={}
   for line in (cap/'stdout').read_text().splitlines():
    row=line.split()
    if len(row)>=2:table.setdefault(row[-1],[]).append(row[-2])
   symbols[label[len('06-symbols-'):]]=table
 for label in ['Rust','partial']:assert symbols[label].get('sys_mincore')==['T'],(label,symbols[label].get('sys_mincore'))
 assert symbols['Cselected'].get('sys_mincore')==['U']
 assert symbols['Cfallback'].get('sys_mincore')==['T']
 for name in m['retired_static_C_bodies']:assert not symbols['Cselected'].get(name),name
 for target in union['exports']:
  assert symbols['Rust'].get(target)==['T'] and symbols['partial'].get(target)==['T'],target
 rw=abi_ns['_f06_exact_abi_words'](O/'mckernel_rust.o','f03_mincore_Rust_ABI',21)
 cw=abi_ns['_f06_exact_abi_words'](O/'mincore-ABI.o','f03_mincore_C_ABI',21)
 assert rw==cw,(rw,cw)
 result=dict(scope=SCOPE,status='PASS_CURRENT39_PLUS_MINCORE_FULLCRATE_SELECTED_FALLBACK_21ABI_STRICT_PARTIAL',records=records,bindings=pin(D/'ACTUAL-EXACT-COMPILER-BINDINGS-1.json'),Rust_ABI_words=rw,C_ABI_words=cw,sys_mincore_unique_Rust_and_partial=True,ten_selected_C_callbacks_absent=True,prior39_exports_preserved=True,partial_U_exact=sorted(name for name,types in symbols['partial'].items() if 'U' in types),outputs=[pin(p) for p in sorted(O.iterdir()) if p.is_file()],CPU0_released=True,canonical_edits=False,controlled_parity=False,native=False,default=False,file_retired=False,CPU_seconds=ns['cpu_used'](),wall_seconds=time.monotonic()-begin)
 write(D/'ACTUAL-MINCORE-COMPILER-RESULT-1.json',result);print(json.dumps(dict(status=result['status'],receipt=pin(D/'ACTUAL-MINCORE-COMPILER-RESULT-1.json'),CPU0_released=True)))
except BaseException as exc:
 result=dict(scope=SCOPE,status='STOP_FIRST_UNEXPECTED_COMPILER_RESULT',error=type(exc).__name__+': '+str(exc),records=records,CPU0_released=all(r['join']['direct_child_joined'] and r['join']['group_absent'] and r['join']['closed_streams'] for r in records))
 write(D/'ACTUAL-MINCORE-COMPILER-FIRST-FAILURE-1.json',result);print(json.dumps(dict(status=result['status'],error=result['error'],receipt=pin(D/'ACTUAL-MINCORE-COMPILER-FIRST-FAILURE-1.json'),CPU0_released=result['CPU0_released'])));raise
