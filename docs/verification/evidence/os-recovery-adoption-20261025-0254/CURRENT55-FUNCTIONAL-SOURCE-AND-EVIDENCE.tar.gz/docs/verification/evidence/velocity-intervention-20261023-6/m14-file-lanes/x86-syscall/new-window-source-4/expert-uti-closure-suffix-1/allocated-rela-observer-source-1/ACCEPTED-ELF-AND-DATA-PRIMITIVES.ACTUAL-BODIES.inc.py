class Elf:

    def __init__(self, path):
        self.raw = path.read_bytes()
        eh = struct.unpack_from('<16sHHIQQQIHHHHHH', self.raw)
        assert eh[0][:6] == b'\x7fELF\x02\x01' and eh[1] == 1 and (eh[2] == 62) and (eh[11] == 64)
        self.sections = [dict(zip(['name_off', 'type', 'flags', 'addr', 'offset', 'size', 'link', 'info', 'align', 'entsize'], struct.unpack_from('<IIQQQQIIQQ', self.raw, eh[6] + i * 64))) for i in range(eh[12])]
        names = self.payload(self.sections[eh[13]])
        for (i, section) in enumerate(self.sections):
            section.update(index=i, name=self.string(names, section['name_off']))
        tables = [s for s in self.sections if s['type'] == 2]
        assert len(tables) == 1 and tables[0]['entsize'] == 24
        self.table = tables[0]
        strings = self.payload(self.sections[self.table['link']])
        self.symbols = []
        for i in range(self.table['size'] // 24):
            (no, info, other, idx, value, size) = struct.unpack_from('<IBBHQQ', self.raw, self.table['offset'] + i * 24)
            self.symbols.append(dict(index=i, name=self.string(strings, no), bind=info >> 4, type=info & 15, shndx=idx, value=value, size=size))

    @staticmethod
    def string(table, offset):
        return table[offset:table.index(b'\x00', offset)].decode()

    def payload(self, section):
        return self.raw[section['offset']:section['offset'] + section['size']]

    def sym(self, name):
        found = [s for s in self.symbols if s['name'] == name]
        assert len(found) == 1, (name, found)
        return found[0]

    def data(self, name):
        sym = self.sym(name)
        assert sym['shndx'] not in (0, 65521) and sym['type'] == 1
        data = self.payload(self.sections[sym['shndx']])
        assert sym['value'] + sym['size'] <= len(data)
        return data[sym['value']:sym['value'] + sym['size']]

    def word(self, name):
        data = self.data(name)
        assert len(data) == 8, (name, len(data))
        return int.from_bytes(data, 'little')

def owning_relocations(elf, symbol):
    result = []
    for sec in elf.sections:
        if sec['type'] != 4 or sec['info'] != symbol['shndx']:
            continue
        assert sec['link'] == elf.table['index'] and sec['entsize'] == 24 and (sec['size'] % 24 == 0)
        for i in range(sec['size'] // 24):
            (offset, info, addend) = struct.unpack_from('<QQq', elf.raw, sec['offset'] + 24 * i)
            assert info >> 32 < len(elf.symbols)
            if symbol['value'] <= offset < symbol['value'] + symbol['size']:
                result.append(dict(offset=offset - symbol['value'], type=info & 4294967295, target=elf.symbols[info >> 32], addend=addend, owning_section=sec['info']))
    return result

def defined_object(elf, name):
    sym = elf.sym(name)
    assert sym['bind'] == 1 and sym['type'] == 1 and (0 < sym['shndx'] < len(elf.sections)), sym
    assert elf.sections[sym['shndx']]['flags'] & 2, sym
    return sym

def object_bytes(elf, sym):
    sec = elf.sections[sym['shndx']]
    assert sym['value'] + sym['size'] <= sec['size']
    return bytes(sym['size']) if sec['type'] == 8 else elf.payload(sec)[sym['value']:sym['value'] + sym['size']]
