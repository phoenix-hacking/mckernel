"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Extract literal original C and actual Rust algorithm/entry for controlled HOST parity.
"""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;P=D.parent;R=Path('/home/holden/mckernel')
c=(R/'kernel/syscall.c').read_text();r=(R/'kernel/rust/syscall_policy.rs').read_text()
def block(text,start):
 a=text.index(start);b=text.index('{',a);depth=1;e=b+1
 while depth:
  depth+=(text[e]=='{')-(text[e]=='}');e+=1
 return text[a:e]
def put(n,s):
 with (D/n).open('x') as f:f.write(s)
helpers=[]
for name,kind in [('mincore_prepare_range','SYSCALL_POLICY_HELPER_SCOPE int\n'),('mincore_range_ulong_field','static unsigned long\n'),('mincore_range_ptr_field','static void *\n'),('mincore_range_off_field','static off_t\n'),('mincore_body_result','SYSCALL_POLICY_HELPER_SCOPE long\n')]:helpers.append(block(c,kind+name+'('))
reference='\n\n'.join(helpers)
reference=reference.replace('SYSCALL_POLICY_HELPER_SCOPE ','')
reference=reference.replace('mincore_body_result(', 'reference_mincore_body_result(')
put('reference-body.ACTUAL-C.inc',reference+'\n')
put('entry.ACTUAL-C.inc',(P/'mincore.ACTUAL-ORIGINAL-C.inc').read_text())
rusthelpers=[]
for name,start in [('field_ptr','unsafe fn field_ptr<T>'),('mincore_prepare_range','pub unsafe extern "C" fn mincore_prepare_range('),('mincore_range_ulong','unsafe fn mincore_range_ulong('),('mincore_range_ptr','unsafe fn mincore_range_ptr('),('mincore_range_objoff','unsafe fn mincore_range_objoff('),('mincore_body_result','pub unsafe extern "C" fn mincore_body_result(')]:rusthelpers.append(block(r,start))
put('body.ACTUAL-RUST.rs.inc','\n\n'.join(rusthelpers)+'\n')
x=(R/'kernel/rust/x86_cpu_helpers.rs').read_text()
getters=[block(x,'unsafe fn x86_syscall_read(')]+['#[no_mangle]\n'+block(x,'pub unsafe extern "C" fn ihk_mc_syscall_arg'+str(i)+'(') for i in range(3)]
put('getters.ACTUAL-RUST.rs.inc','\n\n'.join(getters)+'\n')
put('mincore.FROZEN.rs.inc',(P/'mincore.RUST-FRAGMENT.rs.inc').read_text())
put('reference.c','''/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <page.h>
#include <ihk/lock.h>
#include <memobj.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
extern int vsnprintf(char *,size_t,const char *,va_list);
extern void fixture_format(const char *,size_t);
extern void fixture_lock(int,void *);
extern void *fixture_lookup(void *,unsigned long,unsigned long);
extern void *fixture_pte(void *,unsigned long,int,void *,void *,void *);
extern int fixture_present(void *);
extern int fixture_memobj(void *,off_t,int,void *,void *);
extern int fixture_copy(void *,const void *,size_t);
struct ddebug __attribute__((aligned(8),section("__verbose"))) f03_mincore_debug_v1[4];
extern struct ddebug __start___verbose[],__stop___verbose[];
void fixture_debug_flags(unsigned int flags) {
 for(struct ddebug *p=__start___verbose;p<__stop___verbose;p++) p->flags=flags;
}
int kprintf(const char *format,...) {
 char bytes[512];va_list args;va_start(args,format);
 int n=vsnprintf(bytes,sizeof(bytes),format,args);va_end(args);
 if(n>=0 && (size_t)n<sizeof(bytes)) fixture_format(bytes,(size_t)n);
 return n;
}
typedef void (*syscall_rwlock_fn_t)(void *);
typedef struct vm_range *(*syscall_lookup_range_fn_t)(struct process_vm *,unsigned long,unsigned long);
typedef void *(*mincore_pte_lookup_fn_t)(void *,unsigned long);
typedef int (*mincore_pte_present_fn_t)(void *);
typedef int (*mincore_memobj_lookup_fn_t)(void *,unsigned long);
typedef long (*mincore_copy_byte_fn_t)(unsigned long,unsigned char);
typedef void (*mincore_log_fn_t)(int,unsigned long,size_t,unsigned long,int);
#define MINCORE_LOG_INVALID 1
#define MINCORE_LOG_LOOKUP_FAILED 2
#define MINCORE_LOG_COPY_FAILED 3
#define MINCORE_LOG_EXIT 4
#include "reference-body.ACTUAL-C.inc"
static void fixture_range_lock(void *p) { fixture_lock(1,p); }
static void fixture_range_unlock(void *p) { fixture_lock(2,p); }
static void fixture_table_lock(void *p) { fixture_lock(3,p); }
static void fixture_table_unlock(void *p) { fixture_lock(4,p); }
static struct vm_range *fixture_range(struct process_vm *vm,unsigned long a,unsigned long b) { return fixture_lookup(vm,a,b); }
static void *fixture_page(void *p,void *a,int s,void *b,void *z,void *q) { return fixture_pte(p,(unsigned long)a,s,b,z,q); }
static int fixture_present_typed(pte_t *p) { return fixture_present(p); }
static int fixture_object(struct memobj *p,off_t off,int align,uintptr_t *out,unsigned long *flags) { return fixture_memobj(p,off,align,out,flags); }
#define ihk_rwspinlock_read_lock_noirq fixture_range_lock
#define ihk_rwspinlock_read_unlock_noirq fixture_range_unlock
#define ihk_mc_spinlock_lock_noirq fixture_table_lock
#define ihk_mc_spinlock_unlock_noirq fixture_table_unlock
#define lookup_process_memory_range fixture_range
#define ihk_mc_pt_lookup_pte fixture_page
#define pte_is_present fixture_present_typed
#define memobj_lookup_page fixture_object
#define copy_to_user fixture_copy
#define mincore_body_result reference_mincore_body_result
#define sys_mincore original_sys_mincore
#include "entry.ACTUAL-C.inc"
''')
print('prepared literal C/Rust source extractions; no compiler invoked')
