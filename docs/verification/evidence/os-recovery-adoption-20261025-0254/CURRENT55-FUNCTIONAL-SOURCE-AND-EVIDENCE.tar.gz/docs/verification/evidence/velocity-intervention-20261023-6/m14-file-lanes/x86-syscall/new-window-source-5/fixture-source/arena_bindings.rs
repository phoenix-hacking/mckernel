use core::ffi::c_void;
unsafe extern "C" {fn fixture_cpu()->*mut abi::CpuLocalVar;fn fixture_arena()->*mut c_void;
 fn cpu_disable_interrupt_save()->CULong;fn cpu_restore_interrupt(flags:CULong);}
#[no_mangle] static mut memdebug:*mut i8=core::ptr::null_mut();
#[no_mangle] static mut kmalloc_track_hash:[AbiListHead;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_addr_hash:[AbiListHead;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_track_hash_locks:[abi::IhkSpinlock;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_addr_hash_locks:[abi::IhkSpinlock;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_runcount:CInt=0;
#[no_mangle] pub unsafe extern "C" fn get_this_cpu_local_var()->*mut abi::CpuLocalVar {
 unsafe{fixture_cpu()}
}
#[no_mangle] pub unsafe extern "C" fn fixture_reset_genuine_arena(){unsafe{
 let head=core::ptr::addr_of_mut!((*fixture_cpu()).free_list);(*head).next=head;(*head).prev=head;
 let chunk=fixture_arena().cast::<abi::KmallocHeader>();
 mem_helpers::___kmalloc_init_chunk_result(chunk,(65536-size_of::<abi::KmallocHeader>()) as CInt);
 mem_helpers::___kmalloc_insert_chunk_result(head,chunk);
}}
#[no_mangle] pub unsafe extern "C" fn fixture_genuine_free_bytes()->SizeT {unsafe{
 let head=core::ptr::addr_of_mut!((*fixture_cpu()).free_list);let mut p=(*head).next;let mut n=0;
 while p!=head {let h=p.cast::<u8>().sub(offset_of!(abi::KmallocHeader,link)).cast::<abi::KmallocHeader>();
 n+=(*h).size as usize;p=(*p).next;}n
}}
