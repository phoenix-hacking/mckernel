#![feature(c_variadic)]
#![feature(core_intrinsics)]
#![no_std]

use core::panic::PanicInfo;

pub mod abi;
mod abort;
mod affinity;
mod ap;
mod atomic_helpers;
mod bitmap;
mod bitops;
mod builtin_dma;
mod cls;
mod cls_helpers;
mod debug;
mod devobj;
mod fileobj;
mod fork_control_guest;
mod fork_control_registry;
mod freeze;
mod futex;
mod gencore;
mod hash;
mod host_helpers;
mod hugefileobj;
mod ikc_manycore;
mod ikc_master;
mod ikc_queue;
mod init;
mod list_helpers;
mod listeners;
mod llist;
mod lock_helpers;
mod mem_helpers;
mod mikc;
mod numparse;
mod object_helpers;
mod page_alloc;
mod page_helpers;
mod pager;
mod plist;
mod process_helpers;
mod procfs;
mod profile;
mod pte_helpers;
mod rbtree;
mod refcount_helpers;
mod rlimit_helpers;
mod sched_helpers;
mod shmid_helpers;
mod shmobj;
mod smp_ikc;
mod spinlock_helpers;
mod string;
mod syscall_policy;
#[cfg(native_linux_irq_work_v6_12)]
mod native_signal;
#[cfg(native_linux_irq_work_v6_12)]
mod native_fault;
#[cfg(native_linux_irq_work_v6_12)]
mod native_futex;
#[cfg(native_linux_irq_work_v6_12)]
mod native_xstate;
mod sysfs;
#[cfg(native_sysfs_verify)]
#[path = "../../scripts/tests/fixtures/mckernel_guest_sysfs.rs"]
mod sysfs_verify;
mod timer;
mod tofu_uapi;
mod ubsan;
mod waitq;
mod x86_coredump;
mod x86_cpu_helpers;
mod x86_cpu_log_providers;
mod x86_local;
mod x86_memory_helpers;
mod x86_memory_loggers;
mod x86_memory_logger_bridges;
mod x86_perfctr;
mod x86_setup;
mod x86_vsyscall;
#[cfg(native_linux_irq_work_v6_12)]
#[allow(dead_code)]
#[path = "../../host-kernel/native-rust/abi/vdso.rs"]
mod vdso_protocol;
#[cfg(native_linux_irq_work_v6_12)]
mod native_vdso;
#[cfg(native_linux_irq_work_v6_12)]
#[allow(dead_code)]
#[path = "../../host-kernel/native-rust/zero_pages.rs"]
mod zero_pages;
#[cfg(native_linux_irq_work_v6_12)]
mod clone3;
mod xpmem_helpers;
mod zeroobj;

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    unsafe {
        x86_setup::early_panic();
    }
    loop {
        core::hint::spin_loop();
    }
}

#[no_mangle]
pub extern "C" fn mckernel_rust_probe() -> u32 {
    0x5255_5354
}


// Compiler-only readonly ABI witness; no runtime entry or privileged operation is invoked.
#[no_mangle]
#[used]
pub static f03_subset_Rust_ABI: [u64; 20] = [
    core::mem::size_of::<abi::CInt>() as u64,
    core::mem::size_of::<abi::CULong>() as u64,
    core::mem::size_of::<abi::SizeT>() as u64,
    core::mem::size_of::<abi::TimeSpec>() as u64,
    core::mem::align_of::<abi::TimeSpec>() as u64,
    core::mem::offset_of!(abi::TimeSpec, tv_sec) as u64,
    core::mem::offset_of!(abi::TimeSpec, tv_nsec) as u64,
    core::mem::size_of::<abi::SyscallRequest>() as u64,
    core::mem::align_of::<abi::SyscallRequest>() as u64,
    core::mem::offset_of!(abi::SyscallRequest, rtid) as u64,
    core::mem::offset_of!(abi::SyscallRequest, ttid) as u64,
    core::mem::offset_of!(abi::SyscallRequest, valid) as u64,
    core::mem::offset_of!(abi::SyscallRequest, number) as u64,
    core::mem::offset_of!(abi::SyscallRequest, args) as u64,
    core::mem::size_of::<debug::Ddebug>() as u64,
    core::mem::align_of::<debug::Ddebug>() as u64,
    core::mem::offset_of!(debug::Ddebug, file) as u64,
    core::mem::offset_of!(debug::Ddebug, func) as u64,
    core::mem::offset_of!(debug::Ddebug, fmt) as u64,
    core::mem::offset_of!(abi::Mckfd, padding) as u64,
];

// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Compiler-only append to the real crate root, alongside selected mincore cfg.
#[no_mangle]
#[used]
pub static f03_mincore_Rust_ABI: [u64; 21] = [
    core::mem::size_of::<abi::ProcessVm>() as u64,
    core::mem::align_of::<abi::ProcessVm>() as u64,
    core::mem::offset_of!(abi::ProcessVm, address_space) as u64,
    core::mem::offset_of!(abi::ProcessVm, memory_range_lock) as u64,
    core::mem::offset_of!(abi::ProcessVm, page_table_lock) as u64,
    core::mem::offset_of!(abi::ProcessVm, region) as u64,
    core::mem::offset_of!(abi::Thread, vm) as u64,
    core::mem::offset_of!(abi::CpuLocalVar, current) as u64,
    core::mem::offset_of!(abi::AddressSpace, page_table) as u64,
    core::mem::offset_of!(abi::VmRegions, user_start) as u64,
    core::mem::offset_of!(abi::VmRegions, user_end) as u64,
    core::mem::offset_of!(abi::VmRange, start) as u64,
    core::mem::offset_of!(abi::VmRange, end) as u64,
    core::mem::offset_of!(abi::VmRange, memobj) as u64,
    core::mem::offset_of!(abi::VmRange, objoff) as u64,
    core::mem::size_of::<abi::IhkRwSpinlock>() as u64,
    core::mem::align_of::<abi::IhkRwSpinlock>() as u64,
    core::mem::size_of::<abi::IhkSpinlock>() as u64,
    core::mem::align_of::<abi::IhkSpinlock>() as u64,
    core::mem::size_of::<abi::OffT>() as u64,
    core::mem::size_of::<abi::CULong>() as u64,
];
