// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Actual original C vs actual Rust entry/body; provider endpoints are controlled.
#![allow(dead_code)]
use core::ffi::c_void;
use core::ptr::{read_volatile, write};
use std::sync::{Mutex, atomic::{AtomicPtr, Ordering}};
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt, CLong, CULong, SizeT, X86UserContext};
const PAGE_SIZE: CULong = 4096;
const EINVAL: CInt = 22;
const ENOMEM: CInt = 12;
const EFAULT: CInt = 14;
const MINCORE_LOG_INVALID: CInt = 1;
const MINCORE_LOG_LOOKUP_FAILED: CInt = 2;
const MINCORE_LOG_COPY_FAILED: CInt = 3;
const MINCORE_LOG_EXIT: CInt = 4;
type SyscallRwlockFn = unsafe extern "C" fn(*mut c_void);
type MsyncLookupRangeFn = unsafe extern "C" fn(*mut c_void,CULong,CULong)->*mut c_void;
type MincorePteLookupFn = unsafe extern "C" fn(*mut c_void,CULong)->*mut c_void;
type MincorePtePresentFn = unsafe extern "C" fn(*mut c_void)->CInt;
type MincoreMemobjLookupFn = unsafe extern "C" fn(*mut c_void,CULong)->CInt;
type MincoreCopyByteFn = unsafe extern "C" fn(CULong,u8)->CLong;
type MincoreLogFn = unsafe extern "C" fn(CInt,CULong,SizeT,CULong,CInt);
include!("body.ACTUAL-RUST.rs.inc");
include!("getters.ACTUAL-RUST.rs.inc");
unsafe extern "C" {
 fn kprintf(format:*const i8,...)->CInt;
 fn original_sys_mincore(n:CInt,ctx:*mut X86UserContext)->CLong;
 fn fixture_debug_flags(flags:u32);
}
mod debug {
 #[repr(C)] pub struct Ddebug { pub file:*const i8,pub func:*const i8,pub fmt:*const i8,pub line_flags:u32 }
}
static CURRENT: AtomicPtr<abi::CpuLocalVar> = AtomicPtr::new(core::ptr::null_mut());
mod cls { pub unsafe fn get_this_cpu_local_var()->*mut super::abi::CpuLocalVar { super::CURRENT.load(super::Ordering::Relaxed) } }
#[no_mangle]
pub unsafe extern "C" fn get_this_cpu_local_var()->*mut abi::CpuLocalVar { cls::get_this_cpu_local_var() }
mod lock_helpers {
 pub unsafe fn ihk_rwspinlock_read_lock_noirq(p:*mut super::abi::IhkRwSpinlock){super::fixture_lock(1,p.cast())}
 pub unsafe fn ihk_rwspinlock_read_unlock_noirq(p:*mut super::abi::IhkRwSpinlock){super::fixture_lock(2,p.cast())}
}
mod spinlock_helpers {
 pub unsafe fn __ihk_mc_spinlock_lock_noirq(p:*mut super::abi::IhkSpinlock){super::fixture_lock(3,p.cast())}
 pub unsafe fn __ihk_mc_spinlock_unlock_noirq(p:*mut super::abi::IhkSpinlock){super::fixture_lock(4,p.cast())}
}
mod process_helpers {
 pub unsafe fn lookup_process_memory_range(vm:*mut super::abi::ProcessVm,a:u64,b:u64)->*mut super::abi::VmRange{super::fixture_lookup(vm.cast(),a,b).cast()}
}
mod x86_memory_helpers {
 pub unsafe fn ihk_mc_pt_lookup_pte(pt:*mut core::ffi::c_void,a:*mut core::ffi::c_void,s:i32,b:*mut *mut core::ffi::c_void,z:*mut usize,q:*mut i32)->*mut u64{super::fixture_pte(pt,a as u64,s,b.cast(),z.cast(),q.cast()).cast()}
 pub unsafe fn copy_to_user(dst:*mut core::ffi::c_void,src:*const core::ffi::c_void,n:usize)->i32{super::fixture_copy(dst,src,n)}
}
mod pte_helpers { pub unsafe fn pte_is_present(p:*const u64)->i32{super::fixture_present(p.cast_mut().cast())} }
mod object_helpers {
 pub unsafe fn memobj_lookup_page(p:*mut super::abi::Memobj,o:i64,a:i32,b:*mut u64,f:*mut u64)->i32{super::fixture_memobj(p.cast(),o,a,b.cast(),f.cast())}
}
include!("mincore.FROZEN.rs.inc");
#[derive(Clone,Debug,PartialEq,Eq)]
struct Observation { events:Vec<(u8,Vec<u64>)>, formats:Vec<Vec<u8>>, copies:usize }
struct State { observed:Observation,range:bool,pte:bool,vm:usize,ranges:usize,pt:usize,object:usize,vector:usize,hole:u8,entries:[u64;3],object_mask:u8,object_rc:[i32;3],fail_at:usize,fail_rc:i32,huge:bool }
static STATE: Mutex<Option<State>> = Mutex::new(None);
fn with_state<T>(f:impl FnOnce(&mut State)->T)->T {f(STATE.lock().unwrap().as_mut().unwrap())}
fn event(s:&mut State,k:u8,args:&[u64]){s.observed.events.push((k,args.to_vec()));}
#[no_mangle]
pub unsafe extern "C" fn fixture_lock(kind:i32,p:*mut c_void){with_state(|s|{
 let vm=s.vm as *mut abi::ProcessVm;
 match kind {
  1=>{assert!(!s.range&&!s.pte);assert_eq!(p as usize,core::ptr::addr_of_mut!((*vm).memory_range_lock) as usize);s.range=true;},
  2=>{assert!(s.range&&!s.pte);s.range=false;},
  3=>{assert!(s.range&&!s.pte);assert_eq!(p as usize,core::ptr::addr_of_mut!((*vm).page_table_lock) as usize);s.pte=true;},
  4=>{assert!(s.range&&s.pte);s.pte=false;},_=>panic!("unexpected lock code")
 }event(s,kind as u8,&[p as u64]);})}
#[no_mangle]
pub unsafe extern "C" fn fixture_lookup(vm:*mut c_void,a:u64,b:u64)->*mut c_void{with_state(|s|{
 assert!(s.range&&!s.pte);assert_eq!(vm as usize,s.vm);assert_eq!(b,a+1);event(s,5,&[a,b]);
 let i=((a-0x1000)/4096) as usize;if i>=3||s.hole&(1<<i)!=0{return core::ptr::null_mut();}
 (s.ranges as *mut abi::VmRange).add(if s.huge{0}else{i}).cast()
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_pte(pt:*mut c_void,a:u64,shift:i32,b:*mut c_void,z:*mut c_void,q:*mut c_void)->*mut c_void{with_state(|s|{
 assert!(s.range&&s.pte);assert_eq!(pt as usize,s.pt);assert_eq!(shift,0);assert!(b.is_null()&&z.is_null()&&q.is_null());event(s,6,&[a,shift as u64]);
 let i=((a-0x1000)/4096) as usize;let at=if s.huge{0}else{i};
 if s.entries[at]==0{core::ptr::null_mut()}else{(s.pt as *mut u64).add(at).cast()}
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_present(p:*mut c_void)->i32{with_state(|s|{assert!(s.range&&s.pte);let bits=p.cast::<u64>().read();event(s,7,&[bits]);(bits&1!=0) as i32})}
#[no_mangle]
pub unsafe extern "C" fn fixture_memobj(p:*mut c_void,off:i64,align:i32,b:*mut c_void,f:*mut c_void)->i32{with_state(|s|{
 assert!(s.range&&s.pte);assert_eq!(p as usize,s.object);assert_eq!(align,0);assert!(b.is_null()&&f.is_null());
 event(s,8,&[off as u64,align as u64]);let i=((off as u64).wrapping_add(8192)/4096) as usize;assert!(i<3);s.object_rc[i]
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_copy(dst:*mut c_void,src:*const c_void,n:usize)->i32{with_state(|s|{
 assert!(!s.range&&!s.pte,"copy must follow both unlocks");assert_eq!(n,1);let i=dst as usize-s.vector;assert!(i<3);let value=src.cast::<u8>().read();assert!(value<=1);
 s.observed.copies+=1;event(s,9,&[i as u64,value as u64,n as u64]);
 if s.fail_at==s.observed.copies{s.fail_rc}else{dst.cast::<u8>().write(value);0}
})}
#[no_mangle]
pub unsafe extern "C" fn fixture_format(p:*const i8,n:usize){with_state(|s|{s.observed.formats.push(core::slice::from_raw_parts(p.cast(),n).to_vec());})}
unsafe fn zero<T>()->*mut T {
 let p=std::alloc::alloc_zeroed(std::alloc::Layout::new::<T>()).cast::<T>();assert!(!p.is_null());p
}
#[derive(Clone)]
struct Case {start:u64,len:usize,hole:u8,entries:[u64;3],object_mask:u8,object_rc:[i32;3],fail_at:usize,fail_rc:i32,huge:bool,expected_rc:i64,expected:[u8;3]}
fn main(){unsafe{
 let cpu=zero::<abi::CpuLocalVar>();let thread=zero::<abi::Thread>();let vm=zero::<abi::ProcessVm>();let address=zero::<abi::AddressSpace>();let ranges=zero::<[abi::VmRange;3]>().cast::<abi::VmRange>();let object=zero::<abi::Memobj>();
 (*cpu).current=thread;(*thread).vm=vm;(*vm).address_space=address;(*vm).region.user_start=0x1000;(*vm).region.user_end=0x10000;CURRENT.store(cpu,Ordering::Relaxed);
 let base=Case{start:0x1000,len:3*4096,hole:0,entries:[1,0,2],object_mask:0,object_rc:[0,-2,0],fail_at:0,fail_rc:-14,huge:false,expected_rc:0,expected:[1,0,0]};
 let mut cases=vec![base.clone()];
 for (start,len,rc) in [(0x1001,4096,-22),(0,4096,-12),(0x10000,0,-12),(0x1000,usize::MAX,-12),(0x1000,0,0)]{let mut c=base.clone();c.start=start;c.len=len;c.expected_rc=rc;c.expected=[0xaa;3];cases.push(c);}
 for i in 0..3{let mut c=base.clone();c.hole=1<<i;c.expected_rc=-12;for k in i..3{c.expected[k]=0xaa;}cases.push(c);}
 let mut c=base.clone();c.object_mask=7;c.expected=[1,0,1];cases.push(c);
 let mut c=base.clone();c.entries=[0,0,0];c.object_mask=7;c.object_rc=[0,0,-5];c.expected=[1,1,0];cases.push(c);
 let mut c=base.clone();c.huge=true;c.entries=[1|128,0,0];c.expected=[1,1,1];cases.push(c);
 for fail_at in [1,2,3]{for rc in [-14,-5,1]{let mut c=base.clone();c.fail_at=fail_at;c.fail_rc=rc;c.expected_rc=rc as i64;for k in fail_at-1..3{c.expected[k]=0xaa;}cases.push(c);}}
 for (len,expected) in [(1,[1,0xaa,0xaa]),(4097,[1,0,0xaa])]{let mut c=base.clone();c.len=len;c.expected=expected;cases.push(c);}
 let mut comparisons=0;
 for flags in [0,1,128]{fixture_debug_flags(flags);for c in &cases{
  let mut vector=[0xaa;3];let mut entries=c.entries;(*address).page_table=entries.as_mut_ptr().cast();
  for i in 0..3{(*ranges.add(i)).start=if c.huge{0x1000}else{0x1000+i as u64*4096};(*ranges.add(i)).end=if c.huge{0x201000}else{0x2000+i as u64*4096};(*ranges.add(i)).memobj=if c.object_mask&(1<<i)!=0{object}else{core::ptr::null_mut()};(*ranges.add(i)).objoff=-8192+i as i64*4096;}
  let mut ctx: X86UserContext=core::mem::zeroed();ctx.gpr.rdi=c.start;ctx.gpr.rsi=c.len as u64;ctx.gpr.rdx=vector.as_mut_ptr() as u64;
  let entry_pointer=entries.as_mut_ptr() as usize;let vector_pointer=vector.as_mut_ptr() as usize;
  let make=||State{observed:Observation{events:Vec::new(),formats:Vec::new(),copies:0},range:false,pte:false,vm:vm as usize,ranges:ranges as usize,pt:entry_pointer,object:object as usize,vector:vector_pointer,hole:c.hole,entries:c.entries,object_mask:c.object_mask,object_rc:c.object_rc,fail_at:c.fail_at,fail_rc:c.fail_rc,huge:c.huge};
  *STATE.lock().unwrap()=Some(make());let rc=original_sys_mincore(27,&mut ctx);assert_eq!(rc,c.expected_rc);assert_eq!(vector,c.expected);let expected=with_state(|s|{assert!(!s.range&&!s.pte);s.observed.clone()});
  vector.fill(0xaa);*STATE.lock().unwrap()=Some(make());let rc=f03_mincore_candidate::mincore(27,&mut ctx);assert_eq!(rc,c.expected_rc);assert_eq!(vector,c.expected);let actual=with_state(|s|{assert!(!s.range&&!s.pte);s.observed.clone()});assert_eq!(actual,expected);
  if flags==0{assert!(actual.formats.is_empty());}else{assert_eq!(actual.formats.len(),1);}
  comparisons+=1;
 }}
 println!("PASS mincore actual C/Rust residency parity {comparisons} cases; provider arguments, holes, huge-PTE, memobj, copy faults, unlock-before-copy, diagnostic gates");
}}
