"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Source-only adaptation to the current F01 allocator's genuine metadata ABI.
"""
from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent;S=D/'fixture-source';K=Path('/home/holden/mckernel')
m=(K/'kernel/rust/mem_helpers.rs').read_text();p=S/'mem_helpers.rs';s=p.read_text()
# The source closure now contains genuine Rust bridge bodies (F01); remove old
# FFI declarations, never duplicate or replace those new real implementations.
for name in ['mem_kmalloc_track_base_alloc_bridge','mem_kmalloc_track_base_free_bridge','mem_kmalloc_track_lock_bridge','mem_kmalloc_track_unlock_bridge','mem_kmalloc_track_spin_init_bridge','mem_kmalloc_track_log_bridge','mem_kmalloc_invalid_free_bridge']:
 s,n=re.subn(r'(?m)^fn '+name+r'\([^\n]*\n','',s);assert n==1
for name in ['MemLowlevelKmallocMetadata','MemTrackingDebugRecords4']:
 a=m.index('#[repr(C)]\nstruct '+name);b=m.index('\n}',a)+2;s+='\n'+m[a:b]+'\n'
s+='''
unsafe extern "C" {
 static mem_lowlevel_kmalloc_metadata:MemLowlevelKmallocMetadata;
 static mem_kmalloc_track_log_bridge_debug_metadata:MemTrackingDebugRecords4;
 #[link_name="panic"] fn mem_kmalloc_panic(message:*const i8);
 fn cpu_disable_interrupt_save()->CULong;
 fn cpu_restore_interrupt(flags:CULong);
 fn fixture_pages_exhausted(n:CInt,f:CULong,u:CInt)->*mut c_void;
 fn fixture_remote_cpu(cpu:CInt)->*mut c_void;
 fn fixture_corruption(ptr:*mut c_void);
}
// Fixture-owned metadata retains the genuine repr(C) interface and routes only
// physical/IRQ/remote effects to explicitly controlled endpoints. Real tracked,
// chunk splitting/free/consolidation code above is unchanged current source.
#[export_name="mem_lowlevel_kmalloc_metadata"]
static FIXTURE_ALLOCATOR_METADATA:MemLowlevelKmallocMetadata=MemLowlevelKmallocMetadata {
 remote_lock_offset:offset_of!(CpuLocalVar,remote_free_list_lock) as CULong,
 remote_list_offset:offset_of!(CpuLocalVar,remote_free_list) as CULong,
 irq_save:Some(cpu_disable_interrupt_save),irq_restore:Some(cpu_restore_interrupt),
 alloc_pages:Some(fixture_pages_exhausted),get_cpu_local:Some(fixture_remote_cpu),
 remote_lock:Some(mem_kmalloc_track_lock_bridge),
 remote_unlock:Some(mem_kmalloc_track_unlock_bridge),corruption:Some(fixture_corruption),
};
// MEMDEBUG is fixed NULL. These disabled debug records must never be read by
// the genuine tracking body in this qualified subset; no enabled tracking proof.
#[export_name="mem_kmalloc_track_log_bridge_debug_metadata"]
static mut FIXTURE_TRACKING_DEBUG_METADATA:MemTrackingDebugRecords4=MemTrackingDebugRecords4 {
 records:[core::ptr::null_mut();4],flags_byte:27,
};
''';p.write_text(s)
# Replace the historical fixture's now-retired bridge implementations with only
# real metadata-backed arena initialization and fixed MEMDEBUG=NULL storage.
(S/'arena_bindings.rs').write_text('''use core::ffi::c_void;
unsafe extern "C" {fn fixture_cpu()->*mut abi::CpuLocalVar;fn fixture_arena()->*mut c_void;
 fn cpu_disable_interrupt_save()->CULong;fn cpu_restore_interrupt(flags:CULong);}
#[no_mangle] static mut memdebug:*mut i8=core::ptr::null_mut();
#[no_mangle] static mut kmalloc_track_hash:[AbiListHead;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_addr_hash:[AbiListHead;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_track_hash_locks:[abi::IhkSpinlock;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_addr_hash_locks:[abi::IhkSpinlock;256]=unsafe{core::mem::zeroed()};
#[no_mangle] static mut kmalloc_runcount:CInt=0;
#[no_mangle] pub unsafe extern "C" fn get_this_cpu_local_var()->*mut abi::CpuLocalVar {
 unsafe{fixture_cpu()}
}
#[no_mangle] pub unsafe extern "C" fn fixture_reset_genuine_arena(){unsafe{
 let head=core::ptr::addr_of_mut!((*fixture_cpu()).free_list);(*head).next=head;(*head).prev=head;
 let chunk=fixture_arena().cast::<abi::KmallocHeader>();
 mem_helpers::___kmalloc_init_chunk_result(chunk,(65536-size_of::<abi::KmallocHeader>()) as CInt);
 mem_helpers::___kmalloc_insert_chunk_result(head,chunk);
}}
#[no_mangle] pub unsafe extern "C" fn fixture_genuine_free_bytes()->SizeT {unsafe{
 let head=core::ptr::addr_of_mut!((*fixture_cpu()).free_list);let mut p=(*head).next;let mut n=0;
 while p!=head {let h=p.cast::<u8>().sub(offset_of!(abi::KmallocHeader,link)).cast::<abi::KmallocHeader>();
 n+=(*h).size as usize;p=(*p).next;}n
}}
''')
frags=sorted(S.glob('[0-7]-*.rs'))
root='''// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![allow(dead_code,unused_imports)]
mod abi;mod debug;mod spinlock_helpers;mod lock_helpers;mod list_helpers;mod string;mod mem_helpers;
mod process_helpers {
 use crate::abi::{CInt,Thread};const HASH_SIZE:CInt=73;
 include!("hashes.ACTUAL.rs");
 unsafe extern "C" {pub fn hold_thread(t:*mut Thread)->CInt;pub fn release_thread(t:*mut Thread);}
}
mod sched_helpers {unsafe extern "C" {
 pub fn sched_wakeup_thread(t:*mut crate::abi::Thread,states:crate::abi::CInt)->crate::abi::CInt;
}}
use core::mem::{size_of,align_of,offset_of,MaybeUninit};
use core::ptr::null_mut;
use abi::{AbiListHead,CInt,CLong,CULong,SizeT,Thread,Process,SigInfo};
use lock_helpers::McsRwlockNodeIrqsave;
const ESRCH:CInt=3;const EINVAL:CInt=22;const ENOMEM:CInt=12;const EPERM:CInt=1;
const SIGKILL:CInt=9;const SIGSTOP:CInt=19;const SIGCHLD:CInt=17;const SIGCONT:CInt=18;
const PS_RUNNING:CInt=1;const PS_INTERRUPTIBLE:CInt=2;const PS_ZOMBIE:CInt=8;const PS_EXITED:CInt=16;
const PS_STOPPED:CInt=32;const PS_TRACED:CInt=64;const SIGNAL_STOP_CONTINUED:CInt=2;
const CLD_CONTINUED:CInt=6;const IHK_MC_AP_NOWAIT:CULong=2;
unsafe extern "C" {
 fn kprintf(format:*const i8,...)->CInt;
}
include!("sigmask.ACTUAL.rs");
include!("arena_bindings.rs");
'''+''.join('include!("'+p.name+'");\n' for p in frags)+'''
#[no_mangle] pub extern "C" fn fixture_whole_abi(i:usize)->usize {
 let v=[size_of::<Thread>(),align_of::<Thread>(),size_of::<Process>(),align_of::<Process>(),
 size_of::<abi::ProcessHash>(),size_of::<abi::ThreadHash>(),offset_of!(abi::ProcessHash,lock),
 offset_of!(Thread,proc),offset_of!(Thread,sigmask),offset_of!(Thread,sigpending),
 offset_of!(Thread,sigpendinglock),offset_of!(Thread,sigcommon),offset_of!(Thread,sigevent),
 offset_of!(Thread,status),offset_of!(Thread,refcount),offset_of!(Thread,cpu_id),
 offset_of!(Process,threads_list),offset_of!(Process,threads_lock),offset_of!(Process,update_lock),
 offset_of!(Process,pid),offset_of!(Process,pgid),offset_of!(Process,parent),offset_of!(Process,main_thread),
 offset_of!(Process,ruid),offset_of!(Process,euid),offset_of!(Process,suid),offset_of!(Process,status),
 size_of::<abi::SigCommon>(),offset_of!(abi::SigCommon,sigpending),size_of::<abi::SigPending>(),
 offset_of!(abi::SigPending,info),offset_of!(abi::SigPending,ptracecont),size_of::<SigInfo>(),
 size_of::<abi::ResourceSet>(),offset_of!(abi::ResourceSet,process_hash),offset_of!(abi::ResourceSet,thread_hash),
 size_of::<abi::CpuLocalVar>(),offset_of!(abi::CpuLocalVar,resource_set),offset_of!(abi::CpuLocalVar,no_preempt),
 size_of::<abi::KmallocHeader>(),offset_of!(abi::KmallocHeader,link),offset_of!(abi::KmallocHeader,size),
 size_of::<abi::McsRwlockLock>(),align_of::<abi::McsRwlockLock>(),size_of::<McsRwlockNodeIrqsave>()];v[i]
}
'''
(S/'whole_actual.rs').write_text(root)

def pin(path):
 raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(D/'CURRENT-FIXTURE-ALLOCATOR-ABI.json').write_text(json.dumps(dict(scope=__doc__,actual_mem_source=pin(K/'kernel/rust/mem_helpers.rs'),actual_fixture_mem=pin(S/'mem_helpers.rs'),metadata_structs=['MemLowlevelKmallocMetadata','MemTrackingDebugRecords4'],genuine_bridge_bodies='Current46function closure includes actual F01 base alloc/free/spin/log wrappers. Historical C bridge substitutions removed; actual ___kmalloc/___kfree consume genuine metadata ABI.',controlled='Fixed single-CPU64KiB backing, metadata IRQ/physical exhaustion/remote/corruption effects; actual MEMDEBUG=NULL only. No allocator growth/tracking/panic success credit.',fixtures=[pin(S/'arena_bindings.rs'),pin(S/'whole_actual.rs')],actual_compile=None),indent=2)+'\n')
