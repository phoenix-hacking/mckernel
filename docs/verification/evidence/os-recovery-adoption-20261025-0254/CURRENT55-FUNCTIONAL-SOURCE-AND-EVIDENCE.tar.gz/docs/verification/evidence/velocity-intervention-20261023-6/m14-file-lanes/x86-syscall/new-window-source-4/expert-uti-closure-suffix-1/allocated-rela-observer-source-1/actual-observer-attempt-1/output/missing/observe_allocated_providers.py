"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Offline bounded allocated-RELA observer. No compiler, linker or native execution.
"""
from pathlib import Path
import hashlib,json,os,stat,struct,sys
D=Path(__file__).resolve().parent
MANIFEST=D/'EXACT-ALLOCATED-RELA-OBSERVER.NOT-GRANTED.json'
MAX_OBJECT=32<<20
MAX_RESULT=256<<10
MAX_SYMBOLS=250000
MAX_RELOCATIONS=1000000

def need(ok,message):
    if not ok:raise ValueError(message)

def pin(path):
    path=Path(path);before=path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_size<=MAX_OBJECT,'bounded regular ELF/helper input')
    raw=path.read_bytes();after=path.lstat()
    keys=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_nlink')
    need(all(getattr(before,k)==getattr(after,k) for k in keys),'stable observed input')
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def validate_geometry(path):
    raw=Path(path).read_bytes();need(len(raw)>=64,'ELF header extent')
    h=struct.unpack_from('<16sHHIQQQIHHHHHH',raw)
    need(h[0][:7]==b'\x7fELF\x02\x01\x01' and h[1]==1 and h[2]==62,'ELF64LE x86_64 ET_REL')
    need(h[11]==64 and 0<h[12]<=65535 and h[13]<h[12],'ordinary section table geometry')
    need(h[6]+h[12]*64<=len(raw),'complete section headers')
    sections=[struct.unpack_from('<IIQQQQIIQQ',raw,h[6]+i*64) for i in range(h[12])]
    totals=dict(symbols=0,allocated_relocations=0,excluded_nonallocated_relocations=0)
    for s in sections:
        if s[1]!=8:need(s[4]+s[5]<=len(raw),'complete section payload')
        if s[1]==2:
            need(s[9]==24 and s[5]%24==0 and s[6]<len(sections),'symbol geometry')
            totals['symbols']+=s[5]//24
        if s[1]==4:
            need(s[9]==24 and s[5]%24==0 and s[6]<len(sections) and s[7]<len(sections),'RELA geometry')
            key='allocated_relocations' if sections[s[7]][2]&2 else 'excluded_nonallocated_relocations'
            totals[key]+=s[5]//24
    need(totals['symbols']<=MAX_SYMBOLS,'bounded symbol inventory')
    need(totals['allocated_relocations']<=MAX_RELOCATIONS,'bounded allocated relocation inventory')
    return totals

def allocated_references(elf,targets):
    counts={name:dict(code=0,data=0) for name in targets}
    for sec in elf.sections:
        if sec['type']!=4:continue
        owner=elf.sections[sec['info']]
        if not owner['flags']&2:continue # debug RELA never expanded or reported
        need(sec['link']==elf.table['index'] and sec['entsize']==24,'actual allocated symtab/RELA')
        kind='code' if owner['flags']&4 else 'data'
        for i in range(sec['size']//24):
            offset,info,addend=struct.unpack_from('<QQq',elf.raw,sec['offset']+24*i)
            need(info>>32<len(elf.symbols) and offset<owner['size'],'bounded allocated relocation')
            symbol=elf.symbols[info>>32]
            if symbol['name'] in targets:counts[symbol['name']][kind]+=1
    return counts

def provider(elf,name,owning):
    symbol=elf.sym(name)
    need(symbol['bind']==1 and symbol['type']==2 and 0<symbol['shndx']<len(elf.sections),'unique global function '+name)
    section=elf.sections[symbol['shndx']]
    need(section['flags']&2 and section['flags']&4 and symbol['size']>0,'allocated executable nonempty provider '+name)
    need(symbol['value']+symbol['size']<=section['size'],'complete provider bytes '+name)
    code=elf.payload(section)[symbol['value']:symbol['value']+symbol['size']]
    rels=owning(elf,symbol)
    need(len(rels)<=4096,'bounded provider-owned relocation count')
    # Named target identities/addends remain comparable across ld-r symtab/index
    # remapping. Anonymous section targets remain STRUCTURAL evidence only; do not
    # misrepresent their linker-adjusted addends as full semantic equivalence.
    named=[dict(offset=r['offset'],type=r['type'],target=r['target']['name'],addend=r['addend'])
           for r in rels if r['target']['name'] and r['target']['type']!=3]
    return dict(name=name,bytes=len(code),sha256=hashlib.sha256(code).hexdigest(),
                owning_section=section['name'],owned_relocations=len(rels),
                named_relocations=sorted(named,key=lambda r:(r['offset'],r['target'],r['type'],r['addend'])),
                anonymous_or_section_relocations=len(rels)-len(named))

def main():
    manifest=json.loads(MANIFEST.read_text());result_path=Path(manifest['result_path'])
    need(result_path.parent==D and not result_path.exists(),'fresh bounded result')
    need(manifest['status']=='SOURCE_ONLY_NOT_GRANTED_NOT_RUN','fixed prepared source manifest')
    need(pin(Path(__file__))==manifest['observer'],'exact observer source self-binding')
    for row in manifest['inputs']+[manifest['accepted_primitives']]:need(pin(row['path'])==row,'exact observer frozen input '+row['path'])
    helper=Path(manifest['accepted_primitives']['path']);space={'struct':struct}
    exec(compile(helper.read_text(),str(helper),'exec'),space)
    Elf=space['Elf'];owning=space['owning_relocations'];targets=manifest['required_providers']
    report=dict(scope=__doc__,status='FAIL_STOP_PRESERVE_RETAINED_OBJECTS',compiler_invocations=0,linker_invocations=0,
                debug_RELA_excluded=True,current_union=False,production_native=False)
    code=1
    try:
        geometry={k:validate_geometry(v) for k,v in manifest['objects'].items()}
        elfs={k:Elf(Path(v)) for k,v in manifest['objects'].items()}
        witnesses=[]
        for name in targets:
            before=provider(elfs['Rust'],name,owning);after=provider(elfs['partial'],name,owning)
            need(before['bytes']==after['bytes'] and before['sha256']==after['sha256'],'retained provider exact code bytes '+name)
            need(before['named_relocations']==after['named_relocations'],'retained provider named-target RELA '+name)
            need(before['owned_relocations']==after['owned_relocations'],'retained provider relocation geometry '+name)
            for consumer in ('kernel_C','arch_C'):
                need(not [s for s in elfs[consumer].symbols if s['name']==name and s['shndx']!=0],
                     'no selected C provider '+name)
            witnesses.append(dict(Rust=before,partial=after))
        counts={k:allocated_references(e,set(targets)) for k,e in elfs.items()}
        for name in targets:
            for kind in ('code','data'):
                expected=sum(counts[k][name][kind] for k in ('Rust','kernel_C','arch_C'))
                need(counts['partial'][name][kind]==expected,'preserved allocated incoming RELA '+name+' '+kind)
        need(sum(counts['partial']['do_kill'].values())>0,'actual allocated references to public do_kill')
        for row in manifest['inputs']+[manifest['accepted_primitives']]:need(pin(row['path'])==row,'immutable post-observer input '+row['path'])
        report.update(status='PASS_EXACT_PRIVATE_EIGHT_PROVIDERS_ALLOCATED_RELA_ONLY',providers=witnesses,
                      allocated_incoming_counts=counts,geometry=geometry,
                      precise_scope='Eight unique Rust definitions, unchanged code bytes/named-target owning RELA, allocated incoming code/data RELA count conservation. Anonymous section-target addends and runtime semantic behavior remain unqualified.')
        code=0
    except BaseException as error:report['error']=type(error).__name__+': '+str(error)
    raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
    need(len(raw)<=MAX_RESULT,'bounded observer result cap')
    fd=os.open(result_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    print(json.dumps(dict(status=report['status'],error=report.get('error'),result=str(result_path),bytes=len(raw)),sort_keys=True))
    return code

if __name__=='__main__':raise SystemExit(main())
