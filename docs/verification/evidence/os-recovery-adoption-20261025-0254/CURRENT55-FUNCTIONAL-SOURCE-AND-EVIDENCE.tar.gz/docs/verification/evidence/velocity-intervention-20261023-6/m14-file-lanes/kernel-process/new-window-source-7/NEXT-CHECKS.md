Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This source-only candidate layers seven distinct selected C provider ports on the
explicit, still separately reviewed source6 overlay. Its C/Rust diffs apply to
source6 C3330ba92/Rust5dfcc6cc; they must not overwrite a changed canonical or
corrected source6 body. Canonical120f75ec/4efa2509 remains separately bound.

The four IRQ-saving reader/writer bridges call the same existing Rust lock
providers. Caller lock/node addresses, pair order and IRQ-save owner remain
unchanged. The hold-thread callback still ignores the existing int result; both
TID callbacks forward identical arguments to the existing Rust lifecycle bodies.
All original C bodies remain selected in the existing C fallback. No metadata,
getter, shared policy, counter/ref operation or lock algorithm is added.

Before any execution, obtain root's ordinary CPU grant and revalidate all source,
compiler and actual-header bindings. First type-check the current full crate with
the exact source6+source7 process override while retaining current F03/policy and
the canonical CPU-local7912 layout. The explicit representation casts need an
independent ownership/IRQ-node review; no new protection is claimed by this port.

`NEXT-EXACT-PARITY.NOT-GRANTED.json` gives four exact argv arrays for the focused
fixture. It compiles the original C bodies against genuine current kernel
headers, compiles the exact new Rust bodies with genuine source-bound ABI/MCS
types, links, then executes. The fixture is not yet compiled or run.

Expected final stdout:

```
PASS actual-original-C/Rust MCS/TID providers: 30 comparisons, 12 genuine ABI rows, matching lock/node/IRQ state and lifecycle forwarding
```

The fixture covers both reader/writer pairs, two locks/nodes, saved IRQ states0
and0x202, matching node restoration and later pair reuse. Two thread pointers and
three controlled hold results verify that the void callback preserves forwarding.
Two process/thread pairs and three ordinary replacement TIDs cover the exact TID
arguments and one-call sequencing. Real headers and extracted actual Rust types
provide twelve size/alignment/field/width rows, including actual64-byte/aligned64
locks and nodes with first-field offsets0 and canonical CPU-local offset7912.

Backend effects are controlled host observations. They do not exercise hardware
interrupts, real lock contention, real TID-table mutation or final destruction.
After parity/type/ownership checks, use a fresh granted selected/fallback C plus
current full Rust-object/strict-partial check for these seven exports. Root owns
canonical integration and later matching current-default-image/native proof.
