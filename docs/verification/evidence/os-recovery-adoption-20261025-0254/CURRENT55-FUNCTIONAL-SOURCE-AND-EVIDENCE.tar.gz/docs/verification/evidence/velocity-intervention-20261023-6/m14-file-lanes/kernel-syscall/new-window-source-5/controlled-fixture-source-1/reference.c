/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <page.h>
#include <ihk/lock.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
#include <lwk/stddef.h>
extern int vsnprintf(char *,size_t,const char *,va_list);
extern void fixture_format(const char *,size_t);
extern int fixture_verify(struct process_vm *,const void *,size_t);
extern void fixture_lock(int,void *);
extern int fixture_smp(cpu_set_t *,smp_func_t,void *);
extern long syscall_copy_from_user_bridge(void *,unsigned long,size_t);
extern long syscall_copy_to_user_bridge(unsigned long,const void *,size_t);
extern void *syscall_alloc_bridge(size_t,unsigned long);
extern void syscall_mckfd_free_bridge(void *);
extern unsigned long syscall_rdtsc_bridge(void);
int kprintf(const char *format,...) {
 char bytes[512];va_list args;va_start(args,format);
 int n=vsnprintf(bytes,sizeof(bytes),format,args);va_end(args);
 if(n>=0 && (size_t)n<sizeof(bytes)) fixture_format(bytes,(size_t)n);
 return n;
}
static void fixture_table_lock(void *p){fixture_lock(1,p);}
static void fixture_table_unlock(void *p){fixture_lock(2,p);}
typedef int (*move_pages_verify_fn_t)(struct process_vm *vm,
		unsigned long addr, size_t bytes);
typedef int (*move_pages_get_nr_nodes_fn_t)(void);
typedef int (*move_pages_smp_call_fn_t)(void *cpu_set, smp_func_t handler,
		void *arg);
typedef void (*move_pages_log_fn_t)(int event, unsigned long value,
		int error);
typedef long (*syscall_copy_from_user_fn_t)(void *dst,
		unsigned long src_addr, size_t bytes);
typedef long (*syscall_copy_to_user_fn_t)(unsigned long dst_addr,
		const void *src, size_t bytes);
typedef void *(*syscall_policy_alloc_fn_t)(size_t size, unsigned long flags);
typedef void (*syscall_mckfd_free_fn_t)(void *fdp);
typedef void (*syscall_rwlock_fn_t)(void *lock);
typedef unsigned long (*syscall_rdtsc_fn_t)(void);
extern long move_pages_body_result(int pid, unsigned long count,
		unsigned long user_virt_addr_addr, unsigned long user_nodes_addr,
		unsigned long user_status_addr, int flags, struct process_vm *vm,
		void *page_table_lock, void *cpu_set, void *proc,
		unsigned long alloc_flags, size_t ptr_size, size_t int_size,
		size_t pte_size, size_t ulong_size,
		move_pages_verify_fn_t verify_fn,
		syscall_copy_from_user_fn_t copy_from_fn,
		syscall_copy_to_user_fn_t copy_to_fn,
		syscall_policy_alloc_fn_t alloc_fn,
		syscall_mckfd_free_fn_t free_fn,
		move_pages_get_nr_nodes_fn_t get_nr_nodes_fn,
		syscall_rwlock_fn_t lock_fn, syscall_rwlock_fn_t unlock_fn,
		move_pages_smp_call_fn_t smp_call_fn, smp_func_t handler_fn,
		syscall_rdtsc_fn_t rdtsc_fn, move_pages_log_fn_t log_fn);
#undef verify_process_vm
#define verify_process_vm fixture_verify
#undef ihk_mc_spinlock_lock_noirq
#define ihk_mc_spinlock_lock_noirq fixture_table_lock
#undef ihk_mc_spinlock_unlock_noirq
#define ihk_mc_spinlock_unlock_noirq fixture_table_unlock
#undef smp_call_func
#define smp_call_func fixture_smp
#define sys_move_pages original_sys_move_pages
#define MOVE_PAGES_LOG_UNSUPPORTED_PID 1
#define MOVE_PAGES_LOG_UNSUPPORTED_MOVE_ALL 2
#define MOVE_PAGES_LOG_INIT_MALLOC 3
#define MOVE_PAGES_LOG_INIT_VERIFY 4
#define MOVE_PAGES_LOG_PARALLEL 5
#include "entry.ACTUAL-C.inc"
