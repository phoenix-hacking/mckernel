"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure exact-selector and unchanged descriptor/consumer rejection fixtures, no ELF files.
"""
from pathlib import Path
import ast
import copy
import hashlib
import json
import struct
D = Path(__file__).parent
P = D.parent
source = D / "observe_new_metadata.EXACT-DECLARED-SYMBOLS.py"
t = ast.parse(source.read_bytes())
selected = [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in {"exact_declared_debug", "cstring", "descriptor", "allocated_edges"} or isinstance(n, ast.Assign) and any(isinstance(x, ast.Name) and x.id == "DECLARED_DEBUG_SYMBOLS" for x in n.targets)]
ns = dict(struct=struct)
exec(compile(ast.Module(body=selected, type_ignores=[]), str(source), "exec"), ns)
contract = json.loads((P / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
row = contract["Elf_source"]
raw = Path(row["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
tree = ast.parse(raw)
helpers = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in {"object_bytes", "owning_relocations"}]
exec(compile(ast.Module(body=helpers, type_ignores=[]), row["path"], "exec"), ns)
NAMES = ns["DECLARED_DEBUG_SYMBOLS"]
LINES = {"ENTER_DEBUG": 33307, "IPI_DEBUG": 32831}
FILENAME = "/frozen/syscall_policy.rs"
class SyntheticElf:
    def __init__(self):
        names = ["", NAMES["ENTER_DEBUG"], NAMES["IPI_DEBUG"], ".rodata"]
        self.symbols = [dict(index=i, name=name, bind=1 if i in (1,2) else 0, type=1 if i in (1,2) else (3 if i==3 else 0), shndx=1 if i in (1,2) else (2 if i==3 else 0), value=32 if i==2 else 0, size=32 if i in (1,2) else 0) for i,name in enumerate(names)]
        metadata = b"".join(bytes(24) + struct.pack("<I", LINES[m]) + bytes(4) for m in ("ENTER_DEBUG", "IPI_DEBUG"))
        strings = FILENAME.encode() + b"\0do_kill\0"
        self.function_offset = len(FILENAME.encode()) + 1
        self.symbol_offset = len(metadata) + len(strings)
        symbols = b"".join(struct.pack("<IBBHQQ",0,(r["bind"]<<4)|r["type"],0,r["shndx"],r["value"],r["size"]) for r in self.symbols)
        self.verbose_rela_offset = self.symbol_offset + len(symbols)
        relas = b"".join(struct.pack("<QQq",off,(3<<32)|1,add) for off,add in ((0,0),(8,self.function_offset),(32,0),(40,self.function_offset)))
        text_offset = self.verbose_rela_offset + len(relas)
        consumer_offset = text_offset + 16
        consumers = struct.pack("<QQq",0,(1<<32)|1,24) + struct.pack("<QQq",8,(2<<32)|1,24)
        self.raw = bytearray(metadata + strings + symbols + relas + bytes(16) + consumers)
        def section(index, name, typ, flags, offset, size, align=1, info=0, link=0, entsize=0):
            return dict(index=index,name=name,type=typ,flags=flags,offset=offset,size=size,align=align,info=info,link=link,entsize=entsize)
        self.sections = [section(0,"",0,0,0,0),section(1,"__verbose",1,3,0,64,8),section(2,".rodata",1,2,64,len(strings)),section(3,".rela.__verbose",4,0,self.verbose_rela_offset,len(relas),8,1,4,24),section(4,".symtab",2,0,self.symbol_offset,len(symbols),8,0,0,24),section(5,".text",1,6,text_offset,16,8),section(6,".rela.text",4,0,consumer_offset,len(consumers),8,5,4,24)]
        self.table = self.sections[4]
    def payload(self, section):
        return bytes(self.raw[section["offset"]:section["offset"]+section["size"]])
def validate(elf, marker="ENTER_DEBUG"):
    symbol = ns["exact_declared_debug"](elf, marker)
    ns["descriptor"](elf, symbol, FILENAME, "do_kill", LINES[marker])
    ns["allocated_edges"](elf, symbol=symbol)
    return symbol["name"]
cases = []
e = SyntheticElf()
assert [validate(e,m) for m in ("ENTER_DEBUG","IPI_DEBUG")] == [NAMES["ENTER_DEBUG"],NAMES["IPI_DEBUG"]]
cases.append(dict(case="two expected declared records and allocated consumers",status="PASS"))
for name in ("other_module::ENTER_DEBUG","F06_PTRACE_SIGNAL_ENTER_DEBUG",NAMES["ENTER_DEBUG"]+"_suffix"):
    r = dict(e.symbols[1]);r["name"]=name;r["index"]=len(e.symbols);e.symbols.append(r)
assert validate(e)==NAMES["ENTER_DEBUG"] and validate(e,"IPI_DEBUG")==NAMES["IPI_DEBUG"]
cases.append(dict(case="unrelated sameleaf othermodule and suffix distractors ignored",status="PASS"))
def rejected(label, mutate):
    e = SyntheticElf()
    mutate(e)
    try:
        validate(e)
    except AssertionError:
        cases.append(dict(case=label,status="PASS_REJECTED"))
    else:
        raise AssertionError(label + " unexpectedly accepted")
rejected("only unrelated sameleaf",lambda e:e.symbols[1].update(name="F06_PTRACE_SIGNAL_ENTER_DEBUG"))
rejected("wrong declared module",lambda e:e.symbols[1].update(name=NAMES["ENTER_DEBUG"].replace("f06_full_do_kill_candidate","different_module")))
rejected("wrong mangled leaf",lambda e:e.symbols[1].update(name=NAMES["ENTER_DEBUG"]+"_suffix"))
rejected("missing exact declared record",lambda e:e.symbols.pop(1))
rejected("duplicate exact declared name",lambda e:e.symbols.append(dict(e.symbols[1])))
rejected("LOCAL binding",lambda e:e.symbols[1].update(bind=0))
rejected("UND record",lambda e:e.symbols[1].update(shndx=0))
rejected("nonOBJECT record",lambda e:e.symbols[1].update(type=2))
rejected("COMMON reserved index",lambda e:e.symbols[1].update(shndx=0xfff2))
rejected("visibility drift",lambda e:e.raw.__setitem__(e.symbol_offset+24+5,2))
rejected("wrong aligned symbol value",lambda e:e.symbols[1].update(value=8))
rejected("wrong initializer byte",lambda e:e.raw.__setitem__(0,1))
rejected("wrong line or flags",lambda e:struct.pack_into("<I",e.raw,24,33308))
rejected("wrong filename relocation target bytes",lambda e:e.raw.__setitem__(64,ord("x")))
rejected("wrong function relocation target bytes",lambda e:e.raw.__setitem__(64+e.function_offset,ord("x")))
rejected("missing metadata RELA",lambda e:e.sections[3].update(size=0))
rejected("malformed metadata RELA type",lambda e:struct.pack_into("<Q",e.raw,e.verbose_rela_offset+8,(3<<32)|2))
rejected("duplicate metadata RELA owner",lambda e:struct.pack_into("<Q",e.raw,e.verbose_rela_offset+48,0))
rejected("missing allocated consumer edge",lambda e:e.sections[6].update(size=0))
rejected("wrong 32byte record size",lambda e:e.symbols[1].update(size=31))
rejected("wrong writable allocated section flags",lambda e:e.sections[1].update(flags=2))
rejected("wrong record section alignment",lambda e:e.sections[1].update(align=4))
result=dict(scope="Functional McKernel OS/apps and Rust/assembly migration only; no security testing.",status="PASS_PURE_EXACT_DECLARED_DEBUG_SELECTOR_AND_UNCHANGED_DESCRIPTOR_REJECTIONS",cases=cases,count=len(cases),retained_ELF_read=False,compiler=False)
with (D / "ACTUAL-PURE-EXACT-DEBUG-CASES.json").open("x") as out:
    json.dump(result,out,sort_keys=True,indent=2)
    out.write("\n")
print(json.dumps(dict(status=result["status"],count=len(cases))))
