/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
extern int printf(const char *,...);extern int dprintf(int,const char *,...);extern void abort(void);
extern int posix_memalign(void **,size_t,size_t);extern void free(void *);
#define require(v) do{if(!(v)){dprintf(2,"FAIL scheduler lifetime line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
struct sched_syscall_offsets {
 size_t thread_proc_offset,thread_sched_param_offset,thread_sched_policy_offset,thread_cpu_id_offset,thread_cpu_set_offset;
 size_t proc_pid_offset,proc_ruid_offset,proc_euid_offset,proc_cpu_set_offset;
};
typedef unsigned long (*sched_find_thread_fn_t)(int);
typedef void (*sched_thread_unlock_fn_t)(unsigned long);
typedef long (*syscall_copy_to_user_fn_t)(unsigned long,const void *,size_t);
extern long sched_rr_get_interval_retained_v2(int,unsigned long,unsigned long,const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t,syscall_copy_to_user_fn_t);
typedef long (*rr_query_v2_t)(int,unsigned long,unsigned long,const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t,syscall_copy_to_user_fn_t);
_Static_assert(__builtin_types_compatible_p(__typeof__(&sched_rr_get_interval_retained_v2),rr_query_v2_t),"RR query v2 ABI");
_Static_assert(sizeof(long)==8,"actual fullwidth usercopy result");
extern const unsigned long f03_rr_query_Rust_ABI[18];
const unsigned long f03_rr_query_C_ABI[18]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_policy),sizeof(struct process),__alignof__(struct process),__builtin_offsetof(struct process,pid),sizeof(struct timespec),__alignof__(struct timespec),__builtin_offsetof(struct timespec,tv_sec),__builtin_offsetof(struct timespec,tv_nsec),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(syscall_copy_to_user_fn_t),sizeof(long),__alignof__(long)};
static const struct sched_syscall_offsets offsets={__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,cpu_id),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct process,pid),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),__builtin_offsetof(struct process,cpu_set)};
static struct thread self;
static struct process self_proc,target_proc;
static struct thread *selected;
static int reference_count,lookup_edge,hash_edge,find_count,unlock_count,copy_count,alloc_count,free_count;
static int requested_pid,configuration,exit_phase,foreign_case,current_pid,target_policy,initial_current_policy;
static long copy_result;
static struct timespec output;
static unsigned long retired_address;
static void destroy_if_last(void){
 if(selected&&reference_count==0){require(!lookup_edge&&!hash_edge);retired_address=(unsigned long)selected;__builtin_memset(selected,0xdd,sizeof(*selected));free(selected);selected=NULL;free_count++;}
}
static void drop_hash_owner(void){require(hash_edge&&reference_count>0);hash_edge=0;reference_count--;destroy_if_last();}
static unsigned long actual_find(int pid){
 require(foreign_case&&pid==requested_pid&&!selected&&reference_count==0);find_count++;
 if(configuration==7)return 0;
 void *allocation=NULL;size_t alignment=__alignof__(struct thread);if(alignment<sizeof(void *))alignment=sizeof(void *);
 require(posix_memalign(&allocation,alignment,sizeof(*selected))==0&&allocation);selected=allocation;memset(selected,0,sizeof(*selected));alloc_count++;
 target_proc.pid=pid;
 selected->proc=&target_proc;selected->sched_policy=target_policy;
 /* Real allocated struct thread, two modeled positive owners; no fake object or
  * temporary Thread is passed through an incompatible old callback signature. */
 reference_count=2;lookup_edge=hash_edge=1;
 if(exit_phase==1)drop_hash_owner();
 require(selected&&lookup_edge&&reference_count>=1);return (unsigned long)selected;
}
static void actual_unlock(unsigned long address){
 require(lookup_edge&&selected&&(unsigned long)selected==address&&reference_count>=1);unlock_count++;lookup_edge=0;reference_count--;destroy_if_last();
}
static long actual_copy(unsigned long dst,const void *source,size_t bytes){
 require((dst==(unsigned long)&output||dst==0)&&bytes==sizeof(output)&&source);copy_count++;
 if(foreign_case){
  require(selected&&lookup_edge&&reference_count>=1&&!retired_address);
  if(exit_phase==2)drop_hash_owner();
  require(selected&&lookup_edge&&reference_count>=1&&!retired_address);
  require((unsigned long)source<(unsigned long)selected||(unsigned long)source>=(unsigned long)selected+sizeof(*selected));
  /* Interval captured before copy; a later controlled policy change must not
   * change that initialized TimeSpec or cause another thread read after release. */
  selected->sched_policy=target_policy==2?0:2;
 }else{require(!selected&&!lookup_edge);self.sched_policy=initial_current_policy==2?0:2;}
 struct timespec wanted={.tv_sec=0,.tv_nsec=(foreign_case?target_policy:initial_current_policy)==2?10000:0};
 require(!memcmp(source,&wanted,sizeof(wanted)));
 if(!dst)return -EFAULT;
 if(copy_result==0)memcpy((void *)dst,source,bytes);
 else if(copy_result==1)memcpy((void *)dst,source,bytes/2);
 return copy_result;
}
static void reset(int pid,int caller,int config,int phase,long result,int policy){
 require(!selected&&!reference_count&&!lookup_edge&&!hash_edge);
 memset(&self,0,sizeof(self));memset(&self_proc,0,sizeof(self_proc));memset(&target_proc,0,sizeof(target_proc));
 self.proc=&self_proc;self_proc.pid=caller;target_policy=policy;initial_current_policy=policy==2?0:2;self.sched_policy=initial_current_policy;
 requested_pid=pid;current_pid=caller;configuration=config;exit_phase=phase;copy_result=result;
 foreign_case=pid!=0&&pid!=caller;find_count=unlock_count=copy_count=alloc_count=free_count=0;retired_address=0;output.tv_sec=-111;output.tv_nsec=-222;
}
static long expected(void){
 if(requested_pid<0||current_pid<0||configuration==3||configuration==4||configuration==5)return -EINVAL;
 if(foreign_case&&(configuration==1||configuration==2))return -EINVAL;
 if(foreign_case&&configuration==7)return -ESRCH;
 return configuration==6||copy_result?-EFAULT:0;
}
static void check(long rc){
 require(rc==expected());
 int reaches_selection=requested_pid>=0&&current_pid>=0&&configuration!=3&&configuration!=4&&configuration!=5;
 int looked=reaches_selection&&foreign_case&&configuration!=1&&configuration!=2;
 int acquired=looked&&configuration!=7;
 require(find_count==looked&&unlock_count==acquired&&alloc_count==acquired);
 int copied=reaches_selection&&(!foreign_case||acquired);require(copy_count==copied);
 struct timespec initial={.tv_sec=-111,.tv_nsec=-222},wanted={.tv_sec=0,.tv_nsec=(foreign_case?target_policy:initial_current_policy)==2?10000:0};
 if(rc==0)require(!memcmp(&output,&wanted,sizeof(output)));
 if(copied&&rc==-EFAULT){
  if(configuration!=6&&copy_result==1){size_t prefix=sizeof(output)/2;require(!memcmp(&output,&wanted,prefix));require(!memcmp((unsigned char *)&output+prefix,(unsigned char *)&initial+prefix,sizeof(output)-prefix));}
  else require(!memcmp(&output,&initial,sizeof(output)));
 }
 require(!lookup_edge&&reference_count==hash_edge);
 if(selected)drop_hash_owner();
 require(!selected&&!reference_count&&!hash_edge&&free_count==alloc_count);
}
int main(void){
 require(!memcmp(f03_rr_query_C_ABI,f03_rr_query_Rust_ABI,sizeof(f03_rr_query_C_ABI)));
 const int pids[]={-1,0,17,23,2147483647};const int callers[]={17,0,-1};const int policies[]={0,2,5};
 const long copies[]={0,1,-1,2147483648L,4294967296L,-4294967296L};unsigned tested=0;
 for(unsigned p=0;p<5;p++)for(unsigned c=0;c<3;c++)for(int config=0;config<8;config++)for(unsigned ret=0;ret<6;ret++)for(int phase=0;phase<3;phase++)for(unsigned policy=0;policy<3;policy++){
  reset(pids[p],callers[c],config,phase,copies[ret],policies[policy]);
  long rc=sched_rr_get_interval_retained_v2(pids[p],config==6?0:(unsigned long)&output,config==5?0:(unsigned long)&self,config==4?NULL:&offsets,config==1?NULL:actual_find,config==2?NULL:actual_unlock,config==3?NULL:actual_copy);check(rc);tested++;
 }
 require(tested==6480);printf("PASS RR interval retained queries6480 ABI18 policy/time/exit-during-copy/fullwidth-fault/null-utime/current-pid0/unlock-once allocator-balanced controlled-only\n");return 0;
}
