Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source finding: the actual sched_rr_get_interval_body_result uses the same
sched_select_thread that releases a foreign lookup edge before returning its
pointer. RR then reads sched_policy from that released allocation to compute its
TimeSpec. This is the remaining interval consumer identified by Source22/23;
no native crash or OS result is inferred from this source finding.

Private sched_rr_get_interval_retained_v2 uses Source23's exact unchanged guard
and selector bytes, with source-span/hash provenance. It does not edit accepted
Source23 files or copy/reimplement its getter exports. Only the common guard and
query selection are reused in this new module. The actual interval policy helper
is reused unchanged too. Current/pid0 selects the original current thread without
another lookup edge; positive foreign lookup transfers one reference to the same
noncopyable guard. Policy is read under that lifetime, a complete initialized
TimeSpec is captured, genuine generic usercopy runs while the reference is still
retained, then the exact matching unlock releases it once. No hash/IRQ lock is
held across copy, and no thread pointer is used after release. No second lookup,
extra hold, fake Thread, invented allocator or usercopy ABI cast is introduced.

The old RR helper deliberately does NOT reject zero utime locally. This repair
preserves that ordering: PID/current/offset/copy-provider/lookup errors happen
first, then actual usercopy receives the zero address and determines its fault.
Current-pid normalization, missing providers, NULL lookup, policy==SCHED_RR interval
10000ns versus zero for other policies, tv_sec0 and nonzero full-width C-long copy
result -> EFAULT remain unchanged. V2 export naming is explicit; its argument and
provider signature match the old RR ABI. All new compute logic is Rust. Proposed
C change is a declaration only. The default-OFF patches affect the new module and
this one Rust RR entry, leaving Source23 getters and Source24 setter owner disjoint.

Prepared genuine functional regression:18 actual C/Rust Thread/Process/TimeSpec/
offset/provider/long geometry words plus versioned C function type checking.
6480 queries cover5PIDs x3current-PID states x8provider/null/notfound configurations
x6full-width copy results x3exit phases x3policy choices. Actual aligned C Thread
allocation and distinct hash/lookup references reuse qualified Source23 fixture
patterns. Hash-owner exit can occur immediately after lookup or inside copy before
any source read; lookup ownership must still pin the same allocation. The copy
provider also changes policy AFTER TimeSpec capture to verify the output remains
the captured interval. The callback reads a genuine initialized local TimeSpec,
never a fabricated Thread. Oracles check null-utime precedence, RR/non-RR scalar
capture, exact timespec bytes, partial-copy effects, ±2^32 error width, no extra
current/pid0 edge, find/unlock pairing, and actual aligned allocation/free balance.
No freed bytes or old unsafe consumer are read/executed as counterexamples.

This preserves lifetime only. Concurrent policy-field writes, scheduler locking,
actual positive lookup production selection, current fullcrate/entry/link and
native process-exit behavior remain unassessed/open. The fixture's controlled
reference protocol does not prove those native boundaries. Source22 positive
acquisition remains a dependency; Source23/24 other consumers are not replayed.

Next exact check: one private Rust-object compile, genuine-header C link, then the
6480-query/ABI18 regression under a fresh actual ordinary CPU0 grant and retained
h990 AS2G/sharedCPU60/wall90+6/F32/FD256/stack2M/core0/floors. The tuple includes
explicit taskset -c 0 plus source-FD authentication. No compiler, fixture, root,
query, native, cleanup or canonical edit has occurred for Source25.
