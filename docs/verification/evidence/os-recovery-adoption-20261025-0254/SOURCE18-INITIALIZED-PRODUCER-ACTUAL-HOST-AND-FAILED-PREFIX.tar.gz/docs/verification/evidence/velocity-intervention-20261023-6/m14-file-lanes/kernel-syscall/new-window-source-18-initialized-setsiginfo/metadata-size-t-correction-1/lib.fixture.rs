// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
use core::ffi::c_void;
use core::mem::{size_of,MaybeUninit,ManuallyDrop};
use core::ptr::{addr_of,read_volatile};
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt,CLong,CULong,SizeT,SigInfo,SigInfoKill};
#[repr(C, align(64))]
pub struct McsRwlockNodeIrqsave {
    irqsave: CULong,
}
type PtraceFindThreadFn = unsafe extern "C" fn(CInt, CInt) -> CULong;
type PtraceThreadUnlockFn = unsafe extern "C" fn(CULong);
type PtraceControlLogFn = unsafe extern "C" fn(CInt, CInt, CInt);
type PtraceSavedContextClearFn = unsafe extern "C" fn(CULong, CULong) -> CInt;
type PtraceSetSingleStepFn = unsafe extern "C" fn(CULong);
type PtraceRwlockFn = unsafe extern "C" fn(CULong, *mut c_void);
type PtraceTraceSyscallUpdateFn = unsafe extern "C" fn(CULong, CULong, CInt) -> CInt;
type PtracePendingSignalTakeFn = unsafe extern "C" fn(CULong, CULong, CULong, CInt) -> CULong;
type PtraceFreeFn = unsafe extern "C" fn(*mut c_void);
type PtraceDoKillThreadFn =
    unsafe extern "C" fn(*mut c_void, CInt, CInt, CInt, *const SigInfo, CInt) -> CLong;
type PtraceWakeupThreadFn = unsafe extern "C" fn(*mut c_void, CInt);
const EINVAL: CInt = 22;
const EFAULT: CInt = 14;
const ESRCH: CInt = 3;
const SIGKILL: CInt = 9;
const SIGSTOP: CInt = 19;
const NSIG: CInt = 64;
const PTRACE_KILL: CLong = 8;
const PTRACE_CONT: CLong = 7;
const PTRACE_SINGLESTEP: CLong = 9;
const PTRACE_SYSCALL: CLong = 24;
const PTRACE_WAKEUP_ACTION_NONE: CInt = 0;
const PTRACE_WAKEUP_ACTION_KILL: CInt = 1;
const PTRACE_WAKEUP_ACTION_RESUME: CInt = 2;
const PTRACE_RESUME_SIGNAL_SOURCE_USER: CInt = 0;
const PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG: CInt = 1;
const PTRACE_RESUME_SIGNAL_SOURCE_RECVSIG: CInt = 2;
const PTRACE_CONTROL_LOG_WAKEUP_ENTER: CInt = 4;
const PS_TRACED: CInt = 0x40;
const PS_STOPPED: CInt = 0x20;
const SI_USER: CInt = 0;
#[repr(C)]
pub struct PtraceIoOffsets {
    pub thread_proc_offset: SizeT,
    pub thread_status_offset: SizeT,
    pub thread_vm_offset: SizeT,
    pub thread_ptrace_offset: SizeT,
    pub thread_ptrace_eventmsg_offset: SizeT,
    pub thread_ptrace_recvsig_offset: SizeT,
    pub thread_ptrace_sendsig_offset: SizeT,
    pub thread_report_proc_offset: SizeT,
    pub thread_ptrace_saved_uctx_valid_offset: SizeT,
    pub proc_pid_offset: SizeT,
    pub proc_update_lock_offset: SizeT,
}
unsafe extern "C" { fn get_this_cpu_local_var()->*mut abi::CpuLocalVar; }
include!("/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-17-ptrace-wakeup-outer/ACTUAL-UNCHANGED-HELPER-CLOSURE.rs.inc");
include!("/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-17-ptrace-wakeup-outer/ptrace_wakeup_outer.RUST-FRAGMENT.rs.inc");
#[no_mangle]
pub static f03_wakeup_Rust_ABI:[usize;23]=[
    core::mem::size_of::<McsRwlockNodeIrqsave>(),
    core::mem::align_of::<McsRwlockNodeIrqsave>(),
    size_of::<abi::CpuLocalVar>(),
    core::mem::align_of::<abi::CpuLocalVar>(),
    core::mem::offset_of!(abi::CpuLocalVar,current),
    size_of::<PtraceIoOffsets>(),
    core::mem::align_of::<PtraceIoOffsets>(),
    size_of::<f03_ptrace_wakeup_outer_v1::Providers>(),
    core::mem::align_of::<f03_ptrace_wakeup_outer_v1::Providers>(),
    size_of::<abi::SigInfo>(),
    core::mem::align_of::<abi::SigInfo>(),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,find_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,unlock_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,log_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,clear_saved_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,set_single_step_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,lock_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,trace_syscall_update_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,unlock_lock_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,take_pending_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,free_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,do_kill_fn),
    core::mem::offset_of!(f03_ptrace_wakeup_outer_v1::Providers,wakeup_fn),
];

type PtraceUserCopyFromFn = unsafe extern "C" fn(*mut u8, CULong, SizeT) -> CLong;
type SyscallPolicyAllocFn = unsafe extern "C" fn(SizeT, CULong) -> *mut c_void;

const PTRACE_SIGINFO_STORE_SENDSIG: CInt = 0x1;
const PTRACE_SIGINFO_STORE_RECVSIG: CInt = 0x2;
const PTRACE_SIGINFO_ALLOC_SENDSIG: CInt = 0x4;
unsafe fn ptrace_io_status(thread_addr: CULong, offsets: *const PtraceIoOffsets) -> CInt {
    let thread = thread_addr as *mut u8;
    unsafe { read_volatile(field_ptr::<CInt>(thread, (*offsets).thread_status_offset)) }
}

pub extern "C" fn ptrace_status_allows_io(status: CInt) -> CInt {
    if (status & (PS_STOPPED | PS_TRACED)) != 0 {
        1
    } else {
        0
    }
}

#[no_mangle]
pub extern "C" fn ptrace_setsiginfo_target_result(
    status: CInt,
    has_sendsig: CInt,
    has_recvsig: CInt,
) -> CInt {
    if ptrace_status_allows_io(status) == 0 {
        return -ESRCH;
    }

    let mut target = PTRACE_SIGINFO_STORE_SENDSIG;
    if has_sendsig == 0 {
        target |= PTRACE_SIGINFO_ALLOC_SENDSIG;
    }
    if has_recvsig != 0 {
        target |= PTRACE_SIGINFO_STORE_RECVSIG;
    }
    target
}

include!("/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-18-initialized-setsiginfo/setsiginfo_transaction.REUSED-UNCHANGED.rs.inc");
include!("initialized_setsiginfo.RUST-FRAGMENT.rs.inc");
#[no_mangle]
pub static f03_setsiginfo_Rust_ABI:[usize;9]=[size_of::<SigInfo>(),core::mem::align_of::<SigInfo>(),size_of::<f03_initialized_setsiginfo_v3::Providers>(),core::mem::align_of::<f03_initialized_setsiginfo_v3::Providers>(),core::mem::offset_of!(f03_initialized_setsiginfo_v3::Providers,find),core::mem::offset_of!(f03_initialized_setsiginfo_v3::Providers,unlock),core::mem::offset_of!(f03_initialized_setsiginfo_v3::Providers,alloc),core::mem::offset_of!(f03_initialized_setsiginfo_v3::Providers,copy),core::mem::offset_of!(f03_initialized_setsiginfo_v3::Providers,free)];

const ENOMEM:CInt=12;
use core::ptr::{copy_nonoverlapping,write};
