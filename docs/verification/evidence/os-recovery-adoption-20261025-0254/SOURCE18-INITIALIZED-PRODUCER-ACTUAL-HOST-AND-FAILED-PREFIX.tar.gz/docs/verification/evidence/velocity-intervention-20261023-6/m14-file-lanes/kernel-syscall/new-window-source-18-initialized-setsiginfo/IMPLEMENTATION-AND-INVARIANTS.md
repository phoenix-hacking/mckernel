Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This source-only successor reuses setsiginfo_transaction_v2 byte-for-byte from
next-ptrace-setsiginfo-correctness-source-1. It does not duplicate or silently select
that held port. The new f03_ptrace_setsiginfo_initialized_v3 Rust caller provides
two disjoint typed [u8; size_of::<SigInfo>()] snapshots, initialized to zero before
any provider call. It binds genuine pending size/info offset/allocation flags,
PtraceIoOffsets and original find/unlock/allocate/copy/free identities through
immutable metadata. No canonical/default290 or frozen Source17 file is changed.

The initialized-data invariant is: every published info byte is either a previously
initialized existing value or a complete successful copy snapshot. Neither failed
nor partially written copy scratch becomes a published signal. Zero-initialized
scratch remains PRIVATE; zero is never invented as a replacement signal payload.
There is no assume_init and no typed reference to an uninitialized pending node.
Successful copy_from_user still has its original complete-copy contract.

The unchanged v2 transaction allocates a fresh node privately with a genuine free
route, copies both required snapshots before changing either existing target,
commits send then receive info, then publishes fresh sendsig as its final effect.
Allocation error remains ENOMEM before usercopy; failed copy remains EFAULT.
Success preserves both original copy calls and send-then-receive commit order.
Failure deliberately preserves old published pending pointers/info and frees only
our unpublished fresh node, exactly once. This repairs the old error-path early
publication/partial-update behavior; it is not a claim that those defective side
effects were preserved. Reentrant read-only observation during copy sees old state.
No retry, speculative lock, new errno for changed state or imaginary reference is
introduced. Every successful find releases its retained lifetime reference once.

The proposed fixture uses the actual new Rust caller, exact retained transaction,
actual Ptrace target policy and actual Source17 unchanged wakeup helper. It compares
32 genuine ABI words (23 retained wakeup plus9 new signal/table geometry words).
The producer matrix is360 cases:5pending modes (none/send/receive/both/alias),
3copy-failure points,2allocation outcomes,2partial-copy failure modes,2status
states and3PIDs. The independent oracle checks error precedence, copy counts,
no early publication, byte-for-byte old-state preservation, complete successful
snapshots, free ownership/count, retained-reference release and read-only reentrant
observation. After each of the288 nonaliased cases it executes the actual wakeup
consumer under the same controlled initialized-storage contract and checks the
actual info bytes and take/free/kill/unlock order. The72 aliased cases qualify only
producer commit ordering; they DO NOT run a consumer that could leave the second
slot dangling after freeing the aliased node. All storage is ordinary fixture
storage; no native heap/resource or scheduling acceptance is asserted.

Serialization remains a real blocker. find/thread_unlock retain/release a tracee
reference and do not supply a pending-state lock. The fixture deliberately provides
one external exclusive state owner; its callbacks only observe and never mutate
that owner's slots. This proves behavior under that explicit precondition, not
that current kernel callers provide it. No kernel concurrency protocol was added.
The retained CONCURRENCY_HOLD_NOT_SERIALIZED_BY_THREAD_REF and pending-initialization
failure evidence remain authoritative. Before integration, actual do_signal
transfer, getsiginfo, setsiginfo, resume take/free and destruction must share a
ranked ownership/serialization protocol. Faulting copy must stay outside IRQ locks;
commit needs genuine version/pin/authority revalidation with independently accepted
changed-state behavior. Pointer comparison alone cannot prove ABA safety. Aliased
pending ownership and final tracee lifetime likewise need genuine caller proof.

The next executable check is the exact three-command tuple in
EXACT-INITIALIZED-PRODUCER-COMMANDS.NOT-GRANTED.json: compile the private Rust object,
link the real-header controlled C driver, run360producer/288resume cases. It needs
independent source/functional ownership review and a fresh ordinary CPU0 grant.
AS2G/sharedCPU60/wall90+6/F32/FD256/stack2M/core0 and h990 capture stay unchanged.
No compiler, fixture, native, query or cleanup command has been executed here.
