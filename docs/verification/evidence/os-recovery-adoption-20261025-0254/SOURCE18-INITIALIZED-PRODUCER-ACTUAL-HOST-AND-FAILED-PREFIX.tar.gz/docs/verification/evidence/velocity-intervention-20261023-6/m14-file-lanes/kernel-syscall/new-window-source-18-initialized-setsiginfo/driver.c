/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#define main retained_source17_main_not_executed
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-17-ptrace-wakeup-outer/driver.c"
#undef main
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
extern long f03_ptrace_setsiginfo_initialized_v3(int,unsigned long);
extern const unsigned long f03_setsiginfo_Rust_ABI[9];
struct f03_setsiginfo_ops_v3 {
 unsigned long (*find)(int,int);void (*unlock)(unsigned long);
 void *(*alloc)(size_t,unsigned long);long (*copy)(void *,unsigned long,size_t);void (*free)(void *);
};
static int producer_active,producer_refs,alloc_fail,copy_fail,partial_write,copy_count,alloc_count,free_count;
static int original_mode,status_allowed;
static struct sig_pending *send_slot_before,*recv_slot_before;
static struct siginfo send_info_before,recv_info_before;
static struct sig_pending *fresh_private;
static unsigned char user_first[sizeof(struct siginfo)],user_second[sizeof(struct siginfo)];
static unsigned long producer_find(int tgid,int tid){require(producer_active&&tgid==0&&tid==expected_pid&&producer_refs==0);producer_refs++;return (unsigned long)&child;}
static void producer_unlock(unsigned long t){require(t==(unsigned long)&child&&producer_refs==1);producer_refs--;}
static void *producer_alloc(size_t size,unsigned long flags){require(producer_active&&producer_refs==1&&size==sizeof(struct sig_pending)&&flags==IHK_MC_AP_NOWAIT);alloc_count++;if(alloc_fail)return NULL;require(!send_slot_before&&!fresh_private);fresh_private=&send;memset(fresh_private,0xa5,sizeof(*fresh_private));return fresh_private;}
static void unchanged_published_state(void){
 require(child.ptrace_sendsig==send_slot_before&&child.ptrace_recvsig==recv_slot_before);
 if(send_slot_before)require(!memcmp(&send_slot_before->info,&send_info_before,sizeof(send_info_before)));
 if(recv_slot_before)require(!memcmp(&recv_slot_before->info,&recv_info_before,sizeof(recv_info_before)));
}
static long producer_copy(void *dst,unsigned long source,size_t bytes){
 require(producer_active&&producer_refs==1&&bytes==sizeof(struct siginfo)&&source==(unsigned long)user_first&&dst);
 /* Reentrant observation is read-only. No ranked kernel pending lock is inferred.
  * Faulting copy observes old slots/bytes: private allocation is never published. */
 unchanged_published_state();copy_count++;require(copy_count<=2);
 const void *image=copy_count==1?(const void *)user_first:(const void *)user_second;
 if(copy_fail==copy_count){if(partial_write)memcpy(dst,image,bytes/2);unchanged_published_state();return 1;}
 memcpy(dst,image,bytes);unchanged_published_state();return 0;
}
static void producer_free(void *node){require(producer_active&&producer_refs==1&&node==fresh_private&&node==&send&&child.ptrace_sendsig!=node&&child.ptrace_recvsig!=node);free_count++;fresh_private=NULL;}
const struct f03_setsiginfo_ops_v3 f03_setsiginfo_ops_v3={producer_find,producer_unlock,producer_alloc,producer_copy,producer_free};
const struct ptrace_io_offsets f03_setsiginfo_offsets_v3={
 .thread_proc_offset=__builtin_offsetof(struct thread,proc),.thread_status_offset=__builtin_offsetof(struct thread,status),
 .thread_vm_offset=__builtin_offsetof(struct thread,vm),.thread_ptrace_offset=__builtin_offsetof(struct thread,ptrace),
 .thread_ptrace_eventmsg_offset=__builtin_offsetof(struct thread,ptrace_eventmsg),
 .thread_ptrace_recvsig_offset=__builtin_offsetof(struct thread,ptrace_recvsig),.thread_ptrace_sendsig_offset=__builtin_offsetof(struct thread,ptrace_sendsig),
 .thread_report_proc_offset=__builtin_offsetof(struct thread,report_proc),.thread_ptrace_saved_uctx_valid_offset=__builtin_offsetof(struct thread,ptrace_saved_uctx_valid),
 .proc_pid_offset=__builtin_offsetof(struct process,pid),.proc_update_lock_offset=__builtin_offsetof(struct process,update_lock),
};
const unsigned long f03_setsiginfo_pending_size_v3=sizeof(struct sig_pending),f03_setsiginfo_info_offset_v3=__builtin_offsetof(struct sig_pending,info),f03_setsiginfo_alloc_flags_v3=IHK_MC_AP_NOWAIT;
const unsigned long f03_setsiginfo_C_ABI[9]={sizeof(struct siginfo),__alignof__(struct siginfo),sizeof(struct f03_setsiginfo_ops_v3),__alignof__(struct f03_setsiginfo_ops_v3),__builtin_offsetof(struct f03_setsiginfo_ops_v3,find),__builtin_offsetof(struct f03_setsiginfo_ops_v3,unlock),__builtin_offsetof(struct f03_setsiginfo_ops_v3,alloc),__builtin_offsetof(struct f03_setsiginfo_ops_v3,copy),__builtin_offsetof(struct f03_setsiginfo_ops_v3,free)};
static void prepare_case(int pid,int mode,int fail_alloc,int fail_copy,int partial,int allowed){
 reset(pid,1,mode==4?3:mode,0);if(mode==4)child.ptrace_recvsig=&send;
 child.status=allowed?PS_TRACED:0;status_allowed=allowed;original_mode=mode;
 alloc_fail=fail_alloc;copy_fail=fail_copy;partial_write=partial;copy_count=alloc_count=free_count=0;producer_refs=0;fresh_private=NULL;
 send_slot_before=child.ptrace_sendsig;recv_slot_before=child.ptrace_recvsig;
 if(send_slot_before)memcpy(&send_info_before,&send_slot_before->info,sizeof(send_info_before));
 if(recv_slot_before)memcpy(&recv_info_before,&recv_slot_before->info,sizeof(recv_info_before));
 memset(user_first,0x45,sizeof(user_first));memset(user_second,0x82,sizeof(user_second));
}
static void check_producer(long rc){
 int need_alloc=send_slot_before==NULL,need_recv=recv_slot_before!=NULL;
 int alloc_error=status_allowed&&need_alloc&&alloc_fail;
 int first_error=status_allowed&&!alloc_error&&copy_fail==1;
 int second_error=status_allowed&&!alloc_error&&copy_fail==2&&need_recv;
 long expected=!status_allowed?-ESRCH:alloc_error?-ENOMEM:(first_error||second_error)?-EFAULT:0;
 require(rc==expected&&producer_refs==0);
 require(alloc_count==(status_allowed&&need_alloc));
 int expected_copies=!status_allowed||alloc_error?0:first_error?1:need_recv?2:1;
 require(copy_count==expected_copies);
 require(free_count==(status_allowed&&need_alloc&&!alloc_error&&rc!=0));
 if(rc!=0){unchanged_published_state();require(!fresh_private);}
 else {
  require(child.ptrace_sendsig==(send_slot_before?send_slot_before:&send));
  require(child.ptrace_recvsig==recv_slot_before);
  const void *send_expected=child.ptrace_sendsig==child.ptrace_recvsig?(const void *)user_second:(const void *)user_first;
  require(!memcmp(&child.ptrace_sendsig->info,send_expected,sizeof(struct siginfo)));
  if(need_recv)require(!memcmp(&child.ptrace_recvsig->info,user_second,sizeof(struct siginfo)));
  /* Ownership of successful private allocation transferred exactly once. */
  fresh_private=NULL;
 }
}
int main(void){
 require(!memcmp(f03_wakeup_C_ABI,f03_wakeup_Rust_ABI,sizeof(f03_wakeup_C_ABI)));
 require(!memcmp(f03_setsiginfo_C_ABI,f03_setsiginfo_Rust_ABI,sizeof(f03_setsiginfo_C_ABI)));
 const int pids[]={0,17,(-2147483647-1)};unsigned tested=0;
 for(int mode=0;mode<5;mode++)for(int fail=0;fail<3;fail++)for(int alloc=0;alloc<2;alloc++)for(int partial=0;partial<2;partial++)for(int allowed=0;allowed<2;allowed++)for(unsigned p=0;p<3;p++){
  prepare_case(pids[p],mode,alloc,fail,partial,allowed);require(!producer_active);producer_active=1;
  long rc=f03_ptrace_setsiginfo_initialized_v3(pids[p],(unsigned long)user_first);check_producer(rc);producer_active=0;
  /* Resume after success or failure: every published info byte is old initialized
   * state or a complete staged snapshot. Failed fresh allocations stay invisible. */
  if(mode!=4){
  pending_mode=(child.ptrace_sendsig?1:0)|(child.ptrace_recvsig?2:0);memset(&seen,0,sizeof(seen));
  int resumed=ptrace_wakeup_sig(pids[p],PTRACE_CONT,1);snapshot();independent(resumed,PTRACE_CONT,1);
  require(resumed==0&&!producer_refs&&!active_lock);
  } /* Aliased-slot producer case does not establish consumer/free lifetime. */
  tested++;
 }
 require(tested==360);printf("PASS initialized setsiginfo stage-commit cases360 resumes288 ABI32 producer-fault-rollback/reentrant-observer/resume initialized-only external-exclusive-state\n");return 0;
}
