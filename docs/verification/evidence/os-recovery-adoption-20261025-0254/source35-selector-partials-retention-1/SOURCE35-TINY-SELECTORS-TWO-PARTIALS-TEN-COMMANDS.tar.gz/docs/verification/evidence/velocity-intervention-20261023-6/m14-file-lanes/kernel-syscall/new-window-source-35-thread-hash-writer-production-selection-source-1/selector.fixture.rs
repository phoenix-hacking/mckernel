// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Data-only callback selector witness. Existing runtime providers are linked
// from retained objects; no Source33/34 body is recompiled here.
#![no_std]
use core::ffi::c_void;
type ProcessThreadActionFn = unsafe extern "C" fn(*mut c_void);
extern "C" { fn process_destroy_thread_hash_detach_bridge(thread: *mut c_void); }
#[cfg(f02_thread_hash_writer_candidate_v3)]
mod f02_thread_hash_writer_provider_v3 {
    use core::ffi::c_void;
    extern "C" { pub fn process_destroy_thread_hash_detach_candidate_v3(thread: *mut c_void); }
}
const fn selected_callback() -> ProcessThreadActionFn {
    #[cfg(f02_thread_hash_writer_candidate_v3)]
    let hash_detach_fn: ProcessThreadActionFn =
        f02_thread_hash_writer_provider_v3::process_destroy_thread_hash_detach_candidate_v3;
    #[cfg(not(f02_thread_hash_writer_candidate_v3))]
    let hash_detach_fn: ProcessThreadActionFn = process_destroy_thread_hash_detach_bridge;
    hash_detach_fn
}
#[used]
#[no_mangle]
pub static SOURCE35_SELECTED_HASH_CALLBACK: ProcessThreadActionFn = selected_callback();
