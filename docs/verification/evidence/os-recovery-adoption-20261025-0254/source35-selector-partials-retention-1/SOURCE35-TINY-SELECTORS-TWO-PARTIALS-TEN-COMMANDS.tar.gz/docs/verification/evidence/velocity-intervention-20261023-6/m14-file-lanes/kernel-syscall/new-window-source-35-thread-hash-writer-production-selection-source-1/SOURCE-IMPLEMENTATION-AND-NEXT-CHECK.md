Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source35 adds one default-OFF CMake option pairing the Source34 Rust cfg with its process.c macro. The original Rust bridge remains byte-identical behind cfg(not ON); ON emits the unchanged Source34 candidate and Source33 typed writer. Source34 caller/module and C prototype guards are reused. No compute C body is added.

The ten-command recipe checks five real CMake LANGUAGES NONE profiles, compiles only two new data-only callback selectors using the actual current290 nightly/compiler flags, links retained providers, then checks exact callback-pointer relocations, unique selected Rust provider, ABI36 and import closure. Source34 provider/header and Source22 lookup are retained; no known provider, whole crate or C/ASM object is recompiled. OFF links the retained f9 whole-Rust provider; ON links retained Source34 and Source22 objects. These are isolated partial objects, never current default image or native acceptance.

Process/VM/main-thread/free-path lifetimes, final-owner prelock assumptions, current complete production consumer closure and native contention remain OPEN. Root owns canonical integration and any execution grant. No command has run in this lane.
