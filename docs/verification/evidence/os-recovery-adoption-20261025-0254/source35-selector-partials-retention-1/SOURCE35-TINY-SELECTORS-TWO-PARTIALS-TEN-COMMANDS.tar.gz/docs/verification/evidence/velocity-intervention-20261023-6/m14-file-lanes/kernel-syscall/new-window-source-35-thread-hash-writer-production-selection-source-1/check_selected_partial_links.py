#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read-only strict selector/partial-link metadata check. Never executes objects.
"""
import ast
import hashlib
import json
from pathlib import Path
import struct
import sys
ROOT = Path(__file__).resolve().parent
INPUT = json.loads((ROOT / 'RETAINED-PROVIDERS-AND-SELECTOR-SOURCE.INPUTS.json').read_text())
def require(condition, message):
    if not condition:
        raise ValueError(message)
def auth(row):
    raw = Path(row['path']).read_bytes()
    require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'retained source/object changed')
    return raw
for key, row in INPUT.items():
    if isinstance(row, dict) and 'path' in row:
        auth(row)
selected = [node for node in ast.parse(auth(INPUT['qualified_ELF_helper'])).body if isinstance(node, ast.ClassDef) and node.name == '_ReuseElf' or isinstance(node, ast.FunctionDef) and node.name in {'_reuse_elf_owning_relocations', '_reuse_elf_object_bytes'}]
namespace = dict(Path=Path, struct=struct)
exec(compile(ast.Module(body=selected, type_ignores=[]), '<qualified-readonly-ELF-helper-extraction>', 'exec'), namespace)
Elf = namespace['_ReuseElf']
relocations = namespace['_reuse_elf_owning_relocations']
object_bytes = namespace['_reuse_elf_object_bytes']
abi_nodes = [node for node in ast.parse(auth(INPUT['qualified_ABI_checker'])).body if isinstance(node, ast.FunctionDef) and node.name == 'elf']
exec(compile(ast.Module(body=abi_nodes, type_ignores=[]), '<actual-Source34-ABI-table-reader>', 'exec'), namespace)
abi = namespace['elf']
provider_abi, imports = abi(Path(INPUT['Source34_provider']['path']), 'SOURCE34_RUST_ABI')
c_abi, c_imports = abi(Path(INPUT['Source34_C_ABI']['path']), 'SOURCE34_C_ABI')
require(provider_abi == c_abi and not c_imports, 'retained genuine ABI36 differs')
require(imports == {'get_this_cpu_local_var','process_list_is_linked_result','process_list_detach_result','process_mcs_writer_lock_bridge','process_mcs_writer_unlock_bridge','panic'}, 'retained Source34 imports differ')
def defined(elf, name):
    return [symbol for symbol in elf.symbols if symbol['name'] == name and symbol['shndx'] != 0]
def names(elf, undefined=False):
    return {symbol['name'] for symbol in elf.symbols if symbol['name'] and (symbol['shndx'] == 0 if undefined else symbol['shndx'] != 0)}
def selected_pointer(elf, expected):
    rows = defined(elf, 'SOURCE35_SELECTED_HASH_CALLBACK')
    require(len(rows) == 1 and rows[0]['bind'] == 1 and rows[0]['type'] == 1 and rows[0]['size'] == 8, 'exact selected callback pointer missing')
    pointer = rows[0]
    require(object_bytes(elf, pointer) == bytes(8), 'selected pointer whole-byte initializer differs')
    edges = relocations(elf, pointer)
    require(len(edges) == 1 and edges[0]['offset'] == 0 and edges[0]['type'] == 1 and edges[0]['addend'] == 0 and edges[0]['target']['name'] == expected, 'selected callback relocation differs')
    return edges[0]
off_selector, on_selector, off_partial, on_partial = [Elf(Path(value)) for value in sys.argv[1:5]]
old_name = 'process_destroy_thread_hash_detach_bridge'
new_name = 'process_destroy_thread_hash_detach_candidate_v3'
require(names(off_selector, True) == {old_name} and names(on_selector, True) == {new_name}, 'selector imports not exact')
proof = []
for mode, selector, partial, expected, forbidden, provider_rows in [
    ('OFF', off_selector, off_partial, old_name, new_name, [Elf(Path(INPUT['OFF_current290_full_Rust']['path']))]),
    ('ON', on_selector, on_partial, new_name, old_name, [Elf(Path(INPUT['Source34_provider']['path'])), Elf(Path(INPUT['Source22_lookup']['path']))]),
]:
    edge = selected_pointer(selector, expected)
    partial_edge = selected_pointer(partial, expected)
    require(not defined(selector, old_name) and not defined(selector, new_name), 'selector duplicated a runtime callback body')
    owned = defined(partial, expected)
    require(len(owned) == 1 and owned[0]['bind'] == 1 and owned[0]['type'] == 2 and owned[0]['size'] > 0 and not defined(partial, forbidden), 'unique actual selected Rust provider differs')
    all_inputs = [selector, *provider_rows]
    expected_undefined = set().union(*(names(item, True) for item in all_inputs)) - set().union(*(names(item) for item in all_inputs))
    require(names(partial, True) == expected_undefined, 'partial-link import closure differs')
    if mode == 'ON':
        require(len(defined(partial, 'process_thread_hash_detach_live_body_v3')) == 1, 'Source33 writer body not uniquely owned')
        require(not any('panicking' in symbol or 'panic_const' in symbol or 'unwrap_failed' in symbol for symbol in names(selector, True) | imports), 'new unsupported Rust panic import')
    proof.append(dict(mode=mode,selected=expected,selected_provider=owned[0],selector_relocation=edge,partial_relocation=partial_edge,undefined_count=len(expected_undefined)))
print(json.dumps(dict(scope=__doc__,status='PASS_SOURCE35_ON_OFF_EXACT_SELECTOR_RELOCATIONS_UNIQUE_RETAINED_RUST_PROVIDERS',ABI_words=36,proof=proof,unchanged_providers_recompiled=False,full_current_default_link=False,native=False,Process_and_free_path_lifetimes='OPEN'),sort_keys=True))
