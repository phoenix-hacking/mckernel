#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Finite Source35 ordinary ten-command envelope. Preparation grants nothing; exact Root grant
must exist separately. Reuses reviewed h990 ownership/retirement implementation.
"""
import ast
import builtins
import datetime
import dis
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
RECIPE = ROOT / 'EXACT-DEFAULT-OFF-ON-SELECTOR-AND-PARTIAL-LINK-COMMANDS.NOT-GRANTED.json'
RECIPE_SHA = '5c2bdbf616ec293bc594edaee4fce52b69a19e35fab76ab3a3b482dd45d586d4'
HELPER = REPO / ('docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/'
                 'sdk-physical-source/run_two_commands_source_bound_corrected.py')
HELPER_SHA = '990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
GRANT = ROOT / 'ROOT-EXACT-SOURCE35-TEN-COMMAND-GRANT.json'
OUTPUT = ROOT / 'output-1'
CAPTURE = ROOT / 'actual-ten-command-capture-1'
RESULT = ROOT / 'ACTUAL-SOURCE35-TEN-COMMAND-FIRST-RESULT.json'
FIXED_DEADLINE_UTC = 1793030133
SCOPE = 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
SOURCE_MANIFEST = {'path': '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-35-thread-hash-writer-production-selection-source-1/FINITE-SOURCE35-PRODUCTION-SELECTION.FILES.json', 'sha256': '9dfb9e25f6a52da19f88a1ed0ddacf6e5050e0a1c418b2c20cab464101303d0a', 'bytes': 5970}
SIZE_PLAN = {'path': '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-35-thread-hash-writer-production-selection-source-1/FINITE-PARTIAL-LINK-OUTPUT-SIZE-PLAN.SOURCE-ONLY.json', 'sha256': '654a8dcee7d009b422e1446ad5cbd3e6428b445e050ac1b6a43847fb33892018', 'bytes': 1011}
COMMAND_NAMES = ['cmake-default-off', 'cmake-explicit-on', 'cmake-legacy-C-off', 'cmake-invalid-on-without-Rust', 'cmake-invalid-on-arm64', 'compile-selector-off', 'compile-selector-on', 'partial-link-off', 'partial-link-on', 'check-exact-selector-and-provider-ownership']
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size',
          'st_mtime_ns', 'st_ctime_ns')
PROFILE = dict(parent_control_CPU=7, command_CPU=0, ordinary_jobs=1, AS_bytes=2 << 30,
               whole_CPU_seconds=60, whole_wall_seconds=90, retirement_seconds=6,
               FS_bytes=32 << 20, FD=256, stack_bytes=2 << 20, core_bytes=0)


def write(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def stable_pin(path):
    # Existing tool argv can name a distribution symlink. Preserve its lexical
    # path metadata AND stable target FD metadata instead of silently changing argv.
    lexical_before = path.lstat()
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink < 1 or before.st_size > 32 << 20:
            raise RuntimeError('expected bounded regular input: ' + str(path))
        digest, size = hashlib.sha256(), 0
        while True:
            block = os.read(fd, 65536)
            if not block:
                break
            size += len(block)
            if size > 32 << 20:
                raise RuntimeError('input exceeded bound: ' + str(path))
            digest.update(block)
        after, target, lexical_after = os.fstat(fd), path.stat(), path.lstat()
        if (any(getattr(before, key) != getattr(after, key)
                or getattr(before, key) != getattr(target, key) for key in FIELDS)
                or any(getattr(lexical_before, key) != getattr(lexical_after, key) for key in FIELDS)
                or size != before.st_size):
            raise RuntimeError('input metadata changed while hashing: ' + str(path))
        return dict(path=str(path), bytes=size, sha256=digest.hexdigest(),
                    target_identity={key: getattr(before, key) for key in FIELDS},
                    lexical_identity={key: getattr(lexical_before, key) for key in FIELDS})
    finally:
        os.close(fd)


def byte_pin(path):
    row = stable_pin(path)
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def dependencies(code):
    result = {item.argval for item in dis.get_instructions(code) if item.opname == 'LOAD_GLOBAL'}
    for child in code.co_consts:
        if isinstance(child, type(code)):
            result.update(dependencies(child))
    return result


def timestamp():
    return dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                monotonic_seconds=time.monotonic())


def main():
    records, namespace, baseline = [], {}, None
    begin, timer_started, output_created, capture_created = time.monotonic(), False, False, False
    try:
        if time.time() + 96 > FIXED_DEADLINE_UTC:
            raise RuntimeError('same fixed eighteen-hour window has insufficient bounded time')
        if any(path.exists() or path.is_symlink() for path in (OUTPUT, CAPTURE, RESULT)):
            raise RuntimeError('fresh output/capture/result roots required; no replay')
        if os.getuid() != 1000 or os.geteuid() != 1000 or os.sched_getaffinity(0) != {7}:
            raise RuntimeError('ordinary UID1000 parent control CPU7 required')
        if byte_pin(RECIPE)['sha256'] != RECIPE_SHA:
            raise RuntimeError('exact independently reviewed recipe changed')
        recipe = json.loads(RECIPE.read_text())
        if any(os.path.lexists(path) for path in recipe['must_remain_absent_before_grant']):
            raise RuntimeError('fresh declared output roots required; no replay')
        if len(recipe['commands']) != 10 or [row['name'] for row in recipe['commands']] != COMMAND_NAMES:
            raise RuntimeError('exact ten frozen commands required')
        grant = json.loads(GRANT.read_text())
        authority = grant.get('root_grant')
        own_pin = byte_pin(Path(__file__).resolve())
        if (not isinstance(authority, dict) or authority.get('authority') != '/root'
                or authority.get('authorized') is not True or authority.get('once') is not True
                or grant.get('recipe') != byte_pin(RECIPE) or grant.get('runner') != own_pin
                or grant.get('profile') != PROFILE or grant.get('source_manifest') != SOURCE_MANIFEST
                or grant.get('size_plan') != SIZE_PLAN):
            raise RuntimeError('separate exact non-NULL durable Root grant required')
        raw = HELPER.read_bytes()
        if hashlib.sha256(raw).hexdigest() != HELPER_SHA:
            raise RuntimeError('reviewed h990 helper changed')
        functions = {'need', 'write', 'hashed', 'stop', 'cpu_used', 'members', 'process_start',
                     'terminal_unreaped', 'wait_terminal', 'owned_capture'}
        assignments = {'FIELDS', 'stopping', 'CENSUS_SOURCE', 'CENSUS_SHA', '_CENSUS', 'STOP_SIGNALS'}
        nodes = [node for node in ast.parse(raw).body
                 if isinstance(node, (ast.Import, ast.ImportFrom))
                 or isinstance(node, ast.FunctionDef) and node.name in functions
                 or isinstance(node, ast.Assign) and any(
                     isinstance(target, ast.Name) and target.id in assignments
                     for target in node.targets)]
        namespace = {'__file__': str(HELPER)}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(HELPER), 'exec'), namespace)
        used = set().union(*(dependencies(namespace[name].__code__) for name in functions))
        if used - set(namespace) - set(vars(builtins)):
            raise RuntimeError('reviewed h990 extraction dependencies missing')
        bindings = recipe['inputs'] + recipe['tools'] + [
            row for row in recipe['retained'].values()
            if isinstance(row, dict) and set(row) == {'path', 'bytes', 'sha256'}]
        bindings += [SOURCE_MANIFEST, SIZE_PLAN, byte_pin(RECIPE), byte_pin(HELPER),
                     byte_pin(GRANT), own_pin,
                     dict(path=str(namespace['CENSUS_SOURCE']),
                          bytes=namespace['CENSUS_SOURCE'].stat().st_size,
                          sha256=namespace['CENSUS_SHA'])]
        unique = {}
        for row in bindings:
            if row['path'] in unique and unique[row['path']] != row:
                raise RuntimeError('conflicting stable source binding')
            unique[row['path']] = row
        bindings = list(unique.values())
        size_plan = json.loads(Path(SIZE_PLAN['path']).read_text())
        if (size_plan['unchanged_RLIMIT_FSIZE'] != 32 << 20
                or size_plan['OFF_planning_ceiling'] >= 32 << 20
                or size_plan['ON_planning_ceiling'] >= 32 << 20):
            raise RuntimeError('declared link size plan exceeds unchanged profile')

        def verify():
            observed = []
            for expected in bindings:
                actual = stable_pin(Path(expected['path']))
                if {key: actual[key] for key in ('path', 'bytes', 'sha256')} != expected:
                    raise RuntimeError('bound source/header/tool/retained input changed: '
                                       + expected['path'])
                observed.append(actual)
            if baseline is not None and observed != baseline:
                raise RuntimeError('stable input identity changed after admission')
            return observed

        baseline = verify()
        mem = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                       if line.startswith('MemAvailable:'))) * 1024
        host, scratch = os.statvfs('/home/holden'), os.statvfs('/home/holden/mckernel-work/scratch')
        if (os.environ.get('MCKERNEL_OS_MEMORY_GIB') != '22.0485' or mem < 25501368320 or host.f_bavail * host.f_frsize < (16 << 30) + (64 << 20)
                or scratch.f_bavail * scratch.f_frsize < 12 << 30):
            raise RuntimeError('existing ordinary resource headroom floor')
        os.chdir(REPO)
        os.environ.update(RUST_MIN_STACK='2097152', LC_ALL='C', OMP_NUM_THREADS='1',
                          RAYON_NUM_THREADS='1')
        for number in namespace['STOP_SIGNALS']:
            signal.signal(number, namespace['stop'])
        for key, value in ((resource.RLIMIT_AS, 2 << 30), (resource.RLIMIT_CPU, 60),
                           (resource.RLIMIT_FSIZE, 32 << 20), (resource.RLIMIT_NOFILE, 256),
                           (resource.RLIMIT_STACK, 2 << 20), (resource.RLIMIT_CORE, 0)):
            resource.setrlimit(key, (value, value))
        OUTPUT.mkdir(mode=0o700)
        output_created = True
        CAPTURE.mkdir(mode=0o700)
        capture_created = True
        write(CAPTURE / 'profile-and-admission.json',
              dict(scope=SCOPE, **PROFILE, recipe=byte_pin(RECIPE), runner=own_pin,
                   grant=byte_pin(GRANT), h990_helper=byte_pin(HELPER),
                   MemAvailable_bytes=mem, host_available_bytes=host.f_bavail * host.f_frsize,
                   scratch_available_bytes=scratch.f_bavail * scratch.f_frsize,
                   admitted_inputs=baseline, **timestamp()))
        signal.setitimer(signal.ITIMER_REAL, max(0.1, 96 - (time.monotonic() - begin)))
        timer_started = True
        for index, command in enumerate(recipe['commands']):
            before = verify()
            if command['name'].startswith('partial-link-'):
                selector = OUTPUT / ('selector-on.o' if command['name'].endswith('-on') else 'selector-off.o')
                if selector.is_symlink() or not selector.is_file() or selector.stat().st_size > size_plan['new_selector_per_file_ceiling']:
                    raise RuntimeError('actual fresh selector exceeds declared link input ceiling')
            wall_remaining = 90 - (time.monotonic() - begin)
            cpu_remaining = int(60 - namespace['cpu_used']())
            if wall_remaining <= 0 or cpu_remaining < 1:
                raise RuntimeError('shared whole wall/CPU budget exhausted')
            capture = CAPTURE / ('%02d' % index)
            capture.mkdir(mode=0o700)
            write(capture / 'frozen-command-and-pins.json',
                  dict(scope=SCOPE, command=command, inputs=before, grant=byte_pin(GRANT),
                       **timestamp()))
            write(capture / 'enqueue-observation.json',
                  dict(scope=SCOPE, argv=command['argv'], argc=len(command['argv']),
                       parent_affinity=sorted(os.sched_getaffinity(0)),
                       CPU_seconds=namespace['cpu_used'](), **timestamp()))

            def limits():
                os.sched_setaffinity(0, {0})
                os.chdir(command['cwd'])
                resource.setrlimit(resource.RLIMIT_CPU, (cpu_remaining, cpu_remaining))

            def started_reader(pid):
                birth = namespace['process_start'](pid)
                affinity = sorted(os.sched_getaffinity(pid))
                write(capture / 'start-observation.json',
                      dict(pid=pid, start=birth, command_affinity=affinity,
                           observed_wrapper_argv0=command['argv'][0],
                           compiler_command=command['name'].startswith('compile-selector-'),
                           **timestamp()))
                if affinity != [0]:
                    raise RuntimeError('command did not enter exact CPU0 affinity')
                if command['name'].startswith('compile-selector-'):
                    # Observe only this newly owned process group. No external
                    # observer, signal, root query or runtime action is used.
                    expected_compiler = next(token for token in command['argv'] if token.endswith('/bin/rustc'))
                    found = None
                    until = min(time.monotonic() + 0.25, begin + 90)
                    while time.monotonic() < until and found is None:
                        for member in namespace['members'](pid):
                            try:
                                executable = os.readlink('/proc/' + str(member) + '/exe')
                                member_start = namespace['process_start'](member)
                                if executable == str(Path(expected_compiler).resolve()):
                                    found = dict(pid=member, start=member_start, executable=executable,
                                                 affinity=sorted(os.sched_getaffinity(member)), **timestamp())
                                    break
                            except (FileNotFoundError, ProcessLookupError):
                                continue
                        if found is None:
                            time.sleep(0.001)
                    write(capture / 'compiler-start-observation.json',
                          dict(status='OBSERVED_OWNED_COMPILER_PID' if found else 'NOT_OBSERVED_IN_BOUNDED_WINDOW',
                               expected_compiler=expected_compiler, observation=found,
                               wrapper_pid=pid, wrapper_start=birth,
                               unknown_is_not_fabricated_compiler_identity=True))
                return birth

            joined = namespace['owned_capture'](command, capture, wall_remaining, limits,
                                                 started_reader=started_reader)
            write(capture / 'whole-join-and-end.json',
                  dict(join=joined, CPU_seconds=namespace['cpu_used'](),
                       maximum_child_RSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                       **timestamp()))
            records.append(dict(command=command, join=joined))
            write(capture / 'post-command-inputs.json', dict(inputs=verify(), **timestamp()))
            if (joined['returncode'] != command['expected_returncode']
                    or not joined['direct_child_joined'] or not joined['group_absent']
                    or not joined['closed_streams'] or joined['error']
                    or joined['retirement_error'] or joined['timed_out']):
                raise RuntimeError('first unexpected command result; STOP no retry')
            if command['expected_returncode'] == 1:
                if 'Thread-hash writer V3 requires the existing x86_64 Rust process consumer' not in (capture / 'stderr').read_text():
                    raise RuntimeError('invalid selector refused for unexpected cause; STOP no retry')
            if command['name'].startswith('compile-selector-'):
                selector = OUTPUT / ('selector-on.o' if command['name'].endswith('-on') else 'selector-off.o')
                if not selector.is_file() or selector.is_symlink() or selector.stat().st_size > size_plan['new_selector_per_file_ceiling']:
                    raise RuntimeError('new selector object exceeds finite size declaration')
            if command['name'].startswith('partial-link-'):
                mode = 'ON' if command['name'].endswith('-on') else 'OFF'
                partial = OUTPUT / ('selected-on.partial.o' if mode == 'ON' else 'selected-off.partial.o')
                if not partial.is_file() or partial.is_symlink() or partial.stat().st_size > size_plan[mode + '_planning_ceiling']:
                    raise RuntimeError('partial object exceeds declared unchanged-profile size plan')

        if namespace['cpu_used']() > 60:
            raise RuntimeError('shared whole CPU budget exceeded')
        write(RESULT, dict(scope=SCOPE, status='PASS_SOURCE35_DEFAULT_OFF_ON_PAIRED_SELECTORS_AND_RETAINED_PARTIAL_LINKS',
                           records=records, seconds=time.monotonic() - begin,
                           CPU_seconds=namespace['cpu_used'](), CPU0_released=True,
                           maximum_child_RSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                           final_inputs=verify(), actual_objects=[byte_pin(OUTPUT / name)
                                                                 for name in ('selector-off.o', 'selector-on.o', 'selected-off.partial.o', 'selected-on.partial.o')],
                           recipe=byte_pin(RECIPE), root_grant=byte_pin(GRANT),
                           native=False, production_default=False, canonical_mutations=0))
        print(json.dumps(dict(status='PASS_SOURCE35_DEFAULT_OFF_ON_PAIRED_SELECTORS_AND_RETAINED_PARTIAL_LINKS',
                              result=byte_pin(RESULT))))
        return 0
    except BaseException as error:
        # owned_capture joins before it returns, including on its own failures.
        # An uncertain retirement is preserved as a hold, never inferred clear.
        result = dict(scope=SCOPE, status='FAIL_STOP_PRESERVE_PREFIX_NO_RETRY',
                      error=type(error).__name__ + ': ' + str(error), records=records,
                      seconds=time.monotonic() - begin, output_created=output_created,
                      capture_created=capture_created,
                      CPU_seconds=namespace['cpu_used']() if 'cpu_used' in namespace else None,
                      maximum_child_RSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                      CPU0_released=all(row['join']['direct_child_joined']
                                        and row['join']['group_absent']
                                        and row['join']['closed_streams'] for row in records),
                      canonical_mutations=0, native=False, production_default=False)
        if not RESULT.exists():
            write(RESULT, result)
        raise
    finally:
        if timer_started:
            signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    sys.exit(main())
