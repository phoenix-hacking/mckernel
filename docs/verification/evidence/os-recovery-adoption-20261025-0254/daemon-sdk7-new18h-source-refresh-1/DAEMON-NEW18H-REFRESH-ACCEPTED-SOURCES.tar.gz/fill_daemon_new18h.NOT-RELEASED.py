"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Private new18h fill adapter; no query, owner, compiler, SDK or cleanup execution.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,time
from current_authority import validate_current
from fill_schema_new18h import make_payload, canonical, require
D=Path(__file__).resolve().parent
MAX=32*2**20
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def load_raw(path,expected=None):
    path=Path(path)
    assert path.is_absolute() and not any(p.is_symlink() for p in (path,*path.parents))
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);assert stat.S_ISREG(first.st_mode) and first.st_nlink==1 and first.st_size<=MAX
        parts=[];size=0
        while True:
            part=os.read(fd,min(1048576,MAX+1-size))
            if not part:break
            parts.append(part);size+=len(part);assert size<=MAX
        last=os.fstat(fd);named=path.lstat()
        assert all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in FIELDS)
    finally:os.close(fd)
    raw=b''.join(parts);assert len(raw)==first.st_size
    digest=hashlib.sha256(raw).hexdigest()
    if expected is not None:assert digest==expected
    return raw,dict(path=str(path),sha256=digest,bytes=len(raw)),{k:getattr(first,k) for k in FIELDS}

def read(path,expected=None):
    raw,ref,meta=load_raw(path,expected);return json.loads(raw),ref,meta

def write_raw(path,raw):
    assert not os.path.lexists(path)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        view=memoryview(raw)
        while view:
            n=os.write(fd,view);assert n>0;view=view[n:]
        os.fchown(fd,1000,1000);os.fsync(fd)
    finally:os.close(fd)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def write(path,value):return write_raw(path,canonical(value))


def exact(ref):
    value, actual, _ = read(ref['path'],ref['sha256'])
    require(actual == ref, 'exact retained tuple differs')
    return value


def main():
    require(os.getuid() == os.geteuid() == 0, 'authenticated root metadata writer required')
    require(len(sys.argv) == 4 and sys.argv[1] in ('--prepare-review-payload','--publish-reviewed-release'),
            'exact fill mode plus hash-bound inputs required')
    inputs, _, _ = read(sys.argv[2],sys.argv[3])
    packet, packet_ref, _ = read(D/'CONSUMER.NEXT18H.PENDING.json')
    # Revalidate unchanged SOURCE27 and provider; do not relabel source approval.
    manifest = exact(packet['source27'])
    require(manifest['member_count'] == len(manifest['members']) == 27, 'exact SOURCE27 member count')
    for ref in manifest['members'].values():
        raw, actual, _ = load_raw(ref['path'],ref['sha256'])
        require(actual == ref, 'SOURCE27 member identity differs')
    raw, actual, _ = load_raw(packet['provider']['path'],packet['provider']['sha256'])
    require(actual == packet['provider'], 'produced131 provider differs')
    for ref in packet['refresh_sources'].values():
        raw, actual, _ = load_raw(ref['path'],ref['sha256'])
        require(actual == ref, 'refreshed source tuple differs')
    current = exact(packet['current_physical'])
    validate_current(current,exact(packet['SDK21_artifact_behavior']))
    # Revalidate actual combined physical/postjoin raw captures and wholejoin bytes.
    exact(current['stdout']);exact(current['whole_join'])
    for ref in current['raw_captures'].values():
        raw, actual, _ = load_raw(ref['path'],ref['sha256'])
        require(actual == ref, 'raw physical capture differs')
    base = exact(packet['pending_release_base'])
    query = exact(inputs['query']);join = exact(inputs['query_join'])
    rawout, outref, outmeta = load_raw(join['captures']['stdout']['path'],join['captures']['stdout']['sha256'])
    rawerr, errref, errmeta = load_raw(join['captures']['stderr']['path'],join['captures']['stderr']['sha256'])
    require(len(rawout) == join['captures']['stdout']['size'] and len(rawerr) == join['captures']['stderr']['size'] == 0,
            'complete retained query stdout and empty stderr required')
    summary = json.loads(rawout)
    require(summary['status'] == query['status'] and summary['at'] == query['at'] and summary['resources'] == query['resources'] and
            summary['target_calls'] == summary['container_create_calls'] == 0, 'wholejoin stdout/query result disagree')
    refs = dict(packet=packet_ref, source_review=packet['source_approval'], fetched=packet['fetched_source'],
                publication=inputs['publication'], refresh_review=inputs['source_refresh_review'],
                current_stdout=current['stdout'], query=inputs['query'], join=inputs['query_join'],
                stdout=outref, query_source=packet['refresh_sources']['query'], query_export=None)
    now = time.time()
    payload = make_payload(base,packet,exact(packet['source_approval']),exact(packet['full11_map']),
                           exact(packet['fetched_source']),current,query,join,exact(inputs['publication']),
                           exact(inputs['source_refresh_review']),now,os.environ.get('MCKERNEL_OS_MEMORY_GIB'),refs)
    require(query['wall_deadline_epoch'] == 1793030133 and now < query['wall_deadline_epoch'] and
            time.monotonic() < query['monotonic_deadline'] and time.clock_gettime(time.CLOCK_BOOTTIME) < query['boot_deadline'],
            'fixed parent wall/BOOT/MONOTONIC deadline reached')
    require(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == query['boot_id'] == base['boot_id'], 'same boot required')
    if sys.argv[1] == '--prepare-review-payload':
        # Preserve original stable metadata, root-authenticated export, O_EXCL,
        # fsync and chown semantics. No workload or live-observer call is present.
        export_dir = D/'root-query-export-new18h-1'
        export_dir.mkdir(mode=0o700);os.chown(export_dir,1000,1000)
        exports=[]
        for label, ref in [('ADMISSION.json',inputs['query']),('WHOLE-JOIN.json',inputs['query_join']),('stdout',outref),('stderr',errref)]:
            raw, origin, meta = load_raw(ref['path'],ref['sha256'])
            copy = write_raw(export_dir/label,raw)
            exports.append(dict(origin=origin,origin_identity=meta,owned_export=copy))
        payload['query_export'] = write(export_dir/'ROOT-AUTHENTICATED-EXPORT.json',dict(status='ROOT_EXACT_RETAINED_QUERY_AND_WHOLE_JOIN_EXPORT',record_writer='/root',root_uid=os.geteuid(),exports=exports))
        copies = {Path(row['owned_export']['path']).name:row['owned_export'] for row in exports}
        payload.update(actual_query=copies['ADMISSION.json'],actual_query_whole_join=copies['WHOLE-JOIN.json'],actual_query_stdout=copies['stdout'])
        out=write(D/'RELEASE.NEW18H.REVIEW-PAYLOAD.NOT-RELEASED.json',payload)
        print(json.dumps(dict(status='PAYLOAD_FOR_INDEPENDENT_REVIEW_NOT_EXECUTION_RELEASE',payload=out,reviewed_release_payload_sha256=hashlib.sha256(canonical(payload)).hexdigest())))
    else:
        stored, stored_ref, _ = read(D/'RELEASE.NEW18H.REVIEW-PAYLOAD.NOT-RELEASED.json')
        # All source/current/query checks above rerun before publication. The
        # reviewed payload must match except for authenticated exported paths.
        for key in ('query_export','actual_query','actual_query_whole_join','actual_query_stdout'):
            payload[key] = stored[key]
        require(stored == payload, 'reviewed payload differs from current validated bindings')
        review = exact(inputs['execution_review'])
        require(review['decision'] == 'PASS_EXECUTION' and review['implementation_ownership'] is False and
                review['reviewer'] and review['reviewer'] != payload['author'] and
                review['reviewed_release_payload_sha256'] == hashlib.sha256(canonical(payload)).hexdigest(),
                'independent exact payload execution review required')
        final = dict(payload,execution_review={k:inputs['execution_review'][k] for k in ('path','sha256')})
        out = write(D/'RELEASE.NEW18H.FINAL.json',final)
        print(json.dumps(dict(status='REVIEWED_RELEASE_PUBLISHED_OWNER_NOT_EXECUTED',release=out)))

if __name__ == '__main__':
    main()
