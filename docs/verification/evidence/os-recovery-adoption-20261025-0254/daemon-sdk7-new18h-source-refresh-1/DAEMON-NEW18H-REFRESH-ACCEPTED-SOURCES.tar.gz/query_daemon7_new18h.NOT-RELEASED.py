"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Private successor for one read-only SDK admission. Source only; no execution grant.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
import time
from current_authority import bound, validate_current

D = Path(__file__).resolve().parent


def main():
    # A separately hash-bound independent query release is required before clocks,
    # runtime-owner import, directory creation or Docker inspection.
    if len(sys.argv) != 4 or sys.argv[1] != '--reviewed-query-release':
        raise ValueError('independent exact query release is required')
    release_raw = Path(sys.argv[2]).read_bytes()
    if hashlib.sha256(release_raw).hexdigest() != sys.argv[3]:
        raise ValueError('query release hash differs')
    release = json.loads(release_raw)
    packet_raw = (D/'CONSUMER.NEXT18H.PENDING.json').read_bytes()
    packet = json.loads(packet_raw)
    if release['schema'] != 'mckernel.daemon7.new18h.readonly-query-release.v1' or release['decision'] != 'PASS_READONLY_QUERY_ONLY':
        raise ValueError('exact independent read-only query release required')
    if release['implementation_ownership'] is not False or release['SDK_execution_released'] is not False:
        raise ValueError('query scope differs')
    if release['packet_sha256'] != hashlib.sha256(packet_raw).hexdigest() or release['query_sha256'] != hashlib.sha256(Path(__file__).read_bytes()).hexdigest():
        raise ValueError('released source differs')
    if release['window'] != packet['window'] or release['wall_deadline_epoch'] != 1793030133:
        raise ValueError('fixed parent new18h window required')
    if time.time() >= release['wall_deadline_epoch'] or time.monotonic() >= release['monotonic_deadline'] or time.clock_gettime(time.CLOCK_BOOTTIME) >= release['boot_deadline']:
        raise ValueError('parent deadline reached')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != release['boot_id']:
        raise ValueError('release boot identity differs')
    if os.environ.get('MCKERNEL_OS_MEMORY_GIB') != '22.0485':
        raise ValueError('parent aggregate budget environment differs')
    current = bound(packet['current_physical'])
    validate_current(current, bound(packet['SDK21_artifact_behavior']))
    # The release must affirm that no serialized operation intervened. A subsequent
    # default-image operation requires a new source-bound current-proof refresh.
    if release['current_physical'] != packet['current_physical'] or release['no_intervening_serialized_operation'] is not True:
        raise ValueError('latest serialized operation must be freshly reconciled')
    owner_ref = packet['owner']
    raw = Path(owner_ref['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != owner_ref['sha256']:
        raise ValueError('owner source differs')
    spec = importlib.util.spec_from_file_location('daemon7_retained_owner', owner_ref['path'])
    owner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owner)
    source_map = bound(packet['full11_map'])
    # Use the exact source-map representation retained by SOURCE27 approval.
    approval = bound(packet['source_approval'])
    owner.validate_runtime_source_bindings(approval['source_sha256'])
    request = bound(packet['request'])
    owner.output_namespace(request)
    mount = owner.live_admission(request)
    capacity = owner.measure(request)
    conflicts = {owner.LEASE, owner.COMMON, Path(owner.shared.SHARED_HEAVY_LOCK_PATH),
                 Path(owner.image.COMMON_EXCLUSION), Path(owner.host.OPERATIONAL_EXCLUSION_PATH)}
    conflicts.update(owner.ROOT.glob('native-exact-mckernel-image-lease-*.json'))
    if any(os.path.lexists(p) for p in conflicts):
        raise ValueError('active resource owner blocks query')
    evidence = D/'actual-readonly-query-1'
    evidence.mkdir(mode=0o700)
    with owner.DeferredSignals() as latch:
        client = owner.ExternalDocker(evidence/'image-inspect.log', latch, sudo=True)
        result = client.call(['image', 'inspect', request['image_id']], timeout=15)
        if result.returncode != 0 or client.client_retirement_unproven:
            raise ValueError('image inspection or client retirement failed')
        rows = json.loads(result.stdout)
        if len(rows) != 1 or rows[0]['Id'] != request['image_id'] or rows[0]['Architecture'] != 'amd64':
            raise ValueError('pinned image differs')
        client.check_all_client_groups()
        if client.client_retirement_unproven:
            raise ValueError('image client retirement unproven')
    report = dict(at=time.time(), window=packet['window'], aggregate_memory_GiB=os.environ['MCKERNEL_OS_MEMORY_GIB'],
                  normal_retirement_acceptance_sha256=current['normal_retirement_acceptance_sha256'],
                  live_identity_and_resource_gates=True, conflict_paths_absent=[str(p) for p in sorted(conflicts)],
                  request_image_id=request['image_id'], group_checks=client.group_checks,
                  boot_id=release['boot_id'], boot_deadline=release['boot_deadline'], monotonic_deadline=release['monotonic_deadline'],
                  wall_deadline_epoch=release['wall_deadline_epoch'], status='PASS_READONLY_DAEMON7_NEW18H_CAPACITY_IDENTITY_IMAGE_ONLY',
                  scope=packet['scope'], request=packet['request'], current_physical=packet['current_physical'],
                  SDK21_artifact_behavior=packet['SDK21_artifact_behavior'], resources=capacity, mount=mount,
                  image_id=rows[0]['Id'], target_calls=0, container_create_calls=0, SDK_execution_released=False)
    (evidence/'ADMISSION.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(status=report['status'], at=report['at'], resources=capacity, target_calls=0, container_create_calls=0)))

if __name__ == '__main__':
    main()
