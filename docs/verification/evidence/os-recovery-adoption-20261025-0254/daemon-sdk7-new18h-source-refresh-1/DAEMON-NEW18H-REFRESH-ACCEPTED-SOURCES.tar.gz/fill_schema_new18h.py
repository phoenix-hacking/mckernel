"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure schema adapter for the daemon7 new18h fill. No owner or live observer imports.
"""
import copy
import hashlib
import json
import math

MEMAVAILABLE_FLOOR = 25501368320
AGGREGATE_GIB = '22.0485'
WINDOW = dict(id='new18h-1792965333924702242', start='2026-10-25T21:55:33Z', deadline='2026-10-26T15:55:33Z')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def validate_query(query, join, packet, now, aggregate_env):
    require(aggregate_env == AGGREGATE_GIB, 'actual aggregate environment differs')
    require(query['status'] == 'PASS_READONLY_DAEMON7_NEW18H_CAPACITY_IDENTITY_IMAGE_ONLY', 'new18h query schema required')
    require(query['request'] == packet['request'], 'query request differs')
    require(query['current_physical'] == packet['current_physical'], 'query current physical proof differs')
    require(query['SDK21_artifact_behavior'] == packet['SDK21_artifact_behavior'], 'query SDK21 proof differs')
    require(query['window'] == packet['window'] == WINDOW, 'fixed parent window differs')
    require(query['aggregate_memory_GiB'] == aggregate_env, 'query aggregate environment differs')
    require(type(query['at']) in (int, float) and math.isfinite(query['at']) and
            type(now) in (int, float) and math.isfinite(now) and 0 <= now-query['at'] <= 120,
            'query must be fresh within120seconds')
    require(query['target_calls'] == query['container_create_calls'] == 0 and query['SDK_execution_released'] is False,
            'read-only query must not execute workload')
    resources = query['resources']
    require(type(resources['memory_available']) is int and resources['memory_available'] >= MEMAVAILABLE_FLOOR,
            'preserved available-memory floor')
    for key in ('host', 'scratch'):
        require(type(resources[key+'_free']) is int and type(resources[key+'_minimum_bytes']) is int and
                resources[key+'_minimum_bytes'] >= (16 if key == 'host' else 12)*2**30 and
                resources[key+'_free'] >= resources[key+'_minimum_bytes'], 'preserved '+key+' capacity gate')
    require(query['live_identity_and_resource_gates'] is True and query['conflict_paths_absent'],
            'live request identity and resource gates required')
    require(query['image_id'] == query['request_image_id'] == 'sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5',
            'pinned image differs')
    require(join['returncode'] == 0 and all(join[k] is True for k in ('direct_child_joined','group_absent','closed_streams')),
            'query wholejoin incomplete')
    require(join['error'] is None and join['retirement_error'] is None and join['timed_out'] is False and
            join['remaining_group_members'] == join['unexpected_group_members'] == [], 'query retirement incomplete')
    require(join['captures']['stderr']['size'] == 0 and join['captures']['stderr']['sha256'] == hashlib.sha256(b'').hexdigest(),
            'query stderr must be empty')
    return resources


def make_payload(base, packet, source_review, source_map, fetched, current, query, join,
                 publication, refresh_review, now, aggregate_env, refs):
    resources = validate_query(query, join, packet, now, aggregate_env)
    require(base['status'] == 'PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW' and
            base['execution_release'] is False and base['execution_review'] is None, 'pending release base required')
    require(base['nonce'] == '8349b6a1fc6d428aa250521380cacf8d' and base['request'] == {k: packet['request'][k] for k in ('path','sha256')} and source_review['request_sha256'] == packet['request']['sha256'], 'exact request nonce required')
    require(base['source_sha256'] == source_map['source_sha256'] == source_review['source_sha256'], 'unchanged full11 source map required')
    require(source_review['decision'] == 'PASS_SOURCE' and source_review['implementation_ownership'] is False and
            source_review['execution_authority'] is False and source_review['SDK_execution_released'] is False and
            source_review['reviewer'] != base['author'], 'independent unchanged source27 approval required')
    require(source_review['provider_sha256'] == packet['provider']['sha256'] == '89639e9d56c390968a86a95bb734128ec61bd0f6de28f7c7992cfb9e00b9ef96', 'produced provider differs')
    require(fetched['status'] == 'PASS_ACTUAL_FETCHED_SOURCE' and fetched['source_archive_member_count'] == 27 and
            fetched['heavy_execution_release'] is False and fetched['source_archive_sha256'] == 'f7bfc850c50d7f30eb7dd5dec436d7fe5fa6f32b264d7be4db971491fd770435', 'genuine source27 fetched proof required')
    require(publication['status'] == 'PASS_ACTUAL_FETCHED_DAEMON_NEW18H_SOURCE_REFRESH' and
            publication['commit'] == publication['fetched_commit'] and len(publication['commit']) == 40 and
            all(c in '0123456789abcdef' for c in publication['commit']), 'genuine fetched refreshed source publication required')
    require(publication['source27'] == packet['source27'] and publication['current_physical'] == packet['current_physical'] and
            publication['SDK21_artifact_behavior'] == packet['SDK21_artifact_behavior'] and
            publication['source_refs'] == packet['refresh_sources'] and publication['packet'] == refs['packet'], 'exact refreshed publication tuple differs')
    require(refresh_review['decision'] == 'PASS_SOURCE_REFRESH' and refresh_review['implementation_ownership'] is False and
            refresh_review['reviewer'] != base['author'] and refresh_review['source_refs'] == packet['refresh_sources'] and
            refresh_review['current_physical'] == packet['current_physical'] and refresh_review['SDK_execution_released'] is False,
            'independent narrow refresh source review required')
    require(current['normal_retirement_acceptance_sha256'] == query['normal_retirement_acceptance_sha256'], 'query retirement binding differs')
    payload = copy.deepcopy(base)
    payload.pop('execution_review')
    payload.update(status='PASS_EXECUTION_RELEASE', execution_release=True,
                   source_review=refs['source_review'], fetched_source_verified=True, fetched_source_proof=refs['fetched'],
                   current_authority_source_proof=refs['publication'], current_physical=refs['current_stdout'],
                   current_live_postjoin=refs['current_stdout'], current_physical_acceptance=packet['current_physical'],
                   current_proof_schema=current['schema'], current_proof_is_combined_physical_postjoin=True,
                   source_refresh_review=refs['refresh_review'], actual_query=refs['query'],
                   actual_query_whole_join=refs['join'], actual_query_stdout=refs['stdout'],
                   readonly_query_source=refs['query_source'], query_export=refs['query_export'],
                   window=WINDOW, aggregate_review=dict(one_heavy=True, jobs=7, aggregate_memory_GiB=aggregate_env,
                   memory_available_required_bytes=MEMAVAILABLE_FLOOR, memory_available=resources['memory_available'],
                   host_reserve_bytes=4*2**30, control_monitor_bytes=4026531840,
                   heavy_CPUs=[2,3,4,5], heavy_memory_bytes=12*2**30, ordinary_CPUs=[0,6], ordinary_memory_each=2*2**30,
                   CPU1_excluded=True, scratch_actual=resources['scratch_free'], scratch_required=resources['scratch_minimum_bytes']))
    return payload
