"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure source-schema regressions. Synthetic query/publication/review are fixtures only.
"""
from pathlib import Path
import ast
import copy
import hashlib
import json
from current_authority import bound
from fill_schema_new18h import make_payload, canonical, MEMAVAILABLE_FLOOR

D=Path(__file__).resolve().parent

def run():
    packet=json.loads((D/'CONSUMER.NEXT18H.PENDING.json').read_text())
    base=bound(packet['pending_release_base']);approval=bound(packet['source_approval'])
    source_map=bound(packet['full11_map']);fetched=bound(packet['fetched_source']);current=bound(packet['current_physical'])
    query=dict(status='PASS_READONLY_DAEMON7_NEW18H_CAPACITY_IDENTITY_IMAGE_ONLY',request=packet['request'],
               current_physical=packet['current_physical'],SDK21_artifact_behavior=packet['SDK21_artifact_behavior'],
               window=packet['window'],aggregate_memory_GiB='22.0485',at=1000,target_calls=0,container_create_calls=0,
               SDK_execution_released=False,resources=dict(memory_available=MEMAVAILABLE_FLOOR,host_free=40*2**30,
               host_minimum_bytes=32*2**30,scratch_free=30*2**30,scratch_minimum_bytes=20*2**30),
               live_identity_and_resource_gates=True,conflict_paths_absent=['fixture-absence'],
               image_id='sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5',
               request_image_id='sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5',
               normal_retirement_acceptance_sha256=current['normal_retirement_acceptance_sha256'])
    join=dict(returncode=0,direct_child_joined=True,group_absent=True,closed_streams=True,error=None,
              retirement_error=None,timed_out=False,remaining_group_members=[],unexpected_group_members=[],
              captures=dict(stderr=dict(size=0,sha256=hashlib.sha256(b'').hexdigest())))
    packet_ref=dict(path=str(D/'CONSUMER.NEXT18H.PENDING.json'),bytes=(D/'CONSUMER.NEXT18H.PENDING.json').stat().st_size,
                    sha256=hashlib.sha256((D/'CONSUMER.NEXT18H.PENDING.json').read_bytes()).hexdigest())
    pub=dict(status='PASS_ACTUAL_FETCHED_DAEMON_NEW18H_SOURCE_REFRESH',commit='a'*40,fetched_commit='a'*40,
             source27=packet['source27'],current_physical=packet['current_physical'],
             SDK21_artifact_behavior=packet['SDK21_artifact_behavior'],source_refs=packet['refresh_sources'],packet=packet_ref)
    review=dict(decision='PASS_SOURCE_REFRESH',implementation_ownership=False,reviewer='fixture-independent-reviewer',
                source_refs=packet['refresh_sources'],current_physical=packet['current_physical'],SDK_execution_released=False)
    refs=dict(packet=packet_ref,source_review=packet['source_approval'],fetched=packet['fetched_source'],
              publication={'fixture':True},refresh_review={'fixture':True},current_stdout=current['stdout'],
              query={'fixture':True},join={'fixture':True},stdout={'fixture':True},query_source=packet['refresh_sources']['query'],query_export=None)
    args=[base,packet,approval,source_map,fetched,current,query,join,pub,review,1001,'22.0485',refs]
    payload=make_payload(*args)
    assert payload['aggregate_review']['aggregate_memory_GiB']=='22.0485'
    assert payload['aggregate_review']['memory_available_required_bytes']==MEMAVAILABLE_FLOOR
    assert payload['source_sha256']==base['source_sha256'] and 'execution_review' not in payload
    assert payload['current_physical']==payload['current_live_postjoin']==current['stdout']
    assert payload['current_proof_is_combined_physical_postjoin'] is True
    cases=[]
    def case(label,index,path,value):
        a=[copy.deepcopy(x) for x in args];obj=a[index]
        for key in path[:-1]:obj=obj[key]
        obj[path[-1]]=value;cases.append((label,a))
    for key,value in [('status','PASS_OLD_C_C_QUERY'),('aggregate_memory_GiB','24'),('at',880),('target_calls',1),('container_create_calls',1),('SDK_execution_released',True),('live_identity_and_resource_gates',False),('conflict_paths_absent',[]),('normal_retirement_acceptance_sha256','0'*64),('image_id','different')]:
        case(key,6,[key],value)
    case('future query',6,['at'],1002)
    case('nonfinite query',6,['at'],float('nan'))
    case('old current proof',6,['current_physical','sha256'],'71dfa12d'+'0'*56)
    for key,value in [('memory_available',MEMAVAILABLE_FLOOR-1),('host_free',31*2**30),('scratch_free',19*2**30),('host_minimum_bytes',0),('scratch_minimum_bytes',0)]:case(key,6,['resources',key],value)
    for key,value in [('returncode',1),('direct_child_joined',False),('group_absent',False),('closed_streams',False),('error','failure'),('retirement_error','failure'),('timed_out',True),('remaining_group_members',[123]),('unexpected_group_members',[123])]:case(key,7,[key],value)
    case('stderr bytes',7,['captures','stderr','size'],1)
    case('pending source review',2,['decision'],'PENDING')
    case('provider differs',2,['provider_sha256'],'0'*64)
    case('unfetched source27',4,['status'],'PENDING')
    case('unfetched refresh',8,['status'],'PENDING')
    case('wrong fetched commit',8,['fetched_commit'],'b'*40)
    case('refresh source ownership',9,['implementation_ownership'],True)
    case('refresh grants SDK',9,['SDK_execution_released'],True)
    case('pending base differs',0,['execution_release'],True)
    for label,a in cases:
        try:make_payload(*a)
        except ValueError:pass
        else:raise AssertionError('negative accepted: '+label)
    a=[copy.deepcopy(x) for x in args];a[11]='24'
    try:make_payload(*a)
    except ValueError:pass
    else:raise AssertionError('wrong actual aggregate accepted')
    # Exact retained stable-reader/export-writer bodies are preserved.
    old=Path(packet['historical_fill']['path']).read_text()
    new=(D/'fill_daemon_new18h.NOT-RELEASED.py').read_text()
    def bodies(source):
        return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    oldf,newf=bodies(old),bodies(new)
    for name in ('load_raw','read','write_raw','write'):assert oldf[name]==newf[name]
    for name in ('fill_daemon_new18h.NOT-RELEASED.py','fill_schema_new18h.py','query_daemon7_new18h.NOT-RELEASED.py'):
        ast.parse((D/name).read_text())
    result=dict(scope=packet['scope'],status='PASS_PURE_NEW18H_FILL_SCHEMA_CONTROLS',positive=1,negative=len(cases)+1,
                retained_IO_function_AST_matches=4,live_query_runs=0,SDK_runs=0,fixture_payload_published=False)
    (D/'FILL-STATIC-REGRESSION-RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':run()
