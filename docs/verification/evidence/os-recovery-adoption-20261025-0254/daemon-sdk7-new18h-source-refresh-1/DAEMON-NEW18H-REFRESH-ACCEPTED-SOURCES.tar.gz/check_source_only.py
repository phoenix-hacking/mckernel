"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Validate source27/provider/current-proof bytes only. Never import runtime owners.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys
from current_authority import bound, validate_current

D = Path(__file__).resolve().parent

def main():
    if sys.argv[1:] != ['--check-source-only']:
        raise ValueError('source-only mode required')
    packet = json.loads((D/'CONSUMER.NEXT18H.PENDING.json').read_bytes())
    validate_current(bound(packet['current_physical']), bound(packet['SDK21_artifact_behavior']))
    manifest = bound(packet['source27'])
    approval = bound(packet['source_approval'])
    if approval['decision'] != 'PASS_SOURCE' or approval['execution_authority'] is not False:
        raise ValueError('source approval scope differs')
    if len(manifest['members']) != 27 or manifest['member_count'] != 27:
        raise ValueError('source27 count differs')
    for ref in manifest['members'].values():
        raw = Path(ref['path']).read_bytes()
        if len(raw) != ref['bytes'] or hashlib.sha256(raw).hexdigest() != ref['sha256']:
            raise ValueError('source27 member changed')
    for ref in packet['readset'] + list(packet['refresh_sources'].values()):
        raw = Path(ref['path']).read_bytes()
        if len(raw) != ref['bytes'] or hashlib.sha256(raw).hexdigest() != ref['sha256']:
            raise ValueError('consumer input changed: ' + ref['path'])
    for name in ('current_authority.py', 'check_source_only.py', 'query_daemon7_new18h.NOT-RELEASED.py', 'fill_schema_new18h.py', 'fill_daemon_new18h.NOT-RELEASED.py'):
        ast.parse((D/name).read_text())
    qualifier = ast.parse(Path(packet['readset'][0]['path']).read_text())
    main_node = next(n for n in qualifier.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    env = {'BASE': Path('/candidate'), 'OUT': Path('/work/daemon-sdk-1'),
           'binary': Path('/work/daemon-sdk-1/build/sdk-daemon/ihkmond')}
    def value(node, local):
        if isinstance(node, ast.Constant): return node.value
        if isinstance(node, ast.Name): return local[node.id]
        if isinstance(node, (ast.Tuple, ast.List)): return [value(v, local) for v in node.elts]
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div): return value(node.left,local)/value(node.right,local)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add): return value(node.left,local)+value(node.right,local)
        raise ValueError('unexpected command AST')
    actual = []
    def collect(nodes, local):
        for node in nodes:
            if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple) and all(isinstance(e,ast.Name) for e in node.target.elts) and [e.id for e in node.target.elts] == ['label','source']:
                for pair in value(node.iter,local):
                    collect(node.body, dict(local, label=pair[0], source=pair[1]))
            expr = node.value if isinstance(node, (ast.Expr, ast.Assign)) else None
            if isinstance(expr, ast.Call) and isinstance(expr.func, ast.Name) and expr.func.id == 'run':
                actual.append(dict(label=value(expr.args[0],local),argv=[str(v) for v in value(expr.args[1],local)]))
    collect(main_node.body,env)
    if actual != packet['seven_commands'] or len(actual) != 7:
        raise ValueError('exact seven command expansion differs from actual qualifier AST')
    if any(packet[k] is not None for k in ('publication', 'source_refresh_review', 'query_release', 'SDK_execution_release', 'clock_boot_cutoff', 'clock_monotonic_cutoff')):
        raise ValueError('source-only pending fields must remain null')
    print(json.dumps(dict(status='PASS_STATIC_DAEMON7_SOURCE27_PROVIDER_CURRENT_BINDING',
                          commands=len(packet['seven_commands']), source_members=27,
                          runtime_executed=False, query_executed=False, execution_release=False)))

if __name__ == '__main__':
    main()
