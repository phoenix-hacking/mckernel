#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Compare genuine ELF64 C/Rust ABI data witnesses. Does not execute kernel code.
"""
import json
from pathlib import Path
import struct
import sys


def elf(path, wanted):
    raw = path.read_bytes()
    if raw[:7] != b'\x7fELF\x02\x01\x01':
        raise ValueError('expected ELF64 little endian ' + str(path))
    header = struct.unpack_from('<HHIQQQIHHHHHH', raw, 16)
    if header[0] != 1 or header[1] != 62 or header[10] != 64:
        raise ValueError('expected x86_64 relocatable with 64-byte section headers')
    section_offset, section_count = header[5], header[11]
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw, section_offset + 64 * i)
                for i in range(section_count)]
    matches, undefined = [], set()
    for section in sections:
        if section[1] != 2:
            continue
        strings = sections[section[6]]
        names = raw[strings[4]:strings[4] + strings[5]]
        if section[9] != 24:
            raise ValueError('unexpected ELF64 symbol entry size')
        for offset in range(section[4], section[4] + section[5], 24):
            name, info, _, index, value, size = struct.unpack_from('<IBBHQQ', raw, offset)
            end = names.index(b'\0', name)
            symbol = names[name:end].decode('ascii')
            if index == 0 and symbol:
                undefined.add(symbol)
            if symbol != wanted:
                continue
            if index == 0 or info >> 4 != 1 or size != 36 * 8:
                raise ValueError('ABI witness must be a global defined 36-word table')
            storage = sections[index]
            if value + size > storage[5]:
                raise ValueError('ABI witness outside section')
            begin = storage[4] + value
            matches.append(struct.unpack_from('<36Q', raw, begin))
    if len(matches) != 1:
        raise ValueError('expected exactly one ABI witness ' + wanted)
    return matches[0], undefined


def main():
    rust, providers = elf(Path(sys.argv[1]), 'SOURCE34_RUST_ABI')
    c, c_providers = elf(Path(sys.argv[2]), 'SOURCE34_C_ABI')
    differences = [dict(word=i, Rust=a, C=b) for i, (a, b) in enumerate(zip(rust, c)) if a != b]
    expected = {'get_this_cpu_local_var', 'process_list_is_linked_result',
                'process_list_detach_result', 'process_mcs_writer_lock_bridge',
                'process_mcs_writer_unlock_bridge', 'panic'}
    if differences or providers != expected or c_providers:
        raise ValueError(json.dumps(dict(ABI_differences=differences,
                                        Rust_undefined=sorted(providers),
                                        expected_undefined=sorted(expected),
                                        C_undefined=sorted(c_providers))))
    print(json.dumps(dict(scope='Functional OS work only; no security testing.',
                         status='PASS_SOURCE34_GENUINE_HEADER_ABI36_EXACT_SIX_PROVIDER_IMPORTS',
                         words=36, values=list(rust), providers=sorted(providers),
                         native=False, production_default=False)))


if __name__ == '__main__':
    main()
