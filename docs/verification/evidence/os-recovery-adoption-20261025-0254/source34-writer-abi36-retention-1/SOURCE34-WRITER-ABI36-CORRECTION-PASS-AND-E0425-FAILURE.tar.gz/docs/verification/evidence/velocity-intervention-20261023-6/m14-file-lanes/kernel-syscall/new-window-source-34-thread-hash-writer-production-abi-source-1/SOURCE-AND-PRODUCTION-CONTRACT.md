Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source34 owner: process_hash33. Private/default OFF; no canonical/shared write,
compiler, root, Docker or native action. Source33's accepted tree is unchanged.
Next executable check is the exact isolated Rust object command in
EXACT-PROVIDER-AND-C-ABI-COMMANDS.NOT-GRANTED.json, after a fresh coordinator grant.
It unlocks the genuine C-header ABI witness and strict data/import comparison;
production integration and current native qualification remain later gates.

Existing provider reused; missing caller composition implemented

The actual selected source has no `thread_hash_del` symbol or `HashBucket` type.
It has `process_destroy_thread_hash_detach_bridge(void *)` and real
`ThreadHash`/`struct thread_hash`, with list[73] and lock[73]. Both the existing C
reference and canonical Rust implementation already perform writer-locked unlink.
GENUINE-PROVIDER-AND-CALLER-FACTS.json binds those source bodies and their direct
writer/free call sites. Source34 does not claim to implement that existing port.

The new Rust body, `process_destroy_thread_hash_detach_candidate_v3`, supplies the
previously missing production void-callback composition to Source33's unchanged
typed helper (SHA256 59b00885e7e6c5889e0a1a63da3cb79410fee401460653694d11dee1ab152f9f).
It keeps the original unlinked fast return, so that path does not acquire a lock
or access CPU/resource-set state. The existing final owner still excludes
concurrent membership mutation during that original prelock test. The linked
path loads the actual current CPU/resource_set/thread_hash once, gives the helper
its real Thread pointer and aligned caller-owned IRQ-save node, and passes the
actual writer bridge pair. Source33 rechecks membership under the matching writer
and uses one cached bucket address through unlock. No new lock/refcount/global
reader mechanism is invented. Source22's positive-only acquisition artifact is
retained unchanged, not recompiled or linked into this new ABI-only object.

PRODUCTION-CALLER.DEFAULT-OFF.patch changes the Rust `destroy_thread` callback
selection only under `f02_thread_hash_writer_candidate_v3`. Without that cfg,
it supplies exactly the existing Rust provider. The old provider remains intact.
The C delta adds a candidate declaration/type assertion and a guard requiring
the existing Rust process consumer; it adds no compute C body or data. It does
not change production build flags. The actual build must tie C macro
MCKERNEL_RUST_THREAD_HASH_WRITER_V3 to the Rust cfg before selection can qualify.
The patch requires source placement of the unchanged Source33 leaf at
kernel/rust/thread_hash_detach_v3.rs and this new provider leaf at
kernel/rust/thread_hash_writer_provider_v3.rs. Those are proposed destinations,
not edits made by this worker.

Void ABI and genuine fatal backend

The adapter retains `unsafe extern "C" fn(*mut c_void)` and is statically assigned
to the original ProcessThreadActionFn. C declarations use the actual
process_thread_action_fn_t and process_mcs_rwlock_fn_t, with incompatible types
rejected by the proposed genuine C compiler command. The new internal helper
returns C int; negative setup results cannot silently return to a void destructor
and permit a still-published allocation to be freed.

Failures use ONLY the already existing kernel backend: `super::panic`, declared
in process_helpers.rs as `fn panic(*const i8) -> !`; exported by
kernel/rust/abort.rs as `#[no_mangle] pub unsafe extern "C" fn panic(*const i8) -> !`;
included unconditionally by `mod abort` in kernel/rust/lib.rs. Its genuine C
declaration is `void panic(const char *)` in lib/include/ihk/debug.h. These exact
origins are hash-bound. Static NUL-terminated messages pass through that existing
ABI. No Rust panic!, assertion, unwrap, core::panicking import, allocator or new
fatal callback is introduced in the runtime adapter. The proposed object check
requires exactly six undefined providers, including that existing `panic` symbol;
extra core::panicking/bounds/overflow imports fail the check. Current image/link
provider evidence still must bind the actual selected abort object; source export
presence alone is not new current-default-link acceptance.

Under the real supported linked-thread caller contract, null Thread, null current
CPU, null resource_set, null thread_hash, negative TID and invalid bucket geometry
are unreachable. The final owner provides live storage, a stable valid published
TID, the real current resource_set/hash and genuine lock callbacks. The adapter
adds fatal diagnostics for invalid setup rather than authorizing a silent free.
These unsupported states are not new syscall error behavior. The original
supported unlinked return and successful linked detach behavior stay the same.
The original prelock membership contract and one-time no-poisoned-retry rule
remain required; this candidate does not erase them.

Bound writers, frees and process lifetime

The bound Rust `chain_thread_checked`/process_chain_thread_body_result publish to
the same table/bucket using the matching writer. The bound old final-detach
provider unlinks before later thread destruction. `destroy_thread` is called
through process_destroy_thread_bridge by both ordinary and checked final-release
paths. `process_release_thread_body_result` and its checked variant decrement
first, invoke profile and procfs removal, then call destroy_thread before VM
release. Profile frees event storage, not the thread allocation; procfs provider
lifetime is still a real production obligation, not asserted by these fixtures.

`process_destroy_thread_body_result` invokes hash detach before sibling teardown,
TID updates, pending/optional cleanup, sigcommon release and nonmain thread page
free. For a main thread it retains stack storage for later process final release;
`process_release_process_body_result` frees that main_thread before freeing the
Process itself. Current VM/process reference ordering must preserve Process.pid
and every found thread's storage until the matching reader releases. Source22's
reader can see a final-zero thread while its writer waits, but its positive CAS
must reject it; a positive acquired edge prevents final destruction until release.
Source33's accepted five HOST tests qualify only their actual tested composition.

The direct C free sites are retained in the caller-facts JSON. Creation and clone
rollback callbacks are separate prepublication candidates: their complete
publication/rollback paths must be qualified before asserting that all frees are
covered by the final-detach adapter. Rust direct free occurrences, including
creation and clone cleanup, are also recorded without claiming their ownership
from occurrence counts. No repository-wide freeing-path acceptance follows from
this focused extraction. The complete production process/VM/main-thread lifetime,
all configuration-specific freeing paths and current native contention remain
OPEN. Global-data C debt, including existing runq_reservation_lock,
resource_set_lock and resource_set_list ownership, is unchanged and OPEN.

Prepared ABI/source checks and limits

The C and Rust witnesses contain the same 36 actual sizeof/alignment/offsetof/
array-element/callback-width facts: Thread identity/hash/refcount/process/VM,
Process PID, ThreadHash list/lock layout, real MCS lock/node, CPU resource_set,
ResourceSet thread_hash, list links, C integer types and hash count. The C witness
uses genuine headers and no executable main or C runtime body. The Rust witness
uses a byte-identical ABI snapshot and exact selected IRQ-save node declaration.
The prior accepted Source22 C include/config profile is explicitly recorded as a
reused ordinary fixture profile; it is not inferred to be the new default image.
All current bound headers must remain exact before actual compilation.

Three proposed commands: isolated Rust object compile (panic=abort), real-header
C data/prototype object compile, and read-only ELF64 data/import comparison. The
comparison requires all 36 words equal, C undefined providers empty, and Rust
undefined providers exactly get_this_cpu_local_var, process_list_is_linked_result,
process_list_detach_result, process_mcs_writer_lock_bridge,
process_mcs_writer_unlock_bridge and panic. No native code or test program runs.
The fixture node type is an exact selected source declaration, not proof of
runtime IRQ handling; Source33 retained the actual lock-provider HOST checks.

No command has run. Fresh coordinator resource/CPU admission, independent source
and ABI/lifetime review, actual selected fullcrate/C compilation, default link,
current genuine providers, configuration obligations and native acceptance remain
OPEN. Existing C references stay intact. Source/ABI passes do not retire a C file
or complete M14. Keep one failure plus one bounded correction per failure family,
then expert escalation; preserve all original Source22/33 failures and results.
