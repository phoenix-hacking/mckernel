/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
/* Header-only ABI data witness; no C runtime implementation or executable main. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <ihk/debug.h>
#include <process.h>
#include <process_helpers.h>
#include "WRITER-PROVIDER-ABI.C-DECLARATIONS.inc"

_Static_assert(__builtin_types_compatible_p(__typeof__(&panic), void (*)(const char *)),
    "candidate uses the existing kernel panic pointer ABI, never Rust panic!");

const unsigned long SOURCE34_C_ABI[36] = {
    sizeof(struct thread), __alignof__(struct thread),
    __builtin_offsetof(struct thread, tid), __builtin_offsetof(struct thread, hash_list),
    __builtin_offsetof(struct thread, refcount), __builtin_offsetof(struct thread, proc),
    __builtin_offsetof(struct thread, vm), sizeof(((struct thread *)0)->refcount.counter),
    __builtin_offsetof(struct process, pid), sizeof(struct process), __alignof__(struct process),
    sizeof(struct thread_hash), __alignof__(struct thread_hash),
    __builtin_offsetof(struct thread_hash, list), __builtin_offsetof(struct thread_hash, lock),
    sizeof(struct mcs_rwlock_lock), __alignof__(struct mcs_rwlock_lock),
    sizeof(struct mcs_rwlock_node_irqsave), __alignof__(struct mcs_rwlock_node_irqsave),
    __builtin_offsetof(struct cpu_local_var, resource_set),
    sizeof(struct resource_set), __alignof__(struct resource_set),
    __builtin_offsetof(struct resource_set, thread_hash),
    sizeof(struct list_head), __alignof__(struct list_head),
    __builtin_offsetof(struct list_head, next), __builtin_offsetof(struct list_head, prev),
    sizeof(unsigned long), __alignof__(unsigned long), sizeof(int), __alignof__(int),
    HASH_SIZE, sizeof(process_thread_action_fn_t), sizeof(process_mcs_rwlock_fn_t),
    sizeof(((struct thread_hash *)0)->list[0]), sizeof(((struct thread_hash *)0)->lock[0]),
};
