#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Prepare private provider/selection/ABI witnesses. Never compiles or runs a workload.
"""
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SOURCE33 = ROOT.parent / 'new-window-source-33-thread-hash-positive-acquisition-source-1'
SOURCE22 = ROOT.parent / 'new-window-source-22-positive-reference-lookup-repair'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def body(text, name):
    # Find a definition, not the earlier extern-block declaration/prototype.
    match = re.search(r'(?:pub(?:\([^)]*\))? )?(?:unsafe )?(?:extern "C" )?fn '
                      + re.escape(name) + r'\([^;{]*\)[^;{]*\{', text)
    if match is None:
        raise ValueError('missing implementation ' + name)
    begin = match.start()
    depth, end = 1, match.end()
    while depth:
        if text[end] == '{':
            depth += 1
        elif text[end] == '}':
            depth -= 1
        end += 1
    return text[begin:end]


def main():
    genuine = ROOT / 'genuine'
    genuine.mkdir(exist_ok=False)
    abi = REPO / 'kernel/rust/abi.rs'
    (genuine / 'abi.rs').write_bytes(abi.read_bytes())
    process = REPO / 'kernel/rust/process_helpers.rs'
    text = process.read_text()
    hash_source = body(text, 'thread_hash')
    hash_size = re.search(r'^const HASH_SIZE:[^\n]*', text, re.M).group()
    (genuine / 'thread_hash.ACTUAL.rs.inc').write_text(hash_size + '\n' + hash_source + '\n')
    lock = REPO / 'kernel/rust/lock_helpers.rs'
    lock_text = lock.read_text()
    begin = lock_text.index('#[repr(C, align(64))]\npub struct McsRwlockNodeIrqsave')
    end = lock_text.index('\n}', begin) + 2
    (genuine / 'lock_node.ACTUAL.rs.inc').write_text(lock_text[begin:end] + '\n')

    names = ('process_destroy_thread_hash_detach_bridge', 'destroy_thread',
             'process_destroy_thread_bridge', 'process_destroy_thread_body_result',
             'release_thread', 'release_thread_checked', 'release_thread_runtime_final_checked',
             'process_release_thread_body_result', 'process_release_thread_checked_body_result',
             'process_release_process_body_result', 'process_free_thread_pages_bridge',
             'chain_thread_checked', 'process_chain_thread_body_result',
             'process_procfs_delete_thread_bridge', 'process_release_thread_profile_bridge',
             'process_mcs_reader_lock_bridge', 'process_mcs_reader_unlock_bridge',
             'process_mcs_writer_lock_bridge', 'process_mcs_writer_unlock_bridge')
    selected = {name: body(text, name) for name in names}
    (genuine / 'selected_writer_and_free_bodies.rs.txt').write_text(
        '\n\n'.join('// ' + name + '\n' + value for name, value in selected.items()) + '\n')
    c = REPO / 'kernel/process.c'
    c_text = c.read_text()
    c_sites = [dict(line=i, text=line) for i, line in enumerate(c_text.splitlines(), 1)
               if re.search(r'process_(destroy_thread_hash_detach_bridge|free_thread_pages_bridge)'
                            r'|mcs_rwlock_writer_(?:lock|unlock)\(&resource_set->thread_hash', line)]
    origins = dict(process_Rust=pin(process), process_C=pin(c), ABI=pin(abi), lock=pin(lock),
                   abort=pin(REPO / 'kernel/rust/abort.rs'),
                   Rust_module_root=pin(REPO / 'kernel/rust/lib.rs'),
                   panic_C_header=pin(REPO / 'lib/include/ihk/debug.h'))
    source_facts = dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; '
                             'no security testing.', origins=origins,
                        actual_writer_symbol='process_destroy_thread_hash_detach_bridge(void *)',
                        no_thread_hash_del_or_HashBucket_symbol=True,
                        selected_bodies={name: dict(bytes=len(value.encode()),
                                                   sha256=hashlib.sha256(value.encode()).hexdigest())
                                         for name, value in selected.items()},
                        selected_C_writer_and_free_sites=c_sites,
                        whole_repository_free_path_acceptance=False)
    (ROOT / 'GENUINE-PROVIDER-AND-CALLER-FACTS.json').write_text(
        json.dumps(source_facts, indent=2) + '\n')

    # One private source patch: replace only the Rust destroy_thread callback
    # selection. The existing provider and every default consumer remain intact.
    rust_new = text + '''
// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#[cfg(f02_thread_hash_writer_candidate_v3)]
#[path = "thread_hash_detach_v3.rs"]
mod f02_thread_hash_writer_v3;
#[cfg(f02_thread_hash_writer_candidate_v3)]
#[path = "thread_hash_writer_provider_v3.rs"]
mod f02_thread_hash_writer_provider_v3;
'''
    old = 'pub unsafe extern "C" fn destroy_thread(thread: *mut Thread) {\n'
    new = old + '''    #[cfg(f02_thread_hash_writer_candidate_v3)]
    let hash_detach_fn: ProcessThreadActionFn =
        f02_thread_hash_writer_provider_v3::process_destroy_thread_hash_detach_candidate_v3;
    #[cfg(not(f02_thread_hash_writer_candidate_v3))]
    let hash_detach_fn: ProcessThreadActionFn = process_destroy_thread_hash_detach_bridge;
'''
    assert rust_new.count(old) == 1
    rust_new = rust_new.replace(old, new, 1)
    start = rust_new.index(new)
    callback = '        Some(process_destroy_thread_hash_detach_bridge),'
    index = rust_new.index(callback, start)
    rust_new = rust_new[:index] + rust_new[index:].replace(callback, '        Some(hash_detach_fn),', 1)
    c_insert = '''
/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#ifdef MCKERNEL_RUST_THREAD_HASH_WRITER_V3
#ifndef MCKERNEL_RUST_PROCESS_HELPERS
#error "thread-hash writer candidate requires the existing Rust process consumer"
#endif
void process_destroy_thread_hash_detach_candidate_v3(void *thread);
_Static_assert(__builtin_types_compatible_p(
    __typeof__(&process_destroy_thread_hash_detach_candidate_v3), process_thread_action_fn_t),
    "thread-hash writer candidate preserves the original void callback ABI");
#endif
'''
    c_new = c_text.replace('#include <process_helpers.h>\n',
                           '#include <process_helpers.h>\n' + c_insert, 1)
    patch = ''.join(difflib.unified_diff(text.splitlines(True), rust_new.splitlines(True),
                                       fromfile='a/kernel/rust/process_helpers.rs',
                                       tofile='b/kernel/rust/process_helpers.rs'))
    patch += ''.join(difflib.unified_diff(c_text.splitlines(True), c_new.splitlines(True),
                                        fromfile='a/kernel/process.c', tofile='b/kernel/process.c'))
    (ROOT / 'PRODUCTION-CALLER.DEFAULT-OFF.patch').write_text(patch)

    prior = json.loads((SOURCE22 / 'EXACT-LOOKUP-REPAIR-C-SUFFIX.NOT-GRANTED.json').read_text())
    c_argv = prior['commands'][0]['argv']
    source_start = c_argv.index(str(SOURCE22 / 'driver.c'))
    c_argv = c_argv[:source_start] + ['-c', str(ROOT / 'abi-witness.c'),
                                    '-o', str(ROOT / 'output-1/header-abi.o')]
    rustc = Path('/home/holden/mckernel-work/toolchains/rustup/toolchains/'
                 '1.92.0-x86_64-unknown-linux-gnu/bin/rustc')
    rust_argv = [str(rustc), '--crate-name', 'source34_writer_provider', '--crate-type', 'lib',
                 '--edition=2021', '-C', 'panic=abort', '-C', 'opt-level=2',
                 '--emit=obj=' + str(ROOT / 'output-1/provider.o'), str(ROOT / 'lib.fixture.rs')]
    inputs = [pin(ROOT / name) for name in ('thread_hash_writer_provider_v3.rs', 'lib.fixture.rs',
              'abi-witness.c', 'WRITER-PROVIDER-ABI.C-DECLARATIONS.inc', 'check_abi_objects.py')]
    inputs += [pin(path) for path in sorted(genuine.iterdir())]
    recipe = dict(scope=source_facts['scope'], status='SOURCE_ONLY_READY_NO_EXECUTION_GRANT',
                  production_default=False, inputs=inputs,
                  unchanged_Source33_writer=pin(SOURCE33 / 'thread_hash_detach_v3.rs'),
                  retained_Source22_not_recompiled=pin(SOURCE22 / 'output-1/candidate.o'),
                  prior_accepted_profile_source=pin(SOURCE22 / 'EXACT-LOOKUP-REPAIR-C-SUFFIX.NOT-GRANTED.json'),
                  header_bindings=[pin(Path(row['path'])) for row in prior['header_bindings']],
                  tools=[pin(rustc), pin(Path('/usr/bin/gcc-9')), pin(Path('/home/holden/anaconda3/bin/python3'))],
                  commands=[dict(argv=argv, cwd=str(REPO), expected_exit=0,
                                 purpose=source_facts['scope'] + ' ' + purpose)
                            for argv, purpose in (
                                (rust_argv, 'Compile private Rust void production callback adapter '
                                 'and unchanged Source33 writer; no Source22 recompilation.'),
                                (c_argv, 'Compile genuine-header data-only C ABI/prototype witness; '
                                 'no compute C runtime implementation.'),
                                (['/home/holden/anaconda3/bin/python3', str(ROOT / 'check_abi_objects.py'),
                                  str(ROOT / 'output-1/provider.o'), str(ROOT / 'output-1/header-abi.o')],
                                 'Compare all 36 real C/Rust ABI facts and exact six production '
                                 'provider imports; reject core panicking or extra unresolved helpers.'))],
                  proposed_profile=dict(ordinary_jobs=1, CPU='fresh coordinator grant required',
                                        AS_bytes=2 << 30, CPU_seconds=60,
                                        whole_wall_seconds=90, retirement_seconds=6),
                  holds=['Independent source/ABI/lifetime review; no execution granted.',
                         'Six actual imports must bind genuine current linked providers.',
                         'C and Rust candidate flags must be tied by actual production build selection.',
                         'Current wholecrate/default-link/all free paths/process lifetime/native OPEN.',
                         'Global-data C and whole-file retirement remain OPEN.'])
    (ROOT / 'EXACT-PROVIDER-AND-C-ABI-COMMANDS.NOT-GRANTED.json').write_text(
        json.dumps(recipe, indent=2) + '\n')


if __name__ == '__main__':
    main()
