// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Production ABI/provider object fixture. No platform emulation or executable run.
#![no_std]
#![allow(dead_code)]

use core::ffi::c_void;
use core::mem::{align_of, offset_of, size_of};

#[path = "genuine/abi.rs"]
mod abi;

use abi::{
    AbiListHead, CInt, CULong, CpuLocalVar, Process, ResourceSet, Thread, ThreadHash,
    PROCESS_HASH_SIZE,
};

mod lock_helpers {
    use crate::abi::CULong;
    include!("genuine/lock_node.ACTUAL.rs.inc");
}

use lock_helpers::McsRwlockNodeIrqsave;

type ProcessMcsRwlockFn = unsafe extern "C" fn(CULong, *mut c_void);
type ProcessThreadActionFn = unsafe extern "C" fn(*mut c_void);

extern "C" {
    fn get_this_cpu_local_var() -> *mut CpuLocalVar;
    fn process_list_is_linked_result(entry: *const AbiListHead) -> CInt;
    fn process_list_detach_result(entry: *mut AbiListHead);
    fn process_mcs_writer_lock_bridge(lock: CULong, node: *mut c_void);
    fn process_mcs_writer_unlock_bridge(lock: CULong, node: *mut c_void);
    fn panic(message: *const i8) -> !;
}

include!("genuine/thread_hash.ACTUAL.rs.inc");

#[path = "../new-window-source-33-thread-hash-positive-acquisition-source-1/thread_hash_detach_v3.rs"]
mod f02_thread_hash_writer_v3;
#[path = "thread_hash_writer_provider_v3.rs"]
mod f02_thread_hash_writer_provider_v3;

#[used]
#[no_mangle]
pub static SOURCE34_RUST_ABI: [usize; 36] = [
    size_of::<Thread>(), align_of::<Thread>(),
    offset_of!(Thread, tid), offset_of!(Thread, hash_list),
    offset_of!(Thread, refcount), offset_of!(Thread, proc), offset_of!(Thread, vm),
    size_of::<CInt>(), offset_of!(Process, pid), size_of::<Process>(), align_of::<Process>(),
    size_of::<ThreadHash>(), align_of::<ThreadHash>(),
    offset_of!(ThreadHash, list), offset_of!(ThreadHash, lock),
    size_of::<abi::McsRwlockLock>(), align_of::<abi::McsRwlockLock>(),
    size_of::<McsRwlockNodeIrqsave>(), align_of::<McsRwlockNodeIrqsave>(),
    offset_of!(CpuLocalVar, resource_set), size_of::<ResourceSet>(), align_of::<ResourceSet>(),
    offset_of!(ResourceSet, thread_hash), size_of::<AbiListHead>(), align_of::<AbiListHead>(),
    offset_of!(AbiListHead, next), offset_of!(AbiListHead, prev),
    size_of::<CULong>(), align_of::<CULong>(), size_of::<CInt>(), align_of::<CInt>(),
    abi::PROCESS_HASH_SIZE, size_of::<ProcessThreadActionFn>(), size_of::<ProcessMcsRwlockFn>(),
    size_of::<AbiListHead>(), size_of::<abi::McsRwlockLock>(),
];
