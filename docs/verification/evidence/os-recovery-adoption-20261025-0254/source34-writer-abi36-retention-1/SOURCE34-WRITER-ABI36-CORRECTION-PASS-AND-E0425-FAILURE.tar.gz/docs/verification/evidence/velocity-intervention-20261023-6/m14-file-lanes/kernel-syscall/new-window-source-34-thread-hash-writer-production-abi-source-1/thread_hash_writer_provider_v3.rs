// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private process_helpers child; proposed caller selection defaults OFF.
use core::ffi::c_void;
use core::mem::MaybeUninit;
use core::ptr::addr_of_mut;

use crate::abi::Thread;
use crate::lock_helpers::McsRwlockNodeIrqsave;

/// Adapt the existing void final-destruction callback to Source33's typed writer.
///
/// The existing provider already has a Rust body. This successor adds only the
/// missing production caller composition to the unchanged Source33 helper. The
/// original unlinked fast return and public void callback ABI are preserved.
///
/// # Safety
/// The caller exclusively owns this live thread's one-time final destruction.
/// It excludes concurrent mutation of the original prelock membership test.
/// This CPU's resource_set, hash table, published TID and adjacent list nodes
/// remain live/stable under the same original writer/IRQ-save protocol. Every
/// allocation free and process/VM/sigcommon release follows successful callback
/// completion; no poisoned previously detached thread is passed again. This is
/// not a positive reference, a second lifetime domain or a new CPU pinning rule.
#[no_mangle]
pub unsafe extern "C" fn process_destroy_thread_hash_detach_candidate_v3(thread_arg: *mut c_void) {
    let thread = thread_arg.cast::<Thread>();
    if thread.is_null() {
        // SAFETY: A failed final-owner setup must not return to the void teardown
        // caller and free a possibly still-published allocation. Static message
        // is NUL-terminated; existing kernel panic does not return.
        unsafe { super::panic(b"thread hash detach: null final owner\0".as_ptr().cast()) };
    }
    // SAFETY: Same final-owner prelock membership obligation as the old provider.
    // Retain the old unlinked fast return without reading CPU/resource-set state.
    let entry = unsafe { addr_of_mut!((*thread).hash_list) };
    if unsafe { super::process_list_is_linked_result(entry) } == 0 {
        return;
    }
    // SAFETY: The original linked path supplies the live current CPU; explicit
    // setup failures stop before any destructive continuation through this void ABI.
    let cpu = unsafe { super::get_this_cpu_local_var() };
    if cpu.is_null() {
        unsafe { super::panic(b"thread hash detach: absent current CPU\0".as_ptr().cast()) };
    }
    let resource_set = unsafe { (*cpu).resource_set };
    if resource_set.is_null() {
        unsafe { super::panic(b"thread hash detach: absent resource set\0".as_ptr().cast()) };
    }
    let hash_table = unsafe { (*resource_set).thread_hash };
    let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    // SAFETY: Genuine ThreadHash storage and existing matching writer callbacks.
    // Source33 rechecks membership while locked and unlocks one cached bucket.
    let result = unsafe {
        super::f02_thread_hash_writer_v3::process_thread_hash_detach_live_body_v3(
            thread,
            hash_table,
            node.as_mut_ptr().cast(),
            Some(super::process_mcs_writer_lock_bridge),
            Some(super::process_mcs_writer_unlock_bridge),
        )
    };
    if result < 0 {
        // SAFETY: The error acquired no writer/reference and authorized no free.
        // Use the existing fatal backend, never silently continue final teardown.
        unsafe { super::panic(b"thread hash detach: invalid writer setup\0".as_ptr().cast()) };
    }
}

const _: super::ProcessThreadActionFn = process_destroy_thread_hash_detach_candidate_v3;
