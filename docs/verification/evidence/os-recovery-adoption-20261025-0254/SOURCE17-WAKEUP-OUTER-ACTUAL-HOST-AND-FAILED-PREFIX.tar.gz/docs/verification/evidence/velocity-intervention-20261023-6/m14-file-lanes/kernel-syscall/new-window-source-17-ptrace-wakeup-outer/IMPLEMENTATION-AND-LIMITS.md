Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

The actual callback is ptrace_wakeup_sig, the remaining wakeup slot in the19-entry
ptrace table. No ptrace_wakeup_sigstop symbol exists in the selected source. This
private successor moves its current-thread read, typed MCS IRQ-save lock-node
storage, genuine offset/provider tuple binding and helper invocation to Rust.
The existing production ptrace_wakeup_sig_body_result and its decision/read helper
bodies are reused unchanged. Twelve provider identities remain identical. Their
lower C bridges remain debt; this is an outer callback candidate only.

Both new selectors remain OFF. No current290 source, canonical file, callback table
or default build selector was changed. The patch retains the entire original
selected/fallback C callback under the unselected branch. Genuine header metadata
contains only immutable offsets and original provider addresses; no new C runtime
algorithm is added. Rust uses the existing McsRwlockNodeIrqsave type, not guessed
scratch size. MaybeUninit storage is passed as a raw node pointer; no assume_init
or read of incoming uninitialized node bytes is introduced. Genuine lock providers
retain the obligation to initialize before use and finish synchronously before
this callback returns. Lookup/unlock, pending take/copy/free, do_kill and wakeup
order remain in the existing helper.

The proposed controlled fixture compares the original SELECTED C outer callback
with the new Rust outer and reuses the actual same full Rust helper. It checks23
real C/Rust ABI words before either callback: CPU/current-thread, genuine MCS
node size/alignment, offsets/table geometry, signal-info size/alignment and all12
provider slots. It then compares4032 pairs:6requests x7signal values x2lookup
outcomes x4fully-initialized pending modes x4do_kill returns x3PIDs. Independent
oracles check result precedence/truncation, original callback identity/arguments,
ordered lookup/unlock, saved context, single-step, balanced live lock-node use,
trace syscall state, pending consumption and initialized bytes, free-before-kill,
wakeup and failure behavior. Snapshot precedes every snapshot-based assertion.
The fixture's static pending objects are fully byte-initialized before any helper
read. Its controlled free provider records retirement; it proves no native heap
lifetime or allocator correctness. Real do_kill and scheduler effects are absent.

Known sendsig copy-fault publication evidence remains preserved under
next-ptrace-resume-initialization-decision-1. A successful initialized-pending
fixture does not qualify those paths or release this whole callback for current290.
No source-only equivalence argument can make indeterminate pending.info valid.

Before whole-callback selection the separate producer/caller qualification must:

1. Bind the actual allocator, copy_from_user provider and current setsiginfo body.
   Cover no-slot allocation failure, copy failure before/after partial writes,
   preexisting initialized sendsig, recvsig and both-slot cases, and success.
2. Establish the intended externally visible copy-fault contract independently;
   verify exact errno, pending pointer identity/ownership, every readable info byte,
   allocation/free balance and preservation of preexisting state. An error may not
   leave a future resume consumer able to read indeterminate bytes. Do not repair
   this by assuming initialization or weakening the observer.
3. Prove caller serialization between producer publication/replacement and resume
   take/copy/free. Cover producer-vs-consumer overlap and reference ownership through
   do_kill and final thread_unlock, including do_kill failure. No double free,
   stale pointer or lock-node escape is permitted by that functional lifetime proof.
4. Exercise the accepted producer result through real resume under the same
   independently reviewed ownership contract, then qualify current fullcrate,
   selected/fallback whole C, genuine provider ABI, partial link and native behavior.

No compiler or fixture command has run for this successor. The next executable
check is exactly the three commands in EXACT-WAKEUP-OUTER-COMMANDS.NOT-GRANTED.json
under a fresh ordinary CPU0 grant after independent source review, using the
existing h990 source-bound capture and AS2G/CPU60/wall90+6/F32/FD256/stack2M/core0
profile. That result can qualify only controlled fully initialized pending storage.
