/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include "reference.c"
extern int ptrace_wakeup_sig(int,long,long);
extern const unsigned long f03_wakeup_Rust_ABI[23];
extern int printf(const char *,...);
extern int dprintf(int,const char *,...);
extern void abort(void);
#define require(v) do{if(!(v)){dprintf(2,"FAIL wakeup line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
static struct cpu_local_var cpu;
static struct thread current,child;
static struct process tracer,tracee;
static struct sig_pending send,recv;
static int lookup_present,pending_mode,expected_pid,active_lock;
static long kill_result;
static unsigned long active_node;
struct observations {
 int order[32],count,finds,unlocks,clears,steps,locks,updates,lock_unwinds,takes,frees,kills,wakes;
 int logevent,logpid,logdata,trace_syscall,pending_source,freed_source,kill_pid,kill_tid,kill_sig,kill_cont,wake_states;
 int saved_valid,ptrace_state,sendsig_remaining,recvsig_remaining;
 struct siginfo info;
};
static struct observations seen;
static void note(int n){require(seen.count<32);seen.order[seen.count++]=n;}
struct cpu_local_var *get_this_cpu_local_var(void){note(1);return &cpu;}
static unsigned long ptrace_wakeup_find_thread_bridge(int tgid,int tid){note(3);seen.finds++;require(tgid==expected_pid&&tid==expected_pid);return lookup_present?(unsigned long)&child:0;}
static void ptrace_wakeup_thread_unlock_bridge(unsigned long t){note(13);seen.unlocks++;require(t==(unsigned long)&child&&!active_lock);}
static void ptrace_wakeup_log_bridge(int event,int pid,int data){note(2);seen.logevent=event;seen.logpid=pid;seen.logdata=data;}
static int ptrace_wakeup_clear_saved_bridge(unsigned long t,unsigned long off){note(4);seen.clears++;require(t==(unsigned long)&child&&off==__builtin_offsetof(struct thread,ptrace_saved_uctx_valid));child.ptrace_saved_uctx_valid=0;return 1;}
static void ptrace_wakeup_set_single_step_bridge(unsigned long t){note(5);seen.steps++;require(t==(unsigned long)&child);}
static void ptrace_wakeup_update_lock_bridge(unsigned long addr,void *node){note(6);seen.locks++;require(addr==(unsigned long)&tracee.update_lock&&!active_lock&&node);require(!((unsigned long)node%__alignof__(struct mcs_rwlock_node_irqsave)));active_lock=1;active_node=(unsigned long)node;*(unsigned long *)node=0x7a31;}
static int ptrace_wakeup_trace_syscall_bridge(unsigned long t,unsigned long off,int value){note(7);seen.updates++;require(t==(unsigned long)&child&&off==__builtin_offsetof(struct thread,ptrace)&&active_lock);seen.trace_syscall=value;child.ptrace=(child.ptrace&~PT_TRACE_SYSCALL)|(value?PT_TRACE_SYSCALL:0);return child.ptrace;}
static void ptrace_wakeup_update_unlock_bridge(unsigned long addr,void *node){note(8);seen.lock_unwinds++;require(addr==(unsigned long)&tracee.update_lock&&active_lock&&(unsigned long)node==active_node&&*(unsigned long *)node==0x7a31);active_lock=0;active_node=0;}
static unsigned long ptrace_wakeup_pending_take_bridge(unsigned long t,unsigned long so,unsigned long ro,int source){note(9);seen.takes++;require(t==(unsigned long)&child&&so==__builtin_offsetof(struct thread,ptrace_sendsig)&&ro==__builtin_offsetof(struct thread,ptrace_recvsig)&&!active_lock);seen.pending_source=source;struct sig_pending *result=NULL;if(source==1){result=child.ptrace_sendsig;child.ptrace_sendsig=NULL;}if(source==2){result=child.ptrace_recvsig;child.ptrace_recvsig=NULL;}return (unsigned long)result;}
static void ptrace_detach_kfree_bridge(void *pending){note(10);seen.frees++;require(pending==&send||pending==&recv);seen.freed_source=pending==&send?1:2;require((pending==&send&&!(child.ptrace_sendsig))||(pending==&recv&&!(child.ptrace_recvsig)));/* Static fully initialized fixture storage; record retirement only. */}
static long ptrace_detach_do_kill_bridge(void *t,int pid,int tid,int sig,const void *info,int cont){note(11);seen.kills++;require(t==&current&&pid==expected_pid&&tid==-1&&info&&!active_lock);seen.kill_pid=pid;seen.kill_tid=tid;seen.kill_sig=sig;seen.kill_cont=cont;memcpy(&seen.info,info,sizeof(seen.info));return kill_result;}
static void ptrace_detach_wakeup_bridge(void *t,int states){note(12);seen.wakes++;require(t==&child&&!active_lock);seen.wake_states=states;}
static void reset(int pid,int present,int pending,long result){
 memset(&seen,0,sizeof(seen));memset(&cpu,0,sizeof(cpu));memset(&current,0,sizeof(current));memset(&child,0,sizeof(child));memset(&tracer,0,sizeof(tracer));memset(&tracee,0,sizeof(tracee));
 /* Fully initialize EVERY byte before helper read; no copy-failure or allocator
  * publication claim is made by these controlled pending objects. */
 memset(&send,0x31,sizeof(send));memset(&recv,0x72,sizeof(recv));
 cpu.current=&current;current.proc=&tracer;tracer.pid=314;child.proc=&tracee;child.ptrace_saved_uctx_valid=1;child.ptrace=PT_TRACE_SYSCALL|0x400;
 expected_pid=pid;lookup_present=present;pending_mode=pending;kill_result=result;active_lock=0;active_node=0;
 child.ptrace_sendsig=(pending&1)?&send:NULL;child.ptrace_recvsig=(pending&2)?&recv:NULL;
}
static void snapshot(void){require(!active_lock&&!active_node);seen.saved_valid=child.ptrace_saved_uctx_valid;seen.ptrace_state=child.ptrace;seen.sendsig_remaining=child.ptrace_sendsig!=NULL;seen.recvsig_remaining=child.ptrace_recvsig!=NULL;}
static void independent(int rc,long request,long data){
 int valid=data>=0&&data<=64,resume=request==PTRACE_CONT||request==PTRACE_SINGLESTEP||request==PTRACE_SYSCALL,kill=request==PTRACE_KILL;
 int action=lookup_present&&valid&&(resume||kill),forward=action&&(kill||(data&&data!=SIGSTOP));
 int failed=forward&&(int)kill_result<0;
 require(rc==(!lookup_present?-ESRCH:!valid?-EINVAL:forward?(int)kill_result:0));
 require(seen.finds==1&&seen.unlocks==lookup_present&&seen.logevent==4&&seen.logpid==expected_pid&&seen.logdata==(int)data);
 require(seen.clears==action&&seen.steps==(action&&resume&&request==PTRACE_SINGLESTEP));
 require(seen.locks==(action&&resume)&&seen.updates==seen.locks&&seen.lock_unwinds==seen.locks);
 require(seen.kills==forward&&seen.wakes==(lookup_present&&valid&&!failed));
 require(seen.takes==(forward&&!kill));
 int source=request==PTRACE_CONT?(pending_mode&1?1:pending_mode&2?2:0):0;
 require(seen.frees==(forward&&!kill&&source!=0));
 require(seen.saved_valid==!action);
 if(action&&resume)require(seen.trace_syscall==(request==PTRACE_SYSCALL));
 if(seen.wakes)require(seen.wake_states==(PS_TRACED|PS_STOPPED));
 if(forward){
  require(seen.kill_cont==!kill&&seen.kill_sig==(kill?SIGKILL:(int)data));
  if(!kill&&source){const struct siginfo *expected=source==1?&send.info:&recv.info;require(!memcmp(&seen.info,expected,sizeof(seen.info)));require(seen.freed_source==source);}
  else {struct siginfo expected;memset(&expected,0,sizeof(expected));expected.si_signo=kill?SIGKILL:(int)data;if(!kill){expected.si_code=SI_USER;expected._sifields._kill.si_pid=314;}require(!memcmp(&seen.info,&expected,sizeof(expected)));}
 }
 require(seen.order[0]==1&&seen.order[1]==2&&seen.order[2]==3);
 for(int i=1;i<seen.count;i++)require(seen.order[i]>seen.order[i-1]);
}
int main(void){
 require(!memcmp(f03_wakeup_C_ABI,f03_wakeup_Rust_ABI,sizeof(f03_wakeup_C_ABI)));
 const long requests[]={PTRACE_CONT,PTRACE_KILL,PTRACE_SINGLESTEP,PTRACE_SYSCALL,0,0x7fffffffffffffffL};
 const long signals[]={-1,0,1,SIGSTOP,64,65,0x100000001L};
 const long results[]={0,17,-7,0x100000001L};const int pids[]={0,17,(-2147483647-1)};unsigned tested=0;
 for(unsigned r=0;r<6;r++)for(unsigned s=0;s<7;s++)for(int present=0;present<2;present++)for(int pending=0;pending<4;pending++)for(unsigned f=0;f<4;f++)for(unsigned p=0;p<3;p++){
  reset(pids[p],present,pending,results[f]);int old=original_ptrace_wakeup_sig(pids[p],requests[r],signals[s]);snapshot();independent(old,requests[r],signals[s]);struct observations baseline=seen;
  reset(pids[p],present,pending,results[f]);int new=ptrace_wakeup_sig(pids[p],requests[r],signals[s]);snapshot();independent(new,requests[r],signals[s]);require(old==new&&!memcmp(&baseline,&seen,sizeof(seen)));tested++;
 }
 require(tested==4032);printf("PASS ptrace wakeup outer genuine-C/Rust cases4032 ABI23 providers12 initialized-pending-only ownership/order/node-lifetime\n");return 0;
}
