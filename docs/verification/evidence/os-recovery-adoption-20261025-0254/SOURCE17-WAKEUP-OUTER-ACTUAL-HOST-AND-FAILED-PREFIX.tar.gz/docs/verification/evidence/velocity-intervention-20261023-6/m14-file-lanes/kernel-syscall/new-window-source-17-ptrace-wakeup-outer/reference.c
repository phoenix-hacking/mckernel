/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <ihk/debug.h>
#include <stdarg.h>
typedef int (*ptrace_traceme_fn_t)(void);
#include <string.h>
typedef unsigned long (*ptrace_find_thread_fn_t)(int tgid, int tid);
typedef void (*ptrace_thread_unlock_fn_t)(unsigned long thread_addr);
typedef void (*ptrace_control_log_fn_t)(int event, int value, int result);
typedef int (*ptrace_saved_context_clear_fn_t)(unsigned long thread_addr,
		unsigned long offset);
typedef void (*ptrace_set_single_step_fn_t)(unsigned long thread_addr);
typedef void (*ptrace_rwlock_fn_t)(unsigned long lock_addr, void *node);
typedef int (*ptrace_trace_syscall_update_fn_t)(unsigned long thread_addr,
		unsigned long ptrace_offset, int trace_syscall);
typedef unsigned long (*ptrace_pending_signal_take_fn_t)(
		unsigned long thread_addr, unsigned long sendsig_offset,
		unsigned long recvsig_offset, int source);
typedef void (*ptrace_free_fn_t)(void *ptr);
typedef long (*ptrace_do_kill_thread_fn_t)(void *current_thread,
		int pid, int tid, int sig, const void *info, int ptracecont);
typedef void (*ptrace_wakeup_thread_fn_t)(void *thread, int valid_states);
struct ptrace_io_offsets {
	size_t thread_proc_offset;
	size_t thread_status_offset;
	size_t thread_vm_offset;
	size_t thread_ptrace_offset;
	size_t thread_ptrace_eventmsg_offset;
	size_t thread_ptrace_recvsig_offset;
	size_t thread_ptrace_sendsig_offset;
	size_t thread_report_proc_offset;
	size_t thread_ptrace_saved_uctx_valid_offset;
	size_t proc_pid_offset;
	size_t proc_update_lock_offset;
};
extern int ptrace_wakeup_sig_body_result(int pid, long request, long data,
		unsigned long current_thread, unsigned long info_offset,
		const struct ptrace_io_offsets *offsets, void *lock_node,
		ptrace_find_thread_fn_t find_fn,
		ptrace_thread_unlock_fn_t unlock_fn,
		ptrace_control_log_fn_t log_fn,
		ptrace_saved_context_clear_fn_t clear_saved_fn,
		ptrace_set_single_step_fn_t set_single_step_fn,
		ptrace_rwlock_fn_t lock_fn,
		ptrace_trace_syscall_update_fn_t trace_syscall_update_fn,
		ptrace_rwlock_fn_t unlock_lock_fn,
		ptrace_pending_signal_take_fn_t take_pending_fn,
		ptrace_free_fn_t free_fn,
		ptrace_do_kill_thread_fn_t do_kill_fn,
		ptrace_wakeup_thread_fn_t wakeup_fn);
static unsigned long ptrace_wakeup_find_thread_bridge(int,int);
static void ptrace_wakeup_thread_unlock_bridge(unsigned long);
static void ptrace_wakeup_log_bridge(int,int,int);
static int ptrace_wakeup_clear_saved_bridge(unsigned long,unsigned long);
static void ptrace_wakeup_set_single_step_bridge(unsigned long);
static void ptrace_wakeup_update_lock_bridge(unsigned long,void *);
static int ptrace_wakeup_trace_syscall_bridge(unsigned long,unsigned long,int);
static void ptrace_wakeup_update_unlock_bridge(unsigned long,void *);
static unsigned long ptrace_wakeup_pending_take_bridge(unsigned long,unsigned long,unsigned long,int);
static void ptrace_detach_kfree_bridge(void *);
static long ptrace_detach_do_kill_bridge(void *,int,int,int,const void *,int);
static void ptrace_detach_wakeup_bridge(void *,int);
static const struct ptrace_io_offsets ptrace_wakeup_io_offsets = {
	.thread_proc_offset = __builtin_offsetof(struct thread, proc),
	.thread_status_offset = __builtin_offsetof(struct thread, status),
	.thread_vm_offset = __builtin_offsetof(struct thread, vm),
	.thread_ptrace_offset = __builtin_offsetof(struct thread, ptrace),
	.thread_ptrace_eventmsg_offset =
		__builtin_offsetof(struct thread, ptrace_eventmsg),
	.thread_ptrace_recvsig_offset =
		__builtin_offsetof(struct thread, ptrace_recvsig),
	.thread_ptrace_sendsig_offset =
		__builtin_offsetof(struct thread, ptrace_sendsig),
	.thread_report_proc_offset =
		__builtin_offsetof(struct thread, report_proc),
	.thread_ptrace_saved_uctx_valid_offset =
		__builtin_offsetof(struct thread, ptrace_saved_uctx_valid),
	.proc_pid_offset = __builtin_offsetof(struct process, pid),
	.proc_update_lock_offset =
		__builtin_offsetof(struct process, update_lock),
};
/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
struct f03_ptrace_wakeup_ops_v1 {
    ptrace_find_thread_fn_t find_fn;
    ptrace_thread_unlock_fn_t unlock_fn;
    ptrace_control_log_fn_t log_fn;
    ptrace_saved_context_clear_fn_t clear_saved_fn;
    ptrace_set_single_step_fn_t set_single_step_fn;
    ptrace_rwlock_fn_t lock_fn;
    ptrace_trace_syscall_update_fn_t trace_syscall_update_fn;
    ptrace_rwlock_fn_t unlock_lock_fn;
    ptrace_pending_signal_take_fn_t take_pending_fn;
    ptrace_free_fn_t free_fn;
    ptrace_do_kill_thread_fn_t do_kill_fn;
    ptrace_wakeup_thread_fn_t wakeup_fn;
 };
const struct ptrace_io_offsets f03_ptrace_wakeup_offsets_v1 = {
	.thread_proc_offset = __builtin_offsetof(struct thread, proc),
	.thread_status_offset = __builtin_offsetof(struct thread, status),
	.thread_vm_offset = __builtin_offsetof(struct thread, vm),
	.thread_ptrace_offset = __builtin_offsetof(struct thread, ptrace),
	.thread_ptrace_eventmsg_offset =
		__builtin_offsetof(struct thread, ptrace_eventmsg),
	.thread_ptrace_recvsig_offset =
		__builtin_offsetof(struct thread, ptrace_recvsig),
	.thread_ptrace_sendsig_offset =
		__builtin_offsetof(struct thread, ptrace_sendsig),
	.thread_report_proc_offset =
		__builtin_offsetof(struct thread, report_proc),
	.thread_ptrace_saved_uctx_valid_offset =
		__builtin_offsetof(struct thread, ptrace_saved_uctx_valid),
	.proc_pid_offset = __builtin_offsetof(struct process, pid),
	.proc_update_lock_offset =
		__builtin_offsetof(struct process, update_lock),
};
const unsigned long f03_ptrace_wakeup_info_offset_v1=__builtin_offsetof(struct sig_pending,info);
const struct f03_ptrace_wakeup_ops_v1 f03_ptrace_wakeup_ops_v1={
    .find_fn=ptrace_wakeup_find_thread_bridge,
    .unlock_fn=ptrace_wakeup_thread_unlock_bridge,
    .log_fn=ptrace_wakeup_log_bridge,
    .clear_saved_fn=ptrace_wakeup_clear_saved_bridge,
    .set_single_step_fn=ptrace_wakeup_set_single_step_bridge,
    .lock_fn=ptrace_wakeup_update_lock_bridge,
    .trace_syscall_update_fn=ptrace_wakeup_trace_syscall_bridge,
    .unlock_lock_fn=ptrace_wakeup_update_unlock_bridge,
    .take_pending_fn=ptrace_wakeup_pending_take_bridge,
    .free_fn=ptrace_detach_kfree_bridge,
    .do_kill_fn=ptrace_detach_do_kill_bridge,
    .wakeup_fn=ptrace_detach_wakeup_bridge,
};

static int original_ptrace_wakeup_sig(int pid,long request,long data) {
	struct thread *thread = get_this_cpu_local_var()->current;
	struct mcs_rwlock_node_irqsave lock;

	return ptrace_wakeup_sig_body_result(pid, request, data,
			(unsigned long)thread,
			__builtin_offsetof(struct sig_pending, info),
			&ptrace_wakeup_io_offsets, &lock,
			ptrace_wakeup_find_thread_bridge,
			ptrace_wakeup_thread_unlock_bridge,
			ptrace_wakeup_log_bridge,
			ptrace_wakeup_clear_saved_bridge,
			ptrace_wakeup_set_single_step_bridge,
			ptrace_wakeup_update_lock_bridge,
			ptrace_wakeup_trace_syscall_bridge,
			ptrace_wakeup_update_unlock_bridge,
			ptrace_wakeup_pending_take_bridge,
			ptrace_detach_kfree_bridge,
			ptrace_detach_do_kill_bridge,
			ptrace_detach_wakeup_bridge);
}
const unsigned long f03_wakeup_C_ABI[23]={sizeof(struct mcs_rwlock_node_irqsave),__alignof__(struct mcs_rwlock_node_irqsave),sizeof(struct cpu_local_var),__alignof__(struct cpu_local_var),__builtin_offsetof(struct cpu_local_var,current),sizeof(struct ptrace_io_offsets),__alignof__(struct ptrace_io_offsets),sizeof(struct f03_ptrace_wakeup_ops_v1),__alignof__(struct f03_ptrace_wakeup_ops_v1),sizeof(struct siginfo),__alignof__(struct siginfo),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,find_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,unlock_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,log_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,clear_saved_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,set_single_step_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,lock_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,trace_syscall_update_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,unlock_lock_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,take_pending_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,free_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,do_kill_fn),__builtin_offsetof(struct f03_ptrace_wakeup_ops_v1,wakeup_fn)};
