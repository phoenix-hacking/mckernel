//! Immutable expected statuses for the private finite inventory fixture.
//! This file owns no descriptor construction and imports no production code.
#[derive(Clone, Copy)]
pub struct Vector { pub name: &'static str, pub expected: i32 }

pub const VECTORS: &[Vector] = &[
    Vector { name: "empty", expected: -22 },
    Vector { name: "capacity-zero", expected: -28 },
    Vector { name: "capacity-exact", expected: 0 },
    Vector { name: "capacity-exceeded", expected: -28 },
    Vector { name: "count-mismatch", expected: -22 },
    Vector { name: "count-overflow", expected: -75 },
    Vector { name: "duplicate-id", expected: -22 },
    Vector { name: "foreign-id", expected: -22 },
    Vector { name: "null-link", expected: -22 },
    Vector { name: "dangling-link", expected: -22 },
    Vector { name: "one-sided-link", expected: -22 },
    Vector { name: "malformed-sentinel", expected: -22 },
    Vector { name: "foreign-cycle", expected: -22 },
    Vector { name: "wrong-mode", expected: -22 },
    Vector { name: "invalid-page-count", expected: -22 },
    Vector { name: "page-count-overflow", expected: -75 },
    Vector { name: "misaligned-extent", expected: -22 },
    Vector { name: "foreign-extent", expected: -22 },
    Vector { name: "overlapping-extent", expected: -22 },
    Vector { name: "stale-generation", expected: -22 },
    Vector { name: "concurrent-mutation", expected: -22 },
    Vector { name: "valid-single", expected: 0 },
    Vector { name: "valid-two", expected: 0 },
];

pub fn case(name: &str) -> Option<Vector> {
    VECTORS.iter().copied().find(|vector| vector.name == name)
}
