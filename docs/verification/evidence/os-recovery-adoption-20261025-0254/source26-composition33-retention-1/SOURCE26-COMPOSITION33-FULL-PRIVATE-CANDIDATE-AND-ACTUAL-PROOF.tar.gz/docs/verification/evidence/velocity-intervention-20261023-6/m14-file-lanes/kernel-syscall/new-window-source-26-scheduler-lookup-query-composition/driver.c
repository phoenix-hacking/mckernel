/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
extern int printf(const char *,...);extern int dprintf(int,const char *,...);extern void abort(void);
extern int posix_memalign(void **,size_t,size_t);extern void free(void *);
#define require(v) do{if(!(v)){dprintf(2,"FAIL lookup query composition line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
struct sched_syscall_offsets {
 size_t thread_proc_offset,thread_sched_param_offset,thread_sched_policy_offset,thread_cpu_id_offset,thread_cpu_set_offset;
 size_t proc_pid_offset,proc_ruid_offset,proc_euid_offset,proc_cpu_set_offset;
};
typedef unsigned long (*sched_find_thread_fn_t)(int);
typedef void (*sched_thread_unlock_fn_t)(unsigned long);
typedef long (*syscall_copy_to_user_fn_t)(unsigned long,const void *,size_t);
#include <process_helpers.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-22-positive-reference-lookup-repair/VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
extern struct thread *f02_public_find_thread_candidate_v2(int,int);
extern long sched_getparam_retained_v2(int,unsigned long,unsigned long,size_t,const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t,syscall_copy_to_user_fn_t);
extern long sched_getscheduler_retained_v2(int,unsigned long,const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t);
extern long sched_rr_get_interval_retained_v2(int,unsigned long,unsigned long,const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t,syscall_copy_to_user_fn_t);
extern const unsigned long f02_lookup_Rust_ABI[12],f03_sched_query_Rust_ABI[18],f03_rr_query_Rust_ABI[18];
typedef struct thread *(*public_find_v2_fn_t)(int,int);
_Static_assert(__builtin_types_compatible_p(__typeof__(&f02_public_find_thread_candidate_v2),public_find_v2_fn_t),"public lookup keeps genuine Thread pointer ABI");
_Static_assert(sizeof(long)==8,"actual usercopy full-width long ABI");

static const struct sched_syscall_offsets offsets={__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,cpu_id),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct process,pid),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),__builtin_offsetof(struct process,cpu_set)};
enum query_kind { QUERY_PARAM,QUERY_POLICY,QUERY_RR };
enum composition_case {
 CASE_FOREIGN,CASE_EXIT_AFTER_LOOKUP,CASE_EXIT_IN_QUERY,CASE_INITIAL_ZERO,
 CASE_WARNING_LAST_OWNER,CASE_CURRENT_ZERO,CASE_CURRENT_PID,CASE_NOT_FOUND,
 CASE_NEGATIVE_PID,CASE_NULL_OUTPUT,CASE_LONG_COPY_FAULT,CASE_MISSING_COPY
};
static struct thread self;
static struct process self_process,target_process;
static struct thread *target;
static struct thread_hash thread_hash_state;
static struct resource_set resources;
static struct cpu_local_var cpu;
static int reader_held,reader_locks,reader_unlocks,lookup_calls,query_releases,copy_calls,warnings;
static int owner_edge,query_edge,published,allocations,destructions,case_number,current_query,requested_pid;
static unsigned long node_identity;
static struct sched_param parameter_output;
static struct timespec interval_output;
static int target_count(void){require(target);return __atomic_load_n(&target->refcount.counter,__ATOMIC_SEQ_CST);}
static struct list_head *target_head(void){return &thread_hash_state.list[101%HASH_SIZE];}
static void unlink_target(void){
 require(target&&published&&!reader_held);
 struct list_head *head=target_head();require(head->next==&target->hash_list&&head->prev==&target->hash_list);
 head->next=head->prev=head;target->hash_list.next=target->hash_list.prev=NULL;published=0;
}
static void reap_target_if_zero(void){
 if(!target||target_count()!=0)return;
 require(!reader_held&&!owner_edge&&!query_edge);
 if(published)unlink_target();
 __builtin_memset(target,0xdd,sizeof(*target));free(target);target=NULL;destructions++;
}
static void exit_hash_owner(void){
 require(target&&owner_edge&&target_count()>0);owner_edge=0;
 int remaining=__atomic_sub_fetch(&target->refcount.counter,1,__ATOMIC_SEQ_CST);require(remaining>=0);
 /* Reader pins allocation/process storage at final zero. Writer retirement must
  * wait for its release; no zero-count object is freed during a lookup read. */
 if(!reader_held){if(published)unlink_target();reap_target_if_zero();}
}
struct cpu_local_var *get_this_cpu_local_var(void){return &cpu;}
void process_mcs_reader_lock_bridge(unsigned long address,void *node){
 require(address==(unsigned long)&thread_hash_state.lock[requested_pid%HASH_SIZE]&&!reader_held&&node);
 require(!((unsigned long)node%__alignof__(struct mcs_rwlock_node_irqsave)));reader_held=1;reader_locks++;node_identity=(unsigned long)node;*(unsigned long *)node=0x4a77;
}
void process_mcs_reader_unlock_bridge(unsigned long address,void *node){
 require(address==(unsigned long)&thread_hash_state.lock[requested_pid%HASH_SIZE]&&reader_held&&(unsigned long)node==node_identity&&*(unsigned long *)node==0x4a77);
 reader_held=0;reader_unlocks++;node_identity=0;
 if(case_number==CASE_EXIT_AFTER_LOOKUP&&owner_edge)exit_hash_owner();
 reap_target_if_zero();
}
void process_hold_thread_warn_bridge(void *address){
 require(target&&address==target&&reader_held&&target->status==PS_EXITED);warnings++;
 require(case_number==CASE_WARNING_LAST_OWNER);exit_hash_owner();
}
/* Same genuine scheduler bridge ABI: direct pointer-returning find(0,pid) call,
 * then pointer-to-unsigned-long value conversion. No callback pointer cast. */
static unsigned long scheduler_find(int pid){
 require(pid==requested_pid&&!reader_held&&!query_edge);lookup_calls++;
 struct thread *found=f02_public_find_thread_candidate_v2(0,pid);
 require(!reader_held);
 if(found){require(found==target&&target_count()==1+owner_edge);query_edge=1;}
 return (unsigned long)found;
}
static sched_find_thread_fn_t const actual_scheduler_find_signature=scheduler_find;
static void scheduler_unlock(unsigned long address){
 require(target&&(unsigned long)target==address&&query_edge&&!reader_held&&target_count()>0);query_releases++;
 if(case_number==CASE_EXIT_IN_QUERY&&current_query==QUERY_POLICY)exit_hash_owner();
 query_edge=0;int remaining=__atomic_sub_fetch(&target->refcount.counter,1,__ATOMIC_SEQ_CST);require(remaining==owner_edge);reap_target_if_zero();
}
static long generic_user_copy(unsigned long destination,const void *source,size_t bytes){
 require(current_query!=QUERY_POLICY&&!reader_held&&source);copy_calls++;
 int foreign=requested_pid!=0&&requested_pid!=17;
 if(foreign){
  require(target&&query_edge&&target_count()==1+owner_edge);
  if(case_number==CASE_EXIT_IN_QUERY)exit_hash_owner();
  require(target&&query_edge&&target_count()>=1);
 }
 if(current_query==QUERY_PARAM){
  require(bytes==sizeof(parameter_output)&&source==(foreign?(void *)&target->sched_param:(void *)&self.sched_param));
  require(((const struct sched_param *)source)->sched_priority==(foreign?991:77));
 }else{
  struct timespec expected={.tv_sec=0,.tv_nsec=foreign?10000:0};require(bytes==sizeof(expected)&&!memcmp(source,&expected,sizeof(expected)));
 }
 if(!destination)return -EFAULT;
 if(case_number==CASE_LONG_COPY_FAULT)return 4294967296L;
 memcpy((void *)destination,source,bytes);return 0;
}
static void initialize_case(int query,int test_case){
 require(!target&&!owner_edge&&!query_edge&&!published&&!reader_held);
 __builtin_memset(&self,0,sizeof(self));__builtin_memset(&self_process,0,sizeof(self_process));__builtin_memset(&target_process,0,sizeof(target_process));
 __builtin_memset(&thread_hash_state,0,sizeof(thread_hash_state));__builtin_memset(&resources,0,sizeof(resources));__builtin_memset(&cpu,0,sizeof(cpu));
 current_query=query;case_number=test_case;requested_pid=test_case==CASE_CURRENT_ZERO?0:test_case==CASE_CURRENT_PID?17:test_case==CASE_NOT_FOUND?999:test_case==CASE_NEGATIVE_PID?-1:101;
 self.proc=&self_process;self_process.pid=17;self.refcount.counter=1;self.sched_param.sched_priority=77;self.sched_policy=0;
 cpu.current=&self;cpu.resource_set=&resources;resources.thread_hash=&thread_hash_state;
 lookup_calls=query_releases=copy_calls=reader_locks=reader_unlocks=warnings=allocations=destructions=0;node_identity=0;
 parameter_output.sched_priority=-123;interval_output.tv_sec=-111;interval_output.tv_nsec=-222;
 struct list_head *head=target_head();head->next=head->prev=head;
 struct list_head *missing=&thread_hash_state.list[999%HASH_SIZE];missing->next=missing->prev=missing;
 if(test_case!=CASE_CURRENT_ZERO&&test_case!=CASE_CURRENT_PID&&test_case!=CASE_NEGATIVE_PID){
  void *allocation=NULL;size_t alignment=__alignof__(struct thread);if(alignment<sizeof(void *))alignment=sizeof(void *);
  require(posix_memalign(&allocation,alignment,sizeof(*target))==0&&allocation);target=allocation;__builtin_memset(target,0,sizeof(*target));allocations++;
  target->tid=101;target->proc=&target_process;target_process.pid=100;target->refcount.counter=test_case==CASE_INITIAL_ZERO?0:1;
  target->status=test_case==CASE_WARNING_LAST_OWNER?PS_EXITED:PS_TRACED;target->sched_param.sched_priority=991;target->sched_policy=2;
  head->next=head->prev=&target->hash_list;target->hash_list.next=target->hash_list.prev=head;published=1;owner_edge=test_case!=CASE_INITIAL_ZERO;
 }
}
static long expected_result(void){
 if(case_number==CASE_NEGATIVE_PID||case_number==CASE_MISSING_COPY||(case_number==CASE_NULL_OUTPUT&&current_query==QUERY_PARAM))return -EINVAL;
 if(case_number==CASE_INITIAL_ZERO||case_number==CASE_WARNING_LAST_OWNER||case_number==CASE_NOT_FOUND)return -ESRCH;
 if(case_number==CASE_NULL_OUTPUT||case_number==CASE_LONG_COPY_FAULT)return -EFAULT;
 if(current_query==QUERY_POLICY)return requested_pid==0||requested_pid==17?0:2;
 return 0;
}
static void check_composition(long result){
 require(result==expected_result());
 int current=case_number==CASE_CURRENT_ZERO||case_number==CASE_CURRENT_PID;
 int invalid=case_number==CASE_NEGATIVE_PID||case_number==CASE_MISSING_COPY||(case_number==CASE_NULL_OUTPUT&&current_query==QUERY_PARAM);
 int looked=!current&&!invalid;
 int acquired=looked&&case_number!=CASE_INITIAL_ZERO&&case_number!=CASE_WARNING_LAST_OWNER&&case_number!=CASE_NOT_FOUND;
 require(lookup_calls==looked&&reader_locks==looked&&reader_unlocks==looked&&!reader_held&&!node_identity);
 require(query_releases==acquired&&!query_edge);
 require(copy_calls==(current_query!=QUERY_POLICY&&!invalid&&(current||acquired)));
 require(warnings==(case_number==CASE_WARNING_LAST_OWNER));
 if(result==0&&current_query==QUERY_PARAM)require(parameter_output.sched_priority==(current?77:991));
 if(result==0&&current_query==QUERY_RR)require(interval_output.tv_sec==0&&interval_output.tv_nsec==(current?0:10000));
 require(self.refcount.counter==1);
 if(target&&owner_edge)exit_hash_owner();else reap_target_if_zero();
 require(!target&&!owner_edge&&!query_edge&&!published&&allocations==destructions);
}
static void geometry(void){
 const unsigned long lookup12[12]={sizeof(struct process_find_thread_offsets),__alignof__(struct process_find_thread_offsets),__builtin_offsetof(struct process_find_thread_offsets,thread_hash_list_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_tid_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_proc_offset),__builtin_offsetof(struct process_find_thread_offsets,proc_pid_offset),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),__builtin_offsetof(struct thread,refcount),sizeof(int),sizeof(process_thread_try_hold_fn_v2),sizeof(struct mcs_rwlock_node_irqsave)};
 const unsigned long query18[18]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),sizeof(struct process),__alignof__(struct process),__builtin_offsetof(struct process,pid),sizeof(struct sched_param),__alignof__(struct sched_param),__builtin_offsetof(struct sched_param,sched_priority),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(syscall_copy_to_user_fn_t),sizeof(long),__alignof__(long)};
 const unsigned long rr18[18]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_policy),sizeof(struct process),__alignof__(struct process),__builtin_offsetof(struct process,pid),sizeof(struct timespec),__alignof__(struct timespec),__builtin_offsetof(struct timespec,tv_sec),__builtin_offsetof(struct timespec,tv_nsec),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(syscall_copy_to_user_fn_t),sizeof(long),__alignof__(long)};
 require(!memcmp(lookup12,f02_lookup_Rust_ABI,sizeof(lookup12))&&!memcmp(query18,f03_sched_query_Rust_ABI,sizeof(query18))&&!memcmp(rr18,f03_rr_query_Rust_ABI,sizeof(rr18)));
}
int main(void){
 geometry();unsigned calls=0;
 for(int query=QUERY_PARAM;query<=QUERY_RR;query++)for(int test_case=CASE_FOREIGN;test_case<=CASE_MISSING_COPY;test_case++){
  if(query==QUERY_POLICY&&test_case>CASE_NEGATIVE_PID)continue;
  initialize_case(query,test_case);unsigned long destination=test_case==CASE_NULL_OUTPUT?0:query==QUERY_PARAM?(unsigned long)&parameter_output:(unsigned long)&interval_output;
  syscall_copy_to_user_fn_t copy=test_case==CASE_MISSING_COPY?NULL:generic_user_copy;
  long result=query==QUERY_PARAM?sched_getparam_retained_v2(requested_pid,destination,(unsigned long)&self,sizeof(parameter_output),&offsets,actual_scheduler_find_signature,scheduler_unlock,copy):query==QUERY_POLICY?sched_getscheduler_retained_v2(requested_pid,(unsigned long)&self,&offsets,actual_scheduler_find_signature,scheduler_unlock):sched_rr_get_interval_retained_v2(requested_pid,destination,(unsigned long)&self,&offsets,actual_scheduler_find_signature,scheduler_unlock,copy);
  check_composition(result);calls++;
 }
 require(calls==33);printf("PASS scheduler lookup/query composition calls33 ABI48 retained-objects3 positive-CAS/zero-reject/owner-exit/copy-exit/current-pid0/error-order/edge-free-balance controlled-only\n");return 0;
}
