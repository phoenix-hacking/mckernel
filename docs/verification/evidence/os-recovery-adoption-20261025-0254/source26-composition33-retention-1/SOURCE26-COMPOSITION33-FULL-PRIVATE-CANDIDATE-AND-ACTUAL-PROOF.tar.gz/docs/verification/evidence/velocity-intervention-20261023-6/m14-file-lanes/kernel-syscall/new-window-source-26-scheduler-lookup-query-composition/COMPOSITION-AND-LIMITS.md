Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This is a new fixture-only composition of three exact accepted Rust objects:
Source22 positive lookup fbd48780, Source23 getter queries a42df0cf, and Source25 RR
dfdc8f2a. No Rust source, accepted provider body or object is changed/recompiled.
Source21 and Source24 objects are not linked or required by this fixture. No
standalone42/4320/6480 or earlier411/60 vectors are replayed.

The genuine scheduler find callback has unsigned-long(int) ABI; the accepted
Source22 public lookup has Thread*(int,int) ABI. The C fixture uses the existing
sched_find_thread_bridge pattern: direct call to the public lookup with(0,pid),
then pointer-to-unsigned-long VALUE conversion. It never casts function pointers,
wraps an old void hold as success, fabricates Thread layout or changes usercopy
width. Source22's actual atomic positive acquisition executes against the genuine
Thread refcount and reader-protected real hash membership. Source23/25 query
objects receive the same acquired edge and release it through their real guard.

The controlled HOST lifecycle adapters expose actual C Thread/Process/hash/CPU/
resource_set geometry and allocator-backed aligned Thread storage. Reader adapters
pin published allocation/process storage at final zero until writer retirement.
A hash-owner exit clears membership only outside the reader; allocation frees only
after no positive edges remain and membership is detached. The query release
adapter consumes exactly its own positive edge with matching SeqCst atomic count
updates. No free or field access occurs through an unowned pointer. These adapters
are finite HOST providers, not production scheduler/destructor or IRQ acceptance.

Exactly33 calls cover12 getparam,9 getscheduler and12 RR compositions. They target
new integration boundaries: ordinary foreign acquisition; initial owner exit after
CAS but before query; exit during copy (or before scalar query release); a final-zero
published node rejected by Source22 and retired after reader release; last owner
dropped by the actual warning callback before CAS; current/pid0 with no extra edge;
missing/negative target; getter-versus-RR null-output precedence; full-width +2^32
copy error; missing copy provider. Current/self reference count remains unchanged.
Independent oracles check exact lookup/query-release/copy counts, no resurrection,
warning count, reader balance, initialized parameter/TimeSpec/scalar bytes, errno,
last-edge destruction and actual aligned allocation/free balance. No actual freed
memory or old unsafe getter is read as a counterexample.

Before composition runs, C validates48 genuine ABI words from the retained objects:
Source22's12, Source23's18 and Source25's18. The accepted Source22 source-bound
full lookup20-word geometry proof remains a reused prerequisite; its reference
object is not linked/reexecuted. The new descriptor retains exact tool/header/
source/acceptance pins plus full stat/hash identities of all three object files.

True production requirements remain: reviewed source selection must connect the
positive-reference lookup successor and all caller repairs in the actual current
fullcrate/entry/link set, preserve matching hold/release and final hash-writer
retirement, review actual allocator/process/sigcommon lifetime and concurrently
written scheduler fields, then qualify native process-exit/fault/resource behavior.
This HOST composition supplies no multicore/IRQ/default/native or C-retirement
credit. No canonical edits or hidden Source24 dependency are introduced.

Next exact check is only two commands: genuine C link with the three retained
objects, then33-call/ABI48 composition regression. No compiler or execution is
performed while preparing this packet. It needs actual ROOT admission after its
priority archival operation, explicit CPU0 taskset/source-FD envelope and unchanged
h990/AS2G/sharedCPU60/wall90+6/F32/FD256/stack2M/core0/floors. The first failure
must remain retained; no unchanged deterministic replay is authorized.
