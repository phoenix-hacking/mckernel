// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// HOST fixture: actual Rust ticket/MCS locks, retained Source22 code, platform stubs.
#![allow(dead_code)]

use core::ffi::c_void;
use core::mem::{offset_of, MaybeUninit};
use core::ptr::{addr_of_mut, null_mut};
use core::sync::atomic::{AtomicI32, Ordering};
use std::cell::{Cell, RefCell};
use std::sync::mpsc::{self, Sender};
use std::time::Duration;

#[path = "genuine/abi.rs"]
mod abi;
#[path = "genuine/lock_helpers.rs"]
mod lock_helpers;
#[path = "genuine/spinlock_helpers.rs"]
mod spinlock_helpers;
#[path = "thread_hash_detach_v3.rs"]
mod thread_hash_detach_v3;

use abi::{AbiListHead, CInt, CULong, CpuLocalVar, Process, Thread, ThreadHash, PROCESS_HASH_SIZE};
use lock_helpers::McsRwlockNodeIrqsave;

type ProcessMcsRwlockFn = unsafe extern "C" fn(CULong, *mut c_void);
type TryHoldFn = unsafe extern "C" fn(*mut c_void) -> CInt;

#[repr(C)]
struct ProcessFindThreadOffsets {
    thread_hash_list_offset: CULong,
    thread_tid_offset: CULong,
    thread_proc_offset: CULong,
    proc_pid_offset: CULong,
}

extern "C" {
    fn process_try_hold_thread_live_v2(thread: *mut c_void) -> CInt;
    fn process_find_thread_live_body_result_v2(
        head: *mut AbiListHead,
        hash_lock: CULong,
        node: *mut c_void,
        pid: CInt,
        tid: CInt,
        offsets: *const ProcessFindThreadOffsets,
        lock: Option<ProcessMcsRwlockFn>,
        unlock: Option<ProcessMcsRwlockFn>,
        hold: Option<TryHoldFn>,
    ) -> *mut c_void;
}

const HASH_SIZE: CInt = PROCESS_HASH_SIZE as CInt;

pub extern "C" fn thread_hash(tid: CInt) -> CInt {
    tid % HASH_SIZE
}

include!("genuine/process_bodies.rs.inc");

thread_local! {
    static IRQ_ENABLED: Cell<bool> = const { Cell::new(true) };
    static PREEMPT_DEPTH: Cell<usize> = const { Cell::new(0) };
    static WARNINGS: Cell<usize> = const { Cell::new(0) };
    static WARNING_HOOK: RefCell<Option<Box<dyn FnMut()>>> = RefCell::new(None);
    static PAUSE_NOTICE: RefCell<Option<Sender<()>>> = const { RefCell::new(None) };
}

#[no_mangle]
extern "C" fn preempt_disable() {
    PREEMPT_DEPTH.set(PREEMPT_DEPTH.get() + 1);
}

#[no_mangle]
extern "C" fn preempt_enable() {
    PREEMPT_DEPTH.set(PREEMPT_DEPTH.get().checked_sub(1).expect("balanced preemption"));
}

#[no_mangle]
extern "C" fn cpu_disable_interrupt_save() -> CULong {
    if IRQ_ENABLED.replace(false) { 0x200 } else { 0 }
}

#[no_mangle]
extern "C" fn cpu_restore_interrupt(flags: CULong) {
    IRQ_ENABLED.set(flags & 0x200 != 0);
}

#[no_mangle]
extern "C" fn cpu_pause() {
    PAUSE_NOTICE.with_borrow_mut(|notice| {
        if let Some(sender) = notice.take() {
            sender.send(()).expect("reader awaits actual ticket contention");
        }
    });
    std::thread::yield_now();
}

#[no_mangle]
extern "C" fn get_this_cpu_local_var() -> *mut CpuLocalVar {
    // Retained public wrapper is linked, but these tests explicitly supply a real
    // typed bucket to its unchanged inner body rather than emulating a guest CPU.
    null_mut()
}

#[no_mangle]
extern "C" fn process_hold_thread_warn_bridge(_thread: *mut c_void) {
    assert!(!IRQ_ENABLED.get());
    assert_eq!(PREEMPT_DEPTH.get(), 1);
    WARNINGS.set(WARNINGS.get() + 1);
    WARNING_HOOK.with_borrow_mut(|hook| {
        if let Some(hook) = hook.as_mut() {
            hook();
        }
    });
}

struct Fixture {
    hash: Box<ThreadHash>,
    process: Box<Process>,
    target: *mut Thread,
}

impl Fixture {
    fn new(pid: CInt, tid: CInt, count: CInt) -> Self {
        // SAFETY: These C ABI aggregates contain only zero-valid integers, raw
        // pointers and nullable callbacks. Lists and locks are initialized below.
        let mut hash: Box<ThreadHash> = Box::new(unsafe { core::mem::zeroed() });
        let mut process: Box<Process> = Box::new(unsafe { core::mem::zeroed() });
        let mut target: Box<Thread> = Box::new(unsafe { core::mem::zeroed() });
        for bucket in 0..PROCESS_HASH_SIZE {
            let head = addr_of_mut!(hash.list[bucket]);
            // SAFETY: Box allocation is stable; every bucket gets its own genuine
            // initialized head/lock. No reference or pointer escapes this setup.
            unsafe {
                (*head).next = head;
                (*head).prev = head;
                lock_helpers::mcs_rwlock_init(
                    addr_of_mut!(hash.lock[bucket]).cast::<lock_helpers::McsRwlockLock>(),
                );
            }
        }
        process.pid = pid;
        target.proc = &raw mut *process;
        target.tid = tid;
        target.status = 0x10; // Genuine warning predicate, exercised before CAS.
        target.refcount.counter = count;
        let target = Box::into_raw(target);
        // SAFETY: A valid positive TID, stable allocation and private empty bucket.
        unsafe {
            let head = addr_of_mut!(hash.list[thread_hash(tid) as usize]);
            let entry = addr_of_mut!((*target).hash_list);
            (*entry).next = head;
            (*entry).prev = head;
            (*head).next = entry;
            (*head).prev = entry;
        }
        Self { hash, process, target }
    }

    fn count(&self) -> CInt {
        // SAFETY: The fixture owns this live allocation; all counter accesses
        // during schedules use the same AtomicI32 and SeqCst domain as Source22.
        unsafe { AtomicI32::from_ptr(addr_of_mut!((*self.target).refcount.counter)) }
            .load(Ordering::SeqCst)
    }

    fn lookup(&mut self, pid: CInt, tid: CInt) -> *mut Thread {
        let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
        let offsets = ProcessFindThreadOffsets {
            thread_hash_list_offset: offset_of!(Thread, hash_list) as CULong,
            thread_tid_offset: offset_of!(Thread, tid) as CULong,
            thread_proc_offset: offset_of!(Thread, proc) as CULong,
            proc_pid_offset: offset_of!(Process, pid) as CULong,
        };
        let bucket = if tid > 0 { thread_hash(tid) as usize } else { 0 };
        // SAFETY: Real typed ABI geometry and original reader pair protect this
        // table and every traversed node until Source22 transfers its owned edge.
        unsafe {
            process_find_thread_live_body_result_v2(
                addr_of_mut!(self.hash.list[bucket]),
                addr_of_mut!(self.hash.lock[bucket]) as CULong,
                node.as_mut_ptr().cast(), pid, tid, &offsets,
                Some(process_mcs_reader_lock_bridge), Some(process_mcs_reader_unlock_bridge),
                Some(process_try_hold_thread_live_v2),
            ).cast()
        }
    }

    fn detach(&mut self) -> CInt {
        // SAFETY: The fixture owns final teardown; actual matching writer pair and
        // typed node protect list membership before the fixture deallocates it.
        unsafe { detach(self.target, &raw mut *self.hash) }
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        if !self.target.is_null() {
            // SAFETY: All schedule workers joined and the fixture retains this
            // allocation. Remaining nonfinal counts are deliberate test inputs.
            unsafe { drop(Box::from_raw(self.target)) };
        }
    }
}

unsafe fn detach(thread: *mut Thread, hash: *mut ThreadHash) -> CInt {
    let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    // SAFETY: The calling fixture supplies its real table/thread and final owner.
    unsafe {
        thread_hash_detach_v3::process_thread_hash_detach_live_body_v3(
            thread, hash, node.as_mut_ptr().cast(),
            Some(process_mcs_writer_lock_bridge), Some(process_mcs_writer_unlock_bridge),
        )
    }
}

fn platform_restored(irq_enabled: bool) {
    assert_eq!(IRQ_ENABLED.get(), irq_enabled, "same saved IRQ state restored");
    assert_eq!(PREEMPT_DEPTH.get(), 0, "one balanced preemption edge");
}

#[test]
fn empty_missing_current_foreign_and_count_boundaries() {
    for irq_enabled in [false, true] {
        IRQ_ENABLED.set(irq_enabled);
        for count in [-1, 0, 1, 2, CInt::MAX - 1, CInt::MAX] {
            for pid in [-1, 71, 81] {
                let mut fixture = Fixture::new(71, 81, count);
                WARNINGS.set(0);
                let found = fixture.lookup(pid, 81);
                let eligible = count > 0 && count < CInt::MAX;
                assert_eq!(found == fixture.target, eligible);
                assert_eq!(fixture.count(), count + CInt::from(eligible));
                assert_eq!(WARNINGS.get(), 1);
                platform_restored(irq_enabled);
                if eligible {
                    // Consume only the exact edge returned by the reused lookup.
                    unsafe { AtomicI32::from_ptr(addr_of_mut!((*found).refcount.counter)) }
                        .fetch_sub(1, Ordering::SeqCst);
                }
                assert!(fixture.lookup(99, 81).is_null()); // Unrelated process PID.
                assert!(fixture.lookup(71, 82).is_null()); // Missing TID / empty bucket.
                assert!(fixture.lookup(71, 0).is_null());
                assert_eq!(fixture.detach(), 1);
                assert!(fixture.lookup(71, 81).is_null()); // Unlink before acquisition.
                platform_restored(irq_enabled);
            }
        }
    }
}

#[test]
fn initialized_unlinked_membership_checked_under_writer() {
    for irq_enabled in [false, true] {
        IRQ_ENABLED.set(irq_enabled);
        let mut fixture = Fixture::new(71, 81, 1);
        assert_eq!(fixture.detach(), 1);
        // Reinitialize solely for this distinct unlinked-input fixture. Production
        // callers must not retry the genuine poisoned once-detached node.
        unsafe {
            let entry = addr_of_mut!((*fixture.target).hash_list);
            (*entry).next = entry;
            (*entry).prev = entry;
        }
        assert_eq!(fixture.detach(), 0);
        platform_restored(irq_enabled);
    }
}

#[test]
fn final_zero_during_reader_blocks_unlink_and_actual_free_until_unlock() {
    for irq_enabled in [false, true] {
        IRQ_ENABLED.set(irq_enabled);
        let mut fixture = Fixture::new(71, 81, 1);
        let target = fixture.target as usize;
        let hash = (&raw mut *fixture.hash) as usize;
        let (start_tx, start_rx) = mpsc::channel();
        let (contended_tx, contended_rx) = mpsc::channel();
        let (done_tx, done_rx) = mpsc::channel();
        let writer = std::thread::spawn(move || {
            IRQ_ENABLED.set(irq_enabled);
            start_rx.recv_timeout(Duration::from_secs(5)).expect("warning starts writer");
            PAUSE_NOTICE.with_borrow_mut(|notice| *notice = Some(contended_tx));
            // SAFETY: Reader retains table/thread; final zero owns teardown. The
            // actual writer cannot detach or free until the reader unlocks.
            unsafe {
                assert_eq!(detach(target as *mut Thread, hash as *mut ThreadHash), 1);
                platform_restored(irq_enabled);
                drop(Box::from_raw(target as *mut Thread));
            }
            done_tx.send(()).expect("main receives actual free completion");
        });
        WARNING_HOOK.with_borrow_mut(|hook| {
            *hook = Some(Box::new(move || {
                // SAFETY: Real Source22 reader currently pins this exact allocation.
                let count = unsafe {
                    AtomicI32::from_ptr(addr_of_mut!((*(target as *mut Thread)).refcount.counter))
                };
                assert_eq!(count.fetch_sub(1, Ordering::SeqCst), 1);
                start_tx.send(()).unwrap();
                contended_rx.recv_timeout(Duration::from_secs(5))
                    .expect("actual writer ticket reached cpu_pause behind reader");
                assert!(done_rx.try_recv().is_err(), "free cannot precede reader unlock");
            }));
        });
        assert!(fixture.lookup(71, 81).is_null(), "zero cannot be resurrected");
        WARNING_HOOK.with_borrow_mut(|hook| *hook = None);
        // Never touch thread memory after lookup unlock; writer actually freed it.
        fixture.target = null_mut();
        writer.join().expect("writer detached, restored IRQs and actually freed once");
        platform_restored(irq_enabled);
        assert!(fixture.lookup(71, 81).is_null());
    }
}

#[test]
fn acquired_reference_survives_original_owner_drop_then_last_release_frees() {
    for irq_enabled in [false, true] {
        IRQ_ENABLED.set(irq_enabled);
        let mut fixture = Fixture::new(71, 81, 1);
        let acquired = fixture.lookup(71, 81);
        assert_eq!(acquired, fixture.target);
        assert_eq!(fixture.count(), 2);
        let count = unsafe { AtomicI32::from_ptr(addr_of_mut!((*acquired).refcount.counter)) };
        assert_eq!(count.fetch_sub(1, Ordering::SeqCst), 2);
        assert_eq!(fixture.count(), 1, "lookup edge prevents final destruction");
        assert_eq!(count.fetch_sub(1, Ordering::SeqCst), 1);
        assert_eq!(fixture.detach(), 1);
        // SAFETY: Last release, writer completed, table no longer publishes it.
        unsafe { drop(Box::from_raw(acquired)) };
        fixture.target = null_mut();
        assert!(fixture.lookup(71, 81).is_null());
        platform_restored(irq_enabled);
    }
}

#[test]
fn invalid_setup_does_not_enter_writer_or_change_platform_state() {
    let mut fixture = Fixture::new(71, 81, 1);
    for irq_enabled in [false, true] {
        IRQ_ENABLED.set(irq_enabled);
        let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
        for (thread, hash, lock_node, lock, unlock) in [
            (null_mut(), &raw mut *fixture.hash, node.as_mut_ptr().cast(),
             Some(process_mcs_writer_lock_bridge as ProcessMcsRwlockFn),
             Some(process_mcs_writer_unlock_bridge as ProcessMcsRwlockFn)),
            (fixture.target, null_mut(), node.as_mut_ptr().cast(), None, None),
            (fixture.target, &raw mut *fixture.hash, null_mut(), None, None),
            (fixture.target, &raw mut *fixture.hash, node.as_mut_ptr().cast(), None,
             Some(process_mcs_writer_unlock_bridge as ProcessMcsRwlockFn)),
            (fixture.target, &raw mut *fixture.hash, node.as_mut_ptr().cast(),
             Some(process_mcs_writer_lock_bridge as ProcessMcsRwlockFn), None),
        ] {
            assert_eq!(unsafe {
                thread_hash_detach_v3::process_thread_hash_detach_live_body_v3(
                    thread, hash, lock_node, lock, unlock,
                )
            }, -22);
            assert_eq!(fixture.count(), 1);
            platform_restored(irq_enabled);
        }
    }
}
