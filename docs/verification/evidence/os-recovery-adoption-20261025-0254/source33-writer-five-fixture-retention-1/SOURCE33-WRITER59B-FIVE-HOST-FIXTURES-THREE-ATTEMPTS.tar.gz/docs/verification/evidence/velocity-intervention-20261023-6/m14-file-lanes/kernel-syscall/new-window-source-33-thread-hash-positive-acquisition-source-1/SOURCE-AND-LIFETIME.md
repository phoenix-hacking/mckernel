Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source33 remains private and default OFF. No canonical/shared source was edited.
Owner: process_hash33. Downstream: production composition/qualification of Source22
and Source31/32 retained-reference consumers. Native/C-file retirement credit: zero.

The existing reader is already implemented, not missing. Source22's retained
`output-1/candidate.o` is 3032 bytes, SHA256
`fbd487805402b1e0248481f69a7597276fd6dd100aeeba0d572dc4383b695e0b`.
It calls the actual `process_mcs_reader_lock_bridge` before list traversal and
positive-only `process_try_hold_thread_live_v2`, then unlocks. Source33 links that
object directly; it does not re-port or recompile the existing lookup/CAS body.
The original Source22 actual C42/ABI12+20 acceptance is retained at its scope.

The new body is `process_thread_hash_detach_live_body_v3` in
`thread_hash_detach_v3.rs`. It is a typed writer-side composition: cache one genuine
ThreadHash bucket address, acquire its existing writer with its caller-owned
IRQ-save node, inspect membership under that writer, reuse the actual existing
list-detach/poison body, and unlock the identical cached address/node. It frees
nothing and transfers no reference. Initialized unlinked entries return zero;
one-time linked detach returns one. Invalid setup returns -EINVAL before locking.
Negative setup results do not permit a caller to continue destructive teardown.
The old bridge and old selection remain intact until a reviewed caller successor
qualifies its setup/error contract. No compute C expansion is proposed.

Actual selected ordering and ownership

* `kernel/process.c::find_thread` and the Rust `find_thread` both select one
  resource_set thread-hash bucket and use the reader pair during lookup.
* `process_release_thread_body_result` decrements before final destruction; its
  profile and procfs callbacks precede `destroy_thread`. Profile frees event
  storage, not thread allocation; procfs removal is a separate provider obligation.
* `process_destroy_thread_body_result` calls hash detach before obtaining sibling
  ownership, releasing sigcommon or freeing a nonmain thread's stack allocation.
  VM/process final release follows `destroy_thread` in the release body; the main
  thread allocation is freed later by process teardown. Those full provider and
  configuration contracts still need current production qualification.
* Canonical `process_destroy_thread_hash_detach_bridge` already takes the matching
  writer before unlink. Its membership test precedes that lock; Source33 moves the
  test into the locked companion and caches the same bucket for release.
* The current selected `lock_helpers` reader and writer IRQ-save entries both
  call the same `spinlock_helpers` ticket lock. These fixtures use those complete
  actual Rust modules, not a counter-only imitation of reader/writer exclusion.

The essential lifetime condition is unchanged: every freeing path for a published
thread must first complete detachment under this same bucket writer, and its
process must remain live for PID comparison until the reader releases. A positive
CAS before final decrement retains the allocation after reader unlock. A CAS
after final zero rejects while the reader still prevents the writer from
unlinking/freeing. This does not invent global reader protection, RCU, a second
reference count or a new lock domain. It cannot qualify unrelated freeing paths.

Required production callbacks and ABI

The only lock callbacks are genuine existing
`process_mcs_writer_lock_bridge(unsigned long, void *)` and its matching unlock,
the same `process_mcs_rwlock_fn_t` as in `kernel/include/process_helpers.h:214`.
The genuine reader pair is supplied to the retained Source22 body unchanged.
Typed storage uses the current Rust/C Thread, ThreadHash, 64-byte MCS lock and
64-byte IRQ-save node layout. New body signature returns C int and accepts
`Thread *`, `ThreadHash *`, `void *` node and two nullable function pointers.
No old void hold callback is converted into an acquisition result. No callback
ABI is cast to conceal a return type mismatch.

Fixture limits and next command

`COMPILE-AND-FIXTURE.READY.NOT-GRANTED.json` binds exact source snapshots, extracted
genuine bridge/list bodies, retained Source22 object and pinned compiler. The
next commands are its exact pinned rustc --test compilation and one serialized
fixture invocation, after a fresh coordinator grant for an ordinary CPU. No
compiler or fixture has run as of initial preparation. Source materialization is
not an executable behavior result. No new Docker/root/native action is proposed.

The five prepared test functions cover empty/missing TID, own/exact/foreign/fallback
PID, negative/zero/positive/MAX-1/MAX reference counts, initialized-unlinked nodes,
unlink-before-acquire, invalid setup, and both initial IRQ states. A deterministic
two-thread schedule drops the final edge inside the real Source22 warning while
the real reader is held. It requires the writer to reach the actual ticket wait
loop, verifies free has not completed, then lets the unchanged zero CAS reject.
Only after reader unlock may the writer detach and actually deallocate the Box.
The acquired-edge fixture drops the original owner's edge, proves one remains,
then consumes that last edge, detaches and deallocates. The fixture release is a
minimal edge/destruction harness; it is not the complete production release path.

Host IRQ, preemption and warning hooks are explicit platform stubs. They check
balanced actual lock-provider calls and restoration of both saved IRQ states;
they do not execute privileged IRQ instructions or claim native behavior.
No seeded stress or security testing is included. ABI/fullcrate/default-link,
all real final-free paths, real process lifetime, native contention and independent
execution/final acceptance remain OPEN. No broad COMMON/BSS diagnosis or unchanged
image build is attempted.

Failure history starts empty for this new companion/fixture family. Preserve a
first failure and allow one bounded correction before expert escalation. Keep
all Source22/31/32 evidence, all existing compiler/native restrictions and the
fixed campaign deadline/credit/service controls unchanged.
