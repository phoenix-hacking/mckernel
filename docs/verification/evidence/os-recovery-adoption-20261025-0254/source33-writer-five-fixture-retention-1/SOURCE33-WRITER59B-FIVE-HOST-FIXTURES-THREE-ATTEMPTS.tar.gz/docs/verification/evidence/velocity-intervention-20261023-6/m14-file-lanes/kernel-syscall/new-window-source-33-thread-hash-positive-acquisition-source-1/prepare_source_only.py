#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Freeze genuine fixture sources and a compiler proposal. Does not compile or run.
"""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SOURCE22 = ROOT.parent / 'new-window-source-22-positive-reference-lookup-repair'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def function(text, name):
    # Every selected function is unsafe; extern-block prototypes are plain `fn`
    # and must never be mistaken for an implementation.
    found = re.search(r'(?:pub )?unsafe (?:extern "C" )?fn ' + name + r'\(', text)
    if found is None:
        raise RuntimeError('missing genuine function ' + name)
    begin = found.start()
    brace = text.index('{', found.end())
    depth = 1
    end = brace + 1
    while depth:
        if text[end] == '{':
            depth += 1
        elif text[end] == '}':
            depth -= 1
        end += 1
    return text[begin:end] + '\n'


def main():
    snapshot = ROOT / 'genuine'
    snapshot.mkdir(exist_ok=False)
    bindings = []
    for name in ('abi.rs', 'lock_helpers.rs', 'spinlock_helpers.rs'):
        origin = REPO / 'kernel/rust' / name
        target = snapshot / name
        target.write_bytes(origin.read_bytes())
        bindings.append(dict(origin=pin(origin), snapshot=pin(target)))
    origin = REPO / 'kernel/rust/process_helpers.rs'
    text = origin.read_text()
    names = ('process_list_is_linked_result', 'list_detach', 'process_list_detach_result',
             'process_mcs_reader_lock_bridge', 'process_mcs_reader_unlock_bridge',
             'process_mcs_writer_lock_bridge', 'process_mcs_writer_unlock_bridge')
    functions = []
    bodies = []
    for name in names:
        body = function(text, name)
        # Bridge symbols are required by the retained Source22 object.
        bodies.append(('#[no_mangle]\n' if name.startswith('process_mcs_') else '') + body)
        functions.append(dict(name=name, bytes=len(body.encode()),
                              sha256=hashlib.sha256(body.encode()).hexdigest()))
    constants = '\n'.join(re.findall(r'^const LIST_POISON[12]:[^\n]*', text, re.M))
    (snapshot / 'process_bodies.rs.inc').write_text(constants + '\n\n' + '\n'.join(bodies))
    bindings.append(dict(origin=pin(origin), extraction=pin(snapshot / 'process_bodies.rs.inc'),
                         exact_functions=functions))
    retained = SOURCE22 / 'output-1/candidate.o'
    if pin(retained)['sha256'] != 'fbd487805402b1e0248481f69a7597276fd6dd100aeeba0d572dc4383b695e0b':
        raise RuntimeError('Source22 retained object changed')
    rustc = Path('/home/holden/mckernel-work/toolchains/rustup/toolchains/'
                 '1.92.0-x86_64-unknown-linux-gnu/bin/rustc')
    result = dict(
        scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',
        status='SOURCE_ONLY_READY_FRESH_COORDINATOR_GRANT_REQUIRED',
        owner='process_hash33', production_default=False,
        genuine_sources=bindings, retained_Source22_object=pin(retained), rustc=pin(rustc),
        sources=[pin(ROOT / name) for name in ('thread_hash_detach_v3.rs', 'fixture.rs',
                                               'prepare_source_only.py')],
        commands=[
            dict(purpose='Functional OS work only; no security testing. Compile only the new '
                         'writer companion and real-lock HOST fixtures; link retained Source22 '
                         'object without recompiling its CAS/lookup implementation.',
                 argv=[str(rustc), '--test', '--edition=2021', '-C', 'opt-level=1',
                       '-C', 'debuginfo=0', '-C', 'link-arg=' + str(retained),
                       str(ROOT / 'fixture.rs'), '-o', str(ROOT / 'output-1/fixture')],
                 cwd=str(REPO), expected_exit=0),
            dict(purpose='Functional OS work only; no security testing. Run deterministic '
                         'HOST ownership, actual ticket-lock and IRQ/preemption-stub fixtures. '
                         'No McKernel guest or native claim.',
                 argv=[str(ROOT / 'output-1/fixture'), '--test-threads=1', '--nocapture'],
                 cwd=str(REPO), expected_exit=0)],
        proposed_profile=dict(ordinary_jobs=1, compiler_threads=1, CPU='coordinator grant required',
                              AS_bytes=2 << 30, whole_wall_seconds=90, whole_CPU_seconds=60,
                              new_root_or_Docker_or_guest=False),
        holds=['Fresh coordinator resource/compiler grant.',
               'Independent source and ABI/concurrency review before production integration.',
               'Actual fullcrate/C ABI/default link/native evidence remain OPEN.'])
    (ROOT / 'COMPILE-AND-FIXTURE.READY.NOT-GRANTED.json').write_text(
        json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
