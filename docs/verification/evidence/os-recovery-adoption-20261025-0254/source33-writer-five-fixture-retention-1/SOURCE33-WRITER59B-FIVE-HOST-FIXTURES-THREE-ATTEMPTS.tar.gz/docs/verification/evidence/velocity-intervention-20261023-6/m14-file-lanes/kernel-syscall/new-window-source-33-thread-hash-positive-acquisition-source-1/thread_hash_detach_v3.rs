// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private process_helpers child. No production/default selection is changed.
use core::ffi::c_void;
use core::ptr::addr_of_mut;

use crate::abi::{CInt, CULong, Thread, ThreadHash, PROCESS_HASH_SIZE};

use super::ProcessMcsRwlockFn;

/// Detach one final-destruction thread under its original hash bucket writer.
///
/// Returns one for a detached entry, zero for an initialized unlinked entry, or
/// -EINVAL for invalid setup. The result transfers no reference and frees nothing.
/// Source22 supplies the reader/positive-CAS side unchanged; this companion closes
/// the writer's unlocked membership observation and caches one bucket identity.
///
/// # Safety
/// `thread` is a live allocation exclusively owned by its one-time final teardown.
/// Its immutable TID still identifies this live `hash_table` and its actual bucket.
/// The table, node and thread outlive both callbacks. `node` is aligned exclusive
/// writable McsRwlockNodeIrqsave storage. Callbacks are the genuine matching writer
/// pair, with the original lock order, saved IRQ state and preemption semantics.
/// All insertion/removal uses that bucket's lock; published adjacent nodes remain
/// live through unlock. No already-poisoned, previously detached entry is allowed.
/// Thread/process/sigcommon/VM storage may be released only AFTER this returns.
/// A failed setup does not authorize continued teardown or a retry with dead data.
#[no_mangle]
pub unsafe extern "C" fn process_thread_hash_detach_live_body_v3(
    thread: *mut Thread,
    hash_table: *mut ThreadHash,
    node: *mut c_void,
    lock: Option<ProcessMcsRwlockFn>,
    unlock: Option<ProcessMcsRwlockFn>,
) -> CInt {
    if thread.is_null() || hash_table.is_null() || node.is_null() {
        return -22;
    }
    let (Some(lock), Some(unlock)) = (lock, unlock) else {
        return -22;
    };
    // SAFETY: Final teardown owns thread storage and its immutable published TID.
    let tid = unsafe { (*thread).tid };
    if tid < 0 {
        return -22;
    }
    let bucket = super::thread_hash(tid);
    if bucket < 0 || bucket as usize >= PROCESS_HASH_SIZE {
        return -22;
    }
    // SAFETY: Genuine ThreadHash geometry, stable table and validated bucket.
    // Cache one address before acquisition; unlock never reloads CPU/resource_set.
    let lock_addr = unsafe { addr_of_mut!((*hash_table).lock[bucket as usize]) as CULong };
    // SAFETY: Original matching writer/IRQ-save ABI; node stays private throughout.
    unsafe { lock(lock_addr, node) };
    // SAFETY: Membership is observed only while the corresponding writer is held.
    // The same lock excludes Source22 readers and protects adjacent live links.
    let entry = unsafe { addr_of_mut!((*thread).hash_list) };
    let detached = if unsafe { super::process_list_is_linked_result(entry) } != 0 {
        // SAFETY: One-time teardown and genuine linked node under its writer.
        // Reuse the existing detach/poison implementation without rewriting it.
        unsafe { super::process_list_detach_result(entry) };
        1
    } else {
        0
    };
    // SAFETY: Exact acquisition address/node; actual bridge restores saved IRQs.
    unsafe { unlock(lock_addr, node) };
    detached
}

const _: unsafe extern "C" fn(
    *mut Thread,
    *mut ThreadHash,
    *mut c_void,
    Option<ProcessMcsRwlockFn>,
    Option<ProcessMcsRwlockFn>,
) -> CInt = process_thread_hash_detach_live_body_v3;
