#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Verify a HOST fixture derivative; this is not a kernel/default artifact qualifier.
"""
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
RECIPE = ROOT / 'EXACT-FOUR-SECTION-CORRECTION.NOT-GRANTED.json'


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


class Elf:
    def __init__(self, path):
        self.path = path
        self.raw = path.read_bytes()
        header = struct.unpack_from('<16sHHIQQQIHHHHHH', self.raw)
        require(header[0][:7] == b'\x7fELF\x02\x01\x01', 'expected ELF64 little endian')
        require(header[1:4] == (1, 62, 1), 'expected x86_64 ET_REL version1')
        require(header[4] == 0 and header[5] == 0, 'no entry/program headers permitted')
        require(header[11] == 64 and header[12] > 0, 'ordinary ELF section table')
        self.sections = [struct.unpack_from('<IIQQQQIIQQ', self.raw, header[6] + i * 64)
                         for i in range(header[12])]
        name_section = self.sections[header[13]]
        self.names = self.raw[name_section[4]:name_section[4] + name_section[5]]
        self.symbols = {}
        for index, section in enumerate(self.sections):
            if section[1] != 2:
                continue
            require(section[9] == 24, 'ELF64 symbol stride')
            strings = self.bytes(section[6])
            symbols = []
            for offset in range(section[4], section[4] + section[5], 24):
                name, info, other, owner, value, size = struct.unpack_from('<IBBHQQ', self.raw, offset)
                symbols.append(dict(name=self.string(strings, name), info=info, other=other,
                                    owner=owner, value=value, size=size))
            self.symbols[index] = symbols
        require(len(self.symbols) == 1, 'exactly one symbol table')

    @staticmethod
    def string(raw, offset):
        end = raw.find(b'\0', offset)
        require(0 <= offset < len(raw) and end >= offset, 'valid string table offset')
        return raw[offset:end].decode()

    def name(self, index):
        return self.string(self.names, self.sections[index][0])

    def bytes(self, index):
        section = self.sections[index]
        return self.raw[section[4]:section[4] + section[5]]

    def index(self, name):
        found = [i for i in range(len(self.sections)) if self.name(i) == name]
        require(len(found) == 1, 'unique section ' + name)
        return found[0]

    def relocations(self, owner):
        result = []
        for section in self.sections:
            if section[7] != owner or section[1] not in (4, 9):
                continue
            require(section[1] == 4 and section[9] == 24, 'only ELF64 RELA permitted')
            for offset in range(section[4], section[4] + section[5], 24):
                location, info, addend = struct.unpack_from('<QQq', self.raw, offset)
                symbol = self.symbols[section[6]][info >> 32]
                require(0 < symbol['owner'] < len(self.sections), 'relocation owns defined section')
                result.append(dict(offset=location, type=info & 0xffffffff,
                                   target_section=self.name(symbol['owner']),
                                   target_value=symbol['value'], addend=addend))
        return sorted(result, key=lambda row: (row['offset'], row['target_section']))

    def function(self, name):
        found = [symbol for table in self.symbols.values() for symbol in table
                 if symbol['name'] == name]
        require(len(found) == 1, 'unique exported symbol ' + name)
        symbol = dict(found[0])
        require(0 < symbol['owner'] < len(self.sections), 'function has defined owner')
        symbol['section'] = self.name(symbol.pop('owner'))
        return symbol


def main():
    recipe = json.loads(RECIPE.read_text())
    source_path = Path(recipe['closure']['source_object']['path'])
    source_raw = source_path.read_bytes()
    require(hashlib.sha256(source_raw).hexdigest() == recipe['closure']['source_object']['sha256'],
            'original retained f9 object hash')
    source = Elf(source_path)
    derived_path = Path(recipe['closure']['derived_object'])
    derived = Elf(derived_path)
    expected = recipe['closure']['sections']
    expected_names = {row['name'] for row in expected}
    allocated = {derived.name(i) for i, section in enumerate(derived.sections) if section[2] & 2}
    require(allocated == expected_names, 'exact four allocated sections; no metadata/startup roots')
    rows = []
    relocation_count = 0
    for row in expected:
        before_index = source.index(row['name'])
        after_index = derived.index(row['name'])
        before = source.sections[before_index]
        after = derived.sections[after_index]
        require(before[1:4] == after[1:4] and before[5] == after[5] == row['bytes'],
                'section type/flags/address/size unchanged: ' + row['name'])
        require(before[8:] == after[8:], 'section alignment/entry size unchanged')
        raw = source.bytes(before_index)
        require(raw == derived.bytes(after_index), 'exact original instruction bytes')
        require(hashlib.sha256(raw).hexdigest() == row['sha256'], 'frozen section bytes')
        before_relocations = source.relocations(before_index)
        after_relocations = derived.relocations(after_index)
        require(before_relocations == after_relocations == row['relocations'],
                'full semantic RELA target/offset/type/addend equivalence')
        require(all(item['type'] == 1 and item['target_section'] in expected_names
                    for item in after_relocations), 'R_X86_64_64 closure stays inside exact four')
        relocation_count += len(after_relocations)
        rows.append(dict(name=row['name'], bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                         relocations=after_relocations))
    require(relocation_count == 3, 'exact three original RELAs')
    for export in recipe['closure']['exports']:
        original = source.function(export)
        current = derived.function(export)
        require(original == current, 'exact selected function symbol ABI/value/size/visibility')
        require(current['info'] == 0x12 and current['other'] == 0 and current['value'] == 0,
                'GLOBAL FUNC DEFAULT zero-offset entry')
    undefined = [symbol['name'] for table in derived.symbols.values() for symbol in table
                 if symbol['owner'] == 0 and symbol['name']]
    require(not undefined, 'no undefined imports or traps')
    require(not any(symbol['name'] == 'main' for table in derived.symbols.values() for symbol in table),
            'kernel main absent')
    result = dict(scope=recipe['scope'], status='PASS_EXACT_FOUR_SECTIONS_THREE_RELAS_HOST_DERIVATIVE_ONLY',
                  source_object=recipe['closure']['source_object'],
                  derived_object=dict(path=str(derived_path), bytes=len(derived.raw),
                                      sha256=hashlib.sha256(derived.raw).hexdigest()),
                  sections=rows, exported_ABI=recipe['closure']['exports'], undefined=[],
                  production_default=False, native=False, code_recompiled=False)
    with (ROOT / 'output-1/EXACT-RETAINED-BYTE-CLOSURE-PROOF.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print('PASS exact retained code sections=4 bytes=593 RELAs=3 exports=2 undefined=0 HOST-only')


if __name__ == '__main__':
    main()
