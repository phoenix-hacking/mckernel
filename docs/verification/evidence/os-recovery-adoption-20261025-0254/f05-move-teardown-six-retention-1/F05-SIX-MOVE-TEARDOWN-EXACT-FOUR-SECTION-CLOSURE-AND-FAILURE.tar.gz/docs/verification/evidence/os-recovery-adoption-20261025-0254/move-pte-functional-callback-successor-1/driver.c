/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <arch-memory.h>
#include <arch-memory-helpers.h>

extern int dprintf(int, const char *, ...);
extern int puts(const char *);
extern void abort(void);
extern int posix_memalign(void **, __SIZE_TYPE__, __SIZE_TYPE__);
extern void free(void *);

#define require(value) do { if (!(value)) { \
    dprintf(2, "FAIL move teardown line=%d: %s\n", __LINE__, #value); abort(); \
} } while (0)

_Static_assert(sizeof(pte_t) == 8, "genuine LP64 PTE");
_Static_assert(PT_ENTRIES * sizeof(pte_t) == PAGE_SIZE, "genuine table geometry");
_Static_assert(__builtin_types_compatible_p(__typeof__(&x86_move_one_page_body_result),
    int (*)(void *, void *, unsigned long *, unsigned long, int, unsigned long,
            unsigned long, void *, void *, x86_move_set_range_fn_t, x86_move_log_fn_t)),
    "genuine callback prototype");

struct allocation { pte_t *table; unsigned long phys; int live; };
static struct allocation allocations[4];
static int allocated, freed, translations, expected_free[4], mode, sets, logs;
static pte_t *source_entry, *destination_entry;
static unsigned long original_entry, source_start, destination_start, page_address;
static int page_shift;
static char vm_identity, range_identity, argument_identity;

static pte_t *new_table(void)
{
    void *memory = 0;
    require(allocated < 4);
    require(posix_memalign(&memory, PAGE_SIZE, PAGE_SIZE) == 0);
    pte_t *table = memory;
    for (int index = 0; index < PT_ENTRIES; ++index) table[index] = 0;
    allocations[allocated] = (struct allocation){table, (allocated + 1UL) << PAGE_SHIFT, 1};
    ++allocated;
    return table;
}

static void *translate_table(unsigned long physical)
{
    ++translations;
    for (int index = 0; index < allocated; ++index) {
        if (physical == allocations[index].phys) {
            require(allocations[index].live);
            return allocations[index].table;
        }
    }
    /* Payload, huge mappings, and absent entries must never become table owners. */
    require(0);
    return 0;
}

static void release_table(void *address, int count)
{
    require(count == 1 && freed < allocated);
    int index = expected_free[freed];
    require(address == allocations[index].table && allocations[index].live);
    allocations[index].live = 0;
    ++freed;
    free(address);
}

static void unexpected_panic(int reason)
{
    (void)reason;
    require(0);
}

static int map_destination(void *pt, void *vm, unsigned long start, unsigned long end,
    unsigned long phys, unsigned long attr, int shift, void *range, int overwrite)
{
    require(pt == allocations[0].table && vm == &vm_identity && range == &range_identity);
    require(sets++ == 0 && *source_entry == 0);
    require(start == destination_start + (page_address - source_start));
    require(end == start + (1UL << page_shift));
    require(phys == (original_entry & PT_PHYSMASK));
    require(attr == (original_entry & ~PT_PHYSMASK));
    require(shift == page_shift && overwrite == 0);
    if (mode != 1) *destination_entry = phys | attr;
    if (mode == 3) *source_entry = 0xbeef003UL;
    return mode == 1 || mode == 2 || mode == 3 ? -12 : 0;
}

static void record_log(int event, void *arg, void *pt, unsigned long *ptep,
    unsigned long entry, unsigned long current, unsigned long address, int shift, int error)
{
    require(logs++ == 0 && arg == &argument_identity && pt == allocations[0].table);
    require(ptep == source_entry && entry == original_entry);
    require(current == *source_entry && address == page_address && shift == page_shift);
    require(event == (mode == 4 ? X86_MOVE_ONE_LOG_FILEOFF : X86_MOVE_ONE_LOG_SET_FAILED));
    require(error == (mode == 4 ? -524 : -12));
}

static const x86_move_set_range_fn_t genuine_set_callback = map_destination;
static const x86_move_log_fn_t genuine_log_callback = record_log;
static const x86_pt_phys_to_virt_fn_t genuine_translate_callback = translate_table;
static const x86_pt_free_pages_fn_t genuine_release_callback = release_table;
static const x86_pt_destroy_panic_fn_t genuine_panic_callback = unexpected_panic;

static void move_then_teardown(int scenario)
{
    mode = scenario;
    allocated = freed = translations = sets = logs = 0;
    pte_t *source_root = new_table();
    pte_t *destination_root = new_table();
    if (mode == 5) {
        source_entry = &source_root[3];
        destination_entry = &destination_root[4];
        expected_free[0] = 0;
        expected_free[1] = 1;
        page_shift = LARGE_PAGE_SHIFT;
        source_start = 0x400000;
        destination_start = 0xa00000;
        page_address = 0x600000;
        original_entry = 0x200000UL | PFL2_PRESENT | PFL2_SIZE | (1UL << 63);
    } else {
        pte_t *source_leaf = new_table();
        pte_t *destination_leaf = new_table();
        source_root[3] = allocations[2].phys | PFL2_PRESENT;
        destination_root[4] = allocations[3].phys | PFL2_PRESENT;
        source_entry = &source_leaf[7];
        destination_entry = &destination_leaf[8];
        expected_free[0] = 2;
        expected_free[1] = 0;
        expected_free[2] = 3;
        expected_free[3] = 1;
        page_shift = PAGE_SHIFT;
        source_start = 0x4000;
        destination_start = 0x7000;
        page_address = 0x5000;
        original_entry = 0xdead000UL | PFL2_PRESENT | (1UL << 63);
        if (mode == 4) original_entry |= PFL1_FILEOFF;
    }
    /* Real L2 entries which must not trigger a physical-to-table translation. */
    source_root[10] = 0x600000UL | PFL2_PRESENT | PFL2_SIZE;
    destination_root[10] = 0x800000UL | PFL2_SIZE;
    *source_entry = original_entry;
    int error = x86_move_one_page_body_result(&argument_identity, source_root, source_entry,
        page_address, page_shift, source_start, destination_start, &vm_identity,
        &range_identity, genuine_set_callback, genuine_log_callback);
    require(error == (mode == 4 ? -524 : mode >= 1 && mode <= 3 ? -12 : 0));
    require(sets == (mode == 4 ? 0 : 1));
    require(logs == (mode >= 1 && mode <= 4 ? 1 : 0));
    require(*source_entry == (mode == 4 ? original_entry : mode == 3 ? 0xbeef003UL : 0));
    require(*destination_entry == (mode == 1 || mode == 4 ? 0 : original_entry));
    /* Preserve the observed partial state on failed mapping; no invented rollback. */
    require(x86_pt_destroy_table_result(2, source_root, genuine_translate_callback,
        genuine_release_callback, genuine_panic_callback) == 0);
    require(x86_pt_destroy_table_result(2, destination_root, genuine_translate_callback,
        genuine_release_callback, genuine_panic_callback) == 0);
    require(freed == allocated && translations == (mode == 5 ? 0 : 2));
    for (int index = 0; index < allocated; ++index) require(!allocations[index].live);
}

int main(void)
{
    for (int scenario = 0; scenario < 6; ++scenario) move_then_teardown(scenario);
    puts("PASS move-teardown lifecycle scenarios=6 move_calls=6 destroy_calls=12 tables_freed=22 ABI=3");
    return 0;
}
