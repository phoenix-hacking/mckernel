Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This fixture extends the selected F05 move callback into page-table teardown.
It does not port another copy of the callback or repeat the historical 42-case
standalone trace fixture. HANDOFF records that trace fixture as HOST accepted;
the newer worklist's unlocated `875f` object/prepared42 pointer remains UNKNOWN.
Neither pointer is used as executable authority here.

The executable dependency is the unchanged, actually compiled corrected default
Rust object `f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003`.
Its actual `x86_memory_helpers.rs` bytes match the current selected source.
The candidate composes its existing `x86_move_one_page_body_result` and
`x86_pt_destroy_table_result`; no Rust recompile or production source patch is
needed. The genuine header types and constants are bound to the same actual
materialized source graph, not locally invented declarations.

Six scenarios use real aligned 4 KiB host allocations as 512-entry page tables.
The destination callback verifies the source has already been atomically cleared,
the exact physical/attribute split, full-width NX bit, translated destination,
page shift, VM/range identity and overwrite=0. Scenarios cover success, rejection
before destination write, destination write followed by error, source repopulation
followed by error, file-offset rejection and a 2 MiB mapping. The oracle preserves
existing partial state on mapping error; it does not invent rollback. Failure logs
must report the original entry and the current source PTE separately.

Each move then runs the real Rust recursive teardown on source and destination
L2 trees. The translation adapter accepts only registered live table allocations.
The release adapter requires child-before-parent order and frees each allocation
once using the host allocator. Present huge mappings, absent entries and physical
payload addresses must never be translated into table owners or freed. Across six
scenarios, 6 moves and 12 teardowns must release exactly 22 table allocations.
No pointer into a freed table is dereferenced afterward.

The exact next tuple in READY.NOT-GRANTED.json has only two commands: GCC9 links
this HOST fixture against the retained object with section garbage collection;
the resulting program runs the six focused composition scenarios. The frozen
runner authenticates source/input identities and uses the existing h990 capture,
first-failure stop and CPU0 finite ordinary profile. The runner source was parsed
as Python only. No C compiler, fixture or workload was executed in preparation.

This is a controlled provider composition. It does not execute the actual
`ihk_mc_pt_set_range` allocation/walker provider, hardware TLB flush, kernel VM
locks or concurrent aliasing. Those remain concrete production requirements.
Passing it would establish this callback/teardown composition under the stated
initialized table ownership, not native mapping or whole-file acceptance.
