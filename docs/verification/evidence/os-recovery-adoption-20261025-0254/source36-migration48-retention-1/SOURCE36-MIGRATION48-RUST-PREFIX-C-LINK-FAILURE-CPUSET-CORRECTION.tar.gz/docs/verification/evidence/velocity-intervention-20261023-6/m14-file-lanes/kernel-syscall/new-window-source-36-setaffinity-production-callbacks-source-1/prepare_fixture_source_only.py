"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare genuine-layout controlled fixture and ordinary recipe; never run commands.
"""
from pathlib import Path
import hashlib, json, re

HERE=Path(__file__).resolve().parent
REPO=Path('/home/holden/mckernel')
KS=HERE.parent
SOURCE=REPO/'kernel/rust/sched_helpers.rs'
ABI=KS/'new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust/abi.rs'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def write(name, value):
    path=HERE/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream: stream.write(value)
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

source=SOURCE.read_text()
start=source.index('#[repr(C)]\nstruct SchedMigrateRequest {')
end=source.index('\n}',start)+2
request=source[start:end]
c=(REPO/'kernel/process.c').read_text()
start=c.index('struct migrate_request {')
end=c.index('\n};',start)+3
write('ACTUAL-MIGRATION-REQUEST.C.inc',c[start:end]+'\n')
header=(REPO/'kernel/include/sched_helpers.h').read_text()
start=header.index('int sched_do_migrate_body_result(')
end=header.index(';',start)+1
declaration=header[start:end].replace('sched_do_migrate_body_result(', 'sched_do_migrate_mask_serialized_v3(',1)
declaration=declaration.replace('unsigned long current_cpu_addr, int cpu_set_bits,','unsigned long current_cpu_addr, unsigned long reservation_lock_addr, int cpu_set_bits,',1)
assert 'reservation_lock_addr' in declaration
write('VERSIONED-MIGRATION-ABI.C.inc',declaration+'\n')
fields=[('req_list_offset','SchedMigrateRequest','list','struct migrate_request'),
 ('req_thread_offset','SchedMigrateRequest','thread','struct migrate_request'),
 ('req_wq_offset','SchedMigrateRequest','wq','struct migrate_request'),
 ('thread_cpu_id_offset','Thread','cpu_id','struct thread'),
 ('thread_tid_offset','Thread','tid','struct thread'),
 ('thread_cpu_set_offset','Thread','cpu_set','struct thread'),
 ('thread_sched_list_offset','Thread','sched_list','struct thread'),
 ('thread_vm_offset','Thread','vm','struct thread'),
 ('vm_address_space_offset','AddressSpace_PLACEHOLDER','address_space','struct process_vm'),
 ('address_space_cpu_set_offset','AddressSpace','cpu_set','struct address_space'),
 ('address_space_cpu_set_lock_offset','AddressSpace','cpu_set_lock','struct address_space'),
 ('cpu_migq_lock_offset','CpuLocalVar','migq_lock','struct cpu_local_var'),
 ('cpu_migq_offset','CpuLocalVar','migq','struct cpu_local_var'),
 ('cpu_runq_lock_offset','CpuLocalVar','runq_lock','struct cpu_local_var'),
 ('cpu_runq_offset','CpuLocalVar','runq','struct cpu_local_var'),
 ('cpu_runq_len_offset','CpuLocalVar','runq_len','struct cpu_local_var'),
 ('cpu_flags_offset','CpuLocalVar','flags','struct cpu_local_var')]
fields=[(a,'ProcessVm' if b=='AddressSpace_PLACEHOLDER' else b,c,d) for a,b,c,d in fields]
rust_abi=['size_of::<Thread>()','align_of::<Thread>()','size_of::<CpuLocalVar>()',
 'align_of::<CpuLocalVar>()','size_of::<SchedMigrateRequest>()','align_of::<SchedMigrateRequest>()',
 'size_of::<SchedDoMigrateOffsets>()','align_of::<SchedDoMigrateOffsets>()',
 'size_of::<CULong>()','size_of::<CInt>()','size_of::<abi::CpuSet>()',
 'size_of::<Option<SchedMigrateSpinLockFn>>()','size_of::<Option<SchedMigrateCpuLocalFn>>()']
rust_abi += [f'offset_of!({b},{c})' for a,b,c,d in fields]
c_abi=['sizeof(struct thread)','_Alignof(struct thread)','sizeof(struct cpu_local_var)',
 '_Alignof(struct cpu_local_var)','sizeof(struct migrate_request)','_Alignof(struct migrate_request)',
 'sizeof(struct sched_do_migrate_offsets)','_Alignof(struct sched_do_migrate_offsets)',
 'sizeof(unsigned long)','sizeof(int)','sizeof(cpu_set_t)',
 'sizeof(sched_migrate_spin_lock_fn_t)','sizeof(sched_migrate_cpu_local_fn_t)']
c_abi += [f'__builtin_offsetof({d},{c})' for a,b,c,d in fields]
write('ACTUAL-MIGRATION-ABI.C.inc','static const unsigned long c_abi[]={\n'+',\n'.join(c_abi)+'\n};\n'+
 'static const struct sched_do_migrate_offsets offsets={\n'+',\n'.join(f'.{a}=__builtin_offsetof({d},{c})' for a,b,c,d in fields)+'\n};\n')
write('lib.fixture.rs','// '+SCOPE+'\n#![no_std]\n#[path="'+str(ABI)+'"] mod abi;\n'+
 'use abi::{CInt,CULong,AbiListHead,Thread,Waitq,CpuLocalVar,ProcessVm,AddressSpace};\n'+
 'use core::ptr::{read_volatile,write_volatile};\n'+
 'use core::mem::{size_of,align_of,offset_of};\n'+request+'\n'+
 'include!("ACTUAL-MIGRATION-TYPES-AND-HELPERS.rs.inc");\n'+
 'include!("ACTUAL-OLD-MIGRATION-BODY.rs.inc");\n'+
 '#[path="f03_migration_mask_serialized_v3.rs"] mod f03_migration_mask_serialized_v3;\n'+
 '#[no_mangle]\npub static f36_migration_Rust_ABI:[usize;'+str(len(rust_abi))+']=[\n'+',\n'.join(rust_abi)+'\n];\n')

old_recipe=json.loads((KS/'new-window-source-32-setaffinity-lifetime/EXACT-SOURCE32-C-SUFFIX.FROZEN-NOT-GRANTED.json').read_text())
gcc=list(old_recipe['commands'][0]['argv'])
old_driver=str(KS/'new-window-source-32-setaffinity-lifetime/driver.c')
assert gcc.count(old_driver)==1
# Keep genuine include/ABI flags, replace only fixture operands/output.
driver_pos=gcc.index(old_driver)
gcc=gcc[:driver_pos]+[str(HERE/'driver.c'),str(HERE/'output-1/candidate.o'),'-Wl,--gc-sections','-no-pie','-o',str(HERE/'fixture-output-1/fixture')]
rustc=Path('/home/holden/mckernel-work/toolchains/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc')
commands=[dict(name='00-Rust-actual-old-and-private-new-migration-object',argv=[str(rustc),'--crate-name','migration_mask_serialized','--crate-type','lib','--edition=2021','-C','panic=abort','-C','opt-level=2','-C','overflow-checks=off','--emit=obj='+str(HERE/'output-1/candidate.o'),str(HERE/'lib.fixture.rs')]),
 dict(name='01-genuine-C-layout-and-callback-ABI-fixture-link',argv=gcc),
 dict(name='02-controlled-migration-mask-publication-and-transfer',argv=[str(HERE/'fixture-output-1/fixture')])]
for command in commands:
    command.update(cwd=str(HERE),purpose=SCOPE+' '+command['name'])
local_inputs=[pin(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.suffix in {'.rs','.inc','.py','.patch','.c'}]
write('EXACT-ORDINARY-RECIPE.SOURCE-ONLY.NOT-GRANTED.json',json.dumps(dict(scope=SCOPE,
 status='SOURCE_ONLY_NOT_REVIEWED_NOT_GRANTED',commands=commands,inputs=local_inputs,
 immutable_abi=pin(ABI),source_origins=[pin(SOURCE),pin(REPO/'kernel/process.c'),pin(REPO/'kernel/include/sched_helpers.h')],
 header_bindings=old_recipe['header_bindings'],compiler=pin(rustc),
 resources=dict(cpu=[0],jobs=1,uid=1000,as_bytes=2147483648,cpu_seconds=60,wall_seconds=90,grace_seconds=6,file_bytes=33554432,nofile=256,stack_bytes=2097152,core_bytes=0),
 execution='No commands run. Requires ROOT ordinary grant and independent unsafe/ABI review. Split compile-only prefix before fixture suffix.',
 no_replay='Source22/31/32 accepted objects/tests unchanged; none rerun or recompiled. This only tests new migration boundary.'),indent=2)+'\n')
print('Source36 genuine-layout fixture and three-command ordinary recipe prepared only.')
