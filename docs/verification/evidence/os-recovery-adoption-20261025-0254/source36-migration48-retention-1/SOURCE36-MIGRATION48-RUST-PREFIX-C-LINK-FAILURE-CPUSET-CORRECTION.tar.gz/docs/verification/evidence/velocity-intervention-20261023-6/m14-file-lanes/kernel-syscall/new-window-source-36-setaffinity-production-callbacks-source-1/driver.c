/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <sched_helpers.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
#include "ACTUAL-MIGRATION-REQUEST.C.inc"
#include "VERSIONED-MIGRATION-ABI.C.inc"
#include "ACTUAL-MIGRATION-ABI.C.inc"
extern int printf(const char *, ...), dprintf(int, const char *, ...);
extern void abort(void);
#define require(condition) do { if (!(condition)) { dprintf(2,"FAIL migration serialization line=%d: %s\n",__LINE__,#condition); abort(); } } while (0)
extern const unsigned long f36_migration_Rust_ABI[30];
extern int f36_original_migration(int,unsigned long,int,unsigned int,int,
    const struct sched_do_migrate_offsets *,sched_migrate_spin_lock_fn_t,
    sched_migrate_spin_unlock_fn_t,sched_migrate_noirq_lock_fn_t,
    sched_migrate_noirq_unlock_fn_t,sched_migrate_cpu_local_fn_t,
    sched_migrate_waitq_wakeup_fn_t,sched_migrate_vector_fn_t,
    sched_migrate_interrupt_fn_t,sched_do_migrate_log_fn_t);

static struct cpu_local_var cpus[3];
static struct thread threads[3];
static struct process_vm vm;
static struct address_space address_space;
static struct migrate_request requests[3];
static ihk_spinlock_t reservation;
static int modern,current_slot,cpu_ids[3],held_migq,held_mask,held_runq[3],held_vm;
static int wakes,logs,ipis,mask_locks,mask_unlocks,inject_writer,writer_done,writer_cpu;
static int missing_target,expected_error,assert_mask_order;
static unsigned long irqstate,entry_irqstate;
static unsigned long lock_address(void *address) { return (unsigned long)address; }
static void list_init(struct list_head *head) { head->next=head->prev=head; }
static void list_append(struct list_head *head,struct list_head *entry) {
    entry->next=head; entry->prev=head->prev; head->prev->next=entry; head->prev=entry;
}
static void mask_one(cpu_set_t *mask,int cpu) { memset(mask,0,sizeof(*mask)); if(cpu>=0) CPU_SET(cpu,mask); }

/* Model precisely the accepted setter's reservation-protected publication and
 * CPU observation, not its already-tested lookup/usercopy/refcount machinery.
 * Enqueue is deferred until this worker returns, just as a blocked enqueue can
 * wait for the worker's still-held runqueue lock in the production route. */
static void publish_second_setter(void) {
    require(!held_mask); writer_done=1;
    mask_one(&threads[0].cpu_set,cpu_ids[2]);
    writer_cpu=threads[0].cpu_id;
}
static int runq_slot(unsigned long address) {
    for(int slot=0;slot<3;slot++)
        if(address==lock_address(&cpus[slot].runq_lock)) return slot;
    return -1;
}
static unsigned long lock_irq(unsigned long address) {
    unsigned long saved=irqstate; irqstate &= ~0x200UL;
    if(address==lock_address(&cpus[current_slot].migq_lock)) {
        require(!held_migq&&!held_mask); held_migq=1;
    } else if(address==lock_address(&reservation)) {
        require(modern&&held_migq&&!held_mask&&!held_runq[0]&&!held_runq[1]&&!held_runq[2]);
        held_mask=1; mask_locks++;
    } else if(address==lock_address(&address_space.cpu_set_lock)) {
        require(!held_mask&&!held_vm); held_vm=1;
    } else {
        int slot=runq_slot(address); require(slot>=0&&!held_runq[slot]&&held_migq);
        if(assert_mask_order&&modern) require(held_mask);
        if(inject_writer&&!writer_done&&!held_mask) publish_second_setter();
        held_runq[slot]=1;
    }
    return saved;
}
static void unlock_irq(unsigned long address,unsigned long saved) {
    if(address==lock_address(&cpus[current_slot].migq_lock)) {
        require(held_migq&&!held_mask&&!held_runq[0]&&!held_runq[1]&&!held_runq[2]&&!held_vm);
        held_migq=0;
    } else if(address==lock_address(&reservation)) {
        require(held_mask); held_mask=0; mask_unlocks++;
        if(inject_writer&&!writer_done) {
            require(held_runq[0]+held_runq[1]+held_runq[2]==2);
            publish_second_setter();
        }
    } else if(address==lock_address(&address_space.cpu_set_lock)) {
        require(held_vm&&!held_mask); held_vm=0;
    } else {
        int slot=runq_slot(address); require(slot>=0&&held_runq[slot]&&!held_mask); held_runq[slot]=0;
    }
    irqstate=saved;
}
static void lock_noirq(unsigned long address) {
    int slot=runq_slot(address); require(slot>=0&&!held_runq[slot]&&!(irqstate&0x200));
    if(assert_mask_order&&modern) require(held_mask);
    held_runq[slot]=1;
}
static void unlock_noirq(unsigned long address) {
    int slot=runq_slot(address); require(slot>=0&&held_runq[slot]&&!held_mask); held_runq[slot]=0;
}
static unsigned long cpu_local(int cpu) {
    require(held_migq); if(modern) require(held_mask);
    if(missing_target) return 0;
    for(int slot=0;slot<3;slot++) if(cpu_ids[slot]==cpu) return (unsigned long)&cpus[slot];
    return 0;
}
static void wake(unsigned long address) {
    require(held_migq&&!held_mask&&!held_vm);
    require(address==(unsigned long)&requests[0].wq||address==(unsigned long)&requests[1].wq||address==(unsigned long)&requests[2].wq);
    wakes++;
}
static int vector(int key) { require(key==71&&!held_mask); return 151; }
static void interrupt(int cpu,int number) { require(cpu!=cpu_ids[current_slot]&&number==151&&!held_mask); ipis++; }
static void log_move(unsigned long address,int tid,int from,int to) {
    struct thread *thread=(struct thread *)address;
    require(!held_mask&&held_migq&&thread->tid==tid&&thread->cpu_id==to&&from==cpu_ids[current_slot]); logs++;
}
_Static_assert(__builtin_types_compatible_p(__typeof__(&lock_irq),sched_migrate_spin_lock_fn_t),"genuine lock callback ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&unlock_irq),sched_migrate_spin_unlock_fn_t),"genuine unlock callback ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&cpu_local),sched_migrate_cpu_local_fn_t),"genuine CPU lookup callback ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&wake),sched_migrate_waitq_wakeup_fn_t),"genuine waitq callback ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&log_move),sched_do_migrate_log_fn_t),"genuine log callback ABI");

static void reset(int use_new,int start_slot,int allowed_cpu,int with_vm,int enabled) {
    memset(cpus,0,sizeof(cpus)); memset(threads,0,sizeof(threads)); memset(requests,0,sizeof(requests));
    memset(&vm,0,sizeof(vm)); memset(&address_space,0,sizeof(address_space));
    modern=use_new; current_slot=start_slot; cpu_ids[0]=0; cpu_ids[1]=1; cpu_ids[2]=2;
    held_migq=held_mask=held_vm=0; memset(held_runq,0,sizeof(held_runq));
    wakes=logs=ipis=mask_locks=mask_unlocks=inject_writer=writer_done=missing_target=expected_error=0;
    writer_cpu=-1; assert_mask_order=1;
    entry_irqstate=0x51a7000000000051UL|(enabled?0x200UL:0); irqstate=entry_irqstate;
    for(int slot=0;slot<3;slot++) { list_init(&cpus[slot].migq); list_init(&cpus[slot].runq); }
    for(int index=0;index<3;index++) { threads[index].tid=71+index; threads[index].cpu_id=cpu_ids[start_slot]; list_init(&threads[index].sched_list); }
    threads[0].vm=with_vm?&vm:NULL; vm.address_space=&address_space;
    mask_one(&address_space.cpu_set,cpu_ids[start_slot]); mask_one(&threads[0].cpu_set,allowed_cpu);
    list_append(&cpus[start_slot].runq,&threads[0].sched_list); cpus[start_slot].runq_len=1;
    requests[0].thread=&threads[0]; list_append(&cpus[start_slot].migq,&requests[0].list);
}
static int run_worker(int missing_provider) {
    int result;
    if(modern)
        result=sched_do_migrate_mask_serialized_v3(cpu_ids[current_slot],(unsigned long)&cpus[current_slot],(unsigned long)&reservation,
            1024,0x10,71,&offsets,missing_provider==1?NULL:lock_irq,missing_provider==2?NULL:unlock_irq,
            missing_provider==3?NULL:lock_noirq,missing_provider==4?NULL:unlock_noirq,missing_provider==5?NULL:cpu_local,
            missing_provider==6?NULL:wake,missing_provider==7?NULL:vector,missing_provider==8?NULL:interrupt,
            missing_provider==9?NULL:log_move);
    else
        result=f36_original_migration(cpu_ids[current_slot],(unsigned long)&cpus[current_slot],1024,0x10,71,&offsets,
            missing_provider==1?NULL:lock_irq,missing_provider==2?NULL:unlock_irq,
            missing_provider==3?NULL:lock_noirq,missing_provider==4?NULL:unlock_noirq,missing_provider==5?NULL:cpu_local,
            missing_provider==6?NULL:wake,missing_provider==7?NULL:vector,missing_provider==8?NULL:interrupt,
            missing_provider==9?NULL:log_move);
    require(!held_migq&&!held_mask&&!held_vm&&!held_runq[0]&&!held_runq[1]&&!held_runq[2]);
    require(mask_locks==mask_unlocks);
    return result;
}
static void require_move(int target,int with_vm) {
    require(threads[0].cpu_id==cpu_ids[target]&&cpus[current_slot].runq_len==0&&cpus[target].runq_len==1);
    require(cpus[target].runq.next==&threads[0].sched_list&&cpus[target].runq.prev==&threads[0].sched_list);
    require((cpus[target].flags&0x10)&&wakes==1&&logs==1&&ipis==1);
    if(with_vm) require(!CPU_ISSET(cpu_ids[current_slot],&address_space.cpu_set)&&CPU_ISSET(cpu_ids[target],&address_space.cpu_set));
}
int main(void) {
    unsigned int cases=0,legacy_stale=0;
    require(sizeof(c_abi)/sizeof(c_abi[0])==30);
    for(unsigned long index=0;index<30;index++) require(c_abi[index]==f36_migration_Rust_ABI[index]);
    /* Both address ordering branches, IRQ entry states, VM bookkeeping paths. */
    for(int use_new=0;use_new<2;use_new++) for(int reverse=0;reverse<2;reverse++)
    for(int with_vm=0;with_vm<2;with_vm++) for(int enabled=0;enabled<2;enabled++) {
        int from=reverse?2:0,to=reverse?0:1;
        reset(use_new,from,to,with_vm,enabled); require(run_worker(0)==1); require_move(to,with_vm);
        require(irqstate==(use_new?entry_irqstate:entry_irqstate&~0x200UL)); cases++;
    }
    /* Eight required nullable providers fail before acquiring any lock. Log is optional. */
    for(int use_new=0;use_new<2;use_new++) for(int provider=1;provider<=8;provider++) {
        reset(use_new,0,1,0,0); require(run_worker(provider)==-EINVAL); require(!wakes&&!ipis&&!logs&&!mask_locks); cases++;
    }
    for(int use_new=0;use_new<2;use_new++) for(int skip=0;skip<6;skip++) {
        reset(use_new,0,1,0,1);
        if(skip==0) requests[0].thread=NULL;
        if(skip==1) threads[0].cpu_id=2;
        if(skip==2) mask_one(&threads[0].cpu_set,0);
        if(skip==3) mask_one(&threads[0].cpu_set,-1);
        if(skip==4) missing_target=1;
        if(skip==5) list_init(&cpus[0].migq);
        require(run_worker(0)==(skip==5?0:1)); require(wakes==(skip==5?0:1)&&!logs&&!ipis);
        require(irqstate==entry_irqstate); cases++;
    }
    /* Real mask word beyond bit63, with the target CPU supplied by the genuine ABI callback. */
    for(int use_new=0;use_new<2;use_new++) {
        reset(use_new,0,65,1,0); cpu_ids[2]=65; require(run_worker(0)==1); require_move(2,1); cases++;
    }
    /* Deterministic setter/migration interleaving: old CPU observation loses B;
     * reservation admission makes B observe the committed CPU and reach CPU2. */
    for(int use_new=0;use_new<2;use_new++) {
        reset(use_new,0,1,1,0); inject_writer=1; require(run_worker(0)==1); require_move(1,1);
        require(writer_done&&writer_cpu==(use_new?1:0));
        inject_writer=0; current_slot=writer_cpu;
        list_append(&cpus[current_slot].migq,&requests[0].list);
        require(run_worker(0)==1);
        if(use_new) require(threads[0].cpu_id==2&&CPU_ISSET(threads[0].cpu_id,&threads[0].cpu_set));
        else { require(threads[0].cpu_id==1&&!CPU_ISSET(threads[0].cpu_id,&threads[0].cpu_set)); legacy_stale++; }
        cases++;
    }
    printf("SOURCE36_CONTROLLED cases=%u legacy_stale=%u new_stale=0 ABI30\n",cases,legacy_stale);
    return 0;
}
