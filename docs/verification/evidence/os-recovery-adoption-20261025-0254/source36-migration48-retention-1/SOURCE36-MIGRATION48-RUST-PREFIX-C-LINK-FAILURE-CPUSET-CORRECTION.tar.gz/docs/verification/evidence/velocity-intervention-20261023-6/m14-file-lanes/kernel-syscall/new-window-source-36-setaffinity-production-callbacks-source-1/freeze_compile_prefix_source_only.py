"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Freeze source-only prefix. No compiler, observer, fixture or native execution.
"""
from pathlib import Path
import difflib, hashlib, json, sys

HERE=Path(__file__).resolve().parent
REPO=Path('/home/holden/mckernel')
KS=HERE.parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name, value):
    path=HERE/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream: stream.write(value)

# Install the exact local module next to the private parent, without touching
# canonical or accepted Source32 files. Header addition is a declaration only.
write('private-postimage/kernel/rust/f03_migration_mask_serialized_v3.rs',
      (HERE/'f03_migration_mask_serialized_v3.rs').read_text())
header=REPO/'kernel/include/sched_helpers.h'
old=header.read_text()
new=old.replace('int sched_do_migrate_body_result(',
    (HERE/'VERSIONED-MIGRATION-ABI.C.inc').read_text()+'\nint sched_do_migrate_body_result(',1)
write('private-postimage/kernel/include/sched_helpers.h',new)
patch=(HERE/'MIGRATION-MASK-AUTHORITY.DEFAULT-OFF.patch').read_text()
write('PRODUCTION-DECLARATION-AND-WORKER.DEFAULT-OFF.patch',patch+''.join(difflib.unified_diff(
    old.splitlines(True),new.splitlines(True),fromfile='a/kernel/include/sched_helpers.h',tofile='b/kernel/include/sched_helpers.h')))

fixture=json.loads((HERE/'EXACT-ORDINARY-RECIPE.SOURCE-ONLY.NOT-GRANTED.json').read_text())
prior=json.loads((KS/'new-window-source-32-setaffinity-lifetime/EXACT-SOURCE32-COMPILE-ONLY.NOT-GRANTED.json').read_text())
recipe=dict(scope=SCOPE,status='SOURCE_ONLY_SOURCE36_COMPILE_NOT_GRANTED',commands=fixture['commands'][:1],
    inputs=[pin(path) for path in sorted(HERE.rglob('*')) if path.is_file() and path.suffix in {'.rs','.inc','.c','.patch','.py'}],
    sources=[fixture['immutable_abi']],canonical_origins=[],
    header_bindings=[pin(Path(row['path'])) for row in fixture['header_bindings']],
    tools={key:pin(Path(row['path'])) for key,row in prior['tools'].items()},
    fixture_tools={key:pin(Path(row['path'])) for key,row in prior['fixture_tools'].items()},
    production_sources=[pin(REPO/'kernel/rust/sched_helpers.rs'),pin(REPO/'kernel/rust/process_helpers.rs'),
        pin(REPO/'kernel/rust/syscall_policy.rs'),pin(REPO/'kernel/process.c'),pin(REPO/'kernel/include/sched_helpers.h'),
        pin(REPO/'arch/x86_64/kernel/syscall.c')],
    resources=fixture['resources'],
    requires='Independent unsafe/ABI review and exact ROOT ordinary CPU0 compile-only grant. No suffix granted.',
    no_replay='No Source22/31/32 objects are compiled, linked or executed in this prefix; no fullcrate or native action.')
# Materialized production references are data provenance, not compiler inputs.
write('EXACT-SOURCE36-COMPILE-ONLY.NOT-GRANTED.json',json.dumps(recipe,indent=2)+'\n')
recipe_path=HERE/'EXACT-SOURCE36-COMPILE-ONLY.NOT-GRANTED.json'
runner=(KS/'new-window-source-32-setaffinity-lifetime/run_Source32_compile_once.NOT-GRANTED.py').read_text()
runner=runner.replace('Source32','Source36').replace('SOURCE32','SOURCE36').replace('source32','source36')
runner=runner.replace('4c714347cce3419e7e0fc0c9f0ce7fce7bddda66f04b3f2971daf61aeb401525',pin(recipe_path)['sha256'])
runner=runner.replace('focused setter real-ABI/accepted31core','migration mask/runqueue real-ABI')
runner=runner.replace('focused setter Rust object compile only','migration mask/runqueue Rust object compile only')
runner=runner.replace('PASS_FOCUSED_SOURCE36_SETAFFINITY_LIFETIME_COMPILE_ONLY','PASS_FOCUSED_SOURCE36_MIGRATION_MASK_SERIALIZATION_COMPILE_ONLY')
write('run_Source36_compile_once.NOT-GRANTED.py',runner)
runner_path=HERE/'run_Source36_compile_once.NOT-GRANTED.py'
ready=dict(scope=SCOPE,status='SOURCE_ONLY_NOT_REVIEWED_NOT_GRANTED',recipe=pin(recipe_path),runner=pin(runner_path),
    launch_argv=['/usr/bin/taskset','-c','0',sys.executable,str(runner_path)],
    production_patch=pin(HERE/'PRODUCTION-DECLARATION-AND-WORKER.DEFAULT-OFF.patch'),
    new_body=pin(HERE/'f03_migration_mask_serialized_v3.rs'),
    fixture=pin(HERE/'driver.c'),ABI_entries=30,planned_controlled_cases=48,
    original_stale_interleavings_expected=1,new_stale_interleavings_expected=0,
    no_actual_commands_run=True,all_selectors_OFF=True,
    holds=['Global mask readers/writers not assessed. Process eligibility stability unchanged.',
        'Exact selected migq->reservation->runqueue order still requires independent source review.',
        'No native IRQ/migration, runtime/default/fullcrate or C retirement acceptance.'])
write('READY-SOURCE36-COMPILE-PREFIX.NOT-GRANTED.json',json.dumps(ready,indent=2)+'\n')
write('ROOT-EXACT-SOURCE36-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',json.dumps(dict(
    scope=SCOPE,status='PREPARED_NOT_GRANTED',recipe=pin(recipe_path),runner=pin(runner_path),
    ready=pin(HERE/'READY-SOURCE36-COMPILE-PREFIX.NOT-GRANTED.json'),launch_argv=ready['launch_argv'],
    authority='ROOT must replace this data with an actual durable grant only after its ordinary slot release.'),indent=2)+'\n')
print(json.dumps(dict(ready=pin(HERE/'READY-SOURCE36-COMPILE-PREFIX.NOT-GRANTED.json'),recipe=pin(recipe_path),runner=pin(runner_path))))
