"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bind the actual retained Source36 object to C link + ABI30/48-case fixture only.
This preparation program never invokes a compiler, fixture, observer or subprocess.
"""
from pathlib import Path
import hashlib, json

HERE=Path(__file__).resolve().parent
REPO=Path('/home/holden/mckernel')
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
    path=Path(path); raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def identity(path):
    path=Path(path); value=path.stat()
    return dict(**pin(path),device=value.st_dev,inode=value.st_ino,uid=value.st_uid,
        gid=value.st_gid,mode=oct(value.st_mode&0o7777),nlink=value.st_nlink,
        mtime_ns=value.st_mtime_ns,ctime_ns=value.st_ctime_ns)
def write(name,value):
    with (HERE/name).open('x') as stream:
        if isinstance(value,str): stream.write(value)
        else: json.dump(value,stream,indent=2); stream.write('\n')

receipt_path=HERE/'ACTUAL-SOURCE36-COMPILE-FIRST-RESULT.json'
assert pin(receipt_path)['sha256']=='04ae635ddc3129f60b469f9a5c3f99947526b0b13d6ca65285b7ad033aaed23a'
receipt=json.loads(receipt_path.read_text())
assert receipt['status']=='PASS_FOCUSED_SOURCE36_MIGRATION_MASK_SERIALIZATION_COMPILE_ONLY'
assert receipt['compiler_commands']==1 and receipt['fixture_commands']==0
obj=receipt['actual_object']
assert pin(obj['path'])==obj and obj['bytes']==4624
assert obj['sha256']=='215618ab9fcb355611e5f5749b98632d573f11afd8b9c2bfde09edd324205b23'
join=receipt['records'][0]['join']
assert join['returncode']==0 and join['direct_child_joined'] and join['group_absent'] and join['closed_streams']
prefix_path=HERE/'EXACT-SOURCE36-COMPILE-ONLY.NOT-GRANTED.json'
prefix=json.loads(prefix_path.read_text())
for row in prefix['inputs']+prefix['sources']+prefix['header_bindings']:
    assert pin(row['path'])==row, row['path']

original_path=HERE/'EXACT-ORDINARY-RECIPE.SOURCE-ONLY.NOT-GRANTED.json'
original=json.loads(original_path.read_text())
commands=original['commands'][1:]
assert len(commands)==2
old_output=HERE/'fixture-output-1/fixture'
new_output=HERE/'fixture-suffix-output-1/migration-parity'
assert commands[0]['argv'].count(str(old_output))==1
commands[0]['argv']=[str(new_output) if value==str(old_output) else value for value in commands[0]['argv']]
assert commands[1]['argv']==[str(old_output)]
commands[1]['argv']=[str(new_output)]
assert commands[0]['argv'].count(obj['path'])==1
assert all('rustc' not in value for command in commands for value in command['argv'])
for path in [new_output.parent,HERE/'actual-migration-C-suffix-capture-first-1',HERE/'ACTUAL-SOURCE36-C-SUFFIX-FIRST-RESULT.json']:
    assert not path.exists(), str(path)

inputs={row['path']:row for row in prefix['inputs']+prefix['sources']}
extra=[Path(obj['path']),receipt_path,prefix_path,original_path,
    HERE/'OWNERSHIP-LOCK-ORDER-AND-NEXT-CHECK.md',HERE/'EXACT-SELECTED-PRODUCTION-REFERENCES.SOURCE.json',
    Path(join['captures']['stderr']['path']),Path(join['captures']['stdout']['path']),
    HERE/'actual-parity-capture-first-1/00-Rust-actual-old-and-private-new-migration-object/command.json',
    Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc')]
for path in extra: inputs[str(path)]=pin(path)
headers={row['path']:row for row in prefix['header_bindings']}
headers[str(REPO/'kernel/include/sched_helpers.h')]=pin(REPO/'kernel/include/sched_helpers.h')
tools=dict(prefix['tools'])
tools['gcc9']=pin('/usr/bin/gcc-9')
recipe=dict(scope=SCOPE,status='SOURCE_ONLY_RETAINED2156_C_SUFFIX_NOT_GRANTED',
    commands=commands,inputs=list(inputs.values()),sources=[],canonical_origins=[],
    header_bindings=list(headers.values()),tools=tools,
    fixture_tools={'cc1':pin('/usr/lib/gcc/x86_64-linux-gnu/9/cc1')},
    retained_identity=[identity(obj['path'])],actual_Rust=obj,actual_compiler_receipt=pin(receipt_path),
    original_recipe=pin(original_path),unchanged_driver=pin(HERE/'driver.c'),
    oracle_expected_stdout='SOURCE36_CONTROLLED cases=48 legacy_stale=1 new_stale=0 ABI30\n',
    controlled_cases=48,ABI_words=30,expected_original_stale_placements=1,new_stale_placements=0,
    oracle_status='Predicted fixture result until actual execution; source/interleaving diagnosis is not a native observation.',
    resources=original['resources'],root_grant=None,
    scope_holds=['No Rust compiler, accepted Source22/31/32 workload replay, fullcrate, native or canonical action.',
        'Controlled callback writer models only reservation-protected mask publication/CPU observation; no concurrent kernel proof.',
        'Global writers/readers, Process eligibility stability, hash admission and native lock ordering remain separate gates.'])
name='EXACT-SOURCE36-C-SUFFIX.FROZEN-NOT-GRANTED.json'
write(name,recipe)
recipe_pin=pin(HERE/name)
runner=(HERE.parent/'new-window-source-32-setaffinity-lifetime/run_Source32_C_suffix_once.NOT-GRANTED.py').read_text()
runner=runner.replace('Source32','Source36').replace('SOURCE32','SOURCE36').replace('source32','source36')
runner=runner.replace('add729601d40f4e0753bee0e8689f355cf20fc9cff7be40e6606c137f1e32558',recipe_pin['sha256'])
runner=runner.replace('actual07b2/reused31/fbd setter-only controlled C ABI/lifetime suffix','actual2156 retained-object migration ABI30/48-case C suffix')
runner=runner.replace('actual-setaffinity-C-suffix-capture-first-1','actual-migration-C-suffix-capture-first-1')
runner=runner.replace("authority='Exact durable ROOT Source36 C-only setter fixture link/run; reusebb154/fbd/typednegativeABI evidence with no getter/Rust/fullcrate/native/default actions.'",
    "authority='Exact durable ROOT Source36 C-only migration ABI30/48-case link/run reusing actual2156 object; no Rust/fullcrate/native/default actions.'")
runner=runner.replace("command['name'] == '02-controlled440pairs880calls-setter-mask-migration-lifetime'",
    "command['name'] == '02-controlled-migration-mask-publication-and-transfer'")
runner=runner.replace('controlled old/new lifetime oracle output differs','controlled migration serialization oracle output differs')
runner=runner.replace("status='PASS_SOURCE36_CONTROLLED440_PAIRS_ABI28_REUSED31_ABI22_LOOKUP12'",
    "status='PASS_SOURCE36_CONTROLLED48_MIGRATION_MASK_SERIALIZATION_ABI30'")
old="""actual_Rust=recipe['actual_Rust'], retained31=recipe['retained31_Rust'],
                      retained_lookup=recipe['retained_positive_lookup'],
                      actual_fixture=pin(OUTPUT / 'setaffinity-parity'), controlled_pairs=440,
                      controlled_calls=880, repaired_overflow_cases=20, ABI_words=28, reused_ABI_words=[22,12]"""
new="""actual_Rust=recipe['actual_Rust'], compiler_receipt=recipe['actual_compiler_receipt'],
                      actual_fixture=pin(OUTPUT / 'migration-parity'), controlled_cases=48,
                      original_stale_placements=1, new_stale_placements=0, ABI_words=30,
                      fixture_scope='Controlled protocol interleaving only; no native/concurrent-kernel acceptance'"""
assert runner.count(old)==1
runner=runner.replace(old,new)
write('run_Source36_C_suffix_once.NOT-GRANTED.py',runner)
runner_pin=pin(HERE/'run_Source36_C_suffix_once.NOT-GRANTED.py')
ready=dict(scope=SCOPE,status='SOURCE_ONLY_REQUIRES_INDEPENDENT_REVIEW_AND_ROOT_GRANT',
    recipe=recipe_pin,runner=runner_pin,retained_Rust=obj,retained_identity=recipe['retained_identity'],
    actual_compiler_receipt=pin(receipt_path),driver=pin(HERE/'driver.c'),
    output_absent=True,capture_absent=True,result_absent=True,controlled_cases=48,ABI_words=30,
    original_stale_placements_expected=1,new_stale_placements_expected=0,
    actual_suffix_commands=0,root_grant=None,native=False,production_default=False)
write('READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json',ready)
fields=json.loads((HERE.parent/'new-window-source-32-setaffinity-lifetime/ROOT-EXACT-SOURCE32-C-SUFFIX-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text())
fields.update(ready=pin(HERE/'READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json'),recipe=recipe_pin,runner=runner_pin,
    status='PREPARED_FIELDS_NOT_A_GRANT',root_grant=None,retained_Rust=obj,
    compiler_receipt=pin(receipt_path),controlled_cases=48,ABI_words=30)
fields['launch_argv'][-2]=runner_pin['path']; fields['launch_argv'][-1]=runner_pin['sha256']
write('ROOT-EXACT-SOURCE36-C-SUFFIX-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
print(json.dumps(dict(READY=fields['ready'],recipe=recipe_pin,runner=runner_pin,
    retained_object=obj,source_only=True,actual_suffix_commands=0)))
