"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Extract actual providers and create a private default-OFF successor. No execution.
"""
from pathlib import Path
import difflib, hashlib, json, re

HERE = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SOURCE = REPO / 'kernel/rust/sched_helpers.rs'
SCOPE = 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def write(name, value):
    path = HERE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(value)

def function(text, name):
    found = re.search(r'(?:pub(?:\([^)]*\))? )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(', text)
    assert found, name
    brace = text.index('{', found.end())
    depth, end = 1, brace + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[found.start():end]

source = SOURCE.read_text()
original = function(source, 'sched_do_migrate_body_result')
body = original.replace('sched_do_migrate_body_result(', 'sched_do_migrate_mask_serialized_v3(', 1)
body = body.replace('    current_cpu_addr: usize,', '    current_cpu_addr: usize,\n    reservation_lock_addr: usize,', 1)
body = body.replace('if current_cpu_addr == 0 || cpu_set_bits <= 0', 'if current_cpu_addr == 0 || reservation_lock_addr == 0 || cpu_set_bits <= 0', 1)
body = body.replace('let mut irqstate = unsafe { lock(migq_lock_addr) };', 'let migration_irqstate = unsafe { lock(migq_lock_addr) };', 1)
marker = '        let thread_cpu_id = unsafe {'
assert body.count(marker) == 1
body = body.replace(marker, '''        // One authority covers the live mask and its CPU/runqueue application.
        // No reference acquisition, usercopy, wait, log or IPI occurs in this scope.
        let mask_admission = ReservationAdmission {
            address: reservation_lock_addr,
            irqstate: unsafe { lock(reservation_lock_addr) },
            unlock,
        };
''' + marker, 1)
# Null-request branch precedes admission. Every other skip releases it before wakeup.
begin = body.index('        let mask_admission = ')
prefix, rest = body[:begin], body[begin:]
needle = '            unsafe {\n                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));'
assert rest.count(needle) == 4
rest = rest.replace(needle, '            drop(mask_admission);\n' + needle)
body = prefix + rest
body = body.replace('        irqstate = unsafe {\n            sched_double_rq_lock(', '        let runqueue_irqstate = unsafe {\n            sched_double_rq_lock(', 1)
marker = '\n        let moving_vm = unsafe {'
assert body.count(marker) == 1
body = body.replace(marker, '''
        // cpu_id and both runqueue memberships are now committed together.
        // A later setter observes the new CPU when enqueueing its own request.
        // Keep existing runqueue exclusion for VM bookkeeping, but release the
        // reservation authority before invoking any externally visible callback.
        drop(mask_admission);
''' + marker, 1)
body = body.replace('                irqstate,\n                offsets,', '                runqueue_irqstate,\n                offsets,', 1)
body = body.replace('unlock(migq_lock_addr, irqstate);', 'unlock(migq_lock_addr, migration_irqstate);', 1)
assert 'let mut irqstate' not in body
intro = '''// ''' + SCOPE + '''
use super::{CInt, CULong, SchedDoMigrateOffsets, SchedMigrateSpinLockFn,
    SchedMigrateSpinUnlockFn, SchedMigrateNoirqLockFn, SchedMigrateNoirqUnlockFn,
    SchedMigrateCpuLocalFn, SchedMigrateWaitqWakeupFn, SchedMigrateVectorFn,
    SchedMigrateInterruptFn, SchedDoMigrateLogFn, EINVAL, read_volatile,
    write_volatile, list_next, list_detach_poison_addr, cpu_set_isset_addr,
    sched_double_rq_lock, list_detach_counted_addr, list_add_tail_counted_addr,
    cpu_clear_bit_addr, cpu_set_bit_addr, sched_double_rq_unlock};

/// Own only the original reservation-lock acquisition; never a Thread borrow.
struct ReservationAdmission {
    address: usize,
    irqstate: CULong,
    unlock: SchedMigrateSpinUnlockFn,
}

impl Drop for ReservationAdmission {
    fn drop(&mut self) {
        // SAFETY: Construction follows the paired lock callback. Each path drops
        // once, before any wakeup, IPI, log, wait, reference release or usercopy.
        unsafe { (self.unlock)(self.address, self.irqstate) };
    }
}

/// Consume existing synchronous requests while serializing mask/CPU application.
///
/// # Safety
/// Original worker's live CPU/Thread/request/VM and exact-offset contracts apply.
/// Each request remains stack-live until its original wakeup/waitq_finish route.
/// The selected writer and this worker share the SAME reservation lock. Every
/// selected CPU/runqueue transfer must use the described reservation -> runqueue
/// order; no selected reservation owner may enqueue/wait for migration while
/// holding it. This worker nests migq -> reservation -> ordered runqueues and
/// releases reservation after transfer, before callbacks. Existing callbacks and
/// raw list helpers retain their ABI and exclusions. No Rust reference to kernel
/// mutable state spans a callback. Process-mask stability and unassessed writers
/// are prerequisites, not conclusions from this body.
#[no_mangle]
'''
write('f03_migration_mask_serialized_v3.rs', intro + body + '\n')
write('ACTUAL-OLD-MIGRATION-BODY.rs.inc', '#[no_mangle]\n' + original.replace('sched_do_migrate_body_result(', 'f36_original_migration(', 1) + '\n')

postimage = source
public = function(source, 'sched_do_migrate_public')
old_call = '        sched_do_migrate_body_result('
assert public.count(old_call) == 1
new_public = public.replace(old_call, '''        #[cfg(f03_migration_mask_serialized_v3)]
        let _ = sched_do_migrate_mask_serialized_v3;
        #[cfg(f03_migration_mask_serialized_v3)]
        sched_do_migrate_mask_serialized_v3(''', 1)
# Duplicate only the exact existing call expression for the OFF branch.
call_begin = public.index(old_call)
call_end = public.index('\n        )', call_begin) + len('\n        )')
old_expression = public[call_begin:call_end]
new_expression = old_expression.replace('sched_do_migrate_body_result(', 'sched_do_migrate_mask_serialized_v3(', 1)
new_expression = new_expression.replace('            current_cpu_addr,', '            current_cpu_addr,\n            core::ptr::addr_of_mut!(runq_reservation_lock) as usize,', 1)
new_public = public[:call_begin] + '        #[cfg(f03_migration_mask_serialized_v3)]\n        {\n' + new_expression + '\n        }\n        #[cfg(not(f03_migration_mask_serialized_v3))]\n        {\n' + old_expression + '\n        }' + public[call_end:]
postimage = postimage.replace(public, new_public, 1)
postimage += '''
#[cfg(all(f03_migration_mask_serialized_v3,
    not(all(f03_setaffinity_retained_v2, f03_sched_bridges_candidate,
        f02_positive_reference_lookup_candidate))))]
compile_error!("serialized migration requires retained setaffinity, Rust callbacks and positive lookup");
#[cfg(f03_migration_mask_serialized_v3)]
#[path = "f03_migration_mask_serialized_v3.rs"]
mod f03_migration_mask_serialized_v3;
#[cfg(f03_migration_mask_serialized_v3)]
pub use f03_migration_mask_serialized_v3::sched_do_migrate_mask_serialized_v3;
'''
write('private-postimage/kernel/rust/sched_helpers.rs', postimage)
write('MIGRATION-MASK-AUTHORITY.DEFAULT-OFF.patch', ''.join(difflib.unified_diff(
    source.splitlines(True), postimage.splitlines(True), fromfile='a/kernel/rust/sched_helpers.rs', tofile='b/kernel/rust/sched_helpers.rs')) + ''.join(difflib.unified_diff(
    [], (intro+body+'\n').splitlines(True), fromfile='/dev/null', tofile='b/kernel/rust/f03_migration_mask_serialized_v3.rs')))

types = '\n'.join(line for line in source.splitlines() if line.startswith('type SchedMigrate') or line.startswith('type SchedDoMigrate'))
start = source.index('#[repr(C)]\npub struct SchedDoMigrateOffsets')
end = source.index('\n#[repr(C)]', start + 1)
names = ['list_next', 'list_prev_addr', 'list_detach_poison_addr', 'list_add_tail_addr',
    'list_add_tail_counted_addr', 'list_detach_counted_addr', 'cpu_set_word',
    'cpu_set_isset_addr', 'cpu_set_bit_addr', 'cpu_clear_bit_addr',
    'sched_double_rq_lock', 'sched_double_rq_unlock']
write('ACTUAL-MIGRATION-TYPES-AND-HELPERS.rs.inc', types+'\n'+source[start:end]+'\n'+
    'const EINVAL:CInt=22; const LIST_POISON1:usize=0x0010_0129; const LIST_POISON2:usize=0x0020_0229;\n'+
    '\n\n'.join(function(source, name) for name in names)+'\n')
write('SOURCE-ORIGINS.json', json.dumps(dict(scope=SCOPE, status='SOURCE_ONLY_NO_CHECKS_RUN',
    actual_source=pin(SOURCE), new_body=pin(HERE/'f03_migration_mask_serialized_v3.rs'),
    private_postimage=pin(HERE/'private-postimage/kernel/rust/sched_helpers.rs'),
    exact_body_delta='New explicit reservation-address ABI; admission guard spans live mask selection through cpu_id/runqueue transfer; distinct outer/runqueue/VM IRQ tokens; all remaining work copied from actual Rust worker.',
    default_OFF=True, canonical_writes=False), indent=2)+'\n')
print('Source36 private default-OFF migration authority body prepared; no compiler or tests run.')
