Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source36 is private and default OFF. No compiler or fixture has run. Source32's
accepted setter, positive lookup reference, copy/error ordering and final release
remain unchanged. No accepted workload is replayed.

The existing worker selects a destination from live Thread.cpu_set without the
reservation lock used by the setter. Snapshotting and releasing before transfer
would leave this source-level interleaving: A selects CPU1 for a CPU0 thread; B
publishes CPU2-only and observes CPU0; A transfers to CPU1; B's CPU0 request skips
the now-CPU1 thread. This is a diagnosis pending regression, not a native failure.
The new worker shares reservation authority through destination selection and
CPU/runqueue transfer, so B observes the committed CPU1 for its subsequent request.
Concurrent setters retain existing last-publication semantics.

| Actual selected body | Ownership and exclusion | Source36 |
| --- | --- | --- |
| Source32 sched_setaffinity_retained_v2 | Current borrow or positive lookup edge survives copy/apply/synchronous migration | Exact accepted body unchanged; no relookup or redundant hold |
| syscall_policy sched_request_migrate_bridge | Borrows same live Thread address | Existing Rust callback unchanged |
| sched_request_migrate / sched_request_migrate_body_result | Stack request and wait entry; migq then runq; unlock before schedule/waitq_finish | Unchanged synchronous lifetime |
| sched_idle_iteration_body_result | Disables IRQs before migration callback | Unchanged |
| sched_do_migrate_public | Real offsets and Rust callback providers | Private cfg passes existing reservation-lock storage to versioned worker |
| New worker selection and CPU/list transfer | Migq, reservation, then ordered runqueues | Reservation guard drops on every skip and immediately after transfer |
| Existing VM/log/IPI/wakeup tail | Both runqueue locks stay held; VM mask has its own lock | Reservation already released; original order preserved |

The selected lock order is migq → reservation → ordered runqueues. Existing
sched_request_migrate_body_result uses migq → runqueue and releases migq before
schedule/wait. Source32 and clone-mask helpers release reservation before
migration enqueue or obtain_clone_cpuid. Existing release_cpuid, runq_add_thread
and x86 obtain_clone_cpuid use reservation → runqueue. No selected reservation
owner may enqueue or wait for migration while retaining reservation. No selected
runqueue owner may acquire reservation while retaining that runqueue. These
prerequisites require independent review; they are not global synchronization
claims. The new worker releases reservation while still holding runqueues and
does not reacquire it. Runqueue owners waiting behind reservation therefore do
not create a reverse acquisition in this worker.

The CPU-local callback does run inside reservation admission. Its actual Rust
provider process_sched_cpu_local_bridge only calls get_cpu_local_var and returns
the address. It must not enqueue, wait, log or acquire these locks. The remaining
providers already exist in Rust: spin/noirq wrappers call reviewed primitives;
waitq wrappers call existing Rust queues; schedule calls the existing scheduler;
vector/IPI and wakeup preserve their actual provider contracts. The worker's VM
mask lock, logging, IPI and wakeup calls still occur under original runqueue locks,
with reservation released. This patch adds no callback ABI or C computation.

The exported worker is explicitly versioned: sched_do_migrate_mask_serialized_v3
adds a reservation-address argument. The C declaration uses actual header types;
return is C int and IRQ tokens are full unsigned long. Separate outer-migq,
reservation, runqueue and VM saved tokens prevent nested-token substitution.
The actual idle caller enters IRQ-disabled; enabled-entry fixture vectors test
token pairing without claiming an observed native IRQ bug.

Small unsafe invariants: the synchronous request preserves the Thread edge and
request stack lifetime until original wakeup; the guard owns only one lock/token,
never a Thread borrow; it drops once on all admitted paths, before wakeup, logging,
IPI, wait, usercopy or reference release. Raw mutable kernel storage is accessed
without retaining Rust references across callbacks. CPU/list transfer commits
while reservation and both runqueue locks are held. No Thread access follows
the original wakeup.

Existing migration/request/idle C fallbacks remain inactive references under
their current Rust selection macros. Their presence is still C debt at whole-file
scope. Rust-owned runq_reservation_lock storage and all real callbacks are reused.
Source34/35 retain exclusive ownership of thread-hash writer work.

The minimal next check is the one Rust object command in
EXACT-SOURCE36-COMPILE-ONLY.NOT-GRANTED.json through its taskset-0 runner, after
independent review and ROOT grant. The separate three-command source-only recipe
prepares compile, genuine-header C link and one controlled fixture. ABI30 and
48 cases cover 16 move combinations, 16 missing-provider failures, 12 skipped or
empty requests, two high-word mask cases and two old/new setter interleavings.
It expects one original stale placement and zero new ones. The test writer models
only accepted Source32's locked mask publication/CPU observation, not its already
tested lookup/copy/reference machinery. No C or fixture suffix is granted.

Remaining gates: selected unsafe/lock review, compiler and controlled regression,
full-crate composition with accepted modules, strict ABI/link/ownership checks,
and separately released native migration. Process eligibility stability, other
live mask readers/writers, direct CPU-id writers, global hash acquisition and
current/Process lifetime remain explicit holds. No production default, whole-file,
native or C-retirement credit follows from this preparation.
