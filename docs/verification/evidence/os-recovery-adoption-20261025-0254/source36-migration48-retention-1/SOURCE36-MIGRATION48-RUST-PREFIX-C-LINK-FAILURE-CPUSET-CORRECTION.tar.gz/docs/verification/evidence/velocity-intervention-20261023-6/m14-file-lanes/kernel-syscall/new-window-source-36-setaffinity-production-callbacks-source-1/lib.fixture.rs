// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust/abi.rs"] mod abi;
use abi::{CInt,CULong,AbiListHead,Thread,Waitq,CpuLocalVar,ProcessVm,AddressSpace};
use core::ptr::{read_volatile,write_volatile};
use core::mem::{size_of,align_of,offset_of};
#[repr(C)]
struct SchedMigrateRequest {
    list: AbiListHead,
    thread: *mut Thread,
    wq: Waitq,
}
include!("ACTUAL-MIGRATION-TYPES-AND-HELPERS.rs.inc");
include!("ACTUAL-OLD-MIGRATION-BODY.rs.inc");
#[path="f03_migration_mask_serialized_v3.rs"] mod f03_migration_mask_serialized_v3;
#[no_mangle]
pub static f36_migration_Rust_ABI:[usize;30]=[
size_of::<Thread>(),
align_of::<Thread>(),
size_of::<CpuLocalVar>(),
align_of::<CpuLocalVar>(),
size_of::<SchedMigrateRequest>(),
align_of::<SchedMigrateRequest>(),
size_of::<SchedDoMigrateOffsets>(),
align_of::<SchedDoMigrateOffsets>(),
size_of::<CULong>(),
size_of::<CInt>(),
size_of::<abi::CpuSet>(),
size_of::<Option<SchedMigrateSpinLockFn>>(),
size_of::<Option<SchedMigrateCpuLocalFn>>(),
offset_of!(SchedMigrateRequest,list),
offset_of!(SchedMigrateRequest,thread),
offset_of!(SchedMigrateRequest,wq),
offset_of!(Thread,cpu_id),
offset_of!(Thread,tid),
offset_of!(Thread,cpu_set),
offset_of!(Thread,sched_list),
offset_of!(Thread,vm),
offset_of!(ProcessVm,address_space),
offset_of!(AddressSpace,cpu_set),
offset_of!(AddressSpace,cpu_set_lock),
offset_of!(CpuLocalVar,migq_lock),
offset_of!(CpuLocalVar,migq),
offset_of!(CpuLocalVar,runq_lock),
offset_of!(CpuLocalVar,runq),
offset_of!(CpuLocalVar,runq_len),
offset_of!(CpuLocalVar,flags)
];
