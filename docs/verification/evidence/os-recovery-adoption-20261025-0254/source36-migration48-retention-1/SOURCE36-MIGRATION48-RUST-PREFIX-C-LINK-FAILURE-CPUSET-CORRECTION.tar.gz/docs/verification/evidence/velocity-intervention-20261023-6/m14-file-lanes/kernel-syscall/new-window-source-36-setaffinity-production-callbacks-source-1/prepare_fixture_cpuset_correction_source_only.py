"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One bounded fixture provider correction after actual C link failure; source only.
"""
from pathlib import Path
import difflib, hashlib, json, re

OLD=Path(__file__).resolve().parent
NEW=OLD/'fixture-cpuset-provider-correction-1'
REPO=Path('/home/holden/mckernel')
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
    path=Path(path); raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
    with (NEW/name).open('x') as stream:
        if isinstance(value,str): stream.write(value)
        else: json.dump(value,stream,indent=2); stream.write('\n')

failure_path=OLD/'ACTUAL-SOURCE36-C-SUFFIX-FIRST-RESULT.json'
assert pin(failure_path)['sha256']=='b391c465738e0e37cd8c94c5bd8dbcc53d6b88dfdac97286783f865d73629fd6'
failure=json.loads(failure_path.read_text())
assert len(failure['records'])==1 and failure['records'][0]['join']['returncode']==1
assert failure['records'][0]['join']['direct_child_joined'] and failure['records'][0]['join']['group_absent']
assert failure['records'][0]['join']['closed_streams']
old_recipe_path=OLD/'EXACT-SOURCE36-C-SUFFIX.FROZEN-NOT-GRANTED.json'
recipe=json.loads(old_recipe_path.read_text())
assert pin(recipe['actual_Rust']['path'])==recipe['actual_Rust']
assert recipe['actual_Rust']['sha256']=='215618ab9fcb355611e5f5749b98632d573f11afd8b9c2bfde09edd324205b23'
for row in recipe['inputs']+recipe['sources']+recipe['header_bindings']:
    assert pin(row['path'])==row, row['path']
NEW.mkdir(mode=0o700)
helpers='''/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Fixture-only mask seeding/inspection over the genuine affinity.h layout.
 * This is not a replacement for production CPU_SET/CPU_ISSET exports.
 * The word/bit formula matches kernel/rust/affinity.rs CPU_SET_S/CPU_ISSET_S.
 */
_Static_assert(__builtin_offsetof(cpu_set_t,__bits)==0,"genuine cpuset word offset");
_Static_assert(sizeof(((cpu_set_t *)0)->__bits[0])==sizeof(unsigned long),"genuine cpuset word width");
_Static_assert(__builtin_types_compatible_p(__typeof__(((cpu_set_t *)0)->__bits[0]),__cpu_mask),"genuine cpuset element type");
_Static_assert(__NCPUBITS==64,"selected x86_64 cpuset word bits");
_Static_assert(sizeof(cpu_set_t)*8==CPU_SETSIZE,"genuine cpuset storage extent");
_Static_assert(_Alignof(cpu_set_t)==_Alignof(__cpu_mask),"genuine cpuset word alignment");
static unsigned long fixture_CPU_SET(unsigned long cpu,cpu_set_t *mask) {
    require(mask!=NULL&&cpu<CPU_SETSIZE);
    __cpu_mask bit=((__cpu_mask)1)<<(cpu%__NCPUBITS);
    mask->__bits[cpu/__NCPUBITS]|=bit;
    return mask->__bits[cpu/__NCPUBITS];
}
static int fixture_CPU_ISSET(unsigned long cpu,const cpu_set_t *mask) {
    require(mask!=NULL&&cpu<CPU_SETSIZE);
    __cpu_mask bit=((__cpu_mask)1)<<(cpu%__NCPUBITS);
    return (mask->__bits[cpu/__NCPUBITS]&bit)!=0;
}
'''
write('fixture_cpuset_bits.C.inc',helpers)
original=(OLD/'driver.c').read_text()
names=re.findall(r'\bCPU_(?:SET|ISSET)\s*\(',original)
assert len(names)==5 and names.count('CPU_SET(')==1 and names.count('CPU_ISSET(')==4
corrected=re.sub(r'\b(CPU_SET|CPU_ISSET)\b',r'fixture_\1',original)
marker='extern const unsigned long f36_migration_Rust_ABI[30];'
assert corrected.count(marker)==1
include='#include "fixture_cpuset_bits.C.inc"\n'
corrected=corrected.replace(marker,include+marker,1)
# Apart from the new helper include and five provider identifiers, byte equality
# authenticates all 48 cases, every original require predicate, constants and text.
normalized=corrected.replace(include,'',1).replace('fixture_CPU_SET','CPU_SET').replace('fixture_CPU_ISSET','CPU_ISSET')
assert normalized==original
write('driver.c',corrected)
copies=[]
for name in ['ACTUAL-MIGRATION-REQUEST.C.inc','VERSIONED-MIGRATION-ABI.C.inc','ACTUAL-MIGRATION-ABI.C.inc']:
    write(name,(OLD/name).read_text())
    assert (NEW/name).read_bytes()==(OLD/name).read_bytes()
    copies.append(dict(original=pin(OLD/name),successor=pin(NEW/name)))
write('FIXTURE-ONLY-CPUSET-PROVIDER.patch',''.join(difflib.unified_diff(original.splitlines(True),corrected.splitlines(True),
    fromfile=str(OLD/'driver.c'),tofile=str(NEW/'driver.c')))+''.join(difflib.unified_diff([],helpers.splitlines(True),
    fromfile='/dev/null',tofile=str(NEW/'fixture_cpuset_bits.C.inc'))))
old_output=OLD/'fixture-suffix-output-1/migration-parity'
new_output=NEW/'fixture-suffix-output-1/migration-parity'
commands=recipe['commands']
assert commands[0]['argv'].count(str(OLD/'driver.c'))==1
assert commands[0]['argv'].count(str(old_output))==1
commands[0]['argv']=[str(NEW/'driver.c') if value==str(OLD/'driver.c') else str(new_output) if value==str(old_output) else value for value in commands[0]['argv']]
assert '-Werror=implicit-function-declaration' not in commands[0]['argv']
flag_index=commands[0]['argv'].index('-Werror=incompatible-pointer-types')+1
commands[0]['argv'].insert(flag_index,'-Werror=implicit-function-declaration')
assert commands[1]['argv']==[str(old_output)]
commands[1]['argv']=[str(new_output)]
for command in commands: command['cwd']=str(NEW)
inputs={row['path']:row for row in recipe['inputs']}
extra=[failure_path,old_recipe_path,OLD/'driver.c',OLD/'ROOT-EXACT-SOURCE36-C-SUFFIX-GRANT.json',
    OLD/'READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json',OLD/'run_Source36_C_suffix_once.NOT-GRANTED.py',
    Path(failure['records'][0]['join']['captures']['stderr']['path']),
    REPO/'kernel/include/affinity.h',REPO/'kernel/rust/affinity.rs',Path(__file__)]
extra += list(NEW.iterdir())
for path in extra: inputs[str(path)]=pin(path)
headers={row['path']:row for row in recipe['header_bindings']}
headers[str(REPO/'kernel/include/affinity.h')]=pin(REPO/'kernel/include/affinity.h')
recipe.update(status='SOURCE_ONLY_ONE_BOUNDED_FIXTURE_CPUSET_PROVIDER_CORRECTION_NOT_GRANTED',
    commands=commands,inputs=list(inputs.values()),header_bindings=list(headers.values()),root_grant=None,
    original_failure=pin(failure_path),original_recipe=pin(old_recipe_path),unchanged_driver=None,
    original_driver=pin(OLD/'driver.c'),corrected_driver=pin(NEW/'driver.c'),
    bounded_correction='Five fixture calls now use typed helpers over genuine __bits; add only fixture -Werror=implicit-function-declaration; no production/Rust/assertion/oracle change.',
    normalized_driver_byte_identical=True,existing_require_predicates_unchanged=True,
    exact_metadata_copies=copies)
name='EXACT-SOURCE36-C-SUFFIX.FROZEN-NOT-GRANTED.json'
write(name,recipe)
recipe_pin=pin(NEW/name)
runner=(OLD/'run_Source36_C_suffix_once.NOT-GRANTED.py').read_text()
old_sha=pin(old_recipe_path)['sha256']
assert runner.count(old_sha)==1
runner=runner.replace(old_sha,recipe_pin['sha256'],1)
write('run_Source36_C_suffix_once.NOT-GRANTED.py',runner)
runner_pin=pin(NEW/'run_Source36_C_suffix_once.NOT-GRANTED.py')
ready=dict(scope=SCOPE,status='SOURCE_ONLY_ONE_BOUNDED_FIXTURE_CORRECTION_REQUIRES_REVIEW_AND_ROOT_GRANT',
    recipe=recipe_pin,runner=runner_pin,retained_Rust=recipe['actual_Rust'],retained_identity=recipe['retained_identity'],
    actual_compiler_receipt=recipe['actual_compiler_receipt'],original_failure=pin(failure_path),
    driver=pin(NEW/'driver.c'),helpers=pin(NEW/'fixture_cpuset_bits.C.inc'),
    normalized_driver_byte_identical=True,controlled_cases=48,ABI_words=30,oracle_expected_stdout=recipe['oracle_expected_stdout'],
    root_grant=None,actual_suffix_commands=0,output_absent=True,capture_absent=True,result_absent=True,
    production_body_unchanged=True,Rust_recompilations=0,native=False,production_default=False)
write('READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json',ready)
fields=json.loads((OLD/'ROOT-EXACT-SOURCE36-C-SUFFIX-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text())
fields.update(ready=pin(NEW/'READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json'),recipe=recipe_pin,runner=runner_pin,root_grant=None,
    status='PREPARED_FIELDS_NOT_A_GRANT')
fields['launch_argv'][-2]=runner_pin['path'];fields['launch_argv'][-1]=runner_pin['sha256']
write('ROOT-EXACT-SOURCE36-C-SUFFIX-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
write('CORRECTION-AND-UNCHANGED-ORACLE.SOURCE.json',dict(scope=SCOPE,status='SOURCE_ONLY_NO_COMMANDS_RUN',
    failure_family='Declared affinity function providers absent from focused fixture link. Genuine affinity.h exports declarations, not macros.',
    original_failure=pin(failure_path),original_driver=pin(OLD/'driver.c'),corrected_driver=pin(NEW/'driver.c'),
    normalized_driver_byte_identical=True,provider_identifiers_replaced=5,production_body_unchanged=True,
    fixture_flag_delta=['-Werror=implicit-function-declaration'],
    flag_explanation='This additional compile gate catches future undeclared names; actual original failure was absent definitions of declared CPU_SET/CPU_ISSET.',
    header=pin(REPO/'kernel/include/affinity.h'),actual_Rust_formula_reference=pin(REPO/'kernel/rust/affinity.rs'),
    metadata_copies=copies,retained_Rust=recipe['actual_Rust'],next='Independent source review and fresh ROOT C-only grant; no further same-family automatic correction.'))
print(json.dumps(dict(READY=fields['ready'],recipe=recipe_pin,runner=runner_pin,source_only=True,actual_commands=0)))
