Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

The actual focused Rust compile is retained in
ACTUAL-SOURCE36-COMPILE-FIRST-RESULT.json, SHA256
04ae635ddc3129f60b469f9a5c3f99947526b0b13d6ca65285b7ad033aaed23a.
It produced candidate.o, 4624 bytes, SHA256
215618ab9fcb355611e5f5749b98632d573f11afd8b9c2bfde09edd324205b23.
The original source-only lockmap predates that compile; its historical statement
that no compiler ran is superseded by this additive result reference. Its lock,
lifetime and remaining-production-gate discussion is unchanged. No C suffix ran.

The new suffix reuses that exact object and compiler receipt, with full inode,
device, mode, ownership, size, hash and timestamp identity checks before and after
the sequence. It contains two commands: genuine-header C link, then one controlled
fixture execution. It has zero Rust/full-crate commands and replays no accepted
Source22, Source31 or Source32 workload.

The original driver, body, helper extracts, versioned declaration, ABI metadata
and all assertions remain byte-identical to the compiled prefix. The callback
types come from the genuine sched_helpers.h; the request definition is extracted
from actual process.c. The fixture compares 30 C/Rust layout/type-width values and
48 cases. Expected stdout is exactly:

```
SOURCE36_CONTROLLED cases=48 legacy_stale=1 new_stale=0 ABI30
```

That is an expected controlled result, not an observation. The two-setter case
models reservation-protected mask publication and CPU observation at the first
runqueue acquisition. For the new body, publication waits until reservation
release after CPU/list transfer; the modeled second request then addresses the
new CPU. For the old body, publication observes the old CPU and the second request
takes the existing wrong-CPU skip. The test does not simulate usercopy, lookup,
reference lifetime, a native scheduler or arbitrary simultaneous CPUs.

READY-SOURCE36-C-SUFFIX.NOT-GRANTED.json binds the frozen two-command recipe and
runner. The prepared grant fields explicitly contain root_grant=null. The runner
requires a separate actual durable ROOT grant, preserves first failure, never
retries, retains raw captures and joins, and enforces the existing one-job CPU0,
2GiB/60CPU/90+6wall/32MiBfile/FD256/2MiBstack/core0 profile and fresh floors.
The exact outer launch uses taskset, -c, 0 as separate argv entries. All suffix
output, capture and result paths were absent at preparation. Independent review
received the exact tuple; source preparation supplies no execution release.

Full-crate composition, strict production ABI/link ownership, global writer and
reader coverage, Process eligibility stability and native migration remain open.
Selectors remain OFF; canonical and previously accepted files remain unchanged.
