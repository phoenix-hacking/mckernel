#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual whole-object ownership and relocation qualification; no object execution.
"""
import ast
import hashlib
import json
import struct
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
recipe = json.loads((root / 'EXACT-RETAINED-WHOLE-RUST-OBSERVER-CORRECTION.NOT-GRANTED.json').read_text())

def pinned_bytes(row):
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    return raw

elf_row = recipe['Elf_source']
elf_source = pinned_bytes(elf_row)
selected = [node for node in ast.parse(elf_source).body
            if isinstance(node, (ast.Import, ast.ImportFrom))
            or isinstance(node, ast.ClassDef) and node.name == 'Elf'
            or isinstance(node, ast.FunctionDef) and node.name in {'object_bytes', 'owning_relocations'}]
namespace = {'Path': Path, 'struct': struct}
exec(compile(ast.Module(body=selected, type_ignores=[]), elf_row['path'], 'exec'), namespace)
metadata_row = recipe['qualified_descriptor_helper']
metadata_source = pinned_bytes(metadata_row)
selected = [node for node in ast.parse(metadata_source).body
            if isinstance(node, ast.FunctionDef) and node.name in {'cstring', 'descriptor'}]
exec(compile(ast.Module(body=selected, type_ignores=[]), metadata_row['path'], 'exec'), namespace)
Elf = namespace['Elf']
object_bytes = namespace['object_bytes']
owning_relocations = namespace['owning_relocations']
descriptor = namespace['descriptor']
old = Elf(Path(recipe['actual_old_Rust_object']['path']))
new_path = Path(recipe['new_Rust_object_path'])
new = Elf(new_path)

def function(elf, name):
    rows = [row for row in elf.symbols if row['name'] == name and row['shndx'] != 0]
    assert len(rows) == 1 and rows[0]['bind'] == 1 and rows[0]['type'] == 2
    symbol = rows[0]
    assert 0 < symbol['shndx'] < len(elf.sections)
    assert symbol['size'] > 0 and elf.sections[symbol['shndx']]['flags'] & 6 == 6
    return symbol

def undefined(elf):
    return {row['name'] for row in elf.symbols if row['name'] and row['shndx'] == 0}

def panic_targets(elf, symbol):
    return [row['target']['name'] for row in owning_relocations(elf, symbol)
            if any(part in row['target']['name'] for part in
                   ('panic_const', 'panicking', 'rust_begin_unwind', 'panic_fmt'))]

old_handler = function(old, 'move_pages_smp_handler')
new_handler = function(new, 'move_pages_smp_handler')
original_panics = panic_targets(old, old_handler)
assert len(original_panics) == 2
assert any('panic_const_div_by_zero' in name for name in original_panics)
assert any('panic_const_div_overflow' in name for name in original_panics)
assert not panic_targets(new, new_handler)
assert undefined(new) == undefined(old) - set(original_panics), 'unexpected whole-object import change'
assert not any('panic_const_div_by_zero' in name or 'panic_const_div_overflow' in name
               for name in undefined(new))

logger_function = function(new, 'arch_process_vm_rw_log_bridge')
logger_code_relocations = owning_relocations(new, logger_function)
policy = Path(recipe['candidate_policy']['path'])
policy_lines = policy.read_text().splitlines()
markers = ['F06_PROCESS_VM_IOV_LOCAL_DEBUG', 'F06_PROCESS_VM_IOV_REMOTE_DEBUG',
           'F06_PROCESS_VM_FOUND_DEBUG', 'F06_PROCESS_VM_COPY_DEBUG']
logger_proof = {}
for marker in markers:
    previous = [row for row in old.symbols if marker in row['name'] and row['type'] == 1]
    assert len(previous) == 1 and previous[0]['bind'] == 1, 'original GLOBAL defect control'
    symbols = [row for row in new.symbols if marker in row['name'] and row['type'] == 1]
    assert len(symbols) == 1
    symbol = symbols[0]
    assert symbol['bind'] == 0 and symbol['size'] == 32
    assert 0 < symbol['shndx'] < len(new.sections)
    other_offset = new.table['offset'] + symbol['index'] * new.table['entsize'] + 5
    assert new.raw[other_offset] == 0, 'LOCAL logger visibility must remain DEFAULT0'
    overlaps = [row for row in new.symbols if row['type'] == 1
                and row['shndx'] == symbol['shndx'] and row['size']
                and max(row['value'], symbol['value']) <
                min(row['value'] + row['size'], symbol['value'] + symbol['size'])]
    assert len(overlaps) == 1, 'duplicate or overlapping logger storage'
    starts = [index for index, line in enumerate(policy_lines) if 'static mut ' + marker + ':' in line]
    assert len(starts) == 1
    start = starts[0]
    # The next compact logger may start within ten lines; only this exact
    # named initializer owns the line! value used by its descriptor contract.
    end = next(index for index in range(start, len(policy_lines))
               if policy_lines[index].strip() == '};')
    source_lines = [index + 1 for index in range(start, end + 1)
                    if 'line_flags: line!()' in policy_lines[index]]
    assert len(source_lines) == 1
    record = descriptor(new, symbol, str(policy), 'arch_process_vm_rw_log_bridge', source_lines[0])
    consumers = []
    for relocation in logger_code_relocations:
        target = relocation['target']
        if target['shndx'] != symbol['shndx']:
            continue
        address = target['value'] + relocation['addend']
        if symbol['value'] <= address < symbol['value'] + symbol['size']:
            assert relocation['type'] == 1, 'actual large-model data reference must retain 64-bit ABI'
            consumers.append(relocation)
    assert consumers, 'no actual logger callback instruction edge'
    logger_proof[marker] = {'record': record, 'callback_consumer_relocations': consumers}

result = {
    'scope': recipe['scope'],
    'status': 'PASS_ACTUAL_DEFAULT_WHOLE_RUST_HANDLER_NO_PANIC_AND_FOUR_LOCAL_LOGGERS',
    'new_Rust_object': {'path': str(new_path), 'bytes': new_path.stat().st_size,
                        'sha256': hashlib.sha256(new_path.read_bytes()).hexdigest()},
    'old_handler': old_handler, 'new_handler': new_handler,
    'removed_original_panic_imports': original_panics,
    'whole_undefined_set_exact_except_removed_panics': True,
    'logger_callback': logger_function, 'logger_proof': logger_proof,
    'actual_default_flags_without_explicit_codegen_units': True,
    'canonical_edits': 0, 'partial_or_final_link_validated': False, 'native': False,
}
with (root / 'ACTUAL-DEFAULT-CORRECTED-WHOLE-RUST-OWNERSHIP.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print('PASS actual-default wholeRust move-handler panicRELA0 removed2 imports-exact fourLOCAL32/DEFAULT0/bytes/RELA/callback-consumers no-CGU-override')
