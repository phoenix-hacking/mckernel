/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
extern int f03_ptrace_pending_snapshot_take_locked_v1(struct thread *,int,struct siginfo *,void **);
extern const unsigned long f03_pending_lock_Rust_ABI[17];
extern int printf(const char *,...);
extern int dprintf(int,const char *,...);
extern void abort(void);
#define require(v) do{if(!(v)){dprintf(2,"FAIL pending lock line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
static struct thread target;
static struct sig_common common;
static struct sig_pending first,second,transfer_node;
static int held,transfer_schedule,locks,unlocks,transfers,alias_mode;
static unsigned long active_node;
static int first_live,second_live,transfer_live;
const unsigned long f03_pending_lock_C_ABI[17]={
 sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,sigcommon),__builtin_offsetof(struct thread,ptrace_sendsig),__builtin_offsetof(struct thread,ptrace_recvsig),
 sizeof(struct sig_common),__alignof__(struct sig_common),__builtin_offsetof(struct sig_common,lock),
 sizeof(struct sig_pending),__alignof__(struct sig_pending),__builtin_offsetof(struct sig_pending,info),
 sizeof(struct siginfo),__alignof__(struct siginfo),sizeof(struct mcs_rwlock_lock),__alignof__(struct mcs_rwlock_lock),
 sizeof(struct mcs_rwlock_node_irqsave),__alignof__(struct mcs_rwlock_node_irqsave)};
/* Genuine C header function type bindings. These are controlled HOST providers,
 * not real IRQ/spin execution. Production Rust uses the same existing exports. */
void (*const f03_actual_MCS_lock_signature)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)=__mcs_rwlock_writer_lock;
void (*const f03_actual_MCS_unlock_signature)(struct mcs_rwlock_lock *,struct mcs_rwlock_node_irqsave *)=__mcs_rwlock_writer_unlock;
static void release_slot(struct sig_pending *p){if(!p)return;if(p==&first){require(first_live);first_live=0;}else if(p==&second){require(second_live);second_live=0;}else{require(p==&transfer_node&&transfer_live);transfer_live=0;}}
static void selected_transfer(void){
 /* Same ownership order as the existing do_signal transfer, participating in
  * common.lock. Distinct-node domain only; aliased-node free remains held. */
 require(!held&&!alias_mode&&transfers==0);transfers++;
 release_slot(target.ptrace_recvsig);target.ptrace_recvsig=&transfer_node;
 release_slot(target.ptrace_sendsig);target.ptrace_sendsig=NULL;transfer_live=1;
}
void __mcs_rwlock_writer_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){require(lock==&common.lock&&!held&&node&&!((unsigned long)node%__alignof__(*node)));if(transfer_schedule==1&&!alias_mode)selected_transfer();held=1;locks++;active_node=(unsigned long)node;*(unsigned long *)node=0x5a391;}
void __mcs_rwlock_writer_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){require(lock==&common.lock&&held&&(unsigned long)node==active_node&&*(unsigned long *)node==0x5a391);held=0;active_node=0;unlocks++;if(transfer_schedule==2&&!alias_mode)selected_transfer();}
static void reset(int mode,int plan,unsigned char pattern){
 memset(&target,0,sizeof(target));memset(&common,0,sizeof(common));
 /* Explicit byte initialization uses builtin HOST memset only for controlled
  * data patterns; all genuine typed structures/offsets remain header-owned. */
 __builtin_memset(&first,pattern,sizeof(first));__builtin_memset(&second,pattern+1,sizeof(second));__builtin_memset(&transfer_node,pattern+2,sizeof(transfer_node));
 target.sigcommon=&common;target.ptrace_sendsig=(mode==1||mode==3||mode==4)?&first:NULL;target.ptrace_recvsig=mode==2?&first:mode==3?&second:mode==4?&first:NULL;
 alias_mode=mode==4;held=locks=unlocks=transfers=0;active_node=0;transfer_schedule=plan;first_live=second_live=1;transfer_live=0;
}
int main(void){
 require(!memcmp(f03_pending_lock_C_ABI,f03_pending_lock_Rust_ABI,sizeof(f03_pending_lock_C_ABI)));
 unsigned tested=0;for(int mode=0;mode<5;mode++)for(int source=1;source<=2;source++)for(int plan=0;plan<3;plan++)for(int pattern=0;pattern<3;pattern++){
  reset(mode,plan,0x31+pattern);struct siginfo snapshot,before;__builtin_memset(&snapshot,0xcc,sizeof(snapshot));before=snapshot;
  struct sig_pending *expected=source==1?target.ptrace_sendsig:target.ptrace_recvsig;
  if(plan==1&&!alias_mode)expected=source==2?&transfer_node:NULL;
  void *detached=(void *)0x1;int rc=f03_ptrace_pending_snapshot_take_locked_v1(&target,source,&snapshot,&detached);
  require(locks==1&&unlocks==1&&!held&&!active_node);
  if(alias_mode){require(rc==2&&!detached&&!memcmp(&snapshot,&before,sizeof(snapshot)));require(target.ptrace_sendsig==&first&&target.ptrace_recvsig==&first);}
  else if(!expected){require(rc==0&&!detached&&!memcmp(&snapshot,&before,sizeof(snapshot)));}
  else {
   require(rc==1&&detached==expected&&!memcmp(&snapshot,&expected->info,sizeof(snapshot)));
   if(expected==&first)require(first_live);else if(expected==&second)require(second_live);else require(expected==&transfer_node&&transfer_live);
   /* Detachment transfers ownership; simulated caller retires after lock release.
    * The queued transfer cannot retire a node absent from its published slots. */
   release_slot(expected);
  }
  tested++;
 }
 require(tested==90);printf("PASS existing sigcommon MCS snapshot-detach cases90 ABI17 controlled-before/after-transfer alias-held no-native-serialization-credit\n");return 0;
}
