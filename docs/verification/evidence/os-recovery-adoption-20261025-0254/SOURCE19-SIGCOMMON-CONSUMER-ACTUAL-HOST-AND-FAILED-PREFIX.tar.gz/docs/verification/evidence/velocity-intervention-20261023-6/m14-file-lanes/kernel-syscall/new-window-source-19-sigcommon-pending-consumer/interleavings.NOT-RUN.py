#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Finite defined state models; no kernel threads, native pointers or OS acceptance.
"""
from itertools import permutations

def merges(first, second):
    if not first:
        yield second
    elif not second:
        yield first
    else:
        for tail in merges(first[1:], second):
            yield first[:1] + tail
        for tail in merges(first, second[1:]):
            yield second[:1] + tail

serialized = blocked = 0
for events in merges(('CL', 'CT', 'CU'), ('WL', 'WT', 'WU')):
    lock = None
    valid = True
    for event in events:
        actor, phase = event
        if phase == 'L':
            if lock is not None:
                valid = False
                break
            lock = actor
        elif phase == 'T':
            assert lock == actor
        else:
            assert lock == actor
            lock = None
    if valid:
        assert lock is None
        serialized += 1
    else:
        blocked += 1
assert (serialized, blocked) == (2, 18)

legacy_safe = legacy_hazard = 0
for events in merges(('CAPTURE', 'USE'), ('TRANSFER',)):
    slot = 'old'
    borrowed = None
    live = {'old'}
    for event in events:
        if event == 'CAPTURE':
            borrowed = slot
        elif event == 'TRANSFER':
            live.remove(slot)
            live.add('new')
            slot = 'new'
        elif borrowed in live:
            legacy_safe += 1
        else:
            legacy_hazard += 1
assert (legacy_safe, legacy_hazard) == (2, 1)

results = []
for detach in (False, True):
    valid = hazards = 0
    for events in merges(('LOCK', 'CAPTURE', 'UNLOCK', 'USE'), ('TRANSFER',)):
        slot = 'old'
        borrowed = None
        live = {'old'}
        held = False
        blocked_schedule = False
        for event in events:
            if event == 'LOCK':
                held = True
            elif event == 'UNLOCK':
                held = False
            elif event == 'CAPTURE':
                assert held
                borrowed = slot
                if detach:
                    slot = None
            elif event == 'TRANSFER':
                if held:
                    blocked_schedule = True
                    break
                if slot is not None:
                    live.remove(slot)
                live.add('new')
                slot = 'new'
            elif event == 'USE':
                hazards += borrowed not in live
        if not blocked_schedule:
            valid += 1
    results.append((valid, hazards))
assert results == [(3, 1), (3, 0)]

# A retained tracee reference or equal raw slot pointer does not pin a pending
# allocation/version across faulting copy. This is a defined integer model only.
old_identity, old_generation = 0x1000, 1
replacement_identity, replacement_generation = 0x1000, 2
assert old_identity == replacement_identity
assert old_generation != replacement_generation
print('PASS pending interleavings serialized2 blocked18 legacy-hazard1 borrowed-after-unlock-hazard1 detach-hazard0 pointer-equal-ABA-held model-only')
