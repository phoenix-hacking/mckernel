// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
mod lock_helpers {
 use crate::abi::CULong;
 pub use crate::abi::McsRwlockLock;
#[repr(C, align(64))]
pub struct McsRwlockNodeIrqsave {
    irqsave: CULong,
}
 unsafe extern "C" {
  pub fn __mcs_rwlock_writer_lock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
  pub fn __mcs_rwlock_writer_unlock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
 }
}
include!("sigcommon_snapshot_take.RUST-FRAGMENT.rs.inc");
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f03_pending_lock_Rust_ABI:[usize;17]=[size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,sigcommon),offset_of!(abi::Thread,ptrace_sendsig),offset_of!(abi::Thread,ptrace_recvsig),size_of::<abi::SigCommon>(),align_of::<abi::SigCommon>(),offset_of!(abi::SigCommon,lock),size_of::<abi::SigPending>(),align_of::<abi::SigPending>(),offset_of!(abi::SigPending,info),size_of::<abi::SigInfo>(),align_of::<abi::SigInfo>(),size_of::<abi::McsRwlockLock>(),align_of::<abi::McsRwlockLock>(),size_of::<lock_helpers::McsRwlockNodeIrqsave>(),align_of::<lock_helpers::McsRwlockNodeIrqsave>()];
