Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Actual existing shared authority is thread.sigcommon->lock. The selected Rust
arch_do_signal_default_pending_transfer_result runs under this original MCS writer
lock, frees old recvsig, publishes detached incoming pending, frees old sendsig,
clears sendsig, then releases that same lock/IRQ-save node. This is an existing
shared lock, not a newly invented pending mutex. process.update_lock protects
ptrace trace-syscall flag mutation but is released before pending take/copy/free.
find_thread holds a tracee reference after releasing its hash lock; thread_unlock
releases that reference and does not serialize pending state.

This separate private successor implements one substantive internal consumer
primitive: f03_ptrace_pending_snapshot_take_locked_v1. It acquires the genuine
sigcommon MCS writer export with the existing typed MCS IRQ-save node, snapshots
all initialized selected info bytes and clears the selected slot WHILE holding
that lock, transfers the detached node to its caller, then releases the lock.
No allocation, usercopy, do_kill, scheduler action or free occurs in this critical
section. No lock-node pointer survives return. The caller can use the initialized
snapshot and retire the detached node after unlocking, provided all participants
honor this lock and nodes are uniquely owned. Both are explicit safety obligations.

The internal result is NONE/TAKEN/HELD_ALIAS; these codes are NOT errno or ptrace
syscall results. Aliased send/receive slots are refused without reading info,
detaching or freeing either slot. No syscall adaptation or selector is emitted:
whole callback selection and aliased-consumer behavior remain held. Actual thread
and sigcommon lifetime must be retained by the eventual caller. This primitive
does not assert that a thread reference alone pins an arbitrary pending node.

The concrete integration blocker remains at the producer boundary. Wrapping the
entire accepted v2 transaction with sigcommon lock would hold an IRQ-save lock
across faulting copy_from_user and is not a valid integration. Splitting it around
copy requires a real commit authority after reacquisition. Existing code has no
pending-node refcount, publication generation or transaction epoch. Raw pointer
identity and tracee reference do not provide that authority: another participating
transfer can free/reallocate the same address during unlocked copy. No generation
or node pin exists in the selected interfaces to distinguish that ABA. Other
getsiginfo and destruction paths still read/free pending state without the same
ongoing lock. A local consumer lock cannot protect against those participants.

Therefore the producer cannot yet be coherently selected by a two-call wrapper.
A real repair needs an independently agreed commit contract plus actual shared
participant changes: stage outside IRQ lock, use a real version/pin or explicitly
reviewed commit-against-current-state contract after reacquiring it, and cover
producer/getter/take/transfer/final destruction consistently. None of those
contracts is inferred from the HOST exclusive-owner fixture. No source-only
port or unchanged deterministic rerun is offered as a substitute.

Prepared smallest actual consumer check:17 C/Rust geometry words for genuine
Thread/SigCommon/SigPending/SigInfo/MCS lock/node plus exact C header bindings to
__mcs_rwlock_writer_lock/unlock. A controlled HOST fixture runs90 cases across
five slot states, two source choices, transfer before acquisition/after release,
and three initialized payloads. It checks balanced same-node lock ownership,
actual snapshot bytes, detachment, no-free-of-detached-node by later transfer,
and explicit alias hold. MCS providers are controlled HOST endpoints; this is
ABI/consumer behavior qualification, not native IRQ or multicore acceptance.

The finite interleaving regression separately records the old capture/transfer/use
hazard, why releasing a lock before using a still-published borrowed node remains
unsafe, why detach-before-unlock removes that model hazard, why a writer ignoring
the lock remains outside the protocol, and why pointer equality cannot detect a
modeled ABA generation change. No actual freed memory is read by this regression.

Exact proposed check tuple: compile private Rust object; link genuine-header C
consumer driver; run90cases/ABI17; run the finite interleaving regression. Independent
review and a fresh ordinary CPU0 grant are required. Existing h990/AS2G/sharedCPU60/
wall90+6/F32/FD256/stack2M/core0/floors remain. No compiler/runtime/model/root/native
operation has been executed for this successor. Accepted Source17/18 bytes and
canonical/current290 sources remain unchanged.
