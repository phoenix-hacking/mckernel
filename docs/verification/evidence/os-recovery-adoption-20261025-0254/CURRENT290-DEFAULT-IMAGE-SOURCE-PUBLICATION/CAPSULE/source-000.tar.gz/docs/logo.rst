.. figure:: mckernel-logo.png
