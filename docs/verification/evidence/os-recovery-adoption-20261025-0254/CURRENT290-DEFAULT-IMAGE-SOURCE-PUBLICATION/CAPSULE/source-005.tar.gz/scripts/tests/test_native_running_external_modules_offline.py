"""Injected process tests only: synthetic ELF files carry no compilation credit."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from scripts import native_running_external_modules_offline as driver

ROOT = Path(__file__).resolve().parents[2]
PREPARATION = ROOT / "docs/verification/evidence/current68-host-control-sdk-preparation-20261022-1.json"


def fake_elf(name, release=driver.RELEASE, bridges=()):
    names = b"\0.shstrtab\0.modinfo\0.strtab\0.symtab\0"
    info = ("name=" + name + "\0vermagic=" + release + " SMP mod_unload \0license=GPL\0").encode()
    strings = b"\0"
    symbols = bytes(24)
    for symbol, defined in bridges:
        symbols += struct.pack("<IBBHQQ", len(strings), 0x12, 0, 1 if defined else 0, 0, 0)
        strings += symbol.encode() + b"\0"
    header = bytearray(64)
    header[:6] = b"\x7fELF\x02\x01"
    struct.pack_into("<HH", header, 16, 1, 62)
    struct.pack_into("<Q", header, 40, 64)
    struct.pack_into("<HHH", header, 58, 64, 5, 1)
    sections = bytes(64)
    offset = 64 + 5 * 64
    for name_offset, kind, data, link, entry_size in (
            (1, 3, names, 0, 0), (11, 1, info, 0, 0),
            (20, 3, strings, 0, 0), (28, 2, symbols, 3, 24)):
        sections += struct.pack("<IIQQQQIIQQ", name_offset, kind, 0, 0, offset, len(data), link, 0, 1, entry_size)
        offset += len(data)
    return bytes(header) + sections + names + info + strings + symbols


class ExternalModulesDriverTests(unittest.TestCase):
    def setUp(self):
        parent = os.environ.get("MCKERNEL_EXTERNAL_DRIVER_EVIDENCE")
        temp = tempfile.TemporaryDirectory(prefix="driver-case-", dir=parent)
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.baseline, self.candidate, self.inputs = [self.root / x for x in ("out", "candidate", "inputs")]
        for path in [self.baseline, self.inputs, self.candidate / "modules", self.candidate / "home", self.candidate / "tmp"]:
            path.mkdir(parents=True, exist_ok=True)
        # Synthetic executor cases replace only preparation loading and the tool basis.
        # Separate loader tests exercise the installed current68 authentication contract.
        # Synthetic input bytes are never passed to a compiler.
        self.manifest = json.loads(PREPARATION.read_text())
        self.manifest["references"] = {}
        self.manifest["rust_support_exact_cmd_deps"] = []
        self.manifest["build_support_stat_only"] = []
        for row in self.manifest["closure"]:
            data = ("synthetic fixture input " + row["path"] + "\n").encode()
            target = self.candidate / "modules" / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            row["bytes"], row["sha256"] = len(data), hashlib.sha256(data).hexdigest()
        for crate in driver.MODULES:
            prefix = "/out/" + driver.KERNEL + "/drivers/misc/mckernel/"
            content = "deps_original := \\\n  " + prefix + crate + ".rs \\\n"
            name = "baseline-" + crate + ".o.cmd"
            (self.inputs / name).write_text(content)
            self.manifest["references"]["compiler_" + crate] = {
                "path": "/reference/" + name, "retained_copy": "/retained/" + name,
                "sha256": hashlib.sha256(content.encode()).hexdigest()}
        # Unit fixtures inject the container's make identity; no host make executes.
        # Keep the actual pipe-proof decoder and content hash checks in the path.
        proof = dict(status="PASS_PINNED_MAKE_PIPE_RECIPE", image_id="sha256:0f8ad280e47d76b23554de4aec411752e1f779f9b2fc7fece6b0b3375dc9775d",
                     make_path="/usr/bin/make", returncode=0, direct_child_joined=True,
                     pipe_jobserver_observed=True, fifo_count=0,
                     argv=["/usr/bin/make", "--jobserver-style=pipe", "-j2", "-f", "/probe/Makefile", "all"],
                     make_sha256="97539f226fb36b8a39b147b6efe50a44f50c65773f7ad7013c0dc1e633f11362")
        raw = json.dumps(proof).encode()
        self.manifest["make_pipe_probe"] = dict(input_name="fixture-make-pipe-proof.json", sha256=hashlib.sha256(raw).hexdigest())
        (self.inputs / "fixture-make-pipe-proof.json").write_bytes(raw)
        original_digest = driver.digest
        def container_digest(path):
            if path == Path("/usr/bin/make"): return proof["make_sha256"]
            return original_digest(path)
        injected_make = patch.object(driver, "digest", side_effect=container_digest)
        injected_make.start(); self.addCleanup(injected_make.stop)
        (self.baseline / "build").mkdir()
        tool = self.baseline / "build/fixture-tool"
        tool.write_bytes(b"synthetic tool input, never executed")
        self.basis = {"fixture-tool": hashlib.sha256(tool.read_bytes()).hexdigest()}

    def run_driver(self, executor=None, execute=True):
        with patch.object(driver, "load_preparation", return_value=copy.deepcopy(self.manifest)), \
             patch.object(driver, "BASIS_DIGESTS", self.basis), \
             patch.object(driver.subprocess, "run", side_effect=executor) as process:
            receipt = driver.execute(PREPARATION, self.baseline, self.candidate, self.inputs, run=execute)
        (self.root / "test-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        return receipt, process

    def synthetic_process(self, argv, **kwargs):
        self.assertEqual(argv, self.manifest["proposed_external_command"])
        self.assertEqual(kwargs["cwd"], self.baseline / "build")
        self.assertEqual(kwargs["env"], self.manifest["environment"])
        self.assertEqual(kwargs["timeout"], 1800)
        kwargs["stdout"].write(b"synthetic injected executor; no compiler ran\n")
        directory = self.candidate / "modules"
        for crate, module in driver.MODULES.items():
            (directory / (module + ".ko")).write_bytes(fake_elf(crate))
            for suffix in (".o", ".mod.c", ".mod.o"):
                (directory / (module + suffix)).write_bytes(b"synthetic generated fixture\n")
            leaf = "mcctrl_rust" if crate == "mcctrl" else crate
            text = "savedcmd_/candidate/modules/" + leaf + ".o := rustc --crate-name " + leaf
            text += " --emit=obj=/candidate/modules/" + leaf + ".o /candidate/modules/" + leaf + ".rs\n"
            text += "source_/candidate/modules/" + leaf + ".o := /candidate/modules/" + leaf + ".rs\n"
            text += "deps_/candidate/modules/" + leaf + ".o := \\\n"
            text += "".join("  /candidate/modules/" + name + " \\\n" for name in driver.EXACT_DEPENDENCIES[crate])
            (directory / ("." + leaf + ".o.cmd")).write_text(text)
        definitions = [(symbol, True) for symbol in driver.MM_BRIDGES]
        (directory / "mcctrl_rust.o").write_bytes(fake_elf("mcctrl", bridges=[(symbol, False) for symbol in driver.MM_BRIDGES]))
        for name in ("mcctrl_vm_write_compat.o", "mcctrl.o", "mcctrl.ko"):
            (directory / name).write_bytes(fake_elf("mcctrl", bridges=definitions))
        (directory / ".mcctrl_vm_write_compat.o.cmd").write_text(
            "savedcmd_C := cc -c /candidate/modules/mcctrl_vm_write_compat.c -o /candidate/modules/mcctrl_vm_write_compat.o\n"
            "source_C := /candidate/modules/mcctrl_vm_write_compat.c\n"
            "deps_C := /candidate/modules/mcctrl_vm_write_compat.h\n")
        (directory / "mcctrl.mod").write_text("/candidate/modules/mcctrl_rust.o /candidate/modules/mcctrl_vm_write_compat.o\n")
        (directory / ".mcctrl.o.cmd").write_text("savedcmd_link := ld -r -o /candidate/modules/mcctrl.o @/candidate/modules/mcctrl.mod\n")
        (directory / "modules.order").write_text("".join("/candidate/modules/" + name + ".o\n" for name in driver.MODULES.values()))
        exports = ("ihk_os_create_unbooted_v6", "ihk_os_create_unbooted_v12", "ihk_os_application_prepare_fork_control_v1",
                   "ihk_os_application_prepare_fork_control_receipt_v1")
        (directory / "Module.symvers").write_text("".join("0x00000000\t" + symbol + "\t/candidate/modules/ihk\tEXPORT_SYMBOL_GPL\tMCKERNEL_IHK_V1\n" for symbol in exports))
        return subprocess.CompletedProcess(argv, 0)

    def test_frozen_preparation_and_exact_all_three_plan(self):
        manifest = driver.load_preparation(PREPARATION)
        plan = driver.plan(manifest)
        self.assertEqual(plan["argv"][-2:], ["-j2", "modules"])
        self.assertEqual(plan["read_only_mounts"], ["/out", "/inputs"])
        self.assertEqual(plan["writable_mounts"], ["/candidate"])
        self.assertEqual(set(plan["all_three_modules_required"]), {"ihk", "ihk-smp-x86_64", "mcctrl"})
        self.assertNotIn("bzImage", plan["argv"])
        provenance = plan["source_provenance"]
        self.assertEqual(provenance["baseline_source_sha"], "942c927b1ec93cc31284ff498455909d9bb2d0fc")
        self.assertEqual(provenance["source_candidate_sha"], "52fd08d7495bd1e622d02cbb186cbbd0696829c192fb9afdedb83fecaa56b53a")
        self.assertEqual({row["path"] for row in provenance["reviewed_deltas"]}, set(driver.REPLACEMENTS))
        closure = {row["path"]: row["sha256"] for row in manifest["closure"]}
        encoded = json.dumps(closure, sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(provenance["closure_sha256"], hashlib.sha256(encoded).hexdigest())
        self.assertIn("not proof of unchanged compiled source", provenance["compatibility_build_id"]["meaning"])
        changed = self.root / "changed-preparation.json"
        changed.write_bytes(PREPARATION.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "frozen preparation digest"):
            driver.load_preparation(changed)

    def test_historical_preparation_is_refused(self):
        historical = ROOT / "docs/verification/evidence/native-running-external-modules-preparation-20261017-2.json"
        with self.assertRaisesRegex(ValueError, "frozen preparation digest"):
            driver.load_preparation(historical)

    def test_current68_loader_refuses_changed_map_and_dependencies(self):
        for failure in ("map", "dependencies", "identity", "replacement"):
            manifest = json.loads(PREPARATION.read_text())
            if failure == "map": manifest["closure"][0]["sha256"] = "0" * 64
            if failure == "dependencies": manifest["source_dependency_sets"]["ihk"] = []
            if failure == "identity": manifest["source_identity"] = "0" * 64
            if failure == "replacement": manifest["closure"][0]["reviewed_replacement"] = False
            path = self.root / (failure + ".json")
            path.write_text(json.dumps(manifest))
            # Rebind only the outer digest: exercise real semantic decoding.
            with self.subTest(failure=failure), patch.object(driver, "PREPARATION_SHA256", driver.digest(path)), self.assertRaises(ValueError):
                driver.load_preparation(path)

    def test_final_mm_provider_undefined_or_duplicate_symbols_are_refused(self):
        for failure in ("undefined", "duplicate"):
            with self.subTest(failure=failure):
                self.synthetic_process(self.manifest["proposed_external_command"], cwd=self.baseline / "build",
                                       env=self.manifest["environment"], timeout=1800, stdout=io.BytesIO())
                bridges = [(symbol, failure != "undefined") for symbol in driver.MM_BRIDGES]
                if failure == "duplicate": bridges.append((driver.MM_BRIDGES[0], True))
                (self.candidate / "modules/mcctrl.ko").write_bytes(fake_elf("mcctrl", bridges=bridges))
                with self.assertRaisesRegex(ValueError, "MM provider D/U mismatch"):
                    driver.actual_mm_provider_check(self.candidate / "modules")

    def test_actual_current68_reference_only_pipe_proof_contract(self):
        manifest = driver.load_preparation(PREPARATION)
        self.assertNotIn("make_pipe_probe", manifest)
        reference = manifest["references"]["make_pipe_proof"]
        retained = Path(reference["retained_copy"])
        self.assertEqual(driver.digest(retained), reference["sha256"])
        # Only /usr/bin/make identity is injected by setUp; descriptor, proof
        # bytes, hashes and every decoder/content check use installed code.
        driver.pipe_probe(manifest, retained.parent)

    def test_actual_reference_only_pipe_proof_drift_is_refused(self):
        current = driver.load_preparation(PREPARATION)
        self.assertNotIn("make_pipe_probe", current)
        reference = current["references"]["make_pipe_proof"]
        retained = Path(reference["retained_copy"])
        copied = self.inputs / retained.name
        copied.write_bytes(retained.read_bytes())
        for failure in ("reference", "proof", "content"):
            manifest = copy.deepcopy(current)
            copied.write_bytes(retained.read_bytes())
            if failure == "reference":
                manifest["references"]["make_pipe_proof"]["sha256"] = "0" * 64
            elif failure == "proof":
                copied.write_bytes(copied.read_bytes() + b" ")
            else:
                proof = json.loads(copied.read_bytes())
                proof["direct_child_joined"] = False
                copied.write_text(json.dumps(proof))
                manifest["references"]["make_pipe_proof"]["sha256"] = driver.digest(copied)
            expected = "pipe recipe proof" if failure == "content" else "pipe probe drift"
            with self.subTest(failure=failure), self.assertRaisesRegex(ValueError, expected):
                driver.pipe_probe(manifest, self.inputs)

    def test_missing_pipe_probe_is_refused_before_executor(self):
        self.manifest.pop("make_pipe_probe")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertIn("retained make pipe proof reference required", receipt["error"])
        process.assert_not_called()

    def test_changed_pipe_probe_is_refused_before_executor(self):
        (self.inputs / "fixture-make-pipe-proof.json").write_text("changed proof")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertIn("pipe probe drift", receipt["error"])
        process.assert_not_called()

    def test_plan_never_launches_a_process(self):
        receipt, process = self.run_driver(execute=False)
        self.assertEqual(receipt["status"], "PLAN_VALIDATED_NO_BUILD")
        process.assert_not_called()

    def test_injected_process_checks_arguments_environment_and_all_outputs(self):
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertEqual(receipt["status"], "BUILD_ARTIFACT_CHECKS_PASS", receipt)
        self.assertFalse(receipt["application_acceptance"])
        self.assertEqual(len(receipt["artifacts"]), 3)
        self.assertEqual(receipt["make_returncode"], 0)
        self.assertEqual(receipt["source_candidate_sha"], driver.SOURCE_CANDIDATE_SHA)
        self.assertEqual(receipt["baseline_source_sha"], driver.BASELINE_SOURCE_SHA)
        self.assertEqual(receipt["source_provenance"], driver.source_provenance(self.manifest))
        process.assert_called_once()

    def test_old_or_changed_source_never_invokes_make(self):
        (self.candidate / "modules/os_runtime.rs").write_text("old Ready publication")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertEqual(receipt["status"], "FAIL")
        self.assertIn("source changed: os_runtime.rs", receipt["error"])
        process.assert_not_called()

    def test_missing_module_fails_after_one_process_and_preserves_generated_files(self):
        def missing(argv, **kwargs):
            result = self.synthetic_process(argv, **kwargs)
            (self.candidate / "modules/mcctrl.ko").unlink()
            return result
        receipt, process = self.run_driver(missing)
        self.assertIn("missing or unexpected native module", receipt["error"])
        self.assertEqual(receipt["make_returncode"], 0)
        self.assertIn("ihk.ko", receipt["retained_files"])
        process.assert_called_once()

    def test_nonzero_status_streams_and_partial_output_survive_without_retry(self):
        def failure(argv, **kwargs):
            kwargs["stdout"].write(b"partial stdout\n")
            kwargs["stderr"].write(b"original compiler failure\n")
            (self.candidate / "modules/partial.o").write_bytes(b"partial")
            return subprocess.CompletedProcess(argv, 23)
        receipt, process = self.run_driver(failure)
        self.assertEqual(receipt["status"], "FAIL")
        self.assertEqual(receipt["make_returncode"], 23)
        evidence = self.candidate / "evidence"
        original = (evidence / "receipt.json").read_bytes()
        self.assertEqual((evidence / "make.stderr").read_bytes(), b"original compiler failure\n")
        self.assertIn("partial.o", receipt["retained_files"])
        with self.assertRaises(FileExistsError):
            self.run_driver(failure)
        self.assertEqual((evidence / "receipt.json").read_bytes(), original)
        process.assert_called_once()

    def test_timeout_has_distinct_receipt_and_retains_streams(self):
        def timeout(argv, **kwargs):
            kwargs["stderr"].write(b"partial timeout log")
            raise subprocess.TimeoutExpired(argv, 1800)
        receipt, process = self.run_driver(timeout)
        self.assertEqual(receipt["error"], "external make timeout")
        self.assertIsNone(receipt["make_returncode"])
        self.assertEqual(receipt["timeout_seconds"], 1800)
        process.assert_called_once()

    def test_old_dependency_source_path_is_rejected(self):
        def old(argv, **kwargs):
            result = self.synthetic_process(argv, **kwargs)
            path = self.candidate / "modules/.ihk.o.cmd"
            path.write_text(path.read_text().replace("source_/candidate/modules/ihk.o := /candidate/modules/ihk.rs",
                                                    "source_/candidate/modules/ihk.o := /out/old/ihk.rs"))
            return result
        receipt, process = self.run_driver(old)
        self.assertIn("wrong compiler source", receipt["error"])
        self.assertEqual(receipt["status"], "FAIL")
        process.assert_called_once()

    def test_changed_reference_rejected_before_process(self):
        (self.inputs / "baseline-ihk.o.cmd").write_text("unbound reference")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertIn("reference changed", receipt["error"])
        process.assert_not_called()

    def test_actual_linux_612_object_order_and_invalid_sets(self):
        # Exact raw format emitted by the first real external make (exit0).
        actual = ["/candidate/modules/ihk.o", "/candidate/modules/ihk-smp-x86_64.o", "/candidate/modules/mcctrl.o"]
        self.assertEqual(driver.module_order(actual), ["ihk", "ihk-smp-x86_64", "mcctrl"])
        for rows in [actual[:-1], actual + [actual[0]], [actual[0], actual[0], actual[2]],
                     [path.replace("/candidate/", "/foreign/") for path in actual],
                     [path[:-2] + ".ko" for path in actual],
                     [path.replace("/modules/", "/modules/../modules/") for path in actual],
                     [actual[0], actual[1], "/candidate/modules/unknown.o"]]:
            with self.subTest(order=rows), self.assertRaisesRegex(ValueError, "modpost module set mismatch"):
                driver.module_order(rows)

    def test_changed_basis_tool_rejected_before_process(self):
        (self.baseline / "build/fixture-tool").write_bytes(b"changed tool")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertIn("basis tool/header changed", receipt["error"])
        process.assert_not_called()

    def test_zero_exit_with_wrong_vermagic_is_rejected(self):
        def bad(argv, **kwargs):
            result = self.synthetic_process(argv, **kwargs)
            (self.candidate / "modules/ihk.ko").write_bytes(fake_elf("ihk", "old-kernel"))
            return result
        receipt, process = self.run_driver(bad)
        self.assertIn("wrong vermagic", receipt["error"])
        self.assertEqual(receipt["status"], "FAIL")
        process.assert_called_once()

    def test_make_mutating_source_cannot_pass_output_checks(self):
        def bad(argv, **kwargs):
            result = self.synthetic_process(argv, **kwargs)
            (self.candidate / "modules/sysfs_remote.rs").write_bytes(b"unreviewed replacement")
            return result
        receipt, process = self.run_driver(bad)
        self.assertIn("source changed: sysfs_remote.rs", receipt["error"])
        self.assertEqual(receipt["status"], "FAIL")
        process.assert_called_once()

    def test_symlink_source_and_overlapping_roots_are_rejected(self):
        path = self.candidate / "modules/os_runtime.rs"
        path.unlink()
        path.symlink_to(self.inputs / "baseline-ihk.o.cmd")
        receipt, process = self.run_driver(self.synthetic_process)
        self.assertIn("symlink", receipt["error"])
        process.assert_not_called()
        with self.assertRaisesRegex(ValueError, "overlap"):
            driver.execute(PREPARATION, self.baseline, self.baseline, self.inputs)
        self.assertFalse((self.baseline / "evidence").exists())


if __name__ == "__main__":
    unittest.main()
