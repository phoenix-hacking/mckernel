#!/bin/sh
MCEXEC=mcexec
./CT2000 ./CT2001
