# Empty custom commands generated dependencies file for mcps_rust_main.
# This may be replaced when dependencies are built.
