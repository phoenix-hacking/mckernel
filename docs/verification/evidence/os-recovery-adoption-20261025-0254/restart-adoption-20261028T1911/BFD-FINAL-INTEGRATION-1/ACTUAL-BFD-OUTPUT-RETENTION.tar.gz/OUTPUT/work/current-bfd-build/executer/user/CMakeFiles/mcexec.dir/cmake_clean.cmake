file(REMOVE_RECURSE
  "CMakeFiles/mcexec.dir/link.d"
  "mcexec"
  "mcexec.pdb"
  "rust/mcexec_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcexec.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
