# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for sched_yield_rust_main.
