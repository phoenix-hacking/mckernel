mcinspect: \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/Scrt1.o \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/crti.o \
  /usr/lib/gcc/x86_64-redhat-linux/14/crtbeginS.o \
  rust/bfd_accessors.o \
  rust/mcinspect_helpers.o \
  lib/libdwarf/libdwarf.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libz.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libelf.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so \
  /usr/lib64/libbfd.a \
  /usr/lib64/libsframe.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libiberty.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libz.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libdl.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so \
  /lib64/libc.so.6 \
  /usr/lib64/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/14/crtendS.o \
  /usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/crtn.o \
  /usr/lib64/libzstd.so.1 \
  /lib64/ld-linux-x86-64.so.2

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/Scrt1.o:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/crti.o:

/usr/lib/gcc/x86_64-redhat-linux/14/crtbeginS.o:

rust/bfd_accessors.o:

rust/mcinspect_helpers.o:

lib/libdwarf/libdwarf.a:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libz.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libelf.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libbfd.so:

/usr/lib64/libbfd.a:

/usr/lib64/libsframe.a:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libiberty.a:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libz.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libdl.a:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/libc.so:

/lib64/libc.so.6:

/usr/lib64/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/14/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/14/crtendS.o:

/usr/lib/gcc/x86_64-redhat-linux/14/../../../../lib64/crtn.o:

/usr/lib64/libzstd.so.1:

/lib64/ld-linux-x86-64.so.2:
