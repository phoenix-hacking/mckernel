executer/user/lib/libdwarf/CMakeFiles/dwarf.dir/libdwarf/libdwarf/dwarf_groups.c.o: \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_groups.c \
 /usr/include/stdc-predef.h \
 /work/current-bfd-build/executer/user/lib/libdwarf/config.h \
 /usr/include/stdio.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stddef.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stdarg.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_incl.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/libdwarfdefs.h \
 /usr/include/sys/types.h /usr/include/bits/types/clock_t.h \
 /usr/include/bits/types/clockid_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/timer_t.h /usr/include/bits/stdint-intn.h \
 /usr/include/endian.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/byteswap.h \
 /usr/include/bits/uintn-identity.h /usr/include/sys/select.h \
 /usr/include/bits/select.h /usr/include/bits/types/sigset_t.h \
 /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/string.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/strings.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf.h \
 /work/current-bfd-build/executer/user/lib/libdwarf/libdwarf.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_base_types.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_opaque.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_error.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf_tsearch.h \
 /usr/include/stdlib.h /usr/include/bits/waitflags.h \
 /usr/include/bits/waitstatus.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-float.h
