# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for bfd_rust_accessors.
