file(REMOVE_RECURSE
  "CMakeFiles/bfd_rust_accessors"
  "rust/bfd_accessors.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/bfd_rust_accessors.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
