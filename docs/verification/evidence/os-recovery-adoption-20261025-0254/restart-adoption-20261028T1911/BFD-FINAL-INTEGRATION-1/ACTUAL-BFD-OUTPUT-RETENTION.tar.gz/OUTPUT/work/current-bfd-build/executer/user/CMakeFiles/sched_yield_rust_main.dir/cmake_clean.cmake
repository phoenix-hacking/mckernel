file(REMOVE_RECURSE
  "CMakeFiles/sched_yield_rust_main"
  "rust/libsched_yield.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/sched_yield_rust_main.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
