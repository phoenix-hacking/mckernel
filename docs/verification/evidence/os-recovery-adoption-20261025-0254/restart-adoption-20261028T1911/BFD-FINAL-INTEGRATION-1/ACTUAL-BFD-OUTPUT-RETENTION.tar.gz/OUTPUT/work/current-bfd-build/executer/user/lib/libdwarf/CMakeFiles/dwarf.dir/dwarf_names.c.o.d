executer/user/lib/libdwarf/CMakeFiles/dwarf.dir/dwarf_names.c.o: \
 /work/current-bfd-build/executer/user/lib/libdwarf/dwarf_names.c \
 /usr/include/stdc-predef.h \
 /src/executer/user/lib/libdwarf/libdwarf/libdwarf/dwarf.h \
 /work/current-bfd-build/executer/user/lib/libdwarf/libdwarf.h
