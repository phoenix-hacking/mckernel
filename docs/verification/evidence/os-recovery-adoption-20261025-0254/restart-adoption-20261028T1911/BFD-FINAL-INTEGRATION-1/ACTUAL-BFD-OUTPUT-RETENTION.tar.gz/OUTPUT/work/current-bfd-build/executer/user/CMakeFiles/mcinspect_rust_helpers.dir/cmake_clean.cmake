file(REMOVE_RECURSE
  "CMakeFiles/mcinspect_rust_helpers"
  "rust/mcinspect_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcinspect_rust_helpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
