# Empty custom commands generated dependencies file for sched_yield_rust_main.
# This may be replaced when dependencies are built.
