# Empty custom commands generated dependencies file for bfd_rust_accessors.
# This may be replaced when dependencies are built.
