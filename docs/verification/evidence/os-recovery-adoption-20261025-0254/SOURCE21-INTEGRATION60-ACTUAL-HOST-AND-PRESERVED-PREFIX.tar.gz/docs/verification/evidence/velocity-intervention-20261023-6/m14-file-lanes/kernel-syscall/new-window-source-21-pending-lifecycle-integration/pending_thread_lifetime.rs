// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private process_helpers child; every selector remains OFF.
use core::mem::{offset_of, MaybeUninit};
use core::ptr::{addr_of_mut, null_mut};
use core::sync::atomic::{AtomicI32, Ordering};

use crate::abi::{AbiListHead, CInt, Thread, PROCESS_HASH_SIZE};
use crate::lock_helpers::{McsRwlockLock, McsRwlockNodeIrqsave};

/// Acquire an existing positive Thread.refcount edge without resurrecting zero.
///
/// # Safety
/// Existing hash reader lock retains this published Thread storage until return;
/// final destruction must detach under the same bucket's writer before freeing.
/// Every count operation uses the actual atomic refcount and balanced ownership.
/// A successful result owns exactly one edge, released with existing thread_unlock.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_try_hold_live_thread_v1(thread: *mut Thread) -> CInt {
    // SAFETY: Preserve the original hold callback's actual exited-thread warning
    // BEFORE the count operation, under the same hash guard. No callback signature
    // changes: the existing void warning bridge remains a diagnostic, not admission.
    unsafe {
        if super::process_hold_thread_warn_exited_result((*thread).status) != 0 {
            super::process_hold_thread_warn_bridge(thread.cast());
        }
    }
    // SAFETY: The hash guard pins allocation storage even after the last edge drops.
    // Use the same AtomicI32/SeqCst representation as existing process_ref_* bodies.
    let counter = unsafe { AtomicI32::from_ptr(addr_of_mut!((*thread).refcount.counter)) };
    let mut count = counter.load(Ordering::SeqCst);
    while count > 0 && count < CInt::MAX {
        match counter.compare_exchange_weak(count, count + 1, Ordering::SeqCst, Ordering::SeqCst) {
            Ok(_) => return 1,
            Err(observed) => count = observed,
        }
    }
    0
}

/// Original hash traversal/PID fallback with positive-only reference acquisition.
///
/// # Safety
/// Head/lock belong to the same live bucket, with original list geometry. Every
/// final free first takes this lock for hash detachment. No node is retained after
/// unlock unless the CAS acquired its actual refcount edge. No output owns zero.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_find_live_in_hash_v1(
    head: *mut AbiListHead, lock: *mut McsRwlockLock, pid: CInt, tid: CInt,
) -> *mut Thread {
    if tid <= 0 || head.is_null() || lock.is_null() { return null_mut(); }
    let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    // SAFETY: Genuine existing IRQ-save hash reader provider, same node through unlock.
    unsafe { crate::lock_helpers::__mcs_rwlock_reader_lock(lock, node.as_mut_ptr()) };
    let mut match_pid = pid;
    let mut found = null_mut();
    loop {
        // SAFETY: Adjacent hash list entries remain live under this bucket reader.
        let mut entry = unsafe { (*head).next };
        while !entry.is_null() && entry != head {
            // SAFETY: This exact container geometry is used by selected find_thread.
            let thread = unsafe { entry.cast::<u8>().sub(offset_of!(Thread, hash_list)) }
                .cast::<Thread>();
            // SAFETY: Hash membership pins the typed node, and its process edge is
            // retained until final destructor after writer-detachment.
            let matches = unsafe {
                (*thread).tid == tid && (match_pid <= 0
                    || (!(*thread).proc.is_null() && (*(*thread).proc).pid == match_pid))
            };
            if matches && unsafe { f03_pending_try_hold_live_thread_v1(thread) } != 0 {
                found = thread;
                break;
            }
            // SAFETY: The same reader guard protects next's storage and value.
            entry = unsafe { (*entry).next };
        }
        if !found.is_null() || match_pid <= 0 || match_pid != tid { break; }
        match_pid = 0;
    }
    // SAFETY: All borrowed hash pointers die here; only found owns a positive edge.
    unsafe { crate::lock_helpers::__mcs_rwlock_reader_unlock(lock, node.as_mut_ptr()) };
    found
}

/// Actual kernel entry: reuse current CPU/resource-set/hash selection unchanged.
///
/// # Safety
/// Original find_thread CPU/resource-set lifetime and binding contracts apply.
/// On success caller must call existing thread_unlock exactly once.
#[no_mangle]
pub unsafe extern "C" fn f03_find_thread_pending_live_v1(pid: CInt, tid: CInt) -> *mut Thread {
    if tid <= 0 { return null_mut(); }
    // SAFETY: Same original current-CPU provider; CPU/resource-set lifetime is external.
    let cpu = unsafe { super::get_this_cpu_local_var() };
    if cpu.is_null() || unsafe { (*cpu).resource_set.is_null() } { return null_mut(); }
    let hash = super::thread_hash(tid);
    if hash < 0 || hash as usize >= PROCESS_HASH_SIZE { return null_mut(); }
    // SAFETY: Same live resource-set hash as selected find_thread, validated above.
    let bucket = unsafe { (*(*cpu).resource_set).thread_hash };
    if bucket.is_null() { return null_mut(); }
    // SAFETY: Validated real index and typed bucket arrays, with existing lock geometry.
    unsafe { f03_pending_find_live_in_hash_v1(
        addr_of_mut!((*bucket).list).cast::<AbiListHead>().add(hash as usize),
        addr_of_mut!((*bucket).lock).cast::<McsRwlockLock>().add(hash as usize), pid, tid,
    ) }
}
