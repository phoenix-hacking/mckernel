// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt,CLong,CULong,SizeT};
use core::mem::{align_of,offset_of,size_of};
include!("genuine_syscall_parent.fixture.rs.inc");
include!("../new-window-source-20-pending-commit-lifecycle/usercopy-long-abi-correction-1/genuine_usercopy_types.RUST-DECLARATIONS.inc");
unsafe extern "C" {
 fn syscall_copy_from_user_bridge(dst:*mut u8,src:CULong,bytes:SizeT)->CLong;
 fn syscall_copy_to_user_bridge(dst:CULong,src:*const u8,bytes:SizeT)->CLong;
}
mod mem_helpers {
 use crate::abi::{CInt,CULong};use core::ffi::c_void;
 unsafe extern "C" {
  pub fn kmalloc_tracked(bytes:CInt,flags:CULong,file:*mut i8,line:CInt)->*mut c_void;
  pub fn kfree_tracked(pending:*mut c_void,file:*mut i8,line:CInt);
 }
}
mod lock_helpers {
 pub use crate::abi::McsRwlockLock;use crate::abi::CULong;
 #[repr(C,align(64))] pub struct McsRwlockNodeIrqsave { irqsave:CULong }
 unsafe extern "C" {
  pub fn __mcs_rwlock_reader_lock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
  pub fn __mcs_rwlock_reader_unlock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
  pub fn __mcs_rwlock_writer_lock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
  pub fn __mcs_rwlock_writer_unlock(lock:*mut McsRwlockLock,node:*mut McsRwlockNodeIrqsave);
 }
}
mod pending_lifecycle {
 use crate::abi::{CInt,CLong,CULong,Thread};use core::ffi::c_void;
 #[repr(C)] pub struct Outcome { pub disposition:CInt,pub error:CLong }
 pub const COMPLETE:CInt=0;pub const HELD_ALIAS:CInt=3;
 unsafe extern "C" {
  pub fn f03_pending_stage_and_commit_v1(thread:*mut Thread,data:CULong,flags:CULong,
   allocate:unsafe extern "C" fn(usize,CULong)->*mut c_void,
   free:unsafe extern "C" fn(*mut c_void),copy:super::PtraceUserCopyFromFn)->Outcome;
  pub fn f03_pending_get_snapshot_v1(thread:*mut Thread,data:CULong,
   copy:super::PtraceUserCopyToFn)->Outcome;
 }
}
mod process_helpers {
 use core::ffi::c_void;use core::mem::{offset_of,MaybeUninit};use core::ptr::null_mut;
 use crate::abi::{
    AbiListHead, AddressSpace, CInt, CLong, CULong, CpuLocalVar, CpuSet, IhkAtomic, IhkSpinlock,
    Mckfd, McsRwlockLock, Memobj, OffT, Process, ProcessHash, ProcessVm, ProgramLoadDesc, RLimit,
    ResourceSet, SigCommon, SigPending, SigStack, SizeT, Thread, ThreadHash, VmRange,
    VmRangeNumaPolicy, Waitq, AUXV_LEN, CPU_SET_MAX_CPUS, MCK_RLIM_MAX, PROCESS_HASH_SIZE,
    PROCESS_NUMA_MASK_BITS, VM_RANGE_CACHE_SIZE,
};
 use crate::lock_helpers::McsRwlockNodeIrqsave;
 include!("genuine_process_parent.fixture.rs.inc");
 #[path="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-21-pending-lifecycle-integration/pending_thread_lifetime.rs"] mod pending_thread_lifetime;
 include!("pending_destroy_integration.rs.inc");
 #[no_mangle]
 pub unsafe extern "C" fn f03_fixture_detached_optional_cleanup(
  thread:*mut Thread,owned:*mut F03DetachedPending,
 )->CInt {
  f03_destroy_thread_optional_pending_cleanup_v1(thread.cast(),owned,
   offset_of!(Thread,ptrace_debugreg) as CULong,offset_of!(Thread,ptrace_recvsig) as CULong,
   offset_of!(Thread,ptrace_sendsig) as CULong,offset_of!(Thread,fp_regs) as CULong,
   offset_of!(Thread,coredump_regs) as CULong,
   Some(process_optional_free_bridge),Some(release_fp_regs))
 }
}
#[path="pending_lifecycle_callers.rs"] mod pending_lifecycle_callers;
#[no_mangle]
pub static f03_integration_Rust_ABI:[usize;20]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,hash_list),
 offset_of!(abi::Thread,refcount),offset_of!(abi::IhkAtomic,counter),
 size_of::<abi::IhkAtomic>(),align_of::<abi::IhkAtomic>(),
 size_of::<abi::ThreadHash>(),offset_of!(abi::ThreadHash,lock),
 size_of::<abi::ResourceSet>(),offset_of!(abi::ResourceSet,thread_hash),
 size_of::<abi::CpuLocalVar>(),offset_of!(abi::CpuLocalVar,resource_set),
 size_of::<abi::Process>(),offset_of!(abi::Process,pid),
 size_of::<pending_lifecycle::Outcome>(),offset_of!(pending_lifecycle::Outcome,error),
 size_of::<process_helpers::F03DetachedPending>(),
 size_of::<process_helpers::F03PendingDestroyResult>(),abi::PROCESS_HASH_SIZE,
];
