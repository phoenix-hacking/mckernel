/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"


#include <kmalloc.h>
#include "../new-window-source-20-pending-commit-lifecycle/usercopy-long-abi-correction-1/genuine_usercopy_types.C-DECLARATIONS.inc"
struct outcome { int disposition; long error; };
struct detached_pending { void *receive, *send; };
extern struct thread *f03_find_thread_pending_live_v1(int,int);
extern struct outcome f03_ptrace_setsiginfo_lifecycle_result_v1(int,unsigned long);
extern struct outcome f03_ptrace_getsiginfo_lifecycle_result_v1(int,unsigned long);
extern struct outcome f03_ptrace_resume_pending_lifecycle_result_v1(int,long,struct siginfo *,int *);
extern int f03_fixture_detached_optional_cleanup(struct thread *,struct detached_pending *);
extern const unsigned long f03_integration_Rust_ABI[20],f03_lifecycle_Rust_ABI[25];
extern int printf(const char *,...);
extern int dprintf(int,const char *,...);
extern void abort(void);
#define require(v) do{if(!(v)){dprintf(2,"FAIL integration line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
static struct thread target;
static struct process process;
static struct sig_common common;
static struct thread_hash hash;
static struct resource_set resources;
static struct cpu_local_var cpu;
static struct sig_pending send_node,receive_node,fresh;
static unsigned long debug_token,core_token,fp_token;
static int hash_held,signal_held,reader_count,writer_count,release_count,warning_count;
static int drop_before_lookup,drop_during_copy,retired,fault_copy,mutate_shape;
static int allocation_count,free_count,copy_count,private_live,copy_observed_refs;
static unsigned long reader_identity,writer_identity;
static struct siginfo expected_copy;
static char cleanup_order[8];static int cleanup_count;
const unsigned long f03_pending_lifecycle_alloc_flags_v1=IHK_MC_AP_NOWAIT;
static void append(char value){require(cleanup_count<8);cleanup_order[cleanup_count++]=value;}
struct cpu_local_var *get_this_cpu_local_var(void){return &cpu;}
void __mcs_rwlock_reader_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[101%HASH_SIZE]&&!hash_held&&!signal_held&&node);
 require((unsigned long)node%__alignof__(*node)==0);hash_held=1;reader_count++;
 reader_identity=(unsigned long)node;*(unsigned long *)node=0x1235;
 if(drop_before_lookup)target.refcount.counter=0;
}
void __mcs_rwlock_reader_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[101%HASH_SIZE]&&hash_held&&(unsigned long)node==reader_identity);
 require(*(unsigned long *)node==0x1235);hash_held=0;reader_identity=0;
}
void __mcs_rwlock_writer_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&common.lock&&!hash_held&&!signal_held&&node);
 require((unsigned long)node%__alignof__(*node)==0);signal_held=1;writer_count++;
 writer_identity=(unsigned long)node;*(unsigned long *)node=0x4321;
}
void __mcs_rwlock_writer_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&common.lock&&signal_held&&(unsigned long)node==writer_identity);
 require(*(unsigned long *)node==0x4321);signal_held=0;writer_identity=0;
}
void process_hold_thread_warn_bridge(void *thread){
 require(thread==&target&&hash_held&&target.status==PS_EXITED);warning_count++;
}
void thread_unlock(struct thread *thread){
 require(thread==&target&&!hash_held&&!signal_held&&target.refcount.counter>0);
 target.refcount.counter--;release_count++;if(!target.refcount.counter)retired=1;
}
void *kmalloc_tracked(int bytes,ihk_mc_ap_flag flags,char *file,int line){
 require(!hash_held&&!signal_held&&!retired&&target.refcount.counter>=2);
 require(bytes==sizeof(fresh)&&flags==IHK_MC_AP_NOWAIT&&file&&line>0&&!private_live);
 allocation_count++;private_live=1;__builtin_memset(&fresh,0xcc,sizeof(fresh));return &fresh;
}
void kfree_tracked(void *pending,char *file,int line){
 require(!hash_held&&!signal_held&&!retired&&target.refcount.counter>=1&&file&&line>0);
 require(pending==&fresh||pending==&send_node||pending==&receive_node);
 if(pending==&fresh){require(private_live);private_live=0;}
 free_count++;append('F');
}
long syscall_copy_from_user_bridge(void *destination,unsigned long source,size_t bytes){
 require(!hash_held&&!signal_held&&!retired&&target.refcount.counter>=1);
 require(source==0x1234&&bytes==sizeof(struct siginfo));copy_count++;
 copy_observed_refs=target.refcount.counter;
 if(drop_during_copy&&copy_count==1){require(target.refcount.counter==2);target.refcount.counter--;}
 if(mutate_shape&&copy_count==1){
  struct mcs_rwlock_node_irqsave node;__mcs_rwlock_writer_lock(&common.lock,&node);
  target.ptrace_recvsig=&receive_node;__mcs_rwlock_writer_unlock(&common.lock,&node);
 }
 __builtin_memset(destination,0x51,bytes);return fault_copy?1:0;
}
long syscall_copy_to_user_bridge(unsigned long destination,const void *source,size_t bytes){
 require(!hash_held&&!signal_held&&!retired&&target.refcount.counter>=1);
 require(destination==0x1234&&bytes==sizeof(struct siginfo));copy_count++;
 copy_observed_refs=target.refcount.counter;
 require(!memcmp(source,&expected_copy,bytes));
 if(drop_during_copy){require(target.refcount.counter==2);target.refcount.counter--;}
 return fault_copy?1:0;
}
_Static_assert(__builtin_types_compatible_p(__typeof__(&syscall_copy_from_user_bridge),ptrace_user_copy_from_fn_t),"genuine long copy-from ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&syscall_copy_to_user_bridge),ptrace_user_copy_to_fn_t),"genuine long copy-to ABI");
void process_optional_free_bridge(void *p){
 require(!hash_held&&!signal_held);
 if(p==&debug_token)append('D');else if(p==&receive_node)append('R');
 else if(p==&send_node)append('S');else{require(p==&core_token);append('C');}
}
void release_fp_regs(struct thread *thread){require(thread==&target&&target.fp_regs==(void *)&fp_token);append('P');}
static void reset(void){
 __builtin_memset(&target,0,sizeof(target));__builtin_memset(&process,0,sizeof(process));
 __builtin_memset(&common,0,sizeof(common));__builtin_memset(&hash,0,sizeof(hash));
 __builtin_memset(&resources,0,sizeof(resources));__builtin_memset(&cpu,0,sizeof(cpu));
 __builtin_memset(&send_node,0x31,sizeof(send_node));__builtin_memset(&receive_node,0x42,sizeof(receive_node));
 target.tid=101;target.proc=&process;target.sigcommon=&common;target.status=PS_TRACED;
 target.refcount.counter=1;process.pid=100;cpu.resource_set=&resources;resources.thread_hash=&hash;
 struct list_head *head=&hash.list[101%HASH_SIZE];head->next=head->prev=&target.hash_list;
 target.hash_list.next=target.hash_list.prev=head;
 hash_held=signal_held=reader_count=writer_count=release_count=warning_count=0;
 drop_before_lookup=drop_during_copy=retired=fault_copy=mutate_shape=0;
 allocation_count=free_count=copy_count=private_live=copy_observed_refs=0;
 reader_identity=writer_identity=0;cleanup_count=0;
}
static void verify_geometry(void){
 const unsigned long actual20[20]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,hash_list),__builtin_offsetof(struct thread,refcount),__builtin_offsetof(ihk_atomic_t,counter),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),sizeof(struct thread_hash),__builtin_offsetof(struct thread_hash,lock),sizeof(struct resource_set),__builtin_offsetof(struct resource_set,thread_hash),sizeof(struct cpu_local_var),__builtin_offsetof(struct cpu_local_var,resource_set),sizeof(struct process),__builtin_offsetof(struct process,pid),sizeof(struct outcome),__builtin_offsetof(struct outcome,error),sizeof(struct detached_pending),3*sizeof(int),HASH_SIZE};
 const unsigned long actual25[25]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,sigcommon),__builtin_offsetof(struct thread,ptrace_sendsig),__builtin_offsetof(struct thread,ptrace_recvsig),sizeof(struct sig_common),__alignof__(struct sig_common),__builtin_offsetof(struct sig_common,lock),sizeof(struct sig_pending),__alignof__(struct sig_pending),__builtin_offsetof(struct sig_pending,info),sizeof(struct siginfo),__alignof__(struct siginfo),sizeof(struct mcs_rwlock_lock),__alignof__(struct mcs_rwlock_lock),sizeof(struct mcs_rwlock_node_irqsave),__alignof__(struct mcs_rwlock_node_irqsave),__builtin_offsetof(struct thread,status),3*sizeof(int),__alignof__(int),2*sizeof(int),sizeof(struct outcome),__alignof__(struct outcome),__builtin_offsetof(struct outcome,error),sizeof(int)};
 require(!memcmp(actual20,f03_integration_Rust_ABI,sizeof(actual20)));
 require(!memcmp(actual25,f03_lifecycle_Rust_ABI,sizeof(actual25)));
}
int main(void){
 verify_geometry();unsigned lookup_cases=0,caller_cases=0,resume_cases=0,cleanup_cases=0;
 const int counts[6]={-1,0,1,2,2147483646,2147483647};const int pids[3]={0,101,999};
 for(int i=0;i<6;i++)for(int p=0;p<3;p++)for(int before=0;before<2;before++){
  reset();target.refcount.counter=counts[i];target.status=PS_EXITED;drop_before_lookup=before;
  struct thread *found=f03_find_thread_pending_live_v1(pids[p],101);
  int count=before?0:counts[i];int matches=pids[p]!=999;
  int acquired=matches&&count>0&&count<2147483647;
  require(found==(acquired?&target:NULL));require(target.refcount.counter==count+acquired);
  require(reader_count==1&&!hash_held&&!signal_held&&warning_count==matches);
  if(acquired){thread_unlock(found);require(target.refcount.counter==count&&release_count==1);}
  lookup_cases++;
 }
 /* Actual caller guards: absent tracee, ordinary success, final external edge
  * dropping DURING copy, copy rollback, and an unmapped internal changed-state hold. */
 for(int mode=0;mode<6;mode++){
  reset();struct outcome result;
  if(mode==0){target.refcount.counter=0;result=f03_ptrace_getsiginfo_lifecycle_result_v1(101,0x1234);require(result.disposition==1&&result.error==-ESRCH&&!release_count&&!copy_count);}
  else if(mode==1||mode==2){target.ptrace_recvsig=&receive_node;expected_copy=receive_node.info;drop_during_copy=mode==2;result=f03_ptrace_getsiginfo_lifecycle_result_v1(101,0x1234);require(!result.disposition&&!result.error&&copy_observed_refs==2&&release_count==1);require(retired==(mode==2));}
  else {fault_copy=mode==4;mutate_shape=mode==5;result=f03_ptrace_setsiginfo_lifecycle_result_v1(101,0x1234);require(release_count==1&&copy_observed_refs==2&&allocation_count==1);if(mode==3){require(!result.disposition&&!result.error&&target.ptrace_sendsig==&fresh&&private_live&&!free_count);}else{require(result.disposition==(mode==4?1:2)&&result.error==(mode==4?-EFAULT:0));require(!target.ptrace_sendsig&&!private_live&&free_count==1&&cleanup_order[0]=='F');}}
  require(!hash_held&&!signal_held);caller_cases++;
 }
 for(int mode=0;mode<5;mode++)for(int choice=0;choice<2;choice++){
  reset();target.ptrace_sendsig=mode==1||mode==3||mode==4?&send_node:NULL;
  target.ptrace_recvsig=mode==2||mode==3?&receive_node:mode==4?&send_node:NULL;
  struct siginfo snapshot,before;__builtin_memset(&snapshot,0xcc,sizeof(snapshot));before=snapshot;
  int present=-1;long request=choice?9:7;
  struct outcome result=f03_ptrace_resume_pending_lifecycle_result_v1(101,request,&snapshot,&present);
  struct sig_pending *expected=choice?NULL:mode==1||mode==3?&send_node:mode==2?&receive_node:NULL;
  require(release_count==1&&!hash_held&&!signal_held);
  if(mode==4){require(result.disposition==3&&!result.error&&!present&&!free_count&&!memcmp(&snapshot,&before,sizeof(snapshot)));}
  else{require(!result.disposition&&!result.error&&present==(expected!=NULL)&&free_count==present);if(expected)require(!memcmp(&snapshot,&expected->info,sizeof(snapshot)));else require(!memcmp(&snapshot,&before,sizeof(snapshot)));}
  resume_cases++;
 }
 for(int mask=0;mask<8;mask++){
  reset();struct detached_pending owned={mask&1?&receive_node:NULL,mask&2?&send_node:NULL};
  target.ptrace_debugreg=&debug_token;target.fp_regs=mask&4?(void *)&fp_token:NULL;target.coredump_regs=&core_token;
  int result=f03_fixture_detached_optional_cleanup(&target,&owned);
  require(!owned.receive&&!owned.send&&!target.ptrace_recvsig&&!target.ptrace_sendsig);
  char expected[8];int n=0;expected[n++]='D';if(mask&1)expected[n++]='R';if(mask&2)expected[n++]='S';if(mask&4)expected[n++]='P';expected[n++]='C';
  require(cleanup_count==n&&!memcmp(cleanup_order,expected,n));
  require(result==2+!!(mask&1)+!!(mask&2)+!!(mask&4));cleanup_cases++;
 }
 require(lookup_cases==36&&caller_cases==6&&resume_cases==10&&cleanup_cases==8);
 printf("PASS integration lookup36 callers6 resume10 cleanup8 ABI20 reusedABI25 controlled-only no-native-credit\n");return 0;
}
