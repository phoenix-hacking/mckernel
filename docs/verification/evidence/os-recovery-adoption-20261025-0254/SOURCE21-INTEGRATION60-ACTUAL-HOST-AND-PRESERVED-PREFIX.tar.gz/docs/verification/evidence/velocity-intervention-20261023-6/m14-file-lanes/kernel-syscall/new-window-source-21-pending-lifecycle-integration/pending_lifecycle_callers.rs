// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private syscall_policy child. Internal outcomes are NOT syscall return values.
use core::ffi::c_void;
use core::mem::{size_of, MaybeUninit};
use core::ptr::{addr_of_mut, copy_nonoverlapping, null_mut, read_volatile, write_volatile};

use crate::abi::{CInt, CLong, CULong, SigCommon, SigInfo, SigPending, Thread};
use crate::lock_helpers::McsRwlockNodeIrqsave;
use super::pending_lifecycle::{Outcome, COMPLETE, HELD_ALIAS};

unsafe extern "C" {
    fn f03_find_thread_pending_live_v1(pid: CInt, tid: CInt) -> *mut Thread;
    static f03_pending_lifecycle_alloc_flags_v1: CULong;
}

/// The existing Thread refcount owns thread storage and its sigcommon edge. No
/// sigcommon or pending-node pointer is fabricated into an independent reference.
struct TraceeReference { thread: *mut Thread }

impl TraceeReference {
    unsafe fn acquire(pid: CInt, tid: CInt) -> Option<Self> {
        // SAFETY: New real hash lookup uses positive-only acquisition of the
        // existing count while final destruction's hash writer cannot free storage.
        let thread = unsafe { f03_find_thread_pending_live_v1(pid, tid) };
        if thread.is_null() { None } else { Some(Self { thread }) }
    }
}

impl Drop for TraceeReference {
    fn drop(&mut self) {
        // SAFETY: Exactly one real count edge is owned. All pending locks and
        // private-node cleanup finish before dropping this outer scope guard.
        unsafe { crate::process_helpers::thread_unlock(self.thread) };
    }
}

unsafe extern "C" fn free_private_pending(pending: *mut c_void) {
    // SAFETY: Callers transfer one private or detached unique node, outside locks.
    unsafe { crate::mem_helpers::kfree_tracked(pending,
        concat!(file!(), "\0").as_ptr().cast_mut().cast(), line!() as CInt) };
}

unsafe extern "C" fn allocate_private_pending(bytes: usize, flags: CULong) -> *mut c_void {
    // SAFETY: Accepted caller requests exactly one SigPending, whose size fits the
    // genuine allocator's C-int argument. Keep actual tracked allocation semantics
    // with this Rust call site's metadata, rather than borrowing unrelated fd origin.
    unsafe { crate::mem_helpers::kmalloc_tracked(bytes as CInt, flags,
        concat!(file!(), "\0").as_ptr().cast_mut().cast(), line!() as CInt) }
}

/// Actual retained-tracee producer caller around the accepted Source20 body.
///
/// # Safety
/// All selected pending participants and status/lifecycle admission must meet the
/// accepted body's contracts. Positive lookup proves allocation lifetime only.
/// Status writers are NOT all serialized by sigcommon.lock; selector stays OFF.
/// This Outcome has no ptrace dispatch adaptation, especially for HELD_*.
#[no_mangle]
pub unsafe extern "C" fn f03_ptrace_setsiginfo_lifecycle_result_v1(
    pid: CInt, data: CULong,
) -> Outcome {
    // SAFETY: acquire retains an actual positive tracee edge until guard drop.
    let Some(tracee) = (unsafe { TraceeReference::acquire(0, pid) }) else {
        return Outcome { disposition: 1, error: -3 };
    };
    // SAFETY: Genuine metadata/provider identities. Accepted producer alone owns
    // private rollback and unlocks before return; the thread edge spans both copies.
    unsafe { super::pending_lifecycle::f03_pending_stage_and_commit_v1(
        tracee.thread, data, f03_pending_lifecycle_alloc_flags_v1,
        allocate_private_pending, free_private_pending, super::syscall_copy_from_user_bridge,
    ) }
}

/// Actual retained-tracee getter; positive reference survives unlocked usercopy.
///
/// # Safety
/// Same shared participant/initialized-byte/status contracts as accepted getter.
#[no_mangle]
pub unsafe extern "C" fn f03_ptrace_getsiginfo_lifecycle_result_v1(
    pid: CInt, data: CULong,
) -> Outcome {
    // SAFETY: Original lookup tuple, repaired positive acquisition of actual edge.
    let Some(tracee) = (unsafe { TraceeReference::acquire(0, pid) }) else {
        return Outcome { disposition: 1, error: -3 };
    };
    // SAFETY: Its internal snapshot and locks complete before the guard releases.
    unsafe { super::pending_lifecycle::f03_pending_get_snapshot_v1(
        tracee.thread, data, super::syscall_copy_to_user_bridge,
    ) }
}

/// Select the original resume priority and detach/snapshot in ONE signal lock.
/// Source19's proven lock/snapshot/detach operations are reused in the same order;
/// source selection is moved into that critical section to avoid a new race.
///
/// # Safety
/// Caller retains actual tracee/sigcommon. Outputs are disjoint initialized writable
/// storage. All participants share the real lock and published bytes are initialized.
/// TAKEN transfers unique ownership; NONE/HELD_ALIAS transfer nothing. Return is
/// Source19 NONE=0/TAKEN=1/HELD_ALIAS=2, NOT syscall errno or success.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_resume_snapshot_selected_v1(
    thread: *mut Thread, request: CLong, snapshot: *mut SigInfo,
    detached: *mut *mut c_void,
) -> CInt {
    // SAFETY: Caller owns output storage, disjoint from every published slot.
    unsafe { detached.write(null_mut()) };
    let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    // SAFETY: Live same sigcommon allocation and genuine typed existing lock.
    let lock = unsafe { addr_of_mut!((*(*thread).sigcommon.cast::<SigCommon>()).lock) };
    unsafe { crate::lock_helpers::__mcs_rwlock_writer_lock(lock.cast(), node.as_mut_ptr()) };
    // SAFETY: No usercopy/free/allocation/scheduler callback occurs under this guard.
    let result = unsafe {
        let send = read_volatile(addr_of_mut!((*thread).ptrace_sendsig));
        let receive = read_volatile(addr_of_mut!((*thread).ptrace_recvsig));
        if !send.is_null() && send == receive { 2 } else {
            let source = super::ptrace_resume_signal_source_result(
                request, (!send.is_null()) as CInt, (!receive.is_null()) as CInt);
            let slot = match source {
                1 => addr_of_mut!((*thread).ptrace_sendsig),
                2 => addr_of_mut!((*thread).ptrace_recvsig),
                _ => null_mut(),
            };
            let pending = if slot.is_null() { null_mut() } else { read_volatile(slot) };
            if pending.is_null() { 0 } else {
                copy_nonoverlapping(addr_of_mut!((*pending.cast::<SigPending>()).info).cast::<u8>(),
                    snapshot.cast::<u8>(), size_of::<SigInfo>());
                write_volatile(slot, null_mut());
                detached.write(pending);
                1
            }
        }
    };
    // SAFETY: Same node and lock are restored before any caller frees detached.
    unsafe { crate::lock_helpers::__mcs_rwlock_writer_unlock(lock.cast(), node.as_mut_ptr()) };
    result
}

/// Independent actual resume consumption body: acquire tracee, snapshot and retire
/// detached ownership outside signal lock, release positive tracee edge once.
/// Does not call do_kill/wakeup or translate a hold into ptrace success.
///
/// # Safety
/// Pending participation/initialized bytes apply; snapshot must be disjoint storage.
#[no_mangle]
pub unsafe extern "C" fn f03_ptrace_resume_pending_lifecycle_result_v1(
    pid: CInt, request: CLong, snapshot: *mut SigInfo, was_present: *mut CInt,
) -> Outcome {
    // SAFETY: Caller supplies writable disjoint initialized output.
    unsafe { was_present.write(0) };
    let Some(tracee) = (unsafe { TraceeReference::acquire(pid, pid) }) else {
        return Outcome { disposition: 1, error: -3 };
    };
    let mut detached = null_mut();
    // SAFETY: Retained positive edge spans detach, retirement and outer guard drop.
    let taken = unsafe { f03_pending_resume_snapshot_selected_v1(
        tracee.thread, request, snapshot, &mut detached) };
    if taken == 2 { return Outcome { disposition: HELD_ALIAS, error: 0 }; }
    if taken == 1 {
        // SAFETY: Source19 transfer invariant, now with same-lock source selection.
        unsafe { free_private_pending(detached); was_present.write(1); }
    }
    Outcome { disposition: COMPLETE, error: 0 }
}
