Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Latest actual result: exact root-granted retained-object suffix PASS60 focused
checks/ABI20+reused25 (a8aa675c), both commands joined0/groups absent/streams closed.
CPU0 was explicitly released to root for its separate process-only action.
No Rust compile or Source20's411 checks were replayed. Independent actual-result
acceptance is pending. Generic destructor still compiled but uncalled/link-GC;
warning exact-once behavior beyond the tested lookup shapes is not established.
See ACTUAL-CONTROLLED-60-AND-CURSOR.json. Preparation/UNRUN text below is retained
history; status/HELD/global-routing/alias/native holds remain unchanged.

Current scope: private default-OFF integration bodies compile. Full runtime
selection remains held. No canonical/shared files, accepted Source20 bytes or
objects, launcher controls, native quarantined parent866814/shared324a or runtime
ownership records were changed. There was no C fixture/root/native execution.

All new bodies compiled in the genuine-layout fixture after one bounded parent
declaration correction. The first failure and exact missing-name diagnostics are
retained. Runtime source bytes did not change between those compiler attempts.
Successful result: parent-declaration-closure-correction-1/
ACTUAL-COMPILE-ONLY-FIRST-RESULT.json (c4130793); object12936B/d8012b72.
The fixture compiles the entire private final-destructor body, not merely its
cleanup helper. Its proposed HOST oracle invokes only optional owned cleanup;
no whole destructor runtime claim is made. CPU0 was explicitly released.

Actual implementations

* pending_thread_lifetime.rs follows actual current CPU -> resource_set ->
  thread_hash, original modulo bucket selection, PID matching and PID==TID
  fallback. Under the real hash reader it acquires only an existing positive
  AtomicI32 Thread.refcount, using the original SeqCst ordering. Zero/negative
  and saturated counts are not incremented, and positive MAX-1 can reach MAX
  without overflow. The original exited-thread warning bridge runs before the
  counter operation under the same hash reader. No old void callback signature
  is changed or interpreted as an admission result.
* pending_lifecycle_callers.rs uses a real retained tracee guard through the
  accepted Source20 producer/getter. Guard drop invokes original thread_unlock
  exactly once, after pending unlock and private-node rollback/commit. Genuine
  CLong usercopy bridges are reused directly. Allocation/free retain tracked
  allocator semantics with meaningful Rust call-site metadata; no unrelated fd
  origin is borrowed. Allocation flags come from genuine immutable C metadata.
* The new resume body chooses the original CONT send-before-receive priority
  inside the same sigcommon writer critical section as Source19's snapshot,
  detach and ownership transfer. Selection before lock acquisition would remain
  racy even if the old take helper later locked. The new function does not
  unlock/relock between source choice and detach. It retires the detached node
  outside the signal lock while its tracee edge remains held. It returns an
  internal presence/outcome record; do_kill/wakeup dispatch is deliberately not
  routed while internal holds have no approved external behavior.
* pending_destroy_integration.rs.inc implements an actual final caller, requiring
  zero in the existing Thread.refcount. It detaches both distinct pending slots
  under sigcommon.lock BEFORE the inherited body takes process.threads_lock.
  Explicit detached ownership then flows into the selected full destructor
  successor. Only its optional cleanup changes: debugreg, receive, send, FP and
  coredump releases keep their original order, but pending nodes come from the
  detached owner record rather than rereading published slots. Ownership is
  cleared before callbacks. release_sigcommon remains after this cleanup.
  If the inherited body fails early, leftover detached nodes retire after return.
  A live-ref/alias refusal stays an internal result; it is not discarded into a
  void destructor callback or silently treated as successful destruction.

Selected ownership findings and exact limits

| Actual selected source | Source-backed fact | Integration consequence |
| --- | --- | --- |
| process_find_thread_body_result -> process_hold_thread_bridge -> hold_thread -> process_ref_inc_direct_result | Hash reader pins membership/storage, but the void hold callback unconditionally fetch_adds. |
| process_release_thread_body_result -> process_destroy_thread_bridge -> destroy_thread -> process_destroy_thread_hash_detach_bridge | Final decrement reaches zero before destructor hash-writer detachment; sigcommon release/thread pages happen after detachment. |
| New positive-only hash lookup | A successful CAS before final decrement retains an actual edge; a zero observed after final decrement is not resurrected. Hash reader delays physical detachment/free during the decision. | This is a source/interleaving diagnosis and candidate repair, pending controlled regression and later native proof. All selected hash lookup routes must adopt positive-only acquisition before claiming zero-ref admission globally. The private checked caller alone cannot repair another legacy lookup resurrecting zero. |
| process_thread_alloc_init_body_result; selected create/clone constructors | Full Thread storage is zeroed before per-field construction; count begins at two. The clone base-state copy covers affinity/in_kernel rather than copying pending slot pointers. |
| process_clone_sigcommon_share_body_result; process_sigcommon_alloc_init_body_result | Construction assigns an existing held sigcommon edge or allocates a new use-count-one sigcommon. Final selected destructor releases it after pending cleanup. | A properly retained Thread edge carries its same constructed sigcommon allocation through usercopy. No new independent pending-node pin is inferred. This remains conditional on balanced real edges and routing final destruction through the stated lifecycle. |
| arch_do_signal_default_pending_transfer_result | Existing selected signal path already owns sigcommon writer/IRQ-save node; it retires old receive/send and publishes the detached incoming node before unlocking. | Preserve the existing function/lock. Do not acquire sigcommon again around it. Incoming ownership must remain detached/unique, with initialized info bytes. |
| process.update_lock at ptrace_wakeup_sig_body_result | Covers trace-syscall flag mutation and is released before pending operations. | New pending selection takes sigcommon only after that lock is released; no new update->sigcommon nesting is proposed. |
| arch_do_signal_trap_stop_result and arch_do_signal_stop_result | Some status stores precede process.update_lock; other stores use it. These are not all protected by sigcommon. | Source20's status/shape observation is not a proof of a common status admission authority. The candidate remains OFF. |
| Original final destructor | process.threads_lock spans optional frees and release_sigcommon. | Early signal detach avoids introducing threads_lock->sigcommon acquisition. The remainder reuses the original lock order, including release_sigcommon after optional cleanup. |

The two first table rows are one combined concrete lifetime counterexample:
last decrement can precede lookup's unconditional increment while the thread is
still hash-visible. They do not prove any native failure occurred. The proposed
positive-only acquisition closes that particular arithmetic admission gap only
when every lookup needing the borrowed hash lifetime uses it. Existing holders
with already-owned positive edges retain their established hold/release route.

Alias induction is conditional on real selected ownership: construction starts
with empty slots; Source20 allocates a fresh unpublished send node; locked resume
detaches one unique node; selected signal transfer consumes a detached incoming
queue node and retires both old distinct allocations; final destruction detaches
before retiring. None of these operations intentionally creates send==receive.
That induction does not authorize ignoring an observed alias, assume initialization
for arbitrary incoming queue bytes, or pretend all legacy paths have cut over.

Current-slot commit remains a proposed behavioral contract, not production
acceptance. A staged operation may commit to replacement current nodes when
status and presence match; this is a possible linearization inside the genuine
signal lock because no borrowed snapshot address is used. It does not detect
identity changes/ABA. Whether a ptrace operation is allowed to affect replacement
pending signals, and what to do on changed shape/status, still requires an actual
API/lifecycle decision. HELD_STATE/HELD_ALIAS are never mapped to syscall errno or
success. Saturated/refused reference acquisition likewise has no approved new
external policy; candidate lookup returns no edge, and no syscall dispatch is
selected from its internal caller error. The private zero-ref destructor's hold
cannot be fitted to the current void release callback without an explicit policy.

Private patch and next executable check

DEFAULT-OFF-KERNEL-INTEGRATION-CURRENT.patch is the current exact private patch
for kernel/syscall.c, syscall_policy.rs, process_helpers.rs and four Rust files.
The earlier DEFAULT-OFF-KERNEL-INTEGRATION.patch is retained source-preparation
history before warning preservation. New C consists only of genuine immutable
allocation-flag metadata and compile-time guards. All runtime algorithms are
Rust; the accepted Source20 Rust module is reused byte-for-byte. Module candidate
cfgs compile independent internal bodies. Selection cfgs deliberately fail at
compile time until the unresolved status/HELD/final-callback contracts are closed.
GLOBAL-POSITIVE-LOOKUP-ROUTING.BLOCKED.patch identifies the precise future global
find_thread branch required by positive-only admission; it is not released.

Current independent-review tuple: READY68521fad, recipe15358e7b, runner7bf36243.
The prepared two-command genuine-header suffix reuses new objectd8012b72 plus
accepted Source20d904db5d with complete filesystem identities. No successful
Rust compilation or Source20's accepted411 regression is replayed. It checks:
36 zero/negative/positive/saturation/PID-fallback/before-lookup-drop cases with
the original warning side effect; six real caller-guard/rollback/internal-hold
cases; ten same-lock resume-priority cases; eight detached optional-cleanup order
cases. New ABI20 plus retained ABI25 are compared with genuine selected headers.
No callback int/long adaptation is invented. C header binding includes the exact
production usercopy typedefs. The link uses section GC solely to discard uncalled
full-destructor dependencies, which are compiled but not exercised by this oracle.
This limitation is explicit in the command purpose and result expectation.

Independent ownership/ABI/source review and a fresh root ordinary CPU0 grant are
required before suffix execution. Retain all raw streams/joins, stop first failure
and follow the existing one-correction convergence rule. No source/controlled
result clears quarantined native ownership, supplies a privileged release, proves
whole-destructor execution or closes default/native/whole-file/C retirement.
