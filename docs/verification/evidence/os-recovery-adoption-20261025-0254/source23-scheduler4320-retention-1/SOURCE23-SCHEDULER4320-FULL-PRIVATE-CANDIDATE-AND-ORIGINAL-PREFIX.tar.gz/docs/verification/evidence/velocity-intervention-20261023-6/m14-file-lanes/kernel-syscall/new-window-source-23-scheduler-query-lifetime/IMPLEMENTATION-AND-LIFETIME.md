Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Source finding, not a native observation: the selected Rust sched_select_thread
foreign branch obtains find_thread's retained reference, immediately calls
thread_unlock, then returns the raw pointer. sched_getparam_body_result later
forms its sched_param source pointer; sched_getscheduler_body_result later reads
sched_policy. Source22's selected caller cohort independently identifies these
consumers. The same shared selector also serves sched_rr_get_interval_body_result;
that third consumer remains OPEN and is not silently repaired by this packet.

This private default-OFF repair adds two explicitly named v2 query exports with
the existing argument widths/provider ABIs: sched_getparam_retained_v2 and
sched_getscheduler_retained_v2. A new query-only selector preserves the exact
negative/null/current-pid normalization and missing-provider errno flow but retains
the positive foreign lookup edge in a noncopyable Rust guard. Current/self/pid0
selection owns no additional edge and performs no find/unlock. The old shared
selector and setter/relookup behavior stay unchanged.

Actual find_thread already releases its lookup hash lock before returning a
positive reference. Consequently the smallest repair retains that reference
through the genuine generic copy_to_user provider, with no hash/IRQ lock held,
then releases the SAME edge exactly once. This follows the coordinator's latest
explicit guidance to retain ownership through faulting copy. No Thread snapshot,
fake object, new allocation, second lookup, field-pointer cast through an old
callback or substitute memory-copy/MM implementation is introduced. The scalar
getscheduler policy is read before releasing the edge and returned afterward.
Neither query uses a thread pointer after release. A guard also pairs any future
normal Rust early return with its actual unlock provider.

The real generic syscall_copy_to_user_bridge returns CLong and retains the actual
MM/fault/tracing and signed-int-to-long conversion boundary. Any nonzero complete
C-long result maps to EFAULT as before, including positive returns whose low32bits
are zero. No int/long function pointer cast is used. Both v2 exports preserve the
actual old generic param_size argument; supported wrappers supply sizeof the
genuine sched_param. The source patch only selects these new Rust calls under
f03_scheduler_query_lifetime_v2. Existing C runtime glue remains byte-identical;
proposed C additions are declarations only. Module/default selectors remain OFF.

Ownership dependency: a positive find callback must actually transfer one positive
reference. Source22 repairs the separate negative/zero acquisition contract. This
consumer does not turn a failed hold into a valid object, change lookup release
counts or establish native lookup acceptance. Actual production integration must
bind a qualified positive-reference lookup successor plus its matching unlock.
The current syscall thread already has its original execution lifetime.

Prepared genuine functional fixture:18 C/Rust geometry/width words plus actual
versioned C function/provider types. The HOST lookup uses posix_memalign with the
real struct thread alignment/size, initializes a real struct thread/process, and
models distinct hash-owner and retained-lookup positive edges. Target exit can
drop the hash owner immediately after lookup or inside usercopy BEFORE its first
source read. The lookup edge must keep that exact allocation alive throughout.
Unlock poisons and frees only after the last edge. No freed storage is read and
no fake Thread object is constructed to satisfy an obsolete callback ABI.

The finite matrix runs2160getparam and2160getscheduler queries:5PIDs x3current-PID
states x8provider/null/notfound configurations x6fullwidth usercopy results x3exit
phases. Independent oracles check errno precedence, current/pid0 no-extra-edge,
positive/NULL lookup, missing providers, matching find/unlock counts, retained
ownership during copy/exit, scalar capture before final release, partial-copy
fault behavior, allocation/free balance and no surviving references. The six copy
results include0,1,-1,INT_MAX+1,+2^32 and-2^32 to expose accidental int truncation.
This fixture validates the caller's ownership protocol using controlled providers;
it is not an actual McKernel process-exit or allocator/native acceptance result.

No old unsafe getter is executed as a counterexample. The defect stays labeled a
source finding until genuine behavior and independent acceptance checks pass.
Next exact check is compile private Rust object, link genuine C header consumer,
run the finite regression under a fresh ordinary CPU0 grant and the retained
h990/AS2G/sharedCPU60/wall90+6/F32/FD256/stack2M/core0 profile. No compiler, fixture,
root, workload query, native or cleanup operation has run for Source23. All prior
accepted Source17/18/20/21 and other owners' work remain untouched.
