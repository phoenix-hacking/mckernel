// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private default-OFF query repair; no change to the shared setter selector.
use super::{SchedSyscallOffsets,SchedFindThreadFn,SchedThreadUnlockFn,SchedCopyToUserFn,
 sched_normalized_pid,sched_thread_pid,sched_thread_policy,sched_errno,EINVAL,ESRCH,EFAULT};
use crate::abi::{CInt,CLong,CULong,SizeT};

struct RetainedQueryThread {
 address:usize,
 release:Option<SchedThreadUnlockFn>,
}
impl Drop for RetainedQueryThread {
 fn drop(&mut self) {
  if let Some(release)=self.release.take() {
   // SAFETY: Exactly one positive lookup edge was transferred to this guard.
   // Current-thread selection owns no such edge and never enters this branch.
   unsafe { release(self.address) };
  }
 }
}

/// Select current or retain the exact foreign allocation through query completion.
/// # Safety
/// Same genuine thread/process/offset/provider contract as the existing selector.
/// Successful foreign lookup returns a positive retained reference with hash lock
/// already dropped. Its matched unlock releases that edge, not an IRQ/state lock.
unsafe fn select_retained_query(
 pid:CInt,current:usize,offsets:&SchedSyscallOffsets,
 find:Option<SchedFindThreadFn>,unlock:Option<SchedThreadUnlockFn>,
)->Result<RetainedQueryThread,CLong> {
 let normalized=unsafe { sched_normalized_pid(pid,current,offsets)? };
 let current_pid=unsafe { sched_thread_pid(current,offsets) };
 if current_pid<0{return Err(sched_errno(EINVAL));}
 if current_pid==normalized{return Ok(RetainedQueryThread{address:current,release:None});}
 let (Some(find),Some(unlock))=(find,unlock) else{return Err(sched_errno(EINVAL));};
 let address=unsafe { find(normalized) };
 if address==0{return Err(sched_errno(ESRCH));}
 Ok(RetainedQueryThread{address,release:Some(unlock)})
}

/// Preserve scheduler parameter copying while holding the genuine lookup reference.
/// # Safety
/// Actual offsets and param_size denote the initialized scheduler parameter span.
/// The generic usercopy provider retains its full C-long ABI/MM/tracing/fault
/// contract. The retained edge pins this exact allocation through faulting copy;
/// no hash/IRQ lock remains held, no fake Thread or second lookup is introduced.
#[no_mangle]
pub unsafe extern "C" fn sched_getparam_retained_v2(
 pid:CInt,uparam:CULong,current:usize,param_size:SizeT,
 offsets:*const SchedSyscallOffsets,find:Option<SchedFindThreadFn>,
 unlock:Option<SchedThreadUnlockFn>,copy:Option<SchedCopyToUserFn>,
)->CLong {
 if uparam==0||pid<0||current==0||offsets.is_null(){return sched_errno(EINVAL);}
 let Some(copy)=copy else{return sched_errno(EINVAL);};
 let offsets=unsafe { &*offsets };
 let selected=match unsafe{select_retained_query(pid,current,offsets,find,unlock)} {
  Ok(value)=>value,Err(error)=>return error,
 };
 let source=selected.address.wrapping_add(offsets.thread_sched_param_offset) as *const u8;
 let copied=unsafe { copy(uparam,source,param_size) };
 // No thread/field pointer is used after the matching lookup edge is released.
 drop(selected);
 if copied!=0{sched_errno(EFAULT)}else{0}
}

/// Read policy while the genuine lookup edge still pins the selected allocation.
/// # Safety
/// Same actual thread/process/offset/lifetime provider contracts as getparam.
#[no_mangle]
pub unsafe extern "C" fn sched_getscheduler_retained_v2(
 pid:CInt,current:usize,offsets:*const SchedSyscallOffsets,
 find:Option<SchedFindThreadFn>,unlock:Option<SchedThreadUnlockFn>,
)->CLong {
 if pid<0||current==0||offsets.is_null(){return sched_errno(EINVAL);}
 let offsets=unsafe { &*offsets };
 let selected=match unsafe{select_retained_query(pid,current,offsets,find,unlock)} {
  Ok(value)=>value,Err(error)=>return error,
 };
 let policy=unsafe { sched_thread_policy(selected.address,offsets) } as CLong;
 drop(selected);
 policy
}
