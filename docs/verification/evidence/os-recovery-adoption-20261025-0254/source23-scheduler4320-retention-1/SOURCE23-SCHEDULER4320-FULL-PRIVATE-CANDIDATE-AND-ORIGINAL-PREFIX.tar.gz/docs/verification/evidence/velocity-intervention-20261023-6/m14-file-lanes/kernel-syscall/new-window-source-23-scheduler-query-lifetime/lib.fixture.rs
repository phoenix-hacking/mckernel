// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
use core::ptr::read_volatile;
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use abi::{CInt,CLong,CULong,SizeT};
const EINVAL:CInt=22;const ESRCH:CInt=3;const EFAULT:CInt=14;
type SchedFindThreadFn = unsafe extern "C" fn(CInt) -> usize;
type SchedThreadUnlockFn = unsafe extern "C" fn(usize);
type SchedCopyToUserFn = unsafe extern "C" fn(CULong, *const u8, SizeT) -> CLong;
#[repr(C)]
pub struct SchedSyscallOffsets {
    pub thread_proc_offset: SizeT,
    pub thread_sched_param_offset: SizeT,
    pub thread_sched_policy_offset: SizeT,
    pub thread_cpu_id_offset: SizeT,
    pub thread_cpu_set_offset: SizeT,
    pub proc_pid_offset: SizeT,
    pub proc_ruid_offset: SizeT,
    pub proc_euid_offset: SizeT,
    pub proc_cpu_set_offset: SizeT,
}
include!("ACTUAL-QUERY-HELPERS.REUSED.rs.inc");
#[path="f03_scheduler_query_lifetime_v2.rs"] mod f03_scheduler_query_lifetime_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f03_sched_query_Rust_ABI:[usize;18]=[size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),offset_of!(abi::Thread,sched_param),offset_of!(abi::Thread,sched_policy),size_of::<abi::Process>(),align_of::<abi::Process>(),offset_of!(abi::Process,pid),size_of::<abi::SchedParam>(),align_of::<abi::SchedParam>(),offset_of!(abi::SchedParam,sched_priority),size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),size_of::<Option<SchedFindThreadFn>>(),size_of::<Option<SchedThreadUnlockFn>>(),size_of::<Option<SchedCopyToUserFn>>(),size_of::<CLong>(),align_of::<CLong>()];
