"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Private CPU37 actual ELF/type/initializer/allocated/partial observations; no ISA or kernel calls.
"""
from pathlib import Path
import ast,hashlib,json,struct,types
D=Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1');P=json.loads((D/'CPU37-OBSERVATION-CONTRACT.json').read_bytes());O=D/'output-1';A=Path(__file__).parent/'storage-observation-1';A.mkdir(mode=0o700)
def write(p,o):
 with Path(p).open('x') as f:json.dump(o,f,indent=2,sort_keys=True);f.write('\n')
def defs(row,names=None,extra=None):
 path=Path(row['path']);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];tree=ast.parse(raw)
 selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,(ast.FunctionDef,ast.ClassDef)) and (names is None or n.name in names)]
 if names and 'COMPILER_NOTE_PAYLOAD' in names:selected += [n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='COMPILER_NOTE_PAYLOAD' for t in n.targets)]
 ns=dict(Path=Path,struct=struct,json=json,hashlib=hashlib,cap=types.SimpleNamespace(write=write),A=A)
 if extra:ns.update(extra)
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),ns);return ns
f=defs(P['Elf_source'],{'Elf','COMPILER_NOTE_PAYLOAD','exact_compiler_note','selected_c_data_gate','owning_relocations','defined_object','object_bytes'})
cpu=defs(P['CPU29_observer'],extra=f);Elf=f['Elf'];obj=f['defined_object'];data=f['object_bytes'];relas=f['owning_relocations']
rust=Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-30-fullcrate-logger-internal-linkage/output-1/candidate.o'));selected=Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-3/ordinary-HOST-qualification-preparation-1/bounded-C-include-namespace-transport-correction-1/output-1/F04.selected.o'));abi=Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-3/ordinary-HOST-qualification-preparation-1/bounded-C-include-namespace-transport-correction-1/output-1/F04.ABI66-signatures.o'));partial=Elf(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-30-fullcrate-logger-internal-linkage/follow-on-source-only/output-1/CPU37.partial.o'));reference=Elf(Path(P['old_reference_C']['path']))
def named(e,name,typ):
 rows=[r for r in e.symbols if r['name']==name];defined=[r for r in rows if r['bind']==1 and r['type']==typ and 0<r['shndx']<len(e.sections)]
 assert len(defined)==1 and not [r for r in rows if r['shndx']==0],(name,rows)
 return defined[0]
def bytes_for(e,name):return data(e,obj(e,name))
def cstring(e,row):
 t=row['target'];assert row['type']==1 and 0<t['shndx']<len(e.sections)
 sec=e.sections[t['shndx']];start=t['value']+row['addend'];payload=e.payload(sec)
 assert sec['flags']&2 and 0<=start<len(payload);end=payload.index(b'\0',start);return payload[start:end].decode()
def readonly(e,symbol):
 sec=e.sections[symbol['shndx']];assert sec['flags']&2 and not sec['flags']&5,(symbol,sec)
 return sec
# All genuine selected bodies remain Rust; storage equality does not prove
# IRQ callback/fd lifetimes or the inherited freeze(NULL) behavior.
asm_prior={'native_user_read_u32_fault','native_user_read_u32_recover','native_xrstor_fault','native_xrstor_recover'}
prior_names={}
for row in rust.symbols:prior_names.setdefault(row['name'],[]).append(row)
for name in P['expected_all_prior_Rust_T']:
 rows=[r for r in prior_names.get(name,[]) if r['bind']==1 and 0<r['shndx']<len(rust.sections)];assert len(rows)==1 and not any(r['shndx']==0 for r in prior_names.get(name,[]))
 assert rows[0]['type']==(0 if name in asm_prior else 2)
 if name in asm_prior:assert rows[0]['size']==0 and rust.sections[rows[0]['shndx']]['flags']&6==6
for name in P['old100_targets']:named(rust,name,2);named(partial,name,2)
f['selected_c_data_gate'](selected)
old29=cpu['cpu_storage_proof'](rust,abi,partial,P['old29_plan']);write(A/'ACTUAL-PRIOR29-RETAINED-REAL-ABI-AND-PARTIAL.json',old29)
# Real selected headers derive all layouts; no surrogate structures or offsets.
assert abi.data('M14_ACTUAL_C_IRQ_HANDLER_LAYOUT')==bytes_for(rust,'x86_main_irq_handler_layout')
assert len(abi.data('M14_ACTUAL_C_IRQ_HANDLER_LAYOUT'))==9*8
assert abi.data('M14_REAL_C_CPU_INFO_LAYOUT')==bytes_for(rust,'M14_REAL_RUST_CPU_INFO_LAYOUT')
assert len(abi.data('M14_REAL_C_CPU_INFO_LAYOUT'))==8*8
words=struct.unpack('<8Q',abi.data('M14_REAL_C_CPU_INFO_LAYOUT'))
assert abi.word('CPU37_REAL_SIZE_'+str(P['new37'].index('x86_cpu_info_ncpus_offset')))==8
assert int.from_bytes(bytes_for(rust,'x86_cpu_info_ncpus_offset'),'little')==words[2]
assert struct.unpack('<5Q',abi.data('M14_REAL_C_DDEBUG_LAYOUT'))==(32,8,0,8,16)
bits=abi.data('M14_REAL_C_DDEBUG_BITS');assert len(bits)==32 and int.from_bytes(bits[24:28],'little')==0x5aabcdef
verbose={r['name']:r for r in P['verbose']};proof={}
for i,name in enumerate(P['new37']):
 s=obj(rust,name);p=obj(partial,name);c=obj(reference,name)
 size=abi.word('CPU37_REAL_SIZE_'+str(i));align=abi.word('CPU37_REAL_ALIGN_'+str(i))
 assert s['size']==p['size']==c['size']==size
 for e,sy in ((rust,s),(partial,p)):
  sec=e.sections[sy['shndx']];assert sec['flags']&2 and not sec['flags']&4 and sec['align']>=align and sy['value']%align==0
 assert not [r for r in selected.symbols if r['name']==name and r['shndx']!=0],('C provider remains',name)
 rb=data(rust,s);pb=data(partial,p);cb=data(reference,c);assert rb==pb==cb,(name,'actual original initial bytes')
 rr=relas(rust,s);pr=relas(partial,p);cr=relas(reference,c)
 if name in verbose:
  record=verbose[name];assert size==record['records']*32
  assert rust.sections[s['shndx']]['name']==partial.sections[p['shndx']]['name']=='__verbose'
  assert rust.sections[s['shndx']]['flags']&3==3 and partial.sections[p['shndx']]['flags']&3==3
  for n,expect in enumerate(record['entries']):
   start=n*32;assert int.from_bytes(rb[start+24:start+28],'little')==expect['line'] and expect['flags']==0
   assert rb[start+16:start+24]==bytes(8) and rb[start+28:start+32]==bytes(4)
   for elf,rows,filename in ((reference,cr,P['old_reference_C_source_spelling']),(rust,rr,P['new_source_spelling']),(partial,pr,P['new_source_spelling'])):
    local=[r for r in rows if start<=r['offset']<start+32];assert len(local)==2 and {r['offset']-start for r in local}=={0,8}
    for r in local:assert cstring(elf,r)==(filename if r['offset']==start else expect['func'])
  assert len(rr)==len(pr)==len(cr)==record['records']*2
 elif name in P['slot_targets']:
  wanted=P['slot_targets'][name];assert size==8 and align==8
  readonly(rust,s);readonly(partial,p)
  for elf,rows in ((reference,cr),(rust,rr),(partial,pr)):
   assert len(rows)==1 and rows[0]['offset']==0 and rows[0]['type']==1 and rows[0]['addend']==0
   assert rows[0]['target']['name']==wanted
  target=obj(rust,wanted);linked=obj(partial,wanted);assert target['size']==linked['size']
 elif name=='gettime_local_support':
  assert size==4 and rb==bytes(4) and rust.sections[s['shndx']]['flags']&3==3 and partial.sections[p['shndx']]['flags']&3==3
  assert not rr and not pr and not cr
 else:
  readonly(rust,s);readonly(partial,p);assert not rr and not pr and not cr
 proof[name]=dict(Rust=s,partial=p,real_C_original=c,real_C_size=size,real_C_alignment=align,exact_initializer_bytes=rb.hex(),Rust_relocations=rr,partial_relocations=pr,actual_C_reference_relocations=cr,original_C_reference_current81=True)
assert len(proof)==37 and sum(x['records'] for x in P['verbose'])==27 and len(verbose)==8
# Observe actual ALLOC consumers once; immutable constants may fold and are not
# assigned fictional C U/call edges. Exact pointer-field relocations above remain mandatory.
edges=[]
new_symbols={name:obj(rust,name) for name in P['new37']}
for sec in rust.sections:
 if sec['type']!=4 or not rust.sections[sec['info']]['flags']&2:continue
 assert sec['link']==rust.table['index'] and sec['entsize']==24 and sec['size']%24==0
 owner=rust.sections[sec['info']]
 for j in range(sec['size']//24):
  off,info,addend=struct.unpack_from('<QQq',rust.raw,sec['offset']+j*24);assert off<owner['size'] and info>>32<len(rust.symbols)
  target=rust.symbols[info>>32]
  if target['shndx']==0:continue
  where=target['value']+addend
  for name in P['new37']:
   sy=new_symbols[name]
   if target['shndx']==sy['shndx'] and sy['value']<=where<sy['value']+sy['size']:edges.append(dict(owner_section=sec['info'],offset=off,type=info&0xffffffff,target_name=name,target_relative=where-sy['value'],addend=addend))
write(A/'ACTUAL-NEW37-REAL-ABI-INITIALIZER-POINTER-DEBUG-AND-PARTIAL.json',dict(status='PASS_ACTUAL_NEW37_STORAGE_PLUS_PRIOR29_TYPED_INITIALIZERS_ALLOCATED_PARTIAL_ONLY',providers=proof,debug_records=27,actual_allocated_consumer_edges=edges,all37_C_imports_claimed=False,mainIRQ_lifetime='HOLD',NULLfreeze='HOLD',hardware_ISA_executed=False,default_GCC14=None,native=None,wholefile_retirement=None))
print(json.dumps(dict(status='PASS_CPU66_STORAGE_REAL_ABI_INITIALIZERS_ALLOCATED_PARTIAL_ONLY',new37=37,prior29=29,debug_records=27,default_native=False)))
