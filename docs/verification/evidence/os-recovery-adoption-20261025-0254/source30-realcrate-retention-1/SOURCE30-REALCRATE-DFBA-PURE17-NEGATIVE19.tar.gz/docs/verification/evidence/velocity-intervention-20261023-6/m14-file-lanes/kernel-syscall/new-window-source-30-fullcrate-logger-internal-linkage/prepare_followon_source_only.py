"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare static follow-on source templates; no object hash, no executable release.
"""
from pathlib import Path
import ast,difflib,hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
OLD=BASE/'new-window-source-28-selected-c-abi-partial-link/expert-artifact-path-correction-1'
NEXT=ROOT/'follow-on-source-only'
NEXT.mkdir(mode=0o700)
old=json.loads((OLD/'EXACT-SELECTED-C-ABI-STRICT-PARTIAL.FROZEN-NOT-GRANTED.json').read_text())
RUST=str(ROOT/'output-1/candidate.o');PARTIAL=str(NEXT/'output-1/CPU37.partial.o');POLICY=str(ROOT/'candidate/kernel/rust/syscall_policy.rs')
old_rust=old['new_Rust_object']['path'];old_partial=old['commands'][2]['argv'][3]
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def assignment(text,name,prior,new):
 nodes=[n for n in ast.parse(text).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name];assert len(nodes)==1
 value=nodes[0].value;assert ast.dump(value)==ast.dump(ast.parse(prior,mode='eval').body)
 lines=text.splitlines(True);assert value.lineno==value.end_lineno;i=value.lineno-1
 lines[i]=lines[i][:value.col_offset]+new+lines[i][value.end_col_offset:];return ''.join(lines)
rows=[]
for name in ['retained_observe_current290.py','retained_observe_current_F04_storage.py','retained_observe_new_metadata.py','observe_changed_boundary.py']:
 original=(OLD/name).read_text();new=original
 if name!='observe_changed_boundary.py':
  new=assignment(new,'rust','Elf(Path('+repr(old_rust)+'))','Elf(Path('+repr(RUST)+'))')
  new=assignment(new,'partial','Elf(Path('+repr(old_partial)+'))','Elf(Path('+repr(PARTIAL)+'))')
 if name=='retained_observe_current290.py':
  # Only the remaining explicit trace tuple path uses this old partial literal.
  assert new.count(old_partial)==1;new=new.replace(old_partial,PARTIAL)
 if name=='retained_observe_new_metadata.py':
  old_policy=str(Path(old_rust).parents[1]/'candidate/kernel/rust/syscall_policy.rs')
  new=assignment(new,'policy','Path('+repr(old_policy)+')','Path('+repr(POLICY)+')')
 with (NEXT/name).open('x') as f:f.write(new)
 rows.append(dict(original=pin(OLD/name),successor=pin(NEXT/name),delta=''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='Source28/'+name,tofile='Source30-followon/'+name))))
# Keep the expert validator algorithm and19negatives; freeze the real new SHA only
# after the genuine compiler record exists. Until then this template fails closed.
preflight=(OLD/'preflight_artifact_roles_pure.py').read_text()
preflight=preflight.replace("RUST_SHA='6057a688c5566214a76a045b098cb9b914c4a22c09c06fc8264835f17788a43e'","RUST_SHA='__BIND_SOURCE30_ACTUAL_COMPILER_OBJECT_SHA_BEFORE_EXECUTION__'")
preflight=preflight.replace("recipe['commands'][2]","recipe['commands'][0]").replace("command['name'].startswith('02-')","command['name'].startswith('00-')").replace("replaced['commands'][2]","replaced['commands'][0]")
with (NEXT/'preflight_artifact_roles_pure.TEMPLATE-NOT-EXECUTABLE.py').open('x') as f:f.write(preflight)
commands=[]
link=json.loads(json.dumps(old['commands'][2]));link['name']='00-retained-four-C-new-Source30-partial';link['cwd']=str(NEXT);link['argv'][3]=PARTIAL;link['argv'][-1]=RUST;link['purpose']=old['scope']+' Retained same four selected C objects plus new genuine Source30 Rust object; no old Rust/image rebuild, C compiler or runtime action.';commands.append(link)
for index,prior in enumerate(old['commands'][3:],1):
 command=json.loads(json.dumps(prior));command['name']=f'{index:02d}-'+prior['name'][3:];command['cwd']=str(NEXT);command['argv'][-1]=str(NEXT/Path(command['argv'][-1]).name);commands.append(command)
assert len(commands)==5
inputs={r['path']:r for r in old['inputs']}
for row in rows:inputs[row['successor']['path']]=row['successor']
inputs[POLICY]=pin(POLICY)
pending=dict(scope=old['scope'],status='PROVISIONAL_SOURCE_ONLY_INCOMPLETE_UNTIL_REAL_SOURCE30_OBJECT_AND_FRESH_REVIEW',commands=commands,inputs=list(inputs.values()),sources=[],canonical_origins=[],header_bindings=[],tools=old['tools'],fixture_tools=old['fixture_tools'],absent_include_namespaces=old['absent_include_namespaces'],selected_C_objects=old['selected_C_objects'],new_Rust_object=dict(path=RUST,sha256=None,bytes=None,status='PENDING_GENUINE_SOURCE30_COMPILER_RESULT_DO_NOT_EXECUTE'),Elf_source=old['Elf_source'],pure_preflight=dict(actual_baselines=old['pure_preflight']['actual_baselines'],consumed_artifact_closure=old['pure_preflight']['consumed_artifact_closure'],changed_boundary_original=old['pure_preflight']['changed_boundary_original'],template=pin(NEXT/'preflight_artifact_roles_pure.TEMPLATE-NOT-EXECUTABLE.py'),mandatory='After actual new Source30object hash bound, generate frozen exactSHA preflight from expert template and run1positive/19negatives under ROOTgrant; then new independent review+ROOT5command suffix grant.'),newpolicy=pin(POLICY),retained_C_syntax_ABI_prefix=dict(artifact=pin(OLD/'ACTUAL-QUALIFICATION-FIRST-FAILURE-AND-RELEASE.json'),indices=[0,1],scope='Reuse only unchanged selected C versioned declarations/type witnesses; no compiler replay. Source30 changes no C or callback signature.'),strict_assertions_unchanged=[143,38,139],original_LOCAL_logger_oracle_unchanged=True,new13symbol_observer_byte_identical=True,transport_deltas=rows,no_default_or_native=True,executions_authorized=0)
with (NEXT/'FOLLOWON-RETAINED-C-STRICT-PARTIAL.PROVISIONAL-NOT-EXECUTABLE.json').open('x') as f:json.dump(pending,f,indent=2);f.write('\n')
print(json.dumps(dict(status=pending['status'],commands=5,source_only=True,actual_newobject_hash_bound=False)))
