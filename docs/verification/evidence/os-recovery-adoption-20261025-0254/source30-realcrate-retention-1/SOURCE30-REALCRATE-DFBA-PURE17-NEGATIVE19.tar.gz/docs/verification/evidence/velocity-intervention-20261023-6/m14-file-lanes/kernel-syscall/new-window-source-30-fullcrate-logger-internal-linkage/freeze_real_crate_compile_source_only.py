"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Freeze one genuine 77-module Rust compiler prefix; execute no commands.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
OLD=BASE/'new-window-source-27-scheduler-lifetime-selected-crate-integration/module-resolution-correction-1'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
 with (ROOT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
previous=json.loads((OLD/'EXACT-REAL-CRATE-COMPILE-ONLY.ROOT-GRANTED.json').read_text())
command=json.loads(json.dumps(previous['commands'][0]));argv=command['argv']
indices=[i for i,x in enumerate(argv) if x.startswith('--emit=obj=')];assert len(indices)==1
argv[indices[0]]='--emit=obj='+str(ROOT/'output-1/candidate.o')
assert argv[-1]==str(OLD/'candidate/kernel/rust/lib.rs');argv[-1]=str(ROOT/'candidate/kernel/rust/lib.rs')
command.update(name='00-real77module-fullcrate-explicit-internal-logger-object',cwd=str(ROOT),purpose=SCOPE+' One real selected 77-module kernel Rust crate compile with only rootfeature(linkage)+4loggerinternalattrs; no old6057 rebuild/output overwrite, C compiler/link/runtime/native/default action.')
manifest=json.loads((ROOT/'SOURCE30-EXACT-FIVE-LINKAGE-ADDITIONS.SOURCE.json').read_text())
inputs=[row['successor'] for row in manifest['files']]
inputs += [pin(ROOT/'SOURCE30-EXACT-FIVE-LINKAGE-ADDITIONS.SOURCE.json'),pin(ROOT/'EXACT-FIVE-LINKAGE-ADDITIONS.patch'),pin(OLD/'EXACT-REAL-CRATE-COMPILE-ONLY.ROOT-GRANTED.json'),pin(ROOT/'prepare_source_only.py')]
# Original helper metadata and compiler/sysroot sources remain exactly bound;
# mutable original canonical sources are retained as provenance in the manifest.
for row in previous['inputs']:
 if not row['path'].startswith(str(OLD/'candidate')+'/'):inputs.append(row)
recipe=dict(scope=SCOPE,status='SOURCE_ONLY_GENUINE_FULLCRATE_LINKAGE_FIX_PREFIX_NOT_GRANTED',commands=[command],inputs=inputs,sources=previous['sources'],canonical_origins=[],header_bindings=[],tools=previous['tools'],fixture_tools=previous['fixture_tools'],retained_e517_producer=previous['retained_e517_producer'],new_cfgs=previous['new_cfgs'],genuine_ABI_appendix_bytes=38654,actual_modules=77,private_files=88,exact_changed_file_count=2,explicit_delta='Root feature(linkage),4internalattrs; genuine source/output/privatecwd transport only; all flags/cfg/codegen/sysroot unchanged.',original6057=pin(OLD/'output-1/candidate.o'),requirements=['ROOT exact one-command ordinaryCPU0 grant and fresh profile floors required.','Preserve new unsuppressed diagnostics; compile alone proves neither original LOCAL predicate nor kernel ABI/link/native acceptance.','After actual object hash frozen, bind fresh follow-on observer paths and reuse expert17role preflight before separate ROOT partial/static-observer grant.'])
name='EXACT-REAL77MODULE-LOGGER-INTERNAL-COMPILE.NOT-GRANTED.json';write(name,recipe);sha=pin(ROOT/name)['sha256']
runner=(OLD/'run_real_crate_compile_once.ROOT-GRANTED.py').read_text()
runner=runner.replace('Source27 real selected full-kernel compile-only prefix; fresh exact root grant required before execution.','Source30 genuine selected full-kernel explicit-internal logger compile-only prefix; fresh exact ROOT grant required.')
# Replace the original exact prefix recipe and its known source-bound digest only.
assert "RECIPE_SHA = '39bea86a0a77dd9d719665c31c3ef1d5c784cc39c31ab72628392575798dbcc9'" in runner
runner=runner.replace("RECIPE = ROOT / 'EXACT-REAL-CRATE-COMPILE-ONLY.ROOT-GRANTED.json'","RECIPE = ROOT / '"+name+"'").replace("RECIPE_SHA = '39bea86a0a77dd9d719665c31c3ef1d5c784cc39c31ab72628392575798dbcc9'","RECIPE_SHA = '"+sha+"'")
runner=runner.replace("recipe = json.loads(RECIPE.read_text())", "recipe = json.loads(RECIPE.read_text())\n        grant = json.loads((ROOT / 'ROOT-EXACT-SOURCE30-COMPILE-GRANT.json').read_text())\n        if grant['recipe']['sha256'] != RECIPE_SHA or grant['runner'] != pin(Path(__file__)):\n            raise RuntimeError('missing exact durable ROOT source30 compile grant')")
runner=runner.replace("RESULT = ROOT / 'ACTUAL-REAL-CRATE-COMPILE-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE30-REAL77MODULE-COMPILE-FIRST-RESULT.json'")
runner=runner.replace("authority='Exact durable root grant: private Rust object compile only; no C fixture, runtime, native, default or acceptance claim.'","authority='Exact durable ROOT Source30 one real77module Rust compiler grant only; no C, link, observer, fixture, runtime, native or default action.'")
with (ROOT/'run_real77module_linkage_compile_once.NOT-GRANTED.py').open('x') as f:f.write(runner)
ready=dict(scope=SCOPE,status='SOURCE_ONLY_REAL77MODULE_LINKAGE_FIX_READY_FOR_REVIEW_AND_ROOT_GRANT',recipe=pin(ROOT/name),runner=pin(ROOT/'run_real77module_linkage_compile_once.NOT-GRANTED.py'),manifest=pin(ROOT/'SOURCE30-EXACT-FIVE-LINKAGE-ADDITIONS.SOURCE.json'),patch=pin(ROOT/'EXACT-FIVE-LINKAGE-ADDITIONS.patch'),actual_compiles=0,unchanged_files=86,kernel_ABI=False,LOCAL_oracle_passed=False,native=False,default=False)
write('READY-SOURCE30-REAL77MODULE-COMPILE.NOT-GRANTED.json',ready)
bootstrap="import os,sys,hashlib; p=sys.argv[1]; fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC); raw=os.read(fd,1048576); st=os.fstat(fd); assert len(raw)==st.st_size and hashlib.sha256(raw).hexdigest()==sys.argv[2], 'source FD binding mismatch'; ns={'__name__':'__main__','__file__':p}; exec(compile(raw,p,'exec'),ns)"
fields=dict(scope=SCOPE,status='PREPARED_FIELDS_NOT_A_GRANT',ready=pin(ROOT/'READY-SOURCE30-REAL77MODULE-COMPILE.NOT-GRANTED.json'),recipe=ready['recipe'],runner=ready['runner'],launch_argv=['/usr/bin/taskset','-c','0','/home/holden/anaconda3/bin/python3','-c',bootstrap,ready['runner']['path'],ready['runner']['sha256']],execution_count=1,profile=dict(CPU=0,jobs=1,UID=1000,AS_bytes=2<<30,CPU_seconds=60,wall_seconds=90,retirement_seconds=6,file_bytes=32<<20,FDs=256,stack_bytes=2<<20,core_bytes=0,MemAvailable_min_bytes=25501368320,host_floor_bytes=(16<<30)+(64<<20),scratch_floor_bytes=12<<30,aggregate_GiB=22.0485),fullcrate_commands=1,no_C_link_ELF_fixture_runtime_or_native=True)
write('ROOT-EXACT-SOURCE30-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
print(json.dumps(dict(READY=fields['ready'],recipe=ready['recipe'],runner=ready['runner'],actual_modules=77,private_files=88,unchanged_files=86)))
