// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private default-OFF query repair; no change to the shared setter selector.
use super::{SchedSyscallOffsets,SchedFindThreadFn,SchedThreadUnlockFn,SchedCopyToUserFn,
 sched_thread_policy,sched_errno,EINVAL,EFAULT};
use crate::abi::{CInt,CLong,CULong,SizeT};

use super::sched_retained_target::select_retained_query;

/// Preserve scheduler parameter copying while holding the genuine lookup reference.
/// # Safety
/// Actual offsets and param_size denote the initialized scheduler parameter span.
/// The generic usercopy provider retains its full C-long ABI/MM/tracing/fault
/// contract. The retained edge pins this exact allocation through faulting copy;
/// no hash/IRQ lock remains held, no fake Thread or second lookup is introduced.
#[no_mangle]
pub unsafe extern "C" fn sched_getparam_retained_v2(
 pid:CInt,uparam:CULong,current:usize,param_size:SizeT,
 offsets:*const SchedSyscallOffsets,find:Option<SchedFindThreadFn>,
 unlock:Option<SchedThreadUnlockFn>,copy:Option<SchedCopyToUserFn>,
)->CLong {
 if uparam==0||pid<0||current==0||offsets.is_null(){return sched_errno(EINVAL);}
 let Some(copy)=copy else{return sched_errno(EINVAL);};
 let offsets=unsafe { &*offsets };
 let selected=match unsafe{select_retained_query(pid,current,offsets,find,unlock)} {
  Ok(value)=>value,Err(error)=>return error,
 };
 let source=selected.address.wrapping_add(offsets.thread_sched_param_offset) as *const u8;
 let copied=unsafe { copy(uparam,source,param_size) };
 // No thread/field pointer is used after the matching lookup edge is released.
 drop(selected);
 if copied!=0{sched_errno(EFAULT)}else{0}
}

/// Read policy while the genuine lookup edge still pins the selected allocation.
/// # Safety
/// Same actual thread/process/offset/lifetime provider contracts as getparam.
#[no_mangle]
pub unsafe extern "C" fn sched_getscheduler_retained_v2(
 pid:CInt,current:usize,offsets:*const SchedSyscallOffsets,
 find:Option<SchedFindThreadFn>,unlock:Option<SchedThreadUnlockFn>,
)->CLong {
 if pid<0||current==0||offsets.is_null(){return sched_errno(EINVAL);}
 let offsets=unsafe { &*offsets };
 let selected=match unsafe{select_retained_query(pid,current,offsets,find,unlock)} {
  Ok(value)=>value,Err(error)=>return error,
 };
 let policy=unsafe { sched_thread_policy(selected.address,offsets) } as CLong;
 drop(selected);
 policy
}
