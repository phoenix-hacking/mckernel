// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private default-OFF setter repair. Getter and shared legacy selector stay unchanged.
use super::{
    sched_errno, sched_thread_policy,
    SchedApplySchedulerFn, SchedCopyFromUserFn, SchedDoSyscall2Fn,
    SchedFindThreadFn, SchedSyscallOffsets, SchedThreadUnlockFn,
    EFAULT, EINVAL, SCHED_CHECK_SAME_OWNER,
};
use crate::abi::{CInt, CLong, CULong, SizeT};

// Exact Source23 private guard/selection implementation, without getter bodies.
// It transfers one actual foreign lookup edge; Drop consumes it exactly once.
use super::sched_retained_target::select_retained_query;

/// Set parameters on the SAME retained allocation selected before ownership check.
///
/// # Safety
/// Genuine offsets and param_size identify initialized scheduler fields/storage.
/// Foreign find returns one positive actual Thread reference, with the hash lock
/// released. Its matching unlock consumes that edge. Current-thread selection
/// borrows the original live syscall thread and acquires no extra edge.
/// Existing syscall2/copy/apply ABI and runtime/MM/runqueue-lock contracts apply.
/// No hash or IRQ lock is held across offload, faulting copy or apply. A reference
/// pins allocation identity, not scheduler-field serialization; the latter remains
/// the original provider's responsibility and needs native qualification.
#[no_mangle]
pub unsafe extern "C" fn sched_setparam_retained_v2(
    pid: CInt, uparam_addr: CULong, current_thread: usize,
    param_addr: usize, param_size: SizeT, offsets: *const SchedSyscallOffsets,
    syscall_nr: CInt, find: Option<SchedFindThreadFn>, unlock: Option<SchedThreadUnlockFn>,
    copy_from: Option<SchedCopyFromUserFn>, syscall2: Option<SchedDoSyscall2Fn>,
    apply: Option<SchedApplySchedulerFn>,
) -> CLong {
    if uparam_addr == 0 || pid < 0 || current_thread == 0 || param_addr == 0 || offsets.is_null() {
        return sched_errno(EINVAL);
    }
    let Some(copy_from) = copy_from else { return sched_errno(EINVAL); };
    let Some(apply) = apply else { return sched_errno(EINVAL); };
    // SAFETY: Same metadata and selection order as the original setparam body.
    let offsets = unsafe { &*offsets };
    let selected = match unsafe {
        select_retained_query(pid, current_thread, offsets, find, unlock)
    } {
        Ok(selected) => selected,
        Err(error) => return error,
    };

    if selected.release.is_some() {
        let Some(syscall2) = syscall2 else { return sched_errno(EINVAL); };
        // SAFETY: The reused selector can return foreign only for nonzero pid;
        // normalized_pid then equals the original pid. Keep the original check's
        // number/operation/argument, with the original allocation still retained.
        let checked = unsafe { syscall2(syscall_nr, SCHED_CHECK_SAME_OWNER, pid as CULong) };
        if checked != 0 { return checked; }
    }

    // SAFETY: Private caller-owned scratch, genuine signed C-long usercopy ABI.
    // Preserve original semantics: only negative copy results map to EFAULT.
    let copied = unsafe { copy_from(param_addr as *mut u8, uparam_addr, param_size) };
    if copied < 0 { return sched_errno(EFAULT); }

    // SAFETY: The original allocation is still pinned, even if the numeric ID was
    // removed/rebound during offload/copy. Read policy after copy as before, then
    // use the same genuine apply provider and its established runqueue locks.
    let policy = unsafe { sched_thread_policy(selected.address, offsets) };
    let applied = unsafe { apply(selected.address, policy, param_addr) } as CLong;
    drop(selected);
    applied
}
