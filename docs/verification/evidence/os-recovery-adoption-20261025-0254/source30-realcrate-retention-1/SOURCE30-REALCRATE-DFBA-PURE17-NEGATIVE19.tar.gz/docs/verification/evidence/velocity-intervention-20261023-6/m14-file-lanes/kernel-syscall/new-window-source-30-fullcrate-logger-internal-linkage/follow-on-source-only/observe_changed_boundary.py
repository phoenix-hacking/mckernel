"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Changed-boundary ELF ownership and actual ALLOC RELA; no runtime execution.
"""
from pathlib import Path
import ast,hashlib,json,struct
ROOT=Path(__file__).resolve().parent
recipe=json.loads((ROOT/'EXACT-SELECTED-C-ABI-STRICT-PARTIAL.FROZEN-NOT-GRANTED.json').read_bytes())
row=recipe['Elf_source'];raw=Path(row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.ClassDef) and n.name=='Elf']
ns=dict(Path=Path,struct=struct);exec(compile(ast.Module(body=nodes,type_ignores=[]),row['path'],'exec'),ns)
Elf=ns['Elf'];rust=Elf(Path(recipe['new_Rust_object']['path']));partial=Elf(ROOT/'output-1/CPU37.partial.o')
components=[Elf(Path(row['path'])) for row in recipe['selected_C_objects']]
names=['process_try_hold_thread_live_v2','process_find_thread_live_body_result_v2','sched_getparam_retained_v2','sched_getscheduler_retained_v2','sched_setparam_retained_v2','sched_rr_get_interval_retained_v2']
entries=['find_thread','sched_find_thread_bridge','sched_thread_unlock_bridge','sys_sched_getparam','sys_sched_getscheduler','sys_sched_setparam','sys_sched_rr_get_interval']
def defined(e,name):return [r for r in e.symbols if r['name']==name and 0<r['shndx']<len(e.sections)]
proof={}
for name in names+entries:
 pair={}
 for label,e in [('Rust',rust),('partial',partial)]:
  rows=defined(e,name);assert len(rows)==1 and rows[0]['bind']==1 and rows[0]['type']==2,(name,label,rows)
  assert not [r for r in e.symbols if r['name']==name and r['shndx']==0],(name,label,'unresolved')
  pair[label]=rows[0]
 for c in components:assert not defined(c,name),(name,'retained C definition')
 proof[name]=pair
edges=[]
for label,e in [('Rust',rust),('partial',partial)]:
 for sec in e.sections:
  if sec['type']!=4 or not e.sections[sec['info']]['flags']&2:continue
  assert sec['link']==e.table['index'] and sec['entsize']==24 and sec['size']%24==0
  owner=e.sections[sec['info']]
  for index in range(sec['size']//24):
   offset,info,addend=struct.unpack_from('<QQq',e.raw,sec['offset']+index*24)
   assert offset<owner['size'] and info>>32<len(e.symbols)
   target=e.symbols[info>>32]
   if target['name'] not in names:continue
   callers=[r['name'] for r in e.symbols if r['type']==2 and r['shndx']==sec['info'] and r['value']<=offset<r['value']+r['size']]
   edges.append(dict(artifact=label,owner_section=owner['name'],owner_flags=owner['flags'],offset=offset,type=info&0xffffffff,addend=addend,target=target['name'],instruction_owners=callers))
result=dict(scope=recipe['scope'],status='PASS_CHANGED_BOUNDARY_DEFINED_OWNERSHIP_AND_OBSERVED_ALLOC_RELA_ONLY',definitions=proof,allocated_edges=edges,edge_limit='Optimization may inline local calls; source selection and actual emitted edge observations are separate. No fabricated U/call edge.',ABI_limit='ELF symbols carry no C function types. C static assertions plus genuine Rust source signatures provide the type evidence; this object check is ownership only.',Rust_object=recipe['new_Rust_object'],default=False,native=False)
with (ROOT/'ACTUAL-CHANGED-BOUNDARY-OWNERSHIP.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(dict(status=result['status'],definitions=len(proof),observed_allocated_edges=len(edges))))
