// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private default-OFF RR consumer; accepted Source23 getters remain unchanged.

use super::{
    sched_errno, sched_rr_interval_nsec,
    sched_thread_policy, SchedCopyToUserFn, SchedFindThreadFn, SchedSyscallOffsets,
    SchedThreadUnlockFn, EFAULT, EINVAL,
};
use crate::abi::{CInt, CLong, CULong, TimeSpec};

// Retain the reviewed guard/selector bytes, including their ownership contract.
use super::sched_retained_target::select_retained_query;

/// Retain the selected allocation through interval capture and genuine user copy.
///
/// # Safety
/// The caller supplies a live current thread and genuine aligned, immutable syscall
/// offsets. A successful foreign lookup transfers one positive reference and has
/// already released its hash lock. Its matching unlock releases that same edge.
/// Initialized scheduler fields obey the original scheduler access contract; this
/// repair does not add synchronization for concurrent field writers. The generic
/// copy provider retains its full C-long, MM, tracing and user-fault behavior.
#[no_mangle]
pub unsafe extern "C" fn sched_rr_get_interval_retained_v2(
    pid: CInt,
    output_time_address: CULong,
    current_thread: usize,
    offsets: *const SchedSyscallOffsets,
    find_thread_fn: Option<SchedFindThreadFn>,
    unlock_thread_fn: Option<SchedThreadUnlockFn>,
    copy_to_user_fn: Option<SchedCopyToUserFn>,
) -> CLong {
    // Preserve RR precedence: zero output addresses reach the actual user-copy
    // provider after PID, current-thread, provider and lookup validation.
    if pid < 0 || current_thread == 0 || offsets.is_null() {
        return sched_errno(EINVAL);
    }
    let Some(copy_to_user) = copy_to_user_fn else {
        return sched_errno(EINVAL);
    };
    // SAFETY: The caller supplies genuine, aligned offsets, immutable for this call.
    let syscall_offsets = unsafe { &*offsets };
    // SAFETY: The original current-thread lifetime or positive lookup edge pins the
    // exact selected allocation. The guard releases only a foreign acquired edge.
    let selected_thread = match unsafe {
        select_retained_query(
            pid,
            current_thread,
            syscall_offsets,
            find_thread_fn,
            unlock_thread_fn,
        )
    } {
        Ok(selected) => selected,
        Err(error) => return error,
    };
    // SAFETY: The retained allocation and genuine field offset remain live and
    // aligned. The existing helper preserves the original volatile C-int read.
    let captured_policy = unsafe { sched_thread_policy(selected_thread.address, syscall_offsets) };
    let interval = TimeSpec {
        tv_sec: 0,
        tv_nsec: sched_rr_interval_nsec(captured_policy),
    };
    // SAFETY: The complete initialized local TimeSpec lives through this synchronous
    // copy. The actual provider handles the user address and may fault; the lookup
    // reference remains retained, with no hash or IRQ lock held across the call.
    let copy_result = unsafe {
        copy_to_user(
            output_time_address,
            (&interval as *const TimeSpec).cast::<u8>(),
            core::mem::size_of::<TimeSpec>(),
        )
    };
    drop(selected_thread);
    if copy_result != 0 {
        sched_errno(EFAULT)
    } else {
        0
    }
}
