// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Exact Source23 guard, factored once; visibility-only change.
use super::{SchedSyscallOffsets, SchedFindThreadFn, SchedThreadUnlockFn,
    sched_normalized_pid, sched_thread_pid, sched_errno, EINVAL, ESRCH};
use crate::abi::{CInt, CLong};

pub(super) struct RetainedQueryThread {
 pub(super) address:usize,
 pub(super) release:Option<SchedThreadUnlockFn>,
}
impl Drop for RetainedQueryThread {
 fn drop(&mut self) {
  if let Some(release)=self.release.take() {
   // SAFETY: Exactly one positive lookup edge was transferred to this guard.
   // Current-thread selection owns no such edge and never enters this branch.
   unsafe { release(self.address) };
  }
 }
}

/// Select current or retain the exact foreign allocation through query completion.
/// # Safety
/// Same genuine thread/process/offset/provider contract as the existing selector.
/// Successful foreign lookup returns a positive retained reference with hash lock
/// already dropped. Its matched unlock releases that edge, not an IRQ/state lock.
pub(super) unsafe fn select_retained_query(
 pid:CInt,current:usize,offsets:&SchedSyscallOffsets,
 find:Option<SchedFindThreadFn>,unlock:Option<SchedThreadUnlockFn>,
)->Result<RetainedQueryThread,CLong> {
 let normalized=unsafe { sched_normalized_pid(pid,current,offsets)? };
 let current_pid=unsafe { sched_thread_pid(current,offsets) };
 if current_pid<0{return Err(sched_errno(EINVAL));}
 if current_pid==normalized{return Ok(RetainedQueryThread{address:current,release:None});}
 let (Some(find),Some(unlock))=(find,unlock) else{return Err(sched_errno(EINVAL));};
 let address=unsafe { find(normalized) };
 if address==0{return Err(sched_errno(ESRCH));}
 Ok(RetainedQueryThread{address,release:Some(unlock)})
}

