// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private process_helpers child. Public find_thread API remains pointer/NULL.
use core::ffi::c_void;
use core::mem::offset_of;
use core::ptr::{addr_of_mut, null_mut};
use core::sync::atomic::{AtomicI32, Ordering};

use crate::abi::{AbiListHead, CInt, CULong, Thread};
use super::{ProcessFindThreadOffsets, ProcessMcsRwlockFn};

/// New explicit ABI: one means an owned real reference was acquired, zero means
/// none was acquired. This is NOT the preexisting void hold callback type.
pub type ProcessThreadTryHoldFnV2 = unsafe extern "C" fn(*mut c_void) -> CInt;

/// Preserve the genuine hold warning, then acquire only an existing positive edge.
///
/// # Safety
/// The real hash reader retains Thread allocation storage; final destruction
/// must take its corresponding writer for detachment before freeing the Thread
/// or releasing its process/sigcommon edges. Existing atomic ownership is balanced.
/// A return of one transfers exactly one edge for original thread_unlock. Zero
/// transfers nothing, including at zero, negative or saturated count. No errno
/// or ptrace-lifecycle disposition is introduced by this callback.
#[no_mangle]
pub unsafe extern "C" fn process_try_hold_thread_live_v2(thread: *mut c_void) -> CInt {
    let thread = thread.cast::<Thread>();
    // SAFETY: Match original hold_thread warning and its order before increment.
    // The same actual void callback remains only a diagnostic; never admission.
    unsafe {
        if super::process_hold_thread_warn_exited_result((*thread).status) != 0 {
            super::process_hold_thread_warn_bridge(thread.cast());
        }
    }
    // SAFETY: Same real AtomicI32 counter and SeqCst domain as selected ref helpers.
    let counter = unsafe { AtomicI32::from_ptr(addr_of_mut!((*thread).refcount.counter)) };
    let mut count = counter.load(Ordering::SeqCst);
    while count > 0 && count < CInt::MAX {
        match counter.compare_exchange_weak(count, count + 1, Ordering::SeqCst, Ordering::SeqCst) {
            Ok(_) => return 1,
            Err(observed) => count = observed,
        }
    }
    0
}

const _: ProcessThreadTryHoldFnV2 = process_try_hold_thread_live_v2;

/// Versioned lookup with explicit acquisition outcome and original pointer/NULL API.
///
/// Exact PID matches retain priority over PID==TID fallback. Fallback retries
/// only nodes whose process PID did NOT match the first pass: already-attempted
/// exact PID candidates are not warned or acquired a second time after rejection.
/// No failed candidate address is cached for this exclusion; it follows from
/// the same immutable published process PID used by existing hash lookup.
///
/// # Safety
/// Head, lock, node and offsets are genuine selected hash geometry. Lock callbacks
/// are the actual synchronous reader pair and protect every traversed allocation.
/// Process PID is stable while published; process lifetime lasts until after hash
/// writer detachment, as in the selected final destructor. try_hold returns only
/// one after acquiring an actual positive Thread edge; zero acquires none and may
/// not free/detach any hash entry. Its warning callback does not mutate the list.
/// The old void callback MUST NOT be cast or wrapped into this ABI.
#[no_mangle]
pub unsafe extern "C" fn process_find_thread_live_body_result_v2(
    head: *mut AbiListHead, hash_lock: CULong, lock_node: *mut c_void,
    pid: CInt, tid: CInt, offsets: *const ProcessFindThreadOffsets,
    lock: Option<ProcessMcsRwlockFn>, unlock: Option<ProcessMcsRwlockFn>,
    try_hold: Option<ProcessThreadTryHoldFnV2>,
) -> *mut c_void {
    if tid <= 0 || head.is_null() || lock_node.is_null() || offsets.is_null() {
        return null_mut();
    }
    let (Some(lock), Some(unlock), Some(try_hold)) = (lock, unlock, try_hold) else {
        return null_mut();
    };
    // SAFETY: Actual synchronous reader pair pins nodes even during final-zero gap.
    unsafe { lock(hash_lock, lock_node) };
    let mut fallback = false;
    loop {
        // SAFETY: Genuine offsets remain immutable and valid through the reader.
        let geometry = unsafe { &*offsets };
        let mut entry = unsafe { (*head).next };
        while !entry.is_null() && entry != head {
            // Read the next link before attempting acquisition. On rejection no
            // borrowed candidate is read again, retained as state, freed or returned.
            let next = unsafe { (*entry).next };
            // SAFETY: Same selected list container and field geometry as original.
            let candidate = unsafe { entry.cast::<u8>()
                .sub(geometry.thread_hash_list_offset as usize) };
            let candidate_tid = unsafe { *candidate.add(geometry.thread_tid_offset as usize)
                .cast::<CInt>() };
            if candidate_tid == tid {
                let process = unsafe { *candidate.add(geometry.thread_proc_offset as usize)
                    .cast::<*mut u8>() };
                let process_pid = if process.is_null() { 0 } else {
                    unsafe { *process.add(geometry.proc_pid_offset as usize).cast::<CInt>() }
                };
                let matches = if fallback { process_pid != pid }
                    else { pid <= 0 || process_pid == pid };
                if matches && unsafe { try_hold(candidate.cast()) } == 1 {
                    // SAFETY: The successful callback edge, not hash membership,
                    // now retains this node beyond matching unlock and return.
                    unsafe { unlock(hash_lock, lock_node) };
                    return candidate.cast();
                }
            }
            entry = next;
        }
        if fallback || pid <= 0 || pid != tid { break; }
        fallback = true;
    }
    // SAFETY: No failed pointer or ownership claim survives the hash guard.
    unsafe { unlock(hash_lock, lock_node) };
    null_mut()
}

/// Compile-time geometry cross-check, with no production data/field changes.
const _: () = {
    assert!(offset_of!(Thread, refcount) % core::mem::align_of::<AtomicI32>() == 0);
    assert!(core::mem::size_of::<crate::abi::IhkAtomic>() == core::mem::size_of::<AtomicI32>());
};
