"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bind actual genuine Source30 object to expert-preflight/five-command source tuples.
Do not execute preflight, linker, observers, compiler or runtime.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
FOLLOW=ROOT/'follow-on-source-only'
BASE=ROOT.parent
PRIOR=BASE/'new-window-source-28-selected-c-abi-partial-link/expert-artifact-path-correction-1'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
 with (FOLLOW/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
result=ROOT/'ACTUAL-SOURCE30-REAL77MODULE-COMPILE-FIRST-RESULT.json';actual=json.loads(result.read_text())
assert actual['status']=='PASS_REAL_SELECTED_KERNEL_CRATE_COMPILE_ONLY'
obj=actual['actual_object'];assert pin(obj['path'])==obj and obj['sha256']=='dfba39b9a86707bc30f59bf9611a134bbf9733c97487984b7852fa89be993a13'
assert actual['records'][0]['join']['returncode']==0 and actual['records'][0]['join']['direct_child_joined'] and actual['records'][0]['join']['group_absent'] and actual['records'][0]['join']['closed_streams']
recipe=json.loads((FOLLOW/'FOLLOWON-RETAINED-C-STRICT-PARTIAL.PROVISIONAL-NOT-EXECUTABLE.json').read_text())
recipe['new_Rust_object']=obj
preflight=(FOLLOW/'preflight_artifact_roles_pure.TEMPLATE-NOT-EXECUTABLE.py').read_text();placeholder='__BIND_SOURCE30_ACTUAL_COMPILER_OBJECT_SHA_BEFORE_EXECUTION__';assert preflight.count(placeholder)==1
preflight=preflight.replace(placeholder,obj['sha256'])
with (FOLLOW/'preflight_artifact_roles_pure.NOT-GRANTED.py').open('x') as f:f.write(preflight)
recipe['pure_preflight']['source']=pin(FOLLOW/'preflight_artifact_roles_pure.NOT-GRANTED.py')
recipe['pure_preflight']['actual_baselines']=[x for x in recipe['pure_preflight']['actual_baselines']]
recipe['status']='ACTUAL_DFBA_OBJECT_FROZEN_FOLLOWON_SOURCE_ONLY_REQUIRES_PURE_PREFLIGHT_REVIEW_AND_ROOT_GRANTS'
recipe['actual_compiler_receipt']=pin(result)
recipe['compiled_policy']=pin(ROOT/'candidate/kernel/rust/syscall_policy.rs')
inputs={row['path']:row for row in recipe['inputs']}
for p in [Path(obj['path']),result,ROOT/'EXACT-REAL77MODULE-LOGGER-INTERNAL-COMPILE.NOT-GRANTED.json',ROOT/'READY-SOURCE30-REAL77MODULE-COMPILE.NOT-GRANTED.json',FOLLOW/'preflight_artifact_roles_pure.NOT-GRANTED.py',FOLLOW/'FOLLOWON-RETAINED-C-STRICT-PARTIAL.PROVISIONAL-NOT-EXECUTABLE.json']:
 inputs[str(p)]=pin(p)
recipe['inputs']=list(inputs.values())
name='EXACT-SELECTED-C-ABI-STRICT-PARTIAL.FROZEN-NOT-GRANTED.json';write(name,recipe);sha=pin(FOLLOW/name)['sha256']
runner=(PRIOR/'run_selected_c_abi_partial_once.NOT-GRANTED.py').read_text()
runner=runner.replace('Source28 retained-object selected-C ABI/strict partial suffix; fresh exact root grant required before execution.','Source30 actual dfba retained-C partial/four static observer suffix; fresh exact ROOT grant required.')
runner=runner.replace("RECIPE_SHA = 'f138701a4a6efe6855dbb9dc6d5e1238d63270ae4279d96a46e21825a9b57fe6'","RECIPE_SHA = '"+sha+"'").replace("ROOT / 'ROOT-EXACT-SOURCE28-GRANT.json'","ROOT / 'ROOT-EXACT-SOURCE30-FOLLOWON-GRANT.json'")
runner=runner.replace("RESULT = ROOT / 'ACTUAL-SELECTED-C-ABI-STRICT-PARTIAL-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE30-FOLLOWON-FIRST-RESULT.json'")
runner=runner.replace("authority='Exact durable root grant: two genuine full-TU C syntax-only checks, one retained-object partial link, four static ELF observers; zero Rust compiler, fixture or native execution.'","authority='Exact durable ROOT Source30 follow-on grant: one actual-dfba retained-four-C partial link and four static ELF observers only; no C/Rust compiler, fixture, runtime, native or default action.'")
runner=runner.replace("recipe=pin(RECIPE), C_syntax_only_commands=2, Rust_compiler_commands=0,","recipe=pin(RECIPE), C_syntax_only_commands=0, Rust_compiler_commands=0,")
runner=runner.replace('missing exact durable ROOT source28 grant','missing exact durable ROOT source30 follow-on grant')
with (FOLLOW/'run_Source30_followon_once.NOT-GRANTED.py').open('x') as f:f.write(runner)
ready=dict(scope=SCOPE,status='SOURCE_ONLY_ACTUAL_DFBA_FIVE_COMMAND_SUFFIX_REQUIRES_EXPERT_PREFLIGHT_REVIEW_ROOT_GRANT',recipe=pin(FOLLOW/name),runner=pin(FOLLOW/'run_Source30_followon_once.NOT-GRANTED.py'),actual_object=obj,actual_compiler_receipt=pin(result),preflight=pin(FOLLOW/'preflight_artifact_roles_pure.NOT-GRANTED.py'),new_observers_prepared=4,commands=5,actual_followon_commands=0,original_LOCAL_oracle_unchanged=True,retained_C_syntax_no_replay=True,default=False,native=False)
write('READY-SOURCE30-FOLLOWON.NOT-GRANTED.json',ready)
bootstrap="import os,sys,hashlib; p=sys.argv[1]; fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC); raw=os.read(fd,1048576); st=os.fstat(fd); assert len(raw)==st.st_size and hashlib.sha256(raw).hexdigest()==sys.argv[2], 'source FD binding mismatch'; ns={'__name__':'__main__','__file__':p}; exec(compile(raw,p,'exec'),ns)"
profile=json.loads((ROOT/'ROOT-EXACT-SOURCE30-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text())['profile']
fields=dict(scope=SCOPE,status='PREPARED_FIELDS_NOT_A_GRANT',ready=pin(FOLLOW/'READY-SOURCE30-FOLLOWON.NOT-GRANTED.json'),recipe=ready['recipe'],runner=ready['runner'],launch_argv=['/usr/bin/taskset','-c','0','/home/holden/anaconda3/bin/python3','-c',bootstrap,ready['runner']['path'],ready['runner']['sha256']],execution_count=1,profile=profile,compiler_commands=0,actual_link_and_observer_commands=5,no_runtime_or_native=True)
write('ROOT-EXACT-SOURCE30-FOLLOWON-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
# Preflight gets a separate result/output/capture namespace and grant.
pure=dict(scope=SCOPE,commands=[dict(name='00-pure17artifact19negative-actual-dfba',argv=['/home/holden/anaconda3/bin/python3','-I','-B',str(FOLLOW/'preflight_artifact_roles_pure.NOT-GRANTED.py')],cwd=str(FOLLOW),purpose=SCOPE+' Source/data AST17artifact role and19negative expert preflight only; no observer import/exec, compiler, link, ELF or runtime.')],inputs=recipe['inputs']+[pin(FOLLOW/name)],sources=[],canonical_origins=[],header_bindings=[],tools={},fixture_tools={},absent_include_namespaces=recipe['absent_include_namespaces'])
pure_name='EXACT-SOURCE30-EXPERT-PURE-PREFLIGHT.NOT-GRANTED.json';write(pure_name,pure);pure_sha=pin(FOLLOW/pure_name)['sha256']
pure_runner=runner.replace("RECIPE = ROOT / '"+name+"'","RECIPE = ROOT / '"+pure_name+"'").replace("RECIPE_SHA = '"+sha+"'","RECIPE_SHA = '"+pure_sha+"'")
pure_runner=pure_runner.replace("ROOT / 'ROOT-EXACT-SOURCE30-FOLLOWON-GRANT.json'","ROOT / 'ROOT-EXACT-SOURCE30-PURE-PREFLIGHT-GRANT.json'").replace("OUTPUT = ROOT / 'output-1'","OUTPUT = ROOT / 'pure-preflight-output-1'").replace("CAPTURE = ROOT / 'actual-parity-capture-first-1'","CAPTURE = ROOT / 'actual-pure-preflight-capture-first-1'").replace("RESULT = ROOT / 'ACTUAL-SOURCE30-FOLLOWON-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE30-PURE-PREFLIGHT-ENVELOPE-FIRST-RESULT.json'")
pure_runner=pure_runner.replace("status='PASS_SELECTED_C_ABI_AND_RETAINED_OBJECT_STRICT_PARTIAL_ONLY'","status='PASS_SOURCE30_EXPERT_PURE_PREFLIGHT_ONLY'")
pure_runner=pure_runner.replace("recipe=pin(RECIPE), C_syntax_only_commands=0, Rust_compiler_commands=0,\n                      linker_commands=1, static_ELF_observer_commands=4, fixture_commands=0,\n                      fullcrate_compilations=0, actual_partial=pin(OUTPUT / 'CPU37.partial.o'),\n                      reused_Rust_object=recipe['new_Rust_object'], retained_C_objects=recipe['selected_C_objects']", "recipe=pin(RECIPE), C_syntax_only_commands=0, Rust_compiler_commands=0,\n                      linker_commands=0, static_ELF_observer_commands=0, fixture_commands=0,\n                      fullcrate_compilations=0, pure_result=pin(ROOT / 'ACTUAL-PURE-ARTIFACT-PREFLIGHT-FIRST-RESULT.json')")
pure_runner=pure_runner.replace("authority='Exact durable ROOT Source30 follow-on grant: one actual-dfba retained-four-C partial link and four static ELF observers only; no C/Rust compiler, fixture, runtime, native or default action.'","authority='Exact durable ROOT Source30 pure source/data preflight only; no compiler, link, ELF observer, fixture, runtime, native or default action.'")
with (FOLLOW/'run_Source30_pure_preflight_once.NOT-GRANTED.py').open('x') as f:f.write(pure_runner)
pure_fields=dict(scope=SCOPE,status='PREPARED_FIELDS_NOT_A_GRANT',recipe=pin(FOLLOW/pure_name),runner=pin(FOLLOW/'run_Source30_pure_preflight_once.NOT-GRANTED.py'),launch_argv=['/usr/bin/taskset','-c','0','/home/holden/anaconda3/bin/python3','-c',bootstrap,str(FOLLOW/'run_Source30_pure_preflight_once.NOT-GRANTED.py'),pin(FOLLOW/'run_Source30_pure_preflight_once.NOT-GRANTED.py')['sha256']],execution_count=1,profile=profile,source_preflight_only=True)
write('ROOT-EXACT-SOURCE30-PURE-PREFLIGHT-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',pure_fields)
print(json.dumps(dict(READY=fields['ready'],recipe=ready['recipe'],runner=ready['runner'],pure_recipe=pure_fields['recipe'],pure_runner=pure_fields['runner'],source_only=True)))
