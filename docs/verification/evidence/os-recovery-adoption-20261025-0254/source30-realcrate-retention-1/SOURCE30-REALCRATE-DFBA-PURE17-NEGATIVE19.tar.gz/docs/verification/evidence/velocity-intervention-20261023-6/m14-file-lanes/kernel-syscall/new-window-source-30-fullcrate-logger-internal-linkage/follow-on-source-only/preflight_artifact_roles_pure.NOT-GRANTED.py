"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure source/data path preflight: no observer imports/exec, subprocess, compiler,
linker, ELF parser, kernel or runtime workload. AST inspection and byte hashes only.
"""
from pathlib import Path
import ast,copy,hashlib,json
ROOT=Path(__file__).resolve().parent
RECIPE=ROOT/'EXACT-SELECTED-C-ABI-STRICT-PARTIAL.FROZEN-NOT-GRANTED.json'
RUST_SHA='dfba39b9a86707bc30f59bf9611a134bbf9733c97487984b7852fa89be993a13'
FILES=['retained_observe_current290.py','retained_observe_current_F04_storage.py','retained_observe_new_metadata.py']
ASSIGNMENTS=[(0,'rust','Rust'),(0,'partial','partial'),(1,'rust','Rust'),(1,'partial','partial'),(2,'rust','Rust'),(2,'partial','partial'),(0,'process','C0'),(0,'arch','C1'),(0,'f03','C2'),(0,'f04','C3'),(1,'selected','C3'),(2,'process','C0'),(2,'arch_data_elf','C1'),(2,'f03','C2'),(2,'policy','policy')]
ROLE_NAMES=[FILES[i]+':'+target for i,target,_ in ASSIGNMENTS]+['trace:selected_C','trace:partial']

def need(value,message):
 if not value:raise ValueError(message)

def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def assignment(tree,target):
 rows=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id==target]
 need(len(rows)==1,'unique top-level artifact target required: '+target)
 return rows[0]

def resolve(node,known):
 if isinstance(node,ast.Constant) and isinstance(node.value,str):return node.value
 if isinstance(node,ast.Name) and node.id in known:return known[node.id]
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ['Path','Elf'] and len(node.args)==1 and not node.keywords:
  value=resolve(node.args[0],known)
  need(isinstance(value,str),'literal Path/Elf argument required')
  return value
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Div):
  left=resolve(node.left,known);right=resolve(node.right,known)
  need(isinstance(left,str) and isinstance(right,str),'literal path join required')
  return str(Path(left)/right)
 raise ValueError('unresolved artifact path AST: '+ast.dump(node))

def environment(tree):
 known={}
 for name in ['D','O']:
  known[name]=resolve(assignment(tree,name).value,known)
 return known

def trace_items(tree):
 value=assignment(tree,'trace_proof').value
 need(isinstance(value,ast.DictComp) and len(value.generators)==1,'exact trace generator expected')
 generator=value.generators[0]
 need(isinstance(generator.target,ast.Tuple) and [x.id for x in generator.target.elts]==['label','elf','path'],'trace target shape')
 need(isinstance(generator.iter,ast.Tuple) and len(generator.iter.elts)==2,'exact trace pair expected')
 result={}
 for item in generator.iter.elts:
  need(isinstance(item,ast.Tuple) and len(item.elts)==3 and isinstance(item.elts[0],ast.Constant),'trace item shape')
  label=item.elts[0].value;need(label not in result,'duplicate trace role');result[label]=item
 need(set(result)=={'selected_C','partial'},'trace labels')
 return result

def assert_ast(tree):return [ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,ast.Assert)]

def validate(recipe,trees,baseline_assertions,consumed):
 need(recipe['new_Rust_object']['sha256']==RUST_SHA,'wrong accepted Rust identity')
 rust=recipe['new_Rust_object']['path']
 command=recipe['commands'][0];argv=command['argv']
 need(command['name'].startswith('00-') and argv[:3]==['/usr/bin/ld','-r','-o'] and len(argv)==9,'exact partial link operand shape')
 partial=argv[3];need(partial==str(ROOT/'output-1/CPU37.partial.o'),'fresh private partial output')
 cpaths=argv[4:-1];need(cpaths==[x['path'] for x in recipe['selected_C_objects']],'ld selected C tuple/order mismatch')
 need(argv[-1]==rust,'ld Rust operand differs from accepted Rust')
 expected={'Rust':rust,'partial':partial,'policy':str(Path(rust).parents[1]/'candidate/kernel/rust/syscall_policy.rs')}
 expected.update({'C'+str(i):value for i,value in enumerate(cpaths)})
 environments=[environment(t) for t in trees]
 roles={}
 for index,target,role in ASSIGNMENTS:
  path=resolve(assignment(trees[index],target).value,environments[index])
  need(path==expected[role],'wrong artifact role '+FILES[index]+':'+target)
  roles[FILES[index]+':'+target]=path
 for label,item in trace_items(trees[0]).items():
  path=resolve(item.elts[2],environments[0]);need(path==expected['C0' if label=='selected_C' else 'partial'],'wrong trace artifact '+label)
  roles['trace:'+label]=path
 for tree,expected_assertions,count in zip(trees,baseline_assertions,[143,38,139]):
  actual=assert_ast(tree);need(len(actual)==count and actual==expected_assertions,'retained assertion AST changed')
 bound={r['path']:r for r in recipe['inputs']}
 for row in consumed:
  need(row['path'] in bound and bound[row['path']]==row,'missing or changed consumed artifact binding: '+row['path'])
 need(len(roles)==17,'all17 roles checked')
 return roles

def main():
 recipe=json.loads(RECIPE.read_bytes());trees=[ast.parse((ROOT/name).read_text()) for name in FILES]
 baseline_rows=recipe['pure_preflight']['actual_baselines']
 baseline_assertions=[assert_ast(ast.parse(Path(row['path']).read_text())) for row in baseline_rows]
 consumed=recipe['pure_preflight']['consumed_artifact_closure']
 # Current bytes are checked once. Negative tests remain source/data-only and
 # do not parse or execute the compiled objects they intentionally misselect.
 for row in recipe['inputs']:
  need(pin(row['path'])==row,'frozen actual source/data bytes changed: '+row['path'])
 changed=ROOT/'observe_changed_boundary.py';prior=Path(recipe['pure_preflight']['changed_boundary_original']['path'])
 need(changed.read_bytes()==prior.read_bytes(),'changed-boundary observer must stay byte-identical')
 roles=validate(recipe,trees,baseline_assertions,consumed)
 negatives=[];wrong=str(Path(recipe['selected_C_objects'][0]['path']).parent/'mckernel_rust.cpu37.o')
 for index,target,_ in ASSIGNMENTS:
  mutated=copy.deepcopy(trees);assignment(mutated[index],target).value=ast.parse('Path('+repr(wrong)+')',mode='eval').body
  try:validate(recipe,mutated,baseline_assertions,consumed)
  except ValueError as error:negatives.append(dict(role=FILES[index]+':'+target,status='REJECTED',reason=str(error)))
  else:raise ValueError('one-path negative was accepted: '+target)
 for label in ['selected_C','partial']:
  mutated=copy.deepcopy(trees);trace_items(mutated[0])[label].elts[2]=ast.parse('Path('+repr(wrong)+')',mode='eval').body
  try:validate(recipe,mutated,baseline_assertions,consumed)
  except ValueError as error:negatives.append(dict(role='trace:'+label,status='REJECTED',reason=str(error)))
  else:raise ValueError('trace negative accepted')
 # One exact legitimate consumed fallback pin is independently required.
 fallback=next(row for row in consumed if row['path'].endswith('/process.fallback.o'))
 removed=copy.deepcopy(recipe);removed['inputs']=[r for r in removed['inputs'] if r['path']!=fallback['path']]
 try:validate(removed,trees,baseline_assertions,consumed)
 except ValueError as error:negatives.append(dict(role='removed-consumed-fallback',status='REJECTED',reason=str(error)))
 else:raise ValueError('removed fallback negative accepted')
 replaced=copy.deepcopy(recipe);replaced['commands'][0]['argv'][-1]=wrong
 try:validate(replaced,trees,baseline_assertions,consumed)
 except ValueError as error:negatives.append(dict(role='substituted-ld-Rust',status='REJECTED',reason=str(error)))
 else:raise ValueError('substituted ld Rust negative accepted')
 need(len(negatives)==19,'19 independent negatives required')
 result=dict(scope=recipe['scope'],status='PASS_PURE17_ARTIFACT_ROLES_AND19_INDEPENDENT_NEGATIVES',positive_cases=1,negative_cases=19,roles=roles,negatives=negatives,retained_assertion_counts=[143,38,139],consumed_artifact_closure=len(consumed),unchanged_new13symbol_observer=True,observer_import_or_exec=0,subprocesses=0,compiler_commands=0,linker_commands=0,ELF_parser_invocations=0,qualification_commands=0)
 with (ROOT/'ACTUAL-PURE-ARTIFACT-PREFLIGHT-FIRST-RESULT.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
 print(json.dumps(dict(status=result['status'],positive=1,negatives=19,roles=17)))

if __name__=='__main__':main()
