"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare an actual Source27 88-file successor with exactly five linkage additions.
"""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
OLD=BASE/'new-window-source-27-scheduler-lifetime-selected-crate-integration/module-resolution-correction-1'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(path,text):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x') as f:f.write(text)
files=sorted(path for path in (OLD/'candidate').rglob('*') if path.is_file());assert len(files)==88
rows=[];deltas=[]
names=['F06_PROCESS_VM_IOV_LOCAL_DEBUG','F06_PROCESS_VM_IOV_REMOTE_DEBUG','F06_PROCESS_VM_FOUND_DEBUG','F06_PROCESS_VM_COPY_DEBUG']
for previous in files:
 relative=previous.relative_to(OLD/'candidate');original=previous.read_text();changed=original
 if str(relative)=='kernel/rust/lib.rs':
  assert '#![feature(linkage)]' not in original;changed='#![feature(linkage)]\n'+original
 elif str(relative)=='kernel/rust/syscall_policy.rs':
  for name in names:
   prior='static mut '+name+':';assert changed.count(prior)==1
   changed=changed.replace(prior,'#[linkage = "internal"]\n'+prior)
 path=ROOT/'candidate'/relative;write(path,changed)
 rows.append(dict(relative=str(relative),original=pin(previous),successor=pin(path),byte_identical=changed==original))
 if changed!=original:deltas.append(dict(relative=str(relative),patch=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='Source27/'+str(relative),tofile='Source30/'+str(relative)))))
assert len(deltas)==2 and sum(row['byte_identical'] for row in rows)==86
source_recipe=json.loads((OLD/'EXACT-REAL-CRATE-COMPILE-ONLY.ROOT-GRANTED.json').read_text())
# Explicitly retain provenance separately from the fresh actual-consumed closure.
# Source30 consumes its private copy, not mutable contemporary canonical origins.
manifest=dict(scope=SCOPE,status='SOURCE_ONLY_REAL_FULLCRATE_LINKAGE_CANDIDATE_NOT_COMPILED',original_recipe=pin(OLD/'EXACT-REAL-CRATE-COMPILE-ONLY.ROOT-GRANTED.json'),original_actual_object=pin(OLD/'output-1/candidate.o'),tiny_diagnostic=pin(BASE/'new-window-source-29-logger-linkage-diagnostic/ACTUAL-COMPILED-TINY-SHAPES-AND-RELEASE.json'),files=rows,file_count=88,unchanged_files=86,changed_files=['kernel/rust/lib.rs','kernel/rust/syscall_policy.rs'],only_runtime_delta='One root feature(linkage) and exactly four linkage=internal attrs. No used/section/name/sourceinitializer/callback/body/ABI/selectedcfg/toolchain changes.',source_patch=deltas,original_canonical_origin_rows=source_recipe['canonical_origins'],canonical_origin_scope='Historical source27 provenance only; no live canonical source is consumed by the private Source30 compiler. Fresh private88files are individually pinned and derived directly from immutable Source27 corrected source.',ownership_obligations=['Each private logger must remain exactly one LOCAL0 OBJECT32 DEFAULT0 allocation in allocated writable non-executable __verbose, with no alias/duplicate storage.','Keep exact record initializer bytes plus source-qualified file/line/function pointer RELA and actual arch_process_vm_rw_log_bridge instruction consumers.','Same production codegen-units=1 only; no cross-CGU, LTO, changed compiler or other flag profile accepted by tiny diagnostic. Any later profile needs fresh selected-code evidence.','No genuine caller may retain a global/mangled undefined reference to the now-internal statics. Public callback must remain unique GLOBAL function and unchanged signature/body; actual partial defined/undefined union remains mandatory.','Dynamic debug still finds original used __verbose records; source allocation/format/pointer and runtime mutation/lifetime contracts stay open until fullcrate/link/native checks.'],selector_state='Private source only, no canonical/default/current290 selection.',runtime_or_native=False)
write(ROOT/'SOURCE30-EXACT-FIVE-LINKAGE-ADDITIONS.SOURCE.json',json.dumps(manifest,indent=2)+'\n')
write(ROOT/'EXACT-FIVE-LINKAGE-ADDITIONS.patch',''.join(x['patch'] for x in deltas))
print(json.dumps(dict(status='SOURCE_ONLY88FILE_CANDIDATE_PREPARED',files=88,unchanged=86,changed=2,patch=pin(ROOT/'EXACT-FIVE-LINKAGE-ADDITIONS.patch'))))
