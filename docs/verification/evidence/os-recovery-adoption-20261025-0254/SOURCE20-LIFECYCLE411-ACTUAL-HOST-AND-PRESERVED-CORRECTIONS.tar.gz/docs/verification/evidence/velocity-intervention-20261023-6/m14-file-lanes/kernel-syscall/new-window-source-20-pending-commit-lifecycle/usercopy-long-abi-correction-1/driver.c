/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"

struct stage_plan { int status, has_send, has_receive; };
struct outcome { int disposition; long error; };
typedef void *(*allocate_fn)(size_t, unsigned long);
typedef void (*free_fn)(void *);
#include "genuine_usercopy_types.C-DECLARATIONS.inc"
extern struct outcome f03_pending_stage_and_commit_v1(struct thread *, unsigned long,
        unsigned long, allocate_fn, free_fn, ptrace_user_copy_from_fn_t);
extern struct outcome f03_pending_get_snapshot_v1(struct thread *, unsigned long, ptrace_user_copy_to_fn_t);
extern struct outcome f03_pending_detach_for_destroy_v1(struct thread *, void **, void **);
extern const unsigned long f03_lifecycle_Rust_ABI[25];
extern int printf(const char *, ...);
extern int dprintf(int, const char *, ...);
extern void abort(void);
#define require(v) do { if (!(v)) { dprintf(2, "FAIL lifecycle line=%d expression=%s\n", \
    __LINE__, #v); abort(); } } while (0)

static const unsigned long expected_abi[25] = {
    sizeof(struct thread), __alignof__(struct thread), __builtin_offsetof(struct thread,sigcommon),
    __builtin_offsetof(struct thread,ptrace_sendsig), __builtin_offsetof(struct thread,ptrace_recvsig),
    sizeof(struct sig_common), __alignof__(struct sig_common), __builtin_offsetof(struct sig_common,lock),
    sizeof(struct sig_pending), __alignof__(struct sig_pending), __builtin_offsetof(struct sig_pending,info),
    sizeof(struct siginfo), __alignof__(struct siginfo), sizeof(struct mcs_rwlock_lock),
    __alignof__(struct mcs_rwlock_lock), sizeof(struct mcs_rwlock_node_irqsave),
    __alignof__(struct mcs_rwlock_node_irqsave), __builtin_offsetof(struct thread,status),
    sizeof(struct stage_plan), __alignof__(struct stage_plan),
    __builtin_offsetof(struct stage_plan,has_receive), sizeof(struct outcome),
    __alignof__(struct outcome), __builtin_offsetof(struct outcome,error),
    __builtin_offsetof(struct stage_plan,has_send)
};

static struct thread target;
static struct sig_common common;
static struct sig_pending old_send, old_receive, new_send, new_receive, private_node;
static int held, locks, unlocks, allocation_calls, free_calls, copy_calls, copy_to_calls;
static int allocation_fails, fault_copy, partial_fault, mutation, private_live, generation;
static unsigned long node_identity;
static long fault_status;
static struct siginfo prior_send, prior_receive, getter_expected;
static int prior_has_send, prior_has_receive;

/* Genuine header function types and real lock/node geometry. These controlled
 * endpoints enforce ownership in HOST only, with no IRQ/spin/native claim. */
void (*const actual_lock_signature)(struct mcs_rwlock_lock *,
        struct mcs_rwlock_node_irqsave *) = __mcs_rwlock_writer_lock;
void (*const actual_unlock_signature)(struct mcs_rwlock_lock *,
        struct mcs_rwlock_node_irqsave *) = __mcs_rwlock_writer_unlock;
void __mcs_rwlock_writer_lock(struct mcs_rwlock_lock *lock,
        struct mcs_rwlock_node_irqsave *node)
{
    require(lock == &common.lock && !held && node);
    require((unsigned long)node % __alignof__(*node) == 0);
    held = 1; locks++; node_identity = (unsigned long)node;
    *(unsigned long *)node = 0x53261;
}
void __mcs_rwlock_writer_unlock(struct mcs_rwlock_lock *lock,
        struct mcs_rwlock_node_irqsave *node)
{
    require(lock == &common.lock && held && (unsigned long)node == node_identity);
    require(*(unsigned long *)node == 0x53261);
    held = 0; unlocks++; node_identity = 0;
}

static void save_current_bytes(void)
{
    require(!held);
    prior_has_send = target.ptrace_sendsig != NULL;
    prior_has_receive = target.ptrace_recvsig != NULL;
    if (prior_has_send) prior_send = target.ptrace_sendsig->info;
    if (prior_has_receive) prior_receive = target.ptrace_recvsig->info;
}

static void mutate_published_state(void)
{
    struct mcs_rwlock_node_irqsave node;
    __mcs_rwlock_writer_lock(&common.lock, &node);
    if (mutation == 1) {
        /* Equivalent slot shape, DIFFERENT allocations. */
        if (target.ptrace_sendsig) target.ptrace_sendsig = &new_send;
        if (target.ptrace_recvsig) target.ptrace_recvsig = &new_receive;
    } else if (mutation == 2) {
        target.ptrace_recvsig = target.ptrace_recvsig ? NULL : &new_receive;
    } else if (mutation == 3) {
        target.status = 0;
    } else if (mutation == 4) {
        target.ptrace_sendsig = target.ptrace_recvsig = &new_send;
    } else if (mutation == 5) {
        /* Logical retire/reallocate at SAME address. No actual freed storage is
         * accessed: static bytes model the new allocation generation explicitly. */
        generation++;
        if (target.ptrace_sendsig)
            __builtin_memset(&target.ptrace_sendsig->info, 0xb1, sizeof(struct siginfo));
        if (target.ptrace_recvsig)
            __builtin_memset(&target.ptrace_recvsig->info, 0xb2, sizeof(struct siginfo));
    }
    __mcs_rwlock_writer_unlock(&common.lock, &node);
    save_current_bytes();
}

static void *allocate_private(size_t bytes, unsigned long flags)
{
    require(!held && bytes == sizeof(private_node) && flags == 0x5123 && !private_live);
    allocation_calls++;
    if (allocation_fails) return NULL;
    private_live = 1;
    __builtin_memset(&private_node, 0xdd, sizeof(private_node));
    return &private_node;
}
static void release_private(void *node)
{
    require(!held && node == &private_node && private_live);
    require(target.ptrace_sendsig != node && target.ptrace_recvsig != node);
    free_calls++; private_live = 0;
}
static long copy_from(void *destination, unsigned long source, size_t bytes)
{
    require(!held && source == 0x1234 && bytes == sizeof(struct siginfo));
    require(destination != (void *)&old_send.info && destination != (void *)&old_receive.info);
    require(destination != (void *)&new_send.info && destination != (void *)&new_receive.info);
    require(destination != (void *)&private_node.info);
    copy_calls++;
    if (copy_calls == 1) mutate_published_state();
    size_t count = fault_copy == copy_calls ? (partial_fault ? bytes / 2 : 0) : bytes;
    __builtin_memset(destination, copy_calls == 1 ? 0x51 : 0x62, count);
    return fault_copy == copy_calls ? fault_status : 0;
}
static long copy_to(unsigned long destination, const void *source, size_t bytes)
{
    require(!held && destination == 0x1234 && bytes == sizeof(getter_expected));
    copy_to_calls++;
    /* Retire/replace CURRENT published slots before examining the snapshot.
     * A correct getter still supplies the bytes copied while locked. */
    mutate_published_state();
    require(!memcmp(source, &getter_expected, bytes));
    return fault_copy != 0 ? fault_status : 0;
}
_Static_assert(__builtin_types_compatible_p(__typeof__(&copy_from), ptrace_user_copy_from_fn_t),
        "copy_from must match exact production long-return provider typedef");
_Static_assert(__builtin_types_compatible_p(__typeof__(&copy_to), ptrace_user_copy_to_fn_t),
        "copy_to must match exact production long-return provider typedef");
_Static_assert(sizeof(long) == 8, "high-word nonzero usercopy vector requires actual LP64 ABI");
static ptrace_user_copy_from_fn_t const actual_copy_from_signature = copy_from;
static ptrace_user_copy_to_fn_t const actual_copy_to_signature = copy_to;
static int bytes_equal(const void *data, unsigned char pattern, size_t bytes)
{
    const unsigned char *p = data;
    for (size_t i = 0; i < bytes; i++) if (p[i] != pattern) return 0;
    return 1;
}

static void reset(int mode)
{
    __builtin_memset(&target, 0, sizeof(target));
    __builtin_memset(&common, 0, sizeof(common));
    __builtin_memset(&old_send, 0x31, sizeof(old_send));
    __builtin_memset(&old_receive, 0x42, sizeof(old_receive));
    __builtin_memset(&new_send, 0x93, sizeof(new_send));
    __builtin_memset(&new_receive, 0xa4, sizeof(new_receive));
    target.sigcommon = &common; target.status = PS_TRACED;
    target.ptrace_sendsig = mode == 1 || mode == 3 || mode == 4 ? &old_send : NULL;
    target.ptrace_recvsig = mode == 2 || mode == 3 ? &old_receive : mode == 4 ? &old_send : NULL;
    held = locks = unlocks = allocation_calls = free_calls = copy_calls = copy_to_calls = 0;
    allocation_fails = fault_copy = partial_fault = mutation = private_live = generation = 0;
    node_identity = 0; fault_status = 1;
    save_current_bytes();
}

static void producer_case(int mode, int alloc_fail, int copy_fault, int partial, int change, long failure_value)
{
    reset(mode); allocation_fails = alloc_fail; fault_copy = copy_fault;
    partial_fault = partial; mutation = change; fault_status = failure_value;
    int initially_no_send = !target.ptrace_sendsig;
    int initially_has_receive = target.ptrace_recvsig != NULL;
    struct outcome result = f03_pending_stage_and_commit_v1(&target, 0x1234,
            0x5123, allocate_private, release_private, copy_from);
    int expected_disposition = 0; long expected_error = 0;
    if (mode == 4) expected_disposition = 3;
    else if (initially_no_send && alloc_fail) { expected_disposition = 1; expected_error = -ENOMEM; }
    else if (copy_fault == 1 || (copy_fault == 2 && initially_has_receive)) {
        expected_disposition = 1; expected_error = -EFAULT;
    } else if (change == 4) expected_disposition = 3;
    else if (change == 2 || change == 3) expected_disposition = 2;
    require(result.disposition == expected_disposition && result.error == expected_error);
    require(!held && locks == unlocks && !node_identity);
    if (mode == 4) require(!allocation_calls && !copy_calls);
    else {
        require(allocation_calls == initially_no_send);
        if (initially_no_send && alloc_fail) require(!copy_calls);
        else require(copy_calls == (copy_fault == 1 ? 1 : 1 + initially_has_receive));
    }
    if (result.disposition == 0) {
        require(target.ptrace_sendsig);
        require(bytes_equal(&target.ptrace_sendsig->info, 0x51, sizeof(struct siginfo)));
        if (initially_has_receive)
            require(bytes_equal(&target.ptrace_recvsig->info, 0x62, sizeof(struct siginfo)));
        if (initially_no_send) {
            require(target.ptrace_sendsig == &private_node && private_live && !free_calls);
            require(bytes_equal(&private_node, 0, __builtin_offsetof(struct sig_pending, info)));
            require(private_node.ptracecont == 0 && private_node.interrupted == 0);
        } else require(!private_live && !free_calls);
    } else {
        require((target.ptrace_sendsig != NULL) == prior_has_send);
        require((target.ptrace_recvsig != NULL) == prior_has_receive);
        if (prior_has_send) require(!memcmp(&target.ptrace_sendsig->info, &prior_send, sizeof(prior_send)));
        if (prior_has_receive) require(!memcmp(&target.ptrace_recvsig->info, &prior_receive, sizeof(prior_receive)));
        require(!private_live);
        require(free_calls == (mode != 4 && initially_no_send && !alloc_fail));
    }
    if (change == 5 && copy_calls) require(generation == 1);
}

int main(void)
{
    require(actual_copy_from_signature == copy_from && actual_copy_to_signature == copy_to);
    require(!memcmp(expected_abi, f03_lifecycle_Rust_ABI, sizeof(expected_abi)));
    unsigned producer_cases = 0, getter_cases = 0, destroy_cases = 0;
    for (int mode = 0; mode < 5; mode++)
    for (int alloc_fail = 0; alloc_fail < 2; alloc_fail++)
    for (int copy_fault = 0; copy_fault < 3; copy_fault++)
    for (int partial = 0; partial < 2; partial++)
    for (int change = 0; change < 6; change++) {
        producer_case(mode, alloc_fail, copy_fault, partial, change, 1); producer_cases++;
    }
    /* Preserve original360 producer cases; add high-word nonzero failure vectors
     * through the SAME transaction/rollback oracle, with no adapter or cast. */
    for (int mode = 0; mode < 4; mode++)
    for (int copy_fault = 1; copy_fault <= 2; copy_fault++)
    for (int partial = 0; partial < 2; partial++) {
        producer_case(mode, 0, copy_fault, partial, 0, 1L << 32); producer_cases++;
    }
    for (int mode = 0; mode < 5; mode++)
    for (int fault = 0; fault < 3; fault++)
    for (int change = 0; change < 2; change++) {
        reset(mode); fault_copy = fault; mutation = change ? 5 : 1;
        fault_status = fault == 2 ? 1L << 32 : 1;
        int has_receive = target.ptrace_recvsig != NULL;
        if (has_receive) getter_expected = target.ptrace_recvsig->info;
        struct outcome result = f03_pending_get_snapshot_v1(&target, 0x1234, copy_to);
        require(result.disposition == (!has_receive || fault ? 1 : 0));
        require(result.error == (!has_receive ? -ESRCH : fault ? -EFAULT : 0));
        require(copy_to_calls == has_receive && locks == unlocks && !held);
        getter_cases++;
    }
    for (int mode = 0; mode < 5; mode++) {
        reset(mode); void *receive = (void *)1, *send = (void *)1;
        void *expected_receive = target.ptrace_recvsig, *expected_send = target.ptrace_sendsig;
        struct outcome result = f03_pending_detach_for_destroy_v1(&target, &receive, &send);
        require(!held && locks == 1 && unlocks == 1 && !free_calls && !copy_calls);
        require(!result.error && result.disposition == (mode == 4 ? 3 : 0));
        if (mode == 4) {
            require(!receive && !send && target.ptrace_recvsig == expected_receive);
            require(target.ptrace_sendsig == expected_send);
        } else {
            require(receive == expected_receive && send == expected_send);
            require(!target.ptrace_recvsig && !target.ptrace_sendsig);
        }
        destroy_cases++;
    }
    require(producer_cases == 376 && getter_cases == 30 && destroy_cases == 5);
    printf("PASS lifecycle producer376 getter30 destroy5 ABI25 long-usercopy-highword current-state-contract-held no-native-credit\n");
    return 0;
}
