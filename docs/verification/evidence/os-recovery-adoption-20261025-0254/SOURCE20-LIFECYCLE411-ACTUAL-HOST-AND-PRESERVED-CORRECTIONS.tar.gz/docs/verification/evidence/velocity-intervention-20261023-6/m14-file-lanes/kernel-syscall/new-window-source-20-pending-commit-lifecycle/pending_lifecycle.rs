// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private internal candidate. No syscall selector or canonical caller is emitted.
use core::ffi::c_void;
use core::mem::{size_of, MaybeUninit};
use core::ptr::{addr_of_mut, copy_nonoverlapping, null_mut, read_volatile, write_volatile};

use crate::abi::{CInt, CLong, CULong, SigCommon, SigInfo, SigPending, Thread};
use crate::lock_helpers::McsRwlockNodeIrqsave;

pub const COMPLETE: CInt = 0;
pub const SYSCALL_ERROR: CInt = 1;
pub const HELD_STATE: CInt = 2;
pub const HELD_ALIAS: CInt = 3;
const ESRCH: CLong = 3;
const ENOMEM: CLong = 12;
const EFAULT: CLong = 14;
const IO_ELIGIBLE: CInt = 0x20 | 0x40;

/// Pointer-free observation. Equality is a shape/status check, NEVER a generation check.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct StagePlan {
    pub status: CInt,
    pub has_send: CInt,
    pub has_receive: CInt,
}

/// Internal disposition is separate from errno. HELD_* has no syscall translation.
#[repr(C)]
pub struct Outcome {
    pub disposition: CInt,
    pub error: CLong,
}

impl Outcome {
    fn complete() -> Self { Self { disposition: COMPLETE, error: 0 } }
    fn error(error: CLong) -> Self { Self { disposition: SYSCALL_ERROR, error } }
    fn held(disposition: CInt) -> Self { Self { disposition, error: 0 } }
}

pub type Allocate = unsafe extern "C" fn(usize, CULong) -> *mut c_void;
pub type Free = unsafe extern "C" fn(*mut c_void);
pub type CopyFrom = unsafe extern "C" fn(*mut u8, CULong, usize) -> CInt;
pub type CopyTo = unsafe extern "C" fn(CULong, *const u8, usize) -> CInt;

/// Existing MCS writer/IRQ-save guard; its node is stack-owned through unlock.
unsafe fn with_pending_lock<R>(thread: *mut Thread, operation: impl FnOnce() -> R) -> R {
    let mut node = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    // SAFETY: The public entry contracts retain thread AND its original sigcommon.
    let lock = unsafe { addr_of_mut!((*(*thread).sigcommon.cast::<SigCommon>()).lock) };
    // SAFETY: Existing synchronous provider initializes the same aligned node it unlocks.
    unsafe { crate::lock_helpers::__mcs_rwlock_writer_lock(lock.cast(), node.as_mut_ptr()) };
    let result = operation();
    // SAFETY: No callback under this guard faults, allocates, frees, sleeps or panics.
    unsafe { crate::lock_helpers::__mcs_rwlock_writer_unlock(lock.cast(), node.as_mut_ptr()) };
    result
}

unsafe fn current_plan(thread: *mut Thread) -> StagePlan {
    // SAFETY: Invoked only inside the existing sigcommon writer lock; status access
    // additionally needs the actual caller's status/lifecycle exclusion (still OPEN).
    unsafe {
        StagePlan {
            status: read_volatile(addr_of_mut!((*thread).status)),
            has_send: (!read_volatile(addr_of_mut!((*thread).ptrace_sendsig)).is_null()) as CInt,
            has_receive: (!read_volatile(addr_of_mut!((*thread).ptrace_recvsig)).is_null()) as CInt,
        }
    }
}

unsafe fn has_alias(thread: *mut Thread) -> bool {
    // SAFETY: Both slots are examined only while holding their common writer lock.
    unsafe {
        let send = read_volatile(addr_of_mut!((*thread).ptrace_sendsig));
        !send.is_null() && send == read_volatile(addr_of_mut!((*thread).ptrace_recvsig))
    }
}

/// Snapshot only eligibility and slot presence; no pending address leaves the lock.
///
/// # Safety
/// Retain thread and its unchanged sigcommon through the call. All pending slot
/// participants must use this same lock; caller supplies status/lifecycle exclusion.
/// Do not enter holding sigcommon.lock. Output is disjoint writable StagePlan.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_stage_plan_v1(
    thread: *mut Thread, output: *mut StagePlan,
) -> Outcome {
    // SAFETY: The caller meets the lock/lifetime/output requirements above.
    unsafe { with_pending_lock(thread, || {
        let plan = current_plan(thread);
        if plan.status & IO_ELIGIBLE == 0 { return Outcome::error(-ESRCH); }
        if has_alias(thread) { return Outcome::held(HELD_ALIAS); }
        output.write(plan);
        Outcome::complete()
    }) }
}

/// Commit staged bytes to CURRENT nodes under the genuine lock, never to a saved address.
///
/// This deliberately proposes commit-against-current-state semantics: unchanged
/// shape/status may contain replacement allocations, including allocator address
/// reuse. It does not claim to detect ABA or preserve snapshot-node identity.
///
/// # Safety
/// Common entry lifetime/participant/status contracts apply. Plan is the unmodified
/// successful observation; initialized byte arrays are private and disjoint from
/// every node and output. Fresh is a private initialized SigPending exactly when
/// plan.has_send==0, otherwise NULL. On COMPLETE ownership transfers and fresh is
/// set NULL. On every other outcome caller still owns fresh. No frees occur here.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_commit_current_v1(
    thread: *mut Thread, plan: *const StagePlan,
    send_bytes: *const u8, receive_bytes: *const u8, fresh: *mut *mut c_void,
) -> Outcome {
    // SAFETY: Copy the pointer-free plan from caller-owned initialized storage.
    let expected = unsafe { plan.read() };
    // SAFETY: No usercopy/allocation/callback occurs within this critical section.
    unsafe { with_pending_lock(thread, || {
        if has_alias(thread) { return Outcome::held(HELD_ALIAS); }
        let current = current_plan(thread);
        if current.status != expected.status || current.has_send != expected.has_send
            || current.has_receive != expected.has_receive {
            return Outcome::held(HELD_STATE);
        }
        // These pointers are first acquired after locking, used only before unlock.
        let send_slot = addr_of_mut!((*thread).ptrace_sendsig);
        let send = if expected.has_send == 0 { fresh.read() } else { read_volatile(send_slot) };
        let receive = read_volatile(addr_of_mut!((*thread).ptrace_recvsig));
        copy_nonoverlapping(send_bytes, addr_of_mut!((*send.cast::<SigPending>()).info).cast(),
            size_of::<SigInfo>());
        if expected.has_receive != 0 {
            copy_nonoverlapping(receive_bytes,
                addr_of_mut!((*receive.cast::<SigPending>()).info).cast(), size_of::<SigInfo>());
        }
        if expected.has_send == 0 {
            write_volatile(send_slot, send);
            fresh.write(null_mut());
        }
        Outcome::complete()
    }) }
}

/// Source-only transaction preserving status -> allocation -> send copy -> receive
/// copy -> commit precedence. Copy faults leave all published bytes unchanged.
///
/// # Safety
/// Retain actual thread/sigcommon lifetime across unlocked callbacks, with all
/// participants honoring the shared lock and initialized published info bytes.
/// Providers have the existing allocator/usercopy/tracked-free contracts; they may
/// reenter pending operations while this function is UNLOCKED. Callers must inspect
/// Outcome.disposition and may not return HELD_* as successful ptrace or errno.
/// Caller additionally adopts the proposed current-slot commit contract above.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_stage_and_commit_v1(
    thread: *mut Thread, data: CULong, alloc_flags: CULong,
    allocate: Allocate, free: Free, copy_from: CopyFrom,
) -> Outcome {
    let mut plan = StagePlan { status: 0, has_send: 0, has_receive: 0 };
    // SAFETY: Thread/sigcommon lifetime spans this transaction by caller contract.
    let observation = unsafe { f03_pending_stage_plan_v1(thread, &mut plan) };
    if observation.disposition != COMPLETE { return observation; }
    let mut fresh = null_mut();
    if plan.has_send == 0 {
        // SAFETY: Allocation occurs with no IRQ-save pending lock held.
        fresh = unsafe { allocate(size_of::<SigPending>(), alloc_flags) };
        if fresh.is_null() { return Outcome::error(-ENOMEM); }
        // SAFETY: Fully initialize private raw allocation, including info padding.
        // SigPending has integer, raw-pointer and union fields, with no Rust Drop.
        unsafe { fresh.cast::<u8>().write_bytes(0, size_of::<SigPending>()) };
    }
    let mut send = [0u8; size_of::<SigInfo>()];
    let mut receive = [0u8; size_of::<SigInfo>()];
    // SAFETY: Each callback writes to private, disjoint initialized scratch outside
    // the lock. A partial/failing write never changes a published pending node.
    let send_failed = unsafe { copy_from(send.as_mut_ptr(), data, send.len()) } != 0;
    let result = if send_failed {
        Outcome::error(-EFAULT)
    } else if plan.has_receive != 0
        && unsafe { copy_from(receive.as_mut_ptr(), data, receive.len()) } != 0 {
        Outcome::error(-EFAULT)
    } else {
        // SAFETY: Staging succeeded. Commit checks current shape and only accesses
        // node pointers acquired while locked; no borrowed pending pointer survived.
        unsafe { f03_pending_commit_current_v1(thread, &plan, send.as_ptr(),
            receive.as_ptr(), &mut fresh) }
    };
    if !fresh.is_null() {
        // SAFETY: Only our unpublished allocation remains; commit clears on transfer.
        unsafe { free(fresh) };
    }
    result
}

/// Get initialized receive bytes under lock, then perform faulting copy after unlock.
///
/// # Safety
/// Common lifetime/participant/status contracts apply; published info bytes must
/// be initialized. The copy provider has the genuine copy_to_user contract.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_get_snapshot_v1(
    thread: *mut Thread, data: CULong, copy_to: CopyTo,
) -> Outcome {
    let mut snapshot = [0u8; size_of::<SigInfo>()];
    // SAFETY: The snapshot never borrows the pending allocation after unlock.
    let observation = unsafe { with_pending_lock(thread, || {
        let current = current_plan(thread);
        if current.status & IO_ELIGIBLE == 0 || current.has_receive == 0 {
            return Outcome::error(-ESRCH);
        }
        let receive = read_volatile(addr_of_mut!((*thread).ptrace_recvsig));
        copy_nonoverlapping(addr_of_mut!((*receive.cast::<SigPending>()).info).cast::<u8>(),
            snapshot.as_mut_ptr(), snapshot.len());
        Outcome::complete()
    }) };
    if observation.disposition != COMPLETE { return observation; }
    // SAFETY: Private bytes remain live through synchronous unlocked usercopy.
    if unsafe { copy_to(data, snapshot.as_ptr(), snapshot.len()) } != 0 {
        Outcome::error(-EFAULT)
    } else { Outcome::complete() }
}

/// Detach both unique nodes under lock; caller retires them after lock release.
///
/// # Safety
/// In addition to common lifetime/participant contracts, final destruction must
/// exclude future publishers until thread/sigcommon retirement. This is an ACTUAL
/// lifecycle prerequisite, not supplied by this helper or inferred from refcount.
/// Outputs are disjoint writable pointers. COMPLETE transfers receive then send
/// ownership. HELD_ALIAS clears outputs but changes neither slot. No node is freed.
#[no_mangle]
pub unsafe extern "C" fn f03_pending_detach_for_destroy_v1(
    thread: *mut Thread, receive_output: *mut *mut c_void, send_output: *mut *mut c_void,
) -> Outcome {
    // SAFETY: Output storage is live and disjoint from thread and either slot.
    unsafe { receive_output.write(null_mut()); send_output.write(null_mut()); }
    // SAFETY: All slot accesses and ownership transfer occur under the common lock.
    unsafe { with_pending_lock(thread, || {
        if has_alias(thread) { return Outcome::held(HELD_ALIAS); }
        let receive = addr_of_mut!((*thread).ptrace_recvsig);
        let send = addr_of_mut!((*thread).ptrace_sendsig);
        receive_output.write(read_volatile(receive));
        send_output.write(read_volatile(send));
        write_volatile(receive, null_mut());
        write_volatile(send, null_mut());
        Outcome::complete()
    }) }
}
