Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Latest actual check: root's exact corrected retained-object two-command CPU0
grant completed PASS producer376/getter30/destroy5/ABI25, result a2308f2b.
Both children joined0, groups absent, streams closed, CPU0 released. Genuine
CLong/long callbacks and high-word nonzero error vectors passed the controlled
oracle. No Rust compile was replayed. See ACTUAL-CONTROLLED-411-ABI25-AND-CURSOR.json.
Independent actual-result acceptance is pending. Production/current-slot commit,
status/lifetime/participant/destructor-lock-order and external HELD contracts
remain open. No canonical, default, native or C-retirement credit is added.
The UNRUN/preparation descriptions below are historical evidence.

Latest correction: independent perf_review18h found the initial private usercopy
callback return ABI was int, whereas actual kernel/syscall.c provider typedefs
and Rust PtraceUserCopy*Fn return long/CLong. That initial object and all pins are
retained and must not enter the fixture. The current successor is
usercopy-long-abi-correction-1/: it imports exact production Rust aliases from
the parent module and includes exact extracted C provider typedefs with static
type compatibility checks. No truncating casts or adapters are used.
New changed-source Rust compile PASS first attempt; retained object d904db5d,
result 3622520b, normal join/group absence/closed streams and CPU0 release.
Prepared original385 plus26 high-word usercopy vectors total411, including
1L<<32 failures through the same EFAULT/rollback/no-publication oracle.
Corrected retained-object two-command suffix recipe444266b8/runner6c12a56b and
READY24bde050 remain NOT GRANTED/UNRUN pending independent review. The following
first-compile details and initial385-case recipe are historical context; use
ACTUAL-LONG-USERCOPY-ABI-CORRECTION-AND-CURSOR.json for the current check.

Status: private Rust object COMPILES; controlled C fixture UNRUN. The first
compile failed because recipe substitution emitted the wrong fixture cfg; its
E0432 and complete normal retirement remain retained. One permitted cfg-only
correction compiled the substantive Rust module, with no Rust source edits.
The successful object is 5,000 bytes/SHA b8f86a0781b21263cc222bdf125dac65e715e1ef40a3a52c8add09845566d8c9.
Corrected check wall .183665s/shared CPU .264082s/maximum child RSS 98,000KiB;
CPU0 released, direct child joined, group absent and streams closed.
No controlled fixture, model, runtime observer, root/module, guest or cleanup
execution. No production selectors or canonical sources changed.
This private lane owns only new-window-source-20-pending-commit-lifecycle/.
Do not use this source packet to release shared quarantined ownership.

The concrete defect is that an unlocked copy_from_user may overlap the existing
sigcommon-locked transfer and free a node borrowed by the producer. A tracee
reference, pointer equality or process.update_lock does not pin that allocation.
Source19 correctly identified that simply splitting Source18's transaction around
usercopy leaves this defect. This successor implements a pointer-free staging
boundary and does not reuse the externally-exclusive v2 transaction internally.
Source17/18/19 controlled acceptance remains at its original exact scope.

The private Rust module implements five exported internal bodies:

* f03_pending_stage_plan_v1 locks actual thread.sigcommon.lock, checks the existing
  STOPPED/TRACED eligibility bits and records only status and two presence flags.
  Its StagePlan contains no node address or reference and has no generation claim.
* f03_pending_stage_and_commit_v1 performs optional allocation before usercopy,
  initializes the entire unpublished allocation and two disjoint byte arrays,
  then performs the original send-before-receive copy sequence outside the lock.
  Copy failure rolls back only its own private allocation. No published pointer
  or info byte is changed by this transaction on copy failure.
* f03_pending_commit_current_v1 reacquires the same signal lock, rejects aliases
  and changed status/presence, obtains CURRENT nodes under that lock, updates their
  initialized info ranges and publishes a fresh send node only after both copies.
  No node pointer acquired by the plan survives across usercopy because the plan
  never acquired or returned such a pointer. Commit's borrowed pointers do not
  survive its critical section. A private unpublished allocation may span it.
* f03_pending_get_snapshot_v1 copies initialized receive info bytes under the
  signal lock and performs copy_to_user using private bytes after unlocking.
* f03_pending_detach_for_destroy_v1 atomically detaches distinct send/receive
  slots under the signal lock. Its outputs are transferred unique ownership,
  not borrowed published pointers. It performs no allocation or free. Final
  destruction must prohibit future publishers until thread retirement.

COMPLETE and SYSCALL_ERROR are internal dispositions with a separate signed
error field. HELD_STATE and HELD_ALIAS are internal refusal dispositions, each
with error=0, not ptrace success. There is no syscall adapter or automatic retry.
The caller must inspect disposition first. This deliberately makes an incomplete
ABI/lifecycle decision impossible to silently return as an existing syscall code.
Existing sequential lookup is left with the eventual caller: it must retain the
actual find_thread reference and release exactly once after private rollback or
commit. These helpers do not acquire/release that reference themselves.

In an unchanged, uniquely owned sequential state, the producer preserves status
error before allocation, allocation/ENOMEM before any usercopy, first-copy EFAULT
before second copy, second-copy EFAULT before commit, and send-before-receive
write order. Alias handling is held because the existing transfer/free domain
requires distinct allocations. Failure-atomic publication is the intentional
Source18 repair of the original early-publication/partial-commit behavior; it is
not claimed byte-for-byte equivalent to that defective failure behavior.

The proposed commit contract is explicit and remains UNACCEPTED: after staging,
commit updates the current eligible slots when status and presence match the
observation. Replacement nodes may differ from snapshot time, and allocator ABA
may leave the same address holding a different allocation. This implementation
does not compare addresses or assert that shape detects identity changes. It
operates on the current live allocation while locked. Thus the old borrowed-node
hazard is removed under the stated protocol, but only a real ownership/concurrency
review can decide whether current-slot commit matches intended ptrace behavior.
If identity preservation is required, the selected ABI has no proved version or
pin; full selection stays blocked. HELD_STATE has no approved external behavior.

Exact selected ownership/caller map (hashes in the recipe)

| Selected location | Existing authority and action | Required integration |
| --- | --- | --- |
| kernel/syscall.c ptrace_setsiginfo, selected ptrace_setsiginfo_body_result in kernel/rust/syscall_policy.rs | find_thread retains a tracee, then snapshots status/slots without sigcommon lock; current body publishes fresh before usercopy | Replace producer only after current-slot commit and real caller lifetime/status contracts are accepted. Source18 v2 is not safe merely by adding two lock calls. |
| kernel/syscall.c ptrace_getsiginfo / Rust f03_ptrace_getsiginfo_v1 and ptrace_getsiginfo_body_result | Reads pending receive info with retained tracee but no continuing shared lock | Bind get-snapshot to actual find/unlock and copy_to_user providers, keep initialized-byte prerequisite and errors. |
| kernel/rust/syscall_policy.rs ptrace_wakeup_sig_body_result; kernel/rust/process_helpers.rs process_thread_ptrace_pending_signal_take_result | process.update_lock is released after flag mutation; pending take/copy/free lacks sigcommon lock | Reuse Source19 locked snapshot/detach with actual Source17 outer; consume detached ownership outside lock through existing free-before-kill order and final thread_unlock. Alias refusal has no syscall mapping. |
| kernel/rust/syscall_policy.rs arch_do_signal_default_pending_transfer_result | Already called holding sigcommon.lock and original typed IRQ-save node; retires old receive, publishes incoming, retires old send, clears send, unlocks | Preserve this actual selected lock and caller/node lifetime. Source20 adds no second lock around this already-locked function. Its distinct-allocation precondition remains. |
| kernel/rust/process_helpers.rs destroy_thread -> process_destroy_thread_body_result -> process_destroy_thread_optional_cleanup_result | Existing threads_lock spans destruction; optional cleanup directly reads/frees debugreg, receive, send without clearing slots; release_sigcommon follows it | Need a coherent insertion before release_sigcommon, detach pending under sigcommon lock, free detached nodes once outside it, and prevent old optional cleanup from freeing them again. Retain debugreg/FP/coredump behavior and original receive-before-send free order. Review actual threads_lock -> sigcommon.lock order and exclusion of new publishers before integration. |
| kernel/rust/process_helpers.rs release_thread / find_thread / thread_unlock | Reference management is a lifetime route, not pending-node pinning or proof that sigcommon is stable across every call | Prove actual reference/teardown path and immutable sigcommon relationship for each new caller. |

Small unsafe invariants

1. Thread and its same sigcommon allocation stay live across lock acquisition,
   unlocked provider calls, commit and unlock. Status access additionally needs
   actual lifecycle exclusion; volatile alone is not synchronization and the
   signal lock does not itself prove all status writers participate.
2. Every publisher/getter/take/transfer/destructor uses that same signal lock.
   Existing unconverted participants violate this candidate's eligibility.
3. Published info bytes, including padding/union storage read as bytes, are
   initialized; each live node is uniquely owned by one slot or detached owner.
   The only pointer allowed to span unlocked staging is the private allocation.
4. Private scratch/output regions are disjoint and initialized; genuine metadata
   and C ABI are checked before fixture execution. The allocator returns aligned
   SigPending-sized storage and free retains genuine tracked-free semantics.
5. The MCS node stays on the stack until matching synchronous unlock. No usercopy,
   allocator, destructor callback, scheduler or fallible operation runs while
   the lock is held. Detached output does not retain the stack lock node.
6. Final destructor admission independently excludes future publishers. Detaching
   alone is not a closing flag, admission barrier or proof of final lifetime.

Prepared smallest executable check

The root-level recipe/runner and first failure are historical retained evidence.
fixture-cfg-correction-1/EXACT-LIFECYCLE-COMMANDS.NOT-GRANTED.json holds corrected
three-command argv tuples: compile the private module with the candidate cfg;
link the genuine-header C driver with the new object; run its controlled regression.
The compile prefix is now completed and MUST NOT be replayed. Current next check
is fixture-cfg-correction-1/EXACT-FIXTURE-SUFFIX-COMMANDS.NOT-GRANTED.json:
two commands reusing the exact retained object with hash and filesystem identity.
Its matching runner and READY-FOR-INDEPENDENT-REVIEW.NOT-GRANTED.json are prepared;
neither suffix command has run. Fresh ordinary CPU0 release and
the existing reviewed resource/capture profile are prerequisites. The fixture
compares 25 C/Rust geometry words, including Thread.status, signal lock/node,
SigPending/info and internal StagePlan/Outcome layout. Real header function types
bind the existing MCS symbols; the fixture uses controlled endpoints, not native
IRQ execution. Provider callbacks require the lock to be released for allocation,
usercopy and private free. Same-node lock/unlock identity is checked.

Prepared cases: 360 producer combinations (five slot states, allocation fault,
two copy-fault positions plus success, untouched/partial failed scratch, and six
interleavings); 20 getter combinations; five destructor shapes. Interleavings
cover no change, same-shape different allocations, changed receive presence,
changed status, alias introduction and explicitly modeled same-address generation
replacement. The oracle expects current-node updates only under the proposed
contract, preserves callback error precedence, and verifies rollback/private
allocation balance. Getters supply old snapshotted bytes even after reentrant
replacement. Destructor outputs are checked for ownership and empty slots, with
aliases untouched. Static fixture storage models allocation generations without
reading actual freed memory. None of these checks has run.

Remaining production/native gates

Independent review must first accept or reject current-slot commit semantics,
initialization assumptions, actual lifetime/status exclusion, callback ABI and
lock order. It must define a legitimate changed-state/alias external contract,
or keep those paths blocked; inventing EAGAIN, retries, generations or refcounts
is not authorized by source evidence. Then central ownership coordinates all
producer/getter/take/transfer/final-destruction participant edits, with no partial
selection. In particular, the destructor helper cannot simply be inserted before
the old pending frees without clearing/removing those actual reads/frees.

After these source prerequisites, run the genuine-header controlled tuple under
its actual grant, then current wholecrate/selected/fallback C/ABI/partial-link
qualification. Root owns those integration edits and actual compiler admission.
Real current-candidate native ptrace set/get/resume, copy/allocation fault,
transfer overlap and final resource restoration remain required. Existing
quarantined parent/shared exclusion is untouched. A controlled HOST pass would
qualify only this explicit contract and ABI, never native serialization, whole
callback selection, whole-file closure or C retirement.
