// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
#[path = "/home/holden/mckernel/kernel/rust/abi.rs"]
mod abi;

mod lock_helpers {
    use crate::abi::CULong;
    pub use crate::abi::McsRwlockLock;
    // Exact existing lock_helpers.rs node representation, checked against genuine C.
    #[repr(C, align(64))]
    pub struct McsRwlockNodeIrqsave { irqsave: CULong }
    unsafe extern "C" {
        pub fn __mcs_rwlock_writer_lock(
            lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave,
        );
        pub fn __mcs_rwlock_writer_unlock(
            lock: *mut McsRwlockLock, node: *mut McsRwlockNodeIrqsave,
        );
    }
}

#[cfg(f03_pending_lifecycle_candidate)]
mod pending_lifecycle;

use core::mem::{align_of, offset_of, size_of};
use abi::{CLong, CULong, SizeT};
include!("genuine_usercopy_types.RUST-DECLARATIONS.inc");
use pending_lifecycle::{Outcome, StagePlan};

#[no_mangle]
pub static f03_lifecycle_Rust_ABI: [usize; 25] = [
    size_of::<abi::Thread>(), align_of::<abi::Thread>(), offset_of!(abi::Thread, sigcommon),
    offset_of!(abi::Thread, ptrace_sendsig), offset_of!(abi::Thread, ptrace_recvsig),
    size_of::<abi::SigCommon>(), align_of::<abi::SigCommon>(), offset_of!(abi::SigCommon, lock),
    size_of::<abi::SigPending>(), align_of::<abi::SigPending>(), offset_of!(abi::SigPending, info),
    size_of::<abi::SigInfo>(), align_of::<abi::SigInfo>(),
    size_of::<abi::McsRwlockLock>(), align_of::<abi::McsRwlockLock>(),
    size_of::<lock_helpers::McsRwlockNodeIrqsave>(), align_of::<lock_helpers::McsRwlockNodeIrqsave>(),
    offset_of!(abi::Thread, status), size_of::<StagePlan>(), align_of::<StagePlan>(),
    offset_of!(StagePlan, has_receive), size_of::<Outcome>(), align_of::<Outcome>(),
    offset_of!(Outcome, error), offset_of!(StagePlan, has_send),
];
