# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
from pathlib import Path
import ast,datetime,hashlib,json,re,stat
R=Path('/home/holden/mckernel');BASE=R/'docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu';D=BASE/'new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1';B=D/'complete-genuine-ABI14-witness-suffix07-source-1';Q=D/'exact-fullcrate-logger-GLOBAL1-retained12-source-1';S=BASE/'new-window-source-17-current285-five-data-owner-union-source-1/bounded-whole-C-table-section-profile-successor-1'
def pin(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def emit(n,x):p=Q/n;p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n');return pin(p)
oldhelper=D/'observe_logger_allocated_data.SOURCE-ONLY.py';newhelper=Q/'observe_logger_fullcrate_GLOBAL1.py';s=(B/'observe_new_metadata.py').read_text();needle=repr(pin(oldhelper));assert s.count(needle)==1;s=s.replace(needle,repr(pin(newhelper)));ast.parse(s);(Q/'observe_new_metadata.py').write_text(s)
orig=json.loads((S/'EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json').read_text());producer={}
for directory,indices in [(D/'actual-current290-attempt-1',range(4)),(D/'genuine-uti-header-transport-suffix04-source-1/actual-suffix04-12-attempt-1',(4,5)),(B/'actual-suffix07-12-attempt-1',(7,8,9))]:
 for i in indices:
  cap=directory/f'{i:02d}';record=json.loads((cap/'DURABLE-OBJECT-BEFORE-OBSERVERS.json').read_text());path=record['artifact']['path'];producer[path]={'artifact':pin(Path(path)),'actual_producer':pin(cap/'command.json'),'actual_join':pin(cap/'WHOLE-JOIN.json'),'actual_durable_binding':pin(cap/'DURABLE-OBJECT-BEFORE-OBSERVERS.json')}
assert len(producer)==9
profile=json.loads((B/'EXACT-CURRENT290-SUFFIX07-12.NOT-GRANTED.json').read_text())['profile'];q={'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','status':'SOURCE_ONLY_TWO_COMMANDS_PURE_AND_RETAINED_METADATA12_NOT_GRANTED','root_contract':'m14.current290.entry-callbacks','profile':profile,'compiler_link_replay':False,'original_failure':pin(B/'actual-suffix07-12-attempt-1/FAILURE.STOP.json'),'original_handoff':pin(B/'ACTUAL-CURRENT290-OBJECT-PASS-LOGGER-BINDING-FAILURE-HANDOFF.COMPLETE.json'),'original_recipe':pin(B/'EXACT-CURRENT290-SUFFIX07-12.NOT-GRANTED.json'),'retained_outputs':list(producer.values()),'retained_successful_commands':list(range(12)),'actual_fixed_profile_census':pin(Q/'TINY-EXACT-FOUR-LOGGER-GLOBAL1-CENSUS.ACTUAL-RETAINED.json'),'profile_source':pin(Q/'EXACT-WHOLECRATE-GLOBAL1-PROFILE.SOURCE-ONLY.json'),'commands':[{'argv':['/home/holden/anaconda3/bin/python3','-I','-B',str(Q/'pure_logger_GLOBAL1_profile.py')],'cwd':str(D),'label':'00-focused-pure-GLOBAL1-profile-controls','purpose':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing. Two positive and38negative model controls hit actual newprofile helper/descriptor rejection paths; no actual ELF/compiler/native.'},{'argv':['/home/holden/anaconda3/bin/python3','-I','-B',str(Q/'observe_new_metadata.py')],'cwd':str(D),'label':'01-retained-original-index12-only','purpose':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing. Retained current290 metadata12 with exactGLOBAL1 loggerprofile then genuine ptrace19/exec checks; no compiler/link/main/F04 replay.'}]};emit('EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json',q)
a=json.loads((B/'EXACT-FIXED-INPUT-FD-AUTHORITY.json').read_text());inputs={r['path']:r for r in a['rows']}
def ident(p):
 t=p.stat();assert stat.S_ISREG(t.st_mode);return {k:getattr(t,k) for k in ['st_ctime_ns','st_dev','st_gid','st_ino','st_mode','st_mtime_ns','st_nlink','st_size','st_uid']}
for row in a['rows']:assert ident(Path(row['path']))==row['fresh_readonly_FD_identity'],row['path']
def add(p):
 p=p.resolve();t=ident(p);x=pin(p);assert ident(p)==t;inputs[str(p)]={'path':str(p),'sha256':x['sha256'],'bytes':x['bytes'],'expected_size':x['bytes'],'maximum':x['bytes']+4096,'fresh_readonly_FD_identity':t}
for p in Q.iterdir():
 if p.is_file():add(p)
for item in q['retained_outputs']:
 for v in item.values():add(Path(v['path']))
for p in [B/'ROOT-GRANT.json',B/'ACTUAL-CURRENT290-OBJECT-PASS-LOGGER-BINDING-FAILURE-HANDOFF.COMPLETE.json',B/'actual-suffix07-12-attempt-1/FAILURE.STOP.json',B/'actual-suffix07-12-attempt-1/12/stderr',D/'ACTUAL-UNION-PROVIDERS.COMMON-CORRECTED.json']:
 add(p)
for p in (D/'storage-observation-1').iterdir():
 if p.is_file():add(p)
a['rows']=sorted(inputs.values(),key=lambda r:r['path']);a['count']=len(a['rows']);emit('EXACT-FIXED-INPUT-FD-AUTHORITY.json',a)
s=(S/'run_retained_data5_observer_once.NOT-GRANTED.py').read_text();s=s.replace(str(S.parent),str(D))
# This derivative's config lives in newQ; source/compiled inputs stay in B.
s=re.sub(r'^WORK_CWD = Path\([^\n]+\)', 'WORK_CWD = Path('+repr(str(D))+')',s,flags=re.M)
s=re.sub(r'^M = Path\([^\n]+\)', 'M = Path('+repr(str(B/'FROZEN-CURRENT290-SOURCE-AND-HEADER-BINDINGS.json'))+')',s,flags=re.M)
for field,path in [('F_SHA',Q/'EXACT-FIXED-INPUT-FD-AUTHORITY.json'),('R_SHA',Q/'EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json'),('M_SHA',B/'FROZEN-CURRENT290-SOURCE-AND-HEADER-BINDINGS.json')]:s=re.sub(r'^'+field+r" = '[0-9a-f]+'",field+' = '+repr(pin(path)['sha256']),s,flags=re.M)
s=s.replace('CURRENT285','CURRENT290').replace('current285','current290');ast.parse(s);driver=Q/'run_pure_and_retained_logger12_once.NOT-GRANTED.py';driver.write_text(s)
def fs(src):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)}
assert fs(s)==fs((S/'run_retained_data5_observer_once.NOT-GRANTED.py').read_text());assert fs((Q/'observe_new_metadata.py').read_text())==fs((B/'observe_new_metadata.py').read_text())
ready={'scope':q['scope'],'status':'SOURCE_READY_PENDING_INDEPENDENT_EXPERT_REVIEW_AND_ROOT_ONCE_GRANT','contract':q['root_contract'],'driver':pin(driver),'recipe':pin(Q/'EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json'),'fixed_FD_authority':pin(Q/'EXACT-FIXED-INPUT-FD-AUTHORITY.json'),'manifest':pin(B/'FROZEN-CURRENT290-SOURCE-AND-HEADER-BINDINGS.json'),'profile':profile,'pure_controls':{'positive':2,'negative':38,'status':'SOURCE_ONLY_UNRUN'},'actual_retained_observer_indices':[12],'new_compiler_link_commands':0,'retained_nine_artifacts':list(producer.values()),'source_profile_helper':pin(newhelper),'actual_exact_census':pin(Q/'TINY-EXACT-FOUR-LOGGER-GLOBAL1-CENSUS.ACTUAL-RETAINED.json'),'same_metadata_foundation_helper_AST':True,'same_driver_lifecycle_helper_AST':True,'observed_ready_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'enqueue_UTC':None,'actual_first_compiler_UTC':None,'no_actual290_acceptance':True,'argv':['taskset','-c','6','/home/holden/anaconda3/bin/python3','-B',str(driver)]};emit('EXECUTABLE-READY.NOT-GRANTED.json',ready);(Q/'freeze_retained12_source_only.py').write_bytes(Path(__file__).read_bytes());print(pin(Q/'EXECUTABLE-READY.NOT-GRANTED.json'));print(pin(driver));print(pin(Q/'EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json'));print('FD',a['count'])
