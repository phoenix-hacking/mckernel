"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual new selected metadata bytes and allocated RELA; old anonymous debt stays open.
"""
from pathlib import Path
import ast
import hashlib
import json
import struct
D = Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1')
O = D / "output-1"
P = json.loads((D / "CPU37-OBSERVATION-CONTRACT.json").read_bytes())
C = json.loads((D / "PROVIDER-CONTRACT.FROZEN78-PLUS-F04100.json").read_bytes())
row = P["Elf_source"]
raw = Path(row["path"]).read_bytes()
assert hashlib.sha256(raw).hexdigest() == row["sha256"]
t = ast.parse(raw)
nodes = [n for n in t.body if isinstance(n, (ast.Import, ast.ImportFrom)) or isinstance(n, ast.ClassDef) and n.name == "Elf" or isinstance(n, ast.FunctionDef) and n.name in {"object_bytes", "owning_relocations"}]
ns = dict(Path=Path, struct=struct)
exec(compile(ast.Module(body=nodes, type_ignores=[]), row["path"], "exec"), ns)
Elf = ns["Elf"]
object_bytes = ns["object_bytes"]
owning_relocations = ns["owning_relocations"]
rust = Elf(O / "mckernel_rust.cpu37.o")
process = Elf(O / "process.selected.o")
partial = Elf(O / "CPU37.partial.o")
reference_row = C["source10_actual_fixture"]
reference_raw = Path(reference_row["path"]).read_bytes()
assert hashlib.sha256(reference_raw).hexdigest() == reference_row["sha256"]
reference = Elf(Path(reference_row["path"]))
def defined(elf, predicate):
    rows = [r for r in elf.symbols if r["type"] == 1 and 0 < r["shndx"] < len(elf.sections) and predicate(r)]
    assert len(rows) == 1, rows
    return rows[0]
DECLARED_DEBUG_SYMBOLS = {'ENTER_DEBUG': '_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy26f06_full_do_kill_candidate11ENTER_DEBUG', 'IPI_DEBUG': '_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy28f06_do_kill_wakeup_candidate9IPI_DEBUG'}
def exact_declared_debug(elf, marker):
    name = DECLARED_DEBUG_SYMBOLS[marker]
    rows = [row for row in elf.symbols if row["name"] == name]
    assert len(rows) == 1, (marker, name, rows)
    symbol = rows[0]
    assert symbol["bind"] == 1 and symbol["type"] == 1, symbol
    assert 0 < symbol["shndx"] < len(elf.sections), symbol
    assert 0 <= symbol["index"] < len(elf.symbols), symbol
    other_offset = elf.table["offset"] + symbol["index"] * elf.table["entsize"] + 5
    # Exact retained Rust/partial records expose GLOBAL OBJECT / DEFAULT0.
    assert elf.raw[other_offset] == 0, (marker, "unexpected symbol visibility")
    return symbol

def cstring(elf, relocation):
    target = relocation["target"]
    assert relocation["type"] == 1 and 0 < target["shndx"] < len(elf.sections)
    section = elf.sections[target["shndx"]]
    assert section["flags"] & 2
    payload = elf.payload(section)
    start = target["value"] + relocation["addend"]
    assert 0 <= start < len(payload)
    return payload[start:payload.index(b"\0", start)].decode()
def descriptor(elf, symbol, filename, function, line):
    section = elf.sections[symbol["shndx"]]
    assert symbol["size"] == 32 and symbol["value"] % 8 == 0
    assert section["name"] == "__verbose" and section["flags"] & 3 == 3 and not section["flags"] & 4
    assert section["align"] >= 8
    initial = object_bytes(elf, symbol)
    assert initial[:24] == bytes(24) and initial[28:] == bytes(4)
    assert int.from_bytes(initial[24:28], "little") == line
    relas = owning_relocations(elf, symbol)
    assert len(relas) == 2 and {r["offset"] for r in relas} == {0, 8}
    for rela in relas:
        assert cstring(elf, rela) == (filename if rela["offset"] == 0 else function)
    return dict(symbol=symbol, initial_hex=initial.hex(), relocations=relas, filename=filename, function=function, line=line)
def allocated_edges(elf, symbol=None, external=None):
    edges = []
    for section in elf.sections:
        if section["type"] != 4 or not elf.sections[section["info"]]["flags"] & 2:
            continue
        assert section["link"] == elf.table["index"] and section["entsize"] == 24
        for at in range(section["offset"], section["offset"] + section["size"], 24):
            offset, info, addend = struct.unpack_from("<QQq", elf.raw, at)
            assert offset < elf.sections[section["info"]]["size"] and info >> 32 < len(elf.symbols)
            target = elf.symbols[info >> 32]
            owns = external is not None and target["name"] == external
            if symbol is not None and target["shndx"] == symbol["shndx"]:
                where = target["value"] + addend
                owns = owns or symbol["value"] <= where < symbol["value"] + symbol["size"]
            if owns:
                edges.append(dict(owner=section["info"], offset=offset, relocation_type=info & 0xffffffff, target=target, addend=addend))
    assert edges, (symbol, external, "no actual allocated consumer edge")
    return edges
reference_symbol = defined(reference, lambda r: r["name"] == "process_create_cpu_debug")
expected_initial = object_bytes(reference, reference_symbol)
assert expected_initial[24:28] == struct.pack("<I", 276)
process_proof = {}
for label, elf in (("selected_C", process), ("partial", partial)):
    symbol = defined(elf, lambda r: r["name"] == "process_create_cpu_debug")
    assert symbol["bind"] == 1 and object_bytes(elf, symbol) == expected_initial
    process_proof[label] = descriptor(elf, symbol, '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c', "process_create_cpu_log_bridge", 276)
    line = defined(elf, lambda r: r["name"] == "process_create_thread_alloc_pages_source_line")
    assert line["bind"] == 1 and line["size"] == 4
    assert object_bytes(elf, line) == struct.pack("<i", 788)
    assert elf.sections[line["shndx"]]["flags"] & 2 and not elf.sections[line["shndx"]]["flags"] & 5
    assert not owning_relocations(elf, line)
process_edges = {name: allocated_edges(rust, external=name) for name in ("process_create_cpu_debug", "process_create_thread_alloc_pages_source_line")}
policy = Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/complete-genuine-ABI14-witness-suffix07-source-1/compiler-source/kernel/rust/syscall_policy.rs')
lines = policy.read_text().splitlines()
arch_proof = {}
for marker in ("ENTER_DEBUG", "IPI_DEBUG"):
    starts = [i for i, line in enumerate(lines) if "static mut " + marker + ":" in line]
    assert len(starts) == 1
    start = starts[0]
    line_numbers = [i + 1 for i in range(start, min(start + 10, len(lines))) if "line_flags: line!()" in lines[i]]
    assert len(line_numbers) == 1
    pair = {}
    for label, elf in (("Rust", rust), ("partial", partial)):
        symbol = exact_declared_debug(elf, marker)
        pair[label] = descriptor(elf, symbol, str(policy), "do_kill", line_numbers[0])
        if label == "Rust":
            pair["actual_allocated_consumer_edges"] = allocated_edges(elf, symbol=symbol)
    assert pair["Rust"]["initial_hex"] == pair["partial"]["initial_hex"]
    arch_proof[marker] = pair
f03 = Elf(O / "F03.selected.o")
scheduler_row = C["scheduler_fixture"]
assert hashlib.sha256(Path(scheduler_row["path"]).read_bytes()).hexdigest() == scheduler_row["sha256"]
scheduler_reference = Elf(Path(scheduler_row["path"]))
expected_debug = defined(scheduler_reference, lambda r: r["name"] == "f03_sched_setparam_debug_v1")
expected_bytes = object_bytes(scheduler_reference, expected_debug)
assert expected_bytes[24:28] == struct.pack("<I", 26052)
scheduler_proof = {}
for label, elf in (("selected_C", f03), ("partial", partial)):
    symbol = defined(elf, lambda r: r["name"] == "f03_sched_setparam_debug_v1")
    assert symbol["bind"] == 1 and object_bytes(elf, symbol) == expected_bytes
    scheduler_proof[label] = descriptor(elf, symbol, str(D / "source/kernel/syscall.c"), "sched_setparam_log_bridge", 26052)
scheduler_edges = allocated_edges(rust, external="f03_sched_setparam_debug_v1")

# New exact named arrays: use the accepted 32-byte descriptor checker for each member.
def array_descriptors(elf, name, filename, function, expected_lines):
    symbol = defined(elf, lambda row: row["name"] == name)
    assert symbol["bind"] == 1 and symbol["size"] == 32 * len(expected_lines)
    records = []
    for index, expected_line in enumerate(expected_lines):
        member = dict(symbol, value=symbol["value"] + index * 32, size=32)
        records.append(descriptor(elf, member, filename, function, expected_line))
    assert len(owning_relocations(elf, symbol)) == len(expected_lines) * 2
    return dict(symbol=symbol, records=records)
process36_metadata = {label: array_descriptors(elf, "process_ptrace_traceme_debug", '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c', "process_ptrace_traceme_log_bridge", [236,240,243]) for label, elf in (("selected_C",process),("partial",partial))}
process36_edges = allocated_edges(rust, external="process_ptrace_traceme_debug")
signal_metadata = {label: array_descriptors(elf, "f03_kill_log_debug_v1", str(D / "source/kernel/syscall.c"), "syscall_kill_log_bridge", [8313,8315]) for label, elf in (("selected_C",f03),("partial",partial))}
signal_edges = allocated_edges(rust, external="f03_kill_log_debug_v1")
ptrace_start = next(i for i,line in enumerate(lines) if "pub static mut arch_ptrace_user_log_debug_v1:" in line)
ptrace_lines = [i+1 for i in range(ptrace_start,ptrace_start+20) if "line_flags: line!()" in lines[i]]
assert len(ptrace_lines) == 2
ptrace_metadata = {label: array_descriptors(elf, "arch_ptrace_user_log_debug_v1", str(policy), "arch_ptrace_user_log_bridge", ptrace_lines) for label,elf in (("Rust",rust),("partial",partial))}
ptrace_edges = allocated_edges(rust, symbol=defined(rust, lambda row: row["name"] == "arch_ptrace_user_log_debug_v1"))

def verify_tracked_free_line_cell(symbol, section, initial, relas):
    assert symbol["bind"] == 1 and symbol["type"] == 1 and symbol["size"] == 4
    assert section["flags"] & 2 and not section["flags"] & 5
    assert symbol["value"] % 4 == 0 and section["align"] >= 4
    assert initial == struct.pack("<i", 3501)
    assert not relas
    return dict(symbol=symbol, section=section, initial_hex=initial.hex(), relocations=relas)
tracked_free_line = {}
for label, elf in (("selected_C",process),("partial",partial)):
    symbol = defined(elf, lambda row: row["name"] == "process_free_thread_pages_source_line")
    tracked_free_line[label] = verify_tracked_free_line_cell(symbol, elf.sections[symbol["shndx"]], object_bytes(elf,symbol), owning_relocations(elf,symbol))
assert tracked_free_line["selected_C"]["initial_hex"] == tracked_free_line["partial"]["initial_hex"]
tracked_free_line_edges = allocated_edges(rust, external="process_free_thread_pages_source_line")

# New process debug descriptors retain genuine C identities; no filename normalization.
new_process = {}
for record in C["process_new3_metadata"]["descriptor_records"]:
    name=record["symbol"]
    if name=="process_free_range_body_debug":
        continue  # The genuine three-record array is checked below with per-record functions.
    pair={}
    for label,elf in (("selected_C",process),("partial",partial)):
        symbol=defined(elf,lambda row:row["name"]==name)
        assert symbol["bind"]==1
        pair[label]=descriptor(elf,symbol,'/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c',record["func"],record["line"])
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,external=name)
    new_process[name]=pair
free_records=[]
for label,elf in (("selected_C",process),("partial",partial)):
    symbol=defined(elf,lambda row:row["name"]=="process_free_range_body_debug")
    assert symbol["bind"]==1 and symbol["size"]==96
    values=[]
    for index,(function,line) in enumerate((("process_free_range_log_bridge",1947),("process_free_range_log_bridge",1955),("free_process_memory_range",1964))):
        values.append(descriptor(elf,dict(symbol,value=symbol["value"]+index*32,size=32),'/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c',function,line))
    assert len(owning_relocations(elf,symbol))==6
    free_records.append(dict(label=label,symbol=symbol,records=values))
free_record_edges=allocated_edges(rust,external="process_free_range_body_debug")
new_readonly={}
for name,value in (("process_free_range_pages_source_line",1873),("process_page_fault_anon_clear_profile_event",4002)):
    pair={}
    for label,elf in (("selected_C",process),("partial",partial)):
        symbol=defined(elf,lambda row:row["name"]==name);section=elf.sections[symbol["shndx"]]
        assert symbol["bind"]==1 and symbol["size"]==4 and symbol["value"]%4==0
        assert section["flags"]&2 and not section["flags"]&5 and section["align"]>=4
        initial=object_bytes(elf,symbol);assert initial==struct.pack("<i",value) and not owning_relocations(elf,symbol)
        pair[label]=dict(symbol=symbol,initial_hex=initial.hex())
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,external=name);new_readonly[name]=pair
# Profile constant is meaningful only for this exact paired current profile.
recipe=json.loads((Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/complete-genuine-ABI14-witness-suffix07-source-1/EXACT-CURRENT290-SUFFIX07-12.NOT-GRANTED.json')).read_bytes())
assert "-DPROFILE_ENABLE" in json.loads(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/actual-current285-data5-attempt-1/00/command.json').read_bytes())["argv"]
assert "enable_profile" in recipe["commands"][8]["argv"]
new_arch={}
for name,count in (("arch_mmap_log_debug_v1",2),("arch_shmget_log_debug_v1",2),("arch_vdso_public_log_debug_v1",4)):
    start=next(i for i,line in enumerate(lines) if "pub static mut "+name+":" in line)
    end=next(i for i in range(start+1,len(lines)) if lines[i].strip()=="];")
    expected_lines=[i+1 for i in range(start,end) if "line_flags: line!()" in lines[i]]
    assert len(expected_lines)==count
    function=name.replace("_debug_v1","_bridge")
    pair={label:array_descriptors(elf,name,str(policy),function,expected_lines) for label,elf in (("Rust",rust),("partial",partial))}
    pair["actual_Rust_allocated_consumer"]=allocated_edges(rust,symbol=defined(rust,lambda row:row["name"]==name))
    new_arch[name]=pair
# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
# Replace ONLY the old block headed:
# 'Dispatch descriptor and unchanged genuine sparse C table are independently bound.'
# through its dispatch_edges assignment. All existing285 source/data/trace gates stay.
table_contract = json.loads(Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/complete-genuine-ABI14-witness-suffix07-source-1/TABLE-UNION-INPUTS.SOURCE-ONLY.json').read_bytes())
whole_TU_profile = table_contract['whole_TU_fallback_profile']
for binding in whole_TU_profile['bound_files']:
    payload = Path(binding['path']).read_bytes()
    assert len(payload) == binding['bytes'] and hashlib.sha256(payload).hexdigest() == binding['sha256']
# Bind the actual newly produced fallback identity before choosing its exact
# source-qualified section profile; historical source17 geometry remains retained.
durable_fallback = json.loads((Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/genuine-uti-header-transport-suffix04-source-1/actual-suffix04-12-attempt-1/05/DURABLE-OBJECT-BEFORE-OBSERVERS.json')).read_bytes())
fallback_artifact = durable_fallback['artifact']
assert fallback_artifact['path'] == str(O / 'F03.fallback.o')
fallback_raw = Path(fallback_artifact['path']).read_bytes()
assert len(fallback_raw) == fallback_artifact['size']
assert hashlib.sha256(fallback_raw).hexdigest() == fallback_artifact['sha256']
assert durable_fallback['producer_index'] == 5
assert durable_fallback['producer_command'] == recipe['commands'][5]
assert durable_fallback['producer_join']['returncode'] == 0
assert durable_fallback['producer_join']['direct_child_joined']
assert durable_fallback['producer_join']['group_absent']
assert durable_fallback['producer_join']['closed_streams']
actual_fallback_command = json.loads((Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/genuine-uti-header-transport-suffix04-source-1/actual-suffix04-12-attempt-1/05/command.json')).read_bytes())
assert actual_fallback_command == whole_TU_profile['exact_F03_fallback_command']
assert actual_fallback_command == json.loads((D / 'EXACT-CURRENT290-THIRTEEN-COMMANDS.SOURCE-ONLY.NOT-GRANTED.json').read_bytes())['commands'][5]
for key in ('observer', 'slot_manifest', 'provider_reference'):
    row = table_contract[key]
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
observer_row = table_contract['observer']
owned_namespace = {}
exec(compile(Path(observer_row['path']).read_bytes(), observer_row['path'], 'exec'),
     owned_namespace)
manifest = json.loads(Path(table_contract['slot_manifest']['path']).read_bytes())
provider_reference = json.loads(Path(table_contract['provider_reference']['path']).read_bytes())
# Verify original selected reference remains exactly117 configured provider slots;
# this moves storage ownership, not a provider/function body or its declaration.
reference_row = C['F03_dispatch_reference']
assert hashlib.sha256(Path(reference_row['path']).read_bytes()).hexdigest() == reference_row['sha256']
dispatch_reference = Elf(Path(reference_row['path']))
expected_table = defined(dispatch_reference, lambda row: row['name'] == 'syscall_table')
assert expected_table['size'] == 4025 * 8
expected_edges = owning_relocations(dispatch_reference, expected_table)
expected_slots = {(row['offset'] // 8): row['target']['name'] for row in expected_edges}
assert len(expected_edges) == len(expected_slots) == 117
assert expected_slots == {row['slot']: 'sys_' + row['name']
                         for row in manifest['all_declarations']
                         if all(manifest['current_flags'][guard] for guard in row['guards'])}
for row in expected_edges:
    assert row['offset'] % 8 == 0 and row['type'] == 1 and row['addend'] == 0
table_union_proof = owned_namespace['verify_union'](
    rust, f03, partial, Elf(O / 'F03.fallback.o'),
    {'Rust': rust, 'F03_C': f03},
    manifest, provider_reference, owning_relocations, object_bytes)
dispatch_proof = table_union_proof['descriptor']
# Retain this exact existing actual Rust instruction-consumer edge gate.
dispatch_edges = allocated_edges(rust, external='f03_syscall_dispatch_binding_v1')

# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
# Added to the retained exact descriptor/cell observer; its helper bodies stay unchanged.
data_map = json.loads((D / "PROCESS43-TEN-DATA-AND-ATOMIC-WITNESS-MAP.json").read_bytes())
post230_data = {}
for entry in data_map["ten_data"]:
    name = entry["name"]
    row = entry["fixture_object"]
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
    fixture = Elf(Path(row["path"]))
    reference_symbol = defined(fixture, lambda symbol: symbol["name"] == name)
    expected = object_bytes(fixture, reference_symbol)
    assert len(expected) == entry["bytes"]
    result = {}
    for label, elf in (("selected_C", process), ("partial", partial)):
        symbol = defined(elf, lambda symbol: symbol["name"] == name)
        assert symbol["bind"] == 1 and symbol["size"] == entry["bytes"]
        section = elf.sections[symbol["shndx"]]
        assert section["flags"] & 2 and not section["flags"] & 4
        initial = object_bytes(elf, symbol)
        assert initial == expected, (name, label, initial.hex(), expected.hex())
        relocations = owning_relocations(elf, symbol)
        if name == "process_schedule_switch_debug":
            result[label] = descriptor(elf, symbol, '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c', "schedule", 4684)
        elif "descriptors" in entry:
            assert section["name"] == "__verbose" and section["align"] >= 8
            records = []
            for index, record in enumerate(entry["descriptors"]):
                member = dict(symbol, value=symbol["value"] + 32 * index, size=32)
                records.append(descriptor(elf, member, '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c', record["function"], record["line"]))
            assert len(relocations) == 2 * len(records)
            result[label] = records
        elif name == "process_idle_callbacks":
            assert initial == bytes(80) and len(relocations) == 10
            assert sorted((rela["offset"], rela["type"], rela["target"]["name"], rela["addend"]) for rela in relocations) == [
                (8 * index, 1, target, 0) for index, target in enumerate(entry["targets"])
            ]
            result[label] = dict(symbol=symbol, initial_hex=initial.hex(), relocations=relocations)
        else:
            assert not relocations, (name, relocations)
            if "value" in entry:
                assert symbol["value"] % 4 == 0 and section["align"] >= 4
                assert not section["flags"] & 5 and initial == struct.pack("<I", entry["value"])
            if name == "process_schedule_exit_debug_input":
                assert initial == bytes(8) and symbol["value"] % 8 == 0
            result[label] = dict(symbol=symbol, initial_hex=initial.hex(), relocations=relocations)
    result["actual_Rust_allocated_consumer"] = allocated_edges(rust, external=name)
    # These declarations remain project C data debt, even when Rust consumes them.
    post230_data[name] = result

# The selected AtomicU32 is private zero-initialized storage, not a C-data retirement claim.
counter_name = "_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust15process_helpers32remaining_process_schedule_entry25MCEXEC_V10_SCHEDULER_LOGS"
counter_proof = {}
for label, elf in (("Rust", rust), ("partial", partial)):
    symbol = defined(elf, lambda row: row["name"] == counter_name)
    section = elf.sections[symbol["shndx"]]
    assert symbol["bind"] == 0 and symbol["size"] == 4
    assert symbol["value"] % 4 == 0 and section["align"] >= 4
    assert section["type"] == 8 and section["flags"] & 3 == 3 and not section["flags"] & 4
    assert not owning_relocations(elf, symbol)
    edges = allocated_edges(elf, symbol=symbol)
    schedule_rows = [row for row in elf.symbols if row["name"] == "schedule" and row["type"] == 2 and row["bind"] == 1 and 0 < row["shndx"] < len(elf.sections)]
    assert len(schedule_rows) == 1
    schedule_symbol = schedule_rows[0]
    code_edges = [edge for edge in edges if edge["owner"] == schedule_symbol["shndx"] and schedule_symbol["value"] <= edge["offset"] < schedule_symbol["value"] + schedule_symbol["size"] and elf.sections[edge["owner"]]["flags"] & 4]
    assert code_edges, (label, "counter has no allocated instruction consumer")
    counter_proof[label] = dict(symbol=symbol, section=section, semantic_zero_bytes=4, instruction_edges=code_edges)

smp_metadata = {}
for marker in ("F06_MOVE_PHASE1_DEBUG", "F06_MOVE_PHASE2_DEBUG", "F06_MOVE_PHASE3_DEBUG", "F06_MOVE_LOOKUP_DEBUG", "F06_MOVE_ALLOC_DEBUG", "F06_MOVE_COPY_DEBUG"):
    starts = [index for index, line in enumerate(lines) if line.startswith("static mut " + marker + ":")]
    assert len(starts) == 1
    start = starts[0]
    expected_lines = [index + 1 for index in range(start, start + 8) if "line_flags: line!()" in lines[index]]
    assert len(expected_lines) == 1
    pair = {}
    for label, elf in (("Rust", rust), ("partial", partial)):
        name = "_RNvNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy%d%s" % (len(marker), marker)
        symbol = defined(elf, lambda row: row["name"] == name)
        assert symbol["bind"] == 1
        assert elf.raw[elf.table["offset"] + symbol["index"] * elf.table["entsize"] + 5] == 0
        pair[label] = descriptor(elf, symbol, str(policy), "move_pages_smp_handler", expected_lines[0])
        pair[label]["actual_allocated_consumer"] = allocated_edges(elf, symbol=symbol)
    assert pair["Rust"]["initial_hex"] == pair["partial"]["initial_hex"]
    smp_metadata[marker] = pair

# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
# Additive exact current285 C metadata; all accepted277 helper predicates remain intact.
later7_contract = json.loads((D / "LATER7-ABI-DATA-REVIEW-CONTRACT.json").read_bytes())
post285_process_data = {}
for entry in later7_contract["data"]:
    name = entry["symbol"]
    row = entry["object"]
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
    witness = Elf(Path(row["path"]))
    witness_symbol = defined(witness, lambda value: value["name"] == name)
    expected = object_bytes(witness, witness_symbol)
    assert len(expected) == entry["bytes"]
    pair = {}
    for label, elf in (("selected_C", process), ("partial", partial)):
        symbol = defined(elf, lambda value: value["name"] == name)
        section = elf.sections[symbol["shndx"]]
        assert symbol["bind"] == 1 and symbol["size"] == entry["bytes"]
        assert symbol["value"] % 8 == 0 and section["align"] >= 8
        assert object_bytes(elf, symbol) == expected
        relas = owning_relocations(elf, symbol)
        if "descriptors" in entry:
            records = []
            for index, record in enumerate(entry["descriptors"]):
                member = dict(symbol, value=symbol["value"] + 32 * index, size=32)
                records.append(descriptor(elf, member, '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-17-current285-five-data-owner-union-source-1/source/kernel/process.c', record["function"], record["line"]))
            assert len(relas) == 36 and len(records) == 18
            pair[label] = dict(symbol=symbol, records=records)
        else:
            assert section["flags"] & 2 and not section["flags"] & 5
            assert expected == bytes(8) and not relas
            pair[label] = dict(symbol=symbol, section=section, initial_hex=expected.hex(), relocations=relas)
    pair["actual_Rust_allocated_consumer"] = allocated_edges(rust, external=name)
    post285_process_data[name] = pair

entry_metadata = {
    label: array_descriptors(elf, "f03_syscall_entry_debug_v1", str(D / "source/kernel/syscall.c"), "syscall", [28800, 28812, 28821, 28828, 28831, 28876])
    for label, elf in (("selected_C", f03), ("partial", partial))
}
entry_metadata["actual_Rust_allocated_consumer"] = allocated_edges(rust, external="f03_syscall_entry_debug_v1")

# Exact two independently owned packed PID/count atomics, never broad substring matches.
entry_atomics = {}
for leaf in ("ENTRY_LOG_BUDGET", "RETURN_LOG_BUDGET"):
    module = "f03_syscall_entry_candidate"
    name = "_RNvNtNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy%d%s%d%s" % (len(module), module, len(leaf), leaf)
    pair = {}
    for label, elf in (("Rust", rust), ("partial", partial)):
        symbol = defined(elf, lambda value: value["name"] == name)
        section = elf.sections[symbol["shndx"]]
        assert symbol["bind"] == 0 and symbol["size"] == 8
        assert symbol["value"] % 8 == 0 and section["align"] >= 8
        assert section["type"] == 1 and section["flags"] & 3 == 3 and not section["flags"] & 4
        assert object_bytes(elf, symbol) == bytes.fromhex("00000000ffffffff")
        assert not owning_relocations(elf, symbol)
        assert elf.raw[elf.table["offset"] + symbol["index"] * elf.table["entsize"] + 5] == 0
        consumers = allocated_edges(elf, symbol=symbol)
        syscall_rows = [row for row in elf.symbols if row["name"] == "syscall" and row["bind"] == 1 and row["type"] == 2 and 0 < row["shndx"] < len(elf.sections)]
        assert len(syscall_rows) == 1
        syscall_owner = syscall_rows[0]
        instruction_edges = [edge for edge in consumers if edge["owner"] == syscall_owner["shndx"] and syscall_owner["value"] <= edge["offset"] < syscall_owner["value"] + syscall_owner["size"] and elf.sections[edge["owner"]]["flags"] & 4]
        assert instruction_edges, (leaf, "no allocated executable consumer")
        pair[label] = dict(symbol=symbol, section=section, initial_hex=object_bytes(elf, symbol).hex(), instruction_edges=instruction_edges)
    entry_atomics[leaf] = pair
assert entry_atomics["ENTRY_LOG_BUDGET"]["Rust"]["symbol"]["shndx"] != entry_atomics["RETURN_LOG_BUDGET"]["Rust"]["symbol"]["shndx"] or entry_atomics["ENTRY_LOG_BUDGET"]["Rust"]["symbol"]["value"] != entry_atomics["RETURN_LOG_BUDGET"]["Rust"]["symbol"]["value"]

entry_data_contract = json.loads((D / "ENTRY-ALLOCATED-DATA-AND-PROFILE-CONTRACT.json").read_bytes())
name_row = entry_data_contract["genuine_277_name_table_object"]
assert hashlib.sha256(Path(name_row["path"]).read_bytes()).hexdigest() == name_row["sha256"]
name_reference = Elf(Path(name_row["path"]))
reference_names = defined(name_reference, lambda row: row["name"] == "syscall_name")
assert reference_names["bind"] == 1 and reference_names["size"] == 4025 * 8
reference_name_slots = {(rela["offset"], rela["type"], cstring(name_reference, rela)) for rela in owning_relocations(name_reference, reference_names)}
entry_config = {}
for label, elf in (("selected_C", f03), ("partial", partial)):
    symbol = defined(elf, lambda row: row["name"] == "f03_syscall_entry_config_v1")
    section = elf.sections[symbol["shndx"]]
    assert symbol["bind"] == 1 and symbol["size"] == 80 and symbol["value"] % 8 == 0 and section["align"] >= 8
    assert section["flags"] & 2 and not section["flags"] & 4
    initial = object_bytes(elf, symbol)
    scalars = defined(elf, lambda row: row["name"] == "f03_entry_config_scalar_witness_v1")
    guards = defined(elf, lambda row: row["name"] == "f03_entry_config_guard_witness_v1")
    assert scalars["bind"] == guards["bind"] == 1 and scalars["size"] == 56 and guards["size"] == 32
    for witness_symbol in (scalars, guards):
        witness_section = elf.sections[witness_symbol["shndx"]]
        assert witness_section["flags"] & 2 and not witness_section["flags"] & 5
        assert not owning_relocations(elf, witness_symbol)
    assert initial[24:80] == object_bytes(elf, scalars)
    assert object_bytes(elf, guards) == struct.pack("<4Q", 1, 1, 0, 0)
    assert initial == bytes(8) + struct.pack("<Q", 4025) + bytes(8) + bytes.fromhex(entry_data_contract["scalar14_little_endian_hex"])
    relas = owning_relocations(elf, symbol)
    assert len(relas) == 2 and {rela["offset"] for rela in relas} == {0, 16}
    names = defined(elf, lambda row: row["name"] == "syscall_name")
    assert names["bind"] == 1 and names["size"] == 4025 * 8
    assert object_bytes(elf, names) == object_bytes(name_reference, reference_names)
    slots = {(rela["offset"], rela["type"], cstring(elf, rela)) for rela in owning_relocations(elf, names)}
    assert slots == reference_name_slots
    for rela in relas:
        assert rela["type"] == 1
        if rela["offset"] == 0:
            assert rela["target"]["shndx"] == names["shndx"]
            assert rela["target"]["value"] + rela["addend"] == names["value"]
            target = rela["target"]
            if target["name"] == "syscall_name":
                assert target["bind"] == 1 and target["type"] == 1 and rela["addend"] == 0
            else:
                assert target["bind"] == 0 and target["type"] == 3 and target["name"] == "" and target["value"] == 0 and target["size"] == 0
        else:
            assert rela["target"]["name"] == "process_fork_runtime_drain_current_v1" and rela["addend"] == 0
    entry_config[label] = dict(symbol=symbol, section=section, initial_hex=initial.hex(), relocations=relas, genuine_name_table=names, name_slots=sorted(slots))
assert "-DMCKERNEL_NATIVE_FORK_OWNED_TRANSACTION" in recipe["commands"][4]["argv"]
assert "-DDISABLE_SCHED_YIELD" not in recipe["commands"][4]["argv"]
assert "-DENABLE_FUGAKU_HACKS" not in recipe["commands"][4]["argv"]
entry_config["actual_Rust_allocated_consumer"] = allocated_edges(rust, external="f03_syscall_entry_config_v1")

# Explicit newdata-owner successor; original277/285 descriptor helpers remain unchanged.
data_owner_source = D / "observe_storage3_arch104_data.py"
data_owner_ns = {}
exec(compile(data_owner_source.read_bytes(), str(data_owner_source), "exec"), data_owner_ns)
arch_data_elf = Elf(O / "f06-arch-selected.o")
process_fallback_data_elf = Elf(O / "process.fallback.o")
arch_fallback_data_elf = Elf(O / "f06-arch-fallback.o")
arch_original_row = json.loads((D / "ARCH104-GENUINE-SELECTED-C-BASELINE.SOURCE-ONLY.json").read_bytes())["reference_object"]
assert hashlib.sha256(Path(arch_original_row["path"]).read_bytes()).hexdigest() == arch_original_row["sha256"]
arch_original_data_elf = Elf(Path(arch_original_row["path"]))
data5_storage_arch = data_owner_ns["observe_storage_arch"](
    rust, process, arch_data_elf, process_fallback_data_elf, arch_fallback_data_elf, arch_original_data_elf, partial,
    object_bytes, owning_relocations, allocated_edges,
)

CURRENT290_ADDITIVE_OBSERVER_BINDINGS = [{'path': '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1/exact-fullcrate-logger-GLOBAL1-retained12-source-1/observe_logger_fullcrate_GLOBAL1.py', 'sha256': 'a818f09c38be2d8ee0ca5828e36f57b5df4841a2206606590d73d9f5b6c026ac', 'bytes': 4235}, {'path': '/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-16-current289-observer-contribution/current290-successor-source-1/observe_ptrace19_current290.py', 'sha256': '5293029031352e68153158c4570743077a5d0cca6b49390969b32640acadeeae', 'bytes': 7954}]

# Current290 additive gates preserve every inherited285/data5 predicate above.
current290_abi = {}
for c_name, r_name, count, c_elf in (
    ('CURRENT289_LOGGER_C_ABI16', 'CURRENT289_LOGGER_RUST_ABI16', 16, arch_data_elf),
    ('CURRENT290_EXEC_C_ABI14', 'CURRENT290_EXEC_RUST_ABI14', 14, f03),
    ('CURRENT290_GETSIGINFO_C_ABI14', 'CURRENT290_GETSIGINFO_RUST_ABI14', 14, f03),
):
    expected = c_elf.data(c_name)
    assert len(expected) == count * 8
    assert rust.data(r_name) == partial.data(r_name) == expected
    current290_abi[c_name] = expected.hex()
for row in CURRENT290_ADDITIVE_OBSERVER_BINDINGS:
    payload = Path(row['path']).read_bytes()
    assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
logger_ns = {}
exec(compile(Path(CURRENT290_ADDITIVE_OBSERVER_BINDINGS[0]['path']).read_bytes(),
             CURRENT290_ADDITIVE_OBSERVER_BINDINGS[0]['path'], 'exec'), logger_ns)
logger_proof = logger_ns['observe_logger'](
    rust, partial, arch_data_elf, arch_fallback_data_elf, policy,
    descriptor, allocated_edges, object_bytes)
ptrace_ns = {}
exec(compile(Path(CURRENT290_ADDITIVE_OBSERVER_BINDINGS[1]['path']).read_bytes(),
             CURRENT290_ADDITIVE_OBSERVER_BINDINGS[1]['path'], 'exec'), ptrace_ns)
ptrace19_proof = ptrace_ns['verify_ptrace19'](
    rust, f03, partial, Elf(O / 'F03.fallback.o'), str(D / 'source/kernel/syscall.c'),
    object_bytes, owning_relocations, cstring)
# Exact public entry instruction edges to the existing exec provider. Genuine
# C signature assertions and ABI14 are compiled in this same source profile.
exec_provider_edges = allocated_edges(rust, external='syscall_execveat_bridge')
exec_instruction_proof = {}
for name in ('sys_execve', 'sys_execveat'):
    symbols = [row for row in rust.symbols if row['name'] == name]
    assert len(symbols) == 1 and symbols[0]['bind'] == 1 and symbols[0]['type'] == 2
    owner = symbols[0]
    edges = [edge for edge in exec_provider_edges
             if edge['owner'] == owner['shndx']
             and owner['value'] <= edge['offset'] < owner['value'] + owner['size']
             and rust.sections[edge['owner']]['flags'] & 4]
    assert edges, (name, 'missing existing exec C provider instruction edge')
    exec_instruction_proof[name] = edges

result = dict(current290_ABI=current290_abi, logger13=logger_proof,ptrace19=ptrace19_proof,exec_instruction_proof=exec_instruction_proof, owned_handler_table=table_union_proof, data5_storage_arch=data5_storage_arch,post285_process_C_data_debt=post285_process_data, entry_metadata=entry_metadata, entry_config=entry_config, entry_AtomicU64=entry_atomics, post230_C_data_debt=post230_data, selected_AtomicU32=counter_proof, SMP_metadata=smp_metadata, new_process=new_process,free_range_records=free_records,free_range_edges=free_record_edges,new_readonly=new_readonly,new_arch=new_arch,dispatch=dispatch_proof,dispatch_edges=dispatch_edges,tracked_free_line=tracked_free_line, tracked_free_line_edges=tracked_free_line_edges, process36=process36_metadata, process36_edges=process36_edges, signal_process=signal_metadata, signal_process_edges=signal_edges, ptrace_log=ptrace_metadata, ptrace_edges=ptrace_edges, status="PASS_CURRENT290_PLUS_FIVE_ALLOCATED_DATA_OWNERS_ONLY", source10=process_proof, source10_allocated_edges=process_edges, F06=arch_proof, scheduler=scheduler_proof, scheduler_edges=scheduler_edges, historical_23_anonymous_edges="OPEN", SDK=False, native=False, production_default=False)
with (Path(__file__).parent / "ACTUAL-NEW-METADATA-RELA.EXACT-SYMBOLS.json").open("x") as out:
    json.dump(result, out, sort_keys=True, indent=2)
    out.write("\n")
print(json.dumps(dict(status=result["status"], source10_descriptors=1, F06_descriptors=2)))
