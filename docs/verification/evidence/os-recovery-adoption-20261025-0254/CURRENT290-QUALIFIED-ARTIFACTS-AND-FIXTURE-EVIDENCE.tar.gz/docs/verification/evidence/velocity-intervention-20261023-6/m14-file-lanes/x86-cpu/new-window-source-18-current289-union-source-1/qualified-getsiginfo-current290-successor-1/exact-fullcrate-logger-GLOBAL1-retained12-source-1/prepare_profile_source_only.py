# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
from pathlib import Path
import ast,hashlib,json
R=Path('/home/holden/mckernel');D=R/'docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1';Q=D/'exact-fullcrate-logger-GLOBAL1-retained12-source-1';old=D/'observe_logger_allocated_data.SOURCE-ONLY.py'
def pin(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
r=json.loads((Q/'TINY-EXACT-FOUR-LOGGER-GLOBAL1-CENSUS.ACTUAL-RETAINED.json').read_text());names={x['leaf']:x['exact_name'] for x in r['inventory']['Rust']};assert len(names)==4
s=old.read_text();start=s.index('        # v0 root module symbol:');end=s.index('        records = {}',start);s=s[:start]+'        exact_name = EXACT_FULLCRATE_DESCRIPTORS[name]\n'+s[end:];s=s.replace('if re.fullmatch(pattern, row[\'name\'])','if row[\'name\'] == exact_name').replace("assert symbol['bind'] == 0 and symbol['type'] == 1", "assert symbol['bind'] == 1 and symbol['type'] == 1")
anchor="            records[label] = descriptor(elf, symbol, str(policy), function, expected[0])";insert="""            section = elf.sections[symbol['shndx']]
            assert section['type'] == 1 and section['name'] == '__verbose'
            assert section['flags'] == (0x200003 if label == 'Rust' else 3)
            assert section['align'] == 8
            assert symbol['size'] == 32 and symbol['value'] % 8 == 0
            assert 0 <= symbol['value'] <= section['size'] - 32
""";assert anchor in s;s=s.replace(anchor,insert+anchor);s=s.replace('import re\n','EXACT_FULLCRATE_DESCRIPTORS = '+repr(names)+'\n');ast.parse(s);p=Q/'observe_logger_fullcrate_GLOBAL1.py';p.write_text(s)
profile={'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','status':'EXACT_SOURCE_ONLY_WHOLECRATE_PROFILE_NOT_RETAINED_OBSERVER_PASS','helper':pin(p),'old_leaf_assumption_helper':pin(old),'actual_exact_census':pin(Q/'TINY-EXACT-FOUR-LOGGER-GLOBAL1-CENSUS.ACTUAL-RETAINED.json'),'exact_names':names,'required_binding':1,'required_type':1,'required_raw_st_other':0,'required_record_bytes':32,'required_alignment':8,'Rust_section_flags':2097155,'partial_section_flags':3,'section_name':'__verbose','section_type':1,'old_leaf_LOCAL0_contract':'retained unchanged; not a claim that LOCAL0 is impossible in staticlib fixture','unchanged_gates':['all285/data5/F0466','full32B initializer and exactfile/func/line','two exactR64 owningpointerRELAs','real callback instructionconsumer and normaldefinedsymbol extent','zero selected/legacy Clogger definition','realABI16 byte equality','postlogger ptrace19 andexec checks must reach']}
p=Q/'EXACT-WHOLECRATE-GLOBAL1-PROFILE.SOURCE-ONLY.json';p.write_text(json.dumps(profile,indent=2,sort_keys=True)+'\n');(Q/'prepare_profile_source_only.py').write_bytes(Path(__file__).read_bytes());print(pin(Q/'observe_logger_fullcrate_GLOBAL1.py'));print(pin(p))
