"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bounded in-memory controls for the actual new logger profile helper, not OS/ELF acceptance.
"""
from pathlib import Path
import ast
import copy
import hashlib
import json
import struct

N = Path(__file__).resolve().parent
D = N.parent
source = N / 'observe_logger_fullcrate_GLOBAL1.py'
ns = {}
exec(compile(source.read_bytes(), str(source), 'exec'), ns)
verify = ns['observe_logger']
NAMES = tuple(ns['EXACT_FULLCRATE_DESCRIPTORS'])
EXACT = ns['EXACT_FULLCRATE_DESCRIPTORS']
FN = 'arch_process_vm_rw_log_bridge'
metadata = D / 'complete-genuine-ABI14-witness-suffix07-source-1/observe_new_metadata.py'
tree = ast.parse(metadata.read_bytes())
helpers = [node for node in tree.body if isinstance(node, ast.FunctionDef)
           and node.name in {'cstring', 'descriptor'}]

def object_bytes(elf, symbol):
    payload = elf.payload(elf.sections[symbol['shndx']])
    return bytes(payload[symbol['value']:symbol['value'] + symbol['size']])

def owning_relocations(elf, symbol):
    return elf.relocations[symbol['name']]

def allocated_edges(elf, symbol=None, external=None):
    assert external is None and symbol is not None
    result = []
    for edge in elf.consumers[symbol['name']]:
        target = edge['target']
        if (target['shndx'] == symbol['shndx']
                and symbol['value'] <= target['value'] + edge['addend']
                < symbol['value'] + symbol['size']):
            result.append(edge)
    return result

h = dict(object_bytes=object_bytes, owning_relocations=owning_relocations)
exec(compile(ast.Module(body=helpers, type_ignores=[]), str(metadata), 'exec'), h)

class ElfModel:
    def payload(self, section):
        return self.payloads[section['index']]

    def data(self, name):
        return self.abi[name]

root = N / 'pure-profile-output-1'
root.mkdir(mode=0o700)
policy = root / 'model_policy.rs'
policy.write_text(''.join('static mut '+name+': Stub = Stub {\n    line_flags: line!(),\n};\n' + '\n'*5
                          for name in NAMES))
filename = str(policy)
strings = (filename.encode() + b'\0' + FN.encode() + b'\0'
           + b'/changed/path.rs\0wrong_function\0')
function_at = len(filename.encode()) + 1
wrong_file_at = function_at + len(FN) + 1
wrong_function_at = wrong_file_at + len('/changed/path.rs') + 1
ABI = struct.pack('<16Q', *range(16))

def make(label):
    elf = ElfModel()
    elf.sections = [dict(index=i, type=0, flags=0, align=1, name='', size=0)
                    for i in range(7)]
    elf.payloads = {}
    elf.symbols = []
    elf.raw = bytearray(512)
    elf.table = dict(offset=0, entsize=24)
    elf.relocations = {}
    elf.consumers = {}
    for i, name in enumerate(NAMES):
        section_index = i+1 if label == 'Rust' else 1
        value = 0 if label == 'Rust' else i*32
        elf.sections[section_index] = dict(index=section_index, type=1,
            flags=0x200003 if label == 'Rust' else 3, align=8,
            name='__verbose', size=32 if label == 'Rust' else 128)
        elf.payloads.setdefault(section_index, bytearray(32 if label == 'Rust' else 128))
        elf.payloads[section_index][value:value+32] = bytes(24) + struct.pack('<I', i*8+2) + bytes(4)
        symbol = dict(name=EXACT[name], index=i+1, bind=1, type=1,
                      shndx=section_index, value=value, size=32)
        elf.symbols.append(symbol)
        target = dict(name='', index=10, bind=0, type=3, shndx=6, value=0, size=0)
        elf.relocations[symbol['name']] = [
            dict(offset=0, type=1, target=copy.deepcopy(target), addend=0),
            dict(offset=8, type=1, target=copy.deepcopy(target), addend=function_at)]
        elf.consumers[symbol['name']] = [dict(owner=5, offset=i*8+8,
            relocation_type=1, target=copy.deepcopy(symbol), addend=24)]
    elf.sections[5] = dict(index=5, type=1, flags=6, align=16, name='.text', size=128)
    elf.sections[6] = dict(index=6, type=1, flags=2, align=1, name='.rodata', size=len(strings))
    elf.payloads[6] = strings
    elf.symbols.append(dict(name=FN, index=5, bind=1, type=2, shndx=5, value=0, size=96))
    elf.abi = {'CURRENT289_LOGGER_RUST_ABI16': ABI}
    return elf

def reference():
    elf = ElfModel()
    elf.symbols = []
    elf.sections = [{}, {}]
    elf.abi = {'CURRENT289_LOGGER_C_ABI16': ABI}
    return elf

def fixture():
    return dict(rust=make('Rust'), partial=make('partial'),
                selected=reference(), legacy=reference())

def run(f):
    return verify(f['rust'], f['partial'], f['selected'], f['legacy'], policy,
                  h['descriptor'], allocated_edges, object_bytes)

def symbol(f, label='rust'):
    return f[label].symbols[0]

def relas(f):
    return f['rust'].relocations[EXACT[NAMES[0]]]

def byte(f, offset, value):
    row = symbol(f)
    f['rust'].payloads[row['shndx']][row['value']+offset] = value

positives = []
f = fixture()
run(f)
positives.append('four_exact_GLOBAL1_records_both_objects')
f = fixture()
for elf in (f['rust'], f['partial']):
    for name in NAMES:
        elf.consumers[EXACT[name]][0]['offset'] += 16
    elf.symbols[-1]['value'] = 16
run(f)
positives.append('translated_function_extents_exact_flags_field_consumers')

cases = [
    ('LOCAL_binding', lambda f: symbol(f).__setitem__('bind', 0)),
    ('UND', lambda f: symbol(f).__setitem__('shndx', 0)),
    ('FUNC', lambda f: symbol(f).__setitem__('type', 2)),
    ('COMMON_reserved', lambda f: symbol(f).__setitem__('shndx', 0xfff2)),
    ('hidden_visibility', lambda f: f['rust'].raw.__setitem__(29, 2)),
    ('wrong_size', lambda f: symbol(f).__setitem__('size', 31)),
    ('wrong_alignment', lambda f: f['rust'].sections[1].__setitem__('align', 4)),
    ('missing_GNUretain_Rust', lambda f: f['rust'].sections[1].__setitem__('flags', 3)),
    ('extra_EXEC_Rust', lambda f: f['rust'].sections[1].__setitem__('flags', 0x200007)),
    ('wrong_partial_flags', lambda f: f['partial'].sections[1].__setitem__('flags', 0x200003)),
    ('wrong_section_name', lambda f: f['rust'].sections[1].__setitem__('name', '.data')),
    ('NOBITS', lambda f: f['rust'].sections[1].__setitem__('type', 8)),
    ('outside_section_extent', lambda f: symbol(f).__setitem__('value', 32)),
    ('duplicate_exact_name', lambda f: f['rust'].symbols.append(copy.deepcopy(symbol(f)))),
    ('missing_exact_name', lambda f: symbol(f).__setitem__('name', 'missing')),
    ('unrelated_same_leaf', lambda f: symbol(f).__setitem__('name', '_RNvNtCsbVRkTr4hvpt_13mckernel_rust12other_module30'+NAMES[0])),
    ('wrong_leaf', lambda f: symbol(f).__setitem__('name', EXACT[NAMES[0]][:-1]+'X')),
    ('suffix_duplicate_spelling', lambda f: symbol(f).__setitem__('name', EXACT[NAMES[0]]+'_duplicate')),
    ('nonnull_fmt', lambda f: byte(f, 16, 1)),
    ('wrong_line', lambda f: byte(f, 24, 77)),
    ('wrong_padding', lambda f: byte(f, 28, 1)),
    ('missing_RELA', lambda f: relas(f).pop()),
    ('wrong_RELA_offset', lambda f: relas(f)[1].__setitem__('offset', 16)),
    ('wrong_RELA_type', lambda f: relas(f)[0].__setitem__('type', 2)),
    ('undefined_RELA_target', lambda f: relas(f)[0]['target'].__setitem__('shndx', 0)),
    ('changed_filename_bytes', lambda f: relas(f)[0].__setitem__('addend', wrong_file_at)),
    ('changed_function_bytes', lambda f: relas(f)[1].__setitem__('addend', wrong_function_at)),
    ('missing_real_consumer', lambda f: f['rust'].consumers[EXACT[NAMES[0]]].clear()),
    ('consumer_other_function', lambda f: f['rust'].consumers[EXACT[NAMES[0]]][0].__setitem__('offset', 120)),
    ('consumer_nonEXEC', lambda f: f['rust'].sections[5].__setitem__('flags', 2)),
    ('consumer_wrong_target', lambda f: f['rust'].consumers[EXACT[NAMES[0]]][0]['target'].__setitem__('value', 999)),
    ('consumer_wrong_field', lambda f: f['rust'].consumers[EXACT[NAMES[0]]][0].__setitem__('addend', 0)),
    ('consumer_wrong_RELA_type', lambda f: f['rust'].consumers[EXACT[NAMES[0]]][0].__setitem__('relocation_type', 2)),
    ('consumer_wrong_named_target', lambda f: f['rust'].consumers[EXACT[NAMES[0]]][0]['target'].__setitem__('name', 'unrelated')),
    ('duplicate_consumer_RELA', lambda f: f['rust'].consumers[EXACT[NAMES[0]]].append(copy.deepcopy(f['rust'].consumers[EXACT[NAMES[0]]][0]))),
    ('selected_C_definition', lambda f: f['selected'].symbols.append(dict(name=FN, shndx=1))),
    ('legacy_C_definition', lambda f: f['legacy'].symbols.append(dict(name=FN, shndx=1))),
    ('ABI16_mismatch', lambda f: f['rust'].abi.__setitem__('CURRENT289_LOGGER_RUST_ABI16', bytes(128))),
]
negatives = []
for name, mutate in cases:
    f = fixture()
    mutate(f)
    try:
        run(f)
    except AssertionError:
        negatives.append(name)
    else:
        raise AssertionError(('negative unexpectedly accepted', name))
assert len(positives) == 2 and len(negatives) == 38
out = dict(scope=__doc__.splitlines()[0], status='PASS_BOUNDED_OBSERVER_MODEL_CONTROLS_ONLY',
           positives=positives, negatives=negatives, positive_count=2, negative_count=38,
           actual_helper_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
           helper_path=str(source), no_actual_ELF_read=True, no_compiler=True,
           OS_runtime_or_artifact_acceptance=False)
with (N/'ACTUAL-PURE-LOGGER-GLOBAL1-PROFILE-CONTROLS.json').open('x') as f:
    json.dump(out, f, indent=2, sort_keys=True)
    f.write('\n')
print(json.dumps(dict(status=out['status'], positives=2, negatives=38)))
