# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
from pathlib import Path
import ast, copy, datetime, hashlib, json, re, stat
R=Path('/home/holden/mckernel')
D=R/'docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/x86-cpu/new-window-source-18-current289-union-source-1/qualified-getsiginfo-current290-successor-1'
P=D/'exact-fullcrate-logger-GLOBAL1-retained12-source-1'
Q=D/'logger-GLOBAL1-fixture-spacing-retained12-successor-source-1'
assert not Q.exists()
Q.mkdir(mode=0o700)
def pin(p):
 raw=p.read_bytes(); return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def emit(name,x):
 (Q/name).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n'); return pin(Q/name)
def ident(p):
 t=p.stat();assert stat.S_ISREG(t.st_mode)
 return {k:getattr(t,k) for k in ['st_ctime_ns','st_dev','st_gid','st_ino','st_mode','st_mtime_ns','st_nlink','st_size','st_uid']}
def functions(s):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
helper=Q/'observe_logger_fullcrate_GLOBAL1.py'
helper.write_bytes((P/helper.name).read_bytes())
pure=(P/'pure_logger_GLOBAL1_profile.py').read_text()
a="'static mut '+name+': Stub = Stub {\\n    line_flags: line!(),\\n};\\n'"
assert pure.count(a)==1 and pure.count("struct.pack('<I', i*3+2)")==1
pure=pure.replace(a,a+" + '\\n'*5").replace("struct.pack('<I', i*3+2)","struct.pack('<I', i*8+2)")
ast.parse(pure);(Q/'pure_logger_GLOBAL1_profile.py').write_text(pure)
metadata=(P/'observe_new_metadata.py').read_text()
assert metadata.count(repr(pin(P/helper.name)))==1
metadata=metadata.replace(repr(pin(P/helper.name)),repr(pin(helper)))
assert functions(metadata)==functions((P/'observe_new_metadata.py').read_text())
(Q/'observe_new_metadata.py').write_text(metadata)
profile_source=json.loads((P/'EXACT-WHOLECRATE-GLOBAL1-PROFILE.SOURCE-ONLY.json').read_text())
profile_source['helper']=pin(helper)
emit('EXACT-WHOLECRATE-GLOBAL1-PROFILE.SOURCE-ONLY.json',profile_source)
recipe=json.loads((P/'EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json').read_text())
recipe['original_consumed_pure_failure']=pin(P/'actual-pure-and-retained12-attempt-1/FAILURE.STOP.json')
recipe['profile_source']=pin(Q/'EXACT-WHOLECRATE-GLOBAL1-PROFILE.SOURCE-ONLY.json')
for command in recipe['commands']:
 command['argv']=[v.replace(str(P),str(Q)) for v in command['argv']]
 assert command['cwd']==str(D)
emit('EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json',recipe)
# Original frozen authority remains intact; successors extend its fixed-read set.
authority=json.loads((P/'EXACT-FIXED-INPUT-FD-AUTHORITY.json').read_text())
inputs={row['path']:row for row in authority['rows']}
for row in authority['rows']:
 assert ident(Path(row['path']))==row['fresh_readonly_FD_identity'],row['path']
def add(p):
 before=ident(p);x=pin(p);assert ident(p)==before
 inputs[str(p)]=dict(path=str(p),sha256=x['sha256'],bytes=x['bytes'],expected_size=x['bytes'],maximum=x['bytes']+4096,fresh_readonly_FD_identity=before)
for p in Q.iterdir():
 if p.is_file():add(p)
for name in ['actual-pure-and-retained12-attempt-1/FAILURE.STOP.json','actual-pure-and-retained12-attempt-1/00/stderr','actual-pure-and-retained12-attempt-1/00/WHOLE-JOIN.json']:
 add(P/name)
authority['rows']=sorted(inputs.values(),key=lambda row:row['path']);authority['count']=len(inputs)
emit('EXACT-FIXED-INPUT-FD-AUTHORITY.json',authority)
driver=(P/'run_pure_and_retained_logger12_once.NOT-GRANTED.py').read_text()
for field,name in [('F_SHA','EXACT-FIXED-INPUT-FD-AUTHORITY.json'),('R_SHA','EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json')]:
 driver=re.sub(r'^'+field+r" = '[0-9a-f]+'",field+' = '+repr(pin(Q/name)['sha256']),driver,flags=re.M)
assert functions(driver)==functions((P/'run_pure_and_retained_logger12_once.NOT-GRANTED.py').read_text())
assert str(P) not in driver
(Q/'run_pure_and_retained_logger12_once.NOT-GRANTED.py').write_text(driver)
ready=json.loads((P/'EXECUTABLE-READY.NOT-GRANTED.json').read_text())
for key,name in [('driver','run_pure_and_retained_logger12_once.NOT-GRANTED.py'),('recipe','EXACT-PURE-AND-RETAINED12-SUFFIX.NOT-GRANTED.json'),('fixed_FD_authority','EXACT-FIXED-INPUT-FD-AUTHORITY.json'),('source_profile_helper','observe_logger_fullcrate_GLOBAL1.py')]:
 ready[key]=pin(Q/name)
ready['argv']=[v.replace(str(P),str(Q)) for v in ready['argv']]
ready['observed_ready_UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
ready['original_consumed_pure_failure']=recipe['original_consumed_pure_failure']
ready['fixture_only_correction']='8-line synthetic declaration blocks and exact i*8+2 descriptor line values; observer unchanged.'
ready['exclusive_outputs']=[str(Q/name) for name in ['output-1','actual-pure-and-retained12-attempt-1','pure-profile-output-1','ACTUAL-PURE-LOGGER-GLOBAL1-PROFILE-CONTROLS.json','ACTUAL-NEW-METADATA-RELA.EXACT-SYMBOLS.json']]
ready['original_observer_byte_identical']=True
ready['source_only_syntax_and_AST_checks_passed']=True
ready['no_execution_grant']=True
ready_pin=emit('EXECUTABLE-READY.NOT-GRANTED.json',ready)
grant_required=dict(scope=ready['scope'],status='REQUIRED_SCHEMA_ONLY_NOT_A_GRANT',target_file=str(Q/'ROOT-GRANT.json'),required_fields=dict(scope=ready['scope'],CPU=6,ordinary_jobs=1,ready_sha256=ready_pin['sha256']),recommended_bindings=dict(argv=ready['argv'],uid=1000,jobs=1,harness='h990',slot='CPU6',AS_bytes=2147483648,CPU_seconds=60,FD=256,F_bytes=33554432,core=0,stack_bytes=2097152,wall_seconds=90,retirement_margin_seconds=6,source_review_sha256='FRESH_INDEPENDENT_REVIEW_REQUIRED'),constraints='Fresh one-shot ordinary CPU6 grant only; new source/ready binding, exclusive absent outputs, current resource floors. No compiler/link/native or consumed grant replay.')
emit('ROOT-GRANT-REQUIRED.SCHEMA-ONLY.NOT-A-GRANT.json',grant_required)
(Q/'prepare_spacing_successor_source_only.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(ready=ready_pin,argv=ready['argv'],profile=ready['profile'],authority_count=authority['count'],driver=ready['driver'],recipe=ready['recipe'],grant_schema=pin(Q/'ROOT-GRANT-REQUIRED.SCHEMA-ONLY.NOT-A-GRANT.json'),execution=False)))
