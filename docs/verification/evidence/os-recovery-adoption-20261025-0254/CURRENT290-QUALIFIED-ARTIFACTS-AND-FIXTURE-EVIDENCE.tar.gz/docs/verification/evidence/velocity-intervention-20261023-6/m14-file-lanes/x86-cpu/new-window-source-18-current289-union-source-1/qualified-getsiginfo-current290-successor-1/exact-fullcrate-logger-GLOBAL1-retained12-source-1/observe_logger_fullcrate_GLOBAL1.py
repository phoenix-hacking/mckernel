"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Additive wholecrate logger record ownership; no standalone symbol indices reused.
"""
EXACT_FULLCRATE_DESCRIPTORS = {'F06_PROCESS_VM_IOV_LOCAL_DEBUG': '_RNvNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy30F06_PROCESS_VM_IOV_LOCAL_DEBUG', 'F06_PROCESS_VM_IOV_REMOTE_DEBUG': '_RNvNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy31F06_PROCESS_VM_IOV_REMOTE_DEBUG', 'F06_PROCESS_VM_FOUND_DEBUG': '_RNvNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy26F06_PROCESS_VM_FOUND_DEBUG', 'F06_PROCESS_VM_COPY_DEBUG': '_RNvNtCsbVRkTr4hvpt_13mckernel_rust14syscall_policy25F06_PROCESS_VM_COPY_DEBUG'}

def observe_logger(rust, partial, selected_arch, legacy_arch, policy, descriptor,
                   allocated_edges, object_bytes):
    function = 'arch_process_vm_rw_log_bridge'
    names = ('F06_PROCESS_VM_IOV_LOCAL_DEBUG', 'F06_PROCESS_VM_IOV_REMOTE_DEBUG',
             'F06_PROCESS_VM_FOUND_DEBUG', 'F06_PROCESS_VM_COPY_DEBUG')
    lines = policy.read_text().splitlines()
    result = {}
    for name in names:
        declaration = [i for i, line in enumerate(lines) if 'static mut '+name+':' in line]
        assert len(declaration) == 1, (name, declaration)
        start = declaration[0]
        expected = [i+1 for i in range(start, start+8) if 'line_flags: line!()' in lines[i]]
        assert len(expected) == 1, (name, expected)
        exact_name = EXACT_FULLCRATE_DESCRIPTORS[name]
        records = {}
        for label, elf in (('Rust', rust), ('partial', partial)):
            rows = [row for row in elf.symbols if row['name'] == exact_name]
            assert len(rows) == 1, (label, name, rows)
            symbol = rows[0]
            assert symbol['bind'] == 1 and symbol['type'] == 1, symbol
            assert 0 < symbol['shndx'] < len(elf.sections), symbol
            assert elf.raw[elf.table['offset']+symbol['index']*elf.table['entsize']+5] == 0
            section = elf.sections[symbol['shndx']]
            assert section['type'] == 1 and section['name'] == '__verbose'
            assert section['flags'] == (0x200003 if label == 'Rust' else 3)
            assert section['align'] == 8
            assert symbol['size'] == 32 and symbol['value'] % 8 == 0
            assert 0 <= symbol['value'] <= section['size'] - 32
            records[label] = descriptor(elf, symbol, str(policy), function, expected[0])
            owners = [row for row in elf.symbols if row['name'] == function]
            assert len(owners) == 1, owners
            owner = owners[0]
            assert owner['bind'] == 1 and owner['type'] == 2
            assert 0 < owner['shndx'] < len(elf.sections) and owner['size'] > 0
            edges = [edge for edge in allocated_edges(elf, symbol=symbol)
                     if edge['owner'] == owner['shndx']
                     and owner['value'] <= edge['offset'] < owner['value']+owner['size']
                     and elf.sections[edge['owner']]['flags'] & 4]
            assert edges, (label, name, 'missing actual callback instruction consumer')
            assert len(edges) == 1, (label, name, edges)
            edge = edges[0]
            assert edge['relocation_type'] == 1 and edge['addend'] == 24
            assert edge['target']['name'] == symbol['name']
            assert edge['target']['bind'] == 1 and edge['target']['type'] == 1
            records[label]['actual_function_instruction_edges'] = edges
        assert records['Rust']['initial_hex'] == records['partial']['initial_hex']
        result[name] = records
    # The full legacy reference has POLICY OFF; its surrounding selected-only
    # process-VM block is inactive. Focused original-C fixture remains separate.
    for label, elf in (('selected_C', selected_arch), ('legacy_C', legacy_arch)):
        assert not [row for row in elf.symbols if row['name'] == function
                    and 0 < row['shndx'] < len(elf.sections)], label
    expected = selected_arch.data('CURRENT289_LOGGER_C_ABI16')
    assert len(expected) == 16*8
    assert rust.data('CURRENT289_LOGGER_RUST_ABI16') == expected
    assert partial.data('CURRENT289_LOGGER_RUST_ABI16') == expected
    result['ABI16_hex'] = expected.hex()
    return result
