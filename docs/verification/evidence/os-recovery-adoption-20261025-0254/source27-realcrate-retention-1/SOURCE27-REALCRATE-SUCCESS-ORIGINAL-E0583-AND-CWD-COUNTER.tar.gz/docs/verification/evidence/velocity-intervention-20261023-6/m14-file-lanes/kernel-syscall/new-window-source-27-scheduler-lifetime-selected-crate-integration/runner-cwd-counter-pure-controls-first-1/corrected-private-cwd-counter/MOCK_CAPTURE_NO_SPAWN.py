import os
import json
from pathlib import Path
FIELDS=()
stopping=False
CENSUS_SOURCE='MOCK_ONLY_NO_CENSUS'
CENSUS_SHA='MOCK_ONLY'
_CENSUS=None
STOP_SIGNALS=()
def need(*args): return None
def write(*args): return None
def hashed(*args): return None
def stop(*args): return None
def cpu_used(): return 0.001
def members(*args): return []
def process_start(*args): return 0
def terminal_unreaped(*args): return False
def wait_terminal(*args): return None
def owned_capture(command, capture, wall_remaining, limits):
    observed = dict(actual_cwd=os.getcwd(), declared_cwd=command['cwd'],
        mock_only=True, Popen_called=False, Rust_compilers_started=0)
    (capture/'mock-cwd-observation.json').write_text(json.dumps(observed))
    if os.getcwd()!=command['cwd']:
        raise RuntimeError('MOCK_CWD_MISMATCH actual='+os.getcwd()+' declared='+command['cwd'])
    limits()
    Path(command['mock_output']).write_bytes(b'MOCK_ONLY_NOT_A_RUST_OBJECT')
    (capture/'stdout').write_text('')
    (capture/'stderr').write_text('')
    return dict(returncode=0,direct_child_joined=True,group_absent=True,
        closed_streams=True,error=None,retirement_error=None,timed_out=False,
        mock_only=True,Rust_compilers_started=0)
