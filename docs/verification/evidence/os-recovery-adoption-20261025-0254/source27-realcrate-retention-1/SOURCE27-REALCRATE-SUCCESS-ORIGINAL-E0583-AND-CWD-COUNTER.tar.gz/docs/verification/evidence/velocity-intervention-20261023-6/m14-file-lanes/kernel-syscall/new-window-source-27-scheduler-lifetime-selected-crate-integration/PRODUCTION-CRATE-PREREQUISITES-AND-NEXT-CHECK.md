Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Latest runner correction: independent review blocked the original launch because
the runner changed cwd to the repository and reported fullcrate_compilations=0.
Original source/tuple is retained. Successor runner e4cfaef0 changes only those
two statements: cwd now follows the exact private command cwd, and successful
single full-crate compilation reports1. READY64505b3a and unchanged recipe
cd139714 await focused review and ROOT's actual compiler grant. Pure AST plus
three actual-main mock controls PASS (proof62f2b0c3): original cwd/counter defects
are observed, corrected inherited cwd is private and reported counter is1.
Those are mocks with zero Rust compiler/Popen calls inside them, not a compiler
or production acceptance. CPU0 released; actual production output remains absent.

Source27 is an independent source composition of the real kernel Rust crate,
not a reduced fixture parent. No compiler has run. Canonical files, current290's
immutable source/object/compiler/image prefixes and Source26's retained-object
fixture composition are untouched. All four new cfgs are private candidate
choices; global build defaults and CMake selection remain unchanged.

The frozen compiler manifest binds every exact candidate file. The original
SELECTED-CRATE-COMPOSITION.DEFAULT-OFF.patch concentrates on runtime selection
and the modified syscall_policy copy. The additive complete diff,
COMPLETE-STATIC-CANDIDATE-WITH-RETAINED-ABI.patch, additionally contains the
retained lib/page_helpers/x86_cpu_helpers ABI suffixes. COMPLETE-DIFF-SCOPE.json
records that distinction. No source, recipe, runner or READY hash changed.

The candidate has88 bound files/5,075,812B, including the actual canonical
kernel/rust/lib.rs and its77 declared root modules. The three real outside-crate
paths (sysfs fixture, native vDSO ABI and zero-pages protocol) are copied at their
original relative locations. No public API, production parent types, callback
stubs, fake Thread or alternate scalar implementation substitutes for the real
crate. Inactive cfg modules are bound but are not claimed compiler-executed.

Retained current290 object e5170c9d supplies the exact actual nightly1.95 compiler,
cmake environment/codegen cfg prefix and genuine generated ABI appendices. Its
root differs from normalized canonical lib.rs only by ABI witness suffixes and
absolute module paths. Its page_helpers/syscall_policy/x86_cpu_helpers sources
are canonical prefixes plus ABI suffixes. Source27 preserves all38,654 appendix
bytes without changing values or weakening guards. The current canonical abi.rs
and real runtime sources are retained, with changed scheduler/lookup composition
only. No historical object is rebuilt unchanged or requalified by assertion.

The retained sysfs_verify absolute source path is missing, while that cfg is OFF
in the e517 command. Source27 copies the real current canonical sysfs fixture
at its genuine relative path anyway, and records the missing inactive historical
path explicitly. It neither restores/mutates old namespaces nor silently declares
that missing historical file a current runtime input.

Actual source composition

| Source | Real selected path in candidate | Exact scope |
| --- | --- | --- |
| Source22 | Public process_helpers::find_thread delegates to versioned positive-reference helper under its cfg. | Same pointer/NULL public ABI; explicit int one/zero acquisition callback; actual AtomicI32 count and original warning/hash reader. Old void helper remains unchanged. |
| Source23 | sys_sched_getparam and sys_sched_getscheduler bind retained-v2 helpers under their cfg. | Same genuine argument extraction, offsets, current-thread and usercopy providers. Both reviewed function bodies are byte-identical. |
| Source24 | sched_setparam_body_result delegates under its cfg. | Same helper ABI, one original allocation through owner check/copy/apply; reviewed function body byte-identical. Existing setscheduler is unchanged. |
| Source25 | sys_sched_rr_get_interval binds retained-v2 helper under its cfg. | Same zero-output-address precedence, TimeSpec, provider ABI and interval helper; reviewed function body byte-identical. |
| Shared guard | One sched_helpers::sched_retained_target module. | Literal Source23 guard/selector algorithm; only pub(super) visibility on type/fields/selector enables sibling reuse. Source24 copy was exact; Source25 differs only by one trailing LF. Three copies are replaced by imports of this one implementation. |

The four scheduler bodies have exact body hashes in the static manifest. Guard
factoring is not presented as byte-identical source: its visibility/import edits
are explicit and its algorithm is verified by stripping only pub(super) back to
the original Source23 span. Type fields, reference operations and callback ABI
are unchanged. C change is only Source22's declarations/static type checks in
private kernel/process.c; there is no new C runtime algorithm or C compilation.

Genuine compiler prefix

The original retained producer command is bound by path and hash in the recipe.
It uses /usr/bin/cmake -E env, the same nightly-2026-02-18 rustc executable and
the exact retained version/build-ID/SSE/CPU-origin environment. Existing full-kernel
cfgs, optimization/debug/target/no-redzone/codegen-units1 flags are preserved.
The retained build tag remains a base tag, not a claim that Source27 is that old
commit. Source27 source/object provenance uses its separate immutable manifest.

Intentional command delta is limited to the actual private crate-root argument,
private object output, private cwd (so even a compiler crash file stays private),
and four new cfgs: f02_positive_reference_lookup_candidate,
f03_scheduler_query_lifetime_v2, f03_sched_setparam_lifetime_candidate,
f03_rr_interval_lifetime_v2. No pending-state or destructor-selection guard is
removed or bypassed. Source21's unresolved pending-lifecycle path is not selected.

The retained record pinned the same rustc and cmake executable bytes. Source27
also freshly binds57 target metadata/library files/494,377,257B, including the
actual compiler driver/target core closure. This is a fresh binding, not a claim
that the historical e517 record had that additional closure. Toolchain/library
files are read only; no installation, fallback toolchain or settings change occurs.

Actual production prerequisites remain

1. Native selected kernel must genuinely resolve public find_thread to this
   Rust candidate, with original supporting profile flags. An inactive legacy C
   lookup still using a void hold callback is not silently declared repaired.
2. Existing hash reader/writer must protect the same published lists. Final
   release decrements the actual Thread count, and physical destruction first
   detaches under the corresponding hash writer before process/sigcommon edges
   and Thread pages are released. Published process PID remains stable across
   the two-pass lookup. The new callback returns an edge only after positive CAS;
   warning remains the original diagnostic and has no admission authority.
3. Actual scheduler find/unlock bridges must transfer/consume that positive
   Thread edge. Current-thread selection borrows the existing syscall lifetime.
   Same-allocation retention is not proof of sched_policy/state serialization:
   actual apply/runqueue locking, migration, offload, usercopy and final retirement
   keep their original contracts and remain native obligations.
4. Usercopy keeps genuine C-long status and scratch/offset/initialized-byte
   contracts. No hash/IRQ lock spans the faulting copy or ownership offload. Setter
   error ordering, query/RR semantics and original owner checks remain unchanged
   except the already-reviewed lifetime/identity repairs.
5. C type checks, actual selected/default object link, resource restoration and
   changed-boundary native application checks require their own real compiler/
   execution release. A full Rust compile does not prove any of those effects or
   resolve Source21 pending-state/status/alias/HELD policies.

Small unsafe invariants are the same actual references and layouts, now connected
to the real parents. One foreign edge remains until every field read/copy/apply
finishes, then drops once on each normal return; current owns no additional edge.
No failed lookup pointer escapes its hash guard and no zero-count node is
returned. Shared guard layout is internal Rust only, not a new C ABI. The original
kernel destructor, real callback providers and no-fake-pin constraint are preserved.

Next executable check

READY-REAL-CRATE-COMPILE.NOT-GRANTED.json (40facead) binds recipe cd139714 and
runner a18bac77. Root must grant the exact ordinary CPU0 one-job/2GiB profile
with fresh standard floors and source/physical scheduling admission. Launch uses
explicit /usr/bin/taskset argv -c,0 before the runner Python. It makes ONE changed
source full-kernel rustc command and retains the first stderr/object/raw join.
No C compiler/link, prior fixture/test suite, root/module/guest or native observer
is included. Stop first unexpected result and apply the bounded-correction rule.

The intended technical result is honest compiler feedback from the selected real
crate. Candidate may remain default-OFF and incomplete after that result. No
default/native/whole-file/C-retirement acceptance, engineering percentage or
current290 qualifier is inferred from source composition or compiler success.
