#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Actual runner-main controls with a nonspawning capture mock; zero Rust compilers.
"""
import ast
import contextlib
import hashlib
import io
import json
import os as real_os
from pathlib import Path as RealPath
import resource as real_resource
import signal as real_signal
import types

ROOT = RealPath(__file__).resolve().parent
ORIGINAL = ROOT / 'run_real_crate_compile_once.NOT-GRANTED.py'
CORRECTED = ROOT / 'run_real_crate_compile_once.cwd-counter-correction-1.NOT-GRANTED.py'
OUTPUT = ROOT / 'runner-cwd-counter-pure-controls-first-1'
SCOPE = 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'

MOCK_CAPTURE_SOURCE = '''import os
import json
from pathlib import Path
FIELDS=()
stopping=False
CENSUS_SOURCE='MOCK_ONLY_NO_CENSUS'
CENSUS_SHA='MOCK_ONLY'
_CENSUS=None
STOP_SIGNALS=()
def need(*args): return None
def write(*args): return None
def hashed(*args): return None
def stop(*args): return None
def cpu_used(): return 0.001
def members(*args): return []
def process_start(*args): return 0
def terminal_unreaped(*args): return False
def wait_terminal(*args): return None
def owned_capture(command, capture, wall_remaining, limits):
    observed = dict(actual_cwd=os.getcwd(), declared_cwd=command['cwd'],
        mock_only=True, Popen_called=False, Rust_compilers_started=0)
    (capture/'mock-cwd-observation.json').write_text(json.dumps(observed))
    if os.getcwd()!=command['cwd']:
        raise RuntimeError('MOCK_CWD_MISMATCH actual='+os.getcwd()+' declared='+command['cwd'])
    limits()
    Path(command['mock_output']).write_bytes(b'MOCK_ONLY_NOT_A_RUST_OBJECT')
    (capture/'stdout').write_text('')
    (capture/'stderr').write_text('')
    return dict(returncode=0,direct_child_joined=True,group_absent=True,
        closed_streams=True,error=None,retirement_error=None,timed_out=False,
        mock_only=True,Rust_compilers_started=0)
'''


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


class ResourceMock:
    """Keep the real runner's limit calls observable without changing test limits."""
    def __init__(self):
        self.limits = []

    def __getattr__(self, name):
        return getattr(real_resource, name)

    def setrlimit(self, key, value):
        self.limits.append((key, value))

    def getrusage(self, who):
        return types.SimpleNamespace(ru_maxrss=0)


class SignalMock:
    ITIMER_REAL = real_signal.ITIMER_REAL

    @staticmethod
    def signal(*args):
        return None

    @staticmethod
    def setitimer(*args):
        return None


class OsMock:
    """Real chdir/fsync, mocked admission/affinity/environment, never a process spawn."""
    def __init__(self):
        self.environ = dict(real_os.environ)

    def __getattr__(self, name):
        return getattr(real_os, name)

    @staticmethod
    def getuid():
        return 1000

    @staticmethod
    def geteuid():
        return 1000

    @staticmethod
    def sched_getaffinity(pid):
        return {0}

    @staticmethod
    def sched_setaffinity(pid, affinity):
        assert affinity == {0}

    @staticmethod
    def statvfs(path):
        return types.SimpleNamespace(f_bavail=(256 << 30)//4096, f_frsize=4096)


class NormalizeOnlyReviewedDelta(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'os' and node.func.attr == 'chdir'):
            node.args = [ast.Constant('NORMALIZED_REVIEWED_CWD')]
        return node

    def visit_keyword(self, node):
        node = self.generic_visit(node)
        if node.arg == 'fullcrate_compilations':
            node.value = ast.Constant('NORMALIZED_REVIEWED_COUNTER')
        return node


def check_ast_delta():
    original = ORIGINAL.read_text()
    corrected = CORRECTED.read_text()
    assert pin(ORIGINAL)['sha256'] == 'a18bac778c965d983ecf09202da5b8afbb78f266b7607eef2006f298d4b24cfa'
    assert pin(CORRECTED)['sha256'] == 'e4cfaef049e63c42122c270d381d6bd41b087eb625dadc44f920d8c4f0a2f387'
    assert original.count("os.chdir(Path('/home/holden/mckernel'))") == 1
    assert corrected.count("os.chdir(Path(recipe['commands'][0]['cwd']))") == 1
    assert original.count('fullcrate_compilations=0, actual_object=') == 1
    assert corrected.count('fullcrate_compilations=1, actual_object=') == 1
    normalize = lambda text: ast.dump(NormalizeOnlyReviewedDelta().visit(ast.parse(text)))
    assert normalize(original) == normalize(corrected), 'unreviewed runner AST delta'
    # Exactly one chdir controls the parent inherited by capture; no later reset.
    main = next(node for node in ast.parse(corrected).body if isinstance(node, ast.FunctionDef)
        and node.name == 'main')
    chdir = [node for node in ast.walk(main) if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute) and node.func.attr == 'chdir']
    assert len(chdir) == 1
    return dict(status='PASS', changes_only=['declared command cwd', 'fullcrate success counter'])


def run_actual_main_mock(label, runner, declared_cwd, expect_failure, expected_counter):
    case = OUTPUT / label
    case.mkdir(mode=0o700)
    helper = case / 'MOCK_CAPTURE_NO_SPAWN.py'
    helper.write_text(MOCK_CAPTURE_SOURCE)
    memory = case / 'mock-meminfo'
    memory.write_text('MemAvailable: 100000000 kB\n')
    recipe_path = case / 'mock-recipe.json'
    recipe_path.write_text(json.dumps(dict(
        commands=[dict(name='mock-only-no-compiler', argv=['MOCK_NEVER_EXECUTED'],
            cwd=str(declared_cwd), mock_output=str(case/'output/candidate.o'))],
        inputs=[], sources=[], canonical_origins=[], header_bindings=[],
        tools={}, fixture_tools={}), indent=2)+'\n')
    # Execute the actual unchanged production main function, with only its test
    # environment/capture provider mocked. All generated bytes stay under case.
    namespace = dict(__name__='production_main_mock', __file__=str(runner))
    exec(compile(runner.read_bytes(), str(runner), 'exec'), namespace)
    namespace.update(RECIPE=recipe_path, RECIPE_SHA=pin(recipe_path)['sha256'],
        HELPER=helper, HELPER_SHA=pin(helper)['sha256'], OUTPUT=case/'output',
        CAPTURE=case/'captures', RESULT=case/'MOCK_MAIN_RESULT_NOT_A_COMPILER.json',
        os=OsMock(), resource=ResourceMock(), signal=SignalMock())

    def path_mock(value):
        return memory if str(value) == '/proc/meminfo' else RealPath(value)

    namespace['Path'] = path_mock
    previous = RealPath.cwd()
    console = io.StringIO()
    caught = None
    try:
        with contextlib.redirect_stdout(console), contextlib.redirect_stderr(console):
            try:
                status = namespace['main']()
            except BaseException as error:
                caught = type(error).__name__+': '+str(error)
                status = None
    finally:
        real_os.chdir(previous)
    result = json.loads(namespace['RESULT'].read_text())
    observed = json.loads((case/'captures/mock-only-no-compiler/mock-cwd-observation.json').read_text())
    assert observed['Popen_called'] is False and observed['Rust_compilers_started'] == 0
    if expect_failure:
        assert caught and 'MOCK_CWD_MISMATCH' in caught and not result['records']
        assert result['status'] == 'FAIL_STOP_PRESERVE_PREFIX_NO_RETRY'
    else:
        assert caught is None and status == 0
        assert observed['actual_cwd'] == observed['declared_cwd']
        assert result['fullcrate_compilations'] == expected_counter
        assert len(result['records']) == 1 and result['records'][0]['join']['mock_only']
    (case/'captured-main-console.txt').write_text(console.getvalue())
    return dict(label=label, runner=pin(runner), declared_cwd=str(declared_cwd),
        observed_cwd=observed['actual_cwd'], expected_failure=expect_failure,
        observed_fullcrate_counter=result.get('fullcrate_compilations'),
        expected_counter=expected_counter, mock_only=True, real_compilers=0,
        raw_mock_result=pin(namespace['RESULT']))


def main():
    if OUTPUT.exists():
        raise RuntimeError('existing pure-control attempt retained; no replay')
    ast_result = check_ast_delta()
    OUTPUT.mkdir(mode=0o700)
    rows = [
        run_actual_main_mock('original-cwd-defect', ORIGINAL, ROOT, True, None),
        run_actual_main_mock('original-counter-defect', ORIGINAL, RealPath('/home/holden/mckernel'), False, 0),
        run_actual_main_mock('corrected-private-cwd-counter', CORRECTED, ROOT, False, 1),
    ]
    result = dict(scope=SCOPE, status='PASS_AST_AND_THREE_ACTUAL_MAIN_MOCK_CONTROLS_ONLY',
        ast_control=ast_result, mock_controls=rows, actual_Rust_compiler_commands=0,
        actual_process_spawns=0, actual_affinity_or_limit_mutations=0,
        production_candidate_mutations=0, native=False)
    (OUTPUT/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print('PASS Source27 runner AST1 productionmock3 cwd-private counter1 zero-compilers')


if __name__ == '__main__':
    main()
