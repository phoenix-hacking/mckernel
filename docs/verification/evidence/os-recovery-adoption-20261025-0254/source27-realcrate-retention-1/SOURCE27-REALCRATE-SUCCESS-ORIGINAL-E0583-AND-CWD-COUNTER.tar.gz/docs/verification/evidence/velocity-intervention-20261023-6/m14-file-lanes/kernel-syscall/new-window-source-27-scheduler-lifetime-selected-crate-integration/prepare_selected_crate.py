#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare only an independent actual-kernel source composition and binding manifest.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re

REPO = Path('/home/holden/mckernel')
BASE = REPO / 'docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall'
ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT / 'candidate'
RETAINED = REPO / ('docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/'
    'x86-cpu/new-window-source-18-current289-union-source-1/'
    'qualified-getsiginfo-current290-successor-1/complete-genuine-ABI14-witness-suffix07-source-1')
SCOPE = 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def module_paths(text, root):
    pending = None
    result = {}
    for line in text.splitlines():
        match = re.match(r'#\[path\s*=\s*"([^"]+)"\]', line)
        if match:
            pending = Path(match.group(1))
        match = re.match(r'(?:pub )?mod (\w+);', line)
        if match:
            name = match.group(1)
            result[name] = (root / pending).resolve() if pending else root / (name + '.rs')
            pending = None
    return result


def function(text, name):
    match = re.search(r'(?:pub )?(?:unsafe )?(?:extern "C" )?fn ' + name + r'\(', text)
    start = match.start()
    brace = text.index('{', match.end())
    depth = 1
    end = brace + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end]


def write(relative, raw):
    target = CANDIDATE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(raw if isinstance(raw, bytes) else raw.encode())


def main():
    if CANDIDATE.exists():
        raise RuntimeError('existing independent candidate retained; no overwrite/replay')
    source_rows = []
    # Copy actual production Rust sources, excluding unselected test directories.
    for origin in sorted((REPO / 'kernel/rust').glob('*.rs')):
        relative = origin.relative_to(REPO)
        write(relative, origin.read_bytes())
        source_rows.append({'origin': pin(origin), 'copy': str(CANDIDATE / relative)})
    canonical_root = (REPO / 'kernel/rust/lib.rs').read_text()
    canonical_modules = module_paths(canonical_root, REPO / 'kernel/rust')
    for name, origin in canonical_modules.items():
        if origin.parent == REPO / 'kernel/rust':
            continue
        relative = origin.relative_to(REPO)
        write(relative, origin.read_bytes())
        source_rows.append({'module': name, 'origin': pin(origin), 'copy': str(CANDIDATE / relative)})
    retained_root_path = RETAINED / 'lib.current-successor.ABI.object.rs'
    retained_root = retained_root_path.read_text()
    retained_modules = module_paths(retained_root, RETAINED)
    normalized = lambda text: re.sub(r'^#\[path = "[^"]+"\]\n', '', text, flags=re.M)
    canonical_normalized = normalized(canonical_root)
    retained_normalized = normalized(retained_root)
    if not retained_normalized.startswith(canonical_normalized):
        raise RuntimeError('actual canonical root no longer matches retained genuine crate prefix')
    appendix_rows = []
    missing_inactive_retained = []
    for name, origin in canonical_modules.items():
        previous = retained_modules[name]
        if not previous.exists():
            # e517 has native_sysfs_verify OFF. Current canonical source is still
            # copied; no missing historical path is read or silently fabricated.
            if name != 'sysfs_verify':
                raise RuntimeError('missing retained real module: ' + name)
            missing_inactive_retained.append({'module': name, 'path': str(previous),
                'current_canonical': pin(origin), 'reason': 'native_sysfs_verify absent from retained cfg set'})
            continue
        current = origin.read_bytes()
        retained = previous.read_bytes()
        if not retained.startswith(current):
            raise RuntimeError('retained module is not current canonical plus ABI suffix: ' + name)
        extra = retained[len(current):]
        if extra:
            target = CANDIDATE / origin.relative_to(REPO)
            target.write_bytes(current + extra)
            appendix_rows.append({'module': name, 'retained': pin(previous),
                'canonical': pin(origin), 'appendix_bytes': len(extra),
                'appendix_sha256': hashlib.sha256(extra).hexdigest()})
    root_appendix = retained_normalized[len(canonical_normalized):]
    (CANDIDATE / 'kernel/rust/lib.rs').write_text(canonical_root + root_appendix)
    appendix_rows.append({'module': 'lib', 'retained': pin(retained_root_path),
        'canonical': pin(REPO / 'kernel/rust/lib.rs'), 'appendix_bytes': len(root_appendix.encode()),
        'appendix_sha256': hashlib.sha256(root_appendix.encode()).hexdigest()})

    # Compose Source22's unchanged production candidate and unchanged public ABI.
    source22 = BASE / 'new-window-source-22-positive-reference-lookup-repair'
    process_path = CANDIDATE / 'kernel/rust/process_helpers.rs'
    process = process_path.read_text()
    old_find = function(process, 'find_thread')
    replacement_find = (source22 / 'PUBLIC-FIND-THREAD.REUSED-WRAPPER.rs.inc').read_text()
    replacement_find = replacement_find.removeprefix('#[no_mangle]\n').replace(
        'fn f02_public_find_thread_candidate_v2(', 'fn find_thread(', 1).rstrip()
    process = process.replace(old_find, replacement_find, 1)
    process += ('\n// ' + SCOPE + '\n#[cfg(f02_positive_reference_lookup_candidate)]\n'
        '#[path="f02_positive_reference_lookup.rs"]\nmod f02_positive_reference_lookup;\n')
    process_path.write_text(process)
    write('kernel/rust/f02_positive_reference_lookup.rs', (source22 / 'positive_reference_lookup.rs').read_bytes())

    source23 = BASE / 'new-window-source-23-scheduler-query-lifetime'
    source24 = BASE / 'new-window-source-24-scheduler-setter-lifetime'
    source25 = BASE / 'new-window-source-25-rr-interval-lifetime'
    query_original = (source23 / 'f03_scheduler_query_lifetime_v2.rs').read_text()
    guard_start = query_original.index('struct RetainedQueryThread {')
    guard_end = query_original.index('/// Preserve scheduler parameter copying', guard_start)
    guard = query_original[guard_start:guard_end]
    guard24 = (source24 / 'RETAINED-TARGET.REUSED-SOURCE23.rs.inc').read_text()
    guard25 = (source25 / 'scheduler_query_retention.REUSED-EXACT.inc').read_text()
    if guard != guard24 or guard.rstrip('\n') != guard25.rstrip('\n'):
        raise RuntimeError('scheduler guards differ beyond the recorded trailing newline')
    common = guard.replace('struct RetainedQueryThread {', 'pub(super) struct RetainedQueryThread {', 1)
    common = common.replace(' address:usize,', ' pub(super) address:usize,', 1)
    common = common.replace(' release:Option<SchedThreadUnlockFn>,',
        ' pub(super) release:Option<SchedThreadUnlockFn>,', 1)
    common = common.replace('unsafe fn select_retained_query(', 'pub(super) unsafe fn select_retained_query(', 1)
    # The existing algorithm is literal apart from internal visibility required to
    # share one actual guard. No fields, reference operations or callback ABI change.
    if common.replace('pub(super) ', '') != guard:
        raise RuntimeError('non-visibility guard mutation')
    common_header = ('// ' + SCOPE + '\n// Exact Source23 guard, factored once; visibility-only change.\n'
        'use super::{SchedSyscallOffsets, SchedFindThreadFn, SchedThreadUnlockFn,\n'
        '    sched_normalized_pid, sched_thread_pid, sched_errno, EINVAL, ESRCH};\n'
        'use crate::abi::{CInt, CLong};\n\n')
    write('kernel/rust/sched_retained_target.rs', common_header + common)
    query = query_original[:guard_start] + 'use super::sched_retained_target::select_retained_query;\n\n' + query_original[guard_end:]
    query = query.replace(' sched_normalized_pid,sched_thread_pid,sched_thread_policy,', ' sched_thread_policy,')
    query = query.replace('EINVAL,ESRCH,EFAULT', 'EINVAL,EFAULT')
    setter_original = (source24 / 'f03_sched_setparam_lifetime_v2.rs').read_text()
    setter = setter_original.replace('include!("RETAINED-TARGET.REUSED-SOURCE23.rs.inc");',
        'use super::sched_retained_target::select_retained_query;')
    setter = setter.replace('sched_errno, sched_normalized_pid, sched_thread_pid, sched_thread_policy,',
        'sched_errno, sched_thread_policy,').replace('EFAULT, EINVAL, ESRCH,', 'EFAULT, EINVAL,')
    rr_original = (source25 / 'f03_sched_rr_interval_lifetime_v2.rs').read_text()
    rr = rr_original.replace('include!("scheduler_query_retention.REUSED-EXACT.inc");',
        'use super::sched_retained_target::select_retained_query;')
    rr = rr.replace('sched_errno, sched_normalized_pid, sched_rr_interval_nsec, sched_thread_pid,',
        'sched_errno, sched_rr_interval_nsec,').replace('EFAULT, EINVAL, ESRCH,', 'EFAULT, EINVAL,')
    for name, text in [('f03_scheduler_query_lifetime_v2.rs', query),
        ('f03_sched_setparam_lifetime_v2.rs', setter), ('f03_sched_rr_interval_lifetime_v2.rs', rr)]:
        write('kernel/rust/' + name, text)
    body_preservation = []
    for original, changed, names in [(query_original, query, ['sched_getparam_retained_v2', 'sched_getscheduler_retained_v2']),
        (setter_original, setter, ['sched_setparam_retained_v2']),
        (rr_original, rr, ['sched_rr_get_interval_retained_v2'])]:
        for name in names:
            before = function(original, name)
            after = function(changed, name)
            if before != after:
                raise RuntimeError('reviewed scheduler body changed: ' + name)
            body_preservation.append({'function': name, 'bytes': len(before.encode()),
                'sha256': hashlib.sha256(before.encode()).hexdigest(), 'exact_body_preserved': True})

    sched_path = CANDIDATE / 'kernel/rust/sched_helpers.rs'
    sched = sched_path.read_text()
    old_setter = function(sched, 'sched_setparam_body_result')
    brace = old_setter.index('{')
    args = 'pid,uparam_addr,current_thread,param_addr,param_size,offsets,syscall_nr,find_fn,unlock_fn,copy_from_fn,syscall2_fn,apply_fn'
    updated_setter = (old_setter[:brace+1] + '\n    #[cfg(f03_sched_setparam_lifetime_candidate)]\n    {\n'
        '        return f03_sched_setparam_lifetime_v2::sched_setparam_retained_v2(' + args + ');\n    }\n'
        '    #[cfg(not(f03_sched_setparam_lifetime_candidate))]\n    {' + old_setter[brace+1:-1] + '\n    }\n}')
    sched = sched.replace(old_setter, updated_setter, 1)
    sched += ('\n// ' + SCOPE + '\n'
        '#[cfg(any(f03_scheduler_query_lifetime_v2, f03_sched_setparam_lifetime_candidate, f03_rr_interval_lifetime_v2))]\n'
        'mod sched_retained_target;\n'
        '#[cfg(f03_scheduler_query_lifetime_v2)]\npub(crate) mod f03_scheduler_query_lifetime_v2;\n'
        '#[cfg(f03_sched_setparam_lifetime_candidate)]\nmod f03_sched_setparam_lifetime_v2;\n'
        '#[cfg(f03_rr_interval_lifetime_v2)]\npub(crate) mod f03_sched_rr_interval_lifetime_v2;\n')
    sched_path.write_text(sched)
    syscall_path = CANDIDATE / 'kernel/rust/syscall_policy.rs'
    syscall = syscall_path.read_text()
    for entry, old_call, cfg, module, new_call in [
        ('sys_sched_getparam', 'sched_getparam_body_result', 'f03_scheduler_query_lifetime_v2', 'f03_scheduler_query_lifetime_v2', 'sched_getparam_retained_v2'),
        ('sys_sched_getscheduler', 'sched_getscheduler_body_result', 'f03_scheduler_query_lifetime_v2', 'f03_scheduler_query_lifetime_v2', 'sched_getscheduler_retained_v2'),
        ('sys_sched_rr_get_interval', 'sched_rr_get_interval_body_result', 'f03_rr_interval_lifetime_v2', 'f03_sched_rr_interval_lifetime_v2', 'sched_rr_get_interval_retained_v2')]:
        original = function(syscall, entry)
        replacement = ('#[cfg(' + cfg + ')]\n    use crate::sched_helpers::' + module + '::' + new_call + ' as query;\n'
            '    #[cfg(not(' + cfg + '))]\n    use crate::sched_helpers::' + old_call + ' as query;\n\n    query(')
        changed = original.replace('crate::sched_helpers::' + old_call + '(', replacement, 1)
        if changed == original:
            raise RuntimeError('selected kernel entry binding missing: ' + entry)
        syscall = syscall.replace(original, changed, 1)
    syscall_path.write_text(syscall)

    # C change is declarations/static type checks only, with no added runtime body.
    c_origin = REPO / 'kernel/process.c'
    declarations = (source22 / 'VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc').read_text()
    c_source = c_origin.read_text().replace('#include <process_helpers.h>\n',
        '#include <process_helpers.h>\n\n#ifdef MCKERNEL_RUST_F02_POSITIVE_REFERENCE_LOOKUP\n' + declarations + '#endif\n', 1)
    write('kernel/process.c', c_source)

    modified = ['kernel/process.c', 'kernel/rust/process_helpers.rs', 'kernel/rust/sched_helpers.rs', 'kernel/rust/syscall_policy.rs']
    patch = []
    for relative in modified:
        before = (REPO / relative).read_text()
        after = (CANDIDATE / relative).read_text()
        # ABI appendix provenance is retained explicitly in the manifest; this is
        # the exact complete private candidate delta, never an applied canonical patch.
        patch.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
            fromfile='a/' + relative, tofile='b/' + relative))
    for relative in ['kernel/rust/f02_positive_reference_lookup.rs', 'kernel/rust/sched_retained_target.rs',
        'kernel/rust/f03_scheduler_query_lifetime_v2.rs', 'kernel/rust/f03_sched_setparam_lifetime_v2.rs',
        'kernel/rust/f03_sched_rr_interval_lifetime_v2.rs']:
        patch.extend(difflib.unified_diff([], (CANDIDATE / relative).read_text().splitlines(True),
            fromfile='/dev/null', tofile='b/' + relative))
    (ROOT / 'SELECTED-CRATE-COMPOSITION.DEFAULT-OFF.patch').write_text(''.join(patch))
    candidate_rows = [pin(path) for path in sorted(CANDIDATE.rglob('*')) if path.is_file()]
    manifest = {'scope': SCOPE, 'status': 'REAL_FULL_KERNEL_CRATE_STATIC_CANDIDATE_NOT_COMPILED_NOT_GRANTED',
        'canonical_origins': source_rows, 'candidate_files': candidate_rows,
        'retained_e517_root': pin(retained_root_path), 'genuine_ABI_appendices_preserved': appendix_rows,
        'inactive_missing_retained_paths': missing_inactive_retained,
        'same_reviewed_scheduler_function_bodies': body_preservation,
        'shared_guard': {'origin': pin(source23 / 'f03_scheduler_query_lifetime_v2.rs'),
            'source23_span_sha256': hashlib.sha256(guard.encode()).hexdigest(),
            'source24_exact': guard == guard24,
            'source25_trailing_LF_difference_only': guard.rstrip('\n') == guard25.rstrip('\n'),
            'candidate': pin(CANDIDATE / 'kernel/rust/sched_retained_target.rs'),
            'changes': 'Single actual guard, only pub(super) type/fields/selector visibility; literal algorithm unchanged.'},
        'new_cfgs': ['f02_positive_reference_lookup_candidate', 'f03_scheduler_query_lifetime_v2',
            'f03_sched_setparam_lifetime_candidate', 'f03_rr_interval_lifetime_v2'],
        'C_change': 'Source22 declarations/static type checks only; no C compiler or runtime action.',
        'default_global_flags_changed': False, 'current290_mutations': 0, 'canonical_mutations': 0,
        'fixture_or_native_execution': False}
    with (ROOT / 'STATIC-REAL-CRATE-CANDIDATE-MANIFEST.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': manifest['status'], 'copied_files': len(candidate_rows),
        'candidate_bytes': sum(row['bytes'] for row in candidate_rows),
        'unchanged_reviewed_scheduler_bodies': len(body_preservation),
        'ABI_appendix_bytes': sum(row['appendix_bytes'] for row in appendix_rows),
        'manifest': pin(ROOT / 'STATIC-REAL-CRATE-CANDIDATE-MANIFEST.json')}))


if __name__ == '__main__':
    main()
