Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Latest actual C-only suffix PASS333logical scenarios/657body calls,
genuineABI22+lookup12 (resultc7fb320d), first attempt. Both children joined0,
groups absent, streams closed; CPU0 explicitly released. Original retained
objects04223e19/fbd48780 were reused with no Rust recompilation or prior-suite
replay. See ACTUAL-CONTROLLED-333-AND-TASK-CURSOR.json. Independent actual-result
acceptance and production/native synchronization gates remain open. Earlier
UNRUN/preparation descriptions below are retained history.

Source24 is a private, default-OFF sched_setparam lifetime/identity repair. Its new
Rust body compiled on the first prefix: result54ff5651, object2896B/04223e19,
wall .175359s/shared CPU .257560s/maximum child RSS95,700KiB. Child joined0,
group absent, streams closed, CPU0 explicitly released. No C fixture ran.
Canonical files, Source22/23 accepted inputs, current290 source/flags/compiler
prefixes and native ownership were unchanged. Root alone integrates shared files.

The selected defect is concrete: sched_setparam_body_result calls the shared
sched_select_thread, which finds and immediately unlocks the foreign allocation.
It then checks owner, copies parameters, finds the numeric ID again and applies
using that second allocation. Final exit between those operations can make the
second lookup fail or return a replacement, even though the owner check was for
the earlier identity. Existing sched_setscheduler_body_result already preserves
one allocation across owner check/apply and explicitly documents this reason.
That working body is retained unchanged and supplies the behavioral precedent.

The actual delta is f03_sched_setparam_lifetime_v2.rs plus the exact Source23
RetainedQueryThread/selector source span. The new setter:

* Preserves argument checks, copy/apply-provider validation, initial lookup, owner
  check, usercopy and apply result order. Initial missing targets still yield
  ESRCH before owner/copy. Provider errors retain their original precedence.
* Keeps the initial foreign lookup edge through owner offload, faulting copy,
  policy read and apply. It never performs a second ID lookup. Current-thread
  selection borrows its original syscall lifetime and acquires/releases no edge.
* Reuses Source23's exact guard/selector bytes; no getter implementation or shared
  legacy selector is copied into a new port or edited. Guard Drop consumes one
  foreign edge exactly once on every normal success/error return.
* Preserves the genuine C-long owner/copy return ABI. Nonzero owner status returns
  unchanged; only negative copy status maps to EFAULT, exactly like the selected
  setter. Apply retains its C-int result widened to C-long. No errno is invented.
* Reads policy after usercopy from the still-retained original allocation, then
  calls the same apply provider. No hash/IRQ lock is held across offload, usercopy
  or apply. Existing provider runqueue/state locking is unchanged.

For foreign selection, original pid must be nonzero: pid0 normalizes to current
process PID and takes the current branch. Therefore the original numeric pid is
the same normalized owner-check argument for the retained foreign branch. No
extra lookup or normalization callback is added to obtain that argument.

Sequential errors/results remain comparable. Under final-exit interleavings,
the former second-lookup ESRCH or replacement-target apply intentionally changes:
the retained original stays live through completion, matching setscheduler's
existing allocation-identity rule. This is not an equivalence claim for the
defective relookup behavior, nor a new permission/ownership-check policy.

Minimal unsafe invariants

1. Foreign find returns a positive actual reference after dropping its hash lock;
   original unlock consumes exactly that edge. Source22's independently qualified
   positive lookup is reused in the controlled fixture, not reimplemented in C.
2. The current syscall thread stays live by its existing context. A current target
   has no foreign edge to drop. Its PID/process metadata uses the original helpers.
3. Scratch, offsets and scheduler parameter bytes meet genuine layout/alignment
   and initialized-storage contracts. Synchronous providers do not retain stack
   storage or throw an unexpected unwind through the kernel C ABI.
4. Allocation lifetime is distinct from sched_policy/state serialization. The
   existing volatile policy read and apply provider locking remain the authority;
   CPU migration, concurrent state updates and real native teardown are unassessed.

The patch SETPARAM-LIFETIME.DEFAULT-OFF.patch modifies only private future
sched_helpers.rs selection plus two Rust files. The public C helper ABI remains
sched_setparam_body_result with the same arguments and return. Default-off cfg
delegation chooses the new versioned Rust body; the original branch remains
preserved. There is no new live compute C logic and no shared canonical edit.

Prepared meaningful next check

C-SUFFIX.READY-FOR-INDEPENDENT-REVIEW.NOT-GRANTED.json binds READY10b75809,
recipe dad4b301 and runner be3eb728. Two commands link the genuine C header/ABI
driver with new object04223e19 plus accepted lookup objectfbd48780, then run the
controlled oracle. Both retained object identities are pinned. No successful
Rust prefix, Source22's42 suite, Source23 getter suite or older60/411 suite is
replayed. The selected original setter is retained as a reference in the new
object solely for the old/new comparison.

Prepared324 old/new matrix pairs cover current/foreign, present/absent lookup,
zero/negative/high-word owner status, zero/negative-high-word/positive-high-word
copy status, apply result propagation and exit during owner check or usercopy.
Nine focused cases cover invalid arguments, missing copy/apply/find/unlock/check
providers, lookup-before-missing-check precedence and current-thread no-provider
selection. There are333 logical scenarios/657 body calls. Genuine ABI22 and
retained lookup ABI12 are checked, including real C-long/C-int callback types.

The controlled final-exit model obeys positive references and actual hash order:
dropping the original external edge can detach/publish a replacement only after
the count reaches zero and the hash writer is acquired. Old setparam releases
too early, permitting replacement or disappearance before its second lookup.
New setparam's edge prevents retirement until after apply/error cleanup. Static
storage models retirement without reading actually freed memory. No IRQ/spin or
native scheduler behavior is supplied by the controlled providers.

Independent source/ownership/ABI review and a fresh root ordinary grant are
required before the two commands. Stop first unexpected result, retain raw streams
and joins, and use the existing bounded-correction rule. No fixture grant exists.

Remaining boundaries

Source23 owns getter repair; its sources are untouched. Existing setscheduler
is unchanged. RR interval still uses the old selector/read path and remains an
independent open consumer; it is not included in this setter patch. The shared
legacy selector is left unchanged so pending getter/current290 work is isolated.
Actual fullcrate/selected C ABI/default link, positive lookup production routing,
native offload/copy/runqueue behavior and final resource restoration remain open.
A HOST pass would qualify the explicit controlled contract only, without default,
whole-file/C-retirement or native acceptance credit.
