/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"




#include <process_helpers.h>
#include "GENUINE-SETTER-DECLARATIONS.C.inc"
#include "../new-window-source-22-positive-reference-lookup-repair/VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
extern struct thread *f02_public_find_thread_candidate_v2(int,int);
extern const unsigned long f03_setparam_lifetime_Rust_ABI[22],f02_lookup_Rust_ABI[12];
extern int printf(const char *,...);extern int dprintf(int,const char *,...);extern void abort(void);
#define require(v)do{if(!(v)){dprintf(2,"FAIL setparam lifetime line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
static struct thread current_thread,original_target,replacement_target;
static struct process current_process,original_process,replacement_process;
static struct resource_set resources;
static struct thread_hash hash;
static struct cpu_local_var cpu;
static struct sched_param copied_param;
static int foreign_target,lookup_present,change_stage,owner_calls,copy_calls,apply_calls;
static int find_calls,unlock_calls,applied_identity,original_retired,replacement_pending;
static int baseline_dropped,hash_reader_held,hash_writer_held;
static unsigned long active_node;
static long owner_result,copy_result;static int apply_result;
static char events[32];static int event_count;
static void event(char value){require(event_count<32);events[event_count++]=value;}
struct cpu_local_var *get_this_cpu_local_var(void){return &cpu;}
void __mcs_rwlock_reader_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[200%HASH_SIZE]&&!hash_reader_held&&!hash_writer_held);
 require(node&&!((unsigned long)node%__alignof__(*node)));hash_reader_held=1;active_node=(unsigned long)node;*(unsigned long *)node=0x51aa;
}
void __mcs_rwlock_reader_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[200%HASH_SIZE]&&hash_reader_held&&(unsigned long)node==active_node&&*(unsigned long *)node==0x51aa);hash_reader_held=0;active_node=0;
}
void process_mcs_reader_lock_bridge(unsigned long lock,void *node){__mcs_rwlock_reader_lock((struct mcs_rwlock_lock *)lock,node);}
void process_mcs_reader_unlock_bridge(unsigned long lock,void *node){__mcs_rwlock_reader_unlock((struct mcs_rwlock_lock *)lock,node);}
void __mcs_rwlock_writer_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[200%HASH_SIZE]&&!hash_reader_held&&!hash_writer_held);hash_writer_held=1;active_node=(unsigned long)node;*(unsigned long *)node=0x61bb;
}
void __mcs_rwlock_writer_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[200%HASH_SIZE]&&hash_writer_held&&(unsigned long)node==active_node&&*(unsigned long *)node==0x61bb);hash_writer_held=0;active_node=0;
}
void process_hold_thread_warn_bridge(void *thread){require(thread==&original_target&&hash_reader_held&&original_target.status==PS_EXITED);}
static void publish(struct thread *thread){
 struct list_head *head=&hash.list[200%HASH_SIZE];
 if(thread){head->next=head->prev=&thread->hash_list;thread->hash_list.next=thread->hash_list.prev=head;}
 else head->next=head->prev=head;
}
static void complete_original_retirement(void){
 require(original_target.refcount.counter==0&&replacement_pending&&!original_retired&&!hash_reader_held&&!hash_writer_held);
 struct mcs_rwlock_node_irqsave node;__mcs_rwlock_writer_lock(&hash.lock[200%HASH_SIZE],&node);
 original_retired=1;publish(change_stage==1?&replacement_target:NULL);
 __mcs_rwlock_writer_unlock(&hash.lock[200%HASH_SIZE],&node);
}
static void request_original_exit(void){
 require(foreign_target&&!baseline_dropped&&original_target.refcount.counter>0&&!hash_reader_held&&!hash_writer_held);
 baseline_dropped=1;replacement_pending=1;original_target.status=PS_EXITED;
 original_target.refcount.counter--;if(!original_target.refcount.counter)complete_original_retirement();
}
static unsigned long find_target(int pid){
 require(pid==200&&!hash_reader_held&&!hash_writer_held);find_calls++;event('F');
 return (unsigned long)f02_public_find_thread_candidate_v2(0,pid);
}
static void release_target(unsigned long address){
 struct thread *thread=(void *)address;require((thread==&original_target||thread==&replacement_target)&&!hash_reader_held&&!hash_writer_held&&thread->refcount.counter>0);
 unlock_calls++;event('U');thread->refcount.counter--;
 if(thread==&original_target&&!thread->refcount.counter)complete_original_retirement();
}
static long check_owner(int nr,unsigned long operation,unsigned long pid){
 require(nr==142&&operation==1&&pid==200&&!hash_reader_held&&!hash_writer_held);owner_calls++;event('S');
 if(change_stage==1&&!baseline_dropped)request_original_exit();return owner_result;
}
static long copy_parameters(void *destination,unsigned long source,size_t bytes){
 require(destination==&copied_param&&source==0x1234&&bytes==sizeof(copied_param)&&!hash_reader_held&&!hash_writer_held);
 copy_calls++;event('C');copied_param.sched_priority=foreign_target?9:0;
 if(foreign_target){if(!original_retired)original_target.sched_policy=2;replacement_target.sched_policy=1;}
 else current_thread.sched_policy=0;
 if(foreign_target&&change_stage==2&&!baseline_dropped)request_original_exit();
 return copy_result;
}
static int apply_parameters(unsigned long address,int policy,unsigned long parameter){
 struct thread *thread=(void *)address;require(!hash_reader_held&&!hash_writer_held&&parameter==(unsigned long)&copied_param);
 require(thread==&current_thread||thread==&original_target||thread==&replacement_target);
 if(thread==&original_target){require(!original_retired&&thread->refcount.counter>0&&policy==2);applied_identity=1;}
 else if(thread==&replacement_target){require(thread->refcount.counter>=2&&policy==1);applied_identity=2;}
 else{require(!foreign_target&&policy==0&&thread->refcount.counter==1);applied_identity=0;}
 require(copied_param.sched_priority==(foreign_target?9:0));apply_calls++;event('A');return apply_result;
}
_Static_assert(__builtin_types_compatible_p(__typeof__(&find_target),sched_find_thread_fn_t),"genuine find ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&release_target),sched_thread_unlock_fn_t),"genuine release ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&check_owner),syscall_do_syscall2_fn_t),"full C-long owner status ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&copy_parameters),syscall_copy_from_user_fn_t),"full C-long copy ABI");
_Static_assert(__builtin_types_compatible_p(__typeof__(&apply_parameters),sched_apply_scheduler_fn_t),"genuine C-int apply ABI");
static const struct sched_syscall_offsets offsets={
 __builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,cpu_id),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct process,pid),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),__builtin_offsetof(struct process,cpu_set)};
static void reset(int foreign,int present,int change,long owner,long copied,int applied){
 __builtin_memset(&current_thread,0,sizeof(current_thread));__builtin_memset(&original_target,0,sizeof(original_target));__builtin_memset(&replacement_target,0,sizeof(replacement_target));
 __builtin_memset(&current_process,0,sizeof(current_process));__builtin_memset(&original_process,0,sizeof(original_process));__builtin_memset(&replacement_process,0,sizeof(replacement_process));
 __builtin_memset(&resources,0,sizeof(resources));__builtin_memset(&hash,0,sizeof(hash));__builtin_memset(&cpu,0,sizeof(cpu));__builtin_memset(&copied_param,0,sizeof(copied_param));
 current_thread.tid=current_process.pid=100;original_target.tid=original_process.pid=200;replacement_target.tid=replacement_process.pid=200;
 current_thread.proc=&current_process;original_target.proc=&original_process;replacement_target.proc=&replacement_process;
 current_thread.refcount.counter=original_target.refcount.counter=replacement_target.refcount.counter=1;
 current_thread.status=original_target.status=replacement_target.status=PS_TRACED;
 current_thread.sched_policy=3;original_target.sched_policy=1;replacement_target.sched_policy=2;
 cpu.resource_set=&resources;resources.thread_hash=&hash;cpu.current=&current_thread;
 foreign_target=foreign;lookup_present=present;change_stage=change;owner_result=owner;copy_result=copied;apply_result=applied;
 owner_calls=copy_calls=apply_calls=find_calls=unlock_calls=original_retired=replacement_pending=baseline_dropped=hash_reader_held=hash_writer_held=0;
 active_node=0;event_count=0;applied_identity=-1;publish(present?&original_target:NULL);
}
static void verify_geometry(void){
 const unsigned long actual22[22]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),__builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,refcount),sizeof(struct process),__builtin_offsetof(struct process,pid),sizeof(struct sched_param),__alignof__(struct sched_param),__builtin_offsetof(struct sched_param,sched_priority),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),__builtin_offsetof(struct sched_syscall_offsets,proc_pid_offset),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(syscall_copy_from_user_fn_t),sizeof(syscall_do_syscall2_fn_t),sizeof(sched_apply_scheduler_fn_t),sizeof(long),__alignof__(long),sizeof(int)};
 const unsigned long actual12[12]={sizeof(struct process_find_thread_offsets),__alignof__(struct process_find_thread_offsets),__builtin_offsetof(struct process_find_thread_offsets,thread_hash_list_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_tid_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_proc_offset),__builtin_offsetof(struct process_find_thread_offsets,proc_pid_offset),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),__builtin_offsetof(struct thread,refcount),sizeof(int),sizeof(process_thread_try_hold_fn_v2),sizeof(struct mcs_rwlock_node_irqsave)};
 require(!memcmp(actual22,f03_setparam_lifetime_Rust_ABI,sizeof(actual22))&&!memcmp(actual12,f02_lookup_Rust_ABI,sizeof(actual12)));
}
static long call_setter(int corrected,int pid,unsigned long user,sched_find_thread_fn_t find,sched_thread_unlock_fn_t unlock,syscall_copy_from_user_fn_t copy,syscall_do_syscall2_fn_t check,sched_apply_scheduler_fn_t apply){
 if(corrected)return sched_setparam_retained_v2(pid,user,(unsigned long)&current_thread,(unsigned long)&copied_param,sizeof(copied_param),&offsets,142,find,unlock,copy,check,apply);
 return f03_setparam_original_reference(pid,user,(unsigned long)&current_thread,(unsigned long)&copied_param,sizeof(copied_param),&offsets,142,find,unlock,copy,check,apply);
}
int main(void){
 verify_geometry();unsigned matrix_cases=0,provider_cases=0,identity_differences=0;
 const long owner_results[3]={0,-1,1L<<32};const long copy_results[3]={0,-(1L<<32),1L<<32};const int apply_results[3]={0,-22,17};
 for(int foreign=0;foreign<2;foreign++)for(int present=0;present<2;present++)for(int owner=0;owner<3;owner++)for(int copied=0;copied<3;copied++)for(int applied=0;applied<3;applied++)for(int change=0;change<3;change++){
  for(int corrected=0;corrected<2;corrected++){
   reset(foreign,present,change,owner_results[owner],copy_results[copied],apply_results[applied]);
   long result=call_setter(corrected,foreign?200:0,0x1234,find_target,release_target,copy_parameters,check_owner,apply_parameters);
   long expected;int should_apply=0;
   if(foreign&&!present)expected=-ESRCH;
   else if(foreign&&owner_results[owner])expected=owner_results[owner];
   else if(copy_results[copied]<0)expected=-EFAULT;
   else if(foreign&&change==2&&!corrected)expected=-ESRCH;
   else{expected=apply_results[applied];should_apply=1;}
   require(result==expected&&apply_calls==should_apply&&!hash_reader_held&&!hash_writer_held);
   require(owner_calls==(foreign&&present));
   int reached_copy=!(foreign&&(!present||owner_results[owner]));require(copy_calls==reached_copy);
   if(should_apply)require(applied_identity==(!foreign?0:!corrected&&change==1?2:1));
   if(!foreign)require(!find_calls&&!unlock_calls);
   else if(!present)require(find_calls==1&&!unlock_calls);
   else if(corrected)require(find_calls==1&&unlock_calls==1);
   else{int second=owner_results[owner]==0&&copy_results[copied]>=0;require(find_calls==1+second&&unlock_calls==1+(second&&change!=2));}
   require(original_target.refcount.counter<=1&&replacement_target.refcount.counter==1&&current_thread.refcount.counter==1);
   if(foreign&&present&&owner_results[owner]==0&&copy_results[copied]>=0&&change)identity_differences++;
  }
  matrix_cases++;
 }
 for(int which=0;which<9;which++){
  reset(1,which!=7,0,0,0,0);int pid=which==1?-1:which==8?0:200;unsigned long user=which==0?0:0x1234;
  sched_find_thread_fn_t find=which==4||which==8?NULL:find_target;
  sched_thread_unlock_fn_t unlock=which==5||which==8?NULL:release_target;
  syscall_copy_from_user_fn_t copy=which==2?NULL:copy_parameters;
  syscall_do_syscall2_fn_t check=which>=6?NULL:check_owner;
  sched_apply_scheduler_fn_t apply=which==3?NULL:apply_parameters;
  if(which==8)foreign_target=0;
  long result=call_setter(1,pid,user,find,unlock,copy,check,apply);
  require(result==(which==8?0:which==7?-ESRCH:-EINVAL));
  if(which==6)require(find_calls==1&&unlock_calls==1&&!copy_calls&&!apply_calls);
  else if(which==7)require(find_calls==1&&!unlock_calls&&!copy_calls&&!apply_calls);
  else if(which==8)require(!find_calls&&!unlock_calls&&copy_calls==1&&apply_calls==1);
  else require(!find_calls&&!unlock_calls&&!copy_calls&&!apply_calls);
  require(!hash_reader_held&&!hash_writer_held&&original_target.refcount.counter==1);provider_cases++;
 }
 require(matrix_cases==324&&provider_cases==9&&identity_differences>0);
 printf("PASS setparam lifetime matrix324 provider9 ABI22 reusedLookupABI12 retained-original-identity no-native-credit\n");return 0;
}
