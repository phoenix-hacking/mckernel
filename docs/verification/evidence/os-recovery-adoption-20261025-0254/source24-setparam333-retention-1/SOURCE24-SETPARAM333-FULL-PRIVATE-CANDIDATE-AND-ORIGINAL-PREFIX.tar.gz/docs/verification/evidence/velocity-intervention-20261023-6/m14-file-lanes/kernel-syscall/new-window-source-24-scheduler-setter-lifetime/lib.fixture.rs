// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"]mod abi;
use abi::{CInt,CLong,CULong,SizeT};use core::ptr::read_volatile;
include!("GENUINE-SETTER-DECLARATIONS.rs.inc");
include!("ACTUAL-PARENT-HELPERS.REUSED-SOURCE23.rs.inc");
include!("SELECTED-SETTER-REFERENCE.rs.inc");
#[path="f03_sched_setparam_lifetime_v2.rs"]mod f03_sched_setparam_lifetime_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f03_setparam_lifetime_Rust_ABI:[usize;22]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),
 offset_of!(abi::Thread,sched_param),offset_of!(abi::Thread,sched_policy),offset_of!(abi::Thread,refcount),
 size_of::<abi::Process>(),offset_of!(abi::Process,pid),
 size_of::<abi::SchedParam>(),align_of::<abi::SchedParam>(),offset_of!(abi::SchedParam,sched_priority),
 size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),offset_of!(SchedSyscallOffsets,proc_pid_offset),
 size_of::<Option<SchedFindThreadFn>>(),size_of::<Option<SchedThreadUnlockFn>>(),
 size_of::<Option<SchedCopyFromUserFn>>(),size_of::<Option<SchedDoSyscall2Fn>>(),size_of::<Option<SchedApplySchedulerFn>>(),
 size_of::<CLong>(),align_of::<CLong>(),size_of::<CInt>(),
];
