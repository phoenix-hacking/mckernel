Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Latest actual C-only suffix PASS42/ABI12+reused20 and expected old-void callback
compile rejection (result88500fa4). Link/run exited0; deliberately negative ABI
compile exited1 with the required incompatible-pointer-types diagnostic. All
three children joined/groups absent/streams closed; CPU0 explicitly released.
No Rust compile or original60/411 suites were replayed. See
ACTUAL-CONTROLLED-42-AND-ABI-CURSOR.json. Independent actual-result acceptance
and current production/fullcrate/link/native gates remain open. Earlier UNRUN
descriptions below are retained preparation history.

Latest actual result: Source22 Rust object compiled PASS on its first actual
compiler invocation, object3032B/fbd48780, result8f485564. Original root CPU7
inheritance gate failurede8297fa and the subsequent pre-Python taskset CLI
argument refusal are retained; neither started a compiler. The data-only
successor changed only capture/result names, used the same recipe814812d6 and
unchanged runtime/function sources, and launched with explicit taskset -c 0.
CPU0 was released. Current retained-object C-only suffix is READY916bde9d /
recipe50ca68c9 / runner9e291cc4; no C fixture has run. See
ACTUAL-COMPILE-AND-NEXT-CHECK-CURSOR.json. Source-only/unstarted text below is
retained preparation history; production/default/native gates remain open.

Source22 isolates reference acquisition from Source21's unresolved pending-state,
status, alias and external HELD contracts. No compiler or fixture command has run.
Canonical sources, accepted Source20/21 objects and evidence, runtime ownership,
the imminent process-only action and quarantined native state remain untouched.

The minimal current patch is MINIMAL-PRODUCTION-LOOKUP.CURRENT-DEFAULT-OFF.patch.
It changes only the selected Rust public find_thread's private helper selection,
adds one Rust leaf module, and adds declaration/type-check-only C under a candidate
macro in kernel/process.c. The public function remains
find_thread(int pid,int tid)->struct thread*. A non-NULL result owns exactly one
existing Thread.refcount edge, released by original thread_unlock. NULL owns no
edge, so existing NULL branches do not release one. No syscall errno, ptrace
disposition, pending lock or final-destructor callback is added here.

New internal ABI is explicit: process_find_thread_live_body_result_v2 accepts a
process_thread_try_hold_fn_v2 returning C int one/zero. One means acquisition of
one actual positive reference; zero means none. The existing void hold helper and
old process_find_thread_body_result signature remain unchanged. No cast/wrapper
pretends the old callback supplied a positive outcome. C declarations and static
type checks, Rust function-type binding and a negative void-callback C compile
are prepared. Both languages bind the genuine signed counter type/geometry.

process_try_hold_thread_live_v2 calls the genuine exited warning before its count
operation, then uses the selected AtomicI32/SeqCst domain. It accepts only positive
counts below MAX. Zero, negative and MAX return no edge; MAX-1 can safely reach MAX.
No internal HOLD code is collapsed into NULL: this versioned callback has only the
documented acquired/no-edge outcome, and adds no policy to existing callers.

The actual final release decrements to zero before destroy_thread obtains the
hash writer and detaches the node. A reader pins physical membership/storage until
that writer can run, including the process lifetime needed for PID comparison.
The new CAS either acquires before final-zero (then the final decrement cannot
destroy), or rejects after it. The old unconditional fetch_add can resurrect zero.
This is source/interleaving reasoning until the new regression passes, and still
is not a claim of an observed native failure or native repair qualification.

The v2 helper preserves first-pass exact-PID priority and PID==TID fallback. The
fallback pass excludes process-PID-equal candidates already tried in the first
pass. This addresses Source21's missing leader cases: for proc.pid==tid and
zero/MAX, the old candidate warns twice while rejecting; the new candidate warns
once. No failed node address is retained for deduplication. The existing published
process PID is immutable for the two-pass decision. A rejected candidate is not
read again, freed, cached or returned; only the next list link, captured under the
same reader before acquisition, advances traversal. Another eligible fallback
node can still be acquired after an exact candidate rejects. Ordinary positive
exact-PID preference and traversal order stay intact.

Selected public consumer cohort

EXACT-LOOKUP-CALLER-COHORT-AND-LIFETIME.json contains only this symbol's selected
consumer rows and exact reference/destruction bodies, with source hashes. Mention
counts are extraction aids, never a proof of balanced ownership or coverage.

| Selected route | Existing NULL branch | Existing successful ownership route |
| --- | --- | --- |
| syscall_policy ptrace poke/peek user/text, get/set registers, FP/regset, eventmsg, siginfo, options, attach/detach and wakeup | Existing ESRCH branch returns without a release. | Original unlock_thread provider releases the lookup edge after synchronous work and on actual selected failure branches. Candidate provider tuples retain their current identities; no ptrace callback behavior changes. |
| arch_ptrace_prctl_body_result via original architecture find bridge | Existing ESRCH before reading target state. | Existing thread unlock after operation and explicit provider-failure exits. |
| host_wake_syscall_result via host_find_thread_result/raw bridge | Existing EINVAL plus missing-target log. | Existing wake/log then host_thread_unlock_result. |
| host remote-page-fault dispatch via same bridge | Existing missing-target log and EINVAL dispatch. | Current-thread case and actual complete provider tuple release after dispatch/defer/wakeup; allocation failure releases before ENOMEM. Missing-provider internal branches are not claimed as generally reference-safe. |
| sched affinity and setter direct lookups via sched_find_thread_bridge | Existing ESRCH on zero return. | Existing operation/error paths release the acquired edge; setters relookup after permission/usercopy where their existing flow requires it. |
| sched_select_thread foreign-thread branch | Existing ESRCH on zero return. | It currently releases immediately and returns the pointer as an unowned value. Its getter consumers remain a separate concrete defect, below. |

Separate consumer defect: sched_select_thread calls thread_unlock before returning
the foreign pointer. sched_getparam_body_result then forms/copies its sched_param;
sched_getscheduler_body_result reads its policy; sched_rr_get_interval_body_result
also reads policy. Those reads are not protected by the released lookup edge.
The lookup repair does not silently claim to solve them, return a different edge
count, or change their API. Root has been notified for an independent source lane.
This blocks broad caller-lifetime acceptance, not compilation/ABI qualification of
the isolated acquisition fix. Current setter flows that relookup remain distinct.

Prepared executable prefix

COMPILE-PREFIX.READY.NOT-GRANTED.json freezes the first ordinary compile only:
the real new leaf module and exact selected public wrapper (export renamed solely
inside the fixture), genuine selected offsets/aliases/warning predicate/hash
arithmetic, and the candidate cfg. No pending lifecycle body is recompiled.
The full four-command source-only tuple compiles that object, links the genuine
C header consumer with accepted Source21 objectd801 as a reference, runs42 new
checks, then deliberately compiles an old void callback against the v2 type and
requires the precise incompatible-pointer-types rejection. Source21's60-case
suite and Source20's411-case suite are not replayed.

Prepared cases:24 ordinary positive parity comparisons,12 missing exact-PID
zero/negative/MAX fallback cases, two final-edge drops during the original warning,
two exact-PID/fallback-priority list shapes, and two explicit new callback outcome
cases. ABI12 plus retained Source21 ABI20 are checked against genuine headers.
Zero rejected candidates produce no acquired pointer and no release. Controlled
retained-object comparisons deliberately expose the previously untested duplicate
warning case; they do not revise Source21's accepted original60 results.

Fresh root grant and resource admission are required for any prefix/suffix. Stop
first unexpected result and preserve raw streams/joins. If root first grants the
compile prefix, bind its resulting object and prepare a suffix; do not rerun the
successful compile or use the original full-runner output root for replay.

Production prefix and remaining gates

PRODUCTION-PREFIX.NOT-GRANTED.json records the exact build-system flags source,
new cfg/macro delta, unchanged public ABI, and actual private patch. Its fullcrate
and selected C prefix awaits root's current coherent composition and original
compiler argv binding. This worker does not invent current native/generated
configuration, copy an older generated profile into a production claim, or
execute the source-only build plan. The immediate exact executable prefix is the
genuine-layout compile above. Central integration then qualifies the actual
current fullcrate, process.c compiler/type checks, selected/default link and native
lookup/release behavior under their real grants. Selector remains OFF meanwhile.
No source/ABI/controlled result claims whole-file closure, C retirement, scheduler
consumer repair, pending lifecycle selection or native acceptance.
