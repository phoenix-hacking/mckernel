/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"



#include <process_helpers.h>
#include "VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
static void old_void_hold(void *thread) { (void)thread; }
/* Expected compile failure: old void ABI cannot supply acquisition outcome. */
process_thread_try_hold_fn_v2 f02_reject_void_callback = old_void_hold;
