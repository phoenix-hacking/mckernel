/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"



#include <process_helpers.h>
#include "VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
extern struct thread *f02_public_find_thread_candidate_v2(int,int);
extern struct thread *f03_find_thread_pending_live_v1(int,int);
extern const unsigned long f02_lookup_Rust_ABI[12],f03_integration_Rust_ABI[20];
extern int printf(const char *,...);extern int dprintf(int,const char *,...);extern void abort(void);
#define require(v) do{if(!(v)){dprintf(2,"FAIL positive lookup line=%d expression=%s\n",__LINE__,#v);abort();}}while(0)
static struct thread target,other;
static struct process process,other_process;
static struct thread_hash hash;
static struct resource_set resources;
static struct cpu_local_var cpu;
static int held,locks,unlocks,warnings,drop_before,drop_in_warning,warning_drops,try_calls,return_edge;
static unsigned long node_identity;
struct cpu_local_var *get_this_cpu_local_var(void){return &cpu;}
void __mcs_rwlock_reader_lock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[101%HASH_SIZE]&&!held&&node);require(!((unsigned long)node%__alignof__(*node)));
 held=1;locks++;node_identity=(unsigned long)node;*(unsigned long *)node=0x2ab7;
 if(drop_before)target.refcount.counter=0;
}
void __mcs_rwlock_reader_unlock(struct mcs_rwlock_lock *lock,struct mcs_rwlock_node_irqsave *node){
 require(lock==&hash.lock[101%HASH_SIZE]&&held&&(unsigned long)node==node_identity);
 require(*(unsigned long *)node==0x2ab7);held=0;unlocks++;node_identity=0;
}
void process_mcs_reader_lock_bridge(unsigned long lock,void *node){
 __mcs_rwlock_reader_lock((struct mcs_rwlock_lock *)lock,node);
}
void process_mcs_reader_unlock_bridge(unsigned long lock,void *node){
 __mcs_rwlock_reader_unlock((struct mcs_rwlock_lock *)lock,node);
}
void process_hold_thread_warn_bridge(void *thread){
 struct thread *candidate=thread;require(held&&candidate->status==PS_EXITED);warnings++;
 if(drop_in_warning&&!warning_drops&&candidate==&target){require(target.refcount.counter==1);target.refcount.counter=0;warning_drops++;}
}
static void reset(void){
 __builtin_memset(&target,0,sizeof(target));__builtin_memset(&other,0,sizeof(other));
 __builtin_memset(&process,0,sizeof(process));__builtin_memset(&other_process,0,sizeof(other_process));
 __builtin_memset(&hash,0,sizeof(hash));__builtin_memset(&resources,0,sizeof(resources));__builtin_memset(&cpu,0,sizeof(cpu));
 target.tid=101;target.proc=&process;target.refcount.counter=1;process.pid=100;
 other.tid=101;other.proc=&other_process;other.refcount.counter=1;other_process.pid=101;
 cpu.resource_set=&resources;resources.thread_hash=&hash;
 struct list_head *head=&hash.list[101%HASH_SIZE];head->next=head->prev=&target.hash_list;
 target.hash_list.next=target.hash_list.prev=head;
 held=locks=unlocks=warnings=drop_before=drop_in_warning=warning_drops=try_calls=return_edge=0;node_identity=0;
}
static void release_result(struct thread *thread){require(thread&&!held&&thread->refcount.counter>0);thread->refcount.counter--;}
static void add_second(void){
 struct list_head *head=&hash.list[101%HASH_SIZE];
 target.hash_list.next=&other.hash_list;other.hash_list.prev=&target.hash_list;
 other.hash_list.next=head;head->prev=&other.hash_list;
}
static int controlled_try_hold(void *raw){
 struct thread *thread=raw;require(held&&thread==&target);try_calls++;
 if(return_edge){require(thread->refcount.counter>0);thread->refcount.counter++;return 1;}
 return 0;
}
static process_thread_try_hold_fn_v2 const genuine_positive_callback=controlled_try_hold;
static void geometry(void){
 const unsigned long actual12[12]={sizeof(struct process_find_thread_offsets),__alignof__(struct process_find_thread_offsets),__builtin_offsetof(struct process_find_thread_offsets,thread_hash_list_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_tid_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_proc_offset),__builtin_offsetof(struct process_find_thread_offsets,proc_pid_offset),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),__builtin_offsetof(struct thread,refcount),sizeof(int),sizeof(process_thread_try_hold_fn_v2),sizeof(struct mcs_rwlock_node_irqsave)};
 const unsigned long actual20[20]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,hash_list),__builtin_offsetof(struct thread,refcount),__builtin_offsetof(ihk_atomic_t,counter),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),sizeof(struct thread_hash),__builtin_offsetof(struct thread_hash,lock),sizeof(struct resource_set),__builtin_offsetof(struct resource_set,thread_hash),sizeof(struct cpu_local_var),__builtin_offsetof(struct cpu_local_var,resource_set),sizeof(struct process),__builtin_offsetof(struct process,pid),2*sizeof(long),sizeof(long),2*sizeof(void *),3*sizeof(int),HASH_SIZE};
 require(!memcmp(actual12,f02_lookup_Rust_ABI,sizeof(actual12)));
 require(!memcmp(actual20,f03_integration_Rust_ABI,sizeof(actual20)));
}
int main(void){
 geometry();unsigned positive_cases=0,failed_fallback_cases=0,warning_race_cases=0,priority_cases=0,callback_cases=0;
 const int pids[4]={0,100,101,999};const int counts[3]={1,2,2147483646};
 for(int p=0;p<4;p++)for(int c=0;c<3;c++)for(int exited=0;exited<2;exited++){
  int expected_found=pids[p]!=999;int old_warning,old_count;
  reset();target.refcount.counter=counts[c];target.status=exited?PS_EXITED:PS_TRACED;
  struct thread *old=f03_find_thread_pending_live_v1(pids[p],101);
  require(old==(expected_found?&target:NULL));old_warning=warnings;old_count=target.refcount.counter;
  if(old)release_result(old);
  reset();target.refcount.counter=counts[c];target.status=exited?PS_EXITED:PS_TRACED;
  struct thread *now=f02_public_find_thread_candidate_v2(pids[p],101);
  require(now==(expected_found?&target:NULL)&&warnings==old_warning&&target.refcount.counter==old_count);
  require(locks==1&&unlocks==1&&!held&&warnings==(expected_found&&exited));
  if(now)release_result(now);require(target.refcount.counter==counts[c]);positive_cases++;
 }
 const int rejected[3]={-1,0,2147483647};
 for(int c=0;c<3;c++)for(int exited=0;exited<2;exited++)for(int before=0;before<2;before++){
  reset();process.pid=101;target.refcount.counter=rejected[c];target.status=exited?PS_EXITED:PS_TRACED;drop_before=before;
  require(!f03_find_thread_pending_live_v1(101,101));
  require(warnings==(exited?2:0)); /* Retain the actual missing Source21 fallback behavior. */
  reset();process.pid=101;target.refcount.counter=rejected[c];target.status=exited?PS_EXITED:PS_TRACED;drop_before=before;
  require(!f02_public_find_thread_candidate_v2(101,101));
  require(warnings==exited&&target.refcount.counter==(before?0:rejected[c]));
  require(locks==1&&unlocks==1&&!held);failed_fallback_cases++;
 }
 for(int leader=0;leader<2;leader++){
  reset();process.pid=leader?101:100;target.status=PS_EXITED;drop_in_warning=1;
  require(!f02_public_find_thread_candidate_v2(101,101));
  require(warnings==1&&warning_drops==1&&target.refcount.counter==0&&!held);
  warning_race_cases++;
 }
 /* Exact PID priority remains above first-in-list fallback. A rejected exact
  * candidate is attempted once; a different eligible fallback may still acquire. */
 for(int exact_live=0;exact_live<2;exact_live++){
  reset();add_second();target.status=other.status=PS_EXITED;other.refcount.counter=exact_live?1:0;
  struct thread *found=f02_public_find_thread_candidate_v2(101,101);
  require(found==(exact_live?&other:&target));require(warnings==(exact_live?1:2));
  require(target.refcount.counter==(exact_live?1:2)&&other.refcount.counter==(exact_live?2:0));
  release_result(found);priority_cases++;
 }
 const struct process_find_thread_offsets offsets={__builtin_offsetof(struct thread,hash_list),__builtin_offsetof(struct thread,tid),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct process,pid)};
 for(int acquire=0;acquire<2;acquire++){
  reset();return_edge=acquire;struct mcs_rwlock_node_irqsave node;
  void *found=process_find_thread_live_body_result_v2(&hash.list[101%HASH_SIZE],(unsigned long)&hash.lock[101%HASH_SIZE],&node,0,101,&offsets,process_mcs_reader_lock_bridge,process_mcs_reader_unlock_bridge,genuine_positive_callback);
  require(found==(acquire?&target:NULL)&&try_calls==1&&target.refcount.counter==1+acquire&&!held);
  if(found)release_result(found);callback_cases++;
 }
 require(positive_cases==24&&failed_fallback_cases==12&&warning_race_cases==2&&priority_cases==2&&callback_cases==2);
 printf("PASS lookup repair positive24 rejectedFallback12 warningRace2 priority2 callback2 ABI12 reusedABI20 controlled-only no-native-credit\n");return 0;
}
