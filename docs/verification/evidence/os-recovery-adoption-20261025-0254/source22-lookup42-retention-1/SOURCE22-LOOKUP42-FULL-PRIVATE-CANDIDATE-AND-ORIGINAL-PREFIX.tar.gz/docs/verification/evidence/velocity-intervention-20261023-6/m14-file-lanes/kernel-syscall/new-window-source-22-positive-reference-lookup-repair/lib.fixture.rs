// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#![allow(dead_code,unused_imports)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
use core::ffi::c_void;use core::mem::{offset_of,size_of,align_of,MaybeUninit};
use core::ptr::null_mut;
use abi::{AbiListHead,CInt,CULong,CpuLocalVar,Process,Thread,PROCESS_HASH_SIZE};
mod lock_helpers {
 use crate::abi::CULong;
 #[repr(C,align(64))] pub struct McsRwlockNodeIrqsave{irqsave:CULong}
}
use lock_helpers::McsRwlockNodeIrqsave;
include!("GENUINE-PARENT-DECLARATIONS.fixture.rs.inc");
#[path="positive_reference_lookup.rs"] mod f02_positive_reference_lookup;
include!("PUBLIC-FIND-THREAD.REUSED-WRAPPER.rs.inc");
#[no_mangle]
pub static f02_lookup_Rust_ABI:[usize;12]=[
 size_of::<ProcessFindThreadOffsets>(),align_of::<ProcessFindThreadOffsets>(),
 offset_of!(ProcessFindThreadOffsets,thread_hash_list_offset),
 offset_of!(ProcessFindThreadOffsets,thread_tid_offset),
 offset_of!(ProcessFindThreadOffsets,thread_proc_offset),
 offset_of!(ProcessFindThreadOffsets,proc_pid_offset),
 size_of::<abi::IhkAtomic>(),align_of::<abi::IhkAtomic>(),
 offset_of!(Thread,refcount),size_of::<CInt>(),
 size_of::<f02_positive_reference_lookup::ProcessThreadTryHoldFnV2>(),
 size_of::<McsRwlockNodeIrqsave>(),
];
