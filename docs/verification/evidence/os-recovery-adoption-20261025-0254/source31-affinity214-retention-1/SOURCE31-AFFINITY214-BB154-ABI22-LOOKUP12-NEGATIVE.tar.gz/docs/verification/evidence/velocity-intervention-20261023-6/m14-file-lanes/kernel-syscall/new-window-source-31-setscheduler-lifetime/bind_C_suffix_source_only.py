"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bind actual new object and retained lookup to three C-only controlled commands.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
 with (ROOT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
prefix=json.loads((ROOT/'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json').read_text());obj=prefix['actual_object'];assert pin(obj['path'])==obj
assert obj['sha256']=='bb154063deeaacf31413acc0b440669574bdb84700ee02e725ae50b75f846f05'
proposed=json.loads((ROOT/'EXACT-SOURCE31-C-SUFFIX.PROVISIONAL-NOT-GRANTED.json').read_text())
compile_recipe=json.loads((ROOT/'EXACT-SOURCE31-COMPILE-ONLY.NOT-GRANTED.json').read_text())
inputs={row['path']:row for row in compile_recipe['inputs']+compile_recipe['sources']}
for p in [Path(obj['path']),Path(proposed['reused_lookup_object']['path']),ROOT/'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json',ROOT/'EXACT-SOURCE31-COMPILE-ONLY.NOT-GRANTED.json',Path('/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc'),BASE/'new-window-source-22-positive-reference-lookup-repair/VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc']:
 inputs[str(p)]=pin(p)
recipe=dict(scope=SCOPE,status='ACTUAL_RETAINED_RUST_OBJECT_SOURCE31_C_SUFFIX_SOURCE_ONLY_REQUIRES_REVIEW_ROOT_GRANT',commands=proposed['commands'],inputs=list(inputs.values()),sources=[],canonical_origins=[],header_bindings=compile_recipe['header_bindings'],tools=compile_recipe['tools'],fixture_tools={'cc1':pin(Path('/usr/lib/gcc/x86_64-linux-gnu/9/cc1'))},retained_new_Rust_object=obj,reused_positive_lookup_object=proposed['reused_lookup_object'],actual_compiler_receipt=pin(ROOT/'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json'),oracle_expected_stdout='PASS affinity retained-edge comparisons=214 calls=428 overflow_repaired=24 ABI22+reusedLookup12 no-native-credit\n',warning_ABI='Only explicitly versioned diagnostic-only void callback is admissible; old int hold intentionally rejected. No acquisition success is inferred from warning.',scope_limit='Actual controlled old/new body/ABI only; mask synchronization/setaffinity/current Process/global positive admission/native/default/fullcrate integration remain open.')
name='EXACT-SOURCE31-C-SUFFIX.FROZEN-NOT-GRANTED.json';write(name,recipe);sha=pin(ROOT/name)['sha256']
prototype=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/follow-on-source-only/run_Source30_followon_once.NOT-GRANTED.py'
runner=prototype.read_text().replace('Source30 actual dfba retained-C partial/four static observer suffix; fresh exact ROOT grant required.','Source31 actual retained-object controlled C ABI/lifetime suffix; exact ROOT grant required.')
runner=runner.replace("RECIPE = ROOT / 'EXACT-SELECTED-C-ABI-STRICT-PARTIAL.FROZEN-NOT-GRANTED.json'","RECIPE = ROOT / '"+name+"'").replace("RECIPE_SHA = '5da80ee53f3ba4d42048322336916fdb34259946db435440a5f6232f8554bb2e'","RECIPE_SHA = '"+sha+"'")
runner=runner.replace("ROOT / 'ROOT-EXACT-SOURCE30-FOLLOWON-GRANT.json'","ROOT / 'ROOT-EXACT-SOURCE31-C-SUFFIX-GRANT.json'")
runner=runner.replace("for directory in recipe['absent_include_namespaces']:","for directory in recipe.get('absent_include_namespaces', []):")
runner=runner.replace("OUTPUT = ROOT / 'output-1'","OUTPUT = ROOT / 'fixture-suffix-output-1'").replace("CAPTURE = ROOT / 'actual-parity-capture-first-1'","CAPTURE = ROOT / 'actual-affinity-C-suffix-capture-first-1'").replace("RESULT = ROOT / 'ACTUAL-SOURCE30-FOLLOWON-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE31-C-SUFFIX-FIRST-RESULT.json'")
runner=runner.replace("authority='Exact durable ROOT Source30 follow-on grant: one actual-dfba retained-four-C partial link and four static ELF observers only; no C/Rust compiler, fixture, runtime, native or default action.'","authority='Exact durable ROOT Source31 C-only controlled fixture link/run plus expected old-hold ABI compile rejection; no Rust/fullcrate/native/default actions.'")
runner=runner.replace("if (joined['returncode'] != 0 or not joined['direct_child_joined']", "if (joined['returncode'] != command.get('expected_returncode', 0) or not joined['direct_child_joined']")
needle="                raise RuntimeError('first unexpected result; STOP preserve prefix, no retry')\n"
addition=needle+"""            for expected in command.get('expected_stderr_contains', []):
                stderr = Path(joined['captures']['stderr']['path']).read_text()
                if expected not in stderr:
                    raise RuntimeError('expected negative ABI diagnostic absent: ' + expected)
            if command['name'] == '02-controlled214pairs428calls-affinity-lifetime':
                stdout = Path(joined['captures']['stdout']['path']).read_text()
                if stdout != recipe['oracle_expected_stdout']:
                    raise RuntimeError('controlled old/new lifetime oracle output differs')
"""
assert runner.count(needle)==1;runner=runner.replace(needle,addition)
runner=runner.replace("status='PASS_SELECTED_C_ABI_AND_RETAINED_OBJECT_STRICT_PARTIAL_ONLY'","status='PASS_SOURCE31_CONTROLLED214_PAIRS_ABI22_REUSED_LOOKUP12_AND_NEGATIVE_CALLBACK_ABI'")
runner=runner.replace("recipe=pin(RECIPE), C_syntax_only_commands=0, Rust_compiler_commands=0,\n                      linker_commands=1, static_ELF_observer_commands=4, fixture_commands=0,\n                      fullcrate_compilations=0, actual_partial=pin(OUTPUT / 'CPU37.partial.o'),\n                      reused_Rust_object=recipe['new_Rust_object'], retained_C_objects=recipe['selected_C_objects']", "recipe=pin(RECIPE), C_link_commands=1, Rust_compiler_commands=0,\n                      negative_C_ABI_commands=1, fixture_commands=1, fullcrate_compilations=0,\n                      retained_Rust=recipe['retained_new_Rust_object'],\n                      retained_lookup=recipe['reused_positive_lookup_object'],\n                      actual_fixture=pin(OUTPUT / 'affinity-parity'), controlled_pairs=214,\n                      controlled_calls=428, repaired_overflow_cases=24, ABI_words=22, reused_ABI_words=12")
runner=runner.replace('missing exact durable ROOT source30 follow-on grant','missing exact durable ROOT source31 C suffix grant')
with (ROOT/'run_Source31_C_suffix_once.NOT-GRANTED.py').open('x') as f:f.write(runner)
ready=dict(scope=SCOPE,status='SOURCE_ONLY_SOURCE31_C_SUFFIX_REQUIRES_INDEPENDENT_REVIEW_ROOT_GRANT',recipe=pin(ROOT/name),runner=pin(ROOT/'run_Source31_C_suffix_once.NOT-GRANTED.py'),actual_Rust=obj,retained_lookup=proposed['reused_lookup_object'],actual_compiler_receipt=pin(ROOT/'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json'),driver=pin(ROOT/'driver.c'),negative_ABI=pin(ROOT/'NEGATIVE-OLD-HOLD-AS-WARNING.c'),controlled_pairs=214,calls=428,ABI22=True,reusedLookup12=True,actual_C_commands=0,native=False,default=False)
write('READY-SOURCE31-C-SUFFIX.NOT-GRANTED.json',ready)
fields=json.loads((ROOT/'ROOT-EXACT-SOURCE31-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text());fields.update(ready=pin(ROOT/'READY-SOURCE31-C-SUFFIX.NOT-GRANTED.json'),recipe=ready['recipe'],runner=ready['runner'],compiler_commands=0,C_suffix_commands=3);fields['launch_argv'][-2]=ready['runner']['path'];fields['launch_argv'][-1]=ready['runner']['sha256'];fields.pop('no_C_link_fixture_execution_native_or_default',None);fields.pop('compiler_commands',None);fields.update(Rust_compiler_commands=0,C_compiler_commands=2,controlled_fixture_executions=1,no_fullcrate_native_default_or_canonical_actions=True);write('ROOT-EXACT-SOURCE31-C-SUFFIX-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
print(json.dumps(dict(READY=fields['ready'],recipe=ready['recipe'],runner=ready['runner'],retained_Rust=obj)))
