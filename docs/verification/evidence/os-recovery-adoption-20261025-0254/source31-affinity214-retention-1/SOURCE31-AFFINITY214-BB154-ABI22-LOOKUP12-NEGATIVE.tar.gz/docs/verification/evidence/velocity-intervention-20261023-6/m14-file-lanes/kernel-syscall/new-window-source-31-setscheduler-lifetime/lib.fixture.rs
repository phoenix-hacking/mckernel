// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust/abi.rs"] mod abi;
use core::ffi::c_void;
use core::ptr::read_volatile;
use core::sync::atomic::{AtomicI32,Ordering};
use abi::{CInt,CLong,CULong,SizeT,IhkAtomic};
include!("ACTUAL-AFFINITY-DECLARATIONS.rs.inc");
include!("ACTUAL-AFFINITY-PARENT-HELPERS.rs.inc");
include!("ACTUAL-OLD-AFFINITY-BODY.rs.inc");
include!("ACTUAL-LEGACY-ATOMIC-AND-WARNING.rs.inc");
#[path="f03_getaffinity_retained_v2.rs"] mod f03_getaffinity_retained_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f31_affinity_Rust_ABI:[usize;22]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),
 offset_of!(abi::Thread,refcount),offset_of!(abi::Thread,cpu_set),offset_of!(abi::Thread,status),
 size_of::<abi::Process>(),offset_of!(abi::Process,ruid),offset_of!(abi::Process,euid),
 size_of::<abi::CpuSet>(),align_of::<abi::CpuSet>(),
 size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),
 size_of::<CInt>(),size_of::<CLong>(),align_of::<CLong>(),
 size_of::<Option<SchedFindThreadFn>>(),size_of::<Option<SchedThreadUnlockFn>>(),
 size_of::<Option<SchedHoldThreadFn>>(),size_of::<Option<SchedReleaseThreadFn>>(),
 size_of::<Option<SchedCopyToUserFn>>(),size_of::<Option<f03_getaffinity_retained_v2::SchedAffinityWarningOnlyFnV2>>(),
];
