"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Freeze one focused Rust compile prefix and proposed controlled C suffix; execute neither.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
OLD=BASE/'new-window-source-24-scheduler-setter-lifetime'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
 with (ROOT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
old=json.loads((OLD/'EXACT-COMPILE-ONLY-COMMAND.NOT-GRANTED.json').read_text())
command=json.loads(json.dumps(old['commands'][0]));argv=command['argv'];argv[argv.index('--crate-name')+1]='affinity_retained_lifetime'
i=argv.index('--cfg');del argv[i:i+2]
argv.insert(i,'overflow-checks=off');argv.insert(i,'-C')
for j,x in enumerate(argv):
 if x.startswith('--emit=obj='):argv[j]='--emit=obj='+str(ROOT/'output-1/candidate.o')
argv[-1]=str(ROOT/'lib.fixture.rs')
command.update(name='00-affinity-retained-v2-and-actual-old-AtomicI32-body-Rust-object',cwd=str(ROOT),purpose=SCOPE+' Compile new versioned retained-affinity getter and exact extracted original getter/ref-inc functions with genuine Source30abi only; no C fixture, setscheduler replay, fullcrate, runtime or native.')
inputs=[pin(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ['.rs','.inc','.json','.patch','.c']]
abi=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust/abi.rs'
recipe=dict(scope=SCOPE,status='SOURCE_ONLY_SOURCE31_COMPILE_PREFIX_NOT_GRANTED',commands=[command],inputs=inputs,sources=[pin(abi)],canonical_origins=[],header_bindings=old['header_bindings'],tools=old['tools'],fixture_tools={},requirements=['One exact ROOT ordinary CPU0 onejobAS2GiB finite-profile compile-only grant; no C fixture execution before independent unsafe/ABI review.','Actual Source22 positive lookup object reused only later in controlled fixture; no42/60/411/prior333 replay.','Fixture helper extraction is controlled-body evidence, not a real fullcrate or kernel/native ABI acceptance.','Preserve exact warned-state diagnostics through explicitly versioned diagnostic-only callback; no old hold cast or hidden acquisition.'])
name='EXACT-SOURCE31-COMPILE-ONLY.NOT-GRANTED.json';write(name,recipe);sha=pin(ROOT/name)['sha256']
prototype=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/run_real77module_linkage_compile_once.NOT-GRANTED.py'
runner=prototype.read_text().replace('Source30 genuine selected full-kernel explicit-internal logger compile-only prefix; fresh exact ROOT grant required.','Source31 focused real-ABI/extracted-body affinity lifetime compile-only prefix; exact ROOT grant required.')
runner=runner.replace("RECIPE = ROOT / 'EXACT-REAL77MODULE-LOGGER-INTERNAL-COMPILE.NOT-GRANTED.json'","RECIPE = ROOT / '"+name+"'").replace("RECIPE_SHA = '255b55afde2aeed6c02f86e6b24ae34b67bed22c37ba46a623eb86a87982e10a'","RECIPE_SHA = '"+sha+"'")
runner=runner.replace("ROOT / 'ROOT-EXACT-SOURCE30-COMPILE-GRANT.json'","ROOT / 'ROOT-EXACT-SOURCE31-COMPILE-GRANT.json'").replace("RESULT = ROOT / 'ACTUAL-SOURCE30-REAL77MODULE-COMPILE-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json'")
runner=runner.replace("status='PASS_REAL_SELECTED_KERNEL_CRATE_COMPILE_ONLY'","status='PASS_FOCUSED_SOURCE31_AFFINITY_LIFETIME_COMPILE_ONLY'").replace('fullcrate_compilations=1,','fullcrate_compilations=0,')
runner=runner.replace("authority='Exact durable ROOT Source30 one real77module Rust compiler grant only; no C, link, observer, fixture, runtime, native or default action.'","authority='Exact durable ROOT Source31 focused Rust fixture-body object compile only; no C/link/executable fixture/fullcrate/native/default action.'").replace('missing exact durable ROOT source30 compile grant','missing exact durable ROOT source31 compile grant')
with (ROOT/'run_Source31_compile_once.NOT-GRANTED.py').open('x') as f:f.write(runner)
ready=dict(scope=SCOPE,status='SOURCE_ONLY_COMPILE_PREFIX_READY_FOR_ROOT_GRANT',recipe=pin(ROOT/name),runner=pin(ROOT/'run_Source31_compile_once.NOT-GRANTED.py'),source=pin(ROOT/'f03_getaffinity_retained_v2.rs'),fixture=pin(ROOT/'lib.fixture.rs'),controlled_C_driver=pin(ROOT/'driver.c'),private_patch=pin(ROOT/'GETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch'),reuse_and_scope=pin(ROOT/'EXACT-SETSCHEDULER-REUSE-AND-AFFINITY-OWNERSHIP.SOURCE.json'),actual_compiles=0,default=False,native=False)
write('READY-SOURCE31-COMPILE-PREFIX.NOT-GRANTED.json',ready)
bootstrap="import os,sys,hashlib; p=sys.argv[1]; fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC); raw=os.read(fd,1048576); st=os.fstat(fd); assert len(raw)==st.st_size and hashlib.sha256(raw).hexdigest()==sys.argv[2], 'source FD binding mismatch'; ns={'__name__':'__main__','__file__':p}; exec(compile(raw,p,'exec'),ns)"
profile=json.loads((BASE/'new-window-source-30-fullcrate-logger-internal-linkage/ROOT-EXACT-SOURCE30-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text())['profile']
fields=dict(scope=SCOPE,status='PREPARED_FIELDS_NOT_A_GRANT',ready=pin(ROOT/'READY-SOURCE31-COMPILE-PREFIX.NOT-GRANTED.json'),recipe=ready['recipe'],runner=ready['runner'],launch_argv=['/usr/bin/taskset','-c','0','/home/holden/anaconda3/bin/python3','-c',bootstrap,ready['runner']['path'],ready['runner']['sha256']],execution_count=1,profile=profile,compiler_commands=1,no_C_link_fixture_execution_native_or_default=True)
write('ROOT-EXACT-SOURCE31-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
# C suffix remains a proposal until real retained Rust object and independent review.
prior=json.loads((OLD/'EXACT-SETPARAM-C-SUFFIX.NOT-GRANTED.json').read_text())['commands'][0]
link=prior['argv'][:]
for i,x in enumerate(link):
 if x==str(OLD/'driver.c'):link[i]=str(ROOT/'driver.c')
 if x==str(OLD/'output-1/candidate.o'):link[i]=str(ROOT/'output-1/candidate.o')
link[link.index('-o')+1]=str(ROOT/'fixture-suffix-output-1/affinity-parity')
negative=link[:];negative=negative[:negative.index(str(ROOT/'driver.c'))]+['-fsyntax-only',str(ROOT/'NEGATIVE-OLD-HOLD-AS-WARNING.c')]
suffix=dict(scope=SCOPE,status='SOURCE_ONLY_C_SUFFIX_PENDING_ACTUAL_RUST_OBJECT_REVIEW_GRANT',commands=[dict(name='01-genuine-ABI22-and-reused-positiveLookup12-C-link',argv=link,cwd=str(ROOT),purpose=SCOPE+' Compile/link controlled real-struct old/new allocation-lifetime fixture only; no kernel/runtime selection.'),dict(name='02-controlled214pairs428calls-affinity-lifetime',argv=[str(ROOT/'fixture-suffix-output-1/affinity-parity')],cwd=str(ROOT),purpose=SCOPE+' Controlled original/new compare214pairs incl signedMAX temporary-domain regression, last-owner release, warning counts, provider/error precedence and full-C-long highword results; no native acceptance.'),dict(name='03-reject-old-int-hold-as-new-void-diagnostic-only',argv=negative,cwd=str(ROOT),expected_returncode=1,expected_stderr_contains=['incompatible-pointer-types','rejected_old_hold'],purpose=SCOPE+' Expected compile rejection proves old int hold is not silently accepted as new diagnostic-only void callback.')],reused_lookup_object=pin(BASE/'new-window-source-22-positive-reference-lookup-repair/output-1/candidate.o'),new_Rust_object=dict(path=str(ROOT/'output-1/candidate.o'),sha256=None,status='PENDING_GENUINE_COMPILE_PREFIX'),genuine_C_header_bindings=old['header_bindings'],inputs=[pin(ROOT/'driver.c'),pin(ROOT/'VERSIONED-AFFINITY-ABI.C.inc'),pin(ROOT/'NEGATIVE-OLD-HOLD-AS-WARNING.c')],controlled_comparisons=214,expected_calls=428,source_expected_overflow_repairs=24,ABI_words=22,reused_lookup_ABI_words=12,native=False,default=False)
write('EXACT-SOURCE31-C-SUFFIX.PROVISIONAL-NOT-GRANTED.json',suffix)
print(json.dumps(dict(READY=fields['ready'],recipe=ready['recipe'],runner=ready['runner'],source_only=True)))
