/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <process_helpers.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-22-positive-reference-lookup-repair/VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
extern int printf(const char *, ...), dprintf(int,const char *, ...);
extern void abort(void), free(void *);
extern int posix_memalign(void **,size_t,size_t);
#define require(v) do { if (!(v)) { dprintf(2,"FAIL affinity lifecycle line=%d: %s\n",__LINE__,#v); abort(); } } while (0)
struct sched_syscall_offsets {
    size_t thread_proc_offset,thread_sched_param_offset,thread_sched_policy_offset;
    size_t thread_cpu_id_offset,thread_cpu_set_offset,proc_pid_offset;
    size_t proc_ruid_offset,proc_euid_offset,proc_cpu_set_offset;
};
typedef unsigned long (*sched_find_thread_fn_t)(int);
typedef void (*sched_thread_unlock_fn_t)(unsigned long);
typedef int (*sched_hold_thread_fn_t)(unsigned long);
typedef void (*sched_release_thread_fn_t)(unsigned long);
typedef long (*syscall_copy_to_user_fn_t)(unsigned long,const void *,size_t);
#include "VERSIONED-AFFINITY-ABI.C.inc"
extern long f31_original_getaffinity(int,size_t,unsigned long,unsigned long,size_t,int,
    const struct sched_syscall_offsets *,sched_find_thread_fn_t,sched_thread_unlock_fn_t,
    sched_hold_thread_fn_t,sched_release_thread_fn_t,syscall_copy_to_user_fn_t);
extern int process_ref_inc_direct_result(void *,unsigned long);
extern int process_hold_thread_warn_exited_result(int);
extern const unsigned long f31_affinity_Rust_ABI[22];
extern const unsigned long f02_lookup_Rust_ABI[12];
static const struct sched_syscall_offsets offsets={
    __builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),
    __builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,cpu_id),
    __builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct process,pid),
    __builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),
    __builtin_offsetof(struct process,cpu_set)};
static struct thread current;
static struct process current_process,target_process;
static struct thread *target;
static struct list_head head;
static struct mcs_rwlock_node_irqsave node;
static int hash_locked,writer_locked,is_new,holds,unlocks,releases,warnings,copies,finds,negative_seen;
static int copied_refcount,drop_hash_owner,retired,permission_denied,current_proc_null;
static long copy_result;
static cpu_set_t copied_mask;
static int refcount(struct thread *thread){return __atomic_load_n(&thread->refcount.counter,__ATOMIC_SEQ_CST);}
void process_hold_thread_warn_bridge(void *thread){
    require(thread==target||thread==&current);require(((struct thread *)thread)->status==PS_EXITED);
    warnings++;
}
static void reader_lock(unsigned long lock,void *storage){
    require(lock==(unsigned long)&head&&storage==&node&&!hash_locked&&!writer_locked);hash_locked=1;
}
static void reader_unlock(unsigned long lock,void *storage){
    require(lock==(unsigned long)&head&&storage==&node&&hash_locked);hash_locked=0;
}
static unsigned long find_target(int tid){
    finds++;struct process_find_thread_offsets geometry={
        __builtin_offsetof(struct thread,hash_list),__builtin_offsetof(struct thread,tid),
        __builtin_offsetof(struct thread,proc),__builtin_offsetof(struct process,pid)};
    return (unsigned long)process_find_thread_live_body_result_v2(&head,(unsigned long)&head,&node,
        0,tid,&geometry,reader_lock,reader_unlock,process_try_hold_thread_live_v2);
}
static void drop_reference(unsigned long address){
    struct thread *thread=(struct thread *)address;int old=__atomic_fetch_sub(&thread->refcount.counter,1,__ATOMIC_SEQ_CST);
    if(old==1&&thread==target){
        require(!hash_locked&&!writer_locked);writer_locked=1;
        head.next=head.prev=&head;target->hash_list.next=target->hash_list.prev=NULL;
        writer_locked=0;free(target);target=NULL;retired++;
    }
}
static void unlock_target(unsigned long address){unlocks++;drop_reference(address);}
static void release_target(unsigned long address){releases++;drop_reference(address);}
static int legacy_hold(unsigned long address){
    holds++;struct thread *thread=(struct thread *)address;
    if(process_hold_thread_warn_exited_result(thread->status))process_hold_thread_warn_bridge(thread);
    require(process_ref_inc_direct_result(thread,__builtin_offsetof(struct thread,refcount))==0);
    if(refcount(thread)<=0)negative_seen=1;
    return 0; /* Genuine old hold_thread deliberately returns zero after ignored result. */
}
static long copy_mask(unsigned long output,const void *source,size_t bytes){
    require(!hash_locked&&output==(unsigned long)&copied_mask);copies++;
    struct thread *thread=source==(const void *)&current.cpu_set?&current:target;
    require(thread&&source==(const void *)&thread->cpu_set);
    copied_refcount=refcount(thread);if(copied_refcount<=0)negative_seen=1;
    if(is_new)require(copied_refcount>0);
    if(drop_hash_owner&&thread==target){require(refcount(target)>=2);drop_reference((unsigned long)target);}
    if(copy_result>=0)memcpy(&copied_mask,source,bytes);
    return copy_result;
}
struct outcome {long result;int warnings,copies,finds,negative,final_count,retired,holds,unlocks,releases;cpu_set_t mask;};
static struct outcome execute(int modern,int tid,int initial,int status,long copy_status,size_t len,int nr_cpus,int missing,int drop,int deny,int null_proc){
    void *allocation=NULL;require(posix_memalign(&allocation,__alignof__(struct thread),sizeof(struct thread))==0);
    target=allocation;memset(target,0,sizeof(*target));memset(&current,0,sizeof(current));
    memset(&current_process,0,sizeof(current_process));memset(&target_process,0,sizeof(target_process));
    current.proc=&current_process;current.tid=100;current.status=status;current.refcount.counter=initial;
    current_process.pid=100;current_process.euid=77;target_process.pid=200;
    target_process.ruid=deny?88:77;target_process.euid=deny?99:77;
    target->proc=&target_process;target->tid=201;target->status=status;target->refcount.counter=initial;
    if(null_proc)current.proc=NULL;
    memset(&current.cpu_set,0x5a,sizeof(cpu_set_t));memset(&target->cpu_set,0x5a,sizeof(cpu_set_t));
    head.next=head.prev=&target->hash_list;target->hash_list.next=target->hash_list.prev=&head;
    hash_locked=writer_locked=holds=unlocks=releases=warnings=copies=finds=negative_seen=retired=0;
    copied_refcount=0;is_new=modern;copy_result=copy_status;drop_hash_owner=drop;permission_denied=deny;current_proc_null=null_proc;
    memset(&copied_mask,0,sizeof(copied_mask));
    sched_find_thread_fn_t find=(missing&8)?NULL:find_target;
    sched_thread_unlock_fn_t unlock=(missing&16)?NULL:unlock_target;
    sched_release_thread_fn_t release=(missing&2)?NULL:release_target;
    syscall_copy_to_user_fn_t copy=(missing&1)?NULL:copy_mask;
    long result=modern?sched_getaffinity_retained_v2(tid,len,(unsigned long)&copied_mask,(unsigned long)&current,sizeof(cpu_set_t),nr_cpus,&offsets,find,unlock,(missing&4)?NULL:sched_affinity_hold_warning_v2,release,copy):
        f31_original_getaffinity(tid,len,(unsigned long)&copied_mask,(unsigned long)&current,sizeof(cpu_set_t),nr_cpus,&offsets,find,unlock,(missing&4)?NULL:legacy_hold,release,copy);
    require(!hash_locked&&!writer_locked);
    struct outcome out={result,warnings,copies,finds,negative_seen,tid==0?refcount(&current):(target?refcount(target):0),retired,holds,unlocks,releases,copied_mask};
    if(target){head.next=head.prev=&head;free(target);target=NULL;}
    return out;
}
static unsigned long comparisons,overflow_repairs;
static void compare(int tid,int initial,int status,long copy_status,size_t len,int nr_cpus,int missing,int drop,int deny,int null_proc){
    struct outcome old=execute(0,tid,initial,status,copy_status,len,nr_cpus,missing,drop,deny,null_proc);
    struct outcome newer=execute(1,tid,initial,status,copy_status,len,nr_cpus,missing,drop,deny,null_proc);
    require(old.result==newer.result&&old.warnings==newer.warnings&&old.copies==newer.copies&&old.finds==newer.finds);
    require(old.final_count==newer.final_count&&old.retired==newer.retired&&!memcmp(&old.mask,&newer.mask,sizeof(cpu_set_t)));
    require(!newer.negative&&!newer.holds);
    if(old.negative){overflow_repairs++;require(initial==2147483647||(tid!=0&&initial==2147483646));}
    comparisons++;
}
static void abi(void){
    unsigned long actual[22]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,refcount),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct thread,status),sizeof(struct process),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),sizeof(cpu_set_t),__alignof__(cpu_set_t),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(int),sizeof(long),__alignof__(long),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(sched_hold_thread_fn_t),sizeof(sched_release_thread_fn_t),sizeof(syscall_copy_to_user_fn_t),sizeof(sched_affinity_warning_only_fn_v2)};
    require(!memcmp(actual,f31_affinity_Rust_ABI,sizeof(actual)));
    unsigned long lookup[12]={sizeof(struct process_find_thread_offsets),__alignof__(struct process_find_thread_offsets),__builtin_offsetof(struct process_find_thread_offsets,thread_hash_list_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_tid_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_proc_offset),__builtin_offsetof(struct process_find_thread_offsets,proc_pid_offset),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),__builtin_offsetof(struct thread,refcount),sizeof(int),sizeof(process_thread_try_hold_fn_v2),sizeof(struct mcs_rwlock_node_irqsave)};
    require(!memcmp(lookup,f02_lookup_Rust_ABI,sizeof(lookup)));
}
int main(void){
    abi();long statuses[]={-14,-(1L<<32),0,1,1L<<32,0x7fffffffffffffffL};
    int counts[]={1,2,2147483646,2147483647};int tids[]={0,201,-1};int states[]={PS_RUNNING,PS_EXITED};
    for(unsigned long c=0;c<4;c++)for(unsigned long t=0;t<3;t++)for(unsigned long s=0;s<2;s++)for(unsigned long r=0;r<6;r++)compare(tids[t],counts[c],states[s],statuses[r],sizeof(cpu_set_t),64,0,0,0,0);
    for(int missing=0;missing<32;missing++){compare(0,1,PS_EXITED,0,sizeof(cpu_set_t),64,missing,0,0,0);compare(201,1,PS_EXITED,0,sizeof(cpu_set_t),64,missing,0,0,0);}
    compare(201,1,PS_EXITED,0,sizeof(cpu_set_t),64,0,1,0,0);
    compare(201,1,PS_EXITED,-(1L<<32),sizeof(cpu_set_t),64,0,1,0,0);
    compare(201,1,PS_EXITED,0,sizeof(cpu_set_t),64,0,0,1,0);
    compare(201,1,PS_EXITED,0,sizeof(cpu_set_t),64,0,0,0,1);
    compare(0,1,PS_RUNNING,0,1,64,0,0,0,0);compare(201,1,PS_RUNNING,0,0,0,0,0,0,0);
    require(overflow_repairs>0);
    printf("PASS affinity retained-edge comparisons=%lu calls=%lu overflow_repaired=%lu ABI22+reusedLookup12 no-native-credit\n",comparisons,comparisons*2,overflow_repairs);return 0;
}
