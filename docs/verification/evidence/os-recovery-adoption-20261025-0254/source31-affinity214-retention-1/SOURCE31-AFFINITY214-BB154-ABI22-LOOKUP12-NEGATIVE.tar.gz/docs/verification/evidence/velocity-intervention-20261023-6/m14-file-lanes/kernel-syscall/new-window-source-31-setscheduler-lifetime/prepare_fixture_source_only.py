"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Extract actual selected bodies for a controlled lifetime fixture, never compile/run.
"""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SRC=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def function(text,name):
 m=re.search(r'(?:pub(?:\([^)]*\))? )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',text);assert m,name
 start=m.start();brace=text.index('{',m.end());depth=1;i=brace+1
 while depth:
  depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[start:i]
def write(name,text):
 with (ROOT/name).open('x') as f:f.write(text)
s=(SRC/'sched_helpers.rs').read_text();p=(SRC/'process_helpers.rs').read_text()
parents=['sched_affinity_permission_result','sched_getaffinity_len_result','sched_affinity_copy_len','sched_errno','sched_read_usize','sched_thread_proc','sched_proc_ruid','sched_proc_euid']
parent='\n\n'.join(function(s,n) for n in parents)+'\n'
old=function(s,'sched_affinity_select_thread')+'\n\n#[no_mangle]\n'+function(s,'sched_getaffinity_body_result').replace('fn sched_getaffinity_body_result(','fn f31_original_getaffinity(',1)+'\n'
ref=function(p,'process_ref_atomic_at')+'\n\n#[no_mangle]\n'+function(p,'process_ref_inc_direct_result')+'\n\n#[no_mangle]\n'+function(p,'process_hold_thread_warn_exited_result')+'\n'
write('ACTUAL-AFFINITY-PARENT-HELPERS.rs.inc',parent);write('ACTUAL-OLD-AFFINITY-BODY.rs.inc',old);write('ACTUAL-LEGACY-ATOMIC-AND-WARNING.rs.inc',ref)
# Exact existing callback aliases and actual immutable layout, with one new explicit
# diagnostic-only callback type owned by the versioned successor module.
start=s.index('pub struct SchedSyscallOffsets {');start=s.rfind('#[repr(C)]',0,start);end=s.index('\n}',start)+2
layout=s[start:end]
aliases='\n'.join(next(line for line in s.splitlines() if line.startswith('type '+name+' = ')) for name in ['SchedFindThreadFn','SchedThreadUnlockFn','SchedHoldThreadFn','SchedReleaseThreadFn','SchedCopyToUserFn'])
write('ACTUAL-AFFINITY-DECLARATIONS.rs.inc',layout+'\n'+aliases+'\nconst EINVAL:CInt=22;const EPERM:CInt=1;const ESRCH:CInt=3;const EFAULT:CInt=14;const PS_EXITED:CInt=0x10;\n')
fixture='''// '''+SCOPE+'''
#![no_std]
#[path="'''+str(SRC/'abi.rs')+'''"] mod abi;
use core::ffi::c_void;
use core::ptr::read_volatile;
use core::sync::atomic::{AtomicI32,Ordering};
use abi::{CInt,CLong,CULong,SizeT,IhkAtomic};
include!("ACTUAL-AFFINITY-DECLARATIONS.rs.inc");
include!("ACTUAL-AFFINITY-PARENT-HELPERS.rs.inc");
include!("ACTUAL-OLD-AFFINITY-BODY.rs.inc");
include!("ACTUAL-LEGACY-ATOMIC-AND-WARNING.rs.inc");
#[path="f03_getaffinity_retained_v2.rs"] mod f03_getaffinity_retained_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f31_affinity_Rust_ABI:[usize;22]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),
 offset_of!(abi::Thread,refcount),offset_of!(abi::Thread,cpu_set),offset_of!(abi::Thread,status),
 size_of::<abi::Process>(),offset_of!(abi::Process,ruid),offset_of!(abi::Process,euid),
 size_of::<abi::CpuSet>(),align_of::<abi::CpuSet>(),
 size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),
 size_of::<CInt>(),size_of::<CLong>(),align_of::<CLong>(),
 size_of::<Option<SchedFindThreadFn>>(),size_of::<Option<SchedThreadUnlockFn>>(),
 size_of::<Option<SchedHoldThreadFn>>(),size_of::<Option<SchedReleaseThreadFn>>(),
 size_of::<Option<SchedCopyToUserFn>>(),size_of::<Option<f03_getaffinity_retained_v2::SchedAffinityWarningOnlyFnV2>>(),
];
'''
write('lib.fixture.rs',fixture)
setsched=function(s,'sched_setscheduler_body_result')
manifest=dict(scope=SCOPE,status='SOURCE_ONLY_NO_COMPILER_OR_FIXTURE_GRANT',setscheduler_reuse=dict(source=pin(SRC/'sched_helpers.rs'),function_sha256=hashlib.sha256(setsched.encode()).hexdigest(),qualified_Rust_object=pin(BASE/'new-window-source-30-fullcrate-logger-internal-linkage/output-1/candidate.o'),qualified_partial=pin(BASE/'new-window-source-30-fullcrate-logger-internal-linkage/follow-on-source-only/output-1/CPU37.partial.o'),contract='Copy precedes lookup by existing precedence; one positive foreign lookup reference spans owner-offload and apply, then one unlock. No second lookup or source31 reimplementation.'),adjacent_selected_scope=['sched_setscheduler_body_result','sched_affinity_select_thread','sched_getaffinity_body_result','sys_sched_getaffinity'],actual_selected_sources=[pin(SRC/'sched_helpers.rs'),pin(SRC/'process_helpers.rs'),pin(SRC/'syscall_policy.rs'),pin(SRC/'abi.rs')],reused_positive_lookup_object=pin(BASE/'new-window-source-22-positive-reference-lookup-repair/output-1/candidate.o'),new_callback_contract='Versioned void diagnostic-only warning; never the old int-returning hold ABI, never acquisition success behind a void callback.',lifetime_delta='Retain original positive lookup edge directly, avoid redundant unchecked hold+unlock overflow. Current tid0 borrows the established syscall allocation; preserve actual exited warning separately.',unassessed='CPU-mask writer/usercopy synchronization, setaffinity redundant hold, native/current/default integration remain open; no fullfile retirement.',fixture_extractions=[pin(ROOT/n) for n in ['ACTUAL-AFFINITY-PARENT-HELPERS.rs.inc','ACTUAL-OLD-AFFINITY-BODY.rs.inc','ACTUAL-LEGACY-ATOMIC-AND-WARNING.rs.inc','ACTUAL-AFFINITY-DECLARATIONS.rs.inc']],fixture_limit='Controlled extracted actual bodies and real kernel ABI types only. No production-crate, global lifecycle or native acceptance from harness.')
write('EXACT-SETSCHEDULER-REUSE-AND-AFFINITY-OWNERSHIP.SOURCE.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status=manifest['status'],setscheduler_sha=manifest['setscheduler_reuse']['function_sha256'])))
