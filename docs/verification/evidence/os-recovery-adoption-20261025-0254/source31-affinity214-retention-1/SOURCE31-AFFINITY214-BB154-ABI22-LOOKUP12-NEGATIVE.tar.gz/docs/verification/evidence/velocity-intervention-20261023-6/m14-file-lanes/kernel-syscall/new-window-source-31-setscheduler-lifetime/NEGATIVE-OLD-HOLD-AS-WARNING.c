/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include "driver.c"
/* The new diagnostic-only ABI must reject the actual old int hold signature. */
static sched_affinity_warning_only_fn_v2 rejected_old_hold = legacy_hold;
