"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Create private default-OFF selected caller/declaration patch; canonical writes forbidden.
"""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
SOURCE=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/candidate'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
patch=[];bindings=[]
for relative in ['kernel/rust/sched_helpers.rs','kernel/rust/syscall_policy.rs','kernel/process.c']:
 if relative=='kernel/process.c':continue
 p=SOURCE/relative;old=p.read_text();new=old
 if relative.endswith('sched_helpers.rs'):
  suffix='''
// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#[cfg(all(f03_getaffinity_retained_v2,
    not(all(f02_positive_reference_lookup_candidate, f03_sched_bridges_candidate))))]
compile_error!("getaffinity retained v2 requires the actual positive lookup and Rust scheduler bridge");
#[cfg(f03_getaffinity_retained_v2)]
#[path = "f03_getaffinity_retained_v2.rs"]
mod f03_getaffinity_retained_v2;
#[cfg(f03_getaffinity_retained_v2)]
pub use f03_getaffinity_retained_v2::{
    sched_affinity_hold_warning_v2, sched_getaffinity_retained_v2,
};
'''
  new+=suffix
 else:
  first=old.index('pub unsafe extern "C" fn sys_sched_getaffinity(')
  begin=old.index('    crate::sched_helpers::sched_getaffinity_body_result(',first)
  end=old.index('\n    )',begin)+len('\n    )')
  original_call=old[begin:end]
  new_call=original_call.replace('crate::sched_helpers::sched_getaffinity_body_result(',
      'crate::sched_helpers::sched_getaffinity_retained_v2(',1).replace(
      'Some(sched_hold_thread_bridge),','Some(crate::sched_helpers::sched_affinity_hold_warning_v2),')
  replacement='    #[cfg(f03_getaffinity_retained_v2)]\n    {\n'+''.join('    '+line+'\n' for line in new_call.splitlines())+'    }\n    #[cfg(not(f03_getaffinity_retained_v2))]\n    {\n'+''.join('    '+line+'\n' for line in original_call.splitlines())+'    }'
  new=old[:begin]+replacement+old[end:]
 target=ROOT/'private-postimage'/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('x') as f:f.write(new)
 bindings.append(dict(base=pin(p),postimage=pin(target)))
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
# C is declarations only; use genuine selected C TU source namespace as patch base.
c=Path('/home/holden/mckernel/kernel/syscall.c');old=c.read_text();needle='typedef void (*sched_release_thread_fn_t)(unsigned long thread_addr);'
assert old.count(needle)==1
addition='\n#ifdef MCKERNEL_RUST_SCHED_GETAFFINITY_RETAINED_V2\n'+(ROOT/'VERSIONED-AFFINITY-ABI.C.inc').read_text()+'#endif\n'
new=old.replace(needle,needle+addition)
target=ROOT/'private-postimage/kernel/syscall.c';target.parent.mkdir(parents=True,exist_ok=True)
with target.open('x') as f:f.write(new)
bindings.append(dict(base=pin(c),postimage=pin(target)))
patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/kernel/syscall.c',tofile='b/kernel/syscall.c'))
# New Rust compute body stays a separate module, not embedded C or a copied old setter.
body=(ROOT/'f03_getaffinity_retained_v2.rs').read_text();patch.extend(difflib.unified_diff([],body.splitlines(True),fromfile='/dev/null',tofile='b/kernel/rust/f03_getaffinity_retained_v2.rs'))
with (ROOT/'GETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch').open('x') as f:f.write(''.join(patch))
with (ROOT/'PRIVATE-PATCH-BASES-AND-POSTIMAGES.SOURCE.json').open('x') as f:json.dump(dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',bindings=bindings,new_body=pin(ROOT/'f03_getaffinity_retained_v2.rs'),patch=pin(ROOT/'GETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch'),default_OFF=True,C_compute_added=False),f,indent=2);f.write('\n')
print('PRIVATE_DEFAULT_OFF_PATCH_PREPARED_NO_CANONICAL_EDITS')
