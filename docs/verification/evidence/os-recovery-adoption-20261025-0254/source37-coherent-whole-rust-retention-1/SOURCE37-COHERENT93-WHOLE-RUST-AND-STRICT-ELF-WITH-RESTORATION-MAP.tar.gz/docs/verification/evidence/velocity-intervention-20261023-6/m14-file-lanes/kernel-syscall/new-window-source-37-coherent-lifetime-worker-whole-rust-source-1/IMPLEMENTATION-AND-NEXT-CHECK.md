Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Owner: whole_rust37. This private successor composes the accepted positive lookup,
retained affinity, thread-hash final-detach writer and mask-serialized migration
worker. No new runtime body was invented. Canonical edits, compiler executions,
CMake executions, object execution and native execution are zero. ROOT grant is
NULL. Same goal 01a170fb-57c3-7ab3-862d-8005bef92a63, credit run
7f4af94a83b14cc08f97401f5891d965 and fixed deadline 2026-10-26T15:55:33Z apply.
No service, model, billing, launcher or ownership control was changed.

The base is default290-corrected-real-crate-source-1/candidate: its exact 83 files
and all default codegen flags are reused. Four supplemental original production
inputs (CMakeLists.txt, process.c, syscall.c and sched_helpers.h) come from that
base's recorded actual_source_root. The result contains 93 files: 80 unchanged,
seven changed, six added. ABI.rs is byte-identical; no Source27 CGU1 setting,
query/setparam/rr-interval module or ABI appendix is imported. The base object
f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003 is retained;
it is not recompiled unchanged.

The exact source changes are COHERENT-SUCCESSOR.patch and the complete per-file
base/postimage bindings are BASE-TO-CHANGED-MANIFEST.json. Six body modules are
byte-identical to their qualified donor sources; SOURCE-PREPARATION-CHECKS.json
records the equality. Source32's three getter visibility additions are already
part of its genuine shared donor. The new process cfg dependency guard and CMake
selector are composition only. No C computation was added.

| Private cfg/selector | Actual consumer/provider | Required pairing |
| --- | --- | --- |
| f02_positive_reference_lookup_candidate | find_thread -> process_find_thread_live_body_result_v2 -> process_try_hold_thread_live_v2 | f02_thread_hash_writer_candidate_v3, process_global_storage_candidate |
| f02_thread_hash_writer_candidate_v3 | destroy_thread's void callback -> Source34 provider -> Source33 typed writer | ENABLE_RUST_THREAD_HASH_WRITER_V3; old provider excluded only ON |
| f03_getaffinity_retained_v2 | sys_sched_getaffinity -> Source31 retained core | positive lookup, existing f03_sched_bridges_candidate |
| f03_setaffinity_retained_v2 | sys_sched_setaffinity -> Source32 setter/shared Source31 guard | positive lookup, existing Rust scheduler bridges |
| f03_migration_mask_serialized_v3 | sched_do_migrate_public -> Source36 versioned worker | retained setter, positive lookup, existing Rust scheduler bridges |
| ENABLE_RUST_AFFINITY_COHERENT_V3 (default OFF) | Adds all four affinity/lookup cfgs and exact six module dependencies together with writer option | x86_64 + ENABLE_RUST_KERNEL + ENABLE_RUST_THREAD_HASH_WRITER_V3 + linux-6.12 existing global storage |

The coherent CMake option pairs declaration-only C selectors
MCKERNEL_RUST_F02_POSITIVE_REFERENCE_LOOKUP,
MCKERNEL_RUST_SCHED_GETAFFINITY_RETAINED_V2,
MCKERNEL_RUST_SCHED_SETAFFINITY_RETAINED_V2 and the existing actual
MCKERNEL_RUST_PROCESS_GLOBAL_STORAGE macro. The existing separate writer option
pairs MCKERNEL_RUST_THREAD_HASH_WRITER_V3. The supplemental original CMake lacked
the already known global-storage macro pairing; this successor adds that pairing
only under the new coherent option. Existing defaults remain unchanged.

Source32 retains its positive lookup edge or current syscall borrow through the
synchronous migration callback. Source35 ON has one selected void callback owner;
its OFF implementation is excluded. Source36 remains byte-identical, including
migq -> reservation -> ordered runqueue acquisition, reservation release before
observable callbacks, and distinct migration/reservation/runqueue/VM IRQ tokens.
Actual Process/VM/current-thread lifetime and other global mask/CPU writers remain
OPEN; this composition does not establish their concurrency prerequisites.

Preparation encountered two exact-context conflicts, both preserved with partial
source trees and notes: overlapping Source22/35 C declaration insertions and an
unchanged Source27 declaration appearing only as Source32 patch context. They
were resolved by preserving both exact declaration blocks and omitting only the
unrelated context line. No candidate compiler failure or workload replay occurred.

Next executable check is EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json:
one changed whole-crate object compile, then the prepared symbol/import/data/
production-consumer observer and the preserved original arithmetic/logger oracle.
Use the existing reviewed owned-capture mechanism, CPU0, one job, 2 GiB AS,
60 CPU seconds shared, 90 wall seconds, 32 MiB file ceiling, six-second cleanup
and joined child/closed stream checks. A fresh actual ROOT resource grant and
independent execution review remain required. The recipe is prepared only; no
runner execution is self-authorized. Existing one-heavy ownership is untouched.
The output directory is empty and ready. Expected object is
output-1/coherent-lifetime-worker-rust.o; never substitute an isolated fixture.

The observer requires eight unique new GLOBAL function providers, no old OFF
callback symbol, exact base unresolved imports, exact unique shared-data sizes,
and actual affected production instruction/callback relocation edges. A missing
edge fails closed: inspect compiler output under the bounded correction policy;
do not weaken it or infer selection from source counts. The original logger
oracle retains all descriptor/LOCAL/relocation and original negative predicates;
only source/output paths and changed-candidate reporting labels are adapted.

Passing this check unlocks a reviewed real retained C/assembly partial link and
production selector/ABI closure. Default image, actual blocking/hardware/global
writers, current/Process lifetime, native migration, whole-file C retirement and
M14 acceptance stay OPEN. No accepted workload is replayed by this packet.
