// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private default-OFF setter; reuse the accepted Source31 edge selector/guard.
use crate::abi::{CInt, CLong, CULong, SizeT};

use super::f03_getaffinity_retained_v2::{
    select_retained_affinity_target, SchedAffinityWarningOnlyFnV2,
};
use super::{
    sched_affinity_copy_len, sched_affinity_lock, sched_affinity_unlock,
    sched_cpuset_copy, sched_cpuset_is_set, sched_cpuset_set, sched_cpuset_zero,
    sched_errno, sched_thread_cpu_id, sched_thread_proc, SchedCopyFromUserFn,
    SchedFindThreadFn, SchedReleaseThreadFn, SchedRequestMigrateFn, SchedSyscallOffsets,
    SchedThreadUnlockFn, EFAULT, EINVAL,
};

/// Apply the requested mask to the exact retained allocation, then migrate it.
///
/// # Safety
/// Current has the original live syscall-thread borrow. Genuine offsets identify
/// initialized Thread/Process state, and the disjoint aligned scratch buffers
/// each span the native cpuset_size. Positive find and diagnostic-only warning
/// follow the accepted Source31 contract. The existing Process eligibility-mask
/// stability requirement is unchanged; this is not a new concurrency proof.
/// The original runq_reservation_lock serializes supported thread-mask writers.
/// It is released before migration, usercopy, reference release or any offload.
/// The genuine migration callback finishes its request before returning and does
/// not retain this borrowed address; the same allocation stays live through it.
#[no_mangle]
pub unsafe extern "C" fn sched_setaffinity_retained_v2(
    tid: CInt,
    len: SizeT,
    user_mask: CULong,
    current_thread: usize,
    copied_mask: usize,
    intersection_mask: usize,
    cpuset_size: SizeT,
    num_processors: CInt,
    offsets: *const SchedSyscallOffsets,
    find: Option<SchedFindThreadFn>,
    unlock: Option<SchedThreadUnlockFn>,
    warn: Option<SchedAffinityWarningOnlyFnV2>,
    release: Option<SchedReleaseThreadFn>,
    copy_from: Option<SchedCopyFromUserFn>,
    migrate: Option<SchedRequestMigrateFn>,
) -> CLong {
    // Preserve the original user-address precedence, including invalid providers.
    if user_mask == 0 {
        return sched_errno(EFAULT);
    }
    if current_thread == 0 || copied_mask == 0 || intersection_mask == 0
        || cpuset_size == 0 || offsets.is_null() || num_processors < 0
    {
        return sched_errno(EINVAL);
    }
    let Some(copy_from) = copy_from else { return sched_errno(EINVAL); };
    let Some(release) = release else { return sched_errno(EINVAL); };
    let Some(migrate) = migrate else { return sched_errno(EINVAL); };

    if cpuset_size > len {
        // SAFETY: The caller's native-size scratch buffer is writable and disjoint.
        unsafe { sched_cpuset_zero(copied_mask, cpuset_size) };
    }
    let copy_len = sched_affinity_copy_len(len, cpuset_size);
    // Copy precedes lookup in the original path; no borrowed target crosses it.
    // Its full C-long result is nonzero-on-error, including a nonzero high word.
    if unsafe { copy_from(copied_mask as *mut u8, user_mask, copy_len) } != 0 {
        return sched_errno(EFAULT);
    }

    // SAFETY: Genuine aligned immutable offsets remain live for this syscall.
    let offsets = unsafe { &*offsets };
    let target = match unsafe {
        select_retained_affinity_target(tid, current_thread, offsets, find, unlock, warn, release)
    } {
        Ok(target) => target,
        Err(error) => return error,
    };
    // SAFETY: The retained allocation/borrow pins its existing Process edge.
    let process = unsafe { sched_thread_proc(target.address, offsets) };
    if process == 0 {
        return sched_errno(EINVAL);
    }
    unsafe { sched_cpuset_zero(intersection_mask, cpuset_size) };
    let eligible_mask = process.wrapping_add(offsets.proc_cpu_set_offset);
    let mut nonempty = false;
    for cpu in 0..num_processors {
        if unsafe { sched_cpuset_is_set(copied_mask, cpuset_size, cpu) }
            && unsafe { sched_cpuset_is_set(eligible_mask, cpuset_size, cpu) }
        {
            unsafe { sched_cpuset_set(intersection_mask, cpuset_size, cpu) };
            nonempty = true;
        }
    }
    if !nonempty {
        return sched_errno(EINVAL);
    }

    let thread_mask = target.address.wrapping_add(offsets.thread_cpu_set_offset);
    // SAFETY: Use the genuine existing mask serialization, without holding the
    // hash reader or carrying an IRQ lock across migration/usercopy/release.
    let irqstate = unsafe { sched_affinity_lock() };
    unsafe { sched_cpuset_copy(thread_mask, intersection_mask, cpuset_size) };
    let cpu = unsafe { sched_thread_cpu_id(target.address, offsets) };
    let needs_migration = !unsafe { sched_cpuset_is_set(thread_mask, cpuset_size, cpu) };
    unsafe { sched_affinity_unlock(irqstate) };
    if needs_migration {
        // SAFETY: Its real synchronous migration/wait callback borrows this exact
        // target while the original lookup edge/current syscall borrow survives.
        unsafe { migrate(cpu, target.address) };
    }
    drop(target);
    0
}
