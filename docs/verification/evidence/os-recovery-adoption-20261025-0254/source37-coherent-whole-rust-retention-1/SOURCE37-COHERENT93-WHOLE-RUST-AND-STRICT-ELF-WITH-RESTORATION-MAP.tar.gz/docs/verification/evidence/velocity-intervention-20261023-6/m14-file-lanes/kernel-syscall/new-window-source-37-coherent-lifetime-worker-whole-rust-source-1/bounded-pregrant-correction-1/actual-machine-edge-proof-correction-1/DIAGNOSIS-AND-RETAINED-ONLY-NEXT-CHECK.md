Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

The actual Rust compile succeeded. Its exact retained object is 18,206,144 bytes,
SHA256 6e54dc57de7cb4c4b5506cdaddb181e7758edfc7640684f9f587b48518ebd3ce.
The first strict observer failed on the absent named find_thread ->
process_find_thread_live_body_result_v2 relocation. The logger oracle did not run.
Both direct children joined with groups absent/closed streams; the original result,
warnings, failed assertion and join evidence remain untouched. Prefix references
are bound in ACTUAL-PREFIX-AND-OBJECT.REFERENCES.json. No compiler replay, donor
attribute/source edit, new Rust object, target execution or canonical edit occurred.

This is optimizer inlining in the retained object. Every prepared row was inspected:

| Actual owner | Extent | Missing named edges | Actual observed implementation |
| --- | --- | --- | --- |
| find_thread | 775B | positive lookup + try-hold | Hash73/cached bucket reader; PID precedence/fallback; original warning; guarded positive AtomicI32 CAS; original reader/IRQ release |
| process_destroy_thread_hash_detach_candidate_v3 | 600B | typed writer body | Immutable TID/hash73; cached writer; membership recheck inside acquisition; link detach/poison; same cached unlock/IRQ token |
| sys_sched_getaffinity | 540B | retained getter + diagnostic warning | Current borrow bypass or genuine find_thread; process permission; warning only; original target mask usercopy; nonzero-TID-only final release |
| sched_do_migrate_public | 3199B | serialized worker | Migq then actual reservation authority then ordered runqueues; CPU/list commit before reservation release; independent IRQ tokens; original tail |
| destroy_thread | 2213B | none | Actual named candidate-detach relocation remains strict |
| sys_sched_setaffinity | 391B | none | Actual named setter and warning relocations remain strict |

The decisive positive reference instructions are find_thread+0x24d through0x278:
real counter offset0x1214; normalized(count-1)<=0x7ffffffd rejects count<=0/MAX;
lock cmpxchg count+1 at0x26e; failure branches back before release. Success then
releases the cached hash reader and restores the original IRQ token. The detached
writer rechecks membership at0x161, detaches/poisons0x177–0x18d and releases the
same cached writer at0x18d, restoring its saved token at0x1e2.

The getter's tid0 branch at0x103 goes to the borrowed-current path0x189, which
installs no release callback. The nonzero path invokes genuine find_thread through
its actual owned relocation at0x10b, preserves permission/failure release, observes
status/TID only, copies Thread.cpu_set0x1230 at0x1bd, and releases once only when
TID is nonzero at0x1da. No redundant hold/CAS is inserted in this getter.

The serialized worker has actual runq_reservation_lock relocation0x20d into R13,
reservation ticket acquisition0x2d0 before live CPU/mask selection, ordered runqueue
acquisitions0x6cf/0x754, CPU/list/count commit0x7e4–0x82b, and reservation release
0x82b before VM/log/IPI/wakeup. IRQ storage remains distinct: outer migq stack-0x88,
runqueue stack-0x80, VM stack-0x70 and reservation's separate saved register token.
Full skip and tail instructions/RELAs are retained in the four-section disassembly.
These observations do not establish global writer or lifetime/native correctness.

EXACT-FOUR-INLINE-MACHINE-CONTRACT.json is limited to this exact retained object.
It binds all four real owner sections, complete owner code hashes, no function
alias, meaningful instruction windows and every section-owned relocation including
real warning/panic/usercopy/wakeup/IPI providers. The corrected observer requires
exactly these six absent inline callee names at exactly these four owners. Unknown
missing edges, a changed object or any altered code/RELA are rejected. The three
remaining actual named edges are unchanged. All original provider uniqueness,
OFF-provider absence, exact imports, shared-data ownership/sizes, arithmetic and
LOCAL logger predicates remain unchanged. No blanket skip or cfg-based inference
replaces machine ownership. OBSERVER-BOUNDED-CORRECTION.diff records the change.

Cheap read-only machine diagnosis and in-memory controls PASS4 positive/27 negative:
actual f9 baseline old bodies fail each new semantic-window contract; foreign
section, substituted provider and overlapping alias controls fail; saturation,
atomicity, genuine counter offset, CAS retry, writer admission/recheck, current
borrow/release, reservation acquisition/unlock and wrong IRQ-token mutations fail.
These execute only the small proof core on retained/synthetic bytes. They do not
run the full corrected observer, logger oracle, compiled artifact or OS workload.
The exact retained object hash was rechecked afterward and is unchanged.

An optional pyelftools DWARF diagnostic failed on unsupported relocation24 while
loading all debug sections. Its failure is recorded; no DWARF evidence is used in
the correction and no package/library modification or unchanged diagnostic replay
was made. The final observer uses only the existing pinned ELF parser and standard
Python instruction/RELA contract code; it adds no external package dependency.

REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json prepares ONLY the corrected strict
ownership observer and the unchanged qualified bounded arithmetic/logger oracle.
It binds the SAME object and existing source/helper/tool inputs. The original
3-command tuple/result stays failed and consumed; its compiler is never replayed.
ROOT grant is NULL. Independent source review and fresh ordinary execution release
are still required. ROOT owns any future finite two-command envelope/admission.
Default image, actual linked artifact, native, global lifecycle and whole-file
C-retirement acceptance remain OPEN.
