"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare exact retained-object observer correction; never recompile or run observers.
"""
from pathlib import Path
import ast,hashlib,json,struct
ROOT=Path(__file__).resolve().parent;PRIOR=ROOT.parent
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def writejson(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
object_row=pin(PRIOR/'output-1/coherent-lifetime-worker-rust.o');assert object_row['bytes']==18206144 and object_row['sha256']=='6e54dc57de7cb4c4b5506cdaddb181e7758edfc7640684f9f587b48518ebd3ce'
main_recipe=PRIOR/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json';j=json.loads(main_recipe.read_text());base=json.loads(Path(j['base_recipe']['path']).read_text());row=base['Elf_source'];raw=Path(row['path']).read_bytes();assert pin(Path(row['path']))==row
nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.ClassDef) and n.name=='Elf' or isinstance(n,ast.FunctionDef) and n.name in {'object_bytes','owning_relocations'}];ns={'Path':Path,'struct':struct};exec(compile(ast.Module(body=nodes,type_ignores=[]),row['path'],'exec'),ns);elf=ns['Elf'](Path(object_row['path']))
windows={
 'find_thread':[
 (0xa0,0xd9,'real TID hash73 and exact cached bucket geometry'),
 (0x136,0x149,'actual paired hash reader ticket acquisition'),
 (0x190,0x210,'exact PID pass before PID==TID fallback; no rejected exact candidate retry'),
 (0x210,0x24d,'genuine status warning before positive acquisition; actual kprintf RELA retained'),
 (0x24d,0x278,'signed real refcount0x1214: reject count<=0/MAX, CAS count+1 with retry'),
 (0x278,0x290,'release cached reader only after actual successful positive CAS'),
 (0x2f8,0x300,'restore exact saved reader IRQ token before successful return')],
 'process_destroy_thread_hash_detach_candidate_v3':[
 (0x10,0x25,'preserve genuine unlinked-entry fast return'),
 (0xac,0xec,'validate immutable TID/hash73 and cache original bucket writer address'),
 (0x149,0x161,'matching genuine hash writer ticket acquisition'),
 (0x161,0x193,'recheck membership under writer, detach links, poison one entry, unlock same cached bucket'),
 (0x1e2,0x1ea,'restore original writer IRQ token and return before destruction continues')],
 'sys_sched_getaffinity':[
 (0x100,0x123,'tid0 current borrow bypasses genuine positive lookup; nonzero uses actual find_thread edge'),
 (0x126,0x178,'same acquired target process permission checks before transfer'),
 (0x178,0x195,'permission failures release one edge; tid0 current borrow installs no release'),
 (0x195,0x1bd,'diagnostic-only status/TID warning with actual kprintf edge; no hold increment'),
 (0x1bd,0x1e5,'copy same target mask0x1230 while retained, then release only nonzero TID once'),
 (0x1e5,0x1fe,'preserve copy error and original returned copy length')],
 'sched_do_migrate_public':[
 (0x7f,0x89,'outer migq IRQ token saved independently at stack-0x88'),
 (0xed,0x113,'outer actual migq lock acquired before reservation'),
 (0x20b,0x215,'actual shared runq_reservation_lock RELA selects reservation authority'),
 (0x2cb,0x325,'reservation acquisition precedes live CPU/mask selection and skip guard'),
 (0x440,0x4d4,'choose destination from live mask while reservation held; empty selection unlocks reservation'),
 (0x599,0x5c2,'order both runqueues and save distinct runqueue IRQ token at stack-0x80'),
 (0x6ca,0x6e2,'first ordered runqueue actual ticket acquisition'),
 (0x74f,0x763,'second ordered runqueue actual ticket acquisition'),
 (0x7e4,0x832,'commit cpu_id and destination runqueue/list count, THEN release same reservation'),
 (0x89f,0x8a8,'restore reservation token before VM/tail callbacks'),
 (0x8dc,0x8e3,'independent VM IRQ token stored at stack-0x70'),
 (0xa31,0xa37,'restore VM token before tail log/IPI/wakeup'),
 (0xb79,0xb95,'genuine request wakeup followed by first runqueue release'),
 (0xc07,0xc10,'second runqueue release'),
 (0xc74,0xc7f,'restore distinct runqueue token and continue original request loop'),
 (0x198,0x1a1,'empty/done path restores independently saved outer migq token')]
}
callees={'find_thread':['process_find_thread_live_body_result_v2','process_try_hold_thread_live_v2'],'process_destroy_thread_hash_detach_candidate_v3':['process_thread_hash_detach_live_body_v3'],'sys_sched_getaffinity':['sched_getaffinity_retained_v2','sched_affinity_hold_warning_v2'],'sched_do_migrate_public':['sched_do_migrate_mask_serialized_v3']}
contracts={}
for name,spans in windows.items():
 s=next(s for s in elf.symbols if s['name']==name and s['shndx']);code=ns['object_bytes'](elf,s);relocs=ns['owning_relocations'](elf,s)
 contracts[name]=dict(caller=name,inlined_callees=callees[name],symbol_size=s['size'],section_name=elf.sections[s['shndx']]['name'],code_sha256=hashlib.sha256(code).hexdigest(),instruction_windows=[dict(offset=start,bytes_hex=code[start:end].hex(),meaning=meaning) for start,end,meaning in spans],owned_relocations=relocs)
contract=dict(scope=SCOPE,accepted_object_only=object_row,status='SOURCE_ONLY_INDEPENDENT_REVIEW_REQUIRED',root_grant=None,contracts=contracts,unchanged_strict_named_edges={'destroy_thread':['process_destroy_thread_hash_detach_candidate_v3'],'sys_sched_setaffinity':['sched_setaffinity_retained_v2','sched_affinity_hold_warning_v2']})
writejson(ROOT/'EXACT-FOUR-INLINE-MACHINE-CONTRACT.json',contract)
# All pre-edge predicates stay unchanged. Four exact observed inline callsites
# use reviewed same-object instruction/RELA proof; other edges stay named/strict.
s=(PRIOR/'observe_coherent_object.NOT-RUN.py').read_text()
s=s.replace("recipe=json.loads((ROOT/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json').read_text())","recipe=json.loads((ROOT.parent/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json').read_text())\nsuffix=json.loads((ROOT/'REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json').read_text())")
s=s.replace("new_path=ROOT/'output-1/coherent-lifetime-worker-rust.o';base=Elf(base_path);new=Elf(new_path)","new_path=Path(suffix['retained_object']['path']);pinned(suffix['retained_object']);base=Elf(base_path);new=Elf(new_path)\ncontract=json.loads(pinned(suffix['inline_contract']))\nassert contract['accepted_object_only']==suffix['retained_object']\ninline_ns={};exec(compile(pinned(suffix['inline_helper']),suffix['inline_helper']['path'],'exec'),inline_ns)\ncheck_inline=inline_ns['check_inline_machine_body']")
old="""    for callee in callees:assert callee in names,(caller,callee,'missing actual object consumer edge')
    edge_proof[caller]=[r for r in relocs if r['target']['name'] in callees]
"""
new="""    missing=[callee for callee in callees if callee not in names]
    if caller in contract['contracts']:
        selected=contract['contracts'][caller]
        assert missing==selected['inlined_callees'],(caller,'unreviewed missing or changed inline edge')
        assert sorted(callees)==sorted(selected['inlined_callees'])
        edge_proof[caller]=check_inline(new,symbol,relocs,selected,ns['object_bytes'])
    else:
        assert contract['unchanged_strict_named_edges'][caller]==callees
        for callee in callees:assert callee in names,(caller,callee,'missing actual object consumer edge')
        edge_proof[caller]=[r for r in relocs if r['target']['name'] in callees]
"""
# Original loader calls its dictionary ns, which already contains object_bytes.
assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace("'PASS_CHANGED_CANDIDATE_WHOLE_OBJECT_COMPILE_OWNERSHIP_ONLY'","'PASS_RETAINED_SOURCE37_WHOLE_OBJECT_EXACT_INLINE_AND_NAMED_OWNERSHIP_ONLY'")
s=s.replace('ACTUAL-COHERENT-WHOLE-OBJECT-OWNERSHIP.json','ACTUAL-RETAINED-SOURCE37-INLINE-AND-NAMED-OWNERSHIP.json')
s=s.replace('PASS changed coherent whole-object','PASS retained coherent whole-object exact inline/named')
(ROOT/'observe_retained_source37_exact_machine_edges.NOT-RUN.py').write_text(s)
(ROOT/'OBSERVER-BOUNDED-CORRECTION.diff').write_text(''.join(__import__('difflib').unified_diff((PRIOR/'observe_coherent_object.NOT-RUN.py').read_text().splitlines(True),s.splitlines(True),fromfile='qualified-prefix-failed-named-edge-observer',tofile='exact-retained-object-inline-and-named-observer')))
recipe=dict(scope=SCOPE,status='PREPARED_RETAINED_ONLY_NOT_GRANTED_NOT_EXECUTED',root_grant=None,retained_object=object_row,unchanged_original_recipe=pin(main_recipe),unchanged_original_observer=pin(PRIOR/'observe_coherent_object.NOT-RUN.py'),inline_contract=pin(ROOT/'EXACT-FOUR-INLINE-MACHINE-CONTRACT.json'),inline_helper=pin(ROOT/'inline_machine_contract.py'),original_prefix_result=pin(PRIOR/'finite-three-command-envelope-source-1/ACTUAL-SOURCE37-THREE-COMMAND-RESULT.json'),profile=j['profile'],commands=[dict(name='00-retained-exact-inline-and-named-provider-import-data-ownership',argv=[j['tools']['Python']['path'],'-B',str(ROOT/'observe_retained_source37_exact_machine_edges.NOT-RUN.py')],cwd=str(ROOT),purpose=SCOPE+' Reuse exact compiled object6e54; preserve all original provider/import/data/strict-named predicates and check only four reviewed inline bodies with exact instructions and owned RELAs; no compiler.'),dict(name='01-unchanged-qualified-bounded-arithmetic-logger-oracle',argv=j['commands'][2]['argv'],cwd=j['commands'][2]['cwd'],purpose=j['commands'][2]['purpose'])],expected_exits=[0,0],must_remain_absent=[str(ROOT/'ACTUAL-RETAINED-SOURCE37-INLINE-AND-NAMED-OWNERSHIP.json'),str(PRIOR/'ACTUAL-COHERENT-ORIGINAL-LOGGER-ARITHMETIC-OWNERSHIP.json')],compiler_replays=0,native=False,default_image=False)
recipe['inputs']=j['inputs']+list(j['tools'].values())+[object_row,pin(main_recipe),recipe['inline_contract'],recipe['inline_helper'],pin(ROOT/'observe_retained_source37_exact_machine_edges.NOT-RUN.py')]
writejson(ROOT/'REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json',recipe)
for p in [ROOT/'inline_machine_contract.py',ROOT/'observe_retained_source37_exact_machine_edges.NOT-RUN.py',ROOT/'prepare_machine_edge_successor.py']:ast.parse(p.read_text())
assert pin(Path(object_row['path']))==object_row
print(json.dumps(dict(status='SOURCE_ONLY_RETAINED_OBJECT_CORRECTION_PREPARED',contract=pin(ROOT/'EXACT-FOUR-INLINE-MACHINE-CONTRACT.json'),recipe=pin(ROOT/'REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json'))))
