"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Source preparation only. Exact hunk matching; no compiler or runtime execution.
"""
from pathlib import Path
import difflib, hashlib, json, shutil
ROOT=Path(__file__).resolve().parent
KS=ROOT.parent
BASE=KS/'default290-corrected-real-crate-source-1/candidate'
DERIV=json.loads((BASE.parent/'EXACT-ACTUAL-DEFAULT-SOURCE-DERIVATION.json').read_text())
ACTUAL=Path(DERIV['actual_source_root'])
DEST=ROOT/'candidate'
assert not DEST.exists()
shutil.copytree(BASE,DEST)
base_sources={str(p.relative_to(BASE)):p for p in BASE.rglob('*') if p.is_file()}
for relative in ['kernel/CMakeLists.txt','kernel/process.c','kernel/syscall.c','kernel/include/sched_helpers.h']:
    p=ACTUAL/relative; target=DEST/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);base_sources[relative]=p
applied=[]
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def patch(name, skip=()):
    p=KS/name; lines=p.read_text().splitlines(True);i=0;current=None
    while i<len(lines):
        if lines[i].startswith('--- '):
            oldpath=lines[i][4:].strip();newpath=lines[i+1][4:].strip();current=newpath.removeprefix('b/');i+=2
            if current not in skip:
                target=DEST/current; target.parent.mkdir(parents=True,exist_ok=True)
                if oldpath=='/dev/null':assert not target.exists();target.write_text('')
            continue
        if lines[i].startswith('@@ '):
            i+=1;h=[]
            while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
                if lines[i].startswith((' ','+','-')):h.append(lines[i])
                elif lines[i].strip():raise AssertionError(lines[i])
                i+=1
            if current in skip:continue
            old=''.join(x[1:] for x in h if x[0] in ' -');new=''.join(x[1:] for x in h if x[0] in ' +')
            text=(DEST/current).read_text()
            if old:
                # Source32's first hunk carries an unrelated Source27 rr-interval
                # declaration as context. It is deliberately absent from this base.
                excluded_context='pub(crate) mod f03_sched_rr_interval_lifetime_v2;\n\n'
                if current=='kernel/rust/sched_helpers.rs' and old.startswith(excluded_context):
                    assert new.startswith(excluded_context)
                    old=old[len(excluded_context):];new=new[len(excluded_context):]
                assert text.count(old)==1,(name,current,'exact old hunk mismatch',old[:180])
                text=text.replace(old,new,1)
            else:assert not text;text=new
            (DEST/current).write_text(text)
            continue
        i+=1
    applied.append(pin(p))
# Every Source35 Rust writer body comes through its original exact patch and leaf files.
patch('new-window-source-35-thread-hash-writer-production-selection-source-1/SOURCE35-DEFAULT-OFF-PRODUCTION-SELECTION.patch')
for n in ['thread_hash_detach_v3.rs','thread_hash_writer_provider_v3.rs']:
    shutil.copyfile(KS/'new-window-source-35-thread-hash-writer-production-selection-source-1/candidate/kernel/rust'/n,DEST/'kernel/rust'/n)
# Source22/35 both insert C declarations after the same include. Merge exact
# Source22 added declaration lines at that original anchor; bodies remain untouched.
lookup_patch=KS/'new-window-source-22-positive-reference-lookup-repair/MINIMAL-PRODUCTION-LOOKUP.CURRENT-DEFAULT-OFF.patch'
section=lookup_patch.read_text().split('--- a/kernel/process.c\n',1)[1].split('--- a/kernel/rust/process_helpers.rs\n',1)[0]
added=''.join(x[1:] for x in section.splitlines(True) if x.startswith('+') and not x.startswith('+++'))
p=DEST/'kernel/process.c';s=p.read_text();anchor='#include <process_helpers.h>\n';assert s.count(anchor)==1;p.write_text(s.replace(anchor,anchor+added,1))
patch('new-window-source-22-positive-reference-lookup-repair/MINIMAL-PRODUCTION-LOOKUP.CURRENT-DEFAULT-OFF.patch',skip=['kernel/process.c'])
# Source31 sched append had context from unrelated query modules. Append only its
# own added lines rather than importing those excluded candidate bodies/ABIs.
p=KS/'new-window-source-31-setscheduler-lifetime/GETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch'
text=p.read_text();section=text.split('--- a/kernel/rust/sched_helpers.rs\n',1)[1].split('--- a/kernel/rust/syscall_policy.rs\n',1)[0]
addition=''.join(line[1:] for line in section.splitlines(True) if line.startswith('+') and not line.startswith('+++'))
target=DEST/'kernel/rust/sched_helpers.rs';target.write_text(target.read_text()+addition)
patch('new-window-source-31-setscheduler-lifetime/GETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch',skip=['kernel/rust/sched_helpers.rs'])
patch('new-window-source-32-setaffinity-lifetime/SETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch')
# Source36 final prototype/body patch has the same worker as its focused compile;
# its append context is the original sched tail, still present once here.
patch('new-window-source-36-setaffinity-production-callbacks-source-1/PRODUCTION-DECLARATION-AND-WORKER.DEFAULT-OFF.patch')
# Close candidate composition prerequisites explicitly; no new runtime body.
p=DEST/'kernel/rust/process_helpers.rs';s=p.read_text();s+='''
// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#[cfg(all(f02_positive_reference_lookup_candidate,
    not(all(f02_thread_hash_writer_candidate_v3, process_global_storage_candidate))))]
compile_error!("coherent positive lookup requires the paired writer and actual Rust global storage");
''';p.write_text(s)
# Default OFF private selector pairs all new Rust flags and declaration-only C ABIs.
p=DEST/'kernel/CMakeLists.txt';s=p.read_text()
needle='set(MCKERNEL_HOST_IRQ_ABI "legacy" CACHE STRING'
assert s.count(needle)==1
s=s.replace(needle,'''# Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
option(ENABLE_RUST_AFFINITY_COHERENT_V3 "Select private retained affinity and serialized migration" OFF)
if (ENABLE_RUST_AFFINITY_COHERENT_V3 AND
    (NOT ENABLE_RUST_KERNEL OR NOT ENABLE_RUST_THREAD_HASH_WRITER_V3 OR
     NOT "${ARCH}" STREQUAL "x86_64" OR NOT MCKERNEL_HOST_IRQ_ABI STREQUAL "linux-6.12"))
    message(FATAL_ERROR "Coherent affinity V3 requires x86_64 Rust, writer V3 and linux-6.12 global storage")
endif()
'''+needle,1)
# The IRQ ABI cache declaration must precede its coherent dependency check.
block_start=s.index('if (ENABLE_RUST_AFFINITY_COHERENT_V3 AND')
block_end=s.index('endif()\n',block_start)+len('endif()\n')
block=s[block_start:block_end];s=s[:block_start]+s[block_end:]
anchor='set_property(CACHE MCKERNEL_HOST_IRQ_ABI PROPERTY STRINGS legacy linux-6.12)\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+block,1)
needle='\t\tset(RUST_KERNEL_CFG)\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''        if (ENABLE_RUST_AFFINITY_COHERENT_V3)
            list(APPEND RUST_KERNEL_CFG
                "--cfg" "f02_positive_reference_lookup_candidate"
                "--cfg" "f03_getaffinity_retained_v2"
                "--cfg" "f03_setaffinity_retained_v2"
                "--cfg" "f03_migration_mask_serialized_v3")
            list(APPEND RUST_KERNEL_SRCS
                "${CMAKE_CURRENT_SOURCE_DIR}/rust/f02_positive_reference_lookup.rs"
                "${CMAKE_CURRENT_SOURCE_DIR}/rust/f03_getaffinity_retained_v2.rs"
                "${CMAKE_CURRENT_SOURCE_DIR}/rust/f03_setaffinity_retained_v2.rs"
                "${CMAKE_CURRENT_SOURCE_DIR}/rust/f03_migration_mask_serialized_v3.rs")
        endif()
''',1)
needle='\tif (MCKERNEL_HOST_IRQ_ABI STREQUAL "linux-6.12")\n\t\tset_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/syscall.c" APPEND PROPERTY'
assert s.count(needle)==1
s=s.replace(needle,'''    if (ENABLE_RUST_AFFINITY_COHERENT_V3)
        set_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/process.c" APPEND PROPERTY
            COMPILE_DEFINITIONS "MCKERNEL_RUST_F02_POSITIVE_REFERENCE_LOOKUP;MCKERNEL_RUST_PROCESS_GLOBAL_STORAGE")
        set_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/syscall.c" APPEND PROPERTY
            COMPILE_DEFINITIONS "MCKERNEL_RUST_SCHED_GETAFFINITY_RETAINED_V2;MCKERNEL_RUST_SCHED_SETAFFINITY_RETAINED_V2")
    endif()
'''+needle,1)
p.write_text(s)
# Explicit cfgs only; identical existing codegen switches, no codegen-units override.
base_recipe=BASE.parent/'EXACT-ACTUAL-DEFAULT-CORRECTED-RUST.NOT-GRANTED.json'
recipe=json.loads(base_recipe.read_text());argv=recipe['commands'][0]['argv'][:]
new_cfg=['f02_positive_reference_lookup_candidate','f02_thread_hash_writer_candidate_v3','f03_getaffinity_retained_v2','f03_setaffinity_retained_v2','f03_migration_mask_serialized_v3']
argv=[a.replace(str(BASE),str(DEST)).replace(str(BASE.parent/'output-1/corrected-current290-rust.o'),str(ROOT/'output-1/coherent-lifetime-worker-rust.o')) for a in argv]
for cfg in new_cfg:argv[-2:-2]=['--cfg',cfg]
assert not any('codegen-units' in a for a in argv)
recipe_out=dict(scope=recipe['scope'],status='PREPARED_NOT_GRANTED_NOT_EXECUTED',root_grant=None,profile=recipe['profile'],base_recipe=pin(base_recipe),tools=recipe['tools'],commands=[dict(name='00-changed-coherent-whole-Rust-object',argv=argv,cwd=str(ROOT),purpose=recipe['scope']+' Compile changed whole crate with five explicitly added cfgs; preserve actual default codegen flags. No C/ASM/image/native execution.')],new_cfgs=new_cfg,default_selection=False,compiler_executions=0)
(ROOT/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json').write_text(json.dumps(recipe_out,indent=2)+'\n')
# Exact manifest: 83 original files plus four supplementary real production inputs.
rows=[];diff=[]
for p in sorted(DEST.rglob('*')):
    if not p.is_file():continue
    rel=str(p.relative_to(DEST));b=base_sources.get(rel);same=b is not None and p.read_bytes()==b.read_bytes()
    rows.append(dict(relative=rel,kind='unchanged' if same else ('changed' if b else 'added'),base=pin(b) if b else None,candidate=pin(p)))
    if not same:diff.extend(difflib.unified_diff(b.read_text().splitlines(True) if b else [],p.read_text().splitlines(True),fromfile='a/'+rel if b else '/dev/null',tofile='b/'+rel))
(ROOT/'COHERENT-SUCCESSOR.patch').write_text(''.join(diff))
manifest=dict(scope=recipe['scope'],status='SOURCE_PREPARED_COMPILER_AND_NATIVE_OPEN',owner='whole_rust37',root_grant=None,goal='01a170fb-57c3-7ab3-862d-8005bef92a63',credit_run='7f4af94a83b14cc08f97401f5891d965',deadline='2026-10-26T15:55:33Z',base_tree=str(BASE),base_Rust_object_sha256='f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003',supplementary_production_source_root=str(ACTUAL),applied_patches=applied,files=rows,counts={k:sum(r['kind']==k for r in rows) for k in ['unchanged','changed','added']},total_files=len(rows),compiler_executions=0,canonical_edits=0,policy_sha256={'CONVERGENCE.md':'3cb05691834bbd11da1597862111cd1bf8264baf020a097635b452668d064dce','GOAL.md':'aaf587e0b24a2b801edf462fc40727709f96cfedd70a2de94bb59191afc4a849','HANDOFF.md':'b408a2c4dc6181b0a94ade89ca4d7bb8280e1e7b2e798a952b00841b6cbff6a2','START.md':'dafb718ee3c820a91516f589e220ca380662656757c008d419ddebc6a9157d69'})
(ROOT/'BASE-TO-CHANGED-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(result='SOURCE_PREPARED_NO_COMPILER',counts=manifest['counts'],total_files=len(rows),patch=pin(ROOT/'COHERENT-SUCCESSOR.patch'))))
