Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Owner whole_rust37 prepared this disjoint finite ordinary envelope. It does not
change the independently accepted corrected candidate, three-command recipe or
either oracle. ROOT grant is NULL and its actual grant path is absent. No runner,
compiler, oracle, census, resource query, root/native/heavy operation or workload
has executed. Existing ROOT Edefault/main-heavy ownership remains untouched.

Use only run_source37_three_commands_once.NOT-GRANTED.py with the frozen
ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json. The spec pins corrected recipe1c5a710b,
its 103 input rows plus four tools (107 logical rows,106 unique paths), h990
helper990807ab and accepted census96d17547. The runner adds held bindings for its
own bytes, the actual ROOT grant, spec/recipe and existing armed-window receipt.
It retains one read-only CLOEXEC FD per unique lexical path through the complete
sequence, checking hash/full fstat metadata and lexical lstat/symlink target plus
current target identity before/after every command and on final success/failure.
Every input is capped at32MiB and the parent live FD count must stay below256.
No historical recursion or sysroot scan is introduced.

The corrected output-1 directory was authenticated as existing and empty:
UID/GID1000,mode0700,dev66306,inode59656428. Its full current identity is in the
spec. Runtime requires that exact original empty directory at initial admission,
holds its CLOEXEC directory FD, and keeps identity/owner/mode checks across output
creation. It never deletes, recreates or substitutes the directory. All generated
object/oracle JSON, claim, capture and envelope-result paths must be absent.

The profile is the reviewed Source34/35/h990 profile: parent controlCPU7,
commandCPU0,one job,AS2GiB,sharedCPU60s/work-wall90s plus retirement6s,FS32MiB,
FD256,stack2MiB,core0. Existing MemAvailable25501368320B,HOST16GiB+64MiB and
scratch12GiB floor checks are retained. No new container, heavy, native or service
profile is granted. The full invocation uses the same90+6 finite timer; child
CPU limits consume the remaining shared lifetime CPU budget. The actual command
cwd and argv are the unchanged corrected recipe values.

The accepted h990 functions, including owned_capture, are extracted unchanged.
The accepted census leaf is loaded directly from its held authenticated source.
A wait wrapper only samples the already owned process group to record the first
observed selected Rust compiler executable, if observed; actual exec-start latency
is not invented. It never changes ownership/signalling/reaping behavior. The
usual raw stdout/stderr, started/direct-wait/direct-join, groups-absent and closed
stream evidence remain. Each command adds durable ready/enqueue/start/end records,
CPU/wall and explicitly cumulative child peak RSS. First unexpected exit, oracle,
input or retirement failure stops without another command or automatic retry.
A missing returned join retains retirement uncertainty instead of claiming release.

ROOT must instantiate a separate actual grant from the NULL template, binding the
exact runner/spec/recipe/profile/output identity and this same goal/credit/window.
Populate only the already armed exact MONOTONIC/BOOTTIME values and immutable
bound launch/guardian receipt; never derive new cutoffs or reset them. The runner
checks UTC1793030133 plus both supplied armed clocks have90+6s remaining. Root
also provides its actual fresh ordinary resource admission. No controller,
launcher, billing, model, guardian or account mutation is included here.

EXACT-ROOT-COMMAND.PREPARED-NOT-GRANTED.json supplies the CPU7 command. The actual
ROOT grant path must remain absent until ROOT authorizes the concrete tuple.
Preparation, source AST checks and READY are not execution authority. The three
commands remain exactly: changed whole-Rust compile; strict providers/import/data/
production-consumer edges; qualified bounded arithmetic/logger oracle. Default
image, whole-file C retirement, native/lifetime/global-writer acceptance stay OPEN.
