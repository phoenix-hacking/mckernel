Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This additive successor implements the complete independent pregrant review batch.
The parent Source37 tuple remains immutable and BLOCKED_SOURCE; execute neither
its original recipe nor its old observer. ROOT grant for this successor is NULL.
No compiler, CMake, object observer, native workload, root operation or launcher
control ran. Same goal, credit run and fixed 2026-10-26T15:55:33Z deadline apply.

The actual 83-file Rust base remains default290-corrected-real-crate-source-1/
candidate, including a059 root and fefec policy bytes. Supplemental production
CMake authority is current canonical f29336679e462746822d5ce9efe1a74491fbea1f0cbb46d56cfdc48ae082b3cc,
including the existing accepted Linux6.12 process-global-storage pairing. The
historical f54 CMake is not current authority. Three other supplemental original
C/header inputs retain their exact recorded bindings. The 93-file successor has
80 unchanged, seven changed and six added files. The six module bodies and ABI
are unchanged from Source37's qualified donors.

The CMake diff against current f293 contains additions only. Its preexisting
Linux6.12 MCKERNEL_RUST_PROCESS_GLOBAL_STORAGE pairing applies regardless of the
new coherent option. The new coherent block appends only the positive-lookup
process macro, plus the separate two new affinity declaration macros on syscall.c.
The original Source35 writer selector still appends its independent writer macro.
OFF defaults preserve the current pairing; no duplicate-global regression is
reintroduced. The private coherent/writer options and five cfg dependencies keep
the same consumer table from the original implementation notes.

The original arithmetic/logger oracle now derives from the actual qualified
bounded checker (6b5a53a51d5b392a91acb30eb9487f036ab1b631f985964730034933c4af91f6).
It locates the first closing }; for each exact named initializer and requires one
line! site inside that boundary. The already failed start+10 extent is absent.
All original symbol, LOCAL/default-visibility, overlap, descriptor, relocation,
negative-control, panic and import predicates remain. Adaptations are source/
object/recipe/output/report bindings plus an immediate historical-object pin
before its ELF parse. BOUNDED-ORACLE-TRANSPORT.diff records every adaptation.

The main three-command recipe explicitly binds only its direct consumed closure:
immutable base recipe4b8f2b9b, retained accepted f9d2e566 object, historical
5b70e620 object, Elf helperdac5cb0d, descriptor helper1a3ab937 and the actual
Anaconda Python binary used in both observer commands. These six rows appear in
both consumed_inputs and inputs. Generated candidate object/results are outputs,
not preexecution pins. The candidate source, observer and oracle recipe rows are
also bound. No recursive historical or sysroot inventory was added.

The eventual owned envelope MUST verify all input rows before and after the full
three-command sequence through held read-only FDs: configured size/SHA256 plus
stable device/inode/mode/size/mtime_ns/ctime_ns before/after hashing and across the
sequence, with pathname identity matching the held FD. A mismatch fails closed.
The exact requirement is envelope_required_binding_contract in the recipe. This
is not a replacement runtime envelope or execution authorization. Root retains
ownership of the existing reviewed capture mechanism and fresh resource grant.

SOURCE-PREPARATION-CHECKS.json records 93 file pins, six unchanged donor bodies,
unchanged ABI, Python AST checks, six direct pins and four unique bounded logger
line sites. These are source checks only. No object predicates have executed.
The two source-context failures and original blocked tuple remain preserved.

Next: independently review this one complete corrected tuple and bind it into
the existing actual owned envelope. Then obtain fresh ROOT CPU0/one-job/2GiB AS
admission for exactly the same three commands: changed whole-Rust compile using
original codegen flags plus five declared cfgs; strict provider/import/shared-data/
production-consumer-edge observer; and the corrected original arithmetic/logger
oracle. No blanket consumer-edge waiver is authorized. Actual default/image,
retained C/assembly partial link, Process/current/global-writer lifetime, native
migration and whole-file C retirement remain OPEN.
