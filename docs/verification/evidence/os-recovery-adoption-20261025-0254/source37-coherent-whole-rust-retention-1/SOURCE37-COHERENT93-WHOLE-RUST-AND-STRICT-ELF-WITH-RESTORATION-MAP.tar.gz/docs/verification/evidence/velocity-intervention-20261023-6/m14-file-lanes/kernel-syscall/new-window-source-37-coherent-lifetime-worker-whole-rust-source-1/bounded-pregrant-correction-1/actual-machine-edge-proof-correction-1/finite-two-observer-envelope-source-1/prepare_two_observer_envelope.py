"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare finite retained-two-observer envelope, preserving every existing byte.
"""
from pathlib import Path
import ast,hashlib,json,os
ROOT=Path(__file__).resolve().parent;CORRECTION=ROOT.parent;PRIOR=CORRECTION.parent
OLD=PRIOR/'finite-three-command-envelope-source-1'
FIELDS=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 raw=p.read_bytes();assert len(raw)<=32<<20;return dict(path=str(p.absolute()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def writejson(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
r=CORRECTION/'REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json';assert pin(r)['sha256']=='38b85fa509bac3786ad897a06a46a297a6458a1dc191ce74d74f36a057567aed';j=json.loads(r.read_text());oldspec=json.loads((OLD/'ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json').read_text())
assert len(j['inputs'])==112 and len({x['path'] for x in j['inputs']})==111
for row in j['inputs']:assert pin(Path(row['path']))==row
obj=Path(j['retained_object']['path']);assert pin(obj)==j['retained_object'];obj_identity={k:getattr(obj.stat(),k) for k in FIELDS};assert obj_identity['st_uid']==obj_identity['st_gid']==1000
prefix=OLD/'ACTUAL-SOURCE37-THREE-COMMAND-RESULT.json';assert pin(prefix)['sha256']=='586cbbc3c7f200d23ea55d15c76d90a16753648bd2da8afcc721a37c125c615d'
pj=json.loads(prefix.read_text());assert len(pj['records'])==2 and pj['records'][0]['join']['returncode']==0 and pj['records'][1]['join']['returncode']==1 and pj['CPU0_workload_retirement_proven'] and pj['final_input_verification_error'] is None
prefix_paths=[prefix,CORRECTION/'ACTUAL-PREFIX-AND-OBJECT.REFERENCES.json',OLD/'actual-three-command-capture-1/00/whole-join-and-end.json',OLD/'actual-three-command-capture-1/00/stderr',OLD/'actual-three-command-capture-1/01/whole-join-and-end.json',OLD/'actual-three-command-capture-1/01/stderr']
receipt=dict(path='/home/holden/mckernel-work/host-preparation/velocity-intervention-20261025-1/new-18-hour-window-1/parent-handoff/POST-DETACH-NEW18H-VERIFIED.json',bytes=4115,sha256='243a7419308a3ed95e8c83a5a250ec1655a2b2d06f494dc3d24f0a1ad373ce60')
assert pin(Path(receipt['path']))==receipt
spec=dict(scope=j['scope'],status='SOURCE_ONLY_NOT_GRANTED_NOT_EXECUTED',root_grant=None,recipe=pin(r),profile=oldspec['profile'],logical_input_rows=112,unique_recipe_input_paths=111,recipe_inputs=j['inputs'],helper=oldspec['helper'],census=oldspec['census'],retained_object=j['retained_object'],retained_object_identity=obj_identity,prefix_result=pin(prefix),prefix_bindings=[pin(p) for p in prefix_paths],existing_armed_window_authority=receipt,existing_armed_cutoffs=dict(authority='existing_armed_window',UTC_epoch=1793030133,monotonic_seconds=812240.493656513,boottime_seconds=827578.62070498),required_absent_paths=[str(ROOT/'actual-two-observer-capture-1'),str(ROOT/'ACTUAL-SOURCE37-TWO-OBSERVER-RESULT.json'),str(ROOT/'ATTEMPT-CLAIM.json')]+j['must_remain_absent'],command_names=[c['name'] for c in j['commands']],expected_exits=[0,0],fixed_window=oldspec['fixed_window'],same_goal=oldspec['same_goal'],credit_run=oldspec['credit_run'],prefix_scope='Original real compile PASS; first named-edge-only observer FAIL; third logger NOT RUN. Preserve failed tuple and actual joins. This packet executes only corrected strict observer plus unchanged qualified logger on same retained object.',fd_contract=oldspec['fd_contract'].replace('107row','112row').replace('all3commands','both observer commands'),no_compiler_command=True,compiler_replays=0)
for path in spec['required_absent_paths']:assert not os.path.lexists(path),path
specpath=ROOT/'ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json';writejson(specpath,spec)
s=(OLD/'run_source37_three_commands_once.NOT-GRANTED.py').read_text()
s=s.replace('Finite Source37 ordinary envelope','Finite Source37 retained-two-observer ordinary envelope')
s=s.replace("SPEC_SHA='9d0fa3ad4ade8c0af39f6d58d2a2f7f1963269da78d081a41c651d6e0598c00a'","SPEC_SHA='"+pin(specpath)['sha256']+"'")
s=s.replace('ROOT-EXACT-SOURCE37-THREE-COMMAND-GRANT.json','ROOT-EXACT-SOURCE37-TWO-OBSERVER-GRANT.json').replace('actual-three-command-capture-1','actual-two-observer-capture-1').replace('ACTUAL-SOURCE37-THREE-COMMAND-RESULT.json','ACTUAL-SOURCE37-TWO-OBSERVER-RESULT.json')
s=s.replace('DIR_STABLE_FIELDS=FIELDS[:6]\n','')
start=s.index('\ndef directory_verify(');end=s.index('\ndef main():',start);s=s[:start]+s[end:]
s=s.replace('held=HeldInputs();directory_fd=None;namespace={};records=[]','held=HeldInputs();namespace={};records=[]')
s=s.replace("len(recipe['commands'])==3","len(recipe['commands'])==2").replace('exact three-command sequence','exact retained two-observer sequence')
s=s.replace("recipe['inputs']+list(recipe['tools'].values())==spec['recipe_inputs'] and len(spec['recipe_inputs'])==107","recipe['inputs']==spec['recipe_inputs'] and len(spec['recipe_inputs'])==112").replace('exact107logical input rows','exact112logical input rows')
s=s.replace("        for key in ('helper','census'):held.add(spec[key])","        for key in ('helper','census'):held.add(spec[key])\n        for row in spec['prefix_bindings']:held.add(row)\n        held.add(spec['existing_armed_window_authority'])\n        actual_object=held.rows[spec['retained_object']['path']]['baseline']\n        need(actual_object['target_identity']==spec['retained_object_identity'] and actual_object['lexical_identity']==spec['retained_object_identity'],'retained actual object full identity must match successful compiler artifact')\n        prefix=json.loads(held.read(Path(spec['prefix_result']['path'])))\n        need(len(prefix['records'])==2 and prefix['records'][0]['join']['returncode']==0 and prefix['records'][1]['join']['returncode']==1 and prefix['CPU0_workload_retirement_proven'] and prefix['final_input_verification_error'] is None,'preserve genuine compile-pass/observer-fail/retirement/stable-input prefix')")
s=s.replace("and grant.get('profile')==PROFILE and grant.get('existing_output_directory')==spec['existing_output_directory']","and grant.get('profile')==PROFILE and grant.get('retained_object')==spec['retained_object']\n             and grant.get('retained_object_identity')==spec['retained_object_identity']")
start=s.index("        need(isinstance(cutoffs,dict)");end=s.index("        held.add(receipt)",start)
s=s[:start]+"""        need(cutoffs==spec['existing_armed_cutoffs'],'exact existing armed wall/MONO/BOOT cutoffs only')
        receipt=grant.get('existing_armed_window_authority')
        need(receipt==spec['existing_armed_window_authority'],'exact preexisting bound window authority243a only')
"""+s[end:]
start=s.index("        output=Path(spec['existing_output_directory']['path'])");end=s.index('        # h990 functions',start);s=s[:start]+s[end:]
s=s.replace("admitted_inputs=initial_inputs,existing_output_directory=output_initial,parent_FD_count=fd_count(),","admitted_inputs=initial_inputs,retained_object=spec['retained_object'],retained_object_identity=spec['retained_object_identity'],\n              prior_prefix_result=spec['prefix_result'],prefix_scope=spec['prefix_scope'],parent_FD_count=fd_count(),")
s=s.replace("        original_wait=namespace['wait_terminal']\n",'')
s=s.replace("            pre_inputs=held.verify();directory_verify(output,directory_fd,spec['existing_output_directory'])","            pre_inputs=held.verify()")
s=s.replace(";first_compiler=[]",'')
start=s.index("            rust_identity=held.rows[");end=s.index('            def limits():',start);s=s[:start]+s[end:]
s=s.replace("                  first_compiler_observed=bool(first_compiler),**timestamp()))","                  **timestamp()))")
s=s.replace("                  existing_output_directory=directory_verify(output,directory_fd,spec['existing_output_directory']),\n",'')
s=s.replace("        final_inputs=held.verify();directory_verify(output,directory_fd,spec['existing_output_directory'])","        final_inputs=held.verify()")
s=s.replace('PASS_SOURCE37_CHANGED_WHOLE_RUST_AND_STRICT_OWNERSHIP_ORACLES','PASS_SOURCE37_RETAINED_TWO_STRICT_OBSERVERS_SAME_COMPILED_OBJECT')
s=s.replace("final_inputs=final_inputs,outputs=outputs,recipe=spec['recipe'],root_grant=grant_pin,","final_inputs=final_inputs,outputs=outputs,recipe=spec['recipe'],root_grant=grant_pin,\n              retained_object=spec['retained_object'],retained_object_identity=spec['retained_object_identity'],\n              prior_prefix_result=spec['prefix_result'],prefix_scope=spec['prefix_scope'],compiler_replays=0,")
s=s.replace("        if directory_fd is not None:os.close(directory_fd)\n",'')
runner=ROOT/'run_source37_two_observers_once.NOT-GRANTED.py';runner.write_text(s);ast.parse(s);compile(s,str(runner),'exec')
assert 'directory_verify' not in s and 'selected_nightly_Rust' not in s and 'first_compiler' not in s
assert pin(obj)==j['retained_object'] and {k:getattr(obj.stat(),k) for k in FIELDS}==obj_identity
print(json.dumps(dict(spec=pin(specpath),runner=pin(runner),recipe=pin(r),logical_rows=112)))
