#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Finite Source37 retained-two-observer ordinary envelope: source preparation does not grant execution.
Reuses h990 owned_capture unchanged; holds all exact inputs through the sequence.
"""
import ast
import builtins
import datetime
import dis
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import sys
import time

ROOT=Path(__file__).absolute().parent
SPEC=ROOT/'ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json'
SPEC_SHA='aa1b9df262793e95ef9af97287dc87c2fd9586a9d8bd340d48161c03efc807bf'
GRANT=ROOT/'ROOT-EXACT-SOURCE37-TWO-OBSERVER-GRANT.json'
CAPTURE=ROOT/'actual-two-observer-capture-1'
RESULT=ROOT/'ACTUAL-SOURCE37-TWO-OBSERVER-RESULT.json'
CLAIM=ROOT/'ATTEMPT-CLAIM.json'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
FIELDS=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PROFILE=dict(parent_control_CPU=7,command_CPU=0,ordinary_jobs=1,AS_bytes=2<<30,
             whole_CPU_seconds=60,whole_wall_seconds=90,retirement_seconds=6,
             FS_bytes=32<<20,FD=256,stack_bytes=2<<20,core_bytes=0)


def need(ok,message):
    if not ok:raise RuntimeError(message)


def identity(value):return {key:getattr(value,key) for key in FIELDS}


def timestamp():
    return dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                monotonic_seconds=time.monotonic(),
                boottime_seconds=time.clock_gettime(time.CLOCK_BOOTTIME))


def write(path,value):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())


def fd_count():
    count=len(os.listdir('/proc/self/fd'))
    need(count<256,'parent live FD count must remain below256')
    return count


class HeldInputs:
    """One O_RDONLY/CLOEXEC FD per unique lexical path; never reopen at verify."""
    def __init__(self):self.rows={}

    def add(self,expected):
        path=str(Path(expected['path']).absolute())
        need(path==expected['path'],'input path must retain exact absolute argv spelling')
        if path in self.rows:
            need(self.rows[path]['expected']==expected,'conflicting duplicate input binding')
            return self.rows[path]['baseline']
        lexical=Path(path).lstat()
        fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC)
        try:
            need(not os.get_inheritable(fd),'held source FD must close on exec')
            row=dict(fd=fd,expected=expected,initial_lexical=identity(lexical),
                     initial_link=os.readlink(path) if stat.S_ISLNK(lexical.st_mode) else None)
            self.rows[path]=row
            actual=self._verify(path,row,admitting=True)
            row['baseline']=actual
            fd_count()
            return actual
        except BaseException:
            self.rows.pop(path,None);os.close(fd);raise

    def add_current(self,path):
        # Dynamic actual Root grant/runner are immediately checked against the
        # independently bound authority fields before any workload or mutation.
        path=str(Path(path).absolute());fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_CLOEXEC)
        try:
            before=os.fstat(fd);need(stat.S_ISREG(before.st_mode) and 0<=before.st_size<=32<<20,'bounded dynamic regular file')
            digest=hashlib.sha256();size=0
            while True:
                block=os.read(fd,65536)
                if not block:break
                size+=len(block);need(size<=32<<20,'dynamic file32MiB ceiling');digest.update(block)
            need(identity(before)==identity(os.fstat(fd))==identity(Path(path).stat()),'stable dynamic FD before authority check')
            expected=dict(path=path,bytes=size,sha256=digest.hexdigest())
        finally:os.close(fd)
        self.add(expected);return expected

    def _verify(self,path,row,admitting=False):
        fd=row['fd'];need(not os.get_inheritable(fd),'held FD CLOEXEC lost')
        lexical_before=Path(path).lstat();before=os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink>=1 and 0<=before.st_size<=32<<20,'bounded regular source/tool/object input')
        os.lseek(fd,0,os.SEEK_SET);digest=hashlib.sha256();size=0
        while True:
            block=os.read(fd,65536)
            if not block:break
            size+=len(block);need(size<=32<<20,'held input32MiB ceiling');digest.update(block)
        after=os.fstat(fd);target=Path(path).stat();lexical_after=Path(path).lstat()
        need(identity(before)==identity(after)==identity(target),'held FD and current target identity/hash extent changed: '+path)
        need(identity(lexical_before)==identity(lexical_after)==row['initial_lexical'],'lexical input identity changed: '+path)
        link=os.readlink(path) if stat.S_ISLNK(lexical_after.st_mode) else None
        need(link==row['initial_link'],'lexical symlink target changed: '+path)
        observed=dict(path=path,bytes=size,sha256=digest.hexdigest(),target_identity=identity(after),
                      lexical_identity=identity(lexical_after),lexical_symlink_target=link,fd=fd,close_on_exec=True)
        expected=row['expected']
        need({key:observed[key] for key in ('path','bytes','sha256')}==expected,'exact held input byte binding changed: '+path)
        need(size==before.st_size,'held FD short read: '+path)
        if not admitting:need(observed==row['baseline'],'held source identity changed across command sequence: '+path)
        return observed

    def verify(self):
        rows=[self._verify(path,row) for path,row in self.rows.items()]
        fd_count();return rows

    def read(self,path):
        path=str(path);row=self.rows[path];self._verify(path,row)
        os.lseek(row['fd'],0,os.SEEK_SET);parts=[];size=0
        while True:
            block=os.read(row['fd'],65536)
            if not block:break
            size+=len(block);need(size<=32<<20,'held loader bound');parts.append(block)
        self._verify(path,row);return b''.join(parts)

    def close(self):
        for row in self.rows.values():os.close(row['fd'])
        self.rows.clear()


def dependencies(code):
    names={i.argval for i in dis.get_instructions(code) if i.opname=='LOAD_GLOBAL'}
    for value in code.co_consts:
        if isinstance(value,type(code)):names.update(dependencies(value))
    return names


def main():
    held=HeldInputs();namespace={};records=[]
    authorized=False;capture_created=False;timer_started=False;capture_uncertain=False
    begin=time.monotonic();cpu_begin=resource.getrusage(resource.RUSAGE_SELF)
    try:
        need(os.getuid()==os.geteuid()==1000 and os.sched_getaffinity(0)=={7},'reviewed ordinary UID1000 parentCPU7')
        # The same finite90+6 profile covers preparation/admission as well as
        # commands. Before any child exists an alarm can simply stop this owner.
        def admission_alarm(signum,frame):raise InterruptedError('Source37 finite pre-capture alarm '+str(signum))
        signal.signal(signal.SIGALRM,admission_alarm)
        signal.setitimer(signal.ITIMER_REAL,96);timer_started=True
        for key,value in ((resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),
                          (resource.RLIMIT_NOFILE,256),(resource.RLIMIT_STACK,2<<20),(resource.RLIMIT_CORE,0)):
            resource.setrlimit(key,(value,value))
        fd= os.open(SPEC,os.O_RDONLY|os.O_CLOEXEC)
        try:spec_size=os.fstat(fd).st_size
        finally:os.close(fd)
        held.add(dict(path=str(SPEC),bytes=spec_size,sha256=SPEC_SHA));spec=json.loads(held.read(SPEC))
        need(spec['profile']==PROFILE and spec['root_grant'] is None,'frozen ordinary profile; preparation grants nothing')
        for path in spec['required_absent_paths']:need(not os.path.lexists(path),'fresh attempt/output path required: '+path)
        held.add(spec['recipe']);recipe_path=Path(spec['recipe']['path']);recipe=json.loads(held.read(recipe_path))
        need(len(recipe['commands'])==2 and [c['name'] for c in recipe['commands']]==spec['command_names'],'exact retained two-observer sequence')
        need(recipe['inputs']==spec['recipe_inputs'] and len(spec['recipe_inputs'])==112,'exact112logical input rows')
        for row in spec['recipe_inputs']:held.add(row)
        need(len(held.rows)==spec['unique_recipe_input_paths']+2,'finite unique recipe inputs plus spec/recipe only')
        for key in ('helper','census'):held.add(spec[key])
        for row in spec['prefix_bindings']:held.add(row)
        held.add(spec['existing_armed_window_authority'])
        actual_object=held.rows[spec['retained_object']['path']]['baseline']
        need(actual_object['target_identity']==spec['retained_object_identity'] and actual_object['lexical_identity']==spec['retained_object_identity'],'retained actual object full identity must match successful compiler artifact')
        prefix=json.loads(held.read(Path(spec['prefix_result']['path'])))
        need(len(prefix['records'])==2 and prefix['records'][0]['join']['returncode']==0 and prefix['records'][1]['join']['returncode']==1 and prefix['CPU0_workload_retirement_proven'] and prefix['final_input_verification_error'] is None,'preserve genuine compile-pass/observer-fail/retirement/stable-input prefix')
        own_pin=held.add_current(Path(__file__).absolute());grant_pin=held.add_current(GRANT)
        grant=json.loads(held.read(GRANT));authority=grant.get('root_grant')
        need(isinstance(authority,dict) and authority.get('authority')=='/root'
             and authority.get('authorized') is True and authority.get('once') is True,
             'separate actual non-NULL one-shot Root grant required')
        need(grant.get('recipe')==spec['recipe'] and grant.get('runner')==own_pin
             and grant.get('envelope_spec')==held.rows[str(SPEC)]['expected']
             and grant.get('profile')==PROFILE and grant.get('retained_object')==spec['retained_object']
             and grant.get('retained_object_identity')==spec['retained_object_identity']
             and grant.get('same_goal')==spec['same_goal'] and grant.get('credit_run')==spec['credit_run']
             and grant.get('fixed_window')==spec['fixed_window'],'actual Root grant must bind exact frozen tuple/window/profile/output')
        cutoffs=grant.get('existing_armed_cutoffs')
        need(cutoffs==spec['existing_armed_cutoffs'],'exact existing armed wall/MONO/BOOT cutoffs only')
        receipt=grant.get('existing_armed_window_authority')
        need(receipt==spec['existing_armed_window_authority'],'exact preexisting bound window authority243a only')
        held.add(receipt)
        need(grant.get('fresh_resource_admission') is not None,'actual Root ordinary resource admission required')
        need(time.time()+96<=1793030133 and time.monotonic()+96<=cutoffs['monotonic_seconds']
             and time.clock_gettime(time.CLOCK_BOOTTIME)+96<=cutoffs['boottime_seconds'],'existing fixed wall/MONO/BOOT window remaining90+6')
        authorized=True
        # h990 functions and census bytes are read from their already-held FDs.
        raw=held.read(Path(spec['helper']['path']))
        functions={'need','write','hashed','stop','cpu_used','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
        assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
        nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.Import,ast.ImportFrom))
               or isinstance(n,ast.FunctionDef) and n.name in functions
               or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
        namespace={'__file__':spec['helper']['path']};exec(compile(ast.Module(body=nodes,type_ignores=[]),spec['helper']['path'],'exec'),namespace)
        used=set().union(*(dependencies(namespace[name].__code__) for name in functions))
        need(not used-set(namespace)-set(vars(builtins)),'exact reviewed h990 extraction dependencies')
        need(str(namespace['CENSUS_SOURCE'])==spec['census']['path'] and namespace['CENSUS_SHA']==spec['census']['sha256'],'exact reviewed census binding')
        # Install the same census leaf directly from held authenticated bytes;
        # no extra historical helper tree or sysroot is read.
        census_tree=ast.parse(held.read(Path(spec['census']['path'])))
        cls=next(n for n in census_tree.body if isinstance(n,ast.ClassDef) and n.name=='Docker')
        leaf=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_surviving_group_members')
        census_ns={'Path':Path};exec(compile(ast.Module(body=[leaf],type_ignores=[]),spec['census']['path'],'exec'),census_ns)
        namespace['_CENSUS']=census_ns[leaf.name]
        initial_inputs=held.verify();fd_count()
        mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
        host=os.statvfs('/home/holden');scratch=os.statvfs('/home/holden/mckernel-work/scratch')
        need(mem>=25501368320 and host.f_bavail*host.f_frsize>=(16<<30)+(64<<20)
             and scratch.f_bavail*scratch.f_frsize>=12<<30,'unchanged reviewed ordinary headroom floors')
        os.chdir('/home/holden/mckernel')
        os.environ.update(RUST_MIN_STACK='2097152',LC_ALL='C',OMP_NUM_THREADS='1',RAYON_NUM_THREADS='1')
        for number in namespace['STOP_SIGNALS']:signal.signal(number,namespace['stop'])
        for key,value in ((resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),
                          (resource.RLIMIT_NOFILE,256),(resource.RLIMIT_STACK,2<<20),(resource.RLIMIT_CORE,0)):
            resource.setrlimit(key,(value,value))
        authorized=True
        write(CLAIM,dict(scope=SCOPE,root_grant=grant_pin,runner=own_pin,recipe=spec['recipe'],**timestamp()))
        CAPTURE.mkdir(mode=0o700);capture_created=True
        write(CAPTURE/'profile-and-admission.json',dict(scope=SCOPE,profile=PROFILE,root_grant=grant_pin,
              recipe=spec['recipe'],runner=own_pin,envelope_spec=held.rows[str(SPEC)]['expected'],
              admitted_inputs=initial_inputs,retained_object=spec['retained_object'],retained_object_identity=spec['retained_object_identity'],
              prior_prefix_result=spec['prefix_result'],prefix_scope=spec['prefix_scope'],parent_FD_count=fd_count(),
              MemAvailable_bytes=mem,host_available_bytes=host.f_bavail*host.f_frsize,
              scratch_available_bytes=scratch.f_bavail*scratch.f_frsize,**timestamp()))
        signal.setitimer(signal.ITIMER_REAL,max(0.1,96-(time.monotonic()-begin)));timer_started=True
        for index,command in enumerate(recipe['commands']):
            current=CAPTURE/('%02d'%index);current.mkdir(mode=0o700)
            pre_inputs=held.verify()
            remaining_wall=90-(time.monotonic()-begin);remaining_cpu=int(60-namespace['cpu_used']())
            need(remaining_wall>0 and remaining_cpu>=1,'shared90wall/60CPU remaining')
            command_begin=time.monotonic();command_cpu=namespace['cpu_used']()
            write(current/'ready.json',dict(scope=SCOPE,command=command,expected_exit=0,inputs=pre_inputs,
                  remaining_wall_seconds=remaining_wall,remaining_CPU_seconds=remaining_cpu,**timestamp()))
            os.chdir(command['cwd'])
            write(current/'enqueue-observation.json',dict(scope=SCOPE,argv=command['argv'],actual_cwd=os.getcwd(),parent_affinity=sorted(os.sched_getaffinity(0)),
                  parent_FD_count=fd_count(),CPU_seconds=command_cpu,**timestamp()))
            def limits():
                os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_CPU,(remaining_cpu,remaining_cpu))
            def started_reader(pid):
                birth=namespace['process_start'](pid);affinity=sorted(os.sched_getaffinity(pid))
                write(current/'start-observation.json',dict(pid=pid,start=birth,command_affinity=affinity,**timestamp()))
                need(affinity==[0],'exact childCPU0 affinity');return birth
            capture_uncertain=True
            joined=namespace['owned_capture'](command,current,remaining_wall,limits,started_reader=started_reader)
            capture_uncertain=False
            write(current/'whole-join-and-end.json',dict(join=joined,CPU_seconds=namespace['cpu_used'](),
                  command_CPU_seconds_delta=namespace['cpu_used']()-command_cpu,
                  command_wall_seconds=time.monotonic()-command_begin,
                  maximum_child_RSS_KiB_cumulative=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                  **timestamp()))
            records.append(dict(command=command,join=joined))
            write(current/'post-command-inputs.json',dict(inputs=held.verify(),
                  parent_FD_count=fd_count(),**timestamp()))
            need(joined['returncode']==0 and joined['direct_child_joined'] and joined['group_absent']
                 and joined['closed_streams'] and not joined['error'] and not joined['retirement_error']
                 and not joined['timed_out'],'first unexpected result STOP; no retry')
        need(namespace['cpu_used']()<=60,'shared60CPU cap')
        final_inputs=held.verify()
        # Hash generated files only after all exact commands/joins/pins pass.
        outputs=[]
        for path in spec['required_absent_paths'][3:]:
            actual=namespace['hashed'](Path(path),32<<20);outputs.append(actual)
        write(RESULT,dict(scope=SCOPE,status='PASS_SOURCE37_RETAINED_TWO_STRICT_OBSERVERS_SAME_COMPILED_OBJECT',
              records=records,seconds=time.monotonic()-begin,CPU_seconds=namespace['cpu_used'](),
              maximum_child_RSS_KiB_cumulative=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
              final_inputs=final_inputs,outputs=outputs,recipe=spec['recipe'],root_grant=grant_pin,
              retained_object=spec['retained_object'],retained_object_identity=spec['retained_object_identity'],
              prior_prefix_result=spec['prefix_result'],prefix_scope=spec['prefix_scope'],compiler_replays=0,
              parent_FD_count=fd_count(),CPU0_workload_retirement_proven=True,
              default_image=False,native=False,canonical_mutations=0,**timestamp()))
        print(json.dumps(dict(status='PASS_SOURCE37_RETAINED_TWO_STRICT_OBSERVERS_SAME_COMPILED_OBJECT',result=str(RESULT))))
        return 0
    except BaseException as error:
        # h990 retains/join its own creator before returning. A failed call with
        # no returned join is uncertainty, never an inferred CPU/workload release.
        if authorized and not os.path.lexists(RESULT):
            try:failure_inputs=held.verify();failure_input_error=None
            except BaseException as binding_error:
                failure_inputs=None;failure_input_error=type(binding_error).__name__+': '+str(binding_error)
            write(RESULT,dict(scope=SCOPE,status='FAIL_STOP_PRESERVE_PREFIX_NO_RETRY',
                  final_inputs=failure_inputs,final_input_verification_error=failure_input_error,
                  retained_object=spec['retained_object'],retained_object_identity=spec['retained_object_identity'],
                  prior_prefix_result=spec['prefix_result'],prefix_scope=spec['prefix_scope'],compiler_replays=0,
                  error=type(error).__name__+': '+str(error),records=records,
                  seconds=time.monotonic()-begin,capture_created=capture_created,
                  CPU_seconds=namespace['cpu_used']() if 'cpu_used' in namespace else None,
                  maximum_child_RSS_KiB_cumulative=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                  CPU0_workload_retirement_proven=not capture_uncertain and all(r['join']['direct_child_joined']
                  and r['join']['group_absent'] and r['join']['closed_streams'] for r in records),
                  capture_retirement_uncertain=capture_uncertain,default_image=False,native=False,
                  canonical_mutations=0,**timestamp()))
        raise
    finally:
        if timer_started:signal.setitimer(signal.ITIMER_REAL,0)
        held.close()


if __name__=='__main__':sys.exit(main())
