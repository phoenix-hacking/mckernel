"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Exact four-callsite machine contract for retained Source37 object6e54; no generic
missing-edge waiver, architecture execution, disassembler or external package.
"""
import hashlib


def check_instruction_windows(code,contract):
    for window in contract['instruction_windows']:
        expected=bytes.fromhex(window['bytes_hex']);start=window['offset']
        assert code[start:start+len(expected)]==expected,(contract['caller'],window['meaning'],'instruction window mismatch')


def relocation_signature(rows):
    return [dict(offset=row['offset'],type=row['type'],target=row['target'],
                 addend=row['addend'],owning_section=row['owning_section']) for row in rows]


def check_owned_relocations(rows,symbol,contract):
    assert all(row['owning_section']==symbol['shndx'] for row in rows),'foreign section cannot prove this caller'
    assert relocation_signature(rows)==contract['owned_relocations'],(contract['caller'],'actual section-owned RELA contract changed')


def check_inline_machine_body(elf,symbol,rows,contract,object_bytes):
    assert symbol['name']==contract['caller'] and symbol['size']==contract['symbol_size']
    section=elf.sections[symbol['shndx']]
    assert section['name']==contract['section_name'] and section['flags']&6==6
    assert section['size']==symbol['size'] and symbol['value']==0,'exact standalone caller extent required'
    aliases=[s for s in elf.symbols if s['type']==2 and s['size'] and s['shndx']==symbol['shndx']]
    assert len(aliases)==1 and aliases[0]['name']==contract['caller'],'no section alias substitute'
    code=object_bytes(elf,symbol)
    check_instruction_windows(code,contract)
    assert hashlib.sha256(code).hexdigest()==contract['code_sha256'],'entire caller body must match reviewed same-object machine proof'
    check_owned_relocations(rows,symbol,contract)
    names={r['target']['name'] for r in rows}
    assert all(callee not in names for callee in contract['inlined_callees']),'this exact contract covers only observed inline absence'
    return dict(scope='exact retained-object inline instruction and owned-RELA proof',
                caller=contract['caller'],inlined_callees=contract['inlined_callees'],
                section=symbol['shndx'],code_sha256=contract['code_sha256'],
                instruction_windows=contract['instruction_windows'],owned_relocations=rows,
                no_native_or_global_lifetime_acceptance=True)
