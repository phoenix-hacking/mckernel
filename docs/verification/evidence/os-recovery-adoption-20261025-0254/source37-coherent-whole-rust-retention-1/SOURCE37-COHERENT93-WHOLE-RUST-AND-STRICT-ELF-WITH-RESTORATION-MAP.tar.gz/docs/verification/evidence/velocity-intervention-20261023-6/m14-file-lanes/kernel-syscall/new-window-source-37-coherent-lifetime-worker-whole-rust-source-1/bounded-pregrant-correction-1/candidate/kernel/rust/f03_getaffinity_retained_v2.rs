// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
// Private, default-OFF successor. Preserve the already-qualified setscheduler body.
use core::ffi::c_void;

use crate::abi::{CInt, CLong, CULong, SizeT, Thread};

use super::{
    sched_affinity_copy_len, sched_affinity_permission_result, sched_errno,
    sched_getaffinity_len_result, sched_proc_euid, sched_proc_ruid, sched_thread_proc,
    SchedCopyToUserFn, SchedFindThreadFn, SchedReleaseThreadFn, SchedSyscallOffsets,
    SchedThreadUnlockFn, EFAULT, EINVAL, ESRCH,
};

/// Diagnostic only: this callback acquires, consumes and transfers NO reference.
/// It is a new versioned ABI, never a cast or wrapper of the old int-returning hold.
pub type SchedAffinityWarningOnlyFnV2 = unsafe extern "C" fn(usize);

unsafe extern "C" {
    fn process_hold_thread_warn_exited_result(status: CInt) -> CInt;
    fn process_hold_thread_warn_bridge(thread: *mut c_void);
}

/// Preserve the genuine hold warning without an unnecessary counter increment.
///
/// # Safety
/// The syscall's current-thread borrow or its one positive lookup reference keeps
/// this exact initialized Thread readable throughout the synchronous diagnostic.
/// The existing warning provider reads tid and prints; it must not release an edge.
#[no_mangle]
pub unsafe extern "C" fn sched_affinity_hold_warning_v2(thread_address: usize) {
    let thread = thread_address as *const Thread;
    // SAFETY: The caller's actual borrow/edge pins aligned Thread storage. Match
    // the original hold's status observation and conditional diagnostic ordering.
    let status = unsafe { (*thread).status };
    if unsafe { process_hold_thread_warn_exited_result(status) } != 0 {
        unsafe { process_hold_thread_warn_bridge(thread.cast_mut().cast()) };
    }
}

const _: SchedAffinityWarningOnlyFnV2 = sched_affinity_hold_warning_v2;

pub(super) struct RetainedAffinityTarget {
    pub(super) address: usize,
    release: Option<SchedReleaseThreadFn>,
}

impl Drop for RetainedAffinityTarget {
    fn drop(&mut self) {
        if let Some(release) = self.release.take() {
            // SAFETY: Some means exactly one actual acquired edge. No field or
            // pointer derived from this allocation is used after this call.
            unsafe { release(self.address) };
        }
    }
}

pub(super) unsafe fn select_retained_affinity_target(
    tid: CInt,
    current_thread: usize,
    offsets: &SchedSyscallOffsets,
    find: Option<SchedFindThreadFn>,
    unlock: Option<SchedThreadUnlockFn>,
    warn: Option<SchedAffinityWarningOnlyFnV2>,
    release: SchedReleaseThreadFn,
) -> Result<RetainedAffinityTarget, CLong> {
    let Some(warn) = warn else { return Err(sched_errno(EINVAL)); };
    if tid == 0 {
        // SAFETY: Same live current-thread borrow admitted by the selected syscall.
        unsafe { warn(current_thread) };
        return Ok(RetainedAffinityTarget { address: current_thread, release: None });
    }
    let (Some(find), Some(unlock)) = (find, unlock) else {
        return Err(sched_errno(EINVAL));
    };
    // SAFETY: Actual Source22 positive-only find transfers one edge after releasing
    // its hash reader. A failed acquisition returns NULL and no retained address.
    let address = unsafe { find(tid) };
    if address == 0 {
        return Err(sched_errno(ESRCH));
    }
    let mut target = RetainedAffinityTarget { address, release: Some(unlock) };
    // SAFETY: The lookup edge pins this Thread and its Process through permission.
    let current_process = unsafe { sched_thread_proc(current_thread, offsets) };
    let target_process = unsafe { sched_thread_proc(address, offsets) };
    if current_process == 0 || target_process == 0 {
        return Err(sched_errno(EINVAL));
    }
    let permission = sched_affinity_permission_result(
        unsafe { sched_proc_euid(current_process, offsets) },
        unsafe { sched_proc_ruid(target_process, offsets) },
        unsafe { sched_proc_euid(target_process, offsets) },
    );
    if permission != 0 {
        return Err(permission as CLong);
    }
    // SAFETY: Preserve the old second hold's diagnostic only. Its otherwise
    // redundant increment+unlock can overflow a genuine signed counter at MAX.
    // Carry the already-positive lookup edge directly to the original final
    // release instead; real thread_unlock itself is just release_thread.
    unsafe { warn(address) };
    target.release = Some(release);
    Ok(target)
}

/// Copy affinity while retaining the exact acquired allocation without reholding.
///
/// # Safety
/// Actual offsets/cpuset_size identify readable initialized native mask storage.
/// Foreign find has the Source22 positive-reference contract. Current is borrowed
/// under the existing syscall lifetime. Warning callbacks are diagnostic only;
/// unlock/release consume the one edge on their respective original paths.
/// Usercopy preserves its genuine C-long/MM/fault contract, with no hash/IRQ lock
/// held. Mask-writer synchronization is unchanged and remains separately unassessed.
#[no_mangle]
pub unsafe extern "C" fn sched_getaffinity_retained_v2(
    tid: CInt,
    len: SizeT,
    user_mask: CULong,
    current_thread: usize,
    cpuset_size: SizeT,
    num_processors: CInt,
    offsets: *const SchedSyscallOffsets,
    find: Option<SchedFindThreadFn>,
    unlock: Option<SchedThreadUnlockFn>,
    warn: Option<SchedAffinityWarningOnlyFnV2>,
    release: Option<SchedReleaseThreadFn>,
    copy_to: Option<SchedCopyToUserFn>,
) -> CLong {
    if current_thread == 0 || cpuset_size == 0 || offsets.is_null() || num_processors < 0 {
        return sched_errno(EINVAL);
    }
    let length_result = sched_getaffinity_len_result(len, num_processors);
    if length_result != 0 {
        return length_result as CLong;
    }
    let Some(copy_to) = copy_to else { return sched_errno(EINVAL); };
    let Some(release) = release else { return sched_errno(EINVAL); };
    let copy_len = sched_affinity_copy_len(len, cpuset_size);
    // SAFETY: Caller supplies aligned immutable offsets for this synchronous call.
    let offsets = unsafe { &*offsets };
    let target = match unsafe {
        select_retained_affinity_target(tid, current_thread, offsets, find, unlock, warn, release)
    } {
        Ok(target) => target,
        Err(error) => return error,
    };
    let source = target.address.wrapping_add(offsets.thread_cpu_set_offset) as *const u8;
    // SAFETY: The exact target borrow/edge survives the whole faulting usercopy.
    let copied = unsafe { copy_to(user_mask, source, copy_len) };
    drop(target);
    if copied < 0 { sched_errno(EFAULT) } else { copy_len as CLong }
}
