Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This finite envelope prepares only the independently accepted corrected strict
observer and unchanged qualified bounded arithmetic/logger oracle. It preserves
recipe38b85fa5, actual object6e54dc57/18206144B, all source/donor/compiler inputs,
and original failed prefix586cbbc3. ROOT grant is NULL. Neither runner nor observer
has executed in this packet, and no compiler command exists in the recipe.

The actual object's full dev/inode/uid/gid/mode/nlink/size/mtime_ns/ctime_ns identity
is frozen in ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json. Its O_RDONLY CLOEXEC FD remains
held across the sequence, and full identity/hash/path relations are verified
before/after both commands and final success/failure. The 112 logical recipe rows
(111 unique paths), exact proof/helper/observer, h990/census, runner/grant/spec/
recipe, selected actual-prefix records and window receipt use the same reviewed
held-FD contract; parent FD count stays below256. No unchanged Rust compile,
sysroot/history inventory, target execution or cleanup is included.

The original real compiler success, named-edge-only failure, warnings and actual
joins remain referenced/byte-bound. Admission checks that genuine prefix has
exactly compile0/observer1, proven joined retirement and stable original inputs.
Both success and failure results retain that prefix and actual object identity.
They do not relabel the consumed 3-command attempt as passing or replay its compile.

The h990 owned_capture and held-FD code are reused from the admitted 3-command
envelope. Compiler sampling/output-directory creation logic is removed; both
commands are exact Python observers at their original declared cwd/argv. Only
fresh claim/capture/envelope-result and two absent oracle-result paths are written.
No existing output directory or object is recreated, removed or written.

Profile remains parentCPU7/childCPU0/onejob/AS2GiB/sharedCPU60s/work90s+retirement6s/
FS32MiB/FD256/stack2MiB/core0, with identical existing admission floors. Durable
ready/enqueue/start/end, command CPU/wall, cumulative child RSS, raw stdout/stderr,
direct joins, group/closed-stream proof and stable inputs are captured. First
unexpected result stops and preserves its prefix; no automatic retry occurs.

Existing window authority is only the bound POST-DETACH-NEW18H-VERIFIED receipt
243a7419/4115B. It is referenced, not copied. Exact existing cutoffs are UTCepoch
1793030133, MONOTONIC812240.493656513 and BOOTTIME827578.62070498. The runner compares
ROOT grant against those unchanged values and requires90+6s remaining on all
clocks; none is derived/reset. Same goal01a170fb-57c3-7ab3-862d-8005bef92a63 and
creditrun7f4af94a83b14cc08f97401f5891d965 remain. No account/control framework change
or second launcher is introduced.

ROOT-GRANT-TEMPLATE.NULL.NOT-GRANTED.json and EXACT-ROOT-COMMAND.PREPARED-NOT-GRANTED.json
bind the concrete runner/spec/recipe/object identity. Only ROOT may create the
separate actual one-shot grant with fresh ordinary admission after review. This
READY/source packet grants nothing. Default image/native/global-lifetime/whole-file
C-retirement acceptance remains OPEN.
