"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Cheap read-only machine-contract diagnosis and in-memory negative controls.
Never invokes compiler, full ownership observers, guest or target code.
"""
from pathlib import Path
import ast,copy,hashlib,json,struct
ROOT=Path(__file__).resolve().parent;PRIOR=ROOT.parent
recipe=json.loads((ROOT/'REMAINING-TWO-OBSERVERS.PREPARED-NOT-GRANTED.json').read_text());contract=json.loads((ROOT/'EXACT-FOUR-INLINE-MACHINE-CONTRACT.json').read_text());main=json.loads(Path(recipe['unchanged_original_recipe']['path']).read_text());base_recipe=json.loads(Path(main['base_recipe']['path']).read_text());r=base_recipe['Elf_source'];raw=Path(r['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']
nodes=[n for n in ast.parse(raw).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.ClassDef) and n.name=='Elf' or isinstance(n,ast.FunctionDef) and n.name in {'object_bytes','owning_relocations'}];ns={'Path':Path,'struct':struct};exec(compile(ast.Module(body=nodes,type_ignores=[]),r['path'],'exec'),ns)
helper={};exec(compile((ROOT/'inline_machine_contract.py').read_bytes(),str(ROOT/'inline_machine_contract.py'),'exec'),helper)
elf=ns['Elf'](Path(recipe['retained_object']['path']));base=ns['Elf'](Path(main['retained_accepted_whole_Rust_object']['path']));rows=[]
def rejection(label,fn):
 try:fn()
 except AssertionError as e:rows.append(dict(label=label,rejected=True,reason=str(e)));return
 raise AssertionError('negative did not reject: '+label)
for name,c in contract['contracts'].items():
 s=next(s for s in elf.symbols if s['name']==name and s['shndx']);relocs=ns['owning_relocations'](elf,s);code=ns['object_bytes'](elf,s)
 helper['check_inline_machine_body'](elf,s,relocs,c,ns['object_bytes']);rows.append(dict(label='actual retained '+name+' exact machine diagnosis',positive=True))
 baseline_name='process_destroy_thread_hash_detach_bridge' if name=='process_destroy_thread_hash_detach_candidate_v3' else name
 old=next(s for s in base.symbols if s['name']==baseline_name and s['shndx'])
 old_code=ns['object_bytes'](base,old)
 rejection('actual accepted baseline old '+baseline_name+' cannot satisfy new semantic windows',lambda:helper['check_instruction_windows'](old_code,c))
 bad=copy.deepcopy(relocs);bad[0]['owning_section']+=1
 rejection(name+' foreign-section RELA cannot prove caller',lambda:helper['check_owned_relocations'](bad,s,c))
 bad=copy.deepcopy(relocs);bad[0]['target']['name']='wrong_existing_provider'
 rejection(name+' substituted RELA target rejected',lambda:helper['check_owned_relocations'](bad,s,c))
 alias=copy.copy(elf);alias.symbols=elf.symbols+[dict(s,name='fabricated_section_alias')]
 rejection(name+' overlapping section alias rejected',lambda:helper['check_inline_machine_body'](alias,s,relocs,c,ns['object_bytes']))
mutations=[('find_thread',0x265,0xfe,'positive saturation guard must continue rejecting MAX'),('find_thread',0x26e,0x90,'positive acquisition must remain atomic'),('find_thread',0x272,0x18,'positive CAS must target genuine refcount field'),('find_thread',0x276,0x74,'failed CAS must retry before reader release'),('process_destroy_thread_hash_detach_candidate_v3',0x14e,0x90,'detach must preserve writer acquisition'),('process_destroy_thread_hash_detach_candidate_v3',0x161,0x90,'detach must recheck membership inside writer'),('sys_sched_getaffinity',0x104,0x85,'current borrow must bypass lookup'),('sys_sched_getaffinity',0x1dd,0x75,'current borrow must never consume lookup edge'),('sched_do_migrate_public',0x2d0,0x90,'mask selection requires reservation acquisition'),('sched_do_migrate_public',0x82c,0x90,'committed transfer requires reservation unlock'),('sched_do_migrate_public',0xc77,0x78,'runqueue must restore its own IRQ token')]
for name,offset,value,meaning in mutations:
 c=contract['contracts'][name];s=next(s for s in elf.symbols if s['name']==name and s['shndx']);code=bytearray(ns['object_bytes'](elf,s));assert code[offset]!=value;code[offset]=value
 rejection('semantic mutation: '+meaning,lambda:helper['check_instruction_windows'](bytes(code),c))
assert hashlib.sha256(Path(recipe['retained_object']['path']).read_bytes()).hexdigest()==recipe['retained_object']['sha256']
result=dict(scope=recipe['scope'],status='PASS_LOCAL_MACHINE_DIAGNOSIS_AND_IN_MEMORY_CONTROLS_ONLY',positive=sum(x.get('positive',False) for x in rows),negative=sum(x.get('rejected',False) for x in rows),controls=rows,full_observer_executions=0,logger_oracle_executions=0,compiler_replays=0,target_execution=False,formal_acceptance=False)
(ROOT/'LOCAL-MACHINE-CONTRACT-REGRESSION.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],result['positive'],result['negative'])
