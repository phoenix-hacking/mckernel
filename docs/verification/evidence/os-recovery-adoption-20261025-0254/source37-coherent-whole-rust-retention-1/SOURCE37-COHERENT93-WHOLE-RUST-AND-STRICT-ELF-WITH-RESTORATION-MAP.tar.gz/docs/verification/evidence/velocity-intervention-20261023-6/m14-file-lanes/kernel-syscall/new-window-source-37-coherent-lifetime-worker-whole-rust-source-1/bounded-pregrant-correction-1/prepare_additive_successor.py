"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One additive source-only correction for the complete independent pregrant batch.
"""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent;KS=OLD.parent
BASE=KS/'default290-corrected-real-crate-source-1/candidate'
BOUNDED=BASE.parent/'bounded-logger-initializer-observer-correction-1'
def pin(p):
    raw=p.read_bytes();return dict(path=str(p.absolute()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def writejson(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
assert not (ROOT/'candidate').exists()
shutil.copytree(OLD/'candidate',ROOT/'candidate');(ROOT/'output-1').mkdir()
# Preserve current accepted canonical CMake default pairing; add new selection only.
canonical=Path('/home/holden/mckernel/kernel/CMakeLists.txt')
assert pin(canonical)['sha256']=='f29336679e462746822d5ce9efe1a74491fbea1f0cbb46d56cfdc48ae082b3cc'
p=ROOT/'candidate/kernel/CMakeLists.txt';s=p.read_text()
s=s.replace('COMPILE_DEFINITIONS "MCKERNEL_RUST_F02_POSITIVE_REFERENCE_LOOKUP;MCKERNEL_RUST_PROCESS_GLOBAL_STORAGE")','COMPILE_DEFINITIONS MCKERNEL_RUST_F02_POSITIVE_REFERENCE_LOOKUP)',1)
needle='\tif (MCKERNEL_HOST_IRQ_ABI STREQUAL "linux-6.12")\n\t\tset_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/syscall.c" APPEND PROPERTY';assert s.count(needle)==1
s=s.replace(needle,'''\tif (MCKERNEL_HOST_IRQ_ABI STREQUAL "linux-6.12")
\t\t# Pair the existing Rust process_global_storage_candidate provider above.
\t\tset_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/process.c" APPEND PROPERTY
\t\t\tCOMPILE_DEFINITIONS MCKERNEL_RUST_PROCESS_GLOBAL_STORAGE)
\t\tset_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/syscall.c" APPEND PROPERTY''',1)
p.write_text(s)
cmake_diff=list(difflib.unified_diff(canonical.read_text().splitlines(True),s.splitlines(True),fromfile='a/kernel/CMakeLists.txt',tofile='b/kernel/CMakeLists.txt'))
assert not any(x.startswith('-') and not x.startswith('---') for x in cmake_diff)
# Transport actual qualified bounded observer, changing bindings/report labels only.
s=(BOUNDED/'observe_actual_default_corrected_object.NOT-RUN.py').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6b5a53a51d5b392a91acb30eb9487f036ab1b631f985964730034933c4af91f6'
s=s.replace("'EXACT-RETAINED-WHOLE-RUST-OBSERVER-CORRECTION.NOT-GRANTED.json'","'ORIGINAL-ARITHMETIC-LOGGER-ORACLE.RECIPE.json'")
s=s.replace("old = Elf(Path(recipe['actual_old_Rust_object']['path']))","# Pin exact directly consumed historical object immediately before parsing.\npinned_bytes(recipe['actual_old_Rust_object'])\nold = Elf(Path(recipe['actual_old_Rust_object']['path']))")
s=s.replace('PASS_ACTUAL_DEFAULT_WHOLE_RUST_HANDLER_NO_PANIC_AND_FOUR_LOCAL_LOGGERS','PASS_CHANGED_CANDIDATE_HANDLER_NO_PANIC_AND_FOUR_LOCAL_LOGGERS').replace("'actual_default_flags_without_explicit_codegen_units': True,","'actual_default_flags_without_explicit_codegen_units': False,\n    'codegen_flags_retained_but_five_explicit_candidate_cfgs_added': True,")
s=s.replace('ACTUAL-DEFAULT-CORRECTED-WHOLE-RUST-OWNERSHIP.json','ACTUAL-COHERENT-ORIGINAL-LOGGER-ARITHMETIC-OWNERSHIP.json').replace('PASS actual-default wholeRust','PASS changed-candidate wholeRust')
(ROOT/'observe_original_arithmetic_logger_oracle.NOT-RUN.py').write_text(s)
original_recipe=json.loads((BOUNDED/'EXACT-RETAINED-WHOLE-RUST-OBSERVER-CORRECTION.NOT-GRANTED.json').read_text())
# Only direct consumed oracle fields, avoiding unrelated historical recipe recursion.
oracle_recipe={k:original_recipe[k] for k in ['scope','Elf_source','qualified_descriptor_helper','actual_old_Rust_object']}
oracle_recipe['new_Rust_object_path']=str(ROOT/'output-1/coherent-lifetime-worker-rust.o');oracle_recipe['candidate_policy']=pin(ROOT/'candidate/kernel/rust/syscall_policy.rs')
writejson(ROOT/'ORIGINAL-ARITHMETIC-LOGGER-ORACLE.RECIPE.json',oracle_recipe)
# Preserve strict new provider/import/storage/production edge oracle.
s=(OLD/'observe_coherent_object.NOT-RUN.py').read_text()
s=s.replace("base_recipe=json.loads(Path(recipe['base_recipe']['path']).read_text())\n",'')
needle="    return raw\n";assert s.count(needle)==1
s=s.replace(needle,needle+"base_recipe=json.loads(pinned(recipe['base_recipe']))\n",1)
s=s.replace("base_path=Path(base_recipe['new_Rust_object_path']);assert hashlib.sha256(base_path.read_bytes()).hexdigest()=='f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003'","pinned(recipe['retained_accepted_whole_Rust_object'])\nbase_path=Path(recipe['retained_accepted_whole_Rust_object']['path'])")
(ROOT/'observe_coherent_object.NOT-RUN.py').write_text(s)
# Rebind exact changed source manifest. CMake current authority explicitly f293.
m=json.loads((OLD/'BASE-TO-CHANGED-MANIFEST.json').read_text())
m['status']='ADDITIVE_CORRECTED_SOURCE_PREPARED_NOT_EXECUTED';m['supersedes_blocked_source_tuple']=pin(OLD/'BLOCKED-SOURCE-ORIGINAL-TUPLE.json')
for row in m['files']:
    row['candidate']=pin(ROOT/'candidate'/row['relative'])
    if row['relative']=='kernel/CMakeLists.txt':row['base']=pin(canonical)
m['supplementary_production_source_root']='Three C/header inputs retain recorded actual_source_root; CMake current canonical f293 explicit row overrides historical f54.'
m['supplementary_current_CMake']=pin(canonical)
writejson(ROOT/'BASE-TO-CHANGED-MANIFEST.json',m)
patch=[]
for row in m['files']:
    if row['kind']=='unchanged':continue
    base=Path(row['base']['path']) if row['base'] else None;p=Path(row['candidate']['path'])
    patch.extend(difflib.unified_diff(base.read_text().splitlines(True) if base else [],p.read_text().splitlines(True),fromfile='a/'+row['relative'] if base else '/dev/null',tofile='b/'+row['relative']))
(ROOT/'COHERENT-SUCCESSOR.patch').write_text(''.join(patch))
# Direct consumed input closure only: generated artifacts/results are outputs.
j=json.loads((OLD/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json').read_text())
for c in j['commands']:
    c['argv']=[x.replace(str(OLD/'candidate'),str(ROOT/'candidate')).replace(str(OLD/'output-1'),str(ROOT/'output-1')).replace(str(OLD/'observe_'),str(ROOT/'observe_')) for x in c['argv']];c['cwd']=str(ROOT)
j['status']='ADDITIVE_PREGRANT_CORRECTED_NOT_EXECUTED';j['root_grant']=None
assert j['base_recipe']['sha256']=='4b8f2b9b16354864d675c87beac52529a8b7786d2047a69436d5c58ef824a6f5'
base_recipe=json.loads(Path(j['base_recipe']['path']).read_text())
j['retained_accepted_whole_Rust_object']=pin(Path(base_recipe['new_Rust_object_path']))
assert j['retained_accepted_whole_Rust_object']['sha256']=='f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003'
# Make Python tool binding explicit at exactly its command argv spelling.
python_path=Path(j['commands'][1]['argv'][0]);j['tools']['Python']=pin(python_path)
assert j['commands'][2]['argv'][0]==str(python_path)
j['inputs']=[row['candidate'] for row in m['files']]
direct=[j['base_recipe'],j['retained_accepted_whole_Rust_object'],oracle_recipe['actual_old_Rust_object'],oracle_recipe['Elf_source'],oracle_recipe['qualified_descriptor_helper'],j['tools']['Python']]
j['consumed_inputs']=direct
j['inputs']+=direct
for n in ['BASE-TO-CHANGED-MANIFEST.json','observe_coherent_object.NOT-RUN.py','observe_original_arithmetic_logger_oracle.NOT-RUN.py','ORIGINAL-ARITHMETIC-LOGGER-ORACLE.RECIPE.json']:
    j['inputs'].append(pin(ROOT/n))
j['observer']=pin(ROOT/'observe_coherent_object.NOT-RUN.py')
j['retained_original_helper_inputs']={k:oracle_recipe[k] for k in ['Elf_source','qualified_descriptor_helper','actual_old_Rust_object']}
j['envelope_required_binding_contract']={
    'root_grant':None,'fresh_root_resource_grant_required':True,
    'input_binding':'Every inputs/consumed_inputs row must be verified before and after the complete three-command sequence through opened read-only FDs: expected size/SHA256, device/inode/mode/size/mtime_ns/ctime_ns stable before/after hashing and across sequence; held FD and current pathname identity must match. No silent substitution.',
    'failure':'Any pre/post mismatch fails closed and preserves capture; no compiler replay or oracle weakening.',
    'generated_outputs':['output-1/coherent-lifetime-worker-rust.o','ACTUAL-COHERENT-WHOLE-OBJECT-OWNERSHIP.json','ACTUAL-COHERENT-ORIGINAL-LOGGER-ARITHMETIC-OWNERSHIP.json'],
    'generated_output_pins_before_execution':False,
    'existing_owned_capture_profile':'CPU0/1job/2GiBAS/60sharedCPU/90wall/32MiBfile/6s-cleanup; original join/group/stream closure remains required.'}
j['qualified_bounded_oracle_source']=pin(BOUNDED/'observe_actual_default_corrected_object.NOT-RUN.py')
j['original_oracle_changes']='Actual bounded checker: only recipe/current source/output/reporting transport plus immediate retained-old-object pin; strict initialized-source extent, uniqueness and semantic predicates retained.'
writejson(ROOT/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json',j)
# Cheap source-only checks: no compiler, CMake, object observer or workload.
for row in m['files']:
    assert pin(Path(row['candidate']['path']))==row['candidate']
for p in [ROOT/'prepare_additive_successor.py',ROOT/'observe_coherent_object.NOT-RUN.py',ROOT/'observe_original_arithmetic_logger_oracle.NOT-RUN.py']:ast.parse(p.read_text())
for row in direct:assert pin(Path(row['path']))==row
assert (ROOT/'candidate/kernel/rust/abi.rs').read_bytes()==(BASE/'kernel/rust/abi.rs').read_bytes()
assert not any('codegen-units' in x for x in j['commands'][0]['argv'])
assert len(j['commands'])==3 and j['root_grant'] is None
old_checks=json.loads((OLD/'SOURCE-PREPARATION-CHECKS.json').read_text())
for row in old_checks['module_donor_equality']:
    assert (ROOT/'candidate/kernel/rust'/row['module']).read_bytes()==Path(row['donor']).read_bytes()
lines=(ROOT/'candidate/kernel/rust/syscall_policy.rs').read_text().splitlines();initializer_proof={}
for marker in ['F06_PROCESS_VM_IOV_LOCAL_DEBUG','F06_PROCESS_VM_IOV_REMOTE_DEBUG','F06_PROCESS_VM_FOUND_DEBUG','F06_PROCESS_VM_COPY_DEBUG']:
    starts=[i for i,line in enumerate(lines) if 'static mut '+marker+':' in line];assert len(starts)==1;start=starts[0]
    end=next(i for i in range(start,len(lines)) if lines[i].strip()=='};')
    owned=[i+1 for i in range(start,end+1) if 'line_flags: line!()' in lines[i]];assert len(owned)==1
    initializer_proof[marker]=dict(start=start+1,end=end+1,owned_line=owned[0])
writejson(ROOT/'SOURCE-PREPARATION-CHECKS.json',dict(scope=j['scope'],status='PASS_SOURCE_ONLY_COMPLETE_PREGRANT_CORRECTION_BATCH',candidate_files=len(m['files']),donor_modules_identical=6,abi_unchanged=True,current_CMake_base=pin(canonical),CMake_patch_only_additions=True,bounded_logger_initializer_lines=initializer_proof,direct_consumed_pins=len(direct),compiler_executions=0,cmake_executions=0,object_observer_executions=0,root_grant=None))
print(json.dumps(dict(status='ADDITIVE_SOURCE_SUCCESSOR_PREPARED_NO_EXECUTION',files=len(m['files']),direct_consumed_rows=len(direct),patch=pin(ROOT/'COHERENT-SUCCESSOR.patch'),recipe=pin(ROOT/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json'))))
