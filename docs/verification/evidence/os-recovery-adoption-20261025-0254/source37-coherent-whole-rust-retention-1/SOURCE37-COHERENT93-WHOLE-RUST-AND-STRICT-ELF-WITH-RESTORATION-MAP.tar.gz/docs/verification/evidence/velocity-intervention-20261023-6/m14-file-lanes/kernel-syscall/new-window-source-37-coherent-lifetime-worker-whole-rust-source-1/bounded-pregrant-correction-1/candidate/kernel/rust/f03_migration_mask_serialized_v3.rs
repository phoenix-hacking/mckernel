// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
use super::{CInt, CULong, SchedDoMigrateOffsets, SchedMigrateSpinLockFn,
    SchedMigrateSpinUnlockFn, SchedMigrateNoirqLockFn, SchedMigrateNoirqUnlockFn,
    SchedMigrateCpuLocalFn, SchedMigrateWaitqWakeupFn, SchedMigrateVectorFn,
    SchedMigrateInterruptFn, SchedDoMigrateLogFn, EINVAL, read_volatile,
    write_volatile, list_next, list_detach_poison_addr, cpu_set_isset_addr,
    sched_double_rq_lock, list_detach_counted_addr, list_add_tail_counted_addr,
    cpu_clear_bit_addr, cpu_set_bit_addr, sched_double_rq_unlock};

/// Own only the original reservation-lock acquisition; never a Thread borrow.
struct ReservationAdmission {
    address: usize,
    irqstate: CULong,
    unlock: SchedMigrateSpinUnlockFn,
}

impl Drop for ReservationAdmission {
    fn drop(&mut self) {
        // SAFETY: Construction follows the paired lock callback. Each path drops
        // once, before any wakeup, IPI, log, wait, reference release or usercopy.
        unsafe { (self.unlock)(self.address, self.irqstate) };
    }
}

/// Consume existing synchronous requests while serializing mask/CPU application.
///
/// # Safety
/// Original worker's live CPU/Thread/request/VM and exact-offset contracts apply.
/// Each request remains stack-live until its original wakeup/waitq_finish route.
/// The selected writer and this worker share the SAME reservation lock. Every
/// selected CPU/runqueue transfer must use the described reservation -> runqueue
/// order; no selected reservation owner may enqueue/wait for migration while
/// holding it. This worker nests migq -> reservation -> ordered runqueues and
/// releases reservation after transfer, before callbacks. Existing callbacks and
/// raw list helpers retain their ABI and exclusions. No Rust reference to kernel
/// mutable state spans a callback. Process-mask stability and unassessed writers
/// are prerequisites, not conclusions from this body.
#[no_mangle]
pub unsafe extern "C" fn sched_do_migrate_mask_serialized_v3(
    current_cpu_id: CInt,
    current_cpu_addr: usize,
    reservation_lock_addr: usize,
    cpu_set_bits: CInt,
    need_resched_flag: u32,
    vector_key: CInt,
    offsets: *const SchedDoMigrateOffsets,
    lock_fn: Option<SchedMigrateSpinLockFn>,
    unlock_fn: Option<SchedMigrateSpinUnlockFn>,
    noirq_lock_fn: Option<SchedMigrateNoirqLockFn>,
    noirq_unlock_fn: Option<SchedMigrateNoirqUnlockFn>,
    cpu_local_fn: Option<SchedMigrateCpuLocalFn>,
    waitq_wakeup_fn: Option<SchedMigrateWaitqWakeupFn>,
    vector_fn: Option<SchedMigrateVectorFn>,
    interrupt_fn: Option<SchedMigrateInterruptFn>,
    log_fn: Option<SchedDoMigrateLogFn>,
) -> CInt {
    if current_cpu_addr == 0 || reservation_lock_addr == 0 || cpu_set_bits <= 0 || offsets.is_null() {
        return -EINVAL;
    }
    let (
        Some(lock),
        Some(unlock),
        Some(noirq_lock),
        Some(noirq_unlock),
        Some(cpu_local),
        Some(waitq_wakeup),
        Some(vector),
        Some(interrupt),
    ) = (
        lock_fn,
        unlock_fn,
        noirq_lock_fn,
        noirq_unlock_fn,
        cpu_local_fn,
        waitq_wakeup_fn,
        vector_fn,
        interrupt_fn,
    )
    else {
        return -EINVAL;
    };

    let offsets = unsafe { &*offsets };
    let migq_lock_addr = current_cpu_addr.wrapping_add(offsets.cpu_migq_lock_offset);
    let migq_head = current_cpu_addr.wrapping_add(offsets.cpu_migq_offset);
    let migration_irqstate = unsafe { lock(migq_lock_addr) };
    let mut processed: CInt = 0;
    let mut entry = unsafe { list_next(migq_head) };

    while entry != migq_head {
        let next = unsafe { list_next(entry) };
        let req_addr = entry.wrapping_sub(offsets.req_list_offset);
        let thread_addr = unsafe {
            read_volatile(req_addr.wrapping_add(offsets.req_thread_offset) as *const usize)
        };

        processed = processed.wrapping_add(1);
        unsafe {
            list_detach_poison_addr(entry);
        }

        if thread_addr == 0 {
            unsafe {
                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            }
            entry = next;
            continue;
        }

        // One authority covers the live mask and its CPU/runqueue application.
        // No reference acquisition, usercopy, wait, log or IPI occurs in this scope.
        let mask_admission = ReservationAdmission {
            address: reservation_lock_addr,
            irqstate: unsafe { lock(reservation_lock_addr) },
            unlock,
        };
        let thread_cpu_id = unsafe {
            read_volatile(thread_addr.wrapping_add(offsets.thread_cpu_id_offset) as *const CInt)
        };
        if thread_cpu_id != current_cpu_id {
            drop(mask_admission);
            unsafe {
                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            }
            entry = next;
            continue;
        }

        let thread_cpu_set = thread_addr.wrapping_add(offsets.thread_cpu_set_offset);
        if unsafe { cpu_set_isset_addr(thread_cpu_set, current_cpu_id, cpu_set_bits) } {
            drop(mask_admission);
            unsafe {
                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            }
            entry = next;
            continue;
        }

        let mut target_cpu_id = 0;
        while target_cpu_id < cpu_set_bits {
            if unsafe { cpu_set_isset_addr(thread_cpu_set, target_cpu_id, cpu_set_bits) } {
                break;
            }
            target_cpu_id += 1;
        }
        if target_cpu_id == cpu_set_bits {
            drop(mask_admission);
            unsafe {
                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            }
            entry = next;
            continue;
        }

        let target_cpu_addr = unsafe { cpu_local(target_cpu_id) };
        if target_cpu_addr == 0 {
            drop(mask_admission);
            unsafe {
                waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            }
            entry = next;
            continue;
        }

        let runqueue_irqstate = unsafe {
            sched_double_rq_lock(current_cpu_addr, target_cpu_addr, offsets, lock, noirq_lock)
        };
        unsafe {
            list_detach_counted_addr(
                thread_addr.wrapping_add(offsets.thread_sched_list_offset),
                current_cpu_addr.wrapping_add(offsets.cpu_runq_len_offset),
            );
        }
        let old_cpu_id = unsafe {
            read_volatile(thread_addr.wrapping_add(offsets.thread_cpu_id_offset) as *const CInt)
        };
        unsafe {
            write_volatile(
                thread_addr.wrapping_add(offsets.thread_cpu_id_offset) as *mut CInt,
                target_cpu_id,
            );
            list_add_tail_counted_addr(
                thread_addr.wrapping_add(offsets.thread_sched_list_offset),
                target_cpu_addr.wrapping_add(offsets.cpu_runq_offset),
                target_cpu_addr.wrapping_add(offsets.cpu_runq_len_offset),
            );
        }

        // cpu_id and both runqueue memberships are now committed together.
        // A later setter observes the new CPU when enqueueing its own request.
        // Keep existing runqueue exclusion for VM bookkeeping, but release the
        // reservation authority before invoking any externally visible callback.
        drop(mask_admission);

        let moving_vm = unsafe {
            read_volatile(thread_addr.wrapping_add(offsets.thread_vm_offset) as *const usize)
        };
        let mut clear_old_cpu = true;
        let runq_head = current_cpu_addr.wrapping_add(offsets.cpu_runq_offset);
        let mut runq_entry = unsafe { list_next(runq_head) };
        while runq_entry != runq_head {
            let candidate = runq_entry.wrapping_sub(offsets.thread_sched_list_offset);
            let candidate_vm = unsafe {
                read_volatile(candidate.wrapping_add(offsets.thread_vm_offset) as *const usize)
            };
            if candidate_vm != 0 && candidate_vm == moving_vm {
                clear_old_cpu = false;
                break;
            }
            runq_entry = unsafe { list_next(runq_entry) };
        }

        if moving_vm != 0 {
            let address_space = unsafe {
                read_volatile(
                    moving_vm.wrapping_add(offsets.vm_address_space_offset) as *const usize
                )
            };
            if address_space != 0 {
                let cpu_set_addr = address_space.wrapping_add(offsets.address_space_cpu_set_offset);
                let cpu_set_lock_addr =
                    address_space.wrapping_add(offsets.address_space_cpu_set_lock_offset);
                let cpu_set_irqstate = unsafe { lock(cpu_set_lock_addr) };
                unsafe {
                    if clear_old_cpu {
                        cpu_clear_bit_addr(cpu_set_addr, old_cpu_id, cpu_set_bits);
                    }
                    cpu_set_bit_addr(cpu_set_addr, target_cpu_id, cpu_set_bits);
                    unlock(cpu_set_lock_addr, cpu_set_irqstate);
                }
            }
        }

        if let Some(log) = log_fn {
            let tid = unsafe {
                read_volatile(thread_addr.wrapping_add(offsets.thread_tid_offset) as *const CInt)
            };
            unsafe {
                log(thread_addr, tid, old_cpu_id, target_cpu_id);
            }
        }

        unsafe {
            let flags_addr = target_cpu_addr.wrapping_add(offsets.cpu_flags_offset);
            let flags = read_volatile(flags_addr as *const u32);
            write_volatile(flags_addr as *mut u32, flags | need_resched_flag);
            interrupt(target_cpu_id, vector(vector_key));
            waitq_wakeup(req_addr.wrapping_add(offsets.req_wq_offset));
            sched_double_rq_unlock(
                current_cpu_addr,
                target_cpu_addr,
                runqueue_irqstate,
                offsets,
                unlock,
                noirq_unlock,
            );
        }

        entry = next;
    }

    unsafe {
        unlock(migq_lock_addr, migration_irqstate);
    }
    processed
}
