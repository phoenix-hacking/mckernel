#!/usr/bin/env python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepared whole-object symbol/import/data ownership check. No artifact execution.
Missing compiler/link edges fail closed; this is not native lifetime acceptance.
"""
import ast, hashlib, json, struct
from pathlib import Path
ROOT=Path(__file__).resolve().parent
recipe=json.loads((ROOT/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json').read_text())
base_recipe=json.loads(Path(recipe['base_recipe']['path']).read_text())
def pinned(row):
    p=Path(row['path']);raw=p.read_bytes()
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],str(p)
    return raw
row=base_recipe['Elf_source'];source=pinned(row)
selected=[n for n in ast.parse(source).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.ClassDef) and n.name=='Elf' or isinstance(n,ast.FunctionDef) and n.name in {'object_bytes','owning_relocations'}]
ns={'Path':Path,'struct':struct};exec(compile(ast.Module(body=selected,type_ignores=[]),row['path'],'exec'),ns)
Elf=ns['Elf'];owning=ns['owning_relocations']
base_path=Path(base_recipe['new_Rust_object_path']);assert hashlib.sha256(base_path.read_bytes()).hexdigest()=='f9d2e56657c47e22dbea5c84df13eea7d04071239b6732e9ab5dae05621c2003'
new_path=ROOT/'output-1/coherent-lifetime-worker-rust.o';base=Elf(base_path);new=Elf(new_path)
def undefined(e):return {s['name'] for s in e.symbols if s['name'] and s['shndx']==0}
def function(e,name):
    rows=[s for s in e.symbols if s['name']==name and s['shndx']!=0]
    assert len(rows)==1,(name,rows)
    s=rows[0];assert s['bind']==1 and s['type']==2 and s['size']>0 and e.sections[s['shndx']]['flags']&6==6
    return s
providers=['process_try_hold_thread_live_v2','process_find_thread_live_body_result_v2','process_thread_hash_detach_live_body_v3','process_destroy_thread_hash_detach_candidate_v3','sched_affinity_hold_warning_v2','sched_getaffinity_retained_v2','sched_setaffinity_retained_v2','sched_do_migrate_mask_serialized_v3']
proof={name:function(new,name) for name in providers}
assert not any(s['name']=='process_destroy_thread_hash_detach_bridge' for s in new.symbols), 'OFF callback must have no ON definition or unresolved consumer'
assert undefined(new)==undefined(base),dict(added=sorted(undefined(new)-undefined(base)),removed=sorted(undefined(base)-undefined(new)))
# Preserve actual Rust-owned shared storage exactly, with one GLOBAL definition.
data_proof={}
for name in ['runq_reservation_lock','resource_set_lock','resource_set_list']:
    old=[s for s in base.symbols if s['name']==name and s['shndx']!=0]
    current=[s for s in new.symbols if s['name']==name and s['shndx']!=0]
    assert len(old)==len(current)==1 and current[0]['bind']==1 and current[0]['type']==1
    assert current[0]['size']==old[0]['size']
    data_proof[name]=current[0]
# Preserve original arithmetic repair and four LOCAL logger objects. Path/line
# descriptor validation stays a separate original oracle adapted to this source.
handler=function(new,'move_pages_smp_handler')
assert not any(any(x in r['target']['name'] for x in ['panic_const_div_by_zero','panic_const_div_overflow']) for r in owning(new,handler))
for marker in ['F06_PROCESS_VM_IOV_LOCAL_DEBUG','F06_PROCESS_VM_IOV_REMOTE_DEBUG','F06_PROCESS_VM_FOUND_DEBUG','F06_PROCESS_VM_COPY_DEBUG']:
    rows=[s for s in new.symbols if marker in s['name'] and s['type']==1]
    assert len(rows)==1 and rows[0]['bind']==0 and rows[0]['size']==32
# Direct instruction/callback references are required for the affected production
# consumers. Optimization surprises require inspection, never automatic waiver.
edges={
 'find_thread': ['process_find_thread_live_body_result_v2','process_try_hold_thread_live_v2'],
 'destroy_thread': ['process_destroy_thread_hash_detach_candidate_v3'],
 'process_destroy_thread_hash_detach_candidate_v3':['process_thread_hash_detach_live_body_v3'],
 'sys_sched_getaffinity':['sched_getaffinity_retained_v2','sched_affinity_hold_warning_v2'],
 'sys_sched_setaffinity':['sched_setaffinity_retained_v2','sched_affinity_hold_warning_v2'],
 'sched_do_migrate_public':['sched_do_migrate_mask_serialized_v3'],
}
edge_proof={}
for caller,callees in edges.items():
    symbol=function(new,caller);relocs=owning(new,symbol);names={r['target']['name'] for r in relocs}
    for callee in callees:assert callee in names,(caller,callee,'missing actual object consumer edge')
    edge_proof[caller]=[r for r in relocs if r['target']['name'] in callees]
result=dict(scope=recipe['scope'],status='PASS_CHANGED_CANDIDATE_WHOLE_OBJECT_COMPILE_OWNERSHIP_ONLY',object=dict(path=str(new_path),bytes=new_path.stat().st_size,sha256=hashlib.sha256(new_path.read_bytes()).hexdigest()),providers=proof,production_consumer_edges=edge_proof,data_ownership=data_proof,undefined_exact=sorted(undefined(new)),default_image=False,native=False,global_lifetime_acceptance=False,whole_C_retirement=False)
with (ROOT/'ACTUAL-COHERENT-WHOLE-OBJECT-OWNERSHIP.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASS changed coherent whole-object providers/imports/storage/production-consumer-edges; default/native/lifetime OPEN')
