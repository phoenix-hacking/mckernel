"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare exact finite envelope inputs only; never execute runner or workload.
"""
from pathlib import Path
import ast,hashlib,json,os,stat
ROOT=Path(__file__).resolve().parent;CAND=ROOT.parent
RECIPE=CAND/'EXACT-WHOLE-RUST-COMPILE.PREPARED-NOT-GRANTED.json'
assert hashlib.sha256(RECIPE.read_bytes()).hexdigest()=='1c5a710b8de7631962297e5141b4c1e3bdb3a092a5e1f83c13bd89c90f3edfca'
j=json.loads(RECIPE.read_text());FIELDS=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 raw=p.read_bytes();assert len(raw)<=32<<20;return dict(path=str(p.absolute()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def identity(s):return {k:getattr(s,k) for k in FIELDS}
output=CAND/'output-1';lex=output.lstat();assert stat.S_ISDIR(lex.st_mode) and lex.st_uid==lex.st_gid==1000 and stat.S_IMODE(lex.st_mode)==0o700
fd=os.open(output,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
 assert identity(os.fstat(fd))==identity(lex)==identity(output.lstat());assert not os.listdir(fd)
 output_binding=dict(path=str(output),identity=identity(lex),uid=1000,gid=1000,permission_mode=0o700,empty=True)
finally:os.close(fd)
helper=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py');assert pin(helper)['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
census=Path('/home/holden/mckernel-work/host-preparation/current-host-rust-pair-sdk-20261019-1/capsule/scripts/native_rust_exact_build_container_owner.py');assert pin(census)['sha256']=='96d17547bfc71454d54e95a705138cc9b26faa1e2cafc34105c9ed8d5a68f4d1'
rows=j['inputs']+list(j['tools'].values());assert len(rows)==107
seen={}
for row in rows:
 assert pin(Path(row['path']))==row
 if row['path'] in seen:assert seen[row['path']]==row
 seen[row['path']]=row
profile=dict(parent_control_CPU=7,command_CPU=0,ordinary_jobs=1,AS_bytes=2<<30,whole_CPU_seconds=60,whole_wall_seconds=90,retirement_seconds=6,FS_bytes=32<<20,FD=256,stack_bytes=2<<20,core_bytes=0)
spec=dict(scope=j['scope'],status='SOURCE_ONLY_NOT_GRANTED_NOT_EXECUTED',root_grant=None,recipe=pin(RECIPE),profile=profile,logical_input_rows=107,unique_recipe_input_paths=len(seen),recipe_inputs=rows,helper=pin(helper),census=pin(census),existing_output_directory=output_binding,required_absent_paths=[str(ROOT/'actual-three-command-capture-1'),str(ROOT/'ACTUAL-SOURCE37-THREE-COMMAND-RESULT.json'),str(ROOT/'ATTEMPT-CLAIM.json'),str(CAND/'output-1/coherent-lifetime-worker-rust.o'),str(CAND/'ACTUAL-COHERENT-WHOLE-OBJECT-OWNERSHIP.json'),str(CAND/'ACTUAL-COHERENT-ORIGINAL-LOGGER-ARITHMETIC-OWNERSHIP.json')],command_names=[c['name'] for c in j['commands']],expected_exits=[0,0,0],fixed_window=dict(id='new18h-1792965333924702242',start_UTC='2026-10-25T21:55:33Z',deadline_UTC='2026-10-26T15:55:33Z',deadline_UTC_epoch=1793030133),same_goal='01a170fb-57c3-7ab3-862d-8005bef92a63',credit_run='7f4af94a83b14cc08f97401f5891d965',cutoff_grant_rule='Root supplies existing exact armed MONOTONIC/BOOTTIME cutoffs and authoritative bound guardian receipt; never derive/reset. No new account/guardian/framework operation.',fd_contract='Hold read-only CLOEXEC descriptors for every unique107row input path plus recipe/spec/helper/census/runner/Rootgrant through all3commands. Verify FD hash+identity and lexical path+target identity before/after every command and final sequence; parent live FD count stays <256.',source34_profile_reuse=pin(ROOT.parent.parent.parent/'new-window-source-34-thread-hash-writer-production-abi-source-1/run_three_commands_correction1_once.NOT-GRANTED.py'))
for path in spec['required_absent_paths']:assert not os.path.lexists(path),path
p=ROOT/'ENVELOPE-SPEC.PREPARED-NOT-GRANTED.json';assert not p.exists();p.write_text(json.dumps(spec,indent=2)+'\n');print(json.dumps(pin(p)))
