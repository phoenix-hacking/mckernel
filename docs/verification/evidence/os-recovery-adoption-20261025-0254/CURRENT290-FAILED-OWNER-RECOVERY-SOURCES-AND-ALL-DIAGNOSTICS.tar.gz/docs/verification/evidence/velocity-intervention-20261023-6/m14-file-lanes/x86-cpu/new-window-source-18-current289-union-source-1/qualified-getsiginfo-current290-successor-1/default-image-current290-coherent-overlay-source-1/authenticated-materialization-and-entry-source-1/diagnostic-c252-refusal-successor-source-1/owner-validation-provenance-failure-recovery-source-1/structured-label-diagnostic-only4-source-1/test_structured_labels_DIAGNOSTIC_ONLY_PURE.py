"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure synthetic-label fixture controls only; no observer import or live query.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json
N=Path(__file__).parent
r=json.loads((N/'READY-FIXED44-STRUCTURED-LABELS.DIAGNOSTIC-ONLY.SOURCE.json').read_bytes());profile=json.loads(Path(r['diagnostic_profile']['path']).read_bytes())
ref=r['comparator'];raw=Path(ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'];spec=importlib.util.spec_from_file_location('pure_structured_labels',ref['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fixed=profile['fixed_rows'];assert len(fixed)==44
state={'Status':'exited','Running':False,'Paused':False,'Restarting':False,'OOMKilled':False,'Dead':False,'Pid':0,'ExitCode':1,'Error':'','StartedAt':'fixture-start','FinishedAt':'fixture-finish'}
values=[{'Id':row['ID'],'Name':'/'+row['Names'],'Image':'sha256:'+row['ID'],'Config':{'Image':'fixture=config-image:'+row['ID'],'Labels':{'mckernel.owner':'fixture-owner-'+str(i),'org.opencontainers.image.authors':'A, B=engineer, C <mail=box>'}},'State':copy.deepcopy(state)} for i,row in enumerate(fixed)]
def encode(value):return json.dumps(value,sort_keys=True).encode()
expected=m.project(encode(values),fixed,{})
results=[]
def positive(name,fn):assert fn();results.append({'name':name,'expected':'PASS'})
def reject(name,fn):
 try:fn()
 except (m.Refusal,json.JSONDecodeError,KeyError):results.append({'name':name,'expected':'REFUSED'})
 else:raise AssertionError('accepted:'+name)
def comparechange(name,change):
 rows=copy.deepcopy(expected);change(rows);reject(name,lambda:m.compare(expected,rows))
def projectchange(name,change):
 rows=copy.deepcopy(values);change(rows);reject(name,lambda:m.project(encode(rows),fixed,{}))
positive('JSON_key_order_permutation_and_comma_equal_label_values',lambda:m.compare(expected,m.project(json.dumps([{k:dict(reversed(list(v.items()))) if isinstance(v,dict) else v for k,v in reversed(list(row.items()))} for row in values]).encode(),fixed,{})))
positive('full_comma_equal_author_value_preserved',lambda:all(row['Config.Labels']['org.opencontainers.image.authors']=='A, B=engineer, C <mail=box>' for row in expected))
nullvalues=copy.deepcopy(values);nullvalues[0]['Config']['Labels']=None;nullprojection=m.project(encode(nullvalues),fixed,{})
positive('null_no_labels_preserved_distinct_type',lambda:nullprojection[0 if nullprojection[0]['Id']==values[0]['Id'] else next(i for i,v in enumerate(nullprojection) if v['Id']==values[0]['Id'])]['Config.Labels'] is None and m.compare(nullprojection,copy.deepcopy(nullprojection)))
changed=copy.deepcopy(nullprojection);next(v for v in changed if v['Id']==values[0]['Id'])['Config.Labels']={};reject('null_not_coerced_to_empty_map',lambda:m.compare(nullprojection,changed))
comparechange('changed_owner_label',lambda x:x[0]['Config.Labels'].__setitem__('mckernel.owner','changed'))
comparechange('missing_owner_label',lambda x:x[0]['Config.Labels'].pop('mckernel.owner'))
comparechange('extra_owner_label',lambda x:x[0]['Config.Labels'].__setitem__('mckernel.owner.extra','extra'))
comparechange('changed_comma_author',lambda x:x[0]['Config.Labels'].__setitem__('org.opencontainers.image.authors','A, B=changed, C <mail=box>'))
comparechange('extra_label_key',lambda x:x[0]['Config.Labels'].__setitem__('extra','x=y,z'))
comparechange('missing_author_key',lambda x:x[0]['Config.Labels'].pop('org.opencontainers.image.authors'))
comparechange('extra_projection_key',lambda x:x[0].__setitem__('extra',1))
comparechange('missing_projection_key',lambda x:x[0].pop('Config.Image'))
comparechange('changed_new_inspect_immutable_Image',lambda x:x[0].__setitem__('Image','sha256:'+'f'*64))
comparechange('changed_new_Config_Image',lambda x:x[0].__setitem__('Config.Image','changed-config-ref'))
comparechange('changed_State_value',lambda x:x[0]['State'].__setitem__('ExitCode',7))
projectchange('duplicate_CID',lambda x:x.__setitem__(1,copy.deepcopy(x[0])))
projectchange('missing_CID',lambda x:x.pop())
projectchange('extra_CID',lambda x:x.append(copy.deepcopy(x[0])))
projectchange('unexpected_CID',lambda x:x[0].__setitem__('Id','f'*64))
projectchange('wrong_Name',lambda x:x[0].__setitem__('Name','/changed'))
projectchange('double_leading_slash_Name',lambda x:x[0].__setitem__('Name','/'+x[0]['Name']))
projectchange('wrong_Image_type',lambda x:x[0].__setitem__('Image',[]))
projectchange('wrong_Config_Image_type',lambda x:x[0]['Config'].__setitem__('Image',2))
for key,value in [('Running',True),('Paused',True),('Restarting',True),('Pid',1),('Status','running'),('ExitCode',True)]:projectchange('wrong_State_'+key,lambda x,k=key,v=value:x[0]['State'].__setitem__(k,v))
for value in ([], 'labels', 2, True, {'owner':1}):projectchange('wrong_Label_map_type_'+repr(value),lambda x,v=value:x[0]['Config'].__setitem__('Labels',v))
owner=values[0]['Id'];reject('changed_genuine_fixture_owner_anchor',lambda:m.project(encode(values),fixed,{owner:'other-fixture-owner'}))
# Duplicate-key JSON must fail even when values repeat.
duplicate=encode(values).replace(b'"Id":',b'"Id":"duplicate", "Id":',1);reject('duplicate_JSON_Id_key',lambda:m.project(duplicate,fixed,{}))
duplicate=encode(values).replace(b'"mckernel.owner":',b'"mckernel.owner":"duplicate", "mckernel.owner":',1);reject('duplicate_JSON_label_key',lambda:m.project(duplicate,fixed,{}))
psraw=b''.join(encode(row)+b'\n' for row in fixed);positive('exact_historical_ps44_identity_projection',lambda:len(m.validate_ps_identity(psraw,fixed)['historical_identity_rows'])==44)
for key in ('ID','Names','Image','State'):
 bad=copy.deepcopy(fixed);bad[0][key]='changed';reject('changed_historical_ps_'+key,lambda b=bad:m.validate_ps_identity(b''.join(encode(row)+b'\n' for row in b),fixed))
# Every accepted parent/shared/input/PROC function remains the same definition.
old=ast.parse((N.parent/'readonly_failed_owner_provenance.CAPTURE-FIRST3.py').read_bytes());new=ast.parse(Path(r['reader']['path']).read_bytes());functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)};oldf=functions(old);newf=functions(new);assert all(newf[k]==v for k,v in oldf.items())
assert profile['known_owner_anchors']=={} and profile['historical_full_label_map_coverage']==0 and not profile['new_maps_are_historical_baseline']
print(json.dumps({'scope':__doc__,'status':'PASS_PURE_FIXED44_STRUCTURED_LABEL_AND_IDENTITY_CONTROLS','cases':results,'case_count':len(results),'positive':sum(x['expected']=='PASS' for x in results),'negative':sum(x['expected']=='REFUSED' for x in results),'all_parent_functions_AST_identical':True,'fixture_labels_are_synthetic_not_historical':True,'historical_map_coverage':0,'observer_imported':False,'live_queries':0},sort_keys=True))
