"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Isolated AST/publisher/domain controls only. No observer/import, PROC/Docker or root work.
"""
from pathlib import Path
import ast,hashlib,json,os,types
D=Path(__file__).parent
ready=json.loads((D/'READY-READONLY-FAILED-OWNER.CORRECTION1.SOURCE-ONLY.json').read_bytes())
row=ready['reader'];raw=Path(row['path']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];tree=ast.parse(raw)
p=json.loads(Path(ready['profile']['path']).read_bytes())
historical=json.loads(Path(p['historical_profile']['path']).read_bytes());current=json.loads(Path(p['current_profile']['path']).read_bytes())
ns=dict(p=p,historical=historical,current=current,Path=Path,m=types.SimpleNamespace())
assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=='m' and t.attr=='ABSENT' for t in n.targets) and isinstance(n.value,ast.BinOp))
sourceassignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='sources' for t in n.targets))
exec(compile(ast.Module(body=[assignment,sourceassignment],type_ignores=[]),'<actual-domain-assignments>','exec'),ns)
assert ns['m'].ABSENT==set(historical['required_absent_pids'])|set(current['required_absent_pids'])|set(p['required_absent_pids']) and len(ns['m'].ABSENT)==45
assert 866814 not in ns['m'].ABSENT
assert len(ns['sources'])==len(set(ns['sources']))==8
assert ns['sources'][:6]==historical['publisher_source_paths']+current['source_paths']
base=ast.parse(Path(p['process_census_source']['path']).read_bytes());code=ast.literal_eval(next(n.value for n in base.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROC_CODE' for t in n.targets)))
marker='    for arg in argv:\n';code=code.replace(marker,'    if any(path in argv for path in '+repr(ns['sources'])+'): return True\n'+marker,1)
t=ast.parse(code);parts=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='publisher' or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='heavy' for t in n.targets)]
probe={'os':os};exec(compile(ast.Module(body=parts,type_ignores=[]),'<actual-injected-publisher>','exec'),probe)
cases=0
for path in ns['sources']:
 assert probe['publisher']('/usr/bin/python3.8',['python','-I','-B',path]);cases+=1
 # Generic predicate intentionally recognizes some native filenames; neutral
 # near-match arguments test exact explicit-source matching without that rule.
 for argv in [['text:'+path+':text'],['-c','print('+repr(path)+')']]:
  assert not probe['publisher']('/usr/bin/python3.8',argv);cases+=1
snapshot=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='snapshot')
loop=next(n for n in snapshot.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='sorted(m.ABSENT)')
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='h' and n.func.attr=='members' for n in ast.walk(loop))
assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='validate_process_report' for n in ast.walk(snapshot))
assert not (D/'actual-failed-owner-readonly-correction1-capture-1').exists()
print(json.dumps({'scope':__doc__,'status':'PASS_PURE_SOURCE_DOMAIN_CONTROLS','publisher_cases':cases,'exact_source_positives':8,'nonmatching_negatives':16,'historical_absent':22,'SDK_absent':16,'new_absent':7,'union_absent':45,'all_group_checks_preserved':True,'observer_executed':False,'root_work':False},sort_keys=True))
