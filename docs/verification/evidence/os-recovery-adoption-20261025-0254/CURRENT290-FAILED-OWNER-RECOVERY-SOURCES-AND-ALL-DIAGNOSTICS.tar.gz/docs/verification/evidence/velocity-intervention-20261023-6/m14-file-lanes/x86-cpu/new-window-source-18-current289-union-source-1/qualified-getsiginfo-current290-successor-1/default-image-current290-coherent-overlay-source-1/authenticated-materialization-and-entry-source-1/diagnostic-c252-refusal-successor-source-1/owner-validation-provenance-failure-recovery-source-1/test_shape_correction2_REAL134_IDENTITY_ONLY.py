"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Real134 protected input identity regression only; no observer/PROC/Docker/root/mutation.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json
D=Path(__file__).parent
r=json.loads((D/'READY-READONLY-FAILED-OWNER.SHAPE-CORRECTION2.SOURCE-ONLY.json').read_bytes())
p=json.loads(Path(r['profile']['path']).read_bytes())
def load(ref,name):
 raw=Path(ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256']
 spec=importlib.util.spec_from_file_location(name,ref['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
m=load(p['primitive'],'shape_only_existing_authority1');normal=load(p['normal_engine'],'shape_only_existing_normal')
raw=Path(r['reader']['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['reader']['sha256'];tree=ast.parse(raw)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='exact_identity');ns=dict(m=m,normal=normal,Path=Path);exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-observer-shape-adapter>','exec'),ns)
counts={};hardlinks=[];observed=[]
for key in ['historical_profile','current_profile']:
 c=json.loads(Path(p[key]['path']).read_bytes());counts[key]=0
 for expected in c['protected_inputs']:
  row=c['archived_records'].get(expected['path'],expected);actual=ns['exact_identity'](row);assert actual==row;counts[key]+=1;observed.append(actual)
  if row['nlink']==2:hardlinks.append(row)
assert counts=={'historical_profile':55,'current_profile':79} and len(observed)==134 and len(hardlinks)==2
negative=0
for row in hardlinks:
 # Each mismatch must still refuse: accepted hardlinks are exact identities,
 # not a broader link-count or metadata allowance.
 for key,value in [('nlink',1),('inode',row['inode']+1),('sha256','0'*64),('mode','0o644')]:
  bad=copy.deepcopy(row);bad[key]=value
  try:ns['exact_identity'](bad)
  except m.Refusal:negative+=1
  else:raise AssertionError('identity mismatch accepted:'+key)
assert negative==8
# All other functions retain correction1 behavior and45-process/group domain.
old=ast.parse((D/'readonly_failed_owner_provenance.CORRECTION1.py').read_bytes());bodies=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef) and n.name!='exact_identity'}
assert bodies(old)==bodies(tree)
print(json.dumps({'scope':__doc__,'status':'PASS_ALL134_REAL_PROTECTED_IDENTITIES_AND8_NEGATIVE_HARDLINK_CONTROLS','profiles':counts,'real_identity_rows':134,'accepted_exact_nlink2_rows':len(hardlinks),'negative_refusals':negative,'all_other_functions_AST_identical':True,'observer_executed':False,'root_or_mutation':False,'real_identity_rows_digest':hashlib.sha256(json.dumps(observed,sort_keys=True).encode()).hexdigest()},sort_keys=True))
