"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure synthetic-label fixtures; no observer import, live query or historical map claim.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json
N=Path(__file__).parent;r=json.loads((N/'READY-FIXED44-STRUCTURED-LABELS.DIAGNOSTIC-ONLY.SOURCE.json').read_bytes());p=json.loads(Path(r['diagnostic_profile']['path']).read_bytes())
ref=r['comparator'];raw=Path(ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'];spec=importlib.util.spec_from_file_location('pure_tagged_labels',ref['path']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fixed=p['fixed_rows'];display={row['ID']:row['Labels'] for row in fixed};assert len(fixed)==44
state={'Status':'exited','Running':False,'Paused':False,'Restarting':False,'OOMKilled':False,'Dead':False,'Pid':0,'ExitCode':1,'Error':'','StartedAt':'fixture-start','FinishedAt':'fixture-finish'}
values=[{'Id':row['ID'],'Name':'/'+row['Names'],'Image':'sha256:'+row['ID'],'Config':{'Image':'fixture=config-image:'+row['ID'],'Labels':{'mckernel.owner':'fixture-owner-'+str(i),'org.opencontainers.image.authors':'A, B=engineer, C <mail=box>'} if row['Labels'] else {}},'State':copy.deepcopy(state)} for i,row in enumerate(fixed)]
def encode(v):return json.dumps(v,sort_keys=True).encode()
def project(v,anchors=None):return m.project(v,fixed,{} if anchors is None else anchors,display)
expected=project(encode(values));nonempty=next(i for i,row in enumerate(values) if row['Config']['Labels']);empty=next(i for i,row in enumerate(values) if row['Config']['Labels']=={});nonemptycid=values[nonempty]['Id'];E=next(i for i,row in enumerate(expected) if row['Id']==nonemptycid)
results=[]
def positive(name,fn):assert fn(),name;results.append({'name':name,'expected':'PASS'})
def reject(name,fn):
 try:fn()
 except (m.Refusal,json.JSONDecodeError,KeyError):results.append({'name':name,'expected':'REFUSED'})
 else:raise AssertionError('accepted:'+name)
def comparechange(name,change):
 rows=copy.deepcopy(expected);change(rows);reject(name,lambda:m.compare(expected,rows))
def projectchange(name,change):
 rows=copy.deepcopy(values);change(rows);reject(name,lambda:project(encode(rows)))
def reverse(v):
 if isinstance(v,dict):return {k:reverse(x) for k,x in reversed(list(v.items()))}
 if isinstance(v,list):return [reverse(x) for x in v]
 return v
positive('JSON_key_order_permutation',lambda:m.compare(expected,project(encode(reverse(values)))))
positive('full_comma_equal_author_value_preserved',lambda:expected[E]['Config.Labels']['value']['org.opencontainers.image.authors']=='A, B=engineer, C <mail=box>')
positive('empty_map_empty_map_new_pair',lambda:m.compare(expected,copy.deepcopy(expected)))
nullvalues=copy.deepcopy(values);nullvalues[empty]['Config']['Labels']=None;nullprojection=project(encode(nullvalues));positive('null_null_new_pair',lambda:m.compare(nullprojection,copy.deepcopy(nullprojection)))
reject('null_empty_map_new_pair_refused',lambda:m.compare(nullprojection,expected))
reject('empty_map_null_new_pair_refused',lambda:m.compare(expected,nullprojection))
projectchange('null_against_old_nonempty',lambda x:x[nonempty]['Config'].__setitem__('Labels',None))
projectchange('empty_map_against_old_nonempty',lambda x:x[nonempty]['Config'].__setitem__('Labels',{}))
projectchange('nonempty_map_against_old_empty',lambda x:x[empty]['Config'].__setitem__('Labels',{'fixture':'not-empty'}))
for name,key,value in [('changed_owner','mckernel.owner','changed'),('extra_owner_key','mckernel.owner.extra','extra'),('changed_comma_author','org.opencontainers.image.authors','A, B=changed, C <mail=box>'),('extra_label_key','extra','x=y,z')]:comparechange(name,lambda x,k=key,v=value:x[E]['Config.Labels']['value'].__setitem__(k,v))
for name,key in [('missing_owner','mckernel.owner'),('missing_author','org.opencontainers.image.authors')]:comparechange(name,lambda x,k=key:x[E]['Config.Labels']['value'].pop(k))
comparechange('extra_projection_key',lambda x:x[E].__setitem__('extra',1));comparechange('missing_projection_key',lambda x:x[E].pop('Config.Image'))
comparechange('changed_new_inspect_Image',lambda x:x[E].__setitem__('Image','sha256:'+'f'*64));comparechange('changed_new_Config_Image',lambda x:x[E].__setitem__('Config.Image','changed-ref'));comparechange('changed_State',lambda x:x[E]['State'].__setitem__('ExitCode',7))
projectchange('duplicate_CID',lambda x:x.__setitem__(1,copy.deepcopy(x[0])));projectchange('missing_CID',lambda x:x.pop());projectchange('extra_CID',lambda x:x.append(copy.deepcopy(x[0])));projectchange('unexpected_CID',lambda x:x[0].__setitem__('Id','f'*64));projectchange('wrong_Name',lambda x:x[0].__setitem__('Name','/changed'));projectchange('double_slash_Name',lambda x:x[0].__setitem__('Name','/'+x[0]['Name']));projectchange('wrong_Image_type',lambda x:x[0].__setitem__('Image',[]));projectchange('wrong_Config_Image_type',lambda x:x[0]['Config'].__setitem__('Image',2))
for key,value in [('Running',True),('Paused',True),('Restarting',True),('Pid',1),('Status','running'),('ExitCode',True)]:projectchange('wrong_State_'+key,lambda x,k=key,v=value:x[0]['State'].__setitem__(k,v))
for value in ([], 'labels', 2, True, {'owner':1}):projectchange('wrong_Label_container_'+repr(value),lambda x,v=value:x[nonempty]['Config'].__setitem__('Labels',v))
positive('matching_fixture_owner_anchor',lambda:bool(project(encode(values),{nonemptycid:values[nonempty]['Config']['Labels']['mckernel.owner']})))
reject('changed_fixture_owner_anchor',lambda:project(encode(values),{nonemptycid:'wrong-fixture-owner'}))
reject('owner_anchor_on_empty_display',lambda:project(encode(values),{values[empty]['Id']:'invented'}))
duplicate=encode(values).replace(b'"Id":',b'"Id":"duplicate", "Id":',1);reject('duplicate_JSON_Id_key',lambda:project(duplicate));duplicate=encode(values).replace(b'"mckernel.owner":',b'"mckernel.owner":"duplicate", "mckernel.owner":',1);reject('duplicate_JSON_label_key',lambda:project(duplicate))
psraw=b''.join(encode(row)+b'\n' for row in fixed);positive('exact_historical_ps44_nonlabel_projection',lambda:len(m.validate_ps_identity(psraw,fixed)['historical_identity_rows'])==44)
for key in ('ID','Names','Image','State'):
 bad=copy.deepcopy(fixed);bad[0][key]='changed';reject('changed_historical_ps_'+key,lambda b=bad:m.validate_ps_identity(b''.join(encode(row)+b'\n' for row in b),fixed))
old=ast.parse((N.parent/'readonly_failed_owner_provenance.CAPTURE-FIRST3.py').read_bytes());new=ast.parse(Path(r['reader']['path']).read_bytes());functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)};oldf=functions(old);newf=functions(new);assert all(newf[k]==v for k,v in oldf.items())
assert p['known_owner_anchors']=={} and p['historical_full_label_map_coverage']==0 and not p['new_maps_are_historical_baseline']
print(json.dumps({'scope':__doc__,'status':'PASS_PURE_FIXED44_TAGGED_LABEL_AND_IDENTITY_CONTROLS','cases':results,'case_count':len(results),'positive':sum(x['expected']=='PASS' for x in results),'negative':sum(x['expected']=='REFUSED' for x in results),'all_parent_functions_AST_identical':True,'fixture_labels_are_synthetic_not_historical':True,'historical_map_coverage':0,'observer_imported':False,'live_queries':0},sort_keys=True))
