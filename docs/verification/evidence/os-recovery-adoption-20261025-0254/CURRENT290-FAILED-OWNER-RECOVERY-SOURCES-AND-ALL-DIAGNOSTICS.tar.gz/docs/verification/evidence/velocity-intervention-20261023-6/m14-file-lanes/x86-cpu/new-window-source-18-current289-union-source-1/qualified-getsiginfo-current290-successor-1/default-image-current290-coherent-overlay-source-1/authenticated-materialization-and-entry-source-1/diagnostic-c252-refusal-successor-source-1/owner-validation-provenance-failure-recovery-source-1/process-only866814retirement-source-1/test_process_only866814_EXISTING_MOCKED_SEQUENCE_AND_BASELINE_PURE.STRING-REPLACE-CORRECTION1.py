"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Existing exact execute sequence with every action mocked; immutable baseline/source only.
"""
from pathlib import Path
import ast,hashlib,importlib.util,json,unittest
N=Path(__file__).parent
r=json.loads((N/'READY-PROCESS-ONLY866814-RETIREMENT.SOURCE.json').read_bytes())
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
for key in ('source','profile','primitive','readonly_acceptance'):
 row=r[key];raw=Path(row['path']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
a=load(r['source']['path'],'actual_process_only_adapter_pure')
assert a.m.execute.__code__.co_filename==r['primitive']['path']
assert a.m.PID==866814 and a.m.START=='76706306' and a.m.PARENT==866813 and len(a.m.ABSENT)==45 and 866814 not in a.m.ABSENT
assert a.r['shared_identity']['sha256']=='324ae871e07d57c1453e57473b64bb31f947d073a9a903b1adca1dad1c1aaaed' and a.r['shared_identity']['device']==1828 and a.r['shared_identity']['inode']==116858
baseline=a.typed_baseline();assert len(baseline)==44 and a.m.sha(a.m.canonical(baseline))=='b4ea8108faa5c00f21ce0b8f42af79e2a72094789de49482006f5d035d8809df'
# Retained observation bodies are verbatim; no observer import or live call.
parent=ast.parse(Path(a.r['typed_diagnostic_source']['path']).read_bytes());source=ast.parse(Path(r['source']['path']).read_bytes());funcs=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)};oldf=funcs(parent);newf=funcs(source)
for name in ('load','proc_bytes_eof','fixed','exact_identity','retained_domain','evidence','shared_record'):assert oldf[name]==newf[name]
for node in ast.walk(source):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute):assert node.func.attr not in ('unlink','remove','rename','truncate','kill','killpg','pidfd_open','pidfd_send_signal','flock'),node.func.attr
assert all(isinstance(n.func.value,ast.Name) and n.func.value.id=='code' for n in ast.walk(source) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='replace')
assert not any(isinstance(n,ast.FunctionDef) and n.name=='execute' for n in source.body)
# Reuse four existing mocked tests against the actual adapted module's unchanged
# execute function. All pidfd/signal/flock/proc/query/writer calls are mocked by
# the existing harness; no runtime target or permanent mutex is accessed.
b=load('/home/holden/mckernel/scripts/tests/test_native_exact_scratch22_authority1_quarantine_recovery.py','existing_exact_execute_sequence_tests');b.m=a.m
names=['test_prepared_before_sole_signal_and_complete_before_root_unlock','test_pre_signal_failure_never_sends_or_acquires_replacement','test_uncertain_signal_response_consumes_budget_and_never_retries','test_postflight_or_complete_writer_failure_keeps_replacement_lock']
suite=unittest.TestSuite(b.RecoveryTests(name) for name in names);result=unittest.TextTestRunner(verbosity=2).run(suite)
assert result.wasSuccessful()
print(json.dumps({'scope':__doc__,'status':'PASS4_EXISTING_MOCKED_EXECUTE_SEQUENCE_AND_REAL_IMMUTABLE_BASELINE_SOURCE_CONTROLS','mocked_sequence_tests':result.testsRun,'retained_observation_function_bodies_identical':7,'prior_absent_union':45,'new_current_projection_rows':44,'shared_node_and_bytes_bound':True,'execute_body_reused_unchanged':True,'actual_pidfd_calls':0,'actual_signals':0,'actual_flock':0,'actual_queries':0,'source_import_actions':'configuration and immutable source/JSON reads only'},sort_keys=True))
