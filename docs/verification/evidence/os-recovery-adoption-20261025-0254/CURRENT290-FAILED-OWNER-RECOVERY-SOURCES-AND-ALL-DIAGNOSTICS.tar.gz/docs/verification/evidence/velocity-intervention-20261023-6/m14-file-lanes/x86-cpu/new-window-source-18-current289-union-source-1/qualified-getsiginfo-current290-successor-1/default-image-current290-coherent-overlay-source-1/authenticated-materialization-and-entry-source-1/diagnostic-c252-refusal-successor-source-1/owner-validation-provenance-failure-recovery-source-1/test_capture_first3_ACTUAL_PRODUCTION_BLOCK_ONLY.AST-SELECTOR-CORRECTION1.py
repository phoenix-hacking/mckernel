"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Isolated actual production Docker block, fake readonly/publish only; no observer import/query.
"""
from pathlib import Path
import ast,copy,hashlib,json,types
D=Path(__file__).parent
r=json.loads((D/'READY-READONLY-FAILED-OWNER.CAPTURE-FIRST3.SOURCE-ONLY.json').read_bytes());profile=json.loads(Path(r['profile']['path']).read_bytes())
raw=Path(r['reader']['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['reader']['sha256'];new=ast.parse(raw)
old=ast.parse((D/'readonly_failed_owner_provenance.SHAPE-CORRECTION2.py').read_bytes())
def function(t,name):return next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name)
a=function(old,'snapshot');b=function(new,'snapshot')
assert [ast.dump(n,include_attributes=False) for n in a.body if isinstance(n,ast.If)]==[ast.dump(n,include_attributes=False) for n in b.body if isinstance(n,ast.If)]
assert ast.dump(function(old,'readonly'),include_attributes=False)==ast.dump(function(new,'readonly'),include_attributes=False)
start=next(i for i,n in enumerate(b.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='readonly' and isinstance(n.value.args[0],ast.List) and ast.literal_eval(n.value.args[0].elts[0])=='/usr/bin/docker')
stop=next(i for i,n in enumerate(b.body) if i>start and isinstance(n,ast.If) and 'Docker inventory changed' in ast.unparse(n))
block=b.body[start:stop+1]
assert isinstance(block[1],ast.Assign) and isinstance(block[1].targets[0],ast.Subscript) and ast.literal_eval(block[1].targets[0].slice)=='containers'
compiled=compile(ast.Module(body=block,type_ignores=[]),'<actual-capture-before-oracle-production-block>','exec')
primitive=ast.parse(Path(profile['primitive']['path']).read_bytes());strict=function(primitive,'strict')
class Refusal(RuntimeError):pass
helper={'json':json,'Refusal':Refusal};exec(compile(ast.Module(body=[strict],type_ignores=[]),'<accepted-strict-parser>','exec'),helper)
base_raw=Path(profile['docker_baseline']['path']).read_bytes();rows=[json.loads(line) for line in base_raw.splitlines()]
assert len(rows)==44
argv=['/usr/bin/docker','--host=unix:///var/run/docker.sock','ps','-a','--no-trunc','--format','{{json .}}']
def run_case(name,data,expected_error=None,p=None):
 captures={};published=[];queries=[]
 def readonly(args):assert args==argv;queries.append(args);return data
 def publish(filename,raw):published.append((filename,raw));return {'fixture':True}
 ns=dict(readonly=readonly,publish=publish,label='fixture',captures=captures,p=profile if p is None else p,m=types.SimpleNamespace(strict=helper['strict'],Refusal=Refusal))
 try:exec(compiled,ns)
 except BaseException as error:
  assert expected_error is not None and type(error) is expected_error,(name,type(error),expected_error)
 else:assert expected_error is None,name
 assert len(queries)==1 and published==[('fixture.containers.jsonl',data)] and captures['containers']=={'fixture':True}
 return {'case':name,'result':'PASS','expected_error':None if expected_error is None else expected_error.__name__,'raw_retained_exact':True,'actual_query':False}
def encode(rows):return b''.join(json.dumps(row,sort_keys=True).encode()+b'\n' for row in rows)
results=[run_case('matching44_PASS_rawexact',base_raw)]
bad=copy.deepcopy(rows);bad[0]['Labels']+='mismatching-field';results.append(run_case('mismatching_field_REFUSED_rawretained',encode(bad),Refusal))
bad=copy.deepcopy(rows);bad[0]['State']='running';fixture=copy.deepcopy(profile);next(row for row in fixture['docker_fixed_rows'] if row['ID']==bad[0]['ID'])['State']='running';results.append(run_case('running_state_REFUSED_even_with_matching_projection_rawretained',encode(bad),Refusal,fixture))
results.append(run_case('malformed_JSON_originalerror_rawretained',b'{malformed\n',json.JSONDecodeError))
bad=copy.deepcopy(rows);del bad[0]['Names'];results.append(run_case('missing_field_originalerror_rawretained',encode(bad),KeyError))
assert not (D/'actual-failed-owner-readonly-capture-first3-capture-1').exists()
print(json.dumps({'scope':__doc__,'status':'PASS5_ACTUAL_PRODUCTION_BLOCK_CAPTURE_BEFORE_UNCHANGED_ORACLE','cases':results,'predicate_AST_identical':True,'readonly_function_AST_identical':True,'baseline_unchanged':True,'production_block_statement_count':len(block),'observer_imported':False,'live_queries':0},sort_keys=True))
