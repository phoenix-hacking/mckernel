"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare Source31 shared edge-core reuse and actual Source30 setter/mask helpers.
"""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PRIOR=BASE/'new-window-source-31-setscheduler-lifetime'
SRC=BASE/'new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,text):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(text)
def function(text,name):
 m=re.search(r'(?:pub(?:\([^)]*\))? )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',text);assert m,name
 begin=m.start();brace=text.index('{',m.end());depth=1;i=brace+1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[begin:i]
s=(SRC/'sched_helpers.rs').read_text();prior=(PRIOR/'f03_getaffinity_retained_v2.rs').read_text()
start=prior.index('struct RetainedAffinityTarget {');end=prior.index('/// Copy affinity while retaining',start)
core=prior[start:end]
core=core.replace('struct RetainedAffinityTarget {','pub(super) struct RetainedAffinityTarget {',1).replace('    address: usize,','    pub(super) address: usize,',1).replace('unsafe fn select_retained_affinity_target(','pub(super) unsafe fn select_retained_affinity_target(',1)
type_line=next(line for line in prior.splitlines() if line.startswith('pub type SchedAffinityWarningOnlyFnV2 = '))
write('AFFINITY-RETENTION-CORE.REUSED-SOURCE31.rs.inc',type_line+'\n\n'+core)
# Production successor: Source31 full module gets only three sibling visibility
# changes. Getter and warning producers stay exactly as accepted; no old file edit.
visible=prior.replace('struct RetainedAffinityTarget {','pub(super) struct RetainedAffinityTarget {',1).replace('    address: usize,','    pub(super) address: usize,',1).replace('unsafe fn select_retained_affinity_target(','pub(super) unsafe fn select_retained_affinity_target(',1)
write('private-postimage/kernel/rust/f03_getaffinity_retained_v2.rs',visible)
parents=['sched_read_int','sched_thread_cpu_id','sched_cpuset_zero','sched_cpuset_copy','sched_cpuset_is_set','sched_cpuset_set','sched_affinity_lock','sched_affinity_unlock']
write('ACTUAL-MASK-AND-LOCK-HELPERS.rs.inc','\n\n'.join(function(s,n) for n in parents)+'\n')
write('ACTUAL-OLD-SETAFFINITY-BODY.rs.inc',function(s,'sched_affinity_select_thread')+'\n\n#[no_mangle]\n'+function(s,'sched_setaffinity_body_result').replace('fn sched_setaffinity_body_result(','fn f32_original_setaffinity(',1)+'\n')
# Readonly actual parent ABI/helpers from accepted31, not reimplemented geometry.
write('ACTUAL-AFFINITY-DECLARATIONS.REUSED-SOURCE31.rs.inc',(PRIOR/'ACTUAL-AFFINITY-DECLARATIONS.rs.inc').read_text()+'''type SchedCopyFromUserFn = unsafe extern "C" fn(*mut u8,CULong,SizeT)->CLong;
type SchedRequestMigrateFn = unsafe extern "C" fn(CInt,usize);
unsafe extern "C" {
    #[link_name="process_spin_lock_bridge"] fn process_spin_lock_bridge_c(lock:CULong)->CULong;
    #[link_name="process_spin_unlock_bridge"] fn process_spin_unlock_bridge_c(lock:CULong,irq:CULong);
    static mut runq_reservation_lock: abi::IhkSpinlock;
}
''')
write('ACTUAL-PARENT-HELPERS.REUSED-SOURCE31.rs.inc',(PRIOR/'ACTUAL-AFFINITY-PARENT-HELPERS.rs.inc').read_text())
fixture='''// '''+SCOPE+'''
#![no_std]
#[path="'''+str(SRC/'abi.rs')+'''"] mod abi;
use core::ptr::{read_volatile,write_volatile};
use abi::{CInt,CLong,CULong,SizeT};
include!("ACTUAL-AFFINITY-DECLARATIONS.REUSED-SOURCE31.rs.inc");
include!("ACTUAL-PARENT-HELPERS.REUSED-SOURCE31.rs.inc");
include!("ACTUAL-MASK-AND-LOCK-HELPERS.rs.inc");
include!("ACTUAL-OLD-SETAFFINITY-BODY.rs.inc");
mod f03_getaffinity_retained_v2 {
    use crate::abi::{CInt,CLong};
    use super::{sched_errno,sched_thread_proc,sched_proc_euid,sched_proc_ruid,
        sched_affinity_permission_result,SchedFindThreadFn,SchedThreadUnlockFn,
        SchedReleaseThreadFn,SchedSyscallOffsets,EINVAL,ESRCH};
    include!("AFFINITY-RETENTION-CORE.REUSED-SOURCE31.rs.inc");
}
#[path="f03_setaffinity_retained_v2.rs"] mod f03_setaffinity_retained_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f32_setaffinity_Rust_ABI:[usize;28]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),
 offset_of!(abi::Thread,refcount),offset_of!(abi::Thread,cpu_set),offset_of!(abi::Thread,cpu_id),
 offset_of!(abi::Thread,status),size_of::<abi::Process>(),offset_of!(abi::Process,cpu_set),
 offset_of!(abi::Process,ruid),offset_of!(abi::Process,euid),size_of::<abi::CpuSet>(),
 align_of::<abi::CpuSet>(),size_of::<abi::IhkSpinlock>(),align_of::<abi::IhkSpinlock>(),
 size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),size_of::<CInt>(),
 size_of::<CLong>(),align_of::<CLong>(),size_of::<Option<SchedFindThreadFn>>(),
 size_of::<Option<SchedThreadUnlockFn>>(),size_of::<Option<SchedHoldThreadFn>>(),
 size_of::<Option<SchedReleaseThreadFn>>(),size_of::<Option<SchedCopyFromUserFn>>(),
 size_of::<Option<SchedRequestMigrateFn>>(),
 size_of::<Option<f03_getaffinity_retained_v2::SchedAffinityWarningOnlyFnV2>>(),size_of::<SizeT>(),
];
'''
write('lib.fixture.rs',fixture)
manifest=dict(scope=SCOPE,status='SOURCE_ONLY_NO_COMPILER_OR_FIXTURE_EXECUTION',selected_defect='Original setaffinity still uses unchecked redundant hold+unlock after a positive lookup. Reuse acceptedSource31 selector/guard, holding sameallocation throughmaskapply and synchronousmigration withtid0borrow.',exact_reuse=dict(Source31_body=pin(PRIOR/'f03_getaffinity_retained_v2.rs'),Source31_actual_object=pin(PRIOR/'output-1/candidate.o'),Source31_actual_controlled_acceptance=pin(PRIOR/'ACTUAL-CONTROLLED214-ABI22-LOOKUP12-AND-RELEASE.json'),Source22_positive_lookup_object=pin(BASE/'new-window-source-22-positive-reference-lookup-repair/output-1/candidate.o')),core_refactor='Only pub(super) struct/address/selector visibility changes in privatecopy Source31 module. Core selection/Drop/warning/getter bodies unchanged. Fixture compiles edge-core only; reuses actualbb154 warning/legacyAtomic providers, no getter replay.',actual_sources=[pin(SRC/'sched_helpers.rs'),pin(SRC/'syscall_policy.rs'),pin(SRC/'abi.rs')],migration_reference=dict(wrapper='sched_request_migrate ->sched_request_migrate_body_result ->schedule()->waitq_finish()',source=pin(SRC/'sched_helpers.rs'),contract='Existing synchronous stackrequest/waitentry provider. Mask runq_reservation_lock released before migration; sameThreadedge/currentborrow remains untilreturn.'),explicit_holds=['Process eligibility-mask stability/globalhashpositive admission/callerProcess lifetime remain source contracts, not new concurrencyproof.','Existingrunq_reservation_lock retained for supported thread-mask writes; no hash or IRQ lock across usercopy/migration/finalrelease.','No productioncrate/default/native acceptance from controlled fixture; no whole-file Cretirement.'])
write('EXACT-REUSED-CORE-SETTER-MIGRATION-OWNERSHIP.SOURCE.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status=manifest['status'],bb154_reused=True,fbd_reused=True,getter_not_replayed=True)))
