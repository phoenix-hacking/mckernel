"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Private caller/module/declaration composition only; never edit prior/canonical files.
"""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'new-window-source-31-setscheduler-lifetime'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
patch=[];rows=[]
for relative in ['kernel/rust/sched_helpers.rs','kernel/rust/syscall_policy.rs','kernel/syscall.c']:
 base=PRIOR/'private-postimage'/relative;old=base.read_text();new=old
 if relative.endswith('sched_helpers.rs'):
  new=new.replace('#[cfg(all(f03_getaffinity_retained_v2,','#[cfg(all(any(f03_getaffinity_retained_v2, f03_setaffinity_retained_v2),',1)
  assert new.count('#[cfg(f03_getaffinity_retained_v2)]')==2
  new=new.replace('#[cfg(f03_getaffinity_retained_v2)]','#[cfg(any(f03_getaffinity_retained_v2, f03_setaffinity_retained_v2))]')
  new=new.replace('getaffinity retained v2 requires the actual positive lookup and Rust scheduler bridge','retained affinity v2 requires the actual positive lookup and Rust scheduler bridge')
  new+='''
#[cfg(f03_setaffinity_retained_v2)]
#[path = "f03_setaffinity_retained_v2.rs"]
mod f03_setaffinity_retained_v2;
#[cfg(f03_setaffinity_retained_v2)]
pub use f03_setaffinity_retained_v2::sched_setaffinity_retained_v2;
'''
 elif relative.endswith('syscall_policy.rs'):
  start=old.index('pub unsafe extern "C" fn sys_sched_setaffinity(')
  begin=old.index('    crate::sched_helpers::sched_setaffinity_body_result(',start)
  end=old.index('\n    )',begin)+len('\n    )');call=old[begin:end]
  candidate=call.replace('sched_setaffinity_body_result(','sched_setaffinity_retained_v2(',1).replace('Some(sched_hold_thread_bridge),','Some(crate::sched_helpers::sched_affinity_hold_warning_v2),')
  new=old[:begin]+'    #[cfg(f03_setaffinity_retained_v2)]\n    {\n'+''.join('    '+line+'\n' for line in candidate.splitlines())+'    }\n    #[cfg(not(f03_setaffinity_retained_v2))]\n    {\n'+''.join('    '+line+'\n' for line in call.splitlines())+'    }'+old[end:]
 else:
  marker='#ifdef MCKERNEL_RUST_SCHED_GETAFFINITY_RETAINED_V2';assert old.count(marker)==1
  new=new.replace(marker,'#if defined(MCKERNEL_RUST_SCHED_GETAFFINITY_RETAINED_V2) || defined(MCKERNEL_RUST_SCHED_SETAFFINITY_RETAINED_V2)',1)
  marker='typedef void (*sched_request_migrate_fn_t)(int cpu_id,\n\t\tunsigned long thread_addr);';assert new.count(marker)==1
  new=new.replace(marker,marker+'\n#ifdef MCKERNEL_RUST_SCHED_SETAFFINITY_RETAINED_V2\n'+(ROOT/'VERSIONED-SETAFFINITY-ABI.C.inc').read_text()+'#endif\n',1)
 target=ROOT/'private-postimage'/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('x') as f:f.write(new)
 rows.append(dict(base=pin(base),postimage=pin(target)))
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
# Exactly three visibility additions to accepted31 core; no getter/warning logic change.
a=PRIOR/'f03_getaffinity_retained_v2.rs';b=ROOT/'private-postimage/kernel/rust/f03_getaffinity_retained_v2.rs'
patch.extend(difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),fromfile='a/kernel/rust/f03_getaffinity_retained_v2.rs',tofile='b/kernel/rust/f03_getaffinity_retained_v2.rs'))
patch.extend(difflib.unified_diff([], (ROOT/'f03_setaffinity_retained_v2.rs').read_text().splitlines(True),fromfile='/dev/null',tofile='b/kernel/rust/f03_setaffinity_retained_v2.rs'))
with (ROOT/'SETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch').open('x') as f:f.write(''.join(patch))
with (ROOT/'PRIVATE-PATCH-BASES-AND-POSTIMAGES.SOURCE.json').open('x') as f:json.dump(dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',bindings=rows,Source31_original=pin(a),shared31_visibility_successor=pin(b),newbody=pin(ROOT/'f03_setaffinity_retained_v2.rs'),patch=pin(ROOT/'SETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch'),only_C_declarations=True,default_OFF=True),f,indent=2);f.write('\n')
print('PRIVATE_DEFAULT_OFF_SETTER_AND_SHARED31_VISIBILITY_PATCH_PREPARED')
