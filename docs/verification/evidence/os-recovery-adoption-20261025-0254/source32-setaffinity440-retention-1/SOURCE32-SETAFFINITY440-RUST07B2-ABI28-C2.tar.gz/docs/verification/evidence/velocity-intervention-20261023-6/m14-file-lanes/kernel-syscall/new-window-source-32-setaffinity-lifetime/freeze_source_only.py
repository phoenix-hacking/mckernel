"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Freeze focused compiler prefix and setter-only paired fixture proposal; execute none.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
PRIOR=BASE/'new-window-source-31-setscheduler-lifetime'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
def pin(path):
 path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
 with (ROOT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
old=json.loads((PRIOR/'EXACT-SOURCE31-COMPILE-ONLY.NOT-GRANTED.json').read_text())
command=json.loads(json.dumps(old['commands'][0]));argv=command['argv'];argv[argv.index('--crate-name')+1]='setaffinity_retained_lifetime'
for i,arg in enumerate(argv):
 if arg.startswith('--emit=obj='):argv[i]='--emit=obj='+str(ROOT/'output-1/candidate.o')
argv[-1]=str(ROOT/'lib.fixture.rs')
command.update(name='00-setaffinity-retained-v2-reused31edgecore-actual-old-body-Rust-object',cwd=str(ROOT),purpose=SCOPE+' Compile new setter and exact original setter/mask/lock helpers with accepted31edgecore and realABI only. Reuse actualbb154/fbd later; no getter replay/fullcrate/C/native execution.')
inputs=[pin(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ['.rs','.inc','.json','.patch','.c']]
recipe=dict(scope=SCOPE,status='SOURCE_ONLY_SOURCE32_FOCUSED_COMPILE_NOT_GRANTED',commands=[command],inputs=inputs,sources=old['sources'],canonical_origins=[],header_bindings=old['header_bindings'],tools=old['tools'],fixture_tools={},requirements=['Exact ROOTordinaryCPU0onejobAS2Gfinite compile-only grant required.','Only controlled extracted actual old/new setter and reusedaccepted31edgecore; realfullcrate/provider/hash/Process/native/mask-concurrency holds remain open.','C link/runtime suffix requires actual new object, independent review and separate ROOT grant; reusebb154/fbd withoutRust/getter/prior214 replay.'])
name='EXACT-SOURCE32-COMPILE-ONLY.NOT-GRANTED.json';write(name,recipe);sha=pin(ROOT/name)['sha256']
runner=(PRIOR/'run_Source31_compile_once.NOT-GRANTED.py').read_text().replace('Source31 focused real-ABI/extracted-body affinity lifetime compile-only prefix; exact ROOT grant required.','Source32 focused setter real-ABI/accepted31core compile-only prefix; exact ROOT grant required.')
runner=runner.replace("RECIPE = ROOT / 'EXACT-SOURCE31-COMPILE-ONLY.NOT-GRANTED.json'","RECIPE = ROOT / '"+name+"'").replace("RECIPE_SHA = '133e64e37492f260ef5bf4bcf4c124e4e2c54f49f47065df58b328d3ba25ed73'","RECIPE_SHA = '"+sha+"'").replace("ROOT / 'ROOT-EXACT-SOURCE31-COMPILE-GRANT.json'","ROOT / 'ROOT-EXACT-SOURCE32-COMPILE-GRANT.json'")
runner=runner.replace("RESULT = ROOT / 'ACTUAL-SOURCE31-COMPILE-FIRST-RESULT.json'","RESULT = ROOT / 'ACTUAL-SOURCE32-COMPILE-FIRST-RESULT.json'").replace("status='PASS_FOCUSED_SOURCE31_AFFINITY_LIFETIME_COMPILE_ONLY'","status='PASS_FOCUSED_SOURCE32_SETAFFINITY_LIFETIME_COMPILE_ONLY'")
runner=runner.replace('missing exact durable ROOT source31 compile grant','missing exact durable ROOT source32 compile grant').replace("authority='Exact durable ROOT Source31 focused Rust fixture-body object compile only; no C/link/executable fixture/fullcrate/native/default action.'","authority='Exact durable ROOT Source32 focused setter Rust object compile only; no C/link/executable fixture/getter replay/fullcrate/native/default action.'")
with (ROOT/'run_Source32_compile_once.NOT-GRANTED.py').open('x') as f:f.write(runner)
ready=dict(scope=SCOPE,status='SOURCE_ONLY_SOURCE32_COMPILE_PREFIX_REQUIRES_REVIEW_ROOT_GRANT',recipe=pin(ROOT/name),runner=pin(ROOT/'run_Source32_compile_once.NOT-GRANTED.py'),source=pin(ROOT/'f03_setaffinity_retained_v2.rs'),reused31core=pin(ROOT/'AFFINITY-RETENTION-CORE.REUSED-SOURCE31.rs.inc'),fixture=pin(ROOT/'lib.fixture.rs'),C_driver=pin(ROOT/'driver.c'),patch=pin(ROOT/'SETAFFINITY-RETAINED-EDGE.DEFAULT-OFF.patch'),actual_compiles=0,native=False,default=False)
write('READY-SOURCE32-COMPILE-PREFIX.NOT-GRANTED.json',ready)
fields=json.loads((PRIOR/'ROOT-EXACT-SOURCE31-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json').read_text());fields.update(ready=pin(ROOT/'READY-SOURCE32-COMPILE-PREFIX.NOT-GRANTED.json'),recipe=ready['recipe'],runner=ready['runner']);fields['launch_argv'][-2]=ready['runner']['path'];fields['launch_argv'][-1]=ready['runner']['sha256'];write('ROOT-EXACT-SOURCE32-COMPILE-GRANT-FIELDS.PREPARED-NOT-GRANTED.json',fields)
prior_link=json.loads((PRIOR/'EXACT-SOURCE31-C-SUFFIX.FROZEN-NOT-GRANTED.json').read_text())['commands'][0]['argv']
link=prior_link[:]
for i,arg in enumerate(link):
 if arg==str(PRIOR/'driver.c'):link[i]=str(ROOT/'driver.c')
 if arg==str(PRIOR/'output-1/candidate.o'):link[i:i+1]=[str(ROOT/'output-1/candidate.o'),str(PRIOR/'output-1/candidate.o')];break
link[link.index('-o')+1]=str(ROOT/'fixture-suffix-output-1/setaffinity-parity')
suffix=dict(scope=SCOPE,status='PROVISIONAL_SOURCE32_TWO_C_COMMANDS_NO_EXECUTION_OR_NEW_OBJECT_HASH',commands=[dict(name='01-setter-genuineABI28-reused31ABI22Lookup12-C-link',argv=link,cwd=str(ROOT),purpose=SCOPE+' Controlled setter link with actualbb154warning/Atomic andfbdpositive lookup, no Rust recompile/getter replay.'),dict(name='02-controlled440pairs880calls-setter-mask-migration-lifetime',argv=[str(ROOT/'fixture-suffix-output-1/setaffinity-parity')],cwd=str(ROOT),purpose=SCOPE+' Paired old/new setter reference/mask/IRQ-token/migration/errno fixture only; no kernel or native acceptance.')],new_Rust_object=dict(path=str(ROOT/'output-1/candidate.o'),sha256=None,status='PENDING_REAL_COMPILE_PREFIX'),retained31_Rust_object=pin(PRIOR/'output-1/candidate.o'),retained_positive_lookup=pin(BASE/'new-window-source-22-positive-reference-lookup-repair/output-1/candidate.o'),oracle_expected_stdout='PASS setaffinity retained-edge comparisons=440 calls=880 overflow_repaired=20 ABI28+reusedABI22Lookup12 no-native-credit\n',negative_callback_ABI_reused=pin(PRIOR/'ACTUAL-CONTROLLED214-ABI22-LOOKUP12-AND-RELEASE.json'),controlled_pairs=440,calls=880,source_expected_overflow_repairs=20,ABI_words=28,reused_ABI_words=[22,12],matrix_plan=dict(matrix='2tidcontexts*3positivecounterstates*2statusstates*5CLongcopyresults*5maskintersections=300pairs',missing_provider='64copy/release/migrate/warn/find/unlock combinations*2tidcontexts=128pairs',special='12cases: lastowner duringmigration, denied permission, NULLcurrentProc foreign/current, user0priority, shortlen, len0, nrCPU0, exitduringprelookupcopy, currentCPU1/no migrate, negativeTid, SizeT1<<32'),preserved_order='User0EFAULT precedes provider/geometry; zero-shortscratch/copy before lookup; CLongcopyANYnonzero EFAULT inclpositivehighword; permission/empty returns consume sameedge; runqreservation lockcoverswrite and unlocksprecedes synchronousmigration/drop.',explicit_holds=['Actualpositivefind/globalhashwriter/callerProcess contracts beyond selected source','Processeligibilitymask synchronization and real nativeIRQ/migration completion semantics','Actualfullcrate/default/production/native/wholefileCretirement'],actual_C_commands=0)
write('EXACT-SOURCE32-C-SUFFIX.PROVISIONAL-NOT-GRANTED.json',suffix)
print(json.dumps(dict(READY=fields['ready'],recipe=ready['recipe'],runner=ready['runner'],fixture_pairs=440,fixture_calls=880,source_only=True)))
