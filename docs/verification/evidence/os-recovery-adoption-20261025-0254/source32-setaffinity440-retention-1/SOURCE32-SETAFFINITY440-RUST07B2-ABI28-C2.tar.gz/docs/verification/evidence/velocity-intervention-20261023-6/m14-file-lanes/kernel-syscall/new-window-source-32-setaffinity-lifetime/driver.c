/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing. */
#include <types.h>
#include <kmsg.h>
#include <ihk/cpu.h>
#include <cpulocal.h>
#include <errno.h>
#include <cls.h>
#include <syscall.h>
#include <ihk/lock.h>
#include <process.h>
#include <process_helpers.h>
#include <string.h>
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-process/new-window-source-10/next-memory-forwarding-providers-source-1/genuine-definition-and-x86-memset-correction-source-1/fixture/inline_memset.ACTUAL-C.inc"
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-22-positive-reference-lookup-repair/VERSIONED-PROVIDER-ABI.C-DECLARATIONS.inc"
extern int printf(const char *, ...), dprintf(int,const char *, ...);
extern void abort(void), free(void *);
extern int posix_memalign(void **,size_t,size_t);
#define require(v) do { if (!(v)) { dprintf(2,"FAIL affinity lifecycle line=%d: %s\n",__LINE__,#v); abort(); } } while (0)
struct sched_syscall_offsets {
    size_t thread_proc_offset,thread_sched_param_offset,thread_sched_policy_offset;
    size_t thread_cpu_id_offset,thread_cpu_set_offset,proc_pid_offset;
    size_t proc_ruid_offset,proc_euid_offset,proc_cpu_set_offset;
};
typedef unsigned long (*sched_find_thread_fn_t)(int);
typedef void (*sched_thread_unlock_fn_t)(unsigned long);
typedef int (*sched_hold_thread_fn_t)(unsigned long);
typedef void (*sched_release_thread_fn_t)(unsigned long);
typedef long (*syscall_copy_to_user_fn_t)(unsigned long,const void *,size_t);
typedef long (*syscall_copy_from_user_fn_t)(void *,unsigned long,size_t);
typedef void (*sched_request_migrate_fn_t)(int,unsigned long);
#include "/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-31-setscheduler-lifetime/VERSIONED-AFFINITY-ABI.C.inc"
#include "VERSIONED-SETAFFINITY-ABI.C.inc"
extern long f32_original_setaffinity(int,size_t,unsigned long,unsigned long,unsigned long,
    unsigned long,size_t,int,const struct sched_syscall_offsets *,sched_find_thread_fn_t,
    sched_thread_unlock_fn_t,sched_hold_thread_fn_t,sched_release_thread_fn_t,
    syscall_copy_from_user_fn_t,sched_request_migrate_fn_t);
extern int process_ref_inc_direct_result(void *,unsigned long);
extern int process_hold_thread_warn_exited_result(int);
extern const unsigned long f32_setaffinity_Rust_ABI[28],f31_affinity_Rust_ABI[22],f02_lookup_Rust_ABI[12];
static const struct sched_syscall_offsets offsets={
    __builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,sched_param),
    __builtin_offsetof(struct thread,sched_policy),__builtin_offsetof(struct thread,cpu_id),
    __builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct process,pid),
    __builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),
    __builtin_offsetof(struct process,cpu_set)};
ihk_spinlock_t runq_reservation_lock;
static struct thread current,*target;
static struct process current_process,target_process;
static struct list_head head;
static struct mcs_rwlock_node_irqsave node;
static cpu_set_t request_mask,k_mask,intersection_mask,last_mask;
static int hash_locked,writer_locked,mask_locked,modern,active_tid;
static int warnings,finds,holds,lookup_unlocks,releases,copies,locks,unlocks,migrations;
static int negative_seen,retired,migration_cpu,drop_during_migrate,exit_during_copy;
static long copy_result;
static unsigned long mask_bits(const cpu_set_t *mask){unsigned long bits;memcpy(&bits,mask,sizeof(bits));return bits;}
static void seed_mask(cpu_set_t *mask,unsigned long bits){memset(mask,0,sizeof(*mask));memcpy(mask,&bits,sizeof(bits));}
static int refcount(struct thread *thread){return __atomic_load_n(&thread->refcount.counter,__ATOMIC_SEQ_CST);}
static struct thread *selected(void){return active_tid==0?&current:target;}
void process_hold_thread_warn_bridge(void *thread){require(thread==target||thread==&current);require(((struct thread *)thread)->status==PS_EXITED);warnings++;}
static void reader_lock(unsigned long lock,void *storage){require(lock==(unsigned long)&head&&storage==&node&&!hash_locked&&!writer_locked);hash_locked=1;}
static void reader_unlock(unsigned long lock,void *storage){require(lock==(unsigned long)&head&&storage==&node&&hash_locked);hash_locked=0;}
static unsigned long find_target(int tid){
    finds++;struct process_find_thread_offsets geometry={__builtin_offsetof(struct thread,hash_list),__builtin_offsetof(struct thread,tid),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct process,pid)};
    return (unsigned long)process_find_thread_live_body_result_v2(&head,(unsigned long)&head,&node,0,tid,&geometry,reader_lock,reader_unlock,process_try_hold_thread_live_v2);
}
static void drop_reference(unsigned long address){
    struct thread *thread=(struct thread *)address;int old=__atomic_fetch_sub(&thread->refcount.counter,1,__ATOMIC_SEQ_CST);
    if(old==1&&thread==target){require(!hash_locked&&!writer_locked&&!mask_locked);writer_locked=1;head.next=head.prev=&head;target->hash_list.next=target->hash_list.prev=NULL;writer_locked=0;free(target);target=NULL;retired++;}
}
static void unlock_target(unsigned long address){lookup_unlocks++;drop_reference(address);}
static void release_target(unsigned long address){
    require(!hash_locked&&!mask_locked);releases++;memcpy(&last_mask,&((struct thread *)address)->cpu_set,sizeof(last_mask));drop_reference(address);
}
static int legacy_hold(unsigned long address){
    holds++;struct thread *thread=(struct thread *)address;
    if(process_hold_thread_warn_exited_result(thread->status))process_hold_thread_warn_bridge(thread);
    require(process_ref_inc_direct_result(thread,__builtin_offsetof(struct thread,refcount))==0);
    if(refcount(thread)<=0)negative_seen=1;return 0;
}
unsigned long process_spin_lock_bridge(unsigned long lock){
    require(lock==(unsigned long)&runq_reservation_lock&&!mask_locked&&!hash_locked);mask_locked=1;locks++;
    require(selected());if(refcount(selected())<=0)negative_seen=1;if(modern)require(refcount(selected())>0);return 0x51a7000000000051UL;
}
void process_spin_unlock_bridge(unsigned long lock,unsigned long irq){
    require(lock==(unsigned long)&runq_reservation_lock&&irq==0x51a7000000000051UL&&mask_locked&&!hash_locked);
    require(selected()&&!memcmp(&selected()->cpu_set,&intersection_mask,sizeof(cpu_set_t)));mask_locked=0;unlocks++;
}
static long copy_input(void *destination,unsigned long source,size_t bytes){
    require(destination==&k_mask&&source==(unsigned long)&request_mask&&!hash_locked&&!mask_locked);copies++;
    if(copy_result==0)memcpy(destination,&request_mask,bytes);
    if(exit_during_copy){require(target&&refcount(target)==1);drop_reference((unsigned long)target);}
    return copy_result;
}
static void migrate_target(int cpu,unsigned long address){
    require(!hash_locked&&!mask_locked&&(struct thread *)address==selected());migrations++;migration_cpu=cpu;
    if(refcount(selected())<=0)negative_seen=1;if(modern)require(refcount(selected())>0);
    require(!memcmp(&selected()->cpu_set,&intersection_mask,sizeof(cpu_set_t)));
    if(drop_during_migrate){require(target&&(struct thread *)address==target&&refcount(target)>=2);drop_reference(address);}
}
struct outcome {long result;int warnings,finds,copies,locks,unlocks,migrations,migration_cpu,negative,retired,final_count;cpu_set_t k,intersection,applied;};
static struct outcome execute(int newer,int tid,int initial,int state,long copy_status,int mask_case,size_t len,int nr_cpus,int missing,int drop,int deny,int null_proc,int zero_user,int copy_exit,int cpu){
    void *allocation=NULL;require(posix_memalign(&allocation,__alignof__(struct thread),sizeof(struct thread))==0);
    target=allocation;memset(target,0,sizeof(*target));memset(&current,0,sizeof(current));memset(&current_process,0,sizeof(current_process));memset(&target_process,0,sizeof(target_process));
    current.proc=&current_process;current.tid=100;current.status=state;current.cpu_id=cpu;current.refcount.counter=initial;
    current_process.pid=100;current_process.euid=77;target_process.pid=200;target_process.ruid=deny?88:77;target_process.euid=deny?99:77;
    target->proc=&target_process;target->tid=201;target->status=state;target->cpu_id=cpu;target->refcount.counter=initial;
    if(null_proc)current.proc=NULL;
    unsigned long request_bits[]={1,2,4,3,0},eligible_bits[]={3,3,3,6,3};
    seed_mask(&request_mask,request_bits[mask_case]);seed_mask(&current_process.cpu_set,eligible_bits[mask_case]);seed_mask(&target_process.cpu_set,eligible_bits[mask_case]);
    seed_mask(&current.cpu_set,1);seed_mask(&target->cpu_set,1);seed_mask(&last_mask,1);
    memset(&k_mask,0xa5,sizeof(k_mask));memset(&intersection_mask,0xcc,sizeof(intersection_mask));
    head.next=head.prev=&target->hash_list;target->hash_list.next=target->hash_list.prev=&head;
    hash_locked=writer_locked=mask_locked=warnings=finds=holds=lookup_unlocks=releases=copies=locks=unlocks=migrations=negative_seen=retired=0;
    migration_cpu=-99;modern=newer;active_tid=tid;copy_result=copy_status;drop_during_migrate=drop;exit_during_copy=copy_exit;
    sched_find_thread_fn_t find=(missing&16)?NULL:find_target;sched_thread_unlock_fn_t unlock=(missing&32)?NULL:unlock_target;
    sched_release_thread_fn_t release=(missing&2)?NULL:release_target;syscall_copy_from_user_fn_t copy=(missing&1)?NULL:copy_input;
    sched_request_migrate_fn_t migrate=(missing&4)?NULL:migrate_target;
    unsigned long user=zero_user?0:(unsigned long)&request_mask;
    long result=newer?sched_setaffinity_retained_v2(tid,len,user,(unsigned long)&current,(unsigned long)&k_mask,(unsigned long)&intersection_mask,sizeof(cpu_set_t),nr_cpus,&offsets,find,unlock,(missing&8)?NULL:sched_affinity_hold_warning_v2,release,copy,migrate):
        f32_original_setaffinity(tid,len,user,(unsigned long)&current,(unsigned long)&k_mask,(unsigned long)&intersection_mask,sizeof(cpu_set_t),nr_cpus,&offsets,find,unlock,(missing&8)?NULL:legacy_hold,release,copy,migrate);
    require(!hash_locked&&!writer_locked&&!mask_locked&&locks==unlocks);
    cpu_set_t applied;if(tid==0)memcpy(&applied,&current.cpu_set,sizeof(applied));else if(target)memcpy(&applied,&target->cpu_set,sizeof(applied));else memcpy(&applied,&last_mask,sizeof(applied));
    if(result==0){unsigned long expected=request_bits[mask_case]&eligible_bits[mask_case];
        require(mask_bits(&applied)==expected);require(migrations==((expected&(1UL<<cpu))?0:1));}
    struct outcome out={result,warnings,finds,copies,locks,unlocks,migrations,migration_cpu,negative_seen,retired,tid==0?refcount(&current):(target?refcount(target):0),k_mask,intersection_mask,applied};
    if(target){head.next=head.prev=&head;free(target);target=NULL;}return out;
}
static unsigned long comparisons,overflow_repairs;
static void compare(int tid,int initial,int state,long copy_status,int mask_case,size_t len,int nr_cpus,int missing,int drop,int deny,int null_proc,int zero_user,int copy_exit,int cpu){
    struct outcome a=execute(0,tid,initial,state,copy_status,mask_case,len,nr_cpus,missing,drop,deny,null_proc,zero_user,copy_exit,cpu);
    struct outcome b=execute(1,tid,initial,state,copy_status,mask_case,len,nr_cpus,missing,drop,deny,null_proc,zero_user,copy_exit,cpu);
    require(a.result==b.result&&a.warnings==b.warnings&&a.finds==b.finds&&a.copies==b.copies&&a.locks==b.locks&&a.unlocks==b.unlocks&&a.migrations==b.migrations&&a.migration_cpu==b.migration_cpu);
    require(a.final_count==b.final_count&&a.retired==b.retired&&!memcmp(&a.k,&b.k,sizeof(a.k))&&!memcmp(&a.intersection,&b.intersection,sizeof(a.intersection))&&!memcmp(&a.applied,&b.applied,sizeof(a.applied)));
    require(!b.negative);if(a.negative){require(initial==2147483647||(tid!=0&&initial==2147483646));overflow_repairs++;}comparisons++;
}
static void abi(void){
    unsigned long words[28]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,refcount),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct thread,cpu_id),__builtin_offsetof(struct thread,status),sizeof(struct process),__builtin_offsetof(struct process,cpu_set),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),sizeof(cpu_set_t),__alignof__(cpu_set_t),sizeof(ihk_spinlock_t),__alignof__(ihk_spinlock_t),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(int),sizeof(long),__alignof__(long),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(sched_hold_thread_fn_t),sizeof(sched_release_thread_fn_t),sizeof(syscall_copy_from_user_fn_t),sizeof(sched_request_migrate_fn_t),sizeof(sched_affinity_warning_only_fn_v2),sizeof(size_t)};
    require(!memcmp(words,f32_setaffinity_Rust_ABI,sizeof(words)));
    unsigned long prior[22]={sizeof(struct thread),__alignof__(struct thread),__builtin_offsetof(struct thread,proc),__builtin_offsetof(struct thread,refcount),__builtin_offsetof(struct thread,cpu_set),__builtin_offsetof(struct thread,status),sizeof(struct process),__builtin_offsetof(struct process,ruid),__builtin_offsetof(struct process,euid),sizeof(cpu_set_t),__alignof__(cpu_set_t),sizeof(struct sched_syscall_offsets),__alignof__(struct sched_syscall_offsets),sizeof(int),sizeof(long),__alignof__(long),sizeof(sched_find_thread_fn_t),sizeof(sched_thread_unlock_fn_t),sizeof(sched_hold_thread_fn_t),sizeof(sched_release_thread_fn_t),sizeof(syscall_copy_to_user_fn_t),sizeof(sched_affinity_warning_only_fn_v2)};
    require(!memcmp(prior,f31_affinity_Rust_ABI,sizeof(prior)));
    unsigned long lookup[12]={sizeof(struct process_find_thread_offsets),__alignof__(struct process_find_thread_offsets),__builtin_offsetof(struct process_find_thread_offsets,thread_hash_list_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_tid_offset),__builtin_offsetof(struct process_find_thread_offsets,thread_proc_offset),__builtin_offsetof(struct process_find_thread_offsets,proc_pid_offset),sizeof(ihk_atomic_t),__alignof__(ihk_atomic_t),__builtin_offsetof(struct thread,refcount),sizeof(int),sizeof(process_thread_try_hold_fn_v2),sizeof(struct mcs_rwlock_node_irqsave)};
    require(!memcmp(lookup,f02_lookup_Rust_ABI,sizeof(lookup)));
}
int main(void){
    abi();int tids[]={0,201},counts[]={1,2147483646,2147483647},states[]={PS_RUNNING,PS_EXITED};long status[]={-14,-(1L<<32),0,1,1L<<32};
    for(int t=0;t<2;t++)for(int c=0;c<3;c++)for(int s=0;s<2;s++)for(int r=0;r<5;r++)for(int m=0;m<5;m++)compare(tids[t],counts[c],states[s],status[r],m,sizeof(cpu_set_t),64,0,0,0,0,0,0,0);
    for(int missing=0;missing<64;missing++){compare(0,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,missing,0,0,0,0,0,0);compare(201,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,missing,0,0,0,0,0,0);}
    compare(201,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,0,1,0,0,0,0,0);
    compare(201,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,0,0,1,0,0,0,0);
    compare(201,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,0,0,0,1,0,0,0);
    compare(0,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,0,0,0,1,0,0,0);
    compare(201,1,PS_RUNNING,0,1,sizeof(cpu_set_t),64,63,0,0,0,1,0,0);
    compare(201,1,PS_RUNNING,0,1,3,64,0,0,0,0,0,0,0);
    compare(201,1,PS_RUNNING,0,1,0,64,0,0,0,0,0,0,0);
    compare(201,1,PS_RUNNING,0,1,sizeof(cpu_set_t),0,0,0,0,0,0,0,0);
    compare(201,1,PS_EXITED,0,1,sizeof(cpu_set_t),64,0,0,0,0,0,1,0);
    compare(201,1,PS_RUNNING,0,1,sizeof(cpu_set_t),64,0,0,0,0,0,0,1);
    compare(-1,1,PS_RUNNING,0,1,sizeof(cpu_set_t),64,0,0,0,0,0,0,0);
    compare(201,1,PS_RUNNING,0,1,1UL<<32,64,0,0,0,0,0,0,0);
    require(comparisons==440&&overflow_repairs==20);
    printf("PASS setaffinity retained-edge comparisons=%lu calls=%lu overflow_repaired=%lu ABI28+reusedABI22Lookup12 no-native-credit\n",comparisons,comparisons*2,overflow_repairs);return 0;
}
