// Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
#![no_std]
#[path="/home/holden/mckernel/docs/verification/evidence/velocity-intervention-20261023-6/m14-file-lanes/kernel-syscall/new-window-source-30-fullcrate-logger-internal-linkage/candidate/kernel/rust/abi.rs"] mod abi;
use core::ptr::{read_volatile,write_volatile};
use abi::{CInt,CLong,CULong,SizeT};
include!("ACTUAL-AFFINITY-DECLARATIONS.REUSED-SOURCE31.rs.inc");
include!("ACTUAL-PARENT-HELPERS.REUSED-SOURCE31.rs.inc");
include!("ACTUAL-MASK-AND-LOCK-HELPERS.rs.inc");
include!("ACTUAL-OLD-SETAFFINITY-BODY.rs.inc");
mod f03_getaffinity_retained_v2 {
    use crate::abi::{CInt,CLong};
    use super::{sched_errno,sched_thread_proc,sched_proc_euid,sched_proc_ruid,
        sched_affinity_permission_result,SchedFindThreadFn,SchedThreadUnlockFn,
        SchedReleaseThreadFn,SchedSyscallOffsets,EINVAL,ESRCH};
    include!("AFFINITY-RETENTION-CORE.REUSED-SOURCE31.rs.inc");
}
#[path="f03_setaffinity_retained_v2.rs"] mod f03_setaffinity_retained_v2;
use core::mem::{size_of,align_of,offset_of};
#[no_mangle]
pub static f32_setaffinity_Rust_ABI:[usize;28]=[
 size_of::<abi::Thread>(),align_of::<abi::Thread>(),offset_of!(abi::Thread,proc),
 offset_of!(abi::Thread,refcount),offset_of!(abi::Thread,cpu_set),offset_of!(abi::Thread,cpu_id),
 offset_of!(abi::Thread,status),size_of::<abi::Process>(),offset_of!(abi::Process,cpu_set),
 offset_of!(abi::Process,ruid),offset_of!(abi::Process,euid),size_of::<abi::CpuSet>(),
 align_of::<abi::CpuSet>(),size_of::<abi::IhkSpinlock>(),align_of::<abi::IhkSpinlock>(),
 size_of::<SchedSyscallOffsets>(),align_of::<SchedSyscallOffsets>(),size_of::<CInt>(),
 size_of::<CLong>(),align_of::<CLong>(),size_of::<Option<SchedFindThreadFn>>(),
 size_of::<Option<SchedThreadUnlockFn>>(),size_of::<Option<SchedHoldThreadFn>>(),
 size_of::<Option<SchedReleaseThreadFn>>(),size_of::<Option<SchedCopyFromUserFn>>(),
 size_of::<Option<SchedRequestMigrateFn>>(),
 size_of::<Option<f03_getaffinity_retained_v2::SchedAffinityWarningOnlyFnV2>>(),size_of::<SizeT>(),
];
