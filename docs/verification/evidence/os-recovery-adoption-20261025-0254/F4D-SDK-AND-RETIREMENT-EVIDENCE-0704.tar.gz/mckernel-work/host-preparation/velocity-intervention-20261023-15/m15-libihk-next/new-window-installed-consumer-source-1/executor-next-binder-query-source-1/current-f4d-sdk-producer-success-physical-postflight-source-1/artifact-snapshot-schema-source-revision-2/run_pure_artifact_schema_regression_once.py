"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing."""
from pathlib import Path
import hashlib,json,signal,importlib.util
D=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current-f4d-sdk-producer-success-physical-postflight-source-1/artifact-snapshot-schema-source-revision-2')
p=D/'test_actual_sdk_producer_wrapper_artifact_schema.PURE.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='dee50356176209debe8a5ce3300a3bbb3275335ba58375866c4a298fab1bd91b'
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py');assert hashlib.sha256(H.read_bytes()).hexdigest()=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
s=importlib.util.spec_from_file_location('h',H);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
for n in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(n,h.stop)
out=D/'actual-pure-producer-artifact-schema-regression-1';out.mkdir(mode=0o700)
argv=['/usr/bin/taskset','-c','6','/usr/bin/prlimit','--as=536870912:536870912','--cpu=15:15','--fsize=4194304:4194304','--nofile=256:256','--core=0:0','--','/home/holden/anaconda3/bin/python3','-I','-B',str(p)]
h.write(out/'EXACT-ARGV-AND-GRANT.json',dict(scope=__doc__,argv=argv,grant='Root CPU6 once actualwholeartifactchecker purefixture, onejob512MiB CPU15 wall25+6 F4MiB FD256 core0, no root/reader/cleanup/native',source_sha256='dee50356176209debe8a5ce3300a3bbb3275335ba58375866c4a298fab1bd91b'))
signal.setitimer(signal.ITIMER_REAL,31);r=h.owned_capture(dict(argv=argv,purpose=__doc__+' Pure actual fullsdkproducerwrapper+sameFDartifacthelper+genuineengineschema all7artifacts and negativecontrols; no readers or mutation.'),out,25,lambda:None);h.write(out/'WHOLE-JOIN.json',r);signal.setitimer(signal.ITIMER_REAL,0)
print(json.dumps(r,sort_keys=True));assert r['returncode']==0 and all(r[k] is True for k in ('direct_child_joined','group_absent','closed_streams')) and r['error'] is None and r['retirement_error'] is None and not r['timed_out'];print((out/'stdout').read_text())
