"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Exact successful selected SDK producer normal-retirement postflight; no cleanup/replay/workload.
"""
from pathlib import Path
import hashlib,json,os,fcntl,types,stat
MANIFEST={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current-f4d-sdk-producer-success-physical-postflight-source-1/EXACT-F4D-SDK-PRODUCER-NORMAL-RETIREMENT.INPUTS.json', 'bytes': 338544, 'sha256': '5e525f7b69ea80c6828f9b0057761c712a30f84aac8844dc26381f2d5ade4db4'}
raw=Path(MANIFEST['path']).read_bytes();assert len(raw)==MANIFEST['bytes'] and hashlib.sha256(raw).hexdigest()==MANIFEST['sha256']
x=json.loads(raw)
def need(v,m):
 if not v:raise RuntimeError(m)
need(os.getuid()==os.geteuid()==0,'authenticated root postflight')
source=Path(x['cleanup_source']['path']).read_bytes();need(hashlib.sha256(source).hexdigest()==x['cleanup_source']['sha256'],'retained read-only engine')
m=types.ModuleType('_m15_install_readonly');m.__file__=x['cleanup_source']['path'];exec(compile(source,m.__file__,'exec'),m.__dict__)
for ref in x['refs']:
 row=m.observe_identity(Path(ref['path']));need(row['size']==ref['bytes'] and row['sha256']==ref['sha256'],'exact retained input:'+ref['path'])
v=json.loads(m.read_bounded(Path(x['receipt']['path'])));owner_receipt=json.loads(m.read_bounded(Path(x['owner_receipt']['path'])))
need(v==owner_receipt,'full stdout and durable owner receipt equal')
terminal=json.loads(m.read_bounded(Path(x['direct_terminal']['path'])))
need(terminal['actual_tool_session']==23810 and terminal['actual_terminal_chunk']=='f2e2fb' and terminal['tool_exit_code']==0 and terminal['owner']==dict(pid=x['owner_pid'],starttime=x['owner_starttime']),'genuine root actual23810 terminal, not invented h990')
need(terminal['captures']['DIRECT-OWNER-PROCESS-BEFORE-EXEC.json']==x['before_exec'] and terminal['captures']['owner.stdout']==x['receipt'] and terminal['captures']['owner.stderr']['bytes']==0 and terminal['retired'] is True and terminal['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE' and terminal['owner_status']=='PASS' and terminal['driver_status']=='PASS_SELECTED_SDK_EXECUTOR_PRODUCER_ONLY' and terminal['native_acceptance'] is False,'exact actual selected SDK producer tool terminal and normal retirement')
need(v['status']==v['build_status']=='PASS' and v['retired'] is True and v['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE','actual SDK producer owner PASS with successful normal cleanup')
need(v['terminal_container_retained'] is False and v['cleanup_separately_required'] is False,'normal owned removal already complete; never repeat cleanup')
need(v['container_id']==x['container_id'] and v['container_name']==x['container_name'] and v['owner_nonce']==x['nonce'],'exact failed-operation container')
def validate_sdk_producer_receipt(raw,actual_path,expected_path,ref,configuration_sha256,source_identity,expected,commands):
 need(actual_path==expected_path==ref['path'],'exact current selected SDK producer receipt path')
 need(type(raw) is bytes and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'exact existing selected SDK producer receipt bytes')
 value=json.loads(raw)
 need(value==expected and value['schema']=='mckernel.sdk-executor-default-receipt.v1' and value['status']=='PASS_SELECTED_SDK_EXECUTOR_PRODUCER_ONLY','actual typed selected SDK producer receipt')
 need(all(value[k] is False for k in ('native','default_acceptance','CLI_executed','C_library_TU','all349_provider_parity','all51_data_ABI','allocation_proof')),'no unearned native or full runtime acceptance')
 need(all(value[k] is True for k in ('Rust_main','ASM_only_archive','BUILDID_binary_bytes','generated_BUILDID_equal')),'actual selected producer properties')
 need(value['configuration_sha256']==configuration_sha256 and value['source_identity']==source_identity,'exact current configuration and materialized source')
 need(value['commands']==commands and len(commands)==9 and value['planned_new_command_indices']==[3,4,5,6,7,8],'nine records with only six new commands')
 need(value['retained_prefix']['indices']==[0,1,2] and value['retained_prefix']['replayed'] is False,'retained prefix was not replayed')
 for index,row in enumerate(commands):
  need(row['command']['index']==index and row['result']['returncode']==0,'all retained prefix and new suffix command records PASS')
  result=row['result']
  need(all(result[k] is True for k in ('direct_child_joined','group_absent','closed_streams')) and result['error'] is None and result['retirement_error'] is None and result['timed_out'] is False and result['remaining_group_members']==result['unexpected_group_members']==[],'all recorded inner command lifetimes closed')
 return value

def sdk_producer_receipt_check():
 expected=str(Path(x['request']['candidate_root'])/'evidence/receipt.json')
 preparation=x['request']['preparation'];raw=m.read_bounded(Path(preparation['path']))
 need(hashlib.sha256(raw).hexdigest()==preparation['sha256'],'exact bound preparation before source identity')
 materialized=json.loads(raw)['source_identity']
 value=validate_sdk_producer_receipt(m.read_bounded(Path(x['driver_receipt']['path'])),x['driver_receipt']['path'],expected,x['driver_receipt'],preparation['sha256'],materialized,x['expected_driver_receipt'],x['expected_driver_commands'])
 need(value==v['driver_receipt'],'durable producer receipt equals actual owner receipt field')
 for index,ref in enumerate(x['command_result_refs']):
  need(json.loads(m.read_bounded(Path(ref['path'])))==value['commands'][index],'each retained/new command equals pinned actual RESULT file')
 for container_path,item in value['artifacts'].items():
  need(container_path.startswith('/work/') and item['path']==container_path,'exact recorded artifact container namespace')
  host=Path(x['request']['candidate_root'])/container_path[len('/work/'):]
  actual=m.observe_identity(host)
  fields=('device','inode','uid','gid','mode','nlink','size','sha256','mtime_ns','ctime_ns')
  need(all(actual[k]==item[k] for k in fields),'exact actual selected producer artifact identity:'+container_path)
 prefix=value['retained_prefix'];abi=prefix['ABI_object'];actual=m.observe_identity(Path(abi['path']))
 need(actual['size']==abi['bytes'] and actual['sha256']==abi['sha256'] and str(Path(abi['path'])).startswith(prefix['original_candidate']+'/'),'exact retained ABI object')
 need(hashlib.sha256(m.read_bounded(Path(prefix['manifest']))).hexdigest()==prefix['sha256'],'exact retained prefix provenance manifest')
 return True
need(v['wait_exit_code']==0 and sdk_producer_receipt_check(),'actual selected SDK producer receipt and successful owner wait')
def finite_candidate_snapshot(fd):
 rows=[];total=0
 def metadata(s):
  return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,size=s.st_size,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
 def walk(parent,relative):
  nonlocal total
  before=os.fstat(parent);names=sorted(os.listdir(parent));rows.append(dict(relative_path=relative,kind='directory',**metadata(before)))
  for name in names:
   need(name not in ('.','..') and '/' not in name,'finite candidate name')
   rel=relative+'/'+name if relative else name;named=os.stat(name,dir_fd=parent,follow_symlinks=False)
   need(len(rows)<1024,'finite candidate entry bound')
   if stat.S_ISDIR(named.st_mode):
    child=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
    try:
     need(metadata(os.fstat(child))==metadata(named),'candidate directory name/FD identity')
     walk(child,rel)
     need(metadata(os.fstat(child))==metadata(os.stat(name,dir_fd=parent,follow_symlinks=False)),'candidate directory changed')
    finally:os.close(child)
   else:
    need(stat.S_ISREG(named.st_mode),'candidate symlink/special entry refused')
    child=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
    try:
     start=os.fstat(child);need(metadata(start)==metadata(named),'candidate file name/FD identity')
     need(start.st_size<=4194304,'finite candidate single-file bound')
     h=hashlib.sha256();size=0
     while True:
      block=os.read(child,1048576)
      if not block:break
      size+=len(block);total+=len(block);need(total<=16777216,'finite candidate total byte bound');h.update(block)
     need(size==start.st_size and metadata(start)==metadata(os.fstat(child))==metadata(os.stat(name,dir_fd=parent,follow_symlinks=False)),'candidate file stable full read')
     rows.append(dict(relative_path=rel,kind='file',sha256=h.hexdigest(),**metadata(start)))
    finally:os.close(child)
  need(names==sorted(os.listdir(parent)) and metadata(before)==metadata(os.fstat(parent)),'candidate directory stable complete traversal')
 walk(fd,'')
 return sorted(rows,key=lambda row:row['relative_path'])
def candidate_check():
 path=Path(x['request']['candidate_root']);fd,_=m.directory(path)
 try:
  before=os.fstat(fd)
  actual=dict(path=str(path),device=before.st_dev,inode=before.st_ino,mode=before.st_mode&0o7777,uid=before.st_uid,gid=before.st_gid)
  need(actual==x['request']['candidate_identity'],'exact retained real partial candidate directory identity')
  expected=json.loads(m.read_bounded(Path(x['candidate_inventory']['path'])))
  need(finite_candidate_snapshot(fd)==expected['entries'],'exact complete nonempty partial candidate FD inventory')
  need(expected['file_count']==446 and expected['entry_count']==557 and expected['total_file_bytes']==3527255,'exact finite partial artifact scope')
  after=os.fstat(fd);named=path.lstat()
  fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_nlink','st_mtime_ns','st_ctime_ns')
  need(all(getattr(before,k)==getattr(after,k)==getattr(named,k) for k in fields),'candidate FD/name identity changed')
 finally:os.close(fd)
 return actual
candidate_before=candidate_check()
need(m.read_bounded(Path(x['container_log']['path'])).decode()==x['expected_container_log'],'exact retained failed configure container log')
need(v['operation_lease']['nonce']==x['operation_lease_nonce'] and x['operation_lease_nonce']!=x['nonce'],'operation-lease and runtime nonces distinct')
need(v['terminal_container_info'] is None and v['terminal_container_info_current'] is True,'truthful normal-removal receipt shape')
for name in ('inspect-terminal.json','inspect-terminal-fresh.json'):
 refs=[ref for ref in x['refs'] if Path(ref['path']).name==name]
 need(len(refs)==1,'exact already-pinned durable terminal inspect:'+name)
 item=json.loads(m.read_bounded(Path(refs[0]['path'])))
 need(item['Id']==x['container_id'] and item['Name']=='/'+x['container_name'] and item['State']['Status']=='exited' and item['State']['Running'] is False and item['State']['Pid']==0 and item['State']['ExitCode']==0,'actual durable terminal failure inspect')
need(v['client_count']==14 and v['postflight']['all_clients_reaped'] is True and v['postflight']['container_absent'] is True,'actual14normalclients and removal')
for name in ('shared_record','common_record','operation_lease'):
 need(v[name]['pid']==x['owner_pid'] and v[name]['starttime']==x['owner_starttime'],'exact owned record birth:'+name)
for group in v['client_group_checks']+v['admission_client_group_checks']:
 need(group['empty'] is True and group['surviving_members']==[] and 'error' not in group,'retained normal client groups closed')
for role,count,key in [('owner',14,'client_group_checks'),('admission',1,'admission_client_group_checks')]:
 wanted={(c['status']['path'],c['pid']) for c in x['clients'] if c['role']==role}
 got={(g['status_path'],g['pid']) for g in v[key]};need(got==wanted and len(got)==count,'exact closed client status set')
 for g in wanted:
  status=json.loads(m.read_bounded(Path(g[0])));need(status['state']=='exited' and status['exit_code']==0 and status['pid']==g[1],'exact client terminal status')
m.RELEASE=json.loads(m.read_bounded(Path(x['prior_mount_release']['path'])));m.BOOT_ID=x['request']['boot_id'];m.OWNER_PID=x['owner_pid'];m.OWNER_START=x['owner_starttime'];m.WAITER_PIDS=tuple(c['pid'] for c in x['clients'])+tuple(c['pid'] for c in x['query_helpers'])
m.CONTAINER=x['container_id'];m.CONTAINER_NAME=x['container_name'];m.OWNER_NONCE=x['nonce']
# Preserve all inherited publisher predicates; add only exact current owner/fill/entry argv membership.
anchor='def publisher(exe,argv):\n'
need(m.PROC_CODE.count(anchor)==1,'exact inherited publisher anchor')
current_publishers=['/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/truthful-suffix-receipt-source-1/target_tools_sdk_owner.RETAINED-PREFIX-SUFFIX.SOURCE-ONLY.py', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/fill_executor_current_review_payload.OVERLAY-FETCH-BOUND.NOT-RELEASED.py', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/publish_reviewed_release_then_exec_owner.OVERLAY-FETCH-BOUND.NOT-RELEASED.py']
m.PROC_CODE=m.PROC_CODE.replace(anchor,anchor+'    if any(p in argv for p in '+repr(current_publishers)+'): return True\n')
reader_identity=dict(pid=os.getpid(),starttime=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],boot_id=x['request']['boot_id'])
need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==m.BOOT_ID,'actual current boot')
lock=m.observe_identity(m.ROOT_LOCK);need((lock['device'],lock['inode'],lock['uid'],lock['gid'],lock['mode'],lock['nlink'],lock['size'])==(27,4,0,0,'0o644',1,0),'permanent27:4mutex')
key=f"{os.major(lock['device']):02x}:{os.minor(lock['device']):02x}:{lock['inode']}";need(not [l for l in Path('/proc/locks').read_text().splitlines() if key in l.split()],'root mutex free before read')
fd=os.open(m.ROOT_LOCK,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
try:
 need((os.fstat(fd).st_dev,os.fstat(fd).st_ino)==(27,4),'held27:4FD');fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m.validate_mount()
 paths=set(x['generic_absence_paths'])|{x['request']['common_exclusion_path'],x['request']['lease_path'],'/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock'}
 for path in paths:need(not os.path.lexists(path),'owned/exclusion path present:'+path)
 need(not m.census(),'owned failed CID/name/nonce still present')
 need(candidate_check()==candidate_before and sdk_producer_receipt_check(),'exact selected SDK producer outputs unchanged')
 # Preserve exact terminal ownership archive/release and every closed client record.
 for ref in x['refs']:
  row=m.observe_identity(Path(ref['path']));need(row['size']==ref['bytes'] and row['sha256']==ref['sha256'],'retained evidence postflight')
 for path in paths:need(not os.path.lexists(path),'post-observation ownership path present:'+path)
 need(m.observe_identity(m.ROOT_LOCK)==lock,'root mutex unchanged')
 need(candidate_check()==candidate_before,'retained candidate identity unchanged after observation')
 print(json.dumps(dict(scope=__doc__,schema='mckernel.m15.executor.sdk-producer-success.physical-readback.v1',status='PASS_M15_EXECUTOR_SDK_PRODUCER_SUCCESS_MUTEX_HELD_CURRENT_PHYSICAL',current_reader_identity=reader_identity,direct_terminal=x['direct_terminal'],original_workload_status='PASS',SDK_command_records=9,retained_prefix_indices=[0,1,2],new_command_indices=[3,4,5,6,7,8],SDK_commands_executed=6,manifest=MANIFEST,owner=dict(pid=x['owner_pid'],starttime=x['owner_starttime']),container_absent=dict(id=x['container_id'],name=x['container_name'],nonce=x['nonce']),root_lock=lock,absence_paths=sorted(paths),owner_clients=14,admission_clients=1,client_births=None,partial_candidate_inventory=x['candidate_inventory'],inner_command_births=x['inner_command_births'],proc=m.PROCESS_REPORTS[-1],artifact_native_acceptance=False),sort_keys=True))
finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
