"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing."""
from pathlib import Path
import json,hashlib,signal,importlib.util
D=Path(__file__).parent
H=Path('/home/holden/mckernel/docs/verification/evidence/phase5-m03-handshake-runtime-checkpoint-20261020-1/sdk-physical-source/run_two_commands_source_bound_corrected.py')
assert hashlib.sha256(H.read_bytes()).hexdigest()=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8'
s=importlib.util.spec_from_file_location('h',H);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
for n in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(n,h.stop)
base=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current-f4d-sdk-producer-success-physical-postflight-source-1')
rows=[('readonly_sdk_producer_success_current_proc.py', '29340c4ba405815dcbc3f95096d81ea74b556764ef3817e5b257554f6fcb2937'), ('readonly_sdk_producer_success_mutex_physical.py', '1706801cd98722289ef9ace06030ab57f35eddb786c0ea3f3915612e2047a24e')]
for i,(name,sha) in enumerate(rows):
 p=base/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
 out=D/str(i);out.mkdir(mode=0o700)
 cmd=dict(argv=['/usr/bin/sudo','-A','/usr/bin/taskset','-c','7','/usr/bin/prlimit','--as=2147483648:2147483648','--cpu=30:30','--fsize=33554432:33554432','--core=0:0','--nofile=256','--','/home/holden/anaconda3/bin/python3','-I','-B',str(p)],purpose=__doc__+' Exact current failedSDK owner read-only normal-retirement PROC or mutex/exclusion proof; no cleanup or workload.')
 signal.setitimer(signal.ITIMER_REAL,70);r=h.owned_capture(cmd,out,60,lambda:None);h.write(out/'WHOLE-JOIN.json',r);signal.setitimer(signal.ITIMER_REAL,0)
 assert r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and r['error'] is None and r['retirement_error'] is None and not r['timed_out']
 print(json.dumps(dict(index=i,returncode=r['returncode'],seconds=r['seconds'])))
