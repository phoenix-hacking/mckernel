"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing."""
from pathlib import Path
import json,hashlib,os,stat,ast,re
B=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1');O=B/'current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3';D=B/'current-f4d-sdk-producer-success-physical-postflight-source-1';D.mkdir(mode=0o755)
def desc(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,s):
 with p.open('x') as f:f.write(s)
 return desc(p)
def js(p,v):return write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
T=Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/F4D-ACTUAL-SDK-SUFFIX-RESULT-AND-TOOL-TERMINAL.json');assert desc(T)['sha256']=='596f2718898b42ff4b7b4772648d2f9b3b0e39c1ecda2ee524030f6c44c532e7';t=json.loads(T.read_text());v=json.loads(Path(t['captures']['owner.stdout']['path']).read_text());req=v['request'];C=Path(req['candidate_root']);E=Path(req['owner_evidence_root']);S=Path(req['request_path']).parent;Q=S/'admission-preparation-2/root-readonly-admission-capture-1';q=json.loads((Q/'ACTUAL-DIRECT-EXIT-AND-CLIENT-ABSENCE.json').read_text());driverpath=C/'evidence/receipt.json';driver=json.loads(driverpath.read_text());prep=json.loads(Path(req['preparation']['path']).read_text());assert driver==v['driver_receipt'];assert driver['source_identity']==prep['source_identity'];assert driver['configuration_sha256']==req['preparation']['sha256'];assert v['status']==v['build_status']=='PASS' and v['retired'] and v['wait_exit_code']==0 and v['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE'
prefix=driver['retained_prefix'];pm=json.loads(Path(prefix['manifest']).read_text());assert desc(prefix['manifest'])['sha256']==prefix['sha256'];assert prefix['indices']==[0,1,2] and prefix['replayed'] is False
commands=[];commandrefs=[];inner=[]
for i in range(9):
 if i<3:rp=Path(pm['prefix'][i]['files']['RESULT.json']['path'])
 else:rp=C/f'output/m15-executor-captures/{i:02d}/RESULT.json'
 row=json.loads(rp.read_text());assert row==driver['commands'][i];assert row['command']['index']==i and row['result']['returncode']==0;commands.append(row);commandrefs.append(desc(rp))
 if i>=3:inner.append(dict(index=i,**json.loads((rp.parent/'started.json').read_text())))
clients=[]
for role,key in [('owner','client_group_checks'),('admission','admission_client_group_checks')]:
 for path,pid in sorted({(z['status_path'],z['pid']) for z in v[key]}):
  status=json.loads(Path(path).read_text());assert status['state']=='exited' and status['exit_code']==0;clients.append(dict(role=role,pid=pid,starttime=None,argv=status['argv'],status=desc(path)))
assert len(clients)==15
helpers=[dict(role='direct-query',pid=q['direct_process']['pid'],starttime=q['direct_process']['starttime'])]+[dict(role='query-client',pid=z['pid'],starttime=z['recorded_birth'],source_record_has_no_birth=z['source_record_has_no_birth'],status_path=z['status_path']) for z in q['client_checks']]
oldready=json.loads((O/'READY.CORRECTED-ACTUAL-FAILED-DRIVER-RECEIPT-WRAPPER.PURE-PASS.NOT-RELEASED.json').read_text());old=json.loads(Path(oldready['manifest']['path']).read_text());source=Path(oldready['readers'][0]['path']).read_text();tree=ast.parse(source);snapshot=ast.get_source_segment(source,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='finite_candidate_snapshot')).replace('len(rows)<256','len(rows)<1024');ns=dict(os=os,stat=stat,hashlib=hashlib,need=lambda ok,msg:None if ok else (_ for _ in ()).throw(RuntimeError(msg)));exec(snapshot,ns);fd=os.open(C,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:inventory=ns['finite_candidate_snapshot'](fd)
finally:os.close(fd)
files=[r for r in inventory if r['kind']=='file'];assert len(inventory)==557 and len(files)==446 and sum(r['size'] for r in files)==3527255
ir=js(D/'EXACT-F4D-SDK-PRODUCER-CANDIDATE-FD-INVENTORY.json',dict(scope=__doc__,candidate_identity=req['candidate_identity'],entries=inventory,entry_count=557,file_count=446,total_file_bytes=3527255,SDK_commands_executed=6,retained_prefix_indices=[0,1,2],new_command_indices=[3,4,5,6,7,8]))
refs={}
def add(p):
 p=Path(p);refs[str(p)]=desc(p)
for base in (E,E.parent/('native-running-modules-admission-'+v['owner_nonce']),S/'actual-root-final-publish-and-owner-1',Q,Q.parent/'root-readonly-admission-preview-1',C):
 for root,dirs,names in os.walk(base,onerror=lambda e:(_ for _ in ()).throw(e),followlinks=False):
  for n in dirs:assert not (Path(root)/n).is_symlink()
  for n in names:add(Path(root)/n)
for row in pm['prefix']:
 rp=Path(row['files']['RESULT.json']['path'])
 for p in rp.parent.iterdir():
  assert p.is_file() and not p.is_symlink();add(p)
add(prefix['ABI_object']['path']);add(prefix['manifest']);add(pm['failed_receipt']['path'])
before=t['captures']['DIRECT-OWNER-PROCESS-BEFORE-EXEC.json'];argv=json.loads(Path(before['path']).read_text())['argv'];ownerpaths=[Path(a) for a in argv if Path(a).name.startswith('target_tools_sdk_owner')];assert len(ownerpaths)==1;ownerpath=ownerpaths[0];fill=S/'fill_executor_current_review_payload.OVERLAY-FETCH-BOUND.NOT-RELEASED.py';entry=S/'publish_reviewed_release_then_exec_owner.OVERLAY-FETCH-BOUND.NOT-RELEASED.py'
for p in (T,S/'RELEASE.ROOT.FINAL.json',S/'ROOT-ACTUAL-EXECUTION-REVIEW.json',req['request_path'],req['driver']['path'],req['preparation']['path'],before['path'],ir['path'],ownerpath,fill,entry):add(p)
x={k:old[k] for k in ('scope','cleanup_source','prior_mount_release','prior_mount_release_scope','generic_absence_paths')};x.update(SDK_commands_executed=6,SDK_command_records=9,retained_prefix_indices=[0,1,2],new_command_indices=[3,4,5,6,7,8],before_exec=before,clients=clients,client_births=None,container_id=v['container_id'],container_name=v['container_name'],container_log=desc(E/'container.log'),direct_terminal=desc(T),driver_receipt=desc(driverpath),expected_driver_receipt=driver,expected_driver_commands=commands,command_result_refs=commandrefs,retained_prefix=prefix,expected_container_log=(E/'container.log').read_text(),inner_command_births=inner,nonce=v['owner_nonce'],operation_lease_nonce=v['operation_lease']['nonce'],owner_pid=t['owner']['pid'],owner_starttime=t['owner']['starttime'],owner_receipt=desc(E/'owner-receipt.json'),query_helper_absence_proof=desc(Q/'ACTUAL-DIRECT-EXIT-AND-CLIENT-ABSENCE.json'),query_helpers=helpers,receipt=t['captures']['owner.stdout'],request=req,request_ref=desc(req['request_path']),refs=sorted(refs.values(),key=lambda z:z['path']),candidate_inventory=ir,limitation='Selected SDK producer-only PASS with six actual new suffix commands03..08 and three immutable retained00..02 records; no native/default/fullruntime acceptance. Dockerclient host births not recorded remain null. Historical03c failure remains FAIL and is not relabeled.')
manifest=js(D/'EXACT-F4D-SDK-PRODUCER-NORMAL-RETIREMENT.INPUTS.json',x)
guard='''def validate_sdk_producer_receipt(raw,actual_path,expected_path,ref,configuration_sha256,source_identity,expected,commands):
 need(actual_path==expected_path==ref['path'],'exact current selected SDK producer receipt path')
 need(type(raw) is bytes and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'exact existing selected SDK producer receipt bytes')
 value=json.loads(raw)
 need(value==expected and value['schema']=='mckernel.sdk-executor-default-receipt.v1' and value['status']=='PASS_SELECTED_SDK_EXECUTOR_PRODUCER_ONLY','actual typed selected SDK producer receipt')
 need(all(value[k] is False for k in ('native','default_acceptance','CLI_executed','C_library_TU','all349_provider_parity','all51_data_ABI','allocation_proof')),'no unearned native or full runtime acceptance')
 need(all(value[k] is True for k in ('Rust_main','ASM_only_archive','BUILDID_binary_bytes','generated_BUILDID_equal')),'actual selected producer properties')
 need(value['configuration_sha256']==configuration_sha256 and value['source_identity']==source_identity,'exact current configuration and materialized source')
 need(value['commands']==commands and len(commands)==9 and value['planned_new_command_indices']==[3,4,5,6,7,8],'nine records with only six new commands')
 need(value['retained_prefix']['indices']==[0,1,2] and value['retained_prefix']['replayed'] is False,'retained prefix was not replayed')
 for index,row in enumerate(commands):
  need(row['command']['index']==index and row['result']['returncode']==0,'all retained prefix and new suffix command records PASS')
  result=row['result']
  need(all(result[k] is True for k in ('direct_child_joined','group_absent','closed_streams')) and result['error'] is None and result['retirement_error'] is None and result['timed_out'] is False and result['remaining_group_members']==result['unexpected_group_members']==[],'all recorded inner command lifetimes closed')
 return value

def sdk_producer_receipt_check():
 expected=str(Path(x['request']['candidate_root'])/'evidence/receipt.json')
 preparation=x['request']['preparation'];raw=m.read_bounded(Path(preparation['path']))
 need(hashlib.sha256(raw).hexdigest()==preparation['sha256'],'exact bound preparation before source identity')
 materialized=json.loads(raw)['source_identity']
 value=validate_sdk_producer_receipt(m.read_bounded(Path(x['driver_receipt']['path'])),x['driver_receipt']['path'],expected,x['driver_receipt'],preparation['sha256'],materialized,x['expected_driver_receipt'],x['expected_driver_commands'])
 need(value==v['driver_receipt'],'durable producer receipt equals actual owner receipt field')
 for index,ref in enumerate(x['command_result_refs']):
  need(json.loads(m.read_bounded(Path(ref['path'])))==value['commands'][index],'each retained/new command equals pinned actual RESULT file')
 for container_path,item in value['artifacts'].items():
  need(container_path.startswith('/work/') and item['path']==container_path,'exact recorded artifact container namespace')
  host=Path(x['request']['candidate_root'])/container_path[len('/work/'):]
  actual=m.observe_identity(host)
  fields=('device','inode','uid','gid','mode','nlink','size','sha256','mtime_ns','ctime_ns')
  need(all(actual[k]==item[k] for k in fields),'exact actual selected producer artifact identity:'+container_path)
 prefix=value['retained_prefix'];abi=prefix['ABI_object'];actual=m.observe_identity(Path(abi['path']))
 need(actual['size']==abi['bytes'] and actual['sha256']==abi['sha256'] and str(Path(abi['path'])).startswith(prefix['original_candidate']+'/'),'exact retained ABI object')
 need(hashlib.sha256(m.read_bounded(Path(prefix['manifest']))).hexdigest()==prefix['sha256'],'exact retained prefix provenance manifest')
 return True
'''
readers=[]
for oldref in oldready['readers']+[oldready['postjoin_template']]:
 p=Path(oldref['path']);s=p.read_text();s=re.sub(r'^MANIFEST=.*$', 'MANIFEST='+repr(manifest),s,flags=re.M)
 start=s.index("need(terminal['tool_session_id']");end=s.index("need(v['status']",start)
 s=s[:start]+"""need(terminal['actual_tool_session']==23810 and terminal['actual_terminal_chunk']=='f2e2fb' and terminal['tool_exit_code']==0 and terminal['owner']==dict(pid=x['owner_pid'],starttime=x['owner_starttime']),'genuine root actual23810 terminal, not invented h990')
need(terminal['captures']['DIRECT-OWNER-PROCESS-BEFORE-EXEC.json']==x['before_exec'] and terminal['captures']['owner.stdout']==x['receipt'] and terminal['captures']['owner.stderr']['bytes']==0 and terminal['retired'] is True and terminal['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE' and terminal['owner_status']=='PASS' and terminal['driver_status']=='PASS_SELECTED_SDK_EXECUTOR_PRODUCER_ONLY' and terminal['native_acceptance'] is False,'exact actual selected SDK producer tool terminal and normal retirement')
"""+s[end:]
 s=s.replace("v['status']==v['build_status']=='FAIL'","v['status']==v['build_status']=='PASS'").replace('actual failed owner with successful normal cleanup','actual SDK producer owner PASS with successful normal cleanup')
 start=s.index('def validate_failed_driver_receipt(');end=s.index('def finite_candidate_snapshot(',start)
 s=s[:start]+guard+"need(v['wait_exit_code']==0 and sdk_producer_receipt_check(),'actual selected SDK producer receipt and successful owner wait')\n"+s[end:]
 s=s.replace('len(rows)<256','len(rows)<1024').replace("expected['file_count']==61 and expected['entry_count']==89 and expected['total_file_bytes']==749822","expected['file_count']==446 and expected['entry_count']==557 and expected['total_file_bytes']==3527255")
 start=s.index("need(terminal['successful_command_indices']");end=s.index("need(m.read_bounded(Path(x['container_log']['path']))",start);s=s[:start]+s[end:]
 start=s.index("failed_join=json.loads(");end=s.index('# Preserve all inherited publisher predicates;',start);s=s[:start]+s[end:]
 s=re.sub(r'^current_publishers=.*$', 'current_publishers='+repr([str(ownerpath),str(fill),str(entry)]),s,flags=re.M)
 s=s.replace('failed_driver_receipt_check()','sdk_producer_receipt_check()')
 s=s.replace('partial-compiler-failure','sdk-producer-success').replace('PARTIAL_COMPILER_FAILURE','SDK_PRODUCER_SUCCESS').replace("original_workload_status='FAIL',failed_observer_capture=x['failed_observer_capture'],failed_observer_identity=x['failed_observer_identity'],","original_workload_status='PASS',SDK_command_records=9,retained_prefix_indices=[0,1,2],new_command_indices=[3,4,5,6,7,8],")
 s=s.replace("value['original_workload_status']=='FAIL' and value['SDK_commands_executed']==4","value['original_workload_status']=='PASS' and value['SDK_commands_executed']==6 and value['SDK_command_records']==9")
 s=s.replace('SDK_commands_executed=4','SDK_commands_executed=6').replace('Exact partial-compiler-failed SDK owner normal-retirement postflight','Exact successful selected SDK producer normal-retirement postflight')
 s=s.replace('partial SDK outputs unchanged','selected SDK producer outputs unchanged').replace('nonempty partial compiler candidate unchanged','nonempty successful SDK producer candidate unchanged')
 ast.parse(s);assert 'failed_driver' not in s and 'failed_observer' not in s and 'successful_command_indices' not in s
 newname=p.name.replace('partial_compiler_failure','sdk_producer_success');readers.append(write(D/newname,s))
r=Path(oldready['runner']['path']).read_text();r=re.sub(r'^base=Path\(.*$', 'base=Path('+repr(str(D))+')',r,flags=re.M);r=re.sub(r'^rows=.*$', 'rows='+repr([(Path(z['path']).name,z['sha256']) for z in readers[:2]]),r,flags=re.M);runner=write(D/'run_once.py',r)
ready=dict(scope=__doc__,status='SOURCE_ONLY_F4D_ACTUAL_SDK_PRODUCER_NORMAL_RETIREMENT_AWAITING_INDEPENDENT_READONLY_EXECUTION_RELEASE',manifest=manifest,candidate_inventory=ir,readers=readers[:2],postjoin_template=readers[2],runner=runner,runner_argv=['/home/holden/anaconda3/bin/python3','-I','-B',runner['path']],profile=oldready['profile'],owner=dict(pid=t['owner']['pid'],starttime=t['owner']['starttime']),runtime_nonce=v['owner_nonce'],container_id=v['container_id'],operation_lease_nonce=v['operation_lease']['nonce'],candidate_identity=req['candidate_identity'],driver_receipt=x['driver_receipt'],SDK_commands_executed=6,SDK_command_records=9,retained_prefix_indices=[0,1,2],new_command_indices=[3,4,5,6,7,8],owner_clients=14,admission_clients=1,additional_query_helpers=helpers,client_births=None,inner_command_births=inner,original_workload_status='PASS',artifact_native_acceptance=False,actual_physical=None,actual_current_postjoin=None,protected_refs=len(x['refs']),root_actual_terminal=desc(T),predecessor_reader_ready=desc(O/'READY.CORRECTED-ACTUAL-FAILED-DRIVER-RECEIPT-WRAPPER.PURE-PASS.NOT-RELEASED.json'),source_delta=['exact genuine F4D data+typed producer-only PASS receipt and successful durable inspect exit0','6new suffix commands03..08 and3readonly retained00..02;9records not9new executions','full557entry446file3527255byte stableFD candidate inventory; bound1024, file4MiB/total16MiB unchanged','exact all7 producer artifacts identities and retainedABI/provenance; no SDKnative/defaultacceptance'])
rr=js(D/'READY.CURRENT-F4D-SDK-PRODUCER-PHYSICAL.SOURCE-ONLY.json',ready)
print(json.dumps(dict(ready=rr,manifest=manifest,inventory=ir,readers=readers,runner=runner,refs=len(x['refs']),query_helpers=helpers),indent=2))
