"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure full actual sdk_producer_receipt_check and actual shared snapshot/FD functions; no observer entrypoint.
"""
from pathlib import Path
import ast,json,hashlib,copy,types,os,stat
SOURCE={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current-f4d-sdk-producer-success-physical-postflight-source-1/artifact-snapshot-schema-source-revision-2/readonly_sdk_producer_success_current_proc.py', 'bytes': 18021, 'sha256': 'bea5cc6334f466e84606a531824c602ed11d1eb4081dced3096ce3ffc585e6a0'}
MANIFEST={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current-f4d-sdk-producer-success-physical-postflight-source-1/artifact-snapshot-schema-source-revision-2/EXACT-F4D-ARTIFACT-SNAPSHOT-SCHEMA-CORRECTED.INPUTS.json', 'bytes': 345038, 'sha256': '435aaf56635931fcafe1f8d95b874a38153f7eb382a5434b29aca6461b98f5fd'}
for ref in (SOURCE,MANIFEST):
 data=Path(ref['path']).read_bytes();assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
original=json.loads(Path(MANIFEST['path']).read_bytes());engine=Path(original['cleanup_source']['path']).read_bytes();assert hashlib.sha256(engine).hexdigest()==original['cleanup_source']['sha256'];etree=ast.parse(engine);wanted={'Refusal','identity','directory','read_bounded','observe_identity'};constants={'DOCUMENT_LIMIT','PROTECTED_LIMIT'};eunits=[n for n in etree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted or isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id in constants for z in n.targets)];assert len(eunits)==7
m=types.ModuleType('actual_extracted_readonly_engine');m.__dict__.update(dict(os=os,stat=stat,hashlib=hashlib));exec(compile(ast.Module(body=eunits,type_ignores=[]),'ACTUAL_SHARED_FD_SNAPSHOT_FUNCTIONS','exec'),m.__dict__);actual_read=m.read_bounded
names={'validate_sdk_producer_receipt','sdk_producer_receipt_check','observe_producer_artifact_identity'};tree=ast.parse(Path(SOURCE['path']).read_text());units=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(units)==3
for name in ('readonly_sdk_producer_success_mutex_physical.py','readonly_sdk_producer_success_helpers_postjoin.SOURCE-ONLY.PENDING-CAPTURES.py'):
 other=ast.parse((Path(SOURCE['path']).parent/name).read_text());guards=[n for n in other.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(guards)==3 and ast.dump(ast.Module(body=guards,type_ignores=[]))==ast.dump(ast.Module(body=units,type_ignores=[]))
receipt_path=original['driver_receipt']['path'];receipt_raw=actual_read(Path(receipt_path));actual_owner=json.loads(actual_read(Path(original['receipt']['path'])));seen=set()
def need(value,message):
 if not value:raise RuntimeError(message)
def invoke(x=None,raw=None):
 x=copy.deepcopy(original) if x is None else x
 def bounded(path,maximum=m.DOCUMENT_LIMIT):
  seen.add(str(path))
  if str(path)==receipt_path and raw is not None:return raw
  return actual_read(path,maximum)
 m.read_bounded=bounded;v=copy.deepcopy(actual_owner);v['driver_receipt']=x['expected_driver_receipt']
 ns=dict(Path=Path,json=json,hashlib=hashlib,os=os,stat=stat,m=m,x=x,v=v,need=need);exec(compile(ast.Module(body=units,type_ignores=[]),'ACTUAL_FULL_RECEIPT_WRAPPER_AND_HELPER','exec'),ns)
 return ns['sdk_producer_receipt_check']()
# Original actual shared snapshot schema must remain timestamp-free; no richer fake schema.
for key in original['expected_driver_receipt']['artifacts']:
 host=Path(original['request']['candidate_root'])/key[len('/work/'):];base=m.observe_identity(host);assert 'mtime_ns' not in base and 'ctime_ns' not in base
assert invoke();negative=[]
def rejected(label,fn):
 try:fn()
 except (RuntimeError,KeyError,ValueError,TypeError,OSError):negative.append(label);return
 raise AssertionError('unexpected acceptance:'+label)
artifact=next(iter(original['expected_driver_receipt']['artifacts']))
def artifact_mutation(field,newvalue,label=None,missing=False):
 x=copy.deepcopy(original);value=x['expected_driver_receipt'];item=value['artifacts'][artifact]
 if missing:item.pop(field)
 else:item[field]=newvalue
 raw=(json.dumps(value,sort_keys=True)+'\n').encode();x['driver_receipt'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());rejected(label or field,lambda:invoke(x,raw))
base=original['expected_driver_receipt']['artifacts'][artifact]
for field in ('device','inode','size','uid','gid','nlink','mtime_ns','ctime_ns'):artifact_mutation(field,base[field]+1)
artifact_mutation('sha256','0'*64,'artifacthash');artifact_mutation('mode','0o600' if base['mode']!='0o600' else '0o644','artifactmode');artifact_mutation('mtime_ns',None,'missingmtime',True);artifact_mutation('ctime_ns',None,'missingctime',True)
x=copy.deepcopy(original);value=x['expected_driver_receipt'];value['source_identity']=x['request']['input_identity'];raw=(json.dumps(value,sort_keys=True)+'\n').encode();x['driver_receipt'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());rejected('wrongactualpreparationSourceIdentity',lambda:invoke(x,raw))
rejected('wrongrawreceipthash',lambda:invoke(raw=receipt_raw+b' '))
assert len(negative)==14
print(json.dumps(dict(scope=__doc__,status='PASS_PURE_ACTUAL_SDK_PRODUCER_FULL_WRAPPER_AND_STABLE_FD_ARTIFACT_SCHEMA',positive=1,negative=len(negative),rejected=negative,actual_artifacts=7,source=SOURCE,manifest=MANIFEST,shared_engine=original['cleanup_source'],original_shared_snapshot_has_no_timestamps=True,proof_writes=False,observer_entrypoint_executed=False,read_only_paths=sorted(seen)),sort_keys=True))
