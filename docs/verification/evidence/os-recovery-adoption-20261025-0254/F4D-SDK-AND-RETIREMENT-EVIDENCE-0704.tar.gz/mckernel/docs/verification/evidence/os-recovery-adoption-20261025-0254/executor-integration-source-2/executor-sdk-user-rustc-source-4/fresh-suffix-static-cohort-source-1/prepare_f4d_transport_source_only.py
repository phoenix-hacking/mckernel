"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Prepare existing finalfill/directentry/chain/samePID sources with genuine current03c data; no operation imports.
"""
from pathlib import Path
import ast,hashlib,json
r=Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254');b=r/'executor-integration-source-2';s=b/'executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1';old=b/'executor-sdk-config-path-source-3/precommand-input-closure-source-1/static-successor-source-1'
def ref(p):
 z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def assign(t,k,value):
 ns=[n for n in ast.parse(t).body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==k for x in n.targets)];assert len(ns)==1;n=ns[0];ls=t.splitlines(True);ls[n.lineno-1:n.end_lineno]=[k+' = '+value+'\n'];o=''.join(ls);ast.parse(o);return o

def emit(p,t):
 ast.parse(t)
 with p.open('x') as f:f.write(t)
 return ref(p)
def js(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
 return ref(p)
def literal_replacements(t,values):
 lines=t.splitlines(True);edits=[]
 for n in ast.walk(ast.parse(t)):
  if isinstance(n,ast.Constant) and type(n.value) in (str,int) and n.value in values:edits.append((n.lineno,n.col_offset,n.end_lineno,n.end_col_offset,repr(values[n.value])))
 for a,c,b,e,v in sorted(edits,reverse=True):assert a==b;l=lines[a-1];lines[a-1]=l[:c]+v+l[e:]
 return ''.join(lines)
ready=json.loads((s/'READY.FRESH-SUFFIX-STATIC-COHORT.SOURCE-ONLY.json').read_bytes());oldready=json.loads((old/'READY.FRESH-AUTHORITY-BIND-STATIC-COHORT.PENDING.json').read_bytes());refs=json.loads((s/'CURRENT03C-EXACT-FROZEN-REFS.json').read_bytes());primary=ref(r/'ROOT-RECORDED-EXECUTOR-USER-RUSTC-RETAINED-SUFFIX-SOURCE-APPROVAL.json');qref=ref(s/'admission-preparation-2/run_root_sdk_readonly_admission.py');qiref=ref(s/'admission-preparation-2/QUERY-INPUTS.ROOT.json')
original=(old/'fill_executor_current_review_payload.OVERLAY-FETCH-BOUND.NOT-RELEASED.py').read_text();t=original.replace(str(old),str(s)).replace('REQUEST.FRESH-AUTHORITY-BIND.SOURCE-ONLY.json','REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json').replace('EXACT-ELEVEN-SOURCE-MAP.FRESH-AUTHORITY-BIND.json','EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json').replace('EXACT-SOURCE15-AUTHORITY-BIND-INPUTS.json','EXACT-SOURCE17-FRESH-SUFFIX-INPUTS.json')
qtext=Path(qref['path']).read_text();block=qtext[qtext.index('# Latest03c'):qtext.index('mountpoint=owner.safe_path')].replace('owner.BOOT',"base['boot_id']");start=t.index('# Latest52f');end=t.index("base['source_review']",start);t=t[:start]+block+'\n'+t[end:]
# All freshnonce and source descriptors are literal AST data, independently from retained runtime03c nonce.
t=literal_replacements(t,{oldready['nonce']:ready['nonce'],oldready['request']['sha256']:ready['request']['sha256'],oldready['source_map']['sha256']:ready['source_map']['sha256'],'0e199d205dca98c209d948b0490369b9c83aee79d33ab06e0bf9158265470aac':'cc2b2b517c48bf83d47baa22148033c173af2bcf6532655fbc45d9039ac5e659'})
# Restore the retained current03c runtime nonce if it shares the oldfresh nonce (it does by design).
# Current-block is authoritative and remains exact query block, copied again after fresh-request literal fill.
start=t.index('# Latest03c');end=t.index("base['source_review']",start);t=t[:start]+block+'\n'+t[end:]
oldprimary=str(r/'ROOT-RECORDED-EXECUTOR-AUTHORITY-BIND-453-INPUTS-EXPERT-APPROVAL.json');t=t.replace(oldprimary,primary['path']).replace('cc36f21e778321907a8e43682ac3405707d09c632c7943f8681046bc77a3f2f9',primary['sha256'])
# Exact primary approval's truthful field schema.
t=t.replace("primary_source_approval['decision']=='PASS_SOURCE' and primary_source_approval['owner_retry_released'] is False","primary_source_approval['decision']=='PASS_SOURCE' and primary_source_approval['execution_authority'] is False")
ls=t.splitlines(True);edits=[]
for n in ast.walk(ast.parse(t)):
 if isinstance(n,ast.Compare) and isinstance(n.left,ast.Name) and n.left.id in {'primary_ref','primary_source_approval'} and len(n.comparators)==1 and isinstance(n.comparators[0],ast.Dict):
  v=primary if n.left.id=='primary_ref' else json.loads(Path(primary['path']).read_bytes());m=n.comparators[0];edits.append((m.lineno,m.col_offset,m.end_lineno,m.end_col_offset,repr(v)))
for a,c,z,e,v in sorted(edits,reverse=True):assert a==z;line=ls[a-1];ls[a-1]=line[:c]+v+line[e:]
t=''.join(ls)
# Rewrite every exact local source descriptor, including byte counts.
paths={x['path']:x for x in list(refs.values())+[ready['request'],ready['source_map'],qref,qiref,ready['ordinary_entry'],ready['inert_release'],primary,ready['source_manifest']]}
# Old query paths changed subdirectory to2, not only root.
t=t.replace(str(s/'admission-preparation-1/run_root_sdk_readonly_admission.py'),qref['path']).replace(str(s/'admission-preparation-1/QUERY-INPUTS.ROOT.json'),qiref['path'])
ls=t.splitlines(True);edits=[]
for n in ast.walk(ast.parse(t)):
 if isinstance(n,ast.Dict):
  try:v=ast.literal_eval(n)
  except (ValueError,TypeError):continue
  if isinstance(v,dict) and set(v)=={'path','bytes','sha256'} and v['path'] in paths:edits.append((n.lineno,n.col_offset,n.end_lineno,n.end_col_offset,repr(paths[v['path']])))
for a,c,z,e,v in sorted(edits,reverse=True):assert a==z;line=ls[a-1];ls[a-1]=line[:c]+v+line[e:]
t=''.join(ls)
pins={x['path']:x['sha256'] for x in list(refs.values())+[ready['request'],ready['source_map'],qref,qiref,ready['ordinary_entry'],ready['inert_release'],primary]}
for k,v in dict(COHORT_AUTHORITY='None',PINS=repr(pins),PHYSICAL_PATH='Path('+repr(refs['physical_stdout']['path'])+')',POSTJOIN_PATH='Path('+repr(refs['postjoin_stdout']['path'])+')',REQUEST_SHA=repr(ready['request']['sha256']),A="D/'admission-preparation-2'").items():t=assign(t,k,v)
t=t.replace("fetched['member_count']==len(fetched['published_members'])==15","fetched['member_count']==len(fetched['published_members'])==17")
fr=emit(s/'fill_executor_current_review_payload.SOURCE17-PENDING-AUTHORITY.py',t)
# Directentry exactpins and argv only; no lifecycle changes.
t=(old/'direct_query_entry.SOURCE-ONLY.NOT-RELEASED.py').read_text().replace("'admission-preparation-1'","'admission-preparation-2'");t=assign(t,'pins',repr({'run_root_sdk_readonly_admission.py':qref['sha256'],'QUERY-INPUTS.ROOT.json':qiref['sha256']}));er=emit(s/'direct_query_entry.SOURCE-ONLY.NOT-RELEASED.py',t)
# Existing chain and samePID wrapper bodies; finalfill/publishedproof pins genuinely pending.
t=(old/'direct_query_postjoin_prepare.PENDING-03C-AUTHORITY.py').read_text().replace("'admission-preparation-1'","'admission-preparation-2'")
for k,v in dict(FILL_REF=None,ENTRY_REF=er,QUERY_REF=qref,INPUTS_REF=qiref,REQUEST_REF=ready['request'],FETCH_SHA=None,APPROVAL_SHA=None).items():t=assign(t,k,repr(v))
cr=emit(s/'direct_query_postjoin_prepare.SOURCE17-PENDING-AUTHORITY.py',t)
t=(old/'publish_reviewed_release_then_exec_owner.PENDING-NEW-AUTHORITY.py').read_text()
for k,v in dict(FILL_REF=None,ENTRY_REF=ready['ordinary_entry'],REQUEST_REF=ready['request'],OWNER_REF=ready['owner']).items():t=assign(t,k,repr(v))
sr=emit(s/'publish_reviewed_release_then_exec_owner.SOURCE17-PENDING-AUTHORITY.py',t)
result=dict(scope=ready['scope'],fill=fr,entry=er,chain=cr,samePID=sr,query=qref,query_inputs=qiref,current_acceptance=refs['independent_current'],primary_source_approval=primary,archive=ref(s/'SOURCE-ONLY-FRESH-SUFFIX-EXECUTOR17.tar.gz'),required_genuine_future_inputs=['SOURCE17 fetched proof','owner-consumable11 approval','current authority overlay fetched proof'],query_owner_executed=False)
js(s/'READY.F4D-FULL-TRANSPORT.SOURCE17-PENDING.json',result);print(json.dumps(result))
