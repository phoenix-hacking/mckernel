"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
ROOT metadata only: exact existing query export/reviewed release flow specialized for target tools.
No owner/query/compiler/SDK imports or execution; core runtime source remains unchanged.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,time,re
COHORT_AUTHORITY = None
assert isinstance(COHORT_AUTHORITY,dict) and COHORT_AUTHORITY['overlay_fetched_proof'] is not None, 'genuine new sourceapproval/fetched/overlay data fill required before effects'
D=Path(__file__).parent
R = Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1')
P = Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1')
A = D/'admission-preparation-2'
PINS = {'/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/EXACT-03C-PARTIAL-CANDIDATE-FD-INVENTORY.json': '820ab61a2d56544e20496732219d140938763352bfe886c2908f68a261757380', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/03C-ACTUAL-FIRST-COMPILER-RESULT-AND-TOOL-TERMINAL.json': '4a09cf5f593ae9ab5c1b3146a698513dccc27022bccebf1f3bf74f7e9bd6c0e9', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/03C-ACTUAL-PHYSICAL-AND-CURRENT-ACCEPTANCE.json': '68c89b5ab8fe5af4859d8cb66603a0c64d588df9efb1a2b1abdc62de3317508e', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-source-revision-2/EXACT-03C-FAILED-DRIVER-RECEIPT-CORRECTED.INPUTS.json': '0020e6c641ae7efcf9b3dc4fe64de2f88c61bcaeb82884d8e7e1847a1eb7220e', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/1/WHOLE-JOIN.json': 'd848a5e18f82da68ec491ecc4ece3f6da50adb5a4407585c275499732a0e6f66', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_mutex_physical.py': '3cbd195463015c18a4348b4ad381978150bff8ee33270c0237383348f31da19d', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/1/stdout': 'ba4184cde44f212db9dbbd8813fe4ce99b9bcd1a6b520cc26a3e2ef32c3c055e', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/actual-helpers-postjoin-1/0/WHOLE-JOIN.json': 'c74862e3527f3719b227fbb8bba3f8865b40bb2fabe02745d3d1614fd9624c7c', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_helpers_postjoin.ACTUAL-CAPTURES.NOT-RELEASED.py': 'bdbd09e9f6efb4deac6dcc8f81a2fa0f989701d0a4461495c6d185a28623ad16', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/actual-helpers-postjoin-1/0/stdout': '4cb38d9316455244d87da2f26e55c7824205af55d03166c363d09976ab77ac07', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/0/WHOLE-JOIN.json': '32144f538a9d12b3092854762df4ecfad326f25595bc6cda80a1636f7fdac888', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_current_proc.py': 'c637c204e81a17a609513be313bb18aae97eb018a7699538cd2ccc6cfef5ccda', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/0/stdout': '163e70ce457be72e285f5e26d8f3debc8a9e60ef96f23284cdfb78a6ace955f7', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json': 'dca913c0a463437779990c7f7ed747255ae7f1e1825636243ba53d8a9b404895', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json': '098957706cfa582628a2cb8acebca72ce65212debf79c42d404c455519da5c2c', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/admission-preparation-2/run_root_sdk_readonly_admission.py': '0999f11961722e553c164671f2d032b3af2c3190a481bf69d9776f7a7f70cffa', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/admission-preparation-2/QUERY-INPUTS.ROOT.json': 'c3ca00dc64469af51a67846c7971d5d6ca10d660d80273dfe86be88fcb734799', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/ROOT-OWNER-ENTRY.PENDING.json': 'd8046f33827b3db504ed31a1e56143ac3d064c9163074996ac3c8a670f618c03', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json': 'cfa03449043abfcdb434b28a36c15a18552361db9f0806a8f27a47bdd4705c22', '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/ROOT-RECORDED-EXECUTOR-USER-RUSTC-RETAINED-SUFFIX-SOURCE-APPROVAL.json': '14fccb43074abbdcff4cc0f26701030a5179f011649f9e0e0fffa3cf065350a1'}
PHYSICAL_PATH = Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/1/stdout')
POSTJOIN_PATH = Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/actual-helpers-postjoin-1/0/stdout')
REQUEST_SHA = 'dca913c0a463437779990c7f7ed747255ae7f1e1825636243ba53d8a9b404895'
SOURCE_APPROVAL_PATH = Path(COHORT_AUTHORITY['source_approval']['path'])
MAX=32*2**20
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')

def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()

def load_raw(path,expected=None):
    path=Path(path)
    assert path.is_absolute() and not any(p.is_symlink() for p in (path,*path.parents))
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);assert stat.S_ISREG(first.st_mode) and first.st_nlink==1 and first.st_size<=MAX
        parts=[];size=0
        while True:
            part=os.read(fd,min(1048576,MAX+1-size))
            if not part:break
            parts.append(part);size+=len(part);assert size<=MAX
        last=os.fstat(fd);named=path.lstat()
        assert all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in FIELDS)
    finally:os.close(fd)
    raw=b''.join(parts);assert len(raw)==first.st_size
    digest=hashlib.sha256(raw).hexdigest()
    if expected is not None:assert digest==expected
    return raw,dict(path=str(path),sha256=digest,bytes=len(raw)),{k:getattr(first,k) for k in FIELDS}

def read(path,expected=None):
    raw,ref,meta=load_raw(path,expected);return json.loads(raw),ref,meta

def pinned(path):return read(path,PINS[str(path)])[0]

def write_raw(path,raw):
    assert not os.path.lexists(path)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        view=memoryview(raw)
        while view:
            n=os.write(fd,view);assert n>0;view=view[n:]
        os.fchown(fd,1000,1000);os.fsync(fd)
    finally:os.close(fd)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def write(path,value):return write_raw(path,canonical(value))

def fresh(query):
    now=time.time();assert type(query['at']) in (int,float) and 0<=now-query['at']<=120
    return now

assert os.getuid()==os.geteuid()==0 and len(sys.argv) in (3,4)
assert sys.argv[1] in ('--prepare-review-payload','--publish-reviewed-release')
base=pinned(R/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json')
entry=pinned(P/'ROOT-OWNER-ENTRY.PENDING.json')
request=pinned(Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json'))
if sys.argv[1]=='--prepare-review-payload':
    assert len(sys.argv)==4
    SOURCE_APPROVAL_SHA=sys.argv[3]
else:
    prior_payload,_,_=read(D/'RELEASE.ROOT.REVIEW-PAYLOAD.NOT-RELEASED.json')
    assert prior_payload['source_review']['path']==str(SOURCE_APPROVAL_PATH)
    SOURCE_APPROVAL_SHA=prior_payload['source_review']['sha256']
assert re.fullmatch('[0-9a-f]{64}',SOURCE_APPROVAL_SHA)
source_review,_,_=read(SOURCE_APPROVAL_PATH,SOURCE_APPROVAL_SHA)
source_map=pinned(Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json'))
assert request['nonce']==base['nonce']=='f4dcf272cd194553825efd493d5c034a'
assert base['request']==dict(path=str(Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json')),sha256=REQUEST_SHA)
assert SOURCE_APPROVAL_SHA==COHORT_AUTHORITY['source_approval']['sha256']
assert source_review==COHORT_AUTHORITY['source_approval_expected']
assert source_review['schema']=='mckernel.m15.executor.authority-bind03c.owner-consumable-source-review.v1'
assert source_review['decision']=='PASS_SOURCE' and source_review['reviewer']=='/root/recovery_review' and source_review['implementation_ownership'] is False
assert source_review['request_sha256']==REQUEST_SHA and source_review['source_map_sha256']=='098957706cfa582628a2cb8acebca72ce65212debf79c42d404c455519da5c2c'
assert source_review['source_sha256']==source_map['source_sha256']==base['source_sha256']
assert source_review['execution_authority'] is False and source_review['SDK_execution_released'] is False and source_review['native_acceptance'] is False
primary_source_approval,primary_ref,_=read('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/ROOT-RECORDED-EXECUTOR-USER-RUSTC-RETAINED-SUFFIX-SOURCE-APPROVAL.json','14fccb43074abbdcff4cc0f26701030a5179f011649f9e0e0fffa3cf065350a1')
assert primary_ref=={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/ROOT-RECORDED-EXECUTOR-USER-RUSTC-RETAINED-SUFFIX-SOURCE-APPROVAL.json', 'bytes': 1026, 'sha256': '14fccb43074abbdcff4cc0f26701030a5179f011649f9e0e0fffa3cf065350a1'} and primary_source_approval=={'decision': 'PASS_SOURCE', 'reviewer': '/root/recovery_review', 'implementation_ownership': False, 'ready_sha256': 'ca3a34f48a22f8ee62870f7056e62a445ab8b737f5e32f1cc1ad2237afe63132', 'owner_sha256': '12b098e4a7bfcabfc8dcc9ffab553e31d35291d45ed07fc8bf63f5e7f586d6dc', 'driver_sha256': '30a86c386f09741a18e7873f0869526edb4bc3e63524bdfc47431ac8695de3a4', 'preparation_sha256': '8d603e4fc5d61c2c2931a77064c7bb5a2a08664094bbbd797963c3db153306c7', 'commands_sha256': '4d0545fba91375a5618182f18d001c0c114b0827c207d4fbe8d56b1ee4fb4c4f', 'actual_cmake_controls_sha256': '8d368c1c00d8f8256ed28dd5e4beffd4f5646506f2017e74c682c00968c3f1b5', 'scope': 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing. ExactIHK_USER_RUSTC configureflag; threeactualfragmentgenerationcontrols; retainedactual00..02+ABI readonly and plannedfresh03..08 only; postoracles/lifetime preserved. Fieldtruthfullyplanned_new_command_indices.', 'execution_authority': False, 'SDK_native_acceptance': False}
assert primary_source_approval['decision']=='PASS_SOURCE' and primary_source_approval['execution_authority'] is False
assert source_review['primary_review_sha256']==primary_ref['sha256']
assert source_review['fetched_source_proof_sha256']==COHORT_AUTHORITY['fetched_source_proof']['sha256']
assert COHORT_AUTHORITY['fetched_source_expected']['source_archive']['sha256']=='cc2b2b517c48bf83d47baa22148033c173af2bcf6532655fbc45d9039ac5e659'
assert source_review['fetched_commit']==COHORT_AUTHORITY['fetched_commit'] and source_review['reviewer']!=base['author']
assert base['execution_review'] is None and base['status']=='PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW'
assert base['source_review'] is None and base['aggregate_review'] is None
assert base['current_physical'] is None and base['current_live_postjoin'] is None and base['fetched_source_verified'] is False
physical=pinned(PHYSICAL_PATH);postjoin=pinned(POSTJOIN_PATH)
def current_bound(ref):
    raw,actual,_=load_raw(ref['path'],ref['sha256'])
    assert actual==ref
    return json.loads(raw)

def current_join(label,stdout_label,pid,start):
    j=current_bound(CURRENT_REFS[label])
    assert j['returncode']==0 and all(j[k] is True for k in ('direct_child_joined','group_absent','closed_streams'))
    assert j['pid']==pid and str(j['start'])==start
    assert j['error'] is None and j['retirement_error'] is None and j['timed_out'] is False
    assert j['remaining_group_members']==j['unexpected_group_members']==[]
    out=j['captures']['stdout'];expected=CURRENT_REFS[stdout_label]
    assert {k:out[k] for k in ('path','sha256')}=={k:expected[k] for k in ('path','sha256')} and out['size']==expected['bytes']
    err=j['captures']['stderr'];raw,_,_=load_raw(err['path'],err['sha256']);assert len(raw)==err['size']==0
    return j

def current_bound_raw(ref):
    raw,actual,_=load_raw(ref['path'],ref['sha256']);assert actual==ref
    return raw
# Latest03c normal retirement is distinct from retained historical M14/COPY evidence.
CURRENT_REFS = {'proc_stdout': {'bytes': 45218, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/0/stdout', 'sha256': '163e70ce457be72e285f5e26d8f3debc8a9e60ef96f23284cdfb78a6ace955f7'}, 'proc_join': {'bytes': 1435, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/0/WHOLE-JOIN.json', 'sha256': '32144f538a9d12b3092854762df4ecfad326f25595bc6cda80a1636f7fdac888'}, 'physical_stdout': {'bytes': 47116, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/1/stdout', 'sha256': 'ba4184cde44f212db9dbbd8813fe4ce99b9bcd1a6b520cc26a3e2ef32c3c055e'}, 'physical_join': {'bytes': 1434, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/1/WHOLE-JOIN.json', 'sha256': 'd848a5e18f82da68ec491ecc4ece3f6da50adb5a4407585c275499732a0e6f66'}, 'postjoin_stdout': {'bytes': 48323, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/actual-helpers-postjoin-1/0/stdout', 'sha256': '4cb38d9316455244d87da2f26e55c7824205af55d03166c363d09976ab77ac07'}, 'postjoin_join': {'bytes': 1486, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/actual-helpers-postjoin-1/0/WHOLE-JOIN.json', 'sha256': 'c74862e3527f3719b227fbb8bba3f8865b40bb2fabe02745d3d1614fd9624c7c'}, 'proc_source': {'bytes': 15693, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_current_proc.py', 'sha256': 'c637c204e81a17a609513be313bb18aae97eb018a7699538cd2ccc6cfef5ccda'}, 'physical_source': {'bytes': 17394, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_mutex_physical.py', 'sha256': '3cbd195463015c18a4348b4ad381978150bff8ee33270c0237383348f31da19d'}, 'postjoin_source': {'bytes': 21197, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3/readonly_partial_compiler_failure_helpers_postjoin.ACTUAL-CAPTURES.NOT-RELEASED.py', 'sha256': 'bdbd09e9f6efb4deac6dcc8f81a2fa0f989701d0a4461495c6d185a28623ad16'}, 'manifest': {'bytes': 130076, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-source-revision-2/EXACT-03C-FAILED-DRIVER-RECEIPT-CORRECTED.INPUTS.json', 'sha256': '0020e6c641ae7efcf9b3dc4fe64de2f88c61bcaeb82884d8e7e1847a1eb7220e'}, 'direct_terminal': {'bytes': 9965, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/03C-ACTUAL-FIRST-COMPILER-RESULT-AND-TOOL-TERMINAL.json', 'sha256': '4a09cf5f593ae9ab5c1b3146a698513dccc27022bccebf1f3bf74f7e9bd6c0e9'}, 'independent_current': {'bytes': 2281, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/03C-ACTUAL-PHYSICAL-AND-CURRENT-ACCEPTANCE.json', 'sha256': '68c89b5ab8fe5af4859d8cb66603a0c64d588df9efb1a2b1abdc62de3317508e'}, 'candidate_inventory': {'bytes': 36185, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/EXACT-03C-PARTIAL-CANDIDATE-FD-INVENTORY.json', 'sha256': '820ab61a2d56544e20496732219d140938763352bfe886c2908f68a261757380'}}
CURRENT_EXPECTED_INDEPENDENT = {'schema': 'mckernel.m15.executor.partial-compiler-failure.current-acceptance.v1', 'status': 'PASS', 'reviewer': '/root/recovery_review', 'implementation_ownership': False, 'physical_accepted': True, 'current_live_postjoin_accepted': True, 'owner': {'pid': 568167, 'starttime': '70709178'}, 'runtime_nonce': '03c828b9dc994d25a082ecc8cbe54f51', 'operation_lease_nonce': 'c66772787fa541219017f53afa2132d3', 'manifest_sha256': '0020e6c641ae7efcf9b3dc4fe64de2f88c61bcaeb82884d8e7e1847a1eb7220e', 'physical_stdout_sha256': 'ba4184cde44f212db9dbbd8813fe4ce99b9bcd1a6b520cc26a3e2ef32c3c055e', 'physical_join_sha256': 'd848a5e18f82da68ec491ecc4ece3f6da50adb5a4407585c275499732a0e6f66', 'postjoin_stdout_sha256': '4cb38d9316455244d87da2f26e55c7824205af55d03166c363d09976ab77ac07', 'postjoin_whole_join_sha256': 'c74862e3527f3719b227fbb8bba3f8865b40bb2fabe02745d3d1614fd9624c7c', 'current_reader_identity': {'pid': 573524, 'starttime': '70784110', 'boot_id': '7bfc5687-6c04-4d15-84eb-b92ab9a55dcb'}, 'joined_direct_child': {'pid': 573521, 'starttime': '70784103', 'returncode': 0, 'group_absent': True}, 'candidate_inventory_sha256': '820ab61a2d56544e20496732219d140938763352bfe886c2908f68a261757380', 'candidate_entries': 89, 'candidate_files': 61, 'candidate_file_bytes': 749822, 'protected_refs': 161, 'owner_clients': 14, 'admission_clients': 1, 'additional_query_helpers': 2, 'prior_helpers': 4, 'failed_observer_sudo': {'pid': 571314, 'starttime': '70749851'}, 'failed_observer_python_identity': None, 'client_births': None, 'inner_command_births_namespace': 'container PID namespace; not HOST process identities', 'permanent_mutex_free_before': True, 'permanent_mutex_free_after': True, 'terminal_evidence_unchanged': True, 'original_workload_status': 'FAIL', 'SDK_commands_executed': 4, 'successful_command_indices': [0, 1, 2], 'first_failure_command_index': 3, 'artifact_native_acceptance': False, 'heavy_execution_released': False, 'scope': 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing. Actual03c partial-compiler-failure normal-retirement physical and current postjoin evidence only.'}
current_proc=current_bound(CURRENT_REFS['proc_stdout'])
current_physical=current_bound(CURRENT_REFS['physical_stdout'])
current_postjoin=current_bound(CURRENT_REFS['postjoin_stdout'])
current_independent=current_bound(CURRENT_REFS['independent_current'])
current_manifest=current_bound(CURRENT_REFS['manifest'])
current_terminal=current_bound(CURRENT_REFS['direct_terminal'])
for key in ('proc_source','physical_source','postjoin_source'):current_bound_raw(CURRENT_REFS[key])
assert current_independent==CURRENT_EXPECTED_INDEPENDENT
assert current_independent['status']=='PASS' and current_independent['implementation_ownership'] is False
assert current_independent['reviewer']=='/root/recovery_review' and current_independent['physical_accepted'] is True and current_independent['current_live_postjoin_accepted'] is True
assert current_independent['heavy_execution_released'] is False and current_independent['artifact_native_acceptance'] is False
assert current_independent['owner']=={'pid':568167,'starttime':'70709178'} and current_independent['runtime_nonce']=='03c828b9dc994d25a082ecc8cbe54f51'
assert current_independent['operation_lease_nonce']=='c66772787fa541219017f53afa2132d3'
assert current_independent['manifest_sha256']==CURRENT_REFS['manifest']['sha256']
assert current_independent['physical_stdout_sha256']==CURRENT_REFS['physical_stdout']['sha256'] and current_independent['physical_join_sha256']==CURRENT_REFS['physical_join']['sha256']
assert current_independent['postjoin_stdout_sha256']==CURRENT_REFS['postjoin_stdout']['sha256'] and current_independent['postjoin_whole_join_sha256']==CURRENT_REFS['postjoin_join']['sha256']
assert current_independent['current_reader_identity']==current_postjoin['current_reader_identity']
for value,identity in ((current_proc,{'boot_id':base['boot_id'],'pid':572886,'starttime':'70775677'}),(current_physical,{'boot_id':base['boot_id'],'pid':572894,'starttime':'70775708'}),(current_postjoin,{'boot_id':base['boot_id'],'pid':573524,'starttime':'70784110'})):
    assert value['current_reader_identity']==identity and value['owner']==current_independent['owner']
    assert value['manifest']==CURRENT_REFS['manifest'] and value['direct_terminal']==CURRENT_REFS['direct_terminal']
    assert value['client_births'] is None and value['inner_command_births']==[{'index': 0, 'pid': 8, 'start': 70709329}, {'index': 1, 'pid': 9, 'start': 70709333}, {'index': 2, 'pid': 12, 'start': 70709339}, {'index': 3, 'pid': 13, 'start': 70709341}] and value['SDK_commands_executed']==4 and value['original_workload_status']=='FAIL'
    proc=value['proc'];assert proc['schema']=='fp-save-image.proc.v2' and proc['status']=='COMPLETE' and proc['uid']==0 and proc['boot_id']==base['boot_id']
    assert proc['failure'] is None and proc['publishers']==[] and len(proc['snapshots'])==2
    assert all(not any(row[0]==568167 for row in sweep) for sweep in proc['snapshots'])
assert current_proc['schema']==current_physical['schema']=='mckernel.m15.executor.partial-compiler-failure.physical-readback.v1'
assert current_proc['status']=='PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_EXACT_PROC' and current_proc['owner_client_count']==14 and current_proc['admission_client_count']==1
assert current_physical['status']=='PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_MUTEX_HELD_CURRENT_PHYSICAL'
assert current_physical['container_absent']=={'id':'a2af07c8fd70162ef5a37e2a5792e791f32de4126f16567c41b288ac73ff6dc7','name':'mckernel-external-03c828b9dc994d25a082ecc8cbe54f51','nonce':'03c828b9dc994d25a082ecc8cbe54f51'}
# Current03c is the actual SDK4 failure with a retained nonempty candidate, distinct from prior precommand scope.
assert current_physical['artifact_native_acceptance'] is False
candidate_inventory=current_bound(CURRENT_REFS['candidate_inventory'])
assert current_physical['partial_candidate_inventory']==CURRENT_REFS['candidate_inventory']
assert candidate_inventory['entry_count']==current_independent['candidate_entries']==89 and candidate_inventory['file_count']==current_independent['candidate_files']==61 and candidate_inventory['total_file_bytes']==current_independent['candidate_file_bytes']==749822
assert current_independent['candidate_inventory_sha256']==CURRENT_REFS['candidate_inventory']['sha256']
assert candidate_inventory['SDK_commands_executed']==current_terminal['SDK_commands_executed']==4 and candidate_inventory['successful_command_indices']==current_terminal['successful_command_indices']==[0,1,2] and candidate_inventory['first_failure_command_index']==current_terminal['first_failure_command_index']==3
assert current_terminal['candidate_nonempty_expected'] is True and current_terminal['retired'] is True and current_terminal['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE' and current_terminal['original_workload_status']=='FAIL'
assert current_physical['failed_observer_capture']==current_postjoin['failed_observer_capture']==current_manifest['failed_observer_capture'] and current_physical['failed_observer_identity']==current_postjoin['failed_observer_identity']==current_manifest['failed_observer_identity']
assert current_manifest['failed_observer_identity']['python_pid_birth'] is None and current_independent['failed_observer_python_identity'] is None
assert current_manifest['failed_observer_identity']['sudo_pid']==current_independent['failed_observer_sudo']['pid']==571314 and current_manifest['failed_observer_identity']['sudo_starttime']==current_independent['failed_observer_sudo']['starttime']=='70749851'
failed_observer=current_bound(current_manifest['failed_observer_capture']['join'])
assert failed_observer['returncode']==1 and failed_observer['pid']==571314 and str(failed_observer['start'])=='70749851' and all(failed_observer[k] is True for k in ('direct_child_joined','group_absent','closed_streams')) and failed_observer['error'] is None and failed_observer['retirement_error'] is None and failed_observer['timed_out'] is False and failed_observer['remaining_group_members']==failed_observer['unexpected_group_members']==[]
assert all(not any(row[0]==571314 for row in sweep) for sweep in current_postjoin['proc']['snapshots'])
for stream in ('stdout','stderr'):
    failed_ref=current_manifest['failed_observer_capture'][stream];current_bound_raw(failed_ref)
    failed_cap=failed_observer['captures'][stream];assert failed_cap['path']==failed_ref['path'] and failed_cap['sha256']==failed_ref['sha256'] and failed_cap['size']==failed_ref['bytes']
assert current_manifest['failed_observer_capture']['stdout']['bytes']==0 and current_manifest['failed_observer_capture']['stderr']['bytes']>0

assert current_physical['owner_clients']==current_postjoin['owner_clients']==14 and current_physical['admission_clients']==current_postjoin['admission_clients']==1
assert current_physical['root_lock']==current_postjoin['root_lock']=={'device': 27, 'gid': 0, 'inode': 4, 'mode': '0o644', 'nlink': 1, 'path': '/run/lock/mckernel-development.lock', 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'size': 0, 'uid': 0}
assert current_physical['absence_paths']==current_postjoin['absence_paths']==['/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/image-lease.json', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/lease.json', '/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock', '/home/holden/mckernel-work/scratch/native-exact-candidate-operational-exclusion-scratch18-image-1.json', '/home/holden/mckernel-work/scratch/native-running-external-modules-operational-exclusion.json', '/home/holden/mckernel-work/scratch/native-running-external-modules.lease.json']
assert current_postjoin['schema']=='mckernel.m15.executor.partial-compiler-failure.postjoin-readback.v1'
assert current_postjoin['status']=='PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_CURRENT_HELPERS_POSTJOIN_MUTEX_FREE'
assert current_postjoin['known_prior_helpers']==[{'pid': 572886, 'role': 'proc-python', 'starttime': '70775677'}, {'pid': 572883, 'role': 'proc-sudo', 'starttime': '70775670'}, {'pid': 572894, 'role': 'physical-python', 'starttime': '70775708'}, {'pid': 572891, 'role': 'physical-sudo', 'starttime': '70775701'}]
assert current_postjoin['prior_captures']=={k:CURRENT_REFS[k] for k in ('proc_stdout','proc_join','physical_stdout','physical_join')}
assert current_postjoin['permanent_mutex_free_before'] is True and current_postjoin['permanent_mutex_free_after'] is True and current_postjoin['flock_acquired'] is False and current_postjoin['terminal_evidence_unchanged'] is True
assert all(not any(row[0] in {572886,572883,572894,572891} for row in sweep) for sweep in current_postjoin['proc']['snapshots'])
current_join('proc_join','proc_stdout',572883,'70775670')
current_join('physical_join','physical_stdout',572891,'70775701')
current_join('postjoin_join','postjoin_stdout',573521,'70784103')


base['source_review']=dict(path=str(SOURCE_APPROVAL_PATH),sha256=SOURCE_APPROVAL_SHA)
base['source_approval_primary']={k:primary_ref[k] for k in ('path','sha256')}
base['aggregate_review']={'CPU1_excluded': True, 'control_monitor_bytes': 4026531840, 'full_campaign_required_bytes': 25501368320, 'heavy_CPUs': [2, 3, 4, 5], 'heavy_memory_bytes': 12884901888, 'host_reserve_bytes': 4294967296, 'memory_available': None, 'one_heavy': True, 'ordinary_CPUs': [0, 6], 'ordinary_memory_each': 2147483648, 'scratch_actual': None, 'scratch_required': None}
E=D/'root-query-export-1';payload_path=D/'RELEASE.ROOT.REVIEW-PAYLOAD.NOT-RELEASED.json'
FETCHED_SOURCE_PROOF = COHORT_AUTHORITY['fetched_source_proof']
fetched,fetched_ref,_=read(FETCHED_SOURCE_PROOF['path'],FETCHED_SOURCE_PROOF['sha256'])
assert fetched_ref==FETCHED_SOURCE_PROOF and fetched==COHORT_AUTHORITY['fetched_source_expected']
assert fetched['schema']=='mckernel.actual.fetched.corrected.executor.source15.v1' and fetched['status']=='PASS_FETCHED_EXACT_CORRECTED_SOURCE15'
assert fetched['source_sha256']==base['source_sha256'] and fetched['request']=={'bytes': 3988, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json', 'sha256': 'dca913c0a463437779990c7f7ed747255ae7f1e1825636243ba53d8a9b404895'} and fetched['source_map']=={'bytes': 3602, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json', 'sha256': '098957706cfa582628a2cb8acebca72ce65212debf79c42d404c455519da5c2c'}
assert fetched['member_count']==len(fetched['published_members'])==17 and fetched['SDK_execution'] is False and fetched['native_acceptance'] is False and fetched['execution_release'] is False
assert re.fullmatch('[0-9a-f]{40}',source_review['fetched_commit']) and source_review['fetched_commit']==COHORT_AUTHORITY['fetched_commit']
assert sys.argv[1]!='--prepare-review-payload' or sys.argv[2]==FETCHED_SOURCE_PROOF['sha256']
source15={'bytes': 10620, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/EXACT-SOURCE17-FRESH-SUFFIX-INPUTS.json', 'sha256': '706cabbe0492c5bf186d15840e3868b69eef4f5deb8deec9c220a895dda43f10'}
manifest,manifest_ref,_=read(source15['path'],source15['sha256']);assert manifest_ref==source15
assert manifest['member_count']==len(manifest['members'])==15 and manifest['no_object_or_binary_build_outputs'] is True
for row in manifest['members'].values():
    raw,actual,_=load_raw(row['path'],row['sha256']);assert actual==row
assert {k[len('executor-runtime/'):]:v['sha256'] for k,v in manifest['members'].items() if k.startswith('executor-runtime/')}==base['source_sha256']
assert manifest['actual_request']=={'bytes': 3988, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json', 'sha256': 'dca913c0a463437779990c7f7ed747255ae7f1e1825636243ba53d8a9b404895'} and manifest['actual11map']=={'bytes': 3602, 'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json', 'sha256': '098957706cfa582628a2cb8acebca72ce65212debf79c42d404c455519da5c2c'}
CURRENT_OVERLAY_FETCHED_PROOF = COHORT_AUTHORITY['overlay_fetched_proof']
overlay,overlay_ref,_=read(CURRENT_OVERLAY_FETCHED_PROOF['path'],CURRENT_OVERLAY_FETCHED_PROOF['sha256'])
assert overlay_ref==CURRENT_OVERLAY_FETCHED_PROOF and overlay==COHORT_AUTHORITY['overlay_fetched_expected']
assert overlay['status']=='PASS_FETCHED_CORRECTED_EXECUTOR_CURRENT_AUTHORITY_OVERLAY'
assert overlay['source_proof']==FETCHED_SOURCE_PROOF
assert overlay['current_physical']==CURRENT_REFS['physical_stdout'] and overlay['current_postjoin']==CURRENT_REFS['postjoin_stdout']
assert overlay['query_source']=={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/admission-preparation-2/run_root_sdk_readonly_admission.py', 'bytes': 52581, 'sha256': '0999f11961722e553c164671f2d032b3af2c3190a481bf69d9776f7a7f70cffa'} and overlay['query_inputs']=={'path': '/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1/admission-preparation-2/QUERY-INPUTS.ROOT.json', 'bytes': 328, 'sha256': 'c3ca00dc64469af51a67846c7971d5d6ca10d660d80273dfe86be88fcb734799'}
assert overlay['member_count']==15 and overlay['retirement_members']==9
assert overlay['commit']==overlay['fetched_commit'] and re.fullmatch('[0-9a-f]{40}',overlay['commit']) and re.fullmatch('[0-9a-f]{40}',overlay['tree'])

if sys.argv[1]=='--prepare-review-payload':
    assert not E.exists() and not payload_path.exists()
    query_path=A/'root-readonly-admission-preview-1/ADMISSION.json'
    query,qref,qmeta=read(query_path)
    join_path=A/'ROOT-READONLY-ADMISSION-WHOLE-JOIN.json';join,jref,jmeta=read(join_path)
    assert query['status']=='PASS_READONLY_SDK_CAPACITY_IDENTITY_IMAGE_ONLY'
    assert query['request_sha256']==REQUEST_SHA and query['target_calls']==query['container_create_calls']==0
    assert query['current_physical_acceptance']==PINS[str(PHYSICAL_PATH)] and query['current_postjoin']==PINS[str(POSTJOIN_PATH)]
    assert query['current_clearance_scope']==physical['status']
    assert join['returncode']==0 and all(join[k] is True for k in ('direct_child_joined','group_absent','closed_streams'))
    assert join['error'] is None and join['retirement_error'] is None and join['timed_out'] is False
    assert join['remaining_group_members']==join['unexpected_group_members']==[]
    rawout,oref,ometa=load_raw(join['captures']['stdout']['path'],join['captures']['stdout']['sha256'])
    rawerr,eref,emeta=load_raw(join['captures']['stderr']['path'],join['captures']['stderr']['sha256'])
    assert len(rawout)==join['captures']['stdout']['size'] and len(rawerr)==join['captures']['stderr']['size']==0
    summary=json.loads(rawout);assert summary['status']==query['status'] and summary['at']==query['at']
    assert summary['resources']==query['resources'] and summary['target_calls']==0
    resources=query['resources'];assert resources['memory_available']>=25501368320
    assert resources['host_free']>=resources['host_minimum_bytes'] and resources['scratch_free']>=resources['scratch_minimum_bytes']
    now=fresh(query)
    E.mkdir(mode=0o700);os.chown(E,1000,1000)
    exports=[]
    for label,path,expected in [('ADMISSION.json',query_path,qref['sha256']),('WHOLE-JOIN.json',join_path,jref['sha256']),('stdout',Path(oref['path']),oref['sha256']),('stderr',Path(eref['path']),eref['sha256'])]:
        raw,origin,meta=load_raw(path,expected);copy=write_raw(E/label,raw)
        exports.append(dict(origin=origin,origin_identity=meta,owned_export=copy))
    export=write(E/'ROOT-AUTHENTICATED-EXPORT.json',dict(status='ROOT_EXACT_RETAINED_QUERY_AND_WHOLE_JOIN_EXPORT',record_writer='/root',root_uid=os.geteuid(),exports=exports))
    outrefs={Path(x['owned_export']['path']).name:x['owned_export'] for x in exports}
    base.update(execution_release=True,current_authority_source_proof={k:overlay_ref[k] for k in ('path','sha256')},status='PASS_EXECUTION_RELEASE',fetched_source_verified=True,fetched_source_proof={k:fetched_ref[k] for k in ('path','sha256')},
        current_physical=dict(path=str(PHYSICAL_PATH),sha256=PINS[str(PHYSICAL_PATH)]),current_live_postjoin=dict(path=str(POSTJOIN_PATH),sha256=PINS[str(POSTJOIN_PATH)]),
        actual_query={k:outrefs['ADMISSION.json'][k] for k in ('path','sha256')},actual_query_whole_join={k:outrefs['WHOLE-JOIN.json'][k] for k in ('path','sha256')},
        actual_query_stdout={k:outrefs['stdout'][k] for k in ('path','sha256')},query_export=export,
        readonly_query_source=dict(path=str(A/'run_root_sdk_readonly_admission.py'),sha256=PINS[str(A/'run_root_sdk_readonly_admission.py')]),
        readonly_query_capture_source=None)
    base['aggregate_review'].update(memory_available=resources['memory_available'],scratch_actual=resources['scratch_free'],scratch_required=resources['scratch_minimum_bytes'])
    payload={k:v for k,v in base.items() if k!='execution_review'}
    payload_ref=write(payload_path,payload)
    print(json.dumps(dict(status='PAYLOAD_FOR_INDEPENDENT_REVIEW_NOT_EXECUTION_RELEASE',payload=payload_ref,reviewed_release_payload_sha256=hashlib.sha256(canonical(payload)).hexdigest(),query_export=export,query_age=now-query['at'],remaining_seconds=120-(now-query['at']))))
else:
    review_path=Path(sys.argv[2]);review,review_ref,_=read(review_path,sys.argv[3])
    payload,payload_ref,_=read(payload_path);query,_,_=read(payload['actual_query']['path'],payload['actual_query']['sha256']);now=fresh(query)
    assert payload['nonce']==request['nonce'] and payload['request']==base['request'] and payload['source_sha256']==base['source_sha256']
    assert payload['source_review']==base['source_review'] and payload['status']=='PASS_EXECUTION_RELEASE' and 'execution_review' not in payload
    assert review['decision']=='PASS_EXECUTION' and review['implementation_ownership'] is False
    assert review['reviewer'] and review['reviewer']!=payload['author']
    assert review['reviewed_release_payload_sha256']==hashlib.sha256(canonical(payload)).hexdigest()
    final=dict(payload,execution_review={k:review_ref[k] for k in ('path','sha256')})
    release_ref=write(R/'RELEASE.ROOT.FINAL.json',final)
    argv=entry['argv'];assert '--cpu=' not in ' '.join(argv) and entry['outer_timeout'] is None and entry['outer_CPU_rlimit'] is None
    assert argv[:3]==['/usr/bin/taskset','-c','7'] and '/usr/bin/sudo' not in argv
    argv[argv.index('--release-sha256')+1]=release_ref['sha256']
    entry.update(argv=argv,at=now,memory_available=query['resources']['memory_available'],query_age_seconds=now-query['at'],release_sha256=release_ref['sha256'],status='EXACT_INDEPENDENTLY_REVIEWED_ORDINARY_ENTRY_NOT_EXECUTED',source_only=False)
    entry_ref=write(R/'ROOT-OWNER-ENTRY.FINAL.LIBDWARF1.json',entry)
    print(json.dumps(dict(status='REVIEWED_RELEASE_PUBLISHED_OWNER_NOT_EXECUTED',release=release_ref,ordinary_entry=entry_ref,query_age_seconds=now-query['at'])))
