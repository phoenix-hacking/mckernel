"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Source preparation only: existing current-reader predicates bound to genuine SDK4/nonempty03c evidence.
"""
from pathlib import Path
import ast,hashlib,json
r=Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254');b=r/'executor-integration-source-2';s=b/'executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1';old=b/'executor-sdk-config-path-source-3/precommand-input-closure-source-1/static-successor-source-1';p=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/new-window-installed-consumer-source-1/executor-next-binder-query-source-1/current03c-partial-compiler-failure-physical-postflight-source-1/actual-failed-driver-receipt-wrapper-source-revision-3')
def ref(p):
 z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def assign(t,k,v):
 ns=[n for n in ast.parse(t).body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==k for x in n.targets)];assert len(ns)==1;n=ns[0];ls=t.splitlines(True);ls[n.lineno-1:n.end_lineno]=[k+' = '+repr(v)+'\n'];out=''.join(ls);ast.parse(out);return out

def js(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 return ref(p)
ready=json.loads((s/'READY.FRESH-SUFFIX-STATIC-COHORT.SOURCE-ONLY.json').read_bytes());ind=r/'03C-ACTUAL-PHYSICAL-AND-CURRENT-ACCEPTANCE.json';primary=r/'ROOT-RECORDED-EXECUTOR-USER-RUSTC-RETAINED-SUFFIX-SOURCE-APPROVAL.json';assert ref(ind)['sha256']=='68c89b5ab8fe5af4859d8cb66603a0c64d588df9efb1a2b1abdc62de3317508e';assert ref(primary)['sha256']=='14fccb43074abbdcff4cc0f26701030a5179f011649f9e0e0fffa3cf065350a1'
i=json.loads(ind.read_bytes());ph=json.loads((p/'1/stdout').read_bytes());proc=json.loads((p/'0/stdout').read_bytes());post=json.loads((p/'actual-helpers-postjoin-1/0/stdout').read_bytes());inventory=Path(ph['partial_candidate_inventory']['path'])
refs={k:ref(path) for k,path in dict(proc_stdout=p/'0/stdout',proc_join=p/'0/WHOLE-JOIN.json',physical_stdout=p/'1/stdout',physical_join=p/'1/WHOLE-JOIN.json',postjoin_stdout=p/'actual-helpers-postjoin-1/0/stdout',postjoin_join=p/'actual-helpers-postjoin-1/0/WHOLE-JOIN.json',proc_source=p/'readonly_partial_compiler_failure_current_proc.py',physical_source=p/'readonly_partial_compiler_failure_mutex_physical.py',postjoin_source=p/'readonly_partial_compiler_failure_helpers_postjoin.ACTUAL-CAPTURES.NOT-RELEASED.py',manifest=Path(ph['manifest']['path']),direct_terminal=Path(ph['direct_terminal']['path']),independent_current=ind,candidate_inventory=inventory).items()}
assert refs['physical_stdout']['sha256']==i['physical_stdout_sha256'] and refs['postjoin_stdout']['sha256']==i['postjoin_stdout_sha256'];js(s/'CURRENT03C-EXACT-FROZEN-REFS.json',refs)
t=(old/'admission-preparation-1/run_root_sdk_readonly_admission.py').read_text();oldmap=json.loads((old/'EXACT-ELEVEN-SOURCE-MAP.FRESH-AUTHORITY-BIND.json').read_bytes());t=t.replace(str(old),str(s)).replace(oldmap['owner']['path'],ready['owner']['path']).replace(oldmap['owner']['sha256'],ready['owner']['sha256']).replace(oldmap['driver']['sha256'],ready['driver']['sha256']);t=assign(t,'CURRENT_REFS',refs);t=assign(t,'CURRENT_EXPECTED_INDEPENDENT',i)
# Exact constant replacement through AST spans, never substring placeholders or hashes.
constants={557761:568167,'70585035':'70709178','52f76375b2944beeabbc456aa483ed8a':'03c828b9dc994d25a082ecc8cbe54f51','dfa90bc0b8e1402fbfa075cf977342cf':'c66772787fa541219017f53afa2132d3',560722:proc['current_reader_identity']['pid'],'70624890':proc['current_reader_identity']['starttime'],560727:ph['current_reader_identity']['pid'],'70624918':ph['current_reader_identity']['starttime'],561541:post['current_reader_identity']['pid'],'70634942':post['current_reader_identity']['starttime'],560719:572883,'70624883':'70775670',560724:572891,'70624911':'70775701',561538:573521,'70634935':'70784103','e7b186804d5df09464fa7a4a966be4c5428bbecf085998a80a754c1422a6c36c':ph['container_absent']['id'],'mckernel-external-52f76375b2944beeabbc456aa483ed8a':ph['container_absent']['name'],'mckernel.m15.executor.precommand-failure.physical-readback.v1':'mckernel.m15.executor.partial-compiler-failure.physical-readback.v1','mckernel.m15.executor.precommand-failure.postjoin-readback.v1':'mckernel.m15.executor.partial-compiler-failure.postjoin-readback.v1','PASS_M15_EXECUTOR_PRECOMMAND_FAILURE_EXACT_PROC':'PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_EXACT_PROC','PASS_M15_EXECUTOR_PRECOMMAND_FAILURE_MUTEX_HELD_CURRENT_PHYSICAL':'PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_MUTEX_HELD_CURRENT_PHYSICAL','PASS_M15_EXECUTOR_PRECOMMAND_FAILURE_CURRENT_HELPERS_POSTJOIN_MUTEX_FREE':'PASS_M15_EXECUTOR_PARTIAL_COMPILER_FAILURE_CURRENT_HELPERS_POSTJOIN_MUTEX_FREE'}
ls=t.splitlines(True);edits=[]
for n in ast.walk(ast.parse(t)):
 if isinstance(n,ast.Constant) and type(n.value) in (int,str) and n.value in constants:
  edits.append((n.lineno,n.col_offset,n.end_lineno,n.end_col_offset,repr(constants[n.value])))
for a,c,z,e,value in sorted(edits,reverse=True):assert a==z;line=ls[a-1];ls[a-1]=line[:c]+value+line[e:]
t=''.join(ls)
needle="value['client_births'] is None and value['inner_command_births']==[] and value['SDK_commands_executed']==0";assert t.count(needle)==1;t=t.replace(needle,"value['client_births'] is None and value['inner_command_births']=="+repr(ph['inner_command_births'])+" and value['SDK_commands_executed']==4")
needle="assert current_physical['installed_artifacts']==[] and current_physical['artifact_native_acceptance'] is False";assert t.count(needle)==1
replacement="""# Current03c is the actual SDK4 failure with a retained nonempty candidate, distinct from prior precommand scope.
assert current_physical['artifact_native_acceptance'] is False
candidate_inventory=current_bound(CURRENT_REFS['candidate_inventory'])
assert current_physical['partial_candidate_inventory']==CURRENT_REFS['candidate_inventory']
assert candidate_inventory['entry_count']==current_independent['candidate_entries']==89 and candidate_inventory['file_count']==current_independent['candidate_files']==61 and candidate_inventory['total_file_bytes']==current_independent['candidate_file_bytes']==749822
assert current_independent['candidate_inventory_sha256']==CURRENT_REFS['candidate_inventory']['sha256']
assert candidate_inventory['SDK_commands_executed']==current_terminal['SDK_commands_executed']==4 and candidate_inventory['successful_command_indices']==current_terminal['successful_command_indices']==[0,1,2] and candidate_inventory['first_failure_command_index']==current_terminal['first_failure_command_index']==3
assert current_terminal['candidate_nonempty_expected'] is True and current_terminal['retired'] is True and current_terminal['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE' and current_terminal['original_workload_status']=='FAIL'
assert current_physical['failed_observer_capture']==current_postjoin['failed_observer_capture']==current_manifest['failed_observer_capture'] and current_physical['failed_observer_identity']==current_postjoin['failed_observer_identity']==current_manifest['failed_observer_identity']
assert current_manifest['failed_observer_identity']['python_pid_birth'] is None and current_independent['failed_observer_python_identity'] is None
assert current_manifest['failed_observer_identity']['sudo_pid']==current_independent['failed_observer_sudo']['pid']==571314 and current_manifest['failed_observer_identity']['sudo_starttime']==current_independent['failed_observer_sudo']['starttime']=='70749851'
failed_observer=current_bound(current_manifest['failed_observer_capture']['join'])
assert failed_observer['returncode']==1 and failed_observer['pid']==571314 and str(failed_observer['start'])=='70749851' and all(failed_observer[k] is True for k in ('direct_child_joined','group_absent','closed_streams')) and failed_observer['error'] is None and failed_observer['retirement_error'] is None and failed_observer['timed_out'] is False and failed_observer['remaining_group_members']==failed_observer['unexpected_group_members']==[]
assert all(not any(row[0]==571314 for row in sweep) for sweep in current_postjoin['proc']['snapshots'])
for stream in ('stdout','stderr'):
    failed_ref=current_manifest['failed_observer_capture'][stream];current_bound_raw(failed_ref)
    failed_cap=failed_observer['captures'][stream];assert failed_cap['path']==failed_ref['path'] and failed_cap['sha256']==failed_ref['sha256'] and failed_cap['size']==failed_ref['bytes']
assert current_manifest['failed_observer_capture']['stdout']['bytes']==0 and current_manifest['failed_observer_capture']['stderr']['bytes']>0
"""
t=t.replace(needle,replacement);t=t.replace('# Latest52f','# Latest03c')
ast.parse(t);q=s/'admission-preparation-2';q.mkdir(mode=0o700);out=q/'run_root_sdk_readonly_admission.py'
with out.open('x') as f:f.write(t)
ip=q/'QUERY-INPUTS.ROOT.json';js(ip,dict(request=ready['request']['path'],request_sha256=ready['request']['sha256']))
# Function/class source parsers and joins remain identical; only current record scope assertions and literal data differ.
def units(x):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(x).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert units(t)==units((old/'admission-preparation-1/run_root_sdk_readonly_admission.py').read_text())
result=dict(scope=ready['scope'],query=ref(out),inputs=ref(ip),current_refs=ref(s/'CURRENT03C-EXACT-FROZEN-REFS.json'),current_acceptance=ref(ind),primary_source_approval=ref(primary),functions_classes_AST_unchanged=True,scope_delta='GenuineSDK4 failure/nonempty89entrycandidate + originalfailedobserverrc1 retained; all prior parser/ownership/mutex/client/group guards preserved',source_only=True)
js(s/'READY.F4D-QUERY-CURRENT03C-SOURCE-ONLY.json',result);print(json.dumps(result))
