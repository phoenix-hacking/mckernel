"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bind genuine SOURCE17/full11 approval to the finite22 source/current metadata overlay only.
"""
from pathlib import Path
import ast,hashlib,json
r=Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254');s=r/'executor-integration-source-2/executor-sdk-user-rustc-source-4/fresh-suffix-static-cohort-source-1'
def ref(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def assign(t,k,v):
 ns=[n for n in ast.parse(t).body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==k for x in n.targets)];assert len(ns)==1;n=ns[0];ls=t.splitlines(True);ls[n.lineno-1:n.end_lineno]=[k+' = '+repr(v)+'\n'];o=''.join(ls);ast.parse(o);return o

def emit(p,t):
 ast.parse(t)
 with p.open('x') as f:f.write(t)
 return ref(p)
def js(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
 return ref(p)
fp=r/'ACTUAL-FETCHED-F4D-EXECUTOR-SOURCE17-A1F20991.json';ap=r/'ACTUAL-OWNER-CONSUMABLE-F4D-EXECUTOR-SOURCE-APPROVAL.json';assert ref(fp)['sha256']=='d7821face741cd5deaf28b419f4e2a7836b2be81f6b0bfe1da65777f44695d84';assert ref(ap)['sha256']=='b7c620d8cd05bfa70ab247287a6057f1e536a2ba87b1200356a2d9647b8ce344'
f=json.loads(fp.read_bytes());a=json.loads(ap.read_bytes());manifest=json.loads((s/'EXACT-SOURCE17-FRESH-SUFFIX-INPUTS.json').read_bytes());assert f['source_members']==manifest['members'] and len(f['source_members'])==17
c=dict(source_approval=ref(ap),source_approval_expected=a,fetched_source_proof=ref(fp),fetched_source_expected=f,fetched_commit=f['fetched_commit'],overlay_fetched_proof=None,overlay_fetched_expected=None)
old=s/'fill_executor_current_review_payload.SOURCE17-EXACT-PROOF-SHAPE.PENDING-AUTHORITY.py';t=assign(old.read_text(),'COHORT_AUTHORITY',c);t=t.replace('mckernel.m15.executor.authority-bind03c.owner-consumable-source-review.v1',a['schema']);fill=s/'fill_executor_current_review_payload.SOURCE17-FETCH-BOUND.OVERLAY-PENDING.py';fr=emit(fill,t)
bind=json.loads((s/'CURRENT-F4D-AUTHORITY-BINDINGS.PENDING.json').read_bytes());bind['fetched_source_proof']=ref(fp);bind['owner_consumable_sourceapproval']=ref(ap);br=js(s/'CURRENT-F4D-AUTHORITY-BINDINGS.SOURCE17-FETCH-BOUND.json',bind)
spec=json.loads((s/'EXACT-TWENTYTWO-F4D-AUTHORITY-OVERLAY.PENDING-FETCH.json').read_bytes());spec['base_source_proof']=spec['source_proof']=ref(fp);spec['files']['CURRENT-INSTALL-AUTHORITY-BINDINGS.json']=br;spec['files']['adjacent/finalfill.py']=fr;sp=s/'EXACT-TWENTYTWO-F4D-AUTHORITY-OVERLAY.SOURCE17-FETCH-BOUND.json';spr=js(sp,spec)
for v in spec['files'].values():assert ref(Path(v['path']))==v
pub=s/'publish_f4d_authority_overlay22.SOURCE17-FETCH-BOUND.py';pr=emit(pub,assign((s/'publish_f4d_authority_overlay22.PENDING-FETCH.py').read_text(),'SPEC',spr))
w=(s/'run_fresh_suffix_source17_archive_h990.CPU6.py').read_text().replace('archive_fresh_suffix_executor17_once.NOT-GRANTED.py',pub.name).replace('EXACT-SOURCE17-FRESH-SUFFIX-INPUTS.json',sp.name).replace('9d18ef7737b84e74a4882805ee9dcc91ba5cf6a54de014dff36500e0882e90d5',pr['sha256']).replace('706cabbe0492c5bf186d15840e3868b69eef4f5deb8deec9c220a895dda43f10',spr['sha256']).replace('actual-fresh-suffix-source17-archive-h990-1','actual-f4d-authority-overlay22-h990-1').replace('--archive-once','--publish-overlay-once').replace('Root granted finite15a0 SOURCE15 archive, fourchangedmembers only,11unchanged','Root granted finitef4d authorityoverlay22members16retirement, genuineSOURCE17/full11 sourcebound')
wp=s/'run_f4d_authority_overlay22_h990.CPU6.py';wr=emit(wp,w)
ready=dict(scope=__doc__,fill=fr,bindings=br,spec=spr,publisher=pr,wrapper=wr,destination=spec['destination'],member_count=22,retirement_members=16,source_archive_members=17,execution='ROOT_GRANTED_CPU6_ONCE_AFTER_M14_MEM_RELEASE',outer_argv=['/usr/bin/taskset','-c','6','/usr/bin/prlimit','--as=536870912:536870912','--cpu=30:30','--fsize=16777216:16777216','--nofile=256:256','--core=0:0','/usr/bin/python3','-I','-B',str(wp)])
rr=js(s/'READY.F4D-BOUND-FINITE22-OVERLAY.ROOT-GRANTED.json',ready);print(json.dumps(dict(ready=rr,**ready)))
