from pathlib import Path
import ast,hashlib,json,os,stat,uuid
b=Path('/home/holden/mckernel/docs/verification/evidence/os-recovery-adoption-20261025-0254/executor-integration-source-2');src=b/'executor-sdk-user-rustc-source-4';s=src/'fresh-suffix-static-cohort-source-1';s.mkdir(mode=0o700);old=b/'executor-sdk-config-path-source-3/precommand-input-closure-source-1/static-successor-source-1';truth=src/'truthful-suffix-receipt-source-1'
def ref(p):
 z=p.read_bytes();return dict(path=str(p),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def node(p):
 x=p.stat();return dict(path=str(p),device=x.st_dev,inode=x.st_ino,mode=stat.S_IMODE(x.st_mode),uid=x.st_uid,gid=x.st_gid)
def js(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
 return ref(p)
owner=truth/'target_tools_sdk_owner.RETAINED-PREFIX-SUFFIX.SOURCE-ONLY.py';driver=truth/'target_tools_sdk_driver.RETAINED-PREFIX-SUFFIX.SOURCE-ONLY.py';prep=src/'preparation.SUFFIX-SOURCE-ONLY.json';commands=src/'NINE-EXACT-EXECUTOR-COMMANDS.IHK-USER-RUSTC-CORRECTED.json'
assert ref(owner)['sha256']=='12b098e4a7bfcabfc8dcc9ffab553e31d35291d45ed07fc8bf63f5e7f586d6dc';assert ref(driver)['sha256']=='30a86c386f09741a18e7873f0869526edb4bc3e63524bdfc47431ac8695de3a4';assert node(src)['mode']==0o700
nonce=uuid.uuid4().hex;r=json.loads((old/'REQUEST.FRESH-AUTHORITY-BIND.SOURCE-ONLY.json').read_bytes());workspace=Path(r['output_parent_identity']['path']);candidate=workspace/('native-running-modules-candidate-'+nonce);evidence=workspace/('native-running-modules-owner-'+nonce);assert not candidate.exists() and not evidence.exists();candidate.mkdir(mode=0o700)
r.update(nonce=nonce,candidate_root=str(candidate),candidate_identity=node(candidate),owner_evidence_root=str(evidence),input_root=str(src),input_identity=node(src),driver={k:ref(driver)[k] for k in ('path','sha256')},preparation={k:ref(prep)[k] for k in ('path','sha256')},request_path=str(s/'REQUEST.FRESH-SUFFIX.SOURCE-ONLY.json'));rr=js(Path(r['request_path']),r)
m=json.loads((old/'EXACT-ELEVEN-SOURCE-MAP.FRESH-AUTHORITY-BIND.json').read_bytes());m.update(configuration=ref(prep),driver=ref(driver),owner=ref(owner),preparation=ref(prep),request=rr,nonce=nonce);m['source_sha256']['scripts/native_running_external_modules_owner.py']=ref(owner)['sha256'];m['source_sha256']['scripts/native_running_external_modules_offline.py']=ref(driver)['sha256'];mr=js(s/'EXACT-ELEVEN-SOURCE-MAP.FRESH-SUFFIX.json',m)
v=json.loads((old/'EXACT-SOURCE15-AUTHORITY-BIND-INPUTS.json').read_bytes());members=v['members']
for name,p in [('executor-data/preparation.json',prep),('executor-data/TARGET-DRIVER.INPUTS.json',prep),('executor-data/ACTUAL-FINAL-ELEVEN-SOURCE-MAP.json',Path(mr['path'])),('executor-data/REQUEST.ROOT.FINAL.SOURCE-ONLY.json',Path(rr['path'])),('executor-runtime/scripts/native_running_external_modules_owner.py',owner),('executor-runtime/scripts/native_running_external_modules_offline.py',driver),('executor-data/RETAINED-03C-PREFIX-MANIFEST.json',src/'ACTUAL03C-CONFIGURE-FAILURE-AND-BOUNDED-SOURCE-CORRECTION.json'),('executor-data/NINE-EXACT-EXECUTOR-COMMANDS.json',commands)]:members[name]=ref(p)
assert len(members)==17
for row in members.values():assert ref(Path(row['path']))==row
v.update(member_count=17,actual11map=mr,actual_request=rr,actual_current03c_physical=None,actual_independent_executor_source_approval=None,actual_pending_release=None,source_correction_ready=ref(truth/'READY.TRUTHFUL-SUFFIX-RECEIPT.SOURCE-ONLY.json'),actual_CMake_threecase_proof=ref(src/'ACTUAL-THREECASE-CMAKE-PASS-AND-SUFFIX-HANDOFF.json'))
v.pop('actual_current52f_physical',None);manifest=s/'EXACT-SOURCE17-FRESH-SUFFIX-INPUTS.json';man=js(manifest,v)
entry=json.loads((old/'ROOT-OWNER-ENTRY.PENDING.json').read_bytes());entry['argv']=[str(owner) if x==mold else x for x in entry['argv'] for mold in [json.loads((old/'EXACT-ELEVEN-SOURCE-MAP.FRESH-AUTHORITY-BIND.json').read_bytes())['owner']['path']]]
entry['argv']=[str(s/'RELEASE.ROOT.FINAL.json') if x==str(old/'RELEASE.ROOT.FINAL.json') else rr['path'] if x==str(old/'REQUEST.FRESH-AUTHORITY-BIND.SOURCE-ONLY.json') else rr['sha256'] if x=='e8b4f97897be351deaa91c97eec8f1b68cfd1f9e4502478298c0af50e5778b86' else x for x in entry['argv']];er=js(s/'ROOT-OWNER-ENTRY.PENDING.json',entry)
release=json.loads((old/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json').read_bytes());release.update(nonce=nonce,request={k:rr[k] for k in ('path','sha256')},source_sha256=m['source_sha256']);lr=js(s/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json',release)
t=(old/'archive_authority_bind_executor15_once.NOT-GRANTED.py').read_text();a=ast.parse(t);ls=t.splitlines(True)
for n in ast.walk(a):
 if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='manifest_ref' for x in n.targets):ls[n.lineno-1:n.end_lineno]=['    manifest_ref='+repr(man)+'\n']
t=''.join(ls).replace("manifest['member_count']==15","manifest['member_count']==17").replace('len(set(names))==15','len(set(names))==17').replace('member_count=15','member_count=17').replace(str(old/'SOURCE-ONLY-AUTHORITY-BIND-EXECUTOR15.tar.gz'),str(s/'SOURCE-ONLY-FRESH-SUFFIX-EXECUTOR17.tar.gz'));ast.parse(t);helper=s/'archive_fresh_suffix_executor17_once.NOT-GRANTED.py'
with helper.open('x') as f:f.write(t)
w=(old/'run_authority_bind_source15_archive_h990.CPU6.py').read_text().replace('archive_authority_bind_executor15_once.NOT-GRANTED.py',helper.name).replace('EXACT-SOURCE15-AUTHORITY-BIND-INPUTS.json',manifest.name).replace('ee456dcdff08c9d7477ca482b4a794a100d6f70a6172b7378a49199aefcb7de4',ref(helper)['sha256']).replace('e0be912b14625b01b61c4b9b96073f28d7f0c802ca9ad3a66c987f13dcf9ac5d',man['sha256']).replace('actual-authority-bind-source15-archive-h990-1','actual-fresh-suffix-source17-archive-h990-1');ast.parse(w);wp=s/'run_fresh_suffix_source17_archive_h990.CPU6.py'
with wp.open('x') as f:f.write(w)
ready=dict(scope=v['scope'],nonce=nonce,request=rr,source_map=mr,source_manifest=man,archive_helper=ref(helper),archive_wrapper=ref(wp),owner=ref(owner),driver=ref(driver),preparation=ref(prep),ordinary_entry=er,inert_release=lr,input_identity=node(src),source_identity=json.loads(prep.read_bytes())['source_identity'],candidate_identity=node(candidate),source_archive_member_count=17,extra_source_members=['retained-prefix manifest','changed exact command document'],execution_release=False,source_archive_execution='PENDING_CPU6_SLOT_GRANT',physical_current='PENDING_NEW03C_GENUINE_ACCEPTANCE')
pr=s/'READY.FRESH-SUFFIX-STATIC-COHORT.SOURCE-ONLY.json';js(pr,ready);print(json.dumps(dict(ready=ref(pr),**ready)))
