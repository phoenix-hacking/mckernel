#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define MCKERNEL_KREF_MARK (1U << 30)

struct ihk_atomic {
	int counter;
};

struct kref {
	struct ihk_atomic refcount;
};

struct memobj;
struct memobj_ops {
	void (*free)(struct memobj *);
};

struct memobj {
	struct memobj_ops *ops;
	uint32_t flags;
	uint32_t status;
	size_t size;
	struct ihk_atomic refcnt;
};

extern void kref_init(struct kref *);
extern unsigned int kref_read(const struct kref *);
extern unsigned int kref_is_mckernel(const struct kref *);
extern void kref_get(struct kref *);
extern int kref_put(struct kref *, void (*release)(struct kref *));
extern int memobj_ref(struct memobj *);
extern int memobj_unref(struct memobj *);

#ifdef USE_C_REFCOUNT_MODEL
static int atomic_inc_return(struct ihk_atomic *v)
{
	return __sync_add_and_fetch(&v->counter, 1);
}

static int atomic_dec_return(struct ihk_atomic *v)
{
	return __sync_sub_and_fetch(&v->counter, 1);
}

void kref_init(struct kref *kref)
{
	kref->refcount.counter = MCKERNEL_KREF_MARK + 1;
}

unsigned int kref_read(const struct kref *kref)
{
	return kref->refcount.counter & ~MCKERNEL_KREF_MARK;
}

unsigned int kref_is_mckernel(const struct kref *kref)
{
	return kref->refcount.counter & MCKERNEL_KREF_MARK;
}

void kref_get(struct kref *kref)
{
	atomic_inc_return(&kref->refcount);
}

int kref_put(struct kref *kref, void (*release)(struct kref *))
{
	if (atomic_dec_return(&kref->refcount) == (int)MCKERNEL_KREF_MARK) {
		release(kref);
		return 1;
	}
	return 0;
}

int memobj_ref(struct memobj *obj)
{
	return atomic_inc_return(&obj->refcnt);
}

int memobj_unref(struct memobj *obj)
{
	int cnt = atomic_dec_return(&obj->refcnt);

	if (cnt == 0)
		obj->ops->free(obj);
	return cnt;
}
#endif

static int kref_release_count;
static int memobj_free_count;

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void fake_kref_release(struct kref *kref)
{
	(void)kref;
	kref_release_count++;
}

static void fake_memobj_free(struct memobj *obj)
{
	(void)obj;
	memobj_free_count++;
}

int main(void)
{
	struct kref ref;
	struct memobj_ops ops = { .free = fake_memobj_free };
	struct memobj obj = { .ops = &ops, .flags = 3, .status = 7,
			      .size = 4096, .refcnt = { .counter = 1 } };
	unsigned long digest = 0x726566636f756e74UL;
	int ret;

	kref_release_count = 0;
	memobj_free_count = 0;

	kref_init(&ref);
	require(kref_read(&ref) == 1);
	require(kref_is_mckernel(&ref) == MCKERNEL_KREF_MARK);
	kref_get(&ref);
	require(kref_read(&ref) == 2);
	ret = kref_put(&ref, fake_kref_release);
	require(ret == 0);
	require(kref_release_count == 0);
	require(kref_read(&ref) == 1);
	ret = kref_put(&ref, fake_kref_release);
	require(ret == 1);
	require(kref_release_count != 0);
	require(kref_read(&ref) == 0);
	mix(&digest, ref.refcount.counter);
	mix(&digest, (unsigned long)kref_release_count);

	require(memobj_ref(&obj) == 2);
	require(obj.refcnt.counter == 2);
	require(memobj_unref(&obj) == 1);
	require(memobj_free_count == 0);
	require(memobj_unref(&obj) == 0);
	require(memobj_free_count != 0);
	mix(&digest, obj.refcnt.counter);
	mix(&digest, (unsigned long)memobj_free_count);

printf("refcount_helpers ok digest=%016lx kref=%d memobj=%d\n",
	       digest, kref_release_count != 0, memobj_free_count != 0);
	return 0;
}
