#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

struct rb_node {
	unsigned long __rb_parent_color;
	struct rb_node *rb_right;
	struct rb_node *rb_left;
} __attribute__((aligned(sizeof(long))));

struct rb_root {
	struct rb_node *rb_node;
};

struct rb_augment_callbacks {
	void (*propagate)(struct rb_node *node, struct rb_node *stop);
	void (*copy)(struct rb_node *old, struct rb_node *new);
	void (*rotate)(struct rb_node *old, struct rb_node *new);
};

#define rb_entry(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))

extern void rb_insert_color(struct rb_node *, struct rb_root *);
extern void rb_erase(struct rb_node *, struct rb_root *);
extern struct rb_node *__rb_parent(unsigned long);
extern unsigned long __rb_color(unsigned long);
extern int __rb_is_black(unsigned long);
extern int __rb_is_red(unsigned long);
extern unsigned long rb_color(const struct rb_node *);
extern int rb_is_red(const struct rb_node *);
extern int rb_is_black(const struct rb_node *);
extern struct rb_node *rb_next(const struct rb_node *);
extern struct rb_node *rb_next_safe(const struct rb_node *);
extern struct rb_node *rb_prev(const struct rb_node *);
extern struct rb_node *rb_first(const struct rb_root *);
extern struct rb_node *rb_first_safe(const struct rb_root *);
extern struct rb_node *rb_last(const struct rb_root *);
extern struct rb_node *rb_first_postorder(const struct rb_root *);
extern struct rb_node *rb_next_postorder(const struct rb_node *);
extern void rb_replace_node(struct rb_node *, struct rb_node *, struct rb_root *);
extern struct rb_node *rb_parent(const struct rb_node *);
extern int rb_empty_root(const struct rb_root *);
extern int rb_empty_node(const struct rb_node *);
extern void rb_clear_node(struct rb_node *);
extern void rb_link_node(struct rb_node *, struct rb_node *,
			 struct rb_node **);
extern void rb_set_parent(struct rb_node *, struct rb_node *);
extern void rb_set_parent_color(struct rb_node *, struct rb_node *, int);
extern void __rb_change_child(struct rb_node *, struct rb_node *,
			      struct rb_node *, struct rb_root *);
extern void __rb_insert_augmented(struct rb_node *, struct rb_root *,
				  void (*)(struct rb_node *, struct rb_node *));
extern void rb_insert_augmented(struct rb_node *, struct rb_root *,
				const struct rb_augment_callbacks *);
extern struct rb_node *__rb_erase_augmented(struct rb_node *,
					    struct rb_root *,
					    const struct rb_augment_callbacks *);
extern void rb_erase_augmented(struct rb_node *, struct rb_root *,
			       const struct rb_augment_callbacks *);
extern struct rb_node *rb_preorder_dfs_search(const struct rb_root *,
					      _Bool (*)(struct rb_node *, void *),
					      void *);

int ihk_mc_chk_page_address(unsigned long mem_addr) { (void)mem_addr; return 0; }
__attribute__((weak)) unsigned long virt_to_phys(void *v) { return (unsigned long)v; }
__attribute__((weak)) void *phys_to_virt(unsigned long p) { return (void *)p; }
__attribute__((weak)) int zero_at_free = 1;

struct item {
	int key;
	int value;
	struct rb_node rb;
};

struct aug_item {
	int key;
	unsigned long subtree_sum;
	struct rb_node rb;
};

static void insert_item(struct rb_root *root, struct item *item)
{
	struct rb_node **link = &root->rb_node;
	struct rb_node *parent = NULL;

	while (*link) {
		struct item *entry = rb_entry(*link, struct item, rb);
		parent = *link;
		if (item->key < entry->key)
			link = &(*link)->rb_left;
		else if (item->key > entry->key)
			link = &(*link)->rb_right;
		else
			exit(2);
	}

	rb_link_node(&item->rb, parent, link);
	if (rb_parent(&item->rb) != parent ||
			item->rb.rb_left || item->rb.rb_right || *link != &item->rb)
		exit(11);
	rb_insert_color(&item->rb, root);
}

static _Bool match_key(struct rb_node *node, void *arg)
{
	return rb_entry(node, struct item, rb)->key == *(int *)arg;
}

static void require_sorted(struct rb_root *root, const int *expected, int count)
{
	struct rb_node *node = rb_first(root);
	int i = 0;

	if (node != rb_first_safe(root))
		exit(3);

	for (; node; node = rb_next(node), i++) {
		if (i >= count || rb_entry(node, struct item, rb)->key != expected[i])
			exit(4);
		if (rb_next_safe(node) != rb_next(node))
			exit(5);
	}
	if (i != count)
		exit(6);

	node = rb_last(root);
	for (i = count - 1; i >= 0; i--, node = rb_prev(node)) {
		if (!node || rb_entry(node, struct item, rb)->key != expected[i])
			exit(7);
	}
	if (node)
		exit(8);
}

static int aug_propagate_count;
static int aug_copy_count;
static int aug_rotate_count;

static unsigned long aug_compute(struct aug_item *item)
{
	unsigned long sum = (unsigned long)item->key;

	if (item->rb.rb_left)
		sum += rb_entry(item->rb.rb_left, struct aug_item, rb)->subtree_sum;
	if (item->rb.rb_right)
		sum += rb_entry(item->rb.rb_right, struct aug_item, rb)->subtree_sum;
	return sum;
}

static void aug_propagate(struct rb_node *node, struct rb_node *stop)
{
	while (node != stop) {
		struct aug_item *item = rb_entry(node, struct aug_item, rb);

		item->subtree_sum = aug_compute(item);
		aug_propagate_count++;
		node = rb_parent(node);
	}
}

static void aug_copy(struct rb_node *old, struct rb_node *new)
{
	rb_entry(new, struct aug_item, rb)->subtree_sum =
		rb_entry(old, struct aug_item, rb)->subtree_sum;
	aug_copy_count++;
}

static void aug_rotate(struct rb_node *old, struct rb_node *new)
{
	struct aug_item *old_item = rb_entry(old, struct aug_item, rb);
	struct aug_item *new_item = rb_entry(new, struct aug_item, rb);

	new_item->subtree_sum = old_item->subtree_sum;
	old_item->subtree_sum = aug_compute(old_item);
	aug_rotate_count++;
}

static const struct rb_augment_callbacks aug_callbacks = {
	aug_propagate, aug_copy, aug_rotate
};

static void insert_aug_item(struct rb_root *root, struct aug_item *item)
{
	struct rb_node **link = &root->rb_node;
	struct rb_node *parent = NULL;

	while (*link) {
		struct aug_item *entry = rb_entry(*link, struct aug_item, rb);

		parent = *link;
		if (item->key < entry->key)
			link = &(*link)->rb_left;
		else if (item->key > entry->key)
			link = &(*link)->rb_right;
		else
			exit(20);
	}

	item->subtree_sum = (unsigned long)item->key;
	rb_link_node(&item->rb, parent, link);
	aug_propagate(parent, NULL);
	rb_insert_augmented(&item->rb, root, &aug_callbacks);
}

static void require_aug_sorted(struct rb_root *root, const int *expected,
			       int count)
{
	struct rb_node *node = rb_first(root);
	unsigned long total = 0;
	int i = 0;

	for (; i < count; i++)
		total += (unsigned long)expected[i];
	if (count && rb_entry(root->rb_node, struct aug_item, rb)->subtree_sum != total)
		exit(21);

	for (i = 0; node; node = rb_next(node), i++) {
		if (i >= count ||
				rb_entry(node, struct aug_item, rb)->key != expected[i])
			exit(22);
	}
	if (i != count)
		exit(23);
}

static void require_exported_helpers(void)
{
	struct rb_root root = { NULL };
	struct rb_node parent = { 0 };
	struct rb_node child = { 0 };
	struct rb_node replacement = { 0 };

	rb_set_parent_color(&child, &parent, 0);
	if (__rb_parent(child.__rb_parent_color) != &parent ||
			__rb_color(child.__rb_parent_color) != 0 ||
			!__rb_is_red(child.__rb_parent_color) ||
			rb_parent(&child) != &parent ||
			rb_color(&child) != 0 || !rb_is_red(&child) ||
			rb_is_black(&child))
		exit(16);

	rb_set_parent_color(&child, &parent, 1);
	if (__rb_parent(child.__rb_parent_color) != &parent ||
			__rb_color(child.__rb_parent_color) != 1 ||
			!__rb_is_black(child.__rb_parent_color) ||
			rb_color(&child) != 1 || !rb_is_black(&child) ||
			rb_is_red(&child))
		exit(17);

	rb_set_parent(&child, NULL);
	if (rb_parent(&child) != NULL || rb_color(&child) != 1)
		exit(18);

	root.rb_node = &parent;
	parent.rb_left = &child;
	__rb_change_child(&child, &replacement, &parent, &root);
	if (parent.rb_left != &replacement)
		exit(19);
	__rb_change_child(&parent, &child, NULL, &root);
	if (root.rb_node != &child)
		exit(24);
}

int main(void)
{
	struct rb_root root = { NULL };
	struct rb_root aug_root = { NULL };
	int keys[] = { 40, 10, 70, 20, 60, 80, 30, 50, 15, 65, 5, 75 };
	struct item items[sizeof(keys) / sizeof(keys[0])];
	struct aug_item aug_items[sizeof(keys) / sizeof(keys[0])];
	int sorted[] = { 5, 10, 15, 20, 30, 40, 50, 60, 65, 70, 75, 80 };
	int after_erase[] = { 5, 10, 15, 20, 30, 50, 60, 65, 70, 75, 80 };
	int target = 65;
	struct item replacement = { .key = 65, .value = 6500 };
	struct rb_node *found;
	int post_count = 0;

	require_exported_helpers();
	if (!rb_empty_root(&root))
		exit(14);

	for (size_t i = 0; i < sizeof(items) / sizeof(items[0]); i++) {
		items[i].key = keys[i];
		items[i].value = keys[i] * 10;
		rb_clear_node(&items[i].rb);
		aug_items[i].key = keys[i];
		aug_items[i].subtree_sum = 0;
		rb_clear_node(&aug_items[i].rb);
		if (!rb_empty_node(&items[i].rb))
			exit(12);
		insert_item(&root, &items[i]);
		insert_aug_item(&aug_root, &aug_items[i]);
		if (rb_empty_node(&items[i].rb))
			exit(13);
		if (rb_empty_root(&root))
			exit(15);
	}

	require_sorted(&root, sorted, 12);
	require_aug_sorted(&aug_root, sorted, 12);
	found = rb_preorder_dfs_search(&root, match_key, &target);
	if (!found)
		exit(9);
	rb_replace_node(found, &replacement.rb, &root);
	require_sorted(&root, sorted, 12);

	for (found = rb_first_postorder(&root); found; found = rb_next_postorder(found))
		post_count++;
	if (post_count != 12)
		exit(10);

	for (size_t i = 0; i < sizeof(items) / sizeof(items[0]); i++) {
		if (items[i].key == 40) {
			rb_erase(&items[i].rb, &root);
			break;
		}
	}
	require_sorted(&root, after_erase, 11);
	rb_erase_augmented(&aug_items[0].rb, &aug_root, &aug_callbacks);
	require_aug_sorted(&aug_root, after_erase, 11);
	if (!aug_propagate_count || !aug_copy_count)
		exit(25);
	printf("rbtree ok count=11 first=5 last=80 post=%d aug=%d/%d/%d\n",
	       post_count, aug_propagate_count, aug_copy_count,
	       aug_rotate_count);
	return 0;
}
