extern int printf(const char *, ...);
extern void abort(void);

#include <list.h>
#include <cls.h>

#define PAGEALLOC_TRACK_HASH_SIZE 256
#define PAGEALLOC_TRACK_HASH_MASK (PAGEALLOC_TRACK_HASH_SIZE - 1)
#define LOCAL_PAGE_SIZE 4096UL

struct pagealloc_track_entry;

struct pagealloc_track_addr_entry {
	void *addr;
	int runcount;
	struct list_head list;
	struct pagealloc_track_entry *entry;
	struct list_head hash;
	int npages;
};

struct pagealloc_track_entry {
	char *file;
	int line;
	ihk_atomic_t alloc_count;
	struct list_head hash;
	struct list_head addr_list;
	ihk_spinlock_t addr_list_lock;
};

static unsigned char page_payloads[8][LOCAL_PAGE_SIZE * 8]
	__attribute__((aligned(4096)));
static struct list_head page_track_heads[PAGEALLOC_TRACK_HASH_SIZE];
static struct list_head page_addr_heads[PAGEALLOC_TRACK_HASH_SIZE];
static ihk_spinlock_t page_track_locks[PAGEALLOC_TRACK_HASH_SIZE];
static ihk_spinlock_t page_addr_locks[PAGEALLOC_TRACK_HASH_SIZE];
static struct pagealloc_track_entry page_entries[4];
static struct pagealloc_track_addr_entry page_addr_entries[8];
static char page_file_storage[4][32];
static void *page_alloc_returns[16];
static int page_alloc_return_count;
static int page_alloc_index;
static int page_alloc_npages[16];
static int page_alloc_p2align[16];
static unsigned long page_alloc_flags[16];
static int page_alloc_nodes[16];
static int page_alloc_is_user[16];
static unsigned long page_alloc_virt[16];
static void *meta_alloc_returns[32];
static int meta_alloc_return_count;
static int meta_alloc_index;
static int meta_alloc_sizes[32];
static unsigned long meta_alloc_flags[32];
static void *meta_freed[32];
static int meta_free_count;
static void *page_freed[16];
static int page_free_npages[16];
static int page_free_is_user[16];
static int page_free_count;
static unsigned long page_lock_addrs[320];
static unsigned long page_unlock_addrs[320];
static unsigned long page_unlock_flags[320];
static int page_lock_count;
static int page_unlock_count;
static unsigned long page_noirq_lock_addrs[16];
static unsigned long page_noirq_unlock_addrs[16];
static int page_noirq_lock_count;
static int page_noirq_unlock_count;
static unsigned long page_spin_init_addr;
static int page_spin_init_count;
static int page_log_events[64];
static void *page_log_ptrs[64];
static int page_log_npages[64];
static int page_log_count;
static int page_leak_log_events[32];
static void *page_leak_log_ptrs[32];
static int page_leak_log_counts[32];
static int page_leak_log_runcounts[32];
static int page_leak_log_count;
static int invalid_free_count;
static void *invalid_free_ptr;
static char *invalid_free_file;
static int invalid_free_line;
static int invalid_size_count;
static void *invalid_size_ptr;
static int invalid_size_npages;
static int invalid_size_alloc_npages;
static char *invalid_size_file;
static int invalid_size_line;

extern struct pagealloc_track_entry *pagealloc_track_find_entry_result(
		char *, int, struct list_head *);
extern void *pagealloc_track_alloc_result(int, int, unsigned long, int, int,
		unsigned long, char *, int, char *, int, struct list_head *,
		ihk_spinlock_t *, struct list_head *, ihk_spinlock_t *, int,
		void *(*)(int, int, unsigned long, int, int, unsigned long),
		void *(*)(int, unsigned long), void (*)(void *),
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long),
		void (*)(int, void *, char *, int, int));
extern int pagealloc_track_free_result(void *, int, int, char *, int, char *,
		int, struct list_head *, ihk_spinlock_t *, struct list_head *,
		ihk_spinlock_t *, void (*)(void *, int, int),
		void *(*)(int, unsigned long), void (*)(void *),
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long), void (*)(unsigned long),
		void (*)(unsigned long), void (*)(void *, char *, int),
		void (*)(void *, int, int, char *, int),
		void (*)(int, void *, char *, int, int));
extern int mem_track_hashes_init_result(int *, struct list_head *,
		ihk_spinlock_t *, struct list_head *, ihk_spinlock_t *, int,
		void (*)(unsigned long));
extern int pagealloc_memcheck_result(struct list_head *, ihk_spinlock_t *,
		int *, int, unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long), void (*)(unsigned long),
		void (*)(unsigned long),
		void (*)(int, void *, char *, int, int, int, int));

static void require(int cond)
{
	if (!cond)
		abort();
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static struct pagealloc_track_entry *page_track_entry_from_hash(
		struct list_head *hash)
{
	return (struct pagealloc_track_entry *)((char *)hash -
		offsetof(struct pagealloc_track_entry, hash));
}

static struct pagealloc_track_addr_entry *page_track_addr_from_list(
		struct list_head *list)
{
	return (struct pagealloc_track_addr_entry *)((char *)list -
		offsetof(struct pagealloc_track_addr_entry, list));
}

static struct pagealloc_track_addr_entry *page_track_addr_from_hash(
		struct list_head *hash)
{
	return (struct pagealloc_track_addr_entry *)((char *)hash -
		offsetof(struct pagealloc_track_addr_entry, hash));
}

static int test_strlen(const char *s)
{
	int len = 0;

	while (s[len])
		len++;
	return len;
}

static int test_streq(const char *a, const char *b)
{
	while (*a || *b) {
		if (*a != *b)
			return 0;
		a++;
		b++;
	}
	return 1;
}

static int page_track_hash_for(const char *file, int line)
{
	return (test_strlen(file) + line) & PAGEALLOC_TRACK_HASH_MASK;
}

static int page_addr_hash_for(void *ptr)
{
	return ((unsigned long)ptr >> 5) & PAGEALLOC_TRACK_HASH_MASK;
}

static void init_page_track_heads(void)
{
	int i;

	for (i = 0; i < PAGEALLOC_TRACK_HASH_SIZE; i++) {
		INIT_LIST_HEAD(&page_track_heads[i]);
		INIT_LIST_HEAD(&page_addr_heads[i]);
		page_track_locks[i].head_tail = 0;
		page_addr_locks[i].head_tail = 0;
	}
}

static void reset_page_fake(void)
{
	int i;

	page_alloc_return_count = 0;
	page_alloc_index = 0;
	meta_alloc_return_count = 0;
	meta_alloc_index = 0;
	for (i = 0; i < 16; i++) {
		page_alloc_returns[i] = NULL;
		page_alloc_npages[i] = 0;
		page_alloc_p2align[i] = 0;
		page_alloc_flags[i] = 0;
		page_alloc_nodes[i] = 0;
		page_alloc_is_user[i] = 0;
		page_alloc_virt[i] = 0;
		page_freed[i] = NULL;
		page_free_npages[i] = 0;
		page_free_is_user[i] = 0;
	}
	for (i = 0; i < 32; i++) {
		meta_alloc_returns[i] = NULL;
		meta_alloc_sizes[i] = 0;
		meta_alloc_flags[i] = 0;
		meta_freed[i] = NULL;
	}
	meta_free_count = 0;
	page_free_count = 0;
	for (i = 0; i < 320; i++) {
		page_lock_addrs[i] = 0;
		page_unlock_addrs[i] = 0;
		page_unlock_flags[i] = 0;
	}
	for (i = 0; i < 64; i++) {
		page_log_events[i] = 0;
		page_log_ptrs[i] = NULL;
		page_log_npages[i] = 0;
	}
	for (i = 0; i < 32; i++) {
		page_leak_log_events[i] = 0;
		page_leak_log_ptrs[i] = NULL;
		page_leak_log_counts[i] = 0;
		page_leak_log_runcounts[i] = 0;
	}
	page_lock_count = 0;
	page_unlock_count = 0;
	for (i = 0; i < 16; i++) {
		page_noirq_lock_addrs[i] = 0;
		page_noirq_unlock_addrs[i] = 0;
	}
	page_noirq_lock_count = 0;
	page_noirq_unlock_count = 0;
	page_spin_init_addr = 0;
	page_spin_init_count = 0;
	page_log_count = 0;
	page_leak_log_count = 0;
	invalid_free_count = 0;
	invalid_free_ptr = NULL;
	invalid_free_file = NULL;
	invalid_free_line = 0;
	invalid_size_count = 0;
	invalid_size_ptr = NULL;
	invalid_size_npages = 0;
	invalid_size_alloc_npages = 0;
	invalid_size_file = NULL;
	invalid_size_line = 0;
}

static void push_page_alloc(void *ptr)
{
	page_alloc_returns[page_alloc_return_count++] = ptr;
}

static void push_meta_alloc(void *ptr)
{
	meta_alloc_returns[meta_alloc_return_count++] = ptr;
}

static void *fake_page_alloc(int npages, int p2align, unsigned long flag,
		int node, int is_user, unsigned long virt_addr)
{
	int index = page_alloc_index++;

	page_alloc_npages[index] = npages;
	page_alloc_p2align[index] = p2align;
	page_alloc_flags[index] = flag;
	page_alloc_nodes[index] = node;
	page_alloc_is_user[index] = is_user;
	page_alloc_virt[index] = virt_addr;
	if (index >= page_alloc_return_count)
		return NULL;
	return page_alloc_returns[index];
}

static void fake_page_free(void *ptr, int npages, int is_user)
{
	page_freed[page_free_count] = ptr;
	page_free_npages[page_free_count] = npages;
	page_free_is_user[page_free_count] = is_user;
	page_free_count++;
}

static void *fake_meta_alloc(int size, unsigned long flag)
{
	int index = meta_alloc_index++;

	meta_alloc_sizes[index] = size;
	meta_alloc_flags[index] = flag;
	if (index >= meta_alloc_return_count)
		return NULL;
	return meta_alloc_returns[index];
}

static void fake_meta_free(void *ptr)
{
	meta_freed[meta_free_count++] = ptr;
}

static unsigned long fake_page_lock(unsigned long lock_addr)
{
	page_lock_addrs[page_lock_count] = lock_addr;
	return 0x8000UL + (unsigned long)page_lock_count++;
}

static void fake_page_unlock(unsigned long lock_addr, unsigned long flags)
{
	page_unlock_addrs[page_unlock_count] = lock_addr;
	page_unlock_flags[page_unlock_count] = flags;
	page_unlock_count++;
}

static void fake_page_noirq_lock(unsigned long lock_addr)
{
	page_noirq_lock_addrs[page_noirq_lock_count++] = lock_addr;
}

static void fake_page_noirq_unlock(unsigned long lock_addr)
{
	page_noirq_unlock_addrs[page_noirq_unlock_count++] = lock_addr;
}

static void fake_page_spin_init(unsigned long lock_addr)
{
	page_spin_init_addr = lock_addr;
	page_spin_init_count++;
}

static void fake_page_log(int event, void *ptr, char *file, int line,
		int npages)
{
	(void)file;
	(void)line;
	page_log_events[page_log_count] = event;
	page_log_ptrs[page_log_count] = ptr;
	page_log_npages[page_log_count] = npages;
	page_log_count++;
}

static void fake_invalid_free(void *ptr, char *file, int line)
{
	invalid_free_count++;
	invalid_free_ptr = ptr;
	invalid_free_file = file;
	invalid_free_line = line;
}

static void fake_invalid_size(void *ptr, int npages, int alloc_npages,
		char *file, int line)
{
	invalid_size_count++;
	invalid_size_ptr = ptr;
	invalid_size_npages = npages;
	invalid_size_alloc_npages = alloc_npages;
	invalid_size_file = file;
	invalid_size_line = line;
}

static void fake_page_leak_log(int event, void *ptr, char *file, int line,
		int size, int count, int runcount)
{
	(void)file;
	(void)line;
	(void)size;
	page_leak_log_events[page_leak_log_count] = event;
	page_leak_log_ptrs[page_leak_log_count] = ptr;
	page_leak_log_counts[page_leak_log_count] = count;
	page_leak_log_runcounts[page_leak_log_count] = runcount;
	page_leak_log_count++;
}

int main(void)
{
	unsigned long digest = 0x70616765UL;
	void *result;
	int hash;
	int addr_hash;
	int initialized;
	int page_runcount;

	init_page_track_heads();
	reset_page_fake();
	push_page_alloc(page_payloads[0]);
	push_meta_alloc(&page_entries[0]);
	push_meta_alloc(page_file_storage[0]);
	push_meta_alloc(&page_addr_entries[0]);
	result = pagealloc_track_alloc_result(4, 2, 0x55, 3, 1, 0xabc,
			"page.c", 31, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 21,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[0]);
	hash = page_track_hash_for("page.c", 31);
	addr_hash = page_addr_hash_for(page_payloads[0]);
	require(page_alloc_index == 1);
	require(page_alloc_npages[0] == 4 && page_alloc_p2align[0] == 2);
	require(page_alloc_flags[0] == 0x55 && page_alloc_nodes[0] == 3);
	require(page_alloc_is_user[0] == 1 && page_alloc_virt[0] == 0xabc);
	require(meta_alloc_index == 3);
	require(meta_alloc_sizes[0] == (int)sizeof(struct pagealloc_track_entry));
	require(meta_alloc_sizes[1] == test_strlen("page.c") + 1);
	require(meta_alloc_sizes[2] == (int)sizeof(struct pagealloc_track_addr_entry));
	require(meta_alloc_flags[0] == 0x2 && meta_alloc_flags[2] == 0x2);
	require(page_lock_count == 3 && page_unlock_count == 3);
	require(page_lock_addrs[0] == (unsigned long)&page_track_locks[hash]);
	require(page_lock_addrs[1] ==
			(unsigned long)&page_entries[0].addr_list_lock);
	require(page_lock_addrs[2] == (unsigned long)&page_addr_locks[addr_hash]);
	require(page_spin_init_count == 1);
	require(page_spin_init_addr == (unsigned long)&page_entries[0].addr_list_lock);
	require(page_entries[0].line == 31);
	require(page_entries[0].alloc_count.counter == 1);
	require(test_streq(page_entries[0].file, "page.c"));
	require(page_track_entry_from_hash(page_track_heads[hash].next) ==
			&page_entries[0]);
	require(page_track_addr_from_list(page_entries[0].addr_list.next) ==
			&page_addr_entries[0]);
	require(page_track_addr_from_hash(page_addr_heads[addr_hash].next) ==
			&page_addr_entries[0]);
	require(page_addr_entries[0].addr == page_payloads[0]);
	require(page_addr_entries[0].runcount == 21);
	require(page_addr_entries[0].entry == &page_entries[0]);
	require(page_addr_entries[0].npages == 4);
	require(page_log_count == 2);
	require(page_log_events[0] == 3 && page_log_events[1] == 5);
	require(pagealloc_track_find_entry_result("page.c", 31,
			page_track_heads) == &page_entries[0]);
	mix(&digest, (unsigned long)page_entries[0].alloc_count.counter);
	mix(&digest, (unsigned long)page_addr_entries[0].npages);

	reset_page_fake();
	push_page_alloc(page_payloads[1]);
	push_meta_alloc(&page_addr_entries[1]);
	result = pagealloc_track_alloc_result(2, 0, 0x56, -1, 0, 0xffff,
			"page.c", 31, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 22,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[1]);
	require(meta_alloc_index == 1);
	require(page_entries[0].alloc_count.counter == 2);
	require(page_addr_entries[1].entry == &page_entries[0]);
	require(page_addr_entries[1].npages == 2);
	require(page_log_count == 1 && page_log_events[0] == 5);
	mix(&digest, (unsigned long)page_entries[0].alloc_count.counter);

	reset_page_fake();
	push_page_alloc(page_payloads[2]);
	result = pagealloc_track_alloc_result(3, 0, 0x57, 0, 0, 0,
			"nodebug.c", 9, NULL, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 23,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[2]);
	require(page_alloc_index == 1 && meta_alloc_index == 0);
	require(page_lock_count == 0 && page_log_count == 0);

	reset_page_fake();
	push_page_alloc(page_payloads[3]);
	result = pagealloc_track_alloc_result(3, 0, 0x58, 0, 0, 0,
			"uninit.c", 10, (char *)1, 0, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 24,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[3]);
	require(meta_alloc_index == 0 && page_lock_count == 0);

	reset_page_fake();
	result = pagealloc_track_alloc_result(1, 0, 0x59, 0, 0, 0,
			"fail.c", 11, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 25,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == NULL);
	require(page_alloc_index == 1 && page_lock_count == 0);

	reset_page_fake();
	push_page_alloc(page_payloads[4]);
	push_meta_alloc(NULL);
	result = pagealloc_track_alloc_result(1, 0, 0x5a, 0, 0, 0,
			"entryfail.c", 12, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 26,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[4]);
	require(page_lock_count == 1 && page_unlock_count == 1);
	require(page_log_count == 1 && page_log_events[0] == 1);

	reset_page_fake();
	push_page_alloc(page_payloads[5]);
	push_meta_alloc(&page_entries[2]);
	push_meta_alloc(NULL);
	result = pagealloc_track_alloc_result(1, 0, 0x5b, 0, 0, 0,
			"filefail.c", 13, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 27,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[5]);
	require(meta_free_count == 1 && meta_freed[0] == &page_entries[2]);
	require(page_log_count == 1 && page_log_events[0] == 2);

	reset_page_fake();
	push_page_alloc(page_payloads[6]);
	push_meta_alloc(NULL);
	result = pagealloc_track_alloc_result(1, 0, 0x5c, 0, 0, 0,
			"page.c", 31, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 28,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[6]);
	require(page_entries[0].alloc_count.counter == 3);
	require(page_log_count == 1 && page_log_events[0] == 4);

	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[0], 1, 1,
			"page.c", 101, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == 0);
	require(page_addr_entries[0].addr == page_payloads[0] + LOCAL_PAGE_SIZE);
	require(page_addr_entries[0].npages == 3);
	require(page_free_count == 1 && page_freed[0] == page_payloads[0]);
	require(page_free_npages[0] == 1 && page_free_is_user[0] == 1);
	addr_hash = page_addr_hash_for(page_addr_entries[0].addr);
	require(page_track_addr_from_hash(page_addr_heads[addr_hash].next) ==
			&page_addr_entries[0]);
	mix(&digest, (unsigned long)page_addr_entries[0].npages);

	reset_page_fake();
	push_meta_alloc(&page_addr_entries[2]);
	require(pagealloc_track_free_result(page_payloads[0] + 2 * LOCAL_PAGE_SIZE,
			1, 1, "page.c", 102, (char *)1, 1,
			page_track_heads, page_track_locks, page_addr_heads,
			page_addr_locks, fake_page_free, fake_meta_alloc,
			fake_meta_free, fake_page_lock, fake_page_unlock,
			fake_page_noirq_lock, fake_page_noirq_unlock,
			fake_invalid_free, fake_invalid_size, fake_page_log) == 0);
	require(page_addr_entries[0].addr == page_payloads[0] + LOCAL_PAGE_SIZE);
	require(page_addr_entries[0].npages == 1);
	require(page_addr_entries[2].addr == page_payloads[0] + 3 * LOCAL_PAGE_SIZE);
	require(page_addr_entries[2].npages == 1);
	require(page_addr_entries[2].entry == &page_entries[0]);
	require(page_entries[0].alloc_count.counter == 4);
	require(page_noirq_lock_count == 1 && page_noirq_unlock_count == 1);
	require(page_log_count == 3);
	require(page_log_events[0] == 8 && page_log_events[1] == 9);
	require(page_log_events[2] == 10);
	mix(&digest, (unsigned long)page_entries[0].alloc_count.counter);

	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[1], 2, 0,
			"page.c", 103, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == 0);
	require(meta_free_count == 1 && meta_freed[0] == &page_addr_entries[1]);
	require(page_entries[0].alloc_count.counter == 3);
	require(page_free_count == 1 && page_freed[0] == page_payloads[1]);
	require(page_log_count == 1 && page_log_events[0] == 6);
	mix(&digest, (unsigned long)page_entries[0].alloc_count.counter);

	init_page_track_heads();
	reset_page_fake();
	push_page_alloc(page_payloads[3]);
	push_meta_alloc(&page_entries[3]);
	push_meta_alloc(page_file_storage[3]);
	push_meta_alloc(&page_addr_entries[3]);
	result = pagealloc_track_alloc_result(2, 0, 0x60, 0, 0, 0,
			"last.c", 44, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 31,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[3]);
	hash = page_track_hash_for("last.c", 44);
	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[3], 2, 0,
			"last.c", 104, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == 0);
	require(meta_free_count == 3);
	require(meta_freed[0] == &page_addr_entries[3]);
	require(meta_freed[1] == page_file_storage[3]);
	require(meta_freed[2] == &page_entries[3]);
	require(page_freed[0] == page_payloads[3]);
	require(page_track_heads[hash].next == &page_track_heads[hash]);
	require(page_log_count == 2);
	require(page_log_events[0] == 6 && page_log_events[1] == 7);

	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[7], 1, 0,
			"bad.c", 105, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == -22);
	require(invalid_free_count == 1 && invalid_free_ptr == page_payloads[7]);
	require(test_streq(invalid_free_file, "bad.c"));
	require(invalid_free_line == 105);
	require(page_free_count == 0);

	init_page_track_heads();
	reset_page_fake();
	push_page_alloc(page_payloads[4]);
	push_meta_alloc(&page_entries[1]);
	push_meta_alloc(page_file_storage[1]);
	push_meta_alloc(&page_addr_entries[4]);
	result = pagealloc_track_alloc_result(1, 0, 0x61, 0, 0, 0,
			"small.c", 45, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks, 32,
			fake_page_alloc, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_spin_init,
			fake_page_log);
	require(result == page_payloads[4]);
	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[4], 2, 0,
			"small.c", 106, (char *)1, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == -22);
	require(invalid_size_count == 1);
	require(invalid_size_ptr == page_payloads[4]);
	require(invalid_size_npages == 2);
	require(invalid_size_alloc_npages == 1);
	require(test_streq(invalid_size_file, "small.c"));
	require(page_free_count == 0);

	reset_page_fake();
	require(pagealloc_track_free_result(page_payloads[6], 5, 1,
			"nodebug.c", 107, NULL, 1, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			fake_page_free, fake_meta_alloc, fake_meta_free,
			fake_page_lock, fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_invalid_free,
			fake_invalid_size, fake_page_log) == 0);
	require(page_free_count == 1 && page_freed[0] == page_payloads[6]);
	require(page_free_npages[0] == 5 && page_free_is_user[0] == 1);
	require(page_lock_count == 0 && invalid_free_count == 0);
	mix(&digest, (unsigned long)page_free_npages[0]);

	initialized = 0;
	reset_page_fake();
	require(mem_track_hashes_init_result(&initialized, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			PAGEALLOC_TRACK_HASH_SIZE, fake_page_spin_init) == 1);
	require(initialized == 1);
	require(page_spin_init_count == PAGEALLOC_TRACK_HASH_SIZE * 2);
	require(page_track_heads[17].next == &page_track_heads[17]);
	require(page_addr_heads[31].prev == &page_addr_heads[31]);
	require(mem_track_hashes_init_result(&initialized, page_track_heads,
			page_track_locks, page_addr_heads, page_addr_locks,
			PAGEALLOC_TRACK_HASH_SIZE, fake_page_spin_init) == 0);
	require(page_spin_init_count == PAGEALLOC_TRACK_HASH_SIZE * 2);
	mix(&digest, (unsigned long)page_spin_init_count);

	init_page_track_heads();
	reset_page_fake();
	page_runcount = 12;
	hash = page_track_hash_for("pleak.c", 90);
	page_entries[0].file = "pleak.c";
	page_entries[0].line = 90;
	page_entries[0].alloc_count.counter = 2;
	INIT_LIST_HEAD(&page_entries[0].hash);
	INIT_LIST_HEAD(&page_entries[0].addr_list);
	list_add(&page_entries[0].hash, &page_track_heads[hash]);
	page_addr_entries[0].addr = page_payloads[0];
	page_addr_entries[0].runcount = 12;
	page_addr_entries[1].addr = page_payloads[1];
	page_addr_entries[1].runcount = 11;
	INIT_LIST_HEAD(&page_addr_entries[0].list);
	INIT_LIST_HEAD(&page_addr_entries[1].list);
	list_add(&page_addr_entries[0].list, &page_entries[0].addr_list);
	list_add(&page_addr_entries[1].list, &page_entries[0].addr_list);
	require(pagealloc_memcheck_result(page_track_heads, page_track_locks,
			&page_runcount, PAGEALLOC_TRACK_HASH_SIZE, fake_page_lock,
			fake_page_unlock, fake_page_noirq_lock,
			fake_page_noirq_unlock, fake_page_leak_log) == 1);
	require(page_runcount == 13);
	require(page_lock_count == PAGEALLOC_TRACK_HASH_SIZE);
	require(page_unlock_count == PAGEALLOC_TRACK_HASH_SIZE);
	require(page_noirq_lock_count == 1 && page_noirq_unlock_count == 1);
	require(page_leak_log_count == 3);
	require(page_leak_log_events[0] == 1 && page_leak_log_events[1] == 1);
	require(page_leak_log_events[2] == 2);
	require(page_leak_log_counts[2] == 1);
	require(page_leak_log_runcounts[2] == 12);
	mix(&digest, (unsigned long)page_runcount);
	mix(&digest, (unsigned long)page_leak_log_count);

	printf("pagealloc_track ok digest=%016lx\n", digest);
	return 0;
}
