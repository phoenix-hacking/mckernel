#include <stdio.h>
#include <stdlib.h>

struct llist_node { struct llist_node *next; };
struct llist_head { struct llist_node *first; };

extern void init_llist_head(struct llist_head *);
extern _Bool llist_empty(const struct llist_head *);
extern struct llist_node *llist_next(struct llist_node *);
extern _Bool llist_add_batch(struct llist_node *, struct llist_node *,
			     struct llist_head *);
extern _Bool llist_add(struct llist_node *, struct llist_head *);
extern struct llist_node *llist_del_all(struct llist_head *);
extern struct llist_node *llist_del_first(struct llist_head *);
extern struct llist_node *llist_reverse_order(struct llist_node *);

struct item {
	int value;
	struct llist_node node;
};

#define entry(ptr) ((struct item *)((char *)(ptr) - __builtin_offsetof(struct item, node)))

static void require(int cond)
{
	if (!cond)
		exit(2);
}

int main(void)
{
	struct llist_head head = { (struct llist_node *)0x1 };
	struct item items[6];
	struct llist_node *node;
	struct llist_node *rev;
	int sum = 0;

	init_llist_head(&head);
	require(llist_empty(&head));
	for (int i = 0; i < 6; i++) {
		items[i].value = i + 1;
		items[i].node.next = NULL;
	}

	items[0].node.next = &items[1].node;
	items[1].node.next = &items[2].node;
	require(llist_add_batch(&items[0].node, &items[2].node, &head) == 1);
	items[3].node.next = &items[4].node;
	require(llist_add_batch(&items[3].node, &items[4].node, &head) == 0);
	node = llist_del_first(&head);
	require(node == &items[3].node && head.first == &items[4].node);
	require(llist_next(node) == &items[4].node);
	node = llist_del_first(&head);
	require(node == &items[4].node);
	require(!llist_empty(&head));
	node = llist_del_all(&head);
	require(node == &items[0].node && llist_empty(&head));
	require(llist_add(&items[5].node, &head) == 1);
	require(llist_add_batch(node, &items[2].node, &head) == 0);
	rev = llist_reverse_order(llist_del_all(&head));
	for (node = rev; node; node = node->next)
		sum = sum * 10 + entry(node)->value;
	printf("llist ok sum=%d first=%d\n", sum, entry(rev)->value);
	return 0;
}
