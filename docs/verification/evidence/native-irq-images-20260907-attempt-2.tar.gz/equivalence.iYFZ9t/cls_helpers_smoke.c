extern int printf(const char *, ...);
extern int fflush(void *);
extern void abort(void);
extern void exit(int);

#define PROFILE_ENABLE 1
#define ENABLE_RUSAGE 1
#include <cls.h>
#include <page.h>
#include <rusage.h>
#include <ihk/ihk_monitor.h>

extern struct cpu_local_var *clv;
extern int cpu_local_var_initialized;
struct rusage_global rusage;

static struct ihk_os_cpu_monitor monitor_cpu[4];
static unsigned char cls_arena[4 * 8192] __attribute__((aligned(64)));
static int current_cpu;
static int alloc_pages_seen;
static int alloc_flags_seen;

extern void cpu_local_var_init_result(int, struct ihk_os_cpu_monitor *,
		struct rusage_percpu *, void *(*)(int, int));
extern struct cpu_local_var *get_cpu_local_var_result(int);
extern struct cpu_local_var *get_this_cpu_local_var(void);
extern void preempt_enable_result(void);
extern void preempt_disable_result(void);

int ihk_mc_get_processor_id_equiv(void)
{
	return current_cpu;
}

__attribute__((weak)) int ihk_mc_get_processor_id(void)
{
	return current_cpu;
}

static void *fake_alloc_pages(int nr_pages, int flags)
{
	alloc_pages_seen = nr_pages;
	alloc_flags_seen = flags;
	if ((unsigned long)nr_pages * PAGE_SIZE > sizeof(cls_arena))
		abort();
	return cls_arena;
}

static void require_line(int cond, int line)
{
	if (!cond) {
		printf("cls require failed line=%d\n", line);
		exit(1);
	}
}

#define require(cond) require_line((cond), __LINE__)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	unsigned long digest = 0x1badc0deUL;
	int expected_pages;

	cpu_local_var_init_result(2, monitor_cpu, rusage.cpu, fake_alloc_pages);
	expected_pages = (sizeof(struct cpu_local_var) * 2 + PAGE_SIZE - 1) >> PAGE_SHIFT;

	require(clv == (struct cpu_local_var *)cls_arena);
	require(cpu_local_var_initialized == 1);
	require(alloc_pages_seen == expected_pages);
	require(alloc_flags_seen == 1);
	require(clv[0].monitor == &monitor_cpu[0]);
	require(clv[1].monitor == &monitor_cpu[1]);
	require(clv[0].rusage == &rusage.cpu[0]);
	require(clv[1].rusage == &rusage.cpu[1]);
	require(clv[0].smp_func_req_list.next == &clv[0].smp_func_req_list);
	require(clv[0].smp_func_req_list.prev == &clv[0].smp_func_req_list);
	require(clv[1].backlog_list.next == &clv[1].backlog_list);
	require(clv[1].backlog_list.prev == &clv[1].backlog_list);
	require(get_cpu_local_var_result(1) == &clv[1]);

	current_cpu = 1;
	require(get_this_cpu_local_var() == &clv[1]);
	clv[1].no_preempt.counter = 3;
	preempt_disable_result();
	require(clv[1].no_preempt.counter == 4);
	preempt_enable_result();
	require(clv[1].no_preempt.counter == 3);

	mix(&digest, sizeof(struct cpu_local_var));
	mix(&digest, (unsigned long)alloc_pages_seen);
	mix(&digest, (unsigned long)alloc_flags_seen);
	mix(&digest, (unsigned long)(clv[1].monitor - monitor_cpu));
	mix(&digest, (unsigned long)(clv[1].rusage - rusage.cpu));
	mix(&digest, (unsigned long)clv[1].no_preempt.counter);

printf("cls_helpers ok digest=%016lx\n", digest);
return 0;
}
