extern int printf(const char *, ...);
extern int fflush(void *);
extern void abort(void);

#define TOF_RSC_TNI0_TOQ0 0
#define TOF_RSC_TNI0_TCQ0 72
#define TOF_RSC_TNI0_MRQ0 144
#define TOF_RSC_TNI0_PBQ 216
#define TOF_RSC_TNI0_PRQ 222
#define TOF_RSC_TNI0_STEERINGTABLE0 228
#define TOF_RSC_TNI0_MBTABLE0 297
#define TOF_ICC_RH_LEN 8
#define TOF_ICC_ECRC_LEN 4
#define TOF_ICC_FRAME_ALIGN 32
#define TOF_ICC_FRAME_LEN_MIN 104
#define TOF_ICC_TOQ_DESC_SIZE 32
#define TOF_ICC_TCQ_DESC_SIZE 8
#define TOF_ICC_MRQ_DESC_SIZE 32
#define TOF_ICC_PBQ_DESC_SIZE 8
#define TOF_ICC_PRQ_DESC_SIZE 8
#define tof_icc_reg_pa 0x40000000UL
#define TOF_UTOFU_MRU_EMPTY (-1)
#define PAGE_SHIFT 12
	#define TOF_STAG_TRANS_PS_CODE_64KB 0
	#define TOF_STAG_TRANS_PS_CODE_2MB 1
	#define TOF_ICC_NTNIS 6
	#define TOF_ICC_NCQS 12
	#define TOF_ICC_NBGS 48
	#define TOF_ICC_BCH_DMA_ALIGN 256UL
	#define TOF_ICC_BG_BSEQ_SIZE (1UL << 24)
	#define EFAULT 14
	#define EINVAL 22
	#define ENOENT 2
	#define EPERM 1
	#define EBUSY 16
	#define ENOSPC 28
	#define ENOTTY 25
	#define ETIMEDOUT 110
	#define ENOTSUPP 524
	#define TOF_UTOFU_SPECIAL_STAG 4096
	#define TOF_UTOFU_ALLOC_STAG_LPG 0x2U
	#define TOF_UTOFU_BLANK_MBVA (~0UL)
	#define TOF_IOCTL_ALLOC_STAG 0x1001U
	#define TOF_IOCTL_FREE_STAGS 0x1002U
	#define TOF_IOCTL_ENABLE_BCH 0x1003U
	#define TOF_IOCTL_DISABLE_BCH 0x1004U
	#define PROFILE_tofu_stag_alloc 501
	#define PROFILE_tofu_stag_free_stags 502
	#define TOFU_FREE_STAG_PROFILE_PRE 1
	#define TOFU_FREE_STAG_PROFILE_CQFLUSH 2
	#define TOFU_FREE_STAG_PROFILE_DEALLOC 3
	#define TOFU_FREE_STAG_PROFILE_TOTAL 4

struct tof_utofu_trans_list {
	short prev;
	short next;
	unsigned char pgszbits;
	void *mbpt;
};

struct tof_trans_table {
	unsigned long steering;
	unsigned long mbpt;
};

struct tof_icc_steering_entry_words {
	unsigned long word;
	unsigned long length;
};

struct tof_icc_mb_entry_words {
	unsigned long word;
	unsigned long npage;
};

	struct tof_icc_mbpt_entry_words {
		unsigned long word;
	};

	struct tofu_addr {
		unsigned char pa;
		unsigned char pb;
		unsigned char pc;
		unsigned char x;
		unsigned char y;
		unsigned char z;
		unsigned char a;
		unsigned char b;
		unsigned char c;
	};

	struct tof_set_bg {
		int tni;
		int gate;
		int source_lgate;
		struct tofu_addr source_raddr;
		int source_rtni;
		int source_rgate;
		int dest_lgate;
		struct tofu_addr dest_raddr;
		int dest_rtni;
		int dest_rgate;
	};

	struct tof_enable_bch {
		void *addr;
		int bseq;
		int num;
		struct tof_set_bg *bgs;
	};

	struct tof_alloc_stag {
		unsigned int flags;
		int stag;
		unsigned long offset;
		void *va;
		unsigned long len;
	};

	struct tof_free_stags {
		unsigned short num;
		int *stags;
	};

	#define TOF_TRANS_START_MASK ((1UL << 36) - 1)
	#define TOF_TRANS_LEN_MASK ((1UL << 27) - 1)
	#define TOF_ICC_STEERING_READONLY_SHIFT 6
	#define TOF_ICC_STEERING_ENABLE_SHIFT 7
#define TOF_ICC_STEERING_MBVA_SHIFT 8
#define TOF_ICC_STEERING_MBVA_MASK ((1UL << 32) - 1)
#define TOF_ICC_STEERING_MBID_SHIFT 48
#define TOF_ICC_STEERING_MBID_MASK ((1UL << 16) - 1)
#define TOF_ICC_STEERING_MUT_MASK \
	((1UL << TOF_ICC_STEERING_READONLY_SHIFT) | \
	 (1UL << TOF_ICC_STEERING_ENABLE_SHIFT) | \
	 (TOF_ICC_STEERING_MBVA_MASK << TOF_ICC_STEERING_MBVA_SHIFT) | \
	 (TOF_ICC_STEERING_MBID_MASK << TOF_ICC_STEERING_MBID_SHIFT))
#define TOF_ICC_MB_PS_MASK ((1UL << 3) - 1)
#define TOF_ICC_MB_ENABLE_SHIFT 7
#define TOF_ICC_MB_IPA_SHIFT 8
#define TOF_ICC_MB_IPA_MASK ((1UL << 32) - 1)
#define TOF_ICC_MB_MUT_MASK \
	(TOF_ICC_MB_PS_MASK | (1UL << TOF_ICC_MB_ENABLE_SHIFT) | \
	 (TOF_ICC_MB_IPA_MASK << TOF_ICC_MB_IPA_SHIFT))
#define TOF_ICC_MBPT_ENABLE_SHIFT 7
#define TOF_ICC_MBPT_IPA_SHIFT 12
#define TOF_ICC_MBPT_IPA_MASK ((1UL << 28) - 1)
	#define TOF_ICC_MBPT_MUT_MASK \
		((1UL << TOF_ICC_MBPT_ENABLE_SHIFT) | \
		 (TOF_ICC_MBPT_IPA_MASK << TOF_ICC_MBPT_IPA_SHIFT))
	#define TOF_ICC_REG_BGS_SIGNAL_MASK_SIG_RECV (1UL << 63)
	#define TOF_ICC_REG_BGS_SIGNAL_MASK_TLP_RECV (1UL << 62)
	#define TOF_ICC_REG_BGS_SIGNAL_MASK_SIG_SEND (1UL << 61)
	#define TOF_ICC_REG_BGS_SIGNAL_MASK_TLP_SEND (1UL << 60)
	#define TOF_ICC_REG_BGS_LOCAL_LINK_BGID_RECV 0x0000003f00000000UL
		#define TOF_ICC_REG_BGS_LOCAL_LINK_BGID_SEND 0x000000000000003fUL
	#define TOF_ICC_REG_BGS_REMOTE_LINK_BG_ADDRESS_RECV 0x0fffffff00000000UL
		#define TOF_ICC_REG_BGS_REMOTE_LINK_BG_ADDRESS_SEND 0x00000000ffffffffUL
		#define TOF_ICC_REG_BGS_ENABLE 0
		#define TOF_ICC_REG_BGS_STATE 0x30
		#define TOF_ICC_REG_BGS_STATE_ENABLE 1
		#define TOF_ICC_REG_BGS_SIGNAL_MASK 0x58
		#define TOF_ICC_REG_BGS_LOCAL_LINK 0x60
		#define TOF_ICC_REG_BGS_REMOTE_LINK 0x68
		#define TOF_ICC_REG_BGS_SUBNET_SIZE 0x70
		#define TOF_ICC_REG_BGS_GPID_BSEQ 0x78
		#define TOF_ICC_REG_BGS_BCH_MASK 0x800
		#define TOF_ICC_REG_BGS_BCH_MASK_STATUS 0x808
	#define TOF_ICC_REG_BGS_BCH_MASK_STATUS_RUN (1UL << 63)
	#define TOF_ICC_REG_BGS_BCH_NOTICE_IPA 0x810
	#define TOF_ICC_REG_BGS_BCH_MASK_MASK (1UL << 63)

	struct tofu_globals {
		unsigned long tof_ib_stag_lock_addr;
		unsigned long tof_ib_stag_list_addr;
		unsigned long tof_ib_stag_list_Rp_addr;
		unsigned long tof_ib_stag_list_Wp_addr;
		unsigned long tof_ib_mbpt_mem_addr;
		unsigned long tof_ib_steering_addr;
		unsigned long tof_ib_mb_addr;
		unsigned long tof_core_cq_addr;
		unsigned long tof_core_bg_addr;
		unsigned long tof_utofu_bg_addr;
		unsigned long tof_utofu_handler_bg_signal_addr;
		unsigned long linux_vmalloc_start;
		unsigned long linux_vmalloc_end;
	};

	#ifdef USE_C_TOFU_UAPI_MODEL
	static unsigned long c_round_up(unsigned long x, unsigned long y)
	{
	return ((x - 1) | (y - 1)) + 1;
}

int TOF_RSC_TOQ(int tni, int cqid)
{
	return TOF_RSC_TNI0_TOQ0 + tni * 12 + cqid;
}

int TOF_RSC_TCQ(int tni, int cqid)
{
	return TOF_RSC_TNI0_TCQ0 + tni * 12 + cqid;
}

int TOF_RSC_MRQ(int tni, int cqid)
{
	return TOF_RSC_TNI0_MRQ0 + tni * 12 + cqid;
}

int TOF_RSC_PBQ(int tni)
{
	return TOF_RSC_TNI0_PBQ + tni;
}

int TOF_RSC_PRQ(int tni)
{
	return TOF_RSC_TNI0_PRQ + tni;
}

int TOF_RSC_STT(int tni, int cqid)
{
	return TOF_RSC_TNI0_STEERINGTABLE0 + tni * 12 + cqid;
}

int TOF_RSC_MBT(int tni, int cqid)
{
	return TOF_RSC_TNI0_MBTABLE0 + tni * 12 + cqid;
}

int tof_icc_get_framelen(int len)
{
	len = TOF_ICC_RH_LEN + c_round_up(len + TOF_ICC_ECRC_LEN,
			TOF_ICC_FRAME_ALIGN);
	if (len < TOF_ICC_FRAME_LEN_MIN) {
		len = TOF_ICC_FRAME_LEN_MIN;
	}
	return len;
}

unsigned long GENMASK(int h, int l)
{
	return ((~0UL) << l) & (~0UL >> (64 - 1 - h));
}

void *tofu_indexed_2d_ptr_body_result(void *base, int major, int minor,
	int major_limit, int minor_limit, unsigned long elem_size)
{
	if ((unsigned int)major >= (unsigned int)major_limit ||
	    (unsigned int)minor >= (unsigned int)minor_limit) {
		return (void *)0;
	}

	return (void *)((unsigned long)base +
		((unsigned long)major * (unsigned long)minor_limit +
		 (unsigned long)minor) * elem_size);
}

	int tofu_utofu_unset_bg_body_result(unsigned char *enabled, int tni, int bgid,
		int (*unset_fn)(int, int), void (*unregister_fn)(int, int))
	{
		if (!enabled)
			return -22;
	if (*enabled) {
		if (!unset_fn || !unregister_fn)
			return -22;
		(void)unset_fn(tni, bgid);
		*enabled = 0;
		unregister_fn(tni, bgid);
		}
		return 0;
	}

	static unsigned long tofu_model_mask_set(unsigned long val, unsigned long mask)
	{
		unsigned long shift = mask & (~mask + 1);
		return val * shift & mask;
	}

	static unsigned long tofu_model_pack_remote_bg(const struct tofu_addr *addr,
		unsigned long tni, long gate)
	{
		return ((unsigned long)gate & 0x3f) |
			((tni & 0x7) << 6) |
			(((unsigned long)addr->c & 0x1) << 9) |
			(((unsigned long)addr->b & 0x3) << 10) |
			(((unsigned long)addr->a & 0x1) << 12) |
			(((unsigned long)addr->z & 0x1f) << 13) |
			(((unsigned long)addr->y & 0x1f) << 18) |
			(((unsigned long)addr->x & 0x1f) << 23) |
			(((unsigned long)addr->pc & 0x1) << 28) |
			(((unsigned long)addr->pb & 0x3) << 29) |
			(((unsigned long)addr->pa & 0x1) << 31);
	}

	int tofu_core_bg_links_body_result(long source_lgate,
		const struct tofu_addr *source_raddr, unsigned long source_rtni,
		long source_rgate, long dest_lgate,
		const struct tofu_addr *dest_raddr, unsigned long dest_rtni,
		long dest_rgate, unsigned long *sigmask_out,
		unsigned long *locallink_out, unsigned long *remotelink_out)
	{
		unsigned long sigmask = 0;
		unsigned long locallink = 0;
		unsigned long remotelink = 0;

		if (!sigmask_out || !locallink_out || !remotelink_out)
			return -22;

		if (source_lgate >= 0) {
			locallink |= tofu_model_mask_set(source_lgate,
				TOF_ICC_REG_BGS_LOCAL_LINK_BGID_RECV);
		}
		else {
			sigmask |= TOF_ICC_REG_BGS_SIGNAL_MASK_SIG_RECV;
		}

		if (source_rgate >= 0) {
			if (!source_raddr)
				return -22;
			remotelink |= tofu_model_mask_set(
				tofu_model_pack_remote_bg(source_raddr,
					source_rtni, source_rgate),
				TOF_ICC_REG_BGS_REMOTE_LINK_BG_ADDRESS_RECV);
		}
		else {
			sigmask |= TOF_ICC_REG_BGS_SIGNAL_MASK_TLP_RECV;
		}

		if (dest_lgate >= 0) {
			locallink |= tofu_model_mask_set(dest_lgate,
				TOF_ICC_REG_BGS_LOCAL_LINK_BGID_SEND);
		}
		else {
			sigmask |= TOF_ICC_REG_BGS_SIGNAL_MASK_SIG_SEND;
		}

		if (dest_rgate >= 0) {
			if (!dest_raddr)
				return -22;
			remotelink |= tofu_model_mask_set(
				tofu_model_pack_remote_bg(dest_raddr,
					dest_rtni, dest_rgate),
				TOF_ICC_REG_BGS_REMOTE_LINK_BG_ADDRESS_SEND);
		}
		else {
			sigmask |= TOF_ICC_REG_BGS_SIGNAL_MASK_TLP_SEND;
		}

		*sigmask_out = sigmask;
		*locallink_out = locallink;
		*remotelink_out = remotelink;
		return 0;
	}

	int tofu_core_set_bg_body_result(const struct tof_set_bg *setbg,
		unsigned long subnet, unsigned int bseq, unsigned int gpid,
		unsigned long timeout, void *(*get_bg_fn)(int, int),
		void (*publish_fn)(void *, unsigned long, unsigned int),
		unsigned long (*lock_fn)(void *),
		void (*unlock_fn)(void *, unsigned long),
		void (*reset_irqmask_fn)(void *),
		void (*reset_irqmask_imc_fn)(void *),
		void *(*bgs_reg_fn)(void *),
		void (*writeq_fn)(unsigned long, void *, long),
		void (*wmb_fn)(void),
		int (*readq_spin_fn)(void *, long, unsigned long, unsigned long,
			unsigned long))
	{
		unsigned long sigmask;
		unsigned long locallink;
		unsigned long remotelink;
		unsigned long flags;
		void *bg;
		void *bgs_reg;
		int ret;

		if (!setbg || !get_bg_fn || !publish_fn || !lock_fn ||
		    !unlock_fn || !reset_irqmask_fn || !reset_irqmask_imc_fn ||
		    !bgs_reg_fn || !writeq_fn || !wmb_fn || !readq_spin_fn)
			return -22;

		bg = get_bg_fn(setbg->tni, setbg->gate);
		if (!bg)
			return -22;

		flags = lock_fn(bg);
		publish_fn(bg, subnet, gpid);
		reset_irqmask_fn(bg);
		reset_irqmask_imc_fn(bg);

		ret = tofu_core_bg_links_body_result(setbg->source_lgate,
			&setbg->source_raddr, setbg->source_rtni,
			setbg->source_rgate, setbg->dest_lgate,
			&setbg->dest_raddr, setbg->dest_rtni,
			setbg->dest_rgate, &sigmask, &locallink, &remotelink);
		if (ret < 0) {
			unlock_fn(bg, flags);
			return ret;
		}

		bgs_reg = bgs_reg_fn(bg);
		writeq_fn(sigmask, bgs_reg, TOF_ICC_REG_BGS_SIGNAL_MASK);
		writeq_fn(locallink, bgs_reg, TOF_ICC_REG_BGS_LOCAL_LINK);
		writeq_fn(remotelink, bgs_reg, TOF_ICC_REG_BGS_REMOTE_LINK);
		writeq_fn(subnet, bgs_reg, TOF_ICC_REG_BGS_SUBNET_SIZE);
		writeq_fn(((unsigned long)gpid << 24) | bseq, bgs_reg,
			TOF_ICC_REG_BGS_GPID_BSEQ);
		wmb_fn();
		writeq_fn(1, bgs_reg, TOF_ICC_REG_BGS_ENABLE);
		if (!readq_spin_fn(bgs_reg, TOF_ICC_REG_BGS_STATE,
				TOF_ICC_REG_BGS_STATE_ENABLE,
				TOF_ICC_REG_BGS_STATE_ENABLE, timeout))
			ret = -ETIMEDOUT;
		else
			ret = 0;
		unlock_fn(bg, flags);
		return ret;
	}

	static int tofu_model_subnet_field(unsigned long subnet, unsigned int shift)
	{
		return (int)((subnet >> shift) & 0x3f);
	}

	static int tofu_model_subnet_axis_includes(int n, int s, int l, int p)
	{
		if (l == 0)
			return p < n;
		return (p < s ? p + n : p) < s + l;
	}

	static int tofu_model_subnet_includes(unsigned long subnet,
		unsigned char px, unsigned char py, unsigned char pz)
	{
		return tofu_model_subnet_axis_includes(
				tofu_model_subnet_field(subnet, 48),
				tofu_model_subnet_field(subnet, 42),
				tofu_model_subnet_field(subnet, 36), px) &&
			tofu_model_subnet_axis_includes(
				tofu_model_subnet_field(subnet, 30),
				tofu_model_subnet_field(subnet, 24),
				tofu_model_subnet_field(subnet, 18), py) &&
			tofu_model_subnet_axis_includes(
				tofu_model_subnet_field(subnet, 12),
				tofu_model_subnet_field(subnet, 6),
				tofu_model_subnet_field(subnet, 0), pz);
	}

	int tofu_utofu_set_bg_after_copy_body_result(void *ubch,
		const struct tof_set_bg *req, int kuid, unsigned int bseq,
		int ntni, int nbgs, void *(*get_bg_fn)(int, int),
		int (*meta_fn)(void *, unsigned long *, unsigned int *,
			unsigned char *),
		void (*set_enabled_fn)(void *, unsigned char),
		int (*set_bg_fn)(const struct tof_set_bg *, unsigned long,
			unsigned int, unsigned int),
		int (*bgmask_set_fn)(void *, int, int),
		void (*register_signal_fn)(int, int,
			void (*)(int, int, unsigned long, unsigned long)),
		void (*signal_handler)(int, int, unsigned long, unsigned long),
		void (*error_log_fn)(int))
	{
		unsigned long subnet = 0;
		unsigned int gpid = 0;
		unsigned char enabled = 0;
		void *ubg;
		int ret;

		(void)kuid;
		if (!ubch || !req || ntni < 0 || nbgs < 0 || nbgs > 64 ||
		    !get_bg_fn || !meta_fn || !set_enabled_fn || !set_bg_fn ||
		    !bgmask_set_fn || !register_signal_fn || !error_log_fn)
			return -22;

		ubg = get_bg_fn(req->tni, req->gate);
		if (!ubg) {
			error_log_fn(-22);
			return -22;
		}
		if (req->tni < 0 || req->tni >= ntni ||
		    req->gate < 0 || req->gate >= nbgs) {
			error_log_fn(-22);
			return -22;
		}

		ret = meta_fn(ubg, &subnet, &gpid, &enabled);
		if (ret < 0)
			return ret;

		if (req->source_lgate >= nbgs ||
		    (req->source_rgate >= 0 &&
		     (!tofu_model_subnet_includes(subnet, req->source_raddr.x,
			      req->source_raddr.y, req->source_raddr.z) ||
		      req->source_rtni < 0 || req->source_rtni >= ntni ||
		      req->source_rgate >= nbgs)) ||
		    req->dest_lgate >= nbgs ||
		    (req->dest_rgate >= 0 &&
		     (!tofu_model_subnet_includes(subnet, req->dest_raddr.x,
			      req->dest_raddr.y, req->dest_raddr.z) ||
		      req->dest_rtni < 0 || req->dest_rtni >= ntni ||
		      req->dest_rgate >= nbgs))) {
			error_log_fn(-22);
			return -22;
		}
		if (enabled)
			return -EBUSY;

		ret = set_bg_fn(req, subnet, bseq, gpid);
		if (ret < 0) {
			error_log_fn(ret);
			return ret;
		}
		set_enabled_fn(ubg, 1);
		ret = bgmask_set_fn(ubch, req->tni, req->gate);
		if (ret < 0)
			return ret;
		register_signal_fn(req->tni, req->gate, signal_handler);
		return 0;
	}

	int tofu_utofu_unset_bg_after_copy_body_result(
		const struct tof_set_bg *req, void *(*get_bg_fn)(int, int),
		int (*unset_bg_fn)(void *))
	{
		void *ubg;

		if (!req || !get_bg_fn || !unset_bg_fn)
			return -EINVAL;
		ubg = get_bg_fn(req->tni, req->gate);
		if (!ubg)
			return -EINVAL;
		return unset_bg_fn(ubg);
	}

	int tofu_core_register_signal_bg_body_result(
		void (**slot)(int, int, unsigned long, unsigned long),
		void *lock_arg,
		void (*handler)(int, int, unsigned long, unsigned long),
		unsigned long (*lock_fn)(void *),
		void (*unlock_fn)(void *, unsigned long))
	{
		unsigned long flags;

		if (!slot || !lock_fn || !unlock_fn)
			return -22;

		flags = lock_fn(lock_arg);
		*slot = handler;
		unlock_fn(lock_arg, flags);
		return 0;
	}

	int tofu_core_enable_bch_body_result(const void *bch_reg,
		void *bgs_reg, unsigned long dma_ipa, unsigned long dma_align,
		unsigned long timeout,
		void (*writeq_fn)(unsigned long, void *, long),
		int (*readq_spin_fn)(void *, long, unsigned long, unsigned long,
			unsigned long))
	{
		if (!bch_reg || dma_align == 0 ||
				(dma_ipa & (dma_align - 1)) != 0)
			return -22;
		if (!writeq_fn || !readq_spin_fn)
			return -22;

		writeq_fn(dma_ipa, bgs_reg, TOF_ICC_REG_BGS_BCH_NOTICE_IPA);
		writeq_fn(0, bgs_reg, TOF_ICC_REG_BGS_BCH_MASK);
		if (!readq_spin_fn(bgs_reg, TOF_ICC_REG_BGS_BCH_MASK_STATUS,
				TOF_ICC_REG_BGS_BCH_MASK_STATUS_RUN, 0,
				timeout))
			return -ETIMEDOUT;
		return 0;
	}

	int tofu_core_bch_disable_locked_body_result(const void *bch_reg,
		void *bgs_reg,
		void (*writeq_fn)(unsigned long, void *, long))
	{
		if (!bch_reg || !writeq_fn)
			return -22;

		writeq_fn(TOF_ICC_REG_BGS_BCH_MASK_MASK, bgs_reg,
			TOF_ICC_REG_BGS_BCH_MASK);
		return 0;
	}

	int tofu_core_bg_disable_body_result(void *bgs_reg,
		void (*writeq_fn)(unsigned long, void *, long))
	{
		if (!writeq_fn)
			return -22;

		writeq_fn(0, bgs_reg, TOF_ICC_REG_BGS_ENABLE);
		return 0;
	}

	int tofu_core_cacheflush_timeout_body_result(
		void *(*get_cq_fn)(int, int),
		void *(*cqs_reg_fn)(void *),
		void (*writeq_fn)(unsigned long, void *, long),
		void (*wmb_fn)(void),
		void (*log_fn)(int, int, int),
		int ntni, int ncqs, int kcqid,
		int steering_disabled, long steering_enable_offset)
	{
		int tni;
		int cqid;

		if (ntni < 0 || ncqs < 0)
			return -EINVAL;
		if (!get_cq_fn || !cqs_reg_fn || !writeq_fn || !wmb_fn ||
		    !log_fn)
			return -EINVAL;

		for (tni = 0; tni < ntni; ++tni) {
			for (cqid = 0; cqid < ncqs; ++cqid) {
				void *cq;
				void *cqs;

				if (cqid == kcqid)
					continue;
				cq = get_cq_fn(tni, cqid);
				if (!cq)
					return -EINVAL;
				cqs = cqs_reg_fn(cq);
				if (!cqs)
					return -EINVAL;
				if (steering_disabled) {
					writeq_fn(0, cqs, steering_enable_offset);
					wmb_fn();
				}
				log_fn(1, tni, cqid);
			}
		}

		return 0;
	}

	int tofu_core_cq_cacheflush_body_result(void *cq, int tni, int cqid,
		void *(*cqs_reg_fn)(void *),
		void (*writeq_fn)(unsigned long, void *, long),
		int (*readq_spin_fn)(void *, long, unsigned long, unsigned long,
			unsigned long),
		int (*timeout_fn)(void *), void (*log_fn)(int, int, int),
		void (*panic_fn)(void), int panic_disabled,
		unsigned long first_timeout, unsigned long second_timeout,
		long cache_flush_offset, long status_offset,
		unsigned long busy_mask)
	{
		void *cqs;

		if (!cq)
			return -EINVAL;
		if (!cqs_reg_fn || !writeq_fn || !readq_spin_fn ||
		    !timeout_fn || !log_fn || !panic_fn)
			return -EINVAL;
		cqs = cqs_reg_fn(cq);
		if (!cqs)
			return -EINVAL;

		writeq_fn(1, cqs, cache_flush_offset);
		if (!readq_spin_fn(cqs, status_offset, busy_mask, 0,
				first_timeout)) {
			log_fn(0, tni, cqid);
			if (panic_disabled) {
				int ret = timeout_fn(cq);
				if (ret < 0)
					return ret;
				if (!readq_spin_fn(cqs, status_offset, busy_mask,
						0, second_timeout)) {
					log_fn(0, tni, cqid);
					panic_fn();
				}
			}
			else {
				panic_fn();
			}
		}

		return 0;
	}

	int tofu_utofu_release_cq_body_result(void *ucq, int enabled,
		int tni, int cqid, int num_stag,
		void (*disabled_log_fn)(int, int),
		void (*drain_ranges_fn)(void *, int),
		void (*free_stag_fn)(void *, int),
		void (*done_log_fn)(void *))
	{
		int do_free;
		int stag;

		if (!ucq || num_stag < 0)
			return -EINVAL;
		if (!disabled_log_fn || !drain_ranges_fn || !free_stag_fn ||
		    !done_log_fn)
			return -EINVAL;

		if (enabled) {
			do_free = 1;
		}
		else {
			disabled_log_fn(tni, cqid);
			do_free = 0;
		}

		drain_ranges_fn(ucq, do_free);
		if (do_free) {
			for (stag = 0; stag < num_stag; ++stag)
				free_stag_fn(ucq, stag);
		}
		done_log_fn(ucq);
		return 0;
	}

	int tofu_utofu_alloc_new_steering_body_result(void *ucq, int stag,
		unsigned long start, unsigned long end, unsigned char pgszbits,
		unsigned long plus_mbva, int readonly, unsigned long blank_mbva,
		unsigned long page_size, unsigned long mbpt_entry_size,
		int profile_enabled, int profile_alloc_event,
		int profile_update_event, int profile_total_event,
		int (*calc_mbptstart_fn)(long, long, unsigned long,
			unsigned char, unsigned long *),
		int (*alloc_mbpt_fn)(void *, unsigned long, void **, int),
		void (*set_mbpt_meta_fn)(void *, unsigned long, unsigned long),
		unsigned long (*mbpt_iova_fn)(void *),
		int (*update_mbpt_entries_fn)(void *, void *, unsigned long,
			unsigned long, unsigned int, unsigned long, int),
		void (*free_mbpt_fn)(void *, void *),
		void (*enable_mb_fn)(void *, int, unsigned long, unsigned char,
			unsigned long),
		void (*enable_steering_fn)(void *, int, unsigned long,
			unsigned long, int),
		void (*trans_enable_fn)(void *, int, unsigned long, unsigned long,
			unsigned long, unsigned long, unsigned char, void *),
		void (*raw_rc_fn)(int), unsigned long (*timestamp_fn)(void),
		void (*profile_event_fn)(int, unsigned long))
	{
		unsigned long pgsz;
		unsigned long npages;
		unsigned long entries_per_page;
		unsigned long mbpt_npages;
		unsigned long mbptstart = 0;
		unsigned long mbva;
		unsigned long iova;
		unsigned long ts = 0;
		unsigned long ts_rolling = 0;
		void *mbpt = 0;
		int ret;
		unsigned int ix;

		if (!ucq || stag < 0 || end < start || page_size == 0 ||
				mbpt_entry_size == 0 ||
				pgszbits >= sizeof(unsigned long) * 8)
			return -EINVAL;
		if (!calc_mbptstart_fn || !alloc_mbpt_fn ||
		    !set_mbpt_meta_fn || !mbpt_iova_fn ||
		    !update_mbpt_entries_fn || !free_mbpt_fn ||
		    !enable_mb_fn || !enable_steering_fn || !trans_enable_fn ||
		    !raw_rc_fn)
			return -EINVAL;
		if (profile_enabled && (!timestamp_fn || !profile_event_fn))
			return -EINVAL;

		pgsz = 1UL << pgszbits;
		npages = (end - start) >> pgszbits;
		entries_per_page = page_size / mbpt_entry_size;
		if (entries_per_page == 0)
			return -EINVAL;
		mbpt_npages = ((npages + entries_per_page - 1) /
			entries_per_page) * entries_per_page;

		if (profile_enabled) {
			ts = timestamp_fn();
			ts_rolling = ts;
		}

		ret = calc_mbptstart_fn((long)start, (long)end, mbpt_npages,
			pgszbits, &mbptstart);
		if (ret < 0) {
			raw_rc_fn(ret);
			return ret;
		}

		ret = alloc_mbpt_fn(ucq, mbpt_npages, &mbpt, stag);
		if (ret < 0) {
			raw_rc_fn(ret);
			return ret;
		}
		if (!mbpt) {
			raw_rc_fn(-EINVAL);
			return -EINVAL;
		}

		set_mbpt_meta_fn(mbpt, mbptstart, pgsz);
		if (profile_enabled) {
			unsigned long now = timestamp_fn();
			profile_event_fn(profile_alloc_event, now - ts_rolling);
			ts_rolling = timestamp_fn();
		}

		ix = (unsigned int)((start - mbptstart) >> pgszbits);
		ret = update_mbpt_entries_fn(ucq, mbpt, start, end, ix, pgsz,
			readonly);
		if (ret < 0) {
			raw_rc_fn(ret);
			free_mbpt_fn(ucq, mbpt);
			return ret;
		}

		mbva = plus_mbva == blank_mbva ? 0 :
			start - mbptstart + plus_mbva;
		iova = mbpt_iova_fn(mbpt);
		enable_mb_fn(ucq, stag, iova, pgszbits, mbpt_npages);
		enable_steering_fn(ucq, stag, mbva, end - mbptstart - mbva,
			readonly);
		trans_enable_fn(ucq, stag, start, end - start, mbptstart,
			mbpt_npages * mbpt_entry_size, pgszbits, mbpt);

		if (profile_enabled) {
			unsigned long now = timestamp_fn();
			profile_event_fn(profile_update_event, now - ts_rolling);
			profile_event_fn(profile_total_event, timestamp_fn() - ts);
		}

		return 0;
	}

	static unsigned long tofu_model_align_down(unsigned long value,
		unsigned long align)
	{
		return value & ~(align - 1);
	}

	static unsigned long tofu_model_align_up(unsigned long value,
		unsigned long align)
	{
		return tofu_model_align_down(value + align - 1, align);
	}

	int tofu_utofu_ioctl_alloc_stag_body_result(void *dev, unsigned long arg,
		int special_stag, unsigned int alloc_lpg_flag,
		unsigned long blank_mbva, unsigned long page_size,
		unsigned char page_shift, unsigned long special_align,
		void *(*dev_to_cq_fn)(void *),
		void *(*current_vm_fn)(void),
		int (*copyin_fn)(struct tof_alloc_stag *, unsigned long),
		int (*copyout_fn)(unsigned long, const struct tof_alloc_stag *),
		int (*ucq_enabled_fn)(void *),
		int (*steering_enabled_fn)(void *, int),
		void (*vm_read_lock_fn)(void *),
		void (*vm_read_unlock_fn)(void *),
		void *(*lookup_range_fn)(void *, unsigned long, unsigned long),
		int (*stack_faultable_fn)(void *, unsigned long, unsigned long),
		int (*page_fault_fn)(void *, unsigned long),
		int (*pagesize_locked_fn)(unsigned long, unsigned long,
			unsigned char *, int),
		void (*cq_lock_fn)(void *),
		void (*cq_unlock_fn)(void *),
		int (*trans_search_fn)(void *, unsigned long, unsigned long,
			unsigned char, int),
		int (*reserve_stag_fn)(void *, int),
		void (*release_stag_fn)(void *, int),
		int (*alloc_new_steering_fn)(void *, int, unsigned long,
			unsigned long, unsigned char, unsigned long, int),
		unsigned long (*get_mbpt_start_fn)(void *, int),
		void (*range_insert_fn)(void *, void *, unsigned long,
			unsigned long, void *, int))
	{
		struct tof_alloc_stag req;
		void *ucq;
		void *vm;
		int readonly;
		unsigned long va;
		int ret;

		if (!dev || special_stag <= 0 || page_size == 0 ||
		    special_align == 0 ||
		    page_shift >= sizeof(unsigned long) * 8)
			return -EINVAL;
		if (!dev_to_cq_fn || !current_vm_fn || !copyin_fn ||
		    !copyout_fn || !ucq_enabled_fn || !steering_enabled_fn ||
		    !vm_read_lock_fn || !vm_read_unlock_fn ||
		    !lookup_range_fn || !stack_faultable_fn || !page_fault_fn ||
		    !pagesize_locked_fn || !cq_lock_fn || !cq_unlock_fn ||
		    !trans_search_fn || !reserve_stag_fn || !release_stag_fn ||
		    !alloc_new_steering_fn || !get_mbpt_start_fn ||
		    !range_insert_fn)
			return -EINVAL;

		ucq = dev_to_cq_fn(dev);
		if (!ucq)
			return -EINVAL;
		if (!ucq_enabled_fn(ucq))
			return -EPERM;

		req.flags = 0;
		req.stag = 0;
		req.offset = 0;
		req.va = 0;
		req.len = 0;
		ret = copyin_fn(&req, arg);
		if (ret < 0)
			return ret;

		if (req.stag < -1 || req.stag >= special_stag ||
		    !req.va || req.len == 0)
			return -EINVAL;
		if (req.stag >= 0 && steering_enabled_fn(ucq, req.stag))
			return -EBUSY;

		vm = current_vm_fn();
		if (!vm)
			return -EINVAL;

		readonly = (req.flags & 1) != 0;
		va = (unsigned long)req.va;

		for (;;) {
			unsigned long start;
			unsigned long end;
			unsigned char pgszbits;
			unsigned long pgsz;
			void *range;

			vm_read_lock_fn(vm);
			start = tofu_model_align_down(va, page_size);
			end = tofu_model_align_up(va + req.len, page_size);
			range = lookup_range_fn(vm, start, end);
			if (!range) {
				if (stack_faultable_fn(vm, start, end)) {
					vm_read_unlock_fn(vm);
					if (page_fault_fn(vm, start) < 0) {
						ret = -EINVAL;
						break;
					}
					continue;
				}

				vm_read_unlock_fn(vm);
				ret = -EINVAL;
				break;
			}

			pgszbits = page_shift;
			if (req.flags & alloc_lpg_flag) {
				ret = pagesize_locked_fn(va, req.len, &pgszbits,
					readonly);
				if (ret < 0) {
					vm_read_unlock_fn(vm);
					return ret;
				}
			}
			if (pgszbits >= sizeof(unsigned long) * 8) {
				vm_read_unlock_fn(vm);
				return -EINVAL;
			}
			pgsz = 1UL << pgszbits;
			start = tofu_model_align_down(va, pgsz);
			end = tofu_model_align_up(va + req.len, pgsz);

			cq_lock_fn(ucq);
			if (req.stag < 0) {
				int stag = trans_search_fn(ucq, start, end,
					pgszbits, readonly);

				if (stag < 0) {
					stag = reserve_stag_fn(ucq, readonly);
					if (stag < 0) {
						cq_unlock_fn(ucq);
						vm_read_unlock_fn(vm);
						return -ENOSPC;
					}
					ret = alloc_new_steering_fn(ucq, stag,
						start, end, pgszbits, blank_mbva,
						readonly);
					if (ret < 0)
						release_stag_fn(ucq, stag);
				}
				else {
					ret = 0;
				}

				req.stag = stag;
				req.offset = va - get_mbpt_start_fn(ucq, stag);
			}
			else {
				unsigned long plus_mbva;

				if (steering_enabled_fn(ucq, req.stag)) {
					cq_unlock_fn(ucq);
					vm_read_unlock_fn(vm);
					return -EBUSY;
				}
				plus_mbva = tofu_model_align_down(va,
					special_align) - start;
				ret = alloc_new_steering_fn(ucq, req.stag,
					start, end, pgszbits, plus_mbva,
					readonly);
				req.offset = va & (special_align - 1);
			}
			cq_unlock_fn(ucq);

			if (ret == 0)
				range_insert_fn(vm, range, start, end, ucq,
					req.stag);

			vm_read_unlock_fn(vm);
			break;
		}

		if (ret == 0) {
			int out_ret = copyout_fn(arg, &req);
			if (out_ret < 0)
				ret = out_ret;
		}

		return ret;
	}

	int tofu_utofu_disable_bch_body_result(unsigned char *enabled,
		int tni, int bgid, const unsigned long *bgmask, int ntni, int nbgs,
		int (*disable_fn)(int, int), int (*unset_fn)(int, int),
		void (*error_log_fn)(int), void (*mb_fn)(void))
	{
		int mask_tni;
		int mask_bgid;
		int ret;

		if (!enabled || !bgmask || ntni < 0 || nbgs < 0 || nbgs > 64)
			return -22;
		if (!*enabled)
			return -1;
		if (!disable_fn || !unset_fn || !mb_fn)
			return -22;

		ret = disable_fn(tni, bgid);
		if (ret < 0) {
			if (error_log_fn)
				error_log_fn(ret);
			return ret;
		}

		for (mask_tni = 0; mask_tni < ntni; ++mask_tni) {
			unsigned long mask = bgmask[mask_tni];
			for (mask_bgid = 0; mask_bgid < nbgs; ++mask_bgid) {
				if ((mask >> mask_bgid) & 1) {
					ret = unset_fn(mask_tni, mask_bgid);
					if (ret < 0)
						return ret;
				}
			}
		}

		*enabled = 0;
		mb_fn();
		return 0;
	}

	int tofu_utofu_bch_device_disable_body_result(void *dev,
		unsigned long device_offset, void (*log_fn)(void *),
		int (*disable_fn)(void *))
	{
		void *ubg;

		if (!dev || !log_fn || !disable_fn)
			return -EINVAL;
		ubg = (void *)((char *)dev - device_offset);
		log_fn(ubg);
		return disable_fn(ubg);
	}

	int tofu_utofu_init_globals_body_result(
		void *(*get_globals_fn)(void),
		void (*publish_fn)(const void *),
		void (*unavailable_log_fn)(void),
		void (*globals_log_fn)(const void *),
		void (*clear_caches_fn)(void),
		void (*init_lock_fn)(int, int),
		int tni_count, int cq_count,
		void (*done_log_fn)(void))
	{
		void *globals;
		int tni;
		int cq;

		if (tni_count < 0 || cq_count < 0)
			return -EINVAL;
		if (!get_globals_fn || !publish_fn || !unavailable_log_fn ||
		    !globals_log_fn || !clear_caches_fn || !init_lock_fn ||
		    !done_log_fn)
			return -EINVAL;

		globals = get_globals_fn();
		if (!globals) {
			unavailable_log_fn();
			return 0;
		}

		publish_fn(globals);
		globals_log_fn(globals);
		clear_caches_fn();
		for (tni = 0; tni < tni_count; ++tni) {
			for (cq = 0; cq < cq_count; ++cq)
				init_lock_fn(tni, cq);
		}
		done_log_fn();
		return 0;
	}

	int tofu_utofu_finalize_body_result(
		void *(*get_globals_fn)(void),
		int (*current_enabled_fn)(void),
		void (*scan_stags_fn)(void),
		void (*scan_done_log_fn)(void),
		int (*clear_range_fn)(void *, void *))
	{
		struct tofu_globals *globals;

		if (!get_globals_fn || !current_enabled_fn || !scan_stags_fn ||
		    !scan_done_log_fn || !clear_range_fn)
			return -EINVAL;

		globals = (struct tofu_globals *)get_globals_fn();
		if (!globals)
			return 0;

		if (current_enabled_fn()) {
			scan_stags_fn();
			scan_done_log_fn();
		}

		return clear_range_fn((void *)globals->linux_vmalloc_start,
				(void *)globals->linux_vmalloc_end);
	}

	int tofu_utofu_release_fd_body_result(unsigned char enable_tofu,
		void *fd_data, const void *fd_path, int pid, int fd,
		int (*path_kind_fn)(const void *), void (*release_cq_fn)(void *),
		void (*release_bch_fn)(void *), void (*log_fn)(int, int, int))
	{
		int kind;

		if (!enable_tofu || !fd_data || !fd_path)
			return 0;
		if (!path_kind_fn || !release_cq_fn || !release_bch_fn)
			return -22;

		kind = path_kind_fn(fd_path);
		if (kind == 1) {
			if (log_fn)
				log_fn(pid, fd, 1);
			release_cq_fn(fd_data);
		}
		else if (kind == 2) {
			if (log_fn)
				log_fn(pid, fd, 2);
			release_bch_fn(fd_data);
		}
		return 0;
	}

	int tofu_utofu_release_fds_body_result(unsigned char enable_tofu,
		void *proc, int max_fd, void (*release_fd_fn)(void *, int))
	{
		int fd;

		if (!enable_tofu)
			return 0;
		if (!proc || max_fd < 0 || !release_fd_fn)
			return -22;
		for (fd = 0; fd < max_fd; ++fd)
			release_fd_fn(proc, fd);
		return 0;
	}

	long tofu_utofu_unlocked_ioctl_body_result(int fd, unsigned int cmd,
		unsigned long arg, int max_fd, void *fd_data,
		unsigned int alloc_cmd, unsigned int free_cmd,
		unsigned int enable_bch_cmd, unsigned int disable_bch_cmd,
		unsigned char profile_enabled, int profile_alloc_event,
		int profile_free_event,
		int (*alloc_fn)(void *, unsigned long),
		int (*free_fn)(void *, unsigned long),
		int (*enable_bch_fn)(void *, unsigned long),
		int (*disable_bch_fn)(void *, unsigned long),
		unsigned long (*timestamp_fn)(void),
		void (*profile_event_fn)(int, unsigned long),
		void (*unknown_log_fn)(int))
	{
		unsigned long start = 0;
		int profile_event = 0;
		int has_profile_event = 0;
		int ret;

		if (fd < 0 || max_fd < 0 || fd >= max_fd || !fd_data)
			return -ENOTSUPP;

		if (profile_enabled) {
			if (!timestamp_fn)
				return -22;
			start = timestamp_fn();
		}

		if (cmd == alloc_cmd) {
			if (!alloc_fn)
				return -22;
			ret = alloc_fn(fd_data, arg);
			profile_event = profile_alloc_event;
			has_profile_event = 1;
		}
		else if (cmd == free_cmd) {
			if (!free_fn)
				return -22;
			ret = free_fn(fd_data, arg);
			profile_event = profile_free_event;
			has_profile_event = 1;
		}
		else if (cmd == enable_bch_cmd) {
			if (!enable_bch_fn)
				return -22;
			ret = enable_bch_fn(fd_data, arg);
		}
		else if (cmd == disable_bch_cmd) {
			if (!disable_bch_fn)
				return -22;
			ret = disable_bch_fn(fd_data, arg);
		}
		else {
			if (unknown_log_fn)
				unknown_log_fn(fd);
			return -ENOTSUPP;
		}

		if (profile_enabled && has_profile_event) {
			if (!timestamp_fn || !profile_event_fn)
				return -22;
			profile_event_fn(profile_event, timestamp_fn() - start);
		}

		return ret;
	}

	int tofu_utofu_free_stags_after_req_copy_body_result(void *ucq,
		struct tof_free_stags *req, void *arg, int *staging,
		int max_stags,
		int (*copyin_stags_fn)(int *, const int *, unsigned long),
		int (*copyout_stags_fn)(int *, const int *, unsigned long),
		int (*copyout_req_fn)(void *, const struct tof_free_stags *),
		int (*free_one_fn)(void *, int), void (*remove_range_fn)(int),
		void (*raw_rc_fn)(int),
		void (*log_out_fn)(void *, unsigned short, int *, int))
	{
		int no_free_count = 0;
		int idx;

		if (!ucq || !req || !arg || !staging || max_stags < 0)
			return -EINVAL;
		if (!copyin_stags_fn || !copyout_stags_fn ||
		    !copyout_req_fn || !free_one_fn || !remove_range_fn)
			return -EINVAL;
		if ((int)req->num > max_stags || !req->stags)
			return -EINVAL;

		if (copyin_stags_fn(staging, req->stags, req->num) != 0) {
			if (raw_rc_fn)
				raw_rc_fn(-EFAULT);
			return -EFAULT;
		}

		for (idx = 0; idx < (int)req->num; ++idx) {
			int stag = staging[idx];
			int ret = free_one_fn(ucq, stag);

			remove_range_fn(stag);
			if (ret == 0) {
				staging[idx] = -1;
			}
			else if (ret == -ENOENT) {
				++no_free_count;
				continue;
			}
			else {
				req->num = (unsigned short)(idx - no_free_count);
				if (copyout_stags_fn(req->stags, staging,
					    req->num) != 0) {
					if (raw_rc_fn)
						raw_rc_fn(-EFAULT);
					return -EFAULT;
				}
				if (copyout_req_fn(arg, req) != 0)
					return -EFAULT;
				return ret;
			}
		}

		req->num = (unsigned short)(idx - no_free_count);
		if (copyout_stags_fn(req->stags, staging, req->num) != 0) {
			if (raw_rc_fn)
				raw_rc_fn(-EFAULT);
			return -EFAULT;
		}
		if (copyout_req_fn(arg, req) != 0)
			return -EFAULT;
		if (log_out_fn)
			log_out_fn(ucq, req->num, req->stags, no_free_count);

		return no_free_count > 0 ? -ENOENT : 0;
	}

	int tofu_utofu_free_stag_body_result(void *ucq, int stag,
		int num_stag, int (*steering_enabled_fn)(void *, int),
		int (*kref_is_mckernel_fn)(void *, int),
		void (*non_mckernel_log_fn)(void *, int),
		void (*disable_entries_fn)(void *, int),
		void (*trans_disable_fn)(void *, int), void (*wmb_fn)(void),
		void *profile_state, void (*profile_fn)(void *, int),
		int (*cacheflush_fn)(void *, int),
		void (*kref_put_fn)(void *, int),
		void (*clear_mbpt_fn)(void *, int),
		void (*dealloc_log_fn)(void *, int))
	{
		int enabled;

		if (!ucq || num_stag < 0 || stag < 0 || stag >= num_stag)
			return -EINVAL;
		if (!steering_enabled_fn || !kref_is_mckernel_fn ||
		    !disable_entries_fn || !trans_disable_fn || !wmb_fn ||
		    !cacheflush_fn || !kref_put_fn || !clear_mbpt_fn)
			return -EINVAL;

		enabled = steering_enabled_fn(ucq, stag);
		if (enabled < 0)
			return -EINVAL;
		if (enabled == 0)
			return -ENOENT;

		if (!kref_is_mckernel_fn(ucq, stag)) {
			if (non_mckernel_log_fn)
				non_mckernel_log_fn(ucq, stag);
			return -EINVAL;
		}

		disable_entries_fn(ucq, stag);
		trans_disable_fn(ucq, stag);
		wmb_fn();
		if (profile_fn)
			profile_fn(profile_state, TOFU_FREE_STAG_PROFILE_PRE);

		(void)cacheflush_fn(ucq, stag);

		if (profile_fn)
			profile_fn(profile_state, TOFU_FREE_STAG_PROFILE_CQFLUSH);
		kref_put_fn(ucq, stag);
		clear_mbpt_fn(ucq, stag);
		if (dealloc_log_fn)
			dealloc_log_fn(ucq, stag);
		if (profile_fn) {
			profile_fn(profile_state, TOFU_FREE_STAG_PROFILE_DEALLOC);
			profile_fn(profile_state, TOFU_FREE_STAG_PROFILE_TOTAL);
		}

		return 0;
	}

	int tofu_utofu_enable_bch_precheck_body_result(int bgid,
		const unsigned char *enabled, int max_bchs)
	{
		if (!enabled || max_bchs < 0)
			return -EINVAL;
		if (bgid >= max_bchs)
			return -ENOTTY;
		if (*enabled)
			return -EBUSY;
		return 0;
	}

	int tofu_utofu_enable_bch_request_validate_result(
		const struct tof_enable_bch *req, unsigned long dma_align,
		unsigned long bseq_size)
	{
		if (!req || dma_align == 0 || bseq_size == 0)
			return -EINVAL;
		if (req->num < 0 || !req->bgs || !req->addr ||
				((unsigned long)req->addr & (dma_align - 1)) != 0 ||
				(unsigned int)req->bseq >= bseq_size)
			return -EINVAL;
		return 0;
	}

	int tofu_utofu_enable_bch_commit_body_result(void *ubg,
		unsigned char *enabled, int tni, int bgid,
		const struct tof_enable_bch *req, unsigned long ipa,
		unsigned long *bgmask, int ntni, unsigned long *iova, int kuid,
		int (*enable_fn)(int, int, unsigned long),
		int (*set_bg_fn)(void *, const struct tof_set_bg *, int, unsigned int),
		int (*disable_fn)(int, int),
		int (*unset_bg_fn)(const struct tof_set_bg *),
		void (*error_log_fn)(int))
	{
		int i;
		int ret;

		if (!ubg || !enabled || !req || !bgmask || !iova || ntni < 0 ||
				!enable_fn || !set_bg_fn || !disable_fn ||
				!unset_bg_fn || !error_log_fn)
			return -EINVAL;
		if (req->num < 0 || !req->bgs)
			return -EINVAL;

		for (i = 0; i < ntni; ++i)
			bgmask[i] = 0;

		ret = enable_fn(tni, bgid, ipa);
		if (ret < 0) {
			error_log_fn(ret);
			disable_fn(tni, bgid);
			return ret;
		}

		for (i = 0; i < req->num; ++i) {
			ret = set_bg_fn(ubg, &req->bgs[i], kuid,
				(unsigned int)req->bseq);
			if (ret < 0) {
				error_log_fn(ret);
				disable_fn(tni, bgid);
				for (; i--; )
					unset_bg_fn(&req->bgs[i]);
				return ret;
			}
		}

		*enabled = 1;
		*iova = ipa;
		return 0;
	}

	int TOF_ICC_TLP_LEN(int len)
	{
		return (len + 1) * TOF_ICC_FRAME_ALIGN;
	}

int TOF_ICC_FRAME_LEN(int len)
{
	return TOF_ICC_RH_LEN + TOF_ICC_TLP_LEN(len);
}

int TOF_ICC_TOQ_SIZE_BITS(int size)
{
	return size * 2 + 11;
}

int TOF_ICC_TOQ_SIZE(int size)
{
	return 1 << TOF_ICC_TOQ_SIZE_BITS(size);
}

int TOF_ICC_TOQ_LEN(int size)
{
	return TOF_ICC_TOQ_SIZE(size) * TOF_ICC_TOQ_DESC_SIZE;
}

int TOF_ICC_TCQ_LEN(int size)
{
	return TOF_ICC_TOQ_SIZE(size) * TOF_ICC_TCQ_DESC_SIZE;
}

int TOF_ICC_MRQ_SIZE_BITS(int size)
{
	return size * 2 + 11;
}

int TOF_ICC_MRQ_SIZE(int size)
{
	return 1 << TOF_ICC_MRQ_SIZE_BITS(size);
}

int TOF_ICC_MRQ_LEN(int size)
{
	return TOF_ICC_MRQ_SIZE(size) * TOF_ICC_MRQ_DESC_SIZE;
}

int TOF_ICC_PBQ_SIZE_BITS(int size)
{
	return size * 2 + 11;
}

int TOF_ICC_PBQ_SIZE(int size)
{
	return 1 << TOF_ICC_PBQ_SIZE_BITS(size);
}

int TOF_ICC_PBQ_LEN(int size)
{
	return TOF_ICC_PBQ_SIZE(size) * TOF_ICC_PBQ_DESC_SIZE;
}

int TOF_ICC_PRQ_SIZE_BITS(int size)
{
	return size * 2 + 11;
}

int TOF_ICC_PRQ_SIZE(int size)
{
	return 1 << TOF_ICC_PRQ_SIZE_BITS(size);
}

int TOF_ICC_PRQ_LEN(int size)
{
	return TOF_ICC_PRQ_SIZE(size) * TOF_ICC_PRQ_DESC_SIZE;
}

int TOF_ICC_MB_PS_ENCODE(int bits)
{
	return bits % 9 == 3 ? bits / 9 - 1 : bits / 13 + 3;
}

unsigned long TOF_ICC_REG_CQ_PA(int tni, int cqid)
{
	return tof_icc_reg_pa + tni * 0x1000000 + cqid * 0x10000;
}

unsigned long TOF_ICC_REG_BCH_PA(int tni, int bgid)
{
	return tof_icc_reg_pa + 0x0000e00000 + tni * 0x1000000
		+ bgid * 0x10000;
}

unsigned long TOF_ICC_REG_CQS_PA(int tni, int cqid)
{
	return tof_icc_reg_pa + 0x0000400000 + tni * 0x1000000
		+ cqid * 0x10000;
}

unsigned long TOF_ICC_REG_BGS_PA(int tni, int bgid)
{
	return tof_icc_reg_pa + 0x0000800000 + tni * 0x1000000
		+ bgid * 0x10000;
}

unsigned long TOF_ICC_REG_TNI_PA(int tni)
{
	return tof_icc_reg_pa + 0x0000c00000 + tni * 0x1000000;
}

unsigned long TOF_ICC_REG_PORT_PA(int port)
{
	return tof_icc_reg_pa + 0x0006000000 + port * 0x1000;
}

int TOF_ICC_XB_TC_DATA_CYCLE_COUNT(int tni)
{
	return tni * 0x10 + 0x0;
}

int TOF_ICC_XB_TC_WAIT_CYCLE_COUNT(int tni)
{
	return tni * 0x10 + 0x8;
}

int TOF_ICC_XB_TD_DATA_CYCLE_COUNT(int tnr)
{
	return tnr * 0x10 + 0x60;
}

int TOF_ICC_XB_TD_WAIT_CYCLE_COUNT(int tnr)
{
	return tnr * 0x10 + 0x68;
}

int TOF_ICC_REG_TOFU_TD_TLP_FILTER(int tnr)
{
	return tnr * 0x10 + 0x10;
}

int TOF_ICC_REG_TOFU_TD_SETTINGS(int tnr)
{
	return tnr * 0x10 + 0x18;
}

int TOF_ICC_REG_TOFU_TNI_VMS(int tni, int vmsid)
{
	return tni * 0x100 + vmsid * 0x8 + 0x100;
}

int TOF_ICC_REG_TOFU_TNI_VMS_CQ00(int tni)
{
	return tni * 0x100 + 0x180;
}

int TOF_ICC_REG_TOFU_TNI_VMS_BG00(int tni)
{
	return tni * 0x100 + 0x1a0;
}

int TOF_ICC_REG_TOFU_TNI_VMS_BG16(int tni)
{
	return tni * 0x100 + 0x1a8;
}

int TOF_ICC_REG_TOFU_TNI_VMS_BG32(int tni)
{
	return tni * 0x100 + 0x1b0;
}

int TOF_ICC_REG_TOFU_TNI_MSI_BASE(int tni)
{
	return tni * 0x100 + 0x1c0;
}

int tofu_utofu_calc_mbptstart_body_result(long start, long end,
		unsigned long mbpt_npages, unsigned char pgszbits,
		unsigned long *mbptstart)
{
	(void)end;
	(void)mbpt_npages;
	(void)pgszbits;
	if (!mbptstart)
		return -22;
	*mbptstart = start;
	return 0;
}

unsigned long tofu_ib_dmaaddr_pack_result(unsigned int stag,
					  unsigned int offset)
{
	return (unsigned long)stag << 32 | offset;
}

unsigned int tofu_ib_dmaaddr_stag_result(unsigned long dmaaddr)
{
	return dmaaddr >> 32;
}

short tofu_ib_stag_alloc_body_result(const short *list, int *read_pos,
	const int *write_pos, int max_stag)
{
	short ret;
	int rp;
	int wp;

	if (!list || !read_pos || !write_pos || max_stag <= 0)
		return -22;
	rp = *read_pos;
	wp = *write_pos;
	if (rp == wp)
		return -2;
	if (rp < 0 || rp >= max_stag || wp < 0 || wp >= max_stag)
		return -22;
	ret = list[rp];
	*read_pos = (rp + 1) % max_stag;
	return ret;
}

int tofu_ib_stag_free_body_result(short *list, const int *read_pos,
	int *write_pos, short stag, int max_stag)
{
	int rp;
	int wp;
	int next;

	if (!list || !read_pos || !write_pos || max_stag <= 0)
		return -22;
	rp = *read_pos;
	wp = *write_pos;
	if (rp < 0 || rp >= max_stag || wp < 0 || wp >= max_stag)
		return -22;
	next = (wp + 1) % max_stag;
	if (next != rp) {
		list[wp] = stag;
		*write_pos = next;
		return 1;
	}
	return 0;
}

int tofu_utofu_trans_mru_delete_body_result(
	struct tof_utofu_trans_list *mru, int *mruhead, int stag,
	int empty_stag)
{
	int prev;
	int next;

	if (!mru || !mruhead || stag < 0)
		return -22;
	prev = mru[stag].prev;
	next = mru[stag].next;
	if (prev == empty_stag || next == empty_stag)
		return 0;
	if (prev == stag) {
		*mruhead = empty_stag;
	}
	else {
		if (*mruhead == stag)
			*mruhead = next;
		mru[prev].next = next;
		mru[next].prev = prev;
	}
	mru[stag].prev = empty_stag;
	mru[stag].next = empty_stag;
	return 0;
}

int tofu_utofu_trans_mru_insert_body_result(
	struct tof_utofu_trans_list *mru, int *mruhead, int stag,
	unsigned char pgszbits, void *mbpt, int empty_stag)
{
	int next;
	int prev;

	if (!mru || !mruhead || stag < 0)
		return -22;
	mru[stag].pgszbits = pgszbits;
	mru[stag].mbpt = mbpt;
	if (*mruhead == empty_stag) {
		mru[stag].prev = stag;
		mru[stag].next = stag;
	}
	else {
		next = *mruhead;
		prev = mru[next].prev;
		mru[stag].prev = prev;
		mru[stag].next = next;
		mru[prev].next = stag;
		mru[next].prev = stag;
	}
	*mruhead = stag;
	return 0;
}

int tofu_utofu_trans_disable_body_result(void *table_slot,
	struct tof_utofu_trans_list *mru, int *mruhead, int stag,
	int empty_stag, void (*atomic_set_fn)(void *, unsigned long))
{
	if (!table_slot || !mru || !mruhead || stag < 0 || !atomic_set_fn)
		return -22;
	atomic_set_fn(table_slot, 0);
	return tofu_utofu_trans_mru_delete_body_result(mru, mruhead, stag,
						      empty_stag);
}

unsigned long tofu_utofu_trans_entry_pack_result(unsigned long start,
	unsigned long len, unsigned char pgszbits, int page_shift,
	int ps_code_64kb, int ps_code_2mb)
{
	unsigned long ps_code;

	if (page_shift < 0 || page_shift >= 64)
		return 0;
	ps_code = pgszbits == page_shift ? ps_code_64kb : ps_code_2mb;
	return ((start >> page_shift) & ((1UL << 36) - 1)) |
		(((len >> page_shift) & ((1UL << 27) - 1)) << 36) |
		((ps_code & 1UL) << 63);
}

int tofu_utofu_trans_update_body_result(struct tof_trans_table *table_slot,
	struct tof_utofu_trans_list *mru, int *mruhead, void *lock_arg,
	int stag, unsigned long start, unsigned long len,
	unsigned char pgszbits, void *mbpt, int empty_stag, int page_shift,
	int ps_code_64kb, int ps_code_2mb,
	void (*atomic_set_fn)(void *, unsigned long),
	unsigned long (*lock_fn)(void *), void (*unlock_fn)(void *, unsigned long))
{
	unsigned long flags;
	int ret;

	if (!table_slot || !mru || !mruhead || !lock_arg || stag < 0 ||
			!atomic_set_fn || !lock_fn || !unlock_fn)
		return -22;
	atomic_set_fn(table_slot, tofu_utofu_trans_entry_pack_result(start,
		len, pgszbits, page_shift, ps_code_64kb, ps_code_2mb));
	flags = lock_fn(lock_arg);
	ret = tofu_utofu_trans_mru_delete_body_result(mru, mruhead, stag,
						      empty_stag);
	if (!ret)
		ret = tofu_utofu_trans_mru_insert_body_result(mru, mruhead,
			stag, pgszbits, mbpt, empty_stag);
	unlock_fn(lock_arg, flags);
	return ret;
}

int tofu_utofu_trans_enable_body_result(struct tof_trans_table *table_slot,
	struct tof_utofu_trans_list *mru, int *mruhead, void *lock_arg,
	int stag, unsigned long start, unsigned long len,
	unsigned long mbptstart, unsigned long mbptlen, unsigned char pgszbits,
	void *mbpt, int empty_stag, int page_shift, int ps_code_64kb,
	int ps_code_2mb, void (*atomic_set_fn)(void *, unsigned long),
	void (*wmb_fn)(void), unsigned long (*lock_fn)(void *),
	void (*unlock_fn)(void *, unsigned long))
{
	if (!table_slot || !mru || !mruhead || !lock_arg || stag < 0 || !wmb_fn)
		return -22;
	table_slot->mbpt = tofu_utofu_trans_entry_pack_result(mbptstart,
		mbptlen, pgszbits, page_shift, ps_code_64kb, ps_code_2mb);
	wmb_fn();
	return tofu_utofu_trans_update_body_result(table_slot, mru, mruhead,
		lock_arg, stag, start, len, pgszbits, mbpt, empty_stag,
		page_shift, ps_code_64kb, ps_code_2mb, atomic_set_fn,
		lock_fn, unlock_fn);
}

static unsigned long tofu_model_set_field(unsigned long word,
	unsigned long mask, int shift, unsigned long value)
{
	return (word & ~(mask << shift)) | ((value & mask) << shift);
}

unsigned long tofu_utofu_trans_table_steering_start_result(
	const struct tof_trans_table *table_slot, int page_shift)
{
	if (!table_slot || page_shift < 0 || page_shift >= 64)
		return 0;
	return (table_slot->steering & TOF_TRANS_START_MASK) << page_shift;
}

unsigned long tofu_utofu_trans_table_steering_len_result(
	const struct tof_trans_table *table_slot, int page_shift)
{
	if (!table_slot || page_shift < 0 || page_shift >= 64)
		return 0;
	return ((table_slot->steering >> 36) & TOF_TRANS_LEN_MASK) << page_shift;
}

unsigned long tofu_utofu_trans_table_mbpt_start_result(
	const struct tof_trans_table *table_slot, int page_shift)
{
	if (!table_slot || page_shift < 0 || page_shift >= 64)
		return 0;
	return (table_slot->mbpt & TOF_TRANS_START_MASK) << page_shift;
}

unsigned long tofu_utofu_trans_table_mbpt_len_result(
	const struct tof_trans_table *table_slot, int page_shift)
{
	if (!table_slot || page_shift < 0 || page_shift >= 64)
		return 0;
	return ((table_slot->mbpt >> 36) & TOF_TRANS_LEN_MASK) << page_shift;
}

int tofu_icc_steering_enable_body_result(
	struct tof_icc_steering_entry_words *entry, int stag,
	unsigned long mbva, unsigned long length, int readonly,
	void (*wmb_fn)(void))
{
	unsigned long word;

	if (!entry || stag < 0 || !wmb_fn)
		return -22;
	word = entry->word & ~TOF_ICC_STEERING_MUT_MASK;
	if (readonly)
		word |= 1UL << TOF_ICC_STEERING_READONLY_SHIFT;
	word |= ((mbva >> 8) & TOF_ICC_STEERING_MBVA_MASK) <<
		TOF_ICC_STEERING_MBVA_SHIFT;
	word |= ((unsigned long)stag & TOF_ICC_STEERING_MBID_MASK) <<
		TOF_ICC_STEERING_MBID_SHIFT;
	entry->length = length;
	entry->word = word;
	wmb_fn();
	entry->word = word | (1UL << TOF_ICC_STEERING_ENABLE_SHIFT);
	return 0;
}

int tofu_icc_steering_entry_is_enabled_result(
	const struct tof_icc_steering_entry_words *entry)
{
	if (!entry)
		return 0;
	return (entry->word >> TOF_ICC_STEERING_ENABLE_SHIFT) & 1;
}

int tofu_icc_steering_disable_entry_body_result(
	struct tof_icc_steering_entry_words *entry)
{
	if (!entry)
		return -22;
	entry->word &= ~(1UL << TOF_ICC_STEERING_ENABLE_SHIFT);
	return 0;
}

int tofu_utofu_reserve_stag_body_result(
	const struct tof_icc_steering_entry_words *steering, int special_stag,
	int num_stag, int readonly, unsigned long entry_size)
{
	int stag;

	if (!steering || special_stag < 0 || num_stag < special_stag ||
			entry_size == 0)
		return -22;
	for (stag = special_stag + (readonly != 0); stag < num_stag;
			stag += 2) {
		const struct tof_icc_steering_entry_words *entry =
			(const struct tof_icc_steering_entry_words *)
			((const char *)steering + (unsigned long)stag *
				entry_size);
		if (!tofu_icc_steering_entry_is_enabled_result(entry))
			return stag;
	}
	return -1;
}

int tofu_icc_mb_enable_body_result(struct tof_icc_mb_entry_words *entry,
	unsigned long iova, unsigned char pgszbits, unsigned long npages,
	void (*wmb_fn)(void))
{
	unsigned long word;

	if (!entry || !wmb_fn)
		return -22;
	word = entry->word & ~TOF_ICC_MB_MUT_MASK;
	word = tofu_model_set_field(word, TOF_ICC_MB_PS_MASK, 0,
		(unsigned long)TOF_ICC_MB_PS_ENCODE(pgszbits));
	word = tofu_model_set_field(word, TOF_ICC_MB_IPA_MASK,
		TOF_ICC_MB_IPA_SHIFT, iova >> 8);
	entry->npage = npages;
	entry->word = word;
	wmb_fn();
	entry->word = word | (1UL << TOF_ICC_MB_ENABLE_SHIFT);
	return 0;
}

int tofu_icc_mb_disable_entry_body_result(
	struct tof_icc_mb_entry_words *entry)
{
	if (!entry)
		return -22;
	entry->word &= ~(1UL << TOF_ICC_MB_ENABLE_SHIFT);
	return 0;
}

unsigned long tofu_icc_mbpt_disable_entry_body_result(
	struct tof_icc_mbpt_entry_words *entry)
{
	unsigned long word;
	unsigned long ipa;

	if (!entry)
		return 0;
	word = entry->word;
	if (!((word >> TOF_ICC_MBPT_ENABLE_SHIFT) & 1))
		return 0;
	ipa = ((word >> TOF_ICC_MBPT_IPA_SHIFT) &
		TOF_ICC_MBPT_IPA_MASK) << 12;
	entry->word = word & ~TOF_ICC_MBPT_MUT_MASK;
	return ipa;
}

int tofu_icc_mbpt_enable_entry_body_result(
	struct tof_icc_mbpt_entry_words *entry, unsigned long iova,
	void (*wmb_fn)(void))
{
	unsigned long word;

	if (!entry || !wmb_fn)
		return -22;
	word = entry->word & ~TOF_ICC_MBPT_MUT_MASK;
	word = tofu_model_set_field(word, TOF_ICC_MBPT_IPA_MASK,
		TOF_ICC_MBPT_IPA_SHIFT, iova >> 12);
	entry->word = word;
	wmb_fn();
	entry->word = word | (1UL << TOF_ICC_MBPT_ENABLE_SHIFT);
	return 0;
}

int tofu_icc_mbpt_entry_is_enabled_result(
	const struct tof_icc_mbpt_entry_words *entry)
{
	if (!entry)
		return 0;
	return (entry->word >> TOF_ICC_MBPT_ENABLE_SHIFT) & 1;
}

int tofu_utofu_trans_search_body_result(
	const struct tof_trans_table *table,
	const struct tof_utofu_trans_list *mru, int mruhead,
	unsigned long start, unsigned long end, unsigned char pgszbits,
	int readonly, int exact_address_match, int empty_stag,
	int special_stag, int max_stag, int page_shift)
{
	int stag;
	int want_readonly;
	int visited;

	if (!table || !mru || max_stag <= 0 || special_stag < 0 ||
			page_shift < 0 || page_shift >= 64)
		return -22;
	if (mruhead == empty_stag)
		return -2;
	if (mruhead < 0 || mruhead >= max_stag)
		return -22;

	want_readonly = readonly != 0;
	stag = mruhead;
	visited = 0;
	do {
		unsigned long stagstart;
		unsigned long stagend;

		if (stag < 0 || stag >= max_stag)
			return -22;
		stagstart = tofu_utofu_trans_table_steering_start_result(
			&table[stag], page_shift);
		stagend = stagstart +
			tofu_utofu_trans_table_steering_len_result(
				&table[stag], page_shift);
		if (stag >= special_stag && ((stag & 1) == want_readonly) &&
				mru[stag].pgszbits == pgszbits) {
			if (exact_address_match & 1) {
				if (stagstart == start && stagend == end)
					return stag;
			}
			else {
				if (stagstart <= start && end <= stagend)
					return stag;
			}
		}
		stag = mru[stag].next;
		++visited;
		if (visited >= max_stag && stag != mruhead)
			return -22;
	} while (stag != mruhead);

	return -2;
}
#else
extern int TOF_RSC_TOQ(int, int);
extern int TOF_RSC_TCQ(int, int);
extern int TOF_RSC_MRQ(int, int);
extern int TOF_RSC_PBQ(int);
extern int TOF_RSC_PRQ(int);
extern int TOF_RSC_STT(int, int);
extern int TOF_RSC_MBT(int, int);
extern int tof_icc_get_framelen(int);
extern unsigned long GENMASK(int, int);
extern int TOF_ICC_TLP_LEN(int);
extern int TOF_ICC_FRAME_LEN(int);
extern int TOF_ICC_TOQ_SIZE_BITS(int);
extern int TOF_ICC_TOQ_SIZE(int);
extern int TOF_ICC_TOQ_LEN(int);
extern int TOF_ICC_TCQ_LEN(int);
extern int TOF_ICC_MRQ_SIZE_BITS(int);
extern int TOF_ICC_MRQ_SIZE(int);
extern int TOF_ICC_MRQ_LEN(int);
extern int TOF_ICC_PBQ_SIZE_BITS(int);
extern int TOF_ICC_PBQ_SIZE(int);
extern int TOF_ICC_PBQ_LEN(int);
extern int TOF_ICC_PRQ_SIZE_BITS(int);
extern int TOF_ICC_PRQ_SIZE(int);
extern int TOF_ICC_PRQ_LEN(int);
extern int TOF_ICC_MB_PS_ENCODE(int);
extern unsigned long TOF_ICC_REG_CQ_PA(int, int);
extern unsigned long TOF_ICC_REG_BCH_PA(int, int);
extern unsigned long TOF_ICC_REG_CQS_PA(int, int);
extern unsigned long TOF_ICC_REG_BGS_PA(int, int);
extern unsigned long TOF_ICC_REG_TNI_PA(int);
extern unsigned long TOF_ICC_REG_PORT_PA(int);
extern int TOF_ICC_XB_TC_DATA_CYCLE_COUNT(int);
extern int TOF_ICC_XB_TC_WAIT_CYCLE_COUNT(int);
extern int TOF_ICC_XB_TD_DATA_CYCLE_COUNT(int);
extern int TOF_ICC_XB_TD_WAIT_CYCLE_COUNT(int);
extern int TOF_ICC_REG_TOFU_TD_TLP_FILTER(int);
extern int TOF_ICC_REG_TOFU_TD_SETTINGS(int);
extern int TOF_ICC_REG_TOFU_TNI_VMS(int, int);
extern int TOF_ICC_REG_TOFU_TNI_VMS_CQ00(int);
extern int TOF_ICC_REG_TOFU_TNI_VMS_BG00(int);
extern int TOF_ICC_REG_TOFU_TNI_VMS_BG16(int);
extern int TOF_ICC_REG_TOFU_TNI_VMS_BG32(int);
extern int TOF_ICC_REG_TOFU_TNI_MSI_BASE(int);
extern int tofu_utofu_calc_mbptstart_body_result(long, long, unsigned long,
		unsigned char, unsigned long *);
extern unsigned long tofu_ib_dmaaddr_pack_result(unsigned int, unsigned int);
extern unsigned int tofu_ib_dmaaddr_stag_result(unsigned long);
extern short tofu_ib_stag_alloc_body_result(const short *, int *,
	const int *, int);
extern int tofu_ib_stag_free_body_result(short *, const int *, int *,
	short, int);
extern int tofu_utofu_trans_mru_delete_body_result(
	struct tof_utofu_trans_list *, int *, int, int);
extern int tofu_utofu_trans_mru_insert_body_result(
	struct tof_utofu_trans_list *, int *, int, unsigned char, void *, int);
extern int tofu_utofu_trans_disable_body_result(void *,
	struct tof_utofu_trans_list *, int *, int, int,
	void (*)(void *, unsigned long));
extern unsigned long tofu_utofu_trans_entry_pack_result(unsigned long,
	unsigned long, unsigned char, int, int, int);
extern int tofu_utofu_trans_update_body_result(struct tof_trans_table *,
	struct tof_utofu_trans_list *, int *, void *, int, unsigned long,
	unsigned long, unsigned char, void *, int, int, int, int,
	void (*)(void *, unsigned long), unsigned long (*)(void *),
	void (*)(void *, unsigned long));
extern int tofu_utofu_trans_enable_body_result(struct tof_trans_table *,
	struct tof_utofu_trans_list *, int *, void *, int, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned char, void *,
	int, int, int, int, void (*)(void *, unsigned long), void (*)(void),
	unsigned long (*)(void *), void (*)(void *, unsigned long));
extern unsigned long tofu_utofu_trans_table_steering_start_result(
	const struct tof_trans_table *, int);
extern unsigned long tofu_utofu_trans_table_steering_len_result(
	const struct tof_trans_table *, int);
extern unsigned long tofu_utofu_trans_table_mbpt_start_result(
	const struct tof_trans_table *, int);
extern unsigned long tofu_utofu_trans_table_mbpt_len_result(
	const struct tof_trans_table *, int);
extern int tofu_icc_steering_enable_body_result(
	struct tof_icc_steering_entry_words *, int, unsigned long,
	unsigned long, int, void (*)(void));
extern int tofu_icc_steering_entry_is_enabled_result(
	const struct tof_icc_steering_entry_words *);
extern int tofu_icc_steering_disable_entry_body_result(
	struct tof_icc_steering_entry_words *);
extern int tofu_utofu_reserve_stag_body_result(
	const struct tof_icc_steering_entry_words *, int, int, int,
	unsigned long);
extern int tofu_icc_mb_enable_body_result(
	struct tof_icc_mb_entry_words *, unsigned long, unsigned char,
	unsigned long, void (*)(void));
extern int tofu_icc_mb_disable_entry_body_result(
	struct tof_icc_mb_entry_words *);
extern unsigned long tofu_icc_mbpt_disable_entry_body_result(
	struct tof_icc_mbpt_entry_words *);
extern int tofu_icc_mbpt_enable_entry_body_result(
	struct tof_icc_mbpt_entry_words *, unsigned long, void (*)(void));
extern int tofu_icc_mbpt_entry_is_enabled_result(
	const struct tof_icc_mbpt_entry_words *);
extern int tofu_utofu_trans_search_body_result(
	const struct tof_trans_table *, const struct tof_utofu_trans_list *,
	int, unsigned long, unsigned long, unsigned char, int, int, int, int,
	int, int);
	extern void *tofu_indexed_2d_ptr_body_result(void *, int, int, int, int,
		unsigned long);
	extern int tofu_utofu_unset_bg_body_result(unsigned char *, int, int,
		int (*)(int, int), void (*)(int, int));
			extern int tofu_core_bg_links_body_result(long, const struct tofu_addr *,
				unsigned long, long, long, const struct tofu_addr *, unsigned long,
				long, unsigned long *, unsigned long *, unsigned long *);
			extern int tofu_core_set_bg_body_result(const struct tof_set_bg *,
				unsigned long, unsigned int, unsigned int, unsigned long,
				void *(*)(int, int),
				void (*)(void *, unsigned long, unsigned int),
				unsigned long (*)(void *), void (*)(void *, unsigned long),
				void (*)(void *), void (*)(void *), void *(*)(void *),
				void (*)(unsigned long, void *, long), void (*)(void),
				int (*)(void *, long, unsigned long, unsigned long,
					unsigned long));
			extern int tofu_utofu_set_bg_after_copy_body_result(void *,
				const struct tof_set_bg *, int, unsigned int, int, int,
				void *(*)(int, int),
				int (*)(void *, unsigned long *, unsigned int *,
					unsigned char *),
				void (*)(void *, unsigned char),
				int (*)(const struct tof_set_bg *, unsigned long,
					unsigned int, unsigned int),
				int (*)(void *, int, int),
				void (*)(int, int,
					void (*)(int, int, unsigned long, unsigned long)),
				void (*)(int, int, unsigned long, unsigned long),
				void (*)(int));
			extern int tofu_utofu_unset_bg_after_copy_body_result(
				const struct tof_set_bg *, void *(*)(int, int),
				int (*)(void *));
			extern int tofu_core_register_signal_bg_body_result(
				void (**)(int, int, unsigned long, unsigned long), void *,
				void (*)(int, int, unsigned long, unsigned long),
			unsigned long (*)(void *), void (*)(void *, unsigned long));
		extern int tofu_core_enable_bch_body_result(
			const void *, void *, unsigned long, unsigned long,
			unsigned long, void (*)(unsigned long, void *, long),
			int (*)(void *, long, unsigned long, unsigned long,
				unsigned long));
		extern int tofu_core_bch_disable_locked_body_result(
			const void *, void *, void (*)(unsigned long, void *, long));
		extern int tofu_core_bg_disable_body_result(
			void *, void (*)(unsigned long, void *, long));
		extern int tofu_core_cacheflush_timeout_body_result(
			void *(*)(int, int), void *(*)(void *),
			void (*)(unsigned long, void *, long), void (*)(void),
			void (*)(int, int, int), int, int, int, int, long);
		extern int tofu_core_cq_cacheflush_body_result(
			void *, int, int, void *(*)(void *),
			void (*)(unsigned long, void *, long),
			int (*)(void *, long, unsigned long, unsigned long,
				unsigned long),
			int (*)(void *), void (*)(int, int, int), void (*)(void),
			int, unsigned long, unsigned long, long, long,
			unsigned long);
		extern int tofu_utofu_release_cq_body_result(
			void *, int, int, int, int, void (*)(int, int),
			void (*)(void *, int), void (*)(void *, int),
			void (*)(void *));
		extern int tofu_utofu_alloc_new_steering_body_result(
			void *, int, unsigned long, unsigned long, unsigned char,
			unsigned long, int, unsigned long, unsigned long,
			unsigned long, int, int, int, int,
			int (*)(long, long, unsigned long, unsigned char,
				unsigned long *),
			int (*)(void *, unsigned long, void **, int),
			void (*)(void *, unsigned long, unsigned long),
			unsigned long (*)(void *),
			int (*)(void *, void *, unsigned long, unsigned long,
				unsigned int, unsigned long, int),
			void (*)(void *, void *),
			void (*)(void *, int, unsigned long, unsigned char,
				unsigned long),
			void (*)(void *, int, unsigned long, unsigned long, int),
			void (*)(void *, int, unsigned long, unsigned long,
				unsigned long, unsigned long, unsigned char, void *),
			void (*)(int), unsigned long (*)(void),
			void (*)(int, unsigned long));
		extern int tofu_utofu_ioctl_alloc_stag_body_result(
			void *, unsigned long, int, unsigned int, unsigned long,
			unsigned long, unsigned char, unsigned long,
			void *(*)(void *), void *(*)(void),
			int (*)(struct tof_alloc_stag *, unsigned long),
			int (*)(unsigned long, const struct tof_alloc_stag *),
			int (*)(void *), int (*)(void *, int),
			void (*)(void *), void (*)(void *),
			void *(*)(void *, unsigned long, unsigned long),
			int (*)(void *, unsigned long, unsigned long),
			int (*)(void *, unsigned long),
			int (*)(unsigned long, unsigned long, unsigned char *,
				int),
			void (*)(void *), void (*)(void *),
			int (*)(void *, unsigned long, unsigned long,
				unsigned char, int),
			int (*)(void *, int), void (*)(void *, int),
			int (*)(void *, int, unsigned long, unsigned long,
				unsigned char, unsigned long, int),
			unsigned long (*)(void *, int),
			void (*)(void *, void *, unsigned long, unsigned long,
				void *, int));
		extern int tofu_utofu_disable_bch_body_result(
			unsigned char *, int, int, const unsigned long *, int, int,
			int (*)(int, int), int (*)(int, int), void (*)(int),
			void (*)(void));
		extern int tofu_utofu_bch_device_disable_body_result(
			void *, unsigned long, void (*)(void *), int (*)(void *));
		extern int tofu_utofu_init_globals_body_result(
			void *(*)(void), void (*)(const void *), void (*)(void),
			void (*)(const void *), void (*)(void), void (*)(int, int),
			int, int, void (*)(void));
		extern int tofu_utofu_finalize_body_result(
			void *(*)(void), int (*)(void), void (*)(void),
			void (*)(void), int (*)(void *, void *));
		extern int tofu_utofu_release_fd_body_result(
			unsigned char, void *, const void *, int, int,
			int (*)(const void *), void (*)(void *), void (*)(void *),
			void (*)(int, int, int));
		extern int tofu_utofu_release_fds_body_result(
			unsigned char, void *, int, void (*)(void *, int));
		extern long tofu_utofu_unlocked_ioctl_body_result(
			int, unsigned int, unsigned long, int, void *,
			unsigned int, unsigned int, unsigned int, unsigned int,
			unsigned char, int, int,
			int (*)(void *, unsigned long),
			int (*)(void *, unsigned long),
			int (*)(void *, unsigned long),
			int (*)(void *, unsigned long),
			unsigned long (*)(void),
			void (*)(int, unsigned long), void (*)(int));
		extern int tofu_utofu_free_stags_after_req_copy_body_result(
			void *, struct tof_free_stags *, void *, int *, int,
			int (*)(int *, const int *, unsigned long),
			int (*)(int *, const int *, unsigned long),
			int (*)(void *, const struct tof_free_stags *),
			int (*)(void *, int), void (*)(int), void (*)(int),
			void (*)(void *, unsigned short, int *, int));
		extern int tofu_utofu_free_stag_body_result(
			void *, int, int, int (*)(void *, int),
			int (*)(void *, int), void (*)(void *, int),
			void (*)(void *, int), void (*)(void *, int),
			void (*)(void), void *, void (*)(void *, int),
			int (*)(void *, int), void (*)(void *, int),
			void (*)(void *, int), void (*)(void *, int));
		extern int tofu_utofu_enable_bch_precheck_body_result(
			int, const unsigned char *, int);
		extern int tofu_utofu_enable_bch_request_validate_result(
			const struct tof_enable_bch *, unsigned long,
			unsigned long);
		extern int tofu_utofu_enable_bch_commit_body_result(
			void *, unsigned char *, int, int,
			const struct tof_enable_bch *, unsigned long,
			unsigned long *, int, unsigned long *, int,
			int (*)(int, int, unsigned long),
			int (*)(void *, const struct tof_set_bg *, int, unsigned int),
			int (*)(int, int), int (*)(const struct tof_set_bg *),
			void (*)(int));
		#endif

static void require_at(int cond, int line)
{
	if (!cond) {
		printf("tofu_uapi require failed at line %d\n", line);
		fflush((void *)0);
		abort();
	}
}

#define require(cond) require_at((cond), __LINE__)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static int tofu_atomic_set_count;
static int tofu_lock_count;
static int tofu_unlock_count;
static int tofu_wmb_count;
static unsigned long tofu_last_flags;
static int tofu_lock_token;
static int tofu_bg_unset_count;
static int tofu_bg_unregister_count;
static int tofu_bg_last_tni;
static int tofu_bg_last_bgid;
struct tofu_core_bg_model {
	char bgs_reg;
	unsigned long subnet;
	unsigned int gpid;
};

static struct tofu_core_bg_model tofu_core_bg_slot;
static int tofu_core_bg_get_count;
static int tofu_core_bg_get_null;
static int tofu_core_bg_last_tni;
static int tofu_core_bg_last_bgid;
static int tofu_core_bg_publish_count;
static int tofu_core_bg_lock_count;
static int tofu_core_bg_unlock_count;
static unsigned long tofu_core_bg_last_flags;
static int tofu_core_bg_reset_irqmask_count;
static int tofu_core_bg_reset_irqmask_imc_count;
static int tofu_core_bg_bgs_reg_count;
struct tofu_utofu_bg_model {
	unsigned long subnet;
	unsigned int gpid;
	unsigned char enabled;
};

static struct tofu_utofu_bg_model tofu_utofu_bg_slot;
static char tofu_utofu_ubch_token;
static unsigned long tofu_utofu_bgmask_model[TOF_ICC_NTNIS];
static int tofu_utofu_bg_get_count;
static int tofu_utofu_bg_get_null;
static int tofu_utofu_bg_last_tni;
static int tofu_utofu_bg_last_bgid;
static int tofu_utofu_meta_count;
static int tofu_utofu_meta_result;
static int tofu_utofu_set_enabled_count;
static int tofu_utofu_core_set_count;
static int tofu_utofu_core_set_result;
static const struct tof_set_bg *tofu_utofu_core_set_last_req;
static unsigned long tofu_utofu_core_set_last_subnet;
static unsigned int tofu_utofu_core_set_last_bseq;
static unsigned int tofu_utofu_core_set_last_gpid;
static int tofu_utofu_bgmask_set_count;
static int tofu_utofu_bgmask_set_result;
static int tofu_utofu_register_signal_count;
static int tofu_utofu_register_last_tni;
static int tofu_utofu_register_last_bgid;
static void (*tofu_utofu_register_last_handler)(int, int, unsigned long,
	unsigned long);
static int tofu_utofu_unset_ptr_count;
static int tofu_utofu_unset_ptr_result;
static int tofu_signal_count;
static int tofu_writeq_count;
static unsigned long tofu_writeq_last_val;
static void *tofu_writeq_last_reg;
static long tofu_writeq_last_offset;
static unsigned long tofu_writeq_values[8];
static void *tofu_writeq_regs[8];
static long tofu_writeq_offsets[8];
static int tofu_readq_spin_count;
static int tofu_readq_spin_result;
static void *tofu_readq_spin_last_reg;
static long tofu_readq_spin_last_offset;
static unsigned long tofu_readq_spin_last_mask;
static unsigned long tofu_readq_spin_last_expect;
static unsigned long tofu_readq_spin_last_timeout;
struct tofu_core_cq_model {
	void *cqs;
	int tni;
	int cqid;
};
static struct tofu_core_cq_model tofu_cacheflush_cq[TOF_ICC_NTNIS][TOF_ICC_NCQS];
static int tofu_cacheflush_get_count;
static int tofu_cacheflush_get_null;
static int tofu_cacheflush_reg_count;
static int tofu_cacheflush_log_count;
static int tofu_cacheflush_log_events[16];
static int tofu_cacheflush_log_tni[16];
static int tofu_cacheflush_log_cqid[16];
static int tofu_cacheflush_timeout_count;
static int tofu_cacheflush_timeout_result;
static void *tofu_cacheflush_timeout_arg;
static int tofu_cacheflush_panic_count;
static int tofu_cacheflush_read_count;
static int tofu_cacheflush_read_results[4];
static void *tofu_cacheflush_read_reg[4];
static long tofu_cacheflush_read_offset[4];
static unsigned long tofu_cacheflush_read_mask[4];
static unsigned long tofu_cacheflush_read_expect[4];
static unsigned long tofu_cacheflush_read_timeout[4];
static int tofu_disable_bch_count;
static int tofu_disable_bch_result;
static int tofu_disable_bch_last_tni;
static int tofu_disable_bch_last_bgid;
static int tofu_unset_by_id_count;
static int tofu_unset_by_id_order[16];
static int tofu_unset_by_id_fail_tni;
static int tofu_unset_by_id_fail_bgid;
static int tofu_error_log_count;
static int tofu_error_log_last;
static int tofu_bch_device_log_count;
static int tofu_bch_device_disable_count;
static int tofu_bch_device_disable_result;
static void *tofu_bch_device_expected_bg;
static void *tofu_bch_device_last_log_bg;
static void *tofu_bch_device_last_disable_bg;
static struct tofu_globals tofu_globals_slot;
static int tofu_get_globals_count;
static int tofu_get_globals_null;
static int tofu_init_publish_count;
static int tofu_init_unavailable_log_count;
static int tofu_init_globals_log_count;
static int tofu_init_clear_caches_count;
static int tofu_init_lock_count;
static int tofu_init_lock_order[96];
static int tofu_init_done_log_count;
static int tofu_finalize_current_enabled;
static int tofu_finalize_current_count;
static int tofu_finalize_scan_count;
static int tofu_finalize_scan_done_count;
static int tofu_finalize_clear_count;
static void *tofu_finalize_clear_start;
static void *tofu_finalize_clear_end;
static int tofu_finalize_clear_result;
static int tofu_release_kind_result;
static int tofu_release_cq_count;
static int tofu_release_bch_count;
static int tofu_release_log_count;
static int tofu_release_last_pid;
static int tofu_release_last_fd;
static int tofu_release_last_kind;
static int tofu_release_fd_count;
static int tofu_release_fd_order[16];
static int tofu_release_cq_disabled_log_count;
static int tofu_release_cq_disabled_tni;
static int tofu_release_cq_disabled_cqid;
static int tofu_release_cq_drain_count;
static int tofu_release_cq_drain_do_free;
static int tofu_release_cq_free_count;
static int tofu_release_cq_free_order[16];
static int tofu_release_cq_done_count;
struct tofu_alloc_new_mbpt_model {
	unsigned long mbptstart;
	unsigned long pgsz;
	unsigned long iova;
};
static struct tofu_alloc_new_mbpt_model tofu_alloc_new_mbpt;
static int tofu_alloc_new_calc_count;
static int tofu_alloc_new_calc_result;
static unsigned long tofu_alloc_new_calc_mbptstart;
static unsigned long tofu_alloc_new_calc_mbpt_npages;
static int tofu_alloc_new_alloc_count;
static int tofu_alloc_new_alloc_result;
static int tofu_alloc_new_alloc_stag;
static unsigned long tofu_alloc_new_alloc_npages;
static int tofu_alloc_new_null_mbpt;
static int tofu_alloc_new_set_meta_count;
static int tofu_alloc_new_update_count;
static int tofu_alloc_new_update_result;
static unsigned long tofu_alloc_new_update_start;
static unsigned long tofu_alloc_new_update_end;
static unsigned int tofu_alloc_new_update_ix;
static unsigned long tofu_alloc_new_update_pgsz;
static int tofu_alloc_new_update_readonly;
static int tofu_alloc_new_free_count;
static int tofu_alloc_new_enable_mb_count;
static unsigned long tofu_alloc_new_enable_mb_iova;
static unsigned char tofu_alloc_new_enable_mb_pgszbits;
static unsigned long tofu_alloc_new_enable_mb_npages;
static int tofu_alloc_new_enable_steering_count;
static unsigned long tofu_alloc_new_enable_steering_mbva;
static unsigned long tofu_alloc_new_enable_steering_len;
static int tofu_alloc_new_enable_steering_readonly;
static int tofu_alloc_new_trans_enable_count;
static unsigned long tofu_alloc_new_trans_start;
static unsigned long tofu_alloc_new_trans_len;
static unsigned long tofu_alloc_new_trans_mbptstart;
static unsigned long tofu_alloc_new_trans_mbptlen;
static int tofu_alloc_new_raw_rc_count;
static int tofu_alloc_new_raw_rc_last;
static unsigned long tofu_alloc_new_timestamp_value;
static int tofu_alloc_new_timestamp_count;
static int tofu_alloc_new_profile_count;
static int tofu_alloc_new_profile_events[4];
static unsigned long tofu_alloc_new_profile_elapsed[4];
static struct tof_alloc_stag tofu_alloc_stag_req;
static struct tof_alloc_stag tofu_alloc_stag_out;
static int tofu_alloc_stag_dev_to_cq_count;
static int tofu_alloc_stag_dev_to_cq_null;
static int tofu_alloc_stag_current_vm_count;
static int tofu_alloc_stag_current_vm_null;
static int tofu_alloc_stag_copyin_count;
static int tofu_alloc_stag_copyin_result;
static int tofu_alloc_stag_copyout_count;
static int tofu_alloc_stag_copyout_result;
static int tofu_alloc_stag_ucq_enabled;
static int tofu_alloc_stag_ucq_enabled_count;
static int tofu_alloc_stag_steering_count;
static int tofu_alloc_stag_steering_stag;
static int tofu_alloc_stag_steering_result;
static int tofu_alloc_stag_steering_after_count;
static int tofu_alloc_stag_steering_after_result;
static int tofu_alloc_stag_vm_lock_count;
static int tofu_alloc_stag_vm_unlock_count;
static int tofu_alloc_stag_lookup_count;
static int tofu_alloc_stag_lookup_failures;
static unsigned long tofu_alloc_stag_lookup_start[4];
static unsigned long tofu_alloc_stag_lookup_end[4];
static int tofu_alloc_stag_stack_faultable;
static int tofu_alloc_stag_stack_count;
static int tofu_alloc_stag_page_fault_count;
static int tofu_alloc_stag_page_fault_result;
static int tofu_alloc_stag_pagesize_count;
static unsigned char tofu_alloc_stag_pagesize_bits;
static int tofu_alloc_stag_pagesize_result;
static int tofu_alloc_stag_pagesize_readonly;
static int tofu_alloc_stag_cq_lock_count;
static int tofu_alloc_stag_cq_unlock_count;
static int tofu_alloc_stag_trans_count;
static int tofu_alloc_stag_trans_result;
static unsigned long tofu_alloc_stag_trans_start;
static unsigned long tofu_alloc_stag_trans_end;
static unsigned char tofu_alloc_stag_trans_pgszbits;
static int tofu_alloc_stag_trans_readonly;
static int tofu_alloc_stag_reserve_count;
static int tofu_alloc_stag_reserve_result;
static int tofu_alloc_stag_reserve_readonly;
static int tofu_alloc_stag_release_count;
static int tofu_alloc_stag_release_stag;
static int tofu_alloc_stag_alloc_new_count;
static int tofu_alloc_stag_alloc_new_result;
static int tofu_alloc_stag_alloc_new_stag;
static unsigned long tofu_alloc_stag_alloc_new_start;
static unsigned long tofu_alloc_stag_alloc_new_end;
static unsigned char tofu_alloc_stag_alloc_new_pgszbits;
static unsigned long tofu_alloc_stag_alloc_new_plus_mbva;
static int tofu_alloc_stag_alloc_new_readonly;
static int tofu_alloc_stag_get_mbpt_count;
static unsigned long tofu_alloc_stag_mbpt_start;
static int tofu_alloc_stag_range_insert_count;
static unsigned long tofu_alloc_stag_range_start;
static unsigned long tofu_alloc_stag_range_end;
static int tofu_alloc_stag_range_stag;
static int tofu_ioctl_call_count;
static int tofu_ioctl_last_kind;
static unsigned long tofu_ioctl_last_arg;
static int tofu_ioctl_results[4];
static int tofu_ioctl_timestamp_count;
static unsigned long tofu_ioctl_timestamp_value;
static int tofu_ioctl_profile_count;
static int tofu_ioctl_profile_last_event;
static unsigned long tofu_ioctl_profile_last_delta;
static int tofu_ioctl_unknown_count;
static int tofu_ioctl_unknown_last_fd;
static int tofu_free_stags_copyin_count;
static int tofu_free_stags_copyout_count;
static int tofu_free_stags_reqout_count;
static int tofu_free_stags_free_count;
static int tofu_free_stags_remove_count;
static int tofu_free_stags_log_count;
static int tofu_free_stags_copyin_fail;
static int tofu_free_stags_copyout_fail;
static int tofu_free_stags_reqout_fail;
static int tofu_free_stags_results[8];
static int tofu_free_stags_free_order[8];
static int tofu_free_stags_remove_order[8];
static unsigned short tofu_free_stags_log_num;
static int *tofu_free_stags_log_stags;
static int tofu_free_stags_log_no_free;
static int tofu_free_stag_enabled_result;
static int tofu_free_stag_kref_result;
static int tofu_free_stag_cacheflush_result;
static int tofu_free_stag_enabled_count;
static int tofu_free_stag_kref_count;
static int tofu_free_stag_non_mckernel_log_count;
static int tofu_free_stag_disable_count;
static int tofu_free_stag_trans_disable_count;
static int tofu_free_stag_wmb_count;
static int tofu_free_stag_profile_count;
static int tofu_free_stag_cacheflush_count;
static int tofu_free_stag_kref_put_count;
static int tofu_free_stag_clear_count;
static int tofu_free_stag_dealloc_log_count;
static int tofu_free_stag_order[16];
static int tofu_free_stag_order_count;
static int tofu_free_stag_profile_order[8];
static int tofu_free_stag_last_stag;
static const struct tof_set_bg *tofu_enable_bgs_base;
static int tofu_enable_call_count;
static int tofu_enable_result;
static int tofu_enable_last_tni;
static int tofu_enable_last_bgid;
static unsigned long tofu_enable_last_ipa;
static int tofu_set_bg_count;
static int tofu_set_bg_fail_index;
static int tofu_set_bg_order[8];
static int tofu_set_bg_last_kuid;
static unsigned int tofu_set_bg_last_bseq;
static int tofu_commit_disable_count;
static int tofu_commit_disable_last_tni;
static int tofu_commit_disable_last_bgid;
static int tofu_unset_user_count;
static int tofu_unset_user_order[8];

static void tofu_fake_atomic_set(void *slot, unsigned long value)
{
	*(unsigned long *)slot = value;
	++tofu_atomic_set_count;
}

static unsigned long tofu_fake_lock(void *lock)
{
	require(lock == &tofu_lock_token);
	tofu_last_flags = 0xa500UL + (unsigned long)tofu_lock_count;
	++tofu_lock_count;
	return tofu_last_flags;
}

static void tofu_fake_unlock(void *lock, unsigned long flags)
{
	require(lock == &tofu_lock_token);
	require(flags == tofu_last_flags);
	++tofu_unlock_count;
}

static void tofu_fake_wmb(void)
{
	++tofu_wmb_count;
}

static void *tofu_fake_core_bg_get(int tni, int bgid)
{
	tofu_core_bg_last_tni = tni;
	tofu_core_bg_last_bgid = bgid;
	++tofu_core_bg_get_count;
	if (tofu_core_bg_get_null)
		return 0;
	return &tofu_core_bg_slot;
}

static void tofu_fake_core_bg_publish(void *bg, unsigned long subnet,
	unsigned int gpid)
{
	require(bg == &tofu_core_bg_slot);
	tofu_core_bg_slot.subnet = subnet;
	tofu_core_bg_slot.gpid = gpid;
	++tofu_core_bg_publish_count;
}

static unsigned long tofu_fake_core_bg_lock(void *bg)
{
	require(bg == &tofu_core_bg_slot);
	tofu_core_bg_last_flags = 0xc0de0000UL +
		(unsigned long)tofu_core_bg_lock_count;
	++tofu_core_bg_lock_count;
	return tofu_core_bg_last_flags;
}

static void tofu_fake_core_bg_unlock(void *bg, unsigned long flags)
{
	require(bg == &tofu_core_bg_slot);
	require(flags == tofu_core_bg_last_flags);
	++tofu_core_bg_unlock_count;
}

static void tofu_fake_core_bg_reset_irqmask(void *bg)
{
	require(bg == &tofu_core_bg_slot);
	++tofu_core_bg_reset_irqmask_count;
}

static void tofu_fake_core_bg_reset_irqmask_imc(void *bg)
{
	require(bg == &tofu_core_bg_slot);
	++tofu_core_bg_reset_irqmask_imc_count;
}

static void *tofu_fake_core_bg_bgs_reg(void *bg)
{
	require(bg == &tofu_core_bg_slot);
	++tofu_core_bg_bgs_reg_count;
	return &tofu_core_bg_slot.bgs_reg;
}

static void tofu_reset_core_bg_fakes(void)
{
	tofu_core_bg_slot.bgs_reg = 0;
	tofu_core_bg_slot.subnet = 0;
	tofu_core_bg_slot.gpid = 0;
	tofu_core_bg_get_count = 0;
	tofu_core_bg_get_null = 0;
	tofu_core_bg_last_tni = 0;
	tofu_core_bg_last_bgid = 0;
	tofu_core_bg_publish_count = 0;
	tofu_core_bg_lock_count = 0;
	tofu_core_bg_unlock_count = 0;
	tofu_core_bg_last_flags = 0;
	tofu_core_bg_reset_irqmask_count = 0;
	tofu_core_bg_reset_irqmask_imc_count = 0;
	tofu_core_bg_bgs_reg_count = 0;
	tofu_writeq_count = 0;
	tofu_wmb_count = 0;
	tofu_readq_spin_count = 0;
	tofu_readq_spin_result = 1;
}

static void tofu_reset_utofu_set_bg_fakes(void)
{
	int i;

	tofu_utofu_bg_slot.subnet = 0;
	tofu_utofu_bg_slot.gpid = 0;
	tofu_utofu_bg_slot.enabled = 0;
	for (i = 0; i < TOF_ICC_NTNIS; ++i)
		tofu_utofu_bgmask_model[i] = 0;
	tofu_utofu_bg_get_count = 0;
	tofu_utofu_bg_get_null = 0;
	tofu_utofu_bg_last_tni = 0;
	tofu_utofu_bg_last_bgid = 0;
	tofu_utofu_meta_count = 0;
	tofu_utofu_meta_result = 0;
	tofu_utofu_set_enabled_count = 0;
	tofu_utofu_core_set_count = 0;
	tofu_utofu_core_set_result = 0;
	tofu_utofu_core_set_last_req = 0;
	tofu_utofu_core_set_last_subnet = 0;
	tofu_utofu_core_set_last_bseq = 0;
	tofu_utofu_core_set_last_gpid = 0;
	tofu_utofu_bgmask_set_count = 0;
	tofu_utofu_bgmask_set_result = 0;
	tofu_utofu_register_signal_count = 0;
	tofu_utofu_register_last_tni = 0;
	tofu_utofu_register_last_bgid = 0;
	tofu_utofu_register_last_handler = 0;
	tofu_utofu_unset_ptr_count = 0;
	tofu_utofu_unset_ptr_result = 0;
	tofu_error_log_count = 0;
	tofu_error_log_last = 0;
}

static void *tofu_fake_utofu_bg_get(int tni, int bgid)
{
	tofu_utofu_bg_last_tni = tni;
	tofu_utofu_bg_last_bgid = bgid;
	++tofu_utofu_bg_get_count;
	if (tofu_utofu_bg_get_null)
		return 0;
	return &tofu_utofu_bg_slot;
}

static int tofu_fake_utofu_meta(void *bg, unsigned long *subnet,
	unsigned int *gpid, unsigned char *enabled)
{
	require(bg == &tofu_utofu_bg_slot);
	++tofu_utofu_meta_count;
	if (tofu_utofu_meta_result < 0)
		return tofu_utofu_meta_result;
	*subnet = tofu_utofu_bg_slot.subnet;
	*gpid = tofu_utofu_bg_slot.gpid;
	*enabled = tofu_utofu_bg_slot.enabled;
	return 0;
}

static void tofu_fake_utofu_set_enabled(void *bg, unsigned char enabled)
{
	require(bg == &tofu_utofu_bg_slot);
	tofu_utofu_bg_slot.enabled = enabled;
	++tofu_utofu_set_enabled_count;
}

static int tofu_fake_utofu_core_set_bg(const struct tof_set_bg *req,
	unsigned long subnet, unsigned int bseq, unsigned int gpid)
{
	tofu_utofu_core_set_last_req = req;
	tofu_utofu_core_set_last_subnet = subnet;
	tofu_utofu_core_set_last_bseq = bseq;
	tofu_utofu_core_set_last_gpid = gpid;
	++tofu_utofu_core_set_count;
	return tofu_utofu_core_set_result;
}

static int tofu_fake_utofu_bgmask_set(void *ubch, int tni, int bgid)
{
	require(ubch == &tofu_utofu_ubch_token);
	++tofu_utofu_bgmask_set_count;
	if (tofu_utofu_bgmask_set_result < 0)
		return tofu_utofu_bgmask_set_result;
	if ((unsigned int)tni >= TOF_ICC_NTNIS ||
	    (unsigned int)bgid >= TOF_ICC_NBGS)
		return -22;
	tofu_utofu_bgmask_model[tni] |= 1UL << bgid;
	return 0;
}

static void tofu_fake_utofu_register_signal(int tni, int bgid,
	void (*handler)(int, int, unsigned long, unsigned long))
{
	tofu_utofu_register_last_tni = tni;
	tofu_utofu_register_last_bgid = bgid;
	tofu_utofu_register_last_handler = handler;
	++tofu_utofu_register_signal_count;
}

static int tofu_fake_utofu_unset_ptr(void *bg)
{
	require(bg == &tofu_utofu_bg_slot);
	++tofu_utofu_unset_ptr_count;
	return tofu_utofu_unset_ptr_result;
}

static void tofu_fake_signal(int tni, int bgid, unsigned long irr,
	unsigned long data)
{
	(void)tni;
	(void)bgid;
	(void)irr;
	(void)data;
	++tofu_signal_count;
}

static void tofu_fake_writeq(unsigned long val, void *reg, long offset)
{
	if (tofu_writeq_count < 8) {
		tofu_writeq_values[tofu_writeq_count] = val;
		tofu_writeq_regs[tofu_writeq_count] = reg;
		tofu_writeq_offsets[tofu_writeq_count] = offset;
	}
	tofu_writeq_last_val = val;
	tofu_writeq_last_reg = reg;
	tofu_writeq_last_offset = offset;
	++tofu_writeq_count;
}

static int tofu_fake_readq_spin(void *reg, long offset, unsigned long mask,
	unsigned long expect, unsigned long timeout)
{
	tofu_readq_spin_last_reg = reg;
	tofu_readq_spin_last_offset = offset;
	tofu_readq_spin_last_mask = mask;
	tofu_readq_spin_last_expect = expect;
	tofu_readq_spin_last_timeout = timeout;
	++tofu_readq_spin_count;
	return tofu_readq_spin_result;
}

static void tofu_reset_cacheflush_fakes(void)
{
	int i;
	int j;

	for (i = 0; i < TOF_ICC_NTNIS; ++i) {
		for (j = 0; j < TOF_ICC_NCQS; ++j) {
			tofu_cacheflush_cq[i][j].cqs =
				(void *)(0xc0000000UL + (unsigned long)i * 0x1000UL +
					(unsigned long)j * 0x100UL);
			tofu_cacheflush_cq[i][j].tni = i;
			tofu_cacheflush_cq[i][j].cqid = j;
		}
	}
	tofu_cacheflush_get_count = 0;
	tofu_cacheflush_get_null = 0;
	tofu_cacheflush_reg_count = 0;
	tofu_cacheflush_log_count = 0;
	for (i = 0; i < 16; ++i) {
		tofu_cacheflush_log_events[i] = 0;
		tofu_cacheflush_log_tni[i] = 0;
		tofu_cacheflush_log_cqid[i] = 0;
	}
	tofu_cacheflush_timeout_count = 0;
	tofu_cacheflush_timeout_result = 0;
	tofu_cacheflush_timeout_arg = 0;
	tofu_cacheflush_panic_count = 0;
	tofu_cacheflush_read_count = 0;
	for (i = 0; i < 4; ++i) {
		tofu_cacheflush_read_results[i] = 1;
		tofu_cacheflush_read_reg[i] = 0;
		tofu_cacheflush_read_offset[i] = 0;
		tofu_cacheflush_read_mask[i] = 0;
		tofu_cacheflush_read_expect[i] = 0;
		tofu_cacheflush_read_timeout[i] = 0;
	}
	tofu_writeq_count = 0;
	tofu_writeq_last_val = 0;
	tofu_writeq_last_reg = 0;
	tofu_writeq_last_offset = 0;
	tofu_wmb_count = 0;
}

static void *tofu_fake_cacheflush_get_cq(int tni, int cqid)
{
	++tofu_cacheflush_get_count;
	if (tofu_cacheflush_get_null)
		return 0;
	require((unsigned int)tni < TOF_ICC_NTNIS);
	require((unsigned int)cqid < TOF_ICC_NCQS);
	return &tofu_cacheflush_cq[tni][cqid];
}

static void *tofu_fake_cacheflush_cqs_reg(void *cq)
{
	struct tofu_core_cq_model *model = cq;

	++tofu_cacheflush_reg_count;
	return model->cqs;
}

static int tofu_fake_cacheflush_readq_spin(void *reg, long offset,
	unsigned long mask, unsigned long expect, unsigned long timeout)
{
	int index = tofu_cacheflush_read_count;

	if (index < 4) {
		tofu_cacheflush_read_reg[index] = reg;
		tofu_cacheflush_read_offset[index] = offset;
		tofu_cacheflush_read_mask[index] = mask;
		tofu_cacheflush_read_expect[index] = expect;
		tofu_cacheflush_read_timeout[index] = timeout;
	}
	++tofu_cacheflush_read_count;
	if (index < 4)
		return tofu_cacheflush_read_results[index];
	return 1;
}

static int tofu_fake_cacheflush_timeout(void *cq)
{
	tofu_cacheflush_timeout_arg = cq;
	++tofu_cacheflush_timeout_count;
	return tofu_cacheflush_timeout_result;
}

static void tofu_fake_cacheflush_log(int event, int tni, int cqid)
{
	if (tofu_cacheflush_log_count < 16) {
		tofu_cacheflush_log_events[tofu_cacheflush_log_count] = event;
		tofu_cacheflush_log_tni[tofu_cacheflush_log_count] = tni;
		tofu_cacheflush_log_cqid[tofu_cacheflush_log_count] = cqid;
	}
	++tofu_cacheflush_log_count;
}

static void tofu_fake_cacheflush_panic(void)
{
	++tofu_cacheflush_panic_count;
}

static int tofu_fake_disable_bch(int tni, int bgid)
{
	tofu_disable_bch_last_tni = tni;
	tofu_disable_bch_last_bgid = bgid;
	++tofu_disable_bch_count;
	return tofu_disable_bch_result;
}

static int tofu_fake_unset_bg_by_id(int tni, int bgid)
{
	if (tofu_unset_by_id_count < 16)
		tofu_unset_by_id_order[tofu_unset_by_id_count] =
			tni * 64 + bgid;
	++tofu_unset_by_id_count;
	if (tni == tofu_unset_by_id_fail_tni &&
	    bgid == tofu_unset_by_id_fail_bgid)
		return -77;
	return 0;
}

static void tofu_fake_error_log(int ret)
{
	tofu_error_log_last = ret;
	++tofu_error_log_count;
}

static void tofu_fake_bch_device_log(void *bg)
{
	require(bg == tofu_bch_device_expected_bg);
	tofu_bch_device_last_log_bg = bg;
	++tofu_bch_device_log_count;
}

static int tofu_fake_bch_device_disable(void *bg)
{
	require(bg == tofu_bch_device_expected_bg);
	require(tofu_bch_device_log_count == 1);
	tofu_bch_device_last_disable_bg = bg;
	++tofu_bch_device_disable_count;
	return tofu_bch_device_disable_result;
}

static void tofu_reset_lifecycle_fakes(void)
{
	int i;

	tofu_globals_slot.tof_ib_stag_lock_addr = 0x1010UL;
	tofu_globals_slot.tof_ib_stag_list_addr = 0x2020UL;
	tofu_globals_slot.tof_ib_stag_list_Rp_addr = 0x3030UL;
	tofu_globals_slot.tof_ib_stag_list_Wp_addr = 0x4040UL;
	tofu_globals_slot.tof_ib_mbpt_mem_addr = 0x5050UL;
	tofu_globals_slot.tof_ib_steering_addr = 0x6060UL;
	tofu_globals_slot.tof_ib_mb_addr = 0x7070UL;
	tofu_globals_slot.tof_core_cq_addr = 0x8080UL;
	tofu_globals_slot.tof_core_bg_addr = 0x9090UL;
	tofu_globals_slot.tof_utofu_bg_addr = 0xa0a0UL;
	tofu_globals_slot.tof_utofu_handler_bg_signal_addr = 0xb0b0UL;
	tofu_globals_slot.linux_vmalloc_start = 0xaaaa0000UL;
	tofu_globals_slot.linux_vmalloc_end = 0xaaaa9000UL;
	tofu_get_globals_count = 0;
	tofu_get_globals_null = 0;
	tofu_init_publish_count = 0;
	tofu_init_unavailable_log_count = 0;
	tofu_init_globals_log_count = 0;
	tofu_init_clear_caches_count = 0;
	tofu_init_lock_count = 0;
	for (i = 0; i < 96; ++i)
		tofu_init_lock_order[i] = 0;
	tofu_init_done_log_count = 0;
	tofu_finalize_current_enabled = 0;
	tofu_finalize_current_count = 0;
	tofu_finalize_scan_count = 0;
	tofu_finalize_scan_done_count = 0;
	tofu_finalize_clear_count = 0;
	tofu_finalize_clear_start = 0;
	tofu_finalize_clear_end = 0;
	tofu_finalize_clear_result = 0;
}

static void *tofu_fake_get_globals(void)
{
	++tofu_get_globals_count;
	if (tofu_get_globals_null)
		return 0;
	return &tofu_globals_slot;
}

static void tofu_fake_init_publish(const void *globals)
{
	require(globals == &tofu_globals_slot);
	++tofu_init_publish_count;
}

static void tofu_fake_init_unavailable_log(void)
{
	++tofu_init_unavailable_log_count;
}

static void tofu_fake_init_globals_log(const void *globals)
{
	require(globals == &tofu_globals_slot);
	require(tofu_init_publish_count == 1);
	++tofu_init_globals_log_count;
}

static void tofu_fake_init_clear_caches(void)
{
	require(tofu_init_globals_log_count == 1);
	++tofu_init_clear_caches_count;
}

static void tofu_fake_init_lock(int tni, int cq)
{
	require(tofu_init_clear_caches_count == 1);
	if (tofu_init_lock_count < 96)
		tofu_init_lock_order[tofu_init_lock_count] = tni * 16 + cq;
	++tofu_init_lock_count;
}

static void tofu_fake_init_done_log(void)
{
	require(tofu_init_lock_count > 0);
	++tofu_init_done_log_count;
}

static int tofu_fake_finalize_current_enabled(void)
{
	++tofu_finalize_current_count;
	return tofu_finalize_current_enabled;
}

static void tofu_fake_finalize_scan(void)
{
	require(tofu_finalize_current_count == 1);
	++tofu_finalize_scan_count;
}

static void tofu_fake_finalize_scan_done(void)
{
	require(tofu_finalize_scan_count == 1);
	++tofu_finalize_scan_done_count;
}

static int tofu_fake_finalize_clear_range(void *start, void *end)
{
	tofu_finalize_clear_start = start;
	tofu_finalize_clear_end = end;
	++tofu_finalize_clear_count;
	return tofu_finalize_clear_result;
}

static int tofu_fake_path_kind(const void *path)
{
	require(path == (const void *)0xabc0UL ||
		path == (const void *)0xabc1UL ||
		path == (const void *)0xabc2UL);
	return tofu_release_kind_result;
}

static void tofu_fake_release_cq(void *data)
{
	require(data == (void *)0xdef0UL);
	++tofu_release_cq_count;
}

static void tofu_fake_release_bch(void *data)
{
	require(data == (void *)0xdef0UL);
	++tofu_release_bch_count;
}

static void tofu_fake_release_log(int pid, int fd, int kind)
{
	tofu_release_last_pid = pid;
	tofu_release_last_fd = fd;
	tofu_release_last_kind = kind;
	++tofu_release_log_count;
}

static void tofu_fake_release_fd(void *proc, int fd)
{
	require(proc == (void *)0xfeed0000UL);
	if (tofu_release_fd_count < 16)
		tofu_release_fd_order[tofu_release_fd_count] = fd;
	++tofu_release_fd_count;
}

static void tofu_reset_release_cq_fakes(void)
{
	int i;

	tofu_release_cq_disabled_log_count = 0;
	tofu_release_cq_disabled_tni = 0;
	tofu_release_cq_disabled_cqid = 0;
	tofu_release_cq_drain_count = 0;
	tofu_release_cq_drain_do_free = -1;
	tofu_release_cq_free_count = 0;
	for (i = 0; i < 16; ++i)
		tofu_release_cq_free_order[i] = -1;
	tofu_release_cq_done_count = 0;
}

static void tofu_fake_release_cq_disabled_log(int tni, int cqid)
{
	tofu_release_cq_disabled_tni = tni;
	tofu_release_cq_disabled_cqid = cqid;
	++tofu_release_cq_disabled_log_count;
}

static void tofu_fake_release_cq_drain(void *ucq, int do_free)
{
	require(ucq == (void *)0xbeef0000UL);
	tofu_release_cq_drain_do_free = do_free;
	++tofu_release_cq_drain_count;
}

static void tofu_fake_release_cq_free_stag(void *ucq, int stag)
{
	require(ucq == (void *)0xbeef0000UL);
	if (tofu_release_cq_free_count < 16)
		tofu_release_cq_free_order[tofu_release_cq_free_count] = stag;
	++tofu_release_cq_free_count;
}

static void tofu_fake_release_cq_done(void *ucq)
{
	require(ucq == (void *)0xbeef0000UL);
	++tofu_release_cq_done_count;
}

static void tofu_reset_alloc_new_fakes(void)
{
	int i;

	tofu_alloc_new_mbpt.mbptstart = 0;
	tofu_alloc_new_mbpt.pgsz = 0;
	tofu_alloc_new_mbpt.iova = 0x44440000UL;
	tofu_alloc_new_calc_count = 0;
	tofu_alloc_new_calc_result = 0;
	tofu_alloc_new_calc_mbptstart = 0x100000UL;
	tofu_alloc_new_calc_mbpt_npages = 0;
	tofu_alloc_new_alloc_count = 0;
	tofu_alloc_new_alloc_result = 0;
	tofu_alloc_new_alloc_stag = 0;
	tofu_alloc_new_alloc_npages = 0;
	tofu_alloc_new_null_mbpt = 0;
	tofu_alloc_new_set_meta_count = 0;
	tofu_alloc_new_update_count = 0;
	tofu_alloc_new_update_result = 0;
	tofu_alloc_new_update_start = 0;
	tofu_alloc_new_update_end = 0;
	tofu_alloc_new_update_ix = 0;
	tofu_alloc_new_update_pgsz = 0;
	tofu_alloc_new_update_readonly = 0;
	tofu_alloc_new_free_count = 0;
	tofu_alloc_new_enable_mb_count = 0;
	tofu_alloc_new_enable_mb_iova = 0;
	tofu_alloc_new_enable_mb_pgszbits = 0;
	tofu_alloc_new_enable_mb_npages = 0;
	tofu_alloc_new_enable_steering_count = 0;
	tofu_alloc_new_enable_steering_mbva = 0;
	tofu_alloc_new_enable_steering_len = 0;
	tofu_alloc_new_enable_steering_readonly = 0;
	tofu_alloc_new_trans_enable_count = 0;
	tofu_alloc_new_trans_start = 0;
	tofu_alloc_new_trans_len = 0;
	tofu_alloc_new_trans_mbptstart = 0;
	tofu_alloc_new_trans_mbptlen = 0;
	tofu_alloc_new_raw_rc_count = 0;
	tofu_alloc_new_raw_rc_last = 0;
	tofu_alloc_new_timestamp_value = 1000;
	tofu_alloc_new_timestamp_count = 0;
	tofu_alloc_new_profile_count = 0;
	for (i = 0; i < 4; ++i) {
		tofu_alloc_new_profile_events[i] = 0;
		tofu_alloc_new_profile_elapsed[i] = 0;
	}
}

static int tofu_fake_alloc_new_calc(long start, long end,
	unsigned long mbpt_npages, unsigned char pgszbits,
	unsigned long *mbptstart)
{
	require(start == 0x101234UL);
	require(end == 0x109234UL);
	require(pgszbits == 12);
	tofu_alloc_new_calc_mbpt_npages = mbpt_npages;
	++tofu_alloc_new_calc_count;
	if (tofu_alloc_new_calc_result < 0)
		return tofu_alloc_new_calc_result;
	*mbptstart = tofu_alloc_new_calc_mbptstart;
	return 0;
}

static int tofu_fake_alloc_new_alloc_mbpt(void *ucq,
	unsigned long mbpt_npages, void **pmbpt, int stag)
{
	require(ucq == (void *)0xbeef0000UL);
	tofu_alloc_new_alloc_npages = mbpt_npages;
	tofu_alloc_new_alloc_stag = stag;
	++tofu_alloc_new_alloc_count;
	if (tofu_alloc_new_alloc_result < 0)
		return tofu_alloc_new_alloc_result;
	*pmbpt = tofu_alloc_new_null_mbpt ? 0 : &tofu_alloc_new_mbpt;
	return 0;
}

static void tofu_fake_alloc_new_set_meta(void *mbpt, unsigned long mbptstart,
	unsigned long pgsz)
{
	require(mbpt == &tofu_alloc_new_mbpt);
	tofu_alloc_new_mbpt.mbptstart = mbptstart;
	tofu_alloc_new_mbpt.pgsz = pgsz;
	++tofu_alloc_new_set_meta_count;
}

static unsigned long tofu_fake_alloc_new_iova(void *mbpt)
{
	require(mbpt == &tofu_alloc_new_mbpt);
	return tofu_alloc_new_mbpt.iova;
}

static int tofu_fake_alloc_new_update(void *ucq, void *mbpt,
	unsigned long start, unsigned long end, unsigned int ix,
	unsigned long pgsz, int readonly)
{
	require(ucq == (void *)0xbeef0000UL);
	require(mbpt == &tofu_alloc_new_mbpt);
	tofu_alloc_new_update_start = start;
	tofu_alloc_new_update_end = end;
	tofu_alloc_new_update_ix = ix;
	tofu_alloc_new_update_pgsz = pgsz;
	tofu_alloc_new_update_readonly = readonly;
	++tofu_alloc_new_update_count;
	return tofu_alloc_new_update_result;
}

static void tofu_fake_alloc_new_free(void *ucq, void *mbpt)
{
	require(ucq == (void *)0xbeef0000UL);
	require(mbpt == &tofu_alloc_new_mbpt);
	++tofu_alloc_new_free_count;
}

static void tofu_fake_alloc_new_enable_mb(void *ucq, int stag,
	unsigned long iova, unsigned char pgszbits, unsigned long mbpt_npages)
{
	require(ucq == (void *)0xbeef0000UL);
	require(stag == 9);
	tofu_alloc_new_enable_mb_iova = iova;
	tofu_alloc_new_enable_mb_pgszbits = pgszbits;
	tofu_alloc_new_enable_mb_npages = mbpt_npages;
	++tofu_alloc_new_enable_mb_count;
}

static void tofu_fake_alloc_new_enable_steering(void *ucq, int stag,
	unsigned long mbva, unsigned long length, int readonly)
{
	require(ucq == (void *)0xbeef0000UL);
	require(stag == 9);
	tofu_alloc_new_enable_steering_mbva = mbva;
	tofu_alloc_new_enable_steering_len = length;
	tofu_alloc_new_enable_steering_readonly = readonly;
	++tofu_alloc_new_enable_steering_count;
}

static void tofu_fake_alloc_new_trans_enable(void *ucq, int stag,
	unsigned long start, unsigned long len, unsigned long mbptstart,
	unsigned long mbptlen, unsigned char pgszbits, void *mbpt)
{
	require(ucq == (void *)0xbeef0000UL);
	require(stag == 9);
	require(mbpt == &tofu_alloc_new_mbpt);
	require(pgszbits == 12);
	tofu_alloc_new_trans_start = start;
	tofu_alloc_new_trans_len = len;
	tofu_alloc_new_trans_mbptstart = mbptstart;
	tofu_alloc_new_trans_mbptlen = mbptlen;
	++tofu_alloc_new_trans_enable_count;
}

static void tofu_fake_alloc_new_raw_rc(int ret)
{
	tofu_alloc_new_raw_rc_last = ret;
	++tofu_alloc_new_raw_rc_count;
}

static unsigned long tofu_fake_alloc_new_timestamp(void)
{
	tofu_alloc_new_timestamp_value += 10;
	++tofu_alloc_new_timestamp_count;
	return tofu_alloc_new_timestamp_value;
}

static void tofu_fake_alloc_new_profile(int event, unsigned long elapsed)
{
	if (tofu_alloc_new_profile_count < 4) {
		tofu_alloc_new_profile_events[tofu_alloc_new_profile_count] =
			event;
		tofu_alloc_new_profile_elapsed[tofu_alloc_new_profile_count] =
			elapsed;
	}
	++tofu_alloc_new_profile_count;
}

#define TOFU_ALLOC_STAG_DEV ((void *)0xa110c000UL)
#define TOFU_ALLOC_STAG_UCQ ((void *)0xa110c100UL)
#define TOFU_ALLOC_STAG_VM ((void *)0xa110c200UL)
#define TOFU_ALLOC_STAG_RANGE ((void *)0xa110c300UL)
#define TOFU_ALLOC_STAG_ARG 0xa110c400UL

static void tofu_reset_alloc_stag_fakes(void)
{
	int i;

	tofu_alloc_stag_req.flags = 0;
	tofu_alloc_stag_req.stag = -1;
	tofu_alloc_stag_req.offset = 0;
	tofu_alloc_stag_req.va = (void *)0x12345UL;
	tofu_alloc_stag_req.len = 0x2345UL;
	tofu_alloc_stag_out.flags = 0;
	tofu_alloc_stag_out.stag = 0;
	tofu_alloc_stag_out.offset = 0;
	tofu_alloc_stag_out.va = 0;
	tofu_alloc_stag_out.len = 0;
	tofu_alloc_stag_dev_to_cq_count = 0;
	tofu_alloc_stag_dev_to_cq_null = 0;
	tofu_alloc_stag_current_vm_count = 0;
	tofu_alloc_stag_current_vm_null = 0;
	tofu_alloc_stag_copyin_count = 0;
	tofu_alloc_stag_copyin_result = 0;
	tofu_alloc_stag_copyout_count = 0;
	tofu_alloc_stag_copyout_result = 0;
	tofu_alloc_stag_ucq_enabled = 1;
	tofu_alloc_stag_ucq_enabled_count = 0;
	tofu_alloc_stag_steering_count = 0;
	tofu_alloc_stag_steering_stag = -2;
	tofu_alloc_stag_steering_result = 0;
	tofu_alloc_stag_steering_after_count = -1;
	tofu_alloc_stag_steering_after_result = 0;
	tofu_alloc_stag_vm_lock_count = 0;
	tofu_alloc_stag_vm_unlock_count = 0;
	tofu_alloc_stag_lookup_count = 0;
	tofu_alloc_stag_lookup_failures = 0;
	for (i = 0; i < 4; ++i) {
		tofu_alloc_stag_lookup_start[i] = 0;
		tofu_alloc_stag_lookup_end[i] = 0;
	}
	tofu_alloc_stag_stack_faultable = 0;
	tofu_alloc_stag_stack_count = 0;
	tofu_alloc_stag_page_fault_count = 0;
	tofu_alloc_stag_page_fault_result = 0;
	tofu_alloc_stag_pagesize_count = 0;
	tofu_alloc_stag_pagesize_bits = PAGE_SHIFT;
	tofu_alloc_stag_pagesize_result = 0;
	tofu_alloc_stag_pagesize_readonly = 0;
	tofu_alloc_stag_cq_lock_count = 0;
	tofu_alloc_stag_cq_unlock_count = 0;
	tofu_alloc_stag_trans_count = 0;
	tofu_alloc_stag_trans_result = 77;
	tofu_alloc_stag_trans_start = 0;
	tofu_alloc_stag_trans_end = 0;
	tofu_alloc_stag_trans_pgszbits = 0;
	tofu_alloc_stag_trans_readonly = 0;
	tofu_alloc_stag_reserve_count = 0;
	tofu_alloc_stag_reserve_result = 88;
	tofu_alloc_stag_reserve_readonly = 0;
	tofu_alloc_stag_release_count = 0;
	tofu_alloc_stag_release_stag = 0;
	tofu_alloc_stag_alloc_new_count = 0;
	tofu_alloc_stag_alloc_new_result = 0;
	tofu_alloc_stag_alloc_new_stag = 0;
	tofu_alloc_stag_alloc_new_start = 0;
	tofu_alloc_stag_alloc_new_end = 0;
	tofu_alloc_stag_alloc_new_pgszbits = 0;
	tofu_alloc_stag_alloc_new_plus_mbva = 0;
	tofu_alloc_stag_alloc_new_readonly = 0;
	tofu_alloc_stag_get_mbpt_count = 0;
	tofu_alloc_stag_mbpt_start = 0x10000UL;
	tofu_alloc_stag_range_insert_count = 0;
	tofu_alloc_stag_range_start = 0;
	tofu_alloc_stag_range_end = 0;
	tofu_alloc_stag_range_stag = 0;
}

static void *tofu_fake_alloc_stag_dev_to_cq(void *dev)
{
	require(dev == TOFU_ALLOC_STAG_DEV);
	++tofu_alloc_stag_dev_to_cq_count;
	if (tofu_alloc_stag_dev_to_cq_null)
		return 0;
	return TOFU_ALLOC_STAG_UCQ;
}

static void *tofu_fake_alloc_stag_current_vm(void)
{
	++tofu_alloc_stag_current_vm_count;
	if (tofu_alloc_stag_current_vm_null)
		return 0;
	return TOFU_ALLOC_STAG_VM;
}

static int tofu_fake_alloc_stag_copyin(struct tof_alloc_stag *req,
	unsigned long arg)
{
	require(arg == TOFU_ALLOC_STAG_ARG);
	++tofu_alloc_stag_copyin_count;
	if (tofu_alloc_stag_copyin_result < 0)
		return tofu_alloc_stag_copyin_result;
	*req = tofu_alloc_stag_req;
	return 0;
}

static int tofu_fake_alloc_stag_copyout(unsigned long arg,
	const struct tof_alloc_stag *req)
{
	require(arg == TOFU_ALLOC_STAG_ARG);
	++tofu_alloc_stag_copyout_count;
	if (tofu_alloc_stag_copyout_result < 0)
		return tofu_alloc_stag_copyout_result;
	tofu_alloc_stag_out = *req;
	return 0;
}

static int tofu_fake_alloc_stag_ucq_enabled(void *ucq)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	++tofu_alloc_stag_ucq_enabled_count;
	return tofu_alloc_stag_ucq_enabled;
}

static int tofu_fake_alloc_stag_steering_enabled(void *ucq, int stag)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	++tofu_alloc_stag_steering_count;
	if (stag == tofu_alloc_stag_steering_stag) {
		if (tofu_alloc_stag_steering_after_count >= 0 &&
		    tofu_alloc_stag_steering_count >
		    tofu_alloc_stag_steering_after_count)
			return tofu_alloc_stag_steering_after_result;
		return tofu_alloc_stag_steering_result;
	}
	return 0;
}

static void tofu_fake_alloc_stag_vm_read_lock(void *vm)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	++tofu_alloc_stag_vm_lock_count;
}

static void tofu_fake_alloc_stag_vm_read_unlock(void *vm)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	++tofu_alloc_stag_vm_unlock_count;
}

static void *tofu_fake_alloc_stag_lookup_range(void *vm, unsigned long start,
	unsigned long end)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	if (tofu_alloc_stag_lookup_count < 4) {
		tofu_alloc_stag_lookup_start[tofu_alloc_stag_lookup_count] =
			start;
		tofu_alloc_stag_lookup_end[tofu_alloc_stag_lookup_count] =
			end;
	}
	++tofu_alloc_stag_lookup_count;
	if (tofu_alloc_stag_lookup_failures > 0) {
		--tofu_alloc_stag_lookup_failures;
		return 0;
	}
	return TOFU_ALLOC_STAG_RANGE;
}

static int tofu_fake_alloc_stag_stack_faultable(void *vm,
	unsigned long start, unsigned long end)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	require(start <= end);
	++tofu_alloc_stag_stack_count;
	return tofu_alloc_stag_stack_faultable;
}

static int tofu_fake_alloc_stag_page_fault(void *vm, unsigned long start)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	require(start == 0x12000UL);
	++tofu_alloc_stag_page_fault_count;
	return tofu_alloc_stag_page_fault_result;
}

static int tofu_fake_alloc_stag_pagesize_locked(unsigned long va,
	unsigned long len, unsigned char *pgszbits, int readonly)
{
	require(va == (unsigned long)tofu_alloc_stag_req.va);
	require(len == tofu_alloc_stag_req.len);
	tofu_alloc_stag_pagesize_readonly = readonly;
	++tofu_alloc_stag_pagesize_count;
	if (tofu_alloc_stag_pagesize_result < 0)
		return tofu_alloc_stag_pagesize_result;
	*pgszbits = tofu_alloc_stag_pagesize_bits;
	return 0;
}

static void tofu_fake_alloc_stag_cq_lock(void *ucq)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	++tofu_alloc_stag_cq_lock_count;
}

static void tofu_fake_alloc_stag_cq_unlock(void *ucq)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	++tofu_alloc_stag_cq_unlock_count;
}

static int tofu_fake_alloc_stag_trans_search(void *ucq, unsigned long start,
	unsigned long end, unsigned char pgszbits, int readonly)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	tofu_alloc_stag_trans_start = start;
	tofu_alloc_stag_trans_end = end;
	tofu_alloc_stag_trans_pgszbits = pgszbits;
	tofu_alloc_stag_trans_readonly = readonly;
	++tofu_alloc_stag_trans_count;
	return tofu_alloc_stag_trans_result;
}

static int tofu_fake_alloc_stag_reserve(void *ucq, int readonly)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	tofu_alloc_stag_reserve_readonly = readonly;
	++tofu_alloc_stag_reserve_count;
	return tofu_alloc_stag_reserve_result;
}

static void tofu_fake_alloc_stag_release(void *ucq, int stag)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	tofu_alloc_stag_release_stag = stag;
	++tofu_alloc_stag_release_count;
}

static int tofu_fake_alloc_stag_alloc_new(void *ucq, int stag,
	unsigned long start, unsigned long end, unsigned char pgszbits,
	unsigned long plus_mbva, int readonly)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	tofu_alloc_stag_alloc_new_stag = stag;
	tofu_alloc_stag_alloc_new_start = start;
	tofu_alloc_stag_alloc_new_end = end;
	tofu_alloc_stag_alloc_new_pgszbits = pgszbits;
	tofu_alloc_stag_alloc_new_plus_mbva = plus_mbva;
	tofu_alloc_stag_alloc_new_readonly = readonly;
	++tofu_alloc_stag_alloc_new_count;
	return tofu_alloc_stag_alloc_new_result;
}

static unsigned long tofu_fake_alloc_stag_get_mbpt_start(void *ucq, int stag)
{
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	require(stag == tofu_alloc_stag_out.stag ||
		stag == tofu_alloc_stag_trans_result ||
		stag == tofu_alloc_stag_reserve_result);
	++tofu_alloc_stag_get_mbpt_count;
	return tofu_alloc_stag_mbpt_start;
}

static void tofu_fake_alloc_stag_range_insert(void *vm, void *range,
	unsigned long start, unsigned long end, void *ucq, int stag)
{
	require(vm == TOFU_ALLOC_STAG_VM);
	require(range == TOFU_ALLOC_STAG_RANGE);
	require(ucq == TOFU_ALLOC_STAG_UCQ);
	tofu_alloc_stag_range_start = start;
	tofu_alloc_stag_range_end = end;
	tofu_alloc_stag_range_stag = stag;
	++tofu_alloc_stag_range_insert_count;
}

static int tofu_call_alloc_stag(void)
{
	return tofu_utofu_ioctl_alloc_stag_body_result(TOFU_ALLOC_STAG_DEV,
		TOFU_ALLOC_STAG_ARG, TOF_UTOFU_SPECIAL_STAG,
		TOF_UTOFU_ALLOC_STAG_LPG, TOF_UTOFU_BLANK_MBVA, 4096, 12,
		256, tofu_fake_alloc_stag_dev_to_cq,
		tofu_fake_alloc_stag_current_vm,
		tofu_fake_alloc_stag_copyin,
		tofu_fake_alloc_stag_copyout,
		tofu_fake_alloc_stag_ucq_enabled,
		tofu_fake_alloc_stag_steering_enabled,
		tofu_fake_alloc_stag_vm_read_lock,
		tofu_fake_alloc_stag_vm_read_unlock,
		tofu_fake_alloc_stag_lookup_range,
		tofu_fake_alloc_stag_stack_faultable,
		tofu_fake_alloc_stag_page_fault,
		tofu_fake_alloc_stag_pagesize_locked,
		tofu_fake_alloc_stag_cq_lock,
		tofu_fake_alloc_stag_cq_unlock,
		tofu_fake_alloc_stag_trans_search,
		tofu_fake_alloc_stag_reserve,
		tofu_fake_alloc_stag_release,
		tofu_fake_alloc_stag_alloc_new,
		tofu_fake_alloc_stag_get_mbpt_start,
		tofu_fake_alloc_stag_range_insert);
}

static int tofu_fake_ioctl_common(void *dev, unsigned long arg, int kind)
{
	require(dev == (void *)0xf00d0000UL);
	tofu_ioctl_last_kind = kind;
	tofu_ioctl_last_arg = arg;
	++tofu_ioctl_call_count;
	return tofu_ioctl_results[kind];
}

static int tofu_fake_ioctl_alloc(void *dev, unsigned long arg)
{
	return tofu_fake_ioctl_common(dev, arg, 0);
}

static int tofu_fake_ioctl_free(void *dev, unsigned long arg)
{
	return tofu_fake_ioctl_common(dev, arg, 1);
}

static int tofu_fake_ioctl_enable_bch(void *dev, unsigned long arg)
{
	return tofu_fake_ioctl_common(dev, arg, 2);
}

static int tofu_fake_ioctl_disable_bch(void *dev, unsigned long arg)
{
	return tofu_fake_ioctl_common(dev, arg, 3);
}

static unsigned long tofu_fake_ioctl_timestamp(void)
{
	++tofu_ioctl_timestamp_count;
	tofu_ioctl_timestamp_value += 50;
	return tofu_ioctl_timestamp_value;
}

static void tofu_fake_ioctl_profile_event(int event, unsigned long delta)
{
	tofu_ioctl_profile_last_event = event;
	tofu_ioctl_profile_last_delta = delta;
	++tofu_ioctl_profile_count;
}

static void tofu_fake_ioctl_unknown_log(int fd)
{
	tofu_ioctl_unknown_last_fd = fd;
	++tofu_ioctl_unknown_count;
}

static void tofu_reset_free_stags_fakes(void)
{
	int i;

	tofu_free_stags_copyin_count = 0;
	tofu_free_stags_copyout_count = 0;
	tofu_free_stags_reqout_count = 0;
	tofu_free_stags_free_count = 0;
	tofu_free_stags_remove_count = 0;
	tofu_free_stags_log_count = 0;
	tofu_free_stags_copyin_fail = 0;
	tofu_free_stags_copyout_fail = 0;
	tofu_free_stags_reqout_fail = 0;
	for (i = 0; i < 8; ++i) {
		tofu_free_stags_results[i] = 0;
		tofu_free_stags_free_order[i] = 0;
		tofu_free_stags_remove_order[i] = 0;
	}
	tofu_free_stags_log_num = 0;
	tofu_free_stags_log_stags = 0;
	tofu_free_stags_log_no_free = 0;
	tofu_error_log_count = 0;
	tofu_error_log_last = 0;
}

static int tofu_fake_copyin_stags(int *dst, const int *src,
	unsigned long count)
{
	unsigned long i;

	++tofu_free_stags_copyin_count;
	if (tofu_free_stags_copyin_fail)
		return -EFAULT;
	for (i = 0; i < count; ++i)
		dst[i] = src[i];
	return 0;
}

static int tofu_fake_copyout_stags(int *dst, const int *src,
	unsigned long count)
{
	unsigned long i;

	++tofu_free_stags_copyout_count;
	if (tofu_free_stags_copyout_fail)
		return -EFAULT;
	for (i = 0; i < count; ++i)
		dst[i] = src[i];
	return 0;
}

static int tofu_fake_copyout_free_req(void *arg,
	const struct tof_free_stags *req)
{
	struct tof_free_stags *out = (struct tof_free_stags *)arg;

	++tofu_free_stags_reqout_count;
	if (tofu_free_stags_reqout_fail)
		return -EFAULT;
	*out = *req;
	return 0;
}

static int tofu_fake_free_one_stag(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe0000UL);
	if (tofu_free_stags_free_count < 8)
		tofu_free_stags_free_order[tofu_free_stags_free_count] = stag;
	return tofu_free_stags_results[tofu_free_stags_free_count++];
}

static void tofu_fake_remove_stag_range(int stag)
{
	if (tofu_free_stags_remove_count < 8)
		tofu_free_stags_remove_order[tofu_free_stags_remove_count] = stag;
	++tofu_free_stags_remove_count;
}

static void tofu_fake_free_stags_log(void *ucq, unsigned short num,
	int *stags, int no_free_count)
{
	require(ucq == (void *)0xcafe0000UL);
	tofu_free_stags_log_num = num;
	tofu_free_stags_log_stags = stags;
	tofu_free_stags_log_no_free = no_free_count;
	++tofu_free_stags_log_count;
}

static void tofu_record_free_stag_order(int op)
{
	if (tofu_free_stag_order_count < 16)
		tofu_free_stag_order[tofu_free_stag_order_count] = op;
	++tofu_free_stag_order_count;
}

static void tofu_reset_free_stag_fakes(void)
{
	int i;

	tofu_free_stag_enabled_result = 1;
	tofu_free_stag_kref_result = 1;
	tofu_free_stag_cacheflush_result = 0;
	tofu_free_stag_enabled_count = 0;
	tofu_free_stag_kref_count = 0;
	tofu_free_stag_non_mckernel_log_count = 0;
	tofu_free_stag_disable_count = 0;
	tofu_free_stag_trans_disable_count = 0;
	tofu_free_stag_wmb_count = 0;
	tofu_free_stag_profile_count = 0;
	tofu_free_stag_cacheflush_count = 0;
	tofu_free_stag_kref_put_count = 0;
	tofu_free_stag_clear_count = 0;
	tofu_free_stag_dealloc_log_count = 0;
	tofu_free_stag_order_count = 0;
	tofu_free_stag_last_stag = 0;
	for (i = 0; i < 16; ++i)
		tofu_free_stag_order[i] = 0;
	for (i = 0; i < 8; ++i)
		tofu_free_stag_profile_order[i] = 0;
}

static int tofu_fake_free_stag_enabled(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	tofu_free_stag_last_stag = stag;
	++tofu_free_stag_enabled_count;
	return tofu_free_stag_enabled_result;
}

static int tofu_fake_free_stag_kref(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	++tofu_free_stag_kref_count;
	return tofu_free_stag_kref_result;
}

static void tofu_fake_free_stag_non_mckernel_log(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	++tofu_free_stag_non_mckernel_log_count;
}

static void tofu_fake_free_stag_disable_entries(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(1);
	++tofu_free_stag_disable_count;
}

static void tofu_fake_free_stag_trans_disable(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(2);
	++tofu_free_stag_trans_disable_count;
}

static void tofu_fake_free_stag_wmb(void)
{
	tofu_record_free_stag_order(3);
	++tofu_free_stag_wmb_count;
}

static void tofu_fake_free_stag_profile(void *state, int stage)
{
	require(state == (void *)0x51510000UL);
	if (tofu_free_stag_profile_count < 8)
		tofu_free_stag_profile_order[tofu_free_stag_profile_count] = stage;
	tofu_record_free_stag_order(10 + stage);
	++tofu_free_stag_profile_count;
}

static int tofu_fake_free_stag_cacheflush(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(4);
	++tofu_free_stag_cacheflush_count;
	return tofu_free_stag_cacheflush_result;
}

static void tofu_fake_free_stag_kref_put(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(5);
	++tofu_free_stag_kref_put_count;
}

static void tofu_fake_free_stag_clear(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(6);
	++tofu_free_stag_clear_count;
}

static void tofu_fake_free_stag_dealloc_log(void *ucq, int stag)
{
	require(ucq == (void *)0xcafe1000UL);
	require(stag == tofu_free_stag_last_stag);
	tofu_record_free_stag_order(7);
	++tofu_free_stag_dealloc_log_count;
}

static int tofu_fake_enable_bch(int tni, int bgid, unsigned long ipa)
{
	tofu_enable_last_tni = tni;
	tofu_enable_last_bgid = bgid;
	tofu_enable_last_ipa = ipa;
	++tofu_enable_call_count;
	return tofu_enable_result;
}

static int tofu_fake_set_bg(void *ubg, const struct tof_set_bg *bgs,
	int kuid, unsigned int bseq)
{
	int index;

	require(ubg == (void *)0xbeef0000UL);
	index = (int)(bgs - tofu_enable_bgs_base);
	require(index >= 0 && index < 8);
	if (tofu_set_bg_count < 8)
		tofu_set_bg_order[tofu_set_bg_count] = index;
	tofu_set_bg_last_kuid = kuid;
	tofu_set_bg_last_bseq = bseq;
	++tofu_set_bg_count;
	if (index == tofu_set_bg_fail_index)
		return -66;
	return 0;
}

static int tofu_fake_commit_disable_bch(int tni, int bgid)
{
	tofu_commit_disable_last_tni = tni;
	tofu_commit_disable_last_bgid = bgid;
	++tofu_commit_disable_count;
	return 0;
}

static int tofu_fake_unset_bg_user(const struct tof_set_bg *bgs)
{
	int index = (int)(bgs - tofu_enable_bgs_base);

	require(index >= 0 && index < 8);
	if (tofu_unset_user_count < 8)
		tofu_unset_user_order[tofu_unset_user_count] = index;
	++tofu_unset_user_count;
	return 0;
}

static int tofu_fake_unset_bg(int tni, int bgid)
{
	tofu_bg_last_tni = tni;
	tofu_bg_last_bgid = bgid;
	++tofu_bg_unset_count;
	return -1234;
}

static void tofu_fake_unregister_bg(int tni, int bgid)
{
	require(tni == tofu_bg_last_tni);
	require(bgid == tofu_bg_last_bgid);
	require(tofu_bg_unset_count == tofu_bg_unregister_count + 1);
	++tofu_bg_unregister_count;
}

int main(void)
{
	int lengths[] = { -8, -5, -4, -3, 0, 1, 4, 28, 29, 60, 61, 62, 92, 93, 2017 };
	unsigned long digest = 0x710f1ccUL;
	int i;
	int tni;
	int cqid;
	int frame;
	int size;
	int bits;

	for (tni = 0; tni < 3; ++tni) {
		mix(&digest, (unsigned long)TOF_RSC_PBQ(tni));
		mix(&digest, (unsigned long)TOF_RSC_PRQ(tni));
		for (cqid = 0; cqid < 4; ++cqid) {
			mix(&digest, (unsigned long)TOF_RSC_TOQ(tni, cqid));
			mix(&digest, (unsigned long)TOF_RSC_TCQ(tni, cqid));
			mix(&digest, (unsigned long)TOF_RSC_MRQ(tni, cqid));
			mix(&digest, (unsigned long)TOF_RSC_STT(tni, cqid));
			mix(&digest, (unsigned long)TOF_RSC_MBT(tni, cqid));
			mix(&digest, TOF_ICC_REG_CQ_PA(tni, cqid));
			mix(&digest, TOF_ICC_REG_CQS_PA(tni, cqid));
			mix(&digest, TOF_ICC_REG_BCH_PA(tni, cqid));
			mix(&digest, TOF_ICC_REG_BGS_PA(tni, cqid));
		}
		mix(&digest, TOF_ICC_REG_TNI_PA(tni));
		mix(&digest, TOF_ICC_REG_PORT_PA(tni));
		mix(&digest, (unsigned long)TOF_ICC_XB_TC_DATA_CYCLE_COUNT(tni));
		mix(&digest, (unsigned long)TOF_ICC_XB_TC_WAIT_CYCLE_COUNT(tni));
		mix(&digest, (unsigned long)TOF_ICC_XB_TD_DATA_CYCLE_COUNT(tni));
		mix(&digest, (unsigned long)TOF_ICC_XB_TD_WAIT_CYCLE_COUNT(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TD_TLP_FILTER(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TD_SETTINGS(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_VMS(tni, 7));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_VMS_CQ00(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_VMS_BG00(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_VMS_BG16(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_VMS_BG32(tni));
		mix(&digest, (unsigned long)TOF_ICC_REG_TOFU_TNI_MSI_BASE(tni));
	}

	require(TOF_RSC_TOQ(1, 2) == 14);
	require(TOF_RSC_MBT(2, 3) == 324);
	require(GENMASK(63, 0) == ~0UL);
	require(GENMASK(56, 32) == 0x01ffffff00000000UL);
	require(GENMASK(29, 5) == 0x000000003fffffe0UL);
	require(TOF_ICC_TLP_LEN(61) == 1984);
	require(TOF_ICC_FRAME_LEN(61) == 1992);
	require(TOF_ICC_MB_PS_ENCODE(12) == 0);
	require(TOF_ICC_MB_PS_ENCODE(16) == 4);
	require(TOF_ICC_MB_PS_ENCODE(21) == 1);
	require(TOF_ICC_REG_CQ_PA(1, 2) == 0x41020000UL);
	require(TOF_ICC_REG_PORT_PA(2) == 0x46002000UL);
	require(TOF_ICC_REG_TOFU_TNI_VMS(2, 3) == 0x318);
	require(tof_icc_get_framelen(0) == TOF_ICC_FRAME_LEN_MIN);
	require(tof_icc_get_framelen(92) == TOF_ICC_FRAME_LEN_MIN);
	require(tof_icc_get_framelen(93) == 136);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		2, 3, 6, 8, 64) == (void *)0x100004c0UL);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		5, 7, 6, 8, 64) == (void *)0x10000bc0UL);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		6, 0, 6, 8, 64) == (void *)0);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		0, 8, 6, 8, 64) == (void *)0);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		-1, 0, 6, 8, 64) == (void *)0);
	require(tofu_indexed_2d_ptr_body_result((void *)0x10000000UL,
		0, -1, 6, 8, 64) == (void *)0);
	require(tofu_indexed_2d_ptr_body_result((void *)0,
		1, 1, 6, 8, 64) == (void *)0x240UL);
	mix(&digest, (unsigned long)tofu_indexed_2d_ptr_body_result(
		(void *)0x10000000UL, 3, 2, 6, 8, 128));
		{
			unsigned char enabled = 1;
			require(tofu_utofu_unset_bg_body_result(&enabled, 5, 6,
				tofu_fake_unset_bg, tofu_fake_unregister_bg) == 0);
			require(enabled == 0);
		require(tofu_bg_unset_count == 1);
		require(tofu_bg_unregister_count == 1);
		require(tofu_bg_last_tni == 5);
		require(tofu_bg_last_bgid == 6);
		mix(&digest, ((unsigned long)tofu_bg_unset_count << 8) |
			(unsigned long)tofu_bg_unregister_count);
		require(tofu_utofu_unset_bg_body_result(&enabled, 7, 8,
			tofu_fake_unset_bg, tofu_fake_unregister_bg) == 0);
		require(enabled == 0);
		require(tofu_bg_unset_count == 1);
		require(tofu_bg_unregister_count == 1);
		enabled = 1;
		require(tofu_utofu_unset_bg_body_result(&enabled, 9, 10,
			0, tofu_fake_unregister_bg) == -22);
		require(enabled == 1);
		require(tofu_utofu_unset_bg_body_result(&enabled, 9, 10,
			tofu_fake_unset_bg, 0) == -22);
		require(enabled == 1);
			require(tofu_utofu_unset_bg_body_result(0, 1, 2,
				tofu_fake_unset_bg, tofu_fake_unregister_bg) == -22);
		}
		{
			struct tofu_addr src = {
				.pa = 1, .pb = 2, .pc = 1, .x = 17, .y = 6,
				.z = 3, .a = 1, .b = 2, .c = 1
			};
			struct tofu_addr dst = {
				.pa = 0, .pb = 1, .pc = 0, .x = 4, .y = 18,
				.z = 7, .a = 0, .b = 3, .c = 0
			};
			unsigned long sigmask = 0;
			unsigned long locallink = 0;
			unsigned long remotelink = 0;

			require(tofu_core_bg_links_body_result(3, &src, 2, -1,
				-1, &dst, 5, 17, &sigmask, &locallink,
				&remotelink) == 0);
			require(sigmask == 0x6000000000000000UL);
			require(locallink == 0x0000000300000000UL);
			require(remotelink == 0x000000002248ed51UL);
			mix(&digest, sigmask);
			mix(&digest, locallink);
			mix(&digest, remotelink);

			sigmask = locallink = remotelink = 0;
			require(tofu_core_bg_links_body_result(-1, &src, 2, 11,
				12, &dst, 5, -1, &sigmask, &locallink,
				&remotelink) == 0);
			require(sigmask == 0x9000000000000000UL);
			require(locallink == 0x000000000000000cUL);
			require(remotelink == 0x08987a8b00000000UL);
			mix(&digest, sigmask);
			mix(&digest, locallink);
			mix(&digest, remotelink);

			require(tofu_core_bg_links_body_result(0, &src, 0, -1,
				0, &dst, 0, -1, 0, &locallink,
				&remotelink) == -22);
			require(tofu_core_bg_links_body_result(0, 0, 0, 1,
				0, &dst, 0, -1, &sigmask, &locallink,
				&remotelink) == -22);
		}
		{
			struct tof_set_bg req = {
				.tni = 2,
				.gate = 5,
				.source_lgate = 3,
				.source_raddr = {
					.pa = 1, .pb = 2, .pc = 1, .x = 17,
					.y = 6, .z = 3, .a = 1, .b = 2,
					.c = 1,
				},
				.source_rtni = 2,
				.source_rgate = -1,
				.dest_lgate = -1,
				.dest_raddr = {
					.pa = 0, .pb = 1, .pc = 0, .x = 4,
					.y = 18, .z = 7, .a = 0, .b = 3,
					.c = 0,
				},
				.dest_rtni = 5,
				.dest_rgate = 17,
			};

			tofu_reset_core_bg_fakes();
			require(tofu_core_set_bg_body_result(&req, 0x99aaUL, 0x33,
				0x44, 0x123456UL, tofu_fake_core_bg_get,
				tofu_fake_core_bg_publish, tofu_fake_core_bg_lock,
				tofu_fake_core_bg_unlock,
				tofu_fake_core_bg_reset_irqmask,
				tofu_fake_core_bg_reset_irqmask_imc,
				tofu_fake_core_bg_bgs_reg, tofu_fake_writeq,
				tofu_fake_wmb, tofu_fake_readq_spin) == 0);
			require(tofu_core_bg_get_count == 1);
			require(tofu_core_bg_last_tni == 2);
			require(tofu_core_bg_last_bgid == 5);
			require(tofu_core_bg_publish_count == 1);
			require(tofu_core_bg_slot.subnet == 0x99aaUL);
			require(tofu_core_bg_slot.gpid == 0x44);
			require(tofu_core_bg_lock_count == 1);
			require(tofu_core_bg_unlock_count == 1);
			require(tofu_core_bg_reset_irqmask_count == 1);
			require(tofu_core_bg_reset_irqmask_imc_count == 1);
			require(tofu_core_bg_bgs_reg_count == 1);
			require(tofu_writeq_count == 6);
			require(tofu_writeq_values[0] == 0x6000000000000000UL);
			require(tofu_writeq_offsets[0] == TOF_ICC_REG_BGS_SIGNAL_MASK);
			require(tofu_writeq_values[1] == 0x0000000300000000UL);
			require(tofu_writeq_offsets[1] == TOF_ICC_REG_BGS_LOCAL_LINK);
			require(tofu_writeq_values[2] == 0x000000002248ed51UL);
			require(tofu_writeq_offsets[2] == TOF_ICC_REG_BGS_REMOTE_LINK);
			require(tofu_writeq_values[3] == 0x99aaUL);
			require(tofu_writeq_offsets[3] == TOF_ICC_REG_BGS_SUBNET_SIZE);
			require(tofu_writeq_values[4] == 0x44000033UL);
			require(tofu_writeq_offsets[4] == TOF_ICC_REG_BGS_GPID_BSEQ);
			require(tofu_writeq_values[5] == 1);
			require(tofu_writeq_offsets[5] == TOF_ICC_REG_BGS_ENABLE);
			require(tofu_wmb_count == 1);
			require(tofu_readq_spin_count == 1);
			require(tofu_readq_spin_last_reg == &tofu_core_bg_slot.bgs_reg);
			require(tofu_readq_spin_last_offset == TOF_ICC_REG_BGS_STATE);
			require(tofu_readq_spin_last_mask ==
				TOF_ICC_REG_BGS_STATE_ENABLE);
			require(tofu_readq_spin_last_expect ==
				TOF_ICC_REG_BGS_STATE_ENABLE);
			require(tofu_readq_spin_last_timeout == 0x123456UL);
			mix(&digest, tofu_writeq_values[0] ^ tofu_writeq_values[2] ^
				tofu_writeq_values[4]);

			tofu_reset_core_bg_fakes();
			tofu_readq_spin_result = 0;
			require(tofu_core_set_bg_body_result(&req, 0x88UL, 0x2,
				0x3, 0x777UL, tofu_fake_core_bg_get,
				tofu_fake_core_bg_publish, tofu_fake_core_bg_lock,
				tofu_fake_core_bg_unlock,
				tofu_fake_core_bg_reset_irqmask,
				tofu_fake_core_bg_reset_irqmask_imc,
				tofu_fake_core_bg_bgs_reg, tofu_fake_writeq,
				tofu_fake_wmb, tofu_fake_readq_spin) == -ETIMEDOUT);
			require(tofu_writeq_count == 6);
			require(tofu_readq_spin_count == 1);
			require(tofu_core_bg_unlock_count == 1);

			tofu_reset_core_bg_fakes();
			tofu_core_bg_get_null = 1;
			require(tofu_core_set_bg_body_result(&req, 0x88UL, 0x2,
				0x3, 0x777UL, tofu_fake_core_bg_get,
				tofu_fake_core_bg_publish, tofu_fake_core_bg_lock,
				tofu_fake_core_bg_unlock,
				tofu_fake_core_bg_reset_irqmask,
				tofu_fake_core_bg_reset_irqmask_imc,
				tofu_fake_core_bg_bgs_reg, tofu_fake_writeq,
				tofu_fake_wmb, tofu_fake_readq_spin) == -22);
			require(tofu_core_bg_get_count == 1);
			require(tofu_core_bg_lock_count == 0);
			require(tofu_writeq_count == 0);

			tofu_reset_core_bg_fakes();
			require(tofu_core_set_bg_body_result(0, 0x88UL, 0x2,
				0x3, 0x777UL, tofu_fake_core_bg_get,
				tofu_fake_core_bg_publish, tofu_fake_core_bg_lock,
				tofu_fake_core_bg_unlock,
				tofu_fake_core_bg_reset_irqmask,
				tofu_fake_core_bg_reset_irqmask_imc,
				tofu_fake_core_bg_bgs_reg, tofu_fake_writeq,
				tofu_fake_wmb, tofu_fake_readq_spin) == -22);
			require(tofu_core_bg_get_count == 0);
				require(tofu_core_set_bg_body_result(&req, 0x88UL, 0x2,
					0x3, 0x777UL, 0, tofu_fake_core_bg_publish,
					tofu_fake_core_bg_lock, tofu_fake_core_bg_unlock,
				tofu_fake_core_bg_reset_irqmask,
				tofu_fake_core_bg_reset_irqmask_imc,
				tofu_fake_core_bg_bgs_reg, tofu_fake_writeq,
				tofu_fake_wmb, tofu_fake_readq_spin) == -22);
				require(tofu_core_bg_get_count == 0);
			}
			{
				void *cq = &tofu_cacheflush_cq[1][2];

				tofu_reset_cacheflush_fakes();
				require(tofu_core_cacheflush_timeout_body_result(
					tofu_fake_cacheflush_get_cq,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq, tofu_fake_wmb,
					tofu_fake_cacheflush_log, 2, 3, 2, 1,
					0x44) == 0);
				require(tofu_cacheflush_get_count == 4);
				require(tofu_cacheflush_reg_count == 4);
				require(tofu_writeq_count == 4);
				require(tofu_wmb_count == 4);
				require(tofu_cacheflush_log_count == 4);
				require(tofu_cacheflush_log_events[0] == 1);
				require(tofu_cacheflush_log_tni[0] == 0);
				require(tofu_cacheflush_log_cqid[0] == 0);
				require(tofu_cacheflush_log_cqid[1] == 1);
				require(tofu_cacheflush_log_tni[2] == 1);
				require(tofu_cacheflush_log_cqid[3] == 1);
				require(tofu_writeq_last_val == 0);
				require(tofu_writeq_last_offset == 0x44);
				mix(&digest,
					((unsigned long)tofu_cacheflush_get_count << 24) |
					((unsigned long)tofu_writeq_count << 16) |
					(unsigned long)tofu_cacheflush_log_count);

				tofu_reset_cacheflush_fakes();
				require(tofu_core_cacheflush_timeout_body_result(
					tofu_fake_cacheflush_get_cq,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq, tofu_fake_wmb,
					tofu_fake_cacheflush_log, 2, 3, 2, 0,
					0x44) == 0);
				require(tofu_cacheflush_get_count == 4);
				require(tofu_writeq_count == 0);
				require(tofu_wmb_count == 0);
				require(tofu_cacheflush_log_count == 4);

				tofu_reset_cacheflush_fakes();
				tofu_cacheflush_get_null = 1;
				require(tofu_core_cacheflush_timeout_body_result(
					tofu_fake_cacheflush_get_cq,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq, tofu_fake_wmb,
					tofu_fake_cacheflush_log, 2, 3, 2, 1,
					0x44) == -EINVAL);
				require(tofu_cacheflush_get_count == 1);
				require(tofu_cacheflush_reg_count == 0);
				require(tofu_core_cacheflush_timeout_body_result(0,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq, tofu_fake_wmb,
					tofu_fake_cacheflush_log, 2, 3, 2, 1,
					0x44) == -EINVAL);

				tofu_reset_cacheflush_fakes();
				require(tofu_core_cq_cacheflush_body_result(cq, 1, 2,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq,
					tofu_fake_cacheflush_readq_spin,
					tofu_fake_cacheflush_timeout,
					tofu_fake_cacheflush_log,
					tofu_fake_cacheflush_panic, 1, 111, 222,
					0x10, 0x20, 0x80) == 0);
				require(tofu_writeq_count == 1);
				require(tofu_writeq_last_val == 1);
				require(tofu_writeq_last_offset == 0x10);
				require(tofu_cacheflush_read_count == 1);
				require(tofu_cacheflush_read_offset[0] == 0x20);
				require(tofu_cacheflush_read_mask[0] == 0x80);
				require(tofu_cacheflush_read_expect[0] == 0);
				require(tofu_cacheflush_read_timeout[0] == 111);
				require(tofu_cacheflush_timeout_count == 0);
				require(tofu_cacheflush_log_count == 0);
				require(tofu_cacheflush_panic_count == 0);

				tofu_reset_cacheflush_fakes();
				tofu_cacheflush_read_results[0] = 0;
				tofu_cacheflush_read_results[1] = 1;
				require(tofu_core_cq_cacheflush_body_result(cq, 1, 2,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq,
					tofu_fake_cacheflush_readq_spin,
					tofu_fake_cacheflush_timeout,
					tofu_fake_cacheflush_log,
					tofu_fake_cacheflush_panic, 1, 111, 222,
					0x10, 0x20, 0x80) == 0);
				require(tofu_cacheflush_read_count == 2);
				require(tofu_cacheflush_read_timeout[1] == 222);
				require(tofu_cacheflush_timeout_count == 1);
				require(tofu_cacheflush_timeout_arg == cq);
				require(tofu_cacheflush_log_count == 1);
				require(tofu_cacheflush_log_events[0] == 0);
				require(tofu_cacheflush_log_tni[0] == 1);
				require(tofu_cacheflush_log_cqid[0] == 2);
				require(tofu_cacheflush_panic_count == 0);

				tofu_reset_cacheflush_fakes();
				tofu_cacheflush_read_results[0] = 0;
				tofu_cacheflush_read_results[1] = 0;
				require(tofu_core_cq_cacheflush_body_result(cq, 1, 2,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq,
					tofu_fake_cacheflush_readq_spin,
					tofu_fake_cacheflush_timeout,
					tofu_fake_cacheflush_log,
					tofu_fake_cacheflush_panic, 1, 111, 222,
					0x10, 0x20, 0x80) == 0);
				require(tofu_cacheflush_log_count == 2);
				require(tofu_cacheflush_timeout_count == 1);
				require(tofu_cacheflush_panic_count == 1);

				tofu_reset_cacheflush_fakes();
				tofu_cacheflush_read_results[0] = 0;
				require(tofu_core_cq_cacheflush_body_result(cq, 1, 2,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq,
					tofu_fake_cacheflush_readq_spin,
					tofu_fake_cacheflush_timeout,
					tofu_fake_cacheflush_log,
					tofu_fake_cacheflush_panic, 0, 111, 222,
					0x10, 0x20, 0x80) == 0);
				require(tofu_cacheflush_read_count == 1);
				require(tofu_cacheflush_timeout_count == 0);
				require(tofu_cacheflush_log_count == 1);
				require(tofu_cacheflush_panic_count == 1);

				tofu_reset_cacheflush_fakes();
				require(tofu_core_cq_cacheflush_body_result(0, 1, 2,
					tofu_fake_cacheflush_cqs_reg,
					tofu_fake_writeq,
					tofu_fake_cacheflush_readq_spin,
					tofu_fake_cacheflush_timeout,
					tofu_fake_cacheflush_log,
					tofu_fake_cacheflush_panic, 1, 111, 222,
					0x10, 0x20, 0x80) == -EINVAL);
				require(tofu_writeq_count == 0);
				mix(&digest,
					((unsigned long)tofu_cacheflush_read_count << 24) |
					((unsigned long)tofu_cacheflush_timeout_count << 16) |
					(unsigned long)tofu_cacheflush_panic_count);
			}
			{
				unsigned long subnet =
					(8UL << 48) | (8UL << 30) | (8UL << 12);
				struct tof_set_bg req = {
					.tni = 2,
					.gate = 5,
					.source_lgate = -1,
					.source_raddr = {
						.x = 1, .y = 2, .z = 3,
					},
					.source_rtni = 1,
					.source_rgate = 7,
					.dest_lgate = 8,
					.dest_raddr = {
						.x = 4, .y = 5, .z = 6,
					},
					.dest_rtni = 2,
					.dest_rgate = -1,
				};

				tofu_reset_utofu_set_bg_fakes();
				tofu_utofu_bg_slot.subnet = subnet;
				tofu_utofu_bg_slot.gpid = 0x55;
				require(tofu_utofu_set_bg_after_copy_body_result(
					&tofu_utofu_ubch_token, &req, 1000, 0x66,
					TOF_ICC_NTNIS, TOF_ICC_NBGS,
					tofu_fake_utofu_bg_get, tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == 0);
				require(tofu_utofu_bg_get_count == 1);
				require(tofu_utofu_bg_last_tni == 2);
				require(tofu_utofu_bg_last_bgid == 5);
				require(tofu_utofu_meta_count == 1);
				require(tofu_utofu_core_set_count == 1);
				require(tofu_utofu_core_set_last_req == &req);
				require(tofu_utofu_core_set_last_subnet == subnet);
				require(tofu_utofu_core_set_last_bseq == 0x66);
				require(tofu_utofu_core_set_last_gpid == 0x55);
				require(tofu_utofu_set_enabled_count == 1);
				require(tofu_utofu_bg_slot.enabled == 1);
				require(tofu_utofu_bgmask_set_count == 1);
				require(tofu_utofu_bgmask_model[2] == (1UL << 5));
				require(tofu_utofu_register_signal_count == 1);
				require(tofu_utofu_register_last_tni == 2);
				require(tofu_utofu_register_last_bgid == 5);
				require(tofu_utofu_register_last_handler == tofu_fake_signal);
				require(tofu_error_log_count == 0);
				mix(&digest, tofu_utofu_core_set_last_subnet ^
					tofu_utofu_bgmask_model[2] ^
					(unsigned long)tofu_utofu_register_signal_count);

				tofu_reset_utofu_set_bg_fakes();
				tofu_utofu_bg_slot.subnet = subnet;
				req.source_raddr.x = 9;
				require(tofu_utofu_set_bg_after_copy_body_result(
					&tofu_utofu_ubch_token, &req, 1000, 0x66,
					TOF_ICC_NTNIS, TOF_ICC_NBGS,
					tofu_fake_utofu_bg_get, tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == -22);
				require(tofu_error_log_count == 1);
				require(tofu_error_log_last == -22);
				require(tofu_utofu_core_set_count == 0);
				require(tofu_utofu_set_enabled_count == 0);
				req.source_raddr.x = 1;

				tofu_reset_utofu_set_bg_fakes();
				tofu_utofu_bg_slot.subnet = subnet;
				tofu_utofu_bg_slot.enabled = 1;
				require(tofu_utofu_set_bg_after_copy_body_result(
					&tofu_utofu_ubch_token, &req, 1000, 0x66,
					TOF_ICC_NTNIS, TOF_ICC_NBGS,
					tofu_fake_utofu_bg_get, tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == -EBUSY);
				require(tofu_error_log_count == 0);
				require(tofu_utofu_core_set_count == 0);
				require(tofu_utofu_set_enabled_count == 0);

				tofu_reset_utofu_set_bg_fakes();
				tofu_utofu_bg_slot.subnet = subnet;
				tofu_utofu_core_set_result = -77;
				require(tofu_utofu_set_bg_after_copy_body_result(
					&tofu_utofu_ubch_token, &req, 1000, 0x66,
					TOF_ICC_NTNIS, TOF_ICC_NBGS,
					tofu_fake_utofu_bg_get, tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == -77);
				require(tofu_error_log_count == 1);
				require(tofu_error_log_last == -77);
				require(tofu_utofu_set_enabled_count == 0);
				require(tofu_utofu_bgmask_set_count == 0);
				require(tofu_utofu_register_signal_count == 0);

				tofu_reset_utofu_set_bg_fakes();
				tofu_utofu_bg_get_null = 1;
				require(tofu_utofu_set_bg_after_copy_body_result(
					&tofu_utofu_ubch_token, &req, 1000, 0x66,
					TOF_ICC_NTNIS, TOF_ICC_NBGS,
					tofu_fake_utofu_bg_get, tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == -22);
				require(tofu_error_log_count == 1);
				require(tofu_utofu_meta_count == 0);

				tofu_reset_utofu_set_bg_fakes();
				require(tofu_utofu_set_bg_after_copy_body_result(
					0, &req, 1000, 0x66, TOF_ICC_NTNIS,
					TOF_ICC_NBGS, tofu_fake_utofu_bg_get,
					tofu_fake_utofu_meta,
					tofu_fake_utofu_set_enabled,
					tofu_fake_utofu_core_set_bg,
					tofu_fake_utofu_bgmask_set,
					tofu_fake_utofu_register_signal,
					tofu_fake_signal, tofu_fake_error_log) == -22);
				require(tofu_utofu_bg_get_count == 0);
			require(tofu_utofu_set_bg_after_copy_body_result(
				&tofu_utofu_ubch_token, &req, 1000, 0x66,
				TOF_ICC_NTNIS, TOF_ICC_NBGS, 0,
				tofu_fake_utofu_meta,
				tofu_fake_utofu_set_enabled,
				tofu_fake_utofu_core_set_bg,
				tofu_fake_utofu_bgmask_set,
				tofu_fake_utofu_register_signal,
				tofu_fake_signal, tofu_fake_error_log) == -22);
			require(tofu_utofu_bg_get_count == 0);
		}
		{
			struct tof_set_bg req = { .tni = 3, .gate = 9 };
			unsigned long unset_mix = 0;

			tofu_reset_utofu_set_bg_fakes();
			require(tofu_utofu_unset_bg_after_copy_body_result(
				&req, tofu_fake_utofu_bg_get,
				tofu_fake_utofu_unset_ptr) == 0);
			require(tofu_utofu_bg_get_count == 1);
			require(tofu_utofu_bg_last_tni == 3);
			require(tofu_utofu_bg_last_bgid == 9);
			require(tofu_utofu_unset_ptr_count == 1);
			unset_mix ^= ((unsigned long)tofu_utofu_bg_get_count << 16) |
				((unsigned long)tofu_utofu_unset_ptr_count << 8) |
				(unsigned long)tofu_utofu_bg_last_bgid;

			tofu_reset_utofu_set_bg_fakes();
			tofu_utofu_unset_ptr_result = -55;
			require(tofu_utofu_unset_bg_after_copy_body_result(
				&req, tofu_fake_utofu_bg_get,
				tofu_fake_utofu_unset_ptr) == -55);
			require(tofu_utofu_bg_get_count == 1);
			require(tofu_utofu_unset_ptr_count == 1);
			unset_mix ^= ((unsigned long)tofu_utofu_bg_get_count << 12) |
				((unsigned long)tofu_utofu_unset_ptr_count << 4);

			tofu_reset_utofu_set_bg_fakes();
			tofu_utofu_bg_get_null = 1;
			require(tofu_utofu_unset_bg_after_copy_body_result(
				&req, tofu_fake_utofu_bg_get,
				tofu_fake_utofu_unset_ptr) == -EINVAL);
			require(tofu_utofu_bg_get_count == 1);
			require(tofu_utofu_unset_ptr_count == 0);

			tofu_reset_utofu_set_bg_fakes();
			require(tofu_utofu_unset_bg_after_copy_body_result(
				0, tofu_fake_utofu_bg_get,
				tofu_fake_utofu_unset_ptr) == -EINVAL);
			require(tofu_utofu_bg_get_count == 0);
			require(tofu_utofu_unset_bg_after_copy_body_result(
				&req, 0, tofu_fake_utofu_unset_ptr) == -EINVAL);
			require(tofu_utofu_bg_get_count == 0);
			require(tofu_utofu_unset_bg_after_copy_body_result(
				&req, tofu_fake_utofu_bg_get, 0) == -EINVAL);
			require(tofu_utofu_bg_get_count == 0);
			mix(&digest, unset_mix);
		}
		{
			void (*slot)(int, int, unsigned long, unsigned long) = 0;

			tofu_lock_count = 0;
			tofu_unlock_count = 0;
			tofu_signal_count = 0;
			require(tofu_core_register_signal_bg_body_result(&slot,
				&tofu_lock_token, tofu_fake_signal, tofu_fake_lock,
				tofu_fake_unlock) == 0);
			require(slot == tofu_fake_signal);
			require(tofu_lock_count == 1);
			require(tofu_unlock_count == 1);
			slot(1, 2, 3, 4);
			require(tofu_signal_count == 1);
			require(tofu_core_register_signal_bg_body_result(&slot,
				&tofu_lock_token, 0, tofu_fake_lock,
				tofu_fake_unlock) == 0);
			require(slot == 0);
			require(tofu_lock_count == 2);
			require(tofu_unlock_count == 2);
			require(tofu_core_register_signal_bg_body_result(0,
				&tofu_lock_token, tofu_fake_signal, tofu_fake_lock,
				tofu_fake_unlock) == -22);
			require(tofu_core_register_signal_bg_body_result(&slot,
				&tofu_lock_token, tofu_fake_signal, 0,
				tofu_fake_unlock) == -22);
			require(tofu_core_register_signal_bg_body_result(&slot,
				&tofu_lock_token, tofu_fake_signal, tofu_fake_lock,
				0) == -22);
			mix(&digest, ((unsigned long)tofu_lock_count << 8) |
				(unsigned long)tofu_unlock_count);
		}
		{
			char bch_reg;
			char bgs_reg;

			tofu_writeq_count = 0;
			tofu_readq_spin_count = 0;
			tofu_readq_spin_result = 1;
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123400UL, TOF_ICC_BCH_DMA_ALIGN,
				0xbeefUL, tofu_fake_writeq,
				tofu_fake_readq_spin) == 0);
			require(tofu_writeq_count == 2);
			require(tofu_writeq_values[0] == 0x123400UL);
			require(tofu_writeq_regs[0] == &bgs_reg);
			require(tofu_writeq_offsets[0] ==
				TOF_ICC_REG_BGS_BCH_NOTICE_IPA);
			require(tofu_writeq_values[1] == 0);
			require(tofu_writeq_regs[1] == &bgs_reg);
			require(tofu_writeq_offsets[1] ==
				TOF_ICC_REG_BGS_BCH_MASK);
			require(tofu_readq_spin_count == 1);
			require(tofu_readq_spin_last_reg == &bgs_reg);
			require(tofu_readq_spin_last_offset ==
				TOF_ICC_REG_BGS_BCH_MASK_STATUS);
			require(tofu_readq_spin_last_mask ==
				TOF_ICC_REG_BGS_BCH_MASK_STATUS_RUN);
			require(tofu_readq_spin_last_expect == 0);
			require(tofu_readq_spin_last_timeout == 0xbeefUL);

			tofu_writeq_count = 0;
			tofu_readq_spin_count = 0;
			tofu_readq_spin_result = 0;
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123400UL, TOF_ICC_BCH_DMA_ALIGN,
				0xbeefUL, tofu_fake_writeq,
				tofu_fake_readq_spin) == -ETIMEDOUT);
			require(tofu_writeq_count == 2);
			require(tofu_readq_spin_count == 1);

			tofu_writeq_count = 0;
			tofu_readq_spin_count = 0;
			require(tofu_core_enable_bch_body_result(0, &bgs_reg,
				0x123400UL, TOF_ICC_BCH_DMA_ALIGN, 0xbeefUL,
				tofu_fake_writeq, tofu_fake_readq_spin) == -22);
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123401UL, TOF_ICC_BCH_DMA_ALIGN,
				0xbeefUL, tofu_fake_writeq,
				tofu_fake_readq_spin) == -22);
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123400UL, 0, 0xbeefUL,
				tofu_fake_writeq, tofu_fake_readq_spin) == -22);
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123400UL, TOF_ICC_BCH_DMA_ALIGN,
				0xbeefUL, 0, tofu_fake_readq_spin) == -22);
			require(tofu_core_enable_bch_body_result(&bch_reg,
				&bgs_reg, 0x123400UL, TOF_ICC_BCH_DMA_ALIGN,
				0xbeefUL, tofu_fake_writeq, 0) == -22);
			require(tofu_writeq_count == 0);
			require(tofu_readq_spin_count == 0);
			mix(&digest, tofu_writeq_values[0] ^
				((unsigned long)tofu_writeq_offsets[1] << 16) ^
				(unsigned long)tofu_readq_spin_last_timeout);

			tofu_writeq_count = 0;
			require(tofu_core_bch_disable_locked_body_result(&bch_reg,
				&bgs_reg, tofu_fake_writeq) == 0);
			require(tofu_writeq_count == 1);
			require(tofu_writeq_last_val ==
				TOF_ICC_REG_BGS_BCH_MASK_MASK);
			require(tofu_writeq_last_reg == &bgs_reg);
			require(tofu_writeq_last_offset ==
				TOF_ICC_REG_BGS_BCH_MASK);
			require(tofu_core_bch_disable_locked_body_result(0,
				&bgs_reg, tofu_fake_writeq) == -22);
			require(tofu_core_bch_disable_locked_body_result(&bch_reg,
				&bgs_reg, 0) == -22);
			require(tofu_writeq_count == 1);
			require(tofu_core_bg_disable_body_result(&bgs_reg,
				tofu_fake_writeq) == 0);
			require(tofu_writeq_count == 2);
			require(tofu_writeq_last_val == 0);
			require(tofu_writeq_last_reg == &bgs_reg);
			require(tofu_writeq_last_offset == TOF_ICC_REG_BGS_ENABLE);
			require(tofu_core_bg_disable_body_result(&bgs_reg, 0)
				== -22);
			require(tofu_writeq_count == 2);
			mix(&digest, tofu_writeq_last_val ^
				((unsigned long)tofu_writeq_last_offset << 16) ^
				(unsigned long)tofu_writeq_count);
		}
		{
			unsigned char enabled;
			unsigned long masks[TOF_ICC_NTNIS] = { 0 };

			enabled = 0;
			tofu_disable_bch_count = 0;
			tofu_unset_by_id_count = 0;
			tofu_error_log_count = 0;
			tofu_wmb_count = 0;
			tofu_disable_bch_result = 0;
			tofu_unset_by_id_fail_tni = -1;
			tofu_unset_by_id_fail_bgid = -1;
			require(tofu_utofu_disable_bch_body_result(&enabled, 2, 3,
				masks, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -1);
			require(tofu_disable_bch_count == 0);
			require(tofu_unset_by_id_count == 0);
			require(tofu_wmb_count == 0);

			enabled = 1;
			tofu_disable_bch_result = -44;
			require(tofu_utofu_disable_bch_body_result(&enabled, 4, 5,
				masks, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -44);
			require(enabled == 1);
			require(tofu_disable_bch_count == 1);
			require(tofu_disable_bch_last_tni == 4);
			require(tofu_disable_bch_last_bgid == 5);
			require(tofu_error_log_count == 1);
			require(tofu_error_log_last == -44);
			require(tofu_unset_by_id_count == 0);
			require(tofu_wmb_count == 0);

			enabled = 1;
			masks[0] = (1UL << 1) | (1UL << 4);
			masks[2] = (1UL << 3);
			tofu_disable_bch_count = 0;
			tofu_unset_by_id_count = 0;
			tofu_error_log_count = 0;
			tofu_wmb_count = 0;
			tofu_disable_bch_result = 0;
			require(tofu_utofu_disable_bch_body_result(&enabled, 6, 7,
				masks, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == 0);
			require(enabled == 0);
			require(tofu_disable_bch_count == 1);
			require(tofu_unset_by_id_count == 3);
			require(tofu_unset_by_id_order[0] == 1);
			require(tofu_unset_by_id_order[1] == 4);
			require(tofu_unset_by_id_order[2] == 2 * 64 + 3);
			require(tofu_error_log_count == 0);
			require(tofu_wmb_count == 1);
			mix(&digest, ((unsigned long)tofu_unset_by_id_count << 16) |
				(unsigned long)tofu_wmb_count);

			enabled = 1;
			tofu_unset_by_id_count = 0;
			tofu_wmb_count = 0;
			tofu_unset_by_id_fail_tni = 2;
			tofu_unset_by_id_fail_bgid = 3;
			require(tofu_utofu_disable_bch_body_result(&enabled, 6, 7,
				masks, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -77);
			require(enabled == 1);
			require(tofu_unset_by_id_count == 3);
			require(tofu_wmb_count == 0);
			tofu_unset_by_id_fail_tni = -1;
			tofu_unset_by_id_fail_bgid = -1;

			require(tofu_utofu_disable_bch_body_result(0, 1, 2,
				masks, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -22);
			require(tofu_utofu_disable_bch_body_result(&enabled, 1, 2,
				0, TOF_ICC_NTNIS, TOF_ICC_NBGS,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -22);
			require(tofu_utofu_disable_bch_body_result(&enabled, 1, 2,
				masks, TOF_ICC_NTNIS, 65,
				tofu_fake_disable_bch, tofu_fake_unset_bg_by_id,
				tofu_fake_error_log, tofu_fake_wmb) == -22);
		}
		{
			struct tofu_bch_device_fixture {
				char prefix[37];
				char common;
			} fixture;
			void *dev = &fixture.common;
			unsigned long offset = (unsigned long)
				((char *)&fixture.common - (char *)&fixture);

			tofu_bch_device_expected_bg = &fixture;
			tofu_bch_device_log_count = 0;
			tofu_bch_device_disable_count = 0;
			tofu_bch_device_disable_result = 0;
			tofu_bch_device_last_log_bg = 0;
			tofu_bch_device_last_disable_bg = 0;
			require(tofu_utofu_bch_device_disable_body_result(dev,
				offset, tofu_fake_bch_device_log,
				tofu_fake_bch_device_disable) == 0);
			require(tofu_bch_device_log_count == 1);
			require(tofu_bch_device_disable_count == 1);
			require(tofu_bch_device_last_log_bg == &fixture);
			require(tofu_bch_device_last_disable_bg == &fixture);

			tofu_bch_device_log_count = 0;
			tofu_bch_device_disable_count = 0;
			tofu_bch_device_disable_result = -91;
			require(tofu_utofu_bch_device_disable_body_result(dev,
				offset, tofu_fake_bch_device_log,
				tofu_fake_bch_device_disable) == -91);
			require(tofu_bch_device_log_count == 1);
			require(tofu_bch_device_disable_count == 1);

			tofu_bch_device_log_count = 0;
			tofu_bch_device_disable_count = 0;
			require(tofu_utofu_bch_device_disable_body_result(0,
				offset, tofu_fake_bch_device_log,
				tofu_fake_bch_device_disable) == -EINVAL);
			require(tofu_bch_device_log_count == 0);
			require(tofu_bch_device_disable_count == 0);
			require(tofu_utofu_bch_device_disable_body_result(dev,
				offset, 0, tofu_fake_bch_device_disable) == -EINVAL);
			require(tofu_bch_device_log_count == 0);
			require(tofu_bch_device_disable_count == 0);
			require(tofu_utofu_bch_device_disable_body_result(dev,
				offset, tofu_fake_bch_device_log, 0) == -EINVAL);
			require(tofu_bch_device_log_count == 0);
			require(tofu_bch_device_disable_count == 0);
			mix(&digest, ((unsigned long)tofu_bch_device_log_count << 8) |
				(unsigned long)offset);
		}
		{
			tofu_reset_lifecycle_fakes();
			require(tofu_utofu_init_globals_body_result(
				tofu_fake_get_globals, tofu_fake_init_publish,
				tofu_fake_init_unavailable_log,
				tofu_fake_init_globals_log,
				tofu_fake_init_clear_caches,
				tofu_fake_init_lock, 2, 3,
				tofu_fake_init_done_log) == 0);
			require(tofu_get_globals_count == 1);
			require(tofu_init_publish_count == 1);
			require(tofu_init_unavailable_log_count == 0);
			require(tofu_init_globals_log_count == 1);
			require(tofu_init_clear_caches_count == 1);
			require(tofu_init_lock_count == 6);
			require(tofu_init_lock_order[0] == 0);
			require(tofu_init_lock_order[1] == 1);
			require(tofu_init_lock_order[2] == 2);
			require(tofu_init_lock_order[3] == 16);
			require(tofu_init_lock_order[5] == 18);
			require(tofu_init_done_log_count == 1);
			mix(&digest, ((unsigned long)tofu_init_lock_count << 24) |
				((unsigned long)tofu_init_lock_order[3] << 8) |
				(unsigned long)tofu_init_done_log_count);

			tofu_reset_lifecycle_fakes();
			tofu_get_globals_null = 1;
			require(tofu_utofu_init_globals_body_result(
				tofu_fake_get_globals, tofu_fake_init_publish,
				tofu_fake_init_unavailable_log,
				tofu_fake_init_globals_log,
				tofu_fake_init_clear_caches,
				tofu_fake_init_lock, 2, 3,
				tofu_fake_init_done_log) == 0);
			require(tofu_get_globals_count == 1);
			require(tofu_init_unavailable_log_count == 1);
			require(tofu_init_publish_count == 0);
			require(tofu_init_lock_count == 0);
			require(tofu_init_done_log_count == 0);

			tofu_reset_lifecycle_fakes();
			require(tofu_utofu_init_globals_body_result(
				0, tofu_fake_init_publish,
				tofu_fake_init_unavailable_log,
				tofu_fake_init_globals_log,
				tofu_fake_init_clear_caches,
				tofu_fake_init_lock, 2, 3,
				tofu_fake_init_done_log) == -EINVAL);
			require(tofu_get_globals_count == 0);
			require(tofu_utofu_init_globals_body_result(
				tofu_fake_get_globals, tofu_fake_init_publish,
				tofu_fake_init_unavailable_log,
				tofu_fake_init_globals_log,
				tofu_fake_init_clear_caches,
				tofu_fake_init_lock, -1, 3,
				tofu_fake_init_done_log) == -EINVAL);
			require(tofu_get_globals_count == 0);

			tofu_reset_lifecycle_fakes();
			tofu_finalize_current_enabled = 1;
			tofu_finalize_clear_result = -5;
			require(tofu_utofu_finalize_body_result(
				tofu_fake_get_globals,
				tofu_fake_finalize_current_enabled,
				tofu_fake_finalize_scan,
				tofu_fake_finalize_scan_done,
				tofu_fake_finalize_clear_range) == -5);
			require(tofu_get_globals_count == 1);
			require(tofu_finalize_current_count == 1);
			require(tofu_finalize_scan_count == 1);
			require(tofu_finalize_scan_done_count == 1);
			require(tofu_finalize_clear_count == 1);
			require(tofu_finalize_clear_start ==
				(void *)tofu_globals_slot.linux_vmalloc_start);
			require(tofu_finalize_clear_end ==
				(void *)tofu_globals_slot.linux_vmalloc_end);
			mix(&digest, (unsigned long)tofu_finalize_clear_count);
			mix(&digest, (unsigned long)tofu_finalize_clear_start);
			mix(&digest, (unsigned long)tofu_finalize_clear_end);

			tofu_reset_lifecycle_fakes();
			require(tofu_utofu_finalize_body_result(
				tofu_fake_get_globals,
				tofu_fake_finalize_current_enabled,
				tofu_fake_finalize_scan,
				tofu_fake_finalize_scan_done,
				tofu_fake_finalize_clear_range) == 0);
			require(tofu_finalize_current_count == 1);
			require(tofu_finalize_scan_count == 0);
			require(tofu_finalize_scan_done_count == 0);
			require(tofu_finalize_clear_count == 1);

			tofu_reset_lifecycle_fakes();
			tofu_get_globals_null = 1;
			require(tofu_utofu_finalize_body_result(
				tofu_fake_get_globals,
				tofu_fake_finalize_current_enabled,
				tofu_fake_finalize_scan,
				tofu_fake_finalize_scan_done,
				tofu_fake_finalize_clear_range) == 0);
			require(tofu_get_globals_count == 1);
			require(tofu_finalize_current_count == 0);
			require(tofu_finalize_clear_count == 0);

			tofu_reset_lifecycle_fakes();
			require(tofu_utofu_finalize_body_result(0,
				tofu_fake_finalize_current_enabled,
				tofu_fake_finalize_scan,
				tofu_fake_finalize_scan_done,
				tofu_fake_finalize_clear_range) == -EINVAL);
			require(tofu_get_globals_count == 0);
		}
		{
			void *ucq = (void *)0xbeef0000UL;

			tofu_reset_release_cq_fakes();
			require(tofu_utofu_release_cq_body_result(ucq, 1, 4, 7, 3,
				tofu_fake_release_cq_disabled_log,
				tofu_fake_release_cq_drain,
				tofu_fake_release_cq_free_stag,
				tofu_fake_release_cq_done) == 0);
			require(tofu_release_cq_disabled_log_count == 0);
			require(tofu_release_cq_drain_count == 1);
			require(tofu_release_cq_drain_do_free == 1);
			require(tofu_release_cq_free_count == 3);
			require(tofu_release_cq_free_order[0] == 0);
			require(tofu_release_cq_free_order[1] == 1);
			require(tofu_release_cq_free_order[2] == 2);
			require(tofu_release_cq_done_count == 1);

			tofu_reset_release_cq_fakes();
			require(tofu_utofu_release_cq_body_result(ucq, 0, 5, 8, 3,
				tofu_fake_release_cq_disabled_log,
				tofu_fake_release_cq_drain,
				tofu_fake_release_cq_free_stag,
				tofu_fake_release_cq_done) == 0);
			require(tofu_release_cq_disabled_log_count == 1);
			require(tofu_release_cq_disabled_tni == 5);
			require(tofu_release_cq_disabled_cqid == 8);
			require(tofu_release_cq_drain_count == 1);
			require(tofu_release_cq_drain_do_free == 0);
			require(tofu_release_cq_free_count == 0);
			require(tofu_release_cq_done_count == 1);

			require(tofu_utofu_release_cq_body_result(0, 1, 1, 1, 1,
				tofu_fake_release_cq_disabled_log,
				tofu_fake_release_cq_drain,
				tofu_fake_release_cq_free_stag,
				tofu_fake_release_cq_done) == -EINVAL);
			require(tofu_utofu_release_cq_body_result(ucq, 1, 1, 1, -1,
				tofu_fake_release_cq_disabled_log,
				tofu_fake_release_cq_drain,
				tofu_fake_release_cq_free_stag,
				tofu_fake_release_cq_done) == -EINVAL);
			require(tofu_utofu_release_cq_body_result(ucq, 1, 1, 1, 1,
				0, tofu_fake_release_cq_drain,
				tofu_fake_release_cq_free_stag,
				tofu_fake_release_cq_done) == -EINVAL);
			require(tofu_utofu_release_cq_body_result(ucq, 1, 1, 1, 1,
				tofu_fake_release_cq_disabled_log,
				tofu_fake_release_cq_drain, 0,
				tofu_fake_release_cq_done) == -EINVAL);
			mix(&digest,
				((unsigned long)tofu_release_cq_drain_count << 24) |
				((unsigned long)tofu_release_cq_done_count << 16) |
				(unsigned long)tofu_release_cq_disabled_log_count);
		}
		{
			void *ucq = (void *)0xbeef0000UL;

			tofu_reset_alloc_new_fakes();
			require(tofu_utofu_alloc_new_steering_body_result(ucq, 9,
				0x101234UL, 0x109234UL, 12, 0x200UL, 1,
				0xffffffffffffffffUL, 4096, 8, 1, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc,
				tofu_fake_alloc_new_timestamp,
				tofu_fake_alloc_new_profile) == 0);
			require(tofu_alloc_new_calc_count == 1);
			require(tofu_alloc_new_calc_mbpt_npages == 512);
			require(tofu_alloc_new_alloc_count == 1);
			require(tofu_alloc_new_alloc_npages == 512);
			require(tofu_alloc_new_alloc_stag == 9);
			require(tofu_alloc_new_set_meta_count == 1);
			require(tofu_alloc_new_mbpt.mbptstart == 0x100000UL);
			require(tofu_alloc_new_mbpt.pgsz == 4096);
			require(tofu_alloc_new_update_count == 1);
			require(tofu_alloc_new_update_ix == 1);
			require(tofu_alloc_new_update_pgsz == 4096);
			require(tofu_alloc_new_update_readonly == 1);
			require(tofu_alloc_new_enable_mb_count == 1);
			require(tofu_alloc_new_enable_mb_iova == 0x44440000UL);
			require(tofu_alloc_new_enable_mb_pgszbits == 12);
			require(tofu_alloc_new_enable_mb_npages == 512);
			require(tofu_alloc_new_enable_steering_count == 1);
			require(tofu_alloc_new_enable_steering_mbva == 0x1434UL);
			require(tofu_alloc_new_enable_steering_len == 0x7e00UL);
			require(tofu_alloc_new_enable_steering_readonly == 1);
			require(tofu_alloc_new_trans_enable_count == 1);
			require(tofu_alloc_new_trans_start == 0x101234UL);
			require(tofu_alloc_new_trans_len == 0x8000UL);
			require(tofu_alloc_new_trans_mbptstart == 0x100000UL);
			require(tofu_alloc_new_trans_mbptlen == 4096);
			require(tofu_alloc_new_profile_count == 3);
			require(tofu_alloc_new_profile_events[0] == 101);
			require(tofu_alloc_new_profile_events[1] == 102);
			require(tofu_alloc_new_profile_events[2] == 103);
			require(tofu_alloc_new_profile_elapsed[0] == 10);
			require(tofu_alloc_new_profile_elapsed[1] == 10);
			require(tofu_alloc_new_profile_elapsed[2] == 40);

			tofu_reset_alloc_new_fakes();
			require(tofu_utofu_alloc_new_steering_body_result(ucq, 9,
				0x101234UL, 0x109234UL, 12,
				0xffffffffffffffffUL, 0,
				0xffffffffffffffffUL, 4096, 8, 0, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc, 0, 0) == 0);
			require(tofu_alloc_new_enable_steering_mbva == 0);
			require(tofu_alloc_new_enable_steering_len == 0x9234UL);
			require(tofu_alloc_new_profile_count == 0);

			tofu_reset_alloc_new_fakes();
			tofu_alloc_new_update_result = -77;
			require(tofu_utofu_alloc_new_steering_body_result(ucq, 9,
				0x101234UL, 0x109234UL, 12, 0x200UL, 1,
				0xffffffffffffffffUL, 4096, 8, 0, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc, 0, 0) == -77);
			require(tofu_alloc_new_raw_rc_count == 1);
			require(tofu_alloc_new_raw_rc_last == -77);
			require(tofu_alloc_new_free_count == 1);
			require(tofu_alloc_new_enable_mb_count == 0);

			tofu_reset_alloc_new_fakes();
			tofu_alloc_new_alloc_result = -12;
			require(tofu_utofu_alloc_new_steering_body_result(ucq, 9,
				0x101234UL, 0x109234UL, 12, 0x200UL, 1,
				0xffffffffffffffffUL, 4096, 8, 0, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc, 0, 0) == -12);
			require(tofu_alloc_new_raw_rc_last == -12);
			require(tofu_alloc_new_set_meta_count == 0);

			require(tofu_utofu_alloc_new_steering_body_result(ucq, 9,
				0x101234UL, 0x109234UL, 12, 0x200UL, 1,
				0xffffffffffffffffUL, 4096, 8, 1, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc, 0,
				tofu_fake_alloc_new_profile) == -EINVAL);
			require(tofu_utofu_alloc_new_steering_body_result(0, 9,
				0x101234UL, 0x109234UL, 12, 0x200UL, 1,
				0xffffffffffffffffUL, 4096, 8, 0, 101, 102, 103,
				tofu_fake_alloc_new_calc,
				tofu_fake_alloc_new_alloc_mbpt,
				tofu_fake_alloc_new_set_meta,
				tofu_fake_alloc_new_iova,
				tofu_fake_alloc_new_update,
				tofu_fake_alloc_new_free,
				tofu_fake_alloc_new_enable_mb,
				tofu_fake_alloc_new_enable_steering,
				tofu_fake_alloc_new_trans_enable,
				tofu_fake_alloc_new_raw_rc, 0, 0) == -EINVAL);
			mix(&digest,
				((unsigned long)tofu_alloc_new_calc_count << 24) |
				((unsigned long)tofu_alloc_new_alloc_count << 16) |
				((unsigned long)tofu_alloc_new_update_count << 8) |
				(unsigned long)tofu_alloc_new_raw_rc_count);
			mix(&digest, tofu_alloc_new_trans_mbptlen ^
				tofu_alloc_new_enable_steering_len);
		}
		{
			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_ucq_enabled = 0;
			require(tofu_call_alloc_stag() == -EPERM);
			require(tofu_alloc_stag_dev_to_cq_count == 1);
			require(tofu_alloc_stag_ucq_enabled_count == 1);
			require(tofu_alloc_stag_copyin_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_copyin_result = -EFAULT;
			require(tofu_call_alloc_stag() == -EFAULT);
			require(tofu_alloc_stag_copyin_count == 1);
			require(tofu_alloc_stag_vm_lock_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.stag = TOF_UTOFU_SPECIAL_STAG;
			require(tofu_call_alloc_stag() == -EINVAL);
			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.va = 0;
			require(tofu_call_alloc_stag() == -EINVAL);
			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.len = 0;
			require(tofu_call_alloc_stag() == -EINVAL);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.flags = 1;
			tofu_alloc_stag_trans_result = 77;
			require(tofu_call_alloc_stag() == 0);
			require(tofu_alloc_stag_out.stag == 77);
			require(tofu_alloc_stag_out.offset == 0x2345UL);
			require(tofu_alloc_stag_lookup_start[0] == 0x12000UL);
			require(tofu_alloc_stag_lookup_end[0] == 0x15000UL);
			require(tofu_alloc_stag_trans_start == 0x12000UL);
			require(tofu_alloc_stag_trans_end == 0x15000UL);
			require(tofu_alloc_stag_trans_pgszbits == PAGE_SHIFT);
			require(tofu_alloc_stag_trans_readonly == 1);
			require(tofu_alloc_stag_reserve_count == 0);
			require(tofu_alloc_stag_alloc_new_count == 0);
			require(tofu_alloc_stag_get_mbpt_count == 1);
			require(tofu_alloc_stag_range_insert_count == 1);
			require(tofu_alloc_stag_copyout_count == 1);
			require(tofu_alloc_stag_vm_lock_count == 1);
			require(tofu_alloc_stag_vm_unlock_count == 1);
			require(tofu_alloc_stag_cq_lock_count == 1);
			require(tofu_alloc_stag_cq_unlock_count == 1);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_trans_result = -1;
			tofu_alloc_stag_reserve_result = 88;
			require(tofu_call_alloc_stag() == 0);
			require(tofu_alloc_stag_out.stag == 88);
			require(tofu_alloc_stag_reserve_count == 1);
			require(tofu_alloc_stag_alloc_new_count == 1);
			require(tofu_alloc_stag_alloc_new_stag == 88);
			require(tofu_alloc_stag_alloc_new_plus_mbva ==
				TOF_UTOFU_BLANK_MBVA);
			require(tofu_alloc_stag_range_insert_count == 1);
			require(tofu_alloc_stag_release_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_trans_result = -1;
			tofu_alloc_stag_reserve_result = -1;
			require(tofu_call_alloc_stag() == -ENOSPC);
			require(tofu_alloc_stag_reserve_count == 1);
			require(tofu_alloc_stag_alloc_new_count == 0);
			require(tofu_alloc_stag_copyout_count == 0);
			require(tofu_alloc_stag_cq_unlock_count == 1);
			require(tofu_alloc_stag_vm_unlock_count == 1);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_trans_result = -1;
			tofu_alloc_stag_reserve_result = 88;
			tofu_alloc_stag_alloc_new_result = -77;
			require(tofu_call_alloc_stag() == -77);
			require(tofu_alloc_stag_release_count == 1);
			require(tofu_alloc_stag_release_stag == 88);
			require(tofu_alloc_stag_range_insert_count == 0);
			require(tofu_alloc_stag_copyout_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.flags = 1;
			tofu_alloc_stag_req.stag = 7;
			require(tofu_call_alloc_stag() == 0);
			require(tofu_alloc_stag_trans_count == 0);
			require(tofu_alloc_stag_reserve_count == 0);
			require(tofu_alloc_stag_alloc_new_stag == 7);
			require(tofu_alloc_stag_alloc_new_plus_mbva == 0x300UL);
			require(tofu_alloc_stag_alloc_new_readonly == 1);
			require(tofu_alloc_stag_out.offset == 0x45UL);
			require(tofu_alloc_stag_range_stag == 7);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.stag = 7;
			tofu_alloc_stag_steering_stag = 7;
			tofu_alloc_stag_steering_result = 1;
			require(tofu_call_alloc_stag() == -EBUSY);
			require(tofu_alloc_stag_steering_count == 1);
			require(tofu_alloc_stag_vm_lock_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.stag = 7;
			tofu_alloc_stag_steering_stag = 7;
			tofu_alloc_stag_steering_after_count = 1;
			tofu_alloc_stag_steering_after_result = 1;
			require(tofu_call_alloc_stag() == -EBUSY);
			require(tofu_alloc_stag_steering_count == 2);
			require(tofu_alloc_stag_cq_lock_count == 1);
			require(tofu_alloc_stag_cq_unlock_count == 1);
			require(tofu_alloc_stag_alloc_new_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_req.flags = TOF_UTOFU_ALLOC_STAG_LPG | 1;
			tofu_alloc_stag_pagesize_bits = 16;
			require(tofu_call_alloc_stag() == 0);
			require(tofu_alloc_stag_pagesize_count == 1);
			require(tofu_alloc_stag_pagesize_readonly == 1);
			require(tofu_alloc_stag_trans_start == 0x10000UL);
			require(tofu_alloc_stag_trans_end == 0x20000UL);
			require(tofu_alloc_stag_trans_pgszbits == 16);
			require(tofu_alloc_stag_range_start == 0x10000UL);
			require(tofu_alloc_stag_range_end == 0x20000UL);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_lookup_failures = 1;
			tofu_alloc_stag_stack_faultable = 1;
			require(tofu_call_alloc_stag() == 0);
			require(tofu_alloc_stag_lookup_count == 2);
			require(tofu_alloc_stag_page_fault_count == 1);
			require(tofu_alloc_stag_vm_lock_count == 2);
			require(tofu_alloc_stag_vm_unlock_count == 2);
			require(tofu_alloc_stag_copyout_count == 1);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_lookup_failures = 1;
			tofu_alloc_stag_stack_faultable = 1;
			tofu_alloc_stag_page_fault_result = -5;
			require(tofu_call_alloc_stag() == -EINVAL);
			require(tofu_alloc_stag_lookup_count == 1);
			require(tofu_alloc_stag_page_fault_count == 1);
			require(tofu_alloc_stag_cq_lock_count == 0);
			require(tofu_alloc_stag_copyout_count == 0);

			tofu_reset_alloc_stag_fakes();
			tofu_alloc_stag_copyout_result = -EFAULT;
			require(tofu_call_alloc_stag() == -EFAULT);
			require(tofu_alloc_stag_range_insert_count == 1);
			require(tofu_alloc_stag_copyout_count == 1);

			tofu_reset_alloc_stag_fakes();
			require(tofu_utofu_ioctl_alloc_stag_body_result(
				TOFU_ALLOC_STAG_DEV, TOFU_ALLOC_STAG_ARG,
				TOF_UTOFU_SPECIAL_STAG,
				TOF_UTOFU_ALLOC_STAG_LPG, TOF_UTOFU_BLANK_MBVA,
				4096, 12, 256, 0,
				tofu_fake_alloc_stag_current_vm,
				tofu_fake_alloc_stag_copyin,
				tofu_fake_alloc_stag_copyout,
				tofu_fake_alloc_stag_ucq_enabled,
				tofu_fake_alloc_stag_steering_enabled,
				tofu_fake_alloc_stag_vm_read_lock,
				tofu_fake_alloc_stag_vm_read_unlock,
				tofu_fake_alloc_stag_lookup_range,
				tofu_fake_alloc_stag_stack_faultable,
				tofu_fake_alloc_stag_page_fault,
				tofu_fake_alloc_stag_pagesize_locked,
				tofu_fake_alloc_stag_cq_lock,
				tofu_fake_alloc_stag_cq_unlock,
				tofu_fake_alloc_stag_trans_search,
				tofu_fake_alloc_stag_reserve,
				tofu_fake_alloc_stag_release,
				tofu_fake_alloc_stag_alloc_new,
				tofu_fake_alloc_stag_get_mbpt_start,
				tofu_fake_alloc_stag_range_insert) == -EINVAL);

			mix(&digest,
				((unsigned long)tofu_alloc_stag_copyin_count << 32) |
				((unsigned long)tofu_alloc_stag_copyout_count << 24) |
				((unsigned long)tofu_alloc_stag_vm_lock_count << 16) |
				((unsigned long)tofu_alloc_stag_cq_lock_count << 8) |
				(unsigned long)tofu_alloc_stag_range_insert_count);
			mix(&digest, tofu_alloc_stag_out.offset ^
				tofu_alloc_stag_trans_end ^
				tofu_alloc_stag_alloc_new_plus_mbva);
		}
		{
			tofu_release_kind_result = 1;
			tofu_release_cq_count = 0;
			tofu_release_bch_count = 0;
			tofu_release_log_count = 0;
			require(tofu_utofu_release_fd_body_result(0,
				(void *)0xdef0UL, (const void *)0xabc0UL, 123, 4,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_release_cq_count == 0);
			require(tofu_utofu_release_fd_body_result(1,
				0, (const void *)0xabc0UL, 123, 4,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, 0, 123, 4,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_release_cq_count == 0);

			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, (const void *)0xabc0UL, 123, 4,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_release_cq_count == 1);
			require(tofu_release_bch_count == 0);
			require(tofu_release_log_count == 1);
			require(tofu_release_last_pid == 123);
			require(tofu_release_last_fd == 4);
			require(tofu_release_last_kind == 1);

			tofu_release_kind_result = 2;
			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, (const void *)0xabc1UL, 321, 5,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_release_cq_count == 1);
			require(tofu_release_bch_count == 1);
			require(tofu_release_log_count == 2);
			require(tofu_release_last_kind == 2);

			tofu_release_kind_result = 0;
			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, (const void *)0xabc2UL, 1, 2,
				tofu_fake_path_kind, tofu_fake_release_cq,
				tofu_fake_release_bch, tofu_fake_release_log) == 0);
			require(tofu_release_cq_count == 1);
			require(tofu_release_bch_count == 1);
			require(tofu_release_log_count == 2);
			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, (const void *)0xabc0UL, 1, 2,
				0, tofu_fake_release_cq, tofu_fake_release_bch,
				tofu_fake_release_log) == -22);
			require(tofu_utofu_release_fd_body_result(1,
				(void *)0xdef0UL, (const void *)0xabc0UL, 1, 2,
				tofu_fake_path_kind, 0, tofu_fake_release_bch,
				tofu_fake_release_log) == -22);

			tofu_release_fd_count = 0;
			require(tofu_utofu_release_fds_body_result(0,
				(void *)0xfeed0000UL, 4, tofu_fake_release_fd) == 0);
			require(tofu_release_fd_count == 0);
			require(tofu_utofu_release_fds_body_result(1,
				(void *)0xfeed0000UL, 4, tofu_fake_release_fd) == 0);
			require(tofu_release_fd_count == 4);
			require(tofu_release_fd_order[0] == 0);
			require(tofu_release_fd_order[3] == 3);
			require(tofu_utofu_release_fds_body_result(1,
				0, 4, tofu_fake_release_fd) == -22);
			require(tofu_utofu_release_fds_body_result(1,
				(void *)0xfeed0000UL, -1, tofu_fake_release_fd) == -22);
			require(tofu_utofu_release_fds_body_result(1,
				(void *)0xfeed0000UL, 4, 0) == -22);
			mix(&digest, ((unsigned long)tofu_release_cq_count << 24) |
				((unsigned long)tofu_release_bch_count << 16) |
				(unsigned long)tofu_release_fd_count);
		}
		{
			void *dev = (void *)0xf00d0000UL;

			tofu_ioctl_call_count = 0;
			tofu_ioctl_timestamp_count = 0;
			tofu_ioctl_profile_count = 0;
			tofu_ioctl_unknown_count = 0;
			tofu_ioctl_timestamp_value = 1000;
			tofu_ioctl_results[0] = 10;
			tofu_ioctl_results[1] = -11;
			tofu_ioctl_results[2] = 12;
			tofu_ioctl_results[3] = 13;

			require(tofu_utofu_unlocked_ioctl_body_result(8,
				TOF_IOCTL_ALLOC_STAG, 0xabcUL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -ENOTSUPP);
			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_ALLOC_STAG, 0xabcUL, 8, 0,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -ENOTSUPP);
			require(tofu_ioctl_call_count == 0);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_ALLOC_STAG, 0xabcUL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == 10);
			require(tofu_ioctl_call_count == 1);
			require(tofu_ioctl_last_kind == 0);
			require(tofu_ioctl_last_arg == 0xabcUL);
			require(tofu_ioctl_profile_count == 0);
			require(tofu_ioctl_timestamp_count == 0);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_FREE_STAGS, 0xdefUL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				1, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -11);
			require(tofu_ioctl_call_count == 2);
			require(tofu_ioctl_last_kind == 1);
			require(tofu_ioctl_profile_count == 1);
			require(tofu_ioctl_profile_last_event ==
				PROFILE_tofu_stag_free_stags);
			require(tofu_ioctl_profile_last_delta == 50);
			require(tofu_ioctl_timestamp_count == 2);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_ENABLE_BCH, 0x123UL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				1, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == 12);
			require(tofu_ioctl_last_kind == 2);
			require(tofu_ioctl_profile_count == 1);
			require(tofu_ioctl_timestamp_count == 3);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_DISABLE_BCH, 0x456UL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == 13);
			require(tofu_ioctl_last_kind == 3);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				0xffffffffU, 0x456UL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -ENOTSUPP);
			require(tofu_ioctl_unknown_count == 1);
			require(tofu_ioctl_unknown_last_fd == 3);

			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_ALLOC_STAG, 0xabcUL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				0, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				0, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch,
				tofu_fake_ioctl_timestamp,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -22);
			require(tofu_utofu_unlocked_ioctl_body_result(3,
				TOF_IOCTL_ALLOC_STAG, 0xabcUL, 8, dev,
				TOF_IOCTL_ALLOC_STAG, TOF_IOCTL_FREE_STAGS,
				TOF_IOCTL_ENABLE_BCH, TOF_IOCTL_DISABLE_BCH,
				1, PROFILE_tofu_stag_alloc,
				PROFILE_tofu_stag_free_stags,
				tofu_fake_ioctl_alloc, tofu_fake_ioctl_free,
				tofu_fake_ioctl_enable_bch,
				tofu_fake_ioctl_disable_bch, 0,
				tofu_fake_ioctl_profile_event,
				tofu_fake_ioctl_unknown_log) == -22);
			mix(&digest, ((unsigned long)tofu_ioctl_call_count << 24) |
				((unsigned long)tofu_ioctl_profile_count << 16) |
				((unsigned long)tofu_ioctl_timestamp_count << 8) |
				(unsigned long)tofu_ioctl_unknown_count);
			mix(&digest, tofu_ioctl_profile_last_delta);
		}
		{
			void *ucq = (void *)0xcafe0000UL;
			int user_stags[8] = { 4, 5, 6, 7, 8, 9, 10, 11 };
			int staging[8] = { 0 };
			struct tof_free_stags req = { 3, user_stags };
			struct tof_free_stags out_req = { 0, 0 };

			tofu_reset_free_stags_fakes();
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == 0);
			require(req.num == 3);
			require(out_req.num == 3);
			require(out_req.stags == user_stags);
			require(user_stags[0] == -1 && user_stags[1] == -1 &&
				user_stags[2] == -1);
			require(tofu_free_stags_free_count == 3);
			require(tofu_free_stags_remove_count == 3);
			require(tofu_free_stags_log_count == 1);
			require(tofu_free_stags_log_no_free == 0);

			user_stags[0] = 7;
			user_stags[1] = 8;
			user_stags[2] = 9;
			req.num = 3;
			out_req.num = 0;
			tofu_reset_free_stags_fakes();
			tofu_free_stags_results[1] = -ENOENT;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -ENOENT);
			require(req.num == 2);
			require(out_req.num == 2);
			require(user_stags[0] == -1 && user_stags[1] == 8 &&
				user_stags[2] == 9);
			require(tofu_free_stags_remove_order[0] == 7);
			require(tofu_free_stags_remove_order[1] == 8);
			require(tofu_free_stags_remove_order[2] == 9);
			require(tofu_free_stags_log_count == 1);
			require(tofu_free_stags_log_no_free == 1);

			user_stags[0] = 11;
			user_stags[1] = 12;
			user_stags[2] = 13;
			req.num = 3;
			out_req.num = 0;
			tofu_reset_free_stags_fakes();
			tofu_free_stags_results[1] = -ENOENT;
			tofu_free_stags_results[2] = -77;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -77);
			require(req.num == 1);
			require(out_req.num == 1);
			require(user_stags[0] == -1 && user_stags[1] == 12);
			require(tofu_free_stags_remove_count == 3);
			require(tofu_free_stags_log_count == 0);

			req.num = 2;
			req.stags = user_stags;
			tofu_reset_free_stags_fakes();
			tofu_free_stags_copyin_fail = 1;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EFAULT);
			require(tofu_error_log_count == 1);
			require(tofu_error_log_last == -EFAULT);
			require(tofu_free_stags_free_count == 0);
			require(tofu_free_stags_copyout_count == 0);

			tofu_reset_free_stags_fakes();
			tofu_free_stags_copyout_fail = 1;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EFAULT);
			require(tofu_error_log_count == 1);
			require(tofu_free_stags_reqout_count == 0);

			tofu_reset_free_stags_fakes();
			tofu_free_stags_reqout_fail = 1;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EFAULT);
			require(tofu_error_log_count == 0);
			require(tofu_free_stags_copyout_count == 1);
			require(tofu_free_stags_reqout_count == 1);

			req.num = 1025;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EINVAL);
			req.num = 1;
			req.stags = 0;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				tofu_fake_copyin_stags, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EINVAL);
			req.stags = user_stags;
			require(tofu_utofu_free_stags_after_req_copy_body_result(
				ucq, &req, &out_req, staging, 1024,
				0, tofu_fake_copyout_stags,
				tofu_fake_copyout_free_req,
				tofu_fake_free_one_stag,
				tofu_fake_remove_stag_range, tofu_fake_error_log,
				tofu_fake_free_stags_log) == -EINVAL);

			mix(&digest,
				((unsigned long)tofu_free_stags_free_count << 32) |
				((unsigned long)tofu_free_stags_remove_count << 24) |
				((unsigned long)tofu_free_stags_copyin_count << 16) |
				((unsigned long)tofu_free_stags_copyout_count << 8) |
				(unsigned long)tofu_free_stags_reqout_count);
			mix(&digest,
				((unsigned long)tofu_free_stags_log_count << 16) |
				(unsigned long)tofu_free_stags_log_no_free);
		}
		{
			void *ucq = (void *)0xcafe1000UL;
			void *profile_state = (void *)0x51510000UL;

			tofu_reset_free_stag_fakes();
			require(tofu_utofu_free_stag_body_result(
				ucq, 3, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == 0);
			require(tofu_free_stag_enabled_count == 1);
			require(tofu_free_stag_kref_count == 1);
			require(tofu_free_stag_disable_count == 1);
			require(tofu_free_stag_trans_disable_count == 1);
			require(tofu_free_stag_wmb_count == 1);
			require(tofu_free_stag_cacheflush_count == 1);
			require(tofu_free_stag_kref_put_count == 1);
			require(tofu_free_stag_clear_count == 1);
			require(tofu_free_stag_dealloc_log_count == 1);
			require(tofu_free_stag_profile_count == 4);
			require(tofu_free_stag_order_count == 11);
			require(tofu_free_stag_order[0] == 1);
			require(tofu_free_stag_order[1] == 2);
			require(tofu_free_stag_order[2] == 3);
			require(tofu_free_stag_order[3] == 11);
			require(tofu_free_stag_order[4] == 4);
			require(tofu_free_stag_order[5] == 12);
			require(tofu_free_stag_order[6] == 5);
			require(tofu_free_stag_order[7] == 6);
			require(tofu_free_stag_order[8] == 7);
			require(tofu_free_stag_order[9] == 13);
			require(tofu_free_stag_order[10] == 14);

			tofu_reset_free_stag_fakes();
			tofu_free_stag_enabled_result = 0;
			require(tofu_utofu_free_stag_body_result(
				ucq, 4, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -ENOENT);
			require(tofu_free_stag_kref_count == 0);
			require(tofu_free_stag_disable_count == 0);

			tofu_reset_free_stag_fakes();
			tofu_free_stag_enabled_result = -EINVAL;
			require(tofu_utofu_free_stag_body_result(
				ucq, 4, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -EINVAL);
			require(tofu_free_stag_kref_count == 0);

			tofu_reset_free_stag_fakes();
			tofu_free_stag_kref_result = 0;
			require(tofu_utofu_free_stag_body_result(
				ucq, 5, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -EINVAL);
			require(tofu_free_stag_non_mckernel_log_count == 1);
			require(tofu_free_stag_disable_count == 0);

			tofu_reset_free_stag_fakes();
			tofu_free_stag_cacheflush_result = -88;
			require(tofu_utofu_free_stag_body_result(
				ucq, 6, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				0, tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == 0);
			require(tofu_free_stag_profile_count == 0);
			require(tofu_free_stag_kref_put_count == 1);

			require(tofu_utofu_free_stag_body_result(
				ucq, -1, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -EINVAL);
			require(tofu_utofu_free_stag_body_result(
				ucq, 16, 16, tofu_fake_free_stag_enabled,
				tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -EINVAL);
			require(tofu_utofu_free_stag_body_result(
				ucq, 1, 16, 0, tofu_fake_free_stag_kref,
				tofu_fake_free_stag_non_mckernel_log,
				tofu_fake_free_stag_disable_entries,
				tofu_fake_free_stag_trans_disable,
				tofu_fake_free_stag_wmb, profile_state,
				tofu_fake_free_stag_profile,
				tofu_fake_free_stag_cacheflush,
				tofu_fake_free_stag_kref_put,
				tofu_fake_free_stag_clear,
				tofu_fake_free_stag_dealloc_log) == -EINVAL);

			mix(&digest,
				((unsigned long)tofu_free_stag_order_count << 24) |
				((unsigned long)tofu_free_stag_profile_count << 16) |
				((unsigned long)tofu_free_stag_kref_put_count << 8) |
				(unsigned long)tofu_free_stag_dealloc_log_count);
		}
		{
			struct tof_set_bg bgs[4] = { { 0 } };
			struct tof_enable_bch req;
			unsigned char enabled = 0;
			unsigned long bgmask[TOF_ICC_NTNIS];
			unsigned long iova = 0;
			int j;

			for (j = 0; j < 4; ++j) {
				bgs[j].tni = j + 1;
				bgs[j].gate = j + 3;
			}
			req.addr = (void *)0x2000UL;
			req.bseq = 77;
			req.num = 3;
			req.bgs = bgs;

			require(tofu_utofu_enable_bch_precheck_body_result(2,
				&enabled, 4) == 0);
			require(tofu_utofu_enable_bch_precheck_body_result(4,
				&enabled, 4) == -ENOTTY);
			enabled = 1;
			require(tofu_utofu_enable_bch_precheck_body_result(2,
				&enabled, 4) == -EBUSY);
			enabled = 0;
			require(tofu_utofu_enable_bch_precheck_body_result(2,
				0, 4) == -EINVAL);

			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == 0);
			req.num = -1;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.num = 3;
			req.bgs = 0;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.bgs = bgs;
			req.addr = 0;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.addr = (void *)0x2101UL;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.addr = (void *)0x2000UL;
			req.bseq = -1;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.bseq = (int)TOF_ICC_BG_BSEQ_SIZE;
			require(tofu_utofu_enable_bch_request_validate_result(&req,
				TOF_ICC_BCH_DMA_ALIGN, TOF_ICC_BG_BSEQ_SIZE) == -EINVAL);
			req.bseq = 77;

			tofu_enable_bgs_base = bgs;
			tofu_enable_call_count = 0;
			tofu_enable_result = 0;
			tofu_set_bg_count = 0;
			tofu_set_bg_fail_index = -1;
			tofu_commit_disable_count = 0;
			tofu_unset_user_count = 0;
			tofu_error_log_count = 0;
			enabled = 0;
			iova = 0;
			for (j = 0; j < TOF_ICC_NTNIS; ++j)
				bgmask[j] = 0xff00UL + (unsigned long)j;
			require(tofu_utofu_enable_bch_commit_body_result(
				(void *)0xbeef0000UL, &enabled, 5, 7, &req,
				0x123400UL, bgmask, TOF_ICC_NTNIS, &iova, 600,
				tofu_fake_enable_bch, tofu_fake_set_bg,
				tofu_fake_commit_disable_bch,
				tofu_fake_unset_bg_user,
				tofu_fake_error_log) == 0);
			require(enabled == 1);
			require(iova == 0x123400UL);
			require(tofu_enable_call_count == 1);
			require(tofu_enable_last_tni == 5);
			require(tofu_enable_last_bgid == 7);
			require(tofu_enable_last_ipa == 0x123400UL);
			require(tofu_set_bg_count == 3);
			require(tofu_set_bg_order[0] == 0);
			require(tofu_set_bg_order[1] == 1);
			require(tofu_set_bg_order[2] == 2);
			require(tofu_set_bg_last_kuid == 600);
			require(tofu_set_bg_last_bseq == 77);
			require(tofu_commit_disable_count == 0);
			require(tofu_unset_user_count == 0);
			require(tofu_error_log_count == 0);
			for (j = 0; j < TOF_ICC_NTNIS; ++j)
				require(bgmask[j] == 0);

			tofu_enable_call_count = 0;
			tofu_enable_result = -44;
			tofu_set_bg_count = 0;
			tofu_commit_disable_count = 0;
			tofu_unset_user_count = 0;
			tofu_error_log_count = 0;
			enabled = 0;
			iova = 0xfeedUL;
			for (j = 0; j < TOF_ICC_NTNIS; ++j)
				bgmask[j] = 0xaa00UL + (unsigned long)j;
			require(tofu_utofu_enable_bch_commit_body_result(
				(void *)0xbeef0000UL, &enabled, 5, 7, &req,
				0x123401UL, bgmask, TOF_ICC_NTNIS, &iova, 601,
				tofu_fake_enable_bch, tofu_fake_set_bg,
				tofu_fake_commit_disable_bch,
				tofu_fake_unset_bg_user,
				tofu_fake_error_log) == -44);
			require(enabled == 0);
			require(iova == 0xfeedUL);
			require(tofu_enable_call_count == 1);
			require(tofu_set_bg_count == 0);
			require(tofu_commit_disable_count == 1);
			require(tofu_commit_disable_last_tni == 5);
			require(tofu_commit_disable_last_bgid == 7);
			require(tofu_unset_user_count == 0);
			require(tofu_error_log_count == 1);
			require(tofu_error_log_last == -44);
			for (j = 0; j < TOF_ICC_NTNIS; ++j)
				require(bgmask[j] == 0);

			tofu_enable_call_count = 0;
			tofu_enable_result = 0;
			tofu_set_bg_count = 0;
			tofu_set_bg_fail_index = 2;
			tofu_commit_disable_count = 0;
			tofu_unset_user_count = 0;
			tofu_error_log_count = 0;
			enabled = 0;
			iova = 0xbeadUL;
			require(tofu_utofu_enable_bch_commit_body_result(
				(void *)0xbeef0000UL, &enabled, 5, 7, &req,
				0x123402UL, bgmask, TOF_ICC_NTNIS, &iova, 602,
				tofu_fake_enable_bch, tofu_fake_set_bg,
				tofu_fake_commit_disable_bch,
				tofu_fake_unset_bg_user,
				tofu_fake_error_log) == -66);
			require(enabled == 0);
			require(iova == 0xbeadUL);
			require(tofu_enable_call_count == 1);
			require(tofu_set_bg_count == 3);
			require(tofu_set_bg_order[0] == 0);
			require(tofu_set_bg_order[1] == 1);
			require(tofu_set_bg_order[2] == 2);
			require(tofu_commit_disable_count == 1);
			require(tofu_unset_user_count == 2);
			require(tofu_unset_user_order[0] == 1);
			require(tofu_unset_user_order[1] == 0);
			require(tofu_error_log_count == 1);
			require(tofu_error_log_last == -66);

			tofu_enable_call_count = 0;
			tofu_set_bg_count = 0;
			tofu_commit_disable_count = 0;
			tofu_unset_user_count = 0;
			tofu_error_log_count = 0;
			require(tofu_utofu_enable_bch_commit_body_result(
				(void *)0xbeef0000UL, &enabled, 5, 7, &req,
				0x123403UL, bgmask, TOF_ICC_NTNIS, &iova, 603,
				0, tofu_fake_set_bg, tofu_fake_commit_disable_bch,
				tofu_fake_unset_bg_user,
				tofu_fake_error_log) == -EINVAL);
			require(tofu_utofu_enable_bch_commit_body_result(
				(void *)0xbeef0000UL, &enabled, 5, 7, &req,
				0x123403UL, bgmask, TOF_ICC_NTNIS, &iova, 603,
				tofu_fake_enable_bch, tofu_fake_set_bg,
				tofu_fake_commit_disable_bch,
				tofu_fake_unset_bg_user, 0) == -EINVAL);
			require(tofu_enable_call_count == 0);
			require(tofu_set_bg_count == 0);
			require(tofu_commit_disable_count == 0);
			require(tofu_unset_user_count == 0);
			require(tofu_error_log_count == 0);

			mix(&digest, ((unsigned long)tofu_set_bg_count << 24) |
				((unsigned long)tofu_commit_disable_count << 16) |
				((unsigned long)tofu_unset_user_count << 8) |
				(unsigned long)tofu_error_log_count);
			mix(&digest, iova);
			mix(&digest, (unsigned long)tofu_error_log_last);
		}

			for (size = 0; size < 6; ++size) {
			mix(&digest, (unsigned long)TOF_ICC_TOQ_SIZE_BITS(size));
			mix(&digest, (unsigned long)TOF_ICC_TOQ_SIZE(size));
		mix(&digest, (unsigned long)TOF_ICC_TOQ_LEN(size));
		mix(&digest, (unsigned long)TOF_ICC_TCQ_LEN(size));
		mix(&digest, (unsigned long)TOF_ICC_MRQ_SIZE_BITS(size));
		mix(&digest, (unsigned long)TOF_ICC_MRQ_SIZE(size));
		mix(&digest, (unsigned long)TOF_ICC_MRQ_LEN(size));
		mix(&digest, (unsigned long)TOF_ICC_PBQ_SIZE_BITS(size));
		mix(&digest, (unsigned long)TOF_ICC_PBQ_SIZE(size));
		mix(&digest, (unsigned long)TOF_ICC_PBQ_LEN(size));
		mix(&digest, (unsigned long)TOF_ICC_PRQ_SIZE_BITS(size));
		mix(&digest, (unsigned long)TOF_ICC_PRQ_SIZE(size));
		mix(&digest, (unsigned long)TOF_ICC_PRQ_LEN(size));
	}

	for (bits = 3; bits < 30; ++bits)
		mix(&digest, (unsigned long)TOF_ICC_MB_PS_ENCODE(bits));

	for (i = 0; i < (int)(sizeof(lengths) / sizeof(lengths[0])); ++i) {
		mix(&digest, (unsigned long)(unsigned int)TOF_ICC_TLP_LEN(lengths[i]));
		mix(&digest, (unsigned long)(unsigned int)TOF_ICC_FRAME_LEN(lengths[i]));
		frame = tof_icc_get_framelen(lengths[i]);
		mix(&digest, (unsigned long)(unsigned int)lengths[i]);
		mix(&digest, (unsigned long)(unsigned int)frame);
	}

	{
		struct tof_utofu_trans_list mru[8];
		struct tof_trans_table table[8];
		unsigned long mbptstart = 0;
		unsigned long dmaaddr;
		short stag_ring[4] = { 11, 22, 33, 44 };
		int stag_rp = 1;
		int stag_wp = 3;
		int head = TOF_UTOFU_MRU_EMPTY;

		for (i = 0; i < 8; ++i) {
			mru[i].prev = TOF_UTOFU_MRU_EMPTY;
			mru[i].next = TOF_UTOFU_MRU_EMPTY;
			mru[i].pgszbits = 0;
			mru[i].mbpt = 0;
			table[i].steering = 0xff00UL + (unsigned long)i;
			table[i].mbpt = 0xee00UL + (unsigned long)i;
		}

		require(tofu_utofu_calc_mbptstart_body_result(
			0x12345000L, 0x12346000L, 4, 16, &mbptstart) == 0);
		require(mbptstart == 0x12345000UL);
		require(tofu_utofu_calc_mbptstart_body_result(
			0, 0, 0, 0, 0) == -22);
		dmaaddr = tofu_ib_dmaaddr_pack_result(0x1234U, 0xabcd5678U);
		require(dmaaddr == 0x1234abcd5678UL);
		require(tofu_ib_dmaaddr_stag_result(dmaaddr) == 0x1234U);
		require(tofu_ib_stag_alloc_body_result(stag_ring,
			&stag_rp, &stag_wp, 4) == 22);
		require(stag_rp == 2 && stag_wp == 3);
		require(tofu_ib_stag_alloc_body_result(stag_ring,
			&stag_rp, &stag_wp, 4) == 33);
		require(stag_rp == 3 && stag_wp == 3);
		require(tofu_ib_stag_alloc_body_result(stag_ring,
			&stag_rp, &stag_wp, 4) == -2);
		require(tofu_ib_stag_free_body_result(stag_ring,
			&stag_rp, &stag_wp, 77, 4) == 1);
		require(stag_ring[3] == 77 && stag_wp == 0);
		stag_rp = 1;
		stag_wp = 0;
		require(tofu_ib_stag_free_body_result(stag_ring,
			&stag_rp, &stag_wp, 88, 4) == 0);
		require(stag_ring[0] == 11 && stag_wp == 0);
		require(tofu_ib_stag_alloc_body_result(0,
			&stag_rp, &stag_wp, 4) == -22);
		require(tofu_ib_stag_free_body_result(stag_ring,
			0, &stag_wp, 88, 4) == -22);

		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 2, 16, (void *)0x2000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == 2 && mru[2].prev == 2 && mru[2].next == 2);
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 4, 21, (void *)0x4000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == 4 && mru[4].prev == 2 && mru[4].next == 2 &&
			mru[2].prev == 4 && mru[2].next == 4);
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 6, 16, (void *)0x6000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == 6 && mru[6].prev == 2 && mru[6].next == 4 &&
			mru[2].next == 6 && mru[4].prev == 6);

		require(tofu_utofu_trans_mru_delete_body_result(
			mru, &head, 6, TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == 4 && mru[2].next == 4 && mru[4].prev == 2 &&
			mru[6].prev == TOF_UTOFU_MRU_EMPTY &&
			mru[6].next == TOF_UTOFU_MRU_EMPTY);
		require(tofu_utofu_trans_mru_delete_body_result(
			mru, &head, 2, TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == 4 && mru[4].prev == 4 && mru[4].next == 4);
		require(tofu_utofu_trans_mru_delete_body_result(
			mru, &head, 4, TOF_UTOFU_MRU_EMPTY) == 0);
		require(head == TOF_UTOFU_MRU_EMPTY);
		require(tofu_utofu_trans_mru_delete_body_result(
			mru, &head, 4, TOF_UTOFU_MRU_EMPTY) == 0);
		require(tofu_utofu_trans_mru_insert_body_result(
			0, &head, 1, 16, 0, TOF_UTOFU_MRU_EMPTY) == -22);

		head = TOF_UTOFU_MRU_EMPTY;
		for (i = 0; i < 8; ++i) {
			mru[i].prev = TOF_UTOFU_MRU_EMPTY;
			mru[i].next = TOF_UTOFU_MRU_EMPTY;
		}
		tofu_atomic_set_count = 0;
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 1, 16, (void *)0x1000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 3, 21, (void *)0x3000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(tofu_utofu_trans_disable_body_result(
			&table[3], mru, &head, 3, TOF_UTOFU_MRU_EMPTY,
			tofu_fake_atomic_set) == 0);
		require(table[3].steering == 0 && tofu_atomic_set_count == 1);
		require(head == 1 && mru[1].prev == 1 && mru[1].next == 1 &&
			mru[3].prev == TOF_UTOFU_MRU_EMPTY &&
			mru[3].next == TOF_UTOFU_MRU_EMPTY);
		require(tofu_utofu_trans_disable_body_result(
			&table[1], mru, &head, 1, TOF_UTOFU_MRU_EMPTY,
			0) == -22);
		require(table[1].steering == 0xff01UL && head == 1);

		tofu_atomic_set_count = 0;
		tofu_lock_count = 0;
		tofu_unlock_count = 0;
		tofu_wmb_count = 0;
		require(tofu_utofu_trans_entry_pack_result(0x12345000UL,
			0x6000UL, PAGE_SHIFT, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB) == 0x6000012345UL);
		require(tofu_utofu_trans_entry_pack_result(0x34567000UL,
			0x200000UL, 21, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB) == 0x8000200000034567UL);
		require(tofu_utofu_trans_update_body_result(&table[5], mru,
			&head, &tofu_lock_token, 5, 0x55555000UL, 0x9000UL,
			16, (void *)0x5000UL, TOF_UTOFU_MRU_EMPTY,
			PAGE_SHIFT, TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB, tofu_fake_atomic_set,
			tofu_fake_lock, tofu_fake_unlock) == 0);
		require(table[5].steering == 0x8000009000055555UL &&
			head == 5 && mru[5].pgszbits == 16 &&
			mru[5].mbpt == (void *)0x5000UL);
		require(tofu_atomic_set_count == 1 && tofu_lock_count == 1 &&
			tofu_unlock_count == 1);
		require(tofu_utofu_trans_enable_body_result(&table[7], mru,
			&head, &tofu_lock_token, 7, 0x77777000UL, 0xa000UL,
			0x70000000UL, 0x3000UL, PAGE_SHIFT,
			(void *)0x7000UL, TOF_UTOFU_MRU_EMPTY, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB, tofu_fake_atomic_set,
			tofu_fake_wmb, tofu_fake_lock, tofu_fake_unlock) == 0);
		require(table[7].mbpt == 0x3000070000UL &&
			table[7].steering == 0xa000077777UL &&
			head == 7 && mru[7].pgszbits == PAGE_SHIFT &&
			mru[7].mbpt == (void *)0x7000UL &&
			tofu_wmb_count == 1 && tofu_lock_count == 2 &&
			tofu_unlock_count == 2);
		require(tofu_utofu_trans_update_body_result(0, mru, &head,
			&tofu_lock_token, 7, 0, 0, 0, 0,
			TOF_UTOFU_MRU_EMPTY, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB, tofu_fake_atomic_set,
			tofu_fake_lock, tofu_fake_unlock) == -22);
		require(tofu_utofu_trans_table_steering_start_result(
			&table[7], PAGE_SHIFT) == 0x77777000UL);
		require(tofu_utofu_trans_table_steering_len_result(
			&table[7], PAGE_SHIFT) == 0xa000UL);
		require(tofu_utofu_trans_table_mbpt_start_result(
			&table[7], PAGE_SHIFT) == 0x70000000UL);
		require(tofu_utofu_trans_table_mbpt_len_result(
			&table[7], PAGE_SHIFT) == 0x3000UL);
		require(tofu_utofu_trans_table_steering_start_result(0,
			PAGE_SHIFT) == 0);

		head = TOF_UTOFU_MRU_EMPTY;
		for (i = 0; i < 8; ++i) {
			mru[i].prev = TOF_UTOFU_MRU_EMPTY;
			mru[i].next = TOF_UTOFU_MRU_EMPTY;
			mru[i].pgszbits = 0;
			table[i].steering = 0;
			table[i].mbpt = 0;
		}
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 3, PAGE_SHIFT, (void *)0x3000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		require(tofu_utofu_trans_mru_insert_body_result(
			mru, &head, 5, 21, (void *)0x5000UL,
			TOF_UTOFU_MRU_EMPTY) == 0);
		table[3].steering = tofu_utofu_trans_entry_pack_result(
			0x30000000UL, 0x2000UL, PAGE_SHIFT, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB);
		table[5].steering = tofu_utofu_trans_entry_pack_result(
			0x50000000UL, 0x4000UL, 21, PAGE_SHIFT,
			TOF_STAG_TRANS_PS_CODE_64KB,
			TOF_STAG_TRANS_PS_CODE_2MB);
		require(tofu_utofu_trans_search_body_result(table, mru, head,
			0x50000000UL, 0x50004000UL, 21, 1, 1,
			TOF_UTOFU_MRU_EMPTY, 3, 8, PAGE_SHIFT) == 5);
		require(tofu_utofu_trans_search_body_result(table, mru, head,
			0x50001000UL, 0x50002000UL, 21, 1, 0,
			TOF_UTOFU_MRU_EMPTY, 3, 8, PAGE_SHIFT) == 5);
		require(tofu_utofu_trans_search_body_result(table, mru, head,
			0x50000000UL, 0x50004000UL, 21, 0, 1,
			TOF_UTOFU_MRU_EMPTY, 3, 8, PAGE_SHIFT) == -2);
		require(tofu_utofu_trans_search_body_result(table, mru, head,
			0x50000000UL, 0x50004000UL, PAGE_SHIFT, 1, 1,
			TOF_UTOFU_MRU_EMPTY, 3, 8, PAGE_SHIFT) == -2);
		require(tofu_utofu_trans_search_body_result(table, mru,
			TOF_UTOFU_MRU_EMPTY, 0, 0, 0, 0, 0,
			TOF_UTOFU_MRU_EMPTY, 3, 8, PAGE_SHIFT) == -2);
		require(tofu_utofu_trans_search_body_result(0, mru, head,
			0, 0, 0, 0, 0, TOF_UTOFU_MRU_EMPTY, 3, 8,
			PAGE_SHIFT) == -22);
		mix(&digest, (unsigned long)tofu_utofu_trans_search_body_result(
			table, mru, head, 0x30000000UL, 0x30002000UL,
			PAGE_SHIFT, 1, 1, TOF_UTOFU_MRU_EMPTY, 3, 8,
			PAGE_SHIFT));

		{
			struct tof_icc_steering_entry_words steering = {
				.word = 0x0000aa000000003fUL,
				.length = 0
			};
			struct tof_icc_steering_entry_words steering_table[8];
			struct tof_icc_mb_entry_words mb = {
				.word = 0xff00000000000078UL,
				.npage = 0
			};
			struct tof_icc_mbpt_entry_words mbpt_ent = {
				.word = 0x0f00000000000f7fUL
			};

			tofu_wmb_count = 0;
			require(tofu_icc_steering_enable_body_result(
				&steering, 0x3456, 0x1234567800UL,
				0x9000UL, 1, tofu_fake_wmb) == 0);
			require(steering.word ==
				0x3456aa12345678ffUL);
			require(steering.length == 0x9000UL);
			require(tofu_wmb_count == 1);
			require(tofu_icc_steering_enable_body_result(
				0, 0, 0, 0, 0, tofu_fake_wmb) == -22);
			require(tofu_icc_steering_entry_is_enabled_result(
				&steering) == 1);
			require(tofu_icc_steering_disable_entry_body_result(
				&steering) == 0);
			require(steering.word ==
				0x3456aa123456787fUL);
			require(tofu_icc_steering_entry_is_enabled_result(
				&steering) == 0);
			require(tofu_icc_steering_disable_entry_body_result(
				0) == -22);

			for (i = 0; i < 8; ++i) {
				steering_table[i].word =
					1UL << TOF_ICC_STEERING_ENABLE_SHIFT;
				steering_table[i].length = 0;
			}
			steering_table[6].word = 0;
			steering_table[7].word = 0;
			require(tofu_utofu_reserve_stag_body_result(
				steering_table, 4, 8, 0,
				sizeof(steering_table[0])) == 6);
			require(tofu_utofu_reserve_stag_body_result(
				steering_table, 4, 8, 1,
				sizeof(steering_table[0])) == 7);
			steering_table[6].word =
				1UL << TOF_ICC_STEERING_ENABLE_SHIFT;
			steering_table[7].word =
				1UL << TOF_ICC_STEERING_ENABLE_SHIFT;
			require(tofu_utofu_reserve_stag_body_result(
				steering_table, 4, 8, 0,
				sizeof(steering_table[0])) == -1);
			require(tofu_utofu_reserve_stag_body_result(
				0, 4, 8, 0, sizeof(steering_table[0])) == -22);

			require(tofu_icc_mb_enable_body_result(&mb,
				0x1234567800UL, 16, 0x44UL,
				tofu_fake_wmb) == 0);
			require(mb.word == 0xff000012345678fcUL);
			require(mb.npage == 0x44UL);
			require(tofu_wmb_count == 2);
			require(tofu_icc_mb_disable_entry_body_result(&mb)
				== 0);
			require(mb.word == 0xff0000123456787cUL);
			require(mb.npage == 0x44UL);
			require(tofu_icc_mb_disable_entry_body_result(0)
				== -22);
			require(tofu_icc_mb_enable_body_result(&mb,
				0, 0, 0, 0) == -22);

			require(tofu_icc_mbpt_enable_entry_body_result(
				&mbpt_ent, 0xabcdef000UL, tofu_fake_wmb) == 0);
			require(mbpt_ent.word == 0x0f00000abcdeffffUL);
			require(tofu_icc_mbpt_entry_is_enabled_result(
				&mbpt_ent) == 1);
			require(tofu_wmb_count == 3);
			require(tofu_icc_mbpt_disable_entry_body_result(
				&mbpt_ent) == 0xabcdef000UL);
			require(mbpt_ent.word == 0x0f00000000000f7fUL);
			require(tofu_icc_mbpt_entry_is_enabled_result(
				&mbpt_ent) == 0);
			require(tofu_icc_mbpt_disable_entry_body_result(
				&mbpt_ent) == 0);
			require(tofu_icc_mbpt_enable_entry_body_result(
				&mbpt_ent, 0, 0) == -22);
			require(tofu_icc_mbpt_entry_is_enabled_result(0) == 0);

			mix(&digest, steering.word);
			mix(&digest, (unsigned long)tofu_utofu_reserve_stag_body_result(
				steering_table, 4, 8, 0,
				sizeof(steering_table[0])));
			mix(&digest, mb.word);
			mix(&digest, mbpt_ent.word);
		}

		mix(&digest, mbptstart);
		mix(&digest, dmaaddr);
		mix(&digest, (unsigned long)(unsigned short)stag_ring[3]);
		mix(&digest, (unsigned long)(unsigned int)stag_rp);
		mix(&digest, (unsigned long)(unsigned int)stag_wp);
		mix(&digest, (unsigned long)head);
		mix(&digest, table[3].steering);
		mix(&digest, table[7].mbpt);
		mix(&digest, (unsigned long)(unsigned char)mru[4].pgszbits);
	}

	printf("tofu_uapi ok digest=%016lx frame=%d\n",
			digest, tof_icc_get_framelen(93));
	return 0;
}
