#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct plist_head {
	struct list_head prio_list;
	struct list_head node_list;
};

struct plist_node {
	int prio;
	struct plist_head plist;
};

struct item {
	int id;
	struct plist_node node;
};

extern void plist_add(struct plist_node *, struct plist_head *);
extern void plist_del(struct plist_node *, struct plist_head *);
extern void plist_head_init(struct plist_head *, void *);
extern void plist_head_init_raw(struct plist_head *, void *);
extern void plist_node_init(struct plist_node *, int);
extern int plist_head_empty(const struct plist_head *);
extern int plist_node_empty(const struct plist_node *);
extern struct plist_node *plist_first(const struct plist_head *);

#define container_of(ptr, type, member) \
	((type *)((char *)(ptr) - offsetof(type, member)))
#define item_from_node(ptr) container_of(ptr, struct item, node)
#define plist_from_node(ptr) container_of(ptr, struct plist_node, plist.node_list)
#define plist_from_prio(ptr) container_of(ptr, struct plist_node, plist.prio_list)

static void require(int condition)
{
	if (!condition)
		exit(12);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void check_links(struct list_head *head)
{
	struct list_head *pos = head;
	int count = 0;

	do {
		require(pos->next->prev == pos);
		require(pos->prev->next == pos);
		pos = pos->next;
		require(++count < 64);
	} while (pos != head);
}

static unsigned long digest_state(struct plist_head *head)
{
	unsigned long digest = 0x706c697374UL;
	struct list_head *pos;
	int last_prio = -2147483647 - 1;
	int count = 0;

	check_links(&head->node_list);
	check_links(&head->prio_list);
	if (!plist_head_empty(head))
		require(plist_first(head) == plist_from_node(head->node_list.next));

	for (pos = head->node_list.next; pos != &head->node_list; pos = pos->next) {
		struct plist_node *node = plist_from_node(pos);
		struct item *item = item_from_node(node);

		require(node->prio >= last_prio);
		last_prio = node->prio;
		mix(&digest, ((unsigned long)(unsigned int)node->prio << 32) |
			     (unsigned long)(unsigned int)item->id);
		count++;
	}
	mix(&digest, (unsigned long)count);

	count = 0;
	for (pos = head->prio_list.next; pos != &head->prio_list; pos = pos->next) {
		struct plist_node *node = plist_from_prio(pos);
		struct item *item = item_from_node(node);

		require(!plist_node_empty(node));
		mix(&digest, 0x8000000000000000UL |
			     ((unsigned long)(unsigned int)node->prio << 32) |
			     (unsigned long)(unsigned int)item->id);
		count++;
	}
	mix(&digest, (unsigned long)count << 16);
	return digest;
}

int main(void)
{
	struct plist_head head;
	struct item items[8];
	int prios[] = { 20, 5, 10, 5, 15, 10, 0, 15 };
	unsigned long digest = 0;

	plist_head_init_raw(&head, NULL);
	require(plist_head_empty(&head));
	plist_head_init(&head, NULL);
	require(plist_head_empty(&head));
	for (int i = 0; i < 8; i++) {
		items[i].id = i;
		plist_node_init(&items[i].node, prios[i]);
		require(plist_node_empty(&items[i].node));
	}

	plist_add(&items[0].node, &head);
	plist_add(&items[1].node, &head);
	plist_add(&items[2].node, &head);
	plist_add(&items[3].node, &head);
	plist_add(&items[4].node, &head);
	plist_add(&items[5].node, &head);
	mix(&digest, digest_state(&head));

	plist_del(&items[1].node, &head);
	require(plist_node_empty(&items[1].node));
	mix(&digest, digest_state(&head));

	plist_del(&items[5].node, &head);
	require(plist_node_empty(&items[5].node));
	mix(&digest, digest_state(&head));

	plist_add(&items[6].node, &head);
	mix(&digest, digest_state(&head));

	plist_del(&items[2].node, &head);
	require(plist_node_empty(&items[2].node));
	mix(&digest, digest_state(&head));

	plist_add(&items[7].node, &head);
	mix(&digest, digest_state(&head));

	plist_del(&items[4].node, &head);
	require(plist_node_empty(&items[4].node));
	mix(&digest, digest_state(&head));

	plist_del(&items[6].node, &head);
	plist_del(&items[3].node, &head);
	plist_del(&items[7].node, &head);
	plist_del(&items[0].node, &head);
	require(head.node_list.next == &head.node_list);
	require(head.prio_list.next == &head.prio_list);
	require(plist_head_empty(&head));
	mix(&digest, digest_state(&head));

	printf("plist ok digest=%016lx\n", digest);
	return 0;
}
