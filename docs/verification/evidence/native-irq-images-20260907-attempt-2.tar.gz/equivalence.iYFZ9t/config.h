/* Minimal generated-config placeholder for page_alloc equivalence. */
#define PROFILE_ENABLE 1
