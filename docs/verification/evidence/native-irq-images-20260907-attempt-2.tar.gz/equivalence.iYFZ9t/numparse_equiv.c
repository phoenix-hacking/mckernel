#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

extern unsigned long simple_strtoul(const char *, char **, unsigned int);
extern long simple_strtol(const char *, char **, unsigned int);
extern unsigned long long simple_strtoull(const char *, char **, unsigned int);
extern long long simple_strtoll(const char *, char **, unsigned int);
extern int strict_strtoul(const char *, unsigned int, unsigned long *);
extern int strict_strtol(const char *, unsigned int, long *);
extern int strict_strtoull(const char *, unsigned int, unsigned long long *);
extern int strict_strtoll(const char *, unsigned int, long long *);
extern unsigned long strtol(const char *, char **, unsigned int);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static long ptr_offset(const char *base, const char *ptr)
{
	if (!ptr)
		return -1;
	return ptr - base;
}

int main(void)
{
	const char *inputs[] = {
		"", "0", "00", "01", "077", "0x", "0x0", "0x10",
		"0XfFz", "123abc", "-123abc", "-0x10", "+17",
		"18446744073709551616", "deadBEEF", "101010", "9", "2",
		"12\n", "12x", " 12", "-\n", "-0", "-9223372036854775808",
	};
	unsigned int bases[] = { 0, 1, 2, 8, 10, 16, 17, 36 };
	unsigned long digest = 0x51a1f1ed12345678UL;

	for (unsigned int i = 0; i < sizeof(inputs) / sizeof(inputs[0]); i++) {
		for (unsigned int b = 0; b < sizeof(bases) / sizeof(bases[0]); b++) {
			char *end = (char *)0x1;
			unsigned long ul = simple_strtoul(inputs[i], &end, bases[b]);
			mix(&digest, ul);
			mix_signed(&digest, ptr_offset(inputs[i], end));

			end = (char *)0x1;
			mix_signed(&digest, simple_strtol(inputs[i], &end, bases[b]));
			mix_signed(&digest, ptr_offset(inputs[i], end));

			end = (char *)0x1;
			mix(&digest, (unsigned long)simple_strtoull(inputs[i], &end, bases[b]));
			mix_signed(&digest, ptr_offset(inputs[i], end));

			end = (char *)0x1;
			mix_signed(&digest, (long)simple_strtoll(inputs[i], &end, bases[b]));
			mix_signed(&digest, ptr_offset(inputs[i], end));

			end = (char *)0x1;
			mix(&digest, strtol(inputs[i], &end, bases[b]));
			mix_signed(&digest, ptr_offset(inputs[i], end));
		}
	}

	for (unsigned int i = 0; i < sizeof(inputs) / sizeof(inputs[0]); i++) {
		unsigned long ul = 0xfeedfacecafebeefUL;
		unsigned long long ull = 0x1122334455667788ULL;
		long sl = 0x12345678L;
		long long sll = 0x123456789abcdefLL;
		int ret;

		ret = strict_strtoul(inputs[i], 0, &ul);
		mix_signed(&digest, ret);
		mix(&digest, ul);
		ret = strict_strtol(inputs[i], 0, &sl);
		mix_signed(&digest, ret);
		mix_signed(&digest, sl);
		ret = strict_strtoull(inputs[i], 0, &ull);
		mix_signed(&digest, ret);
		mix(&digest, (unsigned long)ull);
		ret = strict_strtoll(inputs[i], 0, &sll);
		mix_signed(&digest, ret);
		mix_signed(&digest, (long)sll);

		ret = strict_strtoul(inputs[i], 16, &ul);
		mix_signed(&digest, ret);
		mix(&digest, ul);
		ret = strict_strtol(inputs[i], 10, &sl);
		mix_signed(&digest, ret);
		mix_signed(&digest, sl);
	}

	printf("numparse ok digest=%016lx\n", digest);
	return 0;
}
