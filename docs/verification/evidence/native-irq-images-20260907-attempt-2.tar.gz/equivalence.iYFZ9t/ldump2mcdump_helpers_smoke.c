#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct dump_mem_chunk {
	unsigned long addr;
	unsigned long size;
};

extern int ldump2_count_chunks_result(const unsigned long *map,
				      unsigned long map_count);
extern int ldump2_fill_chunks_result(struct dump_mem_chunk *chunks,
				     unsigned long max_chunks,
				     unsigned long start,
				     const unsigned long *map,
				     unsigned long map_count,
				     int page_shift);
extern int ldump2_physmem_name_result(char *buf, size_t buf_size, int index);

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	const unsigned long start = 0x100000UL;
	const int page_shift = 12;
	unsigned long map[2];
	struct dump_mem_chunk chunks[5];
	char name[32];
	unsigned long digest = 0x6c64756d70326d63UL;
	int count;

	map[0] = (1UL << 0) | (1UL << 1) | (1UL << 2) |
		 (1UL << 5) | (1UL << 63);
	map[1] = (1UL << 0) | (1UL << 1) | (1UL << 3) | (1UL << 8);

	count = ldump2_count_chunks_result(map, 2);
	require(count == 5);
	memset(chunks, 0, sizeof(chunks));
	require(ldump2_fill_chunks_result(chunks, 5, start, map, 2,
					  page_shift) == 5);
	require(chunks[0].addr == start);
	require(chunks[0].size == (3UL << page_shift));
	require(chunks[1].addr == start + (5UL << page_shift));
	require(chunks[1].size == (1UL << page_shift));
	require(chunks[2].addr == start + (63UL << page_shift));
	require(chunks[2].size == (3UL << page_shift));
	require(chunks[3].addr == start + (67UL << page_shift));
	require(chunks[3].size == (1UL << page_shift));
	require(chunks[4].addr == start + (72UL << page_shift));
	require(chunks[4].size == (1UL << page_shift));
	require(ldump2_fill_chunks_result(chunks, 4, start, map, 2,
					  page_shift) < 0);
	require(ldump2_count_chunks_result(NULL, 0) == 0);
	require(ldump2_count_chunks_result(NULL, 1) < 0);
	require(ldump2_physmem_name_result(name, sizeof(name), 42) == 9);
	require(!strcmp(name, "physmem42"));
	require(ldump2_physmem_name_result(name, 8, 42) < 0);

	for (int i = 0; i < count; i++) {
		mix(&digest, chunks[i].addr);
		mix(&digest, chunks[i].size);
	}
	mix(&digest, (unsigned long)strlen(name));
	printf("ldump2mcdump_helpers ok digest=%016lx\n", digest);
	return 0;
}
