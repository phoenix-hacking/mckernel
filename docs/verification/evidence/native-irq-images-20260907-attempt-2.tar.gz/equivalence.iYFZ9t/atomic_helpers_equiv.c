#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct ihk_atomic { int counter; };
struct ihk_atomic64 { long counter64; };

extern int ihk_atomic_read(const struct ihk_atomic *v);
extern void ihk_atomic_set(struct ihk_atomic *v, int i);
extern void ihk_atomic_add(int i, struct ihk_atomic *v);
extern void ihk_atomic_sub(int i, struct ihk_atomic *v);
extern void ihk_atomic_inc(struct ihk_atomic *v);
extern void ihk_atomic_dec(struct ihk_atomic *v);
extern int ihk_atomic_dec_and_test(struct ihk_atomic *v);
extern int ihk_atomic_inc_and_test(struct ihk_atomic *v);
extern int ihk_atomic_add_return(int i, struct ihk_atomic *v);
extern int ihk_atomic_sub_return(int i, struct ihk_atomic *v);
extern int ihk_atomic_inc_return(struct ihk_atomic *v);
extern int ihk_atomic_dec_return(struct ihk_atomic *v);
extern long ihk_atomic64_read(const struct ihk_atomic64 *v);
extern void ihk_atomic64_set(struct ihk_atomic64 *v, long i);
extern void ihk_atomic64_inc(struct ihk_atomic64 *v);
extern long ihk_atomic64_add_return(long i, struct ihk_atomic64 *v);
extern long ihk_atomic64_sub_return(long i, struct ihk_atomic64 *v);
extern unsigned long xchg8(unsigned long *ptr, unsigned long x);
extern int xchg4(int *ptr, int x);
extern unsigned long atomic_xchg_ulong(unsigned long *ptr, unsigned long x);
extern void *atomic_xchg_ptr(void **ptr, void *x);
extern unsigned long atomic_cmpxchg8(unsigned long *addr,
				     unsigned long oldval,
				     unsigned long newval);
extern unsigned long atomic_cmpxchg4(unsigned int *addr,
				     unsigned int oldval,
				     unsigned int newval);
extern int atomic_cmpxchg_int(int *addr, int oldval, int newval);
extern unsigned long atomic_cmpxchg_ulong(unsigned long *addr,
					  unsigned long oldval,
					  unsigned long newval);
extern void *atomic_cmpxchg_ptr(void **addr, void *oldval, void *newval);
extern int compare_and_swap(void *addr, unsigned long olddata,
			    unsigned long newdata);
extern void ihk_atomic_add_long(long i, long *v);
extern void ihk_atomic_add_ulong(long i, unsigned long *v);
extern unsigned long ihk_atomic_add_long_return(long i, long *v);

#ifdef USE_C_ATOMIC_MODEL
int ihk_atomic_read(const struct ihk_atomic *v) { return v->counter; }
void ihk_atomic_set(struct ihk_atomic *v, int i) { v->counter = i; }
void ihk_atomic_add(int i, struct ihk_atomic *v) { __sync_add_and_fetch(&v->counter, i); }
void ihk_atomic_sub(int i, struct ihk_atomic *v) { __sync_sub_and_fetch(&v->counter, i); }
void ihk_atomic_inc(struct ihk_atomic *v) { __sync_add_and_fetch(&v->counter, 1); }
void ihk_atomic_dec(struct ihk_atomic *v) { __sync_sub_and_fetch(&v->counter, 1); }
int ihk_atomic_dec_and_test(struct ihk_atomic *v) { return __sync_sub_and_fetch(&v->counter, 1) == 0; }
int ihk_atomic_inc_and_test(struct ihk_atomic *v) { return __sync_add_and_fetch(&v->counter, 1) == 0; }
int ihk_atomic_add_return(int i, struct ihk_atomic *v) { return __sync_add_and_fetch(&v->counter, i); }
int ihk_atomic_sub_return(int i, struct ihk_atomic *v) { return __sync_sub_and_fetch(&v->counter, i); }
int ihk_atomic_inc_return(struct ihk_atomic *v) { return ihk_atomic_add_return(1, v); }
int ihk_atomic_dec_return(struct ihk_atomic *v) { return ihk_atomic_sub_return(1, v); }
long ihk_atomic64_read(const struct ihk_atomic64 *v) { return v->counter64; }
void ihk_atomic64_set(struct ihk_atomic64 *v, long i) { v->counter64 = i; }
void ihk_atomic64_inc(struct ihk_atomic64 *v) { __sync_add_and_fetch(&v->counter64, 1); }
long ihk_atomic64_add_return(long i, struct ihk_atomic64 *v) { return __sync_add_and_fetch(&v->counter64, i); }
long ihk_atomic64_sub_return(long i, struct ihk_atomic64 *v) { return __sync_sub_and_fetch(&v->counter64, i); }
unsigned long xchg8(unsigned long *ptr, unsigned long x) { return __sync_lock_test_and_set(ptr, x); }
int xchg4(int *ptr, int x) { return __sync_lock_test_and_set(ptr, x); }
unsigned long atomic_xchg_ulong(unsigned long *ptr, unsigned long x) { return __sync_lock_test_and_set(ptr, x); }
void *atomic_xchg_ptr(void **ptr, void *x) { return __sync_lock_test_and_set(ptr, x); }
unsigned long atomic_cmpxchg8(unsigned long *addr, unsigned long oldval, unsigned long newval) { return __sync_val_compare_and_swap(addr, oldval, newval); }
unsigned long atomic_cmpxchg4(unsigned int *addr, unsigned int oldval, unsigned int newval) { return __sync_val_compare_and_swap(addr, oldval, newval); }
int atomic_cmpxchg_int(int *addr, int oldval, int newval) { return __sync_val_compare_and_swap(addr, oldval, newval); }
unsigned long atomic_cmpxchg_ulong(unsigned long *addr, unsigned long oldval, unsigned long newval) { return __sync_val_compare_and_swap(addr, oldval, newval); }
void *atomic_cmpxchg_ptr(void **addr, void *oldval, void *newval) { return __sync_val_compare_and_swap(addr, oldval, newval); }
int compare_and_swap(void *addr, unsigned long olddata, unsigned long newdata) { return __sync_bool_compare_and_swap((unsigned long *)addr, olddata, newdata); }
void ihk_atomic_add_long(long i, long *v) { __sync_add_and_fetch(v, i); }
void ihk_atomic_add_ulong(long i, unsigned long *v) { __sync_add_and_fetch(v, i); }
unsigned long ihk_atomic_add_long_return(long i, long *v) { return __sync_add_and_fetch(v, i); }
#endif

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	struct ihk_atomic a = { .counter = 0 };
	struct ihk_atomic64 a64 = { .counter64 = 0 };
	unsigned long u64 = 0x1111111122222222UL;
	unsigned int u32 = 0x12345678U;
	unsigned long cas_word = 0x0102030405060708UL;
	int x4 = 77;
	unsigned long xul = 0x1212121234343434UL;
	void *slots[3] = { &a, &a64, &cas_word };
	long sl = 10;
	unsigned long ul = 20;
	unsigned long digest = 0x61746f6d6963UL;

	ihk_atomic_set(&a, -1);
	require(ihk_atomic_read(&a) == -1);
	require(ihk_atomic_inc_and_test(&a) == 1);
	ihk_atomic_add(5, &a);
	require(ihk_atomic_add_return(7, &a) == 12);
	require(ihk_atomic_inc_return(&a) == 13);
	ihk_atomic_sub(2, &a);
	require(ihk_atomic_sub_return(9, &a) == 2);
	require(ihk_atomic_dec_return(&a) == 1);
	ihk_atomic_dec(&a);
	require(ihk_atomic_dec_and_test(&a) == 0);
	mix(&digest, (unsigned int)ihk_atomic_read(&a));

	ihk_atomic64_set(&a64, -5);
	require(ihk_atomic64_read(&a64) == -5);
	ihk_atomic64_inc(&a64);
	require(ihk_atomic64_add_return(100, &a64) == 96);
	require(ihk_atomic64_sub_return(6, &a64) == 90);
	mix(&digest, (unsigned long)ihk_atomic64_read(&a64));

	require(xchg8(&u64, 0x3333333344444444UL) == 0x1111111122222222UL);
	require(xchg4(&x4, -12) == 77);
	require(x4 == -12);
	require(atomic_xchg_ulong(&xul, 0xf0f0f0f00f0f0f0fUL) ==
		0x1212121234343434UL);
	require(xul == 0xf0f0f0f00f0f0f0fUL);
	require(atomic_xchg_ptr(&slots[0], slots[2]) == &a);
	require(slots[0] == &cas_word);
	require(atomic_cmpxchg8(&u64, 0, 1) == 0x3333333344444444UL);
	require(atomic_cmpxchg8(&u64, 0x3333333344444444UL, 0x55) ==
		0x3333333344444444UL);
	require(u64 == 0x55);
	require(atomic_cmpxchg4(&u32, 0, 1) == 0x12345678U);
	require(atomic_cmpxchg4(&u32, 0x12345678U, 0xabcdef01U) ==
		0x12345678U);
	require(u32 == 0xabcdef01U);
	require(atomic_cmpxchg_int(&x4, 0, 99) == -12);
	require(atomic_cmpxchg_int(&x4, -12, 99) == -12);
	require(x4 == 99);
	require(atomic_cmpxchg_ulong(&xul, 0, 1) == 0xf0f0f0f00f0f0f0fUL);
	require(atomic_cmpxchg_ulong(&xul, 0xf0f0f0f00f0f0f0fUL,
				     0x0101010102020202UL) ==
		0xf0f0f0f00f0f0f0fUL);
	require(xul == 0x0101010102020202UL);
	require(atomic_cmpxchg_ptr(&slots[0], slots[1], NULL) == &cas_word);
	require(atomic_cmpxchg_ptr(&slots[0], slots[2], slots[1]) ==
		&cas_word);
	require(slots[0] == &a64);
	require(compare_and_swap(&cas_word, 0, 0xaabbccddeeff0011UL) == 0);
	require(cas_word == 0x0102030405060708UL);
	require(compare_and_swap(&cas_word, 0x0102030405060708UL,
				 0xaabbccddeeff0011UL) == 1);
	require(cas_word == 0xaabbccddeeff0011UL);
	ihk_atomic_add_long(-3, &sl);
	ihk_atomic_add_ulong(4, &ul);
	require(ihk_atomic_add_long_return(9, &sl) == 16);
	require(ul == 24);
	mix(&digest, u64);
	mix(&digest, u32);
	mix(&digest, cas_word);
	mix(&digest, (unsigned int)x4);
	mix(&digest, xul);
	mix(&digest, slots[0] == &a64);
	mix(&digest, (unsigned long)sl);
	mix(&digest, ul);

	printf("atomic_helpers ok digest=%016lx a=%d a64=%ld\n",
	       digest, ihk_atomic_read(&a), ihk_atomic64_read(&a64));
	return 0;
}
