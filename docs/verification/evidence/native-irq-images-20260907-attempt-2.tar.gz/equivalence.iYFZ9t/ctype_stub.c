__attribute__((weak)) int kprintf(const char *format, ...)
{
	(void)format;
	return 0;
}

__attribute__((weak)) void panic(const char *message)
{
	(void)message;
	__builtin_abort();
}

__attribute__((weak)) unsigned char _ctype[256] = {
	['A' ... 'F'] = 0x01 | 0x40,
	['G' ... 'Z'] = 0x01,
	['a' ... 'f'] = 0x02 | 0x40,
	['g' ... 'z'] = 0x02,
	['0' ... '9'] = 0x04 | 0x40,
	[' '] = 0x20 | 0x80,
	['\f'] = 0x20,
	['\n'] = 0x20,
	['\r'] = 0x20,
	['\t'] = 0x20,
	['\v'] = 0x20,
};
