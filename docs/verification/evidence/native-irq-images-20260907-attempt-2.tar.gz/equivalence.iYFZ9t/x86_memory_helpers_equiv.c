#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

#define PTATTR_ACTIVE 0x01UL
#define PTATTR_WRITABLE 0x02UL
#define PTATTR_USER 0x04UL
#define PTATTR_DIRTY 0x40UL
#define PTATTR_LARGEPAGE 0x80UL
#define PTATTR_FILEOFF (1UL << 11)
#define PTATTR_NO_EXECUTE 0x8000000000000000UL
#define PTATTR_UNCACHABLE 0x10000UL
#define PTATTR_FOR_USER 0x20000UL
#define PTATTR_WRITE_COMBINED 0x40000UL
#define VR_PRIVATE 0x2000UL
#define PF_PROT (1UL << 0)
#define PF_WRITE (1UL << 1)
#define PF_USER (1UL << 2)
#define PF_PATCH (1UL << 29)
#define PF_POPULATE (1UL << 30)
#define PF_PRESENT 0x01UL
#define PF_SIZE 0x80UL
#define VPTEF_SKIP_NULL 0x0001
#define PTE_NULL 0UL
#define PT_ENTRIES 512
#define PT_PHYSMASK ((((1UL << 52) - 1)) & ~(4096UL - 1))
#define PAGE_SHIFT 12
#define PAGE_SIZE (1UL << PAGE_SHIFT)
#define PAGE_MASK (~(PAGE_SIZE - 1))
#define PTL1_SHIFT 12
#define PTL2_SHIFT 21
#define PTL3_SHIFT 30
#define PTL4_SHIFT 39
#define PTL1_SIZE (1UL << PTL1_SHIFT)
#define PTL2_SIZE (1UL << PTL2_SHIFT)
#define PTL3_SIZE (1UL << PTL3_SHIFT)
#define IHK_MC_AP_NOWAIT 0x000002
#define IHK_MC_AP_CRITICAL 0x000001
#define PFL2_KERN_ATTR 0x03UL
#define PFL3_PDIR_ATTR 0x07UL
#define PM_STATUS_BITS 3
#define PM_STATUS_OFFSET (64 - PM_STATUS_BITS)
#define PM_STATUS_MASK (((1ULL << PM_STATUS_BITS) - 1) << PM_STATUS_OFFSET)
#define PM_STATUS(nr) (((uint64_t)(nr) << PM_STATUS_OFFSET) & PM_STATUS_MASK)
#define PM_PSHIFT_BITS 6
#define PM_PSHIFT_OFFSET (PM_STATUS_OFFSET - PM_PSHIFT_BITS)
#define PM_PSHIFT_MASK (((1ULL << PM_PSHIFT_BITS) - 1) << PM_PSHIFT_OFFSET)
#define PM_PSHIFT(x) (((uint64_t)(x) << PM_PSHIFT_OFFSET) & PM_PSHIFT_MASK)
#define PM_PFRAME_MASK ((1ULL << PM_PSHIFT_OFFSET) - 1)
#define PM_PFRAME(x) ((x) & PM_PFRAME_MASK)
#define PM_PRESENT PM_STATUS(4ULL)
#define X86_CLEAR_OLD_FLUSH_MEMOBJ 0x01
#define X86_CLEAR_OLD_FREE_ANON 0x02
#define X86_CLEAR_OLD_XPMEM_KEEP 0x04
#define X86_CLEAR_OLD_TRY_UNMAP 0x08
#define X86_CLEAR_EFFECT_FLUSH_MEMOBJ 1
#define X86_CLEAR_EFFECT_FREE_ANON 2
#define X86_CLEAR_EFFECT_XPMEM_KEEP 3
	#define X86_CLEAR_EFFECT_FREE_UNMAPPED 4
	#define X86_CLEAR_EFFECT_CHILD_FREE 5
	#define X86_CLEAR_RANGE_LOG_SPLIT 8
	#define X86_CLEAR_RANGE_LOG_LARGE_PHYS 9
	#define X86_SET_RANGE_LOG_BUSY 1
#define X86_SET_RANGE_LOG_ALLOC_FAILED 2
#define X86_SET_RANGE_LOG_WALK_FAILED 3
#define X86_SET_RANGE_LOG_MAP_LARGE 4
#define X86_SET_RANGE_LOG_RSS_ADD 5
#define X86_SET_RANGE_LOG_RSS_SKIP 6
#define X86_SPLIT_LARGE_PAGE_LOG_INVALID_PGSIZE 1
#define X86_SPLIT_LARGE_PAGE_LOG_ALLOC_FAILED 2
#define X86_SPLIT_LARGE_PAGE_LOG_RSS_ADD 3
#define X86_SPLIT_LARGE_PAGE_LOG_RSS_SUB 4
#define X86_SPLIT_LARGE_PAGE_LOG_PAGE_UNMAP 5
#define X86_PT_SPLIT_LOG_NOT_SPLITABLE 1
#define X86_PT_SPLIT_LOG_SPLIT_FAILED 2
#define X86_MOVE_ONE_LOG_FILEOFF 1
#define X86_MOVE_ONE_LOG_SET_FAILED 2
#define X86_INIT_NORMAL_LOG_RANGE 1
#define X86_INIT_NORMAL_LOG_SET_FAILED 2
#define X86_INIT_TEXT_LOG_LPAGES 1
#define X86_INIT_TEXT_LOG_BASE 2
#define X86_INIT_LINUX_LOG_FULL 1
#define X86_INIT_LINUX_LOG_FULL_RANGE 2
#define X86_INIT_LINUX_LOG_FULL_SET_FAILED 3
#define X86_INIT_LINUX_LOG_CHUNKS 4
#define X86_INIT_LINUX_LOG_NO_CHUNK 5
#define X86_INIT_LINUX_LOG_BAD_CHUNK 6
#define X86_INIT_LINUX_LOG_CHUNK_RANGE 7
#define X86_INIT_LINUX_LOG_CHUNK_SET_FAILED 8
#define X86_ADDR_LOG_KERNEL 1
#define X86_ADDR_LOG_STRAIGHT 2
#define X86_PT_PRINT_LOG_TABLE 1
#define X86_PT_PRINT_LOG_NOT_PRESENT 2
#define X86_PT_PRINT_LOG_ENTRY 3
#define X86_PT_PRINT_LOG_LARGE 4
#define SCD_MSG_GET_VDSO_INFO 0xb

struct x86_fake_ikc_packet_header {
	void *channel;
};

struct x86_fake_syscall_request {
	int rtid;
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};

struct x86_fake_ikc_scd_packet {
	struct x86_fake_ikc_packet_header header;
	int msg;
	int err;
	void *reply;
	union {
		struct {
			int ref;
			int osnum;
			int pid;
			unsigned long arg;
			struct x86_fake_syscall_request req;
			unsigned long resp_pa;
		};
	};
};

extern int x86_vdso_packet_prepare_result(
	struct x86_fake_ikc_scd_packet *, int, unsigned long);
extern unsigned long x86_attr_to_l3attr_result(unsigned long, unsigned long);
extern unsigned long x86_attr_to_l2attr_result(unsigned long, unsigned long);
extern unsigned long x86_attr_to_l1attr_result(unsigned long, unsigned long);
extern unsigned long x86_set_pte_value_result(unsigned long, unsigned long,
					      unsigned long);
extern void set_pte(unsigned long *, unsigned long, unsigned long)
	__attribute__((weak));
extern int set_pt_large_page(void *, void *, unsigned long, unsigned long)
	__attribute__((weak));
extern int ihk_mc_pt_set_large_page(void *, void *, unsigned long, unsigned long)
	__attribute__((weak));
extern int ihk_mc_pt_set_page(void *, void *, unsigned long, unsigned long)
	__attribute__((weak));
extern int x86_pt_set_pte_value_result(size_t, unsigned long, unsigned long,
				       unsigned long, int, unsigned long *);
extern int x86_rust_stub_pt_set_page_calls;
extern int x86_rust_stub_pt_set_page_rc;
extern void *x86_rust_stub_pt_set_page_pt;
extern unsigned long x86_rust_stub_pt_set_page_virt;
extern unsigned long x86_rust_stub_pt_set_page_phys;
extern unsigned long x86_rust_stub_pt_set_page_attr;
extern int x86_smaller_page_size_result(size_t, int, size_t *, int *);
extern unsigned long x86_early_alloc_align_end_result(unsigned long);
extern int x86_early_alloc_exhausted_result(unsigned long, unsigned long);
extern unsigned long x86_early_alloc_next_result(unsigned long, int);
extern void *x86_early_alloc_pages_body_result(
	void **, unsigned long, unsigned long, int, unsigned long (*)(void *),
	void *(*)(unsigned long), void (*)(int));
extern int x86_early_alloc_invalidate_body_result(void **);
extern void *x86_get_last_early_heap_body_result(void **);
extern int x86_check_available_page_size_body_result(
	int *, void (*)(unsigned long, unsigned long *), void (*)(int, int));
extern int x86_enable_ptattr_no_execute_body_result(unsigned long *,
						    unsigned long);
extern void *x86_ihk_mc_allocate_body_result(int, int, int,
					     void *(*)(int, int),
					     void (*)(int));
extern int x86_ihk_mc_free_body_result(int, void *, void (*)(void *),
				       void (*)(int));
extern unsigned long x86_setup_l2_body_result(void *, unsigned long,
					      unsigned long, unsigned long,
					      unsigned long (*)(void *));
extern unsigned long x86_setup_l3_body_result(void *, unsigned long,
					      unsigned long, unsigned long,
					      int, void *(*)(int, int),
					      unsigned long (*)(void *));
extern int x86_init_page_table_body_result(
	void **, void **, int *, void *, size_t, int, void (*)(int),
	void *(*)(int, int), void (*)(void *), void (*)(void *),
	void (*)(void *), void (*)(void *), void (*)(void *),
	void (*)(void *), void (*)(void *), void (*)(void *),
	void (*)(int, void *), void (*)(int));
extern int x86_pt_print_pte_body_result(
	void *, void *, unsigned long, unsigned long (*)(void *),
	void *(*)(unsigned long),
	void (*)(int, int, unsigned long, int));
extern int ihk_mc_pt_print_pte(void *, void *) __attribute__((weak));
extern void *(*x86_rust_stub_pt_phys_to_virt_override)(unsigned long);
extern int x86_rust_stub_pt_print_log_count;
extern int x86_rust_stub_pt_print_last_event;
extern int x86_rust_stub_pt_print_last_level;
extern void x86_pt_indices_result(unsigned long, int *, int *, int *, int *);
extern void x86_walk_bounds_result(unsigned long, unsigned long,
				   unsigned long, unsigned long, int,
				   int *, int *);
extern int x86_walk_step_result(int, int, int *);
extern int x86_walk_pte_range_result(unsigned long, unsigned long long,
				     unsigned long long, unsigned long long,
				     unsigned long long, int,
				     int (*)(void *, unsigned long *,
					      unsigned long long,
					      unsigned long long,
					      unsigned long long),
				     void *, int (*)(unsigned long),
				     unsigned long);
extern int walk_pte_l1(void *, unsigned long long, unsigned long long,
		       unsigned long long,
		       int (*)(void *, unsigned long *, unsigned long long,
				unsigned long long, unsigned long long),
		       void *) __attribute__((weak));
extern int walk_pte_l2(void *, unsigned long long, unsigned long long,
		       unsigned long long,
		       int (*)(void *, unsigned long *, unsigned long long,
				unsigned long long, unsigned long long),
		       void *) __attribute__((weak));
extern int walk_pte_l3(void *, unsigned long long, unsigned long long,
		       unsigned long long,
		       int (*)(void *, unsigned long *, unsigned long long,
				unsigned long long, unsigned long long),
		       void *) __attribute__((weak));
extern int walk_pte_l4(void *, unsigned long long, unsigned long long,
		       unsigned long long,
		       int (*)(void *, unsigned long *, unsigned long long,
				unsigned long long, unsigned long long),
		       void *) __attribute__((weak));
extern int walk_pte_l1_safe(void *, unsigned long long, unsigned long long,
			    unsigned long long,
			    int (*)(void *, unsigned long *,
				     unsigned long long, unsigned long long,
				     unsigned long long),
			    void *) __attribute__((weak));
extern int walk_pte_l2_safe(void *, unsigned long long, unsigned long long,
			    unsigned long long,
			    int (*)(void *, unsigned long *,
				     unsigned long long, unsigned long long,
				     unsigned long long),
			    void *) __attribute__((weak));
extern int walk_pte_l3_safe(void *, unsigned long long, unsigned long long,
			    unsigned long long,
			    int (*)(void *, unsigned long *,
				     unsigned long long, unsigned long long,
				     unsigned long long),
			    void *) __attribute__((weak));
extern int walk_pte_l4_safe(void *, unsigned long long, unsigned long long,
			    unsigned long long,
			    int (*)(void *, unsigned long *,
				     unsigned long long, unsigned long long,
				     unsigned long long),
			    void *) __attribute__((weak));
extern int visit_pte_l1(void *, unsigned long *, unsigned long long,
			unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l1_bridge(void *, unsigned long long,
				    unsigned long long, unsigned long long,
				    void *) __attribute__((weak));
extern int visit_pte_l2(void *, unsigned long *, unsigned long long,
			unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l2_bridge(void *, unsigned long long,
				    unsigned long long, unsigned long long,
				    void *) __attribute__((weak));
extern int visit_pte_l3(void *, unsigned long *, unsigned long long,
			unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l3_bridge(void *, unsigned long long,
				    unsigned long long, unsigned long long,
				    void *) __attribute__((weak));
extern int visit_pte_l4(void *, unsigned long *, unsigned long long,
			unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l4_bridge(void *, unsigned long long,
				    unsigned long long, unsigned long long,
				    void *) __attribute__((weak));
extern int visit_pte_range(void *, void *, void *, int, int,
			   int (*)(void *, void *, unsigned long *, void *,
				    int),
			   void *) __attribute__((weak));
extern int visit_pte_l1_safe(void *, unsigned long *, unsigned long long,
			     unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l1_safe_bridge(void *, unsigned long long,
					 unsigned long long, unsigned long long,
					 void *) __attribute__((weak));
extern int visit_pte_l2_safe(void *, unsigned long *, unsigned long long,
			     unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l2_safe_bridge(void *, unsigned long long,
					 unsigned long long, unsigned long long,
					 void *) __attribute__((weak));
extern int visit_pte_l3_safe(void *, unsigned long *, unsigned long long,
			     unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l3_safe_bridge(void *, unsigned long long,
					 unsigned long long, unsigned long long,
					 void *) __attribute__((weak));
extern int visit_pte_l4_safe(void *, unsigned long *, unsigned long long,
			     unsigned long long, unsigned long long)
	__attribute__((weak));
extern int x86_visit_walk_l4_safe_bridge(void *, unsigned long long,
					 unsigned long long, unsigned long long,
					 void *) __attribute__((weak));
extern int visit_pte_range_safe(void *, void *, void *, int, int,
				int (*)(void *, void *, unsigned long *,
					 void *, int),
				void *) __attribute__((weak));
extern int x86_virt_to_phys_level_result(unsigned long, unsigned long, int,
					 unsigned long, unsigned long *,
					 unsigned long *);
	extern int x86_pt_virt_to_phys_size_result(void *, void *, unsigned long,
						   unsigned long *, unsigned long *,
						   void *(*)(unsigned long));
	extern uint64_t x86_pt_virt_to_pagemap_result(void *, void *, unsigned long,
						      void *(*)(unsigned long));
	extern int ihk_mc_pt_virt_to_phys_size(void *, const void *,
					       unsigned long *, unsigned long *)
		__attribute__((weak));
	extern int ihk_mc_pt_virt_to_phys(void *, const void *, unsigned long *)
		__attribute__((weak));
	extern uint64_t ihk_mc_pt_virt_to_pagemap(void *, unsigned long)
		__attribute__((weak));
	extern void *x86_rust_stub_init_pt_override __attribute__((weak));
	extern void *(*x86_rust_stub_phys_to_virt_override)(unsigned long)
		__attribute__((weak));
	extern int x86_split_large_page_prepare_result(unsigned long, size_t,
						       unsigned long *, size_t *,
						       unsigned long *);
extern unsigned long x86_split_large_page_next_entry_result(unsigned long,
							    size_t);
extern int x86_split_large_page_source_result(unsigned long, size_t,
					      unsigned long *,
					      unsigned long *, size_t *);
extern int x86_split_large_page_child_map_result(unsigned long, size_t,
						 int, unsigned long *);
extern unsigned long x86_split_large_page_publish_result(unsigned long);
extern int x86_split_large_page_source_unmap_result(unsigned long, size_t,
						    unsigned long *);
extern int x86_split_large_page_body_result(unsigned long *, size_t, int,
					    void *(*)(int, int),
					    unsigned long (*)(void *),
					    void *(*)(unsigned long),
					    void (*)(void *),
					    void (*)(size_t, size_t),
					    void (*)(size_t, size_t),
					    int (*)(void *),
					    void (*)(int, unsigned long,
						     size_t, size_t, void *),
					    void (*)(void));
extern int x86_pt_split_body_result(void *, void *, unsigned long,
				    unsigned int, int,
				    unsigned long *(*)(void *, unsigned long,
						       int, unsigned long *,
						       size_t *, int *),
				    void *(*)(unsigned long),
				    int (*)(void *, unsigned int),
				    int (*)(unsigned long *, size_t),
				    void (*)(void *, unsigned long, int),
				    void (*)(int, int));
extern unsigned long x86_clear_pt_page_aligned_addr_result(unsigned long, int);
extern int x86_clear_pt_page_target_result(unsigned long, int, int *);
extern int x86_pt_clear_page_result(void *, void *, unsigned long, int,
				    void *(*)(unsigned long));
extern int ihk_mc_pt_clear_page(void *, void *) __attribute__((weak));
extern int ihk_mc_pt_clear_large_page(void *, void *) __attribute__((weak));
extern int x86_visit_pte_action_result(unsigned long, int, unsigned long,
				       unsigned long, unsigned long,
				       unsigned long, int, int,
				       unsigned long, int, int, int);
extern int x86_visit_pte_leaf_result(void *, void *, unsigned long *,
				     unsigned long, int, int,
				     int (*)(void *, void *,
					      unsigned long *, void *, int));
extern int x86_visit_pte_level_result(void *, void *, unsigned long *,
				      unsigned long, unsigned long,
				      unsigned long, int, int, int,
				      unsigned long, int, unsigned long,
				      int, int, int, unsigned long,
				      void *(*)(int, int),
				      unsigned long (*)(void *),
				      void *(*)(unsigned long),
				      int (*)(void *, unsigned long,
					       unsigned long, unsigned long,
					       void *),
				      void *,
				      int (*)(void *, void *,
					       unsigned long *, void *, int),
				      void (*)(int, int));
extern int x86_visit_pte_root_result(unsigned long *, unsigned long,
				     unsigned long, unsigned long, int, int,
				     unsigned long, void *(*)(int, int),
				     unsigned long (*)(void *),
				     void *(*)(unsigned long),
				     int (*)(void *, unsigned long,
					      unsigned long, unsigned long,
					      void *),
				     void *);
extern int x86_visit_pte_range_dispatch_result(void *, unsigned long,
					       unsigned long, void *,
					       int (*)(void *,
							unsigned long,
							unsigned long,
							unsigned long,
							void *));
extern int x86_clear_range_validate_result(unsigned long, unsigned long,
					   unsigned long, unsigned long);
extern int x86_clear_range_free_physical_result(int, int, int, int);
extern int x86_clear_range_entry_action_result(unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long);
extern void x86_clear_range_old_entry_result(unsigned long, size_t,
					     unsigned long *, int *, int *);
extern int x86_clear_range_old_action_result(int, int, int, int, int, int,
					     int, int);
extern int x86_remote_flush_tlb_add_addr_result(void *, unsigned long *,
						int *, int, unsigned long,
						int,
						void (*)(void *, unsigned long *,
							  int, int));
extern int x86_clear_range_old_effects_result(int, int, int, void *, void *,
					      unsigned long, unsigned long,
					      size_t,
					      void (*)(void *, unsigned long,
						       size_t),
					      void *(*)(unsigned long),
					      void (*)(void *, int),
					      int (*)(void *),
					      void (*)(size_t, size_t),
					      void (*)(void *, size_t,
						       size_t),
					      void (*)(int, unsigned long,
						       unsigned long, size_t));
	extern int x86_clear_range_child_table_result(unsigned long *, void *,
						     unsigned long, unsigned long,
						     unsigned long, unsigned long,
						     int, void *, unsigned long *,
						     int *, int, int,
						     void (*)(void *, unsigned long *,
							       int, int),
						     void (*)(void *, int),
						     void (*)(int, unsigned long,
							       unsigned long, size_t));
	extern int x86_clear_range_leaf_body_result(void *, unsigned long *,
						    unsigned long, unsigned long,
						    unsigned long, void *,
						    unsigned long *, int *, int,
						    int, int, void *,
						    int (*)(void *,
							     unsigned long, size_t,
							     unsigned long *,
							     void **, int *),
						    void (*)(void *,
							     unsigned long *,
							     int, int),
						    void (*)(void *,
							     unsigned long,
							     size_t),
						    void *(*)(unsigned long),
						    void (*)(void *, int),
						    int (*)(void *),
						    void (*)(size_t, size_t),
						    void (*)(void *, size_t,
							     size_t),
						    void (*)(int, unsigned long,
							     unsigned long,
							     size_t));
	extern int x86_clear_range_level_body_result(void *, unsigned long *,
						     unsigned long,
						     unsigned long,
						     unsigned long, int,
						     unsigned long,
						     unsigned long, int, void *,
						     unsigned long *, int *,
						     int, int, int, void *,
						     int (*)(void *,
							      unsigned long,
							      size_t,
							      unsigned long *,
							      void **, int *),
						     void *(*)(unsigned long),
						     int (*)(void *,
							      unsigned long,
							      unsigned long,
							      unsigned long,
							      void *),
						     void (*)(void *,
							      unsigned long *,
							      int, int),
						     void (*)(void *, int),
						     void (*)(void *,
							      unsigned long,
							      size_t),
						     void (*)(void *, int),
						     int (*)(void *),
						     void (*)(size_t, size_t),
						     void (*)(void *, size_t,
							      size_t),
						     void (*)(int, void *,
							      unsigned long *,
							      unsigned long,
							      unsigned long,
							      unsigned long,
							      int, int,
							      unsigned long),
						     void (*)(int,
							      unsigned long,
							      unsigned long,
							      size_t));
	extern int x86_clear_range_root_body_result(void *, unsigned long *,
						    unsigned long, unsigned long,
						    unsigned long,
						    void *(*)(unsigned long),
						    int (*)(void *,
							     unsigned long,
							     unsigned long,
							     unsigned long,
							     void *));
	extern int x86_change_attr_leaf_action_result(unsigned long, unsigned long);
extern int x86_change_attr_entry_action_result(unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      unsigned long);
extern int x86_pt_change_attr_range_result(void *, unsigned long,
					   unsigned long, unsigned long,
					   unsigned long,
					   void *(*)(unsigned long));
extern int x86_set_range_leaf_action_result(unsigned long);
extern int x86_set_range_entry_action_result(unsigned long, unsigned long,
					    unsigned long, unsigned long,
					    unsigned long, int, int,
					    unsigned long, unsigned long, int);
extern int x86_set_range_map_entry_result(unsigned long, unsigned long,
					  unsigned long, unsigned long, int,
					  unsigned long, unsigned long *,
					  unsigned long *);
extern int x86_set_range_conflict_result(void *, void *, unsigned long,
					 unsigned long, unsigned long,
					 unsigned long, int, int,
					 int (*)(void *, void *,
						  unsigned long,
						  unsigned long, int, void *),
					 void (*)(int, int, unsigned long,
						   unsigned long,
						   unsigned long, int,
						   unsigned long,
						   unsigned long, size_t,
						   size_t, int));
extern int x86_set_range_alloc_failed_result(void *, void *, unsigned long,
					     unsigned long, unsigned long,
					     unsigned long, int, int,
					     int (*)(void *, void *,
						      unsigned long,
						      unsigned long, int,
						      void *),
					     void (*)(int, int,
						       unsigned long,
						       unsigned long,
						       unsigned long, int,
						       unsigned long,
						       unsigned long, size_t,
						       size_t, int));
extern int x86_set_range_walk_failed_result(int, unsigned long,
					    unsigned long, unsigned long,
					    unsigned long, int,
					    void (*)(int, int,
						      unsigned long,
						      unsigned long,
						      unsigned long, int,
						      unsigned long,
						      unsigned long, size_t,
						      size_t, int));
extern int x86_set_range_map_effect_result(unsigned long, unsigned long,
					   unsigned long, unsigned long,
					   unsigned long, int,
					   unsigned long, size_t,
					   unsigned long *, void *, int,
					   int (*)(void *, unsigned long,
						    size_t, size_t),
					   void (*)(int, int,
						     unsigned long,
						     unsigned long,
						     unsigned long, int,
						     unsigned long,
						     unsigned long, size_t,
						     size_t, int));
extern int x86_set_range_leaf_body_result(void *, unsigned long *,
					  unsigned long, unsigned long,
					  unsigned long, void *, void *,
					  unsigned long, unsigned long,
					  unsigned long, void *,
					  int (*)(void *, void *,
						   unsigned long,
						   unsigned long, int, void *),
					  int (*)(void *, unsigned long,
						   size_t, size_t),
					  void (*)(int, int,
						    unsigned long,
						    unsigned long,
						    unsigned long, int,
						    unsigned long,
						    unsigned long, size_t,
						    size_t, int));
extern int x86_set_range_level_body_result(void *, unsigned long *,
					   unsigned long, unsigned long,
					   unsigned long, void *, void *,
					   unsigned long, unsigned long,
					   unsigned long, unsigned long, int,
					   int, unsigned long, unsigned long,
					   int, unsigned long, void *,
					   void *(*)(int, int),
					   void (*)(void *, int),
					   unsigned long (*)(void *),
					   void *(*)(unsigned long),
					   int (*)(void *, unsigned long,
						    unsigned long,
						    unsigned long, void *),
					   int (*)(void *, void *,
						    unsigned long,
						    unsigned long, int,
						    void *),
					   int (*)(void *, unsigned long,
						    size_t, size_t),
					   void (*)(int, int,
						     unsigned long,
						     unsigned long,
						     unsigned long, int,
						     unsigned long,
						     unsigned long, size_t,
						     size_t, int));
extern int x86_clear_range_top_result(void *, void *, unsigned long,
				      unsigned long, unsigned long,
				      unsigned long, int, int, int, int,
				      void *, unsigned long **, int *,
				      int *, int *, void **, void **, int,
				      unsigned long, void *,
				      void *(*)(int, int),
				      void (*)(void *, int),
				      int (*)(void *, unsigned long,
					       unsigned long, unsigned long,
					       void *),
				      void (*)(void *, unsigned long *,
					       int, int),
				      int,
				      void (*)(int, void *, unsigned long,
					       unsigned long, int));
extern int x86_set_range_top_result(void *, void *, unsigned long,
				    unsigned long, unsigned long, int, int,
				    void *, void *, void **,
				    unsigned long *, int *,
				    unsigned long *, void **, int *,
				    void **,
				    int (*)(void *, unsigned long,
					     unsigned long, unsigned long,
					     void *),
				    void (*)(int, int, unsigned long,
					     unsigned long, unsigned long,
					     int, unsigned long,
					     unsigned long, size_t,
					     size_t, int));
extern int x86_pte_store_result(unsigned long *, unsigned long);
extern unsigned long x86_pte_publish_table_result(unsigned long *,
						  unsigned long);
extern unsigned long x86_pte_clear_result(unsigned long *);
extern unsigned long x86_pte_apply_attr_result(unsigned long *, unsigned long,
					       unsigned long);
extern int x86_pt_kernel_lock_needed_result(unsigned long);
extern void *x86_pt_alloc_zeroed_result(int, void *(*)(int, int));
extern unsigned long *x86_pt_get_pte_result(void *, void *, unsigned long,
					    unsigned long, unsigned long, int,
					    void *(*)(int, int),
					    unsigned long (*)(void *),
					    void *(*)(unsigned long));
extern int x86_pt_set_page_body_result(void *, void *, unsigned long,
				       unsigned long, unsigned long,
				       unsigned long, void *(*)(int, int),
				       unsigned long (*)(void *),
				       void *(*)(unsigned long),
				       void (*)(unsigned long));
extern int x86_lookup_default_pgshift_result(int, int);
extern int x86_lookup_l4_empty_pgshift_result(int);
extern int x86_lookup_level_action_result(unsigned long, int, int,
					  unsigned long);
extern void x86_lookup_shape_result(unsigned long, int, unsigned long *,
				    size_t *, int *);
extern unsigned long *x86_pt_lookup_pte_result(void *, unsigned long, int,
					       int, unsigned long *,
					       size_t *, int *,
					       void *(*)(unsigned long));
extern int x86_move_pte_preflight_result(unsigned long, size_t,
					 unsigned long, unsigned long,
					 unsigned long, unsigned long *);
extern int x86_move_one_page_body_result(void *, void *, unsigned long *,
					 unsigned long, int, unsigned long,
					 unsigned long, void *, void *,
					 int (*)(void *, void *,
						  unsigned long, unsigned long,
						  unsigned long, unsigned long,
						  int, void *, int),
					 void (*)(int, void *, void *,
						  unsigned long *,
						  unsigned long,
						  unsigned long,
						  unsigned long, int, int));
extern int x86_move_pte_range_body_result(void *, unsigned long,
					  unsigned long, size_t, void *,
					  void *, void *, uintptr_t *,
					  uintptr_t *, void **, void **,
					  int (*)(void *, void *,
						   unsigned long *, void *,
						   int),
					  int (*)(void *, unsigned long,
						   unsigned long, int, int,
						   int (*)(void *, void *,
							    unsigned long *,
							    void *, int),
						   void *),
					  void (*)(void));
extern unsigned long x86_read_cr3_result(void);
extern void x86_load_cr3_result(unsigned long);
extern void x86_flush_tlb_body_result(unsigned long (*)(void),
				      void (*)(unsigned long));
extern void x86_flush_tlb_result(void);
extern void x86_flush_tlb_single_body_result(unsigned long,
					     void (*)(unsigned long));
extern void x86_flush_tlb_single_result(unsigned long);
extern int x86_load_page_table_body_result(void *, void *,
					   unsigned long (*)(void *),
					   void (*)(unsigned long));
extern void *x86_map_fixed_area_body_result(void *, unsigned long *,
					    unsigned long, unsigned long,
					    int,
					    int (*)(void *, unsigned long,
						     unsigned long,
						     unsigned long),
					    void (*)(void));
extern int x86_init_normal_area_body_result(void *, unsigned long,
					    unsigned long, unsigned long,
					    int, int,
					    unsigned long (*)(int, int),
					    int (*)(void *, unsigned long,
						     unsigned long,
						     unsigned long),
					    void (*)(int, unsigned long,
						     unsigned long,
						     unsigned long));
extern int x86_init_text_area_body_result(void *, unsigned long,
					  unsigned long, unsigned long,
					  int, unsigned long, unsigned long,
					  unsigned long,
					  int (*)(void *, unsigned long,
						   unsigned long,
						   unsigned long),
					  void (*)(int, unsigned long,
						   unsigned long,
						   unsigned long));
extern int x86_init_fixed_area_body_result(unsigned long *, unsigned long);
extern int x86_init_low_area_body_result(void *, unsigned long,
					 unsigned long,
					 int (*)(void *, unsigned long,
						  unsigned long,
						  unsigned long));
extern int x86_init_vsyscall_area_body_result(void *, unsigned long, void *,
					      unsigned long,
					      unsigned long (*)(void *),
					      int (*)(void *, unsigned long,
						       unsigned long,
						       unsigned long));
extern int x86_init_linux_kernel_mapping_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	char *, char *(*)(char *), int (*)(void),
	int (*)(int, unsigned long *, unsigned long *, int *),
	int (*)(void *, unsigned long, unsigned long, unsigned long),
	void (*)(int, unsigned long, unsigned long, unsigned long,
		 unsigned long, int));
extern unsigned long x86_virt_to_phys_body_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, void (*)(int, unsigned long));
extern void *x86_phys_to_virt_body_result(unsigned long, int,
					  unsigned long, unsigned long);
extern int x86_reserve_arch_pages_body_result(
	void *, unsigned long, unsigned long, void *, void *, unsigned long,
	unsigned long, unsigned long, unsigned long (*)(void *),
	void (*)(void *, unsigned long, unsigned long, int),
	void (*)(unsigned long, unsigned long,
		 void (*)(void *, unsigned long, unsigned long, int)));
extern void x86_move_pte_entry_parts_result(unsigned long, unsigned long *,
					    unsigned long *);
extern unsigned long x86_arch_vrflag_to_ptattr_result(unsigned long,
						      uint64_t,
						      unsigned long);
extern int x86_destroy_pt_entry_action_result(int, unsigned long,
					      unsigned long *);
extern void *x86_pt_create_result(void *, int, void *(*)(int, int));
extern int x86_pt_destroy_table_result(int, void *,
				       void *(*)(unsigned long),
				       void (*)(void *, int),
				       void (*)(int));
extern void x86_pt_destroy_root_result(void *, void (*)(int, void *));
extern void *ihk_mc_pt_create(int) __attribute__((weak));
extern void ihk_mc_pt_destroy(void *) __attribute__((weak));
extern int x86_pt_prepare_map_result(void *, void *, unsigned long,
				     unsigned long, int, unsigned long,
				     void *(*)(int, int),
				     unsigned long (*)(void *),
				     int (*)(void *, unsigned long,
					     unsigned long, unsigned long));
extern int ihk_mc_pt_prepare_map(void *, void *, unsigned long, int)
	__attribute__((weak));
extern int x86_pt_set_pte_body_result(void *, unsigned long *, size_t,
				      unsigned long, unsigned long,
				      unsigned long, int,
				      void (*)(int, void *, unsigned long *,
					       size_t, unsigned long,
					       unsigned long, int,
					       unsigned long),
				      void (*)(void));
extern int x86_verify_process_vm_result(void *, unsigned long, size_t,
					unsigned long, unsigned long,
					unsigned long,
					int (*)(void *, void *,
						 unsigned long),
					void (*)(int, void *,
						 unsigned long,
						 unsigned long, int));
extern int x86_process_vm_copy_result(void *, void *, unsigned long,
				      unsigned long, size_t, unsigned long,
				      unsigned long, unsigned long, int,
				      int (*)(void *, void *,
					       unsigned long),
				      int (*)(void *, const void *,
					       unsigned long *),
				      int (*)(unsigned long, unsigned long),
				      void *(*)(unsigned long, int,
						unsigned long),
				      void (*)(void *, int),
				      void *(*)(unsigned long),
				      void (*)(int, void *, unsigned long,
					       unsigned long, int));
extern int x86_copy_from_user_result(void *, void *, const void *, size_t,
				     int (*)(void *, void *, const void *,
					      size_t));
extern int x86_copy_to_user_result(void *, void *, const void *, size_t,
				   int (*)(void *, void *, const void *,
					    size_t));
extern long x86_getlong_user_result(long *, const long *,
				    int (*)(void *, const void *, size_t));
extern int x86_getint_user_result(int *, const int *,
				  int (*)(void *, const void *, size_t));
extern int x86_setlong_user_result(long *, long,
				   int (*)(void *, const void *, size_t));
extern int x86_setint_user_result(int *, int,
				  int (*)(void *, const void *, size_t));
extern int x86_strlen_user_result(void *, const char *, unsigned long,
				  int (*)(void *, void *, unsigned long));
extern int x86_strcpy_from_user_result(void *, char *, const char *,
				       unsigned long,
				       int (*)(void *, void *,
						unsigned long));
extern int x86_copy_from_user_public_result(void *, void *, const void *,
					    size_t,
					    int (*)(void *, void *,
						     const void *, size_t));
extern int x86_copy_to_user_public_result(void *, void *, const void *,
					  size_t,
					  int (*)(void *, void *,
						   const void *, size_t));
extern int x86_copy_from_user_direct_public_result(void *, void *,
						   const void *, size_t,
						   int (*)(void *, void *,
							    unsigned long),
						   int (*)(void *,
							    const void *,
							    unsigned long *),
						   int (*)(unsigned long,
							    unsigned long),
						   void *(*)(unsigned long,
							      int,
							      unsigned long),
						   void (*)(void *, int),
						   void *(*)(unsigned long),
						   void (*)(int, void *,
							    unsigned long,
							    unsigned long,
							    int));
extern int x86_copy_to_user_direct_public_result(void *, void *,
						 const void *, size_t,
						 int (*)(void *, void *,
							  unsigned long),
						 int (*)(void *,
							  const void *,
							  unsigned long *),
						 int (*)(unsigned long,
							  unsigned long),
						 void *(*)(unsigned long, int,
							   unsigned long),
						 void (*)(void *, int),
						 void *(*)(unsigned long),
						 void (*)(int, void *,
							  unsigned long,
							  unsigned long,
							  int));
extern int x86_strlen_user_public_result(void *, const char *,
					 unsigned long,
					 int (*)(void *, void *,
						  unsigned long));
extern int x86_strcpy_from_user_public_result(void *, char *, const char *,
					      unsigned long,
					      int (*)(void *, void *,
						       unsigned long));
extern long x86_getlong_user_public_result(long *, const long *,
					   int (*)(void *, const void *,
						    size_t));
extern int x86_getint_user_public_result(int *, const int *,
					 int (*)(void *, const void *,
						  size_t));
extern int x86_setlong_user_public_result(long *, long,
					  int (*)(void *, const void *,
						   size_t));
extern int x86_setint_user_public_result(int *, int,
					 int (*)(void *, const void *,
						  size_t));
extern int x86_verify_process_vm_public_result(void *, const void *, size_t,
					       int (*)(void *, void *,
							unsigned long),
					       void (*)(int, void *,
							unsigned long,
							unsigned long, int));
extern int x86_read_process_vm_public_result(void *, void *, const void *,
					     size_t,
					     int (*)(void *, void *,
						      unsigned long),
					     int (*)(void *, const void *,
						      unsigned long *),
					     int (*)(unsigned long,
						      unsigned long),
					     void *(*)(unsigned long, int,
						       unsigned long),
					     void (*)(void *, int),
					     void *(*)(unsigned long),
					     void (*)(int, void *,
						      unsigned long,
						      unsigned long, int));
extern int x86_write_process_vm_public_result(void *, void *, const void *,
					      size_t,
					      int (*)(void *, void *,
						       unsigned long),
					      int (*)(void *, const void *,
						       unsigned long *),
					      int (*)(unsigned long,
						       unsigned long),
					      void *(*)(unsigned long, int,
							unsigned long),
					      void (*)(void *, int),
					      void *(*)(unsigned long),
					      void (*)(int, void *,
						       unsigned long,
						       unsigned long, int));
extern int x86_patch_process_vm_public_result(void *, void *, const void *,
					      size_t,
					      int (*)(void *, void *,
						       unsigned long),
					      int (*)(void *, const void *,
						       unsigned long *),
					      int (*)(unsigned long,
						       unsigned long),
					      void *(*)(unsigned long, int,
							unsigned long),
					      void (*)(void *, int),
					      void *(*)(unsigned long),
					      void (*)(int, void *,
						       unsigned long,
						       unsigned long, int));

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

struct walk_trace {
	unsigned long digest;
	int calls;
	int enoent_mode;
	int fail_after;
	int fail_error;
};

static int fake_walk_pte_cb(void *arg, unsigned long *ptep,
			    unsigned long long base,
			    unsigned long long start,
			    unsigned long long end)
{
	struct walk_trace *trace = arg;

	trace->calls++;
	mix(&trace->digest, *ptep);
	mix(&trace->digest, (unsigned long)base);
	mix(&trace->digest, (unsigned long)start);
	mix(&trace->digest, (unsigned long)end);
	if (trace->fail_after && trace->calls == trace->fail_after)
		return trace->fail_error;
	if (trace->enoent_mode)
		return -2;
	return 0;
}

static int fake_walk_phys_check(unsigned long phys)
{
	return phys == 0xdead000UL ? -1 : 0;
}

struct fake_page_table {
	unsigned long entry[PT_ENTRIES];
};

static struct fake_page_table fake_created_tables[4];
static int fake_pt_alloc_count;
static int fake_pt_alloc_fail;
static int fake_pt_last_ap_flag;
static int fake_pt_destroy_calls;
static int fake_pt_destroy_level;
static void *fake_pt_destroy_ptr;
static int fake_pt_destroy_table_phys_calls;
static int fake_pt_destroy_table_free_calls;
static void *fake_pt_destroy_table_free_order[8];
static int fake_pt_destroy_table_free_npages[8];
static int fake_pt_destroy_table_panic_reason;
static int fake_pt_set_page_calls;
static int fake_pt_set_page_fail_after;
static int fake_pt_set_page_fail_error;
static unsigned long fake_pt_set_page_digest;
static void *fake_pt_set_expected_pt;
static int fake_pt_set_pte_log_count;
static int fake_pt_set_pte_panic_count;
static unsigned long fake_pt_set_pte_digest;
static int fake_pt_set_page_log_count;
static unsigned long fake_pt_set_page_log_digest;
static int fake_split_phys_to_page_calls;
static int fake_split_page_map_calls;
static int fake_split_rss_add_calls;
static int fake_split_rss_sub_calls;
static int fake_split_page_unmap_calls;
static int fake_split_page_unmap_result;
static int fake_split_log_calls;
static int fake_split_log_event;
static int fake_split_panic_calls;
static unsigned long fake_split_digest;
static unsigned long fake_pt_split_slots[4];
static unsigned long *fake_pt_split_pteps[8];
static unsigned long fake_pt_split_pgaddrs[8];
static size_t fake_pt_split_pgsizes[8];
static int fake_pt_split_seq_len;
static int fake_pt_split_lookup_calls;
static int fake_pt_splitable_calls;
static int fake_pt_splitable_result;
static void *fake_pt_split_last_page;
static unsigned int fake_pt_split_last_flags;
static int fake_pt_split_large_calls;
static int fake_pt_split_large_result;
static int fake_pt_split_flush_calls;
static void *fake_pt_split_flush_vm;
static unsigned long fake_pt_split_flush_addr;
static int fake_pt_split_flush_cpu;
static int fake_pt_split_log_calls;
static int fake_pt_split_log_event;
static int fake_pt_split_log_error;
static unsigned long fake_pt_split_digest;
static int fake_move_set_range_calls;
static int fake_move_set_range_result;
static unsigned long fake_move_set_start;
static unsigned long fake_move_set_end;
static unsigned long fake_move_set_phys;
static unsigned long fake_move_set_attr;
static int fake_move_set_pgshift;
static void *fake_move_set_pt;
static void *fake_move_set_vm;
static void *fake_move_set_range_arg;
static int fake_move_set_overwrite;
static int fake_move_log_calls;
static int fake_move_log_event;
static int fake_move_log_error;
static unsigned long fake_move_log_entry;
static unsigned long fake_move_log_current;
static unsigned long fake_move_digest;
struct fake_move_range_args {
	uintptr_t src;
	uintptr_t dest;
	void *vm;
	void *range;
};
static int fake_move_range_visit_calls;
static int fake_move_range_visit_result;
static int fake_move_range_call_visitor;
static int fake_move_range_visitor_calls;
static int fake_move_range_flush_calls;
static void *fake_move_range_visit_pt;
static unsigned long fake_move_range_visit_start;
static unsigned long fake_move_range_visit_end;
static int fake_move_range_visit_pgshift;
static int fake_move_range_visit_flags;
static void *fake_move_range_visit_arg;
static unsigned long fake_move_range_arg_src;
static unsigned long fake_move_range_arg_dest;
static void *fake_move_range_arg_vm;
static void *fake_move_range_arg_range;
static unsigned long fake_move_range_digest;
static int fake_load_cr3_calls;
static unsigned long fake_load_cr3_addr;
static int fake_read_cr3_calls;
static int fake_invlpg_calls;
static unsigned long fake_invlpg_addr;
static unsigned long fake_load_digest;
static int fake_mem_panic_count;
static int fake_mem_panic_reason;
static unsigned long fake_mem_cpuid_edx_value;
static unsigned long fake_mem_cpuid_op;
static int fake_mem_log_count;
static int fake_mem_log_event;
static int fake_mem_log_value;
static int fake_mem_kmalloc_calls;
static int fake_mem_kmalloc_size;
static int fake_mem_kmalloc_flag;
static int fake_mem_kfree_calls;
static void *fake_mem_kfree_ptr;
static unsigned char fake_mem_alloc_buf[64];
static unsigned char fake_init_pt_pages[2][4096];
static int fake_init_page_alloc_calls;
static int fake_init_page_alloc_fail_at;
static int fake_init_page_alloc_flags[4];
static int fake_init_page_order_count;
static int fake_init_page_order[32];
static int fake_init_page_spin_init_calls;
static void *fake_init_page_spin_lock;
static int fake_init_page_loaded_calls;
static void *fake_init_page_loaded_pt;
static int fake_init_page_log_count;
static int fake_init_page_log_event;
static void *fake_init_page_log_pt;
static int fake_fixed_set_calls;
static int fake_fixed_set_fail_after;
static int fake_fixed_flush_calls;
static unsigned long fake_fixed_virt[8];
static unsigned long fake_fixed_phys[8];
static unsigned long fake_fixed_attr[8];
static unsigned long fake_fixed_digest;
static unsigned long fake_init_normal_map_start;
static unsigned long fake_init_normal_map_end;
static int fake_init_normal_get_calls;
static int fake_init_normal_set_calls;
static int fake_init_normal_set_fail_after;
static int fake_init_normal_log_calls;
static int fake_init_normal_fail_log_calls;
static unsigned long fake_init_normal_virt[8];
static unsigned long fake_init_normal_phys[8];
static unsigned long fake_init_normal_attr[8];
static unsigned long fake_init_normal_digest;
static int fake_init_text_set_calls;
static int fake_init_text_set_fail_after;
static int fake_init_text_log_calls;
static unsigned long fake_init_text_nlpages;
static unsigned long fake_init_text_base;
static unsigned long fake_init_text_virt[8];
static unsigned long fake_init_text_phys[8];
static unsigned long fake_init_text_attr[8];
static unsigned long fake_init_text_digest;
static int fake_init_linux_safe_present;
static int fake_init_linux_find_calls;
static int fake_init_linux_get_nr_calls;
static int fake_init_linux_nr_chunks;
static int fake_init_linux_get_chunk_calls;
static int fake_init_linux_bad_chunk_id;
static int fake_init_linux_set_calls;
static int fake_init_linux_set_fail_after;
static int fake_init_linux_log_calls;
static int fake_init_linux_log_event_counts[9];
static unsigned long fake_init_linux_chunk_start[4];
static unsigned long fake_init_linux_chunk_end[4];
static unsigned long fake_init_linux_virt[16];
static unsigned long fake_init_linux_phys[16];
static unsigned long fake_init_linux_attr[16];
static unsigned long fake_init_linux_digest;
static int fake_addr_log_calls;
static int fake_addr_log_kernel_calls;
static int fake_addr_log_straight_calls;
static unsigned long fake_addr_log_digest;
static int fake_reserve_cb_calls;
static void *fake_reserve_cb_pa[8];
static unsigned long fake_reserve_cb_start[8];
static unsigned long fake_reserve_cb_end[8];
static int fake_reserve_cb_flag[8];
static int fake_reserve_arch_calls;
static unsigned long fake_reserve_arch_start;
static unsigned long fake_reserve_arch_end;
static void (*fake_reserve_arch_cb)(void *, unsigned long, unsigned long,
				    int);
static unsigned long fake_reserve_digest;

static void *fake_pt_alloc_pages(int nr_pages, int ap_flag)
{
	struct fake_page_table *pt;

	if (fake_pt_alloc_fail || nr_pages != 1 ||
	    fake_pt_alloc_count >= (int)(sizeof(fake_created_tables) /
		    sizeof(fake_created_tables[0]))) {
		return NULL;
	}

	fake_pt_last_ap_flag = ap_flag;
	pt = &fake_created_tables[fake_pt_alloc_count++];
	for (int i = 0; i < PT_ENTRIES; i++)
		pt->entry[i] = 0xf00d0000UL + (unsigned long)i;
	return pt;
}

static void fake_pt_destroy(int level, void *pt)
{
	fake_pt_destroy_calls++;
	fake_pt_destroy_level = level;
	fake_pt_destroy_ptr = pt;
}

static unsigned long fake_pt_destroy_phys(void *addr)
{
	for (int i = 0;
	     i < (int)(sizeof(fake_created_tables) /
		     sizeof(fake_created_tables[0])); i++) {
		if (addr == &fake_created_tables[i])
			return 0x400000000UL + ((unsigned long)i << 12);
	}

	return 0;
}

static void *fake_pt_destroy_phys_to_virt(unsigned long phys)
{
	fake_pt_destroy_table_phys_calls++;
	for (int i = 0;
	     i < (int)(sizeof(fake_created_tables) /
		     sizeof(fake_created_tables[0])); i++) {
		if (phys == fake_pt_destroy_phys(&fake_created_tables[i]))
			return &fake_created_tables[i];
	}

	return NULL;
}

static void fake_pt_destroy_free_pages(void *pt, int nr_pages)
{
	if (fake_pt_destroy_table_free_calls <
	    (int)(sizeof(fake_pt_destroy_table_free_order) /
		    sizeof(fake_pt_destroy_table_free_order[0]))) {
		fake_pt_destroy_table_free_order[
			fake_pt_destroy_table_free_calls] = pt;
		fake_pt_destroy_table_free_npages[
			fake_pt_destroy_table_free_calls] = nr_pages;
	}
	fake_pt_destroy_table_free_calls++;
}

static void fake_pt_destroy_panic(int reason)
{
	fake_pt_destroy_table_panic_reason = reason;
}

static int fake_pt_destroy_helper_failed_calls;

void *x86_pt_alloc_pages_bridge(int nr_pages, int ap_flag)
{
	return fake_pt_alloc_pages(nr_pages, ap_flag);
}

void x86_pt_free_pages_bridge(void *pt, int nr_pages)
{
	fake_pt_destroy_free_pages(pt, nr_pages);
}

void x86_pt_destroy_panic_bridge(int reason)
{
	fake_pt_destroy_panic(reason);
}

void x86_pt_destroy_helper_failed_panic_bridge(void)
{
	fake_pt_destroy_helper_failed_calls++;
}

static void reset_fake_pt_destroy_table(void)
{
	fake_pt_destroy_table_phys_calls = 0;
	fake_pt_destroy_table_free_calls = 0;
	fake_pt_destroy_table_panic_reason = 0;
	fake_pt_destroy_helper_failed_calls = 0;
	memset(fake_pt_destroy_table_free_order, 0,
		sizeof(fake_pt_destroy_table_free_order));
	memset(fake_pt_destroy_table_free_npages, 0,
		sizeof(fake_pt_destroy_table_free_npages));
	for (int i = 0;
	     i < (int)(sizeof(fake_created_tables) /
		     sizeof(fake_created_tables[0])); i++)
		memset(&fake_created_tables[i], 0, sizeof(fake_created_tables[i]));
}

struct fake_user_copy_vm {
	unsigned long user_start;
	unsigned long user_end;
	int page_fault_calls;
	int page_fault_fail_after;
	int page_fault_error;
	unsigned long page_fault_reason_digest;
	int vtop_calls;
	int vtop_fail_after;
	int is_memory_result;
	int map_calls;
	int unmap_calls;
	int log_calls;
	unsigned long log_digest;
};

static unsigned char fake_user_copy_space[8192];
static unsigned long fake_user_copy_base;
static struct fake_user_copy_vm *active_fake_user_copy;
static struct fake_public_thread *active_fake_public_thread;

struct fake_public_address_space {
	void *page_table;
};

struct fake_public_vm_regions {
	unsigned long vm_start, vm_end;
	unsigned long text_start, text_end;
	unsigned long data_start, data_end;
	unsigned long brk_start, brk_end, brk_end_allocated;
	unsigned long map_start, map_end;
	unsigned long stack_start, stack_end;
	unsigned long user_start, user_end;
};

struct fake_public_process_vm {
	struct fake_public_address_space *address_space;
	void *vm_range_tree_root;
	struct fake_public_vm_regions region;
};

struct fake_public_thread {
	unsigned char before_vm[4200];
	struct fake_public_process_vm *vm;
};

static void reset_fake_user_copy(struct fake_user_copy_vm *vm)
{
	memset(vm, 0, sizeof(*vm));
	active_fake_user_copy = vm;
	vm->user_start = fake_user_copy_base;
	vm->user_end = fake_user_copy_base + sizeof(fake_user_copy_space);
	vm->is_memory_result = 1;
	memset(fake_user_copy_space, 0, sizeof(fake_user_copy_space));
}

static void fake_public_prepare(struct fake_public_process_vm *pvm,
				struct fake_public_address_space *asp,
				struct fake_public_thread *thread,
				struct fake_user_copy_vm *vm)
{
	memset(pvm, 0, sizeof(*pvm));
	memset(asp, 0, sizeof(*asp));
	memset(thread, 0, sizeof(*thread));
	asp->page_table = vm;
	pvm->address_space = asp;
	pvm->region.user_start = vm->user_start;
	pvm->region.user_end = vm->user_end;
	thread->vm = pvm;
	active_fake_user_copy = vm;
	active_fake_public_thread = thread;
}

static unsigned long fake_user_copy_digest_addr(unsigned long value)
{
	if (value >= fake_user_copy_base &&
	    value < fake_user_copy_base + sizeof(fake_user_copy_space))
		return 0x100000UL + (value - fake_user_copy_base);
	return value ? 1 : 0;
}

static unsigned long fake_user_copy_page_safe_offset(unsigned long padding)
{
	unsigned long aligned;

	aligned = ((fake_user_copy_base + PAGE_SIZE - 1) & PAGE_MASK) -
		fake_user_copy_base;
	return aligned + padding;
}

static int fake_user_page_fault(void *vmp, void *addr, unsigned long reason)
{
	struct fake_user_copy_vm *vm = vmp;

	vm->page_fault_calls++;
	mix(&vm->page_fault_reason_digest, (unsigned long)addr);
	mix(&vm->page_fault_reason_digest, reason);
	if (vm->page_fault_fail_after &&
	    vm->page_fault_calls == vm->page_fault_fail_after)
		return vm->page_fault_error;
	return 0;
}

static int fake_user_verify(void *vmp, void *addr, unsigned long size)
{
	struct fake_user_copy_vm *vm = vmp;
	unsigned long uaddr = (unsigned long)addr;

	vm->page_fault_calls++;
	mix(&vm->page_fault_reason_digest, uaddr);
	mix(&vm->page_fault_reason_digest, size);
	if (uaddr < vm->user_start || vm->user_end <= uaddr ||
	    vm->user_end - uaddr < size)
		return -14;
	if (vm->page_fault_fail_after &&
	    vm->page_fault_calls == vm->page_fault_fail_after)
		return vm->page_fault_error;
	return 0;
}

static int fake_user_vtop(void *pt, const void *virt, unsigned long *pa)
{
	struct fake_user_copy_vm *vm = pt;
	unsigned long uaddr = (unsigned long)virt;

	vm->vtop_calls++;
	if (vm->vtop_fail_after && vm->vtop_calls == vm->vtop_fail_after)
		return -77;
	*pa = (unsigned long)&fake_user_copy_space[uaddr - fake_user_copy_base];
	return 0;
}

static int fake_user_is_memory(unsigned long start, unsigned long end)
{
	(void)end;
	return active_fake_user_copy->is_memory_result && start != 0;
}

static void *fake_user_map(unsigned long phys, int nr_pages, unsigned long attr)
{
	struct fake_user_copy_vm *vm = active_fake_user_copy;

	vm->map_calls++;
	mix(&vm->log_digest, nr_pages);
	mix(&vm->log_digest, attr);
	return (void *)phys;
}

static void fake_user_unmap(void *addr, int nr_pages)
{
	struct fake_user_copy_vm *vm = active_fake_user_copy;

	vm->unmap_calls++;
	mix(&vm->log_digest,
		fake_user_copy_digest_addr((unsigned long)addr));
	mix(&vm->log_digest, nr_pages);
}

static void *fake_user_phys_to_virt(unsigned long phys)
{
	return (void *)phys;
}

static void fake_user_log(int event, void *vmp, unsigned long a,
			  unsigned long b, int error)
{
	struct fake_user_copy_vm *vm = vmp;

	vm->log_calls++;
	mix(&vm->log_digest, (unsigned long)event);
	mix(&vm->log_digest, fake_user_copy_digest_addr(a));
	mix(&vm->log_digest, fake_user_copy_digest_addr(b));
	mix(&vm->log_digest, (unsigned int)error);
}

static int fake_user_read_process_vm(void *vm, void *dst, const void *src,
				     size_t size)
{
	return x86_process_vm_copy_result(vm, vm, (unsigned long)src,
		(unsigned long)dst, size,
		((struct fake_user_copy_vm *)vm)->user_start,
		((struct fake_user_copy_vm *)vm)->user_end,
		1UL << 2, 0, fake_user_page_fault, fake_user_vtop,
		fake_user_is_memory, fake_user_map, fake_user_unmap,
		fake_user_phys_to_virt, fake_user_log);
}

static int fake_user_write_process_vm(void *vm, void *dst, const void *src,
				      size_t size)
{
	return x86_process_vm_copy_result(vm, vm, (unsigned long)dst,
		(unsigned long)src, size,
		((struct fake_user_copy_vm *)vm)->user_start,
		((struct fake_user_copy_vm *)vm)->user_end,
		(1UL << 30) | (1UL << 1) | (1UL << 2), 1,
		fake_user_page_fault, fake_user_vtop, fake_user_is_memory,
		fake_user_map, fake_user_unmap, fake_user_phys_to_virt,
		fake_user_log);
}

static int fake_public_user_page_fault(void *vmp, void *addr,
				       unsigned long reason)
{
	(void)vmp;
	return fake_user_page_fault(active_fake_user_copy, addr, reason);
}

static int fake_public_user_verify(void *vmp, void *addr,
				   unsigned long size)
{
	(void)vmp;
	return fake_user_verify(active_fake_user_copy, addr, size);
}

static void fake_public_user_log(int event, void *vmp, unsigned long a,
				 unsigned long b, int error)
{
	(void)vmp;
	fake_user_log(event, active_fake_user_copy, a, b, error);
}

static int fake_public_user_read_process_vm(void *vm, void *dst,
					    const void *src, size_t size)
{
	return x86_read_process_vm_public_result(vm, dst, src, size,
		fake_public_user_page_fault, fake_user_vtop,
		fake_user_is_memory, fake_user_map, fake_user_unmap,
		fake_user_phys_to_virt, fake_public_user_log);
}

static int fake_public_user_write_process_vm(void *vm, void *dst,
					     const void *src, size_t size)
{
	return x86_write_process_vm_public_result(vm, dst, src, size,
		fake_public_user_page_fault, fake_user_vtop,
		fake_user_is_memory, fake_user_map, fake_user_unmap,
		fake_user_phys_to_virt, fake_public_user_log);
}

static int fake_public_copy_from_user_global(void *dst, const void *src,
					     size_t size)
{
	return x86_copy_from_user_public_result(active_fake_public_thread, dst,
		src, size, fake_public_user_read_process_vm);
}

static int fake_public_copy_to_user_global(void *dst, const void *src,
					   size_t size)
{
	return x86_copy_to_user_public_result(active_fake_public_thread, dst,
		src, size, fake_public_user_write_process_vm);
}

static int fake_user_copy_from_user_global(void *dst, const void *src,
					   size_t size)
{
	return x86_copy_from_user_result(active_fake_user_copy, dst, src, size,
		fake_user_read_process_vm);
}

static int fake_user_copy_to_user_global(void *dst, const void *src,
					 size_t size)
{
	return x86_copy_to_user_result(active_fake_user_copy, dst, src, size,
		fake_user_write_process_vm);
}

static unsigned long fake_pt_virt_to_phys(void *addr)
{
	for (int i = 0;
	     i < (int)(sizeof(fake_created_tables) /
		     sizeof(fake_created_tables[0])); i++) {
		if (addr == &fake_created_tables[i])
			return 0x100000000UL + ((unsigned long)i << 12);
	}

	return 0x1fff0000UL;
}

static int fake_pt_set_page(void *pt, unsigned long virt, unsigned long phys,
			    unsigned long attr)
{
	fake_pt_set_page_calls++;
	mix(&fake_pt_set_page_digest, pt == fake_pt_set_expected_pt);
	mix(&fake_pt_set_page_digest, virt);
	mix(&fake_pt_set_page_digest, phys);
	mix(&fake_pt_set_page_digest, attr);

	if (fake_pt_set_page_fail_after &&
	    fake_pt_set_page_calls == fake_pt_set_page_fail_after) {
		return fake_pt_set_page_fail_error;
	}

	return 0;
}

static void fake_pt_set_pte_log(int event, void *pt, unsigned long *ptep,
				size_t pgsize, unsigned long phys,
				unsigned long attr, int error,
				unsigned long current)
{
	fake_pt_set_pte_log_count++;
	mix(&fake_pt_set_pte_digest, (unsigned int)event);
	mix(&fake_pt_set_pte_digest, pt == fake_pt_set_expected_pt);
	mix(&fake_pt_set_pte_digest, ptep != NULL);
	mix(&fake_pt_set_pte_digest, pgsize);
	mix(&fake_pt_set_pte_digest, phys);
	mix(&fake_pt_set_pte_digest, attr);
	mix(&fake_pt_set_pte_digest, (unsigned int)-error);
	mix(&fake_pt_set_pte_digest, current);
}

static void fake_pt_set_pte_panic(void)
{
	fake_pt_set_pte_panic_count++;
	mix(&fake_pt_set_pte_digest, 0x70616e6963UL);
}

static void fake_pt_set_page_log(unsigned long virt)
{
	fake_pt_set_page_log_count++;
	mix(&fake_pt_set_page_log_digest, virt);
}

static void reset_fake_split_large_page(void)
{
	fake_split_phys_to_page_calls = 0;
	fake_split_page_map_calls = 0;
	fake_split_rss_add_calls = 0;
	fake_split_rss_sub_calls = 0;
	fake_split_page_unmap_calls = 0;
	fake_split_page_unmap_result = 0;
	fake_split_log_calls = 0;
	fake_split_log_event = 0;
	fake_split_panic_calls = 0;
	fake_split_digest = 0x73706c69747067UL;
	fake_pt_alloc_count = 0;
	fake_pt_alloc_fail = 0;
	fake_pt_last_ap_flag = -1;
	memset(fake_created_tables, 0, sizeof(fake_created_tables));
}

static void *fake_split_phys_to_page(unsigned long phys)
{
	fake_split_phys_to_page_calls++;
	mix(&fake_split_digest, phys);
	return (void *)(uintptr_t)(0x500000000UL | (phys & 0xfffff000UL));
}

static void fake_split_page_map(void *page)
{
	fake_split_page_map_calls++;
	mix(&fake_split_digest, (unsigned long)(uintptr_t)page);
}

static void fake_split_rss_add(size_t size, size_t pgsize)
{
	fake_split_rss_add_calls++;
	mix(&fake_split_digest, size);
	mix(&fake_split_digest, pgsize);
}

static void fake_split_rss_sub(size_t size, size_t pgsize)
{
	fake_split_rss_sub_calls++;
	mix(&fake_split_digest, size);
	mix(&fake_split_digest, pgsize);
}

static int fake_split_page_unmap(void *page)
{
	fake_split_page_unmap_calls++;
	mix(&fake_split_digest, (unsigned long)(uintptr_t)page);
	return fake_split_page_unmap_result;
}

static void fake_split_log(int event, unsigned long value, size_t size,
			   size_t pgsize, void *page)
{
	fake_split_log_calls++;
	fake_split_log_event = event;
	mix(&fake_split_digest, (unsigned int)event);
	mix(&fake_split_digest, value);
	mix(&fake_split_digest, size);
	mix(&fake_split_digest, pgsize);
	mix(&fake_split_digest, (unsigned long)(uintptr_t)page);
}

static void fake_split_panic(void)
{
	fake_split_panic_calls++;
	mix(&fake_split_digest, 0x70616e6963UL);
}

static void reset_fake_pt_split(void)
{
	memset(fake_pt_split_slots, 0, sizeof(fake_pt_split_slots));
	memset(fake_pt_split_pteps, 0, sizeof(fake_pt_split_pteps));
	memset(fake_pt_split_pgaddrs, 0, sizeof(fake_pt_split_pgaddrs));
	memset(fake_pt_split_pgsizes, 0, sizeof(fake_pt_split_pgsizes));
	fake_pt_split_seq_len = 0;
	fake_pt_split_lookup_calls = 0;
	fake_pt_splitable_calls = 0;
	fake_pt_splitable_result = 1;
	fake_pt_split_last_page = NULL;
	fake_pt_split_last_flags = 0;
	fake_pt_split_large_calls = 0;
	fake_pt_split_large_result = 0;
	fake_pt_split_flush_calls = 0;
	fake_pt_split_flush_vm = NULL;
	fake_pt_split_flush_addr = 0;
	fake_pt_split_flush_cpu = 0;
	fake_pt_split_log_calls = 0;
	fake_pt_split_log_event = 0;
	fake_pt_split_log_error = 0;
	fake_pt_split_digest = 0x707473706c6974UL;
}

static unsigned long *fake_pt_split_lookup(void *pt, unsigned long addr,
					   int pgshift, unsigned long *pgaddrp,
					   size_t *pgsizep, int *p2alignp)
{
	int ix = fake_pt_split_lookup_calls++;

	mix(&fake_pt_split_digest, pt == (void *)0x1111UL);
	mix(&fake_pt_split_digest, addr);
	mix(&fake_pt_split_digest, (unsigned int)pgshift);
	mix(&fake_pt_split_digest, p2alignp == NULL);

	if (ix >= fake_pt_split_seq_len) {
		if (pgaddrp)
			*pgaddrp = addr;
		if (pgsizep)
			*pgsizep = PTL1_SIZE;
		return NULL;
	}

	if (pgaddrp)
		*pgaddrp = fake_pt_split_pgaddrs[ix];
	if (pgsizep)
		*pgsizep = fake_pt_split_pgsizes[ix];
	return fake_pt_split_pteps[ix];
}

static void *fake_pt_split_phys_to_page(unsigned long phys)
{
	mix(&fake_pt_split_digest, phys);
	return (void *)(uintptr_t)(0x600000000UL | (phys & 0xfffff000UL));
}

static int fake_pt_splitable(void *page, unsigned int memobj_flags)
{
	fake_pt_splitable_calls++;
	fake_pt_split_last_page = page;
	fake_pt_split_last_flags = memobj_flags;
	mix(&fake_pt_split_digest, (unsigned long)(uintptr_t)page);
	mix(&fake_pt_split_digest, memobj_flags);
	return fake_pt_splitable_result;
}

static int fake_pt_split_large(unsigned long *ptep, size_t pgsize)
{
	fake_pt_split_large_calls++;
	mix(&fake_pt_split_digest, ptep == &fake_pt_split_slots[0]);
	mix(&fake_pt_split_digest, pgsize);
	if (!fake_pt_split_large_result && ptep)
		*ptep = 0x777000UL | PF_PRESENT;
	return fake_pt_split_large_result;
}

static void fake_pt_split_flush(void *vm, unsigned long addr, int cpu_id)
{
	fake_pt_split_flush_calls++;
	fake_pt_split_flush_vm = vm;
	fake_pt_split_flush_addr = addr;
	fake_pt_split_flush_cpu = cpu_id;
	mix(&fake_pt_split_digest, vm == (void *)0x2222UL);
	mix(&fake_pt_split_digest, addr);
	mix(&fake_pt_split_digest, (unsigned int)cpu_id);
}

static void fake_pt_split_log(int event, int error)
{
	fake_pt_split_log_calls++;
	fake_pt_split_log_event = event;
	fake_pt_split_log_error = error;
	mix(&fake_pt_split_digest, (unsigned int)event);
	mix(&fake_pt_split_digest, (unsigned int)-error);
}

static void reset_fake_move_one(void)
{
	fake_move_set_range_calls = 0;
	fake_move_set_range_result = 0;
	fake_move_set_start = 0;
	fake_move_set_end = 0;
	fake_move_set_phys = 0;
	fake_move_set_attr = 0;
	fake_move_set_pgshift = 0;
	fake_move_set_pt = NULL;
	fake_move_set_vm = NULL;
	fake_move_set_range_arg = NULL;
	fake_move_set_overwrite = -1;
	fake_move_log_calls = 0;
	fake_move_log_event = 0;
	fake_move_log_error = 0;
	fake_move_log_entry = 0;
	fake_move_log_current = 0;
	fake_move_digest = 0x6d6f76656f6e65UL;
}

static int fake_move_set_range_fn(void *pt, void *vm, unsigned long start,
				  unsigned long end, unsigned long phys,
				  unsigned long attr, int pgshift, void *range,
				  int overwrite)
{
	fake_move_set_range_calls++;
	fake_move_set_pt = pt;
	fake_move_set_vm = vm;
	fake_move_set_start = start;
	fake_move_set_end = end;
	fake_move_set_phys = phys;
	fake_move_set_attr = attr;
	fake_move_set_pgshift = pgshift;
	fake_move_set_range_arg = range;
	fake_move_set_overwrite = overwrite;
	mix(&fake_move_digest, pt == (void *)0x1111UL);
	mix(&fake_move_digest, vm == (void *)0x2222UL);
	mix(&fake_move_digest, range == (void *)0x3333UL);
	mix(&fake_move_digest, start);
	mix(&fake_move_digest, end);
	mix(&fake_move_digest, phys);
	mix(&fake_move_digest, attr);
	mix(&fake_move_digest, (unsigned int)pgshift);
	mix(&fake_move_digest, (unsigned int)overwrite);
	return fake_move_set_range_result;
}

static void fake_move_log(int event, void *arg, void *pt,
			  unsigned long *ptep, unsigned long entry,
			  unsigned long current, unsigned long pgaddr,
			  int pgshift, int error)
{
	fake_move_log_calls++;
	fake_move_log_event = event;
	fake_move_log_error = error;
	fake_move_log_entry = entry;
	fake_move_log_current = current;
	mix(&fake_move_digest, (unsigned int)event);
	mix(&fake_move_digest, arg == (void *)0x4444UL);
	mix(&fake_move_digest, pt == (void *)0x1111UL);
	mix(&fake_move_digest, ptep != NULL);
	mix(&fake_move_digest, entry);
	mix(&fake_move_digest, current);
	mix(&fake_move_digest, pgaddr);
	mix(&fake_move_digest, (unsigned int)pgshift);
	mix(&fake_move_digest, (unsigned int)-error);
}

static void reset_fake_move_range(void)
{
	fake_move_range_visit_calls = 0;
	fake_move_range_visit_result = 0;
	fake_move_range_call_visitor = 0;
	fake_move_range_visitor_calls = 0;
	fake_move_range_flush_calls = 0;
	fake_move_range_visit_pt = NULL;
	fake_move_range_visit_start = 0;
	fake_move_range_visit_end = 0;
	fake_move_range_visit_pgshift = -1;
	fake_move_range_visit_flags = 0;
	fake_move_range_visit_arg = NULL;
	fake_move_range_arg_src = 0;
	fake_move_range_arg_dest = 0;
	fake_move_range_arg_vm = NULL;
	fake_move_range_arg_range = NULL;
	fake_move_range_digest = 0x6d6f76726e6765UL;
}

static int fake_move_range_visitor(void *arg, void *pt, unsigned long *ptep,
				   void *base, int pgshift)
{
	struct fake_move_range_args *args = arg;

	fake_move_range_visitor_calls++;
	if (args) {
		fake_move_range_arg_src = args->src;
		fake_move_range_arg_dest = args->dest;
		fake_move_range_arg_vm = args->vm;
		fake_move_range_arg_range = args->range;
	}
	mix(&fake_move_range_digest, pt == (void *)0x1111UL);
	mix(&fake_move_range_digest, ptep != NULL);
	mix(&fake_move_range_digest, (unsigned long)(uintptr_t)base);
	mix(&fake_move_range_digest, (unsigned int)pgshift);
	return 0;
}

static int fake_move_range_visit(void *pt, unsigned long start,
				 unsigned long end, int pgshift, int flags,
				 int (*visitor)(void *, void *,
						unsigned long *, void *, int),
				 void *arg)
{
	static unsigned long pte_slot = 0x12345001UL;

	fake_move_range_visit_calls++;
	fake_move_range_visit_pt = pt;
	fake_move_range_visit_start = start;
	fake_move_range_visit_end = end;
	fake_move_range_visit_pgshift = pgshift;
	fake_move_range_visit_flags = flags;
	fake_move_range_visit_arg = arg;
	mix(&fake_move_range_digest, pt == (void *)0x1111UL);
	mix(&fake_move_range_digest, start);
	mix(&fake_move_range_digest, end);
	mix(&fake_move_range_digest, (unsigned int)pgshift);
	mix(&fake_move_range_digest, (unsigned int)flags);
	mix(&fake_move_range_digest, visitor == fake_move_range_visitor);
	if (fake_move_range_call_visitor && visitor)
		return visitor(arg, pt, &pte_slot, (void *)start, PTL1_SHIFT);
	return fake_move_range_visit_result;
}

static void fake_move_range_flush(void)
{
	fake_move_range_flush_calls++;
	mix(&fake_move_range_digest, 0x666c757368UL);
}

static void reset_fake_load_page_table(void)
{
	fake_load_cr3_calls = 0;
	fake_load_cr3_addr = 0;
	fake_read_cr3_calls = 0;
	fake_invlpg_calls = 0;
	fake_invlpg_addr = 0;
	fake_load_digest = 0x6c6f61647067UL;
	fake_mem_panic_count = 0;
	fake_mem_panic_reason = 0;
	fake_mem_cpuid_edx_value = 0;
	fake_mem_cpuid_op = 0;
	fake_mem_log_count = 0;
	fake_mem_log_event = 0;
	fake_mem_log_value = 0;
	fake_mem_kmalloc_calls = 0;
	fake_mem_kmalloc_size = 0;
	fake_mem_kmalloc_flag = 0;
	fake_mem_kfree_calls = 0;
	fake_mem_kfree_ptr = NULL;
	memset(fake_init_pt_pages, 0xa5, sizeof(fake_init_pt_pages));
	fake_init_page_alloc_calls = 0;
	fake_init_page_alloc_fail_at = 0;
	memset(fake_init_page_alloc_flags, 0, sizeof(fake_init_page_alloc_flags));
	fake_init_page_order_count = 0;
	memset(fake_init_page_order, 0, sizeof(fake_init_page_order));
	fake_init_page_spin_init_calls = 0;
	fake_init_page_spin_lock = NULL;
	fake_init_page_loaded_calls = 0;
	fake_init_page_loaded_pt = NULL;
	fake_init_page_log_count = 0;
	fake_init_page_log_event = 0;
	fake_init_page_log_pt = NULL;
}

static unsigned long fake_read_cr3(void)
{
	fake_read_cr3_calls++;
	mix(&fake_load_digest, 0x72656164637233UL);
	return 0xabcde000UL;
}

static void fake_load_cr3(unsigned long pt_addr)
{
	fake_load_cr3_calls++;
	fake_load_cr3_addr = pt_addr;
	mix(&fake_load_digest, pt_addr);
}

static void fake_invlpg(unsigned long addr)
{
	fake_invlpg_calls++;
	fake_invlpg_addr = addr;
	mix(&fake_load_digest, addr);
}

static unsigned long fake_mem_virt_to_phys(void *addr)
{
	unsigned long value = (unsigned long)addr;

	mix(&fake_load_digest, value);
	if (value >= 0xffff800000000000UL)
		return value - 0xffff800000000000UL;
	return value - 0xffff000000000000UL;
}

static void *fake_mem_phys_to_virt(unsigned long phys)
{
	mix(&fake_load_digest, phys);
	return (void *)(phys + 0xffff800000000000UL);
}

static void fake_mem_panic(int reason)
{
	fake_mem_panic_count++;
	fake_mem_panic_reason = reason;
	mix(&fake_load_digest, (unsigned long)(unsigned int)reason);
}

static void fake_mem_cpuid_edx(unsigned long op, unsigned long *edxp)
{
	fake_mem_cpuid_op = op;
	*edxp = fake_mem_cpuid_edx_value;
}

static void fake_mem_log_int(int event, int value)
{
	fake_mem_log_count++;
	fake_mem_log_event = event;
	fake_mem_log_value = value;
}

static void fake_mem_log(int event)
{
	fake_mem_log_count++;
	fake_mem_log_event = event;
}

static void *fake_mem_kmalloc(int size, int flag)
{
	fake_mem_kmalloc_calls++;
	fake_mem_kmalloc_size = size;
	fake_mem_kmalloc_flag = flag;
	return fake_mem_alloc_buf;
}

static void fake_mem_kfree(void *ptr)
{
	fake_mem_kfree_calls++;
	fake_mem_kfree_ptr = ptr;
}

static void fake_init_page_record(int event)
{
	fake_init_page_order[fake_init_page_order_count] = event;
	fake_init_page_order_count++;
}

static void fake_init_page_check(int event)
{
	fake_init_page_record(10 + event);
}

static void *fake_init_page_alloc(int nr_pages, int flag)
{
	fake_init_page_alloc_calls++;
	fake_init_page_alloc_flags[fake_init_page_alloc_calls - 1] = flag;
	fake_init_page_record(20 + fake_init_page_alloc_calls);
	if (fake_init_page_alloc_fail_at == fake_init_page_alloc_calls)
		return NULL;
	if (nr_pages != 1) {
		fake_init_page_record(99);
		return NULL;
	}
	return fake_init_pt_pages[fake_init_page_alloc_calls - 1];
}

static void fake_init_page_spin_init(void *lock)
{
	fake_init_page_spin_init_calls++;
	fake_init_page_spin_lock = lock;
	fake_init_page_record(30);
}

static void fake_init_page_normal(void *pt)
{
	if (pt != fake_init_pt_pages[0])
		fake_init_page_record(99);
	fake_init_pt_pages[0][0] = 0x11;
	fake_init_page_record(40);
}

static void fake_init_page_linux(void *pt)
{
	if (pt != fake_init_pt_pages[0])
		fake_init_page_record(99);
	fake_init_pt_pages[0][1] = 0x22;
	fake_init_page_record(41);
}

static void fake_init_page_fixed(void *pt)
{
	if (pt != fake_init_pt_pages[0])
		fake_init_page_record(99);
	fake_init_pt_pages[0][2] = 0x33;
	fake_init_page_record(42);
}

static void fake_init_page_text(void *pt)
{
	if (pt != fake_init_pt_pages[0])
		fake_init_page_record(99);
	fake_init_pt_pages[0][3] = 0x44;
	fake_init_page_record(43);
}

static void fake_init_page_vsyscall(void *pt)
{
	if (pt != fake_init_pt_pages[0])
		fake_init_page_record(99);
	fake_init_pt_pages[0][4] = 0x55;
	fake_init_page_record(44);
}

static void fake_init_page_low(void *pt)
{
	if (pt != fake_init_pt_pages[1])
		fake_init_page_record(99);
	fake_init_pt_pages[1][7] ^= 0x7f;
	fake_init_page_record(45);
}

static void fake_init_page_low_noop(void *pt)
{
	if (pt != fake_init_pt_pages[1])
		fake_init_page_record(99);
	fake_init_page_record(46);
}

static void fake_init_page_load(void *pt)
{
	fake_init_page_loaded_calls++;
	fake_init_page_loaded_pt = pt;
	fake_init_page_record(50);
}

static void fake_init_page_log(int event, void *pt)
{
	fake_init_page_log_count++;
	fake_init_page_log_event = event;
	fake_init_page_log_pt = pt;
	fake_init_page_record(60 + event);
}

static void reset_fake_fixed_area(void)
{
	fake_fixed_set_calls = 0;
	fake_fixed_set_fail_after = 0;
	fake_fixed_flush_calls = 0;
	memset(fake_fixed_virt, 0, sizeof(fake_fixed_virt));
	memset(fake_fixed_phys, 0, sizeof(fake_fixed_phys));
	memset(fake_fixed_attr, 0, sizeof(fake_fixed_attr));
	fake_fixed_digest = 0x666978656461UL;
}

static int fake_fixed_set_page(void *pt, unsigned long virt,
			       unsigned long phys, unsigned long attr)
{
	int ix = fake_fixed_set_calls++;

	mix(&fake_fixed_digest, pt == (void *)0x1111UL);
	mix(&fake_fixed_digest, virt);
	mix(&fake_fixed_digest, phys);
	mix(&fake_fixed_digest, attr);
	if (ix < (int)(sizeof(fake_fixed_virt) / sizeof(fake_fixed_virt[0]))) {
		fake_fixed_virt[ix] = virt;
		fake_fixed_phys[ix] = phys;
		fake_fixed_attr[ix] = attr;
	}
	if (fake_fixed_set_fail_after &&
	    fake_fixed_set_calls == fake_fixed_set_fail_after)
		return -5;
	return 0;
}

static void fake_fixed_flush(void)
{
	fake_fixed_flush_calls++;
	mix(&fake_fixed_digest, 0x666c757368UL);
}

static void reset_fake_init_normal_area(void)
{
	fake_init_normal_map_start = 0;
	fake_init_normal_map_end = 0;
	fake_init_normal_get_calls = 0;
	fake_init_normal_set_calls = 0;
	fake_init_normal_set_fail_after = 0;
	fake_init_normal_log_calls = 0;
	fake_init_normal_fail_log_calls = 0;
	memset(fake_init_normal_virt, 0, sizeof(fake_init_normal_virt));
	memset(fake_init_normal_phys, 0, sizeof(fake_init_normal_phys));
	memset(fake_init_normal_attr, 0, sizeof(fake_init_normal_attr));
	fake_init_normal_digest = 0x696e69746e6f72UL;
}

static unsigned long fake_init_normal_get_addr(int type, int arg)
{
	fake_init_normal_get_calls++;
	mix(&fake_init_normal_digest, (unsigned int)type);
	mix(&fake_init_normal_digest, (unsigned int)arg);
	if (type == 11)
		return fake_init_normal_map_start;
	if (type == 12)
		return fake_init_normal_map_end;
	return 0;
}

static int fake_init_normal_set_large(void *pt, unsigned long virt,
				      unsigned long phys, unsigned long attr)
{
	int ix = fake_init_normal_set_calls++;

	mix(&fake_init_normal_digest, pt == (void *)0x1111UL);
	mix(&fake_init_normal_digest, virt);
	mix(&fake_init_normal_digest, phys);
	mix(&fake_init_normal_digest, attr);
	if (ix < (int)(sizeof(fake_init_normal_virt) /
		       sizeof(fake_init_normal_virt[0]))) {
		fake_init_normal_virt[ix] = virt;
		fake_init_normal_phys[ix] = phys;
		fake_init_normal_attr[ix] = attr;
	}
	if (fake_init_normal_set_fail_after &&
	    fake_init_normal_set_calls == fake_init_normal_set_fail_after)
		return -5;
	return 0;
}

static void fake_init_normal_log(int event, unsigned long a, unsigned long b,
				 unsigned long c)
{
	fake_init_normal_log_calls++;
	mix(&fake_init_normal_digest, (unsigned int)event);
	mix(&fake_init_normal_digest, a);
	mix(&fake_init_normal_digest, b);
	mix(&fake_init_normal_digest, c);
	if (event == X86_INIT_NORMAL_LOG_SET_FAILED)
		fake_init_normal_fail_log_calls++;
}

static void reset_fake_init_text_area(void)
{
	fake_init_text_set_calls = 0;
	fake_init_text_set_fail_after = 0;
	fake_init_text_log_calls = 0;
	fake_init_text_nlpages = 0;
	fake_init_text_base = 0;
	memset(fake_init_text_virt, 0, sizeof(fake_init_text_virt));
	memset(fake_init_text_phys, 0, sizeof(fake_init_text_phys));
	memset(fake_init_text_attr, 0, sizeof(fake_init_text_attr));
	fake_init_text_digest = 0x74657874696e69UL;
}

static int fake_init_text_set_large(void *pt, unsigned long virt,
				    unsigned long phys, unsigned long attr)
{
	int ix = fake_init_text_set_calls++;

	mix(&fake_init_text_digest, pt == (void *)0x1111UL);
	mix(&fake_init_text_digest, virt);
	mix(&fake_init_text_digest, phys);
	mix(&fake_init_text_digest, attr);
	if (ix < (int)(sizeof(fake_init_text_virt) /
		       sizeof(fake_init_text_virt[0]))) {
		fake_init_text_virt[ix] = virt;
		fake_init_text_phys[ix] = phys;
		fake_init_text_attr[ix] = attr;
	}
	if (fake_init_text_set_fail_after &&
	    fake_init_text_set_calls == fake_init_text_set_fail_after)
		return -5;
	return 0;
}

static void fake_init_text_log(int event, unsigned long a, unsigned long b,
			       unsigned long c)
{
	fake_init_text_log_calls++;
	mix(&fake_init_text_digest, (unsigned int)event);
	mix(&fake_init_text_digest, a);
	mix(&fake_init_text_digest, b);
	mix(&fake_init_text_digest, c);
	if (event == X86_INIT_TEXT_LOG_LPAGES)
		fake_init_text_nlpages = a;
	if (event == X86_INIT_TEXT_LOG_BASE)
		fake_init_text_base = a;
}

static void reset_fake_init_linux_mapping(void)
{
	fake_init_linux_safe_present = 0;
	fake_init_linux_find_calls = 0;
	fake_init_linux_get_nr_calls = 0;
	fake_init_linux_nr_chunks = 0;
	fake_init_linux_get_chunk_calls = 0;
	fake_init_linux_bad_chunk_id = -1;
	fake_init_linux_set_calls = 0;
	fake_init_linux_set_fail_after = 0;
	fake_init_linux_log_calls = 0;
	memset(fake_init_linux_log_event_counts, 0,
		sizeof(fake_init_linux_log_event_counts));
	memset(fake_init_linux_chunk_start, 0,
		sizeof(fake_init_linux_chunk_start));
	memset(fake_init_linux_chunk_end, 0,
		sizeof(fake_init_linux_chunk_end));
	memset(fake_init_linux_virt, 0, sizeof(fake_init_linux_virt));
	memset(fake_init_linux_phys, 0, sizeof(fake_init_linux_phys));
	memset(fake_init_linux_attr, 0, sizeof(fake_init_linux_attr));
	fake_init_linux_digest = 0x6c696e75786d6170UL;
}

static char *fake_init_linux_find_command_line(char *name)
{
	fake_init_linux_find_calls++;
	mix(&fake_init_linux_digest, name != NULL);
	return fake_init_linux_safe_present ? name : NULL;
}

static int fake_init_linux_get_nr_chunks(void)
{
	fake_init_linux_get_nr_calls++;
	mix(&fake_init_linux_digest, 0x6e726368756e6bUL);
	return fake_init_linux_nr_chunks;
}

static int fake_init_linux_get_chunk(int id, unsigned long *start,
				     unsigned long *end, int *numa_id)
{
	fake_init_linux_get_chunk_calls++;
	mix(&fake_init_linux_digest, (unsigned int)id);
	if (id == fake_init_linux_bad_chunk_id)
		return -1;
	*start = fake_init_linux_chunk_start[id];
	*end = fake_init_linux_chunk_end[id];
	*numa_id = id + 10;
	return 0;
}

static int fake_init_linux_set_large(void *pt, unsigned long virt,
				     unsigned long phys, unsigned long attr)
{
	int ix = fake_init_linux_set_calls++;

	mix(&fake_init_linux_digest, pt == (void *)0x1111UL);
	mix(&fake_init_linux_digest, virt);
	mix(&fake_init_linux_digest, phys);
	mix(&fake_init_linux_digest, attr);
	if (ix < (int)(sizeof(fake_init_linux_virt) /
		       sizeof(fake_init_linux_virt[0]))) {
		fake_init_linux_virt[ix] = virt;
		fake_init_linux_phys[ix] = phys;
		fake_init_linux_attr[ix] = attr;
	}
	if (fake_init_linux_set_fail_after &&
	    fake_init_linux_set_calls == fake_init_linux_set_fail_after)
		return -5;
	return 0;
}

static void fake_init_linux_log(int event, unsigned long a, unsigned long b,
				unsigned long c, unsigned long d, int error)
{
	fake_init_linux_log_calls++;
	if (event >= 0 && event < (int)(sizeof(fake_init_linux_log_event_counts) /
					sizeof(fake_init_linux_log_event_counts[0])))
		fake_init_linux_log_event_counts[event]++;
	mix(&fake_init_linux_digest, (unsigned int)event);
	mix(&fake_init_linux_digest, a);
	mix(&fake_init_linux_digest, b);
	mix(&fake_init_linux_digest, c);
	mix(&fake_init_linux_digest, d);
	mix(&fake_init_linux_digest, (unsigned int)-error);
}

static void reset_fake_addr_log(void)
{
	fake_addr_log_calls = 0;
	fake_addr_log_kernel_calls = 0;
	fake_addr_log_straight_calls = 0;
	fake_addr_log_digest = 0x616464726c6f67UL;
}

static void fake_addr_log(int event, unsigned long value)
{
	fake_addr_log_calls++;
	if (event == X86_ADDR_LOG_KERNEL)
		fake_addr_log_kernel_calls++;
	if (event == X86_ADDR_LOG_STRAIGHT)
		fake_addr_log_straight_calls++;
	mix(&fake_addr_log_digest, (unsigned int)event);
	mix(&fake_addr_log_digest, value);
}

static void reset_fake_reserve_arch_pages(void)
{
	fake_reserve_cb_calls = 0;
	memset(fake_reserve_cb_pa, 0, sizeof(fake_reserve_cb_pa));
	memset(fake_reserve_cb_start, 0, sizeof(fake_reserve_cb_start));
	memset(fake_reserve_cb_end, 0, sizeof(fake_reserve_cb_end));
	memset(fake_reserve_cb_flag, 0, sizeof(fake_reserve_cb_flag));
	fake_reserve_arch_calls = 0;
	fake_reserve_arch_start = 0;
	fake_reserve_arch_end = 0;
	fake_reserve_arch_cb = NULL;
	fake_reserve_digest = 0x72657365727665UL;
}

static unsigned long fake_reserve_virt_to_phys(void *addr)
{
	unsigned long value = (unsigned long)(uintptr_t)addr;

	mix(&fake_reserve_digest, value);
	return value - 0xffff800000000000UL;
}

static void fake_reserve_cb(void *pa, unsigned long start,
			    unsigned long end, int flag)
{
	int ix = fake_reserve_cb_calls++;

	mix(&fake_reserve_digest, pa == (void *)0x1111UL);
	mix(&fake_reserve_digest, start);
	mix(&fake_reserve_digest, end);
	mix(&fake_reserve_digest, (unsigned int)flag);
	if (ix < (int)(sizeof(fake_reserve_cb_start) /
		       sizeof(fake_reserve_cb_start[0]))) {
		fake_reserve_cb_pa[ix] = pa;
		fake_reserve_cb_start[ix] = start;
		fake_reserve_cb_end[ix] = end;
		fake_reserve_cb_flag[ix] = flag;
	}
}

static void fake_reserve_arch(unsigned long start, unsigned long end,
			      void (*cb)(void *, unsigned long,
					 unsigned long, int))
{
	fake_reserve_arch_calls++;
	fake_reserve_arch_start = start;
	fake_reserve_arch_end = end;
	fake_reserve_arch_cb = cb;
	mix(&fake_reserve_digest, start);
	mix(&fake_reserve_digest, end);
	mix(&fake_reserve_digest, cb == fake_reserve_cb);
}

static int fake_clear_flush_calls;
static int fake_clear_remote_flush_calls;
static int fake_clear_free_calls;
static int fake_clear_unmap_calls;
	static int fake_clear_unmap_result;
	static int fake_clear_rss_calls;
	static int fake_clear_memobj_rss_calls;
	static int fake_clear_log_calls;
	static int fake_clear_old_action_calls;
	static int fake_clear_old_action_result;
	static unsigned long fake_clear_old_action_phys;
	static void *fake_clear_old_action_page;
	static int fake_clear_old_action_fileoff;
	static int fake_clear_child_walk_calls;
	static int fake_clear_child_walk_result;
	static void *fake_clear_child_walk_last_pt;
	static int fake_clear_range_log_calls;
	static int fake_clear_range_log_event;
	static unsigned long fake_clear_digest;

static void reset_fake_clear_effects(void)
{
	fake_clear_flush_calls = 0;
	fake_clear_remote_flush_calls = 0;
	fake_clear_free_calls = 0;
	fake_clear_unmap_calls = 0;
	fake_clear_unmap_result = 0;
		fake_clear_rss_calls = 0;
		fake_clear_memobj_rss_calls = 0;
		fake_clear_log_calls = 0;
		fake_clear_old_action_calls = 0;
		fake_clear_old_action_result = 0;
		fake_clear_old_action_phys = 0x5000UL;
		fake_clear_old_action_page = NULL;
		fake_clear_old_action_fileoff = 0;
		fake_clear_child_walk_calls = 0;
		fake_clear_child_walk_result = 0;
		fake_clear_child_walk_last_pt = NULL;
		fake_clear_range_log_calls = 0;
		fake_clear_range_log_event = 0;
		fake_clear_digest = 0x636c656172656666UL;
	}

	static int fake_clear_old_action(void *args, unsigned long old,
					 size_t pgsize, unsigned long *physp,
					 void **pagep, int *fileoffp)
	{
		fake_clear_old_action_calls++;
		mix(&fake_clear_digest, args == (void *)0xc1eaUL);
		mix(&fake_clear_digest, old);
		mix(&fake_clear_digest, pgsize);
		if (physp)
			*physp = fake_clear_old_action_phys;
		if (pagep)
			*pagep = fake_clear_old_action_page;
		if (fileoffp)
			*fileoffp = fake_clear_old_action_fileoff;
		return fake_clear_old_action_result;
	}

	static int fake_clear_child_walk(void *pt, unsigned long base,
					 unsigned long start, unsigned long end,
					 void *args)
	{
		fake_clear_child_walk_calls++;
		fake_clear_child_walk_last_pt = pt;
		mix(&fake_clear_digest, (unsigned long)pt);
		mix(&fake_clear_digest, base);
		mix(&fake_clear_digest, start);
		mix(&fake_clear_digest, end);
		mix(&fake_clear_digest, args == (void *)0xc1eaUL);
		return fake_clear_child_walk_result;
	}

	static void fake_clear_range_log(int event, void *args, unsigned long *ptep,
					 unsigned long base, unsigned long start,
					 unsigned long end, int error,
					 int level_shift, unsigned long phys)
	{
		fake_clear_range_log_calls++;
		fake_clear_range_log_event = event;
		mix(&fake_clear_digest, (unsigned int)event);
		mix(&fake_clear_digest, args == (void *)0xc1eaUL);
		mix(&fake_clear_digest, ptep != NULL);
		mix(&fake_clear_digest, base);
		mix(&fake_clear_digest, start);
		mix(&fake_clear_digest, end);
		mix(&fake_clear_digest, (unsigned int)-error);
		mix(&fake_clear_digest, (unsigned int)level_shift);
		mix(&fake_clear_digest, phys);
	}

	static void fake_clear_remote_flush(void *vm, unsigned long *addrs,
					    int nr_addr, int cpu_id)
{
	fake_clear_remote_flush_calls++;
	mix(&fake_clear_digest, vm == (void *)0xaaaaUL);
	mix(&fake_clear_digest, addrs[0]);
	mix(&fake_clear_digest, (unsigned int)nr_addr);
	mix(&fake_clear_digest, (unsigned int)cpu_id);
}

static void fake_clear_flush_memobj(void *memobj, unsigned long phys,
				    size_t pgsize)
{
	fake_clear_flush_calls++;
	mix(&fake_clear_digest, memobj == (void *)0xbbbbUL);
	mix(&fake_clear_digest, phys);
	mix(&fake_clear_digest, pgsize);
}

static void *fake_clear_phys_to_virt(unsigned long phys)
{
	mix(&fake_clear_digest, phys ^ 0x70787973UL);
	return (void *)(phys + 0x100000UL);
}

static void fake_clear_free_pages(void *addr, int nr_pages)
{
	fake_clear_free_calls++;
	mix(&fake_clear_digest, (unsigned long)addr);
	mix(&fake_clear_digest, (unsigned int)nr_pages);
}

static int fake_clear_page_unmap(void *page)
{
	fake_clear_unmap_calls++;
	mix(&fake_clear_digest, page == (void *)0xccccUL);
	return fake_clear_unmap_result;
}

static void fake_clear_rss_sub(size_t size, size_t pgsize)
{
	fake_clear_rss_calls++;
	mix(&fake_clear_digest, size);
	mix(&fake_clear_digest, pgsize);
}

static void fake_clear_memobj_rss_sub(void *memobj, size_t size,
				      size_t pgsize)
{
	fake_clear_memobj_rss_calls++;
	mix(&fake_clear_digest, memobj == (void *)0xbbbbUL);
	mix(&fake_clear_digest, size);
	mix(&fake_clear_digest, pgsize);
}

static void fake_clear_effect_log(int event, unsigned long base,
				  unsigned long phys, size_t pgsize)
{
	fake_clear_log_calls++;
	mix(&fake_clear_digest, (unsigned int)event);
	mix(&fake_clear_digest, base);
	mix(&fake_clear_digest, phys);
	mix(&fake_clear_digest, pgsize);
}

static int fake_set_clear_calls;
static int fake_set_rss_calls;
static int fake_set_rss_result;
static int fake_set_log_calls;
static int fake_set_child_walk_calls;
static int fake_set_child_walk_result;
static void *fake_set_child_walk_last_pt;
static unsigned long fake_set_digest;

static void reset_fake_set_range(void)
{
	fake_set_clear_calls = 0;
	fake_set_rss_calls = 0;
	fake_set_rss_result = 0;
	fake_set_log_calls = 0;
	fake_set_child_walk_calls = 0;
	fake_set_child_walk_result = 0;
	fake_set_child_walk_last_pt = NULL;
	fake_set_digest = 0x73657472616e6765UL;
}

static int fake_set_clear(void *pt, void *vm, unsigned long start,
			  unsigned long end, int free_physical, void *memobj)
{
	fake_set_clear_calls++;
	mix(&fake_set_digest, pt == (void *)0x1111UL);
	mix(&fake_set_digest, vm == (void *)0x2222UL);
	mix(&fake_set_digest, start);
	mix(&fake_set_digest, end);
	mix(&fake_set_digest, (unsigned int)free_physical);
	mix(&fake_set_digest, memobj == NULL);
	return 0;
}

static int fake_set_rss_add(void *range, unsigned long phys, size_t size,
			    size_t pgsize)
{
	fake_set_rss_calls++;
	mix(&fake_set_digest, range == (void *)0x3333UL);
	mix(&fake_set_digest, phys);
	mix(&fake_set_digest, size);
	mix(&fake_set_digest, pgsize);
	return fake_set_rss_result;
}

static void fake_set_log(int event, int level_shift, unsigned long base,
			 unsigned long start, unsigned long end, int error,
			 unsigned long pte, unsigned long phys, size_t size,
			 size_t pgsize, int rss_called)
{
	fake_set_log_calls++;
	mix(&fake_set_digest, (unsigned int)event);
	mix(&fake_set_digest, (unsigned int)level_shift);
	mix(&fake_set_digest, base);
	mix(&fake_set_digest, start);
	mix(&fake_set_digest, end);
	mix(&fake_set_digest, (unsigned int)-error);
	mix(&fake_set_digest, pte);
	mix(&fake_set_digest, phys);
	mix(&fake_set_digest, size);
	mix(&fake_set_digest, pgsize);
	mix(&fake_set_digest, (unsigned int)rss_called);
}

static void *fake_set_phys_to_virt(unsigned long phys)
{
	for (int i = 0;
	     i < (int)(sizeof(fake_created_tables) /
		     sizeof(fake_created_tables[0])); i++) {
		if (phys == fake_pt_virt_to_phys(&fake_created_tables[i]))
			return &fake_created_tables[i];
	}

	return NULL;
}

static int fake_pt_print_log_count;
static int fake_pt_print_last_event;
static int fake_pt_print_last_level;
static unsigned long fake_pt_print_digest;

static void reset_fake_pt_print(void)
{
	fake_pt_print_log_count = 0;
	fake_pt_print_last_event = 0;
	fake_pt_print_last_level = 0;
	fake_pt_print_digest = 0x7072696e74707465UL;
	memset(fake_created_tables, 0, sizeof(fake_created_tables));
}

static void fake_pt_print_log(int event, int level,
			      unsigned long value, int index)
{
	fake_pt_print_log_count++;
	fake_pt_print_last_event = event;
	fake_pt_print_last_level = level;
	mix(&fake_pt_print_digest, (unsigned int)event);
	mix(&fake_pt_print_digest, (unsigned int)level);
	mix(&fake_pt_print_digest, value);
	mix(&fake_pt_print_digest, (unsigned int)index);
}

static int fake_set_child_walk(void *pt, unsigned long base,
			       unsigned long start, unsigned long end,
			       void *args)
{
	fake_set_child_walk_calls++;
	fake_set_child_walk_last_pt = pt;
	mix(&fake_set_digest, args == (void *)0x4444UL);
	mix(&fake_set_digest, pt != NULL);
	mix(&fake_set_digest, base);
	mix(&fake_set_digest, start);
	mix(&fake_set_digest, end);
	return fake_set_child_walk_result;
}

struct fake_clear_top_args {
	int free_physical;
	void *memobj;
	void *vm;
	unsigned long *addr;
	int nr_addr;
	int max_nr_addr;
};

static int fake_clear_top_walk_calls;
static int fake_clear_top_walk_result;
static int fake_clear_top_log_calls;
static int fake_clear_top_log_event;
static int fake_clear_top_alloc_count;
static int fake_clear_top_alloc_fail;
static int fake_clear_top_free_count;
static int fake_clear_top_free_npages;
static unsigned long fake_clear_top_addr[2048];
static unsigned long fake_clear_top_digest;

static void reset_fake_clear_top(void)
{
	reset_fake_clear_effects();
	fake_clear_top_walk_calls = 0;
	fake_clear_top_walk_result = 0;
	fake_clear_top_log_calls = 0;
	fake_clear_top_log_event = 0;
	fake_clear_top_alloc_count = 0;
	fake_clear_top_alloc_fail = 0;
	fake_clear_top_free_count = 0;
	fake_clear_top_free_npages = 0;
	memset(fake_clear_top_addr, 0, sizeof(fake_clear_top_addr));
	fake_clear_top_digest = 0x636c72746f70746fUL;
}

static void *fake_clear_top_alloc_pages(int nr_pages, int ap_flag)
{
	if (fake_clear_top_alloc_fail || nr_pages != 4)
		return NULL;

	fake_clear_top_alloc_count++;
	mix(&fake_clear_top_digest, (unsigned int)nr_pages);
	mix(&fake_clear_top_digest, (unsigned int)ap_flag);
	return fake_clear_top_addr;
}

static void fake_clear_top_free_pages(void *addr, int nr_pages)
{
	fake_clear_top_free_count++;
	fake_clear_top_free_npages = nr_pages;
	mix(&fake_clear_top_digest, addr == fake_clear_top_addr);
	mix(&fake_clear_top_digest, (unsigned int)nr_pages);
}

static int fake_clear_top_walk(void *pt, unsigned long base,
			       unsigned long start, unsigned long end,
			       void *arg)
{
	struct fake_clear_top_args *args = arg;

	fake_clear_top_walk_calls++;
	mix(&fake_clear_top_digest, pt == (void *)0x1111UL);
	mix(&fake_clear_top_digest, base);
	mix(&fake_clear_top_digest, start);
	mix(&fake_clear_top_digest, end);
	mix(&fake_clear_top_digest, args->free_physical);
	mix(&fake_clear_top_digest, args->memobj == (void *)0xbbbbUL);
	mix(&fake_clear_top_digest, args->vm == (void *)0xaaaaUL);
	mix(&fake_clear_top_digest, args->addr != NULL);
	mix(&fake_clear_top_digest, (unsigned int)args->max_nr_addr);
	if (args->addr && args->max_nr_addr > 0) {
		args->addr[0] = 0x5151000UL;
		args->nr_addr = 1;
	}
	return fake_clear_top_walk_result;
}

static void fake_clear_top_log(int event, void *pt, unsigned long start,
			       unsigned long end, int free_physical)
{
	fake_clear_top_log_calls++;
	fake_clear_top_log_event = event;
	mix(&fake_clear_top_digest, (unsigned int)event);
	mix(&fake_clear_top_digest, pt == (void *)0x1111UL);
	mix(&fake_clear_top_digest, start);
	mix(&fake_clear_top_digest, end);
	mix(&fake_clear_top_digest, (unsigned int)free_physical);
}

struct fake_set_top_args {
	void *pt;
	unsigned long phys;
	int attr;
	unsigned long diff;
	void *vm;
	int pgshift;
	void *range;
};

static int fake_set_top_walk_calls;
static int fake_set_top_walk_result;

static void reset_fake_set_top(void)
{
	reset_fake_set_range();
	fake_set_top_walk_calls = 0;
	fake_set_top_walk_result = 0;
}

static int fake_set_top_walk(void *pt, unsigned long base,
			     unsigned long start, unsigned long end,
			     void *arg)
{
	struct fake_set_top_args *args = arg;

	fake_set_top_walk_calls++;
	mix(&fake_set_digest, pt == (void *)0x1111UL);
	mix(&fake_set_digest, args->pt == (void *)0x1111UL);
	mix(&fake_set_digest, args->vm == (void *)0x2222UL);
	mix(&fake_set_digest, args->range == (void *)0x3333UL);
	mix(&fake_set_digest, args->phys);
	mix(&fake_set_digest, (unsigned int)args->attr);
	mix(&fake_set_digest, args->diff);
	mix(&fake_set_digest, (unsigned int)args->pgshift);
	mix(&fake_set_digest, base);
	mix(&fake_set_digest, start);
	mix(&fake_set_digest, end);
	return fake_set_top_walk_result;
}

static int fake_visit_calls;
static int fake_visit_fail_error;
static int fake_visit_e2big_once;
static int fake_visit_walk_calls;
static int fake_visit_walk_result;
static int fake_visit_log_calls;
static int fake_visit_log_event;
static int fake_visit_log_shift;
static unsigned long fake_visit_digest;

static void reset_fake_visit(void)
{
	fake_visit_calls = 0;
	fake_visit_fail_error = 0;
	fake_visit_e2big_once = 0;
	fake_visit_walk_calls = 0;
	fake_visit_walk_result = 0;
	fake_visit_log_calls = 0;
	fake_visit_log_event = 0;
	fake_visit_log_shift = 0;
	fake_visit_digest = 0x7669736974707465UL;
	fake_pt_alloc_count = 0;
	fake_pt_alloc_fail = 0;
	fake_pt_last_ap_flag = 0;
	memset(fake_created_tables, 0, sizeof(fake_created_tables));
}

static int fake_visit_leaf(void *arg, void *pt, unsigned long *ptep,
			   void *base, int pgshift)
{
	fake_visit_calls++;
	mix(&fake_visit_digest, arg == (void *)0x1111UL);
	mix(&fake_visit_digest, pt == (void *)0x2222UL);
	mix(&fake_visit_digest, ptep != NULL ? *ptep : 0);
	mix(&fake_visit_digest, (unsigned long)base);
	mix(&fake_visit_digest, (unsigned int)pgshift);
	if (fake_visit_fail_error)
		return fake_visit_fail_error;
	if (fake_visit_e2big_once) {
		fake_visit_e2big_once = 0;
		return -7;
	}
	return 0;
}

static void *fake_visit_phys_to_virt(unsigned long phys)
{
	return fake_set_phys_to_virt(phys);
}

static int fake_visit_child_walk(void *pt, unsigned long base,
				 unsigned long start, unsigned long end,
				 void *args)
{
	fake_visit_walk_calls++;
	mix(&fake_visit_digest, pt != NULL);
	mix(&fake_visit_digest, args == (void *)0x3333UL);
	mix(&fake_visit_digest, base);
	mix(&fake_visit_digest, start);
	mix(&fake_visit_digest, end);
	return fake_visit_walk_result;
}

static void fake_visit_log(int event, int level_shift)
{
	fake_visit_log_calls++;
	fake_visit_log_event = event;
	fake_visit_log_shift = level_shift;
	mix(&fake_visit_digest, (unsigned int)event);
	mix(&fake_visit_digest, (unsigned int)level_shift);
}

struct harness_visit_pte_args {
	void *pt;
	int flags;
	int pgshift;
	int (*funcp)(void *, void *, unsigned long *, void *, int);
	void *arg;
};

int x86_use_1gb_page_bridge(void)
{
	return 1;
}

void x86_visit_pte_log_bridge(int event, int level_shift)
{
	fake_visit_log(event, level_shift);
}

int main(void)
{
	unsigned long digest = 0x5838364d454d484cUL;
	unsigned long attr_mask = PTATTR_FILEOFF | PTATTR_WRITABLE |
		PTATTR_USER | PTATTR_ACTIVE | PTATTR_NO_EXECUTE;
	unsigned long attrs[] = {
		0,
		PTATTR_ACTIVE | PTATTR_USER,
		PTATTR_ACTIVE | PTATTR_WRITABLE | PTATTR_USER,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_LARGEPAGE,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_LARGEPAGE |
			PTATTR_UNCACHABLE,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_UNCACHABLE,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_WRITE_COMBINED,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_WRITE_COMBINED |
			PTATTR_UNCACHABLE,
		PTATTR_ACTIVE | PTATTR_USER | PTATTR_NO_EXECUTE,
		PTATTR_FILEOFF | PTATTR_LARGEPAGE,
	};

	{
		struct x86_fake_ikc_scd_packet packet = {
			.header = { .channel = (void *)0x1111 },
			.msg = -1,
			.err = -2,
			.reply = (void *)0x2222,
			.ref = -3,
			.osnum = -4,
			.pid = -5,
			.arg = 0x3333,
			.req = {
				.rtid = 31,
				.ttid = 32,
				.valid = 33,
				.number = 34,
				.args = { 35, 36, 37, 38, 39, 40 },
			},
			.resp_pa = 0x4444,
		};

		require(x86_vdso_packet_prepare_result(&packet,
			SCD_MSG_GET_VDSO_INFO, 0xabcdef00UL) == 0);
		require(packet.header.channel == (void *)0x1111);
		require(packet.msg == SCD_MSG_GET_VDSO_INFO);
		require(packet.err == -2);
		require(packet.reply == (void *)0x2222);
		require(packet.ref == -3);
		require(packet.pid == -5);
		require(packet.arg == 0xabcdef00UL);
		require(packet.req.number == 34);
		require(packet.req.args[5] == 40);
		require(packet.resp_pa == 0x4444);
		require(x86_vdso_packet_prepare_result(NULL,
			SCD_MSG_GET_VDSO_INFO, 0) == -22);
		mix(&digest, (unsigned int)packet.msg);
		mix(&digest, packet.arg);
		mix(&digest, packet.req.args[5]);
	}

	{
		unsigned long virt = (1UL << PTL4_SHIFT) |
			(2UL << PTL3_SHIFT) | (3UL << PTL2_SHIFT) |
			(4UL << PTL1_SHIFT);
		unsigned long l4 = (virt >> PTL4_SHIFT) & 511UL;
		unsigned long l3 = (virt >> PTL3_SHIFT) & 511UL;
		unsigned long l2 = (virt >> PTL2_SHIFT) & 511UL;
		unsigned long l1 = (virt >> PTL1_SHIFT) & 511UL;

		reset_fake_pt_print();
		fake_created_tables[0].entry[l4] =
			fake_pt_virt_to_phys(&fake_created_tables[1]) | 0x1UL;
		fake_created_tables[1].entry[l3] =
			fake_pt_virt_to_phys(&fake_created_tables[2]) | 0x1UL;
		fake_created_tables[2].entry[l2] =
			fake_pt_virt_to_phys(&fake_created_tables[3]) | 0x1UL;
		fake_created_tables[3].entry[l1] = 0x55555000UL | 0x1UL;
		require(x86_pt_print_pte_body_result(NULL, &fake_created_tables[0],
				virt, fake_pt_virt_to_phys,
				fake_set_phys_to_virt, fake_pt_print_log) == 0);
			require(fake_pt_print_log_count == 8);
		require(fake_pt_print_last_event == X86_PT_PRINT_LOG_ENTRY);
		require(fake_pt_print_last_level == 1);
		mix(&digest, fake_pt_print_digest);

		if (ihk_mc_pt_print_pte) {
			reset_fake_pt_print();
			fake_created_tables[0].entry[l4] =
				fake_pt_virt_to_phys(&fake_created_tables[1]) |
				0x1UL;
			fake_created_tables[1].entry[l3] =
				fake_pt_virt_to_phys(&fake_created_tables[2]) |
				0x1UL;
			fake_created_tables[2].entry[l2] =
				fake_pt_virt_to_phys(&fake_created_tables[3]) |
				0x1UL;
			fake_created_tables[3].entry[l1] =
				0x55555000UL | 0x1UL;
			x86_rust_stub_pt_phys_to_virt_override =
				fake_set_phys_to_virt;
			x86_rust_stub_pt_print_log_count = 0;
			x86_rust_stub_pt_print_last_event = 0;
			x86_rust_stub_pt_print_last_level = 0;
			require(ihk_mc_pt_print_pte(&fake_created_tables[0],
					(void *)virt) == 0);
			require(x86_rust_stub_pt_print_log_count == 8);
			require(x86_rust_stub_pt_print_last_event ==
					X86_PT_PRINT_LOG_ENTRY);
			require(x86_rust_stub_pt_print_last_level == 1);
			x86_rust_stub_pt_phys_to_virt_override = NULL;
		}

		reset_fake_pt_print();
		fake_created_tables[0].entry[l4] =
			fake_pt_virt_to_phys(&fake_created_tables[1]) | 0x1UL;
		fake_created_tables[1].entry[l3] =
			fake_pt_virt_to_phys(&fake_created_tables[2]) | 0x1UL;
		fake_created_tables[2].entry[l2] = 0x66600000UL | 0x81UL;
		require(x86_pt_print_pte_body_result(&fake_created_tables[0], NULL,
				virt, fake_pt_virt_to_phys,
				fake_set_phys_to_virt, fake_pt_print_log) == 0);
		require(fake_pt_print_last_event == X86_PT_PRINT_LOG_LARGE);
		require(fake_pt_print_last_level == 2);
		mix(&digest, fake_pt_print_digest);

		reset_fake_pt_print();
		fake_created_tables[0].entry[l4] =
			fake_pt_virt_to_phys(&fake_created_tables[1]) | 0x1UL;
		fake_created_tables[1].entry[l3] =
			fake_pt_virt_to_phys(&fake_created_tables[2]) | 0x81UL;
		require(x86_pt_print_pte_body_result(&fake_created_tables[0], NULL,
				virt, fake_pt_virt_to_phys,
				fake_set_phys_to_virt, fake_pt_print_log) == 0);
		require(fake_pt_print_last_event == X86_PT_PRINT_LOG_LARGE);
		require(fake_pt_print_last_level == 3);
		mix(&digest, fake_pt_print_digest);

		reset_fake_pt_print();
		fake_created_tables[0].entry[l4] =
			fake_pt_virt_to_phys(&fake_created_tables[1]) | 0x1UL;
		fake_created_tables[1].entry[l3] =
			fake_pt_virt_to_phys(&fake_created_tables[2]) | 0x1UL;
		fake_created_tables[2].entry[l2] =
			fake_pt_virt_to_phys(&fake_created_tables[3]) | 0x1UL;
		require(x86_pt_print_pte_body_result(&fake_created_tables[0], NULL,
				virt, fake_pt_virt_to_phys,
				fake_set_phys_to_virt, fake_pt_print_log) == -14);
			require(fake_pt_print_log_count == 9);
		require(fake_pt_print_last_event == X86_PT_PRINT_LOG_ENTRY);
		require(fake_pt_print_last_level == 1);
		mix(&digest, fake_pt_print_digest);
		require(x86_pt_print_pte_body_result(NULL, NULL, virt,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_pt_print_log) == -14);
		require(x86_pt_print_pte_body_result(&fake_created_tables[0],
				NULL, virt, NULL, fake_set_phys_to_virt,
				fake_pt_print_log) == -22);
	}

	for (unsigned int i = 0; i < sizeof(attrs) / sizeof(attrs[0]); i++) {
		mix(&digest, x86_attr_to_l3attr_result(attrs[i], attr_mask));
		mix(&digest, x86_attr_to_l2attr_result(attrs[i], attr_mask));
		mix(&digest, x86_attr_to_l1attr_result(attrs[i], attr_mask));
		mix(&digest, x86_set_pte_value_result(0x200000 + i * 0x1000,
						      attrs[i], attr_mask));
	}
	if (set_pte) {
		unsigned long slot = 0;
		unsigned long expected = x86_set_pte_value_result(
				0x12345000UL, PTATTR_WRITABLE | PTATTR_USER,
				attr_mask);

		set_pte(&slot, 0x12345000UL, PTATTR_WRITABLE | PTATTR_USER);
		require(slot == expected);
	}
	if (set_pt_large_page && ihk_mc_pt_set_large_page &&
			ihk_mc_pt_set_page) {
		x86_rust_stub_pt_set_page_calls = 0;
		x86_rust_stub_pt_set_page_rc = 0;
		require(set_pt_large_page((void *)0x1111UL, (void *)0x2222UL,
				0x33330000UL, PTATTR_USER) == 0);
		require(x86_rust_stub_pt_set_page_calls == 1);
		require(x86_rust_stub_pt_set_page_pt == (void *)0x1111UL);
		require(x86_rust_stub_pt_set_page_virt == 0x2222UL);
		require(x86_rust_stub_pt_set_page_phys == 0x33330000UL);
		require(x86_rust_stub_pt_set_page_attr ==
				(PTATTR_USER | PTATTR_LARGEPAGE |
				PTATTR_ACTIVE));

		x86_rust_stub_pt_set_page_calls = 0;
		require(ihk_mc_pt_set_large_page((void *)0x4444UL,
				(void *)0x5555UL, 0x66660000UL,
				PTATTR_WRITABLE) == 0);
		require(x86_rust_stub_pt_set_page_calls == 1);
		require(x86_rust_stub_pt_set_page_pt == (void *)0x4444UL);
		require(x86_rust_stub_pt_set_page_virt == 0x5555UL);
		require(x86_rust_stub_pt_set_page_phys == 0x66660000UL);
		require(x86_rust_stub_pt_set_page_attr ==
				(PTATTR_WRITABLE | PTATTR_LARGEPAGE |
				PTATTR_ACTIVE));

		x86_rust_stub_pt_set_page_calls = 0;
		x86_rust_stub_pt_set_page_rc = -5;
		require(ihk_mc_pt_set_page((void *)0x7777UL,
				(void *)0x8888UL, 0x99990000UL,
				PTATTR_USER) == -5);
		require(x86_rust_stub_pt_set_page_calls == 1);
		require(x86_rust_stub_pt_set_page_pt == (void *)0x7777UL);
		require(x86_rust_stub_pt_set_page_virt == 0x8888UL);
		require(x86_rust_stub_pt_set_page_phys == 0x99990000UL);
		require(x86_rust_stub_pt_set_page_attr ==
				(PTATTR_USER | PTATTR_ACTIVE));
		x86_rust_stub_pt_set_page_rc = 0;
	}
	size_t sizes[] = {
		0, 1, 4096, 4097, 2UL * 1024 * 1024,
		(2UL * 1024 * 1024) + 1, 1024UL * 1024 * 1024,
		(1024UL * 1024 * 1024) + 1,
	};
	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++) {
		int l4idx = -1, l3idx = -1, l2idx = -1, l1idx = -1;

		x86_pt_indices_result(sizes[i], &l4idx, &l3idx, &l2idx,
			&l1idx);
		mix(&digest, (unsigned int)l4idx);
		mix(&digest, (unsigned int)l3idx);
		mix(&digest, (unsigned int)l2idx);
		mix(&digest, (unsigned int)l1idx);
		for (int use_1gb = 0; use_1gb <= 1; use_1gb++) {
			size_t newsize = 0xfeedfaceUL;
			int p2align = 12345;
			int error = x86_smaller_page_size_result(sizes[i],
					use_1gb, &newsize, &p2align);
			mix(&digest, sizes[i]);
			mix(&digest, use_1gb);
			mix(&digest, (unsigned long)(unsigned int)-error);
			mix(&digest, newsize);
			mix(&digest, (unsigned long)(unsigned int)p2align);
		}
		mix(&digest, x86_early_alloc_align_end_result(sizes[i]));
		mix(&digest, (unsigned int)x86_early_alloc_exhausted_result(
			sizes[i], 2UL * 1024 * 1024));
		mix(&digest, x86_early_alloc_next_result(sizes[i],
			(int)i - 2));
	}
	for (unsigned int s = 0; s < sizeof(sizes) / sizeof(sizes[0]); s++) {
		for (unsigned int e = 0; e < sizeof(sizes) / sizeof(sizes[0]); e++) {
			int six = -123;
			int eix = -456;

			x86_walk_bounds_result(sizes[s], sizes[e],
				4096, 2UL * 1024 * 1024, 12, &six, &eix);
			mix(&digest, (unsigned int)six);
			mix(&digest, (unsigned int)eix);
			x86_walk_bounds_result(sizes[s], sizes[e],
				0, 0, 39, &six, &eix);
			mix(&digest, (unsigned int)six);
			mix(&digest, (unsigned int)eix);
		}
	}
	{
		static const int walk_cases[][3] = {
			{ -2, 0, 0 },
			{ -2, -2, 0 },
			{ 0, -2, 0 },
			{ -2, -12, 1 },
			{ 0, -5, 1 },
		};

		for (unsigned int i = 0;
				i < sizeof(walk_cases) / sizeof(walk_cases[0]);
				i++) {
			int next_ret = 0x7777;
			int stop = x86_walk_step_result(walk_cases[i][0],
				walk_cases[i][1], &next_ret);

			require(stop == walk_cases[i][2]);
			if (walk_cases[i][1] == 0)
				require(next_ret == 0);
			else if (walk_cases[i][1] == -2)
				require(next_ret == walk_cases[i][0]);
			else
				require(next_ret == walk_cases[i][1]);
			mix(&digest, (unsigned int)stop);
			mix(&digest, (unsigned int)next_ret);
		}
		require(x86_walk_step_result(0, -5, NULL) == 1);
		mix(&digest, 0x786477616c6bUL);
	}
	{
		unsigned long pt[512];
		unsigned long base = 0x400000UL;
		struct walk_trace trace;
		int ret;

		for (int i = 0; i < 512; i++)
			pt[i] = 0x1000000UL + (unsigned long)i * 0x1000UL |
				PF_PRESENT;

		trace.digest = 0x77616c6b707465UL;
		trace.calls = 0;
		trace.enoent_mode = 0;
		trace.fail_after = 0;
		trace.fail_error = 0;
		ret = x86_walk_pte_range_result((unsigned long)pt, base,
			base + 0x1000, base + 0x8000, 2UL * 1024 * 1024,
			12, fake_walk_pte_cb, &trace, NULL, PT_PHYSMASK);
		require(ret == 0);
		require(trace.calls == 7);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, (unsigned int)trace.calls);
		mix(&digest, trace.digest);

		trace.digest = 0x656e6f656e7472UL;
		trace.calls = 0;
		trace.enoent_mode = 1;
		ret = x86_walk_pte_range_result((unsigned long)pt, base,
			base, base + 0x3000, 2UL * 1024 * 1024, 12,
			fake_walk_pte_cb, &trace, NULL, PT_PHYSMASK);
		require(ret == -2);
		require(trace.calls == 3);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, (unsigned int)trace.calls);
		mix(&digest, trace.digest);

		trace.digest = 0x73746f70657272UL;
		trace.calls = 0;
		trace.enoent_mode = 0;
		trace.fail_after = 2;
		trace.fail_error = -5;
		ret = x86_walk_pte_range_result((unsigned long)pt, base,
			base, base + 0x5000, 2UL * 1024 * 1024, 12,
			fake_walk_pte_cb, &trace, NULL, PT_PHYSMASK);
		require(ret == -5);
		require(trace.calls == 2);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, (unsigned int)trace.calls);
		mix(&digest, trace.digest);

		pt[2] = 0xdead000UL | PF_PRESENT;
		trace.digest = 0x7361666577616c6bUL;
		trace.calls = 0;
		trace.enoent_mode = 0;
		trace.fail_after = 0;
		trace.fail_error = 0;
		ret = x86_walk_pte_range_result((unsigned long)pt, base,
			base, base + 0x5000, 2UL * 1024 * 1024, 12,
			fake_walk_pte_cb, &trace, fake_walk_phys_check,
			PT_PHYSMASK);
		require(ret == 0);
		require(trace.calls == 4);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, (unsigned int)trace.calls);
		mix(&digest, trace.digest);

		require(x86_walk_pte_range_result(0, base, base,
			base + 0x1000, 2UL * 1024 * 1024, 12,
			fake_walk_pte_cb, &trace, NULL, PT_PHYSMASK) == -2);
		require(x86_walk_pte_range_result((unsigned long)pt, base,
			base, base + 0x1000, 2UL * 1024 * 1024, 12,
			NULL, &trace, NULL, PT_PHYSMASK) == -2);
		mix(&digest, 0x77616c6b646f6e65UL);

		if (walk_pte_l1 && walk_pte_l2 && walk_pte_l3 &&
				walk_pte_l4) {
			trace.digest = 0x77616c6b6c6576UL;
			trace.calls = 0;
			trace.enoent_mode = 0;
			trace.fail_after = 0;
			trace.fail_error = 0;
			ret = walk_pte_l1(pt, base, base + 0x1000,
				base + 0x5000, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 4);

			trace.calls = 0;
			ret = walk_pte_l2(pt, 0, PTL2_SIZE,
				PTL2_SIZE * 4, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 3);

			trace.calls = 0;
			ret = walk_pte_l3(pt, 0, PTL3_SIZE,
				PTL3_SIZE * 3, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 2);

			trace.calls = 0;
			ret = walk_pte_l4(pt, 0, 0,
				(1UL << PTL4_SHIFT) * 2,
				fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 2);
			mix(&digest, trace.digest);
			mix(&digest, 0x776c6b6c766cUL);
		}

		if (walk_pte_l1_safe && walk_pte_l2_safe &&
				walk_pte_l3_safe && walk_pte_l4_safe) {
			trace.digest = 0x73616665776c6bUL;
			trace.calls = 0;
			trace.enoent_mode = 0;
			trace.fail_after = 0;
			trace.fail_error = 0;
			ret = walk_pte_l1_safe(pt, base, base + 0x1000,
				base + 0x4000, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 3);

			trace.calls = 0;
			ret = walk_pte_l2_safe(pt, 0, PTL2_SIZE,
				PTL2_SIZE * 3, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 2);

			trace.calls = 0;
			ret = walk_pte_l3_safe(pt, 0, PTL3_SIZE,
				PTL3_SIZE * 2, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 1);

			trace.calls = 0;
			ret = walk_pte_l4_safe(pt, 0, 0,
				1UL << PTL4_SHIFT, fake_walk_pte_cb, &trace);
			require(ret == 0);
			require(trace.calls == 1);

			require(walk_pte_l1_safe(NULL, base, base,
				base + 0x1000, fake_walk_pte_cb, &trace) == 0);
			require(walk_pte_l4_safe(NULL, 0, 0,
				1UL << PTL4_SHIFT, fake_walk_pte_cb,
				&trace) == 0);
			mix(&digest, trace.digest);
			mix(&digest, 0x73616665776c766cUL);
		}
	}
	{
		unsigned long entries[] = {
			0,
			PF_PRESENT,
			0x12345000UL | PF_PRESENT,
			0x200000UL | PF_PRESENT | PF_SIZE,
			0x40000000UL | PF_PRESENT | PF_SIZE,
			0x000ffffffffff000UL | PF_PRESENT,
		};
		int level_shifts[] = { 12, 21, 30, 39 };
		unsigned long virt = 0x123456789abcUL;

		for (unsigned int e = 0; e < sizeof(entries) / sizeof(entries[0]); e++) {
			for (unsigned int s = 0; s < sizeof(level_shifts) / sizeof(level_shifts[0]); s++) {
				unsigned long phys = 0xfeedfaceUL;
				unsigned long size = 0xcafecafeUL;
				unsigned long size_flag = level_shifts[s] == 12 ||
					level_shifts[s] == 39 ? 0 : PF_SIZE;
				int action = x86_virt_to_phys_level_result(
					entries[e], virt, level_shifts[s],
					size_flag, &phys, &size);

				if (entries[e] == 0) {
					require(action == 0);
					require(phys == 0xfeedfaceUL);
					require(size == 0xcafecafeUL);
				}
				if (entries[e] == PF_PRESENT && level_shifts[s] == 12) {
					require(action == 2);
					require(size == 4096);
				}
				if (entries[e] == PF_PRESENT && level_shifts[s] == 21) {
					require(action == 1);
				}
				if ((entries[e] & PF_SIZE) && level_shifts[s] != 12 &&
				    level_shifts[s] != 39) {
					require(action == 2);
					require(size == (1UL << level_shifts[s]));
					require(phys == ((entries[e] & PT_PHYSMASK) |
						(virt & ((1UL << level_shifts[s]) - 1))));
				}

				mix(&digest, (unsigned int)action);
				mix(&digest, phys);
				mix(&digest, size);
			}
		}
		require(x86_virt_to_phys_level_result(PF_PRESENT, virt, 12,
			0, NULL, NULL) == 2);
		mix(&digest, 0x76746f70646f6e65UL);
	}
	{
		unsigned long virt = 0x123456789abcUL;
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);
		unsigned long phys;
		unsigned long size;
		unsigned long entry;

		reset_fake_pt_destroy_table();
		entry = 0x40000000UL | PF_PRESENT | PF_SIZE;
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] = entry;
		phys = 0xfeedfaceUL;
		size = 0xcafecafeUL;
		require(x86_pt_virt_to_phys_size_result(&fake_created_tables[0],
			NULL, virt, &phys, &size,
			fake_pt_destroy_phys_to_virt) == 0);
		require(fake_pt_destroy_table_phys_calls == 1);
		require(size == (1UL << PTL3_SHIFT));
		require(phys == ((entry & PT_PHYSMASK) |
			(virt & ((1UL << PTL3_SHIFT) - 1))));
		mix(&digest, phys);
		mix(&digest, size);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		entry = 0x200000UL | PF_PRESENT | PF_SIZE;
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] = entry;
		phys = 0xfeedfaceUL;
		size = 0xcafecafeUL;
		require(x86_pt_virt_to_phys_size_result(&fake_created_tables[0],
			NULL, virt, &phys, &size,
			fake_pt_destroy_phys_to_virt) == 0);
		require(fake_pt_destroy_table_phys_calls == 2);
		require(size == (1UL << PTL2_SHIFT));
		require(phys == ((entry & PT_PHYSMASK) |
			(virt & ((1UL << PTL2_SHIFT) - 1))));
		mix(&digest, phys);
		mix(&digest, size);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		entry = 0xabcde000UL | PF_PRESENT;
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] = entry;
		phys = 0xfeedfaceUL;
		size = 0xcafecafeUL;
		require(x86_pt_virt_to_phys_size_result(&fake_created_tables[0],
			NULL, virt, &phys, &size,
			fake_pt_destroy_phys_to_virt) == 0);
		require(fake_pt_destroy_table_phys_calls == 3);
		require(size == (1UL << PTL1_SHIFT));
		require(phys == ((entry & PT_PHYSMASK) |
			(virt & ((1UL << PTL1_SHIFT) - 1))));
		mix(&digest, phys);
		mix(&digest, size);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		phys = 0xfeedfaceUL;
		size = 0xcafecafeUL;
		require(x86_pt_virt_to_phys_size_result(&fake_created_tables[0],
			NULL, virt, &phys, &size,
			fake_pt_destroy_phys_to_virt) == -14);
		require(fake_pt_destroy_table_phys_calls == 0);
		require(phys == 0xfeedfaceUL);
		require(size == 0xcafecafeUL);
		mix(&digest, phys);
		mix(&digest, size);

		reset_fake_pt_destroy_table();
		entry = 0x40000000UL | PF_PRESENT | PF_SIZE;
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] = entry;
		phys = 0;
		size = 0;
		require(x86_pt_virt_to_phys_size_result(NULL,
			&fake_created_tables[0], virt, &phys, &size,
			fake_pt_destroy_phys_to_virt) == 0);
		require(size == (1UL << PTL3_SHIFT));
		mix(&digest, phys);
		mix(&digest, size);

		require(x86_pt_virt_to_phys_size_result(NULL, NULL, virt,
			&phys, &size, fake_pt_destroy_phys_to_virt) == -14);
		require(x86_pt_virt_to_phys_size_result(&fake_created_tables[0],
			NULL, virt, &phys, &size, NULL) == -14);
		mix(&digest, 0x76746f7073697a65UL);
	}
	{
		unsigned long virt = 0x123456789abcUL;
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);
		unsigned long entry = 0xabcde000UL | PF_PRESENT;
		uint64_t pagemap;
		uint64_t expected;

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] = entry;
		pagemap = x86_pt_virt_to_pagemap_result(
			&fake_created_tables[0], NULL, virt,
			fake_pt_destroy_phys_to_virt);
		expected = PM_PFRAME(((entry & PT_PHYSMASK) |
			(virt & ((1UL << PTL1_SHIFT) - 1))) >> PAGE_SHIFT);
		expected |= PM_PSHIFT(PAGE_SHIFT) | PM_PRESENT;
		require(pagemap == expected);
		require(fake_pt_destroy_table_phys_calls == 3);
		mix(&digest, (unsigned long)pagemap);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		pagemap = x86_pt_virt_to_pagemap_result(
			&fake_created_tables[0], NULL, virt,
			fake_pt_destroy_phys_to_virt);
		require(pagemap == PM_PSHIFT(PAGE_SHIFT));
			require(x86_pt_virt_to_pagemap_result(
				&fake_created_tables[0], NULL, virt, NULL) ==
				PM_PSHIFT(PAGE_SHIFT));
			mix(&digest, (unsigned long)pagemap);
			mix(&digest, 0x706167656d6170UL);

			if (ihk_mc_pt_virt_to_phys_size &&
			    ihk_mc_pt_virt_to_phys &&
			    ihk_mc_pt_virt_to_pagemap) {
				unsigned long wrapper_phys = 0;
				unsigned long wrapper_size = 0;
				unsigned long wrapper_phys_short = 0;
				uint64_t wrapper_pagemap;
				int wrapper_ret;
				int weak_stub_result;

				reset_fake_pt_destroy_table();
				fake_created_tables[0].entry[l4idx] =
					fake_pt_destroy_phys(&fake_created_tables[1]) |
					PF_PRESENT;
				fake_created_tables[1].entry[l3idx] =
					fake_pt_destroy_phys(&fake_created_tables[2]) |
					PF_PRESENT;
				fake_created_tables[2].entry[l2idx] =
					fake_pt_destroy_phys(&fake_created_tables[3]) |
					PF_PRESENT;
				fake_created_tables[3].entry[l1idx] = entry;
				x86_rust_stub_init_pt_override =
					&fake_created_tables[0];
				x86_rust_stub_phys_to_virt_override =
					fake_pt_destroy_phys_to_virt;

				wrapper_ret = ihk_mc_pt_virt_to_phys_size(NULL,
					(void *)virt, &wrapper_phys,
					&wrapper_size);
				weak_stub_result = wrapper_ret == 0 &&
					wrapper_phys == virt &&
					wrapper_size == (1UL << PTL1_SHIFT);
				if (!weak_stub_result) {
					require(wrapper_ret == 0);
					require(wrapper_size == (1UL << PTL1_SHIFT));
					require(wrapper_phys == ((entry & PT_PHYSMASK) |
						(virt & ((1UL << PTL1_SHIFT) - 1))));
					require(ihk_mc_pt_virt_to_phys(NULL,
						(void *)virt, &wrapper_phys_short) == 0);
					require(wrapper_phys_short == wrapper_phys);
					wrapper_pagemap = ihk_mc_pt_virt_to_pagemap(NULL,
						virt);
					require(wrapper_pagemap == expected);
				}
				x86_rust_stub_init_pt_override = NULL;
				x86_rust_stub_phys_to_virt_override = NULL;
				reset_fake_pt_destroy_table();
			}
		}
		{
		unsigned long virt = 0x123456789abcUL;
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);
		unsigned long leaf = 0xabcde000UL | PF_PRESENT;
		unsigned long large = 0x40000000UL | PF_PRESENT | PF_SIZE;
		int ret;

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] = leaf;
		ret = x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 0, fake_pt_destroy_phys_to_virt);
		require(ret == 0);
		require(fake_pt_destroy_table_phys_calls == 3);
		require(fake_created_tables[3].entry[l1idx] == 0);
		require(fake_created_tables[2].entry[l2idx] != 0);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, fake_pt_destroy_table_phys_calls);
		mix(&digest, fake_created_tables[3].entry[l1idx]);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] = large;
		ret = x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 1, fake_pt_destroy_phys_to_virt);
		require(ret == 0);
		require(fake_pt_destroy_table_phys_calls == 2);
		require(fake_created_tables[2].entry[l2idx] == 0);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, fake_pt_destroy_table_phys_calls);
		mix(&digest, fake_created_tables[2].entry[l2idx]);

		reset_fake_pt_destroy_table();
		ret = x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 0, fake_pt_destroy_phys_to_virt);
		require(ret == -22);
		require(fake_pt_destroy_table_phys_calls == 0);
		mix(&digest, (unsigned int)-ret);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		ret = x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 0, fake_pt_destroy_phys_to_virt);
		require(ret == -22);
		require(fake_pt_destroy_table_phys_calls == 1);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		ret = x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 0, fake_pt_destroy_phys_to_virt);
		require(ret == -22);
		require(fake_pt_destroy_table_phys_calls == 2);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] = large;
		ret = x86_pt_clear_page_result(NULL, &fake_created_tables[0],
			virt, 1, fake_pt_destroy_phys_to_virt);
		require(ret == 0);
		require(fake_created_tables[2].entry[l2idx] == 0);
		require(x86_pt_clear_page_result(NULL, NULL, virt, 0,
			fake_pt_destroy_phys_to_virt) == -22);
		require(x86_pt_clear_page_result(&fake_created_tables[0], NULL,
			virt, 0, NULL) == -22);
		mix(&digest, 0x636c727074706167UL);
	}
	if (ihk_mc_pt_clear_page && ihk_mc_pt_clear_large_page) {
		unsigned long virt = 0x123456789abcUL;
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] =
			0xfeedf000UL | PF_PRESENT;
		x86_rust_stub_pt_phys_to_virt_override =
			fake_pt_destroy_phys_to_virt;
		require(ihk_mc_pt_clear_page(&fake_created_tables[0],
			(void *)virt) == 0);
		require(fake_pt_destroy_table_phys_calls == 3);
		require(fake_created_tables[3].entry[l1idx] == 0);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			0x40000000UL | PF_PRESENT | PF_SIZE;
		require(ihk_mc_pt_clear_large_page(&fake_created_tables[0],
			(void *)virt) == 0);
		require(fake_pt_destroy_table_phys_calls == 2);
		require(fake_created_tables[2].entry[l2idx] == 0);
		x86_rust_stub_pt_phys_to_virt_override = NULL;
		mix(&digest, 0x707562636c727074UL);
	}
	{
		unsigned long virt = 0x123456789abcUL;
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);
		unsigned long *ptep;
		unsigned long base;
		size_t size;
		int p2align;

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			0x40000000UL | PF_PRESENT | PF_SIZE;
		base = 0;
		size = 0;
		p2align = -1;
		ptep = x86_pt_lookup_pte_result(&fake_created_tables[0],
			virt, 0, 1, &base, &size, &p2align,
			fake_pt_destroy_phys_to_virt);
		require(ptep == &fake_created_tables[1].entry[l3idx]);
		require(size == (1UL << PTL3_SHIFT));
		require(p2align == PTL3_SHIFT - PTL1_SHIFT);
		require(fake_pt_destroy_table_phys_calls == 1);
		mix(&digest, ptep == &fake_created_tables[1].entry[l3idx]);
		mix(&digest, base);
		mix(&digest, size);
		mix(&digest, (unsigned int)p2align);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			0x200000UL | PF_PRESENT | PF_SIZE;
		ptep = x86_pt_lookup_pte_result(&fake_created_tables[0],
			virt, 0, 0, &base, &size, &p2align,
			fake_pt_destroy_phys_to_virt);
		require(ptep == &fake_created_tables[2].entry[l2idx]);
		require(size == (1UL << PTL2_SHIFT));
		require(p2align == PTL2_SHIFT - PTL1_SHIFT);
		require(fake_pt_destroy_table_phys_calls == 2);
		mix(&digest, ptep == &fake_created_tables[2].entry[l2idx]);
		mix(&digest, base);
		mix(&digest, size);

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] =
			0xabcde000UL | PF_PRESENT;
		ptep = x86_pt_lookup_pte_result(&fake_created_tables[0],
			virt, PTL1_SHIFT, 0, &base, &size, &p2align,
			fake_pt_destroy_phys_to_virt);
		require(ptep == &fake_created_tables[3].entry[l1idx]);
		require(size == (1UL << PTL1_SHIFT));
		require(p2align == 0);
		require(fake_pt_destroy_table_phys_calls == 3);
		mix(&digest, ptep == &fake_created_tables[3].entry[l1idx]);
		mix(&digest, base);
		mix(&digest, size);

		reset_fake_pt_destroy_table();
		ptep = x86_pt_lookup_pte_result(&fake_created_tables[0],
			virt, PTL4_SHIFT, 1, &base, &size, &p2align,
			fake_pt_destroy_phys_to_virt);
		require(ptep == NULL);
		require(size == (1UL << PTL3_SHIFT));
		require(p2align == PTL3_SHIFT - PTL1_SHIFT);
		require(fake_pt_destroy_table_phys_calls == 0);
		require(x86_pt_lookup_pte_result(&fake_created_tables[0],
			virt, 0, 1, &base, &size, &p2align, NULL) == NULL);
		mix(&digest, base);
		mix(&digest, size);
		mix(&digest, 0x6c6f6f6b707465UL);
	}
	{
		unsigned long virt = 0x123456789abcUL;
		unsigned long start = virt & ~(4096UL - 1);
		unsigned long l2base = virt & ~((1UL << PTL2_SHIFT) - 1);
		int l4idx = (virt >> PTL4_SHIFT) & (PT_ENTRIES - 1);
		int l3idx = (virt >> PTL3_SHIFT) & (PT_ENTRIES - 1);
		int l2idx = (virt >> PTL2_SHIFT) & (PT_ENTRIES - 1);
		int l1idx = (virt >> PTL1_SHIFT) & (PT_ENTRIES - 1);
		unsigned long original = 0xabcde000UL | PF_PRESENT |
			PTATTR_WRITABLE;
		int ret;

		reset_fake_pt_destroy_table();
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] =
			fake_pt_destroy_phys(&fake_created_tables[3]) |
			PF_PRESENT;
		fake_created_tables[3].entry[l1idx] = original;
		ret = x86_pt_change_attr_range_result(&fake_created_tables[0],
			start, start + 4096, PTATTR_WRITABLE, PTATTR_USER,
			fake_pt_destroy_phys_to_virt);
		require(ret == 0);
		require(fake_created_tables[3].entry[l1idx] ==
			((original & ~PTATTR_WRITABLE) | PTATTR_USER));
		require(fake_pt_destroy_table_phys_calls == 3);
		mix(&digest, (unsigned int)-ret);
		mix(&digest, fake_created_tables[3].entry[l1idx]);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		reset_fake_pt_destroy_table();
		original = 0x200000UL | PF_PRESENT | PF_SIZE |
			PTATTR_WRITABLE;
		fake_created_tables[0].entry[l4idx] =
			fake_pt_destroy_phys(&fake_created_tables[1]) |
			PF_PRESENT;
		fake_created_tables[1].entry[l3idx] =
			fake_pt_destroy_phys(&fake_created_tables[2]) |
			PF_PRESENT;
		fake_created_tables[2].entry[l2idx] = original;
		ret = x86_pt_change_attr_range_result(&fake_created_tables[0],
			l2base, l2base + (1UL << PTL2_SHIFT),
			PTATTR_WRITABLE, PTATTR_USER,
			fake_pt_destroy_phys_to_virt);
		require(ret == 0);
		require(fake_created_tables[2].entry[l2idx] ==
			((original & ~PTATTR_WRITABLE) | PTATTR_USER));
		require(fake_pt_destroy_table_phys_calls == 2);
		mix(&digest, fake_created_tables[2].entry[l2idx]);
		mix(&digest, fake_pt_destroy_table_phys_calls);

		ret = x86_pt_change_attr_range_result(&fake_created_tables[0],
			l2base + 4096, l2base + 8192,
			PTATTR_USER, PTATTR_WRITABLE,
			fake_pt_destroy_phys_to_virt);
		require(ret == -22);
		mix(&digest, (unsigned int)-ret);

		reset_fake_pt_destroy_table();
		ret = x86_pt_change_attr_range_result(&fake_created_tables[0],
			start, start + 4096, PTATTR_WRITABLE,
			PTATTR_USER, fake_pt_destroy_phys_to_virt);
		require(ret == -2);
		require(x86_pt_change_attr_range_result(&fake_created_tables[0],
			start, start + 4096, PTATTR_WRITABLE,
			PTATTR_USER, NULL) == -22);
		mix(&digest, 0x6368617474726e67UL);
	}
	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++) {
		for (int large = 0; large <= 1; large++) {
			int clear_l2 = -1;

			mix(&digest, x86_clear_pt_page_aligned_addr_result(
				sizes[i], large));
			mix(&digest, (unsigned int)-x86_clear_pt_page_target_result(
				0, large, &clear_l2));
			mix(&digest, (unsigned int)clear_l2);
			clear_l2 = -1;
			mix(&digest, (unsigned int)-x86_clear_pt_page_target_result(
				1, large, &clear_l2));
			mix(&digest, (unsigned int)clear_l2);
		}
	}
	{
		unsigned long entries[] = {
			0, 1, 0x80, 0x81, 0x1000, 0x1080,
			PTATTR_FILEOFF, PTATTR_FILEOFF | 0x80,
		};
		unsigned long ranges[][3] = {
			{ 0, 0x200000, 0 },
			{ 0x1000, 0x200000, 0 },
			{ 0, 0x1000, 0 },
			{ 0, 0, 0 },
			{ 0x200000, 0x400000, 0x200000 },
			{ ~0UL - 0x1000, ~0UL, ~0UL - 0x1000 },
		};
		unsigned long diffs[] = {
			0, 0x1000, 0x200000, 0x400000, ~0UL,
		};
		size_t move_pgsizes[] = {
			4096, 2UL * 1024 * 1024,
			1024UL * 1024 * 1024, 12345,
		};
		unsigned long move_entries[] = {
			0, 1, PTATTR_FILEOFF,
			0x12345000UL | PTATTR_ACTIVE | PTATTR_WRITABLE,
			0x000ffffffffff000UL | PTATTR_NO_EXECUTE |
				PTATTR_USER,
			0x45678000UL | PTATTR_ACTIVE | PTATTR_DIRTY,
			0x200000UL | PTATTR_FILEOFF | PTATTR_LARGEPAGE,
		};
		int pgshifts[] = { 0, 12, 21, 30, 39 };
		int map_shifts[] = { 12, 21, 30, 39 };
		int shape_shifts[] = { 12, 21, 30, 39 };

		for (unsigned int e = 0; e < sizeof(entries) / sizeof(entries[0]); e++) {
			mix(&digest, (unsigned int)x86_set_range_leaf_action_result(
				entries[e]));
			for (unsigned int p = 0; p < sizeof(pgshifts) / sizeof(pgshifts[0]); p++) {
				for (int use_1gb = 0; use_1gb <= 1; use_1gb++) {
					mix(&digest, (unsigned int)x86_lookup_default_pgshift_result(
						pgshifts[p], use_1gb));
				}
				mix(&digest, (unsigned int)x86_lookup_l4_empty_pgshift_result(
					pgshifts[p]));
				mix(&digest, (unsigned int)x86_lookup_level_action_result(
					entries[e], pgshifts[p], 21, 0x80));
				mix(&digest, (unsigned int)x86_lookup_level_action_result(
					entries[e], pgshifts[p], 30, 0x80));
				mix(&digest, (unsigned int)x86_lookup_level_action_result(
					entries[e], pgshifts[p], 30, 0));
			}
			for (unsigned int r = 0; r < sizeof(ranges) / sizeof(ranges[0]); r++) {
				for (unsigned int s = 0; s < sizeof(shape_shifts) / sizeof(shape_shifts[0]); s++) {
					unsigned long base = 0xbadbadUL;
					size_t size = 0xcafecafeUL;
					int p2align = -1234;

					x86_lookup_shape_result(ranges[r][0],
						shape_shifts[s], &base, &size,
						&p2align);
					mix(&digest, base);
					mix(&digest, size);
					mix(&digest, (unsigned int)p2align);
				}
				for (unsigned int p = 0; p < sizeof(pgshifts) / sizeof(pgshifts[0]); p++) {
					for (int skip = 0; skip <= 1; skip++) {
						for (int direct_requires = 0; direct_requires <= 1; direct_requires++) {
							for (int direct_enabled = 0; direct_enabled <= 1; direct_enabled++) {
								for (int can_alloc = 0; can_alloc <= 1; can_alloc++) {
									mix(&digest,
										(unsigned int)x86_visit_pte_action_result(
											entries[e], skip,
											ranges[r][0], ranges[r][1],
											ranges[r][2],
											2UL * 1024 * 1024, 21,
											pgshifts[p], 0x80,
											direct_requires,
											direct_enabled, can_alloc));
								}
							}
						}
					}
				}
				mix(&digest, (unsigned int)x86_clear_range_entry_action_result(
					entries[e], ranges[r][2], ranges[r][0],
					ranges[r][1], 2UL * 1024 * 1024, 0x80));
				mix(&digest, (unsigned int)x86_change_attr_leaf_action_result(
					entries[e], PTATTR_FILEOFF));
				mix(&digest, (unsigned int)x86_change_attr_entry_action_result(
					entries[e], ranges[r][2], ranges[r][0],
					ranges[r][1], 2UL * 1024 * 1024, 0x80,
					PTATTR_FILEOFF));
				mix(&digest, (unsigned int)x86_change_attr_entry_action_result(
					entries[e], ranges[r][2], ranges[r][0],
					ranges[r][1], 1024UL * 1024 * 1024, 0x80,
					PTATTR_FILEOFF));
				mix(&digest, (unsigned int)x86_change_attr_entry_action_result(
					entries[e], ranges[r][2], ranges[r][0],
					ranges[r][1], 0, 0, 0));
				for (unsigned int d = 0; d < sizeof(diffs) / sizeof(diffs[0]); d++) {
					for (unsigned int p = 0; p < sizeof(pgshifts) / sizeof(pgshifts[0]); p++) {
						for (int direct = 0; direct <= 1; direct++) {
							mix(&digest, (unsigned int)x86_set_range_entry_action_result(
								entries[e], ranges[r][2],
								ranges[r][0], ranges[r][1],
								diffs[d], pgshifts[p], 21,
								2UL * 1024 * 1024, 0x80,
								direct));
							mix(&digest, (unsigned int)x86_set_range_entry_action_result(
								entries[e], ranges[r][2],
								ranges[r][0], ranges[r][1],
								diffs[d], pgshifts[p], 30,
								1024UL * 1024 * 1024,
								0x80, direct));
							for (unsigned int s = 0; s < sizeof(map_shifts) / sizeof(map_shifts[0]); s++) {
								unsigned long map_phys = 0xaaaaaaaaUL;
								unsigned long map_entry = 0xbbbbbbbbUL;
								int error = x86_set_range_map_entry_result(
									diffs[d], ranges[r][2],
									ranges[r][0], attrs[e %
									(sizeof(attrs) /
									sizeof(attrs[0]))],
									map_shifts[s], attr_mask,
									&map_phys, &map_entry);

								mix(&digest, (unsigned int)-error);
								mix(&digest, map_phys);
								mix(&digest, map_entry);
							}
						}
					}
				}
				mix(&digest, (unsigned int)x86_set_range_entry_action_result(
					entries[e], ranges[r][2], ranges[r][0],
					ranges[r][1], 0, 0, 0, 0, 0, 0));
			}
		}

		{
			unsigned long pte;
			int ret;

			reset_fake_visit();
			pte = 0;
			ret = x86_visit_pte_leaf_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x12345000UL, 1,
				PTL1_SHIFT, fake_visit_leaf);
			require(ret == 0);
			require(fake_visit_calls == 0);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			pte = 0x5555UL;
			ret = x86_visit_pte_leaf_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x12345000UL, 0,
				PTL1_SHIFT, fake_visit_leaf);
			require(ret == 0);
			require(fake_visit_calls == 1);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			pte = PF_PRESENT | PF_SIZE | 0x200000UL;
			ret = x86_visit_pte_level_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x200000UL,
				0x200000UL, 0x400000UL, 0, 0, PTL2_SHIFT,
				2UL * 1024 * 1024, PTL2_SHIFT, PF_SIZE,
				0, 1, 1, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL,
				fake_visit_leaf, fake_visit_log);
			require(ret == 0);
			require(fake_visit_calls == 1);
			require(fake_visit_walk_calls == 0);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			fake_visit_e2big_once = 1;
			pte = 0;
			ret = x86_visit_pte_level_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x200000UL,
				0x200000UL, 0x400000UL, 0, 0, PTL2_SHIFT,
				2UL * 1024 * 1024, PTL2_SHIFT, PF_SIZE,
				0, 1, 1, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL,
				fake_visit_leaf, fake_visit_log);
			require(ret == 0);
			require(fake_visit_calls == 1);
			require(fake_visit_walk_calls == 1);
			require(fake_pt_alloc_count == 1);
			require(pte == (fake_pt_virt_to_phys(&fake_created_tables[0]) |
					0x7UL));
			mix(&digest, fake_visit_digest);
			mix(&digest, pte);

			reset_fake_visit();
			pte = fake_pt_virt_to_phys(&fake_created_tables[0]) |
				PF_PRESENT;
			ret = x86_visit_pte_level_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x200000UL,
				0x200000UL, 0x201000UL, 1, 1, PTL1_SHIFT,
				2UL * 1024 * 1024, PTL2_SHIFT, PF_SIZE,
				1, 1, 0, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL,
				fake_visit_leaf, fake_visit_log);
			require(ret == 0);
			require(fake_visit_calls == 0);
			require(fake_visit_walk_calls == 1);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			pte = PF_PRESENT | PF_SIZE | 0x200000UL;
			ret = x86_visit_pte_level_result((void *)0x1111UL,
				(void *)0x2222UL, &pte, 0x200000UL,
				0x200000UL, 0x201000UL, 1, 1, PTL1_SHIFT,
				2UL * 1024 * 1024, PTL2_SHIFT, PF_SIZE,
				1, 0, 0, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL,
				fake_visit_leaf, fake_visit_log);
			require(ret == -12);
			require(fake_visit_log_calls == 1);
			require(fake_visit_log_event == 1);
			require(fake_visit_log_shift == PTL2_SHIFT);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			pte = 0;
			ret = x86_visit_pte_root_result(&pte, 0, 0x200000UL,
				0x400000UL, 0, 1, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL);
			require(ret == 0);
			require(fake_visit_walk_calls == 1);
			require(fake_pt_alloc_count == 1);
			mix(&digest, fake_visit_digest);
			mix(&digest, pte);

			reset_fake_visit();
			pte = 0;
			ret = x86_visit_pte_root_result(&pte, 0, 0x200000UL,
				0x400000UL, 1, 0, 0x7, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_visit_phys_to_virt,
				fake_visit_child_walk, (void *)0x3333UL);
			require(ret == 0);
			require(fake_visit_walk_calls == 0);
			mix(&digest, fake_visit_digest);

			reset_fake_visit();
			ret = x86_visit_pte_range_dispatch_result((void *)0x2222UL,
				0x1000UL, 0x9000UL, (void *)0x3333UL,
				fake_visit_child_walk);
			require(ret == 0);
			require(fake_visit_walk_calls == 1);
			mix(&digest, fake_visit_digest);
		}

		{
			unsigned long slot = 0;
			unsigned long expected;
			int ret;

			reset_fake_set_range();
			ret = x86_set_range_conflict_result(
				(void *)0x1111UL, (void *)0x2222UL,
				0x4000UL, 0x8000UL, 0x5000UL,
				0xabc007UL, PTL1_SHIFT, 0,
				fake_set_clear, fake_set_log);
			require(ret == -16);
			require(fake_set_clear_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			ret = x86_set_range_alloc_failed_result(
				(void *)0x1111UL, (void *)0x2222UL,
				0x4000UL, 0x8000UL, 0x5000UL,
				0xdef007UL, PTL2_SHIFT, 0,
				fake_set_clear, fake_set_log);
			require(ret == -12);
			require(fake_set_clear_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			ret = x86_set_range_walk_failed_result(-5, 0x5000UL,
				0x4000UL, 0x8000UL, 0xdef007UL,
				PTL3_SHIFT, fake_set_log);
			require(ret == -5);
			require(fake_set_clear_calls == 0);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			fake_set_rss_result = 1;
			ret = x86_set_range_map_effect_result(0x200000UL,
				0x400000UL, 0x300000UL, 0x500000UL,
				PTATTR_ACTIVE | PTATTR_WRITABLE | PTATTR_USER,
				PTL2_SHIFT, attr_mask,
				1UL << PTL2_SHIFT, &slot,
				(void *)0x3333UL, 1, fake_set_rss_add,
				fake_set_log);
			require(ret == 0);
			expected = 0x300000UL | x86_attr_to_l2attr_result(
				PTATTR_ACTIVE | PTATTR_WRITABLE |
				PTATTR_USER | PTATTR_LARGEPAGE, attr_mask);
			require(slot == expected);
			require(fake_set_rss_calls == 1);
			require(fake_set_log_calls == 2);
			mix(&digest, fake_set_digest);
			mix(&digest, slot);

			reset_fake_set_range();
			slot = 0;
			ret = x86_set_range_map_effect_result(0x9000UL,
				0x1000UL, 0x1000UL, 0x2000UL,
				PTATTR_ACTIVE | PTATTR_USER,
				PTL1_SHIFT, attr_mask, 1UL << PTL1_SHIFT,
				&slot, (void *)0x3333UL, 0,
				fake_set_rss_add, fake_set_log);
			require(ret == 0);
			require(fake_set_rss_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);
			mix(&digest, slot);

			require(x86_set_range_conflict_result(
				(void *)0x1111UL, (void *)0x2222UL,
				0x4000UL, 0x8000UL, 0x5000UL,
				0xabc007UL, PTL1_SHIFT, 0, NULL,
				fake_set_log) == -22);
			require(x86_set_range_map_effect_result(0x9000UL,
				0x1000UL, 0x1000UL, 0x2000UL,
				PTATTR_ACTIVE, PTL1_SHIFT, attr_mask,
				1UL << PTL1_SHIFT, NULL,
				(void *)0x3333UL, 0, fake_set_rss_add,
				fake_set_log) == -22);
			require(x86_set_range_map_effect_result(0x9000UL,
				0x1000UL, 0x1000UL, 0x2000UL,
				PTATTR_ACTIVE, 99, attr_mask,
				1UL << PTL1_SHIFT, &slot,
				(void *)0x3333UL, 0, fake_set_rss_add,
				fake_set_log) == -22);

			reset_fake_set_range();
			slot = 0;
			ret = x86_set_range_leaf_body_result((void *)0x4444UL,
				&slot, 0x1000UL, 0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x9000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, (void *)0x3333UL,
				fake_set_clear, fake_set_rss_add,
				fake_set_log);
			require(ret == 0);
			require(slot == (0x9000UL | x86_attr_to_l1attr_result(
				PTATTR_ACTIVE | PTATTR_USER, attr_mask)));
			require(fake_set_rss_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);
			mix(&digest, slot);

			reset_fake_set_range();
			slot = 0xabc007UL;
			ret = x86_set_range_leaf_body_result((void *)0x4444UL,
				&slot, 0x1000UL, 0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x9000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, (void *)0x3333UL,
				fake_set_clear, fake_set_rss_add,
				fake_set_log);
			require(ret == -16);
			require(fake_set_clear_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			reset_fake_pt_destroy_table();
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			slot = 0;
			ret = x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0x200000UL,
				0x200000UL, 0x400000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL,
				PTATTR_ACTIVE | PTATTR_WRITABLE |
				PTATTR_USER, attr_mask, 0, PTL2_SHIFT,
				PTL2_SHIFT, 1UL << PTL2_SHIFT, 0x80UL,
				1, 0x07UL, (void *)0x3333UL,
				fake_pt_alloc_pages,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log);
			require(ret == 0);
			require(fake_pt_alloc_count == 0);
			require(fake_set_child_walk_calls == 0);
			require(fake_set_rss_calls == 1);
			require(fake_set_log_calls == 2);
			mix(&digest, fake_set_digest);
			mix(&digest, slot);

			reset_fake_set_range();
			reset_fake_pt_destroy_table();
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			slot = 0;
			ret = x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0,
				0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, 0, 0, PTL2_SHIFT,
				1UL << PTL2_SHIFT, 0x80UL, 1, 0x07UL,
				(void *)0x3333UL, fake_pt_alloc_pages,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log);
			require(ret == 0);
			require(fake_pt_alloc_count == 1);
			require(fake_created_tables[0].entry[0] == 0);
			require(slot == (fake_pt_virt_to_phys(
				&fake_created_tables[0]) | 0x07UL));
			require(fake_set_child_walk_calls == 1);
			require(fake_set_child_walk_last_pt ==
				&fake_created_tables[0]);
			mix(&digest, fake_set_digest);
			mix(&digest, slot);

			reset_fake_set_range();
			reset_fake_pt_destroy_table();
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			slot = fake_pt_virt_to_phys(&fake_created_tables[1]) |
				0x07UL;
			ret = x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0,
				0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, 0, 0, PTL2_SHIFT,
				1UL << PTL2_SHIFT, 0x80UL, 1, 0x07UL,
				(void *)0x3333UL, fake_pt_alloc_pages,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log);
			require(ret == 0);
			require(fake_pt_alloc_count == 0);
			require(fake_set_child_walk_calls == 1);
			require(fake_set_child_walk_last_pt ==
				&fake_created_tables[1]);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			fake_set_child_walk_result = -5;
			ret = x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0,
				0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, 0, 0, PTL2_SHIFT,
				1UL << PTL2_SHIFT, 0x80UL, 1, 0x07UL,
				(void *)0x3333UL, fake_pt_alloc_pages,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log);
			require(ret == -5);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			reset_fake_set_range();
			reset_fake_pt_destroy_table();
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 1;
			slot = 0;
			ret = x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0,
				0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, 0, 0, PTL2_SHIFT,
				1UL << PTL2_SHIFT, 0x80UL, 1, 0x07UL,
				(void *)0x3333UL, fake_pt_alloc_pages,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log);
			require(ret == -12);
			require(fake_set_clear_calls == 1);
			require(fake_set_log_calls == 1);
			mix(&digest, fake_set_digest);

			require(x86_set_range_level_body_result(
				(void *)0x4444UL, &slot, 0,
				0x1000UL, 0x2000UL,
				(void *)0x1111UL, (void *)0x2222UL,
				0x800000UL, PTATTR_ACTIVE | PTATTR_USER,
				attr_mask, 0, 0, PTL2_SHIFT,
				1UL << PTL2_SHIFT, 0x80UL, 1, 0x07UL,
				(void *)0x3333UL, NULL,
				fake_pt_destroy_free_pages,
				fake_pt_virt_to_phys, fake_set_phys_to_virt,
				fake_set_child_walk, fake_set_clear,
				fake_set_rss_add, fake_set_log) == -22);

			{
				struct fake_set_top_args top_args;

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_set_top();
				ret = x86_set_range_top_result(
					(void *)0x1111UL, (void *)0x2222UL,
					0x4000UL, 0x8000UL, 0x14000UL,
					(int)(PTATTR_ACTIVE | PTATTR_USER),
					PTL1_SHIFT, (void *)0x3333UL,
					&top_args, &top_args.pt,
					&top_args.phys, &top_args.attr,
					&top_args.diff, &top_args.vm,
					&top_args.pgshift, &top_args.range,
					fake_set_top_walk, fake_set_log);
				require(ret == 0);
				require(fake_set_top_walk_calls == 1);
				require(fake_set_log_calls == 0);
				require(top_args.diff == (0x4000UL ^ 0x14000UL));
				mix(&digest, fake_set_digest);

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_set_top();
				fake_set_top_walk_result = -7;
				ret = x86_set_range_top_result(
					(void *)0x1111UL, (void *)0x2222UL,
					0x4000UL, 0x8000UL, 0x14000UL,
					(int)(PTATTR_ACTIVE | PTATTR_USER),
					PTL1_SHIFT, (void *)0x3333UL,
					&top_args, &top_args.pt,
					&top_args.phys, &top_args.attr,
					&top_args.diff, &top_args.vm,
					&top_args.pgshift, &top_args.range,
					fake_set_top_walk, fake_set_log);
				require(ret == -7);
				require(fake_set_top_walk_calls == 1);
				require(fake_set_log_calls == 1);
				mix(&digest, fake_set_digest);

				require(x86_set_range_top_result(
					(void *)0x1111UL, (void *)0x2222UL,
					0x4000UL, 0x8000UL, 0x14000UL,
					(int)(PTATTR_ACTIVE | PTATTR_USER),
					PTL1_SHIFT, (void *)0x3333UL,
					&top_args, &top_args.pt,
					&top_args.phys, &top_args.attr,
					&top_args.diff, &top_args.vm,
					&top_args.pgshift, &top_args.range,
					NULL, fake_set_log) == -22);
			}
		}

		{
			unsigned long slot = 0;
			unsigned long old;
			unsigned long updated;

			require(x86_pte_store_result(&slot, 0x12345007UL) == 0);
			require(slot == 0x12345007UL);
			mix(&digest, slot);
			require(x86_pte_store_result(NULL, 0x1UL) == -22);

			old = x86_pte_publish_table_result(&slot, 0x2007UL);
			require(old == 0x12345007UL);
			require(slot == 0x12345007UL);
			mix(&digest, old);
			mix(&digest, slot);

			slot = 0;
			old = x86_pte_publish_table_result(&slot, 0x3007UL);
			require(old == 0);
			require(slot == 0x3007UL);
			mix(&digest, old);
			mix(&digest, slot);

			old = x86_pte_clear_result(&slot);
			require(old == 0x3007UL);
			require(slot == 0);
			mix(&digest, old);
			mix(&digest, slot);
			require(x86_pte_clear_result(NULL) == ~0UL);
			require(x86_pte_publish_table_result(NULL, 0x1UL) == ~0UL);

			slot = 0xabcdef0fUL;
			updated = x86_pte_apply_attr_result(&slot, 0xf0UL,
							    0x40UL);
			require(updated == ((0xabcdef0fUL & ~0xf0UL) | 0x40UL));
			require(slot == updated);
			mix(&digest, updated);
			mix(&digest, slot);
			require(x86_pte_apply_attr_result(NULL, 0x1UL, 0x2UL) ==
				~0UL);
		}

		for (unsigned int e = 0; e < sizeof(move_entries) / sizeof(move_entries[0]); e++) {
			unsigned long phys = 0x11111111UL;
			unsigned long attr = 0x22222222UL;

			x86_move_pte_entry_parts_result(move_entries[e],
				&phys, &attr);
			mix(&digest, phys);
			mix(&digest, attr);
			for (unsigned int f = 0; f < sizeof(diffs) / sizeof(diffs[0]); f++) {
				unsigned long arch_attr =
					x86_arch_vrflag_to_ptattr_result(
						(f & 1) ? VR_PRIVATE : 0,
						diffs[f] & (PF_PROT |
							PF_POPULATE |
							PF_PATCH),
						move_entries[e]);

				if ((diffs[f] & PF_PROT) ||
				    ((diffs[f] & (PF_POPULATE | PF_PATCH)) &&
				     (f & 1))) {
					require(arch_attr & PTATTR_DIRTY);
				}
				mix(&digest, arch_attr);
			}
			for (unsigned int p = 0; p < sizeof(move_pgsizes) / sizeof(move_pgsizes[0]); p++) {
				for (unsigned int r = 0; r < sizeof(ranges) / sizeof(ranges[0]); r++) {
					unsigned long mapped = 0xfeedfaceUL;
					int error = x86_move_pte_preflight_result(
						move_entries[e],
						move_pgsizes[p],
						ranges[r][0], ranges[r][1],
						ranges[r][2], &mapped);

					mix(&digest, move_pgsizes[p]);
					mix(&digest, (unsigned int)-error);
					mix(&digest, mapped);
				}
			}
		}
		{
			unsigned long slot;
			int ret;

			reset_fake_move_one();
			slot = 0x12345000UL | PF_PRESENT | PTATTR_WRITABLE |
				PTATTR_USER;
			ret = x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, &slot, 0x3000UL, PTL1_SHIFT,
				0x1000UL, 0x9000UL, (void *)0x2222UL,
				(void *)0x3333UL, fake_move_set_range_fn,
				fake_move_log);
			require(ret == 0);
			require(slot == 0);
			require(fake_move_set_range_calls == 1);
			require(fake_move_set_pt == (void *)0x1111UL);
			require(fake_move_set_vm == (void *)0x2222UL);
			require(fake_move_set_range_arg == (void *)0x3333UL);
			require(fake_move_set_start == 0xb000UL);
			require(fake_move_set_end == 0xc000UL);
			require(fake_move_set_phys == 0x12345000UL);
			require(fake_move_set_attr ==
				((0x12345000UL | PF_PRESENT |
				PTATTR_WRITABLE | PTATTR_USER) & ~PT_PHYSMASK));
			require(fake_move_set_pgshift == PTL1_SHIFT);
			require(fake_move_set_overwrite == 0);
			require(fake_move_log_calls == 0);
			mix(&digest, fake_move_digest);

			reset_fake_move_one();
			slot = 0x800000UL | PF_PRESENT | PF_SIZE |
				PTATTR_FILEOFF;
			ret = x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, &slot, 0x800000UL,
				PTL2_SHIFT, 0x800000UL, 0x1800000UL,
				(void *)0x2222UL, (void *)0x3333UL,
				fake_move_set_range_fn, fake_move_log);
			require(ret == -524);
			require(slot == (0x800000UL | PF_PRESENT | PF_SIZE |
				PTATTR_FILEOFF));
			require(fake_move_set_range_calls == 0);
			require(fake_move_log_event == X86_MOVE_ONE_LOG_FILEOFF);
			require(fake_move_log_entry == slot);
			mix(&digest, fake_move_digest);

			reset_fake_move_one();
			fake_move_set_range_result = -6;
			slot = 0x12345000UL | PF_PRESENT | PTATTR_USER;
			ret = x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, &slot, 0x3000UL, PTL1_SHIFT,
				0x1000UL, 0x9000UL, (void *)0x2222UL,
				(void *)0x3333UL, fake_move_set_range_fn,
				fake_move_log);
			require(ret == -6);
			require(slot == 0);
			require(fake_move_set_range_calls == 1);
			require(fake_move_log_event ==
				X86_MOVE_ONE_LOG_SET_FAILED);
			require(fake_move_log_error == -6);
			require(fake_move_log_current == 0);
			mix(&digest, fake_move_digest);

			require(x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, NULL, 0x3000UL,
				PTL1_SHIFT, 0x1000UL, 0x9000UL,
				(void *)0x2222UL, (void *)0x3333UL,
				fake_move_set_range_fn, fake_move_log) == -22);
			require(x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, &slot, 0x3000UL,
				-1, 0x1000UL, 0x9000UL,
				(void *)0x2222UL, (void *)0x3333UL,
				fake_move_set_range_fn, fake_move_log) == -22);
			require(x86_move_one_page_body_result((void *)0x4444UL,
				(void *)0x1111UL, &slot, 0x3000UL,
				PTL1_SHIFT, 0x1000UL, 0x9000UL,
				(void *)0x2222UL, (void *)0x3333UL,
				NULL, fake_move_log) == -22);
			mix(&digest, 0x6d6f76656e756cUL);
		}
		{
			struct fake_move_range_args args;
			int ret;

			memset(&args, 0, sizeof(args));
			reset_fake_move_range();
			fake_move_range_call_visitor = 1;
			ret = x86_move_pte_range_body_result((void *)0x1111UL,
				0x2000UL, 0xa000UL, 0x3000UL,
				(void *)0x2222UL, (void *)0x3333UL, &args,
				&args.src, &args.dest, &args.vm, &args.range,
				fake_move_range_visitor, fake_move_range_visit,
				fake_move_range_flush);
			require(ret == 0);
			require(args.src == 0x2000UL);
			require(args.dest == 0xa000UL);
			require(args.vm == (void *)0x2222UL);
			require(args.range == (void *)0x3333UL);
			require(fake_move_range_visit_calls == 1);
			require(fake_move_range_visit_pt == (void *)0x1111UL);
			require(fake_move_range_visit_start == 0x2000UL);
			require(fake_move_range_visit_end == 0x5000UL);
			require(fake_move_range_visit_pgshift == 0);
			require(fake_move_range_visit_flags == 1);
			require(fake_move_range_visit_arg == &args);
			require(fake_move_range_visitor_calls == 1);
			require(fake_move_range_arg_src == 0x2000UL);
			require(fake_move_range_arg_dest == 0xa000UL);
			require(fake_move_range_arg_vm == (void *)0x2222UL);
			require(fake_move_range_arg_range == (void *)0x3333UL);
			require(fake_move_range_flush_calls == 1);
			mix(&digest, fake_move_range_digest);

			memset(&args, 0, sizeof(args));
			reset_fake_move_range();
			fake_move_range_visit_result = -5;
			ret = x86_move_pte_range_body_result((void *)0x1111UL,
				0x8000UL, 0x18000UL, 0x2000UL,
				(void *)0x2222UL, (void *)0x3333UL, &args,
				&args.src, &args.dest, &args.vm, &args.range,
				fake_move_range_visitor, fake_move_range_visit,
				fake_move_range_flush);
			require(ret == -5);
			require(args.src == 0x8000UL);
			require(args.dest == 0x18000UL);
			require(fake_move_range_visit_end == 0xa000UL);
			require(fake_move_range_flush_calls == 1);
			mix(&digest, fake_move_range_digest);

			require(x86_move_pte_range_body_result((void *)0x1111UL,
				0x2000UL, 0xa000UL, 0x3000UL,
				(void *)0x2222UL, (void *)0x3333UL, &args,
				&args.src, &args.dest, &args.vm, &args.range,
				NULL, fake_move_range_visit,
				fake_move_range_flush) == -22);
			require(x86_move_pte_range_body_result((void *)0x1111UL,
				0x2000UL, 0xa000UL, 0x3000UL,
				(void *)0x2222UL, (void *)0x3333UL, NULL,
				&args.src, &args.dest, &args.vm, &args.range,
				fake_move_range_visitor, fake_move_range_visit,
				fake_move_range_flush) == -22);
			require(x86_move_pte_range_body_result((void *)0x1111UL,
				0x2000UL, 0xa000UL, 0x3000UL,
				(void *)0x2222UL, (void *)0x3333UL, &args,
				&args.src, &args.dest, &args.vm, &args.range,
				fake_move_range_visitor, NULL,
				fake_move_range_flush) == -22);
			require(x86_move_pte_range_body_result((void *)0x1111UL,
				0x2000UL, 0xa000UL, 0x3000UL,
				(void *)0x2222UL, (void *)0x3333UL, &args,
				&args.src, &args.dest, &args.vm, &args.range,
				fake_move_range_visitor, fake_move_range_visit,
				NULL) == -22);
			mix(&digest, 0x6d6f7665726e67UL);
		}
		{
			reset_fake_load_page_table();
			{
				void *last = NULL;
				void *ret;

				ret = x86_early_alloc_pages_body_result(&last,
					0xffff000000012345UL, 0x20000UL, 2,
					fake_mem_virt_to_phys,
					fake_mem_phys_to_virt, fake_mem_panic);
				require(ret == (void *)0xffff800000013000UL);
				require(last == (void *)0xffff800000015000UL);
				require(fake_mem_panic_count == 0);

				ret = x86_early_alloc_pages_body_result(&last,
					0xffff000000012345UL, 0x20000UL, 1,
					fake_mem_virt_to_phys,
					fake_mem_phys_to_virt, fake_mem_panic);
				require(ret == (void *)0xffff800000015000UL);
				require(last == (void *)0xffff800000016000UL);
				mix(&digest, (unsigned long)last);
			}

			{
				void *last = (void *)-1;
				require(x86_early_alloc_pages_body_result(&last,
					0xffff000000012345UL, 0x20000UL, 1,
					fake_mem_virt_to_phys,
					fake_mem_phys_to_virt, fake_mem_panic) == NULL);
				require(fake_mem_panic_count == 1 &&
					fake_mem_panic_reason == 1);
				mix(&digest, (unsigned long)fake_mem_panic_reason);
			}

			reset_fake_load_page_table();
			{
				void *last = (void *)0xffff800000030000UL;
				require(x86_early_alloc_pages_body_result(&last,
					0xffff000000012345UL, 0x20000UL, 1,
					fake_mem_virt_to_phys,
					fake_mem_phys_to_virt, fake_mem_panic) == NULL);
				require(fake_mem_panic_count == 1 &&
					fake_mem_panic_reason == 2);
				require(x86_early_alloc_invalidate_body_result(&last) == 0);
				require(last == (void *)-1);
				require(x86_get_last_early_heap_body_result(&last) ==
					(void *)-1);
				mix(&digest, (unsigned long)fake_mem_panic_reason);
			}

			reset_fake_load_page_table();
			{
				int use_1gb = -1;
				unsigned long attr = 0x1234UL;

				fake_mem_cpuid_edx_value = 0;
				require(x86_check_available_page_size_body_result(
					&use_1gb, fake_mem_cpuid_edx,
					fake_mem_log_int) == 0);
				require(use_1gb == 0 &&
					fake_mem_cpuid_op == 0x80000001UL);
				require(fake_mem_log_count == 1 &&
					fake_mem_log_event == 1 &&
					fake_mem_log_value == 0);
				fake_mem_cpuid_edx_value = 1UL << 26;
				require(x86_check_available_page_size_body_result(
					&use_1gb, fake_mem_cpuid_edx,
					fake_mem_log_int) == 0);
				require(use_1gb == 1);
				require(x86_enable_ptattr_no_execute_body_result(
					&attr, 0x8000000000000000UL) == 0);
				require(attr == (0x1234UL | 0x8000000000000000UL));
				mix(&digest, attr ^ (unsigned long)use_1gb);
			}

			reset_fake_load_page_table();
			{
				void *allocated;

				allocated = x86_ihk_mc_allocate_body_result(0, 32,
					2, fake_mem_kmalloc, fake_mem_log);
				require(allocated == NULL && fake_mem_kmalloc_calls == 0);
				require(fake_mem_log_count == 1 &&
					fake_mem_log_event == 1);
				allocated = x86_ihk_mc_allocate_body_result(1, 48,
					2, fake_mem_kmalloc, fake_mem_log);
				require(allocated == fake_mem_alloc_buf);
				require(fake_mem_kmalloc_calls == 1 &&
					fake_mem_kmalloc_size == 48 &&
					fake_mem_kmalloc_flag == 2);
				require(x86_ihk_mc_free_body_result(0, allocated,
					fake_mem_kfree, fake_mem_log) == 0);
				require(fake_mem_kfree_calls == 0 &&
					fake_mem_log_event == 2);
				require(x86_ihk_mc_free_body_result(1, allocated,
					fake_mem_kfree, fake_mem_log) == 0);
				require(fake_mem_kfree_calls == 1 &&
					fake_mem_kfree_ptr == allocated);
				mix(&digest, (unsigned long)fake_mem_kmalloc_size ^
					(unsigned long)fake_mem_kfree_calls);
			}

			reset_fake_load_page_table();
			memset(fake_created_tables, 0xa5, sizeof(fake_created_tables));
			{
				unsigned long ret;

				ret = x86_setup_l2_body_result(&fake_created_tables[0],
					0, PTL2_SIZE, PTL2_SIZE * 3,
					fake_pt_virt_to_phys);
				require(ret == fake_pt_virt_to_phys(&fake_created_tables[0]));
				require(fake_created_tables[0].entry[0] == 0);
				require(fake_created_tables[0].entry[1] ==
					(PTL2_SIZE | PFL2_KERN_ATTR | PF_SIZE));
				require(fake_created_tables[0].entry[2] ==
					((2UL * PTL2_SIZE) | PFL2_KERN_ATTR |
					 PF_SIZE));
				require(fake_created_tables[0].entry[3] == 0);
				mix(&digest, ret);
				mix(&digest, fake_created_tables[0].entry[2]);
			}

			reset_fake_load_page_table();
			memset(fake_created_tables, 0xa5, sizeof(fake_created_tables));
			{
				unsigned long ret;

				fake_pt_alloc_count = 1;
				fake_pt_alloc_fail = 0;
				fake_pt_last_ap_flag = -1;
				ret = x86_setup_l3_body_result(&fake_created_tables[0],
					0, PTL3_SIZE, PTL3_SIZE + PTL2_SIZE,
					IHK_MC_AP_CRITICAL, fake_pt_alloc_pages,
					fake_pt_virt_to_phys);
				require(ret == fake_pt_virt_to_phys(&fake_created_tables[0]));
				require(fake_pt_alloc_count == 2);
				require(fake_pt_last_ap_flag == IHK_MC_AP_CRITICAL);
				require(fake_created_tables[0].entry[0] == 0);
				require(fake_created_tables[0].entry[1] ==
					(fake_pt_virt_to_phys(&fake_created_tables[1]) |
					 PFL3_PDIR_ATTR));
				require(fake_created_tables[0].entry[2] == 0);
				require(fake_created_tables[1].entry[0] ==
					(PTL3_SIZE | PFL2_KERN_ATTR | PF_SIZE));
				require(fake_created_tables[1].entry[1] == 0);
				mix(&digest, ret ^ fake_created_tables[0].entry[1]);
				mix(&digest, fake_created_tables[1].entry[0]);
			}

			reset_fake_load_page_table();
			{
				void *init_pt = NULL;
				void *boot_pt = NULL;
				int loaded = 0;
				int fake_lock = 0;

				require(x86_init_page_table_body_result(&init_pt,
					&boot_pt, &loaded, &fake_lock, 64, 1,
					fake_init_page_check,
					fake_init_page_alloc,
					fake_init_page_spin_init,
					fake_init_page_normal,
					fake_init_page_linux,
					fake_init_page_fixed,
					fake_init_page_text,
					fake_init_page_vsyscall,
					fake_init_page_low,
					fake_init_page_load,
					fake_init_page_log,
					fake_mem_panic) == 0);
				require(init_pt == fake_init_pt_pages[0]);
				require(boot_pt == fake_init_pt_pages[1]);
				require(loaded == 1);
				require(fake_init_page_spin_init_calls == 1 &&
					fake_init_page_spin_lock == &fake_lock);
				require(fake_init_page_alloc_calls == 2 &&
					fake_init_page_alloc_flags[0] == 1 &&
					fake_init_page_alloc_flags[1] == 1);
				require(fake_init_pt_pages[0][0] == 0x11 &&
					fake_init_pt_pages[0][1] == 0x22 &&
					fake_init_pt_pages[0][2] == 0x33 &&
					fake_init_pt_pages[0][3] == 0x44 &&
					fake_init_pt_pages[0][4] == 0x55 &&
					fake_init_pt_pages[0][8] == 0);
				require(fake_init_pt_pages[1][0] == 0x11 &&
					fake_init_pt_pages[1][4] == 0x55 &&
					fake_init_pt_pages[1][7] == 0x7f);
				require(fake_init_page_loaded_calls == 1 &&
					fake_init_page_loaded_pt == init_pt);
				require(fake_init_page_log_count == 1 &&
					fake_init_page_log_event == 1 &&
					fake_init_page_log_pt == init_pt);
				require(fake_init_page_order_count == 12);
				require(fake_init_page_order[0] == 13 &&
					fake_init_page_order[1] == 21 &&
					fake_init_page_order[2] == 30 &&
					fake_init_page_order[3] == 40 &&
					fake_init_page_order[4] == 41 &&
					fake_init_page_order[5] == 42 &&
					fake_init_page_order[6] == 43 &&
					fake_init_page_order[7] == 44 &&
					fake_init_page_order[8] == 22 &&
					fake_init_page_order[9] == 45 &&
					fake_init_page_order[10] == 50 &&
					fake_init_page_order[11] == 61);
				mix(&digest, (unsigned long)loaded ^
					(unsigned long)fake_init_page_order_count);
				mix(&digest, (unsigned long)fake_init_pt_pages[1][7]);
			}

			reset_fake_load_page_table();
			{
				void *init_pt = NULL;
				void *boot_pt = NULL;
				int loaded = 0;
				int fake_lock = 0;

				fake_init_page_alloc_fail_at = 1;
				require(x86_init_page_table_body_result(&init_pt,
					&boot_pt, &loaded, &fake_lock, 64, 1,
					fake_init_page_check,
					fake_init_page_alloc,
					fake_init_page_spin_init,
					fake_init_page_normal,
					fake_init_page_linux,
					fake_init_page_fixed,
					fake_init_page_text,
					fake_init_page_vsyscall,
					fake_init_page_low,
					fake_init_page_load,
					fake_init_page_log,
					fake_mem_panic) == -12);
				require(fake_mem_panic_count == 1 &&
					fake_mem_panic_reason == 3);
				mix(&digest, (unsigned long)fake_mem_panic_reason);
			}

			reset_fake_load_page_table();
			{
				void *init_pt = NULL;
				void *boot_pt = NULL;
				int loaded = 0;
				int fake_lock = 0;

				fake_init_page_alloc_fail_at = 2;
				require(x86_init_page_table_body_result(&init_pt,
					&boot_pt, &loaded, &fake_lock, 64, 1,
					fake_init_page_check,
					fake_init_page_alloc,
					fake_init_page_spin_init,
					fake_init_page_normal,
					fake_init_page_linux,
					fake_init_page_fixed,
					fake_init_page_text,
					fake_init_page_vsyscall,
					fake_init_page_low,
					fake_init_page_load,
					fake_init_page_log,
					fake_mem_panic) == -12);
				require(fake_mem_panic_count == 1 &&
					fake_mem_panic_reason == 4);
				mix(&digest, (unsigned long)fake_mem_panic_reason);
			}

			reset_fake_load_page_table();
			{
				void *init_pt = NULL;
				void *boot_pt = NULL;
				int loaded = 0;
				int fake_lock = 0;

				require(x86_init_page_table_body_result(&init_pt,
					&boot_pt, &loaded, &fake_lock, 64, 1,
					fake_init_page_check,
					fake_init_page_alloc,
					fake_init_page_spin_init,
					fake_init_page_normal,
					fake_init_page_linux,
					fake_init_page_fixed,
					fake_init_page_text,
					fake_init_page_vsyscall,
					fake_init_page_low_noop,
					fake_init_page_load,
					fake_init_page_log,
					fake_mem_panic) == -22);
				require(fake_mem_panic_count == 1 &&
					fake_mem_panic_reason == 5);
				require(loaded == 0 &&
					fake_init_page_loaded_calls == 0);
				mix(&digest, (unsigned long)fake_mem_panic_reason);
			}

			reset_fake_load_page_table();
			x86_flush_tlb_body_result(fake_read_cr3, fake_load_cr3);
			require(fake_read_cr3_calls == 1);
			require(fake_load_cr3_calls == 1);
			require(fake_load_cr3_addr == 0xabcde000UL);
			mix(&digest, fake_load_digest);

			reset_fake_load_page_table();
			x86_flush_tlb_body_result(NULL, fake_load_cr3);
			x86_flush_tlb_body_result(fake_read_cr3, NULL);
			require(fake_read_cr3_calls == 0);
			require(fake_load_cr3_calls == 0);
			mix(&digest, fake_load_digest);

			reset_fake_load_page_table();
			x86_flush_tlb_single_body_result(0x12345000UL,
				fake_invlpg);
			require(fake_invlpg_calls == 1);
			require(fake_invlpg_addr == 0x12345000UL);
			mix(&digest, fake_load_digest);

			reset_fake_load_page_table();
			x86_flush_tlb_single_body_result(0x12345000UL, NULL);
			require(fake_invlpg_calls == 0);
			mix(&digest, fake_load_digest);
		}
		{
			reset_fake_load_page_table();
			require(x86_load_page_table_body_result(
				&fake_created_tables[1], &fake_created_tables[0],
				fake_pt_virt_to_phys, fake_load_cr3) == 0);
			require(fake_load_cr3_calls == 1);
			require(fake_load_cr3_addr ==
				fake_pt_virt_to_phys(&fake_created_tables[1]));
			mix(&digest, fake_load_digest);

			reset_fake_load_page_table();
			require(x86_load_page_table_body_result(
				NULL, &fake_created_tables[0],
				fake_pt_virt_to_phys, fake_load_cr3) == 0);
			require(fake_load_cr3_calls == 1);
			require(fake_load_cr3_addr ==
				fake_pt_virt_to_phys(&fake_created_tables[0]));
			mix(&digest, fake_load_digest);

			reset_fake_load_page_table();
			require(x86_load_page_table_body_result(
				NULL, NULL, fake_pt_virt_to_phys,
				fake_load_cr3) == -22);
			require(fake_load_cr3_calls == 0);
			require(x86_load_page_table_body_result(
				&fake_created_tables[1], &fake_created_tables[0],
				NULL, fake_load_cr3) == -22);
			require(x86_load_page_table_body_result(
				&fake_created_tables[1], &fake_created_tables[0],
				fake_pt_virt_to_phys, NULL) == -22);
			mix(&digest, fake_load_digest);
		}
		{
			unsigned long fixed;
			void *ret;

			reset_fake_fixed_area();
			fixed = 0x10000000UL;
			ret = x86_map_fixed_area_body_result((void *)0x1111UL,
				&fixed, 0x12345UL, 8192, 1,
				fake_fixed_set_page, fake_fixed_flush);
			require(ret == (void *)0x10000345UL);
			require(fixed == 0x10003000UL);
			require(fake_fixed_set_calls == 3);
			require(fake_fixed_flush_calls == 1);
			require(fake_fixed_virt[0] == 0x10000000UL);
			require(fake_fixed_virt[1] == 0x10001000UL);
			require(fake_fixed_virt[2] == 0x10002000UL);
			require(fake_fixed_phys[0] == 0x12000UL);
			require(fake_fixed_phys[1] == 0x13000UL);
			require(fake_fixed_phys[2] == 0x14000UL);
			require(fake_fixed_attr[0] ==
				(PTATTR_WRITABLE | PTATTR_ACTIVE |
				PTATTR_UNCACHABLE));
			mix(&digest, fake_fixed_digest);

			reset_fake_fixed_area();
			fixed = 0x20000000UL;
			ret = x86_map_fixed_area_body_result((void *)0x1111UL,
				&fixed, 0x20000UL, 4096, 0,
				fake_fixed_set_page, fake_fixed_flush);
			require(ret == (void *)0x20000000UL);
			require(fixed == 0x20001000UL);
			require(fake_fixed_set_calls == 1);
			require(fake_fixed_attr[0] ==
				(PTATTR_WRITABLE | PTATTR_ACTIVE));
			require(fake_fixed_flush_calls == 1);
			mix(&digest, fake_fixed_digest);

			reset_fake_fixed_area();
			fixed = 0x30000000UL;
			fake_fixed_set_fail_after = 2;
			ret = x86_map_fixed_area_body_result((void *)0x1111UL,
				&fixed, 0x12345UL, 8192, 1,
				fake_fixed_set_page, fake_fixed_flush);
			require(ret == NULL);
			require(fixed == 0x30000000UL);
			require(fake_fixed_set_calls == 2);
			require(fake_fixed_flush_calls == 0);
			mix(&digest, fake_fixed_digest);

			fixed = 0x40000000UL;
			require(x86_map_fixed_area_body_result(NULL, &fixed,
				0x1000UL, 4096, 0, fake_fixed_set_page,
				fake_fixed_flush) == NULL);
			require(x86_map_fixed_area_body_result((void *)0x1111UL,
				NULL, 0x1000UL, 4096, 0,
				fake_fixed_set_page, fake_fixed_flush) == NULL);
			require(x86_map_fixed_area_body_result((void *)0x1111UL,
				&fixed, 0x1000UL, 4096, 0, NULL,
				fake_fixed_flush) == NULL);
			require(x86_map_fixed_area_body_result((void *)0x1111UL,
				&fixed, 0x1000UL, 4096, 0,
				fake_fixed_set_page, NULL) == NULL);
			mix(&digest, 0x6669786e756cUL);
		}
		{
			reset_fake_init_normal_area();
			fake_init_normal_map_start = 0x200000UL;
			fake_init_normal_map_end = 0x800000UL;
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff800000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large,
				fake_init_normal_log) == 0);
			require(fake_init_normal_get_calls == 2);
			require(fake_init_normal_set_calls == 3);
			require(fake_init_normal_log_calls == 1);
			require(fake_init_normal_fail_log_calls == 0);
			require(fake_init_normal_virt[0] ==
				0xffff800000200000UL);
			require(fake_init_normal_virt[1] ==
				0xffff800000400000UL);
			require(fake_init_normal_virt[2] ==
				0xffff800000600000UL);
			require(fake_init_normal_phys[0] == 0x200000UL);
			require(fake_init_normal_phys[1] == 0x400000UL);
			require(fake_init_normal_phys[2] == 0x600000UL);
			require(fake_init_normal_attr[0] == PTATTR_WRITABLE);
			mix(&digest, fake_init_normal_digest);

			reset_fake_init_normal_area();
			fake_init_normal_map_start = 0;
			fake_init_normal_map_end = 0x600000UL;
			fake_init_normal_set_fail_after = 2;
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large,
				fake_init_normal_log) == 0);
			require(fake_init_normal_set_calls == 3);
			require(fake_init_normal_log_calls == 2);
			require(fake_init_normal_fail_log_calls == 1);
			require(fake_init_normal_virt[2] ==
				0xffff900000400000UL);
			mix(&digest, fake_init_normal_digest);

			reset_fake_init_normal_area();
			fake_init_normal_map_start = 0x800000UL;
			fake_init_normal_map_end = 0x800000UL;
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large,
				fake_init_normal_log) == 0);
			require(fake_init_normal_set_calls == 0);
			require(fake_init_normal_log_calls == 1);
			mix(&digest, fake_init_normal_digest);

			require(x86_init_normal_area_body_result(
				NULL, 0xffff900000000000UL, PTL2_SIZE,
				PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large,
				fake_init_normal_log) == -22);
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL, 0,
				PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large,
				fake_init_normal_log) == -22);
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12, NULL,
				fake_init_normal_set_large,
				fake_init_normal_log) == -22);
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr, NULL,
				fake_init_normal_log) == -22);
			require(x86_init_normal_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 11, 12,
				fake_init_normal_get_addr,
				fake_init_normal_set_large, NULL) == -22);
			mix(&digest, 0x696e69746e756cUL);
		}
		{
			reset_fake_init_text_area();
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff800000000000UL,
				0xffff800000601234UL, PTL2_SIZE,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x400000UL, PTATTR_WRITABLE,
				fake_init_text_set_large,
				fake_init_text_log) == 0);
			require(fake_init_text_nlpages == 5);
			require(fake_init_text_base == 0x400000UL);
			require(fake_init_text_log_calls == 2);
			require(fake_init_text_set_calls == 5);
			require(fake_init_text_virt[0] ==
				0xffff800000000000UL);
			require(fake_init_text_virt[4] ==
				0xffff800000800000UL);
			require(fake_init_text_phys[0] == 0x400000UL);
			require(fake_init_text_phys[4] == 0xc00000UL);
			require(fake_init_text_attr[0] == PTATTR_WRITABLE);
			mix(&digest, fake_init_text_digest);

			reset_fake_init_text_area();
			fake_init_text_set_fail_after = 2;
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				0xffff900000201000UL, PTL2_SIZE,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE,
				fake_init_text_set_large,
				fake_init_text_log) == 0);
			require(fake_init_text_nlpages == 3);
			require(fake_init_text_set_calls == 3);
			require(fake_init_text_virt[2] ==
				0xffff900000400000UL);
			mix(&digest, fake_init_text_digest);

			require(x86_init_text_area_body_result(
				NULL, 0xffff900000000000UL,
				0xffff900000201000UL, PTL2_SIZE,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE,
				fake_init_text_set_large,
				fake_init_text_log) == -22);
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				0xffff900000201000UL, 0,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE,
				fake_init_text_set_large,
				fake_init_text_log) == -22);
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				0xffff900000201000UL, PTL2_SIZE,
				-1, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE,
				fake_init_text_set_large,
				fake_init_text_log) == -22);
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				0xffff900000201000UL, PTL2_SIZE,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE, NULL,
				fake_init_text_log) == -22);
			require(x86_init_text_area_body_result(
				(void *)0x1111UL, 0xffff900000000000UL,
				0xffff900000201000UL, PTL2_SIZE,
				PTL2_SHIFT, ~(PTL2_SIZE - 1),
				0x800000UL, PTATTR_WRITABLE,
				fake_init_text_set_large, NULL) == -22);
			mix(&digest, 0x746578746e756cUL);
		}
		{
			unsigned long fixed = 0;

			require(x86_init_fixed_area_body_result(
				&fixed, 0xffffa00000000000UL) == 0);
			require(fixed == 0xffffa00000000000UL);
			require(x86_init_fixed_area_body_result(
				NULL, 0xffffa00000000000UL) == -22);
			mix(&digest, fixed);

			reset_fake_init_text_area();
			require(x86_init_low_area_body_result(
				(void *)0x1111UL, PTATTR_NO_EXECUTE,
				PTATTR_WRITABLE, fake_init_text_set_large) == 0);
			require(fake_init_text_set_calls == 1);
			require(fake_init_text_virt[0] == 0);
			require(fake_init_text_phys[0] == 0);
			require(fake_init_text_attr[0] ==
				(PTATTR_NO_EXECUTE | PTATTR_WRITABLE));
			mix(&digest, fake_init_text_digest);

			reset_fake_init_text_area();
			fake_init_text_set_fail_after = 1;
			require(x86_init_low_area_body_result(
				(void *)0x1111UL, PTATTR_NO_EXECUTE,
				PTATTR_WRITABLE, fake_init_text_set_large) == 0);
			require(fake_init_text_set_calls == 1);
			require(x86_init_low_area_body_result(
				NULL, PTATTR_NO_EXECUTE, PTATTR_WRITABLE,
				fake_init_text_set_large) == -22);
			require(x86_init_low_area_body_result(
				(void *)0x1111UL, PTATTR_NO_EXECUTE,
				PTATTR_WRITABLE, NULL) == -22);
			mix(&digest, fake_init_text_digest);
		}
		{
			reset_fake_fixed_area();
			require(x86_init_vsyscall_area_body_result(
				(void *)0x1111UL, 0xffffffffff600000UL,
				&fake_created_tables[2],
				PTATTR_ACTIVE | PTATTR_USER,
				fake_pt_virt_to_phys,
				fake_fixed_set_page) == 0);
			require(fake_fixed_set_calls == 1);
			require(fake_fixed_virt[0] == 0xffffffffff600000UL);
			require(fake_fixed_phys[0] ==
				fake_pt_virt_to_phys(&fake_created_tables[2]));
			require(fake_fixed_attr[0] ==
				(PTATTR_ACTIVE | PTATTR_USER));
			mix(&digest, fake_fixed_digest);

			reset_fake_fixed_area();
			fake_fixed_set_fail_after = 1;
			require(x86_init_vsyscall_area_body_result(
				(void *)0x1111UL, 0xffffffffff600000UL,
				&fake_created_tables[2],
				PTATTR_ACTIVE | PTATTR_USER,
				fake_pt_virt_to_phys,
				fake_fixed_set_page) == -5);
			require(fake_fixed_set_calls == 1);
			mix(&digest, fake_fixed_digest);

			require(x86_init_vsyscall_area_body_result(
				NULL, 0xffffffffff600000UL,
				&fake_created_tables[2],
				PTATTR_ACTIVE | PTATTR_USER,
				fake_pt_virt_to_phys,
				fake_fixed_set_page) == -22);
			require(x86_init_vsyscall_area_body_result(
				(void *)0x1111UL, 0xffffffffff600000UL,
				NULL, PTATTR_ACTIVE | PTATTR_USER,
				fake_pt_virt_to_phys,
				fake_fixed_set_page) == -22);
			require(x86_init_vsyscall_area_body_result(
				(void *)0x1111UL, 0xffffffffff600000UL,
				&fake_created_tables[2],
				PTATTR_ACTIVE | PTATTR_USER, NULL,
				fake_fixed_set_page) == -22);
			require(x86_init_vsyscall_area_body_result(
				(void *)0x1111UL, 0xffffffffff600000UL,
				&fake_created_tables[2],
				PTATTR_ACTIVE | PTATTR_USER,
				fake_pt_virt_to_phys, NULL) == -22);
			mix(&digest, 0x767379736e756cUL);
		}
		{
			char safe_name[] = "safe_kernel_map";

			reset_fake_init_linux_mapping();
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == 0);
			require(fake_init_linux_find_calls == 1);
			require(fake_init_linux_get_nr_calls == 0);
			require(fake_init_linux_set_calls == 3);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_FULL] == 1);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_FULL_RANGE] == 1);
			require(fake_init_linux_virt[0] ==
				0xffff880000000000UL);
			require(fake_init_linux_virt[2] ==
				0xffff880000400000UL);
			require(fake_init_linux_phys[2] == 0x400000UL);
			require(fake_init_linux_attr[0] == PTATTR_WRITABLE);
			mix(&digest, fake_init_linux_digest);

			reset_fake_init_linux_mapping();
			fake_init_linux_set_fail_after = 2;
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == 0);
			require(fake_init_linux_set_calls == 3);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_FULL_SET_FAILED] == 1);
			mix(&digest, fake_init_linux_digest);

			reset_fake_init_linux_mapping();
			fake_init_linux_safe_present = 1;
			fake_init_linux_nr_chunks = 2;
			fake_init_linux_chunk_start[0] = 0x200000UL;
			fake_init_linux_chunk_end[0] = 0x600000UL;
			fake_init_linux_chunk_start[1] = 0x1000000UL;
			fake_init_linux_chunk_end[1] = 0x1200000UL;
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == 0);
			require(fake_init_linux_get_nr_calls == 1);
			require(fake_init_linux_get_chunk_calls == 2);
			require(fake_init_linux_set_calls == 3);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_CHUNKS] == 1);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_CHUNK_RANGE] == 2);
			require(fake_init_linux_virt[0] ==
				0xffff880000200000UL);
			require(fake_init_linux_virt[2] ==
				0xffff880001000000UL);
			require(fake_init_linux_phys[2] == 0x1000000UL);
			mix(&digest, fake_init_linux_digest);

			reset_fake_init_linux_mapping();
			fake_init_linux_safe_present = 1;
			fake_init_linux_nr_chunks = 0;
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == 0);
			require(fake_init_linux_set_calls == 0);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_NO_CHUNK] == 1);
			mix(&digest, fake_init_linux_digest);

			reset_fake_init_linux_mapping();
			fake_init_linux_safe_present = 1;
			fake_init_linux_nr_chunks = 2;
			fake_init_linux_bad_chunk_id = 1;
			fake_init_linux_chunk_start[0] = 0;
			fake_init_linux_chunk_end[0] = 0x200000UL;
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == 0);
			require(fake_init_linux_set_calls == 1);
			require(fake_init_linux_log_event_counts[
				X86_INIT_LINUX_LOG_BAD_CHUNK] == 1);
			mix(&digest, fake_init_linux_digest);

			require(x86_init_linux_kernel_mapping_body_result(
				NULL, 0xffff880000000000UL, PTL2_SIZE,
				PTATTR_WRITABLE, 0x600000UL, safe_name,
				fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL, 0,
				PTATTR_WRITABLE, 0x600000UL, safe_name,
				fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL, NULL,
				fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, NULL, fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				NULL, fake_init_linux_get_chunk,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks, NULL,
				fake_init_linux_set_large,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk, NULL,
				fake_init_linux_log) == -22);
			require(x86_init_linux_kernel_mapping_body_result(
				(void *)0x1111UL, 0xffff880000000000UL,
				PTL2_SIZE, PTATTR_WRITABLE, 0x600000UL,
				safe_name, fake_init_linux_find_command_line,
				fake_init_linux_get_nr_chunks,
				fake_init_linux_get_chunk,
				fake_init_linux_set_large, NULL) == -22);
			mix(&digest, 0x6c696e756e756cUL);
		}
		{
			unsigned long map_st = 0xffff800000000000UL;
			unsigned long map_fixed = 0xffff860000000000UL;
			unsigned long linux_base = 0xffff880000000000UL;
			unsigned long kernel_base = 0xffffffff80000000UL;
			unsigned long kernel_phys = 0x400000UL;
			unsigned long pa;

			reset_fake_addr_log();
			pa = x86_virt_to_phys_body_result(
				kernel_base + 0x12345UL, kernel_base,
				kernel_phys, linux_base, map_fixed, map_st,
				fake_addr_log);
			require(pa == kernel_phys + 0x12345UL);
			pa = x86_virt_to_phys_body_result(
				linux_base + 0x22000UL, kernel_base,
				kernel_phys, linux_base, map_fixed, map_st,
				fake_addr_log);
			require(pa == 0x22000UL);
			pa = x86_virt_to_phys_body_result(
				map_fixed + 0x3000UL, kernel_base,
				kernel_phys, linux_base, map_fixed, map_st,
				fake_addr_log);
			require(pa == 0x3000UL);
			pa = x86_virt_to_phys_body_result(
				map_st + 0x5000UL, kernel_base, kernel_phys,
				linux_base, map_fixed, map_st, fake_addr_log);
			require(pa == 0x5000UL);
			require(fake_addr_log_calls == 2);
			require(fake_addr_log_kernel_calls == 1);
			require(fake_addr_log_straight_calls == 1);
			mix(&digest, fake_addr_log_digest);

			pa = x86_virt_to_phys_body_result(
				map_st + 0x9000UL, kernel_base, kernel_phys,
				linux_base, map_fixed, map_st, NULL);
			require(pa == 0x9000UL);
			require(x86_phys_to_virt_body_result(0x7000UL, 0,
				map_st, linux_base) == (void *)(map_st + 0x7000UL));
			require(x86_phys_to_virt_body_result(0x7000UL, 1,
				map_st, linux_base) ==
				(void *)(linux_base + 0x7000UL));
			mix(&digest, 0x616464726e756cUL);
		}
		{
			reset_fake_reserve_arch_pages();
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL,
				(void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, fake_reserve_cb,
				fake_reserve_arch) == 0);
			require(fake_reserve_cb_calls == 3);
			require(fake_reserve_cb_pa[0] == (void *)0x1111UL);
			require(fake_reserve_cb_pa[1] == (void *)0x1111UL);
			require(fake_reserve_cb_pa[2] == (void *)0x1111UL);
			require(fake_reserve_cb_start[0] == 0x1000UL);
			require(fake_reserve_cb_end[0] == 0x9000UL);
			require(fake_reserve_cb_start[1] == 0x8000UL);
			require(fake_reserve_cb_end[1] == 0x9000UL);
			require(fake_reserve_cb_start[2] == 0);
			require(fake_reserve_cb_end[2] == PAGE_SIZE);
			require(fake_reserve_cb_flag[0] == 0);
			require(fake_reserve_cb_flag[1] == 0);
			require(fake_reserve_cb_flag[2] == 0);
			require(fake_reserve_arch_calls == 1);
			require(fake_reserve_arch_start == 0x300000UL);
			require(fake_reserve_arch_end == 0x700000UL);
			require(fake_reserve_arch_cb == fake_reserve_cb);
			mix(&digest, (unsigned int)fake_reserve_cb_calls);
			for (int i = 0; i < fake_reserve_cb_calls; i++) {
				mix(&digest, fake_reserve_cb_pa[i] ==
					(void *)0x1111UL);
				mix(&digest, fake_reserve_cb_start[i]);
				mix(&digest, fake_reserve_cb_end[i]);
				mix(&digest, (unsigned int)fake_reserve_cb_flag[i]);
			}
			mix(&digest, (unsigned int)fake_reserve_arch_calls);
			mix(&digest, fake_reserve_arch_start);
			mix(&digest, fake_reserve_arch_end);

			require(x86_reserve_arch_pages_body_result(
				NULL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL,
				(void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, fake_reserve_cb,
				fake_reserve_arch) == -22);
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				NULL, (void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, fake_reserve_cb,
				fake_reserve_arch) == -22);
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL, NULL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, fake_reserve_cb,
				fake_reserve_arch) == -22);
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL,
				(void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE, NULL,
				fake_reserve_cb, fake_reserve_arch) == -22);
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL,
				(void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, NULL,
				fake_reserve_arch) == -22);
			require(x86_reserve_arch_pages_body_result(
				(void *)0x1111UL, 0x300000UL, 0x700000UL,
				(void *)0xffff800000001000UL,
				(void *)0xffff800000009000UL,
				0x8000UL, 0x1000UL, PAGE_SIZE,
				fake_reserve_virt_to_phys, fake_reserve_cb,
				NULL) == -22);
			mix(&digest, 0x7265736e756cUL);
		}

		{
			unsigned long destroy_entries[] = {
				0,
				PF_PRESENT,
				PF_PRESENT | PF_SIZE,
				0x12345000UL | PF_PRESENT | PTATTR_WRITABLE |
					PTATTR_USER,
				0x12345000UL | PF_PRESENT | PF_SIZE |
					PTATTR_USER,
			};

			for (int level = 0; level <= 5; level++) {
				for (unsigned int e = 0;
						e < sizeof(destroy_entries) /
							sizeof(destroy_entries[0]);
						e++) {
					unsigned long lower = 0xfeedfaceUL;
					int action = x86_destroy_pt_entry_action_result(
						level, destroy_entries[e], &lower);

					mix(&digest, (unsigned int)action);
					mix(&digest, lower);
				}
			}

			{
				unsigned long lower = 0xfeedfaceUL;
				int action = x86_destroy_pt_entry_action_result(
					4, 0x12345000UL | PF_PRESENT,
					&lower);

				require(action == 1);
				require(lower == (0x12345000UL & PT_PHYSMASK));
				mix(&digest, (unsigned int)action);
				mix(&digest, lower);
				require(x86_destroy_pt_entry_action_result(
					4, 0x12345000UL | PF_PRESENT, NULL) ==
					1);
			}

			reset_fake_pt_destroy_table();
			fake_created_tables[0].entry[0] =
				fake_pt_destroy_phys(&fake_created_tables[1]) |
				PF_PRESENT;
			fake_created_tables[0].entry[1] =
				fake_pt_destroy_phys(&fake_created_tables[2]) |
				PF_PRESENT | PF_SIZE;
			fake_created_tables[0].entry[2] =
				fake_pt_destroy_phys(&fake_created_tables[3]);
			fake_created_tables[1].entry[7] =
				fake_pt_destroy_phys(&fake_created_tables[3]) |
				PF_PRESENT;
			fake_created_tables[1].entry[8] =
				fake_pt_destroy_phys(&fake_created_tables[2]) |
				PF_PRESENT | PF_SIZE;
			require(x86_pt_destroy_table_result(4,
				&fake_created_tables[0],
				fake_pt_destroy_phys_to_virt,
				fake_pt_destroy_free_pages,
				fake_pt_destroy_panic) == 0);
			require(fake_pt_destroy_table_phys_calls == 2);
			require(fake_pt_destroy_table_free_calls == 3);
			require(fake_pt_destroy_table_free_order[0] ==
				&fake_created_tables[3]);
			require(fake_pt_destroy_table_free_order[1] ==
				&fake_created_tables[1]);
			require(fake_pt_destroy_table_free_order[2] ==
				&fake_created_tables[0]);
			for (int i = 0; i < fake_pt_destroy_table_free_calls; i++) {
				mix(&digest,
					fake_pt_destroy_table_free_order[i] ==
					&fake_created_tables[0]);
				mix(&digest,
					fake_pt_destroy_table_free_order[i] ==
					&fake_created_tables[1]);
				mix(&digest,
					fake_pt_destroy_table_free_order[i] ==
					&fake_created_tables[3]);
				mix(&digest,
					(unsigned int)fake_pt_destroy_table_free_npages[i]);
			}

			reset_fake_pt_destroy_table();
			require(x86_pt_destroy_table_result(1,
				&fake_created_tables[0], NULL,
				fake_pt_destroy_free_pages,
				fake_pt_destroy_panic) == 0);
			require(fake_pt_destroy_table_phys_calls == 0);
			require(fake_pt_destroy_table_free_calls == 1);
			require(fake_pt_destroy_table_free_order[0] ==
				&fake_created_tables[0]);
			mix(&digest, fake_pt_destroy_table_free_calls);

			reset_fake_pt_destroy_table();
			require(x86_pt_destroy_table_result(0,
				&fake_created_tables[0],
				fake_pt_destroy_phys_to_virt,
				fake_pt_destroy_free_pages,
				fake_pt_destroy_panic) == -22);
			require(fake_pt_destroy_table_panic_reason == 1);
			mix(&digest, fake_pt_destroy_table_panic_reason);

			reset_fake_pt_destroy_table();
			require(x86_pt_destroy_table_result(4, NULL,
				fake_pt_destroy_phys_to_virt,
				fake_pt_destroy_free_pages,
				fake_pt_destroy_panic) == -22);
			require(fake_pt_destroy_table_panic_reason == 2);
			mix(&digest, fake_pt_destroy_table_panic_reason);

			reset_fake_pt_destroy_table();
			require(x86_pt_destroy_table_result(4,
				&fake_created_tables[0], NULL,
				fake_pt_destroy_free_pages,
				fake_pt_destroy_panic) == -22);
			require(x86_pt_destroy_table_result(4,
				&fake_created_tables[0],
				fake_pt_destroy_phys_to_virt, NULL,
				fake_pt_destroy_panic) == -22);
		}
		{
			struct fake_page_table init;
			struct fake_page_table *pt;

			for (int i = 0; i < PT_ENTRIES; i++)
				init.entry[i] = 0x80000000UL + (unsigned long)i;

			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			fake_pt_last_ap_flag = -1;
			pt = x86_pt_create_result(&init, 7, fake_pt_alloc_pages);
			require(pt == &fake_created_tables[0]);
			require(fake_pt_alloc_count == 1);
			require(fake_pt_last_ap_flag == 7);
			for (int i = 0; i < PT_ENTRIES / 2; i++) {
				require(pt->entry[i] == 0);
				mix(&digest, pt->entry[i]);
			}
			for (int i = PT_ENTRIES / 2; i < PT_ENTRIES; i++) {
				require(pt->entry[i] == init.entry[i]);
				mix(&digest, pt->entry[i]);
			}

			fake_pt_alloc_fail = 1;
			require(x86_pt_create_result(&init, 8,
				fake_pt_alloc_pages) == NULL);
			require(x86_pt_create_result(&init, 8, NULL) == NULL);
			mix(&digest, (unsigned int)fake_pt_alloc_count);

			for (int i = 0; i < PT_ENTRIES; i++)
				pt->entry[i] = 0x90000000UL + (unsigned long)i;
			fake_pt_destroy_calls = 0;
			fake_pt_destroy_level = -1;
			fake_pt_destroy_ptr = NULL;
			x86_pt_destroy_root_result(pt, fake_pt_destroy);
			require(fake_pt_destroy_calls == 1);
			require(fake_pt_destroy_level == 4);
			require(fake_pt_destroy_ptr == pt);
			for (int i = 0; i < PT_ENTRIES / 2; i++) {
				require(pt->entry[i] == 0x90000000UL +
					(unsigned long)i);
				mix(&digest, pt->entry[i]);
			}
			for (int i = PT_ENTRIES / 2; i < PT_ENTRIES; i++) {
				require(pt->entry[i] == 0);
				mix(&digest, pt->entry[i]);
			}
			x86_pt_destroy_root_result(pt, NULL);
			require(fake_pt_destroy_calls == 1);
			mix(&digest, 0x70746c696665UL);

			if (ihk_mc_pt_create && ihk_mc_pt_destroy) {
				for (int i = 0; i < PT_ENTRIES; i++)
					init.entry[i] = 0xa0000000UL +
						(unsigned long)i;

				x86_rust_stub_init_pt_override = &init;
				fake_pt_alloc_count = 0;
				fake_pt_alloc_fail = 0;
				fake_pt_last_ap_flag = -1;
				pt = ihk_mc_pt_create(12);
				require(pt == &fake_created_tables[0]);
				require(fake_pt_alloc_count == 1);
				require(fake_pt_last_ap_flag == 12);
				for (int i = 0; i < PT_ENTRIES / 2; i++)
					require(pt->entry[i] == 0);
				for (int i = PT_ENTRIES / 2; i < PT_ENTRIES; i++)
					require(pt->entry[i] == init.entry[i]);
				x86_rust_stub_init_pt_override = NULL;

				reset_fake_pt_destroy_table();
				fake_created_tables[0].entry[0] =
					fake_pt_destroy_phys(&fake_created_tables[1]) |
					PF_PRESENT;
				fake_created_tables[0].entry[1] =
					fake_pt_destroy_phys(&fake_created_tables[2]) |
					PF_PRESENT | PF_SIZE;
				fake_created_tables[0].entry[PT_ENTRIES / 2] =
					0xbeef0000UL | PF_PRESENT;
				fake_created_tables[1].entry[7] =
					fake_pt_destroy_phys(&fake_created_tables[3]) |
					PF_PRESENT;
				x86_rust_stub_pt_phys_to_virt_override =
					fake_pt_destroy_phys_to_virt;
				ihk_mc_pt_destroy(&fake_created_tables[0]);
				require(fake_created_tables[0].entry[PT_ENTRIES / 2] == 0);
				require(fake_pt_destroy_table_phys_calls == 2);
				require(fake_pt_destroy_table_free_calls == 3);
				require(fake_pt_destroy_table_free_order[0] ==
					&fake_created_tables[3]);
				require(fake_pt_destroy_table_free_order[1] ==
					&fake_created_tables[1]);
				require(fake_pt_destroy_table_free_order[2] ==
					&fake_created_tables[0]);
				require(fake_pt_destroy_helper_failed_calls == 0);
				x86_rust_stub_pt_phys_to_virt_override = NULL;
				mix(&digest, 0x7074637264657374UL);
			}
		}
		{
			struct fake_page_table root = { 0 };
			struct fake_page_table init = { 0 };
			struct fake_page_table *pt;
			unsigned long *ptep;
			unsigned long virt = 0x123456789000UL;
			unsigned long phys = 0xabcdef123000UL;
			unsigned long attr = PTATTR_ACTIVE | PTATTR_WRITABLE |
				PTATTR_USER | PTATTR_FOR_USER;
			int l4idx, l3idx, l2idx, l1idx;
			int ret;

			require(x86_pt_kernel_lock_needed_result(0xffff000000001000UL) == 1);
			require(x86_pt_kernel_lock_needed_result(0x7fff000000001000UL) == 0);

			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			fake_pt_last_ap_flag = -1;
			pt = x86_pt_alloc_zeroed_result(5, fake_pt_alloc_pages);
			require(pt == &fake_created_tables[0]);
			require(fake_pt_alloc_count == 1);
			require(fake_pt_last_ap_flag == 5);
			for (int i = 0; i < PT_ENTRIES; i++)
				require(pt->entry[i] == 0);
			fake_pt_alloc_fail = 1;
			require(x86_pt_alloc_zeroed_result(6,
				fake_pt_alloc_pages) == NULL);
			require(x86_pt_alloc_zeroed_result(6, NULL) == NULL);
			mix(&digest, (unsigned int)fake_pt_alloc_count);

			x86_pt_indices_result(virt, &l4idx, &l3idx, &l2idx,
				&l1idx);
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			ptep = x86_pt_get_pte_result(&root, &init, virt,
				attr, attr_mask, 9, fake_pt_alloc_pages,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt);
			require(ptep == &fake_created_tables[2].entry[l1idx]);
			require(fake_pt_alloc_count == 3);
			require(fake_pt_last_ap_flag == 9);
			require(root.entry[l4idx] ==
				(fake_pt_destroy_phys(&fake_created_tables[0]) |
				 (attr & attr_mask)));
			require(fake_created_tables[0].entry[l3idx] ==
				(fake_pt_destroy_phys(&fake_created_tables[1]) |
				 (attr & attr_mask)));
			require(fake_created_tables[1].entry[l2idx] ==
				(fake_pt_destroy_phys(&fake_created_tables[2]) |
				 (attr & attr_mask)));
			mix(&digest, (unsigned long)(ptep -
				fake_created_tables[2].entry));
			mix(&digest, root.entry[l4idx]);
			mix(&digest, fake_created_tables[0].entry[l3idx]);
			mix(&digest, fake_created_tables[1].entry[l2idx]);

			memset(&root, 0, sizeof(root));
			memset(fake_created_tables, 0, sizeof(fake_created_tables));
			fake_pt_alloc_count = 0;
			ptep = x86_pt_get_pte_result(&root, &init, virt,
				PTATTR_ACTIVE | PTATTR_USER |
					PTATTR_LARGEPAGE,
				attr_mask, 10, fake_pt_alloc_pages,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt);
			require(ptep == &fake_created_tables[1].entry[l2idx]);
			require(fake_pt_alloc_count == 2);
			mix(&digest, (unsigned long)(ptep -
				fake_created_tables[1].entry));
			require(x86_pt_get_pte_result(NULL, NULL, virt, attr,
				attr_mask, 0, fake_pt_alloc_pages,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt) == NULL);

			memset(&root, 0, sizeof(root));
			memset(fake_created_tables, 0, sizeof(fake_created_tables));
			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			fake_pt_set_page_log_count = 0;
			fake_pt_set_page_log_digest = 0x73657470616765UL;
			ret = x86_pt_set_page_body_result(&root, &init, virt,
				phys, attr, attr_mask, fake_pt_alloc_pages,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log);
			require(ret == 0);
			require(fake_pt_alloc_count == 3);
			require(fake_pt_last_ap_flag == 2);
			require(fake_created_tables[2].entry[l1idx] ==
				((phys & ~(4096UL - 1)) |
				 (attr & attr_mask)));
			ret = x86_pt_set_page_body_result(&root, &init, virt,
				phys, attr, attr_mask, fake_pt_alloc_pages,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log);
			require(ret == 0);
			ret = x86_pt_set_page_body_result(&root, &init, virt,
				phys + 0x3000, attr, attr_mask,
				fake_pt_alloc_pages, fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log);
			require(ret == -16);
			require(fake_pt_set_page_log_count == 1);
			mix(&digest, fake_created_tables[2].entry[l1idx]);
			mix(&digest, fake_pt_set_page_log_digest);

			memset(&root, 0, sizeof(root));
			memset(fake_created_tables, 0, sizeof(fake_created_tables));
			fake_pt_alloc_count = 0;
			attr = PTATTR_ACTIVE | PTATTR_USER |
				PTATTR_LARGEPAGE;
			ret = x86_pt_set_page_body_result(&root, &init, virt,
				phys + 0x12345, attr, attr_mask,
				fake_pt_alloc_pages, fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log);
			require(ret == 0);
			require(fake_pt_alloc_count == 2);
			require(fake_created_tables[1].entry[l2idx] ==
				(((phys + 0x12345) &
				  ~((2UL * 1024 * 1024) - 1)) |
				 (attr & (attr_mask | PTATTR_LARGEPAGE)) |
				 PF_SIZE));
			ret = x86_pt_set_page_body_result(&root, &init, virt,
				phys + (4UL * 1024 * 1024), attr, attr_mask,
				fake_pt_alloc_pages, fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log);
			require(ret == -12);
			require(x86_pt_set_page_body_result(&root, &init, virt,
				phys, attr, attr_mask, NULL,
				fake_pt_destroy_phys,
				fake_pt_destroy_phys_to_virt,
				fake_pt_set_page_log) == 0);
			mix(&digest, fake_created_tables[1].entry[l2idx]);
		}
		{
			struct fake_page_table root = { 0 };
			struct fake_page_table init = { 0 };
			int ret;

			fake_pt_alloc_count = 0;
			fake_pt_alloc_fail = 0;
			ret = x86_pt_prepare_map_result(&root, &init, 0,
				1UL << 39, 0, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				fake_pt_set_page);
			require(ret == 0);
			require(fake_pt_alloc_count == 2);
			require(root.entry[0] ==
				(fake_pt_virt_to_phys(&fake_created_tables[0]) |
				 0x07UL));
			require(root.entry[1] ==
				(fake_pt_virt_to_phys(&fake_created_tables[1]) |
				 0x07UL));
			mix(&digest, root.entry[0]);
			mix(&digest, root.entry[1]);

			root.entry[3] = 0x1007UL;
			fake_pt_alloc_count = 0;
			ret = x86_pt_prepare_map_result(&root, &init,
				3UL << 39, 0, 0, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				fake_pt_set_page);
			require(ret == 0);
			require(fake_pt_alloc_count == 0);
			mix(&digest, root.entry[3]);

			root.entry[4] = 0;
			fake_pt_alloc_fail = 1;
			ret = x86_pt_prepare_map_result(&root, &init,
				4UL << 39, 0, 0, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				fake_pt_set_page);
			require(ret == -12);
			require(root.entry[4] == 0);
			require(x86_pt_prepare_map_result(&root, &init,
				4UL << 39, 0, 0, PTATTR_WRITABLE,
				NULL, fake_pt_virt_to_phys,
				fake_pt_set_page) == -12);
			require(x86_pt_prepare_map_result(&root, &init,
				4UL << 39, 0, 0, PTATTR_WRITABLE,
				fake_pt_alloc_pages, NULL,
				fake_pt_set_page) == -12);
			mix(&digest, 0x70746669727374UL);

			fake_pt_set_page_calls = 0;
			fake_pt_set_page_fail_after = 0;
			fake_pt_set_page_fail_error = 0;
			fake_pt_set_expected_pt = &init;
			fake_pt_set_page_digest = 0x70747365747067UL;
			ret = x86_pt_prepare_map_result(NULL, &init, 0x4000,
				0x3000, 1, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				fake_pt_set_page);
			require(ret == 0);
			require(fake_pt_set_page_calls == 3);
			mix(&digest, fake_pt_set_page_digest);

			fake_pt_set_page_calls = 0;
			fake_pt_set_page_fail_after = 2;
			fake_pt_set_page_fail_error = -7;
			fake_pt_set_expected_pt = &root;
			fake_pt_set_page_digest = 0x70746661696cUL;
			ret = x86_pt_prepare_map_result(&root, &init, 0x8000,
				0x3000, 1, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				fake_pt_set_page);
			require(ret == -7);
			require(fake_pt_set_page_calls == 2);
			require(x86_pt_prepare_map_result(&root, &init,
				0x8000, 0x1000, 1, PTATTR_WRITABLE,
				fake_pt_alloc_pages, fake_pt_virt_to_phys,
				NULL) == -12);
			mix(&digest, fake_pt_set_page_digest);

			if (ihk_mc_pt_prepare_map) {
				memset(&root, 0, sizeof(root));
				memset(&init, 0, sizeof(init));
				memset(fake_created_tables, 0,
					sizeof(fake_created_tables));
				x86_rust_stub_init_pt_override = &init;
				fake_pt_alloc_count = 0;
				fake_pt_alloc_fail = 0;
				ret = ihk_mc_pt_prepare_map(&root, NULL,
					1UL << 39, 0);
				require(ret == 0);
				require(fake_pt_alloc_count == 2);
				require(root.entry[0] ==
					((unsigned long)&fake_created_tables[0] |
						0x07UL));
				require(root.entry[1] ==
					((unsigned long)&fake_created_tables[1] |
						0x07UL));

				x86_rust_stub_pt_set_page_calls = 0;
				x86_rust_stub_pt_set_page_rc = 0;
				ret = ihk_mc_pt_prepare_map(NULL,
					(void *)0x4000UL, 0x3000, 1);
				require(ret == 0);
				require(x86_rust_stub_pt_set_page_calls == 3);
				require(x86_rust_stub_pt_set_page_pt == &init);
				require(x86_rust_stub_pt_set_page_virt ==
					0x6000UL);
				require(x86_rust_stub_pt_set_page_phys == 0);
				require(x86_rust_stub_pt_set_page_attr ==
					PTATTR_WRITABLE);
				x86_rust_stub_init_pt_override = NULL;
				mix(&digest, 0x707265706d6170UL);
			}
		}
		{
			struct fake_page_table pt = { 0 };
			unsigned long slot;
			size_t pgsizes[] = {
				4096, 2UL * 1024 * 1024,
				1024UL * 1024 * 1024, 12345,
			};
			unsigned long phys[] = {
				0x1000, 2UL * 1024 * 1024,
				(2UL * 1024 * 1024) + 0x1000,
				1024UL * 1024 * 1024,
				(1024UL * 1024 * 1024) + 0x1000,
			};

			fake_pt_set_expected_pt = &pt;
			fake_pt_set_pte_log_count = 0;
			fake_pt_set_pte_panic_count = 0;
			fake_pt_set_pte_digest = 0x707465626f6479UL;
			for (unsigned int p = 0;
			     p < sizeof(pgsizes) / sizeof(pgsizes[0]); p++) {
				for (unsigned int h = 0;
				     h < sizeof(phys) / sizeof(phys[0]); h++) {
					for (int use_1gb = 0; use_1gb <= 1;
					     use_1gb++) {
						slot = 0xabcdef00UL | p;
						int error = x86_pt_set_pte_body_result(
							&pt, &slot, pgsizes[p],
							phys[h], attrs[p %
							(sizeof(attrs) /
							 sizeof(attrs[0]))],
							attr_mask, use_1gb,
							fake_pt_set_pte_log,
							fake_pt_set_pte_panic);

						mix(&fake_pt_set_pte_digest,
							pgsizes[p]);
						mix(&fake_pt_set_pte_digest,
							phys[h]);
						mix(&fake_pt_set_pte_digest,
							(unsigned int)use_1gb);
						mix(&fake_pt_set_pte_digest,
							(unsigned int)-error);
						mix(&fake_pt_set_pte_digest, slot);
					}
				}
			}
			require(fake_pt_set_pte_log_count > 0);
			require(fake_pt_set_pte_panic_count > 0);
			slot = 0;
			require(x86_pt_set_pte_body_result(&pt, &slot, 4096,
				0x5000, PTATTR_ACTIVE, attr_mask, 0, NULL,
				NULL) == 0);
			require(slot == (0x5000 | PTATTR_ACTIVE));
			mix(&digest, fake_pt_set_pte_digest);
			mix(&digest, slot);
		}

		for (unsigned int e = 0; e < sizeof(move_entries) / sizeof(move_entries[0]); e++) {
			for (unsigned int p = 0; p < sizeof(move_pgsizes) / sizeof(move_pgsizes[0]); p++) {
				unsigned long phys = 0x12345678UL;
				int fileoff = -1;
				int dirty = -2;

				x86_clear_range_old_entry_result(move_entries[e],
					move_pgsizes[p], &phys, &fileoff,
					&dirty);
				mix(&digest, phys);
				mix(&digest, (unsigned int)fileoff);
				mix(&digest, (unsigned int)dirty);
			}
		}
		for (int fileoff = 0; fileoff <= 1; fileoff++) {
			for (int free_physical = 0; free_physical <= 1; free_physical++) {
				for (int has_page = 0; has_page <= 1; has_page++) {
					for (int in_memobj = 0; in_memobj <= 1; in_memobj++) {
						for (int dirty = 0; dirty <= 1; dirty++) {
							for (int has_memobj = 0; has_memobj <= 1; has_memobj++) {
								for (int no_flush = 0; no_flush <= 1; no_flush++) {
									for (int xpmem = 0; xpmem <= 1; xpmem++) {
										mix(&digest,
											(unsigned int)x86_clear_range_old_action_result(
												fileoff, free_physical,
												has_page, in_memobj,
												dirty, has_memobj,
												no_flush, xpmem));
									}
								}
							}
						}
					}
				}
			}
		}
		{
			unsigned long addrs[2] = { 0 };
			unsigned long slot = 0x12345007UL;
			int nr_addr = 0;
			int ret;

			reset_fake_clear_effects();
			ret = x86_remote_flush_tlb_add_addr_result(
				(void *)0xaaaaUL, addrs, &nr_addr, 2,
				0x1000UL, 9, fake_clear_remote_flush);
			require(ret == 0);
			require(nr_addr == 1);
			require(addrs[0] == 0x1000UL);
			ret = x86_remote_flush_tlb_add_addr_result(
				(void *)0xaaaaUL, addrs, &nr_addr, 2,
				0x2000UL, 9, fake_clear_remote_flush);
			require(ret == 0);
			require(nr_addr == 2);
			ret = x86_remote_flush_tlb_add_addr_result(
				(void *)0xaaaaUL, addrs, &nr_addr, 2,
				0x3000UL, 9, fake_clear_remote_flush);
			require(ret == 1);
			require(fake_clear_remote_flush_calls == 1);
			require(nr_addr == 1);
			require(addrs[0] == 0x3000UL);
			mix(&digest, fake_clear_digest);
			require(x86_remote_flush_tlb_add_addr_result(
				(void *)0xaaaaUL, addrs, &nr_addr, 0,
				0x4000UL, 9, fake_clear_remote_flush) == -22);

			reset_fake_clear_effects();
			ret = x86_clear_range_old_effects_result(
				X86_CLEAR_OLD_FLUSH_MEMOBJ |
					X86_CLEAR_OLD_FREE_ANON,
				0, 1, (void *)0xbbbbUL, NULL, 0x5000UL,
				0x6000UL, 4096, fake_clear_flush_memobj,
				fake_clear_phys_to_virt, fake_clear_free_pages,
				fake_clear_page_unmap, fake_clear_rss_sub,
				fake_clear_memobj_rss_sub,
				fake_clear_effect_log);
			require(ret == 0);
			require(fake_clear_flush_calls == 1);
			require(fake_clear_free_calls == 1);
			require(fake_clear_rss_calls == 1);
			require(fake_clear_log_calls == 2);
			mix(&digest, fake_clear_digest);

			reset_fake_clear_effects();
			ret = x86_clear_range_old_effects_result(
				X86_CLEAR_OLD_XPMEM_KEEP, 0, 1,
				(void *)0xbbbbUL, NULL, 0x7000UL,
				0x8000UL, 2UL * 1024 * 1024,
				fake_clear_flush_memobj, fake_clear_phys_to_virt,
				fake_clear_free_pages, fake_clear_page_unmap,
				fake_clear_rss_sub, fake_clear_memobj_rss_sub,
				fake_clear_effect_log);
			require(ret == 0);
			require(fake_clear_free_calls == 0);
			require(fake_clear_log_calls == 1);
			mix(&digest, fake_clear_digest);

			reset_fake_clear_effects();
			fake_clear_unmap_result = 0;
			ret = x86_clear_range_old_effects_result(
				X86_CLEAR_OLD_TRY_UNMAP, 0, 1,
				(void *)0xbbbbUL, (void *)0xccccUL,
				0x9000UL, 0xa000UL, 4096,
				fake_clear_flush_memobj, fake_clear_phys_to_virt,
				fake_clear_free_pages, fake_clear_page_unmap,
				fake_clear_rss_sub, fake_clear_memobj_rss_sub,
				fake_clear_effect_log);
			require(ret == 0);
			require(fake_clear_unmap_calls == 1);
			require(fake_clear_free_calls == 0);
			fake_clear_unmap_result = 1;
			ret = x86_clear_range_old_effects_result(
				X86_CLEAR_OLD_TRY_UNMAP, 0, 1,
				(void *)0xbbbbUL, (void *)0xccccUL,
				0xb000UL, 0xc000UL, 4096,
				fake_clear_flush_memobj, fake_clear_phys_to_virt,
				fake_clear_free_pages, fake_clear_page_unmap,
				fake_clear_rss_sub, fake_clear_memobj_rss_sub,
				fake_clear_effect_log);
			require(ret == 0);
			require(fake_clear_free_calls == 1);
			require(fake_clear_memobj_rss_calls == 1);
			mix(&digest, fake_clear_digest);
			require(x86_clear_range_old_effects_result(
				X86_CLEAR_OLD_FREE_ANON, 0, 1,
				(void *)0xbbbbUL, NULL, 0xd000UL,
				0xe000UL, 4096, fake_clear_flush_memobj,
				fake_clear_phys_to_virt, NULL,
				fake_clear_page_unmap, fake_clear_rss_sub,
				fake_clear_memobj_rss_sub,
				fake_clear_effect_log) == -22);

			reset_fake_clear_effects();
			nr_addr = 0;
			ret = x86_clear_range_child_table_result(&slot,
				(void *)0xddddUL, 0x1000UL, 0x1000UL,
				0x3000UL, 0x2000UL, 1,
				(void *)0xaaaaUL, addrs, &nr_addr, 2, 11,
				fake_clear_remote_flush, fake_clear_free_pages,
				fake_clear_effect_log);
			require(ret == 1);
			require(slot == 0);
			require(nr_addr == 1);
			require(addrs[0] == 0x1000UL);
			require(fake_clear_free_calls == 1);
			require(fake_clear_log_calls == 1);
			mix(&digest, fake_clear_digest);

			slot = 0x7777UL;
			ret = x86_clear_range_child_table_result(&slot,
				(void *)0xddddUL, 0x1800UL, 0x1000UL,
				0x2800UL, 0x2000UL, 1,
				(void *)0xaaaaUL, addrs, &nr_addr, 2, 11,
				fake_clear_remote_flush, fake_clear_free_pages,
				fake_clear_effect_log);
			require(ret == 0);
			require(slot == 0x7777UL);
				require(x86_clear_range_child_table_result(&slot,
					(void *)0xddddUL, 0x1000UL, 0x1000UL,
					0x3000UL, 0x2000UL, 1,
					(void *)0xaaaaUL, addrs, &nr_addr, 2, 11,
					fake_clear_remote_flush, NULL,
					fake_clear_effect_log) == -22);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0;
				ret = x86_clear_range_leaf_body_result(
					(void *)0xc1eaUL, &slot, 0x1000UL,
					0x1000UL, 0x2000UL, (void *)0xaaaaUL,
					addrs, &nr_addr, 2, 11, 1,
					(void *)0xbbbbUL, fake_clear_old_action,
					fake_clear_remote_flush,
					fake_clear_flush_memobj,
					fake_clear_phys_to_virt,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_effect_log);
				require(ret == -2);
				require(fake_clear_old_action_calls == 0);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0x5007UL;
				fake_clear_old_action_result =
					X86_CLEAR_OLD_FREE_ANON;
				fake_clear_old_action_phys = 0x5000UL;
				ret = x86_clear_range_leaf_body_result(
					(void *)0xc1eaUL, &slot, 0x3000UL,
					0x3000UL, 0x4000UL, (void *)0xaaaaUL,
					addrs, &nr_addr, 2, 11, 1,
					(void *)0xbbbbUL, fake_clear_old_action,
					fake_clear_remote_flush,
					fake_clear_flush_memobj,
					fake_clear_phys_to_virt,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_effect_log);
				require(ret == 0);
				require(slot == 0);
				require(nr_addr == 1);
				require(addrs[0] == 0x3000UL);
				require(fake_clear_old_action_calls == 1);
				require(fake_clear_free_calls == 1);
				require(fake_clear_rss_calls == 1);
				mix(&digest, fake_clear_digest);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0x200000UL | PTATTR_LARGEPAGE | 0x7UL;
				ret = x86_clear_range_level_body_result(
					(void *)0xc1eaUL, &slot, 0x200000UL,
					0x201000UL, 0x400000UL, PTL2_SHIFT,
					0x200000UL, PTATTR_LARGEPAGE, 1,
					(void *)0xaaaaUL, addrs, &nr_addr, 2,
					11, 1, (void *)0xbbbbUL,
					fake_clear_old_action,
					fake_clear_phys_to_virt,
					fake_clear_child_walk,
					fake_clear_remote_flush,
					fake_clear_free_pages,
					fake_clear_flush_memobj,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_range_log,
					fake_clear_effect_log);
				require(ret == -22);
				require(fake_clear_range_log_calls == 1);
				require(fake_clear_range_log_event ==
					X86_CLEAR_RANGE_LOG_SPLIT);
				require(slot != 0);
				mix(&digest, fake_clear_digest);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0x40000000UL | PTATTR_LARGEPAGE | 0x7UL;
				ret = x86_clear_range_level_body_result(
					(void *)0xc1eaUL, &slot, 0x40000000UL,
					0x40000000UL, 0x80000000UL, PTL3_SHIFT,
					0x40000000UL, PTATTR_LARGEPAGE, 1,
					(void *)0xaaaaUL, addrs, &nr_addr, 2,
					11, 1, (void *)0xbbbbUL,
					fake_clear_old_action,
					fake_clear_phys_to_virt,
					fake_clear_child_walk,
					fake_clear_remote_flush,
					fake_clear_free_pages,
					fake_clear_flush_memobj,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_range_log,
					fake_clear_effect_log);
				require(ret == 0);
				require(slot == 0);
				require(fake_clear_old_action_calls == 1);
				require(fake_clear_range_log_event ==
					X86_CLEAR_RANGE_LOG_LARGE_PHYS);
				mix(&digest, fake_clear_digest);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0x800000UL | 0x7UL;
				fake_clear_child_walk_result = -2;
				ret = x86_clear_range_level_body_result(
					(void *)0xc1eaUL, &slot, 0x800000UL,
					0x800000UL, 0xa00000UL, PTL2_SHIFT,
					0x200000UL, PTATTR_LARGEPAGE, 1,
					(void *)0xaaaaUL, addrs, &nr_addr, 2,
					11, 1, (void *)0xbbbbUL,
					fake_clear_old_action,
					fake_clear_phys_to_virt,
					fake_clear_child_walk,
					fake_clear_remote_flush,
					fake_clear_free_pages,
					fake_clear_flush_memobj,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_range_log,
					fake_clear_effect_log);
				require(ret == 0);
				require(slot == 0);
				require(fake_clear_child_walk_calls == 1);
				require(fake_clear_free_calls == 1);
				require(fake_clear_log_calls == 1);
				mix(&digest, fake_clear_digest);

				reset_fake_clear_effects();
				nr_addr = 0;
				slot = 0xc00000UL | 0x7UL;
				fake_clear_child_walk_result = -5;
				ret = x86_clear_range_level_body_result(
					(void *)0xc1eaUL, &slot, 0xc00000UL,
					0xc00000UL, 0xe00000UL, PTL2_SHIFT,
					0x200000UL, PTATTR_LARGEPAGE, 1,
					(void *)0xaaaaUL, addrs, &nr_addr, 2,
					11, 1, (void *)0xbbbbUL,
					fake_clear_old_action,
					fake_clear_phys_to_virt,
					fake_clear_child_walk,
					fake_clear_remote_flush,
					fake_clear_free_pages,
					fake_clear_flush_memobj,
					fake_clear_free_pages,
					fake_clear_page_unmap,
					fake_clear_rss_sub,
					fake_clear_memobj_rss_sub,
					fake_clear_range_log,
					fake_clear_effect_log);
				require(ret == -5);
				require(slot != 0);
				require(fake_clear_free_calls == 0);

				reset_fake_clear_effects();
				slot = 0;
				require(x86_clear_range_root_body_result(
					(void *)0xc1eaUL, &slot, 0x1000UL,
					0x1000UL, 0x2000UL,
					fake_clear_phys_to_virt,
					fake_clear_child_walk) == -2);
				slot = 0x1000000UL | 0x7UL;
				ret = x86_clear_range_root_body_result(
					(void *)0xc1eaUL, &slot, 0x1000000UL,
					0x1000000UL, 0x1200000UL,
					fake_clear_phys_to_virt,
					fake_clear_child_walk);
				require(ret == 0);
				require(fake_clear_child_walk_calls == 1);
				require(fake_clear_child_walk_last_pt ==
					(void *)(0x1000000UL + 0x100000UL));
				mix(&digest, fake_clear_digest);

				{
					struct fake_clear_top_args top_args;

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_clear_top();
				ret = x86_clear_range_top_result(
					(void *)0x1111UL, (void *)0xaaaaUL,
					0x2000UL, 0x5000UL, 0x1000UL,
					0x8000UL, 1, 0, 0, 0,
					(void *)0xbbbbUL, &top_args.addr,
					&top_args.nr_addr,
					&top_args.max_nr_addr,
					&top_args.free_physical,
					&top_args.memobj, &top_args.vm,
					4, 4096, &top_args,
					fake_clear_top_alloc_pages,
					fake_clear_top_free_pages,
					fake_clear_top_walk,
					fake_clear_remote_flush, 13,
					fake_clear_top_log);
				require(ret == 0);
				require(top_args.addr != NULL);
				require(top_args.free_physical == 1);
				require(top_args.max_nr_addr == 2048);
				require(fake_clear_top_walk_calls == 1);
				require(fake_clear_remote_flush_calls == 1);
				require(fake_clear_top_alloc_count == 1);
				require(fake_clear_top_free_count == 1);
				require(fake_clear_top_free_npages == 4);
				mix(&digest, fake_clear_top_digest);
				mix(&digest, fake_clear_digest);

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_clear_top();
				ret = x86_clear_range_top_result(
					(void *)0x1111UL, (void *)0xaaaaUL,
					0x0UL, 0x5000UL, 0x1000UL,
					0x8000UL, 1, 0, 0, 0,
					(void *)0xbbbbUL, &top_args.addr,
					&top_args.nr_addr,
					&top_args.max_nr_addr,
					&top_args.free_physical,
					&top_args.memobj, &top_args.vm,
					4, 4096, &top_args,
					fake_clear_top_alloc_pages,
					fake_clear_top_free_pages,
					fake_clear_top_walk,
					fake_clear_remote_flush, 13,
					fake_clear_top_log);
				require(ret == -22);
				require(fake_clear_top_alloc_count == 0);
				require(fake_clear_top_log_calls == 1);
				require(fake_clear_top_log_event == 6);
				mix(&digest, fake_clear_top_digest);

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_clear_top();
				fake_clear_top_alloc_fail = 1;
				ret = x86_clear_range_top_result(
					(void *)0x1111UL, (void *)0xaaaaUL,
					0x2000UL, 0x5000UL, 0x1000UL,
					0x8000UL, 1, 0, 0, 0,
					(void *)0xbbbbUL, &top_args.addr,
					&top_args.nr_addr,
					&top_args.max_nr_addr,
					&top_args.free_physical,
					&top_args.memobj, &top_args.vm,
					4, 4096, &top_args,
					fake_clear_top_alloc_pages,
					fake_clear_top_free_pages,
					fake_clear_top_walk,
					fake_clear_remote_flush, 13,
					fake_clear_top_log);
				require(ret == -12);
				require(fake_clear_top_log_calls == 1);
				require(fake_clear_top_log_event == 7);
				mix(&digest, fake_clear_top_digest);

				memset(&top_args, 0, sizeof(top_args));
				reset_fake_clear_top();
				fake_clear_top_walk_result = -5;
				ret = x86_clear_range_top_result(
					(void *)0x1111UL, (void *)0xaaaaUL,
					0x2000UL, 0x5000UL, 0x1000UL,
					0x8000UL, 1, 0, 0, 0,
					(void *)0xbbbbUL, &top_args.addr,
					&top_args.nr_addr,
					&top_args.max_nr_addr,
					&top_args.free_physical,
					&top_args.memobj, &top_args.vm,
					4, 4096, &top_args,
					fake_clear_top_alloc_pages,
					fake_clear_top_free_pages,
					fake_clear_top_walk,
					fake_clear_remote_flush, 13,
					fake_clear_top_log);
				require(ret == -5);
				require(fake_clear_top_walk_calls == 1);
				require(fake_clear_top_free_count == 1);
				mix(&digest, fake_clear_top_digest);
			}
		}

		for (unsigned int s = 0; s < sizeof(sizes) / sizeof(sizes[0]); s++) {
			for (unsigned int e = 0; e < sizeof(sizes) / sizeof(sizes[0]); e++) {
				mix(&digest, (unsigned int)-x86_clear_range_validate_result(
					sizes[s], sizes[e], 0x1000,
					4UL * 1024 * 1024));
			}
		}

		for (int free_physical = 0; free_physical <= 1; free_physical++) {
			for (int dev = 0; dev <= 1; dev++) {
				for (int premap = 0; premap <= 1; premap++) {
					for (int straight = 0; straight <= 1; straight++) {
						mix(&digest,
							(unsigned int)x86_clear_range_free_physical_result(
								free_physical, dev,
								premap, straight));
					}
				}
			}
		}
	}
	{
		size_t pgsizes[] = {
			4096, 2UL * 1024 * 1024, 1024UL * 1024 * 1024,
			12345,
		};
		unsigned long phys[] = {
			0, 4096, 2UL * 1024 * 1024,
			(2UL * 1024 * 1024) + 4096,
			1024UL * 1024 * 1024,
			(1024UL * 1024 * 1024) + 4096,
		};

		for (unsigned int p = 0; p < sizeof(pgsizes) / sizeof(pgsizes[0]); p++) {
			for (unsigned int a = 0; a < sizeof(attrs) / sizeof(attrs[0]); a++) {
				for (unsigned int h = 0; h < sizeof(phys) / sizeof(phys[0]); h++) {
					for (int use_1gb = 0; use_1gb <= 1; use_1gb++) {
						unsigned long entry = 0x12345678UL;
						int error = x86_pt_set_pte_value_result(
							pgsizes[p], phys[h], attrs[a],
							attr_mask, use_1gb, &entry);

						mix(&digest, pgsizes[p]);
						mix(&digest, phys[h]);
						mix(&digest, attrs[a]);
						mix(&digest, use_1gb);
						mix(&digest, (unsigned long)(unsigned int)-error);
						mix(&digest, entry);
					}
				}
			}
		}
		for (unsigned int p = 0; p < sizeof(pgsizes) / sizeof(pgsizes[0]); p++) {
			for (unsigned int a = 0; a < sizeof(attrs) / sizeof(attrs[0]); a++) {
				unsigned long child = 0xaaaaaaaaUL;
				size_t rss_pgsize = 0xbbbbbbbbUL;
				unsigned long step = 0xccccccccUL;
				int error = x86_split_large_page_prepare_result(
					attrs[a], pgsizes[p], &child,
					&rss_pgsize, &step);

				mix(&digest, (unsigned long)(unsigned int)-error);
				mix(&digest, child);
				mix(&digest, rss_pgsize);
				mix(&digest, step);
				mix(&digest, x86_split_large_page_next_entry_result(
					attrs[a], pgsizes[p]));
				{
					unsigned long phys_base = 0x11111111UL;
					unsigned long source_child = 0x22222222UL;
					size_t source_rss = 0x33333333UL;
					unsigned long map_phys = 0x44444444UL;
					unsigned long unmap_phys = 0x55555555UL;
					int source_error =
						x86_split_large_page_source_result(
							attrs[a], pgsizes[p],
							&phys_base,
							&source_child,
							&source_rss);

					mix(&digest, (unsigned long)(unsigned int)-source_error);
					mix(&digest, phys_base);
					mix(&digest, source_child);
					mix(&digest, source_rss);
					for (int i = 0; i < 4; i++) {
						mix(&digest,
							(unsigned int)x86_split_large_page_child_map_result(
								phys_base, pgsizes[p],
								i, &map_phys));
						mix(&digest, map_phys);
					}
					mix(&digest,
						x86_split_large_page_publish_result(
							phys[a % (sizeof(phys) /
								sizeof(phys[0]))]));
					mix(&digest,
						(unsigned int)x86_split_large_page_source_unmap_result(
							phys_base, pgsizes[p],
							&unmap_phys));
					mix(&digest, unmap_phys);
				}
			}
		}
		{
			unsigned long source = 0x400000000UL | PF_PRESENT | PF_SIZE;
			unsigned long slot = source;
			int ret;

			reset_fake_split_large_page();
			ret = x86_split_large_page_body_result(&slot, PTL3_SIZE,
				IHK_MC_AP_NOWAIT, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_split_phys_to_page,
				fake_split_page_map, fake_split_rss_add,
				fake_split_rss_sub, fake_split_page_unmap,
				fake_split_log, fake_split_panic);
			require(ret == 0);
			require(fake_pt_alloc_count == 1);
			require(fake_pt_last_ap_flag == IHK_MC_AP_NOWAIT);
			require(slot == ((fake_pt_virt_to_phys(&fake_created_tables[0]) &
				PT_PHYSMASK) | 0x07UL));
			require(fake_created_tables[0].entry[0] == source);
			require(fake_created_tables[0].entry[1] ==
				source + PTL2_SIZE);
			require(fake_created_tables[0].entry[PT_ENTRIES - 1] ==
				source + ((unsigned long)(PT_ENTRIES - 1) *
				PTL2_SIZE));
			require(fake_split_phys_to_page_calls == PT_ENTRIES + 1);
			require(fake_split_page_map_calls == PT_ENTRIES);
			require(fake_split_page_unmap_calls == 1);
			require(fake_split_rss_add_calls == PT_ENTRIES);
			require(fake_split_rss_sub_calls == 1);
			require(fake_split_log_calls == PT_ENTRIES + 1);
			require(fake_split_panic_calls == 0);
			mix(&digest, fake_split_digest);

			source = 0x800000UL | PF_PRESENT | PF_SIZE;
			slot = source;
			reset_fake_split_large_page();
			ret = x86_split_large_page_body_result(&slot, PTL2_SIZE,
				IHK_MC_AP_NOWAIT, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_split_phys_to_page,
				fake_split_page_map, fake_split_rss_add,
				fake_split_rss_sub, fake_split_page_unmap,
				fake_split_log, fake_split_panic);
			require(ret == 0);
			require(fake_created_tables[0].entry[0] ==
				(source & ~PF_SIZE));
			require(fake_created_tables[0].entry[1] ==
				(source & ~PF_SIZE) + PTL1_SIZE);
			require(fake_split_phys_to_page_calls == 0);
			require(fake_split_page_map_calls == 0);
			require(fake_split_page_unmap_calls == 0);
			require(fake_split_rss_add_calls == PT_ENTRIES);
			require(fake_split_rss_sub_calls == 1);
			mix(&digest, fake_split_digest);

			reset_fake_split_large_page();
			slot = source;
			ret = x86_split_large_page_body_result(&slot, 12345,
				IHK_MC_AP_NOWAIT, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_split_phys_to_page,
				fake_split_page_map, fake_split_rss_add,
				fake_split_rss_sub, fake_split_page_unmap,
				fake_split_log, fake_split_panic);
			require(ret == -22);
			require(fake_pt_alloc_count == 0);
			require(fake_split_log_event ==
				X86_SPLIT_LARGE_PAGE_LOG_INVALID_PGSIZE);
			mix(&digest, fake_split_digest);

			reset_fake_split_large_page();
			fake_pt_alloc_fail = 1;
			slot = source;
			ret = x86_split_large_page_body_result(&slot, PTL2_SIZE,
				IHK_MC_AP_NOWAIT, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_split_phys_to_page,
				fake_split_page_map, fake_split_rss_add,
				fake_split_rss_sub, fake_split_page_unmap,
				fake_split_log, fake_split_panic);
			require(ret == -12);
			require(fake_split_log_event ==
				X86_SPLIT_LARGE_PAGE_LOG_ALLOC_FAILED);
			mix(&digest, fake_split_digest);

			reset_fake_split_large_page();
			fake_split_page_unmap_result = 1;
			source = 0x500000000UL | PF_PRESENT | PF_SIZE;
			slot = source;
			ret = x86_split_large_page_body_result(&slot, PTL3_SIZE,
				IHK_MC_AP_NOWAIT, fake_pt_alloc_pages,
				fake_pt_virt_to_phys, fake_split_phys_to_page,
				fake_split_page_map, fake_split_rss_add,
				fake_split_rss_sub, fake_split_page_unmap,
				fake_split_log, fake_split_panic);
			require(ret == 0);
			require(fake_split_page_unmap_calls == 1);
			require(fake_split_log_event ==
				X86_SPLIT_LARGE_PAGE_LOG_PAGE_UNMAP);
			require(fake_split_panic_calls == 1);
			mix(&digest, fake_split_digest);
		}
		{
			unsigned long addr = 0x400001000UL;
			int ret;

			reset_fake_pt_split();
			fake_pt_split_slots[0] = 0x400000000UL | PF_PRESENT |
				PF_SIZE;
			fake_pt_split_seq_len = 2;
			fake_pt_split_pteps[0] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[0] = 0x400000000UL;
			fake_pt_split_pgsizes[0] = PTL3_SIZE;
			fake_pt_split_pteps[1] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[1] = addr;
			fake_pt_split_pgsizes[1] = PTL2_SIZE;
			ret = x86_pt_split_body_result((void *)0x1111UL,
				(void *)0x2222UL, addr, 0x55, 7,
				fake_pt_split_lookup, fake_pt_split_phys_to_page,
				fake_pt_splitable, fake_pt_split_large,
				fake_pt_split_flush, fake_pt_split_log);
			require(ret == 0);
			require(fake_pt_split_lookup_calls == 2);
			require(fake_pt_splitable_calls == 1);
			require(fake_pt_split_last_page ==
				(void *)(uintptr_t)0x600000000UL);
			require(fake_pt_split_last_flags == 0x55);
			require(fake_pt_split_large_calls == 1);
			require(fake_pt_split_flush_calls == 1);
			require(fake_pt_split_flush_vm == (void *)0x2222UL);
			require(fake_pt_split_flush_addr == 0x400000000UL);
			require(fake_pt_split_flush_cpu == 7);
			require(fake_pt_split_log_calls == 0);
			mix(&digest, fake_pt_split_digest);

			reset_fake_pt_split();
			fake_pt_split_slots[0] = 0x900000UL | PF_PRESENT |
				PF_SIZE | PTATTR_FILEOFF;
			fake_pt_split_seq_len = 2;
			fake_pt_split_pteps[0] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[0] = 0x800000UL;
			fake_pt_split_pgsizes[0] = PTL2_SIZE;
			fake_pt_split_pteps[1] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[1] = addr;
			fake_pt_split_pgsizes[1] = PTL1_SIZE;
			ret = x86_pt_split_body_result((void *)0x1111UL,
				(void *)0x2222UL, addr, 0xaa, 3,
				fake_pt_split_lookup, fake_pt_split_phys_to_page,
				fake_pt_splitable, fake_pt_split_large,
				fake_pt_split_flush, fake_pt_split_log);
			require(ret == 0);
			require(fake_pt_splitable_calls == 1);
			require(fake_pt_split_last_page == NULL);
			require(fake_pt_split_large_calls == 1);
			require(fake_pt_split_flush_calls == 1);
			mix(&digest, fake_pt_split_digest);

			reset_fake_pt_split();
			fake_pt_split_slots[0] = PTE_NULL;
			fake_pt_split_seq_len = 1;
			fake_pt_split_pteps[0] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[0] = 0x800000UL;
			fake_pt_split_pgsizes[0] = PTL2_SIZE;
			ret = x86_pt_split_body_result((void *)0x1111UL,
				(void *)0x2222UL, addr, 0, 0,
				fake_pt_split_lookup, fake_pt_split_phys_to_page,
				fake_pt_splitable, fake_pt_split_large,
				fake_pt_split_flush, fake_pt_split_log);
			require(ret == 0);
			require(fake_pt_splitable_calls == 0);
			require(fake_pt_split_large_calls == 0);
			require(fake_pt_split_flush_calls == 0);
			mix(&digest, fake_pt_split_digest);

			reset_fake_pt_split();
			fake_pt_splitable_result = 0;
			fake_pt_split_slots[0] = 0x400000000UL | PF_PRESENT |
				PF_SIZE;
			fake_pt_split_seq_len = 1;
			fake_pt_split_pteps[0] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[0] = 0x400000000UL;
			fake_pt_split_pgsizes[0] = PTL3_SIZE;
			ret = x86_pt_split_body_result((void *)0x1111UL,
				(void *)0x2222UL, addr, 0, 0,
				fake_pt_split_lookup, fake_pt_split_phys_to_page,
				fake_pt_splitable, fake_pt_split_large,
				fake_pt_split_flush, fake_pt_split_log);
			require(ret == -22);
			require(fake_pt_split_large_calls == 0);
			require(fake_pt_split_log_event ==
				X86_PT_SPLIT_LOG_NOT_SPLITABLE);
			mix(&digest, fake_pt_split_digest);

			reset_fake_pt_split();
			fake_pt_split_large_result = -5;
			fake_pt_split_slots[0] = 0x400000000UL | PF_PRESENT |
				PF_SIZE;
			fake_pt_split_seq_len = 1;
			fake_pt_split_pteps[0] = &fake_pt_split_slots[0];
			fake_pt_split_pgaddrs[0] = 0x400000000UL;
			fake_pt_split_pgsizes[0] = PTL3_SIZE;
			ret = x86_pt_split_body_result((void *)0x1111UL,
				(void *)0x2222UL, addr, 0, 0,
				fake_pt_split_lookup, fake_pt_split_phys_to_page,
				fake_pt_splitable, fake_pt_split_large,
				fake_pt_split_flush, fake_pt_split_log);
			require(ret == -5);
			require(fake_pt_split_flush_calls == 0);
			require(fake_pt_split_log_event ==
				X86_PT_SPLIT_LOG_SPLIT_FAILED);
			require(fake_pt_split_log_error == -5);
			mix(&digest, fake_pt_split_digest);
		}
	}
	{
		struct fake_user_copy_vm user_vm;
		struct fake_public_address_space public_as;
		struct fake_public_process_vm public_vm;
		struct fake_public_thread public_thread;
		unsigned char dst[8192];
		unsigned char src[64];
		unsigned long user_addr;
		unsigned long cross_offset;
		unsigned long string_offset;
		long long_value = 0;
		int int_value = 0;
		char string_out[64];
		int ret;

		fake_user_copy_base = (unsigned long)fake_user_copy_space;
		reset_fake_user_copy(&user_vm);
		for (unsigned int i = 0; i < sizeof(fake_user_copy_space); i++)
			fake_user_copy_space[i] = (unsigned char)(i * 7 + 3);
		memset(dst, 0, sizeof(dst));
		user_addr = fake_user_copy_base + 123;
		ret = x86_process_vm_copy_result(&user_vm, &user_vm,
			user_addr, (unsigned long)dst, 5000,
			user_vm.user_start, user_vm.user_end, 1UL << 2, 0,
			fake_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_user_log);
		require(ret == 0);
		require(memcmp(dst, &fake_user_copy_space[123], 5000) == 0);
		mix(&digest, user_vm.page_fault_calls);
		mix(&digest, user_vm.vtop_calls);
		mix(&digest, dst[0]);
		mix(&digest, dst[4999]);

		reset_fake_user_copy(&user_vm);
		user_vm.is_memory_result = 0;
		for (unsigned int i = 0; i < sizeof(src); i++)
			src[i] = (unsigned char)(0xa0 + i);
		cross_offset = ((fake_user_copy_base + 4096) &
			~(4096UL - 1)) - fake_user_copy_base - 2;
		if (cross_offset > sizeof(fake_user_copy_space) - sizeof(src))
			cross_offset = 37;
		user_addr = fake_user_copy_base + cross_offset;
		ret = x86_process_vm_copy_result(&user_vm, &user_vm,
			user_addr, (unsigned long)src, sizeof(src),
			user_vm.user_start, user_vm.user_end,
			(1UL << 30) | (1UL << 1) | (1UL << 2), 1,
			fake_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_user_log);
		require(ret == 0);
		require(memcmp(&fake_user_copy_space[cross_offset], src,
			sizeof(src)) == 0);
		require(user_vm.map_calls == user_vm.unmap_calls);
		require(user_vm.map_calls > 0);
		mix(&digest, user_vm.map_calls);
		mix(&digest, user_vm.unmap_calls);
		mix(&digest, fake_user_copy_space[cross_offset + 17]);

		reset_fake_user_copy(&user_vm);
		user_vm.page_fault_fail_after = 1;
		user_vm.page_fault_error = -55;
		ret = x86_verify_process_vm_result(&user_vm,
			fake_user_copy_base + 16, 8, user_vm.user_start,
			user_vm.user_end, 1UL << 2, fake_user_page_fault,
			fake_user_log);
		require(ret == -55);
		mix(&digest, user_vm.log_digest);
		ret = x86_verify_process_vm_result(&user_vm,
			fake_user_copy_base - 16, 8, user_vm.user_start,
			user_vm.user_end, 1UL << 2, fake_user_page_fault,
			fake_user_log);
		require(ret == -14);

		reset_fake_user_copy(&user_vm);
		user_vm.vtop_fail_after = 1;
		ret = x86_process_vm_copy_result(&user_vm, &user_vm,
			fake_user_copy_base + 8, (unsigned long)dst, 8,
			user_vm.user_start, user_vm.user_end, 1UL << 2, 0,
			fake_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_user_log);
		require(ret == -77);
		mix(&digest, user_vm.log_digest);

		reset_fake_user_copy(&user_vm);
		string_offset = fake_user_copy_page_safe_offset(64);
		memcpy(&fake_user_copy_space[string_offset], "hello", 6);
		ret = x86_strlen_user_result(&user_vm,
			(char *)&fake_user_copy_space[string_offset],
			0xffff000000000000UL, fake_user_verify);
		require(ret == 5);
		memset(string_out, 0, sizeof(string_out));
		ret = x86_strcpy_from_user_result(&user_vm, string_out,
			(char *)&fake_user_copy_space[string_offset],
			0xffff000000000000UL, fake_user_verify);
		require(ret == 0);
		require(strcmp(string_out, "hello") == 0);
		mix(&digest, user_vm.page_fault_calls);
		mix(&digest, (unsigned long)string_out[1]);

		reset_fake_user_copy(&user_vm);
		*(long *)&fake_user_copy_space[512] = 0x1122334455667788L;
		*(int *)&fake_user_copy_space[640] = 0x12345678;
		require(x86_copy_from_user_result(&user_vm, dst,
			(void *)(fake_user_copy_base + 512), sizeof(long),
			fake_user_read_process_vm) == 0);
		require(*(long *)dst == 0x1122334455667788L);
		require(x86_getlong_user_result(&long_value,
			(long *)(fake_user_copy_base + 512),
			fake_user_copy_from_user_global) == 0);
		require(long_value == 0x1122334455667788L);
		require(x86_getint_user_result(&int_value,
			(int *)(fake_user_copy_base + 640),
			fake_user_copy_from_user_global) == 0);
		require(int_value == 0x12345678);
		long_value = 0x0102030405060708L;
		int_value = 0x5a6b7c8d;
		require(x86_setlong_user_result(
			(long *)(fake_user_copy_base + 700), long_value,
			fake_user_copy_to_user_global) == 0);
		require(*(long *)&fake_user_copy_space[700] == long_value);
		require(x86_setint_user_result(
			(int *)(fake_user_copy_base + 720), int_value,
			fake_user_copy_to_user_global) == 0);
		require(*(int *)&fake_user_copy_space[720] == int_value);
		mix(&digest, *(unsigned long *)&fake_user_copy_space[700]);
		mix(&digest, *(unsigned int *)&fake_user_copy_space[720]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		for (unsigned int i = 0; i < sizeof(fake_user_copy_space); i++)
			fake_user_copy_space[i] = (unsigned char)(0x5a ^ i);
		memset(dst, 0, sizeof(dst));
		ret = x86_read_process_vm_public_result(&public_vm, dst,
			(void *)(fake_user_copy_base + 96), 384,
			fake_public_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_public_user_log);
		require(ret == 0);
		require(memcmp(dst, &fake_user_copy_space[96], 384) == 0);
		require(user_vm.vtop_calls > 0);
		mix(&digest, user_vm.page_fault_calls);
		mix(&digest, user_vm.vtop_calls);
		mix(&digest, dst[17]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		for (unsigned int i = 0; i < sizeof(src); i++)
			src[i] = (unsigned char)(0xd0 + i);
		user_vm.is_memory_result = 0;
		ret = x86_write_process_vm_public_result(&public_vm,
			(void *)(fake_user_copy_base + 818), src, sizeof(src),
			fake_public_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_public_user_log);
		require(ret == 0);
		require(memcmp(&fake_user_copy_space[818], src,
			sizeof(src)) == 0);
		require(user_vm.map_calls == user_vm.unmap_calls);
		mix(&digest, user_vm.map_calls);
		mix(&digest, fake_user_copy_space[833]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		*(long *)&fake_user_copy_space[1200] = 0x33445566778899aaL;
		*(int *)&fake_user_copy_space[1224] = 0x2468ace0;
		memset(dst, 0, sizeof(dst));
		require(x86_copy_from_user_public_result(&public_thread, dst,
			(void *)(fake_user_copy_base + 1200), sizeof(long),
			fake_public_user_read_process_vm) == 0);
		require(*(long *)dst == 0x33445566778899aaL);
		require(x86_getlong_user_public_result(&long_value,
			(long *)(fake_user_copy_base + 1200),
			fake_public_copy_from_user_global) == 0);
		require(long_value == 0x33445566778899aaL);
		require(x86_getint_user_public_result(&int_value,
			(int *)(fake_user_copy_base + 1224),
			fake_public_copy_from_user_global) == 0);
		require(int_value == 0x2468ace0);
		long_value = 0x0f1e2d3c4b5a6978L;
		int_value = 0x10293847;
		require(x86_setlong_user_public_result(
			(long *)(fake_user_copy_base + 1300), long_value,
			fake_public_copy_to_user_global) == 0);
		require(*(long *)&fake_user_copy_space[1300] == long_value);
		require(x86_setint_user_public_result(
			(int *)(fake_user_copy_base + 1320), int_value,
			fake_public_copy_to_user_global) == 0);
		require(*(int *)&fake_user_copy_space[1320] == int_value);
		mix(&digest, *(unsigned long *)&fake_user_copy_space[1300]);
		mix(&digest, *(unsigned int *)&fake_user_copy_space[1320]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		for (unsigned int i = 0; i < sizeof(fake_user_copy_space); i++)
			fake_user_copy_space[i] = (unsigned char)(0x33 + i);
		memset(dst, 0, sizeof(dst));
		require(x86_copy_from_user_direct_public_result(
			&public_thread, dst,
			(void *)(fake_user_copy_base + 160), 80,
			fake_public_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_public_user_log) == 0);
		require(memcmp(dst, &fake_user_copy_space[160], 80) == 0);
		for (unsigned int i = 0; i < sizeof(src); i++)
			src[i] = (unsigned char)(0x44 + i);
		require(x86_copy_to_user_direct_public_result(
			&public_thread,
			(void *)(fake_user_copy_base + 1900), src,
			sizeof(src), fake_public_user_page_fault,
			fake_user_vtop, fake_user_is_memory, fake_user_map,
			fake_user_unmap, fake_user_phys_to_virt,
			fake_public_user_log) == 0);
		require(memcmp(&fake_user_copy_space[1900], src,
			sizeof(src)) == 0);
		mix(&digest, dst[19]);
		mix(&digest, fake_user_copy_space[1911]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		string_offset = fake_user_copy_page_safe_offset(96);
		memcpy(&fake_user_copy_space[string_offset], "public", 7);
		memset(string_out, 0, sizeof(string_out));
		require(x86_strlen_user_public_result(&public_thread,
			(char *)&fake_user_copy_space[string_offset],
			0xffff000000000000UL,
			fake_public_user_verify) == 6);
		require(x86_strcpy_from_user_public_result(&public_thread,
			string_out, (char *)&fake_user_copy_space[string_offset],
			0xffff000000000000UL,
			fake_public_user_verify) == 0);
		require(strcmp(string_out, "public") == 0);
		mix(&digest, user_vm.page_fault_calls);
		mix(&digest, (unsigned long)string_out[2]);

		reset_fake_user_copy(&user_vm);
		fake_public_prepare(&public_vm, &public_as, &public_thread,
			&user_vm);
		require(x86_verify_process_vm_public_result(&public_vm,
			(void *)(fake_user_copy_base - 1), 8,
			fake_public_user_page_fault,
			fake_public_user_log) == -14);
		for (unsigned int i = 0; i < sizeof(src); i++)
			src[i] = (unsigned char)(0xe0 + i);
		ret = x86_patch_process_vm_public_result(&public_vm,
			(void *)(fake_user_copy_base + 2048), src, sizeof(src),
			fake_public_user_page_fault, fake_user_vtop,
			fake_user_is_memory, fake_user_map, fake_user_unmap,
			fake_user_phys_to_virt, fake_public_user_log);
		require(ret == 0);
		require(memcmp(&fake_user_copy_space[2048], src,
			sizeof(src)) == 0);
		require(user_vm.log_calls >= 2);
		mix(&digest, user_vm.log_digest);
	}

printf("x86_memory_helpers ok digest=%016lx\n", digest);
	return 0;
}
