#include <errno.h>
#include <elf.h>
#include <limits.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define SFD_CLOEXEC 02000000
	#define SFD_NONBLOCK 04000
	#define O_CLOEXEC 02000000
	#define O_NONBLOCK 04000
	#ifndef AT_FDCWD
	#define AT_FDCWD -100
	#endif
	#ifndef AT_SYMLINK_NOFOLLOW
	#define AT_SYMLINK_NOFOLLOW 0x100
	#endif
	#ifndef AT_EMPTY_PATH
	#define AT_EMPTY_PATH 0x1000
	#endif
	#define MCEXEC_UP_SEND_SIGNAL 0x30a02906UL
	#define MCEXEC_UP_UTI_GET_CTX 0x30a02920UL
	#define MCEXEC_UP_UTI_ATTR 0x30a02927UL
	#define MCEXEC_UP_SIG_THREAD 0x30a02922UL
	#define MCEXEC_UP_SYSCALL_THREAD 0x30a02924UL
#ifndef WEXITED
#define WEXITED 0x00000004
#endif
#ifndef WNOWAIT
#define WNOWAIT 0x01000000
#endif
#ifndef SIGURG
#define SIGURG 23
#endif

struct fake_syscall_args {
	unsigned long r15;
	unsigned long r14;
	unsigned long r13;
	unsigned long r12;
	unsigned long rbp;
	unsigned long rbx;
	unsigned long r11;
	unsigned long r10;
	unsigned long r9;
	unsigned long r8;
	unsigned long rax;
	unsigned long rcx;
	unsigned long rdx;
	unsigned long rsi;
	unsigned long rdi;
	unsigned long orig_rax;
	unsigned long rip;
	unsigned long cs;
	unsigned long eflags;
	unsigned long rsp;
	unsigned long ss;
	unsigned long fs_base;
	unsigned long gs_base;
	unsigned long ds;
	unsigned long es;
	unsigned long fs;
	unsigned long gs;
};

struct fake_mcexec_syscall_request {
	int rtid;
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};

struct fake_mcexec_syscall_wait_desc {
	unsigned long cpu;
	struct fake_mcexec_syscall_request sr;
	int pid;
};

struct fake_sendsig_siginfo {
	int si_signo;
	int si_errno;
	int si_code;
	int si_pid;
	unsigned char rest[128 - 4 * sizeof(int)];
};

struct fake_signal_desc {
	int cpu;
	int pid;
	int tid;
	int sig;
	unsigned char info[128];
};

struct fake_syscall_struct {
	int number;
	unsigned long args[6];
	unsigned long ret;
	unsigned long uti_info;
};

struct fake_uti_desc {
	char lctx[4096];
	char rctx[4096];
	int mck_tid;
	unsigned long key;
	int pid;
	int tid;
	unsigned long uti_info;
	int fd;
	struct fake_syscall_struct syscall_stack[16];
	int syscall_stack_top;
	long syscalls[512];
	long syscalls2[512];
	int start_syscall_intercept;
};

struct fake_uti_get_ctx_desc {
	unsigned long rp_rctx;
	void *rctx;
	void *lctx;
	int uti_refill_tid;
	unsigned long key;
};

struct fake_uti_switch_ctx_desc {
	void *rctx;
	void *lctx;
};

struct fake_uti_attr_desc {
	unsigned long phys_attr;
	char *uti_cpu_set_str;
	size_t uti_cpu_set_len;
};

struct fake_thread_data;
struct fake_env_list_entry {
	char *str;
	char *name;
	char *value;
	struct fake_env_list_entry *next;
};
struct fake_list_head {
	struct fake_list_head *next;
	struct fake_list_head *prev;
};

extern int mcexec_path_is_absolute_result(const char *path);
extern int mcexec_path_is_single_component_exec_result(const char *path);
extern int mcexec_path_len_less_than_result(const char *path, size_t limit);
extern int mcexec_copy_path_result(const char *path, char *out, size_t size);
extern int mcexec_join_path_result(const char *prefix, const char *path,
				   char *out, size_t size);
extern int mcexec_reduce_stack_body(unsigned long orig_cur,
				    unsigned long orig_max, char **argv);
extern int lookup_exec_path(char *filename, char *path, int max_len,
			    int execvp);
extern int load_elf_desc(char *filename, void **desc_p, char **shebang_p);
extern int load_elf_desc_shebang(char *shebang_argv0, void **desc_p,
				 char ***shebang_argv_p, int execvp);
extern char *search_file(char *orgpath, int mode);
extern int mcexec_objdump_rpath_cmd_result(const char *path, char *out,
					   size_t size);
extern ssize_t mcexec_find_libdir_body(char *libdir, size_t len);
extern void mcexec_ld_preload_init_body(void);
extern int transfer_image(int fd, void *desc);
extern void *load_interp(void *desc, void *fp);
extern void print_desc(void *desc);
extern void print_flat(char *flat);
extern unsigned long atobytes(char *string);
extern pid_t gettid(void);
extern int tgkill(int tgid, int tid, int sig);
extern void do_syscall_return(int fd, int cpu, long ret, int n,
			      unsigned long src, unsigned long dest,
			      unsigned long sz);
extern void do_syscall_load(int fd, int cpu, unsigned long dest,
			    unsigned long src, unsigned long sz);
extern long do_strncpy_from_user(int fd, void *dest, void *src,
				 unsigned long n);
extern int close_cloexec_fds(int mcos_fd);
extern void init_sigaction(void);
extern int init_worker_threads(int fd);
extern void overlay_addfd(int fd, const char *path);
extern void overlay_delfd(int fd);
extern int overlay_blacklist(const char *path);
extern const char *overlay_path(int dirfd, const char *in, char *buf,
				int *resolvelinks);
extern int overlay_getdents(int sysnum, int fd, void *dirp,
			    unsigned int count);
extern void sendsig(int sig, void *siginfo, void *context);
extern long act_signalfd4(struct fake_mcexec_syscall_wait_desc *w);
extern void act_sigaction(struct fake_mcexec_syscall_wait_desc *w);
extern void act_sigprocmask(struct fake_mcexec_syscall_wait_desc *w);
extern void act_signalfd4_syscall(struct fake_mcexec_syscall_wait_desc *w,
				  int fd, int cpu);
extern void act_rt_sigaction(struct fake_mcexec_syscall_wait_desc *w,
			     int fd, int cpu);
extern void act_rt_sigprocmask(struct fake_mcexec_syscall_wait_desc *w,
			       int fd, int cpu);
extern void act_setfsuid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu);
extern void act_setresuid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			  int cpu);
extern void act_setreuid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu);
extern void act_setuid(struct fake_mcexec_syscall_wait_desc *w, int fd,
		       int cpu);
extern void act_setresgid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			  int cpu);
extern void act_setregid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu);
extern void act_setgid(struct fake_mcexec_syscall_wait_desc *w, int fd,
		       int cpu);
extern void act_setfsgid(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu);
	extern void act_close(struct fake_mcexec_syscall_wait_desc *w, int fd,
			      int cpu);
	extern long mcexec_do_generic_syscall_body(
		struct fake_mcexec_syscall_wait_desc *w);
	extern long mcexec_util_thread_body(struct fake_thread_data *my_thread,
					    unsigned long rp_rctx,
					    int remote_tid,
					    unsigned long pattr,
					    unsigned long uti_info,
					    unsigned long uti_desc_arg);
	extern void act_generic_syscall(struct fake_mcexec_syscall_wait_desc *w,
					int fd, int cpu);
extern void act_sched_setaffinity(struct fake_mcexec_syscall_wait_desc *w,
				  int fd, int cpu, void *my_thread);
extern void act_getdents(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu);
extern void act_perf_event_open(struct fake_mcexec_syscall_wait_desc *w,
				int fd, int cpu);
extern void act_futex_clock(struct fake_mcexec_syscall_wait_desc *w, int fd,
			    int cpu);
extern void act_kill(struct fake_mcexec_syscall_wait_desc *w, int fd,
		     int cpu, void *my_thread);
extern void act_wait4(struct fake_mcexec_syscall_wait_desc *w, int fd,
		      int cpu);
extern void act_gettid(struct fake_mcexec_syscall_wait_desc *w, int fd,
		       int cpu);
extern void act_debug_mlock(struct fake_mcexec_syscall_wait_desc *w, int fd,
			    int cpu);
extern void act_swapout_unavailable(struct fake_mcexec_syscall_wait_desc *w,
				    int fd, int cpu);
	extern void act_linux_spawn(struct fake_mcexec_syscall_wait_desc *w, int fd,
				    int cpu);
	extern void act_clone_complete(struct fake_mcexec_syscall_wait_desc *w,
				       int fd, int cpu);
	extern int act_clone_start(struct fake_mcexec_syscall_wait_desc *w,
				   int fd, int cpu, long *main_loop_ret);
	extern void act_exit(struct fake_mcexec_syscall_wait_desc *w, int cpu,
			     int is_child);
	extern void act_execve_phase1(struct fake_mcexec_syscall_wait_desc *w,
				      int fd, int cpu, char *pathbuf);
	extern long act_execve_phase2(struct fake_mcexec_syscall_wait_desc *w,
				      int fd, int cpu);
	extern int act_execve(struct fake_mcexec_syscall_wait_desc *w, int fd,
			      int cpu, char *pathbuf, long *main_loop_ret);
extern void act_reserved_memory_syscall(
	struct fake_mcexec_syscall_wait_desc *w, int fd, int cpu);
extern void act_readlinkat(struct fake_mcexec_syscall_wait_desc *w, int fd,
			   int cpu, char *pathbuf, char *tmpbuf);
extern void act_openat(struct fake_mcexec_syscall_wait_desc *w, int fd,
		       int cpu, char *pathbuf, char *tmpbuf);
extern void act_open(struct fake_mcexec_syscall_wait_desc *w, int fd,
		     int cpu, char *pathbuf, char *tmpbuf);
extern void act_readlink(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu, char *pathbuf, char *tmpbuf);
extern void act_newfstatat(struct fake_mcexec_syscall_wait_desc *w, int fd,
			   int cpu, char *pathbuf, char *tmpbuf);
extern void act_stat(struct fake_mcexec_syscall_wait_desc *w, int fd,
		     int cpu, char *pathbuf, char *tmpbuf);
extern void act_faccessat(struct fake_mcexec_syscall_wait_desc *w, int fd,
			  int cpu, char *pathbuf, char *tmpbuf);
extern void act_access(struct fake_mcexec_syscall_wait_desc *w, int fd,
		       int cpu, char *pathbuf, char *tmpbuf);
extern void act_getxattr(struct fake_mcexec_syscall_wait_desc *w, int fd,
			 int cpu, char *pathbuf, char *tmpbuf);
extern void act_lgetxattr(struct fake_mcexec_syscall_wait_desc *w, int fd,
			  int cpu, char *pathbuf, char *tmpbuf);
extern int act_main_loop_syscall(struct fake_mcexec_syscall_wait_desc *w,
				 int fd, int cpu, void *my_thread,
				 char *pathbuf, char *tmpbuf,
				 long *main_loop_ret, int is_child);
extern int act_main_loop_iteration(struct fake_mcexec_syscall_wait_desc *w,
				   int fd, struct fake_thread_data *my_thread,
				   char *pathbuf, char *tmpbuf,
				   long *main_loop_ret, int is_child);
	extern int act_main_loop_body(struct fake_thread_data *my_thread, int fd,
				      int is_child);
	extern void *mcexec_main_loop_thread_func_body(void *arg);
	extern int mcexec_create_worker_thread_body(struct fake_thread_data **tp_out,
						    void *init_ready);
	extern void mcexec_join_all_threads_body(void);
	extern void mcexec_kill_thread_body(unsigned long tid, unsigned long sig,
					    struct fake_thread_data *my_thread);
	extern int mcexec_get_thp_disable_body(void);
extern void mcexec_numa_local_body(unsigned long *localset,
				   unsigned long *nodemask,
				   int nonlocal);
extern void *mcexec_numa_node_set_body(int n, void *numa_nodes,
				       size_t cpu_set_size);
extern void mcexec_numa_all_body(unsigned long *nodemask);
extern int mcexec_opendev_body(void);
extern int mcexec_getpath_execveat_body(int dirfd, const char *filename,
					int flags, char *pathbuf,
					size_t size);
extern void mcexec_overlay_list_add_body(struct fake_list_head *entry,
					 struct fake_list_head *head);
extern void mcexec_overlay_list_del_body(struct fake_list_head *entry);
extern int mcexec_mapped_proc_task_parent_exists_body(const char *mapped);
extern int mcexec_dirent_is64_body(int sysnum, int getdents64);
extern int mcexec_env_list_count_result(
	const struct fake_env_list_entry *head);
extern struct fake_env_list_entry *mcexec_search_env_list_result(
	struct fake_env_list_entry *head, const char *name);
extern void mcexec_add_env_list_body(struct fake_env_list_entry **headp,
				     char *add_string);
extern void mcexec_destroy_env_list_result(
	struct fake_env_list_entry *head);
extern char **mcexec_create_local_environ_result(
	struct fake_env_list_entry *inc_list);
extern void mcexec_destroy_local_environ_result(char **local_env);
	extern int mcexec_apply_option_result(int opt, const char *optarg,
					      int *target_core, int *nr_processes,
				      int *nr_threads,
				      unsigned long *mpol_threshold,
				      unsigned long *heap_extension,
				      unsigned long *straight_map_threshold,
				      long *stack_premap, long *stack_max,
				      int *uti_thread_rank,
				      unsigned long *mcexec_flags);
extern int mcexec_post_options_plan_result(int optind, int argc,
					   const char *candidate,
					   unsigned long heap_extension,
					   unsigned long page_size,
					   int current_mcosid,
					   unsigned long *planned_heap_extension,
					   int *planned_mcosid,
					   int *planned_optind);
extern int mcexec_usage_line_result(char *buf, size_t size, const char *prog,
				    int add_envs_option);
extern void print_usage(char **argv);
extern int mcexec_flatten_strings_result(char *pre_strings, char **strings,
					 char **flat);
extern int flatten_strings(char *pre_strings, char **strings, char **flat);
extern int mcexec_shebang_argv_extend_result(char ***shebang_argv_p,
					     char *shebang);
extern int mcexec_execve1_transfer_buffer_result(const void *desc,
						 size_t desc_size,
						 const void *args,
						 size_t args_len,
						 char **buffer_out,
						 size_t *size_out);
extern int mcexec_syscall_should_log_result(long number,
					    unsigned long arg0,
					    long nr_write);
extern long mcexec_errno_return_result(long ret, int errno_value);
extern long mcexec_path_copy_return_result(long copy_ret,
					   unsigned long limit);
extern long mcexec_close_plan_result(unsigned long remote_fd, int mcos_fd);
extern int mcexec_setfsuid_needs_cred_result(unsigned long mode);
extern long mcexec_sched_setaffinity_action_result(unsigned long pid_arg);
extern void mcexec_exit_status_plan_result(long number,
					   unsigned long status,
					   long nr_exit_group,
					   int is_child, int is_tty,
					   int *sig, int *term,
					   int *report_sig,
					   int *report_status);
extern int mcexec_collect_active_tids_result(const void *head, int *tids,
					     size_t count);
extern int mcexec_fork_sync_complete_result(void *top, int pid,
					    void **fs_out,
					    void **node_out);
extern int mcexec_fork_sync_remove_node_result(void *top, void *target);
extern int mcexec_dirent_rewrite_offsets_result(void *dirents, size_t start,
						size_t end, size_t base,
						int is64);
extern int mcexec_copy_dirents_result(void *dst, const void *dirents,
				      size_t dirents_size, size_t offset,
				      unsigned int *count, int is64);
extern int copy_dirents(void *dst, void *dirents, size_t dirents_size,
			off_t offset, unsigned int *count, int sysnum);
extern int mcexec_dirent_buffer_contains_name_result(const void *dirents,
						     size_t dirents_size,
						     const void *entry,
						     int is64);
extern unsigned long get_syscall_number(struct fake_syscall_args *args);
extern unsigned long get_syscall_return(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg1(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg2(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg3(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg4(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg5(struct fake_syscall_args *args);
extern unsigned long get_syscall_arg6(struct fake_syscall_args *args);
extern unsigned long get_syscall_rip(struct fake_syscall_args *args);
extern void set_syscall_number(struct fake_syscall_args *args,
			       unsigned long value);
extern void set_syscall_return(struct fake_syscall_args *args,
			       unsigned long value);
extern void set_syscall_arg1(struct fake_syscall_args *args,
			     unsigned long value);
extern void set_syscall_arg2(struct fake_syscall_args *args,
			     unsigned long value);
extern void set_syscall_arg3(struct fake_syscall_args *args,
			     unsigned long value);
extern void set_syscall_arg4(struct fake_syscall_args *args,
			     unsigned long value);
extern void set_syscall_arg5(struct fake_syscall_args *args,
			     unsigned long value);
extern void set_syscall_arg6(struct fake_syscall_args *args,
			     unsigned long value);
extern int syscall_enter(struct fake_syscall_args *args);
extern void set_bit(int nr, volatile unsigned long *addr);
extern void clear_bit(int nr, volatile unsigned long *addr);
extern int test_bit(int nr, const void *addr);

struct fake_thread_data {
	struct fake_thread_data *next;
	unsigned long thread_id;
	int cpu;
	int ret;
	int tid;
	int terminate;
	int remote_tid;
	int remote_cpu;
	int joined;
	int detached;
	void *lock;
	void *init_ready;
};

int fd;
int ncpu;
int nnodes;
int n_threads;
unsigned long page_size;
unsigned long page_mask;
unsigned char *dma_buf;
struct fake_thread_data *thread_data;

struct fake_fork_sync {
	int status;
	volatile int success;
	char sem_storage[128];
};

struct fake_fork_sync_container {
	int pid;
	struct fake_fork_sync_container *next;
	struct fake_fork_sync *fs;
};

struct fake_fork_sync_container *fork_sync_top;

struct fake_dirent64 {
	unsigned long d_ino;
	long d_off;
	unsigned short d_reclen;
	unsigned char d_type;
	char d_name[];
};

struct fake_program_section {
	unsigned long vaddr;
	unsigned long len;
	unsigned long remote_pa;
	unsigned long filesz;
	unsigned long offset;
	int prot;
	unsigned char interp;
	void *fp;
};

	struct fake_program_desc {
		int num_sections;
		int cpu;
		int pid;
		int stack_prot;
		int pgid;
		int reloc;
		int enable_vdso;
		unsigned long entry;
		unsigned long rprocess;
		unsigned long at_phdr;
		unsigned long at_phent;
		unsigned long at_phnum;
		unsigned long at_entry;
		unsigned long at_clktck;
		unsigned long interp_align;
		unsigned long rlimit_cur;
		unsigned long rlimit_max;
		unsigned long args_len;
		long stack_premap;
		struct fake_program_section sections[4];
	};

struct fake_syscall_load_desc {
	unsigned long cpu;
	unsigned long src;
	unsigned long dest;
	unsigned long size;
};

struct fake_syscall_ret_desc {
	long cpu;
	long ret;
	unsigned long src;
	unsigned long dest;
	unsigned long size;
};

struct fake_strncpy_from_user_desc {
	void *dest;
	void *src;
	unsigned long n;
	long result;
};

#define MCEXEC_UP_TRANSFER 0x30a02901UL
#define MCEXEC_UP_WAIT_SYSCALL 0x30a02903UL
#define MCEXEC_UP_RET_SYSCALL 0x30a02904UL
#define MCEXEC_UP_LOAD_SYSCALL 0x30a02905UL
#define MCEXEC_UP_STRNCPY_FROM_USER 0x30a02908UL
#define MCEXEC_UP_GET_CREDV 0x30a0290bUL
#define MCEXEC_UP_OPEN_EXEC 0x30a02912UL
#define MCEXEC_UP_CLOSE_EXEC 0x30a02913UL
#define MCEXEC_UP_TRANSFER_TO_REMOTE 0
#define MCEXEC_UP_TRANSFER_FROM_REMOTE 1

struct fake_remote_transfer {
	unsigned long rphys;
	void *userp;
	unsigned long size;
	char direction;
};

static char usage_capture[2048];
static size_t usage_capture_len;
static int usage_add_envs_option;
static int mcexec_errno_value;
static const char *fake_altroot = "/alt";
static const char *fake_access_hit;
static const char *fake_access_hit_prefix;
static char fake_access_last_path[512];
static int fake_access_count;
static int fake_access_mode;
static int fake_load_elf_desc_count;
static int fake_load_elf_desc_result;
static char fake_load_elf_desc_path[512];
static char *fake_load_elf_desc_first_shebang;
static void *fake_load_elf_desc_desc_value;
static char *fake_load_elf_interp_path;
static int fake_load_desc_stat_count;
static int fake_load_desc_stat_result;
static int fake_load_desc_not_exec_count;
static int fake_load_desc_zero_count;
static int fake_load_desc_open_failed_count;
static int fake_load_desc_header_failed_count;
static int fake_load_desc_shebang_read_failed_count;
static int fake_load_desc_open_exec_failed_count;
static int fake_load_desc_exec_path_count;
static char fake_load_desc_exec_path[512];
static int fake_load_desc_parse_elf_failed_count;
static int fake_load_desc_interp_not_found_count;
static int fake_load_desc_interp_open_failed_count;
static int fake_load_desc_parse_interp_failed_count;
static int fake_load_desc_sections_count;
static int fake_load_desc_sections_value;
static int fake_load_section_count;
static int fake_load_finalize_count;
static int fake_load_cred_bridge_count;
static int fake_load_too_large_interp_count;
static int fake_load_cannot_read_interp_count;
static int fake_load_cred[8];
static unsigned long fake_load_digest;
static int fake_load_shebang_find_error_count;
static int fake_load_shebang_load_error_count;
static int fake_load_interp_section_count;
static int fake_load_interp_num_sections_set;
static unsigned long fake_load_interp_entry_set;
static unsigned long fake_load_interp_align_set;
static unsigned long fake_load_interp_digest;
static int fake_lookup_lstat_count;
static int fake_lookup_lstat_result;
static char fake_lookup_lstat_path[512];
static int fake_lookup_array_too_small_count;
static int fake_lookup_stat_error_count;
static int fake_lookup_not_found_count;
static int fake_lookup_success_count;
static int fake_search_file_too_long_count;
static int fake_reduce_overflow_count;
static int fake_reduce_setenv_count;
static int fake_reduce_setenv_ret;
static char fake_reduce_setenv_value[64];
static int fake_reduce_setenv_failed_count;
static int fake_reduce_setrlimit_count;
static int fake_reduce_setrlimit_ret;
static unsigned long fake_reduce_setrlimit_cur;
static unsigned long fake_reduce_setrlimit_max;
static int fake_reduce_setrlimit_failed_count;
static int fake_reduce_readlink_count;
static ssize_t fake_reduce_readlink_ret;
static char fake_reduce_readlink_target[256];
static int fake_reduce_readlink_failed_count;
static int fake_reduce_execv_count;
static char fake_reduce_execv_path[256];
static char **fake_reduce_execv_argv;
static int fake_reduce_execv_failed_count;
static int fake_print_desc_intro_count;
static int fake_print_desc_main_count;
static int fake_print_desc_section_count;
static unsigned long fake_print_desc_digest;
static int fake_print_flat_count_calls;
static int fake_print_flat_entry_count;
static unsigned long fake_print_flat_digest;
static int fake_ioctl_result;
static int fake_ioctl_fd;
static unsigned long fake_ioctl_request;
static int fake_ioctl_count;
	static int fake_ioctl_transfer_count;
	static int fake_ioctl_get_cred_count;
	static int fake_ioctl_open_exec_count;
	static char fake_ioctl_open_exec_path[512];
	static struct fake_remote_transfer fake_transfer_desc;
	static unsigned char fake_transfer_bytes[1024];
	static size_t fake_transfer_bytes_size;
	static unsigned long fake_transfer_digest;
static int fake_ioctl_ret_count;
static int fake_ioctl_load_count;
static struct fake_syscall_ret_desc fake_ret_desc;
static struct fake_syscall_load_desc fake_load_desc;
static int fake_ioctl_strncpy_count;
static int fake_ioctl_errno;
static long fake_strncpy_result;
static struct fake_strncpy_from_user_desc fake_strncpy_desc;
static int fake_strncpy_copy;
static int fake_perror_count;
static char fake_perror_tag[64];
static int fake_sysconf_name;
static long fake_sysconf_result;
static int fake_fcntl_count;
static int fake_fcntl_seen[16];
static int fake_fd_flags[16];
static int fake_close_count;
static int fake_closed_fds[16];
static int fake_init_sigaction_master_tid;
static int fake_init_sigaction_count;
static int fake_init_sigaction_seen[65];
static unsigned long fake_init_sigaction_digest;
static int fake_act_sigaction_count;
static int fake_act_sigaction_last_sig;
static int fake_act_sigaction_last_ignored;
static unsigned long fake_act_sigaction_digest;
static int fake_act_sigprocmask_count;
static unsigned long fake_act_sigprocmask_mask;
static unsigned long fake_act_sigprocmask_digest;
static int fake_pipe2_count;
static int fake_pipe2_flags;
static int fake_pipe2_result;
static int fake_pipe2_read_fd;
static int fake_pipe2_write_fd;
static int fake_act_signalfd4_write_count;
static int fake_act_signalfd4_write_fd;
static size_t fake_act_signalfd4_write_len;
static unsigned long fake_act_signalfd4_write_digest;
static ssize_t fake_act_signalfd4_write_result;
static int fake_act_signalfd4_write_error_count;
static int fake_sig_thread_count;
static unsigned long fake_sig_thread_arg[16];
static int fake_sig_thread_result[16];
static int fake_send_signal_count;
static int fake_send_signal_result;
static struct fake_signal_desc fake_send_signal_desc;
static int fake_syscall_thread_count;
static int fake_syscall_thread_result;
static unsigned long fake_syscall_thread_ret;
static struct fake_syscall_struct fake_syscall_thread_param;
static int fake_sendsig_default_count;
static int fake_sendsig_default_sig;
static int fake_sendsig_handler_count;
static int fake_sendsig_handler_sig;
static void *fake_sendsig_handler_info;
static void *fake_sendsig_handler_context;
static int fake_worker_lock_init_count;
static int fake_worker_barrier_count;
static int fake_worker_reset_count;
static int fake_worker_create_count;
static int fake_worker_create_fail_at;
static int fake_worker_wait_count;
static int fake_worker_error_count;
static int fake_worker_error_ret;
static int fake_overlay_mcosid;
static int fake_overlay_stat_count;
static int fake_overlay_stat_result;
static char fake_overlay_stat_path[256];
static int fake_overlay_cpu_node_count;
static int fake_overlay_cpu_node_cpu;
static int fake_overlay_cpu_node_node;
static int fake_overlay_cpu_node_result;
static int fake_overlay_addfd_too_long_count;
static int fake_overlay_addfd_publish_count;
static int fake_overlay_addfd_publish_fd;
static char fake_overlay_addfd_linux_path[256];
static char fake_overlay_addfd_mck_path[256];
static size_t fake_overlay_addfd_pathlen;
static int fake_overlay_delfd_count;
static int fake_overlay_delfd_fd;
static int fake_mcexec_generic_count;
static long fake_mcexec_generic_ret;
static unsigned long fake_mcexec_generic_number;
static unsigned long fake_mcexec_generic_arg0;
static int fake_mcexec_generic_raw_count;
static long fake_mcexec_generic_raw_ret;
static int fake_mcexec_generic_raw_errno;
static unsigned long fake_mcexec_generic_raw_number;
static unsigned long fake_mcexec_generic_raw_arg0;
static unsigned long fake_mcexec_generic_raw_arg5;
static int fake_mcexec_generic_start_count;
static unsigned long fake_mcexec_generic_start_number;
static int fake_mcexec_generic_done_count;
static unsigned long fake_mcexec_generic_done_number;
static long fake_mcexec_generic_done_ret;
static int fake_sched_util_count;
static void *fake_sched_util_thread;
static unsigned long fake_sched_util_args[5];
static long fake_sched_util_ret;
static int fake_sched_invalid_count;
static unsigned long fake_sched_invalid_pid;
static int fake_util_missing_desc_count;
static void *fake_util_desc_log_ptr;
static int fake_util_barrier_init_count;
static int fake_util_create_worker_count;
static int fake_util_create_worker_ret;
static struct fake_thread_data fake_util_worker;
static int fake_util_worker_tid;
static int fake_util_worker_error_count;
static int fake_util_worker_error_rc;
static int fake_util_barrier_wait_count;
static int fake_util_worker_tid_log_count;
static int fake_util_worker_tid_log_value;
static int fake_util_syscall_888_count;
static long fake_util_syscall_888_ret;
static int fake_util_intercept_warning_count;
static int fake_util_intercept_warning_rc;
static int fake_util_get_ctx_count;
static int fake_util_get_ctx_result;
static int fake_util_get_ctx_errno;
static unsigned long fake_util_get_ctx_key;
static struct fake_uti_get_ctx_desc fake_util_get_ctx_desc;
static int fake_util_get_ctx_error_count;
static int fake_util_get_ctx_error_errno;
static int fake_util_param_large_count;
static int fake_util_attr_count;
static int fake_util_attr_result;
static int fake_util_attr_errno;
static struct fake_uti_attr_desc fake_util_attr_desc;
static int fake_util_attr_error_count;
static int fake_util_attr_error_errno;
static int fake_util_switch_count;
static int fake_util_switch_ret;
static struct fake_uti_switch_ctx_desc fake_util_switch_desc;
static void *fake_util_switch_lctx;
static void *fake_util_switch_rctx;
static int fake_util_switch_failed_count;
static int fake_util_switch_failed_rc;
static int fake_util_switch_returned_count;
static int fake_util_switch_returned_rc;
static int fake_perf_event_open_count;
static long fake_perf_event_open_ret;
static int fake_clock_gettime_count;
static int fake_clock_gettime_id;
static long fake_clock_gettime_ret;
static long fake_clock_gettime_sec;
static long fake_clock_gettime_nsec;
static int fake_clock_gettime_log_count;
static long fake_clock_gettime_log_sec;
static long fake_clock_gettime_log_nsec;
static int fake_kill_thread_count;
static unsigned long fake_kill_thread_tid;
static unsigned long fake_kill_thread_sig;
static void *fake_kill_thread_arg;
static int fake_kill_thread_head_count;
static int fake_kill_thread_pthread_count;
static struct fake_thread_data *fake_kill_thread_pthread_tp[4];
static int fake_kill_thread_pthread_sig[4];
static struct fake_thread_data *fake_kill_thread_esrch_tp;
static int fake_kill_thread_not_found_count;
static unsigned long fake_kill_thread_not_found_tid;
static int fake_kill_thread_not_found_sig;
static int fake_mcexec_waitid_count;
static int fake_mcexec_waitid_pid;
static int fake_mcexec_waitid_opt;
static int fake_mcexec_waitid_ret;
static int fake_mcexec_waitid_errno;
static int fake_mcexec_wait4_error_count;
static unsigned long fake_mcexec_wait4_error_requested;
static int fake_mcexec_wait4_error_ret;
static int fake_mcexec_wait4_error_errno;
static int fake_mcexec_gettid_alloc_error_count;
static int fake_mcexec_gettid_transfer_error_count;
static int fake_debug_mlock_log_count;
static unsigned long fake_debug_mlock_log_addr;
static unsigned long fake_debug_mlock_log_len;
static int fake_debug_mlock_count;
static unsigned long fake_debug_mlock_addr;
static unsigned long fake_debug_mlock_len;
static long fake_debug_mlock_ret;
static int fake_swapout_unavailable_count;
static int fake_linux_spawn_invalid_arg_count;
static int fake_linux_spawn_invalid_exec_path_count;
static int fake_linux_spawn_alloc_exec_path_failed_count;
static int fake_linux_spawn_strncpy_failed_count;
static int fake_linux_spawn_alloc_argv_failed_count;
static int fake_linux_spawn_alloc_argv_index;
static int fake_linux_spawn_posix_failed_count;
static int fake_linux_spawn_posix_failed_rc;
static int fake_posix_spawn_count;
static int fake_posix_spawn_ret;
static char fake_posix_spawn_path[256];
static int fake_posix_spawn_argc;
static char fake_posix_spawn_argv[4][64];
static int fake_posix_spawn_envp_is_null;
static int fake_fork_sync_lock_count;
static int fake_fork_sync_unlock_count;
	static int fake_fork_sync_munmap_count;
	static void *fake_fork_sync_munmap_ptr;
	static int fake_fork_sync_free_count;
	static void *fake_fork_sync_free_ptr;
	static struct fake_fork_sync *fake_clone_alloc_fs_result;
	static int fake_clone_alloc_fs_count;
	static struct fake_fork_sync_container *fake_clone_alloc_container_result;
	static int fake_clone_alloc_container_count;
	static int fake_clone_fork_result;
	static int fake_clone_fork_errno;
	static int fake_clone_fork_count;
	static int fake_clone_fork_failed_count;
	static int fake_clone_sem_trywait_count;
	static int fake_clone_sem_trywait_len;
	static int fake_clone_sem_trywait_result[4];
	static int fake_clone_sem_trywait_errno[4];
	static int fake_clone_waitpid_count;
	static int fake_clone_waitpid_pid;
	static int fake_clone_waitpid_result;
	static int fake_clone_sched_yield_count;
	static int fake_clone_child_failed_count;
	static int fake_clone_sem_destroy_count;
	static void *fake_clone_sem_destroy_ptr;
	static int fake_clone_child_count;
	static struct fake_mcexec_syscall_wait_desc *fake_clone_child_w;
	static void *fake_clone_child_fs;
	static long fake_clone_child_ret;
	static int fake_mcexec_exit_debug_count;
static unsigned long fake_mcexec_exit_debug_status;
static int fake_mcexec_exit_debug_cpu;
static int fake_mcexec_exit_isatty_fd;
static int fake_mcexec_exit_isatty_result;
static int fake_mcexec_exit_report_signal_count;
static int fake_mcexec_exit_report_signal_sig;
static int fake_mcexec_exit_report_status_count;
static int fake_mcexec_exit_report_status_term;
static int fake_mcexec_exit_cmd_servers_count;
static int fake_mcexec_exit_replay_signal_count;
static int fake_mcexec_exit_replay_signal_sig;
static int fake_mcexec_exit_process_count;
static int fake_mcexec_exit_process_term;
static int fake_execve2_alloc_desc_failed_count;
static int fake_execve2_transfer_desc_failed_count;
static int fake_execve2_transfer_desc_ok_count;
static int fake_execve2_transfer_image_failed_count;
static int fake_execve2_image_transferred_count;
static int fake_execve2_close_exec_failed_count;
	static int fake_execve2_close_exec_failed_ret;
	static int fake_ioctl_close_exec_count;
	static int fake_ioctl_close_exec_result;
	static int fake_ioctl_transfer_from_result;
	static int fake_ioctl_transfer_to_result;
	static unsigned char fake_ioctl_from_remote_bytes[1024];
	static size_t fake_ioctl_from_remote_size;
	static int fake_execve1_enable_vdso = 1;
	static unsigned long fake_execve1_rlim_cur = 0x111000UL;
	static unsigned long fake_execve1_rlim_max = 0x222000UL;
	static long fake_execve1_stack_premap = 0x333000L;
	static int fake_execve1_load_desc_ok_count;
	static char fake_execve1_load_desc_ok_path[512];
	static int fake_execve1_load_desc_ok_sections;
	static int fake_execve1_runtime_set_count;
	static int fake_execve1_args_len_set_count;
	static int fake_execve1_transfer_alloc_failed_count;
	static int fake_execve1_transfer_failed_count;
	static char fake_execve1_transfer_failed_path[512];
	static int fake_execve1_transfer_ok_count;
	static char fake_execve1_transfer_ok_path[512];
	static int fake_execve_invalid_phase_count;
	static int fake_main_loop_log_count;
	static int fake_main_loop_log_cpu;
	static long fake_main_loop_log_number;
	static struct fake_mcexec_syscall_wait_desc fake_wait_descs[8];
	static int fake_wait_results[8];
	static int fake_wait_errno[8];
	static unsigned long fake_wait_seen_cpu[8];
	static int fake_wait_seen_pid[8];
	static int fake_wait_len;
	static int fake_wait_index;
	static int fake_main_loop_timeout_count;
		static int fake_thread_barrier_wait_count;
		static void *fake_thread_barrier_wait_ptr;
		static int fake_main_loop_is_child;
		static struct fake_thread_data fake_create_worker_storage;
		static int fake_create_worker_alloc_count;
		static int fake_create_worker_alloc_fail;
		static int fake_create_worker_alloc_error_count;
		static int fake_create_worker_next_cpu_count;
		static int fake_create_worker_next_cpu_value;
		static int fake_create_worker_lock_count;
		static void *fake_create_worker_lock_ptr;
		static int fake_create_worker_publish_count;
		static struct fake_thread_data *fake_create_worker_publish_tp;
		static struct fake_thread_data **fake_create_worker_publish_out;
		static int fake_create_worker_publish_order;
		static int fake_create_worker_pthread_count;
		static struct fake_thread_data *fake_create_worker_pthread_tp;
		static int fake_create_worker_pthread_ret;
		static int fake_create_worker_pthread_order;
		static int fake_create_worker_event_order;
		static int fake_join_all_threads_head_count;
		static int fake_join_all_threads_join_count;
		static struct fake_thread_data *fake_join_all_threads_joined[4];
		static struct fake_thread_data *fake_join_all_threads_insert_head;
		static int fake_thp_prctl_count;
		static int fake_thp_prctl_ret;
		static unsigned long fake_numa_node_cpu_mask[4];
		static int fake_numa_node_cpu_isset_count;
		static int fake_numa_local_log_count;
		static int fake_numa_node_log_count;
		static int fake_opendev_mcosid;
		static char fake_opendev_dev[64];
		static size_t fake_opendev_dev_size;
		static int fake_opendev_path_error_count;
		static int fake_opendev_open_count;
		static char fake_opendev_open_path[128];
		static int fake_opendev_open_ret;
		static int fake_opendev_open_error_count;
		static int fake_opendev_publish_count;
		static int fake_opendev_publish_fd;
		static unsigned char fake_opendev_buildid[16];
		static unsigned char fake_opendev_query_value[16];
		static unsigned char fake_opendev_query_result[16];
		static int fake_opendev_query_count;
		static int fake_opendev_query_fd;
		static int fake_opendev_query_ret;
		static int fake_opendev_query_error_count;
		static int fake_opendev_close_count;
		static int fake_opendev_close_fd;
		static int fake_opendev_mismatch_count;
		static int fake_env_invalid_count;
		static char fake_env_invalid_value[128];
static int fake_find_libdir_readlink_count;
static ssize_t fake_find_libdir_readlink_ret;
static char fake_find_libdir_readlink_target[PATH_MAX];
static int fake_find_libdir_popen_count;
static int fake_find_libdir_popen_fail;
static char fake_find_libdir_popen_cmd[PATH_MAX];
static int fake_find_libdir_getline_count;
static ssize_t fake_find_libdir_getline_ret;
static char fake_find_libdir_getline_line[PATH_MAX];
static char fake_find_libdir_line_storage[PATH_MAX];
static int fake_find_libdir_pclose_count;
static int fake_find_libdir_free_count;
static int fake_find_libdir_readlink_failed_count;
static int fake_find_libdir_readlink_failed_error;
static int fake_find_libdir_objdump_failed_count;
static int fake_find_libdir_objdump_failed_error;
static int fake_find_libdir_rpath_failed_count;
static int fake_find_libdir_rpath_failed_error;
static int fake_find_libdir_file;
static int fake_ld_preload_getenv_count;
static int fake_ld_preload_existing_present;
static char fake_ld_preload_existing[PATH_MAX];
static int fake_ld_preload_cleanup_present;
static int fake_ld_preload_setenv_count;
static int fake_ld_preload_setenv_ret;
static char fake_ld_preload_setenv_value[PATH_MAX];
static int fake_ld_preload_unsetenv_count;
static int fake_ld_preload_enable_uti;
static int fake_ld_preload_disable_sched_yield;
static int fake_ld_preload_enable_qlmpi;
static int fake_ld_preload_find_failed_count;
static int fake_ld_preload_line_too_long_count;
static int fake_ld_preload_setenv_failed_count;
static int fake_ld_preload_debug_count;
static char fake_ld_preload_debug_value[PATH_MAX];
static int fake_overlay_enable_uti;
static int fake_overlay_find_libdir_result;
static char fake_overlay_libdir[256];
static int fake_overlay_readlink_count;
static int fake_overlay_readlink_result;
static char fake_overlay_readlink_path[256];
static char fake_overlay_readlink_target[256];
static int fake_overlay_lstat_count;
static int fake_overlay_lstat_result;
static int fake_overlay_lstat_is_symlink;
static char fake_overlay_lstat_path[256];
static int fake_overlay_stat_errno_count;
static int fake_overlay_stat_errno_result;
static char fake_overlay_stat_errno_path[256];
static int fake_overlay_parent_exists_count;
static int fake_overlay_parent_exists_result;
static char fake_overlay_parent_exists_path[256];
static int fake_overlay_considering_count;
static int fake_overlay_fd_truncated_count;
static int fake_overlay_readlink_failed_count;
static int fake_overlay_truncated_count;
static int fake_overlay_getcwd_failed_count;
static int fake_overlay_glued_count;
static int fake_overlay_find_libdir_failed_count;
static int fake_overlay_replaced_count;
static int fake_overlay_trying_count;
static int fake_overlay_blacklisted_count;
static void *fake_overlay_getdents_ofd;
static int fake_overlay_getdents_fd;
static int fake_overlay_getdents_hide_orig;
static char fake_overlay_getdents_linux_path[256];
static size_t fake_overlay_getdents_pathlen;
static int fake_overlay_getdents_mck_fd;
static int fake_overlay_getdents_linux_fd;
static char fake_overlay_getdents_mck_cache[256];
static size_t fake_overlay_getdents_mck_cache_size;
static char fake_overlay_getdents_linux_cache[256];
static size_t fake_overlay_getdents_linux_cache_size;
static int fake_overlay_getdents_append_mck_count;
static int fake_overlay_getdents_append_linux_count;
static int fake_overlay_getdents_offset_log_count;
static int fake_overlay_getdents_upper_log_count;
static int fake_overlay_getdents_lower_log_count;
static int fake_overlay_getdents_blacklisted_log_count;
static int fake_overlay_getdents_dupe_log_count;
static int fake_overlay_getdents_upper_small_count;
static int fake_overlay_getdents_lower_small_count;
static int fake_overlay_getdents_mck_size_log_count;
static int fake_overlay_getdents_linux_size_log_count;
static char fake_getdents_passthrough[128];
static size_t fake_getdents_passthrough_size;
static int fake_getdents_passthrough_fd;
static char fake_getdents_mck_src[256];
static size_t fake_getdents_mck_src_size;
static char fake_getdents_linux_src[256];
static size_t fake_getdents_linux_src_size;
static int fake_getdents_mck_calls;
static int fake_getdents_linux_calls;
static int fake_getdents_passthrough_calls;
static int fake_lseek_count;
static long fake_lseek_current;
static long fake_lseek_advance;
static int fake_path_bridge_kind;
static int fake_path_bridge_count;
static int fake_path_bridge_dirfd;
static int fake_path_bridge_mode;
static int fake_path_bridge_flags;
static size_t fake_path_bridge_size;
static char fake_path_bridge_path[512];
static char fake_path_bridge_name[128];
static long fake_path_bridge_ret;
static int fake_path_open_log_count;
static int fake_path_open_log_tid;
static int fake_cred_kind;
static int fake_cred_count;
static int fake_cred_fd;
static unsigned long fake_cred_args[3];
static long fake_cred_ret;

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static size_t put_dirent64(char *buf, const char *name, unsigned short reclen)
{
	struct fake_dirent64 *dir = (struct fake_dirent64 *)buf;

	memset(buf, 0, reclen);
	dir->d_ino = 1;
	dir->d_off = 0;
	dir->d_reclen = reclen;
	dir->d_type = 8;
	strcpy(dir->d_name, name);
	return reclen;
}

int mcexec_copy_dirents_is64_bridge(int sysnum)
{
	return sysnum == 1;
}

int mcexec_print_usage_add_envs_bridge(void)
{
	return usage_add_envs_option;
}

void mcexec_print_usage_write_bridge(const char *line, size_t len)
{
	if (usage_capture_len + len >= sizeof(usage_capture)) {
		fprintf(stderr, "usage capture overflow\n");
		abort();
	}
	memcpy(usage_capture + usage_capture_len, line, len);
	usage_capture_len += len;
	usage_capture[usage_capture_len] = '\0';
}

void mcexec_atobytes_set_errno_bridge(int value)
{
	mcexec_errno_value = value;
}

const char *mcexec_altroot_bridge(void)
{
	return fake_altroot;
}

void mcexec_search_file_path_too_long_bridge(const char *root,
					     const char *path)
{
	(void)root;
	(void)path;
	fake_search_file_too_long_count++;
}

static void reset_reduce_stack_fakes(void)
{
	fake_reduce_overflow_count = 0;
	fake_reduce_setenv_count = 0;
	fake_reduce_setenv_ret = 0;
	memset(fake_reduce_setenv_value, 0, sizeof(fake_reduce_setenv_value));
	fake_reduce_setenv_failed_count = 0;
	fake_reduce_setrlimit_count = 0;
	fake_reduce_setrlimit_ret = 0;
	fake_reduce_setrlimit_cur = 0;
	fake_reduce_setrlimit_max = 0;
	fake_reduce_setrlimit_failed_count = 0;
	fake_reduce_readlink_count = 0;
	fake_reduce_readlink_ret = 0;
	memset(fake_reduce_readlink_target, 0,
	       sizeof(fake_reduce_readlink_target));
	fake_reduce_readlink_failed_count = 0;
	fake_reduce_execv_count = 0;
	memset(fake_reduce_execv_path, 0, sizeof(fake_reduce_execv_path));
	fake_reduce_execv_argv = NULL;
	fake_reduce_execv_failed_count = 0;
}

static void reset_find_libdir_fakes(void)
{
	fake_find_libdir_readlink_count = 0;
	fake_find_libdir_readlink_ret = 0;
	memset(fake_find_libdir_readlink_target, 0,
	       sizeof(fake_find_libdir_readlink_target));
	fake_find_libdir_popen_count = 0;
	fake_find_libdir_popen_fail = 0;
	memset(fake_find_libdir_popen_cmd, 0, sizeof(fake_find_libdir_popen_cmd));
	fake_find_libdir_getline_count = 0;
	fake_find_libdir_getline_ret = 0;
	memset(fake_find_libdir_getline_line, 0,
	       sizeof(fake_find_libdir_getline_line));
	memset(fake_find_libdir_line_storage, 0,
	       sizeof(fake_find_libdir_line_storage));
	fake_find_libdir_pclose_count = 0;
	fake_find_libdir_free_count = 0;
	fake_find_libdir_readlink_failed_count = 0;
	fake_find_libdir_readlink_failed_error = 0;
	fake_find_libdir_objdump_failed_count = 0;
	fake_find_libdir_objdump_failed_error = 0;
	fake_find_libdir_rpath_failed_count = 0;
	fake_find_libdir_rpath_failed_error = 0;
}

static void reset_ld_preload_fakes(void)
{
	fake_ld_preload_getenv_count = 0;
	fake_ld_preload_existing_present = 0;
	memset(fake_ld_preload_existing, 0, sizeof(fake_ld_preload_existing));
	fake_ld_preload_cleanup_present = 0;
	fake_ld_preload_setenv_count = 0;
	fake_ld_preload_setenv_ret = 0;
	memset(fake_ld_preload_setenv_value, 0,
	       sizeof(fake_ld_preload_setenv_value));
	fake_ld_preload_unsetenv_count = 0;
	fake_ld_preload_enable_uti = 0;
	fake_ld_preload_disable_sched_yield = 0;
	fake_ld_preload_enable_qlmpi = 0;
	fake_ld_preload_find_failed_count = 0;
	fake_ld_preload_line_too_long_count = 0;
	fake_ld_preload_setenv_failed_count = 0;
	fake_ld_preload_debug_count = 0;
	memset(fake_ld_preload_debug_value, 0,
	       sizeof(fake_ld_preload_debug_value));
}

void mcexec_reduce_stack_newval_overflow_bridge(void)
{
	fake_reduce_overflow_count++;
}

int mcexec_reduce_stack_setenv_bridge(const char *newval)
{
	fake_reduce_setenv_count++;
	snprintf(fake_reduce_setenv_value, sizeof(fake_reduce_setenv_value),
		 "%s", newval);
	return fake_reduce_setenv_ret;
}

void mcexec_reduce_stack_setenv_failed_bridge(void)
{
	fake_reduce_setenv_failed_count++;
}

int mcexec_reduce_stack_setrlimit_bridge(unsigned long cur,
					 unsigned long max)
{
	fake_reduce_setrlimit_count++;
	fake_reduce_setrlimit_cur = cur;
	fake_reduce_setrlimit_max = max;
	return fake_reduce_setrlimit_ret;
}

void mcexec_reduce_stack_setrlimit_failed_bridge(void)
{
	fake_reduce_setrlimit_failed_count++;
}

ssize_t mcexec_reduce_stack_readlink_bridge(char *path, size_t size)
{
	fake_reduce_readlink_count++;
	if (fake_reduce_readlink_ret >= 0) {
		size_t len = (size_t)fake_reduce_readlink_ret;

		if (len > size)
			len = size;
		memcpy(path, fake_reduce_readlink_target, len);
	}
	return fake_reduce_readlink_ret;
}

void mcexec_reduce_stack_readlink_failed_bridge(void)
{
	fake_reduce_readlink_failed_count++;
}

int mcexec_reduce_stack_execv_bridge(const char *path, char **argv)
{
	fake_reduce_execv_count++;
	snprintf(fake_reduce_execv_path, sizeof(fake_reduce_execv_path), "%s",
		 path);
	fake_reduce_execv_argv = argv;
	return -1;
}

void mcexec_reduce_stack_execv_failed_bridge(void)
{
	fake_reduce_execv_failed_count++;
}

ssize_t mcexec_find_libdir_readlink_bridge(char *path, size_t size)
{
	size_t len;

	fake_find_libdir_readlink_count++;
	if (fake_find_libdir_readlink_ret < 0) {
		errno = EINVAL;
		return fake_find_libdir_readlink_ret;
	}
	if (fake_find_libdir_readlink_ret > 0)
		len = (size_t)fake_find_libdir_readlink_ret;
	else
		len = strlen(fake_find_libdir_readlink_target);
	if (len > size)
		len = size;
	memcpy(path, fake_find_libdir_readlink_target, len);
	return (ssize_t)len;
}

void *mcexec_find_libdir_popen_bridge(const char *cmd)
{
	fake_find_libdir_popen_count++;
	snprintf(fake_find_libdir_popen_cmd,
		 sizeof(fake_find_libdir_popen_cmd), "%s", cmd);
	if (fake_find_libdir_popen_fail) {
		errno = EIO;
		return NULL;
	}
	return &fake_find_libdir_file;
}

ssize_t mcexec_find_libdir_getline_bridge(char **line, size_t *linelen,
					  void *filep)
{
	size_t len;

	if (filep != &fake_find_libdir_file) {
		fprintf(stderr, "unexpected find_libdir getline file handle\n");
		abort();
	}
	fake_find_libdir_getline_count++;
	if (fake_find_libdir_getline_ret <= 0) {
		errno = ENOENT;
		return fake_find_libdir_getline_ret;
	}
	len = (size_t)fake_find_libdir_getline_ret;
	if (len >= sizeof(fake_find_libdir_line_storage)) {
		fprintf(stderr, "find_libdir fake line is too long\n");
		abort();
	}
	memcpy(fake_find_libdir_line_storage, fake_find_libdir_getline_line, len);
	fake_find_libdir_line_storage[len] = '\0';
	*line = fake_find_libdir_line_storage;
	*linelen = sizeof(fake_find_libdir_line_storage);
	return fake_find_libdir_getline_ret;
}

void mcexec_find_libdir_pclose_bridge(void *filep)
{
	if (filep != &fake_find_libdir_file) {
		fprintf(stderr, "unexpected find_libdir pclose file handle\n");
		abort();
	}
	fake_find_libdir_pclose_count++;
}

void mcexec_find_libdir_free_bridge(char *line)
{
	if (line != fake_find_libdir_line_storage) {
		fprintf(stderr, "unexpected find_libdir free pointer\n");
		abort();
	}
	fake_find_libdir_free_count++;
}

void mcexec_find_libdir_readlink_failed_bridge(int error)
{
	fake_find_libdir_readlink_failed_count++;
	fake_find_libdir_readlink_failed_error = error;
}

void mcexec_find_libdir_objdump_failed_bridge(int error)
{
	fake_find_libdir_objdump_failed_count++;
	fake_find_libdir_objdump_failed_error = error;
}

void mcexec_find_libdir_rpath_not_found_bridge(int error)
{
	fake_find_libdir_rpath_failed_count++;
	fake_find_libdir_rpath_failed_error = error;
}

char *mcexec_ld_preload_getenv_bridge(const char *name)
{
	fake_ld_preload_getenv_count++;
	if (strcmp(name, "MCKERNEL_LD_PRELOAD") == 0)
		return fake_ld_preload_existing_present ?
			fake_ld_preload_existing : NULL;
	if (strcmp(name, "ld_preload_envname") == 0)
		return fake_ld_preload_cleanup_present ?
			fake_ld_preload_existing : NULL;
	return NULL;
}

int mcexec_ld_preload_setenv_bridge(const char *value)
{
	fake_ld_preload_setenv_count++;
	snprintf(fake_ld_preload_setenv_value,
		 sizeof(fake_ld_preload_setenv_value), "%s", value);
	return fake_ld_preload_setenv_ret;
}

int mcexec_ld_preload_unsetenv_bridge(void)
{
	fake_ld_preload_unsetenv_count++;
	return 0;
}

int mcexec_ld_preload_enable_uti_bridge(void)
{
	return fake_ld_preload_enable_uti;
}

int mcexec_ld_preload_disable_sched_yield_bridge(void)
{
	return fake_ld_preload_disable_sched_yield;
}

int mcexec_ld_preload_enable_qlmpi_bridge(void)
{
	return fake_ld_preload_enable_qlmpi;
}

void mcexec_ld_preload_find_failed_bridge(void)
{
	fake_ld_preload_find_failed_count++;
}

void mcexec_ld_preload_line_too_long_bridge(void)
{
	fake_ld_preload_line_too_long_count++;
}

void mcexec_ld_preload_setenv_failed_bridge(void)
{
	fake_ld_preload_setenv_failed_count++;
}

void mcexec_ld_preload_debug_bridge(const char *envbuf)
{
	fake_ld_preload_debug_count++;
	snprintf(fake_ld_preload_debug_value,
		 sizeof(fake_ld_preload_debug_value), "%s", envbuf);
}

int access(const char *path, int mode)
{
	fake_access_count++;
	fake_access_mode = mode;
	snprintf(fake_access_last_path, sizeof(fake_access_last_path), "%s",
		 path);
	if (fake_access_hit && strcmp(path, fake_access_hit) == 0)
		return 0;
	if (fake_access_hit_prefix &&
	    strncmp(path, fake_access_hit_prefix,
		    strlen(fake_access_hit_prefix)) == 0)
		return 0;

	errno = ENOENT;
	return -1;
}

int mcexec_load_desc_stat_size_bridge(const char *filename, long *size_out)
{
	struct stat sb;

	fake_load_desc_stat_count++;
	snprintf(fake_load_elf_desc_path, sizeof(fake_load_elf_desc_path), "%s",
		 filename);
	if (fake_load_desc_stat_result)
		return fake_load_desc_stat_result;
	if (stat(filename, &sb) == -1)
		return errno;
	*size_out = sb.st_size;
	return 0;
}

void *mcexec_load_alloc_desc_bridge(int nsections)
{
	struct fake_program_desc *desc;
	size_t size;

	if (nsections < 0 || nsections > 4) {
		fprintf(stderr, "unexpected nsections %d\n", nsections);
		abort();
	}
	size = offsetof(struct fake_program_desc, sections) +
		nsections * sizeof(struct fake_program_section);
	desc = malloc(size);
	if (!desc) {
		fprintf(stderr, "fake descriptor allocation failed\n");
		abort();
	}
	memset(desc, 0, size);
	desc->num_sections = nsections;
	desc->stack_prot = PROT_READ | PROT_WRITE | PROT_EXEC;
	return desc;
}

void mcexec_load_publish_main_section_bridge(void *desc, int index,
					     unsigned long vaddr,
					     unsigned long filesz,
					     unsigned long offset,
					     unsigned long len, int prot,
					     void *fp)
{
	struct fake_program_section *section =
		&((struct fake_program_desc *)desc)->sections[index];

	section->vaddr = vaddr;
	section->filesz = filesz;
	section->offset = offset;
	section->len = len;
	section->prot = prot;
	section->interp = 0;
	section->fp = fp;
	fake_load_section_count++;
	mix(&fake_load_digest, vaddr);
	mix(&fake_load_digest, filesz);
	mix(&fake_load_digest, offset);
	mix(&fake_load_digest, len);
	mix(&fake_load_digest, (unsigned long)prot);
}

int *mcexec_load_cred_bridge(void *desc)
{
	(void)desc;
	fake_load_cred_bridge_count++;
	return fake_load_cred;
}

long mcexec_load_clk_tck_bridge(void)
{
	return 100;
}

void mcexec_load_finalize_desc_bridge(void *desc, int pid, int pgid,
				      int reloc, unsigned long entry,
				      unsigned long at_phdr,
				      unsigned long at_phent,
				      unsigned long at_phnum,
				      unsigned long at_entry,
				      unsigned long at_clktck,
				      int stack_prot)
{
	struct fake_program_desc *program = desc;

	program->pid = pid;
	program->pgid = pgid;
	program->reloc = reloc;
	program->entry = entry;
	program->at_phdr = at_phdr;
	program->at_phent = at_phent;
	program->at_phnum = at_phnum;
	program->at_entry = at_entry;
	program->at_clktck = at_clktck;
	program->stack_prot = stack_prot;
	fake_load_finalize_count++;
	mix(&fake_load_digest, entry);
	mix(&fake_load_digest, at_phdr);
	mix(&fake_load_digest, at_phnum);
	mix(&fake_load_digest, (unsigned long)stack_prot);
}

void mcexec_load_too_large_interp_bridge(void)
{
	fake_load_too_large_interp_count++;
}

void mcexec_load_cannot_read_interp_bridge(void)
{
	fake_load_cannot_read_interp_count++;
}

void mcexec_load_desc_not_executable_bridge(const char *filename, int error)
{
	(void)filename;
	(void)error;
	fake_load_desc_not_exec_count++;
}

void mcexec_load_desc_zero_length_bridge(const char *filename)
{
	(void)filename;
	fake_load_desc_zero_count++;
}

void mcexec_load_desc_open_failed_bridge(const char *filename)
{
	(void)filename;
	fake_load_desc_open_failed_count++;
}

void mcexec_load_desc_header_failed_bridge(const char *filename)
{
	(void)filename;
	fake_load_desc_header_failed_count++;
}

void mcexec_load_desc_shebang_read_failed_bridge(const char *filename)
{
	(void)filename;
	fake_load_desc_shebang_read_failed_count++;
}

void mcexec_load_desc_open_exec_failed_bridge(const char *filename,
					      int ret, int fd_value)
{
	(void)filename;
	(void)ret;
	(void)fd_value;
	fake_load_desc_open_exec_failed_count++;
}

void mcexec_load_desc_publish_exec_path_bridge(char *path)
{
	fake_load_desc_exec_path_count++;
	snprintf(fake_load_desc_exec_path, sizeof(fake_load_desc_exec_path), "%s",
		 path);
	free(path);
}

void mcexec_load_desc_strdup_failed_bridge(void)
{
}

void mcexec_load_desc_getcwd_failed_bridge(void)
{
}

void mcexec_load_desc_alloc_exec_path_failed_bridge(void)
{
}

void mcexec_load_desc_build_exec_path_failed_bridge(void)
{
}

void mcexec_load_desc_parse_elf_failed_bridge(void)
{
	fake_load_desc_parse_elf_failed_count++;
}

void mcexec_load_desc_interp_not_found_bridge(const char *path)
{
	(void)path;
	fake_load_desc_interp_not_found_count++;
}

void mcexec_load_desc_interp_open_failed_bridge(const char *path)
{
	(void)path;
	fake_load_desc_interp_open_failed_count++;
}

void mcexec_load_desc_parse_interp_failed_bridge(void)
{
	fake_load_desc_parse_interp_failed_count++;
}

void mcexec_load_desc_sections_bridge(int count)
{
	fake_load_desc_sections_count++;
	fake_load_desc_sections_value = count;
}

void mcexec_load_shebang_find_error_bridge(const char *path)
{
	(void)path;
	fake_load_shebang_find_error_count++;
}

void mcexec_load_shebang_load_error_bridge(const char *path)
{
	(void)path;
	fake_load_shebang_load_error_count++;
}

int mcexec_lookup_lstat_errno_bridge(const char *path)
{
	fake_lookup_lstat_count++;
	snprintf(fake_lookup_lstat_path, sizeof(fake_lookup_lstat_path), "%s",
		 path);
	return fake_lookup_lstat_result;
}

void mcexec_lookup_array_too_small_bridge(void)
{
	fake_lookup_array_too_small_count++;
}

void mcexec_lookup_stat_error_bridge(const char *path, int error)
{
	(void)path;
	(void)error;
	fake_lookup_stat_error_count++;
}

void mcexec_lookup_not_found_bridge(const char *filename)
{
	(void)filename;
	fake_lookup_not_found_count++;
}

void mcexec_lookup_success_bridge(const char *path)
{
	(void)path;
	fake_lookup_success_count++;
}

int mcexec_desc_num_sections_bridge(const void *desc)
{
	return ((const struct fake_program_desc *)desc)->num_sections;
}

int mcexec_desc_cpu_bridge(const void *desc)
{
	return ((const struct fake_program_desc *)desc)->cpu;
}

int mcexec_desc_pid_bridge(const void *desc)
{
	return ((const struct fake_program_desc *)desc)->pid;
}

size_t mcexec_program_load_desc_size_bridge(void)
{
	return offsetof(struct fake_program_desc, sections);
}

	size_t mcexec_program_image_section_size_bridge(void)
	{
		return sizeof(struct fake_program_section);
	}

	int mcexec_execve1_enable_vdso_bridge(void)
	{
		return fake_execve1_enable_vdso;
	}

	unsigned long mcexec_execve1_rlim_cur_bridge(void)
	{
		return fake_execve1_rlim_cur;
	}

	unsigned long mcexec_execve1_rlim_max_bridge(void)
	{
		return fake_execve1_rlim_max;
	}

	long mcexec_execve1_stack_premap_bridge(void)
	{
		return fake_execve1_stack_premap;
	}

	void mcexec_desc_set_execve1_runtime_bridge(void *desc, int vdso,
						    unsigned long rlim_cur,
						    unsigned long rlim_max,
						    long prem)
	{
		struct fake_program_desc *program = desc;

		program->enable_vdso = vdso;
		program->rlimit_cur = rlim_cur;
		program->rlimit_max = rlim_max;
		program->stack_premap = prem;
		fake_execve1_runtime_set_count++;
	}

	void mcexec_desc_set_args_len_bridge(void *desc, unsigned long args_len)
	{
		((struct fake_program_desc *)desc)->args_len = args_len;
		fake_execve1_args_len_set_count++;
	}

	void mcexec_execve1_load_desc_ok_bridge(const char *filename, int sections)
	{
		fake_execve1_load_desc_ok_count++;
		fake_execve1_load_desc_ok_sections = sections;
		snprintf(fake_execve1_load_desc_ok_path,
			 sizeof(fake_execve1_load_desc_ok_path), "%s", filename);
	}

	void mcexec_execve1_transfer_alloc_failed_bridge(const char *filename)
	{
		(void)filename;
		fake_execve1_transfer_alloc_failed_count++;
	}

	void mcexec_execve1_transfer_failed_bridge(const char *filename)
	{
		fake_execve1_transfer_failed_count++;
		snprintf(fake_execve1_transfer_failed_path,
			 sizeof(fake_execve1_transfer_failed_path), "%s", filename);
	}

	void mcexec_execve1_transfer_ok_bridge(const char *filename)
	{
		fake_execve1_transfer_ok_count++;
		snprintf(fake_execve1_transfer_ok_path,
			 sizeof(fake_execve1_transfer_ok_path), "%s", filename);
	}

	void mcexec_execve_invalid_phase_bridge(void)
	{
		fake_execve_invalid_phase_count++;
	}

	void mcexec_main_loop_log_syscall_bridge(int cpu, long number)
	{
		fake_main_loop_log_count++;
		fake_main_loop_log_cpu = cpu;
		fake_main_loop_log_number = number;
	}

	void mcexec_main_loop_timeout_bridge(void)
	{
		fake_main_loop_timeout_count++;
	}

		int mcexec_main_loop_thread_barrier_wait_bridge(void *barrier)
		{
			fake_thread_barrier_wait_count++;
			fake_thread_barrier_wait_ptr = barrier;
			return 0;
		}

		int mcexec_main_loop_is_child_bridge(void)
		{
			return fake_main_loop_is_child;
		}

		void *mcexec_create_worker_thread_alloc_bridge(void)
		{
			fake_create_worker_alloc_count++;
			if (fake_create_worker_alloc_fail)
				return NULL;
			return &fake_create_worker_storage;
		}

		void mcexec_create_worker_thread_alloc_error_bridge(void)
		{
			fake_create_worker_alloc_error_count++;
		}

		int mcexec_create_worker_thread_next_cpu_bridge(void)
		{
			fake_create_worker_next_cpu_count++;
			return fake_create_worker_next_cpu_value++;
		}

		void *mcexec_create_worker_thread_lock_bridge(void)
		{
			fake_create_worker_lock_count++;
			return fake_create_worker_lock_ptr;
		}

		void mcexec_create_worker_thread_publish_bridge(
			struct fake_thread_data *tp, struct fake_thread_data **tp_out)
		{
			fake_create_worker_publish_count++;
			fake_create_worker_publish_tp = tp;
			fake_create_worker_publish_out = tp_out;
			fake_create_worker_publish_order = ++fake_create_worker_event_order;
			tp->next = thread_data;
			thread_data = tp;
			if (tp_out)
				*tp_out = tp;
		}

		int mcexec_create_worker_thread_pthread_create_bridge(
			struct fake_thread_data *tp)
		{
			fake_create_worker_pthread_count++;
			fake_create_worker_pthread_tp = tp;
			fake_create_worker_pthread_order = ++fake_create_worker_event_order;
			tp->thread_id = 0xfeedUL;
			return fake_create_worker_pthread_ret;
		}

		struct fake_thread_data *mcexec_join_all_threads_head_bridge(void)
		{
			fake_join_all_threads_head_count++;
			return thread_data;
		}

		void mcexec_join_all_threads_join_bridge(struct fake_thread_data *tp)
		{
			if (fake_join_all_threads_join_count < 4)
				fake_join_all_threads_joined[
					fake_join_all_threads_join_count] = tp;
			fake_join_all_threads_join_count++;
			if (fake_join_all_threads_join_count == 1 &&
					fake_join_all_threads_insert_head) {
				fake_join_all_threads_insert_head->next = thread_data;
				thread_data = fake_join_all_threads_insert_head;
				fake_join_all_threads_insert_head = NULL;
			}
		}

		void mcexec_load_cannot_read_ehdr_bridge(void)
		{
	}

void mcexec_load_elfmag_mismatch_bridge(void)
{
}

void mcexec_load_phdr_failed_bridge(int index)
{
	(void)index;
}

void mcexec_load_realloc_failed_bridge(unsigned long size)
{
	(void)size;
}

void mcexec_load_pt_interp_on_interp_bridge(void)
{
}

void mcexec_desc_set_num_sections_bridge(void *desc, int count)
{
	((struct fake_program_desc *)desc)->num_sections = count;
	fake_load_interp_num_sections_set = count;
}

void mcexec_desc_set_entry_bridge(void *desc, unsigned long entry)
{
	((struct fake_program_desc *)desc)->entry = entry;
	fake_load_interp_entry_set = entry;
}

void mcexec_desc_set_interp_align_bridge(void *desc, unsigned long align)
{
	((struct fake_program_desc *)desc)->interp_align = align;
	fake_load_interp_align_set = align;
}

void mcexec_desc_publish_interp_section_bridge(void *desc, int index,
					       unsigned long vaddr,
					       unsigned long filesz,
					       unsigned long offset,
					       unsigned long len, int prot,
					       void *fp)
{
	struct fake_program_section *section =
		&((struct fake_program_desc *)desc)->sections[index];

	section->vaddr = vaddr;
	section->filesz = filesz;
	section->offset = offset;
	section->len = len;
	section->prot = prot;
	section->interp = 1;
	section->fp = fp;
	fake_load_interp_section_count++;
	mix(&fake_load_interp_digest, vaddr);
	mix(&fake_load_interp_digest, filesz);
	mix(&fake_load_interp_digest, offset);
	mix(&fake_load_interp_digest, len);
	mix(&fake_load_interp_digest, (unsigned long)prot);
}

void mcexec_load_section_log_bridge(int index, unsigned long vaddr,
				    unsigned long filesz,
				    unsigned long offset, unsigned long len,
				    int prot)
{
	(void)index;
	(void)vaddr;
	(void)filesz;
	(void)offset;
	(void)len;
	(void)prot;
}

unsigned long mcexec_desc_entry_bridge(const void *desc)
{
	return ((const struct fake_program_desc *)desc)->entry;
}

unsigned long mcexec_desc_rprocess_bridge(const void *desc)
{
	return ((const struct fake_program_desc *)desc)->rprocess;
}

unsigned long mcexec_desc_section_vaddr_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].vaddr;
}

unsigned long mcexec_desc_section_len_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].len;
}

unsigned long mcexec_desc_section_remote_pa_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].remote_pa;
}

unsigned long mcexec_desc_section_filesz_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].filesz;
}

unsigned long mcexec_desc_section_offset_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].offset;
}

void *mcexec_desc_section_fp_bridge(const void *desc, int index)
{
	return ((const struct fake_program_desc *)desc)->sections[index].fp;
}

void mcexec_transfer_seek_error_bridge(void)
{
}

void mcexec_transfer_access_error_bridge(void)
{
}

void mcexec_transfer_short_error_bridge(void)
{
}

void mcexec_transfer_seeked_bridge(unsigned long offset, unsigned long size)
{
	mix(&fake_transfer_digest, offset);
	mix(&fake_transfer_digest, size);
}

void mcexec_print_desc_intro_bridge(const void *desc)
{
	fake_print_desc_intro_count++;
	fake_print_desc_digest ^= (unsigned long)(uintptr_t)desc;
}

void mcexec_print_desc_main_bridge(int cpu, int pid, unsigned long entry,
				   unsigned long rprocess)
{
	fake_print_desc_main_count++;
	fake_print_desc_digest ^= (unsigned long)cpu << 1;
	fake_print_desc_digest ^= (unsigned long)pid << 2;
	fake_print_desc_digest ^= entry;
	fake_print_desc_digest ^= rprocess;
}

void mcexec_print_desc_section_bridge(unsigned long vaddr, unsigned long len,
				      unsigned long remote_pa,
				      unsigned long filesz)
{
	fake_print_desc_section_count++;
	fake_print_desc_digest ^= vaddr + len + remote_pa + filesz;
}

void mcexec_print_flat_count_bridge(long count)
{
	fake_print_flat_count_calls++;
	fake_print_flat_digest ^= (unsigned long)count;
}

void mcexec_print_flat_entry_bridge(const char *entry)
{
	fake_print_flat_entry_count++;
	fake_print_flat_digest ^= strlen(entry);
	while (*entry) {
		fake_print_flat_digest ^= (unsigned long)(unsigned char)*entry;
		entry++;
	}
}

int ioctl(int fd, unsigned long request, ...)
{
	va_list ap;
	unsigned long arg;

	va_start(ap, request);
	arg = va_arg(ap, unsigned long);
	va_end(ap);

	fake_ioctl_fd = fd;
	fake_ioctl_request = request;
	fake_ioctl_count++;

	if (request == MCEXEC_UP_WAIT_SYSCALL) {
		struct fake_mcexec_syscall_wait_desc *desc =
			(struct fake_mcexec_syscall_wait_desc *)arg;
		int slot = fake_wait_index++;

		if (slot < 0 || slot >= fake_wait_len ||
		    slot >= (int)(sizeof(fake_wait_descs) /
				  sizeof(fake_wait_descs[0]))) {
			fprintf(stderr, "wait syscall capture overflow\n");
			abort();
		}

		fake_wait_seen_cpu[slot] = desc->cpu;
		fake_wait_seen_pid[slot] = desc->pid;
		if (fake_wait_results[slot] == 0)
			memcpy(desc, &fake_wait_descs[slot], sizeof(*desc));
		errno = fake_wait_errno[slot];
		return fake_wait_results[slot];
	} else if (request == MCEXEC_UP_TRANSFER) {
		struct fake_remote_transfer *desc =
			(struct fake_remote_transfer *)arg;
		unsigned char *bytes = desc->userp;

		memcpy(&fake_transfer_desc, desc, sizeof(fake_transfer_desc));
		if (desc->direction == MCEXEC_UP_TRANSFER_FROM_REMOTE) {
			size_t len = fake_ioctl_from_remote_size;
			if (len > desc->size)
				len = desc->size;
			memcpy(desc->userp, fake_ioctl_from_remote_bytes, len);
			return fake_ioctl_transfer_from_result;
		}

		fake_transfer_bytes_size = desc->size;
		if (fake_transfer_bytes_size > sizeof(fake_transfer_bytes))
			fake_transfer_bytes_size = sizeof(fake_transfer_bytes);
		memcpy(fake_transfer_bytes, bytes, fake_transfer_bytes_size);
		fake_ioctl_transfer_count++;
		mix(&fake_transfer_digest, desc->rphys);
		mix(&fake_transfer_digest, desc->size);
			mix(&fake_transfer_digest, desc->direction);
			for (size_t i = 0; i < desc->size; i++)
				mix(&fake_transfer_digest, bytes[i]);
			if (fake_ioctl_transfer_to_result) {
				errno = fake_ioctl_errno;
				return fake_ioctl_transfer_to_result;
			}
		} else if (request == MCEXEC_UP_RET_SYSCALL) {
			memcpy(&fake_ret_desc, (const void *)arg, sizeof(fake_ret_desc));
			fake_ioctl_ret_count++;
	} else if (request == MCEXEC_UP_LOAD_SYSCALL) {
		memcpy(&fake_load_desc, (const void *)arg,
		       sizeof(fake_load_desc));
		fake_ioctl_load_count++;
	} else if (request == MCEXEC_UP_STRNCPY_FROM_USER) {
		struct fake_strncpy_from_user_desc *desc =
			(struct fake_strncpy_from_user_desc *)arg;

		memcpy(&fake_strncpy_desc, desc, sizeof(fake_strncpy_desc));
		if (fake_strncpy_copy && fake_strncpy_result >= 0 &&
		    desc->dest && desc->src) {
			size_t len = (size_t)fake_strncpy_result;

			if (len > desc->n)
				len = desc->n;
			memcpy(desc->dest, desc->src, len);
		}
		desc->result = fake_strncpy_result;
		fake_ioctl_strncpy_count++;
	} else if (request == MCEXEC_UP_GET_CREDV) {
		int *cred = (int *)arg;

		for (int i = 0; i < 8; i++)
			cred[i] = 1000 + i;
		fake_ioctl_get_cred_count++;
	} else if (request == MCEXEC_UP_OPEN_EXEC) {
		fake_ioctl_open_exec_count++;
		snprintf(fake_ioctl_open_exec_path,
			 sizeof(fake_ioctl_open_exec_path), "%s",
			 (const char *)arg);
	} else if (request == MCEXEC_UP_CLOSE_EXEC) {
		fake_ioctl_close_exec_count++;
		return fake_ioctl_close_exec_result;
	} else if (request == MCEXEC_UP_UTI_GET_CTX) {
		struct fake_uti_get_ctx_desc *desc =
			(struct fake_uti_get_ctx_desc *)arg;

		memcpy(&fake_util_get_ctx_desc, desc,
		       sizeof(fake_util_get_ctx_desc));
		fake_util_get_ctx_count++;
		if (fake_util_get_ctx_result) {
			errno = fake_util_get_ctx_errno;
			return fake_util_get_ctx_result;
		}
		desc->key = fake_util_get_ctx_key;
		return 0;
	} else if (request == MCEXEC_UP_UTI_ATTR) {
		struct fake_uti_attr_desc *desc =
			(struct fake_uti_attr_desc *)arg;

		memcpy(&fake_util_attr_desc, desc, sizeof(fake_util_attr_desc));
		fake_util_attr_count++;
		if (fake_util_attr_result) {
			errno = fake_util_attr_errno;
			return fake_util_attr_result;
		}
		return 0;
	} else if (request == MCEXEC_UP_SIG_THREAD) {
		if (fake_sig_thread_count >= (int)(sizeof(fake_sig_thread_arg) /
						  sizeof(fake_sig_thread_arg[0]))) {
			fprintf(stderr, "sig thread capture overflow\n");
			abort();
		}
		fake_sig_thread_arg[fake_sig_thread_count] = arg;
		return fake_sig_thread_result[fake_sig_thread_count++];
	} else if (request == MCEXEC_UP_SEND_SIGNAL) {
		memcpy(&fake_send_signal_desc, (const void *)arg,
		       sizeof(fake_send_signal_desc));
		fake_send_signal_count++;
		return fake_send_signal_result;
	} else if (request == MCEXEC_UP_SYSCALL_THREAD) {
		struct fake_syscall_struct *param =
			(struct fake_syscall_struct *)arg;

		memcpy(&fake_syscall_thread_param, param,
		       sizeof(fake_syscall_thread_param));
		param->ret = fake_syscall_thread_ret;
		fake_syscall_thread_count++;
		return fake_syscall_thread_result;
	} else {
		fprintf(stderr, "unexpected ioctl request %#lx\n", request);
		abort();
	}

	errno = fake_ioctl_errno;
	return fake_ioctl_result;
}

void perror(const char *tag)
{
	fake_perror_count++;
	snprintf(fake_perror_tag, sizeof(fake_perror_tag), "%s", tag);
}

long sysconf(int name)
{
	fake_sysconf_name = name;
	return fake_sysconf_result;
}

int fcntl(int fd, int cmd, ...)
{
	if (cmd != 1) {
		fprintf(stderr, "unexpected fcntl cmd %d\n", cmd);
		abort();
	}
	fake_fcntl_count++;
	if (fd >= 0 && fd < (int)(sizeof(fake_fcntl_seen) /
				  sizeof(fake_fcntl_seen[0]))) {
		fake_fcntl_seen[fd]++;
		return fake_fd_flags[fd];
	}

	return 0;
}

int close(int fd)
{
	if (fake_close_count >= (int)(sizeof(fake_closed_fds) /
				      sizeof(fake_closed_fds[0]))) {
		fprintf(stderr, "close capture overflow\n");
		abort();
	}
	fake_closed_fds[fake_close_count++] = fd;
	return 0;
}

long syscall(long number, ...)
{
	va_list ap;
	int fd_arg;
	void *dirp_arg;
	unsigned long count_arg;
	size_t len;

	if (number == 186)
		return 12345;
	if (number == 234) {
		errno = EINVAL;
		return -1;
	}
	if (number == 888) {
		fake_util_syscall_888_count++;
		return fake_util_syscall_888_ret;
	}

	va_start(ap, number);
	fd_arg = va_arg(ap, int);
	dirp_arg = va_arg(ap, void *);
	count_arg = va_arg(ap, unsigned long);
	va_end(ap);

	if (number != 1 && number != 217) {
		errno = ENOSYS;
		return -1;
	}

	if (fd_arg == fake_getdents_passthrough_fd) {
		fake_getdents_passthrough_calls++;
		len = fake_getdents_passthrough_size;
		if (len > count_arg)
			len = count_arg;
		memcpy(dirp_arg, fake_getdents_passthrough, len);
		return (long)len;
	}
	if (fd_arg == fake_overlay_getdents_mck_fd) {
		fake_getdents_mck_calls++;
		if (fake_getdents_mck_calls > 1)
			return 0;
		len = fake_getdents_mck_src_size;
		if (len > count_arg)
			len = count_arg;
		memcpy(dirp_arg, fake_getdents_mck_src, len);
		return (long)len;
	}
	if (fd_arg == fake_overlay_getdents_linux_fd) {
		fake_getdents_linux_calls++;
		if (fake_getdents_linux_calls > 1)
			return 0;
		len = fake_getdents_linux_src_size;
		if (len > count_arg)
			len = count_arg;
		memcpy(dirp_arg, fake_getdents_linux_src, len);
		return (long)len;
	}

	errno = EBADF;
	return -1;
}

off_t lseek(int fd, off_t offset, int whence)
{
	(void)fd;
	fake_lseek_count++;
	if (whence != SEEK_CUR) {
		errno = EINVAL;
		return -1;
	}
	if (offset == 0)
		return fake_lseek_current;
	fake_lseek_advance += offset;
	fake_lseek_current += offset;
	return fake_lseek_current;
}

static long fake_path_bridge_record(int kind, int dirfd, const char *path,
				    const char *name, int mode, int flags,
				    size_t size)
{
	fake_path_bridge_kind = kind;
	fake_path_bridge_count++;
	fake_path_bridge_dirfd = dirfd;
	fake_path_bridge_mode = mode;
	fake_path_bridge_flags = flags;
	fake_path_bridge_size = size;
	snprintf(fake_path_bridge_path, sizeof(fake_path_bridge_path), "%s",
		 path ? path : "");
	snprintf(fake_path_bridge_name, sizeof(fake_path_bridge_name), "%s",
		 name ? name : "");
	return fake_path_bridge_ret;
}

long mcexec_path_readlinkat_bridge(int dirfd, const char *path, char *buf,
				   size_t size)
{
	(void)buf;
	return fake_path_bridge_record(1, dirfd, path, NULL, 0, 0, size);
}

long mcexec_path_readlink_bridge(const char *path, char *buf, size_t size)
{
	(void)buf;
	return fake_path_bridge_record(2, -100, path, NULL, 0, 0, size);
}

long mcexec_path_fstatat_bridge(int dirfd, const char *path, void *statbuf,
				int flags)
{
	(void)statbuf;
	return fake_path_bridge_record(3, dirfd, path, NULL, 0, flags, 0);
}

long mcexec_path_stat_bridge(const char *path, void *statbuf)
{
	(void)statbuf;
	return fake_path_bridge_record(4, -100, path, NULL, 0, 0, 0);
}

long mcexec_path_faccessat_bridge(int dirfd, const char *path, int mode,
				  int flags)
{
	return fake_path_bridge_record(5, dirfd, path, NULL, mode, flags, 0);
}

long mcexec_path_access_bridge(const char *path, int mode)
{
	return fake_path_bridge_record(6, -100, path, NULL, mode, 0, 0);
}

long mcexec_path_getxattr_bridge(const char *path, const char *name,
				 void *value, size_t size)
{
	(void)value;
	return fake_path_bridge_record(7, -100, path, name, 0, 0, size);
}

long mcexec_path_lgetxattr_bridge(const char *path, const char *name,
				  void *value, size_t size)
{
	(void)value;
	return fake_path_bridge_record(8, -100, path, name, 0, 0, size);
}

void mcexec_path_openat_log_bridge(int dirfd, const char *path, int tid)
{
	fake_path_open_log_count++;
	fake_path_bridge_dirfd = dirfd;
	fake_path_open_log_tid = tid;
	snprintf(fake_path_bridge_path, sizeof(fake_path_bridge_path), "%s",
		 path ? path : "");
}

void mcexec_path_open_log_bridge(const char *path)
{
	fake_path_open_log_count++;
	snprintf(fake_path_bridge_path, sizeof(fake_path_bridge_path), "%s",
		 path ? path : "");
}

long mcexec_path_openat_bridge(int dirfd, const char *path,
			       unsigned long flags, unsigned long mode)
{
	return fake_path_bridge_record(9, dirfd, path, NULL, (int)mode,
				       (int)flags, 0);
}

long mcexec_path_open_bridge(const char *path, unsigned long flags,
			     unsigned long mode)
{
	return fake_path_bridge_record(10, -100, path, NULL, (int)mode,
				       (int)flags, 0);
}

static long fake_cred_record(int kind, unsigned long a0, unsigned long a1,
			     unsigned long a2)
{
	fake_cred_kind = kind;
	fake_cred_count++;
	fake_cred_args[0] = a0;
	fake_cred_args[1] = a1;
	fake_cred_args[2] = a2;
	return fake_cred_ret;
}

void mcexec_cred_get_bridge(int fd, unsigned long arg)
{
	fake_cred_fd = fd;
	(void)fake_cred_record(1, arg, 0, 0);
}

long mcexec_cred_setfsuid_bridge(unsigned long uid)
{
	return fake_cred_record(2, uid, 0, 0);
}

long mcexec_cred_setresuid_bridge(unsigned long ruid, unsigned long euid,
				  unsigned long suid)
{
	return fake_cred_record(3, ruid, euid, suid);
}

long mcexec_cred_setreuid_bridge(unsigned long ruid, unsigned long euid)
{
	return fake_cred_record(4, ruid, euid, 0);
}

long mcexec_cred_setuid_bridge(unsigned long uid)
{
	return fake_cred_record(5, uid, 0, 0);
}

long mcexec_cred_setresgid_bridge(unsigned long rgid, unsigned long egid,
				  unsigned long sgid)
{
	return fake_cred_record(6, rgid, egid, sgid);
}

long mcexec_cred_setregid_bridge(unsigned long rgid, unsigned long egid)
{
	return fake_cred_record(7, rgid, egid, 0);
}

long mcexec_cred_setgid_bridge(unsigned long gid)
{
	return fake_cred_record(8, gid, 0, 0);
}

long mcexec_cred_setfsgid_bridge(unsigned long gid)
{
	return fake_cred_record(9, gid, 0, 0);
}

long mcexec_do_generic_syscall_bridge(
	struct fake_mcexec_syscall_wait_desc *w)
{
	fake_mcexec_generic_count++;
	fake_mcexec_generic_number = w->sr.number;
	fake_mcexec_generic_arg0 = w->sr.args[0];
	return fake_mcexec_generic_ret;
}

long mcexec_do_generic_syscall_raw_bridge(
	struct fake_mcexec_syscall_wait_desc *w)
{
	fake_mcexec_generic_raw_count++;
	fake_mcexec_generic_raw_number = w->sr.number;
	fake_mcexec_generic_raw_arg0 = w->sr.args[0];
	fake_mcexec_generic_raw_arg5 = w->sr.args[5];
	errno = fake_mcexec_generic_raw_errno;
	return fake_mcexec_generic_raw_ret;
}

void mcexec_do_generic_syscall_start_bridge(unsigned long number)
{
	fake_mcexec_generic_start_count++;
	fake_mcexec_generic_start_number = number;
}

void mcexec_do_generic_syscall_done_bridge(unsigned long number, long ret)
{
	fake_mcexec_generic_done_count++;
	fake_mcexec_generic_done_number = number;
	fake_mcexec_generic_done_ret = ret;
}

static void reset_fake_util_thread(void)
{
	fake_util_missing_desc_count = 0;
	fake_util_desc_log_ptr = NULL;
	fake_util_barrier_init_count = 0;
	fake_util_create_worker_count = 0;
	fake_util_create_worker_ret = 0;
	memset(&fake_util_worker, 0, sizeof(fake_util_worker));
	fake_util_worker_tid = 4321;
	fake_util_worker_error_count = 0;
	fake_util_worker_error_rc = 0;
	fake_util_barrier_wait_count = 0;
	fake_util_worker_tid_log_count = 0;
	fake_util_worker_tid_log_value = 0;
	fake_util_syscall_888_count = 0;
	fake_util_syscall_888_ret = -1;
	fake_util_intercept_warning_count = 0;
	fake_util_intercept_warning_rc = 0;
	fake_util_get_ctx_count = 0;
	fake_util_get_ctx_result = 0;
	fake_util_get_ctx_errno = 0;
	fake_util_get_ctx_key = 0xabcdef0123456789UL;
	memset(&fake_util_get_ctx_desc, 0, sizeof(fake_util_get_ctx_desc));
	fake_util_get_ctx_error_count = 0;
	fake_util_get_ctx_error_errno = 0;
	fake_util_param_large_count = 0;
	fake_util_attr_count = 0;
	fake_util_attr_result = 0;
	fake_util_attr_errno = 0;
	memset(&fake_util_attr_desc, 0, sizeof(fake_util_attr_desc));
	fake_util_attr_error_count = 0;
	fake_util_attr_error_errno = 0;
	fake_util_switch_count = 0;
	fake_util_switch_ret = -22;
	memset(&fake_util_switch_desc, 0, sizeof(fake_util_switch_desc));
	fake_util_switch_lctx = NULL;
	fake_util_switch_rctx = NULL;
	fake_util_switch_failed_count = 0;
	fake_util_switch_failed_rc = 0;
	fake_util_switch_returned_count = 0;
	fake_util_switch_returned_rc = 0;
}

void mcexec_util_thread_missing_desc_bridge(void)
{
	fake_util_missing_desc_count++;
}

void mcexec_util_thread_desc_log_bridge(void *desc)
{
	fake_util_desc_log_ptr = desc;
}

void mcexec_util_thread_barrier_init_bridge(void)
{
	fake_util_barrier_init_count++;
}

int mcexec_util_thread_create_worker_bridge(struct fake_thread_data **tp_out)
{
	fake_util_create_worker_count++;
	if (fake_util_create_worker_ret)
		return fake_util_create_worker_ret;
	fake_util_worker.tid = fake_util_worker_tid;
	if (tp_out)
		*tp_out = &fake_util_worker;
	return 0;
}

void mcexec_util_thread_worker_error_bridge(int rc)
{
	fake_util_worker_error_count++;
	fake_util_worker_error_rc = rc;
}

void mcexec_util_thread_barrier_wait_bridge(void)
{
	fake_util_barrier_wait_count++;
}

void mcexec_util_thread_worker_tid_log_bridge(int tid)
{
	fake_util_worker_tid_log_count++;
	fake_util_worker_tid_log_value = tid;
}

void mcexec_util_thread_intercept_warning_bridge(int rc)
{
	fake_util_intercept_warning_count++;
	fake_util_intercept_warning_rc = rc;
}

void mcexec_util_thread_get_ctx_error_bridge(int errno_value)
{
	fake_util_get_ctx_error_count++;
	fake_util_get_ctx_error_errno = errno_value;
}

void mcexec_util_thread_param_large_bridge(void)
{
	fake_util_param_large_count++;
}

void mcexec_util_thread_attr_error_bridge(int errno_value)
{
	fake_util_attr_error_count++;
	fake_util_attr_error_errno = errno_value;
}

int mcexec_util_thread_switch_ctx_bridge(struct fake_uti_switch_ctx_desc *desc,
					 void *lctx, void *rctx)
{
	fake_util_switch_count++;
	memcpy(&fake_util_switch_desc, desc, sizeof(fake_util_switch_desc));
	fake_util_switch_lctx = lctx;
	fake_util_switch_rctx = rctx;
	return fake_util_switch_ret;
}

void mcexec_util_thread_switch_failed_bridge(int rc)
{
	fake_util_switch_failed_count++;
	fake_util_switch_failed_rc = rc;
}

void mcexec_util_thread_switch_returned_bridge(int rc)
{
	fake_util_switch_returned_count++;
	fake_util_switch_returned_rc = rc;
}

long mcexec_sched_setaffinity_util_bridge(void *my_thread,
					  unsigned long rp_rctx,
					  int remote_tid,
					  unsigned long pattr,
					  unsigned long uti_info,
					  unsigned long uti_desc)
{
	fake_sched_util_count++;
	fake_sched_util_thread = my_thread;
	fake_sched_util_args[0] = rp_rctx;
	fake_sched_util_args[1] = (unsigned long)remote_tid;
	fake_sched_util_args[2] = pattr;
	fake_sched_util_args[3] = uti_info;
	fake_sched_util_args[4] = uti_desc;
	return fake_sched_util_ret;
}

void mcexec_sched_setaffinity_invalid_bridge(unsigned long pid_arg)
{
	fake_sched_invalid_count++;
	fake_sched_invalid_pid = pid_arg;
}

long mcexec_perf_event_open_bridge(void)
{
	fake_perf_event_open_count++;
	return fake_perf_event_open_ret;
}

struct fake_mcexec_timespec {
	long tv_sec;
	long tv_nsec;
};

long mcexec_clock_gettime_bridge(int clock_id,
				 struct fake_mcexec_timespec *tv)
{
	fake_clock_gettime_count++;
	fake_clock_gettime_id = clock_id;
	tv->tv_sec = fake_clock_gettime_sec;
	tv->tv_nsec = fake_clock_gettime_nsec;
	return fake_clock_gettime_ret;
}

void mcexec_clock_gettime_log_bridge(long sec, long nsec)
{
	fake_clock_gettime_log_count++;
	fake_clock_gettime_log_sec = sec;
	fake_clock_gettime_log_nsec = nsec;
}

void mcexec_kill_thread_bridge(unsigned long tid, unsigned long sig,
			       void *my_thread)
{
	fake_kill_thread_count++;
	fake_kill_thread_tid = tid;
	fake_kill_thread_sig = sig;
	fake_kill_thread_arg = my_thread;
}

struct fake_thread_data *mcexec_kill_thread_head_bridge(void)
{
	fake_kill_thread_head_count++;
	return thread_data;
}

int mcexec_kill_thread_pthread_kill_bridge(struct fake_thread_data *tp,
					   int sig)
{
	if (fake_kill_thread_pthread_count < 4) {
		fake_kill_thread_pthread_tp[fake_kill_thread_pthread_count] = tp;
		fake_kill_thread_pthread_sig[fake_kill_thread_pthread_count] = sig;
	}
	fake_kill_thread_pthread_count++;
	if (tp == fake_kill_thread_esrch_tp)
		return ESRCH;
	return 0;
}

void mcexec_kill_thread_not_found_bridge(unsigned long tid, int sig)
{
	fake_kill_thread_not_found_count++;
	fake_kill_thread_not_found_tid = tid;
	fake_kill_thread_not_found_sig = sig;
}

int mcexec_waitid_pid_bridge(int pid, int opt, int *errno_out)
{
	fake_mcexec_waitid_count++;
	fake_mcexec_waitid_pid = pid;
	fake_mcexec_waitid_opt = opt;
	if (errno_out)
		*errno_out = fake_mcexec_waitid_errno;
	return fake_mcexec_waitid_ret;
}

void mcexec_wait4_error_bridge(unsigned long requested_pid, int ret,
			       int errno_value)
{
	fake_mcexec_wait4_error_count++;
	fake_mcexec_wait4_error_requested = requested_pid;
	fake_mcexec_wait4_error_ret = ret;
	fake_mcexec_wait4_error_errno = errno_value;
}

void mcexec_gettid_alloc_error_bridge(void)
{
	fake_mcexec_gettid_alloc_error_count++;
}

void mcexec_gettid_transfer_error_bridge(void)
{
	fake_mcexec_gettid_transfer_error_count++;
}

void mcexec_debug_mlock_log_bridge(unsigned long addr, unsigned long len)
{
	fake_debug_mlock_log_count++;
	fake_debug_mlock_log_addr = addr;
	fake_debug_mlock_log_len = len;
}

long mcexec_debug_mlock_bridge(unsigned long addr, unsigned long len)
{
	fake_debug_mlock_count++;
	fake_debug_mlock_addr = addr;
	fake_debug_mlock_len = len;
	return fake_debug_mlock_ret;
}

void mcexec_swapout_unavailable_bridge(void)
{
	fake_swapout_unavailable_count++;
}

void mcexec_linux_spawn_invalid_arg_bridge(void)
{
	fake_linux_spawn_invalid_arg_count++;
}

void mcexec_linux_spawn_invalid_exec_path_bridge(void)
{
	fake_linux_spawn_invalid_exec_path_count++;
}

void mcexec_linux_spawn_alloc_exec_path_failed_bridge(void)
{
	fake_linux_spawn_alloc_exec_path_failed_count++;
}

void mcexec_linux_spawn_strncpy_failed_bridge(void)
{
	fake_linux_spawn_strncpy_failed_count++;
}

void mcexec_linux_spawn_alloc_argv_failed_bridge(int index)
{
	fake_linux_spawn_alloc_argv_failed_count++;
	fake_linux_spawn_alloc_argv_index = index;
}

void mcexec_linux_spawn_posix_spawn_failed_bridge(int rc)
{
	fake_linux_spawn_posix_failed_count++;
	fake_linux_spawn_posix_failed_rc = rc;
}

int posix_spawn(pid_t *pid, const char *path, const void *file_actions,
		const void *attrp, char *const argv[], char *const envp[])
{
	(void)file_actions;
	(void)attrp;

	fake_posix_spawn_count++;
	snprintf(fake_posix_spawn_path, sizeof(fake_posix_spawn_path), "%s",
		 path);
	fake_posix_spawn_envp_is_null = envp == NULL;
	fake_posix_spawn_argc = 0;
	memset(fake_posix_spawn_argv, 0, sizeof(fake_posix_spawn_argv));
	for (int i = 0; argv && argv[i] &&
	     i < (int)(sizeof(fake_posix_spawn_argv) /
		       sizeof(fake_posix_spawn_argv[0])); i++) {
		snprintf(fake_posix_spawn_argv[i],
			 sizeof(fake_posix_spawn_argv[i]), "%s", argv[i]);
		fake_posix_spawn_argc++;
	}
	if (pid)
		*pid = 4242;
	return fake_posix_spawn_ret;
}

void mcexec_fork_sync_lock_bridge(void)
{
	fake_fork_sync_lock_count++;
}

void mcexec_fork_sync_unlock_bridge(void)
{
	fake_fork_sync_unlock_count++;
}

void mcexec_fork_sync_munmap_bridge(void *fs)
{
	fake_fork_sync_munmap_count++;
	fake_fork_sync_munmap_ptr = fs;
}

	void mcexec_fork_sync_free_bridge(void *node)
	{
		fake_fork_sync_free_count++;
		fake_fork_sync_free_ptr = node;
	}

	void *mcexec_clone_alloc_fork_sync_bridge(void)
	{
		fake_clone_alloc_fs_count++;
		if (fake_clone_alloc_fs_result)
			memset(fake_clone_alloc_fs_result, 0,
			       sizeof(*fake_clone_alloc_fs_result));
		return fake_clone_alloc_fs_result;
	}

	void *mcexec_clone_alloc_container_bridge(void)
	{
		fake_clone_alloc_container_count++;
		if (fake_clone_alloc_container_result)
			memset(fake_clone_alloc_container_result, 0,
			       sizeof(*fake_clone_alloc_container_result));
		return fake_clone_alloc_container_result;
	}

	int mcexec_clone_fork_bridge(void)
	{
		fake_clone_fork_count++;
		errno = fake_clone_fork_errno;
		return fake_clone_fork_result;
	}

	void mcexec_clone_fork_failed_bridge(void)
	{
		fake_clone_fork_failed_count++;
	}

	long mcexec_clone_child_bridge(struct fake_mcexec_syscall_wait_desc *w,
				       void *fs)
	{
		fake_clone_child_count++;
		fake_clone_child_w = w;
		fake_clone_child_fs = fs;
		fork_sync_top = NULL;
		return fake_clone_child_ret;
	}

	int mcexec_clone_sem_trywait_bridge(void *fs)
	{
		int index = fake_clone_sem_trywait_count++;

		(void)fs;
		if (index < fake_clone_sem_trywait_len) {
			errno = fake_clone_sem_trywait_errno[index];
			return fake_clone_sem_trywait_result[index];
		}
		errno = 0;
		return 0;
	}

	int mcexec_clone_waitpid_nohang_bridge(int pid)
	{
		fake_clone_waitpid_count++;
		fake_clone_waitpid_pid = pid;
		return fake_clone_waitpid_result;
	}

	void mcexec_clone_sched_yield_bridge(void)
	{
		fake_clone_sched_yield_count++;
	}

	void mcexec_clone_child_after_fork_failed_bridge(void)
	{
		fake_clone_child_failed_count++;
	}

	void mcexec_clone_sem_destroy_bridge(void *fs)
	{
		fake_clone_sem_destroy_count++;
		fake_clone_sem_destroy_ptr = fs;
	}

	static void reset_clone_start_fakes(struct fake_fork_sync *fs,
					    struct fake_fork_sync_container *node,
					    int fork_result)
	{
		fake_clone_alloc_fs_result = fs;
		fake_clone_alloc_fs_count = 0;
		fake_clone_alloc_container_result = node;
		fake_clone_alloc_container_count = 0;
		fake_clone_fork_result = fork_result;
		fake_clone_fork_errno = 0;
		fake_clone_fork_count = 0;
		fake_clone_fork_failed_count = 0;
		fake_clone_sem_trywait_count = 0;
		fake_clone_sem_trywait_len = 0;
		memset(fake_clone_sem_trywait_result, 0,
		       sizeof(fake_clone_sem_trywait_result));
		memset(fake_clone_sem_trywait_errno, 0,
		       sizeof(fake_clone_sem_trywait_errno));
		fake_clone_waitpid_count = 0;
		fake_clone_waitpid_pid = 0;
		fake_clone_waitpid_result = 0;
		fake_clone_sched_yield_count = 0;
		fake_clone_child_failed_count = 0;
		fake_clone_sem_destroy_count = 0;
		fake_clone_sem_destroy_ptr = NULL;
		fake_clone_child_count = 0;
		fake_clone_child_w = NULL;
		fake_clone_child_fs = NULL;
		fake_clone_child_ret = 0;
		fake_fork_sync_lock_count = 0;
		fake_fork_sync_unlock_count = 0;
		fake_fork_sync_munmap_count = 0;
		fake_fork_sync_munmap_ptr = NULL;
		fake_fork_sync_free_count = 0;
		fake_fork_sync_free_ptr = NULL;
		fake_ioctl_ret_count = 0;
		memset(&fake_ret_desc, 0, sizeof(fake_ret_desc));
	}

	void mcexec_exit_debug_bridge(unsigned long status, int cpu)
	{
	fake_mcexec_exit_debug_count++;
	fake_mcexec_exit_debug_status = status;
	fake_mcexec_exit_debug_cpu = cpu;
}

int mcexec_exit_isatty_bridge(int fd)
{
	fake_mcexec_exit_isatty_fd = fd;
	return fake_mcexec_exit_isatty_result;
}

void mcexec_exit_report_signal_bridge(int sig)
{
	fake_mcexec_exit_report_signal_count++;
	fake_mcexec_exit_report_signal_sig = sig;
}

void mcexec_exit_report_status_bridge(int term)
{
	fake_mcexec_exit_report_status_count++;
	fake_mcexec_exit_report_status_term = term;
}

void mcexec_exit_cmd_servers_bridge(void)
{
	fake_mcexec_exit_cmd_servers_count++;
}

void mcexec_exit_replay_signal_bridge(int sig)
{
	fake_mcexec_exit_replay_signal_count++;
	fake_mcexec_exit_replay_signal_sig = sig;
}

void mcexec_exit_process_bridge(int term)
{
	fake_mcexec_exit_process_count++;
	fake_mcexec_exit_process_term = term;
}

void mcexec_execve2_alloc_desc_failed_bridge(void)
{
	fake_execve2_alloc_desc_failed_count++;
}

void mcexec_execve2_transfer_desc_failed_bridge(void)
{
	fake_execve2_transfer_desc_failed_count++;
}

void mcexec_execve2_transfer_desc_ok_bridge(void)
{
	fake_execve2_transfer_desc_ok_count++;
}

void mcexec_execve2_transfer_image_failed_bridge(void)
{
	fake_execve2_transfer_image_failed_count++;
}

void mcexec_execve2_image_transferred_bridge(void)
{
	fake_execve2_image_transferred_count++;
}

void mcexec_execve2_close_exec_failed_bridge(int ret)
{
	fake_execve2_close_exec_failed_count++;
	fake_execve2_close_exec_failed_ret = ret;
}

int pipe2(int pipefd[2], int flags)
{
	fake_pipe2_count++;
	fake_pipe2_flags = flags;
	if (fake_pipe2_result < 0) {
		errno = EIO;
		return fake_pipe2_result;
	}
	pipefd[0] = fake_pipe2_read_fd;
	pipefd[1] = fake_pipe2_write_fd;
	return fake_pipe2_result;
}

void mcexec_init_sigaction_set_master_tid_bridge(int tid)
{
	fake_init_sigaction_master_tid = tid;
}

void mcexec_init_sigaction_install_bridge(int sig)
{
	if (sig < 0 || sig >= (int)(sizeof(fake_init_sigaction_seen) /
				    sizeof(fake_init_sigaction_seen[0]))) {
		fprintf(stderr, "unexpected signal %d\n", sig);
		abort();
	}
	fake_init_sigaction_count++;
	fake_init_sigaction_seen[sig]++;
	fake_init_sigaction_digest ^= (unsigned long)sig << (sig % 8);
}

void mcexec_act_sigaction_install_bridge(int sig, int ignored)
{
	fake_act_sigaction_count++;
	fake_act_sigaction_last_sig = sig;
	fake_act_sigaction_last_ignored = ignored;
	fake_act_sigaction_digest ^= (unsigned long)sig << (ignored ? 3 : 1);
}

void mcexec_act_sigprocmask_apply_bridge(unsigned long mask)
{
	fake_act_sigprocmask_count++;
	fake_act_sigprocmask_mask = mask;
	fake_act_sigprocmask_digest ^= mask;
}

ssize_t mcexec_act_signalfd4_write_bridge(int fd, const void *info,
					  size_t len)
{
	const unsigned char *bytes = info;

	fake_act_signalfd4_write_count++;
	fake_act_signalfd4_write_fd = fd;
	fake_act_signalfd4_write_len = len;
	fake_act_signalfd4_write_digest ^= (unsigned long)fd;
	fake_act_signalfd4_write_digest ^= (unsigned long)len << 4;
	for (size_t i = 0; i < len; i += 17) {
		fake_act_signalfd4_write_digest ^=
			(unsigned long)bytes[i] << (i % 8);
	}
	return fake_act_signalfd4_write_result;
}

void mcexec_act_signalfd4_write_error_bridge(void)
{
	fake_act_signalfd4_write_error_count++;
}

int mcexec_sendsig_si_pid_bridge(const void *siginfo)
{
	return ((const struct fake_sendsig_siginfo *)siginfo)->si_pid;
}

int mcexec_sendsig_si_signo_bridge(const void *siginfo)
{
	return ((const struct fake_sendsig_siginfo *)siginfo)->si_signo;
}

void mcexec_sendsig_default_action_bridge(int sig)
{
	fake_sendsig_default_count++;
	fake_sendsig_default_sig = sig;
}

void fake_sendsig_handler(int sig, void *siginfo, void *context)
{
	fake_sendsig_handler_count++;
	fake_sendsig_handler_sig = sig;
	fake_sendsig_handler_info = siginfo;
	fake_sendsig_handler_context = context;
}

void mcexec_init_worker_threads_lock_init_bridge(void)
{
	fake_worker_lock_init_count++;
}

void mcexec_init_worker_threads_barrier_init_bridge(int count)
{
	fake_worker_barrier_count = count;
}

void mcexec_init_worker_threads_reset_cpuid_bridge(void)
{
	fake_worker_reset_count++;
}

int mcexec_init_worker_threads_create_bridge(void)
{
	fake_worker_create_count++;
	if (fake_worker_create_fail_at == fake_worker_create_count)
		return 17;
	return 0;
}

void mcexec_init_worker_threads_wait_bridge(void)
{
	fake_worker_wait_count++;
}

void mcexec_init_worker_threads_error_bridge(int ret)
{
	fake_worker_error_count++;
	fake_worker_error_ret = ret;
}

int mcexec_get_thp_disable_prctl_bridge(void)
{
	fake_thp_prctl_count++;
	return fake_thp_prctl_ret;
}

int mcexec_numa_node_cpu_isset_bridge(int node, int cpu)
{
	fake_numa_node_cpu_isset_count++;
	if (node < 0 || node >= 4)
		return 0;
	return test_bit(cpu, &fake_numa_node_cpu_mask[node]);
}

void mcexec_numa_local_cpu_log_bridge(int cpu)
{
	(void)cpu;
	fake_numa_local_log_count++;
}

void mcexec_numa_node_cpu_log_bridge(int cpu, int node)
{
	(void)cpu;
	(void)node;
	fake_numa_node_log_count++;
}

int mcexec_opendev_mcosid_bridge(void)
{
	return fake_opendev_mcosid;
}

char *mcexec_opendev_dev_bridge(void)
{
	return fake_opendev_dev;
}

size_t mcexec_opendev_dev_size_bridge(void)
{
	return fake_opendev_dev_size;
}

void mcexec_opendev_path_error_bridge(void)
{
	fake_opendev_path_error_count++;
}

int mcexec_opendev_open_bridge(const char *path)
{
	fake_opendev_open_count++;
	snprintf(fake_opendev_open_path, sizeof(fake_opendev_open_path),
		 "%s", path);
	return fake_opendev_open_ret;
}

void mcexec_opendev_open_error_bridge(const char *path)
{
	(void)path;
	fake_opendev_open_error_count++;
}

void mcexec_opendev_publish_fd_bridge(int value)
{
	fake_opendev_publish_count++;
	fake_opendev_publish_fd = value;
	fd = value;
}

size_t mcexec_opendev_buildid_size_bridge(void)
{
	return sizeof(fake_opendev_buildid);
}

const char *mcexec_opendev_buildid_bridge(void)
{
	return (const char *)fake_opendev_buildid;
}

char *mcexec_opendev_query_result_bridge(void)
{
	memset(fake_opendev_query_result, 0,
	       sizeof(fake_opendev_query_result));
	return (char *)fake_opendev_query_result;
}

int mcexec_opendev_query_buildid_bridge(int target_fd, char *query_result)
{
	fake_opendev_query_count++;
	fake_opendev_query_fd = target_fd;
	memcpy(query_result, fake_opendev_query_value,
	       sizeof(fake_opendev_query_value));
	return fake_opendev_query_ret;
}

void mcexec_opendev_query_error_bridge(void)
{
	fake_opendev_query_error_count++;
}

void mcexec_opendev_close_bridge(int target_fd)
{
	fake_opendev_close_count++;
	fake_opendev_close_fd = target_fd;
}

void mcexec_opendev_buildid_mismatch_bridge(const char *buildid,
					    const char *query_result)
{
	(void)buildid;
	(void)query_result;
	fake_opendev_mismatch_count++;
}

void mcexec_add_env_list_invalid_bridge(const char *add_string)
{
	fake_env_invalid_count++;
	snprintf(fake_env_invalid_value, sizeof(fake_env_invalid_value),
		 "%s", add_string);
}

int mcexec_overlay_mcosid_bridge(void)
{
	return fake_overlay_mcosid;
}

int mcexec_overlay_stat_exists_bridge(const char *path)
{
	fake_overlay_stat_count++;
	snprintf(fake_overlay_stat_path, sizeof(fake_overlay_stat_path), "%s",
		 path);
	return fake_overlay_stat_result;
}

int mcexec_overlay_cpu_in_node_bridge(int cpu, int node)
{
	fake_overlay_cpu_node_count++;
	fake_overlay_cpu_node_cpu = cpu;
	fake_overlay_cpu_node_node = node;
	return fake_overlay_cpu_node_result;
}

void mcexec_overlay_addfd_path_too_long_bridge(void)
{
	fake_overlay_addfd_too_long_count++;
}

int mcexec_overlay_addfd_publish_bridge(int fd, const char *linux_path,
					const char *mck_path, size_t pathlen)
{
	fake_overlay_addfd_publish_count++;
	fake_overlay_addfd_publish_fd = fd;
	snprintf(fake_overlay_addfd_linux_path,
		 sizeof(fake_overlay_addfd_linux_path), "%s", linux_path);
	snprintf(fake_overlay_addfd_mck_path, sizeof(fake_overlay_addfd_mck_path),
		 "%s", mck_path);
	fake_overlay_addfd_pathlen = pathlen;
	return 0;
}

void mcexec_overlay_delfd_bridge(int fd)
{
	fake_overlay_delfd_count++;
	fake_overlay_delfd_fd = fd;
}

int mcexec_overlay_enable_uti_bridge(void)
{
	return fake_overlay_enable_uti;
}

int mcexec_overlay_find_libdir_bridge(char *out, size_t size)
{
	if (fake_overlay_find_libdir_result < 0)
		return fake_overlay_find_libdir_result;
	snprintf(out, size, "%s", fake_overlay_libdir);
	return 0;
}

ssize_t mcexec_overlay_readlink_bridge(const char *path, char *out,
				       size_t size)
{
	size_t len;

	fake_overlay_readlink_count++;
	snprintf(fake_overlay_readlink_path, sizeof(fake_overlay_readlink_path),
		 "%s", path);
	if (fake_overlay_readlink_result < 0) {
		errno = EINVAL;
		return fake_overlay_readlink_result;
	}
	if (fake_overlay_readlink_result > 0)
		len = (size_t)fake_overlay_readlink_result;
	else
		len = strlen(fake_overlay_readlink_target);
	if (len > size)
		len = size;
	memcpy(out, fake_overlay_readlink_target, len);
	return (ssize_t)len;
}

int mcexec_overlay_lstat_is_symlink_bridge(const char *path, int *is_symlink)
{
	fake_overlay_lstat_count++;
	snprintf(fake_overlay_lstat_path, sizeof(fake_overlay_lstat_path), "%s",
		 path);
	if (fake_overlay_lstat_result < 0)
		return fake_overlay_lstat_result;
	*is_symlink = fake_overlay_lstat_is_symlink;
	return 0;
}

int mcexec_overlay_stat_errno_bridge(const char *path)
{
	fake_overlay_stat_errno_count++;
	snprintf(fake_overlay_stat_errno_path,
		 sizeof(fake_overlay_stat_errno_path), "%s", path);
	return fake_overlay_stat_errno_result;
}

int mcexec_overlay_mapped_proc_task_parent_exists_bridge(const char *mapped)
{
	fake_overlay_parent_exists_count++;
	snprintf(fake_overlay_parent_exists_path,
		 sizeof(fake_overlay_parent_exists_path), "%s", mapped);
	return fake_overlay_parent_exists_result;
}

void mcexec_overlay_considering_bridge(int dirfd, const char *path)
{
	(void)dirfd;
	(void)path;
	fake_overlay_considering_count++;
}

void mcexec_overlay_fd_path_truncated_bridge(int dirfd)
{
	(void)dirfd;
	fake_overlay_fd_truncated_count++;
}

void mcexec_overlay_readlink_fd_failed_bridge(int dirfd, int error)
{
	(void)dirfd;
	(void)error;
	fake_overlay_readlink_failed_count++;
}

void mcexec_overlay_truncated_bridge(const char *path)
{
	(void)path;
	fake_overlay_truncated_count++;
}

void mcexec_overlay_getcwd_failed_bridge(int error)
{
	(void)error;
	fake_overlay_getcwd_failed_count++;
}

void mcexec_overlay_glued_bridge(const char *path)
{
	(void)path;
	fake_overlay_glued_count++;
}

void mcexec_overlay_find_libdir_failed_bridge(void)
{
	fake_overlay_find_libdir_failed_count++;
}

void mcexec_overlay_replaced_bridge(const char *path, const char *mapped)
{
	(void)path;
	(void)mapped;
	fake_overlay_replaced_count++;
}

void mcexec_overlay_trying_bridge(const char *path, int error)
{
	(void)path;
	(void)error;
	fake_overlay_trying_count++;
}

void mcexec_overlay_blacklisted_bridge(const char *path)
{
	(void)path;
	fake_overlay_blacklisted_count++;
}

void *mcexec_overlay_getdents_find_bridge(int fd)
{
	return fd == fake_overlay_getdents_fd ? fake_overlay_getdents_ofd : NULL;
}

int mcexec_overlay_getdents_hide_orig_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_hide_orig;
}

const char *mcexec_overlay_getdents_linux_path_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_linux_path;
}

size_t mcexec_overlay_getdents_pathlen_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_pathlen;
}

void *mcexec_overlay_getdents_mck_dirents_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_mck_cache;
}

size_t mcexec_overlay_getdents_mck_size_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_mck_cache_size;
}

void *mcexec_overlay_getdents_linux_dirents_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_linux_cache;
}

size_t mcexec_overlay_getdents_linux_size_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_linux_cache_size;
}

int mcexec_overlay_getdents_mck_fd_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_mck_fd;
}

int mcexec_overlay_getdents_linux_fd_bridge(void *ofd)
{
	(void)ofd;
	return fake_overlay_getdents_linux_fd;
}

int mcexec_overlay_getdents_append_mck_bridge(void *ofd, const void *dirp,
					      size_t len, int is64)
{
	int rc;

	(void)ofd;
	require(fake_overlay_getdents_mck_cache_size + len <=
		sizeof(fake_overlay_getdents_mck_cache));
	memcpy(fake_overlay_getdents_mck_cache +
	       fake_overlay_getdents_mck_cache_size, dirp, len);
	rc = mcexec_dirent_rewrite_offsets_result(
		fake_overlay_getdents_mck_cache,
		fake_overlay_getdents_mck_cache_size,
		fake_overlay_getdents_mck_cache_size + len, 0, is64);
	if (rc < 0)
		return rc;
	fake_overlay_getdents_mck_cache_size += len;
	fake_overlay_getdents_append_mck_count++;
	return 0;
}

int mcexec_overlay_getdents_append_linux_bridge(void *ofd, const void *dirp,
						size_t len, int is64,
						int old_ret)
{
	int rc;

	(void)ofd;
	(void)old_ret;
	require(fake_overlay_getdents_linux_cache_size + len <=
		sizeof(fake_overlay_getdents_linux_cache));
	memcpy(fake_overlay_getdents_linux_cache +
	       fake_overlay_getdents_linux_cache_size, dirp, len);
	fake_overlay_getdents_linux_cache_size += len;
	rc = mcexec_dirent_rewrite_offsets_result(
		fake_overlay_getdents_linux_cache, 0,
		fake_overlay_getdents_linux_cache_size,
		fake_overlay_getdents_mck_cache_size, is64);
	if (rc < 0)
		return rc;
	fake_overlay_getdents_append_linux_count++;
	return 0;
}

void mcexec_overlay_getdents_offset_bridge(long offset)
{
	(void)offset;
	fake_overlay_getdents_offset_log_count++;
}

void mcexec_overlay_getdents_upper_bridge(int mck_ret, int ret,
					  unsigned int count)
{
	(void)mck_ret;
	(void)ret;
	(void)count;
	fake_overlay_getdents_upper_log_count++;
}

void mcexec_overlay_getdents_lower_failed_bridge(int error)
{
	(void)error;
}

void mcexec_overlay_getdents_blacklisted_bridge(const char *path)
{
	(void)path;
	fake_overlay_getdents_blacklisted_log_count++;
}

void mcexec_overlay_getdents_dupe_bridge(const char *name)
{
	(void)name;
	fake_overlay_getdents_dupe_log_count++;
}

void mcexec_overlay_getdents_lower_bridge(int linux_ret, int ret,
					  unsigned int count)
{
	(void)linux_ret;
	(void)ret;
	(void)count;
	fake_overlay_getdents_lower_log_count++;
}

void mcexec_overlay_getdents_offset_too_large_bridge(long offset,
						     size_t mck_size,
						     size_t linux_size)
{
	(void)offset;
	(void)mck_size;
	(void)linux_size;
}

void mcexec_overlay_getdents_upper_small_bridge(void)
{
	fake_overlay_getdents_upper_small_count++;
}

void mcexec_overlay_getdents_lower_small_bridge(void)
{
	fake_overlay_getdents_lower_small_count++;
}

void mcexec_overlay_getdents_mck_size_log_bridge(size_t size, long offset,
						 int len,
						 unsigned int count)
{
	(void)size;
	(void)offset;
	(void)len;
	(void)count;
	fake_overlay_getdents_mck_size_log_count++;
}

void mcexec_overlay_getdents_linux_size_log_bridge(size_t size, long offset,
						   int len,
						   unsigned int count)
{
	(void)size;
	(void)offset;
	(void)len;
	(void)count;
	fake_overlay_getdents_linux_size_log_count++;
}

int main(void)
{
	char out[512];
	char long_path[4096];
	char huge_path[8192];
	char limited[255 + 1];
	char desc_blob[16];
	char dirents[96];
	unsigned char transfer_file[32];
	unsigned char dma_area[32];
	char *argv_flat;
	char *argv_flat2;
	char *argv_flat_public;
	unsigned char siginfo_blob[128];
	struct fake_sendsig_siginfo sendsig_info;
	int sendsig_context;
	char *buffer;
	char *search_result;
	const char *overlay_mapped;
	char atobytes_empty[] = "";
	char atobytes_kib[] = "2K";
	char *flat_argv0[] = { "cmd", "arg", NULL };
	char *flat_argv1[] = { "tail", NULL };
	char *shebang_argv0[] = { "script", NULL };
	char *usage_argv[] = { "mcexec", NULL };
	char *reduce_argv[] = { "mcexec", "prog", NULL };
	char **shebang_argv;
	char shebang0[] = "/usr/bin/env python";
	char shebang1[] = "/bin/sh";
	char shebang_recursive0[] = "script";
	char tmp_template[] = "/tmp/mcexec-smoke-XXXXXX";
	char *tmpdir;
	char script_path[PATH_MAX];
	char interp_path_file[PATH_MAX];
	char search_direct[] = "/bin/direct";
	char search_missing[] = "/bin/missing";
	char lookup_tool[] = "tool";
	char lookup_local[] = "local";
	char lookup_relative[] = "dir/app";
	char lookup_absolute[] = "/bin/app";
	char *print_flat_buf;
	char remote_dest;
	char remote_src;
	long print_flat_storage[8];
	unsigned long bitwords[2] = { 0 };
	unsigned long digest = 0x6d636578656370UL;
	unsigned long planned_heap;
	unsigned long heap_extension;
	unsigned long mcexec_flags;
	unsigned long mpol_threshold;
	unsigned long straight_map_threshold;
	int i;
	int nr_processes;
	int nr_threads;
	int planned_mcosid;
	int planned_optind;
	int argv_flat2_len;
	int rc;
	int resolvelinks;
	int report_sig;
	int report_status;
	int sig;
	int target_core;
	int tids[5];
	int term;
	int uti_thread_rank;
	long lrc;
	long stack_max;
	long stack_premap;
	size_t d0;
	size_t d1;
	size_t transfer_size;
	unsigned int dirent_count;
	FILE *tmp_fp;
	FILE *transfer_fp;
	FILE *interp_fp;
	size_t interp_desc_size;
	void *fs_out;
	void *node_out;
	void *load_desc_out;
	long *flat_words;
	struct fake_program_desc *interp_desc;
	struct fake_program_desc *interp_loaded;
	Elf64_Ehdr interp_hdr;
	Elf64_Phdr interp_phdrs[2];
	struct fake_syscall_args regs;
	struct fake_thread_data th4 = { .tid = 44 };
	struct fake_thread_data th3 = { .next = &th4, .tid = 33, .terminate = 1 };
	struct fake_thread_data th2 = { .next = &th3, .tid = 22, .joined = 1 };
	struct fake_thread_data th1 = { .next = &th2, .tid = 11 };
	struct fake_thread_data sig_thread2 = { .tid = 202 };
	struct fake_thread_data sig_thread1 = { .next = &sig_thread2 };
	struct fake_fork_sync fs1 = { 0 };
	struct fake_fork_sync fs2 = { 0 };
	struct fake_fork_sync fs3 = { 0 };
	struct fake_fork_sync_container f3 = { .pid = 303, .fs = &fs3 };
	struct fake_fork_sync_container f2 = { .pid = 202, .next = &f3, .fs = &fs2 };
	struct fake_fork_sync_container f1 = { .pid = 101, .next = &f2, .fs = &fs1 };
	struct fake_fork_sync_container *fork_top = &f1;
	struct fake_program_desc print_desc_fake;
	struct fake_mcexec_syscall_wait_desc sigwait;

	tmpdir = mkdtemp(tmp_template);
	require(tmpdir != NULL);
	require(snprintf(script_path, sizeof(script_path), "%s/script",
			 tmpdir) < (int)sizeof(script_path));
	require(snprintf(interp_path_file, sizeof(interp_path_file),
			 "%s/interp", tmpdir) < (int)sizeof(interp_path_file));
	tmp_fp = fopen(script_path, "wb");
	require(tmp_fp != NULL);
	require(fputs("#! interp -S\n", tmp_fp) >= 0);
	require(fclose(tmp_fp) == 0);
	tmp_fp = fopen(interp_path_file, "wb");
	require(tmp_fp != NULL);
	memset(&interp_hdr, 0, sizeof(interp_hdr));
	memcpy(interp_hdr.e_ident, ELFMAG, SELFMAG);
	interp_hdr.e_type = ET_DYN;
	interp_hdr.e_entry = 0x401020;
	interp_hdr.e_phoff = sizeof(interp_hdr);
	interp_hdr.e_phnum = 2;
	memset(interp_phdrs, 0, sizeof(interp_phdrs));
	interp_phdrs[0].p_type = PT_LOAD;
	interp_phdrs[0].p_flags = PF_R | PF_X;
	interp_phdrs[0].p_offset = 0x100;
	interp_phdrs[0].p_vaddr = 0x401000;
	interp_phdrs[0].p_filesz = 0x20;
	interp_phdrs[0].p_memsz = 0x30;
	interp_phdrs[1].p_type = PT_GNU_STACK;
	interp_phdrs[1].p_flags = PF_R | PF_W;
	require(fwrite(&interp_hdr, 1, sizeof(interp_hdr), tmp_fp) ==
		sizeof(interp_hdr));
	require(fwrite(interp_phdrs, 1, sizeof(interp_phdrs), tmp_fp) ==
		sizeof(interp_phdrs));
	require(fclose(tmp_fp) == 0);

	memset(&regs, 0, sizeof(regs));
	set_syscall_number(&regs, 231);
	set_syscall_return(&regs, (unsigned long)-ENOSYS);
	set_syscall_arg1(&regs, 0x1111);
	set_syscall_arg2(&regs, 0x2222);
	set_syscall_arg3(&regs, 0x3333);
	set_syscall_arg4(&regs, 0x4444);
	set_syscall_arg5(&regs, 0x5555);
	set_syscall_arg6(&regs, 0x6666);
	regs.rip = 0x7777;
	require(get_syscall_number(&regs) == 231);
	require(get_syscall_return(&regs) == (unsigned long)-ENOSYS);
	require(get_syscall_arg1(&regs) == 0x1111);
	require(get_syscall_arg2(&regs) == 0x2222);
	require(get_syscall_arg3(&regs) == 0x3333);
	require(get_syscall_arg4(&regs) == 0x4444);
	require(get_syscall_arg5(&regs) == 0x5555);
	require(get_syscall_arg6(&regs) == 0x6666);
	require(get_syscall_rip(&regs) == 0x7777);
	require(syscall_enter(&regs) == 1);
	set_syscall_return(&regs, 0);
	require(syscall_enter(&regs) == 0);
	mix(&digest, get_syscall_number(&regs));
	mix(&digest, get_syscall_arg6(&regs));
	mix(&digest, get_syscall_rip(&regs));
	set_bit(1, bitwords);
	set_bit(40, bitwords);
	require(test_bit(1, bitwords) == 1);
	require(test_bit(40, bitwords) == 1);
	require(test_bit(2, bitwords) == 0);
	require(bitwords[0] == ((1UL << 1) | (1UL << 40)));
	clear_bit(1, bitwords);
	require(test_bit(1, bitwords) == 0);
	require(test_bit(40, bitwords) == 1);
	mix(&digest, bitwords[0]);

	require(mcexec_path_is_absolute_result("/bin/hostname") == 1);
	require(mcexec_path_is_absolute_result("bin/hostname") == 0);
	require(mcexec_path_is_absolute_result("") == 0);

	require(mcexec_path_is_single_component_exec_result("hostname") == 1);
	require(mcexec_path_is_single_component_exec_result("") == 1);
	require(mcexec_path_is_single_component_exec_result("./hostname") == 0);
	require(mcexec_path_is_single_component_exec_result(".hidden") == 0);
	require(mcexec_path_is_single_component_exec_result("bin/hostname") == 0);
	require(mcexec_path_is_single_component_exec_result("/bin/hostname") == 0);

	unsetenv("COKERNEL_EXEC_ROOT");
	require(setenv("COKERNEL_PATH", "/nope:/hit:", 1) == 0);
	fake_access_hit = "/hit/tool";
	fake_access_count = 0;
	fake_lookup_lstat_count = 0;
	fake_lookup_lstat_result = 0;
	fake_lookup_success_count = 0;
	memset(out, 0, sizeof(out));
	require(lookup_exec_path(lookup_tool, out, sizeof(out), 1) == 0);
	require(strcmp(out, "/hit/tool") == 0);
	require(fake_access_count == 2);
	require(fake_access_mode == X_OK);
	require(fake_lookup_lstat_count == 1);
	require(strcmp(fake_lookup_lstat_path, "/hit/tool") == 0);
	require(fake_lookup_success_count == 1);

	require(setenv("COKERNEL_PATH", "/miss:", 1) == 0);
	fake_access_hit = "/tool";
	fake_access_count = 0;
	fake_lookup_lstat_count = 0;
	memset(out, 0, sizeof(out));
	require(lookup_exec_path(lookup_tool, out, sizeof(out), 1) == 0);
	require(strcmp(out, "/tool") == 0);
	require(fake_access_count == 2);
	require(fake_lookup_lstat_count == 1);

	fake_access_hit = "local";
	fake_access_count = 0;
	fake_lookup_lstat_count = 0;
	memset(out, 0, sizeof(out));
	require(lookup_exec_path(lookup_local, out, sizeof(out), 0) == 0);
	require(strcmp(out, "local") == 0);
	require(fake_access_count == 1);
	require(fake_lookup_lstat_count == 1);

	fake_access_hit = NULL;
	fake_access_count = 0;
	fake_lookup_lstat_count = 0;
	require(lookup_exec_path(lookup_local, out, sizeof(out), 0) == ENOENT);
	require(fake_access_count == 1);
	require(fake_lookup_lstat_count == 0);

	fake_lookup_lstat_count = 0;
	memset(out, 0, sizeof(out));
	require(lookup_exec_path(lookup_relative, out, sizeof(out), 1) == 0);
	require(strcmp(out, "dir/app") == 0);
	require(fake_lookup_lstat_count == 1);

	require(setenv("COKERNEL_EXEC_ROOT", "/root", 1) == 0);
	fake_lookup_lstat_result = 0;
	fake_lookup_lstat_count = 0;
	memset(out, 0, sizeof(out));
	require(lookup_exec_path(lookup_absolute, out, sizeof(out), 1) == 0);
	require(strcmp(out, "/root//bin/app") == 0);
	require(fake_lookup_lstat_count == 1);

	fake_lookup_lstat_result = EACCES;
	fake_lookup_stat_error_count = 0;
	require(lookup_exec_path(lookup_absolute, out, sizeof(out), 1) == EACCES);
	require(fake_lookup_stat_error_count == 1);
	fake_lookup_lstat_result = 0;

	require(lookup_exec_path(lookup_local, out, 3, 0) == ENAMETOOLONG);
	memset(limited, 'x', 255);
	limited[255] = '\0';
	require(lookup_exec_path(limited, out, sizeof(out), 1) ==
		ENAMETOOLONG);
	unsetenv("COKERNEL_PATH");
	unsetenv("COKERNEL_EXEC_ROOT");
	mix(&digest, (unsigned long)fake_access_count);
	mix(&digest, (unsigned long)fake_lookup_lstat_count);
	mix(&digest, (unsigned long)out[1]);

	require(setenv("COKERNEL_PATH", tmpdir, 1) == 0);
	fake_access_hit = NULL;
	fake_access_hit_prefix = tmpdir;
	fake_lookup_lstat_result = 0;
	fake_load_elf_desc_result = 0;
	fake_load_desc_stat_count = 0;
	fake_load_desc_stat_result = 0;
	fake_load_desc_sections_count = 0;
	fake_load_desc_exec_path_count = 0;
	fake_load_section_count = 0;
	fake_load_finalize_count = 0;
	fake_load_cred_bridge_count = 0;
	fake_ioctl_get_cred_count = 0;
	fake_load_digest = 0;
	memset(fake_load_desc_exec_path, 0, sizeof(fake_load_desc_exec_path));
	fake_load_shebang_find_error_count = 0;
	fake_load_shebang_load_error_count = 0;
	fake_ioctl_open_exec_count = 0;
	memset(fake_ioctl_open_exec_path, 0, sizeof(fake_ioctl_open_exec_path));
	shebang_argv = NULL;
	load_desc_out = NULL;
	rc = load_elf_desc_shebang(shebang_recursive0, &load_desc_out,
				   &shebang_argv, 1);
	require(rc == 0);
	require(load_desc_out != NULL);
	require(fake_load_desc_stat_count == 2);
	require(strcmp(fake_load_elf_desc_path, interp_path_file) == 0);
	require(fake_ioctl_open_exec_count == 1);
	require(strcmp(fake_ioctl_open_exec_path, interp_path_file) == 0);
	require(fake_load_desc_exec_path_count == 1);
	require(strcmp(fake_load_desc_exec_path, interp_path_file) == 0);
	require(fake_load_section_count == 1);
	require(fake_load_finalize_count == 1);
	require(fake_load_cred_bridge_count == 1);
	require(fake_ioctl_get_cred_count == 1);
	require(((struct fake_program_desc *)load_desc_out)->num_sections == 1);
	require(((struct fake_program_desc *)load_desc_out)->entry == 0x401020);
	require(((struct fake_program_desc *)load_desc_out)->stack_prot ==
		(PROT_READ | PROT_WRITE));
	require(((struct fake_program_desc *)load_desc_out)->reloc == 0);
	require(((struct fake_program_desc *)load_desc_out)->at_phdr ==
		0x401000 - 0x100 + sizeof(Elf64_Ehdr));
	require(((struct fake_program_desc *)load_desc_out)->at_phent ==
		sizeof(Elf64_Phdr));
	require(((struct fake_program_desc *)load_desc_out)->at_phnum == 2);
	require(((struct fake_program_desc *)load_desc_out)->at_entry ==
		0x401020);
	require(((struct fake_program_desc *)load_desc_out)->at_clktck == 100);
	require(((struct fake_program_desc *)load_desc_out)->sections[0].vaddr ==
		0x401000);
	require(((struct fake_program_desc *)load_desc_out)->sections[0].filesz ==
		0x20);
	require(((struct fake_program_desc *)load_desc_out)->sections[0].offset ==
		0x100);
	require(((struct fake_program_desc *)load_desc_out)->sections[0].len ==
		0x30);
	require(((struct fake_program_desc *)load_desc_out)->sections[0].prot ==
		(PROT_READ | PROT_EXEC));
	require(((struct fake_program_desc *)load_desc_out)->sections[0].interp ==
		0);
	require(fake_load_desc_sections_count == 1);
	require(fake_load_desc_sections_value == 1);
	require(shebang_argv != NULL);
	require(strcmp(shebang_argv[0], "interp") == 0);
	require(strcmp(shebang_argv[1], "-S") == 0);
	require(shebang_argv[2] == NULL);
	require(fake_load_shebang_find_error_count == 0);
	require(fake_load_shebang_load_error_count == 0);
	free(shebang_argv);
	free(load_desc_out);

	fake_access_hit_prefix = NULL;
	fake_access_hit = NULL;
	fake_load_shebang_find_error_count = 0;
	rc = load_elf_desc_shebang(shebang_recursive0, &load_desc_out,
				   NULL, 1);
	require(rc == ENOENT);
	require(fake_load_shebang_find_error_count == 1);

	fake_access_hit_prefix = tmpdir;
	fake_load_desc_stat_result = EIO;
	fake_load_shebang_load_error_count = 0;
	rc = load_elf_desc_shebang(shebang_recursive0, &load_desc_out,
				   NULL, 1);
	require(rc == EIO);
	require(fake_load_shebang_load_error_count == 1);
	fake_load_desc_stat_result = 0;
	fake_access_hit_prefix = NULL;
	unsetenv("COKERNEL_PATH");
	mix(&digest, fake_load_digest);
	mix(&digest, (unsigned long)fake_load_shebang_find_error_count);
	mix(&digest, (unsigned long)fake_load_shebang_load_error_count);

	target_core = 0;
	nr_processes = 0;
	nr_threads = 0;
	mpol_threshold = 0;
	heap_extension = 0;
	straight_map_threshold = 0;
	stack_premap = 0;
	stack_max = 0;
	uti_thread_rank = 0;
	mcexec_flags = 0;
	require(mcexec_apply_option_result('c', "0x10", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(target_core == 16);
	require(mcexec_apply_option_result('n', "3", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(nr_processes == 3);
	require(mcexec_apply_option_result('t', "4", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(nr_threads == 4);
	require(mcexec_apply_option_result('n', "0", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == -EINVAL);
	require(mcexec_apply_option_result('M', "2M", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(mpol_threshold == 2UL * 1024 * 1024);
	require(mcexec_apply_option_result('h', "1G", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(heap_extension == 1024UL * 1024 * 1024);
	require(mcexec_apply_option_result('S', "64K", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(straight_map_threshold == 64UL * 1024);
	require(mcexec_apply_option_result('s', "8K,16K", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(stack_premap == 8L * 1024);
	require(stack_max == 16L * 1024);
	require(mcexec_apply_option_result('u', "-2", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(uti_thread_rank == -2);
	require(mcexec_apply_option_result('f', "ff", &target_core,
			&nr_processes, &nr_threads, &mpol_threshold,
			&heap_extension, &straight_map_threshold,
			&stack_premap, &stack_max, &uti_thread_rank,
			&mcexec_flags) == 0);
	require(mcexec_flags == 0xff);
	mix(&digest, mcexec_flags + heap_extension + mpol_threshold);

	memset(limited, 'a', sizeof(limited));
	limited[254] = '\0';
	require(mcexec_path_len_less_than_result(limited, 255) == 1);
	limited[254] = 'a';
	limited[255] = '\0';
	require(mcexec_path_len_less_than_result(limited, 255) == 0);

	memset(out, 0xa5, sizeof(out));
	rc = mcexec_copy_path_result("abc", out, sizeof(out));
	require(rc == 3);
	require(strcmp(out, "abc") == 0);
	mix(&digest, (unsigned long)rc);
	for (i = 0; out[i]; i++)
		mix(&digest, (unsigned long)(unsigned char)out[i]);

	require(mcexec_copy_path_result("abcd", out, 4) == -ENAMETOOLONG);
	require(mcexec_copy_path_result("abcd", out, 5) == 4);

	memset(out, 0xa5, sizeof(out));
	rc = mcexec_join_path_result("/root", "/bin/hostname", out,
				     sizeof(out));
	require(rc == (int)strlen("/root//bin/hostname"));
	require(strcmp(out, "/root//bin/hostname") == 0);
	mix(&digest, (unsigned long)rc);
	for (i = 0; out[i]; i++)
		mix(&digest, (unsigned long)(unsigned char)out[i]);

	rc = mcexec_join_path_result("", "hostname", out, sizeof(out));
	require(rc == (int)strlen("/hostname"));
	require(strcmp(out, "/hostname") == 0);

	rc = mcexec_join_path_result("/usr/bin", "hostname", out, sizeof(out));
	require(rc == (int)strlen("/usr/bin/hostname"));
	require(strcmp(out, "/usr/bin/hostname") == 0);
	require(mcexec_join_path_result("/usr/bin", "hostname", out,
					strlen("/usr/bin/hostname")) ==
		-ENAMETOOLONG);

	reset_reduce_stack_fakes();
	snprintf(fake_reduce_readlink_target,
		 sizeof(fake_reduce_readlink_target), "%s", "/self/bin");
	fake_reduce_readlink_ret = (ssize_t)strlen(fake_reduce_readlink_target);
	rc = mcexec_reduce_stack_body(1234, 5678, reduce_argv);
	require(rc == 1);
	require(fake_reduce_setenv_count == 1);
	require(strcmp(fake_reduce_setenv_value, "1234,5678") == 0);
	require(fake_reduce_setrlimit_count == 1);
	require(fake_reduce_setrlimit_cur == 10UL * 1024 * 1024);
	require(fake_reduce_setrlimit_max == 5678);
	require(fake_reduce_readlink_count == 1);
	require(fake_reduce_execv_count == 1);
	require(strcmp(fake_reduce_execv_path, "/self/bin") == 0);
	require(fake_reduce_execv_argv == reduce_argv);
	require(fake_reduce_execv_failed_count == 1);
	mix(&digest, fake_reduce_setrlimit_cur);
	mix(&digest, fake_reduce_setrlimit_max);

	reset_reduce_stack_fakes();
	fake_reduce_readlink_ret = PATH_MAX;
	rc = mcexec_reduce_stack_body(9, 10, reduce_argv);
	require(rc == 1);
	require(strcmp(fake_reduce_execv_path, "/proc/self/exe") == 0);
	require(fake_reduce_execv_failed_count == 1);

	reset_reduce_stack_fakes();
	fake_reduce_setenv_ret = 5;
	rc = mcexec_reduce_stack_body(1, 2, reduce_argv);
	require(rc == 1);
	require(fake_reduce_setenv_count == 1);
	require(fake_reduce_setenv_failed_count == 1);
	require(fake_reduce_setrlimit_count == 0);

	reset_reduce_stack_fakes();
	rc = mcexec_reduce_stack_body(~0UL, ~0UL, reduce_argv);
	require(rc == 1);
	require(fake_reduce_overflow_count == 1);
	require(fake_reduce_setenv_count == 0);

	fake_access_hit = search_direct;
	fake_access_count = 0;
	fake_search_file_too_long_count = 0;
	require(search_file(search_direct, 5) == search_direct);
	require(fake_access_count == 1);
	require(fake_access_mode == 5);
	require(strcmp(fake_access_last_path, search_direct) == 0);

	fake_access_hit = "/alt//bin/missing";
	fake_access_count = 0;
	search_result = search_file(search_missing, 1);
	require(search_result != NULL);
	require(search_result != search_missing);
	require(strcmp(search_result, "/alt//bin/missing") == 0);
	require(fake_access_count == 2);
	require(fake_access_mode == 1);

	fake_access_hit = NULL;
	fake_access_count = 0;
	require(search_file(search_missing, 2) == NULL);
	require(fake_access_count == 2);

	memset(long_path, 'x', sizeof(long_path));
	long_path[sizeof(long_path) - 1] = '\0';
	fake_search_file_too_long_count = 0;
	require(search_file(long_path, 3) == NULL);
	require(fake_search_file_too_long_count == 1);
	mix(&digest, (unsigned long)fake_access_count);

	memset(&print_desc_fake, 0, sizeof(print_desc_fake));
	print_desc_fake.num_sections = 2;
	print_desc_fake.cpu = 7;
	print_desc_fake.pid = 123;
	print_desc_fake.entry = 0x1111;
	print_desc_fake.rprocess = 0x2222;
	print_desc_fake.sections[0].vaddr = 0x1000;
	print_desc_fake.sections[0].len = 0x2000;
	print_desc_fake.sections[0].remote_pa = 0x3000;
	print_desc_fake.sections[0].filesz = 0x4000;
	print_desc_fake.sections[1].vaddr = 0x5000;
	print_desc_fake.sections[1].len = 0x6000;
	print_desc_fake.sections[1].remote_pa = 0x7000;
	print_desc_fake.sections[1].filesz = 0x8000;
	fake_print_desc_intro_count = 0;
	fake_print_desc_main_count = 0;
	fake_print_desc_section_count = 0;
	fake_print_desc_digest = 0;
	print_desc(&print_desc_fake);
	require(fake_print_desc_intro_count == 1);
	require(fake_print_desc_main_count == 1);
	require(fake_print_desc_section_count == 2);
	require(fake_print_desc_digest != 0);
	mix(&digest, fake_print_desc_digest);

	memset(&interp_hdr, 0, sizeof(interp_hdr));
	memcpy(interp_hdr.e_ident, ELFMAG, SELFMAG);
	interp_hdr.e_entry = 0x12345678;
	interp_hdr.e_phoff = sizeof(interp_hdr);
	interp_hdr.e_phnum = 2;
	memset(interp_phdrs, 0, sizeof(interp_phdrs));
	interp_phdrs[0].p_type = PT_LOAD;
	interp_phdrs[0].p_flags = PF_R | PF_X;
	interp_phdrs[0].p_offset = 0x40;
	interp_phdrs[0].p_vaddr = 0x1000;
	interp_phdrs[0].p_filesz = 0x20;
	interp_phdrs[0].p_memsz = 0x30;
	interp_phdrs[0].p_align = 0x2000;
	interp_phdrs[1].p_type = PT_LOAD;
	interp_phdrs[1].p_flags = PF_R | PF_W;
	interp_phdrs[1].p_offset = 0x80;
	interp_phdrs[1].p_vaddr = 0x3000;
	interp_phdrs[1].p_filesz = 0x40;
	interp_phdrs[1].p_memsz = 0x50;
	interp_phdrs[1].p_align = 0x4000;
	interp_fp = tmpfile();
	require(interp_fp != NULL);
	require(fwrite(&interp_hdr, 1, sizeof(interp_hdr), interp_fp) ==
		sizeof(interp_hdr));
	require(fwrite(interp_phdrs, 1, sizeof(interp_phdrs), interp_fp) ==
		sizeof(interp_phdrs));
	require(fflush(interp_fp) == 0);
	rewind(interp_fp);
	interp_desc_size = offsetof(struct fake_program_desc, sections) +
		sizeof(struct fake_program_section);
	interp_desc = malloc(interp_desc_size);
	require(interp_desc != NULL);
	memset(interp_desc, 0, interp_desc_size);
	interp_desc->num_sections = 1;
	fake_load_interp_section_count = 0;
	fake_load_interp_num_sections_set = 0;
	fake_load_interp_entry_set = 0;
	fake_load_interp_align_set = 0;
	fake_load_interp_digest = 0;
	interp_loaded = load_interp(interp_desc, interp_fp);
	require(interp_loaded != NULL);
	require(fake_load_interp_section_count == 2);
	require(fake_load_interp_num_sections_set == 3);
	require(fake_load_interp_entry_set == 0x12345678);
	require(fake_load_interp_align_set == 0x4000);
	require(interp_loaded->num_sections == 3);
	require(interp_loaded->entry == 0x12345678);
	require(interp_loaded->interp_align == 0x4000);
	require(interp_loaded->sections[1].vaddr == 0x1000);
	require(interp_loaded->sections[1].filesz == 0x20);
	require(interp_loaded->sections[1].offset == 0x40);
	require(interp_loaded->sections[1].len == 0x30);
	require(interp_loaded->sections[1].prot == 5);
	require(interp_loaded->sections[1].interp == 1);
	require(interp_loaded->sections[1].fp == interp_fp);
	require(interp_loaded->sections[2].vaddr == 0x3000);
	require(interp_loaded->sections[2].filesz == 0x40);
	require(interp_loaded->sections[2].offset == 0x80);
	require(interp_loaded->sections[2].len == 0x50);
	require(interp_loaded->sections[2].prot == 3);
	require(interp_loaded->sections[2].interp == 1);
	mix(&digest, fake_load_interp_digest);
	free(interp_loaded);
	fclose(interp_fp);

	for (i = 0; i < (int)sizeof(transfer_file); i++)
		transfer_file[i] = (unsigned char)(0x40 + i);
	transfer_fp = tmpfile();
	require(transfer_fp != NULL);
	require(fwrite(transfer_file, 1, sizeof(transfer_file), transfer_fp) ==
		sizeof(transfer_file));
	require(fflush(transfer_fp) == 0);
	page_size = 16;
	page_mask = ~(page_size - 1);
	dma_buf = dma_area;
	memset(dma_area, 0xcc, sizeof(dma_area));
	memset(&print_desc_fake, 0, sizeof(print_desc_fake));
	print_desc_fake.num_sections = 1;
	print_desc_fake.sections[0].vaddr = 0x1003;
	print_desc_fake.sections[0].len = 20;
	print_desc_fake.sections[0].remote_pa = 0x9000;
	print_desc_fake.sections[0].filesz = 10;
	print_desc_fake.sections[0].offset = 2;
	print_desc_fake.sections[0].fp = transfer_fp;
	fake_ioctl_result = 0;
	fake_ioctl_transfer_count = 0;
	fake_transfer_digest = 0;
	fake_perror_count = 0;
	memset(&fake_transfer_desc, 0, sizeof(fake_transfer_desc));
	require(transfer_image(88, &print_desc_fake) == 0);
	require(fake_ioctl_transfer_count == 1);
	require(fake_ioctl_fd == 88);
	require(fake_ioctl_request == MCEXEC_UP_TRANSFER);
	require(fake_transfer_desc.rphys == 0x9000);
	require(fake_transfer_desc.userp == dma_area);
	require(fake_transfer_desc.size == page_size);
	require(fake_transfer_desc.direction == MCEXEC_UP_TRANSFER_TO_REMOTE);
	for (i = 0; i < (int)page_size; i++)
		require(dma_area[i] == 0);
	require(fake_transfer_digest != 0);
	require(fake_perror_count == 0);
	fclose(transfer_fp);
	mix(&digest, fake_transfer_digest);

	memset(print_flat_storage, 0, sizeof(print_flat_storage));
	print_flat_buf = (char *)print_flat_storage;
	print_flat_storage[0] = 2;
	print_flat_storage[1] = 3 * (long)sizeof(long);
	strcpy(print_flat_buf + print_flat_storage[1], "alpha");
	print_flat_storage[2] = print_flat_storage[1] + strlen("alpha") + 1;
	strcpy(print_flat_buf + print_flat_storage[2], "beta");
	fake_print_flat_count_calls = 0;
	fake_print_flat_entry_count = 0;
	fake_print_flat_digest = 0;
	print_flat(print_flat_buf);
	require(fake_print_flat_count_calls == 1);
	require(fake_print_flat_entry_count == 2);
	require(fake_print_flat_digest != 0);
	mix(&digest, fake_print_flat_digest);

	rc = mcexec_objdump_rpath_cmd_result("/proc/self/exe", out,
					     sizeof(out));
	require(rc == (int)strlen("objdump -x /proc/self/exe | awk '/RPATH/ { print $2 }'"));
	require(strcmp(out,
		       "objdump -x /proc/self/exe | awk '/RPATH/ { print $2 }'")
		== 0);
		require(mcexec_objdump_rpath_cmd_result("/proc/self/exe", out,
							strlen(out)) ==
			-ENAMETOOLONG);

		reset_find_libdir_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/opt/mck/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		memset(out, 0, sizeof(out));
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == (ssize_t)strlen("/opt/mck/lib"));
		require(strcmp(out, "/opt/mck/lib") == 0);
		require(fake_find_libdir_readlink_count == 1);
		require(fake_find_libdir_popen_count == 1);
		require(strcmp(fake_find_libdir_popen_cmd,
			       "objdump -x /self/mcexec | awk '/RPATH/ { print $2 }'")
			== 0);
		require(fake_find_libdir_getline_count == 1);
		require(fake_find_libdir_pclose_count == 1);
		require(fake_find_libdir_free_count == 1);
		mix(&digest, (unsigned long)rc);

		reset_find_libdir_fakes();
		fake_find_libdir_readlink_ret = PATH_MAX;
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/fallback/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		memset(out, 0, sizeof(out));
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == (ssize_t)strlen("/fallback/lib"));
		require(strcmp(out, "/fallback/lib") == 0);
		require(strcmp(fake_find_libdir_popen_cmd,
			       "objdump -x /proc/self/exe | awk '/RPATH/ { print $2 }'")
			== 0);
		require(fake_find_libdir_pclose_count == 1);
		require(fake_find_libdir_free_count == 1);
		mix(&digest, (unsigned long)rc);

		reset_find_libdir_fakes();
		memset(fake_find_libdir_readlink_target, 'a',
		       sizeof(fake_find_libdir_readlink_target));
		fake_find_libdir_readlink_ret = PATH_MAX - 1;
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == -ERANGE);
		require(fake_find_libdir_popen_count == 0);

		reset_find_libdir_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		fake_find_libdir_popen_fail = 1;
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == -EIO);
		require(fake_find_libdir_objdump_failed_count == 1);
		require(fake_find_libdir_objdump_failed_error == EIO);
		require(fake_find_libdir_pclose_count == 0);
		require(fake_find_libdir_free_count == 0);

		reset_find_libdir_fakes();
		fake_find_libdir_readlink_ret = -1;
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == -EINVAL);
		require(fake_find_libdir_readlink_failed_count == 1);
		require(fake_find_libdir_readlink_failed_error == EINVAL);
		require(fake_find_libdir_popen_count == 0);

		reset_find_libdir_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		fake_find_libdir_getline_ret = -1;
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == -ENOENT);
		require(fake_find_libdir_rpath_failed_count == 1);
		require(fake_find_libdir_rpath_failed_error == ENOENT);
		require(fake_find_libdir_pclose_count == 1);
		require(fake_find_libdir_free_count == 0);

		reset_find_libdir_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "noslash\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		rc = mcexec_find_libdir_body(out, sizeof(out));
		require(rc == -EINVAL);
		require(fake_find_libdir_pclose_count == 1);
		require(fake_find_libdir_free_count == 1);

		reset_find_libdir_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/small/path\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		rc = mcexec_find_libdir_body(out, strlen("/small/path"));
		require(rc == -ERANGE);
		require(fake_find_libdir_pclose_count == 1);
		require(fake_find_libdir_free_count == 1);

		reset_find_libdir_fakes();
		reset_ld_preload_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/opt/mck/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		fake_ld_preload_enable_uti = 1;
		fake_ld_preload_disable_sched_yield = 1;
		fake_ld_preload_enable_qlmpi = 1;
		fake_ld_preload_existing_present = 1;
		snprintf(fake_ld_preload_existing,
			 sizeof(fake_ld_preload_existing), "%s", "EXISTING");
		fake_ld_preload_cleanup_present = 1;
		mcexec_ld_preload_init_body();
		require(fake_ld_preload_setenv_count == 1);
		require(strcmp(fake_ld_preload_setenv_value,
			       "/opt/mck/lib/libmck_syscall_intercept.so:"
			       "/opt/mck/lib/libsched_yield.so.1.0.0:"
			       "/opt/mck/lib/libqlfort.so:EXISTING") == 0);
		require(fake_ld_preload_debug_count == 1);
		require(strcmp(fake_ld_preload_debug_value,
			       fake_ld_preload_setenv_value) == 0);
		require(fake_ld_preload_unsetenv_count == 1);
		require(fake_ld_preload_getenv_count == 2);
		mix(&digest, (unsigned long)fake_ld_preload_setenv_count);

		reset_find_libdir_fakes();
		reset_ld_preload_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/opt/mck/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		fake_ld_preload_cleanup_present = 1;
		mcexec_ld_preload_init_body();
		require(fake_ld_preload_setenv_count == 0);
		require(fake_ld_preload_debug_count == 0);
		require(fake_ld_preload_unsetenv_count == 1);

		reset_find_libdir_fakes();
		reset_ld_preload_fakes();
		fake_find_libdir_readlink_ret = -1;
		mcexec_ld_preload_init_body();
		require(fake_ld_preload_find_failed_count == 1);
		require(fake_ld_preload_getenv_count == 0);
		require(fake_ld_preload_setenv_count == 0);

		reset_find_libdir_fakes();
		reset_ld_preload_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/opt/mck/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		fake_ld_preload_existing_present = 1;
		memset(fake_ld_preload_existing, 'x',
		       sizeof(fake_ld_preload_existing) - 1);
		fake_ld_preload_existing[sizeof(fake_ld_preload_existing) - 1] =
			'\0';
		fake_ld_preload_enable_uti = 1;
		mcexec_ld_preload_init_body();
		require(fake_ld_preload_line_too_long_count == 1);
		require(fake_ld_preload_setenv_count == 0);
		require(fake_ld_preload_unsetenv_count == 0);

		reset_find_libdir_fakes();
		reset_ld_preload_fakes();
		snprintf(fake_find_libdir_readlink_target,
			 sizeof(fake_find_libdir_readlink_target), "%s",
			 "/self/mcexec");
		fake_find_libdir_readlink_ret =
			(ssize_t)strlen(fake_find_libdir_readlink_target);
		snprintf(fake_find_libdir_getline_line,
			 sizeof(fake_find_libdir_getline_line), "%s",
			 "/opt/mck/lib\n");
		fake_find_libdir_getline_ret =
			(ssize_t)strlen(fake_find_libdir_getline_line);
		fake_ld_preload_enable_uti = 1;
		fake_ld_preload_setenv_ret = -1;
		mcexec_ld_preload_init_body();
		require(fake_ld_preload_setenv_count == 1);
		require(fake_ld_preload_setenv_failed_count == 1);
		require(fake_ld_preload_debug_count == 1);

			require(gettid() > 0);
	require(tgkill(0, gettid(), 0) < 0);
	mix(&digest, (unsigned long)gettid());

	fake_ioctl_result = 0;
	fake_ioctl_count = 0;
	fake_ioctl_ret_count = 0;
	fake_ioctl_load_count = 0;
	fake_perror_count = 0;
	do_syscall_return(9, 3, -44, 77, 0x111, 0x222, 0x333);
	require(fake_ioctl_count == 1);
	require(fake_ioctl_ret_count == 1);
	require(fake_ioctl_fd == 9);
	require(fake_ioctl_request == MCEXEC_UP_RET_SYSCALL);
	require(fake_ret_desc.cpu == 3);
	require(fake_ret_desc.ret == -44);
	require(fake_ret_desc.src == 0x111);
	require(fake_ret_desc.dest == 0x222);
	require(fake_ret_desc.size == 0x333);
	require(fake_perror_count == 0);

	do_syscall_load(10, 4, 0x555, 0x444, 0x666);
	require(fake_ioctl_count == 2);
	require(fake_ioctl_load_count == 1);
	require(fake_ioctl_fd == 10);
	require(fake_ioctl_request == MCEXEC_UP_LOAD_SYSCALL);
	require(fake_load_desc.cpu == 4);
	require(fake_load_desc.src == 0x444);
	require(fake_load_desc.dest == 0x555);
	require(fake_load_desc.size == 0x666);
	require(fake_perror_count == 0);

	fake_ioctl_result = -1;
	do_syscall_return(11, 5, -55, 88, 0x777, 0x888, 0x999);
	require(fake_perror_count == 1);
	require(strcmp(fake_perror_tag, "ret") == 0);
	do_syscall_load(12, 6, 0xaaa, 0xbbb, 0xccc);
	require(fake_perror_count == 2);
	require(strcmp(fake_perror_tag, "load") == 0);
	mix(&digest, fake_ret_desc.size);
	mix(&digest, fake_load_desc.dest);

	fake_ioctl_result = 0;
	fake_ioctl_errno = 0;
	fake_ioctl_strncpy_count = 0;
	fake_strncpy_result = 17;
	fake_perror_count = 0;
	lrc = do_strncpy_from_user(13, &remote_dest, &remote_src, 123);
	require(lrc == 17);
	require(fake_ioctl_strncpy_count == 1);
	require(fake_ioctl_fd == 13);
	require(fake_ioctl_request == MCEXEC_UP_STRNCPY_FROM_USER);
	require(fake_strncpy_desc.dest == &remote_dest);
	require(fake_strncpy_desc.src == &remote_src);
	require(fake_strncpy_desc.n == 123);
	require(fake_perror_count == 0);

	fake_ioctl_result = -1;
	fake_ioctl_errno = EIO;
	lrc = do_strncpy_from_user(14, &remote_dest, &remote_src, 456);
	require(lrc == -EIO);
	require(fake_ioctl_strncpy_count == 2);
	require(fake_ioctl_fd == 14);
	require(fake_strncpy_desc.n == 456);
	require(fake_perror_count == 1);
	require(strcmp(fake_perror_tag, "strncpy_from_user:ioctl") == 0);
	mix(&digest, (unsigned long)(0 - lrc));

	memset(fake_fcntl_seen, 0, sizeof(fake_fcntl_seen));
	memset(fake_fd_flags, 0, sizeof(fake_fd_flags));
	memset(fake_closed_fds, -1, sizeof(fake_closed_fds));
	fake_sysconf_name = -1;
	fake_sysconf_result = 6;
	fake_fcntl_count = 0;
	fake_close_count = 0;
	fake_fd_flags[0] = 1;
	fake_fd_flags[1] = 0;
	fake_fd_flags[2] = 1;
	fake_fd_flags[4] = -1;
	fake_fd_flags[5] = 1;
	require(close_cloexec_fds(2) == 0);
	require(fake_sysconf_name == 4);
	require(fake_fcntl_count == 5);
	require(fake_fcntl_seen[2] == 0);
	require(fake_close_count == 3);
	require(fake_closed_fds[0] == 0);
	require(fake_closed_fds[1] == 4);
	require(fake_closed_fds[2] == 5);
	mix(&digest, (unsigned long)fake_close_count + fake_closed_fds[2]);

	memset(fake_init_sigaction_seen, 0, sizeof(fake_init_sigaction_seen));
	fake_init_sigaction_master_tid = 0;
	fake_init_sigaction_count = 0;
	fake_init_sigaction_digest = 0;
	init_sigaction();
	require(fake_init_sigaction_master_tid > 0);
	require(fake_init_sigaction_count == 58);
	require(fake_init_sigaction_seen[1] == 1);
	require(fake_init_sigaction_seen[64] == 1);
	require(fake_init_sigaction_seen[9] == 0);
	require(fake_init_sigaction_seen[17] == 0);
	require(fake_init_sigaction_seen[19] == 0);
	require(fake_init_sigaction_seen[20] == 0);
	require(fake_init_sigaction_seen[21] == 0);
	require(fake_init_sigaction_seen[22] == 0);
	mix(&digest, fake_init_sigaction_digest);

	fd = 91;
	thread_data = &sig_thread1;
	sig_thread1.tid = gettid();
	sig_thread1.terminate = 0;
	sig_thread1.remote_tid = 440;
	sig_thread1.remote_cpu = 7;
	sig_thread2.next = NULL;
	sig_thread2.tid = 202;
	sig_thread2.terminate = 0;
	sig_thread2.remote_tid = 2040;
	sig_thread2.remote_cpu = 8;
	memset(&sendsig_info, 0, sizeof(sendsig_info));
	for (size_t j = 0; j < sizeof(sendsig_info.rest); j++)
		sendsig_info.rest[j] = (unsigned char)(0x30 + j);
	sendsig_info.si_pid = getpid();
	sendsig_info.si_signo = 23;
	sendsig_context = 0x123456;
	memset(fake_sig_thread_arg, 0, sizeof(fake_sig_thread_arg));
	memset(fake_sig_thread_result, 0, sizeof(fake_sig_thread_result));
	memset(&fake_send_signal_desc, 0, sizeof(fake_send_signal_desc));
	memset(&fake_syscall_thread_param, 0, sizeof(fake_syscall_thread_param));
	fake_sig_thread_count = 0;
	fake_send_signal_count = 0;
	fake_send_signal_result = 0;
	fake_syscall_thread_count = 0;
	fake_syscall_thread_result = 0;
	fake_syscall_thread_ret = 1;
	fake_sendsig_handler_count = 0;
	fake_sendsig_default_count = 0;
	sendsig(23, &sendsig_info, &sendsig_context);
	require(fake_sig_thread_count == 2);
	require(fake_sig_thread_arg[0] == 1);
	require(fake_sig_thread_arg[1] == 0);
	require(fake_send_signal_count == 0);
	require(fake_syscall_thread_count == 0);

	sendsig_info.si_signo = 10;
	memset(fake_sig_thread_arg, 0, sizeof(fake_sig_thread_arg));
	memset(fake_sig_thread_result, 0, sizeof(fake_sig_thread_result));
	memset(&fake_send_signal_desc, 0, sizeof(fake_send_signal_desc));
	fake_sig_thread_count = 0;
	fake_send_signal_count = 0;
	fake_sig_thread_result[0] = 1;
	sendsig(10, &sendsig_info, &sendsig_context);
	require(fake_sig_thread_count == 1);
	require(fake_sig_thread_arg[0] == 1);
	require(fake_send_signal_count == 1);
	require(fake_send_signal_desc.cpu == 7);
	require(fake_send_signal_desc.pid == getpid());
	require(fake_send_signal_desc.tid == 440);
	require(fake_send_signal_desc.sig == 10);
	require(memcmp(fake_send_signal_desc.info, &sendsig_info,
		       sizeof(fake_send_signal_desc.info)) == 0);

	memset(fake_sig_thread_arg, 0, sizeof(fake_sig_thread_arg));
	memset(fake_sig_thread_result, 0, sizeof(fake_sig_thread_result));
	memset(&fake_syscall_thread_param, 0, sizeof(fake_syscall_thread_param));
	fake_sig_thread_count = 0;
	fake_syscall_thread_count = 0;
	fake_sendsig_handler_count = 0;
	fake_syscall_thread_ret = 1;
	sendsig(12, &sendsig_info, &sendsig_context);
	require(fake_sig_thread_count == 2);
	require(fake_sig_thread_arg[0] == 1);
	require(fake_sig_thread_arg[1] == 0);
	require(fake_syscall_thread_count == 1);
	require(fake_syscall_thread_param.number == 13);
	require(fake_syscall_thread_param.args[0] == 12);
	require(fake_sendsig_handler_count == 0);

	memset(fake_sig_thread_arg, 0, sizeof(fake_sig_thread_arg));
	memset(fake_sig_thread_result, 0, sizeof(fake_sig_thread_result));
	memset(&fake_syscall_thread_param, 0, sizeof(fake_syscall_thread_param));
	fake_sig_thread_count = 0;
	fake_syscall_thread_count = 0;
	fake_sendsig_handler_count = 0;
	fake_syscall_thread_ret = (unsigned long)(uintptr_t)fake_sendsig_handler;
	sendsig(12, &sendsig_info, &sendsig_context);
	require(fake_sig_thread_count == 4);
	require(fake_sig_thread_arg[0] == 1);
	require(fake_sig_thread_arg[1] == 0);
	require(fake_sig_thread_arg[2] == 1);
	require(fake_sig_thread_arg[3] == 0);
	require(fake_sendsig_handler_count == 1);
	require(fake_sendsig_handler_sig == 12);
	require(fake_sendsig_handler_info == &sendsig_info);
	require(fake_sendsig_handler_context == &sendsig_context);
	mix(&digest, (unsigned long)fake_send_signal_desc.cpu);
	mix(&digest, (unsigned long)fake_send_signal_desc.tid);
	mix(&digest, (unsigned long)fake_sendsig_handler_count);

	n_threads = 2;
	fake_worker_lock_init_count = 0;
	fake_worker_barrier_count = 0;
	fake_worker_reset_count = 0;
	fake_worker_create_count = 0;
	fake_worker_create_fail_at = 0;
	fake_worker_wait_count = 0;
	fake_worker_error_count = 0;
	require(init_worker_threads(91) == 0);
	require(fake_worker_lock_init_count == 1);
	require(fake_worker_barrier_count == 4);
	require(fake_worker_reset_count == 1);
	require(fake_worker_create_count == 3);
	require(fake_worker_wait_count == 1);
	require(fake_worker_error_count == 0);

	n_threads = 3;
	fake_worker_lock_init_count = 0;
	fake_worker_barrier_count = 0;
	fake_worker_reset_count = 0;
	fake_worker_create_count = 0;
	fake_worker_create_fail_at = 2;
	fake_worker_wait_count = 0;
	fake_worker_error_count = 0;
	fake_worker_error_ret = 0;
	require(init_worker_threads(91) == -17);
	require(fake_worker_lock_init_count == 1);
	require(fake_worker_barrier_count == 5);
	require(fake_worker_reset_count == 1);
	require(fake_worker_create_count == 2);
	require(fake_worker_wait_count == 0);
	require(fake_worker_error_count == 1);
	require(fake_worker_error_ret == 17);
	mix(&digest, (unsigned long)fake_worker_create_count);
	mix(&digest, (unsigned long)fake_worker_error_ret);

	fake_thp_prctl_count = 0;
	fake_thp_prctl_ret = 1;
	require(mcexec_get_thp_disable_body() == 1);
	require(fake_thp_prctl_count == 1);
	fake_thp_prctl_ret = -1;
	require(mcexec_get_thp_disable_body() == 0);
	require(fake_thp_prctl_count == 2);
	mix(&digest, (unsigned long)fake_thp_prctl_count);

	{
		unsigned char numa_storage[96];
		unsigned long localset[4] = { 0 };
		unsigned long nodemask[4] = { 0 };

		ncpu = 4;
		nnodes = 3;
		memset(fake_numa_node_cpu_mask, 0,
		       sizeof(fake_numa_node_cpu_mask));
		set_bit(1, localset);
		set_bit(3, localset);
		set_bit(0, &fake_numa_node_cpu_mask[0]);
		set_bit(1, &fake_numa_node_cpu_mask[0]);
		set_bit(2, &fake_numa_node_cpu_mask[1]);
		set_bit(3, &fake_numa_node_cpu_mask[2]);
		require(mcexec_numa_node_set_body(2, numa_storage, 24) ==
			numa_storage + 48);

		fake_numa_node_cpu_isset_count = 0;
		fake_numa_local_log_count = 0;
		fake_numa_node_log_count = 0;
		memset(nodemask, 0xff, sizeof(nodemask));
		mcexec_numa_local_body(localset, nodemask, 0);
		require(test_bit(0, nodemask) == 1);
		require(test_bit(1, nodemask) == 0);
		require(test_bit(2, nodemask) == 1);
		require(test_bit(3, nodemask) == 0);
		require(fake_numa_node_cpu_isset_count == 12);
		require(fake_numa_local_log_count == 6);
		require(fake_numa_node_log_count == 4);

		fake_numa_node_cpu_isset_count = 0;
		fake_numa_local_log_count = 0;
		fake_numa_node_log_count = 0;
		memset(nodemask, 0xff, sizeof(nodemask));
		mcexec_numa_local_body(localset, nodemask, 1);
		require(test_bit(0, nodemask) == 0);
		require(test_bit(1, nodemask) == 1);
		require(test_bit(2, nodemask) == 0);
		require(test_bit(3, nodemask) == 0);
		require(fake_numa_node_cpu_isset_count == 12);
		require(fake_numa_local_log_count == 6);
		require(fake_numa_node_log_count == 4);

		memset(nodemask, 0xff, sizeof(nodemask));
		mcexec_numa_all_body(nodemask);
		require(test_bit(0, nodemask) == 1);
		require(test_bit(1, nodemask) == 1);
		require(test_bit(2, nodemask) == 1);
		require(test_bit(3, nodemask) == 0);
		mix(&digest, nodemask[0]);
	}

	memset(fake_opendev_buildid, 0, sizeof(fake_opendev_buildid));
	memset(fake_opendev_query_value, 0, sizeof(fake_opendev_query_value));
	memcpy(fake_opendev_buildid, "build-a", 7);
	memcpy(fake_opendev_query_value, "build-a", 7);
	memset(fake_opendev_dev, 0, sizeof(fake_opendev_dev));
	memset(fake_opendev_open_path, 0, sizeof(fake_opendev_open_path));
	fake_opendev_mcosid = 7;
	fake_opendev_dev_size = sizeof(fake_opendev_dev);
	fake_opendev_path_error_count = 0;
	fake_opendev_open_count = 0;
	fake_opendev_open_ret = 44;
	fake_opendev_open_error_count = 0;
	fake_opendev_publish_count = 0;
	fake_opendev_query_count = 0;
	fake_opendev_query_fd = -1;
	fake_opendev_query_ret = 0;
	fake_opendev_query_error_count = 0;
	fake_opendev_close_count = 0;
	fake_opendev_mismatch_count = 0;
	fd = -1;
	require(mcexec_opendev_body() == 44);
	require(strcmp(fake_opendev_dev, "/dev/mcos7") == 0);
	require(strcmp(fake_opendev_open_path, "/dev/mcos7") == 0);
	require(fake_opendev_path_error_count == 0);
	require(fake_opendev_open_count == 1);
	require(fake_opendev_open_error_count == 0);
	require(fake_opendev_publish_count == 1);
	require(fake_opendev_publish_fd == 44);
	require(fd == 44);
	require(fake_opendev_query_count == 1);
	require(fake_opendev_query_fd == 44);
	require(fake_opendev_query_error_count == 0);
	require(fake_opendev_close_count == 0);
	require(fake_opendev_mismatch_count == 0);

	fake_opendev_dev_size = 0;
	fake_opendev_path_error_count = 0;
	fake_opendev_open_count = 0;
	require(mcexec_opendev_body() == -1);
	require(fake_opendev_path_error_count == 1);
	require(fake_opendev_open_count == 0);

	fake_opendev_dev_size = sizeof(fake_opendev_dev);
	fake_opendev_open_ret = -1;
	fake_opendev_open_count = 0;
	fake_opendev_open_error_count = 0;
	fake_opendev_publish_count = 0;
	require(mcexec_opendev_body() == -1);
	require(fake_opendev_open_count == 1);
	require(fake_opendev_open_error_count == 1);
	require(fake_opendev_publish_count == 0);

	fake_opendev_open_ret = 45;
	fake_opendev_publish_count = 0;
	fake_opendev_query_count = 0;
	fake_opendev_query_ret = -1;
	fake_opendev_query_error_count = 0;
	fake_opendev_close_count = 0;
	fake_opendev_close_fd = -1;
	require(mcexec_opendev_body() == -1);
	require(fake_opendev_publish_count == 1);
	require(fake_opendev_query_count == 1);
	require(fake_opendev_query_fd == 45);
	require(fake_opendev_query_error_count == 1);
	require(fake_opendev_close_count == 1);
	require(fake_opendev_close_fd == 45);

	fake_opendev_query_ret = 0;
	fake_opendev_close_count = 0;
	fake_opendev_mismatch_count = 0;
	memset(fake_opendev_query_value, 0, sizeof(fake_opendev_query_value));
	memcpy(fake_opendev_query_value, "other", 6);
	require(mcexec_opendev_body() == -1);
	require(fake_opendev_mismatch_count == 1);
	require(fake_opendev_close_count == 1);
	mix(&digest, (unsigned long)(fake_opendev_publish_fd +
				     fake_opendev_mismatch_count));

	{
		char pathbuf[PATH_MAX];
		char small[8];

		memset(pathbuf, 0, sizeof(pathbuf));
		require(mcexec_getpath_execveat_body(AT_FDCWD, "/bin/echo",
						     0, pathbuf,
						     sizeof(pathbuf)) == 0);
		require(strcmp(pathbuf, "/bin/echo") == 0);

		memset(pathbuf, 0, sizeof(pathbuf));
		require(mcexec_getpath_execveat_body(7, "worker", 0,
						     pathbuf,
						     sizeof(pathbuf)) == 0);
		require(strcmp(pathbuf, "/dev/fd/7/worker") == 0);

		memset(pathbuf, 0, sizeof(pathbuf));
		require(mcexec_getpath_execveat_body(8, "", AT_EMPTY_PATH,
						     pathbuf,
						     sizeof(pathbuf)) == 0);
		require(strcmp(pathbuf, "/dev/fd/8") == 0);

		memset(small, 0, sizeof(small));
		require(mcexec_getpath_execveat_body(9, "too-long", 0,
						     small,
						     sizeof(small)) ==
			ENAMETOOLONG);

		memset(pathbuf, 0, sizeof(pathbuf));
		require(mcexec_getpath_execveat_body(AT_FDCWD,
						     "/proc/self/exe",
						     AT_SYMLINK_NOFOLLOW,
						     pathbuf,
						     sizeof(pathbuf)) ==
			ELOOP);
		mix(&digest, (unsigned long)(pathbuf[0] + small[0]));
	}

	{
		char env_a_str[] = "A=1";
		char env_b_str[] = "B=2";
		char env_a_name[] = "A";
		char env_b_name[] = "B";
		char env_a_value[] = "1";
		char env_b_value[] = "2";
		struct fake_env_list_entry env_a = {
			.str = env_a_str,
			.name = env_a_name,
			.value = env_a_value,
			.next = NULL,
		};
		struct fake_env_list_entry env_b = {
			.str = env_b_str,
			.name = env_b_name,
			.value = env_b_value,
			.next = &env_a,
		};
		struct fake_env_list_entry *env_head = &env_b;
		struct fake_env_list_entry *allocated;
		char env_invalid[] = "NOEQUALS";
		char env_dup[] = "A=dup";
		char env_c[] = "C=3";
		char **local_env;

		require(mcexec_env_list_count_result(env_head) == 2);
		require(mcexec_search_env_list_result(env_head, env_b_name) ==
			&env_b);
		require(mcexec_search_env_list_result(env_head, "MISS") == NULL);

		fake_env_invalid_count = 0;
		memset(fake_env_invalid_value, 0, sizeof(fake_env_invalid_value));
		mcexec_add_env_list_body(&env_head, env_invalid);
		require(fake_env_invalid_count == 1);
		require(strcmp(fake_env_invalid_value, "NOEQUALS") == 0);
		require(env_head == &env_b);

		fake_env_invalid_count = 0;
		mcexec_add_env_list_body(&env_head, env_dup);
		require(fake_env_invalid_count == 0);
		require(env_head == &env_b);

		mcexec_add_env_list_body(&env_head, env_c);
		require(env_head != &env_b);
		require(env_head->str == env_c);
		require(strcmp(env_head->name, "C") == 0);
		require(strcmp(env_head->value, "3") == 0);
		require(env_head->next == &env_b);
		allocated = env_head;
		env_head = allocated->next;
		allocated->next = NULL;
		mcexec_destroy_env_list_result(allocated);
		require(env_head == &env_b);

		local_env = mcexec_create_local_environ_result(env_head);
		require(local_env != NULL);
		require(strcmp(local_env[0], "B=2") == 0);
		require(strcmp(local_env[1], "A=1") == 0);
		require(local_env[2] == NULL);
		mcexec_destroy_local_environ_result(local_env);
		mix(&digest, (unsigned long)(fake_env_invalid_count +
					     mcexec_env_list_count_result(env_head)));
	}

	ncpu = 4;
	nnodes = 2;
	fake_overlay_mcosid = 3;
	{
		struct fake_list_head head;
		struct fake_list_head node;

		head.next = &head;
		head.prev = &head;
		node.next = NULL;
		node.prev = NULL;
		mcexec_overlay_list_add_body(&node, &head);
		require(head.next == &node);
		require(head.prev == &node);
		require(node.next == &head);
		require(node.prev == &head);
		mcexec_overlay_list_del_body(&node);
		require(head.next == &head);
		require(head.prev == &head);
		require(node.next == (struct fake_list_head *)0x00100129);
		require(node.prev == (struct fake_list_head *)0x00200229);
		require(mcexec_dirent_is64_body(217, 217) == 1);
		require(mcexec_dirent_is64_body(78, 217) == 0);
	}
	fake_overlay_addfd_too_long_count = 0;
	fake_overlay_addfd_publish_count = 0;
	memset(fake_overlay_addfd_linux_path, 0,
	       sizeof(fake_overlay_addfd_linux_path));
	memset(fake_overlay_addfd_mck_path, 0,
	       sizeof(fake_overlay_addfd_mck_path));
	overlay_addfd(70, "/tmp/ignored");
	require(fake_overlay_addfd_publish_count == 0);
	require(fake_overlay_addfd_too_long_count == 0);
	overlay_addfd(71, "/proc/mcos3/123/status");
	require(fake_overlay_addfd_publish_count == 1);
	require(fake_overlay_addfd_publish_fd == 71);
	require(strcmp(fake_overlay_addfd_linux_path, "/proc/123/status") == 0);
	require(strcmp(fake_overlay_addfd_mck_path, "/proc/mcos3/123/status") == 0);
	require(fake_overlay_addfd_pathlen == strlen("/proc/123/status"));
	overlay_addfd(72, "/sys/mcos3/node0");
	require(fake_overlay_addfd_publish_count == 2);
	require(fake_overlay_addfd_publish_fd == 72);
	require(strcmp(fake_overlay_addfd_linux_path, "/sys/node0") == 0);
	require(strcmp(fake_overlay_addfd_mck_path, "/sys/mcos3/node0") == 0);
	memset(huge_path, 'x', sizeof(huge_path));
	memcpy(huge_path, "/proc/mcos3/", strlen("/proc/mcos3/"));
	huge_path[sizeof(huge_path) - 1] = '\0';
	overlay_addfd(73, huge_path);
	require(fake_overlay_addfd_too_long_count == 1);
	require(fake_overlay_addfd_publish_count == 2);
	fake_overlay_delfd_count = 0;
	fake_overlay_delfd_fd = 0;
	overlay_delfd(71);
	require(fake_overlay_delfd_count == 1);
	require(fake_overlay_delfd_fd == 71);
	mix(&digest, (unsigned long)fake_overlay_addfd_publish_count);
	mix(&digest, (unsigned long)fake_overlay_delfd_fd);

	fake_overlay_stat_count = 0;
	fake_overlay_stat_result = 0;
	memset(fake_overlay_stat_path, 0, sizeof(fake_overlay_stat_path));
	require(overlay_blacklist("/proc/self/task/77/status") == 0);
	require(fake_overlay_stat_count == 1);
	require(strstr(fake_overlay_stat_path, "/proc/mcos3/") ==
		fake_overlay_stat_path);
	require(strstr(fake_overlay_stat_path, "/task/77") != NULL);

	fake_overlay_stat_count = 0;
	fake_overlay_stat_result = -1;
	require(overlay_blacklist("/proc/123/task/456/status") == -ENOENT);
	require(fake_overlay_stat_count == 1);
	require(strcmp(fake_overlay_stat_path,
		       "/proc/mcos3/123/task/456") == 0);

	fake_overlay_stat_result = 0;
	require(overlay_blacklist("/tmp/not-sys") == 0);
	require(overlay_blacklist("/sys/devices/system/cpu/cpu2") == 0);
	require(overlay_blacklist("/sys/devices/system/cpu/cpu4") == -ENOENT);
	require(overlay_blacklist("/sys/bus/cpu/devices/cpu5") == -ENOENT);
	require(overlay_blacklist("/sys/devices/system/node/node1") == 0);
	require(overlay_blacklist("/sys/devices/system/node/node2") == -ENOENT);
	require(overlay_blacklist("/sys/devices/system/node/node0/memory") ==
		-ENOENT);
	require(overlay_blacklist("/sys/devices/system/node/has_cpu") ==
		-ENOENT);
	require(overlay_blacklist("/sys/fs/cgroup") == -ENOENT);
	require(overlay_blacklist("/sys/devices/pci0000:00/0000:00:01.0/local_cpus") ==
		-ENOENT);

	fake_overlay_cpu_node_count = 0;
	fake_overlay_cpu_node_result = 1;
	require(overlay_blacklist("/sys/devices/system/node/node1/cpu3") == 0);
	require(fake_overlay_cpu_node_count == 1);
	require(fake_overlay_cpu_node_cpu == 3);
	require(fake_overlay_cpu_node_node == 1);
	fake_overlay_cpu_node_result = 0;
	require(overlay_blacklist("/sys/devices/system/cpu/cpu3/node1") ==
		-ENOENT);
	require(fake_overlay_cpu_node_count == 2);
	mix(&digest, (unsigned long)fake_overlay_stat_count);
	mix(&digest, (unsigned long)fake_overlay_cpu_node_count);

	fake_overlay_stat_count = 0;
	fake_overlay_stat_result = 0;
	require(mcexec_mapped_proc_task_parent_exists_body(
		"/proc/mcos3/12/task/34/status") == 1);
	require(fake_overlay_stat_count == 1);
	require(strcmp(fake_overlay_stat_path,
		       "/proc/mcos3/12/task/34") == 0);
	fake_overlay_stat_count = 0;
	fake_overlay_stat_result = -ENOENT;
	require(mcexec_mapped_proc_task_parent_exists_body(
		"/proc/mcos3/12/task/34/missing") == 0);
	require(fake_overlay_stat_count == 1);
	require(strcmp(fake_overlay_stat_path,
		       "/proc/mcos3/12/task/34") == 0);
	fake_overlay_stat_count = 0;
	require(mcexec_mapped_proc_task_parent_exists_body("noslash") == 0);
	require(fake_overlay_stat_count == 0);

	fake_overlay_enable_uti = 0;
	fake_overlay_find_libdir_result = 0;
	snprintf(fake_overlay_libdir, sizeof(fake_overlay_libdir), "%s",
		 "/lib64");
	fake_overlay_readlink_count = 0;
	fake_overlay_readlink_result = 0;
	snprintf(fake_overlay_readlink_target,
		 sizeof(fake_overlay_readlink_target), "%s", "/tmp/base");
	fake_overlay_lstat_count = 0;
	fake_overlay_lstat_result = -ENOENT;
	fake_overlay_lstat_is_symlink = 0;
	fake_overlay_stat_errno_count = 0;
	fake_overlay_stat_errno_result = 0;
	fake_overlay_parent_exists_count = 0;
	fake_overlay_parent_exists_result = 0;
	fake_overlay_replaced_count = 0;
	fake_overlay_trying_count = 0;
	fake_overlay_blacklisted_count = 0;
	memset(long_path, 0, sizeof(long_path));
	resolvelinks = 99;
	overlay_mapped = overlay_path(-100, "/proc/self/status", long_path,
				      &resolvelinks);
	snprintf(out, sizeof(out), "/proc/mcos3/%d/status", getpid());
	require(overlay_mapped == long_path);
	require(strcmp(long_path, out) == 0);
	require(resolvelinks == 0);
	require(fake_overlay_stat_errno_count == 1);
	require(fake_overlay_trying_count == 1);

	memset(long_path, 0, sizeof(long_path));
	overlay_mapped = overlay_path(-100, "/dev/xpmem", long_path,
				      &resolvelinks);
	require(strcmp(overlay_mapped, "/dev/null") == 0);

	fake_overlay_enable_uti = 1;
	fake_overlay_stat_errno_result = 0;
	fake_overlay_replaced_count = 0;
	memset(long_path, 0, sizeof(long_path));
	overlay_mapped = overlay_path(-100, "/usr/lib/libuti.so", long_path,
				      &resolvelinks);
	require(overlay_mapped == long_path);
	require(strcmp(long_path, "/lib64/mck/libuti.so") == 0);
	require(fake_overlay_replaced_count == 1);
	fake_overlay_enable_uti = 0;

	fake_overlay_stat_errno_result = ENOENT;
	fake_overlay_stat_result = 0;
	fake_overlay_stat_count = 0;
	fake_overlay_parent_exists_count = 0;
	memset(long_path, 0, sizeof(long_path));
	overlay_mapped = overlay_path(-100, "/proc/123/task/456/status",
				      long_path, &resolvelinks);
	require(overlay_mapped == long_path);
	require(strcmp(long_path, "/proc/mcos3/123/task/456/status") == 0);
	require(fake_overlay_stat_count == 1);
	require(strcmp(fake_overlay_stat_path,
		       "/proc/mcos3/123/task/456") == 0);
	require(fake_overlay_parent_exists_count == 0);

	fake_overlay_stat_errno_result = ENOENT;
	fake_overlay_stat_result = -ENOENT;
	fake_overlay_blacklisted_count = 0;
	fake_overlay_lstat_count = 0;
	fake_overlay_lstat_result = -ENOENT;
	resolvelinks = 99;
	memset(long_path, 0, sizeof(long_path));
	overlay_mapped = overlay_path(-100, "/sys/devices/system/cpu/cpu9",
				      long_path, &resolvelinks);
	require(strcmp(overlay_mapped, "/nonexisting") == 0);
	require(fake_overlay_blacklisted_count == 1);
	require(fake_overlay_lstat_count == 1);
	require(resolvelinks == 0);

	fake_overlay_stat_errno_result = 0;
	fake_overlay_readlink_count = 0;
	fake_overlay_readlink_result = 0;
	snprintf(fake_overlay_readlink_target,
		 sizeof(fake_overlay_readlink_target), "%s", "/tmp/base");
	overlay_mapped = overlay_path(17, "leaf", long_path, NULL);
	require(strcmp(overlay_mapped, "leaf") == 0);
	require(fake_overlay_readlink_count == 1);
	require(strcmp(fake_overlay_readlink_path, "/proc/self/fd/17") == 0);
	mix(&digest, (unsigned long)fake_overlay_trying_count);
	mix(&digest, (unsigned long)fake_overlay_blacklisted_count);

	memset(&sigwait, 0, sizeof(sigwait));
	fake_strncpy_copy = 1;
	fake_ioctl_result = 0;
	fake_ioctl_errno = 0;
	fake_overlay_stat_errno_result = 0;
	fake_ioctl_strncpy_count = 0;
	fake_ioctl_ret_count = 0;
	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 77;
	fake_strncpy_result = (long)strlen("/tmp/path-action");
	sigwait.sr.args[0] = 9;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"/tmp/path-action";
	sigwait.sr.args[2] = (unsigned long)(uintptr_t)out;
	sigwait.sr.args[3] = 123;
	act_readlinkat(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 1);
	require(fake_path_bridge_count == 1);
	require(fake_path_bridge_dirfd == 9);
	require(fake_path_bridge_size == 123);
	require(strcmp(fake_path_bridge_path, "/tmp/path-action") == 0);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == 77);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 78;
	fake_strncpy_result = (long)strlen("/tmp/readlink");
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"/tmp/readlink";
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)out;
	sigwait.sr.args[2] = 42;
	act_readlink(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 2);
	require(fake_path_bridge_count == 1);
	require(fake_path_bridge_size == 42);
	require(strcmp(fake_path_bridge_path, "/tmp/readlink") == 0);
	require(fake_ret_desc.ret == 78);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 0;
	fake_strncpy_result = (long)strlen("/tmp/statat");
	sigwait.sr.args[0] = 7;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"/tmp/statat";
	sigwait.sr.args[2] = (unsigned long)(uintptr_t)out;
	sigwait.sr.args[3] = 0x40;
	act_newfstatat(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 3);
	require(fake_path_bridge_dirfd == 7);
	require(fake_path_bridge_flags == 0x40);
	require(strcmp(fake_path_bridge_path, "/tmp/statat") == 0);
	require(fake_ret_desc.ret == 0);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = -EACCES;
	fake_strncpy_result = (long)strlen("/tmp/stat");
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"/tmp/stat";
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)out;
	act_stat(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 4);
	require(strcmp(fake_path_bridge_path, "/tmp/stat") == 0);
	require(fake_ret_desc.ret == -EACCES);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 0;
	fake_strncpy_result = (long)strlen("/tmp/faccess");
	sigwait.sr.args[0] = 8;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"/tmp/faccess";
	sigwait.sr.args[2] = 4;
	act_faccessat(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 5);
	require(fake_path_bridge_dirfd == 8);
	require(fake_path_bridge_mode == 4);
	require(fake_path_bridge_flags == 0);
	require(strcmp(fake_path_bridge_path, "/tmp/faccess") == 0);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 0;
	fake_strncpy_result = (long)strlen("/tmp/access");
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"/tmp/access";
	sigwait.sr.args[1] = 1;
	act_access(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 6);
	require(fake_path_bridge_mode == 1);
	require(strcmp(fake_path_bridge_path, "/tmp/access") == 0);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 19;
	fake_strncpy_result = (long)strlen("/tmp/xattr");
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"/tmp/xattr";
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"user.test";
	sigwait.sr.args[2] = (unsigned long)(uintptr_t)out;
	sigwait.sr.args[3] = 64;
	act_getxattr(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 7);
	require(fake_path_bridge_size == 64);
	require(strcmp(fake_path_bridge_path, "/tmp/xattr") == 0);
	require(strcmp(fake_path_bridge_name, "user.test") == 0);
	require(fake_ret_desc.ret == 19);

	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 20;
	act_lgetxattr(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_kind == 8);
	require(fake_path_bridge_count == 1);
	require(fake_ret_desc.ret == 20);

	fake_path_open_log_count = 0;
	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 33;
	fake_strncpy_result = (long)strlen("/proc/self/status");
	fake_overlay_addfd_publish_count = 0;
	memset(fake_overlay_addfd_linux_path, 0,
	       sizeof(fake_overlay_addfd_linux_path));
	memset(fake_overlay_addfd_mck_path, 0,
	       sizeof(fake_overlay_addfd_mck_path));
	sigwait.sr.rtid = 444;
	sigwait.sr.args[0] = (unsigned long)-100;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"/proc/self/status";
	sigwait.sr.args[2] = 0x800;
	sigwait.sr.args[3] = 0600;
	act_openat(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_open_log_count == 1);
	require(fake_path_open_log_tid == 444);
	require(fake_path_bridge_kind == 9);
	require(fake_path_bridge_dirfd == -100);
	require(fake_path_bridge_flags == 0x800);
	require(fake_path_bridge_mode == 0600);
	require(fake_ret_desc.ret == 33);
	require(fake_overlay_addfd_publish_count == 1);
	require(fake_overlay_addfd_publish_fd == 33);
	require(strcmp(fake_overlay_addfd_mck_path, fake_path_bridge_path) == 0);

	fake_path_open_log_count = 0;
	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 34;
	fake_overlay_addfd_publish_count = 0;
	fake_overlay_stat_errno_result = 0;
	fake_strncpy_result = (long)strlen("/tmp/open");
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"/tmp/open";
	sigwait.sr.args[1] = 0x400;
	sigwait.sr.args[2] = 0644;
	act_open(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_open_log_count == 1);
	require(fake_path_bridge_kind == 10);
	require(fake_path_bridge_flags == 0x400);
	require(fake_path_bridge_mode == 0644);
	require(strcmp(fake_path_bridge_path, "/tmp/open") == 0);
	require(fake_ret_desc.ret == 34);
	require(fake_overlay_addfd_publish_count == 0);

	fake_strncpy_copy = 0;
	fake_strncpy_result = PATH_MAX;
	fake_path_bridge_count = 0;
	act_access(&sigwait, 14, 6, long_path, huge_path);
	require(fake_path_bridge_count == 0);
	require(fake_ret_desc.ret == -ENAMETOOLONG);
	mix(&digest, (unsigned long)fake_path_bridge_kind);
	mix(&digest, (unsigned long)fake_path_bridge_size);
	mix(&digest, (unsigned long)fake_ret_desc.ret);

	memset(fake_getdents_passthrough, 0, sizeof(fake_getdents_passthrough));
	fake_getdents_passthrough_size =
		put_dirent64(fake_getdents_passthrough, "plain", 32);
	fake_overlay_getdents_ofd = (void *)(uintptr_t)0x1234;
	fake_overlay_getdents_fd = 300;
	fake_getdents_passthrough_fd = 55;
	fake_overlay_getdents_hide_orig = 0;
	fake_overlay_getdents_mck_fd = 301;
	fake_overlay_getdents_linux_fd = 302;
	fake_getdents_passthrough_calls = 0;
	memset(out, 0, sizeof(out));
	rc = overlay_getdents(1, fake_getdents_passthrough_fd, out, sizeof(out));
	require(rc == (int)fake_getdents_passthrough_size);
	require(strcmp(((struct fake_dirent64 *)out)->d_name, "plain") == 0);
	require(fake_getdents_passthrough_calls == 1);

	memset(fake_getdents_mck_src, 0, sizeof(fake_getdents_mck_src));
	memset(fake_getdents_linux_src, 0, sizeof(fake_getdents_linux_src));
	memset(fake_overlay_getdents_mck_cache, 0,
	       sizeof(fake_overlay_getdents_mck_cache));
	memset(fake_overlay_getdents_linux_cache, 0,
	       sizeof(fake_overlay_getdents_linux_cache));
	memset(out, 0, sizeof(out));
	d0 = put_dirent64(fake_getdents_mck_src, "dup", 32);
	d1 = put_dirent64(fake_getdents_mck_src + d0, "upper", 32);
	fake_getdents_mck_src_size = d0 + d1;
	fake_getdents_linux_src_size =
		put_dirent64(fake_getdents_linux_src, "dup", 32);
	fake_getdents_linux_src_size +=
		put_dirent64(fake_getdents_linux_src +
			     fake_getdents_linux_src_size, "cpu9", 32);
	fake_getdents_linux_src_size +=
		put_dirent64(fake_getdents_linux_src +
			     fake_getdents_linux_src_size, "lower", 32);
	snprintf(fake_overlay_getdents_linux_path,
		 sizeof(fake_overlay_getdents_linux_path), "%s",
		 "/sys/devices/system/cpu");
	fake_overlay_getdents_pathlen =
		strlen(fake_overlay_getdents_linux_path);
	fake_overlay_getdents_mck_cache_size = 0;
	fake_overlay_getdents_linux_cache_size = 0;
	fake_overlay_getdents_append_mck_count = 0;
	fake_overlay_getdents_append_linux_count = 0;
	fake_overlay_getdents_offset_log_count = 0;
	fake_overlay_getdents_upper_log_count = 0;
	fake_overlay_getdents_lower_log_count = 0;
	fake_overlay_getdents_blacklisted_log_count = 0;
	fake_overlay_getdents_dupe_log_count = 0;
	fake_overlay_getdents_mck_size_log_count = 0;
	fake_overlay_getdents_linux_size_log_count = 0;
	fake_getdents_mck_calls = 0;
	fake_getdents_linux_calls = 0;
	fake_lseek_count = 0;
	fake_lseek_current = 0;
	fake_lseek_advance = 0;
	rc = overlay_getdents(217, fake_overlay_getdents_fd, out, sizeof(out));
	require(rc == 96);
	require(fake_getdents_mck_calls == 2);
	require(fake_getdents_linux_calls == 2);
	require(fake_overlay_getdents_append_mck_count == 1);
	require(fake_overlay_getdents_append_linux_count == 1);
	require(fake_overlay_getdents_blacklisted_log_count == 1);
	require(fake_overlay_getdents_dupe_log_count == 1);
	require(fake_overlay_getdents_offset_log_count == 1);
	require(fake_overlay_getdents_upper_log_count == 2);
	require(fake_overlay_getdents_lower_log_count == 2);
	require(fake_overlay_getdents_mck_size_log_count == 1);
	require(fake_overlay_getdents_linux_size_log_count == 1);
	require(fake_lseek_advance == rc);
	require(strcmp(((struct fake_dirent64 *)out)->d_name, "dup") == 0);
	require(((struct fake_dirent64 *)out)->d_off == 32);
	require(strcmp(((struct fake_dirent64 *)(out + 32))->d_name,
		       "upper") == 0);
	require(((struct fake_dirent64 *)(out + 32))->d_off == 64);
	require(strcmp(((struct fake_dirent64 *)(out + 64))->d_name,
		       "lower") == 0);
	require(((struct fake_dirent64 *)(out + 64))->d_off == 96);
	mix(&digest, (unsigned long)fake_getdents_mck_calls);
	mix(&digest, (unsigned long)fake_overlay_getdents_dupe_log_count);

	memset(&sigwait, 0, sizeof(sigwait));
	memset(fake_getdents_passthrough, 0, sizeof(fake_getdents_passthrough));
	memset(out, 0, sizeof(out));
	fake_getdents_passthrough_size =
		put_dirent64(fake_getdents_passthrough, "actplain", 48);
	fake_getdents_passthrough_fd = 66;
	fake_getdents_passthrough_calls = 0;
	sigwait.sr.number = 1;
	sigwait.sr.args[0] = 66;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)out;
	sigwait.sr.args[2] = sizeof(out);
	act_getdents(&sigwait, 14, 6);
	require(fake_getdents_passthrough_calls == 1);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == (long)fake_getdents_passthrough_size);
	require(strcmp(((struct fake_dirent64 *)out)->d_name, "actplain") == 0);

	fake_perf_event_open_count = 0;
	fake_perf_event_open_ret = 123;
	act_perf_event_open(&sigwait, 14, 6);
	require(fake_perf_event_open_count == 1);
	require(fake_ret_desc.ret == 123);
	fake_perf_event_open_ret = -1;
	act_perf_event_open(&sigwait, 14, 6);
	require(fake_perf_event_open_count == 2);
	require(fake_ret_desc.ret == -1);
	mix(&digest, (unsigned long)fake_getdents_passthrough_calls);
	mix(&digest, (unsigned long)fake_perf_event_open_count);
	mix(&digest, (unsigned long)fake_ret_desc.ret);

	memset(&sigwait, 0, sizeof(sigwait));
	fake_clock_gettime_count = 0;
	fake_clock_gettime_log_count = 0;
	fake_clock_gettime_ret = 0;
	fake_clock_gettime_sec = 1234567;
	fake_clock_gettime_nsec = 890;
	sigwait.sr.args[0] = 0xabc000UL;
	sigwait.sr.args[1] = 7;
	act_futex_clock(&sigwait, 14, 6);
	require(fake_clock_gettime_count == 1);
	require(fake_clock_gettime_id == 7);
	require(fake_clock_gettime_log_count == 1);
	require(fake_clock_gettime_log_sec == 1234567);
	require(fake_clock_gettime_log_nsec == 890);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == 0);
	require(fake_ret_desc.dest == 0xabc000UL);
	require(fake_ret_desc.size == sizeof(struct fake_mcexec_timespec));
	require(fake_ret_desc.src != 0);

	fake_clock_gettime_ret = -EINVAL;
	act_futex_clock(&sigwait, 14, 6);
	require(fake_clock_gettime_count == 2);
	require(fake_ret_desc.ret == -EINVAL);

	fake_kill_thread_count = 0;
	sigwait.sr.args[1] = 7777;
	sigwait.sr.args[2] = 9;
	act_kill(&sigwait, 14, 6, (void *)(uintptr_t)0x12345678UL);
	require(fake_kill_thread_count == 1);
	require(fake_kill_thread_tid == 7777);
	require(fake_kill_thread_sig == 9);
	require(fake_kill_thread_arg == (void *)(uintptr_t)0x12345678UL);
	require(fake_ret_desc.ret == 0);

	fake_mcexec_waitid_count = 0;
	fake_mcexec_wait4_error_count = 0;
	fake_mcexec_waitid_ret = 4321;
	fake_mcexec_waitid_errno = 0;
	sigwait.sr.args[0] = 4321;
	sigwait.sr.args[2] = WNOWAIT | 0x1234;
	act_wait4(&sigwait, 14, 6);
	require(fake_mcexec_waitid_count == 1);
	require(fake_mcexec_waitid_pid == 4321);
	require(fake_mcexec_waitid_opt == (WEXITED | WNOWAIT));
	require(fake_mcexec_wait4_error_count == 0);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == 4321);

	fake_mcexec_waitid_ret = -1;
	fake_mcexec_waitid_errno = ECHILD;
	sigwait.sr.args[2] = 0;
	act_wait4(&sigwait, 14, 6);
	require(fake_mcexec_waitid_count == 2);
	require(fake_mcexec_waitid_opt == WEXITED);
	require(fake_mcexec_wait4_error_count == 1);
	require(fake_mcexec_wait4_error_requested == 4321);
	require(fake_mcexec_wait4_error_ret == -1);
	require(fake_mcexec_wait4_error_errno == ECHILD);
	require(fake_ret_desc.ret == -1);

	thread_data = &th1;
	fake_ioctl_result = 0;
	fake_ioctl_transfer_count = 0;
	fake_transfer_digest = 0;
	fake_transfer_bytes_size = 0;
	memset(fake_transfer_bytes, 0, sizeof(fake_transfer_bytes));
	fake_mcexec_gettid_alloc_error_count = 0;
	fake_mcexec_gettid_transfer_error_count = 0;
	sigwait.sr.args[4] = 5;
	sigwait.sr.args[5] = 0xcafe000UL;
	act_gettid(&sigwait, 77, 8);
	require(fake_ioctl_transfer_count == 1);
	require(fake_transfer_desc.rphys == 0xcafe000UL);
	require(fake_transfer_desc.size == sizeof(int) * 5);
	require(fake_transfer_desc.direction == MCEXEC_UP_TRANSFER_TO_REMOTE);
	require(fake_transfer_bytes_size == sizeof(int) * 5);
	require(((int *)fake_transfer_bytes)[0] == 11);
	require(((int *)fake_transfer_bytes)[1] == 44);
	require(((int *)fake_transfer_bytes)[2] == 0);
	require(((int *)fake_transfer_bytes)[3] == 0);
	require(((int *)fake_transfer_bytes)[4] == 0);
	require(fake_mcexec_gettid_alloc_error_count == 0);
	require(fake_mcexec_gettid_transfer_error_count == 0);
	require(fake_ret_desc.cpu == 8);
	require(fake_ret_desc.ret == 0);

	fake_ioctl_transfer_count = 0;
	sigwait.sr.args[4] = 0;
	act_gettid(&sigwait, 77, 8);
	require(fake_ioctl_transfer_count == 0);
	require(fake_ret_desc.ret == 0);

	fake_ioctl_result = -1;
	fake_ioctl_transfer_count = 0;
	fake_mcexec_gettid_transfer_error_count = 0;
	sigwait.sr.args[4] = 2;
	sigwait.sr.args[5] = 0xdead000UL;
	act_gettid(&sigwait, 77, 8);
	require(fake_ioctl_transfer_count == 1);
	require(fake_mcexec_gettid_transfer_error_count == 1);
	require(fake_ret_desc.ret == -EFAULT);
	fake_ioctl_result = 0;

	fake_debug_mlock_log_count = 0;
	fake_debug_mlock_count = 0;
	fake_debug_mlock_ret = -19;
	sigwait.sr.args[0] = (unsigned long)(uintptr_t)"debug-mlock";
	sigwait.sr.args[1] = 4096;
	act_debug_mlock(&sigwait, 77, 8);
	require(fake_debug_mlock_log_count == 1);
	require(fake_debug_mlock_log_addr ==
		(unsigned long)(uintptr_t)"debug-mlock");
	require(fake_debug_mlock_log_len == 4096);
	require(fake_debug_mlock_count == 1);
	require(fake_debug_mlock_addr ==
		(unsigned long)(uintptr_t)"debug-mlock");
	require(fake_debug_mlock_len == 4096);
	require(fake_ret_desc.cpu == 8);
	require(fake_ret_desc.ret == -19);

	fake_swapout_unavailable_count = 0;
	act_swapout_unavailable(&sigwait, 77, 8);
	require(fake_swapout_unavailable_count == 1);
	require(fake_ret_desc.cpu == 8);
	require(fake_ret_desc.ret == -1);

	{
		char spawn_exec[] = "/bin/spawn";
		char spawn_arg0[] = "spawn";
		char spawn_arg1[] = "--flag";
		char *spawn_args[] = { spawn_arg0, spawn_arg1, NULL };

		memset(&sigwait, 0, sizeof(sigwait));
		fake_ioctl_result = 0;
		fake_strncpy_copy = 1;
		fake_strncpy_result = 64;
		fake_ioctl_strncpy_count = 0;
		fake_posix_spawn_count = 0;
		fake_posix_spawn_ret = 0;
		fake_linux_spawn_invalid_arg_count = 0;
		fake_linux_spawn_strncpy_failed_count = 0;
		fake_linux_spawn_posix_failed_count = 0;
		sigwait.sr.args[0] = (unsigned long)(uintptr_t)spawn_exec;
		sigwait.sr.args[1] = (unsigned long)(uintptr_t)spawn_args;
		act_linux_spawn(&sigwait, 77, 8);
		require(fake_ioctl_strncpy_count == 3);
		require(fake_posix_spawn_count == 1);
		require(strcmp(fake_posix_spawn_path, "/bin/spawn") == 0);
		require(fake_posix_spawn_argc == 2);
		require(strcmp(fake_posix_spawn_argv[0], "spawn") == 0);
		require(strcmp(fake_posix_spawn_argv[1], "--flag") == 0);
		require(fake_posix_spawn_envp_is_null == 1);
		require(fake_linux_spawn_invalid_arg_count == 0);
		require(fake_linux_spawn_strncpy_failed_count == 0);
		require(fake_linux_spawn_posix_failed_count == 0);
		require(fake_ret_desc.cpu == 8);
		require(fake_ret_desc.ret == 0);

		fake_ioctl_strncpy_count = 0;
		fake_posix_spawn_count = 0;
		fake_posix_spawn_ret = 17;
		fake_linux_spawn_posix_failed_count = 0;
		act_linux_spawn(&sigwait, 77, 8);
		require(fake_ioctl_strncpy_count == 3);
		require(fake_posix_spawn_count == 1);
		require(fake_linux_spawn_posix_failed_count == 1);
		require(fake_linux_spawn_posix_failed_rc == 17);
		require(fake_ret_desc.ret == -1);

		memset(&sigwait, 0, sizeof(sigwait));
		fake_posix_spawn_count = 0;
		fake_linux_spawn_invalid_arg_count = 0;
		act_linux_spawn(&sigwait, 77, 8);
		require(fake_linux_spawn_invalid_arg_count == 1);
		require(fake_posix_spawn_count == 0);
		require(fake_ret_desc.ret == -1);
	}

	act_reserved_memory_syscall(&sigwait, 14, 6);
	require(fake_ret_desc.ret == -ENOSYS);
	mix(&digest, (unsigned long)fake_clock_gettime_count);
	mix(&digest, (unsigned long)fake_clock_gettime_log_nsec);
	mix(&digest, (unsigned long)fake_kill_thread_tid);
	mix(&digest, (unsigned long)fake_mcexec_waitid_count);
	mix(&digest, (unsigned long)fake_mcexec_wait4_error_errno);
	mix(&digest, fake_transfer_digest);
	mix(&digest, (unsigned long)fake_mcexec_gettid_transfer_error_count);
	mix(&digest, (unsigned long)fake_debug_mlock_count);
	mix(&digest, (unsigned long)fake_debug_mlock_ret);
	mix(&digest, (unsigned long)fake_swapout_unavailable_count);
	mix(&digest, (unsigned long)fake_posix_spawn_count);
	mix(&digest, (unsigned long)fake_linux_spawn_posix_failed_rc);
	mix(&digest, (unsigned long)fake_ret_desc.ret);

	memset(&sigwait, 0, sizeof(sigwait));
	fake_act_sigaction_count = 0;
	fake_act_sigaction_digest = 0;
	sigwait.sr.args[0] = 17;
	sigwait.sr.args[1] = 1;
	act_sigaction(&sigwait);
	require(fake_act_sigaction_count == 0);
	sigwait.sr.args[0] = 23;
	act_sigaction(&sigwait);
	require(fake_act_sigaction_count == 0);
	sigwait.sr.args[0] = 2;
	sigwait.sr.args[1] = 1;
	act_sigaction(&sigwait);
	require(fake_act_sigaction_count == 1);
	require(fake_act_sigaction_last_sig == 2);
	require(fake_act_sigaction_last_ignored == 1);
	sigwait.sr.args[0] = 15;
	sigwait.sr.args[1] = 0;
	act_sigaction(&sigwait);
	require(fake_act_sigaction_count == 2);
	require(fake_act_sigaction_last_sig == 15);
	require(fake_act_sigaction_last_ignored == 0);
	act_rt_sigaction(&sigwait, 14, 6);
	require(fake_act_sigaction_count == 3);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == 0);
	mix(&digest, fake_act_sigaction_digest);

	fake_act_sigprocmask_count = 0;
	fake_act_sigprocmask_mask = 0;
	fake_act_sigprocmask_digest = 0;
	sigwait.sr.args[0] = 0x55aaUL;
	act_sigprocmask(&sigwait);
	require(fake_act_sigprocmask_count == 1);
	require(fake_act_sigprocmask_mask == 0x55aaUL);
	sigwait.sr.args[0] = 0xaa55UL;
	act_rt_sigprocmask(&sigwait, 14, 6);
	require(fake_act_sigprocmask_count == 2);
	require(fake_act_sigprocmask_mask == 0xaa55UL);
	require(fake_ret_desc.ret == 0);
	mix(&digest, fake_act_sigprocmask_digest);

	sigwait.sr.args[0] = 1;
	sigwait.sr.args[1] = 4242;
	act_signalfd4_syscall(&sigwait, 14, 6);
	require(fake_ret_desc.cpu == 6);
	require(fake_ret_desc.ret == -EBADF);
	mix(&digest, (unsigned long)fake_ret_desc.ret);

	fake_ioctl_result = 0;
	fake_cred_count = 0;
	fake_cred_ret = 88;
	sigwait.sr.args[0] = 777;
	sigwait.sr.args[1] = 1;
	act_setfsuid(&sigwait, 55, 9);
	require(fake_cred_kind == 1);
	require(fake_cred_fd == 55);
	require(fake_cred_args[0] == 777);
	require(fake_ret_desc.cpu == 9);
	require(fake_ret_desc.ret == 0);

	fake_cred_ret = 89;
	sigwait.sr.args[1] = 0;
	act_setfsuid(&sigwait, 55, 9);
	require(fake_cred_kind == 2);
	require(fake_cred_args[0] == 777);
	require(fake_ret_desc.ret == 89);

	fake_cred_ret = -5;
	sigwait.sr.args[0] = 11;
	sigwait.sr.args[1] = 12;
	sigwait.sr.args[2] = 13;
	act_setresuid(&sigwait, 55, 9);
	require(fake_cred_kind == 3);
	require(fake_cred_args[0] == 11);
	require(fake_cred_args[1] == 12);
	require(fake_cred_args[2] == 13);
	require(fake_ret_desc.ret == -5);

	fake_cred_ret = -6;
	act_setreuid(&sigwait, 55, 9);
	require(fake_cred_kind == 4);
	require(fake_ret_desc.ret == -6);

	fake_cred_ret = -7;
	act_setuid(&sigwait, 55, 9);
	require(fake_cred_kind == 5);
	require(fake_cred_args[0] == 11);
	require(fake_ret_desc.ret == -7);

	fake_cred_ret = -8;
	act_setresgid(&sigwait, 55, 9);
	require(fake_cred_kind == 6);
	require(fake_cred_args[2] == 13);
	require(fake_ret_desc.ret == -8);

	fake_cred_ret = -9;
	act_setregid(&sigwait, 55, 9);
	require(fake_cred_kind == 7);
	require(fake_ret_desc.ret == -9);

	fake_cred_ret = -10;
	act_setgid(&sigwait, 55, 9);
	require(fake_cred_kind == 8);
	require(fake_ret_desc.ret == -10);

	fake_cred_ret = 101;
	act_setfsgid(&sigwait, 55, 9);
	require(fake_cred_kind == 9);
	require(fake_ret_desc.ret == 101);
	mix(&digest, (unsigned long)fake_cred_count);
	mix(&digest, (unsigned long)fake_cred_kind);
	mix(&digest, (unsigned long)fake_ret_desc.ret);

	memset(&sigwait, 0, sizeof(sigwait));
	fake_mcexec_generic_count = 0;
	fake_mcexec_generic_ret = 202;
	fake_overlay_delfd_count = 0;
	sigwait.sr.number = 3;
	sigwait.sr.args[0] = 77;
	act_close(&sigwait, 55, 9);
	require(fake_mcexec_generic_count == 1);
	require(fake_mcexec_generic_number == 3);
	require(fake_mcexec_generic_arg0 == 77);
	require(fake_overlay_delfd_count == 1);
	require(fake_overlay_delfd_fd == 77);
	require(fake_ret_desc.cpu == 9);
	require(fake_ret_desc.ret == 202);

	fake_mcexec_generic_count = 0;
	fake_overlay_delfd_count = 0;
	sigwait.sr.args[0] = 55;
	act_close(&sigwait, 55, 9);
	require(fake_mcexec_generic_count == 0);
		require(fake_overlay_delfd_count == 1);
		require(fake_overlay_delfd_fd == 55);
		require(fake_ret_desc.ret == -EBADF);

		fake_mcexec_generic_raw_count = 0;
		fake_mcexec_generic_raw_ret = 313;
		fake_mcexec_generic_raw_errno = 0;
		fake_mcexec_generic_start_count = 0;
		fake_mcexec_generic_done_count = 0;
		sigwait.sr.number = 909;
		sigwait.sr.args[0] = 0xaaa0;
		sigwait.sr.args[5] = 0xaaa5;
		require(mcexec_do_generic_syscall_body(&sigwait) == 313);
		require(fake_mcexec_generic_raw_count == 1);
		require(fake_mcexec_generic_raw_number == 909);
		require(fake_mcexec_generic_raw_arg0 == 0xaaa0);
		require(fake_mcexec_generic_raw_arg5 == 0xaaa5);
		require(fake_mcexec_generic_start_count == 1);
		require(fake_mcexec_generic_start_number == 909);
		require(fake_mcexec_generic_done_count == 1);
		require(fake_mcexec_generic_done_number == 909);
		require(fake_mcexec_generic_done_ret == 313);

		fake_mcexec_generic_raw_ret = -1;
		fake_mcexec_generic_raw_errno = EACCES;
		fake_mcexec_generic_start_count = 0;
		fake_mcexec_generic_done_count = 0;
		sigwait.sr.number = 910;
		require(mcexec_do_generic_syscall_body(&sigwait) == -EACCES);
		require(fake_mcexec_generic_raw_count == 2);
		require(fake_mcexec_generic_start_count == 1);
		require(fake_mcexec_generic_start_number == 910);
		require(fake_mcexec_generic_done_count == 1);
		require(fake_mcexec_generic_done_number == 910);
		require(fake_mcexec_generic_done_ret == -EACCES);

		fake_mcexec_generic_count = 0;
		fake_mcexec_generic_ret = -303;
		sigwait.sr.number = 404;
	sigwait.sr.args[0] = 0xbeef;
	act_generic_syscall(&sigwait, 55, 9);
	require(fake_mcexec_generic_count == 1);
	require(fake_mcexec_generic_number == 404);
	require(fake_mcexec_generic_arg0 == 0xbeef);
	require(fake_ret_desc.cpu == 9);
	require(fake_ret_desc.ret == -303);

	fake_path_open_log_count = 0;
	fake_path_bridge_count = 0;
	fake_path_bridge_ret = 35;
	fake_strncpy_result = (long)strlen("/proc/self/status");
	fake_overlay_addfd_publish_count = 0;
	memset(&sigwait, 0, sizeof(sigwait));
	sigwait.sr.number = 257;
	sigwait.sr.rtid = 555;
	sigwait.sr.args[0] = (unsigned long)-100;
	sigwait.sr.args[1] = (unsigned long)(uintptr_t)"/proc/self/status";
	sigwait.sr.args[2] = 0x200;
	sigwait.sr.args[3] = 0600;
	lrc = -444;
	require(act_main_loop_syscall(&sigwait, 55, 11, &th1, long_path,
				      huge_path, &lrc, 0) == 0);
	require(lrc == -444);
	require(fake_path_open_log_count == 1);
	require(fake_path_bridge_kind == 9);
	require(fake_ret_desc.cpu == 11);
	require(fake_ret_desc.ret == 35);

	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_isatty_result = 0;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	memset(&sigwait, 0, sizeof(sigwait));
	sigwait.sr.number = 231;
	sigwait.sr.args[0] = 4 << 8;
	lrc = -555;
	require(act_main_loop_syscall(&sigwait, 55, 12, &th1, long_path,
				      huge_path, &lrc, 0) == 1);
	require(lrc == (4 << 8));
	require(fake_mcexec_exit_debug_count == 1);
	require(fake_mcexec_exit_process_count == 1);
	require(fake_mcexec_exit_process_term == 4);

	fake_mcexec_generic_count = 0;
	fake_mcexec_generic_ret = -404;
	memset(&sigwait, 0, sizeof(sigwait));
	sigwait.sr.number = 7777;
	sigwait.sr.args[0] = 0x1234;
	lrc = -666;
	require(act_main_loop_syscall(&sigwait, 55, 13, &th1, long_path,
				      huge_path, &lrc, 0) == 0);
	require(lrc == -666);
	require(fake_mcexec_generic_count == 1);
	require(fake_mcexec_generic_number == 7777);
	require(fake_mcexec_generic_arg0 == 0x1234);
	require(fake_ret_desc.cpu == 13);
	require(fake_ret_desc.ret == -404);
	mix(&digest, (unsigned long)fake_mcexec_generic_number);
	mix(&digest, (unsigned long)fake_mcexec_exit_process_term);

	fake_main_loop_log_count = 0;
	fake_mcexec_generic_count = 0;
	fake_mcexec_generic_ret = -505;
	memset(&sigwait, 0, sizeof(sigwait));
	th1.cpu = 14;
	th1.remote_tid = 222;
	th1.remote_cpu = 333;
	sigwait.cpu = 88;
	sigwait.sr.number = 1;
	sigwait.sr.rtid = 777;
	sigwait.sr.args[0] = 1;
	lrc = -777;
	require(act_main_loop_iteration(&sigwait, 55, &th1, long_path,
					huge_path, &lrc, 0) == 0);
	require(lrc == -777);
	require(fake_main_loop_log_count == 0);
	require(fake_mcexec_generic_count == 1);
	require(fake_ret_desc.cpu == 14);
	require(fake_ret_desc.ret == -505);
	require(th1.remote_tid == -1);
	require(th1.remote_cpu == 88);

	fake_main_loop_log_count = 0;
	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_isatty_result = 0;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	memset(&sigwait, 0, sizeof(sigwait));
	th1.cpu = 15;
	th1.remote_tid = 222;
	th1.remote_cpu = 333;
	sigwait.cpu = 91;
	sigwait.sr.number = 231;
	sigwait.sr.rtid = 889;
	sigwait.sr.args[0] = 5 << 8;
	lrc = -888;
	require(act_main_loop_iteration(&sigwait, 55, &th1, long_path,
					huge_path, &lrc, 0) == 1);
	require(lrc == (5 << 8));
	require(fake_main_loop_log_count == 1);
	require(fake_main_loop_log_cpu == 15);
	require(fake_main_loop_log_number == 231);
	require(fake_mcexec_exit_process_count == 1);
	require(fake_mcexec_exit_process_term == 5);
	require(th1.remote_tid == 889);
	require(th1.remote_cpu == 91);
	mix(&digest, (unsigned long)(th1.remote_tid + th1.remote_cpu));

	memset(fake_wait_descs, 0, sizeof(fake_wait_descs));
	memset(fake_wait_results, 0, sizeof(fake_wait_results));
	memset(fake_wait_errno, 0, sizeof(fake_wait_errno));
	memset(fake_wait_seen_cpu, 0, sizeof(fake_wait_seen_cpu));
	memset(fake_wait_seen_pid, 0, sizeof(fake_wait_seen_pid));
	fake_wait_index = 0;
	fake_wait_len = 3;
	fake_wait_results[0] = -1;
	fake_wait_errno[0] = EINTR;
	fake_wait_results[1] = 0;
	fake_wait_descs[1].cpu = 123;
	fake_wait_descs[1].sr.number = 1;
	fake_wait_descs[1].sr.rtid = 456;
	fake_wait_descs[1].sr.args[0] = 1;
	fake_wait_results[2] = -1;
	fake_wait_errno[2] = EIO;
	fake_main_loop_timeout_count = 0;
	fake_main_loop_log_count = 0;
	fake_mcexec_generic_count = 0;
	fake_mcexec_generic_ret = -606;
	memset(&fake_ret_desc, 0, sizeof(fake_ret_desc));
	th1.cpu = 16;
	th1.remote_tid = 321;
	th1.remote_cpu = 654;
	require(act_main_loop_body(&th1, 66, 0) == 1);
	require(fake_wait_index == 3);
	require(fake_wait_seen_cpu[0] == 16);
	require(fake_wait_seen_pid[0] == getpid());
	require(fake_main_loop_timeout_count == 1);
	require(fake_main_loop_log_count == 0);
	require(fake_mcexec_generic_count == 1);
	require(fake_ret_desc.cpu == 16);
	require(fake_ret_desc.ret == -606);
	require(th1.remote_tid == -1);
	require(th1.remote_cpu == 123);

	memset(fake_wait_descs, 0, sizeof(fake_wait_descs));
	memset(fake_wait_results, 0, sizeof(fake_wait_results));
	memset(fake_wait_errno, 0, sizeof(fake_wait_errno));
	fake_wait_index = 0;
	fake_wait_len = 1;
	fake_wait_results[0] = 0;
	fake_wait_descs[0].cpu = 124;
	fake_wait_descs[0].sr.number = 231;
	fake_wait_descs[0].sr.rtid = 557;
	fake_wait_descs[0].sr.args[0] = 9 << 8;
	fake_main_loop_timeout_count = 0;
	fake_main_loop_log_count = 0;
	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_isatty_result = 0;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	th1.cpu = 17;
	th1.remote_tid = 321;
	th1.remote_cpu = 654;
	require(act_main_loop_body(&th1, 77, 0) == (9 << 8));
	require(fake_wait_index == 1);
	require(fake_main_loop_timeout_count == 0);
	require(fake_main_loop_log_count == 1);
	require(fake_main_loop_log_cpu == 17);
	require(fake_main_loop_log_number == 231);
	require(fake_mcexec_exit_process_count == 1);
	require(th1.remote_tid == 557);
	require(th1.remote_cpu == 124);
	mix(&digest, (unsigned long)(fake_wait_index + th1.remote_tid));

	fake_thread_barrier_wait_count = 0;
	fake_thread_barrier_wait_ptr = NULL;
	memset(fake_wait_descs, 0, sizeof(fake_wait_descs));
	memset(fake_wait_results, 0, sizeof(fake_wait_results));
	memset(fake_wait_errno, 0, sizeof(fake_wait_errno));
	memset(fake_wait_seen_cpu, 0, sizeof(fake_wait_seen_cpu));
	fake_wait_index = 0;
	fake_wait_len = 1;
	fake_wait_results[0] = -1;
	fake_wait_errno[0] = EIO;
	fake_main_loop_timeout_count = 0;
	fake_main_loop_is_child = 0;
	fd = 88;
	{
		struct fake_thread_data loop_thread = {
			.cpu = 21,
			.tid = 0,
			.remote_tid = 999,
			.ret = -1,
			.init_ready = (void *)0xabc0UL,
		};

		require(mcexec_main_loop_thread_func_body(&loop_thread) == NULL);
		require(loop_thread.tid == 12345);
		require(loop_thread.remote_tid == -1);
		require(loop_thread.ret == 1);
		require(fake_wait_index == 1);
		require(fake_wait_seen_cpu[0] == 21);
		require(fake_ioctl_fd == 88);
	}
	require(fake_thread_barrier_wait_count == 1);
	require(fake_thread_barrier_wait_ptr == (void *)0xabc0UL);
	require(fake_main_loop_timeout_count == 1);

	fake_thread_barrier_wait_count = 0;
	memset(fake_wait_descs, 0, sizeof(fake_wait_descs));
	memset(fake_wait_results, 0, sizeof(fake_wait_results));
	memset(fake_wait_errno, 0, sizeof(fake_wait_errno));
	fake_wait_index = 0;
	fake_wait_len = 1;
	fake_wait_results[0] = -1;
	fake_wait_errno[0] = EIO;
	fake_main_loop_timeout_count = 0;
	fake_main_loop_is_child = 1;
	fd = 99;
	{
		struct fake_thread_data loop_thread = {
			.cpu = 22,
			.tid = 0,
			.remote_tid = 123,
			.ret = 0,
			.init_ready = NULL,
		};

		require(mcexec_main_loop_thread_func_body(&loop_thread) == NULL);
		require(loop_thread.tid == 12345);
		require(loop_thread.remote_tid == -1);
		require(loop_thread.ret == 1);
		require(fake_wait_index == 1);
		require(fake_wait_seen_cpu[0] == 22);
		require(fake_ioctl_fd == 99);
		mix(&digest, (unsigned long)(loop_thread.tid + loop_thread.ret));
	}
	require(fake_thread_barrier_wait_count == 0);
	require(fake_main_loop_timeout_count == 1);

		{
			struct fake_thread_data previous = { .tid = 707 };
			struct fake_thread_data *saved_thread_data = thread_data;
			struct fake_thread_data *created = NULL;

			memset(&fake_create_worker_storage, 0xa5,
			       sizeof(fake_create_worker_storage));
			fake_create_worker_alloc_count = 0;
			fake_create_worker_alloc_fail = 0;
			fake_create_worker_alloc_error_count = 0;
			fake_create_worker_next_cpu_count = 0;
			fake_create_worker_next_cpu_value = 42;
			fake_create_worker_lock_count = 0;
			fake_create_worker_lock_ptr = (void *)0x7000UL;
			fake_create_worker_publish_count = 0;
			fake_create_worker_publish_tp = NULL;
			fake_create_worker_publish_out = NULL;
			fake_create_worker_publish_order = 0;
			fake_create_worker_pthread_count = 0;
			fake_create_worker_pthread_tp = NULL;
			fake_create_worker_pthread_ret = 0;
			fake_create_worker_pthread_order = 0;
			fake_create_worker_event_order = 0;
			thread_data = &previous;

			require(mcexec_create_worker_thread_body(&created,
								 (void *)0x9000UL) == 0);
			require(created == &fake_create_worker_storage);
			require(fake_create_worker_alloc_count == 1);
			require(fake_create_worker_alloc_error_count == 0);
			require(fake_create_worker_next_cpu_count == 1);
			require(fake_create_worker_lock_count == 1);
			require(fake_create_worker_publish_count == 1);
			require(fake_create_worker_pthread_count == 1);
			require(fake_create_worker_storage.cpu == 42);
			require(fake_create_worker_storage.lock == (void *)0x7000UL);
			require(fake_create_worker_storage.init_ready == (void *)0x9000UL);
			require(fake_create_worker_storage.terminate == 0);
			require(fake_create_worker_storage.next == &previous);
			require(thread_data == &fake_create_worker_storage);
			require(fake_create_worker_storage.thread_id == 0xfeedUL);
			require(fake_create_worker_publish_tp == &fake_create_worker_storage);
			require(fake_create_worker_publish_out == &created);
			require(fake_create_worker_pthread_tp == &fake_create_worker_storage);
			require(fake_create_worker_publish_order == 1);
			require(fake_create_worker_pthread_order == 2);
			mix(&digest, (unsigned long)(fake_create_worker_storage.cpu +
						     fake_create_worker_pthread_order));

			fake_create_worker_alloc_fail = 1;
			fake_create_worker_alloc_count = 0;
			fake_create_worker_alloc_error_count = 0;
			fake_create_worker_publish_count = 0;
			fake_create_worker_pthread_count = 0;
			created = (struct fake_thread_data *)0x1234UL;
			require(mcexec_create_worker_thread_body(&created,
								 (void *)0x9001UL) == 12);
			require(created == (struct fake_thread_data *)0x1234UL);
			require(fake_create_worker_alloc_count == 1);
			require(fake_create_worker_alloc_error_count == 1);
			require(fake_create_worker_publish_count == 0);
			require(fake_create_worker_pthread_count == 0);

			fake_create_worker_alloc_fail = 0;
			fake_create_worker_pthread_ret = 17;
			fake_create_worker_publish_count = 0;
			fake_create_worker_pthread_count = 0;
			fake_create_worker_event_order = 0;
			thread_data = &previous;
			require(mcexec_create_worker_thread_body(NULL,
								 (void *)0x9002UL) == 17);
			require(fake_create_worker_publish_count == 1);
			require(fake_create_worker_pthread_count == 1);
			require(fake_create_worker_publish_out == NULL);
			require(fake_create_worker_publish_order == 1);
			require(fake_create_worker_pthread_order == 2);

				thread_data = saved_thread_data;
			}

			{
				struct fake_thread_data *saved_thread_data = thread_data;
				struct fake_thread_data kill_nomatch = { .remote_tid = 9999 };
				struct fake_thread_data kill_esrch = { .remote_tid = 7777,
					.next = &kill_nomatch };
				struct fake_thread_data kill_match = { .remote_tid = 7777,
					.next = &kill_esrch };
				struct fake_thread_data kill_self = { .remote_tid = 7777,
					.next = &kill_match };

				fake_kill_thread_head_count = 0;
				fake_kill_thread_pthread_count = 0;
				memset(fake_kill_thread_pthread_tp, 0,
				       sizeof(fake_kill_thread_pthread_tp));
				memset(fake_kill_thread_pthread_sig, 0,
				       sizeof(fake_kill_thread_pthread_sig));
				fake_kill_thread_esrch_tp = &kill_esrch;
				fake_kill_thread_not_found_count = 0;
				thread_data = &kill_self;

				mcexec_kill_thread_body(7777, 0, &kill_self);
				require(fake_kill_thread_head_count == 1);
				require(fake_kill_thread_pthread_count == 2);
				require(fake_kill_thread_pthread_tp[0] == &kill_match);
				require(fake_kill_thread_pthread_tp[1] == &kill_esrch);
				require(fake_kill_thread_pthread_sig[0] == SIGURG);
				require(fake_kill_thread_pthread_sig[1] == SIGURG);
				require(fake_kill_thread_not_found_count == 1);
				require(fake_kill_thread_not_found_tid == 7777);
				require(fake_kill_thread_not_found_sig == SIGURG);

				fake_kill_thread_pthread_count = 0;
				fake_kill_thread_not_found_count = 0;
				mcexec_kill_thread_body((unsigned long)-1, 12, NULL);
				require(fake_kill_thread_pthread_count == 0);
				require(fake_kill_thread_not_found_count == 0);
				mix(&digest, (unsigned long)(fake_kill_thread_head_count +
							     fake_kill_thread_pthread_sig[0]));

				thread_data = saved_thread_data;
			}

			{
				struct fake_thread_data *saved_thread_data = thread_data;
				struct fake_thread_data join_already = { .thread_id = 3,
				.joined = 1 };
			struct fake_thread_data join_detached = { .thread_id = 2,
				.detached = 1, .next = &join_already };
			struct fake_thread_data join_first = { .thread_id = 1,
				.next = &join_detached };
			struct fake_thread_data join_inserted = { .thread_id = 4 };

			fake_join_all_threads_head_count = 0;
			fake_join_all_threads_join_count = 0;
			memset(fake_join_all_threads_joined, 0,
			       sizeof(fake_join_all_threads_joined));
			fake_join_all_threads_insert_head = &join_inserted;
			thread_data = &join_first;

			mcexec_join_all_threads_body();
			require(fake_join_all_threads_head_count == 3);
			require(fake_join_all_threads_join_count == 2);
			require(fake_join_all_threads_joined[0] == &join_first);
			require(fake_join_all_threads_joined[1] == &join_inserted);
			require(join_first.joined == 1);
			require(join_inserted.joined == 1);
			require(join_detached.joined == 0);
			require(join_already.joined == 1);
			require(thread_data == &join_inserted);
			require(join_inserted.next == &join_first);
			mix(&digest, (unsigned long)(fake_join_all_threads_head_count +
						     fake_join_all_threads_join_count));

			thread_data = saved_thread_data;
		}

	{
		struct fake_uti_desc util_desc;
		struct fake_thread_data util_thread_data;

		memset(&util_thread_data, 0, sizeof(util_thread_data));

		reset_fake_util_thread();
		require(mcexec_util_thread_body(&util_thread_data, 0x1000, 77,
						0, 0x2000, 0) == -EINVAL);
		require(fake_util_missing_desc_count == 1);
		require(fake_util_barrier_init_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fake_util_create_worker_ret = 17;
		require(mcexec_util_thread_body(&util_thread_data, 0x1001, 78,
						0, 0x2001,
						(unsigned long)&util_desc) ==
			-EINVAL);
		require(fake_util_desc_log_ptr == &util_desc);
		require(fake_util_barrier_init_count == 1);
		require(fake_util_create_worker_count == 1);
		require(fake_util_worker_error_count == 1);
		require(fake_util_worker_error_rc == 17);
		require(fake_util_barrier_wait_count == 0);
		require(fake_util_get_ctx_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fd = 66;
		page_size = 8192;
		fake_util_get_ctx_result = -1;
		fake_util_get_ctx_errno = EIO;
		require(mcexec_util_thread_body(&util_thread_data, 0x1010, 79,
						0, 0x2020,
						(unsigned long)&util_desc) ==
			-EIO);
		require(util_desc.fd == 66);
		require(fake_util_syscall_888_count == 1);
		require(fake_util_get_ctx_count == 1);
		require(fake_util_get_ctx_desc.rp_rctx == 0x1010);
		require(fake_util_get_ctx_desc.rctx == util_desc.rctx);
		require(fake_util_get_ctx_desc.lctx == util_desc.lctx);
		require(fake_util_get_ctx_desc.uti_refill_tid == 4321);
		require(fake_util_get_ctx_error_count == 1);
		require(fake_util_get_ctx_error_errno == EIO);
		require(util_desc.mck_tid == 0);
		require(fake_util_switch_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fd = 67;
		page_size = 1;
		require(mcexec_util_thread_body(&util_thread_data, 0x1020, 80,
						0, 0x2030,
						(unsigned long)&util_desc) ==
			-ENOMEM);
		require(util_desc.key == fake_util_get_ctx_key);
		require(util_desc.mck_tid == 80);
		require(util_desc.pid == getpid());
		require(util_desc.tid == 12345);
		require(util_desc.uti_info == 0x2030);
		require(fake_util_param_large_count == 1);
		require(util_desc.start_syscall_intercept == 0);
		require(fake_util_attr_count == 0);
		require(fake_util_switch_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fd = 68;
		page_size = 8192;
		fake_util_attr_result = -1;
		fake_util_attr_errno = EACCES;
		require(setenv("UTI_CPU_SET", "0-3", 1) == 0);
		require(mcexec_util_thread_body(&util_thread_data, 0x1030, 81,
						0x4444, 0x2040,
						(unsigned long)&util_desc) ==
			-EACCES);
		require(fake_util_attr_count == 1);
		require(fake_util_attr_desc.phys_attr == 0x4444);
		require(strcmp(fake_util_attr_desc.uti_cpu_set_str, "0-3") == 0);
		require(fake_util_attr_desc.uti_cpu_set_len == strlen("0-3") + 1);
		require(fake_util_attr_error_count == 1);
		require(fake_util_attr_error_errno == EACCES);
		require(util_desc.start_syscall_intercept == 0);
		require(fake_util_switch_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fd = 69;
		page_size = 8192;
		fake_util_syscall_888_ret = 5;
		fake_util_switch_ret = -22;
		require(mcexec_util_thread_body(&util_thread_data, 0x1040, 82,
						0x5555, 0x2050,
						(unsigned long)&util_desc) ==
			-22);
		require(fake_util_intercept_warning_count == 1);
		require(fake_util_intercept_warning_rc == 5);
		require(fake_util_worker_tid_log_count == 1);
		require(fake_util_worker_tid_log_value == 4321);
		require(util_desc.fd == 69);
		require(util_desc.mck_tid == 82);
		require(util_desc.key == fake_util_get_ctx_key);
		require(util_desc.pid == getpid());
		require(util_desc.tid == 12345);
		require(util_desc.uti_info == 0x2050);
		require(util_desc.start_syscall_intercept == 1);
		require(fake_util_switch_count == 1);
		require(fake_util_switch_desc.rctx == util_desc.rctx);
		require(fake_util_switch_desc.lctx == util_desc.lctx);
		require(fake_util_switch_lctx == util_desc.lctx);
		require(fake_util_switch_rctx == util_desc.rctx);
		require(fake_util_switch_failed_count == 1);
		require(fake_util_switch_failed_rc == -22);
		require(fake_util_switch_returned_count == 0);

		reset_fake_util_thread();
		memset(&util_desc, 0, sizeof(util_desc));
		fd = 70;
		page_size = 8192;
		fake_util_switch_ret = 0;
		require(mcexec_util_thread_body(&util_thread_data, 0x1050, 83,
						0, 0x2060,
						(unsigned long)&util_desc) ==
			-EINVAL);
		require(fake_util_attr_count == 0);
		require(fake_util_switch_returned_count == 1);
		require(fake_util_switch_returned_rc == 0);
		require(fake_util_switch_failed_count == 0);
		require(unsetenv("UTI_CPU_SET") == 0);

		mix(&digest, (unsigned long)(fake_util_get_ctx_count +
					     fake_util_attr_count +
					     fake_util_switch_count));
		mix(&digest, util_desc.key);
	}

		memset(&sigwait, 0, sizeof(sigwait));
		fake_sched_util_count = 0;
	fake_sched_invalid_count = 0;
	fake_sched_util_ret = -13;
	sigwait.sr.rtid = 888;
	sigwait.sr.args[0] = 0;
	sigwait.sr.args[1] = 0x1000;
	sigwait.sr.args[2] = 0x2000;
	sigwait.sr.args[3] = 0x3000;
	sigwait.sr.args[4] = 0x4000;
	act_sched_setaffinity(&sigwait, 55, 9,
			      (void *)(uintptr_t)0xfeedfaceUL);
	require(fake_sched_util_count == 1);
	require(fake_sched_util_thread == (void *)(uintptr_t)0xfeedfaceUL);
	require(fake_sched_util_args[0] == 0x1000);
	require(fake_sched_util_args[1] == 888);
	require(fake_sched_util_args[2] == 0x2000);
	require(fake_sched_util_args[3] == 0x3000);
	require(fake_sched_util_args[4] == 0x4000);
	require(fake_sched_invalid_count == 0);
	require(fake_ret_desc.ret == -13);

	sigwait.sr.args[0] = 123;
	act_sched_setaffinity(&sigwait, 55, 9,
			      (void *)(uintptr_t)0xfeedfaceUL);
	require(fake_sched_util_count == 1);
	require(fake_sched_invalid_count == 1);
	require(fake_sched_invalid_pid == 123);
	require(fake_ret_desc.ret == -EINVAL);
	mix(&digest, (unsigned long)fake_mcexec_generic_count);
	mix(&digest, (unsigned long)fake_mcexec_generic_number);
	mix(&digest, (unsigned long)fake_overlay_delfd_fd);
	mix(&digest, (unsigned long)fake_sched_util_count);
	mix(&digest, (unsigned long)fake_sched_invalid_pid);

	memset(siginfo_blob, 0, sizeof(siginfo_blob));
	for (size_t j = 0; j < sizeof(siginfo_blob); j++)
		siginfo_blob[j] = (unsigned char)(0xa0 + j);
	fake_pipe2_count = 0;
	fake_pipe2_flags = 0;
	fake_pipe2_result = 0;
	fake_pipe2_read_fd = 71;
	fake_pipe2_write_fd = 72;
	fake_act_signalfd4_write_count = 0;
	fake_act_signalfd4_write_digest = 0;
	fake_act_signalfd4_write_result = sizeof(siginfo_blob);
	fake_act_signalfd4_write_error_count = 0;
	fake_close_count = 0;
	memset(fake_closed_fds, -1, sizeof(fake_closed_fds));

	sigwait.sr.args[0] = 0;
	sigwait.sr.args[1] = SFD_NONBLOCK | SFD_CLOEXEC;
	require(act_signalfd4(&sigwait) == 71);
	require(fake_pipe2_count == 1);
	require(fake_pipe2_flags == (O_NONBLOCK | O_CLOEXEC));

	sigwait.sr.args[0] = 2;
	sigwait.sr.args[1] = 999;
	sigwait.sr.args[2] = (unsigned long)(uintptr_t)siginfo_blob;
	require(act_signalfd4(&sigwait) == -EBADF);
	require(fake_act_signalfd4_write_count == 0);

	sigwait.sr.args[1] = 71;
	require(act_signalfd4(&sigwait) == 0);
	require(fake_act_signalfd4_write_count == 1);
	require(fake_act_signalfd4_write_fd == 72);
	require(fake_act_signalfd4_write_len == sizeof(siginfo_blob));
	require(fake_act_signalfd4_write_error_count == 0);

	fake_act_signalfd4_write_result = 7;
	require(act_signalfd4(&sigwait) == -EBADF);
	require(fake_act_signalfd4_write_count == 2);
	require(fake_act_signalfd4_write_error_count == 1);

	sigwait.sr.args[0] = 1;
	sigwait.sr.args[1] = 999;
	require(act_signalfd4(&sigwait) == -EBADF);
	require(fake_close_count == 0);
	sigwait.sr.args[1] = 71;
	require(act_signalfd4(&sigwait) == 0);
	require(fake_close_count == 2);
	require(fake_closed_fds[0] == 71);
	require(fake_closed_fds[1] == 72);
	require(act_signalfd4(&sigwait) == -EBADF);
	mix(&digest, fake_act_signalfd4_write_digest);
	mix(&digest, (unsigned long)fake_close_count + fake_closed_fds[1]);

	mcexec_errno_value = -1;
	require(atobytes(atobytes_kib) == 2048);
	require(mcexec_errno_value == 0);
	mcexec_errno_value = -1;
	require(atobytes(atobytes_empty) == 0);
	require(mcexec_errno_value == ERANGE);
	mix(&digest, (unsigned long)mcexec_errno_value + 2048);

	memset(out, 0xa5, sizeof(out));
	rc = mcexec_usage_line_result(out, sizeof(out), "mcexec", 0);
	require(rc == (int)strlen("usage: mcexec [-c target_core] [-n nr_partitions] [--mpol-threshold=N] [--enable-straight-map] [--extend-heap-by=N] [-s (--stack-premap=)[premap_size][,max]] [--mpol-no-heap] [--mpol-no-bss] [--mpol-no-stack] [--mpol-shm-premap] [--disable-sched-yield]  [--enable-uti] [--uti-thread-rank=N] [--uti-use-last-cpu] [<mcos-id>] (program) [args...]\n"));
	require(!strcmp(out, "usage: mcexec [-c target_core] [-n nr_partitions] [--mpol-threshold=N] [--enable-straight-map] [--extend-heap-by=N] [-s (--stack-premap=)[premap_size][,max]] [--mpol-no-heap] [--mpol-no-bss] [--mpol-no-stack] [--mpol-shm-premap] [--disable-sched-yield]  [--enable-uti] [--uti-thread-rank=N] [--uti-use-last-cpu] [<mcos-id>] (program) [args...]\n"));
	require(mcexec_usage_line_result(out, 12, "mcexec", 0) ==
		-ENAMETOOLONG);
	mix(&digest, (unsigned long)rc);

	memset(out, 0xa5, sizeof(out));
	rc = mcexec_usage_line_result(out, sizeof(out), "mcexec", 1);
	require(strstr(out, "[<-e ENV_NAME=value>...]") != NULL);
	mix(&digest, (unsigned long)rc);

	usage_add_envs_option = 0;
	usage_capture_len = 0;
	memset(usage_capture, 0, sizeof(usage_capture));
	print_usage(usage_argv);
	require(strstr(usage_capture, "usage: mcexec") != NULL);
	require(strstr(usage_capture, "ENV_NAME=value") == NULL);
	usage_add_envs_option = 1;
	usage_capture_len = 0;
	memset(usage_capture, 0, sizeof(usage_capture));
	print_usage(usage_argv);
	require(strstr(usage_capture, "usage: mcexec") != NULL);
	require(strstr(usage_capture, "ENV_NAME=value") != NULL);
	mix(&digest, (unsigned long)usage_capture_len);

	planned_heap = 0;
	planned_mcosid = -1;
	planned_optind = -1;
	rc = mcexec_post_options_plan_result(1, 3, "7",
					     ULONG_MAX, 4096, 0,
					     &planned_heap, &planned_mcosid,
					     &planned_optind);
	require(rc == 0);
	require(planned_heap == 4096);
	require(planned_mcosid == 7);
	require(planned_optind == 2);
	mix(&digest, planned_heap + (unsigned long)planned_mcosid);

	planned_heap = 0;
	planned_mcosid = -1;
	planned_optind = -1;
	rc = mcexec_post_options_plan_result(1, 2, "/bin/true",
					     8192, 4096, 3,
					     &planned_heap, &planned_mcosid,
					     &planned_optind);
	require(rc == 0);
	require(planned_heap == 8192);
	require(planned_mcosid == 3);
	require(planned_optind == 1);

	planned_heap = 0;
	planned_mcosid = -1;
	planned_optind = -1;
	rc = mcexec_post_options_plan_result(1, 2, "8",
					     ULONG_MAX, 4096, 0,
					     &planned_heap, &planned_mcosid,
					     &planned_optind);
	require(rc == -EINVAL);
	require(planned_heap == 4096);
	require(planned_mcosid == 8);
	require(planned_optind == 2);

	rc = mcexec_post_options_plan_result(2, 2, NULL, 8192, 4096, 0,
					     &planned_heap, &planned_mcosid,
					     &planned_optind);
	require(rc == -EINVAL);

	argv_flat = NULL;
	rc = mcexec_flatten_strings_result(NULL, flat_argv0, &argv_flat);
	require(rc > 0);
	flat_words = (long *)argv_flat;
	require(flat_words[0] == 2);
	require(!strcmp(argv_flat + flat_words[1], "cmd"));
	require(!strcmp(argv_flat + flat_words[2], "arg"));
	require(flat_words[3] == rc);
	argv_flat2 = NULL;
	rc = mcexec_flatten_strings_result(argv_flat, flat_argv1,
					   &argv_flat2);
	require(rc > 0);
	flat_words = (long *)argv_flat2;
	require(flat_words[0] == 3);
	require(!strcmp(argv_flat2 + flat_words[1], "cmd"));
	require(!strcmp(argv_flat2 + flat_words[2], "arg"));
	require(!strcmp(argv_flat2 + flat_words[3], "tail"));
	require(flat_words[4] == rc);
	argv_flat2_len = rc;
	mix(&digest, (unsigned long)rc + (unsigned long)flat_words[3]);

	argv_flat_public = NULL;
	rc = flatten_strings(NULL, flat_argv0, &argv_flat_public);
	require(rc > 0);
	flat_words = (long *)argv_flat_public;
	require(flat_words[0] == 2);
	require(!strcmp(argv_flat_public + flat_words[1], "cmd"));
	require(!strcmp(argv_flat_public + flat_words[2], "arg"));
	require(flat_words[3] == rc);
	mix(&digest, (unsigned long)flat_words[3]);
	free(argv_flat_public);

	shebang_argv = NULL;
	require(mcexec_shebang_argv_extend_result(&shebang_argv,
						  shebang0) == 0);
	require(!strcmp(shebang_argv[0], "/usr/bin/env"));
	require(!strcmp(shebang_argv[1], "python"));
	require(shebang_argv[2] == NULL);
	require(mcexec_shebang_argv_extend_result(&shebang_argv,
						  shebang1) == 0);
	require(!strcmp(shebang_argv[0], "/bin/sh"));
	require(!strcmp(shebang_argv[1], "/usr/bin/env"));
	require(!strcmp(shebang_argv[2], "python"));
	require(shebang_argv[3] == NULL);
	mix(&digest, (unsigned long)(unsigned char)shebang_argv[1][1]);
	free(shebang_argv);

	for (i = 0; i < (int)sizeof(desc_blob); i++)
		desc_blob[i] = (char)(0x30 + i);
	buffer = NULL;
	transfer_size = 0;
	require(mcexec_execve1_transfer_buffer_result(
			desc_blob, sizeof(desc_blob), argv_flat2, argv_flat2_len,
			&buffer, &transfer_size) == 0);
	require(transfer_size == sizeof(desc_blob) + (size_t)argv_flat2_len);
	require(!memcmp(buffer, desc_blob, sizeof(desc_blob)));
	require(!memcmp(buffer + sizeof(desc_blob), argv_flat2, argv_flat2_len));
	mix(&digest, transfer_size + (unsigned long)(unsigned char)buffer[3]);
	free(buffer);
	free(argv_flat);
	free(argv_flat2);

	require(mcexec_syscall_should_log_result(1, 1, 1) == 0);
	require(mcexec_syscall_should_log_result(1, 2, 1) == 1);
	require(mcexec_syscall_should_log_result(60, 1, 1) == 1);
	require(mcexec_errno_return_result(-1, EACCES) == -EACCES);
	require(mcexec_errno_return_result(17, EACCES) == 17);
	require(mcexec_path_copy_return_result(255, 255) == -ENAMETOOLONG);
	require(mcexec_path_copy_return_result(-EFAULT, 255) == -EFAULT);
	require(mcexec_path_copy_return_result(42, 255) == 42);
	require(mcexec_close_plan_result(8, 8) == -EBADF);
	require(mcexec_close_plan_result(9, 8) == 0);
	require(mcexec_setfsuid_needs_cred_result(1) == 1);
	require(mcexec_setfsuid_needs_cred_result(0) == 0);
	require(mcexec_sched_setaffinity_action_result(0) == 1);
	require(mcexec_sched_setaffinity_action_result(2) == -EINVAL);
	mcexec_exit_status_plan_result(231, 9, 231, 0, 1, &sig, &term,
				       &report_sig, &report_status);
	require(sig == 9);
	require(term == 0);
	require(report_sig == 1);
	require(report_status == 0);
	mcexec_exit_status_plan_result(231, 3 << 8, 231, 0, 1, &sig, &term,
				       &report_sig, &report_status);
	require(sig == 0);
	require(term == 3);
	require(report_sig == 0);
	require(report_status == 1);
	mcexec_exit_status_plan_result(60, 7 << 8, 231, 0, 1, &sig, &term,
				       &report_sig, &report_status);
	require(sig == 0 && term == 0);
	mix(&digest, (unsigned long)(report_sig + report_status + sig + term));

	memset(&sigwait, 0, sizeof(sigwait));
	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_isatty_result = 1;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	sigwait.sr.number = 231;
	sigwait.sr.args[0] = 9;
	act_exit(&sigwait, 7, 0);
	require(fake_mcexec_exit_debug_count == 1);
	require(fake_mcexec_exit_debug_status == 9);
	require(fake_mcexec_exit_debug_cpu == 7);
	require(fake_mcexec_exit_isatty_fd == 2);
	require(fake_mcexec_exit_report_signal_count == 1);
	require(fake_mcexec_exit_report_signal_sig == 9);
	require(fake_mcexec_exit_report_status_count == 0);
	require(fake_mcexec_exit_cmd_servers_count == 1);
	require(fake_mcexec_exit_replay_signal_count == 1);
	require(fake_mcexec_exit_replay_signal_sig == 9);
	require(fake_mcexec_exit_process_count == 1);
	require(fake_mcexec_exit_process_term == 0);

	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	sigwait.sr.number = 231;
	sigwait.sr.args[0] = 3 << 8;
	act_exit(&sigwait, 8, 0);
	require(fake_mcexec_exit_debug_count == 1);
	require(fake_mcexec_exit_debug_status == (3 << 8));
	require(fake_mcexec_exit_report_signal_count == 0);
	require(fake_mcexec_exit_report_status_count == 1);
	require(fake_mcexec_exit_report_status_term == 3);
	require(fake_mcexec_exit_cmd_servers_count == 1);
	require(fake_mcexec_exit_replay_signal_count == 0);
	require(fake_mcexec_exit_process_count == 1);
	require(fake_mcexec_exit_process_term == 3);

	fake_mcexec_exit_debug_count = 0;
	fake_mcexec_exit_report_signal_count = 0;
	fake_mcexec_exit_report_status_count = 0;
	fake_mcexec_exit_cmd_servers_count = 0;
	fake_mcexec_exit_replay_signal_count = 0;
	fake_mcexec_exit_process_count = 0;
	sigwait.sr.number = 60;
	sigwait.sr.args[0] = 7 << 8;
	act_exit(&sigwait, 9, 0);
	require(fake_mcexec_exit_debug_count == 1);
	require(fake_mcexec_exit_report_signal_count == 0);
	require(fake_mcexec_exit_report_status_count == 0);
	require(fake_mcexec_exit_replay_signal_count == 0);
	require(fake_mcexec_exit_process_count == 1);
	require(fake_mcexec_exit_process_term == 0);
	mix(&digest, (unsigned long)fake_mcexec_exit_process_term);
	mix(&digest, (unsigned long)fake_mcexec_exit_cmd_servers_count);

	{
		struct fake_program_desc *xfer_desc;

		unsetenv("COKERNEL_EXEC_ROOT");
		unsetenv("COKERNEL_PATH");
		fake_access_hit = interp_path_file;
		fake_access_hit_prefix = NULL;
		fake_load_desc_stat_result = 0;
		fake_load_elf_desc_result = 0;
		fake_lookup_lstat_result = 0;
		fake_ioctl_result = 0;
		fake_ioctl_errno = 0;
		fake_ioctl_transfer_to_result = 0;
		fake_ioctl_transfer_count = 0;
		fake_ioctl_ret_count = 0;
		fake_transfer_bytes_size = 0;
		fake_transfer_digest = 0;
		fake_execve1_load_desc_ok_count = 0;
		fake_execve1_load_desc_ok_sections = 0;
		fake_execve1_runtime_set_count = 0;
		fake_execve1_args_len_set_count = 0;
		fake_execve1_transfer_alloc_failed_count = 0;
		fake_execve1_transfer_failed_count = 0;
		fake_execve1_transfer_ok_count = 0;
		memset(fake_transfer_bytes, 0, sizeof(fake_transfer_bytes));
		memset(fake_execve1_load_desc_ok_path, 0,
		       sizeof(fake_execve1_load_desc_ok_path));
		memset(fake_execve1_transfer_failed_path, 0,
		       sizeof(fake_execve1_transfer_failed_path));
		memset(fake_execve1_transfer_ok_path, 0,
		       sizeof(fake_execve1_transfer_ok_path));
		memset(&sigwait, 0, sizeof(sigwait));
		memset(long_path, 0, sizeof(long_path));
		sigwait.sr.args[1] = AT_FDCWD;
		sigwait.sr.args[2] = (unsigned long)interp_path_file;
		sigwait.sr.args[3] = 0x12345000UL;
		sigwait.sr.args[4] = 0;
		act_execve_phase1(&sigwait, 17, 18, long_path);
		require(strcmp(long_path, interp_path_file) == 0);
		require(fake_execve1_load_desc_ok_count == 1);
		require(fake_execve1_load_desc_ok_sections == 1);
		require(strcmp(fake_execve1_load_desc_ok_path,
			       interp_path_file) == 0);
		require(fake_execve1_runtime_set_count == 1);
		require(fake_execve1_args_len_set_count == 0);
		require(fake_execve1_transfer_alloc_failed_count == 0);
		require(fake_execve1_transfer_failed_count == 0);
		require(fake_execve1_transfer_ok_count == 1);
		require(strcmp(fake_execve1_transfer_ok_path,
			       interp_path_file) == 0);
		require(fake_ioctl_transfer_count == 1);
		require(fake_transfer_desc.rphys == 0x12345000UL);
		require(fake_transfer_desc.direction == MCEXEC_UP_TRANSFER_TO_REMOTE);
		require(fake_transfer_bytes_size >=
			offsetof(struct fake_program_desc, sections) +
			sizeof(struct fake_program_section));
		xfer_desc = (struct fake_program_desc *)fake_transfer_bytes;
		require(xfer_desc->num_sections == 1);
		require(xfer_desc->enable_vdso == fake_execve1_enable_vdso);
		require(xfer_desc->rlimit_cur == fake_execve1_rlim_cur);
		require(xfer_desc->rlimit_max == fake_execve1_rlim_max);
		require(xfer_desc->stack_premap == fake_execve1_stack_premap);
		require(fake_ret_desc.cpu == 18);
		require(fake_ret_desc.ret == 0);

		fake_ioctl_transfer_to_result = -1;
		fake_ioctl_errno = EIO;
		fake_ioctl_result = 0;
		fake_ioctl_transfer_count = 0;
		fake_execve1_load_desc_ok_count = 0;
		fake_execve1_runtime_set_count = 0;
		fake_execve1_transfer_failed_count = 0;
		fake_execve1_transfer_ok_count = 0;
		memset(fake_execve1_transfer_failed_path, 0,
		       sizeof(fake_execve1_transfer_failed_path));
		memset(&sigwait, 0, sizeof(sigwait));
		memset(long_path, 0, sizeof(long_path));
		sigwait.sr.args[1] = AT_FDCWD;
		sigwait.sr.args[2] = (unsigned long)interp_path_file;
		sigwait.sr.args[3] = 0x12346000UL;
		sigwait.sr.args[4] = 0;
		act_execve_phase1(&sigwait, 17, 19, long_path);
		require(fake_execve1_load_desc_ok_count == 1);
		require(fake_execve1_runtime_set_count == 1);
		require(fake_ioctl_transfer_count == 1);
		require(fake_execve1_transfer_failed_count == 1);
		require(fake_execve1_transfer_ok_count == 0);
		require(strcmp(fake_execve1_transfer_failed_path,
			       interp_path_file) == 0);
		require(fake_ret_desc.cpu == 19);
		require(fake_ret_desc.ret == -EIO);
		fake_ioctl_transfer_to_result = 0;
		fake_ioctl_errno = 0;
		mix(&digest, fake_transfer_desc.rphys);
		mix(&digest, (unsigned long)fake_execve1_transfer_failed_count);
	}

	{
		struct fake_program_desc execve2_desc;

		memset(&execve2_desc, 0, sizeof(execve2_desc));
		memset(&sigwait, 0, sizeof(sigwait));
		memcpy(fake_ioctl_from_remote_bytes, &execve2_desc,
		       sizeof(execve2_desc));
		fake_ioctl_from_remote_size = sizeof(execve2_desc);
		fake_ioctl_transfer_from_result = 0;
		fake_ioctl_close_exec_result = 0;
		fake_ioctl_close_exec_count = 0;
		fake_execve2_transfer_desc_ok_count = 0;
		fake_execve2_image_transferred_count = 0;
		fake_execve2_transfer_desc_failed_count = 0;
		fake_execve2_transfer_image_failed_count = 0;
		fake_execve2_close_exec_failed_count = 0;
		fake_sysconf_result = 4;
		fake_fcntl_count = 0;
		fake_close_count = 0;
		memset(fake_fd_flags, 0, sizeof(fake_fd_flags));
		memset(fake_fcntl_seen, 0, sizeof(fake_fcntl_seen));
		memset(fake_closed_fds, -1, sizeof(fake_closed_fds));
		sigwait.sr.args[1] = 0xfeed0000UL;
		sigwait.sr.args[2] = sizeof(execve2_desc);
		require(act_execve_phase2(&sigwait, 2, 12) == 0);
		require(fake_transfer_desc.rphys == 0xfeed0000UL);
		require(fake_transfer_desc.size == sizeof(execve2_desc));
		require(fake_transfer_desc.direction ==
			MCEXEC_UP_TRANSFER_FROM_REMOTE);
		require(fake_execve2_transfer_desc_ok_count == 1);
		require(fake_execve2_image_transferred_count == 1);
		require(fake_execve2_transfer_desc_failed_count == 0);
		require(fake_execve2_transfer_image_failed_count == 0);
		require(fake_ioctl_close_exec_count == 1);
		require(fake_fcntl_count == 3);
		require(fake_fcntl_seen[2] == 0);
		require(fake_ret_desc.cpu == 12);
		require(fake_ret_desc.ret == 0);

		fake_ioctl_transfer_from_result = -1;
		fake_execve2_transfer_desc_failed_count = 0;
		fake_execve2_transfer_desc_ok_count = 0;
		fake_execve2_image_transferred_count = 0;
		fake_ioctl_close_exec_count = 0;
		memset(&sigwait, 0, sizeof(sigwait));
		sigwait.sr.args[1] = 0xbeef0000UL;
		sigwait.sr.args[2] = sizeof(execve2_desc);
		require(act_execve_phase2(&sigwait, 2, 13) == 0);
		require(fake_execve2_transfer_desc_failed_count == 1);
		require(fake_execve2_transfer_desc_ok_count == 0);
		require(fake_execve2_image_transferred_count == 0);
		require(fake_ioctl_close_exec_count == 0);
		require(fake_ret_desc.cpu == 13);
		require(fake_ret_desc.ret == EINVAL);
		fake_ioctl_transfer_from_result = 0;

		transfer_fp = tmpfile();
		require(transfer_fp != NULL);
		require(fflush(transfer_fp) == 0);
		memset(&execve2_desc, 0, sizeof(execve2_desc));
		execve2_desc.num_sections = 1;
		execve2_desc.sections[0].vaddr = 0x2000;
		execve2_desc.sections[0].len = 16;
		execve2_desc.sections[0].remote_pa = 0xa000;
		execve2_desc.sections[0].filesz = 16;
		execve2_desc.sections[0].offset = 0;
		execve2_desc.sections[0].fp = transfer_fp;
		memcpy(fake_ioctl_from_remote_bytes, &execve2_desc,
		       sizeof(execve2_desc));
		fake_ioctl_from_remote_size = sizeof(execve2_desc);
		page_size = 16;
		page_mask = ~(page_size - 1);
		dma_buf = dma_area;
		fake_ioctl_result = 0;
		fake_execve2_transfer_image_failed_count = 0;
		fake_execve2_image_transferred_count = 0;
		fake_ioctl_close_exec_count = 0;
		memset(&sigwait, 0, sizeof(sigwait));
		sigwait.sr.args[1] = 0xcafe0000UL;
		sigwait.sr.args[2] = sizeof(execve2_desc);
		require(act_execve_phase2(&sigwait, 2, 14) == -1);
		require(fake_execve2_transfer_image_failed_count == 1);
		require(fake_execve2_image_transferred_count == 0);
		require(fake_ioctl_close_exec_count == 0);
		require(fclose(transfer_fp) == 0);
		fake_ioctl_result = 0;

		memset(&execve2_desc, 0, sizeof(execve2_desc));
		memcpy(fake_ioctl_from_remote_bytes, &execve2_desc,
		       sizeof(execve2_desc));
		fake_ioctl_from_remote_size = sizeof(execve2_desc);
		fake_ioctl_close_exec_result = -7;
		fake_execve2_close_exec_failed_count = 0;
		fake_execve2_close_exec_failed_ret = 0;
		fake_ioctl_close_exec_count = 0;
		memset(&sigwait, 0, sizeof(sigwait));
		sigwait.sr.args[1] = 0xabcd0000UL;
		sigwait.sr.args[2] = sizeof(execve2_desc);
		require(act_execve_phase2(&sigwait, 2, 15) == 1);
		require(fake_ioctl_close_exec_count == 1);
		require(fake_execve2_close_exec_failed_count == 1);
		require(fake_execve2_close_exec_failed_ret == -7);
		fake_ioctl_close_exec_result = 0;
		mix(&digest, (unsigned long)fake_execve2_close_exec_failed_ret);
	}

	{
		struct fake_program_desc execve_desc;

		unsetenv("COKERNEL_EXEC_ROOT");
		unsetenv("COKERNEL_PATH");
		fake_access_hit = interp_path_file;
		fake_access_hit_prefix = NULL;
		fake_load_desc_stat_result = 0;
		fake_load_elf_desc_result = 0;
		fake_lookup_lstat_result = 0;
		fake_ioctl_result = 0;
		fake_ioctl_errno = 0;
		fake_ioctl_transfer_to_result = 0;
		fake_ioctl_transfer_from_result = 0;
		fake_ioctl_close_exec_result = 0;
		fake_ioctl_transfer_count = 0;
		fake_ioctl_ret_count = 0;
		fake_execve1_load_desc_ok_count = 0;
		fake_execve1_runtime_set_count = 0;
		fake_execve1_transfer_ok_count = 0;
		memset(fake_execve1_load_desc_ok_path, 0,
		       sizeof(fake_execve1_load_desc_ok_path));
		memset(fake_execve1_transfer_ok_path, 0,
		       sizeof(fake_execve1_transfer_ok_path));
		memset(&sigwait, 0, sizeof(sigwait));
		memset(long_path, 0, sizeof(long_path));
		sigwait.sr.args[0] = 1;
		sigwait.sr.args[1] = AT_FDCWD;
		sigwait.sr.args[2] = (unsigned long)interp_path_file;
		sigwait.sr.args[3] = 0x12000000UL;
		sigwait.sr.args[4] = 0;
		lrc = 12345;
		require(act_execve(&sigwait, 17, 31, long_path, &lrc) == 0);
		require(lrc == 12345);
		require(fake_execve1_load_desc_ok_count == 1);
		require(fake_execve1_runtime_set_count == 1);
		require(fake_execve1_transfer_ok_count == 1);
		require(fake_ret_desc.cpu == 31);
		require(fake_ret_desc.ret == 0);

		memset(&execve_desc, 0, sizeof(execve_desc));
		memcpy(fake_ioctl_from_remote_bytes, &execve_desc,
		       sizeof(execve_desc));
		fake_ioctl_from_remote_size = sizeof(execve_desc);
		fake_ioctl_transfer_from_result = 0;
		fake_ioctl_close_exec_result = -9;
		fake_execve2_close_exec_failed_count = 0;
		fake_execve2_close_exec_failed_ret = 0;
		fake_ioctl_close_exec_count = 0;
		memset(&sigwait, 0, sizeof(sigwait));
		sigwait.sr.args[0] = 2;
		sigwait.sr.args[1] = 0x12100000UL;
		sigwait.sr.args[2] = sizeof(execve_desc);
		lrc = 0;
		require(act_execve(&sigwait, 17, 32, long_path, &lrc) == 1);
		require(lrc == 1);
		require(fake_ioctl_close_exec_count == 1);
		require(fake_execve2_close_exec_failed_count == 1);
		require(fake_execve2_close_exec_failed_ret == -9);
		fake_ioctl_close_exec_result = 0;

		fake_execve_invalid_phase_count = 0;
		fake_ioctl_ret_count = 0;
		memset(&sigwait, 0, sizeof(sigwait));
		sigwait.sr.args[0] = 99;
		lrc = 54321;
		require(act_execve(&sigwait, 17, 33, long_path, &lrc) == 0);
		require(lrc == 54321);
		require(fake_execve_invalid_phase_count == 1);
		require(fake_ioctl_ret_count == 0);
		mix(&digest, (unsigned long)fake_execve_invalid_phase_count);
		mix(&digest, (unsigned long)fake_execve2_close_exec_failed_ret);
	}

	memset(tids, 0x5a, sizeof(tids));
	require(mcexec_collect_active_tids_result(&th1, tids, 5) == 0);
	require(tids[0] == 11);
	require(tids[1] == 44);
	require(tids[2] == 0);
	require(tids[3] == 0);
	require(tids[4] == 0);
	mix(&digest, (unsigned long)(tids[0] + tids[1]));

	fs_out = NULL;
	node_out = NULL;
	require(mcexec_fork_sync_complete_result(&fork_top, 202, &fs_out,
						 &node_out) == 1);
	require(fs_out == &fs2);
	require(node_out == &f2);
	require(fs2.success == 1);
	require(fork_top == &f1);
	require(f1.next == &f3);
	require(mcexec_fork_sync_complete_result(&fork_top, 404, &fs_out,
						 &node_out) == 0);
	require(mcexec_fork_sync_remove_node_result(&fork_top, &f3) == 1);
	require(f1.next == NULL);
	mix(&digest, (unsigned long)(fs2.success + f1.pid));

	{
		struct fake_fork_sync cfs1 = { 0 };
		struct fake_fork_sync cfs2 = { 0 };
		struct fake_fork_sync cfs3 = { 0 };
		struct fake_fork_sync_container cf3 = {
			.pid = 303, .fs = &cfs3
		};
		struct fake_fork_sync_container cf2 = {
			.pid = 202, .next = &cf3, .fs = &cfs2
		};
		struct fake_fork_sync_container cf1 = {
			.pid = 101, .next = &cf2, .fs = &cfs1
		};

		memset(&sigwait, 0, sizeof(sigwait));
		fork_sync_top = &cf1;
		fake_fork_sync_lock_count = 0;
		fake_fork_sync_unlock_count = 0;
		fake_fork_sync_munmap_count = 0;
		fake_fork_sync_free_count = 0;
		sigwait.sr.args[1] = 202;
		act_clone_complete(&sigwait, 55, 9);
		require(fake_fork_sync_lock_count == 1);
		require(fake_fork_sync_unlock_count == 1);
		require(cfs2.success == 1);
		require(fork_sync_top == &cf1);
		require(cf1.next == &cf3);
		require(fake_fork_sync_munmap_count == 1);
		require(fake_fork_sync_munmap_ptr == &cfs2);
		require(fake_fork_sync_free_count == 1);
		require(fake_fork_sync_free_ptr == &cf2);
		require(fake_ret_desc.cpu == 9);
		require(fake_ret_desc.ret == 0);

		fake_fork_sync_lock_count = 0;
		fake_fork_sync_unlock_count = 0;
		fake_fork_sync_munmap_count = 0;
		fake_fork_sync_free_count = 0;
		sigwait.sr.args[1] = 404;
		act_clone_complete(&sigwait, 55, 9);
		require(fake_fork_sync_lock_count == 1);
		require(fake_fork_sync_unlock_count == 1);
		require(fake_fork_sync_munmap_count == 0);
		require(fake_fork_sync_free_count == 0);
			require(fake_ret_desc.ret == 0);
			mix(&digest, (unsigned long)cfs2.success);
			mix(&digest, (unsigned long)fake_fork_sync_free_count);
		}

		{
			struct fake_fork_sync existing_fs = { 0 };
			struct fake_fork_sync start_fs = { 0 };
			struct fake_fork_sync_container existing = {
				.pid = 77, .fs = &existing_fs
			};
			struct fake_fork_sync_container start_node = { 0 };

			memset(&sigwait, 0, sizeof(sigwait));
			fork_sync_top = &existing;
			reset_clone_start_fakes(&start_fs, &start_node, 333);
			fake_clone_sem_trywait_len = 2;
			fake_clone_sem_trywait_result[0] = -1;
			fake_clone_sem_trywait_errno[0] = EAGAIN;
			fake_clone_sem_trywait_result[1] = 0;
			lrc = -999;
			require(act_clone_start(&sigwait, 55, 21, &lrc) == 0);
			require(lrc == -999);
			require(fake_clone_alloc_fs_count == 1);
			require(fake_clone_alloc_container_count == 1);
			require(fake_clone_fork_count == 1);
			require(fake_clone_sem_trywait_count == 2);
			require(fake_clone_waitpid_count == 1);
			require(fake_clone_waitpid_pid == 333);
			require(fake_clone_sched_yield_count == 1);
			require(fake_clone_sem_destroy_count == 1);
			require(fake_clone_sem_destroy_ptr == &start_fs);
			require(fake_fork_sync_munmap_count == 0);
			require(fake_fork_sync_free_count == 0);
			require(fork_sync_top == &start_node);
			require(start_node.next == &existing);
			require(start_node.fs == &start_fs);
			require(start_node.pid == 333);
			require(fake_ret_desc.cpu == 21);
			require(fake_ret_desc.ret == 333);

			fork_sync_top = &existing;
			reset_clone_start_fakes(&start_fs, &start_node, -1);
			fake_clone_fork_errno = EIO;
			lrc = -999;
			require(act_clone_start(&sigwait, 55, 22, &lrc) == 0);
			require(lrc == -999);
			require(fake_clone_fork_failed_count == 1);
			require(fake_clone_sem_destroy_count == 1);
			require(fake_fork_sync_munmap_count == 1);
			require(fake_fork_sync_munmap_ptr == &start_fs);
			require(fake_fork_sync_free_count == 1);
			require(fake_fork_sync_free_ptr == &start_node);
			require(fork_sync_top == &existing);
			require(fake_ret_desc.cpu == 22);
			require(fake_ret_desc.ret == -EIO);

			fork_sync_top = &existing;
			reset_clone_start_fakes(&start_fs, &start_node, 444);
			fake_clone_sem_trywait_len = 1;
			fake_clone_sem_trywait_result[0] = -1;
			fake_clone_sem_trywait_errno[0] = EAGAIN;
			fake_clone_waitpid_result = 444;
			lrc = -999;
			require(act_clone_start(&sigwait, 55, 23, &lrc) == 0);
			require(lrc == -999);
			require(start_fs.status == -ENOMEM);
			require(fake_clone_child_failed_count == 1);
			require(fake_clone_sem_destroy_count == 1);
			require(fake_fork_sync_munmap_count == 1);
			require(fake_fork_sync_free_count == 1);
			require(fork_sync_top == &existing);
			require(fake_ret_desc.cpu == 23);
			require(fake_ret_desc.ret == -ENOMEM);

			fork_sync_top = &existing;
			reset_clone_start_fakes(&start_fs, &start_node, 0);
			fake_clone_child_ret = 77;
			lrc = -999;
			require(act_clone_start(&sigwait, 55, 24, &lrc) == 1);
			require(lrc == 77);
			require(fake_clone_child_count == 1);
			require(fake_clone_child_w == &sigwait);
			require(fake_clone_child_fs == &start_fs);
			require(fake_clone_sem_destroy_count == 0);
			require(fake_ioctl_ret_count == 0);
			require(fork_sync_top == NULL);
			mix(&digest, (unsigned long)start_node.pid);
			mix(&digest, (unsigned long)fake_clone_child_count);
		}

		memset(dirents, 0, sizeof(dirents));
	d0 = put_dirent64(dirents, "alpha", 32);
	d1 = put_dirent64(dirents + d0, "beta", 32);
	require(mcexec_dirent_rewrite_offsets_result(dirents, 0, d0 + d1,
						     100, 1) == 0);
	require(*(unsigned long *)(dirents + 8) == 100 + d0);
	require(*(unsigned long *)(dirents + d0 + 8) == 100 + d0 + d1);
	require(mcexec_dirent_buffer_contains_name_result(dirents, d0,
							  dirents + d0, 1)
		== 0);
	require(mcexec_dirent_buffer_contains_name_result(dirents, d0 + d1,
							  dirents + d0, 1)
		== 1);
	memset(out, 0, sizeof(out));
	dirent_count = 40;
	rc = mcexec_copy_dirents_result(out, dirents, d0 + d1, 0,
					&dirent_count, 1);
	require(rc == (int)d0);
	require(dirent_count == 0);
	require(!strcmp(((struct fake_dirent64 *)out)->d_name, "alpha"));
	dirent_count = 64;
	rc = mcexec_copy_dirents_result(out, dirents, d0 + d1, d0,
					&dirent_count, 1);
	require(rc == (int)d1);
	require(dirent_count == 64 - d1);
	require(!strcmp(((struct fake_dirent64 *)out)->d_name, "beta"));
	memset(out, 0, sizeof(out));
	dirent_count = 64;
	rc = copy_dirents(out, dirents, d0 + d1, d0, &dirent_count, 217);
	require(rc == (int)d1);
	require(dirent_count == 64 - d1);
	require(!strcmp(((struct fake_dirent64 *)out)->d_name, "beta"));
	mix(&digest, *(unsigned long *)(dirents + d0 + 8));

	printf("mcexec_helpers ok digest=%016lx\n", digest);
	return 0;
}
