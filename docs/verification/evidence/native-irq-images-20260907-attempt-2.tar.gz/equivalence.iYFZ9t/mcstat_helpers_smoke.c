#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern unsigned long mcstat_memory_scale_result(unsigned long max_usage);
extern const char *mcstat_memory_unit_result(unsigned long max_usage);
extern unsigned char mcstat_update_counter_result(unsigned char counter);
extern int mcstat_parse_i32_result(const char *arg);
extern int mcstat_mcos_path_result(char *path, int index);
extern unsigned long mcstat_memory_total_result(const unsigned long *values,
		int count);
extern unsigned long mcstat_memory_current_result(unsigned long kmem_usage,
		const unsigned long *numa_values, int count);
extern unsigned long mcstat_memory_max_result(unsigned long kmem_max_usage,
		unsigned long user_max_usage);
extern const char *mcstat_monstatus_result(int status);
extern const char *mcstat_os_status_result(int status);
extern int mcstat_statistics_header_result(char *buf, size_t buf_size,
		const char *unit);
extern int mcstat_status_line_result(char *buf, size_t buf_size,
		const char *status);
extern int mcstat_osusage_header_result(char *buf, size_t buf_size);
extern int mcstat_cpu_usage_line_result(char *buf, size_t buf_size, int cpu,
		const char *status, long counter);
extern int mcstat_cpuacct_line_result(char *buf, size_t buf_size, int cpu,
		long usage);
extern int mcstat_usage_line_result(char *buf, size_t buf_size);
extern int mcstat_main_plan_result(int sflag, int cflag, int optind,
		int argc, const char *delay_arg, const char *count_arg,
		int *delay, int *count);
extern int mcstat_loop_control_result(int once, int *count,
		unsigned char *show);

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	unsigned long values[] = { 7, 11, 13 };
	unsigned long digest = 0x6d6373746174UL;
	char buf[192];
	int delay;
	int count;
	unsigned char show;
	int rc;

	require(mcstat_memory_scale_result(99UL * 1024 * 1024) == 1024UL * 1024);
	require(mcstat_memory_scale_result(100UL * 1024 * 1024) == 1024UL * 1024 * 1024);
	require(!strcmp(mcstat_memory_unit_result(99UL * 1024 * 1024), "MB"));
	require(!strcmp(mcstat_memory_unit_result(100UL * 1024 * 1024), "GB"));
	require(mcstat_update_counter_result(9) == 0);
	require(mcstat_update_counter_result(4) == 5);
	require(mcstat_parse_i32_result(" -42x") == -42);
	require(mcstat_memory_total_result(values, 3) == 31);
	require(mcstat_memory_current_result(5, values, 3) == 36);
	require(mcstat_memory_max_result(17, 19) == 36);
	require(!strcmp(mcstat_monstatus_result(3), "kernel mode"));
	require(!strcmp(mcstat_monstatus_result(99), "panic"));
	require(!strcmp(mcstat_monstatus_result(123), ""));
	require(!strcmp(mcstat_os_status_result(5), "Running"));
	require(mcstat_os_status_result(123) == NULL);
	mix(&digest, mcstat_memory_current_result(5, values, 3));

	memset(buf, 0, sizeof(buf));
	require(mcstat_mcos_path_result(buf, 7) > 0);
	require(!strcmp(buf, "/dev/mcos7"));

	memset(buf, 0, sizeof(buf));
	rc = mcstat_statistics_header_result(buf, sizeof(buf), "MB");
	require(rc == (int)strlen(buf));
	require(!strcmp(buf,
		"------- memory (MB) ------- ------- tsc ------ --- thread ---\n"
		"    total  current      max    system     user current max\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcstat_status_line_result(buf, sizeof(buf), "Ready");
	require(rc == (int)strlen("McKernel status: Ready\n"));
	require(!strcmp(buf, "McKernel status: Ready\n"));

	memset(buf, 0, sizeof(buf));
	rc = mcstat_osusage_header_result(buf, sizeof(buf));
	require(rc == (int)strlen("--cpu-- --status-- --count--\n"));
	require(!strcmp(buf, "--cpu-- --status-- --count--\n"));

	memset(buf, 0, sizeof(buf));
	rc = mcstat_cpu_usage_line_result(buf, sizeof(buf), 12,
			"user mode", 345);
	require(rc == (int)strlen("    12:  user mode       345\n"));
	require(!strcmp(buf, "    12:  user mode       345\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcstat_cpuacct_line_result(buf, sizeof(buf), 2, 987654);
	require(rc == (int)strlen("cpuacct_usage_percpu[2] = 987654\n"));
	require(!strcmp(buf, "cpuacct_usage_percpu[2] = 987654\n"));
	require(mcstat_cpuacct_line_result(buf, 8, 2, 987654) < 0);
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcstat_usage_line_result(buf, sizeof(buf));
	require(rc == (int)strlen("Usage: mcstat [-h|-n|-s] [delay [count]]\n"));
	require(!strcmp(buf, "Usage: mcstat [-h|-n|-s] [delay [count]]\n"));
	require(mcstat_usage_line_result(buf, 8) < 0);
	mix(&digest, (unsigned long)rc);

	delay = -99;
	count = -99;
	rc = mcstat_main_plan_result(0, 0, 1, 3, "5", "7",
			&delay, &count);
	require(rc == 0);
	require(delay == 5);
	require(count == 7);
	mix(&digest, (unsigned long)(delay + count));

	delay = -99;
	count = -99;
	rc = mcstat_main_plan_result(0, 1, 1, 2, "-2", NULL,
			&delay, &count);
	require(rc == 1);
	require(delay == -2);
	require(count == -1);

	delay = -99;
	count = -99;
	rc = mcstat_main_plan_result(1, 1, 1, 1, NULL, NULL,
			&delay, &count);
	require(rc == 2);
	require(delay == 0);
	require(count == 1);
	count = 2;
	show = 9;
	rc = mcstat_loop_control_result(0, &count, &show);
	require(rc == 2);
	require(count == 1);
	require(show == 0);
	rc = mcstat_loop_control_result(0, &count, &show);
	require(rc == 1);
	require(count == 0);
	require(show == 0);
	count = -1;
	show = 4;
	rc = mcstat_loop_control_result(1, &count, &show);
	require(rc == 0);
	require(count == -1);
	require(show == 4);
	require(mcstat_loop_control_result(0, NULL, &show) == 1);

	printf("mcstat_helpers ok digest=%016lx\n", digest);
	return 0;
}
