#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

enum {
	ECLAIR_CMD_QSUPPORTED = 1,
	ECLAIR_CMD_HG = 2,
	ECLAIR_CMD_HC = 3,
	ECLAIR_CMD_VCTRLC = 4,
	ECLAIR_CMD_CTRLC = 5,
	ECLAIR_CMD_VCONT_QUERY = 6,
	ECLAIR_CMD_CONTINUE = 7,
	ECLAIR_CMD_STOP_QUERY = 8,
	ECLAIR_CMD_QC = 9,
	ECLAIR_CMD_QATTACHED = 10,
	ECLAIR_CMD_TARGET_XML = 11,
	ECLAIR_CMD_DETACH = 12,
	ECLAIR_CMD_REGS = 13,
	ECLAIR_CMD_MEMORY = 14,
	ECLAIR_CMD_QTSTATUS = 15,
	ECLAIR_CMD_MEMORY_MAP = 16,
	ECLAIR_CMD_THREAD_ALIVE = 17,
	ECLAIR_CMD_QFTHREADINFO = 18,
	ECLAIR_CMD_QSTHREADINFO = 19,
	ECLAIR_CMD_QTHREAD_EXTRA_INFO = 20,
};
enum {
	ECLAIR_PACKET_STEP_NONE = 0,
	ECLAIR_PACKET_STEP_INTERRUPT = 1,
	ECLAIR_PACKET_STEP_READY = 2,
	ECLAIR_PACKET_STEP_BAD = 3,
	ECLAIR_PACKET_STEP_ERROR = 4,
};
enum {
	ECLAIR_REMOTE_ACTION_NONE = 0,
	ECLAIR_REMOTE_ACTION_NMI = 1,
	ECLAIR_REMOTE_ACTION_CONTINUE = 2,
};
enum {
	ECLAIR_PURE_COMMAND_NOT_HANDLED = -1,
	ECLAIR_PURE_COMMAND_PARSE_ERROR = -2,
	ECLAIR_PURE_COMMAND_INVALID_TID = -3,
	ECLAIR_PURE_COMMAND_BUFFER_ERROR = -4,
};

extern int eclair_parse_i32_result(const char *arg);
extern int eclair_physmem_name_result(char *path, int index);
extern int eclair_mcos_path_result(char *path, int index);
extern ssize_t eclair_print_hex_result(char *buf, size_t buf_size,
				       const char *str);
extern ssize_t eclair_print_bin_result(char *buf, size_t buf_size,
				       const void *data, size_t size);
extern ssize_t eclair_simple_response_result(char *buf, size_t buf_size,
					     int cmd_kind, int interactive,
					     int remote_running);
extern ssize_t eclair_gdb_target_result(char *buf, size_t buf_size,
					unsigned int port);
extern ssize_t eclair_packet_frame_result(char *buf, size_t buf_size,
					  const char *payload);
extern ssize_t eclair_banner_result(char *buf, size_t buf_size,
				    int interactive, const char *dump_path);
extern ssize_t eclair_usage_result(char *buf, size_t buf_size);
extern ssize_t eclair_open_mcos_error_result(char *buf, size_t buf_size,
					     const char *file, int line,
					     int os_id, int errno_value);
extern ssize_t eclair_read_physmem_invalid_result(char *buf, size_t buf_size,
						  uintptr_t pa);
extern ssize_t eclair_lookup_failed_result(char *buf, size_t buf_size,
					   const char *func, const char *name);
extern ssize_t eclair_thread_extra_info_result(char *buf, size_t buf_size,
					       int pid, int status, int idle,
					       int lcpu, int cpu);
extern int eclair_gdb_command_kind_result(const char *cmd, int interactive);
extern int eclair_parse_hex_i32_result(const char *arg, int *out);
extern int eclair_parse_memory_request_result(const char *cmd,
					      uintptr_t *start, size_t *size);
extern unsigned char eclair_response_checksum_result(const char *payload);
extern int eclair_parse_packet_checksum_result(const char *hex, uint8_t *out);
extern ssize_t eclair_interrupt_command_result(char *buf, size_t buf_size);
extern int eclair_packet_step_result(int input, int interactive,
				     int *mode, uint8_t *sum, uint8_t *check,
				     char *lbuf, size_t lbuf_size,
				     size_t *lpos, char *cbuf,
				     size_t cbuf_size);
extern int eclair_remote_command_plan_result(int cmd_kind, int interactive,
					     int remote_running, int *action,
					     int *next_remote_running,
					     int *set_done);
extern ssize_t eclair_static_response_result(char *buf, size_t buf_size,
					     int cmd_kind, int current_tid,
					     uintptr_t map_kernel_start,
					     const char *arch);
extern ssize_t eclair_thread_list_entry_result(char *buf, size_t buf_size,
					       int first, int tid);
struct eclair_thread_info;
extern struct eclair_thread_info *eclair_thread_lookup_result(
		struct eclair_thread_info *head, int tid);
extern ssize_t eclair_thread_list_result(char *buf, size_t buf_size,
		struct eclair_thread_info *head);
extern ssize_t eclair_thread_extra_info_hex_result(char *buf, size_t buf_size,
		struct eclair_thread_info *head, int tid);
extern ssize_t eclair_pure_command_response_result(const char *cmd,
		int cmd_kind, char *buf, size_t buf_size,
		struct eclair_thread_info *head,
		struct eclair_thread_info **current_thread,
		int interactive, int remote_running,
		uintptr_t map_kernel_start, const char *arch,
		int *error_tid, int *error_kind);
extern int apply_remote_action(int action, const char *continue_error);
extern int eclair_dprintf(const char *fmt, ...);
extern uintptr_t lookup_symbol(char *name);
extern int read_mem(uintptr_t va, void *buf, size_t size);
extern int read_64(uintptr_t va, void *buf);
extern int read_32(uintptr_t va, void *buf);
extern int read_symbol_64(char *name, void *buf);
extern ssize_t print_bin(char *buf, size_t buf_size, void *data, size_t size);
extern int setup_symbols(char *fname);
extern int setup_dump_interactive(void);
extern int setup_dump(char *fname);
extern int setup_constants(void);
extern void intr_handler(int dummy);
extern void print_usage(void);
extern void options(int argc, char **argv);

#define PS_RUNNING 0x01
#define PS_INTERRUPTIBLE 0x02
#define PS_STOPPED 0x20
#define CS_RESERVED 0x030000

struct eclair_thread_info {
	struct eclair_thread_info *next;
	int status;
	int pid;
	int tid;
	int cpu;
	int lcpu;
	int idle;
	uintptr_t process;
	uintptr_t clv;
	uintptr_t arch_clv;
};

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

struct eclair_bfd_section {
	const char *name;
	unsigned int id;
	unsigned int index;
	struct eclair_bfd_section *next;
	struct eclair_bfd_section *prev;
	unsigned int flags;
	uintptr_t vma;
};
struct eclair_bfd_symbol {
	void *the_bfd;
	const char *name;
	uintptr_t value;
	unsigned int flags;
	struct eclair_bfd_section *section;
};
struct eclair_options {
	uint8_t cpu;
	uint8_t help;
	char *kernel_path;
	char *dump_path;
	char *log_path;
	int interactive;
	int os_id;
	int mcos_fd;
	int print_idle;
};
struct eclair_dump_mem_chunk {
	unsigned long addr;
	unsigned long size;
};
struct eclair_dump_mem_chunks {
	int nr_chunks;
	unsigned long kernel_base;
	unsigned long phys_start;
	struct eclair_dump_mem_chunk chunks[2];
};
struct eclair_dumpargs {
	int cmd;
	unsigned int level;
	long start;
	long size;
	void *buf;
	void *spare[4];
};
static uintptr_t virt_to_phys_va;
static uintptr_t bfd_last_offset;
static size_t bfd_last_size;
static char bfd_last_name[32];
static char bfd_section_names[8][32];
static int bfd_section_count;
static char eclair_bfd_fopen_name[64];
static int ioctl_fd;
static unsigned long ioctl_request;
static int ioctl_cmd;
static long ioctl_start;
static long ioctl_size;
static int ioctl_count;
static int ioctl_cmds[8];
static unsigned int ioctl_levels[8];
static int kill_pid;
static int kill_sig;
static int arch_setup_constants_calls;
static int arch_setup_constants_fd;
static char eclair_bfd_openr_name[64];
extern int gdbpid;
extern unsigned long PHYS_OFFSET;
extern unsigned long MAP_KERNEL_START;
extern unsigned long kernel_base;
extern uintptr_t debug_constants[12];
extern int remote_running;
extern struct eclair_options opt;
static struct eclair_dump_mem_chunks eclair_mem_chunks = {
	.nr_chunks = 2,
	.kernel_base = 0xfeed0000UL,
	.phys_start = 0x100000UL,
	.chunks = {
		{ .addr = 0x2000, .size = 0x1000 },
		{ .addr = 0x5000, .size = 0x2000 },
	},
};
extern struct eclair_dump_mem_chunks *mem_chunks;
extern void *dumpbfd;
static void *eclair_dump_bfd = (void *)0xfeedfaceUL;
static void *eclair_physchunks_section = (void *)0x1235UL;
static void *eclair_physmem_section = (void *)0x1234UL;
static struct eclair_bfd_section eclair_symbol_sections[] = {
	{ .vma = 0x900 },
	{ .vma = 0x1900 },
};
static struct eclair_bfd_symbol eclair_symbols[] = {
	{ .name = "alpha", .value = 0x700,
	  .section = &eclair_symbol_sections[0] },
	{ .name = "beta", .value = 0x700,
	  .section = &eclair_symbol_sections[1] },
	{ .name = "debug_constants", .value = 0x700,
	  .section = &eclair_symbol_sections[0] },
};
static struct eclair_bfd_symbol *eclair_symtab_storage[] = {
	&eclair_symbols[0],
	&eclair_symbols[1],
	&eclair_symbols[2],
};
extern struct eclair_bfd_symbol **symtab;
extern ssize_t nsyms;
extern void *symbfd;

void *bfd_openr(const char *name, const char *target)
{
	(void)target;
	strncpy(eclair_bfd_openr_name, name,
			sizeof(eclair_bfd_openr_name) - 1);
	eclair_bfd_openr_name[sizeof(eclair_bfd_openr_name) - 1] = '\0';
	return (void *)0xdecafbadUL;
}

int bfd_check_format(void *abfd, int format)
{
	return (abfd == (void *)0xdecafbadUL || abfd == eclair_dump_bfd) &&
		format == 1;
}

void *bfd_fopen(const char *name, const char *target, const char *mode,
		int fd)
{
	(void)target;
	(void)mode;
	(void)fd;
	strncpy(eclair_bfd_fopen_name, name,
			sizeof(eclair_bfd_fopen_name) - 1);
	eclair_bfd_fopen_name[sizeof(eclair_bfd_fopen_name) - 1] = '\0';
	return eclair_dump_bfd;
}

int arch_setup_constants(int fd)
{
	arch_setup_constants_calls++;
	arch_setup_constants_fd = fd;
	return 0;
}

long eclair_bfd_get_symtab_upper_bound_bridge(void *abfd)
{
	require(abfd == (void *)0xdecafbadUL);
	return sizeof(eclair_symtab_storage);
}

long eclair_bfd_canonicalize_symtab_bridge(void *abfd,
		struct eclair_bfd_symbol **location)
{
	require(abfd == (void *)0xdecafbadUL);
	location[0] = &eclair_symbols[0];
	location[1] = &eclair_symbols[1];
	location[2] = &eclair_symbols[2];
	return sizeof(eclair_symtab_storage) / sizeof(eclair_symtab_storage[0]);
}

uintptr_t virt_to_phys(uintptr_t va)
{
	virt_to_phys_va = va;
	if (va == 0xbad)
		return UINTPTR_MAX;
	return va + 0x1000;
}

void *bfd_get_section_by_name(void *abfd, const char *name)
{
	if (abfd != dumpbfd) {
		fprintf(stderr, "unexpected bfd handle\n");
		return NULL;
	}
	strncpy(bfd_last_name, name, sizeof(bfd_last_name) - 1);
	bfd_last_name[sizeof(bfd_last_name) - 1] = '\0';
	if (bfd_section_count >= 0 && bfd_section_count < 8) {
		strncpy(bfd_section_names[bfd_section_count], name,
				sizeof(bfd_section_names[0]) - 1);
		bfd_section_names[bfd_section_count]
			[sizeof(bfd_section_names[0]) - 1] = '\0';
	}
	bfd_section_count++;
	if (!strcmp(name, "physchunks"))
		return eclair_physchunks_section;
	return eclair_physmem_section;
}

int bfd_get_section_contents(void *abfd, void *section, void *buf,
			     long offset, unsigned long size)
{
	uint64_t value64 = 0x8877665544332211ULL;
	uint32_t value32 = 0xaabbccddU;
	uintptr_t constants[12] = {
		0x10, 0x20, 0x30, 0x40, 0x50, 0x60,
		0x70, 0x80, 0x90, 0xa0, 0xb0, 0xc0,
	};

	if (abfd != dumpbfd) {
		fprintf(stderr, "unexpected bfd content request\n");
		return 0;
	}
	bfd_last_offset = offset;
	bfd_last_size = size;
	if (section == eclair_physchunks_section) {
		memcpy(buf, &eclair_mem_chunks, size);
	}
	else if (section != eclair_physmem_section) {
		fprintf(stderr, "unexpected bfd section\n");
		return 0;
	}
	else if (size == sizeof(constants)) {
		memcpy(buf, constants, sizeof(constants));
	}
	else if (size == sizeof(value64)) {
		memcpy(buf, &value64, sizeof(value64));
	}
	else if (size == sizeof(value32)) {
		memcpy(buf, &value32, sizeof(value32));
	}
	else {
		memset(buf, 0x5a, size);
	}

	return 1;
}

void bfd_perror(const char *message)
{
	fprintf(stderr, "bfd_perror: %s\n", message);
}

int ioctl(int fd, unsigned long request, ...)
{
	uint64_t value64 = 0x1122334455667788ULL;
	struct eclair_dumpargs *args;
	va_list ap;

	va_start(ap, request);
	args = va_arg(ap, struct eclair_dumpargs *);
	va_end(ap);

	ioctl_fd = fd;
	ioctl_request = request;
	ioctl_cmd = args->cmd;
	ioctl_start = args->start;
	ioctl_size = args->size;
	if (ioctl_count >= 0 && ioctl_count < 8) {
		ioctl_cmds[ioctl_count] = args->cmd;
		ioctl_levels[ioctl_count] = args->level;
	}
	ioctl_count++;
	if (args->cmd == 7) {
		args->size = sizeof(eclair_mem_chunks);
	}
	else if (args->cmd == 8) {
		memcpy(args->buf, &eclair_mem_chunks, sizeof(eclair_mem_chunks));
	}
	else if (args->size == (long)sizeof(value64) && args->buf) {
		memcpy(args->buf, &value64, sizeof(value64));
	}
	return 0;
}

int kill(pid_t pid, int sig)
{
	kill_pid = pid;
	kill_sig = sig;
	return 0;
}

static int capture_print_usage(char *out, size_t out_size)
{
	FILE *capture;
	int saved_stderr;
	size_t nread;

	capture = tmpfile();
	require(capture != NULL);
	saved_stderr = dup(fileno(stderr));
	require(saved_stderr >= 0);
	fflush(stderr);
	require(dup2(fileno(capture), fileno(stderr)) >= 0);
	print_usage();
	fflush(stderr);
	require(dup2(saved_stderr, fileno(stderr)) >= 0);
	close(saved_stderr);
	rewind(capture);
	nread = fread(out, 1, out_size - 1, capture);
	out[nread] = '\0';
	fclose(capture);
	return 0;
}

int main(void)
{
	unsigned char payload[] = { 0x00, 0xab, 0xff };
	unsigned long digest = 0x65636c616972UL;
	uintptr_t start = 0;
	size_t size = 0;
	uint64_t value64 = 0;
	uint32_t value32 = 0;
	uint8_t check = 0;
	char buf[512];
	char cbuf[3];
	char expected[512];
	struct eclair_thread_info threads[3];
	struct eclair_thread_info *current_thread;
	int out = 0;
	int mode = 0;
	int action = 0;
	int next_remote = 0;
	int set_done = 0;
	int error_tid = 0;
	int error_kind = 0;
	size_t lpos = 0;
	uint8_t psum = 0;
	uint8_t pcheck = 0;
	int dbg_ret = eclair_dprintf("debug %d", 7);
	char *options_argv[] = {
		"eclair", "-c", "-l", "-k", "kernel.alt",
		"-d", "dump.alt", "-o", "9",
	};
	ssize_t n;

	gdbpid = 0;
	PHYS_OFFSET = 0;
	MAP_KERNEL_START = 0;
	kernel_base = 0;
	memset(debug_constants, 0, sizeof(uintptr_t) * 12);
	remote_running = 123;
	memset(&opt, 0, sizeof(opt));
	opt.interactive = 0;
	opt.mcos_fd = 77;
	mem_chunks = &eclair_mem_chunks;
	dumpbfd = eclair_dump_bfd;
	symtab = eclair_symtab_storage;
	nsyms = sizeof(eclair_symtab_storage) /
		sizeof(eclair_symtab_storage[0]);
	symbfd = NULL;

	require(dbg_ret == 0);
	require(eclair_parse_i32_result(" -42tail") == -42);
	options(sizeof(options_argv) / sizeof(options_argv[0]), options_argv);
	require(opt.cpu == 1 && opt.print_idle == 1 && opt.os_id == 9);
	require(opt.help == 0 && opt.interactive == 0 && opt.mcos_fd == -1);
	require(!strcmp(opt.kernel_path, "kernel.alt"));
	require(!strcmp(opt.dump_path, "dump.alt"));
	opt.mcos_fd = 77;
	memset(buf, 0, sizeof(buf));
	require(eclair_physmem_name_result(buf, 17) == 9);
	require(!strcmp(buf, "physmem17"));
	require(eclair_mcos_path_result(buf, 3) == 10);
	require(!strcmp(buf, "/dev/mcos3"));

	require(eclair_print_hex_result(buf, sizeof(buf), "Az") == 4);
	require(!strcmp(buf, "417a"));
	require(eclair_print_bin_result(buf, sizeof(buf), payload,
			sizeof(payload)) == 6);
	require(!strcmp(buf, "00abff"));
	require(eclair_print_bin_result(buf, 4, payload, sizeof(payload)) < 0);
	require(print_bin(buf, sizeof(buf), payload, sizeof(payload)) == 6);
	require(!strcmp(buf, "00abff"));
	symtab = NULL;
	nsyms = -1;
	require(setup_symbols("kernel.img") == 0);
	require(symbfd == (void *)0xdecafbadUL);
	require(!strcmp(eclair_bfd_openr_name, "kernel.img"));
	require(nsyms == 3);
	dumpbfd = NULL;
	mem_chunks = NULL;
	kernel_base = 0;
	PHYS_OFFSET = 0;
	bfd_section_count = 0;
	memset(bfd_section_names, 0, sizeof(bfd_section_names));
	require(setup_dump("ignored.dump") == 0);
	require(dumpbfd == eclair_dump_bfd);
	require(!strcmp(eclair_bfd_fopen_name, "dump.alt"));
	require(bfd_section_count == 3);
	require(!strcmp(bfd_section_names[0], "physchunks"));
	require(!strcmp(bfd_section_names[1], "physmem0"));
	require(!strcmp(bfd_section_names[2], "physmem1"));
	require(mem_chunks != NULL);
	require(mem_chunks->nr_chunks == 2);
	require(kernel_base == 0xfeed0000UL);
	require(PHYS_OFFSET == 0x100000UL);
	memset(debug_constants, 0, sizeof(debug_constants));
	arch_setup_constants_calls = 0;
	require(setup_constants() == 0);
	require(arch_setup_constants_calls == 1);
	require(arch_setup_constants_fd == 77);
	require(debug_constants[0] == 0x10);
	require(debug_constants[1] == 0x20);
	require(debug_constants[10] == 0xb0);
	require(debug_constants[11] == 0xc0);
	require(lookup_symbol("beta") == 0x2000);
	require(lookup_symbol("missing") == UINTPTR_MAX);
	require(read_64(0x4444, &value64) == 0);
	require(value64 == 0x8877665544332211ULL);
	require(virt_to_phys_va == 0x4444);
	require(!strcmp(bfd_last_name, "physmem1"));
	require(bfd_last_offset == 0x444 &&
			bfd_last_size == sizeof(value64));
	require(read_32(0x5555, &value32) == 0);
	require(value32 == 0xaabbccddU);
	require(virt_to_phys_va == 0x5555);
	require(!strcmp(bfd_last_name, "physmem1"));
	require(bfd_last_offset == 0x1555 &&
			bfd_last_size == sizeof(value32));
	value64 = 0;
	require(read_symbol_64("alpha", &value64) == 0);
	require(value64 == 0x8877665544332211ULL);
	require(virt_to_phys_va == 0x1000);
	require(!strcmp(bfd_last_name, "physmem0"));
	require(bfd_last_offset == 0 &&
			bfd_last_size == sizeof(value64));
	require(read_mem(0xbad, &value64, sizeof(value64)) == 1);
	ioctl_count = 0;
	remote_running = 99;
	mem_chunks = NULL;
	require(setup_dump_interactive() == 0);
	require(ioctl_count == 4);
	require(ioctl_cmds[0] == 6 && ioctl_levels[0] == 0);
	require(ioctl_cmds[1] == 1);
	require(ioctl_cmds[2] == 7);
	require(ioctl_cmds[3] == 8);
	require(remote_running == 0);
	require(mem_chunks != NULL);
	require(mem_chunks->nr_chunks == 2);
	require(kernel_base == 0xfeed0000UL);
	require(PHYS_OFFSET == 0x100000UL);
	opt.interactive = 1;
	value64 = 0;
	require(read_mem(0x6666, &value64, sizeof(value64)) == 0);
	require(value64 == 0x1122334455667788ULL);
	require(ioctl_fd == 77 && ioctl_request == 0x112a06);
	require(ioctl_start == 0x7666 &&
			ioctl_size == (long)sizeof(value64));
	opt.interactive = 0;
	gdbpid = 1234;
	intr_handler(0);
	require(kill_pid == 1234 && kill_sig == 2);

	require(eclair_gdb_command_kind_result("qSupported", 0) ==
			ECLAIR_CMD_QSUPPORTED);
	require(eclair_gdb_command_kind_result("Hg10", 0) == ECLAIR_CMD_HG);
	require(eclair_gdb_command_kind_result("vCtrlC", 1) ==
		ECLAIR_CMD_VCTRLC);
	require(eclair_gdb_command_kind_result("vCtrlC", 0) == 0);
	require(eclair_parse_hex_i32_result("1a", &out) == 0);
	require(out == 0x1a);
	require(eclair_parse_memory_request_result("m100,20", &start,
						   &size) == 0);
	require(start == 0x100 && size == 0x20);

	require(eclair_response_checksum_result("OK") == 0x9a);
	require(eclair_parse_packet_checksum_result("9a", &check) == 0);
	require(check == 0x9a);
	require(eclair_packet_frame_result(buf, sizeof(buf), "OK") == 6);
	require(!strcmp(buf, "$OK#9a"));
	require(eclair_interrupt_command_result(buf, sizeof(buf)) == 6);
	require(!strcmp(buf, "Ctrl-C"));
	require(eclair_packet_step_result('$', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(mode == 1 && psum == 0 && lpos == 0);
	require(eclair_packet_step_result('O', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('K', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('#', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('9', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('a', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_READY);
	require(mode == 0 && pcheck == 0x9a && !strcmp(buf, "OK"));
	require(eclair_packet_step_result('$', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('O', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('#', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('0', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_NONE);
	require(eclair_packet_step_result('0', 0, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_BAD);
	require(eclair_packet_step_result(0x03, 1, &mode, &psum, &pcheck,
				buf, sizeof(buf), &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_INTERRUPT);
	require(!strcmp(buf, "Ctrl-C"));
	mode = 1;
	lpos = 3;
	require(eclair_packet_step_result('X', 0, &mode, &psum, &pcheck,
				buf, 4, &lpos, cbuf, sizeof(cbuf)) ==
		ECLAIR_PACKET_STEP_ERROR);
	require(mode == 0);

	n = eclair_simple_response_result(buf, sizeof(buf), ECLAIR_CMD_HC,
					  0, 0);
	require(n == 3 && !strcmp(buf, "S02"));
	n = eclair_simple_response_result(buf, sizeof(buf), ECLAIR_CMD_HC,
					  1, 0);
	require(n == 2 && !strcmp(buf, "OK"));
	n = eclair_simple_response_result(buf, sizeof(buf),
					  ECLAIR_CMD_STOP_QUERY, 1, 1);
	require(n == 3 && !strcmp(buf, "S12"));
	n = eclair_simple_response_result(buf, sizeof(buf),
					  ECLAIR_CMD_VCONT_QUERY, 0, 0);
	require(n == 0 && !strcmp(buf, ""));

	require(eclair_gdb_target_result(buf, sizeof(buf), 2345) > 0);
	require(!strcmp(buf, "target remote :2345"));
	require(eclair_banner_result(buf, sizeof(buf), 0, "dump.img") > 0);
	require(!strcmp(buf, "eclair 0.20160314 using dump file: dump.img"));
	require(eclair_banner_result(buf, sizeof(buf), 1, "dump.img") > 0);
	require(!strcmp(buf, "eclair 0.20160314 live debug mode"));
	require(eclair_usage_result(buf, sizeof(buf)) > 0);
	require(!strcmp(buf,
		"usage: eclair [-ch] [-d <mcdump>] [-k <kernel.img>]"));
	memset(buf, 0, sizeof(buf));
	require(capture_print_usage(buf, sizeof(buf)) == 0);
	require(!strcmp(buf,
		"usage: eclair [-ch] [-d <mcdump>] [-k <kernel.img>]\n"));
	require(eclair_open_mcos_error_result(buf, sizeof(buf), "eclair.c",
					      12, 5, 2) > 0);
	require(!strcmp(buf,
		"eclair.c:12 error: opening /dev/mcos5, errno: 2"));
	require(eclair_read_physmem_invalid_result(buf, sizeof(buf),
						  0x1234) > 0);
	require(!strcmp(buf, "read_physmem: invalid addr 0x1234"));
	require(eclair_lookup_failed_result(buf, sizeof(buf), "read_symbol_64",
					   "foo") > 0);
	require(!strcmp(buf, "read_symbol_64(foo):lookup_symbol failed"));

	require(eclair_static_response_result(buf, sizeof(buf),
			ECLAIR_CMD_QSUPPORTED, 0, 0x1000, "x86_64") > 0);
	require(!strcmp(buf, "PacketSize=1024;qXfer:features:read+"));
	require(eclair_static_response_result(buf, sizeof(buf), ECLAIR_CMD_QC,
			0x2a, 0x1000, "x86_64") > 0);
	require(!strcmp(buf, "QC2a"));
	require(eclair_static_response_result(buf, sizeof(buf),
			ECLAIR_CMD_MEMORY_MAP, 0, 0x1000, "x86_64") > 0);
	require(!strcmp(buf,
		"l<memory-map><memory type=\"rom\" start=\"0x1000\" length=\"0x27000\"/></memory-map>"));
	require(eclair_static_response_result(buf, sizeof(buf),
			ECLAIR_CMD_TARGET_XML, 0, 0x1000, "x86_64") > 0);
	require(strstr(buf, "<architecture>x86_64</architecture>") != NULL);
	require(eclair_thread_list_entry_result(buf, sizeof(buf), 1,
						0x20) > 0);
	require(!strcmp(buf, "m20"));
	require(eclair_thread_list_entry_result(buf, sizeof(buf), 0,
						0x21) > 0);
	require(!strcmp(buf, ",21"));
	memset(threads, 0, sizeof(threads));
	threads[0].next = &threads[1];
	threads[0].status = PS_RUNNING;
	threads[0].pid = 10;
	threads[0].tid = 0x10;
	threads[0].lcpu = 2;
	threads[1].next = &threads[2];
	threads[1].status = PS_INTERRUPTIBLE;
	threads[1].pid = 11;
	threads[1].tid = 0x20;
	threads[1].lcpu = 3;
	threads[1].idle = 1;
	threads[2].status = CS_RESERVED;
	threads[2].pid = 12;
	threads[2].tid = 0x30;
	threads[2].cpu = 7;
	require(eclair_thread_lookup_result(threads, 0x20) == &threads[1]);
	require(eclair_thread_lookup_result(threads, 0x40) == NULL);
	require(eclair_thread_list_result(buf, sizeof(buf), threads) == 9);
	require(!strcmp(buf, "m10,20,30"));
	require(eclair_thread_list_result(buf, 5, threads) < 0);
	require(eclair_print_hex_result(expected, sizeof(expected),
				"PID 11, idle waiting on CPU 3") > 0);
	require(eclair_thread_extra_info_hex_result(buf, sizeof(buf),
				threads, 0x20) == (ssize_t)strlen(expected));
	require(!strcmp(buf, expected));
	require(eclair_thread_extra_info_hex_result(buf, sizeof(buf),
				threads, 0x40) == -2);
	current_thread = &threads[0];
	error_tid = 0;
	error_kind = 0;
	require(eclair_pure_command_response_result("qSupported",
			ECLAIR_CMD_QSUPPORTED, buf, sizeof(buf), threads,
			&current_thread, 0, 0, 0x1000, "x86_64",
			&error_tid, &error_kind) > 0);
	require(!strcmp(buf, "PacketSize=1024;qXfer:features:read+"));
	require(current_thread == &threads[0] && error_tid == 0 &&
			error_kind == ECLAIR_CMD_QSUPPORTED);
	n = eclair_pure_command_response_result("Hg20", ECLAIR_CMD_HG,
			buf, sizeof(buf), threads, &current_thread, 0, 0,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == 2 && !strcmp(buf, "OK") &&
			current_thread == &threads[1]);
	n = eclair_pure_command_response_result("qC", ECLAIR_CMD_QC,
			buf, sizeof(buf), threads, &current_thread, 0, 0,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == 4 && !strcmp(buf, "QC20"));
	n = eclair_pure_command_response_result("Hg40", ECLAIR_CMD_HG,
			buf, sizeof(buf), threads, &current_thread, 0, 0,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == ECLAIR_PURE_COMMAND_INVALID_TID &&
			error_tid == 0x40 && error_kind == ECLAIR_CMD_HG);
	n = eclair_pure_command_response_result("Hgzz", ECLAIR_CMD_HG,
			buf, sizeof(buf), threads, &current_thread, 0, 0,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == ECLAIR_PURE_COMMAND_PARSE_ERROR &&
			error_kind == ECLAIR_CMD_HG);
	n = eclair_pure_command_response_result("T30",
			ECLAIR_CMD_THREAD_ALIVE, buf, sizeof(buf), threads,
			&current_thread, 0, 0, 0x1000, "x86_64",
			&error_tid, &error_kind);
	require(n == 2 && !strcmp(buf, "OK"));
	n = eclair_pure_command_response_result("qThreadExtraInfo,20",
			ECLAIR_CMD_QTHREAD_EXTRA_INFO, buf, sizeof(buf),
			threads, &current_thread, 0, 0, 0x1000, "x86_64",
			&error_tid, &error_kind);
	require(n == (ssize_t)strlen(expected) && !strcmp(buf, expected));
	n = eclair_pure_command_response_result("qfThreadInfo",
			ECLAIR_CMD_QFTHREADINFO, buf, sizeof(buf), threads,
			&current_thread, 0, 0, 0x1000, "x86_64",
			&error_tid, &error_kind);
	require(n == 9 && !strcmp(buf, "m10,20,30"));
	n = eclair_pure_command_response_result("qfThreadInfo",
			ECLAIR_CMD_QFTHREADINFO, buf, sizeof(buf), threads,
			&current_thread, 1, 0, 0x1000, "x86_64",
			&error_tid, &error_kind);
	require(n == ECLAIR_PURE_COMMAND_NOT_HANDLED);
	n = eclair_pure_command_response_result("g", ECLAIR_CMD_REGS,
			buf, sizeof(buf), threads, &current_thread, 0, 0,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == ECLAIR_PURE_COMMAND_NOT_HANDLED);
	n = eclair_pure_command_response_result("?", ECLAIR_CMD_STOP_QUERY,
			buf, sizeof(buf), threads, &current_thread, 1, 1,
			0x1000, "x86_64", &error_tid, &error_kind);
	require(n == 3 && !strcmp(buf, "S12"));
	n = eclair_pure_command_response_result("qSupported",
			ECLAIR_CMD_QSUPPORTED, buf, 4, threads,
			&current_thread, 0, 0, 0x1000, "x86_64",
			&error_tid, &error_kind);
	require(n == ECLAIR_PURE_COMMAND_BUFFER_ERROR);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_VCTRLC, 1, 1,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_NMI &&
			next_remote == 0 && set_done == 0);
	ioctl_cmd = 0;
	require(apply_remote_action(action, "DUMP_NMI_CONT for continue") == 0);
	require(ioctl_fd == 77 && ioctl_request == 0x112a06 &&
			ioctl_cmd == 1);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_VCTRLC, 1, 0,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_NONE &&
			next_remote == 0 && set_done == 0);
	ioctl_cmd = 0;
	require(apply_remote_action(action, "DUMP_NMI_CONT for continue") == 0);
	require(ioctl_cmd == 0);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_CONTINUE, 1, 0,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_CONTINUE &&
			next_remote == 1 && set_done == 0);
	require(apply_remote_action(action, "DUMP_NMI_CONT for continue") == 0);
	require(ioctl_cmd == 10);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_CONTINUE, 1, 1,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_NONE &&
			next_remote == 1 && set_done == 0);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_DETACH, 1, 0,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_CONTINUE &&
			next_remote == 1 && set_done == 1);
	require(eclair_remote_command_plan_result(ECLAIR_CMD_DETACH, 0, 0,
				&action, &next_remote, &set_done) == 0);
	require(action == ECLAIR_REMOTE_ACTION_NONE &&
			next_remote == 0 && set_done == 1);
	require(eclair_remote_command_plan_result(999, 0, 0,
				&action, &next_remote, &set_done) < 0);
	require(apply_remote_action(999, "DUMP_NMI_CONT for continue") == -1);
	require(eclair_thread_extra_info_result(buf, sizeof(buf), 77,
			PS_RUNNING, 1, 3, 9) > 0);
	require(!strcmp(buf, "PID 77, idle running on CPU 3"));
	require(eclair_thread_extra_info_result(buf, sizeof(buf), 78,
			PS_INTERRUPTIBLE, 0, 4, 9) > 0);
	require(!strcmp(buf, "PID 78, waiting on CPU 4"));
	require(eclair_thread_extra_info_result(buf, sizeof(buf), 79,
			PS_STOPPED, 0, 5, 9) > 0);
	require(!strcmp(buf, "PID 79, stopped on CPU 5"));
	require(eclair_thread_extra_info_result(buf, sizeof(buf), 80,
			CS_RESERVED, 0, 5, 6) > 0);
	require(!strcmp(buf, "PID 80, CPU 6 reserved"));

	mix(&digest, eclair_response_checksum_result(buf));
	mix(&digest, (unsigned long)dbg_ret);
	mix(&digest, (unsigned long)start + size + check + out);
	mix(&digest, (unsigned long)(uintptr_t)current_thread);
	mix(&digest, (unsigned long)(error_tid + error_kind));
	printf("eclair_helpers ok digest=%016lx\n", digest);
	return 0;
}
