#include <limits.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sysinfo.h>

#define EFAULT 14
#define EINVAL 22
#define EIO 5
#define EPERM 1
#define ENOMEM 12
#define ENOSYS 38
#define ESRCH 3
#define ENOTSUPP 524
#define EOPNOTSUPP 95
#define VR_RESERVED 0x2UL
#define VR_IO_NOCACHE 0x100UL
#define VR_REMOTE 0x200UL
#define VR_LOCKED 0x4000UL
#define VR_FILEOFF 0x8000UL
#define PAGE_SIZE 4096UL
#define PAGE_MASK (~(PAGE_SIZE - 1))
#define PGOFF_LIMIT (1UL << 51)
	#define MCL_CURRENT 0x01
	#define MCL_FUTURE 0x02
	#define MCK_RLIMIT_MEMLOCK 6
	#define MEMLOCK_OP_LOCK 1
	#define MEMLOCK_OP_UNLOCK 2
#define PROT_READ 0x01
#define PROT_WRITE 0x02
#define PROT_EXEC 0x04
#define SHM_HUGETLB 04000
#define SHM_RDONLY 010000
#define SHM_RND 020000
#define SHM_DEST 01000
#define SHM_LOCKED 02000
#define IPC_RMID 0
#define IPC_SET 1
#define IPC_STAT 2
#define IPC_INFO 3
#define SHM_LOCK 11
#define SHM_UNLOCK 12
#define SHM_STAT 13
#define SHM_INFO 14
#define SHMCTL_LOG_ENTER 1
#define SHMCTL_LOG_LOOKUP 2
#define SHMCTL_LOG_EPERM 3
#define SHMCTL_LOG_COPY 4
#define SHMCTL_LOG_EXIT 5
#define SHMCTL_LOG_EACCES 6
#define SHMCTL_LOG_PERM_SHM 7
#define SHMCTL_LOG_PERM_PROC 8
#define SHMCTL_LOG_USER_LOOKUP 9
#define SHMCTL_LOG_TOO_LARGE 10
#define SHMCTL_LOG_EINVAL 11
#define SHM_HUGE_SHIFT 26
#define MAP_HUGE_SHIFT 26
#define SHM_HUGE_2MB (21 << SHM_HUGE_SHIFT)
#define SHM_HUGE_1GB (30 << SHM_HUGE_SHIFT)
#define ARCH_SHMGET_LOG_ENTER 1
#define ARCH_SHMGET_LOG_EXIT 2
#define MAP_SHARED 0x01
#define MAP_PRIVATE 0x02
#define MAP_FIXED 0x10
#define MAP_ANONYMOUS 0x20
#define MAP_32BIT 0x40
#define MAP_GROWSDOWN 0x0100
#define MAP_DENYWRITE 0x0800
#define MAP_EXECUTABLE 0x1000
#define MAP_LOCKED 0x2000
#define MAP_NORESERVE 0x4000
#define MAP_POPULATE 0x8000
#define MAP_NONBLOCK 0x00010000
#define MAP_STACK 0x00020000
#define MAP_HUGETLB 0x00040000
#define MAP_HUGE_MASK ((int)0xfc000000U)
#define MAP_HUGE_2MB (21 << MAP_HUGE_SHIFT)
#define MAP_HUGE_1GB (30 << MAP_HUGE_SHIFT)
#define PTL3_SIZE (1UL << 30)
#define ARCH_MMAP_LOG_ENTER 1
#define ARCH_MMAP_LOG_UNSUPPORTED_PGSIZE 2
#define ARCH_MMAP_LOG_INVALID 3
#define ARCH_MMAP_LOG_NOMEM 4
#define ARCH_MMAP_LOG_UNKNOWN_FLAGS 5
#define ARCH_MMAP_LOG_EXIT 6
#define VR_DEMAND_PAGING 0x1000UL
#define VR_PRIVATE 0x2000UL
#define VR_PROT_READ 0x00010000UL
#define VR_PROT_WRITE 0x00020000UL
#define VR_PROT_EXEC 0x00040000UL
#define VR_PROT_MASK 0x00070000UL
#define VR_MAXPROT_MASK 0x00700000UL
#define PF_WRITE (1UL << 1)
#define PF_USER (1UL << 2)
#define PF_POPULATE (1UL << 30)
#define PTATTR_ACTIVE 0x01UL
#define PTATTR_USER 0x04UL
#define PTATTR_NO_EXECUTE 0x8000000000000000UL
#define PTATTR_UNCACHABLE 0x10000UL
#define ARCH_VDSO_SETUP_LOG_GET_INFO_FAILED 1
#define ARCH_VDSO_SETUP_LOG_LOCAL_GETTIME_DISABLED 2
#define ARCH_VDSO_SETUP_LOG_VDSO_DISABLED 3
#define ARCH_VDSO_SETUP_LOG_MAP_GLOBAL_FAILED 4
#define ARCH_VDSO_MAP_LOG_NOT_AVAILABLE 1
#define ARCH_VDSO_MAP_LOG_ADD_VDSO_FAILED 2
#define ARCH_VDSO_MAP_LOG_MAPPED 3
#define ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED 4
#define ARCH_VDSO_MAP_LOG_ADD_VVAR_FAILED 5
#define MF_SHMDT_OK 0x0002U
#define PROT_TO_VR_FLAG(prot) (((unsigned long)(prot) << 16) & VR_PROT_MASK)
#define VRFLAG_PROT_TO_MAXPROT(vrflag) (((vrflag) & VR_PROT_MASK) << 4)
#define VRFLAG_MAXPROT_TO_PROT(vrflag) (((vrflag) & VR_MAXPROT_MASK) >> 4)
#define SETTIMEOFDAY_LOG_ENTER 1
#define SETTIMEOFDAY_LOG_ORIGIN 2
#define SETTIMEOFDAY_LOG_EXIT 3
#define MREMAP_MAYMOVE 0x01
#define MREMAP_FIXED 0x02

#ifdef SYSCALL_POLICY_USE_C_MODEL
void ts_add(struct timespec *ats, const struct timespec *bts)
{
	ats->tv_sec += bts->tv_sec;
	ats->tv_nsec += bts->tv_nsec;
	while (ats->tv_nsec >= 1000000000) {
		ats->tv_sec++;
		ats->tv_nsec -= 1000000000;
	}
}

void ts_sub(struct timespec *ats, const struct timespec *bts)
{
	ats->tv_sec -= bts->tv_sec;
	ats->tv_nsec -= bts->tv_nsec;
	while (ats->tv_nsec < 0) {
		ats->tv_sec--;
		ats->tv_nsec += 1000000000;
	}
}

void tv_add(struct timeval *ats, const struct timeval *bts)
{
	ats->tv_sec += bts->tv_sec;
	ats->tv_usec += bts->tv_usec;
	while (ats->tv_usec >= 1000000) {
		ats->tv_sec++;
		ats->tv_usec -= 1000000;
	}
}

void tv_sub(struct timeval *ats, const struct timeval *bts)
{
	ats->tv_sec -= bts->tv_sec;
	ats->tv_usec -= bts->tv_usec;
	while (ats->tv_usec < 0) {
		ats->tv_sec--;
		ats->tv_usec += 1000000;
	}
}

void tv_to_ts(struct timespec *ats, const struct timeval *bts)
{
	ats->tv_sec = bts->tv_sec;
	ats->tv_nsec = bts->tv_usec * 1000;
}

void ts_to_tv(struct timeval *ats, const struct timespec *bts)
{
	ats->tv_sec = bts->tv_sec;
	ats->tv_usec = bts->tv_nsec / 1000;
}
#endif

#define MS_ASYNC 0x01
#define MS_INVALIDATE 0x02
#define MS_SYNC 0x04
#define MPOL_DEFAULT 0
#define MPOL_PREFERRED 1
#define MPOL_BIND 2
#define MPOL_INTERLEAVE 3
#define MPOL_F_STATIC_NODES (1 << 15)
#define MPOL_F_RELATIVE_NODES (1 << 14)
#define MPOL_F_NODE (1 << 0)
#define MPOL_F_ADDR (1 << 1)
#define MPOL_F_MEMS_ALLOWED (1 << 2)
#define MPOL_MF_STRICT (1 << 0)
#define MPOL_MF_MOVE (1 << 1)
#define MPOL_MF_MOVE_ALL (1 << 2)
#define MOVE_PAGES_LOG_UNSUPPORTED_PID 1
#define MOVE_PAGES_LOG_UNSUPPORTED_MOVE_ALL 2
#define MOVE_PAGES_LOG_INIT_MALLOC 3
#define MOVE_PAGES_LOG_INIT_VERIFY 4
#define MOVE_PAGES_LOG_PARALLEL 5
#define FAKE_PROCESS_VM_SIZE 304
#define FAKE_PROCESS_VM_LOCK_OFF 180
#define FAKE_PROCESS_VM_NUMA_MASK_OFF 208
#define FAKE_PROCESS_VM_POLICY_OFF 240
#define FAKE_PROCESS_VM_IL_PREV_OFF 244
#define FAKE_RANGE_POLICY_SIZE 80
#define FAKE_RANGE_POLICY_MASK_OFF 40
#define FAKE_RANGE_POLICY_POLICY_OFF 72
#define FAKE_RANGE_POLICY_IL_PREV_OFF 76
#define SIG_BLOCK 0
#define SIG_UNBLOCK 1
#define SIG_SETMASK 2
#define SIGKILL_MASK (1UL << 8)
#define SIGSTOP_MASK (1UL << 18)
#define SFD_CLOEXEC 02000000
#define SFD_NONBLOCK 04000
#define RUSAGE_SELF 0
#define RUSAGE_CHILDREN -1
#define RUSAGE_THREAD 1
#define GETRUSAGE_DISPATCH_SELF 1
#define GETRUSAGE_DISPATCH_CHILDREN 2
#define GETRUSAGE_DISPATCH_THREAD 3
#define GETRUSAGE_THREAD_UPDATE_READY 0
#define GETRUSAGE_THREAD_UPDATE_INTERRUPT 1
#define TERMINATE_CHILD_ACTION_NONE 0
#define TERMINATE_CHILD_ACTION_FREE_ZOMBIE 1
#define TERMINATE_CHILD_ACTION_REPARENT_CHILD 2
#define TERMINATE_CHILD_ACTION_REPARENT_PTRACED 3
#define ITIMER_REAL 0
#define ITIMER_VIRTUAL 1
#define ITIMER_PROF 2
#define CLOCK_REALTIME 0
#define CLOCK_MONOTONIC 1
#define CLOCK_PROCESS_CPUTIME_ID 2
#define CLOCK_THREAD_CPUTIME_ID 3
#define NS_PER_SEC 1000000000L
#define TIME_DISPATCH_NOOP 0
#define TIME_DISPATCH_LOCAL_REALTIME 1
#define TIME_DISPATCH_PROCESS_CPUTIME 2
#define TIME_DISPATCH_THREAD_CPUTIME 3
#define TIME_DISPATCH_FORWARD 4
#define MINSIGSTKSZ 2048
#define SS_DISABLE 2
typedef struct fake_stack {
	void *ss_sp;
	int ss_flags;
	size_t ss_size;
} stack_t;
struct fake_syscall_request {
	int rtid;
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};
struct fake_syscall_response {
	int ttid;
	int stid;
	unsigned long status;
	unsigned long req_thread_status;
	long ret;
	unsigned long fault_address;
	void *pde_data;
};
struct fake_ikc_packet_header {
	void *channel;
};
	struct fake_ikc_scd_packet {
		struct fake_ikc_packet_header header;
		int msg;
	int err;
	void *reply;
	union {
		struct {
			int ref;
			int osnum;
			int pid;
			unsigned long arg;
			struct fake_syscall_request req;
			unsigned long resp_pa;
		};
		struct {
			long sysfs_arg1;
			long sysfs_arg2;
			long sysfs_arg3;
		};
		struct {
			int ttid_body;
		};
		struct {
			unsigned long pdesc;
			int op;
			void *resp;
		};
		struct {
			int eventfd_type;
		};
		struct {
			void *futex_resp;
			int *spin_sleep;
		};
		struct {
			int target_cpu;
			int fault_tid;
			unsigned long fault_address;
			unsigned long fault_reason;
		};
		};
	};
	typedef struct {
		int counter;
	} fake_ihk_atomic_t;
	struct fake_move_pages_smp_req {
		unsigned long count;
		const void **user_virt_addr;
		int *user_status;
		const int *user_nodes;
		void **virt_addr;
		int *status;
		void **ptep;
		int *nodes;
		int nodes_ready;
		int *nr_pages;
		unsigned long *dst_phys;
		void *proc;
		fake_ihk_atomic_t phase_done;
		int phase_ret;
	};
	#define SCD_MSG_SYSCALL_ONESIDE 0x4
	#define SCD_MSG_EVENTFD 0x46
	#define IOV_MAX 1024UL
#define PROCESS_VM_READ 0
#define PROCESS_VM_WRITE 1
#define PR_SET_THP_DISABLE 41
#define PR_GET_THP_DISABLE 42
#define ARCH_SET_GS 0x1001UL
#define ARCH_SET_FS 0x1002UL
#define ARCH_GET_FS 0x1003UL
#define ARCH_GET_GS 0x1004UL
#define IHK_ASR_X86_FS 0
#define IHK_ASR_X86_GS 1
#define PTRACE_TRACEME 0
#define PTRACE_PEEKTEXT 1
#define PTRACE_PEEKDATA 2
#define PTRACE_PEEKUSER 3
#define PTRACE_POKETEXT 4
#define PTRACE_POKEDATA 5
#define PTRACE_POKEUSER 6
#define PTRACE_CONT 7
#define PTRACE_KILL 8
#define PTRACE_SINGLESTEP 9
#define PTRACE_GETREGS 12
#define PTRACE_SETREGS 13
#define PTRACE_GETFPREGS 14
#define PTRACE_SETFPREGS 15
#define PTRACE_ATTACH 16
#define PTRACE_DETACH 17
#define PTRACE_SYSCALL 24
#define PTRACE_GETFPXREGS 18
#define PTRACE_SETFPXREGS 19
#define PTRACE_SETOPTIONS 0x4200
#define PTRACE_GETEVENTMSG 0x4201
#define PTRACE_GETSIGINFO 0x4202
#define PTRACE_SETSIGINFO 0x4203
#define PTRACE_GETREGSET 0x4204
#define PTRACE_SETREGSET 0x4205
#define PTRACE_WAKEUP_ACTION_NONE 0
#define PTRACE_WAKEUP_ACTION_KILL 1
#define PTRACE_WAKEUP_ACTION_RESUME 2
#define PTRACE_RESUME_SIGNAL_SOURCE_USER 0
#define PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG 1
#define PTRACE_RESUME_SIGNAL_SOURCE_RECVSIG 2
#define PTRACE_SIGINFO_STORE_SENDSIG 0x1
#define PTRACE_SIGINFO_STORE_RECVSIG 0x2
#define PTRACE_SIGINFO_ALLOC_SENDSIG 0x4
#define PTRACE_DISPATCH_ARCH 0
#define PTRACE_DISPATCH_TRACEME 1
#define PTRACE_DISPATCH_WAKEUP 2
#define PTRACE_DISPATCH_GETREGS 3
#define PTRACE_DISPATCH_SETREGS 4
#define PTRACE_DISPATCH_GETFPREGS 5
#define PTRACE_DISPATCH_SETFPREGS 6
#define PTRACE_DISPATCH_PEEKUSER 7
#define PTRACE_DISPATCH_POKEUSER 8
#define PTRACE_DISPATCH_PEEKTEXT 9
#define PTRACE_DISPATCH_POKETEXT 10
#define PTRACE_DISPATCH_SETOPTIONS 11
#define PTRACE_DISPATCH_ATTACH 12
#define PTRACE_DISPATCH_DETACH 13
#define PTRACE_DISPATCH_GETSIGINFO 14
#define PTRACE_DISPATCH_SETSIGINFO 15
#define PTRACE_DISPATCH_GETREGSET 16
#define PTRACE_DISPATCH_SETREGSET 17
#define PTRACE_DISPATCH_GETEVENTMSG 18
#define NT_PRSTATUS 1
#define NT_X86_XSTATE 0x202
#define ARCH_PTRACE_REGSET_LOG_READ_UNSUPPORTED 1
#define ARCH_PTRACE_REGSET_LOG_WRITE_UNSUPPORTED 2
#define ARCH_PTRACE_USER_LOG_READ_MISSING_DEBUGREG 3
#define ARCH_PTRACE_USER_LOG_READ_OTHER 4
#define ARCH_PTRACE_USER_LOG_WRITE_MISSING_DEBUGREG 5
#define ARCH_PTRACE_USER_LOG_WRITE_OTHER 6
#define ARCH_PTRACE_USER_LOG_ALLOC_FAILED 7
#define PTRACE_TEXT_LOG_PEEK_BAD_AREA 1
#define PTRACE_TEXT_LOG_POKE_BAD_ADDRESS 2
#define PTRACE_CONTROL_LOG_SETOPTIONS_UNSUPPORTED 1
#define PTRACE_CONTROL_LOG_SETOPTIONS_APPLIED 2
#define PTRACE_CONTROL_LOG_ATTACH_RETURN 3
#define PTRACE_CONTROL_LOG_WAKEUP_ENTER 4
#define PTRACE_REPORT_CLONE_LOG_ENTER 5
#define PTRACE_REPORT_CLONE_LOG_KILL_SIGCHLD 6
#define PTRACE_REPORT_CLONE_LOG_DO_KILL_FAILED 7
#define PTRACE_REPORT_SIGNAL_LOG_ENTER 8
#define PTRACE_REPORT_SIGNAL_LOG_SLEEPING 9
#define PTRACE_REPORT_SIGNAL_LOG_WAKE 10
#define PTRACE_O_TRACESYSGOOD 1
#define PTRACE_O_TRACEFORK 2
#define PTRACE_O_TRACEVFORK 4
#define PTRACE_O_TRACECLONE 8
#define PTRACE_O_TRACEEXEC 0x10
#define PTRACE_O_TRACEVFORKDONE 0x20
#define PTRACE_O_TRACEEXIT 0x40
#define PTRACE_O_MASK 0x7f
#define PT_TRACED 0x80
#define PT_TRACE_EXEC 0x100
#define PT_TRACE_SYSCALL 0x200
#define RFLAGS_MASK 0x54dd5UL
#define DB6_RESERVED_MASK 0xffffffffffff1ff0UL
#define DB6_RESERVED_SET 0xffff0ff0UL
#define DB7_RESERVED_MASK 0xffffffff0000dc00UL
#define DB7_RESERVED_SET 0x400UL
#define PTRACE_EVENT_FORK 1
#define PTRACE_EVENT_VFORK 2
#define PTRACE_EVENT_CLONE 3
#define PTRACE_EVENT_EXEC 4
#define PTRACE_EVENT_VFORK_DONE 5
#define PS_RUNNING 0x1
#define PS_ZOMBIE 0x8
#define PS_EXITED 0x10
#define PS_STOPPED 0x20
#define PS_TRACED 0x40
#define PS_DELAY_STOPPED 0x200
#define PS_DELAY_TRACED 0x400
#define SIGNAL_STOP_STOPPED 0x1
#define SIGNAL_STOP_CONTINUED 0x2
#define WAIT_STOP_SOURCE_NONE 0
#define WAIT_STOP_SOURCE_THREAD 1
#define WAIT_STOP_SOURCE_PROCESS 2
#define WAIT_STOP_SOURCE_MAIN_THREAD 3
#define WAIT_THREAD_REAP_ACTION_NONE 0
#define WAIT_THREAD_REAP_ACTION_RELEASE 1
#define WAIT_THREAD_REAP_ACTION_PTRACE_DETACH 2
#define WAIT_LOG_ENTER 1
#define WAIT_LOG_SLEEPING 2
#define WAIT_LOG_WOKEN 3
#define WAIT_LOG_FOUND 4
#define WAIT_LOG_NOTFOUND 5
#define EXIT_GROUP_STATUS_CONFIRMED 0x0000000100000000UL
#undef WNOHANG
#undef WUNTRACED
#undef WSTOPPED
#undef WEXITED
#undef WCONTINUED
#undef WNOWAIT
#undef __WALL
#undef __WCLONE
#define WNOHANG 0x00000001
#define WUNTRACED 0x00000002
#define WSTOPPED WUNTRACED
#define WEXITED 0x00000004
#define WCONTINUED 0x00000008
#define WNOWAIT 0x01000000
#define __WALL 0x40000000
#define __WCLONE ((int)0x80000000u)
#define P_ALL 0
#define P_PID 1
#define P_PGID 2
#define SIGKILL 9
#define SIGCHLD 17
#define SIGSTOP 19
#define SIGTSTP 20
#define SIGTTIN 21
#define SIGTTOU 22
#define CLD_TRAPPED 4
#define SI_USER 0
#define SIGCONT 18
#define SIGURG 23
#define SIG_IGN_HANDLER 1UL
#define SIGTRAP 5
#define TRAP_TRACE 2
#define RFLAGS_TF (1UL << 8)
#define IHK_MC_AP_NOWAIT 0x000002UL
#define _NSIG 64
#define CSIGNAL 0x000000ff
#define CLONE_VM 0x00000100
#define CLONE_FS 0x00000200
#define CLONE_SIGHAND 0x00000800
#define CLONE_VFORK 0x00004000
#define CLONE_PARENT 0x00008000
#define CLONE_THREAD 0x00010000
#define CLONE_NEWNS 0x00020000
#define CLONE_SYSVSEM 0x00040000
#define CLONE_SETTLS 0x00080000
#define CLONE_PARENT_SETTID 0x00100000
#define CLONE_CHILD_CLEARTID 0x00200000
#define CLONE_CHILD_SETTID 0x01000000
#define CLONE_NEWIPC 0x08000000
#define CLONE_NEWPID 0x20000000
#define SPAWN_TO_LOCAL 0
#define SPAWN_TO_REMOTE 1
#define SPAWNING_TO_REMOTE 1001
#define CLONE_TLS_SOURCE_INHERIT 0
#define CLONE_TLS_SOURCE_ARGUMENT 1
#define AT_FDCWD -100
#define AT_SYMLINK_NOFOLLOW 0x100
#define AT_EMPTY_PATH 0x1000
#define FUTEX_WAIT 0
#define FUTEX_WAKE 1
#define FUTEX_CMP_REQUEUE 4
#define FUTEX_WAKE_OP 5
#define FUTEX_WAIT_BITSET 9
#define FUTEX_PRIVATE_FLAG 128
#define FUTEX_CLOCK_REALTIME 256
#define FUTEX_CMD_MASK (~(FUTEX_PRIVATE_FLAG | FUTEX_CLOCK_REALTIME))

struct fake_do_futex_log_record {
	int event;
	int flags;
	int op;
	unsigned long uaddr;
	uint32_t val;
	unsigned long utime;
	unsigned long uaddr2;
	uint32_t val3;
	int fshared;
	int ret;
	long sec;
	long nsec;
};

struct fake_brk_region {
	unsigned long brk_start;
	unsigned long brk_end;
	unsigned long brk_end_allocated;
};

struct fake_sched_yield_cpu {
	int runq_lock;
	size_t runq_len;
	unsigned int flags;
};

struct fake_msync_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	void *memobj;
};

struct fake_vm_regions {
	unsigned long map_start;
	unsigned long map_end;
	unsigned long user_end;
};

struct fake_vdso_vm_regions {
	unsigned long vm_start, vm_end;
	unsigned long text_start, text_end;
	unsigned long data_start, data_end;
	unsigned long brk_start, brk_end, brk_end_allocated;
	unsigned long map_start, map_end;
	unsigned long stack_start, stack_end;
	unsigned long user_start, user_end;
};

struct fake_vdso_process_vm {
	void *address_space;
	void *vm_range_tree_node;
	struct fake_vdso_vm_regions region;
	void *proc;
	void *opt;
	void *free_cb;
	void *vdso_addr;
	void *vvar_addr;
};

struct fake_arch_vdso {
	long busy;
	int vdso_npages;
	char vvar_is_global;
	char hpet_is_global;
	char pvti_is_global;
	char padding;
	long vdso_physlist[2];
	void *vvar_virt;
	long vvar_phys;
	void *hpet_virt;
	long hpet_phys;
	void *pvti_virt;
	long pvti_phys;
	void *vgtod_virt;
};

struct fake_do_munmap_proc {
	unsigned long straight_va;
	size_t straight_len;
};

struct fake_clear_host_vm {
	int is_memory_range_lock_taken;
};

struct fake_shmdt_memobj {
	void *ops;
	uint32_t flags;
};

struct fake_shmat_obj {
	int memobj;
	int pgshift;
	size_t real_segsz;
	unsigned int uid;
	unsigned int cuid;
	unsigned int gid;
	unsigned int cgid;
	uint16_t mode;
};

struct fake_ipc_perm {
	int key;
	unsigned int uid;
	unsigned int gid;
	unsigned int cuid;
	unsigned int cgid;
	uint16_t mode;
	uint8_t padding[2];
	uint16_t seq;
	uint8_t padding2[22];
};

struct fake_shmid_ds {
	struct fake_ipc_perm shm_perm;
	size_t shm_segsz;
	long shm_atime;
	long shm_dtime;
	long shm_ctime;
	int shm_cpid;
	int shm_lpid;
	uint64_t shm_nattch;
	uint8_t padding[12];
	int init_pgshift;
};

struct fake_shminfo {
	uint64_t shmmax;
	uint64_t shmmin;
	uint64_t shmmni;
	uint64_t shmseg;
	uint64_t shmall;
	uint8_t padding[32];
};

struct fake_shm_info {
	int32_t used_ids;
	uint8_t padding[4];
	uint64_t shm_tot;
	uint64_t shm_rss;
	uint64_t shm_swp;
	uint64_t swap_attempts;
	uint64_t swap_successes;
};

struct fake_shmlock_user {
	unsigned int ruid;
	int padding;
	size_t locked;
};

struct fake_shmctl_obj {
	int memobj;
	int pgshift;
	size_t real_segsz;
	struct fake_shmlock_user *user;
	struct fake_shmid_ds ds;
};

struct fake_shmctl_offsets {
	size_t obj_memobj_offset;
	size_t obj_pgshift_offset;
	size_t obj_real_segsz_offset;
	size_t obj_user_offset;
	size_t obj_ds_offset;
	size_t obj_uid_offset;
	size_t obj_cuid_offset;
	size_t obj_gid_offset;
	size_t obj_cgid_offset;
	size_t obj_mode_offset;
	size_t obj_ctime_offset;
	size_t obj_nattch_offset;
	size_t shmlock_user_locked_offset;
	size_t shmid_ds_size;
	size_t shminfo_size;
	size_t shm_info_size;
};

struct fake_mremap_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	unsigned long pgshift;
	void *memobj;
	unsigned long objoff;
};

struct memlock_log_record {
	int event;
	int op;
	int cpu;
	unsigned long start;
	size_t len;
	unsigned long addr;
	unsigned long range_start;
	unsigned long range_end;
	int error;
};

struct mprotect_log_record {
	int event;
	int cpu;
	unsigned long start;
	size_t len;
	int prot;
	unsigned long addr;
	unsigned long range_start;
	unsigned long range_end;
	unsigned long range_flags;
	unsigned long protflags;
	unsigned long denied;
	int error;
};

struct remap_file_pages_log_record {
	int event;
	int cpu;
	unsigned long start0;
	size_t size;
	int prot;
	size_t pgoff;
	int flags;
	unsigned long start;
	unsigned long end;
	unsigned long range_start;
	unsigned long range_end;
	unsigned long range_flags;
	void *memobj;
	long off;
	int error;
};

struct mremap_log_record {
	int event;
	unsigned long oldaddr;
	size_t oldsize0;
	size_t newsize0;
	int flags;
	unsigned long newaddr;
	unsigned long oldstart;
	unsigned long oldend;
	unsigned long newstart;
	unsigned long newend;
	unsigned long range_start;
	unsigned long range_end;
	unsigned long range_flags;
	unsigned long lckstart;
	unsigned long lckend;
	int error;
};

struct fake_mincore_range {
	unsigned long start;
	unsigned long end;
	void *memobj;
	long objoff;
};

struct rusage {
	struct timeval ru_utime;
	struct timeval ru_stime;
	long ru_maxrss;
	long ru_ixrss;
	long ru_idrss;
	long ru_isrss;
	long ru_minflt;
	long ru_majflt;
	long ru_nswap;
	long ru_inblock;
	long ru_oublock;
	long ru_msgsnd;
	long ru_msgrcv;
	long ru_nsignals;
	long ru_nvcsw;
	long ru_nivcsw;
};

struct fake_itimerval {
	struct timeval it_interval;
	struct timeval it_value;
};

struct fake_siginfo_child {
	int si_pid;
	int si_uid;
	int si_status;
	int padding;
	long si_utime;
	long si_stime;
};

struct fake_siginfo_kill {
	int si_pid;
	int si_uid;
};

union fake_siginfo_fields {
	int pad[28];
	struct fake_siginfo_child sigchld;
	struct fake_siginfo_kill kill;
};

struct fake_siginfo {
	int si_signo;
	int si_errno;
	int si_code;
	int padding;
	union fake_siginfo_fields sifields;
};

struct fake_getrusage_thread {
	int pad;
	int times_update;
};

struct fake_list_head {
	struct fake_list_head *next;
	struct fake_list_head *prev;
};

struct fake_cputime_process;

struct fake_cputime_thread {
	int cpu_id;
	int status;
	int in_kernel;
	int times_update;
	unsigned long user_tsc;
	unsigned long system_tsc;
	struct fake_cputime_process *proc;
	struct fake_list_head siblings_list;
};

struct fake_cputime_process {
	struct fake_list_head threads_list;
	struct timespec utime;
	struct timespec stime;
	struct timespec utime_children;
	struct timespec stime_children;
	long maxrss;
	long maxrss_children;
};

struct fake_cputime_offsets {
	size_t thread_proc_offset;
	size_t thread_status_offset;
	size_t thread_in_kernel_offset;
	size_t thread_cpu_id_offset;
	size_t thread_times_update_offset;
	size_t thread_user_tsc_offset;
	size_t thread_system_tsc_offset;
	size_t thread_siblings_list_offset;
	size_t proc_threads_list_offset;
	size_t proc_utime_offset;
	size_t proc_stime_offset;
	size_t proc_utime_children_offset;
	size_t proc_stime_children_offset;
	size_t proc_maxrss_offset;
	size_t proc_maxrss_children_offset;
};

struct fake_syscall_times_offsets {
	size_t thread_proc_offset;
	size_t thread_user_tsc_offset;
	size_t thread_system_tsc_offset;
	size_t proc_utime_offset;
	size_t proc_stime_offset;
	size_t proc_utime_children_offset;
	size_t proc_stime_children_offset;
};

struct fake_syscall_times_tms {
	unsigned long tms_utime;
	unsigned long tms_stime;
	unsigned long tms_cutime;
	unsigned long tms_cstime;
};

struct fake_itimer_offsets {
	size_t thread_itimer_enabled_offset;
	size_t thread_itimer_virtual_offset;
	size_t thread_itimer_prof_offset;
	size_t thread_itimer_virtual_value_offset;
	size_t thread_itimer_prof_value_offset;
};

struct fake_itimer_thread {
	int prefix;
	int itimer_enabled;
	struct fake_itimerval itimer_virtual;
	struct fake_itimerval itimer_prof;
	struct timespec itimer_virtual_value;
	struct timespec itimer_prof_value;
	int suffix;
};

struct fake_ptrace_thread {
	int pad;
	int ptrace;
	unsigned long eventmsg;
	void *ptrace_recvsig;
	void *ptrace_sendsig;
};

struct fake_sig_pending {
	unsigned char list[16];
	unsigned long sigmask;
	unsigned char info[128];
	int ptracecont;
	int interrupted;
};

struct fake_reg_thread {
	unsigned long values[8];
	unsigned long written[8];
	int fail_at;
};

struct fake_vm_word {
	unsigned long value;
	unsigned long last_addr;
	int fail;
};

struct fake_fpregs_thread {
	unsigned long last_data;
	int fail;
};

struct fake_arch_fpregs_thread {
	void *fp_regs;
};

struct fake_iovec {
	void *iov_base;
	size_t iov_len;
};

struct fake_process_vm_rw_offsets {
	size_t thread_proc_offset;
	size_t thread_vm_offset;
	size_t proc_vm_offset;
	size_t proc_status_offset;
	size_t proc_ruid_offset;
	size_t proc_euid_offset;
	size_t proc_suid_offset;
	size_t proc_rgid_offset;
	size_t proc_egid_offset;
	size_t proc_sgid_offset;
	size_t process_vm_address_space_offset;
	size_t address_space_page_table_offset;
	size_t vm_range_flag_offset;
};

struct fake_process_vm_rw_log_record {
	int event;
	int x;
	int y;
	int z;
	unsigned long a;
	unsigned long b;
	unsigned long c;
	unsigned long d;
	unsigned long e;
};

struct fake_process_vm_rw_address_space {
	void *page_table;
};

struct fake_process_vm_rw_vm {
	struct fake_process_vm_rw_address_space *address_space;
	int tag;
};

struct fake_process_vm_rw_proc {
	struct fake_process_vm_rw_vm *vm;
	int status;
	int ruid;
	int euid;
	int suid;
	int rgid;
	int egid;
	int sgid;
};

struct fake_process_vm_rw_thread {
	struct fake_process_vm_rw_proc *proc;
	struct fake_process_vm_rw_vm *vm;
};

struct fake_process_vm_rw_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
};

struct fake_regset_thread {
	int copy_from_fail;
	int io_fail;
	int copy_to_fail;
	int xstate_fail;
	int copy_from_calls;
	int io_calls;
	int copy_to_calls;
	int xstate_copy_to_calls;
	int xstate_copy_from_calls;
	int log_calls;
	int log_event;
	long log_type;
	unsigned long seen_base;
	unsigned long xstate_user_addr;
	size_t seen_len;
	size_t xstate_bytes;
	long seen_type;
	size_t new_len;
};

struct fake_ptrace_io_offsets {
	size_t thread_proc_offset;
	size_t thread_status_offset;
	size_t thread_vm_offset;
	size_t thread_ptrace_offset;
	size_t thread_ptrace_eventmsg_offset;
	size_t thread_ptrace_recvsig_offset;
	size_t thread_ptrace_sendsig_offset;
	size_t thread_report_proc_offset;
	size_t thread_ptrace_saved_uctx_valid_offset;
	size_t proc_pid_offset;
	size_t proc_update_lock_offset;
};

struct fake_ptrace_report_clone_offsets {
	size_t thread_proc_offset;
	size_t thread_tid_offset;
	size_t thread_status_offset;
	size_t thread_exit_status_offset;
	size_t thread_ptrace_offset;
	size_t thread_ptrace_eventmsg_offset;
	size_t proc_pid_offset;
	size_t proc_parent_offset;
	size_t proc_status_offset;
	size_t proc_update_lock_offset;
	size_t proc_waitpid_q_offset;
};

struct fake_ptrace_report_exec_offsets {
	size_t thread_ptrace_offset;
	size_t thread_ctx_offset;
	size_t thread_uctx_offset;
	size_t thread_ptrace_saved_uctx_offset;
	size_t thread_ptrace_saved_uctx_valid_offset;
};

struct fake_ptrace_report_signal_offsets {
	size_t thread_proc_offset;
	size_t thread_tid_offset;
	size_t thread_status_offset;
	size_t thread_exit_status_offset;
	size_t thread_signal_flags_offset;
	size_t thread_ptrace_offset;
	size_t thread_ptrace_debugreg_offset;
	size_t thread_report_proc_offset;
	size_t proc_pid_offset;
	size_t proc_parent_offset;
	size_t proc_main_thread_offset;
	size_t proc_status_offset;
	size_t proc_update_lock_offset;
	size_t proc_waitpid_q_offset;
};

struct fake_arch_ptrace_user_offsets {
	size_t thread_proc_offset;
	size_t thread_ptrace_saved_uctx_valid_offset;
	size_t thread_ptrace_saved_uctx_offset;
	size_t thread_ptrace_debugreg_offset;
	size_t proc_status_offset;
	size_t uctx_sr_offset;
	size_t uctx_gpr_offset;
};

struct fake_arch_user_context {
	unsigned long sr[2];
	unsigned long gpr[8];
};

struct fake_rt_sigreturn_gpr {
	unsigned long r15;
	unsigned long r14;
	unsigned long r13;
	unsigned long r12;
	unsigned long rbp;
	unsigned long rbx;
	unsigned long r11;
	unsigned long r10;
	unsigned long r9;
	unsigned long r8;
	unsigned long rax;
	unsigned long rcx;
	unsigned long rdx;
	unsigned long rsi;
	unsigned long rdi;
	unsigned long error;
	unsigned long rip;
	unsigned long cs;
	unsigned long rflags;
	unsigned long rsp;
	unsigned long ss;
};

struct fake_rt_sigreturn_context {
	unsigned long sr[6];
	unsigned char is_gpr_valid;
	unsigned char is_sr_valid;
	unsigned char spare_flags6;
	unsigned char spare_flags5;
	unsigned char spare_flags4;
	unsigned char spare_flags3;
	unsigned char spare_flags2;
	unsigned char spare_flags1;
	struct fake_rt_sigreturn_gpr gpr;
};

struct fake_rt_sigreturn_frame {
	unsigned long flags;
	void *link;
	stack_t sigstack;
	unsigned long regs[23];
	void *fpregs;
	unsigned long reserve[8];
	unsigned long sigrc;
	unsigned long sigmask;
	int num;
	int restart;
	unsigned long ss;
	struct fake_siginfo info;
};

struct fake_rt_sigreturn_thread {
	int prefix;
	unsigned long sigmask;
	stack_t sigstack;
	int suffix;
};

struct fake_arch_ptrace_thread {
	struct fake_ptrace_io_proc *proc;
	int saved_valid;
	struct fake_arch_user_context saved_uctx;
	unsigned long *debugreg;
	struct fake_arch_user_context *live_uctx;
	int unlocks;
	int find_key;
	int log_event;
	int log_value;
	int log_result;
};

struct fake_ptrace_io_proc {
	int pid;
	struct fake_ptrace_io_proc *parent;
	struct fake_ptrace_io_thread *main_thread;
	int status;
	int update_lock;
	int waitpid_q;
};

struct fake_ptrace_io_thread {
	struct fake_ptrace_io_proc *proc;
	int tid;
	int status;
	int exit_status;
	int signal_flags;
	struct fake_vm_word *vm;
	unsigned char kernel_ctx[16];
	void *uctx;
	int ptrace;
	unsigned long eventmsg;
	void *ptrace_debugreg;
	unsigned char saved_uctx[24];
	void *ptrace_recvsig;
	void *ptrace_sendsig;
	struct fake_ptrace_io_proc *report_proc;
	int saved_valid;
	unsigned long values[8];
	unsigned long written[8];
	int fail_at;
	unsigned long last_data;
	int fpregs_fail;
	int unlocks;
	int find_key;
	int log_event;
	int log_value;
	int log_result;
	unsigned long log_addr;
	int single_steps;
	int trace_updates;
	int wake_calls;
	int wake_states;
	struct fake_regset_thread regset;
};

static struct fake_regset_thread *active_regset_thread;
static struct fake_ptrace_io_thread *active_ptrace_io_thread;
static struct fake_arch_ptrace_thread *active_arch_ptrace_thread;
static const struct fake_arch_ptrace_user_offsets *active_arch_ptrace_offsets;
static void *fake_arch_alloc_result;
static size_t fake_arch_alloc_size;
static unsigned long fake_arch_alloc_flags;
static int fake_arch_alloc_calls;
static void *fake_ptrace_alloc_result;
static size_t fake_ptrace_alloc_size;
static unsigned long fake_ptrace_alloc_flags;
static int fake_ptrace_alloc_calls;
static int fake_ptrace_attach_calls;
static unsigned long fake_ptrace_attach_thread_addr;
static unsigned long fake_ptrace_attach_proc_addr;
static int fake_ptrace_attach_rc;
static int fake_ptrace_detach_calls;
static unsigned long fake_ptrace_detach_thread_addr;
static int fake_ptrace_detach_data;
static int fake_ptrace_kill_calls;
static void *fake_ptrace_kill_current;
static int fake_ptrace_kill_pid;
static int fake_ptrace_kill_tid;
static int fake_ptrace_kill_sig;
static int fake_ptrace_kill_ptracecont;
static int fake_ptrace_kill_si_signo;
static int fake_ptrace_kill_si_code;
static int fake_ptrace_kill_si_pid;
static int fake_ptrace_kill_si_status;
static long fake_ptrace_kill_rc;
static int fake_ptrace_lock_calls;
static int fake_ptrace_unlock_calls;
static unsigned long fake_ptrace_lock_addr;
static void *fake_ptrace_lock_node;
static int fake_ptrace_free_calls;
static void *fake_ptrace_freed_ptr;
static int fake_ptrace_waitq_wake_calls;
static void *fake_ptrace_waitq_wake_addr;
static int fake_ptrace_preempt_enable_calls;
static int fake_ptrace_preempt_disable_calls;
static int fake_ptrace_report_signal_calls;
static int fake_ptrace_report_signal_sig;
static int fake_ptrace_arch_event_calls;
static void *fake_ptrace_arch_event_thread;
static void *fake_ptrace_arch_event_ctx;
static long fake_ptrace_arch_event_setret;
static int fake_ptrace_save_debugreg_calls;
static void *fake_ptrace_saved_debugreg;
static int fake_ptrace_schedule_calls;

struct fake_rlimit {
	uint64_t rlim_cur;
	uint64_t rlim_max;
};

struct fake_syscall_process_ids {
	int pid;
	int pgid;
	int execed;
	int ruid;
	int euid;
	int suid;
	int fsuid;
	int rgid;
	int egid;
	int sgid;
	int fsgid;
	struct fake_rlimit rlimit[8];
	struct fake_syscall_process_ids *ppid_parent;
};

struct fake_syscall_thread_ids {
	int tid;
	struct fake_syscall_process_ids *proc;
	int *clear_child_tid;
};

struct fake_syscall_setpgid_offsets {
	size_t thread_proc_offset;
	size_t proc_pid_offset;
	size_t proc_pgid_offset;
	size_t proc_execed_offset;
};

struct fake_syscall_mlockall_offsets {
	size_t thread_proc_offset;
	size_t proc_euid_offset;
	size_t proc_rlimit_offset;
	size_t rlimit_entry_size;
	int memlock_resource;
};

struct fake_syscall_mckfd_offsets {
	size_t thread_proc_offset;
	size_t proc_mckfd_lock_offset;
	size_t proc_mckfd_offset;
	size_t mckfd_next_offset;
	size_t mckfd_fd_offset;
	size_t mckfd_read_cb_offset;
	size_t mckfd_ioctl_cb_offset;
	size_t mckfd_close_cb_offset;
	size_t mckfd_fcntl_cb_offset;
};

struct fake_syscall_mckfd {
	struct fake_syscall_mckfd *next;
	int fd;
	int sig_no;
	long data;
	void *opt;
	long (*read_cb)(struct fake_syscall_mckfd *, void *);
	int (*ioctl_cb)(struct fake_syscall_mckfd *, void *);
	long (*mmap_cb)(struct fake_syscall_mckfd *, void *);
	int (*close_cb)(struct fake_syscall_mckfd *, void *);
	int (*fcntl_cb)(struct fake_syscall_mckfd *, void *);
	int (*dup_cb)(struct fake_syscall_mckfd *, void *);
};

struct fake_syscall_mckfd_process {
	int prefix;
	unsigned long mckfd_lock;
	struct fake_syscall_mckfd *mckfd;
};

struct fake_syscall_mckfd_thread {
	int prefix;
	struct fake_syscall_mckfd_process *proc;
};

struct fake_sigaltstack_thread {
	int prefix;
	stack_t sigstack;
	int suffix;
};

struct fake_sigmask_thread {
	int prefix;
	unsigned long sigmask;
	int suffix;
};

struct fake_uti_attr {
	unsigned long words[4];
};

struct fake_uti_process {
	int prefix;
	int enable_uti;
	int suffix;
};

struct fake_uti_thread {
	int prefix;
	struct fake_uti_process *proc;
	int mod_clone;
	void *mod_clone_arg;
	int suffix;
};

struct fake_threads_signal_process {
	int prefix;
	int pid;
	struct fake_list_head threads_list;
	int suffix;
};

struct fake_threads_signal_thread {
	int prefix;
	struct fake_threads_signal_process *proc;
	int tid;
	int status;
	struct fake_list_head siblings_list;
	int suffix;
};

struct fake_sigaction {
	void *sa_handler;
	unsigned long sa_flags;
	void *sa_restorer;
	unsigned long sa_mask;
};

struct fake_k_sigaction {
	struct fake_sigaction sa;
};

struct fake_sigcommon {
	int lock_word;
	struct fake_k_sigaction action[64];
};

struct fake_monitor {
	int prefix;
	int status;
};

struct fake_wait_thread {
	int tid;
	int signal_flags;
	int exit_status;
};

struct fake_wait_process {
	int pid;
	int status;
	int group_exit_status;
	struct fake_wait_thread *main_thread;
};

struct fake_thread_exit_process {
	int pid;
	int waitpid_q;
};

struct fake_thread_exit_thread {
	struct fake_thread_exit_process *report_proc;
	int ptrace;
	int termsig;
	int exit_status;
	int tid;
	unsigned long user_tsc;
	unsigned long system_tsc;
};

struct fake_finalize_process {
	struct fake_finalize_process *parent;
	int status;
	int update_lock;
	int pid;
	int group_exit_status;
	int termsig;
	struct timespec utime;
	struct timespec stime;
	int waitpid_q;
};

struct fake_terminate_mcexec_process {
	unsigned long group_exit_status;
	int nohost;
};

struct fake_sync_child_atomic64 {
	long counter64;
};

struct fake_sync_child_event {
	int inherit;
	int counter_id;
	struct fake_sync_child_atomic64 count;
	unsigned long child_count_total;
	struct fake_sync_child_event *group_leader;
	struct fake_list_head sibling_list;
	int pid;
	struct fake_list_head group_entry;
};

struct fake_perf_start_process {
	int perf_status;
	void *monitoring_event;
};

struct fake_perf_read_thread {
	struct fake_perf_start_process *proc;
	unsigned long system_tsc;
	unsigned long user_tsc;
	unsigned long pmc_alloc_map;
	unsigned long extra_reg_alloc_map;
};

struct fake_perf_read_event {
	int pid;
	int inherit;
	int counter_id;
	struct fake_perf_counter_attr {
		int exclude_kernel;
		int exclude_user;
		int inherit;
	} attr;
	unsigned long hw_config;
	unsigned int extra_reg;
	int extra_reg_idx;
	int state;
	int use_invariant_tsc;
	struct fake_sync_child_atomic64 count;
	unsigned long child_count_total;
	struct fake_perf_read_event *group_leader;
	int nr_siblings;
	unsigned long pmc_status;
	struct fake_list_head sibling_list;
	struct fake_list_head group_entry;
	long long base_user_tsc;
	long long stopped_user_tsc;
	long long user_accum_count;
	long long base_system_tsc;
	long long stopped_system_tsc;
	long long system_accum_count;
};

struct fake_perf_ioctl_process {
	int perf_status;
	void *monitoring_event;
};

struct fake_perf_fcntl_fd {
	int sig_no;
};

struct fake_perf_mmap_page {
	unsigned long capabilities;
	unsigned long data_head;
};

struct fake_perf_open_fd {
	struct fake_perf_open_fd *next;
	int fd;
	int sig_no;
	long data;
	void *opt;
	long (*read_cb)(void *, void *);
	int (*ioctl_cb)(void *, void *);
	long (*mmap_cb)(void *, void *);
	int (*close_cb)(void *, void *);
	int (*fcntl_cb)(void *, void *);
};

struct fake_perf_open_process {
	int mckfd_lock;
	struct fake_perf_open_fd *mckfd;
};

struct fake_perf_open_attr {
	unsigned int type;
	unsigned int size;
	unsigned long config;
	unsigned long sample_period;
	unsigned long sample_type;
	unsigned long read_format;
	int freq;
};

struct fake_perf_alloc_hw {
	struct fake_sync_child_atomic64 prev_count;
	unsigned long sample_period;
	unsigned long last_period;
	struct fake_sync_child_atomic64 period_left;
};

struct fake_perf_alloc_extra {
	unsigned long config;
	unsigned int reg;
	int idx;
};

struct fake_perf_alloc_event {
	unsigned char attr_copy[32];
	int poison;
	struct fake_list_head group_entry;
	struct fake_list_head sibling_list;
	unsigned long sample_freq;
	int nr_siblings;
	struct fake_sync_child_atomic64 count;
	unsigned long child_count_total;
	void *parent;
	int use_invariant_tsc;
	unsigned long hw_config;
	unsigned long hw_config_ext;
	struct fake_perf_alloc_extra extra_reg;
	struct fake_perf_alloc_hw hw;
};

struct fake_terminate_host_process {
	int nohost;
};

struct fake_terminate_host_thread {
	struct fake_terminate_host_process *proc;
	int refcount;
};

struct fake_wait_candidate_process {
	int pid;
	int status;
};

struct fake_wait_candidate_thread {
	struct fake_wait_candidate_process *proc;
	int tid;
	int status;
	int ptrace;
	int signal_flags;
	int report_detached;
	int ptrace_detached;
	int released;
};

struct fake_wait_zombie_offsets {
	size_t thread_ptrace_offset;
	size_t proc_pid_offset;
	size_t proc_ppid_parent_offset;
	size_t proc_parent_offset;
	size_t proc_status_offset;
	size_t proc_group_exit_status_offset;
	size_t proc_nowait_offset;
	size_t proc_update_lock_offset;
	size_t proc_children_lock_offset;
	size_t proc_threads_lock_offset;
	size_t proc_siblings_list_offset;
	size_t proc_children_list_offset;
	size_t proc_main_thread_offset;
	size_t proc_stime_offset;
	size_t proc_utime_offset;
	size_t proc_stime_children_offset;
	size_t proc_utime_children_offset;
	size_t proc_maxrss_offset;
	size_t proc_maxrss_children_offset;
};

struct fake_wait_zombie_thread {
	int ptrace;
	int ptrace_detached;
};

struct fake_wait_zombie_process {
	int pid;
	struct fake_wait_zombie_process *ppid_parent;
	struct fake_wait_zombie_process *parent;
	int status;
	int group_exit_status;
	int nowait;
	int update_lock;
	int children_lock;
	int threads_lock;
	int siblings_list;
	int children_list;
	struct fake_wait_zombie_thread *main_thread;
	struct timespec stime;
	struct timespec utime;
	struct timespec stime_children;
	struct timespec utime_children;
	long maxrss;
	long maxrss_children;
	int sibling_detached;
	int sibling_added;
	int released;
};

struct fake_wait_scan_offsets {
	size_t thread_proc_offset;
	size_t thread_tid_offset;
	size_t thread_status_offset;
	size_t thread_ptrace_offset;
	size_t thread_signal_flags_offset;
	size_t thread_termsig_offset;
	size_t thread_report_siblings_list_offset;
	size_t thread_siblings_list_offset;
	size_t proc_pid_offset;
	size_t proc_pgid_offset;
	size_t proc_status_offset;
	size_t proc_children_lock_offset;
	size_t proc_threads_lock_offset;
	size_t proc_children_list_offset;
	size_t proc_ptraced_children_list_offset;
	size_t proc_siblings_list_offset;
	size_t proc_ptraced_siblings_list_offset;
	size_t proc_report_threads_list_offset;
	size_t proc_threads_list_offset;
	size_t proc_main_thread_offset;
};

struct fake_wait_scan_process;

struct fake_wait_scan_thread {
	struct fake_wait_scan_process *proc;
	int tid;
	int status;
	int ptrace;
	int signal_flags;
	int termsig;
	struct fake_list_head report_siblings_list;
	struct fake_list_head siblings_list;
	int report_detached;
	int ptrace_detached;
	int released;
};

struct fake_wait_scan_process {
	int pid;
	int pgid;
	int status;
	int children_lock;
	int threads_lock;
	struct fake_list_head children_list;
	struct fake_list_head ptraced_children_list;
	struct fake_list_head siblings_list;
	struct fake_list_head ptraced_siblings_list;
	struct fake_list_head report_threads_list;
	struct fake_list_head threads_list;
	struct fake_wait_scan_thread *main_thread;
	struct fake_wait_scan_process *ppid_parent;
	struct fake_wait_scan_process *parent;
	int group_exit_status;
	int nowait;
	int update_lock;
	struct timespec stime;
	struct timespec utime;
	struct timespec stime_children;
	struct timespec utime_children;
	long maxrss;
	long maxrss_children;
	int released;
};

struct fake_ptrace_detach_offsets {
	size_t thread_proc_offset;
	size_t thread_termsig_offset;
	size_t thread_status_offset;
	size_t thread_tid_offset;
	size_t thread_report_proc_offset;
	size_t thread_report_siblings_list_offset;
	size_t thread_ptrace_offset;
	size_t thread_ptrace_saved_uctx_valid_offset;
	size_t thread_ptrace_debugreg_offset;
	size_t proc_pid_offset;
	size_t proc_status_offset;
	size_t proc_parent_offset;
	size_t proc_ppid_parent_offset;
	size_t proc_main_thread_offset;
	size_t proc_children_lock_offset;
	size_t proc_threads_lock_offset;
	size_t proc_children_list_offset;
	size_t proc_siblings_list_offset;
	size_t proc_ptraced_siblings_list_offset;
	size_t proc_report_threads_list_offset;
};

struct fake_ptrace_detach_process;

struct fake_ptrace_detach_thread {
	struct fake_ptrace_detach_process *proc;
	int termsig;
	int status;
	int tid;
	void *report_proc;
	struct fake_list_head report_siblings_list;
	int ptrace;
	int ptrace_saved_uctx_valid;
	void *ptrace_debugreg;
	int single_step_cleared;
	int exit_signal_calls;
	int wake_calls;
	int wake_states;
	int release_calls;
};

struct fake_ptrace_detach_process {
	int pid;
	int status;
	struct fake_ptrace_detach_process *parent;
	struct fake_ptrace_detach_process *ppid_parent;
	struct fake_ptrace_detach_thread *main_thread;
	int children_lock;
	int threads_lock;
	struct fake_list_head children_list;
	struct fake_list_head siblings_list;
	struct fake_list_head ptraced_siblings_list;
	struct fake_list_head report_threads_list;
	int finalized;
};

struct fake_ptrace_syscall_ops {
	int (*traceme_fn)(void);
	int (*wakeup_fn)(int, long, long);
	long (*getregs_fn)(int, long);
	long (*setregs_fn)(int, long);
	long (*getfpregs_fn)(int, long);
	long (*setfpregs_fn)(int, long);
	long (*peekuser_fn)(int, long, long);
	long (*pokeuser_fn)(int, long, long);
	long (*peektext_fn)(int, long, long);
	long (*poketext_fn)(int, long, long);
	int (*setoptions_fn)(int, int);
	int (*attach_fn)(int);
	int (*detach_fn)(int, int);
	long (*getsiginfo_fn)(int, void *);
	long (*setsiginfo_fn)(int, void *);
	long (*getregset_fn)(int, long, long);
	long (*setregset_fn)(int, long, long);
	long (*geteventmsg_fn)(int, long);
	long (*arch_fn)(long, int, long, long);
};

extern int ptrace_detach_thread_body_result(void *, int, void *, void *,
					    void *,
					    const struct fake_ptrace_detach_offsets *,
					    void (*)(void *, void *),
					    void (*)(void *, void *),
					    void (*)(void *),
					    int (*)(void *, unsigned long,
						     void *, void *, void *,
						     void *),
					    int (*)(void *, unsigned long,
						     void *, void *),
					    void *(*)(void *, unsigned long,
						       unsigned long,
						       unsigned long),
					    void (*)(void *),
					    void (*)(void *),
					    int (*)(void *, unsigned long,
						     int, int, unsigned long,
						     void *, void *, void *),
					    void (*)(void *),
					    long (*)(void *, int, int, int,
						      const void *, int),
					    void (*)(void *, int),
					    void (*)(void *),
					    void (*)(void *),
					    void *);
extern long ptrace_syscall_body_result(long, int, long, long,
				       const struct fake_ptrace_syscall_ops *);

struct fake_do_wait_process {
	int prefix;
	int pid;
	int waitpid_q;
	int suffix;
};

struct fake_do_wait_thread {
	int prefix;
	struct fake_do_wait_process *proc;
	int signal_pending;
	int suffix;
};

struct fake_do_wait_entry {
	int initialized;
	struct fake_do_wait_thread *thread;
	void *waitq;
	int prepared;
	int finished;
	int status;
};

#define FAKE_DO_WAIT_MAX_CALLS 8
#define FAKE_DO_WAIT_MAX_LOGS 16

static int fake_getresid_fail_after = -1;
static int fake_getresid_calls;
static int fake_stack_copy_from_fail;
static int fake_stack_copy_to_fail;
static int fake_stack_copy_from_calls;
static int fake_stack_copy_to_calls;
static int fake_waitid_copy_to_calls;
static size_t fake_waitid_copy_to_bytes;
static int fake_wait4_do_wait_calls;
static int fake_wait4_copy_to_calls;
static int fake_wait4_pid;
static int fake_wait4_options;
static int fake_wait4_rc;
static int fake_wait4_status;
static struct rusage fake_wait4_seen_usage;
static int fake_wait_reap_calls;
static void *fake_wait_reap_thread;
static int fake_wait_reap_options;
static int fake_wait_reap_clear_mask;
static int fake_wait_candidate_stopped_calls;
static int fake_wait_candidate_continued_calls;
static int fake_wait_candidate_unlock_calls;
static int fake_wait_candidate_report_detach_calls;
static int fake_wait_candidate_ptrace_detach_calls;
static int fake_wait_candidate_release_calls;
static int fake_wait_candidate_event_seq;
static int fake_wait_candidate_report_event;
static int fake_wait_candidate_unlock_event;
static int fake_wait_candidate_release_event;
static int fake_wait_candidate_stopped_rc;
static int fake_wait_candidate_continued_rc;
static void *fake_wait_candidate_stopped_thread;
static void *fake_wait_candidate_stopped_proc;
static void *fake_wait_candidate_stopped_child;
static unsigned long fake_wait_candidate_digest;
static int fake_wait_zombie_host_calls;
static int fake_wait_zombie_host_pid;
static int fake_wait_zombie_host_options;
static int fake_wait_zombie_host_rc;
static int fake_wait_zombie_lock_calls;
static int fake_wait_zombie_unlock_calls;
static int fake_wait_zombie_detach_calls;
static int fake_wait_zombie_add_tail_calls;
static int fake_wait_zombie_ptrace_detach_calls;
static int fake_wait_zombie_release_calls;
static int fake_wait_zombie_log_count;
static int fake_wait_zombie_event_seq;
static int fake_wait_zombie_parent_unlock_event;
static int fake_wait_zombie_ptrace_event;
static int fake_wait_zombie_release_event;
static struct fake_wait_zombie_process *fake_wait_zombie_active_parent;
static struct fake_wait_zombie_process *fake_wait_zombie_active_child;
static struct fake_wait_zombie_process *fake_wait_zombie_active_pid1;
static unsigned long fake_wait_zombie_digest;
static int fake_do_wait_proc_calls;
static int fake_do_wait_thread_calls;
static int fake_do_wait_init_calls;
static int fake_do_wait_prepare_calls;
static int fake_do_wait_finish_calls;
static int fake_do_wait_has_signal_calls;
static int fake_do_wait_schedule_calls;
static int fake_do_wait_log_count;
static int fake_do_wait_proc_rc[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_thread_rc[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_proc_empty[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_thread_empty[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_proc_status[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_thread_status[FAKE_DO_WAIT_MAX_CALLS];
static int fake_do_wait_log_events[FAKE_DO_WAIT_MAX_LOGS];
static int fake_do_wait_log_current[FAKE_DO_WAIT_MAX_LOGS];
static int fake_do_wait_log_wait_pid[FAKE_DO_WAIT_MAX_LOGS];
static unsigned long fake_do_wait_scan_digest;
static unsigned long fake_do_wait_log_digest;
static int fake_eventfd_send_calls;
static void *fake_eventfd_send_channel;
static int fake_eventfd_send_opt;
static int fake_eventfd_send_rc;
static struct fake_ikc_scd_packet fake_eventfd_send_packet;
static int fake_forward_sigmask_calls;
static unsigned long fake_forward_sigmask_value;
static int fake_do_sigaction_calls;
static int fake_do_sigaction_sig;
static int fake_do_sigaction_has_act;
static int fake_do_sigaction_has_oact;
static unsigned long fake_do_sigaction_seen_mask;
static int fake_do_sigaction_rc;
static struct fake_k_sigaction fake_do_sigaction_old;
static int fake_sigaction_body_lock_calls;
static int fake_sigaction_body_unlock_calls;
static int fake_sigaction_body_forward_calls;
static int fake_sigaction_body_forward_sig;
static unsigned long fake_sigaction_body_forward_mask;
static void *fake_sigaction_body_lock_ptr;
static void *fake_sigaction_body_unlock_ptr;
static void *fake_sigaction_body_lock_node;
static void *fake_sigaction_body_unlock_node;
static int fake_do_kill_calls;
static int fake_do_kill_pid;
static int fake_do_kill_sig;
static int fake_do_kill_rc;
static int fake_do_kill_thread_calls;
static void *fake_do_kill_thread_current;
static int fake_do_kill_thread_pid;
static int fake_do_kill_thread_tid;
static int fake_do_kill_thread_sig;
static int fake_do_kill_thread_ptracecont;
static int fake_do_kill_thread_si_signo;
static int fake_do_kill_thread_si_code;
static int fake_do_kill_thread_si_pid;
static int fake_do_kill_thread_si_status;
static long fake_do_kill_thread_si_utime;
static long fake_do_kill_thread_si_stime;
static long fake_do_kill_thread_rc;
static int fake_thread_exit_wake_calls;
static void *fake_thread_exit_wake_waitq;
static int fake_thread_exit_log_calls;
static int fake_thread_exit_log_sig;
static long fake_thread_exit_log_error;
static int fake_finalize_lock_calls;
static void *fake_finalize_lock_ptr;
static void *fake_finalize_lock_node;
static int fake_finalize_unlock_calls;
static void *fake_finalize_unlock_ptr;
static void *fake_finalize_unlock_node;
static int fake_finalize_release_calls;
static void *fake_finalize_release_proc;
static int fake_finalize_wakeup_log_calls;
static int fake_terminate_cmpxchg_calls;
static unsigned long *fake_terminate_cmpxchg_ptr;
static unsigned long fake_terminate_cmpxchg_old;
static unsigned long fake_terminate_cmpxchg_new;
static int fake_terminate_cmpxchg_force_mismatch;
static unsigned long fake_terminate_cmpxchg_mismatch_value;
static int fake_terminate_syscall_calls;
static struct fake_syscall_request *fake_terminate_syscall_req;
static int fake_terminate_syscall_cpu;
static long fake_terminate_syscall_rc;
static int fake_sync_child_read_calls;
static int fake_sync_child_read_last_counter;
static int fake_sync_child_read_counter_sum;
static unsigned long fake_sync_child_read_base;
static int fake_sync_child_set_calls;
static void *fake_sync_child_set_last_ptr;
static long fake_sync_child_set_last_value;
static int fake_perf_read_update_calls;
static void *fake_perf_read_update_event;
static int fake_perf_read_atomic_read_calls;
static void *fake_perf_read_atomic_read_ptr;
static int fake_perf_read_attr_calls;
static const void *fake_perf_read_attr_ptr;
static int fake_perf_read_attr_rc;
static int fake_perf_read_value_calls;
static void *fake_perf_read_value_last_event;
static int fake_perf_read_copy_calls;
static unsigned long fake_perf_read_copy_base;
static long fake_perf_read_copy_fail_call;
static size_t fake_perf_read_copy_last_bytes;
static unsigned long fake_perf_read_copy_last_offset;
static int fake_perf_read_group_dispatch_calls;
static int fake_perf_read_one_dispatch_calls;
static void *fake_perf_read_dispatch_event;
static unsigned long fake_perf_read_dispatch_format;
static unsigned long fake_perf_read_dispatch_buf;
static long fake_perf_read_group_dispatch_rc;
static long fake_perf_read_one_dispatch_rc;
static int fake_perf_counter_extra_calls;
static void *fake_perf_counter_extra_event;
static int fake_perf_counter_extra_rc;
static int fake_perf_counter_init_calls;
static int fake_perf_counter_init_counter;
static unsigned long fake_perf_counter_init_config;
static int fake_perf_counter_init_mode;
static int fake_perf_counter_init_rc;
static int fake_perf_counter_attr_calls;
static const void *fake_perf_counter_attr_ptr;
static int fake_perf_counter_attr_rc;
static int fake_perf_start_mask_check_calls;
static unsigned long fake_perf_start_mask_check_last;
static unsigned long fake_perf_start_mask_check_accept;
static int fake_perf_start_set_period_calls;
static void *fake_perf_start_set_period_event;
static int fake_perf_start_counter_set_calls;
static void *fake_perf_start_counter_set_event;
static int fake_perf_start_counter_set_rc;
static int fake_perf_start_hw_start_calls;
static unsigned long fake_perf_start_hw_start_mask;
static int fake_perf_start_hw_start_rc;
static int fake_perf_stop_hw_calls;
static unsigned long fake_perf_stop_hw_mask;
static int fake_perf_stop_hw_flags;
static int fake_perf_stop_hw_rc;
static int fake_perf_ioctl_start_calls;
static int fake_perf_ioctl_stop_calls;
static int fake_perf_ioctl_reset_calls;
static void *fake_perf_ioctl_last_event;
static int fake_perf_ioctl_find_calls;
static int fake_perf_ioctl_find_pid;
static void *fake_perf_ioctl_find_lock;
static void *fake_perf_ioctl_find_result;
static int fake_perf_ioctl_unlock_calls;
static void *fake_perf_ioctl_unlock_proc;
static void *fake_perf_ioctl_unlock_lock;
static int fake_perf_close_free_calls;
static void *fake_perf_close_free_ptr;
static int fake_perf_fcntl_forward_calls;
static int fake_perf_fcntl_forward_nr;
static void *fake_perf_fcntl_forward_ctx;
static long fake_perf_fcntl_forward_rc;
static int fake_perf_mmap_calls;
static unsigned long fake_perf_mmap_addr;
static size_t fake_perf_mmap_len;
static int fake_perf_mmap_prot;
static int fake_perf_mmap_flags;
static int fake_perf_mmap_fd;
static long fake_perf_mmap_off;
static int fake_perf_mmap_vrf0;
static void *fake_perf_mmap_private_data;
static long fake_perf_mmap_rc;
static int fake_perf_open_lock_calls;
static void *fake_perf_open_lock_arg;
static int fake_perf_open_unlock_calls;
static void *fake_perf_open_unlock_arg;
static long fake_perf_open_unlock_flags;
static int fake_perf_open_counter_alloc_calls;
static void *fake_perf_open_counter_alloc_thread;
static void *fake_perf_open_counter_alloc_event;
static int fake_perf_open_counter_alloc_rc;
static int fake_perf_open_event_alloc_calls;
static void *fake_perf_open_event_alloc_attr;
static void *fake_perf_open_event_alloc_result;
static int fake_perf_open_event_alloc_rc;
static int fake_perf_open_copy_calls;
static unsigned long fake_perf_open_copy_src;
static size_t fake_perf_open_copy_bytes;
static long fake_perf_open_copy_rc;
static int fake_perf_open_attr_freq_calls;
static int fake_perf_open_syscall_calls;
static struct fake_syscall_request *fake_perf_open_syscall_req;
static int fake_perf_open_syscall_cpu;
static long fake_perf_open_syscall_rc;
static int fake_perf_alloc_hw_map_calls;
static int fake_perf_alloc_cache_map_calls;
static int fake_perf_alloc_cache_extra_calls;
static int fake_perf_alloc_raw_map_calls;
static int fake_perf_alloc_validate_calls;
static unsigned long fake_perf_alloc_validate_last;
static unsigned long fake_perf_alloc_validate_reject;
static int fake_perf_alloc_extra_id_calls;
static unsigned long fake_perf_alloc_extra_id_config;
static unsigned long fake_perf_alloc_extra_id_ext;
static int fake_perf_alloc_extra_id_rc;
static int fake_perf_alloc_msr_calls;
static int fake_perf_alloc_idx_calls;
static int fake_perf_alloc_hw_init_calls;
static void *fake_perf_alloc_hw_init_event;
static int fake_perf_alloc_hw_init_rc;
static int fake_perf_alloc_alloc_calls;
static size_t fake_perf_alloc_alloc_size;
static unsigned long fake_perf_alloc_alloc_flags;
static void *fake_perf_alloc_alloc_result;
static int fake_perf_alloc_free_calls;
static void *fake_perf_alloc_free_ptr;
static int fake_process_cleanup_find_calls;
static int fake_process_cleanup_find_pid;
static void *fake_process_cleanup_find_lock;
static void *fake_process_cleanup_find_result;
static int fake_process_cleanup_unlock_calls;
static void *fake_process_cleanup_unlock_proc;
static void *fake_process_cleanup_unlock_lock;
static int fake_process_cleanup_cleanup_calls;
static void *fake_process_cleanup_cleanup_proc;
static int fake_process_cleanup_cleanup_fd;
static int fake_process_cleanup_cleanup_first_fd;
static int fake_process_cleanup_cleanup_last_fd;
static int fake_process_cleanup_cleanup_fd_sum;
static long fake_process_cleanup_cleanup_rc;
static int fake_process_cleanup_missing_log_calls;
static int fake_process_cleanup_missing_log_pid;
static int fake_process_cleanup_sequence;
static int fake_process_cleanup_cleanup_sequence;
static int fake_process_cleanup_unlock_sequence;
static int fake_terminate_host_find_calls;
static int fake_terminate_host_find_pid;
static void *fake_terminate_host_find_lock;
static void *fake_terminate_host_find_result;
static int fake_terminate_host_unlock_calls;
static void *fake_terminate_host_unlock_proc;
static void *fake_terminate_host_unlock_lock;
static int fake_terminate_host_ref_set_calls;
static void *fake_terminate_host_ref_set_ptr;
static int fake_terminate_host_ref_set_value;
static int fake_terminate_host_release_thread_calls;
static void *fake_terminate_host_release_thread_ptr;
static int fake_terminate_host_release_process_calls;
static void *fake_terminate_host_release_process_ptr;
static int fake_refresh_uid_calls;
static int fake_refresh_gid_calls;
static int fake_getcred_calls;
static int *fake_getcred_buf;
static int fake_getcred_values[8];
static int fake_processor_id_calls;
static int fake_processor_id_value;
static int fake_virt_to_phys_calls;
static void *fake_virt_to_phys_ptr;
static unsigned long fake_virt_to_phys_value;
static int fake_gettime_calls;
static unsigned long fake_do_futex_digest;
static int fake_do_futex_syscall_time_calls;
static int fake_do_futex_syscall_nr;
static int fake_do_futex_syscall_clock;
static int fake_do_futex_syscall_fail;
static int fake_do_futex_local_time_calls;
static int fake_do_futex_linux_time_calls;
static int fake_do_futex_linux_clock;
static int fake_do_futex_linux_fail;
static int fake_do_futex_ns_per_tsc_calls;
static int fake_do_futex_dispatch_calls;
static int fake_do_futex_log_calls;
static unsigned long fake_brk_digest;
static int fake_brk_flush_calls;
static int fake_brk_lock_calls;
static int fake_brk_unlock_calls;
static int fake_brk_extend_calls;
static unsigned long fake_brk_extend_result;
static unsigned long fake_brk_extend_old;
static unsigned long fake_brk_extend_address;
static unsigned long fake_brk_extend_vrflag;
static int fake_brk_log_calls;
static unsigned long fake_munmap_digest;
static int fake_munmap_lock_calls;
static int fake_munmap_unlock_calls;
static int fake_munmap_do_calls;
static int fake_munmap_do_rc;
static unsigned long fake_munmap_do_addr;
static size_t fake_munmap_do_len;
static int fake_munmap_do_holding;
static int fake_munmap_log_calls;
static unsigned long fake_do_munmap_digest;
static int fake_do_munmap_begin_calls;
static int fake_do_munmap_finish_calls;
static int fake_do_munmap_remove_calls;
static int fake_do_munmap_remove_rc;
static int fake_do_munmap_ro_freed;
static unsigned long fake_do_munmap_remove_start;
static unsigned long fake_do_munmap_remove_end;
static int fake_do_munmap_clear_calls;
static unsigned long fake_do_munmap_clear_addr;
static size_t fake_do_munmap_clear_len;
static int fake_do_munmap_clear_holding;
static int fake_do_munmap_sethost_calls;
static int fake_do_munmap_sethost_rc;
static unsigned long fake_do_munmap_sethost_addr;
static size_t fake_do_munmap_sethost_len;
static int fake_do_munmap_sethost_prot;
static int fake_do_munmap_sethost_holding;
static int fake_do_munmap_log_calls;
static unsigned long fake_clear_host_digest;
static int fake_clear_host_forward_calls;
static long fake_clear_host_forward_rc;
static int fake_clear_host_forward_nr;
static unsigned long fake_clear_host_forward_arg0;
static unsigned long fake_clear_host_forward_arg1;
static unsigned long fake_clear_host_forward_arg2;
static int fake_clear_host_log_calls;
static long fake_clear_host_log_error;
static unsigned long fake_munmap_all_digest;
static struct fake_msync_range *fake_munmap_all_ranges;
static int fake_munmap_all_range_count;
static int fake_munmap_all_lock_calls;
static int fake_munmap_all_unlock_calls;
static int fake_munmap_all_lookup_calls;
static int fake_munmap_all_next_calls;
static int fake_munmap_all_do_calls;
static int fake_munmap_all_do_fail_index;
static unsigned long fake_munmap_all_last_addr;
static size_t fake_munmap_all_last_size;
static int fake_munmap_all_free_calls;
static int fake_munmap_all_log_calls;
static unsigned long fake_shmdt_digest;
static struct fake_msync_range *fake_shmdt_ranges;
static int fake_shmdt_range_count;
static int fake_shmdt_lock_calls;
static int fake_shmdt_unlock_calls;
static int fake_shmdt_lookup_calls;
static int fake_shmdt_munmap_calls;
static int fake_shmdt_munmap_rc;
static unsigned long fake_shmdt_munmap_addr;
static size_t fake_shmdt_munmap_len;
static int fake_shmdt_munmap_holding;
static int fake_shmdt_log_calls;
static unsigned long fake_shmat_digest;
static struct fake_shmat_obj *fake_shmat_obj;
static int fake_shmat_lookup_rc;
static int fake_shmat_list_lock_calls;
static int fake_shmat_list_unlock_calls;
static int fake_shmat_lookup_calls;
static int fake_shmat_unref_calls;
static int fake_shmat_range_lock_calls;
static int fake_shmat_range_unlock_calls;
static int fake_shmat_lookup_range_calls;
static int fake_shmat_range_busy;
static int fake_shmat_search_calls;
static int fake_shmat_search_rc;
static unsigned long fake_shmat_search_addr;
static int fake_shmat_sethost_calls;
static int fake_shmat_sethost_rc;
static unsigned long fake_shmat_sethost_start;
static size_t fake_shmat_sethost_len;
static int fake_shmat_sethost_prot;
static int fake_shmat_add_calls;
static int fake_shmat_add_rc;
static unsigned long fake_shmat_add_start;
static unsigned long fake_shmat_add_end;
static unsigned long fake_shmat_add_flags;
static int fake_shmat_add_pgshift;
static int fake_shmat_log_calls;
static unsigned long fake_shmctl_digest;
static struct fake_shmctl_obj *fake_shmctl_obj;
static struct fake_shmctl_obj *fake_shmctl_index_obj;
static struct fake_shmlock_user *fake_shmctl_user;
static int fake_shmctl_lookup_rc;
static int fake_shmctl_lookup_index_rc;
static int fake_shmctl_list_lock_calls;
static int fake_shmctl_list_unlock_calls;
static int fake_shmctl_lookup_calls;
static int fake_shmctl_lookup_index_calls;
static int fake_shmctl_unref_calls;
static int fake_shmctl_copy_from_calls;
static int fake_shmctl_copy_to_calls;
static long fake_shmctl_copy_from_rc;
static long fake_shmctl_copy_to_rc;
static int fake_shmctl_max_index;
static int fake_shmctl_max_index_calls;
static int fake_shmctl_users_lock_calls;
static int fake_shmctl_users_unlock_calls;
static int fake_shmctl_user_get_calls;
static int fake_shmctl_user_get_rc;
static int fake_shmctl_user_free_calls;
static int fake_shmctl_refcnt_calls;
static int fake_shmctl_refcnt_value;
static int fake_shmctl_log_calls;
static int fake_shmctl_last_log_event;
static unsigned long fake_search_free_digest;
static struct fake_msync_range *fake_search_free_ranges;
static int fake_search_free_range_count;
static int fake_search_free_lookup_calls;
static int fake_search_free_log_calls;
static unsigned long fake_msync_digest;
static struct fake_msync_range *fake_msync_ranges;
static int fake_msync_range_count;
static int fake_msync_lock_calls;
static int fake_msync_unlock_calls;
static int fake_msync_lookup_calls;
static int fake_msync_next_calls;
static int fake_msync_has_pager_calls;
static int fake_msync_sync_calls;
static int fake_msync_invalidate_calls;
static int fake_msync_sync_rc;
static int fake_msync_invalidate_rc;
static unsigned long fake_msync_last_sync_start;
static unsigned long fake_msync_last_sync_end;
static unsigned long fake_msync_last_invalidate_start;
static unsigned long fake_msync_last_invalidate_end;
static int fake_msync_log_calls;
static unsigned long fake_memlock_digest;
static struct fake_msync_range *fake_memlock_ranges;
static int fake_memlock_range_count;
static int fake_memlock_lock_calls;
static int fake_memlock_unlock_calls;
static int fake_memlock_lookup_calls;
static int fake_memlock_next_calls;
static int fake_memlock_split_calls;
static int fake_memlock_join_calls;
static int fake_memlock_populate_calls;
static int fake_memlock_populate_rc;
static unsigned long fake_memlock_populate_start;
static size_t fake_memlock_populate_len;
static int fake_memlock_log_calls;
static unsigned long fake_mprotect_digest;
static struct fake_msync_range *fake_mprotect_ranges;
static int fake_mprotect_range_count;
static int fake_mprotect_lock_calls;
static int fake_mprotect_unlock_calls;
static int fake_mprotect_lookup_calls;
static int fake_mprotect_next_calls;
static int fake_mprotect_split_calls;
static int fake_mprotect_join_calls;
static int fake_mprotect_change_calls;
static int fake_mprotect_sethost_calls;
static int fake_mprotect_flush_nfo_calls;
static int fake_mprotect_flush_tlb_calls;
static int fake_mprotect_log_calls;
static int fake_mprotect_split_rc;
static int fake_mprotect_join_rc;
static int fake_mprotect_change_rc;
static int fake_mprotect_sethost_rc;
static unsigned long fake_mprotect_sethost_start;
static size_t fake_mprotect_sethost_len;
static int fake_mprotect_sethost_prot;
static unsigned long fake_remap_file_pages_digest;
static struct fake_msync_range *fake_remap_file_pages_ranges;
static int fake_remap_file_pages_range_count;
static int fake_remap_file_pages_lock_calls;
static int fake_remap_file_pages_unlock_calls;
static int fake_remap_file_pages_lookup_calls;
static int fake_remap_file_pages_callable_calls;
static int fake_remap_file_pages_remap_calls;
static int fake_remap_file_pages_clear_calls;
static int fake_remap_file_pages_populate_calls;
static int fake_remap_file_pages_flush_calls;
static int fake_remap_file_pages_log_calls;
static int fake_remap_file_pages_remap_rc;
static int fake_remap_file_pages_populate_rc;
static unsigned long fake_remap_file_pages_last_start;
static unsigned long fake_remap_file_pages_last_end;
static long fake_remap_file_pages_last_off;
static unsigned long fake_remap_file_pages_clear_start;
static size_t fake_remap_file_pages_clear_size;
static unsigned long fake_mremap_digest;
static struct fake_mremap_range *fake_mremap_ranges;
static int fake_mremap_range_count;
static int fake_mremap_lock_calls;
static int fake_mremap_unlock_calls;
static int fake_mremap_lookup_calls;
static int fake_mremap_extend_calls;
static int fake_mremap_flush_calls;
static int fake_mremap_search_calls;
static int fake_mremap_munmap_calls;
static int fake_mremap_memobj_ref_calls;
static int fake_mremap_memobj_unref_calls;
static int fake_mremap_add_calls;
static int fake_mremap_pte_lock_calls;
static int fake_mremap_pte_unlock_calls;
static int fake_mremap_split_calls;
static int fake_mremap_move_calls;
static int fake_mremap_populate_calls;
static int fake_mremap_log_calls;
static int fake_mremap_extend_rc;
static int fake_mremap_search_rc;
static int fake_mremap_munmap_rc;
static int fake_mremap_add_rc;
static int fake_mremap_split_rc;
static int fake_mremap_move_rc;
static int fake_mremap_populate_rc;
static unsigned long fake_mremap_search_addr;
static unsigned long fake_mremap_add_start;
static unsigned long fake_mremap_add_end;
static long fake_mremap_add_pgshift;
static unsigned long fake_mremap_add_flags;
static void *fake_mremap_add_memobj;
static unsigned long fake_mremap_add_objoff;
static unsigned long fake_mremap_munmap_addr;
static size_t fake_mremap_munmap_len;
static int fake_mremap_munmap_holding;
static unsigned long fake_mremap_move_oldstart;
static unsigned long fake_mremap_move_newstart;
static size_t fake_mremap_move_size;
static unsigned long fake_mremap_populate_start;
static size_t fake_mremap_populate_len;
static unsigned long fake_mincore_digest;
static struct fake_mincore_range *fake_mincore_ranges;
static int fake_mincore_range_count;
static unsigned long fake_mincore_pte_values[8];
static int fake_mincore_range_lock_calls;
static int fake_mincore_range_unlock_calls;
static int fake_mincore_pte_lock_calls;
static int fake_mincore_pte_unlock_calls;
static int fake_mincore_lookup_calls;
static int fake_mincore_pte_lookup_calls;
static int fake_mincore_pte_present_calls;
static int fake_mincore_memobj_lookup_calls;
static int fake_mincore_copy_calls;
static int fake_mincore_copy_fail_at;
static unsigned char fake_mincore_vec[8];
static int fake_mincore_log_calls;
static int fake_syscall2_calls;
static int fake_syscall2_nr;
static unsigned long fake_syscall2_arg0;
static unsigned long fake_syscall2_arg1;
static long fake_syscall2_rc;
static int fake_generic_syscall_calls;
static struct fake_syscall_request *fake_generic_syscall_req;
static int fake_generic_syscall_cpu;
static long fake_generic_syscall_rc;
static int fake_syscall3_calls;
static int fake_syscall3_nr;
static unsigned long fake_syscall3_arg0;
static unsigned long fake_syscall3_arg1;
static unsigned long fake_syscall3_arg2;
static long fake_syscall3_rc;
static int fake_set_timer_calls;
static int fake_set_timer_runq_locked;
static int fake_exit_calls;
static int fake_exit_code;
static int fake_exit_group_log_calls;
static int fake_exit_group_log_pid;
static int fake_terminate_calls;
static int fake_terminate_status;
static int fake_terminate_group;
static int fake_sched_yield_lock_calls;
static int fake_sched_yield_unlock_calls;
static int fake_sched_yield_schedule_calls;
static long fake_sched_yield_irqstate;
static struct fake_cputime_thread *fake_cputime_by_cpu[8];
static int fake_cputime_lock_calls;
static int fake_cputime_unlock_calls;
static int fake_cputime_interrupt_calls;
static int fake_cputime_copy_calls;
static int fake_cputime_copy_fail;
static int fake_cputime_pause_calls;
static unsigned long fake_cputime_interrupt_digest;
static int fake_times_tsc_calls;
static int fake_times_jiffy_calls;
static int fake_times_add_calls;
static int fake_setpgid_find_calls;
static int fake_setpgid_unlock_calls;
static int fake_setpgid_lock_cookie;
static struct fake_syscall_process_ids *fake_setpgid_table[4];
static int fake_prlimit_calls;
static int fake_prlimit_pid;
static int fake_prlimit_resource;
static unsigned long fake_prlimit_new_addr;
static unsigned long fake_prlimit_old_addr;
static long fake_prlimit_rc;
static int fake_get_cpu_calls;
static int fake_mlock_log_calls;
static int fake_mlock_log_flags;
static int fake_mlock_log_error;
static int fake_getcpu_copy_calls;
static int fake_getcpu_copy_fail_after;
static long fake_getcpu_copy_error;
static int fake_getmem_copy_calls;
static int fake_getmem_copy_fail_after;
static unsigned long fake_getmem_copy_bytes;
static int fake_getmem_lookup_node_calls;
static unsigned long fake_getmem_lookup_node_addr;
static int fake_getmem_lookup_node_result;
static int fake_getmem_lock_calls;
static int fake_getmem_unlock_calls;
static void *fake_getmem_last_lock;
static int fake_getmem_lookup_range_calls;
static unsigned long fake_getmem_lookup_start;
static unsigned long fake_getmem_lookup_end;
static void *fake_getmem_lookup_range_result;
static int fake_getmem_policy_search_calls;
static unsigned long fake_getmem_policy_search_addr;
static void *fake_getmem_policy_search_result;
static int fake_getmem_log_calls;
static int fake_getmem_log_event;
static unsigned long fake_getmem_log_addr;
static int fake_getmem_log_value;
static int fake_mckfd_lock_calls;
static int fake_mckfd_unlock_calls;
static unsigned long fake_mckfd_unlock_irq;
static int fake_mckfd_read_calls;
static int fake_mckfd_mmap_calls;
static int fake_mckfd_ioctl_calls;
static int fake_mckfd_fcntl_calls;
static int fake_mckfd_close_calls;
static int fake_mckfd_free_calls;
static int fake_mckfd_tofu_ioctl_calls;
static int fake_mckfd_tofu_close_calls;
static int fake_mckfd_fd_sum;
static int fake_mckfd_ctx_matches;
static long fake_mckfd_read_rc;
static long fake_mckfd_mmap_rc;
static int fake_mckfd_ioctl_rc;
static int fake_mckfd_fcntl_rc;
static int fake_mckfd_close_rc;
static int fake_mckfd_tofu_handled;
static long fake_mckfd_tofu_rc;
static unsigned long fake_mckfd_tofu_cmd;
static unsigned long fake_mckfd_tofu_arg;
static unsigned long fake_rdtsc_value;
static unsigned long fake_rdtsc_step;
static unsigned long fake_ns_per_tsc_value;
static int fake_settimeofday_lock_calls;
static int fake_settimeofday_unlock_calls;
static long fake_settimeofday_version;
static int fake_settimeofday_atomic_read_calls;
static int fake_settimeofday_atomic_inc_calls;
static int fake_settimeofday_wmb_calls;
static int fake_settimeofday_panic_calls;
static int fake_settimeofday_log_calls;
static int fake_settimeofday_origin_logs;
static long fake_settimeofday_origin_sec;
static long fake_settimeofday_origin_nsec;
static long fake_settimeofday_exit_error;
static unsigned long fake_settimeofday_digest;
static int fake_has_sigpending_after;
static int fake_has_sigpending_calls;
static int fake_cpu_pause_calls;
static int fake_forward_context_calls;
static int fake_forward_context_nr;
static void *fake_forward_context_ctx;
static unsigned long fake_forward_context_seen_mask;
static long fake_forward_context_rc;
static struct fake_sigmask_thread *fake_forward_context_thread;
static int fake_pending_mask_calls;
static void *fake_pending_mask_thread;
static unsigned long fake_pending_mask_value;
static int fake_signalfd_create_calls;
static int fake_signalfd_create_nr;
static int fake_signalfd_create_flags;
static long fake_signalfd_create_rc;
static int fake_signalfd_publish_calls;
static void *fake_signalfd_publish_thread;
static int fake_signalfd_publish_fd;
static unsigned long fake_signalfd_publish_mask;
static int fake_signalfd_publish_create;
static long fake_signalfd_publish_rc;
static int fake_sigsuspend_calls;
static void *fake_sigsuspend_thread;
static void *fake_sigsuspend_set;
static long fake_sigsuspend_rc;
static int fake_process_vm_rw_calls;
static int fake_process_vm_rw_pid;
static const void *fake_process_vm_rw_local;
static const void *fake_process_vm_rw_remote;
static unsigned long fake_process_vm_rw_liovcnt;
static unsigned long fake_process_vm_rw_riovcnt;
static unsigned long fake_process_vm_rw_flags;
static int fake_process_vm_rw_op;
static int fake_process_vm_rw_rc;
static struct fake_process_vm_rw_range fake_arch_pvm_range;
static struct fake_process_vm_rw_vm *fake_arch_pvm_local_vm;
static struct fake_process_vm_rw_vm *fake_arch_pvm_remote_vm;
static struct fake_process_vm_rw_proc *fake_arch_pvm_remote_proc;
static int fake_arch_pvm_lock_calls;
static int fake_arch_pvm_unlock_calls;
static int fake_arch_pvm_lookup_calls;
static int fake_arch_pvm_lookup_fail_call;
static unsigned long fake_arch_pvm_lookup_flags[16];
static int fake_arch_pvm_find_calls;
static int fake_arch_pvm_find_pid;
static void *fake_arch_pvm_find_lock;
static int fake_arch_pvm_find_missing;
static int fake_arch_pvm_process_unlock_calls;
static int fake_arch_pvm_update_lock_calls;
static int fake_arch_pvm_update_unlock_calls;
static int fake_arch_pvm_hold_calls;
static int fake_arch_pvm_release_calls;
static int fake_arch_pvm_vtop_calls;
static int fake_arch_pvm_vtop_fail_count;
static unsigned long fake_arch_pvm_vtop_last_virt;
static int fake_arch_pvm_fault_calls;
static int fake_arch_pvm_fault_fail;
static unsigned long fake_arch_pvm_fault_last_addr;
static unsigned long fake_arch_pvm_fault_last_reason;
static int fake_arch_pvm_memcpy_calls;
static size_t fake_arch_pvm_memcpy_bytes;
static int fake_arch_pvm_log_calls;
static unsigned long fake_arch_pvm_remote_base;
static unsigned char *fake_arch_pvm_remote_storage;
static int fake_arch_prctl_cpu;
static int fake_arch_prctl_set_calls;
static int fake_arch_prctl_set_type;
static unsigned long fake_arch_prctl_set_value;
static int fake_arch_prctl_set_rc;
static int fake_arch_prctl_get_calls;
static int fake_arch_prctl_get_type;
static unsigned long *fake_arch_prctl_get_addr;
static int fake_arch_prctl_get_rc;
static int fake_arch_prctl_log_calls;
static int fake_arch_prctl_log_event;
static int fake_arch_prctl_log_cpu;
static unsigned long fake_arch_prctl_log_value;
static int fake_arch_clone_sequence;
static int fake_arch_clone_lock_calls;
static int fake_arch_clone_unlock_calls;
static int fake_arch_clone_fork_calls;
static int fake_arch_clone_lock_seq;
static int fake_arch_clone_fork_seq;
static int fake_arch_clone_unlock_seq;
static void *fake_arch_clone_lock_ptr;
static void *fake_arch_clone_unlock_ptr;
static void *fake_arch_clone_lock_node;
static void *fake_arch_clone_unlock_node;
static int fake_arch_clone_fork_flags;
static unsigned long fake_arch_clone_fork_args[6];
static unsigned long fake_arch_clone_fork_rc;
static int fake_rt_sigreturn_copy_calls;
static int fake_rt_sigreturn_copy_fail_at;
static unsigned long fake_rt_sigreturn_last_src;
static size_t fake_rt_sigreturn_last_bytes;
static void *fake_rt_sigreturn_last_dst;
static int fake_rt_sigreturn_syscall_calls;
static int fake_rt_sigreturn_syscall_num;
static void *fake_rt_sigreturn_syscall_regs;
static long fake_rt_sigreturn_syscall_rc;
static int fake_rt_sigreturn_set_signal_calls;
static int fake_rt_sigreturn_set_signal_sig;
static void *fake_rt_sigreturn_set_signal_regs;
static int fake_rt_sigreturn_set_signal_code;
static int fake_rt_sigreturn_resched_calls;
static int fake_rt_sigreturn_check_signal_calls;
static int fake_rt_sigreturn_check_signal_signum;
static void *fake_rt_sigreturn_check_signal_regs;
static int fake_rt_sigreturn_check_signal_num;
static unsigned char fake_rt_sigreturn_alloc_area[192];
static void *fake_rt_sigreturn_alloc_result;
static size_t fake_rt_sigreturn_alloc_size;
static unsigned long fake_rt_sigreturn_alloc_flags;
static int fake_rt_sigreturn_alloc_calls;
static void *fake_rt_sigreturn_free_ptr;
static int fake_rt_sigreturn_free_calls;
static void *fake_rt_sigreturn_xrstor_ptr;
static int fake_rt_sigreturn_xrstor_calls;
static int fake_arch_time_copy_calls;
static unsigned long fake_arch_time_copy_dst;
static size_t fake_arch_time_copy_bytes;
static long fake_arch_time_copy_value;
static int fake_arch_time_copy_fail;
static int fake_arch_shmget_default_shift_calls;
static int fake_arch_shmget_default_shift;
static int fake_arch_shmget_calls;
static long fake_arch_shmget_key;
static size_t fake_arch_shmget_size;
static int fake_arch_shmget_flags;
static int fake_arch_shmget_rc;
static int fake_arch_shmget_log_calls;
static int fake_arch_shmget_log_events[4];
static long fake_arch_shmget_log_key[4];
static size_t fake_arch_shmget_log_size[4];
static int fake_arch_shmget_log_flags[4];
static int fake_arch_shmget_log_error[4];
static int fake_arch_shmget_log_shmid[4];
static int fake_arch_mmap_default_shift_calls;
static int fake_arch_mmap_default_shift;
static int fake_arch_mmap_overmap_calls;
static size_t fake_arch_mmap_overmap_len;
static int fake_arch_mmap_overmap_shift;
static int fake_arch_mmap_overmap_rc;
static int fake_do_mmap_smaller_page_calls;
static size_t fake_do_mmap_smaller_page_size;
static int fake_do_mmap_smaller_page_p2align;
static int fake_do_mmap_smaller_page_rc;
static int fake_arch_mmap_calls;
static unsigned long fake_arch_mmap_addr;
static size_t fake_arch_mmap_len;
static int fake_arch_mmap_prot;
static int fake_arch_mmap_flags;
static int fake_arch_mmap_fd;
static long fake_arch_mmap_off;
static int fake_arch_mmap_vrf0;
static void *fake_arch_mmap_private_data;
static long fake_arch_mmap_rc;
static int fake_arch_mmap_log_calls;
static int fake_arch_mmap_log_events[8];
static unsigned long fake_arch_mmap_log_addr0[8];
static size_t fake_arch_mmap_log_len0[8];
static int fake_arch_mmap_log_flags0[8];
static int fake_arch_mmap_log_error[8];
static unsigned long fake_arch_mmap_log_result[8];
static int fake_arch_mmap_log_extra[8];
static int fake_arch_vdso_get_info_calls;
static int fake_arch_vdso_get_info_rc;
static int fake_arch_vdso_map_global_calls;
static int fake_arch_vdso_map_global_rc;
static int fake_arch_vdso_setup_log_calls;
static int fake_arch_vdso_setup_log_events[8];
static int fake_arch_vdso_setup_log_errors[8];
static int fake_arch_vdso_add_range_calls;
static unsigned long fake_arch_vdso_add_start[4];
static unsigned long fake_arch_vdso_add_end[4];
static unsigned long fake_arch_vdso_add_flags[4];
static int fake_arch_vdso_add_fail_call;
static int fake_arch_vdso_add_rc;
static int fake_arch_vdso_set_range_calls;
static void *fake_arch_vdso_set_pt[8];
static unsigned long fake_arch_vdso_set_start[8];
static unsigned long fake_arch_vdso_set_end[8];
static unsigned long fake_arch_vdso_set_phys[8];
static unsigned long fake_arch_vdso_set_attr[8];
static void *fake_arch_vdso_set_range_token[8];
static int fake_arch_vdso_set_fail_call;
static int fake_arch_vdso_set_rc;
static int fake_arch_vdso_map_log_calls;
static int fake_arch_vdso_map_log_events[8];
static int fake_arch_vdso_map_log_errors[8];
static unsigned long fake_arch_vdso_map_log_a[8];
static unsigned long fake_arch_vdso_map_log_b[8];
static unsigned long fake_arch_vdso_map_log_c[8];
static unsigned long fake_arch_vdso_map_log_d[8];
static int fake_arch_vdso_map_log_pages[8];
static int fake_move_alloc_calls;
static size_t fake_move_alloc_sizes[8];
static unsigned long fake_move_alloc_flags[8];
static void *fake_move_alloc_results[8];
static int fake_move_alloc_fail_at;
static int fake_move_free_calls;
static void *fake_move_freed[8];
static int fake_move_verify_calls;
static unsigned long fake_move_verify_addr[8];
static size_t fake_move_verify_bytes[8];
static int fake_move_verify_fail_at;
static int fake_move_copy_from_calls;
static int fake_move_copy_to_calls;
static int fake_move_copy_to_rc;
static int fake_move_nr_nodes_value;
static int fake_move_lock_calls;
static int fake_move_unlock_calls;
static void *fake_move_last_lock;
static int fake_move_smp_calls;
static int fake_move_smp_rc;
static void *fake_move_smp_cpu_set;
static void *fake_move_smp_req;
static int fake_move_handler_calls;
static int fake_move_log_calls;
static int fake_move_log_events[8];
static unsigned long fake_move_log_values[8];
static int fake_util_thread_calls;
static void *fake_util_thread_arg;
static long fake_util_thread_rc;
static int fake_util_alloc_calls;
static size_t fake_util_alloc_size;
static unsigned long fake_util_alloc_flags;
static void *fake_util_alloc_result;
static int fake_util_free_calls;
static void *fake_util_freed[4];
static int fake_execveat_calls;
static void *fake_execveat_ctx;
static int fake_execveat_dirfd;
static const void *fake_execveat_filename;
static void **fake_execveat_argv;
static void **fake_execveat_envp;
static int fake_execveat_flags;
static int fake_execveat_rc;
static int fake_swapout_pageout_calls;
static const void *fake_swapout_pageout_filename;
static void *fake_swapout_pageout_workarea;
static size_t fake_swapout_pageout_size;
static int fake_swapout_pageout_flag;
static int fake_swapout_pageout_rc;
static int fake_swapout_pagein_calls;
static int fake_swapout_pagein_flag;
static int fake_swapout_pagein_rc;
static int fake_strlen_calls;
static long fake_strlen_rc;
static int fake_open_special_calls;
static const void *fake_open_special_pathname;
static int fake_open_special_flags;
static void *fake_open_special_ctx;
static long fake_open_special_rc;

static void mix(unsigned long *digest, unsigned long value);
static void mix_signed(unsigned long *digest, long value);
static void require(int condition);

static void
reset_fake_eventfd_send(void)
{
	memset(&fake_eventfd_send_packet, 0, sizeof(fake_eventfd_send_packet));
	fake_eventfd_send_calls = 0;
	fake_eventfd_send_channel = NULL;
	fake_eventfd_send_opt = -1;
	fake_eventfd_send_rc = 0;
}

static int
fake_eventfd_send(void *channel, void *packet, int opt)
{
	fake_eventfd_send_calls++;
	fake_eventfd_send_channel = channel;
	fake_eventfd_send_opt = opt;
	memcpy(&fake_eventfd_send_packet, packet,
			sizeof(fake_eventfd_send_packet));
	return fake_eventfd_send_rc;
}

static long
fake_copy_int_to_user(unsigned long dst_addr, const int *src)
{
	int *dst = (int *)(uintptr_t)dst_addr;

	if (fake_getresid_fail_after >= 0 &&
			fake_getresid_calls >= fake_getresid_fail_after) {
		fake_getresid_calls++;
		return -1;
	}

	*dst = *src;
	fake_getresid_calls++;
	return 0;
}

static long
fake_copy_stack_from_user(void *dst, unsigned long src_addr, size_t bytes)
{
	fake_stack_copy_from_calls++;
	if (fake_stack_copy_from_fail)
		return -1;
	memcpy(dst, (const void *)(uintptr_t)src_addr, bytes);
	return 0;
}

static long
fake_copy_stack_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_stack_copy_to_calls++;
	if (fake_stack_copy_to_fail)
		return -1;
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static long
fake_waitid_copy_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_waitid_copy_to_calls++;
	fake_waitid_copy_to_bytes = bytes;
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static int
fake_wait4_do_wait(int pid, int *status, int options, struct rusage *usage)
{
	fake_wait4_do_wait_calls++;
	fake_wait4_pid = pid;
	fake_wait4_options = options;
	fake_wait4_seen_usage = *usage;
	*status = fake_wait4_status;
	usage->ru_utime.tv_sec = 1;
	usage->ru_utime.tv_usec = 2345;
	usage->ru_stime.tv_sec = 6;
	usage->ru_stime.tv_usec = 7890;
	usage->ru_maxrss = 42;
	usage->ru_nvcsw = 7;
	return fake_wait4_rc;
}

static long
fake_wait4_copy_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_wait4_copy_to_calls++;
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static int
fake_wait_signal_flags_reap(void *thread, unsigned long signal_flags_offset,
			    int options, int clear_mask)
{
	int *signal_flags;

	fake_wait_reap_calls++;
	fake_wait_reap_thread = thread;
	fake_wait_reap_options = options;
	fake_wait_reap_clear_mask = clear_mask;
	if (!thread)
		return 0;

	signal_flags = (int *)((char *)thread + signal_flags_offset);
	if (!(options & WNOWAIT))
		*signal_flags &= ~clear_mask;
	return *signal_flags;
}

static int
fake_wait_exit_status_reap(void *object, unsigned long exit_status_offset,
			   int options)
{
	int *exit_status;

	fake_wait_reap_calls++;
	fake_wait_reap_thread = object;
	fake_wait_reap_options = options;
	fake_wait_reap_clear_mask = 0;
	if (!object)
		return 0;

	exit_status = (int *)((char *)object + exit_status_offset);
	if (!(options & WNOWAIT))
		*exit_status = 0;
	return *exit_status;
}

static void
fake_wait_candidate_reset(void)
{
	fake_wait_candidate_stopped_calls = 0;
	fake_wait_candidate_continued_calls = 0;
	fake_wait_candidate_unlock_calls = 0;
	fake_wait_candidate_report_detach_calls = 0;
	fake_wait_candidate_ptrace_detach_calls = 0;
	fake_wait_candidate_release_calls = 0;
	fake_wait_candidate_event_seq = 0;
	fake_wait_candidate_report_event = 0;
	fake_wait_candidate_unlock_event = 0;
	fake_wait_candidate_release_event = 0;
	fake_wait_candidate_stopped_rc = 0;
	fake_wait_candidate_continued_rc = 0;
	fake_wait_candidate_stopped_thread = NULL;
	fake_wait_candidate_stopped_proc = NULL;
	fake_wait_candidate_stopped_child = NULL;
	fake_wait_candidate_digest = 0x7761697463616e64UL;
	fake_wait_reap_calls = 0;
	fake_wait_reap_thread = NULL;
}

static int
fake_wait_candidate_stopped(void *thread, void *child_proc, void *child_thread,
			    int *status, int options)
{
	fake_wait_candidate_stopped_calls++;
	fake_wait_candidate_stopped_thread = thread;
	fake_wait_candidate_stopped_proc = child_proc;
	fake_wait_candidate_stopped_child = child_thread;
	*status = 0x5100 | fake_wait_candidate_stopped_calls;
	mix(&fake_wait_candidate_digest, 0x73746f70UL);
	mix(&fake_wait_candidate_digest, options);
	return fake_wait_candidate_stopped_rc;
}

static int
fake_wait_candidate_continued(void *thread, void *child_proc,
			      void *child_thread, int *status, int options)
{
	fake_wait_candidate_continued_calls++;
	*status = 0x5200 | fake_wait_candidate_continued_calls;
	mix(&fake_wait_candidate_digest, 0x636f6e74UL);
	mix(&fake_wait_candidate_digest, thread != NULL);
	mix(&fake_wait_candidate_digest, child_proc != NULL);
	mix(&fake_wait_candidate_digest, child_thread != NULL);
	mix(&fake_wait_candidate_digest, options);
	return fake_wait_candidate_continued_rc;
}

static void
fake_wait_candidate_unlock(void *lock, void *node)
{
	fake_wait_candidate_unlock_calls++;
	fake_wait_candidate_unlock_event = ++fake_wait_candidate_event_seq;
	mix(&fake_wait_candidate_digest, 0x756e6c6bUL);
	mix(&fake_wait_candidate_digest, lock != NULL);
	mix(&fake_wait_candidate_digest, node != NULL);
}

static void
fake_wait_candidate_report_detach(void *thread)
{
	struct fake_wait_candidate_thread *candidate = thread;

	fake_wait_candidate_report_detach_calls++;
	fake_wait_candidate_report_event = ++fake_wait_candidate_event_seq;
	candidate->report_detached++;
}

static void
fake_wait_candidate_ptrace_detach(void *thread)
{
	struct fake_wait_candidate_thread *candidate = thread;

	fake_wait_candidate_ptrace_detach_calls++;
	candidate->ptrace_detached++;
}

static void
fake_wait_candidate_release(void *thread)
{
	struct fake_wait_candidate_thread *candidate = thread;

	fake_wait_candidate_release_calls++;
	fake_wait_candidate_release_event = ++fake_wait_candidate_event_seq;
	candidate->released++;
}

static void
fake_wait_zombie_reset(void)
{
	fake_wait_zombie_host_calls = 0;
	fake_wait_zombie_host_pid = 0;
	fake_wait_zombie_host_options = 0;
	fake_wait_zombie_host_rc = 0;
	fake_wait_zombie_lock_calls = 0;
	fake_wait_zombie_unlock_calls = 0;
	fake_wait_zombie_detach_calls = 0;
	fake_wait_zombie_add_tail_calls = 0;
	fake_wait_zombie_ptrace_detach_calls = 0;
	fake_wait_zombie_release_calls = 0;
	fake_wait_zombie_log_count = 0;
	fake_wait_zombie_event_seq = 0;
	fake_wait_zombie_parent_unlock_event = 0;
	fake_wait_zombie_ptrace_event = 0;
	fake_wait_zombie_release_event = 0;
	fake_wait_zombie_active_parent = NULL;
	fake_wait_zombie_active_child = NULL;
	fake_wait_zombie_active_pid1 = NULL;
	fake_wait_zombie_digest = 0x776169747a6f6d62UL;
}

static int
fake_wait_zombie_host_wait4(int pid, int options)
{
	fake_wait_zombie_host_calls++;
	fake_wait_zombie_host_pid = pid;
	fake_wait_zombie_host_options = options;
	mix(&fake_wait_zombie_digest, 0x686f7374UL);
	mix_signed(&fake_wait_zombie_digest, pid);
	mix_signed(&fake_wait_zombie_digest, options);
	return fake_wait_zombie_host_rc;
}

static void
fake_wait_zombie_lock(void *lock, void *node)
{
	fake_wait_zombie_lock_calls++;
	mix(&fake_wait_zombie_digest, 0x6c6f636bUL);
	mix(&fake_wait_zombie_digest, lock != NULL);
	mix(&fake_wait_zombie_digest, node != NULL);
}

static void
fake_wait_zombie_unlock(void *lock, void *node)
{
	fake_wait_zombie_unlock_calls++;
	if (fake_wait_zombie_active_parent &&
	    lock == &fake_wait_zombie_active_parent->children_lock)
		fake_wait_zombie_parent_unlock_event =
			++fake_wait_zombie_event_seq;
	mix(&fake_wait_zombie_digest, 0x756e6c6bUL);
	mix(&fake_wait_zombie_digest, lock != NULL);
	mix(&fake_wait_zombie_digest, node != NULL);
}

static void
fake_wait_zombie_list_detach(void *entry)
{
	fake_wait_zombie_detach_calls++;
	if (fake_wait_zombie_active_child &&
	    entry == &fake_wait_zombie_active_child->siblings_list)
		fake_wait_zombie_active_child->sibling_detached++;
	mix(&fake_wait_zombie_digest, 0x64657463UL);
}

static void
fake_wait_zombie_list_add_tail(void *entry, void *head)
{
	fake_wait_zombie_add_tail_calls++;
	if (fake_wait_zombie_active_child &&
	    fake_wait_zombie_active_pid1 &&
	    entry == &fake_wait_zombie_active_child->siblings_list &&
	    head == &fake_wait_zombie_active_pid1->children_list) {
		fake_wait_zombie_active_child->sibling_added++;
	}
	mix(&fake_wait_zombie_digest, 0x61646474UL);
	mix(&fake_wait_zombie_digest, head != NULL);
}

static void
fake_wait_zombie_ptrace_detach(void *thread)
{
	struct fake_wait_zombie_thread *candidate = thread;

	fake_wait_zombie_ptrace_detach_calls++;
	fake_wait_zombie_ptrace_event = ++fake_wait_zombie_event_seq;
	if (candidate)
		candidate->ptrace_detached++;
}

static void
fake_wait_zombie_release_process(void *proc)
{
	struct fake_wait_zombie_process *candidate = proc;

	fake_wait_zombie_release_calls++;
	fake_wait_zombie_release_event = ++fake_wait_zombie_event_seq;
	if (candidate)
		candidate->released++;
}

static void
fake_wait_zombie_log(int event, int pid, int status, int ret)
{
	fake_wait_zombie_log_count++;
	mix(&fake_wait_zombie_digest, 0x6c6f6721UL);
	mix_signed(&fake_wait_zombie_digest, event);
	mix_signed(&fake_wait_zombie_digest, pid);
	mix_signed(&fake_wait_zombie_digest, status);
	mix_signed(&fake_wait_zombie_digest, ret);
}

static int fake_wait_scan_lock_calls;
static int fake_wait_scan_unlock_calls;
static int fake_wait_scan_detach_calls;
static int fake_wait_scan_add_tail_calls;
static int fake_wait_scan_release_calls;
static int fake_wait_scan_ptrace_detach_calls;
static int fake_wait_scan_stopped_calls;
static int fake_wait_scan_continued_calls;
static int fake_wait_scan_report_detach_calls;
static unsigned long fake_wait_scan_digest;
static int fake_ptrace_detach_lock_calls;
static int fake_ptrace_detach_unlock_calls;
static int fake_ptrace_detach_list_detach_calls;
static int fake_ptrace_detach_main_reparent_calls;
static int fake_ptrace_detach_report_detach_calls;
static int fake_ptrace_detach_report_attach_calls;
static int fake_ptrace_detach_cleanup_calls;
static int fake_ptrace_detach_free_calls;
static int fake_ptrace_detach_clear_calls;
static int fake_ptrace_detach_exit_signal_calls;
static int fake_ptrace_detach_do_kill_calls;
static int fake_ptrace_detach_wakeup_calls;
static int fake_ptrace_detach_release_calls;
static int fake_ptrace_detach_finalize_calls;
static int fake_ptrace_detach_seen_pid;
static int fake_ptrace_detach_seen_tid;
static int fake_ptrace_detach_seen_sig;
static int fake_ptrace_detach_seen_si_signo;
static int fake_ptrace_detach_seen_si_code;
static int fake_ptrace_detach_seen_si_pid;
static int fake_ptrace_detach_seen_ptracecont;
static void *fake_ptrace_detach_seen_current;
static void *fake_ptrace_detach_freed_ptr;
static unsigned long fake_ptrace_detach_digest;

static void
fake_wait_scan_reset(void)
{
	fake_wait_scan_lock_calls = 0;
	fake_wait_scan_unlock_calls = 0;
	fake_wait_scan_detach_calls = 0;
	fake_wait_scan_add_tail_calls = 0;
	fake_wait_scan_release_calls = 0;
	fake_wait_scan_ptrace_detach_calls = 0;
	fake_wait_scan_stopped_calls = 0;
	fake_wait_scan_continued_calls = 0;
	fake_wait_scan_report_detach_calls = 0;
	fake_wait_scan_digest = 0x776169747363616eUL;
}

static void
fake_wait_scan_list_init(struct fake_list_head *head)
{
	head->next = head;
	head->prev = head;
}

static void
fake_wait_scan_list_add_tail(struct fake_list_head *entry,
			     struct fake_list_head *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static void
fake_wait_scan_lock(void *lock, void *node)
{
	fake_wait_scan_lock_calls++;
	mix(&fake_wait_scan_digest, 0x6c6f636bUL);
	mix(&fake_wait_scan_digest, lock != NULL);
	mix(&fake_wait_scan_digest, node != NULL);
}

static void
fake_wait_scan_unlock(void *lock, void *node)
{
	fake_wait_scan_unlock_calls++;
	mix(&fake_wait_scan_digest, 0x756e6c6bUL);
	mix(&fake_wait_scan_digest, lock != NULL);
	mix(&fake_wait_scan_digest, node != NULL);
}

static void
fake_wait_scan_list_detach(void *entry)
{
	fake_wait_scan_detach_calls++;
	mix(&fake_wait_scan_digest, 0x64657463UL);
	mix(&fake_wait_scan_digest, entry != NULL);
}

static void
fake_wait_scan_list_add_tail_cb(void *entry, void *head)
{
	fake_wait_scan_add_tail_calls++;
	mix(&fake_wait_scan_digest, 0x61646474UL);
	mix(&fake_wait_scan_digest, entry != NULL);
	mix(&fake_wait_scan_digest, head != NULL);
}

static void
fake_wait_scan_ptrace_detach(void *thread)
{
	struct fake_wait_scan_thread *scan_thread = thread;

	fake_wait_scan_ptrace_detach_calls++;
	if (scan_thread)
		scan_thread->ptrace_detached++;
}

static void
fake_wait_scan_release_process(void *proc)
{
	struct fake_wait_scan_process *scan_proc = proc;

	fake_wait_scan_release_calls++;
	if (scan_proc)
		scan_proc->released++;
}

static void
fake_wait_scan_release_thread(void *thread)
{
	struct fake_wait_scan_thread *scan_thread = thread;

	fake_wait_scan_release_calls++;
	if (scan_thread)
		scan_thread->released++;
}

static void
fake_wait_scan_report_detach(void *thread)
{
	struct fake_wait_scan_thread *scan_thread = thread;

	fake_wait_scan_report_detach_calls++;
	if (scan_thread)
		scan_thread->report_detached++;
}

static int
fake_wait_scan_stopped(void *thread, void *child_proc, void *child_thread,
		       int *status, int options)
{
	struct fake_wait_scan_process *proc = child_proc;
	struct fake_wait_scan_thread *scan_thread = child_thread;

	fake_wait_scan_stopped_calls++;
	*status = 0x6100 | fake_wait_scan_stopped_calls;
	mix(&fake_wait_scan_digest, 0x73746f70UL);
	mix(&fake_wait_scan_digest, thread != NULL);
	mix(&fake_wait_scan_digest, proc ? (unsigned long)proc->pid : 0);
	mix(&fake_wait_scan_digest, scan_thread ?
		(unsigned long)scan_thread->tid : 0);
	mix_signed(&fake_wait_scan_digest, options);
	return scan_thread ? scan_thread->tid : (proc ? proc->pid : -1);
}

static int
fake_wait_scan_continued(void *thread, void *child_proc, void *child_thread,
			 int *status, int options)
{
	struct fake_wait_scan_process *proc = child_proc;
	struct fake_wait_scan_thread *scan_thread = child_thread;

	fake_wait_scan_continued_calls++;
	*status = 0x6200 | fake_wait_scan_continued_calls;
	mix(&fake_wait_scan_digest, 0x636f6e74UL);
	mix(&fake_wait_scan_digest, thread != NULL);
	mix(&fake_wait_scan_digest, proc ? (unsigned long)proc->pid : 0);
	mix(&fake_wait_scan_digest, scan_thread ?
		(unsigned long)scan_thread->tid : 0);
	mix_signed(&fake_wait_scan_digest, options);
	return scan_thread ? scan_thread->tid : (proc ? proc->pid : -1);
}

static const struct fake_wait_scan_offsets fake_wait_scan_offsets = {
	.thread_proc_offset = offsetof(struct fake_wait_scan_thread, proc),
	.thread_tid_offset = offsetof(struct fake_wait_scan_thread, tid),
	.thread_status_offset = offsetof(struct fake_wait_scan_thread, status),
	.thread_ptrace_offset = offsetof(struct fake_wait_scan_thread, ptrace),
	.thread_signal_flags_offset =
		offsetof(struct fake_wait_scan_thread, signal_flags),
	.thread_termsig_offset =
		offsetof(struct fake_wait_scan_thread, termsig),
	.thread_report_siblings_list_offset =
		offsetof(struct fake_wait_scan_thread, report_siblings_list),
	.thread_siblings_list_offset =
		offsetof(struct fake_wait_scan_thread, siblings_list),
	.proc_pid_offset = offsetof(struct fake_wait_scan_process, pid),
	.proc_pgid_offset = offsetof(struct fake_wait_scan_process, pgid),
	.proc_status_offset = offsetof(struct fake_wait_scan_process, status),
	.proc_children_lock_offset =
		offsetof(struct fake_wait_scan_process, children_lock),
	.proc_threads_lock_offset =
		offsetof(struct fake_wait_scan_process, threads_lock),
	.proc_children_list_offset =
		offsetof(struct fake_wait_scan_process, children_list),
	.proc_ptraced_children_list_offset =
		offsetof(struct fake_wait_scan_process, ptraced_children_list),
	.proc_siblings_list_offset =
		offsetof(struct fake_wait_scan_process, siblings_list),
	.proc_ptraced_siblings_list_offset =
		offsetof(struct fake_wait_scan_process, ptraced_siblings_list),
	.proc_report_threads_list_offset =
		offsetof(struct fake_wait_scan_process, report_threads_list),
	.proc_threads_list_offset =
		offsetof(struct fake_wait_scan_process, threads_list),
	.proc_main_thread_offset =
		offsetof(struct fake_wait_scan_process, main_thread),
};

static const struct fake_wait_zombie_offsets fake_wait_scan_zombie_offsets = {
	.thread_ptrace_offset = offsetof(struct fake_wait_scan_thread, ptrace),
	.proc_pid_offset = offsetof(struct fake_wait_scan_process, pid),
	.proc_ppid_parent_offset =
		offsetof(struct fake_wait_scan_process, ppid_parent),
	.proc_parent_offset = offsetof(struct fake_wait_scan_process, parent),
	.proc_status_offset = offsetof(struct fake_wait_scan_process, status),
	.proc_group_exit_status_offset =
		offsetof(struct fake_wait_scan_process, group_exit_status),
	.proc_nowait_offset = offsetof(struct fake_wait_scan_process, nowait),
	.proc_update_lock_offset =
		offsetof(struct fake_wait_scan_process, update_lock),
	.proc_children_lock_offset =
		offsetof(struct fake_wait_scan_process, children_lock),
	.proc_threads_lock_offset =
		offsetof(struct fake_wait_scan_process, threads_lock),
	.proc_siblings_list_offset =
		offsetof(struct fake_wait_scan_process, siblings_list),
	.proc_children_list_offset =
		offsetof(struct fake_wait_scan_process, children_list),
	.proc_main_thread_offset =
		offsetof(struct fake_wait_scan_process, main_thread),
	.proc_stime_offset = offsetof(struct fake_wait_scan_process, stime),
	.proc_utime_offset = offsetof(struct fake_wait_scan_process, utime),
	.proc_stime_children_offset =
		offsetof(struct fake_wait_scan_process, stime_children),
	.proc_utime_children_offset =
		offsetof(struct fake_wait_scan_process, utime_children),
	.proc_maxrss_offset = offsetof(struct fake_wait_scan_process, maxrss),
	.proc_maxrss_children_offset =
		offsetof(struct fake_wait_scan_process, maxrss_children),
};

static const struct fake_ptrace_detach_offsets fake_ptrace_detach_offsets = {
	.thread_proc_offset =
		offsetof(struct fake_ptrace_detach_thread, proc),
	.thread_termsig_offset =
		offsetof(struct fake_ptrace_detach_thread, termsig),
	.thread_status_offset =
		offsetof(struct fake_ptrace_detach_thread, status),
	.thread_tid_offset =
		offsetof(struct fake_ptrace_detach_thread, tid),
	.thread_report_proc_offset =
		offsetof(struct fake_ptrace_detach_thread, report_proc),
	.thread_report_siblings_list_offset =
		offsetof(struct fake_ptrace_detach_thread,
			 report_siblings_list),
	.thread_ptrace_offset =
		offsetof(struct fake_ptrace_detach_thread, ptrace),
	.thread_ptrace_saved_uctx_valid_offset =
		offsetof(struct fake_ptrace_detach_thread,
			 ptrace_saved_uctx_valid),
	.thread_ptrace_debugreg_offset =
		offsetof(struct fake_ptrace_detach_thread, ptrace_debugreg),
	.proc_pid_offset =
		offsetof(struct fake_ptrace_detach_process, pid),
	.proc_status_offset =
		offsetof(struct fake_ptrace_detach_process, status),
	.proc_parent_offset =
		offsetof(struct fake_ptrace_detach_process, parent),
	.proc_ppid_parent_offset =
		offsetof(struct fake_ptrace_detach_process, ppid_parent),
	.proc_main_thread_offset =
		offsetof(struct fake_ptrace_detach_process, main_thread),
	.proc_children_lock_offset =
		offsetof(struct fake_ptrace_detach_process, children_lock),
	.proc_threads_lock_offset =
		offsetof(struct fake_ptrace_detach_process, threads_lock),
	.proc_children_list_offset =
		offsetof(struct fake_ptrace_detach_process, children_list),
	.proc_siblings_list_offset =
		offsetof(struct fake_ptrace_detach_process, siblings_list),
	.proc_ptraced_siblings_list_offset =
		offsetof(struct fake_ptrace_detach_process,
			 ptraced_siblings_list),
	.proc_report_threads_list_offset =
		offsetof(struct fake_ptrace_detach_process,
			 report_threads_list),
};

static void
fake_ptrace_detach_reset(void)
{
	fake_ptrace_detach_lock_calls = 0;
	fake_ptrace_detach_unlock_calls = 0;
	fake_ptrace_detach_list_detach_calls = 0;
	fake_ptrace_detach_main_reparent_calls = 0;
	fake_ptrace_detach_report_detach_calls = 0;
	fake_ptrace_detach_report_attach_calls = 0;
	fake_ptrace_detach_cleanup_calls = 0;
	fake_ptrace_detach_free_calls = 0;
	fake_ptrace_detach_clear_calls = 0;
	fake_ptrace_detach_exit_signal_calls = 0;
	fake_ptrace_detach_do_kill_calls = 0;
	fake_ptrace_detach_wakeup_calls = 0;
	fake_ptrace_detach_release_calls = 0;
	fake_ptrace_detach_finalize_calls = 0;
	fake_ptrace_detach_seen_pid = 0;
	fake_ptrace_detach_seen_tid = 0;
	fake_ptrace_detach_seen_sig = 0;
	fake_ptrace_detach_seen_si_signo = 0;
	fake_ptrace_detach_seen_si_code = 0;
	fake_ptrace_detach_seen_si_pid = 0;
	fake_ptrace_detach_seen_ptracecont = 0;
	fake_ptrace_detach_seen_current = NULL;
	fake_ptrace_detach_freed_ptr = NULL;
	fake_ptrace_detach_digest = 0x7074726465746163UL;
}

static void
fake_ptrace_detach_list_init(struct fake_list_head *head)
{
	head->next = head;
	head->prev = head;
}

static void
fake_ptrace_detach_list_add_tail(struct fake_list_head *entry,
				 struct fake_list_head *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static void
fake_ptrace_detach_list_unlink(struct fake_list_head *entry)
{
	if (!entry || !entry->next || !entry->prev)
		return;
	entry->prev->next = entry->next;
	entry->next->prev = entry->prev;
	entry->next = entry;
	entry->prev = entry;
}

static void
fake_ptrace_detach_lock(void *lock, void *node)
{
	fake_ptrace_detach_lock_calls++;
	mix(&fake_ptrace_detach_digest, 0x6c6f636bUL);
	mix(&fake_ptrace_detach_digest, lock != NULL);
	mix(&fake_ptrace_detach_digest, node != NULL);
}

static void
fake_ptrace_detach_unlock(void *lock, void *node)
{
	fake_ptrace_detach_unlock_calls++;
	mix(&fake_ptrace_detach_digest, 0x756e6c6bUL);
	mix(&fake_ptrace_detach_digest, lock != NULL);
	mix(&fake_ptrace_detach_digest, node != NULL);
}

static void
fake_ptrace_detach_list_detach(void *entry)
{
	fake_ptrace_detach_list_detach_calls++;
	fake_ptrace_detach_list_unlink(entry);
	mix(&fake_ptrace_detach_digest, 0x6c646574UL);
}

static int
fake_ptrace_detach_main_reparent(void *process, unsigned long parent_offset,
				 void *parent, void *ptraced_entry,
				 void *sibling_entry, void *children_head)
{
	fake_ptrace_detach_main_reparent_calls++;
	fake_ptrace_detach_list_unlink(ptraced_entry);
	fake_ptrace_detach_list_add_tail(sibling_entry, children_head);
	*(void **)((char *)process + parent_offset) = parent;
	mix(&fake_ptrace_detach_digest, 0x6d726570UL);
	return 1;
}

static int
fake_ptrace_detach_report_detach(void *thread,
				 unsigned long report_proc_offset,
				 void *report_proc, void *entry)
{
	fake_ptrace_detach_report_detach_calls++;
	*(void **)((char *)thread + report_proc_offset) = report_proc;
	fake_ptrace_detach_list_unlink(entry);
	mix(&fake_ptrace_detach_digest, 0x72646574UL);
	return 1;
}

static void *
fake_ptrace_detach_cleanup(void *thread, unsigned long ptrace_offset,
			   unsigned long saved_valid_offset,
			   unsigned long debugreg_offset)
{
	void **debugreg_slot = (void **)((char *)thread + debugreg_offset);
	void *debugreg = *debugreg_slot;

	fake_ptrace_detach_cleanup_calls++;
	*(int *)((char *)thread + ptrace_offset) = 0;
	*(int *)((char *)thread + saved_valid_offset) = 0;
	*debugreg_slot = NULL;
	mix(&fake_ptrace_detach_digest, 0x636c656eUL);
	return debugreg;
}

static void
fake_ptrace_detach_free(void *ptr)
{
	fake_ptrace_detach_free_calls++;
	fake_ptrace_detach_freed_ptr = ptr;
	mix(&fake_ptrace_detach_digest, ptr != NULL);
}

static void
fake_ptrace_detach_clear_single_step(void *thread)
{
	struct fake_ptrace_detach_thread *fake = thread;

	fake_ptrace_detach_clear_calls++;
	if (fake)
		fake->single_step_cleared++;
}

static int
fake_ptrace_detach_report_attach(void *thread, unsigned long termsig_offset,
				 int update_termsig, int termsig,
				 unsigned long report_proc_offset,
				 void *report_proc, void *entry, void *head)
{
	fake_ptrace_detach_report_attach_calls++;
	if (update_termsig)
		*(int *)((char *)thread + termsig_offset) = termsig;
	*(void **)((char *)thread + report_proc_offset) = report_proc;
	fake_ptrace_detach_list_add_tail(entry, head);
	mix(&fake_ptrace_detach_digest, 0x72617474UL);
	return 1;
}

static void
fake_ptrace_detach_exit_signal(void *thread)
{
	struct fake_ptrace_detach_thread *fake = thread;

	fake_ptrace_detach_exit_signal_calls++;
	if (fake)
		fake->exit_signal_calls++;
}

static long
fake_ptrace_detach_do_kill(void *current_thread, int pid, int tid, int sig,
			   const void *info, int ptracecont)
{
	const struct fake_siginfo *sinfo = info;

	fake_ptrace_detach_do_kill_calls++;
	fake_ptrace_detach_seen_current = current_thread;
	fake_ptrace_detach_seen_pid = pid;
	fake_ptrace_detach_seen_tid = tid;
	fake_ptrace_detach_seen_sig = sig;
	fake_ptrace_detach_seen_ptracecont = ptracecont;
	if (sinfo) {
		fake_ptrace_detach_seen_si_signo = sinfo->si_signo;
		fake_ptrace_detach_seen_si_code = sinfo->si_code;
		fake_ptrace_detach_seen_si_pid = sinfo->sifields.kill.si_pid;
	}
	mix(&fake_ptrace_detach_digest, 0x646b696cUL);
	return 0;
}

static void
fake_ptrace_detach_wakeup(void *thread, int valid_states)
{
	struct fake_ptrace_detach_thread *fake = thread;

	fake_ptrace_detach_wakeup_calls++;
	if (fake) {
		fake->wake_calls++;
		fake->wake_states = valid_states;
	}
}

static void
fake_ptrace_detach_release(void *thread)
{
	struct fake_ptrace_detach_thread *fake = thread;

	fake_ptrace_detach_release_calls++;
	if (fake)
		fake->release_calls++;
}

static void
fake_ptrace_detach_finalize(void *proc)
{
	struct fake_ptrace_detach_process *fake = proc;

	fake_ptrace_detach_finalize_calls++;
	if (fake)
		fake->finalized++;
}

static void
exercise_ptrace_detach_body(unsigned long *digest)
{
	int lock_node = 0x55;
	int debug_cookie = 0x1234;
	int ret;
	struct fake_ptrace_detach_process tracer = { .pid = 400 };
	struct fake_ptrace_detach_process parent = { .pid = 200 };
	struct fake_ptrace_detach_process tracee = {
		.pid = 300,
		.status = PS_ZOMBIE,
		.parent = &tracer,
		.ppid_parent = &parent,
	};
	struct fake_ptrace_detach_process pid1 = { .pid = 1 };
	struct fake_ptrace_detach_thread current = { .proc = &tracer, .tid = 444 };
	struct fake_ptrace_detach_thread main_thread = {
		.proc = &tracee,
		.termsig = 9,
		.status = PS_ZOMBIE,
		.tid = 333,
		.report_proc = &tracer,
		.ptrace = PT_TRACED,
		.ptrace_saved_uctx_valid = 1,
		.ptrace_debugreg = &debug_cookie,
	};
	struct fake_list_head ptraced_head;

	tracee.main_thread = &main_thread;
	fake_ptrace_detach_list_init(&tracer.children_list);
	fake_ptrace_detach_list_init(&tracer.report_threads_list);
	fake_ptrace_detach_list_init(&parent.children_list);
	fake_ptrace_detach_list_init(&tracee.children_list);
	fake_ptrace_detach_list_init(&tracee.siblings_list);
	fake_ptrace_detach_list_init(&tracee.ptraced_siblings_list);
	fake_ptrace_detach_list_init(&tracee.report_threads_list);
	fake_ptrace_detach_list_init(&main_thread.report_siblings_list);
	fake_ptrace_detach_list_init(&ptraced_head);
	fake_ptrace_detach_list_add_tail(&tracee.siblings_list,
					 &tracer.children_list);
	fake_ptrace_detach_list_add_tail(&tracee.ptraced_siblings_list,
					 &ptraced_head);
	fake_ptrace_detach_list_add_tail(&main_thread.report_siblings_list,
					 &tracer.report_threads_list);

	fake_ptrace_detach_reset();
	ret = ptrace_detach_thread_body_result(&main_thread, 9, &current,
		&tracer, &pid1, &fake_ptrace_detach_offsets,
		fake_ptrace_detach_lock, fake_ptrace_detach_unlock,
		fake_ptrace_detach_list_detach,
		fake_ptrace_detach_main_reparent,
		fake_ptrace_detach_report_detach,
		fake_ptrace_detach_cleanup, fake_ptrace_detach_free,
		fake_ptrace_detach_clear_single_step,
		fake_ptrace_detach_report_attach,
		fake_ptrace_detach_exit_signal,
		fake_ptrace_detach_do_kill,
		fake_ptrace_detach_wakeup,
		fake_ptrace_detach_release,
		fake_ptrace_detach_finalize, &lock_node);
	require(ret == 511);
	require(fake_ptrace_detach_lock_calls == 4);
	require(fake_ptrace_detach_unlock_calls == 4);
	require(fake_ptrace_detach_list_detach_calls == 1);
	require(fake_ptrace_detach_main_reparent_calls == 1);
	require(fake_ptrace_detach_report_detach_calls == 1);
	require(fake_ptrace_detach_report_attach_calls == 1);
	require(fake_ptrace_detach_cleanup_calls == 1);
	require(fake_ptrace_detach_free_calls == 1);
	require(fake_ptrace_detach_clear_calls == 1);
	require(fake_ptrace_detach_exit_signal_calls == 1);
	require(fake_ptrace_detach_do_kill_calls == 1);
	require(fake_ptrace_detach_wakeup_calls == 1);
	require(fake_ptrace_detach_release_calls == 1);
	require(fake_ptrace_detach_finalize_calls == 1);
	require(tracee.parent == &parent);
	require(main_thread.report_proc == &tracee);
	require(main_thread.ptrace == 0);
	require(main_thread.ptrace_saved_uctx_valid == 0);
	require(main_thread.ptrace_debugreg == NULL);
	require(fake_ptrace_detach_freed_ptr == &debug_cookie);
	require(main_thread.single_step_cleared == 1);
	require(main_thread.exit_signal_calls == 1);
	require(main_thread.wake_states == (PS_TRACED | PS_STOPPED));
	require(main_thread.release_calls == 1);
	require(tracee.finalized == 1);
	require(fake_ptrace_detach_seen_current == &current);
	require(fake_ptrace_detach_seen_pid == tracee.pid);
	require(fake_ptrace_detach_seen_tid == main_thread.tid);
	require(fake_ptrace_detach_seen_sig == 9);
	require(fake_ptrace_detach_seen_si_signo == 9);
	require(fake_ptrace_detach_seen_si_code == 0);
	require(fake_ptrace_detach_seen_si_pid == tracer.pid);
	require(fake_ptrace_detach_seen_ptracecont == 1);
	mix_signed(digest, ret);
	mix_signed(digest, fake_ptrace_detach_lock_calls);
	mix_signed(digest, fake_ptrace_detach_unlock_calls);
	mix_signed(digest, fake_ptrace_detach_seen_pid);
	mix_signed(digest, fake_ptrace_detach_seen_tid);
	mix_signed(digest, fake_ptrace_detach_seen_si_pid);
	mix(digest, fake_ptrace_detach_digest);

	{
		struct fake_ptrace_detach_thread worker = {
			.proc = &tracee,
			.termsig = SIGCHLD,
			.status = PS_RUNNING,
			.tid = 334,
			.report_proc = &tracer,
			.ptrace = PT_TRACED,
			.ptrace_saved_uctx_valid = 1,
			.ptrace_debugreg = NULL,
		};

		fake_ptrace_detach_list_init(&worker.report_siblings_list);
		fake_ptrace_detach_list_add_tail(&worker.report_siblings_list,
						 &tracer.report_threads_list);
		fake_ptrace_detach_reset();
		ret = ptrace_detach_thread_body_result(&worker, 0, &current,
			&tracer, &pid1, &fake_ptrace_detach_offsets,
			fake_ptrace_detach_lock, fake_ptrace_detach_unlock,
			fake_ptrace_detach_list_detach,
			fake_ptrace_detach_main_reparent,
			fake_ptrace_detach_report_detach,
			fake_ptrace_detach_cleanup, fake_ptrace_detach_free,
			fake_ptrace_detach_clear_single_step,
			fake_ptrace_detach_report_attach,
			fake_ptrace_detach_exit_signal,
			fake_ptrace_detach_do_kill,
			fake_ptrace_detach_wakeup,
			fake_ptrace_detach_release,
			fake_ptrace_detach_finalize, &lock_node);
		require(ret == 136);
		require(fake_ptrace_detach_lock_calls == 1);
		require(fake_ptrace_detach_unlock_calls == 1);
		require(fake_ptrace_detach_report_detach_calls == 1);
		require(fake_ptrace_detach_report_attach_calls == 0);
		require(fake_ptrace_detach_do_kill_calls == 0);
		require(fake_ptrace_detach_finalize_calls == 0);
		require(worker.report_proc == NULL);
		require(worker.wake_states == (PS_TRACED | PS_STOPPED));
		require(worker.release_calls == 1);
		mix_signed(digest, ret);
		mix_signed(digest, fake_ptrace_detach_lock_calls);
		mix_signed(digest, worker.report_proc == NULL);
		mix(digest, fake_ptrace_detach_digest);
	}

	ret = ptrace_detach_thread_body_result(NULL, 0, &current, &tracer,
		&pid1, &fake_ptrace_detach_offsets,
		fake_ptrace_detach_lock, fake_ptrace_detach_unlock,
		fake_ptrace_detach_list_detach,
		fake_ptrace_detach_main_reparent,
		fake_ptrace_detach_report_detach,
		fake_ptrace_detach_cleanup, fake_ptrace_detach_free,
		fake_ptrace_detach_clear_single_step,
		fake_ptrace_detach_report_attach,
		fake_ptrace_detach_exit_signal,
		fake_ptrace_detach_do_kill,
		fake_ptrace_detach_wakeup,
		fake_ptrace_detach_release,
		fake_ptrace_detach_finalize, &lock_node);
	require(ret == -22);
	mix_signed(digest, ret);
}

static void
fake_do_wait_reset(void)
{
	fake_do_wait_proc_calls = 0;
	fake_do_wait_thread_calls = 0;
	fake_do_wait_init_calls = 0;
	fake_do_wait_prepare_calls = 0;
	fake_do_wait_finish_calls = 0;
	fake_do_wait_has_signal_calls = 0;
	fake_do_wait_schedule_calls = 0;
	fake_do_wait_log_count = 0;
	fake_do_wait_scan_digest = 0x64776169745f7363UL;
	fake_do_wait_log_digest = 0x64776169745f6c67UL;
	memset(fake_do_wait_log_events, 0, sizeof(fake_do_wait_log_events));
	memset(fake_do_wait_log_current, 0, sizeof(fake_do_wait_log_current));
	memset(fake_do_wait_log_wait_pid, 0, sizeof(fake_do_wait_log_wait_pid));
	for (int i = 0; i < FAKE_DO_WAIT_MAX_CALLS; i++) {
		fake_do_wait_proc_rc[i] = 0;
		fake_do_wait_thread_rc[i] = 0;
		fake_do_wait_proc_empty[i] = INT_MIN;
		fake_do_wait_thread_empty[i] = INT_MIN;
		fake_do_wait_proc_status[i] = INT_MIN;
		fake_do_wait_thread_status[i] = INT_MIN;
	}
}

static int
fake_do_wait_proc_scan(int pid, int *status, int options, void *rusage,
		       int *empty)
{
	int index = fake_do_wait_proc_calls++;

	require(index < FAKE_DO_WAIT_MAX_CALLS);
	mix(&fake_do_wait_scan_digest, 0x70726f63UL);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)pid);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)options);
	mix(&fake_do_wait_scan_digest, rusage != NULL);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)*empty);
	if (fake_do_wait_proc_empty[index] != INT_MIN)
		*empty = fake_do_wait_proc_empty[index];
	if (fake_do_wait_proc_status[index] != INT_MIN)
		*status = fake_do_wait_proc_status[index];
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)*empty);
	return fake_do_wait_proc_rc[index];
}

static int
fake_do_wait_thread_scan(int pid, int *status, int options, void *rusage,
			 int *empty)
{
	int index = fake_do_wait_thread_calls++;

	require(index < FAKE_DO_WAIT_MAX_CALLS);
	mix(&fake_do_wait_scan_digest, 0x74687264UL);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)pid);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)options);
	mix(&fake_do_wait_scan_digest, rusage != NULL);
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)*empty);
	if (fake_do_wait_thread_empty[index] != INT_MIN)
		*empty = fake_do_wait_thread_empty[index];
	if (fake_do_wait_thread_status[index] != INT_MIN)
		*status = fake_do_wait_thread_status[index];
	mix(&fake_do_wait_scan_digest, (unsigned long)(long)*empty);
	return fake_do_wait_thread_rc[index];
}

static void
fake_do_wait_init(void *entry, void *thread)
{
	struct fake_do_wait_entry *wait_entry = entry;

	fake_do_wait_init_calls++;
	wait_entry->initialized++;
	wait_entry->thread = thread;
}

static void
fake_do_wait_prepare(void *waitq, void *entry, int status)
{
	struct fake_do_wait_entry *wait_entry = entry;

	fake_do_wait_prepare_calls++;
	wait_entry->waitq = waitq;
	wait_entry->prepared++;
	wait_entry->status = status;
}

static void
fake_do_wait_finish(void *waitq, void *entry)
{
	struct fake_do_wait_entry *wait_entry = entry;

	fake_do_wait_finish_calls++;
	wait_entry->waitq = waitq;
	wait_entry->finished++;
}

static int
fake_do_wait_has_signal(void *thread)
{
	struct fake_do_wait_thread *wait_thread = thread;

	fake_do_wait_has_signal_calls++;
	return wait_thread->signal_pending;
}

static void
fake_do_wait_schedule(void)
{
	fake_do_wait_schedule_calls++;
}

static void
fake_do_wait_log(int event, int current_pid, int wait_pid)
{
	int index = fake_do_wait_log_count++;

	require(index < FAKE_DO_WAIT_MAX_LOGS);
	fake_do_wait_log_events[index] = event;
	fake_do_wait_log_current[index] = current_pid;
	fake_do_wait_log_wait_pid[index] = wait_pid;
	mix(&fake_do_wait_log_digest, (unsigned long)(long)event);
	mix(&fake_do_wait_log_digest, (unsigned long)(long)current_pid);
	mix(&fake_do_wait_log_digest, (unsigned long)(long)wait_pid);
}

static long
fake_forward_sigmask(unsigned long sigmask)
{
	fake_forward_sigmask_calls++;
	fake_forward_sigmask_value = sigmask;
	return 0;
}

static int
fake_do_sigaction(int sig, void *act, void *oact)
{
	struct fake_k_sigaction *ksa;

	fake_do_sigaction_calls++;
	fake_do_sigaction_sig = sig;
	fake_do_sigaction_has_act = act != NULL;
	fake_do_sigaction_has_oact = oact != NULL;
	if (act) {
		ksa = act;
		fake_do_sigaction_seen_mask = ksa->sa.sa_mask;
	}
	if (oact) {
		*(struct fake_k_sigaction *)oact = fake_do_sigaction_old;
	}
	return fake_do_sigaction_rc;
}

static void
fake_sigaction_body_lock(void *lock, void *node)
{
	fake_sigaction_body_lock_calls++;
	fake_sigaction_body_lock_ptr = lock;
	fake_sigaction_body_lock_node = node;
}

static void
fake_sigaction_body_unlock(void *lock, void *node)
{
	fake_sigaction_body_unlock_calls++;
	fake_sigaction_body_unlock_ptr = lock;
	fake_sigaction_body_unlock_node = node;
}

static long
fake_sigaction_body_forward(int sig, const void *act)
{
	const struct fake_k_sigaction *ksa = act;

	fake_sigaction_body_forward_calls++;
	fake_sigaction_body_forward_sig = sig;
	fake_sigaction_body_forward_mask = ksa->sa.sa_mask;
	return 0;
}

static long
fake_do_kill(int pid, int sig, const void *info)
{
	const struct fake_siginfo *sinfo = info;

	fake_do_kill_calls++;
	fake_do_kill_pid = pid;
	fake_do_kill_sig = sig;
	if (sinfo)
		fake_do_sigaction_seen_mask = sinfo->si_signo;
	return fake_do_kill_rc;
}

static long
fake_do_kill_thread(void *thread, int pid, int tid, int sig, const void *info,
		    int ptracecont)
{
	const struct fake_siginfo *sinfo = info;

	fake_do_kill_thread_calls++;
	fake_do_kill_thread_current = thread;
	fake_do_kill_thread_pid = pid;
	fake_do_kill_thread_tid = tid;
	fake_do_kill_thread_sig = sig;
	fake_do_kill_thread_ptracecont = ptracecont;
	if (sinfo) {
		fake_do_kill_thread_si_signo = sinfo->si_signo;
		fake_do_kill_thread_si_code = sinfo->si_code;
		fake_do_kill_thread_si_pid = sinfo->sifields.kill.si_pid;
		fake_do_kill_thread_si_status =
			sinfo->sifields.sigchld.si_status;
		fake_do_kill_thread_si_utime = sinfo->sifields.sigchld.si_utime;
		fake_do_kill_thread_si_stime = sinfo->sifields.sigchld.si_stime;
	}
	return fake_do_kill_thread_rc;
}

static void
fake_thread_exit_wake(void *waitq)
{
	fake_thread_exit_wake_calls++;
	fake_thread_exit_wake_waitq = waitq;
}

static void
fake_thread_exit_log(int sig, long error)
{
	fake_thread_exit_log_calls++;
	fake_thread_exit_log_sig = sig;
	fake_thread_exit_log_error = error;
}

static void
fake_finalize_lock(void *lock, void *node)
{
	fake_finalize_lock_calls++;
	fake_finalize_lock_ptr = lock;
	fake_finalize_lock_node = node;
}

static void
fake_finalize_unlock(void *lock, void *node)
{
	fake_finalize_unlock_calls++;
	fake_finalize_unlock_ptr = lock;
	fake_finalize_unlock_node = node;
}

static void
fake_finalize_release(void *proc)
{
	fake_finalize_release_calls++;
	fake_finalize_release_proc = proc;
}

static void
fake_finalize_wakeup_log(void)
{
	fake_finalize_wakeup_log_calls++;
}

static unsigned long
fake_terminate_cmpxchg(unsigned long *value, unsigned long old_value,
		       unsigned long new_value)
{
	unsigned long observed = *value;

	fake_terminate_cmpxchg_calls++;
	fake_terminate_cmpxchg_ptr = value;
	fake_terminate_cmpxchg_old = old_value;
	fake_terminate_cmpxchg_new = new_value;
	if (fake_terminate_cmpxchg_force_mismatch) {
		return fake_terminate_cmpxchg_mismatch_value;
	}
	if (observed == old_value) {
		*value = new_value;
	}
	return observed;
}

static long
fake_terminate_syscall(struct fake_syscall_request *request, int cpu)
{
	fake_terminate_syscall_calls++;
	fake_terminate_syscall_req = request;
	fake_terminate_syscall_cpu = cpu;
	return fake_terminate_syscall_rc;
}

static void fake_sync_child_reset(unsigned long base)
{
	fake_sync_child_read_calls = 0;
	fake_sync_child_read_last_counter = -1;
	fake_sync_child_read_counter_sum = 0;
	fake_sync_child_read_base = base;
	fake_sync_child_set_calls = 0;
	fake_sync_child_set_last_ptr = NULL;
	fake_sync_child_set_last_value = 0;
}

static unsigned long fake_sync_child_perf_read(int counter_id)
{
	fake_sync_child_read_calls++;
	fake_sync_child_read_last_counter = counter_id;
	fake_sync_child_read_counter_sum += counter_id;
	return fake_sync_child_read_base + (unsigned long)counter_id;
}

static void fake_sync_child_count_set(void *count, long value)
{
	struct fake_sync_child_atomic64 *atomic = count;

	fake_sync_child_set_calls++;
	fake_sync_child_set_last_ptr = count;
	fake_sync_child_set_last_value = value;
	atomic->counter64 = value;
}

static void fake_perf_read_reset(void)
{
	fake_perf_read_update_calls = 0;
	fake_perf_read_update_event = NULL;
	fake_perf_read_atomic_read_calls = 0;
	fake_perf_read_atomic_read_ptr = NULL;
	fake_perf_read_attr_calls = 0;
	fake_perf_read_attr_ptr = NULL;
	fake_perf_read_attr_rc = 0;
	fake_perf_read_value_calls = 0;
	fake_perf_read_value_last_event = NULL;
	fake_perf_read_copy_calls = 0;
	fake_perf_read_copy_base = 0;
	fake_perf_read_copy_fail_call = -1;
	fake_perf_read_copy_last_bytes = 0;
	fake_perf_read_copy_last_offset = 0;
	fake_perf_read_group_dispatch_calls = 0;
	fake_perf_read_one_dispatch_calls = 0;
	fake_perf_read_dispatch_event = NULL;
	fake_perf_read_dispatch_format = 0;
	fake_perf_read_dispatch_buf = 0;
	fake_perf_read_group_dispatch_rc = 17;
	fake_perf_read_one_dispatch_rc = 9;
	fake_perf_counter_extra_calls = 0;
	fake_perf_counter_extra_event = NULL;
	fake_perf_counter_extra_rc = 0;
	fake_perf_counter_init_calls = 0;
	fake_perf_counter_init_counter = -1;
	fake_perf_counter_init_config = 0;
	fake_perf_counter_init_mode = 0;
	fake_perf_counter_init_rc = 0;
	fake_perf_counter_attr_calls = 0;
	fake_perf_counter_attr_ptr = NULL;
	fake_perf_counter_attr_rc = 0;
	fake_perf_start_mask_check_calls = 0;
	fake_perf_start_mask_check_last = 0;
	fake_perf_start_mask_check_accept = ~0UL;
	fake_perf_start_set_period_calls = 0;
	fake_perf_start_set_period_event = NULL;
	fake_perf_start_counter_set_calls = 0;
	fake_perf_start_counter_set_event = NULL;
	fake_perf_start_counter_set_rc = 0;
	fake_perf_start_hw_start_calls = 0;
	fake_perf_start_hw_start_mask = 0;
	fake_perf_start_hw_start_rc = 0;
	fake_perf_stop_hw_calls = 0;
	fake_perf_stop_hw_mask = 0;
	fake_perf_stop_hw_flags = -1;
	fake_perf_stop_hw_rc = 0;
	fake_perf_ioctl_start_calls = 0;
	fake_perf_ioctl_stop_calls = 0;
	fake_perf_ioctl_reset_calls = 0;
	fake_perf_ioctl_last_event = NULL;
	fake_perf_ioctl_find_calls = 0;
	fake_perf_ioctl_find_pid = -1;
	fake_perf_ioctl_find_lock = NULL;
	fake_perf_ioctl_find_result = NULL;
	fake_perf_ioctl_unlock_calls = 0;
	fake_perf_ioctl_unlock_proc = NULL;
	fake_perf_ioctl_unlock_lock = NULL;
	fake_perf_close_free_calls = 0;
	fake_perf_close_free_ptr = NULL;
	fake_perf_fcntl_forward_calls = 0;
	fake_perf_fcntl_forward_nr = -1;
	fake_perf_fcntl_forward_ctx = NULL;
	fake_perf_fcntl_forward_rc = 0;
	fake_perf_mmap_calls = 0;
	fake_perf_mmap_addr = 0;
	fake_perf_mmap_len = 0;
	fake_perf_mmap_prot = 0;
	fake_perf_mmap_flags = 0;
	fake_perf_mmap_fd = 0;
	fake_perf_mmap_off = 0;
	fake_perf_mmap_vrf0 = -1;
	fake_perf_mmap_private_data = (void *)1;
	fake_perf_mmap_rc = 0;
	fake_perf_open_lock_calls = 0;
	fake_perf_open_lock_arg = NULL;
	fake_perf_open_unlock_calls = 0;
	fake_perf_open_unlock_arg = NULL;
	fake_perf_open_unlock_flags = 0;
	fake_perf_open_counter_alloc_calls = 0;
	fake_perf_open_counter_alloc_thread = NULL;
	fake_perf_open_counter_alloc_event = NULL;
	fake_perf_open_counter_alloc_rc = 6;
	fake_perf_open_event_alloc_calls = 0;
	fake_perf_open_event_alloc_attr = NULL;
	fake_perf_open_event_alloc_result = NULL;
	fake_perf_open_event_alloc_rc = 0;
	fake_perf_open_copy_calls = 0;
	fake_perf_open_copy_src = 0;
	fake_perf_open_copy_bytes = 0;
	fake_perf_open_copy_rc = 0;
	fake_perf_open_attr_freq_calls = 0;
	fake_perf_open_syscall_calls = 0;
	fake_perf_open_syscall_req = NULL;
	fake_perf_open_syscall_cpu = -1;
	fake_perf_open_syscall_rc = 0;
	fake_perf_alloc_hw_map_calls = 0;
	fake_perf_alloc_cache_map_calls = 0;
	fake_perf_alloc_cache_extra_calls = 0;
	fake_perf_alloc_raw_map_calls = 0;
	fake_perf_alloc_validate_calls = 0;
	fake_perf_alloc_validate_last = 0;
	fake_perf_alloc_validate_reject = ~0UL;
	fake_perf_alloc_extra_id_calls = 0;
	fake_perf_alloc_extra_id_config = 0;
	fake_perf_alloc_extra_id_ext = 0;
	fake_perf_alloc_extra_id_rc = -1;
	fake_perf_alloc_msr_calls = 0;
	fake_perf_alloc_idx_calls = 0;
	fake_perf_alloc_hw_init_calls = 0;
	fake_perf_alloc_hw_init_event = NULL;
	fake_perf_alloc_hw_init_rc = 0;
	fake_perf_alloc_alloc_calls = 0;
	fake_perf_alloc_alloc_size = 0;
	fake_perf_alloc_alloc_flags = 0;
	fake_perf_alloc_alloc_result = NULL;
	fake_perf_alloc_free_calls = 0;
	fake_perf_alloc_free_ptr = NULL;
}

static unsigned long fake_perf_read_update(void *event)
{
	struct fake_perf_read_event *perf = event;

	fake_perf_read_update_calls++;
	fake_perf_read_update_event = event;
	perf->count.counter64 += 33;
	return (unsigned long)perf->count.counter64;
}

static long fake_perf_read_atomic_read(void *count)
{
	struct fake_sync_child_atomic64 *atomic = count;

	fake_perf_read_atomic_read_calls++;
	fake_perf_read_atomic_read_ptr = count;
	return atomic->counter64;
}

static int fake_perf_read_attr_flags(const void *attr, int *exclude_user,
				     int *exclude_kernel, int *inherit)
{
	const struct fake_perf_counter_attr *perf_attr = attr;

	fake_perf_read_attr_calls++;
	fake_perf_read_attr_ptr = attr;
	if (fake_perf_read_attr_rc) {
		return fake_perf_read_attr_rc;
	}
	if (!perf_attr || !exclude_user || !exclude_kernel || !inherit) {
		return -22;
	}

	*exclude_user = perf_attr->exclude_user;
	*exclude_kernel = perf_attr->exclude_kernel;
	*inherit = perf_attr->inherit;
	return 0;
}

static unsigned long fake_perf_read_value(void *event)
{
	struct fake_perf_read_event *perf = event;

	fake_perf_read_value_calls++;
	fake_perf_read_value_last_event = event;
	return perf->count.counter64;
}

static long fake_perf_read_copy_to_user(unsigned long dst_addr,
					const void *src, size_t bytes)
{
	unsigned long offset = dst_addr - fake_perf_read_copy_base;

	fake_perf_read_copy_calls++;
	fake_perf_read_copy_last_bytes = bytes;
	fake_perf_read_copy_last_offset = offset;
	if (fake_perf_read_copy_fail_call == fake_perf_read_copy_calls) {
		return -1;
	}

	memcpy((void *)dst_addr, src, bytes);
	return 0;
}

static long fake_perf_read_group_dispatch(void *event,
					  unsigned long read_format,
					  unsigned long buf_addr)
{
	fake_perf_read_group_dispatch_calls++;
	fake_perf_read_dispatch_event = event;
	fake_perf_read_dispatch_format = read_format;
	fake_perf_read_dispatch_buf = buf_addr;
	return fake_perf_read_group_dispatch_rc;
}

static long fake_perf_read_one_dispatch(void *event,
					unsigned long read_format,
					unsigned long buf_addr)
{
	fake_perf_read_one_dispatch_calls++;
	fake_perf_read_dispatch_event = event;
	fake_perf_read_dispatch_format = read_format;
	fake_perf_read_dispatch_buf = buf_addr;
	return fake_perf_read_one_dispatch_rc;
}

static int fake_perf_counter_extra_set(void *event)
{
	fake_perf_counter_extra_calls++;
	fake_perf_counter_extra_event = event;
	return fake_perf_counter_extra_rc;
}

static int fake_perf_counter_init_raw(int counter_id,
				      unsigned long hw_config, int mode)
{
	fake_perf_counter_init_calls++;
	fake_perf_counter_init_counter = counter_id;
	fake_perf_counter_init_config = hw_config;
	fake_perf_counter_init_mode = mode;
	return fake_perf_counter_init_rc;
}

static int fake_perf_counter_attr_flags(const void *attr,
					int *exclude_kernel,
					int *exclude_user)
{
	const struct fake_perf_counter_attr *perf_attr = attr;

	fake_perf_counter_attr_calls++;
	fake_perf_counter_attr_ptr = attr;
	if (fake_perf_counter_attr_rc) {
		return fake_perf_counter_attr_rc;
	}
	if (!perf_attr || !exclude_kernel || !exclude_user) {
		return -22;
	}
	*exclude_kernel = perf_attr->exclude_kernel;
	*exclude_user = perf_attr->exclude_user;
	return 0;
}

static int fake_perf_start_mask_check(unsigned long mask)
{
	fake_perf_start_mask_check_calls++;
	fake_perf_start_mask_check_last = mask;
	return (mask & fake_perf_start_mask_check_accept) != 0;
}

static int fake_perf_start_set_period(void *event)
{
	fake_perf_start_set_period_calls++;
	fake_perf_start_set_period_event = event;
	return 0;
}

static int fake_perf_start_counter_set(void *event)
{
	fake_perf_start_counter_set_calls++;
	fake_perf_start_counter_set_event = event;
	return fake_perf_start_counter_set_rc;
}

static int fake_perf_start_hw_start(unsigned long mask)
{
	fake_perf_start_hw_start_calls++;
	fake_perf_start_hw_start_mask = mask;
	return fake_perf_start_hw_start_rc;
}

static int fake_perf_stop_hw(unsigned long mask, int flags)
{
	fake_perf_stop_hw_calls++;
	fake_perf_stop_hw_mask = mask;
	fake_perf_stop_hw_flags = flags;
	return fake_perf_stop_hw_rc;
}

static void fake_perf_ioctl_start(void *event)
{
	fake_perf_ioctl_start_calls++;
	fake_perf_ioctl_last_event = event;
}

static void fake_perf_ioctl_stop(void *event)
{
	fake_perf_ioctl_stop_calls++;
	fake_perf_ioctl_last_event = event;
}

static void fake_perf_ioctl_reset_event(void *event)
{
	fake_perf_ioctl_reset_calls++;
	fake_perf_ioctl_last_event = event;
}

static void *fake_perf_ioctl_find(int pid, void *lock_arg)
{
	fake_perf_ioctl_find_calls++;
	fake_perf_ioctl_find_pid = pid;
	fake_perf_ioctl_find_lock = lock_arg;
	return fake_perf_ioctl_find_result;
}

static void fake_perf_ioctl_unlock(void *proc, void *lock_arg)
{
	fake_perf_ioctl_unlock_calls++;
	fake_perf_ioctl_unlock_proc = proc;
	fake_perf_ioctl_unlock_lock = lock_arg;
}

static void fake_perf_close_free(void *ptr)
{
	fake_perf_close_free_calls++;
	fake_perf_close_free_ptr = ptr;
}

static long fake_perf_fcntl_forward(int syscall_nr, void *ctx)
{
	fake_perf_fcntl_forward_calls++;
	fake_perf_fcntl_forward_nr = syscall_nr;
	fake_perf_fcntl_forward_ctx = ctx;
	return fake_perf_fcntl_forward_rc;
}

static long fake_perf_mmap_do(unsigned long addr, size_t len, int prot,
			      int flags, int fd, long off, int vrf0,
			      void *private_data)
{
	fake_perf_mmap_calls++;
	fake_perf_mmap_addr = addr;
	fake_perf_mmap_len = len;
	fake_perf_mmap_prot = prot;
	fake_perf_mmap_flags = flags;
	fake_perf_mmap_fd = fd;
	fake_perf_mmap_off = off;
	fake_perf_mmap_vrf0 = vrf0;
	fake_perf_mmap_private_data = private_data;
	return fake_perf_mmap_rc;
}

static long fake_perf_open_long_cb(void *fdp, void *ctx)
{
	return fdp == ctx ? 1 : 0;
}

static int fake_perf_open_int_cb(void *fdp, void *ctx)
{
	return fdp == ctx ? 1 : 0;
}

static long fake_perf_open_lock(void *lock)
{
	fake_perf_open_lock_calls++;
	fake_perf_open_lock_arg = lock;
	return 0x5a5a;
}

static void fake_perf_open_unlock(void *lock, long flags)
{
	fake_perf_open_unlock_calls++;
	fake_perf_open_unlock_arg = lock;
	fake_perf_open_unlock_flags = flags;
}

static int fake_perf_open_counter_alloc(void *thread, void *event)
{
	fake_perf_open_counter_alloc_calls++;
	fake_perf_open_counter_alloc_thread = thread;
	fake_perf_open_counter_alloc_event = event;
	return fake_perf_open_counter_alloc_rc;
}

static int fake_perf_open_event_alloc(void **event_out, void *attr)
{
	fake_perf_open_event_alloc_calls++;
	fake_perf_open_event_alloc_attr = attr;
	if (fake_perf_open_event_alloc_result) {
		*event_out = fake_perf_open_event_alloc_result;
	}
	return fake_perf_open_event_alloc_rc;
}

static long fake_perf_open_copy_from_user(void *dst, unsigned long src_addr,
					  size_t bytes)
{
	fake_perf_open_copy_calls++;
	fake_perf_open_copy_src = src_addr;
	fake_perf_open_copy_bytes = bytes;
	if (fake_perf_open_copy_rc) {
		return fake_perf_open_copy_rc;
	}
	memcpy(dst, (const void *)src_addr, bytes);
	return 0;
}

static int fake_perf_open_attr_freq(const void *attr)
{
	const struct fake_perf_open_attr *perf_attr = attr;

	fake_perf_open_attr_freq_calls++;
	return perf_attr->freq;
}

static long fake_perf_open_syscall(struct fake_syscall_request *request,
				   int cpu)
{
	fake_perf_open_syscall_calls++;
	fake_perf_open_syscall_req = request;
	fake_perf_open_syscall_cpu = cpu;
	return fake_perf_open_syscall_rc;
}

static unsigned long fake_perf_alloc_hw_map(unsigned long config)
{
	fake_perf_alloc_hw_map_calls++;
	return 0x1000UL + config;
}

static unsigned long fake_perf_alloc_cache_map(unsigned long config)
{
	fake_perf_alloc_cache_map_calls++;
	return 0x2000UL + config;
}

static unsigned long fake_perf_alloc_cache_extra(unsigned long config)
{
	fake_perf_alloc_cache_extra_calls++;
	return 0x30UL + config;
}

static unsigned long fake_perf_alloc_raw_map(unsigned long config)
{
	fake_perf_alloc_raw_map_calls++;
	return 0x3000UL + config;
}

static int fake_perf_alloc_validate(unsigned long hw_config)
{
	fake_perf_alloc_validate_calls++;
	fake_perf_alloc_validate_last = hw_config;
	return hw_config != fake_perf_alloc_validate_reject;
}

static int fake_perf_alloc_extra_id(unsigned long hw_config,
				    unsigned long hw_config_ext)
{
	fake_perf_alloc_extra_id_calls++;
	fake_perf_alloc_extra_id_config = hw_config;
	fake_perf_alloc_extra_id_ext = hw_config_ext;
	return fake_perf_alloc_extra_id_rc;
}

static unsigned int fake_perf_alloc_extra_msr(int id)
{
	fake_perf_alloc_msr_calls++;
	return 0xabc000U + (unsigned int)id;
}

static int fake_perf_alloc_extra_idx(int id)
{
	fake_perf_alloc_idx_calls++;
	return id + 7;
}

static int fake_perf_alloc_hw_init(void *event)
{
	fake_perf_alloc_hw_init_calls++;
	fake_perf_alloc_hw_init_event = event;
	return fake_perf_alloc_hw_init_rc;
}

static void *fake_perf_alloc_alloc(size_t size, unsigned long flags)
{
	fake_perf_alloc_alloc_calls++;
	fake_perf_alloc_alloc_size = size;
	fake_perf_alloc_alloc_flags = flags;
	return fake_perf_alloc_alloc_result;
}

static void fake_perf_alloc_free(void *ptr)
{
	fake_perf_alloc_free_calls++;
	fake_perf_alloc_free_ptr = ptr;
}

static void fake_process_cleanup_reset(void *find_result)
{
	fake_process_cleanup_find_calls = 0;
	fake_process_cleanup_find_pid = -1;
	fake_process_cleanup_find_lock = NULL;
	fake_process_cleanup_find_result = find_result;
	fake_process_cleanup_unlock_calls = 0;
	fake_process_cleanup_unlock_proc = NULL;
	fake_process_cleanup_unlock_lock = NULL;
	fake_process_cleanup_cleanup_calls = 0;
	fake_process_cleanup_cleanup_proc = NULL;
	fake_process_cleanup_cleanup_fd = -1;
	fake_process_cleanup_cleanup_first_fd = -1;
	fake_process_cleanup_cleanup_last_fd = -1;
	fake_process_cleanup_cleanup_fd_sum = 0;
	fake_process_cleanup_cleanup_rc = 0;
	fake_process_cleanup_missing_log_calls = 0;
	fake_process_cleanup_missing_log_pid = -1;
	fake_process_cleanup_sequence = 0;
	fake_process_cleanup_cleanup_sequence = 0;
	fake_process_cleanup_unlock_sequence = 0;
}

static void *
fake_process_cleanup_find(int pid, void *lock_arg)
{
	fake_process_cleanup_find_calls++;
	fake_process_cleanup_find_pid = pid;
	fake_process_cleanup_find_lock = lock_arg;
	return fake_process_cleanup_find_result;
}

static void
fake_process_cleanup_unlock(void *proc, void *lock_arg)
{
	fake_process_cleanup_unlock_calls++;
	fake_process_cleanup_unlock_proc = proc;
	fake_process_cleanup_unlock_lock = lock_arg;
	fake_process_cleanup_unlock_sequence = ++fake_process_cleanup_sequence;
}

static long
fake_process_cleanup_fd(void *proc, int fd)
{
	fake_process_cleanup_cleanup_calls++;
	fake_process_cleanup_cleanup_proc = proc;
	fake_process_cleanup_cleanup_fd = fd;
	if (fake_process_cleanup_cleanup_calls == 1)
		fake_process_cleanup_cleanup_first_fd = fd;
	fake_process_cleanup_cleanup_last_fd = fd;
	fake_process_cleanup_cleanup_fd_sum += fd;
	fake_process_cleanup_cleanup_sequence = ++fake_process_cleanup_sequence;
	return fake_process_cleanup_cleanup_rc;
}

static void
fake_process_cleanup_missing_log(int pid)
{
	fake_process_cleanup_missing_log_calls++;
	fake_process_cleanup_missing_log_pid = pid;
}

static void *
fake_terminate_host_find(int pid, void *lock_arg)
{
	fake_terminate_host_find_calls++;
	fake_terminate_host_find_pid = pid;
	fake_terminate_host_find_lock = lock_arg;
	return fake_terminate_host_find_result;
}

static void
fake_terminate_host_unlock(void *proc, void *lock_arg)
{
	fake_terminate_host_unlock_calls++;
	fake_terminate_host_unlock_proc = proc;
	fake_terminate_host_unlock_lock = lock_arg;
}

static void
fake_terminate_host_ref_set(void *refcount, int value)
{
	fake_terminate_host_ref_set_calls++;
	fake_terminate_host_ref_set_ptr = refcount;
	fake_terminate_host_ref_set_value = value;
	*(int *)refcount = value;
}

static void
fake_terminate_host_release_thread(void *thread)
{
	fake_terminate_host_release_thread_calls++;
	fake_terminate_host_release_thread_ptr = thread;
}

static void
fake_terminate_host_release_process(void *proc)
{
	fake_terminate_host_release_process_calls++;
	fake_terminate_host_release_process_ptr = proc;
}

static void
fake_refresh_uid(void)
{
	fake_refresh_uid_calls++;
}

static void
fake_refresh_gid(void)
{
	fake_refresh_gid_calls++;
}

static int *
fake_getcred(int *buf)
{
	fake_getcred_calls++;
	fake_getcred_buf = buf;
	for (int i = 0; i < 8; i++)
		buf[i] = fake_getcred_values[i];
	return buf;
}

static int
fake_processor_id(void)
{
	fake_processor_id_calls++;
	return fake_processor_id_value;
}

static unsigned long
fake_virt_to_phys(void *addr)
{
	fake_virt_to_phys_calls++;
	fake_virt_to_phys_ptr = addr;
	return fake_virt_to_phys_value;
}

static void
fake_gettime(void *ts)
{
	struct timespec *wts = ts;

	fake_gettime_calls++;
	wts->tv_sec = 12;
	wts->tv_nsec = 345678900;
}

static void
fake_do_futex_reset(void)
{
	fake_do_futex_digest = 0x4655544558424f44UL;
	fake_do_futex_syscall_time_calls = 0;
	fake_do_futex_syscall_nr = 0;
	fake_do_futex_syscall_clock = 0;
	fake_do_futex_syscall_fail = 0;
	fake_do_futex_local_time_calls = 0;
	fake_do_futex_linux_time_calls = 0;
	fake_do_futex_linux_clock = 0;
	fake_do_futex_linux_fail = 0;
	fake_do_futex_ns_per_tsc_calls = 0;
	fake_do_futex_dispatch_calls = 0;
	fake_do_futex_log_calls = 0;
}

static int
fake_do_futex_syscall_time(int syscall_nr, int clock_id, struct timespec *ts)
{
	fake_do_futex_syscall_time_calls++;
	fake_do_futex_syscall_nr = syscall_nr;
	fake_do_futex_syscall_clock = clock_id;
	if (fake_do_futex_syscall_fail)
		return -1;
	ts->tv_sec = 20;
	ts->tv_nsec = 300;
	return 0;
}

static void
fake_do_futex_local_time(struct timespec *ts)
{
	fake_do_futex_local_time_calls++;
	ts->tv_sec = 30;
	ts->tv_nsec = 400;
}

static int
fake_do_futex_linux_time(int clock_id, struct timespec *ts)
{
	fake_do_futex_linux_time_calls++;
	fake_do_futex_linux_clock = clock_id;
	if (fake_do_futex_linux_fail)
		return -77;
	ts->tv_sec = 40;
	ts->tv_nsec = 500;
	return 0;
}

static unsigned long
fake_do_futex_ns_per_tsc(void)
{
	fake_do_futex_ns_per_tsc_calls++;
	return 10;
}

static int
fake_do_futex_dispatch(unsigned long uaddr, int op, uint32_t val,
		       uint64_t timeout, unsigned long uaddr2, uint32_t val2,
		       uint32_t val3, int fshared)
{
	fake_do_futex_dispatch_calls++;
	mix(&fake_do_futex_digest, uaddr);
	mix_signed(&fake_do_futex_digest, op);
	mix(&fake_do_futex_digest, val);
	mix(&fake_do_futex_digest, timeout);
	mix(&fake_do_futex_digest, uaddr2);
	mix(&fake_do_futex_digest, val2);
	mix(&fake_do_futex_digest, val3);
	mix_signed(&fake_do_futex_digest, fshared);
	return 900 + op + fshared;
}

static void
fake_do_futex_log(const struct fake_do_futex_log_record *record)
{
	fake_do_futex_log_calls++;
	mix_signed(&fake_do_futex_digest, record->event);
	mix_signed(&fake_do_futex_digest, record->flags);
	mix_signed(&fake_do_futex_digest, record->op);
	mix(&fake_do_futex_digest, record->uaddr);
	mix(&fake_do_futex_digest, record->val);
	mix(&fake_do_futex_digest, record->utime != 0);
	mix(&fake_do_futex_digest, record->uaddr2);
	mix(&fake_do_futex_digest, record->val3);
	mix_signed(&fake_do_futex_digest, record->fshared);
	mix_signed(&fake_do_futex_digest, record->ret);
	mix_signed(&fake_do_futex_digest, record->sec);
	mix_signed(&fake_do_futex_digest, record->nsec);
}

static void
fake_brk_reset(unsigned long extend_result)
{
	fake_brk_digest = 0x42524b424f44594UL;
	fake_brk_flush_calls = 0;
	fake_brk_lock_calls = 0;
	fake_brk_unlock_calls = 0;
	fake_brk_extend_calls = 0;
	fake_brk_extend_result = extend_result;
	fake_brk_extend_old = 0;
	fake_brk_extend_address = 0;
	fake_brk_extend_vrflag = 0;
	fake_brk_log_calls = 0;
}

static void
fake_brk_flush(void)
{
	fake_brk_flush_calls++;
	mix_signed(&fake_brk_digest, 11);
}

static void
fake_brk_lock(void *lock)
{
	fake_brk_lock_calls++;
	mix(&fake_brk_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_brk_unlock(void *lock)
{
	fake_brk_unlock_calls++;
	mix(&fake_brk_digest, (unsigned long)(uintptr_t)lock != 0);
}

static unsigned long
fake_brk_extend(void *vm, unsigned long old_end, unsigned long address,
		unsigned long vrflag)
{
	fake_brk_extend_calls++;
	fake_brk_extend_old = old_end;
	fake_brk_extend_address = address;
	fake_brk_extend_vrflag = vrflag;
	mix(&fake_brk_digest, (unsigned long)(uintptr_t)vm != 0);
	mix(&fake_brk_digest, old_end);
	mix(&fake_brk_digest, address);
	mix(&fake_brk_digest, vrflag);
	return fake_brk_extend_result;
}

static void
fake_brk_log(int event, int cpu, unsigned long brk_start,
	     unsigned long brk_end, unsigned long value)
{
	fake_brk_log_calls++;
	mix_signed(&fake_brk_digest, event);
	mix_signed(&fake_brk_digest, cpu);
	mix(&fake_brk_digest, brk_start);
	mix(&fake_brk_digest, brk_end);
	mix(&fake_brk_digest, value);
}

static void
fake_munmap_reset(int rc)
{
	fake_munmap_digest = 0x4d554e4d41504UL;
	fake_munmap_lock_calls = 0;
	fake_munmap_unlock_calls = 0;
	fake_munmap_do_calls = 0;
	fake_munmap_do_rc = rc;
	fake_munmap_do_addr = 0;
	fake_munmap_do_len = 0;
	fake_munmap_do_holding = 0;
	fake_munmap_log_calls = 0;
}

static void
fake_munmap_lock(void *lock)
{
	fake_munmap_lock_calls++;
	mix(&fake_munmap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_munmap_unlock(void *lock)
{
	fake_munmap_unlock_calls++;
	mix(&fake_munmap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static int
fake_munmap_do(void *addr, size_t len, int holding)
{
	fake_munmap_do_calls++;
	fake_munmap_do_addr = (unsigned long)(uintptr_t)addr;
	fake_munmap_do_len = len;
	fake_munmap_do_holding = holding;
	mix(&fake_munmap_digest, fake_munmap_do_addr);
	mix(&fake_munmap_digest, len);
	mix_signed(&fake_munmap_digest, holding);
	return fake_munmap_do_rc;
}

static void
fake_munmap_log(int event, int cpu, unsigned long addr, size_t len, int error)
{
	fake_munmap_log_calls++;
	mix_signed(&fake_munmap_digest, event);
	mix_signed(&fake_munmap_digest, cpu);
	mix(&fake_munmap_digest, addr);
	mix(&fake_munmap_digest, len);
	mix_signed(&fake_munmap_digest, error);
}

static void
fake_do_munmap_reset(int remove_rc, int ro_freed)
{
	fake_do_munmap_digest = 0x444f4d554e4d4150UL;
	fake_do_munmap_begin_calls = 0;
	fake_do_munmap_finish_calls = 0;
	fake_do_munmap_remove_calls = 0;
	fake_do_munmap_remove_rc = remove_rc;
	fake_do_munmap_ro_freed = ro_freed;
	fake_do_munmap_remove_start = 0;
	fake_do_munmap_remove_end = 0;
	fake_do_munmap_clear_calls = 0;
	fake_do_munmap_clear_addr = 0;
	fake_do_munmap_clear_len = 0;
	fake_do_munmap_clear_holding = 0;
	fake_do_munmap_sethost_calls = 0;
	fake_do_munmap_sethost_rc = 0;
	fake_do_munmap_sethost_addr = 0;
	fake_do_munmap_sethost_len = 0;
	fake_do_munmap_sethost_prot = 0;
	fake_do_munmap_sethost_holding = 0;
	fake_do_munmap_log_calls = 0;
}

static void
fake_do_munmap_begin(void)
{
	fake_do_munmap_begin_calls++;
	mix(&fake_do_munmap_digest, 0x424547494eUL);
}

static int
fake_do_munmap_remove(void *vm, unsigned long start, unsigned long end,
		      int *ro_freedp)
{
	fake_do_munmap_remove_calls++;
	fake_do_munmap_remove_start = start;
	fake_do_munmap_remove_end = end;
	if (ro_freedp)
		*ro_freedp = fake_do_munmap_ro_freed;
	mix(&fake_do_munmap_digest, (unsigned long)(uintptr_t)vm != 0);
	mix(&fake_do_munmap_digest, start);
	mix(&fake_do_munmap_digest, end);
	mix_signed(&fake_do_munmap_digest, fake_do_munmap_ro_freed);
	return fake_do_munmap_remove_rc;
}

static void
fake_do_munmap_clear(unsigned long addr, size_t len, int holding)
{
	fake_do_munmap_clear_calls++;
	fake_do_munmap_clear_addr = addr;
	fake_do_munmap_clear_len = len;
	fake_do_munmap_clear_holding = holding;
	mix(&fake_do_munmap_digest, addr);
	mix(&fake_do_munmap_digest, len);
	mix_signed(&fake_do_munmap_digest, holding);
}

static int
fake_do_munmap_sethost(unsigned long addr, size_t len, int prot, int holding)
{
	fake_do_munmap_sethost_calls++;
	fake_do_munmap_sethost_addr = addr;
	fake_do_munmap_sethost_len = len;
	fake_do_munmap_sethost_prot = prot;
	fake_do_munmap_sethost_holding = holding;
	mix(&fake_do_munmap_digest, addr);
	mix(&fake_do_munmap_digest, len);
	mix_signed(&fake_do_munmap_digest, prot);
	mix_signed(&fake_do_munmap_digest, holding);
	return fake_do_munmap_sethost_rc;
}

static void
fake_do_munmap_finish(void)
{
	fake_do_munmap_finish_calls++;
	mix(&fake_do_munmap_digest, 0x46494e495348UL);
}

static void
fake_do_munmap_log(unsigned long addr, size_t len, int error)
{
	fake_do_munmap_log_calls++;
	mix(&fake_do_munmap_digest, addr);
	mix(&fake_do_munmap_digest, len);
	mix_signed(&fake_do_munmap_digest, error);
}

static void
fake_clear_host_reset(long forward_rc)
{
	fake_clear_host_digest = 0x434c5248505445UL;
	fake_clear_host_forward_calls = 0;
	fake_clear_host_forward_rc = forward_rc;
	fake_clear_host_forward_nr = 0;
	fake_clear_host_forward_arg0 = 0;
	fake_clear_host_forward_arg1 = 0;
	fake_clear_host_forward_arg2 = 0;
	fake_clear_host_log_calls = 0;
	fake_clear_host_log_error = 0;
}

static long
fake_clear_host_forward(int syscall_nr, unsigned long arg0,
			unsigned long arg1, unsigned long arg2)
{
	fake_clear_host_forward_calls++;
	fake_clear_host_forward_nr = syscall_nr;
	fake_clear_host_forward_arg0 = arg0;
	fake_clear_host_forward_arg1 = arg1;
	fake_clear_host_forward_arg2 = arg2;
	mix_signed(&fake_clear_host_digest, syscall_nr);
	mix(&fake_clear_host_digest, arg0);
	mix(&fake_clear_host_digest, arg1);
	mix(&fake_clear_host_digest, arg2);
	return fake_clear_host_forward_rc;
}

static void
fake_clear_host_log(long error)
{
	fake_clear_host_log_calls++;
	fake_clear_host_log_error = error;
	mix_signed(&fake_clear_host_digest, error);
}

static void
fake_munmap_all_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_munmap_all_digest = 0x4d554e414c4cUL;
	fake_munmap_all_ranges = ranges;
	fake_munmap_all_range_count = range_count;
	fake_munmap_all_lock_calls = 0;
	fake_munmap_all_unlock_calls = 0;
	fake_munmap_all_lookup_calls = 0;
	fake_munmap_all_next_calls = 0;
	fake_munmap_all_do_calls = 0;
	fake_munmap_all_do_fail_index = -1;
	fake_munmap_all_last_addr = 0;
	fake_munmap_all_last_size = 0;
	fake_munmap_all_free_calls = 0;
	fake_munmap_all_log_calls = 0;
}

static void
fake_munmap_all_lock(void *lock)
{
	fake_munmap_all_lock_calls++;
	mix(&fake_munmap_all_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_munmap_all_unlock(void *lock)
{
	fake_munmap_all_unlock_calls++;
	mix(&fake_munmap_all_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_munmap_all_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_munmap_all_lookup_calls++;
	mix(&fake_munmap_all_digest, start);
	mix(&fake_munmap_all_digest, end);
	return fake_munmap_all_range_count > 0 ? &fake_munmap_all_ranges[0] :
		NULL;
}

static void *
fake_munmap_all_next(void *vm, void *range)
{
	(void)vm;
	fake_munmap_all_next_calls++;
	mix(&fake_munmap_all_digest, (unsigned long)(uintptr_t)range != 0);
	for (int i = 0; i < fake_munmap_all_range_count - 1; i++) {
		if (&fake_munmap_all_ranges[i] == range)
			return &fake_munmap_all_ranges[i + 1];
	}
	return NULL;
}

static int
fake_munmap_all_do(void *addr, size_t size, int holding)
{
	fake_munmap_all_do_calls++;
	fake_munmap_all_last_addr = (unsigned long)(uintptr_t)addr;
	fake_munmap_all_last_size = size;
	mix(&fake_munmap_all_digest, fake_munmap_all_last_addr);
	mix(&fake_munmap_all_digest, size);
	mix_signed(&fake_munmap_all_digest, holding);
	if (fake_munmap_all_do_calls == fake_munmap_all_do_fail_index)
		return -16;
	return 0;
}

static void
fake_munmap_all_free(void *vm)
{
	(void)vm;
	fake_munmap_all_free_calls++;
	mix(&fake_munmap_all_digest, 0x46524545UL);
}

static void
fake_munmap_all_log(unsigned long addr, size_t size, int error)
{
	fake_munmap_all_log_calls++;
	mix(&fake_munmap_all_digest, addr);
	mix(&fake_munmap_all_digest, size);
	mix_signed(&fake_munmap_all_digest, error);
}

static void
fake_shmdt_reset(struct fake_msync_range *ranges, int range_count, int rc)
{
	fake_shmdt_digest = 0x53484d4454UL;
	fake_shmdt_ranges = ranges;
	fake_shmdt_range_count = range_count;
	fake_shmdt_lock_calls = 0;
	fake_shmdt_unlock_calls = 0;
	fake_shmdt_lookup_calls = 0;
	fake_shmdt_munmap_calls = 0;
	fake_shmdt_munmap_rc = rc;
	fake_shmdt_munmap_addr = 0;
	fake_shmdt_munmap_len = 0;
	fake_shmdt_munmap_holding = 0;
	fake_shmdt_log_calls = 0;
}

static void
fake_shmdt_lock(void *lock)
{
	fake_shmdt_lock_calls++;
	mix(&fake_shmdt_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_shmdt_unlock(void *lock)
{
	fake_shmdt_unlock_calls++;
	mix(&fake_shmdt_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_shmdt_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_shmdt_lookup_calls++;
	mix(&fake_shmdt_digest, start);
	mix(&fake_shmdt_digest, end);
	for (int i = 0; i < fake_shmdt_range_count; i++) {
		if (fake_shmdt_ranges[i].start <= start &&
				start < fake_shmdt_ranges[i].end) {
			return &fake_shmdt_ranges[i];
		}
	}
	return NULL;
}

static int
fake_shmdt_munmap(void *addr, size_t len, int holding)
{
	fake_shmdt_munmap_calls++;
	fake_shmdt_munmap_addr = (unsigned long)(uintptr_t)addr;
	fake_shmdt_munmap_len = len;
	fake_shmdt_munmap_holding = holding;
	mix(&fake_shmdt_digest, fake_shmdt_munmap_addr);
	mix(&fake_shmdt_digest, len);
	mix_signed(&fake_shmdt_digest, holding);
	return fake_shmdt_munmap_rc;
}

static void
fake_shmdt_log(int event, unsigned long addr, int error)
{
	fake_shmdt_log_calls++;
	mix_signed(&fake_shmdt_digest, event);
	mix(&fake_shmdt_digest, addr);
	mix_signed(&fake_shmdt_digest, error);
}

static void
fake_shmat_reset(struct fake_shmat_obj *obj)
{
	fake_shmat_digest = 0x53484d4154UL;
	fake_shmat_obj = obj;
	fake_shmat_lookup_rc = 0;
	fake_shmat_list_lock_calls = 0;
	fake_shmat_list_unlock_calls = 0;
	fake_shmat_lookup_calls = 0;
	fake_shmat_unref_calls = 0;
	fake_shmat_range_lock_calls = 0;
	fake_shmat_range_unlock_calls = 0;
	fake_shmat_lookup_range_calls = 0;
	fake_shmat_range_busy = 0;
	fake_shmat_search_calls = 0;
	fake_shmat_search_rc = 0;
	fake_shmat_search_addr = 0;
	fake_shmat_sethost_calls = 0;
	fake_shmat_sethost_rc = 0;
	fake_shmat_sethost_start = 0;
	fake_shmat_sethost_len = 0;
	fake_shmat_sethost_prot = 0;
	fake_shmat_add_calls = 0;
	fake_shmat_add_rc = 0;
	fake_shmat_add_start = 0;
	fake_shmat_add_end = 0;
	fake_shmat_add_flags = 0;
	fake_shmat_add_pgshift = 0;
	fake_shmat_log_calls = 0;
}

static void
fake_shmat_list_lock(void)
{
	fake_shmat_list_lock_calls++;
	mix(&fake_shmat_digest, 0x4c4f434bUL);
}

static void
fake_shmat_list_unlock(void)
{
	fake_shmat_list_unlock_calls++;
	mix(&fake_shmat_digest, 0x554e4c4bUL);
}

static int
fake_shmat_lookup(int shmid, void **objp)
{
	fake_shmat_lookup_calls++;
	mix_signed(&fake_shmat_digest, shmid);
	if (fake_shmat_lookup_rc)
		return fake_shmat_lookup_rc;
	if (objp)
		*objp = fake_shmat_obj;
	mix(&fake_shmat_digest, fake_shmat_obj != NULL);
	return 0;
}

static void
fake_shmat_unref(void *memobj)
{
	fake_shmat_unref_calls++;
	mix(&fake_shmat_digest, fake_shmat_obj != NULL &&
			memobj == &fake_shmat_obj->memobj);
}

static void
fake_shmat_range_lock(void *lock)
{
	fake_shmat_range_lock_calls++;
	mix(&fake_shmat_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_shmat_range_unlock(void *lock)
{
	fake_shmat_range_unlock_calls++;
	mix(&fake_shmat_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_shmat_lookup_range(void *vm, unsigned long start, unsigned long end)
{
	static int busy;

	(void)vm;
	fake_shmat_lookup_range_calls++;
	mix(&fake_shmat_digest, start);
	mix(&fake_shmat_digest, end);
	return fake_shmat_range_busy ? &busy : NULL;
}

static int
fake_shmat_search(size_t len, int pgshift, unsigned long *addrp)
{
	fake_shmat_search_calls++;
	mix(&fake_shmat_digest, len);
	mix_signed(&fake_shmat_digest, pgshift);
	if (addrp)
		*addrp = fake_shmat_search_addr;
	return fake_shmat_search_rc;
}

static int
fake_shmat_set_host_vma(unsigned long start, size_t len, int prot,
			int holding_lock)
{
	fake_shmat_sethost_calls++;
	fake_shmat_sethost_start = start;
	fake_shmat_sethost_len = len;
	fake_shmat_sethost_prot = prot;
	mix(&fake_shmat_digest, start);
	mix(&fake_shmat_digest, len);
	mix_signed(&fake_shmat_digest, prot);
	mix_signed(&fake_shmat_digest, holding_lock);
	return fake_shmat_sethost_rc;
}

static int
fake_shmat_add_range(void *vm, unsigned long start, unsigned long end,
		     unsigned long phys, unsigned long flags, void *memobj,
		     long objoff, int pgshift)
{
	(void)vm;
	fake_shmat_add_calls++;
	fake_shmat_add_start = start;
	fake_shmat_add_end = end;
	fake_shmat_add_flags = flags;
	fake_shmat_add_pgshift = pgshift;
	mix(&fake_shmat_digest, start);
	mix(&fake_shmat_digest, end);
	mix(&fake_shmat_digest, phys == ~0UL);
	mix(&fake_shmat_digest, flags);
	mix(&fake_shmat_digest, fake_shmat_obj != NULL &&
			memobj == &fake_shmat_obj->memobj);
	mix_signed(&fake_shmat_digest, objoff);
	mix_signed(&fake_shmat_digest, pgshift);
	return fake_shmat_add_rc;
}

static void
fake_shmat_log(int event, int shmid, unsigned long shmaddr, int shmflg,
	       long error)
{
	fake_shmat_log_calls++;
	mix_signed(&fake_shmat_digest, event);
	mix_signed(&fake_shmat_digest, shmid);
	mix(&fake_shmat_digest, shmaddr);
	mix_signed(&fake_shmat_digest, shmflg);
	mix_signed(&fake_shmat_digest, error);
}

extern long shmat_body_result(int, unsigned long, int, unsigned int,
			      unsigned int, void *, void *, size_t, size_t,
			      size_t, size_t, size_t, size_t, size_t, size_t,
			      void (*)(void), void (*)(void),
			      int (*)(int, void **), void (*)(void *),
			      void (*)(void *), void (*)(void *),
			      void *(*)(void *, unsigned long, unsigned long),
			      int (*)(size_t, int, unsigned long *),
			      int (*)(unsigned long, size_t, int, int),
			      int (*)(void *, unsigned long, unsigned long,
				      unsigned long, unsigned long, void *,
				      long, int),
			      void (*)(int, int, unsigned long, int, long));

static long
fake_shmat_call(int shmid, unsigned long shmaddr, int shmflg,
		unsigned int euid, unsigned int egid)
{
	int fake_vm;
	int fake_lock;

	return shmat_body_result(shmid, shmaddr, shmflg, euid, egid,
		&fake_vm, &fake_lock,
		offsetof(struct fake_shmat_obj, pgshift),
		offsetof(struct fake_shmat_obj, real_segsz),
		offsetof(struct fake_shmat_obj, memobj),
		offsetof(struct fake_shmat_obj, uid),
		offsetof(struct fake_shmat_obj, cuid),
		offsetof(struct fake_shmat_obj, gid),
		offsetof(struct fake_shmat_obj, cgid),
		offsetof(struct fake_shmat_obj, mode),
		fake_shmat_list_lock, fake_shmat_list_unlock,
		fake_shmat_lookup, fake_shmat_unref, fake_shmat_range_lock,
		fake_shmat_range_unlock, fake_shmat_lookup_range,
		fake_shmat_search, fake_shmat_set_host_vma,
		fake_shmat_add_range, fake_shmat_log);
}

static const struct fake_shmctl_offsets fake_shmctl_offsets = {
	.obj_memobj_offset = offsetof(struct fake_shmctl_obj, memobj),
	.obj_pgshift_offset = offsetof(struct fake_shmctl_obj, pgshift),
	.obj_real_segsz_offset = offsetof(struct fake_shmctl_obj, real_segsz),
	.obj_user_offset = offsetof(struct fake_shmctl_obj, user),
	.obj_ds_offset = offsetof(struct fake_shmctl_obj, ds),
	.obj_uid_offset = offsetof(struct fake_shmctl_obj, ds.shm_perm.uid),
	.obj_cuid_offset = offsetof(struct fake_shmctl_obj, ds.shm_perm.cuid),
	.obj_gid_offset = offsetof(struct fake_shmctl_obj, ds.shm_perm.gid),
	.obj_cgid_offset = offsetof(struct fake_shmctl_obj, ds.shm_perm.cgid),
	.obj_mode_offset = offsetof(struct fake_shmctl_obj, ds.shm_perm.mode),
	.obj_ctime_offset = offsetof(struct fake_shmctl_obj, ds.shm_ctime),
	.obj_nattch_offset = offsetof(struct fake_shmctl_obj, ds.shm_nattch),
	.shmlock_user_locked_offset = offsetof(struct fake_shmlock_user, locked),
	.shmid_ds_size = sizeof(struct fake_shmid_ds),
	.shminfo_size = sizeof(struct fake_shminfo),
	.shm_info_size = sizeof(struct fake_shm_info),
};

static struct fake_shminfo fake_shmctl_shminfo = {
	.shmmax = 0x1111,
	.shmmin = 1,
	.shmmni = 0x2222,
	.shmseg = 0x3333,
	.shmall = 0x4444,
};

static struct fake_shm_info fake_shmctl_shm_info = {
	.used_ids = 9,
	.shm_tot = 0xaaaa,
	.shm_rss = 0xbbbb,
	.shm_swp = 0xcccc,
	.swap_attempts = 0xdddd,
	.swap_successes = 0xeeee,
};

static void
fake_shmctl_reset(struct fake_shmctl_obj *obj,
		  struct fake_shmlock_user *user)
{
	fake_shmctl_digest = 0x53484d43544cUL;
	fake_shmctl_obj = obj;
	fake_shmctl_index_obj = obj;
	fake_shmctl_user = user;
	fake_shmctl_lookup_rc = 0;
	fake_shmctl_lookup_index_rc = 0;
	fake_shmctl_list_lock_calls = 0;
	fake_shmctl_list_unlock_calls = 0;
	fake_shmctl_lookup_calls = 0;
	fake_shmctl_lookup_index_calls = 0;
	fake_shmctl_unref_calls = 0;
	fake_shmctl_copy_from_calls = 0;
	fake_shmctl_copy_to_calls = 0;
	fake_shmctl_copy_from_rc = 0;
	fake_shmctl_copy_to_rc = 0;
	fake_shmctl_max_index = 37;
	fake_shmctl_max_index_calls = 0;
	fake_shmctl_users_lock_calls = 0;
	fake_shmctl_users_unlock_calls = 0;
	fake_shmctl_user_get_calls = 0;
	fake_shmctl_user_get_rc = 0;
	fake_shmctl_user_free_calls = 0;
	fake_shmctl_refcnt_calls = 0;
	fake_shmctl_refcnt_value = 5;
	fake_shmctl_log_calls = 0;
	fake_shmctl_last_log_event = 0;
}

static void
fake_shmctl_list_lock(void)
{
	fake_shmctl_list_lock_calls++;
	mix(&fake_shmctl_digest, 0x53484c4bUL);
}

static void
fake_shmctl_list_unlock(void)
{
	fake_shmctl_list_unlock_calls++;
	mix(&fake_shmctl_digest, 0x5348554cUL);
}

static int
fake_shmctl_lookup(int shmid, void **objp)
{
	fake_shmctl_lookup_calls++;
	mix_signed(&fake_shmctl_digest, shmid);
	if (fake_shmctl_lookup_rc)
		return fake_shmctl_lookup_rc;
	if (objp)
		*objp = fake_shmctl_obj;
	mix(&fake_shmctl_digest, fake_shmctl_obj != NULL);
	return 0;
}

static int
fake_shmctl_lookup_by_index(int index, void **objp)
{
	fake_shmctl_lookup_index_calls++;
	mix_signed(&fake_shmctl_digest, index);
	if (fake_shmctl_lookup_index_rc)
		return fake_shmctl_lookup_index_rc;
	if (objp)
		*objp = fake_shmctl_index_obj;
	mix(&fake_shmctl_digest, fake_shmctl_index_obj != NULL);
	return 0;
}

static void
fake_shmctl_unref(void *memobj)
{
	fake_shmctl_unref_calls++;
	mix(&fake_shmctl_digest, fake_shmctl_obj != NULL &&
			memobj == &fake_shmctl_obj->memobj);
}

static long
fake_shmctl_copy_from(void *dst, unsigned long src, size_t bytes)
{
	fake_shmctl_copy_from_calls++;
	mix(&fake_shmctl_digest, bytes);
	if (fake_shmctl_copy_from_rc)
		return fake_shmctl_copy_from_rc;
	memcpy(dst, (void *)(uintptr_t)src, bytes);
	return 0;
}

static long
fake_shmctl_copy_to(unsigned long dst, const void *src, size_t bytes)
{
	fake_shmctl_copy_to_calls++;
	mix(&fake_shmctl_digest, bytes);
	if (fake_shmctl_copy_to_rc)
		return fake_shmctl_copy_to_rc;
	memcpy((void *)(uintptr_t)dst, src, bytes);
	return 0;
}

static int
fake_shmctl_get_max_index(void)
{
	fake_shmctl_max_index_calls++;
	mix_signed(&fake_shmctl_digest, fake_shmctl_max_index);
	return fake_shmctl_max_index;
}

static void
fake_shmctl_users_lock(void)
{
	fake_shmctl_users_lock_calls++;
	mix(&fake_shmctl_digest, 0x55534c4bUL);
}

static void
fake_shmctl_users_unlock(void)
{
	fake_shmctl_users_unlock_calls++;
	mix(&fake_shmctl_digest, 0x5553554cUL);
}

static int
fake_shmctl_user_get(unsigned int ruid, void **userp)
{
	fake_shmctl_user_get_calls++;
	mix(&fake_shmctl_digest, ruid);
	if (fake_shmctl_user_get_rc)
		return fake_shmctl_user_get_rc;
	if (userp)
		*userp = fake_shmctl_user;
	mix(&fake_shmctl_digest, fake_shmctl_user != NULL);
	return 0;
}

static void
fake_shmctl_user_free(void *user)
{
	fake_shmctl_user_free_calls++;
	mix(&fake_shmctl_digest, user == fake_shmctl_user);
}

static int
fake_shmctl_refcnt_read(void *memobj)
{
	fake_shmctl_refcnt_calls++;
	mix(&fake_shmctl_digest, fake_shmctl_obj != NULL &&
			memobj == &fake_shmctl_obj->memobj);
	return fake_shmctl_refcnt_value;
}

static void
fake_shmctl_log(int event, int shmid, int cmd, unsigned long buf, long error)
{
	fake_shmctl_log_calls++;
	fake_shmctl_last_log_event = event;
	mix_signed(&fake_shmctl_digest, event);
	mix_signed(&fake_shmctl_digest, shmid);
	mix_signed(&fake_shmctl_digest, cmd);
	mix(&fake_shmctl_digest, buf != 0);
	mix_signed(&fake_shmctl_digest, error);
}

extern long shmctl_body_result(int, int, unsigned long, unsigned int,
			       unsigned int, unsigned int, unsigned long,
			       long, int, int,
			       const struct fake_shmctl_offsets *,
			       const struct fake_shminfo *,
			       const struct fake_shm_info *, void (*)(void),
			       void (*)(void), int (*)(int, void **),
			       int (*)(int, void **), void (*)(void *),
			       long (*)(void *, unsigned long, size_t),
			       long (*)(unsigned long, const void *, size_t),
			       int (*)(void), void (*)(void), void (*)(void),
			       int (*)(unsigned int, void **),
			       void (*)(void *), int (*)(void *),
			       void (*)(int, int, int, unsigned long, long));

static long
fake_shmctl_call(int shmid, int cmd, void *buf, unsigned int euid,
		 unsigned int egid, unsigned int ruid, unsigned long rlim,
		 int cap_sys_admin, int cap_ipc_lock)
{
	return shmctl_body_result(shmid, cmd, (unsigned long)(uintptr_t)buf,
		euid, egid, ruid, rlim, 1234567, cap_sys_admin,
		cap_ipc_lock, &fake_shmctl_offsets, &fake_shmctl_shminfo,
		&fake_shmctl_shm_info, fake_shmctl_list_lock,
		fake_shmctl_list_unlock, fake_shmctl_lookup,
		fake_shmctl_lookup_by_index, fake_shmctl_unref,
		fake_shmctl_copy_from, fake_shmctl_copy_to,
		fake_shmctl_get_max_index, fake_shmctl_users_lock,
		fake_shmctl_users_unlock, fake_shmctl_user_get,
		fake_shmctl_user_free, fake_shmctl_refcnt_read,
		fake_shmctl_log);
}

static void
fake_search_free_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_search_free_digest = 0x53465350414345UL;
	fake_search_free_ranges = ranges;
	fake_search_free_range_count = range_count;
	fake_search_free_lookup_calls = 0;
	fake_search_free_log_calls = 0;
}

static void *
fake_search_free_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_search_free_lookup_calls++;
	mix(&fake_search_free_digest, start);
	mix(&fake_search_free_digest, end);
	for (int i = 0; i < fake_search_free_range_count; i++) {
		if (fake_search_free_ranges[i].start <= start &&
				start < fake_search_free_ranges[i].end) {
			return &fake_search_free_ranges[i];
		}
	}
	return NULL;
}

static void
fake_search_free_log(int event, size_t len, int pgshift, unsigned long addr,
		     int error)
{
	fake_search_free_log_calls++;
	mix_signed(&fake_search_free_digest, event);
	mix(&fake_search_free_digest, len);
	mix_signed(&fake_search_free_digest, pgshift);
	mix(&fake_search_free_digest, addr);
	mix_signed(&fake_search_free_digest, error);
}

static void
fake_msync_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_msync_digest = 0x4d53594e43UL;
	fake_msync_ranges = ranges;
	fake_msync_range_count = range_count;
	fake_msync_lock_calls = 0;
	fake_msync_unlock_calls = 0;
	fake_msync_lookup_calls = 0;
	fake_msync_next_calls = 0;
	fake_msync_has_pager_calls = 0;
	fake_msync_sync_calls = 0;
	fake_msync_invalidate_calls = 0;
	fake_msync_sync_rc = 0;
	fake_msync_invalidate_rc = 0;
	fake_msync_last_sync_start = 0;
	fake_msync_last_sync_end = 0;
	fake_msync_last_invalidate_start = 0;
	fake_msync_last_invalidate_end = 0;
	fake_msync_log_calls = 0;
}

static void
fake_msync_lock(void *lock)
{
	fake_msync_lock_calls++;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_msync_unlock(void *lock)
{
	fake_msync_unlock_calls++;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_msync_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_msync_lookup_calls++;
	mix(&fake_msync_digest, start);
	mix(&fake_msync_digest, end);
	for (int i = 0; i < fake_msync_range_count; i++) {
		if (fake_msync_ranges[i].start <= start &&
				start < fake_msync_ranges[i].end) {
			return &fake_msync_ranges[i];
		}
	}
	return NULL;
}

static void *
fake_msync_next(void *vm, void *range)
{
	(void)vm;
	fake_msync_next_calls++;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)range != 0);
	for (int i = 0; i < fake_msync_range_count - 1; i++) {
		if (&fake_msync_ranges[i] == range) {
			return &fake_msync_ranges[i + 1];
		}
	}
	return NULL;
}

static int
fake_msync_has_pager(void *memobj)
{
	fake_msync_has_pager_calls++;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)memobj != 0);
	return memobj ? *(int *)memobj : 0;
}

static int
fake_msync_sync(void *vm, void *range, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_msync_sync_calls++;
	fake_msync_last_sync_start = start;
	fake_msync_last_sync_end = end;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)range != 0);
	mix(&fake_msync_digest, start);
	mix(&fake_msync_digest, end);
	return fake_msync_sync_rc;
}

static int
fake_msync_invalidate(void *vm, void *range, unsigned long start,
		      unsigned long end)
{
	(void)vm;
	fake_msync_invalidate_calls++;
	fake_msync_last_invalidate_start = start;
	fake_msync_last_invalidate_end = end;
	mix(&fake_msync_digest, (unsigned long)(uintptr_t)range != 0);
	mix(&fake_msync_digest, start);
	mix(&fake_msync_digest, end);
	return fake_msync_invalidate_rc;
}

static void
fake_msync_log(int event, unsigned long start, size_t len, int flags, int error)
{
	fake_msync_log_calls++;
	mix_signed(&fake_msync_digest, event);
	mix(&fake_msync_digest, start);
	mix(&fake_msync_digest, len);
	mix_signed(&fake_msync_digest, flags);
	mix_signed(&fake_msync_digest, error);
}

static void
fake_memlock_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_memlock_digest = 0x4d454d4c4f434bUL;
	fake_memlock_ranges = ranges;
	fake_memlock_range_count = range_count;
	fake_memlock_lock_calls = 0;
	fake_memlock_unlock_calls = 0;
	fake_memlock_lookup_calls = 0;
	fake_memlock_next_calls = 0;
	fake_memlock_split_calls = 0;
	fake_memlock_join_calls = 0;
	fake_memlock_populate_calls = 0;
	fake_memlock_populate_rc = 0;
	fake_memlock_populate_start = 0;
	fake_memlock_populate_len = 0;
	fake_memlock_log_calls = 0;
}

static void
fake_memlock_lock(void *lock)
{
	fake_memlock_lock_calls++;
	mix(&fake_memlock_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_memlock_unlock(void *lock)
{
	fake_memlock_unlock_calls++;
	mix(&fake_memlock_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_memlock_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_memlock_lookup_calls++;
	mix(&fake_memlock_digest, start);
	mix(&fake_memlock_digest, end);
	for (int i = 0; i < fake_memlock_range_count; i++) {
		if (fake_memlock_ranges[i].start <= start &&
				start < fake_memlock_ranges[i].end) {
			return &fake_memlock_ranges[i];
		}
	}
	return NULL;
}

static void *
fake_memlock_next(void *vm, void *range)
{
	(void)vm;
	fake_memlock_next_calls++;
	mix(&fake_memlock_digest, (unsigned long)(uintptr_t)range != 0);
	for (int i = 0; i < fake_memlock_range_count - 1; i++) {
		if (&fake_memlock_ranges[i] == range) {
			return &fake_memlock_ranges[i + 1];
		}
	}
	return NULL;
}

static int
fake_memlock_split(void *vm, void *range_arg, unsigned long addr,
		   void **new_range)
{
	struct fake_msync_range *range = range_arg;

	(void)vm;
	fake_memlock_split_calls++;
	mix(&fake_memlock_digest, addr);
	if (!range || addr <= range->start || range->end <= addr) {
		return -22;
	}
	if (new_range) {
		range->start = addr;
		*new_range = range;
	}
	else {
		range->end = addr;
	}
	return 0;
}

static int
fake_memlock_join(void *vm, void *left_arg, void *right_arg)
{
	struct fake_msync_range *left = left_arg;
	struct fake_msync_range *right = right_arg;

	(void)vm;
	fake_memlock_join_calls++;
	mix(&fake_memlock_digest, left ? left->start : 0);
	mix(&fake_memlock_digest, right ? right->end : 0);
	if (!left || !right || left->end != right->start) {
		return -22;
	}
	left->end = right->end;
	left->flag |= right->flag;
	return 0;
}

static int
fake_memlock_populate(void *vm, unsigned long start, size_t len)
{
	(void)vm;
	fake_memlock_populate_calls++;
	fake_memlock_populate_start = start;
	fake_memlock_populate_len = len;
	mix(&fake_memlock_digest, start);
	mix(&fake_memlock_digest, len);
	return fake_memlock_populate_rc;
}

static void
fake_memlock_log(const struct memlock_log_record *record)
{
	fake_memlock_log_calls++;
	mix_signed(&fake_memlock_digest, record->event);
	mix_signed(&fake_memlock_digest, record->op);
	mix_signed(&fake_memlock_digest, record->cpu);
	mix(&fake_memlock_digest, record->start);
	mix(&fake_memlock_digest, record->len);
	mix(&fake_memlock_digest, record->addr);
	mix(&fake_memlock_digest, record->range_start);
	mix(&fake_memlock_digest, record->range_end);
	mix_signed(&fake_memlock_digest, record->error);
}

static void
fake_mprotect_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_mprotect_digest = 0x4d50524f54454354UL;
	fake_mprotect_ranges = ranges;
	fake_mprotect_range_count = range_count;
	fake_mprotect_lock_calls = 0;
	fake_mprotect_unlock_calls = 0;
	fake_mprotect_lookup_calls = 0;
	fake_mprotect_next_calls = 0;
	fake_mprotect_split_calls = 0;
	fake_mprotect_join_calls = 0;
	fake_mprotect_change_calls = 0;
	fake_mprotect_sethost_calls = 0;
	fake_mprotect_flush_nfo_calls = 0;
	fake_mprotect_flush_tlb_calls = 0;
	fake_mprotect_log_calls = 0;
	fake_mprotect_split_rc = 0;
	fake_mprotect_join_rc = 0;
	fake_mprotect_change_rc = 0;
	fake_mprotect_sethost_rc = 0;
	fake_mprotect_sethost_start = 0;
	fake_mprotect_sethost_len = 0;
	fake_mprotect_sethost_prot = 0;
}

static void
fake_mprotect_lock(void *lock)
{
	fake_mprotect_lock_calls++;
	mix(&fake_mprotect_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mprotect_unlock(void *lock)
{
	fake_mprotect_unlock_calls++;
	mix(&fake_mprotect_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_mprotect_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_mprotect_lookup_calls++;
	mix(&fake_mprotect_digest, start);
	mix(&fake_mprotect_digest, end);
	for (int i = 0; i < fake_mprotect_range_count; i++) {
		if (fake_mprotect_ranges[i].start <= start &&
				start < fake_mprotect_ranges[i].end) {
			return &fake_mprotect_ranges[i];
		}
	}
	return NULL;
}

static void *
fake_mprotect_next(void *vm, void *range)
{
	(void)vm;
	fake_mprotect_next_calls++;
	mix(&fake_mprotect_digest, (unsigned long)(uintptr_t)range != 0);
	for (int i = 0; i < fake_mprotect_range_count - 1; i++) {
		if (&fake_mprotect_ranges[i] == range) {
			return &fake_mprotect_ranges[i + 1];
		}
	}
	return NULL;
}

static int
fake_mprotect_split(void *vm, void *range_arg, unsigned long addr,
		    void **new_range)
{
	struct fake_msync_range *range = range_arg;

	(void)vm;
	fake_mprotect_split_calls++;
	mix(&fake_mprotect_digest, addr);
	if (fake_mprotect_split_rc) {
		return fake_mprotect_split_rc;
	}
	if (!range || addr <= range->start || range->end <= addr) {
		return -22;
	}
	if (new_range) {
		range->start = addr;
		*new_range = range;
	}
	else {
		range->end = addr;
	}
	return 0;
}

static int
fake_mprotect_join(void *vm, void *left_arg, void *right_arg)
{
	struct fake_msync_range *left = left_arg;
	struct fake_msync_range *right = right_arg;

	(void)vm;
	fake_mprotect_join_calls++;
	mix(&fake_mprotect_digest, left ? left->start : 0);
	mix(&fake_mprotect_digest, right ? right->end : 0);
	if (fake_mprotect_join_rc) {
		return fake_mprotect_join_rc;
	}
	if (!left || !right || left->end != right->start) {
		return -22;
	}
	left->end = right->end;
	left->flag = (left->flag & ~VR_PROT_MASK) |
		(right->flag & VR_PROT_MASK) |
		(left->flag & ~VR_PROT_MASK);
	return 0;
}

static int
fake_mprotect_change(void *vm, void *range_arg, unsigned long protflags)
{
	struct fake_msync_range *range = range_arg;

	(void)vm;
	fake_mprotect_change_calls++;
	mix(&fake_mprotect_digest, range ? range->start : 0);
	mix(&fake_mprotect_digest, protflags);
	if (fake_mprotect_change_rc) {
		return fake_mprotect_change_rc;
	}
	if (!range) {
		return -22;
	}
	range->flag = (range->flag & ~VR_PROT_MASK) | protflags;
	return 0;
}

static int
fake_mprotect_set_host_vma(unsigned long start, size_t len, int prot,
			   int holding_lock)
{
	fake_mprotect_sethost_calls++;
	fake_mprotect_sethost_start = start;
	fake_mprotect_sethost_len = len;
	fake_mprotect_sethost_prot = prot;
	mix(&fake_mprotect_digest, start);
	mix(&fake_mprotect_digest, len);
	mix_signed(&fake_mprotect_digest, prot);
	mix_signed(&fake_mprotect_digest, holding_lock);
	return fake_mprotect_sethost_rc;
}

static void
fake_mprotect_flush_nfo(void)
{
	fake_mprotect_flush_nfo_calls++;
	mix(&fake_mprotect_digest, 0x4e464f);
}

static void
fake_mprotect_flush_tlb(void)
{
	fake_mprotect_flush_tlb_calls++;
	mix(&fake_mprotect_digest, 0x544c42);
}

static void
fake_mprotect_log(const struct mprotect_log_record *record)
{
	fake_mprotect_log_calls++;
	mix_signed(&fake_mprotect_digest, record->event);
	mix_signed(&fake_mprotect_digest, record->cpu);
	mix(&fake_mprotect_digest, record->start);
	mix(&fake_mprotect_digest, record->len);
	mix_signed(&fake_mprotect_digest, record->prot);
	mix(&fake_mprotect_digest, record->addr);
	mix(&fake_mprotect_digest, record->range_start);
	mix(&fake_mprotect_digest, record->range_end);
	mix(&fake_mprotect_digest, record->range_flags);
	mix(&fake_mprotect_digest, record->protflags);
	mix(&fake_mprotect_digest, record->denied);
	mix_signed(&fake_mprotect_digest, record->error);
}

static void
fake_remap_file_pages_reset(struct fake_msync_range *ranges, int range_count)
{
	fake_remap_file_pages_digest = 0x52464d4150554c;
	fake_remap_file_pages_ranges = ranges;
	fake_remap_file_pages_range_count = range_count;
	fake_remap_file_pages_lock_calls = 0;
	fake_remap_file_pages_unlock_calls = 0;
	fake_remap_file_pages_lookup_calls = 0;
	fake_remap_file_pages_callable_calls = 0;
	fake_remap_file_pages_remap_calls = 0;
	fake_remap_file_pages_clear_calls = 0;
	fake_remap_file_pages_populate_calls = 0;
	fake_remap_file_pages_flush_calls = 0;
	fake_remap_file_pages_log_calls = 0;
	fake_remap_file_pages_remap_rc = 0;
	fake_remap_file_pages_populate_rc = 0;
	fake_remap_file_pages_last_start = 0;
	fake_remap_file_pages_last_end = 0;
	fake_remap_file_pages_last_off = 0;
	fake_remap_file_pages_clear_start = 0;
	fake_remap_file_pages_clear_size = 0;
}

static void
fake_remap_file_pages_lock(void *lock)
{
	fake_remap_file_pages_lock_calls++;
	mix(&fake_remap_file_pages_digest,
	    (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_remap_file_pages_unlock(void *lock)
{
	fake_remap_file_pages_unlock_calls++;
	mix(&fake_remap_file_pages_digest,
	    (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_remap_file_pages_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_remap_file_pages_lookup_calls++;
	mix(&fake_remap_file_pages_digest, start);
	mix(&fake_remap_file_pages_digest, end);
	for (int i = 0; i < fake_remap_file_pages_range_count; i++) {
		if (fake_remap_file_pages_ranges[i].start <= start &&
				end <= fake_remap_file_pages_ranges[i].end) {
			return &fake_remap_file_pages_ranges[i];
		}
	}
	return NULL;
}

static int
fake_remap_file_pages_callable(void *memobj)
{
	fake_remap_file_pages_callable_calls++;
	mix(&fake_remap_file_pages_digest,
	    (unsigned long)(uintptr_t)memobj != 0);
	return memobj ? *(int *)memobj : 0;
}

static int
fake_remap_file_pages_remap(void *vm, void *range, unsigned long start,
			    unsigned long end, long off)
{
	(void)vm;
	fake_remap_file_pages_remap_calls++;
	fake_remap_file_pages_last_start = start;
	fake_remap_file_pages_last_end = end;
	fake_remap_file_pages_last_off = off;
	mix(&fake_remap_file_pages_digest,
	    (unsigned long)(uintptr_t)range != 0);
	mix(&fake_remap_file_pages_digest, start);
	mix(&fake_remap_file_pages_digest, end);
	mix(&fake_remap_file_pages_digest, (unsigned long)off);
	return fake_remap_file_pages_remap_rc;
}

static void
fake_remap_file_pages_clear_host(unsigned long start, size_t size,
				 int holding_lock)
{
	fake_remap_file_pages_clear_calls++;
	fake_remap_file_pages_clear_start = start;
	fake_remap_file_pages_clear_size = size;
	mix(&fake_remap_file_pages_digest, start);
	mix(&fake_remap_file_pages_digest, size);
	mix_signed(&fake_remap_file_pages_digest, holding_lock);
}

static int
fake_remap_file_pages_populate(void *vm, unsigned long start, size_t size)
{
	(void)vm;
	fake_remap_file_pages_populate_calls++;
	mix(&fake_remap_file_pages_digest, start);
	mix(&fake_remap_file_pages_digest, size);
	return fake_remap_file_pages_populate_rc;
}

static void
fake_remap_file_pages_flush(void)
{
	fake_remap_file_pages_flush_calls++;
	mix(&fake_remap_file_pages_digest, 0x4e464f);
}

static void
fake_remap_file_pages_log(const struct remap_file_pages_log_record *record)
{
	fake_remap_file_pages_log_calls++;
	mix_signed(&fake_remap_file_pages_digest, record->event);
	mix_signed(&fake_remap_file_pages_digest, record->cpu);
	mix(&fake_remap_file_pages_digest, record->start0);
	mix(&fake_remap_file_pages_digest, record->size);
	mix_signed(&fake_remap_file_pages_digest, record->prot);
	mix(&fake_remap_file_pages_digest, record->pgoff);
	mix_signed(&fake_remap_file_pages_digest, record->flags);
	mix(&fake_remap_file_pages_digest, record->start);
	mix(&fake_remap_file_pages_digest, record->end);
	mix(&fake_remap_file_pages_digest, record->range_start);
	mix(&fake_remap_file_pages_digest, record->range_end);
	mix(&fake_remap_file_pages_digest, record->range_flags);
	mix(&fake_remap_file_pages_digest,
	    (unsigned long)((uintptr_t)record->memobj != 0));
	mix(&fake_remap_file_pages_digest, (unsigned long)record->off);
	mix_signed(&fake_remap_file_pages_digest, record->error);
}

static void
fake_mremap_reset(struct fake_mremap_range *ranges, int range_count)
{
	fake_mremap_digest = 0x4d52454d41504UL;
	fake_mremap_ranges = ranges;
	fake_mremap_range_count = range_count;
	fake_mremap_lock_calls = 0;
	fake_mremap_unlock_calls = 0;
	fake_mremap_lookup_calls = 0;
	fake_mremap_extend_calls = 0;
	fake_mremap_flush_calls = 0;
	fake_mremap_search_calls = 0;
	fake_mremap_munmap_calls = 0;
	fake_mremap_memobj_ref_calls = 0;
	fake_mremap_memobj_unref_calls = 0;
	fake_mremap_add_calls = 0;
	fake_mremap_pte_lock_calls = 0;
	fake_mremap_pte_unlock_calls = 0;
	fake_mremap_split_calls = 0;
	fake_mremap_move_calls = 0;
	fake_mremap_populate_calls = 0;
	fake_mremap_log_calls = 0;
	fake_mremap_extend_rc = 0;
	fake_mremap_search_rc = 0;
	fake_mremap_munmap_rc = 0;
	fake_mremap_add_rc = 0;
	fake_mremap_split_rc = 0;
	fake_mremap_move_rc = 0;
	fake_mremap_populate_rc = 0;
	fake_mremap_search_addr = 0x30000UL;
	fake_mremap_add_start = 0;
	fake_mremap_add_end = 0;
	fake_mremap_add_pgshift = 0;
	fake_mremap_add_flags = 0;
	fake_mremap_add_memobj = NULL;
	fake_mremap_add_objoff = 0;
	fake_mremap_munmap_addr = 0;
	fake_mremap_munmap_len = 0;
	fake_mremap_munmap_holding = 0;
	fake_mremap_move_oldstart = 0;
	fake_mremap_move_newstart = 0;
	fake_mremap_move_size = 0;
	fake_mremap_populate_start = 0;
	fake_mremap_populate_len = 0;
}

static void
fake_mremap_lock(void *lock)
{
	fake_mremap_lock_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mremap_unlock(void *lock)
{
	fake_mremap_unlock_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_mremap_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_mremap_lookup_calls++;
	mix(&fake_mremap_digest, start);
	mix(&fake_mremap_digest, end);
	for (int i = 0; i < fake_mremap_range_count; i++) {
		if (fake_mremap_ranges[i].start <= start &&
				start < fake_mremap_ranges[i].end) {
			return &fake_mremap_ranges[i];
		}
	}
	return NULL;
}

static int
fake_mremap_extend(void *vm, void *range_arg, unsigned long newend)
{
	struct fake_mremap_range *range = range_arg;

	(void)vm;
	fake_mremap_extend_calls++;
	mix(&fake_mremap_digest, range ? range->end : 0);
	mix(&fake_mremap_digest, newend);
	if (fake_mremap_extend_rc)
		return fake_mremap_extend_rc;
	if (!range)
		return -22;
	range->end = newend;
	return 0;
}

static void
fake_mremap_flush(void)
{
	fake_mremap_flush_calls++;
	mix(&fake_mremap_digest, 0x4e464f);
}

static int
fake_mremap_search(size_t size, unsigned long pgshift,
		   unsigned long *newstartp)
{
	fake_mremap_search_calls++;
	mix(&fake_mremap_digest, size);
	mix(&fake_mremap_digest, pgshift);
	if (newstartp)
		*newstartp = fake_mremap_search_addr;
	return fake_mremap_search_rc;
}

static int
fake_mremap_munmap(void *addr, size_t len, int holding_lock)
{
	fake_mremap_munmap_calls++;
	fake_mremap_munmap_addr = (unsigned long)(uintptr_t)addr;
	fake_mremap_munmap_len = len;
	fake_mremap_munmap_holding = holding_lock;
	mix(&fake_mremap_digest, fake_mremap_munmap_addr);
	mix(&fake_mremap_digest, len);
	mix_signed(&fake_mremap_digest, holding_lock);
	return fake_mremap_munmap_rc;
}

static void
fake_mremap_memobj_ref(void *memobj)
{
	fake_mremap_memobj_ref_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)memobj != 0);
}

static void
fake_mremap_memobj_unref(void *memobj)
{
	fake_mremap_memobj_unref_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)memobj != 0);
}

static int
fake_mremap_add(void *vm, unsigned long start, unsigned long end,
		long pgshift, unsigned long flags, void *memobj,
		unsigned long objoff)
{
	(void)vm;
	fake_mremap_add_calls++;
	fake_mremap_add_start = start;
	fake_mremap_add_end = end;
	fake_mremap_add_pgshift = pgshift;
	fake_mremap_add_flags = flags;
	fake_mremap_add_memobj = memobj;
	fake_mremap_add_objoff = objoff;
	mix(&fake_mremap_digest, start);
	mix(&fake_mremap_digest, end);
	mix_signed(&fake_mremap_digest, pgshift);
	mix(&fake_mremap_digest, flags);
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)memobj != 0);
	mix(&fake_mremap_digest, objoff);
	return fake_mremap_add_rc;
}

static void
fake_mremap_pte_lock(void *lock)
{
	fake_mremap_pte_lock_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mremap_pte_unlock(void *lock)
{
	fake_mremap_pte_unlock_calls++;
	mix(&fake_mremap_digest, (unsigned long)(uintptr_t)lock != 0);
}

static int
fake_mremap_split(void *vm, void *range_arg, unsigned long addr,
		  void **new_range)
{
	struct fake_mremap_range *range = range_arg;

	(void)vm;
	fake_mremap_split_calls++;
	mix(&fake_mremap_digest, addr);
	if (fake_mremap_split_rc)
		return fake_mremap_split_rc;
	if (!range || addr <= range->start || range->end <= addr)
		return -22;
	if (new_range) {
		range->start = addr;
		*new_range = range;
	}
	else {
		range->end = addr;
	}
	return 0;
}

static int
fake_mremap_move(void *page_table, void *vm, void *oldstart, void *newstart,
		 size_t size, void *range)
{
	(void)page_table;
	(void)vm;
	(void)range;
	fake_mremap_move_calls++;
	fake_mremap_move_oldstart = (unsigned long)(uintptr_t)oldstart;
	fake_mremap_move_newstart = (unsigned long)(uintptr_t)newstart;
	fake_mremap_move_size = size;
	mix(&fake_mremap_digest, fake_mremap_move_oldstart);
	mix(&fake_mremap_digest, fake_mremap_move_newstart);
	mix(&fake_mremap_digest, size);
	return fake_mremap_move_rc;
}

static int
fake_mremap_populate(void *vm, unsigned long start, size_t len)
{
	(void)vm;
	fake_mremap_populate_calls++;
	fake_mremap_populate_start = start;
	fake_mremap_populate_len = len;
	mix(&fake_mremap_digest, start);
	mix(&fake_mremap_digest, len);
	return fake_mremap_populate_rc;
}

static void
fake_mremap_log(const struct mremap_log_record *record)
{
	fake_mremap_log_calls++;
	mix_signed(&fake_mremap_digest, record->event);
	mix(&fake_mremap_digest, record->oldaddr);
	mix(&fake_mremap_digest, record->oldsize0);
	mix(&fake_mremap_digest, record->newsize0);
	mix_signed(&fake_mremap_digest, record->flags);
	mix(&fake_mremap_digest, record->newaddr);
	mix(&fake_mremap_digest, record->oldstart);
	mix(&fake_mremap_digest, record->oldend);
	mix(&fake_mremap_digest, record->newstart);
	mix(&fake_mremap_digest, record->newend);
	mix(&fake_mremap_digest, record->range_start);
	mix(&fake_mremap_digest, record->range_end);
	mix(&fake_mremap_digest, record->range_flags);
	mix(&fake_mremap_digest, record->lckstart);
	mix(&fake_mremap_digest, record->lckend);
	mix_signed(&fake_mremap_digest, record->error);
}

static void
fake_mincore_reset(struct fake_mincore_range *ranges, int range_count)
{
	fake_mincore_digest = 0x4d494e434f5245UL;
	fake_mincore_ranges = ranges;
	fake_mincore_range_count = range_count;
	for (int i = 0; i < 8; i++) {
		fake_mincore_pte_values[i] = 0;
		fake_mincore_vec[i] = 0xaa;
	}
	fake_mincore_range_lock_calls = 0;
	fake_mincore_range_unlock_calls = 0;
	fake_mincore_pte_lock_calls = 0;
	fake_mincore_pte_unlock_calls = 0;
	fake_mincore_lookup_calls = 0;
	fake_mincore_pte_lookup_calls = 0;
	fake_mincore_pte_present_calls = 0;
	fake_mincore_memobj_lookup_calls = 0;
	fake_mincore_copy_calls = 0;
	fake_mincore_copy_fail_at = -1;
	fake_mincore_log_calls = 0;
}

static void
fake_mincore_range_lock(void *lock)
{
	fake_mincore_range_lock_calls++;
	mix(&fake_mincore_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mincore_range_unlock(void *lock)
{
	fake_mincore_range_unlock_calls++;
	mix(&fake_mincore_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mincore_pte_lock(void *lock)
{
	fake_mincore_pte_lock_calls++;
	mix(&fake_mincore_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_mincore_pte_unlock(void *lock)
{
	fake_mincore_pte_unlock_calls++;
	mix(&fake_mincore_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void *
fake_mincore_lookup(void *vm, unsigned long start, unsigned long end)
{
	(void)vm;
	fake_mincore_lookup_calls++;
	mix(&fake_mincore_digest, start);
	mix(&fake_mincore_digest, end);
	for (int i = 0; i < fake_mincore_range_count; i++) {
		if (fake_mincore_ranges[i].start <= start &&
				start < fake_mincore_ranges[i].end) {
			return &fake_mincore_ranges[i];
		}
	}
	return NULL;
}

static void *
fake_mincore_pte_lookup(void *page_table, unsigned long addr)
{
	unsigned long base = (unsigned long)(uintptr_t)page_table;
	unsigned long index = (addr - base) / PAGE_SIZE;

	fake_mincore_pte_lookup_calls++;
	mix(&fake_mincore_digest, addr);
	if (index < 8 && fake_mincore_pte_values[index]) {
		return &fake_mincore_pte_values[index];
	}
	return NULL;
}

static int
fake_mincore_pte_present(void *pte)
{
	fake_mincore_pte_present_calls++;
	mix(&fake_mincore_digest, *(unsigned long *)pte);
	return (*(unsigned long *)pte & 1) != 0;
}

static int
fake_mincore_memobj_lookup(void *memobj, unsigned long offset)
{
	int present = memobj ? *(int *)memobj : 0;

	fake_mincore_memobj_lookup_calls++;
	mix(&fake_mincore_digest, (unsigned long)(uintptr_t)memobj != 0);
	mix(&fake_mincore_digest, offset);
	return present ? 0 : -2;
}

static long
fake_mincore_copy_byte(unsigned long dst, unsigned char value)
{
	unsigned long index = dst;

	fake_mincore_copy_calls++;
	mix(&fake_mincore_digest, index);
	mix(&fake_mincore_digest, value);
	if (fake_mincore_copy_fail_at == fake_mincore_copy_calls) {
		return -14;
	}
	if (index < sizeof(fake_mincore_vec)) {
		fake_mincore_vec[index] = value;
		return 0;
	}
	return -14;
}

static void
fake_mincore_log(int event, unsigned long start, size_t len,
		 unsigned long vec, int error)
{
	fake_mincore_log_calls++;
	mix_signed(&fake_mincore_digest, event);
	mix(&fake_mincore_digest, start);
	mix(&fake_mincore_digest, len);
	mix(&fake_mincore_digest, vec);
	mix_signed(&fake_mincore_digest, error);
}

static void
fake_times_tsc_to_ts(unsigned long tsc, void *ts)
{
	struct timespec *wts = ts;

	fake_times_tsc_calls++;
	wts->tv_sec = (long)(tsc / 1000);
	wts->tv_nsec = (long)((tsc % 1000) * 1000000);
}

static unsigned long
fake_timespec_to_jiffy(const void *ts)
{
	const struct timespec *wts = ts;

	fake_times_jiffy_calls++;
	return (unsigned long)wts->tv_sec * 100 +
		(unsigned long)wts->tv_nsec / 10000000;
}

static void
fake_times_ts_add(void *dst, const void *src)
{
	struct timespec *wts = dst;
	const struct timespec *add = src;

	fake_times_add_calls++;
	wts->tv_sec += add->tv_sec;
	wts->tv_nsec += add->tv_nsec;
	if (wts->tv_nsec >= 1000000000L) {
		wts->tv_sec++;
		wts->tv_nsec -= 1000000000L;
	}
}

static long
fake_do_syscall2(int syscall_nr, unsigned long arg0, unsigned long arg1)
{
	fake_syscall2_calls++;
	fake_syscall2_nr = syscall_nr;
	fake_syscall2_arg0 = arg0;
	fake_syscall2_arg1 = arg1;
	return fake_syscall2_rc;
}

static long
fake_generic_syscall(struct fake_syscall_request *request, int cpu)
{
	fake_generic_syscall_calls++;
	fake_generic_syscall_req = request;
	fake_generic_syscall_cpu = cpu;
	return fake_generic_syscall_rc;
}

static long
fake_do_syscall3(int syscall_nr, unsigned long arg0, unsigned long arg1,
		 unsigned long arg2)
{
	fake_syscall3_calls++;
	fake_syscall3_nr = syscall_nr;
	fake_syscall3_arg0 = arg0;
	fake_syscall3_arg1 = arg1;
	fake_syscall3_arg2 = arg2;
	return fake_syscall3_rc;
}

static void
fake_set_timer(int runq_locked)
{
	fake_set_timer_calls++;
	fake_set_timer_runq_locked = runq_locked;
}

static void
fake_exit_do_exit(int code)
{
	fake_exit_calls++;
	fake_exit_code = code;
}

static void
fake_exit_group_log(int pid)
{
	fake_exit_group_log_calls++;
	fake_exit_group_log_pid = pid;
}

static void
fake_terminate(int status, int group)
{
	fake_terminate_calls++;
	fake_terminate_status = status;
	fake_terminate_group = group;
}

static long
fake_sched_yield_lock(void *lock)
{
	require(lock != NULL);
	fake_sched_yield_lock_calls++;
	return fake_sched_yield_irqstate;
}

static void
fake_sched_yield_unlock(void *lock, long irqstate)
{
	require(lock != NULL);
	fake_sched_yield_unlock_calls++;
	require(irqstate == fake_sched_yield_irqstate);
}

static void
fake_sched_yield_schedule(void)
{
	fake_sched_yield_schedule_calls++;
}

static void *
fake_setpgid_find_process(int pid, void *lock_arg)
{
	int *cookie = lock_arg;

	fake_setpgid_find_calls++;
	if (cookie) {
		(*cookie)++;
		fake_setpgid_lock_cookie = *cookie;
	}
	for (unsigned int i = 0; i < sizeof(fake_setpgid_table) /
			sizeof(fake_setpgid_table[0]); i++) {
		if (fake_setpgid_table[i] &&
				fake_setpgid_table[i]->pid == pid) {
			return fake_setpgid_table[i];
		}
	}
	return NULL;
}

static void
fake_setpgid_process_unlock(void *proc, void *lock_arg)
{
	int *cookie = lock_arg;

	require(proc != NULL);
	fake_setpgid_unlock_calls++;
	if (cookie) {
		(*cookie)--;
		fake_setpgid_lock_cookie = *cookie;
	}
}

static long
fake_do_prlimit64(int pid, int resource, unsigned long new_limit_addr,
		  unsigned long old_limit_addr)
{
	fake_prlimit_calls++;
	fake_prlimit_pid = pid;
	fake_prlimit_resource = resource;
	fake_prlimit_new_addr = new_limit_addr;
	fake_prlimit_old_addr = old_limit_addr;
	return fake_prlimit_rc;
}

static int
fake_get_cpu_id(void)
{
	fake_get_cpu_calls++;
	return 17;
}

static void
fake_mlock_log(int flags, int error)
{
	fake_mlock_log_calls++;
	fake_mlock_log_flags = flags;
	fake_mlock_log_error = error;
}

static long
fake_getcpu_copy_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_getcpu_copy_calls++;
	if (fake_getcpu_copy_fail_after >= 0 &&
			fake_getcpu_copy_calls > fake_getcpu_copy_fail_after) {
		return fake_getcpu_copy_error;
	}
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static void
reset_getmem_trace(void)
{
	fake_getmem_copy_calls = 0;
	fake_getmem_copy_fail_after = -1;
	fake_getmem_copy_bytes = 0;
	fake_getmem_lookup_node_calls = 0;
	fake_getmem_lookup_node_addr = 0;
	fake_getmem_lookup_node_result = 0;
	fake_getmem_lock_calls = 0;
	fake_getmem_unlock_calls = 0;
	fake_getmem_last_lock = NULL;
	fake_getmem_lookup_range_calls = 0;
	fake_getmem_lookup_start = 0;
	fake_getmem_lookup_end = 0;
	fake_getmem_lookup_range_result = NULL;
	fake_getmem_policy_search_calls = 0;
	fake_getmem_policy_search_addr = 0;
	fake_getmem_policy_search_result = NULL;
	fake_getmem_log_calls = 0;
	fake_getmem_log_event = 0;
	fake_getmem_log_addr = 0;
	fake_getmem_log_value = 0;
}

static void
fake_getmem_init_vm(unsigned char *vm, int policy, unsigned long mask0)
{
	memset(vm, 0, FAKE_PROCESS_VM_SIZE);
	*(unsigned long *)(vm + FAKE_PROCESS_VM_NUMA_MASK_OFF) = mask0;
	*(int *)(vm + FAKE_PROCESS_VM_POLICY_OFF) = policy;
}

static void
fake_getmem_init_range_policy(unsigned char *policy, int mode,
			      unsigned long mask0)
{
	memset(policy, 0, FAKE_RANGE_POLICY_SIZE);
	*(unsigned long *)(policy + FAKE_RANGE_POLICY_MASK_OFF) = mask0;
	*(int *)(policy + FAKE_RANGE_POLICY_POLICY_OFF) = mode;
}

static long
fake_getmem_copy_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_getmem_copy_calls++;
	fake_getmem_copy_bytes += bytes;
	if (fake_getmem_copy_fail_after >= 0 &&
			fake_getmem_copy_calls > fake_getmem_copy_fail_after) {
		return -1;
	}
	if (!dst_addr) {
		return -1;
	}
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static long
fake_getmem_copy_from_user(void *dst, unsigned long src_addr, size_t bytes)
{
	fake_getmem_copy_calls++;
	fake_getmem_copy_bytes += bytes;
	if (fake_getmem_copy_fail_after >= 0 &&
			fake_getmem_copy_calls > fake_getmem_copy_fail_after) {
		return -1;
	}
	if (!src_addr && bytes) {
		return -1;
	}
	memcpy(dst, (const void *)(uintptr_t)src_addr, bytes);
	return 0;
}

static void
fake_setmem_log(int event, int value, int pid)
{
	fake_getmem_log_calls++;
	fake_getmem_log_event = event;
	fake_getmem_log_addr = (unsigned long)(unsigned int)value;
	fake_getmem_log_value = pid;
}

static int fake_mbind_clear_calls;
static unsigned long fake_mbind_clear_start;
static unsigned long fake_mbind_clear_end;
static int fake_mbind_clear_rc;
static int fake_mbind_alloc_calls;
static size_t fake_mbind_alloc_size;
static unsigned long fake_mbind_alloc_flags;
static void *fake_mbind_alloc_result;
static int fake_mbind_rb_clear_calls;
static int fake_mbind_insert_calls;
static int fake_mbind_insert_rc;

static void
reset_mbind_trace(void)
{
	reset_getmem_trace();
	fake_mbind_clear_calls = 0;
	fake_mbind_clear_start = 0;
	fake_mbind_clear_end = 0;
	fake_mbind_clear_rc = 0;
	fake_mbind_alloc_calls = 0;
	fake_mbind_alloc_size = 0;
	fake_mbind_alloc_flags = 0;
	fake_mbind_alloc_result = NULL;
	fake_mbind_rb_clear_calls = 0;
	fake_mbind_insert_calls = 0;
	fake_mbind_insert_rc = 0;
}

static int
fake_mbind_clear_range(void *vm, unsigned long start, unsigned long end)
{
	require(vm != NULL);
	fake_mbind_clear_calls++;
	fake_mbind_clear_start = start;
	fake_mbind_clear_end = end;
	return fake_mbind_clear_rc;
}

static void *
fake_mbind_alloc(size_t size, unsigned long flags)
{
	fake_mbind_alloc_calls++;
	fake_mbind_alloc_size = size;
	fake_mbind_alloc_flags = flags;
	return fake_mbind_alloc_result;
}

static void
fake_mbind_rb_clear(void *policy)
{
	require(policy != NULL);
	fake_mbind_rb_clear_calls++;
	memset(policy, 0, 24);
}

static int
fake_mbind_insert(void *vm, void *policy)
{
	require(vm != NULL);
	require(policy != NULL);
	fake_mbind_insert_calls++;
	return fake_mbind_insert_rc;
}

static void
fake_mbind_log(int event, unsigned long arg0, unsigned long arg1, int arg2)
{
	fake_getmem_log_calls++;
	fake_getmem_log_event = event;
	fake_getmem_log_addr = arg0 ^ (arg1 << 1);
	fake_getmem_log_value = arg2;
}

static int
fake_getmem_lookup_node(void *vm, void *addr)
{
	require(vm != NULL);
	fake_getmem_lookup_node_calls++;
	fake_getmem_lookup_node_addr = (unsigned long)(uintptr_t)addr;
	return fake_getmem_lookup_node_result;
}

static void
fake_getmem_read_lock(void *lock)
{
	fake_getmem_lock_calls++;
	fake_getmem_last_lock = lock;
}

static void
fake_getmem_read_unlock(void *lock)
{
	fake_getmem_unlock_calls++;
	fake_getmem_last_lock = lock;
}

static void *
fake_getmem_lookup_range(void *vm, unsigned long start, unsigned long end)
{
	require(vm != NULL);
	fake_getmem_lookup_range_calls++;
	fake_getmem_lookup_start = start;
	fake_getmem_lookup_end = end;
	return fake_getmem_lookup_range_result;
}

static void *
fake_getmem_policy_search(void *vm, unsigned long addr)
{
	require(vm != NULL);
	fake_getmem_policy_search_calls++;
	fake_getmem_policy_search_addr = addr;
	return fake_getmem_policy_search_result;
}

static void
fake_getmem_log(int event, unsigned long addr, int value)
{
	fake_getmem_log_calls++;
	fake_getmem_log_event = event;
	fake_getmem_log_addr = addr;
	fake_getmem_log_value = value;
}

static long
fake_mckfd_lock(void *lock)
{
	require(lock != NULL);
	fake_mckfd_lock_calls++;
	return 0x500 + fake_mckfd_lock_calls;
}

static void
fake_mckfd_unlock(void *lock, long irqstate)
{
	require(lock != NULL);
	fake_mckfd_unlock_calls++;
	fake_mckfd_unlock_irq = (unsigned long)irqstate;
}

static long
fake_mckfd_read(struct fake_syscall_mckfd *fdp, void *ctx)
{
	fake_mckfd_read_calls++;
	fake_mckfd_fd_sum += fdp->fd;
	fake_mckfd_ctx_matches += ctx != NULL;
	return fake_mckfd_read_rc;
}

static long
fake_mckfd_mmap(struct fake_syscall_mckfd *fdp, void *ctx)
{
	fake_mckfd_mmap_calls++;
	fake_mckfd_fd_sum += fdp->fd;
	fake_mckfd_ctx_matches += ctx != NULL;
	return fake_mckfd_mmap_rc;
}

static int
fake_mckfd_ioctl(struct fake_syscall_mckfd *fdp, void *ctx)
{
	fake_mckfd_ioctl_calls++;
	fake_mckfd_fd_sum += fdp->fd;
	fake_mckfd_ctx_matches += ctx != NULL;
	return fake_mckfd_ioctl_rc;
}

static int
fake_mckfd_fcntl(struct fake_syscall_mckfd *fdp, void *ctx)
{
	fake_mckfd_fcntl_calls++;
	fake_mckfd_fd_sum += fdp->fd;
	fake_mckfd_ctx_matches += ctx != NULL;
	return fake_mckfd_fcntl_rc;
}

static int
fake_mckfd_close(struct fake_syscall_mckfd *fdp, void *ctx)
{
	fake_mckfd_close_calls++;
	fake_mckfd_fd_sum += fdp->fd;
	fake_mckfd_ctx_matches += ctx != NULL;
	return fake_mckfd_close_rc;
}

static void
fake_mckfd_free(void *fdp)
{
	struct fake_syscall_mckfd *fake = fdp;

	fake_mckfd_free_calls++;
	fake_mckfd_fd_sum += fake->fd;
}

static long
fake_mckfd_tofu_ioctl(void *thread, int fd, unsigned long cmd,
		      unsigned long arg, int *handled)
{
	(void)thread;
	fake_mckfd_tofu_ioctl_calls++;
	fake_mckfd_fd_sum += fd;
	fake_mckfd_tofu_cmd = cmd;
	fake_mckfd_tofu_arg = arg;
	*handled = fake_mckfd_tofu_handled;
	return fake_mckfd_tofu_rc;
}

static void
fake_mckfd_tofu_close(void *thread, int fd)
{
	(void)thread;
	fake_mckfd_tofu_close_calls++;
	fake_mckfd_fd_sum += fd;
}

static unsigned long
fake_rdtsc(void)
{
	unsigned long ret = fake_rdtsc_value;

	fake_rdtsc_value += fake_rdtsc_step;
	return ret;
}

static unsigned long
fake_ns_per_tsc(void)
{
	return fake_ns_per_tsc_value;
}

static void
fake_settimeofday_reset(long version)
{
	fake_settimeofday_digest = 0x53455454494d45UL;
	fake_settimeofday_lock_calls = 0;
	fake_settimeofday_unlock_calls = 0;
	fake_settimeofday_version = version;
	fake_settimeofday_atomic_read_calls = 0;
	fake_settimeofday_atomic_inc_calls = 0;
	fake_settimeofday_wmb_calls = 0;
	fake_settimeofday_panic_calls = 0;
	fake_settimeofday_log_calls = 0;
	fake_settimeofday_origin_logs = 0;
	fake_settimeofday_origin_sec = 0;
	fake_settimeofday_origin_nsec = 0;
	fake_settimeofday_exit_error = 0;
	fake_stack_copy_from_calls = 0;
	fake_stack_copy_from_fail = 0;
	fake_forward_context_calls = 0;
	fake_forward_context_rc = 0;
	fake_forward_context_thread = NULL;
	fake_rdtsc_value = 0;
	fake_rdtsc_step = 0;
}

static void
fake_settimeofday_lock(void *lock)
{
	fake_settimeofday_lock_calls++;
	mix(&fake_settimeofday_digest, (unsigned long)(uintptr_t)lock != 0);
}

static void
fake_settimeofday_unlock(void *lock)
{
	fake_settimeofday_unlock_calls++;
	mix(&fake_settimeofday_digest, (unsigned long)(uintptr_t)lock != 0);
}

static long
fake_settimeofday_atomic_read(void *value)
{
	(void)value;
	fake_settimeofday_atomic_read_calls++;
	mix_signed(&fake_settimeofday_digest, fake_settimeofday_version);
	return fake_settimeofday_version;
}

static void
fake_settimeofday_atomic_inc(void *value)
{
	(void)value;
	fake_settimeofday_atomic_inc_calls++;
	fake_settimeofday_version++;
	mix_signed(&fake_settimeofday_digest, fake_settimeofday_version);
}

static void
fake_settimeofday_wmb(void)
{
	fake_settimeofday_wmb_calls++;
	mix_signed(&fake_settimeofday_digest, fake_settimeofday_wmb_calls);
}

static void
fake_settimeofday_panic(void)
{
	fake_settimeofday_panic_calls++;
	mix_signed(&fake_settimeofday_digest, fake_settimeofday_panic_calls);
}

static void
fake_settimeofday_log(int event, unsigned long utv, unsigned long utz,
		      long sec, long nsec, long error)
{
	fake_settimeofday_log_calls++;
	if (event == SETTIMEOFDAY_LOG_ORIGIN) {
		fake_settimeofday_origin_logs++;
		fake_settimeofday_origin_sec = sec;
		fake_settimeofday_origin_nsec = nsec;
	}
	if (event == SETTIMEOFDAY_LOG_EXIT)
		fake_settimeofday_exit_error = error;
	mix_signed(&fake_settimeofday_digest, event);
	mix(&fake_settimeofday_digest, utv != 0);
	mix(&fake_settimeofday_digest, utz != 0);
	mix_signed(&fake_settimeofday_digest, sec);
	mix_signed(&fake_settimeofday_digest, nsec);
	mix_signed(&fake_settimeofday_digest, error);
}

static int
fake_has_sigpending(void *thread)
{
	(void)thread;
	fake_has_sigpending_calls++;
	return fake_has_sigpending_after >= 0 &&
		fake_has_sigpending_calls > fake_has_sigpending_after;
}

static void
fake_cpu_pause(void)
{
	fake_cpu_pause_calls++;
}

static void
fake_cputime_list_init(struct fake_list_head *head)
{
	head->next = head;
	head->prev = head;
}

static void
fake_cputime_list_add_tail(struct fake_list_head *entry,
			   struct fake_list_head *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static void
fake_cputime_lock(void *proc, void *arg)
{
	int *cookie = arg;

	require(proc != NULL);
	fake_cputime_lock_calls++;
	if (cookie)
		(*cookie)++;
}

static void
fake_cputime_unlock(void *proc, void *arg)
{
	int *cookie = arg;

	require(proc != NULL);
	fake_cputime_unlock_calls++;
	if (cookie)
		(*cookie)--;
}

static void
fake_cputime_interrupt(int cpu_id)
{
	require(cpu_id >= 0 && cpu_id < 8);
	require(fake_cputime_by_cpu[cpu_id] != NULL);
	fake_cputime_by_cpu[cpu_id]->times_update = 1;
	fake_cputime_interrupt_calls++;
	mix(&fake_cputime_interrupt_digest, (unsigned long)cpu_id);
}

static void
fake_cputime_pause(void)
{
	fake_cputime_pause_calls++;
	require(fake_cputime_pause_calls < 32);
}

static long
fake_cputime_copy_to_user(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_cputime_copy_calls++;
	if (fake_cputime_copy_fail)
		return -1;
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static long
fake_forward_context(int syscall_nr, void *ctx)
{
	fake_forward_context_calls++;
	fake_forward_context_nr = syscall_nr;
	fake_forward_context_ctx = ctx;
	if (fake_forward_context_thread)
		fake_forward_context_seen_mask = fake_forward_context_thread->sigmask;
	return fake_forward_context_rc;
}

struct fake_syscall_gpr {
	unsigned long r15, r14, r13, r12, rbp, rbx, r11, r10;
	unsigned long r9, r8, rax, rcx, rdx, rsi, rdi, orig_rax;
	unsigned long rip, cs, rflags, rsp, ss;
};

struct fake_syscall_context {
	unsigned long sr[6];
	unsigned char is_gpr_valid;
	unsigned char is_sr_valid;
	unsigned char spare_flags6;
	unsigned char spare_flags5;
	unsigned char spare_flags4;
	unsigned char spare_flags3;
	unsigned char spare_flags2;
	unsigned char spare_flags1;
	struct fake_syscall_gpr gpr;
};

__attribute__((weak)) unsigned long uti_desc;
static int fake_direct_mlock_log_calls;
static unsigned long fake_direct_mlock_log_addr;
static unsigned long fake_direct_mlock_log_len;
static int fake_direct_register_log_calls;
static unsigned long fake_direct_register_log_desc;

__attribute__((weak)) void *get_this_cpu_local_var(void)
{
	return NULL;
}

__attribute__((weak)) int ihk_mc_get_processor_id(void)
{
	return 0;
}

__attribute__((weak)) long
syscall_policy_do_syscall2_bridge(int syscall_nr,
				  unsigned long arg0,
				  unsigned long arg1)
{
	return fake_do_syscall2(syscall_nr, arg0, arg1);
}

__attribute__((weak)) long
syscall_policy_forward_context_bridge(int syscall_nr, void *ctx)
{
	return fake_forward_context(syscall_nr, ctx);
}

__attribute__((weak)) void
syscall_linux_mlock_log_bridge(unsigned long addr, unsigned long len)
{
	fake_direct_mlock_log_calls++;
	fake_direct_mlock_log_addr = addr;
	fake_direct_mlock_log_len = len;
}

__attribute__((weak)) void
syscall_util_register_desc_log_bridge(int tid, unsigned long desc)
{
	fake_direct_register_log_calls++;
	(void)tid;
	fake_direct_register_log_desc = desc;
}

static unsigned long
fake_pending_mask(void *thread)
{
	fake_pending_mask_calls++;
	fake_pending_mask_thread = thread;
	return fake_pending_mask_value;
}

static long
fake_signalfd_create(int syscall_nr, int flags)
{
	fake_signalfd_create_calls++;
	fake_signalfd_create_nr = syscall_nr;
	fake_signalfd_create_flags = flags;
	return fake_signalfd_create_rc;
}

static long
fake_signalfd_publish(void *thread, int fd, const unsigned long *mask,
		      int create)
{
	fake_signalfd_publish_calls++;
	fake_signalfd_publish_thread = thread;
	fake_signalfd_publish_fd = fd;
	fake_signalfd_publish_mask = *mask;
	fake_signalfd_publish_create = create;
	return fake_signalfd_publish_rc ? fake_signalfd_publish_rc : fd;
}

static long
fake_sigsuspend(void *thread, void *set)
{
	fake_sigsuspend_calls++;
	fake_sigsuspend_thread = thread;
	fake_sigsuspend_set = set;
	return fake_sigsuspend_rc;
}

static int
fake_process_vm_rw(int pid, const void *local_iov, unsigned long liovcnt,
		   const void *remote_iov, unsigned long riovcnt,
		   unsigned long flags, int op)
{
	fake_process_vm_rw_calls++;
	fake_process_vm_rw_pid = pid;
	fake_process_vm_rw_local = local_iov;
	fake_process_vm_rw_liovcnt = liovcnt;
	fake_process_vm_rw_remote = remote_iov;
	fake_process_vm_rw_riovcnt = riovcnt;
	fake_process_vm_rw_flags = flags;
	fake_process_vm_rw_op = op;
	return fake_process_vm_rw_rc;
}

static const struct fake_process_vm_rw_offsets fake_arch_pvm_offsets = {
	.thread_proc_offset = offsetof(struct fake_process_vm_rw_thread, proc),
	.thread_vm_offset = offsetof(struct fake_process_vm_rw_thread, vm),
	.proc_vm_offset = offsetof(struct fake_process_vm_rw_proc, vm),
	.proc_status_offset = offsetof(struct fake_process_vm_rw_proc, status),
	.proc_ruid_offset = offsetof(struct fake_process_vm_rw_proc, ruid),
	.proc_euid_offset = offsetof(struct fake_process_vm_rw_proc, euid),
	.proc_suid_offset = offsetof(struct fake_process_vm_rw_proc, suid),
	.proc_rgid_offset = offsetof(struct fake_process_vm_rw_proc, rgid),
	.proc_egid_offset = offsetof(struct fake_process_vm_rw_proc, egid),
	.proc_sgid_offset = offsetof(struct fake_process_vm_rw_proc, sgid),
	.process_vm_address_space_offset =
		offsetof(struct fake_process_vm_rw_vm, address_space),
	.address_space_page_table_offset =
		offsetof(struct fake_process_vm_rw_address_space, page_table),
	.vm_range_flag_offset = offsetof(struct fake_process_vm_rw_range, flag),
};

static void
fake_arch_pvm_reset(struct fake_process_vm_rw_thread *thread,
		    struct fake_process_vm_rw_proc *local_proc,
		    struct fake_process_vm_rw_proc *remote_proc,
		    struct fake_process_vm_rw_vm *local_vm,
		    struct fake_process_vm_rw_vm *remote_vm,
		    struct fake_process_vm_rw_address_space *remote_as,
		    unsigned char *remote_storage)
{
	memset(&fake_arch_pvm_range, 0, sizeof(fake_arch_pvm_range));
	memset(fake_arch_pvm_lookup_flags, 0, sizeof(fake_arch_pvm_lookup_flags));
	fake_arch_pvm_local_vm = local_vm;
	fake_arch_pvm_remote_vm = remote_vm;
	fake_arch_pvm_remote_proc = remote_proc;
	fake_arch_pvm_lock_calls = 0;
	fake_arch_pvm_unlock_calls = 0;
	fake_arch_pvm_lookup_calls = 0;
	fake_arch_pvm_lookup_fail_call = 0;
	fake_arch_pvm_find_calls = 0;
	fake_arch_pvm_find_pid = 0;
	fake_arch_pvm_find_lock = NULL;
	fake_arch_pvm_find_missing = 0;
	fake_arch_pvm_process_unlock_calls = 0;
	fake_arch_pvm_update_lock_calls = 0;
	fake_arch_pvm_update_unlock_calls = 0;
	fake_arch_pvm_hold_calls = 0;
	fake_arch_pvm_release_calls = 0;
	fake_arch_pvm_vtop_calls = 0;
	fake_arch_pvm_vtop_fail_count = 0;
	fake_arch_pvm_vtop_last_virt = 0;
	fake_arch_pvm_fault_calls = 0;
	fake_arch_pvm_fault_fail = 0;
	fake_arch_pvm_fault_last_addr = 0;
	fake_arch_pvm_fault_last_reason = 0;
	fake_arch_pvm_memcpy_calls = 0;
	fake_arch_pvm_memcpy_bytes = 0;
	fake_arch_pvm_log_calls = 0;
	fake_arch_pvm_remote_base = (unsigned long)(uintptr_t)remote_storage;
	fake_arch_pvm_remote_storage = remote_storage;

	*local_proc = (struct fake_process_vm_rw_proc){
		.vm = local_vm,
		.status = PS_RUNNING,
		.ruid = 1000,
		.euid = 1000,
		.suid = 1000,
		.rgid = 100,
		.egid = 100,
		.sgid = 100,
	};
	*remote_proc = *local_proc;
	remote_proc->vm = remote_vm;
	*local_vm = (struct fake_process_vm_rw_vm){ .address_space = NULL, .tag = 1 };
	*remote_as = (struct fake_process_vm_rw_address_space){
		.page_table = (void *)0xfeed1000UL,
	};
	*remote_vm = (struct fake_process_vm_rw_vm){
		.address_space = remote_as,
		.tag = 2,
	};
	*thread = (struct fake_process_vm_rw_thread){
		.proc = local_proc,
		.vm = local_vm,
	};
}

static void
fake_arch_pvm_read_lock(void *vm)
{
	require(vm == fake_arch_pvm_local_vm || vm == fake_arch_pvm_remote_vm);
	fake_arch_pvm_lock_calls++;
}

static void
fake_arch_pvm_read_unlock(void *vm)
{
	require(vm == fake_arch_pvm_local_vm || vm == fake_arch_pvm_remote_vm);
	fake_arch_pvm_unlock_calls++;
}

static void *
fake_arch_pvm_lookup_range(void *vm, unsigned long start, unsigned long end)
{
	unsigned long flag;

	require(vm == fake_arch_pvm_local_vm || vm == fake_arch_pvm_remote_vm);
	require(end >= start || end == start);
	fake_arch_pvm_lookup_calls++;
	if (fake_arch_pvm_lookup_fail_call == fake_arch_pvm_lookup_calls)
		return NULL;

	flag = fake_arch_pvm_lookup_flags[fake_arch_pvm_lookup_calls];
	fake_arch_pvm_range.start = start;
	fake_arch_pvm_range.end = end;
	fake_arch_pvm_range.flag = flag ? flag : (VR_PROT_READ | VR_PROT_WRITE);
	return &fake_arch_pvm_range;
}

static void *
fake_arch_pvm_find_process(int pid, void *lock_node)
{
	fake_arch_pvm_find_calls++;
	fake_arch_pvm_find_pid = pid;
	fake_arch_pvm_find_lock = lock_node;
	return fake_arch_pvm_find_missing ? NULL : fake_arch_pvm_remote_proc;
}

static void
fake_arch_pvm_process_unlock(void *proc, void *lock_node)
{
	require(proc == fake_arch_pvm_remote_proc);
	require(lock_node == fake_arch_pvm_find_lock);
	fake_arch_pvm_process_unlock_calls++;
}

static void
fake_arch_pvm_update_lock(void *proc, void *lock_node)
{
	require(proc == fake_arch_pvm_remote_proc);
	require(lock_node != NULL);
	fake_arch_pvm_update_lock_calls++;
}

static void
fake_arch_pvm_update_unlock(void *proc, void *lock_node)
{
	require(proc == fake_arch_pvm_remote_proc);
	require(lock_node != NULL);
	fake_arch_pvm_update_unlock_calls++;
}

static void
fake_arch_pvm_hold_vm(void *vm)
{
	require(vm == fake_arch_pvm_remote_vm);
	fake_arch_pvm_hold_calls++;
}

static void
fake_arch_pvm_release_vm(void *vm)
{
	require(vm == fake_arch_pvm_remote_vm);
	fake_arch_pvm_release_calls++;
}

static int
fake_arch_pvm_vtop(void *page_table, unsigned long virt,
		   unsigned long *phys, unsigned long *psize)
{
	fake_arch_pvm_vtop_calls++;
	fake_arch_pvm_vtop_last_virt = virt;
	require(page_table == (void *)0xfeed1000UL);
	if (fake_arch_pvm_vtop_calls <= fake_arch_pvm_vtop_fail_count)
		return -1;
	*phys = virt;
	*psize = PAGE_SIZE;
	return 0;
}

static int
fake_arch_pvm_page_fault(void *vm, unsigned long addr, unsigned long reason)
{
	require(vm == fake_arch_pvm_remote_vm);
	fake_arch_pvm_fault_calls++;
	fake_arch_pvm_fault_last_addr = addr;
	fake_arch_pvm_fault_last_reason = reason;
	return fake_arch_pvm_fault_fail ? -1 : 0;
}

static void *
fake_arch_pvm_phys_to_virt(unsigned long phys)
{
	return (void *)(uintptr_t)phys;
}

static void
fake_arch_pvm_memcpy(void *dst, const void *src, size_t bytes)
{
	fake_arch_pvm_memcpy_calls++;
	fake_arch_pvm_memcpy_bytes += bytes;
	memmove(dst, src, bytes);
}

static void
fake_arch_pvm_log(const struct fake_process_vm_rw_log_record *record)
{
	require(record != NULL);
	fake_arch_pvm_log_calls++;
}

extern int arch_process_vm_read_writev_body_result(
	int, const struct fake_iovec *, unsigned long,
	const struct fake_iovec *, unsigned long, unsigned long, int, void *,
	void *, void *, const struct fake_process_vm_rw_offsets *,
	void (*)(void *), void (*)(void *),
	void *(*)(void *, unsigned long, unsigned long),
	void *(*)(int, void *), void (*)(void *, void *),
	void (*)(void *, void *), void (*)(void *, void *),
	void (*)(void *), void (*)(void *),
	int (*)(void *, unsigned long, unsigned long *, unsigned long *),
	int (*)(void *, unsigned long, unsigned long),
	void *(*)(unsigned long), void (*)(void *, const void *, size_t),
	void (*)(const struct fake_process_vm_rw_log_record *));

static int
fake_arch_pvm_call(int pid, const struct fake_iovec *local_iov,
		   unsigned long liovcnt, const struct fake_iovec *remote_iov,
		   unsigned long riovcnt, unsigned long flags, int op,
		   struct fake_process_vm_rw_thread *thread)
{
	char find_lock;
	char update_lock;

	return arch_process_vm_read_writev_body_result(pid, local_iov, liovcnt,
		remote_iov, riovcnt, flags, op, thread, &find_lock,
		&update_lock, &fake_arch_pvm_offsets,
		fake_arch_pvm_read_lock, fake_arch_pvm_read_unlock,
		fake_arch_pvm_lookup_range, fake_arch_pvm_find_process,
		fake_arch_pvm_process_unlock, fake_arch_pvm_update_lock,
		fake_arch_pvm_update_unlock, fake_arch_pvm_hold_vm,
		fake_arch_pvm_release_vm, fake_arch_pvm_vtop,
		fake_arch_pvm_page_fault, fake_arch_pvm_phys_to_virt,
		fake_arch_pvm_memcpy, fake_arch_pvm_log);
}

static void
exercise_arch_process_vm_rw_policy(unsigned long *digest)
{
	struct fake_process_vm_rw_thread thread;
	struct fake_process_vm_rw_proc local_proc;
	struct fake_process_vm_rw_proc remote_proc;
	struct fake_process_vm_rw_vm local_vm;
	struct fake_process_vm_rw_vm remote_vm;
	struct fake_process_vm_rw_address_space remote_as;
	unsigned char local[32];
	unsigned char remote[32];
	struct fake_iovec local_iov[2];
	struct fake_iovec remote_iov[2];
	int rc;

	rc = arch_process_vm_read_writev_body_result(7, NULL, 0, NULL, 0,
		1, PROCESS_VM_READ, NULL, NULL, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		NULL, NULL);
	require(rc == -EINVAL);
	mix_signed(digest, rc);

	memset(local, 0, sizeof(local));
	memcpy(remote, "abcdefghijklmnop", 16);
	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 8 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 8 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	rc = fake_arch_pvm_call(77, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == 8);
	require(memcmp(local, remote, 8) == 0);
	require(fake_arch_pvm_lookup_calls == 6);
	require(fake_arch_pvm_find_calls == 1);
	require(fake_arch_pvm_find_pid == 77);
	require(fake_arch_pvm_process_unlock_calls == 1);
	require(fake_arch_pvm_update_lock_calls == 1);
	require(fake_arch_pvm_update_unlock_calls == 1);
	require(fake_arch_pvm_hold_calls == 1);
	require(fake_arch_pvm_release_calls == 1);
	require(fake_arch_pvm_vtop_calls == 1);
	require(fake_arch_pvm_memcpy_calls == 1);
	require(fake_arch_pvm_memcpy_bytes == 8);
	require(fake_arch_pvm_log_calls == 4);
	mix_signed(digest, rc);
	mix(digest, local[0]);

	memcpy(local, "QRSTUVWX", 8);
	memset(remote, 0, sizeof(remote));
	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 8 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 8 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	rc = fake_arch_pvm_call(78, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_WRITE, &thread);
	require(rc == 8);
	require(memcmp(remote, "QRSTUVWX", 8) == 0);
	require(fake_arch_pvm_memcpy_calls == 1);
	mix_signed(digest, rc);
	mix(digest, remote[0]);

	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 8 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 8 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_lookup_fail_call = 1;
	rc = fake_arch_pvm_call(79, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EFAULT);
	require(fake_arch_pvm_lock_calls == 1);
	require(fake_arch_pvm_unlock_calls == 1);
	require(fake_arch_pvm_find_calls == 0);
	mix_signed(digest, rc);

	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 4 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 5 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	rc = fake_arch_pvm_call(80, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EINVAL);
	require(fake_arch_pvm_lookup_calls == 2);
	require(fake_arch_pvm_find_calls == 0);
	mix_signed(digest, rc);

	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 4 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 4 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_find_missing = 1;
	rc = fake_arch_pvm_call(81, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -ESRCH);
	require(fake_arch_pvm_find_calls == 1);
	require(fake_arch_pvm_release_calls == 0);
	mix_signed(digest, rc);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	remote_proc.status = PS_EXITED;
	rc = fake_arch_pvm_call(82, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -ESRCH);
	require(fake_arch_pvm_update_lock_calls == 1);
	require(fake_arch_pvm_update_unlock_calls == 1);
	require(fake_arch_pvm_process_unlock_calls == 1);
	require(fake_arch_pvm_hold_calls == 0);
	mix_signed(digest, rc);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	remote_proc.euid = 2000;
	rc = fake_arch_pvm_call(83, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EPERM);
	require(fake_arch_pvm_hold_calls == 1);
	require(fake_arch_pvm_release_calls == 1);
	mix_signed(digest, rc);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_lookup_flags[4] = VR_PROT_READ;
	rc = fake_arch_pvm_call(84, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EFAULT);
	require(fake_arch_pvm_release_calls == 1);
	require(fake_arch_pvm_memcpy_calls == 0);
	mix_signed(digest, rc);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_lookup_flags[6] = VR_PROT_WRITE;
	rc = fake_arch_pvm_call(85, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EFAULT);
	require(fake_arch_pvm_release_calls == 1);
	require(fake_arch_pvm_memcpy_calls == 0);
	mix_signed(digest, rc);

	memset(local, 0, sizeof(local));
	memcpy(remote, "faultok", 7);
	local_iov[0] = (struct fake_iovec){ .iov_base = local, .iov_len = 7 };
	remote_iov[0] = (struct fake_iovec){ .iov_base = remote, .iov_len = 7 };
	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_vtop_fail_count = 1;
	rc = fake_arch_pvm_call(86, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == 7);
	require(memcmp(local, "faultok", 7) == 0);
	require(fake_arch_pvm_vtop_calls == 2);
	require(fake_arch_pvm_fault_calls == 1);
	require(fake_arch_pvm_fault_last_addr ==
		((unsigned long)(uintptr_t)remote & PAGE_MASK));
	require(fake_arch_pvm_fault_last_reason ==
		(PF_POPULATE | PF_WRITE | PF_USER));
	mix_signed(digest, rc);
	mix(digest, fake_arch_pvm_fault_last_reason);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_vtop_fail_count = 1;
	fake_arch_pvm_fault_fail = 1;
	rc = fake_arch_pvm_call(87, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EFAULT);
	require(fake_arch_pvm_fault_calls == 1);
	require(fake_arch_pvm_release_calls == 1);
	require(fake_arch_pvm_memcpy_calls == 0);
	mix_signed(digest, rc);

	fake_arch_pvm_reset(&thread, &local_proc, &remote_proc, &local_vm,
		&remote_vm, &remote_as, remote);
	fake_arch_pvm_vtop_fail_count = 2;
	rc = fake_arch_pvm_call(88, local_iov, 1, remote_iov, 1, 0,
		PROCESS_VM_READ, &thread);
	require(rc == -EFAULT);
	require(fake_arch_pvm_vtop_calls == 2);
	require(fake_arch_pvm_fault_calls == 1);
	require(fake_arch_pvm_release_calls == 1);
	mix_signed(digest, rc);
}

static int
fake_arch_prctl_get_cpu(void)
{
	return fake_arch_prctl_cpu;
}

static int
fake_arch_prctl_set_register(int type, unsigned long value)
{
	fake_arch_prctl_set_calls++;
	fake_arch_prctl_set_type = type;
	fake_arch_prctl_set_value = value;
	return fake_arch_prctl_set_rc;
}

static int
fake_arch_prctl_get_register(int type, unsigned long *addr)
{
	fake_arch_prctl_get_calls++;
	fake_arch_prctl_get_type = type;
	fake_arch_prctl_get_addr = addr;
	return fake_arch_prctl_get_rc;
}

static void
fake_arch_prctl_log(int event, int cpu, unsigned long value)
{
	fake_arch_prctl_log_calls++;
	fake_arch_prctl_log_event = event;
	fake_arch_prctl_log_cpu = cpu;
	fake_arch_prctl_log_value = value;
}

static void
fake_arch_clone_lock(void *lock, void *node)
{
	fake_arch_clone_lock_calls++;
	fake_arch_clone_lock_ptr = lock;
	fake_arch_clone_lock_node = node;
	fake_arch_clone_lock_seq = ++fake_arch_clone_sequence;
}

static void
fake_arch_clone_unlock(void *lock, void *node)
{
	fake_arch_clone_unlock_calls++;
	fake_arch_clone_unlock_ptr = lock;
	fake_arch_clone_unlock_node = node;
	fake_arch_clone_unlock_seq = ++fake_arch_clone_sequence;
}

static unsigned long
fake_arch_do_fork(int clone_flags, unsigned long newsp,
		  unsigned long parent_tidptr, unsigned long child_tidptr,
		  unsigned long tls, unsigned long pc, unsigned long sp)
{
	fake_arch_clone_fork_calls++;
	fake_arch_clone_fork_flags = clone_flags;
	fake_arch_clone_fork_args[0] = newsp;
	fake_arch_clone_fork_args[1] = parent_tidptr;
	fake_arch_clone_fork_args[2] = child_tidptr;
	fake_arch_clone_fork_args[3] = tls;
	fake_arch_clone_fork_args[4] = pc;
	fake_arch_clone_fork_args[5] = sp;
	fake_arch_clone_fork_seq = ++fake_arch_clone_sequence;
	return fake_arch_clone_fork_rc;
}

static void
reset_fake_rt_sigreturn(void)
{
	fake_rt_sigreturn_copy_calls = 0;
	fake_rt_sigreturn_copy_fail_at = 0;
	fake_rt_sigreturn_last_src = 0;
	fake_rt_sigreturn_last_bytes = 0;
	fake_rt_sigreturn_last_dst = NULL;
	fake_rt_sigreturn_syscall_calls = 0;
	fake_rt_sigreturn_syscall_num = 0;
	fake_rt_sigreturn_syscall_regs = NULL;
	fake_rt_sigreturn_syscall_rc = -789;
	fake_rt_sigreturn_set_signal_calls = 0;
	fake_rt_sigreturn_set_signal_sig = 0;
	fake_rt_sigreturn_set_signal_regs = NULL;
	fake_rt_sigreturn_set_signal_code = 0;
	fake_rt_sigreturn_resched_calls = 0;
	fake_rt_sigreturn_check_signal_calls = 0;
	fake_rt_sigreturn_check_signal_signum = 0;
	fake_rt_sigreturn_check_signal_regs = NULL;
	fake_rt_sigreturn_check_signal_num = 0;
	memset(fake_rt_sigreturn_alloc_area, 0,
	       sizeof(fake_rt_sigreturn_alloc_area));
	fake_rt_sigreturn_alloc_result = fake_rt_sigreturn_alloc_area + 3;
	fake_rt_sigreturn_alloc_size = 0;
	fake_rt_sigreturn_alloc_flags = 0;
	fake_rt_sigreturn_alloc_calls = 0;
	fake_rt_sigreturn_free_ptr = NULL;
	fake_rt_sigreturn_free_calls = 0;
	fake_rt_sigreturn_xrstor_ptr = NULL;
	fake_rt_sigreturn_xrstor_calls = 0;
}

static long
fake_rt_sigreturn_copy_from(void *dst, unsigned long src, size_t bytes)
{
	fake_rt_sigreturn_copy_calls++;
	fake_rt_sigreturn_last_dst = dst;
	fake_rt_sigreturn_last_src = src;
	fake_rt_sigreturn_last_bytes = bytes;
	if (fake_rt_sigreturn_copy_fail_at == fake_rt_sigreturn_copy_calls)
		return -1;
	memcpy(dst, (void *)(uintptr_t)src, bytes);
	return 0;
}

static long
fake_rt_sigreturn_syscall(int num, void *regs)
{
	fake_rt_sigreturn_syscall_calls++;
	fake_rt_sigreturn_syscall_num = num;
	fake_rt_sigreturn_syscall_regs = regs;
	return fake_rt_sigreturn_syscall_rc;
}

static void
fake_rt_sigreturn_set_signal(int sig, void *regs, const void *info)
{
	const struct fake_siginfo *sinfo = info;

	fake_rt_sigreturn_set_signal_calls++;
	fake_rt_sigreturn_set_signal_sig = sig;
	fake_rt_sigreturn_set_signal_regs = regs;
	fake_rt_sigreturn_set_signal_code = sinfo->si_code;
}

static void
fake_rt_sigreturn_check_need_resched(void)
{
	fake_rt_sigreturn_resched_calls++;
}

static void
fake_rt_sigreturn_check_signal(int signum, void *regs, int num)
{
	fake_rt_sigreturn_check_signal_calls++;
	fake_rt_sigreturn_check_signal_signum = signum;
	fake_rt_sigreturn_check_signal_regs = regs;
	fake_rt_sigreturn_check_signal_num = num;
}

static void *
fake_rt_sigreturn_alloc(size_t size, unsigned long flags)
{
	fake_rt_sigreturn_alloc_calls++;
	fake_rt_sigreturn_alloc_size = size;
	fake_rt_sigreturn_alloc_flags = flags;
	return fake_rt_sigreturn_alloc_result;
}

static void
fake_rt_sigreturn_free(void *ptr)
{
	fake_rt_sigreturn_free_calls++;
	fake_rt_sigreturn_free_ptr = ptr;
}

static void
fake_rt_sigreturn_xrstor(void *ptr)
{
	fake_rt_sigreturn_xrstor_calls++;
	fake_rt_sigreturn_xrstor_ptr = ptr;
}

static long
fake_arch_time_copy_to_user(unsigned long dst, const void *src, size_t bytes)
{
	fake_arch_time_copy_calls++;
	fake_arch_time_copy_dst = dst;
	fake_arch_time_copy_bytes = bytes;
	fake_arch_time_copy_value = *(const long *)src;
	if (fake_arch_time_copy_fail)
		return -1;
	memcpy((void *)(uintptr_t)dst, src, bytes);
	return 0;
}

static int
fake_arch_shmget_default_huge_shift(void)
{
	fake_arch_shmget_default_shift_calls++;
	return fake_arch_shmget_default_shift;
}

static int
fake_arch_do_shmget(long key, size_t size, int shmflg)
{
	fake_arch_shmget_calls++;
	fake_arch_shmget_key = key;
	fake_arch_shmget_size = size;
	fake_arch_shmget_flags = shmflg;
	return fake_arch_shmget_rc;
}

static void
fake_arch_shmget_log(int event, long key, size_t size, int shmflg0,
		     int error, int shmid)
{
	int slot = fake_arch_shmget_log_calls++;

	require(slot >= 0 && slot < 4);
	fake_arch_shmget_log_events[slot] = event;
	fake_arch_shmget_log_key[slot] = key;
	fake_arch_shmget_log_size[slot] = size;
	fake_arch_shmget_log_flags[slot] = shmflg0;
	fake_arch_shmget_log_error[slot] = error;
	fake_arch_shmget_log_shmid[slot] = shmid;
}

static int
fake_arch_mmap_default_huge_shift(void)
{
	fake_arch_mmap_default_shift_calls++;
	return fake_arch_mmap_default_shift;
}

static int
fake_arch_mmap_overmap(size_t len, int pgshift)
{
	fake_arch_mmap_overmap_calls++;
	fake_arch_mmap_overmap_len = len;
	fake_arch_mmap_overmap_shift = pgshift;
	return fake_arch_mmap_overmap_rc;
}

static int
fake_do_mmap_smaller_page(size_t size, int *p2alignp)
{
	fake_do_mmap_smaller_page_calls++;
	fake_do_mmap_smaller_page_size = size;
	if (p2alignp) {
		*p2alignp = fake_do_mmap_smaller_page_p2align;
	}
	return fake_do_mmap_smaller_page_rc;
}

static long
fake_arch_do_mmap(unsigned long addr, size_t len, int prot, int flags,
		  int fd, long off, int vrf0, void *private_data)
{
	fake_arch_mmap_calls++;
	fake_arch_mmap_addr = addr;
	fake_arch_mmap_len = len;
	fake_arch_mmap_prot = prot;
	fake_arch_mmap_flags = flags;
	fake_arch_mmap_fd = fd;
	fake_arch_mmap_off = off;
	fake_arch_mmap_vrf0 = vrf0;
	fake_arch_mmap_private_data = private_data;
	return fake_arch_mmap_rc;
}

static void
fake_arch_mmap_log(int event, unsigned long addr0, size_t len0, int prot,
		   int flags0, int fd, long off0, int error,
		   unsigned long result_addr, int extra)
{
	int slot = fake_arch_mmap_log_calls++;

	(void)prot;
	(void)fd;
	(void)off0;
	require(slot >= 0 && slot < 8);
	fake_arch_mmap_log_events[slot] = event;
	fake_arch_mmap_log_addr0[slot] = addr0;
	fake_arch_mmap_log_len0[slot] = len0;
	fake_arch_mmap_log_flags0[slot] = flags0;
	fake_arch_mmap_log_error[slot] = error;
	fake_arch_mmap_log_result[slot] = result_addr;
	fake_arch_mmap_log_extra[slot] = extra;
}

static void
fake_arch_vdso_reset(void)
{
	memset(fake_arch_vdso_setup_log_events, 0,
		sizeof(fake_arch_vdso_setup_log_events));
	memset(fake_arch_vdso_setup_log_errors, 0,
		sizeof(fake_arch_vdso_setup_log_errors));
	memset(fake_arch_vdso_add_start, 0, sizeof(fake_arch_vdso_add_start));
	memset(fake_arch_vdso_add_end, 0, sizeof(fake_arch_vdso_add_end));
	memset(fake_arch_vdso_add_flags, 0, sizeof(fake_arch_vdso_add_flags));
	memset(fake_arch_vdso_set_pt, 0, sizeof(fake_arch_vdso_set_pt));
	memset(fake_arch_vdso_set_start, 0, sizeof(fake_arch_vdso_set_start));
	memset(fake_arch_vdso_set_end, 0, sizeof(fake_arch_vdso_set_end));
	memset(fake_arch_vdso_set_phys, 0, sizeof(fake_arch_vdso_set_phys));
	memset(fake_arch_vdso_set_attr, 0, sizeof(fake_arch_vdso_set_attr));
	memset(fake_arch_vdso_set_range_token, 0,
		sizeof(fake_arch_vdso_set_range_token));
	memset(fake_arch_vdso_map_log_events, 0,
		sizeof(fake_arch_vdso_map_log_events));
	memset(fake_arch_vdso_map_log_errors, 0,
		sizeof(fake_arch_vdso_map_log_errors));
	memset(fake_arch_vdso_map_log_a, 0, sizeof(fake_arch_vdso_map_log_a));
	memset(fake_arch_vdso_map_log_b, 0, sizeof(fake_arch_vdso_map_log_b));
	memset(fake_arch_vdso_map_log_c, 0, sizeof(fake_arch_vdso_map_log_c));
	memset(fake_arch_vdso_map_log_d, 0, sizeof(fake_arch_vdso_map_log_d));
	memset(fake_arch_vdso_map_log_pages, 0,
		sizeof(fake_arch_vdso_map_log_pages));
	fake_arch_vdso_get_info_calls = 0;
	fake_arch_vdso_get_info_rc = 0;
	fake_arch_vdso_map_global_calls = 0;
	fake_arch_vdso_map_global_rc = 0;
	fake_arch_vdso_setup_log_calls = 0;
	fake_arch_vdso_add_range_calls = 0;
	fake_arch_vdso_add_fail_call = 0;
	fake_arch_vdso_add_rc = -55;
	fake_arch_vdso_set_range_calls = 0;
	fake_arch_vdso_set_fail_call = 0;
	fake_arch_vdso_set_rc = -66;
	fake_arch_vdso_map_log_calls = 0;
}

static int
fake_arch_vdso_get_info(void)
{
	fake_arch_vdso_get_info_calls++;
	return fake_arch_vdso_get_info_rc;
}

static int
fake_arch_vdso_map_global(void)
{
	fake_arch_vdso_map_global_calls++;
	return fake_arch_vdso_map_global_rc;
}

static void
fake_arch_vdso_setup_log(int event, int error)
{
	int slot = fake_arch_vdso_setup_log_calls++;

	require(slot >= 0 && slot < 8);
	fake_arch_vdso_setup_log_events[slot] = event;
	fake_arch_vdso_setup_log_errors[slot] = error;
}

static int
fake_arch_vdso_add_range(struct fake_vdso_process_vm *vm,
			 unsigned long start, unsigned long end,
			 unsigned long flags, void **range)
{
	int slot = fake_arch_vdso_add_range_calls++;

	(void)vm;
	require(slot >= 0 && slot < 4);
	fake_arch_vdso_add_start[slot] = start;
	fake_arch_vdso_add_end[slot] = end;
	fake_arch_vdso_add_flags[slot] = flags;
	if (fake_arch_vdso_add_fail_call == slot + 1)
		return fake_arch_vdso_add_rc;
	*range = (void *)(uintptr_t)(0x8800UL + (unsigned long)slot);
	return 0;
}

static int
fake_arch_vdso_set_range(void *pt, struct fake_vdso_process_vm *vm,
			 unsigned long start, unsigned long end,
			 unsigned long phys, unsigned long attr, void *range)
{
	int slot = fake_arch_vdso_set_range_calls++;

	(void)vm;
	require(slot >= 0 && slot < 8);
	fake_arch_vdso_set_pt[slot] = pt;
	fake_arch_vdso_set_start[slot] = start;
	fake_arch_vdso_set_end[slot] = end;
	fake_arch_vdso_set_phys[slot] = phys;
	fake_arch_vdso_set_attr[slot] = attr;
	fake_arch_vdso_set_range_token[slot] = range;
	if (fake_arch_vdso_set_fail_call == slot + 1)
		return fake_arch_vdso_set_rc;
	return 0;
}

static void
fake_arch_vdso_map_log(int event, int error,
		       struct fake_vdso_process_vm *vm, unsigned long a,
		       unsigned long b, unsigned long c, unsigned long d,
		       int pages)
{
	int slot = fake_arch_vdso_map_log_calls++;

	(void)vm;
	require(slot >= 0 && slot < 8);
	fake_arch_vdso_map_log_events[slot] = event;
	fake_arch_vdso_map_log_errors[slot] = error;
	fake_arch_vdso_map_log_a[slot] = a;
	fake_arch_vdso_map_log_b[slot] = b;
	fake_arch_vdso_map_log_c[slot] = c;
	fake_arch_vdso_map_log_d[slot] = d;
	fake_arch_vdso_map_log_pages[slot] = pages;
}

static void
fake_move_pages_reset(void)
{
	memset(fake_move_alloc_sizes, 0, sizeof(fake_move_alloc_sizes));
	memset(fake_move_alloc_flags, 0, sizeof(fake_move_alloc_flags));
	memset(fake_move_alloc_results, 0, sizeof(fake_move_alloc_results));
	memset(fake_move_freed, 0, sizeof(fake_move_freed));
	memset(fake_move_verify_addr, 0, sizeof(fake_move_verify_addr));
	memset(fake_move_verify_bytes, 0, sizeof(fake_move_verify_bytes));
	memset(fake_move_log_events, 0, sizeof(fake_move_log_events));
	memset(fake_move_log_values, 0, sizeof(fake_move_log_values));
	fake_move_alloc_calls = 0;
	fake_move_alloc_fail_at = -1;
	fake_move_free_calls = 0;
	fake_move_verify_calls = 0;
	fake_move_verify_fail_at = -1;
	fake_move_copy_from_calls = 0;
	fake_move_copy_to_calls = 0;
	fake_move_copy_to_rc = 0;
	fake_move_nr_nodes_value = 4;
	fake_move_lock_calls = 0;
	fake_move_unlock_calls = 0;
	fake_move_last_lock = NULL;
	fake_move_smp_calls = 0;
	fake_move_smp_rc = 0;
	fake_move_smp_cpu_set = NULL;
	fake_move_smp_req = NULL;
	fake_move_handler_calls = 0;
	fake_move_log_calls = 0;
	fake_rdtsc_value = 1000;
	fake_rdtsc_step = 10;
}

static void *
fake_move_alloc(size_t size, unsigned long flags)
{
	int index = fake_move_alloc_calls++;

	require(index < 8);
	fake_move_alloc_sizes[index] = size;
	fake_move_alloc_flags[index] = flags;
	if (fake_move_alloc_fail_at == index)
		return NULL;
	return fake_move_alloc_results[index];
}

static void
fake_move_free(void *ptr)
{
	require(fake_move_free_calls < 8);
	fake_move_freed[fake_move_free_calls++] = ptr;
}

static int
fake_move_verify(void *vm, unsigned long addr, size_t bytes)
{
	int index = fake_move_verify_calls++;

	require(vm != NULL);
	require(index < 8);
	fake_move_verify_addr[index] = addr;
	fake_move_verify_bytes[index] = bytes;
	return fake_move_verify_fail_at == index ? -1 : 0;
}

static long
fake_move_copy_from(void *dst, unsigned long src_addr, size_t bytes)
{
	fake_move_copy_from_calls++;
	memcpy(dst, (const void *)(uintptr_t)src_addr, bytes);
	return 0;
}

static long
fake_move_copy_to(unsigned long dst_addr, const void *src, size_t bytes)
{
	fake_move_copy_to_calls++;
	if (fake_move_copy_to_rc)
		return fake_move_copy_to_rc;
	memcpy((void *)(uintptr_t)dst_addr, src, bytes);
	return 0;
}

static int
fake_move_nr_nodes(void)
{
	return fake_move_nr_nodes_value;
}

static void
fake_move_lock(void *lock)
{
	fake_move_lock_calls++;
	fake_move_last_lock = lock;
}

static void
fake_move_unlock(void *lock)
{
	require(lock == fake_move_last_lock);
	fake_move_unlock_calls++;
}

static int
fake_move_handler(int cpu_index, int nr_cpus, void *arg)
{
	(void)cpu_index;
	(void)nr_cpus;
	(void)arg;
	fake_move_handler_calls++;
	return 0;
}

static int
fake_move_smp_call(void *cpu_set, int (*handler)(int, int, void *), void *arg)
{
	struct fake_move_pages_smp_req *req = arg;

	require(handler != NULL);
	fake_move_smp_calls++;
	fake_move_smp_cpu_set = cpu_set;
	fake_move_smp_req = arg;
	if (req && req->status && req->count >= 2) {
		req->status[0] = 91;
		req->status[1] = 92;
	}
	return fake_move_smp_rc;
}

static void
fake_move_log(int event, unsigned long value, int error)
{
	int index = fake_move_log_calls++;

	(void)error;
	require(index < 8);
	fake_move_log_events[index] = event;
	fake_move_log_values[index] = value;
}

static long
fake_util_thread(void *arg)
{
	fake_util_thread_calls++;
	fake_util_thread_arg = arg;
	return fake_util_thread_rc;
}

static void *
fake_util_alloc(size_t size, unsigned long flags)
{
	fake_util_alloc_calls++;
	fake_util_alloc_size = size;
	fake_util_alloc_flags = flags;
	return fake_util_alloc_result;
}

static void
fake_util_free(void *ptr)
{
	require(fake_util_free_calls < 4);
	fake_util_freed[fake_util_free_calls++] = ptr;
}

static int
fake_execveat(void *ctx, int dirfd, const void *filename, void **argv,
	      void **envp, int flags)
{
	fake_execveat_calls++;
	fake_execveat_ctx = ctx;
	fake_execveat_dirfd = dirfd;
	fake_execveat_filename = filename;
	fake_execveat_argv = argv;
	fake_execveat_envp = envp;
	fake_execveat_flags = flags;
	return fake_execveat_rc;
}

static int
fake_swapout_pageout(const void *filename, void *workarea, size_t size,
		     int flag)
{
	fake_swapout_pageout_calls++;
	fake_swapout_pageout_filename = filename;
	fake_swapout_pageout_workarea = workarea;
	fake_swapout_pageout_size = size;
	fake_swapout_pageout_flag = flag;
	return fake_swapout_pageout_rc;
}

static int
fake_swapout_pagein(int flag)
{
	fake_swapout_pagein_calls++;
	fake_swapout_pagein_flag = flag;
	return fake_swapout_pagein_rc;
}

static long
fake_strlen_user(const void *path)
{
	fake_strlen_calls++;
	if (fake_strlen_rc < 0)
		return fake_strlen_rc;
	return (long)strlen(path);
}

static long
fake_open_special(const void *pathname, int flags, void *ctx)
{
	fake_open_special_calls++;
	fake_open_special_pathname = pathname;
	fake_open_special_flags = flags;
	fake_open_special_ctx = ctx;
	return fake_open_special_rc;
}

extern int robust_list_len_result(size_t);
extern long set_robust_list_body_result(size_t);
extern int tkill_tid_result(int);
extern int tgkill_target_result(int, int);
extern int sigaction_validate(int, int);
extern int rt_sigprocmask_validate(size_t, size_t, int, int);
extern unsigned long rt_sigprocmask_apply(unsigned long, unsigned long, int,
					  int);
extern long rt_sigprocmask_body_result(int, unsigned long, unsigned long,
				       size_t, size_t, void *, size_t,
				       long (*)(void *, unsigned long,
						size_t),
				       long (*)(unsigned long, const void *,
						size_t),
				       long (*)(unsigned long));
extern int rt_sigpending_size_result(size_t, size_t);
extern int signalfd4_sigsetsize_result(size_t, size_t);
extern int signalfd4_flags_result(int);
extern long signalfd_body_result(void);
extern long syscall_temp_sigmask_body_result(unsigned long, void *, size_t,
					     int, void *,
					     long (*)(void *, unsigned long,
						      size_t),
					     long (*)(int, void *));
extern long pselect6_sigmask_body_result(unsigned long, void *, size_t,
					 int, void *,
					 long (*)(void *, unsigned long,
						  size_t),
					 long (*)(int, void *));
extern long rt_sigpending_body_result(unsigned long, size_t, size_t, void *,
				      unsigned long (*)(void *),
				      long (*)(unsigned long,
					       const void *, size_t));
extern long signalfd4_body_result(int, unsigned long, size_t, size_t, int,
				  void *, int,
				  long (*)(void *, unsigned long, size_t),
				  long (*)(int, int),
				  long (*)(void *, int,
					   const unsigned long *, int));
extern int syscall_refresh_cred_needed_result(long);
extern int syscall_getpid_result(int);
extern int syscall_getppid_result(int);
extern int syscall_gettid_result(int);
extern int syscall_set_tid_address_return_result(int);
extern long syscall_getpid_body_result(void *, size_t, size_t);
extern long syscall_getppid_body_result(void *, size_t, size_t, size_t);
extern long syscall_gettid_body_result(void *, size_t);
extern long syscall_set_tid_address_body_result(void *, size_t, size_t,
					       size_t, int *);
extern long syscall_get_process_id_field_result(void *, size_t, size_t);
extern long syscall_getresid_body_result(void *, size_t, size_t, size_t,
					 size_t, unsigned long,
					 unsigned long, unsigned long,
					 long (*)(unsigned long,
						  const int *));
extern long syscall_kill_body_result(void *, size_t, size_t, int, int,
				     long (*)(void *, int, int, int,
					      const void *, int));
extern long syscall_tgkill_body_result(void *, size_t, size_t, int, int,
				       int, long (*)(void *, int, int, int,
						     const void *, int));
extern long syscall_tkill_body_result(void *, size_t, size_t, int, int,
				      long (*)(void *, int, int, int,
					       const void *, int));
extern long syscall_forward_refresh_cred_body_result(int, void *,
						     long (*)(int, void *),
						     void (*)(void));
extern unsigned long syscall_setfsid_body_result(int, int,
						 long (*)(int, unsigned long,
							  unsigned long),
						 void (*)(void));
extern int *getcred_body_result(int *, unsigned long, int,
				unsigned long (*)(void *), int (*)(void),
				long (*)(struct fake_syscall_request *, int));
extern int syscall_refresh_cred_fields_body_result(void *, int *, size_t,
						   size_t, size_t, size_t,
						   size_t, size_t, size_t,
						   size_t, size_t,
						   int *(*)(int *));
extern long syscall_times_body_result(void *, unsigned long, int,
				      const struct fake_syscall_times_offsets *,
				      void (*)(unsigned long, void *),
				      unsigned long (*)(const void *),
				      void (*)(void *, const void *),
				      void (*)(void *),
				      long (*)(unsigned long, const void *,
					       size_t));
extern long syscall_setpgid_body_result(void *, int, int, int, void *,
					const struct fake_syscall_setpgid_offsets *,
					void *, void *(*)(int, void *),
					void (*)(void *, void *),
					long (*)(int, void *));
extern long syscall_setrlimit_body_result(int, unsigned long,
					  long (*)(int, int, unsigned long,
						   unsigned long));
extern long syscall_getrlimit_body_result(int, unsigned long,
					  long (*)(int, int, unsigned long,
						   unsigned long));
extern long syscall_prlimit64_body_result(int, int, unsigned long,
					  unsigned long,
					  long (*)(int, int, unsigned long,
						   unsigned long));
extern long syscall_sysinfo_body_result(unsigned long, unsigned long,
					unsigned long,
					long (*)(unsigned long,
						 const void *, size_t));
extern long syscall_get_cpu_id_body_result(int (*)(void));
extern long syscall_mlockall_body_result(void *, int,
					 const struct fake_syscall_mlockall_offsets *,
					 void (*)(int, int));
extern long syscall_munlockall_body_result(void (*)(int, int));
extern long syscall_getcpu_body_result(unsigned long, unsigned long, int, int,
				       long (*)(unsigned long, const void *,
						size_t));
extern long syscall_read_body_result(void *, int, int, void *,
				     const struct fake_syscall_mckfd_offsets *,
				     long (*)(void *),
				     void (*)(void *, long),
				     long (*)(int, void *));
extern long syscall_ioctl_body_result(void *, int, unsigned long,
				      unsigned long, int, void *,
				      const struct fake_syscall_mckfd_offsets *,
				      long (*)(void *),
				      void (*)(void *, long),
				      long (*)(int, void *),
				      long (*)(void *, int, unsigned long,
					       unsigned long, int *));
extern long syscall_fcntl_body_result(void *, int, int, void *,
				      const struct fake_syscall_mckfd_offsets *,
				      long (*)(void *),
				      void (*)(void *, long),
				      long (*)(int, void *));
extern long syscall_close_body_result(void *, int, int, void *,
				      const struct fake_syscall_mckfd_offsets *,
				      long (*)(void *),
				      void (*)(void *, long),
				      long (*)(int, void *),
				      void (*)(void *, int), void (*)(void *));
extern long do_mmap_mckfd_dispatch_body_result(void *, int, int, void *, int *,
				      const struct fake_syscall_mckfd_offsets *,
				      size_t, long (*)(void *),
				      void (*)(void *, long));
extern int do_mmap_page_size_body_result(int, unsigned long, int, size_t,
				      int *, int *, int (*)(void),
				      int (*)(size_t, int *));
extern long sigaltstack_body_result(void *, size_t, unsigned long,
				    unsigned long,
				    long (*)(void *, unsigned long, size_t),
				    long (*)(unsigned long, const void *,
					     size_t));
extern int syscall_use_requester_tid_result(int, unsigned long, int);
extern int syscall_target_tid_result(int, int);
extern int syscall_send_prepare_result(struct fake_syscall_request *,
				       struct fake_syscall_response *);
extern int syscall_request_copy_result(struct fake_syscall_request *,
				       const struct fake_syscall_request *);
extern int syscall_request_publish_result(struct fake_syscall_request *);
extern long syscall_generic_forwarding_body_result(
	struct fake_syscall_request *, int, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long, int,
	long (*)(struct fake_syscall_request *, int));
extern void syscall_offload_wait_reply(struct fake_syscall_request *,
	struct fake_syscall_response *, int, void *);
extern int syscall_packet_traditional_prepare_result(
	struct fake_ikc_scd_packet *, int, int, int, unsigned long);
extern int syscall_eventfd_packet_prepare_result(
	struct fake_ikc_scd_packet *, int, int);
extern int syscall_eventfd_send_result(void *, int, int,
				       int (*)(void *, void *, int));
extern int syscall_log_budget_result(int, int *, int *, int);
extern int syscall_reject_after_exit_result(int, int, int, int);
extern int syscall_offload_spin_without_schedule_result(int, int);
extern int syscall_offload_prepare_result(struct fake_syscall_request *,
					  struct fake_syscall_response *, int,
					  int, unsigned long, int,
					  unsigned long);
extern int syscall_preempt_disable_needed_result(int);
extern int syscall_proxy_dead_result(long);
extern int syscall_tofu_post_reply_candidate_result(int, long, int, int);
extern int syscall_profile_event_needed_result(int, int);
extern int syscall_offload_counted_result(int, int);
extern int syscall_nested_dispatch_valid_result(int, int, int);
extern int syscall_nested_rt_sigaction_index_result(int, int);
extern int syscall_nested_response_prepare_result(struct fake_syscall_request *,
						  struct fake_syscall_response *,
						  unsigned long,
						  unsigned long, int, int,
						  unsigned long);
extern int setpgid_normalize_pid(int, int);
extern int setpgid_normalize_pgid(int, int);
extern int setpgid_execed_result(int);
extern int memlock_prepare_range(uintptr_t, size_t, uintptr_t, uintptr_t,
				 uintptr_t *, size_t *, uintptr_t *);
extern int memlock_range_flag_result(unsigned long);
extern int memlock_body_result(void *, void *, unsigned long, size_t,
			       unsigned long, unsigned long, int, int,
			       size_t, size_t, size_t, size_t,
			       void (*)(void *), void (*)(void *),
			       void *(*)(void *, unsigned long, unsigned long),
			       void *(*)(void *, void *),
			       int (*)(void *, void *, unsigned long, void **),
			       int (*)(void *, void *, void *),
			       int (*)(void *, unsigned long, size_t),
			       void (*)(const struct memlock_log_record *));
extern int range_has_disallowed_change_flags(unsigned long);
extern int munmap_prepare_range(uintptr_t, size_t, uintptr_t, uintptr_t,
				size_t *);
extern int munmap_body_result(void *, void *, unsigned long, size_t,
			      unsigned long, unsigned long, int,
			      void (*)(void *), void (*)(void *),
			      int (*)(void *, size_t, int),
			      void (*)(int, int, unsigned long, size_t,
				       int));
extern int do_munmap_body_result(void *, void *, unsigned long, size_t, int,
				 size_t, size_t, void (*)(void),
				 int (*)(void *, unsigned long, unsigned long,
					 int *),
				 void (*)(unsigned long, size_t, int),
				 int (*)(unsigned long, size_t, int, int),
				 void (*)(void),
				 void (*)(unsigned long, size_t, int));
extern long clear_host_pte_body_result(void *, unsigned long, size_t, int,
				       size_t, int, int,
				       long (*)(int, unsigned long,
						unsigned long, unsigned long),
				       void (*)(long));
extern void munmap_all_body_result(void *, void *, void *, size_t, size_t,
				   size_t, size_t, void (*)(void *),
				   void (*)(void *),
				   void *(*)(void *, unsigned long,
					     unsigned long),
				   void *(*)(void *, void *),
				   int (*)(void *, size_t, int),
				   void (*)(void *),
				   void (*)(unsigned long, size_t, int));
extern int shmdt_body_result(void *, void *, unsigned long, size_t, size_t,
			     size_t, size_t, unsigned long, void (*)(void *),
			     void (*)(void *),
			     void *(*)(void *, unsigned long, unsigned long),
			     int (*)(void *, size_t, int),
			     void (*)(int, unsigned long, int));
extern long shmat_body_result(int, unsigned long, int, unsigned int,
			      unsigned int, void *, void *, size_t, size_t,
			      size_t, size_t, size_t, size_t, size_t, size_t,
			      void (*)(void), void (*)(void),
			      int (*)(int, void **), void (*)(void *),
			      void (*)(void *), void (*)(void *),
			      void *(*)(void *, unsigned long, unsigned long),
			      int (*)(size_t, int, unsigned long *),
			      int (*)(unsigned long, size_t, int, int),
			      int (*)(void *, unsigned long, unsigned long,
				      unsigned long, unsigned long, void *,
				      long, int),
			      void (*)(int, int, unsigned long, int, long));
extern int search_free_space_body_result(void *, void *, size_t, int,
					 unsigned long *, size_t, size_t,
					 size_t,
					 void *(*)(void *, unsigned long,
						   unsigned long),
					 void (*)(int, size_t, int,
						  unsigned long, int));
extern int set_host_vma_body_result(unsigned long, size_t, int, int);
extern int mprotect_prepare_range(uintptr_t, size_t, uintptr_t, uintptr_t,
				  size_t *, uintptr_t *);
extern void mprotect_split_needed_result(unsigned long, unsigned long,
					 unsigned long, unsigned long,
					 int *, int *);
extern int mprotect_write_changed_result(unsigned long, unsigned long);
extern int mprotect_body_result(void *, void *, unsigned long, size_t, int,
				unsigned long, unsigned long, unsigned long,
				size_t, int, size_t, size_t, size_t,
				void (*)(void *), void (*)(void *),
				void *(*)(void *, unsigned long, unsigned long),
				void *(*)(void *, void *),
				int (*)(void *, void *, unsigned long, void **),
				int (*)(void *, void *, void *),
				int (*)(void *, void *, unsigned long),
				int (*)(unsigned long, size_t, int, int),
				void (*)(void), void (*)(void),
				void (*)(const struct mprotect_log_record *));
extern int mlockall_policy_result(int, int, uint64_t);
extern int remap_file_pages_prepare(uintptr_t, size_t, int, size_t,
				    uintptr_t *, uintptr_t *, long *);
extern int remap_file_pages_body_result(void *, void *, unsigned long,
					size_t, int, size_t, int, int,
					size_t, size_t, size_t, size_t,
					void (*)(void *), void (*)(void *),
					void *(*)(void *, unsigned long,
						  unsigned long),
					int (*)(void *),
					int (*)(void *, void *, unsigned long,
						 unsigned long, long),
					void (*)(unsigned long, size_t, int),
					int (*)(void *, unsigned long, size_t),
					void (*)(void),
					void (*)(const struct remap_file_pages_log_record *));
extern int mremap_prepare_args(uintptr_t, size_t, size_t, int, uintptr_t,
			       uintptr_t, uintptr_t, size_t *, size_t *,
			       uintptr_t *, int *);
extern int mremap_fixed_range_result(uintptr_t, uintptr_t, uintptr_t,
				     uintptr_t, uintptr_t);
extern int mremap_maymove_result(int);
extern long mremap_body_result(void *, void *, void *, void *, unsigned long,
			       size_t, size_t, int, unsigned long,
			       unsigned long, unsigned long, unsigned long,
			       size_t, size_t, size_t, size_t, size_t, size_t,
			       size_t,
			       void (*)(void *), void (*)(void *),
			       void *(*)(void *, unsigned long, unsigned long),
			       int (*)(void *, void *, unsigned long),
			       void (*)(void),
			       int (*)(size_t, unsigned long, unsigned long *),
			       int (*)(void *, size_t, int),
			       void (*)(void *), void (*)(void *),
			       int (*)(void *, unsigned long, unsigned long,
				       long, unsigned long, void *,
				       unsigned long),
			       void (*)(void *), void (*)(void *),
			       int (*)(void *, void *, unsigned long, void **),
			       int (*)(void *, void *, void *, void *, size_t,
				       void *),
			       int (*)(void *, unsigned long, size_t),
			       void (*)(const struct mremap_log_record *));
extern int msync_prepare_range(uintptr_t, size_t, int, size_t *, uintptr_t *);
extern int msync_locked_range_result(int, unsigned long);
extern int msync_body_result(void *, void *, unsigned long, size_t, int,
			     size_t, size_t, size_t, size_t,
			     void (*)(void *), void (*)(void *),
			     void *(*)(void *, unsigned long, unsigned long),
			     void *(*)(void *, void *), int (*)(void *),
			     int (*)(void *, void *, unsigned long, unsigned long),
			     int (*)(void *, void *, unsigned long, unsigned long),
			     void (*)(int, unsigned long, size_t, int, int));
extern int mbind_prepare_range(uintptr_t, unsigned long, unsigned long *);
extern long mbind_body_result(unsigned long, unsigned long, int,
			      unsigned long, unsigned long, int, void *, int,
			      int, int, size_t, unsigned long,
			      long (*)(void *, unsigned long, size_t),
			      void (*)(void *), void (*)(void *),
			      void *(*)(void *, unsigned long, unsigned long),
			      void *(*)(void *, unsigned long),
			      int (*)(void *, unsigned long, unsigned long),
			      void *(*)(size_t, unsigned long),
			      void (*)(void *), int (*)(void *, void *),
			      void (*)(int, unsigned long, unsigned long, int));
extern int mempolicy_nodemask_bits_result(unsigned long, unsigned long *);
extern int mempolicy_nodemask_bits_is_clamped(unsigned long);
extern int mbind_mode_flags_result(int, unsigned int, int *, int *);
extern int mempolicy_mode_is_supported(int);
extern int set_mempolicy_normalize_mode(int, int *);
extern long set_mempolicy_body_result(int, unsigned long, unsigned long,
				      void *, int, int,
				      long (*)(void *, unsigned long, size_t),
				      void (*)(int, int, int));
extern int get_mempolicy_validate(unsigned long, int, int, unsigned long, int,
				  unsigned long *);
extern long get_mempolicy_body_result(unsigned long, unsigned long,
				      unsigned long, unsigned long, int, void *,
				      int, long (*)(unsigned long, const void *, size_t),
				      int (*)(void *, void *),
				      void (*)(void *), void (*)(void *),
				      void *(*)(void *, unsigned long, unsigned long),
				      void *(*)(void *, unsigned long),
				      void (*)(int, unsigned long, int));
	extern int move_pages_policy_result(int, int);
	extern int move_pages_smp_req_prepare_result(
		struct fake_move_pages_smp_req *, unsigned long, const void **,
		int *, const int *, void **, int *, void **, int *, int *,
		unsigned long *, void *);
	extern long move_pages_body_result(
		int, unsigned long, unsigned long, unsigned long, unsigned long,
		int, void *, void *, void *, void *, unsigned long, size_t,
		size_t, size_t, size_t, int (*)(void *, unsigned long, size_t),
		long (*)(void *, unsigned long, size_t),
		long (*)(unsigned long, const void *, size_t),
		void *(*)(size_t, unsigned long), void (*)(void *),
		int (*)(void), void (*)(void *), void (*)(void *),
		int (*)(void *, int (*)(int, int, void *), void *),
		int (*)(int, int, void *), unsigned long (*)(void),
		void (*)(int, unsigned long, int));
	extern int brk_prepare_result(unsigned long, unsigned long, unsigned long,
				      unsigned long, unsigned long *, int *);
extern unsigned long brk_default_vrflags(void);
extern unsigned long brk_body_result(void *, void *, void *, unsigned long,
				     int, size_t, size_t, size_t,
				     void (*)(void), void (*)(void *),
				     void (*)(void *),
				     unsigned long (*)(void *, unsigned long,
							unsigned long,
							unsigned long),
				     void (*)(int, int, unsigned long,
					      unsigned long, unsigned long));
extern int mincore_prepare_range(uintptr_t, size_t, uintptr_t, uintptr_t,
				 uintptr_t *);
extern long mincore_body_result(void *, void *, void *, void *,
				unsigned long, size_t, unsigned long,
				unsigned long, unsigned long,
				size_t, size_t, size_t, size_t,
				void (*)(void *), void (*)(void *),
				void (*)(void *), void (*)(void *),
				void *(*)(void *, unsigned long, unsigned long),
				void *(*)(void *, unsigned long),
				int (*)(void *), int (*)(void *, unsigned long),
				long (*)(unsigned long, unsigned char),
				void (*)(int, unsigned long, size_t,
					 unsigned long, int));
extern unsigned long mmap_base_vrflags(int, int, unsigned long, int);
extern int mmap_populated_mapping_result(int);
extern int mmap_should_set_host_ro(int, int, int);
extern int mmap_update_private_maxprot(int, int);
extern int mmap_prot_denied_result(int, int, int *);
extern unsigned long mmap_maxprot_to_vrflags(int);
extern int mmap_should_force_straight(int, int, unsigned long, size_t, size_t);
extern int mmap_is_shared(int);
extern int getrusage_who_result(int);
extern int getrusage_dispatch_result(int);
extern int getrusage_thread_update_action_result(int, int, int);
extern int getrusage_thread_times_update_prepare_result(unsigned long,
							unsigned long, int);
extern long getrusage_maxrss_kb_result(long);
extern void getrusage_timespec_add_tsc_result(long *, long *, unsigned long,
					      unsigned long);
extern void getrusage_fill_timespec_result(struct rusage *, long, long, long,
					   long, long);
extern long getrusage_body_result(int, unsigned long, void *, unsigned long,
				  const struct fake_cputime_offsets *,
				  void (*)(void *, void *),
				  void (*)(void *, void *), void *,
				  void (*)(int), void (*)(void),
				  long (*)(unsigned long, const void *,
					   size_t));
extern int itimer_which_result(int);
extern int itimer_is_real(int);
extern int itimer_should_start(long, long);
extern void itimer_snapshot_current_result(unsigned long, unsigned long,
					   unsigned long);
extern long setitimer_body_result(int, unsigned long, unsigned long, void *,
				  const struct fake_itimer_offsets *, int,
				  long (*)(int, unsigned long,
					   unsigned long, unsigned long),
				  long (*)(void *, unsigned long, size_t),
				  long (*)(unsigned long, const void *,
					   size_t),
				  void (*)(int));
extern long getitimer_body_result(int, unsigned long, void *,
				  const struct fake_itimer_offsets *, int,
				  long (*)(int, unsigned long,
					   unsigned long),
				  long (*)(unsigned long, const void *,
					   size_t));
extern int clock_gettime_dispatch(int, int, int);
extern long clock_gettime_body_result(int, unsigned long, int, int, void *,
				      unsigned long,
				      const struct fake_cputime_offsets *,
				      void (*)(void *),
				      long (*)(unsigned long, const void *,
					       size_t),
				      long (*)(int, unsigned long,
					       unsigned long),
				      void (*)(void *, void *),
				      void (*)(void *, void *), void *,
				      void (*)(int), void (*)(void));
extern int gettimeofday_dispatch(int, int, int);
extern long gettimeofday_body_result(unsigned long, unsigned long, int, int,
				     void (*)(void *),
				     long (*)(unsigned long, const void *,
					      size_t),
				     long (*)(int, unsigned long,
					      unsigned long));
extern long settimeofday_body_result(unsigned long, unsigned long, int,
				     unsigned long, int, void *, void *,
				     void *, struct timespec *,
				     void (*)(void *), void (*)(void *),
				     long (*)(void *, unsigned long, size_t),
				     unsigned long (*)(void),
				     long (*)(int, void *), long (*)(void *),
				     void (*)(void *), void (*)(void),
				     void (*)(void),
				     void (*)(int, unsigned long,
					      unsigned long, long, long,
					      long));
extern int nanosleep_validate_timespec(long, long);
extern long nanosleep_body_result(unsigned long, unsigned long, int, int,
				  void *, void *, size_t, int,
				  long (*)(void *, unsigned long, size_t),
				  long (*)(unsigned long, const void *,
					   size_t),
				  long (*)(int, unsigned long, unsigned long),
				  unsigned long (*)(void),
				  unsigned long (*)(void),
				  int (*)(void *), void (*)(void));
extern int rt_sigtimedwait_prepare(size_t, size_t, int);
extern int rt_sigtimedwait_timeout_result(long, long, int);
extern void rt_sigtimedwait_prepare_masks(unsigned long, unsigned long,
					  unsigned long *, unsigned long *,
					  unsigned long *);
extern void rt_sigtimedwait_deadline(long, long, long, long, long *, long *);
extern int rt_sigtimedwait_timeout_expired(long, long, long, long);
extern int sigmask_to_signal_number(unsigned long);
extern int signal_pending_deliverable_result(int, int, unsigned long,
					     unsigned long, unsigned long);
extern int signal_pending_interrupt_action_result(int, unsigned long,
						  unsigned long, unsigned long,
						  int);
extern int rt_sigqueueinfo_pid_result(int);
extern long rt_sigqueueinfo_body_result(int, int, unsigned long,
					long (*)(void *, unsigned long,
						 size_t),
					long (*)(int, int, const void *));
extern int sigsuspend_sigsetsize_result(size_t, size_t);
extern unsigned long sigsuspend_prepare_mask(unsigned long);
extern int sigsuspend_pending_matches(unsigned long, unsigned long);
extern long pause_body_result(void *, size_t, long (*)(void *, void *));
extern long rt_sigsuspend_body_result(void *, unsigned long, size_t, size_t,
				      void *,
				      long (*)(void *, unsigned long,
					       size_t),
				      long (*)(void *, void *));
extern int sigaction_sigsetsize_result(size_t, size_t);
extern int do_sigaction_body_result(int, const void *, void *, void *,
				    size_t, size_t, size_t, void *,
				    void (*)(void *, void *),
				    void (*)(void *, void *),
				    long (*)(int, const void *));
extern long rt_sigaction_body_result(int, unsigned long, unsigned long,
				     size_t, size_t,
				     long (*)(void *, unsigned long, size_t),
				     long (*)(unsigned long, const void *,
					      size_t),
				     int (*)(int, void *, void *));
extern int sigaltstack_validate(int, size_t);
extern int sigaltstack_is_disable(int);
extern int process_vm_validate_args(unsigned long, unsigned long, unsigned long);
extern int process_vm_op_is_write(int);
extern int process_vm_op_is_valid(int);
extern long process_vm_rw_body_result(int, const void *, unsigned long,
				      const void *, unsigned long,
				      unsigned long, int,
				      int (*)(int, const void *,
					       unsigned long, const void *,
					       unsigned long, unsigned long,
					       int));
extern int arch_process_vm_read_writev_body_result(
	int, const struct fake_iovec *, unsigned long,
	const struct fake_iovec *, unsigned long, unsigned long, int, void *,
	void *, void *, const struct fake_process_vm_rw_offsets *,
	void (*)(void *), void (*)(void *),
	void *(*)(void *, unsigned long, unsigned long),
	void *(*)(int, void *), void (*)(void *, void *),
	void (*)(void *, void *), void (*)(void *, void *),
	void (*)(void *), void (*)(void *),
	int (*)(void *, unsigned long, unsigned long *, unsigned long *),
	int (*)(void *, unsigned long, unsigned long),
	void *(*)(unsigned long), void (*)(void *, const void *, size_t),
	void (*)(const struct fake_process_vm_rw_log_record *));
extern long prctl_body_result(int, unsigned long, unsigned long,
			      unsigned long, unsigned long, void *, size_t,
			      int, void *, long (*)(int, void *));
extern int arch_prctl_type_result(unsigned long, int *);
extern long arch_prctl_body_result(unsigned long, unsigned long, void *,
				   size_t, int (*)(void),
				   int (*)(int, unsigned long),
				   int (*)(int, unsigned long *),
				   void (*)(int, int, unsigned long));
extern unsigned long arch_clone_body_result(void *, size_t, void *, int,
					    unsigned long, unsigned long,
					    unsigned long, unsigned long,
					    unsigned long, unsigned long,
					    void (*)(void *, void *),
					    void (*)(void *, void *),
					    unsigned long (*)(int,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long));
extern unsigned long arch_fork_body_result(unsigned long, unsigned long,
					   unsigned long (*)(int,
							      unsigned long,
							      unsigned long,
							      unsigned long,
							      unsigned long,
							      unsigned long,
							      unsigned long));
extern unsigned long arch_vfork_body_result(unsigned long, unsigned long,
					    unsigned long (*)(int,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long,
							       unsigned long));
extern long arch_rt_sigreturn_body_result(
	void *, void *, size_t, size_t, size_t, size_t, int, unsigned long,
	long (*)(void *, unsigned long, size_t), long (*)(int, void *),
	void (*)(int, void *, const void *), void (*)(void),
	void (*)(int, void *, int), void *(*)(size_t, unsigned long),
	void (*)(void *), void (*)(void *));
extern long arch_time_body_result(long, unsigned long,
				  long (*)(unsigned long, const void *,
					    size_t));
extern long arch_shmget_body_result(long, size_t, int, int (*)(void),
				    int (*)(long, size_t, int),
				    void (*)(int, long, size_t, int, int,
					     int));
extern long arch_mmap_body_result(unsigned long, size_t, int, int, int, long,
				  unsigned long, unsigned long, int, int,
				  int, int (*)(void), int (*)(size_t, int),
				  long (*)(unsigned long, size_t, int, int,
					   int, long, int, void *),
				  void (*)(int, unsigned long, size_t, int,
					   int, int, long, int,
					   unsigned long, int));
extern int arch_vdso_calc_container_size_result(const struct fake_arch_vdso *,
						size_t *, ptrdiff_t *);
extern int arch_setup_vdso_body_result(struct fake_arch_vdso *, size_t *,
				       ptrdiff_t *, int *, void *,
				       int (*)(void), int (*)(void),
				       void (*)(int, int));
extern int arch_map_vdso_body_result(struct fake_vdso_process_vm *, void *,
				     const struct fake_arch_vdso *, size_t,
				     ptrdiff_t,
				     int (*)(struct fake_vdso_process_vm *,
					     unsigned long, unsigned long,
					     unsigned long, void **),
				     int (*)(void *,
					     struct fake_vdso_process_vm *,
					     unsigned long, unsigned long,
					     unsigned long, unsigned long,
					     void *),
				     void (*)(int, int,
					      struct fake_vdso_process_vm *,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      int));
extern long migrate_pages_body_result(void);
extern long madvise_body_result(unsigned long, size_t, int);
extern long get_system_body_result(void);
extern long perf_event_open_disabled_body_result(void);
extern long linux_mlock_body_result(unsigned long, size_t, int,
				    long (*)(int, unsigned long,
					     unsigned long));
extern long linux_spawn_body_result(int, void *, long (*)(int, void *));
extern long swapout_body_result(const void *, void *, size_t, int, int,
				void *,
				int (*)(const void *, void *, size_t, int),
				int (*)(int), long (*)(int, void *));
extern long open_common_body_result(unsigned long, int, int, void *,
				    const void *, unsigned long,
				    long (*)(const void *),
				    long (*)(void *, unsigned long, size_t),
				    void *(*)(size_t, unsigned long),
				    void (*)(void *),
				    long (*)(const void *, int, void *),
				    long (*)(int, void *));
extern long util_migrate_inter_kernel_body_result(unsigned long, void *,
						  size_t,
						  long (*)(void *,
							   unsigned long,
							   size_t),
						  long (*)(void *));
extern long util_indicate_clone_body_result(void *, int, unsigned long,
					    size_t, unsigned long, size_t,
					    size_t, size_t, size_t,
					    long (*)(void *, unsigned long,
						     size_t),
					    void *(*)(size_t,
						      unsigned long),
					    void (*)(void *));
extern long util_register_desc_body_result(unsigned long, unsigned long *);
extern long threads_signal_body_result(void *, int, int, size_t, size_t,
				       size_t, size_t, size_t, size_t,
				       long (*)(void *, int, int, int,
						const void *, int),
				       void (*)(void));
extern int ptrace_signal_data_result(long);
extern int ptrace_detach_signal_result(long);
extern int ptrace_user_area_result(long, unsigned long);
extern int ptrace_status_allows_io(int);
extern int ptrace_setoptions_flags_result(int);
extern int ptrace_apply_options(int, int);
extern int ptrace_setoptions_apply_thread_result(unsigned long, unsigned long,
						 int);
extern int ptrace_child_traced_result(int, int, int);
extern int ptrace_attach_policy_result(int, int, int, int);
extern int ptrace_attach_mark_traced_result(unsigned long, unsigned long);
extern int ptrace_detach_state_result(int, int);
extern int ptrace_siginfo_state_result(int, int);
extern int ptrace_eventmsg_state_result(int);
extern int ptrace_eventmsg_prepare_result(int, unsigned long,
					  unsigned long *);
extern int ptrace_wakeup_request_action_result(long);
extern int ptrace_resume_single_step_result(long);
extern int ptrace_resume_trace_syscall_result(long);
extern int ptrace_resume_signal_needed_result(long, long);
extern int ptrace_resume_signal_source_result(long, int, int);
extern int ptrace_detach_forward_signal_needed_result(int);
extern int ptrace_detach_exit_signal_needed_result(int);
extern int ptrace_detach_thread_body_result(void *, int, void *, void *,
					    void *,
					    const struct fake_ptrace_detach_offsets *,
					    void (*)(void *, void *),
					    void (*)(void *, void *),
					    void (*)(void *),
					    int (*)(void *, unsigned long,
						     void *, void *, void *,
						     void *),
					    int (*)(void *, unsigned long,
						     void *, void *),
					    void *(*)(void *, unsigned long,
						       unsigned long,
						       unsigned long),
					    void (*)(void *),
					    void (*)(void *),
					    int (*)(void *, unsigned long,
						     int, int, unsigned long,
						     void *, void *, void *),
					    void (*)(void *),
					    long (*)(void *, int, int, int,
						      const void *, int),
					    void (*)(void *, int),
					    void (*)(void *),
					    void (*)(void *),
					    void *);
extern int ptrace_setsiginfo_target_result(int, int, int);
extern int ptrace_getsiginfo_prepare_result(int, unsigned long, unsigned long,
					    void *, size_t);
extern int ptrace_setsiginfo_store_result(unsigned long, unsigned long,
					  unsigned long, unsigned long, int,
					  unsigned long, const void *, size_t);
extern long ptrace_read_user_words_result(unsigned long, unsigned long *,
					  size_t,
					  long (*)(unsigned long, long,
						   unsigned long *));
extern long ptrace_write_user_words_result(unsigned long,
					   const unsigned long *, size_t,
					   long (*)(unsigned long, long,
						    unsigned long));
extern long arch_ptrace_read_gpregs_body_result(unsigned long, void *,
						size_t,
						long (*)(unsigned long, long,
							 unsigned long *));
extern long arch_ptrace_write_gpregs_body_result(unsigned long, const void *,
						 size_t,
						 long (*)(unsigned long, long,
							  unsigned long));
extern long arch_ptrace_fpregs_io_body_result(unsigned long, unsigned long,
					      size_t, size_t, size_t, int,
					      long (*)(unsigned long,
						       const void *, size_t),
					      long (*)(void *, unsigned long,
						       size_t));
extern long arch_ptrace_read_regset_body_result(unsigned long, long, void *,
						void *, size_t, size_t,
						size_t, size_t,
						long (*)(unsigned long, void *),
						long (*)(unsigned long,
							 const void *, size_t),
						long (*)(unsigned long,
							 unsigned long, size_t),
						void (*)(int, long));
extern long arch_ptrace_write_regset_body_result(unsigned long, long, void *,
						 void *, size_t, size_t,
						 size_t, size_t,
						 long (*)(unsigned long,
							  void *),
						 long (*)(unsigned long,
							  const void *),
						 long (*)(void *,
							  unsigned long,
							  size_t),
						 long (*)(unsigned long,
							  unsigned long,
							  size_t),
						 void (*)(int, long));
extern long arch_ptrace_read_user_body_result(
	void *, long, unsigned long *, size_t, size_t, size_t, size_t,
	size_t, const struct fake_arch_ptrace_user_offsets *,
	void *(*)(void *), void (*)(int, int, int));
extern long arch_ptrace_write_user_body_result(
	void *, long, unsigned long, size_t, size_t, size_t, size_t, size_t,
	size_t, const struct fake_arch_ptrace_user_offsets *,
	void *(*)(void *), void (*)(int, int, int));
extern long arch_alloc_debugreg_body_result(
	void *, size_t, size_t, unsigned long, void *(*)(size_t, unsigned long),
	void (*)(int, int, int));
extern long arch_ptrace_prctl_body_result(
	int, long, long, size_t, size_t, size_t,
	const struct fake_arch_ptrace_user_offsets *,
	unsigned long (*)(int, int), void (*)(unsigned long),
	long (*)(unsigned long, long, unsigned long *),
	long (*)(unsigned long, long, unsigned long),
	long (*)(unsigned long, const void *, size_t));
extern long ptrace_read_user_word_result(int, unsigned long, long,
					 unsigned long *,
					 long (*)(unsigned long, long,
						  unsigned long *));
extern long ptrace_write_user_word_result(int, unsigned long, long,
					  unsigned long,
					  long (*)(unsigned long, long,
						   unsigned long));
extern long ptrace_read_vm_word_result(int, unsigned long, unsigned long,
				       unsigned long *,
				       long (*)(unsigned long, unsigned long,
						unsigned long *));
extern long ptrace_write_vm_word_result(int, unsigned long, unsigned long,
					unsigned long,
					long (*)(unsigned long, unsigned long,
						 unsigned long));
extern long ptrace_fpregs_io_result(int, unsigned long, unsigned long,
				    long (*)(unsigned long, unsigned long));
extern long ptrace_regset_io_result(int, unsigned long, long, unsigned long,
				    void *, size_t, size_t, size_t,
				    long (*)(void *, unsigned long, size_t),
				    long (*)(unsigned long, long, void *),
				    long (*)(unsigned long, const void *,
					     size_t));
extern long ptrace_pokeuser_body_result(int, long, long, unsigned long,
					const struct fake_ptrace_io_offsets *,
					unsigned long (*)(int, int),
					void (*)(unsigned long),
					long (*)(unsigned long, long,
						 unsigned long));
extern long ptrace_peekuser_body_result(int, long, long, unsigned long,
					const struct fake_ptrace_io_offsets *,
					unsigned long (*)(int, int),
					void (*)(unsigned long),
					long (*)(unsigned long, long,
						 unsigned long *),
					long (*)(unsigned long, const void *,
						 size_t));
extern long ptrace_getregs_body_result(int, long, void *, size_t,
				       const struct fake_ptrace_io_offsets *,
				       unsigned long (*)(int, int),
				       void (*)(unsigned long),
				       long (*)(unsigned long, long,
						unsigned long *),
				       long (*)(unsigned long, const void *,
						size_t));
extern long ptrace_setregs_body_result(int, long, void *, size_t,
				       const struct fake_ptrace_io_offsets *,
				       unsigned long (*)(int, int),
				       void (*)(unsigned long),
				       long (*)(unsigned long, long,
						unsigned long),
				       long (*)(void *, unsigned long,
						size_t));
extern long ptrace_fpregs_body_result(int, long,
				      const struct fake_ptrace_io_offsets *,
				      unsigned long (*)(int, int),
				      void (*)(unsigned long),
				      long (*)(unsigned long, unsigned long));
extern long ptrace_regset_body_result(int, long, long, void *, size_t,
				      size_t, size_t,
				      const struct fake_ptrace_io_offsets *,
				      unsigned long (*)(int, int),
				      void (*)(unsigned long),
				      long (*)(void *, unsigned long, size_t),
				      long (*)(unsigned long, long, void *),
				      long (*)(unsigned long, const void *,
					       size_t));
extern long ptrace_peektext_body_result(int, long, long,
					const struct fake_ptrace_io_offsets *,
					unsigned long (*)(int, int),
					void (*)(unsigned long),
					long (*)(unsigned long, unsigned long,
						 unsigned long *),
					long (*)(unsigned long, const void *,
						 size_t),
					void (*)(int, unsigned long));
extern long ptrace_poketext_body_result(int, long, long,
					const struct fake_ptrace_io_offsets *,
					unsigned long (*)(int, int),
					void (*)(unsigned long),
					long (*)(unsigned long, unsigned long,
						 unsigned long),
					void (*)(int, unsigned long));
extern long ptrace_geteventmsg_body_result(int, long, size_t,
					   const struct fake_ptrace_io_offsets *,
					   unsigned long (*)(int, int),
					   void (*)(unsigned long),
					   long (*)(unsigned long,
						    const void *, size_t));
extern long ptrace_getsiginfo_body_result(int, unsigned long, void *, size_t,
					  unsigned long,
					  const struct fake_ptrace_io_offsets *,
					  unsigned long (*)(int, int),
					  void (*)(unsigned long),
					  long (*)(unsigned long,
						   const void *, size_t));
extern long ptrace_setsiginfo_body_result(int, unsigned long, void *, size_t,
					  size_t, unsigned long, unsigned long,
					  const struct fake_ptrace_io_offsets *,
					  unsigned long (*)(int, int),
					  void (*)(unsigned long),
					  void *(*)(size_t, unsigned long),
					  long (*)(void *, unsigned long,
						   size_t));
extern int ptrace_wakeup_sig_body_result(int, long, long, unsigned long,
					 unsigned long,
					 const struct fake_ptrace_io_offsets *,
					 void *, unsigned long (*)(int, int),
					 void (*)(unsigned long),
					 void (*)(int, int, int),
					 int (*)(unsigned long, unsigned long),
					 void (*)(unsigned long),
					 void (*)(unsigned long, void *),
					 int (*)(unsigned long, unsigned long,
						 int),
					 void (*)(unsigned long, void *),
					 unsigned long (*)(unsigned long,
							  unsigned long,
							  unsigned long,
							  int),
					 void (*)(void *),
					 long (*)(void *, int, int, int,
						  const void *, int),
					 void (*)(void *, int));
extern int ptrace_report_clone_body_result(
	void *, void *, int, void *,
	const struct fake_ptrace_report_clone_offsets *, void *, void *,
	void (*)(unsigned long, void *), void (*)(unsigned long, void *),
	int (*)(unsigned long, unsigned long),
	long (*)(void *, int, int, int, const void *, int),
	void (*)(void *), void (*)(int, int, int));
extern int ptrace_syscall_event_body_result(void *, size_t,
					    void (*)(void *, int));
extern int ptrace_report_exec_body_result(
	void *, void *, const struct fake_ptrace_report_exec_offsets *,
	size_t, size_t, void *, void (*)(void), void (*)(void),
	void (*)(void *, int), long (*)(void *, void *, long));
extern int ptrace_report_signal_body_result(
	void *, int, void *,
	const struct fake_ptrace_report_signal_offsets *, void *,
	void (*)(void *, void *), void (*)(void *, void *),
	void (*)(void *), void (*)(void *),
	long (*)(void *, int, int, int, const void *, int),
	void (*)(void), void (*)(int, int, int));
extern long arch_ptrace_syscall_event_body_result(void *, void *, long,
						  size_t,
						  void (*)(void *, int));
extern int ptrace_setoptions_body_result(int, int,
					 const struct fake_ptrace_io_offsets *,
					 unsigned long (*)(int, int),
					 void (*)(unsigned long),
					 void (*)(int, int, int));
extern int ptrace_attach_body_result(int, unsigned long, unsigned long,
				     const struct fake_ptrace_io_offsets *,
				     unsigned long (*)(int, int),
				     void (*)(unsigned long),
				     int (*)(unsigned long, unsigned long),
				     long (*)(void *, int, int, int,
					      const void *, int),
				     void (*)(int, int, int));
extern int ptrace_detach_body_result(int, int, unsigned long,
				     const struct fake_ptrace_io_offsets *,
				     unsigned long (*)(int, int),
				     void (*)(unsigned long),
				     void (*)(unsigned long, int));
extern int ptrace_request_dispatch_result(long);
extern int wait4_options_result(int);
extern int waitid_to_wait_pid_result(int, int, int *);
extern int waitid_options_result(int);
extern int wait_should_scan_process_result(int);
extern int wait_should_scan_thread_result(int, int);
extern int wait_process_pid_matches_result(int, int, int, int);
extern int wait_thread_tid_matches_result(int, int, int);
extern int wait_process_exited_candidate_result(int, int);
extern int wait_thread_exited_candidate_result(int, int);
extern int wait_nonptraced_stop_candidate_result(int, int, int);
extern int wait_ptraced_stop_candidate_result(int, int);
extern int wait_continued_candidate_result(int, int);
extern int wait_reap_needed_result(int);
extern int wait_nohang_result(int);
extern int wait_empty_result(int);
extern int wait_stopped_status_result(int);
extern int wait_continued_status_result(void);
extern int wait_continued_body_result(void *, void *, int *, int,
				      unsigned long, unsigned long,
				      unsigned long, unsigned long,
				      int (*)(void *, unsigned long, int,
					       int));
extern int wait_stopped_body_result(void *, void *, int *, int,
				    unsigned long, unsigned long,
				    unsigned long, unsigned long,
				    unsigned long, unsigned long,
				    int (*)(void *, unsigned long, int));
extern int do_wait_body_result(int, int *, int, void *, void *, void *,
			       unsigned long, unsigned long, unsigned long, int,
			       int (*)(int, int *, int, void *, int *),
			       int (*)(int, int *, int, void *, int *),
			       void (*)(void *, void *),
			       void (*)(void *, void *, int),
			       void (*)(void *, void *),
			       int (*)(void *), void (*)(void),
			       void (*)(int, int, int));
extern int wait_process_candidate_body_result(int, int, int *, int, void *,
					      void *, void *, void *, void *,
					      void *, void *, unsigned long,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      int (*)(void *, void *, void *,
						       int *, int),
					      int (*)(void *, void *, void *,
						       int *, int),
					      int (*)(void *, unsigned long,
						       int, int),
					      void (*)(void *, void *),
					      int *);
extern int wait_thread_candidate_body_result(int, int, int *, int, void *,
					     void *, void *, void *,
					     unsigned long, unsigned long,
					     unsigned long, unsigned long,
					     unsigned long,
					     int (*)(void *, void *, void *,
						      int *, int),
					     int (*)(void *, void *, void *,
						      int *, int),
					     int (*)(void *, unsigned long,
						      int, int),
					     void (*)(void *, void *),
					     void (*)(void *), void (*)(void *),
					     void (*)(void *), int *);
extern int wait_process_zombie_body_result(void *, void *, void *, int *, int,
					   void *, void *, void *, void *,
					   const struct fake_wait_zombie_offsets *,
					   int (*)(int, int),
					   void (*)(void *, void *),
					   void (*)(void *, void *),
					   void (*)(void *),
					   void (*)(void *, void *),
					   void (*)(void *), void (*)(void *),
					   void (*)(int, int, int, int),
					   void *, void *, void *, void *);
extern int wait_process_scan_body_result(int, int *, int, void *, int *,
					 void *, void *, void *,
					 const struct fake_wait_scan_offsets *,
					 const struct fake_wait_zombie_offsets *,
					 void (*)(void *, void *),
					 void (*)(void *, void *),
					 int (*)(int, int), void (*)(void *),
					 void (*)(void *, void *),
					 void (*)(void *), void (*)(void *),
					 void (*)(int, int, int, int),
					 int (*)(void *, void *, void *,
						  int *, int),
					 int (*)(void *, void *, void *,
						  int *, int),
					 int (*)(void *, unsigned long,
						  int, int),
					 void *, void *, void *, void *,
					 void *);
extern int wait_thread_scan_body_result(int, int *, int, void *, int *,
					void *, void *,
					const struct fake_wait_scan_offsets *,
					void (*)(void *, void *),
					void (*)(void *, void *),
					int (*)(void *, void *, void *,
						 int *, int),
					int (*)(void *, void *, void *,
						 int *, int),
					int (*)(void *, unsigned long, int,
						 int),
					void (*)(void *), void (*)(void *),
					void (*)(void *), void *);
extern int wait_zombie_skip_host_result(int, int, int);
extern int wait_thread_empty_candidate_result(int, int);
extern int waitid_status_code_result(int);
extern int wait_stopped_source_result(int, int, int, int, int);
extern int wait_stopped_exit_status_result(int, int, int, int);
extern int wait_report_id_result(int, int, int);
extern int wait_reaped_exit_status_result(int, int);
extern int wait_reaped_signal_flags_result(int, int, int);
extern int wait_process_reparent_needed_result(int, int);
extern int wait_main_thread_ptrace_detach_needed_result(int, int);
extern int wait_thread_reap_action_result(int, int);
extern int wait_status_copy_needed_result(int, int);
extern int wait_rusage_copy_needed_result(int);
extern long wait4_body_result(int, unsigned long, int, unsigned long,
			      int (*)(int, int *, int, struct rusage *),
			      long (*)(unsigned long, const void *, size_t));
extern int waitid_siginfo_needed_result(int, int);
extern void waitid_copy_siginfo_result(int, unsigned long, int, long, long,
				       long, long,
				       long (*)(unsigned long,
						const void *, size_t));
extern long waitid_body_result(int, int, unsigned long, int,
			       int (*)(int, int *, int, struct rusage *),
			       long (*)(unsigned long, const void *, size_t));
extern int exit_code_status_result(int);
extern int exit_code_signal_result(int);
extern int exit_syscall_code_result(int);
extern long exit_body_result(int, void (*)(int));
extern long exit_group_body_result(int, int, void (*)(int),
				   void (*)(int, int));
extern long sched_yield_body_result(void *, size_t, size_t, size_t,
				    unsigned int, long (*)(void *),
				    void (*)(void *, long), void (*)(void));
extern int thread_exit_signal_result(int, int);
extern int thread_exit_signal_report_needed_result(const void *);
extern int sigchld_code_result(int);
extern long thread_exit_signal_body_result(void *, size_t, size_t, size_t,
					   size_t, size_t, size_t, size_t,
					   size_t, size_t,
					   void (*)(unsigned long, void *),
					   unsigned long (*)(const void *),
					   long (*)(void *, int, int, int,
						    const void *, int),
					   void (*)(void *),
					   void (*)(int, long));
extern long finalize_process_parent_notify_body_result(void *, size_t, size_t,
						       size_t, size_t, size_t,
						       size_t, size_t,
						       unsigned long (*)(const void *),
						       long (*)(void *, int,
								int, int,
								const void *,
								int),
						       void (*)(void *),
						       void (*)(int, long));
extern long finalize_process_body_result(void *, const void *, void *,
					 size_t, size_t, size_t, size_t,
					 size_t, size_t, size_t, size_t,
					 size_t, void (*)(void *, void *),
					 void (*)(void *, void *),
					 void (*)(void *), void (*)(void),
					 unsigned long (*)(const void *),
					 long (*)(void *, int, int, int,
						  const void *, int),
					 void (*)(void *),
					 void (*)(int, long));
extern int exit_group_status_claimed_result(unsigned long);
extern int terminate_group_status_update_failed_result(unsigned long,
						       unsigned long);
extern int terminate_host_exit_needed_result(int);
extern long terminate_mcexec_body_result(void *, struct fake_syscall_request *,
					 int, int, int, int, size_t, size_t,
					 unsigned long (*)(unsigned long *,
							   unsigned long,
							   unsigned long),
					 long (*)(struct fake_syscall_request *,
						  int));
extern int sync_child_event_needed_result(int, int, int);
extern int sync_child_event_pid_action_result(int);
extern long sync_child_event_body_result(void *, int, int, size_t, size_t,
					 size_t, size_t, size_t, size_t,
					 size_t, unsigned long (*)(int),
					 void (*)(void *, long));
extern unsigned long perf_event_read_value_body_result(void *, void *, int,
						       int, int, size_t,
						       size_t, size_t,
						       size_t, size_t,
						       size_t, size_t,
						       size_t, size_t,
						       size_t, size_t,
						       size_t,
						       unsigned long (*)(void *),
						       long (*)(void *));
extern unsigned long perf_event_read_value_entry_body_result(
	void *, void *, size_t, size_t, size_t, size_t, size_t, size_t,
	size_t, size_t, size_t, size_t, size_t, size_t, size_t,
	int (*)(const void *, int *, int *, int *),
	unsigned long (*)(void *), long (*)(void *));
extern long perf_event_read_one_body_result(void *, unsigned long,
					    unsigned long (*)(void *),
					    long (*)(unsigned long,
						     const void *, size_t));
extern long perf_event_read_group_body_result(void *, unsigned long,
					      size_t, size_t, size_t, size_t,
					      unsigned long (*)(void *),
					      long (*)(unsigned long,
						       const void *, size_t));
extern long perf_read_body_result(void *, unsigned long, unsigned long,
				  unsigned long,
				  long (*)(void *, unsigned long,
					    unsigned long),
				  long (*)(void *, unsigned long,
					    unsigned long));
extern int perf_counter_set_body_result(void *, int, int, int, unsigned long,
					size_t, int, int, int (*)(void *),
					int (*)(int, unsigned long, int));
extern int perf_counter_set_entry_body_result(void *, size_t, size_t, size_t,
					      size_t, int, int,
					      int (*)(const void *, int *,
						       int *),
					      int (*)(void *),
					      int (*)(int, unsigned long,
						       int));
extern long perf_start_body_result(void *, void *, size_t, size_t, size_t,
				   size_t, size_t, size_t, size_t, size_t,
				   size_t, size_t, size_t, size_t, size_t,
				   size_t, size_t, size_t, int, int, int,
				   int (*)(unsigned long), int (*)(void *),
				   int (*)(void *), int (*)(unsigned long));
extern long perf_reset_body_result(void *, void *, size_t, size_t, size_t,
				   size_t, size_t, size_t, size_t, size_t,
				   size_t, size_t, size_t, size_t, size_t,
				   size_t, int (*)(unsigned long),
				   unsigned long (*)(void *),
				   void (*)(void *, long));
extern long perf_stop_body_result(void *, void *, size_t, size_t, size_t,
				  size_t, size_t, size_t, size_t, size_t,
				  size_t, size_t, size_t, size_t, size_t,
				  int, int, int, int,
				  int (*)(unsigned long),
				  int (*)(unsigned long, int),
				  unsigned long (*)(void *));
extern long perf_ioctl_body_result(void *, void *, void *, unsigned long, int,
				   unsigned long, unsigned long,
				   unsigned long, unsigned long, int,
				   size_t, size_t, size_t,
				   void (*)(void *), void (*)(void *),
				   void (*)(void *), void *(*)(int, void *),
				   void (*)(void *, void *));
extern long perf_close_body_result(void *, void *, size_t, size_t, size_t,
				   size_t, size_t, void (*)(void *));
extern long perf_fcntl_body_result(void *, void *, int, long, int, int, int,
				   size_t, long (*)(int, void *));
extern long perf_mmap_body_result(unsigned long, size_t, int, int, int, long,
				  int, int, size_t, size_t, unsigned long,
				  long (*)(unsigned long, size_t, int, int,
					    int, long, int, void *));
extern int perf_event_open_validate_body_result(int, unsigned long,
						unsigned long, unsigned long,
						int, unsigned long,
						unsigned long, unsigned long,
						unsigned long, unsigned long,
						unsigned long);
extern long perf_event_alloc_init_body_result(void *, const void *, size_t,
					      size_t, size_t, size_t, size_t,
					      size_t, size_t, size_t, size_t,
					      size_t, size_t, size_t, size_t,
					      size_t, unsigned long,
					      unsigned long, int,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      void (*)(void *, long));
extern long perf_event_alloc_map_body_result(void **, void *, size_t, size_t,
					     size_t, size_t, size_t,
					     unsigned long, unsigned long,
					     unsigned long, unsigned long,
					     unsigned long,
					     unsigned long (*)(unsigned long),
					     unsigned long (*)(unsigned long),
					     unsigned long (*)(unsigned long),
					     unsigned long (*)(unsigned long),
					     int (*)(unsigned long),
					     int (*)(unsigned long,
						     unsigned long),
					     unsigned int (*)(int),
					     int (*)(int),
					     int (*)(void *));
extern long perf_event_alloc_body_result(void **, const void *, size_t,
					 size_t, unsigned long, size_t,
					 size_t, size_t, size_t, size_t,
					 size_t, size_t, size_t, size_t,
					 size_t, size_t, size_t, size_t,
					 size_t, size_t, size_t, size_t,
					 unsigned long, unsigned long, int,
					 unsigned long, unsigned long,
					 unsigned long, unsigned long,
					 unsigned long, unsigned long,
					 void *(*)(size_t, unsigned long),
					 void (*)(void *),
					 void (*)(void *, long),
					 unsigned long (*)(unsigned long),
					 unsigned long (*)(unsigned long),
					 unsigned long (*)(unsigned long),
					 unsigned long (*)(unsigned long),
					 int (*)(unsigned long),
					 int (*)(unsigned long,
						 unsigned long),
					 unsigned int (*)(int),
					 int (*)(int),
					 int (*)(void *));
extern long perf_event_open_group_body_result(void *, void *, int, int,
					      size_t, size_t, size_t, size_t,
					      size_t, size_t, size_t, size_t,
					      size_t);
extern long perf_event_open_counter_body_result(void *, void *, int, size_t,
						size_t,
						int (*)(void *, void *));
extern long perf_event_open_linux_fd_body_result(
	struct fake_syscall_request *, void *, int, int, int, size_t,
	long (*)(struct fake_syscall_request *, int));
extern long perf_event_open_mckfd_publish_body_result(void *, void *, void *,
						      int, size_t, size_t,
						      size_t, size_t, size_t,
						      size_t, size_t, size_t,
						      size_t, size_t, size_t,
						      long (*)(void *,
								void *),
						      int (*)(void *,
							       void *),
						      long (*)(void *,
								void *),
						      int (*)(void *,
							       void *),
						      int (*)(void *,
							       void *),
						      long (*)(void *),
						      void (*)(void *,
							      long));
extern long perf_event_open_body_result(
	struct fake_syscall_request *, void *, void *, void *, int, int, int,
	int, size_t, unsigned long, size_t, size_t, size_t, size_t, size_t,
	size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t,
	size_t, size_t, size_t, size_t, size_t, size_t,
	int (*)(void **, void *), int (*)(void *, void *),
	long (*)(struct fake_syscall_request *, int),
	void *(*)(size_t, unsigned long), long (*)(void *, void *),
	int (*)(void *, void *), long (*)(void *, void *),
	int (*)(void *, void *), int (*)(void *, void *), long (*)(void *),
	void (*)(void *, long));
extern long perf_event_open_entry_body_result(
	struct fake_syscall_request *, void *, void *, void *, unsigned long,
	size_t, size_t, size_t, size_t, int, int, int, unsigned long, int,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int, size_t, unsigned long, size_t, size_t, size_t,
	size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t,
	size_t, size_t, size_t, size_t, size_t, size_t, size_t, size_t,
	long (*)(void *, unsigned long, size_t), int (*)(const void *),
	int (*)(void **, void *), int (*)(void *, void *),
	long (*)(struct fake_syscall_request *, int),
	void *(*)(size_t, unsigned long), long (*)(void *, void *),
	int (*)(void *, void *), long (*)(void *, void *),
	int (*)(void *, void *), int (*)(void *, void *), long (*)(void *),
	void (*)(void *, long));
extern unsigned long exit_group_status_result(int, int);
extern int terminate_thread_active_result(int);
extern int terminate_process_exited_result(int);
extern int terminate_thread_is_other_result(const void *, const void *);
extern int terminate_report_thread_ptrace_result(int);
extern int terminate_child_cleanup_needed_result(int, int);
extern int terminate_release_child_needed_result(int);
extern int process_lookup_missing_result(const void *);
extern int process_cleanup_tofu_needed_result(int);
extern int process_cleanup_fd_path_free_needed_result(const void *);
extern long process_cleanup_fd_body_result(int, int, void *,
					  void *(*)(int, void *),
					  void (*)(void *, void *),
					  long (*)(void *, int),
					  void (*)(int));
extern long process_cleanup_before_terminate_body_result(int, void *, int,
							 int, int,
							 void *(*)(int,
								   void *),
							 void (*)(void *,
								  void *),
							 long (*)(void *,
								  int));
extern int terminate_host_detached_thread_release_needed_result(const void *,
							 const void *);
extern int terminate_host_kill_needed_result(int);
extern long terminate_host_body_result(int, void *, void *, void *, size_t,
				       size_t, size_t, void *(*)(int, void *),
				       void (*)(void *, void *),
				       void (*)(void *, int),
				       void (*)(void *), void (*)(void *),
				       long (*)(void *, int, int, int,
						const void *, int));
extern int finalize_process_parent_is_pid1_result(const void *, const void *);
extern int finalize_process_parent_signal_needed_result(int);
extern int terminate_status_result(int, int);
extern int terminate_report_thread_release_needed_result(int, int);
extern int terminate_child_action_result(int, int, int);
extern int clone_pthread_marker_result(int, unsigned long, unsigned long);
extern int clone_flags_result(int, int);
extern int clone_host_parent_flags_result(int, int);
extern int clone_report_thread_result(int, int);
extern int clone_parent_tid_store_needed_result(int);
extern int clone_child_cleartid_needed_result(int);
extern int clone_child_tid_store_needed_result(int);
extern int clone_tls_source_result(int);
extern int clone_use_last_cpu_result(int, int);
extern int clone_remote_spawn_result(int);
extern int clone_parent_use_pid1_result(int);
extern int ptrace_exec_event_signal_result(int);
extern int ptrace_syscall_event_signal_result(int);
extern int ptrace_clone_event_result(int, int);
extern int ptrace_clone_reparent_result(int);
extern int execveat_policy_result(int, int, int);
extern long execveat_body_result(void *, int, const void *, void **, void **,
				 int, int,
				 int (*)(void *, int, const void *,
					  void **, void **, int));
extern long execve_body_result(void *, const void *, void **, void **,
			       int (*)(void *, int, const void *, void **,
					void **, int));
extern int futex_decode_flags_result(int, int *, int *);
extern int futex_wait_timeout_needed_result(int, int);
extern int futex_timeout_is_absolute_result(int);
extern int futex_clock_id_result(int);
extern unsigned int futex_requeue_val2_result(int, unsigned long);
extern unsigned long futex_timeout_ns_result(int, long, long, long, long);
extern long do_futex_body_result(int, unsigned long, unsigned long,
				 unsigned long, unsigned long, unsigned long,
				 unsigned long, int, int,
				 int (*)(int, int, struct timespec *),
				 void (*)(struct timespec *),
				 int (*)(int, struct timespec *),
				 unsigned long (*)(void),
				 int (*)(unsigned long, int, uint32_t,
					  uint64_t, unsigned long, uint32_t,
					  uint32_t, int),
				 void (*)(const struct fake_do_futex_log_record *));

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static void require_at(int condition, int line)
{
	if (!condition) {
		fprintf(stderr, "syscall_policy require failed at line %d\n",
			line);
		exit(31);
	}
}

static void require(int condition)
{
	require_at(condition, 0);
}

#define require(condition) require_at((condition), __LINE__)

#ifdef SYSCALL_POLICY_USE_C_MODEL
static void
c_arch_process_vm_log(
	void (*log_fn)(const struct fake_process_vm_rw_log_record *),
	int event, int x, int y, int z, unsigned long a, unsigned long b,
	unsigned long c, unsigned long d, unsigned long e)
{
	struct fake_process_vm_rw_log_record record;

	if (!log_fn)
		return;
	record.event = event;
	record.x = x;
	record.y = y;
	record.z = z;
	record.a = a;
	record.b = b;
	record.c = c;
	record.d = d;
	record.e = e;
	log_fn(&record);
}

int
arch_process_vm_read_writev_body_result(
	int pid, const struct fake_iovec *local_iov, unsigned long liovcnt,
	const struct fake_iovec *remote_iov, unsigned long riovcnt,
	unsigned long flags, int op, void *lthread, void *find_lock_node,
	void *update_lock_node, const struct fake_process_vm_rw_offsets *offsets,
	void (*vm_read_lock_fn)(void *),
	void (*vm_read_unlock_fn)(void *),
	void *(*lookup_range_fn)(void *, unsigned long, unsigned long),
	void *(*find_process_fn)(int, void *),
	void (*process_unlock_fn)(void *, void *),
	void (*update_lock_fn)(void *, void *),
	void (*update_unlock_fn)(void *, void *),
	void (*hold_vm_fn)(void *), void (*release_vm_fn)(void *),
	int (*vtop_fn)(void *, unsigned long, unsigned long *, unsigned long *),
	int (*page_fault_fn)(void *, unsigned long, unsigned long),
	void *(*phys_to_virt_fn)(unsigned long),
	void (*memcpy_fn)(void *, const void *, size_t),
	void (*log_fn)(const struct fake_process_vm_rw_log_record *))
{
	int ret;
	size_t llen = 0, rlen = 0, copied = 0;
	size_t loff = 0, roff = 0;
	size_t to_copy;
	size_t li, ri, pli, pri;
	void *lproc, *lvm, *rproc, *rvm, *range;

	if (flags || liovcnt > IOV_MAX || riovcnt > IOV_MAX)
		return -EINVAL;
	if (!lthread || !find_lock_node || !update_lock_node || !offsets)
		return -EFAULT;
	if (!vm_read_lock_fn || !vm_read_unlock_fn || !lookup_range_fn ||
	    !find_process_fn || !process_unlock_fn || !update_lock_fn ||
	    !update_unlock_fn || !hold_vm_fn || !release_vm_fn || !vtop_fn ||
	    !page_fault_fn || !phys_to_virt_fn || !memcpy_fn)
		return -EFAULT;

	lproc = *(void **)((char *)lthread + offsets->thread_proc_offset);
	lvm = *(void **)((char *)lthread + offsets->thread_vm_offset);
	if (!lproc || !lvm)
		return -EFAULT;

	vm_read_lock_fn(lvm);
	range = lookup_range_fn(lvm, (unsigned long)(uintptr_t)local_iov,
		(unsigned long)(uintptr_t)(local_iov + liovcnt));
	if (!range) {
		ret = -EFAULT;
		goto arg_out;
	}
	range = lookup_range_fn(lvm, (unsigned long)(uintptr_t)remote_iov,
		(unsigned long)(uintptr_t)(remote_iov + riovcnt));
	ret = range ? 0 : -EFAULT;
arg_out:
	vm_read_unlock_fn(lvm);
	if (ret)
		return ret;

	for (li = 0; li < liovcnt; li++) {
		llen += local_iov[li].iov_len;
		c_arch_process_vm_log(log_fn, 1, (int)li, 0, 0,
			(unsigned long)(uintptr_t)local_iov[li].iov_base,
			local_iov[li].iov_len, 0, 0, 0);
	}
	for (ri = 0; ri < riovcnt; ri++) {
		rlen += remote_iov[ri].iov_len;
		c_arch_process_vm_log(log_fn, 2, (int)ri, 0, 0,
			(unsigned long)(uintptr_t)remote_iov[ri].iov_base,
			remote_iov[ri].iov_len, 0, 0, 0);
	}
	if (llen != rlen)
		return -EINVAL;

	rproc = find_process_fn(pid, find_lock_node);
	if (!rproc)
		return -ESRCH;
	update_lock_fn(rproc, update_lock_node);
	if (*(int *)((char *)rproc + offsets->proc_status_offset) ==
			PS_EXITED ||
	    *(int *)((char *)rproc + offsets->proc_status_offset) ==
			PS_ZOMBIE) {
		update_unlock_fn(rproc, update_lock_node);
		process_unlock_fn(rproc, find_lock_node);
		return -ESRCH;
	}
	rvm = *(void **)((char *)rproc + offsets->proc_vm_offset);
	if (!rvm) {
		update_unlock_fn(rproc, update_lock_node);
		process_unlock_fn(rproc, find_lock_node);
		return -EFAULT;
	}
	hold_vm_fn(rvm);
	update_unlock_fn(rproc, update_lock_node);
	process_unlock_fn(rproc, find_lock_node);

	if (*(int *)((char *)lproc + offsets->proc_euid_offset) != 0 &&
	    (*(int *)((char *)lproc + offsets->proc_ruid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_ruid_offset) ||
	     *(int *)((char *)lproc + offsets->proc_ruid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_euid_offset) ||
	     *(int *)((char *)lproc + offsets->proc_ruid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_suid_offset) ||
	     *(int *)((char *)lproc + offsets->proc_rgid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_rgid_offset) ||
	     *(int *)((char *)lproc + offsets->proc_rgid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_egid_offset) ||
	     *(int *)((char *)lproc + offsets->proc_rgid_offset) !=
	     *(int *)((char *)rproc + offsets->proc_sgid_offset))) {
		release_vm_fn(rvm);
		return -EPERM;
	}

	c_arch_process_vm_log(log_fn, 3, pid, op, 0, liovcnt, riovcnt, 0, 0, 0);

	pli = pri = (size_t)-1;
	li = ri = 0;
	ret = 0;
	while (copied < llen) {
		int faulted = 0;
		unsigned long rphys = 0, psize = 0, rpage_left, remote_addr;
		void *rva, *aspace, *page_table;

		if (pli != li) {
			unsigned long base =
				(unsigned long)(uintptr_t)local_iov[li].iov_base;

			vm_read_lock_fn(lvm);
			range = lookup_range_fn(lvm, base, base + 1);
			if (!range) {
				ret = -EFAULT;
			}
			else {
				range = lookup_range_fn(lvm, base,
					base + local_iov[li].iov_len);
				if (!range) {
					ret = -EINVAL;
				}
				else if (!(*(unsigned long *)((char *)range +
						offsets->vm_range_flag_offset) &
					   ((op == PROCESS_VM_READ) ?
					    VR_PROT_WRITE : VR_PROT_READ))) {
					ret = -EFAULT;
				}
			}
			vm_read_unlock_fn(lvm);
			if (ret)
				break;
			pli = li;
		}

		if (pri != ri) {
			size_t check = li;
			unsigned long base =
				(unsigned long)(uintptr_t)remote_iov[check].iov_base;

			vm_read_lock_fn(rvm);
			range = lookup_range_fn(rvm, base, base + 1);
			if (!range) {
				ret = -EFAULT;
			}
			else {
				range = lookup_range_fn(rvm, base,
					base + remote_iov[check].iov_len);
				if (!range) {
					ret = -EINVAL;
				}
				else if (!(*(unsigned long *)((char *)range +
						offsets->vm_range_flag_offset) &
					   ((op == PROCESS_VM_READ) ?
					    VR_PROT_READ : VR_PROT_WRITE))) {
					ret = -EFAULT;
				}
			}
			vm_read_unlock_fn(rvm);
			if (ret)
				break;
			pri = ri;
		}

		to_copy = local_iov[li].iov_len - loff;
		if (remote_iov[ri].iov_len - roff < to_copy)
			to_copy = remote_iov[ri].iov_len - roff;
		remote_addr = (unsigned long)(uintptr_t)remote_iov[ri].iov_base +
			roff;

retry_lookup:
		aspace = *(void **)((char *)rvm +
			offsets->process_vm_address_space_offset);
		page_table = aspace ? *(void **)((char *)aspace +
			offsets->address_space_page_table_offset) : NULL;
		ret = vtop_fn(page_table, remote_addr, &rphys, &psize);
		if (ret) {
			unsigned long addr;

			if (faulted) {
				ret = -EFAULT;
				break;
			}
			for (addr = remote_addr & PAGE_MASK;
			     addr < remote_addr + to_copy; addr += PAGE_SIZE) {
				ret = page_fault_fn(rvm, addr,
					PF_POPULATE | PF_WRITE | PF_USER);
				if (ret) {
					ret = -EFAULT;
					break;
				}
			}
			if (ret)
				break;
			faulted = 1;
			goto retry_lookup;
		}

		rpage_left = ((remote_addr + psize) & ~(psize - 1)) -
			remote_addr;
		if (rpage_left < to_copy)
			to_copy = rpage_left;
		rva = phys_to_virt_fn(rphys);
		if (op == PROCESS_VM_READ)
			memcpy_fn((void *)((uintptr_t)local_iov[li].iov_base +
					  loff), rva, to_copy);
		else
			memcpy_fn(rva, (void *)((uintptr_t)local_iov[li].iov_base +
					       loff), to_copy);
		copied += to_copy;
		c_arch_process_vm_log(log_fn, 4, (int)li, (int)ri, op,
			(unsigned long)(uintptr_t)local_iov[li].iov_base +
				loff,
			remote_addr, to_copy, psize, rpage_left);

		loff += to_copy;
		roff += to_copy;
		if (loff == local_iov[li].iov_len) {
			li++;
			loff = 0;
		}
		if (roff == remote_iov[ri].iov_len) {
			ri++;
			roff = 0;
		}
	}

	release_vm_fn(rvm);
	return ret ? ret : (int)copied;
}

long
arch_rt_sigreturn_body_result(
	void *thread, void *regs0, size_t sigmask_offset,
	size_t sigstack_offset, size_t sigstack_size, size_t frame_size,
	int xsave_size, unsigned long nowait_flag,
	long (*copy_from_fn)(void *, unsigned long, size_t),
	long (*syscall_fn)(int, void *),
	void (*set_signal_fn)(int, void *, const void *),
	void (*check_need_resched_fn)(void),
	void (*check_signal_fn)(int, void *, int),
	void *(*alloc_fn)(size_t, unsigned long),
	void (*free_fn)(void *), void (*xrstor_fn)(void *))
{
	struct fake_rt_sigreturn_context *regs = regs0;
	struct fake_rt_sigreturn_frame *sigsp;
	struct fake_rt_sigreturn_frame frame;

	if (!thread || !regs || !copy_from_fn)
		return -EFAULT;
	if (sigstack_size != sizeof(stack_t) ||
	    frame_size != sizeof(struct fake_rt_sigreturn_frame))
		return -EFAULT;

	sigsp = (struct fake_rt_sigreturn_frame *)regs->gpr.rsp;
	if (!sigsp)
		return -EFAULT;
	if (copy_from_fn(&frame, (unsigned long)(uintptr_t)sigsp,
			 sizeof(frame)))
		return -EFAULT;

	regs->gpr.r15 = frame.regs[7];
	regs->gpr.r14 = frame.regs[6];
	regs->gpr.r13 = frame.regs[5];
	regs->gpr.r12 = frame.regs[4];
	regs->gpr.rbp = frame.regs[10];
	regs->gpr.rbx = frame.regs[11];
	regs->gpr.r11 = frame.regs[3];
	regs->gpr.r10 = frame.regs[2];
	regs->gpr.r9 = frame.regs[1];
	regs->gpr.r8 = frame.regs[0];
	regs->gpr.rax = frame.regs[13];
	regs->gpr.rcx = frame.regs[14];
	regs->gpr.rdx = frame.regs[12];
	regs->gpr.rsi = frame.regs[9];
	regs->gpr.rdi = frame.regs[8];
	regs->gpr.error = frame.regs[19];
	regs->gpr.rip = frame.regs[16];
	regs->gpr.rflags = frame.regs[17];
	regs->gpr.rsp = frame.regs[15];
	*(unsigned long *)((char *)thread + sigmask_offset) = frame.regs[21];
	memcpy((char *)thread + sigstack_offset, &frame.sigstack,
	       sigstack_size);

	if (sigsp->restart) {
		if (!syscall_fn)
			return -EFAULT;
		return syscall_fn(sigsp->num, regs);
	}
	if (regs->gpr.rflags & RFLAGS_TF) {
		struct fake_siginfo info;

		if (!set_signal_fn || !check_need_resched_fn ||
		    !check_signal_fn)
			return -EFAULT;
		regs->gpr.rax = sigsp->sigrc;
		memset(&info, 0, sizeof(info));
		regs->gpr.rflags &= ~RFLAGS_TF;
		info.si_code = TRAP_TRACE;
		set_signal_fn(SIGTRAP, regs, &info);
		check_need_resched_fn();
		check_signal_fn(0, regs, -1);
	}

	if (frame.fpregs && xsave_size) {
		void *fpregs;

		if (!alloc_fn || !free_fn || !xrstor_fn)
			return -EFAULT;
		fpregs = alloc_fn((size_t)xsave_size + 64, nowait_flag);
		if (fpregs) {
			void *kfpregs = (void *)((((uintptr_t)fpregs) + 63) &
						~(uintptr_t)63);

			if (copy_from_fn(kfpregs,
					 (unsigned long)(uintptr_t)frame.fpregs,
					 (size_t)xsave_size))
				return -EFAULT;
			xrstor_fn(kfpregs);
			free_fn(fpregs);
		}
	}

	return (long)sigsp->sigrc;
}

static void
c_arch_vdso_container(const struct fake_arch_vdso *vdso,
		      size_t *container_size, ptrdiff_t *vdso_offset)
{
	ptrdiff_t start = 0;
	ptrdiff_t end = vdso->vdso_npages * PAGE_SIZE;
	ptrdiff_t s, e;

	if (vdso->vvar_virt && !vdso->vvar_is_global) {
		s = (ptrdiff_t)vdso->vvar_virt;
		e = s + PAGE_SIZE;
		if (s < start)
			start = s;
		if (end < e)
			end = e;
	}
	if (vdso->hpet_virt && !vdso->hpet_is_global) {
		s = (ptrdiff_t)vdso->hpet_virt;
		e = s + PAGE_SIZE;
		if (s < start)
			start = s;
		if (end < e)
			end = e;
	}
	if (vdso->pvti_virt && !vdso->pvti_is_global) {
		s = (ptrdiff_t)vdso->pvti_virt;
		e = s + PAGE_SIZE;
		if (s < start)
			start = s;
		if (end < e)
			end = e;
	}

	*vdso_offset = start < 0 ? -start : 0;
	*container_size = end - start;
}

int
arch_vdso_calc_container_size_result(const struct fake_arch_vdso *vdso,
				     size_t *container_size,
				     ptrdiff_t *vdso_offset)
{
	if (!vdso || !container_size || !vdso_offset)
		return -EINVAL;

	c_arch_vdso_container(vdso, container_size, vdso_offset);
	return 0;
}

int
arch_setup_vdso_body_result(struct fake_arch_vdso *vdso,
			    size_t *container_size, ptrdiff_t *vdso_offset,
			    int *gettime_local_supportp, void *tod_do_local,
			    int (*get_info_fn)(void),
			    int (*map_global_fn)(void),
			    void (*log_fn)(int, int))
{
	int error;

	if (!vdso || !container_size || !vdso_offset ||
	    !gettime_local_supportp || !tod_do_local)
		return -EFAULT;
	if (!get_info_fn)
		return -EFAULT;

	error = get_info_fn();
	if (error) {
		if (log_fn)
			log_fn(ARCH_VDSO_SETUP_LOG_GET_INFO_FAILED, error);
		return error;
	}
	if (*gettime_local_supportp && !vdso->vgtod_virt) {
		if (log_fn)
			log_fn(ARCH_VDSO_SETUP_LOG_LOCAL_GETTIME_DISABLED, 0);
		*gettime_local_supportp = 0;
		*(signed char *)tod_do_local = 0;
	}
	if (!vdso->vgtod_virt && vdso->vdso_npages > 0) {
		if (log_fn)
			log_fn(ARCH_VDSO_SETUP_LOG_VDSO_DISABLED, 0);
		vdso->vdso_npages = 0;
		*container_size = 0;
		*vdso_offset = 0;
	}
	if (vdso->vdso_npages <= 0)
		return 0;
	if (!map_global_fn)
		return -EFAULT;

	error = map_global_fn();
	if (error) {
		if (log_fn)
			log_fn(ARCH_VDSO_SETUP_LOG_MAP_GLOBAL_FAILED, error);
		return error;
	}

	c_arch_vdso_container(vdso, container_size, vdso_offset);
	return 0;
}

static unsigned long
c_arch_vdso_addr_add(unsigned long base, ptrdiff_t offset)
{
	return base + (unsigned long)offset;
}

int
arch_map_vdso_body_result(struct fake_vdso_process_vm *vm, void *pt,
			  const struct fake_arch_vdso *vdso,
			  size_t container_size, ptrdiff_t vdso_offset,
			  int (*add_range_fn)(struct fake_vdso_process_vm *,
					      unsigned long, unsigned long,
					      unsigned long, void **),
			  int (*set_range_fn)(void *,
					      struct fake_vdso_process_vm *,
					      unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      void *),
			  void (*log_fn)(int, int,
					 struct fake_vdso_process_vm *,
					 unsigned long, unsigned long,
					 unsigned long, unsigned long, int))
{
	unsigned long container, vdso_addr, vdso_end, vdso_page_bytes;
	unsigned long vrflags;
	void *range = NULL;
	int error;

	if (container_size == 0) {
		if (log_fn)
			log_fn(ARCH_VDSO_MAP_LOG_NOT_AVAILABLE, 0, vm,
			       0, 0, 0, 0, 0);
		return 0;
	}
	if (!vm || !vdso)
		return -EFAULT;
	if (!add_range_fn || !set_range_fn)
		return -EFAULT;

	container = vm->region.map_end;
	vm->region.map_end += container_size;
	vdso_addr = c_arch_vdso_addr_add(container, vdso_offset);
	vdso_page_bytes = vdso->vdso_npages * PAGE_SIZE;
	vdso_end = vdso_addr + vdso_page_bytes;
	vrflags = VR_REMOTE | VR_PROT_READ | VR_PROT_EXEC;
	vrflags |= VRFLAG_PROT_TO_MAXPROT(vrflags);

	error = add_range_fn(vm, vdso_addr, vdso_end, vrflags, &range);
	if (error) {
		if (log_fn)
			log_fn(ARCH_VDSO_MAP_LOG_ADD_VDSO_FAILED, error,
			       vm, 0, 0, 0, 0, 0);
		return error;
	}
	vm->vdso_addr = (void *)vdso_addr;
	if (log_fn)
		log_fn(ARCH_VDSO_MAP_LOG_MAPPED, 0, vm, container,
		       vdso_addr, vdso_end, container_size, vdso->vdso_npages);

	for (int i = 0; i < vdso->vdso_npages; i++) {
		unsigned long s = vdso_addr + i * PAGE_SIZE;
		unsigned long e = s + PAGE_SIZE;

		error = set_range_fn(pt, vm, s, e, vdso->vdso_physlist[i],
				     PTATTR_ACTIVE | PTATTR_USER, range);
		if (error) {
			if (log_fn)
				log_fn(ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED,
				       error, vm, 0, 0, 0, 0, 0);
			return error;
		}
	}

	if (container_size > vdso_page_bytes) {
		unsigned long vvar_start, vvar_end;

		if (vdso_offset) {
			vvar_start = container;
			vvar_end = container + vdso_offset;
		}
		else {
			vvar_start = container + vdso_page_bytes;
			vvar_end = container + container_size;
		}
		vrflags = VR_REMOTE | VR_PROT_READ;
		vrflags |= VRFLAG_PROT_TO_MAXPROT(vrflags);
		error = add_range_fn(vm, vvar_start, vvar_end, vrflags,
				     &range);
		if (error) {
			if (log_fn)
				log_fn(ARCH_VDSO_MAP_LOG_ADD_VVAR_FAILED,
				       error, vm, 0, 0, 0, 0, 0);
			return error;
		}
		vm->vvar_addr = (void *)vvar_start;

		if (vdso->vvar_virt && !vdso->vvar_is_global) {
			unsigned long s = c_arch_vdso_addr_add(
				(unsigned long)vm->vdso_addr,
				(ptrdiff_t)vdso->vvar_virt);
			unsigned long e = s + PAGE_SIZE;
			error = set_range_fn(pt, vm, s, e, vdso->vvar_phys,
					     PTATTR_ACTIVE | PTATTR_USER |
					     PTATTR_NO_EXECUTE, range);
			if (error) {
				if (log_fn)
					log_fn(ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED,
					       error, vm, 0, 0, 0, 0, 0);
				return error;
			}
		}
		if (vdso->hpet_virt && !vdso->hpet_is_global) {
			unsigned long s = c_arch_vdso_addr_add(
				(unsigned long)vm->vdso_addr,
				(ptrdiff_t)vdso->hpet_virt);
			unsigned long e = s + PAGE_SIZE;
			error = set_range_fn(pt, vm, s, e, vdso->hpet_phys,
					     PTATTR_ACTIVE | PTATTR_USER |
					     PTATTR_NO_EXECUTE |
					     PTATTR_UNCACHABLE, range);
			if (error) {
				if (log_fn)
					log_fn(ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED,
					       error, vm, 0, 0, 0, 0, 0);
				return error;
			}
		}
		if (vdso->pvti_virt && !vdso->pvti_is_global) {
			unsigned long s = c_arch_vdso_addr_add(
				(unsigned long)vm->vdso_addr,
				(ptrdiff_t)vdso->pvti_virt);
			unsigned long e = s + PAGE_SIZE;
			error = set_range_fn(pt, vm, s, e, vdso->pvti_phys,
					     PTATTR_ACTIVE | PTATTR_USER |
					     PTATTR_NO_EXECUTE, range);
			if (error) {
				if (log_fn)
					log_fn(ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED,
					       error, vm, 0, 0, 0, 0, 0);
				return error;
			}
		}
	}

	return 0;
}

long
arch_ptrace_read_gpregs_body_result(unsigned long thread_addr, void *regs,
				    size_t regs_size,
				    long (*read_fn)(unsigned long, long,
						    unsigned long *))
{
	unsigned long *out = regs;
	size_t offset = 0;
	size_t index = 0;

	if (!regs)
		return -EFAULT;
	memset(regs, 0, regs_size);
	if (!thread_addr)
		return -EFAULT;
	if (!read_fn)
		return -EFAULT;
	while (offset < regs_size) {
		long rc = read_fn(thread_addr, (long)offset, &out[index]);

		if (rc)
			return rc;
		offset += sizeof(unsigned long);
		index++;
	}
	return 0;
}

long
arch_ptrace_write_gpregs_body_result(unsigned long thread_addr,
				     const void *regs, size_t regs_size,
				     long (*write_fn)(unsigned long, long,
						      unsigned long))
{
	const unsigned long *in = regs;
	size_t offset = 0;
	size_t index = 0;

	if (!thread_addr || !regs)
		return -EFAULT;
	if (!write_fn)
		return -EFAULT;
	while (offset < regs_size) {
		long rc = write_fn(thread_addr, (long)offset, in[index]);

		if (rc)
			return rc;
		offset += sizeof(unsigned long);
		index++;
	}
	return 0;
}

long
arch_ptrace_fpregs_io_body_result(unsigned long thread_addr,
				  unsigned long user_addr,
				  size_t fp_regs_offset,
				  size_t fp_i387_offset,
				  size_t fp_i387_size, int is_write,
				  long (*copy_to_fn)(unsigned long,
						     const void *, size_t),
				  long (*copy_from_fn)(void *,
						       unsigned long, size_t))
{
	void **slot;
	char *fp_regs;

	if (!thread_addr)
		return -EFAULT;
	slot = (void **)((char *)thread_addr + fp_regs_offset);
	fp_regs = *slot;
	if (!fp_regs)
		return -ENOMEM;
	if (is_write) {
		if (!copy_from_fn)
			return -EFAULT;
		return copy_from_fn(fp_regs + fp_i387_offset, user_addr,
				    fp_i387_size);
	}
	else {
		if (!copy_to_fn)
			return -EFAULT;
		return copy_to_fn(user_addr, fp_regs + fp_i387_offset,
				  fp_i387_size);
	}
}

long
arch_ptrace_read_regset_body_result(unsigned long thread_addr, long type,
				    void *iovp, void *scratch,
				    size_t user_regs_size, size_t xstate_size,
				    size_t iov_base_offset,
				    size_t iov_len_offset,
				    long (*read_gpregs_fn)(unsigned long,
							   void *),
				    long (*copy_to_fn)(unsigned long,
						       const void *, size_t),
				    long (*xstate_copy_to_fn)(unsigned long,
							      unsigned long,
							      size_t),
				    void (*log_fn)(int, long))
{
	unsigned long *basep;
	size_t *lenp;
	size_t len;
	long rc;

	if (!thread_addr || !iovp)
		return -EFAULT;
	basep = (unsigned long *)((char *)iovp + iov_base_offset);
	lenp = (size_t *)((char *)iovp + iov_len_offset);
	len = *lenp;
	if (type == NT_PRSTATUS) {
		if (!scratch || !read_gpregs_fn || !copy_to_fn)
			return -EFAULT;
		if (len > user_regs_size) {
			len = user_regs_size;
			*lenp = len;
		}
		rc = read_gpregs_fn(thread_addr, scratch);
		if (rc)
			return rc;
		return copy_to_fn(*basep, scratch, len);
	}
	if (type == NT_X86_XSTATE) {
		if (!xstate_copy_to_fn)
			return -EFAULT;
		if (len > xstate_size) {
			len = xstate_size;
			*lenp = len;
		}
		return xstate_copy_to_fn(thread_addr, *basep, len);
	}
	if (log_fn)
		log_fn(ARCH_PTRACE_REGSET_LOG_READ_UNSUPPORTED, type);
	return -EINVAL;
}

long
arch_ptrace_write_regset_body_result(unsigned long thread_addr, long type,
				     void *iovp, void *scratch,
				     size_t user_regs_size,
				     size_t xstate_size,
				     size_t iov_base_offset,
				     size_t iov_len_offset,
				     long (*read_gpregs_fn)(unsigned long,
							    void *),
				     long (*write_gpregs_fn)(unsigned long,
							     const void *),
				     long (*copy_from_fn)(void *,
							  unsigned long,
							  size_t),
				     long (*xstate_copy_from_fn)(unsigned long,
								 unsigned long,
								 size_t),
				     void (*log_fn)(int, long))
{
	unsigned long *basep;
	size_t *lenp;
	size_t len;
	long rc;

	if (!thread_addr || !iovp)
		return -EFAULT;
	basep = (unsigned long *)((char *)iovp + iov_base_offset);
	lenp = (size_t *)((char *)iovp + iov_len_offset);
	len = *lenp;
	if (type == NT_PRSTATUS) {
		if (!scratch || !read_gpregs_fn || !write_gpregs_fn ||
		    !copy_from_fn)
			return -EFAULT;
		if (len > user_regs_size) {
			len = user_regs_size;
			*lenp = len;
		}
		rc = read_gpregs_fn(thread_addr, scratch);
		if (rc)
			return rc;
		rc = copy_from_fn(scratch, *basep, len);
		if (rc)
			return rc;
		return write_gpregs_fn(thread_addr, scratch);
	}
	if (type == NT_X86_XSTATE) {
		if (!xstate_copy_from_fn)
			return -EFAULT;
		if (len > xstate_size) {
			len = xstate_size;
			*lenp = len;
		}
		return xstate_copy_from_fn(thread_addr, *basep, len);
	}
	if (log_fn)
		log_fn(ARCH_PTRACE_REGSET_LOG_WRITE_UNSUPPORTED, type);
	return -EINVAL;
}

static void *
c_arch_ptrace_user_context(void *thread,
	const struct fake_arch_ptrace_user_offsets *offsets,
	void *(*lookup_fn)(void *))
{
	char *base = thread;

	if (*(int *)(base + offsets->thread_ptrace_saved_uctx_valid_offset))
		return base + offsets->thread_ptrace_saved_uctx_offset;
	if (lookup_fn)
		return lookup_fn(thread);
	return NULL;
}

long
arch_ptrace_read_user_body_result(void *thread, long addr,
	unsigned long *valuep, size_t word_size, size_t user_regs_size,
	size_t user_regs_fs_base_offset, size_t user_debugreg_start_offset,
	size_t user_debugreg_end_offset,
	const struct fake_arch_ptrace_user_offsets *offsets,
	void *(*lookup_fn)(void *), void (*log_fn)(int, int, int))
{
	char *base = thread;
	size_t addr_u = (size_t)addr;

	if (!thread || !valuep || !offsets || !word_size)
		return -EFAULT;
	if (addr < 0 || (addr_u & (word_size - 1)))
		return -EIO;
	if (addr_u < user_regs_size) {
		char *uctx = c_arch_ptrace_user_context(thread, offsets,
							lookup_fn);
		char *src;

		if (!uctx)
			return -EIO;
		if (addr_u < user_regs_fs_base_offset)
			src = uctx + offsets->uctx_gpr_offset + addr_u;
		else
			src = uctx + offsets->uctx_sr_offset +
				(addr_u - user_regs_fs_base_offset);
		*valuep = *(unsigned long *)src;
		return 0;
	}
	if (user_debugreg_start_offset <= addr_u &&
	    addr_u < user_debugreg_end_offset) {
		unsigned long *debugreg = *(unsigned long **)(base +
			offsets->thread_ptrace_debugreg_offset);
		size_t index;

		if (!debugreg) {
			if (log_fn)
				log_fn(ARCH_PTRACE_USER_LOG_READ_MISSING_DEBUGREG,
				       0, 0);
			return -EFAULT;
		}
		index = (addr_u - user_debugreg_start_offset) / word_size;
		*valuep = debugreg[index];
		return 0;
	}
	if (log_fn)
		log_fn(ARCH_PTRACE_USER_LOG_READ_OTHER, (int)addr, 0);
	*valuep = 0;
	return 0;
}

long
arch_ptrace_write_user_body_result(void *thread, long addr,
	unsigned long value, size_t word_size, size_t user_regs_size,
	size_t user_regs_fs_base_offset, size_t user_regs_eflags_offset,
	size_t user_debugreg_start_offset, size_t user_debugreg_end_offset,
	const struct fake_arch_ptrace_user_offsets *offsets,
	void *(*lookup_fn)(void *), void (*log_fn)(int, int, int))
{
	char *base = thread;
	size_t addr_u = (size_t)addr;

	if (!thread || !offsets || !word_size)
		return -EFAULT;
	if (addr < 0 || (addr_u & (word_size - 1)))
		return -EIO;
	if (addr_u < user_regs_size) {
		char *uctx = c_arch_ptrace_user_context(thread, offsets,
							lookup_fn);

		if (!uctx)
			return -EIO;
		if (addr_u == user_regs_eflags_offset) {
			unsigned long *rflagsp = (unsigned long *)(uctx +
				offsets->uctx_gpr_offset + addr_u);
			*rflagsp &= ~RFLAGS_MASK;
			*rflagsp |= value & RFLAGS_MASK;
		}
		else if (addr_u < user_regs_fs_base_offset) {
			*(unsigned long *)(uctx + offsets->uctx_gpr_offset +
				addr_u) = value;
		}
		else {
			*(unsigned long *)(uctx + offsets->uctx_sr_offset +
				(addr_u - user_regs_fs_base_offset)) = value;
		}
		return 0;
	}
	if (user_debugreg_start_offset <= addr_u &&
	    addr_u < user_debugreg_end_offset) {
		unsigned long *debugreg = *(unsigned long **)(base +
			offsets->thread_ptrace_debugreg_offset);
		size_t index;

		if (!debugreg) {
			if (log_fn)
				log_fn(ARCH_PTRACE_USER_LOG_WRITE_MISSING_DEBUGREG,
				       0, 0);
			return -EFAULT;
		}
		if (addr_u == user_debugreg_start_offset + 6 * word_size) {
			value &= ~DB6_RESERVED_MASK;
			value |= DB6_RESERVED_SET;
		}
		if (addr_u == user_debugreg_start_offset + 7 * word_size) {
			value &= ~DB7_RESERVED_MASK;
			value |= DB7_RESERVED_SET;
		}
		index = (addr_u - user_debugreg_start_offset) / word_size;
		debugreg[index] = value;
		return 0;
	}
	if (log_fn)
		log_fn(ARCH_PTRACE_USER_LOG_WRITE_OTHER, (int)addr, 0);
	return 0;
}

long
arch_alloc_debugreg_body_result(void *thread, size_t debugreg_offset,
	size_t alloc_size, unsigned long alloc_flags,
	void *(*alloc_fn)(size_t, unsigned long),
	void (*log_fn)(int, int, int))
{
	unsigned long **slot;
	unsigned long *debugreg;

	if (!thread || !alloc_fn)
		return -ENOMEM;
	slot = (unsigned long **)((char *)thread + debugreg_offset);
	debugreg = alloc_fn(alloc_size, alloc_flags);
	*slot = debugreg;
	if (!debugreg) {
		if (log_fn)
			log_fn(ARCH_PTRACE_USER_LOG_ALLOC_FAILED, 0, 0);
		return -ENOMEM;
	}
	memset(debugreg, 0, alloc_size);
	debugreg[6] = DB6_RESERVED_SET;
	debugreg[7] = DB7_RESERVED_SET;
	return 0;
}

long
arch_ptrace_prctl_body_result(int pid, long code, long addr,
	size_t word_size, size_t user_regs_fs_base_offset,
	size_t user_regs_gs_base_offset,
	const struct fake_arch_ptrace_user_offsets *offsets,
	unsigned long (*find_fn)(int, int), void (*unlock_fn)(unsigned long),
	long (*read_user_fn)(unsigned long, long, unsigned long *),
	long (*write_user_fn)(unsigned long, long, unsigned long),
	long (*copy_to_fn)(unsigned long, const void *, size_t))
{
	unsigned long child;
	void *proc;
	long rc = -EIO;

	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(pid, pid);
	if (!child)
		return -ESRCH;
	proc = *(void **)((char *)child + offsets->thread_proc_offset);
	if (proc && (*(int *)((char *)proc + offsets->proc_status_offset) &
	    (PS_TRACED | PS_STOPPED))) {
		if (code == ARCH_GET_FS || code == ARCH_GET_GS) {
			unsigned long value;
			size_t reg_offset = code == ARCH_GET_FS ?
				user_regs_fs_base_offset :
				user_regs_gs_base_offset;

			if (!read_user_fn || !copy_to_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			rc = read_user_fn(child, (long)reg_offset, &value);
			if (rc == 0)
				rc = copy_to_fn((unsigned long)addr, &value,
						word_size);
		}
		else if (code == ARCH_SET_FS || code == ARCH_SET_GS) {
			size_t reg_offset = code == ARCH_SET_FS ?
				user_regs_fs_base_offset :
				user_regs_gs_base_offset;

			if (!write_user_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			rc = write_user_fn(child, (long)reg_offset,
					   (unsigned long)addr);
		}
		else {
			rc = -EINVAL;
		}
	}
	unlock_fn(child);
	return rc;
}

static int
c_ptrace_io_status(unsigned long thread_addr,
		   const struct fake_ptrace_io_offsets *offsets)
{
	return *(int *)((char *)thread_addr + offsets->thread_status_offset);
}

static unsigned long
c_ptrace_io_proc(unsigned long thread_addr,
		 const struct fake_ptrace_io_offsets *offsets)
{
	return (unsigned long)*(void **)((char *)thread_addr +
					 offsets->thread_proc_offset);
}

static int
c_ptrace_io_ptrace(unsigned long thread_addr,
		   const struct fake_ptrace_io_offsets *offsets)
{
	return *(int *)((char *)thread_addr + offsets->thread_ptrace_offset);
}

static unsigned long
c_ptrace_io_report_proc(unsigned long thread_addr,
			const struct fake_ptrace_io_offsets *offsets)
{
	return (unsigned long)*(void **)((char *)thread_addr +
					 offsets->thread_report_proc_offset);
}

static int
c_ptrace_io_proc_pid(unsigned long proc_addr,
		     const struct fake_ptrace_io_offsets *offsets)
{
	return *(int *)((char *)proc_addr + offsets->proc_pid_offset);
}

static unsigned long
c_ptrace_io_proc_update_lock(unsigned long proc_addr,
			     const struct fake_ptrace_io_offsets *offsets)
{
	return proc_addr + offsets->proc_update_lock_offset;
}

static unsigned long
c_ptrace_io_vm(unsigned long thread_addr,
	       const struct fake_ptrace_io_offsets *offsets)
{
	return (unsigned long)*(void **)((char *)thread_addr +
					 offsets->thread_vm_offset);
}

static unsigned long
c_ptrace_io_eventmsg(unsigned long thread_addr,
		     const struct fake_ptrace_io_offsets *offsets)
{
	return *(unsigned long *)((char *)thread_addr +
				  offsets->thread_ptrace_eventmsg_offset);
}

static unsigned long
c_ptrace_io_recvsig(unsigned long thread_addr,
		    const struct fake_ptrace_io_offsets *offsets)
{
	return (unsigned long)*(void **)((char *)thread_addr +
					 offsets->thread_ptrace_recvsig_offset);
}

static unsigned long
c_ptrace_io_sendsig(unsigned long thread_addr,
		    const struct fake_ptrace_io_offsets *offsets)
{
	return (unsigned long)*(void **)((char *)thread_addr +
					 offsets->thread_ptrace_sendsig_offset);
}

long
ptrace_pokeuser_body_result(int pid, long addr, long data,
			    unsigned long user_struct_size,
			    const struct fake_ptrace_io_offsets *offsets,
			    unsigned long (*find_fn)(int, int),
			    void (*unlock_fn)(unsigned long),
			    long (*write_fn)(unsigned long, long,
					     unsigned long))
{
	unsigned long child;
	long rc = ptrace_user_area_result(addr, user_struct_size);

	if (rc)
		return rc;
	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	rc = ptrace_write_user_word_result(c_ptrace_io_status(child, offsets),
					   child, addr, (unsigned long)data,
					   write_fn);
	unlock_fn(child);
	return rc;
}

long
ptrace_peekuser_body_result(int pid, long addr, long data,
			    unsigned long user_struct_size,
			    const struct fake_ptrace_io_offsets *offsets,
			    unsigned long (*find_fn)(int, int),
			    void (*unlock_fn)(unsigned long),
			    long (*read_fn)(unsigned long, long,
					    unsigned long *),
			    long (*copy_to_fn)(unsigned long, const void *,
					       size_t))
{
	unsigned long child;
	unsigned long value = 0;
	long rc = ptrace_user_area_result(addr, user_struct_size);

	if (rc)
		return rc;
	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	rc = ptrace_read_user_word_result(c_ptrace_io_status(child, offsets),
					  child, addr, &value, read_fn);
	if (!rc) {
		if (!copy_to_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		rc = copy_to_fn((unsigned long)data, &value, sizeof(value));
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_getregs_body_result(int pid, long data, void *scratch,
			   size_t regs_size,
			   const struct fake_ptrace_io_offsets *offsets,
			   unsigned long (*find_fn)(int, int),
			   void (*unlock_fn)(unsigned long),
			   long (*read_fn)(unsigned long, long,
					   unsigned long *),
			   long (*copy_to_fn)(unsigned long, const void *,
					      size_t))
{
	unsigned long child;
	long rc = -EIO;

	if (!offsets || !scratch || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	if (ptrace_status_allows_io(c_ptrace_io_status(child, offsets))) {
		memset(scratch, 0, regs_size);
		rc = ptrace_read_user_words_result(child, scratch, regs_size,
						   read_fn);
		if (!rc) {
			if (!copy_to_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			rc = copy_to_fn((unsigned long)data, scratch, regs_size);
		}
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_setregs_body_result(int pid, long data, void *scratch,
			   size_t regs_size,
			   const struct fake_ptrace_io_offsets *offsets,
			   unsigned long (*find_fn)(int, int),
			   void (*unlock_fn)(unsigned long),
			   long (*write_fn)(unsigned long, long,
					    unsigned long),
			   long (*copy_from_fn)(void *, unsigned long,
						size_t))
{
	unsigned long child;
	long rc = -EIO;

	if (!offsets || !scratch || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	if (ptrace_status_allows_io(c_ptrace_io_status(child, offsets))) {
		if (!copy_from_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		rc = copy_from_fn(scratch, (unsigned long)data, regs_size);
		if (!rc)
			rc = ptrace_write_user_words_result(child, scratch,
							    regs_size,
							    write_fn);
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_fpregs_body_result(int pid, long data,
			  const struct fake_ptrace_io_offsets *offsets,
			  unsigned long (*find_fn)(int, int),
			  void (*unlock_fn)(unsigned long),
			  long (*io_fn)(unsigned long, unsigned long))
{
	unsigned long child;
	long rc;

	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	rc = ptrace_fpregs_io_result(c_ptrace_io_status(child, offsets),
				     child, (unsigned long)data, io_fn);
	unlock_fn(child);
	return rc;
}

long
ptrace_regset_body_result(int pid, long type, long data, void *iovp,
			  size_t iov_size, size_t iov_len_offset,
			  size_t iov_len_size,
			  const struct fake_ptrace_io_offsets *offsets,
			  unsigned long (*find_fn)(int, int),
			  void (*unlock_fn)(unsigned long),
			  long (*copy_from_fn)(void *, unsigned long, size_t),
			  long (*io_fn)(unsigned long, long, void *),
			  long (*copy_to_fn)(unsigned long, const void *,
					     size_t))
{
	unsigned long child;
	long rc;

	if (!offsets || !iovp || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	rc = ptrace_regset_io_result(c_ptrace_io_status(child, offsets),
				     child, type, (unsigned long)data, iovp,
				     iov_size, iov_len_offset, iov_len_size,
				     copy_from_fn, io_fn, copy_to_fn);
	unlock_fn(child);
	return rc;
}

long
ptrace_peektext_body_result(int pid, long addr, long data,
			    const struct fake_ptrace_io_offsets *offsets,
			    unsigned long (*find_fn)(int, int),
			    void (*unlock_fn)(unsigned long),
			    long (*read_fn)(unsigned long, unsigned long,
					    unsigned long *),
			    long (*copy_to_fn)(unsigned long, const void *,
					       size_t),
			    void (*log_fn)(int, unsigned long))
{
	unsigned long child;
	unsigned long value = 0;
	int status;
	long rc;

	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	status = c_ptrace_io_status(child, offsets);
	rc = ptrace_read_vm_word_result(status, c_ptrace_io_vm(child, offsets),
					(unsigned long)addr, &value, read_fn);
	if (rc) {
		if (ptrace_status_allows_io(status) && log_fn)
			log_fn(PTRACE_TEXT_LOG_PEEK_BAD_AREA,
			       (unsigned long)addr);
	}
	else {
		if (!copy_to_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		rc = copy_to_fn((unsigned long)data, &value, sizeof(value));
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_poketext_body_result(int pid, long addr, long data,
			    const struct fake_ptrace_io_offsets *offsets,
			    unsigned long (*find_fn)(int, int),
			    void (*unlock_fn)(unsigned long),
			    long (*write_fn)(unsigned long, unsigned long,
					     unsigned long),
			    void (*log_fn)(int, unsigned long))
{
	unsigned long child;
	int status;
	long rc;

	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	status = c_ptrace_io_status(child, offsets);
	rc = ptrace_write_vm_word_result(status, c_ptrace_io_vm(child, offsets),
					 (unsigned long)addr,
					 (unsigned long)data, write_fn);
	if (rc && ptrace_status_allows_io(status) && log_fn)
		log_fn(PTRACE_TEXT_LOG_POKE_BAD_ADDRESS, (unsigned long)addr);
	unlock_fn(child);
	return rc;
}

long
ptrace_geteventmsg_body_result(int pid, long data, size_t word_size,
			       const struct fake_ptrace_io_offsets *offsets,
			       unsigned long (*find_fn)(int, int),
			       void (*unlock_fn)(unsigned long),
			       long (*copy_to_fn)(unsigned long, const void *,
						  size_t))
{
	unsigned long child;
	unsigned long eventmsg;
	long rc;

	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	eventmsg = c_ptrace_io_eventmsg(child, offsets);
	rc = ptrace_eventmsg_prepare_result(c_ptrace_io_status(child, offsets),
					    eventmsg, &eventmsg);
	if (!rc) {
		if (!copy_to_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		if (copy_to_fn((unsigned long)data, &eventmsg, word_size))
			rc = -EFAULT;
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_getsiginfo_body_result(int pid, unsigned long data, void *scratch,
			      size_t info_size, unsigned long info_offset,
			      const struct fake_ptrace_io_offsets *offsets,
			      unsigned long (*find_fn)(int, int),
			      void (*unlock_fn)(unsigned long),
			      long (*copy_to_fn)(unsigned long,
						 const void *, size_t))
{
	unsigned long child;
	unsigned long pending;
	long rc;

	if (!offsets || !scratch || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	pending = c_ptrace_io_recvsig(child, offsets);
	rc = ptrace_getsiginfo_prepare_result(
		c_ptrace_io_status(child, offsets), pending, info_offset,
		scratch, info_size);
	if (!rc) {
		if (!copy_to_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		if (copy_to_fn(data, scratch, info_size))
			rc = -EFAULT;
	}
	unlock_fn(child);
	return rc;
}

long
ptrace_setsiginfo_body_result(int pid, unsigned long data, void *scratch,
			      size_t info_size, size_t pending_size,
			      unsigned long alloc_flags,
			      unsigned long info_offset,
			      const struct fake_ptrace_io_offsets *offsets,
			      unsigned long (*find_fn)(int, int),
			      void (*unlock_fn)(unsigned long),
			      void *(*alloc_fn)(size_t, unsigned long),
			      long (*copy_from_fn)(void *, unsigned long,
						   size_t))
{
	unsigned long child;
	unsigned long sendsig;
	unsigned long recvsig;
	unsigned long sendsig_offset;
	unsigned long recvsig_offset;
	int target;
	long rc;

	if (!offsets || !scratch || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	sendsig = c_ptrace_io_sendsig(child, offsets);
	recvsig = c_ptrace_io_recvsig(child, offsets);
	target = ptrace_setsiginfo_target_result(
		c_ptrace_io_status(child, offsets), sendsig != 0,
		recvsig != 0);
	rc = target;
	if (target >= 0) {
		rc = 0;
		sendsig_offset = offsets->thread_ptrace_sendsig_offset;
		recvsig_offset = offsets->thread_ptrace_recvsig_offset;
		if (target & PTRACE_SIGINFO_ALLOC_SENDSIG) {
			void *allocated;

			if (!alloc_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			allocated = alloc_fn(pending_size, alloc_flags);
			if (!allocated) {
				rc = -ENOMEM;
			}
			else {
				rc = ptrace_setsiginfo_store_result(child,
					sendsig_offset, recvsig_offset,
					info_offset,
					PTRACE_SIGINFO_ALLOC_SENDSIG,
					(unsigned long)allocated, NULL, 0);
			}
		}
		if (!rc && (target & PTRACE_SIGINFO_STORE_SENDSIG)) {
			if (!copy_from_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			if (copy_from_fn(scratch, data, info_size)) {
				rc = -EFAULT;
			}
			else {
				rc = ptrace_setsiginfo_store_result(child,
					sendsig_offset, recvsig_offset,
					info_offset,
					PTRACE_SIGINFO_STORE_SENDSIG, 0,
					scratch, info_size);
			}
		}
		if (!rc && (target & PTRACE_SIGINFO_STORE_RECVSIG)) {
			if (!copy_from_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			if (copy_from_fn(scratch, data, info_size)) {
				rc = -EFAULT;
			}
			else {
				rc = ptrace_setsiginfo_store_result(child,
					sendsig_offset, recvsig_offset,
					info_offset,
					PTRACE_SIGINFO_STORE_RECVSIG, 0,
					scratch, info_size);
			}
		}
	}
	unlock_fn(child);
	return rc;
}

int
ptrace_wakeup_sig_body_result(int pid, long request, long data,
			      unsigned long current_thread,
			      unsigned long info_offset,
			      const struct fake_ptrace_io_offsets *offsets,
			      void *lock_node,
			      unsigned long (*find_fn)(int, int),
			      void (*unlock_fn)(unsigned long),
			      void (*log_fn)(int, int, int),
			      int (*clear_saved_fn)(unsigned long,
						    unsigned long),
			      void (*set_single_step_fn)(unsigned long),
			      void (*lock_fn)(unsigned long, void *),
			      int (*trace_syscall_update_fn)(unsigned long,
							     unsigned long,
							     int),
			      void (*unlock_lock_fn)(unsigned long, void *),
			      unsigned long (*take_pending_fn)(unsigned long,
							      unsigned long,
							      unsigned long,
							      int),
			      void (*free_fn)(void *),
			      long (*do_kill_fn)(void *, int, int, int,
						 const void *, int),
			      void (*wakeup_fn)(void *, int))
{
	unsigned long child;
	int action;
	int error;

	if (log_fn)
		log_fn(PTRACE_CONTROL_LOG_WAKEUP_ENTER, pid, (int)data);
	if (!offsets || !current_thread || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(pid, pid);
	if (!child)
		return -ESRCH;
	error = ptrace_signal_data_result(data);
	if (error) {
		unlock_fn(child);
		return error;
	}

	action = ptrace_wakeup_request_action_result(request);
	if (action == PTRACE_WAKEUP_ACTION_KILL ||
	    action == PTRACE_WAKEUP_ACTION_RESUME) {
		if (!clear_saved_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		clear_saved_fn(child,
			       offsets->thread_ptrace_saved_uctx_valid_offset);
	}

	if (action == PTRACE_WAKEUP_ACTION_KILL) {
		struct fake_siginfo info;

		if (!do_kill_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		memset(&info, 0, sizeof(info));
		info.si_signo = SIGKILL;
		error = do_kill_fn((void *)current_thread, pid, -1,
				   SIGKILL, &info, 0);
		if (error < 0) {
			unlock_fn(child);
			return error;
		}
	}
	else if (action == PTRACE_WAKEUP_ACTION_RESUME) {
		unsigned long child_proc;
		unsigned long update_lock;

		if (ptrace_resume_single_step_result(request)) {
			if (!set_single_step_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			set_single_step_fn(child);
		}
		child_proc = c_ptrace_io_proc(child, offsets);
		if (!child_proc || !lock_node || !lock_fn ||
		    !trace_syscall_update_fn || !unlock_lock_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		update_lock = c_ptrace_io_proc_update_lock(child_proc,
							   offsets);
		lock_fn(update_lock, lock_node);
		trace_syscall_update_fn(child, offsets->thread_ptrace_offset,
					ptrace_resume_trace_syscall_result(
						request));
		unlock_lock_fn(update_lock, lock_node);

		if (ptrace_resume_signal_needed_result(request, data)) {
			struct fake_siginfo info;
			unsigned long pending;
			int source;

			if (!take_pending_fn || !do_kill_fn) {
				unlock_fn(child);
				return -EFAULT;
			}
			source = ptrace_resume_signal_source_result(request,
				c_ptrace_io_sendsig(child, offsets) != 0,
				c_ptrace_io_recvsig(child, offsets) != 0);
			pending = take_pending_fn(child,
				offsets->thread_ptrace_sendsig_offset,
				offsets->thread_ptrace_recvsig_offset,
				source);
			memset(&info, 0, sizeof(info));
			if (pending) {
				memcpy(&info, (void *)(pending + info_offset),
				       sizeof(info));
				if (!free_fn) {
					unlock_fn(child);
					return -EFAULT;
				}
				free_fn((void *)pending);
			}
			else {
				unsigned long current_proc =
					c_ptrace_io_proc(current_thread,
							  offsets);
				info.si_signo = (int)data;
				info.si_code = SI_USER;
				info.sifields.kill.si_pid = current_proc ?
					c_ptrace_io_proc_pid(current_proc,
							     offsets) : 0;
			}
			error = do_kill_fn((void *)current_thread, pid, -1,
					   (int)data, &info, 1);
			if (error < 0) {
				unlock_fn(child);
				return error;
			}
		}
	}

	if (!wakeup_fn) {
		unlock_fn(child);
		return -EFAULT;
	}
	wakeup_fn((void *)child, PS_TRACED | PS_STOPPED);
	unlock_fn(child);
	return error;
}

int
ptrace_setoptions_body_result(int pid, int flags,
			      const struct fake_ptrace_io_offsets *offsets,
			      unsigned long (*find_fn)(int, int),
			      void (*unlock_fn)(unsigned long),
			      void (*log_fn)(int, int, int))
{
	unsigned long child;
	unsigned long proc_addr;
	int ptrace;
	int ret = ptrace_setoptions_flags_result(flags);

	if (ret) {
		if (log_fn)
			log_fn(PTRACE_CONTROL_LOG_SETOPTIONS_UNSUPPORTED,
			       flags, ret);
		return ret;
	}
	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	proc_addr = child ? c_ptrace_io_proc(child, offsets) : 0;
	ptrace = child ? c_ptrace_io_ptrace(child, offsets) : 0;
	ret = ptrace_child_traced_result(child != 0, proc_addr != 0,
					 ptrace);
	if (ret) {
		if (child)
			unlock_fn(child);
		return ret;
	}
	ret = ptrace_setoptions_apply_thread_result(child,
		offsets->thread_ptrace_offset, flags);
	if (log_fn)
		log_fn(PTRACE_CONTROL_LOG_SETOPTIONS_APPLIED, flags, ret);
	unlock_fn(child);
	return 0;
}

int
ptrace_detach_body_result(int pid, int data, unsigned long current_proc,
			  const struct fake_ptrace_io_offsets *offsets,
			  unsigned long (*find_fn)(int, int),
			  void (*unlock_fn)(unsigned long),
			  void (*detach_fn)(unsigned long, int))
{
	unsigned long child;
	int error = ptrace_detach_signal_result(data);

	if (error)
		return error;
	if (!offsets || !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child)
		return -ESRCH;
	error = ptrace_detach_state_result(
		!!(c_ptrace_io_ptrace(child, offsets) & PT_TRACED),
		c_ptrace_io_report_proc(child, offsets) == current_proc);
	if (!error) {
		if (!detach_fn) {
			unlock_fn(child);
			return -EFAULT;
		}
		detach_fn(child, data);
	}
	unlock_fn(child);
	return error;
}

int
ptrace_attach_body_result(int pid, unsigned long current_thread,
			  unsigned long current_proc,
			  const struct fake_ptrace_io_offsets *offsets,
			  unsigned long (*find_fn)(int, int),
			  void (*unlock_fn)(unsigned long),
			  int (*attach_fn)(unsigned long, unsigned long),
			  long (*do_kill_fn)(void *, int, int, int,
					     const void *, int),
			  void (*log_fn)(int, int, int))
{
	unsigned long child;
	unsigned long child_proc;
	int tracer_pid;
	int error;

	if (!offsets || !current_thread || !current_proc ||
	    !find_fn || !unlock_fn)
		return -EFAULT;
	child = find_fn(0, pid);
	if (!child) {
		if (log_fn)
			log_fn(PTRACE_CONTROL_LOG_ATTACH_RETURN, pid,
			       -ESRCH);
		return -ESRCH;
	}
	tracer_pid = c_ptrace_io_proc_pid(current_proc, offsets);
	child_proc = c_ptrace_io_proc(child, offsets);
	error = ptrace_attach_policy_result(tracer_pid, pid,
					    c_ptrace_io_ptrace(child, offsets),
					    child_proc == current_proc);
	if (error) {
		unlock_fn(child);
		if (log_fn)
			log_fn(PTRACE_CONTROL_LOG_ATTACH_RETURN, pid, error);
		return error;
	}
	ptrace_attach_mark_traced_result(child, offsets->thread_ptrace_offset);
	if (!attach_fn) {
		unlock_fn(child);
		return -EFAULT;
	}
	attach_fn(child, current_proc);
	unlock_fn(child);
	if (!do_kill_fn)
		return -EFAULT;
	{
		struct fake_siginfo info;

		memset(&info, 0, sizeof(info));
		info.si_signo = SIGSTOP;
		info.si_code = SI_USER;
		info.sifields.kill.si_pid = tracer_pid;
		error = do_kill_fn((void *)current_thread, -1, pid,
				   SIGSTOP, &info, 2);
	}
	if (log_fn)
		log_fn(PTRACE_CONTROL_LOG_ATTACH_RETURN, pid, error);
	return error;
}

int
ptrace_report_signal_body_result(void *thread, int sig, void *current_thread,
	const struct fake_ptrace_report_signal_offsets *offsets,
	void *lock_node, void (*lock_fn)(void *, void *),
	void (*unlock_fn)(void *, void *), void (*save_debugreg_fn)(void *),
	void (*wake_fn)(void *),
	long (*do_kill_fn)(void *, int, int, int, const void *, int),
	void (*schedule_fn)(void), void (*log_fn)(int, int, int))
{
	char *thread_base = thread;
	char *proc_base;
	void *proc;
	void *parent_waitq = NULL;
	int parent_pid = 0;
	int wake_parent = 0;
	struct fake_siginfo info;

	if (!thread || !current_thread || !offsets || !lock_node ||
	    !lock_fn || !unlock_fn || !save_debugreg_fn || !wake_fn ||
	    !do_kill_fn || !schedule_fn)
		return -EINVAL;

	proc = *(void **)(thread_base + offsets->thread_proc_offset);
	if (!proc)
		return -EINVAL;
	proc_base = proc;
	if (log_fn)
		log_fn(PTRACE_REPORT_SIGNAL_LOG_ENTER,
		       *(int *)(thread_base + offsets->thread_tid_offset),
		       *(int *)(proc_base + offsets->proc_pid_offset));

	lock_fn(proc_base + offsets->proc_update_lock_offset, lock_node);
	if (!(*(int *)(thread_base + offsets->thread_ptrace_offset) &
	      PT_TRACED)) {
		unlock_fn(proc_base + offsets->proc_update_lock_offset,
			  lock_node);
		return 0;
	}

	*(int *)(thread_base + offsets->thread_exit_status_offset) = sig;
	*(int *)(thread_base + offsets->thread_status_offset) = PS_TRACED;
	*(int *)(thread_base + offsets->thread_ptrace_offset) &=
		~PT_TRACE_SYSCALL;
	save_debugreg_fn(*(void **)(thread_base +
		offsets->thread_ptrace_debugreg_offset));
	if (sig == SIGSTOP || sig == SIGTSTP ||
	    sig == SIGTTIN || sig == SIGTTOU) {
		*(int *)(thread_base + offsets->thread_signal_flags_offset) |=
			SIGNAL_STOP_STOPPED;
	}
	else {
		*(int *)(thread_base + offsets->thread_signal_flags_offset) &=
			~SIGNAL_STOP_STOPPED;
	}

	if (thread == *(void **)(proc_base + offsets->proc_main_thread_offset)) {
		char *parent_base = *(void **)(proc_base +
			offsets->proc_parent_offset);

		if (!parent_base) {
			unlock_fn(proc_base + offsets->proc_update_lock_offset,
				  lock_node);
			return -EINVAL;
		}
		*(int *)(proc_base + offsets->proc_status_offset) =
			PS_TRACED;
		wake_parent = 1;
		parent_pid = *(int *)(parent_base + offsets->proc_pid_offset);
		parent_waitq = parent_base + offsets->proc_waitpid_q_offset;
	}
	else {
		char *report_base = *(void **)(thread_base +
			offsets->thread_report_proc_offset);

		if (!report_base) {
			unlock_fn(proc_base + offsets->proc_update_lock_offset,
				  lock_node);
			return -EINVAL;
		}
		parent_pid = *(int *)(report_base + offsets->proc_pid_offset);
		wake_fn(report_base + offsets->proc_waitpid_q_offset);
	}
	unlock_fn(proc_base + offsets->proc_update_lock_offset, lock_node);

	if (wake_parent)
		wake_fn(parent_waitq);

	memset(&info, 0, sizeof(info));
	info.si_signo = SIGCHLD;
	info.si_code = CLD_TRAPPED;
	info.sifields.sigchld.si_pid =
		*(int *)(thread_base + offsets->thread_tid_offset);
	info.sifields.sigchld.si_status =
		*(int *)(thread_base + offsets->thread_exit_status_offset);
	do_kill_fn(current_thread, parent_pid, -1, SIGCHLD, &info, 0);
	if (log_fn)
		log_fn(PTRACE_REPORT_SIGNAL_LOG_SLEEPING,
		       *(int *)(thread_base + offsets->thread_tid_offset), sig);
	schedule_fn();
	if (log_fn)
		log_fn(PTRACE_REPORT_SIGNAL_LOG_WAKE,
		       *(int *)(thread_base + offsets->thread_tid_offset), sig);
	return 0;
}

long
arch_ptrace_syscall_event_body_result(void *thread, void *ctx, long setret,
				      size_t syscall_ret_offset,
				      void (*event_fn)(void *, int))
{
	unsigned long *retp;

	if (!ctx)
		return -EFAULT;
	retp = (unsigned long *)((char *)ctx + syscall_ret_offset);
	*retp = (unsigned long)setret;
	if (!event_fn)
		return -EFAULT;
	event_fn(thread, 0);
	return (long)*retp;
}
#endif

static long fake_ptrace_read_word(unsigned long thread_addr, long addr,
				  unsigned long *value)
{
	struct fake_reg_thread *thread = (struct fake_reg_thread *)thread_addr;
	unsigned long index = (unsigned long)addr / sizeof(unsigned long);

	if ((int)index == thread->fail_at)
		return -123;
	*value = thread->values[index];
	return 0;
}

static long fake_ptrace_write_word(unsigned long thread_addr, long addr,
				   unsigned long value)
{
	struct fake_reg_thread *thread = (struct fake_reg_thread *)thread_addr;
	unsigned long index = (unsigned long)addr / sizeof(unsigned long);

	if ((int)index == thread->fail_at)
		return -124;
	thread->written[index] = value;
	return 0;
}

static long fake_arch_ptrace_read_gpregs(unsigned long thread_addr, void *regs)
{
	return arch_ptrace_read_gpregs_body_result(thread_addr, regs,
		sizeof(unsigned long) * 8, fake_ptrace_read_word);
}

static long fake_arch_ptrace_write_gpregs(unsigned long thread_addr,
					  const void *regs)
{
	return arch_ptrace_write_gpregs_body_result(thread_addr, regs,
		sizeof(unsigned long) * 8, fake_ptrace_write_word);
}

static long fake_ptrace_read_vm_word(unsigned long vm_addr, unsigned long addr,
				     unsigned long *value)
{
	struct fake_vm_word *vm = (struct fake_vm_word *)vm_addr;

	vm->last_addr = addr;
	if (vm->fail)
		return -125;
	*value = vm->value;
	return 0;
}

static long fake_ptrace_write_vm_word(unsigned long vm_addr, unsigned long addr,
				      unsigned long value)
{
	struct fake_vm_word *vm = (struct fake_vm_word *)vm_addr;

	vm->last_addr = addr;
	if (vm->fail)
		return -126;
	vm->value = value;
	return 0;
}

static long fake_ptrace_fpregs_io(unsigned long thread_addr,
				  unsigned long data_addr)
{
	struct fake_fpregs_thread *thread =
		(struct fake_fpregs_thread *)thread_addr;

	thread->last_data = data_addr;
	if (thread->fail)
		return -127;
	return 0;
}

static long fake_regset_copy_from(void *dst, unsigned long src_addr,
				  size_t bytes)
{
	active_regset_thread->copy_from_calls++;
	if (active_regset_thread->copy_from_fail)
		return -128;
	memcpy(dst, (void *)src_addr, bytes);
	return 0;
}

static long fake_ptrace_regset_io(unsigned long thread_addr, long type,
				  void *iovp)
{
	struct fake_regset_thread *thread =
		(struct fake_regset_thread *)thread_addr;
	struct fake_iovec *iov = iovp;

	thread->io_calls++;
	thread->seen_base = (unsigned long)iov->iov_base;
	thread->seen_len = iov->iov_len;
	thread->seen_type = type;
	if (thread->io_fail)
		return -129;
	iov->iov_len = thread->new_len;
	return 0;
}

static long fake_regset_copy_to(unsigned long dst_addr, const void *src,
				size_t bytes)
{
	active_regset_thread->copy_to_calls++;
	if (active_regset_thread->copy_to_fail)
		return -130;
	memcpy((void *)dst_addr, src, bytes);
	return 0;
}

static long fake_arch_xstate_copy_to(unsigned long thread_addr,
				     unsigned long user_addr, size_t bytes)
{
	struct fake_regset_thread *thread =
		(struct fake_regset_thread *)thread_addr;

	thread->xstate_copy_to_calls++;
	thread->xstate_user_addr = user_addr;
	thread->xstate_bytes = bytes;
	if (thread->xstate_fail)
		return -131;
	return 0;
}

static long fake_arch_xstate_copy_from(unsigned long thread_addr,
				       unsigned long user_addr, size_t bytes)
{
	struct fake_regset_thread *thread =
		(struct fake_regset_thread *)thread_addr;

	thread->xstate_copy_from_calls++;
	thread->xstate_user_addr = user_addr;
	thread->xstate_bytes = bytes;
	if (thread->xstate_fail)
		return -132;
	return 0;
}

static void fake_arch_regset_log(int event, long type)
{
	active_regset_thread->log_calls++;
	active_regset_thread->log_event = event;
	active_regset_thread->log_type = type;
}

static void *fake_arch_lookup_user_context(void *thread_addr)
{
	struct fake_arch_ptrace_thread *thread = thread_addr;

	return thread->live_uctx;
}

static void *fake_arch_alloc(size_t size, unsigned long flags)
{
	fake_arch_alloc_calls++;
	fake_arch_alloc_size = size;
	fake_arch_alloc_flags = flags;
	return fake_arch_alloc_result;
}

static void fake_arch_user_log(int event, int value, int result)
{
	active_arch_ptrace_thread->log_event = event;
	active_arch_ptrace_thread->log_value = value;
	active_arch_ptrace_thread->log_result = result;
}

static unsigned long fake_arch_find_thread(int tgid, int tid)
{
	(void)tgid;
	if (!active_arch_ptrace_thread ||
	    active_arch_ptrace_thread->find_key != tid)
		return 0;
	return (unsigned long)active_arch_ptrace_thread;
}

static void fake_arch_thread_unlock(unsigned long thread_addr)
{
	struct fake_arch_ptrace_thread *thread =
		(struct fake_arch_ptrace_thread *)thread_addr;

	thread->unlocks++;
}

static long fake_arch_read_user(unsigned long thread_addr, long addr,
				unsigned long *value)
{
	return arch_ptrace_read_user_body_result((void *)thread_addr, addr,
		value, sizeof(unsigned long), 64, 16, 128, 128 + 64,
		active_arch_ptrace_offsets, fake_arch_lookup_user_context,
		fake_arch_user_log);
}

static long fake_arch_write_user(unsigned long thread_addr, long addr,
				 unsigned long value)
{
	return arch_ptrace_write_user_body_result((void *)thread_addr, addr,
		value, sizeof(unsigned long), 64, 16, 48, 128, 128 + 64,
		active_arch_ptrace_offsets, fake_arch_lookup_user_context,
		fake_arch_user_log);
}

static unsigned long fake_ptrace_find_thread(int tgid, int tid)
{
	(void)tgid;
	if (!active_ptrace_io_thread ||
	    active_ptrace_io_thread->find_key != tid)
		return 0;
	return (unsigned long)active_ptrace_io_thread;
}

static void fake_ptrace_thread_unlock(unsigned long thread_addr)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;

	thread->unlocks++;
}

static long fake_ptrace_io_read_word(unsigned long thread_addr, long addr,
				     unsigned long *value)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;
	unsigned long index = (unsigned long)addr / sizeof(unsigned long);

	if ((int)index == thread->fail_at)
		return -133;
	*value = thread->values[index];
	return 0;
}

static long fake_ptrace_io_write_word(unsigned long thread_addr, long addr,
				      unsigned long value)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;
	unsigned long index = (unsigned long)addr / sizeof(unsigned long);

	if ((int)index == thread->fail_at)
		return -134;
	thread->written[index] = value;
	return 0;
}

static long fake_ptrace_io_fpregs(unsigned long thread_addr,
				  unsigned long data_addr)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;

	thread->last_data = data_addr;
	return thread->fpregs_fail ? -135 : 0;
}

static long fake_ptrace_io_regset(unsigned long thread_addr, long type,
				  void *iovp)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;
	struct fake_iovec *iov = iovp;
	struct fake_regset_thread *regset = &thread->regset;

	regset->io_calls++;
	regset->seen_base = (unsigned long)iov->iov_base;
	regset->seen_len = iov->iov_len;
	regset->seen_type = type;
	if (regset->io_fail)
		return -136;
	iov->iov_len = regset->new_len;
	return 0;
}

static void fake_ptrace_text_log(int event, unsigned long addr)
{
	active_ptrace_io_thread->log_event = event;
	active_ptrace_io_thread->log_addr = addr;
}

static void fake_ptrace_control_log(int event, int value, int result)
{
	active_ptrace_io_thread->log_event = event;
	active_ptrace_io_thread->log_value = value;
	active_ptrace_io_thread->log_result = result;
}

static void *fake_ptrace_alloc(size_t size, unsigned long flags)
{
	fake_ptrace_alloc_calls++;
	fake_ptrace_alloc_size = size;
	fake_ptrace_alloc_flags = flags;
	return fake_ptrace_alloc_result;
}

static int fake_ptrace_attach_thread(unsigned long thread_addr,
				     unsigned long proc_addr)
{
	fake_ptrace_attach_calls++;
	fake_ptrace_attach_thread_addr = thread_addr;
	fake_ptrace_attach_proc_addr = proc_addr;
	return fake_ptrace_attach_rc;
}

static void fake_ptrace_detach_call(unsigned long thread_addr, int data)
{
	fake_ptrace_detach_calls++;
	fake_ptrace_detach_thread_addr = thread_addr;
	fake_ptrace_detach_data = data;
}

static long fake_ptrace_control_do_kill(void *current_thread, int pid, int tid,
					int sig, const void *info,
					int ptracecont)
{
	const struct fake_siginfo *sinfo = info;

	fake_ptrace_kill_calls++;
	fake_ptrace_kill_current = current_thread;
	fake_ptrace_kill_pid = pid;
	fake_ptrace_kill_tid = tid;
	fake_ptrace_kill_sig = sig;
	fake_ptrace_kill_ptracecont = ptracecont;
	if (sinfo) {
		fake_ptrace_kill_si_signo = sinfo->si_signo;
		fake_ptrace_kill_si_code = sinfo->si_code;
		fake_ptrace_kill_si_pid = sinfo->sifields.kill.si_pid;
		fake_ptrace_kill_si_status = sinfo->sifields.sigchld.si_status;
	}
	return fake_ptrace_kill_rc;
}

static int fake_ptrace_clear_saved(unsigned long thread_addr,
				   unsigned long offset)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;

	*(int *)((char *)thread + offset) = 0;
	return 0;
}

static void fake_ptrace_set_single_step(unsigned long thread_addr)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;

	thread->single_steps++;
}

static void fake_ptrace_update_lock(unsigned long lock_addr, void *node)
{
	fake_ptrace_lock_calls++;
	fake_ptrace_lock_addr = lock_addr;
	fake_ptrace_lock_node = node;
}

static int fake_ptrace_trace_syscall_update(unsigned long thread_addr,
					    unsigned long ptrace_offset,
					    int trace_syscall)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;
	int *ptrace = (int *)((char *)thread + ptrace_offset);

	thread->trace_updates++;
	if (trace_syscall)
		*ptrace |= PT_TRACE_SYSCALL;
	else
		*ptrace &= ~PT_TRACE_SYSCALL;
	return *ptrace;
}

static void fake_ptrace_update_unlock(unsigned long lock_addr, void *node)
{
	(void)lock_addr;
	(void)node;
	fake_ptrace_unlock_calls++;
}

static unsigned long fake_ptrace_pending_take(unsigned long thread_addr,
					      unsigned long sendsig_offset,
					      unsigned long recvsig_offset,
					      int source)
{
	struct fake_ptrace_io_thread *thread =
		(struct fake_ptrace_io_thread *)thread_addr;
	void **sendsig = (void **)((char *)thread + sendsig_offset);
	void **recvsig = (void **)((char *)thread + recvsig_offset);
	void *pending = NULL;

	if (source == PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG) {
		pending = *sendsig;
		*sendsig = NULL;
	}
	else if (source == PTRACE_RESUME_SIGNAL_SOURCE_RECVSIG) {
		pending = *recvsig;
		*recvsig = NULL;
	}
	return (unsigned long)pending;
}

static void fake_ptrace_free_pending(void *ptr)
{
	fake_ptrace_free_calls++;
	fake_ptrace_freed_ptr = ptr;
}

static void fake_ptrace_wakeup_thread(void *thread_addr, int valid_states)
{
	struct fake_ptrace_io_thread *thread = thread_addr;

	thread->wake_calls++;
	thread->wake_states = valid_states;
}

static void fake_ptrace_waitq_wake(void *waitq)
{
	fake_ptrace_waitq_wake_calls++;
	fake_ptrace_waitq_wake_addr = waitq;
}

static void fake_ptrace_preempt_enable(void)
{
	fake_ptrace_preempt_enable_calls++;
}

static void fake_ptrace_preempt_disable(void)
{
	fake_ptrace_preempt_disable_calls++;
}

static void fake_ptrace_report_signal(void *thread, int sig)
{
	struct fake_ptrace_io_thread *t = thread;

	fake_ptrace_report_signal_calls++;
	fake_ptrace_report_signal_sig = sig;
	t->kernel_ctx[0] ^= 0x5a;
	t->ptrace |= PT_TRACE_SYSCALL;
}

static long fake_ptrace_arch_syscall_event(void *thread, void *ctx,
					   long setret)
{
	fake_ptrace_arch_event_calls++;
	fake_ptrace_arch_event_thread = thread;
	fake_ptrace_arch_event_ctx = ctx;
	fake_ptrace_arch_event_setret = setret;
	return 0x7654;
}

static void fake_ptrace_signal_lock(void *lock, void *node)
{
	fake_ptrace_lock_calls++;
	fake_ptrace_lock_addr = (unsigned long)lock;
	fake_ptrace_lock_node = node;
}

static void fake_ptrace_signal_unlock(void *lock, void *node)
{
	(void)lock;
	(void)node;
	fake_ptrace_unlock_calls++;
}

static void fake_ptrace_save_debugreg(void *debugreg)
{
	fake_ptrace_save_debugreg_calls++;
	fake_ptrace_saved_debugreg = debugreg;
}

static void fake_ptrace_schedule(void)
{
	fake_ptrace_schedule_calls++;
}

static void fake_arch_ptrace_syscall_event_cb(void *thread, int unused)
{
	struct fake_ptrace_io_thread *t = thread;

	(void)unused;
	fake_ptrace_arch_event_calls++;
	t->eventmsg++;
}

static int fake_ptrace_syscall_calls;
static int fake_ptrace_syscall_last_op;
static int fake_ptrace_syscall_last_pid;
static long fake_ptrace_syscall_last_request;
static long fake_ptrace_syscall_last_addr;
static long fake_ptrace_syscall_last_data;

static void fake_ptrace_syscall_reset(void)
{
	fake_ptrace_syscall_calls = 0;
	fake_ptrace_syscall_last_op = -1;
	fake_ptrace_syscall_last_pid = -1;
	fake_ptrace_syscall_last_request = -1;
	fake_ptrace_syscall_last_addr = -1;
	fake_ptrace_syscall_last_data = -1;
}

static long fake_ptrace_syscall_return(int op)
{
	return 0x5000 + op;
}

static void fake_ptrace_syscall_record(int op, int pid, long request,
				       long addr, long data)
{
	fake_ptrace_syscall_calls++;
	fake_ptrace_syscall_last_op = op;
	fake_ptrace_syscall_last_pid = pid;
	fake_ptrace_syscall_last_request = request;
	fake_ptrace_syscall_last_addr = addr;
	fake_ptrace_syscall_last_data = data;
}

static int fake_ptrace_traceme_cb(void)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_TRACEME, -1, 0, 0, 0);
	return (int)fake_ptrace_syscall_return(PTRACE_DISPATCH_TRACEME);
}

static int fake_ptrace_wakeup_cb(int pid, long request, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_WAKEUP, pid, request, 0,
				   data);
	return (int)fake_ptrace_syscall_return(PTRACE_DISPATCH_WAKEUP);
}

static long fake_ptrace_getregs_cb(int pid, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_GETREGS, pid, 0, 0, data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_GETREGS);
}

static long fake_ptrace_setregs_cb(int pid, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_SETREGS, pid, 0, 0, data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_SETREGS);
}

static long fake_ptrace_getfpregs_cb(int pid, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_GETFPREGS, pid, 0, 0,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_GETFPREGS);
}

static long fake_ptrace_setfpregs_cb(int pid, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_SETFPREGS, pid, 0, 0,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_SETFPREGS);
}

static long fake_ptrace_peekuser_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_PEEKUSER, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_PEEKUSER);
}

static long fake_ptrace_pokeuser_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_POKEUSER, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_POKEUSER);
}

static long fake_ptrace_peektext_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_PEEKTEXT, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_PEEKTEXT);
}

static long fake_ptrace_poketext_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_POKETEXT, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_POKETEXT);
}

static int fake_ptrace_setoptions_cb(int pid, int flags)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_SETOPTIONS, pid, 0, 0,
				   flags);
	return (int)fake_ptrace_syscall_return(PTRACE_DISPATCH_SETOPTIONS);
}

static int fake_ptrace_attach_cb(int pid)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_ATTACH, pid, 0, 0, 0);
	return (int)fake_ptrace_syscall_return(PTRACE_DISPATCH_ATTACH);
}

static int fake_ptrace_detach_cb(int pid, int data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_DETACH, pid, 0, 0, data);
	return (int)fake_ptrace_syscall_return(PTRACE_DISPATCH_DETACH);
}

static long fake_ptrace_getsiginfo_cb(int pid, void *data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_GETSIGINFO, pid, 0, 0,
				   (long)data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_GETSIGINFO);
}

static long fake_ptrace_setsiginfo_cb(int pid, void *data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_SETSIGINFO, pid, 0, 0,
				   (long)data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_SETSIGINFO);
}

static long fake_ptrace_getregset_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_GETREGSET, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_GETREGSET);
}

static long fake_ptrace_setregset_cb(int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_SETREGSET, pid, 0, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_SETREGSET);
}

static long fake_ptrace_geteventmsg_cb(int pid, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_GETEVENTMSG, pid, 0, 0,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_GETEVENTMSG);
}

static long fake_ptrace_arch_cb(long request, int pid, long addr, long data)
{
	fake_ptrace_syscall_record(PTRACE_DISPATCH_ARCH, pid, request, addr,
				   data);
	return fake_ptrace_syscall_return(PTRACE_DISPATCH_ARCH);
}

static const struct fake_ptrace_syscall_ops fake_ptrace_syscall_ops_full = {
	.traceme_fn = fake_ptrace_traceme_cb,
	.wakeup_fn = fake_ptrace_wakeup_cb,
	.getregs_fn = fake_ptrace_getregs_cb,
	.setregs_fn = fake_ptrace_setregs_cb,
	.getfpregs_fn = fake_ptrace_getfpregs_cb,
	.setfpregs_fn = fake_ptrace_setfpregs_cb,
	.peekuser_fn = fake_ptrace_peekuser_cb,
	.pokeuser_fn = fake_ptrace_pokeuser_cb,
	.peektext_fn = fake_ptrace_peektext_cb,
	.poketext_fn = fake_ptrace_poketext_cb,
	.setoptions_fn = fake_ptrace_setoptions_cb,
	.attach_fn = fake_ptrace_attach_cb,
	.detach_fn = fake_ptrace_detach_cb,
	.getsiginfo_fn = fake_ptrace_getsiginfo_cb,
	.setsiginfo_fn = fake_ptrace_setsiginfo_cb,
	.getregset_fn = fake_ptrace_getregset_cb,
	.setregset_fn = fake_ptrace_setregset_cb,
	.geteventmsg_fn = fake_ptrace_geteventmsg_cb,
	.arch_fn = fake_ptrace_arch_cb,
};

struct range_case {
	uintptr_t start;
	size_t len;
	uintptr_t user_start;
	uintptr_t user_end;
};

static void exercise_memlock(unsigned long *digest)
{
	static const struct range_case cases[] = {
		{ 0x10000UL, 0, 0x10000UL, 0x20000UL },
		{ 0x10001UL, 1, 0x10000UL, 0x20000UL },
		{ 0x0UL, 4096, 0x10000UL, 0x20000UL },
		{ 0x1f000UL, 0x2000, 0x10000UL, 0x20000UL },
		{ ULONG_MAX - 0xfffUL, 0x3000, 0x10000UL, 0x20000UL },
	};

	for (unsigned int i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
		uintptr_t start = 0xa5a5;
		uintptr_t end = 0x5a5a;
		size_t len = 0xcccc;
		int rc = memlock_prepare_range(cases[i].start, cases[i].len,
			cases[i].user_start, cases[i].user_end,
			&start, &len, &end);

		mix_signed(digest, rc);
		mix(digest, start);
		mix(digest, len);
		mix(digest, end);
	}
	{
		int fake_vm;
		int fake_lock;
		struct fake_msync_range ranges[2];
		int rc;

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = 0,
			.memobj = NULL,
		};
		fake_memlock_reset(ranges, 1);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x0UL, PAGE_SIZE,
			0x10000UL, 0x20000UL, MEMLOCK_OP_LOCK, 3,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == -12);
		require(fake_memlock_lock_calls == 0);
		require(fake_memlock_lookup_calls == 0);
		require(fake_memlock_populate_calls == 0);
		mix(digest, fake_memlock_digest);
		mix_signed(digest, rc);

		fake_memlock_reset(ranges, 1);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x2000UL, 0x10000UL, 0x20000UL, MEMLOCK_OP_LOCK, 4,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == 0);
		require(ranges[0].flag & VR_LOCKED);
		require(fake_memlock_lock_calls == 1);
		require(fake_memlock_unlock_calls == 1);
		require(fake_memlock_lookup_calls == 1);
		require(fake_memlock_split_calls == 0);
		require(fake_memlock_join_calls == 0);
		require(fake_memlock_populate_calls == 1);
		require(fake_memlock_populate_start == 0x10000UL);
		require(fake_memlock_populate_len == 0x2000UL);
		mix(digest, fake_memlock_digest);
		mix(digest, ranges[0].flag);

		fake_memlock_reset(ranges, 1);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x2000UL, 0x10000UL, 0x20000UL, MEMLOCK_OP_UNLOCK, 5,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == 0);
		require(!(ranges[0].flag & VR_LOCKED));
		require(fake_memlock_populate_calls == 0);
		mix(digest, fake_memlock_digest);
		mix(digest, ranges[0].flag);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x13000UL,
			.flag = 0,
			.memobj = NULL,
		};
		fake_memlock_reset(ranges, 1);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x1800UL, 0x10000UL, 0x20000UL, MEMLOCK_OP_LOCK, 6,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == 0);
		require(fake_memlock_split_calls == 1);
		require(ranges[0].end == 0x12000UL);
		require(ranges[0].flag & VR_LOCKED);
		mix(digest, fake_memlock_digest);
		mix(digest, ranges[0].end);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x11000UL,
			.flag = 0,
			.memobj = NULL,
		};
		ranges[1] = (struct fake_msync_range) {
			.start = 0x11000UL,
			.end = 0x12000UL,
			.flag = 0,
			.memobj = NULL,
		};
		fake_memlock_reset(ranges, 2);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x2000UL, 0x10000UL, 0x20000UL, MEMLOCK_OP_LOCK, 7,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == 0);
		require(fake_memlock_join_calls == 1);
		require(ranges[0].end == 0x12000UL);
		require(ranges[0].flag & VR_LOCKED);
		require(ranges[1].flag & VR_LOCKED);
		mix(digest, fake_memlock_digest);
		mix(digest, ranges[0].end);

		ranges[0].flag = VR_REMOTE;
		fake_memlock_reset(ranges, 1);
		rc = memlock_body_result(&fake_vm, &fake_lock, 0x10000UL,
			PAGE_SIZE, 0x10000UL, 0x20000UL, MEMLOCK_OP_LOCK, 8,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_memlock_lock, fake_memlock_unlock,
			fake_memlock_lookup, fake_memlock_next,
			fake_memlock_split, fake_memlock_join,
			fake_memlock_populate, fake_memlock_log);
		require(rc == -22);
		require(fake_memlock_split_calls == 0);
		require(fake_memlock_populate_calls == 0);
		mix(digest, fake_memlock_digest);
		mix_signed(digest, rc);
	}
}

static void exercise_unmap_protect(unsigned long *digest)
{
	static const struct range_case cases[] = {
		{ 0x10000UL, 0, 0x10000UL, 0x20000UL },
		{ 0x10000UL, 4096, 0x10000UL, 0x20000UL },
		{ 0x10001UL, 4096, 0x10000UL, 0x20000UL },
		{ 0x1f000UL, 4096, 0x10000UL, 0x20000UL },
		{ 0x20000UL, 4096, 0x10000UL, 0x20000UL },
		{ 0x10000UL, 0x10001, 0x10000UL, 0x20000UL },
		{ ULONG_MAX - 0xfffUL, 0x3000, 0x10000UL, 0x20000UL },
	};

	for (unsigned int i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
		size_t len = 0xdddd;
		uintptr_t end = 0xbeef;

		mix_signed(digest, munmap_prepare_range(cases[i].start,
			cases[i].len, cases[i].user_start, cases[i].user_end,
			&len));
		mix(digest, len);

		len = 0xeeee;
		mix_signed(digest, mprotect_prepare_range(cases[i].start,
			cases[i].len, cases[i].user_start, cases[i].user_end,
			&len, &end));
		mix(digest, len);
		mix(digest, end);
		for (unsigned int r = 0; r < sizeof(cases) / sizeof(cases[0]); r++) {
			int split_start = -7;
			int split_end = -9;

			mprotect_split_needed_result(cases[r].start,
				cases[r].user_end, cases[i].start, end,
				&split_start, &split_end);
			mix_signed(digest, split_start);
			mix_signed(digest, split_end);
		}
	}
	{
		int fake_vm;
		int fake_lock;
		struct fake_msync_range ranges[2];
		int rc;

		fake_munmap_reset(0);
		rc = munmap_body_result(&fake_vm, &fake_lock, 0x10001UL,
			PAGE_SIZE, 0x10000UL, 0x20000UL, 11,
			fake_munmap_lock, fake_munmap_unlock,
			fake_munmap_do, fake_munmap_log);
		require(rc == -22);
		require(fake_munmap_lock_calls == 0);
		require(fake_munmap_unlock_calls == 0);
		require(fake_munmap_do_calls == 0);
		require(fake_munmap_log_calls == 2);
		mix(digest, fake_munmap_digest);
		mix_signed(digest, rc);

		fake_munmap_reset(0);
		rc = munmap_body_result(&fake_vm, &fake_lock, 0x12000UL,
			0x1001UL, 0x10000UL, 0x20000UL, 12,
			fake_munmap_lock, fake_munmap_unlock,
			fake_munmap_do, fake_munmap_log);
		require(rc == 0);
		require(fake_munmap_lock_calls == 1);
		require(fake_munmap_unlock_calls == 1);
		require(fake_munmap_do_calls == 1);
		require(fake_munmap_do_addr == 0x12000UL);
		require(fake_munmap_do_len == 0x2000UL);
		require(fake_munmap_do_holding == 1);
		require(fake_munmap_log_calls == 2);
		mix(digest, fake_munmap_digest);
		mix(digest, fake_munmap_do_len);

		fake_munmap_reset(-14);
		rc = munmap_body_result(&fake_vm, &fake_lock, 0x13000UL,
			PAGE_SIZE, 0x10000UL, 0x20000UL, 13,
			fake_munmap_lock, fake_munmap_unlock,
			fake_munmap_do, fake_munmap_log);
		require(rc == -14);
		require(fake_munmap_lock_calls == 1);
		require(fake_munmap_unlock_calls == 1);
		require(fake_munmap_do_calls == 1);
		require(fake_munmap_do_addr == 0x13000UL);
		require(fake_munmap_do_len == PAGE_SIZE);
		require(fake_munmap_do_holding == 1);
		require(fake_munmap_log_calls == 2);
		mix(digest, fake_munmap_digest);
		mix_signed(digest, rc);

		{
			struct fake_do_munmap_proc proc = {
				.straight_va = 0,
				.straight_len = 0,
			};

			fake_do_munmap_reset(0, 0);
			rc = do_munmap_body_result(&fake_vm, &proc, 0x14000UL,
				PAGE_SIZE, 1,
				offsetof(struct fake_do_munmap_proc,
					 straight_va),
				offsetof(struct fake_do_munmap_proc,
					 straight_len),
				fake_do_munmap_begin, fake_do_munmap_remove,
				fake_do_munmap_clear, fake_do_munmap_sethost,
				fake_do_munmap_finish, fake_do_munmap_log);
			require(rc == 0);
			require(fake_do_munmap_begin_calls == 1);
			require(fake_do_munmap_finish_calls == 1);
			require(fake_do_munmap_remove_calls == 1);
			require(fake_do_munmap_clear_calls == 1);
			require(fake_do_munmap_sethost_calls == 0);
			require(fake_do_munmap_remove_start == 0x14000UL);
			require(fake_do_munmap_remove_end == 0x15000UL);
			require(fake_do_munmap_clear_holding == 1);
			mix(digest, fake_do_munmap_digest);
			mix_signed(digest, rc);

			fake_do_munmap_reset(0, 1);
			rc = do_munmap_body_result(&fake_vm, &proc, 0x15000UL,
				0x2000UL, 0,
				offsetof(struct fake_do_munmap_proc,
					 straight_va),
				offsetof(struct fake_do_munmap_proc,
					 straight_len),
				fake_do_munmap_begin, fake_do_munmap_remove,
				fake_do_munmap_clear, fake_do_munmap_sethost,
				fake_do_munmap_finish, fake_do_munmap_log);
			require(rc == 0);
			require(fake_do_munmap_clear_calls == 0);
			require(fake_do_munmap_sethost_calls == 1);
			require(fake_do_munmap_sethost_addr == 0x15000UL);
			require(fake_do_munmap_sethost_len == 0x2000UL);
			require(fake_do_munmap_sethost_prot ==
				(PROT_READ | PROT_WRITE | PROT_EXEC));
			require(fake_do_munmap_sethost_holding == 0);
			mix(digest, fake_do_munmap_digest);
			mix_signed(digest, rc);

			fake_do_munmap_reset(0, 1);
			fake_do_munmap_sethost_rc = -5;
			rc = do_munmap_body_result(&fake_vm, &proc, 0x16000UL,
				PAGE_SIZE, 1,
				offsetof(struct fake_do_munmap_proc,
					 straight_va),
				offsetof(struct fake_do_munmap_proc,
					 straight_len),
				fake_do_munmap_begin, fake_do_munmap_remove,
				fake_do_munmap_clear, fake_do_munmap_sethost,
				fake_do_munmap_finish, fake_do_munmap_log);
			require(rc == -5);
			require(fake_do_munmap_clear_calls == 0);
			require(fake_do_munmap_sethost_calls == 1);
			mix(digest, fake_do_munmap_digest);
			mix_signed(digest, rc);

			fake_do_munmap_reset(-12, 0);
			rc = do_munmap_body_result(&fake_vm, &proc, 0x17000UL,
				PAGE_SIZE, 1,
				offsetof(struct fake_do_munmap_proc,
					 straight_va),
				offsetof(struct fake_do_munmap_proc,
					 straight_len),
				fake_do_munmap_begin, fake_do_munmap_remove,
				fake_do_munmap_clear, fake_do_munmap_sethost,
				fake_do_munmap_finish, fake_do_munmap_log);
			require(rc == -12);
			require(fake_do_munmap_clear_calls == 1);
			require(fake_do_munmap_sethost_calls == 0);
			mix(digest, fake_do_munmap_digest);
			mix_signed(digest, rc);

			proc.straight_va = 0x18000UL;
			proc.straight_len = 0x4000UL;
			fake_do_munmap_reset(0, 0);
			rc = do_munmap_body_result(&fake_vm, &proc, 0x19000UL,
				PAGE_SIZE, 1,
				offsetof(struct fake_do_munmap_proc,
					 straight_va),
				offsetof(struct fake_do_munmap_proc,
					 straight_len),
				fake_do_munmap_begin, fake_do_munmap_remove,
				fake_do_munmap_clear, fake_do_munmap_sethost,
				fake_do_munmap_finish, fake_do_munmap_log);
			require(rc == 0);
			require(fake_do_munmap_clear_calls == 0);
			require(fake_do_munmap_sethost_calls == 0);
			require(fake_do_munmap_finish_calls == 1);
			mix(digest, fake_do_munmap_digest);
			mix_signed(digest, rc);
		}

		{
			struct fake_clear_host_vm vm = {
				.is_memory_range_lock_taken = -1,
			};
			long lrc;

			fake_clear_host_reset(0);
			lrc = clear_host_pte_body_result(&vm, 0x1a000UL,
				0x2000UL, 1,
				offsetof(struct fake_clear_host_vm,
					 is_memory_range_lock_taken),
				6, 11, fake_clear_host_forward,
				fake_clear_host_log);
			require(lrc == 0);
			require(vm.is_memory_range_lock_taken == -1);
			require(fake_clear_host_forward_calls == 1);
			require(fake_clear_host_forward_nr == 11);
			require(fake_clear_host_forward_arg0 == 0x1a000UL);
			require(fake_clear_host_forward_arg1 == 0x2000UL);
			require(fake_clear_host_forward_arg2 == 0);
			require(fake_clear_host_log_calls == 0);
			mix(digest, fake_clear_host_digest);
			mix_signed(digest, vm.is_memory_range_lock_taken);

			vm.is_memory_range_lock_taken = 77;
			fake_clear_host_reset(-44);
			lrc = clear_host_pte_body_result(&vm, 0x1b000UL,
				PAGE_SIZE, 0,
				offsetof(struct fake_clear_host_vm,
					 is_memory_range_lock_taken),
				7, 12, fake_clear_host_forward,
				fake_clear_host_log);
			require(lrc == -44);
			require(vm.is_memory_range_lock_taken == 77);
			require(fake_clear_host_forward_calls == 1);
			require(fake_clear_host_forward_nr == 12);
			require(fake_clear_host_log_calls == 1);
			require(fake_clear_host_log_error == -44);
			mix(digest, fake_clear_host_digest);
			mix_signed(digest, lrc);
		}

		{
			struct fake_vm_regions region = {
				.map_start = 0x70000UL,
				.map_end = 0x90000UL,
				.user_end = 0xa0000UL,
			};
			struct fake_msync_range all_ranges[2] = {
				{
					.start = 0x20000UL,
					.end = 0x22000UL,
					.flag = 0,
					.memobj = NULL,
				},
				{
					.start = 0x30000UL,
					.end = 0x31000UL,
					.flag = 0,
					.memobj = NULL,
				},
			};

			fake_munmap_all_reset(all_ranges, 2);
			fake_munmap_all_do_fail_index = 2;
			munmap_all_body_result(&fake_vm, &fake_lock, &region,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_vm_regions, map_start),
				offsetof(struct fake_vm_regions, map_end),
				fake_munmap_all_lock,
				fake_munmap_all_unlock,
				fake_munmap_all_lookup,
				fake_munmap_all_next, fake_munmap_all_do,
				fake_munmap_all_free, fake_munmap_all_log);
			require(fake_munmap_all_lock_calls == 1);
			require(fake_munmap_all_unlock_calls == 1);
			require(fake_munmap_all_lookup_calls == 1);
			require(fake_munmap_all_next_calls == 2);
			require(fake_munmap_all_do_calls == 2);
			require(fake_munmap_all_log_calls == 1);
			require(fake_munmap_all_free_calls == 1);
			require(region.map_end == region.map_start);
			require(fake_munmap_all_last_addr == 0x30000UL);
			require(fake_munmap_all_last_size == 0x1000UL);
			mix(digest, fake_munmap_all_digest);
			mix(digest, region.map_end);

			region.map_start = 0x71000UL;
			region.map_end = 0x93000UL;
			fake_munmap_all_reset(all_ranges, 0);
			munmap_all_body_result(&fake_vm, &fake_lock, &region,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_vm_regions, map_start),
				offsetof(struct fake_vm_regions, map_end),
				fake_munmap_all_lock,
				fake_munmap_all_unlock,
				fake_munmap_all_lookup,
				fake_munmap_all_next, fake_munmap_all_do,
				fake_munmap_all_free, fake_munmap_all_log);
			require(fake_munmap_all_do_calls == 0);
			require(fake_munmap_all_free_calls == 1);
			require(fake_munmap_all_log_calls == 0);
			require(region.map_end == 0x71000UL);
			mix(digest, fake_munmap_all_digest);
			mix(digest, region.map_end);
		}

		mix_signed(digest, set_host_vma_body_result(0x14000UL,
			PAGE_SIZE, PROT_READ, 1));
		mix_signed(digest, set_host_vma_body_result(0x15000UL,
			0x2000UL, PROT_READ | PROT_WRITE | PROT_EXEC, 0));

		{
			struct fake_shmdt_memobj good_obj = {
				.ops = NULL,
				.flags = MF_SHMDT_OK,
			};
			struct fake_shmdt_memobj bad_obj = {
				.ops = NULL,
				.flags = 0,
			};

			fake_shmdt_reset(ranges, 0, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x14000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == -22);
			require(fake_shmdt_lock_calls == 1);
			require(fake_shmdt_unlock_calls == 1);
			require(fake_shmdt_lookup_calls == 1);
			require(fake_shmdt_munmap_calls == 0);
			require(fake_shmdt_log_calls == 2);
			mix(digest, fake_shmdt_digest);
			mix_signed(digest, rc);

			ranges[0] = (struct fake_msync_range) {
				.start = 0x14000UL,
				.end = 0x16000UL,
				.flag = 0,
				.memobj = &good_obj,
			};
			fake_shmdt_reset(ranges, 1, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == -22);
			require(fake_shmdt_munmap_calls == 0);
			mix(digest, fake_shmdt_digest);

			ranges[0].start = 0x15000UL;
			ranges[0].memobj = NULL;
			fake_shmdt_reset(ranges, 1, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == -22);
			require(fake_shmdt_munmap_calls == 0);
			mix(digest, fake_shmdt_digest);

			ranges[0].memobj = &bad_obj;
			fake_shmdt_reset(ranges, 1, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == -22);
			require(fake_shmdt_munmap_calls == 0);
			mix(digest, fake_shmdt_digest);

			ranges[0].memobj = &good_obj;
			fake_shmdt_reset(ranges, 1, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == 0);
			require(fake_shmdt_munmap_calls == 1);
			require(fake_shmdt_munmap_addr == 0x15000UL);
			require(fake_shmdt_munmap_len == 0x1000UL);
			require(fake_shmdt_munmap_holding == 1);
			require(fake_shmdt_log_calls == 2);
			mix(digest, fake_shmdt_digest);
			mix(digest, fake_shmdt_munmap_len);

			fake_shmdt_reset(ranges, 1, -16);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup,
				fake_shmdt_munmap, fake_shmdt_log);
			require(rc == -16);
			require(fake_shmdt_munmap_calls == 1);
			require(fake_shmdt_unlock_calls == 1);
			mix(digest, fake_shmdt_digest);
			mix_signed(digest, rc);

			fake_shmdt_reset(ranges, 1, 0);
			rc = shmdt_body_result(&fake_vm, &fake_lock, 0x15000UL,
				offsetof(struct fake_msync_range, start),
				offsetof(struct fake_msync_range, end),
				offsetof(struct fake_msync_range, memobj),
				offsetof(struct fake_shmdt_memobj, flags),
				MF_SHMDT_OK, fake_shmdt_lock,
				fake_shmdt_unlock, fake_shmdt_lookup, NULL,
				fake_shmdt_log);
			require(rc == -22);
			require(fake_shmdt_munmap_calls == 0);
			require(fake_shmdt_unlock_calls == 1);
			mix(digest, fake_shmdt_digest);
			mix_signed(digest, rc);
		}

		{
			struct fake_vm_regions region = {
				.map_end = 0x10000UL,
				.user_end = 0x20000UL,
			};
			struct fake_msync_range search_ranges[1];
			unsigned long addr;

			addr = 0x18000UL;
			fake_search_free_reset(search_ranges, 0);
			rc = search_free_space_body_result(&fake_vm, &region,
				PAGE_SIZE, 12, &addr,
				offsetof(struct fake_vm_regions, user_end),
				offsetof(struct fake_vm_regions, map_end),
				offsetof(struct fake_msync_range, end),
				fake_search_free_lookup, fake_search_free_log);
			require(rc == 0);
			require(addr == 0x18000UL);
			require(region.map_end == 0x10000UL);
			require(fake_search_free_lookup_calls == 1);
			mix(digest, fake_search_free_digest);
			mix(digest, region.map_end);

			addr = 0x1f000UL;
			fake_search_free_reset(search_ranges, 0);
			rc = search_free_space_body_result(&fake_vm, &region,
				0x2000UL, 12, &addr,
				offsetof(struct fake_vm_regions, user_end),
				offsetof(struct fake_vm_regions, map_end),
				offsetof(struct fake_msync_range, end),
				fake_search_free_lookup, fake_search_free_log);
			require(rc == -12);
			require(addr == 0x1f000UL);
			require(fake_search_free_lookup_calls == 0);
			mix(digest, fake_search_free_digest);
			mix_signed(digest, rc);

			addr = 0;
			region.map_end = 0x10003UL;
			fake_search_free_reset(search_ranges, 0);
			rc = search_free_space_body_result(&fake_vm, &region,
				PAGE_SIZE, 12, &addr,
				offsetof(struct fake_vm_regions, user_end),
				offsetof(struct fake_vm_regions, map_end),
				offsetof(struct fake_msync_range, end),
				fake_search_free_lookup, fake_search_free_log);
			require(rc == 0);
			require(addr == 0x11000UL);
			require(region.map_end == 0x12000UL);
			require(fake_search_free_lookup_calls == 1);
			mix(digest, fake_search_free_digest);
			mix(digest, region.map_end);

			search_ranges[0] = (struct fake_msync_range) {
				.start = 0x11000UL,
				.end = 0x13000UL,
				.flag = 0,
				.memobj = NULL,
			};
			addr = 0;
			region.map_end = 0x11000UL;
			fake_search_free_reset(search_ranges, 1);
			rc = search_free_space_body_result(&fake_vm, &region,
				PAGE_SIZE, 12, &addr,
				offsetof(struct fake_vm_regions, user_end),
				offsetof(struct fake_vm_regions, map_end),
				offsetof(struct fake_msync_range, end),
				fake_search_free_lookup, fake_search_free_log);
			require(rc == 0);
			require(addr == 0x13000UL);
			require(region.map_end == 0x14000UL);
			require(fake_search_free_lookup_calls == 2);
			mix(digest, fake_search_free_digest);
			mix(digest, region.map_end);
		}

		{
			struct fake_shmat_obj obj = {
				.memobj = 7,
				.pgshift = 12,
				.real_segsz = 0x3000UL,
				.uid = 10,
				.cuid = 20,
				.gid = 30,
				.cgid = 40,
				.mode = 0666,
			};
			unsigned long write_vrflags = VR_DEMAND_PAGING |
				PROT_TO_VR_FLAG(PROT_READ | PROT_WRITE);
			unsigned long ro_vrflags = VR_DEMAND_PAGING |
				PROT_TO_VR_FLAG(PROT_READ);

			write_vrflags |= VRFLAG_PROT_TO_MAXPROT(write_vrflags);
			ro_vrflags |= VRFLAG_PROT_TO_MAXPROT(ro_vrflags);

			fake_shmat_reset(&obj);
			fake_shmat_lookup_rc = -22;
			rc = fake_shmat_call(7, 0x20000UL, 0, 10, 30);
			require(rc == -22);
			require(fake_shmat_list_lock_calls == 1);
			require(fake_shmat_list_unlock_calls == 1);
			require(fake_shmat_unref_calls == 0);
			require(fake_shmat_range_lock_calls == 0);
			require(fake_shmat_log_calls == 2);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			fake_shmat_reset(&obj);
			rc = fake_shmat_call(8, 0x20001UL, 0, 10, 30);
			require(rc == -22);
			require(fake_shmat_unref_calls == 1);
			require(fake_shmat_range_lock_calls == 0);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			obj.mode = 0444;
			fake_shmat_reset(&obj);
			rc = fake_shmat_call(9, 0x21000UL, 0, 99, 88);
			require(rc == -13);
			require(fake_shmat_unref_calls == 1);
			require(fake_shmat_range_lock_calls == 0);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			obj.mode = 0666;
			fake_shmat_reset(&obj);
			fake_shmat_range_busy = 1;
			rc = fake_shmat_call(10, 0x22000UL, 0, 10, 30);
			require(rc == -12);
			require(fake_shmat_range_lock_calls == 1);
			require(fake_shmat_range_unlock_calls == 1);
			require(fake_shmat_lookup_range_calls == 1);
			require(fake_shmat_unref_calls == 1);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			fake_shmat_reset(&obj);
			fake_shmat_search_rc = -12;
			rc = fake_shmat_call(11, 0, 0, 10, 30);
			require(rc == -12);
			require(fake_shmat_search_calls == 1);
			require(fake_shmat_add_calls == 0);
			require(fake_shmat_unref_calls == 1);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			fake_shmat_reset(&obj);
			fake_shmat_search_addr = 0x30000UL;
			fake_shmat_sethost_rc = -5;
			rc = fake_shmat_call(12, 0, SHM_RDONLY, 10, 30);
			require(rc == -5);
			require(fake_shmat_search_calls == 1);
			require(fake_shmat_sethost_calls == 1);
			require(fake_shmat_add_calls == 0);
			require(fake_shmat_unref_calls == 1);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			fake_shmat_reset(&obj);
			fake_shmat_search_addr = 0x31000UL;
			fake_shmat_add_rc = -17;
			rc = fake_shmat_call(13, 0, SHM_RDONLY, 10, 30);
			require(rc == -17);
			require(fake_shmat_sethost_calls == 2);
			require(fake_shmat_sethost_prot ==
				(PROT_READ | PROT_WRITE | PROT_EXEC));
			require(fake_shmat_unref_calls == 1);
			mix(digest, fake_shmat_digest);
			mix_signed(digest, rc);

			fake_shmat_reset(&obj);
			rc = fake_shmat_call(14, 0x42001UL, SHM_RND, 10, 30);
			require(rc == 0x42000UL);
			require(fake_shmat_lookup_range_calls == 1);
			require(fake_shmat_sethost_calls == 0);
			require(fake_shmat_add_calls == 1);
			require(fake_shmat_add_start == 0x42000UL);
			require(fake_shmat_add_end == 0x45000UL);
			require(fake_shmat_add_flags == write_vrflags);
			require(fake_shmat_add_pgshift == 12);
			require(fake_shmat_unref_calls == 0);
			mix(digest, fake_shmat_digest);
			mix(digest, fake_shmat_add_flags);

			fake_shmat_reset(&obj);
			fake_shmat_search_addr = 0x50000UL;
			rc = fake_shmat_call(15, 0, SHM_RDONLY, 10, 30);
			require(rc == 0x50000UL);
			require(fake_shmat_search_calls == 1);
			require(fake_shmat_sethost_calls == 1);
			require(fake_shmat_add_calls == 1);
			require(fake_shmat_add_start == 0x50000UL);
			require(fake_shmat_add_end == 0x53000UL);
			require(fake_shmat_add_flags == ro_vrflags);
			require(fake_shmat_unref_calls == 0);
			mix(digest, fake_shmat_digest);
			mix(digest, fake_shmat_add_flags);
		}

		{
			struct fake_shmctl_obj obj;
			struct fake_shmctl_obj index_obj;
			struct fake_shmlock_user user;
			struct fake_shmid_ds ads;
			struct fake_shmid_ds out_ds;
			struct fake_shminfo out_info;
			struct fake_shm_info out_shm_info;

			memset(&obj, 0, sizeof(obj));
			obj.pgshift = 12;
			obj.real_segsz = 0x3000UL;
			obj.ds.shm_perm.uid = 10;
			obj.ds.shm_perm.cuid = 20;
			obj.ds.shm_perm.gid = 30;
			obj.ds.shm_perm.cgid = 40;
			obj.ds.shm_perm.mode = 0666;
			memset(&user, 0, sizeof(user));
			user.ruid = 77;
			user.locked = 0x1000UL;

			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(1, IPC_RMID, NULL, 10, 30, 77,
				0x100000UL, 0, 0);
			require(rc == 0);
			require((obj.ds.shm_perm.mode & SHM_DEST) != 0);
			require(fake_shmctl_unref_calls == 2);
			require(fake_shmctl_list_lock_calls == 1);
			require(fake_shmctl_list_unlock_calls == 1);
			require(fake_shmctl_log_calls == 2);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);

			obj.ds.shm_perm.mode = 0666;
			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(2, IPC_RMID, NULL, 99, 30, 77,
				0x100000UL, 0, 0);
			require(rc == -EPERM);
			require((obj.ds.shm_perm.mode & SHM_DEST) == 0);
			require(fake_shmctl_unref_calls == 1);
			require(fake_shmctl_last_log_event == SHMCTL_LOG_EPERM);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);

			memset(&ads, 0, sizeof(ads));
			ads.shm_perm.uid = 55;
			ads.shm_perm.gid = 66;
			ads.shm_perm.mode = 0771;
			obj.ds.shm_perm.uid = 10;
			obj.ds.shm_perm.cuid = 20;
			obj.ds.shm_perm.gid = 30;
			obj.ds.shm_perm.mode = 0644 | SHM_DEST;
			obj.ds.shm_ctime = 1;
			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(3, IPC_SET, &ads, 20, 30, 77,
				0x100000UL, 0, 0);
			require(rc == 0);
			require(obj.ds.shm_perm.uid == 55);
			require(obj.ds.shm_perm.gid == 66);
			require(obj.ds.shm_perm.mode == (SHM_DEST | 0771));
			require(obj.ds.shm_ctime == 1234567);
			require(fake_shmctl_copy_from_calls == 1);
			require(fake_shmctl_unref_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);

			obj.ds.shm_perm.uid = 10;
			obj.ds.shm_perm.cuid = 20;
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_copy_from_rc = -EFAULT;
			rc = fake_shmctl_call(4, IPC_SET, &ads, 10, 30, 77,
				0x100000UL, 0, 0);
			require(rc == -EFAULT);
			require(fake_shmctl_copy_from_calls == 1);
			require(fake_shmctl_unref_calls == 1);
			require(fake_shmctl_last_log_event == SHMCTL_LOG_COPY);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);

			memset(&out_ds, 0, sizeof(out_ds));
			obj.ds.shm_perm.uid = 10;
			obj.ds.shm_perm.cuid = 20;
			obj.ds.shm_perm.gid = 30;
			obj.ds.shm_perm.cgid = 40;
			obj.ds.shm_perm.mode = 0644;
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_refcnt_value = 5;
			rc = fake_shmctl_call(5, IPC_STAT, &out_ds, 99, 30, 77,
				0x100000UL, 1, 0);
			require(rc == 0);
			require(out_ds.shm_nattch == 3);
			require(fake_shmctl_refcnt_calls == 1);
			require(fake_shmctl_copy_to_calls == 1);
			require(fake_shmctl_unref_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, out_ds.shm_nattch);

			memset(&index_obj, 0, sizeof(index_obj));
			index_obj.ds.shm_perm.uid = 90;
			index_obj.ds.shm_perm.cuid = 91;
			index_obj.ds.shm_perm.mode = SHM_DEST | 0600;
			memset(&out_ds, 0, sizeof(out_ds));
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_index_obj = &index_obj;
			fake_shmctl_refcnt_value = 4;
			rc = fake_shmctl_call(6, SHM_STAT, &out_ds, 99, 30, 77,
				0x100000UL, 0, 0);
			require(rc == 0);
			require(out_ds.shm_nattch == 3);
			require(fake_shmctl_lookup_calls == 0);
			require(fake_shmctl_lookup_index_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, out_ds.shm_nattch);

			memset(&out_info, 0, sizeof(out_info));
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_max_index = 42;
			rc = fake_shmctl_call(7, IPC_INFO, &out_info, 10, 30, 77,
				0x100000UL, 0, 0);
			require(rc == 42);
			require(out_info.shmmax == fake_shmctl_shminfo.shmmax);
			require(fake_shmctl_lookup_calls == 1);
			require(fake_shmctl_max_index_calls == 1);
			require(fake_shmctl_unref_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, out_info.shmmni);

			obj.ds.shm_perm.mode = 0666;
			obj.user = NULL;
			user.locked = 0x1000UL;
			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(8, SHM_LOCK, NULL, 10, 30, 77,
				0x10000UL, 0, 0);
			require(rc == 0);
			require((obj.ds.shm_perm.mode & SHM_LOCKED) != 0);
			require(obj.user == &user);
			require(user.locked == 0x4000UL);
			require(fake_shmctl_users_lock_calls == 1);
			require(fake_shmctl_users_unlock_calls == 1);
			require(fake_shmctl_user_get_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, user.locked);

			obj.ds.shm_perm.mode = 0666;
			obj.user = NULL;
			user.locked = 0x1000UL;
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_user_get_rc = -ENOMEM;
			rc = fake_shmctl_call(9, SHM_LOCK, NULL, 10, 30, 77,
				0x10000UL, 0, 0);
			require(rc == -ENOMEM);
			require((obj.ds.shm_perm.mode & SHM_LOCKED) == 0);
			require(fake_shmctl_users_lock_calls == 1);
			require(fake_shmctl_users_unlock_calls == 1);
			require(fake_shmctl_unref_calls == 1);
			require(fake_shmctl_last_log_event ==
				SHMCTL_LOG_USER_LOOKUP);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);

			obj.ds.shm_perm.mode = SHM_LOCKED | 0666;
			obj.user = &user;
			user.locked = obj.real_segsz;
			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(10, SHM_UNLOCK, NULL, 10, 30, 77,
				0x10000UL, 0, 0);
			require(rc == 0);
			require((obj.ds.shm_perm.mode & SHM_LOCKED) == 0);
			require(obj.user == NULL);
			require(user.locked == 0);
			require(fake_shmctl_user_free_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, user.locked);

			memset(&out_shm_info, 0, sizeof(out_shm_info));
			fake_shmctl_reset(&obj, &user);
			fake_shmctl_max_index = -1;
			rc = fake_shmctl_call(11, SHM_INFO, &out_shm_info, 10,
				30, 77, 0x10000UL, 0, 0);
			require(rc == 0);
			require(out_shm_info.shm_tot ==
				fake_shmctl_shm_info.shm_tot);
			require(fake_shmctl_lookup_calls == 0);
			require(fake_shmctl_copy_to_calls == 1);
			require(fake_shmctl_max_index_calls == 1);
			mix(digest, fake_shmctl_digest);
			mix(digest, out_shm_info.shm_tot);

			fake_shmctl_reset(&obj, &user);
			rc = fake_shmctl_call(12, 99, NULL, 10, 30, 77,
				0x10000UL, 0, 0);
			require(rc == -EINVAL);
			require(fake_shmctl_list_lock_calls == 0);
			require(fake_shmctl_last_log_event == SHMCTL_LOG_EINVAL);
			mix(digest, fake_shmctl_digest);
			mix_signed(digest, rc);
		}

		fake_mprotect_reset(NULL, 0);
		rc = mprotect_body_result(&fake_vm, &fake_lock, 0x10001UL,
			PAGE_SIZE, PROT_READ, 0x10000UL, 0x20000UL, 0, 0,
			21, offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			fake_mprotect_lock, fake_mprotect_unlock,
			fake_mprotect_lookup, fake_mprotect_next,
			fake_mprotect_split, fake_mprotect_join,
			fake_mprotect_change, fake_mprotect_set_host_vma,
			fake_mprotect_flush_nfo, fake_mprotect_flush_tlb,
			fake_mprotect_log);
		require(rc == -22);
		require(fake_mprotect_lock_calls == 0);
		require(fake_mprotect_flush_nfo_calls == 0);
		require(fake_mprotect_flush_tlb_calls == 0);
		require(fake_mprotect_log_calls == 2);
		mix(digest, fake_mprotect_digest);
		mix_signed(digest, rc);

		fake_mprotect_reset(NULL, 0);
		rc = mprotect_body_result(&fake_vm, &fake_lock, 0x11000UL,
			PAGE_SIZE, PROT_READ, 0x10000UL, 0x20000UL,
			0x10000UL, 0x4000UL, 22,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			fake_mprotect_lock, fake_mprotect_unlock,
			fake_mprotect_lookup, fake_mprotect_next,
			fake_mprotect_split, fake_mprotect_join,
			fake_mprotect_change, fake_mprotect_set_host_vma,
			fake_mprotect_flush_nfo, fake_mprotect_flush_tlb,
			fake_mprotect_log);
		require(rc == 0);
		require(fake_mprotect_lock_calls == 0);
		require(fake_mprotect_lookup_calls == 0);
		require(fake_mprotect_flush_nfo_calls == 0);
		require(fake_mprotect_flush_tlb_calls == 0);
		require(fake_mprotect_log_calls == 3);
		mix(digest, fake_mprotect_digest);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x13000UL,
			.flag = VR_PROT_WRITE |
				VRFLAG_PROT_TO_MAXPROT(VR_PROT_READ |
					VR_PROT_WRITE | VR_PROT_EXEC),
			.memobj = NULL,
		};
		ranges[1] = (struct fake_msync_range) {
			.start = 0x13000UL,
			.end = 0x15000UL,
			.flag = VR_PROT_WRITE |
				VRFLAG_PROT_TO_MAXPROT(VR_PROT_READ |
					VR_PROT_WRITE | VR_PROT_EXEC),
			.memobj = NULL,
		};
		fake_mprotect_reset(ranges, 2);
		rc = mprotect_body_result(&fake_vm, &fake_lock, 0x11000UL,
			0x3000UL, PROT_READ, 0x10000UL, 0x20000UL, 0, 0,
			23, offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			fake_mprotect_lock, fake_mprotect_unlock,
			fake_mprotect_lookup, fake_mprotect_next,
			fake_mprotect_split, fake_mprotect_join,
			fake_mprotect_change, fake_mprotect_set_host_vma,
			fake_mprotect_flush_nfo, fake_mprotect_flush_tlb,
			fake_mprotect_log);
		require(rc == 0);
		require(fake_mprotect_lock_calls == 1);
		require(fake_mprotect_unlock_calls == 1);
		require(fake_mprotect_lookup_calls == 1);
		require(fake_mprotect_next_calls == 1);
		require(fake_mprotect_split_calls == 2);
		require(fake_mprotect_change_calls == 2);
		require(fake_mprotect_join_calls == 1);
		require(fake_mprotect_sethost_calls == 1);
		require(fake_mprotect_flush_nfo_calls == 1);
		require(fake_mprotect_flush_tlb_calls == 1);
		require(fake_mprotect_sethost_start == 0x11000UL);
		require(fake_mprotect_sethost_len == 0x3000UL);
		require(fake_mprotect_sethost_prot == PROT_READ);
		require(ranges[0].start == 0x11000UL);
		require(ranges[0].end == 0x14000UL);
		mix(digest, fake_mprotect_digest);
		mix(digest, ranges[0].flag);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = VR_PROT_READ |
				VRFLAG_PROT_TO_MAXPROT(VR_PROT_READ),
			.memobj = NULL,
		};
		fake_mprotect_reset(ranges, 1);
		rc = mprotect_body_result(&fake_vm, &fake_lock, 0x10000UL,
			PAGE_SIZE, PROT_WRITE, 0x10000UL, 0x20000UL, 0, 0,
			24, offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			fake_mprotect_lock, fake_mprotect_unlock,
			fake_mprotect_lookup, fake_mprotect_next,
			fake_mprotect_split, fake_mprotect_join,
			fake_mprotect_change, fake_mprotect_set_host_vma,
			fake_mprotect_flush_nfo, fake_mprotect_flush_tlb,
			fake_mprotect_log);
		require(rc == -13);
		require(fake_mprotect_lock_calls == 1);
		require(fake_mprotect_unlock_calls == 1);
		require(fake_mprotect_change_calls == 0);
		require(fake_mprotect_sethost_calls == 0);
		require(fake_mprotect_flush_tlb_calls == 1);
		mix(digest, fake_mprotect_digest);
		mix_signed(digest, rc);

		ranges[0].flag = VR_PROT_WRITE |
			VRFLAG_PROT_TO_MAXPROT(VR_PROT_READ | VR_PROT_WRITE);
		fake_mprotect_reset(ranges, 1);
		fake_mprotect_change_rc = -5;
		rc = mprotect_body_result(&fake_vm, &fake_lock, 0x10000UL,
			PAGE_SIZE, PROT_READ, 0x10000UL, 0x20000UL, 0, 0,
			25, offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			fake_mprotect_lock, fake_mprotect_unlock,
			fake_mprotect_lookup, fake_mprotect_next,
			fake_mprotect_split, fake_mprotect_join,
			fake_mprotect_change, fake_mprotect_set_host_vma,
			fake_mprotect_flush_nfo, fake_mprotect_flush_tlb,
			fake_mprotect_log);
		require(rc == -5);
		require(fake_mprotect_lock_calls == 1);
		require(fake_mprotect_unlock_calls == 1);
		require(fake_mprotect_change_calls == 1);
		require(fake_mprotect_sethost_calls == 0);
		mix(digest, fake_mprotect_digest);
		mix_signed(digest, rc);
	}
}

static void exercise_memory_syscall_policy(unsigned long *digest)
{
	static const int mlock_flags[] = { 0, MCL_CURRENT, MCL_FUTURE,
		MCL_CURRENT | MCL_FUTURE, 4 };
	static const struct range_case remap_cases[] = {
		{ 0x10000UL, 0, 0, 0 },
		{ 0x10001UL, PAGE_SIZE, 0, 0 },
		{ 0x10000UL, PAGE_SIZE, 0, 0 },
		{ 0xfffffffffffff000UL, PAGE_SIZE * 2, 0, 0 },
	};
	static const size_t pgoffs[] = { 0, 1, PGOFF_LIMIT - 1, PGOFF_LIMIT };
	static const int prot_values[] = { 0, 1 };
	static const int mremap_flags[] = {
		0, MREMAP_MAYMOVE, MREMAP_FIXED,
		MREMAP_FIXED | MREMAP_MAYMOVE, 4,
	};
	static const int msync_flags[] = {
		0, MS_ASYNC, MS_INVALIDATE, MS_SYNC,
		MS_ASYNC | MS_SYNC, 8,
	};
	static const unsigned long maxnodes[] = {
		0, 1, 255, 256, 257, PAGE_SIZE << 3, (PAGE_SIZE << 3) + 1,
	};
	static const int modes[] = {
		-1, MPOL_DEFAULT, MPOL_PREFERRED, MPOL_BIND, MPOL_INTERLEAVE,
		4, MPOL_BIND | MPOL_F_STATIC_NODES,
		MPOL_BIND | MPOL_F_RELATIVE_NODES,
		MPOL_BIND | MPOL_F_STATIC_NODES | MPOL_F_RELATIVE_NODES,
	};
	static const int mempolicy_flags[] = {
		0, MPOL_MF_STRICT, MPOL_MF_MOVE,
		MPOL_MF_STRICT | MPOL_MF_MOVE,
	};

	for (unsigned int i = 0; i < sizeof(mlock_flags) / sizeof(mlock_flags[0]); i++) {
		mix_signed(digest, mlockall_policy_result(mlock_flags[i], 0, 0));
		mix_signed(digest, mlockall_policy_result(mlock_flags[i], 0, 4096));
		mix_signed(digest, mlockall_policy_result(mlock_flags[i], 1, 0));
	}

	for (unsigned int i = 0; i < sizeof(remap_cases) / sizeof(remap_cases[0]); i++) {
		for (unsigned int p = 0; p < sizeof(prot_values) / sizeof(prot_values[0]); p++) {
			for (unsigned int o = 0; o < sizeof(pgoffs) / sizeof(pgoffs[0]); o++) {
				uintptr_t start = 0xa5a5;
				uintptr_t end = 0x5a5a;
				long off = -1;

				mix_signed(digest, remap_file_pages_prepare(remap_cases[i].start,
					remap_cases[i].len, prot_values[p], pgoffs[o],
					&start, &end, &off));
				mix(digest, start);
				mix(digest, end);
				mix(digest, (unsigned long)off);
			}
		}
	}

	{
		int fake_vm;
		int fake_lock;
		int callable = 1;
		struct fake_msync_range ranges[1];
		int rc;

		fake_remap_file_pages_reset(NULL, 0);
		rc = remap_file_pages_body_result(&fake_vm, &fake_lock,
			0x10000UL, 0x1001UL, 0, 0, 0, 31,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_remap_file_pages_lock,
			fake_remap_file_pages_unlock,
			fake_remap_file_pages_lookup,
			fake_remap_file_pages_callable,
			fake_remap_file_pages_remap,
			fake_remap_file_pages_clear_host,
			fake_remap_file_pages_populate,
			fake_remap_file_pages_flush,
			fake_remap_file_pages_log);
		require(rc == -22);
		require(fake_remap_file_pages_lock_calls == 1);
		require(fake_remap_file_pages_unlock_calls == 1);
		require(fake_remap_file_pages_lookup_calls == 0);
		require(fake_remap_file_pages_remap_calls == 0);
		mix(digest, fake_remap_file_pages_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x13000UL,
			.flag = VR_PRIVATE,
			.memobj = &callable,
		};
		fake_remap_file_pages_reset(ranges, 1);
		rc = remap_file_pages_body_result(&fake_vm, &fake_lock,
			0x10000UL, 0x2000UL, 0, 1, 0, 32,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_remap_file_pages_lock,
			fake_remap_file_pages_unlock,
			fake_remap_file_pages_lookup,
			fake_remap_file_pages_callable,
			fake_remap_file_pages_remap,
			fake_remap_file_pages_clear_host,
			fake_remap_file_pages_populate,
			fake_remap_file_pages_flush,
			fake_remap_file_pages_log);
		require(rc == -22);
		require(fake_remap_file_pages_lookup_calls == 1);
		require(fake_remap_file_pages_callable_calls == 0);
		require(fake_remap_file_pages_remap_calls == 0);
		mix(digest, fake_remap_file_pages_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x14000UL,
			.flag = VR_LOCKED,
			.memobj = &callable,
		};
		fake_remap_file_pages_reset(ranges, 1);
		fake_remap_file_pages_populate_rc = -5;
		rc = remap_file_pages_body_result(&fake_vm, &fake_lock,
			0x10001UL, 0x2000UL, 0, 2, 0, 33,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_remap_file_pages_lock,
			fake_remap_file_pages_unlock,
			fake_remap_file_pages_lookup,
			fake_remap_file_pages_callable,
			fake_remap_file_pages_remap,
			fake_remap_file_pages_clear_host,
			fake_remap_file_pages_populate,
			fake_remap_file_pages_flush,
			fake_remap_file_pages_log);
		require(rc == 0);
		require(fake_remap_file_pages_lookup_calls == 1);
		require(fake_remap_file_pages_callable_calls == 1);
		require(fake_remap_file_pages_flush_calls == 1);
		require(fake_remap_file_pages_remap_calls == 1);
		require(fake_remap_file_pages_clear_calls == 1);
		require(fake_remap_file_pages_populate_calls == 1);
		require(fake_remap_file_pages_last_start == 0x10000UL);
		require(fake_remap_file_pages_last_end == 0x12000UL);
		require(fake_remap_file_pages_last_off == 0x2000L);
		require(fake_remap_file_pages_clear_start == 0x10000UL);
		require(fake_remap_file_pages_clear_size == 0x2000UL);
		require(ranges[0].flag & VR_FILEOFF);
		mix(digest, fake_remap_file_pages_digest);
		mix(digest, ranges[0].flag);

		ranges[0].flag = 0;
		fake_remap_file_pages_reset(ranges, 1);
		fake_remap_file_pages_remap_rc = -5;
		rc = remap_file_pages_body_result(&fake_vm, &fake_lock,
			0x10000UL, PAGE_SIZE, 0, 3, 0, 34,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_remap_file_pages_lock,
			fake_remap_file_pages_unlock,
			fake_remap_file_pages_lookup,
			fake_remap_file_pages_callable,
			fake_remap_file_pages_remap,
			fake_remap_file_pages_clear_host,
			fake_remap_file_pages_populate,
			fake_remap_file_pages_flush,
			fake_remap_file_pages_log);
		require(rc == -5);
		require(fake_remap_file_pages_remap_calls == 1);
		require(fake_remap_file_pages_clear_calls == 0);
		require(fake_remap_file_pages_populate_calls == 0);
		require(ranges[0].flag & VR_FILEOFF);
		mix(digest, fake_remap_file_pages_digest);
		mix_signed(digest, rc);
	}

	for (unsigned int f = 0; f < sizeof(mremap_flags) / sizeof(mremap_flags[0]); f++) {
		size_t oldsize = 0;
		size_t newsize = 0;
		uintptr_t oldend = 0;
		int no_op = 0;

		mix_signed(digest, mremap_prepare_args(0x10000, PAGE_SIZE,
			PAGE_SIZE, mremap_flags[f], 0x30000, 0x10000, 0x80000,
			&oldsize, &newsize, &oldend, &no_op));
		mix(digest, oldsize);
		mix(digest, newsize);
		mix(digest, oldend);
		mix_signed(digest, no_op);

		mix_signed(digest, mremap_prepare_args(0x10001, PAGE_SIZE,
			PAGE_SIZE * 2, mremap_flags[f], 0x30001, 0x10000, 0x80000,
			&oldsize, &newsize, &oldend, &no_op));
		mix(digest, oldsize);
		mix(digest, newsize);
		mix(digest, oldend);
		mix_signed(digest, no_op);
		mix_signed(digest, mremap_maymove_result(mremap_flags[f]));
	}

	mix_signed(digest, mremap_prepare_args(0xfffffffffffff000UL, 0x3000,
		0x4000, MREMAP_MAYMOVE, 0, 0x10000, 0x80000,
		&(size_t){0}, &(size_t){0}, &(uintptr_t){0}, &(int){0}));
	mix_signed(digest, mremap_prepare_args(0x10000, PAGE_SIZE,
		0x800000, MREMAP_MAYMOVE, 0, 0x10000, 0x80000,
		&(size_t){0}, &(size_t){0}, &(uintptr_t){0}, &(int){0}));

	mix_signed(digest, mremap_fixed_range_result(0x08000, 0x10000,
		0x20000, 0x24000, 0x30000));
	mix_signed(digest, mremap_fixed_range_result(0x22000, 0x10000,
		0x20000, 0x24000, 0x26000));
	mix_signed(digest, mremap_fixed_range_result(0x30000, 0x10000,
		0x20000, 0x24000, 0x34000));

	{
		int fake_vm;
		int fake_lock;
		int fake_pte_lock;
		int fake_memobj;
		void *fake_page_table = (void *)0x700000UL;
		struct fake_mremap_range ranges[2];
		long rc;

#define FAKE_MREMAP_BODY(oldaddr, oldsize0, newsize0, flags, newaddr, straight_va, straight_len) \
		mremap_body_result(&fake_vm, &fake_lock, &fake_pte_lock, \
			fake_page_table, oldaddr, oldsize0, newsize0, flags, \
			newaddr, 0x10000UL, 0x80000UL, straight_va, \
			straight_len, offsetof(struct fake_mremap_range, start), \
			offsetof(struct fake_mremap_range, end), \
			offsetof(struct fake_mremap_range, flag), \
			offsetof(struct fake_mremap_range, pgshift), \
			offsetof(struct fake_mremap_range, memobj), \
			offsetof(struct fake_mremap_range, objoff), \
			fake_mremap_lock, fake_mremap_unlock, \
			fake_mremap_lookup, fake_mremap_extend, \
			fake_mremap_flush, fake_mremap_search, \
			fake_mremap_munmap, fake_mremap_memobj_ref, \
			fake_mremap_memobj_unref, fake_mremap_add, \
			fake_mremap_pte_lock, fake_mremap_pte_unlock, \
			fake_mremap_split, fake_mremap_move, \
			fake_mremap_populate, fake_mremap_log)

		fake_mremap_reset(NULL, 0);
		rc = FAKE_MREMAP_BODY(0x20000UL, PAGE_SIZE, PAGE_SIZE, 0, 0,
			0x20000UL, PAGE_SIZE);
		require(rc == -22);
		require(fake_mremap_lock_calls == 0);
		require(fake_mremap_lookup_calls == 0);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		fake_mremap_reset(NULL, 0);
		rc = FAKE_MREMAP_BODY(0x20000UL, PAGE_SIZE, PAGE_SIZE, 0, 0,
			0, 0);
		require(rc == 0x20000L);
		require(fake_mremap_lock_calls == 1);
		require(fake_mremap_unlock_calls == 1);
		require(fake_mremap_lookup_calls == 0);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_mremap_range) {
			.start = 0x10000UL,
			.end = 0x11000UL,
			.flag = VR_LOCKED,
			.pgshift = 12,
			.memobj = &fake_memobj,
			.objoff = 0x40,
		};
		fake_mremap_reset(ranges, 1);
		fake_mremap_populate_rc = -7;
		rc = FAKE_MREMAP_BODY(0x10000UL, PAGE_SIZE, PAGE_SIZE * 2,
			0, 0, 0, 0);
		require(rc == 0x10000L);
		require(ranges[0].end == 0x12000UL);
		require(fake_mremap_extend_calls == 1);
		require(fake_mremap_flush_calls == 1);
		require(fake_mremap_search_calls == 0);
		require(fake_mremap_add_calls == 0);
		require(fake_mremap_populate_calls == 1);
		require(fake_mremap_populate_start == 0x11000UL);
		require(fake_mremap_populate_len == PAGE_SIZE);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_mremap_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = VR_PRIVATE,
			.pgshift = 21,
			.memobj = &fake_memobj,
			.objoff = 0x700,
		};
		fake_mremap_reset(ranges, 1);
		fake_mremap_extend_rc = -5;
		fake_mremap_search_addr = 0x30000UL;
		rc = FAKE_MREMAP_BODY(0x10000UL, PAGE_SIZE * 2,
			PAGE_SIZE * 4, MREMAP_MAYMOVE, 0, 0, 0);
		require(rc == 0x30000L);
		require(fake_mremap_extend_calls == 1);
		require(fake_mremap_search_calls == 1);
		require(fake_mremap_add_calls == 1);
		require(fake_mremap_add_start == 0x30000UL);
		require(fake_mremap_add_end == 0x34000UL);
		require(fake_mremap_add_pgshift == -1);
		require(fake_mremap_add_flags == VR_PRIVATE);
		require(fake_mremap_add_memobj == &fake_memobj);
		require(fake_mremap_add_objoff == 0x700UL);
		require(fake_mremap_memobj_ref_calls == 1);
		require(fake_mremap_memobj_unref_calls == 0);
		require(fake_mremap_pte_lock_calls == 1);
		require(fake_mremap_pte_unlock_calls == 1);
		require(fake_mremap_move_calls == 1);
		require(fake_mremap_move_oldstart == 0x10000UL);
		require(fake_mremap_move_newstart == 0x30000UL);
		require(fake_mremap_move_size == PAGE_SIZE * 2);
		require(fake_mremap_munmap_calls == 1);
		require(fake_mremap_munmap_addr == 0x10000UL);
		require(fake_mremap_munmap_len == PAGE_SIZE * 2);
		require(fake_mremap_munmap_holding == 1);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_mremap_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = VR_PRIVATE,
			.pgshift = 21,
			.memobj = &fake_memobj,
			.objoff = 0x900,
		};
		fake_mremap_reset(ranges, 1);
		fake_mremap_extend_rc = -5;
		fake_mremap_add_rc = -6;
		rc = FAKE_MREMAP_BODY(0x10000UL, PAGE_SIZE * 2,
			PAGE_SIZE * 4, MREMAP_MAYMOVE, 0, 0, 0);
		require(rc == -6);
		require(fake_mremap_add_calls == 1);
		require(fake_mremap_memobj_ref_calls == 1);
		require(fake_mremap_memobj_unref_calls == 1);
		require(fake_mremap_move_calls == 0);
		require(fake_mremap_munmap_calls == 0);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_mremap_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = VR_PRIVATE,
			.pgshift = 21,
			.memobj = NULL,
			.objoff = 0x200,
		};
		fake_mremap_reset(ranges, 1);
		fake_mremap_extend_rc = -5;
		fake_mremap_move_rc = -9;
		rc = FAKE_MREMAP_BODY(0x10000UL, PAGE_SIZE * 2,
			PAGE_SIZE * 4, MREMAP_MAYMOVE, 0, 0, 0);
		require(rc == -9);
		require(fake_mremap_add_calls == 1);
		require(fake_mremap_pte_lock_calls == 1);
		require(fake_mremap_pte_unlock_calls == 1);
		require(fake_mremap_move_calls == 1);
		require(fake_mremap_munmap_calls == 0);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

		ranges[0] = (struct fake_mremap_range) {
			.start = 0x10000UL,
			.end = 0x13000UL,
			.flag = VR_PRIVATE,
			.pgshift = 12,
			.memobj = NULL,
			.objoff = 0,
		};
		fake_mremap_reset(ranges, 1);
		rc = FAKE_MREMAP_BODY(0x10000UL, PAGE_SIZE * 3, PAGE_SIZE,
			0, 0, 0, 0);
		require(rc == 0x10000L);
		require(fake_mremap_munmap_calls == 1);
		require(fake_mremap_munmap_addr == 0x11000UL);
		require(fake_mremap_munmap_len == PAGE_SIZE * 2);
		require(fake_mremap_add_calls == 0);
		require(fake_mremap_move_calls == 0);
		mix(digest, fake_mremap_digest);
		mix_signed(digest, rc);

#undef FAKE_MREMAP_BODY
	}

	for (unsigned int f = 0; f < sizeof(msync_flags) / sizeof(msync_flags[0]); f++) {
		size_t len = 0;
		uintptr_t end = 0;

		mix_signed(digest, msync_prepare_range(0x10000, PAGE_SIZE,
			msync_flags[f], &len, &end));
		mix(digest, len);
		mix(digest, end);
		mix_signed(digest, msync_prepare_range(0x10001, PAGE_SIZE,
			msync_flags[f], &len, &end));
		mix_signed(digest, msync_locked_range_result(msync_flags[f], 0));
		mix_signed(digest, msync_locked_range_result(msync_flags[f], VR_LOCKED));
	}
	mix_signed(digest, msync_prepare_range(0xfffffffffffff000UL, 0x3000,
		MS_SYNC, &(size_t){0}, &(uintptr_t){0}));
	{
		int fake_vm;
		int fake_lock;
		int pager = 1;
		struct fake_msync_range ranges[2];
		int rc;

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.flag = VR_PRIVATE,
			.memobj = &pager,
		};
		fake_msync_reset(ranges, 1);
		rc = msync_body_result(&fake_vm, &fake_lock, 0x10001UL,
			PAGE_SIZE, MS_SYNC,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_msync_lock, fake_msync_unlock,
			fake_msync_lookup, fake_msync_next,
			fake_msync_has_pager, fake_msync_sync,
			fake_msync_invalidate, fake_msync_log);
		require(rc == -22);
		require(fake_msync_lock_calls == 1);
		require(fake_msync_unlock_calls == 1);
		require(fake_msync_lookup_calls == 0);
		require(fake_msync_sync_calls == 0);
		require(fake_msync_invalidate_calls == 0);
		mix(digest, fake_msync_digest);
		mix_signed(digest, rc);

		fake_msync_reset(ranges, 1);
		rc = msync_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x2000UL, MS_SYNC,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_msync_lock, fake_msync_unlock,
			fake_msync_lookup, fake_msync_next,
			fake_msync_has_pager, fake_msync_sync,
			fake_msync_invalidate, fake_msync_log);
		require(rc == 0);
		require(fake_msync_lock_calls == 1);
		require(fake_msync_unlock_calls == 1);
		require(fake_msync_lookup_calls == 2);
		require(fake_msync_next_calls == 0);
		require(fake_msync_has_pager_calls == 0);
		require(fake_msync_sync_calls == 0);
		require(fake_msync_invalidate_calls == 0);
		mix(digest, fake_msync_digest);

		ranges[0] = (struct fake_msync_range) {
			.start = 0x10000UL,
			.end = 0x11000UL,
			.flag = 0,
			.memobj = NULL,
		};
		ranges[1] = (struct fake_msync_range) {
			.start = 0x11000UL,
			.end = 0x13000UL,
			.flag = 0,
			.memobj = &pager,
		};
		fake_msync_reset(ranges, 2);
		rc = msync_body_result(&fake_vm, &fake_lock, 0x10000UL,
			0x3000UL, MS_SYNC | MS_INVALIDATE,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_msync_lock, fake_msync_unlock,
			fake_msync_lookup, fake_msync_next,
			fake_msync_has_pager, fake_msync_sync,
			fake_msync_invalidate, fake_msync_log);
		require(rc == 0);
		require(fake_msync_lookup_calls == 2);
		require(fake_msync_next_calls == 2);
		require(fake_msync_has_pager_calls == 1);
		require(fake_msync_sync_calls == 1);
		require(fake_msync_invalidate_calls == 1);
		require(fake_msync_last_sync_start == 0x11000UL);
		require(fake_msync_last_sync_end == 0x13000UL);
		require(fake_msync_last_invalidate_start == 0x11000UL);
		require(fake_msync_last_invalidate_end == 0x13000UL);
		mix(digest, fake_msync_digest);

		ranges[0].flag = VR_LOCKED;
		fake_msync_reset(ranges, 2);
		rc = msync_body_result(&fake_vm, &fake_lock, 0x10000UL,
			PAGE_SIZE, MS_INVALIDATE,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_msync_lock, fake_msync_unlock,
			fake_msync_lookup, fake_msync_next,
			fake_msync_has_pager, fake_msync_sync,
			fake_msync_invalidate, fake_msync_log);
		require(rc == -16);
		require(fake_msync_sync_calls == 0);
		require(fake_msync_invalidate_calls == 0);
		mix(digest, fake_msync_digest);

		ranges[0].flag = 0;
		fake_msync_reset(ranges, 2);
		fake_msync_sync_rc = -5;
		rc = msync_body_result(&fake_vm, &fake_lock, 0x11000UL,
			PAGE_SIZE, MS_SYNC,
			offsetof(struct fake_msync_range, start),
			offsetof(struct fake_msync_range, end),
			offsetof(struct fake_msync_range, flag),
			offsetof(struct fake_msync_range, memobj),
			fake_msync_lock, fake_msync_unlock,
			fake_msync_lookup, fake_msync_next,
			fake_msync_has_pager, fake_msync_sync,
			fake_msync_invalidate, fake_msync_log);
		require(rc == -5);
		require(fake_msync_sync_calls == 1);
		require(fake_msync_invalidate_calls == 0);
		mix(digest, fake_msync_digest);
	}

	mix_signed(digest, mbind_prepare_range(0x10000, PAGE_SIZE,
		&(unsigned long){0}));
	mix_signed(digest, mbind_prepare_range(0x10001, PAGE_SIZE,
		&(unsigned long){0}));
	mix_signed(digest, mbind_prepare_range(0x10000, 0,
		&(unsigned long){0}));
	mix_signed(digest, mbind_prepare_range(0xfffffffffffff000UL, 0x3000,
		&(unsigned long){0}));

	for (unsigned int i = 0; i < sizeof(maxnodes) / sizeof(maxnodes[0]); i++) {
		unsigned long bits = 0xdead;

		mix_signed(digest, mempolicy_nodemask_bits_result(maxnodes[i], &bits));
		mix(digest, bits);
		mix_signed(digest, mempolicy_nodemask_bits_is_clamped(maxnodes[i]));
	}

	for (unsigned int m = 0; m < sizeof(modes) / sizeof(modes[0]); m++) {
		for (unsigned int f = 0; f < sizeof(mempolicy_flags) / sizeof(mempolicy_flags[0]); f++) {
			int mode_flags = 0;
			int normalized = 0;

			mix_signed(digest, mbind_mode_flags_result(modes[m],
				mempolicy_flags[f], &mode_flags, &normalized));
			mix_signed(digest, mode_flags);
			mix_signed(digest, normalized);
		}
		mix_signed(digest, mempolicy_mode_is_supported(modes[m]));
		mix_signed(digest, set_mempolicy_normalize_mode(modes[m], &(int){0}));
	}

	mix_signed(digest, get_mempolicy_validate(0, 0, MPOL_DEFAULT, 0, 2,
		&(unsigned long){0}));
	mix_signed(digest, get_mempolicy_validate(0x10000, 0, MPOL_DEFAULT, 0, 2,
		&(unsigned long){0}));
	mix_signed(digest, get_mempolicy_validate(0, MPOL_F_ADDR, MPOL_DEFAULT, 0, 2,
		&(unsigned long){0}));
	mix_signed(digest, get_mempolicy_validate(0, MPOL_F_NODE, MPOL_INTERLEAVE, 0, 2,
		&(unsigned long){0}));
	mix_signed(digest, get_mempolicy_validate(0x10000, MPOL_F_ADDR | MPOL_F_NODE,
		MPOL_INTERLEAVE, 8, 2, &(unsigned long){0}));
	mix_signed(digest, get_mempolicy_validate(0, MPOL_F_MEMS_ALLOWED,
		MPOL_DEFAULT, 1, 2, &(unsigned long){0}));

	{
		union {
			unsigned long align;
			unsigned char bytes[FAKE_PROCESS_VM_SIZE];
		} vm;
		union {
			unsigned long align;
			unsigned char bytes[FAKE_RANGE_POLICY_SIZE];
		} policy;
		union {
			unsigned long align;
			unsigned char bytes[FAKE_RANGE_POLICY_SIZE];
		} policy2;
		unsigned char range_marker[8] = { 0 };
		unsigned long nodemask[4] = { 0, 0, 0, 0 };
		long rc;

		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10000, PAGE_SIZE, MPOL_BIND,
			0, 8, 0, vm.bytes, 1, 0, 4, FAKE_RANGE_POLICY_SIZE,
			0x20, fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == 0);
		require(fake_getmem_lookup_range_calls == 0);
		mix_signed(digest, rc);

		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10001, PAGE_SIZE, MPOL_BIND,
			0, 8, 0, vm.bytes, 0, 0, 4, FAKE_RANGE_POLICY_SIZE,
			0x20, fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -22);
		mix_signed(digest, rc);

		nodemask[0] = 1;
		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10000, PAGE_SIZE, MPOL_DEFAULT,
			(unsigned long)nodemask, 8, 0, vm.bytes, 0, 0, 4,
			FAKE_RANGE_POLICY_SIZE, 0x20,
			fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -22);
		require(fake_getmem_log_event == 6);
		mix_signed(digest, rc);

		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10000, PAGE_SIZE, MPOL_BIND,
			0, 0, 0, vm.bytes, 0, 0, 4, FAKE_RANGE_POLICY_SIZE,
			0x20, fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -22);
		require(fake_getmem_log_event == 7);
		mix_signed(digest, rc);

		nodemask[0] = 0x8;
		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10000, PAGE_SIZE, MPOL_BIND,
			(unsigned long)nodemask, 8, 0, vm.bytes, 0, 0, 2,
			FAKE_RANGE_POLICY_SIZE, 0x20,
			fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -22);
		require(fake_getmem_log_event == 8);
		mix_signed(digest, rc);

		nodemask[0] = 0x3;
		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = mbind_body_result(0x10000, PAGE_SIZE, MPOL_BIND,
			(unsigned long)nodemask, 8, MPOL_MF_STRICT, vm.bytes,
			0, 0, 4, FAKE_RANGE_POLICY_SIZE, 0x20,
			fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -5);
		mix_signed(digest, rc);

		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		fake_getmem_lookup_range_result = NULL;
		rc = mbind_body_result(0x20000, PAGE_SIZE, MPOL_PREFERRED,
			0, 0, 0, vm.bytes, 0, 0, 4, FAKE_RANGE_POLICY_SIZE,
			0x20, fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == -14);
		require(fake_getmem_lock_calls == 1);
		require(fake_getmem_unlock_calls == 1);
		require(fake_getmem_log_event == 9);
		mix_signed(digest, rc);

		memset(policy.bytes, 0, sizeof(policy.bytes));
		*(unsigned long *)(policy.bytes + 24) = 0x30000;
		*(unsigned long *)(policy.bytes + 32) = 0x31000;
		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		fake_getmem_lookup_range_result = range_marker;
		fake_getmem_policy_search_result = policy.bytes;
		nodemask[0] = 0x5;
		rc = mbind_body_result(0x30000, PAGE_SIZE, MPOL_BIND,
			(unsigned long)nodemask, 8, 0, vm.bytes, 0, 0, 4,
			FAKE_RANGE_POLICY_SIZE, 0x20,
			fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == 0);
		require(*(unsigned long *)(policy.bytes + FAKE_RANGE_POLICY_MASK_OFF) == 0x5UL);
		require(*(int *)(policy.bytes + FAKE_RANGE_POLICY_POLICY_OFF) == MPOL_BIND);
		require(fake_mbind_clear_calls == 0);
		mix(digest, *(unsigned long *)(policy.bytes + FAKE_RANGE_POLICY_MASK_OFF));

		memset(policy2.bytes, 0, sizeof(policy2.bytes));
		reset_mbind_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		fake_getmem_lookup_range_result = range_marker;
		fake_getmem_policy_search_result = NULL;
		fake_mbind_alloc_result = policy2.bytes;
		rc = mbind_body_result(0x40000, PAGE_SIZE, MPOL_INTERLEAVE,
			(unsigned long)nodemask, 8, 0, vm.bytes, 0, 0, 4,
			FAKE_RANGE_POLICY_SIZE, 0x20,
			fake_getmem_copy_from_user, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_mbind_clear_range,
			fake_mbind_alloc, fake_mbind_rb_clear,
			fake_mbind_insert, fake_mbind_log);
		require(rc == 0);
		require(fake_mbind_clear_calls == 1);
		require(fake_mbind_alloc_calls == 1);
		require(fake_mbind_rb_clear_calls == 1);
		require(fake_mbind_insert_calls == 1);
		require(*(unsigned long *)(policy2.bytes + 24) == 0x40000UL);
		require(*(int *)(policy2.bytes + FAKE_RANGE_POLICY_POLICY_OFF) == MPOL_INTERLEAVE);
		require(*(int *)(policy2.bytes + FAKE_RANGE_POLICY_IL_PREV_OFF) == 255);
		mix(digest, fake_mbind_clear_end);
	}

	{
		union {
			unsigned long align;
			unsigned char bytes[FAKE_PROCESS_VM_SIZE];
		} vm;
		unsigned long nodemask[4] = { 0, 0, 0, 0 };
		long rc;

		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0);
		rc = set_mempolicy_body_result(MPOL_DEFAULT, 0,
			(PAGE_SIZE << 3) + 1, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		require(fake_getmem_log_event == 1);
		mix_signed(digest, rc);

		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0);
		rc = set_mempolicy_body_result(
			MPOL_BIND | MPOL_F_STATIC_NODES | MPOL_F_RELATIVE_NODES,
			0, 8, vm.bytes, 4, 321, fake_getmem_copy_from_user,
			fake_setmem_log);
		require(rc == -22);
		mix_signed(digest, rc);

		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0);
		rc = set_mempolicy_body_result(99, 0, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		mix_signed(digest, rc);

		nodemask[0] = 1;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0xf);
		rc = set_mempolicy_body_result(MPOL_DEFAULT,
			(unsigned long)nodemask, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		require(fake_getmem_copy_calls == 1);
		require(fake_getmem_log_event == 3);
		mix_signed(digest, rc);
		mix(digest, fake_getmem_copy_bytes);

		nodemask[0] = 0;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0);
		rc = set_mempolicy_body_result(MPOL_DEFAULT,
			(unsigned long)nodemask, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == 0);
		require(*(unsigned long *)(vm.bytes + FAKE_PROCESS_VM_NUMA_MASK_OFF) == 0xfUL);
		require(*(int *)(vm.bytes + FAKE_PROCESS_VM_POLICY_OFF) == MPOL_DEFAULT);
		require(fake_getmem_log_event == 7);
		mix(digest, *(unsigned long *)(vm.bytes + FAKE_PROCESS_VM_NUMA_MASK_OFF));

		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0);
		rc = set_mempolicy_body_result(MPOL_PREFERRED, 0, 0, vm.bytes,
			4, 654, fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == 0);
		require(*(unsigned long *)(vm.bytes + FAKE_PROCESS_VM_NUMA_MASK_OFF) == 0xfUL);
		require(*(int *)(vm.bytes + FAKE_PROCESS_VM_POLICY_OFF) == MPOL_PREFERRED);
		require(fake_getmem_log_value == 654);
		mix_signed(digest, fake_getmem_log_value);

		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = set_mempolicy_body_result(MPOL_BIND, 0, 8, vm.bytes, 4,
			321, fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		require(fake_getmem_log_event == 4);
		mix_signed(digest, rc);

		nodemask[0] = 8;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = set_mempolicy_body_result(MPOL_BIND,
			(unsigned long)nodemask, 8, vm.bytes, 2, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		require(fake_getmem_log_event == 5);
		require(fake_getmem_log_addr == 3);
		mix_signed(digest, rc);

		nodemask[0] = 0x10;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0x3);
		rc = set_mempolicy_body_result(MPOL_BIND,
			(unsigned long)nodemask, 8, vm.bytes, 8, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -22);
		require(fake_getmem_log_event == 6);
		mix_signed(digest, rc);

		nodemask[0] = 0x5;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = set_mempolicy_body_result(MPOL_BIND,
			(unsigned long)nodemask, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == 0);
		require(*(unsigned long *)(vm.bytes + FAKE_PROCESS_VM_NUMA_MASK_OFF) == 0x5UL);
		require(*(int *)(vm.bytes + FAKE_PROCESS_VM_POLICY_OFF) == MPOL_BIND);
		mix(digest, *(unsigned long *)(vm.bytes + FAKE_PROCESS_VM_NUMA_MASK_OFF));

		nodemask[0] = 0x3;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		rc = set_mempolicy_body_result(MPOL_INTERLEAVE,
			(unsigned long)nodemask, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == 0);
		require(*(int *)(vm.bytes + FAKE_PROCESS_VM_IL_PREV_OFF) == 255);
		mix_signed(digest, *(int *)(vm.bytes + FAKE_PROCESS_VM_IL_PREV_OFF));

		nodemask[0] = 0x1;
		reset_getmem_trace();
		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0xf);
		fake_getmem_copy_fail_after = 0;
		rc = set_mempolicy_body_result(MPOL_BIND,
			(unsigned long)nodemask, 8, vm.bytes, 4, 321,
			fake_getmem_copy_from_user, fake_setmem_log);
		require(rc == -14);
		mix_signed(digest, rc);
	}

	{
		union {
			unsigned long align;
			unsigned char bytes[FAKE_PROCESS_VM_SIZE];
		} vm;
		union {
			unsigned long align;
			unsigned char bytes[FAKE_RANGE_POLICY_SIZE];
		} policy;
		unsigned char range_marker[8] = { 0 };
		unsigned long mask_out[4] = { 0, 0, 0, 0 };
		int mode_out = -1;
		long rc;

		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0x5a);
		reset_getmem_trace();
		rc = get_mempolicy_body_result((unsigned long)&mode_out,
			(unsigned long)mask_out, 8, 0x10000, 0, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		mix_signed(digest, rc);
		mix_signed(digest, fake_getmem_copy_calls);
		mix_signed(digest, mode_out);

		memset(mask_out, 0, sizeof(mask_out));
		mode_out = -1;
		reset_getmem_trace();
		rc = get_mempolicy_body_result((unsigned long)&mode_out,
			(unsigned long)mask_out, 8, 0, 0, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		require(rc == 0);
		require(mode_out == MPOL_BIND);
		require((mask_out[0] & 0xffUL) == 0x5aUL);
		mix_signed(digest, fake_getmem_copy_calls);
		mix(digest, fake_getmem_copy_bytes);
		mix(digest, mask_out[0]);

		fake_getmem_init_vm(vm.bytes, MPOL_DEFAULT, 0x77);
		memset(mask_out, 0xcc, sizeof(mask_out));
		mode_out = -1;
		reset_getmem_trace();
		rc = get_mempolicy_body_result((unsigned long)&mode_out,
			(unsigned long)mask_out, 8, 0, 0, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		require(rc == 0);
		require(mode_out == MPOL_DEFAULT);
		require(fake_getmem_copy_calls == 1);
		mix(digest, mask_out[0]);

		fake_getmem_init_vm(vm.bytes, MPOL_BIND, 0x1234);
		memset(mask_out, 0, sizeof(mask_out));
		reset_getmem_trace();
		rc = get_mempolicy_body_result(0, (unsigned long)mask_out, 257,
			0, MPOL_F_MEMS_ALLOWED, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		require(rc == 0);
		require(fake_getmem_log_calls == 1);
		require(fake_getmem_log_event == 1);
		require(fake_getmem_log_value == 256);
		require(fake_getmem_copy_bytes == 32);
		mix(digest, mask_out[0]);

		mode_out = -1;
		fake_getmem_lookup_node_result = 7;
		reset_getmem_trace();
		fake_getmem_lookup_node_result = 7;
		rc = get_mempolicy_body_result((unsigned long)&mode_out, 0, 8,
			0x50000, MPOL_F_ADDR | MPOL_F_NODE, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		require(rc == 0);
		require(mode_out == 7);
		require(fake_getmem_lookup_node_calls == 1);
		mix(digest, fake_getmem_lookup_node_addr);

		mode_out = -1;
		reset_getmem_trace();
		fake_getmem_lookup_node_result = 9;
		fake_getmem_copy_fail_after = 0;
		rc = get_mempolicy_body_result((unsigned long)&mode_out, 0, 8,
			0x60000, MPOL_F_ADDR | MPOL_F_NODE, vm.bytes, 4,
			fake_getmem_copy_to_user, fake_getmem_lookup_node,
			fake_getmem_read_lock, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		require(rc == -14);
		require(fake_getmem_lookup_node_calls == 1);
		mix_signed(digest, rc);

		reset_getmem_trace();
		rc = get_mempolicy_body_result(0, 0, 8, 0x70000,
			MPOL_F_ADDR, vm.bytes, 4, fake_getmem_copy_to_user,
			fake_getmem_lookup_node, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_getmem_log);
		require(rc == -14);
		require(fake_getmem_lock_calls == 1);
		require(fake_getmem_unlock_calls == 1);
		require(fake_getmem_log_event == 2);
		require(fake_getmem_last_lock ==
			(void *)(vm.bytes + FAKE_PROCESS_VM_LOCK_OFF));
		mix_signed(digest, fake_getmem_lookup_range_calls);
		mix(digest, fake_getmem_lookup_end);

		fake_getmem_lookup_range_result = range_marker;
		memset(mask_out, 0, sizeof(mask_out));
		mode_out = -1;
		reset_getmem_trace();
		fake_getmem_lookup_range_result = range_marker;
		rc = get_mempolicy_body_result((unsigned long)&mode_out,
			(unsigned long)mask_out, 8, 0x80000, MPOL_F_ADDR,
			vm.bytes, 4, fake_getmem_copy_to_user,
			fake_getmem_lookup_node, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_getmem_log);
		require(rc == 0);
		require(mode_out == MPOL_BIND);
		require(fake_getmem_policy_search_calls == 1);
		mix(digest, mask_out[0]);

		fake_getmem_init_range_policy(policy.bytes, MPOL_INTERLEAVE,
			0xa5);
		memset(mask_out, 0, sizeof(mask_out));
		mode_out = -1;
		reset_getmem_trace();
		fake_getmem_lookup_range_result = range_marker;
		fake_getmem_policy_search_result = policy.bytes;
		rc = get_mempolicy_body_result((unsigned long)&mode_out,
			(unsigned long)mask_out, 8, 0x90000, MPOL_F_ADDR,
			vm.bytes, 4, fake_getmem_copy_to_user,
			fake_getmem_lookup_node, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_getmem_log);
		require(rc == 0);
		require(mode_out == MPOL_INTERLEAVE);
		require((mask_out[0] & 0xffUL) == 0xa5UL);
		mix(digest, mask_out[0]);

		reset_getmem_trace();
		rc = get_mempolicy_body_result(0, 0, 8, 0xa0000,
			MPOL_F_ADDR, vm.bytes, 4, fake_getmem_copy_to_user,
			fake_getmem_lookup_node, NULL, fake_getmem_read_unlock,
			fake_getmem_lookup_range, fake_getmem_policy_search,
			fake_getmem_log);
		mix_signed(digest, rc);

		reset_getmem_trace();
		rc = get_mempolicy_body_result(0, 0, 8, 0, 0, vm.bytes, 4,
			NULL, fake_getmem_lookup_node, fake_getmem_read_lock,
			fake_getmem_read_unlock, fake_getmem_lookup_range,
			fake_getmem_policy_search, fake_getmem_log);
		mix_signed(digest, rc);
	}

	mix_signed(digest, move_pages_policy_result(0, 0));
	mix_signed(digest, move_pages_policy_result(1, 0));
	mix_signed(digest, move_pages_policy_result(0, MPOL_MF_MOVE));
	mix_signed(digest, move_pages_policy_result(0, MPOL_MF_MOVE_ALL));
	mix_signed(digest, move_pages_policy_result(0, 8));

	{
		struct fake_move_pages_smp_req req;
		const void *user_virt_addr[2] = { (void *)0x1000, (void *)0x2000 };
		int user_status[2] = { -1, -2 };
		const int user_nodes[2] = { 1, 2 };
		void *virt_addr[2] = { (void *)0x3000, (void *)0x4000 };
		int status[2] = { 3, 4 };
		void *ptep[2] = { (void *)0x5000, (void *)0x6000 };
		int nodes[2] = { 5, 6 };
		int nr_pages[2] = { 7, 8 };
		unsigned long dst_phys[2] = { 0x7000, 0x8000 };
		void *proc = (void *)0x9000;
		int rc;

		memset(&req, 0xa5, sizeof(req));
		rc = move_pages_smp_req_prepare_result(&req, 2,
			user_virt_addr, user_status, user_nodes, virt_addr,
			status, ptep, nodes, nr_pages, dst_phys, proc);
		require(rc == 0);
		require(req.count == 2);
		require(req.user_virt_addr == user_virt_addr);
		require(req.user_status == user_status);
		require(req.user_nodes == user_nodes);
		require(req.virt_addr == virt_addr);
		require(req.status == status);
		require(req.ptep == ptep);
		require(req.nodes == nodes);
		require(req.nodes_ready == 0);
		require(req.nr_pages == nr_pages);
		require(req.dst_phys == dst_phys);
		require(req.proc == proc);
		require(req.phase_done.counter == 0);
		require(req.phase_ret == 0);
		mix_signed(digest, rc);
		mix(digest, req.count);
		mix(digest, req.user_virt_addr == user_virt_addr);
		mix(digest, req.user_status == user_status);
		mix(digest, req.user_nodes == user_nodes);
		mix(digest, req.virt_addr == virt_addr);
		mix(digest, req.status == status);
		mix(digest, req.ptep == ptep);
		mix(digest, req.nodes == nodes);
		mix_signed(digest, req.nodes_ready);
		mix(digest, req.nr_pages == nr_pages);
		mix(digest, req.dst_phys == dst_phys);
		mix(digest, req.proc == proc);
		mix_signed(digest, req.phase_done.counter);
		mix_signed(digest, req.phase_ret);
		mix_signed(digest, move_pages_smp_req_prepare_result(NULL, 0,
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
			NULL));
	}

	{
		char vm, page_lock, cpu_set, proc;
		const void *user_virt_addr[2] = {
			(void *)0x1000, (void *)0x2000,
		};
		int user_nodes[2] = { 1, 3 };
		int user_status[2] = { -1, -2 };
		void *virt_addr[2] = { 0 };
		int nr_pages[2] = { 0 };
		int nodes[2] = { 0 };
		int status[2] = { 0 };
		void *ptep[2] = { 0 };
		unsigned long dst_phys[2] = { 0 };
		long rc;

		fake_move_pages_reset();
		fake_move_alloc_results[0] = virt_addr;
		fake_move_alloc_results[1] = nr_pages;
		fake_move_alloc_results[2] = nodes;
		fake_move_alloc_results[3] = status;
		fake_move_alloc_results[4] = ptep;
		fake_move_alloc_results[5] = dst_phys;
		rc = move_pages_body_result(0, 2,
			(unsigned long)user_virt_addr,
			(unsigned long)user_nodes,
			(unsigned long)user_status, MPOL_MF_MOVE,
			&vm, &page_lock, &cpu_set, &proc, 0x55,
			sizeof(void *), sizeof(int), sizeof(void *),
			sizeof(unsigned long), fake_move_verify,
			fake_move_copy_from, fake_move_copy_to,
			fake_move_alloc, fake_move_free,
			fake_move_nr_nodes, fake_move_lock,
			fake_move_unlock, fake_move_smp_call,
			fake_move_handler, fake_rdtsc, fake_move_log);
		require(rc == 0);
		require(fake_move_alloc_calls == 6);
		require(fake_move_alloc_sizes[0] == sizeof(void *) * 2);
		require(fake_move_alloc_sizes[1] == sizeof(int) * 2);
		require(fake_move_alloc_flags[5] == 0x55);
		require(fake_move_verify_calls == 3);
		require(fake_move_verify_addr[0] ==
			(unsigned long)user_virt_addr);
		require(fake_move_verify_addr[1] == (unsigned long)user_nodes);
		require(fake_move_verify_addr[2] == (unsigned long)user_status);
		require(fake_move_copy_from_calls == 1);
		require(nodes[0] == 1 && nodes[1] == 3);
		require(fake_move_lock_calls == 1);
		require(fake_move_unlock_calls == 1);
		require(fake_move_last_lock == &page_lock);
		require(fake_move_smp_calls == 1);
		require(fake_move_smp_cpu_set == &cpu_set);
		require(fake_move_smp_req != NULL);
		require(fake_move_copy_to_calls == 1);
		require(user_status[0] == 91 && user_status[1] == 92);
		require(fake_move_free_calls == 6);
		require(fake_move_log_calls == 3);
		require(fake_move_log_events[0] == MOVE_PAGES_LOG_INIT_MALLOC);
		require(fake_move_log_events[1] == MOVE_PAGES_LOG_INIT_VERIFY);
		require(fake_move_log_events[2] == MOVE_PAGES_LOG_PARALLEL);
		mix_signed(digest, rc);
		mix_signed(digest, fake_move_alloc_calls);
		mix_signed(digest, fake_move_verify_calls);
		mix_signed(digest, fake_move_smp_calls);
		mix_signed(digest, user_status[0]);

		fake_move_pages_reset();
		rc = move_pages_body_result(7, 2,
			(unsigned long)user_virt_addr, 0,
			(unsigned long)user_status, 0, &vm, &page_lock,
			&cpu_set, &proc, 0x55, sizeof(void *), sizeof(int),
			sizeof(void *), sizeof(unsigned long), fake_move_verify,
			fake_move_copy_from, fake_move_copy_to,
			fake_move_alloc, fake_move_free,
			fake_move_nr_nodes, fake_move_lock,
			fake_move_unlock, fake_move_smp_call,
			fake_move_handler, fake_rdtsc, fake_move_log);
		require(rc == -22);
		require(fake_move_alloc_calls == 0);
		require(fake_move_log_calls == 1);
		require(fake_move_log_events[0] ==
			MOVE_PAGES_LOG_UNSUPPORTED_PID);
		mix_signed(digest, rc);
		mix_signed(digest, fake_move_log_events[0]);

		fake_move_pages_reset();
		fake_move_alloc_results[0] = virt_addr;
		fake_move_alloc_results[1] = nr_pages;
		fake_move_alloc_results[2] = nodes;
		fake_move_alloc_fail_at = 3;
		rc = move_pages_body_result(0, 2,
			(unsigned long)user_virt_addr, 0,
			(unsigned long)user_status, 0, &vm, &page_lock,
			&cpu_set, &proc, 0x56, sizeof(void *), sizeof(int),
			sizeof(void *), sizeof(unsigned long), fake_move_verify,
			fake_move_copy_from, fake_move_copy_to,
			fake_move_alloc, fake_move_free,
			fake_move_nr_nodes, fake_move_lock,
			fake_move_unlock, fake_move_smp_call,
			fake_move_handler, fake_rdtsc, fake_move_log);
		require(rc == -12);
		require(fake_move_alloc_calls == 4);
		require(fake_move_free_calls == 6);
		require(fake_move_smp_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_move_free_calls);

		fake_move_pages_reset();
		user_nodes[0] = 9;
		fake_move_alloc_results[0] = virt_addr;
		fake_move_alloc_results[1] = nr_pages;
		fake_move_alloc_results[2] = nodes;
		fake_move_alloc_results[3] = status;
		fake_move_alloc_results[4] = ptep;
		fake_move_alloc_results[5] = dst_phys;
		rc = move_pages_body_result(0, 2,
			(unsigned long)user_virt_addr,
			(unsigned long)user_nodes,
			(unsigned long)user_status, 0, &vm, &page_lock,
			&cpu_set, &proc, 0x57, sizeof(void *), sizeof(int),
			sizeof(void *), sizeof(unsigned long), fake_move_verify,
			fake_move_copy_from, fake_move_copy_to,
			fake_move_alloc, fake_move_free,
			fake_move_nr_nodes, fake_move_lock,
			fake_move_unlock, fake_move_smp_call,
			fake_move_handler, fake_rdtsc, fake_move_log);
		require(rc == -19);
		require(fake_move_copy_from_calls == 1);
		require(fake_move_smp_calls == 0);
		require(fake_move_free_calls == 6);
		mix_signed(digest, rc);

		fake_move_pages_reset();
		user_nodes[0] = 1;
		user_status[0] = -1;
		user_status[1] = -2;
		fake_move_alloc_results[0] = virt_addr;
		fake_move_alloc_results[1] = nr_pages;
		fake_move_alloc_results[2] = nodes;
		fake_move_alloc_results[3] = status;
		fake_move_alloc_results[4] = ptep;
		fake_move_alloc_results[5] = dst_phys;
		fake_move_copy_to_rc = -1;
		rc = move_pages_body_result(0, 2,
			(unsigned long)user_virt_addr, 0,
			(unsigned long)user_status, 0, &vm, &page_lock,
			&cpu_set, &proc, 0x58, sizeof(void *), sizeof(int),
			sizeof(void *), sizeof(unsigned long), fake_move_verify,
			fake_move_copy_from, fake_move_copy_to,
			fake_move_alloc, fake_move_free,
			fake_move_nr_nodes, fake_move_lock,
			fake_move_unlock, fake_move_smp_call,
			fake_move_handler, fake_rdtsc, fake_move_log);
		require(rc == -14);
		require(fake_move_smp_calls == 1);
		require(fake_move_free_calls == 6);
		require(user_status[0] == -1 && user_status[1] == -2);
		mix_signed(digest, rc);
	}
}

static void exercise_brk_mincore_mmap_policy(unsigned long *digest)
{
	static const unsigned long brk_addrs[] = {
		0, 0x1000, 0x1fff, 0x2000, 0x3000, 0x4000, 0x4001,
	};
	static const struct range_case mincore_cases[] = {
		{ 0x10000UL, 0, 0x10000UL, 0x20000UL },
		{ 0x10000UL, PAGE_SIZE, 0x10000UL, 0x20000UL },
		{ 0x10001UL, PAGE_SIZE, 0x10000UL, 0x20000UL },
		{ 0x0UL, PAGE_SIZE, 0x10000UL, 0x20000UL },
		{ 0x1f000UL, PAGE_SIZE * 2, 0x10000UL, 0x20000UL },
		{ 0x10000UL, ULONG_MAX, 0x10000UL, 0x20000UL },
	};
	static const int prot_values[] = {
		0, PROT_READ, PROT_WRITE, PROT_EXEC,
		PROT_READ | PROT_WRITE,
		PROT_READ | PROT_EXEC,
		PROT_READ | PROT_WRITE | PROT_EXEC,
	};
	static const int mmap_flags[] = {
		0, MAP_SHARED, MAP_PRIVATE, MAP_PRIVATE | MAP_ANONYMOUS,
		MAP_PRIVATE | MAP_ANONYMOUS | MAP_LOCKED,
		MAP_PRIVATE | MAP_ANONYMOUS | MAP_POPULATE,
		MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
	};
	static const int maxprots[] = {
		0, PROT_READ, PROT_WRITE, PROT_EXEC,
		PROT_READ | PROT_WRITE,
		PROT_READ | PROT_EXEC,
		PROT_READ | PROT_WRITE | PROT_EXEC,
	};

	for (unsigned int i = 0; i < sizeof(brk_addrs) / sizeof(brk_addrs[0]); i++) {
		unsigned long result = 0xaaaa;
		int extend = -1;

		mix_signed(digest, brk_prepare_result(brk_addrs[i],
			0x1000, 0x2000, 0x4000, &result, &extend));
		mix(digest, result);
		mix_signed(digest, extend);
	}
	mix(digest, brk_default_vrflags());
	{
		struct fake_brk_region region = {
			.brk_start = 0x1000,
			.brk_end = 0x2000,
			.brk_end_allocated = 0x4000,
		};
		int fake_vm;
		int fake_lock;
		unsigned long rc;

		fake_brk_reset(0);
		rc = brk_body_result(&fake_vm, &region, &fake_lock, 0,
			7, offsetof(struct fake_brk_region, brk_start),
			offsetof(struct fake_brk_region, brk_end),
			offsetof(struct fake_brk_region, brk_end_allocated),
			fake_brk_flush, fake_brk_lock, fake_brk_unlock,
			fake_brk_extend, fake_brk_log);
		require(rc == 0x2000);
		require(region.brk_end == 0x2000);
		require(fake_brk_extend_calls == 0);
		mix(digest, fake_brk_digest);
		mix(digest, rc);

		region.brk_start = 0x1000;
		region.brk_end = 0x2000;
		region.brk_end_allocated = 0x4000;
		fake_brk_reset(0);
		rc = brk_body_result(&fake_vm, &region, &fake_lock, 0x3000,
			8, offsetof(struct fake_brk_region, brk_start),
			offsetof(struct fake_brk_region, brk_end),
			offsetof(struct fake_brk_region, brk_end_allocated),
			fake_brk_flush, fake_brk_lock, fake_brk_unlock,
			fake_brk_extend, fake_brk_log);
		require(rc == 0x3000);
		require(region.brk_end == 0x3000);
		require(fake_brk_extend_calls == 0);
		mix(digest, fake_brk_digest);
		mix(digest, region.brk_end);

		region.brk_start = 0x1000;
		region.brk_end = 0x2000;
		region.brk_end_allocated = 0x4000;
		fake_brk_reset(0x4000);
		rc = brk_body_result(&fake_vm, &region, &fake_lock, 0x5000,
			9, offsetof(struct fake_brk_region, brk_start),
			offsetof(struct fake_brk_region, brk_end),
			offsetof(struct fake_brk_region, brk_end_allocated),
			fake_brk_flush, fake_brk_lock, fake_brk_unlock,
			fake_brk_extend, fake_brk_log);
		require(rc == 0x4000);
		require(region.brk_end == 0x2000);
		require(fake_brk_lock_calls == 1);
		require(fake_brk_unlock_calls == 1);
		mix(digest, fake_brk_digest);
		mix(digest, fake_brk_extend_vrflag);

		region.brk_start = 0x1000;
		region.brk_end = 0x2000;
		region.brk_end_allocated = 0x4000;
		fake_brk_reset(0x6000);
		rc = brk_body_result(&fake_vm, &region, &fake_lock, 0x5000,
			10, offsetof(struct fake_brk_region, brk_start),
			offsetof(struct fake_brk_region, brk_end),
			offsetof(struct fake_brk_region, brk_end_allocated),
			fake_brk_flush, fake_brk_lock, fake_brk_unlock,
			fake_brk_extend, fake_brk_log);
		require(rc == 0x5000);
		require(region.brk_end == 0x5000);
		require(region.brk_end_allocated == 0x6000);
		require(fake_brk_extend_old == 0x4000);
		require(fake_brk_extend_address == 0x5000);
		mix(digest, fake_brk_digest);
		mix(digest, region.brk_end_allocated);
	}

	for (unsigned int i = 0; i < sizeof(mincore_cases) / sizeof(mincore_cases[0]); i++) {
		uintptr_t end = 0xbeef;

		mix_signed(digest, mincore_prepare_range(mincore_cases[i].start,
			mincore_cases[i].len, mincore_cases[i].user_start,
			mincore_cases[i].user_end, &end));
		mix(digest, end);
	}
	{
		int fake_vm;
		int fake_range_lock;
		int fake_pte_lock;
		int memobj_present = 1;
		struct fake_mincore_range ranges[2];
		long rc;

		ranges[0] = (struct fake_mincore_range) {
			.start = 0x10000UL,
			.end = 0x12000UL,
			.memobj = &memobj_present,
			.objoff = 0x3000,
		};
		fake_mincore_reset(ranges, 1);
		fake_mincore_pte_values[0] = 1;
		rc = mincore_body_result(&fake_vm, &fake_range_lock,
			&fake_pte_lock, (void *)0x10000UL, 0x10000UL,
			0x2000UL, 0, 0x10000UL, 0x20000UL,
			offsetof(struct fake_mincore_range, start),
			offsetof(struct fake_mincore_range, end),
			offsetof(struct fake_mincore_range, memobj),
			offsetof(struct fake_mincore_range, objoff),
			fake_mincore_range_lock, fake_mincore_range_unlock,
			fake_mincore_pte_lock, fake_mincore_pte_unlock,
			fake_mincore_lookup, fake_mincore_pte_lookup,
			fake_mincore_pte_present, fake_mincore_memobj_lookup,
			fake_mincore_copy_byte, fake_mincore_log);
		require(rc == 0);
		require(fake_mincore_vec[0] == 1);
		require(fake_mincore_vec[1] == 1);
		require(fake_mincore_lookup_calls == 2);
		require(fake_mincore_pte_lookup_calls == 2);
		require(fake_mincore_pte_present_calls == 1);
		require(fake_mincore_memobj_lookup_calls == 1);
		require(fake_mincore_copy_calls == 2);
		require(fake_mincore_range_lock_calls == 2);
		require(fake_mincore_range_unlock_calls == 2);
		require(fake_mincore_pte_lock_calls == 2);
		require(fake_mincore_pte_unlock_calls == 2);
		mix(digest, fake_mincore_digest);

		ranges[0].memobj = NULL;
		fake_mincore_reset(ranges, 1);
		rc = mincore_body_result(&fake_vm, &fake_range_lock,
			&fake_pte_lock, (void *)0x10000UL, 0x10000UL,
			PAGE_SIZE, 0, 0x10000UL, 0x20000UL,
			offsetof(struct fake_mincore_range, start),
			offsetof(struct fake_mincore_range, end),
			offsetof(struct fake_mincore_range, memobj),
			offsetof(struct fake_mincore_range, objoff),
			fake_mincore_range_lock, fake_mincore_range_unlock,
			fake_mincore_pte_lock, fake_mincore_pte_unlock,
			fake_mincore_lookup, fake_mincore_pte_lookup,
			fake_mincore_pte_present, fake_mincore_memobj_lookup,
			fake_mincore_copy_byte, fake_mincore_log);
		require(rc == 0);
		require(fake_mincore_vec[0] == 0);
		require(fake_mincore_memobj_lookup_calls == 0);
		mix(digest, fake_mincore_digest);

		fake_mincore_reset(ranges, 0);
		rc = mincore_body_result(&fake_vm, &fake_range_lock,
			&fake_pte_lock, (void *)0x10000UL, 0x10000UL,
			PAGE_SIZE, 0, 0x10000UL, 0x20000UL,
			offsetof(struct fake_mincore_range, start),
			offsetof(struct fake_mincore_range, end),
			offsetof(struct fake_mincore_range, memobj),
			offsetof(struct fake_mincore_range, objoff),
			fake_mincore_range_lock, fake_mincore_range_unlock,
			fake_mincore_pte_lock, fake_mincore_pte_unlock,
			fake_mincore_lookup, fake_mincore_pte_lookup,
			fake_mincore_pte_present, fake_mincore_memobj_lookup,
			fake_mincore_copy_byte, fake_mincore_log);
		require(rc == -12);
		require(fake_mincore_range_lock_calls == 1);
		require(fake_mincore_range_unlock_calls == 1);
		require(fake_mincore_pte_lock_calls == 0);
		require(fake_mincore_copy_calls == 0);
		mix(digest, fake_mincore_digest);

		ranges[0].memobj = &memobj_present;
		fake_mincore_reset(ranges, 1);
		fake_mincore_copy_fail_at = 1;
		rc = mincore_body_result(&fake_vm, &fake_range_lock,
			&fake_pte_lock, (void *)0x10000UL, 0x10000UL,
			PAGE_SIZE, 0, 0x10000UL, 0x20000UL,
			offsetof(struct fake_mincore_range, start),
			offsetof(struct fake_mincore_range, end),
			offsetof(struct fake_mincore_range, memobj),
			offsetof(struct fake_mincore_range, objoff),
			fake_mincore_range_lock, fake_mincore_range_unlock,
			fake_mincore_pte_lock, fake_mincore_pte_unlock,
			fake_mincore_lookup, fake_mincore_pte_lookup,
			fake_mincore_pte_present, fake_mincore_memobj_lookup,
			fake_mincore_copy_byte, fake_mincore_log);
		require(rc == -14);
		require(fake_mincore_range_unlock_calls == 1);
		require(fake_mincore_pte_unlock_calls == 1);
		require(fake_mincore_copy_calls == 1);
		mix(digest, fake_mincore_digest);
	}

	for (unsigned int p = 0; p < sizeof(prot_values) / sizeof(prot_values[0]); p++) {
		for (unsigned int f = 0; f < sizeof(mmap_flags) / sizeof(mmap_flags[0]); f++) {
			mix(digest, mmap_base_vrflags(prot_values[p], mmap_flags[f],
				VR_REMOTE, 0));
			mix(digest, mmap_base_vrflags(prot_values[p], mmap_flags[f],
				VR_REMOTE, 1));
			mix_signed(digest, mmap_populated_mapping_result(mmap_flags[f]));
			mix_signed(digest, mmap_should_set_host_ro(mmap_flags[f],
				prot_values[p], 0));
			mix_signed(digest, mmap_should_set_host_ro(mmap_flags[f],
				prot_values[p], 1));
			mix_signed(digest, mmap_is_shared(mmap_flags[f]));
		}
	}

	for (unsigned int f = 0; f < sizeof(mmap_flags) / sizeof(mmap_flags[0]); f++) {
		for (unsigned int m = 0; m < sizeof(maxprots) / sizeof(maxprots[0]); m++) {
			mix_signed(digest, mmap_update_private_maxprot(mmap_flags[f],
				maxprots[m]));
			mix(digest, mmap_maxprot_to_vrflags(maxprots[m]));
			for (unsigned int p = 0; p < sizeof(prot_values) / sizeof(prot_values[0]); p++) {
				int denied = 0x55;

				mix_signed(digest, mmap_prot_denied_result(prot_values[p],
					maxprots[m], &denied));
				mix_signed(digest, denied);
			}
		}
	}

	mix_signed(digest, mmap_should_force_straight(MAP_PRIVATE | MAP_ANONYMOUS,
		1, 0x10000, 0x4000, 0x2000));
	mix_signed(digest, mmap_should_force_straight(MAP_PRIVATE | MAP_ANONYMOUS,
		1, 0, 0x4000, 0x2000));
	mix_signed(digest, mmap_should_force_straight(MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
		1, 0x10000, 0x4000, 0x2000));
	mix_signed(digest, mmap_should_force_straight(MAP_PRIVATE | MAP_ANONYMOUS,
		1, 0x10000, 0x1000, 0x2000));
	mix_signed(digest, mmap_should_force_straight(MAP_PRIVATE | MAP_ANONYMOUS,
		0, 0x10000, 0x4000, 0x2000));
}

static void exercise_signal_time_policy(unsigned long *digest)
{
	static const int tids[] = { INT_MIN, -1, 0, 1, 99 };
	static const size_t sigset_sizes[] = { 0, sizeof(unsigned long),
		sizeof(unsigned long) + 1 };
	static const int hows[] = { -1, SIG_BLOCK, SIG_UNBLOCK, SIG_SETMASK, 3 };
	static const unsigned long masks[] = {
		0, 1, SIGKILL_MASK, SIGSTOP_MASK,
		SIGKILL_MASK | SIGSTOP_MASK | 0x55UL,
	};
	static const int signalfd_flags[] = {
		0, SFD_NONBLOCK, SFD_CLOEXEC, SFD_NONBLOCK | SFD_CLOEXEC,
		0x10, SFD_NONBLOCK | 0x10,
	};
	static const int who_values[] = {
		RUSAGE_CHILDREN, RUSAGE_SELF, RUSAGE_THREAD, -2, 2,
	};
	static const int statuses[] = {
		0, PS_RUNNING, PS_ZOMBIE, PS_EXITED, PS_STOPPED,
	};
	static const long rss_values[] = {
		-2048, -1, 0, 1, 1023, 1024, 4096, 123456789,
	};
	static const unsigned long tsc_values[] = {
		0, 1, 999, 1000, 123456789, ULONG_MAX / 8,
	};
	static const unsigned long clocks_per_sec_values[] = {
		0, 1, 10, 1000000, 2500000000UL,
	};
	static const int exit_codes[] = {
		-1, 0, 1, 9, 0x7f, 0x80, 0x8b, 0x0100, 0xff00,
	};
	static const unsigned long group_statuses[] = {
		0, 1, 0xff00, EXIT_GROUP_STATUS_CONFIRMED,
		EXIT_GROUP_STATUS_CONFIRMED | 0x8b,
	};
	static const int itimers[] = {
		-1, ITIMER_REAL, ITIMER_VIRTUAL, ITIMER_PROF, 3,
	};
	static const long timeval_pairs[][2] = {
		{ 0, 0 }, { 1, 0 }, { 0, 1 }, { -1, 0 },
	};
	static const int clock_ids[] = {
		-1, CLOCK_REALTIME, CLOCK_PROCESS_CPUTIME_ID,
		CLOCK_THREAD_CPUTIME_ID, 11,
	};
	static const int bools[] = { 0, 1 };
	static const long timespecs[][2] = {
		{ 0, 0 },
		{ 1, 999999999L },
		{ 1, NS_PER_SEC },
		{ -1, 0 },
		{ 0, -1 },
	};

	for (unsigned int g = 0; g < sizeof(tids) / sizeof(tids[0]); g++) {
		for (unsigned int t = 0; t < sizeof(tids) / sizeof(tids[0]); t++)
			mix_signed(digest, tgkill_target_result(tids[g], tids[t]));
	}

	for (unsigned int s = 0; s < sizeof(sigset_sizes) / sizeof(sigset_sizes[0]); s++) {
		for (unsigned int h = 0; h < sizeof(hows) / sizeof(hows[0]); h++) {
			mix_signed(digest, rt_sigprocmask_validate(sigset_sizes[s],
				sizeof(unsigned long), 0, hows[h]));
			mix_signed(digest, rt_sigprocmask_validate(sigset_sizes[s],
				sizeof(unsigned long), 1, hows[h]));
		}
		mix_signed(digest, rt_sigpending_size_result(sigset_sizes[s],
			sizeof(unsigned long)));
		mix_signed(digest, signalfd4_sigsetsize_result(sigset_sizes[s],
			sizeof(unsigned long)));
	}

	for (unsigned int m = 0; m < sizeof(masks) / sizeof(masks[0]); m++) {
		for (unsigned int s = 0; s < sizeof(masks) / sizeof(masks[0]); s++) {
			for (unsigned int h = 0; h < sizeof(hows) / sizeof(hows[0]); h++) {
				mix(digest, rt_sigprocmask_apply(masks[m], masks[s],
					0, hows[h]));
				mix(digest, rt_sigprocmask_apply(masks[m], masks[s],
					1, hows[h]));
			}
		}
	}

	for (unsigned int f = 0; f < sizeof(signalfd_flags) / sizeof(signalfd_flags[0]); f++)
		mix_signed(digest, signalfd4_flags_result(signalfd_flags[f]));
	mix_signed(digest, set_robust_list_body_result(24));
	mix_signed(digest, set_robust_list_body_result(23));
	mix_signed(digest, signalfd_body_result());

	{
		struct fake_sigmask_thread thread = {
			.prefix = 0x11,
			.sigmask = 0x1111,
			.suffix = 0x22,
		};
		unsigned long user_mask = 0x2222;
		unsigned long pending_out = 0;
		unsigned long pselect_mask = 0x3333;
		unsigned long pselect_ptr = (unsigned long)&pselect_mask;
		unsigned long sfd_mask = 0x4444;
		char fake_ctx;
		long rc;

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		fake_forward_context_calls = 0;
		fake_forward_context_nr = 0;
		fake_forward_context_ctx = NULL;
		fake_forward_context_seen_mask = 0;
		fake_forward_context_rc = 77;
		fake_forward_context_thread = &thread;
		rc = syscall_temp_sigmask_body_result((unsigned long)&user_mask,
			&thread, offsetof(struct fake_sigmask_thread, sigmask),
			281, &fake_ctx, fake_copy_stack_from_user,
			fake_forward_context);
		require(rc == 77);
		require(fake_forward_context_calls == 1);
		require(fake_forward_context_nr == 281);
		require(fake_forward_context_ctx == &fake_ctx);
		require(fake_forward_context_seen_mask == user_mask);
		require(thread.sigmask == 0x1111);
		mix_signed(digest, rc);
		mix(digest, fake_forward_context_seen_mask);
		mix_signed(digest, fake_stack_copy_from_calls);

		fake_stack_copy_from_calls = 0;
		fake_forward_context_calls = 0;
		fake_forward_context_seen_mask = 0;
		fake_forward_context_rc = -9;
		rc = pselect6_sigmask_body_result((unsigned long)&pselect_ptr,
			&thread, offsetof(struct fake_sigmask_thread, sigmask),
			270, &fake_ctx, fake_copy_stack_from_user,
			fake_forward_context);
		require(rc == -9);
		require(fake_stack_copy_from_calls == 2);
		require(fake_forward_context_calls == 1);
		require(fake_forward_context_seen_mask == pselect_mask);
		require(thread.sigmask == 0x1111);
		mix_signed(digest, rc);
		mix(digest, fake_forward_context_seen_mask);
		mix_signed(digest, fake_stack_copy_from_calls);

		fake_pending_mask_calls = 0;
		fake_pending_mask_thread = NULL;
		fake_pending_mask_value = 0x55aa;
		fake_stack_copy_to_calls = 0;
		rc = rt_sigpending_body_result((unsigned long)&pending_out,
			sizeof(unsigned long), sizeof(unsigned long), &thread,
			fake_pending_mask, fake_copy_stack_to_user);
		require(rc == 0);
		require(fake_pending_mask_calls == 1);
		require(fake_pending_mask_thread == &thread);
		require(pending_out == 0x55aa);
		require(fake_stack_copy_to_calls == 1);
		mix(digest, pending_out);
		mix_signed(digest, fake_pending_mask_calls);

		fake_stack_copy_from_calls = 0;
		fake_signalfd_create_calls = 0;
		fake_signalfd_create_rc = 44;
		fake_signalfd_publish_calls = 0;
		fake_signalfd_publish_rc = 0;
		rc = signalfd4_body_result(-1, (unsigned long)&sfd_mask,
			sizeof(unsigned long), sizeof(unsigned long),
			SFD_NONBLOCK, &thread, 289, fake_copy_stack_from_user,
			fake_signalfd_create, fake_signalfd_publish);
		require(rc == 44);
		require(fake_signalfd_create_calls == 1);
		require(fake_signalfd_create_nr == 289);
		require(fake_signalfd_create_flags == SFD_NONBLOCK);
		require(fake_signalfd_publish_calls == 1);
		require(fake_signalfd_publish_thread == &thread);
		require(fake_signalfd_publish_fd == 44);
		require(fake_signalfd_publish_mask == sfd_mask);
		require(fake_signalfd_publish_create == 1);
		mix_signed(digest, rc);
		mix(digest, fake_signalfd_publish_mask);
		mix_signed(digest, fake_signalfd_publish_create);

		sfd_mask = 0x7777;
		fake_stack_copy_from_calls = 0;
		fake_signalfd_create_calls = 0;
		fake_signalfd_publish_calls = 0;
		fake_signalfd_publish_rc = -22;
		rc = signalfd4_body_result(12, (unsigned long)&sfd_mask,
			sizeof(unsigned long), sizeof(unsigned long), 0,
			&thread, 289, fake_copy_stack_from_user,
			fake_signalfd_create, fake_signalfd_publish);
		require(rc == -22);
		require(fake_signalfd_create_calls == 0);
		require(fake_signalfd_publish_calls == 1);
		require(fake_signalfd_publish_fd == 12);
		require(fake_signalfd_publish_mask == sfd_mask);
		require(fake_signalfd_publish_create == 0);
		mix_signed(digest, rc);
		mix(digest, fake_signalfd_publish_mask);
		mix_signed(digest, fake_signalfd_publish_create);

		fake_sigsuspend_calls = 0;
		fake_sigsuspend_thread = NULL;
		fake_sigsuspend_set = NULL;
		fake_sigsuspend_rc = -4;
		rc = pause_body_result(&thread,
			offsetof(struct fake_sigmask_thread, sigmask),
			fake_sigsuspend);
		require(rc == -4);
		require(fake_sigsuspend_calls == 1);
		require(fake_sigsuspend_thread == &thread);
		require(fake_sigsuspend_set == &thread.sigmask);
		mix_signed(digest, rc);
		mix_signed(digest, fake_sigsuspend_calls);

		rc = pause_body_result(NULL,
			offsetof(struct fake_sigmask_thread, sigmask),
			fake_sigsuspend);
		require(rc == -22);
		mix_signed(digest, rc);
		rc = pause_body_result(&thread,
			offsetof(struct fake_sigmask_thread, sigmask), NULL);
		require(rc == -14);
		mix_signed(digest, rc);

		{
			unsigned long suspend_mask = 0x5555;
			unsigned long scratch = 0;

			fake_stack_copy_from_fail = 0;
			fake_stack_copy_from_calls = 0;
			fake_sigsuspend_calls = 0;
			fake_sigsuspend_rc = -5;
			rc = rt_sigsuspend_body_result(&thread,
				(unsigned long)&suspend_mask, sizeof(unsigned long),
				sizeof(unsigned long), &scratch,
				fake_copy_stack_from_user, fake_sigsuspend);
			require(rc == -5);
			require(scratch == suspend_mask);
			require(fake_stack_copy_from_calls == 1);
			require(fake_sigsuspend_calls == 1);
			require(fake_sigsuspend_thread == &thread);
			require(fake_sigsuspend_set == &scratch);
			mix_signed(digest, rc);
			mix(digest, scratch);
			mix_signed(digest, fake_stack_copy_from_calls);

			fake_stack_copy_from_fail = 1;
			fake_stack_copy_from_calls = 0;
			fake_sigsuspend_calls = 0;
			scratch = 0;
			rc = rt_sigsuspend_body_result(&thread,
				(unsigned long)&suspend_mask, sizeof(unsigned long),
				sizeof(unsigned long), &scratch,
				fake_copy_stack_from_user, fake_sigsuspend);
			require(rc == -14);
			require(fake_stack_copy_from_calls == 1);
			require(fake_sigsuspend_calls == 0);
			mix_signed(digest, rc);
			mix_signed(digest, fake_stack_copy_from_calls);

			fake_stack_copy_from_fail = 0;
			fake_stack_copy_from_calls = 0;
			rc = rt_sigsuspend_body_result(&thread,
				(unsigned long)&suspend_mask,
				sizeof(unsigned long) + 1, sizeof(unsigned long),
				&scratch, fake_copy_stack_from_user,
				fake_sigsuspend);
			require(rc == -22);
			require(fake_stack_copy_from_calls == 0);
			mix_signed(digest, rc);

			rc = rt_sigsuspend_body_result(&thread, 0,
				sizeof(unsigned long), sizeof(unsigned long),
				&scratch, fake_copy_stack_from_user,
				fake_sigsuspend);
			require(rc == -14);
			require(fake_stack_copy_from_calls == 0);
			mix_signed(digest, rc);
		}
	}

	for (unsigned int w = 0; w < sizeof(who_values) / sizeof(who_values[0]); w++) {
		mix_signed(digest, getrusage_who_result(who_values[w]));
		mix_signed(digest, getrusage_dispatch_result(who_values[w]));
	}
	for (unsigned int c = 0; c < sizeof(bools) / sizeof(bools[0]); c++) {
		for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++) {
			for (unsigned int k = 0; k < sizeof(bools) / sizeof(bools[0]); k++)
				mix_signed(digest, getrusage_thread_update_action_result(
					bools[c], statuses[s], bools[k]));
		}
	}
	{
		struct fake_getrusage_thread fake = {
			.pad = 0x1234,
			.times_update = 77,
		};
		int action = getrusage_thread_update_action_result(0,
			PS_RUNNING, 0);

		require(getrusage_thread_times_update_prepare_result(
			(unsigned long)&fake,
			offsetof(struct fake_getrusage_thread, times_update),
			action) == 1);
		require(fake.times_update == 0);
		mix_signed(digest, fake.times_update);

		action = getrusage_thread_update_action_result(1,
			PS_RUNNING, 0);
		require(getrusage_thread_times_update_prepare_result(
			(unsigned long)&fake,
			offsetof(struct fake_getrusage_thread, times_update),
			action) == 0);
		require(fake.times_update == 1);
		mix_signed(digest, fake.times_update);
		require(getrusage_thread_times_update_prepare_result(0,
			offsetof(struct fake_getrusage_thread, times_update),
			action) == 0);
	}
	for (unsigned int r = 0; r < sizeof(rss_values) / sizeof(rss_values[0]); r++)
		mix_signed(digest, getrusage_maxrss_kb_result(rss_values[r]));
	for (unsigned int c = 0;
	     c < sizeof(clocks_per_sec_values) / sizeof(clocks_per_sec_values[0]);
	     c++) {
		for (unsigned int t = 0;
		     t < sizeof(tsc_values) / sizeof(tsc_values[0]); t++) {
			struct rusage usage;
			long sec = 1;
			long nsec = 999999999;

			memset(&usage, 0xa5, sizeof(usage));
			getrusage_timespec_add_tsc_result(&sec, &nsec,
				tsc_values[t], clocks_per_sec_values[c]);
			mix_signed(digest, sec);
			mix_signed(digest, nsec);
			getrusage_fill_timespec_result(&usage, sec, nsec,
				sec + 2, nsec / 2, rss_values[t % (sizeof(rss_values) /
					sizeof(rss_values[0]))]);
			mix_signed(digest, usage.ru_utime.tv_sec);
			mix_signed(digest, usage.ru_utime.tv_usec);
			mix_signed(digest, usage.ru_stime.tv_sec);
			mix_signed(digest, usage.ru_stime.tv_usec);
			mix_signed(digest, usage.ru_maxrss);
		}
	}
	for (unsigned int e = 0; e < sizeof(exit_codes) / sizeof(exit_codes[0]); e++) {
		mix_signed(digest, exit_code_status_result(exit_codes[e]));
		mix_signed(digest, exit_code_signal_result(exit_codes[e]));
		mix_signed(digest, exit_syscall_code_result(exit_codes[e]));
		mix_signed(digest, sigchld_code_result(exit_codes[e]));
		for (unsigned int p = 0; p < sizeof(bools) / sizeof(bools[0]); p++)
			mix_signed(digest, thread_exit_signal_result(
				bools[p], exit_codes[e]));
	}
	for (unsigned int g = 0; g < sizeof(group_statuses) / sizeof(group_statuses[0]); g++)
		mix_signed(digest, exit_group_status_claimed_result(
			group_statuses[g]));
	for (unsigned int rc = 0; rc < sizeof(exit_codes) / sizeof(exit_codes[0]); rc++) {
		for (unsigned int sig = 0; sig < sizeof(exit_codes) / sizeof(exit_codes[0]); sig++)
			mix(digest, exit_group_status_result(exit_codes[rc],
				exit_codes[sig]));
	}
	{
		struct fake_sched_yield_cpu cpu;
		long rc;

		fake_exit_calls = 0;
		fake_exit_code = -1;
		rc = exit_body_result(7, fake_exit_do_exit);
		require(rc == 0);
		require(fake_exit_calls == 1);
		require(fake_exit_code == ((7 & 255) << 8));
		mix_signed(digest, fake_exit_calls);
		mix_signed(digest, fake_exit_code);

		fake_exit_group_log_calls = 0;
		fake_exit_group_log_pid = -1;
		fake_terminate_calls = 0;
		fake_terminate_status = -1;
		fake_terminate_group = -1;
		rc = exit_group_body_result(9, 1234, fake_exit_group_log,
			fake_terminate);
		require(rc == 0);
		require(fake_exit_group_log_calls == 1);
		require(fake_exit_group_log_pid == 1234);
		require(fake_terminate_calls == 1);
		require(fake_terminate_status == 9);
		require(fake_terminate_group == 0);
		mix_signed(digest, fake_exit_group_log_pid);
		mix_signed(digest, fake_terminate_status);

		cpu.runq_lock = 1;
		cpu.runq_len = 1;
		cpu.flags = 0;
		fake_sched_yield_lock_calls = 0;
		fake_sched_yield_unlock_calls = 0;
		fake_sched_yield_schedule_calls = 0;
		fake_sched_yield_irqstate = 0x55;
		rc = sched_yield_body_result(&cpu,
			offsetof(struct fake_sched_yield_cpu, flags),
			offsetof(struct fake_sched_yield_cpu, runq_len),
			offsetof(struct fake_sched_yield_cpu, runq_lock),
			0x1U, fake_sched_yield_lock,
			fake_sched_yield_unlock, fake_sched_yield_schedule);
		require(rc == 0);
		require(fake_sched_yield_lock_calls == 1);
		require(fake_sched_yield_unlock_calls == 1);
		require(fake_sched_yield_schedule_calls == 0);
		require(cpu.flags == 0);
		mix_signed(digest, fake_sched_yield_schedule_calls);

		cpu.runq_len = 2;
		cpu.flags = 0x81U;
		fake_sched_yield_lock_calls = 0;
		fake_sched_yield_unlock_calls = 0;
		fake_sched_yield_schedule_calls = 0;
		rc = sched_yield_body_result(&cpu,
			offsetof(struct fake_sched_yield_cpu, flags),
			offsetof(struct fake_sched_yield_cpu, runq_len),
			offsetof(struct fake_sched_yield_cpu, runq_lock),
			0x1U, fake_sched_yield_lock,
			fake_sched_yield_unlock, fake_sched_yield_schedule);
		require(rc == 0);
		require(fake_sched_yield_schedule_calls == 1);
		require(cpu.flags == 0x80U);
		mix_signed(digest, fake_sched_yield_schedule_calls);
		mix(digest, cpu.flags);
	}
	for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++)
		mix_signed(digest, terminate_thread_active_result(statuses[s]));
	require(thread_exit_signal_report_needed_result(NULL) == 0);
	require(thread_exit_signal_report_needed_result(&digest) == 1);
	{
		struct fake_thread_exit_process report_proc = {
			.pid = 4321,
			.waitpid_q = 0x55,
		};
		struct fake_thread_exit_thread thread = {
			.report_proc = &report_proc,
			.ptrace = 0,
			.termsig = 9,
			.exit_status = 0x8b,
			.tid = 2468,
			.user_tsc = 12345,
			.system_tsc = 2001,
		};
		long rc;

		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = -33;
		fake_do_kill_thread_si_signo = -1;
		fake_do_kill_thread_si_code = -1;
		fake_do_kill_thread_si_pid = -1;
		fake_do_kill_thread_si_status = -1;
		fake_do_kill_thread_si_utime = -1;
		fake_do_kill_thread_si_stime = -1;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_wake_waitq = NULL;
		fake_thread_exit_log_calls = 0;
		fake_thread_exit_log_sig = -1;
		fake_thread_exit_log_error = 0;
		fake_times_tsc_calls = 0;
		fake_times_jiffy_calls = 0;
		rc = thread_exit_signal_body_result(&thread,
			offsetof(struct fake_thread_exit_thread, report_proc),
			offsetof(struct fake_thread_exit_thread, ptrace),
			offsetof(struct fake_thread_exit_thread, termsig),
			offsetof(struct fake_thread_exit_thread, exit_status),
			offsetof(struct fake_thread_exit_thread, tid),
			offsetof(struct fake_thread_exit_thread, user_tsc),
			offsetof(struct fake_thread_exit_thread, system_tsc),
			offsetof(struct fake_thread_exit_process, pid),
			offsetof(struct fake_thread_exit_process, waitpid_q),
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_do_kill_thread, fake_thread_exit_wake,
			fake_thread_exit_log);
		require(rc == -33);
		require(fake_do_kill_thread_calls == 1);
		require(fake_do_kill_thread_current == NULL);
		require(fake_do_kill_thread_pid == 4321);
		require(fake_do_kill_thread_tid == -1);
		require(fake_do_kill_thread_sig == 9);
		require(fake_do_kill_thread_ptracecont == 0);
		require(fake_do_kill_thread_si_signo == 9);
		require(fake_do_kill_thread_si_code ==
			sigchld_code_result(thread.exit_status));
		require(fake_do_kill_thread_si_pid == 2468);
		require(fake_do_kill_thread_si_status == 0x8b);
		require(fake_do_kill_thread_si_utime == 1234);
		require(fake_do_kill_thread_si_stime == 200);
		require(fake_thread_exit_wake_calls == 1);
		require(fake_thread_exit_wake_waitq == &report_proc.waitpid_q);
		require(fake_thread_exit_log_calls == 1);
		require(fake_thread_exit_log_sig == 9);
		require(fake_thread_exit_log_error == -33);
		require(fake_times_tsc_calls == 2);
		require(fake_times_jiffy_calls == 2);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_kill_thread_calls);
		mix_signed(digest, fake_do_kill_thread_pid);
		mix_signed(digest, fake_do_kill_thread_sig);
		mix_signed(digest, fake_do_kill_thread_si_code);
		mix_signed(digest, fake_do_kill_thread_si_pid);
		mix_signed(digest, fake_do_kill_thread_si_status);
		mix_signed(digest, fake_do_kill_thread_si_utime);
		mix_signed(digest, fake_do_kill_thread_si_stime);
		mix_signed(digest, fake_thread_exit_wake_calls);
		mix_signed(digest, fake_thread_exit_log_calls);
		mix_signed(digest, fake_times_tsc_calls);
		mix_signed(digest, fake_times_jiffy_calls);

		thread.ptrace = 1;
		thread.termsig = 11;
		thread.exit_status = 0;
		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = 44;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_log_calls = 0;
		rc = thread_exit_signal_body_result(&thread,
			offsetof(struct fake_thread_exit_thread, report_proc),
			offsetof(struct fake_thread_exit_thread, ptrace),
			offsetof(struct fake_thread_exit_thread, termsig),
			offsetof(struct fake_thread_exit_thread, exit_status),
			offsetof(struct fake_thread_exit_thread, tid),
			offsetof(struct fake_thread_exit_thread, user_tsc),
			offsetof(struct fake_thread_exit_thread, system_tsc),
			offsetof(struct fake_thread_exit_process, pid),
			offsetof(struct fake_thread_exit_process, waitpid_q),
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_do_kill_thread, fake_thread_exit_wake,
			fake_thread_exit_log);
		require(rc == 44);
		require(fake_do_kill_thread_calls == 1);
		require(fake_do_kill_thread_sig == SIGCHLD);
		require(fake_do_kill_thread_si_code ==
			sigchld_code_result(thread.exit_status));
		require(fake_thread_exit_wake_calls == 1);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_kill_thread_sig);
		mix_signed(digest, fake_do_kill_thread_si_code);

		thread.report_proc = NULL;
		fake_do_kill_thread_calls = 0;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_log_calls = 0;
		rc = thread_exit_signal_body_result(&thread,
			offsetof(struct fake_thread_exit_thread, report_proc),
			offsetof(struct fake_thread_exit_thread, ptrace),
			offsetof(struct fake_thread_exit_thread, termsig),
			offsetof(struct fake_thread_exit_thread, exit_status),
			offsetof(struct fake_thread_exit_thread, tid),
			offsetof(struct fake_thread_exit_thread, user_tsc),
			offsetof(struct fake_thread_exit_thread, system_tsc),
			offsetof(struct fake_thread_exit_process, pid),
			offsetof(struct fake_thread_exit_process, waitpid_q),
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_do_kill_thread, fake_thread_exit_wake,
			fake_thread_exit_log);
		require(rc == 0);
		require(fake_do_kill_thread_calls == 0);
		require(fake_thread_exit_wake_calls == 0);
		require(fake_thread_exit_log_calls == 0);
		mix_signed(digest, rc);

		rc = thread_exit_signal_body_result(NULL,
			offsetof(struct fake_thread_exit_thread, report_proc),
			offsetof(struct fake_thread_exit_thread, ptrace),
			offsetof(struct fake_thread_exit_thread, termsig),
			offsetof(struct fake_thread_exit_thread, exit_status),
			offsetof(struct fake_thread_exit_thread, tid),
			offsetof(struct fake_thread_exit_thread, user_tsc),
			offsetof(struct fake_thread_exit_thread, system_tsc),
			offsetof(struct fake_thread_exit_process, pid),
			offsetof(struct fake_thread_exit_process, waitpid_q),
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_do_kill_thread, fake_thread_exit_wake,
			fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		thread.report_proc = &report_proc;
		rc = thread_exit_signal_body_result(&thread,
			offsetof(struct fake_thread_exit_thread, report_proc),
			offsetof(struct fake_thread_exit_thread, ptrace),
			offsetof(struct fake_thread_exit_thread, termsig),
			offsetof(struct fake_thread_exit_thread, exit_status),
			offsetof(struct fake_thread_exit_thread, tid),
			offsetof(struct fake_thread_exit_thread, user_tsc),
			offsetof(struct fake_thread_exit_thread, system_tsc),
			offsetof(struct fake_thread_exit_process, pid),
			offsetof(struct fake_thread_exit_process, waitpid_q),
			NULL, fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_finalize_process parent = {
			.parent = NULL,
			.pid = 777,
			.waitpid_q = 0x66,
		};
		struct fake_finalize_process child = {
			.parent = &parent,
			.pid = 888,
			.group_exit_status = 0x85,
			.termsig = SIGCHLD,
			.utime = { .tv_sec = 3, .tv_nsec = 40000000 },
			.stime = { .tv_sec = 5, .tv_nsec = 60000000 },
			.waitpid_q = 0,
		};
		struct fake_finalize_process pid1 = {
			.pid = 1,
		};
		int lock_node = 0x12345678;
		long rc;

		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = -12;
		fake_do_kill_thread_si_signo = -1;
		fake_do_kill_thread_si_code = -1;
		fake_do_kill_thread_si_pid = -1;
		fake_do_kill_thread_si_status = -1;
		fake_do_kill_thread_si_utime = -1;
		fake_do_kill_thread_si_stime = -1;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_wake_waitq = NULL;
		fake_thread_exit_log_calls = 0;
		fake_thread_exit_log_sig = -1;
		fake_thread_exit_log_error = 0;
		fake_times_jiffy_calls = 0;
		rc = finalize_process_parent_notify_body_result(&child,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -12);
		require(fake_do_kill_thread_calls == 1);
		require(fake_do_kill_thread_current == NULL);
		require(fake_do_kill_thread_pid == parent.pid);
		require(fake_do_kill_thread_tid == -1);
		require(fake_do_kill_thread_sig == SIGCHLD);
		require(fake_do_kill_thread_ptracecont == 0);
		require(fake_do_kill_thread_si_signo == SIGCHLD);
		require(fake_do_kill_thread_si_code ==
			sigchld_code_result(child.group_exit_status));
		require(fake_do_kill_thread_si_pid == child.pid);
		require(fake_do_kill_thread_si_status == child.group_exit_status);
		require(fake_do_kill_thread_si_utime == 304);
		require(fake_do_kill_thread_si_stime == 506);
		require(fake_thread_exit_wake_calls == 1);
		require(fake_thread_exit_wake_waitq == &parent.waitpid_q);
		require(fake_thread_exit_log_calls == 1);
		require(fake_thread_exit_log_sig == SIGCHLD);
		require(fake_thread_exit_log_error == -12);
		require(fake_times_jiffy_calls == 2);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_kill_thread_calls);
		mix_signed(digest, fake_do_kill_thread_pid);
		mix_signed(digest, fake_do_kill_thread_sig);
		mix_signed(digest, fake_do_kill_thread_si_code);
		mix_signed(digest, fake_do_kill_thread_si_pid);
		mix_signed(digest, fake_do_kill_thread_si_status);
		mix_signed(digest, fake_do_kill_thread_si_utime);
		mix_signed(digest, fake_do_kill_thread_si_stime);
		mix_signed(digest, fake_thread_exit_wake_calls);
		mix_signed(digest, fake_thread_exit_log_calls);
		mix_signed(digest, fake_times_jiffy_calls);

		child.termsig = 0;
		fake_do_kill_thread_calls = 0;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_log_calls = 0;
		fake_times_jiffy_calls = 0;
		rc = finalize_process_parent_notify_body_result(&child,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == 0);
		require(fake_do_kill_thread_calls == 0);
		require(fake_thread_exit_wake_calls == 1);
		require(fake_thread_exit_wake_waitq == &parent.waitpid_q);
		require(fake_thread_exit_log_calls == 0);
		require(fake_times_jiffy_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_thread_exit_wake_calls);

		child.parent = NULL;
		rc = finalize_process_parent_notify_body_result(&child,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		child.parent = &parent;
		rc = finalize_process_parent_notify_body_result(NULL,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		child.termsig = SIGCHLD;
		rc = finalize_process_parent_notify_body_result(&child,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			NULL, fake_do_kill_thread, fake_thread_exit_wake,
			fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		child.parent = &parent;
		child.status = PS_RUNNING;
		child.termsig = SIGCHLD;
		fake_finalize_lock_calls = 0;
		fake_finalize_lock_ptr = NULL;
		fake_finalize_lock_node = NULL;
		fake_finalize_unlock_calls = 0;
		fake_finalize_unlock_ptr = NULL;
		fake_finalize_unlock_node = NULL;
		fake_finalize_release_calls = 0;
		fake_finalize_release_proc = NULL;
		fake_finalize_wakeup_log_calls = 0;
		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = -19;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_log_calls = 0;
		fake_times_jiffy_calls = 0;
		rc = finalize_process_body_result(&child, &pid1, &lock_node,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, status),
			offsetof(struct fake_finalize_process, update_lock),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_finalize_lock, fake_finalize_unlock,
			fake_finalize_release, fake_finalize_wakeup_log,
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -19);
		require(child.status == PS_ZOMBIE);
		require(fake_finalize_lock_calls == 1);
		require(fake_finalize_lock_ptr == &child.update_lock);
		require(fake_finalize_lock_node == &lock_node);
		require(fake_finalize_unlock_calls == 1);
		require(fake_finalize_unlock_ptr == &child.update_lock);
		require(fake_finalize_unlock_node == &lock_node);
		require(fake_finalize_release_calls == 0);
		require(fake_finalize_wakeup_log_calls == 1);
		require(fake_do_kill_thread_calls == 1);
		require(fake_thread_exit_wake_calls == 1);
		require(fake_thread_exit_log_calls == 1);
		require(fake_times_jiffy_calls == 2);
		mix_signed(digest, rc);
		mix_signed(digest, child.status);
		mix_signed(digest, fake_finalize_lock_calls);
		mix_signed(digest, fake_finalize_unlock_calls);
		mix_signed(digest, fake_finalize_release_calls);
		mix_signed(digest, fake_finalize_wakeup_log_calls);
		mix_signed(digest, fake_do_kill_thread_calls);
		mix_signed(digest, fake_thread_exit_wake_calls);
		mix_signed(digest, fake_thread_exit_log_calls);

		child.parent = &parent;
		child.status = PS_RUNNING;
		child.termsig = SIGCHLD;
		fake_finalize_lock_calls = 0;
		fake_finalize_unlock_calls = 0;
		fake_finalize_release_calls = 0;
		fake_finalize_release_proc = NULL;
		fake_finalize_wakeup_log_calls = 0;
		fake_do_kill_thread_calls = 0;
		fake_thread_exit_wake_calls = 0;
		fake_thread_exit_log_calls = 0;
		rc = finalize_process_body_result(&child, &parent, &lock_node,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, status),
			offsetof(struct fake_finalize_process, update_lock),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_finalize_lock, fake_finalize_unlock,
			fake_finalize_release, fake_finalize_wakeup_log,
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == 0);
		require(child.status == PS_ZOMBIE);
		require(fake_finalize_lock_calls == 1);
		require(fake_finalize_unlock_calls == 1);
		require(fake_finalize_release_calls == 1);
		require(fake_finalize_release_proc == &child);
		require(fake_finalize_wakeup_log_calls == 0);
		require(fake_do_kill_thread_calls == 0);
		require(fake_thread_exit_wake_calls == 0);
		require(fake_thread_exit_log_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_finalize_release_calls);

		child.status = PS_RUNNING;
		rc = finalize_process_body_result(NULL, &parent, &lock_node,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, status),
			offsetof(struct fake_finalize_process, update_lock),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_finalize_lock, fake_finalize_unlock,
			fake_finalize_release, fake_finalize_wakeup_log,
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = finalize_process_body_result(&child, &parent, NULL,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, status),
			offsetof(struct fake_finalize_process, update_lock),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			fake_finalize_lock, fake_finalize_unlock,
			fake_finalize_release, fake_finalize_wakeup_log,
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		mix_signed(digest, rc);

		child.status = PS_RUNNING;
		rc = finalize_process_body_result(&child, &parent, &lock_node,
			offsetof(struct fake_finalize_process, parent),
			offsetof(struct fake_finalize_process, status),
			offsetof(struct fake_finalize_process, update_lock),
			offsetof(struct fake_finalize_process, pid),
			offsetof(struct fake_finalize_process, group_exit_status),
			offsetof(struct fake_finalize_process, termsig),
			offsetof(struct fake_finalize_process, utime),
			offsetof(struct fake_finalize_process, stime),
			offsetof(struct fake_finalize_process, waitpid_q),
			NULL, fake_finalize_unlock,
			fake_finalize_release, fake_finalize_wakeup_log,
			fake_timespec_to_jiffy, fake_do_kill_thread,
			fake_thread_exit_wake, fake_thread_exit_log);
		require(rc == -22);
		require(child.status == PS_RUNNING);
		mix_signed(digest, rc);
	}
	require(terminate_group_status_update_failed_result(0x1234, 0x1234) == 0);
	require(terminate_group_status_update_failed_result(0x1235, 0x1234) == 1);
	require(terminate_host_exit_needed_result(0) == 1);
	require(terminate_host_exit_needed_result(1) == 0);
	require(terminate_host_exit_needed_result(-1) == 0);
	{
		struct fake_terminate_mcexec_process proc = {
			.group_exit_status = 0,
			.nohost = 0,
		};
		struct fake_syscall_request req = {
			.rtid = 11,
			.ttid = 22,
			.valid = 33,
			.number = 44,
			.args = { 55, 66, 77, 88, 99, 111 },
		};
		unsigned long expected_status = exit_group_status_result(7, 9);
		long rc;

		fake_terminate_cmpxchg_calls = 0;
		fake_terminate_cmpxchg_ptr = NULL;
		fake_terminate_cmpxchg_old = 0;
		fake_terminate_cmpxchg_new = 0;
		fake_terminate_cmpxchg_force_mismatch = 0;
		fake_terminate_syscall_calls = 0;
		fake_terminate_syscall_req = NULL;
		fake_terminate_syscall_cpu = -1;
		fake_terminate_syscall_rc = -55;
		rc = terminate_mcexec_body_result(&proc, &req, 7, 9, 3, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == -55);
		require(fake_terminate_cmpxchg_calls == 1);
		require(fake_terminate_cmpxchg_ptr == &proc.group_exit_status);
		require(fake_terminate_cmpxchg_old == 0);
		require(fake_terminate_cmpxchg_new == expected_status);
		require(proc.group_exit_status == expected_status);
		require(proc.nohost == 1);
		require(fake_terminate_syscall_calls == 1);
		require(fake_terminate_syscall_req == &req);
		require(fake_terminate_syscall_cpu == 3);
		require(req.number == 231);
		require(req.args[0] == expected_status);
		require(req.args[1] == 66);
		mix_signed(digest, rc);
		mix(digest, proc.group_exit_status);
		mix_signed(digest, proc.nohost);
		mix_signed(digest, fake_terminate_cmpxchg_calls);
		mix_signed(digest, fake_terminate_syscall_calls);
		mix(digest, req.number);
		mix(digest, req.args[0]);

		proc.group_exit_status = EXIT_GROUP_STATUS_CONFIRMED | 0x1234;
		proc.nohost = 0;
		req.number = 44;
		req.args[0] = 55;
		fake_terminate_cmpxchg_calls = 0;
		fake_terminate_syscall_calls = 0;
		rc = terminate_mcexec_body_result(&proc, &req, 1, 2, 4, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == 0);
		require(fake_terminate_cmpxchg_calls == 0);
		require(fake_terminate_syscall_calls == 0);
		require(proc.nohost == 0);
		require(req.number == 44);
		require(req.args[0] == 55);
		mix_signed(digest, rc);
		mix_signed(digest, fake_terminate_cmpxchg_calls);

		proc.group_exit_status = 0xabc;
		proc.nohost = 0;
		req.number = 44;
		req.args[0] = 55;
		fake_terminate_cmpxchg_calls = 0;
		fake_terminate_syscall_calls = 0;
		fake_terminate_cmpxchg_force_mismatch = 1;
		fake_terminate_cmpxchg_mismatch_value = 0xabd;
		rc = terminate_mcexec_body_result(&proc, &req, 3, 4, 5, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == 0);
		require(fake_terminate_cmpxchg_calls == 1);
		require(fake_terminate_syscall_calls == 0);
		require(proc.group_exit_status == 0xabc);
		require(proc.nohost == 0);
		require(req.number == 44);
		require(req.args[0] == 55);
		mix_signed(digest, rc);
		mix(digest, proc.group_exit_status);
		fake_terminate_cmpxchg_force_mismatch = 0;

		proc.group_exit_status = 0;
		proc.nohost = 1;
		fake_terminate_cmpxchg_calls = 0;
		fake_terminate_syscall_calls = 0;
		rc = terminate_mcexec_body_result(&proc, &req, 5, 6, 7, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == 0);
		require(fake_terminate_cmpxchg_calls == 1);
		require(fake_terminate_syscall_calls == 0);
		require(proc.group_exit_status == exit_group_status_result(5, 6));
		require(proc.nohost == 1);
		mix_signed(digest, rc);
		mix(digest, proc.group_exit_status);

		proc.group_exit_status = 0;
		proc.nohost = 0;
		rc = terminate_mcexec_body_result(NULL, &req, 1, 2, 3, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = terminate_mcexec_body_result(&proc, NULL, 1, 2, 3, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, fake_terminate_syscall);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = terminate_mcexec_body_result(&proc, &req, 1, 2, 3, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			NULL, fake_terminate_syscall);
		require(rc == -22);
		mix_signed(digest, rc);

		proc.group_exit_status = 0;
		proc.nohost = 0;
		rc = terminate_mcexec_body_result(&proc, &req, 1, 2, 3, 231,
			offsetof(struct fake_terminate_mcexec_process,
				 group_exit_status),
			offsetof(struct fake_terminate_mcexec_process, nohost),
			fake_terminate_cmpxchg, NULL);
		require(rc == -22);
		require(proc.group_exit_status == exit_group_status_result(1, 2));
		require(proc.nohost == 0);
		mix_signed(digest, rc);
	}
	require(sync_child_event_needed_result(0, 1, 0) == 0);
	require(sync_child_event_needed_result(1, 0, 0) == 0);
	require(sync_child_event_needed_result(1, 1, 0) == 1);
	require(sync_child_event_needed_result(1, 0, 7) == 1);
	require(sync_child_event_needed_result(1, 0, -1) == 1);
	require(sync_child_event_pid_action_result(0) == 1);
	require(sync_child_event_pid_action_result(7) == 2);
	require(sync_child_event_pid_action_result(-1) == 0);
	{
		struct fake_sync_child_event leader = {
			.inherit = 1,
			.counter_id = 3,
			.child_count_total = 10,
			.group_leader = NULL,
			.pid = 0,
		};
		struct fake_sync_child_event sub1 = {
			.counter_id = 5,
			.child_count_total = 20,
			.pid = 0,
		};
		struct fake_sync_child_event sub2 = {
			.counter_id = 7,
			.child_count_total = 30,
			.pid = 0,
		};
		long rc;

		leader.group_leader = &leader;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&sub1.group_entry);
		fake_wait_scan_list_init(&sub2.group_entry);
		fake_wait_scan_list_add_tail(&sub1.group_entry,
			&leader.sibling_list);
		fake_wait_scan_list_add_tail(&sub2.group_entry,
			&leader.sibling_list);

		fake_sync_child_reset(100);
		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == 0);
		require(leader.child_count_total == 113);
		require(sub1.child_count_total == 125);
		require(sub2.child_count_total == 137);
		require(fake_sync_child_read_calls == 3);
		require(fake_sync_child_read_counter_sum == 15);
		require(fake_sync_child_set_calls == 0);
		mix_signed(digest, rc);
		mix(digest, leader.child_count_total);
		mix(digest, sub1.child_count_total);
		mix(digest, sub2.child_count_total);
		mix_signed(digest, fake_sync_child_read_calls);

		leader.pid = 44;
		leader.child_count_total = 113;
		sub1.child_count_total = 125;
		sub2.child_count_total = 137;
		fake_sync_child_reset(200);
		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == 0);
		require(leader.count.counter64 == 203);
		require(sub1.count.counter64 == 205);
		require(sub2.count.counter64 == 207);
		require(leader.child_count_total == 113);
		require(sub1.child_count_total == 125);
		require(sub2.child_count_total == 137);
		require(fake_sync_child_read_calls == 3);
		require(fake_sync_child_set_calls == 3);
		require(fake_sync_child_set_last_ptr == &sub2.count);
		require(fake_sync_child_set_last_value == 207);
		mix_signed(digest, rc);
		mix_signed(digest, leader.count.counter64);
		mix_signed(digest, sub1.count.counter64);
		mix_signed(digest, sub2.count.counter64);
		mix_signed(digest, fake_sync_child_set_calls);

		leader.inherit = 0;
		leader.pid = 0;
		fake_sync_child_reset(300);
		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == 0);
		require(fake_sync_child_read_calls == 0);
		mix_signed(digest, rc);

		leader.inherit = 1;
		leader.pid = -1;
		fake_sync_child_reset(400);
		rc = sync_child_event_body_result(&leader, leader.inherit,
			77,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == 0);
		require(fake_sync_child_read_calls == 0);
		mix_signed(digest, rc);

		leader.pid = 44;
		fake_sync_child_reset(500);
		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, NULL);
		require(rc == -22);
		require(fake_sync_child_read_calls == 0);
		mix_signed(digest, rc);

		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			NULL, fake_sync_child_count_set);
		require(rc == -22);
		mix_signed(digest, rc);

		leader.group_leader = NULL;
		rc = sync_child_event_body_result(&leader, leader.inherit,
			leader.pid,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = sync_child_event_body_result(NULL, 1, 0,
			offsetof(struct fake_sync_child_event, group_leader),
			offsetof(struct fake_sync_child_event, pid),
			offsetof(struct fake_sync_child_event, counter_id),
			offsetof(struct fake_sync_child_event, count),
			offsetof(struct fake_sync_child_event,
				 child_count_total),
			offsetof(struct fake_sync_child_event, sibling_list),
			offsetof(struct fake_sync_child_event, group_entry),
			fake_sync_child_perf_read, fake_sync_child_count_set);
		require(rc == 0);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_thread thread = {
			.system_tsc = 2000,
			.user_tsc = 1000,
		};
		struct fake_perf_read_event event = {
			.pid = 0,
			.use_invariant_tsc = 1,
			.count = { .counter64 = 10 },
			.child_count_total = 5,
			.base_user_tsc = 100,
			.user_accum_count = 7,
			.base_system_tsc = 200,
			.system_accum_count = 11,
		};
		unsigned long count;

		fake_perf_read_reset();
		count = perf_event_read_value_body_result(&event, &thread,
			0, 0, 1,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 2733);
		require(fake_perf_read_update_calls == 0);
		require(fake_perf_read_atomic_read_calls == 1);
		require(fake_perf_read_atomic_read_ptr == &event.count);
		mix(digest, count);
		mix_signed(digest, fake_perf_read_atomic_read_calls);

		event.count.counter64 = 20;
		event.child_count_total = 9;
		event.stopped_system_tsc = 5000;
		event.base_system_tsc = 4500;
		event.system_accum_count = 3;
		fake_perf_read_reset();
		count = perf_event_read_value_body_result(&event, &thread,
			1, 0, 0,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 523);
		require(fake_perf_read_update_calls == 0);
		mix(digest, count);

		event.pid = 0;
		event.use_invariant_tsc = 0;
		event.count.counter64 = 10;
		event.child_count_total = 5;
		fake_perf_read_reset();
		count = perf_event_read_value_body_result(&event, &thread,
			0, 0, 1,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 48);
		require(fake_perf_read_update_calls == 1);
		require(fake_perf_read_update_event == &event);
		mix(digest, count);
		mix_signed(digest, fake_perf_read_update_calls);

		event.pid = 8;
		event.count.counter64 = 77;
		event.child_count_total = 6;
		fake_perf_read_reset();
		count = perf_event_read_value_body_result(&event, &thread,
			0, 0, 1,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 83);
		require(fake_perf_read_update_calls == 0);
		mix(digest, count);

		count = perf_event_read_value_body_result(NULL, &thread,
			0, 0, 1,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 0);
		mix(digest, count);

		count = perf_event_read_value_body_result(&event, &thread,
			0, 0, 1,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_update, NULL);
		require(count == 0);
		mix(digest, count);
	}
	{
		struct fake_perf_read_thread thread = {
			.system_tsc = 2000,
			.user_tsc = 1000,
		};
		struct fake_perf_read_event event = {
			.pid = 0,
			.attr = {
				.exclude_user = 0,
				.exclude_kernel = 1,
				.inherit = 1,
			},
			.use_invariant_tsc = 1,
			.count = { .counter64 = 10 },
			.child_count_total = 5,
			.base_user_tsc = 100,
			.user_accum_count = 7,
			.base_system_tsc = 200,
			.system_accum_count = 11,
		};
		unsigned long count;

		fake_perf_read_reset();
		count = perf_event_read_value_entry_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_attr_flags, fake_perf_read_update,
			fake_perf_read_atomic_read);
		require(count == 922);
		require(fake_perf_read_attr_calls == 1);
		require(fake_perf_read_attr_ptr == &event.attr);
		require(fake_perf_read_update_calls == 0);
		require(fake_perf_read_atomic_read_calls == 1);
		require(fake_perf_read_atomic_read_ptr == &event.count);
		mix(digest, count);
		mix_signed(digest, fake_perf_read_attr_calls);

		event.use_invariant_tsc = 0;
		event.count.counter64 = 10;
		event.child_count_total = 5;
		fake_perf_read_reset();
		count = perf_event_read_value_entry_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_attr_flags, fake_perf_read_update,
			fake_perf_read_atomic_read);
		require(count == 48);
		require(fake_perf_read_attr_calls == 1);
		require(fake_perf_read_update_calls == 1);
		require(fake_perf_read_update_event == &event);
		require(fake_perf_read_atomic_read_calls == 1);
		mix(digest, count);
		mix_signed(digest, fake_perf_read_update_calls);

		fake_perf_read_reset();
		fake_perf_read_attr_rc = -7;
		count = perf_event_read_value_entry_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_read_attr_flags, fake_perf_read_update,
			fake_perf_read_atomic_read);
		require(count == 0);
		require(fake_perf_read_attr_calls == 1);
		require(fake_perf_read_update_calls == 0);
		require(fake_perf_read_atomic_read_calls == 0);
		mix(digest, count);

		fake_perf_read_reset();
		count = perf_event_read_value_entry_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_event,
				 child_count_total),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 user_accum_count),
			offsetof(struct fake_perf_read_event,
				 base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			NULL, fake_perf_read_update, fake_perf_read_atomic_read);
		require(count == 0);
		require(fake_perf_read_attr_calls == 0);
		require(fake_perf_read_update_calls == 0);
		require(fake_perf_read_atomic_read_calls == 0);
		mix(digest, count);
	}
	{
		struct fake_perf_read_event event = {
			.count = { .counter64 = 0xabcUL },
		};
		unsigned long out[4] = { 0 };
		long rc;

		fake_perf_read_reset();
		fake_perf_read_copy_base = (unsigned long)out;
		rc = perf_event_read_one_body_result(&event,
			(unsigned long)out, fake_perf_read_value,
			fake_perf_read_copy_to_user);
		require(rc == (long)sizeof(unsigned long));
		require(out[0] == 0xabcUL);
		require(fake_perf_read_value_calls == 1);
		require(fake_perf_read_value_last_event == &event);
		require(fake_perf_read_copy_calls == 1);
		require(fake_perf_read_copy_last_bytes ==
			sizeof(unsigned long));
		require(fake_perf_read_copy_last_offset == 0);
		mix_signed(digest, rc);
		mix(digest, out[0]);
		mix_signed(digest, fake_perf_read_copy_calls);

		out[0] = 0;
		fake_perf_read_reset();
		fake_perf_read_copy_base = (unsigned long)out;
		fake_perf_read_copy_fail_call = 1;
		rc = perf_event_read_one_body_result(&event,
			(unsigned long)out, fake_perf_read_value,
			fake_perf_read_copy_to_user);
		require(rc == -14);
		require(out[0] == 0);
		require(fake_perf_read_value_calls == 1);
		require(fake_perf_read_copy_calls == 1);
		mix_signed(digest, rc);

		rc = perf_event_read_one_body_result(NULL, (unsigned long)out,
			fake_perf_read_value, fake_perf_read_copy_to_user);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_event_read_one_body_result(&event, (unsigned long)out,
			NULL, fake_perf_read_copy_to_user);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_event leader = {
			.count = { .counter64 = 10 },
			.nr_siblings = 2,
		};
		struct fake_perf_read_event sub1 = {
			.count = { .counter64 = 20 },
		};
		struct fake_perf_read_event sub2 = {
			.count = { .counter64 = 30 },
		};
		unsigned long out[6] = { 0 };
		long rc;

		leader.group_leader = &leader;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&sub1.group_entry);
		fake_wait_scan_list_init(&sub2.group_entry);
		fake_wait_scan_list_add_tail(&sub1.group_entry,
			&leader.sibling_list);
		fake_wait_scan_list_add_tail(&sub2.group_entry,
			&leader.sibling_list);

		fake_perf_read_reset();
		fake_perf_read_copy_base = (unsigned long)out;
		rc = perf_event_read_group_body_result(&leader,
			(unsigned long)out,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			fake_perf_read_value, fake_perf_read_copy_to_user);
		require(rc == (long)(4 * sizeof(unsigned long)));
		require(out[0] == 3);
		require(out[1] == 10);
		require(out[2] == 20);
		require(out[3] == 30);
		require(fake_perf_read_value_calls == 3);
		require(fake_perf_read_value_last_event == &sub2);
		require(fake_perf_read_copy_calls == 3);
		require(fake_perf_read_copy_last_bytes ==
			sizeof(unsigned long));
		require(fake_perf_read_copy_last_offset ==
			3 * sizeof(unsigned long));
		mix_signed(digest, rc);
		mix(digest, out[0]);
		mix(digest, out[1]);
		mix(digest, out[2]);
		mix(digest, out[3]);
		mix_signed(digest, fake_perf_read_copy_calls);

		memset(out, 0, sizeof(out));
		fake_perf_read_reset();
		fake_perf_read_copy_base = (unsigned long)out;
		fake_perf_read_copy_fail_call = 2;
		rc = perf_event_read_group_body_result(&leader,
			(unsigned long)out,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			fake_perf_read_value, fake_perf_read_copy_to_user);
		require(rc == -14);
		require(out[0] == 3);
		require(out[1] == 10);
		require(out[2] == 0);
		require(fake_perf_read_value_calls == 2);
		require(fake_perf_read_copy_calls == 2);
		mix_signed(digest, rc);

		leader.group_leader = NULL;
		rc = perf_event_read_group_body_result(&leader,
			(unsigned long)out,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			fake_perf_read_value, fake_perf_read_copy_to_user);
		require(rc == -22);
		mix_signed(digest, rc);

		leader.group_leader = &leader;
		rc = perf_event_read_group_body_result(&leader,
			(unsigned long)out,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			fake_perf_read_value, NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_event event = {
			.count = { .counter64 = 44 },
		};
		unsigned long buf = 0x12345000UL;
		unsigned long group_flag = 0x8UL;
		long rc;

		fake_perf_read_reset();
		fake_perf_read_group_dispatch_rc = 123;
		rc = perf_read_body_result(&event, buf, group_flag | 0x20,
			group_flag, fake_perf_read_group_dispatch,
			fake_perf_read_one_dispatch);
		require(rc == 123);
		require(fake_perf_read_group_dispatch_calls == 1);
		require(fake_perf_read_one_dispatch_calls == 0);
		require(fake_perf_read_dispatch_event == &event);
		require(fake_perf_read_dispatch_format == (group_flag | 0x20));
		require(fake_perf_read_dispatch_buf == buf);
		mix_signed(digest, rc);
		mix(digest, fake_perf_read_dispatch_format);

		fake_perf_read_reset();
		fake_perf_read_one_dispatch_rc = 77;
		rc = perf_read_body_result(&event, buf + 8, 0x20,
			group_flag, fake_perf_read_group_dispatch,
			fake_perf_read_one_dispatch);
		require(rc == 77);
		require(fake_perf_read_group_dispatch_calls == 0);
		require(fake_perf_read_one_dispatch_calls == 1);
		require(fake_perf_read_dispatch_event == &event);
		require(fake_perf_read_dispatch_format == 0x20);
		require(fake_perf_read_dispatch_buf == buf + 8);
		mix_signed(digest, rc);
		mix(digest, fake_perf_read_dispatch_buf);

		rc = perf_read_body_result(NULL, buf, 0, group_flag,
			fake_perf_read_group_dispatch,
			fake_perf_read_one_dispatch);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_read_body_result(&event, buf, group_flag, group_flag,
			NULL, fake_perf_read_one_dispatch);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_read_body_result(&event, buf, 0, group_flag,
			fake_perf_read_group_dispatch, NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_event event = {
			.counter_id = 3,
			.extra_reg = 0,
		};
		long rc;

		fake_perf_read_reset();
		rc = perf_counter_set_body_result(&event, 0, 0,
			event.counter_id, 0xabcUL,
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == 0);
		require(fake_perf_counter_extra_calls == 0);
		require(fake_perf_counter_init_calls == 1);
		require(fake_perf_counter_init_counter == 3);
		require(fake_perf_counter_init_config == 0xabcUL);
		require(fake_perf_counter_init_mode == 0x3);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_counter_init_mode);

		event.extra_reg = 7;
		fake_perf_read_reset();
		fake_perf_counter_extra_rc = -9;
		rc = perf_counter_set_body_result(&event, 1, 0,
			event.counter_id, 0x55UL,
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == -1);
		require(fake_perf_counter_extra_calls == 1);
		require(fake_perf_counter_extra_event == &event);
		require(fake_perf_counter_init_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_counter_extra_calls);

		event.extra_reg = 0;
		rc = perf_counter_set_body_result(&event, 0, 0,
			event.counter_id, 0,
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_extra_set, NULL);
		require(rc == -22);
		mix_signed(digest, rc);

		event.counter_id = 6;
		event.hw_config = 0x1234UL;
		event.extra_reg = 0;
		event.attr.exclude_kernel = 0;
		event.attr.exclude_user = 1;
		fake_perf_read_reset();
		rc = perf_counter_set_entry_body_result(&event,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, hw_config),
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_attr_flags,
			fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == 0);
		require(fake_perf_counter_attr_calls == 1);
		require(fake_perf_counter_attr_ptr == &event.attr);
		require(fake_perf_counter_extra_calls == 0);
		require(fake_perf_counter_init_calls == 1);
		require(fake_perf_counter_init_counter == 6);
		require(fake_perf_counter_init_config == 0x1234UL);
		require(fake_perf_counter_init_mode == 0x2);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_counter_attr_calls);
		mix_signed(digest, fake_perf_counter_init_mode);

		event.extra_reg = 7;
		event.attr.exclude_kernel = 1;
		event.attr.exclude_user = 0;
		fake_perf_read_reset();
		rc = perf_counter_set_entry_body_result(&event,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, hw_config),
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_attr_flags,
			fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == 0);
		require(fake_perf_counter_attr_calls == 1);
		require(fake_perf_counter_extra_calls == 1);
		require(fake_perf_counter_extra_event == &event);
		require(fake_perf_counter_init_mode == 0x1);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_counter_extra_calls);
		mix_signed(digest, fake_perf_counter_init_mode);

		fake_perf_read_reset();
		fake_perf_counter_attr_rc = -7;
		rc = perf_counter_set_entry_body_result(&event,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, hw_config),
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, fake_perf_counter_attr_flags,
			fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == -7);
		require(fake_perf_counter_attr_calls == 1);
		require(fake_perf_counter_extra_calls == 0);
		require(fake_perf_counter_init_calls == 0);
		mix_signed(digest, rc);

		fake_perf_read_reset();
		rc = perf_counter_set_entry_body_result(&event,
			offsetof(struct fake_perf_read_event, attr),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, hw_config),
			offsetof(struct fake_perf_read_event, extra_reg),
			0x2, 0x1, NULL, fake_perf_counter_extra_set,
			fake_perf_counter_init_raw);
		require(rc == -22);
		require(fake_perf_counter_attr_calls == 0);
		require(fake_perf_counter_init_calls == 0);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_start_process proc = { 0 };
		struct fake_perf_read_thread thread = {
			.proc = &proc,
			.system_tsc = 2000,
			.user_tsc = 1000,
		};
		struct fake_perf_read_event leader = {
			.counter_id = 1,
			.state = 0,
			.use_invariant_tsc = 1,
			.base_user_tsc = 700,
			.stopped_user_tsc = 900,
			.user_accum_count = 10,
			.base_system_tsc = 1000,
			.stopped_system_tsc = 1500,
			.system_accum_count = 20,
		};
		struct fake_perf_read_event sub = {
			.counter_id = 2,
			.state = 0,
			.use_invariant_tsc = 0,
		};
		long rc;

		leader.group_leader = &leader;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&sub.group_entry);
		fake_wait_scan_list_add_tail(&sub.group_entry,
			&leader.sibling_list);

		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = (1UL << 1) | (1UL << 2);
		rc = perf_start_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process, perf_status),
			0, 1, 2, fake_perf_start_mask_check,
			fake_perf_start_set_period,
			fake_perf_start_counter_set,
			fake_perf_start_hw_start);
		require(rc == 0);
		require(leader.state == 1);
		require(leader.base_user_tsc == 1000);
		require(leader.stopped_user_tsc == 0);
		require(leader.user_accum_count == 210);
		require(leader.base_system_tsc == 2000);
		require(leader.stopped_system_tsc == 0);
		require(leader.system_accum_count == 520);
		require(sub.state == 1);
		require(fake_perf_start_set_period_calls == 1);
		require(fake_perf_start_set_period_event == &sub);
		require(fake_perf_start_counter_set_calls == 1);
		require(fake_perf_start_counter_set_event == &sub);
		require(fake_perf_start_hw_start_calls == 1);
		require(fake_perf_start_hw_start_mask == (1UL << 2));
		require(proc.perf_status == 2);
		mix_signed(digest, rc);
		mix_signed(digest, leader.user_accum_count);
		mix_signed(digest, leader.system_accum_count);
		mix(digest, fake_perf_start_hw_start_mask);
		mix_signed(digest, proc.perf_status);

		leader.state = 1;
		sub.state = 0;
		proc.perf_status = 0;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = 0;
		rc = perf_start_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process, perf_status),
			0, 1, 2, fake_perf_start_mask_check,
			fake_perf_start_set_period,
			fake_perf_start_counter_set,
			fake_perf_start_hw_start);
		require(rc == 0);
		require(fake_perf_start_hw_start_calls == 0);
		require(proc.perf_status == 2);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_start_hw_start_calls);

		leader.state = 0;
		leader.use_invariant_tsc = 0;
		proc.perf_status = 0;
		fake_perf_read_reset();
		rc = perf_start_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process, perf_status),
			0, 1, 2, fake_perf_start_mask_check, NULL,
			fake_perf_start_counter_set,
			fake_perf_start_hw_start);
		require(rc == -22);
		require(proc.perf_status == 0);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_thread thread = {
			.system_tsc = 2000,
			.user_tsc = 1000,
		};
		struct fake_perf_read_event leader = {
			.counter_id = 1,
			.use_invariant_tsc = 1,
			.base_user_tsc = 700,
			.stopped_user_tsc = 900,
			.user_accum_count = 77,
			.base_system_tsc = 300,
			.stopped_system_tsc = 0,
			.system_accum_count = 88,
		};
		struct fake_perf_read_event sub = {
			.counter_id = 2,
			.use_invariant_tsc = 0,
			.count = { .counter64 = 44 },
		};
		long rc;

		leader.group_leader = &leader;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&sub.group_entry);
		fake_wait_scan_list_add_tail(&sub.group_entry,
			&leader.sibling_list);

		fake_perf_read_reset();
		fake_sync_child_reset(0);
		fake_perf_start_mask_check_accept = (1UL << 1) | (1UL << 2);
		rc = perf_reset_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_start_mask_check, fake_perf_read_value,
			fake_sync_child_count_set);
		require(rc == 0);
		require(leader.base_user_tsc == 900);
		require(leader.user_accum_count == 0);
		require(leader.base_system_tsc == 2000);
		require(leader.system_accum_count == 0);
		require(fake_perf_read_value_calls == 1);
		require(fake_perf_read_value_last_event == &sub);
		require(fake_sync_child_set_calls == 1);
		require(sub.count.counter64 == 0);
		mix_signed(digest, rc);
		mix_signed(digest, leader.base_user_tsc);
		mix_signed(digest, leader.base_system_tsc);
		mix_signed(digest, fake_perf_read_value_calls);

		sub.count.counter64 = 55;
		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = 0;
		rc = perf_reset_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_start_mask_check, fake_perf_read_value,
			fake_sync_child_count_set);
		require(rc == 0);
		require(fake_perf_read_value_calls == 0);
		require(sub.count.counter64 == 55);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_read_value_calls);

		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = 1UL << 2;
		leader.use_invariant_tsc = 0;
		rc = perf_reset_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, base_user_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event, user_accum_count),
			offsetof(struct fake_perf_read_event, base_system_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_event,
				 system_accum_count),
			offsetof(struct fake_perf_read_event, count),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			fake_perf_start_mask_check, NULL,
			fake_sync_child_count_set);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_start_process proc = {
			.perf_status = 2,
			.monitoring_event = (void *)0xfeed,
		};
		struct fake_perf_read_thread thread = {
			.proc = &proc,
			.system_tsc = 2000,
			.user_tsc = 1000,
		};
		struct fake_perf_read_event leader = {
			.counter_id = 1,
			.state = 1,
			.use_invariant_tsc = 1,
			.stopped_user_tsc = 0,
			.stopped_system_tsc = 77,
		};
		struct fake_perf_read_event sub = {
			.counter_id = 2,
			.state = 1,
			.use_invariant_tsc = 0,
			.count = { .counter64 = 44 },
		};
		long rc;

		leader.group_leader = &leader;
		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&sub.group_entry);
		fake_wait_scan_list_add_tail(&sub.group_entry,
			&leader.sibling_list);

		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = (1UL << 1) | (1UL << 2);
		rc = perf_stop_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process,
				 monitoring_event),
			offsetof(struct fake_perf_start_process, perf_status),
			1, 0, 0, 5, fake_perf_start_mask_check,
			fake_perf_stop_hw, fake_perf_read_update);
		require(rc == 0);
		require(leader.state == 0);
		require(leader.stopped_user_tsc == 1000);
		require(leader.stopped_system_tsc == 77);
		require(sub.state == 0);
		require(fake_perf_stop_hw_calls == 1);
		require(fake_perf_stop_hw_mask == (1UL << 2));
		require(fake_perf_stop_hw_flags == 5);
		require(fake_perf_read_update_calls == 1);
		require(fake_perf_read_update_event == &sub);
		require(sub.count.counter64 == 77);
		require(proc.monitoring_event == NULL);
		require(proc.perf_status == 0);
		mix_signed(digest, rc);
		mix_signed(digest, leader.stopped_user_tsc);
		mix(digest, fake_perf_stop_hw_mask);
		mix_signed(digest, fake_perf_read_update_calls);
		mix_signed(digest, proc.perf_status);

		leader.state = 1;
		sub.state = 1;
		sub.count.counter64 = 55;
		proc.monitoring_event = &leader;
		proc.perf_status = 2;
		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = 0;
		rc = perf_stop_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process,
				 monitoring_event),
			offsetof(struct fake_perf_start_process, perf_status),
			1, 0, 0, 0, fake_perf_start_mask_check,
			fake_perf_stop_hw, fake_perf_read_update);
		require(rc == 0);
		require(leader.state == 1);
		require(sub.state == 1);
		require(fake_perf_stop_hw_calls == 0);
		require(fake_perf_read_update_calls == 0);
		require(proc.monitoring_event == NULL);
		require(proc.perf_status == 0);
		mix_signed(digest, rc);
		mix_signed(digest, leader.state);

		leader.use_invariant_tsc = 0;
		fake_perf_read_reset();
		fake_perf_start_mask_check_accept = 1UL << 1;
		rc = perf_stop_body_result(&leader, &thread,
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, state),
			offsetof(struct fake_perf_read_event, use_invariant_tsc),
			offsetof(struct fake_perf_read_event, stopped_user_tsc),
			offsetof(struct fake_perf_read_event,
				 stopped_system_tsc),
			offsetof(struct fake_perf_read_thread, user_tsc),
			offsetof(struct fake_perf_read_thread, system_tsc),
			offsetof(struct fake_perf_read_thread, proc),
			offsetof(struct fake_perf_start_process,
				 monitoring_event),
			offsetof(struct fake_perf_start_process, perf_status),
			1, 0, 0, 0, fake_perf_start_mask_check, NULL,
			fake_perf_read_update);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		const unsigned long enable_cmd = 1;
		const unsigned long disable_cmd = 2;
		const unsigned long reset_cmd = 3;
		const unsigned long refresh_cmd = 4;
		const int pp_reset = 1;
		struct fake_perf_read_event event = {
			.pid = 0,
			.inherit = 0,
		};
		struct fake_perf_ioctl_process current = { 0 };
		struct fake_perf_ioctl_process target = { 0 };
		int lock_node = 0x7788;
		long rc;

		fake_perf_read_reset();
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		require(current.monitoring_event == &event);
		require(fake_perf_ioctl_start_calls == 1);
		require(fake_perf_ioctl_last_event == &event);
		require(fake_perf_ioctl_find_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_ioctl_start_calls);

		event.pid = 42;
		target.monitoring_event = NULL;
		target.perf_status = 0;
		fake_perf_read_reset();
		fake_perf_ioctl_find_result = &target;
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		require(fake_perf_ioctl_find_calls == 1);
		require(fake_perf_ioctl_find_pid == 42);
		require(fake_perf_ioctl_find_lock == &lock_node);
		require(target.monitoring_event == &event);
		require(target.perf_status == pp_reset);
		require(fake_perf_ioctl_unlock_calls == 1);
		require(fake_perf_ioctl_unlock_proc == &target);
		require(fake_perf_ioctl_unlock_lock == &lock_node);
		mix_signed(digest, rc);
		mix_signed(digest, target.perf_status);

		target.monitoring_event = &current;
		target.perf_status = 99;
		fake_perf_read_reset();
		fake_perf_ioctl_find_result = &target;
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		require(target.monitoring_event == &current);
		require(target.perf_status == 99);
		require(fake_perf_ioctl_unlock_calls == 1);
		mix_signed(digest, rc);
		mix_signed(digest, target.perf_status);

		fake_perf_read_reset();
		fake_perf_ioctl_find_result = NULL;
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == -22);
		require(fake_perf_ioctl_find_calls == 1);
		require(fake_perf_ioctl_unlock_calls == 0);
		mix_signed(digest, rc);

		event.pid = 0;
		fake_perf_read_reset();
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			disable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		require(fake_perf_ioctl_stop_calls == 1);
		require(fake_perf_ioctl_last_event == &event);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_ioctl_stop_calls);

		fake_perf_read_reset();
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			reset_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		require(fake_perf_ioctl_reset_calls == 1);
		require(fake_perf_ioctl_last_event == &event);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_ioctl_reset_calls);

		event.inherit = 1;
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			refresh_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == -22);
		mix_signed(digest, rc);

		event.inherit = 0;
		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			refresh_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == 0);
		mix_signed(digest, rc);

		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			99, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == -1);
		mix_signed(digest, rc);

		rc = perf_ioctl_body_result(NULL, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			fake_perf_ioctl_start, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_ioctl_body_result(&event, &current, &lock_node,
			enable_cmd, event.inherit, enable_cmd, disable_cmd,
			reset_cmd, refresh_cmd, pp_reset,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_ioctl_process,
				 monitoring_event),
			offsetof(struct fake_perf_ioctl_process, perf_status),
			NULL, fake_perf_ioctl_stop,
			fake_perf_ioctl_reset_event, fake_perf_ioctl_find,
			fake_perf_ioctl_unlock);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_thread thread = {
			.pmc_alloc_map = ~0UL,
			.extra_reg_alloc_map = ~0UL,
		};
		struct fake_perf_read_event event = {
			.counter_id = 5,
			.extra_reg = 0x12,
			.extra_reg_idx = 7,
		};
		unsigned long bit5 = 1UL << 5;
		unsigned long bit7 = 1UL << 7;
		long rc;

		fake_perf_read_reset();
		rc = perf_close_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, extra_reg),
			offsetof(struct fake_perf_read_event, extra_reg_idx),
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			offsetof(struct fake_perf_read_thread,
				 extra_reg_alloc_map),
			fake_perf_close_free);
		require(rc == 0);
		require((thread.pmc_alloc_map & bit5) == 0);
		require((thread.extra_reg_alloc_map & bit7) == 0);
		require(fake_perf_close_free_calls == 1);
		require(fake_perf_close_free_ptr == &event);
		mix_signed(digest, rc);
		mix(digest, thread.pmc_alloc_map);
		mix(digest, thread.extra_reg_alloc_map);
		mix_signed(digest, fake_perf_close_free_calls);

		thread.pmc_alloc_map = ~0UL;
		thread.extra_reg_alloc_map = ~0UL;
		event.counter_id = 4;
		event.extra_reg = 0;
		event.extra_reg_idx = 9;
		fake_perf_read_reset();
		rc = perf_close_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, extra_reg),
			offsetof(struct fake_perf_read_event, extra_reg_idx),
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			offsetof(struct fake_perf_read_thread,
				 extra_reg_alloc_map),
			fake_perf_close_free);
		require(rc == 0);
		require((thread.pmc_alloc_map & (1UL << 4)) == 0);
		require(thread.extra_reg_alloc_map == ~0UL);
		require(fake_perf_close_free_calls == 1);
		mix_signed(digest, rc);
		mix(digest, thread.pmc_alloc_map);

		event.counter_id = 99;
		event.extra_reg = 1;
		event.extra_reg_idx = -1;
		thread.pmc_alloc_map = 0xa5a5UL;
		thread.extra_reg_alloc_map = 0x5a5aUL;
		fake_perf_read_reset();
		rc = perf_close_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, extra_reg),
			offsetof(struct fake_perf_read_event, extra_reg_idx),
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			offsetof(struct fake_perf_read_thread,
				 extra_reg_alloc_map),
			fake_perf_close_free);
		require(rc == 0);
		require(thread.pmc_alloc_map == 0xa5a5UL);
		require(thread.extra_reg_alloc_map == 0x5a5aUL);
		require(fake_perf_close_free_calls == 1);
		mix_signed(digest, rc);
		mix(digest, thread.pmc_alloc_map);

		rc = perf_close_body_result(NULL, &thread,
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, extra_reg),
			offsetof(struct fake_perf_read_event, extra_reg_idx),
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			offsetof(struct fake_perf_read_thread,
				 extra_reg_alloc_map),
			fake_perf_close_free);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_close_body_result(&event, &thread,
			offsetof(struct fake_perf_read_event, counter_id),
			offsetof(struct fake_perf_read_event, extra_reg),
			offsetof(struct fake_perf_read_event, extra_reg_idx),
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			offsetof(struct fake_perf_read_thread,
				 extra_reg_alloc_map),
			NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_fcntl_fd sfd = {
			.sig_no = -1,
		};
		int ctx = 0x55aa;
		long rc;

		fake_perf_read_reset();
		fake_perf_fcntl_forward_rc = 88;
		rc = perf_fcntl_body_result(&sfd, &ctx, 10, 44, 72,
			10, 0xf, offsetof(struct fake_perf_fcntl_fd, sig_no),
			fake_perf_fcntl_forward);
		require(rc == 88);
		require(sfd.sig_no == 44);
		require(fake_perf_fcntl_forward_calls == 1);
		require(fake_perf_fcntl_forward_nr == 72);
		require(fake_perf_fcntl_forward_ctx == &ctx);
		mix_signed(digest, rc);
		mix_signed(digest, sfd.sig_no);

		sfd.sig_no = 11;
		fake_perf_read_reset();
		fake_perf_fcntl_forward_rc = -5;
		rc = perf_fcntl_body_result(&sfd, &ctx, 0xf, 77, 72,
			10, 0xf, offsetof(struct fake_perf_fcntl_fd, sig_no),
			fake_perf_fcntl_forward);
		require(rc == -5);
		require(sfd.sig_no == 11);
		require(fake_perf_fcntl_forward_calls == 1);
		mix_signed(digest, rc);
		mix_signed(digest, sfd.sig_no);

		sfd.sig_no = 22;
		fake_perf_read_reset();
		fake_perf_fcntl_forward_rc = 7;
		rc = perf_fcntl_body_result(&sfd, &ctx, 99, 123, 72,
			10, 0xf, offsetof(struct fake_perf_fcntl_fd, sig_no),
			fake_perf_fcntl_forward);
		require(rc == 7);
		require(sfd.sig_no == 22);
		require(fake_perf_fcntl_forward_calls == 1);
		mix_signed(digest, rc);
		mix_signed(digest, sfd.sig_no);

		rc = perf_fcntl_body_result(NULL, &ctx, 10, 1, 72,
			10, 0xf, offsetof(struct fake_perf_fcntl_fd, sig_no),
			fake_perf_fcntl_forward);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = perf_fcntl_body_result(&sfd, &ctx, 10, 1, 72,
			10, 0xf, offsetof(struct fake_perf_fcntl_fd, sig_no),
			NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_mmap_page page = {
			.capabilities = 0x10,
			.data_head = 0,
		};
		unsigned long cap_rdpmc = 1UL << 2;
		long rc;

		fake_perf_read_reset();
		fake_perf_mmap_rc = (long)&page;
		rc = perf_mmap_body_result(0x1000, 0x2000, 0x1, 0x40,
			7, 0x3000, 0x20, 0x2,
			offsetof(struct fake_perf_mmap_page, data_head),
			offsetof(struct fake_perf_mmap_page, capabilities),
			cap_rdpmc, fake_perf_mmap_do);
		require(rc == (long)&page);
		require(fake_perf_mmap_calls == 1);
		require(fake_perf_mmap_addr == 0x1000);
		require(fake_perf_mmap_len == 0x2000);
		require(fake_perf_mmap_prot == 0x3);
		require(fake_perf_mmap_flags == 0x60);
		require(fake_perf_mmap_fd == 7);
		require(fake_perf_mmap_off == 0x3000);
		require(fake_perf_mmap_vrf0 == 0);
		require(fake_perf_mmap_private_data == NULL);
		require(page.data_head == 16);
		require(page.capabilities == (0x10 | cap_rdpmc));
		mix(digest, page.data_head);
		mix(digest, page.capabilities);
		mix_signed(digest, fake_perf_mmap_calls);

		page.capabilities = cap_rdpmc;
		page.data_head = 99;
		fake_perf_read_reset();
		fake_perf_mmap_rc = (long)&page;
		rc = perf_mmap_body_result(0, 0x4000, 0, 0, -1, -8,
			0x20, 0x2,
			offsetof(struct fake_perf_mmap_page, data_head),
			offsetof(struct fake_perf_mmap_page, capabilities),
			cap_rdpmc, fake_perf_mmap_do);
		require(rc == (long)&page);
		require(fake_perf_mmap_prot == 0x2);
		require(fake_perf_mmap_flags == 0x20);
		require(fake_perf_mmap_fd == -1);
		require(fake_perf_mmap_off == -8);
		require(page.data_head == 16);
		require(page.capabilities == cap_rdpmc);
		mix(digest, page.capabilities);

		rc = perf_mmap_body_result(0, 0, 0, 0, 0, 0, 0x20, 0x2,
			offsetof(struct fake_perf_mmap_page, data_head),
			offsetof(struct fake_perf_mmap_page, capabilities),
			cap_rdpmc, NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		const unsigned long hardware_type = 0;
		const unsigned long hw_cache_type = 3;
		const unsigned long raw_type = 4;
		const unsigned long unsupported_read_mask = 0x7;
		const unsigned long sample_sign_bit = 1UL << 63;
		int rc;

		rc = perf_event_open_validate_body_result(0, 0, raw_type, 0,
			0, 123, raw_type, hardware_type, hw_cache_type,
			unsupported_read_mask, sample_sign_bit);
		require(rc == 0);
		mix_signed(digest, rc);

		rc = perf_event_open_validate_body_result(1, 0, raw_type, 0,
			0, 123, raw_type, hardware_type, hw_cache_type,
			unsupported_read_mask, sample_sign_bit);
		require(rc == -2);
		mix_signed(digest, rc);

		rc = perf_event_open_validate_body_result(0, 0, 99, 0, 0,
			123, raw_type, hardware_type, hw_cache_type,
			unsupported_read_mask, sample_sign_bit);
		require(rc == -2);
		mix_signed(digest, rc);

		rc = perf_event_open_validate_body_result(0, 0, hardware_type,
			0x4, 0, 123, raw_type, hardware_type, hw_cache_type,
			unsupported_read_mask, sample_sign_bit);
		require(rc == -2);
		mix_signed(digest, rc);

		rc = perf_event_open_validate_body_result(0, 0, hw_cache_type,
			0, 1, 123, raw_type, hardware_type, hw_cache_type,
			unsupported_read_mask, sample_sign_bit);
		require(rc == -2);
		mix_signed(digest, rc);

		rc = perf_event_open_validate_body_result(4, 0, raw_type, 0,
			0, sample_sign_bit, raw_type, hardware_type,
			hw_cache_type, unsupported_read_mask,
			sample_sign_bit);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		const unsigned long hardware_type = 0;
		const unsigned long raw_type = 4;
		const unsigned long ref_cpu_cycles = 9;
		struct fake_perf_alloc_event event;
		unsigned char attr[32];
		unsigned long attr_sum = 0;
		size_t i;
		long rc;

		for (i = 0; i < sizeof(attr); i++) {
			attr[i] = (unsigned char)(0x30 + i);
		}

		memset(&event, 0xa5, sizeof(event));
		fake_sync_child_reset(0);
		rc = perf_event_alloc_init_body_result(&event, attr,
			sizeof(event), sizeof(attr),
			offsetof(struct fake_perf_alloc_event, attr_copy),
			offsetof(struct fake_perf_alloc_event, group_entry),
			offsetof(struct fake_perf_alloc_event, sibling_list),
			offsetof(struct fake_perf_alloc_event, sample_freq),
			offsetof(struct fake_perf_alloc_event, nr_siblings),
			offsetof(struct fake_perf_alloc_event, count),
			offsetof(struct fake_perf_alloc_event,
				 child_count_total),
			offsetof(struct fake_perf_alloc_event, parent),
			offsetof(struct fake_perf_alloc_event, hw.sample_period),
			offsetof(struct fake_perf_alloc_event, hw.last_period),
			offsetof(struct fake_perf_alloc_event, hw.period_left),
			offsetof(struct fake_perf_alloc_event,
				 use_invariant_tsc),
			raw_type, 0x55, 0, 77, 1234, hardware_type,
			ref_cpu_cycles, fake_sync_child_count_set);
		require(rc == 0);
		for (i = 0; i < sizeof(attr); i++) {
			require(event.attr_copy[i] == attr[i]);
			attr_sum += event.attr_copy[i];
		}
		require(event.poison == 0);
		require(event.group_entry.next == &event.group_entry);
		require(event.group_entry.prev == &event.group_entry);
		require(event.sibling_list.next == &event.sibling_list);
		require(event.sibling_list.prev == &event.sibling_list);
		require(event.sample_freq == 77);
		require(event.nr_siblings == 0);
		require(event.count.counter64 == 0);
		require(event.child_count_total == 0);
		require(event.parent == NULL);
		require(event.hw.sample_period == 1234);
		require(event.hw.last_period == 1234);
		require(event.hw.period_left.counter64 == 1234);
		require(event.use_invariant_tsc == 0);
		require(fake_sync_child_set_calls == 2);
		require(fake_sync_child_set_last_ptr == &event.hw.period_left);
		require(fake_sync_child_set_last_value == 1234);
		mix_signed(digest, rc);
		mix(digest, attr_sum);
		mix(digest, event.sample_freq);
		mix(digest, event.hw.sample_period);
		mix_signed(digest, fake_sync_child_set_calls);

		memset(&event, 0xa5, sizeof(event));
		fake_sync_child_reset(0);
		rc = perf_event_alloc_init_body_result(&event, attr,
			sizeof(event), sizeof(attr),
			offsetof(struct fake_perf_alloc_event, attr_copy),
			offsetof(struct fake_perf_alloc_event, group_entry),
			offsetof(struct fake_perf_alloc_event, sibling_list),
			offsetof(struct fake_perf_alloc_event, sample_freq),
			offsetof(struct fake_perf_alloc_event, nr_siblings),
			offsetof(struct fake_perf_alloc_event, count),
			offsetof(struct fake_perf_alloc_event,
				 child_count_total),
			offsetof(struct fake_perf_alloc_event, parent),
			offsetof(struct fake_perf_alloc_event, hw.sample_period),
			offsetof(struct fake_perf_alloc_event, hw.last_period),
			offsetof(struct fake_perf_alloc_event, hw.period_left),
			offsetof(struct fake_perf_alloc_event,
				 use_invariant_tsc),
			raw_type, 0x56, 1, 77, 1234, hardware_type,
			ref_cpu_cycles, fake_sync_child_count_set);
		require(rc == 0);
		require(event.hw.sample_period == 1);
		require(event.hw.last_period == 1);
		require(event.hw.period_left.counter64 == 1);
		require(event.use_invariant_tsc == 0);
		mix_signed(digest, rc);
		mix(digest, event.hw.sample_period);

		memset(&event, 0xa5, sizeof(event));
		fake_sync_child_reset(0);
		rc = perf_event_alloc_init_body_result(&event, attr,
			sizeof(event), sizeof(attr),
			offsetof(struct fake_perf_alloc_event, attr_copy),
			offsetof(struct fake_perf_alloc_event, group_entry),
			offsetof(struct fake_perf_alloc_event, sibling_list),
			offsetof(struct fake_perf_alloc_event, sample_freq),
			offsetof(struct fake_perf_alloc_event, nr_siblings),
			offsetof(struct fake_perf_alloc_event, count),
			offsetof(struct fake_perf_alloc_event,
				 child_count_total),
			offsetof(struct fake_perf_alloc_event, parent),
			offsetof(struct fake_perf_alloc_event, hw.sample_period),
			offsetof(struct fake_perf_alloc_event, hw.last_period),
			offsetof(struct fake_perf_alloc_event, hw.period_left),
			offsetof(struct fake_perf_alloc_event,
				 use_invariant_tsc),
			hardware_type, ref_cpu_cycles, 0, 5, 9,
			hardware_type, ref_cpu_cycles,
			fake_sync_child_count_set);
		require(rc == 1);
		require(event.use_invariant_tsc == 1);
		require(event.hw.sample_period == 9);
		require(event.hw.period_left.counter64 == 9);
		mix_signed(digest, rc);
		mix_signed(digest, event.use_invariant_tsc);

		rc = perf_event_alloc_init_body_result(&event, attr,
			sizeof(event), sizeof(attr),
			offsetof(struct fake_perf_alloc_event, attr_copy),
			offsetof(struct fake_perf_alloc_event, group_entry),
			offsetof(struct fake_perf_alloc_event, sibling_list),
			offsetof(struct fake_perf_alloc_event, sample_freq),
			offsetof(struct fake_perf_alloc_event, nr_siblings),
			offsetof(struct fake_perf_alloc_event, count),
			offsetof(struct fake_perf_alloc_event,
				 child_count_total),
			offsetof(struct fake_perf_alloc_event, parent),
			offsetof(struct fake_perf_alloc_event, hw.sample_period),
			offsetof(struct fake_perf_alloc_event, hw.last_period),
			offsetof(struct fake_perf_alloc_event, hw.period_left),
			offsetof(struct fake_perf_alloc_event,
				 use_invariant_tsc),
			raw_type, 0x57, 0, 1, 2, hardware_type,
			ref_cpu_cycles, NULL);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		const unsigned long hardware_type = 0;
		const unsigned long hw_cache_type = 3;
		const unsigned long raw_type = 4;
		struct fake_perf_alloc_event event = { 0 };
		struct fake_perf_alloc_event *out = NULL;
		long rc;

#define PERF_ALLOC_MAP_CALL(outp, eventp, event_type, event_config, hw_map, \
			    cache_map, cache_extra, raw_map, validate, \
			    extra_id, msr, idx_cb, init) \
	perf_event_alloc_map_body_result((void **)(outp), (eventp), \
		offsetof(struct fake_perf_alloc_event, hw_config), \
		offsetof(struct fake_perf_alloc_event, hw_config_ext), \
		offsetof(struct fake_perf_alloc_event, extra_reg.config), \
		offsetof(struct fake_perf_alloc_event, extra_reg.reg), \
		offsetof(struct fake_perf_alloc_event, extra_reg.idx), \
		(event_type), (event_config), hardware_type, hw_cache_type, \
		raw_type, \
		(hw_map), (cache_map), (cache_extra), (raw_map), \
		(validate), (extra_id), (msr), (idx_cb), (init))

		fake_perf_read_reset();
		event.extra_reg.config = 77;
		event.extra_reg.reg = 88;
		event.extra_reg.idx = 99;
		rc = PERF_ALLOC_MAP_CALL(&out, &event, hardware_type, 5,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, fake_perf_alloc_raw_map,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == 0);
		require(out == &event);
		require(event.hw_config == 0x1005);
		require(event.hw_config_ext == 0);
		require(event.extra_reg.config == 77);
		require(event.extra_reg.reg == 88);
		require(event.extra_reg.idx == 99);
		require(fake_perf_alloc_hw_map_calls == 1);
		require(fake_perf_alloc_validate_calls == 1);
		require(fake_perf_alloc_validate_last == 0x1005);
		require(fake_perf_alloc_extra_id_calls == 1);
		require(fake_perf_alloc_msr_calls == 0);
		require(fake_perf_alloc_idx_calls == 0);
		require(fake_perf_alloc_hw_init_calls == 1);
		require(fake_perf_alloc_hw_init_event == &event);
		mix_signed(digest, rc);
		mix(digest, event.hw_config);
		mix_signed(digest, fake_perf_alloc_hw_map_calls);

		memset(&event, 0, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_extra_id_rc = 2;
		rc = PERF_ALLOC_MAP_CALL(&out, &event, hw_cache_type, 7,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, fake_perf_alloc_raw_map,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == 0);
		require(out == &event);
		require(event.hw_config == 0x2007);
		require(event.hw_config_ext == 0x37);
		require(event.extra_reg.config == 0x37);
		require(event.extra_reg.reg == 0xabc002U);
		require(event.extra_reg.idx == 9);
		require(fake_perf_alloc_cache_map_calls == 1);
		require(fake_perf_alloc_cache_extra_calls == 1);
		require(fake_perf_alloc_extra_id_config == 0x2007);
		require(fake_perf_alloc_extra_id_ext == 0x37);
		require(fake_perf_alloc_msr_calls == 1);
		require(fake_perf_alloc_idx_calls == 1);
		mix_signed(digest, rc);
		mix(digest, event.hw_config_ext);
		mix(digest, event.extra_reg.reg);
		mix_signed(digest, event.extra_reg.idx);

		memset(&event, 0, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_validate_reject = 0x3009;
		rc = PERF_ALLOC_MAP_CALL(&out, &event, raw_type, 9,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, fake_perf_alloc_raw_map,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == -2);
		require(out == NULL);
		require(fake_perf_alloc_raw_map_calls == 1);
		require(fake_perf_alloc_validate_calls == 1);
		require(fake_perf_alloc_extra_id_calls == 0);
		require(fake_perf_alloc_hw_init_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_alloc_hw_init_calls);

		memset(&event, 0, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_hw_init_rc = -12;
		rc = PERF_ALLOC_MAP_CALL(&out, &event, raw_type, 4,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, fake_perf_alloc_raw_map,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == -12);
		require(out == NULL);
		require(event.hw_config == 0x3004);
		require(fake_perf_alloc_hw_init_calls == 1);
		mix_signed(digest, rc);
		mix(digest, event.hw_config);

		fake_perf_read_reset();
		rc = PERF_ALLOC_MAP_CALL(&out, &event, 99, 1,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, fake_perf_alloc_raw_map,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == -22);
		require(fake_perf_alloc_validate_calls == 0);
		mix_signed(digest, rc);

		rc = PERF_ALLOC_MAP_CALL(&out, &event, raw_type, 1,
			fake_perf_alloc_hw_map, fake_perf_alloc_cache_map,
			fake_perf_alloc_cache_extra, NULL,
			fake_perf_alloc_validate, fake_perf_alloc_extra_id,
			fake_perf_alloc_extra_msr, fake_perf_alloc_extra_idx,
			fake_perf_alloc_hw_init);
		require(rc == -22);
		mix_signed(digest, rc);

#undef PERF_ALLOC_MAP_CALL
	}
	{
		const unsigned long hardware_type = 0;
		const unsigned long hw_cache_type = 3;
		const unsigned long raw_type = 4;
		const unsigned long ref_cpu_cycles = 9;
		const unsigned long alloc_nowait = 0x000002UL;
		struct fake_perf_alloc_event event;
		struct fake_perf_alloc_event *out = NULL;
		unsigned char attr[32];
		size_t i;
		long rc;

		for (i = 0; i < sizeof(attr); i++) {
			attr[i] = (unsigned char)(0x60 + i);
		}

#define PERF_ALLOC_BODY_CALL(outp, attrp, event_type, event_config, \
			     freq_value, sample_freq_value, \
			     sample_period_value, alloc_cb, free_cb, \
			     atomic_cb) \
	perf_event_alloc_body_result((void **)(outp), (attrp), \
		sizeof(struct fake_perf_alloc_event), sizeof(attr), \
		alloc_nowait, \
		offsetof(struct fake_perf_alloc_event, attr_copy), \
		offsetof(struct fake_perf_alloc_event, group_entry), \
		offsetof(struct fake_perf_alloc_event, sibling_list), \
		offsetof(struct fake_perf_alloc_event, sample_freq), \
		offsetof(struct fake_perf_alloc_event, nr_siblings), \
		offsetof(struct fake_perf_alloc_event, count), \
		offsetof(struct fake_perf_alloc_event, child_count_total), \
		offsetof(struct fake_perf_alloc_event, parent), \
		offsetof(struct fake_perf_alloc_event, hw.sample_period), \
		offsetof(struct fake_perf_alloc_event, hw.last_period), \
		offsetof(struct fake_perf_alloc_event, hw.period_left), \
		offsetof(struct fake_perf_alloc_event, use_invariant_tsc), \
		offsetof(struct fake_perf_alloc_event, hw_config), \
		offsetof(struct fake_perf_alloc_event, hw_config_ext), \
		offsetof(struct fake_perf_alloc_event, extra_reg.config), \
		offsetof(struct fake_perf_alloc_event, extra_reg.reg), \
		offsetof(struct fake_perf_alloc_event, extra_reg.idx), \
		(event_type), (event_config), (freq_value), \
		(sample_freq_value), (sample_period_value), hardware_type, \
		hw_cache_type, raw_type, ref_cpu_cycles, (alloc_cb), \
		(free_cb), (atomic_cb), fake_perf_alloc_hw_map, \
		fake_perf_alloc_cache_map, fake_perf_alloc_cache_extra, \
		fake_perf_alloc_raw_map, fake_perf_alloc_validate, \
		fake_perf_alloc_extra_id, fake_perf_alloc_extra_msr, \
		fake_perf_alloc_extra_idx, fake_perf_alloc_hw_init)

		memset(&event, 0xa5, sizeof(event));
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = &event;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, raw_type, 6, 0, 55,
			777, fake_perf_alloc_alloc, fake_perf_alloc_free,
			fake_sync_child_count_set);
		require(rc == 0);
		require(out == &event);
		require(fake_perf_alloc_alloc_calls == 1);
		require(fake_perf_alloc_alloc_size == sizeof(event));
		require(fake_perf_alloc_alloc_flags == alloc_nowait);
		require(fake_perf_alloc_free_calls == 0);
		require(event.attr_copy[0] == attr[0]);
		require(event.sample_freq == 55);
		require(event.hw.sample_period == 777);
		require(event.hw_config == 0x3006);
		require(fake_perf_alloc_raw_map_calls == 1);
		require(fake_perf_alloc_hw_init_calls == 1);
		mix_signed(digest, rc);
		mix(digest, event.hw_config);
		mix_signed(digest, fake_perf_alloc_alloc_calls);

		memset(&event, 0xa5, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = &event;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, hardware_type,
			ref_cpu_cycles, 0, 5, 9, fake_perf_alloc_alloc,
			fake_perf_alloc_free, fake_sync_child_count_set);
		require(rc == 0);
		require(out == &event);
		require(event.use_invariant_tsc == 1);
		require(fake_perf_alloc_validate_calls == 0);
		require(fake_perf_alloc_hw_init_calls == 0);
		require(fake_perf_alloc_free_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, event.use_invariant_tsc);

		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = NULL;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, raw_type, 1, 0, 1, 2,
			fake_perf_alloc_alloc, fake_perf_alloc_free,
			fake_sync_child_count_set);
		require(rc == -12);
		require(out == NULL);
		require(fake_perf_alloc_alloc_calls == 1);
		require(fake_perf_alloc_free_calls == 0);
		mix_signed(digest, rc);

		memset(&event, 0xa5, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = &event;
		fake_perf_alloc_validate_reject = 0x3009;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, raw_type, 9, 0, 1, 2,
			fake_perf_alloc_alloc, fake_perf_alloc_free,
			fake_sync_child_count_set);
		require(rc == -2);
		require(out == NULL);
		require(fake_perf_alloc_free_calls == 1);
		require(fake_perf_alloc_free_ptr == &event);
		require(fake_perf_alloc_hw_init_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_perf_alloc_free_calls);

		memset(&event, 0xa5, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = &event;
		fake_perf_alloc_hw_init_rc = -12;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, raw_type, 4, 0, 1, 2,
			fake_perf_alloc_alloc, fake_perf_alloc_free,
			fake_sync_child_count_set);
		require(rc == -12);
		require(out == NULL);
		require(fake_perf_alloc_free_calls == 1);
		require(fake_perf_alloc_hw_init_calls == 1);
		mix_signed(digest, rc);

		memset(&event, 0xa5, sizeof(event));
		out = NULL;
		fake_perf_read_reset();
		fake_perf_alloc_alloc_result = &event;
		rc = PERF_ALLOC_BODY_CALL(&out, attr, raw_type, 4, 0, 1, 2,
			fake_perf_alloc_alloc, fake_perf_alloc_free, NULL);
		require(rc == -22);
		require(out == NULL);
		require(fake_perf_alloc_free_calls == 1);
		require(fake_perf_alloc_raw_map_calls == 0);
		mix_signed(digest, rc);

#undef PERF_ALLOC_BODY_CALL
	}
	{
		struct fake_perf_read_event leader = {
			.nr_siblings = 1,
			.pmc_status = 1UL << 1,
		};
		struct fake_perf_read_event existing = { 0 };
		struct fake_perf_read_event event = { 0 };
		struct fake_perf_open_fd miss = {
			.fd = 3,
			.data = (long)&existing,
		};
		struct fake_perf_open_fd hit = {
			.fd = 9,
			.data = (long)&leader,
		};
		struct fake_perf_open_process proc = {
			.mckfd = &miss,
		};
		long rc;

		fake_wait_scan_list_init(&leader.sibling_list);
		fake_wait_scan_list_init(&existing.group_entry);
		fake_wait_scan_list_init(&event.group_entry);
		fake_wait_scan_list_add_tail(&existing.group_entry,
			&leader.sibling_list);
		miss.next = &hit;

		rc = perf_event_open_group_body_result(&event, &proc, -1, 3,
			offsetof(struct fake_perf_open_process, mckfd),
			offsetof(struct fake_perf_open_fd, next),
			offsetof(struct fake_perf_open_fd, fd),
			offsetof(struct fake_perf_open_fd, data),
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, pmc_status));
		require(rc == 0);
		require(event.group_leader == &event);
		require(event.pmc_status == (1UL << 3));
		mix_signed(digest, rc);
		mix(digest, event.pmc_status);

		event.group_leader = NULL;
		event.pmc_status = 0;
		fake_wait_scan_list_init(&event.group_entry);
		rc = perf_event_open_group_body_result(&event, &proc, 9, 4,
			offsetof(struct fake_perf_open_process, mckfd),
			offsetof(struct fake_perf_open_fd, next),
			offsetof(struct fake_perf_open_fd, fd),
			offsetof(struct fake_perf_open_fd, data),
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, pmc_status));
		require(rc == 0);
		require(event.group_leader == &leader);
		require(leader.nr_siblings == 2);
		require(leader.pmc_status == ((1UL << 1) | (1UL << 4)));
		require(existing.group_entry.next == &event.group_entry);
		require(event.group_entry.prev == &existing.group_entry);
		require(event.group_entry.next == &leader.sibling_list);
		require(leader.sibling_list.prev == &event.group_entry);
		mix_signed(digest, rc);
		mix_signed(digest, leader.nr_siblings);
		mix(digest, leader.pmc_status);

		event.group_leader = NULL;
		hit.fd = 11;
		rc = perf_event_open_group_body_result(&event, &proc, 9, 5,
			offsetof(struct fake_perf_open_process, mckfd),
			offsetof(struct fake_perf_open_fd, next),
			offsetof(struct fake_perf_open_fd, fd),
			offsetof(struct fake_perf_open_fd, data),
			offsetof(struct fake_perf_read_event, group_leader),
			offsetof(struct fake_perf_read_event, sibling_list),
			offsetof(struct fake_perf_read_event, group_entry),
			offsetof(struct fake_perf_read_event, nr_siblings),
			offsetof(struct fake_perf_read_event, pmc_status));
		require(rc == -22);
		require(event.group_leader == NULL);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_thread thread = {
			.pmc_alloc_map = 1UL << 1,
		};
		struct fake_perf_read_event event = {
			.pid = -1,
			.counter_id = -1,
		};
		struct fake_syscall_request request = {
			.number = 99,
			.args = { 1, 2, 3, 4, 5, 6 },
		};
		long rc;

		fake_perf_read_reset();
		fake_perf_open_counter_alloc_rc = 5;
		rc = perf_event_open_counter_body_result(&event, &thread, 42,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, counter_id),
			fake_perf_open_counter_alloc);
		require(rc == 5);
		require(event.pid == 42);
		require(event.counter_id == 5);
		require(fake_perf_open_counter_alloc_calls == 1);
		require(fake_perf_open_counter_alloc_thread == &thread);
		require(fake_perf_open_counter_alloc_event == &event);
		mix_signed(digest, rc);
		mix_signed(digest, event.pid);
		mix_signed(digest, event.counter_id);

		event.pid = -1;
		event.counter_id = 77;
		fake_perf_open_counter_alloc_rc = -12;
		rc = perf_event_open_counter_body_result(&event, &thread, 9,
			offsetof(struct fake_perf_read_event, pid),
			offsetof(struct fake_perf_read_event, counter_id),
			fake_perf_open_counter_alloc);
		require(rc == -12);
		require(event.pid == 9);
		require(event.counter_id == 77);
		mix_signed(digest, rc);
		mix_signed(digest, event.counter_id);

		fake_perf_read_reset();
		fake_perf_open_syscall_rc = 88;
		rc = perf_event_open_linux_fd_body_result(&request, &thread,
			4, 298, 3,
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			fake_perf_open_syscall);
		require(rc == 88);
		require(request.number == 298);
		require(request.args[0] == 0);
		require(request.args[1] == 2);
		require(fake_perf_open_syscall_calls == 1);
		require(fake_perf_open_syscall_req == &request);
		require(fake_perf_open_syscall_cpu == 3);
		require(thread.pmc_alloc_map == ((1UL << 1) | (1UL << 4)));
		mix_signed(digest, rc);
		mix(digest, request.number);
		mix(digest, thread.pmc_alloc_map);

		fake_perf_open_syscall_rc = -5;
		thread.pmc_alloc_map = 0;
		request.number = 0;
		request.args[0] = 123;
		rc = perf_event_open_linux_fd_body_result(&request, &thread,
			2, 298, 4,
			offsetof(struct fake_perf_read_thread, pmc_alloc_map),
			fake_perf_open_syscall);
		require(rc == -5);
		require(request.number == 298);
		require(request.args[0] == 0);
		require(thread.pmc_alloc_map == 0);
		mix_signed(digest, rc);
	}
	{
		struct fake_perf_read_event event = { 0 };
		struct fake_perf_open_fd existing = {
			.fd = 44,
		};
		struct fake_perf_open_fd sfd = { 0 };
		struct fake_perf_open_process proc = {
			.mckfd_lock = 7,
			.mckfd = &existing,
		};
		long rc;

		fake_perf_read_reset();
		rc = perf_event_open_mckfd_publish_body_result(&sfd, &event,
			&proc, 12,
			offsetof(struct fake_perf_open_process, mckfd_lock),
			offsetof(struct fake_perf_open_process, mckfd),
			offsetof(struct fake_perf_open_fd, next),
			offsetof(struct fake_perf_open_fd, fd),
			offsetof(struct fake_perf_open_fd, sig_no),
			offsetof(struct fake_perf_open_fd, data),
			offsetof(struct fake_perf_open_fd, read_cb),
			offsetof(struct fake_perf_open_fd, ioctl_cb),
			offsetof(struct fake_perf_open_fd, mmap_cb),
			offsetof(struct fake_perf_open_fd, close_cb),
			offsetof(struct fake_perf_open_fd, fcntl_cb),
			fake_perf_open_long_cb, fake_perf_open_int_cb,
			fake_perf_open_long_cb, fake_perf_open_int_cb,
			fake_perf_open_int_cb, fake_perf_open_lock,
			fake_perf_open_unlock);
		require(rc == 12);
		require(sfd.fd == 12);
		require(sfd.sig_no == -1);
		require(sfd.data == (long)&event);
		require(sfd.read_cb == fake_perf_open_long_cb);
		require(sfd.ioctl_cb == fake_perf_open_int_cb);
		require(sfd.mmap_cb == fake_perf_open_long_cb);
		require(sfd.close_cb == fake_perf_open_int_cb);
		require(sfd.fcntl_cb == fake_perf_open_int_cb);
		require(proc.mckfd == &sfd);
		require(sfd.next == &existing);
		require(fake_perf_open_lock_calls == 1);
		require(fake_perf_open_lock_arg == &proc.mckfd_lock);
		require(fake_perf_open_unlock_calls == 1);
		require(fake_perf_open_unlock_arg == &proc.mckfd_lock);
		require(fake_perf_open_unlock_flags == 0x5a5a);
		mix_signed(digest, rc);
		mix_signed(digest, sfd.fd);

		rc = perf_event_open_mckfd_publish_body_result(&sfd, &event,
			&proc, 12,
			offsetof(struct fake_perf_open_process, mckfd_lock),
			offsetof(struct fake_perf_open_process, mckfd),
			offsetof(struct fake_perf_open_fd, next),
			offsetof(struct fake_perf_open_fd, fd),
			offsetof(struct fake_perf_open_fd, sig_no),
			offsetof(struct fake_perf_open_fd, data),
			offsetof(struct fake_perf_open_fd, read_cb),
			offsetof(struct fake_perf_open_fd, ioctl_cb),
			offsetof(struct fake_perf_open_fd, mmap_cb),
			offsetof(struct fake_perf_open_fd, close_cb),
			offsetof(struct fake_perf_open_fd, fcntl_cb),
			NULL, fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb,
			fake_perf_open_lock, fake_perf_open_unlock);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		const unsigned long alloc_nowait = 0x000002UL;
		struct fake_perf_read_thread thread = {
			.pmc_alloc_map = 1UL << 1,
		};
		struct fake_perf_read_event event = {
			.pid = -1,
			.counter_id = -1,
		};
		struct fake_perf_open_fd existing = {
			.fd = 44,
		};
		struct fake_perf_open_fd sfd = { 0 };
		struct fake_perf_open_process proc = {
			.mckfd_lock = 7,
			.mckfd = &existing,
		};
		struct fake_syscall_request request = {
			.number = 99,
			.args = { 1, 2, 3, 4, 5, 6 },
		};
		unsigned long attr = 0x55aa;
		long rc;

#define PERF_OPEN_BODY_CALL(group_value, event_alloc_cb, counter_cb, \
			    syscall_fn_cb, alloc_fn_cb, read_fn_cb, \
			    ioctl_fn_cb, mmap_fn_cb, close_fn_cb, \
			    fcntl_fn_cb) \
	perf_event_open_body_result(&request, &thread, &proc, &attr, 42, \
		(group_value), 298, 3, sizeof(struct fake_perf_open_fd), \
		alloc_nowait, \
		offsetof(struct fake_perf_read_event, pid), \
		offsetof(struct fake_perf_read_event, counter_id), \
		offsetof(struct fake_perf_open_process, mckfd), \
		offsetof(struct fake_perf_open_fd, next), \
		offsetof(struct fake_perf_open_fd, fd), \
		offsetof(struct fake_perf_open_fd, data), \
		offsetof(struct fake_perf_read_event, group_leader), \
		offsetof(struct fake_perf_read_event, sibling_list), \
		offsetof(struct fake_perf_read_event, group_entry), \
		offsetof(struct fake_perf_read_event, nr_siblings), \
		offsetof(struct fake_perf_read_event, pmc_status), \
		offsetof(struct fake_perf_read_thread, pmc_alloc_map), \
		offsetof(struct fake_perf_open_process, mckfd_lock), \
		offsetof(struct fake_perf_open_fd, sig_no), \
		offsetof(struct fake_perf_open_fd, read_cb), \
		offsetof(struct fake_perf_open_fd, ioctl_cb), \
		offsetof(struct fake_perf_open_fd, mmap_cb), \
		offsetof(struct fake_perf_open_fd, close_cb), \
		offsetof(struct fake_perf_open_fd, fcntl_cb), \
		(event_alloc_cb), (counter_cb), (syscall_fn_cb), \
		(alloc_fn_cb), (read_fn_cb), (ioctl_fn_cb), (mmap_fn_cb), \
		(close_fn_cb), (fcntl_fn_cb), \
		fake_perf_open_lock, fake_perf_open_unlock)

		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = 4;
		fake_perf_open_syscall_rc = 88;
		fake_perf_alloc_alloc_result = &sfd;
		rc = PERF_OPEN_BODY_CALL(-1, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == 88);
		require(fake_perf_open_event_alloc_calls == 1);
		require(fake_perf_open_event_alloc_attr == &attr);
		require(event.pid == 42);
		require(event.counter_id == 4);
		require(event.group_leader == &event);
		require(event.pmc_status == (1UL << 4));
		require(request.number == 298);
		require(request.args[0] == 0);
		require(fake_perf_open_syscall_calls == 1);
		require(fake_perf_open_syscall_cpu == 3);
		require(thread.pmc_alloc_map == ((1UL << 1) | (1UL << 4)));
		require(fake_perf_alloc_alloc_calls == 1);
		require(fake_perf_alloc_alloc_size ==
			sizeof(struct fake_perf_open_fd));
		require(fake_perf_alloc_alloc_flags == alloc_nowait);
		require(sfd.fd == 88);
		require(sfd.sig_no == -1);
		require(sfd.data == (long)&event);
		require(sfd.read_cb == fake_perf_open_long_cb);
		require(proc.mckfd == &sfd);
		require(sfd.next == &existing);
		mix_signed(digest, rc);
		mix_signed(digest, event.counter_id);
		mix(digest, thread.pmc_alloc_map);
		mix_signed(digest, fake_perf_alloc_alloc_calls);

		event.pid = -1;
		event.counter_id = -1;
		event.group_leader = NULL;
		event.pmc_status = 0;
		thread.pmc_alloc_map = 0;
		proc.mckfd = &existing;
		request.number = 0;
		request.args[0] = 123;
		memset(&sfd, 0, sizeof(sfd));
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_event_alloc_rc = -12;
		fake_perf_alloc_alloc_result = &sfd;
		rc = PERF_OPEN_BODY_CALL(-1, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == -12);
		require(fake_perf_open_counter_alloc_calls == 0);
		require(fake_perf_open_syscall_calls == 0);
		require(fake_perf_alloc_alloc_calls == 0);
		mix_signed(digest, rc);

		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = -5;
		rc = PERF_OPEN_BODY_CALL(-1, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == -5);
		require(event.pid == 42);
		require(fake_perf_open_syscall_calls == 0);
		require(fake_perf_alloc_alloc_calls == 0);
		mix_signed(digest, rc);

		event.group_leader = NULL;
		proc.mckfd = &existing;
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = 3;
		rc = PERF_OPEN_BODY_CALL(9, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == -22);
		require(fake_perf_open_syscall_calls == 0);
		require(fake_perf_alloc_alloc_calls == 0);
		mix_signed(digest, rc);

		event.group_leader = NULL;
		event.pmc_status = 0;
		thread.pmc_alloc_map = 0;
		proc.mckfd = &existing;
		request.number = 0;
		request.args[0] = 123;
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = 2;
		fake_perf_open_syscall_rc = -9;
		rc = PERF_OPEN_BODY_CALL(-1, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == -9);
		require(request.number == 298);
		require(thread.pmc_alloc_map == 0);
		require(fake_perf_alloc_alloc_calls == 0);
		mix_signed(digest, rc);

		event.group_leader = NULL;
		event.pmc_status = 0;
		thread.pmc_alloc_map = 0;
		proc.mckfd = &existing;
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = 1;
		fake_perf_open_syscall_rc = 33;
		fake_perf_alloc_alloc_result = NULL;
		rc = PERF_OPEN_BODY_CALL(-1, fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc, fake_perf_open_syscall,
			fake_perf_alloc_alloc, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_long_cb,
			fake_perf_open_int_cb, fake_perf_open_int_cb);
		require(rc == -12);
		require(fake_perf_alloc_alloc_calls == 1);
		require(proc.mckfd == &existing);
		mix_signed(digest, rc);

#undef PERF_OPEN_BODY_CALL
	}
	{
		const unsigned long alloc_nowait = 0x000002UL;
		const unsigned long hardware_type = 0;
		const unsigned long hw_cache_type = 3;
		const unsigned long raw_type = 4;
		const unsigned long unsupported_read_mask = 0x7;
		const unsigned long sample_sign_bit = 1UL << 63;
		struct fake_perf_read_thread thread = {
			.pmc_alloc_map = 1UL << 1,
		};
		struct fake_perf_read_event event = {
			.pid = -1,
			.counter_id = -1,
		};
		struct fake_perf_open_fd existing = {
			.fd = 44,
		};
		struct fake_perf_open_fd sfd = { 0 };
		struct fake_perf_open_process proc = {
			.mckfd_lock = 7,
			.mckfd = &existing,
		};
		struct fake_syscall_request request = {
			.number = 99,
			.args = { 1, 2, 3, 4, 5, 6 },
		};
		struct fake_perf_open_attr user_attr = {
			.type = 4,
			.sample_period = 123,
			.read_format = 0,
			.freq = 0,
		};
		struct fake_perf_open_attr scratch_attr;
		long rc;

#define PERF_OPEN_ENTRY_CALL(user_attr_ptr, validate_cpu, group_value, \
			     flags_value, copy_cb, freq_cb, event_alloc_cb, \
			     counter_cb, syscall_fn_cb, alloc_fn_cb) \
	perf_event_open_entry_body_result(&request, &thread, &proc, \
		&scratch_attr, (unsigned long)(user_attr_ptr), \
		sizeof(struct fake_perf_open_attr), \
		offsetof(struct fake_perf_open_attr, type), \
		offsetof(struct fake_perf_open_attr, read_format), \
		offsetof(struct fake_perf_open_attr, sample_period), \
		42, (validate_cpu), (group_value), (flags_value), 3, \
		raw_type, hardware_type, hw_cache_type, \
		unsupported_read_mask, sample_sign_bit, 298, \
		sizeof(struct fake_perf_open_fd), alloc_nowait, \
		offsetof(struct fake_perf_read_event, pid), \
		offsetof(struct fake_perf_read_event, counter_id), \
		offsetof(struct fake_perf_open_process, mckfd), \
		offsetof(struct fake_perf_open_fd, next), \
		offsetof(struct fake_perf_open_fd, fd), \
		offsetof(struct fake_perf_open_fd, data), \
		offsetof(struct fake_perf_read_event, group_leader), \
		offsetof(struct fake_perf_read_event, sibling_list), \
		offsetof(struct fake_perf_read_event, group_entry), \
		offsetof(struct fake_perf_read_event, nr_siblings), \
		offsetof(struct fake_perf_read_event, pmc_status), \
		offsetof(struct fake_perf_read_thread, pmc_alloc_map), \
		offsetof(struct fake_perf_open_process, mckfd_lock), \
		offsetof(struct fake_perf_open_fd, sig_no), \
		offsetof(struct fake_perf_open_fd, read_cb), \
		offsetof(struct fake_perf_open_fd, ioctl_cb), \
		offsetof(struct fake_perf_open_fd, mmap_cb), \
		offsetof(struct fake_perf_open_fd, close_cb), \
		offsetof(struct fake_perf_open_fd, fcntl_cb), \
		(copy_cb), (freq_cb), (event_alloc_cb), (counter_cb), \
		(syscall_fn_cb), (alloc_fn_cb), fake_perf_open_long_cb, \
		fake_perf_open_int_cb, fake_perf_open_long_cb, \
		fake_perf_open_int_cb, fake_perf_open_int_cb, \
		fake_perf_open_lock, fake_perf_open_unlock)

		memset(&scratch_attr, 0xa5, sizeof(scratch_attr));
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		fake_perf_open_counter_alloc_rc = 4;
		fake_perf_open_syscall_rc = 88;
		fake_perf_alloc_alloc_result = &sfd;
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 0, -1, 0,
			fake_perf_open_copy_from_user,
			fake_perf_open_attr_freq,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == 88);
		require(fake_perf_open_copy_calls == 1);
		require(fake_perf_open_copy_src == (unsigned long)&user_attr);
		require(fake_perf_open_copy_bytes == sizeof(user_attr));
		require(fake_perf_open_attr_freq_calls == 1);
		require(scratch_attr.type == user_attr.type);
		require(scratch_attr.sample_period == user_attr.sample_period);
		require(scratch_attr.read_format == user_attr.read_format);
		require(scratch_attr.freq == user_attr.freq);
		require(fake_perf_open_event_alloc_calls == 1);
		require(fake_perf_open_event_alloc_attr == &scratch_attr);
		require(event.pid == 42);
		require(event.counter_id == 4);
		require(event.group_leader == &event);
		require(event.pmc_status == (1UL << 4));
		require(request.number == 298);
		require(request.args[0] == 0);
		require(fake_perf_open_syscall_calls == 1);
		require(fake_perf_open_syscall_cpu == 3);
		require(thread.pmc_alloc_map == ((1UL << 1) | (1UL << 4)));
		require(fake_perf_alloc_alloc_calls == 1);
		require(fake_perf_alloc_alloc_size ==
			sizeof(struct fake_perf_open_fd));
		require(fake_perf_alloc_alloc_flags == alloc_nowait);
		require(sfd.fd == 88);
		require(sfd.sig_no == -1);
		require(sfd.data == (long)&event);
		require(sfd.read_cb == fake_perf_open_long_cb);
		require(proc.mckfd == &sfd);
		require(sfd.next == &existing);
		mix_signed(digest, rc);
		mix(digest, scratch_attr.type);
		mix(digest, scratch_attr.sample_period);
		mix_signed(digest, fake_perf_open_copy_calls);
		mix_signed(digest, fake_perf_open_attr_freq_calls);

		memset(&scratch_attr, 0, sizeof(scratch_attr));
		fake_perf_read_reset();
		fake_perf_open_copy_rc = -1;
		fake_perf_open_event_alloc_result = &event;
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 0, -1, 0,
			fake_perf_open_copy_from_user,
			fake_perf_open_attr_freq,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == -14);
		require(fake_perf_open_copy_calls == 1);
		require(fake_perf_open_attr_freq_calls == 0);
		require(fake_perf_open_event_alloc_calls == 0);
		mix_signed(digest, rc);

		user_attr.freq = 1;
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 0, -1, 0,
			fake_perf_open_copy_from_user,
			fake_perf_open_attr_freq,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == -2);
		require(fake_perf_open_copy_calls == 1);
		require(fake_perf_open_attr_freq_calls == 1);
		require(fake_perf_open_event_alloc_calls == 0);
		mix_signed(digest, rc);

		user_attr.freq = 0;
		user_attr.sample_period = sample_sign_bit;
		fake_perf_read_reset();
		fake_perf_open_event_alloc_result = &event;
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 4, -1, 0,
			fake_perf_open_copy_from_user,
			fake_perf_open_attr_freq,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == -22);
		require(fake_perf_open_copy_calls == 1);
		require(fake_perf_open_attr_freq_calls == 1);
		require(fake_perf_open_event_alloc_calls == 0);
		mix_signed(digest, rc);

		user_attr.sample_period = 123;
		fake_perf_read_reset();
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 0, -1, 0, NULL,
			fake_perf_open_attr_freq,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == -22);
		require(fake_perf_open_copy_calls == 0);
		require(fake_perf_open_attr_freq_calls == 0);
		require(fake_perf_open_event_alloc_calls == 0);
		mix_signed(digest, rc);

		fake_perf_read_reset();
		rc = PERF_OPEN_ENTRY_CALL(&user_attr, 0, -1, 0,
			fake_perf_open_copy_from_user, NULL,
			fake_perf_open_event_alloc,
			fake_perf_open_counter_alloc,
			fake_perf_open_syscall,
			fake_perf_alloc_alloc);
		require(rc == -22);
		require(fake_perf_open_copy_calls == 0);
		require(fake_perf_open_attr_freq_calls == 0);
		require(fake_perf_open_event_alloc_calls == 0);
		mix_signed(digest, rc);

#undef PERF_OPEN_ENTRY_CALL
	}
	require(terminate_process_exited_result(PS_EXITED) == 1);
	require(terminate_process_exited_result(PS_ZOMBIE) == 0);
	require(terminate_process_exited_result(PS_RUNNING) == 0);
	require(terminate_process_exited_result(0) == 0);
	require(terminate_thread_is_other_result(&digest, &digest) == 0);
	require(terminate_thread_is_other_result(&digest, NULL) == 1);
	require(terminate_thread_is_other_result(NULL, &digest) == 1);
	require(terminate_thread_is_other_result(NULL, NULL) == 0);
	require(terminate_report_thread_ptrace_result(0) == 0);
	require(terminate_report_thread_ptrace_result(1) == 1);
	require(terminate_report_thread_ptrace_result(-1) == 1);
	require(terminate_child_cleanup_needed_result(1, 1) == 0);
	require(terminate_child_cleanup_needed_result(0, 1) == 1);
	require(terminate_child_cleanup_needed_result(1, 0) == 1);
	require(terminate_child_cleanup_needed_result(0, 0) == 1);
	require(terminate_release_child_needed_result(0) == 0);
	require(terminate_release_child_needed_result(1) == 1);
	require(terminate_release_child_needed_result(-1) == 1);
	require(process_lookup_missing_result(NULL) == 1);
	require(process_lookup_missing_result(&digest) == 0);
	require(process_cleanup_tofu_needed_result(0) == 0);
	require(process_cleanup_tofu_needed_result(1) == 1);
	require(process_cleanup_tofu_needed_result(-1) == 1);
	require(process_cleanup_fd_path_free_needed_result(NULL) == 0);
	require(process_cleanup_fd_path_free_needed_result(&digest) == 1);
	require(terminate_host_detached_thread_release_needed_result(
		NULL, &digest) == 1);
	require(terminate_host_detached_thread_release_needed_result(
		&digest, &digest) == 0);
	require(terminate_host_detached_thread_release_needed_result(
		NULL, NULL) == 0);
	require(terminate_host_kill_needed_result(0) == 1);
	require(terminate_host_kill_needed_result(1) == 0);
	require(terminate_host_kill_needed_result(-1) == 1);
	{
		int proc = 0x1234;
		int lock_node = 0x4321;
		long rc;

		fake_process_cleanup_reset(&proc);
		fake_process_cleanup_cleanup_rc = -77;
		rc = process_cleanup_fd_body_result(501, 9, &lock_node,
			fake_process_cleanup_find, fake_process_cleanup_unlock,
			fake_process_cleanup_fd, fake_process_cleanup_missing_log);
		require(rc == 0);
		require(fake_process_cleanup_find_calls == 1);
		require(fake_process_cleanup_find_pid == 501);
		require(fake_process_cleanup_find_lock == &lock_node);
		require(fake_process_cleanup_cleanup_calls == 1);
		require(fake_process_cleanup_cleanup_proc == &proc);
		require(fake_process_cleanup_cleanup_fd == 9);
		require(fake_process_cleanup_unlock_calls == 1);
		require(fake_process_cleanup_unlock_proc == &proc);
		require(fake_process_cleanup_unlock_lock == &lock_node);
		require(fake_process_cleanup_cleanup_sequence <
			fake_process_cleanup_unlock_sequence);
		require(fake_process_cleanup_missing_log_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_process_cleanup_cleanup_calls);
		mix_signed(digest, fake_process_cleanup_unlock_calls);

		fake_process_cleanup_reset(NULL);
		rc = process_cleanup_fd_body_result(502, 10, &lock_node,
			fake_process_cleanup_find, fake_process_cleanup_unlock,
			fake_process_cleanup_fd, fake_process_cleanup_missing_log);
		require(rc == 0);
		require(fake_process_cleanup_find_calls == 1);
		require(fake_process_cleanup_find_pid == 502);
		require(fake_process_cleanup_cleanup_calls == 0);
		require(fake_process_cleanup_unlock_calls == 0);
		require(fake_process_cleanup_missing_log_calls == 1);
		require(fake_process_cleanup_missing_log_pid == 502);
		mix_signed(digest, rc);
		mix_signed(digest, fake_process_cleanup_missing_log_calls);

		fake_process_cleanup_reset(&proc);
		rc = process_cleanup_fd_body_result(503, 11, &lock_node,
			fake_process_cleanup_find, fake_process_cleanup_unlock,
			NULL, fake_process_cleanup_missing_log);
		require(rc == -22);
		require(fake_process_cleanup_cleanup_calls == 0);
		require(fake_process_cleanup_unlock_calls == 1);
		mix_signed(digest, rc);

		rc = process_cleanup_fd_body_result(504, 12, &lock_node,
			NULL, fake_process_cleanup_unlock,
			fake_process_cleanup_fd, fake_process_cleanup_missing_log);
		require(rc == -22);
		mix_signed(digest, rc);

		fake_process_cleanup_reset(&proc);
		rc = process_cleanup_before_terminate_body_result(601,
			&lock_node, 0, 2, 5, fake_process_cleanup_find,
			fake_process_cleanup_unlock, NULL);
		require(rc == 0);
		require(fake_process_cleanup_find_calls == 1);
		require(fake_process_cleanup_find_pid == 601);
		require(fake_process_cleanup_cleanup_calls == 0);
		require(fake_process_cleanup_unlock_calls == 1);
		mix_signed(digest, rc);
		mix_signed(digest, fake_process_cleanup_unlock_calls);

		fake_process_cleanup_reset(&proc);
		rc = process_cleanup_before_terminate_body_result(602,
			&lock_node, 1, 2, 5, fake_process_cleanup_find,
			fake_process_cleanup_unlock, fake_process_cleanup_fd);
		require(rc == 0);
		require(fake_process_cleanup_cleanup_calls == 3);
		require(fake_process_cleanup_cleanup_proc == &proc);
		require(fake_process_cleanup_cleanup_first_fd == 2);
		require(fake_process_cleanup_cleanup_last_fd == 4);
		require(fake_process_cleanup_cleanup_fd_sum == 9);
		require(fake_process_cleanup_unlock_calls == 1);
		require(fake_process_cleanup_cleanup_sequence <
			fake_process_cleanup_unlock_sequence);
		mix_signed(digest, rc);
		mix_signed(digest, fake_process_cleanup_cleanup_calls);
		mix_signed(digest, fake_process_cleanup_cleanup_fd_sum);

		fake_process_cleanup_reset(NULL);
		rc = process_cleanup_before_terminate_body_result(603,
			&lock_node, 1, 2, 5, fake_process_cleanup_find,
			fake_process_cleanup_unlock, fake_process_cleanup_fd);
		require(rc == 0);
		require(fake_process_cleanup_cleanup_calls == 0);
		require(fake_process_cleanup_unlock_calls == 0);
		mix_signed(digest, rc);

		fake_process_cleanup_reset(&proc);
		rc = process_cleanup_before_terminate_body_result(604,
			&lock_node, 1, 2, 5, fake_process_cleanup_find,
			fake_process_cleanup_unlock, NULL);
		require(rc == -22);
		require(fake_process_cleanup_cleanup_calls == 0);
		require(fake_process_cleanup_unlock_calls == 1);
		mix_signed(digest, rc);

		rc = process_cleanup_before_terminate_body_result(605,
			&lock_node, 1, 2, 5, fake_process_cleanup_find,
			NULL, fake_process_cleanup_fd);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	{
		struct fake_terminate_host_process proc = {
			.nohost = 0,
		};
		struct fake_terminate_host_process detached_proc = {
			.nohost = 7,
		};
		struct fake_terminate_host_thread detached_thread = {
			.proc = &detached_proc,
			.refcount = 44,
		};
		int lock_node = 0x4321;
		int current_thread = 0x8765;
		long rc;

		fake_terminate_host_find_calls = 0;
		fake_terminate_host_find_pid = -1;
		fake_terminate_host_find_lock = NULL;
		fake_terminate_host_find_result = &proc;
		fake_terminate_host_unlock_calls = 0;
		fake_terminate_host_unlock_proc = NULL;
		fake_terminate_host_unlock_lock = NULL;
		fake_terminate_host_ref_set_calls = 0;
		fake_terminate_host_release_thread_calls = 0;
		fake_terminate_host_release_process_calls = 0;
		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = -66;
		rc = terminate_host_body_result(123, &detached_thread,
			&current_thread, &lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			fake_terminate_host_find, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process,
			fake_do_kill_thread);
		require(rc == -66);
		require(fake_terminate_host_find_calls == 1);
		require(fake_terminate_host_find_pid == 123);
		require(fake_terminate_host_find_lock == &lock_node);
		require(proc.nohost == 1);
		require(fake_terminate_host_unlock_calls == 1);
		require(fake_terminate_host_unlock_proc == &proc);
		require(fake_terminate_host_unlock_lock == &lock_node);
		require(fake_do_kill_thread_calls == 1);
		require(fake_do_kill_thread_current == &current_thread);
		require(fake_do_kill_thread_pid == 123);
		require(fake_do_kill_thread_tid == -1);
		require(fake_do_kill_thread_sig == SIGKILL);
		require(fake_do_kill_thread_ptracecont == 0);
		require(fake_terminate_host_ref_set_calls == 0);
		require(fake_terminate_host_release_thread_calls == 0);
		require(fake_terminate_host_release_process_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, proc.nohost);
		mix_signed(digest, fake_terminate_host_find_calls);
		mix_signed(digest, fake_terminate_host_unlock_calls);
		mix_signed(digest, fake_do_kill_thread_calls);

		proc.nohost = 1;
		fake_terminate_host_find_calls = 0;
		fake_terminate_host_find_result = &proc;
		fake_terminate_host_unlock_calls = 0;
		fake_do_kill_thread_calls = 0;
		rc = terminate_host_body_result(124, &detached_thread,
			&current_thread, &lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			fake_terminate_host_find, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process,
			fake_do_kill_thread);
		require(rc == 0);
		require(proc.nohost == 1);
		require(fake_terminate_host_unlock_calls == 1);
		require(fake_do_kill_thread_calls == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_kill_thread_calls);

		detached_thread.refcount = 44;
		fake_terminate_host_find_result = NULL;
		fake_terminate_host_unlock_calls = 0;
		fake_terminate_host_ref_set_calls = 0;
		fake_terminate_host_ref_set_ptr = NULL;
		fake_terminate_host_ref_set_value = 0;
		fake_terminate_host_release_thread_calls = 0;
		fake_terminate_host_release_thread_ptr = NULL;
		fake_terminate_host_release_process_calls = 0;
		fake_terminate_host_release_process_ptr = NULL;
		rc = terminate_host_body_result(125, &detached_thread,
			&current_thread, &lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			fake_terminate_host_find, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process,
			fake_do_kill_thread);
		require(rc == 0);
		require(detached_thread.refcount == 1);
		require(fake_terminate_host_unlock_calls == 0);
		require(fake_terminate_host_ref_set_calls == 1);
		require(fake_terminate_host_ref_set_ptr ==
			&detached_thread.refcount);
		require(fake_terminate_host_ref_set_value == 1);
		require(fake_terminate_host_release_thread_calls == 1);
		require(fake_terminate_host_release_thread_ptr ==
			&detached_thread);
		require(fake_terminate_host_release_process_calls == 1);
		require(fake_terminate_host_release_process_ptr ==
			&detached_proc);
		mix_signed(digest, rc);
		mix_signed(digest, detached_thread.refcount);
		mix_signed(digest, fake_terminate_host_ref_set_calls);
		mix_signed(digest, fake_terminate_host_release_thread_calls);
		mix_signed(digest, fake_terminate_host_release_process_calls);

		fake_terminate_host_find_result = NULL;
		fake_terminate_host_ref_set_calls = 0;
		fake_terminate_host_release_thread_calls = 0;
		fake_terminate_host_release_process_calls = 0;
		rc = terminate_host_body_result(126, NULL, &current_thread,
			&lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			fake_terminate_host_find, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process,
			fake_do_kill_thread);
		require(rc == 0);
		require(fake_terminate_host_ref_set_calls == 0);
		require(fake_terminate_host_release_thread_calls == 0);
		require(fake_terminate_host_release_process_calls == 0);
		mix_signed(digest, rc);

		proc.nohost = 0;
		fake_terminate_host_find_result = &proc;
		fake_terminate_host_unlock_calls = 0;
		rc = terminate_host_body_result(127, &detached_thread,
			&current_thread, &lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			fake_terminate_host_find, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process, NULL);
		require(rc == -22);
		require(proc.nohost == 0);
		require(fake_terminate_host_unlock_calls == 1);
		mix_signed(digest, rc);

		rc = terminate_host_body_result(128, &detached_thread,
			&current_thread, &lock_node,
			offsetof(struct fake_terminate_host_process, nohost),
			offsetof(struct fake_terminate_host_thread, proc),
			offsetof(struct fake_terminate_host_thread, refcount),
			NULL, fake_terminate_host_unlock,
			fake_terminate_host_ref_set,
			fake_terminate_host_release_thread,
			fake_terminate_host_release_process,
			fake_do_kill_thread);
		require(rc == -22);
		mix_signed(digest, rc);
	}
	require(finalize_process_parent_is_pid1_result(&digest, &digest) == 1);
	require(finalize_process_parent_is_pid1_result(&digest, NULL) == 0);
	require(finalize_process_parent_is_pid1_result(NULL, &digest) == 0);
	require(finalize_process_parent_is_pid1_result(NULL, NULL) == 1);
	require(finalize_process_parent_signal_needed_result(0) == 0);
	require(finalize_process_parent_signal_needed_result(17) == 1);
	require(finalize_process_parent_signal_needed_result(-1) == 1);
	mix_signed(digest, thread_exit_signal_report_needed_result(&digest));
	mix_signed(digest, terminate_group_status_update_failed_result(
		0x1235, 0x1234));
	mix_signed(digest, terminate_host_exit_needed_result(0));
	mix_signed(digest, terminate_host_exit_needed_result(1));
	mix_signed(digest, sync_child_event_needed_result(1, 1, 0));
	mix_signed(digest, sync_child_event_needed_result(1, 0, 0));
	mix_signed(digest, sync_child_event_pid_action_result(0));
	mix_signed(digest, sync_child_event_pid_action_result(7));
	mix_signed(digest, terminate_process_exited_result(PS_EXITED));
	mix_signed(digest, terminate_process_exited_result(PS_ZOMBIE));
	mix_signed(digest, terminate_thread_is_other_result(&digest, NULL));
	mix_signed(digest, terminate_report_thread_ptrace_result(1));
	mix_signed(digest, terminate_child_cleanup_needed_result(0, 1));
	mix_signed(digest, terminate_release_child_needed_result(1));
	mix_signed(digest, process_lookup_missing_result(NULL));
	mix_signed(digest, process_cleanup_tofu_needed_result(1));
	mix_signed(digest, process_cleanup_fd_path_free_needed_result(&digest));
	mix_signed(digest, terminate_host_detached_thread_release_needed_result(
		NULL, &digest));
	mix_signed(digest, terminate_host_kill_needed_result(-1));
	mix_signed(digest, finalize_process_parent_is_pid1_result(&digest, &digest));
	mix_signed(digest, finalize_process_parent_signal_needed_result(17));
	for (unsigned int rc = 0; rc < sizeof(exit_codes) / sizeof(exit_codes[0]); rc++) {
		for (unsigned int sig = 0; sig < sizeof(exit_codes) / sizeof(exit_codes[0]); sig++)
			mix_signed(digest, terminate_status_result(
				exit_codes[rc], exit_codes[sig]));
	}
	for (unsigned int same = 0; same < sizeof(bools) / sizeof(bools[0]); same++) {
		for (unsigned int sig = 0; sig < sizeof(exit_codes) / sizeof(exit_codes[0]); sig++)
			mix_signed(digest, terminate_report_thread_release_needed_result(
				bools[same], exit_codes[sig]));
	}
	for (unsigned int ppid = 0; ppid < sizeof(bools) / sizeof(bools[0]); ppid++) {
		for (unsigned int parent = 0; parent < sizeof(bools) / sizeof(bools[0]); parent++) {
			for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++)
				mix_signed(digest, terminate_child_action_result(
					bools[ppid], bools[parent],
					statuses[s]));
		}
	}

	for (unsigned int i = 0; i < sizeof(itimers) / sizeof(itimers[0]); i++) {
		mix_signed(digest, itimer_which_result(itimers[i]));
		mix_signed(digest, itimer_is_real(itimers[i]));
	}

	for (unsigned int i = 0; i < sizeof(timeval_pairs) / sizeof(timeval_pairs[0]); i++)
		mix_signed(digest, itimer_should_start(timeval_pairs[i][0],
			timeval_pairs[i][1]));

	{
		static const struct fake_itimer_offsets itimer_offsets = {
			.thread_itimer_enabled_offset =
				offsetof(struct fake_itimer_thread, itimer_enabled),
			.thread_itimer_virtual_offset =
				offsetof(struct fake_itimer_thread, itimer_virtual),
			.thread_itimer_prof_offset =
				offsetof(struct fake_itimer_thread, itimer_prof),
			.thread_itimer_virtual_value_offset =
				offsetof(struct fake_itimer_thread, itimer_virtual_value),
			.thread_itimer_prof_value_offset =
				offsetof(struct fake_itimer_thread, itimer_prof_value),
		};
		struct fake_itimer_thread thread;
		struct fake_itimerval new_timer;
		struct fake_itimerval out_timer;
		struct fake_itimerval snapshot;
		long rc;

		memset(&thread, 0, sizeof(thread));
		thread.itimer_virtual.it_interval.tv_sec = 2;
		thread.itimer_virtual.it_interval.tv_usec = 25;
		thread.itimer_virtual.it_value.tv_sec = 5;
		thread.itimer_virtual.it_value.tv_usec = 750000;
		thread.itimer_virtual_value.tv_sec = 1;
		thread.itimer_virtual_value.tv_nsec = 250000000;
		itimer_snapshot_current_result(
			(unsigned long)(uintptr_t)&thread.itimer_virtual,
			(unsigned long)(uintptr_t)&thread.itimer_virtual_value,
			(unsigned long)(uintptr_t)&snapshot);
		require(snapshot.it_value.tv_sec == 4);
		require(snapshot.it_value.tv_usec == 500000);
		mix_signed(digest, snapshot.it_value.tv_sec);
		mix_signed(digest, snapshot.it_value.tv_usec);

		fake_syscall3_calls = 0;
		fake_syscall3_rc = -70;
		rc = setitimer_body_result(ITIMER_REAL, 0x1111, 0x2222,
			&thread, &itimer_offsets, 38, fake_do_syscall3,
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_set_timer);
		require(rc == -70);
		require(fake_syscall3_calls == 1);
		require(fake_syscall3_nr == 38);
		require(fake_syscall3_arg0 == ITIMER_REAL);
		require(fake_syscall3_arg1 == 0x1111);
		require(fake_syscall3_arg2 == 0x2222);
		mix_signed(digest, rc);
		mix_signed(digest, fake_syscall3_calls);

		fake_syscall3_calls = 0;
		rc = setitimer_body_result(99, 0, 0, &thread, &itimer_offsets,
			38, fake_do_syscall3, fake_copy_stack_from_user,
			fake_copy_stack_to_user, fake_set_timer);
		require(rc == -22);
		require(fake_syscall3_calls == 0);
		mix_signed(digest, rc);

		new_timer.it_interval.tv_sec = 0;
		new_timer.it_interval.tv_usec = 100;
		new_timer.it_value.tv_sec = 3;
		new_timer.it_value.tv_usec = 0;
		memset(&out_timer, 0, sizeof(out_timer));
		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		fake_set_timer_calls = 0;
		rc = setitimer_body_result(ITIMER_VIRTUAL,
			(unsigned long)(uintptr_t)&new_timer,
			(unsigned long)(uintptr_t)&out_timer, &thread,
			&itimer_offsets, 38, fake_do_syscall3,
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_set_timer);
		require(rc == 0);
		require(fake_stack_copy_to_calls == 1);
		require(fake_stack_copy_from_calls == 1);
		require(fake_set_timer_calls == 1);
		require(fake_set_timer_runq_locked == 0);
		require(out_timer.it_value.tv_sec == 4);
		require(out_timer.it_value.tv_usec == 500000);
		require(thread.itimer_virtual.it_value.tv_sec == 3);
		require(thread.itimer_virtual_value.tv_sec == 0);
		require(thread.itimer_virtual_value.tv_nsec == 0);
		require(thread.itimer_enabled == 1);
		mix_signed(digest, rc);
		mix_signed(digest, out_timer.it_value.tv_sec);
		mix_signed(digest, thread.itimer_enabled);

		thread.itimer_prof.it_value.tv_sec = 0;
		thread.itimer_prof.it_value.tv_usec = 7;
		thread.itimer_prof_value.tv_sec = 0;
		thread.itimer_prof_value.tv_nsec = 2000;
		memset(&out_timer, 0, sizeof(out_timer));
		fake_stack_copy_to_calls = 0;
		fake_set_timer_calls = 0;
		rc = setitimer_body_result(ITIMER_PROF, 0,
			(unsigned long)(uintptr_t)&out_timer, &thread,
			&itimer_offsets, 38, fake_do_syscall3,
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_set_timer);
		require(rc == 0);
		require(fake_stack_copy_to_calls == 1);
		require(fake_set_timer_calls == 0);
		require(out_timer.it_value.tv_sec == 0);
		require(out_timer.it_value.tv_usec == 5);
		mix_signed(digest, out_timer.it_value.tv_usec);

		fake_stack_copy_from_fail = 1;
		fake_set_timer_calls = 0;
		rc = setitimer_body_result(ITIMER_PROF,
			(unsigned long)(uintptr_t)&new_timer, 0, &thread,
			&itimer_offsets, 38, fake_do_syscall3,
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_set_timer);
		require(rc == -14);
		require(fake_set_timer_calls == 0);
		fake_stack_copy_from_fail = 0;
		mix_signed(digest, rc);

		fake_syscall2_calls = 0;
		fake_syscall2_rc = -71;
		rc = getitimer_body_result(ITIMER_REAL, 0x3333, &thread,
			&itimer_offsets, 36, fake_do_syscall2,
			fake_copy_stack_to_user);
		require(rc == -71);
		require(fake_syscall2_calls == 1);
		require(fake_syscall2_nr == 36);
		require(fake_syscall2_arg0 == ITIMER_REAL);
		require(fake_syscall2_arg1 == 0x3333);
		mix_signed(digest, rc);
		mix_signed(digest, fake_syscall2_calls);
		fake_syscall2_rc = 0;

		memset(&out_timer, 0, sizeof(out_timer));
		fake_stack_copy_to_calls = 0;
		rc = getitimer_body_result(ITIMER_PROF,
			(unsigned long)(uintptr_t)&out_timer, &thread,
			&itimer_offsets, 36, fake_do_syscall2,
			fake_copy_stack_to_user);
		require(rc == 0);
		require(fake_stack_copy_to_calls == 1);
		require(out_timer.it_value.tv_usec == 5);
		mix_signed(digest, out_timer.it_value.tv_usec);

		fake_stack_copy_to_fail = 1;
		rc = getitimer_body_result(ITIMER_PROF,
			(unsigned long)(uintptr_t)&out_timer, &thread,
			&itimer_offsets, 36, fake_do_syscall2,
			fake_copy_stack_to_user);
		require(rc == -14);
		fake_stack_copy_to_fail = 0;
		mix_signed(digest, rc);

		fake_stack_copy_to_calls = 0;
		rc = getitimer_body_result(ITIMER_VIRTUAL, 0, &thread,
			&itimer_offsets, 36, fake_do_syscall2,
			fake_copy_stack_to_user);
		require(rc == 0);
		require(fake_stack_copy_to_calls == 0);
		mix_signed(digest, rc);
	}

	for (unsigned int c = 0; c < sizeof(clock_ids) / sizeof(clock_ids[0]); c++) {
		for (unsigned int l = 0; l < sizeof(bools) / sizeof(bools[0]); l++) {
			for (unsigned int t = 0; t < sizeof(bools) / sizeof(bools[0]); t++)
				mix_signed(digest, clock_gettime_dispatch(clock_ids[c],
					bools[l], bools[t]));
		}
	}

	{
		static const struct fake_cputime_offsets cputime_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_cputime_thread, proc),
			.thread_status_offset =
				offsetof(struct fake_cputime_thread, status),
			.thread_in_kernel_offset =
				offsetof(struct fake_cputime_thread, in_kernel),
			.thread_cpu_id_offset =
				offsetof(struct fake_cputime_thread, cpu_id),
			.thread_times_update_offset =
				offsetof(struct fake_cputime_thread, times_update),
			.thread_user_tsc_offset =
				offsetof(struct fake_cputime_thread, user_tsc),
			.thread_system_tsc_offset =
				offsetof(struct fake_cputime_thread, system_tsc),
			.thread_siblings_list_offset =
				offsetof(struct fake_cputime_thread, siblings_list),
			.proc_threads_list_offset =
				offsetof(struct fake_cputime_process, threads_list),
			.proc_utime_offset =
				offsetof(struct fake_cputime_process, utime),
			.proc_stime_offset =
				offsetof(struct fake_cputime_process, stime),
			.proc_utime_children_offset =
				offsetof(struct fake_cputime_process, utime_children),
			.proc_stime_children_offset =
				offsetof(struct fake_cputime_process, stime_children),
			.proc_maxrss_offset =
				offsetof(struct fake_cputime_process, maxrss),
			.proc_maxrss_children_offset =
				offsetof(struct fake_cputime_process, maxrss_children),
		};
		struct fake_cputime_process proc;
		struct fake_cputime_thread threads[3];
		struct rusage usage;
		struct timespec ts_out;
		int lock_cookie;
		long rc;

		memset(&proc, 0, sizeof(proc));
		memset(threads, 0, sizeof(threads));
		fake_cputime_list_init(&proc.threads_list);
		proc.utime.tv_sec = 1;
		proc.utime.tv_nsec = 900000000;
		proc.stime.tv_sec = 2;
		proc.stime.tv_nsec = 200000000;
		proc.utime_children.tv_sec = 7;
		proc.utime_children.tv_nsec = 8000;
		proc.stime_children.tv_sec = 8;
		proc.stime_children.tv_nsec = 9000;
		proc.maxrss = 409600;
		proc.maxrss_children = 819200;

		for (int i = 0; i < 3; i++) {
			threads[i].cpu_id = i;
			threads[i].proc = &proc;
			fake_cputime_list_init(&threads[i].siblings_list);
			fake_cputime_list_add_tail(&threads[i].siblings_list,
						   &proc.threads_list);
		}
		threads[0].status = PS_RUNNING;
		threads[0].user_tsc = 500;
		threads[0].system_tsc = 250;
		threads[1].status = PS_RUNNING;
		threads[1].user_tsc = 1250;
		threads[1].system_tsc = 750;
		threads[2].status = PS_STOPPED;
		threads[2].user_tsc = 250;
		threads[2].system_tsc = 100;

		memset(fake_cputime_by_cpu, 0, sizeof(fake_cputime_by_cpu));
		for (int i = 0; i < 3; i++)
			fake_cputime_by_cpu[i] = &threads[i];
		fake_cputime_lock_calls = 0;
		fake_cputime_unlock_calls = 0;
		fake_cputime_interrupt_calls = 0;
		fake_cputime_copy_calls = 0;
		fake_cputime_copy_fail = 0;
		fake_cputime_pause_calls = 0;
		fake_cputime_interrupt_digest = 0x63707574696d6521UL;
		lock_cookie = 0;
		rc = getrusage_body_result(RUSAGE_SELF,
			(unsigned long)(uintptr_t)&usage, &threads[0], 1000,
			&cputime_offsets, fake_cputime_lock,
			fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause,
			fake_cputime_copy_to_user);
		require(rc == 0);
		require(lock_cookie == 0);
		require(fake_cputime_lock_calls == 1);
		require(fake_cputime_unlock_calls == 1);
		require(fake_cputime_interrupt_calls == 1);
		require(fake_cputime_copy_calls == 1);
		require(threads[1].times_update == 1);
		require(usage.ru_utime.tv_sec == 3);
		require(usage.ru_utime.tv_usec == 900000);
		require(usage.ru_stime.tv_sec == 3);
		require(usage.ru_stime.tv_usec == 300000);
		require(usage.ru_maxrss == 400);
		mix_signed(digest, rc);
		mix_signed(digest, fake_cputime_interrupt_calls);
		mix(digest, fake_cputime_interrupt_digest);
		mix_signed(digest, usage.ru_utime.tv_sec);
		mix_signed(digest, usage.ru_stime.tv_usec);
		mix_signed(digest, usage.ru_maxrss);

		fake_cputime_copy_calls = 0;
		rc = getrusage_body_result(RUSAGE_CHILDREN,
			(unsigned long)(uintptr_t)&usage, &threads[0], 1000,
			&cputime_offsets, fake_cputime_lock,
			fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause,
			fake_cputime_copy_to_user);
		require(rc == 0);
		require(fake_cputime_copy_calls == 1);
		require(usage.ru_utime.tv_sec == 7);
		require(usage.ru_utime.tv_usec == 8);
		require(usage.ru_stime.tv_sec == 8);
		require(usage.ru_stime.tv_usec == 9);
		require(usage.ru_maxrss == 800);
		mix_signed(digest, rc);
		mix_signed(digest, usage.ru_utime.tv_usec);
		mix_signed(digest, usage.ru_stime.tv_usec);
		mix_signed(digest, usage.ru_maxrss);

		fake_cputime_copy_calls = 0;
		rc = getrusage_body_result(RUSAGE_THREAD,
			(unsigned long)(uintptr_t)&usage, &threads[0], 1000,
			&cputime_offsets, fake_cputime_lock,
			fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause,
			fake_cputime_copy_to_user);
		require(rc == 0);
		require(fake_cputime_copy_calls == 1);
		require(usage.ru_utime.tv_sec == 0);
		require(usage.ru_utime.tv_usec == 500000);
		require(usage.ru_stime.tv_sec == 0);
		require(usage.ru_stime.tv_usec == 250000);
		require(usage.ru_maxrss == 400);
		mix_signed(digest, rc);
		mix_signed(digest, usage.ru_utime.tv_usec);
		mix_signed(digest, usage.ru_stime.tv_usec);

		fake_cputime_copy_fail = 1;
		rc = getrusage_body_result(RUSAGE_THREAD,
			(unsigned long)(uintptr_t)&usage, &threads[0], 1000,
			&cputime_offsets, fake_cputime_lock,
			fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause,
			fake_cputime_copy_to_user);
		require(rc == -14);
		fake_cputime_copy_fail = 0;
		mix_signed(digest, rc);

		rc = getrusage_body_result(9, (unsigned long)(uintptr_t)&usage,
			&threads[0], 1000, &cputime_offsets,
			fake_cputime_lock, fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause,
			fake_cputime_copy_to_user);
		require(rc == -22);
		mix_signed(digest, rc);

		fake_gettime_calls = 0;
		fake_cputime_copy_calls = 0;
		memset(&ts_out, 0, sizeof(ts_out));
		rc = clock_gettime_body_result(CLOCK_REALTIME,
			(unsigned long)(uintptr_t)&ts_out, 1, 228, &threads[0],
			1000, &cputime_offsets, fake_gettime,
			fake_cputime_copy_to_user, fake_do_syscall2,
			fake_cputime_lock, fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause);
		require(rc == 0);
		require(fake_gettime_calls == 1);
		require(fake_cputime_copy_calls == 1);
		require(ts_out.tv_sec == 12);
		require(ts_out.tv_nsec == 345678900);
		mix_signed(digest, rc);
		mix_signed(digest, fake_gettime_calls);
		mix_signed(digest, ts_out.tv_sec);
		mix_signed(digest, ts_out.tv_nsec);

		fake_syscall2_calls = 0;
		fake_syscall2_rc = -66;
		rc = clock_gettime_body_result(CLOCK_MONOTONIC,
			(unsigned long)(uintptr_t)&ts_out, 0, 228, &threads[0],
			1000, &cputime_offsets, fake_gettime,
			fake_cputime_copy_to_user, fake_do_syscall2,
			fake_cputime_lock, fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause);
		require(rc == -66);
		require(fake_syscall2_calls == 1);
		require(fake_syscall2_nr == 228);
		require(fake_syscall2_arg0 == CLOCK_MONOTONIC);
		require(fake_syscall2_arg1 == (unsigned long)(uintptr_t)&ts_out);
		mix_signed(digest, rc);
		mix_signed(digest, fake_syscall2_nr);
		mix_signed(digest,
			fake_syscall2_arg1 == (unsigned long)(uintptr_t)&ts_out);
		fake_syscall2_rc = 0;

		fake_cputime_copy_calls = 0;
		memset(&ts_out, 0, sizeof(ts_out));
		rc = clock_gettime_body_result(CLOCK_THREAD_CPUTIME_ID,
			(unsigned long)(uintptr_t)&ts_out, 1, 228, &threads[0],
			1000, &cputime_offsets, fake_gettime,
			fake_cputime_copy_to_user, fake_do_syscall2,
			fake_cputime_lock, fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause);
		require(rc == 0);
		require(fake_cputime_copy_calls == 1);
		require(ts_out.tv_sec == 0);
		require(ts_out.tv_nsec == 750000000);
		mix_signed(digest, rc);
		mix_signed(digest, ts_out.tv_sec);
		mix_signed(digest, ts_out.tv_nsec);

		for (int i = 0; i < 3; i++)
			threads[i].times_update = 9;
		fake_cputime_lock_calls = 0;
		fake_cputime_unlock_calls = 0;
		fake_cputime_interrupt_calls = 0;
		fake_cputime_copy_calls = 0;
		fake_cputime_pause_calls = 0;
		fake_cputime_interrupt_digest = 0x63707574696d6521UL;
		memset(&ts_out, 0, sizeof(ts_out));
		rc = clock_gettime_body_result(CLOCK_PROCESS_CPUTIME_ID,
			(unsigned long)(uintptr_t)&ts_out, 1, 228, &threads[0],
			1000, &cputime_offsets, fake_gettime,
			fake_cputime_copy_to_user, fake_do_syscall2,
			fake_cputime_lock, fake_cputime_unlock, &lock_cookie,
			fake_cputime_interrupt, fake_cputime_pause);
		require(rc == 0);
		require(fake_cputime_lock_calls == 1);
		require(fake_cputime_unlock_calls == 1);
		require(fake_cputime_interrupt_calls == 1);
		require(fake_cputime_copy_calls == 1);
		require(ts_out.tv_sec == 7);
		require(ts_out.tv_nsec == 200000000);
		mix_signed(digest, rc);
		mix_signed(digest, fake_cputime_interrupt_calls);
		mix_signed(digest, ts_out.tv_sec);
		mix_signed(digest, ts_out.tv_nsec);

		rc = clock_gettime_body_result(CLOCK_PROCESS_CPUTIME_ID, 0, 1,
			228, NULL, 1000, NULL, NULL, NULL, NULL, NULL, NULL,
			NULL, NULL, NULL);
		require(rc == 0);
		mix_signed(digest, rc);
	}

	for (unsigned int tv = 0; tv < sizeof(bools) / sizeof(bools[0]); tv++) {
		for (unsigned int tz = 0; tz < sizeof(bools) / sizeof(bools[0]); tz++) {
			for (unsigned int l = 0; l < sizeof(bools) / sizeof(bools[0]); l++)
				mix_signed(digest, gettimeofday_dispatch(bools[tv],
					bools[tz], bools[l]));
		}
	}

	for (unsigned int i = 0; i < sizeof(timespecs) / sizeof(timespecs[0]); i++)
		mix_signed(digest, nanosleep_validate_timespec(timespecs[i][0],
			timespecs[i][1]));
}

static void exercise_signal_wait_policy(unsigned long *digest)
{
	static const size_t sigset_sizes[] = {
		0, sizeof(unsigned long), sizeof(unsigned long) + 1,
	};
	static const unsigned long masks[] = {
		0, 1, 2, SIGKILL_MASK, SIGSTOP_MASK,
		SIGKILL_MASK | SIGSTOP_MASK | 0x55UL, 0x8000000000000000UL,
	};
	static const long timeouts[][2] = {
		{ 0, 0 },
		{ 0, 1 },
		{ 1, 999999999L },
		{ 1, NS_PER_SEC },
		{ -1, 0 },
		{ 0, -1 },
	};
	static const long deadlines[][4] = {
		{ 10, 20, 0, 0 },
		{ 10, 999999999L, 0, 1 },
		{ 10, 900000000L, 1, 200000000L },
	};
	static const long expiry[][4] = {
		{ 9, 999999999L, 10, 0 },
		{ 10, 0, 10, 0 },
		{ 10, 1, 10, 0 },
		{ 11, 0, 10, 999999999L },
	};
	static const int flags[] = { 0, SS_DISABLE, 1, 3 };
	static const size_t stack_sizes[] = { 0, MINSIGSTKSZ - 1, MINSIGSTKSZ,
		MINSIGSTKSZ + 1 };
	static const int pids[] = { -1, 0, 1, 99 };
	static const int sigs[] = { 1, SIGCHLD, SIGCONT, SIGURG, 9, 64 };
	static const unsigned long handlers[] = { 0, SIG_IGN_HANDLER, 0x1000 };
	static const int bools[] = { 0, 1 };

	for (unsigned int s = 0; s < sizeof(sigset_sizes) / sizeof(sigset_sizes[0]); s++) {
		mix_signed(digest, rt_sigtimedwait_prepare(sigset_sizes[s],
			sizeof(unsigned long), 0));
		mix_signed(digest, rt_sigtimedwait_prepare(sigset_sizes[s],
			sizeof(unsigned long), 1));
		mix_signed(digest, sigsuspend_sigsetsize_result(sigset_sizes[s],
			sizeof(unsigned long)));
		mix_signed(digest, sigaction_sigsetsize_result(sigset_sizes[s],
			sizeof(unsigned long)));
	}

	for (unsigned int i = 0; i < sizeof(timeouts) / sizeof(timeouts[0]); i++) {
		mix_signed(digest, rt_sigtimedwait_timeout_result(timeouts[i][0],
			timeouts[i][1], 0));
		mix_signed(digest, rt_sigtimedwait_timeout_result(timeouts[i][0],
			timeouts[i][1], 1));
	}

	for (unsigned int raw = 0; raw < sizeof(masks) / sizeof(masks[0]); raw++) {
		for (unsigned int cur = 0; cur < sizeof(masks) / sizeof(masks[0]); cur++) {
			unsigned long wait_mask = 0;
			unsigned long blocked_mask = 0;
			unsigned long interrupt_mask = 0;

			rt_sigtimedwait_prepare_masks(masks[raw], masks[cur],
				&wait_mask, &blocked_mask, &interrupt_mask);
			mix(digest, wait_mask);
			mix(digest, blocked_mask);
			mix(digest, interrupt_mask);
			mix(digest, sigsuspend_prepare_mask(masks[raw]));
			mix_signed(digest, sigsuspend_pending_matches(masks[cur],
				wait_mask));
		}
		mix_signed(digest, sigmask_to_signal_number(masks[raw]));
	}

	for (unsigned int i = 0; i < sizeof(deadlines) / sizeof(deadlines[0]); i++) {
		long sec = 0;
		long nsec = 0;

		rt_sigtimedwait_deadline(deadlines[i][0], deadlines[i][1],
			deadlines[i][2], deadlines[i][3], &sec, &nsec);
		mix_signed(digest, sec);
		mix_signed(digest, nsec);
	}

	for (unsigned int i = 0; i < sizeof(expiry) / sizeof(expiry[0]); i++)
		mix_signed(digest, rt_sigtimedwait_timeout_expired(expiry[i][0],
			expiry[i][1], expiry[i][2], expiry[i][3]));

	for (unsigned int i = 0; i < sizeof(pids) / sizeof(pids[0]); i++)
		mix_signed(digest, rt_sigqueueinfo_pid_result(pids[i]));

	for (unsigned int s = 0; s < sizeof(sigs) / sizeof(sigs[0]); s++) {
		for (unsigned int h = 0; h < sizeof(handlers) / sizeof(handlers[0]); h++) {
			for (unsigned int p = 0; p < sizeof(masks) / sizeof(masks[0]); p++) {
				for (unsigned int b = 0; b < sizeof(masks) / sizeof(masks[0]); b++) {
					for (unsigned int d = 0; d < sizeof(bools) / sizeof(bools[0]); d++) {
						mix_signed(digest,
							signal_pending_deliverable_result(
								bools[d], sigs[s],
								handlers[h],
								masks[p], masks[b]));
						mix_signed(digest,
							signal_pending_interrupt_action_result(
								sigs[s], handlers[h],
								masks[p], masks[b],
								bools[d]));
					}
				}
			}
		}
	}

	for (unsigned int f = 0; f < sizeof(flags) / sizeof(flags[0]); f++) {
		for (unsigned int s = 0; s < sizeof(stack_sizes) / sizeof(stack_sizes[0]); s++)
			mix_signed(digest, sigaltstack_validate(flags[f],
				stack_sizes[s]));
		mix_signed(digest, sigaltstack_is_disable(flags[f]));
	}
}

struct fake_ptrace_syscall_case {
	long request;
	int dispatch;
};

static void exercise_ptrace_syscall_body(unsigned long *digest)
{
	static const struct fake_ptrace_syscall_case cases[] = {
		{ PTRACE_TRACEME, PTRACE_DISPATCH_TRACEME },
		{ PTRACE_CONT, PTRACE_DISPATCH_WAKEUP },
		{ PTRACE_KILL, PTRACE_DISPATCH_WAKEUP },
		{ PTRACE_SINGLESTEP, PTRACE_DISPATCH_WAKEUP },
		{ PTRACE_SYSCALL, PTRACE_DISPATCH_WAKEUP },
		{ PTRACE_GETREGS, PTRACE_DISPATCH_GETREGS },
		{ PTRACE_SETREGS, PTRACE_DISPATCH_SETREGS },
		{ PTRACE_GETFPREGS, PTRACE_DISPATCH_GETFPREGS },
		{ PTRACE_SETFPREGS, PTRACE_DISPATCH_SETFPREGS },
		{ PTRACE_PEEKUSER, PTRACE_DISPATCH_PEEKUSER },
		{ PTRACE_POKEUSER, PTRACE_DISPATCH_POKEUSER },
		{ PTRACE_PEEKTEXT, PTRACE_DISPATCH_PEEKTEXT },
		{ PTRACE_PEEKDATA, PTRACE_DISPATCH_PEEKTEXT },
		{ PTRACE_POKETEXT, PTRACE_DISPATCH_POKETEXT },
		{ PTRACE_POKEDATA, PTRACE_DISPATCH_POKETEXT },
		{ PTRACE_SETOPTIONS, PTRACE_DISPATCH_SETOPTIONS },
		{ PTRACE_ATTACH, PTRACE_DISPATCH_ATTACH },
		{ PTRACE_DETACH, PTRACE_DISPATCH_DETACH },
		{ PTRACE_GETSIGINFO, PTRACE_DISPATCH_GETSIGINFO },
		{ PTRACE_SETSIGINFO, PTRACE_DISPATCH_SETSIGINFO },
		{ PTRACE_GETREGSET, PTRACE_DISPATCH_GETREGSET },
		{ PTRACE_SETREGSET, PTRACE_DISPATCH_SETREGSET },
		{ PTRACE_GETEVENTMSG, PTRACE_DISPATCH_GETEVENTMSG },
		{ PTRACE_GETFPXREGS, PTRACE_DISPATCH_ARCH },
		{ PTRACE_SETFPXREGS, PTRACE_DISPATCH_ARCH },
		{ 999, PTRACE_DISPATCH_ARCH },
	};

	for (unsigned int i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
		const int dispatch = cases[i].dispatch;
		const int pid = 0x40 + (int)i;
		const long addr = 0x1000 + (long)i;
		const long data = 0x2000 + (long)i;
		long expected_request = 0;
		long expected_addr = 0;
		long expected_data = 0;
		long ret;

		if (dispatch == PTRACE_DISPATCH_WAKEUP ||
		    dispatch == PTRACE_DISPATCH_ARCH) {
			expected_request = cases[i].request;
		}
		if (dispatch == PTRACE_DISPATCH_PEEKUSER ||
		    dispatch == PTRACE_DISPATCH_POKEUSER ||
		    dispatch == PTRACE_DISPATCH_PEEKTEXT ||
		    dispatch == PTRACE_DISPATCH_POKETEXT ||
		    dispatch == PTRACE_DISPATCH_GETREGSET ||
		    dispatch == PTRACE_DISPATCH_SETREGSET ||
		    dispatch == PTRACE_DISPATCH_ARCH) {
			expected_addr = addr;
		}
		if (dispatch != PTRACE_DISPATCH_TRACEME &&
		    dispatch != PTRACE_DISPATCH_ATTACH) {
			expected_data = data;
		}

		fake_ptrace_syscall_reset();
		ret = ptrace_syscall_body_result(cases[i].request, pid, addr,
						 data,
						 &fake_ptrace_syscall_ops_full);
		require(ret == fake_ptrace_syscall_return(dispatch));
		require(fake_ptrace_syscall_calls == 1);
		require(fake_ptrace_syscall_last_op == dispatch);
		if (dispatch == PTRACE_DISPATCH_TRACEME) {
			require(fake_ptrace_syscall_last_pid == -1);
		}
		else {
			require(fake_ptrace_syscall_last_pid == pid);
		}
		require(fake_ptrace_syscall_last_request == expected_request);
		require(fake_ptrace_syscall_last_addr == expected_addr);
		require(fake_ptrace_syscall_last_data == expected_data);
		mix_signed(digest, ret);
		mix_signed(digest, fake_ptrace_syscall_last_op);
		mix_signed(digest, fake_ptrace_syscall_last_pid);
		mix_signed(digest, fake_ptrace_syscall_last_request);
		mix_signed(digest, fake_ptrace_syscall_last_addr);
		mix_signed(digest, fake_ptrace_syscall_last_data);
	}

	fake_ptrace_syscall_reset();
	mix_signed(digest, ptrace_syscall_body_result(PTRACE_TRACEME, 1, 2, 3,
						      NULL));
	require(fake_ptrace_syscall_calls == 0);

	{
		struct fake_ptrace_syscall_ops ops =
			fake_ptrace_syscall_ops_full;
		long ret;

		ops.getregs_fn = NULL;
		fake_ptrace_syscall_reset();
		ret = ptrace_syscall_body_result(PTRACE_GETREGS, 1, 2, 3,
						 &ops);
		require(ret == -EOPNOTSUPP);
		require(fake_ptrace_syscall_calls == 0);
		mix_signed(digest, ret);

		ops = fake_ptrace_syscall_ops_full;
		ops.arch_fn = NULL;
		fake_ptrace_syscall_reset();
		ret = ptrace_syscall_body_result(999, 1, 2, 3, &ops);
		require(ret == -EOPNOTSUPP);
		require(fake_ptrace_syscall_calls == 0);
		mix_signed(digest, ret);
	}
}

static void exercise_ptrace_process_vm_policy(unsigned long *digest)
{
	static const unsigned long flags[] = { 0, 1, ULONG_MAX };
	static const unsigned long iovcnts[] = { 0, 1, IOV_MAX, IOV_MAX + 1 };
	static const int ops[] = { -1, PROCESS_VM_READ, PROCESS_VM_WRITE, 2 };
	static const long signal_data[] = { -1, 0, 1, 19, 64, 65, LONG_MAX };
	static const long addrs[] = { LONG_MIN, -1, 0, 7, 8, 120, 121, LONG_MAX };
	static const int statuses[] = {
		0, PS_RUNNING, PS_STOPPED, PS_TRACED, PS_STOPPED | PS_TRACED,
	};
	static const int option_flags[] = {
		0, PTRACE_O_TRACESYSGOOD, PTRACE_O_TRACEFORK,
		PTRACE_O_TRACEVFORK, PTRACE_O_TRACECLONE, PTRACE_O_TRACEEXEC,
		PTRACE_O_TRACEVFORKDONE, PTRACE_O_TRACEEXIT, PTRACE_O_MASK,
		PTRACE_O_MASK | 0x80, -1,
	};
	static const int ptrace_values[] = {
		0, PT_TRACED, PT_TRACE_EXEC, PT_TRACED | PT_TRACE_EXEC,
	};
	static const int bools[] = { 0, 1 };
	static const int pids[] = { 1, 2 };
	static const long ptrace_requests[] = {
		PTRACE_TRACEME, PTRACE_PEEKTEXT, PTRACE_PEEKDATA,
		PTRACE_PEEKUSER, PTRACE_POKETEXT, PTRACE_POKEDATA,
		PTRACE_POKEUSER, PTRACE_CONT, PTRACE_KILL,
		PTRACE_SINGLESTEP, PTRACE_GETREGS, PTRACE_SETREGS,
		PTRACE_GETFPREGS, PTRACE_SETFPREGS, PTRACE_ATTACH,
		PTRACE_DETACH, PTRACE_SYSCALL, PTRACE_SETOPTIONS,
		PTRACE_GETEVENTMSG, PTRACE_GETSIGINFO, PTRACE_SETSIGINFO,
		PTRACE_GETREGSET, PTRACE_SETREGSET, PTRACE_GETFPXREGS,
		PTRACE_SETFPXREGS, 999,
	};
	static const long ptrace_data[] = { 0, 1, SIGSTOP, 64, 65 };

	for (unsigned int f = 0; f < sizeof(flags) / sizeof(flags[0]); f++) {
		for (unsigned int l = 0; l < sizeof(iovcnts) / sizeof(iovcnts[0]); l++) {
			for (unsigned int r = 0; r < sizeof(iovcnts) / sizeof(iovcnts[0]); r++)
				mix_signed(digest, process_vm_validate_args(flags[f],
					iovcnts[l], iovcnts[r]));
		}
	}

	for (unsigned int i = 0; i < sizeof(ops) / sizeof(ops[0]); i++) {
		mix_signed(digest, process_vm_op_is_write(ops[i]));
		mix_signed(digest, process_vm_op_is_valid(ops[i]));
	}

	{
		char local_iov;
		char remote_iov;
		char fake_ctx;
		long rc;

		fake_process_vm_rw_calls = 0;
		fake_process_vm_rw_rc = 123;
		rc = process_vm_rw_body_result(44, &local_iov, 1, &remote_iov,
			2, 0, PROCESS_VM_WRITE, fake_process_vm_rw);
		require(rc == 123);
		require(fake_process_vm_rw_calls == 1);
		require(fake_process_vm_rw_pid == 44);
		require(fake_process_vm_rw_local == &local_iov);
		require(fake_process_vm_rw_liovcnt == 1);
		require(fake_process_vm_rw_remote == &remote_iov);
		require(fake_process_vm_rw_riovcnt == 2);
		require(fake_process_vm_rw_flags == 0);
		require(fake_process_vm_rw_op == PROCESS_VM_WRITE);
		mix_signed(digest, rc);
		mix_signed(digest, fake_process_vm_rw_calls);

		fake_process_vm_rw_calls = 0;
		rc = process_vm_rw_body_result(44, &local_iov, 1, &remote_iov,
			2, 1, PROCESS_VM_READ, fake_process_vm_rw);
		require(rc == -22);
		require(fake_process_vm_rw_calls == 0);
		mix_signed(digest, rc);

		rc = process_vm_rw_body_result(44, &local_iov, 1, &remote_iov,
			2, 0, 99, fake_process_vm_rw);
		require(rc == -22);
		require(fake_process_vm_rw_calls == 0);
		mix_signed(digest, rc);

		rc = process_vm_rw_body_result(44, &local_iov, 1, &remote_iov,
			2, 0, PROCESS_VM_READ, NULL);
		require(rc == -14);
		mix_signed(digest, rc);

		exercise_arch_process_vm_rw_policy(digest);

		{
			struct fake_prctl_proc {
				int prefix;
				int thp_disable;
			} prctl_proc = { 0x55, 0 };

			rc = prctl_body_result(PR_SET_THP_DISABLE, 7, 0, 0, 0,
				&prctl_proc,
				offsetof(struct fake_prctl_proc, thp_disable),
				157, &fake_ctx, fake_forward_context);
			require(rc == 0);
			require(prctl_proc.thp_disable == 7);
			mix_signed(digest, prctl_proc.thp_disable);

			rc = prctl_body_result(PR_GET_THP_DISABLE, 0, 0, 0, 0,
				&prctl_proc,
				offsetof(struct fake_prctl_proc, thp_disable),
				157, &fake_ctx, fake_forward_context);
			require(rc == 7);
			mix_signed(digest, rc);

			rc = prctl_body_result(PR_SET_THP_DISABLE, 1, 1, 0, 0,
				&prctl_proc,
				offsetof(struct fake_prctl_proc, thp_disable),
				157, &fake_ctx, fake_forward_context);
			require(rc == -22);
			require(prctl_proc.thp_disable == 7);
			mix_signed(digest, rc);

			fake_forward_context_calls = 0;
			fake_forward_context_rc = -33;
			rc = prctl_body_result(999, 1, 2, 3, 4,
				&prctl_proc,
				offsetof(struct fake_prctl_proc, thp_disable),
				157, &fake_ctx, fake_forward_context);
			require(rc == -33);
			require(fake_forward_context_calls == 1);
			require(fake_forward_context_nr == 157);
			require(fake_forward_context_ctx == &fake_ctx);
			mix_signed(digest, rc);
			mix_signed(digest, fake_forward_context_calls);
		}

		{
			struct fake_arch_prctl_thread {
				unsigned long prefix;
				unsigned long tlsblock_base;
			} arch_thread = { 0x11UL, 0 };
			unsigned long get_storage = 0;
			int type = -1;

			rc = arch_prctl_type_result(ARCH_SET_FS, &type);
			require(rc == 0);
			require(type == IHK_ASR_X86_FS);
			mix_signed(digest, rc);
			mix_signed(digest, type);

			type = -1;
			rc = arch_prctl_type_result(ARCH_GET_GS, &type);
			require(rc == 0);
			require(type == IHK_ASR_X86_GS);
			mix_signed(digest, rc);
			mix_signed(digest, type);

			rc = arch_prctl_type_result(ARCH_SET_GS, &type);
			require(rc == -ENOTSUPP);
			mix_signed(digest, rc);

			rc = arch_prctl_type_result(0x5555UL, &type);
			require(rc == -EINVAL);
			mix_signed(digest, rc);

			fake_arch_prctl_cpu = 6;
			fake_arch_prctl_set_calls = 0;
			fake_arch_prctl_set_rc = 0;
			fake_arch_prctl_get_calls = 0;
			fake_arch_prctl_log_calls = 0;
			rc = arch_prctl_body_result(ARCH_SET_FS, 0xabcUL,
				&arch_thread,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				fake_arch_prctl_get_cpu,
				fake_arch_prctl_set_register,
				fake_arch_prctl_get_register,
				fake_arch_prctl_log);
			require(rc == 0);
			require(arch_thread.tlsblock_base == 0xabcUL);
			require(fake_arch_prctl_set_calls == 1);
			require(fake_arch_prctl_set_type == IHK_ASR_X86_FS);
			require(fake_arch_prctl_set_value == 0xabcUL);
			require(fake_arch_prctl_get_calls == 0);
			require(fake_arch_prctl_log_calls == 1);
			require(fake_arch_prctl_log_event == ARCH_SET_FS);
			require(fake_arch_prctl_log_cpu == 6);
			require(fake_arch_prctl_log_value == 0xabcUL);
			mix_signed(digest, rc);
			mix(digest, arch_thread.tlsblock_base);
			mix_signed(digest, fake_arch_prctl_log_calls);

			fake_arch_prctl_set_rc = -5;
			fake_arch_prctl_set_calls = 0;
			rc = arch_prctl_body_result(ARCH_SET_FS, 0xdefUL,
				&arch_thread,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				NULL, fake_arch_prctl_set_register,
				fake_arch_prctl_get_register, NULL);
			require(rc == -5);
			require(arch_thread.tlsblock_base == 0xdefUL);
			require(fake_arch_prctl_set_calls == 1);
			require(fake_arch_prctl_log_calls == 1);
			mix_signed(digest, rc);
			mix(digest, arch_thread.tlsblock_base);

			fake_arch_prctl_get_calls = 0;
			fake_arch_prctl_get_rc = 77;
			rc = arch_prctl_body_result(ARCH_GET_FS,
				(unsigned long)(uintptr_t)&get_storage,
				&arch_thread,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				fake_arch_prctl_get_cpu,
				fake_arch_prctl_set_register,
				fake_arch_prctl_get_register,
				fake_arch_prctl_log);
			require(rc == 77);
			require(fake_arch_prctl_get_calls == 1);
			require(fake_arch_prctl_get_type == IHK_ASR_X86_FS);
			require(fake_arch_prctl_get_addr == &get_storage);
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_prctl_get_type);

			fake_arch_prctl_get_rc = -6;
			rc = arch_prctl_body_result(ARCH_GET_GS,
				(unsigned long)(uintptr_t)&get_storage,
				&arch_thread,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				fake_arch_prctl_get_cpu,
				fake_arch_prctl_set_register,
				fake_arch_prctl_get_register,
				fake_arch_prctl_log);
			require(rc == -6);
			require(fake_arch_prctl_get_type == IHK_ASR_X86_GS);
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_prctl_get_type);

			rc = arch_prctl_body_result(ARCH_SET_FS, 0x123UL, NULL,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				fake_arch_prctl_get_cpu,
				fake_arch_prctl_set_register,
				fake_arch_prctl_get_register,
				fake_arch_prctl_log);
			require(rc == -EFAULT);
			mix_signed(digest, rc);

			rc = arch_prctl_body_result(ARCH_GET_FS,
				(unsigned long)(uintptr_t)&get_storage,
				&arch_thread,
				offsetof(struct fake_arch_prctl_thread,
					 tlsblock_base),
				fake_arch_prctl_get_cpu,
				fake_arch_prctl_set_register, NULL,
				fake_arch_prctl_log);
			require(rc == -EFAULT);
			mix_signed(digest, rc);
		}

		{
			struct fake_arch_clone_proc {
				unsigned long prefix;
				unsigned long coredump_lock;
			} clone_proc = { 0x1UL, 0xabcUL };
			char lock_node;
			long time_dst = 0;

			fake_arch_clone_sequence = 0;
			fake_arch_clone_lock_calls = 0;
			fake_arch_clone_unlock_calls = 0;
			fake_arch_clone_fork_calls = 0;
			fake_arch_clone_fork_rc = 0x778899UL;
			rc = (long)arch_clone_body_result(&clone_proc,
				offsetof(struct fake_arch_clone_proc,
					 coredump_lock),
				&lock_node, 0x123, 0x2000UL, 0x3000UL,
				0x4000UL, 0x5000UL, 0x6000UL, 0x7000UL,
				fake_arch_clone_lock, fake_arch_clone_unlock,
				fake_arch_do_fork);
			require((unsigned long)rc == 0x778899UL);
			require(fake_arch_clone_lock_calls == 1);
			require(fake_arch_clone_fork_calls == 1);
			require(fake_arch_clone_unlock_calls == 1);
			require(fake_arch_clone_lock_ptr == &clone_proc.coredump_lock);
			require(fake_arch_clone_unlock_ptr ==
				&clone_proc.coredump_lock);
			require(fake_arch_clone_lock_node == &lock_node);
			require(fake_arch_clone_unlock_node == &lock_node);
			require(fake_arch_clone_lock_seq < fake_arch_clone_fork_seq);
			require(fake_arch_clone_fork_seq <
				fake_arch_clone_unlock_seq);
			require(fake_arch_clone_fork_flags == 0x123);
			require(fake_arch_clone_fork_args[0] == 0x2000UL);
			require(fake_arch_clone_fork_args[1] == 0x3000UL);
			require(fake_arch_clone_fork_args[2] == 0x4000UL);
			require(fake_arch_clone_fork_args[3] == 0x5000UL);
			require(fake_arch_clone_fork_args[4] == 0x6000UL);
			require(fake_arch_clone_fork_args[5] == 0x7000UL);
			mix(digest, fake_arch_clone_fork_rc);
			mix_signed(digest, fake_arch_clone_lock_seq);
			mix_signed(digest, fake_arch_clone_unlock_seq);

			rc = (long)arch_clone_body_result(NULL,
				offsetof(struct fake_arch_clone_proc,
					 coredump_lock),
				&lock_node, 0, 0, 0, 0, 0, 0, 0,
				fake_arch_clone_lock, fake_arch_clone_unlock,
				fake_arch_do_fork);
			require(rc == -EFAULT);
			mix_signed(digest, rc);

			fake_arch_clone_sequence = 0;
			fake_arch_clone_fork_rc = 0x9001UL;
			rc = (long)arch_fork_body_result(0x1111UL, 0x2222UL,
				fake_arch_do_fork);
			require((unsigned long)rc == 0x9001UL);
			require(fake_arch_clone_fork_flags == SIGCHLD);
			require(fake_arch_clone_fork_args[0] == 0);
			require(fake_arch_clone_fork_args[4] == 0x1111UL);
			require(fake_arch_clone_fork_args[5] == 0x2222UL);
			mix(digest, fake_arch_clone_fork_rc);
			mix_signed(digest, fake_arch_clone_fork_flags);

			fake_arch_clone_fork_rc = 0x9002UL;
			rc = (long)arch_vfork_body_result(0x3333UL, 0x4444UL,
				fake_arch_do_fork);
			require((unsigned long)rc == 0x9002UL);
			require(fake_arch_clone_fork_flags ==
				(CLONE_VFORK | SIGCHLD));
			require(fake_arch_clone_fork_args[4] == 0x3333UL);
			require(fake_arch_clone_fork_args[5] == 0x4444UL);
			mix(digest, fake_arch_clone_fork_rc);
			mix_signed(digest, fake_arch_clone_fork_flags);

			rc = (long)arch_fork_body_result(0x1111UL, 0x2222UL,
				NULL);
			require(rc == -EFAULT);
			mix_signed(digest, rc);

			{
				struct fake_rt_sigreturn_thread rt_thread = {
					.prefix = 0x11,
					.sigmask = 0x2222UL,
					.sigstack = {
						.ss_sp = (void *)0x3333UL,
						.ss_flags = 4,
						.ss_size = 0x4444UL,
					},
					.suffix = 0x55,
				};
				struct fake_rt_sigreturn_context rt_regs;
				struct fake_rt_sigreturn_frame frame;
				unsigned char user_fp[32];
				void *aligned;

				memset(&rt_regs, 0, sizeof(rt_regs));
				memset(&frame, 0, sizeof(frame));
				for (int i = 0; i < 23; i++)
					frame.regs[i] = 0x1000UL + (unsigned long)i;
				frame.regs[15] = 0xabc000UL;
				frame.regs[17] = 0x202UL;
				frame.regs[21] = 0xfeedUL;
				frame.sigstack.ss_sp = (void *)0x7777UL;
				frame.sigstack.ss_flags = 6;
				frame.sigstack.ss_size = 0x8888UL;
				frame.sigrc = 0x5151UL;
				frame.num = 44;
				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;

				reset_fake_rt_sigreturn();
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 0,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == (long)frame.sigrc);
				require(rt_regs.gpr.r15 == frame.regs[7]);
				require(rt_regs.gpr.r8 == frame.regs[0]);
				require(rt_regs.gpr.rax == frame.regs[13]);
				require(rt_regs.gpr.error == frame.regs[19]);
				require(rt_regs.gpr.rip == frame.regs[16]);
				require(rt_regs.gpr.rsp == frame.regs[15]);
				require(rt_thread.sigmask == frame.regs[21]);
				require(rt_thread.sigstack.ss_sp ==
					frame.sigstack.ss_sp);
				require(rt_thread.sigstack.ss_flags ==
					frame.sigstack.ss_flags);
				require(rt_thread.sigstack.ss_size ==
					frame.sigstack.ss_size);
				require(fake_rt_sigreturn_copy_calls == 1);
				require(fake_rt_sigreturn_syscall_calls == 0);
				require(fake_rt_sigreturn_set_signal_calls == 0);
				mix_signed(digest, rc);
				mix(digest, rt_regs.gpr.rip);
				mix(digest, rt_thread.sigmask);

				frame.restart = 1;
				frame.num = 123;
				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;
				reset_fake_rt_sigreturn();
				fake_rt_sigreturn_syscall_rc = -777;
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 0,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == -777);
				require(fake_rt_sigreturn_syscall_calls == 1);
				require(fake_rt_sigreturn_syscall_num == 123);
				require(fake_rt_sigreturn_syscall_regs == &rt_regs);
				mix_signed(digest, rc);
				mix_signed(digest,
					   fake_rt_sigreturn_syscall_num);

				frame.restart = 0;
				frame.regs[17] = RFLAGS_TF | 0x2UL;
				frame.sigrc = 0x6161UL;
				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;
				reset_fake_rt_sigreturn();
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 0,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == (long)frame.sigrc);
				require(rt_regs.gpr.rax == frame.sigrc);
				require((rt_regs.gpr.rflags & RFLAGS_TF) == 0);
				require(fake_rt_sigreturn_set_signal_calls == 1);
				require(fake_rt_sigreturn_set_signal_sig == SIGTRAP);
				require(fake_rt_sigreturn_set_signal_regs == &rt_regs);
				require(fake_rt_sigreturn_set_signal_code ==
					TRAP_TRACE);
				require(fake_rt_sigreturn_resched_calls == 1);
				require(fake_rt_sigreturn_check_signal_calls == 1);
				require(fake_rt_sigreturn_check_signal_signum == 0);
				require(fake_rt_sigreturn_check_signal_regs ==
					&rt_regs);
				require(fake_rt_sigreturn_check_signal_num == -1);
				mix_signed(digest, rc);
				mix_signed(digest,
					   fake_rt_sigreturn_set_signal_code);

				frame.regs[17] = 0x202UL;
				frame.fpregs = user_fp;
				for (int i = 0; i < 32; i++)
					user_fp[i] = (unsigned char)(0xa0 + i);
				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;
				reset_fake_rt_sigreturn();
				aligned = (void *)((((uintptr_t)
					fake_rt_sigreturn_alloc_result) + 63) &
					~(uintptr_t)63);
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 32,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == (long)frame.sigrc);
				require(fake_rt_sigreturn_alloc_calls == 1);
				require(fake_rt_sigreturn_alloc_size == 96);
				require(fake_rt_sigreturn_alloc_flags ==
					IHK_MC_AP_NOWAIT);
				require(fake_rt_sigreturn_copy_calls == 2);
				require(fake_rt_sigreturn_last_dst == aligned);
				require(!memcmp(aligned, user_fp, sizeof(user_fp)));
				require(fake_rt_sigreturn_xrstor_calls == 1);
				require(fake_rt_sigreturn_xrstor_ptr == aligned);
				require(fake_rt_sigreturn_free_calls == 1);
				require(fake_rt_sigreturn_free_ptr ==
					fake_rt_sigreturn_alloc_result);
				mix_signed(digest, rc);
				mix_signed(digest,
					   fake_rt_sigreturn_alloc_calls);

				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;
				reset_fake_rt_sigreturn();
				fake_rt_sigreturn_copy_fail_at = 1;
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 32,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == -EFAULT);
				mix_signed(digest, rc);

				rt_regs.gpr.rsp = (unsigned long)(uintptr_t)&frame;
				reset_fake_rt_sigreturn();
				fake_rt_sigreturn_copy_fail_at = 2;
				rc = arch_rt_sigreturn_body_result(&rt_thread,
					&rt_regs,
					offsetof(struct fake_rt_sigreturn_thread,
						 sigmask),
					offsetof(struct fake_rt_sigreturn_thread,
						 sigstack),
					sizeof(stack_t), sizeof(frame), 32,
					IHK_MC_AP_NOWAIT,
					fake_rt_sigreturn_copy_from,
					fake_rt_sigreturn_syscall,
					fake_rt_sigreturn_set_signal,
					fake_rt_sigreturn_check_need_resched,
					fake_rt_sigreturn_check_signal,
					fake_rt_sigreturn_alloc,
					fake_rt_sigreturn_free,
					fake_rt_sigreturn_xrstor);
				require(rc == -EFAULT);
				require(fake_rt_sigreturn_alloc_calls == 1);
				require(fake_rt_sigreturn_free_calls == 0);
				require(fake_rt_sigreturn_xrstor_calls == 0);
				mix_signed(digest, rc);
			}

			fake_arch_time_copy_calls = 0;
			fake_arch_time_copy_fail = 0;
			rc = arch_time_body_result(12345, (unsigned long)
				(uintptr_t)&time_dst, fake_arch_time_copy_to_user);
			require(rc == 12345);
			require(time_dst == 12345);
			require(fake_arch_time_copy_calls == 1);
			require(fake_arch_time_copy_dst ==
				(unsigned long)(uintptr_t)&time_dst);
			require(fake_arch_time_copy_bytes == sizeof(long));
			require(fake_arch_time_copy_value == 12345);
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_time_copy_calls);

			fake_arch_time_copy_calls = 0;
			rc = arch_time_body_result(54321, 0,
				fake_arch_time_copy_to_user);
			require(rc == 54321);
			require(fake_arch_time_copy_calls == 0);
			mix_signed(digest, rc);

			fake_arch_time_copy_fail = 1;
			rc = arch_time_body_result(12, (unsigned long)
				(uintptr_t)&time_dst, fake_arch_time_copy_to_user);
			require(rc == -EFAULT);
			mix_signed(digest, rc);
		}

		{
			const int base_flags = 0600;

			fake_arch_shmget_default_shift_calls = 0;
			fake_arch_shmget_calls = 0;
			fake_arch_shmget_log_calls = 0;
			fake_arch_shmget_rc = 123;
			rc = arch_shmget_body_result(7, 0x4000, base_flags,
				fake_arch_shmget_default_huge_shift,
				fake_arch_do_shmget, fake_arch_shmget_log);
			require(rc == 123);
			require(fake_arch_shmget_default_shift_calls == 0);
			require(fake_arch_shmget_calls == 1);
			require(fake_arch_shmget_key == 7);
			require(fake_arch_shmget_size == 0x4000);
			require(fake_arch_shmget_flags == base_flags);
			require(fake_arch_shmget_log_calls == 2);
			require(fake_arch_shmget_log_events[0] ==
				ARCH_SHMGET_LOG_ENTER);
			require(fake_arch_shmget_log_events[1] ==
				ARCH_SHMGET_LOG_EXIT);
			require(fake_arch_shmget_log_error[1] == 0);
			require(fake_arch_shmget_log_shmid[1] == 123);
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_shmget_flags);

			fake_arch_shmget_default_shift_calls = 0;
			fake_arch_shmget_default_shift = 21;
			fake_arch_shmget_calls = 0;
			fake_arch_shmget_log_calls = 0;
			fake_arch_shmget_rc = 456;
			rc = arch_shmget_body_result(8, 0x8000,
				SHM_HUGETLB | base_flags,
				fake_arch_shmget_default_huge_shift,
				fake_arch_do_shmget, fake_arch_shmget_log);
			require(rc == 456);
			require(fake_arch_shmget_default_shift_calls == 1);
			require(fake_arch_shmget_calls == 1);
			require(fake_arch_shmget_flags ==
				(SHM_HUGETLB | base_flags |
				 (21 << MAP_HUGE_SHIFT)));
			require(fake_arch_shmget_log_calls == 2);
			require(fake_arch_shmget_log_error[1] == 0);
			require(fake_arch_shmget_log_shmid[1] == 456);
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_shmget_flags);

			fake_arch_shmget_default_shift_calls = 0;
			fake_arch_shmget_calls = 0;
			fake_arch_shmget_rc = 789;
			rc = arch_shmget_body_result(9, 0x9000,
				SHM_HUGETLB | SHM_HUGE_1GB | base_flags,
				fake_arch_shmget_default_huge_shift,
				fake_arch_do_shmget, NULL);
			require(rc == 789);
			require(fake_arch_shmget_default_shift_calls == 0);
			require(fake_arch_shmget_calls == 1);
			require(fake_arch_shmget_flags ==
				(SHM_HUGETLB | SHM_HUGE_1GB | base_flags));
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_shmget_flags);

			fake_arch_shmget_calls = 0;
			fake_arch_shmget_log_calls = 0;
			rc = arch_shmget_body_result(10, 0xa000,
				SHM_HUGETLB | (22 << SHM_HUGE_SHIFT),
				fake_arch_shmget_default_huge_shift,
				fake_arch_do_shmget, fake_arch_shmget_log);
			require(rc == -EINVAL);
			require(fake_arch_shmget_calls == 0);
			require(fake_arch_shmget_log_calls == 2);
			require(fake_arch_shmget_log_error[1] == -EINVAL);
			require(fake_arch_shmget_log_shmid[1] == -EINVAL);
			mix_signed(digest, rc);

			fake_arch_shmget_calls = 0;
			rc = arch_shmget_body_result(11, 0xb000,
				SHM_HUGETLB | base_flags, NULL,
				fake_arch_do_shmget, NULL);
			require(rc == -EFAULT);
			require(fake_arch_shmget_calls == 0);
			mix_signed(digest, rc);

			rc = arch_shmget_body_result(12, 0xc000, base_flags,
				fake_arch_shmget_default_huge_shift, NULL,
				NULL);
			require(rc == -EFAULT);
			mix_signed(digest, rc);
		}

		{
			const int mmap_supported = MAP_SHARED | MAP_PRIVATE |
				MAP_FIXED | MAP_ANONYMOUS | MAP_LOCKED |
				MAP_POPULATE | MAP_HUGETLB | MAP_HUGE_MASK;
			const int mmap_ignored = MAP_DENYWRITE | MAP_NORESERVE |
				MAP_STACK;
			const int mmap_errors = MAP_32BIT | MAP_GROWSDOWN |
				MAP_EXECUTABLE | MAP_NONBLOCK;
			const unsigned long user_start = 0x100000000UL;
			const unsigned long user_end = 0x200000000UL;

			fake_arch_mmap_default_shift_calls = 0;
			fake_arch_mmap_overmap_calls = 0;
			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			fake_arch_mmap_rc = 0x12345000;
			rc = arch_mmap_body_result(user_start, 0x1234,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == 0x12345000);
			require(fake_arch_mmap_calls == 1);
			require(fake_arch_mmap_addr == user_start);
			require(fake_arch_mmap_len == 0x2000);
			require(fake_arch_mmap_flags ==
				(MAP_PRIVATE | MAP_ANONYMOUS));
			require(fake_arch_mmap_vrf0 == 0);
			require(fake_arch_mmap_private_data == NULL);
			require(fake_arch_mmap_log_calls == 2);
			require(fake_arch_mmap_log_events[0] ==
				ARCH_MMAP_LOG_ENTER);
			require(fake_arch_mmap_log_events[1] ==
				ARCH_MMAP_LOG_EXIT);
			require(fake_arch_mmap_log_error[1] == 0);
			require(fake_arch_mmap_log_result[1] == 0x12345000);
			mix_signed(digest, rc);
			mix(digest, fake_arch_mmap_len);

			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			fake_arch_mmap_rc = 0x22345000;
			rc = arch_mmap_body_result(0x123UL, PAGE_SIZE,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == 0x22345000);
			require(fake_arch_mmap_calls == 1);
			require(fake_arch_mmap_addr == user_start);
			require(fake_arch_mmap_len == PAGE_SIZE);
			mix_signed(digest, rc);
			mix(digest, fake_arch_mmap_addr);

			fake_arch_mmap_default_shift_calls = 0;
			fake_arch_mmap_default_shift = 21;
			fake_arch_mmap_overmap_calls = 0;
			fake_arch_mmap_overmap_rc = 0;
			fake_arch_mmap_calls = 0;
			fake_arch_mmap_rc = 0x32345000;
			rc = arch_mmap_body_result(user_start, 0x1234,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS |
				MAP_HUGETLB, -1, 0, user_start, user_end,
				mmap_supported, mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				NULL);
			require(rc == 0x32345000);
			require(fake_arch_mmap_default_shift_calls == 1);
			require(fake_arch_mmap_overmap_calls == 1);
			require(fake_arch_mmap_overmap_len == (1UL << 21));
			require(fake_arch_mmap_overmap_shift == 21);
			require(fake_arch_mmap_calls == 1);
			require(fake_arch_mmap_len == (1UL << 21));
			require(fake_arch_mmap_flags ==
				(MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB |
				 MAP_HUGE_2MB));
			mix_signed(digest, rc);
			mix_signed(digest, fake_arch_mmap_flags);

			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			rc = arch_mmap_body_result(user_start, PAGE_SIZE,
				PROT_READ, MAP_SHARED | MAP_HUGETLB, 3, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == -EINVAL);
			require(fake_arch_mmap_calls == 0);
			require(fake_arch_mmap_log_events[1] ==
				ARCH_MMAP_LOG_EXIT);
			require(fake_arch_mmap_log_error[1] == -EINVAL);
			mix_signed(digest, rc);

			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			rc = arch_mmap_body_result(user_start, PAGE_SIZE,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS |
				MAP_HUGETLB | (22 << MAP_HUGE_SHIFT), -1, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == -EINVAL);
			require(fake_arch_mmap_calls == 0);
			require(fake_arch_mmap_log_events[1] ==
				ARCH_MMAP_LOG_UNSUPPORTED_PGSIZE);
			require(fake_arch_mmap_log_events[2] ==
				ARCH_MMAP_LOG_EXIT);
			mix_signed(digest, rc);

			fake_arch_mmap_overmap_rc = -1;
			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			rc = arch_mmap_body_result(user_start, PAGE_SIZE,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS |
				MAP_HUGETLB | MAP_HUGE_2MB, -1, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == -ENOMEM);
			require(fake_arch_mmap_calls == 0);
			require(fake_arch_mmap_log_error[1] == -ENOMEM);
			mix_signed(digest, rc);
			fake_arch_mmap_overmap_rc = 0;

			fake_arch_mmap_calls = 0;
			fake_arch_mmap_log_calls = 0;
			rc = arch_mmap_body_result(user_start, PAGE_SIZE,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS |
				MAP_32BIT, -1, 0, user_start, user_end,
				mmap_supported, mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, fake_arch_do_mmap,
				fake_arch_mmap_log);
			require(rc == -EINVAL);
			require(fake_arch_mmap_calls == 0);
			require(fake_arch_mmap_log_events[1] ==
				ARCH_MMAP_LOG_UNKNOWN_FLAGS);
			mix_signed(digest, rc);

			rc = arch_mmap_body_result(user_start, PAGE_SIZE,
				PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0,
				user_start, user_end, mmap_supported,
				mmap_ignored, mmap_errors,
				fake_arch_mmap_default_huge_shift,
				fake_arch_mmap_overmap, NULL, NULL);
			require(rc == -EFAULT);
			mix_signed(digest, rc);
		}

		{
			struct fake_arch_vdso vdso = {
				.vdso_npages = 2,
				.vvar_virt = (void *)(intptr_t)-4096,
				.vvar_phys = 0x200000,
				.hpet_virt = (void *)(intptr_t)8192,
				.hpet_phys = 0x300000,
				.pvti_virt = (void *)(intptr_t)-8192,
				.pvti_phys = 0x400000,
				.pvti_is_global = 1,
				.vgtod_virt = (void *)0x5555,
			};
			struct fake_vdso_process_vm vm = {
				.region = { .map_end = 0x700000 },
			};
			size_t container_size = 0;
			ptrdiff_t vdso_offset = 0;
			int gettime_local = 1;
			signed char tod_do_local = 1;
			void *pt = (void *)0x7777;
			unsigned long expected_exec_flags =
				VR_REMOTE | VR_PROT_READ | VR_PROT_EXEC;
			unsigned long expected_read_flags =
				VR_REMOTE | VR_PROT_READ;

			expected_exec_flags |=
				VRFLAG_PROT_TO_MAXPROT(expected_exec_flags);
			expected_read_flags |=
				VRFLAG_PROT_TO_MAXPROT(expected_read_flags);

			require(offsetof(struct fake_vdso_process_vm,
				region) == 16);
			require(offsetof(struct fake_vdso_process_vm,
				region.map_end) == 96);
			require(offsetof(struct fake_vdso_process_vm,
				vdso_addr) == 160);
			require(offsetof(struct fake_vdso_process_vm,
				vvar_addr) == 168);

			rc = arch_vdso_calc_container_size_result(&vdso,
				&container_size, &vdso_offset);
			require(rc == 0);
			require(container_size == 0x4000);
			require(vdso_offset == 0x1000);
			mix(digest, container_size);
			mix_signed(digest, vdso_offset);

			fake_arch_vdso_reset();
			rc = arch_setup_vdso_body_result(&vdso,
				&container_size, &vdso_offset,
				&gettime_local, &tod_do_local,
				fake_arch_vdso_get_info,
				fake_arch_vdso_map_global,
				fake_arch_vdso_setup_log);
			require(rc == 0);
			require(fake_arch_vdso_get_info_calls == 1);
			require(fake_arch_vdso_map_global_calls == 1);
			require(fake_arch_vdso_setup_log_calls == 0);
			require(gettime_local == 1);
			require(tod_do_local == 1);
			require(container_size == 0x4000);
			require(vdso_offset == 0x1000);
			mix_signed(digest, fake_arch_vdso_map_global_calls);

			vdso.vgtod_virt = NULL;
			vdso.vdso_npages = 2;
			container_size = 0xfeed;
			vdso_offset = 0xbeef;
			gettime_local = 1;
			tod_do_local = 1;
			fake_arch_vdso_reset();
			rc = arch_setup_vdso_body_result(&vdso,
				&container_size, &vdso_offset,
				&gettime_local, &tod_do_local,
				fake_arch_vdso_get_info,
				fake_arch_vdso_map_global,
				fake_arch_vdso_setup_log);
			require(rc == 0);
			require(gettime_local == 0);
			require(tod_do_local == 0);
			require(vdso.vdso_npages == 0);
			require(container_size == 0);
			require(vdso_offset == 0);
			require(fake_arch_vdso_map_global_calls == 0);
			require(fake_arch_vdso_setup_log_calls == 2);
			require(fake_arch_vdso_setup_log_events[0] ==
				ARCH_VDSO_SETUP_LOG_LOCAL_GETTIME_DISABLED);
			require(fake_arch_vdso_setup_log_events[1] ==
				ARCH_VDSO_SETUP_LOG_VDSO_DISABLED);
			mix_signed(digest, fake_arch_vdso_setup_log_calls);

			vdso.vgtod_virt = (void *)0x5555;
			vdso.vdso_npages = 2;
			fake_arch_vdso_reset();
			fake_arch_vdso_get_info_rc = -77;
			rc = arch_setup_vdso_body_result(&vdso,
				&container_size, &vdso_offset,
				&gettime_local, &tod_do_local,
				fake_arch_vdso_get_info,
				fake_arch_vdso_map_global,
				fake_arch_vdso_setup_log);
			require(rc == -77);
			require(fake_arch_vdso_map_global_calls == 0);
			require(fake_arch_vdso_setup_log_events[0] ==
				ARCH_VDSO_SETUP_LOG_GET_INFO_FAILED);
			require(fake_arch_vdso_setup_log_errors[0] == -77);
			mix_signed(digest, rc);

			fake_arch_vdso_reset();
			fake_arch_vdso_map_global_rc = -88;
			rc = arch_setup_vdso_body_result(&vdso,
				&container_size, &vdso_offset,
				&gettime_local, &tod_do_local,
				fake_arch_vdso_get_info,
				fake_arch_vdso_map_global,
				fake_arch_vdso_setup_log);
			require(rc == -88);
			require(fake_arch_vdso_map_global_calls == 1);
			require(fake_arch_vdso_setup_log_events[0] ==
				ARCH_VDSO_SETUP_LOG_MAP_GLOBAL_FAILED);
			require(fake_arch_vdso_setup_log_errors[0] == -88);
			mix_signed(digest, rc);

			fake_arch_vdso_reset();
			rc = arch_map_vdso_body_result(&vm, pt, &vdso, 0,
				0, fake_arch_vdso_add_range,
				fake_arch_vdso_set_range,
				fake_arch_vdso_map_log);
			require(rc == 0);
			require(fake_arch_vdso_add_range_calls == 0);
			require(fake_arch_vdso_set_range_calls == 0);
			require(fake_arch_vdso_map_log_events[0] ==
				ARCH_VDSO_MAP_LOG_NOT_AVAILABLE);
			require(vm.region.map_end == 0x700000);
			mix_signed(digest, fake_arch_vdso_map_log_calls);

			vdso.vgtod_virt = (void *)0x5555;
			vdso.vdso_npages = 2;
			vdso.vdso_physlist[0] = 0x100000;
			vdso.vdso_physlist[1] = 0x101000;
			vdso.vvar_virt = (void *)(intptr_t)-4096;
			vdso.vvar_is_global = 0;
			vdso.vvar_phys = 0x200000;
			vdso.hpet_virt = (void *)(intptr_t)8192;
			vdso.hpet_is_global = 0;
			vdso.hpet_phys = 0x300000;
			vdso.pvti_virt = NULL;
			vm.region.map_end = 0x700000;
			vm.vdso_addr = NULL;
			vm.vvar_addr = NULL;
			fake_arch_vdso_reset();
			rc = arch_map_vdso_body_result(&vm, pt, &vdso,
				0x4000, 0x1000, fake_arch_vdso_add_range,
				fake_arch_vdso_set_range,
				fake_arch_vdso_map_log);
			require(rc == 0);
			require(vm.region.map_end == 0x704000);
			require(vm.vdso_addr == (void *)0x701000);
			require(vm.vvar_addr == (void *)0x700000);
			require(fake_arch_vdso_add_range_calls == 2);
			require(fake_arch_vdso_add_start[0] == 0x701000);
			require(fake_arch_vdso_add_end[0] == 0x703000);
			require(fake_arch_vdso_add_flags[0] ==
				expected_exec_flags);
			require(fake_arch_vdso_add_start[1] == 0x700000);
			require(fake_arch_vdso_add_end[1] == 0x701000);
			require(fake_arch_vdso_add_flags[1] ==
				expected_read_flags);
			require(fake_arch_vdso_set_range_calls == 4);
			require(fake_arch_vdso_set_pt[0] == pt);
			require(fake_arch_vdso_set_start[0] == 0x701000);
			require(fake_arch_vdso_set_phys[0] == 0x100000);
			require(fake_arch_vdso_set_attr[0] ==
				(PTATTR_ACTIVE | PTATTR_USER));
			require(fake_arch_vdso_set_start[1] == 0x702000);
			require(fake_arch_vdso_set_phys[1] == 0x101000);
			require(fake_arch_vdso_set_start[2] == 0x700000);
			require(fake_arch_vdso_set_phys[2] == 0x200000);
			require(fake_arch_vdso_set_attr[2] ==
				(PTATTR_ACTIVE | PTATTR_USER |
				 PTATTR_NO_EXECUTE));
			require(fake_arch_vdso_set_start[3] == 0x703000);
			require(fake_arch_vdso_set_phys[3] == 0x300000);
			require(fake_arch_vdso_set_attr[3] ==
				(PTATTR_ACTIVE | PTATTR_USER |
				 PTATTR_NO_EXECUTE | PTATTR_UNCACHABLE));
			require(fake_arch_vdso_map_log_events[0] ==
				ARCH_VDSO_MAP_LOG_MAPPED);
			require(fake_arch_vdso_map_log_a[0] == 0x700000);
			require(fake_arch_vdso_map_log_b[0] == 0x701000);
			require(fake_arch_vdso_map_log_c[0] == 0x703000);
			require(fake_arch_vdso_map_log_d[0] == 0x4000);
			require(fake_arch_vdso_map_log_pages[0] == 2);
			mix(digest, vm.region.map_end);
			mix_signed(digest, fake_arch_vdso_set_range_calls);

			vm.region.map_end = 0x700000;
			vm.vdso_addr = NULL;
			fake_arch_vdso_reset();
			fake_arch_vdso_set_fail_call = 1;
			rc = arch_map_vdso_body_result(&vm, pt, &vdso,
				0x4000, 0x1000, fake_arch_vdso_add_range,
				fake_arch_vdso_set_range,
				fake_arch_vdso_map_log);
			require(rc == -66);
			require(vm.vdso_addr == (void *)0x701000);
			require(fake_arch_vdso_map_log_events[1] ==
				ARCH_VDSO_MAP_LOG_SET_RANGE_FAILED);
			require(fake_arch_vdso_map_log_errors[1] == -66);
			mix_signed(digest, rc);

			vm.region.map_end = 0x700000;
			vm.vdso_addr = NULL;
			vm.vvar_addr = NULL;
			fake_arch_vdso_reset();
			fake_arch_vdso_add_fail_call = 2;
			rc = arch_map_vdso_body_result(&vm, pt, &vdso,
				0x4000, 0x1000, fake_arch_vdso_add_range,
				fake_arch_vdso_set_range,
				fake_arch_vdso_map_log);
			require(rc == -55);
			require(vm.vvar_addr == NULL);
			require(fake_arch_vdso_map_log_events[1] ==
				ARCH_VDSO_MAP_LOG_ADD_VVAR_FAILED);
			require(fake_arch_vdso_map_log_errors[1] == -55);
			mix_signed(digest, rc);
		}

		mix_signed(digest, migrate_pages_body_result());
		mix_signed(digest, madvise_body_result(0x1000, 0x2000, 42));
		mix_signed(digest, get_system_body_result());
		mix_signed(digest, perf_event_open_disabled_body_result());

		fake_syscall2_calls = 0;
		fake_syscall2_rc = -33;
		rc = linux_mlock_body_result(0x123000, 0x4000, 802,
			fake_do_syscall2);
		require(rc == -33);
		require(fake_syscall2_calls == 1);
		require(fake_syscall2_nr == 802);
		require(fake_syscall2_arg0 == 0x123000);
		require(fake_syscall2_arg1 == 0x4000);
		mix_signed(digest, rc);
		mix_signed(digest, fake_syscall2_calls);

		rc = linux_mlock_body_result(0x123000, 0x4000, 802, NULL);
		require(rc == -14);
		mix_signed(digest, rc);

		fake_forward_context_calls = 0;
		fake_forward_context_thread = NULL;
		fake_forward_context_rc = 55;
		rc = linux_spawn_body_result(777, &fake_ctx,
			fake_forward_context);
		require(rc == 55);
		require(fake_forward_context_calls == 1);
		require(fake_forward_context_nr == 777);
		require(fake_forward_context_ctx == &fake_ctx);
		mix_signed(digest, rc);
		mix_signed(digest, fake_forward_context_calls);

		rc = linux_spawn_body_result(777, &fake_ctx, NULL);
		require(rc == -14);
		mix_signed(digest, rc);

		{
			char filename[] = "swap.img";
			char workarea[16];
			char linux_ctx;

			fake_forward_context_calls = 0;
			fake_forward_context_rc = -31;
			fake_swapout_pageout_calls = 0;
			fake_swapout_pagein_calls = 0;
			rc = swapout_body_result(NULL, workarea, sizeof(workarea),
				0, 900, &linux_ctx, fake_swapout_pageout,
				fake_swapout_pagein, fake_forward_context);
			require(rc == -31);
			require(fake_forward_context_calls == 1);
			require(fake_forward_context_nr == 900);
			require(fake_forward_context_ctx == &linux_ctx);
			require(fake_swapout_pageout_calls == 0);
			require(fake_swapout_pagein_calls == 0);
			mix_signed(digest, rc);
			mix_signed(digest, fake_forward_context_calls);

			fake_forward_context_calls = 0;
			fake_swapout_pageout_calls = 0;
			fake_swapout_pagein_calls = 0;
			rc = swapout_body_result(filename, workarea,
				sizeof(workarea), 1, 900, &linux_ctx,
				fake_swapout_pageout, fake_swapout_pagein,
				fake_forward_context);
			require(rc == -31);
			require(fake_forward_context_calls == 1);
			require(fake_swapout_pageout_calls == 0);
			require(fake_swapout_pagein_calls == 0);
			mix_signed(digest, rc);

			fake_forward_context_calls = 0;
			fake_forward_context_rc = -44;
			fake_swapout_pageout_calls = 0;
			fake_swapout_pageout_rc = 0;
			fake_swapout_pagein_calls = 0;
			fake_swapout_pagein_rc = 77;
			rc = swapout_body_result(filename, workarea,
				sizeof(workarea), 3, 900, &linux_ctx,
				fake_swapout_pageout, fake_swapout_pagein,
				fake_forward_context);
			require(rc == 77);
			require(fake_swapout_pageout_calls == 1);
			require(fake_swapout_pageout_filename == filename);
			require(fake_swapout_pageout_workarea == workarea);
			require(fake_swapout_pageout_size == sizeof(workarea));
			require(fake_swapout_pageout_flag == 3);
			require(fake_forward_context_calls == 1);
			require(fake_swapout_pagein_calls == 1);
			require(fake_swapout_pagein_flag == 3);
			mix_signed(digest, rc);
			mix_signed(digest, fake_swapout_pageout_calls);

			fake_forward_context_calls = 0;
			fake_swapout_pageout_calls = 0;
			fake_swapout_pagein_calls = 0;
			fake_swapout_pagein_rc = 88;
			rc = swapout_body_result(filename, workarea,
				sizeof(workarea), 2, 900, &linux_ctx,
				fake_swapout_pageout, fake_swapout_pagein,
				fake_forward_context);
			require(rc == 88);
			require(fake_swapout_pageout_calls == 1);
			require(fake_forward_context_calls == 0);
			require(fake_swapout_pagein_calls == 1);
			mix_signed(digest, rc);

			fake_swapout_pageout_rc = -5;
			fake_swapout_pageout_calls = 0;
			fake_swapout_pagein_calls = 0;
			rc = swapout_body_result(filename, workarea,
				sizeof(workarea), 3, 900, &linux_ctx,
				fake_swapout_pageout, fake_swapout_pagein,
				fake_forward_context);
			require(rc == -5);
			require(fake_swapout_pageout_calls == 1);
			require(fake_swapout_pagein_calls == 0);
			mix_signed(digest, rc);

			fake_swapout_pageout_rc = 0;
			rc = swapout_body_result(filename, workarea,
				sizeof(workarea), 3, 900, &linux_ctx,
				fake_swapout_pageout, fake_swapout_pagein, NULL);
			require(rc == -14);
			mix_signed(digest, rc);
		}

		{
			const char xpmem_path[] = "/dev/xpmem";
			const char other_path[] = "/tmp/file";
			char path_storage[32];
			char fake_ctx2;

			fake_strlen_calls = 0;
			fake_strlen_rc = 0;
			fake_stack_copy_from_fail = 0;
			fake_stack_copy_from_calls = 0;
			fake_util_alloc_calls = 0;
			fake_util_alloc_result = path_storage;
			fake_util_free_calls = 0;
			fake_open_special_calls = 0;
			fake_open_special_rc = 45;
			fake_forward_context_calls = 0;
			rc = open_common_body_result((unsigned long)xpmem_path,
				0x12, 901, &fake_ctx2, xpmem_path, 0x88,
				fake_strlen_user, fake_copy_stack_from_user,
				fake_util_alloc, fake_util_free,
				fake_open_special, fake_forward_context);
			require(rc == 45);
			require(fake_strlen_calls == 1);
			require(fake_util_alloc_calls == 1);
			require(fake_util_alloc_size == sizeof(xpmem_path));
			require(fake_util_alloc_flags == 0x88);
			require(fake_stack_copy_from_calls == 1);
			require(strcmp(path_storage, xpmem_path) == 0);
			require(fake_open_special_calls == 1);
			require(fake_open_special_pathname == path_storage);
			require(fake_open_special_flags == 0x12);
			require(fake_open_special_ctx == &fake_ctx2);
			require(fake_forward_context_calls == 0);
			require(fake_util_free_calls == 1);
			require(fake_util_freed[0] == path_storage);
			mix_signed(digest, rc);
			mix_signed(digest, fake_open_special_calls);

			fake_forward_context_calls = 0;
			fake_forward_context_rc = 46;
			fake_open_special_calls = 0;
			fake_util_free_calls = 0;
			rc = open_common_body_result((unsigned long)other_path,
				0x13, 902, &fake_ctx2, xpmem_path, 0x88,
				fake_strlen_user, fake_copy_stack_from_user,
				fake_util_alloc, fake_util_free,
				fake_open_special, fake_forward_context);
			require(rc == 46);
			require(strcmp(path_storage, other_path) == 0);
			require(fake_open_special_calls == 0);
			require(fake_forward_context_calls == 1);
			require(fake_forward_context_nr == 902);
			require(fake_forward_context_ctx == &fake_ctx2);
			require(fake_util_free_calls == 1);
			mix_signed(digest, rc);
			mix_signed(digest, fake_forward_context_calls);

			fake_strlen_rc = -36;
			fake_util_alloc_calls = 0;
			rc = open_common_body_result((unsigned long)other_path,
				0x13, 902, &fake_ctx2, xpmem_path, 0x88,
				fake_strlen_user, fake_copy_stack_from_user,
				fake_util_alloc, fake_util_free,
				fake_open_special, fake_forward_context);
			require(rc == -36);
			require(fake_util_alloc_calls == 0);
			mix_signed(digest, rc);
			fake_strlen_rc = 0;

			fake_util_alloc_result = NULL;
			rc = open_common_body_result((unsigned long)other_path,
				0x13, 902, &fake_ctx2, xpmem_path, 0x88,
				fake_strlen_user, fake_copy_stack_from_user,
				fake_util_alloc, fake_util_free,
				fake_open_special, fake_forward_context);
			require(rc == -12);
			mix_signed(digest, rc);
			fake_util_alloc_result = path_storage;

			fake_stack_copy_from_fail = 1;
			fake_util_free_calls = 0;
			rc = open_common_body_result((unsigned long)other_path,
				0x13, 902, &fake_ctx2, xpmem_path, 0x88,
				fake_strlen_user, fake_copy_stack_from_user,
				fake_util_alloc, fake_util_free,
				fake_open_special, fake_forward_context);
			require(rc == -14);
			require(fake_util_free_calls == 1);
			mix_signed(digest, rc);
			fake_stack_copy_from_fail = 0;
		}

		{
			struct fake_uti_attr user_attr = {
				.words = { 0x11, 0x22, 0x33, 0x44 },
			};
			struct fake_uti_attr scratch_attr = { 0 };
			struct fake_uti_attr allocated_attr = { 0 };
			struct fake_uti_attr old_attr = {
				.words = { 0xaa, 0xbb, 0xcc, 0xdd },
			};
			struct fake_uti_process proc = {
				.prefix = 1,
				.enable_uti = 1,
				.suffix = 2,
			};
			struct fake_uti_thread uti_thread = {
				.prefix = 3,
				.proc = &proc,
				.mod_clone = -1,
				.mod_clone_arg = &old_attr,
				.suffix = 4,
			};
			unsigned long desc_store = 0;

			fake_stack_copy_from_fail = 0;
			fake_stack_copy_from_calls = 0;
			fake_util_thread_calls = 0;
			fake_util_thread_arg = NULL;
			fake_util_thread_rc = 66;
			rc = util_migrate_inter_kernel_body_result(
				(unsigned long)&user_attr, &scratch_attr,
				sizeof(scratch_attr), fake_copy_stack_from_user,
				fake_util_thread);
			require(rc == 66);
			require(fake_stack_copy_from_calls == 1);
			require(fake_util_thread_calls == 1);
			require(fake_util_thread_arg == &scratch_attr);
			require(memcmp(&scratch_attr, &user_attr,
				sizeof(user_attr)) == 0);
			mix_signed(digest, rc);
			mix(digest, scratch_attr.words[0]);

			fake_stack_copy_from_calls = 0;
			fake_util_thread_calls = 0;
			fake_util_thread_arg = (void *)1;
			rc = util_migrate_inter_kernel_body_result(0,
				&scratch_attr, sizeof(scratch_attr),
				fake_copy_stack_from_user, fake_util_thread);
			require(rc == 66);
			require(fake_stack_copy_from_calls == 0);
			require(fake_util_thread_calls == 1);
			require(fake_util_thread_arg == NULL);
			mix_signed(digest, rc);

			fake_stack_copy_from_fail = 1;
			fake_stack_copy_from_calls = 0;
			fake_util_thread_calls = 0;
			rc = util_migrate_inter_kernel_body_result(
				(unsigned long)&user_attr, &scratch_attr,
				sizeof(scratch_attr), fake_copy_stack_from_user,
				fake_util_thread);
			require(rc == -14);
			require(fake_stack_copy_from_calls == 1);
			require(fake_util_thread_calls == 0);
			mix_signed(digest, rc);
			fake_stack_copy_from_fail = 0;

			fake_stack_copy_from_calls = 0;
			fake_util_alloc_calls = 0;
			fake_util_alloc_result = &allocated_attr;
			fake_util_free_calls = 0;
			fake_util_freed[0] = NULL;
			rc = util_indicate_clone_body_result(&uti_thread,
				SPAWN_TO_REMOTE, (unsigned long)&user_attr,
				sizeof(user_attr), 0x77,
				offsetof(struct fake_uti_thread, proc),
				offsetof(struct fake_uti_process, enable_uti),
				offsetof(struct fake_uti_thread, mod_clone),
				offsetof(struct fake_uti_thread, mod_clone_arg),
				fake_copy_stack_from_user, fake_util_alloc,
				fake_util_free);
			require(rc == 0);
			require(fake_util_alloc_calls == 1);
			require(fake_util_alloc_size == sizeof(user_attr));
			require(fake_util_alloc_flags == 0x77);
			require(fake_stack_copy_from_calls == 1);
			require(memcmp(&allocated_attr, &user_attr,
				sizeof(user_attr)) == 0);
			require(fake_util_free_calls == 1);
			require(fake_util_freed[0] == &old_attr);
			require(uti_thread.mod_clone == SPAWN_TO_REMOTE);
			require(uti_thread.mod_clone_arg == &allocated_attr);
			mix_signed(digest, rc);
			mix_signed(digest, fake_util_free_calls);

			proc.enable_uti = 0;
			rc = util_indicate_clone_body_result(&uti_thread,
				SPAWN_TO_LOCAL, 0, sizeof(user_attr), 0x77,
				offsetof(struct fake_uti_thread, proc),
				offsetof(struct fake_uti_process, enable_uti),
				offsetof(struct fake_uti_thread, mod_clone),
				offsetof(struct fake_uti_thread, mod_clone_arg),
				fake_copy_stack_from_user, fake_util_alloc,
				fake_util_free);
			require(rc == -22);
			mix_signed(digest, rc);
			proc.enable_uti = 1;

			rc = util_indicate_clone_body_result(&uti_thread, 99, 0,
				sizeof(user_attr), 0x77,
				offsetof(struct fake_uti_thread, proc),
				offsetof(struct fake_uti_process, enable_uti),
				offsetof(struct fake_uti_thread, mod_clone),
				offsetof(struct fake_uti_thread, mod_clone_arg),
				fake_copy_stack_from_user, fake_util_alloc,
				fake_util_free);
			require(rc == -22);
			mix_signed(digest, rc);

			uti_thread.mod_clone_arg = NULL;
			fake_util_alloc_result = NULL;
			rc = util_indicate_clone_body_result(&uti_thread,
				SPAWN_TO_LOCAL, (unsigned long)&user_attr,
				sizeof(user_attr), 0x77,
				offsetof(struct fake_uti_thread, proc),
				offsetof(struct fake_uti_process, enable_uti),
				offsetof(struct fake_uti_thread, mod_clone),
				offsetof(struct fake_uti_thread, mod_clone_arg),
				fake_copy_stack_from_user, fake_util_alloc,
				fake_util_free);
			require(rc == -12);
			mix_signed(digest, rc);

			fake_util_alloc_result = &allocated_attr;
			fake_stack_copy_from_fail = 1;
			fake_util_free_calls = 0;
			rc = util_indicate_clone_body_result(&uti_thread,
				SPAWN_TO_LOCAL, (unsigned long)&user_attr,
				sizeof(user_attr), 0x77,
				offsetof(struct fake_uti_thread, proc),
				offsetof(struct fake_uti_process, enable_uti),
				offsetof(struct fake_uti_thread, mod_clone),
				offsetof(struct fake_uti_thread, mod_clone_arg),
				fake_copy_stack_from_user, fake_util_alloc,
				fake_util_free);
			require(rc == -14);
			require(fake_util_free_calls == 1);
			require(fake_util_freed[0] == &allocated_attr);
			mix_signed(digest, rc);
			fake_stack_copy_from_fail = 0;

			rc = util_register_desc_body_result(0xabcdef,
				&desc_store);
			require(rc == 0);
			require(desc_store == 0xabcdef);
			mix_signed(digest, rc);
			mix(digest, desc_store);

			rc = util_register_desc_body_result(0xabcdef, NULL);
			require(rc == -14);
			mix_signed(digest, rc);

			{
				struct fake_threads_signal_process sigproc = {
					.prefix = 5,
					.pid = 4321,
					.suffix = 6,
				};
				struct fake_threads_signal_thread current = {
					.prefix = 7,
					.proc = &sigproc,
					.tid = 1,
					.status = PS_RUNNING,
					.suffix = 8,
				};
				struct fake_threads_signal_thread first = {
					.prefix = 9,
					.proc = &sigproc,
					.tid = 2,
					.status = PS_STOPPED,
					.suffix = 10,
				};
				struct fake_threads_signal_thread second = {
					.prefix = 11,
					.proc = &sigproc,
					.tid = 3,
					.status = PS_STOPPED,
					.suffix = 12,
				};

				fake_cputime_list_init(&sigproc.threads_list);
				fake_cputime_list_add_tail(
					&current.siblings_list,
					&sigproc.threads_list);
				fake_cputime_list_add_tail(&first.siblings_list,
					&sigproc.threads_list);
				fake_cputime_list_add_tail(
					&second.siblings_list,
					&sigproc.threads_list);

				fake_do_kill_thread_calls = 0;
				fake_cpu_pause_calls = 0;
				rc = threads_signal_body_result(&current, SIGSTOP,
					1,
					offsetof(struct fake_threads_signal_thread,
						proc),
					offsetof(struct fake_threads_signal_process,
						pid),
					offsetof(struct fake_threads_signal_process,
						threads_list),
					offsetof(struct fake_threads_signal_thread,
						tid),
					offsetof(struct fake_threads_signal_thread,
						status),
					offsetof(struct fake_threads_signal_thread,
						siblings_list),
					fake_do_kill_thread, fake_cpu_pause);
				require(rc == 0);
				require(fake_do_kill_thread_calls == 2);
				require(fake_do_kill_thread_current == &current);
				require(fake_do_kill_thread_pid == 4321);
				require(fake_do_kill_thread_tid == 3);
				require(fake_do_kill_thread_sig == SIGSTOP);
				require(fake_cpu_pause_calls == 0);
				mix_signed(digest, rc);
				mix_signed(digest, fake_do_kill_thread_calls);

				fake_do_kill_thread_calls = 0;
				rc = threads_signal_body_result(&current, SIGCONT,
					0,
					offsetof(struct fake_threads_signal_thread,
						proc),
					offsetof(struct fake_threads_signal_process,
						pid),
					offsetof(struct fake_threads_signal_process,
						threads_list),
					offsetof(struct fake_threads_signal_thread,
						tid),
					offsetof(struct fake_threads_signal_thread,
						status),
					offsetof(struct fake_threads_signal_thread,
						siblings_list),
					fake_do_kill_thread, fake_cpu_pause);
				require(rc == 0);
				require(fake_do_kill_thread_calls == 2);
				require(fake_do_kill_thread_sig == SIGCONT);
				mix_signed(digest, rc);
				mix_signed(digest, fake_do_kill_thread_calls);

				rc = threads_signal_body_result(NULL, SIGCONT, 0,
					offsetof(struct fake_threads_signal_thread,
						proc),
					offsetof(struct fake_threads_signal_process,
						pid),
					offsetof(struct fake_threads_signal_process,
						threads_list),
					offsetof(struct fake_threads_signal_thread,
						tid),
					offsetof(struct fake_threads_signal_thread,
						status),
					offsetof(struct fake_threads_signal_thread,
						siblings_list),
					fake_do_kill_thread, fake_cpu_pause);
				require(rc == -14);
				mix_signed(digest, rc);
			}
		}
	}

	for (unsigned int i = 0; i < sizeof(signal_data) / sizeof(signal_data[0]); i++) {
		mix_signed(digest, ptrace_signal_data_result(signal_data[i]));
		mix_signed(digest, ptrace_detach_signal_result(signal_data[i]));
	}

	for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++) {
		mix_signed(digest, ptrace_user_area_result(addrs[i], 128));
		mix_signed(digest, ptrace_user_area_result(addrs[i], 8));
	}

	for (unsigned int i = 0; i < sizeof(statuses) / sizeof(statuses[0]); i++)
		mix_signed(digest, ptrace_status_allows_io(statuses[i]));

	for (unsigned int f = 0; f < sizeof(option_flags) / sizeof(option_flags[0]); f++) {
		mix_signed(digest, ptrace_setoptions_flags_result(option_flags[f]));
		for (unsigned int p = 0; p < sizeof(ptrace_values) / sizeof(ptrace_values[0]); p++)
			mix_signed(digest, ptrace_apply_options(ptrace_values[p],
				option_flags[f]));
	}
	{
		struct fake_ptrace_thread fake = {
			.pad = 0x44,
			.ptrace = PT_TRACED | PTRACE_O_TRACEFORK,
			.eventmsg = 0x12345678UL,
		};
		unsigned long msg = 0xdeadbeefUL;

		mix_signed(digest, ptrace_setoptions_apply_thread_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace),
			PTRACE_O_TRACEEXEC | PTRACE_O_TRACESYSGOOD));
		require(fake.ptrace == (PT_TRACED | PTRACE_O_TRACEEXEC |
					PTRACE_O_TRACESYSGOOD));
		mix_signed(digest, fake.ptrace);

		mix_signed(digest, ptrace_attach_mark_traced_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace)));
		require(fake.ptrace == (PT_TRACED | PT_TRACE_EXEC));
		mix_signed(digest, fake.ptrace);

		mix_signed(digest, ptrace_eventmsg_prepare_result(PS_TRACED,
			fake.eventmsg, &msg));
		require(msg == fake.eventmsg);
		mix(digest, msg);

		msg = 0xbeefUL;
		mix_signed(digest, ptrace_eventmsg_prepare_result(PS_RUNNING,
			fake.eventmsg, &msg));
		require(msg == 0xbeefUL);
		mix(digest, msg);
		mix_signed(digest, ptrace_eventmsg_prepare_result(PS_STOPPED,
			fake.eventmsg, NULL));
		mix_signed(digest, ptrace_setoptions_apply_thread_result(0,
			offsetof(struct fake_ptrace_thread, ptrace),
			PTRACE_O_TRACEEXIT));
		mix_signed(digest, ptrace_attach_mark_traced_result(0,
			offsetof(struct fake_ptrace_thread, ptrace)));
	}

	for (unsigned int c = 0; c < sizeof(bools) / sizeof(bools[0]); c++) {
		for (unsigned int p = 0; p < sizeof(bools) / sizeof(bools[0]); p++) {
			for (unsigned int t = 0; t < sizeof(ptrace_values) / sizeof(ptrace_values[0]); t++)
				mix_signed(digest, ptrace_child_traced_result(bools[c],
					bools[p], ptrace_values[t]));
		}
	}

	for (unsigned int tr = 0; tr < sizeof(pids) / sizeof(pids[0]); tr++) {
		for (unsigned int ta = 0; ta < sizeof(pids) / sizeof(pids[0]); ta++) {
			for (unsigned int pt = 0; pt < sizeof(ptrace_values) / sizeof(ptrace_values[0]); pt++) {
				for (unsigned int same = 0; same < sizeof(bools) / sizeof(bools[0]); same++)
					mix_signed(digest, ptrace_attach_policy_result(
						pids[tr], pids[ta], ptrace_values[pt],
						bools[same]));
			}
		}
	}

	for (unsigned int traced = 0; traced < sizeof(bools) / sizeof(bools[0]); traced++) {
		for (unsigned int same = 0; same < sizeof(bools) / sizeof(bools[0]); same++)
			mix_signed(digest, ptrace_detach_state_result(bools[traced],
				bools[same]));
	}
	exercise_ptrace_detach_body(digest);

	for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++) {
		for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++)
			mix_signed(digest, ptrace_siginfo_state_result(statuses[s],
				bools[h]));
		mix_signed(digest, ptrace_eventmsg_state_result(statuses[s]));
		for (unsigned int send = 0; send < sizeof(bools) / sizeof(bools[0]); send++) {
			for (unsigned int recv = 0; recv < sizeof(bools) / sizeof(bools[0]); recv++)
				mix_signed(digest, ptrace_setsiginfo_target_result(
					statuses[s], bools[send], bools[recv]));
		}
	}
	{
		struct fake_sig_pending recv = { 0 };
		struct fake_sig_pending send = { 0 };
		struct fake_sig_pending allocated = { 0 };
		struct fake_ptrace_thread fake = {
			.pad = 0x12,
			.ptrace = PT_TRACED,
			.eventmsg = 0xabcdefUL,
			.ptrace_recvsig = &recv,
			.ptrace_sendsig = &send,
		};
		unsigned char info[32];
		unsigned char out[32];
		int target;

		for (unsigned int i = 0; i < sizeof(recv.info); i++)
			recv.info[i] = (unsigned char)(0x80 + i);
		memset(out, 0x5a, sizeof(out));
		mix_signed(digest, ptrace_getsiginfo_prepare_result(PS_TRACED,
			(unsigned long)&recv,
			offsetof(struct fake_sig_pending, info), out,
			sizeof(out)));
		require(memcmp(out, recv.info, sizeof(out)) == 0);
		for (unsigned int i = 0; i < sizeof(out); i++)
			mix(digest, out[i]);

		memset(out, 0x6b, sizeof(out));
		mix_signed(digest, ptrace_getsiginfo_prepare_result(PS_RUNNING,
			(unsigned long)&recv,
			offsetof(struct fake_sig_pending, info), out,
			sizeof(out)));
		require(out[0] == 0x6b);
		mix_signed(digest, ptrace_getsiginfo_prepare_result(PS_TRACED,
			0, offsetof(struct fake_sig_pending, info), out,
			sizeof(out)));
		mix_signed(digest, ptrace_getsiginfo_prepare_result(PS_TRACED,
			(unsigned long)&recv,
			offsetof(struct fake_sig_pending, info), NULL,
			sizeof(out)));

		for (unsigned int i = 0; i < sizeof(info); i++)
			info[i] = (unsigned char)(0x30 + i);
		target = ptrace_setsiginfo_target_result(PS_TRACED, 1, 1);
		mix_signed(digest, ptrace_setsiginfo_store_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info), target, 0,
			info, sizeof(info)));
		require(memcmp(send.info, info, sizeof(info)) == 0);
		require(memcmp(recv.info, info, sizeof(info)) == 0);

		memset(allocated.info, 0, sizeof(allocated.info));
		fake.ptrace_sendsig = NULL;
		target = ptrace_setsiginfo_target_result(PS_TRACED, 0, 1);
		mix_signed(digest, ptrace_setsiginfo_store_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info),
			target & PTRACE_SIGINFO_ALLOC_SENDSIG,
			(unsigned long)&allocated, NULL, 0));
		require(fake.ptrace_sendsig == &allocated);
		mix_signed(digest, ptrace_setsiginfo_store_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info),
			PTRACE_SIGINFO_STORE_SENDSIG, 0, info,
			sizeof(info)));
		require(memcmp(allocated.info, info, sizeof(info)) == 0);

		fake.ptrace_sendsig = NULL;
		mix_signed(digest, ptrace_setsiginfo_store_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info),
			PTRACE_SIGINFO_ALLOC_SENDSIG, 0, NULL, 0));
		require(fake.ptrace_sendsig == NULL);
		mix_signed(digest, ptrace_setsiginfo_store_result(0,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info),
			PTRACE_SIGINFO_STORE_SENDSIG, 0, info,
			sizeof(info)));
		fake.ptrace_recvsig = NULL;
		mix_signed(digest, ptrace_setsiginfo_store_result(
			(unsigned long)&fake,
			offsetof(struct fake_ptrace_thread, ptrace_sendsig),
			offsetof(struct fake_ptrace_thread, ptrace_recvsig),
			offsetof(struct fake_sig_pending, info),
			PTRACE_SIGINFO_STORE_RECVSIG, 0, info,
			sizeof(info)));
	}
	{
		struct fake_reg_thread regs = {
			.values = {
				0x1010UL, 0x2020UL, 0x3030UL, 0x4040UL,
				0x5050UL, 0x6060UL, 0x7070UL, 0x8080UL,
			},
			.written = { 0 },
			.fail_at = -1,
		};
		unsigned long out[8];
			unsigned long in[8] = {
				0x9090UL, 0xa0a0UL, 0xb0b0UL, 0xc0c0UL,
				0xd0d0UL, 0xe0e0UL, 0xf0f0UL, 0x1111UL,
			};
			unsigned long word = 0;

			mix_signed(digest, ptrace_read_user_word_result(
				PS_TRACED, (unsigned long)&regs,
				2 * (long)sizeof(unsigned long), &word,
				fake_ptrace_read_word));
			require(word == regs.values[2]);
			mix(digest, word);
			word = 0x7777UL;
			mix_signed(digest, ptrace_read_user_word_result(
				PS_RUNNING, (unsigned long)&regs, 0, &word,
				fake_ptrace_read_word));
			require(word == 0x7777UL);
			regs.fail_at = 1;
			mix_signed(digest, ptrace_read_user_word_result(
				PS_TRACED, (unsigned long)&regs,
				(long)sizeof(unsigned long), &word,
				fake_ptrace_read_word));
			regs.fail_at = -1;
			mix_signed(digest, ptrace_read_user_word_result(
				PS_TRACED, 0, 0, &word, fake_ptrace_read_word));
			mix_signed(digest, ptrace_read_user_word_result(
				PS_TRACED, (unsigned long)&regs, 0, NULL,
				fake_ptrace_read_word));
			mix_signed(digest, ptrace_read_user_word_result(
				PS_TRACED, (unsigned long)&regs, 0, &word, NULL));

			memset(regs.written, 0, sizeof(regs.written));
			mix_signed(digest, ptrace_write_user_word_result(
				PS_TRACED, (unsigned long)&regs,
				3 * (long)sizeof(unsigned long), 0x51515151UL,
				fake_ptrace_write_word));
			require(regs.written[3] == 0x51515151UL);
			mix(digest, regs.written[3]);
			mix_signed(digest, ptrace_write_user_word_result(
				PS_RUNNING, (unsigned long)&regs, 0, 0x61616161UL,
				fake_ptrace_write_word));
			regs.fail_at = 2;
			mix_signed(digest, ptrace_write_user_word_result(
				PS_TRACED, (unsigned long)&regs,
				2 * (long)sizeof(unsigned long), 0x71717171UL,
				fake_ptrace_write_word));
			regs.fail_at = -1;
			mix_signed(digest, ptrace_write_user_word_result(
				PS_TRACED, 0, 0, 0x81818181UL,
				fake_ptrace_write_word));
			mix_signed(digest, ptrace_write_user_word_result(
				PS_TRACED, (unsigned long)&regs, 0, 0x91919191UL,
				NULL));

			memset(out, 0, sizeof(out));
		mix_signed(digest, ptrace_read_user_words_result(
			(unsigned long)&regs, out, sizeof(out),
			fake_ptrace_read_word));
		require(memcmp(out, regs.values, sizeof(out)) == 0);
		for (unsigned int i = 0; i < sizeof(out) / sizeof(out[0]); i++)
			mix(digest, out[i]);

		regs.fail_at = 3;
		memset(out, 0x5a, sizeof(out));
		mix_signed(digest, ptrace_read_user_words_result(
			(unsigned long)&regs, out, sizeof(out),
			fake_ptrace_read_word));
		require(out[0] == regs.values[0]);
		require(out[1] == regs.values[1]);
		require(out[2] == regs.values[2]);
		require(out[3] == 0x5a5a5a5a5a5a5a5aUL);

		regs.fail_at = -1;
		memset(regs.written, 0, sizeof(regs.written));
		mix_signed(digest, ptrace_write_user_words_result(
			(unsigned long)&regs, in, sizeof(in),
			fake_ptrace_write_word));
		require(memcmp(regs.written, in, sizeof(in)) == 0);
		for (unsigned int i = 0; i < sizeof(regs.written) /
				sizeof(regs.written[0]); i++)
			mix(digest, regs.written[i]);

		regs.fail_at = 4;
		memset(regs.written, 0, sizeof(regs.written));
		mix_signed(digest, ptrace_write_user_words_result(
			(unsigned long)&regs, in, sizeof(in),
			fake_ptrace_write_word));
		require(regs.written[0] == in[0]);
		require(regs.written[1] == in[1]);
		require(regs.written[2] == in[2]);
		require(regs.written[3] == in[3]);
		require(regs.written[4] == 0);

		mix_signed(digest, ptrace_read_user_words_result(0, out,
			sizeof(out), fake_ptrace_read_word));
		mix_signed(digest, ptrace_read_user_words_result(
			(unsigned long)&regs, NULL, sizeof(out),
			fake_ptrace_read_word));
		mix_signed(digest, ptrace_read_user_words_result(
			(unsigned long)&regs, out, sizeof(out), NULL));
		mix_signed(digest, ptrace_write_user_words_result(0, in,
			sizeof(in), fake_ptrace_write_word));
		mix_signed(digest, ptrace_write_user_words_result(
			(unsigned long)&regs, NULL, sizeof(in),
			fake_ptrace_write_word));
		mix_signed(digest, ptrace_write_user_words_result(
			(unsigned long)&regs, in, sizeof(in), NULL));
	}
	{
		struct fake_ptrace_io_proc proc = {
			.pid = 7001,
			.status = PS_TRACED,
		};
		struct fake_arch_user_context live = {
			.sr = { 0x5000, 0x6000 },
			.gpr = {
				0x1000, 0x1001, 0x1002, 0x1003,
				0x1004, 0x1005, 0x1006, 0x1007,
			},
		};
		struct fake_arch_ptrace_thread arch_thread = {
			.proc = &proc,
			.saved_valid = 0,
			.live_uctx = &live,
			.find_key = 7001,
		};
		struct fake_arch_ptrace_user_offsets arch_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_arch_ptrace_thread, proc),
			.thread_ptrace_saved_uctx_valid_offset =
				offsetof(struct fake_arch_ptrace_thread,
					 saved_valid),
			.thread_ptrace_saved_uctx_offset =
				offsetof(struct fake_arch_ptrace_thread,
					 saved_uctx),
			.thread_ptrace_debugreg_offset =
				offsetof(struct fake_arch_ptrace_thread,
					 debugreg),
			.proc_status_offset =
				offsetof(struct fake_ptrace_io_proc, status),
			.uctx_sr_offset =
				offsetof(struct fake_arch_user_context, sr),
			.uctx_gpr_offset =
				offsetof(struct fake_arch_user_context, gpr),
		};
		unsigned long debugreg[8] = { 0 };
		unsigned long value = 0;
		unsigned long copied = 0;
		unsigned long old_flags;
		struct fake_regset_thread copy_tracker = { 0 };

		active_arch_ptrace_thread = &arch_thread;
		active_arch_ptrace_offsets = &arch_offsets;
		mix_signed(digest, arch_ptrace_read_user_body_result(
			&arch_thread, 8, &value, sizeof(value), 64, 16,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(value == live.gpr[1]);
		mix(digest, value);
		mix_signed(digest, arch_ptrace_read_user_body_result(
			&arch_thread, 16, &value, sizeof(value), 64, 16,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(value == live.sr[0]);
		mix(digest, value);

		arch_thread.saved_valid = 1;
		arch_thread.saved_uctx.gpr[2] = 0xabcdef01UL;
		mix_signed(digest, arch_ptrace_read_user_body_result(
			&arch_thread, 16, &value, sizeof(value), 64, 24,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(value == arch_thread.saved_uctx.gpr[2]);
		mix(digest, value);
		arch_thread.saved_valid = 0;

		old_flags = live.gpr[6];
		mix_signed(digest, arch_ptrace_write_user_body_result(
			&arch_thread, 48, 0xffffffffffffffffUL,
			sizeof(value), 64, 16, 48, 128, 128 + 64,
			&arch_offsets, fake_arch_lookup_user_context,
			fake_arch_user_log));
		require((live.gpr[6] & ~RFLAGS_MASK) ==
			(old_flags & ~RFLAGS_MASK));
		require((live.gpr[6] & RFLAGS_MASK) == RFLAGS_MASK);
		mix(digest, live.gpr[6]);
		mix_signed(digest, arch_ptrace_write_user_body_result(
			&arch_thread, 24, 0x7777UL, sizeof(value), 64, 16,
			48, 128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(live.sr[1] == 0x7777UL);
		mix(digest, live.sr[1]);

		arch_thread.debugreg = debugreg;
		debugreg[3] = 0xd00dUL;
		mix_signed(digest, arch_ptrace_read_user_body_result(
			&arch_thread, 128 + 3 * (long)sizeof(value), &value,
			sizeof(value), 64, 16, 128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(value == 0xd00dUL);
		mix(digest, value);
		mix_signed(digest, arch_ptrace_write_user_body_result(
			&arch_thread, 128 + 6 * (long)sizeof(value),
			0xffffffffffffffffUL, sizeof(value), 64, 16, 48,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(debugreg[6] == ((0xffffffffffffffffUL &
			~DB6_RESERVED_MASK) | DB6_RESERVED_SET));
		mix(digest, debugreg[6]);
		mix_signed(digest, arch_ptrace_write_user_body_result(
			&arch_thread, 128 + 7 * (long)sizeof(value),
			0xffffffffffffffffUL, sizeof(value), 64, 16, 48,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(debugreg[7] == ((0xffffffffffffffffUL &
			~DB7_RESERVED_MASK) | DB7_RESERVED_SET));
		mix(digest, debugreg[7]);

		arch_thread.debugreg = NULL;
		mix_signed(digest, arch_ptrace_read_user_body_result(
			&arch_thread, 128, &value, sizeof(value), 64, 16,
			128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(arch_thread.log_event ==
			ARCH_PTRACE_USER_LOG_READ_MISSING_DEBUGREG);
		mix_signed(digest, arch_thread.log_event);
		mix_signed(digest, arch_ptrace_write_user_body_result(
			&arch_thread, 200, 0xaaaaUL, sizeof(value), 64, 16,
			48, 128, 128 + 64, &arch_offsets,
			fake_arch_lookup_user_context, fake_arch_user_log));
		require(arch_thread.log_event ==
			ARCH_PTRACE_USER_LOG_WRITE_OTHER);
		mix_signed(digest, arch_thread.log_value);

		memset(debugreg, 0x5a, sizeof(debugreg));
		fake_arch_alloc_result = debugreg;
		fake_arch_alloc_calls = 0;
		mix_signed(digest, arch_alloc_debugreg_body_result(
			&arch_thread,
			offsetof(struct fake_arch_ptrace_thread, debugreg),
			sizeof(debugreg), 0x55, fake_arch_alloc,
			fake_arch_user_log));
		require(arch_thread.debugreg == debugreg);
		require(fake_arch_alloc_calls == 1);
		require(fake_arch_alloc_size == sizeof(debugreg));
		require(fake_arch_alloc_flags == 0x55);
		require(debugreg[0] == 0);
		require(debugreg[6] == DB6_RESERVED_SET);
		require(debugreg[7] == DB7_RESERVED_SET);
		mix(digest, debugreg[6]);
		fake_arch_alloc_result = NULL;
		arch_thread.debugreg = debugreg;
		mix_signed(digest, arch_alloc_debugreg_body_result(
			&arch_thread,
			offsetof(struct fake_arch_ptrace_thread, debugreg),
			sizeof(debugreg), 0x56, fake_arch_alloc,
			fake_arch_user_log));
		require(arch_thread.debugreg == NULL);
		require(arch_thread.log_event ==
			ARCH_PTRACE_USER_LOG_ALLOC_FAILED);
		mix_signed(digest, arch_thread.log_event);

		active_regset_thread = &copy_tracker;
		active_arch_ptrace_thread = &arch_thread;
		proc.status = PS_TRACED;
		arch_thread.find_key = 7001;
		arch_thread.unlocks = 0;
		live.sr[0] = 0x12345678UL;
		mix_signed(digest, arch_ptrace_prctl_body_result(7001,
			ARCH_GET_FS, (long)&copied, sizeof(value), 16, 24,
			&arch_offsets, fake_arch_find_thread,
			fake_arch_thread_unlock, fake_arch_read_user,
			fake_arch_write_user, fake_regset_copy_to));
		require(copied == live.sr[0]);
		require(arch_thread.unlocks == 1);
		mix(digest, copied);
		mix_signed(digest, arch_ptrace_prctl_body_result(7001,
			ARCH_SET_GS, 0x99887766UL, sizeof(value), 16, 24,
			&arch_offsets, fake_arch_find_thread,
			fake_arch_thread_unlock, fake_arch_read_user,
			fake_arch_write_user, fake_regset_copy_to));
		require(live.sr[1] == 0x99887766UL);
		require(arch_thread.unlocks == 2);
		mix(digest, live.sr[1]);
		mix_signed(digest, arch_ptrace_prctl_body_result(7002,
			ARCH_GET_FS, (long)&copied, sizeof(value), 16, 24,
			&arch_offsets, fake_arch_find_thread,
			fake_arch_thread_unlock, fake_arch_read_user,
			fake_arch_write_user, fake_regset_copy_to));
		proc.status = PS_RUNNING;
		mix_signed(digest, arch_ptrace_prctl_body_result(7001,
			ARCH_GET_FS, (long)&copied, sizeof(value), 16, 24,
			&arch_offsets, fake_arch_find_thread,
			fake_arch_thread_unlock, fake_arch_read_user,
			fake_arch_write_user, fake_regset_copy_to));
	}
	{
		struct fake_vm_word vm = {
			.value = 0xfeedfacecafebeefUL,
			.last_addr = 0,
			.fail = 0,
		};
		unsigned long word = 0;

		mix_signed(digest, ptrace_read_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x12345000UL, &word,
			fake_ptrace_read_vm_word));
		require(word == 0xfeedfacecafebeefUL);
		require(vm.last_addr == 0x12345000UL);
		mix(digest, word);
		mix(digest, vm.last_addr);

		vm.fail = 1;
		word = 0x7777UL;
		mix_signed(digest, ptrace_read_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x12346000UL, &word,
			fake_ptrace_read_vm_word));
		require(word == 0x7777UL);
		require(vm.last_addr == 0x12346000UL);
		vm.fail = 0;
		mix_signed(digest, ptrace_read_vm_word_result(PS_RUNNING,
			(unsigned long)&vm, 0x12347000UL, &word,
			fake_ptrace_read_vm_word));
		mix_signed(digest, ptrace_read_vm_word_result(PS_TRACED, 0,
			0x12348000UL, &word, fake_ptrace_read_vm_word));
		mix_signed(digest, ptrace_read_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x12349000UL, NULL,
			fake_ptrace_read_vm_word));
		mix_signed(digest, ptrace_read_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x1234a000UL, &word, NULL));

		mix_signed(digest, ptrace_write_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x1234b000UL, 0xababababUL,
			fake_ptrace_write_vm_word));
		require(vm.value == 0xababababUL);
		require(vm.last_addr == 0x1234b000UL);
		mix(digest, vm.value);
		mix(digest, vm.last_addr);

		vm.fail = 1;
		mix_signed(digest, ptrace_write_vm_word_result(PS_TRACED,
			(unsigned long)&vm, 0x1234c000UL, 0xcdcdcdcdUL,
			fake_ptrace_write_vm_word));
		require(vm.value == 0xababababUL);
		vm.fail = 0;
		mix_signed(digest, ptrace_write_vm_word_result(PS_RUNNING,
			(unsigned long)&vm, 0x1234d000UL, 0xefefefefUL,
			fake_ptrace_write_vm_word));
			mix_signed(digest, ptrace_write_vm_word_result(PS_TRACED, 0,
				0x1234e000UL, 0x1234UL, fake_ptrace_write_vm_word));
			mix_signed(digest, ptrace_write_vm_word_result(PS_TRACED,
				(unsigned long)&vm, 0x1234f000UL, 0x5678UL, NULL));
		}
		{
			struct fake_fpregs_thread fpregs = { 0 };

			mix_signed(digest, ptrace_fpregs_io_result(PS_TRACED,
				(unsigned long)&fpregs, 0xfeed0001UL,
				fake_ptrace_fpregs_io));
			require(fpregs.last_data == 0xfeed0001UL);
			mix(digest, fpregs.last_data);

			fpregs.fail = 1;
			mix_signed(digest, ptrace_fpregs_io_result(PS_TRACED,
				(unsigned long)&fpregs, 0xfeed0002UL,
				fake_ptrace_fpregs_io));
			require(fpregs.last_data == 0xfeed0002UL);
			fpregs.fail = 0;
			mix_signed(digest, ptrace_fpregs_io_result(PS_RUNNING,
				(unsigned long)&fpregs, 0xfeed0003UL,
				fake_ptrace_fpregs_io));
			mix_signed(digest, ptrace_fpregs_io_result(PS_TRACED, 0,
				0xfeed0004UL, fake_ptrace_fpregs_io));
			mix_signed(digest, ptrace_fpregs_io_result(PS_TRACED,
				(unsigned long)&fpregs, 0xfeed0005UL, NULL));
		}
		{
			struct fake_regset_thread regset = {
				.new_len = 0x44,
			};
			struct fake_iovec user_iov = {
				.iov_base = (void *)0xabcddcbaUL,
				.iov_len = 0x88,
			};
			struct fake_iovec scratch = { 0 };

			active_regset_thread = &regset;
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x123,
				(unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			require(regset.copy_from_calls == 1);
			require(regset.io_calls == 1);
			require(regset.copy_to_calls == 1);
			require(regset.seen_base == 0xabcddcbaUL);
			require(regset.seen_len == 0x88);
			require(regset.seen_type == 0x123);
			require(user_iov.iov_len == 0x44);
			mix(digest, user_iov.iov_len);
			mix(digest, regset.seen_base);
			mix(digest, regset.seen_len);
			mix_signed(digest, regset.seen_type);

			memset(&regset, 0, sizeof(regset));
			regset.copy_from_fail = 1;
			regset.new_len = 0x55;
			user_iov.iov_len = 0x99;
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x124,
				(unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			require(regset.copy_from_calls == 1);
			require(regset.io_calls == 0);
			require(regset.copy_to_calls == 0);
			require(user_iov.iov_len == 0x99);

			memset(&regset, 0, sizeof(regset));
			regset.io_fail = 1;
			regset.new_len = 0x66;
			user_iov.iov_len = 0xaa;
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x125,
				(unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			require(regset.copy_from_calls == 1);
			require(regset.io_calls == 1);
			require(regset.copy_to_calls == 0);
			require(user_iov.iov_len == 0xaa);

			memset(&regset, 0, sizeof(regset));
			regset.copy_to_fail = 1;
			regset.new_len = 0x77;
			user_iov.iov_len = 0xbb;
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x126,
				(unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			require(regset.copy_from_calls == 1);
			require(regset.io_calls == 1);
			require(regset.copy_to_calls == 1);
			require(user_iov.iov_len == 0xbb);

			memset(&regset, 0, sizeof(regset));
			regset.new_len = 0x88;
			mix_signed(digest, ptrace_regset_io_result(PS_RUNNING,
				(unsigned long)&regset, 0x127,
				(unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			require(regset.copy_from_calls == 0);
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED, 0,
				0x128, (unsigned long)&user_iov, &scratch,
				sizeof(scratch), offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x129,
				(unsigned long)&user_iov, NULL, sizeof(scratch),
				offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, fake_regset_copy_to));
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x12a,
				(unsigned long)&user_iov, &scratch, sizeof(scratch),
				sizeof(scratch), sizeof(user_iov.iov_len),
				fake_regset_copy_from, fake_ptrace_regset_io,
				fake_regset_copy_to));
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x12b,
				(unsigned long)&user_iov, &scratch, sizeof(scratch),
				offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), NULL,
				fake_ptrace_regset_io, fake_regset_copy_to));
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x12c,
				(unsigned long)&user_iov, &scratch, sizeof(scratch),
				offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				NULL, fake_regset_copy_to));
			mix_signed(digest, ptrace_regset_io_result(PS_TRACED,
				(unsigned long)&regset, 0x12d,
				(unsigned long)&user_iov, &scratch, sizeof(scratch),
				offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), fake_regset_copy_from,
				fake_ptrace_regset_io, NULL));
		}
		{
			struct fake_reg_thread regs = {
				.values = {
					0x1000UL, 0x2000UL, 0x3000UL, 0x4000UL,
					0x5000UL, 0x6000UL, 0x7000UL, 0x8000UL,
				},
				.fail_at = -1,
			};
			unsigned long gp_out[8];
			unsigned long gp_in[8] = {
				0x8100UL, 0x8200UL, 0x8300UL, 0x8400UL,
				0x8500UL, 0x8600UL, 0x8700UL, 0x8800UL,
			};
			struct fake_regset_thread regset = { 0 };
			struct fake_iovec iov;
			unsigned long user_words[8] = {
				0xa100UL, 0xa200UL, 0xa300UL, 0xa400UL,
				0xa500UL, 0xa600UL, 0xa700UL, 0xa800UL,
			};
			unsigned long scratch[8];
			char fp_storage[64];
			char fp_user[64];
			struct fake_arch_fpregs_thread fp_thread = {
				.fp_regs = fp_storage,
			};

			memset(gp_out, 0x5a, sizeof(gp_out));
			mix_signed(digest, arch_ptrace_read_gpregs_body_result(
				(unsigned long)&regs, gp_out, sizeof(gp_out),
				fake_ptrace_read_word));
			require(memcmp(gp_out, regs.values, sizeof(gp_out)) == 0);
			for (unsigned int i = 0; i < sizeof(gp_out) /
					sizeof(gp_out[0]); i++)
				mix(digest, gp_out[i]);

			regs.fail_at = 2;
			memset(gp_out, 0x5a, sizeof(gp_out));
			mix_signed(digest, arch_ptrace_read_gpregs_body_result(
				(unsigned long)&regs, gp_out, sizeof(gp_out),
				fake_ptrace_read_word));
			require(gp_out[0] == regs.values[0]);
			require(gp_out[1] == regs.values[1]);
			require(gp_out[2] == 0);
			regs.fail_at = -1;
			mix_signed(digest, arch_ptrace_read_gpregs_body_result(
				(unsigned long)&regs, NULL, sizeof(gp_out),
				fake_ptrace_read_word));

			memset(regs.written, 0, sizeof(regs.written));
			mix_signed(digest, arch_ptrace_write_gpregs_body_result(
				(unsigned long)&regs, gp_in, sizeof(gp_in),
				fake_ptrace_write_word));
			require(memcmp(regs.written, gp_in, sizeof(gp_in)) == 0);
			for (unsigned int i = 0; i < sizeof(regs.written) /
					sizeof(regs.written[0]); i++)
				mix(digest, regs.written[i]);

			for (unsigned int i = 0; i < sizeof(fp_storage); i++) {
				fp_storage[i] = (char)(i + 1);
				fp_user[i] = 0;
			}
			active_regset_thread = &regset;
			mix_signed(digest, arch_ptrace_fpregs_io_body_result(
				(unsigned long)&fp_thread,
				(unsigned long)fp_user,
				offsetof(struct fake_arch_fpregs_thread, fp_regs),
				8, 16, 0, fake_regset_copy_to,
				fake_regset_copy_from));
			require(regset.copy_to_calls == 1);
			require(memcmp(fp_user, fp_storage + 8, 16) == 0);
			mix(digest, (unsigned char)fp_user[0]);
			memcpy(fp_user, "abcdefghijklmnop", 16);
			mix_signed(digest, arch_ptrace_fpregs_io_body_result(
				(unsigned long)&fp_thread,
				(unsigned long)fp_user,
				offsetof(struct fake_arch_fpregs_thread, fp_regs),
				8, 16, 1, fake_regset_copy_to,
				fake_regset_copy_from));
			require(regset.copy_from_calls == 1);
			require(memcmp(fp_storage + 8, fp_user, 16) == 0);
			mix(digest, (unsigned char)fp_storage[8]);
			fp_thread.fp_regs = NULL;
			mix_signed(digest, arch_ptrace_fpregs_io_body_result(
				(unsigned long)&fp_thread,
				(unsigned long)fp_user,
				offsetof(struct fake_arch_fpregs_thread, fp_regs),
				8, 16, 0, fake_regset_copy_to,
				fake_regset_copy_from));
			fp_thread.fp_regs = fp_storage;

			memset(&regset, 0, sizeof(regset));
			active_regset_thread = &regset;
			iov.iov_base = gp_out;
			iov.iov_len = sizeof(gp_out) + 32;
			memset(gp_out, 0, sizeof(gp_out));
			mix_signed(digest, arch_ptrace_read_regset_body_result(
				(unsigned long)&regs, NT_PRSTATUS, &iov,
				scratch, sizeof(gp_out), 32,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_regset_copy_to, fake_arch_xstate_copy_to,
				fake_arch_regset_log));
			require(iov.iov_len == sizeof(gp_out));
			require(regset.copy_to_calls == 1);
			require(memcmp(gp_out, regs.values, sizeof(gp_out)) == 0);
			mix(digest, iov.iov_len);
			mix(digest, gp_out[7]);

			memset(regs.written, 0, sizeof(regs.written));
			iov.iov_base = user_words;
			iov.iov_len = sizeof(user_words) + 32;
			mix_signed(digest, arch_ptrace_write_regset_body_result(
				(unsigned long)&regs, NT_PRSTATUS, &iov,
				scratch, sizeof(user_words), 32,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_arch_ptrace_write_gpregs,
				fake_regset_copy_from,
				fake_arch_xstate_copy_from,
				fake_arch_regset_log));
			require(iov.iov_len == sizeof(user_words));
			require(regset.copy_from_calls == 1);
			require(memcmp(regs.written, user_words,
				sizeof(user_words)) == 0);
			mix(digest, regs.written[0]);
			mix(digest, regs.written[7]);

			memset(&regset, 0, sizeof(regset));
			active_regset_thread = &regset;
			iov.iov_base = (void *)0xabcdef00UL;
			iov.iov_len = 128;
			mix_signed(digest, arch_ptrace_read_regset_body_result(
				(unsigned long)&regset, NT_X86_XSTATE, &iov,
				scratch, sizeof(scratch), 64,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_regset_copy_to, fake_arch_xstate_copy_to,
				fake_arch_regset_log));
			require(iov.iov_len == 64);
			require(regset.xstate_copy_to_calls == 1);
			require(regset.xstate_user_addr == 0xabcdef00UL);
			require(regset.xstate_bytes == 64);
			mix(digest, regset.xstate_bytes);

			iov.iov_len = 128;
			mix_signed(digest, arch_ptrace_write_regset_body_result(
				(unsigned long)&regset, NT_X86_XSTATE, &iov,
				scratch, sizeof(scratch), 64,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_arch_ptrace_write_gpregs,
				fake_regset_copy_from,
				fake_arch_xstate_copy_from,
				fake_arch_regset_log));
			require(iov.iov_len == 64);
			require(regset.xstate_copy_from_calls == 1);
			mix(digest, regset.xstate_copy_from_calls);

			iov.iov_len = 16;
			mix_signed(digest, arch_ptrace_read_regset_body_result(
				(unsigned long)&regset, 0x999, &iov,
				scratch, sizeof(scratch), 64,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_regset_copy_to, fake_arch_xstate_copy_to,
				fake_arch_regset_log));
			require(regset.log_event ==
				ARCH_PTRACE_REGSET_LOG_READ_UNSUPPORTED);
			require(regset.log_type == 0x999);
			mix_signed(digest, regset.log_calls);
			mix_signed(digest, arch_ptrace_write_regset_body_result(
				(unsigned long)&regset, 0x998, &iov,
				scratch, sizeof(scratch), 64,
				offsetof(struct fake_iovec, iov_base),
				offsetof(struct fake_iovec, iov_len),
				fake_arch_ptrace_read_gpregs,
				fake_arch_ptrace_write_gpregs,
				fake_regset_copy_from,
				fake_arch_xstate_copy_from,
				fake_arch_regset_log));
			require(regset.log_event ==
				ARCH_PTRACE_REGSET_LOG_WRITE_UNSUPPORTED);
			require(regset.log_type == 0x998);
			mix_signed(digest, regset.log_calls);
		}
		{
			struct fake_vm_word vm = {
				.value = 0x5152535455565758UL,
				.last_addr = 0,
				.fail = 0,
			};
			struct fake_ptrace_io_proc tracer_proc = {
				.pid = 3131,
			};
			struct fake_ptrace_io_proc tracee_proc = {
				.pid = 4242,
			};
			struct fake_ptrace_io_offsets offsets = {
				.thread_proc_offset =
					offsetof(struct fake_ptrace_io_thread,
						 proc),
				.thread_status_offset =
					offsetof(struct fake_ptrace_io_thread,
						 status),
				.thread_vm_offset =
					offsetof(struct fake_ptrace_io_thread,
						 vm),
				.thread_ptrace_offset =
					offsetof(struct fake_ptrace_io_thread,
						 ptrace),
				.thread_ptrace_eventmsg_offset =
					offsetof(struct fake_ptrace_io_thread,
						 eventmsg),
				.thread_ptrace_recvsig_offset =
					offsetof(struct fake_ptrace_io_thread,
						 ptrace_recvsig),
				.thread_ptrace_sendsig_offset =
					offsetof(struct fake_ptrace_io_thread,
						 ptrace_sendsig),
				.thread_report_proc_offset =
					offsetof(struct fake_ptrace_io_thread,
						 report_proc),
				.thread_ptrace_saved_uctx_valid_offset =
					offsetof(struct fake_ptrace_io_thread,
						 saved_valid),
				.proc_pid_offset =
					offsetof(struct fake_ptrace_io_proc, pid),
				.proc_update_lock_offset =
					offsetof(struct fake_ptrace_io_proc,
						 update_lock),
			};
			struct fake_ptrace_io_thread pio = {
				.proc = &tracee_proc,
				.status = PS_TRACED,
				.vm = &vm,
				.ptrace = PT_TRACED,
				.eventmsg = 0x777788889999aaaaUL,
				.report_proc = &tracer_proc,
				.saved_valid = 1,
				.values = {
					0x1100UL, 0x2200UL, 0x3300UL, 0x4400UL,
					0x5500UL, 0x6600UL, 0x7700UL, 0x8800UL,
				},
				.fail_at = -1,
				.find_key = 4242,
			};
			struct fake_ptrace_io_thread current_pio = {
				.proc = &tracer_proc,
			};
			unsigned long user_word = 0;
			unsigned long user_regs[8] = { 0 };
			unsigned long input_regs[8] = {
				0xa100UL, 0xa200UL, 0xa300UL, 0xa400UL,
				0xa500UL, 0xa600UL, 0xa700UL, 0xa800UL,
			};
			unsigned long scratch[8];
			struct fake_iovec user_iov = {
				.iov_base = (void *)0x12345678UL,
				.iov_len = 0x90,
			};
			struct fake_iovec scratch_iov = { 0 };
			struct fake_sig_pending recv_pending = { 0 };
			struct fake_sig_pending send_pending = { 0 };
			struct fake_sig_pending allocated_pending = { 0 };
			unsigned char user_info[128];
			unsigned char out_info[128];
			unsigned char info_scratch[128];

			active_ptrace_io_thread = &pio;
			active_regset_thread = &pio.regset;
			for (unsigned int i = 0; i < sizeof(user_info); i++) {
				user_info[i] = (unsigned char)(0xa0U + i);
				recv_pending.info[i] = (unsigned char)(0x40U + i);
				out_info[i] = 0;
			}

			mix_signed(digest, ptrace_pokeuser_body_result(4242,
				2 * (long)sizeof(unsigned long), 0xbadf00dUL,
				0x400, &offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_write_word));
			require(pio.written[2] == 0xbadf00dUL);
			require(pio.unlocks == 1);
			mix(digest, pio.written[2]);

			mix_signed(digest, ptrace_pokeuser_body_result(4242,
				0x400, 0x1UL, 0x400, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_write_word));
			require(pio.unlocks == 1);

			mix_signed(digest, ptrace_peekuser_body_result(4242,
				3 * (long)sizeof(unsigned long),
				(long)&user_word, 0x400, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_read_word,
				fake_regset_copy_to));
			require(user_word == pio.values[3]);
			require(pio.unlocks == 2);
			mix(digest, user_word);

			mix_signed(digest, ptrace_getregs_body_result(4242,
				(long)user_regs, scratch, sizeof(scratch),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_read_word,
				fake_regset_copy_to));
			require(memcmp(user_regs, pio.values,
				sizeof(user_regs)) == 0);
			require(pio.unlocks == 3);
			mix(digest, user_regs[0]);
			mix(digest, user_regs[7]);

			memset(pio.written, 0, sizeof(pio.written));
			mix_signed(digest, ptrace_setregs_body_result(4242,
				(long)input_regs, scratch, sizeof(scratch),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_write_word,
				fake_regset_copy_from));
			require(memcmp(pio.written, input_regs,
				sizeof(input_regs)) == 0);
			require(pio.unlocks == 4);
			mix(digest, pio.written[1]);
			mix(digest, pio.written[6]);

			mix_signed(digest, ptrace_fpregs_body_result(4242,
				0xfeedbeefUL, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_fpregs));
			require(pio.last_data == 0xfeedbeefUL);
			require(pio.unlocks == 5);
			mix(digest, pio.last_data);

			memset(&pio.regset, 0, sizeof(pio.regset));
			pio.regset.new_len = 0x34;
			user_iov.iov_len = 0x90;
			mix_signed(digest, ptrace_regset_body_result(4242,
				0x444, (long)&user_iov, &scratch_iov,
				sizeof(scratch_iov),
				offsetof(struct fake_iovec, iov_len),
				sizeof(user_iov.iov_len), &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_regset_copy_from,
				fake_ptrace_io_regset,
				fake_regset_copy_to));
			require(pio.regset.copy_from_calls == 1);
			require(pio.regset.io_calls == 1);
			require(pio.regset.copy_to_calls == 1);
			require(user_iov.iov_len == 0x34);
			require(pio.unlocks == 6);
			mix(digest, user_iov.iov_len);
			mix_signed(digest, pio.regset.seen_type);

			mix_signed(digest, ptrace_peektext_body_result(4242,
				0x9000, (long)&user_word, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_read_vm_word,
				fake_regset_copy_to,
				fake_ptrace_text_log));
			require(user_word == vm.value);
			require(vm.last_addr == 0x9000);
			require(pio.unlocks == 7);
			mix(digest, user_word);

			vm.fail = 1;
			pio.log_event = 0;
			mix_signed(digest, ptrace_peektext_body_result(4242,
				0x9008, (long)&user_word, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_read_vm_word,
				fake_regset_copy_to,
				fake_ptrace_text_log));
			require(pio.log_event == PTRACE_TEXT_LOG_PEEK_BAD_AREA);
			require(pio.log_addr == 0x9008);
			require(pio.unlocks == 8);
			vm.fail = 0;
			mix(digest, pio.log_addr);

			mix_signed(digest, ptrace_poketext_body_result(4242,
				0x9010, 0xabcdefUL, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_write_vm_word,
				fake_ptrace_text_log));
			require(vm.value == 0xabcdefUL);
			require(vm.last_addr == 0x9010);
			require(pio.unlocks == 9);
			mix(digest, vm.value);

			vm.fail = 1;
			pio.log_event = 0;
			mix_signed(digest, ptrace_poketext_body_result(4242,
				0x9018, 0x123456UL, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_write_vm_word,
				fake_ptrace_text_log));
			require(pio.log_event ==
				PTRACE_TEXT_LOG_POKE_BAD_ADDRESS);
			require(pio.log_addr == 0x9018);
			require(pio.unlocks == 10);
			vm.fail = 0;
			mix(digest, pio.log_addr);

			user_word = 0;
			mix_signed(digest, ptrace_geteventmsg_body_result(4242,
				(long)&user_word, sizeof(user_word), &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_regset_copy_to));
			require(user_word == pio.eventmsg);
			require(pio.unlocks == 11);
			mix(digest, user_word);

			pio.ptrace_recvsig = &recv_pending;
			memset(out_info, 0, sizeof(out_info));
			mix_signed(digest, ptrace_getsiginfo_body_result(4242,
				(unsigned long)out_info, info_scratch,
				sizeof(out_info),
				offsetof(struct fake_sig_pending, info),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_regset_copy_to));
			require(memcmp(out_info, recv_pending.info,
				sizeof(out_info)) == 0);
			require(pio.unlocks == 12);
			mix(digest, out_info[0]);
			mix(digest, out_info[sizeof(out_info) - 1]);

			pio.ptrace_recvsig = NULL;
			mix_signed(digest, ptrace_getsiginfo_body_result(4242,
				(unsigned long)out_info, info_scratch,
				sizeof(out_info),
				offsetof(struct fake_sig_pending, info),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_regset_copy_to));
			require(pio.unlocks == 13);

			pio.ptrace_recvsig = &recv_pending;
			pio.ptrace_sendsig = NULL;
			memset(&pio.regset, 0, sizeof(pio.regset));
			memset(allocated_pending.info, 0,
				sizeof(allocated_pending.info));
			fake_ptrace_alloc_result = &allocated_pending;
			fake_ptrace_alloc_calls = 0;
			mix_signed(digest, ptrace_setsiginfo_body_result(4242,
				(unsigned long)user_info, info_scratch,
				sizeof(user_info), sizeof(struct fake_sig_pending),
				0x55aaUL, offsetof(struct fake_sig_pending, info),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock, fake_ptrace_alloc,
				fake_regset_copy_from));
			require(fake_ptrace_alloc_calls == 1);
			require(fake_ptrace_alloc_size ==
				sizeof(struct fake_sig_pending));
			require(fake_ptrace_alloc_flags == 0x55aaUL);
			require(pio.ptrace_sendsig == &allocated_pending);
			require(memcmp(allocated_pending.info, user_info,
				sizeof(user_info)) == 0);
			require(memcmp(recv_pending.info, user_info,
				sizeof(user_info)) == 0);
			require(pio.unlocks == 14);
			mix(digest, allocated_pending.info[0]);
			mix(digest, recv_pending.info[sizeof(user_info) - 1]);

			pio.ptrace_sendsig = &send_pending;
			pio.ptrace_recvsig = NULL;
			memset(send_pending.info, 0, sizeof(send_pending.info));
			mix_signed(digest, ptrace_setsiginfo_body_result(4242,
				(unsigned long)user_info, info_scratch,
				sizeof(user_info), sizeof(struct fake_sig_pending),
				0x55aaUL, offsetof(struct fake_sig_pending, info),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock, fake_ptrace_alloc,
				fake_regset_copy_from));
			require(memcmp(send_pending.info, user_info,
				sizeof(user_info)) == 0);
			require(pio.unlocks == 15);
			mix(digest, send_pending.info[1]);

			pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL;
			pio.log_event = 0;
			mix_signed(digest, ptrace_setoptions_body_result(4242,
				PTRACE_O_TRACEFORK | PTRACE_O_TRACEEXIT,
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_control_log));
			require((pio.ptrace & PTRACE_O_TRACEFORK) != 0);
			require((pio.ptrace & PTRACE_O_TRACEEXIT) != 0);
			require(pio.log_event ==
				PTRACE_CONTROL_LOG_SETOPTIONS_APPLIED);
			require(pio.log_value ==
				(PTRACE_O_TRACEFORK | PTRACE_O_TRACEEXIT));
			require(pio.unlocks == 16);
			mix_signed(digest, pio.ptrace);
			mix_signed(digest, pio.log_result);

			pio.log_event = 0;
			mix_signed(digest, ptrace_setoptions_body_result(4242,
				PTRACE_O_MASK | 0x80, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_control_log));
			require(pio.log_event ==
				PTRACE_CONTROL_LOG_SETOPTIONS_UNSUPPORTED);
			require(pio.unlocks == 16);

			pio.log_event = 0;
			pio.ptrace = 0;
			pio.report_proc = &tracer_proc;
			fake_ptrace_attach_calls = 0;
			fake_ptrace_attach_rc = -77;
			fake_ptrace_kill_calls = 0;
			fake_ptrace_kill_rc = 0;
			mix_signed(digest, ptrace_attach_body_result(4242,
				(unsigned long)&pio, (unsigned long)&tracer_proc,
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_attach_thread,
				fake_ptrace_control_do_kill,
				fake_ptrace_control_log));
			require(pio.ptrace == (PT_TRACED | PT_TRACE_EXEC));
			require(fake_ptrace_attach_calls == 1);
			require(fake_ptrace_attach_thread_addr == (unsigned long)&pio);
			require(fake_ptrace_attach_proc_addr ==
				(unsigned long)&tracer_proc);
			require(fake_ptrace_kill_calls == 1);
			require(fake_ptrace_kill_current == &pio);
			require(fake_ptrace_kill_pid == -1);
			require(fake_ptrace_kill_tid == 4242);
			require(fake_ptrace_kill_sig == SIGSTOP);
			require(fake_ptrace_kill_ptracecont == 2);
			require(fake_ptrace_kill_si_signo == SIGSTOP);
			require(fake_ptrace_kill_si_code == SI_USER);
			require(fake_ptrace_kill_si_pid == tracer_proc.pid);
			require(pio.log_event == PTRACE_CONTROL_LOG_ATTACH_RETURN);
			require(pio.log_result == 0);
			require(pio.unlocks == 17);
			mix_signed(digest, fake_ptrace_kill_si_pid);
			mix_signed(digest, fake_ptrace_attach_rc);

			pio.ptrace = 0;
			pio.proc = &tracer_proc;
			mix_signed(digest, ptrace_attach_body_result(4242,
				(unsigned long)&pio, (unsigned long)&tracer_proc,
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_attach_thread,
				fake_ptrace_control_do_kill,
				fake_ptrace_control_log));
			require(pio.unlocks == 18);
			pio.proc = &tracee_proc;

			pio.ptrace = PT_TRACED;
			pio.report_proc = &tracer_proc;
			fake_ptrace_detach_calls = 0;
			mix_signed(digest, ptrace_detach_body_result(4242, 7,
				(unsigned long)&tracer_proc, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_detach_call));
			require(fake_ptrace_detach_calls == 1);
			require(fake_ptrace_detach_thread_addr == (unsigned long)&pio);
			require(fake_ptrace_detach_data == 7);
			require(pio.unlocks == 19);
			mix_signed(digest, fake_ptrace_detach_data);

			pio.report_proc = &tracee_proc;
			mix_signed(digest, ptrace_detach_body_result(4242, 8,
				(unsigned long)&tracer_proc, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_detach_call));
			require(fake_ptrace_detach_calls == 1);
			require(pio.unlocks == 20);
			pio.report_proc = &tracer_proc;

			pio.saved_valid = 1;
			pio.wake_calls = 0;
			pio.log_event = 0;
			fake_ptrace_kill_calls = 0;
			fake_ptrace_kill_rc = 0;
			mix_signed(digest, ptrace_wakeup_sig_body_result(4242,
				PTRACE_KILL, 0, (unsigned long)&current_pio,
				offsetof(struct fake_sig_pending, info),
				&offsets, &scratch_iov, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock, fake_ptrace_control_log,
				fake_ptrace_clear_saved,
				fake_ptrace_set_single_step,
				fake_ptrace_update_lock,
				fake_ptrace_trace_syscall_update,
				fake_ptrace_update_unlock,
				fake_ptrace_pending_take,
				fake_ptrace_free_pending,
				fake_ptrace_control_do_kill,
				fake_ptrace_wakeup_thread));
			require(pio.saved_valid == 0);
			require(fake_ptrace_kill_calls == 1);
			require(fake_ptrace_kill_current == &current_pio);
			require(fake_ptrace_kill_pid == 4242);
			require(fake_ptrace_kill_tid == -1);
			require(fake_ptrace_kill_sig == SIGKILL);
			require(fake_ptrace_kill_ptracecont == 0);
			require(fake_ptrace_kill_si_signo == SIGKILL);
			require(pio.wake_states == (PS_TRACED | PS_STOPPED));
			require(pio.unlocks == 21);
			mix_signed(digest, fake_ptrace_kill_sig);

			{
				struct fake_siginfo *pending_info =
					(struct fake_siginfo *)send_pending.info;

				memset(pending_info, 0, sizeof(*pending_info));
				pending_info->si_signo = SIGURG;
				pending_info->si_code = 77;
				pending_info->sifields.kill.si_pid = 5151;
			}
			pio.saved_valid = 1;
			pio.ptrace = PT_TRACED;
			pio.ptrace_sendsig = &send_pending;
			pio.ptrace_recvsig = NULL;
			pio.wake_calls = 0;
			fake_ptrace_kill_calls = 0;
			fake_ptrace_free_calls = 0;
			fake_ptrace_lock_calls = 0;
			fake_ptrace_unlock_calls = 0;
			mix_signed(digest, ptrace_wakeup_sig_body_result(4242,
				PTRACE_CONT, SIGURG,
				(unsigned long)&current_pio,
				offsetof(struct fake_sig_pending, info),
				&offsets, &scratch_iov, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock, fake_ptrace_control_log,
				fake_ptrace_clear_saved,
				fake_ptrace_set_single_step,
				fake_ptrace_update_lock,
				fake_ptrace_trace_syscall_update,
				fake_ptrace_update_unlock,
				fake_ptrace_pending_take,
				fake_ptrace_free_pending,
				fake_ptrace_control_do_kill,
				fake_ptrace_wakeup_thread));
			require(pio.saved_valid == 0);
			require((pio.ptrace & PT_TRACE_SYSCALL) == 0);
			require(pio.ptrace_sendsig == NULL);
			require(fake_ptrace_free_calls == 1);
			require(fake_ptrace_freed_ptr == &send_pending);
			require(fake_ptrace_lock_calls == 1);
			require(fake_ptrace_unlock_calls == 1);
			require(fake_ptrace_lock_addr ==
				(unsigned long)&tracee_proc +
				offsetof(struct fake_ptrace_io_proc,
					 update_lock));
			require(fake_ptrace_lock_node == &scratch_iov);
			require(fake_ptrace_kill_calls == 1);
			require(fake_ptrace_kill_sig == SIGURG);
			require(fake_ptrace_kill_ptracecont == 1);
			require(fake_ptrace_kill_si_signo == SIGURG);
			require(fake_ptrace_kill_si_code == 77);
			require(fake_ptrace_kill_si_pid == 5151);
			require(pio.wake_states == (PS_TRACED | PS_STOPPED));
			require(pio.unlocks == 22);
			mix_signed(digest, fake_ptrace_kill_si_pid);

			pio.saved_valid = 1;
			pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL;
			pio.ptrace_sendsig = NULL;
			pio.ptrace_recvsig = NULL;
			pio.single_steps = 0;
			fake_ptrace_kill_calls = 0;
			mix_signed(digest, ptrace_wakeup_sig_body_result(4242,
				PTRACE_SINGLESTEP, SIGURG,
				(unsigned long)&current_pio,
				offsetof(struct fake_sig_pending, info),
				&offsets, &scratch_iov, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock, fake_ptrace_control_log,
				fake_ptrace_clear_saved,
				fake_ptrace_set_single_step,
				fake_ptrace_update_lock,
				fake_ptrace_trace_syscall_update,
				fake_ptrace_update_unlock,
				fake_ptrace_pending_take,
				fake_ptrace_free_pending,
				fake_ptrace_control_do_kill,
				fake_ptrace_wakeup_thread));
			require(pio.single_steps == 1);
			require((pio.ptrace & PT_TRACE_SYSCALL) == 0);
			require(fake_ptrace_kill_calls == 1);
			require(fake_ptrace_kill_sig == SIGURG);
			require(fake_ptrace_kill_si_signo == SIGURG);
			require(fake_ptrace_kill_si_code == SI_USER);
			require(fake_ptrace_kill_si_pid == tracer_proc.pid);
			require(pio.unlocks == 23);
			mix_signed(digest, fake_ptrace_kill_si_code);

			{
				struct fake_ptrace_io_proc new_proc = {
					.pid = 5252,
				};
				struct fake_ptrace_io_thread new_pio = {
					.proc = &new_proc,
					.tid = 5151,
					.status = PS_RUNNING,
				};
				struct fake_ptrace_report_clone_offsets clone_offsets = {
					.thread_proc_offset =
						offsetof(struct fake_ptrace_io_thread,
							 proc),
					.thread_tid_offset =
						offsetof(struct fake_ptrace_io_thread,
							 tid),
					.thread_status_offset =
						offsetof(struct fake_ptrace_io_thread,
							 status),
					.thread_exit_status_offset =
						offsetof(struct fake_ptrace_io_thread,
							 exit_status),
					.thread_ptrace_offset =
						offsetof(struct fake_ptrace_io_thread,
							 ptrace),
					.thread_ptrace_eventmsg_offset =
						offsetof(struct fake_ptrace_io_thread,
							 eventmsg),
					.proc_pid_offset =
						offsetof(struct fake_ptrace_io_proc,
							 pid),
					.proc_parent_offset =
						offsetof(struct fake_ptrace_io_proc,
							 parent),
					.proc_status_offset =
						offsetof(struct fake_ptrace_io_proc,
							 status),
					.proc_update_lock_offset =
						offsetof(struct fake_ptrace_io_proc,
							 update_lock),
					.proc_waitpid_q_offset =
						offsetof(struct fake_ptrace_io_proc,
							 waitpid_q),
				};

				tracee_proc.parent = &tracer_proc;
				tracee_proc.status = PS_RUNNING;
				tracer_proc.waitpid_q = 0x1234;
				pio.tid = 4242;
				pio.proc = &tracee_proc;
				pio.status = PS_RUNNING;
				pio.exit_status = 0;
				pio.eventmsg = 0;
				pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL |
					PTRACE_O_TRACEFORK;
				new_pio.ptrace = 0;
				fake_ptrace_attach_calls = 0;
				fake_ptrace_kill_calls = 0;
				fake_ptrace_kill_rc = 0;
				fake_ptrace_lock_calls = 0;
				fake_ptrace_unlock_calls = 0;
				fake_ptrace_waitq_wake_calls = 0;
				pio.log_event = 0;
				mix_signed(digest, ptrace_report_clone_body_result(
					&pio, &new_pio, PTRACE_EVENT_FORK,
					&current_pio, &clone_offsets,
					&scratch_iov, &user_iov,
					fake_ptrace_update_lock,
					fake_ptrace_update_unlock,
					fake_ptrace_attach_thread,
					fake_ptrace_control_do_kill,
					fake_ptrace_waitq_wake,
					fake_ptrace_control_log));
				require(pio.exit_status ==
					(SIGTRAP | (PTRACE_EVENT_FORK << 8)));
				require(tracee_proc.status == PS_TRACED);
				require(pio.status == PS_TRACED);
				require(pio.eventmsg == (unsigned long)new_pio.tid);
				require((pio.ptrace & PT_TRACE_SYSCALL) == 0);
				require((pio.ptrace & PTRACE_O_TRACEFORK) != 0);
				require(new_pio.ptrace == pio.ptrace);
				require(new_pio.exit_status == SIGSTOP);
				require(new_proc.status == PS_TRACED);
				require(new_pio.status == PS_TRACED);
				require(fake_ptrace_attach_calls == 1);
				require(fake_ptrace_attach_thread_addr ==
					(unsigned long)&new_pio);
				require(fake_ptrace_attach_proc_addr ==
					(unsigned long)&tracer_proc);
				require(fake_ptrace_lock_calls == 2);
				require(fake_ptrace_unlock_calls == 2);
				require(fake_ptrace_lock_node == &user_iov);
				require(fake_ptrace_kill_calls == 1);
				require(fake_ptrace_kill_current == &current_pio);
				require(fake_ptrace_kill_pid == tracer_proc.pid);
				require(fake_ptrace_kill_tid == -1);
				require(fake_ptrace_kill_sig == SIGCHLD);
				require(fake_ptrace_kill_ptracecont == 0);
				require(fake_ptrace_kill_si_signo == SIGCHLD);
				require(fake_ptrace_kill_si_code == CLD_TRAPPED);
				require(fake_ptrace_kill_si_pid == tracee_proc.pid);
				require(fake_ptrace_kill_si_status == pio.exit_status);
				require(fake_ptrace_waitq_wake_calls == 1);
				require(fake_ptrace_waitq_wake_addr ==
					(char *)&tracer_proc +
					offsetof(struct fake_ptrace_io_proc,
						 waitpid_q));
				require(pio.log_event ==
					PTRACE_REPORT_CLONE_LOG_KILL_SIGCHLD);
				mix_signed(digest, fake_ptrace_kill_si_status);
				mix_signed(digest, fake_ptrace_waitq_wake_calls);

				pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL |
					PTRACE_O_TRACEVFORKDONE;
				pio.status = PS_RUNNING;
				pio.exit_status = 0;
				pio.eventmsg = 0;
				tracee_proc.status = PS_RUNNING;
				new_pio.status = PS_RUNNING;
				new_pio.exit_status = 0;
				new_pio.ptrace = 0;
				new_proc.status = PS_RUNNING;
				fake_ptrace_attach_calls = 0;
				fake_ptrace_kill_calls = 0;
				fake_ptrace_kill_rc = -88;
				fake_ptrace_lock_calls = 0;
				fake_ptrace_unlock_calls = 0;
				fake_ptrace_waitq_wake_calls = 0;
				pio.log_event = 0;
				mix_signed(digest, ptrace_report_clone_body_result(
					&pio, &new_pio, PTRACE_EVENT_VFORK_DONE,
					&current_pio, &clone_offsets,
					&scratch_iov, &user_iov,
					fake_ptrace_update_lock,
					fake_ptrace_update_unlock,
					fake_ptrace_attach_thread,
					fake_ptrace_control_do_kill,
					fake_ptrace_waitq_wake,
					fake_ptrace_control_log));
				require(fake_ptrace_attach_calls == 0);
				require(fake_ptrace_lock_calls == 1);
				require(fake_ptrace_unlock_calls == 1);
				require(new_pio.status == PS_RUNNING);
				require(new_proc.status == PS_RUNNING);
				require(fake_ptrace_kill_calls == 1);
				require(fake_ptrace_waitq_wake_calls == 1);
				require(pio.log_event ==
					PTRACE_REPORT_CLONE_LOG_DO_KILL_FAILED);
				require(pio.log_result == -88);
				mix_signed(digest, pio.log_result);

				fake_ptrace_kill_rc = 0;
			}
			{
				struct fake_ptrace_report_exec_offsets exec_offsets = {
					.thread_ptrace_offset =
						offsetof(struct fake_ptrace_io_thread,
							 ptrace),
					.thread_ctx_offset =
						offsetof(struct fake_ptrace_io_thread,
							 kernel_ctx),
					.thread_uctx_offset =
						offsetof(struct fake_ptrace_io_thread,
							 uctx),
					.thread_ptrace_saved_uctx_offset =
						offsetof(struct fake_ptrace_io_thread,
							 saved_uctx),
					.thread_ptrace_saved_uctx_valid_offset =
						offsetof(struct fake_ptrace_io_thread,
							 saved_valid),
				};
				struct fake_ptrace_report_signal_offsets signal_offsets = {
					.thread_proc_offset =
						offsetof(struct fake_ptrace_io_thread,
							 proc),
					.thread_tid_offset =
						offsetof(struct fake_ptrace_io_thread,
							 tid),
					.thread_status_offset =
						offsetof(struct fake_ptrace_io_thread,
							 status),
					.thread_exit_status_offset =
						offsetof(struct fake_ptrace_io_thread,
							 exit_status),
					.thread_signal_flags_offset =
						offsetof(struct fake_ptrace_io_thread,
							 signal_flags),
					.thread_ptrace_offset =
						offsetof(struct fake_ptrace_io_thread,
							 ptrace),
					.thread_ptrace_debugreg_offset =
						offsetof(struct fake_ptrace_io_thread,
							 ptrace_debugreg),
					.thread_report_proc_offset =
						offsetof(struct fake_ptrace_io_thread,
							 report_proc),
					.proc_pid_offset =
						offsetof(struct fake_ptrace_io_proc,
							 pid),
					.proc_parent_offset =
						offsetof(struct fake_ptrace_io_proc,
							 parent),
					.proc_main_thread_offset =
						offsetof(struct fake_ptrace_io_proc,
							 main_thread),
					.proc_status_offset =
						offsetof(struct fake_ptrace_io_proc,
							 status),
					.proc_update_lock_offset =
						offsetof(struct fake_ptrace_io_proc,
							 update_lock),
					.proc_waitpid_q_offset =
						offsetof(struct fake_ptrace_io_proc,
							 waitpid_q),
				};
				unsigned char syscall_ctx[24];
				unsigned char ctx_scratch[16];
				unsigned long arch_ctx[2] = { 0, 0 };

				for (unsigned int i = 0; i < sizeof(syscall_ctx); i++)
					syscall_ctx[i] = (unsigned char)(0x80U + i);
				for (unsigned int i = 0; i < sizeof(pio.kernel_ctx); i++)
					pio.kernel_ctx[i] = (unsigned char)(0x20U + i);
				memset(pio.saved_uctx, 0, sizeof(pio.saved_uctx));
				pio.uctx = (void *)0xabcdefUL;
				pio.saved_valid = 0;
				pio.ptrace = PT_TRACED | PT_TRACE_EXEC |
					PT_TRACE_SYSCALL;
				fake_ptrace_preempt_enable_calls = 0;
				fake_ptrace_preempt_disable_calls = 0;
				fake_ptrace_report_signal_calls = 0;
				fake_ptrace_arch_event_calls = 0;
				mix_signed(digest, ptrace_report_exec_body_result(
					&pio, syscall_ctx, &exec_offsets,
					sizeof(pio.kernel_ctx), sizeof(syscall_ctx),
					ctx_scratch, fake_ptrace_preempt_enable,
					fake_ptrace_preempt_disable,
					fake_ptrace_report_signal,
					fake_ptrace_arch_syscall_event));
				require(fake_ptrace_preempt_enable_calls == 1);
				require(fake_ptrace_preempt_disable_calls == 1);
				require(fake_ptrace_report_signal_calls == 1);
				require(fake_ptrace_report_signal_sig ==
					(SIGTRAP | (PTRACE_EVENT_EXEC << 8)));
				require(fake_ptrace_arch_event_calls == 1);
				require(fake_ptrace_arch_event_thread == &pio);
				require(fake_ptrace_arch_event_ctx == pio.saved_uctx);
				require(fake_ptrace_arch_event_setret == 0);
				require(pio.uctx == (void *)0xabcdefUL);
				require(pio.saved_valid == 1);
				require(memcmp(pio.saved_uctx, syscall_ctx,
					       sizeof(syscall_ctx)) == 0);
				require(pio.kernel_ctx[0] == 0x20);
				mix_signed(digest, pio.saved_uctx[3]);
				mix_signed(digest, fake_ptrace_arch_event_calls);

				pio.ptrace = PT_TRACE_SYSCALL |
					PTRACE_O_TRACESYSGOOD;
				fake_ptrace_report_signal_calls = 0;
				mix_signed(digest, ptrace_syscall_event_body_result(
					&pio,
					offsetof(struct fake_ptrace_io_thread,
						 ptrace),
					fake_ptrace_report_signal));
				require(fake_ptrace_report_signal_calls == 1);
				require(fake_ptrace_report_signal_sig ==
					(SIGTRAP | 0x80));
				mix_signed(digest, fake_ptrace_report_signal_sig);

				tracee_proc.parent = &tracer_proc;
				tracee_proc.main_thread = &pio;
				tracee_proc.status = PS_RUNNING;
				tracer_proc.waitpid_q = 0x5151;
				pio.proc = &tracee_proc;
				pio.tid = 6161;
				pio.status = PS_RUNNING;
				pio.exit_status = 0;
				pio.signal_flags = 0;
				pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL;
				pio.ptrace_debugreg = (void *)0xfeedUL;
				fake_ptrace_lock_calls = 0;
				fake_ptrace_unlock_calls = 0;
				fake_ptrace_waitq_wake_calls = 0;
				fake_ptrace_save_debugreg_calls = 0;
				fake_ptrace_schedule_calls = 0;
				fake_ptrace_kill_calls = 0;
				pio.log_event = 0;
				mix_signed(digest, ptrace_report_signal_body_result(
					&pio, SIGSTOP, &current_pio,
					&signal_offsets, &scratch_iov,
					fake_ptrace_signal_lock,
					fake_ptrace_signal_unlock,
					fake_ptrace_save_debugreg,
					fake_ptrace_waitq_wake,
					fake_ptrace_control_do_kill,
					fake_ptrace_schedule,
					fake_ptrace_control_log));
				require(pio.exit_status == SIGSTOP);
				require(pio.status == PS_TRACED);
				require(tracee_proc.status == PS_TRACED);
				require((pio.ptrace & PT_TRACE_SYSCALL) == 0);
				require((pio.signal_flags & SIGNAL_STOP_STOPPED) != 0);
				require(fake_ptrace_saved_debugreg ==
					(void *)0xfeedUL);
				require(fake_ptrace_waitq_wake_calls == 1);
				require(fake_ptrace_waitq_wake_addr ==
					(char *)&tracer_proc +
					offsetof(struct fake_ptrace_io_proc,
						 waitpid_q));
				require(fake_ptrace_kill_calls == 1);
				require(fake_ptrace_kill_pid == tracer_proc.pid);
				require(fake_ptrace_kill_si_pid == pio.tid);
				require(fake_ptrace_kill_si_status == SIGSTOP);
				require(fake_ptrace_schedule_calls == 1);
				require(pio.log_event ==
					PTRACE_REPORT_SIGNAL_LOG_WAKE);
				mix_signed(digest, fake_ptrace_kill_si_status);
				mix_signed(digest, fake_ptrace_schedule_calls);

				tracee_proc.main_thread = &current_pio;
				pio.report_proc = &tracer_proc;
				pio.signal_flags = SIGNAL_STOP_STOPPED;
				pio.ptrace = PT_TRACED | PT_TRACE_SYSCALL;
				fake_ptrace_waitq_wake_calls = 0;
				fake_ptrace_kill_calls = 0;
				mix_signed(digest, ptrace_report_signal_body_result(
					&pio, SIGURG, &current_pio,
					&signal_offsets, &scratch_iov,
					fake_ptrace_signal_lock,
					fake_ptrace_signal_unlock,
					fake_ptrace_save_debugreg,
					fake_ptrace_waitq_wake,
					fake_ptrace_control_do_kill,
					fake_ptrace_schedule,
					fake_ptrace_control_log));
				require((pio.signal_flags & SIGNAL_STOP_STOPPED) == 0);
				require(fake_ptrace_waitq_wake_calls == 1);
				require(fake_ptrace_waitq_wake_addr ==
					(char *)&tracer_proc +
					offsetof(struct fake_ptrace_io_proc,
						 waitpid_q));
				require(fake_ptrace_kill_pid == tracer_proc.pid);
				require(fake_ptrace_kill_si_status == SIGURG);
				mix_signed(digest, pio.signal_flags);

				pio.eventmsg = 0;
				arch_ctx[0] = 0x11;
				fake_ptrace_arch_event_calls = 0;
				mix_signed(digest,
					arch_ptrace_syscall_event_body_result(
						&pio, arch_ctx, -ENOSYS, 0,
						fake_arch_ptrace_syscall_event_cb));
				require((long)arch_ctx[0] == -ENOSYS);
				require(fake_ptrace_arch_event_calls == 1);
				require(pio.eventmsg == 1);
				mix_signed(digest, pio.eventmsg);
			}

			pio.status = PS_RUNNING;
			mix_signed(digest, ptrace_getregs_body_result(4242,
				(long)user_regs, scratch, sizeof(scratch),
				&offsets, fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_read_word,
				fake_regset_copy_to));
			require(pio.unlocks == 24);
			mix_signed(digest, ptrace_geteventmsg_body_result(4242,
				(long)&user_word, sizeof(user_word), &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_regset_copy_to));
			require(pio.unlocks == 25);
			pio.status = PS_TRACED;

			mix_signed(digest, ptrace_peekuser_body_result(9999, 0,
				(long)&user_word, 0x400, &offsets,
				fake_ptrace_find_thread,
				fake_ptrace_thread_unlock,
				fake_ptrace_io_read_word,
				fake_regset_copy_to));
			require(pio.unlocks == 25);
		}

		for (unsigned int r = 0; r < sizeof(ptrace_requests) / sizeof(ptrace_requests[0]); r++) {
			mix_signed(digest, ptrace_request_dispatch_result(
			ptrace_requests[r]));
		mix_signed(digest, ptrace_wakeup_request_action_result(
			ptrace_requests[r]));
		mix_signed(digest, ptrace_resume_single_step_result(
			ptrace_requests[r]));
		mix_signed(digest, ptrace_resume_trace_syscall_result(
			ptrace_requests[r]));
		for (unsigned int d = 0; d < sizeof(ptrace_data) / sizeof(ptrace_data[0]); d++)
			mix_signed(digest, ptrace_resume_signal_needed_result(
				ptrace_requests[r], ptrace_data[d]));
		for (unsigned int send = 0; send < sizeof(bools) / sizeof(bools[0]); send++) {
			for (unsigned int recv = 0; recv < sizeof(bools) / sizeof(bools[0]); recv++)
				mix_signed(digest, ptrace_resume_signal_source_result(
					ptrace_requests[r], bools[send],
					bools[recv]));
		}
	}

	exercise_ptrace_syscall_body(digest);
}

static int
fake_do_wait_body_call(int pid, int *status, int options, void *rusage,
		       struct fake_do_wait_thread *thread,
		       struct fake_do_wait_entry *entry)
{
	return do_wait_body_result(pid, status, options, rusage, thread, entry,
		offsetof(struct fake_do_wait_thread, proc),
		offsetof(struct fake_do_wait_process, pid),
		offsetof(struct fake_do_wait_process, waitpid_q),
		0x5151, fake_do_wait_proc_scan, fake_do_wait_thread_scan,
		fake_do_wait_init, fake_do_wait_prepare,
		fake_do_wait_finish, fake_do_wait_has_signal,
		fake_do_wait_schedule, fake_do_wait_log);
}

static void
exercise_do_wait_body(unsigned long *digest)
{
	struct fake_do_wait_process proc;
	struct fake_do_wait_thread thread;
	struct fake_do_wait_entry entry;
	struct rusage usage;
	int status;
	int ret;

	memset(&proc, 0, sizeof(proc));
	memset(&thread, 0, sizeof(thread));
	memset(&entry, 0, sizeof(entry));
	memset(&usage, 0, sizeof(usage));
	proc.pid = 501;
	thread.proc = &proc;

	fake_do_wait_reset();
	fake_do_wait_proc_rc[0] = 44;
	fake_do_wait_proc_status[0] = 0x1234;
	status = -1;
	ret = fake_do_wait_body_call(44, &status, WEXITED, &usage, &thread,
		&entry);
	require(ret == 44);
	require(status == 0x1234);
	require(fake_do_wait_proc_calls == 1);
	require(fake_do_wait_thread_calls == 0);
	require(fake_do_wait_init_calls == 1);
	require(fake_do_wait_prepare_calls == 1);
	require(fake_do_wait_finish_calls == 1);
	require(fake_do_wait_schedule_calls == 0);
	require(fake_do_wait_log_count == 2);
	require(fake_do_wait_log_events[0] == WAIT_LOG_ENTER);
	require(fake_do_wait_log_events[1] == WAIT_LOG_FOUND);
	require(entry.thread == &thread);
	require(entry.waitq == &proc.waitpid_q);
	require(entry.status == 0x5151);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_do_wait_proc_calls);
	mix_signed(digest, fake_do_wait_thread_calls);
	mix_signed(digest, fake_do_wait_finish_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	fake_do_wait_thread_rc[0] = 77;
	fake_do_wait_thread_status[0] = 0x7777;
	status = -1;
	ret = fake_do_wait_body_call(55, &status, WEXITED | __WCLONE,
		&usage, &thread, &entry);
	require(ret == 77);
	require(status == 0x7777);
	require(fake_do_wait_proc_calls == 0);
	require(fake_do_wait_thread_calls == 1);
	require(fake_do_wait_finish_calls == 1);
	require(fake_do_wait_log_events[1] == WAIT_LOG_FOUND);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_do_wait_proc_calls);
	mix_signed(digest, fake_do_wait_thread_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	status = -1;
	ret = fake_do_wait_body_call(-1, &status, WEXITED, &usage, &thread,
		&entry);
	require(ret == -10);
	require(status == -1);
	require(fake_do_wait_proc_calls == 1);
	require(fake_do_wait_thread_calls == 0);
	require(fake_do_wait_finish_calls == 1);
	require(fake_do_wait_log_count == 2);
	require(fake_do_wait_log_events[1] == WAIT_LOG_NOTFOUND);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_do_wait_finish_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	fake_do_wait_proc_empty[0] = 0;
	status = 0x777;
	ret = fake_do_wait_body_call(-1, &status, WEXITED | WNOHANG,
		&usage, &thread, &entry);
	require(ret == 0);
	require(status == 0);
	require(fake_do_wait_proc_calls == 1);
	require(fake_do_wait_schedule_calls == 0);
	require(fake_do_wait_finish_calls == 1);
	require(fake_do_wait_log_events[1] == WAIT_LOG_NOTFOUND);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_do_wait_schedule_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	fake_do_wait_proc_empty[0] = 0;
	thread.signal_pending = 1;
	status = -1;
	ret = fake_do_wait_body_call(-1, &status, WEXITED, &usage, &thread,
		&entry);
	require(ret == -4);
	require(status == -1);
	require(fake_do_wait_has_signal_calls == 1);
	require(fake_do_wait_schedule_calls == 0);
	require(fake_do_wait_finish_calls == 1);
	require(fake_do_wait_log_count == 2);
	require(fake_do_wait_log_events[1] == WAIT_LOG_SLEEPING);
	thread.signal_pending = 0;
	mix_signed(digest, ret);
	mix_signed(digest, fake_do_wait_has_signal_calls);
	mix_signed(digest, fake_do_wait_schedule_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	fake_do_wait_proc_empty[0] = 0;
	fake_do_wait_proc_empty[1] = 0;
	fake_do_wait_proc_rc[1] = 88;
	fake_do_wait_proc_status[1] = 0x8888;
	status = -1;
	ret = fake_do_wait_body_call(-1, &status, WEXITED, &usage, &thread,
		&entry);
	require(ret == 88);
	require(status == 0x8888);
	require(fake_do_wait_proc_calls == 2);
	require(fake_do_wait_schedule_calls == 1);
	require(fake_do_wait_init_calls == 2);
	require(fake_do_wait_finish_calls == 2);
	require(fake_do_wait_log_count == 4);
	require(fake_do_wait_log_events[1] == WAIT_LOG_SLEEPING);
	require(fake_do_wait_log_events[2] == WAIT_LOG_WOKEN);
	require(fake_do_wait_log_events[3] == WAIT_LOG_FOUND);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_do_wait_schedule_calls);
	mix_signed(digest, fake_do_wait_finish_calls);
	mix(digest, fake_do_wait_scan_digest);
	mix(digest, fake_do_wait_log_digest);

	memset(&entry, 0, sizeof(entry));
	fake_do_wait_reset();
	status = -1;
	ret = do_wait_body_result(1, &status, WEXITED, &usage, NULL, &entry,
		offsetof(struct fake_do_wait_thread, proc),
		offsetof(struct fake_do_wait_process, pid),
		offsetof(struct fake_do_wait_process, waitpid_q),
		0x5151, fake_do_wait_proc_scan, fake_do_wait_thread_scan,
		fake_do_wait_init, fake_do_wait_prepare,
		fake_do_wait_finish, fake_do_wait_has_signal,
		fake_do_wait_schedule, fake_do_wait_log);
	require(ret == -22);
	ret = do_wait_body_result(1, NULL, WEXITED, &usage, &thread, &entry,
		offsetof(struct fake_do_wait_thread, proc),
		offsetof(struct fake_do_wait_process, pid),
		offsetof(struct fake_do_wait_process, waitpid_q),
		0x5151, fake_do_wait_proc_scan, fake_do_wait_thread_scan,
		fake_do_wait_init, fake_do_wait_prepare,
		fake_do_wait_finish, fake_do_wait_has_signal,
		fake_do_wait_schedule, fake_do_wait_log);
	require(ret == -22);
	ret = do_wait_body_result(1, &status, WEXITED, &usage, &thread, &entry,
		offsetof(struct fake_do_wait_thread, proc),
		offsetof(struct fake_do_wait_process, pid),
		offsetof(struct fake_do_wait_process, waitpid_q),
		0x5151, NULL, fake_do_wait_thread_scan,
		fake_do_wait_init, fake_do_wait_prepare,
		fake_do_wait_finish, fake_do_wait_has_signal,
		fake_do_wait_schedule, fake_do_wait_log);
	require(ret == -22);
	thread.proc = NULL;
	ret = fake_do_wait_body_call(1, &status, WEXITED, &usage, &thread,
		&entry);
	require(ret == -22);
	thread.proc = &proc;
	require(fake_do_wait_init_calls == 0);
	require(fake_do_wait_prepare_calls == 0);
	require(fake_do_wait_finish_calls == 0);
	mix_signed(digest, ret);
	mix_signed(digest, fake_do_wait_init_calls);
	mix_signed(digest, fake_do_wait_finish_calls);
}

static int
fake_wait_process_candidate_call(int current_ret, int pid, int *status,
				 int options,
				 struct fake_wait_candidate_thread *current,
				 struct fake_wait_candidate_process *child_proc,
				 struct fake_wait_candidate_thread *child,
				 int *found)
{
	int parent_lock = 1;
	int parent_node = 2;
	int child_lock = 3;
	int child_node = 4;

	return wait_process_candidate_body_result(current_ret, pid, status,
		options, current, child_proc, child, &parent_lock, &parent_node,
		&child_lock, &child_node,
		offsetof(struct fake_wait_candidate_process, pid),
		offsetof(struct fake_wait_candidate_process, status),
		offsetof(struct fake_wait_candidate_thread, tid),
		offsetof(struct fake_wait_candidate_thread, ptrace),
		offsetof(struct fake_wait_candidate_thread, signal_flags),
		fake_wait_candidate_stopped, fake_wait_candidate_continued,
		fake_wait_signal_flags_reap, fake_wait_candidate_unlock, found);
}

static int
fake_wait_thread_candidate_call(int current_ret, int tid, int *status,
				int options,
				struct fake_wait_candidate_thread *current,
				struct fake_wait_candidate_thread *child,
				int *found)
{
	int lock = 5;
	int node = 6;

	return wait_thread_candidate_body_result(current_ret, tid, status,
		options, current, child, &lock, &node,
		offsetof(struct fake_wait_candidate_thread, proc),
		offsetof(struct fake_wait_candidate_thread, tid),
		offsetof(struct fake_wait_candidate_thread, status),
		offsetof(struct fake_wait_candidate_thread, ptrace),
		offsetof(struct fake_wait_candidate_thread, signal_flags),
		fake_wait_candidate_stopped, fake_wait_candidate_continued,
		fake_wait_signal_flags_reap, fake_wait_candidate_unlock,
		fake_wait_candidate_report_detach,
		fake_wait_candidate_ptrace_detach,
		fake_wait_candidate_release, found);
}

static const struct fake_wait_zombie_offsets fake_wait_zombie_offsets = {
	.thread_ptrace_offset = offsetof(struct fake_wait_zombie_thread, ptrace),
	.proc_pid_offset = offsetof(struct fake_wait_zombie_process, pid),
	.proc_ppid_parent_offset =
		offsetof(struct fake_wait_zombie_process, ppid_parent),
	.proc_parent_offset = offsetof(struct fake_wait_zombie_process, parent),
	.proc_status_offset = offsetof(struct fake_wait_zombie_process, status),
	.proc_group_exit_status_offset =
		offsetof(struct fake_wait_zombie_process, group_exit_status),
	.proc_nowait_offset = offsetof(struct fake_wait_zombie_process, nowait),
	.proc_update_lock_offset =
		offsetof(struct fake_wait_zombie_process, update_lock),
	.proc_children_lock_offset =
		offsetof(struct fake_wait_zombie_process, children_lock),
	.proc_threads_lock_offset =
		offsetof(struct fake_wait_zombie_process, threads_lock),
	.proc_siblings_list_offset =
		offsetof(struct fake_wait_zombie_process, siblings_list),
	.proc_children_list_offset =
		offsetof(struct fake_wait_zombie_process, children_list),
	.proc_main_thread_offset =
		offsetof(struct fake_wait_zombie_process, main_thread),
	.proc_stime_offset = offsetof(struct fake_wait_zombie_process, stime),
	.proc_utime_offset = offsetof(struct fake_wait_zombie_process, utime),
	.proc_stime_children_offset =
		offsetof(struct fake_wait_zombie_process, stime_children),
	.proc_utime_children_offset =
		offsetof(struct fake_wait_zombie_process, utime_children),
	.proc_maxrss_offset = offsetof(struct fake_wait_zombie_process, maxrss),
	.proc_maxrss_children_offset =
		offsetof(struct fake_wait_zombie_process, maxrss_children),
};

static int
fake_wait_process_zombie_call(struct fake_wait_zombie_thread *current,
			      struct fake_wait_zombie_process *parent,
			      struct fake_wait_zombie_process *child,
			      struct fake_wait_zombie_process *pid1,
			      int *status, int options, struct rusage *usage)
{
	int parent_children_node = 1;
	int parent_update_node = 2;
	int child_update_node = 3;
	int pid1_children_node = 4;
	int child_threads_node = 5;

	fake_wait_zombie_active_child = child;
	fake_wait_zombie_active_parent = parent;
	fake_wait_zombie_active_pid1 = pid1;
	return wait_process_zombie_body_result(current, parent, child, status,
		options, usage, &parent->children_lock, &parent_children_node,
		pid1, &fake_wait_zombie_offsets, fake_wait_zombie_host_wait4,
		fake_wait_zombie_lock, fake_wait_zombie_unlock,
		fake_wait_zombie_list_detach, fake_wait_zombie_list_add_tail,
		fake_wait_zombie_ptrace_detach,
		fake_wait_zombie_release_process, fake_wait_zombie_log,
		&parent_update_node, &child_update_node, &pid1_children_node,
		&child_threads_node);
}

static void
exercise_wait_zombie_body(unsigned long *digest)
{
	struct fake_wait_zombie_process parent = { .pid = 500 };
	struct fake_wait_zombie_process tracer = { .pid = 700 };
	struct fake_wait_zombie_process pid1 = { .pid = 1 };
	struct fake_wait_zombie_thread current = { 0 };
	struct fake_wait_zombie_thread main_thread = { 0 };
	struct fake_wait_zombie_process child = {
		.pid = 55,
		.ppid_parent = &parent,
		.parent = &parent,
		.status = PS_ZOMBIE,
		.group_exit_status = 0x3300,
		.main_thread = &main_thread,
		.stime = { .tv_sec = 2, .tv_nsec = 900000000 },
		.utime = { .tv_sec = 3, .tv_nsec = 800000000 },
		.stime_children = { .tv_sec = 4, .tv_nsec = 300000000 },
		.utime_children = { .tv_sec = 5, .tv_nsec = 200000000 },
		.maxrss = 8192,
		.maxrss_children = 16384,
	};
	struct rusage usage;
	int status;
	int ret;

	memset(&usage, 0, sizeof(usage));
	parent.stime_children.tv_nsec = 250000000;
	parent.utime_children.tv_nsec = 750000000;
	parent.maxrss_children = 4096;
	fake_wait_zombie_reset();
	fake_wait_zombie_host_rc = child.pid;
	status = -1;
	ret = fake_wait_process_zombie_call(&current, &parent, &child, &pid1,
		&status, WEXITED, &usage);
	require(ret == child.pid);
	require(status == child.group_exit_status);
	require(fake_wait_zombie_host_calls == 1);
	require(fake_wait_zombie_detach_calls == 1);
	require(fake_wait_zombie_add_tail_calls == 1);
	require(fake_wait_zombie_release_calls == 1);
	require(child.parent == &pid1);
	require(child.ppid_parent == &pid1);
	require(child.sibling_detached == 1);
	require(child.sibling_added == 1);
	require(parent.stime_children.tv_sec == 7);
	require(parent.stime_children.tv_nsec == 450000000);
	require(parent.utime_children.tv_sec == 9);
	require(parent.utime_children.tv_nsec == 750000000);
	require(parent.maxrss_children == child.maxrss_children);
	require(usage.ru_utime.tv_sec == child.utime.tv_sec);
	require(usage.ru_utime.tv_usec == child.utime.tv_nsec / 1000);
	require(usage.ru_stime.tv_sec == child.stime.tv_sec);
	require(usage.ru_stime.tv_usec == child.stime.tv_nsec / 1000);
	require(usage.ru_maxrss == child.maxrss / 1024);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_wait_zombie_lock_calls);
	mix_signed(digest, fake_wait_zombie_unlock_calls);
	mix(digest, fake_wait_zombie_digest);

	child.parent = &tracer;
	child.ppid_parent = &parent;
	child.nowait = 1;
	child.sibling_detached = 0;
	child.sibling_added = 0;
	child.released = 0;
	main_thread.ptrace = PT_TRACED;
	main_thread.ptrace_detached = 0;
	fake_wait_zombie_reset();
	status = -1;
	ret = fake_wait_process_zombie_call(&current, &parent, &child, &pid1,
		&status, WEXITED, &usage);
	require(ret == child.pid);
	require(fake_wait_zombie_host_calls == 0);
	require(fake_wait_zombie_detach_calls == 0);
	require(fake_wait_zombie_add_tail_calls == 0);
	require(fake_wait_zombie_release_calls == 0);
	require(fake_wait_zombie_ptrace_detach_calls == 1);
	require(main_thread.ptrace_detached == 1);
	require(fake_wait_zombie_parent_unlock_event <
		fake_wait_zombie_ptrace_event);
	mix_signed(digest, ret);
	mix_signed(digest, fake_wait_zombie_host_calls);
	mix_signed(digest, fake_wait_zombie_ptrace_detach_calls);
	mix(digest, fake_wait_zombie_digest);

	child.parent = &parent;
	child.ppid_parent = &parent;
	child.nowait = 1;
	main_thread.ptrace = PT_TRACED;
	main_thread.ptrace_detached = 0;
	child.released = 0;
	fake_wait_zombie_reset();
	status = -1;
	ret = fake_wait_process_zombie_call(&current, &parent, &child, &pid1,
		&status, WEXITED | WNOWAIT, &usage);
	require(ret == child.pid);
	require(fake_wait_zombie_host_calls == 0);
	require(fake_wait_zombie_release_calls == 0);
	require(fake_wait_zombie_ptrace_detach_calls == 0);
	require(status == child.group_exit_status);
	mix_signed(digest, ret);
	mix_signed(digest, fake_wait_zombie_unlock_calls);
	mix(digest, fake_wait_zombie_digest);

	child.parent = &tracer;
	child.ppid_parent = &parent;
	child.nowait = 0;
	main_thread.ptrace = 0;
	fake_wait_zombie_reset();
	fake_wait_zombie_host_rc = -77;
	status = -1;
	ret = fake_wait_process_zombie_call(&current, &parent, &child, &pid1,
		&status, WEXITED, &usage);
	require(ret == -77);
	require(fake_wait_zombie_host_calls == 1);
	require(fake_wait_zombie_log_count == 3);
	mix_signed(digest, ret);
	mix_signed(digest, fake_wait_zombie_log_count);
	mix(digest, fake_wait_zombie_digest);

	ret = wait_process_zombie_body_result(NULL, &parent, &child, &status,
		WEXITED, &usage, &parent.children_lock, &(int){0}, &pid1,
		&fake_wait_zombie_offsets, fake_wait_zombie_host_wait4,
		fake_wait_zombie_lock, fake_wait_zombie_unlock,
		fake_wait_zombie_list_detach, fake_wait_zombie_list_add_tail,
		fake_wait_zombie_ptrace_detach,
		fake_wait_zombie_release_process, fake_wait_zombie_log,
		&(int){0}, &(int){0}, &(int){0}, &(int){0});
	require(ret == -22);
	mix_signed(digest, ret);
}

static void
exercise_wait_scan_bodies(unsigned long *digest)
{
	struct fake_wait_scan_process parent = { .pid = 500, .pgid = 50 };
	struct fake_wait_scan_process pid1 = { .pid = 1, .pgid = 1 };
	struct fake_wait_scan_process skip = {
		.pid = 44,
		.pgid = 44,
		.status = PS_RUNNING,
	};
	struct fake_wait_scan_process child = {
		.pid = 55,
		.pgid = 50,
		.status = PS_ZOMBIE,
		.group_exit_status = 0x4400,
		.ppid_parent = &parent,
		.parent = &parent,
		.stime = { .tv_sec = 1, .tv_nsec = 1000 },
		.utime = { .tv_sec = 2, .tv_nsec = 2000 },
		.maxrss = 4096,
	};
	struct fake_wait_scan_thread current = { .proc = &parent, .tid = 500 };
	struct fake_wait_scan_thread main_thread = { .proc = &child, .tid = 55 };
	struct rusage usage;
	int node1 = 1, node2 = 2, node3 = 3, node4 = 4, node5 = 5;
	int empty;
	int status;
	int ret;

	fake_wait_scan_list_init(&parent.children_list);
	fake_wait_scan_list_init(&parent.ptraced_children_list);
	fake_wait_scan_list_init(&parent.report_threads_list);
	fake_wait_scan_list_init(&parent.threads_list);
	fake_wait_scan_list_init(&skip.siblings_list);
	fake_wait_scan_list_init(&child.siblings_list);
	fake_wait_scan_list_add_tail(&skip.siblings_list, &parent.children_list);
	fake_wait_scan_list_add_tail(&child.siblings_list, &parent.children_list);
	child.main_thread = &main_thread;
	main_thread.ptrace = PT_TRACED;
	fake_wait_scan_reset();
	fake_wait_zombie_host_rc = child.pid;
	empty = 1;
	status = -1;
	memset(&usage, 0, sizeof(usage));
	ret = wait_process_scan_body_result(child.pid, &status, WEXITED,
		&usage, &empty, &current, &parent, &pid1,
		&fake_wait_scan_offsets, &fake_wait_scan_zombie_offsets,
		fake_wait_scan_lock, fake_wait_scan_unlock,
		fake_wait_zombie_host_wait4, fake_wait_scan_list_detach,
		fake_wait_scan_list_add_tail_cb, fake_wait_scan_ptrace_detach,
		fake_wait_scan_release_process, fake_wait_zombie_log,
		fake_wait_scan_stopped, fake_wait_scan_continued,
		fake_wait_signal_flags_reap, &node1, &node2, &node3,
		&node4, &node5);
	require(ret == child.pid);
	require(empty == 0);
	require(status == child.group_exit_status);
	require(child.parent == &pid1);
	require(child.ppid_parent == &pid1);
	require(child.released == 1);
	require(main_thread.ptrace_detached == 1);
	require(fake_wait_scan_detach_calls == 1);
	require(fake_wait_scan_add_tail_calls == 1);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_wait_scan_lock_calls);
	mix_signed(digest, fake_wait_scan_unlock_calls);
	mix(digest, fake_wait_scan_digest);

	child.status = PS_RUNNING;
	child.parent = &parent;
	child.ppid_parent = &parent;
	child.released = 0;
	main_thread.ptrace = 0;
	main_thread.signal_flags = SIGNAL_STOP_STOPPED;
	fake_wait_scan_reset();
	empty = 1;
	status = -1;
	ret = wait_process_scan_body_result(child.pid, &status, WUNTRACED,
		NULL, &empty, &current, &parent, &pid1,
		&fake_wait_scan_offsets, &fake_wait_scan_zombie_offsets,
		fake_wait_scan_lock, fake_wait_scan_unlock,
		fake_wait_zombie_host_wait4, fake_wait_scan_list_detach,
		fake_wait_scan_list_add_tail_cb, fake_wait_scan_ptrace_detach,
		fake_wait_scan_release_process, fake_wait_zombie_log,
		fake_wait_scan_stopped, fake_wait_scan_continued,
		fake_wait_signal_flags_reap, &node1, &node2, &node3,
		&node4, &node5);
	require(ret == main_thread.tid);
	require(empty == 0);
	require(fake_wait_scan_stopped_calls == 1);
	require(fake_wait_scan_unlock_calls == 2);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_scan_digest);

	{
		struct fake_wait_scan_process ptraced = {
			.pid = 77,
			.pgid = 50,
		};

		fake_wait_scan_list_init(&parent.children_list);
		fake_wait_scan_list_init(&parent.ptraced_children_list);
		fake_wait_scan_list_init(&ptraced.ptraced_siblings_list);
		fake_wait_scan_list_add_tail(&ptraced.ptraced_siblings_list,
			&parent.ptraced_children_list);
		fake_wait_scan_reset();
		empty = 1;
		ret = wait_process_scan_body_result(ptraced.pid, &status,
			WEXITED, NULL, &empty, &current, &parent, &pid1,
			&fake_wait_scan_offsets, &fake_wait_scan_zombie_offsets,
			fake_wait_scan_lock, fake_wait_scan_unlock,
			fake_wait_zombie_host_wait4, fake_wait_scan_list_detach,
			fake_wait_scan_list_add_tail_cb,
			fake_wait_scan_ptrace_detach,
			fake_wait_scan_release_process, fake_wait_zombie_log,
			fake_wait_scan_stopped, fake_wait_scan_continued,
			fake_wait_signal_flags_reap, &node1, &node2, &node3,
			&node4, &node5);
		require(ret == 0);
		require(empty == 0);
		require(fake_wait_scan_unlock_calls == 1);
		mix_signed(digest, ret);
		mix_signed(digest, empty);
	}

	ret = wait_process_scan_body_result(child.pid, &status, WEXITED,
		NULL, NULL, &current, &parent, &pid1, &fake_wait_scan_offsets,
		&fake_wait_scan_zombie_offsets, fake_wait_scan_lock,
		fake_wait_scan_unlock, fake_wait_zombie_host_wait4,
		fake_wait_scan_list_detach, fake_wait_scan_list_add_tail_cb,
		fake_wait_scan_ptrace_detach, fake_wait_scan_release_process,
		fake_wait_zombie_log, fake_wait_scan_stopped,
		fake_wait_scan_continued, fake_wait_signal_flags_reap, &node1,
		&node2, &node3, &node4, &node5);
	require(ret == -22);
	mix_signed(digest, ret);

	{
		struct fake_wait_scan_process tproc = {
			.pid = 900,
			.pgid = 90,
		};
		struct fake_wait_scan_thread reporter = {
			.proc = &tproc,
			.tid = 901,
			.status = PS_EXITED,
		};
		struct fake_wait_scan_thread sibling = {
			.proc = &tproc,
			.tid = 902,
			.termsig = 9,
		};

		tproc.main_thread = &current;
		fake_wait_scan_list_init(&tproc.report_threads_list);
		fake_wait_scan_list_init(&tproc.threads_list);
		fake_wait_scan_list_init(&reporter.report_siblings_list);
		fake_wait_scan_list_init(&sibling.siblings_list);
		fake_wait_scan_list_add_tail(&reporter.report_siblings_list,
			&tproc.report_threads_list);
		fake_wait_scan_list_add_tail(&sibling.siblings_list,
			&tproc.threads_list);
		fake_wait_scan_reset();
		empty = 1;
		status = -1;
		ret = wait_thread_scan_body_result(reporter.tid, &status,
			WEXITED, NULL, &empty, &current, &tproc,
			&fake_wait_scan_offsets, fake_wait_scan_lock,
			fake_wait_scan_unlock, fake_wait_scan_stopped,
			fake_wait_scan_continued, fake_wait_signal_flags_reap,
			fake_wait_scan_report_detach,
			fake_wait_scan_ptrace_detach,
			fake_wait_scan_release_thread, &node1);
		require(ret == reporter.tid);
		require(empty == 0);
		require(reporter.report_detached == 1);
		require(reporter.released == 1);
		require(fake_wait_scan_unlock_calls == 1);
		mix_signed(digest, ret);
		mix_signed(digest, reporter.released);

		fake_wait_scan_list_init(&tproc.report_threads_list);
		fake_wait_scan_reset();
		empty = 1;
		ret = wait_thread_scan_body_result(1234, &status, WEXITED,
			NULL, &empty, &current, &tproc,
			&fake_wait_scan_offsets, fake_wait_scan_lock,
			fake_wait_scan_unlock, fake_wait_scan_stopped,
			fake_wait_scan_continued, fake_wait_signal_flags_reap,
			fake_wait_scan_report_detach,
			fake_wait_scan_ptrace_detach,
			fake_wait_scan_release_thread, &node1);
		require(ret == 0);
		require(empty == 0);
		require(fake_wait_scan_unlock_calls == 1);
		mix_signed(digest, ret);
		mix_signed(digest, empty);

		ret = wait_thread_scan_body_result(1234, &status, WEXITED,
			NULL, NULL, &current, &tproc, &fake_wait_scan_offsets,
			fake_wait_scan_lock, fake_wait_scan_unlock,
			fake_wait_scan_stopped, fake_wait_scan_continued,
			fake_wait_signal_flags_reap,
			fake_wait_scan_report_detach,
			fake_wait_scan_ptrace_detach,
			fake_wait_scan_release_thread, &node1);
		require(ret == -22);
		mix_signed(digest, ret);
	}
}

static void
exercise_wait_candidate_bodies(unsigned long *digest)
{
	struct fake_wait_candidate_process proc = { .pid = 55 };
	struct fake_wait_candidate_thread current = { .proc = &proc, .tid = 11 };
	struct fake_wait_candidate_thread child = { .proc = &proc, .tid = 77 };
	int status;
	int found;
	int ret;

	fake_wait_candidate_reset();
	child.signal_flags = SIGNAL_STOP_STOPPED;
	fake_wait_candidate_stopped_rc = proc.pid;
	status = -1;
	ret = fake_wait_process_candidate_call(123, -1, &status, WUNTRACED,
		&current, &proc, &child, &found);
	require(found == 1);
	require(ret == proc.pid);
	require(fake_wait_candidate_stopped_calls == 1);
	require(fake_wait_candidate_continued_calls == 0);
	require(fake_wait_candidate_unlock_calls == 2);
	require(fake_wait_reap_calls == 1);
	require(child.signal_flags == 0);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix_signed(digest, fake_wait_candidate_unlock_calls);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	child.signal_flags = 0;
	child.ptrace = PT_TRACED;
	child.tid = 77;
	proc.status = PS_TRACED;
	fake_wait_candidate_stopped_rc = proc.pid;
	status = -1;
	ret = fake_wait_process_candidate_call(321, child.tid, &status,
		WUNTRACED, &current, &proc, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_stopped_calls == 1);
	require(fake_wait_candidate_unlock_calls == 2);
	require(fake_wait_reap_calls == 1);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	child.signal_flags = SIGNAL_STOP_CONTINUED;
	child.ptrace = PT_TRACED;
	proc.status = PS_TRACED;
	fake_wait_candidate_stopped_rc = 999;
	fake_wait_candidate_continued_rc = proc.pid;
	status = -1;
	ret = fake_wait_process_candidate_call(7, -1, &status, WCONTINUED,
		&current, &proc, &child, &found);
	require(found == 1);
	require(ret == proc.pid);
	require(fake_wait_candidate_stopped_calls == 1);
	require(fake_wait_candidate_continued_calls == 1);
	require(fake_wait_candidate_unlock_calls == 2);
	require(child.signal_flags == 0);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	child.signal_flags = 0;
	child.ptrace = 0;
	proc.status = 0;
	status = -1;
	ret = fake_wait_process_candidate_call(444, -1, &status, WEXITED,
		&current, &proc, &child, &found);
	require(found == 0);
	require(ret == 444);
	require(fake_wait_candidate_unlock_calls == 0);
	mix_signed(digest, ret);
	mix_signed(digest, found);

	fake_wait_candidate_reset();
	child.status = PS_EXITED;
	child.ptrace = 0;
	child.tid = 88;
	status = -1;
	ret = fake_wait_thread_candidate_call(5, child.tid, &status,
		WEXITED | WNOWAIT, &current, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_unlock_calls == 1);
	require(fake_wait_candidate_ptrace_detach_calls == 0);
	require(fake_wait_candidate_release_calls == 0);
	mix_signed(digest, ret);
	mix_signed(digest, fake_wait_candidate_unlock_calls);

	fake_wait_candidate_reset();
	child.status = PS_EXITED;
	child.ptrace = PT_TRACED;
	status = -1;
	ret = fake_wait_thread_candidate_call(5, child.tid, &status,
		WEXITED, &current, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_unlock_calls == 1);
	require(fake_wait_candidate_ptrace_detach_calls == 1);
	require(child.ptrace_detached == 1);
	mix_signed(digest, ret);
	mix_signed(digest, child.ptrace_detached);

	fake_wait_candidate_reset();
	child.status = PS_EXITED;
	child.ptrace = 0;
	child.report_detached = 0;
	child.released = 0;
	status = -1;
	ret = fake_wait_thread_candidate_call(5, child.tid, &status,
		WEXITED, &current, &child, &found);
	require(found == 1);
	require(fake_wait_candidate_report_detach_calls == 1);
	require(fake_wait_candidate_release_calls == 1);
	require(fake_wait_candidate_report_event <
		fake_wait_candidate_unlock_event);
	require(fake_wait_candidate_unlock_event <
		fake_wait_candidate_release_event);
	mix_signed(digest, ret);
	mix_signed(digest, child.report_detached);
	mix_signed(digest, child.released);

	fake_wait_candidate_reset();
	child.status = 0;
	child.ptrace = 0;
	child.signal_flags = SIGNAL_STOP_STOPPED;
	fake_wait_candidate_stopped_rc = child.tid;
	status = -1;
	ret = fake_wait_thread_candidate_call(5, child.tid, &status,
		WUNTRACED, &current, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_stopped_child == &child);
	require(fake_wait_candidate_unlock_calls == 1);
	require(child.signal_flags == 0);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	child.status = PS_TRACED;
	child.ptrace = PT_TRACED;
	child.signal_flags = 0;
	fake_wait_candidate_stopped_rc = child.tid;
	status = -1;
	ret = fake_wait_thread_candidate_call(5, child.tid, &status,
		WUNTRACED, &current, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_unlock_calls == 1);
	require(fake_wait_reap_calls == 1);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	child.status = PS_TRACED;
	child.ptrace = PT_TRACED;
	child.signal_flags = 0;
	fake_wait_candidate_stopped_rc = 444;
	status = -1;
	ret = fake_wait_thread_candidate_call(33, child.tid, &status,
		WUNTRACED, &current, &child, &found);
	require(found == 0);
	require(ret == 444);
	require(fake_wait_candidate_unlock_calls == 0);
	mix_signed(digest, ret);
	mix_signed(digest, found);

	fake_wait_candidate_reset();
	child.status = 0;
	child.ptrace = 0;
	child.signal_flags = SIGNAL_STOP_CONTINUED;
	fake_wait_candidate_continued_rc = child.tid;
	status = -1;
	ret = fake_wait_thread_candidate_call(33, child.tid, &status,
		WCONTINUED, &current, &child, &found);
	require(found == 1);
	require(ret == child.tid);
	require(fake_wait_candidate_continued_calls == 1);
	require(fake_wait_candidate_unlock_calls == 1);
	require(child.signal_flags == 0);
	mix_signed(digest, ret);
	mix_signed(digest, status);
	mix(digest, fake_wait_candidate_digest);

	fake_wait_candidate_reset();
	ret = wait_thread_candidate_body_result(66, child.tid, &status,
		WEXITED, &current, &child, NULL, NULL,
		offsetof(struct fake_wait_candidate_thread, proc),
		offsetof(struct fake_wait_candidate_thread, tid),
		offsetof(struct fake_wait_candidate_thread, status),
		offsetof(struct fake_wait_candidate_thread, ptrace),
		offsetof(struct fake_wait_candidate_thread, signal_flags),
		NULL, fake_wait_candidate_continued,
		fake_wait_signal_flags_reap, fake_wait_candidate_unlock,
		fake_wait_candidate_report_detach,
		fake_wait_candidate_ptrace_detach,
		fake_wait_candidate_release, &found);
	require(ret == -22);
	mix_signed(digest, ret);
}

static void exercise_wait_policy(unsigned long *digest)
{
	static const int pids[] = { -55, -2, -1, 0, 1, 2, 55 };
	static const int pgids[] = { 1, 2, 55 };
	static const int statuses[] = {
		0, PS_RUNNING, PS_ZOMBIE, PS_EXITED, PS_STOPPED, PS_TRACED,
		PS_DELAY_STOPPED, PS_DELAY_TRACED, PS_STOPPED | PS_TRACED,
		PS_TRACED | PS_DELAY_TRACED,
	};
	static const int signal_flags[] = {
		0, SIGNAL_STOP_STOPPED, SIGNAL_STOP_CONTINUED,
		SIGNAL_STOP_STOPPED | SIGNAL_STOP_CONTINUED,
	};
	static const int ptrace_values[] = { 0, PT_TRACED, PT_TRACE_EXEC,
		PT_TRACED | PT_TRACE_EXEC };
	static const int option_values[] = {
		0, WNOHANG, WUNTRACED, WEXITED, WCONTINUED, WNOWAIT,
		WEXITED | WNOHANG, WEXITED | WNOWAIT,
		WUNTRACED | WCONTINUED, WEXITED | WUNTRACED | WCONTINUED,
		__WCLONE, __WALL, WEXITED | __WCLONE,
		WEXITED | __WALL | WNOWAIT, WEXITED | WUNTRACED |
		WCONTINUED | WNOHANG | WNOWAIT | __WCLONE | __WALL,
		0x10, -1,
	};
	static const int idtypes[] = { P_ALL, P_PID, P_PGID, 3, -1 };
	static const int bools[] = { 0, 1 };
	static const int termsigs[] = { 0, SIGCHLD, 9, 15 };
	static const int wait_statuses[] = {
		0, 1, 9, 0x7f, 0x137f, 0xffff, 0x0100, 0x8b,
	};
	static const int exit_statuses[] = { 0, 1, 9, 0x13, 0xff, 0x137f };
	static const int wait_results[] = { -10, -1, 0, 1, 55 };

	for (unsigned int o = 0; o < sizeof(option_values) / sizeof(option_values[0]); o++) {
		mix_signed(digest, wait4_options_result(option_values[o]));
		mix_signed(digest, waitid_options_result(option_values[o]));
		mix_signed(digest, wait_should_scan_process_result(option_values[o]));
		mix_signed(digest, wait_reap_needed_result(option_values[o]));
		mix_signed(digest, wait_nohang_result(option_values[o]));
		for (unsigned int b = 0; b < sizeof(bools) / sizeof(bools[0]); b++) {
			mix_signed(digest, wait_process_reparent_needed_result(
				option_values[o], bools[b]));
			mix_signed(digest, wait_rusage_copy_needed_result(bools[b]));
			for (unsigned int rc = 0; rc < sizeof(wait_results) / sizeof(wait_results[0]); rc++) {
				mix_signed(digest, wait_status_copy_needed_result(
					wait_results[rc], bools[b]));
				mix_signed(digest, waitid_siginfo_needed_result(
					wait_results[rc], bools[b]));
			}
		}
		for (unsigned int p = 0; p < sizeof(pids) / sizeof(pids[0]); p++)
			mix_signed(digest, wait_should_scan_thread_result(pids[p],
				option_values[o]));
		for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++) {
			mix_signed(digest, wait_process_exited_candidate_result(
				option_values[o], statuses[s]));
			mix_signed(digest, wait_thread_exited_candidate_result(
				option_values[o], statuses[s]));
			for (unsigned int pt = 0; pt < sizeof(ptrace_values) / sizeof(ptrace_values[0]); pt++)
				mix_signed(digest, wait_ptraced_stop_candidate_result(
					ptrace_values[pt], statuses[s]));
		}
		for (unsigned int fl = 0; fl < sizeof(signal_flags) / sizeof(signal_flags[0]); fl++) {
			mix_signed(digest, wait_continued_candidate_result(
				signal_flags[fl], option_values[o]));
			mix_signed(digest, wait_reaped_signal_flags_result(
				option_values[o], signal_flags[fl],
				SIGNAL_STOP_STOPPED));
			mix_signed(digest, wait_reaped_signal_flags_result(
				option_values[o], signal_flags[fl],
				SIGNAL_STOP_CONTINUED));
			for (unsigned int pt = 0; pt < sizeof(ptrace_values) / sizeof(ptrace_values[0]); pt++)
				mix_signed(digest, wait_nonptraced_stop_candidate_result(
					ptrace_values[pt], signal_flags[fl],
					option_values[o]));
		}
		for (unsigned int pt = 0; pt < sizeof(ptrace_values) / sizeof(ptrace_values[0]); pt++) {
			mix_signed(digest, wait_main_thread_ptrace_detach_needed_result(
				option_values[o], ptrace_values[pt]));
			mix_signed(digest, wait_thread_reap_action_result(
				option_values[o], ptrace_values[pt]));
		}
		for (unsigned int e = 0; e < sizeof(exit_statuses) / sizeof(exit_statuses[0]); e++)
			mix_signed(digest, wait_reaped_exit_status_result(
				option_values[o], exit_statuses[e]));
	}

	for (unsigned int has = 0; has < sizeof(bools) / sizeof(bools[0]); has++) {
		for (unsigned int s = 0; s < sizeof(statuses) / sizeof(statuses[0]); s++) {
			for (unsigned int ce = 0; ce < sizeof(exit_statuses) / sizeof(exit_statuses[0]); ce++) {
				for (unsigned int ge = 0; ge < sizeof(exit_statuses) / sizeof(exit_statuses[0]); ge++) {
					for (unsigned int me = 0; me < sizeof(exit_statuses) / sizeof(exit_statuses[0]); me++) {
						int source = wait_stopped_source_result(
							bools[has], exit_statuses[ce],
							statuses[s], exit_statuses[ge],
							exit_statuses[me]);

						mix_signed(digest, source);
						mix_signed(digest, wait_stopped_exit_status_result(
							source, exit_statuses[ce],
							exit_statuses[ge],
							exit_statuses[me]));
						mix_signed(digest, wait_report_id_result(
							source, 55, 77));
					}
				}
			}
		}
	}

	for (unsigned int idt = 0; idt < sizeof(idtypes) / sizeof(idtypes[0]); idt++) {
		for (unsigned int id = 0; id < sizeof(pids) / sizeof(pids[0]); id++) {
			int pid = 0x12345678;

			mix_signed(digest, waitid_to_wait_pid_result(idtypes[idt],
				pids[id], &pid));
			mix_signed(digest, pid);
		}
	}

	for (unsigned int p = 0; p < sizeof(pids) / sizeof(pids[0]); p++) {
		for (unsigned int pg = 0; pg < sizeof(pgids) / sizeof(pgids[0]); pg++) {
			for (unsigned int cg = 0; cg < sizeof(pgids) / sizeof(pgids[0]); cg++) {
				for (unsigned int cp = 0; cp < sizeof(pids) / sizeof(pids[0]); cp++)
					mix_signed(digest, wait_process_pid_matches_result(
						pids[p], pgids[pg], pgids[cg],
						pids[cp]));
			}
		}
	}

	for (unsigned int tid = 0; tid < sizeof(pids) / sizeof(pids[0]); tid++) {
		for (unsigned int child = 0; child < sizeof(pids) / sizeof(pids[0]); child++) {
			for (unsigned int main = 0; main < sizeof(bools) / sizeof(bools[0]); main++)
				mix_signed(digest, wait_thread_tid_matches_result(
					pids[tid], pids[child], bools[main]));
		}
	}

	for (unsigned int e = 0; e < sizeof(bools) / sizeof(bools[0]); e++)
		mix_signed(digest, wait_empty_result(bools[e]));

	for (unsigned int s = 0; s < sizeof(wait_statuses) / sizeof(wait_statuses[0]); s++) {
		mix_signed(digest, wait_stopped_status_result(wait_statuses[s]));
		mix_signed(digest, waitid_status_code_result(wait_statuses[s]));
	}
	mix_signed(digest, wait_continued_status_result());
	exercise_do_wait_body(digest);
	exercise_wait_candidate_bodies(digest);
	exercise_wait_zombie_body(digest);
	exercise_wait_scan_bodies(digest);

	{
		struct fake_wait_thread main_thread = {
			.tid = 100,
			.signal_flags = SIGNAL_STOP_CONTINUED | SIGNAL_STOP_STOPPED,
		};
		struct fake_wait_thread report_thread = {
			.tid = 200,
			.signal_flags = SIGNAL_STOP_CONTINUED | SIGNAL_STOP_STOPPED,
		};
		struct fake_wait_process child = {
			.pid = 55,
			.main_thread = &main_thread,
		};
		int status = -1;
		int ret;

		fake_wait_reap_calls = 0;
		fake_wait_reap_thread = NULL;
		ret = wait_continued_body_result(NULL, &child, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, signal_flags),
			fake_wait_signal_flags_reap);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, main_thread.signal_flags);
		mix_signed(digest, report_thread.signal_flags);
		mix_signed(digest, fake_wait_reap_calls);
		mix_signed(digest, fake_wait_reap_thread == &main_thread);
		mix_signed(digest, fake_wait_reap_options);
		mix_signed(digest, fake_wait_reap_clear_mask);

		status = -1;
		fake_wait_reap_calls = 0;
		fake_wait_reap_thread = NULL;
		ret = wait_continued_body_result(&report_thread, &child, &status,
			WNOWAIT, offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, signal_flags),
			fake_wait_signal_flags_reap);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, main_thread.signal_flags);
		mix_signed(digest, report_thread.signal_flags);
		mix_signed(digest, fake_wait_reap_calls);
		mix_signed(digest, fake_wait_reap_thread == &report_thread);
		mix_signed(digest, fake_wait_reap_options);
		mix_signed(digest, fake_wait_reap_clear_mask);

		fake_wait_reap_calls = 0;
		ret = wait_continued_body_result(&report_thread, &child, NULL,
			0, offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, signal_flags),
			fake_wait_signal_flags_reap);
		mix_signed(digest, ret);
		mix_signed(digest, fake_wait_reap_calls);

		main_thread.exit_status = 0;
		report_thread.exit_status = 0x44;
		child.status = PS_STOPPED;
		child.group_exit_status = 0x55;
		status = -1;
		fake_wait_reap_calls = 0;
		fake_wait_reap_thread = NULL;
		ret = wait_stopped_body_result(&report_thread, &child, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			fake_wait_exit_status_reap);
		require(ret == report_thread.tid);
		require(status == ((0x44 << 8) | 0x7f));
		require(fake_wait_reap_calls == 1);
		require(fake_wait_reap_thread == &report_thread);
		require(fake_wait_reap_options == 0);
		require(fake_wait_reap_clear_mask == 0);
		require(report_thread.exit_status == 0);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, fake_wait_reap_calls);
		mix_signed(digest, fake_wait_reap_thread == &report_thread);
		mix_signed(digest, report_thread.exit_status);

		report_thread.exit_status = 0;
		child.status = PS_DELAY_STOPPED;
		child.group_exit_status = 0x56;
		status = -1;
		fake_wait_reap_calls = 0;
		fake_wait_reap_thread = NULL;
		ret = wait_stopped_body_result(NULL, &child, &status, WNOWAIT,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			fake_wait_exit_status_reap);
		require(ret == child.pid);
		require(status == ((0x56 << 8) | 0x7f));
		require(fake_wait_reap_calls == 1);
		require(fake_wait_reap_thread == &child);
		require(fake_wait_reap_options == WNOWAIT);
		require(child.group_exit_status == 0x56);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, fake_wait_reap_thread == &child);
		mix_signed(digest, fake_wait_reap_options);
		mix_signed(digest, child.group_exit_status);

		child.status = PS_RUNNING;
		child.group_exit_status = 0;
		main_thread.exit_status = 0x57;
		status = -1;
		fake_wait_reap_calls = 0;
		fake_wait_reap_thread = NULL;
		ret = wait_stopped_body_result(NULL, &child, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			fake_wait_exit_status_reap);
		require(ret == child.pid);
		require(status == ((0x57 << 8) | 0x7f));
		require(fake_wait_reap_calls == 1);
		require(fake_wait_reap_thread == &main_thread);
		require(main_thread.exit_status == 0);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, fake_wait_reap_thread == &main_thread);
		mix_signed(digest, main_thread.exit_status);

		main_thread.exit_status = 0;
		status = -1;
		fake_wait_reap_calls = 0;
		ret = wait_stopped_body_result(NULL, &child, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			fake_wait_exit_status_reap);
		require(ret == 0);
		require(status == -1);
		require(fake_wait_reap_calls == 0);
		mix_signed(digest, ret);
		mix_signed(digest, status);
		mix_signed(digest, fake_wait_reap_calls);

		status = -1;
		ret = wait_stopped_body_result(NULL, NULL, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			fake_wait_exit_status_reap);
		require(ret == -22);
		require(status == -1);
		mix_signed(digest, ret);

		child.status = PS_STOPPED;
		child.group_exit_status = 0x58;
		status = -1;
		ret = wait_stopped_body_result(NULL, &child, &status, 0,
			offsetof(struct fake_wait_process, pid),
			offsetof(struct fake_wait_process, status),
			offsetof(struct fake_wait_process, group_exit_status),
			offsetof(struct fake_wait_process, main_thread),
			offsetof(struct fake_wait_thread, tid),
			offsetof(struct fake_wait_thread, exit_status),
			NULL);
		require(ret == -22);
		require(status == ((0x58 << 8) | 0x7f));
		mix_signed(digest, ret);
		mix_signed(digest, status);
	}

	{
		int status_out = -1;
		struct rusage usage_out;
		long rc;

		memset(&usage_out, 0xa5, sizeof(usage_out));
		memset(&fake_wait4_seen_usage, 0, sizeof(fake_wait4_seen_usage));
		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		fake_wait4_rc = 77;
		fake_wait4_status = 0x1234;
		rc = wait4_body_result(123,
			(unsigned long)(uintptr_t)&status_out,
			WNOHANG, (unsigned long)(uintptr_t)&usage_out,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		mix_signed(digest, fake_wait4_copy_to_calls);
		mix_signed(digest, fake_wait4_pid);
		mix_signed(digest, fake_wait4_options);
		mix_signed(digest, status_out);
		mix_signed(digest, fake_wait4_seen_usage.ru_utime.tv_sec);
		mix_signed(digest, fake_wait4_seen_usage.ru_maxrss);
		mix_signed(digest, usage_out.ru_utime.tv_sec);
		mix_signed(digest, usage_out.ru_utime.tv_usec);
		mix_signed(digest, usage_out.ru_stime.tv_sec);
		mix_signed(digest, usage_out.ru_stime.tv_usec);
		mix_signed(digest, usage_out.ru_maxrss);
		mix_signed(digest, usage_out.ru_nvcsw);

		status_out = -1;
		memset(&usage_out, 0x5a, sizeof(usage_out));
		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		fake_wait4_rc = -10;
		fake_wait4_status = 0x5678;
		rc = wait4_body_result(321,
			(unsigned long)(uintptr_t)&status_out,
			WNOWAIT, (unsigned long)(uintptr_t)&usage_out,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		mix_signed(digest, fake_wait4_copy_to_calls);
		mix_signed(digest, status_out);
		mix_signed(digest, usage_out.ru_maxrss);

		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		rc = wait4_body_result(1, 0, -1, 0,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		mix_signed(digest, fake_wait4_copy_to_calls);
	}

	{
		struct fake_siginfo info;
		long rc;

		memset(&info, 0xa5, sizeof(info));
		fake_waitid_copy_to_calls = 0;
		fake_waitid_copy_to_bytes = 0;
		waitid_copy_siginfo_result(55, (unsigned long)(uintptr_t)&info,
			0x137f, 12, 34567, 2, 990000,
			fake_waitid_copy_to_user);
		mix_signed(digest, fake_waitid_copy_to_calls);
		mix_signed(digest, (long)fake_waitid_copy_to_bytes);
		mix_signed(digest, info.si_signo);
		mix_signed(digest, info.si_errno);
		mix_signed(digest, info.si_code);
		mix_signed(digest, info.sifields.sigchld.si_pid);
		mix_signed(digest, info.sifields.sigchld.si_uid);
		mix_signed(digest, info.sifields.sigchld.si_status);
		mix_signed(digest, info.sifields.sigchld.si_utime);
		mix_signed(digest, info.sifields.sigchld.si_stime);

		memset(&info, 0x5a, sizeof(info));
		fake_waitid_copy_to_calls = 0;
		waitid_copy_siginfo_result(0, (unsigned long)(uintptr_t)&info,
			0, 1, 0, 1, 0, fake_waitid_copy_to_user);
		waitid_copy_siginfo_result(55, 0, 0, 1, 0, 1, 0,
			fake_waitid_copy_to_user);
		mix_signed(digest, fake_waitid_copy_to_calls);
		mix_signed(digest, ((unsigned char *)&info)[0]);

		memset(&info, 0xa5, sizeof(info));
		memset(&fake_wait4_seen_usage, 0, sizeof(fake_wait4_seen_usage));
		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		fake_wait4_rc = 55;
		fake_wait4_status = 0x137f;
		rc = waitid_body_result(P_PID, 44,
			(unsigned long)(uintptr_t)&info, WEXITED | WNOHANG,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		mix_signed(digest, fake_wait4_copy_to_calls);
		mix_signed(digest, fake_wait4_pid);
		mix_signed(digest, fake_wait4_options);
		mix_signed(digest, fake_wait4_seen_usage.ru_utime.tv_sec);
		mix_signed(digest, info.si_signo);
		mix_signed(digest, info.si_code);
		mix_signed(digest, info.sifields.sigchld.si_pid);
		mix_signed(digest, info.sifields.sigchld.si_status);
		mix_signed(digest, info.sifields.sigchld.si_utime);
		mix_signed(digest, info.sifields.sigchld.si_stime);

		memset(&info, 0x5a, sizeof(info));
		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		fake_wait4_rc = -10;
		fake_wait4_status = 0x1234;
		rc = waitid_body_result(P_PGID, 7,
			(unsigned long)(uintptr_t)&info, WEXITED | WNOWAIT,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		mix_signed(digest, fake_wait4_copy_to_calls);
		mix_signed(digest, fake_wait4_pid);
		mix_signed(digest, fake_wait4_options);
		mix_signed(digest, ((unsigned char *)&info)[0]);

		fake_wait4_do_wait_calls = 0;
		fake_wait4_copy_to_calls = 0;
		rc = waitid_body_result(99, 1, 0, WEXITED,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
		rc = waitid_body_result(P_ALL, 0, 0, 0,
			fake_wait4_do_wait, fake_wait4_copy_to_user);
		mix_signed(digest, rc);
		mix_signed(digest, fake_wait4_do_wait_calls);
	}

	for (unsigned int ppid = 0; ppid < sizeof(pids) / sizeof(pids[0]); ppid++) {
		for (unsigned int cur = 0; cur < sizeof(pids) / sizeof(pids[0]); cur++) {
			for (unsigned int nw = 0; nw < sizeof(bools) / sizeof(bools[0]); nw++)
				mix_signed(digest, wait_zombie_skip_host_result(
					pids[ppid], pids[cur], bools[nw]));
		}
	}

	for (unsigned int main = 0; main < sizeof(bools) / sizeof(bools[0]); main++) {
		for (unsigned int sig = 0; sig < sizeof(termsigs) / sizeof(termsigs[0]); sig++)
			mix_signed(digest, wait_thread_empty_candidate_result(
				bools[main], termsigs[sig]));
	}
}

static void exercise_clone_exec_futex_policy(unsigned long *digest)
{
	static const int clone_flags[] = {
		0, SIGCHLD, CLONE_VM, CLONE_THREAD,
		CLONE_VM | CLONE_THREAD | CLONE_SIGHAND,
		CLONE_VM | CLONE_THREAD | CLONE_SIGHAND | SIGCHLD,
		CLONE_VM | CLONE_THREAD | CLONE_SIGHAND | 65,
		CLONE_SIGHAND, CLONE_THREAD | CLONE_SIGHAND,
		CLONE_FS | CLONE_NEWNS, CLONE_NEWIPC | CLONE_SYSVSEM,
		CLONE_VM | CLONE_THREAD | CLONE_SIGHAND | CLONE_NEWPID,
		CLONE_PARENT | SIGCHLD, CLONE_VFORK | SIGCHLD,
		CLONE_VFORK | 9, CLONE_SETTLS,
		CLONE_PARENT_SETTID, CLONE_CHILD_CLEARTID,
		CLONE_CHILD_SETTID,
		CLONE_VM | CLONE_THREAD | CLONE_SIGHAND | CLONE_SETTLS |
			CLONE_PARENT_SETTID | CLONE_CHILD_CLEARTID |
			CLONE_CHILD_SETTID | SIGCHLD,
	};
	static const unsigned long stack_values[] = {
		0, 1, 0x10000UL, 0x7fffffffffffUL,
	};
	static const int ptrace_values[] = {
		0, PT_TRACED, PT_TRACE_EXEC, PT_TRACE_SYSCALL,
		PTRACE_O_TRACESYSGOOD, PTRACE_O_TRACEFORK,
		PTRACE_O_TRACEVFORK, PTRACE_O_TRACEVFORKDONE,
		PTRACE_O_TRACECLONE, PTRACE_O_TRACEEXEC,
		PT_TRACE_SYSCALL | PTRACE_O_TRACESYSGOOD,
		PTRACE_O_TRACEVFORK | PTRACE_O_TRACEVFORKDONE,
		PTRACE_O_TRACEFORK | PTRACE_O_TRACECLONE,
	};
	static const int events[] = {
		0, PTRACE_EVENT_FORK, PTRACE_EVENT_VFORK,
		PTRACE_EVENT_CLONE, PTRACE_EVENT_EXEC,
		PTRACE_EVENT_VFORK_DONE,
	};
	static const int exec_flags[] = {
		0, AT_SYMLINK_NOFOLLOW, AT_EMPTY_PATH,
		AT_SYMLINK_NOFOLLOW | AT_EMPTY_PATH, 0x200, -1,
	};
	static const int dirfds[] = {
		AT_FDCWD, -200, -1, 0, 3,
	};
	static const int first_chars[] = {
		0, '/', '.', 'a',
	};
	static const int futex_flags[] = {
		FUTEX_WAIT, FUTEX_WAIT_BITSET, FUTEX_CMP_REQUEUE,
		FUTEX_WAKE_OP, FUTEX_WAIT | FUTEX_PRIVATE_FLAG,
		FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME,
		FUTEX_WAKE_OP | FUTEX_PRIVATE_FLAG | FUTEX_CLOCK_REALTIME,
		-1,
	};
	static const unsigned long arg3_values[] = {
		0, 1, 0xffffffffUL, 0x100000001UL,
	};
	static const long time_values[][4] = {
		{ 0, 0, 0, 0 },
		{ 1, 2, 0, 1 },
		{ 10, 500, 2, 250 },
		{ 2, 0, 10, 0 },
	};
	static const int bools[] = { 0, 1 };
	static const int ptrace_data_values[] = { 0, 1, 9, 64 };
	static const int process_statuses[] = {
		0, PS_RUNNING, PS_EXITED, PS_ZOMBIE, PS_STOPPED,
	};
	static const int mod_clone_values[] = {
		SPAWN_TO_LOCAL, SPAWN_TO_REMOTE, SPAWNING_TO_REMOTE, 7,
	};

	{
		struct timespec rel = { .tv_sec = 2, .tv_nsec = 500 };
		struct timespec abs = { .tv_sec = 50, .tv_nsec = 900 };
		long rc;

		fake_do_futex_reset();
		rc = do_futex_body_result(202, 0x1000, FUTEX_WAKE,
			0x11, 0, 0x2000, 0x33, 0, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix(digest, fake_do_futex_digest);
		mix_signed(digest, fake_do_futex_dispatch_calls);
		mix_signed(digest, fake_do_futex_log_calls);
		mix_signed(digest, fake_do_futex_ns_per_tsc_calls);

		fake_do_futex_reset();
		rc = do_futex_body_result(203, 0x1100,
			FUTEX_WAIT | FUTEX_PRIVATE_FLAG, 0x22,
			(unsigned long)(uintptr_t)&rel, 0x2100, 0x44, 0, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix(digest, fake_do_futex_digest);
		mix_signed(digest, fake_do_futex_dispatch_calls);
		mix_signed(digest, fake_do_futex_log_calls);
		mix_signed(digest, fake_do_futex_ns_per_tsc_calls);

		fake_do_futex_reset();
		rc = do_futex_body_result(204, 0x1200,
			FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME, 0x23,
			(unsigned long)(uintptr_t)&abs, 0x2200, 0x55, 0, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix(digest, fake_do_futex_digest);
		mix_signed(digest, fake_do_futex_local_time_calls);
		mix_signed(digest, fake_do_futex_syscall_time_calls);
		mix_signed(digest, fake_do_futex_ns_per_tsc_calls);

		fake_do_futex_reset();
		rc = do_futex_body_result(205, 0x1300,
			FUTEX_WAIT_BITSET, 0x24,
			(unsigned long)(uintptr_t)&abs, 0x2300, 0x66, 0, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix(digest, fake_do_futex_digest);
		mix_signed(digest, fake_do_futex_syscall_time_calls);
		mix_signed(digest, fake_do_futex_syscall_nr);
		mix_signed(digest, fake_do_futex_syscall_clock);

		fake_do_futex_reset();
		rc = do_futex_body_result(206, 0x1400,
			FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME, 0x25,
			(unsigned long)(uintptr_t)&abs, 0x2400, 0x77, 1, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix(digest, fake_do_futex_digest);
		mix_signed(digest, fake_do_futex_linux_time_calls);
		mix_signed(digest, fake_do_futex_linux_clock);

		fake_do_futex_reset();
		fake_do_futex_syscall_fail = 1;
		rc = do_futex_body_result(207, 0x1500, FUTEX_WAIT_BITSET,
			0x26, (unsigned long)(uintptr_t)&abs, 0x2500,
			0x88, 0, 0, fake_do_futex_syscall_time,
			fake_do_futex_local_time, fake_do_futex_linux_time,
			fake_do_futex_ns_per_tsc, fake_do_futex_dispatch,
			fake_do_futex_log);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_futex_dispatch_calls);

		fake_do_futex_reset();
		fake_do_futex_linux_fail = 1;
		rc = do_futex_body_result(208, 0x1600,
			FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME, 0x27,
			(unsigned long)(uintptr_t)&abs, 0x2600, 0x99, 1, 1,
			fake_do_futex_syscall_time, fake_do_futex_local_time,
			fake_do_futex_linux_time, fake_do_futex_ns_per_tsc,
			fake_do_futex_dispatch, fake_do_futex_log);
		mix_signed(digest, rc);
		mix_signed(digest, fake_do_futex_dispatch_calls);
	}

	for (unsigned int f = 0; f < sizeof(clone_flags) / sizeof(clone_flags[0]); f++) {
		for (unsigned int c = 0; c < sizeof(bools) / sizeof(bools[0]); c++)
			mix_signed(digest, clone_flags_result(clone_flags[f],
				bools[c]));
		for (unsigned int s = 0; s < sizeof(stack_values) / sizeof(stack_values[0]); s++) {
			for (unsigned int p = 0; p < sizeof(stack_values) / sizeof(stack_values[0]); p++)
				mix_signed(digest, clone_pthread_marker_result(
					clone_flags[f], stack_values[s],
					stack_values[p]));
		}
		for (unsigned int p = 0; p < sizeof(dirfds) / sizeof(dirfds[0]); p++)
			mix_signed(digest, clone_host_parent_flags_result(
				clone_flags[f], dirfds[p]));
		for (unsigned int b = 0; b < sizeof(bools) / sizeof(bools[0]); b++)
			mix_signed(digest, clone_report_thread_result(
				clone_flags[f], bools[b] ? SIGCHLD : 9));
		mix_signed(digest, clone_parent_tid_store_needed_result(
			clone_flags[f]));
		mix_signed(digest, clone_child_cleartid_needed_result(
			clone_flags[f]));
		mix_signed(digest, clone_child_tid_store_needed_result(
			clone_flags[f]));
		mix_signed(digest, clone_tls_source_result(clone_flags[f]));
	}

	for (unsigned int m = 0; m < sizeof(mod_clone_values) / sizeof(mod_clone_values[0]); m++) {
		mix_signed(digest, clone_remote_spawn_result(
			mod_clone_values[m]));
		for (unsigned int b = 0; b < sizeof(bools) / sizeof(bools[0]); b++)
			mix_signed(digest, clone_use_last_cpu_result(
				mod_clone_values[m], bools[b]));
	}

	for (unsigned int s = 0; s < sizeof(process_statuses) / sizeof(process_statuses[0]); s++)
		mix_signed(digest, clone_parent_use_pid1_result(
			process_statuses[s]));
	for (unsigned int s = 0; s < sizeof(process_statuses) / sizeof(process_statuses[0]); s++)
		mix_signed(digest, ptrace_detach_exit_signal_needed_result(
			process_statuses[s]));
	for (unsigned int d = 0; d < sizeof(ptrace_data_values) / sizeof(ptrace_data_values[0]); d++)
		mix_signed(digest, ptrace_detach_forward_signal_needed_result(
			ptrace_data_values[d]));

	for (unsigned int p = 0; p < sizeof(ptrace_values) / sizeof(ptrace_values[0]); p++) {
		mix_signed(digest, ptrace_exec_event_signal_result(
			ptrace_values[p]));
		mix_signed(digest, ptrace_syscall_event_signal_result(
			ptrace_values[p]));
		for (unsigned int f = 0; f < sizeof(clone_flags) / sizeof(clone_flags[0]); f++)
			mix_signed(digest, ptrace_clone_event_result(
				ptrace_values[p], clone_flags[f]));
	}

	for (unsigned int e = 0; e < sizeof(events) / sizeof(events[0]); e++)
		mix_signed(digest, ptrace_clone_reparent_result(events[e]));

	for (unsigned int f = 0; f < sizeof(exec_flags) / sizeof(exec_flags[0]); f++) {
		for (unsigned int d = 0; d < sizeof(dirfds) / sizeof(dirfds[0]); d++) {
			for (unsigned int c = 0; c < sizeof(first_chars) / sizeof(first_chars[0]); c++)
				mix_signed(digest, execveat_policy_result(
					exec_flags[f], dirfds[d], first_chars[c]));
		}
	}

	{
		char ctx_byte;
		char filename[] = "/bin/true";
		void *argv[] = { filename, NULL };
		void *envp[] = { NULL };
		long rc;

		fake_execveat_calls = 0;
		fake_execveat_rc = -7;
		rc = execve_body_result(&ctx_byte, filename, argv, envp,
			fake_execveat);
		require(rc == -7);
		require(fake_execveat_calls == 1);
		require(fake_execveat_ctx == &ctx_byte);
		require(fake_execveat_dirfd == AT_FDCWD);
		require(fake_execveat_filename == filename);
		require(fake_execveat_argv == argv);
		require(fake_execveat_envp == envp);
		require(fake_execveat_flags == 0);
		mix_signed(digest, rc);
		mix_signed(digest, fake_execveat_calls);

		fake_execveat_calls = 0;
		fake_execveat_rc = 12;
		rc = execveat_body_result(&ctx_byte, AT_FDCWD, filename,
			argv, envp, AT_SYMLINK_NOFOLLOW, filename[0],
			fake_execveat);
		require(rc == 12);
		require(fake_execveat_calls == 1);
		require(fake_execveat_flags == AT_SYMLINK_NOFOLLOW);
		mix_signed(digest, rc);
		mix_signed(digest, fake_execveat_calls);

		fake_execveat_calls = 0;
		rc = execveat_body_result(&ctx_byte, -2, filename, argv,
			envp, 0, 'r', fake_execveat);
		require(rc == -9);
		require(fake_execveat_calls == 0);
		mix_signed(digest, rc);

		rc = execveat_body_result(&ctx_byte, AT_FDCWD, filename,
			argv, envp, 0x4000, filename[0], fake_execveat);
		require(rc == -22);
		mix_signed(digest, rc);

		rc = execve_body_result(&ctx_byte, filename, argv, envp, NULL);
		require(rc == -14);
		mix_signed(digest, rc);
	}

	for (unsigned int f = 0; f < sizeof(futex_flags) / sizeof(futex_flags[0]); f++) {
		int op = 0x12345678;
		int fshared = 0x12345678;

		mix_signed(digest, futex_decode_flags_result(futex_flags[f],
			&op, &fshared));
		mix_signed(digest, op);
		mix_signed(digest, fshared);
		mix_signed(digest, futex_clock_id_result(futex_flags[f]));
		mix_signed(digest, futex_wait_timeout_needed_result(op, 0));
		mix_signed(digest, futex_wait_timeout_needed_result(op, 1));
		mix_signed(digest, futex_timeout_is_absolute_result(op));
		for (unsigned int a = 0; a < sizeof(arg3_values) / sizeof(arg3_values[0]); a++)
			mix(digest, futex_requeue_val2_result(op, arg3_values[a]));
		for (unsigned int t = 0; t < sizeof(time_values) / sizeof(time_values[0]); t++)
			mix(digest, futex_timeout_ns_result(op, time_values[t][0],
				time_values[t][1], time_values[t][2],
				time_values[t][3]));
	}
}

int main(void)
{
	static const size_t robust_lens[] = { 0, 1, 23, 24, 25, 64 };
	static const int tids[] = { INT_MIN, -2, -1, 0, 1, 12345 };
	static const int sigs[] = { -1, 0, 1, 9, 19, 64, 65 };
	static const int pids[] = { -1, 0, 1, 55 };
	static const int currents[] = { 1, 100 };
	static const int execed[] = { -1, 0, 1, 2 };
	static const long syscall_rcs[] = { -4095, -1, 0, 1, 255 };
	static const int syscall_numbers[] = { 0, 1, 203, 204, 9999 };
	static const int rtids[] = { -2, -1, 0, 1, 77 };
	static const unsigned long flags[] = {
		0, VR_RESERVED, VR_IO_NOCACHE, VR_REMOTE,
		VR_RESERVED | VR_REMOTE, 0x4000,
	};
	unsigned long digest = 0x6d63537973506f6cUL;

	for (unsigned int i = 0; i < sizeof(robust_lens) / sizeof(robust_lens[0]); i++)
		mix_signed(&digest, robust_list_len_result(robust_lens[i]));

	for (unsigned int i = 0; i < sizeof(tids) / sizeof(tids[0]); i++)
		mix_signed(&digest, tkill_tid_result(tids[i]));

	for (unsigned int i = 0; i < sizeof(sigs) / sizeof(sigs[0]); i++) {
		mix_signed(&digest, sigaction_validate(sigs[i], 0));
		mix_signed(&digest, sigaction_validate(sigs[i], 1));
	}

	for (unsigned int c = 0; c < sizeof(currents) / sizeof(currents[0]); c++) {
		for (unsigned int p = 0; p < sizeof(pids) / sizeof(pids[0]); p++) {
			int pid = setpgid_normalize_pid(currents[c], pids[p]);

			mix_signed(&digest, pid);
			for (unsigned int g = 0; g < sizeof(pids) / sizeof(pids[0]); g++)
				mix_signed(&digest, setpgid_normalize_pgid(pid, pids[g]));
		}
	}

	for (unsigned int i = 0; i < sizeof(execed) / sizeof(execed[0]); i++)
		mix_signed(&digest, setpgid_execed_result(execed[i]));

	for (unsigned int i = 0; i < sizeof(syscall_rcs) / sizeof(syscall_rcs[0]); i++)
		mix_signed(&digest, syscall_refresh_cred_needed_result(syscall_rcs[i]));
	for (unsigned int i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
		mix_signed(&digest, syscall_getpid_result(pids[i]));
		mix_signed(&digest, syscall_getppid_result(pids[i]));
		mix_signed(&digest, syscall_gettid_result(pids[i]));
		mix_signed(&digest, syscall_set_tid_address_return_result(pids[i]));
	}
	{
		struct fake_syscall_process_ids parent = {
			.pid = 701,
			.ruid = 710,
			.euid = 711,
			.suid = 712,
			.rgid = 713,
			.egid = 714,
			.sgid = 715,
		};
		struct fake_syscall_process_ids proc = {
			.pid = 801,
			.ruid = 810,
			.euid = 811,
			.suid = 812,
			.rgid = 813,
			.egid = 814,
			.sgid = 815,
			.ppid_parent = &parent,
		};
		struct fake_syscall_thread_ids thread = {
			.tid = 901,
			.proc = &proc,
			.clear_child_tid = (int *)0x1234UL,
		};
		int clear_child_tid_slot = 0;
		int rid_out[3] = { -1, -1, -1 };

		mix_signed(&digest, syscall_getpid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid)));
		mix_signed(&digest, syscall_getppid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, ppid_parent),
			offsetof(struct fake_syscall_process_ids, pid)));
		mix_signed(&digest, syscall_gettid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, tid)));
		mix_signed(&digest, syscall_get_process_id_field_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, ruid)));
		mix_signed(&digest, syscall_get_process_id_field_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, euid)));
		mix_signed(&digest, syscall_get_process_id_field_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, rgid)));
		mix_signed(&digest, syscall_get_process_id_field_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, egid)));
		mix_signed(&digest, syscall_set_tid_address_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, clear_child_tid),
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			&clear_child_tid_slot));
		require(thread.clear_child_tid == &clear_child_tid_slot);
		mix_signed(&digest, (long)(uintptr_t)thread.clear_child_tid -
			(long)(uintptr_t)&clear_child_tid_slot);

		fake_getresid_fail_after = -1;
		fake_getresid_calls = 0;
		mix_signed(&digest, syscall_getresid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, ruid),
			offsetof(struct fake_syscall_process_ids, euid),
			offsetof(struct fake_syscall_process_ids, suid),
			(unsigned long)(uintptr_t)&rid_out[0],
			(unsigned long)(uintptr_t)&rid_out[1],
			(unsigned long)(uintptr_t)&rid_out[2],
			fake_copy_int_to_user));
		mix_signed(&digest, rid_out[0]);
		mix_signed(&digest, rid_out[1]);
		mix_signed(&digest, rid_out[2]);
		mix_signed(&digest, fake_getresid_calls);

		rid_out[0] = rid_out[1] = rid_out[2] = -1;
		fake_getresid_fail_after = -1;
		fake_getresid_calls = 0;
		mix_signed(&digest, syscall_getresid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, rgid),
			offsetof(struct fake_syscall_process_ids, egid),
			offsetof(struct fake_syscall_process_ids, sgid),
			(unsigned long)(uintptr_t)&rid_out[0],
			(unsigned long)(uintptr_t)&rid_out[1],
			(unsigned long)(uintptr_t)&rid_out[2],
			fake_copy_int_to_user));
		mix_signed(&digest, rid_out[0]);
		mix_signed(&digest, rid_out[1]);
		mix_signed(&digest, rid_out[2]);
		mix_signed(&digest, fake_getresid_calls);

		rid_out[0] = rid_out[1] = rid_out[2] = -1;
		fake_getresid_fail_after = 1;
		fake_getresid_calls = 0;
		mix_signed(&digest, syscall_getresid_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, ruid),
			offsetof(struct fake_syscall_process_ids, euid),
			offsetof(struct fake_syscall_process_ids, suid),
			(unsigned long)(uintptr_t)&rid_out[0],
			(unsigned long)(uintptr_t)&rid_out[1],
			(unsigned long)(uintptr_t)&rid_out[2],
			fake_copy_int_to_user));
		mix_signed(&digest, rid_out[0]);
		mix_signed(&digest, rid_out[1]);
		mix_signed(&digest, rid_out[2]);
		mix_signed(&digest, fake_getresid_calls);

		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = 77;
		mix_signed(&digest, syscall_kill_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			55, 9, fake_do_kill_thread));
		mix_signed(&digest, fake_do_kill_thread_calls);
		mix_signed(&digest, fake_do_kill_thread_current == &thread);
		mix_signed(&digest, fake_do_kill_thread_pid);
		mix_signed(&digest, fake_do_kill_thread_tid);
		mix_signed(&digest, fake_do_kill_thread_sig);
		mix_signed(&digest, fake_do_kill_thread_ptracecont);
		mix_signed(&digest, fake_do_kill_thread_si_signo);
		mix_signed(&digest, fake_do_kill_thread_si_code);
		mix_signed(&digest, fake_do_kill_thread_si_pid);

		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = 88;
		mix_signed(&digest, syscall_tgkill_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			44, 45, 10, fake_do_kill_thread));
		mix_signed(&digest, fake_do_kill_thread_calls);
		mix_signed(&digest, fake_do_kill_thread_pid);
		mix_signed(&digest, fake_do_kill_thread_tid);
		mix_signed(&digest, fake_do_kill_thread_si_code);
		mix_signed(&digest, fake_do_kill_thread_si_pid);

		fake_do_kill_thread_calls = 0;
		mix_signed(&digest, syscall_tgkill_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			0, 45, 10, fake_do_kill_thread));
		mix_signed(&digest, fake_do_kill_thread_calls);

		fake_do_kill_thread_calls = 0;
		fake_do_kill_thread_rc = 99;
		mix_signed(&digest, syscall_tkill_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			66, 11, fake_do_kill_thread));
		mix_signed(&digest, fake_do_kill_thread_calls);
		mix_signed(&digest, fake_do_kill_thread_pid);
		mix_signed(&digest, fake_do_kill_thread_tid);
		mix_signed(&digest, fake_do_kill_thread_si_code);
		mix_signed(&digest, fake_do_kill_thread_si_pid);

		fake_do_kill_thread_calls = 0;
		mix_signed(&digest, syscall_tkill_body_result(&thread,
			offsetof(struct fake_syscall_thread_ids, proc),
			offsetof(struct fake_syscall_process_ids, pid),
			0, 11, fake_do_kill_thread));
		mix_signed(&digest, fake_do_kill_thread_calls);

		fake_forward_context_calls = 0;
		fake_forward_context_rc = 0;
		fake_forward_context_thread = NULL;
		fake_refresh_uid_calls = 0;
		mix_signed(&digest, syscall_forward_refresh_cred_body_result(
			117, &thread, fake_forward_context, fake_refresh_uid));
		mix_signed(&digest, fake_forward_context_calls);
		mix_signed(&digest, fake_forward_context_nr);
		mix_signed(&digest, fake_forward_context_ctx == &thread);
		mix_signed(&digest, fake_refresh_uid_calls);

		fake_forward_context_calls = 0;
		fake_forward_context_rc = -5;
		fake_refresh_uid_calls = 0;
		mix_signed(&digest, syscall_forward_refresh_cred_body_result(
			113, &thread, fake_forward_context, fake_refresh_uid));
		mix_signed(&digest, fake_forward_context_calls);
		mix_signed(&digest, fake_refresh_uid_calls);
		fake_forward_context_rc = 0;
		mix_signed(&digest, syscall_forward_refresh_cred_body_result(
			113, &thread, fake_forward_context, NULL));

		fake_syscall2_calls = 0;
		fake_syscall2_rc = 4242;
		fake_refresh_uid_calls = 0;
		mix_signed(&digest, (long)syscall_setfsid_body_result(
			515, 122, fake_do_syscall2, fake_refresh_uid));
		mix_signed(&digest, fake_syscall2_calls);
		mix_signed(&digest, fake_syscall2_nr);
		mix(&digest, fake_syscall2_arg0);
		mix(&digest, fake_syscall2_arg1);
		mix_signed(&digest, fake_refresh_uid_calls);

		fake_syscall2_calls = 0;
		fake_syscall2_rc = 4343;
		fake_refresh_gid_calls = 0;
		mix_signed(&digest, (long)syscall_setfsid_body_result(
			616, 123, fake_do_syscall2, fake_refresh_gid));
		mix_signed(&digest, fake_syscall2_calls);
		mix_signed(&digest, fake_syscall2_nr);
		mix(&digest, fake_syscall2_arg0);
		mix(&digest, fake_syscall2_arg1);
		mix_signed(&digest, fake_refresh_gid_calls);

		{
			void *area = NULL;
			int *raw;
			int *selected;

			require(posix_memalign(&area, 4096, 8192) == 0);
			raw = (int *)((char *)area + 4096 - 16);
			fake_virt_to_phys_calls = 0;
			fake_virt_to_phys_value = 0xcafebabeUL;
			fake_processor_id_calls = 0;
			fake_processor_id_value = 23;
			fake_generic_syscall_calls = 0;
			fake_generic_syscall_req = NULL;
			fake_generic_syscall_cpu = -1;
			fake_generic_syscall_rc = 0;
			selected = getcred_body_result(raw,
				~(unsigned long)(4096 - 1), 122,
				fake_virt_to_phys, fake_processor_id,
				fake_generic_syscall);
			require(selected == raw + 8);
			require(fake_virt_to_phys_calls == 1);
			require(fake_virt_to_phys_ptr == selected);
			require(fake_processor_id_calls == 1);
			require(fake_generic_syscall_calls == 1);
			require(fake_generic_syscall_cpu == 23);
			require(fake_generic_syscall_req->number == 122);
			require(fake_generic_syscall_req->args[0] == 0xcafebabeUL);
			require(fake_generic_syscall_req->args[1] == 1);
			mix(&digest, (unsigned long)(selected - raw));
			mix(&digest, fake_generic_syscall_req->number);
			mix(&digest, fake_generic_syscall_req->args[0]);
			mix_signed(&digest, fake_generic_syscall_cpu);
			free(area);
		}

		{
			struct fake_syscall_process_ids proc = { 0 };
			struct fake_syscall_thread_ids cred_thread = {
				.proc = &proc,
			};
			int scratch[16];

			for (int i = 0; i < 8; i++)
				fake_getcred_values[i] = 100 + i;
			fake_getcred_calls = 0;
			mix_signed(&digest,
				syscall_refresh_cred_fields_body_result(
					&cred_thread, scratch,
					offsetof(struct fake_syscall_thread_ids,
						 proc),
					offsetof(struct fake_syscall_process_ids,
						 ruid),
					offsetof(struct fake_syscall_process_ids,
						 euid),
					offsetof(struct fake_syscall_process_ids,
						 suid),
					offsetof(struct fake_syscall_process_ids,
						 fsuid),
					0, 1, 2, 3, fake_getcred));
			require(fake_getcred_calls == 1);
			require(fake_getcred_buf == scratch);
			require(proc.ruid == 100);
			require(proc.euid == 101);
			require(proc.suid == 102);
			require(proc.fsuid == 103);
			mix_signed(&digest, proc.ruid);
			mix_signed(&digest, proc.fsuid);

			for (int i = 0; i < 8; i++)
				fake_getcred_values[i] = 200 + i;
			mix_signed(&digest,
				syscall_refresh_cred_fields_body_result(
					&cred_thread, scratch,
					offsetof(struct fake_syscall_thread_ids,
						 proc),
					offsetof(struct fake_syscall_process_ids,
						 rgid),
					offsetof(struct fake_syscall_process_ids,
						 egid),
					offsetof(struct fake_syscall_process_ids,
						 sgid),
					offsetof(struct fake_syscall_process_ids,
						 fsgid),
					4, 5, 6, 7, fake_getcred));
			require(proc.rgid == 204);
			require(proc.egid == 205);
			require(proc.sgid == 206);
			require(proc.fsgid == 207);
			mix_signed(&digest, proc.rgid);
			mix_signed(&digest, proc.fsgid);
			mix_signed(&digest,
				syscall_refresh_cred_fields_body_result(
					NULL, scratch,
					offsetof(struct fake_syscall_thread_ids,
						 proc),
					0, 0, 0, 0, 0, 1, 2, 3,
					fake_getcred));
			mix_signed(&digest,
				syscall_refresh_cred_fields_body_result(
					&cred_thread, scratch,
					offsetof(struct fake_syscall_thread_ids,
						 proc),
					0, 0, 0, 0, 0, 1, 2, 3,
					NULL));
		}
	}
	{
		static const struct fake_syscall_times_offsets times_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_cputime_thread, proc),
			.thread_user_tsc_offset =
				offsetof(struct fake_cputime_thread, user_tsc),
			.thread_system_tsc_offset =
				offsetof(struct fake_cputime_thread, system_tsc),
			.proc_utime_offset =
				offsetof(struct fake_cputime_process, utime),
			.proc_stime_offset =
				offsetof(struct fake_cputime_process, stime),
			.proc_utime_children_offset =
				offsetof(struct fake_cputime_process, utime_children),
			.proc_stime_children_offset =
				offsetof(struct fake_cputime_process, stime_children),
		};
		struct fake_cputime_process proc = {
			.utime = { .tv_sec = 1, .tv_nsec = 200000000 },
			.stime = { .tv_sec = 2, .tv_nsec = 300000000 },
			.utime_children = { .tv_sec = 3, .tv_nsec = 400000000 },
			.stime_children = { .tv_sec = 4, .tv_nsec = 500000000 },
		};
		struct fake_cputime_thread thread = {
			.user_tsc = 3456,
			.system_tsc = 7890,
			.proc = &proc,
		};
		struct fake_syscall_times_tms out = { 0 };

		fake_times_tsc_calls = 0;
		fake_times_jiffy_calls = 0;
		fake_times_add_calls = 0;
		fake_gettime_calls = 0;
		fake_cputime_copy_calls = 0;
		fake_cputime_copy_fail = 0;
		mix_signed(&digest, syscall_times_body_result(&thread,
			(unsigned long)(uintptr_t)&out, 1, &times_offsets,
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_times_ts_add, fake_gettime,
			fake_cputime_copy_to_user));
		mix(&digest, out.tms_utime);
		mix(&digest, out.tms_stime);
		mix(&digest, out.tms_cutime);
		mix(&digest, out.tms_cstime);
		mix_signed(&digest, fake_times_tsc_calls);
		mix_signed(&digest, fake_times_jiffy_calls);
		mix_signed(&digest, fake_times_add_calls);
		mix_signed(&digest, fake_gettime_calls);
		mix_signed(&digest, fake_cputime_copy_calls);

		memset(&out, 0, sizeof(out));
		fake_gettime_calls = 0;
		fake_cputime_copy_calls = 0;
		mix_signed(&digest, syscall_times_body_result(&thread,
			(unsigned long)(uintptr_t)&out, 0, &times_offsets,
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_times_ts_add, fake_gettime,
			fake_cputime_copy_to_user));
		mix_signed(&digest, fake_gettime_calls);
		mix_signed(&digest, fake_cputime_copy_calls);

		fake_cputime_copy_fail = 1;
		mix_signed(&digest, syscall_times_body_result(&thread,
			(unsigned long)(uintptr_t)&out, 1, &times_offsets,
			fake_times_tsc_to_ts, fake_timespec_to_jiffy,
			fake_times_ts_add, fake_gettime,
			fake_cputime_copy_to_user));
		fake_cputime_copy_fail = 0;
	}
	{
		static const struct fake_syscall_setpgid_offsets offsets = {
			.thread_proc_offset =
				offsetof(struct fake_syscall_thread_ids, proc),
			.proc_pid_offset =
				offsetof(struct fake_syscall_process_ids, pid),
			.proc_pgid_offset =
				offsetof(struct fake_syscall_process_ids, pgid),
			.proc_execed_offset =
				offsetof(struct fake_syscall_process_ids, execed),
		};
		struct fake_syscall_process_ids current = {
			.pid = 801,
		};
		struct fake_syscall_process_ids child = {
			.pid = 802,
		};
		struct fake_syscall_thread_ids thread = {
			.tid = 901,
			.proc = &current,
		};
		int lock_cookie = 0;

		memset(fake_setpgid_table, 0, sizeof(fake_setpgid_table));
		fake_setpgid_table[0] = &current;
		fake_setpgid_table[1] = &child;
		fake_setpgid_find_calls = 0;
		fake_setpgid_unlock_calls = 0;
		fake_forward_context_calls = 0;
		fake_forward_context_rc = 0;
		mix_signed(&digest, syscall_setpgid_body_result(&thread, 0, 0,
			109, &current, &offsets, &lock_cookie,
			fake_setpgid_find_process,
			fake_setpgid_process_unlock, fake_forward_context));
		mix_signed(&digest, current.pgid);
		mix_signed(&digest, fake_setpgid_find_calls);
		mix_signed(&digest, fake_setpgid_unlock_calls);
		mix_signed(&digest, fake_forward_context_calls);
		mix_signed(&digest, fake_forward_context_nr);
		mix_signed(&digest, fake_setpgid_lock_cookie);

		child.pgid = 0;
		child.execed = 0;
		fake_setpgid_find_calls = 0;
		fake_setpgid_unlock_calls = 0;
		fake_forward_context_calls = 0;
		lock_cookie = 0;
		mix_signed(&digest, syscall_setpgid_body_result(&thread, 802,
			0, 109, &child, &offsets, &lock_cookie,
			fake_setpgid_find_process,
			fake_setpgid_process_unlock, fake_forward_context));
		mix_signed(&digest, child.pgid);
		mix_signed(&digest, fake_setpgid_find_calls);
		mix_signed(&digest, fake_setpgid_unlock_calls);
		mix_signed(&digest, fake_forward_context_calls);

		child.execed = 1;
		fake_setpgid_find_calls = 0;
		fake_setpgid_unlock_calls = 0;
		fake_forward_context_calls = 0;
		lock_cookie = 0;
		mix_signed(&digest, syscall_setpgid_body_result(&thread, 802,
			803, 109, &child, &offsets, &lock_cookie,
			fake_setpgid_find_process,
			fake_setpgid_process_unlock, fake_forward_context));
		mix_signed(&digest, fake_setpgid_find_calls);
		mix_signed(&digest, fake_setpgid_unlock_calls);
		mix_signed(&digest, fake_forward_context_calls);

		child.execed = 0;
		fake_setpgid_find_calls = 0;
		fake_forward_context_calls = 0;
		lock_cookie = 0;
		mix_signed(&digest, syscall_setpgid_body_result(&thread, 999,
			0, 109, &child, &offsets, &lock_cookie,
			fake_setpgid_find_process,
			fake_setpgid_process_unlock, fake_forward_context));
		mix_signed(&digest, fake_setpgid_find_calls);
		mix_signed(&digest, fake_forward_context_calls);
	}
	{
		struct fake_rlimit limit = {
			.rlim_cur = 4096,
			.rlim_max = 8192,
		};
		struct fake_syscall_process_ids proc = {
			.pid = 1,
			.euid = 0,
		};
		struct fake_syscall_thread_ids thread = {
			.proc = &proc,
		};
		static const struct fake_syscall_mlockall_offsets mlock_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_syscall_thread_ids, proc),
			.proc_euid_offset =
				offsetof(struct fake_syscall_process_ids, euid),
			.proc_rlimit_offset =
				offsetof(struct fake_syscall_process_ids, rlimit),
			.rlimit_entry_size = sizeof(struct fake_rlimit),
			.memlock_resource = MCK_RLIMIT_MEMLOCK,
		};

		fake_prlimit_rc = 61;
		fake_prlimit_calls = 0;
		mix_signed(&digest, syscall_setrlimit_body_result(7,
			(unsigned long)(uintptr_t)&limit, fake_do_prlimit64));
		mix_signed(&digest, fake_prlimit_calls);
		mix_signed(&digest, fake_prlimit_pid);
		mix_signed(&digest, fake_prlimit_resource);
		mix_signed(&digest, fake_prlimit_new_addr ==
			(unsigned long)(uintptr_t)&limit);
		mix_signed(&digest, fake_prlimit_old_addr == 0);

		fake_prlimit_rc = 62;
		fake_prlimit_calls = 0;
		mix_signed(&digest, syscall_getrlimit_body_result(8,
			(unsigned long)(uintptr_t)&limit, fake_do_prlimit64));
		mix_signed(&digest, fake_prlimit_calls);
		mix_signed(&digest, fake_prlimit_pid);
		mix_signed(&digest, fake_prlimit_resource);
		mix_signed(&digest, fake_prlimit_new_addr == 0);
		mix_signed(&digest, fake_prlimit_old_addr ==
			(unsigned long)(uintptr_t)&limit);

		fake_prlimit_rc = 63;
		fake_prlimit_calls = 0;
		mix_signed(&digest, syscall_prlimit64_body_result(77, 9,
			(unsigned long)(uintptr_t)&limit,
			(unsigned long)(uintptr_t)&limit, fake_do_prlimit64));
		mix_signed(&digest, fake_prlimit_calls);
		mix_signed(&digest, fake_prlimit_pid);
		mix_signed(&digest, fake_prlimit_resource);
		mix_signed(&digest, fake_prlimit_new_addr ==
			(unsigned long)(uintptr_t)&limit);
		mix_signed(&digest, fake_prlimit_old_addr ==
			(unsigned long)(uintptr_t)&limit);

		struct sysinfo sysinfo_out;
		memset(&sysinfo_out, 0xff, sizeof(sysinfo_out));
		fake_cputime_copy_calls = 0;
		fake_cputime_copy_fail = 0;
		mix_signed(&digest, syscall_sysinfo_body_result(
			(unsigned long)(uintptr_t)&sysinfo_out, 12345, 678,
			fake_cputime_copy_to_user));
		mix(&digest, sysinfo_out.totalram);
		mix(&digest, sysinfo_out.freeram);
		mix(&digest, sysinfo_out.mem_unit);
		mix_signed(&digest, fake_cputime_copy_calls);
		fake_cputime_copy_fail = 1;
		mix_signed(&digest, syscall_sysinfo_body_result(
			(unsigned long)(uintptr_t)&sysinfo_out, 12345, 678,
			fake_cputime_copy_to_user));
		fake_cputime_copy_fail = 0;

		fake_get_cpu_calls = 0;
		mix_signed(&digest, syscall_get_cpu_id_body_result(
			fake_get_cpu_id));
		mix_signed(&digest, fake_get_cpu_calls);

		fake_mlock_log_calls = 0;
		proc.euid = 0;
		proc.rlimit[MCK_RLIMIT_MEMLOCK].rlim_cur = 0;
		mix_signed(&digest, syscall_mlockall_body_result(&thread,
			MCL_CURRENT, &mlock_offsets, fake_mlock_log));
		mix_signed(&digest, fake_mlock_log_calls);
		mix_signed(&digest, fake_mlock_log_flags);
		mix_signed(&digest, fake_mlock_log_error);

		proc.euid = 1000;
		proc.rlimit[MCK_RLIMIT_MEMLOCK].rlim_cur = 4096;
		mix_signed(&digest, syscall_mlockall_body_result(&thread,
			MCL_FUTURE, &mlock_offsets, fake_mlock_log));
		mix_signed(&digest, fake_mlock_log_error);
		proc.rlimit[MCK_RLIMIT_MEMLOCK].rlim_cur = 0;
		mix_signed(&digest, syscall_mlockall_body_result(&thread,
			MCL_CURRENT, &mlock_offsets, fake_mlock_log));
		mix_signed(&digest, fake_mlock_log_error);
		mix_signed(&digest, syscall_mlockall_body_result(&thread,
			0, &mlock_offsets, fake_mlock_log));
		mix_signed(&digest, fake_mlock_log_error);

		fake_mlock_log_calls = 0;
		mix_signed(&digest, syscall_munlockall_body_result(
			fake_mlock_log));
		mix_signed(&digest, fake_mlock_log_calls);
		mix_signed(&digest, fake_mlock_log_error);

		int cpu_out = -1;
		int node_out = -1;
		fake_getcpu_copy_calls = 0;
		fake_getcpu_copy_fail_after = -1;
		fake_getcpu_copy_error = -77;
		mix_signed(&digest, syscall_getcpu_body_result(
			(unsigned long)(uintptr_t)&cpu_out,
			(unsigned long)(uintptr_t)&node_out, 3, 4,
			fake_getcpu_copy_to_user));
		mix_signed(&digest, cpu_out);
		mix_signed(&digest, node_out);
		mix_signed(&digest, fake_getcpu_copy_calls);

		node_out = -1;
		fake_getcpu_copy_calls = 0;
		mix_signed(&digest, syscall_getcpu_body_result(0,
			(unsigned long)(uintptr_t)&node_out, 5, 6,
			fake_getcpu_copy_to_user));
		mix_signed(&digest, node_out);
		mix_signed(&digest, fake_getcpu_copy_calls);

		cpu_out = -1;
		fake_getcpu_copy_calls = 0;
		fake_getcpu_copy_fail_after = 0;
		mix_signed(&digest, syscall_getcpu_body_result(
			(unsigned long)(uintptr_t)&cpu_out,
			(unsigned long)(uintptr_t)&node_out, 7, 8,
			fake_getcpu_copy_to_user));
		mix_signed(&digest, cpu_out);
		mix_signed(&digest, fake_getcpu_copy_calls);
		fake_getcpu_copy_fail_after = -1;
	}
	{
		int pgshift = -1;
		int p2align = -1;

		fake_arch_mmap_default_shift_calls = 0;
		fake_arch_mmap_default_shift = 21;
		fake_do_mmap_smaller_page_calls = 0;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_HUGETLB, 0, 0, PAGE_SIZE, &pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 21);
		require(p2align == 9);
		require(fake_arch_mmap_default_shift_calls == 1);
		require(fake_do_mmap_smaller_page_calls == 0);
		mix_signed(&digest, pgshift);
		mix_signed(&digest, p2align);

		pgshift = -1;
		p2align = -1;
		fake_arch_mmap_default_shift_calls = 0;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_HUGETLB | (30 << MAP_HUGE_SHIFT), 0, 0,
			PAGE_SIZE, &pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 30);
		require(p2align == 18);
		require(fake_arch_mmap_default_shift_calls == 0);
		mix_signed(&digest, pgshift);
		mix_signed(&digest, p2align);

		pgshift = -1;
		p2align = -1;
		fake_do_mmap_smaller_page_calls = 0;
		fake_do_mmap_smaller_page_p2align = 4;
		fake_do_mmap_smaller_page_rc = 0;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_PRIVATE | MAP_ANONYMOUS, 0, 0, PAGE_SIZE * 3,
			&pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 0);
		require(p2align == 4);
		require(fake_do_mmap_smaller_page_calls == 1);
		require(fake_do_mmap_smaller_page_size == PAGE_SIZE * 3 + 1);
		mix_signed(&digest, pgshift);
		mix_signed(&digest, p2align);

		pgshift = -1;
		p2align = -1;
		fake_do_mmap_smaller_page_calls = 0;
		fake_do_mmap_smaller_page_rc = -77;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_PRIVATE | MAP_ANONYMOUS, 0, 0, PAGE_SIZE * 2,
			&pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 0);
		require(p2align == fake_do_mmap_smaller_page_p2align);
		require(fake_do_mmap_smaller_page_calls == 1);
		fake_do_mmap_smaller_page_rc = 0;

		pgshift = -1;
		p2align = -1;
		fake_do_mmap_smaller_page_calls = 0;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_PRIVATE | MAP_ANONYMOUS, 0, 1, PAGE_SIZE * 3,
			&pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 12);
		require(p2align == 0);
		require(fake_do_mmap_smaller_page_calls == 0);
		mix_signed(&digest, pgshift);
		mix_signed(&digest, p2align);

		pgshift = -1;
		p2align = -1;
		fake_do_mmap_smaller_page_calls = 0;
		fake_do_mmap_smaller_page_p2align = 3;
		mix_signed(&digest, do_mmap_page_size_body_result(
			MAP_SHARED, 0x40000000UL, 0, PAGE_SIZE * 4,
			&pgshift, &p2align,
			fake_arch_mmap_default_huge_shift,
			fake_do_mmap_smaller_page));
		require(pgshift == 0);
		require(p2align == 3);
		require(fake_do_mmap_smaller_page_calls == 1);
		mix_signed(&digest, pgshift);
		mix_signed(&digest, p2align);
	}
	{
		static const struct fake_syscall_mckfd_offsets mckfd_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_syscall_mckfd_thread, proc),
			.proc_mckfd_lock_offset =
				offsetof(struct fake_syscall_mckfd_process, mckfd_lock),
			.proc_mckfd_offset =
				offsetof(struct fake_syscall_mckfd_process, mckfd),
			.mckfd_next_offset =
				offsetof(struct fake_syscall_mckfd, next),
			.mckfd_fd_offset =
				offsetof(struct fake_syscall_mckfd, fd),
			.mckfd_read_cb_offset =
				offsetof(struct fake_syscall_mckfd, read_cb),
			.mckfd_ioctl_cb_offset =
				offsetof(struct fake_syscall_mckfd, ioctl_cb),
			.mckfd_close_cb_offset =
				offsetof(struct fake_syscall_mckfd, close_cb),
			.mckfd_fcntl_cb_offset =
				offsetof(struct fake_syscall_mckfd, fcntl_cb),
		};
		struct fake_syscall_mckfd fd_a = {
			.fd = 3,
			.read_cb = fake_mckfd_read,
			.ioctl_cb = fake_mckfd_ioctl,
			.mmap_cb = fake_mckfd_mmap,
			.close_cb = fake_mckfd_close,
			.fcntl_cb = fake_mckfd_fcntl,
		};
		struct fake_syscall_mckfd fd_b = {
			.fd = 4,
			.read_cb = fake_mckfd_read,
			.ioctl_cb = fake_mckfd_ioctl,
			.mmap_cb = fake_mckfd_mmap,
			.close_cb = fake_mckfd_close,
			.fcntl_cb = fake_mckfd_fcntl,
		};
		struct fake_syscall_mckfd fd_c = {
			.fd = 5,
			.close_cb = fake_mckfd_close,
		};
		struct fake_syscall_mckfd_process proc = {
			.mckfd_lock = 0x123,
			.mckfd = &fd_a,
		};
		struct fake_syscall_mckfd_thread thread = {
			.proc = &proc,
		};
		char fake_ctx;

		fd_a.next = &fd_b;
		fd_b.next = &fd_c;
		fake_mckfd_lock_calls = 0;
		fake_mckfd_unlock_calls = 0;
		fake_mckfd_read_calls = 0;
		fake_mckfd_fd_sum = 0;
		fake_mckfd_ctx_matches = 0;
		fake_mckfd_read_rc = 701;
		fake_forward_context_calls = 0;
		fake_forward_context_rc = 900;
		mix_signed(&digest, syscall_read_body_result(&thread, 4, 0,
			&fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context));
		require(fake_mckfd_read_calls == 1);
		require(fake_forward_context_calls == 0);
		mix_signed(&digest, fake_mckfd_lock_calls);
		mix_signed(&digest, fake_mckfd_unlock_calls);
		mix_signed(&digest, fake_mckfd_fd_sum);
		mix_signed(&digest, fake_mckfd_ctx_matches);

		fake_mckfd_fd_sum = 0;
		fake_mckfd_read_calls = 0;
		fake_forward_context_calls = 0;
		fake_forward_context_rc = 901;
		mix_signed(&digest, syscall_read_body_result(&thread, 9, 0x11,
			&fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context));
		require(fake_mckfd_read_calls == 0);
		require(fake_forward_context_calls == 1);
		mix_signed(&digest, fake_forward_context_nr);
		mix_signed(&digest, fake_mckfd_fd_sum);

		{
			int handled = -1;

			fake_mckfd_mmap_calls = 0;
			fake_mckfd_fd_sum = 0;
			fake_mckfd_ctx_matches = 0;
			fake_mckfd_mmap_rc = 904;
			mix_signed(&digest, do_mmap_mckfd_dispatch_body_result(
				&thread, MAP_PRIVATE, 4, &fake_ctx, &handled,
				&mckfd_offsets,
				offsetof(struct fake_syscall_mckfd, mmap_cb),
				fake_mckfd_lock, fake_mckfd_unlock));
			require(handled == 1);
			require(fake_mckfd_mmap_calls == 1);
			mix_signed(&digest, fake_mckfd_fd_sum);
			mix_signed(&digest, fake_mckfd_ctx_matches);

			handled = -1;
			fake_mckfd_mmap_calls = 0;
			fake_mckfd_fd_sum = 0;
			mix_signed(&digest, do_mmap_mckfd_dispatch_body_result(
				&thread, MAP_PRIVATE, 19, &fake_ctx, &handled,
				&mckfd_offsets,
				offsetof(struct fake_syscall_mckfd, mmap_cb),
				fake_mckfd_lock, fake_mckfd_unlock));
			require(handled == 0);
			require(fake_mckfd_mmap_calls == 0);
			mix_signed(&digest, fake_mckfd_fd_sum);

			fd_b.mmap_cb = NULL;
			handled = -1;
			fake_mckfd_mmap_calls = 0;
			mix_signed(&digest, do_mmap_mckfd_dispatch_body_result(
				&thread, MAP_PRIVATE, 4, &fake_ctx, &handled,
				&mckfd_offsets,
				offsetof(struct fake_syscall_mckfd, mmap_cb),
				fake_mckfd_lock, fake_mckfd_unlock));
			require(handled == 1);
			require(fake_mckfd_mmap_calls == 0);
			fd_b.mmap_cb = fake_mckfd_mmap;

			handled = -1;
			fake_mckfd_lock_calls = 0;
			fake_mckfd_unlock_calls = 0;
			mix_signed(&digest, do_mmap_mckfd_dispatch_body_result(
				&thread, MAP_PRIVATE | MAP_ANONYMOUS, 4,
				&fake_ctx, &handled, &mckfd_offsets,
				offsetof(struct fake_syscall_mckfd, mmap_cb),
				fake_mckfd_lock, fake_mckfd_unlock));
			require(handled == 0);
			require(fake_mckfd_lock_calls == 0);
			require(fake_mckfd_unlock_calls == 0);
		}

		fd_b.read_cb = NULL;
		fake_forward_context_calls = 0;
		fake_forward_context_rc = 902;
		mix_signed(&digest, syscall_read_body_result(&thread, 4, 0x12,
			&fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context));
		require(fake_forward_context_calls == 1);
		fd_b.read_cb = fake_mckfd_read;

		fake_mckfd_tofu_ioctl_calls = 0;
		fake_mckfd_tofu_handled = 1;
		fake_mckfd_tofu_rc = 777;
		fake_mckfd_ioctl_calls = 0;
		fake_mckfd_fd_sum = 0;
		mix_signed(&digest, syscall_ioctl_body_result(&thread, 4,
			0xabc, 0xdef, 0x13, &fake_ctx, &mckfd_offsets,
			fake_mckfd_lock, fake_mckfd_unlock,
			fake_forward_context, fake_mckfd_tofu_ioctl));
		require(fake_mckfd_tofu_ioctl_calls == 1);
		require(fake_mckfd_ioctl_calls == 0);
		mix(&digest, fake_mckfd_tofu_cmd);
		mix(&digest, fake_mckfd_tofu_arg);
		mix_signed(&digest, fake_mckfd_fd_sum);

		fake_mckfd_tofu_handled = 0;
		fake_mckfd_ioctl_rc = 778;
		fake_mckfd_ioctl_calls = 0;
		fake_forward_context_calls = 0;
		fake_mckfd_fd_sum = 0;
		mix_signed(&digest, syscall_ioctl_body_result(&thread, 3,
			0x123, 0x456, 0x14, &fake_ctx, &mckfd_offsets,
			fake_mckfd_lock, fake_mckfd_unlock,
			fake_forward_context, fake_mckfd_tofu_ioctl));
		require(fake_mckfd_ioctl_calls == 1);
		require(fake_forward_context_calls == 0);
		mix_signed(&digest, fake_mckfd_fd_sum);

		fake_mckfd_fcntl_rc = 779;
		fake_mckfd_fcntl_calls = 0;
		fake_mckfd_fd_sum = 0;
		mix_signed(&digest, syscall_fcntl_body_result(&thread, 3,
			0x15, &fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context));
		require(fake_mckfd_fcntl_calls == 1);
		mix_signed(&digest, fake_mckfd_fd_sum);

		fake_mckfd_close_rc = 0;
		fake_mckfd_close_calls = 0;
		fake_mckfd_free_calls = 0;
		fake_mckfd_tofu_close_calls = 0;
		fake_mckfd_fd_sum = 0;
		fake_forward_context_calls = 0;
		fake_forward_context_rc = 903;
		mix_signed(&digest, syscall_close_body_result(&thread, 4,
			0x16, &fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context,
			fake_mckfd_tofu_close, fake_mckfd_free));
		require(proc.mckfd == &fd_a);
		require(fd_a.next == &fd_c);
		require(fd_b.next == NULL);
		require(fake_mckfd_close_calls == 1);
		require(fake_mckfd_free_calls == 1);
		require(fake_mckfd_tofu_close_calls == 1);
		require(fake_forward_context_calls == 1);
		mix_signed(&digest, fake_mckfd_fd_sum);

		fake_mckfd_close_calls = 0;
		fake_mckfd_free_calls = 0;
		fake_mckfd_tofu_close_calls = 0;
		fake_mckfd_fd_sum = 0;
		fake_forward_context_calls = 0;
		mix_signed(&digest, syscall_close_body_result(&thread, 9,
			0x17, &fake_ctx, &mckfd_offsets, fake_mckfd_lock,
			fake_mckfd_unlock, fake_forward_context,
			fake_mckfd_tofu_close, fake_mckfd_free));
		require(fake_mckfd_close_calls == 0);
		require(fake_mckfd_free_calls == 0);
		require(fake_mckfd_tofu_close_calls == 1);
		require(fake_forward_context_calls == 1);
		mix_signed(&digest, fake_mckfd_fd_sum);
	}
	{
		struct fake_sigaltstack_thread thread = {
			.prefix = 7,
			.sigstack = {
				.ss_sp = (void *)0x1111UL,
				.ss_flags = 0,
				.ss_size = MINSIGSTKSZ + 64,
			},
			.suffix = 9,
		};
		stack_t old_stack = { 0 };
		stack_t new_stack = {
			.ss_sp = (void *)0x2222UL,
			.ss_flags = 0,
			.ss_size = MINSIGSTKSZ + 128,
		};
		stack_t disable_stack = {
			.ss_sp = (void *)0x3333UL,
			.ss_flags = SS_DISABLE,
			.ss_size = 0,
		};
		stack_t small_stack = {
			.ss_sp = (void *)0x4444UL,
			.ss_flags = 0,
			.ss_size = MINSIGSTKSZ - 1,
		};

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		mix_signed(&digest, sigaltstack_body_result(&thread,
			offsetof(struct fake_sigaltstack_thread, sigstack),
			(unsigned long)(uintptr_t)&new_stack,
			(unsigned long)(uintptr_t)&old_stack,
			fake_copy_stack_from_user, fake_copy_stack_to_user));
		mix(&digest, (unsigned long)(uintptr_t)old_stack.ss_sp);
		mix_signed(&digest, old_stack.ss_flags);
		mix(&digest, old_stack.ss_size);
		mix(&digest, (unsigned long)(uintptr_t)thread.sigstack.ss_sp);
		mix_signed(&digest, thread.sigstack.ss_flags);
		mix(&digest, thread.sigstack.ss_size);
		mix_signed(&digest, fake_stack_copy_from_calls);
		mix_signed(&digest, fake_stack_copy_to_calls);

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		mix_signed(&digest, sigaltstack_body_result(&thread,
			offsetof(struct fake_sigaltstack_thread, sigstack),
			(unsigned long)(uintptr_t)&disable_stack, 0,
			fake_copy_stack_from_user, fake_copy_stack_to_user));
		mix(&digest, (unsigned long)(uintptr_t)thread.sigstack.ss_sp);
		mix_signed(&digest, thread.sigstack.ss_flags);
		mix(&digest, thread.sigstack.ss_size);
		mix_signed(&digest, fake_stack_copy_from_calls);
		mix_signed(&digest, fake_stack_copy_to_calls);

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		mix_signed(&digest, sigaltstack_body_result(&thread,
			offsetof(struct fake_sigaltstack_thread, sigstack),
			(unsigned long)(uintptr_t)&small_stack, 0,
			fake_copy_stack_from_user, fake_copy_stack_to_user));
		mix(&digest, (unsigned long)(uintptr_t)thread.sigstack.ss_sp);
		mix_signed(&digest, thread.sigstack.ss_flags);
		mix(&digest, thread.sigstack.ss_size);
		mix_signed(&digest, fake_stack_copy_from_calls);

		fake_stack_copy_from_fail = 1;
		fake_stack_copy_to_fail = 0;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		mix_signed(&digest, sigaltstack_body_result(&thread,
			offsetof(struct fake_sigaltstack_thread, sigstack),
			(unsigned long)(uintptr_t)&new_stack, 0,
			fake_copy_stack_from_user, fake_copy_stack_to_user));
		mix_signed(&digest, fake_stack_copy_from_calls);

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 1;
		fake_stack_copy_from_calls = 0;
		fake_stack_copy_to_calls = 0;
		mix_signed(&digest, sigaltstack_body_result(&thread,
			offsetof(struct fake_sigaltstack_thread, sigstack),
			(unsigned long)(uintptr_t)&new_stack,
			(unsigned long)(uintptr_t)&old_stack,
			fake_copy_stack_from_user, fake_copy_stack_to_user));
		mix_signed(&digest, fake_stack_copy_from_calls);
		mix_signed(&digest, fake_stack_copy_to_calls);
	}
	{
		struct fake_sigmask_thread thread = {
			.prefix = 1,
			.sigmask = 0x55,
			.suffix = 2,
		};
		unsigned long new_mask = 0x200 | SIGKILL_MASK | SIGSTOP_MASK;
		unsigned long old_mask = 0;

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_forward_sigmask_calls = 0;
		fake_forward_sigmask_value = 0;
		mix_signed(&digest, rt_sigprocmask_body_result(SIG_SETMASK,
			(unsigned long)(uintptr_t)&new_mask,
			(unsigned long)(uintptr_t)&old_mask,
			sizeof(unsigned long), sizeof(unsigned long),
			&thread, offsetof(struct fake_sigmask_thread, sigmask),
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_forward_sigmask));
		mix(&digest, old_mask);
		mix(&digest, thread.sigmask);
		mix_signed(&digest, fake_forward_sigmask_calls);
		mix(&digest, fake_forward_sigmask_value);

		fake_stack_copy_from_fail = 1;
		fake_forward_sigmask_calls = 0;
		mix_signed(&digest, rt_sigprocmask_body_result(SIG_BLOCK,
			(unsigned long)(uintptr_t)&new_mask, 0,
			sizeof(unsigned long), sizeof(unsigned long),
			&thread, offsetof(struct fake_sigmask_thread, sigmask),
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_forward_sigmask));
		mix(&digest, thread.sigmask);
		mix_signed(&digest, fake_forward_sigmask_calls);
	}
	{
		struct fake_siginfo info;

		memset(&info, 0, sizeof(info));
		info.si_signo = 44;
		fake_stack_copy_from_fail = 0;
		fake_do_kill_calls = 0;
		fake_do_kill_rc = 123;
		mix_signed(&digest, rt_sigqueueinfo_body_result(77, 12,
			(unsigned long)(uintptr_t)&info,
			fake_copy_stack_from_user, fake_do_kill));
		mix_signed(&digest, fake_do_kill_calls);
		mix_signed(&digest, fake_do_kill_pid);
		mix_signed(&digest, fake_do_kill_sig);
		mix_signed(&digest, fake_do_sigaction_seen_mask);

		fake_stack_copy_from_fail = 1;
		fake_do_kill_calls = 0;
		mix_signed(&digest, rt_sigqueueinfo_body_result(77, 12,
			(unsigned long)(uintptr_t)&info,
			fake_copy_stack_from_user, fake_do_kill));
		mix_signed(&digest, fake_do_kill_calls);
		mix_signed(&digest, rt_sigqueueinfo_body_result(0, 12,
			(unsigned long)(uintptr_t)&info,
			fake_copy_stack_from_user, fake_do_kill));
	}
	{
		struct fake_sigcommon common;
		struct fake_k_sigaction act;
		struct fake_k_sigaction old;
		char lock_node;

		memset(&common, 0, sizeof(common));
		memset(&act, 0, sizeof(act));
		memset(&old, 0, sizeof(old));
		common.action[9].sa.sa_handler = (void *)0x7777UL;
		common.action[9].sa.sa_flags = 0x88;
		common.action[9].sa.sa_restorer = (void *)0x9999UL;
		common.action[9].sa.sa_mask = 0xdef;
		act.sa.sa_handler = (void *)0x1234UL;
		act.sa.sa_flags = 0x99;
		act.sa.sa_restorer = (void *)0x5678UL;
		act.sa.sa_mask = 0xabc;
		fake_sigaction_body_lock_calls = 0;
		fake_sigaction_body_unlock_calls = 0;
		fake_sigaction_body_forward_calls = 0;
		mix_signed(&digest, do_sigaction_body_result(10, &act, &old,
			&common, offsetof(struct fake_sigcommon, action),
			sizeof(struct fake_k_sigaction),
			offsetof(struct fake_sigcommon, lock_word),
			&lock_node, fake_sigaction_body_lock,
			fake_sigaction_body_unlock,
			fake_sigaction_body_forward));
		mix(&digest, (unsigned long)(uintptr_t)old.sa.sa_handler);
		mix(&digest, old.sa.sa_mask);
		mix(&digest, (unsigned long)(uintptr_t)
				common.action[9].sa.sa_handler);
		mix(&digest, common.action[9].sa.sa_mask);
		mix_signed(&digest, fake_sigaction_body_lock_calls);
		mix_signed(&digest, fake_sigaction_body_unlock_calls);
		mix_signed(&digest, fake_sigaction_body_forward_calls);
		mix_signed(&digest, fake_sigaction_body_forward_sig);
		mix(&digest, fake_sigaction_body_forward_mask);
		mix(&digest, fake_sigaction_body_lock_ptr ==
				&common.lock_word);
		mix(&digest, fake_sigaction_body_unlock_ptr ==
				&common.lock_word);
		mix(&digest, fake_sigaction_body_lock_node == &lock_node);
		mix(&digest, fake_sigaction_body_unlock_node == &lock_node);

		memset(&old, 0, sizeof(old));
		common.action[11].sa.sa_mask = 0x123;
		fake_sigaction_body_forward_calls = 0;
		mix_signed(&digest, do_sigaction_body_result(12, NULL, &old,
			&common, offsetof(struct fake_sigcommon, action),
			sizeof(struct fake_k_sigaction),
			offsetof(struct fake_sigcommon, lock_word),
			&lock_node, fake_sigaction_body_lock,
			fake_sigaction_body_unlock,
			fake_sigaction_body_forward));
		mix(&digest, old.sa.sa_mask);
		mix_signed(&digest, fake_sigaction_body_forward_calls);
		mix_signed(&digest, do_sigaction_body_result(0, &act, &old,
			&common, offsetof(struct fake_sigcommon, action),
			sizeof(struct fake_k_sigaction),
			offsetof(struct fake_sigcommon, lock_word),
			&lock_node, fake_sigaction_body_lock,
			fake_sigaction_body_unlock,
			fake_sigaction_body_forward));
		mix_signed(&digest, do_sigaction_body_result(10, &act, &old,
			&common, offsetof(struct fake_sigcommon, action),
			sizeof(struct fake_k_sigaction),
			offsetof(struct fake_sigcommon, lock_word),
			&lock_node, fake_sigaction_body_lock,
			fake_sigaction_body_unlock, NULL));
	}
	{
		struct fake_sigaction act = {
			.sa_handler = (void *)0x1234UL,
			.sa_flags = 0x99,
			.sa_restorer = (void *)0x5678UL,
			.sa_mask = 0xabc,
		};
		struct fake_sigaction old = { 0 };

		fake_do_sigaction_old.sa.sa_handler = (void *)0x7777UL;
		fake_do_sigaction_old.sa.sa_flags = 0x88;
		fake_do_sigaction_old.sa.sa_restorer = (void *)0x9999UL;
		fake_do_sigaction_old.sa.sa_mask = 0xdef;
		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_do_sigaction_calls = 0;
		fake_do_sigaction_rc = 0;
		mix_signed(&digest, rt_sigaction_body_result(10,
			(unsigned long)(uintptr_t)&act,
			(unsigned long)(uintptr_t)&old,
			sizeof(unsigned long), sizeof(unsigned long),
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_sigaction));
		mix_signed(&digest, fake_do_sigaction_calls);
		mix_signed(&digest, fake_do_sigaction_sig);
		mix_signed(&digest, fake_do_sigaction_has_act);
		mix_signed(&digest, fake_do_sigaction_has_oact);
		mix(&digest, fake_do_sigaction_seen_mask);
		mix(&digest, (unsigned long)(uintptr_t)old.sa_handler);
		mix(&digest, old.sa_mask);

		fake_stack_copy_to_fail = 1;
		mix_signed(&digest, rt_sigaction_body_result(10,
			0, (unsigned long)(uintptr_t)&old,
			sizeof(unsigned long), sizeof(unsigned long),
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_sigaction));
		fake_stack_copy_to_fail = 0;
		mix_signed(&digest, rt_sigaction_body_result(10, 0, 0,
			sizeof(unsigned long) + 1, sizeof(unsigned long),
			fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_sigaction));
	}
	{
		struct timeval tv_out = { 0 };
		unsigned long tv_user = (unsigned long)(uintptr_t)&tv_out;
		unsigned long tz_user = 0x1000UL;

		fake_gettime_calls = 0;
		fake_syscall2_calls = 0;
		fake_stack_copy_to_fail = 0;
		mix_signed(&digest, gettimeofday_body_result(
			tv_user, 0, 1, 96,
			fake_gettime, fake_copy_stack_to_user,
			fake_do_syscall2));
		mix_signed(&digest, fake_gettime_calls);
		mix_signed(&digest, fake_syscall2_calls);
		mix_signed(&digest, tv_out.tv_sec);
		mix_signed(&digest, tv_out.tv_usec);

		fake_syscall2_calls = 0;
		fake_syscall2_rc = -77;
		mix_signed(&digest, gettimeofday_body_result(
			tv_user, tz_user, 1, 96,
			fake_gettime, fake_copy_stack_to_user,
			fake_do_syscall2));
		mix_signed(&digest, fake_syscall2_calls);
		mix_signed(&digest, fake_syscall2_nr);
		mix_signed(&digest, fake_syscall2_arg0 == tv_user);
		mix(&digest, fake_syscall2_arg1);
	}
	{
		struct timeval tv_in = { .tv_sec = 20, .tv_usec = 250000 };
		struct timespec origin = { 0 };
		int fake_lock = 0;
		int fake_ctx = 0;
		long rc;

		fake_settimeofday_reset(0);
		fake_rdtsc_value = 2250;
		fake_forward_context_rc = 0;
		rc = settimeofday_body_result(
			(unsigned long)(uintptr_t)&tv_in, 0, 1, 1000, 164,
			&fake_ctx, &fake_lock, &fake_settimeofday_version,
			&origin, fake_settimeofday_lock,
			fake_settimeofday_unlock, fake_copy_stack_from_user,
			fake_rdtsc, fake_forward_context,
			fake_settimeofday_atomic_read,
			fake_settimeofday_atomic_inc, fake_settimeofday_wmb,
			fake_settimeofday_panic, fake_settimeofday_log);
		require(rc == 0);
		require(fake_settimeofday_lock_calls == 1);
		require(fake_settimeofday_unlock_calls == 1);
		require(fake_stack_copy_from_calls == 1);
		require(fake_forward_context_calls == 1);
		require(fake_forward_context_nr == 164);
		require(fake_settimeofday_atomic_inc_calls == 2);
		require(fake_settimeofday_wmb_calls == 2);
		require(fake_settimeofday_origin_logs == 1);
		require(origin.tv_sec == 18);
		require(origin.tv_nsec == 0);
		require(fake_settimeofday_origin_sec == origin.tv_sec);
		require(fake_settimeofday_origin_nsec == origin.tv_nsec);
		mix(&digest, fake_settimeofday_digest);
		mix_signed(&digest, origin.tv_sec);
		mix_signed(&digest, origin.tv_nsec);

		fake_settimeofday_reset(0);
		fake_forward_context_rc = -33;
		origin.tv_sec = 88;
		origin.tv_nsec = 99;
		rc = settimeofday_body_result(
			(unsigned long)(uintptr_t)&tv_in, 0, 1, 1000, 164,
			&fake_ctx, &fake_lock, &fake_settimeofday_version,
			&origin, fake_settimeofday_lock,
			fake_settimeofday_unlock, fake_copy_stack_from_user,
			fake_rdtsc, fake_forward_context,
			fake_settimeofday_atomic_read,
			fake_settimeofday_atomic_inc, fake_settimeofday_wmb,
			fake_settimeofday_panic, fake_settimeofday_log);
		require(rc == -33);
		require(fake_settimeofday_atomic_inc_calls == 0);
		require(fake_settimeofday_origin_logs == 0);
		require(origin.tv_sec == 88);
		require(fake_settimeofday_exit_error == -33);
		mix(&digest, fake_settimeofday_digest);
		mix_signed(&digest, rc);

		fake_settimeofday_reset(0);
		fake_stack_copy_from_fail = 1;
		rc = settimeofday_body_result(
			(unsigned long)(uintptr_t)&tv_in, 0, 1, 1000, 164,
			&fake_ctx, &fake_lock, &fake_settimeofday_version,
			&origin, fake_settimeofday_lock,
			fake_settimeofday_unlock, fake_copy_stack_from_user,
			fake_rdtsc, fake_forward_context,
			fake_settimeofday_atomic_read,
			fake_settimeofday_atomic_inc, fake_settimeofday_wmb,
			fake_settimeofday_panic, fake_settimeofday_log);
		require(rc == -14);
		require(fake_forward_context_calls == 0);
		require(fake_settimeofday_unlock_calls == 1);
		mix(&digest, fake_settimeofday_digest);
		mix_signed(&digest, rc);

		fake_settimeofday_reset(0);
		fake_forward_context_rc = 41;
		rc = settimeofday_body_result(
			0, 0x1234UL, 1, 1000, 164, &fake_ctx, &fake_lock,
			&fake_settimeofday_version, &origin,
			fake_settimeofday_lock, fake_settimeofday_unlock,
			fake_copy_stack_from_user, fake_rdtsc,
			fake_forward_context, fake_settimeofday_atomic_read,
			fake_settimeofday_atomic_inc, fake_settimeofday_wmb,
			fake_settimeofday_panic, fake_settimeofday_log);
		require(rc == 41);
		require(fake_stack_copy_from_calls == 0);
		require(fake_settimeofday_atomic_inc_calls == 0);
		require(fake_forward_context_calls == 1);
		mix(&digest, fake_settimeofday_digest);
		mix_signed(&digest, rc);

		fake_settimeofday_reset(1);
		fake_forward_context_rc = 0;
		rc = settimeofday_body_result(
			0, 0, 0, 1000, 164, &fake_ctx, &fake_lock,
			&fake_settimeofday_version, &origin,
			fake_settimeofday_lock, fake_settimeofday_unlock,
			fake_copy_stack_from_user, fake_rdtsc,
			fake_forward_context, fake_settimeofday_atomic_read,
			fake_settimeofday_atomic_inc, fake_settimeofday_wmb,
			fake_settimeofday_panic, fake_settimeofday_log);
		require(rc == 0);
		require(fake_settimeofday_panic_calls == 1);
		require(fake_forward_context_calls == 1);
		mix(&digest, fake_settimeofday_digest);
		mix_signed(&digest, fake_settimeofday_panic_calls);
	}
	{
		struct timespec tv = { .tv_sec = 0, .tv_nsec = 1000 };
		struct timespec rem = { 0 };
		struct fake_monitor monitor = { .prefix = 1, .status = 0 };
		int dummy_thread = 0;

		fake_stack_copy_from_fail = 0;
		fake_stack_copy_to_fail = 0;
		fake_syscall2_calls = 0;
		fake_rdtsc_value = 0;
		fake_rdtsc_step = 2500;
		fake_ns_per_tsc_value = 1000;
		fake_has_sigpending_after = -1;
		fake_has_sigpending_calls = 0;
		fake_cpu_pause_calls = 0;
		mix_signed(&digest, nanosleep_body_result(
			(unsigned long)(uintptr_t)&tv,
			(unsigned long)(uintptr_t)&rem, 1, 35,
			&dummy_thread, &monitor, offsetof(struct fake_monitor, status),
			44, fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_syscall2, fake_rdtsc, fake_ns_per_tsc,
			fake_has_sigpending, fake_cpu_pause));
		mix_signed(&digest, monitor.status);
		mix_signed(&digest, fake_cpu_pause_calls);
		mix_signed(&digest, fake_has_sigpending_calls);

		rem.tv_sec = 99;
		rem.tv_nsec = 99;
		fake_rdtsc_value = 0;
		fake_rdtsc_step = 100;
		fake_ns_per_tsc_value = 1000;
		fake_has_sigpending_after = 2;
		fake_has_sigpending_calls = 0;
		fake_cpu_pause_calls = 0;
		mix_signed(&digest, nanosleep_body_result(
			(unsigned long)(uintptr_t)&tv,
			(unsigned long)(uintptr_t)&rem, 1, 35,
			&dummy_thread, &monitor, offsetof(struct fake_monitor, status),
			44, fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_syscall2, fake_rdtsc, fake_ns_per_tsc,
			fake_has_sigpending, fake_cpu_pause));
		mix_signed(&digest, rem.tv_sec);
		mix_signed(&digest, rem.tv_nsec);
		mix_signed(&digest, fake_cpu_pause_calls);

		fake_syscall2_calls = 0;
		fake_syscall2_rc = -88;
		mix_signed(&digest, nanosleep_body_result(
			(unsigned long)(uintptr_t)&tv,
			(unsigned long)(uintptr_t)&rem, 0, 35,
			&dummy_thread, &monitor, offsetof(struct fake_monitor, status),
			44, fake_copy_stack_from_user, fake_copy_stack_to_user,
			fake_do_syscall2, fake_rdtsc, fake_ns_per_tsc,
			fake_has_sigpending, fake_cpu_pause));
		mix_signed(&digest, fake_syscall2_calls);
		mix_signed(&digest, fake_syscall2_nr);
	}
	for (unsigned int i = 0; i < sizeof(syscall_numbers) / sizeof(syscall_numbers[0]); i++) {
		for (unsigned int p = 0; p < sizeof(pids) / sizeof(pids[0]); p++) {
			mix_signed(&digest, syscall_use_requester_tid_result(
				syscall_numbers[i], (unsigned long)pids[p], 203));
		}
	}
	require(syscall_target_tid_result(1, 1234) == 1234);
	require(syscall_target_tid_result(0, 1234) == 0);
	require(syscall_target_tid_result(-1, 77) == 77);
	{
		struct fake_syscall_request send_req = {
			.rtid = 1,
			.ttid = 2,
			.valid = 3,
			.number = 4,
			.args = { 5, 6, 7, 8, 9, 10 },
		};
		struct fake_syscall_response send_res = {
			.ttid = 11,
			.stid = 12,
			.status = 13,
			.req_thread_status = 14,
			.ret = 15,
			.fault_address = 16,
			.pde_data = (void *)0x1234,
		};

		require(syscall_send_prepare_result(&send_req, &send_res) == 0);
		require(send_req.valid == 0);
		require(send_req.number == 4);
		require(send_req.args[1] == 6);
		require(send_res.status == 0);
		require(send_res.req_thread_status == 14);
		require(send_res.pde_data == (void *)0x1234);
		require(syscall_send_prepare_result(NULL, &send_res) == -22);
		require(syscall_send_prepare_result(&send_req, NULL) == -22);
		require(syscall_request_publish_result(&send_req) == 0);
		require(send_req.valid == 1);
		require(syscall_request_publish_result(NULL) == -22);
		mix(&digest, send_req.valid);
		mix(&digest, send_res.status);
	}
	{
		struct fake_syscall_request src_req = {
			.rtid = 21,
			.ttid = 22,
			.valid = 23,
			.number = 24,
			.args = { 25, 26, 27, 28, 29, 30 },
		};
		struct fake_syscall_request dst_req = {
			.rtid = -1,
			.ttid = -2,
			.valid = 77,
			.number = 88,
			.args = { 101, 102, 103, 104, 105, 106 },
		};

		require(syscall_request_copy_result(&dst_req, &src_req) == 0);
		require(dst_req.rtid == 21);
		require(dst_req.ttid == 22);
		require(dst_req.valid == 23);
		require(dst_req.number == 24);
		require(dst_req.args[0] == 25);
		require(dst_req.args[5] == 30);
		require(syscall_request_copy_result(NULL, &src_req) == -22);
		require(syscall_request_copy_result(&dst_req, NULL) == -22);
		mix_signed(&digest, dst_req.rtid);
		mix_signed(&digest, dst_req.ttid);
		mix(&digest, dst_req.valid);
		mix(&digest, dst_req.args[5]);
	}
	{
		struct fake_syscall_request src_req;
		struct fake_syscall_request roundtrip_req;
		_Alignas(struct fake_syscall_request)
			unsigned char src_bytes[sizeof(src_req) + 1];
		_Alignas(struct fake_syscall_request)
			unsigned char dst_bytes[sizeof(roundtrip_req) + 1];
		const struct fake_syscall_request *unaligned_src =
			(const void *)(src_bytes + 1);
		struct fake_syscall_request *unaligned_dst =
			(void *)(dst_bytes + 1);

		memset(&src_req, 0xa5, sizeof(src_req));
		src_req.rtid = -1234567;
		src_req.ttid = 7654321;
		src_req.valid = 0x0123456789abcdefUL;
		src_req.number = 0xfedcba9876543210UL;
		src_req.args[0] = 0x1111111111111111UL;
		src_req.args[1] = 0x2222222222222222UL;
		src_req.args[2] = 0x3333333333333333UL;
		src_req.args[3] = 0x4444444444444444UL;
		src_req.args[4] = 0x5555555555555555UL;
		src_req.args[5] = 0x6666666666666666UL;
		memset(src_bytes, 0x3c, sizeof(src_bytes));
		memcpy(src_bytes + 1, &src_req, sizeof(src_req));
		memset(dst_bytes, 0xc3, sizeof(dst_bytes));

		require((uintptr_t)unaligned_src % _Alignof(struct fake_syscall_request)
			!= 0);
		require((uintptr_t)unaligned_dst % _Alignof(struct fake_syscall_request)
			!= 0);
		require(syscall_request_copy_result(unaligned_dst,
			unaligned_src) == 0);
		require(memcmp(dst_bytes + 1, src_bytes + 1,
			sizeof(src_req)) == 0);
		memcpy(&roundtrip_req, dst_bytes + 1, sizeof(roundtrip_req));
		require(roundtrip_req.rtid == -1234567);
		require(roundtrip_req.ttid == 7654321);
		require(roundtrip_req.valid == 0x0123456789abcdefUL);
		require(roundtrip_req.number == 0xfedcba9876543210UL);
		require(roundtrip_req.args[0] == 0x1111111111111111UL);
		require(roundtrip_req.args[1] == 0x2222222222222222UL);
		require(roundtrip_req.args[2] == 0x3333333333333333UL);
		require(roundtrip_req.args[3] == 0x4444444444444444UL);
		require(roundtrip_req.args[4] == 0x5555555555555555UL);
		require(roundtrip_req.args[5] == 0x6666666666666666UL);
		mix_signed(&digest, roundtrip_req.rtid);
		mix_signed(&digest, roundtrip_req.ttid);
		mix(&digest, roundtrip_req.valid);
		mix(&digest, roundtrip_req.number);
		mix(&digest, roundtrip_req.args[0]);
		mix(&digest, roundtrip_req.args[5]);
	}
	{
		struct fake_syscall_request generic_req = {
			.rtid = 11,
			.ttid = 12,
			.valid = 13,
			.number = 14,
			.args = { 15, 16, 17, 18, 19, 20 },
		};
		long rc;

		fake_generic_syscall_calls = 0;
		fake_generic_syscall_req = NULL;
		fake_generic_syscall_cpu = -1;
		fake_generic_syscall_rc = -1234;
		rc = syscall_generic_forwarding_body_result(&generic_req, 321,
			10, 20, 30, 40, 50, 60, 7,
			fake_generic_syscall);
		require(rc == -1234);
		require(fake_generic_syscall_calls == 1);
		require(fake_generic_syscall_req == &generic_req);
		require(fake_generic_syscall_cpu == 7);
		require(generic_req.rtid == 11);
		require(generic_req.ttid == 12);
		require(generic_req.valid == 13);
		require(generic_req.number == 321);
		require(generic_req.args[0] == 10);
		require(generic_req.args[1] == 20);
		require(generic_req.args[2] == 30);
		require(generic_req.args[3] == 40);
		require(generic_req.args[4] == 50);
		require(generic_req.args[5] == 60);
		require(syscall_generic_forwarding_body_result(NULL, 1,
			2, 3, 4, 5, 6, 7, 8,
			fake_generic_syscall) == -22);
		require(syscall_generic_forwarding_body_result(&generic_req, 1,
			2, 3, 4, 5, 6, 7, 8, NULL) == -22);
		mix_signed(&digest, rc);
		mix_signed(&digest, fake_generic_syscall_calls);
		mix_signed(&digest, fake_generic_syscall_cpu);
		mix_signed(&digest, generic_req.rtid);
		mix_signed(&digest, generic_req.ttid);
		mix(&digest, generic_req.valid);
		mix(&digest, generic_req.number);
		mix(&digest, generic_req.args[0]);
		mix(&digest, generic_req.args[5]);
	}
	{
		struct fake_syscall_request completed_req = {
			.rtid = 1,
			.ttid = 2,
			.valid = 3,
			.number = 39,
			.args = { 4, 5, 6, 7, 8, 9 },
		};
		struct fake_syscall_response completed_res = {
			.ttid = 10,
			.stid = 11,
			.status = 1,
			.req_thread_status = 12,
			.ret = 13,
			.fault_address = 14,
			.pde_data = (void *)0x1234,
		};
		struct fake_syscall_request before_req = completed_req;
		struct fake_syscall_response before_res = completed_res;
		struct {
			unsigned char bytes[5568];
		} __attribute__((aligned(64))) thread_storage = { { 0 } };

		syscall_offload_wait_reply(&completed_req, &completed_res, 7,
			&thread_storage);
		require(memcmp(&completed_req, &before_req, sizeof(completed_req)) == 0);
		require(memcmp(&completed_res, &before_res, sizeof(completed_res)) == 0);
		mix(&digest, completed_res.status);
		mix_signed(&digest, completed_res.ret);
	}
	{
		struct fake_ikc_scd_packet packet = {
			.header = { .channel = (void *)0x1111 },
			.msg = -1,
			.err = -2,
			.reply = (void *)0x2222,
			.ref = -3,
			.osnum = -4,
			.pid = -5,
			.arg = 0x3333,
			.req = {
				.rtid = 31,
				.ttid = 32,
				.valid = 33,
				.number = 34,
				.args = { 35, 36, 37, 38, 39, 40 },
			},
			.resp_pa = 0x4444,
		};

		require(syscall_packet_traditional_prepare_result(&packet,
			SCD_MSG_SYSCALL_ONESIDE, 41, 42, 0x5555) == 0);
		require(packet.msg == SCD_MSG_SYSCALL_ONESIDE);
		require(packet.ref == 41);
		require(packet.pid == 42);
		require(packet.resp_pa == 0x5555);
		require(packet.err == -2);
		require(packet.reply == (void *)0x2222);
		require(packet.osnum == -4);
		require(packet.arg == 0x3333);
		require(packet.req.rtid == 31);
		require(packet.req.args[5] == 40);
		require(syscall_packet_traditional_prepare_result(NULL,
			SCD_MSG_SYSCALL_ONESIDE, 1, 2, 3) == -22);
		mix_signed(&digest, packet.msg);
		mix_signed(&digest, packet.ref);
		mix_signed(&digest, packet.pid);
		mix(&digest, packet.resp_pa);
	}
	{
		struct fake_ikc_scd_packet packet = {
			.header = { .channel = (void *)0x1111 },
			.msg = -1,
			.err = -2,
			.reply = (void *)0x2222,
			.eventfd_type = -3,
		};

		require(syscall_eventfd_packet_prepare_result(&packet,
			SCD_MSG_EVENTFD, 77) == 0);
		require(packet.header.channel == NULL);
		require(packet.msg == SCD_MSG_EVENTFD);
		require(packet.err == 0);
		require(packet.reply == NULL);
		require(packet.eventfd_type == 77);
		require(packet.resp == NULL);
		require(syscall_eventfd_packet_prepare_result(NULL,
			SCD_MSG_EVENTFD, 1) == -22);
		mix_signed(&digest, packet.msg);
		mix_signed(&digest, packet.eventfd_type);
		mix_signed(&digest, packet.err);
	}
	{
		reset_fake_eventfd_send();
		fake_eventfd_send_rc = -31;
		require(syscall_eventfd_send_result((void *)0xcafe,
			SCD_MSG_EVENTFD, 88, fake_eventfd_send) == -31);
		require(fake_eventfd_send_calls == 1);
		require(fake_eventfd_send_channel == (void *)0xcafe);
		require(fake_eventfd_send_opt == 0);
		require(fake_eventfd_send_packet.header.channel == NULL);
		require(fake_eventfd_send_packet.msg == SCD_MSG_EVENTFD);
		require(fake_eventfd_send_packet.err == 0);
		require(fake_eventfd_send_packet.reply == NULL);
		require(fake_eventfd_send_packet.eventfd_type == 88);
		require(fake_eventfd_send_packet.resp == NULL);
		require(syscall_eventfd_send_result(NULL, SCD_MSG_EVENTFD,
			99, fake_eventfd_send) == -31);
		require(fake_eventfd_send_channel == NULL);
		require(syscall_eventfd_send_result((void *)0xcafe,
			SCD_MSG_EVENTFD, 1, NULL) == -22);
		mix_signed(&digest, fake_eventfd_send_calls);
		mix_signed(&digest, fake_eventfd_send_packet.msg);
		mix_signed(&digest, fake_eventfd_send_packet.eventfd_type);
		mix_signed(&digest, fake_eventfd_send_opt);
	}
	{
		int last_pid = -1;
		int log_count = 0;

		require(syscall_log_budget_result(100, &last_pid,
			&log_count, 2) == 1);
		require(last_pid == 100);
		require(log_count == 1);
		require(syscall_log_budget_result(100, &last_pid,
			&log_count, 2) == 1);
		require(log_count == 2);
		require(syscall_log_budget_result(100, &last_pid,
			&log_count, 2) == 0);
		require(log_count == 2);
		require(syscall_log_budget_result(101, &last_pid,
			&log_count, 2) == 1);
		require(last_pid == 101);
		require(log_count == 1);
		require(syscall_log_budget_result(102, &last_pid,
			&log_count, 0) == 0);
		require(last_pid == 102);
		require(log_count == 0);
		require(syscall_log_budget_result(103, NULL,
			&log_count, 2) == -22);
		require(syscall_log_budget_result(103, &last_pid,
			NULL, 2) == -22);
		mix_signed(&digest, last_pid);
		mix_signed(&digest, log_count);
	}
	{
		require(syscall_reject_after_exit_result(PS_EXITED,
			1, 60, 231) == 1);
		require(syscall_reject_after_exit_result(PS_EXITED,
			60, 60, 231) == 0);
		require(syscall_reject_after_exit_result(PS_EXITED,
			231, 60, 231) == 0);
		require(syscall_reject_after_exit_result(0,
			1, 60, 231) == 0);
		mix_signed(&digest, syscall_reject_after_exit_result(
			PS_EXITED, 1, 60, 231));
		mix_signed(&digest, syscall_reject_after_exit_result(
			PS_EXITED, 60, 60, 231));
	}
	require(syscall_offload_spin_without_schedule_result(1, 123) == 1);
	require(syscall_offload_spin_without_schedule_result(-1, 123) == 1);
	require(syscall_offload_spin_without_schedule_result(0, 0) == 1);
	require(syscall_offload_spin_without_schedule_result(0, 123) == 0);
	mix_signed(&digest, syscall_offload_spin_without_schedule_result(1, 123));
	mix_signed(&digest, syscall_offload_spin_without_schedule_result(0, 0));
	mix_signed(&digest, syscall_offload_spin_without_schedule_result(0, 123));
	{
		struct fake_syscall_request offload_req = {
			.rtid = -1,
			.ttid = -2,
			.valid = 55,
			.number = 203,
			.args = { 0, 11, 12, 13, 14, 15 },
		};
		struct fake_syscall_response offload_res = {
			.ttid = -3,
			.stid = -4,
			.status = 44,
			.req_thread_status = 45,
			.ret = -46,
			.fault_address = 47,
			.pde_data = (void *)0x1234,
		};

		require(syscall_offload_prepare_result(&offload_req,
			&offload_res, 4321, 203, offload_req.args[0],
			203, 7) == 1);
		require(offload_req.rtid == 4321);
		require(offload_req.ttid == 4321);
		require(offload_req.valid == 55);
		require(offload_res.req_thread_status == 7);
		require(offload_res.pde_data == NULL);
		mix_signed(&digest, offload_req.rtid);
		mix_signed(&digest, offload_req.ttid);
		mix(&digest, offload_res.req_thread_status);

		offload_req.args[0] = 99;
		offload_req.rtid = -1;
		offload_req.ttid = -2;
		offload_res.pde_data = (void *)0x5678;
		require(syscall_offload_prepare_result(&offload_req,
			&offload_res, 4321, 203, offload_req.args[0],
			203, 8) == 0);
		require(offload_req.rtid == 4321);
		require(offload_req.ttid == 0);
		require(offload_res.req_thread_status == 8);
		require(offload_res.pde_data == NULL);
		require(syscall_offload_prepare_result(NULL,
			&offload_res, 1, 2, 3, 4, 5) == -22);
		require(syscall_offload_prepare_result(&offload_req,
			NULL, 1, 2, 3, 4, 5) == -22);
		mix_signed(&digest, offload_req.ttid);
		mix(&digest, offload_res.req_thread_status);
	}
	require(syscall_offload_counted_result(230, 231) == 1);
	require(syscall_offload_counted_result(231, 231) == 0);
	require(syscall_offload_counted_result(-1, -1) == 0);
	require(syscall_nested_dispatch_valid_result(0, 4, 1) == 1);
	require(syscall_nested_dispatch_valid_result(-1, 4, 1) == 0);
	require(syscall_nested_dispatch_valid_result(4, 4, 1) == 0);
	require(syscall_nested_dispatch_valid_result(2, 4, 0) == 0);
	require(syscall_nested_rt_sigaction_index_result(1, 64) == 0);
	require(syscall_nested_rt_sigaction_index_result(64, 64) == 63);
	require(syscall_nested_rt_sigaction_index_result(0, 64) == -22);
	require(syscall_nested_rt_sigaction_index_result(65, 64) == -22);
	require(syscall_nested_rt_sigaction_index_result(1, 0) == -22);
	require(syscall_tofu_post_reply_candidate_result(16, 0, 16, 257) == 1);
	require(syscall_tofu_post_reply_candidate_result(16, 1, 16, 257) == 0);
	require(syscall_tofu_post_reply_candidate_result(257, 1, 16, 257) == 1);
	require(syscall_tofu_post_reply_candidate_result(257, 0, 16, 257) == 0);
	require(syscall_tofu_post_reply_candidate_result(1, 1, 16, 257) == 0);
	require(syscall_profile_event_needed_result(0, 512) == 1);
	require(syscall_profile_event_needed_result(511, 512) == 1);
	require(syscall_profile_event_needed_result(512, 512) == 0);
	require(syscall_profile_event_needed_result(-1, 512) == 1);
	require(syscall_profile_event_needed_result(0, 0) == 0);
	{
		struct fake_syscall_request response_req = {
			.rtid = -1,
			.ttid = -2,
			.valid = 77,
			.number = 88,
			.args = { 101, 102, 103, 104, 105, 106 },
		};
		struct fake_syscall_response response_res = {
			.ttid = -3,
			.stid = -4,
			.status = 90,
			.req_thread_status = 91,
			.ret = -92,
			.fault_address = 93,
			.pde_data = (void *)0x5678,
		};

		require(syscall_nested_response_prepare_result(&response_req,
			&response_res, 8001, (unsigned long)-38,
			1234, 5678, 9) == 0);
		require(response_req.rtid == 1234);
		require(response_req.ttid == 5678);
		require(response_req.valid == 77);
		require(response_req.number == 8001);
		require(response_req.args[0] == 101);
		require(response_req.args[1] == (unsigned long)-38);
		require(response_req.args[2] == 103);
		require(response_res.status == 90);
		require(response_res.req_thread_status == 9);
		require(response_res.pde_data == (void *)0x5678);
		require(syscall_nested_response_prepare_result(NULL,
			&response_res, 8001, 1, 2, 3, 4) == -22);
		require(syscall_nested_response_prepare_result(&response_req,
			NULL, 8001, 1, 2, 3, 4) == -22);
		mix_signed(&digest, response_req.rtid);
		mix_signed(&digest, response_req.ttid);
		mix(&digest, response_req.number);
		mix(&digest, response_req.args[1]);
		mix(&digest, response_res.req_thread_status);
	}
	mix_signed(&digest, syscall_target_tid_result(1, 1234));
	mix_signed(&digest, syscall_target_tid_result(0, 1234));
	mix_signed(&digest, syscall_offload_counted_result(230, 231));
	mix_signed(&digest, syscall_offload_counted_result(231, 231));
	mix_signed(&digest, syscall_nested_dispatch_valid_result(0, 4, 1));
	mix_signed(&digest, syscall_nested_dispatch_valid_result(4, 4, 1));
	mix_signed(&digest, syscall_nested_rt_sigaction_index_result(1, 64));
	mix_signed(&digest, syscall_nested_rt_sigaction_index_result(65, 64));
	mix_signed(&digest, syscall_tofu_post_reply_candidate_result(
		16, 0, 16, 257));
	mix_signed(&digest, syscall_tofu_post_reply_candidate_result(
		257, 1, 16, 257));
	mix_signed(&digest, syscall_profile_event_needed_result(511, 512));
	mix_signed(&digest, syscall_profile_event_needed_result(512, 512));
	mix_signed(&digest, syscall_profile_event_needed_result(-1, 512));
	for (unsigned int i = 0; i < sizeof(rtids) / sizeof(rtids[0]); i++)
		mix_signed(&digest, syscall_preempt_disable_needed_result(rtids[i]));
	require(syscall_proxy_dead_result(-512) == 1);
	require(syscall_proxy_dead_result(-511) == 0);
	require(syscall_proxy_dead_result(0) == 0);
	require(syscall_proxy_dead_result(512) == 0);
	mix_signed(&digest, syscall_proxy_dead_result(-512));
	mix_signed(&digest, syscall_proxy_dead_result(-511));

	for (unsigned int i = 0; i < sizeof(flags) / sizeof(flags[0]); i++) {
		mix_signed(&digest, memlock_range_flag_result(flags[i]));
		mix_signed(&digest, range_has_disallowed_change_flags(flags[i]));
		for (unsigned int p = 0; p < sizeof(flags) / sizeof(flags[0]); p++)
			mix_signed(&digest, mprotect_write_changed_result(
				flags[i], flags[p]));
	}

	exercise_memlock(&digest);
	exercise_unmap_protect(&digest);
	exercise_memory_syscall_policy(&digest);
	exercise_brk_mincore_mmap_policy(&digest);
	exercise_signal_time_policy(&digest);
	exercise_signal_wait_policy(&digest);
	exercise_ptrace_process_vm_policy(&digest);
	exercise_wait_policy(&digest);
	exercise_clone_exec_futex_policy(&digest);

	printf("syscall_policy_helpers ok digest=%016lx\n", digest);
	return 0;
}
