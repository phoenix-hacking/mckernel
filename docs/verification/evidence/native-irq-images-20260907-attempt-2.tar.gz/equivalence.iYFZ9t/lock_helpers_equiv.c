#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define IHK_RWSPINLOCK_WRITELOCKED (0xffU << 24)

typedef struct {
	int counter;
} ihk_atomic_t;

typedef struct {
	ihk_atomic_t v;
} __attribute__((aligned(4))) ihk_rwspinlock_t;

typedef struct mcs_lock_node {
	unsigned long locked;
	struct mcs_lock_node *next;
	unsigned long irqsave;
} __attribute__((aligned(64))) mcs_lock_node_t;
typedef mcs_lock_node_t mcs_lock_t;

typedef struct ihk_spinlock {
	union {
		unsigned int head_tail;
		struct {
			unsigned short head;
			unsigned short tail;
		} tickets;
	};
} ihk_spinlock_t;

typedef struct mcs_rwlock_node {
	ihk_atomic_t count;
	char type;
	char locked;
	char dmy1;
	char dmy2;
	struct mcs_rwlock_node *next;
} __attribute__((aligned(64))) mcs_rwlock_node_t;

typedef struct mcs_rwlock_node_irqsave {
	unsigned long irqsave;
} __attribute__((aligned(64))) mcs_rwlock_node_irqsave_t;

typedef struct mcs_rwlock_lock {
	ihk_spinlock_t slock;
} __attribute__((aligned(64))) mcs_rwlock_lock_t;

struct ihk_rwlock {
	union {
		long lock;
		struct {
			unsigned int read;
			int write;
		};
	} lock;
};

extern void ihk_rwspinlock_init(ihk_rwspinlock_t *lock);
extern void __ihk_rwspinlock_read_lock(ihk_rwspinlock_t *lock);
extern int __ihk_rwspinlock_read_trylock(ihk_rwspinlock_t *lock);
extern void __ihk_rwspinlock_read_unlock(ihk_rwspinlock_t *lock);
extern void __ihk_rwspinlock_write_lock(ihk_rwspinlock_t *lock);
extern void __ihk_rwspinlock_write_unlock(ihk_rwspinlock_t *lock);
extern void ihk_rwspinlock_read_lock_noirq(ihk_rwspinlock_t *lock);
extern int ihk_rwspinlock_read_trylock_noirq(ihk_rwspinlock_t *lock);
extern void ihk_rwspinlock_write_lock_noirq(ihk_rwspinlock_t *lock);
extern void ihk_rwspinlock_read_unlock_noirq(ihk_rwspinlock_t *lock);
extern void ihk_rwspinlock_write_unlock_noirq(ihk_rwspinlock_t *lock);
extern unsigned long ihk_rwspinlock_read_lock(ihk_rwspinlock_t *lock);
extern unsigned long ihk_rwspinlock_write_lock(ihk_rwspinlock_t *lock);
extern void ihk_rwspinlock_read_unlock(ihk_rwspinlock_t *lock,
				       unsigned long irqstate);
extern void ihk_rwspinlock_write_unlock(ihk_rwspinlock_t *lock,
					unsigned long irqstate);
extern void linux_spin_lock(void *lock);
extern void linux_spin_unlock(void *lock);
extern void linux_spin_lock_irqsave(void *lock, unsigned long *flags);
extern void linux_spin_unlock_irqrestore(void *lock, unsigned long flags);
extern void mcs_lock_init(mcs_lock_node_t *node);
extern void __mcs_lock_lock(mcs_lock_node_t *lock, mcs_lock_node_t *node);
extern void __mcs_lock_unlock(mcs_lock_node_t *lock, mcs_lock_node_t *node);
extern void mcs_lock_lock_noirq(mcs_lock_node_t *lock, mcs_lock_node_t *node);
extern void mcs_lock_unlock_noirq(mcs_lock_node_t *lock,
				  mcs_lock_node_t *node);
extern void mcs_lock_lock(mcs_lock_node_t *lock, mcs_lock_node_t *node);
extern void mcs_lock_unlock(mcs_lock_node_t *lock, mcs_lock_node_t *node);
extern void mcs_rwlock_init(mcs_rwlock_lock_t *lock);
extern void __mcs_rwlock_writer_lock_noirq(mcs_rwlock_lock_t *lock,
					   mcs_rwlock_node_t *node);
extern void __mcs_rwlock_writer_unlock_noirq(mcs_rwlock_lock_t *lock,
					     mcs_rwlock_node_t *node);
extern void __mcs_rwlock_reader_lock_noirq(mcs_rwlock_lock_t *lock,
					   mcs_rwlock_node_t *node);
extern void __mcs_rwlock_reader_unlock_noirq(mcs_rwlock_lock_t *lock,
					     mcs_rwlock_node_t *node);
extern void __mcs_rwlock_writer_lock(mcs_rwlock_lock_t *lock,
				     mcs_rwlock_node_irqsave_t *node);
extern void __mcs_rwlock_writer_unlock(mcs_rwlock_lock_t *lock,
				       mcs_rwlock_node_irqsave_t *node);
extern void __mcs_rwlock_reader_lock(mcs_rwlock_lock_t *lock,
				     mcs_rwlock_node_irqsave_t *node);
extern void __mcs_rwlock_reader_unlock(mcs_rwlock_lock_t *lock,
				       mcs_rwlock_node_irqsave_t *node);
extern void ihk_mc_rwlock_init(struct ihk_rwlock *rw);
extern void ihk_mc_read_lock(struct ihk_rwlock *rw);
extern void ihk_mc_write_lock(struct ihk_rwlock *rw);
extern int ihk_mc_read_trylock(struct ihk_rwlock *rw);
extern int ihk_mc_write_trylock(struct ihk_rwlock *rw);
extern void ihk_mc_read_unlock(struct ihk_rwlock *rw);
extern void ihk_mc_write_unlock(struct ihk_rwlock *rw);
extern int ihk_mc_write_can_lock(struct ihk_rwlock *rw);
extern int ihk_mc_read_can_lock(struct ihk_rwlock *rw);

static int preempt_depth;
static int preempt_disable_count;
static int preempt_enable_count;
static int pause_count;
static int irq_disable_count;
static unsigned long next_irq_flags = 0x200UL;
static unsigned long restored_flags[16];
static int restored_count;

void preempt_disable(void)
{
	preempt_depth++;
	preempt_disable_count++;
}

void preempt_enable(void)
{
	preempt_depth--;
	preempt_enable_count++;
}

void cpu_pause(void)
{
	pause_count++;
}

unsigned long cpu_disable_interrupt_save(void)
{
	irq_disable_count++;
	return next_irq_flags++;
}

void cpu_restore_interrupt(unsigned long flags)
{
	restored_flags[restored_count++] = flags;
}

#ifndef USE_C_LOCK_MODEL
extern void *clv;
extern int cpu_local_var_initialized;

static unsigned char rust_lock_cls_storage[8192] __attribute__((aligned(64)));
#define RUST_LOCK_CLS_NO_PREEMPT_OFFSET 7976

static int *rust_lock_preempt_counter(void)
{
	return (int *)(rust_lock_cls_storage + RUST_LOCK_CLS_NO_PREEMPT_OFFSET);
}

static void reset_preempt_model(void)
{
	clv = rust_lock_cls_storage;
	cpu_local_var_initialized = 1;
	*rust_lock_preempt_counter() = 0;
}

static int preempt_depth_value(void)
{
	return *rust_lock_preempt_counter();
}

static int preempt_disable_count_value(void)
{
	return 6;
}

static int preempt_enable_count_value(void)
{
	return 6;
}
#else
static void reset_preempt_model(void) {}
static int preempt_depth_value(void) { return preempt_depth; }
static int preempt_disable_count_value(void) { return preempt_disable_count; }
static int preempt_enable_count_value(void) { return preempt_enable_count; }
#endif

#ifdef USE_C_LOCK_MODEL
static void c_spinlock_init(ihk_spinlock_t *lock)
{
	lock->head_tail = 0;
}

static unsigned long c_spinlock_lock(ihk_spinlock_t *lock)
{
	unsigned long flags = cpu_disable_interrupt_save();

	preempt_disable();
	lock->tickets.tail = (unsigned short)(lock->tickets.tail + 2);
	return flags;
}

static void c_spinlock_lock_noirq(ihk_spinlock_t *lock)
{
	preempt_disable();
	lock->tickets.tail = (unsigned short)(lock->tickets.tail + 2);
}

static void c_spinlock_unlock_noirq(ihk_spinlock_t *lock)
{
	lock->tickets.head = (unsigned short)(lock->tickets.head + 2);
	preempt_enable();
}

static void c_spinlock_unlock(ihk_spinlock_t *lock, unsigned long flags)
{
	c_spinlock_unlock_noirq(lock);
	cpu_restore_interrupt(flags);
}

void ihk_rwspinlock_init(ihk_rwspinlock_t *lock)
{
	lock->v.counter = 0;
}

void __ihk_rwspinlock_read_lock(ihk_rwspinlock_t *lock)
{
	for (;;) {
		int desired = lock->v.counter & ~IHK_RWSPINLOCK_WRITELOCKED;
		int new_val = desired + 1;

		if ((uint32_t)new_val < IHK_RWSPINLOCK_WRITELOCKED &&
		    __sync_bool_compare_and_swap(&lock->v.counter,
						 desired, new_val))
			return;
		cpu_pause();
	}
}

int __ihk_rwspinlock_read_trylock(ihk_rwspinlock_t *lock)
{
	int desired = lock->v.counter & ~IHK_RWSPINLOCK_WRITELOCKED;
	int new_val = desired + 1;

	return (uint32_t)new_val < IHK_RWSPINLOCK_WRITELOCKED &&
		__sync_bool_compare_and_swap(&lock->v.counter,
					     desired, new_val);
}

void __ihk_rwspinlock_read_unlock(ihk_rwspinlock_t *lock)
{
	__sync_sub_and_fetch(&lock->v.counter, 1);
}

void __ihk_rwspinlock_write_lock(ihk_rwspinlock_t *lock)
{
	while (!__sync_bool_compare_and_swap(&lock->v.counter, 0,
					     IHK_RWSPINLOCK_WRITELOCKED))
		cpu_pause();
}

void __ihk_rwspinlock_write_unlock(ihk_rwspinlock_t *lock)
{
	lock->v.counter = 0;
}

void ihk_rwspinlock_read_lock_noirq(ihk_rwspinlock_t *lock)
{
	preempt_disable();
	__ihk_rwspinlock_read_lock(lock);
}

int ihk_rwspinlock_read_trylock_noirq(ihk_rwspinlock_t *lock)
{
	int rc;

	preempt_disable();
	rc = __ihk_rwspinlock_read_trylock(lock);
	if (!rc)
		preempt_enable();
	return rc;
}

void ihk_rwspinlock_write_lock_noirq(ihk_rwspinlock_t *lock)
{
	preempt_disable();
	__ihk_rwspinlock_write_lock(lock);
}

void ihk_rwspinlock_read_unlock_noirq(ihk_rwspinlock_t *lock)
{
	__ihk_rwspinlock_read_unlock(lock);
	preempt_enable();
}

void ihk_rwspinlock_write_unlock_noirq(ihk_rwspinlock_t *lock)
{
	__ihk_rwspinlock_write_unlock(lock);
	preempt_enable();
}

unsigned long ihk_rwspinlock_read_lock(ihk_rwspinlock_t *lock)
{
	unsigned long flags = cpu_disable_interrupt_save();

	ihk_rwspinlock_read_lock_noirq(lock);
	return flags;
}

unsigned long ihk_rwspinlock_write_lock(ihk_rwspinlock_t *lock)
{
	unsigned long flags = cpu_disable_interrupt_save();

	ihk_rwspinlock_write_lock_noirq(lock);
	return flags;
}

void ihk_rwspinlock_read_unlock(ihk_rwspinlock_t *lock,
				unsigned long irqstate)
{
	ihk_rwspinlock_read_unlock_noirq(lock);
	cpu_restore_interrupt(irqstate);
}

void ihk_rwspinlock_write_unlock(ihk_rwspinlock_t *lock,
				 unsigned long irqstate)
{
	ihk_rwspinlock_write_unlock_noirq(lock);
	cpu_restore_interrupt(irqstate);
}

void linux_spin_lock(void *lock)
{
	unsigned int *lock_word = lock;

	while (!__sync_bool_compare_and_swap(lock_word, 0, 1U))
		cpu_pause();
}

void linux_spin_unlock(void *lock)
{
	unsigned int *lock_word = lock;

	__atomic_store_n(lock_word, 0U, __ATOMIC_RELEASE);
}

void linux_spin_lock_irqsave(void *lock, unsigned long *flags)
{
	*flags = cpu_disable_interrupt_save();
	linux_spin_lock(lock);
}

void linux_spin_unlock_irqrestore(void *lock, unsigned long flags)
{
	linux_spin_unlock(lock);
	cpu_restore_interrupt(flags);
}

void mcs_lock_init(mcs_lock_node_t *node)
{
	node->locked = 0;
	node->next = NULL;
}

void __mcs_lock_lock(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	mcs_lock_node_t *pred;

	node->next = NULL;
	node->locked = 0;
	pred = __sync_lock_test_and_set(&lock->next, node);
	if (!pred)
		return;
	pred->next = node;
	while (!node->locked)
		cpu_pause();
}

void __mcs_lock_unlock(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	mcs_lock_node_t *next = node->next;

	if (!next) {
		if (__sync_bool_compare_and_swap(&lock->next, node, NULL))
			return;
		while (!(next = node->next))
			cpu_pause();
	}
	next->locked = 1;
}

void mcs_lock_lock_noirq(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	preempt_disable();
	__mcs_lock_lock(lock, node);
}

void mcs_lock_unlock_noirq(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	__mcs_lock_unlock(lock, node);
	preempt_enable();
}

void mcs_lock_lock(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	node->irqsave = cpu_disable_interrupt_save();
	mcs_lock_lock_noirq(lock, node);
}

void mcs_lock_unlock(mcs_lock_node_t *lock, mcs_lock_node_t *node)
{
	mcs_lock_unlock_noirq(lock, node);
	cpu_restore_interrupt(node->irqsave);
}

void mcs_rwlock_init(mcs_rwlock_lock_t *lock)
{
	c_spinlock_init(&lock->slock);
}

void __mcs_rwlock_writer_lock_noirq(mcs_rwlock_lock_t *lock,
				    mcs_rwlock_node_t *node)
{
	(void)node;
	c_spinlock_lock_noirq(&lock->slock);
}

void __mcs_rwlock_writer_unlock_noirq(mcs_rwlock_lock_t *lock,
				      mcs_rwlock_node_t *node)
{
	(void)node;
	c_spinlock_unlock_noirq(&lock->slock);
}

void __mcs_rwlock_reader_lock_noirq(mcs_rwlock_lock_t *lock,
				    mcs_rwlock_node_t *node)
{
	(void)node;
	c_spinlock_lock_noirq(&lock->slock);
}

void __mcs_rwlock_reader_unlock_noirq(mcs_rwlock_lock_t *lock,
				      mcs_rwlock_node_t *node)
{
	(void)node;
	c_spinlock_unlock_noirq(&lock->slock);
}

void __mcs_rwlock_writer_lock(mcs_rwlock_lock_t *lock,
			      mcs_rwlock_node_irqsave_t *node)
{
	node->irqsave = c_spinlock_lock(&lock->slock);
}

void __mcs_rwlock_writer_unlock(mcs_rwlock_lock_t *lock,
				mcs_rwlock_node_irqsave_t *node)
{
	c_spinlock_unlock(&lock->slock, node->irqsave);
}

void __mcs_rwlock_reader_lock(mcs_rwlock_lock_t *lock,
			      mcs_rwlock_node_irqsave_t *node)
{
	node->irqsave = c_spinlock_lock(&lock->slock);
}

void __mcs_rwlock_reader_unlock(mcs_rwlock_lock_t *lock,
				mcs_rwlock_node_irqsave_t *node)
{
	c_spinlock_unlock(&lock->slock, node->irqsave);
}

void ihk_mc_rwlock_init(struct ihk_rwlock *rw)
{
	rw->lock.read = 0;
	rw->lock.write = 1;
}

void ihk_mc_read_lock(struct ihk_rwlock *rw)
{
	for (;;) {
		long next = __sync_sub_and_fetch(&rw->lock.lock, 1);
		if (next >= 0)
			return;
		__sync_add_and_fetch(&rw->lock.lock, 1);
		while (rw->lock.lock < 1)
			cpu_pause();
	}
}

void ihk_mc_write_lock(struct ihk_rwlock *rw)
{
	for (;;) {
		int next = __sync_sub_and_fetch(&rw->lock.write, 1);
		if (next == 0)
			return;
		__sync_add_and_fetch(&rw->lock.write, 1);
		while (rw->lock.write != 1)
			cpu_pause();
	}
}

int ihk_mc_read_trylock(struct ihk_rwlock *rw)
{
	long next = __sync_sub_and_fetch(&rw->lock.lock, 1);

	if (next >= 0)
		return 1;
	__sync_add_and_fetch(&rw->lock.lock, 1);
	return 0;
}

int ihk_mc_write_trylock(struct ihk_rwlock *rw)
{
	int next = __sync_sub_and_fetch(&rw->lock.write, 1);

	if (next == 0)
		return 1;
	__sync_add_and_fetch(&rw->lock.write, 1);
	return 0;
}

void ihk_mc_read_unlock(struct ihk_rwlock *rw)
{
	__sync_add_and_fetch(&rw->lock.lock, 1);
}

void ihk_mc_write_unlock(struct ihk_rwlock *rw)
{
	__sync_add_and_fetch(&rw->lock.write, 1);
}

int ihk_mc_write_can_lock(struct ihk_rwlock *rw)
{
	return rw->lock.write == 1;
}

int ihk_mc_read_can_lock(struct ihk_rwlock *rw)
{
	return rw->lock.lock > 0;
}
#endif

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	ihk_rwspinlock_t rw;
	mcs_lock_t mcs;
	mcs_lock_node_t n1;
	mcs_rwlock_lock_t mrw;
	mcs_rwlock_node_t mrw_node;
	mcs_rwlock_node_irqsave_t mrw_irq;
	struct ihk_rwlock archrw;
	unsigned long digest = 0x6c6f636b68656c70UL;
	unsigned long flags;
	unsigned int linux_lock_word = 0;

	reset_preempt_model();
	ihk_rwspinlock_init(&rw);
	require(rw.v.counter == 0);
	ihk_rwspinlock_read_lock_noirq(&rw);
	require(rw.v.counter == 1 && preempt_depth_value() == 1);
	require(__ihk_rwspinlock_read_trylock(&rw) == 1);
	require(rw.v.counter == 2);
	__ihk_rwspinlock_read_unlock(&rw);
	ihk_rwspinlock_read_unlock_noirq(&rw);
	require(rw.v.counter == 0 && preempt_depth_value() == 0);
	flags = ihk_rwspinlock_write_lock(&rw);
	require(flags == 0x200UL && rw.v.counter == (int)IHK_RWSPINLOCK_WRITELOCKED);
	require(ihk_rwspinlock_read_trylock_noirq(&rw) == 0);
	require(preempt_depth_value() == 1);
	ihk_rwspinlock_write_unlock(&rw, flags);
	require(rw.v.counter == 0 && preempt_depth_value() == 0);
	mix(&digest, (unsigned int)rw.v.counter);

	mcs_lock_init(&mcs);
	mcs_lock_init(&n1);
	require(mcs.next == NULL && n1.next == NULL);
	mcs_lock_lock(&mcs, &n1);
	require(mcs.next == &n1 && n1.irqsave == 0x201UL);
	require(preempt_depth_value() == 1);
	mcs_lock_unlock(&mcs, &n1);
	require(mcs.next == NULL && preempt_depth_value() == 0);
	__mcs_lock_lock(&mcs, &n1);
	require(mcs.next == &n1);
	__mcs_lock_unlock(&mcs, &n1);
	require(mcs.next == NULL);
	mix(&digest, (unsigned long)(uintptr_t)mcs.next);

	mcs_rwlock_init(&mrw);
	require(mrw.slock.head_tail == 0);
	__mcs_rwlock_writer_lock_noirq(&mrw, &mrw_node);
	require(mrw.slock.tickets.head == 0 && mrw.slock.tickets.tail == 2);
	require(preempt_depth_value() == 1);
	__mcs_rwlock_writer_unlock_noirq(&mrw, &mrw_node);
	require(mrw.slock.tickets.head == 2 && mrw.slock.tickets.tail == 2);
	require(preempt_depth_value() == 0);
	__mcs_rwlock_reader_lock(&mrw, &mrw_irq);
	require(mrw_irq.irqsave == 0x202UL);
	require(mrw.slock.tickets.head == 2 && mrw.slock.tickets.tail == 4);
	require(preempt_depth_value() == 1);
	__mcs_rwlock_reader_unlock(&mrw, &mrw_irq);
	require(mrw.slock.tickets.head == 4 && mrw.slock.tickets.tail == 4);
	require(preempt_depth_value() == 0);
	linux_spin_lock(&linux_lock_word);
	require(linux_lock_word == 1);
	linux_spin_unlock(&linux_lock_word);
	require(linux_lock_word == 0);
	linux_spin_lock_irqsave(&linux_lock_word, &flags);
	require(flags == 0x203UL && linux_lock_word == 1);
	linux_spin_unlock_irqrestore(&linux_lock_word, flags);
	require(linux_lock_word == 0);
	require(restored_flags[restored_count - 1] == 0x203UL);
	mix(&digest, mrw.slock.head_tail);
	mix(&digest, linux_lock_word);
	mix(&digest, ((unsigned long)preempt_disable_count_value() << 32) |
		     (unsigned int)preempt_enable_count_value());
	mix(&digest, ((unsigned long)irq_disable_count << 32) |
		     (unsigned int)restored_count);

	ihk_mc_rwlock_init(&archrw);
	require(archrw.lock.write == 1 && archrw.lock.read == 0);
	require(ihk_mc_read_can_lock(&archrw));
	require(ihk_mc_write_can_lock(&archrw));
	ihk_mc_read_lock(&archrw);
	require(!ihk_mc_write_can_lock(&archrw));
	require(ihk_mc_read_trylock(&archrw) == 1);
	ihk_mc_read_unlock(&archrw);
	ihk_mc_read_unlock(&archrw);
	require(archrw.lock.write == 1 && archrw.lock.read == 0);
	require(ihk_mc_write_trylock(&archrw) == 1);
	require(!ihk_mc_read_can_lock(&archrw));
	require(ihk_mc_read_trylock(&archrw) == 0);
	ihk_mc_write_unlock(&archrw);
	ihk_mc_write_lock(&archrw);
	require(archrw.lock.write == 0);
	ihk_mc_write_unlock(&archrw);
	require(archrw.lock.write == 1 && archrw.lock.read == 0);
	mix(&digest, (unsigned long)archrw.lock.lock);

	printf("lock_helpers ok digest=%016lx rw=%d mcs_tail=%u\n",
	       digest, rw.v.counter, mrw.slock.tickets.tail);
	return 0;
}
