#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct ihk_spinlock {
	union {
		unsigned int head_tail;
		struct {
			unsigned short head;
			unsigned short tail;
		} tickets;
	};
} ihk_spinlock_t;

extern void ihk_mc_spinlock_init(ihk_spinlock_t *lock);
extern int __ihk_mc_spinlock_trylock_noirq(ihk_spinlock_t *lock);
extern unsigned long __ihk_mc_spinlock_trylock(ihk_spinlock_t *lock,
					       int *result);
extern void __ihk_mc_spinlock_lock_noirq(ihk_spinlock_t *lock);
extern unsigned long __ihk_mc_spinlock_lock(ihk_spinlock_t *lock);
extern void __ihk_mc_spinlock_unlock_noirq(ihk_spinlock_t *lock);
extern void __ihk_mc_spinlock_unlock(ihk_spinlock_t *lock,
				     unsigned long flags);
extern int irqflags_can_interrupt(unsigned long flags);

static int preempt_depth;
static int preempt_disable_count;
static int preempt_enable_count;
static int pause_count;
static int irq_disable_count;
static unsigned long next_irq_flags = 0x100UL;
static unsigned long restored_flags[8];
static int restored_count;

void preempt_disable(void)
{
	preempt_depth++;
	preempt_disable_count++;
}

void preempt_enable(void)
{
	preempt_depth--;
	preempt_enable_count++;
}

void cpu_pause(void)
{
	pause_count++;
}

unsigned long cpu_disable_interrupt_save(void)
{
	irq_disable_count++;
	return next_irq_flags++;
}

void cpu_restore_interrupt(unsigned long flags)
{
	restored_flags[restored_count++] = flags;
}

#ifndef USE_C_SPINLOCK_MODEL
extern void *clv;
extern int cpu_local_var_initialized;

static unsigned char rust_cls_storage[8192] __attribute__((aligned(64)));
#define RUST_CLS_NO_PREEMPT_OFFSET 7976

static int *rust_preempt_counter(void)
{
	return (int *)(rust_cls_storage + RUST_CLS_NO_PREEMPT_OFFSET);
}

static void reset_preempt_model(void)
{
	clv = rust_cls_storage;
	cpu_local_var_initialized = 1;
	*rust_preempt_counter() = 0;
}

static int preempt_depth_value(void)
{
	return *rust_preempt_counter();
}

static int preempt_disable_count_value(void)
{
	return 3;
}

static int preempt_enable_count_value(void)
{
	return 3;
}
#else
static void reset_preempt_model(void) {}
static int preempt_depth_value(void) { return preempt_depth; }
static int preempt_disable_count_value(void) { return preempt_disable_count; }
static int preempt_enable_count_value(void) { return preempt_enable_count; }
#endif

#ifdef USE_C_SPINLOCK_MODEL
void ihk_mc_spinlock_init(ihk_spinlock_t *lock)
{
	lock->head_tail = 0;
}

int __ihk_mc_spinlock_trylock_noirq(ihk_spinlock_t *lock)
{
	ihk_spinlock_t cur = { .head_tail = lock->head_tail };
	ihk_spinlock_t next = { .tickets = {
		.head = cur.tickets.head,
		.tail = (unsigned short)(cur.tickets.tail + 2),
	} };
	int success;

	if (cur.tickets.head != cur.tickets.tail)
		return 0;

	preempt_disable();
	success = __sync_bool_compare_and_swap((unsigned int *)lock,
					       cur.head_tail,
					       next.head_tail);
	if (!success)
		preempt_enable();
	return success;
}

unsigned long __ihk_mc_spinlock_trylock(ihk_spinlock_t *lock, int *result)
{
	unsigned long flags = cpu_disable_interrupt_save();

	*result = __ihk_mc_spinlock_trylock_noirq(lock);
	return flags;
}

void __ihk_mc_spinlock_lock_noirq(ihk_spinlock_t *lock)
{
	unsigned int old;
	unsigned short wait_for;

	preempt_disable();
	old = __sync_fetch_and_add(&lock->head_tail, 2U << 16);
	wait_for = (unsigned short)(old >> 16);
	while ((unsigned short)lock->head_tail != wait_for)
		cpu_pause();
}

unsigned long __ihk_mc_spinlock_lock(ihk_spinlock_t *lock)
{
	unsigned long flags = cpu_disable_interrupt_save();

	__ihk_mc_spinlock_lock_noirq(lock);
	return flags;
}

void __ihk_mc_spinlock_unlock_noirq(ihk_spinlock_t *lock)
{
	__sync_fetch_and_add(&lock->tickets.head, 2);
	preempt_enable();
}

void __ihk_mc_spinlock_unlock(ihk_spinlock_t *lock, unsigned long flags)
{
	__ihk_mc_spinlock_unlock_noirq(lock);
	cpu_restore_interrupt(flags);
}

int irqflags_can_interrupt(unsigned long flags)
{
	return !!(flags & 0x200UL);
}
#endif

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	ihk_spinlock_t lock = { .head_tail = 0xffffffffU };
	unsigned long digest = 0x7370696e6c6f636bUL;
	unsigned long flags;
	int result;

	reset_preempt_model();
	ihk_mc_spinlock_init(&lock);
	require(lock.head_tail == 0);

	flags = __ihk_mc_spinlock_lock(&lock);
	require(flags == 0x100UL);
	require(lock.tickets.head == 0 && lock.tickets.tail == 2);
	require(preempt_depth_value() == 1);
	__ihk_mc_spinlock_unlock(&lock, flags);
	require(lock.tickets.head == 2 && lock.tickets.tail == 2);
	require(preempt_depth_value() == 0);
	require(restored_count == 1 && restored_flags[0] == 0x100UL);
	mix(&digest, lock.head_tail);

	require(__ihk_mc_spinlock_trylock_noirq(&lock) == 1);
	require(lock.tickets.head == 2 && lock.tickets.tail == 4);
	require(preempt_depth_value() == 1);
	__ihk_mc_spinlock_unlock_noirq(&lock);
	require(lock.tickets.head == 4 && lock.tickets.tail == 4);
	require(preempt_depth_value() == 0);
	mix(&digest, lock.head_tail);

	lock.tickets.head = 0;
	lock.tickets.tail = 2;
	require(__ihk_mc_spinlock_trylock_noirq(&lock) == 0);
	require(preempt_depth_value() == 0);
	result = -1;
	flags = __ihk_mc_spinlock_trylock(&lock, &result);
	require(flags == 0x101UL && result == 0);
	require(preempt_depth_value() == 0);
	mix(&digest, lock.head_tail);

	lock.tickets.head = 6;
	lock.tickets.tail = 6;
	result = 0;
	flags = __ihk_mc_spinlock_trylock(&lock, &result);
	require(flags == 0x102UL && result == 1);
	require(lock.tickets.head == 6 && lock.tickets.tail == 8);
	require(preempt_depth_value() == 1);
	__ihk_mc_spinlock_unlock(&lock, flags);
	require(lock.tickets.head == 8 && lock.tickets.tail == 8);
	require(preempt_depth_value() == 0);
	require(restored_count == 2 && restored_flags[1] == 0x102UL);
	require(irqflags_can_interrupt(0x200UL) == 1);
	require(irqflags_can_interrupt(0x201UL) == 1);
	require(irqflags_can_interrupt(0x100UL) == 0);
	mix(&digest, lock.head_tail);
	mix(&digest, (unsigned long)irqflags_can_interrupt(0x200UL));
	mix(&digest, ((unsigned long)preempt_disable_count_value() << 32) |
		     (unsigned int)preempt_enable_count_value());
	mix(&digest, ((unsigned long)irq_disable_count << 32) |
		     (unsigned int)pause_count);

	printf("spinlock_helpers ok digest=%016lx head=%u tail=%u\n",
	       digest, lock.tickets.head, lock.tickets.tail);
	return 0;
}
