#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VR_STACK 0x1UL
#define VR_PRIVATE 0x2000UL
#define VR_PROT_READ 0x00010000UL
#define VR_PROT_WRITE 0x00020000UL
#define VR_PROT_EXEC 0x00040000UL
#define PS_RUNNING 0x1
#define PS_INTERRUPTIBLE 0x2
#define PS_STOPPED 0x20
#define STR_PID 0x1
#define STR_TASK 0x2
#define STR_INVALID 0x4

extern int mck_crash_x86_direct_phys_result(unsigned long addr,
		unsigned long linux_page_offset,
		unsigned long x86_kernel_phys_base,
		unsigned long map_kernel_start,
		unsigned long map_fixed_start,
		unsigned long map_st_start,
		unsigned long *phys_out);
extern int mck_crash_mcreadmem_x86_addr_result(unsigned long addr,
		unsigned long linux_page_offset,
		unsigned long x86_kernel_phys_base,
		unsigned long map_kernel_start,
		unsigned long map_fixed_start,
		unsigned long map_st_start,
		unsigned long *translated_out);
extern int mcreadmem(unsigned long long addr, int memtype, void *buffer,
		long size, char *type, unsigned long error_handle);
extern const char *mck_crash_thread_status_label_result(int status);
extern int mck_crash_vr_perm_result(char *buf, unsigned long flag);
extern int mck_crash_default_path_result(char *buf, size_t buf_size,
		unsigned long start, unsigned long end, unsigned long flag,
		unsigned long vdso_addr, unsigned long vvar_addr,
		unsigned long brk_start, unsigned long brk_end_allocated);
extern int mck_crash_child_pos_result(char *dst, size_t dst_size,
		const char *src, char side);
extern int mck_crash_root_pos_result(char *dst, size_t dst_size);
extern const char *mck_crash_pgshift_label_result(int pgshift);
extern int mck_crash_symbol_value_cmd_result(char *dst, size_t dst_size,
		const char *name);
extern int mck_crash_add_symbol_file_cmd_result(char *dst, size_t dst_size,
		const char *filename);
extern size_t mck_crash_kmsg_first_part_result(int head, int tail, int len);
extern int mck_crash_kmsg_read_body_result(unsigned long kmsg_buf_str,
		int head, int tail, int len, char *msg,
		int (*read_fn)(unsigned long, char *, int));
extern int mck_crash_cmd_mckmsg_body_result(unsigned long kmsg_buf,
		long kmsg_buf_str_offset, long kmsg_buf_head_offset,
		long kmsg_buf_tail_offset, long kmsg_buf_len_offset,
		int (*read_i32_fn)(unsigned long, int *),
		char *(*getbuf_fn)(int),
		void (*freebuf_fn)(char *),
		int (*read_string_fn)(unsigned long, char *, int),
		void (*write_string_fn)(const char *));
extern int mck_crash_cmd_mcinfo_body_result(unsigned long linux_page_offset,
		void (*write_string_fn)(const char *));
extern int mck_crash_extension_init_body_result(void *command_table,
		void (*register_fn)(void *));
extern int mck_crash_extension_fini_body_result(void);
extern const char *mck_crash_thread_comm_result(const char *saved_cmdline,
		int is_idle);
extern int mck_crash_mcps_line_result(char *buf, size_t buf_size,
		int is_active, int tid, int pid, int ppid, int cpu,
		unsigned long thread, const char *status, const char *comm);
extern int mck_crash_mcps_header_result(char *buf, size_t buf_size);
extern int mck_crash_range_filter_result(unsigned long start,
		unsigned long end, unsigned long match_addr);
extern int mck_crash_mcmem_line_result(char *buf, size_t buf_size,
		unsigned long start, unsigned long end, const char *perm,
		unsigned long memobj, const char *path);
extern int mck_crash_mcmem_process_line_result(char *buf, size_t buf_size,
		unsigned long pid, unsigned long thread);
extern int mck_crash_mcmem_header_result(char *buf, size_t buf_size);
extern int mck_crash_mcvtop_header_result(char *buf, size_t buf_size);
extern int mck_crash_pte_line_result(char *buf, size_t buf_size,
		unsigned long virt, unsigned long phys, const char *size_label,
		const char *flags);
extern int mck_crash_pte_raw_line_result(char *buf, size_t buf_size,
		unsigned long pte);
extern int mck_crash_pte_not_found_result(char *buf, size_t buf_size,
		unsigned long addr);
extern int mck_crash_memory_range_header_result(char *buf, size_t buf_size);
extern unsigned long mck_crash_pte_phys_result(unsigned long pte,
		unsigned long virt, int pgshift, unsigned long mask);
extern unsigned long mck_crash_x86_sign_extend_result(unsigned long virt);
extern int mck_crash_pte_should_skip_result(unsigned long pte,
		unsigned long prev_pte, unsigned long attr_mask, int pgshift,
		int prev_pgshift, unsigned long virt, unsigned long prev_virt);
extern int mck_crash_pte_lookup_range_result(unsigned long addr,
		unsigned long virt, unsigned long index, int level_shift,
		unsigned long nonfixed_mask);
extern int mck_crash_x86_pte_flags_result(char *buf, size_t buf_size,
		unsigned long pte, unsigned long rw, unsigned long user,
		unsigned long pwt, unsigned long pcd, unsigned long accessed,
		unsigned long dirty, unsigned long global, unsigned long nx);
extern int mck_crash_arm64_pte_flags_result(char *buf, size_t buf_size,
		unsigned long pte, unsigned long valid, unsigned long user,
		unsigned long rdonly, unsigned long shared, unsigned long af,
		unsigned long ng, unsigned long pxn, unsigned long uxn,
		unsigned long dirty, unsigned long special, unsigned long write,
		unsigned long cont, unsigned long prot_none);
extern int mck_crash_parse_context_values_result(const char *input,
		unsigned long badaddr, unsigned long *decimal_out,
		unsigned long *hex_out);
extern unsigned long mck_crash_pid_hash_head_result(unsigned long thash,
		unsigned long pid, unsigned long hash_size,
		unsigned long list_head_size);
extern int mck_crash_context_lookup_body_result(const char *input,
		unsigned long badaddr, unsigned long clv,
		long clv_resource_set_offset,
		long resource_set_thread_hash_offset, long thread_tid_offset,
		unsigned long *pid_out, unsigned long *thread_out,
		int (*read_ulong_fn)(unsigned long, unsigned long *),
		int (*read_int_fn)(unsigned long, int *),
		int (*lookup_pid_fn)(unsigned long, unsigned long,
			unsigned long *));
extern int mck_crash_parse_hex_addr_result(const char *input,
		unsigned long badaddr, unsigned long *addr_out);
extern int mck_crash_same_boot_result(unsigned long old_boot_param_pa,
		unsigned long old_boot_sec, unsigned long old_boot_nsec,
		unsigned long new_boot_param_pa, unsigned long new_boot_sec,
		unsigned long new_boot_nsec);
extern void mck_crash_x86_arch_init_body_result(
		unsigned long *linux_page_offset_out,
		unsigned long *x86_kernel_phys_base_out,
		unsigned long (*get_symbol_fn)(const char *name));
extern int mck_crash_x86_pte_is_type_page_result(unsigned long pte,
		int level, unsigned long page_pse);
extern int mck_crash_arm64_pte_is_type_page_result(unsigned long pte,
		int level, unsigned long pte_type_mask,
		unsigned long pte_type_page, unsigned long pmd_type_mask,
		unsigned long pmd_type_sect);
extern int mck_crash_ptl_shift_result(int level, int l1, int l2, int l3,
		int l4);
extern int mck_crash_kmsg_wrap_result(int head, int tail);

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static int fake_kmsg_read_calls;
static int fake_kmsg_fail_call;
static const char fake_kmsg_ring[] = "ABCDEFGHIJ";
static unsigned long fake_kmsg_addr[4];
static int fake_kmsg_len[4];
static int fake_cmd_kmsg_read_i32_calls;
static int fake_cmd_kmsg_read_i32_fail_addr;
static int fake_cmd_kmsg_alloc_calls;
static int fake_cmd_kmsg_alloc_fail;
static int fake_cmd_kmsg_free_calls;
static int fake_cmd_kmsg_write_calls;
static int fake_cmd_kmsg_alloc_len;
static char fake_cmd_kmsg_msg[64];
static char fake_cmd_kmsg_written[64];
static int fake_extension_register_calls;
static void *fake_extension_register_table;

static int fake_kmsg_read(unsigned long addr, char *buf, int len)
{
	int call = fake_kmsg_read_calls++;
	unsigned long off = addr - 0x1000UL;

	if (call < 4) {
		fake_kmsg_addr[call] = addr;
		fake_kmsg_len[call] = len;
	}
	if (fake_kmsg_fail_call == call)
		return 0;
	if (off + (unsigned long)len > sizeof(fake_kmsg_ring) - 1)
		return 0;
	memcpy(buf, fake_kmsg_ring + off, len);
	buf[len] = 0;
	return 1;
}

static void reset_fake_kmsg(int fail_call)
{
	fake_kmsg_read_calls = 0;
	fake_kmsg_fail_call = fail_call;
	memset(fake_kmsg_addr, 0, sizeof(fake_kmsg_addr));
	memset(fake_kmsg_len, 0, sizeof(fake_kmsg_len));
}

static void reset_fake_cmd_kmsg(void)
{
	fake_cmd_kmsg_read_i32_calls = 0;
	fake_cmd_kmsg_read_i32_fail_addr = 0;
	fake_cmd_kmsg_alloc_calls = 0;
	fake_cmd_kmsg_alloc_fail = 0;
	fake_cmd_kmsg_free_calls = 0;
	fake_cmd_kmsg_write_calls = 0;
	fake_cmd_kmsg_alloc_len = 0;
	memset(fake_cmd_kmsg_msg, 0, sizeof(fake_cmd_kmsg_msg));
	memset(fake_cmd_kmsg_written, 0, sizeof(fake_cmd_kmsg_written));
}

static int fake_cmd_kmsg_read_i32(unsigned long addr, int *out)
{
	fake_cmd_kmsg_read_i32_calls++;
	if ((int)addr == fake_cmd_kmsg_read_i32_fail_addr)
		return 0;
	if (addr == 0x1020) {
		*out = 8;
		return 1;
	}
	if (addr == 0x1024) {
		*out = 3;
		return 1;
	}
	if (addr == 0x1028) {
		*out = 10;
		return 1;
	}
	return 0;
}

static char *fake_cmd_kmsg_getbuf(int len)
{
	fake_cmd_kmsg_alloc_calls++;
	fake_cmd_kmsg_alloc_len = len;
	if (fake_cmd_kmsg_alloc_fail)
		return NULL;
	return fake_cmd_kmsg_msg;
}

static void fake_cmd_kmsg_freebuf(char *buf)
{
	if (buf != fake_cmd_kmsg_msg)
		exit(2);
	fake_cmd_kmsg_free_calls++;
}

static void fake_cmd_kmsg_write_string(const char *msg)
{
	fake_cmd_kmsg_write_calls++;
	strncpy(fake_cmd_kmsg_written, msg, sizeof(fake_cmd_kmsg_written) - 1);
}

static void fake_register_extension(void *table)
{
	fake_extension_register_calls++;
	fake_extension_register_table = table;
}

static int fake_context_read_ulong_calls;
static int fake_context_read_int_calls;
static int fake_context_lookup_calls;
static int fake_context_read_resource_fail;
static int fake_context_read_hash_fail;
static int fake_context_lookup_hit_pid;
static unsigned long fake_context_lookup_hit_thread;
unsigned long LINUX_PAGE_OFFSET = 0xffff888000000000UL;
unsigned long x86_kernel_phys_base = 0x200000UL;
const unsigned long mck_crash_map_kernel_start = 0xffff900000000000UL;
const unsigned long mck_crash_map_fixed_start = 0xffff860000000000UL;
const unsigned long mck_crash_map_st_start = 0xffff800000000000UL;
static unsigned long fake_readmem_addr;
static int fake_readmem_memtype;
static long fake_readmem_size;
static char *fake_readmem_type;
static unsigned long fake_readmem_error_handle;
static int fake_kvtop_calls;
static unsigned long fake_kvtop_vaddr;
static unsigned long fake_kvtop_phys = 0xabc000UL;

int readmem(unsigned long long addr, int memtype, void *buffer, long size,
	    char *type, unsigned long error_handle)
{
	fake_readmem_addr = addr;
	fake_readmem_memtype = memtype;
	fake_readmem_size = size;
	fake_readmem_type = type;
	fake_readmem_error_handle = error_handle;
	if (buffer && size > 0)
		memset(buffer, 0x5a, size);
	return 77;
}

int kvtop(void *task, unsigned long vaddr, unsigned long *paddr, int verbose)
{
	require(task == NULL);
	require(verbose == 0);
	fake_kvtop_calls++;
	fake_kvtop_vaddr = vaddr;
	*paddr = fake_kvtop_phys;
	return 0;
}

static int fake_context_read_ulong(unsigned long addr, unsigned long *out)
{
	fake_context_read_ulong_calls++;
	if (addr == 0x1100) {
		if (fake_context_read_resource_fail)
			return 0;
		*out = 0x2200;
		return 1;
	}
	if (addr == 0x2220) {
		if (fake_context_read_hash_fail)
			return 0;
		*out = 0x3300;
		return 1;
	}
	return 0;
}

static int fake_context_read_int(unsigned long addr, int *out)
{
	fake_context_read_int_calls++;
	if (addr == 0xabc + 0x30) {
		*out = 77;
		return 1;
	}
	return 0;
}

static int fake_context_lookup_pid(unsigned long pid, unsigned long thash,
				   unsigned long *thread_out)
{
	fake_context_lookup_calls++;
	if (thash == 0x3300 && pid == (unsigned long)fake_context_lookup_hit_pid) {
		*thread_out = fake_context_lookup_hit_thread;
		return 1;
	}
	return 0;
}

static void reset_fake_context(void)
{
	fake_context_read_ulong_calls = 0;
	fake_context_read_int_calls = 0;
	fake_context_lookup_calls = 0;
	fake_context_read_resource_fail = 0;
	fake_context_read_hash_fail = 0;
	fake_context_lookup_hit_pid = -1;
	fake_context_lookup_hit_thread = 0;
}

static int fake_arch_symbol_calls;
static const char *fake_arch_symbol_names[4];

static unsigned long fake_arch_get_symbol(const char *name)
{
	fake_arch_symbol_names[fake_arch_symbol_calls++] = name;
	if (!strcmp(name, "linux_page_offset_base"))
		return 0xffff888000000000UL;
	if (!strcmp(name, "x86_kernel_phys_base"))
		return 0x200000UL;
	return 0;
}

int main(void)
{
	unsigned long digest = 0x637261736868UL;
	unsigned long phys = 0;
	unsigned long dec = 0;
	unsigned long hex = 0;
	unsigned long addr = 0;
	unsigned long pid = 0;
	unsigned long found_thread = 0;
	char buf[512];
	char membuf[8];

	require(mck_crash_x86_direct_phys_result(0xffff900000000123UL,
			0xffff888000000000UL, 0x200000UL,
			0xffff900000000000UL, 0xffff860000000000UL,
			0xffff800000000000UL, &phys) == 1);
	require(phys == 0x200123UL);
	require(mck_crash_x86_direct_phys_result(0x1000, -1UL, 0x200000UL,
			0xffff900000000000UL, 0xffff860000000000UL,
			0xffff800000000000UL, &phys) == 0);
	require(mck_crash_mcreadmem_x86_addr_result(0xffff900000000123UL,
			0xffff888000000000UL, 0x200000UL,
			0xffff900000000000UL, 0xffff860000000000UL,
			0xffff800000000000UL, &phys) == 1);
	require(phys == 0xffff888000200123UL);
	require(mck_crash_mcreadmem_x86_addr_result(0x1000,
			0xffff888000000000UL, 0x200000UL,
			0xffff900000000000UL, 0xffff860000000000UL,
			0xffff800000000000UL, &phys) == 2);
	require(phys == 0x1000);
	require(mck_crash_mcreadmem_x86_addr_result(0x1000, -1UL,
			0x200000UL, 0xffff900000000000UL,
			0xffff860000000000UL, 0xffff800000000000UL,
			&phys) == 0);
	mix(&digest, phys);
	memset(membuf, 0, sizeof(membuf));
	require(mcreadmem(0xffff900000000123ULL, 7, membuf, sizeof(membuf),
			"direct", 9) == 77);
	require(fake_readmem_addr == 0xffff888000200123UL);
	require(fake_readmem_memtype == 7);
	require(fake_readmem_size == (long)sizeof(membuf));
	require(fake_readmem_type && !strcmp(fake_readmem_type, "direct"));
	require(fake_readmem_error_handle == 9);
	require((unsigned char)membuf[0] == 0x5a);
	require(fake_kvtop_calls == 0);
	require(mcreadmem(0x1000ULL, 8, membuf, 4, "kvtop", 10) == 77);
	require(fake_kvtop_calls == 1 && fake_kvtop_vaddr == 0x1000UL);
	require(fake_readmem_addr == 0xffff888000abc000UL);
	LINUX_PAGE_OFFSET = -1UL;
	require(mcreadmem(0x2000ULL, 9, membuf, 2, "raw", 11) == 77);
	require(fake_readmem_addr == 0x2000UL);
	require(fake_kvtop_calls == 1);
	LINUX_PAGE_OFFSET = 0xffff888000000000UL;

	require(!strcmp(mck_crash_thread_status_label_result(PS_RUNNING), "RU"));
	require(!strcmp(mck_crash_thread_status_label_result(PS_INTERRUPTIBLE),
			"IN"));
	require(!strcmp(mck_crash_thread_status_label_result(PS_STOPPED), "T"));
	require(!strcmp(mck_crash_thread_status_label_result(0), "??"));

	require(mck_crash_vr_perm_result(buf, VR_PROT_READ | VR_PROT_WRITE |
			VR_PRIVATE) == 4);
	require(!strcmp(buf, "rw-p"));
	require(mck_crash_default_path_result(buf, sizeof(buf), 0x1000, 0x2000,
			0, 0x1000, 0x3000, 0x4000, 0x5000) > 0);
	require(!strcmp(buf, "[vdso]"));
	require(mck_crash_default_path_result(buf, sizeof(buf), 0x4000, 0x4800,
			0, 0x1000, 0x3000, 0x4000, 0x5000) > 0);
	require(!strcmp(buf, "[heap]"));
	require(mck_crash_default_path_result(buf, sizeof(buf), 0x6000, 0x7000,
			VR_STACK, 0x1000, 0x3000, 0x4000, 0x5000) > 0);
	require(!strcmp(buf, "[stack]"));

	require(mck_crash_child_pos_result(buf, sizeof(buf), "root/l", 'r') > 0);
	require(!strcmp(buf, "root/l/r"));
	require(mck_crash_root_pos_result(buf, sizeof(buf)) > 0);
	require(!strcmp(buf, "root"));
	require(!strcmp(mck_crash_pgshift_label_result(21), "2M"));

	require(mck_crash_symbol_value_cmd_result(buf, sizeof(buf), "boot_param")
			> 0);
	require(!strcmp(buf, "printf \"%p\", &boot_param"));
	require(mck_crash_add_symbol_file_cmd_result(buf, sizeof(buf),
			"mckernel.img") > 0);
	require(!strcmp(buf, "add-symbol-file mckernel.img 0"));
	require(mck_crash_kmsg_first_part_result(8, 3, 10) == 2);
	require(mck_crash_kmsg_wrap_result(8, 3) == 1);
	reset_fake_kmsg(-1);
	require(mck_crash_kmsg_read_body_result(0x1000, 2, 6, 10, buf,
			fake_kmsg_read) == 1);
	require(fake_kmsg_read_calls == 1);
	require(fake_kmsg_addr[0] == 0x1002 && fake_kmsg_len[0] == 4);
	require(!strcmp(buf, "CDEF"));
	reset_fake_kmsg(-1);
	require(mck_crash_kmsg_read_body_result(0x1000, 8, 3, 10, buf,
			fake_kmsg_read) == 1);
	require(fake_kmsg_read_calls == 2);
	require(fake_kmsg_addr[0] == 0x1008 && fake_kmsg_len[0] == 2);
	require(fake_kmsg_addr[1] == 0x1000 && fake_kmsg_len[1] == 3);
	require(!strcmp(buf, "IJABC"));
	reset_fake_kmsg(1);
	require(mck_crash_kmsg_read_body_result(0x1000, 8, 3, 10, buf,
			fake_kmsg_read) == 0);
	require(fake_kmsg_read_calls == 2);
	reset_fake_kmsg(-1);
	reset_fake_cmd_kmsg();
	require(mck_crash_cmd_mckmsg_body_result(0x1000, 0, 0x20, 0x24,
			0x28, fake_cmd_kmsg_read_i32, fake_cmd_kmsg_getbuf,
			fake_cmd_kmsg_freebuf, fake_kmsg_read,
			fake_cmd_kmsg_write_string) == 1);
	require(fake_cmd_kmsg_read_i32_calls == 3);
	require(fake_cmd_kmsg_alloc_calls == 1);
	require(fake_cmd_kmsg_alloc_len == 10);
	require(fake_kmsg_read_calls == 2);
	require(fake_cmd_kmsg_write_calls == 1);
	require(!strcmp(fake_cmd_kmsg_written, "IJABC"));
	require(fake_cmd_kmsg_free_calls == 1);
	reset_fake_kmsg(-1);
	reset_fake_cmd_kmsg();
	fake_cmd_kmsg_read_i32_fail_addr = 0x1024;
	require(mck_crash_cmd_mckmsg_body_result(0x1000, 0, 0x20, 0x24,
			0x28, fake_cmd_kmsg_read_i32, fake_cmd_kmsg_getbuf,
			fake_cmd_kmsg_freebuf, fake_kmsg_read,
			fake_cmd_kmsg_write_string) == 0);
	require(fake_cmd_kmsg_read_i32_calls == 2);
	require(fake_cmd_kmsg_alloc_calls == 0);
	reset_fake_kmsg(0);
	reset_fake_cmd_kmsg();
	require(mck_crash_cmd_mckmsg_body_result(0x1000, 0, 0x20, 0x24,
			0x28, fake_cmd_kmsg_read_i32, fake_cmd_kmsg_getbuf,
			fake_cmd_kmsg_freebuf, fake_kmsg_read,
			fake_cmd_kmsg_write_string) == -1);
	require(fake_cmd_kmsg_free_calls == 1);
	require(fake_cmd_kmsg_write_calls == 0);
	reset_fake_kmsg(-1);
	reset_fake_cmd_kmsg();
	fake_cmd_kmsg_alloc_fail = 1;
	require(mck_crash_cmd_mckmsg_body_result(0x1000, 0, 0x20, 0x24,
			0x28, fake_cmd_kmsg_read_i32, fake_cmd_kmsg_getbuf,
			fake_cmd_kmsg_freebuf, fake_kmsg_read,
			fake_cmd_kmsg_write_string) == -2);
	require(fake_cmd_kmsg_free_calls == 0);
	reset_fake_cmd_kmsg();
	require(mck_crash_cmd_mcinfo_body_result(0xffff888000000000UL,
			fake_cmd_kmsg_write_string) == 1);
	require(fake_cmd_kmsg_write_calls == 1);
	require(!strcmp(fake_cmd_kmsg_written,
			"LINUX_PAGE_OFFSET: 0xffff888000000000\n"));
	require(mck_crash_cmd_mcinfo_body_result(0, NULL) == -2);
	mix(&digest, (unsigned long)strlen(fake_cmd_kmsg_written));
	{
		int fake_command_table;

		fake_extension_register_calls = 0;
		fake_extension_register_table = NULL;
		require(mck_crash_extension_init_body_result(&fake_command_table,
				fake_register_extension) == 0);
		require(fake_extension_register_calls == 1);
		require(fake_extension_register_table == &fake_command_table);
		require(mck_crash_extension_init_body_result(NULL,
				fake_register_extension) == -2);
		require(mck_crash_extension_init_body_result(&fake_command_table,
				NULL) == -2);
		require(mck_crash_extension_fini_body_result() == 0);
		mix(&digest, (unsigned long)fake_extension_register_calls);
	}
	mix(&digest, (unsigned long)fake_kmsg_read_calls);
	require(!strcmp(mck_crash_thread_comm_result("/sbin/init", 0), "init"));
	require(!strcmp(mck_crash_thread_comm_result(NULL, 1), "idle"));

	require(mck_crash_mcps_header_result(buf, sizeof(buf)) > 0);
	require(strstr(buf, "TID") != NULL && strstr(buf, "COMM") != NULL);
	require(mck_crash_mcps_line_result(buf, sizeof(buf), 1, 7, 8, 1, 2,
			0x1234, "RU", "init") > 0);
	require(strstr(buf, ">     7") == buf);
	require(strstr(buf, "0000000000001234") != NULL);
	require(strstr(buf, "RU init") != NULL);

	require(mck_crash_range_filter_result(0x1000, 0x2000, -1UL) == 0);
	require(mck_crash_range_filter_result(0x3000, 0x4000, 0x2000) == 1);
	require(mck_crash_range_filter_result(0x1000, 0x2000, 0x2000) == -1);
	require(mck_crash_mcmem_line_result(buf, sizeof(buf), 0x1000, 0x2000,
			"rwxp", 0x44, "[heap]") > 0);
	require(strstr(buf, "0000000000001000-0000000000002000") == buf);
	require(strstr(buf, "rwxp") != NULL && strstr(buf, "[heap]") != NULL);
	require(mck_crash_mcmem_process_line_result(buf, sizeof(buf), 9,
			0xabc) > 0);
	require(!strcmp(buf, "Memory mapping for process 9 / abc"));
	require(mck_crash_mcmem_header_result(buf, sizeof(buf)) > 0);
	require(strstr(buf, "BACKING FILE") != NULL);
	require(mck_crash_mcvtop_header_result(buf, sizeof(buf)) > 0);
	require(strstr(buf, "VIRT") != NULL && strstr(buf, "FLAGS") != NULL);

	require(mck_crash_pte_line_result(buf, sizeof(buf), 0x1000, 0x2000,
			"4K", "RW|NX") > 0);
	require(!strcmp(buf,
		"0000000000001000 0000000000002000   4K (RW|NX)"));
	require(mck_crash_pte_raw_line_result(buf, sizeof(buf), 0x55) > 0);
	require(!strcmp(buf, "PTE: 55"));
	require(mck_crash_pte_not_found_result(buf, sizeof(buf), 0xbeef) > 0);
	require(!strcmp(buf, "Couldn't find valid PTE for 0xbeef"));
	require(mck_crash_memory_range_header_result(buf, sizeof(buf)) > 0);
	require(!strcmp(buf, "\nMemory range:"));

	require(mck_crash_parse_context_values_result("123", -1UL, &dec,
			&hex) == 3);
	require(dec == 123 && hex == 0x123);
	require(mck_crash_parse_hex_addr_result("0xabc", -1UL, &addr) == 1);
	require(addr == 0xabc);
	require(mck_crash_pid_hash_head_result(0x1000, 7, 4, 16) == 0x1030);
	reset_fake_context();
	fake_context_lookup_hit_pid = 123;
	fake_context_lookup_hit_thread = 0xaabbccUL;
	pid = 0;
	found_thread = 0;
	require(mck_crash_context_lookup_body_result("123", -1UL, 0x1000,
			0x100, 0x20, 0x30, &pid, &found_thread,
			fake_context_read_ulong, fake_context_read_int,
			fake_context_lookup_pid) == STR_PID);
	require(pid == 123 && found_thread == 0xaabbccUL);
	require(fake_context_read_ulong_calls == 2);
	require(fake_context_lookup_calls == 1);
	reset_fake_context();
	pid = 0;
	found_thread = 0;
	require(mck_crash_context_lookup_body_result("0xabc", -1UL, 0x1000,
			0x100, 0x20, 0x30, &pid, &found_thread,
			fake_context_read_ulong, fake_context_read_int,
			fake_context_lookup_pid) == STR_TASK);
	require(pid == 77 && found_thread == 0xabc);
	require(fake_context_lookup_calls == 1);
	require(fake_context_read_int_calls == 1);
	reset_fake_context();
	fake_context_read_resource_fail = 1;
	pid = 0;
	found_thread = 0;
	require(mck_crash_context_lookup_body_result("123", -1UL, 0x1000,
			0x100, 0x20, 0x30, &pid, &found_thread,
			fake_context_read_ulong, fake_context_read_int,
			fake_context_lookup_pid) == STR_INVALID);
	require(mck_crash_context_lookup_body_result(NULL, -1UL, 0x1000,
			0x100, 0x20, 0x30, &pid, &found_thread,
			fake_context_read_ulong, fake_context_read_int,
			fake_context_lookup_pid) == STR_INVALID);
	require(mck_crash_same_boot_result(1, 2, 3, 1, 2, 3) == 1);
	require(mck_crash_same_boot_result(1, 2, 3, 1, 2, 4) == 0);
	LINUX_PAGE_OFFSET = 0;
	x86_kernel_phys_base = 0;
	fake_arch_symbol_calls = 0;
	mck_crash_x86_arch_init_body_result(&LINUX_PAGE_OFFSET,
			&x86_kernel_phys_base, fake_arch_get_symbol);
	require(fake_arch_symbol_calls == 2);
	require(!strcmp(fake_arch_symbol_names[0], "linux_page_offset_base"));
	require(!strcmp(fake_arch_symbol_names[1], "x86_kernel_phys_base"));
	require(LINUX_PAGE_OFFSET == 0xffff888000000000UL);
	require(x86_kernel_phys_base == 0x200000UL);

	require(mck_crash_x86_pte_is_type_page_result(0x80, 2, 0x80) == 1);
	require(mck_crash_arm64_pte_is_type_page_result(3, 1, 3, 3, 3, 1)
			== 1);
	require(mck_crash_ptl_shift_result(3, 12, 21, 30, 39) == 30);
	require(mck_crash_pte_phys_result(0x12345000, 0xabc, 12,
			~0xfffUL) == 0x12345abc);
	require(mck_crash_x86_sign_extend_result(0x800000000000UL) ==
			0xffff800000000000UL);
	require(mck_crash_pte_should_skip_result(0x105, 0x205, 0xff, 12, 12,
			0x2000, 0x1000) == 1);
	require(mck_crash_pte_lookup_range_result(0x1800, 0x1000, 0, 12,
			~0UL) == 0);

	require(mck_crash_x86_pte_flags_result(buf, sizeof(buf), 0x83,
			0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80,
			0x8000000000000000UL) > 0);
	require(!strcmp(buf, "RW|GLOBAL"));
	require(mck_crash_arm64_pte_flags_result(buf, sizeof(buf), 0x13,
			0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80,
			0x100, 0x200, 0x400, 0x800, 0x1000) > 0);
	require(!strcmp(buf, "VALID|USER|AF"));

	mix(&digest, phys + dec + hex + addr);
	printf("mckernel_crash_helpers ok digest=%016lx\n", digest);
	return 0;
}
