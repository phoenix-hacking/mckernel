extern int printf(const char *, ...);
extern int fflush(void *);
extern void abort(void);

#include <list.h>
#include <cls.h>

#define KMALLOC_TRACK_HASH_SIZE 256
#define KMALLOC_TRACK_HASH_MASK (KMALLOC_TRACK_HASH_SIZE - 1)

struct kmalloc_track_entry;

struct kmalloc_track_addr_entry {
	void *addr;
	int runcount;
	struct list_head list;
	struct kmalloc_track_entry *entry;
	struct list_head hash;
};

struct kmalloc_track_entry {
	char *file;
	int line;
	int size;
	ihk_atomic_t alloc_count;
	struct list_head hash;
	struct list_head addr_list;
	ihk_spinlock_t addr_list_lock;
};

static unsigned char arena[512] __attribute__((aligned(64)));
static unsigned char page_arena[8192] __attribute__((aligned(4096)));
static struct cpu_local_var clv_storage[16];
static int current_cpu = 7;
static int irq_save_count;
static int irq_restore_count;
static unsigned long last_restore_flags;
static int alloc_pages_count;
static int alloc_pages_npages;
static unsigned long alloc_pages_flag;
static int alloc_pages_is_user;
static int alloc_pages_fail;
static int remote_lock_count;
static int remote_unlock_count;
static unsigned long remote_lock_addr;
static unsigned long remote_unlock_addr;
static unsigned long remote_unlock_flags;
static int corruption_count;
static void *corruption_ptr;
static unsigned char cache_storage[4][sizeof(struct kmalloc_header) +
	sizeof(struct kmalloc_cache_header) + 16] __attribute__((aligned(64)));
static void *cache_alloc_returns[8];
static int cache_alloc_return_count;
static int cache_alloc_index;
static unsigned long cache_alloc_sizes[8];
static unsigned long cache_alloc_flags[8];
static int cache_log_events[16];
static void *cache_log_ptrs[16];
static int cache_log_count;
static int cache_prealloc_count;
static struct kmalloc_cache_header *cache_prealloc_cache;
static unsigned long cache_prealloc_size;
static int cache_prealloc_nr;
static void *cache_prealloc_payload;
static struct list_head track_hash_heads[KMALLOC_TRACK_HASH_SIZE];
static struct list_head addr_hash_heads[KMALLOC_TRACK_HASH_SIZE];
static ihk_spinlock_t track_hash_locks[KMALLOC_TRACK_HASH_SIZE];
static ihk_spinlock_t addr_hash_locks[KMALLOC_TRACK_HASH_SIZE];
static struct kmalloc_track_entry track_entries[4];
static struct kmalloc_track_addr_entry track_addr_entries[4];
static char track_file_storage[4][32];
static unsigned char track_payloads[8][96] __attribute__((aligned(64)));
static void *track_alloc_returns[16];
static int track_alloc_return_count;
static int track_alloc_index;
static int track_alloc_sizes[16];
static unsigned long track_alloc_flags[16];
static void *track_freed[16];
static int track_free_count;
static unsigned long track_lock_addrs[640];
static unsigned long track_unlock_addrs[640];
static unsigned long track_unlock_flags[640];
static int track_lock_count;
static int track_unlock_count;
static unsigned long track_noirq_lock_addrs[16];
static unsigned long track_noirq_unlock_addrs[16];
static int track_noirq_lock_count;
static int track_noirq_unlock_count;
static unsigned long track_spin_init_addr;
static int track_spin_init_count;
static int track_log_events[32];
static void *track_log_ptrs[32];
static int track_log_count;
static int leak_log_events[32];
static void *leak_log_ptrs[32];
static int leak_log_sizes[32];
static int leak_log_counts[32];
static int leak_log_runcounts[32];
static int leak_log_count;
static int invalid_free_count;
static void *invalid_free_ptr;
static char *invalid_free_file;
static int invalid_free_line;
static int kmalloc_init_register_count;
static int kmalloc_init_this_cpu_count;
static int kmalloc_init_find_count;
static char *kmalloc_init_find_name;
static char kmalloc_init_memdebug_token[] = "memdebug-present";

extern void ___kmalloc_init_chunk_result(struct kmalloc_header *, int);
extern void ___kmalloc_insert_chunk_result(struct list_head *,
		struct kmalloc_header *);
extern void ___kmalloc_consolidate_list_result(struct list_head *);
extern void *___kmalloc_body_result(int, unsigned long, struct list_head *,
		unsigned long (*)(void), void (*)(unsigned long),
		void *(*)(int, unsigned long, int));
extern int ___kfree_body_result(void *, struct list_head *, unsigned long,
		unsigned long, unsigned long (*)(void), void (*)(unsigned long),
		void *(*)(int), unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long), void (*)(void *));
extern int kmalloc_cache_free_result(void *, void (*)(int, void *));
extern int kmalloc_cache_prealloc_result(struct kmalloc_cache_header *,
		unsigned long, int, void *(*)(unsigned long, unsigned long),
		void (*)(int, void *));
extern void *kmalloc_cache_alloc_result(struct kmalloc_cache_header *,
		unsigned long, void (*)(struct kmalloc_cache_header *,
			unsigned long, int), void (*)(int, void *));
extern struct kmalloc_track_entry *kmalloc_track_find_entry_result(int, char *,
		int, struct list_head *);
extern void *kmalloc_track_alloc_result(int, unsigned long, char *, int,
		char *, struct list_head *, ihk_spinlock_t *,
		struct list_head *, ihk_spinlock_t *, int,
		void *(*)(int, unsigned long), void (*)(void *),
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(int, void *, char *, int, int));
extern int kmalloc_track_free_result(void *, char *, int, char *,
		struct list_head *, ihk_spinlock_t *, struct list_head *,
		ihk_spinlock_t *, void (*)(void *),
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(void *, char *, int),
		void (*)(int, void *, char *, int, int));
extern int mem_track_hashes_init_result(int *, struct list_head *,
		ihk_spinlock_t *, struct list_head *, ihk_spinlock_t *, int,
		void (*)(unsigned long));
extern int mem_kmalloc_init_body_result(char **, int *, struct list_head *,
		ihk_spinlock_t *, struct list_head *, ihk_spinlock_t *, int,
		struct cpu_local_var *(*)(void), void (*)(void),
		char *(*)(char *), void (*)(unsigned long));
extern int kmalloc_memcheck_result(struct list_head *, ihk_spinlock_t *,
		int *, int, unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long), void (*)(unsigned long),
		void (*)(unsigned long),
		void (*)(int, void *, char *, int, int, int, int));
extern int kmalloc_consolidate_free_list_result(struct list_head *,
		struct list_head *, ihk_spinlock_t *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long));

int ihk_mc_get_processor_id_equiv(void)
{
	return current_cpu;
}

__attribute__((weak)) int ihk_mc_get_processor_id(void)
{
	return current_cpu;
}

static void require_line(int cond, int line)
{
	if (!cond) {
		printf("kmalloc_helpers require failed line=%d\n", line);
		fflush(0);
		abort();
	}
}

#define require(cond) require_line((cond), __LINE__)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static struct kmalloc_header *kmalloc_header_from_list(struct list_head *list)
{
	return (struct kmalloc_header *)((char *)list -
		offsetof(struct kmalloc_header, list));
}

static struct kmalloc_track_entry *kmalloc_track_entry_from_hash(
		struct list_head *hash)
{
	return (struct kmalloc_track_entry *)((char *)hash -
		offsetof(struct kmalloc_track_entry, hash));
}

static struct kmalloc_track_addr_entry *kmalloc_track_addr_from_list(
		struct list_head *list)
{
	return (struct kmalloc_track_addr_entry *)((char *)list -
		offsetof(struct kmalloc_track_addr_entry, list));
}

static struct kmalloc_track_addr_entry *kmalloc_track_addr_from_hash(
		struct list_head *hash)
{
	return (struct kmalloc_track_addr_entry *)((char *)hash -
		offsetof(struct kmalloc_track_addr_entry, hash));
}

static void reset_fake_kmalloc(void)
{
	irq_save_count = 0;
	irq_restore_count = 0;
	last_restore_flags = 0;
	alloc_pages_count = 0;
	alloc_pages_npages = 0;
	alloc_pages_flag = 0;
	alloc_pages_is_user = -1;
	alloc_pages_fail = 0;
	remote_lock_count = 0;
	remote_unlock_count = 0;
	remote_lock_addr = 0;
	remote_unlock_addr = 0;
	remote_unlock_flags = 0;
	corruption_count = 0;
	corruption_ptr = NULL;
}

static unsigned long fake_irq_save(void)
{
	return 0x5000UL + (unsigned long)irq_save_count++;
}

static void fake_irq_restore(unsigned long flags)
{
	irq_restore_count++;
	last_restore_flags = flags;
}

static void *fake_alloc_pages(int npages, unsigned long flag, int is_user)
{
	alloc_pages_count++;
	alloc_pages_npages = npages;
	alloc_pages_flag = flag;
	alloc_pages_is_user = is_user;
	if (alloc_pages_fail)
		return NULL;
	return page_arena;
}

static void *fake_get_cpu_local_var(int cpu)
{
	if (cpu < 0 || cpu >= 16)
		return NULL;
	return &clv_storage[cpu];
}

static unsigned long fake_remote_lock(unsigned long lock_addr)
{
	remote_lock_count++;
	remote_lock_addr = lock_addr;
	return 0x6000UL;
}

static void fake_remote_unlock(unsigned long lock_addr, unsigned long flags)
{
	remote_unlock_count++;
	remote_unlock_addr = lock_addr;
	remote_unlock_flags = flags;
}

static void fake_corruption(void *ptr)
{
	corruption_count++;
	corruption_ptr = ptr;
}

static void *cache_payload(int index)
{
	return cache_storage[index] + sizeof(struct kmalloc_header);
}

static struct kmalloc_header *cache_header(int index)
{
	return (struct kmalloc_header *)cache_storage[index];
}

static void reset_cache_fake(void)
{
	int i;

	for (i = 0; i < 8; i++) {
		cache_alloc_returns[i] = NULL;
		cache_alloc_sizes[i] = 0;
		cache_alloc_flags[i] = 0;
	}
	for (i = 0; i < 16; i++) {
		cache_log_events[i] = 0;
		cache_log_ptrs[i] = NULL;
	}
	cache_alloc_return_count = 0;
	cache_alloc_index = 0;
	cache_log_count = 0;
	cache_prealloc_count = 0;
	cache_prealloc_cache = NULL;
	cache_prealloc_size = 0;
	cache_prealloc_nr = 0;
	cache_prealloc_payload = NULL;
	memset(cache_storage, 0, sizeof(cache_storage));
}

static void push_cache_alloc(void *ptr)
{
	cache_alloc_returns[cache_alloc_return_count++] = ptr;
}

static void *fake_cache_alloc(unsigned long size, unsigned long flag)
{
	int index = cache_alloc_index++;

	cache_alloc_sizes[index] = size;
	cache_alloc_flags[index] = flag;
	if (index >= cache_alloc_return_count)
		return NULL;
	return cache_alloc_returns[index];
}

static void fake_cache_log(int event, void *ptr)
{
	cache_log_events[cache_log_count] = event;
	cache_log_ptrs[cache_log_count] = ptr;
	cache_log_count++;
}

static void fake_cache_prealloc(struct kmalloc_cache_header *cache,
		unsigned long size, int nr_elem)
{
	cache_prealloc_count++;
	cache_prealloc_cache = cache;
	cache_prealloc_size = size;
	cache_prealloc_nr = nr_elem;
	if (cache_prealloc_payload) {
		struct kmalloc_header *header =
			(struct kmalloc_header *)((char *)cache_prealloc_payload -
					sizeof(struct kmalloc_header));

		header->cache = cache;
		kmalloc_cache_free_result(cache_prealloc_payload,
				fake_cache_log);
	}
}

static int test_strlen(const char *s)
{
	int len = 0;

	while (s[len])
		len++;
	return len;
}

static int test_streq(const char *a, const char *b)
{
	while (*a || *b) {
		if (*a != *b)
			return 0;
		a++;
		b++;
	}
	return 1;
}

static int track_hash_for(const char *file, int line, int size)
{
	return (test_strlen(file) + line + size) & KMALLOC_TRACK_HASH_MASK;
}

static int addr_hash_for(void *ptr)
{
	return ((unsigned long)ptr >> 5) & KMALLOC_TRACK_HASH_MASK;
}

static void init_track_heads(void)
{
	int i;

	for (i = 0; i < KMALLOC_TRACK_HASH_SIZE; i++) {
		INIT_LIST_HEAD(&track_hash_heads[i]);
		INIT_LIST_HEAD(&addr_hash_heads[i]);
		track_hash_locks[i].head_tail = 0;
		addr_hash_locks[i].head_tail = 0;
	}
}

static void reset_track_fake(void)
{
	int i;

	track_alloc_return_count = 0;
	track_alloc_index = 0;
	for (i = 0; i < 16; i++) {
		track_alloc_returns[i] = NULL;
		track_alloc_sizes[i] = 0;
		track_alloc_flags[i] = 0;
		track_freed[i] = NULL;
	}
	track_free_count = 0;
	for (i = 0; i < 640; i++) {
		track_lock_addrs[i] = 0;
		track_unlock_addrs[i] = 0;
		track_unlock_flags[i] = 0;
	}
	for (i = 0; i < 16; i++) {
		track_noirq_lock_addrs[i] = 0;
		track_noirq_unlock_addrs[i] = 0;
	}
	for (i = 0; i < 32; i++) {
		track_log_events[i] = 0;
		track_log_ptrs[i] = NULL;
		leak_log_events[i] = 0;
		leak_log_ptrs[i] = NULL;
		leak_log_sizes[i] = 0;
		leak_log_counts[i] = 0;
		leak_log_runcounts[i] = 0;
	}
	track_lock_count = 0;
	track_unlock_count = 0;
	track_noirq_lock_count = 0;
	track_noirq_unlock_count = 0;
	track_spin_init_addr = 0;
	track_spin_init_count = 0;
	track_log_count = 0;
	leak_log_count = 0;
	invalid_free_count = 0;
	invalid_free_ptr = NULL;
	invalid_free_file = NULL;
	invalid_free_line = 0;
	kmalloc_init_register_count = 0;
	kmalloc_init_this_cpu_count = 0;
	kmalloc_init_find_count = 0;
	kmalloc_init_find_name = NULL;
}

static void push_track_alloc(void *ptr)
{
	track_alloc_returns[track_alloc_return_count++] = ptr;
}

static void *fake_track_alloc(int size, unsigned long flag)
{
	int index = track_alloc_index++;

	track_alloc_sizes[index] = size;
	track_alloc_flags[index] = flag;
	if (index >= track_alloc_return_count)
		return NULL;
	return track_alloc_returns[index];
}

static void fake_track_free(void *ptr)
{
	track_freed[track_free_count++] = ptr;
}

static unsigned long fake_track_lock(unsigned long lock_addr)
{
	track_lock_addrs[track_lock_count] = lock_addr;
	return 0x7000UL + (unsigned long)track_lock_count++;
}

static void fake_track_unlock(unsigned long lock_addr, unsigned long flags)
{
	track_unlock_addrs[track_unlock_count] = lock_addr;
	track_unlock_flags[track_unlock_count] = flags;
	track_unlock_count++;
}

static void fake_track_noirq_lock(unsigned long lock_addr)
{
	track_noirq_lock_addrs[track_noirq_lock_count++] = lock_addr;
}

static void fake_track_noirq_unlock(unsigned long lock_addr)
{
	track_noirq_unlock_addrs[track_noirq_unlock_count++] = lock_addr;
}

static void fake_track_spin_init(unsigned long lock_addr)
{
	track_spin_init_addr = lock_addr;
	track_spin_init_count++;
}

static void fake_track_log(int event, void *ptr, char *file, int line, int size)
{
	(void)file;
	(void)line;
	(void)size;
	track_log_events[track_log_count] = event;
	track_log_ptrs[track_log_count] = ptr;
	track_log_count++;
}

static void fake_invalid_free(void *ptr, char *file, int line)
{
	invalid_free_count++;
	invalid_free_ptr = ptr;
	invalid_free_file = file;
	invalid_free_line = line;
}

static void fake_leak_log(int event, void *ptr, char *file, int line,
		int size, int count, int runcount)
{
	(void)file;
	(void)line;
	leak_log_events[leak_log_count] = event;
	leak_log_ptrs[leak_log_count] = ptr;
	leak_log_sizes[leak_log_count] = size;
	leak_log_counts[leak_log_count] = count;
	leak_log_runcounts[leak_log_count] = runcount;
	leak_log_count++;
}

static struct cpu_local_var *fake_kmalloc_init_this_cpu(void)
{
	kmalloc_init_this_cpu_count++;
	return &clv_storage[0];
}

static void fake_kmalloc_init_register(void)
{
	kmalloc_init_register_count++;
}

static char *fake_kmalloc_init_find_command(char *name)
{
	kmalloc_init_find_count++;
	kmalloc_init_find_name = name;
	return kmalloc_init_memdebug_token;
}

int main(void)
{
	struct list_head free_list;
	struct list_head remote_list;
	struct kmalloc_header *a = (struct kmalloc_header *)(arena + 0);
	struct kmalloc_header *b = (struct kmalloc_header *)
		((char *)a + sizeof(struct kmalloc_header) + 32);
	struct kmalloc_header *c = (struct kmalloc_header *)
		((char *)b + sizeof(struct kmalloc_header) + 48 + 64);
	struct kmalloc_cache_header cache;
	struct kmalloc_cache_header *cache_elem0;
	struct kmalloc_cache_header *cache_elem1;
	struct kmalloc_cache_header *cache_elem2;
	void *cache_result;
	struct kmalloc_header *chunk;
	ihk_spinlock_t remote_lock = { 0 };
	unsigned long digest = 0x51a7f00dUL;
	int count = 0;
	int hash;
	int addr_hash;
	int initialized;
	int km_runcount;

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache_elem0 = (struct kmalloc_cache_header *)cache_payload(0);
	cache_elem1 = (struct kmalloc_cache_header *)cache_payload(1);
	cache_elem2 = (struct kmalloc_cache_header *)cache_payload(2);
	cache_header(0)->cache = &cache;
	require(kmalloc_cache_free_result(cache_elem0, fake_cache_log) == 1);
	require(cache.next == cache_elem0);
	require(cache_elem0->next == NULL);
	require(cache_log_count == 0);

	cache_header(1)->cache = &cache;
	require(kmalloc_cache_free_result(cache_elem1, fake_cache_log) == 1);
	require(cache.next == cache_elem1);
	require(cache_elem1->next == cache_elem0);
	require(cache_elem0->next == NULL);
	mix(&digest, (unsigned long)(cache.next == cache_elem1));

	require(kmalloc_cache_free_result(NULL, fake_cache_log) == 0);
	require(cache.next == cache_elem1);
	require(cache_log_count == 0);

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache_elem2 = (struct kmalloc_cache_header *)cache_payload(2);
	require(kmalloc_cache_free_result(cache_elem2, fake_cache_log) == 0);
	require(cache.next == NULL);
	require(cache_log_count == 1);
	require(cache_log_events[0] == 1 && cache_log_ptrs[0] == cache_elem2);
	mix(&digest, (unsigned long)cache_log_events[0]);

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache_elem0 = (struct kmalloc_cache_header *)cache_payload(0);
	cache_elem1 = (struct kmalloc_cache_header *)cache_payload(1);
	cache.next = cache_elem0;
	cache_elem0->next = cache_elem1;
	cache_elem1->next = NULL;
	cache_result = kmalloc_cache_alloc_result(&cache, 80,
			fake_cache_prealloc, fake_cache_log);
	require(cache_result == cache_elem0);
	require(cache.next == cache_elem1);
	require(cache_prealloc_count == 0 && cache_log_count == 0);
	mix(&digest, (unsigned long)(cache.next == cache_elem1));

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache_elem2 = (struct kmalloc_cache_header *)cache_payload(2);
	cache_prealloc_payload = cache_elem2;
	cache_result = kmalloc_cache_alloc_result(&cache, 96,
			fake_cache_prealloc, fake_cache_log);
	require(cache_result == cache_elem2);
	require(cache.next == NULL);
	require(cache_prealloc_count == 1);
	require(cache_prealloc_cache == &cache);
	require(cache_prealloc_size == 96 && cache_prealloc_nr == 384);
	require(cache_log_count == 1);
	require(cache_log_events[0] == 3 && cache_log_ptrs[0] == &cache);
	mix(&digest, (unsigned long)cache_prealloc_nr);

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache_elem0 = (struct kmalloc_cache_header *)cache_payload(0);
	cache_elem1 = (struct kmalloc_cache_header *)cache_payload(1);
	push_cache_alloc(cache_elem0);
	push_cache_alloc(cache_elem1);
	push_cache_alloc(NULL);
	require(kmalloc_cache_prealloc_result(&cache, 72, 3,
			fake_cache_alloc, fake_cache_log) == 2);
	require(cache_alloc_index == 3);
	require(cache_alloc_sizes[0] == 72 && cache_alloc_flags[0] == 0x2UL);
	require(cache_header(0)->cache == &cache);
	require(cache_header(1)->cache == &cache);
	require(cache.next == cache_elem1);
	require(cache_elem1->next == cache_elem0);
	require(cache_elem0->next == NULL);
	require(cache_log_count == 1 && cache_log_events[0] == 2);
	mix(&digest, (unsigned long)cache_alloc_index);

	reset_cache_fake();
	memset(&cache, 0, sizeof(cache));
	cache.next = (struct kmalloc_cache_header *)cache_payload(0);
	require(kmalloc_cache_prealloc_result(&cache, 64, 2,
			fake_cache_alloc, fake_cache_log) == 0);
	require(cache_alloc_index == 0 && cache_log_count == 0);
	mix(&digest, (unsigned long)(cache_alloc_index + cache_log_count));

	INIT_LIST_HEAD(&free_list);
	INIT_LIST_HEAD(&a->list);
	INIT_LIST_HEAD(&b->list);
	INIT_LIST_HEAD(&c->list);

	___kmalloc_init_chunk_result(a, 32);
	current_cpu = 8;
	___kmalloc_init_chunk_result(b, 48);
	current_cpu = 9;
	___kmalloc_init_chunk_result(c, 16);

	require(a->front_magic == 0x5c5c5c5c && a->end_magic == 0x6d6d6d6d);
	require(a->cpu_id == 7 && b->cpu_id == 8 && c->cpu_id == 9);

	___kmalloc_insert_chunk_result(&free_list, c);
	___kmalloc_insert_chunk_result(&free_list, a);
	___kmalloc_insert_chunk_result(&free_list, b);

	chunk = kmalloc_header_from_list(free_list.next);
	require(chunk == a);
	require(kmalloc_header_from_list(a->list.next) == b);
	require(kmalloc_header_from_list(b->list.next) == c);

	___kmalloc_consolidate_list_result(&free_list);
	require(a->size == 32 + (int)sizeof(struct kmalloc_header) + 48);
	require(kmalloc_header_from_list(a->list.next) == c);
	require(c->list.next == &free_list);

	for (chunk = kmalloc_header_from_list(free_list.next);
	     &chunk->list != &free_list;
	     chunk = kmalloc_header_from_list(chunk->list.next)) {
		mix(&digest, (unsigned long)((char *)chunk - (char *)arena));
		mix(&digest, (unsigned long)chunk->size);
		mix(&digest, (unsigned long)chunk->cpu_id);
		count++;
	}
	require(count == 2);

	INIT_LIST_HEAD(&free_list);
	INIT_LIST_HEAD(&remote_list);
	a = (struct kmalloc_header *)(arena + 0);
	b = (struct kmalloc_header *)
		((char *)a + sizeof(struct kmalloc_header) + 32);
	c = (struct kmalloc_header *)
		((char *)b + sizeof(struct kmalloc_header) + 48);
	___kmalloc_init_chunk_result(a, 32);
	___kmalloc_init_chunk_result(b, 48);
	___kmalloc_init_chunk_result(c, 16);
	___kmalloc_insert_chunk_result(&remote_list, c);
	___kmalloc_insert_chunk_result(&remote_list, a);
	___kmalloc_insert_chunk_result(&free_list, b);
	reset_fake_kmalloc();
	require(kmalloc_consolidate_free_list_result(&remote_list, &free_list,
			&remote_lock, fake_remote_lock, fake_remote_unlock) == 2);
	require(remote_list.next == &remote_list && remote_list.prev == &remote_list);
	require(kmalloc_header_from_list(free_list.next) == a);
	require(a->size == 32 + 48 + 16 + 2 * (int)sizeof(struct kmalloc_header));
	require(a->list.next == &free_list);
	require(remote_lock_count == 1 && remote_unlock_count == 1);
	require(remote_lock_addr == (unsigned long)&remote_lock);
	require(remote_unlock_addr == (unsigned long)&remote_lock);
	mix(&digest, (unsigned long)a->size);
	mix(&digest, (unsigned long)remote_lock_count);

	INIT_LIST_HEAD(&free_list);
	a = (struct kmalloc_header *)(arena + 0);
	current_cpu = 3;
	___kmalloc_init_chunk_result(a, 128);
	___kmalloc_insert_chunk_result(&free_list, a);
	reset_fake_kmalloc();
	chunk = ___kmalloc_body_result(33, 0x22, &free_list,
			fake_irq_save, fake_irq_restore, fake_alloc_pages);
	require(chunk == (void *)((char *)a + sizeof(struct kmalloc_header)));
	require(a->size == 64);
	b = (struct kmalloc_header *)((char *)a + sizeof(struct kmalloc_header) + 64);
	require(kmalloc_header_from_list(free_list.next) == b);
	require(b->size == 128 - 64 - (int)sizeof(struct kmalloc_header));
	require(irq_save_count == 1 && irq_restore_count == 1);
	require(last_restore_flags == 0x5000UL);
	require(alloc_pages_count == 0);
	mix(&digest, (unsigned long)a->size);
	mix(&digest, (unsigned long)b->size);

	INIT_LIST_HEAD(&free_list);
	a = (struct kmalloc_header *)(arena + 192);
	current_cpu = 4;
	___kmalloc_init_chunk_result(a, 32);
	___kmalloc_insert_chunk_result(&free_list, a);
	reset_fake_kmalloc();
	chunk = ___kmalloc_body_result(32, 0x23, &free_list,
			fake_irq_save, fake_irq_restore, fake_alloc_pages);
	require(chunk == (void *)((char *)a + sizeof(struct kmalloc_header)));
	require(free_list.next == &free_list);
	require(a->size == 32);
	require(alloc_pages_count == 0);
	mix(&digest, (unsigned long)a->size);

	INIT_LIST_HEAD(&free_list);
	reset_fake_kmalloc();
	current_cpu = 5;
	chunk = ___kmalloc_body_result(100, 0x24, &free_list,
			fake_irq_save, fake_irq_restore, fake_alloc_pages);
	a = (struct kmalloc_header *)page_arena;
	b = (struct kmalloc_header *)((char *)a + sizeof(struct kmalloc_header) + 128);
	require(chunk == (void *)((char *)a + sizeof(struct kmalloc_header)));
	require(alloc_pages_count == 1);
	require(alloc_pages_npages == 1);
	require(alloc_pages_flag == 0x24);
	require(alloc_pages_is_user == 0);
	require(a->size == 128);
	require(kmalloc_header_from_list(free_list.next) == b);
	require(b->size == 4096 - 128 - 2 * (int)sizeof(struct kmalloc_header));
	require(irq_save_count == 1 && irq_restore_count == 1);
	mix(&digest, (unsigned long)b->size);

	INIT_LIST_HEAD(&free_list);
	reset_fake_kmalloc();
	alloc_pages_fail = 1;
	chunk = ___kmalloc_body_result(4097, 0x25, &free_list,
			fake_irq_save, fake_irq_restore, fake_alloc_pages);
	require(chunk == NULL);
	require(alloc_pages_count == 1);
	require(alloc_pages_npages == 2);
	require(irq_save_count == 1 && irq_restore_count == 1);
	mix(&digest, (unsigned long)alloc_pages_npages);

	INIT_LIST_HEAD(&free_list);
	reset_fake_kmalloc();
	chunk = ___kmalloc_body_result(16, 0x26, &free_list,
			fake_irq_save, fake_irq_restore, NULL);
	require(chunk == NULL);
	require(irq_save_count == 0 && irq_restore_count == 0);

	INIT_LIST_HEAD(&free_list);
	a = (struct kmalloc_header *)(arena + 0);
	b = (struct kmalloc_header *)((char *)a + sizeof(struct kmalloc_header) + 64);
	current_cpu = 6;
	___kmalloc_init_chunk_result(a, 64);
	___kmalloc_init_chunk_result(b, 32);
	___kmalloc_insert_chunk_result(&free_list, b);
	reset_fake_kmalloc();
	require(___kfree_body_result((char *)a + sizeof(struct kmalloc_header),
			&free_list,
			__builtin_offsetof(struct cpu_local_var,
				remote_free_list_lock),
			__builtin_offsetof(struct cpu_local_var, remote_free_list),
			fake_irq_save, fake_irq_restore, fake_get_cpu_local_var,
			fake_remote_lock, fake_remote_unlock, fake_corruption) == 0);
	require(kmalloc_header_from_list(free_list.next) == a);
	require(a->size == 64 + (int)sizeof(struct kmalloc_header) + 32);
	require(a->list.next == &free_list);
	require(irq_save_count == 1 && irq_restore_count == 1);
	require(remote_lock_count == 0 && corruption_count == 0);
	mix(&digest, (unsigned long)a->size);

	INIT_LIST_HEAD(&free_list);
	a = (struct kmalloc_header *)(arena + 256);
	current_cpu = 9;
	___kmalloc_init_chunk_result(a, 48);
	current_cpu = 1;
	INIT_LIST_HEAD(&clv_storage[9].remote_free_list);
	reset_fake_kmalloc();
	require(___kfree_body_result((char *)a + sizeof(struct kmalloc_header),
			&free_list,
			__builtin_offsetof(struct cpu_local_var,
				remote_free_list_lock),
			__builtin_offsetof(struct cpu_local_var, remote_free_list),
			fake_irq_save, fake_irq_restore, fake_get_cpu_local_var,
			fake_remote_lock, fake_remote_unlock, fake_corruption) == 0);
	require(remote_lock_count == 1 && remote_unlock_count == 1);
	require(remote_lock_addr == (unsigned long)&clv_storage[9].remote_free_list_lock);
	require(remote_unlock_addr == remote_lock_addr);
	require(remote_unlock_flags == 0x6000UL);
	require(kmalloc_header_from_list(
			clv_storage[9].remote_free_list.next) == a);
	require(irq_save_count == 1 && irq_restore_count == 1);
	mix(&digest, remote_lock_addr & 0xfffUL);

	reset_fake_kmalloc();
	require(___kfree_body_result(NULL, &free_list,
			__builtin_offsetof(struct cpu_local_var,
				remote_free_list_lock),
			__builtin_offsetof(struct cpu_local_var, remote_free_list),
			fake_irq_save, fake_irq_restore, fake_get_cpu_local_var,
			fake_remote_lock, fake_remote_unlock, fake_corruption) == 0);
	require(irq_save_count == 0 && irq_restore_count == 0);

	a = (struct kmalloc_header *)(arena + 384);
	current_cpu = 2;
	___kmalloc_init_chunk_result(a, 16);
	a->front_magic = 0;
	reset_fake_kmalloc();
	require(___kfree_body_result((char *)a + sizeof(struct kmalloc_header),
			&free_list,
			__builtin_offsetof(struct cpu_local_var,
				remote_free_list_lock),
			__builtin_offsetof(struct cpu_local_var, remote_free_list),
			fake_irq_save, fake_irq_restore, fake_get_cpu_local_var,
			fake_remote_lock, fake_remote_unlock, fake_corruption) == -22);
	require(corruption_count == 1);
	require(corruption_ptr == (char *)a + sizeof(struct kmalloc_header));
	require(irq_save_count == 1 && irq_restore_count == 0);

	init_track_heads();
	reset_track_fake();
	push_track_alloc(track_payloads[0]);
	push_track_alloc(&track_entries[0]);
	push_track_alloc(track_file_storage[0]);
	push_track_alloc(&track_addr_entries[0]);
	chunk = kmalloc_track_alloc_result(64, 0x44, "track.c", 17,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 11,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[0]);
	hash = track_hash_for("track.c", 17, 64);
	addr_hash = addr_hash_for(track_payloads[0]);
	require(track_alloc_index == 4);
	require(track_alloc_sizes[0] == 64 && track_alloc_flags[0] == 0x44);
	require(track_alloc_sizes[1] == (int)sizeof(struct kmalloc_track_entry));
	require(track_alloc_flags[1] == 0x2);
	require(track_alloc_sizes[2] == test_strlen("track.c") + 1);
	require(track_alloc_sizes[3] == (int)sizeof(struct kmalloc_track_addr_entry));
	require(track_lock_count == 3 && track_unlock_count == 3);
	require(track_lock_addrs[0] == (unsigned long)&track_hash_locks[hash]);
	require(track_lock_addrs[1] ==
			(unsigned long)&track_entries[0].addr_list_lock);
	require(track_lock_addrs[2] == (unsigned long)&addr_hash_locks[addr_hash]);
	require(track_spin_init_count == 1);
	require(track_spin_init_addr ==
			(unsigned long)&track_entries[0].addr_list_lock);
	require(track_entries[0].line == 17 && track_entries[0].size == 64);
	require(track_entries[0].alloc_count.counter == 1);
	require(test_streq(track_entries[0].file, "track.c"));
	require(kmalloc_track_entry_from_hash(track_hash_heads[hash].next) ==
			&track_entries[0]);
	require(kmalloc_track_addr_from_list(
			track_entries[0].addr_list.next) ==
			&track_addr_entries[0]);
	require(kmalloc_track_addr_from_hash(
			addr_hash_heads[addr_hash].next) ==
			&track_addr_entries[0]);
	require(track_addr_entries[0].addr == track_payloads[0]);
	require(track_addr_entries[0].runcount == 11);
	require(track_addr_entries[0].entry == &track_entries[0]);
	require(track_log_count == 2);
	require(track_log_events[0] == 3 && track_log_events[1] == 5);
	require(kmalloc_track_find_entry_result(64, "track.c", 17,
			track_hash_heads) == &track_entries[0]);
	mix(&digest, (unsigned long)track_entries[0].alloc_count.counter);
	mix(&digest, (unsigned long)track_addr_entries[0].runcount);

	reset_track_fake();
	push_track_alloc(track_payloads[1]);
	push_track_alloc(&track_addr_entries[1]);
	chunk = kmalloc_track_alloc_result(64, 0x45, "track.c", 17,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 12,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[1]);
	require(track_alloc_index == 2);
	require(track_entries[0].alloc_count.counter == 2);
	require(track_addr_entries[1].entry == &track_entries[0]);
	require(track_addr_entries[1].runcount == 12);
	require(track_log_count == 1 && track_log_events[0] == 5);
	mix(&digest, (unsigned long)track_entries[0].alloc_count.counter);

	reset_track_fake();
	push_track_alloc(track_payloads[2]);
	chunk = kmalloc_track_alloc_result(96, 0x46, "nodebug.c", 19,
			NULL, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 13,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[2]);
	require(track_alloc_index == 1);
	require(track_lock_count == 0 && track_log_count == 0);
	mix(&digest, (unsigned long)track_alloc_sizes[0]);

	reset_track_fake();
	chunk = kmalloc_track_alloc_result(32, 0x47, "fail.c", 20,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 14,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == NULL);
	require(track_alloc_index == 1);
	require(track_lock_count == 0);

	reset_track_fake();
	push_track_alloc(track_payloads[3]);
	push_track_alloc(NULL);
	chunk = kmalloc_track_alloc_result(40, 0x48, "entryfail.c", 21,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 15,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[3]);
	require(track_lock_count == 1 && track_unlock_count == 1);
	require(track_log_count == 1 && track_log_events[0] == 1);

	reset_track_fake();
	push_track_alloc(track_payloads[4]);
	push_track_alloc(&track_entries[1]);
	push_track_alloc(NULL);
	chunk = kmalloc_track_alloc_result(48, 0x49, "filefail.c", 22,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 16,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[4]);
	require(track_free_count == 1 && track_freed[0] == &track_entries[1]);
	require(track_log_count == 1 && track_log_events[0] == 2);

	reset_track_fake();
	push_track_alloc(track_payloads[5]);
	push_track_alloc(NULL);
	chunk = kmalloc_track_alloc_result(64, 0x4a, "track.c", 17,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, 17,
			fake_track_alloc, fake_track_free, fake_track_lock,
			fake_track_unlock, fake_track_spin_init,
			fake_track_log);
	require(chunk == (void *)track_payloads[5]);
	require(track_entries[0].alloc_count.counter == 3);
	require(track_log_count == 1 && track_log_events[0] == 4);
	mix(&digest, (unsigned long)track_entries[0].alloc_count.counter);

	reset_track_fake();
	require(kmalloc_track_free_result(track_payloads[1], "track.c", 101,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, fake_track_free,
			fake_track_lock, fake_track_unlock, fake_invalid_free,
			fake_track_log) == 0);
	require(track_entries[0].alloc_count.counter == 2);
	require(track_free_count == 2);
	require(track_freed[0] == &track_addr_entries[1]);
	require(track_freed[1] == track_payloads[1]);
	require(track_log_count == 1 && track_log_events[0] == 6);
	mix(&digest, (unsigned long)track_entries[0].alloc_count.counter);

	track_entries[0].alloc_count.counter = 1;
	reset_track_fake();
	require(kmalloc_track_free_result(track_payloads[0], "track.c", 102,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, fake_track_free,
			fake_track_lock, fake_track_unlock, fake_invalid_free,
			fake_track_log) == 0);
	require(track_free_count == 4);
	require(track_freed[0] == &track_addr_entries[0]);
	require(track_freed[1] == track_file_storage[0]);
	require(track_freed[2] == &track_entries[0]);
	require(track_freed[3] == track_payloads[0]);
	require(track_hash_heads[hash].next == &track_hash_heads[hash]);
	require(track_log_count == 2);
	require(track_log_events[0] == 6 && track_log_events[1] == 7);

	reset_track_fake();
	require(kmalloc_track_free_result(track_payloads[6], "badfree.c", 23,
			(char *)1, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, fake_track_free,
			fake_track_lock, fake_track_unlock, fake_invalid_free,
			fake_track_log) == -22);
	require(invalid_free_count == 1);
	require(invalid_free_ptr == track_payloads[6]);
	require(invalid_free_line == 23);
	require(test_streq(invalid_free_file, "badfree.c"));
	require(track_free_count == 0);

	reset_track_fake();
	require(kmalloc_track_free_result(track_payloads[7], "nodebug.c", 24,
			NULL, track_hash_heads, track_hash_locks,
			addr_hash_heads, addr_hash_locks, fake_track_free,
			fake_track_lock, fake_track_unlock, fake_invalid_free,
			fake_track_log) == 0);
	require(track_free_count == 1 && track_freed[0] == track_payloads[7]);
	require(track_lock_count == 0 && invalid_free_count == 0);
	mix(&digest, (unsigned long)track_free_count);

	initialized = 0;
	reset_track_fake();
	require(mem_track_hashes_init_result(&initialized, track_hash_heads,
			track_hash_locks, addr_hash_heads, addr_hash_locks,
			KMALLOC_TRACK_HASH_SIZE, fake_track_spin_init) == 1);
	require(initialized == 1);
	require(track_spin_init_count == KMALLOC_TRACK_HASH_SIZE * 2);
	require(track_hash_heads[13].next == &track_hash_heads[13]);
	require(addr_hash_heads[29].prev == &addr_hash_heads[29]);
	require(mem_track_hashes_init_result(&initialized, track_hash_heads,
			track_hash_locks, addr_hash_heads, addr_hash_locks,
			KMALLOC_TRACK_HASH_SIZE, fake_track_spin_init) == 0);
	require(track_spin_init_count == KMALLOC_TRACK_HASH_SIZE * 2);
	mix(&digest, (unsigned long)track_spin_init_count);

	{
		char *memdebug_slot = NULL;

		memset(&clv_storage[0], 0, sizeof(clv_storage[0]));
		memset(track_hash_heads, 0, sizeof(track_hash_heads));
		memset(addr_hash_heads, 0, sizeof(addr_hash_heads));
		initialized = 0;
		reset_track_fake();
		require(mem_kmalloc_init_body_result(&memdebug_slot,
				&initialized, track_hash_heads, track_hash_locks,
				addr_hash_heads, addr_hash_locks,
				KMALLOC_TRACK_HASH_SIZE,
				fake_kmalloc_init_this_cpu,
				fake_kmalloc_init_register,
				fake_kmalloc_init_find_command,
				fake_track_spin_init) == 1);
		require(kmalloc_init_this_cpu_count == 1);
		require(kmalloc_init_register_count == 1);
		require(clv_storage[0].free_list.next == &clv_storage[0].free_list);
		require(clv_storage[0].remote_free_list.prev ==
				&clv_storage[0].remote_free_list);
		require(clv_storage[0].kmalloc_initialized == 1);
		require(kmalloc_init_find_count == 1);
		require(test_streq(kmalloc_init_find_name, "memdebug"));
		require(memdebug_slot == kmalloc_init_memdebug_token);
		require(initialized == 1);
		require(track_spin_init_count == KMALLOC_TRACK_HASH_SIZE * 2 + 1);
		require(track_hash_heads[21].next == &track_hash_heads[21]);
		require(addr_hash_heads[37].prev == &addr_hash_heads[37]);
		mix(&digest, (unsigned long)kmalloc_init_register_count);
		mix(&digest, (unsigned long)track_spin_init_count);

		memset(&clv_storage[0], 0, sizeof(clv_storage[0]));
		reset_track_fake();
		require(mem_kmalloc_init_body_result(&memdebug_slot,
				&initialized, track_hash_heads, track_hash_locks,
				addr_hash_heads, addr_hash_locks,
				KMALLOC_TRACK_HASH_SIZE,
				fake_kmalloc_init_this_cpu,
				fake_kmalloc_init_register,
				fake_kmalloc_init_find_command,
				fake_track_spin_init) == 0);
		require(kmalloc_init_register_count == 1);
		require(kmalloc_init_find_count == 0);
		require(clv_storage[0].kmalloc_initialized == 1);
		require(track_spin_init_count == 1);
		mix(&digest, (unsigned long)track_spin_init_count);
	}

	init_track_heads();
	reset_track_fake();
	km_runcount = 55;
	hash = track_hash_for("leak.c", 77, 88);
	track_entries[2].file = "leak.c";
	track_entries[2].line = 77;
	track_entries[2].size = 88;
	track_entries[2].alloc_count.counter = 2;
	INIT_LIST_HEAD(&track_entries[2].hash);
	INIT_LIST_HEAD(&track_entries[2].addr_list);
	list_add(&track_entries[2].hash, &track_hash_heads[hash]);
	track_addr_entries[2].addr = track_payloads[2];
	track_addr_entries[2].runcount = 55;
	track_addr_entries[3].addr = track_payloads[3];
	track_addr_entries[3].runcount = 54;
	INIT_LIST_HEAD(&track_addr_entries[2].list);
	INIT_LIST_HEAD(&track_addr_entries[3].list);
	list_add(&track_addr_entries[2].list, &track_entries[2].addr_list);
	list_add(&track_addr_entries[3].list, &track_entries[2].addr_list);
	require(kmalloc_memcheck_result(track_hash_heads, track_hash_locks,
			&km_runcount, KMALLOC_TRACK_HASH_SIZE, fake_track_lock,
			fake_track_unlock, fake_track_noirq_lock,
			fake_track_noirq_unlock, fake_leak_log) == 1);
	require(km_runcount == 56);
	require(track_lock_count == KMALLOC_TRACK_HASH_SIZE);
	require(track_unlock_count == KMALLOC_TRACK_HASH_SIZE);
	require(track_noirq_lock_count == 1 && track_noirq_unlock_count == 1);
	require(leak_log_count == 3);
	require(leak_log_events[0] == 1 && leak_log_events[1] == 1);
	require(leak_log_events[2] == 2);
	require(leak_log_counts[2] == 1);
	require(leak_log_sizes[2] == 88);
	require(leak_log_runcounts[2] == 55);
	mix(&digest, (unsigned long)km_runcount);
	mix(&digest, (unsigned long)leak_log_count);

	printf("kmalloc_helpers ok digest=%016lx\n", digest);
	return 0;
}
