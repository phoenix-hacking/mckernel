#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

	#define VERIFY_READ 0
	#define VERIFY_WRITE 1
	#define EINVAL 22
	#define MCK_RLIM_MAX 20
	#define PLD_CPU_SET_MAX_CPUS 1024
	#define PLD_CPU_SET_SIZE (PLD_CPU_SET_MAX_CPUS / (8 * sizeof(unsigned long)))
	#define PLD_PROCESS_NUMA_MASK_BITS 256
	#define PLD_NUMA_MASK_WORDS \
		(PLD_PROCESS_NUMA_MASK_BITS / (sizeof(unsigned long) * 8))
	#define AUXV_LEN 38
	#define PAGE_SIZE 4096UL
	#define PAGE_SHIFT 12
	#define LARGE_PAGE_SHIFT 21
	#define LARGE_PAGE_SIZE (1UL << LARGE_PAGE_SHIFT)
	#define LARGE_PAGE_MASK (~(LARGE_PAGE_SIZE - 1))
	#define USER_STACK_PAGE_MASK LARGE_PAGE_MASK
	#define USER_STACK_PAGE_SHIFT LARGE_PAGE_SHIFT
	#define USER_STACK_PREPAGE_SIZE LARGE_PAGE_SIZE
	#define USER_STACK_PAGE_P2ALIGN (LARGE_PAGE_SHIFT - PAGE_SHIFT)
	#define IHK_MC_AP_NOWAIT 0x000002UL
	#define IHK_MC_AP_USER 0x001000UL
	#define SCHED_NORMAL 0
	#define SS_DISABLE 2
	#define MPOL_NO_STACK 0x02UL
	#define IHK_UCR_STACK_POINTER 1
	#define IHK_UCR_PROGRAM_COUNTER 2
	#define VR_IO_NOCACHE 0x100UL
	#define VR_STACK 0x1UL
	#define VR_AP_USER 0x4UL
	#define VR_REMOTE 0x200UL
	#define VR_WRITE_COMBINED 0x400UL
	#define VR_DONTFORK 0x800UL
	#define VR_DEMAND_PAGING 0x1000UL
	#define VR_PRIVATE 0x2000UL
#define VR_XPMEM 0x40000000UL
#define VR_PROT_READ 0x00010000UL
#define VR_PROT_WRITE 0x00020000UL
#define VR_PROT_EXEC 0x00040000UL
#define VR_PROT_MASK 0x00070000UL
#define VR_MAXPROT_MASK 0x00700000UL
#define NOPHYS (~0UL)
#define PF_WRITE (1UL << 1)
#define PF_USER (1UL << 2)
#define PF_INSTR (1UL << 4)
#define PF_PATCH (1UL << 29)
#define PF_POPULATE (1UL << 30)
#define PROCESS_ADD_RANGE_MAP_SKIP 0
#define PROCESS_ADD_RANGE_MAP_UPDATE 1
#define PROCESS_ADD_RANGE_MAP_MARK_XPMEM 2
#define PROCESS_ADD_RANGE_MAP_DEMAND 3
#define PROCESS_ADD_RANGE_LOG_ALLOC_FAILED 1
#define PROCESS_ADD_RANGE_LOG_INSERT_FAILED 2
#define PROCESS_ADD_RANGE_LOG_PREP_FAILED 3
#define PROCESS_ADD_RANGE_LOG_DEMAND 4
#define PROCESS_ADD_RANGE_LOG_BOUNDS_FAILED 5
#define PROCESS_VM_RANGE_INSERT_LOG_OVERLAP 1
#define PROCESS_VM_RANGE_INSERT_LOG_SUCCESS 2
#define PROCESS_RANGE_PUBLIC_LOG_LOOKUP_ENTER 1
#define PROCESS_RANGE_PUBLIC_LOG_LOOKUP_EXIT 2
#define PROCESS_RANGE_PUBLIC_LOG_NEXT_ENTER 3
#define PROCESS_RANGE_PUBLIC_LOG_NEXT_EXIT 4
#define PROCESS_RANGE_PUBLIC_LOG_PREVIOUS_ENTER 5
#define PROCESS_RANGE_PUBLIC_LOG_PREVIOUS_EXIT 6
#define PROCESS_RANGE_PUBLIC_LOG_EXTEND_ENTER 7
#define PROCESS_RANGE_PUBLIC_LOG_EXTEND_EXIT 8
#define PROCESS_CHANGE_PROT_PUBLIC_LOG_ENTER 1
#define PROCESS_CHANGE_PROT_PUBLIC_LOG_ERROR 2
#define PROCESS_CHANGE_PROT_PUBLIC_LOG_EXIT 3
#define PROCESS_FREE_RANGE_PT_SKIP 0
#define PROCESS_FREE_RANGE_PT_FREE 1
#define PROCESS_FREE_RANGE_PT_CLEAR 2
#define MF_ZEROFILL 0x0010
#define VPTEF_SKIP_NULL 0x0001
#define E2BIG 7
#define PROCESS_REMOVE_STRAIGHT_NO_CONVERT 0
#define PROCESS_REMOVE_STRAIGHT_NEED_RANGE 1
#define PROCESS_REMOVE_STRAIGHT_CONVERTED 2
#define PROCESS_REMOVE_RANGE_LOG_NO_STRAIGHT 1
#define PROCESS_REMOVE_RANGE_LOG_CONVERTED 2
#define PROCESS_REMOVE_RANGE_LOG_SPLIT_FAILED 3
#define PROCESS_REMOVE_RANGE_LOG_FREE_FAILED 4
#define PROCESS_REMOVE_RANGE_LOG_DONE 5
#define PROCESS_FREE_BODY_LOG_PLAN_FAILED 1
#define PROCESS_FREE_BODY_LOG_PT_FREE_FAILED 2
	#define PROCESS_FREE_BODY_LOG_PT_CLEAR_FAILED 3
	#define PROCESS_FREE_BODY_LOG_TOFU_REMOVED 4
	#define PROCESS_FREE_BODY_LOG_FINALIZE_FAILED 5
	#define PROCESS_FREE_BODY_LOG_DONE 6
	#define PROCESS_REMAP_RANGE_LOG_PGSHIFT 1
	#define PROCESS_REMAP_RANGE_LOG_VISIT_FAILED 2
	#define PROCESS_INIT_STACK_LOG_SIZE 1
	#define PROCESS_INIT_STACK_LOG_AP_USER 2
	#define PROCESS_INIT_STACK_LOG_ALLOC_FAILED 3
	#define PROCESS_INIT_STACK_LOG_ADD_FAILED 4
	#define PROCESS_INIT_STACK_LOG_PT_FAILED 5
	#define PROCESS_INIT_STACK_LOG_AUXV 6
	#define PROCESS_INIT_STACK_LOG_SIZE_MISMATCH 7
	#define PROCESS_INIT_STACK_LOG_ALIGN_MISMATCH 8
	#define PROCESS_INIT_STACK_LOG_INITIAL 9
	#define PROCESS_SPLIT_SHM_LOG_LOOKUP_FAILED 1
	#define PROCESS_SPLIT_SHM_LOG_UPDATE_FAILED 2
	#define MF_HUGETLBFS 0x100000U
	#define MF_SHM 0x40000U
	#define PTATTR_ACTIVE 0x01UL
	#define PTATTR_WRITABLE 0x02UL
	#define PTATTR_USER 0x04UL
#define PTATTR_NO_EXECUTE 0x8000000000000000UL
#define PTATTR_UNCACHABLE 0x10000UL
#define PTATTR_FOR_USER 0x20000UL
#define PTATTR_WRITE_COMBINED 0x40000UL
#define PS_EXITED 0x10
#define PT_TRACED 0x80
#define PT_TRACE_EXEC 0x100
#define PT_TRACE_SYSCALL 0x200
#define PROCESS_PTRACE_TRACEME_LOG_ENTER 1
#define PROCESS_PTRACE_TRACEME_LOG_PARENT 2
#define PROCESS_PTRACE_TRACEME_LOG_RETURN 3
#define PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG 1
#define PTRACE_RESUME_SIGNAL_SOURCE_RECVSIG 2
#define UTI_STATE_RUNNING_IN_LINUX 2
#define UTI_STATE_EPILOGUE 3
#define CLONE_VM 0x00000100
#define CLONE_SIGHAND 0x00000800
#define WNOWAIT 0x01000000
#define HASH_SIZE 73
	#define SIGNAL_STOP_STOPPED 0x1
	#define SIGNAL_STOP_CONTINUED 0x2
	#define AT_IGNORE 1UL
	#define AT_PHDR 3UL
	#define AT_PAGESZ 6UL
	#define AT_CLKTCK 17UL
	#define AT_RANDOM 25UL
	#define AT_SYSINFO_EHDR 33UL

#undef __WEXITSTATUS
#undef __WTERMSIG
#undef __WSTOPSIG
#undef __WIFEXITED
#undef __WIFSIGNALED
#undef __WIFSTOPPED

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
	} while (0)

struct process_atomic_model {
	int counter;
};

__attribute__((weak))
int ihk_atomic_inc_return(struct process_atomic_model *v)
{
	return __sync_add_and_fetch(&v->counter, 1);
}

__attribute__((weak))
int ihk_atomic_dec_return(struct process_atomic_model *v)
{
	return __sync_sub_and_fetch(&v->counter, 1);
}

	struct rlimit {
		unsigned long rlim_cur;
		unsigned long rlim_max;
	};

	struct program_image_section {
		unsigned long vaddr;
		unsigned long len;
		unsigned long remote_pa;
		unsigned long filesz;
		unsigned long offset;
		int prot;
		char interp;
		char padding[3];
		void *fp;
	};

	struct program_load_desc {
		unsigned long magic;
		int num_sections;
		int cpu;
		int pid;
		int stack_prot;
		int pgid;
		int cred[8];
		int reloc;
		char enable_vdso;
		char padding[7];
		unsigned long entry;
		unsigned long user_start;
		unsigned long user_end;
		unsigned long rprocess;
		unsigned long rpgtable;
		unsigned long at_phdr;
		unsigned long at_phent;
		unsigned long at_phnum;
		unsigned long at_entry;
		unsigned long at_clktck;
		char *args;
		unsigned long args_len;
		char *envs;
		unsigned long envs_len;
		struct rlimit rlimit[MCK_RLIM_MAX];
		unsigned long interp_align;
		unsigned long mpol_flags;
		unsigned long mpol_threshold;
		unsigned long heap_extension;
		long stack_premap;
		unsigned long mpol_bind_mask;
		int mpol_mode;
		unsigned long mpol_nodemask[PLD_NUMA_MASK_WORDS];
		int thp_disable;
		int enable_uti;
		int uti_thread_rank;
		int uti_use_last_cpu;
		int straight_map;
		size_t straight_map_threshold;
		unsigned long mcexec_flags;
		int nr_processes;
		int process_rank;
		unsigned long cpu_set[PLD_CPU_SET_SIZE];
		int profile;
		struct program_image_section sections[0];
	};

extern unsigned long PROT_TO_VR_FLAG(unsigned long);
extern unsigned long VRFLAG_PROT_TO_MAXPROT(unsigned long);
extern unsigned long VRFLAG_MAXPROT_TO_PROT(unsigned long);
extern int __WEXITSTATUS(int);
extern int __WTERMSIG(int);
extern int __WSTOPSIG(int);
extern int __WIFEXITED(int);
extern int __WIFSIGNALED(int);
extern int __WIFSTOPPED(int);
extern int process_hash(int);
extern int thread_hash(int);
	extern unsigned long common_vrflag_to_ptattr(unsigned long, unsigned long, void *);
extern int process_split_pgshift_result(int, uintptr_t);
extern int process_add_range_bounds_result(unsigned long, unsigned long,
					   unsigned long, unsigned long);
extern int process_add_range_init_result(void *, unsigned long,
					 unsigned long, unsigned long,
					 void *, long, int, void *);
extern int process_copy_user_range_metadata_body_result(
	void *, const void *, void (*)(void *));
extern int process_copy_user_pte_args_init_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	void *, unsigned long, void *, long);
extern int process_copy_user_pte_buffer_body_result(void *, const void *,
						    size_t, int);
extern int process_copy_user_ranges_body_result(
	void *, void *, unsigned long, unsigned long, void *,
	unsigned long, unsigned long, unsigned long, unsigned long,
	void *, int, void (*)(unsigned long), void (*)(unsigned long),
	void *(*)(void *, unsigned long, unsigned long),
	void *(*)(void *, void *), void *(*)(unsigned long),
	void (*)(void *), int (*)(void *, void *),
	int (*)(void *, unsigned long, unsigned long, int, int,
		void *, void *),
	int (*)(void *, void *), void (*)(void *, void *, long));
extern int process_add_range_mapping_result(unsigned long, unsigned long,
					    unsigned long, unsigned long *,
					    int *);
extern int process_add_range_orchestrate_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *, long, int, void *, void **,
	void *(*)(unsigned long), void (*)(void *), int (*)(void *, void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	void (*)(void *, unsigned long, unsigned long), void (*)(void *),
	void (*)(unsigned long, unsigned long),
	void (*)(int, int, unsigned long, unsigned long));
extern int process_add_range_public_body_result(
	void *, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long, void *,
	long, int, void *, void **, void *(*)(unsigned long),
	void (*)(void *), int (*)(void *, void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	void (*)(void *, unsigned long, unsigned long), void (*)(void *),
	void (*)(unsigned long, unsigned long),
	void (*)(int, int, unsigned long, unsigned long));
extern int process_vm_range_insert_result(void *, void *, void *,
					  void (*)(int, void *, void *, void *),
					  void (*)(void *));
extern int process_extend_up_result(unsigned long, unsigned long, int,
				    unsigned long, unsigned long);
extern unsigned long process_change_prot_newflag_result(unsigned long,
							unsigned long);
extern void process_attr_delta_result(unsigned long, unsigned long,
				      unsigned long *, unsigned long *);
extern unsigned long process_private_file_setattr_result(int, unsigned long,
							 unsigned int,
							 unsigned long);
extern int process_remove_region_alignment_result(unsigned long, unsigned long);
extern int process_access_initial_result(int, unsigned long, unsigned long);
extern int process_access_adjacent_result(unsigned long, int, unsigned long);
extern int process_access_permission_result(int, unsigned long);
extern int process_range_cache_hit_result(unsigned long, unsigned long,
					  unsigned long, unsigned long);
extern int process_lookup_range_relation_result(unsigned long, unsigned long,
						unsigned long, unsigned long);
extern int process_range_cache_replace_result(void **, int, void *, void *);
extern int process_range_cache_store_result(void **, int, int *, void *);
extern void *process_lookup_memory_range_body_result(void *, unsigned long,
						     unsigned long);
extern void *process_next_memory_range_body_result(void *);
extern void *process_previous_memory_range_body_result(void *);
extern int process_extend_up_body_result(void *, void *, unsigned long);
extern void *process_lookup_memory_range_public_result(void *, unsigned long,
						       unsigned long,
						       void (*)(int, void *,
								 void *,
								 unsigned long,
								 unsigned long,
								 int));
extern void *process_next_memory_range_public_result(void *, void *,
						    void (*)(int, void *,
							      void *,
							      unsigned long,
							      unsigned long,
							      int));
extern void *process_previous_memory_range_public_result(void *, void *,
							void (*)(int, void *,
								  void *,
								  unsigned long,
								  unsigned long,
								  int));
extern int process_extend_up_public_result(void *, void *, unsigned long,
					   void (*)(int, void *, void *,
						    unsigned long,
						    unsigned long, int));
extern int process_change_prot_body_result(void *, void *, unsigned long,
					   unsigned long (*)(unsigned long,
							     unsigned long,
							     void *),
					   void (*)(unsigned long),
					   void (*)(unsigned long),
					   int (*)(void *, unsigned long,
						    unsigned long,
						    unsigned long,
						    unsigned long));
extern int process_change_prot_public_result(
	void *, void *, unsigned long,
	unsigned long (*)(unsigned long, unsigned long, void *),
	void (*)(unsigned long), void (*)(unsigned long),
	int (*)(void *, unsigned long, unsigned long, unsigned long,
		unsigned long),
	void (*)(int, void *, void *, unsigned long, int));
extern int process_update_page_table_body_result(
	void *, void *, unsigned long, unsigned long,
	unsigned long (*)(unsigned long, unsigned long, void *),
	unsigned long (*)(unsigned long),
	void (*)(unsigned long, unsigned long),
	int (*)(void *, void *, unsigned long, unsigned long,
		unsigned long, unsigned long, int, void *, int),
	void (*)(int));
extern int process_update_page_table_public_result(
	void *, void *, unsigned long, unsigned long,
	unsigned long (*)(unsigned long, unsigned long, void *),
	unsigned long (*)(unsigned long),
	void (*)(unsigned long, unsigned long),
	int (*)(void *, void *, unsigned long, unsigned long,
		unsigned long, unsigned long, int, void *, int),
	void (*)(int));
extern int process_access_ok_body_result(void *, int, unsigned long, size_t);
extern int process_access_ok_public_result(void *, int, unsigned long, size_t,
					   void *);
extern int process_do_page_fault_vm_body_result(
	void *, void *, unsigned long, unsigned long, int,
	void (*)(unsigned long), void (*)(unsigned long),
	void (*)(unsigned long), void (*)(unsigned long),
	int (*)(void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	int (*)(void *, void *, unsigned long, unsigned long));
extern int process_page_fault_vm_retry_body_result(
	void *, unsigned long, unsigned long, void *, unsigned long,
	unsigned long, int (*)(void *, unsigned long, unsigned long),
	void (*)(void), void (*)(void), void (*)(void *, void *));
extern int process_page_fault_vm_public_result(
	void *, void *, unsigned long, unsigned long, int, void *,
	unsigned long, unsigned long, void (*)(unsigned long),
	void (*)(unsigned long), void (*)(unsigned long),
	void (*)(unsigned long), int (*)(void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	int (*)(void *, void *, unsigned long, unsigned long),
	void (*)(void), void (*)(void), void (*)(void *, void *));
extern int process_populate_memory_body_result(
	void *, unsigned long, size_t, unsigned long, unsigned long,
	int (*)(void *, unsigned long, unsigned long), void (*)(void),
	void (*)(void), void (*)(void *, unsigned long, unsigned long,
				 unsigned long, size_t, int));
extern int process_populate_memory_public_result(
	void *, void *, unsigned long, size_t, unsigned long, unsigned long,
	int, void *, unsigned long, unsigned long, void (*)(unsigned long),
	void (*)(unsigned long), void (*)(unsigned long),
	void (*)(unsigned long), int (*)(void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	int (*)(void *, void *, unsigned long, unsigned long),
	void (*)(void), void (*)(void), void (*)(void *, void *),
	void (*)(void *, unsigned long, unsigned long, unsigned long, size_t,
		 int));
extern int process_range_end_commit_result(void *, uintptr_t);
extern int process_range_flag_commit_result(void *, unsigned long);
extern int process_range_stack_start_commit_result(void *, uintptr_t, int);
extern void process_remove_range_step_result(unsigned long, unsigned long,
					     unsigned long, unsigned long,
					     unsigned long, unsigned long,
					     int *, int *, int *, int *);
extern int process_split_range_init_result(const void *, void *, uintptr_t);
extern void process_split_range_commit_result(void *, uintptr_t);
extern int process_memobj_ref_direct_result(void *);
extern int process_memobj_unref_direct_result(void *);
extern int process_range_memobj_ref_or_direct_result(void *, void (*)(void *));
extern int process_range_memobj_unref_or_direct_result(void *, void (*)(void *));
extern int process_range_optional_memobj_ref_or_direct_result(
	void *, void (*)(void *));
extern int process_range_optional_memobj_unref_or_direct_result(
	void *, void (*)(void *));
extern int process_split_range_publish_result(void *, void *, void *,
					     uintptr_t, void **,
					     void (*)(void *),
					     int (*)(void *, void *));
extern int process_split_range_publish_body_result(
	void *, void *, void *, uintptr_t, void **, void (*)(void *),
	int (*)(void *, void *), void (*)(int));
extern int process_split_range_pt_body_result(
	void *, void *, unsigned long,
	int (*)(void *, void *, void *, void *), void (*)(int));
extern void *process_split_range_alloc_init_body_result(
	void *, void *, unsigned long, void *, unsigned long, unsigned long,
	int *, void *(*)(unsigned long, unsigned long),
	void (*)(void *, void *, unsigned long, void *));
extern int process_split_shm_update_body_result(
	void *, void *, unsigned long, unsigned long,
	int (*)(void *, long, int, uintptr_t *, unsigned long *),
	void *(*)(unsigned long),
	int (*)(void *, void *, void *, void *), void (*)(int, int));
extern int process_join_range_prepare_result(void *, const void *);
extern int process_join_range_body_result(void *, void *, void **, int,
					  void *, void *, void (*)(void *),
					  void (*)(void *),
					  int (*)(void *, void *, void *));
extern int process_free_range_pt_plan_result(const void *, unsigned long, int,
					     unsigned long, int,
					     unsigned long, int,
					     unsigned int, unsigned long *,
					     unsigned long *, int *,
					     int (*)(size_t, size_t *));
extern int process_free_range_finalize_result(void *, void *, void **, int,
					      void *, unsigned long, size_t *,
					      unsigned long,
					      void *(*)(unsigned long),
					      void (*)(void *, unsigned long),
					      int (*)(void *, unsigned long,
						       unsigned long),
					      void (*)(void *));
extern int process_free_memory_range_body_result(
	void *, void *, unsigned long, size_t *, unsigned long, int,
	int (*)(size_t, size_t *), void (*)(unsigned long),
	void (*)(unsigned long), void (*)(void *), void (*)(void *),
	int (*)(void *, void *, unsigned long, unsigned long, void *),
	int (*)(void *, void *, unsigned long, unsigned long),
	int (*)(void *, void *), void *(*)(unsigned long),
	void (*)(void *, unsigned long),
	int (*)(void *, unsigned long, unsigned long), void (*)(void *),
	void (*)(int, void *, void *, unsigned long, unsigned long, int));
extern int process_sync_memory_range_body_result(
	void *, void *, unsigned long, unsigned long, void *, void *,
	void (*)(unsigned long), void (*)(unsigned long),
	int (*)(void *, unsigned long, unsigned long, int, int, void *, void *),
	void (*)(void *, void *, unsigned long, unsigned long, int));
extern int process_remap_memory_range_body_result(
	void *, void *, unsigned long, unsigned long, long, void *, void *,
	void (*)(unsigned long), void (*)(unsigned long),
	int (*)(void *, unsigned long, unsigned long, int, int, void *, void *),
	void (*)(int, void *, void *, unsigned long, unsigned long, long, int,
		 int));
extern int process_invalidate_memory_range_body_result(
	void *, void *, unsigned long, unsigned long, void *, void *,
	void (*)(unsigned long), void (*)(unsigned long),
	void *(*)(void *, unsigned long, int, size_t *),
	int (*)(void *), int (*)(void *, size_t), int (*)(void *, size_t),
	int (*)(void *, size_t, unsigned int),
	int (*)(void *, void *, unsigned long, unsigned long, void *),
	int (*)(void *, unsigned long, unsigned long, int, int, void *, void *),
	void (*)(void *, void *, unsigned long, unsigned long, int));
extern int process_invalidate_one_page_body_result(
	void *, void *, void *, void *, int,
	int (*)(void *), int (*)(void *, size_t),
	unsigned long (*)(void *), void *(*)(unsigned long),
	long (*)(void *), void (*)(long, size_t, void *),
	void (*)(void *, void *), void (*)(unsigned long),
	int (*)(void *), int (*)(void *, size_t),
	int (*)(size_t), size_t (*)(int), int (*)(void *),
	void (*)(const char *),
	int (*)(void *, unsigned long, size_t),
	void (*)(void *, void *, void *, unsigned long, void *, int, int));
extern int process_remove_straight_convert_result(unsigned long, size_t,
						  const void *,
						  unsigned long,
						  unsigned long,
						  unsigned long *,
						  unsigned long *,
						  unsigned long *);
	extern int process_remove_memory_range_body_result(
		void *, unsigned long, unsigned long, int *, unsigned long, size_t,
		int (*)(void *, void *, unsigned long, void **),
		void (*)(void *, void *), int (*)(void *, void *),
		void (*)(int, void *, unsigned long, unsigned long, void *, int));
	extern int process_remove_region_body_result(
		void *, unsigned long, unsigned long, void *, void *, void *,
		void *);
	typedef void *(*process_init_stack_alloc_aligned_fn_t)(int, int,
			unsigned long, unsigned long);
	typedef void (*process_init_stack_free_pages_fn_t)(void *, int);
	typedef int (*process_init_stack_add_range_fn_t)(void *, unsigned long,
			unsigned long, unsigned long, unsigned long, int, void **);
	typedef unsigned long (*process_init_stack_virt_to_phys_fn_t)(void *);
	typedef unsigned long (*process_attr_from_vrflag_fn_t)(unsigned long,
			unsigned long, void *);
	typedef int (*process_init_stack_pt_set_range_fn_t)(void *, void *,
			unsigned long, unsigned long, unsigned long, unsigned long,
			int, void *, int);
	typedef unsigned long (*process_init_stack_hwcap_fn_t)(void);
	typedef void (*process_init_stack_modify_context_fn_t)(void *, int,
			unsigned long);
	typedef void (*process_init_stack_log_fn_t)(int,
			const unsigned long *);
	extern int process_init_stack_body_result(
		void *, struct program_load_desc *, unsigned long, int, char **,
		int, char **, unsigned long, int, unsigned long, int,
		unsigned long, unsigned long, int, unsigned long, unsigned long,
		unsigned long, int, unsigned long,
		process_init_stack_alloc_aligned_fn_t,
		process_init_stack_free_pages_fn_t,
		process_init_stack_add_range_fn_t,
		process_init_stack_virt_to_phys_fn_t,
		process_attr_from_vrflag_fn_t,
		process_init_stack_pt_set_range_fn_t,
		process_init_stack_hwcap_fn_t,
		process_init_stack_modify_context_fn_t,
		process_init_stack_log_fn_t);
	extern int process_ref_release_should_destroy_result(int);
extern int process_release_address_space_should_destroy_result(int);
extern int process_release_address_space_should_run_free_cb_result(unsigned long);
extern int process_release_address_space_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	void *, void *, void *);
extern int process_hold_address_space_public_result(void *, unsigned long,
						    void *);
extern int process_release_address_space_public_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	void *, void *, void *);
extern int process_detach_address_space_body_result(
	void *, int, unsigned long, unsigned long, void *);
extern int process_detach_address_space_public_result(
	void *, int, unsigned long, unsigned long, void *);
extern void *process_create_address_space_body_result(
	int, unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *, void *, void *, void *, void *);
extern int process_create_cpu_allowed_result(int, int);
extern int process_create_use_default_cpu_set_result(int);
extern int process_create_cpu_sets_body_result(unsigned long, unsigned long,
	unsigned long, unsigned long, int, int, int, void *, void *);
extern int process_allocated_object_zero_body_result(void *, unsigned long);
extern int process_vm_init_body_result(void *, void *, void *, int, void *,
				       void *, void *);
extern void *process_new_resource_set_body_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int, int, void *, void *, void *, void *);
extern int process_proc_init_body_result(
	void *, void *, unsigned long, int, int, unsigned long,
	unsigned long, void *, void *);
extern int process_sched_init_body_result(
	unsigned long, void *, int, void *, void *, void *, void *, void *,
	void *);
struct process_init_state_offsets {
	unsigned long pid_offset;
	unsigned long status_offset;
	unsigned long parent_offset;
	unsigned long ppid_parent_offset;
	unsigned long pgid_offset;
	unsigned long ruid_offset;
	unsigned long euid_offset;
	unsigned long suid_offset;
	unsigned long fsuid_offset;
	unsigned long rgid_offset;
	unsigned long egid_offset;
	unsigned long sgid_offset;
	unsigned long fsgid_offset;
	unsigned long mpol_flags_offset;
	unsigned long mpol_threshold_offset;
	unsigned long thp_disable_offset;
	unsigned long rlimit_offset;
	unsigned long rlimit_size;
	unsigned long cpu_set_offset;
	unsigned long cpu_set_size;
	unsigned long enable_uti_offset;
};
struct fake_process_ptrace_traceme_offsets;
struct fake_process_ptrace_attach_offsets;
extern int process_init_state_body_result(
	void *process, const void *parent,
	const struct process_init_state_offsets *offsets,
	int initial_pid, int running_status);
extern int process_init_links_body_result(
	void *process, unsigned long hash_list_offset,
	unsigned long siblings_list_offset,
	unsigned long ptraced_siblings_list_offset,
	unsigned long update_lock_offset,
	unsigned long report_threads_list_offset,
	unsigned long threads_list_offset,
	unsigned long children_list_offset,
	unsigned long ptraced_children_list_offset,
	unsigned long threads_lock_offset,
	unsigned long children_lock_offset,
	unsigned long coredump_lock_offset,
	unsigned long mckfd_lock_offset,
	unsigned long waitpid_q_offset,
	unsigned long refcount_offset,
	unsigned long monitoring_event_offset,
	void *rwlock_init_fn, void *spin_init_fn, void *waitq_init_fn,
	void *ref_set_fn);
extern int process_init_profile_body_result(
	void *process, unsigned long profile_lock_offset,
	unsigned long profile_events_offset, void *lock_init_fn);
extern int process_clone_thread_base_state_body_result(
	void *thread, const void *origin, unsigned long cpu_set_offset,
	unsigned long cpu_set_size, unsigned long in_kernel_offset);
extern int process_clone_thread_sched_state_body_result(
	void *thread, const void *origin, unsigned long sched_policy_offset,
	unsigned long sched_priority_offset);
extern int process_thread_sched_default_body_result(
	void *thread, unsigned long sched_policy_offset, int default_policy);
extern int process_create_thread_link_state_body_result(
	void *thread, void *process, void *vm, unsigned long thread_vm_offset,
	unsigned long thread_proc_offset, unsigned long process_vm_offset,
	unsigned long process_main_thread_offset);
extern int process_thread_exit_status_init_body_result(
	void *thread, unsigned long exit_status_offset, int exit_status);
extern int process_thread_spin_sleep_init_body_result(
	void *thread, unsigned long spin_sleep_lock_offset,
	unsigned long spin_sleep_offset, void *spin_init_fn);
extern int process_thread_sigmask_copy_body_result(
	void *thread, const void *origin, unsigned long sigmask_offset,
	unsigned long sigmask_size);
extern int process_clone_profile_state_body_result(
	void *thread, const void *origin, const void *process,
	unsigned long thread_profile_offset, unsigned long process_profile_offset);
extern int process_clone_fork_process_termsig_body_result(
	void *process, unsigned long termsig_offset, int termsig);
extern int process_clone_fork_saved_cmdline_body_result(
	void *process, const void *origin_process,
	unsigned long saved_cmdline_len_offset,
	unsigned long saved_cmdline_offset, unsigned long nowait_flag,
	void *alloc_fn);
extern int process_clone_fork_vm_policy_body_result(
	void *dst_vm, const void *src_vm, unsigned long numa_mask_offset,
	unsigned long numa_mask_size, unsigned long numa_mem_policy_offset,
	unsigned long region_offset, unsigned long region_size);
extern int process_clone_thread_shared_vm_state_body_result(
	void *thread, void *process, void *vm, unsigned long thread_vm_offset,
	unsigned long thread_proc_offset);
extern int process_clone_sigcommon_share_body_result(
	void *thread, const void *origin, unsigned long sigcommon_offset,
	unsigned long sigcommon_use_offset, void *ref_inc_fn);
extern int process_clone_sigcommon_action_copy_body_result(
	void *dst_sigcommon, const void *src_sigcommon,
	unsigned long action_offset, unsigned long action_size);
extern int process_clone_user_context_body_result(
	void *thread, const void *origin, unsigned long uctx_offset,
	unsigned long uctx_size, int stack_pointer_reg, unsigned long sp,
	int program_counter_reg, unsigned long pc,
	void (*modify_context_fn)(void *, int, unsigned long));
extern int process_clone_fork_profile_body_result(
	void *process, const void *origin_process, unsigned long profile_offset);
extern int process_clone_on_fork_vm_body_result(
	void *cpu_local, unsigned long on_fork_vm_offset, void *vm);
extern int process_mckfd_copy_body_result(void *dst, const void *src,
					  unsigned long mckfd_size);
extern void *process_sigcommon_alloc_init_body_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *, void *, void *, void *);
extern int process_thread_sigpending_init_body_result(
	void *, unsigned long, unsigned long, void *);
extern int process_thread_alloc_init_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	void *);
extern int process_thread_sigstack_disable_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long, int);
extern void *process_create_thread_body_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int, int, int, int, int, void *, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, void *(*)(int, unsigned long),
	void *(*)(unsigned long, unsigned long), void (*)(void *),
	void *(*)(int), void (*)(void *), int (*)(void *, void *),
	int (*)(void *, void *, void *),
	void (*)(void *, unsigned long, unsigned long, unsigned long),
	int (*)(void), void (*)(int, int, int), void (*)(unsigned long),
	void (*)(unsigned long), unsigned long (*)(unsigned long),
	void (*)(unsigned long, unsigned long), void (*)(void *));
extern int process_address_space_pid_detach_result(int *, int, int);
extern int process_clone_shares_vm_result(int);
extern int process_clone_shares_sighand_result(int);
extern int process_mckfd_should_dup_result(unsigned long);
extern int process_clone_copy_vm_thread_state_result(void *, const void *,
						     unsigned long,
						     unsigned long, void *,
						     const void *,
						     unsigned long, size_t);
extern int process_tid_index_for_thread_result(const void *, int,
					       unsigned long, unsigned long,
					       unsigned long);
extern int process_tid_index_found_result(int);
extern int process_tid_release_slot_result(void *, int, unsigned long,
					   unsigned long);
extern int process_tid_replace_slot_result(void *, int, unsigned long,
					   unsigned long, unsigned long, int);
extern int process_sigpending_cleanup_needed_result(int);
extern void *process_sigpending_pop_front_result(void *, unsigned long);
extern int process_list_is_linked_result(const void *);
extern void process_list_detach_result(void *);
extern int process_list_detach_counted_result(void *, size_t *);
extern void process_list_add_tail_result(void *, void *);
extern int process_list_add_tail_counted_result(void *, void *,
					       size_t *);
extern int process_list_move_tail_result(void *, void *);
extern int process_list_del_init_result(void *);
extern int process_child_reparent_result(void *, unsigned long, unsigned long,
					 void *, void *, void *, int);
extern int process_thread_report_attach_result(void *, unsigned long, int, int,
					       unsigned long, void *, void *,
					       void *);
extern int process_thread_report_detach_result(void *, unsigned long, void *,
					       void *);
extern int process_ptrace_main_detach_reparent_result(void *, unsigned long,
						      void *, void *, void *,
						      void *);
extern int process_ptrace_main_attach_reparent_result(void *, unsigned long,
						      void *, void *, void *);
extern int process_thread_termsig_clear_result(void *, unsigned long, int);
extern void *process_thread_ptrace_cleanup_result(void *, unsigned long,
						  unsigned long,
						  unsigned long);
extern int process_thread_ptrace_saved_context_clear_result(void *,
							    unsigned long);
extern int process_thread_ptrace_trace_syscall_update_result(void *,
							     unsigned long,
							     int);
extern void *process_thread_ptrace_pending_signal_take_result(void *,
							     unsigned long,
							     unsigned long,
							     int);
extern int process_ptrace_traceme_body_result(
	void *, void *, void *, void *,
	const struct fake_process_ptrace_traceme_offsets *, void *,
	void (*)(unsigned long, void *), void (*)(unsigned long, void *),
	int (*)(void *), void (*)(void *), void (*)(void *),
	void (*)(int, int, unsigned long, int));
extern int process_ptrace_attach_thread_body_result(
	void *, void *, const struct fake_process_ptrace_attach_offsets *,
	void *, void (*)(unsigned long, void *),
	void (*)(unsigned long, void *), int (*)(void *), void (*)(void *),
	void (*)(void *), void (*)(int, int, unsigned long, int));
extern int process_thread_signal_flags_reap_result(void *, unsigned long, int,
						   int);
extern int process_wait_exit_status_reap_result(void *, unsigned long, int);
extern int process_optional_ptr_should_free_result(unsigned long);
extern int process_hold_thread_warn_exited_result(int);
extern int process_sigcommon_release_should_destroy_result(int);
extern int process_destroy_thread_tid_action_result(int, int, int);
extern int process_thread_should_free_pages_result(int);
extern int process_release_vm_should_run_free_cb_result(unsigned long);
extern int process_release_mckfd_should_close_result(unsigned long);
extern int process_mckfd_push_head_result(void *, void *);
extern void *process_mckfd_pop_head_result(void *);
extern int process_mckfd_close_all_result(void *, unsigned long,
					  unsigned long);
extern int process_mckfd_drain_free_result(void *, unsigned long, void *);
extern int process_memory_range_free_all_result(void *, void *,
						unsigned long, void *,
						void *);
extern int process_flush_memory_body_result(void *, void *, void *, void *,
					    void *);
extern int process_free_all_memory_ranges_body_result(void *, void *, void *,
						      void *, void *);
extern int process_cpu_set_update_body_result(unsigned long, unsigned long,
					      int, int, int, void *, void *);
extern int process_cpu_set_public_result(int, unsigned long, unsigned long,
					 int, void *, void *);
extern int process_cpu_clear_public_result(int, unsigned long, unsigned long,
					   int, void *, void *);
extern int process_cpu_clear_and_set_public_result(int, int, unsigned long,
						   unsigned long, int, void *,
						   void *);
extern int process_ref_inc_result(void *, unsigned long, void *);
extern int process_ref_dec_and_test_result(void *, unsigned long, void *);
extern int process_ref_set_result(void *, unsigned long, int, void *);
extern int process_ref_inc_direct_result(void *, unsigned long);
extern int process_ref_dec_and_test_direct_result(void *, unsigned long);
extern int process_ref_set_direct_result(void *, unsigned long, int);
extern int process_ref_hold_body_result(void *, unsigned long, void *);
extern int process_hold_thread_body_result(void *, unsigned long,
					   unsigned long, void *, void *);
extern int process_release_process_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, void *, void *, void *, void *, void *,
	void *, void *, void *, void *, void *, void *);
extern int process_vm_policy_drain_free_result(void *, unsigned long, void *);
extern int process_release_vm_detach_process_result(void *, unsigned long,
						    unsigned long,
						    unsigned long,
						    unsigned long, void *,
						    void *);
extern int process_destroy_thread_optional_cleanup_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *, void *);
extern int process_release_sigcommon_body_result(
	void *, int, int, unsigned long, unsigned long, void *);
extern int process_release_sigcommon_public_body_result(
	void *, unsigned long, unsigned long, unsigned long, void *, void *);
extern int process_release_tid_body_result(
	void *, int, unsigned long, unsigned long, void *, int, void *);
	extern int process_replace_tid_body_result(
		void *, int, unsigned long, unsigned long, unsigned long, void *, int,
		int, void *);
	extern int process_chain_process_body_result(
		void *, void *, unsigned long, void *, void *, unsigned long,
		void *, void *, void *);
	extern int process_chain_thread_body_result(
		void *, void *, unsigned long, void *, void *, unsigned long,
		void *, unsigned long, void *, void *, void *, void *);
	extern int process_destroy_thread_body_result(
		void *, unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long, int,
		void *, void *, void *, void *, void *, void *, void *, void *,
		void *, void *, void *, void *, void *);
	extern void *process_find_thread_body_result(
		void *, unsigned long, void *, int, int, const void *,
		void *, void *, void *);
	extern void *process_find_process_body_result(
		void *, unsigned long, void *, int, const void *, void *, void *);
	extern int process_unlock_found_process_result(
		void *, unsigned long, void *, void *);
	extern int process_release_thread_body_result(
		void *, unsigned long, unsigned long, unsigned long, void *, void *,
		void *, void *, void *);
extern int process_release_vm_body_result(
	void *, unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *, void *, void *, void *, void *, void *, void *,
	void *, void *);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static int check_add_range_mapping(unsigned long *digest, unsigned long phys,
				   unsigned long flag, unsigned long range_flag,
				   int expected_action,
				   unsigned long expected_attr,
				   int expected_memclear)
{
	unsigned long attr = 0xfeedfaceUL;
	int memclear = -1;
	int action = process_add_range_mapping_result(phys, flag, range_flag,
						      &attr, &memclear);

	if (action != expected_action || attr != expected_attr ||
	    memclear != expected_memclear)
		return 1;

	mix(digest, (unsigned long)action);
	mix(digest, attr);
	mix(digest, (unsigned long)memclear);
	return 0;
}

struct fake_tid {
	int tid;
	void *thread;
};

struct fake_vm_state {
	unsigned long pad;
	void *vdso_addr;
	void *vvar_addr;
};

struct fake_sigstack {
	void *ss_sp;
	int ss_flags;
	unsigned long ss_size;
};

struct fake_thread_state {
	int pad;
	struct fake_sigstack sigstack;
};

struct fake_list_head {
	struct fake_list_head *next;
	struct fake_list_head *prev;
};

struct fake_pending {
	struct fake_list_head list;
	unsigned long value;
};

struct fake_process {
	int pid;
	void *ppid_parent;
	void *parent;
	void *main_thread;
	int children_lock;
	int threads_lock;
	struct fake_list_head children_list;
	struct fake_list_head ptraced_children_list;
	struct fake_list_head report_threads_list;
	struct fake_list_head siblings;
	struct fake_list_head ptraced_siblings;
	int group_exit_status;
	unsigned long value;
};

struct fake_thread {
	void *proc;
	int termsig;
	int exit_status;
	void *report_proc;
	struct fake_list_head report_siblings;
	int ptrace;
	int ptrace_saved_uctx_valid;
	void *ptrace_debugreg;
	void *ptrace_sendsig;
	void *ptrace_recvsig;
	int signal_flags;
	int clear_single_step_calls;
	int hold_calls;
	unsigned long value;
	void *fp_regs;
	void *coredump_regs;
};

struct fake_process_ptrace_traceme_offsets {
	unsigned long thread_proc_offset;
	unsigned long thread_report_proc_offset;
	unsigned long thread_report_siblings_list_offset;
	unsigned long thread_ptrace_offset;
	unsigned long thread_ptrace_debugreg_offset;
	unsigned long proc_pid_offset;
	unsigned long proc_parent_offset;
	unsigned long proc_main_thread_offset;
	unsigned long proc_children_lock_offset;
	unsigned long proc_threads_lock_offset;
	unsigned long proc_ptraced_siblings_list_offset;
	unsigned long proc_ptraced_children_list_offset;
	unsigned long proc_report_threads_list_offset;
};

	struct fake_process_ptrace_attach_offsets {
		unsigned long thread_proc_offset;
		unsigned long thread_report_proc_offset;
		unsigned long thread_report_siblings_list_offset;
	unsigned long thread_ptrace_debugreg_offset;
	unsigned long proc_pid_offset;
	unsigned long proc_parent_offset;
	unsigned long proc_main_thread_offset;
	unsigned long proc_children_lock_offset;
	unsigned long proc_threads_lock_offset;
	unsigned long proc_children_list_offset;
	unsigned long proc_siblings_list_offset;
	unsigned long proc_ptraced_siblings_list_offset;
	unsigned long proc_ptraced_children_list_offset;
		unsigned long proc_report_threads_list_offset;
	};

	struct fake_process_find_thread_offsets {
		unsigned long thread_hash_list_offset;
		unsigned long thread_tid_offset;
		unsigned long thread_proc_offset;
		unsigned long proc_pid_offset;
	};

	struct fake_process_find_process_offsets {
		unsigned long process_hash_list_offset;
		unsigned long process_pid_offset;
	};

struct fake_mckfd {
	struct fake_mckfd *next;
	int fd;
	int (*close_cb)(struct fake_mckfd *, void *);
};

struct fake_rb_node {
	unsigned long __rb_parent_color;
	struct fake_rb_node *rb_right;
	struct fake_rb_node *rb_left;
};

struct fake_rb_root {
	struct fake_rb_node *rb_node;
};

struct fake_memobj {
	void *ops;
	unsigned int flags;
	unsigned int status;
	size_t size;
	int refcnt;
	int padding;
	void **pages;
	int nr_pages;
	int padding2;
	char *path;
};

struct fake_memobj_ops {
	void (*free)(void *);
};

struct fake_address_space {
	void *page_table;
	void *opt;
	void *free_cb;
	int refcount;
	unsigned char rest[96];
};

struct fake_vm_regions {
	unsigned long vm_start;
	unsigned long vm_end;
	unsigned long text_start;
	unsigned long text_end;
	unsigned long data_start;
	unsigned long data_end;
	unsigned long brk_start;
	unsigned long brk_end;
	unsigned long brk_end_allocated;
	unsigned long map_start;
	unsigned long map_end;
	unsigned long stack_start;
	unsigned long stack_end;
	unsigned long user_start;
	unsigned long user_end;
};

struct fake_process_vm_full {
	struct fake_address_space *address_space;
	struct fake_rb_root vm_range_tree;
	struct fake_vm_regions region;
	void *proc;
	void *opt;
	void (*free_cb)(void *, void *);
	void *vdso_addr;
	void *vvar_addr;
	unsigned int page_table_lock;
	int memory_range_lock;
	int is_memory_range_lock_taken;
	int refcount;
	int exiting;
	int padding;
	long currss;
	unsigned long numa_mask[4];
	int numa_mem_policy;
	int il_prev;
	struct fake_rb_root vm_range_numa_policy_tree;
	struct fake_vm_range *range_cache[4];
	int range_cache_ind;
	void *swapinfo;
};

struct fake_release_process {
	void *vm;
	int pid;
	struct fake_mckfd *mckfd;
	unsigned long mckfd_lock;
};

struct fake_release_vm {
	int refcount;
	void *address_space;
	struct fake_release_process *proc;
	void (*free_cb)(void *, void *);
	void *opt;
	struct fake_rb_root policy_root;
};

struct fake_sigcommon {
	int use;
	unsigned int lock;
	struct fake_list_head sigpending;
};

struct fake_create_sigstack {
	void *ss_sp;
	int ss_flags;
	size_t ss_size;
};

struct fake_create_thread_obj {
	int refcount;
	struct fake_list_head hash_list;
	struct fake_list_head siblings_list;
	unsigned long cpu_set[2];
	int sched_policy;
	void *sigcommon;
	unsigned int sigpendinglock;
	struct fake_list_head sigpending;
	struct fake_create_sigstack sigstack;
	void *vm;
	void *proc;
	int exit_status;
	unsigned int spin_sleep_lock;
	int spin_sleep;
	unsigned long ctx_marker;
	unsigned long uctx_marker;
};

struct fake_create_process_obj {
	int pid;
	unsigned long cpu_set[2];
	void *vm;
	void *main_thread;
	unsigned long zero_guard;
};

struct fake_create_address_space_obj {
	unsigned long cpu_set[2];
	unsigned int cpu_set_lock;
	int released;
};

struct fake_create_vm_obj {
	void *address_space;
	void *owner;
	int initialized;
};

struct fake_create_sigcommon_obj {
	int use;
	unsigned int lock;
	struct fake_list_head sigpending;
};

#define PROCESS_ABI_HASH_SIZE 73
#define PROCESS_ABI_RESOURCE_SIZE 384
#define PROCESS_ABI_RESOURCE_LIST_OFF 0
#define PROCESS_ABI_RESOURCE_PATH_OFF 16
#define PROCESS_ABI_RESOURCE_PHASH_OFF 24
#define PROCESS_ABI_RESOURCE_THASH_OFF 32
#define PROCESS_ABI_RESOURCE_PHYSMEM_LIST_OFF 40
#define PROCESS_ABI_RESOURCE_PHYSMEM_LOCK_OFF 64
#define PROCESS_ABI_RESOURCE_CPU_SET_OFF 128
#define PROCESS_ABI_RESOURCE_CPU_SET_LOCK_OFF 256
#define PROCESS_ABI_RESOURCE_PID1_OFF 320
#define PROCESS_ABI_PROCESS_HASH_SIZE 5888
#define PROCESS_ABI_PROCESS_HASH_LOCK_OFF 1216
#define PROCESS_ABI_THREAD_HASH_SIZE 5888
#define PROCESS_ABI_PROCESS_SIZE 1728
#define PROCESS_ABI_PROCESS_VM_OFF 128
#define PROCESS_ABI_PROCESS_CHILDREN_LIST_OFF 288
#define PROCESS_ABI_PROCESS_PID_OFF 456
#define PROCESS_ABI_PROCESS_NOHOST_OFF 500
#define PROCESS_ABI_THREAD_SIZE 5568
#define PROCESS_ABI_THREAD_TID_OFF 20
#define PROCESS_ABI_THREAD_VM_OFF 4200
#define PROCESS_ABI_THREAD_CTX_OFF 4208
#define PROCESS_ABI_THREAD_PROC_OFF 4304
#define PROCESS_ABI_THREAD_SIBLINGS_LIST_OFF 4312
#define PROCESS_ABI_VM_SIZE 304
#define PROCESS_ABI_VM_ADDRESS_SPACE_OFF 0
#define PROCESS_ABI_VM_RANGE_TREE_OFF 8
#define PROCESS_ABI_VM_MEMORY_LOCK_OFF 180
#define PROCESS_ABI_VM_NUMA_POLICY_TREE_OFF 248
#define PROCESS_ABI_CPU_LOCAL_SIZE 8128
#define PROCESS_ABI_CPU_LOCAL_IDLE_OFF 64
#define PROCESS_ABI_CPU_LOCAL_IDLE_PROC_OFF 5632
#define PROCESS_ABI_CPU_LOCAL_IDLE_VM_OFF 7360
#define PROCESS_ABI_CPU_LOCAL_IDLE_ASP_OFF 7664
#define PROCESS_ABI_CPU_LOCAL_RUNQ_LOCK_OFF 7832
#define PROCESS_ABI_CPU_LOCAL_RUNQ_OFF 7872
#define PROCESS_ABI_CPU_LOCAL_RUNQ_LEN_OFF 7888
#define PROCESS_ABI_CPU_LOCAL_RESOURCE_SET_OFF 7912
#define PROCESS_ABI_CPU_LOCAL_MIGQ_LOCK_OFF 7948
#define PROCESS_ABI_CPU_LOCAL_MIGQ_OFF 7952

	struct fake_release_thread {
		int refcount;
		void *vm;
		void *proc;
	};

	struct fake_destroy_address_space {
		unsigned long cpu_set[2];
		unsigned long cpu_set_lock;
	};

	struct fake_destroy_vm {
		struct fake_destroy_address_space *address_space;
	};

	struct fake_destroy_proc {
		void *tids;
		void *main_thread;
		unsigned long threads_lock;
	};

	struct fake_destroy_thread {
		void *proc;
		void *vm;
		int cpu_id;
		struct fake_list_head siblings_list;
		int uti_state;
		int uti_refill_tid;
		struct fake_list_head sigpending;
		void *sigcommon;
		void *ptrace_debugreg;
		void *ptrace_recvsig;
		void *ptrace_sendsig;
		void *fp_regs;
		void *coredump_regs;
	};

	struct fake_lookup_process {
		struct fake_list_head hash_list;
		int pid;
	};

	struct fake_lookup_thread {
		struct fake_list_head hash_list;
		int tid;
		struct fake_lookup_process *proc;
	};

struct fake_vm_range {
	struct fake_rb_node vm_rb_node;
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	unsigned long straight_start;
	void *memobj;
	long objoff;
	int pgshift;
	int padding;
	void *private_data;
};

struct fake_copy_user_args {
	void *new_vm;
	unsigned long new_vrflag;
	void *range;
	long fault_addr;
};

struct fake_page_for_split {
	unsigned char padding[72];
	int pgshift;
};

struct fake_policy {
	struct fake_rb_node policy_rb_node;
	int id;
};

static struct fake_vm_range add_orch_range;
static int add_orch_alloc_fail;
static int add_orch_alloc_count;
static int add_orch_free_count;
static int add_orch_insert_count;
static int add_orch_update_count;
static int add_orch_remove_count;
static int add_orch_mark_count;
static int add_orch_memclear_count;
static int add_orch_log_count;
static int add_orch_insert_rc;
static int add_orch_update_rc;
static int add_orch_last_log_event;
static int add_orch_last_log_rc;
static unsigned long add_orch_alloc_size;
static unsigned long add_orch_update_phys;
static unsigned long add_orch_update_attr;
static unsigned long add_orch_remove_start;
static unsigned long add_orch_remove_end;
static unsigned long add_orch_memclear_phys;
static unsigned long add_orch_memclear_bytes;
static void *add_orch_last_vm;
static void *add_orch_last_range;
static int range_insert_log_count;
static int range_insert_dump_count;
static int range_insert_last_event;
static void *range_insert_last_vm;
static void *range_insert_last_newrange;
static void *range_insert_last_range;
static int range_public_log_count;
static int range_public_last_event;
static int range_public_last_error;
static unsigned long range_public_last_start;
static unsigned long range_public_last_end;
static unsigned long range_public_start_xor;
static unsigned long range_public_end_xor;
static void *range_public_last_vm;
static void *range_public_last_range;
static int range_memobj_ref_count;
static int range_memobj_unref_count;
static int range_memobj_direct_free_count;
static int range_free_count;
static int range_tofu_count;
static int range_insert_publish_count;
static int range_insert_publish_rc;
static int split_publish_log_count;
static int split_publish_log_error;
static int split_pt_count;
static int split_pt_rc;
static void *split_pt_page_table;
static void *split_pt_vm;
static void *split_pt_range;
static void *split_pt_addr;
static int split_pt_log_count;
static int split_pt_log_error;
static struct fake_vm_range split_alloc_range;
static int split_alloc_count;
static int split_alloc_fail;
static unsigned long split_alloc_size;
static unsigned long split_alloc_flags;
static int split_alloc_log_count;
static void *split_alloc_log_vm;
static void *split_alloc_log_range;
static unsigned long split_alloc_log_addr;
static void *split_alloc_log_splitp;
static int split_shm_lookup_count;
static int split_shm_lookup_rc;
static unsigned long split_shm_lookup_phys;
static long split_shm_lookup_off;
static int split_shm_lookup_p2align;
static int split_shm_phys_to_page_count;
static unsigned long split_shm_phys_to_page_phys;
static void *split_shm_phys_to_page_result;
static int split_shm_update_count;
static int split_shm_update_rc;
static void *split_shm_update_memobj;
static void *split_shm_update_page_table;
static void *split_shm_update_page;
static void *split_shm_update_vaddr;
static int split_shm_log_count;
static int split_shm_log_event;
static int split_shm_log_error;
static int page_size_call_count;
static int page_size_fail_after;
static unsigned long final_phys_to_virt_phys;
static void *final_phys_to_virt_addr;
static int final_phys_to_virt_count;
static int final_free_pages_count;
static void *final_free_pages_addr;
static unsigned long final_free_pages_npages;
static int final_clear_main_count;
static unsigned long final_clear_main_start;
static unsigned long final_clear_main_end;
static int final_clear_main_rc;
static int free_body_lock_count;
static int free_body_unlock_count;
static unsigned long free_body_lock_addr;
static unsigned long free_body_unlock_addr;
static int free_body_pt_free_count;
static int free_body_pt_free_rc;
static void *free_body_pt_free_page_table;
static void *free_body_pt_free_vm;
static unsigned long free_body_pt_free_start;
static unsigned long free_body_pt_free_end;
static void *free_body_pt_free_memobj;
static int free_body_pt_clear_count;
static int free_body_pt_clear_rc;
static void *free_body_pt_clear_page_table;
static void *free_body_pt_clear_vm;
static unsigned long free_body_pt_clear_start;
static unsigned long free_body_pt_clear_end;
static int free_body_tofu_count;
static int free_body_tofu_result;
static void *free_body_tofu_vm;
static void *free_body_tofu_range;
static int free_body_log_count;
static int free_body_log_event[8];
static unsigned long free_body_log_start[8];
static unsigned long free_body_log_end[8];
static int free_body_log_error[8];
static int sync_body_visit_count;
static int sync_body_visit_rc;
static void *sync_body_visit_page_table;
static unsigned long sync_body_visit_start;
static unsigned long sync_body_visit_end;
static int sync_body_visit_pgshift;
static int sync_body_visit_flags;
static void *sync_body_visit_step;
static void *sync_body_visit_arg;
static struct fake_vm_range copy_alloc_ranges[4];
static int copy_alloc_count;
static int copy_alloc_fail_after;
static int copy_lookup_count;
static int copy_next_count;
static int copy_insert_count;
static int copy_free_count;
static int copy_log_count;
static long copy_log_fault_addr;
static int copy_visit_rc;
static int copy_visit_fail_after;
static long copy_visit_fault_addr;
static int sync_body_log_count;
static int sync_body_log_error;
static unsigned long sync_body_log_start;
static unsigned long sync_body_log_end;
static int remap_body_log_count;
static int remap_body_log_event;
static int remap_body_log_old_pgshift;
static int remap_body_log_error;
static unsigned long remap_body_log_start;
static unsigned long remap_body_log_end;
static long remap_body_log_off;
static int invalidate_lookup_count;
static void *invalidate_lookup_result[2];
static size_t invalidate_lookup_pgsize_result[2];
static void *invalidate_lookup_page_table[2];
static unsigned long invalidate_lookup_addr[2];
static int invalidate_lookup_pgshift[2];
static int invalidate_pte_contiguous_count;
static int invalidate_pte_contiguous_result[2];
static int invalidate_pte_head_count;
static int invalidate_pte_head_result;
static int invalidate_pte_tail_count;
static int invalidate_pte_tail_result;
static int invalidate_split_count;
static int invalidate_split_rc;
static void *invalidate_split_ptep[2];
static size_t invalidate_split_pgsize[2];
static unsigned int invalidate_split_memobj_flags[2];
static int invalidate_one_pte_null_count;
static int invalidate_one_pte_fileoff_count;
static int invalidate_one_pte_fileoff_result;
static int invalidate_one_pte_get_phys_count;
static unsigned long invalidate_one_pte_get_phys_result;
static int invalidate_one_phys_to_page_count;
static unsigned long invalidate_one_phys_to_page_phys;
static void *invalidate_one_phys_to_page_result;
static int invalidate_one_page_offset_count;
static long invalidate_one_page_offset_result;
static int invalidate_one_make_fileoff_count;
static long invalidate_one_make_fileoff_off;
static size_t invalidate_one_make_fileoff_pgsize;
static unsigned long invalidate_one_make_fileoff_value;
static int invalidate_one_xchg_count;
static unsigned long invalidate_one_xchg_old_value;
static unsigned long invalidate_one_xchg_new_value;
static int invalidate_one_flush_count;
static unsigned long invalidate_one_flush_addr;
static int invalidate_one_contiguous_count;
static int invalidate_one_contiguous_result;
static unsigned long invalidate_one_contiguous_value;
static int invalidate_one_head_count;
static int invalidate_one_head_result;
static int invalidate_one_pgsize_to_tbllv_count;
static size_t invalidate_one_pgsize_to_tbllv_pgsize;
static int invalidate_one_pgsize_to_tbllv_result;
static int invalidate_one_tbllv_to_contpgsize_count;
static int invalidate_one_tbllv_to_contpgsize_level;
static size_t invalidate_one_tbllv_to_contpgsize_result;
static int invalidate_one_page_unmap_count;
static int invalidate_one_page_unmap_rc;
static void *invalidate_one_page_unmap_page;
static int invalidate_one_panic_count;
static const char *invalidate_one_panic_message;
static int invalidate_one_memobj_invalidate_count;
static void *invalidate_one_memobj_invalidate_memobj;
static unsigned long invalidate_one_memobj_invalidate_phys;
static size_t invalidate_one_memobj_invalidate_pgsize;
static int invalidate_one_memobj_invalidate_rc;
static int invalidate_one_log_count;
static void *invalidate_one_log_arg;
static void *invalidate_one_log_page_table;
static void *invalidate_one_log_ptep;
static unsigned long invalidate_one_log_pte_value;
static void *invalidate_one_log_pgaddr;
static int invalidate_one_log_pgshift;
static int invalidate_one_log_error;
static int remove_body_split_count;
static unsigned long remove_body_split_addr[4];
static void *remove_body_split_range[4];
static int remove_body_split_rc;
static void *remove_body_split_replacement;
static int remove_body_xpmem_count;
static void *remove_body_xpmem_range;
static int remove_body_free_count;
static void *remove_body_free_range[4];
static int remove_body_free_rc;
static int remove_body_log_count;
static int remove_body_log_event[8];
static unsigned long remove_body_log_start[8];
static unsigned long remove_body_log_end[8];
static void *remove_body_log_range[8];
static int remove_body_log_error[8];
static int remove_region_clear_count;
static int remove_region_clear_rc;
static void *remove_region_clear_page_table;
static void *remove_region_clear_vm;
static unsigned long remove_region_clear_start;
static unsigned long remove_region_clear_end;
static int remove_region_log_count;
static unsigned long remove_region_log_start;
static unsigned long remove_region_log_end;
static int process_mckfd_close_count;
static int process_mckfd_close_fd_sum;
static int process_mckfd_free_count;
static int process_mckfd_free_fd_sum;
static int process_memory_free_count;
static int process_memory_free_rc;
static unsigned long process_memory_free_fail_start;
static unsigned long process_memory_free_start_xor;
static int process_memory_log_count;
static unsigned long process_memory_log_start;
static unsigned long process_memory_log_end;
static int process_memory_log_error;
static int process_policy_free_count;
static int process_policy_free_id_sum;
static int process_detach_count;
static int process_detach_pid;
static void *process_detach_address_space;
static int process_release_count;
static void *process_release_last_proc;
static int process_optional_free_count;
static unsigned long process_optional_free_xor;
static int process_release_fp_count;
static void *process_release_fp_thread;
static int process_ref_inc_count;
static void *process_ref_inc_object;
static unsigned long process_ref_inc_offset;
static int process_hold_warn_count;
static void *process_hold_warn_thread;
static int process_ref_dec_count;
static void *process_ref_dec_object;
static unsigned long process_ref_dec_offset;
static int process_tid_log_count;
static int process_tid_log_tid;
static int process_tid_log_new_tid;
static void *process_tid_log_thread;
static int process_thread_profile_count;
static int process_thread_procfs_count;
static int process_thread_destroy_count;
static int process_thread_release_vm_count;
static unsigned long process_lifecycle_order;
static int process_spin_lock_count;
static int process_spin_unlock_count;
static unsigned long process_spin_lock_addr;
static unsigned long process_spin_unlock_addr;
static unsigned long process_spin_unlock_irq;
static int process_vm_free_cb_count;
static void *process_vm_free_cb_vm;
static void *process_vm_free_cb_opt;
static int process_vm_flush_count;
static int process_vm_free_ranges_count;
static int process_vm_free_count;
static int process_release_resource_count;
static void *process_release_resource_value;
	static int process_release_hash_count;
	static int process_release_sibling_count;
	static int process_release_profile_count;
	static int process_release_thread_pages_count;
	static void *process_release_thread_pages_thread;
	static int process_release_final_count;
	static void *process_release_final_resource;
	static int process_mcs_lock_count;
	static int process_mcs_unlock_count;
	static unsigned long process_mcs_lock_addr;
	static unsigned long process_mcs_unlock_addr;
	static void *process_mcs_lock_node;
	static int process_destroy_hash_detach_count;
	static void *process_destroy_hash_detach_thread;
	static int process_destroy_time_count;
	static void *process_destroy_time_thread;
	static int process_destroy_release_tid_count;
	static int process_destroy_replace_tid_count;
	static int process_destroy_replace_tid_new;
	static void *process_destroy_tid_proc;
	static void *process_destroy_tid_thread;
	static int process_destroy_release_sigcommon_count;
	static void *process_destroy_release_sigcommon_ptr;
	static int process_lookup_hold_count;
	static void *process_lookup_hold_thread;
	static int process_as_free_cb_count;
	static void *process_as_free_cb_asp;
	static void *process_as_free_cb_opt;
static int process_as_pt_destroy_count;
static void *process_as_pt_destroy_page_table;
static int process_as_release_count;
static void *process_as_release_asp;
static unsigned char process_as_alloc_space[256];
static int process_as_alloc_count;
static int process_as_alloc_fail;
static unsigned long process_as_alloc_size;
static unsigned long process_as_alloc_flags;
static int process_as_pt_create_count;
static int process_as_pt_create_fail;
static unsigned long process_as_pt_create_flags;
static int process_as_ref_set_count;
static void *process_as_ref_set_object;
static unsigned long process_as_ref_set_offset;
static int process_as_ref_set_value;
static int process_as_spin_init_count;
static unsigned long process_as_spin_init_addr;
static int process_default_ncpus_count;
static int process_default_ncpus_value;
static int process_create_cpu_log_count;
static int process_create_cpu_invalid_count;
static int process_create_cpu_requested_count;
static int process_create_cpu_last_pid;
static int process_create_cpu_last_cpu;
static unsigned long process_create_cpu_requested_mask;
static int process_rwlock_init_count;
static unsigned long process_rwlock_init_addr;
static int process_waitq_init_count;
static unsigned long process_waitq_init_addr;
static int process_mcs_lock_init_count;
static unsigned long process_mcs_lock_init_addr;
static int process_vm_init_numa_log_count;
static int process_vm_init_numa_log_id;
static struct fake_create_thread_obj create_thread_store;
static struct fake_create_process_obj create_proc_store;
static struct fake_create_vm_obj create_vm_store;
static struct fake_create_address_space_obj create_as_store;
static struct fake_create_sigcommon_obj create_sigcommon_store;
static int create_alloc_pages_count;
static int create_alloc_pages_fail;
static int create_alloc_pages_npages;
static unsigned long create_alloc_pages_flags;
static int create_alloc_count;
static int create_fail_sigcommon;
static unsigned long create_alloc_size[4];
static unsigned long create_alloc_flags[4];
static int create_free_count;
static unsigned long create_free_xor;
static int create_address_space_count;
static int create_address_space_fail;
static int create_address_space_nslots;
static int create_release_address_space_count;
static void *create_release_address_space_ptr;
static int create_init_process_count;
static void *create_init_process_parent;
static int create_init_vm_count;
static void *create_init_vm_owner;
static int create_init_user_count;
static void *create_init_user_thread;
static unsigned long create_init_user_stack_top;
static unsigned long create_init_user_pc;
static unsigned long create_init_user_sp;
static int create_free_thread_count;
static void *create_free_thread_ptr;
static unsigned char boot_resource_store[PROCESS_ABI_RESOURCE_SIZE]
	__attribute__((aligned(64)));
static unsigned char boot_phash_store[PROCESS_ABI_PROCESS_HASH_SIZE]
	__attribute__((aligned(64)));
static unsigned char boot_thash_store[PROCESS_ABI_THREAD_HASH_SIZE]
	__attribute__((aligned(64)));
static unsigned char boot_pid1_store[PROCESS_ABI_PROCESS_SIZE]
	__attribute__((aligned(64)));
static unsigned char boot_path_store[2];
static unsigned char boot_cpu_local_store[PROCESS_ABI_CPU_LOCAL_SIZE]
	__attribute__((aligned(64)));
static struct fake_list_head boot_resource_list;
static int boot_alloc_count;
static int boot_alloc_fail_at;
static unsigned long boot_alloc_size[8];
static unsigned long boot_alloc_flags[8];
static int boot_free_count;
static unsigned long boot_free_xor;
static int boot_init_process_count;
static void *boot_init_process_last_proc;
static void *boot_init_process_last_parent;
static int boot_context_count;
static void *boot_context_thread;
static int boot_save_fp_count;
static void *boot_save_fp_thread;
static int boot_timer_count;
static int boot_timer_cpu;
static int process_range_lock_count;
static int process_range_unlock_count;
static unsigned long process_range_lock_addr;
static unsigned long process_range_unlock_addr;
static int process_change_attr_count;
static int process_change_attr_rc;
static void *process_change_attr_pt;
static unsigned long process_change_attr_start;
static unsigned long process_change_attr_end;
static unsigned long process_change_attr_clr;
static unsigned long process_change_attr_set;
static int change_public_log_count;
static int change_public_error_count;
static int change_public_last_event;
static int change_public_last_error;
static unsigned long change_public_last_protflag;
static void *change_public_last_vm;
static void *change_public_last_range;
static int process_update_pt_count;
static int process_update_pt_rc;
static void *process_update_pt_page_table;
static void *process_update_pt_vm;
static unsigned long process_update_pt_start;
static unsigned long process_update_pt_end;
static unsigned long process_update_pt_phys;
static unsigned long process_update_pt_attr;
static int process_update_pt_pgshift;
static void *process_update_pt_range;
static int process_update_pt_flags;
static int process_update_pt_log_count;
static int process_update_pt_log_error;
static int access_public_log_count;
static int access_public_last_type;
static int access_public_last_error;
static unsigned long access_public_last_addr;
static size_t access_public_last_len;
static void *access_public_last_vm;
static int process_pf_read_lock_count;
static int process_pf_read_unlock_count;
static int process_pf_write_lock_count;
static int process_pf_write_unlock_count;
static unsigned long process_pf_last_lock_addr;
static int process_pf_zero_match_count;
static int process_pf_zero_match_result;
static int process_pf_normal_count;
static int process_pf_xpmem_count;
static int process_pf_normal_rc;
static int process_pf_xpmem_rc;
static unsigned long process_pf_last_addr;
static unsigned long process_pf_last_reason;
static void *process_pf_last_range;
static int process_pf_retry_calls;
static int process_pf_retry_restart_count;
static int process_pf_retry_rc;
static int process_pf_preempt_enable_count;
static int process_pf_preempt_disable_count;
static int process_pf_pgio_dispatch_count;
static void *process_pf_pgio_fp;
static void *process_pf_pgio_arg;
static int process_populate_pf_count;
static int process_populate_fail_after;
static int process_populate_fail_rc;
static int process_populate_warn_count;
static unsigned long process_populate_warn_addr;
	static unsigned long process_populate_warn_off;
	static size_t process_populate_warn_len;
	static int process_populate_warn_error;
	#define PROCESS_STACK_THREAD_SIZE 5568
	#define PROCESS_STACK_THREAD_TID_OFF 20
	#define PROCESS_STACK_THREAD_VM_OFF 4200
	#define PROCESS_STACK_THREAD_UCTX_OFF 4296
	#define PROCESS_STACK_THREAD_PROC_OFF 4304
	#define PROCESS_STACK_PROCESS_SIZE 1728
	#define PROCESS_STACK_PROCESS_PID_OFF 456
	#define PROCESS_STACK_PROCESS_RUID_OFF 464
	#define PROCESS_STACK_PROCESS_EUID_OFF 468
	#define PROCESS_STACK_PROCESS_RGID_OFF 480
	#define PROCESS_STACK_PROCESS_EGID_OFF 484
	#define PROCESS_STACK_PROCESS_RLIMIT_OFF 512
	#define PROCESS_STACK_PROCESS_SAVED_AUXV_OFF 832
	#define PROCESS_STACK_PROCESS_MPOL_FLAGS_OFF 1376
	#define PROCESS_STACK_PROCESS_MPOL_THRESHOLD_OFF 1384
	#define PROCESS_STACK_VM_ASPACE_OFF 0
	#define PROCESS_STACK_VM_MAP_START_OFF 88
	#define PROCESS_STACK_VM_STACK_START_OFF 104
	#define PROCESS_STACK_VM_STACK_END_OFF 112
	#define PROCESS_STACK_VM_USER_END_OFF 128
	#define PROCESS_STACK_VM_VDSO_ADDR_OFF 160
	static unsigned char process_stack_thread[PROCESS_STACK_THREAD_SIZE]
		__attribute__((aligned(64)));
	static unsigned char process_stack_process[PROCESS_STACK_PROCESS_SIZE]
		__attribute__((aligned(64)));
	static struct fake_process_vm_full process_stack_vm
		__attribute__((aligned(64)));
	static struct fake_address_space process_stack_aspace
		__attribute__((aligned(8)));
	static struct fake_vm_range process_stack_range;
	static unsigned char process_stack_pages[8 * 1024 * 1024]
		__attribute__((aligned(4096)));
	static int process_stack_alloc_count;
	static int process_stack_alloc_fail;
	static int process_stack_alloc_npages;
	static int process_stack_alloc_p2align;
	static unsigned long process_stack_alloc_flags;
	static unsigned long process_stack_alloc_addr;
	static int process_stack_free_count;
	static void *process_stack_free_addr;
	static int process_stack_free_npages;
	static int process_stack_add_count;
	static int process_stack_add_rc;
	static int process_stack_add_null_range;
	static unsigned long process_stack_add_start;
	static unsigned long process_stack_add_end;
	static unsigned long process_stack_add_phys;
	static unsigned long process_stack_add_flag;
	static int process_stack_add_pgshift;
	static int process_stack_pt_count;
	static int process_stack_pt_rc;
	static void *process_stack_pt_page_table;
	static void *process_stack_pt_vm;
	static unsigned long process_stack_pt_start;
	static unsigned long process_stack_pt_end;
	static unsigned long process_stack_pt_phys;
	static unsigned long process_stack_pt_attr;
	static int process_stack_pt_pgshift;
	static void *process_stack_pt_range;
	static int process_stack_hwcap_count;
	static int process_stack_modify_count;
	static void *process_stack_modify_uctx;
	static int process_stack_modify_reg;
	static unsigned long process_stack_modify_value;
	static int process_stack_log_count[16];
	static int process_stack_log_last_event;
	static unsigned long process_stack_log_arg[12];

static void reset_add_orchestrate_trace(void)
{
	add_orch_range = (struct fake_vm_range){ 0 };
	add_orch_alloc_fail = 0;
	add_orch_alloc_count = 0;
	add_orch_free_count = 0;
	add_orch_insert_count = 0;
	add_orch_update_count = 0;
	add_orch_remove_count = 0;
	add_orch_mark_count = 0;
	add_orch_memclear_count = 0;
	add_orch_log_count = 0;
	add_orch_insert_rc = 0;
	add_orch_update_rc = 0;
	add_orch_last_log_event = 0;
	add_orch_last_log_rc = 0;
	add_orch_alloc_size = 0;
	add_orch_update_phys = 0;
	add_orch_update_attr = 0;
	add_orch_remove_start = 0;
	add_orch_remove_end = 0;
	add_orch_memclear_phys = 0;
	add_orch_memclear_bytes = 0;
	add_orch_last_vm = NULL;
	add_orch_last_range = NULL;
}

static void *fake_add_range_alloc(unsigned long size)
{
	add_orch_alloc_count++;
	add_orch_alloc_size = size;
	return add_orch_alloc_fail ? NULL : &add_orch_range;
}

static void fake_add_range_free(void *range)
{
	add_orch_free_count++;
	add_orch_last_range = range;
}

static int fake_add_range_insert(void *vm, void *range)
{
	add_orch_insert_count++;
	add_orch_last_vm = vm;
	add_orch_last_range = range;
	return add_orch_insert_rc;
}

static int fake_add_range_update(void *vm, void *range, unsigned long phys,
				 unsigned long attr)
{
	add_orch_update_count++;
	add_orch_last_vm = vm;
	add_orch_last_range = range;
	add_orch_update_phys = phys;
	add_orch_update_attr = attr;
	return add_orch_update_rc;
}

static void fake_add_range_remove(void *vm, unsigned long start,
				  unsigned long end)
{
	add_orch_remove_count++;
	add_orch_last_vm = vm;
	add_orch_remove_start = start;
	add_orch_remove_end = end;
}

static void fake_add_range_mark_xpmem(void *range)
{
	add_orch_mark_count++;
	add_orch_last_range = range;
}

static void fake_add_range_memclear(unsigned long phys, unsigned long bytes)
{
	add_orch_memclear_count++;
	add_orch_memclear_phys = phys;
	add_orch_memclear_bytes = bytes;
}

static void fake_add_range_log(int event, int rc, unsigned long start,
			       unsigned long end)
{
	add_orch_log_count++;
	add_orch_last_log_event = event;
	add_orch_last_log_rc = rc;
	add_orch_remove_start = start;
	add_orch_remove_end = end;
}

static void reset_range_insert_trace(void)
{
	range_insert_log_count = 0;
	range_insert_dump_count = 0;
	range_insert_last_event = 0;
	range_insert_last_vm = NULL;
	range_insert_last_newrange = NULL;
	range_insert_last_range = NULL;
}

static void fake_range_insert_log(int event, void *vm, void *newrange,
				  void *range)
{
	range_insert_log_count++;
	range_insert_last_event = event;
	range_insert_last_vm = vm;
	range_insert_last_newrange = newrange;
	range_insert_last_range = range;
}

static void fake_range_insert_dump(void *vm)
{
	range_insert_dump_count++;
	range_insert_last_vm = vm;
}

static void reset_range_public_trace(void)
{
	range_public_log_count = 0;
	range_public_last_event = 0;
	range_public_last_error = 0;
	range_public_last_start = 0;
	range_public_last_end = 0;
	range_public_start_xor = 0;
	range_public_end_xor = 0;
	range_public_last_vm = NULL;
	range_public_last_range = NULL;
}

static void fake_range_public_log(int event, void *vm, void *range,
				  unsigned long start, unsigned long end,
				  int error)
{
	range_public_log_count++;
	range_public_last_event = event;
	range_public_last_error = error;
	range_public_last_start = start;
	range_public_last_end = end;
	range_public_start_xor ^= start;
	range_public_end_xor ^= end;
	range_public_last_vm = vm;
	range_public_last_range = range;
}

static void fake_range_memobj_direct_free(void *memobj)
{
	(void)memobj;
	range_memobj_direct_free_count++;
}

static void reset_range_body_trace(void)
{
	range_memobj_ref_count = 0;
	range_memobj_unref_count = 0;
	range_memobj_direct_free_count = 0;
	range_free_count = 0;
	range_tofu_count = 0;
	range_insert_publish_count = 0;
	range_insert_publish_rc = 0;
	split_publish_log_count = 0;
	split_publish_log_error = 0;
	split_pt_count = 0;
	split_pt_rc = 0;
	split_pt_page_table = NULL;
	split_pt_vm = NULL;
	split_pt_range = NULL;
	split_pt_addr = NULL;
	split_pt_log_count = 0;
	split_pt_log_error = 0;
	split_alloc_range = (struct fake_vm_range){ 0 };
	split_alloc_count = 0;
	split_alloc_fail = 0;
	split_alloc_size = 0;
	split_alloc_flags = 0;
	split_alloc_log_count = 0;
	split_alloc_log_vm = NULL;
	split_alloc_log_range = NULL;
	split_alloc_log_addr = 0;
	split_alloc_log_splitp = NULL;
	split_shm_lookup_count = 0;
	split_shm_lookup_rc = 0;
	split_shm_lookup_phys = 0;
	split_shm_lookup_off = 0;
	split_shm_lookup_p2align = 0;
	split_shm_phys_to_page_count = 0;
	split_shm_phys_to_page_phys = 0;
	split_shm_phys_to_page_result = NULL;
	split_shm_update_count = 0;
	split_shm_update_rc = 0;
	split_shm_update_memobj = NULL;
	split_shm_update_page_table = NULL;
	split_shm_update_page = NULL;
	split_shm_update_vaddr = NULL;
	split_shm_log_count = 0;
	split_shm_log_event = 0;
	split_shm_log_error = 0;
	page_size_call_count = 0;
	page_size_fail_after = 3;
	final_phys_to_virt_phys = 0;
	final_phys_to_virt_addr = NULL;
	final_phys_to_virt_count = 0;
	final_free_pages_count = 0;
	final_free_pages_addr = NULL;
	final_free_pages_npages = 0;
	final_clear_main_count = 0;
	final_clear_main_start = 0;
	final_clear_main_end = 0;
	final_clear_main_rc = 0;
	free_body_lock_count = 0;
	free_body_unlock_count = 0;
	free_body_lock_addr = 0;
	free_body_unlock_addr = 0;
	free_body_pt_free_count = 0;
	free_body_pt_free_rc = 0;
	free_body_pt_free_page_table = NULL;
	free_body_pt_free_vm = NULL;
	free_body_pt_free_start = 0;
	free_body_pt_free_end = 0;
	free_body_pt_free_memobj = NULL;
	free_body_pt_clear_count = 0;
	free_body_pt_clear_rc = 0;
	free_body_pt_clear_page_table = NULL;
	free_body_pt_clear_vm = NULL;
	free_body_pt_clear_start = 0;
	free_body_pt_clear_end = 0;
	free_body_tofu_count = 0;
	free_body_tofu_result = 0;
	free_body_tofu_vm = NULL;
	free_body_tofu_range = NULL;
	free_body_log_count = 0;
	for (int i = 0; i < 8; i++) {
		free_body_log_event[i] = 0;
		free_body_log_start[i] = 0;
		free_body_log_end[i] = 0;
		free_body_log_error[i] = 0;
	}
	sync_body_visit_count = 0;
	sync_body_visit_rc = 0;
	sync_body_visit_page_table = NULL;
	sync_body_visit_start = 0;
	sync_body_visit_end = 0;
	sync_body_visit_pgshift = 0;
	sync_body_visit_flags = 0;
	sync_body_visit_step = NULL;
	sync_body_visit_arg = NULL;
	memset(copy_alloc_ranges, 0, sizeof(copy_alloc_ranges));
	copy_alloc_count = 0;
	copy_alloc_fail_after = 0;
	copy_lookup_count = 0;
	copy_next_count = 0;
	copy_insert_count = 0;
	copy_free_count = 0;
	copy_log_count = 0;
	copy_log_fault_addr = 0;
	copy_visit_rc = 0;
	copy_visit_fail_after = 0;
	copy_visit_fault_addr = -1;
	sync_body_log_count = 0;
	sync_body_log_error = 0;
	sync_body_log_start = 0;
	sync_body_log_end = 0;
	remap_body_log_count = 0;
	remap_body_log_event = 0;
	remap_body_log_old_pgshift = 0;
	remap_body_log_error = 0;
	remap_body_log_start = 0;
	remap_body_log_end = 0;
	remap_body_log_off = 0;
	invalidate_lookup_count = 0;
	for (int i = 0; i < 2; i++) {
		invalidate_lookup_result[i] = NULL;
		invalidate_lookup_pgsize_result[i] = PAGE_SIZE;
		invalidate_lookup_page_table[i] = NULL;
		invalidate_lookup_addr[i] = 0;
		invalidate_lookup_pgshift[i] = 0;
		invalidate_pte_contiguous_result[i] = 0;
		invalidate_split_ptep[i] = NULL;
		invalidate_split_pgsize[i] = 0;
		invalidate_split_memobj_flags[i] = 0;
	}
	invalidate_pte_contiguous_count = 0;
	invalidate_pte_head_count = 0;
	invalidate_pte_head_result = 1;
	invalidate_pte_tail_count = 0;
	invalidate_pte_tail_result = 1;
	invalidate_split_count = 0;
	invalidate_split_rc = 0;
	invalidate_one_pte_null_count = 0;
	invalidate_one_pte_fileoff_count = 0;
	invalidate_one_pte_fileoff_result = 0;
	invalidate_one_pte_get_phys_count = 0;
	invalidate_one_pte_get_phys_result = 0;
	invalidate_one_phys_to_page_count = 0;
	invalidate_one_phys_to_page_phys = 0;
	invalidate_one_phys_to_page_result = NULL;
	invalidate_one_page_offset_count = 0;
	invalidate_one_page_offset_result = 0;
	invalidate_one_make_fileoff_count = 0;
	invalidate_one_make_fileoff_off = 0;
	invalidate_one_make_fileoff_pgsize = 0;
	invalidate_one_make_fileoff_value = 0;
	invalidate_one_xchg_count = 0;
	invalidate_one_xchg_old_value = 0;
	invalidate_one_xchg_new_value = 0;
	invalidate_one_flush_count = 0;
	invalidate_one_flush_addr = 0;
	invalidate_one_contiguous_count = 0;
	invalidate_one_contiguous_result = 0;
	invalidate_one_contiguous_value = 0;
	invalidate_one_head_count = 0;
	invalidate_one_head_result = 0;
	invalidate_one_pgsize_to_tbllv_count = 0;
	invalidate_one_pgsize_to_tbllv_pgsize = 0;
	invalidate_one_pgsize_to_tbllv_result = 0;
	invalidate_one_tbllv_to_contpgsize_count = 0;
	invalidate_one_tbllv_to_contpgsize_level = 0;
	invalidate_one_tbllv_to_contpgsize_result = 0;
	invalidate_one_page_unmap_count = 0;
	invalidate_one_page_unmap_rc = 0;
	invalidate_one_page_unmap_page = NULL;
	invalidate_one_panic_count = 0;
	invalidate_one_panic_message = NULL;
	invalidate_one_memobj_invalidate_count = 0;
	invalidate_one_memobj_invalidate_memobj = NULL;
	invalidate_one_memobj_invalidate_phys = 0;
	invalidate_one_memobj_invalidate_pgsize = 0;
	invalidate_one_memobj_invalidate_rc = 0;
	invalidate_one_log_count = 0;
	invalidate_one_log_arg = NULL;
	invalidate_one_log_page_table = NULL;
	invalidate_one_log_ptep = NULL;
	invalidate_one_log_pte_value = 0;
	invalidate_one_log_pgaddr = NULL;
	invalidate_one_log_pgshift = 0;
	invalidate_one_log_error = 0;
	remove_body_split_count = 0;
	for (int i = 0; i < 4; i++) {
		remove_body_split_addr[i] = 0;
		remove_body_split_range[i] = NULL;
		remove_body_free_range[i] = NULL;
	}
	remove_body_split_rc = 0;
	remove_body_split_replacement = NULL;
	remove_body_xpmem_count = 0;
	remove_body_xpmem_range = NULL;
	remove_body_free_count = 0;
	remove_body_free_rc = 0;
	remove_body_log_count = 0;
	for (int i = 0; i < 8; i++) {
		remove_body_log_event[i] = 0;
		remove_body_log_start[i] = 0;
		remove_body_log_end[i] = 0;
		remove_body_log_range[i] = NULL;
		remove_body_log_error[i] = 0;
	}
	remove_region_clear_count = 0;
	remove_region_clear_rc = 0;
	remove_region_clear_page_table = NULL;
	remove_region_clear_vm = NULL;
	remove_region_clear_start = 0;
	remove_region_clear_end = 0;
	remove_region_log_count = 0;
	remove_region_log_start = 0;
	remove_region_log_end = 0;
}

static void fake_range_memobj_ref(void *memobj)
{
	(void)memobj;
	range_memobj_ref_count++;
}

static void fake_range_memobj_unref(void *memobj)
{
	(void)memobj;
	range_memobj_unref_count++;
}

static void fake_range_free(void *range)
{
	(void)range;
	range_free_count++;
}

static int fake_range_tofu(void *vm, void *surviving, void *merging)
{
	(void)vm;
	(void)surviving;
	(void)merging;
	range_tofu_count++;
	return 0;
}

static int fake_split_publish_insert(void *vm, void *range)
{
	(void)vm;
	(void)range;
	range_insert_publish_count++;
	return range_insert_publish_rc;
}

static void fake_split_publish_log(int error)
{
	split_publish_log_count++;
	split_publish_log_error = error;
}

static int fake_split_pt_split(void *page_table, void *vm, void *range,
			       void *addr)
{
	split_pt_count++;
	split_pt_page_table = page_table;
	split_pt_vm = vm;
	split_pt_range = range;
	split_pt_addr = addr;
	return split_pt_rc;
}

static void fake_split_pt_log(int error)
{
	split_pt_log_count++;
	split_pt_log_error = error;
}

static void *fake_split_range_alloc(unsigned long size, unsigned long flags)
{
	split_alloc_count++;
	split_alloc_size = size;
	split_alloc_flags = flags;
	return split_alloc_fail ? NULL : &split_alloc_range;
}

static void fake_split_range_alloc_log(void *vm, void *range,
				       unsigned long addr, void *splitp)
{
	split_alloc_log_count++;
	split_alloc_log_vm = vm;
	split_alloc_log_range = range;
	split_alloc_log_addr = addr;
	split_alloc_log_splitp = splitp;
}

static int fake_split_shm_lookup_page(void *memobj, long off, int p2align,
				      uintptr_t *physp,
				      unsigned long *pflag)
{
	(void)memobj;
	(void)pflag;
	split_shm_lookup_count++;
	split_shm_lookup_off = off;
	split_shm_lookup_p2align = p2align;
	if (physp)
		*physp = split_shm_lookup_phys;
	return split_shm_lookup_rc;
}

static void *fake_split_shm_phys_to_page(unsigned long phys)
{
	split_shm_phys_to_page_count++;
	split_shm_phys_to_page_phys = phys;
	return split_shm_phys_to_page_result;
}

static int fake_split_shm_update_page(void *memobj, void *page_table,
				      void *page, void *vaddr)
{
	split_shm_update_count++;
	split_shm_update_memobj = memobj;
	split_shm_update_page_table = page_table;
	split_shm_update_page = page;
	split_shm_update_vaddr = vaddr;
	return split_shm_update_rc;
}

static void fake_split_shm_log(int event, int error)
{
	split_shm_log_count++;
	split_shm_log_event = event;
	split_shm_log_error = error;
}

static int fake_page_size(size_t current, size_t *nextp)
{
	page_size_call_count++;
	if (page_size_fail_after >= 0 &&
	    page_size_call_count > page_size_fail_after)
		return -5;
	if (current == (size_t)-1) {
		*nextp = 0x200000;
		return 0;
	}
	if (current == 0x200000) {
		*nextp = 0x1000;
		return 0;
	}
	return -5;
}

static void *fake_final_phys_to_virt(unsigned long phys)
{
	final_phys_to_virt_count++;
	final_phys_to_virt_phys = phys;
	final_phys_to_virt_addr = (void *)(phys + 0x10000000UL);
	return final_phys_to_virt_addr;
}

static void fake_final_free_pages(void *addr, unsigned long npages)
{
	final_free_pages_count++;
	final_free_pages_addr = addr;
	final_free_pages_npages = npages;
}

static int fake_final_clear_main(void *vm, unsigned long start,
				 unsigned long end)
{
	(void)vm;
	final_clear_main_count++;
	final_clear_main_start = start;
	final_clear_main_end = end;
	return final_clear_main_rc;
}

static void fake_free_body_lock(unsigned long lock_addr)
{
	free_body_lock_count++;
	free_body_lock_addr = lock_addr;
}

static void fake_free_body_unlock(unsigned long lock_addr)
{
	free_body_unlock_count++;
	free_body_unlock_addr = lock_addr;
}

static int fake_free_body_pt_free(void *page_table, void *vm,
				  unsigned long start, unsigned long end,
				  void *memobj)
{
	free_body_pt_free_count++;
	free_body_pt_free_page_table = page_table;
	free_body_pt_free_vm = vm;
	free_body_pt_free_start = start;
	free_body_pt_free_end = end;
	free_body_pt_free_memobj = memobj;
	return free_body_pt_free_rc;
}

static int fake_free_body_pt_clear(void *page_table, void *vm,
				   unsigned long start, unsigned long end)
{
	free_body_pt_clear_count++;
	free_body_pt_clear_page_table = page_table;
	free_body_pt_clear_vm = vm;
	free_body_pt_clear_start = start;
	free_body_pt_clear_end = end;
	return free_body_pt_clear_rc;
}

static int fake_free_body_tofu_remove(void *vm, void *range)
{
	free_body_tofu_count++;
	free_body_tofu_vm = vm;
	free_body_tofu_range = range;
	return free_body_tofu_result;
}

static void fake_free_body_log(int event, void *vm, void *range,
			       unsigned long start, unsigned long end,
			       int error)
{
	(void)vm;
	(void)range;
	int index = free_body_log_count;

	if (index < 8) {
		free_body_log_event[index] = event;
		free_body_log_start[index] = start;
		free_body_log_end[index] = end;
		free_body_log_error[index] = error;
	}
	free_body_log_count++;
}

static int fake_sync_visit(void *page_table, unsigned long start,
			   unsigned long end, int pgshift, int flags,
			   void *visit_step, void *arg)
{
	sync_body_visit_count++;
	sync_body_visit_page_table = page_table;
	sync_body_visit_start = start;
	sync_body_visit_end = end;
	sync_body_visit_pgshift = pgshift;
	sync_body_visit_flags = flags;
	sync_body_visit_step = visit_step;
	sync_body_visit_arg = arg;
	return sync_body_visit_rc;
}

static void *fake_copy_lookup(void *vm_arg, unsigned long start,
			      unsigned long end)
{
	struct fake_process_vm_full *vm = vm_arg;

	copy_lookup_count++;
	return process_lookup_memory_range_body_result(vm, start, end);
}

static void *fake_copy_next(void *vm_arg, void *range)
{
	(void)vm_arg;
	copy_next_count++;
	return process_next_memory_range_body_result(range);
}

static void *fake_copy_alloc(unsigned long size)
{
	add_orch_alloc_size = size;
	copy_alloc_count++;
	if (copy_alloc_fail_after && copy_alloc_count == copy_alloc_fail_after)
		return NULL;
	if (copy_alloc_count >
	    (int)(sizeof(copy_alloc_ranges) / sizeof(copy_alloc_ranges[0])))
		return NULL;
	return &copy_alloc_ranges[copy_alloc_count - 1];
}

static void fake_copy_free(void *range)
{
	(void)range;
	copy_free_count++;
}

static int fake_copy_insert(void *vm_arg, void *range)
{
	struct fake_process_vm_full *vm = vm_arg;

	copy_insert_count++;
	return process_vm_range_insert_result(&vm->vm_range_tree, range, vm,
		NULL, NULL);
}

static int fake_copy_visit(void *page_table, unsigned long start,
			   unsigned long end, int pgshift, int flags,
			   void *visit_step, void *arg)
{
	struct fake_copy_user_args *copy_args = arg;

	sync_body_visit_count++;
	sync_body_visit_page_table = page_table;
	sync_body_visit_start ^= start;
	sync_body_visit_end ^= end;
	sync_body_visit_pgshift ^= pgshift;
	sync_body_visit_flags = flags;
	sync_body_visit_step = visit_step;
	sync_body_visit_arg = arg;
	if (copy_visit_rc &&
	    (!copy_visit_fail_after ||
	     sync_body_visit_count >= copy_visit_fail_after)) {
		if (copy_visit_fault_addr != -1)
			copy_args->fault_addr = copy_visit_fault_addr;
		return copy_visit_rc;
	}
	if (copy_visit_fault_addr != -1)
		copy_args->fault_addr = copy_visit_fault_addr;
	return 0;
}

static void fake_copy_log(void *orgvm, void *range, long fault_addr)
{
	(void)orgvm;
	(void)range;
	copy_log_count++;
	copy_log_fault_addr = fault_addr;
}

static void fake_sync_log(void *vm, void *range, unsigned long start,
			  unsigned long end, int error)
{
	(void)vm;
	(void)range;
	sync_body_log_count++;
	sync_body_log_start = start;
	sync_body_log_end = end;
	sync_body_log_error = error;
}

static void fake_remap_log(int event, void *vm, void *range,
			   unsigned long start, unsigned long end, long off,
			   int old_pgshift, int error)
{
	(void)vm;
	(void)range;
	remap_body_log_count++;
	remap_body_log_event = event;
	remap_body_log_start = start;
	remap_body_log_end = end;
	remap_body_log_off = off;
	remap_body_log_old_pgshift = old_pgshift;
	remap_body_log_error = error;
}

static void *fake_invalidate_lookup_pte(void *page_table, unsigned long addr,
					int pgshift, size_t *pgsizep)
{
	int index = invalidate_lookup_count;

	if (index < 2) {
		invalidate_lookup_page_table[index] = page_table;
		invalidate_lookup_addr[index] = addr;
		invalidate_lookup_pgshift[index] = pgshift;
		if (pgsizep)
			*pgsizep = invalidate_lookup_pgsize_result[index];
	}
	invalidate_lookup_count++;
	return index < 2 ? invalidate_lookup_result[index] : NULL;
}

static int fake_invalidate_pte_contiguous(void *ptep)
{
	int index = invalidate_pte_contiguous_count;

	(void)ptep;
	invalidate_pte_contiguous_count++;
	return index < 2 ? invalidate_pte_contiguous_result[index] : 0;
}

static int fake_invalidate_pte_head(void *ptep, size_t pgsize)
{
	(void)ptep;
	(void)pgsize;
	invalidate_pte_head_count++;
	return invalidate_pte_head_result;
}

static int fake_invalidate_pte_tail(void *ptep, size_t pgsize)
{
	(void)ptep;
	(void)pgsize;
	invalidate_pte_tail_count++;
	return invalidate_pte_tail_result;
}

static int fake_invalidate_split(void *ptep, size_t pgsize,
				 unsigned int memobj_flags)
{
	int index = invalidate_split_count;

	if (index < 2) {
		invalidate_split_ptep[index] = ptep;
		invalidate_split_pgsize[index] = pgsize;
		invalidate_split_memobj_flags[index] = memobj_flags;
	}
	invalidate_split_count++;
	return invalidate_split_rc;
}

static int fake_invalidate_one_pte_null(void *ptep)
{
	invalidate_one_pte_null_count++;
	return *(unsigned long *)ptep == 0;
}

static int fake_invalidate_one_pte_fileoff(void *ptep, size_t pgsize)
{
	(void)ptep;
	(void)pgsize;
	invalidate_one_pte_fileoff_count++;
	return invalidate_one_pte_fileoff_result;
}

static unsigned long fake_invalidate_one_pte_get_phys(void *ptep)
{
	(void)ptep;
	invalidate_one_pte_get_phys_count++;
	return invalidate_one_pte_get_phys_result;
}

static void *fake_invalidate_one_phys_to_page(unsigned long phys)
{
	invalidate_one_phys_to_page_count++;
	invalidate_one_phys_to_page_phys = phys;
	return invalidate_one_phys_to_page_result;
}

static long fake_invalidate_one_page_offset(void *page)
{
	(void)page;
	invalidate_one_page_offset_count++;
	return invalidate_one_page_offset_result;
}

static void fake_invalidate_one_make_fileoff(long off, size_t pgsize,
					     void *ptep)
{
	invalidate_one_make_fileoff_count++;
	invalidate_one_make_fileoff_off = off;
	invalidate_one_make_fileoff_pgsize = pgsize;
	*(unsigned long *)ptep = invalidate_one_make_fileoff_value;
}

static void fake_invalidate_one_pte_xchg(void *ptep, void *valp)
{
	unsigned long old = *(unsigned long *)ptep;

	invalidate_one_xchg_count++;
	invalidate_one_xchg_old_value = old;
	invalidate_one_xchg_new_value = *(unsigned long *)valp;
	*(unsigned long *)ptep = *(unsigned long *)valp;
	*(unsigned long *)valp = old;
}

static void fake_invalidate_one_flush(unsigned long addr)
{
	invalidate_one_flush_count++;
	invalidate_one_flush_addr = addr;
}

static int fake_invalidate_one_contiguous(void *ptep)
{
	invalidate_one_contiguous_count++;
	invalidate_one_contiguous_value = *(unsigned long *)ptep;
	return invalidate_one_contiguous_result;
}

static int fake_invalidate_one_head(void *ptep, size_t pgsize)
{
	(void)ptep;
	(void)pgsize;
	invalidate_one_head_count++;
	return invalidate_one_head_result;
}

static int fake_invalidate_one_pgsize_to_tbllv(size_t pgsize)
{
	invalidate_one_pgsize_to_tbllv_count++;
	invalidate_one_pgsize_to_tbllv_pgsize = pgsize;
	return invalidate_one_pgsize_to_tbllv_result;
}

static size_t fake_invalidate_one_tbllv_to_contpgsize(int level)
{
	invalidate_one_tbllv_to_contpgsize_count++;
	invalidate_one_tbllv_to_contpgsize_level = level;
	return invalidate_one_tbllv_to_contpgsize_result;
}

static int fake_invalidate_one_page_unmap(void *page)
{
	invalidate_one_page_unmap_count++;
	invalidate_one_page_unmap_page = page;
	return invalidate_one_page_unmap_rc;
}

static void fake_invalidate_one_panic(const char *message)
{
	invalidate_one_panic_count++;
	invalidate_one_panic_message = message;
}

static int fake_invalidate_one_memobj_invalidate(void *memobj,
						 unsigned long phys,
						 size_t pgsize)
{
	invalidate_one_memobj_invalidate_count++;
	invalidate_one_memobj_invalidate_memobj = memobj;
	invalidate_one_memobj_invalidate_phys = phys;
	invalidate_one_memobj_invalidate_pgsize = pgsize;
	return invalidate_one_memobj_invalidate_rc;
}

static void fake_invalidate_one_log(void *arg, void *page_table, void *ptep,
				    unsigned long pte_value, void *pgaddr,
				    int pgshift, int error)
{
	invalidate_one_log_count++;
	invalidate_one_log_arg = arg;
	invalidate_one_log_page_table = page_table;
	invalidate_one_log_ptep = ptep;
	invalidate_one_log_pte_value = pte_value;
	invalidate_one_log_pgaddr = pgaddr;
	invalidate_one_log_pgshift = pgshift;
	invalidate_one_log_error = error;
}

static int fake_remove_body_split(void *vm, void *range, unsigned long addr,
				  void **splitp)
{
	(void)vm;
	int index = remove_body_split_count;

	if (index < 4) {
		remove_body_split_addr[index] = addr;
		remove_body_split_range[index] = range;
	}
	remove_body_split_count++;
	if (remove_body_split_rc)
		return remove_body_split_rc;
	if (splitp)
		*splitp = remove_body_split_replacement ?
			remove_body_split_replacement : range;
	return 0;
}

static void fake_remove_body_xpmem(void *vm, void *range)
{
	(void)vm;
	remove_body_xpmem_count++;
	remove_body_xpmem_range = range;
}

static int fake_remove_body_free(void *vm, void *range)
{
	(void)vm;
	int index = remove_body_free_count;

	if (index < 4)
		remove_body_free_range[index] = range;
	remove_body_free_count++;
	return remove_body_free_rc;
}

static void fake_remove_body_log(int event, void *vm, unsigned long start,
				 unsigned long end, void *range, int error)
{
	(void)vm;
	int index = remove_body_log_count;

	if (index < 8) {
		remove_body_log_event[index] = event;
		remove_body_log_start[index] = start;
		remove_body_log_end[index] = end;
		remove_body_log_range[index] = range;
		remove_body_log_error[index] = error;
	}
	remove_body_log_count++;
}

static int fake_remove_region_clear(void *page_table, void *vm,
				    unsigned long start, unsigned long end)
{
	remove_region_clear_count++;
	remove_region_clear_page_table = page_table;
	remove_region_clear_vm = vm;
	remove_region_clear_start = start;
	remove_region_clear_end = end;
	return remove_region_clear_rc;
}

static void fake_remove_region_log(void *vm, unsigned long start,
				   unsigned long end)
{
	(void)vm;
	remove_region_log_count++;
	remove_region_log_start = start;
	remove_region_log_end = end;
}

static void reset_process_release_trace(void)
{
	process_mckfd_close_count = 0;
	process_mckfd_close_fd_sum = 0;
	process_mckfd_free_count = 0;
	process_mckfd_free_fd_sum = 0;
	process_memory_free_count = 0;
	process_memory_free_rc = 0;
	process_memory_free_fail_start = 0;
	process_memory_free_start_xor = 0;
	process_memory_log_count = 0;
	process_memory_log_start = 0;
	process_memory_log_end = 0;
	process_memory_log_error = 0;
	process_policy_free_count = 0;
	process_policy_free_id_sum = 0;
	process_detach_count = 0;
	process_detach_pid = 0;
	process_detach_address_space = NULL;
	process_release_count = 0;
	process_release_last_proc = NULL;
	process_optional_free_count = 0;
	process_optional_free_xor = 0;
	process_release_fp_count = 0;
	process_release_fp_thread = NULL;
	process_ref_inc_count = 0;
	process_ref_inc_object = NULL;
	process_ref_inc_offset = 0;
	process_hold_warn_count = 0;
	process_hold_warn_thread = NULL;
	process_ref_dec_count = 0;
	process_ref_dec_object = NULL;
	process_ref_dec_offset = 0;
	process_tid_log_count = 0;
	process_tid_log_tid = 0;
	process_tid_log_new_tid = 0;
	process_tid_log_thread = NULL;
	process_thread_profile_count = 0;
	process_thread_procfs_count = 0;
	process_thread_destroy_count = 0;
	process_thread_release_vm_count = 0;
	process_lifecycle_order = 0;
	process_spin_lock_count = 0;
	process_spin_unlock_count = 0;
	process_spin_lock_addr = 0;
	process_spin_unlock_addr = 0;
	process_spin_unlock_irq = 0;
	process_vm_free_cb_count = 0;
	process_vm_free_cb_vm = NULL;
	process_vm_free_cb_opt = NULL;
	process_vm_flush_count = 0;
	process_vm_free_ranges_count = 0;
	process_vm_free_count = 0;
	process_release_resource_count = 0;
	process_release_resource_value = NULL;
	process_release_hash_count = 0;
	process_release_sibling_count = 0;
	process_release_profile_count = 0;
	process_release_thread_pages_count = 0;
	process_release_thread_pages_thread = NULL;
	process_release_final_count = 0;
	process_release_final_resource = NULL;
	process_mcs_lock_count = 0;
	process_mcs_unlock_count = 0;
	process_mcs_lock_addr = 0;
	process_mcs_unlock_addr = 0;
	process_mcs_lock_node = NULL;
	process_destroy_hash_detach_count = 0;
	process_destroy_hash_detach_thread = NULL;
	process_destroy_time_count = 0;
	process_destroy_time_thread = NULL;
	process_destroy_release_tid_count = 0;
	process_destroy_replace_tid_count = 0;
	process_destroy_replace_tid_new = 0;
	process_destroy_tid_proc = NULL;
	process_destroy_tid_thread = NULL;
	process_destroy_release_sigcommon_count = 0;
	process_destroy_release_sigcommon_ptr = NULL;
	process_lookup_hold_count = 0;
	process_lookup_hold_thread = NULL;
	process_as_free_cb_count = 0;
	process_as_free_cb_asp = NULL;
	process_as_free_cb_opt = NULL;
	process_as_pt_destroy_count = 0;
	process_as_pt_destroy_page_table = NULL;
	process_as_release_count = 0;
	process_as_release_asp = NULL;
	memset(process_as_alloc_space, 0xa5, sizeof(process_as_alloc_space));
	process_as_alloc_count = 0;
	process_as_alloc_fail = 0;
	process_as_alloc_size = 0;
	process_as_alloc_flags = 0;
	process_as_pt_create_count = 0;
	process_as_pt_create_fail = 0;
	process_as_pt_create_flags = 0;
	process_as_ref_set_count = 0;
	process_as_ref_set_object = NULL;
	process_as_ref_set_offset = 0;
	process_as_ref_set_value = 0;
	process_as_spin_init_count = 0;
	process_as_spin_init_addr = 0;
	process_default_ncpus_count = 0;
	process_default_ncpus_value = 0;
	process_create_cpu_log_count = 0;
	process_create_cpu_invalid_count = 0;
	process_create_cpu_requested_count = 0;
	process_create_cpu_last_pid = 0;
	process_create_cpu_last_cpu = 0;
	process_create_cpu_requested_mask = 0;
	process_rwlock_init_count = 0;
	process_rwlock_init_addr = 0;
	process_waitq_init_count = 0;
	process_waitq_init_addr = 0;
	process_mcs_lock_init_count = 0;
	process_mcs_lock_init_addr = 0;
	process_vm_init_numa_log_count = 0;
	process_vm_init_numa_log_id = -1;
}

static void reset_create_thread_trace(void)
{
	reset_process_release_trace();
	memset(&create_thread_store, 0xa5, sizeof(create_thread_store));
	memset(&create_proc_store, 0xa5, sizeof(create_proc_store));
	memset(&create_vm_store, 0xa5, sizeof(create_vm_store));
	memset(&create_as_store, 0xa5, sizeof(create_as_store));
	memset(&create_sigcommon_store, 0xa5, sizeof(create_sigcommon_store));
	create_alloc_pages_count = 0;
	create_alloc_pages_fail = 0;
	create_alloc_pages_npages = 0;
	create_alloc_pages_flags = 0;
	create_alloc_count = 0;
	create_fail_sigcommon = 0;
	memset(create_alloc_size, 0, sizeof(create_alloc_size));
	memset(create_alloc_flags, 0, sizeof(create_alloc_flags));
	create_free_count = 0;
	create_free_xor = 0;
	create_address_space_count = 0;
	create_address_space_fail = 0;
	create_address_space_nslots = 0;
	create_release_address_space_count = 0;
	create_release_address_space_ptr = NULL;
	create_init_process_count = 0;
	create_init_process_parent = NULL;
	create_init_vm_count = 0;
	create_init_vm_owner = NULL;
	create_init_user_count = 0;
	create_init_user_thread = NULL;
	create_init_user_stack_top = 0;
	create_init_user_pc = 0;
	create_init_user_sp = 0;
	create_free_thread_count = 0;
	create_free_thread_ptr = NULL;
}

static void reset_range_access_trace(void)
{
	process_range_lock_count = 0;
	process_range_unlock_count = 0;
	process_range_lock_addr = 0;
	process_range_unlock_addr = 0;
	process_change_attr_count = 0;
	process_change_attr_rc = 0;
	process_change_attr_pt = NULL;
	process_change_attr_start = 0;
	process_change_attr_end = 0;
	process_change_attr_clr = 0;
	process_change_attr_set = 0;
	change_public_log_count = 0;
	change_public_error_count = 0;
	change_public_last_event = 0;
	change_public_last_error = 0;
	change_public_last_protflag = 0;
	change_public_last_vm = NULL;
	change_public_last_range = NULL;
	process_update_pt_count = 0;
	process_update_pt_rc = 0;
	process_update_pt_page_table = NULL;
	process_update_pt_vm = NULL;
	process_update_pt_start = 0;
	process_update_pt_end = 0;
	process_update_pt_phys = 0;
	process_update_pt_attr = 0;
	process_update_pt_pgshift = 0;
	process_update_pt_range = NULL;
	process_update_pt_flags = 0;
	process_update_pt_log_count = 0;
	process_update_pt_log_error = 0;
	access_public_log_count = 0;
	access_public_last_type = 0;
	access_public_last_error = 0;
	access_public_last_addr = 0;
	access_public_last_len = 0;
	access_public_last_vm = NULL;
}

static void reset_page_fault_trace(void)
{
	process_pf_read_lock_count = 0;
	process_pf_read_unlock_count = 0;
	process_pf_write_lock_count = 0;
	process_pf_write_unlock_count = 0;
	process_pf_last_lock_addr = 0;
	process_pf_zero_match_count = 0;
	process_pf_zero_match_result = 0;
	process_pf_normal_count = 0;
	process_pf_xpmem_count = 0;
	process_pf_normal_rc = 0;
	process_pf_xpmem_rc = 0;
	process_pf_last_addr = 0;
	process_pf_last_reason = 0;
	process_pf_last_range = NULL;
	process_pf_retry_calls = 0;
	process_pf_retry_restart_count = 0;
	process_pf_retry_rc = 0;
	process_pf_preempt_enable_count = 0;
	process_pf_preempt_disable_count = 0;
	process_pf_pgio_dispatch_count = 0;
	process_pf_pgio_fp = NULL;
	process_pf_pgio_arg = NULL;
	process_populate_pf_count = 0;
	process_populate_fail_after = 0;
	process_populate_fail_rc = -77;
	process_populate_warn_count = 0;
	process_populate_warn_addr = 0;
	process_populate_warn_off = 0;
	process_populate_warn_len = 0;
	process_populate_warn_error = 0;
}

static unsigned long fake_range_attr(unsigned long flag, unsigned long fault,
				     void *ptep)
{
	return common_vrflag_to_ptattr(flag, fault, ptep);
}

static void fake_range_lock(unsigned long lock_addr)
{
	process_range_lock_count++;
	process_range_lock_addr = lock_addr;
}

static void fake_range_unlock(unsigned long lock_addr)
{
	process_range_unlock_count++;
	process_range_unlock_addr = lock_addr;
}

static int fake_change_attr(void *page_table, unsigned long start,
			    unsigned long end, unsigned long clrattr,
			    unsigned long setattr)
{
	process_change_attr_count++;
	process_change_attr_pt = page_table;
	process_change_attr_start = start;
	process_change_attr_end = end;
	process_change_attr_clr = clrattr;
	process_change_attr_set = setattr;
	return process_change_attr_rc;
}

static void fake_change_public_log(int event, void *vm, void *range,
				   unsigned long protflag, int error)
{
	change_public_log_count++;
	if (event == PROCESS_CHANGE_PROT_PUBLIC_LOG_ERROR)
		change_public_error_count++;
	change_public_last_event = event;
	change_public_last_error = error;
	change_public_last_protflag = protflag;
	change_public_last_vm = vm;
	change_public_last_range = range;
}

static int fake_update_pt_set_range(void *page_table, void *vm,
				    unsigned long start, unsigned long end,
				    unsigned long phys, unsigned long attr,
				    int pgshift, void *range, int flags)
{
	process_update_pt_count++;
	process_update_pt_page_table = page_table;
	process_update_pt_vm = vm;
	process_update_pt_start = start;
	process_update_pt_end = end;
	process_update_pt_phys = phys;
	process_update_pt_attr = attr;
	process_update_pt_pgshift = pgshift;
	process_update_pt_range = range;
	process_update_pt_flags = flags;
	return process_update_pt_rc;
}

static void fake_update_pt_log(int error)
{
	process_update_pt_log_count++;
	process_update_pt_log_error = error;
}

static void fake_access_public_log(void *vm, int verify_type,
				   unsigned long addr, size_t len, int error)
{
	access_public_log_count++;
	access_public_last_vm = vm;
	access_public_last_type = verify_type;
	access_public_last_addr = addr;
	access_public_last_len = len;
	access_public_last_error = error;
}

static void fake_pf_read_lock(unsigned long lock_addr)
{
	process_pf_read_lock_count++;
	process_pf_last_lock_addr = lock_addr;
}

static void fake_pf_read_unlock(unsigned long lock_addr)
{
	process_pf_read_unlock_count++;
	process_pf_last_lock_addr = lock_addr;
}

static void fake_pf_write_lock(unsigned long lock_addr)
{
	process_pf_write_lock_count++;
	process_pf_last_lock_addr = lock_addr;
}

static void fake_pf_write_unlock(unsigned long lock_addr)
{
	process_pf_write_unlock_count++;
	process_pf_last_lock_addr = lock_addr;
}

static int fake_zeroobj_match(void *memobj)
{
	(void)memobj;
	process_pf_zero_match_count++;
	return process_pf_zero_match_result;
}

static int fake_normal_fault(void *vm, void *range, unsigned long addr,
			     unsigned long reason)
{
	(void)vm;
	process_pf_normal_count++;
	process_pf_last_range = range;
	process_pf_last_addr = addr;
	process_pf_last_reason = reason;
	if (process_pf_retry_restart_count &&
	    process_pf_normal_count <= process_pf_retry_restart_count)
		return -85;
	return process_pf_normal_rc;
}

static int fake_xpmem_fault(void *vm, void *range, unsigned long addr,
			    unsigned long reason)
{
	(void)vm;
	process_pf_xpmem_count++;
	process_pf_last_range = range;
	process_pf_last_addr = addr;
	process_pf_last_reason = reason;
	return process_pf_xpmem_rc;
}

static int fake_retry_fault(void *vm, unsigned long addr,
			    unsigned long reason)
{
	(void)vm;
	process_pf_retry_calls++;
	process_pf_last_addr = addr;
	process_pf_last_reason = reason;
	if (process_pf_retry_calls <= process_pf_retry_restart_count)
		return -85;
	return process_pf_retry_rc;
}

static void fake_preempt_enable(void)
{
	process_pf_preempt_enable_count++;
}

static void fake_preempt_disable(void)
{
	process_pf_preempt_disable_count++;
}

static void fake_pgio_dispatch(void *fp, void *arg)
{
	process_pf_pgio_dispatch_count++;
	process_pf_pgio_fp = fp;
	process_pf_pgio_arg = arg;
}

static int fake_populate_fault(void *vm, unsigned long addr,
			       unsigned long reason)
{
	(void)vm;
	process_populate_pf_count++;
	process_pf_last_addr = addr;
	process_pf_last_reason = reason;
	if (process_populate_fail_after &&
	    process_populate_pf_count >= process_populate_fail_after)
		return process_populate_fail_rc;
	return 0;
}

	static void fake_populate_warn(void *vm, unsigned long addr,
				       unsigned long reason, unsigned long off,
				       size_t len, int error)
	{
	(void)vm;
	(void)reason;
	process_populate_warn_count++;
	process_populate_warn_addr = addr;
	process_populate_warn_off = off;
		process_populate_warn_len = len;
		process_populate_warn_error = error;
	}

	static void process_stack_ptr_store(unsigned char *base, unsigned long off,
					    void *ptr)
	{
		*(void **)(base + off) = ptr;
	}

	static void process_stack_ulong_store(unsigned char *base, unsigned long off,
					      unsigned long value)
	{
		*(unsigned long *)(base + off) = value;
	}

	static void process_stack_int_store(unsigned char *base, unsigned long off,
					    int value)
	{
		*(int *)(base + off) = value;
	}

	static unsigned long process_stack_ulong_load(unsigned char *base,
						      unsigned long off)
	{
		return *(unsigned long *)(base + off);
	}

	static int process_stack_int_load(unsigned char *base, unsigned long off)
	{
		return *(int *)(base + off);
	}

	static void reset_process_stack_trace(void)
	{
		memset(process_stack_thread, 0, sizeof(process_stack_thread));
		memset(process_stack_process, 0, sizeof(process_stack_process));
		memset(&process_stack_vm, 0, sizeof(process_stack_vm));
		memset(&process_stack_aspace, 0, sizeof(process_stack_aspace));
		memset(&process_stack_range, 0, sizeof(process_stack_range));
		memset(process_stack_pages, 0xaa, sizeof(process_stack_pages));
		process_stack_ptr_store(process_stack_thread,
			PROCESS_STACK_THREAD_VM_OFF, &process_stack_vm);
		process_stack_ptr_store(process_stack_thread,
			PROCESS_STACK_THREAD_UCTX_OFF, (void *)0x77770000UL);
		process_stack_ptr_store(process_stack_thread,
			PROCESS_STACK_THREAD_PROC_OFF, process_stack_process);
		process_stack_int_store(process_stack_thread,
			PROCESS_STACK_THREAD_TID_OFF, 2468);
		process_stack_ptr_store(process_stack_process,
			PROCESS_STACK_PROCESS_RLIMIT_OFF +
			15 * sizeof(struct rlimit), (void *)0);
		process_stack_int_store(process_stack_process,
			PROCESS_STACK_PROCESS_PID_OFF, 1357);
		process_stack_int_store(process_stack_process,
			PROCESS_STACK_PROCESS_RUID_OFF, 11);
		process_stack_int_store(process_stack_process,
			PROCESS_STACK_PROCESS_EUID_OFF, 12);
		process_stack_int_store(process_stack_process,
			PROCESS_STACK_PROCESS_RGID_OFF, 13);
		process_stack_int_store(process_stack_process,
			PROCESS_STACK_PROCESS_EGID_OFF, 14);
		process_stack_ulong_store(process_stack_process,
			PROCESS_STACK_PROCESS_RLIMIT_OFF +
			15 * sizeof(struct rlimit), 8 * 1024 * 1024UL);
		process_stack_ulong_store(process_stack_process,
			PROCESS_STACK_PROCESS_MPOL_FLAGS_OFF, 0);
		process_stack_ulong_store(process_stack_process,
			PROCESS_STACK_PROCESS_MPOL_THRESHOLD_OFF,
			1024 * 1024UL);
		process_stack_vm.address_space = &process_stack_aspace;
		process_stack_vm.region.map_start = 0x0000400000000000UL;
		process_stack_vm.region.user_end = 0x0000800000000000UL;
		process_stack_vm.vdso_addr = (void *)0x700000001000UL;
		process_stack_aspace.page_table = (void *)0x12345678000UL;
		process_stack_alloc_count = 0;
		process_stack_alloc_fail = 0;
		process_stack_alloc_npages = 0;
		process_stack_alloc_p2align = 0;
		process_stack_alloc_flags = 0;
		process_stack_alloc_addr = 0;
		process_stack_free_count = 0;
		process_stack_free_addr = NULL;
		process_stack_free_npages = 0;
		process_stack_add_count = 0;
		process_stack_add_rc = 0;
		process_stack_add_null_range = 0;
		process_stack_add_start = 0;
		process_stack_add_end = 0;
		process_stack_add_phys = 0;
		process_stack_add_flag = 0;
		process_stack_add_pgshift = 0;
		process_stack_pt_count = 0;
		process_stack_pt_rc = 0;
		process_stack_pt_page_table = NULL;
		process_stack_pt_vm = NULL;
		process_stack_pt_start = 0;
		process_stack_pt_end = 0;
		process_stack_pt_phys = 0;
		process_stack_pt_attr = 0;
		process_stack_pt_pgshift = 0;
		process_stack_pt_range = NULL;
		process_stack_hwcap_count = 0;
		process_stack_modify_count = 0;
		process_stack_modify_uctx = NULL;
		process_stack_modify_reg = 0;
		process_stack_modify_value = 0;
		memset(process_stack_log_count, 0, sizeof(process_stack_log_count));
		process_stack_log_last_event = 0;
		memset(process_stack_log_arg, 0, sizeof(process_stack_log_arg));
	}

	static void *fake_process_stack_alloc_aligned(int npages, int p2align,
			unsigned long flags, unsigned long virt_addr)
	{
		process_stack_alloc_count++;
		process_stack_alloc_npages = npages;
		process_stack_alloc_p2align = p2align;
		process_stack_alloc_flags = flags;
		process_stack_alloc_addr = virt_addr;
		return process_stack_alloc_fail ? NULL : process_stack_pages;
	}

	static void fake_process_stack_free_pages(void *addr, int npages)
	{
		process_stack_free_count++;
		process_stack_free_addr = addr;
		process_stack_free_npages = npages;
	}

	static int fake_process_stack_add_range(void *vm, unsigned long start,
			unsigned long end, unsigned long phys, unsigned long flag,
			int pgshift, void **rangep)
	{
		process_stack_add_count++;
		process_stack_add_start = start;
		process_stack_add_end = end;
		process_stack_add_phys = phys;
		process_stack_add_flag = flag;
		process_stack_add_pgshift = pgshift;
		require(vm == &process_stack_vm);
		if (process_stack_add_rc)
			return process_stack_add_rc;
		if (rangep)
			*rangep = process_stack_add_null_range ? NULL :
				&process_stack_range;
		process_stack_range.start = start;
		process_stack_range.end = end;
		process_stack_range.flag = flag;
		process_stack_range.pgshift = pgshift;
		return 0;
	}

	static unsigned long fake_process_stack_virt_to_phys(void *addr)
	{
		return (unsigned long)(uintptr_t)addr + 0x100000000UL;
	}

	static unsigned long fake_process_stack_attr(unsigned long flag,
			unsigned long fault, void *ptep)
	{
		(void)ptep;
		return flag ^ fault ^ 0x5555UL;
	}

	static int fake_process_stack_pt_set_range(void *page_table, void *vm,
			unsigned long start, unsigned long end, unsigned long phys,
			unsigned long attr, int pgshift, void *range, int flags)
	{
		(void)flags;
		process_stack_pt_count++;
		process_stack_pt_page_table = page_table;
		process_stack_pt_vm = vm;
		process_stack_pt_start = start;
		process_stack_pt_end = end;
		process_stack_pt_phys = phys;
		process_stack_pt_attr = attr;
		process_stack_pt_pgshift = pgshift;
		process_stack_pt_range = range;
		return process_stack_pt_rc;
	}

	static unsigned long fake_process_stack_hwcap(void)
	{
		process_stack_hwcap_count++;
		return 0xabcddcbaUL;
	}

	static void fake_process_stack_modify_context(void *uctx, int reg,
			unsigned long value)
	{
		process_stack_modify_count++;
		process_stack_modify_uctx = uctx;
		process_stack_modify_reg = reg;
		process_stack_modify_value = value;
	}

	static void fake_process_stack_log(int event, const unsigned long *args)
	{
		int i;

		if (event >= 0 && event < (int)(sizeof(process_stack_log_count) /
						sizeof(process_stack_log_count[0])))
			process_stack_log_count[event]++;
		process_stack_log_last_event = event;
		for (i = 0; i < 12; ++i)
			process_stack_log_arg[i] = args ? args[i] : 0;
	}

	static int fake_process_stack_call(struct program_load_desc *pn,
			int argc, char **argv, int envc, char **env,
			unsigned long stack_alloc_size_override)
	{
		return process_init_stack_body_result(process_stack_thread, pn,
			0x44440000UL, argc, argv, envc, env, PAGE_SIZE,
			PAGE_SHIFT, USER_STACK_PAGE_MASK, USER_STACK_PAGE_SHIFT,
			USER_STACK_PREPAGE_SIZE, stack_alloc_size_override,
			USER_STACK_PAGE_P2ALIGN, IHK_MC_AP_NOWAIT, IHK_MC_AP_USER,
			MPOL_NO_STACK, IHK_UCR_STACK_POINTER, PF_POPULATE,
			fake_process_stack_alloc_aligned,
			fake_process_stack_free_pages,
			fake_process_stack_add_range,
			fake_process_stack_virt_to_phys,
			fake_process_stack_attr,
			fake_process_stack_pt_set_range,
			fake_process_stack_hwcap,
			fake_process_stack_modify_context,
			fake_process_stack_log);
	}

	static int fake_mckfd_close(struct fake_mckfd *fdp, void *ctx)
{
	(void)ctx;
	process_mckfd_close_count++;
	process_mckfd_close_fd_sum += fdp->fd;
	return 0;
}

static void fake_mckfd_free(struct fake_mckfd *fdp)
{
	process_mckfd_free_count++;
	process_mckfd_free_fd_sum += fdp->fd;
}

static int fake_memory_range_free(void *vm, void *range)
{
	struct fake_vm_range *vr = range;

	(void)vm;
	process_memory_free_count++;
	process_memory_free_start_xor ^= vr->start;
	if (process_memory_free_fail_start &&
	    vr->start != process_memory_free_fail_start)
		return 0;
	return process_memory_free_rc;
}

static void fake_memory_range_log(void *vm, void *range, int error)
{
	struct fake_vm_range *vr = range;

	(void)vm;
	process_memory_log_count++;
	process_memory_log_start = vr->start;
	process_memory_log_end = vr->end;
	process_memory_log_error = error;
}

static void fake_policy_free(void *policy)
{
	struct fake_policy *p = policy;

	process_policy_free_count++;
	process_policy_free_id_sum += p->id;
}

static void fake_detach_address_space(void *address_space, int pid)
{
	process_detach_count++;
	process_detach_address_space = address_space;
	process_detach_pid = pid;
}

static void fake_release_process(void *proc)
{
	process_release_count++;
	process_release_last_proc = proc;
}

static void fake_optional_free(void *ptr)
{
	process_optional_free_count++;
	process_optional_free_xor ^= (unsigned long)ptr;
}

static void fake_release_fp_regs(void *thread)
{
	process_release_fp_count++;
	process_release_fp_thread = thread;
}

static void fake_ref_inc(void *object, unsigned long ref_offset)
{
	process_ref_inc_count++;
	process_ref_inc_object = object;
	process_ref_inc_offset = ref_offset;
	(*(int *)((char *)object + ref_offset))++;
}

static void fake_hold_warn(void *thread)
{
	process_hold_warn_count++;
	process_hold_warn_thread = thread;
}

static int fake_ref_dec_and_test(void *object, unsigned long ref_offset)
{
	process_ref_dec_count++;
	process_ref_dec_object = object;
	process_ref_dec_offset = ref_offset;
	return *(int *)((char *)object + ref_offset);
}

static void fake_tid_log(int tid, void *thread, int new_tid)
{
	process_tid_log_count++;
	process_tid_log_tid = tid;
	process_tid_log_thread = thread;
	process_tid_log_new_tid = new_tid;
}

static void fake_thread_profile(void *thread, void *proc)
{
	(void)thread;
	(void)proc;
	process_thread_profile_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 1;
}

static void fake_thread_procfs_delete(void *thread)
{
	(void)thread;
	process_thread_procfs_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 2;
}

static void fake_thread_destroy(void *thread)
{
	(void)thread;
	process_thread_destroy_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 3;
}

static void fake_thread_release_vm(void *vm)
{
	(void)vm;
	process_thread_release_vm_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 4;
}

static unsigned long fake_spin_lock(unsigned long lock_addr)
{
	process_spin_lock_count++;
	process_spin_lock_addr = lock_addr;
	process_lifecycle_order = process_lifecycle_order * 16 + 5;
	return 0x12345678UL;
}

static void fake_spin_unlock(unsigned long lock_addr, unsigned long irqstate)
{
	process_spin_unlock_count++;
	process_spin_unlock_addr = lock_addr;
	process_spin_unlock_irq = irqstate;
	process_lifecycle_order = process_lifecycle_order * 16 + 6;
}

static void fake_vm_free_cb(void *vm, void *opt)
{
	process_vm_free_cb_count++;
	process_vm_free_cb_vm = vm;
	process_vm_free_cb_opt = opt;
	process_lifecycle_order = process_lifecycle_order * 16 + 7;
}

static void fake_vm_flush(void *vm)
{
	(void)vm;
	process_vm_flush_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 8;
}

static void fake_vm_free_ranges(void *vm)
{
	(void)vm;
	process_vm_free_ranges_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 9;
}

static void fake_vm_free(void *vm)
{
	(void)vm;
	process_vm_free_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 10;
}

static void *fake_current_resource_set(void)
{
	process_release_resource_count++;
	process_release_resource_value = (void *)0xfeedcafeUL;
	process_lifecycle_order = process_lifecycle_order * 16 + 11;
	return process_release_resource_value;
}

static void fake_release_hash_detach(void *resource_set, void *proc)
{
	(void)proc;
	if (resource_set != process_release_resource_value)
		exit(2);
	process_release_hash_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 12;
}

static void fake_release_sibling_detach(void *proc)
{
	(void)proc;
	process_release_sibling_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 13;
}

static void fake_release_profile(void *proc)
{
	(void)proc;
	process_release_profile_count++;
	process_lifecycle_order = process_lifecycle_order * 16 + 14;
}

static void fake_release_thread_pages(void *thread)
{
	process_release_thread_pages_count++;
	process_release_thread_pages_thread = thread;
	process_lifecycle_order = process_lifecycle_order * 16 + 15;
}

	static void fake_release_final_cleanup(void *resource_set)
	{
		process_release_final_count++;
		process_release_final_resource = resource_set;
		process_lifecycle_order = process_lifecycle_order * 16 + 16;
	}

	static void fake_process_mcs_lock(unsigned long lock_addr, void *node)
	{
		process_mcs_lock_count++;
		process_mcs_lock_addr = lock_addr;
		process_mcs_lock_node = node;
	}

	static void fake_process_mcs_unlock(unsigned long lock_addr, void *node)
	{
		(void)node;
		process_mcs_unlock_count++;
		process_mcs_unlock_addr = lock_addr;
	}

	static void fake_destroy_hash_detach(void *thread)
	{
		process_destroy_hash_detach_count++;
		process_destroy_hash_detach_thread = thread;
	}

	static void fake_destroy_time_account(void *thread)
	{
		process_destroy_time_count++;
		process_destroy_time_thread = thread;
	}

	static void fake_destroy_release_tid(void *proc, void *thread)
	{
		process_destroy_release_tid_count++;
		process_destroy_tid_proc = proc;
		process_destroy_tid_thread = thread;
	}

	static void fake_destroy_replace_tid(void *proc, void *thread, int new_tid)
	{
		process_destroy_replace_tid_count++;
		process_destroy_replace_tid_new = new_tid;
		process_destroy_tid_proc = proc;
		process_destroy_tid_thread = thread;
	}

	static void fake_destroy_release_sigcommon(void *sigcommon)
	{
		process_destroy_release_sigcommon_count++;
		process_destroy_release_sigcommon_ptr = sigcommon;
	}

	static void fake_process_lookup_hold_thread(void *thread)
	{
		process_lookup_hold_count++;
		process_lookup_hold_thread = thread;
	}

	static void fake_address_space_free_cb(void *asp, void *opt)
	{
	process_as_free_cb_count++;
	process_as_free_cb_asp = asp;
	process_as_free_cb_opt = opt;
}

static void fake_address_space_pt_destroy(void *page_table)
{
	process_as_pt_destroy_count++;
	process_as_pt_destroy_page_table = page_table;
}

static void fake_address_space_release(void *asp)
{
	process_as_release_count++;
	process_as_release_asp = asp;
}

static void *fake_address_space_alloc(unsigned long size, unsigned long flags)
{
	process_as_alloc_count++;
	process_as_alloc_size = size;
	process_as_alloc_flags = flags;
	if (process_as_alloc_fail || size > sizeof(process_as_alloc_space))
		return NULL;
	return process_as_alloc_space;
}

static void *fake_address_space_pt_create(unsigned long flags)
{
	process_as_pt_create_count++;
	process_as_pt_create_flags = flags;
	return process_as_pt_create_fail ? NULL : (void *)0xabcdef000UL;
}

static void fake_ref_set(void *object, unsigned long ref_offset, int value)
{
	process_as_ref_set_count++;
	process_as_ref_set_object = object;
	process_as_ref_set_offset = ref_offset;
	process_as_ref_set_value = value;
	*(int *)((char *)object + ref_offset) = value;
}

static void fake_spin_init(unsigned long lock_addr)
{
	process_as_spin_init_count++;
	process_as_spin_init_addr = lock_addr;
	*(unsigned int *)(uintptr_t)lock_addr = 0x13572468U;
}

static int fake_default_ncpus(void)
{
	process_default_ncpus_count++;
	return process_default_ncpus_value;
}

static void fake_create_cpu_log(int event, int pid, int cpu)
{
	process_create_cpu_log_count++;
	process_create_cpu_last_pid = pid;
	process_create_cpu_last_cpu = cpu;
	if (event == 1) {
		process_create_cpu_invalid_count++;
	}
	else if (event == 2) {
		process_create_cpu_requested_count++;
		if (cpu >= 0 && cpu < (int)(sizeof(unsigned long) * 8))
			process_create_cpu_requested_mask |= 1UL << cpu;
	}
}

static void fake_rwlock_init(unsigned long lock_addr)
{
	process_rwlock_init_count++;
	process_rwlock_init_addr = lock_addr;
	*(unsigned int *)(uintptr_t)lock_addr = 0x2468ace0U;
}

static void fake_waitq_init(unsigned long waitq_addr)
{
	process_waitq_init_count++;
	process_waitq_init_addr = waitq_addr;
	*(unsigned int *)(uintptr_t)waitq_addr = 0x55aa33ccU;
}

static void fake_mcs_lock_init(unsigned long lock_addr)
{
	process_mcs_lock_init_count++;
	process_mcs_lock_init_addr = lock_addr;
	*(unsigned int *)(uintptr_t)lock_addr = 0x0badc0deU;
}

static void fake_vm_init_numa_log(int numa_id)
{
	process_vm_init_numa_log_count++;
	process_vm_init_numa_log_id = numa_id;
}

static void *fake_create_alloc_pages(int npages, unsigned long flags)
{
	create_alloc_pages_count++;
	create_alloc_pages_npages = npages;
	create_alloc_pages_flags = flags;
	return create_alloc_pages_fail ? NULL : &create_thread_store;
}

static void *fake_create_alloc(unsigned long size, unsigned long flags)
{
	int index = create_alloc_count;

	if (index < 4) {
		create_alloc_size[index] = size;
		create_alloc_flags[index] = flags;
	}
	create_alloc_count++;
	if (index == 0 && size == sizeof(create_proc_store))
		return &create_proc_store;
	if (index == 1 && size == sizeof(create_vm_store))
		return &create_vm_store;
	if (index == 2 && size == sizeof(create_sigcommon_store))
		return create_fail_sigcommon ? NULL : &create_sigcommon_store;
	return NULL;
}

static void fake_create_free(void *ptr)
{
	create_free_count++;
	create_free_xor ^= (unsigned long)(uintptr_t)ptr;
}

static void *fake_create_address_space(int nslots)
{
	create_address_space_count++;
	create_address_space_nslots = nslots;
	if (create_address_space_fail)
		return NULL;
	memset(&create_as_store, 0, sizeof(create_as_store));
	return &create_as_store;
}

static void fake_create_release_address_space(void *asp)
{
	create_release_address_space_count++;
	create_release_address_space_ptr = asp;
	create_as_store.released = 1;
}

static int fake_create_init_process(void *proc, void *parent)
{
	struct fake_create_process_obj *process = proc;

	create_init_process_count++;
	create_init_process_parent = parent;
	process->pid = 77;
	return 0;
}

static int fake_create_init_vm(void *owner, void *asp, void *vm)
{
	struct fake_create_vm_obj *v = vm;

	create_init_vm_count++;
	create_init_vm_owner = owner;
	v->owner = owner;
	v->address_space = asp;
	v->initialized = 1;
	return 0;
}

static void fake_create_init_user(void *thread, unsigned long stack_top,
				  unsigned long user_pc, unsigned long user_sp)
{
	struct fake_create_thread_obj *t = thread;

	create_init_user_count++;
	create_init_user_thread = thread;
	create_init_user_stack_top = stack_top;
	create_init_user_pc = user_pc;
	create_init_user_sp = user_sp;
	t->ctx_marker = user_pc ^ stack_top;
	t->uctx_marker = user_sp ^ 0xfacefeedUL;
}

static void fake_create_free_thread(void *thread)
{
	create_free_thread_count++;
	create_free_thread_ptr = thread;
}

static void mix_range_tree(unsigned long *digest, struct fake_rb_node *node)
{
	struct fake_vm_range *range;

	if (!node) {
		mix(digest, 0);
		return;
	}

	mix_range_tree(digest, node->rb_left);
	range = (struct fake_vm_range *)node;
	mix(digest, range->start);
	mix(digest, range->end);
	mix(digest, range->flag);
	mix_range_tree(digest, node->rb_right);
}

static void fake_list_init(struct fake_list_head *head)
{
	head->next = head;
	head->prev = head;
}

static void fake_list_add_tail(struct fake_list_head *entry,
			       struct fake_list_head *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static int boot_cpu_local_covers(const void *ptr, size_t bytes)
{
	uintptr_t base = (uintptr_t)boot_cpu_local_store;
	uintptr_t addr = (uintptr_t)ptr;

	return addr >= base && bytes <= sizeof(boot_cpu_local_store) &&
		addr - base <= sizeof(boot_cpu_local_store) - bytes;
}

static int boot_cpu_local_contains_ptr(const void *ptr)
{
	size_t i;

	if (!ptr)
		return 0;
	for (i = 0; i + sizeof(ptr) <= sizeof(boot_cpu_local_store); i++) {
		void *candidate;

		memcpy(&candidate, boot_cpu_local_store + i,
		       sizeof(candidate));
		if (candidate == ptr)
			return 1;
	}
	return 0;
}

static int boot_cpu_local_count_u32(unsigned int value)
{
	size_t i;
	int count = 0;

	for (i = 0; i + sizeof(value) <= sizeof(boot_cpu_local_store); i++) {
		unsigned int candidate;

		memcpy(&candidate, boot_cpu_local_store + i,
		       sizeof(candidate));
		if (candidate == value)
			count++;
	}
	return count;
}

static int boot_cpu_local_count_self_lists(void)
{
	uintptr_t base = (uintptr_t)boot_cpu_local_store;
	size_t i;
	int count = 0;

	for (i = 0; i + 2 * sizeof(void *) <= sizeof(boot_cpu_local_store);
	     i += sizeof(void *)) {
		void *next;
		void *prev;

		memcpy(&next, boot_cpu_local_store + i, sizeof(next));
		memcpy(&prev, boot_cpu_local_store + i + sizeof(void *),
		       sizeof(prev));
		if (next == (void *)(base + i) && prev == (void *)(base + i))
			count++;
	}
	return count;
}

static void reset_boot_init_trace(void)
{
	memset(boot_resource_store, 0xa5, sizeof(boot_resource_store));
	memset(boot_phash_store, 0xa5, sizeof(boot_phash_store));
	memset(boot_thash_store, 0xa5, sizeof(boot_thash_store));
	memset(boot_pid1_store, 0xa5, sizeof(boot_pid1_store));
	memset(boot_path_store, 0xa5, sizeof(boot_path_store));
	memset(boot_cpu_local_store, 0xa5, sizeof(boot_cpu_local_store));
	boot_resource_list.next = &boot_resource_list;
	boot_resource_list.prev = &boot_resource_list;
	boot_alloc_count = 0;
	boot_alloc_fail_at = 0;
	memset(boot_alloc_size, 0, sizeof(boot_alloc_size));
	memset(boot_alloc_flags, 0, sizeof(boot_alloc_flags));
	boot_free_count = 0;
	boot_free_xor = 0;
	boot_init_process_count = 0;
	boot_init_process_last_proc = NULL;
	boot_init_process_last_parent = NULL;
	boot_context_count = 0;
	boot_context_thread = NULL;
	boot_save_fp_count = 0;
	boot_save_fp_thread = NULL;
	boot_timer_count = 0;
	boot_timer_cpu = -1;
}

static void *fake_boot_alloc(unsigned long size, unsigned long flags)
{
	int index = boot_alloc_count++;

	if (index < (int)(sizeof(boot_alloc_size) / sizeof(boot_alloc_size[0]))) {
		boot_alloc_size[index] = size;
		boot_alloc_flags[index] = flags;
	}
	if (boot_alloc_fail_at && index + 1 == boot_alloc_fail_at)
		return NULL;
	if (index == 0 && size == PROCESS_ABI_RESOURCE_SIZE)
		return boot_resource_store;
	if (index == 1 && size == PROCESS_ABI_PROCESS_HASH_SIZE)
		return boot_phash_store;
	if (index == 2 && size == PROCESS_ABI_THREAD_HASH_SIZE)
		return boot_thash_store;
	if (index == 3 && size == PROCESS_ABI_PROCESS_SIZE)
		return boot_pid1_store;
	if (size == sizeof(boot_path_store))
		return boot_path_store;
	return NULL;
}

static void fake_boot_free(void *ptr)
{
	boot_free_count++;
	boot_free_xor ^= (unsigned long)(uintptr_t)ptr;
}

static int fake_boot_init_process(void *proc, void *parent)
{
	boot_init_process_count++;
	boot_init_process_last_proc = proc;
	boot_init_process_last_parent = parent;
	fake_list_init((struct fake_list_head *)((char *)proc +
		PROCESS_ABI_PROCESS_CHILDREN_LIST_OFF));
	return 0;
}

static void fake_boot_init_context(void *thread)
{
	boot_context_count++;
	boot_context_thread = thread;
	*(unsigned long *)((char *)thread + PROCESS_ABI_THREAD_CTX_OFF) =
		0xabcdef0123456789UL;
}

static int fake_boot_save_fp(void *thread)
{
	boot_save_fp_count++;
	boot_save_fp_thread = thread;
	return 0;
}

static void fake_boot_timer_init(int cpu)
{
	boot_timer_count++;
	boot_timer_cpu = cpu;
}

static int fake_ptrace_traceme_lock_calls;
static int fake_ptrace_traceme_unlock_calls;
static unsigned long fake_ptrace_traceme_last_lock;
static void *fake_ptrace_traceme_last_node;
static int fake_ptrace_traceme_alloc_calls;
static int fake_ptrace_traceme_alloc_rc;
static int fake_ptrace_traceme_log_events[6];
static int fake_ptrace_traceme_log_count;
static int fake_ptrace_traceme_log_pid;
static int fake_ptrace_traceme_log_error;

static void fake_ptrace_traceme_lock(unsigned long lock_addr, void *node)
{
	fake_ptrace_traceme_lock_calls++;
	fake_ptrace_traceme_last_lock = lock_addr;
	fake_ptrace_traceme_last_node = node;
}

static void fake_ptrace_traceme_unlock(unsigned long lock_addr, void *node)
{
	(void)lock_addr;
	(void)node;
	fake_ptrace_traceme_unlock_calls++;
}

static int fake_ptrace_traceme_alloc_debugreg(void *thread)
{
	struct fake_thread *fake = thread;

	fake_ptrace_traceme_alloc_calls++;
	fake->ptrace_debugreg = (void *)0xabcddcbaUL;
	return fake_ptrace_traceme_alloc_rc;
}

static void fake_ptrace_traceme_clear_single_step(void *thread)
{
	((struct fake_thread *)thread)->clear_single_step_calls++;
}

static void fake_ptrace_traceme_hold_thread(void *thread)
{
	((struct fake_thread *)thread)->hold_calls++;
}

static void fake_ptrace_traceme_log(int event, int pid,
				    unsigned long value, int error)
{
	(void)value;
	if (fake_ptrace_traceme_log_count <
	    (int)(sizeof(fake_ptrace_traceme_log_events) /
		  sizeof(fake_ptrace_traceme_log_events[0]))) {
		fake_ptrace_traceme_log_events[
			fake_ptrace_traceme_log_count] = event;
	}
	fake_ptrace_traceme_log_count++;
	fake_ptrace_traceme_log_pid = pid;
	fake_ptrace_traceme_log_error = error;
}

extern int process_memset_smp_handler_body_result(
	int cpu_index, int nr_cpus, unsigned long phys, size_t len, int value,
	void *(*phys_to_virt_fn)(unsigned long),
	void (*memset_fn)(void *, int, size_t),
	void (*log_fn)(int, int, int, unsigned long, size_t,
		       unsigned long, unsigned long));
extern int process_memset_smp_body_result(
	void *cpu_set, void *addr, int value, size_t len,
	unsigned long *phys_slot, size_t *len_slot, int *value_slot,
	void *handler, void *request, unsigned long (*virt_to_phys_fn)(void *),
	int (*smp_call_fn)(void *, void *, void *));

struct fake_memset_smp_req {
	unsigned long phys;
	size_t len;
	int value;
};

static unsigned char fake_memset_smp_memory[128];
static int fake_memset_smp_calls;
static unsigned long fake_memset_smp_last_start;
static size_t fake_memset_smp_last_len;
static int fake_memset_smp_last_value;
static int fake_memset_smp_log_calls;
static unsigned long fake_memset_smp_log_digest;
static void *fake_memset_smp_last_cpu_set;
static void *fake_memset_smp_last_handler;
static void *fake_memset_smp_last_request;
static int fake_memset_smp_return;

static void reset_fake_memset_smp(void)
{
	memset(fake_memset_smp_memory, 0, sizeof(fake_memset_smp_memory));
	fake_memset_smp_calls = 0;
	fake_memset_smp_last_start = 0;
	fake_memset_smp_last_len = 0;
	fake_memset_smp_last_value = 0;
	fake_memset_smp_log_calls = 0;
	fake_memset_smp_log_digest = 0x6d736d70726f6355UL;
	fake_memset_smp_last_cpu_set = NULL;
	fake_memset_smp_last_handler = NULL;
	fake_memset_smp_last_request = NULL;
	fake_memset_smp_return = 0;
}

static void *fake_memset_smp_phys_to_virt(unsigned long phys)
{
	return fake_memset_smp_memory + (phys - 0x1000UL);
}

static unsigned long fake_memset_smp_virt_to_phys(void *addr)
{
	return 0x1000UL + ((unsigned char *)addr - fake_memset_smp_memory);
}

static void fake_memset_smp_memset(void *addr, int value, size_t len)
{
	fake_memset_smp_calls++;
	fake_memset_smp_last_start =
		0x1000UL + ((unsigned char *)addr - fake_memset_smp_memory);
	fake_memset_smp_last_len = len;
	fake_memset_smp_last_value = value;
	memset(addr, value, len);
}

static void fake_memset_smp_log(int event, int cpu_index, int nr_cpus,
				unsigned long phys, size_t len,
				unsigned long start, unsigned long end)
{
	fake_memset_smp_log_calls++;
	mix(&fake_memset_smp_log_digest, (unsigned int)event);
	mix(&fake_memset_smp_log_digest, (unsigned int)cpu_index);
	mix(&fake_memset_smp_log_digest, (unsigned int)nr_cpus);
	mix(&fake_memset_smp_log_digest, phys);
	mix(&fake_memset_smp_log_digest, len);
	mix(&fake_memset_smp_log_digest, start);
	mix(&fake_memset_smp_log_digest, end);
}

static int fake_memset_smp_call(void *cpu_set, void *handler, void *request)
{
	fake_memset_smp_last_cpu_set = cpu_set;
	fake_memset_smp_last_handler = handler;
	fake_memset_smp_last_request = request;
	return fake_memset_smp_return;
}

int main(void)
{
	unsigned long digest = 0x50524f4348454c50UL;
	unsigned long clr = 0, set = 0;
	struct fake_tid tids[3] = {
		{ 10, (void *)0x1000 },
		{ 11, (void *)0x2000 },
		{ 12, (void *)0x3000 },
	};
	struct fake_list_head pending_head;
	struct fake_list_head other_head;
	struct fake_list_head old_children;
	struct fake_list_head new_children;
	struct fake_list_head new_ptraced;
	struct fake_pending pending_a = { { 0 }, 0xa1 };
	struct fake_pending pending_b = { { 0 }, 0xb2 };
	struct fake_pending *pending;
	struct fake_process old_parent = { 0 };
	struct fake_process pid1 = { 0 };
	struct fake_process child_a = { 0 };
	struct fake_process child_b = { 0 };
	struct fake_thread report_thread_a = { 0 };
	struct fake_thread report_thread_b = { 0 };
	struct fake_vm_state src_vm = { 0, (void *)0x700000, (void *)0x710000 };
	struct fake_vm_state dst_vm = { 0 };
	struct fake_thread_state src_thread = {
		0, { (void *)0x720000, 0x33, 0x4400 }
	};
	struct fake_thread_state dst_thread = { 0 };
	size_t runq_len = 0;
	struct fake_mckfd fd_a = { 0, 3 };
	struct fake_mckfd fd_b = { 0, 4 };
	struct fake_mckfd *fd_head = &fd_a;
	struct fake_mckfd *fd;
	int pids[] = { 10, 20, 30, 20 };
	unsigned long flags[] = {
		0,
		VR_PROT_READ,
		VR_PROT_WRITE,
		VR_PROT_READ | VR_PROT_WRITE,
		VR_PROT_READ | VR_PROT_EXEC,
		VR_IO_NOCACHE | VR_PROT_READ,
		VR_REMOTE | VR_PROT_WRITE,
		VR_WRITE_COMBINED | VR_PROT_READ | VR_PROT_EXEC,
	};

	reset_fake_memset_smp();
	require(process_memset_smp_handler_body_result(0, 8, 0x1000, 3,
			0x5a, fake_memset_smp_phys_to_virt,
			fake_memset_smp_memset, fake_memset_smp_log) == 0);
	require(fake_memset_smp_calls == 1);
	require(fake_memset_smp_last_start == 0x1000);
	require(fake_memset_smp_last_len == 3);
	require(fake_memset_smp_last_value == 0x5a);
	require(fake_memset_smp_memory[0] == 0x5a);
	require(fake_memset_smp_memory[2] == 0x5a);
	require(fake_memset_smp_log_calls == 0);
	reset_fake_memset_smp();
	require(process_memset_smp_handler_body_result(1, 8, 0x1000, 3,
			0x5b, fake_memset_smp_phys_to_virt,
			fake_memset_smp_memset, fake_memset_smp_log) == 0);
	require(fake_memset_smp_calls == 0);
	require(process_memset_smp_handler_body_result(3, 4, 0x1000, 10,
			0x6c, fake_memset_smp_phys_to_virt,
			fake_memset_smp_memset, fake_memset_smp_log) == 0);
	require(fake_memset_smp_calls == 1);
	require(fake_memset_smp_last_start == 0x1006);
	require(fake_memset_smp_last_len == 4);
	require(fake_memset_smp_memory[6] == 0x6c);
	require(fake_memset_smp_memory[9] == 0x6c);
	require(fake_memset_smp_log_calls == 1);
	mix(&digest, fake_memset_smp_log_digest);
	require(process_memset_smp_handler_body_result(0, 0, 0x1000, 10,
			0x6c, fake_memset_smp_phys_to_virt,
			fake_memset_smp_memset, fake_memset_smp_log) == -EINVAL);
	{
		struct fake_memset_smp_req req = { 0 };
		int fake_cpu_set;
		int fake_handler;

		reset_fake_memset_smp();
		fake_memset_smp_return = 17;
		require(process_memset_smp_body_result(&fake_cpu_set,
				fake_memset_smp_memory + 5, 0x7d, 31,
				&req.phys, &req.len, &req.value, &fake_handler,
				&req, fake_memset_smp_virt_to_phys,
				fake_memset_smp_call) == 17);
		require(req.phys == 0x1005);
		require(req.len == 31);
		require(req.value == 0x7d);
		require(fake_memset_smp_last_cpu_set == &fake_cpu_set);
		require(fake_memset_smp_last_handler == &fake_handler);
		require(fake_memset_smp_last_request == &req);
		mix(&digest, req.phys + req.len + (unsigned int)req.value);
		require(process_memset_smp_body_result(&fake_cpu_set,
				fake_memset_smp_memory, 0, 1, NULL, &req.len,
				&req.value, &fake_handler, &req,
				fake_memset_smp_virt_to_phys,
				fake_memset_smp_call) == -EINVAL);
	}

	{
		const unsigned long prot_inputs[] = {
			0, 1, 2, 3, 4, 5, 7, 0x12345678UL
		};
		const int status_inputs[] = {
			0, 0x7f, 0x8f, 0x0100, 0xff00, 0x008b, -1
		};
		const int hash_inputs[] = {
			0, 1, 72, 73, 74, -1, -73, -74, 12345
		};

		for (unsigned int i = 0;
		     i < sizeof(prot_inputs) / sizeof(prot_inputs[0]); i++) {
			const unsigned long prot = prot_inputs[i];
			const unsigned long vrflag = prot << 16;

			require(PROT_TO_VR_FLAG(prot) ==
				((prot << 16) & VR_PROT_MASK));
			require(VRFLAG_PROT_TO_MAXPROT(vrflag) ==
				((vrflag & VR_PROT_MASK) << 4));
			require(VRFLAG_MAXPROT_TO_PROT(vrflag << 4) ==
				(((vrflag << 4) & VR_MAXPROT_MASK) >> 4));
			mix(&digest, PROT_TO_VR_FLAG(prot));
			mix(&digest, VRFLAG_PROT_TO_MAXPROT(vrflag));
			mix(&digest, VRFLAG_MAXPROT_TO_PROT(vrflag << 4));
		}

		for (unsigned int i = 0;
		     i < sizeof(status_inputs) / sizeof(status_inputs[0]); i++) {
			const int status = status_inputs[i];

			require(__WEXITSTATUS(status) == ((status & 0xff00) >> 8));
			require(__WTERMSIG(status) == (status & 0x7f));
			require(__WSTOPSIG(status) == ((status & 0xff00) >> 8));
			require(__WIFEXITED(status) == ((status & 0x7f) == 0));
			require(__WIFSIGNALED(status) ==
				((signed char)(((status) & 0x7f) + 1) >> 1) > 0);
			require(__WIFSTOPPED(status) == ((status & 0xff) == 0x7f));
			mix(&digest, (unsigned long)(long)__WEXITSTATUS(status));
			mix(&digest, (unsigned long)(long)__WTERMSIG(status));
			mix(&digest, (unsigned long)(long)__WSTOPSIG(status));
			mix(&digest, (unsigned long)(long)__WIFEXITED(status));
			mix(&digest, (unsigned long)(long)__WIFSIGNALED(status));
			mix(&digest, (unsigned long)(long)__WIFSTOPPED(status));
		}

		for (unsigned int i = 0;
		     i < sizeof(hash_inputs) / sizeof(hash_inputs[0]); i++) {
			const int value = hash_inputs[i];

			require(process_hash(value) == value % HASH_SIZE);
			require(thread_hash(value) == value % HASH_SIZE);
			mix(&digest, (unsigned long)(long)process_hash(value));
			mix(&digest, (unsigned long)(long)thread_hash(value));
		}
	}

	for (unsigned int i = 0; i < sizeof(flags) / sizeof(flags[0]); i++)
		mix(&digest, common_vrflag_to_ptattr(flags[i], 0, 0));

	{
		struct program_load_desc pn = {
			.stack_prot = 0x7,
			.at_phdr = 0x55550000UL,
			.at_phent = 56,
			.at_phnum = 9,
			.at_entry = 0x4444333322221111UL,
			.at_clktck = 100,
			.stack_premap = 0x1000,
		};
		char *argv[] = {
			(char *)0x600000001000UL,
			(char *)0x600000002000UL,
		};
		char *env[] = {
			(char *)0x600000003000UL,
		};
		unsigned long end = 0x0000800000000000UL;
		unsigned long minsz = USER_STACK_PREPAGE_SIZE;
		unsigned long size = 8 * 1024 * 1024UL;
		unsigned long expected_start = end - minsz;
		unsigned long *saved_auxv;
		unsigned long *initial_stack;
		int rc;

		reset_process_stack_trace();
		rc = fake_process_stack_call(&pn, 2, argv, 1, env, 0);
		require(rc == 0);
		require(process_stack_alloc_count == 1);
		require(process_stack_alloc_npages == (int)(minsz >> PAGE_SHIFT));
		require(process_stack_alloc_p2align == USER_STACK_PAGE_P2ALIGN);
		require(process_stack_alloc_flags == (IHK_MC_AP_NOWAIT | IHK_MC_AP_USER));
		require(process_stack_alloc_addr == expected_start);
		require(process_stack_add_count == 1);
		require(process_stack_add_start == expected_start);
		require(process_stack_add_end == end);
		require(process_stack_add_phys == NOPHYS);
		require(process_stack_add_flag & VR_STACK);
		require(process_stack_add_flag & VR_DEMAND_PAGING);
		require(process_stack_add_flag & VR_PRIVATE);
		require(process_stack_add_flag & VR_AP_USER);
		require(process_stack_add_pgshift == USER_STACK_PAGE_SHIFT);
		require(process_stack_pt_count == 1);
		require(process_stack_pt_page_table == process_stack_aspace.page_table);
		require(process_stack_pt_vm == &process_stack_vm);
		require(process_stack_pt_start == expected_start);
		require(process_stack_pt_end == end);
		require(process_stack_pt_phys ==
			(unsigned long)(uintptr_t)process_stack_pages + 0x100000000UL);
		require(process_stack_pt_attr ==
			(process_stack_add_flag ^ PF_POPULATE ^ 0x5555UL));
		require(process_stack_pt_pgshift == USER_STACK_PAGE_SHIFT);
		require(process_stack_pt_range == &process_stack_range);
		require(process_stack_hwcap_count == 1);
		require(process_stack_modify_count == 1);
		require(process_stack_modify_uctx == (void *)0x77770000UL);
		require(process_stack_modify_reg == IHK_UCR_STACK_POINTER);
		require(process_stack_vm.region.stack_end == end);
		require(process_stack_vm.region.stack_start == end - size);
		saved_auxv = (unsigned long *)(process_stack_process +
			PROCESS_STACK_PROCESS_SAVED_AUXV_OFF);
		require(saved_auxv[0] == AT_SYSINFO_EHDR);
		require(saved_auxv[1] == (unsigned long)process_stack_vm.vdso_addr);
		require(saved_auxv[2] == AT_RANDOM);
		require(saved_auxv[4] == AT_CLKTCK);
		require(saved_auxv[5] == pn.at_clktck);
		require(saved_auxv[6] == AT_PAGESZ);
		require(saved_auxv[7] == PAGE_SIZE);
		require(saved_auxv[8] == AT_PHDR);
		require(saved_auxv[9] == pn.at_phdr);
		require(saved_auxv[30] == 16);
		require(saved_auxv[31] == 0xabcddcbaUL);
		initial_stack = (unsigned long *)(process_stack_pages +
			(process_stack_modify_value - expected_start));
		require(initial_stack[0] == 2);
		require(initial_stack[1] == (unsigned long)argv[0]);
		require(initial_stack[2] == (unsigned long)argv[1]);
		require(initial_stack[3] == 0);
		require(initial_stack[4] == (unsigned long)env[0]);
		require(initial_stack[5] == 0);
		require(initial_stack[6] == AT_SYSINFO_EHDR);
		require(initial_stack[7] == (unsigned long)process_stack_vm.vdso_addr);
		require((process_stack_modify_value & 0x3fUL) == 0);
		require(process_stack_log_count[PROCESS_INIT_STACK_LOG_SIZE] == 1);
		require(process_stack_log_count[PROCESS_INIT_STACK_LOG_INITIAL] == 1);
		require(process_stack_log_last_event == PROCESS_INIT_STACK_LOG_INITIAL);
		mix(&digest, process_stack_modify_value);
		mix(&digest, saved_auxv[31]);
		mix(&digest, initial_stack[0] ^ initial_stack[4]);
	}

	{
		struct program_load_desc pn = {
			.stack_prot = 0x3,
			.stack_premap = 0x1000,
		};
		char *argv[] = { (char *)0x610000001000UL };
		char *env[] = { (char *)0x610000002000UL };
		int rc;

		reset_process_stack_trace();
		process_stack_vm.vdso_addr = NULL;
		rc = fake_process_stack_call(&pn, 1, argv, 1, env, 0);
		require(rc == 0);
		require(((unsigned long *)(process_stack_process +
			PROCESS_STACK_PROCESS_SAVED_AUXV_OFF))[0] == AT_IGNORE);
		mix(&digest, ((unsigned long *)(process_stack_process +
			PROCESS_STACK_PROCESS_SAVED_AUXV_OFF))[0]);

		reset_process_stack_trace();
		process_stack_alloc_fail = 1;
		rc = fake_process_stack_call(&pn, 1, argv, 1, env, 0);
		require(rc == -12);
		require(process_stack_alloc_count == 1);
		require(process_stack_add_count == 0);
		require(process_stack_log_count[
			PROCESS_INIT_STACK_LOG_ALLOC_FAILED] == 1);
		mix(&digest, process_stack_alloc_count);

		reset_process_stack_trace();
		process_stack_add_rc = -44;
		rc = fake_process_stack_call(&pn, 1, argv, 1, env, 0);
		require(rc == -44);
		require(process_stack_free_count == 1);
		require(process_stack_log_count[
			PROCESS_INIT_STACK_LOG_ADD_FAILED] == 1);
		mix(&digest, process_stack_free_count);

		reset_process_stack_trace();
		process_stack_add_null_range = 1;
		rc = fake_process_stack_call(&pn, 1, argv, 1, env, 0);
		require(rc == -22);
		require(process_stack_free_count == 1);
		mix(&digest, process_stack_add_count);

		reset_process_stack_trace();
		process_stack_pt_rc = -55;
		rc = fake_process_stack_call(&pn, 1, argv, 1, env, 0);
		require(rc == -55);
		require(process_stack_pt_count == 1);
		require(process_stack_free_count == 1);
		require(process_stack_log_count[
			PROCESS_INIT_STACK_LOG_PT_FAILED] == 1);
		mix(&digest, process_stack_pt_count);

		reset_process_stack_trace();
		rc = fake_process_stack_call(&pn, 1, argv, 1, env,
			8 * 1024 * 1024UL);
		require(rc == 0);
		require(process_stack_alloc_npages == 2048);
		require(process_stack_add_start ==
			0x0000800000000000UL - USER_STACK_PREPAGE_SIZE);
		require(process_stack_pt_start ==
			0x0000800000000000UL - 8 * 1024 * 1024UL);
		mix(&digest, process_stack_alloc_npages);
		mix(&digest, process_stack_pt_start);

		reset_process_stack_trace();
		rc = process_init_stack_body_result(process_stack_thread, &pn,
			0, 1, argv, 1, env, PAGE_SIZE, PAGE_SHIFT,
			USER_STACK_PAGE_MASK, USER_STACK_PAGE_SHIFT,
			USER_STACK_PREPAGE_SIZE, 0, USER_STACK_PAGE_P2ALIGN,
			IHK_MC_AP_NOWAIT, IHK_MC_AP_USER, MPOL_NO_STACK,
			IHK_UCR_STACK_POINTER, PF_POPULATE, NULL,
			fake_process_stack_free_pages,
			fake_process_stack_add_range,
			fake_process_stack_virt_to_phys,
			fake_process_stack_attr,
			fake_process_stack_pt_set_range,
			fake_process_stack_hwcap,
			fake_process_stack_modify_context,
			fake_process_stack_log);
		require(rc == -22);
		mix(&digest, 0x737461636b626164UL);
	}

	mix(&digest, process_split_pgshift_result(21, 0x200000));
	mix(&digest, process_split_pgshift_result(21, 0x201000));
	mix(&digest, process_split_pgshift_result(0, 0x1234));
	mix(&digest, process_add_range_bounds_result(0x1000, 0x9000, 0x1000, 0x9000));
	mix(&digest, process_add_range_bounds_result(0x1000, 0x9000, 0, 0x8000));
	mix(&digest, process_add_range_bounds_result(0x1000, 0x9000, 0x2000, 0xa000));
	{
		unsigned long memobj_marker;
		struct fake_vm_range add_range = {
			.vm_rb_node = {
				.__rb_parent_color = 0x11111111UL,
				.rb_right = (struct fake_rb_node *)0x22222222UL,
				.rb_left = (struct fake_rb_node *)0x33333333UL,
			},
			.start = 0x44,
			.end = 0x55,
			.flag = 0x66,
			.straight_start = 0x77,
			.memobj = (void *)0x88,
			.objoff = 0x99,
			.pgshift = 1,
			.private_data = (void *)0xaa,
		};

		require(process_add_range_init_result(&add_range, 0x2000,
			0x6000, VR_PROT_READ | VR_PRIVATE, &memobj_marker,
			0x1234, 21, (void *)0xfeedUL) == 1);
		require(add_range.vm_rb_node.__rb_parent_color ==
			(unsigned long)&add_range.vm_rb_node);
		require(add_range.vm_rb_node.rb_right ==
			(struct fake_rb_node *)0x22222222UL);
		require(add_range.vm_rb_node.rb_left ==
			(struct fake_rb_node *)0x33333333UL);
		require(add_range.start == 0x2000);
		require(add_range.end == 0x6000);
		require(add_range.flag == (VR_PROT_READ | VR_PRIVATE));
		require(add_range.straight_start == 0);
		require(add_range.memobj == &memobj_marker);
		require(add_range.objoff == 0x1234);
		require(add_range.pgshift == 21);
		require(add_range.private_data == (void *)0xfeedUL);
		require(process_add_range_init_result(NULL, 0x2000, 0x6000,
			VR_PROT_READ, NULL, 0, 0, NULL) == 0);
		mix(&digest, add_range.start ^ add_range.end);
		mix(&digest, add_range.flag);
		mix(&digest, add_range.vm_rb_node.__rb_parent_color -
			(unsigned long)&add_range);
		mix(&digest, add_range.objoff);
		mix(&digest, add_range.pgshift);
	}
	{
		unsigned long memobj_marker;
		struct fake_memobj_ops copy_ops = {
			.free = fake_range_memobj_direct_free,
		};
		struct fake_memobj copy_memobj = {
			.ops = &copy_ops,
			.refcnt = 6,
		};
		struct fake_vm_range src_range = {
			.vm_rb_node = {
				.__rb_parent_color = 0x1000UL,
				.rb_right = (struct fake_rb_node *)0x2000UL,
				.rb_left = (struct fake_rb_node *)0x3000UL,
			},
			.start = 0x11000,
			.end = 0x19000,
			.flag = VR_PROT_READ | VR_PRIVATE | VR_DEMAND_PAGING,
			.straight_start = 0x900000,
			.memobj = &memobj_marker,
			.objoff = 0x4444,
			.pgshift = 21,
			.private_data = (void *)0xabcdefUL,
		};
		struct {
			struct fake_vm_range range;
			unsigned long guard;
		} dst_range = {
			.range = {
				.vm_rb_node = {
					.__rb_parent_color = 0xaaaaUL,
					.rb_right = (struct fake_rb_node *)0xbbbbUL,
					.rb_left = (struct fake_rb_node *)0xccccUL,
				},
			},
			.guard = 0x123456789abcdef0UL,
		};
		struct fake_copy_user_args pte_args = { 0 };
		void *fake_vm = (void *)0x11112222UL;
		int rc;

		reset_range_body_trace();
		mix(&digest, process_copy_user_range_metadata_body_result(
			&dst_range.range, &src_range, fake_range_memobj_ref));
		require(dst_range.range.vm_rb_node.__rb_parent_color ==
			(unsigned long)&dst_range.range.vm_rb_node);
		require(dst_range.range.vm_rb_node.rb_right ==
			(struct fake_rb_node *)0xbbbbUL);
		require(dst_range.range.vm_rb_node.rb_left ==
			(struct fake_rb_node *)0xccccUL);
		require(dst_range.range.start == src_range.start);
		require(dst_range.range.end == src_range.end);
		require(dst_range.range.flag == src_range.flag);
		require(dst_range.range.straight_start ==
			src_range.straight_start);
		require(dst_range.range.memobj == src_range.memobj);
		require(dst_range.range.objoff == src_range.objoff);
		require(dst_range.range.pgshift == src_range.pgshift);
		require(dst_range.range.private_data == src_range.private_data);
		require(dst_range.guard == 0x123456789abcdef0UL);
		require(range_memobj_ref_count == 1);
		mix(&digest, dst_range.range.start ^ dst_range.range.end);
		mix(&digest, dst_range.range.straight_start);
		mix(&digest, range_memobj_ref_count);

		src_range.memobj = NULL;
		dst_range.range.memobj = &memobj_marker;
		reset_range_body_trace();
		mix(&digest, process_copy_user_range_metadata_body_result(
			&dst_range.range, &src_range, NULL));
		require(dst_range.range.memobj == NULL);
		require(range_memobj_ref_count == 0);
		mix(&digest, process_copy_user_range_metadata_body_result(
			NULL, &src_range, fake_range_memobj_ref));
		src_range.memobj = &copy_memobj;
		copy_memobj.refcnt = 6;
		rc = process_copy_user_range_metadata_body_result(
			&dst_range.range, &src_range, NULL);
		require(rc == 0);
		require(copy_memobj.refcnt == 7);
		mix(&digest, (unsigned long)copy_memobj.refcnt);

		reset_range_body_trace();
		copy_memobj.refcnt = 1;
		require(process_memobj_ref_direct_result(&copy_memobj) == 2);
		require(copy_memobj.refcnt == 2);
		require(process_range_memobj_ref_or_direct_result(
			&copy_memobj, NULL) == 0);
		require(copy_memobj.refcnt == 3);
		require(process_range_memobj_unref_or_direct_result(
			&copy_memobj, NULL) == 0);
		require(copy_memobj.refcnt == 2);
		require(process_memobj_unref_direct_result(&copy_memobj) == 1);
		require(range_memobj_direct_free_count == 0);
		require(process_memobj_unref_direct_result(&copy_memobj) == 0);
		require(range_memobj_direct_free_count == 1);
		mix(&digest, (unsigned long)copy_memobj.refcnt);
		mix(&digest, (unsigned long)range_memobj_direct_free_count);

		mix(&digest, process_copy_user_pte_args_init_body_result(
			&pte_args,
			offsetof(struct fake_copy_user_args, new_vm),
			offsetof(struct fake_copy_user_args, new_vrflag),
			offsetof(struct fake_copy_user_args, range),
			offsetof(struct fake_copy_user_args, fault_addr),
			fake_vm, dst_range.range.flag, &dst_range.range, -1));
		require(pte_args.new_vm == fake_vm);
		require(pte_args.new_vrflag == dst_range.range.flag);
		require(pte_args.range == &dst_range.range);
		require(pte_args.fault_addr == -1);
		mix(&digest, pte_args.new_vrflag);
		mix(&digest, (unsigned long)pte_args.fault_addr);
		mix(&digest, process_copy_user_pte_args_init_body_result(
			NULL,
			offsetof(struct fake_copy_user_args, new_vm),
			offsetof(struct fake_copy_user_args, new_vrflag),
			offsetof(struct fake_copy_user_args, range),
			offsetof(struct fake_copy_user_args, fault_addr),
			fake_vm, dst_range.range.flag, &dst_range.range, -1));
		{
			unsigned char src_page[64];
			unsigned char dst_page[64];

			for (size_t i = 0; i < sizeof(src_page); ++i) {
				src_page[i] = (unsigned char)(0x40 + i);
				dst_page[i] = 0xa5;
			}
			mix(&digest, process_copy_user_pte_buffer_body_result(
				dst_page, src_page, sizeof(dst_page), 0));
			require(!memcmp(dst_page, src_page, sizeof(dst_page)));
			mix(&digest, dst_page[31]);

			memset(dst_page, 0x7c, sizeof(dst_page));
			mix(&digest, process_copy_user_pte_buffer_body_result(
				dst_page, src_page, sizeof(dst_page), 1));
			for (size_t i = 0; i < sizeof(dst_page); ++i)
				require(dst_page[i] == 0);
			mix(&digest, dst_page[0]);

			mix(&digest, process_copy_user_pte_buffer_body_result(
				NULL, src_page, sizeof(dst_page), 0));
			mix(&digest, process_copy_user_pte_buffer_body_result(
				dst_page, NULL, sizeof(dst_page), 0));
			mix(&digest, process_copy_user_pte_buffer_body_result(
				dst_page, NULL, sizeof(dst_page), 1));
		}
	}
	{
		struct fake_address_space copy_as = {
			.page_table = (void *)0xc0ffee00UL,
		};
		struct fake_process_vm_full src_vm = {
			.address_space = &copy_as,
		};
		struct fake_process_vm_full dst_vm = {
			.address_space = &copy_as,
		};
		struct fake_vm_range src_a = {
			.start = 0x1000,
			.end = 0x2000,
			.flag = VR_PROT_READ | VR_PRIVATE,
			.pgshift = PAGE_SHIFT,
			.private_data = (void *)0x1111UL,
		};
		struct fake_vm_range src_skip = {
			.start = 0x3000,
			.end = 0x4000,
			.flag = VR_DONTFORK | VR_PROT_READ,
			.pgshift = PAGE_SHIFT,
		};
		struct fake_vm_range src_b = {
			.start = 0x5000,
			.end = 0x7000,
			.flag = VR_PROT_WRITE | VR_DEMAND_PAGING,
			.pgshift = LARGE_PAGE_SHIFT,
			.straight_start = 0x900000,
		};
		struct fake_copy_user_args copy_args = { 0 };
		void *copy_step = (void *)0x51515151UL;
		int rc;

		require(process_vm_range_insert_result(&src_vm.vm_range_tree,
			&src_a, &src_vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&src_vm.vm_range_tree,
			&src_skip, &src_vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&src_vm.vm_range_tree,
			&src_b, &src_vm, NULL, NULL) == 0);

		reset_range_body_trace();
		reset_range_access_trace();
		reset_process_release_trace();
		rc = process_copy_user_ranges_body_result(&dst_vm, &src_vm,
			sizeof(struct fake_vm_range), IHK_MC_AP_NOWAIT,
			&copy_args,
			offsetof(struct fake_copy_user_args, new_vm),
			offsetof(struct fake_copy_user_args, new_vrflag),
			offsetof(struct fake_copy_user_args, range),
			offsetof(struct fake_copy_user_args, fault_addr),
			copy_step, VPTEF_SKIP_NULL, fake_range_lock,
			fake_range_unlock, fake_copy_lookup, fake_copy_next,
			fake_copy_alloc, fake_copy_free, fake_copy_insert,
			fake_copy_visit, fake_memory_range_free, fake_copy_log);
		require(rc == 0);
		require(process_range_lock_count == 1);
		require(process_range_unlock_count == 1);
		require(process_range_lock_addr ==
			(unsigned long)(uintptr_t)&src_vm.memory_range_lock);
		require(process_range_unlock_addr == process_range_lock_addr);
		require(copy_alloc_count == 2);
		require(copy_free_count == 0);
		require(copy_insert_count == 2);
		require(sync_body_visit_count == 2);
		require(sync_body_visit_page_table == copy_as.page_table);
		require(sync_body_visit_start == (src_a.start ^ src_b.start));
		require(sync_body_visit_end == (src_a.end ^ src_b.end));
		require(sync_body_visit_pgshift ==
			(PAGE_SHIFT ^ LARGE_PAGE_SHIFT));
		require(sync_body_visit_flags == VPTEF_SKIP_NULL);
		require(sync_body_visit_step == copy_step);
		require(copy_args.new_vm == &dst_vm);
		require(copy_args.new_vrflag == src_b.flag);
		require(copy_args.range == &copy_alloc_ranges[1]);
		require(copy_args.fault_addr == -1);
		require(copy_alloc_ranges[0].start == src_a.start);
		require(copy_alloc_ranges[0].end == src_a.end);
		require(copy_alloc_ranges[0].flag == src_a.flag);
		require(copy_alloc_ranges[0].private_data ==
			src_a.private_data);
		require(copy_alloc_ranges[1].start == src_b.start);
		require(copy_alloc_ranges[1].end == src_b.end);
		require(copy_alloc_ranges[1].straight_start ==
			src_b.straight_start);
		require(process_lookup_memory_range_body_result(&dst_vm,
			src_skip.start, src_skip.end) == NULL);
		require(process_lookup_memory_range_body_result(&dst_vm,
			src_a.start, src_a.end) == &copy_alloc_ranges[0]);
		require(process_lookup_memory_range_body_result(&dst_vm,
			src_b.start, src_b.end) == &copy_alloc_ranges[1]);
		mix(&digest, (unsigned long)copy_alloc_count);
		mix(&digest, sync_body_visit_start ^ sync_body_visit_end);
		mix(&digest, copy_alloc_ranges[1].straight_start);

		dst_vm = (struct fake_process_vm_full){
			.address_space = &copy_as,
		};
		copy_args = (struct fake_copy_user_args){ 0 };
		reset_range_body_trace();
		reset_range_access_trace();
		reset_process_release_trace();
		copy_visit_rc = -77;
		copy_visit_fail_after = 2;
		copy_visit_fault_addr = 0x6000;
		rc = process_copy_user_ranges_body_result(&dst_vm, &src_vm,
			sizeof(struct fake_vm_range), IHK_MC_AP_NOWAIT,
			&copy_args,
			offsetof(struct fake_copy_user_args, new_vm),
			offsetof(struct fake_copy_user_args, new_vrflag),
			offsetof(struct fake_copy_user_args, range),
			offsetof(struct fake_copy_user_args, fault_addr),
			copy_step, VPTEF_SKIP_NULL, fake_range_lock,
			fake_range_unlock, fake_copy_lookup, fake_copy_next,
			fake_copy_alloc, fake_copy_free, fake_copy_insert,
			fake_copy_visit, fake_memory_range_free, fake_copy_log);
		require(rc == -1);
		require(process_range_lock_count == 1);
		require(process_range_unlock_count == 1);
		require(copy_alloc_count == 2);
		require(copy_insert_count == 2);
		require(sync_body_visit_count == 2);
		require(copy_log_count == 1);
		require(copy_log_fault_addr == 0x6000);
		require(process_memory_free_count == 2);
		require(process_memory_free_start_xor ==
			(src_a.start ^ src_b.start));
		mix(&digest, (unsigned long)process_memory_free_count);
		mix(&digest, (unsigned long)copy_log_fault_addr);

		reset_range_body_trace();
		reset_range_access_trace();
		rc = process_copy_user_ranges_body_result(NULL, &src_vm,
			sizeof(struct fake_vm_range), IHK_MC_AP_NOWAIT,
			&copy_args,
			offsetof(struct fake_copy_user_args, new_vm),
			offsetof(struct fake_copy_user_args, new_vrflag),
			offsetof(struct fake_copy_user_args, range),
			offsetof(struct fake_copy_user_args, fault_addr),
			copy_step, VPTEF_SKIP_NULL, fake_range_lock,
			fake_range_unlock, fake_copy_lookup, fake_copy_next,
			fake_copy_alloc, fake_copy_free, fake_copy_insert,
			fake_copy_visit, fake_memory_range_free, fake_copy_log);
		require(rc == -EINVAL);
		require(process_range_lock_count == 0);
		mix(&digest, (unsigned long)(unsigned int)-rc);
	}
	require(check_add_range_mapping(&digest, NOPHYS, VR_PROT_READ,
		VR_PROT_READ, PROCESS_ADD_RANGE_MAP_SKIP, 0, 0) == 0);
	require(check_add_range_mapping(&digest, 0x100000,
		VR_REMOTE | VR_PROT_WRITE, VR_REMOTE | VR_PROT_WRITE,
		PROCESS_ADD_RANGE_MAP_UPDATE, 0, 0) == 0);
	require(check_add_range_mapping(&digest, 0x100000,
		VR_IO_NOCACHE | VR_PROT_READ, VR_IO_NOCACHE | VR_PROT_READ,
		PROCESS_ADD_RANGE_MAP_UPDATE, PTATTR_UNCACHABLE, 1) == 0);
	require(check_add_range_mapping(&digest, 0x100000,
		VR_XPMEM | VR_PROT_READ, VR_XPMEM | VR_PROT_READ,
		PROCESS_ADD_RANGE_MAP_MARK_XPMEM, 0, 0) == 0);
	require(check_add_range_mapping(&digest, 0x100000,
		VR_DEMAND_PAGING | VR_PROT_READ,
		VR_DEMAND_PAGING | VR_PROT_READ,
		PROCESS_ADD_RANGE_MAP_DEMAND, 0, 0) == 0);
	require(check_add_range_mapping(&digest, 0x100000, 0, 0,
		PROCESS_ADD_RANGE_MAP_SKIP, 0, 0) == 0);
	require(check_add_range_mapping(&digest, 0x100000,
		VR_PROT_READ | VR_PROT_WRITE,
		VR_PROT_READ | VR_PROT_WRITE,
		PROCESS_ADD_RANGE_MAP_UPDATE, 0, 1) == 0);
	{
		unsigned long memobj_marker;
		int vm_marker;
		void *published = (void *)0x1234UL;
		int rc;

		reset_add_orchestrate_trace();
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x2000, 0x6000,
			0x100000, VR_PROT_READ | VR_PROT_WRITE,
			&memobj_marker, 0x1234, 21, (void *)0xfeedUL,
			&published, fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == 0);
		require(published == &add_orch_range);
		require(add_orch_alloc_count == 1);
		require(add_orch_alloc_size == sizeof(struct fake_vm_range));
		require(add_orch_insert_count == 1);
		require(add_orch_update_count == 1);
		require(add_orch_update_phys == 0x100000);
		require(add_orch_update_attr == 0);
		require(add_orch_memclear_count == 1);
		require(add_orch_memclear_phys == 0x100000);
		require(add_orch_memclear_bytes == 0x4000);
		require(add_orch_free_count == 0);
		require(add_orch_remove_count == 0);
		require(add_orch_range.memobj == &memobj_marker);
		require(add_orch_range.private_data == (void *)0xfeedUL);
		mix(&digest, add_orch_update_count);
		mix(&digest, add_orch_memclear_bytes);

		reset_add_orchestrate_trace();
		published = (void *)0x1234UL;
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x3000, 0x5000,
			0x200000, VR_XPMEM | VR_PROT_READ, &memobj_marker,
			0, 12, NULL, &published, fake_add_range_alloc,
			fake_add_range_free, fake_add_range_insert,
			fake_add_range_update, fake_add_range_remove,
			fake_add_range_mark_xpmem, fake_add_range_memclear,
			fake_add_range_log);
		require(rc == 0);
		require(published == &add_orch_range);
		require(add_orch_mark_count == 1);
		require(add_orch_update_count == 0);
		require(add_orch_memclear_count == 0);
		mix(&digest, add_orch_mark_count);

		reset_add_orchestrate_trace();
		add_orch_update_rc = -9;
		published = (void *)0x1234UL;
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x4000, 0x8000,
			0x300000, VR_PROT_READ, &memobj_marker, 0, 12,
			NULL, &published, fake_add_range_alloc,
			fake_add_range_free, fake_add_range_insert,
			fake_add_range_update, fake_add_range_remove,
			fake_add_range_mark_xpmem, fake_add_range_memclear,
			fake_add_range_log);
		require(rc == -9);
		require(published == (void *)0x1234UL);
		require(add_orch_remove_count == 1);
		require(add_orch_remove_start == 0x4000);
		require(add_orch_remove_end == 0x8000);
		require(add_orch_free_count == 1);
		require(add_orch_last_log_event ==
			PROCESS_ADD_RANGE_LOG_PREP_FAILED);
		mix(&digest, add_orch_free_count);
		mix(&digest, add_orch_last_log_event);

		reset_add_orchestrate_trace();
		add_orch_alloc_fail = 1;
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x1000, 0x2000,
			0x300000, VR_PROT_READ, &memobj_marker, 0, 12,
			NULL, NULL, fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == -12);
		require(add_orch_insert_count == 0);
		require(add_orch_last_log_event ==
			PROCESS_ADD_RANGE_LOG_ALLOC_FAILED);
		mix(&digest, add_orch_last_log_event);

		reset_add_orchestrate_trace();
		add_orch_insert_rc = -7;
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x1000, 0x2000,
			0x300000, VR_PROT_READ, &memobj_marker, 0, 12,
			NULL, NULL, fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == -7);
		require(add_orch_free_count == 1);
		require(add_orch_update_count == 0);
		require(add_orch_last_log_event ==
			PROCESS_ADD_RANGE_LOG_INSERT_FAILED);
		mix(&digest, add_orch_last_log_event);

		reset_add_orchestrate_trace();
		rc = process_add_range_orchestrate_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x1000, 0x2000,
			0x300000, VR_DEMAND_PAGING | VR_PROT_READ,
			&memobj_marker, 0, 12, NULL, NULL,
			fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == 0);
		require(add_orch_last_log_event ==
			PROCESS_ADD_RANGE_LOG_DEMAND);
		require(add_orch_update_count == 0);
		require(add_orch_memclear_count == 0);
		mix(&digest, add_orch_last_log_event);

		reset_add_orchestrate_trace();
		published = NULL;
		rc = process_add_range_public_body_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x1000, 0x10000,
			0x3000, 0x7000, 0x200000,
			VR_PROT_READ | VR_PROT_WRITE, &memobj_marker, 0x44,
			12, (void *)0xbeefUL, &published,
			fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == 0);
		require(published == &add_orch_range);
		require(add_orch_alloc_count == 1);
		require(add_orch_update_count == 1);
		require(add_orch_log_count == 0);
		mix(&digest, add_orch_update_count);

		reset_add_orchestrate_trace();
		rc = process_add_range_public_body_result(&vm_marker,
			sizeof(struct fake_vm_range), 0x5000, 0x10000,
			0x3000, 0x7000, 0x200000,
			VR_PROT_READ | VR_PROT_WRITE, &memobj_marker, 0x44,
			12, (void *)0xbeefUL, &published,
			fake_add_range_alloc, fake_add_range_free,
			fake_add_range_insert, fake_add_range_update,
			fake_add_range_remove, fake_add_range_mark_xpmem,
			fake_add_range_memclear, fake_add_range_log);
		require(rc == -22);
		require(add_orch_alloc_count == 0);
		require(add_orch_log_count == 1);
		require(add_orch_last_log_event ==
			PROCESS_ADD_RANGE_LOG_BOUNDS_FAILED);
		require(add_orch_last_log_rc == -22);
		mix(&digest, add_orch_last_log_event);
	}
	{
		struct fake_rb_root root = { 0 };
		struct fake_vm_range middle = {
			.start = 0x3000, .end = 0x4000, .flag = 0x31,
		};
		struct fake_vm_range left = {
			.start = 0x1000, .end = 0x2000, .flag = 0x11,
		};
		struct fake_vm_range right = {
			.start = 0x5000, .end = 0x7000, .flag = 0x51,
		};
		struct fake_vm_range overlap = {
			.start = 0x3800, .end = 0x3900, .flag = 0x81,
		};
		int vm_marker;
		int rc;

		reset_range_insert_trace();
		rc = process_vm_range_insert_result(&root, &middle,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		require(root.rb_node == &middle.vm_rb_node);
		require(range_insert_log_count == 1);
		require(range_insert_dump_count == 1);
		require(range_insert_last_event ==
			PROCESS_VM_RANGE_INSERT_LOG_SUCCESS);
		require(range_insert_last_vm == &vm_marker);
		require(range_insert_last_newrange == &middle);
		require(range_insert_last_range == NULL);

		rc = process_vm_range_insert_result(&root, &left,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		rc = process_vm_range_insert_result(&root, &right,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		require(range_insert_log_count == 3);
		require(range_insert_dump_count == 3);
		mix_range_tree(&digest, root.rb_node);

		rc = process_vm_range_insert_result(&root, &overlap,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == -14);
		require(range_insert_log_count == 4);
		require(range_insert_dump_count == 3);
		require(range_insert_last_event ==
			PROCESS_VM_RANGE_INSERT_LOG_OVERLAP);
		require(range_insert_last_newrange == &overlap);
		require(range_insert_last_range == &middle);
		require(overlap.vm_rb_node.rb_left == NULL);
		require(overlap.vm_rb_node.rb_right == NULL);
		mix(&digest, range_insert_last_event);
		mix_range_tree(&digest, root.rb_node);
	}
	{
		struct fake_address_space as = {
			.page_table = (void *)0xabc000UL,
		};
		struct fake_process_vm_full vm = {
			.address_space = &as,
			.region.user_end = 0x9000,
		};
		struct fake_memobj private_file = {
			.flags = 0,
		};
		struct fake_vm_range left = {
			.start = 0x1000, .end = 0x2000,
			.flag = VR_PROT_READ,
		};
		struct fake_vm_range mid = {
			.start = 0x3000, .end = 0x4000,
			.flag = VR_PROT_READ | VR_PROT_WRITE,
		};
		struct fake_vm_range right = {
			.start = 0x5000, .end = 0x7000,
			.flag = VR_PROT_WRITE,
		};
		struct fake_vm_range private_range = {
			.start = 0x7000, .end = 0x8000,
			.flag = VR_PRIVATE | VR_PROT_READ,
			.memobj = &private_file,
		};
		int rc;

		require(offsetof(struct fake_process_vm_full, address_space) == 0);
		require(offsetof(struct fake_process_vm_full, vm_range_tree) == 8);
		require(offsetof(struct fake_process_vm_full, region) == 16);
		require(offsetof(struct fake_process_vm_full, page_table_lock) == 176);
		require(offsetof(struct fake_process_vm_full, range_cache) == 256);
		require(offsetof(struct fake_process_vm_full, range_cache_ind) == 288);
		require(offsetof(struct fake_memobj, flags) == 8);

		require(process_vm_range_insert_result(&vm.vm_range_tree, &mid,
			&vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree, &left,
			&vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree, &right,
			&vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree,
			&private_range, &vm, NULL, NULL) == 0);

		require(process_lookup_memory_range_body_result(&vm, 0x1100,
			0x1800) == &left);
		require(vm.range_cache_ind == 3);
		require(vm.range_cache[3] == &left);
		vm.range_cache[1] = &mid;
		vm.range_cache_ind = 1;
		require(process_lookup_memory_range_body_result(&vm, 0x3100,
			0x3200) == &mid);
		require(vm.range_cache_ind == 1);
		require(process_lookup_memory_range_body_result(&vm, 0x2500,
			0x3600) == &mid);
		require(process_lookup_memory_range_body_result(&vm, 0x9000,
			0x9000) == NULL);
		require(process_next_memory_range_body_result(&left) == &mid);
		require(process_previous_memory_range_body_result(&right) == &mid);
		require(process_next_memory_range_body_result(&private_range) == NULL);
		require(process_previous_memory_range_body_result(&left) == NULL);

		rc = process_extend_up_body_result(&vm, &left, 0x2800);
		require(rc == 0 && left.end == 0x2800);
		require(process_extend_up_body_result(&vm, &left, 0x3200) == -12);
		require(process_extend_up_body_result(&vm, &left, 0x9500) == -1);
		require(process_extend_up_body_result(&vm, &left, 0x2700) == -22);

		reset_range_public_trace();
		require(process_lookup_memory_range_public_result(&vm, 0x1100,
			0x1800, fake_range_public_log) == &left);
		require(range_public_log_count == 2);
		require(range_public_last_event ==
			PROCESS_RANGE_PUBLIC_LOG_LOOKUP_EXIT);
		require(range_public_last_range == &left);
		require(range_public_last_start == 0x1100);
		require(range_public_last_end == 0x1800);
		mix(&digest, range_public_last_event);

		reset_range_public_trace();
		require(process_next_memory_range_public_result(&vm, &left,
			fake_range_public_log) == &mid);
		require(range_public_log_count == 2);
		require(range_public_last_event ==
			PROCESS_RANGE_PUBLIC_LOG_NEXT_EXIT);
		require(range_public_last_range == &mid);
		require(range_public_last_start == left.start);
		require(range_public_last_end == left.end);
		mix(&digest, range_public_last_event);

		reset_range_public_trace();
		require(process_previous_memory_range_public_result(&vm, &right,
			fake_range_public_log) == &mid);
		require(range_public_log_count == 2);
		require(range_public_last_event ==
			PROCESS_RANGE_PUBLIC_LOG_PREVIOUS_EXIT);
		require(range_public_last_range == &mid);
		require(range_public_last_start == right.start);
		require(range_public_last_end == right.end);
		mix(&digest, range_public_last_event);

		reset_range_public_trace();
		rc = process_extend_up_public_result(&vm, &mid, 0x4800,
			fake_range_public_log);
		require(rc == 0);
		require(mid.end == 0x4800);
		require(range_public_log_count == 2);
		require(range_public_last_event ==
			PROCESS_RANGE_PUBLIC_LOG_EXTEND_EXIT);
		require(range_public_last_range == &mid);
		require(range_public_last_error == 0);
		require(range_public_last_start == mid.start);
		require(range_public_last_end == 0x4800);
		mix(&digest, range_public_last_event);

		reset_range_access_trace();
		rc = process_change_prot_body_result(&vm, &mid,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr);
		require(rc == 0);
		require(process_change_attr_count == 0);

		reset_range_access_trace();
		rc = process_change_prot_body_result(&vm, &private_range,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr);
		require(rc == 0);
		require(private_range.flag ==
			(VR_PRIVATE | VR_PROT_READ | VR_PROT_WRITE));
		require(process_change_attr_count == 0);

		reset_range_access_trace();
		right.flag = VR_PROT_READ;
		rc = process_change_prot_body_result(&vm, &right,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr);
		require(rc == 0);
		require(process_range_lock_count == 1);
		require(process_range_unlock_count == 1);
		require(process_range_lock_addr ==
			(unsigned long)&vm.page_table_lock);
		require(process_range_unlock_addr ==
			(unsigned long)&vm.page_table_lock);
		require(process_change_attr_count == 1);
		require(process_change_attr_pt == as.page_table);
		require(process_change_attr_start == 0x5000);
		require(process_change_attr_end == 0x7000);
		require(process_change_attr_set & PTATTR_WRITABLE);
		require(right.flag == (VR_PROT_READ | VR_PROT_WRITE));
		mix(&digest, process_change_attr_clr);
		mix(&digest, process_change_attr_set);

		reset_range_access_trace();
		process_change_attr_rc = -2;
		right.flag = VR_PROT_READ;
		rc = process_change_prot_body_result(&vm, &right,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr);
		require(rc == 0);
		require(right.flag == (VR_PROT_READ | VR_PROT_WRITE));

		reset_range_access_trace();
		process_change_attr_rc = -5;
		right.flag = VR_PROT_READ;
		rc = process_change_prot_body_result(&vm, &right,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr);
		require(rc == -5);
		require(right.flag == VR_PROT_READ);

		reset_range_access_trace();
		right.flag = VR_PROT_READ;
		rc = process_change_prot_public_result(&vm, &right,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr,
			fake_change_public_log);
		require(rc == 0);
		require(right.flag == (VR_PROT_READ | VR_PROT_WRITE));
		require(change_public_log_count == 2);
		require(change_public_error_count == 0);
		require(change_public_last_event ==
			PROCESS_CHANGE_PROT_PUBLIC_LOG_EXIT);
		require(change_public_last_error == 0);
		require(change_public_last_protflag ==
			(VR_PROT_READ | VR_PROT_WRITE));
		require(change_public_last_vm == &vm);
		require(change_public_last_range == &right);
		mix(&digest, change_public_last_event);

		reset_range_access_trace();
		process_change_attr_rc = -5;
		right.flag = VR_PROT_READ;
		rc = process_change_prot_public_result(&vm, &right,
			VR_PROT_READ | VR_PROT_WRITE, fake_range_attr,
			fake_range_lock, fake_range_unlock, fake_change_attr,
			fake_change_public_log);
		require(rc == -5);
		require(right.flag == VR_PROT_READ);
		require(change_public_log_count == 3);
		require(change_public_error_count == 1);
		require(change_public_last_event ==
			PROCESS_CHANGE_PROT_PUBLIC_LOG_EXIT);
		require(change_public_last_error == -5);
		require(change_public_last_vm == &vm);
		require(change_public_last_range == &right);
		mix(&digest, (unsigned int)-change_public_last_error);

		reset_range_access_trace();
		reset_process_release_trace();
		right.flag = VR_PROT_READ | VR_PROT_WRITE;
		right.pgshift = PAGE_SHIFT;
		rc = process_update_page_table_public_result(&vm, &right,
			0x56789000UL, 0xdeadbeefUL, fake_range_attr,
			fake_spin_lock, fake_spin_unlock,
			fake_update_pt_set_range, fake_update_pt_log);
		require(rc == 0);
		require(process_update_pt_count == 1);
		require(process_update_pt_phys == 0x56789000UL);
		require(process_update_pt_attr ==
			common_vrflag_to_ptattr(right.flag, PF_POPULATE, NULL));
		require(process_update_pt_log_count == 0);
		mix(&digest, process_update_pt_attr);
		mix(&digest, process_update_pt_phys);

		reset_range_access_trace();
		reset_process_release_trace();
		right.flag = VR_PROT_READ | VR_PROT_WRITE;
		right.pgshift = PAGE_SHIFT;
		rc = process_update_page_table_body_result(&vm, &right,
			0x34567000UL, PF_POPULATE, fake_range_attr,
			fake_spin_lock, fake_spin_unlock,
			fake_update_pt_set_range, fake_update_pt_log);
		require(rc == 0);
		require(process_spin_lock_count == 1);
		require(process_spin_unlock_count == 1);
		require(process_spin_lock_addr ==
			(unsigned long)&vm.page_table_lock);
		require(process_spin_unlock_addr ==
			(unsigned long)&vm.page_table_lock);
		require(process_spin_unlock_irq == 0x12345678UL);
		require(process_update_pt_count == 1);
		require(process_update_pt_page_table == as.page_table);
		require(process_update_pt_vm == &vm);
		require(process_update_pt_start == right.start);
		require(process_update_pt_end == right.end);
		require(process_update_pt_phys == 0x34567000UL);
		require(process_update_pt_attr ==
			common_vrflag_to_ptattr(right.flag, PF_POPULATE, NULL));
		require(process_update_pt_pgshift == PAGE_SHIFT);
		require(process_update_pt_range == &right);
		require(process_update_pt_flags == 0);
		require(process_update_pt_log_count == 0);
		mix(&digest, process_update_pt_attr);
		mix(&digest, process_update_pt_phys);

		reset_range_access_trace();
		reset_process_release_trace();
		process_update_pt_rc = -33;
		rc = process_update_page_table_body_result(&vm, &right,
			0x45678000UL, PF_POPULATE, fake_range_attr,
			fake_spin_lock, fake_spin_unlock,
			fake_update_pt_set_range, fake_update_pt_log);
		require(rc == -33);
		require(process_spin_lock_count == 1);
		require(process_spin_unlock_count == 1);
		require(process_update_pt_count == 1);
		require(process_update_pt_log_count == 1);
		require(process_update_pt_log_error == -33);
		mix(&digest, (unsigned int)-process_update_pt_log_error);

		require(process_update_page_table_body_result(NULL, &right,
			0, PF_POPULATE, fake_range_attr, fake_spin_lock,
			fake_spin_unlock, fake_update_pt_set_range,
			fake_update_pt_log) == -22);
		require(process_update_page_table_body_result(&vm, NULL,
			0, PF_POPULATE, fake_range_attr, fake_spin_lock,
			fake_spin_unlock, fake_update_pt_set_range,
			fake_update_pt_log) == -22);
		right.flag = VR_PROT_READ;

		require(process_access_ok_body_result(&vm, VERIFY_READ,
			0x1100, 0x100) == 0);
		require(process_access_ok_body_result(&vm, VERIFY_WRITE,
			0x1100, 0x100) == -13);
		require(process_access_ok_body_result(&vm, VERIFY_READ,
			0x2800, 0x900) == -14);
		require(process_access_ok_body_result(&vm, VERIFY_WRITE,
			0x5100, 0x100) == -13);
		reset_range_access_trace();
		require(process_access_ok_public_result(&vm, VERIFY_READ,
			0x1100, 0x100, fake_access_public_log) == 0);
		require(access_public_log_count == 0);
		require(process_access_ok_public_result(&vm, VERIFY_WRITE,
			0x1100, 0x100, fake_access_public_log) == -13);
		require(access_public_log_count == 1);
		require(access_public_last_vm == &vm);
		require(access_public_last_type == VERIFY_WRITE);
		require(access_public_last_addr == 0x1100);
		require(access_public_last_len == 0x100);
		require(access_public_last_error == -13);
		require(process_access_ok_public_result(&vm, VERIFY_READ,
			0x2800, 0x900, fake_access_public_log) == -14);
		require(access_public_log_count == 2);
		require(access_public_last_error == -14);
		mix(&digest, (unsigned int)-access_public_last_error);
		mix(&digest, (unsigned long)vm.range_cache_ind);
		mix_range_tree(&digest, vm.vm_range_tree.rb_node);
	}
	{
		struct fake_retry_thread {
			void *pgio_fp;
			void *pgio_arg;
		};
		struct fake_address_space as = {
			.page_table = (void *)0xabc000UL,
		};
		struct fake_process_vm_full vm = {
			.address_space = &as,
			.region.stack_start = 0x6000,
			.region.stack_end = 0x9000,
			.is_memory_range_lock_taken = -1,
		};
		struct fake_memobj zero_memobj = { 0 };
		struct fake_vm_range data = {
			.start = 0x1000, .end = 0x2000,
			.flag = VR_PROT_READ,
		};
		struct fake_vm_range private_zero = {
			.start = 0x3000, .end = 0x4000,
			.flag = VR_PRIVATE | VR_PROT_READ,
			.memobj = &zero_memobj,
		};
		struct fake_vm_range xpmem = {
			.start = 0x5000, .end = 0x5800,
			.flag = VR_PROT_READ,
			.private_data = (void *)0xfeedUL,
		};
		struct fake_vm_range stack = {
			.start = 0x7000, .end = 0x9000,
			.flag = VR_PROT_READ | VR_PROT_WRITE,
			.pgshift = 12,
		};
		struct fake_retry_thread retry_thread = {
			.pgio_fp = (void *)0xfeed0001UL,
			.pgio_arg = (void *)0xfeed0002UL,
		};
		int rc;

		require(process_vm_range_insert_result(&vm.vm_range_tree, &data,
			&vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree,
			&private_zero, &vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree, &xpmem,
			&vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&vm.vm_range_tree, &stack,
			&vm, NULL, NULL) == 0);

		reset_page_fault_trace();
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x6801,
			PF_WRITE, 3, fake_pf_read_lock,
			fake_pf_read_unlock, fake_pf_write_lock,
			fake_pf_write_unlock, fake_zeroobj_match,
			fake_normal_fault, fake_xpmem_fault);
		require(rc == 0);
		require(stack.start == 0x6000);
		require(process_pf_write_lock_count == 1);
		require(process_pf_write_unlock_count == 1);
		require(process_pf_read_lock_count == 1);
		require(process_pf_read_unlock_count == 1);
		require(process_pf_normal_count == 1);
		require(process_pf_last_range == &stack);
		require(process_pf_last_addr == 0x6801);
		mix(&digest, stack.start);
		mix(&digest, process_pf_last_reason);

		reset_page_fault_trace();
		vm.is_memory_range_lock_taken = 3;
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x1100,
			0, 3, fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault, fake_xpmem_fault);
		require(rc == 0);
		require(process_pf_read_lock_count == 0);
		require(process_pf_normal_count == 1);

		reset_page_fault_trace();
		process_pf_zero_match_result = 1;
		vm.is_memory_range_lock_taken = -1;
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x3100,
			0, 3, fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault, fake_xpmem_fault);
		require(rc == 0);
		require(process_pf_zero_match_count == 1);
		require(process_pf_last_reason == PF_POPULATE);
		mix(&digest, process_pf_last_reason);

		reset_page_fault_trace();
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x5100,
			0, 3, fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault, fake_xpmem_fault);
		require(rc == 0);
		require(process_pf_xpmem_count == 1);
		require(process_pf_last_range == &xpmem);

		reset_page_fault_trace();
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x1100,
			PF_WRITE, 3, fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault, fake_xpmem_fault);
		require(rc == -14);
		require(process_pf_normal_count == 0);

		reset_page_fault_trace();
		vm.exiting = 1;
		rc = process_do_page_fault_vm_body_result(&vm, &vm, 0x1100,
			0, 3, fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault, fake_xpmem_fault);
		require(rc == -125);
		require(process_pf_read_unlock_count == 1);
		vm.exiting = 0;

		reset_page_fault_trace();
		process_pf_retry_restart_count = 1;
		rc = process_page_fault_vm_retry_body_result(&vm, 0x1234,
			PF_USER, &retry_thread,
			offsetof(struct fake_retry_thread, pgio_fp),
			offsetof(struct fake_retry_thread, pgio_arg),
			fake_retry_fault, fake_preempt_enable,
			fake_preempt_disable, fake_pgio_dispatch);
		require(rc == 0);
		require(process_pf_retry_calls == 2);
		require(process_pf_preempt_enable_count == 1);
		require(process_pf_preempt_disable_count == 1);
		require(process_pf_pgio_dispatch_count == 1);
		require(process_pf_pgio_fp == (void *)0xfeed0001UL);
		require(process_pf_pgio_arg == (void *)0xfeed0002UL);
		require(retry_thread.pgio_fp == NULL);
		mix(&digest, process_pf_retry_calls);

		reset_page_fault_trace();
		retry_thread.pgio_fp = (void *)0xbeef0001UL;
		retry_thread.pgio_arg = (void *)0xbeef0002UL;
		process_pf_retry_restart_count = 1;
		rc = process_page_fault_vm_public_result(&vm, &vm, 0x1100,
			0, 3, &retry_thread,
			offsetof(struct fake_retry_thread, pgio_fp),
			offsetof(struct fake_retry_thread, pgio_arg),
			fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault,
			fake_xpmem_fault, fake_preempt_enable,
			fake_preempt_disable, fake_pgio_dispatch);
		require(rc == 0);
		require(process_pf_normal_count == 2);
		require(process_pf_preempt_enable_count == 1);
		require(process_pf_preempt_disable_count == 1);
		require(process_pf_pgio_dispatch_count == 1);
		require(process_pf_pgio_fp == (void *)0xbeef0001UL);
		require(process_pf_pgio_arg == (void *)0xbeef0002UL);
		require(retry_thread.pgio_fp == NULL);
		mix(&digest, process_pf_normal_count);

		reset_page_fault_trace();
		rc = process_populate_memory_body_result(&vm, 0x10000, 8192,
			4096, PF_USER | PF_POPULATE, fake_populate_fault,
			fake_preempt_disable, fake_preempt_enable,
			fake_populate_warn);
		require(rc == 0);
		require(process_populate_pf_count == 2);
		require(process_pf_preempt_disable_count == 1);
		require(process_pf_preempt_enable_count == 1);
		require(process_pf_last_addr == 0x11000);
		mix(&digest, process_populate_pf_count);

		reset_page_fault_trace();
		process_populate_fail_after = 2;
		rc = process_populate_memory_body_result(&vm, 0x20000, 12288,
			4096, PF_USER | PF_POPULATE, fake_populate_fault,
			fake_preempt_disable, fake_preempt_enable,
			fake_populate_warn);
		require(rc == -77);
		require(process_populate_pf_count == 2);
		require(process_populate_warn_count == 1);
		require(process_populate_warn_addr == 0x21000);
		require(process_populate_warn_off == 4096);
		require(process_populate_warn_len == 12288);
		require(process_populate_warn_error == -77);
		mix(&digest, process_populate_warn_off);

		reset_page_fault_trace();
		rc = process_populate_memory_public_result(&vm, &vm, 0x6000,
			8192, 4096, PF_USER | PF_POPULATE, 3,
			&retry_thread,
			offsetof(struct fake_retry_thread, pgio_fp),
			offsetof(struct fake_retry_thread, pgio_arg),
			fake_pf_read_lock, fake_pf_read_unlock,
			fake_pf_write_lock, fake_pf_write_unlock,
			fake_zeroobj_match, fake_normal_fault,
			fake_xpmem_fault, fake_preempt_disable,
			fake_preempt_enable, fake_pgio_dispatch,
			fake_populate_warn);
		require(rc == 0);
		require(process_pf_normal_count == 2);
		require(process_pf_preempt_disable_count == 1);
		require(process_pf_preempt_enable_count == 1);
		require(process_pf_last_addr == 0x7000);
		mix(&digest, process_pf_normal_count);
	}
	mix(&digest, process_extend_up_result(0x4000, 0x9000, 0, 0, 0x5000));
	mix(&digest, process_extend_up_result(0x4000, 0x9000, 0, 0, 0x4000));
	mix(&digest, process_extend_up_result(0x4000, 0x9000, 0, 0, 0xa000));
	mix(&digest, process_extend_up_result(0x4000, 0x9000, 1, 0x4800, 0x5000));
	mix(&digest, process_change_prot_newflag_result(0x12340000UL | VR_PRIVATE,
							VR_PROT_READ | VR_PROT_WRITE));
	process_attr_delta_result(PTATTR_USER | PTATTR_ACTIVE,
				  PTATTR_USER | PTATTR_WRITABLE, &clr, &set);
	mix(&digest, clr);
	mix(&digest, set);
	mix(&digest, process_private_file_setattr_result(1, VR_PRIVATE, 0,
							 PTATTR_WRITABLE | PTATTR_ACTIVE));
	mix(&digest, process_private_file_setattr_result(1, VR_PRIVATE,
							 MF_HUGETLBFS,
							 PTATTR_WRITABLE | PTATTR_ACTIVE));
	mix(&digest, process_remove_region_alignment_result(0x1000, 0x2000));
	mix(&digest, process_remove_region_alignment_result(0x1001, 0x2000));
	mix(&digest, process_access_initial_result(1, 0x1000, 0x1000));
	mix(&digest, process_access_initial_result(0, 0, 0x1000));
	mix(&digest, process_access_initial_result(1, 0x2000, 0x1000));
	mix(&digest, process_access_adjacent_result(0x2000, 1, 0x2000));
	mix(&digest, process_access_adjacent_result(0x2000, 0, 0));
	mix(&digest, process_access_adjacent_result(0x2000, 1, 0x3000));
	mix(&digest, process_access_permission_result(VERIFY_READ, VR_PROT_READ));
	mix(&digest, process_access_permission_result(VERIFY_READ, VR_PROT_WRITE));
	mix(&digest, process_access_permission_result(VERIFY_WRITE, VR_PROT_WRITE));
	mix(&digest, process_access_permission_result(VERIFY_WRITE, VR_PROT_READ));
	mix(&digest, process_access_permission_result(99, 0));
	{
		static const unsigned long ranges[][2] = {
			{ 0x1000, 0x2000 },
			{ 0x2000, 0x3000 },
			{ 0x4000, 0x8000 },
		};
		static const unsigned long lookups[][2] = {
			{ 0x0, 0x1000 },
			{ 0x1000, 0x1800 },
			{ 0x1800, 0x2800 },
			{ 0x3000, 0x3800 },
			{ 0x7000, 0x9000 },
		};

		for (unsigned int r = 0; r < sizeof(ranges) / sizeof(ranges[0]); r++) {
			for (unsigned int l = 0; l < sizeof(lookups) / sizeof(lookups[0]); l++) {
				mix(&digest, process_range_cache_hit_result(
					ranges[r][0], ranges[r][1],
					lookups[l][0], lookups[l][1]));
				mix(&digest, process_lookup_range_relation_result(
					lookups[l][0], lookups[l][1],
					ranges[r][0], ranges[r][1]));
				for (unsigned int f = 0; f < sizeof(flags) / sizeof(flags[0]); f++) {
					int split_start = -1;
					int split_end = -1;
					int ro_freed = -1;
					int remove_xpmem = -1;

					process_remove_range_step_result(
						ranges[r][0], ranges[r][1],
						lookups[l][0], lookups[l][1],
						flags[f], (f & 1) ? 0x1000UL : 0,
						&split_start, &split_end,
						&ro_freed, &remove_xpmem);
					mix(&digest, (unsigned int)split_start);
					mix(&digest, (unsigned int)split_end);
					mix(&digest, (unsigned int)ro_freed);
					mix(&digest, (unsigned int)remove_xpmem);
				}
			}
		}
	}
	{
		struct fake_vm_range cached_a = { .start = 0x1000, .end = 0x2000 };
		struct fake_vm_range cached_b = { .start = 0x2000, .end = 0x3000 };
		struct fake_vm_range cached_c = { .start = 0x3000, .end = 0x4000 };
		void *cache[4] = {
			&cached_a,
			&cached_b,
			&cached_a,
			NULL,
		};
		int cache_ind = 0;
		int rc;

		rc = process_range_cache_replace_result(cache, 4,
							&cached_a,
							&cached_c);
		require(rc == 2);
		require(cache[0] == &cached_c);
		require(cache[1] == &cached_b);
		require(cache[2] == &cached_c);
		require(cache[3] == NULL);
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)(cache[0] == &cached_c));
		mix(&digest, (unsigned long)(cache[2] == &cached_c));

		rc = process_range_cache_replace_result(cache, 4,
							&cached_b, NULL);
		require(rc == 1);
		require(cache[1] == NULL);
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)(cache[1] == NULL));

		rc = process_range_cache_store_result(cache, 4, &cache_ind,
						      &cached_b);
		require(rc == 3);
		require(cache_ind == 3);
		require(cache[3] == &cached_b);
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)(cache[3] == &cached_b));

		rc = process_range_cache_store_result(cache, 4, &cache_ind,
						      &cached_a);
		require(rc == 2);
		require(cache_ind == 2);
		require(cache[2] == &cached_a);
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)(cache[2] == &cached_a));

		require(process_range_cache_replace_result(NULL, 4,
							   &cached_a,
							   &cached_b) == 0);
		require(process_range_cache_replace_result(cache, 0,
							   &cached_a,
							   &cached_b) == 0);
		require(process_range_cache_replace_result(cache, 4, NULL,
							   &cached_b) == 0);
		require(process_range_cache_store_result(NULL, 4, &cache_ind,
							 &cached_b) == -22);
		require(process_range_cache_store_result(cache, 0, &cache_ind,
							 &cached_b) == -22);
		require(process_range_cache_store_result(cache, 4, NULL,
							 &cached_b) == -22);
		require(process_range_cache_store_result(cache, 4, &cache_ind,
							 NULL) == -22);
		mix(&digest, 0x72616e6765636163UL);
	}
	{
		struct fake_vm_range commit_range = {
			.start = 0x1000,
			.end = 0x2000,
			.flag = VR_PROT_READ,
		};

		require(process_range_end_commit_result(&commit_range,
							0x5000) == 1);
		require(commit_range.end == 0x5000);
		require(process_range_flag_commit_result(&commit_range,
							 VR_PROT_READ |
							 VR_PROT_WRITE) == 1);
		require(commit_range.flag == (VR_PROT_READ | VR_PROT_WRITE));
		require(process_range_end_commit_result(NULL, 0x6000) == 0);
		require(process_range_flag_commit_result(NULL, VR_PROT_EXEC) == 0);
		mix(&digest, commit_range.end);
		mix(&digest, commit_range.flag);
		mix(&digest, 0x766d636f6d6d6974UL);

		commit_range.start = 0x800000;
		require(process_range_stack_start_commit_result(
			&commit_range, 0x7fffff, 21) == 1);
		require(commit_range.start == 0x600000);
		mix(&digest, commit_range.start);

		commit_range.start = 0x800000;
		require(process_range_stack_start_commit_result(
			&commit_range, 0x7ff123, 0) == 1);
		require(commit_range.start == 0x7ff000);
		mix(&digest, commit_range.start);

		require(process_range_stack_start_commit_result(NULL,
								0x7000, 12) == 0);
		require(process_range_stack_start_commit_result(
			&commit_range, 0x7000, -1) == 0);
		mix(&digest, commit_range.start);
	}
	{
		unsigned long memobj_marker;
		struct fake_vm_range low = {
			.start = 0x1000,
			.end = 0x9000,
			.flag = VR_PROT_READ | VR_PRIVATE,
			.straight_start = 0x500000,
			.memobj = &memobj_marker,
			.objoff = 0x2000,
			.pgshift = 21,
			.private_data = (void *)0xfeedUL,
		};
		struct fake_vm_range high = { 0 };
		struct fake_vm_range anon_low = {
			.start = 0x4000,
			.end = 0x8000,
			.flag = VR_PROT_READ,
			.pgshift = 0,
			.private_data = (void *)0xbeefUL,
		};
		struct fake_vm_range anon_high = { 0 };
		struct fake_vm_range surviving = {
			.start = 0x1000,
			.end = 0x3000,
			.flag = VR_PROT_READ,
			.memobj = &memobj_marker,
			.objoff = 0x2000,
			.pgshift = 12,
		};
		struct fake_vm_range merging = {
			.start = 0x3000,
			.end = 0x7000,
			.flag = VR_PROT_READ,
			.memobj = &memobj_marker,
			.objoff = 0x4000,
			.pgshift = 12,
		};
		struct fake_vm_range bad = merging;

		mix(&digest, process_split_range_init_result(&low, &high,
							     0x3000));
		require(low.end == 0x9000);
		require(high.start == 0x3000);
		require(high.end == 0x9000);
		require(high.flag == low.flag);
		require(high.straight_start == 0x502000);
		require(high.memobj == &memobj_marker);
		require(high.objoff == 0x4000);
		require(high.pgshift == 21);
		require(high.private_data == (void *)0xfeedUL);
		mix(&digest, high.start ^ high.end ^ high.straight_start);
		mix(&digest, (unsigned long)high.objoff);
		process_split_range_commit_result(&low, 0x3000);
		require(low.end == 0x3000);
		mix(&digest, low.end);

		mix(&digest, process_split_range_init_result(&anon_low,
							     &anon_high,
							     0x6000));
		require(anon_high.memobj == NULL);
		require(anon_high.objoff == 0);
		require(anon_high.straight_start == 0);
		require(anon_high.private_data == (void *)0xbeefUL);
		mix(&digest, anon_high.start ^ anon_high.end);
		mix(&digest, process_split_range_init_result(NULL, &high,
							     0x3000));
		process_split_range_commit_result(NULL, 0x3000);

		mix(&digest, process_join_range_prepare_result(&surviving,
							       &merging));
		require(surviving.end == 0x7000);
		mix(&digest, surviving.end);
		bad.start = 0x5000;
		require(process_join_range_prepare_result(&surviving,
							  &bad) == -22);
		mix(&digest, 0x6a6f696e62616431UL);
		require(surviving.end == 0x7000);
		surviving.end = 0x3000;
		bad = merging;
		bad.flag = VR_PROT_WRITE;
		require(process_join_range_prepare_result(&surviving,
							  &bad) == -22);
		mix(&digest, 0x6a6f696e62616432UL);
		bad = merging;
		bad.memobj = &bad;
		require(process_join_range_prepare_result(&surviving,
							  &bad) == -22);
		mix(&digest, 0x6a6f696e62616433UL);
		surviving.end = 0x3000;
		bad = merging;
		bad.objoff = 0x5000;
		require(process_join_range_prepare_result(&surviving,
							  &bad) == -22);
		require(process_join_range_prepare_result(NULL, &merging) ==
			-22);
		mix(&digest, 0x6a6f696e62616434UL);
	}
	{
		unsigned long memobj_marker;
		struct fake_memobj_ops split_ops = {
			.free = fake_range_memobj_direct_free,
		};
		struct fake_memobj split_memobj = {
			.ops = &split_ops,
			.refcnt = 2,
		};
		struct fake_vm_range low = {
			.start = 0x1000,
			.end = 0x5000,
			.flag = VR_PROT_READ,
			.memobj = &memobj_marker,
			.objoff = 0x80,
		};
		struct fake_vm_range high = {
			.start = 0x5000,
			.end = 0x9000,
		};
		struct fake_vm_range surviving = {
			.start = 0x1000,
			.end = 0x3000,
			.flag = VR_PROT_READ,
			.memobj = &memobj_marker,
			.objoff = 0x2000,
		};
		struct fake_vm_range merging = {
			.start = 0x3000,
			.end = 0x7000,
			.flag = VR_PROT_READ,
			.memobj = &memobj_marker,
			.objoff = 0x4000,
		};
		struct fake_vm_range final_straight = {
			.start = 0x4000,
			.end = 0x8000,
			.straight_start = 0x102000,
		};
		struct fake_vm_range final_main = {
			.start = 0x100000,
			.end = 0x180000,
		};
		struct fake_vm_range convert_range = {
			.start = 0x6000,
			.end = 0xa000,
			.straight_start = 0x102000,
		};
		struct fake_rb_root root = { 0 };
		void *cache[4] = { &merging, &low, &merging, NULL };
		void *published = NULL;
		void *newrange = NULL;
		unsigned long plan_start = 0;
		unsigned long plan_end = 0;
		unsigned long converted_start = 0;
		unsigned long converted_end = 0;
		unsigned long converted_len = 0;
		size_t straight_len = 0x80000;
		int vm_marker;
		int action = -1;
		int rc;

		reset_range_body_trace();
		rc = process_split_range_publish_result(&vm_marker, &low,
			&high, 0x3000, &published, fake_range_memobj_ref,
			fake_split_publish_insert);
		require(rc == 0);
		require(range_memobj_ref_count == 1);
		require(range_insert_publish_count == 1);
		require(low.end == 0x3000);
		require(published == &high);
		mix(&digest, low.end ^ (unsigned long)(published == &high));

		reset_range_body_trace();
		low.end = 0x5000;
		low.memobj = &split_memobj;
		split_memobj.refcnt = 2;
		published = NULL;
		rc = process_split_range_publish_result(&vm_marker, &low,
			&high, 0x3000, &published, NULL,
			fake_split_publish_insert);
		require(rc == 0);
		require(split_memobj.refcnt == 3);
		require(range_memobj_ref_count == 0);
		require(range_insert_publish_count == 1);
		require(low.end == 0x3000);
		require(published == &high);
		mix(&digest, (unsigned long)split_memobj.refcnt);
		low.memobj = &memobj_marker;

		range_insert_publish_rc = -9;
		rc = process_split_range_publish_result(&vm_marker, &low,
			&high, 0x2800, &published, fake_range_memobj_ref,
			fake_split_publish_insert);
		require(rc == -9);
		mix(&digest, (unsigned long)rc);

		reset_range_body_trace();
		low.end = 0x5000;
		published = NULL;
		rc = process_split_range_publish_body_result(&vm_marker, &low,
			&high, 0x3000, &published, fake_range_memobj_ref,
			fake_split_publish_insert, fake_split_publish_log);
		require(rc == 0);
		require(split_publish_log_count == 0);
		require(published == &high);
		require(low.end == 0x3000);
		mix(&digest, low.end ^ (unsigned long)(published == &high));

		reset_range_body_trace();
		low.end = 0x5000;
		range_insert_publish_rc = -11;
		rc = process_split_range_publish_body_result(&vm_marker, &low,
			&high, 0x3000, &published, fake_range_memobj_ref,
			fake_split_publish_insert, fake_split_publish_log);
		require(rc == -11);
		require(split_publish_log_count == 1);
		require(split_publish_log_error == -11);
		mix(&digest, (unsigned int)-split_publish_log_error);

		{
			struct fake_address_space as = {
				.page_table = (void *)0xabcd000UL,
			};
			struct fake_process_vm_full pt_vm = {
				.address_space = &as,
			};
			struct fake_vm_range pt_range = {
				.start = 0x200000,
				.end = 0x600000,
				.pgshift = 21,
			};

			reset_range_body_trace();
			rc = process_split_range_pt_body_result(&pt_vm,
				&pt_range, 0x201000, fake_split_pt_split,
				fake_split_pt_log);
			require(rc == 0);
			require(pt_range.pgshift == 0);
			require(split_pt_count == 1);
			require(split_pt_page_table == as.page_table);
			require(split_pt_vm == &pt_vm);
			require(split_pt_range == &pt_range);
			require(split_pt_addr == (void *)0x201000UL);
			require(split_pt_log_count == 0);
			mix(&digest, (unsigned long)pt_range.pgshift);
			mix(&digest, (unsigned long)split_pt_addr);

			reset_range_body_trace();
			pt_range.pgshift = 21;
			split_pt_rc = -13;
			rc = process_split_range_pt_body_result(&pt_vm,
				&pt_range, 0x200000, fake_split_pt_split,
				fake_split_pt_log);
			require(rc == -13);
			require(pt_range.pgshift == 21);
			require(split_pt_count == 1);
			require(split_pt_log_count == 1);
			require(split_pt_log_error == -13);
			mix(&digest, (unsigned int)-split_pt_log_error);
		}

		reset_range_body_trace();
		low.end = 0x5000;
		rc = -777;
		published = (void *)0x51515151UL;
		newrange = process_split_range_alloc_init_body_result(
			&vm_marker, &low, 0x2800, &published,
			sizeof(struct fake_vm_range), 0x77, &rc,
			fake_split_range_alloc, fake_split_range_alloc_log);
		require(rc == 0);
		require(newrange == &split_alloc_range);
		require(split_alloc_count == 1);
		require(split_alloc_size == sizeof(struct fake_vm_range));
		require(split_alloc_flags == 0x77);
		require(split_alloc_log_count == 0);
		require(split_alloc_range.start == 0x2800);
		require(split_alloc_range.end == low.end);
		require(split_alloc_range.memobj == low.memobj);
		require(split_alloc_range.objoff == 0x1880);
		mix(&digest, split_alloc_range.start ^ split_alloc_range.end);
		mix(&digest, (unsigned long)split_alloc_range.objoff);

		reset_range_body_trace();
		split_alloc_fail = 1;
		rc = 0;
		newrange = process_split_range_alloc_init_body_result(
			&vm_marker, &low, 0x2800, &published,
			sizeof(struct fake_vm_range), 0x78, &rc,
			fake_split_range_alloc, fake_split_range_alloc_log);
		require(rc == -12);
		require(newrange == NULL);
		require(split_alloc_count == 1);
		require(split_alloc_size == sizeof(struct fake_vm_range));
		require(split_alloc_flags == 0x78);
		require(split_alloc_log_count == 1);
		require(split_alloc_log_vm == &vm_marker);
		require(split_alloc_log_range == &low);
		require(split_alloc_log_addr == 0x2800);
		require(split_alloc_log_splitp == &published);
		mix(&digest, (unsigned int)-rc);

		reset_range_body_trace();
		rc = 0;
		newrange = process_split_range_alloc_init_body_result(
			&vm_marker, &low, 0x2800, &published,
			sizeof(struct fake_vm_range), 0x79, &rc,
			NULL, fake_split_range_alloc_log);
		require(rc == -22);
		require(newrange == NULL);
		require(split_alloc_count == 0);
		require(split_alloc_log_count == 0);
		mix(&digest, (unsigned int)-rc);

		{
			struct fake_address_space as = {
				.page_table = (void *)0xabc000UL,
			};
			struct fake_process_vm_full shm_vm = {
				.address_space = &as,
			};
			struct fake_memobj shm_obj = {
				.flags = MF_SHM,
			};
			struct fake_vm_range shm_range = {
				.start = 0x4000,
				.end = 0x8000,
				.memobj = &shm_obj,
				.objoff = 0x1000,
			};
			struct fake_page_for_split page = {
				.pgshift = 12,
			};

			require(offsetof(struct fake_page_for_split,
				pgshift) == 72);
			reset_range_body_trace();
			split_shm_lookup_phys = 0xfeed000UL;
			split_shm_phys_to_page_result = &page;
			rc = process_split_shm_update_body_result(&shm_vm,
				&shm_range, 0x5234,
				offsetof(struct fake_page_for_split, pgshift),
				fake_split_shm_lookup_page,
				fake_split_shm_phys_to_page,
				fake_split_shm_update_page, fake_split_shm_log);
			require(rc == 0);
			require(split_shm_lookup_count == 1);
			require(split_shm_lookup_off == 0x2234);
			require(split_shm_lookup_p2align == 0);
			require(split_shm_phys_to_page_count == 1);
			require(split_shm_phys_to_page_phys == 0xfeed000UL);
			require(split_shm_update_count == 1);
			require(split_shm_update_memobj == &shm_obj);
			require(split_shm_update_page_table == as.page_table);
			require(split_shm_update_page == &page);
			require(split_shm_update_vaddr == (void *)0x5000UL);
			require(split_shm_log_count == 0);
			mix(&digest, (unsigned long)split_shm_lookup_off);
			mix(&digest, (unsigned long)split_shm_update_vaddr);

			reset_range_body_trace();
			shm_obj.flags = 0;
			rc = process_split_shm_update_body_result(&shm_vm,
				&shm_range, 0x5234,
				offsetof(struct fake_page_for_split, pgshift),
				fake_split_shm_lookup_page,
				fake_split_shm_phys_to_page,
				fake_split_shm_update_page, fake_split_shm_log);
			require(rc == 0);
			require(split_shm_lookup_count == 0);
			require(split_shm_update_count == 0);
			shm_obj.flags = MF_SHM;

			reset_range_body_trace();
			split_shm_lookup_rc = -2;
			rc = process_split_shm_update_body_result(&shm_vm,
				&shm_range, 0x5234,
				offsetof(struct fake_page_for_split, pgshift),
				fake_split_shm_lookup_page,
				fake_split_shm_phys_to_page,
				fake_split_shm_update_page, fake_split_shm_log);
			require(rc == 0);
			require(split_shm_phys_to_page_count == 1);
			require(split_shm_update_count == 0);
			require(split_shm_log_count == 0);

			reset_range_body_trace();
			split_shm_lookup_rc = -5;
			rc = process_split_shm_update_body_result(&shm_vm,
				&shm_range, 0x5234,
				offsetof(struct fake_page_for_split, pgshift),
				fake_split_shm_lookup_page,
				fake_split_shm_phys_to_page,
				fake_split_shm_update_page, fake_split_shm_log);
			require(rc == -5);
			require(split_shm_log_count == 1);
			require(split_shm_log_event ==
				PROCESS_SPLIT_SHM_LOG_LOOKUP_FAILED);
			require(split_shm_log_error == -5);
			mix(&digest, (unsigned int)-split_shm_log_error);

			reset_range_body_trace();
			split_shm_lookup_phys = 0xfeed000UL;
			split_shm_phys_to_page_result = &page;
			split_shm_update_rc = -6;
			rc = process_split_shm_update_body_result(&shm_vm,
				&shm_range, 0x5234,
				offsetof(struct fake_page_for_split, pgshift),
				fake_split_shm_lookup_page,
				fake_split_shm_phys_to_page,
				fake_split_shm_update_page, fake_split_shm_log);
			require(rc == -6);
			require(split_shm_update_count == 1);
			require(split_shm_log_count == 1);
			require(split_shm_log_event ==
				PROCESS_SPLIT_SHM_LOG_UPDATE_FAILED);
			require(split_shm_log_error == -6);
			mix(&digest, (unsigned int)-split_shm_log_error);
		}

		reset_range_insert_trace();
		rc = process_vm_range_insert_result(&root, &surviving,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		rc = process_vm_range_insert_result(&root, &merging,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		reset_range_body_trace();
		rc = process_join_range_body_result(&vm_marker, &root, cache,
			4, &surviving, &merging, fake_range_memobj_unref,
			fake_range_free, fake_range_tofu);
		require(rc == 0);
		require(surviving.end == 0x7000);
		require(range_memobj_unref_count == 1);
		require(range_tofu_count == 1);
		require(range_free_count == 1);
		require(cache[0] == &surviving);
		require(cache[2] == &surviving);
		mix_range_tree(&digest, root.rb_node);
		mix(&digest, surviving.end ^ range_free_count);

		{
			struct fake_memobj_ops join_ops = {
				.free = fake_range_memobj_direct_free,
			};
			struct fake_memobj join_memobj = {
				.ops = &join_ops,
				.refcnt = 2,
			};

			root = (struct fake_rb_root){ 0 };
			surviving = (struct fake_vm_range){
				.start = 0x1000,
				.end = 0x3000,
				.flag = VR_PROT_READ,
				.memobj = &join_memobj,
				.objoff = 0x2000,
			};
			merging = (struct fake_vm_range){
				.start = 0x3000,
				.end = 0x7000,
				.flag = VR_PROT_READ,
				.memobj = &join_memobj,
				.objoff = 0x4000,
			};
			cache[0] = &merging;
			cache[1] = &low;
			cache[2] = &merging;
			cache[3] = NULL;
			require(process_vm_range_insert_result(&root,
				&surviving, &vm_marker, NULL, NULL) == 0);
			require(process_vm_range_insert_result(&root, &merging,
				&vm_marker, NULL, NULL) == 0);
			reset_range_body_trace();
			rc = process_join_range_body_result(&vm_marker, &root,
				cache, 4, &surviving, &merging, NULL,
				fake_range_free, fake_range_tofu);
			require(rc == 0);
			require(join_memobj.refcnt == 1);
			require(range_memobj_unref_count == 0);
			require(range_free_count == 1);
			require(cache[0] == &surviving);
			require(cache[2] == &surviving);
			mix(&digest, (unsigned long)join_memobj.refcnt);
		}

		reset_range_body_trace();
		final_straight.flag = VR_PROT_READ;
		page_size_fail_after = 4;
		rc = process_free_range_pt_plan_result(&final_straight,
			0x100000, 0, 0, 0, 0, 0, 0, &plan_start,
			&plan_end, &action, fake_page_size);
		require(rc == 0);
		require(action == PROCESS_FREE_RANGE_PT_SKIP);
		require(plan_start == final_straight.start);
		require(plan_end == final_straight.end);
		mix(&digest, action ^ plan_start ^ plan_end);

		final_straight.straight_start = 0;
		final_straight.start = 0x210123;
		final_straight.end = 0x220456;
		page_size_call_count = 0;
		page_size_fail_after = 4;
		rc = process_free_range_pt_plan_result(&final_straight,
			0, 0, 0, 0, 0, 0, 0, &plan_start, &plan_end,
			&action, fake_page_size);
		require(rc == 0);
		require(action == PROCESS_FREE_RANGE_PT_FREE);
		require(plan_start == 0x200000);
		require(plan_end == 0x400000);
		mix(&digest, action ^ plan_start ^ plan_end);

		final_straight.flag = VR_REMOTE | VR_PROT_READ;
		page_size_call_count = 0;
		rc = process_free_range_pt_plan_result(&final_straight,
			0, 0, 0, 0, 0, 0, 0, &plan_start, &plan_end,
			&action, fake_page_size);
		require(rc == 0);
		require(action == PROCESS_FREE_RANGE_PT_CLEAR);
		require(page_size_call_count == 0);
		mix(&digest, action ^ page_size_call_count);

		final_straight.flag = VR_PROT_READ;
		page_size_call_count = 0;
		page_size_fail_after = 4;
		rc = process_free_range_pt_plan_result(&final_straight,
			0, 0, 0, 0, 0, 1, MF_HUGETLBFS, &plan_start,
			&plan_end, &action, fake_page_size);
		require(rc == 0);
		require(action == PROCESS_FREE_RANGE_PT_CLEAR);
		mix(&digest, action ^ plan_start ^ plan_end);

		root = (struct fake_rb_root){ 0 };
		cache[0] = &final_straight;
		cache[1] = NULL;
		final_straight.start = 0x4000;
		final_straight.end = 0x8000;
		final_straight.straight_start = 0x102000;
		rc = process_vm_range_insert_result(&root, &final_straight,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		reset_range_body_trace();
		rc = process_free_range_finalize_result(&vm_marker, &root,
			cache, 4, &final_straight, 0x100000, &straight_len,
			0x80000000, fake_final_phys_to_virt,
			fake_final_free_pages, fake_final_clear_main,
			fake_range_free);
		require(rc == 0);
		require(cache[0] == NULL);
		require(final_phys_to_virt_phys == 0x80002000);
		require(final_free_pages_addr == final_phys_to_virt_addr);
		require(final_free_pages_npages == 4);
		require(range_free_count == 1);
		mix(&digest, final_phys_to_virt_phys);
		mix(&digest, final_free_pages_npages);

		root = (struct fake_rb_root){ 0 };
		cache[0] = &final_main;
		straight_len = 0x80000;
		rc = process_vm_range_insert_result(&root, &final_main,
			&vm_marker, fake_range_insert_log,
			fake_range_insert_dump);
		require(rc == 0);
		reset_range_body_trace();
		rc = process_free_range_finalize_result(&vm_marker, &root,
			cache, 4, &final_main, 0x100000, &straight_len,
			0x80000000, fake_final_phys_to_virt,
			fake_final_free_pages, fake_final_clear_main,
			fake_range_free);
		require(rc == 0);
		require(final_clear_main_count == 1);
		require(final_clear_main_start == 0x100000);
		require(final_clear_main_end == 0x180000);
		require(straight_len == 0);
		require(range_free_count == 1);
		mix(&digest, final_clear_main_start ^ final_clear_main_end);

		struct fake_address_space free_as = {
			.page_table = (void *)0xabcd1234UL,
		};
		struct fake_memobj free_memobj = {
			.flags = 0,
		};
		struct fake_process_vm_full free_vm = {
			.address_space = &free_as,
			.vm_range_tree = { 0 },
		};
		struct fake_vm_range free_prev = {
			.start = 0x1000,
			.end = 0x2000,
		};
		struct fake_vm_range free_body = {
			.start = 0x210123,
			.end = 0x220456,
			.flag = VR_PROT_READ,
			.memobj = &free_memobj,
		};
		struct fake_vm_range free_next = {
			.start = 0x900000,
			.end = 0xa00000,
		};
		straight_len = 0x80000;
		require(process_vm_range_insert_result(&free_vm.vm_range_tree,
			&free_prev, &free_vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&free_vm.vm_range_tree,
			&free_body, &free_vm, NULL, NULL) == 0);
		require(process_vm_range_insert_result(&free_vm.vm_range_tree,
			&free_next, &free_vm, NULL, NULL) == 0);
		free_vm.range_cache[0] = &free_body;
		reset_range_body_trace();
		page_size_fail_after = 4;
		free_body_tofu_result = 2;
		rc = process_free_memory_range_body_result(&free_vm,
			&free_body, 0, &straight_len, 0x80000000, 1,
			fake_page_size, fake_free_body_lock,
			fake_free_body_unlock, fake_range_memobj_ref,
			fake_range_memobj_unref, fake_free_body_pt_free,
			fake_free_body_pt_clear, fake_free_body_tofu_remove,
			fake_final_phys_to_virt, fake_final_free_pages,
			fake_final_clear_main, fake_range_free,
			fake_free_body_log);
		require(rc == 0);
		require(free_body_lock_count == 1);
		require(free_body_unlock_count == 1);
		require(free_body_pt_free_count == 1);
		require(free_body_pt_free_page_table == free_as.page_table);
		require(free_body_pt_free_start == 0x200000);
		require(free_body_pt_free_end == 0x400000);
		require(free_body_pt_free_memobj == &free_memobj);
		require(range_memobj_ref_count == 1);
		require(range_memobj_unref_count == 2);
		require(free_body_tofu_count == 1);
		require(free_body_tofu_range == &free_body);
		require(range_free_count == 1);
		require(free_vm.range_cache[0] == NULL);
		require(free_body_log_count == 2);
		require(free_body_log_event[0] ==
			PROCESS_FREE_BODY_LOG_TOFU_REMOVED);
		require(free_body_log_error[0] == 2);
		require(free_body_log_event[1] == PROCESS_FREE_BODY_LOG_DONE);
		mix(&digest, free_body_pt_free_start ^ free_body_pt_free_end);
		mix(&digest, range_memobj_unref_count ^ free_body_tofu_count);

		{
			struct fake_memobj_ops direct_free_ops = {
				.free = fake_range_memobj_direct_free,
			};
			struct fake_memobj direct_free_memobj = {
				.ops = &direct_free_ops,
				.flags = 0,
				.refcnt = 1,
			};
			struct fake_vm_range direct_prev = {
				.start = 0x1000,
				.end = 0x2000,
			};
			struct fake_vm_range direct_body = {
				.start = 0x210123,
				.end = 0x220456,
				.flag = VR_PROT_READ,
				.memobj = &direct_free_memobj,
			};
			struct fake_vm_range direct_next = {
				.start = 0x900000,
				.end = 0xa00000,
			};

			free_vm = (struct fake_process_vm_full){
				.address_space = &free_as,
				.vm_range_tree = { 0 },
			};
			require(process_vm_range_insert_result(
				&free_vm.vm_range_tree, &direct_prev,
				&free_vm, NULL, NULL) == 0);
			require(process_vm_range_insert_result(
				&free_vm.vm_range_tree, &direct_body,
				&free_vm, NULL, NULL) == 0);
			require(process_vm_range_insert_result(
				&free_vm.vm_range_tree, &direct_next,
				&free_vm, NULL, NULL) == 0);
			free_vm.range_cache[0] = &direct_body;
			reset_range_body_trace();
			page_size_fail_after = 4;
			rc = process_free_memory_range_body_result(&free_vm,
				&direct_body, 0, &straight_len, 0x80000000, 0,
				fake_page_size, fake_free_body_lock,
				fake_free_body_unlock, NULL, NULL,
				fake_free_body_pt_free, fake_free_body_pt_clear,
				NULL, fake_final_phys_to_virt,
				fake_final_free_pages, fake_final_clear_main,
				fake_range_free, fake_free_body_log);
			require(rc == 0);
			require(free_body_lock_count == 1);
			require(free_body_unlock_count == 1);
			require(free_body_pt_free_count == 1);
			require(free_body_pt_free_memobj == &direct_free_memobj);
			require(range_memobj_ref_count == 0);
			require(range_memobj_unref_count == 0);
			require(direct_free_memobj.refcnt == 0);
			require(range_memobj_direct_free_count == 1);
			require(range_free_count == 1);
			require(free_vm.range_cache[0] == NULL);
			require(free_body_log_count == 1);
			require(free_body_log_event[0] ==
				PROCESS_FREE_BODY_LOG_DONE);
			mix(&digest, (unsigned long)direct_free_memobj.refcnt);
			mix(&digest,
				(unsigned long)range_memobj_direct_free_count);
		}

		{
			unsigned long sync_arg_marker = 0xabcdef42UL;
			void *sync_step_marker = (void *)0xfeed1234UL;
			struct fake_memobj sync_memobj = {
				.flags = 0,
				.refcnt = 1,
			};
			struct fake_process_vm_full sync_vm = {
				.address_space = &free_as,
			};
			struct fake_vm_range sync_range = {
				.start = 0x4000,
				.end = 0x9000,
				.memobj = &sync_memobj,
				.pgshift = 21,
			};

			reset_range_body_trace();
			rc = process_sync_memory_range_body_result(&sync_vm,
				&sync_range, 0x4000, 0x9000,
				&sync_arg_marker, sync_step_marker,
				fake_free_body_lock, fake_free_body_unlock,
				fake_sync_visit, fake_sync_log);
			require(rc == 0);
			require(free_body_lock_count == 1);
			require(free_body_unlock_count == 1);
			require(sync_body_visit_count == 1);
			require(sync_body_visit_page_table == free_as.page_table);
			require(sync_body_visit_start == 0x4000);
			require(sync_body_visit_end == 0x9000);
			require(sync_body_visit_pgshift == 21);
			require(sync_body_visit_flags == VPTEF_SKIP_NULL);
			require(sync_body_visit_step == sync_step_marker);
			require(sync_body_visit_arg == &sync_arg_marker);
			require(sync_memobj.refcnt == 1);
			require(sync_body_log_count == 0);
			mix(&digest, sync_body_visit_start ^ sync_body_visit_end);
			mix(&digest, (unsigned long)sync_memobj.refcnt);

			reset_range_body_trace();
			sync_memobj.flags = MF_ZEROFILL;
			sync_memobj.refcnt = 7;
			sync_body_visit_rc = -88;
			rc = process_sync_memory_range_body_result(&sync_vm,
				&sync_range, 0x5000, 0xa000,
				&sync_arg_marker, sync_step_marker,
				fake_free_body_lock, fake_free_body_unlock,
				fake_sync_visit, fake_sync_log);
			require(rc == -88);
			require(sync_memobj.refcnt == 7);
			require(sync_body_log_count == 1);
			require(sync_body_log_start == 0x5000);
			require(sync_body_log_end == 0xa000);
			require(sync_body_log_error == -88);
			mix(&digest, (unsigned long)(unsigned int)-rc);
			mix(&digest, (unsigned long)sync_memobj.refcnt);
		}

		{
			unsigned long remap_arg_marker = 0x1234UL;
			void *remap_step_marker = (void *)0xface1234UL;
			struct fake_memobj remap_memobj = {
				.flags = 0,
				.refcnt = 1,
			};
			struct fake_process_vm_full remap_vm = {
				.address_space = &free_as,
			};
			struct fake_vm_range remap_range = {
				.start = 0x6000,
				.end = 0xb000,
				.memobj = &remap_memobj,
				.pgshift = 0,
			};

			reset_range_body_trace();
			rc = process_remap_memory_range_body_result(&remap_vm,
				&remap_range, 0x6000, 0xb000, 0x222,
				&remap_arg_marker, remap_step_marker,
				fake_free_body_lock, fake_free_body_unlock,
				fake_sync_visit, fake_remap_log);
			require(rc == 0);
			require(free_body_lock_count == 1);
			require(free_body_unlock_count == 1);
			require(remap_range.pgshift == PAGE_SHIFT);
			require(remap_memobj.refcnt == 1);
			require(sync_body_visit_count == 1);
			require(sync_body_visit_page_table == free_as.page_table);
			require(sync_body_visit_start == 0x6000);
			require(sync_body_visit_end == 0xb000);
			require(sync_body_visit_flags == 0);
			require(sync_body_visit_pgshift == PAGE_SHIFT);
			require(sync_body_visit_step == remap_step_marker);
			require(sync_body_visit_arg == &remap_arg_marker);
			require(remap_body_log_count == 0);
			mix(&digest, sync_body_visit_start ^ sync_body_visit_end);
			mix(&digest, (unsigned long)remap_range.pgshift);

			reset_range_body_trace();
			remap_memobj.refcnt = 1;
			remap_range.pgshift = LARGE_PAGE_SHIFT;
			rc = process_remap_memory_range_body_result(&remap_vm,
				&remap_range, 0x7000, 0xc000, 0x333,
				&remap_arg_marker, remap_step_marker,
				fake_free_body_lock, fake_free_body_unlock,
				fake_sync_visit, fake_remap_log);
			require(rc == -E2BIG);
			require(sync_body_visit_count == 0);
			require(remap_body_log_count == 1);
			require(remap_body_log_event ==
				PROCESS_REMAP_RANGE_LOG_PGSHIFT);
			require(remap_body_log_start == 0x7000);
			require(remap_body_log_end == 0xc000);
			require(remap_body_log_off == 0x333);
			require(remap_body_log_old_pgshift == LARGE_PAGE_SHIFT);
			require(remap_body_log_error == -E2BIG);
			require(remap_memobj.refcnt == 1);
			mix(&digest,
				(unsigned long)(unsigned int)-remap_body_log_error);
			mix(&digest, (unsigned long)remap_body_log_old_pgshift);

			reset_range_body_trace();
			remap_memobj.refcnt = 1;
			remap_range.pgshift = PAGE_SHIFT;
			sync_body_visit_rc = -66;
			rc = process_remap_memory_range_body_result(&remap_vm,
				&remap_range, 0x8000, 0xd000, 0x444,
				&remap_arg_marker, remap_step_marker,
				fake_free_body_lock, fake_free_body_unlock,
				fake_sync_visit, fake_remap_log);
			require(rc == -66);
			require(sync_body_visit_count == 1);
			require(remap_body_log_count == 1);
			require(remap_body_log_event ==
				PROCESS_REMAP_RANGE_LOG_VISIT_FAILED);
			require(remap_body_log_start == 0x8000);
			require(remap_body_log_end == 0xd000);
			require(remap_body_log_off == 0x444);
			require(remap_body_log_old_pgshift == PAGE_SHIFT);
			require(remap_body_log_error == -66);
			require(remap_memobj.refcnt == 1);
			mix(&digest,
				(unsigned long)(unsigned int)-remap_body_log_error);
			mix(&digest, (unsigned long)remap_body_log_start);
		}

		{
			unsigned long invalidate_arg_marker = 0x5678UL;
			void *invalidate_step_marker = (void *)0xbeef5678UL;
			int start_pte;
			int end_pte;
			struct fake_memobj invalidate_memobj = {
				.flags = 0,
				.refcnt = 1,
			};
			struct fake_process_vm_full invalidate_vm = {
				.address_space = &free_as,
			};
			struct fake_vm_range invalidate_range = {
				.start = 0x9000,
				.end = 0xe000,
				.memobj = &invalidate_memobj,
				.pgshift = 21,
			};

			reset_range_body_trace();
			rc = process_invalidate_memory_range_body_result(
				&invalidate_vm, &invalidate_range, 0x9000,
				0xe000, &invalidate_arg_marker,
				invalidate_step_marker, fake_free_body_lock,
				fake_free_body_unlock,
				fake_invalidate_lookup_pte,
				fake_invalidate_pte_contiguous,
				fake_invalidate_pte_head,
				fake_invalidate_pte_tail,
				fake_invalidate_split,
				fake_free_body_pt_free, fake_sync_visit,
				fake_sync_log);
			require(rc == 0);
			require(free_body_lock_count == 1);
			require(free_body_unlock_count == 1);
			require(invalidate_lookup_count == 2);
			require(invalidate_lookup_page_table[0] ==
				free_as.page_table);
			require(invalidate_lookup_addr[0] == 0x9000);
			require(invalidate_lookup_addr[1] == 0xdfff);
			require(sync_body_visit_count == 1);
			require(sync_body_visit_start == 0x9000);
			require(sync_body_visit_end == 0xe000);
			require(sync_body_visit_pgshift == 21);
			require(sync_body_visit_flags == VPTEF_SKIP_NULL);
			require(sync_body_visit_step == invalidate_step_marker);
			require(sync_body_visit_arg == &invalidate_arg_marker);
			require(free_body_pt_free_count == 0);
			require(sync_body_log_count == 0);
			require(invalidate_memobj.refcnt == 1);
			mix(&digest, sync_body_visit_start ^ sync_body_visit_end);
			mix(&digest, (unsigned long)invalidate_lookup_count);

			reset_range_body_trace();
			invalidate_memobj.flags = MF_SHM;
			invalidate_memobj.refcnt = 1;
			invalidate_lookup_result[0] = &start_pte;
			invalidate_lookup_result[1] = &end_pte;
			invalidate_lookup_pgsize_result[0] = PAGE_SIZE;
			invalidate_lookup_pgsize_result[1] = LARGE_PAGE_SIZE;
			invalidate_pte_contiguous_result[0] = 1;
			invalidate_pte_contiguous_result[1] = 1;
			invalidate_pte_head_result = 0;
			invalidate_pte_tail_result = 0;
			rc = process_invalidate_memory_range_body_result(
				&invalidate_vm, &invalidate_range, 0xa000,
				0xf000, &invalidate_arg_marker,
				invalidate_step_marker, fake_free_body_lock,
				fake_free_body_unlock,
				fake_invalidate_lookup_pte,
				fake_invalidate_pte_contiguous,
				fake_invalidate_pte_head,
				fake_invalidate_pte_tail,
				fake_invalidate_split,
				fake_free_body_pt_free, fake_sync_visit,
				fake_sync_log);
			require(rc == 0);
			require(invalidate_split_count == 2);
			require(invalidate_split_ptep[0] == &start_pte);
			require(invalidate_split_ptep[1] == &end_pte);
			require(invalidate_split_pgsize[0] == PAGE_SIZE);
			require(invalidate_split_pgsize[1] == LARGE_PAGE_SIZE);
			require(invalidate_split_memobj_flags[0] == MF_SHM);
			require(invalidate_split_memobj_flags[1] == MF_SHM);
			require(free_body_pt_free_count == 1);
			require(free_body_pt_free_start == 0xa000);
			require(free_body_pt_free_end == 0xf000);
			require(free_body_pt_free_memobj == &invalidate_memobj);
			require(sync_body_visit_count == 0);
			require(sync_body_log_count == 0);
			require(invalidate_memobj.refcnt == 1);
			mix(&digest, (unsigned long)invalidate_split_count);
			mix(&digest, free_body_pt_free_start ^
				free_body_pt_free_end);

			reset_range_body_trace();
			invalidate_memobj.flags = MF_SHM;
			invalidate_memobj.refcnt = 1;
			invalidate_lookup_result[0] = &start_pte;
			invalidate_pte_contiguous_result[0] = 1;
			invalidate_pte_head_result = 0;
			invalidate_split_rc = -55;
			rc = process_invalidate_memory_range_body_result(
				&invalidate_vm, &invalidate_range, 0xb000,
				0x10000, &invalidate_arg_marker,
				invalidate_step_marker, fake_free_body_lock,
				fake_free_body_unlock,
				fake_invalidate_lookup_pte,
				fake_invalidate_pte_contiguous,
				fake_invalidate_pte_head,
				fake_invalidate_pte_tail,
				fake_invalidate_split,
				fake_free_body_pt_free, fake_sync_visit,
				fake_sync_log);
			require(rc == -55);
			require(invalidate_split_count == 1);
			require(invalidate_lookup_count == 1);
			require(free_body_pt_free_count == 0);
			require(sync_body_visit_count == 0);
			require(sync_body_log_count == 0);
			require(invalidate_memobj.refcnt == 1);
			mix(&digest, (unsigned long)(unsigned int)-rc);

			reset_range_body_trace();
			invalidate_memobj.flags = 0;
			invalidate_memobj.refcnt = 1;
			sync_body_visit_rc = -77;
			rc = process_invalidate_memory_range_body_result(
				&invalidate_vm, &invalidate_range, 0xc000,
				0x11000, &invalidate_arg_marker,
				invalidate_step_marker, fake_free_body_lock,
				fake_free_body_unlock,
				fake_invalidate_lookup_pte,
				fake_invalidate_pte_contiguous,
				fake_invalidate_pte_head,
				fake_invalidate_pte_tail,
				fake_invalidate_split,
				fake_free_body_pt_free, fake_sync_visit,
				fake_sync_log);
			require(rc == -77);
			require(sync_body_visit_count == 1);
			require(sync_body_log_count == 1);
			require(sync_body_log_start == 0xc000);
			require(sync_body_log_end == 0x11000);
			require(sync_body_log_error == -77);
			require(invalidate_memobj.refcnt == 1);
			mix(&digest, (unsigned long)(unsigned int)-rc);
			mix(&digest, sync_body_log_start);

			{
				struct {
					struct fake_vm_range *range;
				} invalidate_one_arg = {
					.range = &invalidate_range,
				};
				void *invalidate_page_table =
					(void *)0xbadbeefUL;
				char fake_page;
				unsigned long pte;

				reset_range_body_trace();
				invalidate_one_pte_get_phys_result =
					0x12345000UL;
				invalidate_one_phys_to_page_result = &fake_page;
				invalidate_one_page_offset_result = 0x7000;
				invalidate_one_make_fileoff_value = 0x777000;
				pte = 0x12345007UL;
				invalidate_range.start = 0x100000;
				invalidate_range.objoff = 0x3000;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x102000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(pte == 0x777000);
				require(invalidate_one_pte_get_phys_count == 1);
				require(invalidate_one_phys_to_page_count == 1);
				require(invalidate_one_phys_to_page_phys ==
					0x12345000UL);
				require(invalidate_one_page_offset_count == 1);
				require(invalidate_one_make_fileoff_count == 1);
				require(invalidate_one_make_fileoff_off == 0x7000);
				require(invalidate_one_make_fileoff_pgsize ==
					PAGE_SIZE);
				require(invalidate_one_xchg_count == 1);
				require(invalidate_one_xchg_old_value ==
					0x12345007UL);
				require(invalidate_one_xchg_new_value == 0x777000);
				require(invalidate_one_flush_count == 1);
				require(invalidate_one_flush_addr == 0x102000UL);
				require(invalidate_one_contiguous_count == 1);
				require(invalidate_one_contiguous_value ==
					0x12345007UL);
				require(invalidate_one_page_unmap_count == 1);
				require(invalidate_one_page_unmap_page == &fake_page);
				require(invalidate_one_memobj_invalidate_count == 1);
				require(invalidate_one_memobj_invalidate_memobj ==
					&invalidate_memobj);
				require(invalidate_one_memobj_invalidate_phys ==
					0x12345000UL);
				require(invalidate_one_memobj_invalidate_pgsize ==
					PAGE_SIZE);
				require(invalidate_one_log_count == 0);
				mix(&digest, pte ^
					invalidate_one_memobj_invalidate_phys);

				reset_range_body_trace();
				pte = 0;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x102000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(invalidate_one_pte_null_count == 1);
				require(invalidate_one_pte_fileoff_count == 0);
				require(invalidate_one_xchg_count == 0);
				require(invalidate_one_memobj_invalidate_count == 0);
				mix(&digest, (unsigned long)invalidate_one_pte_null_count);

				reset_range_body_trace();
				invalidate_one_pte_fileoff_result = 1;
				pte = 0x2222;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x102000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(invalidate_one_pte_fileoff_count == 1);
				require(invalidate_one_pte_get_phys_count == 0);
				require(invalidate_one_memobj_invalidate_count == 0);
				mix(&digest,
					(unsigned long)invalidate_one_pte_fileoff_count);

				reset_range_body_trace();
				invalidate_one_pte_get_phys_result =
					0x33333000UL;
				invalidate_one_contiguous_result = 1;
				invalidate_one_head_result = 0;
				pte = 0x3333;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x102000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(pte == 0);
				require(invalidate_one_contiguous_count == 1);
				require(invalidate_one_head_count == 1);
				require(invalidate_one_memobj_invalidate_count == 0);
				mix(&digest, invalidate_one_contiguous_value);

				reset_range_body_trace();
				invalidate_one_pte_get_phys_result =
					0x44444000UL;
				invalidate_one_contiguous_result = 1;
				invalidate_one_head_result = 1;
				invalidate_one_pgsize_to_tbllv_result = 7;
				invalidate_one_tbllv_to_contpgsize_result =
					0x200000;
				pte = 0x4444;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x102000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(invalidate_one_pgsize_to_tbllv_count == 1);
				require(invalidate_one_pgsize_to_tbllv_pgsize ==
					PAGE_SIZE);
				require(invalidate_one_tbllv_to_contpgsize_count ==
					1);
				require(invalidate_one_tbllv_to_contpgsize_level ==
					7);
				require(invalidate_one_memobj_invalidate_pgsize ==
					0x200000);
				mix(&digest,
					invalidate_one_memobj_invalidate_pgsize);

				reset_range_body_trace();
				invalidate_one_pte_get_phys_result =
					0x55555000UL;
				invalidate_one_memobj_invalidate_rc = -88;
				pte = 0x5555;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x103000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == -88);
				require(invalidate_one_log_count == 1);
				require(invalidate_one_log_arg == &invalidate_one_arg);
				require(invalidate_one_log_page_table ==
					invalidate_page_table);
				require(invalidate_one_log_ptep == &pte);
				require(invalidate_one_log_pte_value == 0);
				require(invalidate_one_log_pgaddr ==
					(void *)0x103000UL);
				require(invalidate_one_log_pgshift == PAGE_SHIFT);
				require(invalidate_one_log_error == -88);
				mix(&digest, (unsigned long)(unsigned int)-rc);

				reset_range_body_trace();
				invalidate_one_pte_get_phys_result =
					0x66666000UL;
				invalidate_one_phys_to_page_result = &fake_page;
				invalidate_one_page_offset_result = 0x6000;
				invalidate_one_page_unmap_rc = 1;
				pte = 0x6666;
				rc = process_invalidate_one_page_body_result(
					&invalidate_one_arg, invalidate_page_table,
					&pte, (void *)0x103000UL, PAGE_SHIFT,
					fake_invalidate_one_pte_null,
					fake_invalidate_one_pte_fileoff,
					fake_invalidate_one_pte_get_phys,
					fake_invalidate_one_phys_to_page,
					fake_invalidate_one_page_offset,
					fake_invalidate_one_make_fileoff,
					fake_invalidate_one_pte_xchg,
					fake_invalidate_one_flush,
					fake_invalidate_one_contiguous,
					fake_invalidate_one_head,
					fake_invalidate_one_pgsize_to_tbllv,
					fake_invalidate_one_tbllv_to_contpgsize,
					fake_invalidate_one_page_unmap,
					fake_invalidate_one_panic,
					fake_invalidate_one_memobj_invalidate,
					fake_invalidate_one_log);
				require(rc == 0);
				require(invalidate_one_make_fileoff_count == 0);
				require(invalidate_one_page_unmap_count == 1);
				require(invalidate_one_panic_count == 1);
				require(strcmp(invalidate_one_panic_message,
					"invalidate_one_page") == 0);
				require(invalidate_one_memobj_invalidate_count == 1);
				mix(&digest,
					(unsigned long)invalidate_one_panic_count);
			}
		}

		free_vm = (struct fake_process_vm_full){
			.address_space = &free_as,
			.vm_range_tree = { 0 },
		};
		struct fake_vm_range clear_body = {
			.start = 0x5000,
			.end = 0x9000,
			.flag = VR_REMOTE | VR_PROT_READ,
		};
		require(process_vm_range_insert_result(&free_vm.vm_range_tree,
			&clear_body, &free_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		free_body_pt_clear_rc = -77;
		rc = process_free_memory_range_body_result(&free_vm,
			&clear_body, 0, &straight_len, 0x80000000, 0,
			fake_page_size, fake_free_body_lock,
			fake_free_body_unlock, fake_range_memobj_ref,
			fake_range_memobj_unref, fake_free_body_pt_free,
			fake_free_body_pt_clear, fake_free_body_tofu_remove,
			fake_final_phys_to_virt, fake_final_free_pages,
			fake_final_clear_main, fake_range_free,
			fake_free_body_log);
		require(rc == 0);
		require(free_body_pt_clear_count == 1);
		require(free_body_pt_clear_start == 0x5000);
		require(free_body_pt_clear_end == 0x9000);
		require(range_memobj_ref_count == 0);
		require(range_memobj_unref_count == 0);
		require(range_free_count == 1);
		require(free_body_log_count == 2);
		require(free_body_log_event[0] ==
			PROCESS_FREE_BODY_LOG_PT_CLEAR_FAILED);
		require(free_body_log_error[0] == -77);
		require(free_body_log_event[1] == PROCESS_FREE_BODY_LOG_DONE);
		mix(&digest, free_body_pt_clear_start ^
			free_body_pt_clear_end);

		free_vm = (struct fake_process_vm_full){
			.address_space = &free_as,
			.vm_range_tree = { 0 },
		};
		struct fake_vm_range free_straight_fail = {
			.start = 0x4000,
			.end = 0x8000,
			.straight_start = 0x102000,
		};
		require(process_vm_range_insert_result(&free_vm.vm_range_tree,
			&free_straight_fail, &free_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		rc = process_free_memory_range_body_result(&free_vm,
			&free_straight_fail, 0x100000, &straight_len,
			0x80000000, 0, fake_page_size,
			fake_free_body_lock, fake_free_body_unlock,
			fake_range_memobj_ref, fake_range_memobj_unref,
			fake_free_body_pt_free, fake_free_body_pt_clear,
			NULL, NULL, fake_final_free_pages,
			fake_final_clear_main, fake_range_free,
			fake_free_body_log);
		require(rc == -22);
		require(free_body_pt_free_count == 0);
		require(free_body_pt_clear_count == 0);
		require(range_free_count == 0);
		require(free_body_log_count == 1);
		require(free_body_log_event[0] ==
			PROCESS_FREE_BODY_LOG_FINALIZE_FAILED);
		mix(&digest, (unsigned long)(unsigned int)-rc);

		rc = process_remove_straight_convert_result(0, 0x80000,
			NULL, 0x100000, 0x101000, &converted_start,
			&converted_end, &converted_len);
		require(rc == PROCESS_REMOVE_STRAIGHT_NO_CONVERT);
		rc = process_remove_straight_convert_result(0x100000,
			0x80000, NULL, 0x102800, 0x103800,
			&converted_start, &converted_end, &converted_len);
		require(rc == PROCESS_REMOVE_STRAIGHT_NEED_RANGE);
		rc = process_remove_straight_convert_result(0x100000,
			0x80000, &convert_range, 0x102800, 0x103800,
			&converted_start, &converted_end, &converted_len);
		require(rc == PROCESS_REMOVE_STRAIGHT_CONVERTED);
		require(converted_start == 0x6800);
		require(converted_end == 0x7800);
		require(converted_len == 0x1000);
		mix(&digest, converted_start ^ converted_end ^ converted_len);

		root = (struct fake_rb_root){ 0 };
		struct fake_process_vm_full remove_vm = {
			.vm_range_tree = { 0 },
		};
		struct fake_vm_range remove_whole = {
			.start = 0x1000,
			.end = 0x5000,
			.flag = VR_PROT_READ,
			.private_data = (void *)0xbeefUL,
		};
		struct fake_vm_range remove_middle = {
			.start = 0x2000,
			.end = 0x5000,
			.flag = VR_PROT_READ,
			.private_data = (void *)0xbeefUL,
		};
		int ro_freed = 0;

		require(process_vm_range_insert_result(&remove_vm.vm_range_tree,
			&remove_whole, &remove_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		remove_body_split_replacement = &remove_middle;
		rc = process_remove_memory_range_body_result(&remove_vm,
			0x2000, 0x4000, &ro_freed, 0, 0,
			fake_remove_body_split, fake_remove_body_xpmem,
			fake_remove_body_free, fake_remove_body_log);
		require(rc == 0);
		require(remove_body_split_count == 2);
		require(remove_body_split_addr[0] == 0x2000);
		require(remove_body_split_addr[1] == 0x4000);
		require(remove_body_xpmem_count == 1);
		require(remove_body_xpmem_range == &remove_middle);
		require(remove_body_free_count == 1);
		require(remove_body_free_range[0] == &remove_middle);
		require(ro_freed == 1);
		require(remove_body_log_count == 1);
		require(remove_body_log_event[0] ==
			PROCESS_REMOVE_RANGE_LOG_DONE);
		require(remove_body_log_error[0] == 1);
		mix(&digest, remove_body_split_addr[0] ^
			remove_body_split_addr[1]);
		mix(&digest, ro_freed ^ remove_body_xpmem_count);

		remove_vm.vm_range_tree = (struct fake_rb_root){ 0 };
		struct fake_vm_range remove_straight = {
			.start = 0x6000,
			.end = 0xa000,
			.flag = VR_PROT_WRITE,
			.straight_start = 0x102000,
		};
		struct fake_vm_range remove_converted_mid = {
			.start = 0x6800,
			.end = 0xa000,
			.flag = VR_PROT_WRITE,
			.straight_start = 0x102800,
		};
		require(process_vm_range_insert_result(&remove_vm.vm_range_tree,
			&remove_straight, &remove_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		remove_body_split_replacement = &remove_converted_mid;
		ro_freed = 99;
		rc = process_remove_memory_range_body_result(&remove_vm,
			0x102800, 0x103800, &ro_freed, 0x100000,
			0x80000, fake_remove_body_split,
			fake_remove_body_xpmem, fake_remove_body_free,
			fake_remove_body_log);
		require(rc == 0);
		require(remove_body_log_count == 2);
		require(remove_body_log_event[0] ==
			PROCESS_REMOVE_RANGE_LOG_CONVERTED);
		require(remove_body_log_start[0] == 0x6800);
		require(remove_body_log_end[0] == 0x7800);
		require(remove_body_split_count == 2);
		require(remove_body_split_addr[0] == 0x6800);
		require(remove_body_split_addr[1] == 0x7800);
		require(remove_body_free_range[0] == &remove_converted_mid);
		require(ro_freed == 0);
		mix(&digest, remove_body_log_start[0] ^
			remove_body_log_end[0]);

		remove_vm.vm_range_tree = (struct fake_rb_root){ 0 };
		struct fake_vm_range no_straight = {
			.start = 0x6000,
			.end = 0xa000,
			.flag = VR_PROT_WRITE,
		};
		require(process_vm_range_insert_result(&remove_vm.vm_range_tree,
			&no_straight, &remove_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		ro_freed = 77;
		rc = process_remove_memory_range_body_result(&remove_vm,
			0x102800, 0x103800, &ro_freed, 0x100000,
			0x80000, fake_remove_body_split,
			fake_remove_body_xpmem, fake_remove_body_free,
			fake_remove_body_log);
		require(rc == 0);
		require(ro_freed == 77);
		require(remove_body_log_count == 1);
		require(remove_body_log_event[0] ==
			PROCESS_REMOVE_RANGE_LOG_NO_STRAIGHT);
		require(remove_body_free_count == 0);
		mix(&digest, remove_body_log_event[0]);

		remove_vm.vm_range_tree = (struct fake_rb_root){ 0 };
		remove_whole.vm_rb_node = (struct fake_rb_node){ 0 };
		require(process_vm_range_insert_result(&remove_vm.vm_range_tree,
			&remove_whole, &remove_vm, NULL, NULL) == 0);
		reset_range_body_trace();
		remove_body_split_rc = -88;
		remove_body_split_replacement = &remove_middle;
		rc = process_remove_memory_range_body_result(&remove_vm,
			0x2000, 0x4000, &ro_freed, 0, 0,
			fake_remove_body_split, fake_remove_body_xpmem,
			fake_remove_body_free, fake_remove_body_log);
		require(rc == -88);
		require(remove_body_log_count == 1);
		require(remove_body_log_event[0] ==
			PROCESS_REMOVE_RANGE_LOG_SPLIT_FAILED);
		require(remove_body_log_error[0] == -88);
		require(remove_body_free_count == 0);
		mix(&digest, (unsigned long)(unsigned int)-rc);

		reset_range_body_trace();
		remove_region_clear_rc = -99;
		rc = process_remove_region_body_result(&free_vm, 0x8000,
			0xa000, fake_free_body_lock, fake_free_body_unlock,
			fake_remove_region_clear, fake_remove_region_log);
		require(rc == 0);
		require(free_body_lock_count == 1);
		require(free_body_unlock_count == 1);
		require(free_body_lock_addr ==
			(unsigned long)(uintptr_t)&free_vm.page_table_lock);
		require(remove_region_clear_count == 1);
		require(remove_region_clear_page_table == free_as.page_table);
		require(remove_region_clear_vm == &free_vm);
		require(remove_region_clear_start == 0x8000);
		require(remove_region_clear_end == 0xa000);
		require(remove_region_log_count == 1);
		require(remove_region_log_start == 0x8000);
		require(remove_region_log_end == 0xa000);
		mix(&digest, remove_region_clear_start ^
			remove_region_clear_end);

		reset_range_body_trace();
		rc = process_remove_region_body_result(&free_vm, 0x8001,
			0xa000, fake_free_body_lock, fake_free_body_unlock,
			fake_remove_region_clear, fake_remove_region_log);
		require(rc == -22);
		require(remove_region_clear_count == 0);
		require(remove_region_log_count == 0);
		mix(&digest, (unsigned long)(unsigned int)-rc);
	}
	mix(&digest, process_ref_release_should_destroy_result(0));
	mix(&digest, process_ref_release_should_destroy_result(1));
	mix(&digest, process_release_address_space_should_destroy_result(0));
	mix(&digest, process_release_address_space_should_destroy_result(1));
	mix(&digest, process_release_address_space_should_run_free_cb_result(0));
	mix(&digest, process_release_address_space_should_run_free_cb_result(0x4000));
	{
		struct fake_release_address_space {
			void *page_table;
			void *opt;
			void (*free_cb)(void *, void *);
			int refcount;
			unsigned long cpu_set[2];
			unsigned int cpu_set_lock;
			int nslots;
			int pids[4];
		} rel_as = {
			.page_table = (void *)0xabcddcbaUL,
			.opt = (void *)0x76543210UL,
			.free_cb = fake_address_space_free_cb,
			.refcount = 1,
			.nslots = 4,
			.pids = { 11, 22, 33, 44 },
		};

		reset_process_release_trace();
		mix(&digest, process_release_address_space_body_result(
			&rel_as,
			offsetof(struct fake_release_address_space, refcount),
			offsetof(struct fake_release_address_space, free_cb),
			offsetof(struct fake_release_address_space, opt),
			offsetof(struct fake_release_address_space, page_table),
			fake_ref_dec_and_test, fake_address_space_pt_destroy,
			fake_optional_free));
		require(process_ref_dec_count == 1);
		require(process_as_free_cb_count == 1);
		require(process_as_free_cb_asp == &rel_as);
		require(process_as_free_cb_opt == (void *)0x76543210UL);
		require(process_as_pt_destroy_count == 1);
		require(process_as_pt_destroy_page_table ==
			(void *)0xabcddcbaUL);
		require(process_optional_free_count == 1);
		require(process_optional_free_xor == (unsigned long)&rel_as);
		mix(&digest, process_as_free_cb_count ^
			process_as_pt_destroy_count);

		rel_as.refcount = 0;
		rel_as.free_cb = NULL;
		reset_process_release_trace();
		mix(&digest, process_release_address_space_body_result(
			&rel_as,
			offsetof(struct fake_release_address_space, refcount),
			offsetof(struct fake_release_address_space, free_cb),
			offsetof(struct fake_release_address_space, opt),
			offsetof(struct fake_release_address_space, page_table),
			fake_ref_dec_and_test, fake_address_space_pt_destroy,
			fake_optional_free));
		require(process_ref_dec_count == 1);
		require(process_as_free_cb_count == 0);
		require(process_as_pt_destroy_count == 0);
		require(process_optional_free_count == 0);

		reset_process_release_trace();
		mix(&digest, process_detach_address_space_body_result(
			&rel_as, 33,
			offsetof(struct fake_release_address_space, pids),
			offsetof(struct fake_release_address_space, nslots),
			fake_address_space_release));
		require(rel_as.pids[2] == 0);
		require(rel_as.pids[1] == 22);
		require(process_as_release_count == 1);
		require(process_as_release_asp == &rel_as);
		mix(&digest, rel_as.pids[2] ^ process_as_release_count);

		rel_as.refcount = 4;
		reset_process_release_trace();
		mix(&digest, process_hold_address_space_public_result(&rel_as,
			offsetof(struct fake_release_address_space, refcount),
			fake_ref_inc));
		require(rel_as.refcount == 5);
		require(process_ref_inc_count == 1);
		require(process_ref_inc_object == &rel_as);

		rel_as.refcount = 1;
		rel_as.free_cb = fake_address_space_free_cb;
		reset_process_release_trace();
		mix(&digest, process_release_address_space_public_result(
			&rel_as,
			offsetof(struct fake_release_address_space, refcount),
			offsetof(struct fake_release_address_space, free_cb),
			offsetof(struct fake_release_address_space, opt),
			offsetof(struct fake_release_address_space, page_table),
			fake_ref_dec_and_test, fake_address_space_pt_destroy,
			fake_optional_free));
		require(process_ref_dec_count == 1);
		require(process_as_free_cb_count == 1);
		require(process_as_pt_destroy_count == 1);
		require(process_optional_free_count == 1);

		rel_as.pids[0] = 55;
		rel_as.pids[1] = 66;
		rel_as.pids[2] = 77;
		rel_as.pids[3] = 88;
		reset_process_release_trace();
		mix(&digest, process_detach_address_space_public_result(
			&rel_as, 66,
			offsetof(struct fake_release_address_space, pids),
			offsetof(struct fake_release_address_space, nslots),
			fake_address_space_release));
		require(rel_as.pids[1] == 0);
		require(process_as_release_count == 1);
		require(process_as_release_asp == &rel_as);
		mix(&digest, rel_as.pids[1] ^ process_as_release_count);

		reset_process_release_trace();
		memset(process_as_alloc_space, 0xa5,
		       sizeof(process_as_alloc_space));
		void *created = process_create_address_space_body_result(
			4, offsetof(struct fake_release_address_space, pids),
			sizeof(int), 0x44,
			offsetof(struct fake_release_address_space, page_table),
			offsetof(struct fake_release_address_space, refcount),
			offsetof(struct fake_release_address_space, cpu_set),
			sizeof(rel_as.cpu_set),
			offsetof(struct fake_release_address_space, cpu_set_lock),
			offsetof(struct fake_release_address_space, nslots),
			fake_address_space_alloc, fake_optional_free,
			fake_address_space_pt_create, fake_ref_set,
			fake_spin_init);
		struct fake_release_address_space *created_as = created;
		require(created == process_as_alloc_space);
		require(process_as_alloc_count == 1);
		require(process_as_alloc_size ==
			offsetof(struct fake_release_address_space, pids) +
			4 * sizeof(int));
		require(process_as_alloc_flags == 0x44);
		require(process_as_pt_create_count == 1);
		require(process_as_pt_create_flags == 0x44);
		require(created_as->page_table == (void *)0xabcdef000UL);
		require(created_as->refcount == 1);
		require(created_as->nslots == 4);
		require(created_as->opt == NULL);
		require(created_as->free_cb == NULL);
		require(created_as->cpu_set[0] == 0);
		require(created_as->cpu_set[1] == 0);
		require(created_as->pids[3] == 0);
		require(process_as_ref_set_count == 1);
		require(process_as_ref_set_object == created);
		require(process_as_spin_init_count == 1);
		require(process_as_spin_init_addr ==
			(unsigned long)(uintptr_t)&created_as->cpu_set_lock);
		require(created_as->cpu_set_lock == 0x13572468U);
		mix(&digest, process_as_alloc_size);
		mix(&digest, (unsigned long)(uintptr_t)created_as->page_table);

		reset_process_release_trace();
		process_as_pt_create_fail = 1;
		created = process_create_address_space_body_result(
			2, offsetof(struct fake_release_address_space, pids),
			sizeof(int), 0x55,
			offsetof(struct fake_release_address_space, page_table),
			offsetof(struct fake_release_address_space, refcount),
			offsetof(struct fake_release_address_space, cpu_set),
			sizeof(rel_as.cpu_set),
			offsetof(struct fake_release_address_space, cpu_set_lock),
			offsetof(struct fake_release_address_space, nslots),
			fake_address_space_alloc, fake_optional_free,
			fake_address_space_pt_create, fake_ref_set,
			fake_spin_init);
		require(created == NULL);
		require(process_as_alloc_count == 1);
		require(process_as_pt_create_count == 1);
		require(process_optional_free_count == 1);
		require(process_optional_free_xor ==
			(unsigned long)(uintptr_t)process_as_alloc_space);
	}
	mix(&digest, process_create_cpu_allowed_result(0, 4));
	mix(&digest, process_create_cpu_allowed_result(4, 4));
	mix(&digest, process_create_cpu_allowed_result(-1, 4));
	mix(&digest, process_create_use_default_cpu_set_result(0));
	mix(&digest, process_create_use_default_cpu_set_result(1));
	{
		unsigned long requested[1] = { (1UL << 1) | (1UL << 3) };
		unsigned long thread_set[2] = { 0 };
		unsigned long proc_set[2] = { 0 };

		reset_process_release_trace();
		process_default_ncpus_value = 5;
		mix(&digest, process_create_cpu_sets_body_result(
			(unsigned long)(uintptr_t)requested, 64,
			(unsigned long)(uintptr_t)thread_set,
			(unsigned long)(uintptr_t)proc_set, 128, 8, 77,
			fake_default_ncpus, fake_create_cpu_log));
		require(thread_set[0] == ((1UL << 1) | (1UL << 3)));
		require(proc_set[0] == thread_set[0]);
		require(process_default_ncpus_count == 0);
		require(process_create_cpu_log_count == 2);
		require(process_create_cpu_requested_count == 2);
		require(process_create_cpu_requested_mask ==
			((1UL << 1) | (1UL << 3)));
		require(process_create_cpu_last_pid == 77);
		mix(&digest, thread_set[0]);
		mix(&digest, process_create_cpu_requested_mask);

		requested[0] = 0;
		thread_set[0] = 0;
		proc_set[0] = 0;
		reset_process_release_trace();
		process_default_ncpus_value = 3;
		mix(&digest, process_create_cpu_sets_body_result(
			(unsigned long)(uintptr_t)requested, 64,
			(unsigned long)(uintptr_t)thread_set,
			(unsigned long)(uintptr_t)proc_set, 128, 8, 78,
			fake_default_ncpus, fake_create_cpu_log));
		require(thread_set[0] == ((1UL << 0) | (1UL << 1) |
					  (1UL << 2)));
		require(proc_set[0] == thread_set[0]);
		require(process_default_ncpus_count == 1);
		require(process_create_cpu_log_count == 0);
		mix(&digest, thread_set[0]);
		mix(&digest, process_default_ncpus_count);

		requested[0] = (1UL << 2) | (1UL << 5);
		thread_set[0] = 0;
		proc_set[0] = 0;
		reset_process_release_trace();
		mix(&digest, process_create_cpu_sets_body_result(
			(unsigned long)(uintptr_t)requested, 64,
			(unsigned long)(uintptr_t)thread_set,
			(unsigned long)(uintptr_t)proc_set, 128, 4, 79,
			fake_default_ncpus, fake_create_cpu_log));
		require(thread_set[0] == (1UL << 2));
		require(proc_set[0] == thread_set[0]);
		require(process_create_cpu_invalid_count == 1);
		require(process_create_cpu_requested_count == 1);
		require(process_create_cpu_last_pid == 79);
		require(process_create_cpu_last_cpu == 5);
		mix(&digest, process_create_cpu_invalid_count);
		mix(&digest, process_create_cpu_last_cpu);
	}
	{
		struct fake_allocated_object {
			unsigned int prefix;
			unsigned long body;
			unsigned char tail[5];
		} zero_obj = {
			.prefix = 0xaabbccddU,
			.body = 0xfeedfaceUL,
			.tail = { 1, 2, 3, 4, 5 },
		};
		unsigned char zero_check[sizeof(zero_obj)] = { 0 };

		mix(&digest, process_allocated_object_zero_body_result(
			&zero_obj, sizeof(zero_obj)));
		require(!memcmp(&zero_obj, zero_check, sizeof(zero_obj)));
		mix(&digest, zero_obj.prefix);
		mix(&digest, process_allocated_object_zero_body_result(
			NULL, sizeof(zero_obj)));
	}
	{
		struct fake_address_space as = { 0 };
		struct fake_process parent = { 0 };
		struct fake_process_vm_full vm;

		memset(&vm, 0xa5, sizeof(vm));
		reset_process_release_trace();
		mix(&digest, process_vm_init_body_result(
			&vm, &parent, &as, 3, fake_rwlock_init,
			fake_spin_init, fake_vm_init_numa_log));
		require(vm.address_space == &as);
		require(vm.proc == &parent);
		require(vm.vm_range_tree.rb_node == NULL);
		require(vm.vm_range_numa_policy_tree.rb_node == NULL);
		require(vm.page_table_lock == 0x13572468U);
		require(vm.memory_range_lock == (int)0x2468ace0U);
		require(vm.refcount == 1);
		require(vm.exiting == 0);
		require(vm.numa_mask[0] == 0x7UL);
		require(vm.numa_mask[1] == 0);
		require(vm.numa_mask[2] == 0);
		require(vm.numa_mask[3] == 0);
		require(vm.numa_mem_policy == 0);
		require(vm.range_cache[0] == NULL);
		require(vm.range_cache[3] == NULL);
		require(vm.range_cache_ind == 0);
		require(process_rwlock_init_count == 1);
		require(process_rwlock_init_addr ==
			(unsigned long)(uintptr_t)&vm.memory_range_lock);
		require(process_as_spin_init_count == 1);
		require(process_as_spin_init_addr ==
			(unsigned long)(uintptr_t)&vm.page_table_lock);
		require(process_vm_init_numa_log_count == 0);
		mix(&digest, vm.numa_mask[0]);
		mix(&digest, vm.refcount);

		memset(&vm, 0xa5, sizeof(vm));
		reset_process_release_trace();
		mix(&digest, process_vm_init_body_result(
			&vm, &parent, &as, 260, fake_rwlock_init,
			fake_spin_init, fake_vm_init_numa_log));
		require(vm.numa_mask[0] == ~0UL);
		require(vm.numa_mask[1] == ~0UL);
		require(vm.numa_mask[2] == ~0UL);
		require(vm.numa_mask[3] == ~0UL);
		require(process_vm_init_numa_log_count == 1);
		require(process_vm_init_numa_log_id == 256);
		mix(&digest, process_vm_init_numa_log_id);
		mix(&digest, process_vm_init_body_result(
			NULL, &parent, &as, 1, fake_rwlock_init,
			fake_spin_init, fake_vm_init_numa_log));
	}
	{
		void *res;
		struct fake_list_head *pid1_hash;
		struct fake_list_head *bucket;
		struct fake_list_head *phys_mem_list;

		reset_boot_init_trace();
		reset_process_release_trace();
		res = process_new_resource_set_body_result(
			PROCESS_ABI_RESOURCE_SIZE, PROCESS_ABI_PROCESS_HASH_SIZE,
			PROCESS_ABI_THREAD_HASH_SIZE, PROCESS_ABI_PROCESS_SIZE,
			IHK_MC_AP_NOWAIT, PROCESS_ABI_HASH_SIZE, 1,
			fake_boot_alloc, fake_boot_free,
			fake_boot_init_process, fake_rwlock_init);
		require(res == boot_resource_store);
		require(boot_alloc_count == 4);
		require(boot_alloc_size[0] == PROCESS_ABI_RESOURCE_SIZE);
		require(boot_alloc_size[1] == PROCESS_ABI_PROCESS_HASH_SIZE);
		require(boot_alloc_size[2] == PROCESS_ABI_THREAD_HASH_SIZE);
		require(boot_alloc_size[3] == PROCESS_ABI_PROCESS_SIZE);
		require(boot_alloc_flags[0] == IHK_MC_AP_NOWAIT);
		require(boot_free_count == 0);
		require(boot_init_process_count == 1);
		require(boot_init_process_last_proc == boot_pid1_store);
		require(boot_init_process_last_parent == boot_pid1_store);
		require(*(void **)(boot_resource_store +
			PROCESS_ABI_RESOURCE_PHASH_OFF) == boot_phash_store);
		require(*(void **)(boot_resource_store +
			PROCESS_ABI_RESOURCE_THASH_OFF) == boot_thash_store);
		require(*(void **)(boot_resource_store +
			PROCESS_ABI_RESOURCE_PID1_OFF) == boot_pid1_store);
		require(*(int *)(boot_pid1_store +
			PROCESS_ABI_PROCESS_PID_OFF) == 1);
		phys_mem_list = (struct fake_list_head *)(boot_resource_store +
			PROCESS_ABI_RESOURCE_PHYSMEM_LIST_OFF);
		require(phys_mem_list->next == phys_mem_list);
		require(phys_mem_list->prev == phys_mem_list);
		require(*(unsigned int *)(boot_resource_store +
			PROCESS_ABI_RESOURCE_PHYSMEM_LOCK_OFF) == 0x2468ace0U);
		require(*(unsigned int *)(boot_resource_store +
			PROCESS_ABI_RESOURCE_CPU_SET_LOCK_OFF) == 0x2468ace0U);
		bucket = (struct fake_list_head *)(boot_phash_store +
			sizeof(struct fake_list_head));
		pid1_hash = (struct fake_list_head *)boot_pid1_store;
		require(bucket->next == pid1_hash);
		require(bucket->prev == pid1_hash);
		require(pid1_hash->next == bucket);
		require(pid1_hash->prev == bucket);
		require(process_rwlock_init_count ==
			2 + PROCESS_ABI_HASH_SIZE * 2);
			mix(&digest, res == boot_resource_store);
		mix(&digest, boot_alloc_count);
		mix(&digest, process_rwlock_init_count);
		mix(&digest, *(int *)(boot_pid1_store +
			PROCESS_ABI_PROCESS_PID_OFF));

		reset_boot_init_trace();
		reset_process_release_trace();
		boot_alloc_fail_at = 3;
		res = process_new_resource_set_body_result(
			PROCESS_ABI_RESOURCE_SIZE, PROCESS_ABI_PROCESS_HASH_SIZE,
			PROCESS_ABI_THREAD_HASH_SIZE, PROCESS_ABI_PROCESS_SIZE,
			IHK_MC_AP_NOWAIT, PROCESS_ABI_HASH_SIZE, 1,
			fake_boot_alloc, fake_boot_free,
			fake_boot_init_process, fake_rwlock_init);
		require(res == NULL);
		require(boot_free_count == 3);
		require(boot_init_process_count == 0);
		mix(&digest, boot_free_count);

		reset_boot_init_trace();
		reset_process_release_trace();
		res = process_new_resource_set_body_result(
			PROCESS_ABI_RESOURCE_SIZE, PROCESS_ABI_PROCESS_HASH_SIZE,
			PROCESS_ABI_THREAD_HASH_SIZE, PROCESS_ABI_PROCESS_SIZE,
			IHK_MC_AP_NOWAIT, PROCESS_ABI_HASH_SIZE, 1,
			fake_boot_alloc, fake_boot_free,
			fake_boot_init_process, fake_rwlock_init);
		mix(&digest, process_proc_init_body_result(
			res, &boot_resource_list,
			(unsigned long)(uintptr_t)(boot_resource_store +
				PROCESS_ABI_RESOURCE_CPU_SET_LOCK_OFF),
			4, 128, sizeof(boot_path_store), IHK_MC_AP_NOWAIT,
			fake_boot_alloc, fake_rwlock_init));
		require(*(void **)(boot_resource_store +
			PROCESS_ABI_RESOURCE_PATH_OFF) == boot_path_store);
		require(boot_path_store[0] == '\0');
		require(*(unsigned long *)(boot_resource_store +
			PROCESS_ABI_RESOURCE_CPU_SET_OFF) == 0xfUL);
		require(boot_resource_list.next ==
			(void *)(boot_resource_store + PROCESS_ABI_RESOURCE_LIST_OFF));
		require(boot_resource_list.prev == boot_resource_list.next);
		require(((struct fake_list_head *)boot_resource_store)->next ==
			&boot_resource_list);
		require(((struct fake_list_head *)boot_resource_store)->prev ==
			&boot_resource_list);
		mix(&digest, *(unsigned long *)(boot_resource_store +
			PROCESS_ABI_RESOURCE_CPU_SET_OFF));
		mix(&digest, boot_alloc_count);

		reset_boot_init_trace();
		reset_process_release_trace();
		res = process_new_resource_set_body_result(
			PROCESS_ABI_RESOURCE_SIZE, PROCESS_ABI_PROCESS_HASH_SIZE,
			PROCESS_ABI_THREAD_HASH_SIZE, PROCESS_ABI_PROCESS_SIZE,
			IHK_MC_AP_NOWAIT, PROCESS_ABI_HASH_SIZE, 1,
			fake_boot_alloc, fake_boot_free,
			fake_boot_init_process, fake_rwlock_init);
		require(process_proc_init_body_result(
			res, &boot_resource_list,
			(unsigned long)(uintptr_t)(boot_resource_store +
				PROCESS_ABI_RESOURCE_CPU_SET_LOCK_OFF),
			2, 128, sizeof(boot_path_store), IHK_MC_AP_NOWAIT,
			fake_boot_alloc, fake_rwlock_init) == 0);
		{
			void *idle_thread;
			void *idle_vm;
			void *idle_proc;
			void *idle_asp;
			struct fake_list_head *children;
			struct fake_list_head *siblings;
			int boot_sched_rc = process_sched_init_body_result(
				(unsigned long)(uintptr_t)boot_cpu_local_store,
				&boot_resource_list, 7, fake_boot_init_process,
				fake_rwlock_init, fake_spin_init,
				fake_boot_init_context, fake_boot_save_fp,
				fake_boot_timer_init);

			mix(&digest, boot_sched_rc);
			require(boot_sched_rc == 0);
			require(boot_cpu_local_contains_ptr(res));
			require(boot_context_count == 1);
			require(boot_save_fp_count == 1);
			require(boot_save_fp_thread == boot_context_thread);
			require(boot_timer_count == 1);
			require(boot_timer_cpu == 7);
			require(boot_init_process_count == 2);
			require(process_as_spin_init_count == 2);
			require(boot_cpu_local_count_u32(0x13572468U) >= 2);
			require(boot_cpu_local_count_self_lists() >= 2);

			idle_thread = boot_context_thread;
			require(boot_cpu_local_covers(idle_thread,
				PROCESS_ABI_THREAD_SIZE));
			idle_vm = *(void **)((char *)idle_thread +
				PROCESS_ABI_THREAD_VM_OFF);
			idle_proc = *(void **)((char *)idle_thread +
				PROCESS_ABI_THREAD_PROC_OFF);
			require(boot_cpu_local_covers(idle_vm,
				PROCESS_ABI_VM_SIZE));
			require(boot_cpu_local_covers(idle_proc,
				PROCESS_ABI_PROCESS_SIZE));
			idle_asp = *(void **)((char *)idle_vm +
				PROCESS_ABI_VM_ADDRESS_SPACE_OFF);
			require(boot_cpu_local_covers(idle_asp,
				sizeof(void *)));
			require(*(void **)((char *)idle_proc +
				PROCESS_ABI_PROCESS_VM_OFF) == idle_vm);
			require(*(int *)((char *)idle_proc +
				PROCESS_ABI_PROCESS_PID_OFF) == 0);
			require(*(int *)((char *)idle_proc +
				PROCESS_ABI_PROCESS_NOHOST_OFF) == 1);
			require(*(int *)((char *)idle_thread +
				PROCESS_ABI_THREAD_TID_OFF) == 7);
			require(*(unsigned int *)((char *)idle_vm +
				PROCESS_ABI_VM_MEMORY_LOCK_OFF) ==
				0x2468ace0U);
			require(*(unsigned long *)((char *)idle_thread +
				PROCESS_ABI_THREAD_CTX_OFF) ==
				0xabcdef0123456789UL);
			children = (struct fake_list_head *)((char *)idle_proc +
				PROCESS_ABI_PROCESS_CHILDREN_LIST_OFF);
			siblings = (struct fake_list_head *)((char *)idle_thread +
				PROCESS_ABI_THREAD_SIBLINGS_LIST_OFF);
			require(children->next == siblings);
			require(children->prev == siblings);
			require(siblings->next == children);
			require(siblings->prev == children);
			mix(&digest, boot_context_count);
			mix(&digest, boot_save_fp_count);
			mix(&digest, boot_timer_cpu);
			mix(&digest, *(int *)((char *)idle_thread +
				PROCESS_ABI_THREAD_TID_OFF));
		}
	}
	{
		struct fake_process_init_state {
			int pid;
			int status;
			void *parent;
			void *ppid_parent;
			int pgid;
			int ruid;
			int euid;
			int suid;
			int fsuid;
			int rgid;
			int egid;
			int sgid;
			int fsgid;
			unsigned long mpol_flags;
			unsigned long mpol_threshold;
			int thp_disable;
			unsigned char rlimit[32];
			unsigned long cpu_set[4];
			int enable_uti;
		} child, parent;
		struct process_init_state_offsets offsets = {
			.pid_offset =
				offsetof(struct fake_process_init_state, pid),
			.status_offset =
				offsetof(struct fake_process_init_state, status),
			.parent_offset =
				offsetof(struct fake_process_init_state, parent),
			.ppid_parent_offset =
				offsetof(struct fake_process_init_state, ppid_parent),
			.pgid_offset =
				offsetof(struct fake_process_init_state, pgid),
			.ruid_offset =
				offsetof(struct fake_process_init_state, ruid),
			.euid_offset =
				offsetof(struct fake_process_init_state, euid),
			.suid_offset =
				offsetof(struct fake_process_init_state, suid),
			.fsuid_offset =
				offsetof(struct fake_process_init_state, fsuid),
			.rgid_offset =
				offsetof(struct fake_process_init_state, rgid),
			.egid_offset =
				offsetof(struct fake_process_init_state, egid),
			.sgid_offset =
				offsetof(struct fake_process_init_state, sgid),
			.fsgid_offset =
				offsetof(struct fake_process_init_state, fsgid),
			.mpol_flags_offset =
				offsetof(struct fake_process_init_state, mpol_flags),
			.mpol_threshold_offset =
				offsetof(struct fake_process_init_state,
					 mpol_threshold),
			.thp_disable_offset =
				offsetof(struct fake_process_init_state, thp_disable),
			.rlimit_offset =
				offsetof(struct fake_process_init_state, rlimit),
			.rlimit_size =
				sizeof(((struct fake_process_init_state *)0)->rlimit),
			.cpu_set_offset =
				offsetof(struct fake_process_init_state, cpu_set),
			.cpu_set_size =
				sizeof(((struct fake_process_init_state *)0)->cpu_set),
			.enable_uti_offset =
				offsetof(struct fake_process_init_state, enable_uti),
		};
		size_t i;

		memset(&child, 0xa5, sizeof(child));
		memset(&parent, 0, sizeof(parent));
		parent.pid = 300;
		parent.status = 301;
		parent.pgid = 302;
		parent.ruid = 303;
		parent.euid = 304;
		parent.suid = 305;
		parent.fsuid = 306;
		parent.rgid = 307;
		parent.egid = 308;
		parent.sgid = 309;
		parent.fsgid = 310;
		parent.mpol_flags = 0x10203040UL;
		parent.mpol_threshold = 0x50607080UL;
		parent.thp_disable = 1;
		for (i = 0; i < sizeof(parent.rlimit); ++i)
			parent.rlimit[i] = (unsigned char)(0x40 + i);
		parent.cpu_set[0] = 0x1001UL;
		parent.cpu_set[1] = 0x2002UL;
		parent.cpu_set[2] = 0x3003UL;
		parent.cpu_set[3] = 0x4004UL;
		parent.enable_uti = 17;

		mix(&digest, process_init_state_body_result(
			&child, &parent, &offsets, -9, 0x55));
		require(child.pid == -9);
		require(child.status == 0x55);
		require(child.parent == &parent);
		require(child.ppid_parent == &parent);
		require(child.pgid == parent.pgid);
		require(child.ruid == parent.ruid);
		require(child.euid == parent.euid);
		require(child.suid == parent.suid);
		require(child.fsuid == parent.fsuid);
		require(child.rgid == parent.rgid);
		require(child.egid == parent.egid);
		require(child.sgid == parent.sgid);
		require(child.fsgid == parent.fsgid);
		require(child.mpol_flags == parent.mpol_flags);
		require(child.mpol_threshold == parent.mpol_threshold);
		require(child.thp_disable == parent.thp_disable);
		require(!memcmp(child.rlimit, parent.rlimit,
			sizeof(child.rlimit)));
		require(!memcmp(child.cpu_set, parent.cpu_set,
			sizeof(child.cpu_set)));
		require(child.enable_uti == parent.enable_uti);
		mix(&digest, child.pid);
		mix(&digest, child.status);
		mix(&digest, child.pgid);
		mix(&digest, child.cpu_set[3]);

		memset(&child, 0, sizeof(child));
		child.parent = (void *)0x1111UL;
		child.ppid_parent = (void *)0x2222UL;
		child.pgid = 333;
		child.cpu_set[0] = 0x9999UL;
		mix(&digest, process_init_state_body_result(
			&child, NULL, &offsets, -7, 0x66));
		require(child.pid == -7);
		require(child.status == 0x66);
		require(child.parent == (void *)0x1111UL);
		require(child.ppid_parent == (void *)0x2222UL);
		require(child.pgid == 333);
		require(child.cpu_set[0] == 0x9999UL);
		mix(&digest, child.pid);
		mix(&digest, child.status);
		mix(&digest, process_init_state_body_result(
			NULL, &parent, &offsets, -1, 1));
		mix(&digest, process_init_state_body_result(
			&child, &parent, NULL, -1, 1));
	}
	{
		struct fake_process_links {
			struct fake_list_head hash_list;
			struct fake_list_head siblings_list;
			struct fake_list_head ptraced_siblings_list;
			unsigned int update_lock;
			struct fake_list_head report_threads_list;
			struct fake_list_head threads_list;
			struct fake_list_head children_list;
			struct fake_list_head ptraced_children_list;
			unsigned int threads_lock;
			unsigned int children_lock;
			unsigned int coredump_lock;
			unsigned int mckfd_lock;
			unsigned int waitpid_q;
			int refcount;
			void *monitoring_event;
		} links;

		memset(&links, 0xa5, sizeof(links));
		links.monitoring_event = (void *)0x1234UL;
		reset_process_release_trace();
		mix(&digest, process_init_links_body_result(
			&links,
			offsetof(struct fake_process_links, hash_list),
			offsetof(struct fake_process_links, siblings_list),
			offsetof(struct fake_process_links, ptraced_siblings_list),
			offsetof(struct fake_process_links, update_lock),
			offsetof(struct fake_process_links, report_threads_list),
			offsetof(struct fake_process_links, threads_list),
			offsetof(struct fake_process_links, children_list),
			offsetof(struct fake_process_links, ptraced_children_list),
			offsetof(struct fake_process_links, threads_lock),
			offsetof(struct fake_process_links, children_lock),
			offsetof(struct fake_process_links, coredump_lock),
			offsetof(struct fake_process_links, mckfd_lock),
			offsetof(struct fake_process_links, waitpid_q),
			offsetof(struct fake_process_links, refcount),
			offsetof(struct fake_process_links, monitoring_event),
			fake_rwlock_init, fake_spin_init, fake_waitq_init,
			fake_ref_set));
		require(links.hash_list.next == &links.hash_list);
		require(links.hash_list.prev == &links.hash_list);
		require(links.siblings_list.next == &links.siblings_list);
		require(links.siblings_list.prev == &links.siblings_list);
		require(links.ptraced_siblings_list.next ==
			&links.ptraced_siblings_list);
		require(links.ptraced_siblings_list.prev ==
			&links.ptraced_siblings_list);
		require(links.report_threads_list.next ==
			&links.report_threads_list);
		require(links.report_threads_list.prev ==
			&links.report_threads_list);
		require(links.threads_list.next == &links.threads_list);
		require(links.threads_list.prev == &links.threads_list);
		require(links.children_list.next == &links.children_list);
		require(links.children_list.prev == &links.children_list);
		require(links.ptraced_children_list.next ==
			&links.ptraced_children_list);
		require(links.ptraced_children_list.prev ==
			&links.ptraced_children_list);
		require(links.update_lock == 0x2468ace0U);
		require(links.threads_lock == 0x2468ace0U);
		require(links.children_lock == 0x2468ace0U);
		require(links.coredump_lock == 0x2468ace0U);
		require(links.mckfd_lock == 0x13572468U);
		require(links.waitpid_q == 0x55aa33ccU);
		require(links.refcount == 2);
		require(links.monitoring_event == NULL);
		require(process_rwlock_init_count == 4);
		require(process_rwlock_init_addr ==
			(unsigned long)(uintptr_t)&links.coredump_lock);
		require(process_as_spin_init_count == 1);
		require(process_as_spin_init_addr ==
			(unsigned long)(uintptr_t)&links.mckfd_lock);
		require(process_waitq_init_count == 1);
		require(process_waitq_init_addr ==
			(unsigned long)(uintptr_t)&links.waitpid_q);
		require(process_as_ref_set_count == 1);
		require(process_as_ref_set_object == &links);
		require(process_as_ref_set_value == 2);
		mix(&digest, links.refcount);
		mix(&digest, links.update_lock);
		mix(&digest, links.mckfd_lock);
		mix(&digest, links.waitpid_q);
		mix(&digest, process_rwlock_init_count);
		mix(&digest, process_waitq_init_count);
		mix(&digest, process_init_links_body_result(
			NULL,
			offsetof(struct fake_process_links, hash_list),
			offsetof(struct fake_process_links, siblings_list),
			offsetof(struct fake_process_links, ptraced_siblings_list),
			offsetof(struct fake_process_links, update_lock),
			offsetof(struct fake_process_links, report_threads_list),
			offsetof(struct fake_process_links, threads_list),
			offsetof(struct fake_process_links, children_list),
			offsetof(struct fake_process_links, ptraced_children_list),
			offsetof(struct fake_process_links, threads_lock),
			offsetof(struct fake_process_links, children_lock),
			offsetof(struct fake_process_links, coredump_lock),
			offsetof(struct fake_process_links, mckfd_lock),
			offsetof(struct fake_process_links, waitpid_q),
			offsetof(struct fake_process_links, refcount),
			offsetof(struct fake_process_links, monitoring_event),
			fake_rwlock_init, fake_spin_init, fake_waitq_init,
			fake_ref_set));
	}
	{
		struct fake_process_profile {
			unsigned int profile_lock;
			void *profile_events;
		} profile;

		memset(&profile, 0xa5, sizeof(profile));
		profile.profile_events = (void *)0x4444UL;
		reset_process_release_trace();
		mix(&digest, process_init_profile_body_result(
			&profile,
			offsetof(struct fake_process_profile, profile_lock),
			offsetof(struct fake_process_profile, profile_events),
			fake_mcs_lock_init));
		require(profile.profile_lock == 0x0badc0deU);
		require(profile.profile_events == NULL);
		require(process_mcs_lock_init_count == 1);
		require(process_mcs_lock_init_addr ==
			(unsigned long)(uintptr_t)&profile.profile_lock);
		mix(&digest, profile.profile_lock);
		mix(&digest, process_mcs_lock_init_count);
		mix(&digest, process_init_profile_body_result(
			NULL,
			offsetof(struct fake_process_profile, profile_lock),
			offsetof(struct fake_process_profile, profile_events),
			fake_mcs_lock_init));
		mix(&digest, process_init_profile_body_result(
			&profile,
			offsetof(struct fake_process_profile, profile_lock),
			offsetof(struct fake_process_profile, profile_events),
			NULL));
	}
	{
		struct fake_clone_thread_state {
			unsigned long pad0;
			unsigned long cpu_set[4];
			int in_kernel;
			int sched_policy;
			struct {
				int sched_priority;
			} sched_param;
			unsigned long guard;
		} dst, src;

		memset(&dst, 0xa5, sizeof(dst));
		memset(&src, 0, sizeof(src));
		src.cpu_set[0] = 0x1010UL;
		src.cpu_set[1] = 0x2020UL;
		src.cpu_set[2] = 0x3030UL;
		src.cpu_set[3] = 0x4040UL;
		src.in_kernel = 1;
		src.sched_policy = 5;
		src.sched_param.sched_priority = 17;
		dst.sched_policy = -123;
		dst.sched_param.sched_priority = -456;
		dst.guard = 0xfeedfaceUL;

		mix(&digest, process_clone_thread_base_state_body_result(
			&dst, &src,
			offsetof(struct fake_clone_thread_state, cpu_set),
			sizeof(dst.cpu_set),
			offsetof(struct fake_clone_thread_state, in_kernel)));
		require(!memcmp(dst.cpu_set, src.cpu_set, sizeof(dst.cpu_set)));
		require(dst.in_kernel == src.in_kernel);
		require(dst.sched_policy == -123);
		require(dst.sched_param.sched_priority == -456);
		require(dst.guard == 0xfeedfaceUL);
		mix(&digest, dst.cpu_set[3]);
		mix(&digest, dst.in_kernel);

		mix(&digest, process_clone_thread_sched_state_body_result(
			&dst, &src,
			offsetof(struct fake_clone_thread_state, sched_policy),
			offsetof(struct fake_clone_thread_state,
				 sched_param.sched_priority)));
		require(dst.sched_policy == src.sched_policy);
		require(dst.sched_param.sched_priority ==
			src.sched_param.sched_priority);
		require(dst.guard == 0xfeedfaceUL);
		mix(&digest, dst.sched_policy);
		mix(&digest, dst.sched_param.sched_priority);
		mix(&digest, process_clone_thread_base_state_body_result(
			NULL, &src,
			offsetof(struct fake_clone_thread_state, cpu_set),
			sizeof(dst.cpu_set),
			offsetof(struct fake_clone_thread_state, in_kernel)));
		mix(&digest, process_clone_thread_base_state_body_result(
			&dst, NULL,
			offsetof(struct fake_clone_thread_state, cpu_set),
			sizeof(dst.cpu_set),
			offsetof(struct fake_clone_thread_state, in_kernel)));
		mix(&digest, process_clone_thread_sched_state_body_result(
			NULL, &src,
			offsetof(struct fake_clone_thread_state, sched_policy),
			offsetof(struct fake_clone_thread_state,
				 sched_param.sched_priority)));
			mix(&digest, process_clone_thread_sched_state_body_result(
				&dst, NULL,
				offsetof(struct fake_clone_thread_state, sched_policy),
				offsetof(struct fake_clone_thread_state,
					 sched_param.sched_priority)));
		}
		{
			struct fake_thread_state_extra {
				int sched_policy;
				int exit_status;
				void *vm;
				void *proc;
				unsigned int spin_sleep_lock;
				int spin_sleep;
				void *sigcommon;
				unsigned long sigmask[2];
				int profile;
				unsigned long guard;
			} thread, origin;
			struct fake_process_state_extra {
				void *vm;
				void *main_thread;
				int termsig;
				long saved_cmdline_len;
				char *saved_cmdline;
				int profile;
			} proc, parent_proc;
			struct fake_vm_policy_state {
				unsigned long pad;
				unsigned long numa_mask[4];
				int numa_mem_policy;
				unsigned long region[6];
				unsigned long guard;
			} dst_vm, src_vm;
			struct fake_sigcommon_state_extra {
				int use;
				unsigned long action[4];
			} shared_sig, dst_sig, src_sig;
			char source_cmdline[] = "rust-owned-cmdline";

			memset(&thread, 0xa5, sizeof(thread));
			memset(&origin, 0, sizeof(origin));
			memset(&proc, 0, sizeof(proc));
			memset(&parent_proc, 0, sizeof(parent_proc));
			memset(&dst_vm, 0xa5, sizeof(dst_vm));
			memset(&src_vm, 0, sizeof(src_vm));
			memset(&shared_sig, 0, sizeof(shared_sig));
			memset(&dst_sig, 0xa5, sizeof(dst_sig));
			memset(&src_sig, 0, sizeof(src_sig));
			thread.guard = 0xaaaabbbbUL;
			origin.vm = (void *)0x11110000UL;
			origin.proc = (void *)0x22220000UL;
			origin.sigcommon = &shared_sig;
			origin.sigmask[0] = 0x10112222UL;
			origin.sigmask[1] = 0x33334444UL;
			origin.profile = 0x05;
			proc.profile = 0x30;
			shared_sig.use = 4;
			for (size_t i = 0; i < sizeof(src_sig.action) /
					sizeof(src_sig.action[0]); ++i)
				src_sig.action[i] = 0xabc000UL + i;
			src_vm.numa_mask[0] = 0x1111UL;
			src_vm.numa_mask[1] = 0x2222UL;
			src_vm.numa_mask[2] = 0x3333UL;
			src_vm.numa_mask[3] = 0x4444UL;
			src_vm.numa_mem_policy = 7;
			for (size_t i = 0; i < sizeof(src_vm.region) /
					sizeof(src_vm.region[0]); ++i)
				src_vm.region[i] = 0x9000UL + i;
			dst_vm.guard = 0xfeed1234UL;

			mix(&digest, process_thread_sched_default_body_result(
				&thread,
				offsetof(struct fake_thread_state_extra, sched_policy),
				3));
			require(thread.sched_policy == 3);
			mix(&digest, thread.sched_policy);

			mix(&digest, process_create_thread_link_state_body_result(
				&thread, &proc, &dst_vm,
				offsetof(struct fake_thread_state_extra, vm),
				offsetof(struct fake_thread_state_extra, proc),
				offsetof(struct fake_process_state_extra, vm),
				offsetof(struct fake_process_state_extra, main_thread)));
			require(thread.vm == &dst_vm);
			require(thread.proc == &proc);
			require(proc.vm == &dst_vm);
			require(proc.main_thread == &thread);
			mix(&digest, (unsigned long)(uintptr_t)(thread.vm == &dst_vm));
			mix(&digest, (unsigned long)(uintptr_t)(proc.main_thread == &thread));

			mix(&digest, process_thread_exit_status_init_body_result(
				&thread,
				offsetof(struct fake_thread_state_extra, exit_status),
				-1));
			require(thread.exit_status == -1);
			mix(&digest, (unsigned long)thread.exit_status);

			reset_process_release_trace();
			thread.spin_sleep = 99;
			mix(&digest, process_thread_spin_sleep_init_body_result(
				&thread,
				offsetof(struct fake_thread_state_extra, spin_sleep_lock),
				offsetof(struct fake_thread_state_extra, spin_sleep),
				fake_spin_init));
			require(thread.spin_sleep_lock == 0x13572468U);
			require(thread.spin_sleep == 0);
			require(process_as_spin_init_count == 1);
			require(process_as_spin_init_addr ==
				(unsigned long)(uintptr_t)&thread.spin_sleep_lock);
			mix(&digest, thread.spin_sleep_lock);
			mix(&digest, process_as_spin_init_count);

			mix(&digest, process_thread_sigmask_copy_body_result(
				&thread, &origin,
				offsetof(struct fake_thread_state_extra, sigmask),
				sizeof(thread.sigmask)));
			require(!memcmp(thread.sigmask, origin.sigmask,
				sizeof(thread.sigmask)));
			require(thread.guard == 0xaaaabbbbUL);
			mix(&digest, thread.sigmask[1]);

			mix(&digest, process_clone_profile_state_body_result(
				&thread, &origin, &proc,
				offsetof(struct fake_thread_state_extra, profile),
				offsetof(struct fake_process_state_extra, profile)));
			require(thread.profile == (origin.profile | proc.profile));
			mix(&digest, thread.profile);

			mix(&digest, process_clone_fork_process_termsig_body_result(
				&proc,
				offsetof(struct fake_process_state_extra, termsig),
				0x44));
			require(proc.termsig == 0x44);
			mix(&digest, proc.termsig);

			parent_proc.saved_cmdline_len = sizeof(source_cmdline);
			parent_proc.saved_cmdline = source_cmdline;
			reset_process_release_trace();
			mix(&digest, process_clone_fork_saved_cmdline_body_result(
				&proc, &parent_proc,
				offsetof(struct fake_process_state_extra,
					 saved_cmdline_len),
				offsetof(struct fake_process_state_extra, saved_cmdline),
				IHK_MC_AP_NOWAIT, fake_address_space_alloc));
			require(process_as_alloc_count == 1);
			require(process_as_alloc_size == sizeof(source_cmdline));
			require(process_as_alloc_flags == IHK_MC_AP_NOWAIT);
			require(proc.saved_cmdline_len == parent_proc.saved_cmdline_len);
			require(proc.saved_cmdline == (char *)process_as_alloc_space);
			require(!memcmp(proc.saved_cmdline, source_cmdline,
				sizeof(source_cmdline)));
			mix(&digest, process_as_alloc_size);
			mix(&digest, (unsigned long)(unsigned char)proc.saved_cmdline[5]);

			reset_process_release_trace();
			process_as_alloc_fail = 1;
			proc.saved_cmdline = NULL;
			mix(&digest, process_clone_fork_saved_cmdline_body_result(
				&proc, &parent_proc,
				offsetof(struct fake_process_state_extra,
					 saved_cmdline_len),
				offsetof(struct fake_process_state_extra, saved_cmdline),
				IHK_MC_AP_NOWAIT, fake_address_space_alloc));
			require(proc.saved_cmdline == NULL);
			require(process_as_alloc_count == 1);
			process_as_alloc_fail = 0;

			mix(&digest, process_clone_fork_vm_policy_body_result(
				&dst_vm, &src_vm,
				offsetof(struct fake_vm_policy_state, numa_mask),
				sizeof(dst_vm.numa_mask),
				offsetof(struct fake_vm_policy_state, numa_mem_policy),
				offsetof(struct fake_vm_policy_state, region),
				sizeof(dst_vm.region)));
			require(!memcmp(dst_vm.numa_mask, src_vm.numa_mask,
				sizeof(dst_vm.numa_mask)));
			require(dst_vm.numa_mem_policy == src_vm.numa_mem_policy);
			require(!memcmp(dst_vm.region, src_vm.region,
				sizeof(dst_vm.region)));
			require(dst_vm.guard == 0xfeed1234UL);
			mix(&digest, dst_vm.numa_mask[3]);
			mix(&digest, dst_vm.region[5]);

			thread.vm = NULL;
			thread.proc = NULL;
			mix(&digest, process_clone_thread_shared_vm_state_body_result(
				&thread, &proc, &dst_vm,
				offsetof(struct fake_thread_state_extra, vm),
				offsetof(struct fake_thread_state_extra, proc)));
			require(thread.vm == &dst_vm);
			require(thread.proc == &proc);
			mix(&digest, (unsigned long)(uintptr_t)(thread.proc == &proc));

			thread.sigcommon = NULL;
			reset_process_release_trace();
			mix(&digest, process_clone_sigcommon_share_body_result(
				&thread, &origin,
				offsetof(struct fake_thread_state_extra, sigcommon),
				offsetof(struct fake_sigcommon_state_extra, use),
				fake_ref_inc));
			require(thread.sigcommon == &shared_sig);
			require(shared_sig.use == 5);
			require(process_ref_inc_count == 1);
			require(process_ref_inc_object == &shared_sig);
			require(process_ref_inc_offset ==
				offsetof(struct fake_sigcommon_state_extra, use));
			mix(&digest, shared_sig.use);
			mix(&digest, process_ref_inc_count);

			mix(&digest, process_clone_sigcommon_action_copy_body_result(
				&dst_sig, &src_sig,
				offsetof(struct fake_sigcommon_state_extra, action),
				sizeof(dst_sig.action)));
			require(!memcmp(dst_sig.action, src_sig.action,
				sizeof(dst_sig.action)));
			require(dst_sig.use == (int)0xa5a5a5a5U);
			mix(&digest, dst_sig.action[3]);

			{
				struct fake_clone_uctx_thread {
					void *uctx;
					unsigned long guard;
				} dst_uctx_thread, src_uctx_thread;
				struct fake_cpu_local_onfork {
					unsigned long pad;
					void *on_fork_vm;
					unsigned long guard;
				} fork_cpu;
				struct fake_mckfd_copy_state {
					int fd;
					void *dup_cb;
					struct fake_mckfd_copy_state *next;
					unsigned long payload[3];
				} src_fd;
				struct fake_mckfd_copy_wrap {
					struct fake_mckfd_copy_state fd;
					unsigned long guard;
				} dst_fd;
				unsigned char src_uctx[64];
				unsigned char dst_uctx[64];

				for (size_t i = 0; i < sizeof(src_uctx); ++i) {
					src_uctx[i] = (unsigned char)(0xc0 + i);
					dst_uctx[i] = 0x5a;
				}
				memset(&dst_uctx_thread, 0, sizeof(dst_uctx_thread));
				memset(&src_uctx_thread, 0, sizeof(src_uctx_thread));
				dst_uctx_thread.uctx = dst_uctx;
				src_uctx_thread.uctx = src_uctx;
				dst_uctx_thread.guard = 0xabcddcbaUL;
				reset_process_stack_trace();
				mix(&digest, process_clone_user_context_body_result(
					&dst_uctx_thread, &src_uctx_thread,
					offsetof(struct fake_clone_uctx_thread, uctx),
					sizeof(src_uctx), IHK_UCR_STACK_POINTER,
					0x12345000UL, IHK_UCR_PROGRAM_COUNTER,
					0x6789abcdUL,
					fake_process_stack_modify_context));
				require(!memcmp(dst_uctx, src_uctx, sizeof(dst_uctx)));
				require(dst_uctx_thread.guard == 0xabcddcbaUL);
				require(process_stack_modify_count == 2);
				require(process_stack_modify_uctx == dst_uctx);
				require(process_stack_modify_reg ==
					IHK_UCR_PROGRAM_COUNTER);
				require(process_stack_modify_value == 0x6789abcdUL);
				mix(&digest, dst_uctx[17]);
				mix(&digest, process_stack_modify_count);

				parent_proc.profile = 0x66;
				proc.profile = 0;
				mix(&digest, process_clone_fork_profile_body_result(
					&proc, &parent_proc,
					offsetof(struct fake_process_state_extra,
						 profile)));
				require(proc.profile == parent_proc.profile);
				mix(&digest, proc.profile);

				memset(&fork_cpu, 0, sizeof(fork_cpu));
				fork_cpu.guard = 0xfacefeedUL;
				mix(&digest, process_clone_on_fork_vm_body_result(
					&fork_cpu,
					offsetof(struct fake_cpu_local_onfork,
						 on_fork_vm),
					&dst_vm));
				require(fork_cpu.on_fork_vm == &dst_vm);
				require(fork_cpu.guard == 0xfacefeedUL);
				mix(&digest, (unsigned long)(uintptr_t)
					(fork_cpu.on_fork_vm == &dst_vm));
				mix(&digest, process_clone_on_fork_vm_body_result(
					&fork_cpu,
					offsetof(struct fake_cpu_local_onfork,
						 on_fork_vm),
					NULL));
				require(fork_cpu.on_fork_vm == NULL);

				memset(&src_fd, 0, sizeof(src_fd));
				memset(&dst_fd, 0xa5, sizeof(dst_fd));
				src_fd.fd = 42;
				src_fd.dup_cb = (void *)0x12345678UL;
				src_fd.next = (void *)0xabcdef00UL;
				src_fd.payload[0] = 0x1010UL;
				src_fd.payload[1] = 0x2020UL;
				src_fd.payload[2] = 0x3030UL;
				dst_fd.guard = 0x99887766UL;
				mix(&digest, process_mckfd_copy_body_result(
					&dst_fd.fd, &src_fd, sizeof(src_fd)));
				require(!memcmp(&dst_fd.fd, &src_fd, sizeof(src_fd)));
				require(dst_fd.guard == 0x99887766UL);
				mix(&digest, dst_fd.fd.payload[2]);

				mix(&digest, process_clone_user_context_body_result(
					NULL, &src_uctx_thread,
					offsetof(struct fake_clone_uctx_thread, uctx),
					sizeof(src_uctx), IHK_UCR_STACK_POINTER,
					0x12345000UL, IHK_UCR_PROGRAM_COUNTER,
					0x6789abcdUL,
					fake_process_stack_modify_context));
				mix(&digest, process_clone_user_context_body_result(
					&dst_uctx_thread, &src_uctx_thread,
					offsetof(struct fake_clone_uctx_thread, uctx),
					sizeof(src_uctx), IHK_UCR_STACK_POINTER,
					0x12345000UL, IHK_UCR_PROGRAM_COUNTER,
					0x6789abcdUL, NULL));
				mix(&digest, process_clone_fork_profile_body_result(
					NULL, &parent_proc,
					offsetof(struct fake_process_state_extra,
						 profile)));
				mix(&digest, process_clone_on_fork_vm_body_result(
					NULL,
					offsetof(struct fake_cpu_local_onfork,
						 on_fork_vm),
					&dst_vm));
				mix(&digest, process_mckfd_copy_body_result(
					NULL, &src_fd, sizeof(src_fd)));
			}

			mix(&digest, process_thread_sched_default_body_result(
				NULL,
				offsetof(struct fake_thread_state_extra, sched_policy),
				3));
			mix(&digest, process_create_thread_link_state_body_result(
				NULL, &proc, &dst_vm,
				offsetof(struct fake_thread_state_extra, vm),
				offsetof(struct fake_thread_state_extra, proc),
				offsetof(struct fake_process_state_extra, vm),
				offsetof(struct fake_process_state_extra, main_thread)));
			mix(&digest, process_thread_exit_status_init_body_result(
				NULL,
				offsetof(struct fake_thread_state_extra, exit_status),
				-1));
			mix(&digest, process_thread_spin_sleep_init_body_result(
				&thread,
				offsetof(struct fake_thread_state_extra, spin_sleep_lock),
				offsetof(struct fake_thread_state_extra, spin_sleep),
				NULL));
			mix(&digest, process_thread_sigmask_copy_body_result(
				&thread, NULL,
				offsetof(struct fake_thread_state_extra, sigmask),
				sizeof(thread.sigmask)));
			mix(&digest, process_clone_profile_state_body_result(
				&thread, &origin, NULL,
				offsetof(struct fake_thread_state_extra, profile),
				offsetof(struct fake_process_state_extra, profile)));
			mix(&digest, process_clone_fork_process_termsig_body_result(
				NULL,
				offsetof(struct fake_process_state_extra, termsig),
				0x44));
			mix(&digest, process_clone_fork_saved_cmdline_body_result(
				&proc, &parent_proc,
				offsetof(struct fake_process_state_extra,
					 saved_cmdline_len),
				offsetof(struct fake_process_state_extra, saved_cmdline),
				IHK_MC_AP_NOWAIT, NULL));
			mix(&digest, process_clone_fork_vm_policy_body_result(
				NULL, &src_vm,
				offsetof(struct fake_vm_policy_state, numa_mask),
				sizeof(dst_vm.numa_mask),
				offsetof(struct fake_vm_policy_state, numa_mem_policy),
				offsetof(struct fake_vm_policy_state, region),
				sizeof(dst_vm.region)));
			mix(&digest, process_clone_thread_shared_vm_state_body_result(
				&thread, NULL, &dst_vm,
				offsetof(struct fake_thread_state_extra, vm),
				offsetof(struct fake_thread_state_extra, proc)));
			mix(&digest, process_clone_sigcommon_share_body_result(
				&thread, &origin,
				offsetof(struct fake_thread_state_extra, sigcommon),
				offsetof(struct fake_sigcommon_state_extra, use),
				NULL));
			mix(&digest, process_clone_sigcommon_action_copy_body_result(
				NULL, &src_sig,
				offsetof(struct fake_sigcommon_state_extra, action),
				sizeof(dst_sig.action)));
		}
		{
			struct fake_sigcommon *sigcommon;
			struct fake_thread_sigpending {
			int pad;
			unsigned int sigpendinglock;
			struct fake_list_head sigpending;
		} sigthread = { 0 };

		reset_process_release_trace();
		sigcommon = process_sigcommon_alloc_init_body_result(
			sizeof(*sigcommon), 0x66,
			offsetof(struct fake_sigcommon, use),
			offsetof(struct fake_sigcommon, lock),
			offsetof(struct fake_sigcommon, sigpending),
			fake_address_space_alloc, fake_optional_free,
			fake_ref_set, fake_rwlock_init);
		require(sigcommon == (void *)process_as_alloc_space);
		require(process_as_alloc_count == 1);
		require(process_as_alloc_size == sizeof(*sigcommon));
		require(process_as_alloc_flags == 0x66);
		require(sigcommon->use == 1);
		require(sigcommon->lock == 0x2468ace0U);
		require(sigcommon->sigpending.next == &sigcommon->sigpending);
		require(sigcommon->sigpending.prev == &sigcommon->sigpending);
		require(process_as_ref_set_count == 1);
		require(process_rwlock_init_count == 1);
		require(process_rwlock_init_addr ==
			(unsigned long)(uintptr_t)&sigcommon->lock);
		mix(&digest, sigcommon->use);
		mix(&digest, sigcommon->lock);

		reset_process_release_trace();
		mix(&digest, process_thread_sigpending_init_body_result(
			&sigthread,
			offsetof(struct fake_thread_sigpending, sigpendinglock),
			offsetof(struct fake_thread_sigpending, sigpending),
			fake_rwlock_init));
		require(sigthread.sigpendinglock == 0x2468ace0U);
		require(sigthread.sigpending.next == &sigthread.sigpending);
		require(sigthread.sigpending.prev == &sigthread.sigpending);
		require(process_rwlock_init_count == 1);
		mix(&digest, sigthread.sigpendinglock);
		mix(&digest, process_thread_sigpending_init_body_result(
			NULL,
			offsetof(struct fake_thread_sigpending, sigpendinglock),
			offsetof(struct fake_thread_sigpending, sigpending),
			fake_rwlock_init));
	}
	{
		struct fake_thread_alloc {
			int prefix;
			int refcount;
			struct fake_list_head hash_list;
			struct fake_list_head siblings_list;
			unsigned long tail;
		} init_thread = {
			.prefix = 0x1111,
			.refcount = 99,
			.hash_list = { (void *)0x10, (void *)0x20 },
			.siblings_list = { (void *)0x30, (void *)0x40 },
			.tail = 0xfeedfaceUL,
		};

		reset_process_release_trace();
		mix(&digest, process_thread_alloc_init_body_result(
			&init_thread, sizeof(init_thread),
			offsetof(struct fake_thread_alloc, refcount),
			offsetof(struct fake_thread_alloc, hash_list),
			offsetof(struct fake_thread_alloc, siblings_list),
			fake_ref_set));
		require(init_thread.prefix == 0);
		require(init_thread.refcount == 2);
		require(init_thread.hash_list.next == &init_thread.hash_list);
		require(init_thread.hash_list.prev == &init_thread.hash_list);
		require(init_thread.siblings_list.next ==
			&init_thread.siblings_list);
		require(init_thread.siblings_list.prev ==
			&init_thread.siblings_list);
		require(init_thread.tail == 0);
		require(process_as_ref_set_count == 1);
		require(process_as_ref_set_object == &init_thread);
		mix(&digest, init_thread.refcount);
		mix(&digest, process_thread_alloc_init_body_result(
			NULL, sizeof(init_thread),
			offsetof(struct fake_thread_alloc, refcount),
			offsetof(struct fake_thread_alloc, hash_list),
			offsetof(struct fake_thread_alloc, siblings_list),
			fake_ref_set));
	}
	{
		struct fake_sigstack {
			void *ss_sp;
			int ss_flags;
			size_t ss_size;
		};
		struct fake_sigstack_thread {
			int prefix;
			struct fake_sigstack sigstack;
		} sigstack_thread = {
			.prefix = 0x777,
			.sigstack = {
				.ss_sp = (void *)0x1234,
				.ss_flags = 9,
				.ss_size = 0x8888,
			},
		};

		mix(&digest, process_thread_sigstack_disable_body_result(
			&sigstack_thread,
			offsetof(struct fake_sigstack_thread, sigstack),
			offsetof(struct fake_sigstack, ss_sp),
			offsetof(struct fake_sigstack, ss_flags),
			offsetof(struct fake_sigstack, ss_size), 2));
		require(sigstack_thread.prefix == 0x777);
		require(sigstack_thread.sigstack.ss_sp == NULL);
		require(sigstack_thread.sigstack.ss_flags == 2);
		require(sigstack_thread.sigstack.ss_size == 0);
		mix(&digest, sigstack_thread.sigstack.ss_flags);
		mix(&digest, process_thread_sigstack_disable_body_result(
			NULL, offsetof(struct fake_sigstack_thread, sigstack),
			offsetof(struct fake_sigstack, ss_sp),
			offsetof(struct fake_sigstack, ss_flags),
			offsetof(struct fake_sigstack, ss_size), 2));
	}
	{
		unsigned long requested[1] = { (1UL << 1) | (1UL << 3) };
		struct fake_create_process_obj parent = { .pid = 1 };
		void *created;

		reset_create_thread_trace();
		created = process_create_thread_body_result(
			0x400000UL, (unsigned long)(uintptr_t)requested, 64, 2,
			sizeof(create_thread_store), sizeof(create_proc_store),
			sizeof(create_vm_store), IHK_MC_AP_NOWAIT, 8192,
			128, 8, SCHED_NORMAL, SS_DISABLE, 2, &parent,
			offsetof(struct fake_create_process_obj, pid),
			offsetof(struct fake_create_thread_obj, refcount),
			offsetof(struct fake_create_thread_obj, hash_list),
			offsetof(struct fake_create_thread_obj, siblings_list),
			offsetof(struct fake_create_thread_obj, cpu_set),
			offsetof(struct fake_create_thread_obj, sched_policy),
			offsetof(struct fake_create_thread_obj, sigcommon),
			offsetof(struct fake_create_thread_obj, sigpendinglock),
			offsetof(struct fake_create_thread_obj, sigpending),
			offsetof(struct fake_create_thread_obj, sigstack),
			offsetof(struct fake_create_sigstack, ss_sp),
			offsetof(struct fake_create_sigstack, ss_flags),
			offsetof(struct fake_create_sigstack, ss_size),
			offsetof(struct fake_create_thread_obj, vm),
			offsetof(struct fake_create_thread_obj, proc),
			offsetof(struct fake_create_process_obj, cpu_set),
			offsetof(struct fake_create_process_obj, vm),
			offsetof(struct fake_create_process_obj, main_thread),
			offsetof(struct fake_create_vm_obj, address_space),
			offsetof(struct fake_create_address_space_obj, cpu_set),
			offsetof(struct fake_create_address_space_obj,
				 cpu_set_lock),
			offsetof(struct fake_create_thread_obj, exit_status),
			offsetof(struct fake_create_thread_obj, spin_sleep_lock),
			offsetof(struct fake_create_thread_obj, spin_sleep),
			sizeof(create_sigcommon_store),
			offsetof(struct fake_create_sigcommon_obj, use),
			offsetof(struct fake_create_sigcommon_obj, lock),
			offsetof(struct fake_create_sigcommon_obj, sigpending),
			fake_create_alloc_pages, fake_create_alloc,
			fake_create_free, fake_create_address_space,
			fake_create_release_address_space,
			fake_create_init_process, fake_create_init_vm,
			fake_create_init_user, fake_default_ncpus,
			fake_create_cpu_log, fake_rwlock_init, fake_spin_init,
			fake_spin_lock, fake_spin_unlock,
			fake_create_free_thread);
		require(created == &create_thread_store);
		require(create_alloc_pages_count == 1);
		require(create_alloc_pages_npages == 2);
		require(create_alloc_pages_flags == IHK_MC_AP_NOWAIT);
		require(create_alloc_count == 3);
		require(create_alloc_size[0] == sizeof(create_proc_store));
		require(create_alloc_size[1] == sizeof(create_vm_store));
		require(create_alloc_size[2] == sizeof(create_sigcommon_store));
		require(create_address_space_count == 1);
		require(create_address_space_nslots == 1);
		require(create_init_process_count == 1);
		require(create_init_process_parent == &parent);
		require(create_init_vm_count == 1);
		require(create_init_vm_owner == &create_proc_store);
		require(create_init_user_count == 1);
		require(create_init_user_thread == &create_thread_store);
		require(create_init_user_stack_top ==
			(unsigned long)(uintptr_t)&create_thread_store + 8192);
		require(create_init_user_pc == 0x400000UL);
		require(create_init_user_sp == 0);
		require(create_free_count == 0);
		require(create_release_address_space_count == 0);
		require(create_free_thread_count == 0);
		require(create_thread_store.refcount == 2);
		require(create_thread_store.hash_list.next ==
			&create_thread_store.hash_list);
		require(create_thread_store.hash_list.prev ==
			&create_thread_store.hash_list);
		require(create_thread_store.siblings_list.next ==
			&create_thread_store.siblings_list);
		require(create_thread_store.siblings_list.prev ==
			&create_thread_store.siblings_list);
		require(create_thread_store.cpu_set[0] ==
			((1UL << 1) | (1UL << 3)));
		require(create_proc_store.cpu_set[0] ==
			create_thread_store.cpu_set[0]);
		require(create_as_store.cpu_set[0] == (1UL << 2));
		require(process_create_cpu_log_count == 2);
		require(process_create_cpu_requested_count == 2);
		require(process_create_cpu_requested_mask ==
			((1UL << 1) | (1UL << 3)));
		require(process_default_ncpus_count == 0);
		require(create_thread_store.sched_policy == SCHED_NORMAL);
		require(create_thread_store.sigcommon ==
			&create_sigcommon_store);
		require(create_sigcommon_store.use == 1);
		require(create_sigcommon_store.lock == 0x2468ace0U);
		require(create_sigcommon_store.sigpending.next ==
			&create_sigcommon_store.sigpending);
		require(create_sigcommon_store.sigpending.prev ==
			&create_sigcommon_store.sigpending);
		require(create_thread_store.sigpendinglock == 0x2468ace0U);
		require(create_thread_store.sigpending.next ==
			&create_thread_store.sigpending);
		require(create_thread_store.sigpending.prev ==
			&create_thread_store.sigpending);
		require(create_thread_store.sigstack.ss_sp == NULL);
		require(create_thread_store.sigstack.ss_flags == SS_DISABLE);
		require(create_thread_store.sigstack.ss_size == 0);
		require(create_thread_store.vm == &create_vm_store);
		require(create_thread_store.proc == &create_proc_store);
		require(create_proc_store.vm == &create_vm_store);
		require(create_proc_store.main_thread == &create_thread_store);
		require(create_vm_store.address_space == &create_as_store);
		require(create_vm_store.owner == &create_proc_store);
		require(create_vm_store.initialized == 1);
		require(create_thread_store.exit_status == -1);
		require(create_thread_store.spin_sleep_lock == 0x13572468U);
		require(create_thread_store.spin_sleep == 0);
		require(process_rwlock_init_count == 2);
		require(process_as_spin_init_count == 1);
		require(process_spin_lock_count == 1);
		require(process_spin_unlock_count == 1);
		require(process_spin_unlock_irq == 0x12345678UL);
		mix(&digest, create_thread_store.refcount);
		mix(&digest, create_thread_store.cpu_set[0]);
		mix(&digest, create_as_store.cpu_set[0]);
		mix(&digest, create_sigcommon_store.use);
		mix(&digest, create_init_user_pc);
		mix(&digest, create_thread_store.spin_sleep_lock);

		reset_create_thread_trace();
		create_fail_sigcommon = 1;
		created = process_create_thread_body_result(
			0x500000UL, (unsigned long)(uintptr_t)requested, 64, 2,
			sizeof(create_thread_store), sizeof(create_proc_store),
			sizeof(create_vm_store), IHK_MC_AP_NOWAIT, 8192,
			128, 8, SCHED_NORMAL, SS_DISABLE, 2, &parent,
			offsetof(struct fake_create_process_obj, pid),
			offsetof(struct fake_create_thread_obj, refcount),
			offsetof(struct fake_create_thread_obj, hash_list),
			offsetof(struct fake_create_thread_obj, siblings_list),
			offsetof(struct fake_create_thread_obj, cpu_set),
			offsetof(struct fake_create_thread_obj, sched_policy),
			offsetof(struct fake_create_thread_obj, sigcommon),
			offsetof(struct fake_create_thread_obj, sigpendinglock),
			offsetof(struct fake_create_thread_obj, sigpending),
			offsetof(struct fake_create_thread_obj, sigstack),
			offsetof(struct fake_create_sigstack, ss_sp),
			offsetof(struct fake_create_sigstack, ss_flags),
			offsetof(struct fake_create_sigstack, ss_size),
			offsetof(struct fake_create_thread_obj, vm),
			offsetof(struct fake_create_thread_obj, proc),
			offsetof(struct fake_create_process_obj, cpu_set),
			offsetof(struct fake_create_process_obj, vm),
			offsetof(struct fake_create_process_obj, main_thread),
			offsetof(struct fake_create_vm_obj, address_space),
			offsetof(struct fake_create_address_space_obj, cpu_set),
			offsetof(struct fake_create_address_space_obj,
				 cpu_set_lock),
			offsetof(struct fake_create_thread_obj, exit_status),
			offsetof(struct fake_create_thread_obj, spin_sleep_lock),
			offsetof(struct fake_create_thread_obj, spin_sleep),
			sizeof(create_sigcommon_store),
			offsetof(struct fake_create_sigcommon_obj, use),
			offsetof(struct fake_create_sigcommon_obj, lock),
			offsetof(struct fake_create_sigcommon_obj, sigpending),
			fake_create_alloc_pages, fake_create_alloc,
			fake_create_free, fake_create_address_space,
			fake_create_release_address_space,
			fake_create_init_process, fake_create_init_vm,
			fake_create_init_user, fake_default_ncpus,
			fake_create_cpu_log, fake_rwlock_init, fake_spin_init,
			fake_spin_lock, fake_spin_unlock,
			fake_create_free_thread);
		require(created == NULL);
		require(create_alloc_count == 3);
		require(create_free_count == 2);
		require(create_release_address_space_count == 1);
		require(create_release_address_space_ptr == &create_as_store);
		require(create_free_thread_count == 1);
		require(create_free_thread_ptr == &create_thread_store);
		require(create_init_user_count == 0);
		require(create_init_vm_count == 0);
		require(process_as_spin_init_count == 0);
		require(create_free_xor ==
			((unsigned long)(uintptr_t)&create_proc_store ^
			 (unsigned long)(uintptr_t)&create_vm_store));
		mix(&digest, create_free_count);
		mix(&digest, create_release_address_space_count);
		mix(&digest, create_free_thread_count);

		reset_create_thread_trace();
		requested[0] = (1UL << 2) | (1UL << 9);
		created = process_create_thread_body_result(
			0x600000UL, (unsigned long)(uintptr_t)requested, 64, 2,
			sizeof(create_thread_store), sizeof(create_proc_store),
			sizeof(create_vm_store), IHK_MC_AP_NOWAIT, 8192,
			128, 4, SCHED_NORMAL, SS_DISABLE, 1, &parent,
			offsetof(struct fake_create_process_obj, pid),
			offsetof(struct fake_create_thread_obj, refcount),
			offsetof(struct fake_create_thread_obj, hash_list),
			offsetof(struct fake_create_thread_obj, siblings_list),
			offsetof(struct fake_create_thread_obj, cpu_set),
			offsetof(struct fake_create_thread_obj, sched_policy),
			offsetof(struct fake_create_thread_obj, sigcommon),
			offsetof(struct fake_create_thread_obj, sigpendinglock),
			offsetof(struct fake_create_thread_obj, sigpending),
			offsetof(struct fake_create_thread_obj, sigstack),
			offsetof(struct fake_create_sigstack, ss_sp),
			offsetof(struct fake_create_sigstack, ss_flags),
			offsetof(struct fake_create_sigstack, ss_size),
			offsetof(struct fake_create_thread_obj, vm),
			offsetof(struct fake_create_thread_obj, proc),
			offsetof(struct fake_create_process_obj, cpu_set),
			offsetof(struct fake_create_process_obj, vm),
			offsetof(struct fake_create_process_obj, main_thread),
			offsetof(struct fake_create_vm_obj, address_space),
			offsetof(struct fake_create_address_space_obj, cpu_set),
			offsetof(struct fake_create_address_space_obj,
				 cpu_set_lock),
			offsetof(struct fake_create_thread_obj, exit_status),
			offsetof(struct fake_create_thread_obj, spin_sleep_lock),
			offsetof(struct fake_create_thread_obj, spin_sleep),
			sizeof(create_sigcommon_store),
			offsetof(struct fake_create_sigcommon_obj, use),
			offsetof(struct fake_create_sigcommon_obj, lock),
			offsetof(struct fake_create_sigcommon_obj, sigpending),
			fake_create_alloc_pages, fake_create_alloc,
			fake_create_free, fake_create_address_space,
			fake_create_release_address_space,
			fake_create_init_process, fake_create_init_vm,
			fake_create_init_user, fake_default_ncpus,
			fake_create_cpu_log, fake_rwlock_init, fake_spin_init,
			fake_spin_lock, fake_spin_unlock,
			fake_create_free_thread);
		require(created == NULL);
		require(create_alloc_count == 2);
		require(create_free_count == 2);
		require(create_release_address_space_count == 1);
		require(create_free_thread_count == 1);
		require(create_init_user_count == 0);
		require(process_create_cpu_requested_count == 1);
		require(process_create_cpu_invalid_count == 1);
		require(process_create_cpu_last_pid == 77);
		require(process_create_cpu_last_cpu == 9);
		require(create_thread_store.cpu_set[0] == (1UL << 2));
		require(create_proc_store.cpu_set[0] == (1UL << 2));
		mix(&digest, process_create_cpu_invalid_count);
		mix(&digest, process_create_cpu_last_cpu);
		mix(&digest, create_free_count);
	}
	mix(&digest, process_address_space_pid_detach_result(pids, 4, 20));
	mix(&digest, pids[1] == 0);
	mix(&digest, pids[3] == 20);
	mix(&digest, process_address_space_pid_detach_result(pids, 4, 99));
	mix(&digest, process_address_space_pid_detach_result(NULL, 4, 20));
	mix(&digest, process_address_space_pid_detach_result(pids, 0, 20));
	mix(&digest, process_clone_shares_vm_result(CLONE_VM));
	mix(&digest, process_clone_shares_vm_result(0));
	mix(&digest, process_clone_shares_sighand_result(CLONE_SIGHAND));
	mix(&digest, process_clone_shares_sighand_result(CLONE_VM));
	mix(&digest, process_mckfd_should_dup_result(0));
	mix(&digest, process_mckfd_should_dup_result(0x5000));
	mix(&digest, process_clone_copy_vm_thread_state_result(&dst_vm,
		&src_vm, offsetof(struct fake_vm_state, vdso_addr),
		offsetof(struct fake_vm_state, vvar_addr), &dst_thread,
		&src_thread, offsetof(struct fake_thread_state, sigstack),
		sizeof(src_thread.sigstack)));
	mix(&digest, dst_vm.vdso_addr == src_vm.vdso_addr);
	mix(&digest, dst_vm.vvar_addr == src_vm.vvar_addr);
	mix(&digest, dst_thread.sigstack.ss_sp == src_thread.sigstack.ss_sp);
	mix(&digest, dst_thread.sigstack.ss_flags ==
		src_thread.sigstack.ss_flags);
	mix(&digest, dst_thread.sigstack.ss_size ==
		src_thread.sigstack.ss_size);
	mix(&digest, process_clone_copy_vm_thread_state_result(NULL,
		&src_vm, offsetof(struct fake_vm_state, vdso_addr),
		offsetof(struct fake_vm_state, vvar_addr), &dst_thread,
		&src_thread, offsetof(struct fake_thread_state, sigstack),
		sizeof(src_thread.sigstack)));
	mix(&digest, process_tid_index_for_thread_result(tids, 3,
							 sizeof(tids[0]),
							 offsetof(struct fake_tid,
								  thread),
							 0x2000));
	mix(&digest, process_tid_index_for_thread_result(tids, 3,
							 sizeof(tids[0]),
							 offsetof(struct fake_tid,
								  thread),
							 0x9000));
	mix(&digest, process_tid_index_for_thread_result(NULL, 3,
							 sizeof(tids[0]),
							 offsetof(struct fake_tid,
								  thread),
							 0x2000));
	mix(&digest, process_tid_index_found_result(1));
	mix(&digest, process_tid_index_found_result(-1));
	mix(&digest, process_tid_release_slot_result(tids, 1,
						     sizeof(tids[0]),
						     offsetof(struct fake_tid,
							      thread)));
	mix(&digest, tids[1].thread == NULL);
	mix(&digest, process_tid_replace_slot_result(tids, 2,
						     sizeof(tids[0]),
						     offsetof(struct fake_tid,
							      tid),
						     offsetof(struct fake_tid,
							      thread),
						     99));
	mix(&digest, tids[2].tid);
	mix(&digest, tids[2].thread == NULL);
	mix(&digest, process_tid_release_slot_result(tids, -1,
						     sizeof(tids[0]),
						     offsetof(struct fake_tid,
							      thread)));
	mix(&digest, process_sigpending_cleanup_needed_result(0));
	mix(&digest, process_sigpending_cleanup_needed_result(1));
	fake_list_init(&pending_head);
	process_list_add_tail_result(&pending_a.list, &pending_head);
	process_list_add_tail_result(&pending_b.list, &pending_head);
	process_list_add_tail_result(NULL, &pending_head);
	process_list_add_tail_result(&pending_b.list, NULL);
	mix(&digest, pending_head.next == &pending_a.list);
	mix(&digest, pending_head.prev == &pending_b.list);
	mix(&digest, pending_a.list.prev == &pending_head);
	mix(&digest, pending_b.list.next == &pending_head);
	pending = process_sigpending_pop_front_result(
		&pending_head, offsetof(struct fake_pending, list));
	mix(&digest, pending == &pending_a);
	mix(&digest, pending_head.next == &pending_b.list);
	mix(&digest, pending_a.list.next == (void *)0x00100129);
	mix(&digest, process_list_is_linked_result(&pending_b.list));
	process_list_detach_result(&pending_b.list);
	mix(&digest, process_list_is_linked_result(&pending_b.list));
	mix(&digest, pending_head.next == &pending_head);
	process_list_add_tail_result(&pending_b.list, &pending_head);
	pending = process_sigpending_pop_front_result(
		&pending_head, offsetof(struct fake_pending, list));
	mix(&digest, pending == &pending_b);
	mix(&digest, pending_head.next == &pending_head);
	mix(&digest, process_sigpending_pop_front_result(
		&pending_head, offsetof(struct fake_pending, list)) == NULL);
	mix(&digest, process_list_is_linked_result(&pending_head));
	process_list_detach_result(NULL);
	process_list_detach_result(&pending_head);
	mix(&digest, pending_head.next == &pending_head);
	fake_list_init(&pending_head);
	mix(&digest, process_list_add_tail_counted_result(&pending_a.list,
							  &pending_head,
							  &runq_len));
	mix(&digest, runq_len);
	mix(&digest, process_list_add_tail_counted_result(&pending_b.list,
							  &pending_head,
							  &runq_len));
	mix(&digest, runq_len);
	mix(&digest, process_list_detach_counted_result(&pending_a.list,
							&runq_len));
	mix(&digest, runq_len);
	mix(&digest, pending_head.next == &pending_b.list);
	mix(&digest, process_list_detach_counted_result(NULL, &runq_len));
	mix(&digest, process_list_add_tail_counted_result(&pending_a.list,
							  NULL, &runq_len));
	mix(&digest, runq_len);
	fake_list_init(&other_head);
	mix(&digest, process_list_move_tail_result(&pending_b.list,
						   &other_head));
	mix(&digest, pending_head.next == &pending_head);
	mix(&digest, other_head.next == &pending_b.list);
	mix(&digest, pending_b.list.prev == &other_head);
	mix(&digest, process_list_move_tail_result(NULL, &pending_head));
	mix(&digest, process_list_move_tail_result(&pending_a.list, NULL));
	mix(&digest, process_list_del_init_result(&pending_b.list));
	mix(&digest, other_head.next == &other_head);
	mix(&digest, pending_b.list.next == &pending_b.list);
	mix(&digest, process_list_del_init_result(NULL));
	fake_list_init(&old_children);
	fake_list_init(&new_children);
	fake_list_init(&new_ptraced);
	fake_list_init(&child_a.siblings);
	fake_list_init(&child_a.ptraced_siblings);
	fake_list_init(&child_b.siblings);
	fake_list_init(&child_b.ptraced_siblings);
	child_a.ppid_parent = &old_parent;
	child_a.parent = &old_parent;
	child_b.ppid_parent = &old_parent;
	child_b.parent = &old_parent;
	fake_list_add_tail(&child_a.siblings, &old_children);
	fake_list_add_tail(&child_b.ptraced_siblings, &old_children);
	mix(&digest, process_child_reparent_result(&child_a,
		offsetof(struct fake_process, ppid_parent),
		offsetof(struct fake_process, parent), &pid1,
		&child_a.siblings, &new_children, 1));
	mix(&digest, child_a.ppid_parent == &pid1);
	mix(&digest, child_a.parent == &pid1);
	mix(&digest, new_children.next == &child_a.siblings);
	mix(&digest, process_child_reparent_result(&child_b,
		offsetof(struct fake_process, ppid_parent),
		offsetof(struct fake_process, parent), &pid1,
		&child_b.ptraced_siblings, &new_ptraced, 0));
	mix(&digest, child_b.ppid_parent == &pid1);
	mix(&digest, child_b.parent == &old_parent);
	mix(&digest, new_ptraced.next == &child_b.ptraced_siblings);
	mix(&digest, process_child_reparent_result(NULL,
		offsetof(struct fake_process, ppid_parent),
		offsetof(struct fake_process, parent), &pid1,
		&child_b.ptraced_siblings, &new_ptraced, 0));
	fake_list_init(&other_head);
	fake_list_init(&report_thread_a.report_siblings);
	fake_list_init(&report_thread_b.report_siblings);
	mix(&digest, process_thread_report_attach_result(&report_thread_a,
		offsetof(struct fake_thread, termsig), 1, 9,
		offsetof(struct fake_thread, report_proc), &pid1,
		&report_thread_a.report_siblings, &other_head));
	mix(&digest, report_thread_a.termsig == 9);
	mix(&digest, report_thread_a.report_proc == &pid1);
	mix(&digest, other_head.next == &report_thread_a.report_siblings);
	mix(&digest, process_thread_report_attach_result(&report_thread_b,
		offsetof(struct fake_thread, termsig), 0, 15,
		offsetof(struct fake_thread, report_proc), &old_parent,
		&report_thread_b.report_siblings, &other_head));
	mix(&digest, report_thread_b.termsig == 0);
	mix(&digest, report_thread_b.report_proc == &old_parent);
	mix(&digest, other_head.prev == &report_thread_b.report_siblings);
	mix(&digest, process_thread_report_detach_result(&report_thread_a,
		offsetof(struct fake_thread, report_proc), NULL,
		&report_thread_a.report_siblings));
	mix(&digest, report_thread_a.report_proc == NULL);
	mix(&digest, other_head.next == &report_thread_b.report_siblings);
	mix(&digest, process_thread_report_detach_result(&report_thread_b,
		offsetof(struct fake_thread, report_proc), &pid1,
		&report_thread_b.report_siblings));
	mix(&digest, report_thread_b.report_proc == &pid1);
	mix(&digest, other_head.next == &other_head);
	fake_list_init(&old_children);
	fake_list_init(&new_children);
	fake_list_init(&child_a.siblings);
	fake_list_init(&child_a.ptraced_siblings);
	child_a.parent = &old_parent;
	fake_list_add_tail(&child_a.ptraced_siblings, &old_children);
	mix(&digest, process_ptrace_main_detach_reparent_result(&child_a,
		offsetof(struct fake_process, parent), &pid1,
		&child_a.ptraced_siblings, &child_a.siblings, &new_children));
	mix(&digest, child_a.parent == &pid1);
	mix(&digest, old_children.next == &old_children);
	mix(&digest, new_children.next == &child_a.siblings);
	mix(&digest, process_ptrace_main_detach_reparent_result(NULL,
		offsetof(struct fake_process, parent), &pid1,
		&child_a.ptraced_siblings, &child_a.siblings, &new_children));
	fake_list_init(&new_children);
	fake_list_init(&child_b.siblings);
	child_b.parent = &old_parent;
	mix(&digest, process_ptrace_main_attach_reparent_result(&child_b,
		offsetof(struct fake_process, parent), &pid1,
		&child_b.siblings, &new_children));
	mix(&digest, child_b.parent == &pid1);
	mix(&digest, new_children.next == &child_b.siblings);
	mix(&digest, process_ptrace_main_attach_reparent_result(NULL,
		offsetof(struct fake_process, parent), &pid1,
		&child_b.siblings, &new_children));
	report_thread_b.termsig = 12;
	mix(&digest, process_thread_termsig_clear_result(&report_thread_b,
		offsetof(struct fake_thread, termsig), 0));
	mix(&digest, report_thread_b.termsig == 12);
	mix(&digest, process_thread_termsig_clear_result(&report_thread_b,
		offsetof(struct fake_thread, termsig), 1));
	mix(&digest, report_thread_b.termsig == 0);
	mix(&digest, process_thread_termsig_clear_result(NULL,
		offsetof(struct fake_thread, termsig), 1));
	report_thread_b.ptrace = 0x123;
	report_thread_b.ptrace_saved_uctx_valid = 1;
	report_thread_b.ptrace_debugreg = (void *)0xabc0;
	mix(&digest, process_thread_ptrace_cleanup_result(&report_thread_b,
		offsetof(struct fake_thread, ptrace),
		offsetof(struct fake_thread, ptrace_saved_uctx_valid),
		offsetof(struct fake_thread, ptrace_debugreg)) ==
		(void *)0xabc0);
	mix(&digest, report_thread_b.ptrace == 0);
	mix(&digest, report_thread_b.ptrace_saved_uctx_valid == 0);
	mix(&digest, report_thread_b.ptrace_debugreg == NULL);
	mix(&digest, process_thread_ptrace_cleanup_result(NULL,
		offsetof(struct fake_thread, ptrace),
		offsetof(struct fake_thread, ptrace_saved_uctx_valid),
		offsetof(struct fake_thread, ptrace_debugreg)) == NULL);
	report_thread_b.ptrace_saved_uctx_valid = 1;
	mix(&digest, process_thread_ptrace_saved_context_clear_result(
		&report_thread_b,
		offsetof(struct fake_thread, ptrace_saved_uctx_valid)));
	mix(&digest, report_thread_b.ptrace_saved_uctx_valid == 0);
	mix(&digest, process_thread_ptrace_saved_context_clear_result(NULL,
		offsetof(struct fake_thread, ptrace_saved_uctx_valid)));
	report_thread_b.ptrace = 0x77 | PT_TRACE_SYSCALL;
	mix(&digest, process_thread_ptrace_trace_syscall_update_result(
		&report_thread_b, offsetof(struct fake_thread, ptrace), 0));
	mix(&digest, (report_thread_b.ptrace & PT_TRACE_SYSCALL) == 0);
	mix(&digest, process_thread_ptrace_trace_syscall_update_result(
		&report_thread_b, offsetof(struct fake_thread, ptrace), 1));
	mix(&digest, (report_thread_b.ptrace & PT_TRACE_SYSCALL) != 0);
	mix(&digest, process_thread_ptrace_trace_syscall_update_result(NULL,
		offsetof(struct fake_thread, ptrace), 1));
	report_thread_b.ptrace_sendsig = (void *)0x5010;
	report_thread_b.ptrace_recvsig = (void *)0x6010;
	mix(&digest, process_thread_ptrace_pending_signal_take_result(
		&report_thread_b, offsetof(struct fake_thread, ptrace_sendsig),
		offsetof(struct fake_thread, ptrace_recvsig),
		PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG) == (void *)0x5010);
	mix(&digest, report_thread_b.ptrace_sendsig == NULL);
	mix(&digest, report_thread_b.ptrace_recvsig == (void *)0x6010);
	mix(&digest, process_thread_ptrace_pending_signal_take_result(
		&report_thread_b, offsetof(struct fake_thread, ptrace_sendsig),
		offsetof(struct fake_thread, ptrace_recvsig),
		PTRACE_RESUME_SIGNAL_SOURCE_RECVSIG) == (void *)0x6010);
	mix(&digest, report_thread_b.ptrace_recvsig == NULL);
	mix(&digest, process_thread_ptrace_pending_signal_take_result(
		&report_thread_b, offsetof(struct fake_thread, ptrace_sendsig),
		offsetof(struct fake_thread, ptrace_recvsig), 0) == NULL);
	mix(&digest, process_thread_ptrace_pending_signal_take_result(NULL,
		offsetof(struct fake_thread, ptrace_sendsig),
		offsetof(struct fake_thread, ptrace_recvsig),
		PTRACE_RESUME_SIGNAL_SOURCE_SENDSIG) == NULL);
	{
		struct fake_process_ptrace_traceme_offsets traceme_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_thread, proc),
			.thread_report_proc_offset =
				offsetof(struct fake_thread, report_proc),
			.thread_report_siblings_list_offset =
				offsetof(struct fake_thread, report_siblings),
			.thread_ptrace_offset =
				offsetof(struct fake_thread, ptrace),
			.thread_ptrace_debugreg_offset =
				offsetof(struct fake_thread, ptrace_debugreg),
			.proc_pid_offset =
				offsetof(struct fake_process, pid),
			.proc_parent_offset =
				offsetof(struct fake_process, parent),
			.proc_main_thread_offset =
				offsetof(struct fake_process, main_thread),
			.proc_children_lock_offset =
				offsetof(struct fake_process, children_lock),
			.proc_threads_lock_offset =
				offsetof(struct fake_process, threads_lock),
			.proc_ptraced_siblings_list_offset =
				offsetof(struct fake_process, ptraced_siblings),
			.proc_ptraced_children_list_offset =
				offsetof(struct fake_process,
					 ptraced_children_list),
			.proc_report_threads_list_offset =
				offsetof(struct fake_process,
					 report_threads_list),
		};

		old_parent.pid = 900;
		child_a.pid = 4242;
		child_a.parent = &old_parent;
		child_a.main_thread = &report_thread_a;
		report_thread_a.proc = &child_a;
		report_thread_a.report_proc = NULL;
		report_thread_a.ptrace = 0;
		report_thread_a.ptrace_debugreg = NULL;
		report_thread_a.clear_single_step_calls = 0;
		report_thread_a.hold_calls = 0;
		fake_list_init(&old_parent.ptraced_children_list);
		fake_list_init(&old_parent.report_threads_list);
		fake_list_init(&child_a.ptraced_siblings);
		fake_list_init(&report_thread_a.report_siblings);
		fake_ptrace_traceme_lock_calls = 0;
		fake_ptrace_traceme_unlock_calls = 0;
		fake_ptrace_traceme_alloc_calls = 0;
		fake_ptrace_traceme_alloc_rc = -55;
		fake_ptrace_traceme_log_count = 0;
		mix(&digest, process_ptrace_traceme_body_result(
			&report_thread_a, &child_a, &old_parent, &pid1,
			&traceme_offsets, &pending_head,
			fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log));
		mix(&digest, report_thread_a.ptrace ==
			(PT_TRACED | PT_TRACE_EXEC));
		mix(&digest, report_thread_a.report_proc == &old_parent);
		mix(&digest, old_parent.ptraced_children_list.next ==
			&child_a.ptraced_siblings);
		mix(&digest, old_parent.report_threads_list.next ==
			&report_thread_a.report_siblings);
		mix(&digest, fake_ptrace_traceme_lock_calls == 2);
		mix(&digest, fake_ptrace_traceme_unlock_calls == 2);
		mix(&digest, fake_ptrace_traceme_last_node == &pending_head);
		mix(&digest, fake_ptrace_traceme_alloc_calls == 1);
		mix(&digest, report_thread_a.ptrace_debugreg ==
			(void *)0xabcddcbaUL);
		mix(&digest, report_thread_a.clear_single_step_calls == 1);
		mix(&digest, report_thread_a.hold_calls == 1);
		mix(&digest, fake_ptrace_traceme_log_count == 3);
		mix(&digest, fake_ptrace_traceme_log_events[0] ==
			PROCESS_PTRACE_TRACEME_LOG_ENTER);
		mix(&digest, fake_ptrace_traceme_log_events[1] ==
			PROCESS_PTRACE_TRACEME_LOG_PARENT);
		mix(&digest, fake_ptrace_traceme_log_events[2] ==
			PROCESS_PTRACE_TRACEME_LOG_RETURN);
		mix(&digest, fake_ptrace_traceme_log_error == -55);

		report_thread_a.ptrace = PT_TRACED;
		mix(&digest, process_ptrace_traceme_body_result(
			&report_thread_a, &child_a, &old_parent, &pid1,
			&traceme_offsets, &pending_head,
			fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log) == -1);

		report_thread_a.ptrace = 0;
		child_a.parent = &pid1;
		mix(&digest, process_ptrace_traceme_body_result(
			&report_thread_a, &child_a, &pid1, &pid1,
			&traceme_offsets, &pending_head,
			fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log) == -1);
		child_a.parent = &old_parent;
	}
	{
		struct fake_process_ptrace_attach_offsets attach_offsets = {
			.thread_proc_offset =
				offsetof(struct fake_thread, proc),
			.thread_report_proc_offset =
				offsetof(struct fake_thread, report_proc),
			.thread_report_siblings_list_offset =
				offsetof(struct fake_thread, report_siblings),
			.thread_ptrace_debugreg_offset =
				offsetof(struct fake_thread, ptrace_debugreg),
			.proc_pid_offset =
				offsetof(struct fake_process, pid),
			.proc_parent_offset =
				offsetof(struct fake_process, parent),
			.proc_main_thread_offset =
				offsetof(struct fake_process, main_thread),
			.proc_children_lock_offset =
				offsetof(struct fake_process, children_lock),
			.proc_threads_lock_offset =
				offsetof(struct fake_process, threads_lock),
			.proc_children_list_offset =
				offsetof(struct fake_process, children_list),
			.proc_siblings_list_offset =
				offsetof(struct fake_process, siblings),
			.proc_ptraced_siblings_list_offset =
				offsetof(struct fake_process, ptraced_siblings),
			.proc_ptraced_children_list_offset =
				offsetof(struct fake_process,
					 ptraced_children_list),
			.proc_report_threads_list_offset =
				offsetof(struct fake_process,
					 report_threads_list),
		};

		old_parent.pid = 901;
		child_a.parent = &old_parent;
		child_a.main_thread = &report_thread_a;
		report_thread_a.proc = &child_a;
		report_thread_a.report_proc = &old_parent;
		report_thread_a.ptrace_debugreg = NULL;
		report_thread_a.clear_single_step_calls = 0;
		report_thread_a.hold_calls = 0;
		fake_list_init(&old_parent.children_list);
		fake_list_init(&old_parent.ptraced_children_list);
		fake_list_init(&old_parent.report_threads_list);
		fake_list_init(&pid1.children_list);
		fake_list_init(&pid1.report_threads_list);
		fake_list_init(&child_a.siblings);
		fake_list_init(&child_a.ptraced_siblings);
		fake_list_init(&report_thread_a.report_siblings);
		fake_list_add_tail(&child_a.siblings,
				   &old_parent.children_list);
		fake_list_add_tail(&report_thread_a.report_siblings,
				   &old_parent.report_threads_list);
		fake_ptrace_traceme_lock_calls = 0;
		fake_ptrace_traceme_unlock_calls = 0;
		fake_ptrace_traceme_alloc_calls = 0;
		fake_ptrace_traceme_alloc_rc = 0;
		fake_ptrace_traceme_log_count = 0;
		mix(&digest, process_ptrace_attach_thread_body_result(
			&report_thread_a, &pid1, &attach_offsets,
			&pending_head, fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log));
		mix(&digest, report_thread_a.report_proc == &pid1);
		mix(&digest, old_parent.report_threads_list.next ==
			&old_parent.report_threads_list);
		mix(&digest, pid1.report_threads_list.next ==
			&report_thread_a.report_siblings);
		mix(&digest, old_parent.children_list.next ==
			&old_parent.children_list);
		mix(&digest, old_parent.ptraced_children_list.next ==
			&child_a.ptraced_siblings);
		mix(&digest, child_a.parent == &pid1);
		mix(&digest, pid1.children_list.next == &child_a.siblings);
		mix(&digest, fake_ptrace_traceme_lock_calls == 4);
		mix(&digest, fake_ptrace_traceme_unlock_calls == 4);
		mix(&digest, fake_ptrace_traceme_last_node == &pending_head);
		mix(&digest, fake_ptrace_traceme_alloc_calls == 1);
		mix(&digest, report_thread_a.ptrace_debugreg ==
			(void *)0xabcddcbaUL);
		mix(&digest, report_thread_a.hold_calls == 1);
		mix(&digest, report_thread_a.clear_single_step_calls == 1);
		mix(&digest, fake_ptrace_traceme_log_count == 1);
		mix(&digest, fake_ptrace_traceme_log_events[0] ==
			PROCESS_PTRACE_TRACEME_LOG_PARENT);
		mix(&digest, fake_ptrace_traceme_log_pid == old_parent.pid);

		child_b.main_thread = &report_thread_a;
		report_thread_b.proc = &child_b;
		report_thread_b.report_proc = NULL;
		report_thread_b.ptrace_debugreg = NULL;
		report_thread_b.clear_single_step_calls = 0;
		report_thread_b.hold_calls = 0;
		fake_list_init(&pid1.report_threads_list);
		fake_list_init(&report_thread_b.report_siblings);
		fake_ptrace_traceme_lock_calls = 0;
		fake_ptrace_traceme_unlock_calls = 0;
		fake_ptrace_traceme_alloc_calls = 0;
		fake_ptrace_traceme_alloc_rc = -55;
		mix(&digest, process_ptrace_attach_thread_body_result(
			&report_thread_b, &pid1, &attach_offsets,
			&pending_head, fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log) == -55);
		mix(&digest, report_thread_b.report_proc == &pid1);
		mix(&digest, pid1.report_threads_list.next ==
			&report_thread_b.report_siblings);
		mix(&digest, fake_ptrace_traceme_alloc_calls == 1);
		mix(&digest, report_thread_b.hold_calls == 0);
		mix(&digest, report_thread_b.clear_single_step_calls == 0);
		mix(&digest, fake_ptrace_traceme_lock_calls == 1);
		mix(&digest, fake_ptrace_traceme_unlock_calls == 1);

		report_thread_b.report_proc = NULL;
		report_thread_b.ptrace_debugreg = (void *)0xbadcafeUL;
		report_thread_b.clear_single_step_calls = 0;
		report_thread_b.hold_calls = 0;
		fake_list_init(&pid1.report_threads_list);
		fake_list_init(&report_thread_b.report_siblings);
		fake_ptrace_traceme_lock_calls = 0;
		fake_ptrace_traceme_unlock_calls = 0;
		fake_ptrace_traceme_alloc_calls = 0;
		fake_ptrace_traceme_alloc_rc = 0;
		mix(&digest, process_ptrace_attach_thread_body_result(
			&report_thread_b, &pid1, &attach_offsets,
			&pending_head, fake_ptrace_traceme_lock,
			fake_ptrace_traceme_unlock,
			fake_ptrace_traceme_alloc_debugreg,
			fake_ptrace_traceme_clear_single_step,
			fake_ptrace_traceme_hold_thread,
			fake_ptrace_traceme_log));
		mix(&digest, report_thread_b.report_proc == &pid1);
		mix(&digest, pid1.report_threads_list.next ==
			&report_thread_b.report_siblings);
		mix(&digest, fake_ptrace_traceme_alloc_calls == 0);
		mix(&digest, report_thread_b.hold_calls == 1);
		mix(&digest, report_thread_b.clear_single_step_calls == 1);
		mix(&digest, fake_ptrace_traceme_lock_calls == 1);
		mix(&digest, fake_ptrace_traceme_unlock_calls == 1);
	}
	report_thread_b.signal_flags =
		SIGNAL_STOP_STOPPED | SIGNAL_STOP_CONTINUED;
	mix(&digest, process_thread_signal_flags_reap_result(&report_thread_b,
		offsetof(struct fake_thread, signal_flags), 0,
		SIGNAL_STOP_STOPPED));
	mix(&digest, report_thread_b.signal_flags == SIGNAL_STOP_CONTINUED);
	mix(&digest, process_thread_signal_flags_reap_result(&report_thread_b,
		offsetof(struct fake_thread, signal_flags), WNOWAIT,
		SIGNAL_STOP_CONTINUED));
	mix(&digest, report_thread_b.signal_flags == SIGNAL_STOP_CONTINUED);
	mix(&digest, process_thread_signal_flags_reap_result(NULL,
		offsetof(struct fake_thread, signal_flags), 0,
		SIGNAL_STOP_CONTINUED));
	report_thread_b.exit_status = 0x7f;
	mix(&digest, process_wait_exit_status_reap_result(&report_thread_b,
		offsetof(struct fake_thread, exit_status), WNOWAIT));
	mix(&digest, report_thread_b.exit_status == 0x7f);
	mix(&digest, process_wait_exit_status_reap_result(&report_thread_b,
		offsetof(struct fake_thread, exit_status), 0));
	mix(&digest, report_thread_b.exit_status == 0);
	child_a.group_exit_status = 0x55;
	mix(&digest, process_wait_exit_status_reap_result(&child_a,
		offsetof(struct fake_process, group_exit_status), 0));
	mix(&digest, child_a.group_exit_status == 0);
	mix(&digest, process_wait_exit_status_reap_result(NULL,
		offsetof(struct fake_thread, exit_status), 0));
	mix(&digest, process_thread_report_attach_result(NULL,
		offsetof(struct fake_thread, termsig), 1, 9,
		offsetof(struct fake_thread, report_proc), &pid1,
		&report_thread_b.report_siblings, &other_head));
	mix(&digest, process_optional_ptr_should_free_result(0));
	mix(&digest, process_optional_ptr_should_free_result(0x6000));
	mix(&digest, process_hold_thread_warn_exited_result(PS_EXITED));
	mix(&digest, process_hold_thread_warn_exited_result(0));
	mix(&digest, process_sigcommon_release_should_destroy_result(0));
	mix(&digest, process_sigcommon_release_should_destroy_result(1));
	mix(&digest, process_destroy_thread_tid_action_result(0, 0,
							     UTI_STATE_RUNNING_IN_LINUX));
	mix(&digest, process_destroy_thread_tid_action_result(1, 0,
							     UTI_STATE_RUNNING_IN_LINUX));
	mix(&digest, process_destroy_thread_tid_action_result(1, 1,
							     UTI_STATE_RUNNING_IN_LINUX));
	mix(&digest, process_destroy_thread_tid_action_result(1, 0,
							     UTI_STATE_EPILOGUE));
	mix(&digest, process_thread_should_free_pages_result(0));
	mix(&digest, process_thread_should_free_pages_result(1));
	mix(&digest, process_release_vm_should_run_free_cb_result(0));
	mix(&digest, process_release_vm_should_run_free_cb_result(0x1000));
	mix(&digest, process_release_mckfd_should_close_result(0));
	mix(&digest, process_release_mckfd_should_close_result(0x2000));
	fd_head = NULL;
	fd_a.next = NULL;
	fd_b.next = NULL;
	mix(&digest, process_mckfd_push_head_result(&fd_head, &fd_a));
	mix(&digest, fd_head == &fd_a);
	mix(&digest, fd_a.next == NULL);
	mix(&digest, process_mckfd_push_head_result(&fd_head, &fd_b));
	mix(&digest, fd_head == &fd_b);
	mix(&digest, fd_b.next == &fd_a);
	mix(&digest, process_mckfd_push_head_result(NULL, &fd_a));
	mix(&digest, process_mckfd_push_head_result(&fd_head, NULL));
	fd = process_mckfd_pop_head_result(&fd_head);
	mix(&digest, fd == &fd_b);
	mix(&digest, fd_head == &fd_a);
	mix(&digest, fd_b.next == NULL);
	fd = process_mckfd_pop_head_result(&fd_head);
	mix(&digest, fd == &fd_a);
	mix(&digest, fd_head == NULL);
	mix(&digest, process_mckfd_pop_head_result(&fd_head) == NULL);
	{
		struct fake_rb_root root = { 0 };
		struct fake_vm_range range = {
			.vm_rb_node = { 1, NULL, NULL },
			.start = 0x1000,
			.end = 0x5000,
		};
		struct fake_policy policy = {
			.policy_rb_node = { 1, NULL, NULL },
			.id = 17,
		};
		struct fake_release_process rel_proc = {
			.vm = (void *)0xabc,
			.pid = 42,
		};
		struct fake_release_vm rel_vm = {
			.address_space = (void *)0xfeed000UL,
			.proc = &rel_proc,
		};
		struct fake_thread cleanup_thread = {
			.ptrace_debugreg = (void *)0x10,
			.ptrace_sendsig = (void *)0x20,
			.ptrace_recvsig = (void *)0x40,
			.fp_regs = (void *)0x80,
			.coredump_regs = (void *)0x100,
		};

		reset_process_release_trace();
		fd_a.next = &fd_b;
		fd_a.close_cb = fake_mckfd_close;
		fd_b.next = NULL;
		fd_b.close_cb = fake_mckfd_close;
		mix(&digest, process_mckfd_close_all_result(&fd_a,
			offsetof(struct fake_mckfd, next),
			offsetof(struct fake_mckfd, close_cb)));
		require(process_mckfd_close_count == 2);
		require(process_mckfd_close_fd_sum == 7);
		fd_head = &fd_a;
		mix(&digest, process_mckfd_drain_free_result(&fd_head,
			offsetof(struct fake_mckfd, next), fake_mckfd_free));
		require(fd_head == NULL);
		require(fd_a.next == NULL);
		require(process_mckfd_free_count == 2);
		require(process_mckfd_free_fd_sum == 7);
		mix(&digest, process_mckfd_free_fd_sum);

		root.rb_node = &range.vm_rb_node;
		process_memory_free_rc = -7;
		mix(&digest, process_memory_range_free_all_result(&rel_vm,
			&root, offsetof(struct fake_vm_range, vm_rb_node),
			fake_memory_range_free, fake_memory_range_log));
		require(process_memory_free_count == 1);
		require(process_memory_log_count == 1);
		require(process_memory_log_start == 0x1000);
		require(process_memory_log_end == 0x5000);
		require(process_memory_log_error == -7);
		mix(&digest, process_memory_log_end);

		{
			struct fake_process_vm_full flush_vm = { 0 };
			struct fake_vm_range flush_left = {
				.vm_rb_node = { 0, NULL, NULL },
				.start = 0x1000,
				.end = 0x2000,
				.memobj = (void *)0x10,
			};
			struct fake_vm_range flush_mid = {
				.vm_rb_node = { 0, NULL, NULL },
				.start = 0x3000,
				.end = 0x4000,
				.memobj = NULL,
			};
			struct fake_vm_range flush_right = {
				.vm_rb_node = { 0, NULL, NULL },
				.start = 0x5000,
				.end = 0x6000,
				.memobj = (void *)0x20,
			};

			flush_mid.vm_rb_node.rb_left = &flush_left.vm_rb_node;
			flush_mid.vm_rb_node.rb_right = &flush_right.vm_rb_node;
			flush_left.vm_rb_node.__rb_parent_color =
				(unsigned long)(uintptr_t)&flush_mid.vm_rb_node;
			flush_right.vm_rb_node.__rb_parent_color =
				(unsigned long)(uintptr_t)&flush_mid.vm_rb_node;
			flush_vm.vm_range_tree.rb_node = &flush_mid.vm_rb_node;

			reset_process_release_trace();
			reset_range_access_trace();
			process_memory_free_rc = -5;
			process_memory_free_fail_start = flush_right.start;
			mix(&digest, process_flush_memory_body_result(&flush_vm,
				fake_range_lock, fake_range_unlock,
				fake_memory_range_free, fake_memory_range_log));
			require(flush_vm.exiting == 1);
			require(process_range_lock_count == 1);
			require(process_range_unlock_count == 1);
			require(process_range_lock_addr ==
				(unsigned long)(uintptr_t)&flush_vm.memory_range_lock);
			require(process_range_unlock_addr == process_range_lock_addr);
			require(process_memory_free_count == 2);
			require(process_memory_free_start_xor ==
				(flush_left.start ^ flush_right.start));
			require(process_memory_log_count == 1);
			require(process_memory_log_start == flush_right.start);
			require(process_memory_log_end == flush_right.end);
			require(process_memory_log_error == -5);
			mix(&digest, process_memory_free_start_xor);
			mix(&digest, process_memory_log_error);

			flush_vm = (struct fake_process_vm_full){ 0 };
			reset_process_release_trace();
			reset_range_access_trace();
			mix(&digest, process_flush_memory_body_result(&flush_vm,
				fake_range_lock, fake_range_unlock,
				fake_memory_range_free, fake_memory_range_log));
			require(flush_vm.exiting == 1);
			require(process_range_lock_count == 1);
			require(process_range_unlock_count == 1);
			require(process_memory_free_count == 0);
			require(process_memory_log_count == 0);

			flush_vm = (struct fake_process_vm_full){ 0 };
			flush_vm.vm_range_tree.rb_node = &flush_mid.vm_rb_node;
			reset_process_release_trace();
			reset_range_access_trace();
			process_memory_free_rc = -6;
			process_memory_free_fail_start = flush_mid.start;
			mix(&digest,
				process_free_all_memory_ranges_body_result(&flush_vm,
					fake_range_lock, fake_range_unlock,
					fake_memory_range_free,
					fake_memory_range_log));
			require(flush_vm.exiting == 0);
			require(process_range_lock_count == 1);
			require(process_range_unlock_count == 1);
			require(process_memory_free_count == 3);
			require(process_memory_free_start_xor ==
				(flush_left.start ^ flush_mid.start ^
				 flush_right.start));
			require(process_memory_log_count == 1);
			require(process_memory_log_start == flush_mid.start);
			require(process_memory_log_end == flush_mid.end);
			require(process_memory_log_error == -6);
			mix(&digest, process_memory_free_start_xor);
		}

		{
			unsigned long cpuset[16] = { 0 };
			unsigned long cpulock = 0;

			reset_process_release_trace();
			mix(&digest, process_cpu_set_update_body_result(
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock,
				-1, 5, 1024, fake_spin_lock,
				fake_spin_unlock));
			require(cpuset[0] == (1UL << 5));
			require(process_spin_lock_count == 1);
			require(process_spin_unlock_count == 1);
			require(process_spin_unlock_irq == 0x12345678UL);

			mix(&digest, process_cpu_set_update_body_result(
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock,
				5, 130, 1024, fake_spin_lock,
				fake_spin_unlock));
			require(cpuset[0] == 0);
			require(cpuset[2] == (1UL << 2));
			require(process_spin_lock_count == 2);
			require(process_spin_unlock_count == 2);

			mix(&digest, process_cpu_set_update_body_result(
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock,
				-4, 2048, 1024, fake_spin_lock,
				fake_spin_unlock));
			require(cpuset[2] == (1UL << 2));
			require(process_spin_lock_count == 3);
			require(process_spin_unlock_count == 3);
			mix(&digest, cpuset[0]);
			mix(&digest, cpuset[2]);
			mix(&digest, process_lifecycle_order);
		}

		{
			unsigned long cpuset[16] = { 0 };
			unsigned long cpulock = 0;
			int rc;

			reset_process_release_trace();
			rc = process_cpu_set_public_result(7,
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock, 1024,
				fake_spin_lock, fake_spin_unlock);
			require(rc == 1);
			require(cpuset[0] == (1UL << 7));
			require(process_spin_lock_count == 1);
			require(process_spin_unlock_count == 1);
			require(process_spin_unlock_irq == 0x12345678UL);

			rc = process_cpu_clear_public_result(7,
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock, 1024,
				fake_spin_lock, fake_spin_unlock);
			require(rc == 1);
			require(cpuset[0] == 0);
			require(process_spin_lock_count == 2);
			require(process_spin_unlock_count == 2);

			cpuset[0] = 1UL << 3;
			rc = process_cpu_clear_and_set_public_result(3, 130,
				(unsigned long)(uintptr_t)cpuset,
				(unsigned long)(uintptr_t)&cpulock, 1024,
				fake_spin_lock, fake_spin_unlock);
			require(rc == 2);
			require(cpuset[0] == 0);
			require(cpuset[2] == (1UL << 2));
			require(process_spin_lock_count == 3);
			require(process_spin_unlock_count == 3);
			require(process_cpu_set_public_result(1, 0,
				(unsigned long)(uintptr_t)&cpulock, 1024,
				fake_spin_lock, fake_spin_unlock) == -22);
			require(process_spin_lock_count == 3);
			mix(&digest, cpuset[0]);
			mix(&digest, cpuset[2]);
			mix(&digest, (unsigned long)process_spin_unlock_count);
		}

		{
			struct fake_hold_thread {
				int status;
				int refcount;
			} hold = {
				.status = PS_EXITED,
				.refcount = 4,
			};
			struct fake_ref_object {
				int pad;
				int refcount;
			} ref_object = {
				.pad = 7,
				.refcount = 41,
			};

			reset_process_release_trace();
			mix(&digest, process_ref_hold_body_result(&ref_object,
				offsetof(struct fake_ref_object, refcount),
				fake_ref_inc));
			require(process_ref_inc_count == 1);
			require(process_ref_inc_object == &ref_object);
			require(process_ref_inc_offset ==
				offsetof(struct fake_ref_object, refcount));
			require(ref_object.refcount == 42);
			mix(&digest, ref_object.refcount);

			ref_object.refcount = 10;
			mix(&digest, process_ref_inc_direct_result(&ref_object,
				offsetof(struct fake_ref_object, refcount)));
			require(ref_object.refcount == 11);
			mix(&digest, process_ref_inc_result(&ref_object,
				offsetof(struct fake_ref_object, refcount),
				NULL));
			require(ref_object.refcount == 12);
			mix(&digest, process_ref_set_direct_result(&ref_object,
				offsetof(struct fake_ref_object, refcount), 2));
			require(ref_object.refcount == 2);
			mix(&digest, process_ref_set_result(&ref_object,
				offsetof(struct fake_ref_object, refcount), 1,
				NULL));
			require(ref_object.refcount == 1);
			mix(&digest, process_ref_dec_and_test_direct_result(
				&ref_object,
				offsetof(struct fake_ref_object, refcount)));
			require(ref_object.refcount == 0);
			ref_object.refcount = 2;
			mix(&digest, process_ref_dec_and_test_result(&ref_object,
				offsetof(struct fake_ref_object, refcount),
				NULL));
			require(ref_object.refcount == 1);
			mix(&digest, process_ref_hold_body_result(&ref_object,
				offsetof(struct fake_ref_object, refcount),
				NULL));
			require(ref_object.refcount == 2);
			mix(&digest, ref_object.refcount);

			mix(&digest, process_hold_thread_body_result(&hold,
				offsetof(struct fake_hold_thread, status),
				offsetof(struct fake_hold_thread, refcount),
				fake_ref_inc, fake_hold_warn));
			require(hold.refcount == 5);
			require(process_ref_inc_count == 2);
			require(process_hold_warn_count == 1);
			require(process_hold_warn_thread == &hold);
			mix(&digest, hold.refcount);
			mix(&digest, process_hold_warn_count);

			hold.status = 0;
			mix(&digest, process_hold_thread_body_result(&hold,
				offsetof(struct fake_hold_thread, status),
				offsetof(struct fake_hold_thread, refcount),
				fake_ref_inc, fake_hold_warn));
			require(hold.refcount == 6);
			require(process_ref_inc_count == 3);
			require(process_hold_warn_count == 1);
			mix(&digest, hold.refcount);
		}

		{
			struct fake_release_process_body {
				int refcount;
				void *tids;
				void *main_thread;
				struct fake_mckfd *mckfd;
				unsigned long mckfd_lock;
			} release_body = {
				.refcount = 1,
				.tids = (void *)0x12345000UL,
				.main_thread = (void *)0x77770000UL,
			};
			struct fake_mckfd proc_fd_a = { 0, 41, NULL };
			struct fake_mckfd proc_fd_b = { 0, 42, NULL };

			proc_fd_a.next = &proc_fd_b;
			release_body.mckfd = &proc_fd_a;
			reset_process_release_trace();
			mix(&digest, process_release_process_body_result(
				&release_body,
				offsetof(struct fake_release_process_body,
					 refcount),
				offsetof(struct fake_release_process_body, tids),
				offsetof(struct fake_release_process_body,
					 main_thread),
				offsetof(struct fake_release_process_body, mckfd),
				offsetof(struct fake_release_process_body,
					 mckfd_lock),
				offsetof(struct fake_mckfd, next),
				fake_ref_dec_and_test,
				fake_current_resource_set,
				fake_release_hash_detach,
				fake_release_sibling_detach,
				fake_release_profile,
				fake_release_thread_pages,
				fake_spin_lock,
				fake_spin_unlock,
				fake_mckfd_free,
				fake_optional_free,
				fake_release_final_cleanup));
			require(process_ref_dec_count == 1);
			require(process_release_resource_count == 1);
			require(process_release_hash_count == 1);
			require(process_release_sibling_count == 1);
			require(process_optional_free_count == 2);
			require(process_release_profile_count == 1);
			require(process_release_thread_pages_count == 1);
			require(process_release_thread_pages_thread ==
				(void *)0x77770000UL);
			require(process_spin_lock_count == 1);
			require(process_spin_unlock_count == 1);
			require(process_mckfd_free_count == 2);
			require(process_mckfd_free_fd_sum == 83);
			require(release_body.mckfd == NULL);
			require(process_release_final_count == 1);
			require(process_release_final_resource ==
				process_release_resource_value);
			mix(&digest, process_lifecycle_order);
			mix(&digest, process_mckfd_free_fd_sum);

			release_body.refcount = 0;
			release_body.mckfd = &proc_fd_a;
			proc_fd_a.next = NULL;
			reset_process_release_trace();
			mix(&digest, process_release_process_body_result(
				&release_body,
				offsetof(struct fake_release_process_body,
					 refcount),
				offsetof(struct fake_release_process_body, tids),
				offsetof(struct fake_release_process_body,
					 main_thread),
				offsetof(struct fake_release_process_body, mckfd),
				offsetof(struct fake_release_process_body,
					 mckfd_lock),
				offsetof(struct fake_mckfd, next),
				fake_ref_dec_and_test,
				fake_current_resource_set,
				fake_release_hash_detach,
				fake_release_sibling_detach,
				fake_release_profile,
				fake_release_thread_pages,
				fake_spin_lock,
				fake_spin_unlock,
				fake_mckfd_free,
				fake_optional_free,
				fake_release_final_cleanup));
			require(process_ref_dec_count == 1);
			require(process_release_resource_count == 0);
			require(process_mckfd_free_count == 0);
			require(release_body.mckfd == &proc_fd_a);
		}

		root.rb_node = &policy.policy_rb_node;
		mix(&digest, process_vm_policy_drain_free_result(&root,
			offsetof(struct fake_policy, policy_rb_node),
			fake_policy_free));
		require(root.rb_node == NULL);
		require(process_policy_free_count == 1);
		require(process_policy_free_id_sum == 17);
		mix(&digest, process_policy_free_id_sum);

		mix(&digest, process_release_vm_detach_process_result(&rel_vm,
			offsetof(struct fake_release_vm, address_space),
			offsetof(struct fake_release_vm, proc),
			offsetof(struct fake_release_process, pid),
			offsetof(struct fake_release_process, vm),
			fake_detach_address_space, fake_release_process));
		require(process_detach_count == 1);
		require(process_detach_pid == 42);
		require(process_detach_address_space == rel_vm.address_space);
		require(process_release_count == 1);
		require(process_release_last_proc == &rel_proc);
		require(rel_proc.vm == NULL);
		mix(&digest, process_detach_pid);

		mix(&digest, process_destroy_thread_optional_cleanup_result(
			&cleanup_thread,
			offsetof(struct fake_thread, ptrace_debugreg),
			offsetof(struct fake_thread, ptrace_recvsig),
			offsetof(struct fake_thread, ptrace_sendsig),
			offsetof(struct fake_thread, fp_regs),
			offsetof(struct fake_thread, coredump_regs),
			fake_optional_free, fake_release_fp_regs));
		require(process_optional_free_count == 4);
		require(process_optional_free_xor ==
			(0x10UL ^ 0x20UL ^ 0x40UL ^ 0x100UL));
		require(process_release_fp_count == 1);
		require(process_release_fp_thread == &cleanup_thread);
		mix(&digest, process_optional_free_xor);

		{
			struct fake_sigcommon sigcommon;
			struct fake_pending rel_pending_a = { { 0 }, 0xc1 };
			struct fake_pending rel_pending_b = { { 0 }, 0xc2 };

			reset_process_release_trace();
			fake_list_init(&sigcommon.sigpending);
			fake_list_init(&rel_pending_a.list);
			fake_list_init(&rel_pending_b.list);
			fake_list_add_tail(&rel_pending_a.list,
					   &sigcommon.sigpending);
			fake_list_add_tail(&rel_pending_b.list,
					   &sigcommon.sigpending);
			mix(&digest, process_release_sigcommon_body_result(
				&sigcommon, 1, 0,
				offsetof(struct fake_sigcommon, sigpending),
				offsetof(struct fake_pending, list),
				fake_optional_free));
			require(process_optional_free_count == 3);
			require(process_optional_free_xor ==
				((unsigned long)&rel_pending_a ^
				 (unsigned long)&rel_pending_b ^
				 (unsigned long)&sigcommon));
			mix(&digest, process_optional_free_count);
			mix(&digest, process_release_sigcommon_body_result(
				&sigcommon, 0, 1,
				offsetof(struct fake_sigcommon, sigpending),
				offsetof(struct fake_pending, list),
				fake_optional_free));
			require(process_optional_free_count == 3);
		}

		{
			struct fake_sigcommon sigcommon = {
				.use = 1,
			};
			struct fake_pending rel_pending = { { 0 }, 0xc3 };

			reset_process_release_trace();
			fake_list_init(&sigcommon.sigpending);
			fake_list_init(&rel_pending.list);
			fake_list_add_tail(&rel_pending.list,
					   &sigcommon.sigpending);
			mix(&digest,
				process_release_sigcommon_public_body_result(
					&sigcommon,
					offsetof(struct fake_sigcommon, use),
					offsetof(struct fake_sigcommon,
						 sigpending),
					offsetof(struct fake_pending, list),
					fake_ref_dec_and_test,
					fake_optional_free));
			require(process_ref_dec_count == 1);
			require(process_optional_free_count == 2);
			require(process_optional_free_xor ==
				((unsigned long)&rel_pending ^
				 (unsigned long)&sigcommon));
			mix(&digest, process_optional_free_count);

			sigcommon.use = 0;
			fake_list_init(&sigcommon.sigpending);
			reset_process_release_trace();
			mix(&digest,
				process_release_sigcommon_public_body_result(
					&sigcommon,
					offsetof(struct fake_sigcommon, use),
					offsetof(struct fake_sigcommon,
						 sigpending),
					offsetof(struct fake_pending, list),
					fake_ref_dec_and_test,
					fake_optional_free));
			require(process_ref_dec_count == 1);
			require(process_optional_free_count == 0);
		}

		{
			struct fake_release_thread rel_thread = {
				.refcount = 1,
				.vm = &rel_vm,
				.proc = &rel_proc,
			};

			reset_process_release_trace();
			tids[0].thread = &rel_thread;
			tids[0].tid = 21;
			mix(&digest, process_release_tid_body_result(tids, 3,
				sizeof(tids[0]), offsetof(struct fake_tid, thread),
				&rel_thread, 21, fake_tid_log));
			require(tids[0].thread == NULL);
			require(process_tid_log_count == 1);
			require(process_tid_log_tid == 21);
			require(process_tid_log_thread == &rel_thread);
			mix(&digest, process_tid_log_tid);

			tids[1].thread = &rel_thread;
			tids[1].tid = 22;
			mix(&digest, process_replace_tid_body_result(tids, 3,
				sizeof(tids[0]), offsetof(struct fake_tid, tid),
				offsetof(struct fake_tid, thread), &rel_thread,
				22, 88, fake_tid_log));
			require(tids[1].thread == NULL);
			require(tids[1].tid == 88);
			require(process_tid_log_count == 2);
			require(process_tid_log_new_tid == 88);
			mix(&digest, tids[1].tid);

			{
				struct fake_list_head child_sibling;
				struct fake_list_head parent_children;
				struct fake_list_head proc_hash;
				struct fake_list_head hash_head;
				unsigned long lock_node = 0xabcdefUL;

				reset_process_release_trace();
				fake_list_init(&child_sibling);
				fake_list_init(&parent_children);
				fake_list_init(&proc_hash);
				fake_list_init(&hash_head);
				mix(&digest, process_chain_process_body_result(
					&child_sibling, &parent_children,
					0x1000UL, &proc_hash, &hash_head, 0x2000UL,
					&lock_node, fake_process_mcs_lock,
					fake_process_mcs_unlock));
				require(parent_children.next == &child_sibling);
				require(hash_head.next == &proc_hash);
				require(process_mcs_lock_count == 2);
				require(process_mcs_unlock_count == 2);
				require(process_mcs_lock_addr == 0x2000UL);
				require(process_mcs_unlock_addr == 0x2000UL);
				require(process_mcs_lock_node == &lock_node);
				mix(&digest, (unsigned long)process_mcs_lock_count);
			}

			{
				struct fake_list_head thread_sibling;
				struct fake_list_head proc_threads;
				struct fake_list_head thread_hash;
				struct fake_list_head hash_head;
				struct {
					int refcount;
				} chain_vm = { .refcount = 3 };
				unsigned long lock_node = 0xf00dUL;

				reset_process_release_trace();
				fake_list_init(&thread_sibling);
				fake_list_init(&proc_threads);
				fake_list_init(&thread_hash);
				fake_list_init(&hash_head);
				mix(&digest, process_chain_thread_body_result(
					&thread_sibling, &proc_threads, 0x3000UL,
					&thread_hash, &hash_head, 0x4000UL,
					&chain_vm, 0,
					&lock_node, fake_process_mcs_lock,
					fake_process_mcs_unlock, fake_ref_inc));
				require(proc_threads.next == &thread_sibling);
				require(hash_head.next == &thread_hash);
				require(process_mcs_lock_count == 2);
				require(process_ref_inc_count == 1);
				require(chain_vm.refcount == 4);
				mix(&digest, (unsigned long)chain_vm.refcount);
			}

			{
				struct fake_destroy_proc dproc = {
					.tids = tids,
				};
				struct fake_destroy_proc main_proc = { 0 };
				struct fake_destroy_thread main_thread = {
					.proc = &main_proc,
				};
				struct fake_destroy_address_space das = { 0 };
				struct fake_destroy_vm dvm = {
					.address_space = &das,
				};
				struct fake_destroy_thread dthread = {
					.proc = &dproc,
					.vm = &dvm,
					.cpu_id = 5,
					.uti_state = UTI_STATE_RUNNING_IN_LINUX,
					.sigcommon = (void *)0xbeef000UL,
					.ptrace_debugreg = (void *)0x10,
					.ptrace_recvsig = (void *)0x20,
					.ptrace_sendsig = (void *)0x40,
					.fp_regs = (void *)0x80,
					.coredump_regs = (void *)0x100,
				};
				struct fake_pending pending_a = { { 0 }, 0xd1 };
				struct fake_pending pending_b = { { 0 }, 0xd2 };
				struct fake_list_head thread_head;
				unsigned long lock_node = 0x5555UL;

				dproc.main_thread = &main_thread;
				das.cpu_set[0] = 1UL << 5;
				fake_list_init(&thread_head);
				fake_list_init(&dthread.siblings_list);
				fake_list_add_tail(&dthread.siblings_list, &thread_head);
				fake_list_init(&dthread.sigpending);
				fake_list_init(&pending_a.list);
				fake_list_init(&pending_b.list);
				fake_list_add_tail(&pending_a.list,
						   &dthread.sigpending);
				fake_list_add_tail(&pending_b.list,
						   &dthread.sigpending);
				reset_process_release_trace();
				mix(&digest, process_destroy_thread_body_result(
					&dthread,
					offsetof(struct fake_destroy_thread, proc),
					offsetof(struct fake_destroy_thread, vm),
					offsetof(struct fake_destroy_thread, cpu_id),
					offsetof(struct fake_destroy_thread,
						 siblings_list),
					offsetof(struct fake_destroy_thread,
						 uti_state),
					offsetof(struct fake_destroy_thread,
						 uti_refill_tid),
					offsetof(struct fake_destroy_thread,
						 sigpending),
					offsetof(struct fake_destroy_thread,
						 sigcommon),
					offsetof(struct fake_destroy_proc,
						 threads_lock),
					offsetof(struct fake_destroy_proc, tids),
					offsetof(struct fake_destroy_proc,
						 main_thread),
					offsetof(struct fake_destroy_vm,
						 address_space),
					offsetof(struct fake_destroy_address_space,
						 cpu_set),
					offsetof(struct fake_destroy_address_space,
						 cpu_set_lock),
					offsetof(struct fake_pending, list),
					offsetof(struct fake_destroy_thread,
						 ptrace_debugreg),
					offsetof(struct fake_destroy_thread,
						 ptrace_recvsig),
					offsetof(struct fake_destroy_thread,
						 ptrace_sendsig),
					offsetof(struct fake_destroy_thread, fp_regs),
					offsetof(struct fake_destroy_thread,
						 coredump_regs),
					128, &lock_node, fake_process_mcs_lock,
					fake_process_mcs_unlock,
					fake_destroy_hash_detach,
					fake_destroy_time_account,
					fake_destroy_release_tid,
					fake_destroy_replace_tid, fake_spin_lock,
					fake_spin_unlock, fake_optional_free,
					fake_release_fp_regs,
					fake_destroy_release_sigcommon,
					fake_release_thread_pages));
				require(process_destroy_hash_detach_count == 1);
				require(process_destroy_hash_detach_thread == &dthread);
				require(process_destroy_time_count == 1);
				require(process_mcs_lock_count == 1);
				require(process_mcs_unlock_count == 1);
				require(process_mcs_lock_addr ==
					(unsigned long)(uintptr_t)&dproc.threads_lock);
				require(thread_head.next == &thread_head);
				require(dthread.siblings_list.next ==
					(struct fake_list_head *)0x00100129UL);
				require(dthread.siblings_list.prev ==
					(struct fake_list_head *)0x00200229UL);
				require(process_destroy_release_tid_count == 1);
				require(process_destroy_replace_tid_count == 0);
				require(process_destroy_tid_proc == &dproc);
				require(process_destroy_tid_thread == &dthread);
				require(das.cpu_set[0] == 0);
				require(process_spin_lock_count == 1);
				require(dthread.sigpending.next == &dthread.sigpending);
				require(process_optional_free_count == 6);
				require(process_optional_free_xor ==
					((unsigned long)&pending_a ^
					 (unsigned long)&pending_b ^
					 0x10UL ^ 0x20UL ^ 0x40UL ^ 0x100UL));
				require(process_release_fp_count == 1);
				require(process_destroy_release_sigcommon_count == 1);
				require(process_destroy_release_sigcommon_ptr ==
					(void *)0xbeef000UL);
				require(process_release_thread_pages_count == 1);
				require(process_release_thread_pages_thread == &dthread);
				mix(&digest, (unsigned long)process_optional_free_count);
				mix(&digest, (unsigned long)process_mcs_unlock_count);
			}

			{
				struct fake_destroy_proc dproc = {
					.tids = tids,
				};
				struct fake_destroy_address_space das = { 0 };
				struct fake_destroy_vm dvm = {
					.address_space = &das,
				};
				struct fake_destroy_thread dthread = {
					.proc = &dproc,
					.vm = &dvm,
					.cpu_id = 7,
					.uti_state = UTI_STATE_EPILOGUE,
					.uti_refill_tid = 123,
					.sigcommon = (void *)0xcafe000UL,
				};
				struct fake_list_head thread_head;
				unsigned long lock_node = 0x7777UL;

				dproc.main_thread = &dthread;
				das.cpu_set[0] = 1UL << 7;
				fake_list_init(&thread_head);
				fake_list_init(&dthread.siblings_list);
				fake_list_add_tail(&dthread.siblings_list, &thread_head);
				fake_list_init(&dthread.sigpending);
				reset_process_release_trace();
				mix(&digest, process_destroy_thread_body_result(
					&dthread,
					offsetof(struct fake_destroy_thread, proc),
					offsetof(struct fake_destroy_thread, vm),
					offsetof(struct fake_destroy_thread, cpu_id),
					offsetof(struct fake_destroy_thread,
						 siblings_list),
					offsetof(struct fake_destroy_thread,
						 uti_state),
					offsetof(struct fake_destroy_thread,
						 uti_refill_tid),
					offsetof(struct fake_destroy_thread,
						 sigpending),
					offsetof(struct fake_destroy_thread,
						 sigcommon),
					offsetof(struct fake_destroy_proc,
						 threads_lock),
					offsetof(struct fake_destroy_proc, tids),
					offsetof(struct fake_destroy_proc,
						 main_thread),
					offsetof(struct fake_destroy_vm,
						 address_space),
					offsetof(struct fake_destroy_address_space,
						 cpu_set),
					offsetof(struct fake_destroy_address_space,
						 cpu_set_lock),
					offsetof(struct fake_pending, list),
					offsetof(struct fake_destroy_thread,
						 ptrace_debugreg),
					offsetof(struct fake_destroy_thread,
						 ptrace_recvsig),
					offsetof(struct fake_destroy_thread,
						 ptrace_sendsig),
					offsetof(struct fake_destroy_thread, fp_regs),
					offsetof(struct fake_destroy_thread,
						 coredump_regs),
					128, &lock_node, fake_process_mcs_lock,
					fake_process_mcs_unlock,
					fake_destroy_hash_detach,
					fake_destroy_time_account,
					fake_destroy_release_tid,
					fake_destroy_replace_tid, fake_spin_lock,
					fake_spin_unlock, fake_optional_free,
					fake_release_fp_regs,
					fake_destroy_release_sigcommon,
					fake_release_thread_pages));
				require(process_destroy_release_tid_count == 0);
				require(process_destroy_replace_tid_count == 1);
				require(process_destroy_replace_tid_new == 123);
				require(process_destroy_tid_proc == &dproc);
				require(process_destroy_tid_thread == &dthread);
				require(das.cpu_set[0] == 0);
				require(process_release_thread_pages_count == 0);
				require(process_optional_free_count == 1);
				require(process_destroy_release_sigcommon_ptr ==
					(void *)0xcafe000UL);
				mix(&digest,
				    (unsigned long)process_destroy_replace_tid_new);
			}

			{
				const struct fake_process_find_thread_offsets
					thread_offsets = {
					.thread_hash_list_offset =
						offsetof(struct fake_lookup_thread,
							 hash_list),
					.thread_tid_offset =
						offsetof(struct fake_lookup_thread, tid),
					.thread_proc_offset =
						offsetof(struct fake_lookup_thread,
							 proc),
					.proc_pid_offset =
						offsetof(struct fake_lookup_process,
							 pid),
				};
				const struct fake_process_find_process_offsets
					process_offsets = {
					.process_hash_list_offset =
						offsetof(struct fake_lookup_process,
							 hash_list),
					.process_pid_offset =
						offsetof(struct fake_lookup_process,
							 pid),
				};
				struct fake_list_head thread_hash;
				struct fake_lookup_process proc_a = { .pid = 10 };
				struct fake_lookup_process proc_b = { .pid = 20 };
				struct fake_lookup_thread thread_a = {
					.tid = 30,
					.proc = &proc_a,
				};
				struct fake_lookup_thread thread_b = {
					.tid = 30,
					.proc = &proc_b,
				};
				struct fake_lookup_thread thread_retry = {
					.tid = 40,
					.proc = &proc_a,
				};
				struct fake_list_head process_hash;
				struct fake_lookup_process proc_c = { .pid = 100 };
				struct fake_lookup_process proc_d = { .pid = 200 };
				unsigned long lock_node = 0x9999UL;
				void *found;

				fake_list_init(&thread_hash);
				fake_list_init(&proc_a.hash_list);
				fake_list_init(&proc_b.hash_list);
				fake_list_init(&thread_a.hash_list);
				fake_list_init(&thread_b.hash_list);
				fake_list_init(&thread_retry.hash_list);
				fake_list_add_tail(&thread_a.hash_list, &thread_hash);
				fake_list_add_tail(&thread_b.hash_list, &thread_hash);
				reset_process_release_trace();
				found = process_find_thread_body_result(&thread_hash,
					0xaaaaUL, &lock_node, 20, 30,
					&thread_offsets, fake_process_mcs_lock,
					fake_process_mcs_unlock,
					fake_process_lookup_hold_thread);
				require(found == &thread_b);
				require(process_mcs_lock_count == 1);
				require(process_mcs_unlock_count == 1);
				require(process_lookup_hold_count == 1);
				require(process_lookup_hold_thread == &thread_b);
				mix(&digest, (unsigned long)process_lookup_hold_count);

				fake_list_init(&thread_hash);
				fake_list_add_tail(&thread_retry.hash_list,
						   &thread_hash);
				reset_process_release_trace();
				found = process_find_thread_body_result(&thread_hash,
					0xaaabUL, &lock_node, 40, 40,
					&thread_offsets, fake_process_mcs_lock,
					fake_process_mcs_unlock,
					fake_process_lookup_hold_thread);
				require(found == &thread_retry);
				require(process_lookup_hold_count == 1);
				require(process_mcs_unlock_count == 1);
				mix(&digest, (unsigned long)process_lookup_hold_count);

				reset_process_release_trace();
				found = process_find_thread_body_result(&thread_hash,
					0xaaacUL, &lock_node, 41, 40,
					&thread_offsets, fake_process_mcs_lock,
					fake_process_mcs_unlock,
					fake_process_lookup_hold_thread);
				require(found == NULL);
				require(process_lookup_hold_count == 0);
				require(process_mcs_lock_count == 1);
				require(process_mcs_unlock_count == 1);
				mix(&digest, (unsigned long)process_mcs_unlock_count);

				fake_list_init(&process_hash);
				fake_list_init(&proc_c.hash_list);
				fake_list_init(&proc_d.hash_list);
				fake_list_add_tail(&proc_c.hash_list, &process_hash);
				fake_list_add_tail(&proc_d.hash_list, &process_hash);
				reset_process_release_trace();
				found = process_find_process_body_result(&process_hash,
					0xbbbbUL, &lock_node, 200,
					&process_offsets, fake_process_mcs_lock,
					fake_process_mcs_unlock);
				require(found == &proc_d);
				require(process_mcs_lock_count == 1);
				require(process_mcs_unlock_count == 0);
				mix(&digest, (unsigned long)process_mcs_lock_count);
				mix(&digest, process_unlock_found_process_result(found,
					0xbbbbUL, &lock_node,
					fake_process_mcs_unlock));
				require(process_mcs_unlock_count == 1);

				reset_process_release_trace();
				found = process_find_process_body_result(&process_hash,
					0xbbbcUL, &lock_node, 300,
					&process_offsets, fake_process_mcs_lock,
					fake_process_mcs_unlock);
				require(found == NULL);
				require(process_mcs_lock_count == 1);
				require(process_mcs_unlock_count == 1);
				mix(&digest, (unsigned long)process_mcs_unlock_count);
			}

			reset_process_release_trace();
			mix(&digest, process_release_thread_body_result(
				&rel_thread,
				offsetof(struct fake_release_thread, refcount),
				offsetof(struct fake_release_thread, vm),
				offsetof(struct fake_release_thread, proc),
				fake_ref_dec_and_test, fake_thread_profile,
				fake_thread_procfs_delete, fake_thread_destroy,
				fake_thread_release_vm));
			require(process_ref_dec_count == 1);
			require(process_thread_profile_count == 1);
			require(process_thread_procfs_count == 1);
			require(process_thread_destroy_count == 1);
			require(process_thread_release_vm_count == 1);
			require(process_lifecycle_order == 0x1234UL);
			mix(&digest, process_lifecycle_order);

			rel_thread.refcount = 0;
			mix(&digest, process_release_thread_body_result(
				&rel_thread,
				offsetof(struct fake_release_thread, refcount),
				offsetof(struct fake_release_thread, vm),
				offsetof(struct fake_release_thread, proc),
				fake_ref_dec_and_test, fake_thread_profile,
				fake_thread_procfs_delete, fake_thread_destroy,
				fake_thread_release_vm));
			require(process_thread_release_vm_count == 1);
		}

		{
			struct fake_mckfd vm_fd_a = { 0, 31, fake_mckfd_close };
			struct fake_mckfd vm_fd_b = { 0, 32, fake_mckfd_close };
			struct fake_policy vm_policy = {
				.policy_rb_node = { 1, NULL, NULL },
				.id = 23,
			};
			struct fake_release_process body_proc = {
				.vm = (void *)0xaa55,
				.pid = 77,
				.mckfd = &vm_fd_a,
				.mckfd_lock = 0,
			};
			struct fake_release_vm body_vm = {
				.refcount = 1,
				.address_space = (void *)0xbb66,
				.proc = &body_proc,
				.free_cb = fake_vm_free_cb,
				.opt = (void *)0xcc77,
			};

			reset_process_release_trace();
			vm_fd_a.next = &vm_fd_b;
			body_vm.policy_root.rb_node = &vm_policy.policy_rb_node;
			mix(&digest, process_release_vm_body_result(&body_vm,
				offsetof(struct fake_release_vm, refcount),
				offsetof(struct fake_release_vm, proc),
				offsetof(struct fake_release_process, mckfd),
				offsetof(struct fake_release_process, mckfd_lock),
				offsetof(struct fake_mckfd, next),
				offsetof(struct fake_mckfd, close_cb),
				offsetof(struct fake_release_vm, free_cb),
				offsetof(struct fake_release_vm, opt),
				offsetof(struct fake_release_vm, address_space),
				offsetof(struct fake_release_process, pid),
				offsetof(struct fake_release_process, vm),
				offsetof(struct fake_release_vm, policy_root),
				offsetof(struct fake_policy, policy_rb_node),
				fake_ref_dec_and_test, fake_spin_lock,
				fake_spin_unlock, fake_vm_flush,
				fake_vm_free_ranges, fake_detach_address_space,
				fake_release_process, fake_policy_free,
				fake_vm_free));
			require(process_ref_dec_count == 1);
			require(process_spin_lock_count == 1);
			require(process_spin_unlock_count == 1);
			require(process_spin_unlock_irq == 0x12345678UL);
			require(process_mckfd_close_count == 2);
			require(process_mckfd_close_fd_sum == 63);
			require(process_vm_free_cb_count == 1);
			require(process_vm_free_cb_vm == &body_vm);
			require(process_vm_free_cb_opt == (void *)0xcc77);
			require(process_vm_flush_count == 1);
			require(process_vm_free_ranges_count == 1);
			require(process_detach_count == 1);
			require(process_detach_pid == 77);
			require(process_detach_address_space == body_vm.address_space);
			require(process_release_count == 1);
			require(body_proc.vm == NULL);
			require(process_policy_free_count == 1);
			require(process_policy_free_id_sum == 23);
			require(process_vm_free_count == 1);
			require(process_lifecycle_order == 0x56789aUL);
			mix(&digest, process_lifecycle_order);
			mix(&digest, process_mckfd_close_fd_sum);
		}
	}

	printf("process_helpers ok digest=%016lx\n", digest);
	return 0;
}
