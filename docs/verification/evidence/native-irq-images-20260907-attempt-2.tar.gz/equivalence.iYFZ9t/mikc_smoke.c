#include <ikc/queue.h>
#include <ikc/msg.h>

int printf(const char *fmt, ...);

extern void ihk_ikc_master_init(void);
extern struct ihk_ikc_channel_desc *ihk_mc_get_master_channel(void);
extern int host_ikc_inited;
extern int rust_stub_kmalloc_calls;
extern int rust_stub_kmalloc_size;
extern int rust_stub_kmalloc_flags;
extern int rust_stub_ikc_init_calls;
extern struct ihk_ikc_channel_desc *rust_stub_ikc_init_channel;
extern ihk_ikc_ph_t rust_stub_ikc_init_handler;
extern int ihk_mc_ikc_init_first_local(struct ihk_ikc_channel_desc *,
				       ihk_ikc_ph_t);
extern int num_processors;
extern ihk_ikc_ph_t arch_master_channel_packet_handler;
extern int rust_stub_ikc_system_init_calls;
extern void *rust_stub_ikc_system_init_os;
extern int rust_stub_page_alloc_calls;
extern int rust_stub_page_alloc_npages[8];
extern int rust_stub_page_alloc_p2align[8];
extern unsigned long rust_stub_page_alloc_flags[8];
extern int rust_stub_page_alloc_node[8];
extern int rust_stub_page_alloc_is_user[8];
extern unsigned long rust_stub_page_alloc_virt[8];
extern void *rust_stub_page_alloc_result[8];
extern int rust_stub_ikc_init_queue_calls;
extern struct ihk_ikc_queue_head *rust_stub_ikc_init_queue_q[4];
extern int rust_stub_ikc_init_queue_id[4];
extern int rust_stub_ikc_init_queue_type[4];
extern int rust_stub_ikc_init_queue_size[4];
extern int rust_stub_ikc_init_queue_packetsize[4];
extern int rust_stub_ikc_init_desc_calls;
extern struct ihk_ikc_channel_desc *rust_stub_ikc_init_desc_channel;
extern void *rust_stub_ikc_init_desc_remote_os;
extern int rust_stub_ikc_init_desc_channel_id;
extern struct ihk_ikc_queue_head *rust_stub_ikc_init_desc_recv;
extern struct ihk_ikc_queue_head *rust_stub_ikc_init_desc_send;
extern ihk_ikc_ph_t rust_stub_ikc_init_desc_handler;
extern struct ihk_ikc_channel_desc *rust_stub_ikc_init_desc_master;
extern int rust_stub_ikc_enable_calls;
extern struct ihk_ikc_channel_desc *rust_stub_ikc_enable_channel;
extern int rust_stub_arch_set_mikc_queue_calls;
extern void *rust_stub_arch_set_mikc_queue_recv;
extern void *rust_stub_arch_set_mikc_queue_send;
extern int ihk_ikc_master_channel_packet_handler(struct ihk_ikc_channel_desc *,
						 void *, void *);

#define require(expr) do { if (!(expr)) return 12; } while (0)

static int fake_arch_packet_handler(struct ihk_ikc_channel_desc *channel,
				    void *packet, void *arg)
{
	(void)channel;
	(void)packet;
	(void)arg;
	return 0;
}

int main(void)
{
	struct ihk_ikc_master_packet packet = { 0 };
	struct ihk_ikc_channel_desc local_channel;
	unsigned char *channel_bytes = (unsigned char *)&local_channel;
	struct ihk_ikc_channel_desc *channel;
	int expected_size;
	int expected_queue_size;
	int expected_pages;
	int rc;
	int i;

	host_ikc_inited = 0;
	num_processors = 5;
	rust_stub_kmalloc_calls = 0;
	rust_stub_kmalloc_size = 0;
	rust_stub_kmalloc_flags = 0;
	rust_stub_ikc_init_calls = 0;
	rust_stub_ikc_init_channel = 0;
	rust_stub_ikc_init_handler = 0;
	rust_stub_ikc_system_init_calls = 0;
	rust_stub_page_alloc_calls = 0;
	rust_stub_ikc_init_queue_calls = 0;
	rust_stub_ikc_init_desc_calls = 0;
	rust_stub_ikc_enable_calls = 0;
	rust_stub_arch_set_mikc_queue_calls = 0;
	arch_master_channel_packet_handler = 0;

	ihk_ikc_master_init();
	channel = ihk_mc_get_master_channel();
	expected_size = sizeof(struct ihk_ikc_channel_desc) +
		sizeof(struct ihk_ikc_master_packet);
	expected_pages = ((4 * num_processors *
		(int)sizeof(struct ihk_ikc_master_packet)) +
		(PAGE_SIZE - 1)) / PAGE_SIZE;
	expected_queue_size = expected_pages * PAGE_SIZE;

	require(channel != 0);
	require(rust_stub_kmalloc_calls == 1);
	require(rust_stub_kmalloc_size == expected_size);
	require(rust_stub_kmalloc_flags == IHK_MC_AP_CRITICAL);
	require(rust_stub_ikc_init_calls == 0);
	require(rust_stub_page_alloc_calls == 2);
	require(rust_stub_page_alloc_npages[0] == expected_pages);
	require(rust_stub_page_alloc_npages[1] == expected_pages);
	require(rust_stub_ikc_init_queue_calls == 0);
	require(rust_stub_ikc_init_desc_calls == 0);
	require(rust_stub_ikc_enable_calls == 0);
	require(rust_stub_arch_set_mikc_queue_calls == 1);
	require(arch_master_channel_packet_handler != 0);
	require(channel->recv.queue == rust_stub_page_alloc_result[0]);
	require(channel->send.queue == rust_stub_page_alloc_result[1]);
	require(channel->recv.queue->pktsize ==
		(int)sizeof(struct ihk_ikc_master_packet));
	require(channel->send.queue->pktsize ==
		(int)sizeof(struct ihk_ikc_master_packet));
	require(channel->recv.queue->pktcount ==
		(expected_queue_size - (int)sizeof(struct ihk_ikc_queue_head)) /
		(int)sizeof(struct ihk_ikc_master_packet));
	require(channel->send.queue->pktcount ==
		(expected_queue_size - (int)sizeof(struct ihk_ikc_queue_head)) /
		(int)sizeof(struct ihk_ikc_master_packet));
	require(channel->handler == ihk_ikc_master_channel_packet_handler);
	require(channel->master == channel);
	require((channel->flag & IKC_FLAG_ENABLED) == IKC_FLAG_ENABLED);

	packet.msg = IHK_IKC_MASTER_MSG_INIT_ACK;
	rc = arch_master_channel_packet_handler(channel, &packet, 0);
	require(rc == 0);
	require(host_ikc_inited == 1);

	host_ikc_inited = 0;
	packet.msg = IHK_IKC_MASTER_MSG_CONNECT;
	rc = arch_master_channel_packet_handler(channel, &packet, 0);
	require(rc == 0);
	require(host_ikc_inited == 0);

	for (i = 0; i < (int)sizeof(local_channel); i++)
		channel_bytes[i] = 0xa5;
	num_processors = 5;
	rust_stub_ikc_system_init_calls = 0;
	rust_stub_ikc_system_init_os = (void *)1;
	rust_stub_page_alloc_calls = 0;
	rust_stub_ikc_init_queue_calls = 0;
	rust_stub_ikc_init_desc_calls = 0;
	rust_stub_ikc_enable_calls = 0;
	rust_stub_arch_set_mikc_queue_calls = 0;
	arch_master_channel_packet_handler = 0;

	rc = ihk_mc_ikc_init_first_local(&local_channel,
					 fake_arch_packet_handler);
	expected_pages = ((4 * num_processors *
		(int)sizeof(struct ihk_ikc_master_packet)) +
		(PAGE_SIZE - 1)) / PAGE_SIZE;
	expected_size = expected_pages * PAGE_SIZE;

	require(rc == 0);
	require(rust_stub_page_alloc_calls == 2);
	require(rust_stub_page_alloc_npages[0] == expected_pages);
	require(rust_stub_page_alloc_npages[1] == expected_pages);
	require(rust_stub_page_alloc_p2align[0] == PAGE_P2ALIGN);
	require(rust_stub_page_alloc_p2align[1] == PAGE_P2ALIGN);
	require(rust_stub_page_alloc_flags[0] == IHK_MC_AP_CRITICAL);
	require(rust_stub_page_alloc_flags[1] == IHK_MC_AP_CRITICAL);
	require(rust_stub_page_alloc_node[0] == -1);
	require(rust_stub_page_alloc_node[1] == -1);
	require(rust_stub_page_alloc_is_user[0] == IHK_MC_PG_KERNEL);
	require(rust_stub_page_alloc_is_user[1] == IHK_MC_PG_KERNEL);
	require(rust_stub_page_alloc_virt[0] == ~0UL);
	require(rust_stub_page_alloc_virt[1] == ~0UL);
	require(rust_stub_ikc_init_queue_calls == 0);
	require(local_channel.recv.queue == rust_stub_page_alloc_result[0]);
	require(local_channel.send.queue == rust_stub_page_alloc_result[1]);
	require(local_channel.recv.queue->id == 0);
	require(local_channel.send.queue->id == 0);
	require(local_channel.recv.queue->type == 0);
	require(local_channel.send.queue->type == 0);
	require(local_channel.recv.queue->queue_size ==
		(unsigned long)(expected_size -
		(int)sizeof(struct ihk_ikc_queue_head)));
	require(local_channel.send.queue->queue_size ==
		(unsigned long)(expected_size -
		(int)sizeof(struct ihk_ikc_queue_head)));
	require(local_channel.recv.queue->pktsize ==
		(int)sizeof(struct ihk_ikc_master_packet));
	require(local_channel.send.queue->pktsize ==
		(int)sizeof(struct ihk_ikc_master_packet));
	require(arch_master_channel_packet_handler == fake_arch_packet_handler);
	require(rust_stub_ikc_init_desc_calls == 0);
	require(local_channel.handler == ihk_ikc_master_channel_packet_handler);
	require(local_channel.master == &local_channel);
	require((local_channel.flag & IKC_FLAG_ENABLED) == IKC_FLAG_ENABLED);
	require(rust_stub_ikc_enable_calls == 0);
	require(rust_stub_arch_set_mikc_queue_calls == 1);
	require(rust_stub_arch_set_mikc_queue_recv ==
		rust_stub_page_alloc_result[0]);
	require(rust_stub_arch_set_mikc_queue_send ==
		rust_stub_page_alloc_result[1]);
	require(channel_bytes[0] != 0xa5);

	printf("mikc ok alloc=%d arch_pages=%d channel=%p\n",
	       rust_stub_kmalloc_size, expected_pages, channel);
	return 0;
}
