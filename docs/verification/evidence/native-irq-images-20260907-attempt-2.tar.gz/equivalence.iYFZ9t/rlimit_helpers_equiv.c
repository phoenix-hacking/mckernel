#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

extern int prlimit_validate_resource(int);
extern int prlimit_validate_new_limit(uint64_t, uint64_t);
extern int prlimit_linux_update_needed(int);
extern int prlimit_to_mckernel_resource(int);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

int main(void)
{
	static const int resources[] = {
		-100, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8,
		9, 10, 11, 12, 13, 14, 15, 16, 17, 99,
	};
	static const uint64_t limits[][2] = {
		{ 0, 0 },
		{ 0, 1 },
		{ 1, 0 },
		{ 4096, 4096 },
		{ 4097, 4096 },
		{ UINT64_MAX, UINT64_MAX },
		{ UINT64_MAX, UINT64_MAX - 1 },
	};
	unsigned long digest = 0x714d175123456789UL;

	for (unsigned int i = 0; i < sizeof(resources) / sizeof(resources[0]); i++) {
		mix_signed(&digest, prlimit_validate_resource(resources[i]));
		mix_signed(&digest, prlimit_linux_update_needed(resources[i]));
		mix_signed(&digest, prlimit_to_mckernel_resource(resources[i]));
	}

	for (unsigned int i = 0; i < sizeof(limits) / sizeof(limits[0]); i++) {
		mix_signed(&digest, prlimit_validate_new_limit(limits[i][0],
			limits[i][1]));
	}

	printf("rlimit_helpers ok digest=%016lx\n", digest);
	return 0;
}
