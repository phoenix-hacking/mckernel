#include <stdint.h>
#include <stdio.h>

extern unsigned long find_next_bit(const unsigned long *, unsigned long,
				   unsigned long);
extern unsigned long find_next_zero_bit(const unsigned long *, unsigned long,
					unsigned long);
extern unsigned long find_first_bit(const unsigned long *, unsigned long);
extern unsigned long find_first_zero_bit(const unsigned long *, unsigned long);
extern unsigned int __sw_hweight32(unsigned int);
extern unsigned int __sw_hweight16(unsigned int);
extern unsigned int __sw_hweight8(unsigned int);
extern unsigned long __sw_hweight64(uint64_t);
extern unsigned long hweight_long(unsigned long);
extern unsigned long ihk_bit_word(unsigned long);
extern unsigned long ihk_align_mask(unsigned long, unsigned long);
extern unsigned long ihk_align(unsigned long, unsigned long);
extern int ihk_is_aligned(unsigned long, unsigned long);

static unsigned long rng_state = 0xfedcba9876543210UL;

static unsigned long rnd(void)
{
	rng_state = rng_state * 2862933555777941757UL + 3037000493UL;
	return rng_state;
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	unsigned long words[5];
	unsigned long sizes[] = { 0, 1, 2, 7, 31, 32, 63, 64, 65, 95, 127,
		128, 129, 191, 255, 256, 257, 319 };
	unsigned long offsets[] = { 0, 1, 2, 5, 31, 32, 33, 63, 64, 65, 95,
		127, 128, 129, 191, 255, 256, 300, 320 };
	unsigned long aligns[] = { 1, 2, 4, 8, 16, 64, 4096 };
	unsigned long digest = 0x6eed0e9da4d94a4fUL;

	for (unsigned int pattern = 0; pattern < 80; pattern++) {
		for (unsigned int i = 0; i < 5; i++)
			words[i] = rnd();

		if ((pattern & 7) == 0) {
			for (unsigned int i = 0; i < 5; i++)
				words[i] = 0;
		} else if ((pattern & 7) == 1) {
			for (unsigned int i = 0; i < 5; i++)
				words[i] = ~0UL;
		} else if ((pattern & 7) == 2) {
			for (unsigned int i = 0; i < 5; i++)
				words[i] = 1UL << ((pattern + i * 13) & 63);
		}

		for (unsigned int si = 0; si < sizeof(sizes) / sizeof(sizes[0]); si++) {
			unsigned long size = sizes[si];

			mix(&digest, find_first_bit(words, size));
			mix(&digest, find_first_zero_bit(words, size));

			for (unsigned int oi = 0; oi < sizeof(offsets) / sizeof(offsets[0]); oi++) {
				mix(&digest, find_next_bit(words, size, offsets[oi]));
				mix(&digest, find_next_zero_bit(words, size, offsets[oi]));
			}
		}

		for (unsigned int i = 0; i < 5; i++) {
			mix(&digest, __sw_hweight8((unsigned int)words[i]));
			mix(&digest, __sw_hweight16((unsigned int)words[i]));
			mix(&digest, __sw_hweight32((unsigned int)words[i]));
			mix(&digest, __sw_hweight64((uint64_t)words[i]));
			mix(&digest, hweight_long(words[i]));
			mix(&digest, ihk_bit_word(words[i]));
			for (unsigned int ai = 0; ai < sizeof(aligns) / sizeof(aligns[0]); ai++) {
				unsigned long aligned = ihk_align(words[i], aligns[ai]);
				mix(&digest, aligned);
				mix(&digest, ihk_align_mask(words[i], aligns[ai] - 1));
				mix(&digest, (unsigned long)ihk_is_aligned(aligned, aligns[ai]));
				mix(&digest, (unsigned long)ihk_is_aligned(words[i], aligns[ai]));
			}
		}
	}

	printf("bitops ok digest=%016lx\n", digest);
	return 0;
}
