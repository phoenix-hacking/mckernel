#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EINVAL 22
#define ENOMEM 12
#define IHK_UCR_STACK_POINTER 1
#define IHK_UCR_PROGRAM_COUNTER 2
#define IHK_ASR_X86_FS 0
#define IHK_ASR_X86_GS 1
#define ARCH_SET_FS 0x1002UL
#define RUST_CPU_LOCAL_CURRENT_OFFSET 7848UL
#define MCCTRL_OS_CPU_READ_REGISTER 0
#define MCCTRL_OS_CPU_WRITE_REGISTER 1
#define PS_INTERRUPTIBLE 0x2
#define PS_UNINTERRUPTIBLE 0x4
#define PS_STOPPED 0x20
#define PS_TRACED 0x40
#define X2APIC_ENABLE (1UL << 10)

struct x86_kregs {
	unsigned long rsp, rbp, rbx, rsi, rdi, r12, r13, r14, r15, rflags;
	unsigned long rsp0;
};

struct x86_sregs {
	unsigned long fs_base, gs_base, ds, es, fs, gs;
};

struct x86_basic_regs {
	unsigned long r15, r14, r13, r12, rbp, rbx, r11, r10;
	unsigned long r9, r8, rax, rcx, rdx, rsi, rdi, orig_rax;
	unsigned long rip, cs, rflags, rsp, ss;
};

struct x86_user_context {
	struct x86_sregs sr;
	uint8_t is_gpr_valid;
	uint8_t is_sr_valid;
	uint8_t spare_flags6;
	uint8_t spare_flags5;
	uint8_t spare_flags4;
	uint8_t spare_flags3;
	uint8_t spare_flags2;
	uint8_t spare_flags1;
	struct x86_basic_regs gpr;
};

struct x86_thread_context_offsets {
	unsigned long thread_status_offset;
	unsigned long thread_uctx_offset;
	unsigned long thread_tlsblock_base_offset;
};

struct fake_thread {
	int status;
	struct x86_user_context *uctx;
	unsigned long tlsblock_base;
};

struct fake_trace_process {
	int pid;
};

struct fake_trace_thread {
	int tid;
	int status;
	struct fake_trace_process *proc;
};

struct x86_trace_enter_user_offsets {
	unsigned long thread_tid_offset;
	unsigned long thread_status_offset;
	unsigned long thread_proc_offset;
	unsigned long process_pid_offset;
};

struct fake_runq_local {
	unsigned long pad;
	unsigned long runq_lock;
	unsigned long runq_irqstate;
};

struct fake_kstack_local {
	unsigned long pad;
	unsigned long kernel_stack;
	unsigned long tss_rsp0;
};

struct fake_cpu_local {
	unsigned long processor_id;
	unsigned long apic_id;
	unsigned char pad_to_paniced[280 - 2 * sizeof(unsigned long)];
	unsigned long paniced;
};

struct ihk_os_cpu_register {
	unsigned long addr;
	unsigned long val;
	unsigned long addr_ext;
	int sync;
};

extern int x86_init_context_body_result(struct x86_kregs *, void *, void *,
					void *(*)(void));
extern int x86_boot_cpu_body_result(
	void *, const void *, unsigned long, int, unsigned long, unsigned long,
	int *, void *, unsigned long (*)(void), unsigned long (*)(int),
	unsigned long (*)(void), void (*)(int, unsigned long), void (*)(void));
extern int x86_init_user_process_body_result(
	struct x86_kregs *, struct x86_user_context **, void *,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, void *);
extern int x86_modify_user_context_result(struct x86_user_context *, int,
					  unsigned long, int, int);
extern void ihk_mc_modify_user_context(struct x86_user_context *, int,
				       unsigned long);
extern struct x86_user_context *x86_lookup_user_context_body_result(
	struct fake_thread *, struct fake_thread *, int,
	const struct x86_thread_context_offsets *);
extern int x86_syscall_handler_publish_result(unsigned long *, void *);
extern int x86_page_fault_handler_publish_result(unsigned long *, void *);
extern int x86_arch_noop_body_result(void);
extern int x86_delay_us_body_result(int, void (*)(int));
extern int x86_tick_log_body_result(int, void (*)(int));
extern int x86_arch_set_special_register_result(int, int, unsigned long,
						void (*)(unsigned long));
extern int x86_arch_get_special_register_result(int, int, unsigned long *,
						unsigned long (*)(void));
extern int x86_get_interrupt_id_result(int, void *(*)(int), unsigned long);
extern int x86_interrupt_cpu_result(int, int, int, void *(*)(int),
				    unsigned long, void (*)(unsigned long, int),
				    void (*)(int, int, int));
extern int x86_lapic_timer_enable_body_result(unsigned int,
					      void (*)(int, unsigned int));
extern int x86_lapic_timer_disable_body_result(void (*)(int, unsigned int));
extern int x86_lapic_ack_body_result(void (*)(int, unsigned int));
extern int x86_x2apic_issue_ipi_body_result(unsigned int, unsigned int,
					    void (*)(void),
					    unsigned long (*)(void),
					    void (*)(unsigned int, unsigned int),
					    void (*)(unsigned long));
extern int x86_apic_issue_ipi_body_result(unsigned int, unsigned int, int,
					  unsigned long (*)(void),
					  void (*)(void),
					  void (*)(unsigned int, unsigned int),
					  void (*)(unsigned long));
extern unsigned long x86_x2apic_enabled_result(unsigned long, unsigned long);
extern int x86_init_lapic_bsp_body_result(unsigned long, void (*)(int));
extern int x86_init_lapic_body_result(int, void **, int, unsigned long,
				      unsigned long, unsigned long,
				      unsigned long (*)(int),
				      void (*)(int, unsigned long),
				      void *(*)(unsigned long, unsigned long, int),
				      void (*)(int, unsigned int));
extern int x86_init_pstate_turbo_body_result(
	int, int, int, int, int, int (*)(void),
	void (*)(unsigned long *, unsigned long *),
	unsigned long (*)(int), void (*)(int, unsigned long));
extern int x86_init_pat_body_result(
	unsigned long *, int, void (*)(unsigned long, unsigned long *),
	unsigned long (*)(int), void (*)(int, unsigned long), void (*)(int));
extern int x86_init_syscall_body_result(int, int, int, unsigned long,
					unsigned long, unsigned long,
					unsigned long (*)(int),
					void (*)(int, unsigned long));
extern int x86_enable_no_execute_body_result(int, int, unsigned long,
					     unsigned long (*)(int),
					     void (*)(int, unsigned long));
extern int x86_check_no_execute_body_result(
	int *, void (*)(unsigned long, unsigned long *), void (*)(int, int),
	void (*)(void));
extern int x86_init_gettime_support_body_result(
	int *, void (*)(unsigned long, unsigned long *), void (*)(int));
extern int x86_init_cpu_body_result(
	void (*)(void), void (*)(void), void (*)(void), void (*)(void),
	void (*)(void), void (*)(void), void (*)(void), void (*)(void));
extern int x86_setup_phase1_body_result(void (*)(void), void (*)(void),
					void (*)(void), void (*)(void));
extern int x86_setup_phase2_body_result(void (*)(void), void (*)(void),
					void (*)(void), void (*)(void),
					void (*)(int));
extern int x86_ihk_mc_init_ap_body_result(
	void **, void **, unsigned long, unsigned long, unsigned long,
	void *(*)(unsigned long, unsigned long, int), int (*)(void),
	void (*)(int), void (*)(void), void (*)(void),
	void (*)(int, unsigned long));
extern int x86_running_on_kvm_body_result(
	unsigned long, void (*)(unsigned long, unsigned long *,
				unsigned long *, unsigned long *, unsigned long *));
extern int x86_pvclock_available_body_result(
	long *, unsigned long, unsigned long, int, int, long, long,
	void (*)(unsigned long, unsigned long *, unsigned long *,
		 unsigned long *, unsigned long *),
	void (*)(int));
extern int x86_arch_setup_pvclock_body_result(
	void **, int *, int, unsigned long, unsigned long, int, unsigned long,
	int, char *, int, int (*)(void),
	void *(*)(int, int, unsigned long, int, int, unsigned long, char *, int),
	void (*)(int));
extern int x86_arch_start_pvclock_body_result(
	void *, long, unsigned long, unsigned long, int (*)(void),
	unsigned long (*)(void *), void (*)(int, unsigned long), void (*)(int));
extern int x86_call_ap_func_body_result(int *, void (*)(void));
extern void call_ap_func(void (*)(void));
extern void __show_stack(unsigned long *);
extern void show_context_stack(unsigned long *);
extern void ihk_mc_boot_cpu(int, unsigned long);
extern void mcexec_v10_trace_enter_user(struct x86_user_context *);
extern void release_runq_lock(void);
extern int x86_show_stack_body_result(
	unsigned long *, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long, unsigned long));
extern int x86_arch_print_pre_interrupt_stack_body_result(
	const void *, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, void (*)(int),
	void (*)(void *, unsigned long));
extern int x86_arch_print_stack_body_result(
	void *, void (*)(int), void (*)(void *, unsigned long));
extern int x86_print_user_context_body_result(
	const struct x86_user_context *,
	void (*)(int, unsigned long, unsigned long, unsigned long,
		 unsigned long));
extern int x86_arch_show_interrupt_context_body_result(
	const struct x86_user_context *, unsigned long (*)(void),
	void (*)(unsigned long),
	void (*)(int, unsigned long, unsigned long, unsigned long,
		 unsigned long));
extern int x86_arch_save_panic_regs_body_result(
	const struct x86_user_context *, const struct x86_kregs *,
	unsigned long *, unsigned long *, unsigned long, unsigned long,
	void (*)(int, unsigned long));
extern int x86_arch_clear_panic_body_result(unsigned long *);
extern int x86_mcexec_v10_trace_enter_user_body_result(
	const struct x86_user_context *, const void *, int *, int, int,
	const struct x86_trace_enter_user_offsets *,
	void (*)(int, int, int, unsigned long, unsigned long, unsigned long,
		 unsigned long, unsigned long, int));
extern int x86_release_runq_lock_body_result(
	void *, unsigned long, unsigned long, void (*)(void *, unsigned long));
extern int x86_set_kstack_body_result(void *, unsigned long, unsigned long,
				      unsigned long);
extern int x86_arch_cpu_read_write_register_body_result(
	void *, int, int, int, unsigned long, unsigned long,
	unsigned long (*)(int), void (*)(int, unsigned long));
extern void mb(void);
extern void rmb(void);
extern void wmb(void);
extern void smp_mb(void);
extern void smp_rmb(void);
extern void smp_wmb(void);
extern void arch_barrier(void);
extern unsigned long smp_load_acquire_ulong(const unsigned long *);
extern unsigned int smp_load_acquire_uint(const unsigned int *);
extern int smp_load_acquire_int(const int *);
extern void *smp_load_acquire_ptr(void *const *);
extern void smp_store_release_ulong(unsigned long *, unsigned long);
extern void smp_store_release_uint(unsigned int *, unsigned int);
extern void smp_store_release_int(int *, int);
extern unsigned long CVAL(unsigned int, unsigned int);
extern unsigned long CVAL2(unsigned int, unsigned int, unsigned int,
			   unsigned int);
extern int ihk_mc_get_smp_handler_irq(void);
extern int ihk_mc_get_interrupt_id(int);
extern void ihk_mc_delay_us(int);
extern void init_tick(void);
extern void init_delay(void);
extern void sync_tick(void);
extern void arch_clone_thread(void *, unsigned long, unsigned long, void *);
extern void arch_flush_icache_all(void);
extern void ihk_mc_init_user_tlsbase(struct x86_user_context *,
				     unsigned long);
extern void ihk_mc_set_page_fault_handler(void *);
extern void ihk_mc_set_syscall_handler(void *);
extern void arch_clear_panic(void);
extern void arch_show_interrupt_context(const void *);
extern void arch_print_pre_interrupt_stack(const struct x86_basic_regs *);
extern void arch_print_stack(void);
extern int arch_setup_pvclock(void);
extern void arch_start_pvclock(void);
extern unsigned long ihk_mc_syscall_arg0(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_arg1(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_arg2(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_arg3(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_arg4(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_arg5(const struct x86_user_context *);
extern void ihk_mc_syscall_set_arg0(struct x86_user_context *, unsigned long);
extern void ihk_mc_syscall_set_arg1(struct x86_user_context *, unsigned long);
extern void ihk_mc_syscall_set_arg2(struct x86_user_context *, unsigned long);
extern void ihk_mc_syscall_set_arg3(struct x86_user_context *, unsigned long);
extern void ihk_mc_syscall_set_arg4(struct x86_user_context *, unsigned long);
extern void ihk_mc_syscall_set_arg5(struct x86_user_context *, unsigned long);
extern unsigned long ihk_mc_syscall_ret(const struct x86_user_context *);
extern void ihk_mc_syscall_set_ret(struct x86_user_context *, unsigned long);
extern unsigned long ihk_mc_syscall_number(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_pc(const struct x86_user_context *);
extern unsigned long ihk_mc_syscall_sp(const struct x86_user_context *);
extern unsigned long REGS_GET_STACK_POINTER(const void *);
void arch_delay(int);

static int arch_prctl_call_count;
static unsigned long arch_prctl_last_code;
static unsigned long arch_prctl_last_address;
unsigned long __x86_syscall_handler;
unsigned long __page_fault_handler_address;
#ifndef USE_C_X86_CPU_MODEL
extern void *clv;
extern int cpu_local_var_initialized;
static unsigned char rust_arch_prctl_cpu_local[8192]
		__attribute__((aligned(64)));
static unsigned char rust_arch_prctl_thread[8192]
		__attribute__((aligned(64)));
#endif

long do_arch_prctl(unsigned long code, unsigned long address)
{
	arch_prctl_call_count++;
	arch_prctl_last_code = code;
	arch_prctl_last_address = address;
	return -123;
}

int arch_prctl_set_register_bridge(int type, unsigned long value)
{
	arch_prctl_call_count++;
	arch_prctl_last_code = type == IHK_ASR_X86_FS ? ARCH_SET_FS :
		(unsigned long)type;
	arch_prctl_last_address = value;
	return -123;
}

#ifdef USE_C_X86_CPU_MODEL
int ihk_mc_get_smp_handler_irq(void)
{
	return 0xf1;
}

void arch_clone_thread(void *othread, unsigned long pc, unsigned long sp,
		       void *nthread)
{
	(void)othread;
	(void)pc;
	(void)sp;
	(void)nthread;
}

void arch_flush_icache_all(void)
{
}

void ihk_mc_init_user_tlsbase(struct x86_user_context *ctx,
			      unsigned long tls_base_addr)
{
	(void)ctx;
	do_arch_prctl(ARCH_SET_FS, tls_base_addr);
}

void ihk_mc_set_page_fault_handler(void *handler)
{
	__page_fault_handler_address = (unsigned long)handler;
}

void ihk_mc_set_syscall_handler(void *handler)
{
	__x86_syscall_handler = (unsigned long)handler;
}

void ihk_mc_delay_us(int us)
{
	arch_delay(us);
}
#endif

#ifndef USE_C_X86_CPU_MODEL
extern void *locals;
#endif

#ifdef USE_C_X86_CPU_MODEL
int x86_boot_cpu_body_result(
	void *trampoline_va, const void *trampoline_code_data,
	unsigned long trampoline_code_size, int cpuid, unsigned long pc,
	unsigned long ap_trampoline, int *boot_status_slot,
	void *setup_x86_ap_addr, unsigned long (*boot_page_table_phys_fn)(void),
	unsigned long (*cpu_kstack_fn)(int),
	unsigned long (*transit_page_table_fn)(void),
	void (*wakeup_fn)(int, unsigned long), void (*pause_fn)(void))
{
	unsigned long *p;
	unsigned long boot_pt;
	unsigned long transit_pt;

	if (!trampoline_va || !trampoline_code_data || !boot_status_slot ||
	    !setup_x86_ap_addr || !boot_page_table_phys_fn || !cpu_kstack_fn ||
	    !transit_page_table_fn || !wakeup_fn || !pause_fn)
		return -EINVAL;

	p = trampoline_va;
	memcpy(p, trampoline_code_data, trampoline_code_size);
	boot_pt = boot_page_table_phys_fn();
	p[1] = boot_pt;
	p[2] = (unsigned long)setup_x86_ap_addr;
	p[3] = pc;
	p[4] = cpu_kstack_fn(cpuid);
	transit_pt = transit_page_table_fn();
	p[6] = transit_pt ? transit_pt : boot_pt;
	*boot_status_slot = 0;
	wakeup_fn(cpuid, ap_trampoline);
	while (!*boot_status_slot)
		pause_fn();
	return 0;
}

int x86_init_context_body_result(struct x86_kregs *ctx, void *stack_pointer,
				 void *next_function, void *(*stack_fn)(void))
{
	unsigned long *sp;

	if (!ctx || !next_function)
		return -EINVAL;
	if (!stack_pointer) {
		if (!stack_fn)
			return -EINVAL;
		stack_pointer = stack_fn();
		if (!stack_pointer)
			return -EINVAL;
	}

	sp = stack_pointer;
	memset(ctx, 0, sizeof(*ctx));
	ctx->rsp = (unsigned long)(sp - 1);
	sp[-1] = (unsigned long)next_function;
	return 0;
}

int x86_init_user_process_body_result(
	struct x86_kregs *ctx, struct x86_user_context **puctx,
	void *stack_pointer, unsigned long new_pc, unsigned long user_sp,
	unsigned long user_cs, unsigned long user_ds, unsigned long rflags_if,
	void *enter_user_mode_addr)
{
	char *sp;
	struct x86_user_context *uctx;
	unsigned long *ret_slot;

	if (!ctx || !puctx || !stack_pointer || !enter_user_mode_addr)
		return -EINVAL;

	sp = stack_pointer;
	sp -= sizeof(*uctx);
	uctx = (struct x86_user_context *)sp;
	*puctx = uctx;

	memset(uctx, 0, sizeof(*uctx));
	uctx->gpr.cs = user_cs;
	uctx->gpr.rip = new_pc;
	uctx->gpr.ss = user_ds;
	uctx->gpr.rsp = user_sp;
	uctx->gpr.rflags = rflags_if;
	uctx->is_gpr_valid = 1;

	memset(ctx, 0, sizeof(*ctx));
	ret_slot = (unsigned long *)sp - 1;
	ctx->rsp = (unsigned long)ret_slot;
	*ret_slot = (unsigned long)enter_user_mode_addr;
	ctx->rsp0 = (unsigned long)stack_pointer;
	return 0;
}

int x86_modify_user_context_result(struct x86_user_context *uctx, int reg,
				   unsigned long value, int stack_pointer_reg,
				   int program_counter_reg)
{
	if (!uctx)
		return -EINVAL;
	if (reg == stack_pointer_reg) {
		uctx->gpr.rsp = value;
		return 1;
	}
	if (reg == program_counter_reg) {
		uctx->gpr.rip = value;
		return 1;
	}
	return 0;
}

void ihk_mc_modify_user_context(struct x86_user_context *uctx, int reg,
				unsigned long value)
{
	(void)x86_modify_user_context_result(uctx, reg, value,
					     IHK_UCR_STACK_POINTER,
					     IHK_UCR_PROGRAM_COUNTER);
}

struct x86_user_context *x86_lookup_user_context_body_result(
	struct fake_thread *thread, struct fake_thread *current_thread,
	int sleep_status_mask, const struct x86_thread_context_offsets *offsets)
{
	struct x86_user_context *uctx;
	char *base;

	if (!thread || !offsets)
		return NULL;
	base = (char *)thread;
	uctx = *(struct x86_user_context **)(base + offsets->thread_uctx_offset);
	if (!uctx)
		return NULL;
	if (((*(int *)(base + offsets->thread_status_offset) &
	      sleep_status_mask) == 0 && thread != current_thread) ||
	    !uctx->is_gpr_valid)
		return NULL;

	if (!uctx->is_sr_valid) {
		uctx->sr.fs_base =
			*(unsigned long *)(base + offsets->thread_tlsblock_base_offset);
		uctx->sr.gs_base = 0;
		uctx->sr.ds = 0;
		uctx->sr.es = 0;
		uctx->sr.fs = 0;
		uctx->sr.gs = 0;
		uctx->is_sr_valid = 1;
	}
	return uctx;
}

unsigned long CVAL(unsigned int event, unsigned int mask)
{
	return (((event & 0xf00UL) << 24) | (mask << 8) | (event & 0xff));
}

void mb(void)
{
	asm volatile("mfence" : : : "memory");
}

void rmb(void)
{
	asm volatile("lfence" : : : "memory");
}

void wmb(void)
{
	asm volatile("sfence" : : : "memory");
}

void smp_mb(void)
{
	mb();
}

void smp_rmb(void)
{
	rmb();
}

void smp_wmb(void)
{
	asm volatile("" : : : "memory");
}

void arch_barrier(void)
{
	asm volatile("" : : : "memory");
}

unsigned long smp_load_acquire_ulong(const unsigned long *p)
{
	unsigned long value = *(const volatile unsigned long *)p;

	asm volatile("" : : : "memory");
	return value;
}

unsigned int smp_load_acquire_uint(const unsigned int *p)
{
	unsigned int value = *(const volatile unsigned int *)p;

	asm volatile("" : : : "memory");
	return value;
}

int smp_load_acquire_int(const int *p)
{
	int value = *(const volatile int *)p;

	asm volatile("" : : : "memory");
	return value;
}

void *smp_load_acquire_ptr(void *const *p)
{
	void *value = *(void *const volatile *)p;

	asm volatile("" : : : "memory");
	return value;
}

void smp_store_release_ulong(unsigned long *p, unsigned long value)
{
	asm volatile("" : : : "memory");
	*(volatile unsigned long *)p = value;
}

void smp_store_release_uint(unsigned int *p, unsigned int value)
{
	asm volatile("" : : : "memory");
	*(volatile unsigned int *)p = value;
}

void smp_store_release_int(int *p, int value)
{
	asm volatile("" : : : "memory");
	*(volatile int *)p = value;
}

unsigned long CVAL2(unsigned int event, unsigned int mask, unsigned int inv,
		    unsigned int count)
{
	return CVAL(event, mask) | ((inv & 1) << 23) | ((count & 0xff) << 24);
}

unsigned long ihk_mc_syscall_arg0(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rdi : 0;
}

unsigned long ihk_mc_syscall_arg1(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rsi : 0;
}

unsigned long ihk_mc_syscall_arg2(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rdx : 0;
}

unsigned long ihk_mc_syscall_arg3(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.r10 : 0;
}

unsigned long ihk_mc_syscall_arg4(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.r8 : 0;
}

unsigned long ihk_mc_syscall_arg5(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.r9 : 0;
}

void ihk_mc_syscall_set_arg0(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.rdi = value;
}

void ihk_mc_syscall_set_arg1(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.rsi = value;
}

void ihk_mc_syscall_set_arg2(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.rdx = value;
}

void ihk_mc_syscall_set_arg3(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.r10 = value;
}

void ihk_mc_syscall_set_arg4(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.r8 = value;
}

void ihk_mc_syscall_set_arg5(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.r9 = value;
}

unsigned long ihk_mc_syscall_ret(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rax : 0;
}

void ihk_mc_syscall_set_ret(struct x86_user_context *uc, unsigned long value)
{
	if (uc)
		uc->gpr.rax = value;
}

unsigned long ihk_mc_syscall_number(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.orig_rax : 0;
}

unsigned long ihk_mc_syscall_pc(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rip : 0;
}

unsigned long ihk_mc_syscall_sp(const struct x86_user_context *uc)
{
	return uc ? uc->gpr.rsp : 0;
}

unsigned long REGS_GET_STACK_POINTER(const void *regs)
{
	const struct x86_user_context *uc = regs;

	return uc ? uc->gpr.rsp : 0;
}

int x86_syscall_handler_publish_result(unsigned long *slot, void *handler)
{
	if (!slot)
		return -EINVAL;
	*slot = (unsigned long)handler;
	return 0;
}

int x86_page_fault_handler_publish_result(unsigned long *slot, void *handler)
{
	return x86_syscall_handler_publish_result(slot, handler);
}

int x86_arch_noop_body_result(void)
{
	return 0;
}

int x86_delay_us_body_result(int us, void (*delay_fn)(int))
{
	if (!delay_fn)
		return -EINVAL;
	delay_fn(us);
	return 0;
}

static void fake_cpu_log(int event);

int x86_tick_log_body_result(int event, void (*log_fn)(int))
{
	if (event < 1 || event > 3)
		return -EINVAL;
	if (log_fn)
		log_fn(event);
	return 0;
}

#ifdef USE_C_X86_CPU_MODEL
void init_tick(void)
{
	x86_tick_log_body_result(1, fake_cpu_log);
}

void init_delay(void)
{
	x86_tick_log_body_result(2, fake_cpu_log);
}

void sync_tick(void)
{
	x86_tick_log_body_result(3, fake_cpu_log);
}
#else
void x86_tick_log_bridge(int event)
{
	fake_cpu_log(event);
}
#endif

int x86_arch_set_special_register_result(int reg_type, int fs_type,
					 unsigned long value,
					 void (*write_fn)(unsigned long))
{
	if (reg_type != fs_type || !write_fn)
		return -EINVAL;
	write_fn(value);
	return 0;
}

int x86_arch_get_special_register_result(int reg_type, int fs_type,
					 unsigned long *valuep,
					 unsigned long (*read_fn)(void))
{
	if (reg_type != fs_type || !valuep || !read_fn)
		return -EINVAL;
	*valuep = read_fn();
	return 0;
}

int x86_arch_cpu_read_write_register_body_result(
	void *desc, int op, int read_op, int write_op,
	unsigned long addr_offset, unsigned long val_offset,
	unsigned long (*read_msr_fn)(int),
	void (*write_msr_fn)(int, unsigned long))
{
	char *base = desc;
	unsigned long addr;

	if (op == read_op) {
		if (!desc || !read_msr_fn)
			return -EINVAL;
		addr = *(unsigned long *)(base + addr_offset);
		*(unsigned long *)(base + val_offset) = read_msr_fn((int)addr);
		return 0;
	}

	if (op == write_op) {
		if (!desc || !write_msr_fn)
			return -EINVAL;
		addr = *(unsigned long *)(base + addr_offset);
		write_msr_fn((int)addr, *(unsigned long *)(base + val_offset));
		return 0;
	}

	return -1;
}

int x86_get_interrupt_id_result(int cpu, void *(*cpu_local_fn)(int),
				unsigned long apic_id_offset)
{
	char *local;

	if (!cpu_local_fn)
		return -1;
	local = cpu_local_fn(cpu);
	if (!local)
		return -1;
	return (int)*(unsigned long *)(local + apic_id_offset);
}

int x86_interrupt_cpu_result(int cpu, int vector, int num_processors,
			     void *(*cpu_local_fn)(int),
			     unsigned long apic_id_offset,
			     void (*issue_ipi_fn)(unsigned long, int),
			     void (*log_fn)(int, int, int))
{
	int apic_id;

	if (cpu < 0 || cpu >= num_processors) {
		if (log_fn)
			log_fn(1, cpu, vector);
		return -1;
	}
	if (!issue_ipi_fn)
		return -1;
	apic_id = x86_get_interrupt_id_result(cpu, cpu_local_fn, apic_id_offset);
	if (apic_id < 0)
		return -1;
	if (log_fn)
		log_fn(2, cpu, vector);
	issue_ipi_fn((unsigned long)apic_id, vector);
	return 0;
}

int x86_lapic_timer_enable_body_result(unsigned int clocks,
				       void (*write_fn)(int, unsigned int))
{
	if (!write_fn)
		return -EINVAL;
	write_fn(0x380, clocks / 16);
	write_fn(0x3e0, 3);
	write_fn(0x320, 0xef | (1U << 17));
	return 0;
}

int x86_lapic_timer_disable_body_result(void (*write_fn)(int, unsigned int))
{
	if (!write_fn)
		return -EINVAL;
	write_fn(0x380, 0);
	return 0;
}

int x86_lapic_ack_body_result(void (*write_fn)(int, unsigned int))
{
	if (!write_fn)
		return -EINVAL;
	write_fn(0x0b0, 0);
	return 0;
}

int x86_x2apic_issue_ipi_body_result(unsigned int apicid, unsigned int low,
				     void (*mb_fn)(void),
				     unsigned long (*disable_save_fn)(void),
				     void (*icr_write_fn)(unsigned int,
							   unsigned int),
				     void (*restore_fn)(unsigned long))
{
	unsigned long flags;

	if (!mb_fn || !disable_save_fn || !icr_write_fn || !restore_fn)
		return -EINVAL;
	mb_fn();
	flags = disable_save_fn();
	icr_write_fn(low, apicid);
	restore_fn(flags);
	return 0;
}

int x86_apic_issue_ipi_body_result(unsigned int apicid, unsigned int low,
				   int lapic_icr_id_shift,
				   unsigned long (*disable_save_fn)(void),
				   void (*wait_idle_fn)(void),
				   void (*icr_write_fn)(unsigned int,
							 unsigned int),
				   void (*restore_fn)(unsigned long))
{
	unsigned long flags;

	if (lapic_icr_id_shift < 0 || lapic_icr_id_shift >= 32 ||
	    !disable_save_fn || !wait_idle_fn || !icr_write_fn || !restore_fn)
		return -EINVAL;
	flags = disable_save_fn();
	wait_idle_fn();
	icr_write_fn(apicid << lapic_icr_id_shift, low);
	restore_fn(flags);
	return 0;
}

unsigned long x86_x2apic_enabled_result(unsigned long msr,
					unsigned long enable_bit)
{
	return msr & enable_bit;
}

int x86_init_lapic_bsp_body_result(unsigned long enabled,
				   void (*select_fn)(int))
{
	int mode;

	if (!select_fn)
		return -EINVAL;
	mode = !!enabled;
	select_fn(mode);
	return mode;
}

int x86_init_lapic_body_result(int x2apic_enabled, void **lapic_vp_slot,
			       int apic_base_msr, unsigned long page_mask,
			       unsigned long page_size,
			       unsigned long apic_enable_bit,
			       unsigned long (*read_msr_fn)(int),
			       void (*write_msr_fn)(int, unsigned long),
			       void *(*map_fixed_fn)(unsigned long, unsigned long,
						      int),
			       void (*write_fn)(int, unsigned int))
{
	unsigned long base;

	if (!write_fn)
		return -EINVAL;
	if (!x2apic_enabled) {
		if (!lapic_vp_slot || !read_msr_fn ||
		    !write_msr_fn || !map_fixed_fn)
			return -EINVAL;
		base = read_msr_fn(apic_base_msr);
		if (!*lapic_vp_slot)
			*lapic_vp_slot = map_fixed_fn(base & page_mask,
						      page_size, 1);
		base |= apic_enable_bit;
		write_msr_fn(apic_base_msr, base);
	}
	write_fn(0x0f0, 0x1ff);
	write_fn(0x340, 0xf0);
	return 0;
}

int x86_init_pstate_turbo_body_result(
	int no_turbo_arg, int platform_info_msr, int turbo_ratio_msr,
	int perf_ctl_msr, int energy_perf_bias_msr,
	int (*running_on_kvm_fn)(void),
	void (*cpuid6_fn)(unsigned long *, unsigned long *),
	unsigned long (*read_msr_fn)(int),
	void (*write_msr_fn)(int, unsigned long))
{
	unsigned long value;
	unsigned long eax, ecx;

	if (!running_on_kvm_fn || !cpuid6_fn || !read_msr_fn || !write_msr_fn)
		return -EINVAL;
	if (running_on_kvm_fn())
		return 0;
	cpuid6_fn(&eax, &ecx);
	if (!(ecx & 0x01))
		return 0;

	value = read_msr_fn(platform_info_msr) & 0xff00;
	if (eax & (1UL << 1)) {
		if (!no_turbo_arg) {
			value = (read_msr_fn(turbo_ratio_msr) & 0xff) << 8;
			value &= ~(1UL << 32);
		}
		else {
			value |= 1UL << 32;
		}
	}

	write_msr_fn(perf_ctl_msr, value);
	if (ecx & (1UL << 3))
		write_msr_fn(energy_perf_bias_msr, 0);
	return 0;
}

int x86_init_pat_body_result(
	unsigned long *boot_pat_state, int cr_pat_msr,
	void (*cpuid_edx_fn)(unsigned long, unsigned long *),
	unsigned long (*read_msr_fn)(int),
	void (*write_msr_fn)(int, unsigned long), void (*log_fn)(int))
{
	unsigned long pat;
	unsigned long edx;

	if (!boot_pat_state || !cpuid_edx_fn || !read_msr_fn || !write_msr_fn)
		return -EINVAL;
	cpuid_edx_fn(1, &edx);
	if (!(edx & (1UL << 16))) {
		if (log_fn)
			log_fn(1);
		return 0;
	}

	pat = (6UL << 0) | (1UL << 8) | (7UL << 16) | (0UL << 24) |
	      (6UL << 32) | (1UL << 40) | (7UL << 48) | (0UL << 56);
	if (!*boot_pat_state)
		*boot_pat_state = read_msr_fn(cr_pat_msr);
	write_msr_fn(cr_pat_msr, pat);
	if (log_fn)
		log_fn(2);
	return 0;
}

int x86_init_syscall_body_result(int efer_msr, int star_msr, int lstar_msr,
				 unsigned long kernel_cs,
				 unsigned long user_cs,
				 unsigned long syscall_addr,
				 unsigned long (*read_msr_fn)(int),
				 void (*write_msr_fn)(int, unsigned long))
{
	unsigned long r;

	if (!read_msr_fn || !write_msr_fn)
		return -EINVAL;
	r = read_msr_fn(efer_msr);
	r |= 1;
	write_msr_fn(efer_msr, r);
	r = (kernel_cs << 32) | (user_cs << 48);
	write_msr_fn(star_msr, r);
	write_msr_fn(lstar_msr, syscall_addr);
	return 0;
}

int x86_enable_no_execute_body_result(int no_execute_available_arg,
				      int efer_msr, unsigned long nxe_bit,
				      unsigned long (*read_msr_fn)(int),
				      void (*write_msr_fn)(int, unsigned long))
{
	if (!no_execute_available_arg)
		return 0;
	if (!read_msr_fn || !write_msr_fn)
		return -EINVAL;
	write_msr_fn(efer_msr, read_msr_fn(efer_msr) | nxe_bit);
	return 0;
}

int x86_check_no_execute_body_result(
	int *no_execute_available_slot,
	void (*cpuid_edx_fn)(unsigned long, unsigned long *),
	void (*log_fn)(int, int), void (*enable_ptattr_fn)(void))
{
	unsigned long edx;

	if (!no_execute_available_slot || !cpuid_edx_fn)
		return -EINVAL;
	cpuid_edx_fn(0x80000001UL, &edx);
	*no_execute_available_slot = (edx & (1UL << 20)) ? 1 : 0;
	if (log_fn)
		log_fn(1, *no_execute_available_slot);
	if (*no_execute_available_slot) {
		if (!enable_ptattr_fn)
			return -EINVAL;
		enable_ptattr_fn();
	}
	return 0;
}

int x86_init_gettime_support_body_result(
	int *gettime_local_support_slot,
	void (*cpuid_edx_fn)(unsigned long, unsigned long *),
	void (*log_fn)(int))
{
	unsigned long edx;

	if (!gettime_local_support_slot || !cpuid_edx_fn)
		return -EINVAL;
	cpuid_edx_fn(0x80000007UL, &edx);
	if (edx & (1UL << 8)) {
		*gettime_local_support_slot = 1;
		if (log_fn)
			log_fn(3);
	}
	return 0;
}

int x86_init_cpu_body_result(
	void (*enable_page_protection_fault_fn)(void),
	void (*enable_no_execute_fn)(void), void (*init_fpu_fn)(void),
	void (*init_lapic_fn)(void), void (*init_syscall_fn)(void),
	void (*init_perfctr_fn)(void), void (*init_pstate_turbo_fn)(void),
	void (*init_pat_fn)(void))
{
	if (!enable_page_protection_fault_fn || !enable_no_execute_fn ||
	    !init_fpu_fn || !init_lapic_fn || !init_syscall_fn ||
	    !init_perfctr_fn || !init_pstate_turbo_fn || !init_pat_fn)
		return -EINVAL;
	enable_page_protection_fault_fn();
	enable_no_execute_fn();
	init_fpu_fn();
	init_lapic_fn();
	init_syscall_fn();
	init_perfctr_fn();
	init_pstate_turbo_fn();
	init_pat_fn();
	return 0;
}

int x86_setup_phase1_body_result(void (*disable_interrupt_fn)(void),
				 void (*init_idt_fn)(void),
				 void (*init_gdt_fn)(void),
				 void (*init_page_table_fn)(void))
{
	if (!disable_interrupt_fn || !init_idt_fn ||
	    !init_gdt_fn || !init_page_table_fn)
		return -EINVAL;
	disable_interrupt_fn();
	init_idt_fn();
	init_gdt_fn();
	init_page_table_fn();
	return 0;
}

int x86_setup_phase2_body_result(void (*check_no_execute_fn)(void),
				 void (*init_lapic_bsp_fn)(void),
				 void (*init_cpu_fn)(void),
				 void (*init_gettime_support_fn)(void),
				 void (*log_fn)(int))
{
	if (!check_no_execute_fn || !init_lapic_bsp_fn ||
	    !init_cpu_fn || !init_gettime_support_fn)
		return -EINVAL;
	check_no_execute_fn();
	init_lapic_bsp_fn();
	init_cpu_fn();
	init_gettime_support_fn();
	if (log_fn)
		log_fn(4);
	return 0;
}

int x86_ihk_mc_init_ap_body_result(
	void **trampoline_va_slot, void **first_page_va_slot,
	unsigned long ap_trampoline_arg, unsigned long ap_trampoline_size_arg,
	unsigned long page_size_arg,
	void *(*map_fixed_fn)(unsigned long, unsigned long, int),
	int (*get_ncpus_fn)(void), void (*init_processors_fn)(int),
	void (*assign_processor_id_fn)(void), void (*init_smp_processor_fn)(void),
	void (*log_fn)(int, unsigned long))
{
	int ncpus;

	if (!trampoline_va_slot || !first_page_va_slot || !map_fixed_fn ||
	    !get_ncpus_fn || !init_processors_fn || !assign_processor_id_fn ||
	    !init_smp_processor_fn)
		return -EINVAL;
	*trampoline_va_slot = map_fixed_fn(ap_trampoline_arg,
					   ap_trampoline_size_arg, 0);
	if (log_fn)
		log_fn(1, ap_trampoline_arg);
	*first_page_va_slot = map_fixed_fn(0, page_size_arg, 0);
	ncpus = get_ncpus_fn();
	if (log_fn)
		log_fn(2, (unsigned long)ncpus);
	init_processors_fn(ncpus);
	assign_processor_id_fn();
	init_smp_processor_fn();
	return 0;
}

int x86_running_on_kvm_body_result(
	unsigned long signature_leaf,
	void (*cpuid_fn)(unsigned long, unsigned long *, unsigned long *,
			 unsigned long *, unsigned long *))
{
	unsigned long eax, ebx, ecx, edx;

	if (!cpuid_fn)
		return 0;
	cpuid_fn(signature_leaf, &eax, &ebx, &ecx, &edx);
	return ebx == 0x4b4d564bUL && ecx == 0x564b4d56UL &&
		edx == 0x0000004dUL;
}

int x86_pvclock_available_body_result(
	long *pvti_msr_slot, unsigned long signature_leaf,
	unsigned long features_leaf, int feature_new_bit, int feature_old_bit,
	long msr_new, long msr_old,
	void (*cpuid_fn)(unsigned long, unsigned long *, unsigned long *,
			 unsigned long *, unsigned long *),
	void (*log_fn)(int))
{
	unsigned long eax, ebx, ecx, edx;

	if (!pvti_msr_slot || feature_new_bit < 0 || feature_new_bit >= 63 ||
	    feature_old_bit < 0 || feature_old_bit >= 63 || !cpuid_fn)
		return 0;
	if (log_fn)
		log_fn(1);
	cpuid_fn(signature_leaf, &eax, &ebx, &ecx, &edx);
	if ((eax && eax < features_leaf) || ebx != 0x4b4d564bUL ||
	    ecx != 0x564b4d56UL || edx != 0x0000004dUL) {
		if (log_fn)
			log_fn(2);
		return 0;
	}
	cpuid_fn(features_leaf, &eax, &ebx, &ecx, &edx);
	if (eax & (1UL << feature_new_bit)) {
		*pvti_msr_slot = msr_new;
		if (log_fn)
			log_fn(3);
		return 1;
	}
	if (eax & (1UL << feature_old_bit)) {
		*pvti_msr_slot = msr_old;
		if (log_fn)
			log_fn(4);
		return 1;
	}
	if (log_fn)
		log_fn(5);
	return 0;
}

int x86_arch_setup_pvclock_body_result(
	void **pvti_slot, int *pvti_npages_slot, int num_processors,
	unsigned long pvti_entry_size, unsigned long page_size, int page_p2align,
	unsigned long alloc_flag, int pg_kernel, char *file, int line,
	int (*available_fn)(void),
	void *(*alloc_fn)(int, int, unsigned long, int, int, unsigned long, char *,
			  int),
	void (*log_fn)(int))
{
	size_t size;
	int npages;
	void *pages;

	if (!pvti_slot || !pvti_npages_slot || num_processors < 0 ||
	    !pvti_entry_size || !page_size || !available_fn || !alloc_fn)
		return -EINVAL;
	if (log_fn)
		log_fn(6);
	if (!available_fn()) {
		if (log_fn)
			log_fn(7);
		return 0;
	}
	size = (size_t)num_processors * pvti_entry_size;
	npages = (int)((size + page_size - 1) / page_size);
	*pvti_npages_slot = npages;
	pages = alloc_fn(npages, page_p2align, alloc_flag, -1, pg_kernel,
			 ~0UL, file, line);
	*pvti_slot = pages;
	if (!pages) {
		if (log_fn)
			log_fn(8);
		return -ENOMEM;
	}
	memset(pages, 0, page_size * (unsigned long)npages);
	if (log_fn)
		log_fn(9);
	return 0;
}

int x86_arch_start_pvclock_body_result(
	void *pvti, long pvti_msr, unsigned long pvti_entry_size,
	unsigned long enable_bit, int (*current_cpu_fn)(void),
	unsigned long (*virt_to_phys_fn)(void *),
	void (*write_msr_fn)(int, unsigned long), void (*log_fn)(int))
{
	int cpu;
	void *entry;
	unsigned long phys;

	if (log_fn)
		log_fn(10);
	if (!pvti) {
		if (log_fn)
			log_fn(11);
		return 0;
	}
	if (!pvti_entry_size || !current_cpu_fn || !virt_to_phys_fn ||
	    !write_msr_fn)
		return -EINVAL;
	cpu = current_cpu_fn();
	if (cpu < 0)
		return -EINVAL;
	entry = (char *)pvti + (unsigned long)cpu * pvti_entry_size;
	phys = virt_to_phys_fn(entry);
	write_msr_fn((int)pvti_msr, phys | enable_bit);
	if (log_fn)
		log_fn(12);
	return 0;
}

int x86_call_ap_func_body_result(int *cpu_boot_status_slot,
				 void (*next_func)(void))
{
	if (!cpu_boot_status_slot || !next_func)
		return -EINVAL;
	*cpu_boot_status_slot = 1;
	next_func();
	return 0;
}

int x86_show_stack_body_result(
	unsigned long *sp, unsigned long lower_bound, unsigned long upper_bound,
	void (*log_fn)(unsigned long, unsigned long, unsigned long))
{
	unsigned long fp;
	unsigned long ip;

	if (!log_fn)
		return -EINVAL;
	while ((unsigned long)sp >= lower_bound &&
	       (unsigned long)sp < upper_bound) {
		fp = sp[0];
		ip = sp[1];
		log_fn(ip, (unsigned long)sp, fp);
		sp = (void *)fp;
	}
	return 0;
}

int x86_arch_print_pre_interrupt_stack_body_result(
	const void *regs_arg, unsigned long error_offset,
	unsigned long rsp_offset, unsigned long rip_offset,
	unsigned long pf_user, unsigned long scan_window,
	void (*log_fn)(int), void (*print_stack_fn)(void *, unsigned long))
{
	const char *regs = regs_arg;
	unsigned long error;
	unsigned long rip;
	unsigned long *rbp;

	if (!regs || !print_stack_fn)
		return -EINVAL;
	error = *(const unsigned long *)(regs + error_offset);
	if (error & pf_user)
		return 0;
	if (log_fn)
		log_fn(13);
	rbp = (unsigned long *)*(const unsigned long *)(regs + rsp_offset);
	while ((unsigned long)rbp > rbp[0] ||
	       (unsigned long)rbp + scan_window < rbp[0])
		rbp++;
	rip = *(const unsigned long *)(regs + rip_offset);
	print_stack_fn(rbp, rip);
	return 0;
}

int x86_arch_print_stack_body_result(
	void *rbp, void (*log_fn)(int),
	void (*print_stack_fn)(void *, unsigned long))
{
	if (!print_stack_fn)
		return -EINVAL;
	if (log_fn)
		log_fn(14);
	print_stack_fn(rbp, 0);
	return 0;
}

int x86_print_user_context_body_result(
	const struct x86_user_context *uctx,
	void (*log_fn)(int, unsigned long, unsigned long, unsigned long,
		       unsigned long))
{
	const struct x86_basic_regs *regs;

	if (!uctx || !log_fn)
		return -EINVAL;
	regs = &uctx->gpr;
	log_fn(20, regs->cs, regs->rip, 0, 0);
	log_fn(21, regs->rax, regs->rbx, regs->rcx, regs->rdx);
	log_fn(22, regs->rsi, regs->rdi, regs->rsp, 0);
	return 0;
}

int x86_arch_show_interrupt_context_body_result(
	const struct x86_user_context *uctx, unsigned long (*lock_fn)(void),
	void (*unlock_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long, unsigned long,
		       unsigned long))
{
	const struct x86_basic_regs *regs;
	unsigned long irqflags;

	if (!uctx || !lock_fn || !unlock_fn || !log_fn)
		return -EINVAL;
	regs = &uctx->gpr;
	irqflags = lock_fn();
	log_fn(1, regs->cs, regs->rip, 0, 0);
	log_fn(2, regs->rax, regs->rbx, regs->rcx, regs->rdx);
	log_fn(3, regs->rsi, regs->rdi, regs->rsp, regs->rbp);
	log_fn(4, regs->r8, regs->r9, regs->r10, regs->r11);
	log_fn(5, regs->r12, regs->r13, regs->r14, regs->r15);
	log_fn(6, regs->cs, regs->ss, regs->rflags, regs->orig_rax);
	unlock_fn(irqflags);
	return 0;
}

int x86_arch_save_panic_regs_body_result(
	const struct x86_user_context *regs, const struct x86_kregs *current_ctx,
	unsigned long *panic_regs, unsigned long *paniced_slot,
	unsigned long user_end, unsigned long enter_user_mode_addr,
	void (*log_fn)(int, unsigned long))
{
	uint32_t *sregs;

	if (!regs || !panic_regs || !paniced_slot)
		return -EINVAL;

	if (regs->gpr.rip > user_end) {
		panic_regs[0] = regs->gpr.rax;
		panic_regs[1] = regs->gpr.rbx;
		panic_regs[2] = regs->gpr.rcx;
		panic_regs[3] = regs->gpr.rdx;
		panic_regs[4] = regs->gpr.rsi;
		panic_regs[5] = regs->gpr.rdi;
		panic_regs[6] = regs->gpr.rbp;
		panic_regs[7] = regs->gpr.rsp;
		panic_regs[8] = regs->gpr.r8;
		panic_regs[9] = regs->gpr.r9;
		panic_regs[10] = regs->gpr.r10;
		panic_regs[11] = regs->gpr.r11;
		panic_regs[12] = regs->gpr.r12;
		panic_regs[13] = regs->gpr.r13;
		panic_regs[14] = regs->gpr.r14;
		panic_regs[15] = regs->gpr.r15;
		panic_regs[16] = regs->gpr.rip;
	} else {
		if (!current_ctx || !log_fn)
			return -EINVAL;
		log_fn(15, regs->gpr.rip);
		panic_regs[0] = 0;
		panic_regs[1] = current_ctx->rbx;
		panic_regs[2] = 0;
		panic_regs[3] = 0;
		panic_regs[4] = current_ctx->rsi;
		panic_regs[5] = current_ctx->rdi;
		panic_regs[6] = current_ctx->rbp;
		panic_regs[7] = current_ctx->rsp;
		panic_regs[8] = 0;
		panic_regs[9] = 0;
		panic_regs[10] = 0;
		panic_regs[11] = 0;
		panic_regs[12] = regs->gpr.r12;
		panic_regs[13] = regs->gpr.r13;
		panic_regs[14] = regs->gpr.r14;
		panic_regs[15] = regs->gpr.r15;
		panic_regs[16] = enter_user_mode_addr;
	}

	sregs = (uint32_t *)&panic_regs[17];
	sregs[0] = regs->gpr.rflags;
	sregs[1] = regs->gpr.cs;
	sregs[2] = regs->gpr.ss;
	sregs[3] = regs->sr.ds;
	sregs[4] = regs->sr.es;
	sregs[5] = regs->sr.fs;
	sregs[6] = regs->sr.gs;
	*paniced_slot = 1;
	return 0;
}

int x86_arch_clear_panic_body_result(unsigned long *paniced_slot)
{
	if (!paniced_slot)
		return -EINVAL;
	*paniced_slot = 0;
	return 0;
}

int x86_mcexec_v10_trace_enter_user_body_result(
	const struct x86_user_context *regs, const void *thread_arg,
	int *counter, int limit, int cpu,
	const struct x86_trace_enter_user_offsets *offsets,
	void (*log_fn)(int, int, int, unsigned long, unsigned long,
		       unsigned long, unsigned long, unsigned long, int))
{
	const char *thread = thread_arg;
	const char *proc;
	int pid = -1;
	int tid = -1;
	int status = -1;
	unsigned long rip = 0;
	unsigned long rsp = 0;
	unsigned long cs = 0;
	unsigned long ss = 0;
	unsigned long rflags = 0;

	if (!counter || !offsets || !log_fn)
		return -EINVAL;
	if (*counter >= limit)
		return 0;
	if (thread) {
		tid = *(const int *)(thread + offsets->thread_tid_offset);
		status = *(const int *)(thread + offsets->thread_status_offset);
		proc = *(const char * const *)(thread + offsets->thread_proc_offset);
		if (proc)
			pid = *(const int *)(proc + offsets->process_pid_offset);
	}
	if (regs) {
		rip = regs->gpr.rip;
		rsp = regs->gpr.rsp;
		cs = regs->gpr.cs;
		ss = regs->gpr.ss;
		rflags = regs->gpr.rflags;
	}
	log_fn(cpu, pid, tid, rip, rsp, cs, ss, rflags, status);
	(*counter)++;
	return 1;
}

int x86_release_runq_lock_body_result(
	void *cpu_local, unsigned long runq_lock_offset,
	unsigned long runq_irqstate_offset,
	void (*unlock_fn)(void *, unsigned long))
{
	char *base = cpu_local;
	void *lock;
	unsigned long irqstate;

	if (!cpu_local || !unlock_fn)
		return -EINVAL;
	lock = base + runq_lock_offset;
	irqstate = *(unsigned long *)(base + runq_irqstate_offset);
	unlock_fn(lock, irqstate);
	return 0;
}

int x86_set_kstack_body_result(void *cpu_local,
			       unsigned long kernel_stack_offset,
			       unsigned long tss_rsp0_offset,
			       unsigned long stack_pointer)
{
	char *base = cpu_local;

	if (!cpu_local)
		return -EINVAL;
	*(unsigned long *)(base + kernel_stack_offset) = stack_pointer;
	*(unsigned long *)(base + tss_rsp0_offset) = stack_pointer;
	return 0;
}
#endif

static unsigned char fallback_stack[256];
static struct fake_cpu_local cpu_locals[4];
#ifndef USE_C_X86_CPU_MODEL
static unsigned char rust_x86_local_area[4 * 4 * 4096]
	__attribute__((aligned(4096)));
#endif
int num_processors;
static unsigned long msr_value;
static unsigned long written_msr;
static int write_count;
static int ipi_count;
static unsigned long last_apic_id;
static int last_vector;
static unsigned long log_digest;
static int lapic_write_count;
static int lapic_write_regs[16];
static unsigned int lapic_write_values[16];
static int mb_count;
static int disable_count;
static int restore_count;
static unsigned long restored_flags[8];
static int wait_idle_count;
static int icr_count;
static unsigned int icr_high[8];
static unsigned int icr_low[8];
static int selected_mode;
static int select_count;
static unsigned long lapic_msr_value;
static int read_msr_count;
static int last_read_msr;
static int write_msr_count;
static int last_write_msr;
static unsigned long last_write_msr_value;
static int write_msr_regs[16];
static unsigned long write_msr_values[16];
static int map_fixed_count;
static unsigned long map_fixed_phys;
static unsigned long map_fixed_size;
static int map_fixed_uncached;
static unsigned char lapic_mapping[4096];
static int running_on_kvm_value;
static unsigned long cpuid6_eax_value;
static unsigned long cpuid6_ecx_value;
static int cpuid6_count;
static unsigned long cpuid_edx_value;
static unsigned long last_cpuid_edx_op;
static int cpuid_edx_count;
static unsigned long platform_info_value;
static unsigned long turbo_ratio_value;
static unsigned long pat_msr_value;
int cpu_log_count;
int cpu_log_events[32];
static int cpu_value_log_count;
static int cpu_value_log_events[8];
static int cpu_value_log_values[8];
static int enable_ptattr_count;
static int order_count;
static int order_events[32];
static int delay_count;
static int last_delay_us;
static int fake_ncpus_value;
static int init_processors_arg;
static int cpu_ulong_log_count;
static int cpu_ulong_log_events[8];
static unsigned long cpu_ulong_log_values[8];
static int cpuid_leaf_count;
static unsigned long cpuid_signature_eax;
static unsigned long cpuid_signature_ebx;
static unsigned long cpuid_signature_ecx;
static unsigned long cpuid_signature_edx;
static unsigned long cpuid_features_eax;
static unsigned char pvclock_pages[8192];
static int pvclock_available_value;
static int pvclock_alloc_count;
static int pvclock_alloc_npages;
static int pvclock_alloc_p2align;
static unsigned long pvclock_alloc_flag;
static int pvclock_alloc_is_user;
static unsigned long pvclock_alloc_virt_addr;
static char *pvclock_alloc_file;
static int pvclock_alloc_line;
static int pvclock_alloc_fail;
struct pvclock_vsyscall_time_info {
	long contents[64/sizeof(long)];
};
struct pvclock_vsyscall_time_info *pvti;
int pvti_npages;
long pvti_msr;
static int current_cpu_value;
static int virt_to_phys_count;
static void *last_virt_to_phys_ptr;
static unsigned long virt_to_phys_base;
static int ap_next_count;
static int public_call_ap_status;
static int stack_frame_log_count;
static unsigned long stack_frame_ips[8];
static unsigned long stack_frame_sps[8];
static unsigned long stack_frame_fps[8];
static int stack_print_count;
static void *stack_print_rbp;
static unsigned long stack_print_first;
static int context_log_count;
static int context_log_events[16];
static unsigned long context_log_a[16];
static unsigned long context_log_b[16];
static unsigned long context_log_c[16];
static unsigned long context_log_d[16];
static int context_lock_count;
static int context_unlock_count;
static unsigned long context_unlock_flags;
static int trace_log_count;
static int trace_cpu;
static int trace_pid;
static int trace_tid;
static unsigned long trace_rip;
static unsigned long trace_rsp;
static unsigned long trace_cs;
static unsigned long trace_ss;
static unsigned long trace_rflags;
static int trace_status;
static int runq_unlock_count;
static void *runq_unlock_lock;
static unsigned long runq_unlock_irqstate;
static int *boot_cpu_status_slot;
static int boot_cpu_wakeup_count;
static int boot_cpu_pause_count;
static int boot_cpu_last_cpuid;
static unsigned long boot_cpu_last_trampoline;
static unsigned long boot_cpu_transit_value;
static unsigned long public_boot_trampoline[8];
static unsigned long public_boot_code[8];
static unsigned long public_boot_ap_trampoline;
static void *public_boot_setup_ap;
static struct x86_trace_enter_user_offsets public_trace_offsets;
static const void *public_trace_thread;
static int public_mcexec_v10_enter_user_logs;
static struct fake_runq_local *public_runq_local;

static void require_line(int condition, int line)
{
	if (!condition) {
		printf("x86_cpu_helpers require failed line=%d\n", line);
		exit(2);
	}
}

#define require(condition) require_line((condition), __LINE__)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void *fake_stack_fn(void)
{
	return fallback_stack + sizeof(fallback_stack);
}

static void fake_write_msr(unsigned long value)
{
	written_msr = value;
	write_count++;
}

static unsigned long fake_read_msr(void)
{
	return msr_value;
}

static void *fake_cpu_local(int cpu)
{
	if (cpu < 0 || cpu >= 4)
		return NULL;
	return &cpu_locals[cpu];
}

#ifdef USE_C_X86_CPU_MODEL
int ihk_mc_get_interrupt_id(int cpu)
{
	return ((struct fake_cpu_local *)fake_cpu_local(cpu))->apic_id;
}

void arch_clear_panic(void)
{
	cpu_locals[0].paniced = 0;
}
#endif

static void seed_public_interrupt_id_local(int cpu, unsigned long apic_id)
{
#ifdef USE_C_X86_CPU_MODEL
	cpu_locals[cpu].apic_id = apic_id;
#else
	memset(rust_x86_local_area, 0, sizeof(rust_x86_local_area));
	locals = rust_x86_local_area;
	*(unsigned long *)(rust_x86_local_area +
			(size_t)cpu * 4 * 4096 +
			offsetof(struct fake_cpu_local, apic_id)) = apic_id;
	#endif
}

static void seed_public_panic_local(unsigned long paniced)
{
#ifdef USE_C_X86_CPU_MODEL
	cpu_locals[0].paniced = paniced;
#else
	memset(rust_x86_local_area, 0, sizeof(rust_x86_local_area));
	locals = rust_x86_local_area;
	*(unsigned long *)(rust_x86_local_area +
			offsetof(struct fake_cpu_local, paniced)) = paniced;
#endif
}

static unsigned long read_public_panic_local(void)
{
#ifdef USE_C_X86_CPU_MODEL
	return cpu_locals[0].paniced;
#else
	return *(unsigned long *)(rust_x86_local_area +
			offsetof(struct fake_cpu_local, paniced));
#endif
}

static void fake_issue_ipi(unsigned long apic_id, int vector)
{
	last_apic_id = apic_id;
	last_vector = vector;
	ipi_count++;
}

static void fake_interrupt_log(int event, int cpu, int vector)
{
	mix(&log_digest, (unsigned long)(unsigned int)event);
	mix(&log_digest, (unsigned long)(unsigned int)cpu);
	mix(&log_digest, (unsigned long)(unsigned int)vector);
}

#ifdef USE_C_X86_CPU_MODEL
int ihk_mc_interrupt_cpu(int cpu, int vector)
{
	return x86_interrupt_cpu_result(cpu, vector, num_processors,
			fake_cpu_local, offsetof(struct fake_cpu_local, apic_id),
			fake_issue_ipi, fake_interrupt_log);
}
#else
void x86_issue_ipi_bridge(unsigned long apic_id, int vector)
{
	fake_issue_ipi(apic_id, vector);
}

void x86_interrupt_log_bridge(int event, int cpu, int vector)
{
	fake_interrupt_log(event, cpu, vector);
}
#endif

static void reset_apic_trace(void)
{
	lapic_write_count = 0;
	mb_count = 0;
	disable_count = 0;
	restore_count = 0;
	wait_idle_count = 0;
	icr_count = 0;
	select_count = 0;
	read_msr_count = 0;
	write_msr_count = 0;
	map_fixed_count = 0;
	cpuid6_count = 0;
	cpuid_edx_count = 0;
	cpu_log_count = 0;
	cpu_value_log_count = 0;
	enable_ptattr_count = 0;
	order_count = 0;
	delay_count = 0;
	last_delay_us = 0;
	init_processors_arg = -1;
	cpu_ulong_log_count = 0;
	cpuid_leaf_count = 0;
	pvclock_alloc_count = 0;
	pvclock_alloc_npages = 0;
	pvclock_alloc_p2align = 0;
	pvclock_alloc_flag = 0;
	pvclock_alloc_is_user = 0;
	pvclock_alloc_virt_addr = 0;
	pvclock_alloc_file = NULL;
	pvclock_alloc_line = 0;
	pvclock_alloc_fail = 0;
	current_cpu_value = 0;
	virt_to_phys_count = 0;
	last_virt_to_phys_ptr = NULL;
	virt_to_phys_base = 0;
	ap_next_count = 0;
	public_call_ap_status = 0;
	stack_frame_log_count = 0;
	stack_print_count = 0;
	stack_print_rbp = NULL;
	stack_print_first = 0;
	context_log_count = 0;
	context_lock_count = 0;
	context_unlock_count = 0;
	context_unlock_flags = 0;
	trace_log_count = 0;
	trace_cpu = 0;
	trace_pid = 0;
	trace_tid = 0;
	trace_rip = 0;
	trace_rsp = 0;
	trace_cs = 0;
	trace_ss = 0;
	trace_rflags = 0;
	trace_status = 0;
	runq_unlock_count = 0;
	runq_unlock_lock = NULL;
	runq_unlock_irqstate = 0;
	boot_cpu_status_slot = NULL;
	boot_cpu_wakeup_count = 0;
	boot_cpu_pause_count = 0;
	boot_cpu_last_cpuid = -1;
	boot_cpu_last_trampoline = 0;
	boot_cpu_transit_value = 0;
	memset(public_boot_trampoline, 0, sizeof(public_boot_trampoline));
	memset(public_boot_code, 0, sizeof(public_boot_code));
	public_boot_ap_trampoline = 0;
	public_boot_setup_ap = NULL;
	memset(&public_trace_offsets, 0, sizeof(public_trace_offsets));
	public_trace_thread = NULL;
	public_mcexec_v10_enter_user_logs = 0;
	public_runq_local = NULL;
}

static void fake_lapic_write(int reg, unsigned int value)
{
	lapic_write_regs[lapic_write_count] = reg;
	lapic_write_values[lapic_write_count] = value;
	lapic_write_count++;
}

static void fake_mb(void)
{
	mb_count++;
}

static unsigned long fake_disable_save(void)
{
	disable_count++;
	return 0xabc0UL + (unsigned long)disable_count;
}

static void fake_restore(unsigned long flags)
{
	restored_flags[restore_count] = flags;
	restore_count++;
}

static void fake_wait_idle(void)
{
	wait_idle_count++;
}

static void fake_icr_write(unsigned int high, unsigned int low)
{
	icr_high[icr_count] = high;
	icr_low[icr_count] = low;
	icr_count++;
}

static void fake_select_lapic_mode(int mode)
{
	selected_mode = mode;
	select_count++;
}

static unsigned long fake_read_msr_reg(int reg)
{
	last_read_msr = reg;
	read_msr_count++;
	if (reg == 0xce)
		return platform_info_value;
	if (reg == 0x1ad)
		return turbo_ratio_value;
	if (reg == 0x277)
		return pat_msr_value;
	return lapic_msr_value;
}

static void fake_write_msr_reg(int reg, unsigned long value)
{
	last_write_msr = reg;
	last_write_msr_value = value;
	write_msr_regs[write_msr_count] = reg;
	write_msr_values[write_msr_count] = value;
	write_msr_count++;
}

static void *fake_map_fixed(unsigned long phys, unsigned long size, int uncached)
{
	map_fixed_phys = phys;
	map_fixed_size = size;
	map_fixed_uncached = uncached;
	map_fixed_count++;
	if (phys == 0 && size == 4096)
		return lapic_mapping + 128;
	return lapic_mapping;
}

static int fake_running_on_kvm(void)
{
	return running_on_kvm_value;
}

static void fake_cpuid6(unsigned long *eaxp, unsigned long *ecxp)
{
	*eaxp = cpuid6_eax_value;
	*ecxp = cpuid6_ecx_value;
	cpuid6_count++;
}

static void fake_cpuid_edx(unsigned long op, unsigned long *edxp)
{
	last_cpuid_edx_op = op;
	*edxp = cpuid_edx_value;
	cpuid_edx_count++;
}

static void fake_cpu_log(int event)
{
	cpu_log_events[cpu_log_count] = event;
	cpu_log_count++;
}

static void fake_cpuid_leaf(unsigned long op, unsigned long *eaxp,
			    unsigned long *ebxp, unsigned long *ecxp,
			    unsigned long *edxp);
static int fake_pvclock_available_body_bridge(void);
static void *fake_alloc_aligned_pages_node(int npages, int p2align,
					   unsigned long flag, int node,
					   int is_user,
					   unsigned long virt_addr, char *file,
					   int line);
static int fake_current_cpu(void);
static unsigned long fake_virt_to_phys_ptr(void *ptr);
static void fake_write_msr_reg(int reg, unsigned long value);

#ifdef USE_C_X86_CPU_MODEL
int arch_setup_pvclock(void)
{
	return x86_arch_setup_pvclock_body_result((void **)&pvti,
			&pvti_npages, num_processors, sizeof(*pvti),
			4096, 0, 0x000002UL, 0,
			(char *)"arch/x86_64/kernel/cpu.c", 0,
			fake_pvclock_available_body_bridge,
			fake_alloc_aligned_pages_node, fake_cpu_log);
}

void arch_start_pvclock(void)
{
	x86_arch_start_pvclock_body_result(pvti, pvti_msr, sizeof(*pvti),
			1, fake_current_cpu, fake_virt_to_phys_ptr,
			fake_write_msr_reg, fake_cpu_log);
}
#else
int x86_current_cpu_bridge(void)
{
	return fake_current_cpu();
}

unsigned long x86_virt_to_phys_bridge(void *addr)
{
	return fake_virt_to_phys_ptr(addr);
}

void x86_write_msr_bridge(int reg, unsigned long value)
{
	fake_write_msr_reg(reg, value);
}

void x86_cpuid_leaf_bridge(unsigned long op, unsigned long *eaxp,
			   unsigned long *ebxp, unsigned long *ecxp,
			   unsigned long *edxp)
{
	fake_cpuid_leaf(op, eaxp, ebxp, ecxp, edxp);
}

void *x86_alloc_aligned_pages_node_bridge(int npages, int p2align,
					  unsigned long flag, int node,
					  int is_user,
					  unsigned long virt_addr,
					  char *file, int line)
{
	return fake_alloc_aligned_pages_node(npages, p2align, flag, node,
			is_user, virt_addr, file, line);
}

void x86_pvclock_log_bridge(int event)
{
	fake_cpu_log(event);
}
#endif

static void fake_delay_us(int us)
{
	last_delay_us = us;
	delay_count++;
}

void arch_delay(int us)
{
	fake_delay_us(us);
}

static void fake_cpu_value_log(int event, int value)
{
	cpu_value_log_events[cpu_value_log_count] = event;
	cpu_value_log_values[cpu_value_log_count] = value;
	cpu_value_log_count++;
}

static void fake_enable_ptattr(void)
{
	enable_ptattr_count++;
}

static void record_order(int event)
{
	order_events[order_count] = event;
	order_count++;
}

static void fake_order_1(void) { record_order(1); }
static void fake_order_2(void) { record_order(2); }
static void fake_order_3(void) { record_order(3); }
static void fake_order_4(void) { record_order(4); }
static void fake_order_5(void) { record_order(5); }
static void fake_order_6(void) { record_order(6); }
static void fake_order_7(void) { record_order(7); }
static void fake_order_8(void) { record_order(8); }

static int fake_get_ncpus(void)
{
	record_order(20);
	return fake_ncpus_value;
}

static void fake_init_processors(int ncpus)
{
	init_processors_arg = ncpus;
	record_order(21);
}

static void fake_cpu_ulong_log(int event, unsigned long value)
{
	cpu_ulong_log_events[cpu_ulong_log_count] = event;
	cpu_ulong_log_values[cpu_ulong_log_count] = value;
	cpu_ulong_log_count++;
}

static void fake_cpuid_leaf(unsigned long op, unsigned long *eaxp,
			    unsigned long *ebxp, unsigned long *ecxp,
			    unsigned long *edxp)
{
	cpuid_leaf_count++;
	if (op == 0x40000000UL) {
		*eaxp = cpuid_signature_eax;
		*ebxp = cpuid_signature_ebx;
		*ecxp = cpuid_signature_ecx;
		*edxp = cpuid_signature_edx;
	}
	else {
		*eaxp = cpuid_features_eax;
		*ebxp = 0;
		*ecxp = 0;
		*edxp = 0;
	}
}

static int fake_pvclock_available_body_bridge(void)
{
	return x86_pvclock_available_body_result(&pvti_msr, 0x40000000UL,
			0x40000001UL, 3, 0, 0x4b564d01, 0x12,
			fake_cpuid_leaf, fake_cpu_log);
}

static int fake_pvclock_available(void)
{
	return pvclock_available_value;
}

static void *fake_alloc_aligned_pages_node(int npages, int p2align,
					   unsigned long flag, int node,
					   int is_user,
					   unsigned long virt_addr, char *file,
					   int line)
{
	(void)node;
	pvclock_alloc_count++;
	pvclock_alloc_npages = npages;
	pvclock_alloc_p2align = p2align;
	pvclock_alloc_flag = flag;
	pvclock_alloc_is_user = is_user;
	pvclock_alloc_virt_addr = virt_addr;
	pvclock_alloc_file = file;
	pvclock_alloc_line = line;
	memset(pvclock_pages, 0x5a, sizeof(pvclock_pages));
	if (pvclock_alloc_fail)
		return NULL;
	return pvclock_pages;
}

static int fake_current_cpu(void)
{
	return current_cpu_value;
}

static unsigned long fake_virt_to_phys_ptr(void *ptr)
{
	virt_to_phys_count++;
	last_virt_to_phys_ptr = ptr;
	return virt_to_phys_base +
		(unsigned long)((unsigned char *)ptr - pvclock_pages);
}

static void fake_next(void) {}
static void fake_enter_user(void) {}
static void fake_handler(void) {}

static void fake_ap_next(void)
{
	ap_next_count++;
}

#ifdef USE_C_X86_CPU_MODEL
void call_ap_func(void (*next_func)(void))
{
	x86_call_ap_func_body_result(&public_call_ap_status, next_func);
}
#else
int *x86_cpu_boot_status_slot_bridge(void)
{
	return &public_call_ap_status;
}
#endif

static void fake_stack_frame_log(unsigned long ip, unsigned long sp,
				 unsigned long fp)
{
	stack_frame_ips[stack_frame_log_count] = ip;
	stack_frame_sps[stack_frame_log_count] = sp;
	stack_frame_fps[stack_frame_log_count] = fp;
	stack_frame_log_count++;
}

static void fake_print_stack(void *rbp, unsigned long first)
{
	stack_print_count++;
	stack_print_rbp = rbp;
	stack_print_first = first;
}

#ifdef USE_C_X86_CPU_MODEL
void __show_stack(unsigned long *sp)
{
	x86_show_stack_body_result(sp, 0xffff800000000000UL,
			0xffffffff80000000UL, fake_stack_frame_log);
}

void show_context_stack(unsigned long *rbp)
{
	x86_show_stack_body_result(rbp, 0xffff800000000000UL,
			0xffffffff80000000UL, fake_stack_frame_log);
}

void arch_print_pre_interrupt_stack(const struct x86_basic_regs *regs)
{
	x86_arch_print_pre_interrupt_stack_body_result(regs,
			offsetof(struct x86_basic_regs, orig_rax),
			offsetof(struct x86_basic_regs, rsp),
			offsetof(struct x86_basic_regs, rip),
			1UL << 2, 0x10000, fake_cpu_log,
			fake_print_stack);
}

void arch_print_stack(void)
{
	void *rbp;

	asm("mov %%rbp, %0" : "=r"(rbp) );
	x86_arch_print_stack_body_result(rbp, fake_cpu_log,
			fake_print_stack);
}
#else
void x86_stack_frame_log_bridge(unsigned long ip, unsigned long sp,
				unsigned long fp)
{
	fake_stack_frame_log(ip, sp, fp);
}

void x86_print_stack_bridge(void *rbp, unsigned long first)
{
	fake_print_stack(rbp, first);
}
#endif

static unsigned long fake_context_lock(void)
{
	context_lock_count++;
	return 0xfeedfaceUL;
}

static void fake_context_unlock(unsigned long flags)
{
	context_unlock_count++;
	context_unlock_flags = flags;
}

static void fake_context_log(int event, unsigned long a, unsigned long b,
			     unsigned long c, unsigned long d)
{
	context_log_events[context_log_count] = event;
	context_log_a[context_log_count] = a;
	context_log_b[context_log_count] = b;
	context_log_c[context_log_count] = c;
	context_log_d[context_log_count] = d;
	context_log_count++;
}

#ifdef USE_C_X86_CPU_MODEL
void arch_show_interrupt_context(const void *reg)
{
	x86_arch_show_interrupt_context_body_result(reg,
			fake_context_lock, fake_context_unlock,
			fake_context_log);
}
#else
unsigned long x86_kprintf_lock_bridge(void)
{
	return fake_context_lock();
}

void x86_kprintf_unlock_bridge(unsigned long flags)
{
	fake_context_unlock(flags);
}

void x86_context_line_log_bridge(int event, unsigned long a, unsigned long b,
				 unsigned long c, unsigned long d)
{
	fake_context_log(event, a, b, c, d);
}
#endif

static void fake_trace_log(int cpu, int pid, int tid, unsigned long rip,
			   unsigned long rsp, unsigned long cs,
			   unsigned long ss, unsigned long rflags, int status)
{
	trace_log_count++;
	trace_cpu = cpu;
	trace_pid = pid;
	trace_tid = tid;
	trace_rip = rip;
	trace_rsp = rsp;
	trace_cs = cs;
	trace_ss = ss;
	trace_rflags = rflags;
	trace_status = status;
}

static void fake_runq_unlock(void *lock, unsigned long irqstate)
{
	runq_unlock_count++;
	runq_unlock_lock = lock;
	runq_unlock_irqstate = irqstate;
}

static unsigned long fake_boot_pt_phys(void)
{
	return 0x12345000UL;
}

static unsigned long fake_cpu_kstack(int cpuid)
{
	return 0x80000000UL + (unsigned long)cpuid * 0x10000UL;
}

static unsigned long fake_transit_pt(void)
{
	return boot_cpu_transit_value;
}

static void fake_boot_wakeup(int cpuid, unsigned long trampoline)
{
	boot_cpu_wakeup_count++;
	boot_cpu_last_cpuid = cpuid;
	boot_cpu_last_trampoline = trampoline;
	if (boot_cpu_status_slot)
		*boot_cpu_status_slot = 1;
}

static void fake_boot_pause(void)
{
	boot_cpu_pause_count++;
	if (boot_cpu_status_slot && boot_cpu_pause_count > 4)
		*boot_cpu_status_slot = 1;
}

#ifdef USE_C_X86_CPU_MODEL
void ihk_mc_boot_cpu(int cpuid, unsigned long pc)
{
	x86_boot_cpu_body_result(public_boot_trampoline,
			public_boot_code, sizeof(public_boot_code),
			cpuid, pc, public_boot_ap_trampoline,
			&public_call_ap_status, public_boot_setup_ap,
			fake_boot_pt_phys, fake_cpu_kstack,
			fake_transit_pt, fake_boot_wakeup,
			fake_boot_pause);
}

void mcexec_v10_trace_enter_user(struct x86_user_context *regs)
{
	x86_mcexec_v10_trace_enter_user_body_result(regs,
			public_trace_thread,
			&public_mcexec_v10_enter_user_logs, 32,
			fake_current_cpu(), &public_trace_offsets,
			fake_trace_log);
}

void release_runq_lock(void)
{
	x86_release_runq_lock_body_result(public_runq_local,
			offsetof(struct fake_runq_local, runq_lock),
			offsetof(struct fake_runq_local, runq_irqstate),
			fake_runq_unlock);
}
#else
void *x86_boot_trampoline_va_bridge(void)
{
	return public_boot_trampoline;
}

const void *x86_boot_trampoline_code_data_bridge(void)
{
	return public_boot_code;
}

unsigned long x86_boot_trampoline_code_size_bridge(void)
{
	return sizeof(public_boot_code);
}

unsigned long x86_boot_ap_trampoline_bridge(void)
{
	return public_boot_ap_trampoline;
}

void *x86_boot_setup_ap_bridge(void)
{
	return public_boot_setup_ap;
}

unsigned long x86_boot_page_table_phys_bridge(void)
{
	return fake_boot_pt_phys();
}

unsigned long x86_cpu_kstack_bridge(int cpuid)
{
	return fake_cpu_kstack(cpuid);
}

unsigned long x86_transit_page_table_bridge(void)
{
	return fake_transit_pt();
}

void x86_wakeup_bridge(int cpuid, unsigned long trampoline)
{
	fake_boot_wakeup(cpuid, trampoline);
}

void x86_cpu_pause_bridge(void)
{
	fake_boot_pause();
}

void *x86_current_thread_bridge(void)
{
	return (void *)public_trace_thread;
}

const struct x86_trace_enter_user_offsets *x86_trace_enter_user_offsets_bridge(void)
{
	return &public_trace_offsets;
}

void x86_mcexec_v10_trace_log_bridge(int cpu, int pid, int tid,
				     unsigned long rip, unsigned long rsp,
				     unsigned long cs, unsigned long ss,
				     unsigned long rflags, int status)
{
	fake_trace_log(cpu, pid, tid, rip, rsp, cs, ss, rflags, status);
}

void *x86_this_cpu_local_var_bridge(void)
{
	return public_runq_local;
}

unsigned long x86_runq_lock_offset_bridge(void)
{
	return offsetof(struct fake_runq_local, runq_lock);
}

unsigned long x86_runq_irqstate_offset_bridge(void)
{
	return offsetof(struct fake_runq_local, runq_irqstate);
}

void x86_runq_unlock_bridge(void *lock, unsigned long irqstate)
{
	fake_runq_unlock(lock, irqstate);
}
#endif

int main(void)
{
	struct x86_thread_context_offsets offsets = {
		.thread_status_offset = offsetof(struct fake_thread, status),
		.thread_uctx_offset = offsetof(struct fake_thread, uctx),
		.thread_tlsblock_base_offset =
			offsetof(struct fake_thread, tlsblock_base),
	};
	unsigned char stack[512];
	struct x86_kregs ctx;
	struct x86_user_context *uctx;
	struct x86_user_context user_ctx;
	struct fake_thread thread;
	struct ihk_os_cpu_register cpu_reg;
	unsigned long slot = 0;
	unsigned long value = 0;
	unsigned long load_ulong = 0xfeed0000cafebeefUL;
	unsigned int load_uint = 0xabcdef01U;
	int load_int = -73;
	unsigned long store_ulong = 0;
	unsigned int store_uint = 0;
	int store_int = 0;
	void *load_ptr = &load_ulong;
	unsigned long digest = 0x7838366370752121UL;
	int ret;

	reset_apic_trace();
	{
		unsigned long trampoline[8];
		unsigned long code[8] = {
			0xaa00, 0xaa01, 0xaa02, 0xaa03,
			0xaa04, 0xaa05, 0xaa06, 0xaa07,
		};
		int boot_status = 99;

		memset(trampoline, 0, sizeof(trampoline));
		boot_cpu_status_slot = &boot_status;
		boot_cpu_transit_value = 0;
		ret = x86_boot_cpu_body_result(trampoline, code, sizeof(code),
				3, 0x5555, 0x77770000, &boot_status,
				fake_enter_user, fake_boot_pt_phys,
				fake_cpu_kstack, fake_transit_pt,
				fake_boot_wakeup, fake_boot_pause);
		require(ret == 0 && boot_status == 1);
		require(boot_cpu_wakeup_count == 1 && boot_cpu_pause_count == 0);
		require(boot_cpu_last_cpuid == 3 &&
			boot_cpu_last_trampoline == 0x77770000);
		require(trampoline[0] == code[0] &&
			trampoline[1] == 0x12345000UL &&
			trampoline[2] == (unsigned long)fake_enter_user &&
			trampoline[3] == 0x5555 &&
			trampoline[4] == 0x80030000UL &&
			trampoline[6] == 0x12345000UL);
		require(x86_boot_cpu_body_result(NULL, code, sizeof(code), 3,
				0x5555, 0x77770000, &boot_status,
				fake_enter_user, fake_boot_pt_phys,
				fake_cpu_kstack, fake_transit_pt,
				fake_boot_wakeup, fake_boot_pause) == -EINVAL);
		mix(&digest, trampoline[1] ^ trampoline[4] ^ trampoline[6]);
	}

	reset_apic_trace();
	{
		public_boot_code[0] = 0xbb00;
		public_boot_code[1] = 0xbb01;
		public_boot_code[2] = 0xbb02;
		public_boot_code[3] = 0xbb03;
		public_boot_code[4] = 0xbb04;
		public_boot_code[5] = 0xbb05;
		public_boot_code[6] = 0xbb06;
		public_boot_code[7] = 0xbb07;
		public_boot_ap_trampoline = 0x88880000UL;
		public_boot_setup_ap = fake_enter_user;
		public_call_ap_status = 99;
		boot_cpu_status_slot = &public_call_ap_status;
		boot_cpu_transit_value = 0x43210000UL;

		ihk_mc_boot_cpu(4, 0x6666);
		require(public_call_ap_status == 1);
		require(boot_cpu_wakeup_count == 1 && boot_cpu_pause_count == 0);
		require(boot_cpu_last_cpuid == 4 &&
			boot_cpu_last_trampoline == 0x88880000UL);
		require(public_boot_trampoline[0] == public_boot_code[0] &&
			public_boot_trampoline[1] == 0x12345000UL &&
			public_boot_trampoline[2] ==
				(unsigned long)fake_enter_user &&
			public_boot_trampoline[3] == 0x6666 &&
			public_boot_trampoline[4] == 0x80040000UL &&
			public_boot_trampoline[6] == 0x43210000UL);
		mix(&digest, public_boot_trampoline[1] ^
			public_boot_trampoline[4] ^
			public_boot_trampoline[6]);
	}

	memset(stack, 0xa5, sizeof(stack));
	memset(&ctx, 0x5a, sizeof(ctx));
	ret = x86_init_context_body_result(&ctx, stack + sizeof(stack),
					   fake_next, fake_stack_fn);
	require(ret == 0);
	require(ctx.rsp == (unsigned long)(stack + sizeof(stack) -
		sizeof(unsigned long)));
	require(*(unsigned long *)ctx.rsp == (unsigned long)fake_next);
	require(ctx.rbp == 0 && ctx.rsp0 == 0);
	mix(&digest, ctx.rsp - (unsigned long)stack);
	mix(&digest, *(unsigned long *)ctx.rsp == (unsigned long)fake_next);

	memset(&ctx, 0x5a, sizeof(ctx));
	ret = x86_init_context_body_result(&ctx, NULL, fake_next, fake_stack_fn);
	require(ret == 0);
	require(ctx.rsp == (unsigned long)(fallback_stack + sizeof(fallback_stack) -
		sizeof(unsigned long)));
	mix(&digest, ctx.rsp - (unsigned long)fallback_stack);

	memset(&ctx, 0x5a, sizeof(ctx));
	uctx = NULL;
	ret = x86_init_user_process_body_result(&ctx, &uctx,
			stack + sizeof(stack), 0x401000, 0x7fff0000, 0x33, 0x3b,
			0x200, fake_enter_user);
	require(ret == 0);
	require(uctx == (struct x86_user_context *)(stack + sizeof(stack) -
		sizeof(*uctx)));
	require(uctx->gpr.cs == 0x33 && uctx->gpr.rip == 0x401000);
	require(uctx->gpr.ss == 0x3b && uctx->gpr.rsp == 0x7fff0000);
	require(uctx->gpr.rflags == 0x200 && uctx->is_gpr_valid == 1);
	require(ctx.rsp0 == (unsigned long)(stack + sizeof(stack)));
	require(*(unsigned long *)ctx.rsp == (unsigned long)fake_enter_user);
	mix(&digest, (unsigned long)((char *)uctx - (char *)stack));
	mix(&digest, uctx->gpr.rip ^ uctx->gpr.rsp);
	mix(&digest, ctx.rsp0 - (unsigned long)stack);
	mix(&digest, *(unsigned long *)ctx.rsp == (unsigned long)fake_enter_user);

	ihk_mc_syscall_set_arg0(uctx, 0x1010);
	ihk_mc_syscall_set_arg1(uctx, 0x2020);
	ihk_mc_syscall_set_arg2(uctx, 0x3030);
	ihk_mc_syscall_set_arg3(uctx, 0x4040);
	ihk_mc_syscall_set_arg4(uctx, 0x5050);
	ihk_mc_syscall_set_arg5(uctx, 0x6060);
	ihk_mc_syscall_set_ret(uctx, 0x7070);
	uctx->gpr.orig_rax = 0x8080;
	require(ihk_mc_syscall_arg0(uctx) == 0x1010);
	require(ihk_mc_syscall_arg1(uctx) == 0x2020);
	require(ihk_mc_syscall_arg2(uctx) == 0x3030);
	require(ihk_mc_syscall_arg3(uctx) == 0x4040);
	require(ihk_mc_syscall_arg4(uctx) == 0x5050);
	require(ihk_mc_syscall_arg5(uctx) == 0x6060);
	require(ihk_mc_syscall_ret(uctx) == 0x7070);
	require(ihk_mc_syscall_number(uctx) == 0x8080);
	require(ihk_mc_syscall_pc(uctx) == 0x401000);
	require(ihk_mc_syscall_sp(uctx) == 0x7fff0000);
	require(REGS_GET_STACK_POINTER(uctx) == 0x7fff0000);
	require(ihk_mc_syscall_arg0(NULL) == 0);
	require(REGS_GET_STACK_POINTER(NULL) == 0);
	ihk_mc_syscall_set_arg0(NULL, 0x9999);
	mix(&digest, ihk_mc_syscall_arg0(uctx) ^ ihk_mc_syscall_arg5(uctx));
	mix(&digest, ihk_mc_syscall_ret(uctx) ^
			ihk_mc_syscall_number(uctx) ^
			REGS_GET_STACK_POINTER(uctx));

	ret = x86_modify_user_context_result(uctx, IHK_UCR_STACK_POINTER,
					     0x70000000, IHK_UCR_STACK_POINTER,
					     IHK_UCR_PROGRAM_COUNTER);
	require(ret == 1 && uctx->gpr.rsp == 0x70000000);
	ret = x86_modify_user_context_result(uctx, IHK_UCR_PROGRAM_COUNTER,
					     0x402000, IHK_UCR_STACK_POINTER,
					     IHK_UCR_PROGRAM_COUNTER);
	require(ret == 1 && uctx->gpr.rip == 0x402000);
	ret = x86_modify_user_context_result(uctx, 99, 0x55,
					     IHK_UCR_STACK_POINTER,
					     IHK_UCR_PROGRAM_COUNTER);
	require(ret == 0 && uctx->gpr.rip == 0x402000);
	ihk_mc_modify_user_context(uctx, IHK_UCR_STACK_POINTER, 0x71000000);
	require(uctx->gpr.rsp == 0x71000000);
	ihk_mc_modify_user_context(uctx, IHK_UCR_PROGRAM_COUNTER, 0x403000);
	require(uctx->gpr.rip == 0x403000);
	ihk_mc_modify_user_context(uctx, 99, 0x66);
	require(uctx->gpr.rip == 0x403000 && uctx->gpr.rsp == 0x71000000);
	mix(&digest, uctx->gpr.rip ^ uctx->gpr.rsp);

	memset(&user_ctx, 0, sizeof(user_ctx));
	user_ctx.is_gpr_valid = 1;
	thread.status = 0;
	thread.uctx = &user_ctx;
	thread.tlsblock_base = 0xabcdef000;
	require(x86_lookup_user_context_body_result(&thread, &thread,
			PS_INTERRUPTIBLE | PS_UNINTERRUPTIBLE |
			PS_STOPPED | PS_TRACED, &offsets) == &user_ctx);
	require(user_ctx.is_sr_valid == 1);
	require(user_ctx.sr.fs_base == 0xabcdef000 && user_ctx.sr.gs_base == 0);
	require(x86_lookup_user_context_body_result(&thread, NULL,
			PS_INTERRUPTIBLE | PS_UNINTERRUPTIBLE |
			PS_STOPPED | PS_TRACED, &offsets) == NULL);
	thread.status = PS_INTERRUPTIBLE;
	require(x86_lookup_user_context_body_result(&thread, NULL,
			PS_INTERRUPTIBLE | PS_UNINTERRUPTIBLE |
			PS_STOPPED | PS_TRACED, &offsets) == &user_ctx);
	user_ctx.is_gpr_valid = 0;
	require(x86_lookup_user_context_body_result(&thread, &thread,
			PS_INTERRUPTIBLE | PS_UNINTERRUPTIBLE |
			PS_STOPPED | PS_TRACED, &offsets) == NULL);
	mix(&digest, user_ctx.sr.fs_base ^ user_ctx.is_sr_valid);

	ret = x86_syscall_handler_publish_result(&slot, fake_handler);
	require(ret == 0 && slot == (unsigned long)fake_handler);
	mix(&digest, slot == (unsigned long)fake_handler);

	slot = 0;
	ret = x86_page_fault_handler_publish_result(&slot, fake_handler);
	require(ret == 0 && slot == (unsigned long)fake_handler);
	require(x86_page_fault_handler_publish_result(NULL, fake_handler) == -EINVAL);
	require(x86_arch_noop_body_result() == 0);
	reset_apic_trace();
	ret = x86_delay_us_body_result(42, fake_delay_us);
	require(ret == 0 && delay_count == 1 && last_delay_us == 42);
	require(x86_delay_us_body_result(1, NULL) == -EINVAL);
	delay_count = 0;
	last_delay_us = 0;
	ihk_mc_delay_us(77);
	require(delay_count == 1 && last_delay_us == 77);
	ret = x86_tick_log_body_result(1, fake_cpu_log);
	require(ret == 0 && cpu_log_count == 1 && cpu_log_events[0] == 1);
	ret = x86_tick_log_body_result(2, fake_cpu_log);
	require(ret == 0 && cpu_log_count == 2 && cpu_log_events[1] == 2);
	ret = x86_tick_log_body_result(3, fake_cpu_log);
	require(ret == 0 && cpu_log_count == 3 && cpu_log_events[2] == 3);
	require(x86_tick_log_body_result(4, fake_cpu_log) == -EINVAL);
	init_tick();
	init_delay();
	sync_tick();
	require(cpu_log_count == 6);
	require(cpu_log_events[3] == 1);
	require(cpu_log_events[4] == 2);
	require(cpu_log_events[5] == 3);
	mix(&digest, (unsigned long)last_delay_us ^
			(unsigned long)cpu_log_count ^
			(unsigned long)(slot == (unsigned long)fake_handler));

	msr_value = 0x1234567890abcdefUL;
	written_msr = 0;
	write_count = 0;
	ret = x86_arch_set_special_register_result(IHK_ASR_X86_FS,
			IHK_ASR_X86_FS, 0xfeedface, fake_write_msr);
	require(ret == 0 && written_msr == 0xfeedface && write_count == 1);
	ret = x86_arch_set_special_register_result(IHK_ASR_X86_GS,
			IHK_ASR_X86_FS, 0x1111, fake_write_msr);
	require(ret == -EINVAL && write_count == 1);
	ret = x86_arch_get_special_register_result(IHK_ASR_X86_FS,
			IHK_ASR_X86_FS, &value, fake_read_msr);
	require(ret == 0 && value == msr_value);
	ret = x86_arch_get_special_register_result(IHK_ASR_X86_FS,
			IHK_ASR_X86_FS, NULL, fake_read_msr);
	require(ret == -EINVAL);
	mix(&digest, written_msr ^ value ^ (unsigned long)write_count);

	reset_apic_trace();
	lapic_msr_value = 0xabcdef0011223344UL;
	memset(&cpu_reg, 0, sizeof(cpu_reg));
	cpu_reg.addr = 0x830;
	ret = x86_arch_cpu_read_write_register_body_result(&cpu_reg,
			MCCTRL_OS_CPU_READ_REGISTER,
			MCCTRL_OS_CPU_READ_REGISTER,
			MCCTRL_OS_CPU_WRITE_REGISTER,
			offsetof(struct ihk_os_cpu_register, addr),
			offsetof(struct ihk_os_cpu_register, val),
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && cpu_reg.val == lapic_msr_value);
	require(read_msr_count == 1 && last_read_msr == 0x830);
	cpu_reg.addr = 0x831;
	cpu_reg.val = 0x777788889999aaaaUL;
	ret = x86_arch_cpu_read_write_register_body_result(&cpu_reg,
			MCCTRL_OS_CPU_WRITE_REGISTER,
			MCCTRL_OS_CPU_READ_REGISTER,
			MCCTRL_OS_CPU_WRITE_REGISTER,
			offsetof(struct ihk_os_cpu_register, addr),
			offsetof(struct ihk_os_cpu_register, val),
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && write_msr_count == 1);
	require(last_write_msr == 0x831 &&
			last_write_msr_value == 0x777788889999aaaaUL);
	ret = x86_arch_cpu_read_write_register_body_result(&cpu_reg, 99,
			MCCTRL_OS_CPU_READ_REGISTER,
			MCCTRL_OS_CPU_WRITE_REGISTER,
			offsetof(struct ihk_os_cpu_register, addr),
			offsetof(struct ihk_os_cpu_register, val),
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == -1 && write_msr_count == 1 && read_msr_count == 1);
	mix(&digest, cpu_reg.val ^ (unsigned long)last_write_msr);
	mix(&digest, last_write_msr_value ^ (unsigned long)ret);

	require(CVAL(0x43, 0x01) == 0x143);
	require(CVAL(0x2e, 0x41) == 0x412e);
	require(CVAL2(0x0e, 0x01, 1, 1) == 0x180010e);
	require(CVAL2(0x123, 0x45, 3, 0xff) ==
			((((0x123UL & 0xf00UL) << 24) | (0x45UL << 8) |
			  (0x123UL & 0xffUL) | (1UL << 23) |
			  (0xffUL << 24))));
	require(ihk_mc_get_smp_handler_irq() == 0xf1);
	arch_clone_thread((void *)0x11UL, 0x22UL, 0x33UL,
			(void *)0x44UL);
	arch_flush_icache_all();
	arch_prctl_call_count = 0;
#ifndef USE_C_X86_CPU_MODEL
	memset(rust_arch_prctl_cpu_local, 0,
	       sizeof(rust_arch_prctl_cpu_local));
	memset(rust_arch_prctl_thread, 0, sizeof(rust_arch_prctl_thread));
	clv = rust_arch_prctl_cpu_local;
	cpu_local_var_initialized = 1;
	*(void **)(rust_arch_prctl_cpu_local +
		   RUST_CPU_LOCAL_CURRENT_OFFSET) = rust_arch_prctl_thread;
#endif
	ihk_mc_init_user_tlsbase(&user_ctx, 0x1234abcdUL);
	require(arch_prctl_call_count == 1);
	require(arch_prctl_last_code == ARCH_SET_FS);
	require(arch_prctl_last_address == 0x1234abcdUL);
	mix(&digest, arch_prctl_last_code ^ arch_prctl_last_address);
	__page_fault_handler_address = 0;
	ihk_mc_set_page_fault_handler(fake_handler);
	require(__page_fault_handler_address == (unsigned long)fake_handler);
	__x86_syscall_handler = 0;
	ihk_mc_set_syscall_handler(fake_handler);
	require(__x86_syscall_handler == (unsigned long)fake_handler);
	mb();
	rmb();
	wmb();
	smp_mb();
	smp_rmb();
	smp_wmb();
	arch_barrier();
	require(smp_load_acquire_ulong(&load_ulong) == 0xfeed0000cafebeefUL);
	require(smp_load_acquire_uint(&load_uint) == 0xabcdef01U);
	require(smp_load_acquire_int(&load_int) == -73);
	require(smp_load_acquire_ptr(&load_ptr) == &load_ulong);
	smp_store_release_ulong(&store_ulong, 0x1020304050607080UL);
	smp_store_release_uint(&store_uint, 0x76543210U);
	smp_store_release_int(&store_int, -19);
	require(store_ulong == 0x1020304050607080UL);
	require(store_uint == 0x76543210U);
	require(store_int == -19);
	mix(&digest, CVAL(0x80, 0x03) ^ CVAL2(0x0e, 0x01, 1, 1));
	mix(&digest, smp_load_acquire_ulong(&store_ulong) ^
			smp_load_acquire_uint(&store_uint) ^
			(unsigned long)smp_load_acquire_int(&store_int));
	mix(&digest, 0x6261727269657273UL);

	for (int i = 0; i < 4; i++) {
		cpu_locals[i].processor_id = i;
		cpu_locals[i].apic_id = 0x80 + i;
	}
	require(x86_get_interrupt_id_result(2, fake_cpu_local,
			offsetof(struct fake_cpu_local, apic_id)) == 0x82);
	seed_public_interrupt_id_local(3, 0x8d);
	require(ihk_mc_get_interrupt_id(3) == 0x8d);
	log_digest = 0x696e7472757074UL;
	ipi_count = 0;
	ret = x86_interrupt_cpu_result(1, 0xf1, 4, fake_cpu_local,
			offsetof(struct fake_cpu_local, apic_id),
			fake_issue_ipi, fake_interrupt_log);
	require(ret == 0 && ipi_count == 1 && last_apic_id == 0x81 &&
		last_vector == 0xf1);
	ret = x86_interrupt_cpu_result(4, 0xf2, 4, fake_cpu_local,
			offsetof(struct fake_cpu_local, apic_id),
			fake_issue_ipi, fake_interrupt_log);
	require(ret == -1 && ipi_count == 1);
	num_processors = 4;
	seed_public_interrupt_id_local(2, 0x8e);
	ipi_count = 0;
	log_digest = 0x7075626963697069UL;
	ret = ihk_mc_interrupt_cpu(2, 0xf3);
	require(ret == 0 && ipi_count == 1 && last_apic_id == 0x8e &&
		last_vector == 0xf3);
	ret = ihk_mc_interrupt_cpu(4, 0xf4);
	require(ret == -1 && ipi_count == 1);
	mix(&digest, last_apic_id ^ (unsigned long)(unsigned int)last_vector);
	mix(&digest, log_digest);

	reset_apic_trace();
	ret = x86_lapic_timer_enable_body_result(160, fake_lapic_write);
	require(ret == 0);
	require(lapic_write_count == 3);
	require(lapic_write_regs[0] == 0x380 && lapic_write_values[0] == 10);
	require(lapic_write_regs[1] == 0x3e0 && lapic_write_values[1] == 3);
	require(lapic_write_regs[2] == 0x320 &&
		lapic_write_values[2] == (0xef | (1U << 17)));
	require(x86_lapic_timer_enable_body_result(1, NULL) == -EINVAL);
	mix(&digest, (unsigned long)lapic_write_values[0]);
	mix(&digest, (unsigned long)lapic_write_values[2]);

	reset_apic_trace();
	require(x86_lapic_timer_disable_body_result(fake_lapic_write) == 0);
	require(lapic_write_count == 1 && lapic_write_regs[0] == 0x380 &&
		lapic_write_values[0] == 0);
	require(x86_lapic_ack_body_result(fake_lapic_write) == 0);
	require(lapic_write_count == 2 && lapic_write_regs[1] == 0x0b0 &&
		lapic_write_values[1] == 0);
	mix(&digest, (unsigned long)lapic_write_count);

	reset_apic_trace();
	ret = x86_x2apic_issue_ipi_body_result(0x44, 0x123, fake_mb,
			fake_disable_save, fake_icr_write, fake_restore);
	require(ret == 0);
	require(mb_count == 1 && disable_count == 1 && restore_count == 1);
	require(icr_count == 1 && icr_high[0] == 0x123 && icr_low[0] == 0x44);
	require(restored_flags[0] == 0xabc1UL);
	mix(&digest, ((unsigned long)icr_high[0] << 16) | icr_low[0]);

	reset_apic_trace();
	ret = x86_apic_issue_ipi_body_result(0x55, 0x456, 24,
			fake_disable_save, fake_wait_idle, fake_icr_write,
			fake_restore);
	require(ret == 0);
	require(disable_count == 1 && wait_idle_count == 1 &&
		restore_count == 1);
	require(icr_count == 1 && icr_high[0] == (0x55U << 24) &&
		icr_low[0] == 0x456);
	require(x86_apic_issue_ipi_body_result(1, 2, 32, fake_disable_save,
			fake_wait_idle, fake_icr_write, fake_restore) == -EINVAL);
	mix(&digest, ((unsigned long)icr_high[0] << 8) ^ icr_low[0]);

	selected_mode = -1;
	select_count = 0;
	require(x86_x2apic_enabled_result(X2APIC_ENABLE | 0x55, X2APIC_ENABLE)
		== X2APIC_ENABLE);
	require(x86_init_lapic_bsp_body_result(X2APIC_ENABLE,
			fake_select_lapic_mode) == 1);
	require(selected_mode == 1 && select_count == 1);
	require(x86_init_lapic_bsp_body_result(0,
			fake_select_lapic_mode) == 0);
	require(selected_mode == 0 && select_count == 2);
	mix(&digest, (unsigned long)selected_mode ^ (unsigned long)select_count);

	reset_apic_trace();
	{
		void *lapic_vp = NULL;

		lapic_msr_value = 0xfee00abcUL;
		ret = x86_init_lapic_body_result(0, &lapic_vp, 0x1b,
				~(4096UL - 1), 4096, 0x800,
				fake_read_msr_reg, fake_write_msr_reg,
				fake_map_fixed, fake_lapic_write);
		require(ret == 0);
		require(read_msr_count == 1 && last_read_msr == 0x1b);
		require(map_fixed_count == 1 &&
			map_fixed_phys == (0xfee00abcUL & ~(4096UL - 1)) &&
			map_fixed_size == 4096 && map_fixed_uncached == 1);
		require(lapic_vp == lapic_mapping);
		require(write_msr_count == 1 && last_write_msr == 0x1b &&
			last_write_msr_value == (0xfee00abcUL | 0x800));
		require(lapic_write_count == 2 &&
			lapic_write_regs[0] == 0x0f0 &&
			lapic_write_values[0] == 0x1ff &&
			lapic_write_regs[1] == 0x340 &&
			lapic_write_values[1] == 0xf0);
		mix(&digest, (unsigned long)map_fixed_count);
		mix(&digest, last_write_msr_value);
	}

	reset_apic_trace();
	{
		void *lapic_vp = lapic_mapping;

		ret = x86_init_lapic_body_result(1, &lapic_vp, 0x1b,
				~(4096UL - 1), 4096, 0x800,
				fake_read_msr_reg, fake_write_msr_reg,
				fake_map_fixed, fake_lapic_write);
		require(ret == 0);
		require(read_msr_count == 0 && map_fixed_count == 0 &&
			write_msr_count == 0);
		require(lapic_write_count == 2 &&
			lapic_write_regs[0] == 0x0f0 &&
			lapic_write_regs[1] == 0x340);
		mix(&digest, (unsigned long)lapic_write_count);
	}

	reset_apic_trace();
	running_on_kvm_value = 1;
	cpuid6_eax_value = 2;
	cpuid6_ecx_value = 9;
	ret = x86_init_pstate_turbo_body_result(0, 0xce, 0x1ad,
			0x199, 0x1b0, fake_running_on_kvm, fake_cpuid6,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && cpuid6_count == 0 && read_msr_count == 0 &&
		write_msr_count == 0);

	reset_apic_trace();
	running_on_kvm_value = 0;
	cpuid6_eax_value = 2;
	cpuid6_ecx_value = 0;
	ret = x86_init_pstate_turbo_body_result(0, 0xce, 0x1ad,
			0x199, 0x1b0, fake_running_on_kvm, fake_cpuid6,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && cpuid6_count == 1 && read_msr_count == 0 &&
		write_msr_count == 0);

	reset_apic_trace();
	cpuid6_eax_value = 0;
	cpuid6_ecx_value = 1 | (1UL << 3);
	platform_info_value = 0x123456UL;
	ret = x86_init_pstate_turbo_body_result(0, 0xce, 0x1ad,
			0x199, 0x1b0, fake_running_on_kvm, fake_cpuid6,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 1 && write_msr_count == 2);
	require(write_msr_regs[0] == 0x199 &&
		write_msr_values[0] == (platform_info_value & 0xff00));
	require(write_msr_regs[1] == 0x1b0 && write_msr_values[1] == 0);
	mix(&digest, write_msr_values[0] ^ (unsigned long)write_msr_count);

	reset_apic_trace();
	cpuid6_eax_value = 1UL << 1;
	cpuid6_ecx_value = 1;
	platform_info_value = 0x567800UL;
	turbo_ratio_value = 0x2aUL;
	ret = x86_init_pstate_turbo_body_result(0, 0xce, 0x1ad,
			0x199, 0x1b0, fake_running_on_kvm, fake_cpuid6,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 2 && write_msr_count == 1);
	require(write_msr_regs[0] == 0x199 &&
		write_msr_values[0] == ((turbo_ratio_value & 0xff) << 8));
	mix(&digest, write_msr_values[0] ^ (unsigned long)read_msr_count);

	reset_apic_trace();
	cpuid6_eax_value = 1UL << 1;
	cpuid6_ecx_value = 1;
	platform_info_value = 0x8800UL;
	ret = x86_init_pstate_turbo_body_result(1, 0xce, 0x1ad,
			0x199, 0x1b0, fake_running_on_kvm, fake_cpuid6,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 1 && write_msr_count == 1);
	require(write_msr_values[0] == ((platform_info_value & 0xff00) |
		(1UL << 32)));
	mix(&digest, write_msr_values[0]);

	reset_apic_trace();
	{
		unsigned long boot_pat = 0;

		cpuid_edx_value = 0;
		ret = x86_init_pat_body_result(&boot_pat, 0x277,
				fake_cpuid_edx, fake_read_msr_reg,
				fake_write_msr_reg, fake_cpu_log);
		require(ret == 0 && cpuid_edx_count == 1 &&
			last_cpuid_edx_op == 1);
		require(cpu_log_count == 1 && cpu_log_events[0] == 1);
		require(write_msr_count == 0 && boot_pat == 0);
		mix(&digest, (unsigned long)cpu_log_events[0]);
	}

	reset_apic_trace();
	{
		unsigned long boot_pat = 0;
		unsigned long expected_pat =
			(6UL << 0) | (1UL << 8) | (7UL << 16) |
			(0UL << 24) | (6UL << 32) | (1UL << 40) |
			(7UL << 48) | (0UL << 56);

		cpuid_edx_value = 1UL << 16;
		pat_msr_value = 0xfeedc0deUL;
		ret = x86_init_pat_body_result(&boot_pat, 0x277,
				fake_cpuid_edx, fake_read_msr_reg,
				fake_write_msr_reg, fake_cpu_log);
		require(ret == 0 && read_msr_count == 1 &&
			write_msr_count == 1);
		require(boot_pat == pat_msr_value);
		require(write_msr_regs[0] == 0x277 &&
			write_msr_values[0] == expected_pat);
		require(cpu_log_count == 1 && cpu_log_events[0] == 2);
		mix(&digest, boot_pat ^ write_msr_values[0]);
	}

	reset_apic_trace();
	{
		unsigned long boot_pat = 0xabcddcbaUL;
		unsigned long saved_boot_pat = boot_pat;

		cpuid_edx_value = 1UL << 16;
		ret = x86_init_pat_body_result(&boot_pat, 0x277,
				fake_cpuid_edx, fake_read_msr_reg,
				fake_write_msr_reg, fake_cpu_log);
		require(ret == 0 && read_msr_count == 0 &&
			write_msr_count == 1);
		require(boot_pat == saved_boot_pat);
		mix(&digest, boot_pat ^ (unsigned long)write_msr_count);
	}

	reset_apic_trace();
	lapic_msr_value = 0x200UL;
	ret = x86_init_syscall_body_result(0xc0000080, 0xc0000081,
			0xc0000082, 0x20, 0x33, 0xfeedfaceUL,
			fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 1 && write_msr_count == 3);
	require(last_read_msr == 0xc0000080);
	require(write_msr_regs[0] == 0xc0000080 &&
		write_msr_values[0] == (lapic_msr_value | 1));
	require(write_msr_regs[1] == 0xc0000081 &&
		write_msr_values[1] == ((0x20UL << 32) | (0x33UL << 48)));
	require(write_msr_regs[2] == 0xc0000082 &&
		write_msr_values[2] == 0xfeedfaceUL);
	mix(&digest, write_msr_values[1] ^ write_msr_values[2]);

	reset_apic_trace();
	lapic_msr_value = 0x1000UL;
	ret = x86_enable_no_execute_body_result(0, 0xc0000080,
			1UL << 11, fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 0 && write_msr_count == 0);
	ret = x86_enable_no_execute_body_result(1, 0xc0000080,
			1UL << 11, fake_read_msr_reg, fake_write_msr_reg);
	require(ret == 0 && read_msr_count == 1 && write_msr_count == 1);
	require(write_msr_regs[0] == 0xc0000080 &&
		write_msr_values[0] == (lapic_msr_value | (1UL << 11)));
	mix(&digest, write_msr_values[0]);

	reset_apic_trace();
	{
		int no_execute_slot = -1;

		cpuid_edx_value = 0;
		ret = x86_check_no_execute_body_result(&no_execute_slot,
				fake_cpuid_edx, fake_cpu_value_log,
				fake_enable_ptattr);
		require(ret == 0 && no_execute_slot == 0);
		require(cpuid_edx_count == 1 &&
			last_cpuid_edx_op == 0x80000001UL);
		require(cpu_value_log_count == 1 &&
			cpu_value_log_events[0] == 1 &&
			cpu_value_log_values[0] == 0);
		require(enable_ptattr_count == 0);
		mix(&digest, (unsigned long)no_execute_slot);
	}

	reset_apic_trace();
	{
		int no_execute_slot = 0;

		cpuid_edx_value = 1UL << 20;
		ret = x86_check_no_execute_body_result(&no_execute_slot,
				fake_cpuid_edx, fake_cpu_value_log,
				fake_enable_ptattr);
		require(ret == 0 && no_execute_slot == 1);
		require(cpu_value_log_count == 1 &&
			cpu_value_log_values[0] == 1);
		require(enable_ptattr_count == 1);
		mix(&digest, (unsigned long)enable_ptattr_count);
	}

	reset_apic_trace();
	{
		int gettime_slot = 7;

		cpuid_edx_value = 0;
		ret = x86_init_gettime_support_body_result(&gettime_slot,
				fake_cpuid_edx, fake_cpu_log);
		require(ret == 0 && gettime_slot == 7);
		require(cpuid_edx_count == 1 &&
			last_cpuid_edx_op == 0x80000007UL);
		require(cpu_log_count == 0);

		cpuid_edx_value = 1UL << 8;
		ret = x86_init_gettime_support_body_result(&gettime_slot,
				fake_cpuid_edx, fake_cpu_log);
		require(ret == 0 && gettime_slot == 1);
		require(cpu_log_count == 1 && cpu_log_events[0] == 3);
		mix(&digest, (unsigned long)gettime_slot ^
			(unsigned long)cpu_log_events[0]);
	}

	reset_apic_trace();
	ret = x86_init_cpu_body_result(fake_order_1, fake_order_2,
			fake_order_3, fake_order_4, fake_order_5,
			fake_order_6, fake_order_7, fake_order_8);
	require(ret == 0 && order_count == 8);
	for (int i = 0; i < 8; i++)
		require(order_events[i] == i + 1);
	require(x86_init_cpu_body_result(NULL, fake_order_2,
			fake_order_3, fake_order_4, fake_order_5,
			fake_order_6, fake_order_7, fake_order_8) == -EINVAL);
	mix(&digest, (unsigned long)order_count ^ (unsigned long)order_events[7]);

	reset_apic_trace();
	ret = x86_setup_phase1_body_result(fake_order_1, fake_order_2,
			fake_order_3, fake_order_4);
	require(ret == 0 && order_count == 4);
	require(order_events[0] == 1 && order_events[1] == 2 &&
		order_events[2] == 3 && order_events[3] == 4);
	mix(&digest, (unsigned long)order_count ^ (unsigned long)order_events[3]);

	reset_apic_trace();
	ret = x86_setup_phase2_body_result(fake_order_1, fake_order_2,
			fake_order_3, fake_order_4, fake_cpu_log);
	require(ret == 0 && order_count == 4);
	require(order_events[0] == 1 && order_events[1] == 2 &&
		order_events[2] == 3 && order_events[3] == 4);
	require(cpu_log_count == 1 && cpu_log_events[0] == 4);
	mix(&digest, (unsigned long)cpu_log_events[0] ^
		(unsigned long)order_events[3]);

	reset_apic_trace();
	{
		void *trampoline = NULL;
		void *first_page = NULL;

		fake_ncpus_value = 6;
		ret = x86_ihk_mc_init_ap_body_result(&trampoline, &first_page,
				0x7000, 0x1000, 4096, fake_map_fixed,
				fake_get_ncpus, fake_init_processors,
				fake_order_1, fake_order_2,
				fake_cpu_ulong_log);
		require(ret == 0 && map_fixed_count == 2);
		require(trampoline == lapic_mapping &&
			first_page == lapic_mapping + 128);
		require(map_fixed_phys == 0 && map_fixed_size == 4096 &&
			map_fixed_uncached == 0);
		require(cpu_ulong_log_count == 2 &&
			cpu_ulong_log_events[0] == 1 &&
			cpu_ulong_log_values[0] == 0x7000 &&
			cpu_ulong_log_events[1] == 2 &&
			cpu_ulong_log_values[1] == 6);
		require(init_processors_arg == 6);
		require(order_count == 4 && order_events[0] == 20 &&
			order_events[1] == 21 && order_events[2] == 1 &&
			order_events[3] == 2);
		mix(&digest, (unsigned long)map_fixed_count ^
			(unsigned long)init_processors_arg);
		mix(&digest, cpu_ulong_log_values[0] ^ cpu_ulong_log_values[1]);
	}

	reset_apic_trace();
	cpuid_signature_eax = 0x40000001UL;
	cpuid_signature_ebx = 0x4b4d564bUL;
	cpuid_signature_ecx = 0x564b4d56UL;
	cpuid_signature_edx = 0x0000004dUL;
	require(x86_running_on_kvm_body_result(0x40000000UL,
			fake_cpuid_leaf) == 1);
	require(cpuid_leaf_count == 1);
	cpuid_signature_edx = 0;
	require(x86_running_on_kvm_body_result(0x40000000UL,
			fake_cpuid_leaf) == 0);
	mix(&digest, (unsigned long)cpuid_leaf_count);

	reset_apic_trace();
	{
		long pvti = -1;

		cpuid_signature_eax = 0x40000001UL;
		cpuid_signature_ebx = 0x4b4d564bUL;
		cpuid_signature_ecx = 0x564b4d56UL;
		cpuid_signature_edx = 0x0000004dUL;
		cpuid_features_eax = 1UL << 3;
		ret = x86_pvclock_available_body_result(&pvti,
				0x40000000UL, 0x40000001UL, 3, 0,
				0x4b564d01, 0x12, fake_cpuid_leaf,
				fake_cpu_log);
		require(ret == 1 && pvti == 0x4b564d01);
		require(cpuid_leaf_count == 2 && cpu_log_count == 2 &&
			cpu_log_events[0] == 1 && cpu_log_events[1] == 3);
		mix(&digest, (unsigned long)pvti ^
			(unsigned long)cpu_log_events[1]);
	}

	reset_apic_trace();
	{
		long pvti = -1;

		cpuid_signature_eax = 0x40000001UL;
		cpuid_signature_ebx = 0x4b4d564bUL;
		cpuid_signature_ecx = 0x564b4d56UL;
		cpuid_signature_edx = 0x0000004dUL;
		cpuid_features_eax = 1UL;
		ret = x86_pvclock_available_body_result(&pvti,
				0x40000000UL, 0x40000001UL, 3, 0,
				0x4b564d01, 0x12, fake_cpuid_leaf,
				fake_cpu_log);
		require(ret == 1 && pvti == 0x12);
		require(cpu_log_count == 2 && cpu_log_events[1] == 4);
		mix(&digest, (unsigned long)pvti ^
			(unsigned long)cpu_log_events[1]);
	}

	reset_apic_trace();
	{
		long pvti = -1;

		cpuid_signature_eax = 0x40000000UL;
		cpuid_signature_ebx = 0;
		cpuid_signature_ecx = 0x564b4d56UL;
		cpuid_signature_edx = 0x0000004dUL;
		cpuid_features_eax = 1UL << 3;
		ret = x86_pvclock_available_body_result(&pvti,
				0x40000000UL, 0x40000001UL, 3, 0,
				0x4b564d01, 0x12, fake_cpuid_leaf,
				fake_cpu_log);
		require(ret == 0 && pvti == -1);
		require(cpuid_leaf_count == 1 && cpu_log_count == 2 &&
			cpu_log_events[1] == 2);
		mix(&digest, (unsigned long)cpu_log_events[1]);
	}

	reset_apic_trace();
	{
		long pvti = -1;

		cpuid_signature_eax = 0x40000001UL;
		cpuid_signature_ebx = 0x4b4d564bUL;
		cpuid_signature_ecx = 0x564b4d56UL;
		cpuid_signature_edx = 0x0000004dUL;
		cpuid_features_eax = 0;
		ret = x86_pvclock_available_body_result(&pvti,
				0x40000000UL, 0x40000001UL, 3, 0,
				0x4b564d01, 0x12, fake_cpuid_leaf,
				fake_cpu_log);
		require(ret == 0 && pvti == -1);
		require(cpuid_leaf_count == 2 && cpu_log_count == 2 &&
			cpu_log_events[1] == 5);
		require(x86_pvclock_available_body_result(NULL,
				0x40000000UL, 0x40000001UL, 3, 0,
				0x4b564d01, 0x12, fake_cpuid_leaf,
				fake_cpu_log) == 0);
		mix(&digest, (unsigned long)cpu_log_events[1] ^
			(unsigned long)cpuid_leaf_count);
	}

	reset_apic_trace();
	{
		void *pvti_ptr = (void *)0x1234;
		int npages = -1;

		pvclock_available_value = 0;
		ret = x86_arch_setup_pvclock_body_result(&pvti_ptr, &npages,
				3, 64, 4096, 12, 0x40, 1, (char *)"cpu.c",
				321, fake_pvclock_available,
				fake_alloc_aligned_pages_node, fake_cpu_log);
		require(ret == 0 && pvti_ptr == (void *)0x1234 &&
			npages == -1 && pvclock_alloc_count == 0);
		require(cpu_log_count == 2 && cpu_log_events[0] == 6 &&
			cpu_log_events[1] == 7);
		mix(&digest, (unsigned long)cpu_log_events[1]);
	}

	reset_apic_trace();
	{
		void *pvti_ptr = NULL;
		int npages = -1;

		pvclock_available_value = 1;
		ret = x86_arch_setup_pvclock_body_result(&pvti_ptr, &npages,
				3, 64, 4096, 12, 0x40, 1, (char *)"cpu.c",
				321, fake_pvclock_available,
				fake_alloc_aligned_pages_node, fake_cpu_log);
		require(ret == 0 && pvti_ptr == pvclock_pages && npages == 1);
		require(pvclock_alloc_count == 1 && pvclock_alloc_npages == 1 &&
			pvclock_alloc_p2align == 12 &&
			pvclock_alloc_flag == 0x40 &&
			pvclock_alloc_is_user == 1 &&
			pvclock_alloc_virt_addr == ~0UL &&
			pvclock_alloc_file == (char *)"cpu.c" &&
			pvclock_alloc_line == 321);
		for (int i = 0; i < 4096; i++)
			require(pvclock_pages[i] == 0);
		require(cpu_log_count == 2 && cpu_log_events[0] == 6 &&
			cpu_log_events[1] == 9);
		mix(&digest, (unsigned long)npages ^ pvclock_alloc_flag);
	}

	reset_apic_trace();
	{
		void *pvti_ptr = (void *)0x1234;
		int npages = -1;

		pvclock_available_value = 1;
		pvclock_alloc_fail = 1;
		ret = x86_arch_setup_pvclock_body_result(&pvti_ptr, &npages,
				3, 64, 4096, 12, 0x40, 1, (char *)"cpu.c",
				321, fake_pvclock_available,
				fake_alloc_aligned_pages_node, fake_cpu_log);
		require(ret == -ENOMEM && pvti_ptr == NULL && npages == 1);
		require(cpu_log_count == 2 && cpu_log_events[1] == 8);
		mix(&digest, (unsigned long)(unsigned int)ret ^
			(unsigned long)cpu_log_events[1]);
	}

	reset_apic_trace();
	pvti = NULL;
	pvti_npages = -1;
	pvti_msr = -1;
	num_processors = 3;
	cpuid_signature_eax = 0x40000001UL;
	cpuid_signature_ebx = 0x4b4d564bUL;
	cpuid_signature_ecx = 0x564b4d56UL;
	cpuid_signature_edx = 0x0000004dUL;
	cpuid_features_eax = 1UL << 3;
	ret = arch_setup_pvclock();
	require(ret == 0 && pvti ==
		(struct pvclock_vsyscall_time_info *)pvclock_pages);
	require(pvti_npages == 1 && pvti_msr == 0x4b564d01);
	require(cpuid_leaf_count == 2 && pvclock_alloc_count == 1);
	require(pvclock_alloc_npages == 1 &&
		pvclock_alloc_p2align == 0 &&
		pvclock_alloc_flag == 0x000002UL &&
		pvclock_alloc_is_user == 0 &&
		pvclock_alloc_virt_addr == ~0UL &&
		pvclock_alloc_file != NULL &&
		pvclock_alloc_line == 0);
	for (int i = 0; i < 4096; i++)
		require(pvclock_pages[i] == 0);
	require(cpu_log_count == 4 && cpu_log_events[0] == 6 &&
		cpu_log_events[1] == 1 && cpu_log_events[2] == 3 &&
		cpu_log_events[3] == 9);
	mix(&digest, (unsigned long)pvti_npages ^ (unsigned long)pvti_msr ^
		(unsigned long)cpu_log_events[3]);

	reset_apic_trace();
	ret = x86_arch_start_pvclock_body_result(NULL, 0x4b564d01, 64, 1,
			fake_current_cpu, fake_virt_to_phys_ptr,
			fake_write_msr_reg, fake_cpu_log);
	require(ret == 0 && virt_to_phys_count == 0 && write_msr_count == 0);
	require(cpu_log_count == 2 && cpu_log_events[0] == 10 &&
		cpu_log_events[1] == 11);
	mix(&digest, (unsigned long)cpu_log_events[1]);

	reset_apic_trace();
	current_cpu_value = 2;
	virt_to_phys_base = 0x100000UL;
	ret = x86_arch_start_pvclock_body_result(pvclock_pages, 0x4b564d01,
			64, 1, fake_current_cpu, fake_virt_to_phys_ptr,
			fake_write_msr_reg, fake_cpu_log);
	require(ret == 0 && virt_to_phys_count == 1);
	require(last_virt_to_phys_ptr == pvclock_pages + 128);
	require(write_msr_count == 1 && write_msr_regs[0] == 0x4b564d01 &&
		write_msr_values[0] == (0x100080UL | 1));
	require(cpu_log_count == 2 && cpu_log_events[0] == 10 &&
		cpu_log_events[1] == 12);
	mix(&digest, write_msr_values[0] ^
		(unsigned long)cpu_log_events[1]);
	require(x86_arch_start_pvclock_body_result(pvclock_pages, 0x4b564d01,
			64, 1, NULL, fake_virt_to_phys_ptr,
			fake_write_msr_reg, fake_cpu_log) == -EINVAL);

	reset_apic_trace();
	pvti = (struct pvclock_vsyscall_time_info *)pvclock_pages;
	pvti_msr = 0x4b564d01;
	current_cpu_value = 3;
	virt_to_phys_base = 0x200000UL;
	arch_start_pvclock();
	require(virt_to_phys_count == 1);
	require(last_virt_to_phys_ptr == pvclock_pages + 3 * sizeof(*pvti));
	require(write_msr_count == 1 && write_msr_regs[0] == 0x4b564d01 &&
		write_msr_values[0] == (0x2000c0UL | 1));
	require(cpu_log_count == 2 && cpu_log_events[0] == 10 &&
		cpu_log_events[1] == 12);
	mix(&digest, write_msr_values[0] ^
		(unsigned long)cpu_log_events[1]);

	reset_apic_trace();
	{
		int boot_status = 0;

		ret = x86_call_ap_func_body_result(&boot_status, fake_ap_next);
		require(ret == 0 && boot_status == 1 && ap_next_count == 1);
		require(x86_call_ap_func_body_result(&boot_status, NULL) ==
			-EINVAL);
		mix(&digest, (unsigned long)boot_status ^
			(unsigned long)ap_next_count);
	}

	reset_apic_trace();
	call_ap_func(fake_ap_next);
	require(public_call_ap_status == 1 && ap_next_count == 1);
	mix(&digest, (unsigned long)public_call_ap_status ^
		(unsigned long)ap_next_count);

	reset_apic_trace();
	{
		unsigned long frames[4];
		unsigned long lower;
		unsigned long upper;

		frames[0] = (unsigned long)&frames[2];
		frames[1] = 0x1111222233334444UL;
		frames[2] = 0;
		frames[3] = 0x5555666677778888UL;
		lower = (unsigned long)&frames[0] - 16;
		upper = (unsigned long)&frames[4] + 16;
		ret = x86_show_stack_body_result(frames, lower, upper,
				fake_stack_frame_log);
		require(ret == 0 && stack_frame_log_count == 2);
		require(stack_frame_ips[0] == frames[1] &&
			stack_frame_sps[0] == (unsigned long)&frames[0] &&
			stack_frame_fps[0] == (unsigned long)&frames[2]);
		require(stack_frame_ips[1] == frames[3] &&
			stack_frame_sps[1] == (unsigned long)&frames[2] &&
			stack_frame_fps[1] == 0);
		require(x86_show_stack_body_result(frames, lower, upper, NULL) ==
			-EINVAL);
		mix(&digest, stack_frame_ips[0] ^ stack_frame_ips[1]);
	}

	reset_apic_trace();
	{
		unsigned long frames[4];

		frames[0] = (unsigned long)&frames[2];
		frames[1] = 0x9999aaaabbbbccccUL;
		frames[2] = 0;
		frames[3] = 0xddddeeeeffff0000UL;
		__show_stack(frames);
		show_context_stack(frames);
		require(stack_frame_log_count == 0);
		mix(&digest, 0x5a5a5a5a5a5a5a5aUL);
	}

	reset_apic_trace();
	{
		struct x86_basic_regs regs;
		unsigned long frames[4];

		memset(&regs, 0, sizeof(regs));
		frames[0] = (unsigned long)&frames[2];
		frames[1] = 0x2222;
		frames[2] = 0;
		frames[3] = 0x3333;
		regs.rsp = (unsigned long)&frames[0];
		regs.rip = 0x4444555566667777UL;
		ret = x86_arch_print_pre_interrupt_stack_body_result(&regs,
				offsetof(struct x86_basic_regs, orig_rax),
				offsetof(struct x86_basic_regs, rsp),
				offsetof(struct x86_basic_regs, rip),
				1UL << 2, 0x10000, fake_cpu_log,
				fake_print_stack);
		require(ret == 0 && stack_print_count == 1 &&
			stack_print_rbp == &frames[0] &&
			stack_print_first == regs.rip);
		require(cpu_log_count == 1 && cpu_log_events[0] == 13);
		regs.orig_rax = 1UL << 2;
		ret = x86_arch_print_pre_interrupt_stack_body_result(&regs,
				offsetof(struct x86_basic_regs, orig_rax),
				offsetof(struct x86_basic_regs, rsp),
				offsetof(struct x86_basic_regs, rip),
				1UL << 2, 0x10000, fake_cpu_log,
				fake_print_stack);
		require(ret == 0 && stack_print_count == 1);
		mix(&digest, stack_print_first ^
			(unsigned long)cpu_log_events[0]);
	}

	reset_apic_trace();
	{
		struct x86_basic_regs regs;
		unsigned long frames[4];

		memset(&regs, 0, sizeof(regs));
		frames[0] = (unsigned long)&frames[2];
		frames[1] = 0x1111;
		frames[2] = 0;
		frames[3] = 0x2222;
		regs.rsp = (unsigned long)&frames[0];
		regs.rip = 0x777788889999aaaaUL;
		arch_print_pre_interrupt_stack(&regs);
		require(stack_print_count == 1 && stack_print_rbp == &frames[0] &&
			stack_print_first == regs.rip);
		require(cpu_log_count == 1 && cpu_log_events[0] == 13);
		regs.orig_rax = 1UL << 2;
		arch_print_pre_interrupt_stack(&regs);
		require(stack_print_count == 1 && cpu_log_count == 1);
		mix(&digest, stack_print_first ^
			(unsigned long)cpu_log_events[0]);
	}

	reset_apic_trace();
	{
		unsigned long frame[2] = { 0, 0x9999 };

		ret = x86_arch_print_stack_body_result(frame, fake_cpu_log,
				fake_print_stack);
		require(ret == 0 && stack_print_count == 1 &&
			stack_print_rbp == frame && stack_print_first == 0);
		require(cpu_log_count == 1 && cpu_log_events[0] == 14);
		require(x86_arch_print_stack_body_result(frame, fake_cpu_log,
				NULL) == -EINVAL);
		mix(&digest, (unsigned long)cpu_log_events[0]);
	}

	reset_apic_trace();
	arch_print_stack();
	require(stack_print_count == 1 && stack_print_rbp != NULL &&
		stack_print_first == 0);
	require(cpu_log_count == 1 && cpu_log_events[0] == 14);
	mix(&digest, (unsigned long)cpu_log_events[0]);

	reset_apic_trace();
	memset(&user_ctx, 0, sizeof(user_ctx));
	user_ctx.gpr.cs = 0x33;
	user_ctx.gpr.rip = 0x4444;
	user_ctx.gpr.rax = 0x1;
	user_ctx.gpr.rbx = 0x2;
	user_ctx.gpr.rcx = 0x3;
	user_ctx.gpr.rdx = 0x4;
	user_ctx.gpr.rsi = 0x5;
	user_ctx.gpr.rdi = 0x6;
	user_ctx.gpr.rsp = 0x7777;
	ret = x86_print_user_context_body_result(&user_ctx, fake_context_log);
	require(ret == 0 && context_log_count == 3);
	require(context_log_events[0] == 20 && context_log_a[0] == 0x33 &&
		context_log_b[0] == 0x4444);
	require(context_log_events[1] == 21 && context_log_a[1] == 0x1 &&
		context_log_b[1] == 0x2 && context_log_c[1] == 0x3 &&
		context_log_d[1] == 0x4);
	require(context_log_events[2] == 22 && context_log_a[2] == 0x5 &&
		context_log_b[2] == 0x6 && context_log_c[2] == 0x7777);
	require(x86_print_user_context_body_result(NULL, fake_context_log) ==
		-EINVAL);
	mix(&digest, context_log_b[0] ^ context_log_c[2]);

	reset_apic_trace();
	memset(&user_ctx, 0, sizeof(user_ctx));
	user_ctx.gpr.r15 = 0x15;
	user_ctx.gpr.r14 = 0x14;
	user_ctx.gpr.r13 = 0x13;
	user_ctx.gpr.r12 = 0x12;
	user_ctx.gpr.rbp = 0xb0;
	user_ctx.gpr.r11 = 0x11;
	user_ctx.gpr.r10 = 0x10;
	user_ctx.gpr.r9 = 0x9;
	user_ctx.gpr.r8 = 0x8;
	user_ctx.gpr.rax = 0xa;
	user_ctx.gpr.rbx = 0xb;
	user_ctx.gpr.rcx = 0xc;
	user_ctx.gpr.rdx = 0xd;
	user_ctx.gpr.rsi = 0xe;
	user_ctx.gpr.rdi = 0xf;
	user_ctx.gpr.orig_rax = 0xee;
	user_ctx.gpr.rip = 0x12345678;
	user_ctx.gpr.cs = 0x10;
	user_ctx.gpr.rflags = 0x202;
	user_ctx.gpr.rsp = 0x8888;
	user_ctx.gpr.ss = 0x18;
	ret = x86_arch_show_interrupt_context_body_result(&user_ctx,
			fake_context_lock, fake_context_unlock,
			fake_context_log);
	require(ret == 0 && context_lock_count == 1 &&
		context_unlock_count == 1 &&
		context_unlock_flags == 0xfeedfaceUL);
	require(context_log_count == 6);
	require(context_log_events[0] == 1 && context_log_a[0] == 0x10 &&
		context_log_b[0] == 0x12345678);
	require(context_log_events[2] == 3 && context_log_a[2] == 0xe &&
		context_log_b[2] == 0xf && context_log_c[2] == 0x8888 &&
		context_log_d[2] == 0xb0);
	require(context_log_events[5] == 6 && context_log_a[5] == 0x10 &&
		context_log_b[5] == 0x18 && context_log_c[5] == 0x202 &&
		context_log_d[5] == 0xee);
	require(x86_arch_show_interrupt_context_body_result(&user_ctx,
			NULL, fake_context_unlock, fake_context_log) == -EINVAL);
	mix(&digest, context_log_d[5] ^ context_unlock_flags);

	reset_apic_trace();
	arch_show_interrupt_context(&user_ctx);
	require(context_lock_count == 1 && context_unlock_count == 1 &&
		context_unlock_flags == 0xfeedfaceUL);
	require(context_log_count == 6);
	require(context_log_events[0] == 1 && context_log_a[0] == 0x10 &&
		context_log_b[0] == 0x12345678);
	require(context_log_events[5] == 6 && context_log_a[5] == 0x10 &&
		context_log_b[5] == 0x18 && context_log_c[5] == 0x202 &&
		context_log_d[5] == 0xee);
	mix(&digest, context_log_b[0] ^ context_log_d[5]);

	reset_apic_trace();
	{
		unsigned long panic_regs[21];
		unsigned long paniced = 0;
		uint32_t *seg = (uint32_t *)&panic_regs[17];
		struct x86_kregs panic_ctx;
		const unsigned long user_end = 0x8000000000000000UL;

		memset(panic_regs, 0xa5, sizeof(panic_regs));
		memset(&user_ctx, 0, sizeof(user_ctx));
		user_ctx.gpr.rax = 0xa0;
		user_ctx.gpr.rbx = 0xb0;
		user_ctx.gpr.rcx = 0xc0;
		user_ctx.gpr.rdx = 0xd0;
		user_ctx.gpr.rsi = 0xe0;
		user_ctx.gpr.rdi = 0xf0;
		user_ctx.gpr.rbp = 0xb00;
		user_ctx.gpr.rsp = 0x5000;
		user_ctx.gpr.r8 = 0x80;
		user_ctx.gpr.r9 = 0x90;
		user_ctx.gpr.r10 = 0x100;
		user_ctx.gpr.r11 = 0x110;
		user_ctx.gpr.r12 = 0x120;
		user_ctx.gpr.r13 = 0x130;
		user_ctx.gpr.r14 = 0x140;
		user_ctx.gpr.r15 = 0x150;
		user_ctx.gpr.rip = user_end + 0x1234;
		user_ctx.gpr.cs = 0x10;
		user_ctx.gpr.ss = 0x18;
		user_ctx.gpr.rflags = 0x202;
		user_ctx.sr.ds = 0x20;
		user_ctx.sr.es = 0x28;
		user_ctx.sr.fs = 0x30;
		user_ctx.sr.gs = 0x38;

		ret = x86_arch_save_panic_regs_body_result(&user_ctx, NULL,
				panic_regs, &paniced, user_end, 0xfeedfaceUL,
				fake_cpu_ulong_log);
		require(ret == 0 && paniced == 1 && cpu_ulong_log_count == 0);
		require(panic_regs[0] == 0xa0 && panic_regs[1] == 0xb0 &&
			panic_regs[2] == 0xc0 && panic_regs[3] == 0xd0);
		require(panic_regs[12] == 0x120 && panic_regs[15] == 0x150 &&
			panic_regs[16] == user_end + 0x1234);
		require(seg[0] == 0x202 && seg[1] == 0x10 &&
			seg[2] == 0x18 && seg[3] == 0x20 &&
			seg[4] == 0x28 && seg[5] == 0x30 &&
			seg[6] == 0x38);

		reset_apic_trace();
		memset(panic_regs, 0, sizeof(panic_regs));
		memset(&panic_ctx, 0, sizeof(panic_ctx));
		paniced = 0;
		panic_ctx.rbx = 0xabc1;
		panic_ctx.rsi = 0xabc2;
		panic_ctx.rdi = 0xabc3;
		panic_ctx.rbp = 0xabc4;
		panic_ctx.rsp = 0xabc5;
		user_ctx.gpr.rip = 0x4444;
		user_ctx.gpr.r12 = 0x7712;
		user_ctx.gpr.r13 = 0x7713;
		user_ctx.gpr.r14 = 0x7714;
		user_ctx.gpr.r15 = 0x7715;

		ret = x86_arch_save_panic_regs_body_result(&user_ctx,
				&panic_ctx, panic_regs, &paniced, user_end,
				0xfeedfaceUL, fake_cpu_ulong_log);
		require(ret == 0 && paniced == 1 && cpu_ulong_log_count == 1);
		require(cpu_ulong_log_events[0] == 15 &&
			cpu_ulong_log_values[0] == 0x4444);
		require(panic_regs[0] == 0 && panic_regs[1] == 0xabc1 &&
			panic_regs[2] == 0 && panic_regs[3] == 0);
		require(panic_regs[4] == 0xabc2 && panic_regs[5] == 0xabc3 &&
			panic_regs[6] == 0xabc4 && panic_regs[7] == 0xabc5);
		require(panic_regs[8] == 0 && panic_regs[11] == 0 &&
			panic_regs[12] == 0x7712 && panic_regs[15] == 0x7715 &&
			panic_regs[16] == 0xfeedfaceUL);
		require(seg[0] == 0x202 && seg[1] == 0x10 &&
			seg[2] == 0x18 && seg[3] == 0x20 &&
			seg[4] == 0x28 && seg[5] == 0x30 &&
			seg[6] == 0x38);
		require(x86_arch_save_panic_regs_body_result(NULL, &panic_ctx,
				panic_regs, &paniced, user_end, 0xfeedfaceUL,
				fake_cpu_ulong_log) == -EINVAL);
		require(x86_arch_save_panic_regs_body_result(&user_ctx, NULL,
				panic_regs, &paniced, user_end, 0xfeedfaceUL,
				fake_cpu_ulong_log) == -EINVAL);
		require(x86_arch_save_panic_regs_body_result(&user_ctx,
				&panic_ctx, panic_regs, &paniced, user_end,
				0xfeedfaceUL, NULL) == -EINVAL);
		paniced = 0xdeadbeefUL;
		require(x86_arch_clear_panic_body_result(&paniced) == 0 &&
			paniced == 0);
		require(x86_arch_clear_panic_body_result(NULL) == -EINVAL);
		seed_public_panic_local(0x12345678UL);
		arch_clear_panic();
		require(read_public_panic_local() == 0);
		mix(&digest, panic_regs[1] ^ panic_regs[16] ^
			(unsigned long)seg[6] ^ paniced);
	}

	reset_apic_trace();
	{
		struct x86_trace_enter_user_offsets trace_offsets = {
			.thread_tid_offset =
				offsetof(struct fake_trace_thread, tid),
			.thread_status_offset =
				offsetof(struct fake_trace_thread, status),
			.thread_proc_offset =
				offsetof(struct fake_trace_thread, proc),
			.process_pid_offset =
				offsetof(struct fake_trace_process, pid),
		};
		struct fake_trace_process proc = { .pid = 456 };
		struct fake_trace_thread trace_thread = {
			.tid = 789,
			.status = 0x55,
			.proc = &proc,
		};
		int trace_counter = 0;

		user_ctx.gpr.rip = 0x1111;
		user_ctx.gpr.rsp = 0x2222;
		user_ctx.gpr.cs = 0x33;
		user_ctx.gpr.ss = 0x44;
		user_ctx.gpr.rflags = 0x202;
		ret = x86_mcexec_v10_trace_enter_user_body_result(&user_ctx,
				&trace_thread, &trace_counter, 32, 7,
				&trace_offsets, fake_trace_log);
		require(ret == 1 && trace_counter == 1 && trace_log_count == 1);
		require(trace_cpu == 7 && trace_pid == 456 &&
			trace_tid == 789 && trace_status == 0x55);
		require(trace_rip == 0x1111 && trace_rsp == 0x2222 &&
			trace_cs == 0x33 && trace_ss == 0x44 &&
			trace_rflags == 0x202);
		trace_counter = 32;
		ret = x86_mcexec_v10_trace_enter_user_body_result(&user_ctx,
				&trace_thread, &trace_counter, 32, 7,
				&trace_offsets, fake_trace_log);
		require(ret == 0 && trace_log_count == 1);
		require(x86_mcexec_v10_trace_enter_user_body_result(&user_ctx,
				&trace_thread, NULL, 32, 7, &trace_offsets,
				fake_trace_log) == -EINVAL);
		mix(&digest, trace_rip ^ (unsigned long)trace_pid);
	}

	reset_apic_trace();
	{
		struct fake_trace_process proc = { .pid = 654 };
		struct fake_trace_thread trace_thread = {
			.tid = 987,
			.status = 0x66,
			.proc = &proc,
		};

		public_trace_offsets.thread_tid_offset =
			offsetof(struct fake_trace_thread, tid);
		public_trace_offsets.thread_status_offset =
			offsetof(struct fake_trace_thread, status);
		public_trace_offsets.thread_proc_offset =
			offsetof(struct fake_trace_thread, proc);
		public_trace_offsets.process_pid_offset =
			offsetof(struct fake_trace_process, pid);
		public_trace_thread = &trace_thread;
		current_cpu_value = 9;
		user_ctx.gpr.rip = 0x7771;
		user_ctx.gpr.rsp = 0x7772;
		user_ctx.gpr.cs = 0x77;
		user_ctx.gpr.ss = 0x88;
		user_ctx.gpr.rflags = 0x246;

		mcexec_v10_trace_enter_user(&user_ctx);
		require(trace_log_count == 1 && trace_cpu == 9);
		require(trace_pid == 654 && trace_tid == 987 &&
			trace_status == 0x66);
		require(trace_rip == 0x7771 && trace_rsp == 0x7772 &&
			trace_cs == 0x77 && trace_ss == 0x88 &&
			trace_rflags == 0x246);
		mix(&digest, trace_rip ^ (unsigned long)trace_pid ^
			(unsigned long)trace_cpu);
	}

	reset_apic_trace();
	{
		struct fake_runq_local local = {
			.pad = 0,
			.runq_lock = 0xabc,
			.runq_irqstate = 0x123456,
		};

		ret = x86_release_runq_lock_body_result(&local,
				offsetof(struct fake_runq_local, runq_lock),
				offsetof(struct fake_runq_local, runq_irqstate),
				fake_runq_unlock);
		require(ret == 0 && runq_unlock_count == 1);
		require(runq_unlock_lock == &local.runq_lock &&
			runq_unlock_irqstate == 0x123456);
		require(x86_release_runq_lock_body_result(NULL,
				offsetof(struct fake_runq_local, runq_lock),
				offsetof(struct fake_runq_local, runq_irqstate),
				fake_runq_unlock) == -EINVAL);
		mix(&digest, runq_unlock_irqstate);
	}

	reset_apic_trace();
	{
		struct fake_runq_local local = {
			.pad = 0,
			.runq_lock = 0xdef,
			.runq_irqstate = 0x654321,
		};

		public_runq_local = &local;
		release_runq_lock();
		require(runq_unlock_count == 1);
		require(runq_unlock_lock == &local.runq_lock &&
			runq_unlock_irqstate == 0x654321);
		mix(&digest, runq_unlock_irqstate);
	}

	{
		struct fake_kstack_local local = {
			.pad = 0x11,
			.kernel_stack = 0,
			.tss_rsp0 = 0,
		};

		ret = x86_set_kstack_body_result(&local,
				offsetof(struct fake_kstack_local, kernel_stack),
				offsetof(struct fake_kstack_local, tss_rsp0),
				0xdeadbeefcafef00dUL);
		require(ret == 0);
		require(local.kernel_stack == 0xdeadbeefcafef00dUL);
		require(local.tss_rsp0 == 0xdeadbeefcafef00dUL);
		require(local.pad == 0x11);
		require(x86_set_kstack_body_result(NULL,
				offsetof(struct fake_kstack_local, kernel_stack),
				offsetof(struct fake_kstack_local, tss_rsp0),
				0x1234) == -EINVAL);
		mix(&digest, local.kernel_stack ^ local.tss_rsp0 ^ local.pad);
	}

	printf("x86_cpu_helpers ok digest=%016lx ipi=%d sr=%d\n",
	       digest, ipi_count, user_ctx.is_sr_valid);
	return 0;
}
