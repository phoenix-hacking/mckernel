#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#define XPMEM_RDONLY 0x1
#define XPMEM_RDWR 0x2
#define XPMEM_PERMIT_MODE 0x1
#define XPMEM_PERM_IRUSR 00400
#define XPMEM_PERM_IWUSR 00200
#define XPMEM_FLAG_DESTROYING 0x00040
#define XPMEM_FLAG_DESTROYED 0x00080
#define XPMEM_FLAG_VALIDPTEs 0x00200
#define XPMEM_REF_KIND_TG 1
#define XPMEM_REF_KIND_SEG 2
#define XPMEM_REF_KIND_AP 3
#define XPMEM_REF_KIND_ATT 4
#define XPMEM_CURRENT_VERSION 0x00026003
#define XPMEM_CMD_VERSION 0x7800UL
#define XPMEM_CMD_MAKE 0x7801UL
#define XPMEM_CMD_REMOVE 0x7802UL
#define XPMEM_CMD_GET 0x7803UL
#define XPMEM_CMD_RELEASE 0x7804UL
#define XPMEM_CMD_ATTACH 0x7805UL
#define XPMEM_CMD_DETACH 0x7806UL
#define PROT_READ 0x01
#define PROT_WRITE 0x02
#define MAP_SHARED 0x01
#define MAP_FIXED 0x10
#define MAP_ANONYMOUS 0x20
#define VR_XPMEM 0x40000000UL
#define VR_PROT_WRITE 0x00020000UL
#define PF_WRITE (1UL << 1)
#define PF_USER (1UL << 2)
#define PF_POPULATE (1UL << 30)
#define PAGE_SIZE 4096UL
#define PAGE_MASK (~(PAGE_SIZE - 1))

extern int xpmem_id_to_tgid_result(long);
extern int xpmem_tg_hashtable_index_result(int);
extern int xpmem_ap_hashtable_index_result(long);
extern int xpmem_segid_to_tgid(long);
extern int xpmem_apid_to_tgid(long);
extern int xpmem_tg_hashtable_index(int);
extern int xpmem_ap_hashtable_index(long);
extern int xpmem_make_id_result(int, int, long *);
extern int xpmem_positive_id_result(long);
extern int xpmem_owner_policy_result(int, int);
extern int xpmem_make_initial_policy_result(int, unsigned long, size_t);
extern int xpmem_make_alignment_result(unsigned long, size_t);
extern int xpmem_get_policy_result(long, int, int, int);
extern int xpmem_perms_result(int, int, unsigned long, short, int, int);
extern int xpmem_check_permit_mode_result(int, int, int, unsigned long, int,
					  int);
extern int xpmem_validate_access_result(int, int, int, unsigned long, size_t,
					long, size_t, int, unsigned long *);
extern int xpmem_attach_initial_policy_result(long, long, unsigned long,
					      size_t, int, size_t *);
extern int xpmem_destroying_state_result(int, int);
extern int xpmem_is_destroying_result(int);
extern int xpmem_destroying_error_result(int, int);
extern int xpmem_two_destroying_error_result(int, int, int);
extern int xpmem_three_destroying_error_result(int, int, int, int);
extern int xpmem_attach_destroying_result(int, int);
extern int xpmem_close_decision_result(int, int, int *, int *);
extern int xpmem_ref_drop_should_free_result(int);
extern int xpmem_begin_destroy_result(int, int *);
extern int xpmem_finish_destroy_result(int);
extern int xpmem_object_lookup_decision_result(long, long, int, int, int);
extern int xpmem_detach_lookup_result(int, unsigned long, unsigned long, int);
extern int xpmem_attach_overlap_result(int, int, unsigned long, size_t,
				       unsigned long);
extern int xpmem_remove_range_step_result(unsigned long, unsigned long,
					  unsigned long, unsigned long,
					  unsigned long, int, int *, int *,
					  int *, int *);
extern int xpmem_remove_memory_range_action_result(unsigned long,
						   unsigned long,
						   unsigned long, size_t,
						   unsigned long *,
						   unsigned long *, int *,
						   int *);
extern int xpmem_range_private_invalid_result(int, unsigned long,
					      unsigned long, int);
extern int xpmem_clear_pte_range_result(int, unsigned long, unsigned long,
					size_t, unsigned long, unsigned long,
					unsigned long *, unsigned long *,
					int *);
extern int xpmem_fault_vaddr_result(unsigned long, unsigned long, size_t,
				    unsigned long, unsigned long *);
extern int xpmem_straight_phys_result(unsigned long, unsigned long, size_t,
				      unsigned long, unsigned long *, size_t *);
extern int xpmem_remote_pte_missing_result(int, int, int);
extern unsigned long xpmem_seg_phys_plus_off_result(unsigned long, size_t,
						    unsigned long);
extern int xpmem_att_page_fits_result(unsigned long, size_t, unsigned long,
				      unsigned long, size_t);
extern int xpmem_pte_mismatch_result(unsigned long, unsigned long);
extern int xpmem_unpin_step_result(unsigned long, size_t, int,
				   unsigned long *, int *);
extern int xpmem_destroyable_wrapper_result(void *, void (*)(int),
					    void (*)(void *));
extern int xpmem_not_destroyable_wrapper_result(void *, int,
						void *(*)(void *, int),
						void (*)(void *, int),
						int (*)(void *),
						void (*)(int, int));
extern int xpmem_ref_wrapper_result(void *, int, void *(*)(void *, int),
				    int (*)(void *), int (*)(void *),
				    void (*)(int));
extern void xpmem_tg_destroyable(void *);
extern void xpmem_seg_destroyable(void *);
extern void xpmem_ap_destroyable(void *);
extern void xpmem_att_destroyable(void *);
extern void xpmem_tg_not_destroyable(void *);
extern void xpmem_seg_not_destroyable(void *);
extern void xpmem_ap_not_destroyable(void *);
extern void xpmem_att_not_destroyable(void *);
extern void xpmem_tg_ref(void *);
extern void xpmem_seg_ref(void *);
extern void xpmem_ap_ref(void *);
extern void xpmem_att_ref(void *);

void xpmem_id_wrapper_bug_on(int condition)
{
	(void)condition;
}

void xpmem_tg_hashtable_index_log(int tgid, int index)
{
	(void)tgid;
	(void)index;
}

void xpmem_ap_hashtable_index_log(long apid, int index)
{
	(void)apid;
	(void)index;
}

struct fake_xpmem_open_offsets {
	size_t proc_mckfd_lock_offset;
	size_t proc_mckfd_offset;
	size_t part_n_opened_offset;
	size_t mckfd_size;
	size_t mckfd_next_offset;
	size_t mckfd_fd_offset;
	size_t mckfd_sig_no_offset;
	size_t mckfd_data_offset;
	size_t mckfd_ioctl_cb_offset;
	size_t mckfd_close_cb_offset;
	size_t mckfd_dup_cb_offset;
};
typedef int (*fake_xpmem_init_fn_t)(void);
typedef long (*fake_xpmem_forward_fn_t)(int, void *);
typedef int (*fake_xpmem_open_fn_t)(void);
typedef void *(*fake_xpmem_alloc_fn_t)(size_t);
typedef long (*fake_xpmem_lock_fn_t)(void *);
typedef void (*fake_xpmem_unlock_fn_t)(void *, long);
typedef int (*fake_xpmem_atomic_inc_fn_t)(void *);
typedef void (*fake_xpmem_atomic_set_fn_t)(void *, int);
typedef void (*fake_xpmem_log_fn_t)(int, int, const char *, int, long, void *);
extern int xpmem_open_body_result(int, const char *, int, void *, void **,
				  void *, const struct fake_xpmem_open_offsets *,
				  unsigned long, unsigned long, unsigned long,
				  fake_xpmem_init_fn_t,
				  fake_xpmem_forward_fn_t,
				  fake_xpmem_open_fn_t,
				  fake_xpmem_alloc_fn_t,
				  fake_xpmem_lock_fn_t,
				  fake_xpmem_unlock_fn_t,
				  fake_xpmem_atomic_inc_fn_t,
				  fake_xpmem_log_fn_t);
struct fake_xpmem_close_offsets {
	size_t part_n_opened_offset;
	size_t mckfd_fd_offset;
	size_t mckfd_data_offset;
};
struct fake_xpmem_partition_offsets {
	size_t part_size;
	size_t part_n_opened_offset;
	size_t part_tg_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
};
struct fake_xpmem_open_tg_offsets {
	size_t proc_pid_offset;
	size_t proc_ruid_offset;
	size_t proc_rgid_offset;
	size_t tg_size;
	size_t tg_lock_offset;
	size_t tg_tgid_offset;
	size_t tg_uid_offset;
	size_t tg_gid_offset;
	size_t tg_uniq_segid_offset;
	size_t tg_uniq_apid_offset;
	size_t tg_seg_list_lock_offset;
	size_t tg_seg_list_offset;
	size_t tg_n_pinned_offset;
	size_t tg_tg_hashlist_offset;
	size_t tg_group_leader_offset;
	size_t tg_vm_offset;
	size_t tg_ap_hashtable_offset;
	size_t part_tg_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
};
struct fake_xpmem_flush_offsets {
	size_t part_tg_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
	size_t mckfd_data_offset;
	size_t proc_pid_offset;
	size_t tg_lock_offset;
	size_t tg_flags_offset;
	size_t tg_hashlist_offset;
	size_t tg_vm_offset;
};
struct fake_xpmem_remove_seg_offsets {
	size_t tg_seg_list_lock_offset;
	size_t seg_lock_offset;
	size_t seg_flags_offset;
	size_t seg_list_offset;
};
struct fake_xpmem_remove_segs_offsets {
	size_t tg_seg_list_lock_offset;
	size_t tg_seg_list_offset;
	size_t seg_list_offset;
};
struct fake_xpmem_release_ap_offsets {
	size_t tg_ap_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t ap_lock_offset;
	size_t ap_apid_offset;
	size_t ap_flags_offset;
	size_t ap_seg_offset;
	size_t ap_att_list_offset;
	size_t ap_ap_list_offset;
	size_t ap_hashlist_offset;
	size_t att_att_list_offset;
	size_t seg_lock_offset;
	size_t seg_tg_offset;
};
struct fake_xpmem_release_aps_offsets {
	size_t tg_ap_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
	size_t ap_hashlist_offset;
};
struct fake_xpmem_tg_lookup_offsets {
	size_t part_tg_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_list_offset;
	size_t tg_tgid_offset;
	size_t tg_flags_offset;
	size_t tg_hashlist_offset;
};
struct fake_xpmem_seg_lookup_offsets {
	size_t tg_seg_list_lock_offset;
	size_t tg_seg_list_offset;
	size_t seg_segid_offset;
	size_t seg_flags_offset;
	size_t seg_list_offset;
};
struct fake_xpmem_ap_lookup_offsets {
	size_t tg_ap_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
	size_t ap_apid_offset;
	size_t ap_flags_offset;
	size_t ap_hashlist_offset;
};
struct fake_xpmem_deref_offsets {
	size_t refcnt_offset;
	size_t flags_offset;
};
struct fake_xpmem_make_id_offsets {
	size_t tg_tgid_offset;
	size_t tg_uniq_offset;
};
struct fake_xpmem_validate_access_offsets {
	size_t proc_pid_offset;
	size_t proc_vm_offset;
	size_t ap_mode_offset;
	size_t ap_tg_offset;
	size_t ap_seg_offset;
	size_t tg_tgid_offset;
	size_t seg_vaddr_offset;
	size_t seg_size_offset;
};
struct fake_xpmem_perm_offsets {
	size_t proc_ruid_offset;
	size_t proc_rgid_offset;
	size_t perm_uid_offset;
	size_t perm_gid_offset;
	size_t perm_mode_offset;
	size_t seg_permit_type_offset;
	size_t seg_permit_value_offset;
	size_t seg_tg_offset;
	size_t tg_uid_offset;
	size_t tg_gid_offset;
};
struct fake_xpmem_make_segment_offsets {
	size_t proc_pid_offset;
	size_t seg_size;
	size_t seg_lock_offset;
	size_t seg_segid_offset;
	size_t seg_vaddr_offset;
	size_t seg_size_offset;
	size_t seg_permit_type_offset;
	size_t seg_permit_value_offset;
	size_t seg_tg_offset;
	size_t seg_ap_list_offset;
	size_t seg_seg_list_offset;
	size_t tg_seg_list_lock_offset;
	size_t tg_seg_list_offset;
};
struct fake_xpmem_get_offsets {
	size_t proc_pid_offset;
	size_t ap_size;
	size_t ap_lock_offset;
	size_t ap_apid_offset;
	size_t ap_mode_offset;
	size_t ap_seg_offset;
	size_t ap_tg_offset;
	size_t ap_att_list_offset;
	size_t ap_ap_list_offset;
	size_t ap_hashlist_offset;
	size_t seg_lock_offset;
	size_t seg_ap_list_offset;
	size_t tg_ap_hashtable_offset;
	size_t hashlist_stride;
	size_t hashlist_lock_offset;
	size_t hashlist_list_offset;
};
struct fake_xpmem_tg_id_offsets {
	size_t tg_tgid_offset;
};
struct fake_xpmem_detach_offsets {
	size_t vm_memory_range_lock_offset;
	size_t range_start_offset;
	size_t range_private_data_offset;
	size_t att_at_lock_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t att_vm_offset;
	size_t att_att_list_offset;
	size_t ap_lock_offset;
	size_t ap_tg_offset;
	size_t ap_seg_offset;
	size_t tg_tgid_offset;
};
struct fake_xpmem_detach_att_offsets {
	size_t vm_memory_range_lock_offset;
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_private_data_offset;
	size_t att_at_lock_offset;
	size_t att_vaddr_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_flags_offset;
	size_t att_vm_offset;
	size_t att_att_list_offset;
	size_t ap_lock_offset;
	size_t ap_seg_offset;
};
struct fake_xpmem_clear_ptes_offsets {
	size_t seg_lock_offset;
	size_t seg_vaddr_offset;
	size_t seg_size_offset;
	size_t seg_ap_list_offset;
	size_t ap_lock_offset;
	size_t ap_seg_offset;
	size_t ap_att_list_offset;
	size_t ap_ap_list_offset;
	size_t att_at_lock_offset;
	size_t att_vaddr_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t att_vm_offset;
	size_t att_att_list_offset;
	size_t vm_memory_range_lock_offset;
};
struct fake_xpmem_remove_process_memory_range_offsets {
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_private_data_offset;
	size_t att_at_lock_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t att_att_list_offset;
	size_t ap_lock_offset;
};
struct fake_xpmem_remove_process_range_offsets {
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_flag_offset;
	size_t range_private_data_offset;
};
struct fake_xpmem_free_process_range_offsets {
	size_t vm_address_space_offset;
	size_t vm_page_table_lock_offset;
	size_t vm_range_tree_offset;
	size_t vm_range_cache_offset;
	size_t vm_range_cache_count;
	size_t address_space_page_table_offset;
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_memobj_offset;
	size_t range_rb_node_offset;
};
struct fake_xpmem_update_page_table_offsets {
	size_t vm_address_space_offset;
	size_t address_space_page_table_offset;
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_pgshift_offset;
	size_t range_private_data_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_vmr_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t ap_flags_offset;
	size_t ap_mode_offset;
	size_t ap_tg_offset;
	size_t ap_seg_offset;
	size_t tg_tgid_offset;
	size_t tg_flags_offset;
	size_t seg_flags_offset;
	size_t seg_tg_offset;
};
struct fake_xpmem_fault_process_range_offsets {
	size_t vm_address_space_offset;
	size_t vm_proc_offset;
	size_t vm_memory_range_lock_offset;
	size_t address_space_page_table_offset;
	size_t proc_straight_va_offset;
	size_t proc_straight_len_offset;
	size_t proc_straight_pa_offset;
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_flag_offset;
	size_t range_pgshift_offset;
	size_t range_private_data_offset;
	size_t att_at_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_vaddr_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t ap_flags_offset;
	size_t ap_mode_offset;
	size_t ap_tg_offset;
	size_t ap_seg_offset;
	size_t tg_tgid_offset;
	size_t tg_flags_offset;
	size_t tg_vm_offset;
	size_t tg_n_pinned_offset;
	size_t seg_flags_offset;
	size_t seg_tg_offset;
};
struct fake_xpmem_attach_offsets {
	size_t mckfd_fd_offset;
	size_t vm_memory_range_lock_offset;
	size_t range_start_offset;
	size_t range_end_offset;
	size_t range_private_data_offset;
	size_t tg_tgid_offset;
	size_t tg_flags_offset;
	size_t ap_lock_offset;
	size_t ap_flags_offset;
	size_t ap_seg_offset;
	size_t ap_att_list_offset;
	size_t seg_flags_offset;
	size_t seg_tg_offset;
	size_t att_size;
	size_t att_at_lock_offset;
	size_t att_vaddr_offset;
	size_t att_at_size_offset;
	size_t att_flags_offset;
	size_t att_ap_offset;
	size_t att_vm_offset;
	size_t att_att_list_offset;
};
struct fake_xpmem_ioctl_offsets {
	unsigned long cmd_version;
	unsigned long cmd_make;
	unsigned long cmd_remove;
	unsigned long cmd_get;
	unsigned long cmd_release;
	unsigned long cmd_attach;
	unsigned long cmd_detach;
	int current_version;
	size_t make_size;
	size_t make_vaddr_offset;
	size_t make_size_offset;
	size_t make_permit_type_offset;
	size_t make_permit_value_offset;
	size_t make_segid_offset;
	size_t remove_size;
	size_t remove_segid_offset;
	size_t get_size;
	size_t get_segid_offset;
	size_t get_flags_offset;
	size_t get_permit_type_offset;
	size_t get_permit_value_offset;
	size_t get_apid_offset;
	size_t release_size;
	size_t release_apid_offset;
	size_t attach_size;
	size_t attach_apid_offset;
	size_t attach_offset_offset;
	size_t attach_size_offset;
	size_t attach_vaddr_offset;
	size_t attach_fd_offset;
	size_t attach_flags_offset;
	size_t detach_size;
	size_t detach_vaddr_offset;
};
struct fake_xpmem_pin_page_offsets {
	size_t tg_n_pinned_offset;
	size_t vm_memory_range_lock_offset;
	size_t vm_stack_start_offset;
	size_t vm_stack_end_offset;
	size_t range_start_offset;
	size_t range_private_data_offset;
};
struct fake_xpmem_ensure_valid_page_offsets {
	size_t seg_flags_offset;
	size_t seg_tg_offset;
	size_t tg_group_leader_offset;
	size_t tg_vm_offset;
};
struct fake_xpmem_vaddr_to_pte_offsets {
	size_t vm_address_space_offset;
	size_t address_space_page_table_offset;
	size_t range_pgshift_offset;
};
struct fake_xpmem_unpin_pages_offsets {
	size_t seg_tg_offset;
	size_t tg_n_pinned_offset;
};
typedef int (*fake_xpmem_atomic_dec_fn_t)(void *);
typedef int (*fake_xpmem_atomic_read_fn_t)(void *);
typedef void (*fake_xpmem_bug_on_fn_t)(int);
typedef void (*fake_xpmem_void_fn_t)(void);
typedef void (*fake_xpmem_mckfd_void_fn_t)(void *);
typedef void (*fake_xpmem_close_log_fn_t)(int, void *, int);
typedef void *(*fake_xpmem_tg_ref_fn_t)(int);
typedef void (*fake_xpmem_rwlock_fn_t)(void *, void *);
typedef void (*fake_xpmem_list_fn_t)(void *);
typedef void (*fake_xpmem_spin_fn_t)(void *);
typedef void (*fake_xpmem_tg_void_fn_t)(void *);
typedef void (*fake_xpmem_flush_log_fn_t)(int, void *, long);
typedef void (*fake_xpmem_ptr_void_fn_t)(void *);
typedef long (*fake_xpmem_object_id_fn_t)(void *);
typedef void (*fake_xpmem_list_add_tail_fn_t)(void *, void *);
typedef void (*fake_xpmem_remove_seg_log_fn_t)(int, void *, void *, long);
typedef void (*fake_xpmem_remove_seg_fn_t)(void *, void *);
typedef void (*fake_xpmem_remove_segs_log_fn_t)(int, void *, void *, long);
typedef void (*fake_xpmem_detach_att_fn_t)(void *, void *);
typedef void (*fake_xpmem_release_ap_log_fn_t)(int, void *, void *, long);
typedef void (*fake_xpmem_tg_lookup_log_fn_t)(int, int, int, void *, void *);
typedef void *(*fake_xpmem_id_ref_fn_t)(long);
typedef void *(*fake_xpmem_ref_by_id_fn_t)(void *, long);
typedef void (*fake_xpmem_rwspin_noirq_fn_t)(void *);
typedef unsigned long (*fake_xpmem_rwspin_lock_fn_t)(void *);
typedef void (*fake_xpmem_rwspin_unlock_fn_t)(void *, unsigned long);
typedef void *(*fake_xpmem_lookup_range_fn_t)(void *, unsigned long,
					      unsigned long);
typedef void *(*fake_xpmem_next_range_fn_t)(void *, void *);
typedef int (*fake_xpmem_split_range_fn_t)(void *, void *, unsigned long,
					   void **);
typedef int (*fake_xpmem_range_action_fn_t)(void *, void *);
typedef void (*fake_xpmem_remove_process_range_log_fn_t)(void *,
					   unsigned long, unsigned long,
					   int, int);
typedef int (*fake_xpmem_pt_clear_range_fn_t)(void *, void *,
					      unsigned long, unsigned long);
typedef void (*fake_xpmem_range_erase_fn_t)(void *, void *);
typedef void (*fake_xpmem_free_process_range_log_fn_t)(int, void *, void *,
					      unsigned long, unsigned long,
					      int);
typedef int (*fake_xpmem_fault_range_page_in_fn_t)(void *, void *,
					      unsigned long, unsigned long,
					      int);
typedef void (*fake_xpmem_update_page_table_log_fn_t)(int, void *, void *,
					      unsigned long, int);
typedef int (*fake_xpmem_validate_access_fn_t)(void *, long, size_t, int,
					       unsigned long *);
typedef unsigned long (*fake_xpmem_mmap_fn_t)(unsigned long, size_t,
					      unsigned long, unsigned long,
					      int, long, unsigned long,
					      void *);
typedef int (*fake_xpmem_copy_from_user_fn_t)(void *, unsigned long, size_t);
typedef int (*fake_xpmem_copy_to_user_fn_t)(unsigned long, const void *,
					    size_t);
typedef int (*fake_xpmem_make_fn_t)(unsigned long, size_t, int, void *,
				    long *);
typedef int (*fake_xpmem_remove_fn_t)(long);
typedef int (*fake_xpmem_get_fn_t)(long, int, int, void *, long *);
typedef int (*fake_xpmem_release_fn_t)(long);
typedef int (*fake_xpmem_attach_fn_t)(void *, long, long, size_t,
				      unsigned long, int, int,
				      unsigned long *);
typedef int (*fake_xpmem_detach_fn_t)(unsigned long);
typedef void (*fake_xpmem_unpin_pages_fn_t)(void *, void *, unsigned long,
					    size_t);
typedef int (*fake_xpmem_munmap_fn_t)(void *, unsigned long, size_t);
typedef int (*fake_xpmem_remove_range_fn_t)(void *, unsigned long,
					    unsigned long, int *);
typedef void (*fake_xpmem_clear_range_fn_t)(void *, unsigned long,
					    unsigned long);
typedef int (*fake_xpmem_page_fault_vm_fn_t)(void *, unsigned long,
					     unsigned long);
typedef int (*fake_xpmem_page_fault_range_fn_t)(void *, void *,
						unsigned long,
						unsigned long);
typedef int (*fake_xpmem_pin_page_fn_t)(void *, void *, void *,
					unsigned long, int);
typedef int (*fake_xpmem_ensure_valid_fn_t)(void *, unsigned long, int);
typedef void *(*fake_xpmem_pt_lookup_pte_fn_t)(void *, unsigned long,
					       int, void **, size_t *,
					       int *);
typedef void *(*fake_xpmem_vaddr_to_pte_fn_t)(void *, unsigned long,
					      size_t *);
typedef int (*fake_xpmem_pte_present_fn_t)(void *);
typedef void (*fake_xpmem_atomic_sub_fn_t)(int, void *);
typedef unsigned long (*fake_xpmem_pte_phys_fn_t)(void *);
typedef int (*fake_xpmem_smaller_page_fn_t)(size_t, size_t *, int *);
typedef void (*fake_xpmem_adjust_page_fn_t)(void *, unsigned long, void *,
					    void **, size_t *);
typedef unsigned long (*fake_xpmem_vrflag_to_ptattr_fn_t)(unsigned long,
							  unsigned long);
typedef int (*fake_xpmem_pgsize_contiguous_fn_t)(size_t);
typedef int (*fake_xpmem_pt_set_pte_fn_t)(void *, void *, size_t,
					  unsigned long, unsigned long);
typedef int (*fake_xpmem_pt_set_range_fn_t)(void *, void *, unsigned long,
					    unsigned long, unsigned long,
					    unsigned long, int, void *, int);
typedef void (*fake_xpmem_flush_tlb_single_fn_t)(unsigned long);
typedef void (*fake_xpmem_fault_log_fn_t)(int, unsigned long,
					  unsigned long, unsigned long,
					  size_t, int);
struct fake_xpmem_fault_process_range_ops {
	fake_xpmem_ptr_void_fn_t att_ref_fn;
	fake_xpmem_ptr_void_fn_t att_deref_fn;
	fake_xpmem_ptr_void_fn_t ap_ref_fn;
	fake_xpmem_ptr_void_fn_t ap_deref_fn;
	fake_xpmem_ptr_void_fn_t tg_ref_fn;
	fake_xpmem_ptr_void_fn_t tg_deref_fn;
	fake_xpmem_ptr_void_fn_t seg_ref_fn;
	fake_xpmem_ptr_void_fn_t seg_deref_fn;
	fake_xpmem_bug_on_fn_t bug_on_fn;
	fake_xpmem_ensure_valid_fn_t ensure_valid_fn;
	fake_xpmem_rwspin_noirq_fn_t read_lock_noirq_fn;
	fake_xpmem_rwspin_noirq_fn_t read_unlock_noirq_fn;
	fake_xpmem_vaddr_to_pte_fn_t vaddr_to_pte_fn;
	fake_xpmem_pte_present_fn_t pte_present_fn;
	fake_xpmem_pte_phys_fn_t pte_phys_fn;
	fake_xpmem_pt_lookup_pte_fn_t pt_lookup_pte_fn;
	fake_xpmem_smaller_page_fn_t smaller_page_fn;
	fake_xpmem_adjust_page_fn_t adjust_page_fn;
	fake_xpmem_vrflag_to_ptattr_fn_t vrflag_to_ptattr_fn;
	fake_xpmem_pgsize_contiguous_fn_t pgsize_contiguous_fn;
	fake_xpmem_pt_set_pte_fn_t pt_set_pte_fn;
	fake_xpmem_pt_set_range_fn_t pt_set_range_fn;
	fake_xpmem_atomic_dec_fn_t atomic_dec_fn;
	fake_xpmem_flush_tlb_single_fn_t flush_tlb_single_fn;
	fake_xpmem_fault_log_fn_t log_fn;
};
typedef int (*fake_xpmem_check_permit_fn_t)(int, void *);
extern int xpmem_dup_body_result(void *, void **,
				 const struct fake_xpmem_close_offsets *,
				 fake_xpmem_atomic_inc_fn_t);
extern int xpmem_close_body_result(void *, void **,
				   const struct fake_xpmem_close_offsets *,
				   fake_xpmem_atomic_dec_fn_t,
				   fake_xpmem_mckfd_void_fn_t,
				   fake_xpmem_void_fn_t,
				   fake_xpmem_close_log_fn_t);
extern int xpmem_partition_init_body_result(void **,
				   const struct fake_xpmem_partition_offsets *,
				   fake_xpmem_alloc_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_atomic_set_fn_t);
extern int xpmem_partition_exit_body_result(void **,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_open_tg_body_result(void **, void *, void *, void *,
				   const struct fake_xpmem_open_tg_offsets *,
				   void *, fake_xpmem_tg_ref_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_alloc_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_atomic_set_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_add_tail_fn_t);
extern int xpmem_flush_body_result(void *, void **,
				   const struct fake_xpmem_flush_offsets *,
				   void *, fake_xpmem_tg_ref_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_tg_void_fn_t,
				   fake_xpmem_tg_void_fn_t,
				   fake_xpmem_tg_void_fn_t,
				   fake_xpmem_flush_log_fn_t);
extern int xpmem_remove_seg_body_result(void *, void *,
				   const struct fake_xpmem_remove_seg_offsets *,
				   void *, fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_remove_seg_log_fn_t);
extern int xpmem_remove_segs_of_tg_body_result(void *,
				   const struct fake_xpmem_remove_segs_offsets *,
				   void *, fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_remove_seg_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_remove_segs_log_fn_t);
extern int xpmem_release_ap_body_result(void *, void *,
				   const struct fake_xpmem_release_ap_offsets *,
				   void *, fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_detach_att_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_release_ap_log_fn_t);
extern int xpmem_release_aps_of_tg_body_result(void *,
				   const struct fake_xpmem_release_aps_offsets *,
				   void *, fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_remove_seg_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_remove_segs_log_fn_t);
extern void *xpmem_tg_ref_by_tgid_nolock_body_result(void *, int, int, int,
				   const struct fake_xpmem_tg_lookup_offsets *,
				   fake_xpmem_ptr_void_fn_t);
extern void *xpmem_tg_ref_by_tgid_wrapper_result(void *, int, int, int,
				   const struct fake_xpmem_tg_lookup_offsets *,
				   const struct fake_xpmem_partition_offsets *,
				   void *, fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_tg_lookup_log_fn_t);
extern int xpmem_is_private_data_result(void *, size_t);
extern void *xpmem_tg_ref_by_tgid(int);
extern void *xpmem_tg_ref_by_tgid_all(int);
extern void *xpmem_tg_ref_by_tgid_nolock(int);
extern void *xpmem_tg_ref_by_tgid_all_nolock(int);
extern int xpmem_is_private_data(void *);
extern void *xpmem_seg_ref_by_segid_body_result(void *, long,
				   const struct fake_xpmem_seg_lookup_offsets *,
				   void *, fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern void *xpmem_ap_ref_by_apid_body_result(void *, long,
				   const struct fake_xpmem_ap_lookup_offsets *,
				   void *, fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_deref_body_result(void *,
				   const struct fake_xpmem_deref_offsets *,
				   int, fake_xpmem_atomic_read_fn_t,
				   fake_xpmem_atomic_dec_fn_t,
				   fake_xpmem_bug_on_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern long xpmem_make_object_id_body_result(void *,
				   const struct fake_xpmem_make_id_offsets *,
				   fake_xpmem_atomic_inc_fn_t,
				   fake_xpmem_atomic_dec_fn_t,
				   fake_xpmem_bug_on_fn_t);
extern int xpmem_validate_access_body_result(void *, void *, long, size_t,
				   int, unsigned long *,
				   const struct fake_xpmem_validate_access_offsets *);
extern int xpmem_is_remote_vm_body_result(void *, void *,
				   const struct fake_xpmem_validate_access_offsets *);
extern int xpmem_perms_body_result(void *, int, void *,
				   const struct fake_xpmem_perm_offsets *);
extern int xpmem_check_permit_mode_body_result(int, void *, void *,
				   const struct fake_xpmem_perm_offsets *,
				   fake_xpmem_bug_on_fn_t);
extern int xpmem_make_segment_body_result(unsigned long, size_t, int, void *,
				   long *, void *,
				   const struct fake_xpmem_make_segment_offsets *,
				   void *, fake_xpmem_tg_ref_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_object_id_fn_t,
				   fake_xpmem_alloc_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_add_tail_fn_t,
				   fake_xpmem_bug_on_fn_t);
extern int xpmem_get_body_result(long, int, int, void *, long *, void *,
				   const struct fake_xpmem_get_offsets *,
				   void *, fake_xpmem_id_ref_fn_t,
				   fake_xpmem_ref_by_id_fn_t,
				   fake_xpmem_check_permit_fn_t,
				   fake_xpmem_tg_ref_fn_t,
				   fake_xpmem_object_id_fn_t,
				   fake_xpmem_alloc_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_rwlock_fn_t,
				   fake_xpmem_list_add_tail_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_bug_on_fn_t);
extern int xpmem_destroy_tg_body_result(void *, fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_remove_body_result(long, int,
				   const struct fake_xpmem_tg_id_offsets *,
				   fake_xpmem_id_ref_fn_t,
				   fake_xpmem_ref_by_id_fn_t,
				   fake_xpmem_remove_seg_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_release_body_result(long, int,
				   const struct fake_xpmem_tg_id_offsets *,
				   fake_xpmem_id_ref_fn_t,
				   fake_xpmem_ref_by_id_fn_t,
				   fake_xpmem_remove_seg_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_vm_munmap_body_result(void *, unsigned long, size_t,
				   fake_xpmem_void_fn_t,
				   fake_xpmem_remove_range_fn_t,
				   fake_xpmem_void_fn_t);
extern int xpmem_detach_body_result(unsigned long, int, void *,
				   const struct fake_xpmem_detach_offsets *,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwspin_lock_fn_t,
				   fake_xpmem_rwspin_unlock_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_unpin_pages_fn_t,
				   fake_xpmem_munmap_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_detach_att_body_result(void *, void *,
				   const struct fake_xpmem_detach_att_offsets *,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_lock_fn_t,
				   fake_xpmem_rwspin_unlock_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_unpin_pages_fn_t,
				   fake_xpmem_munmap_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_clear_ptes_body_result(void *,
				   const struct fake_xpmem_clear_ptes_offsets *,
				   fake_xpmem_clear_range_fn_t);
extern int xpmem_clear_ptes_range_body_result(void *, unsigned long,
				   unsigned long,
				   const struct fake_xpmem_clear_ptes_offsets *,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_clear_range_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_clear_ptes_of_ap_body_result(void *, unsigned long,
				   unsigned long,
				   const struct fake_xpmem_clear_ptes_offsets *,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_clear_range_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_clear_ptes_of_att_body_result(void *, unsigned long,
				   unsigned long,
				   const struct fake_xpmem_clear_ptes_offsets *,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_lock_fn_t,
				   fake_xpmem_rwspin_unlock_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_unpin_pages_fn_t,
				   fake_xpmem_munmap_fn_t);
extern int xpmem_remove_process_memory_range_body_result(void *, void *,
				   const struct fake_xpmem_remove_process_memory_range_offsets *,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwspin_lock_fn_t,
				   fake_xpmem_rwspin_unlock_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_remove_process_range_body_result(void *, unsigned long,
				   unsigned long, int *,
				   const struct fake_xpmem_remove_process_range_offsets *,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_next_range_fn_t,
				   fake_xpmem_split_range_fn_t,
				   fake_xpmem_range_action_fn_t,
				   fake_xpmem_range_action_fn_t,
				   fake_xpmem_remove_process_range_log_fn_t);
extern int xpmem_free_process_range_body_result(void *, void *,
				   const struct fake_xpmem_free_process_range_offsets *,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_pt_clear_range_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_range_erase_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_free_process_range_log_fn_t);
extern int xpmem_update_process_page_table_body_result(void *, void *, int,
				   int,
				   const struct fake_xpmem_update_page_table_offsets *,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_bug_on_fn_t,
				   fake_xpmem_fault_range_page_in_fn_t,
				   fake_xpmem_pt_lookup_pte_fn_t,
				   fake_xpmem_pte_present_fn_t,
				   fake_xpmem_update_page_table_log_fn_t);
extern int xpmem_fault_process_memory_range_body_result(void *, void *,
				   unsigned long, unsigned long, int,
				   int, void *,
				   const struct fake_xpmem_fault_process_range_offsets *,
				   const struct fake_xpmem_fault_process_range_ops *);
extern int xpmem_ioctl_body_result(void *, unsigned long, unsigned long,
				   const struct fake_xpmem_ioctl_offsets *,
				   fake_xpmem_copy_from_user_fn_t,
				   fake_xpmem_copy_to_user_fn_t,
				   fake_xpmem_make_fn_t,
				   fake_xpmem_remove_fn_t,
				   fake_xpmem_get_fn_t,
				   fake_xpmem_release_fn_t,
				   fake_xpmem_attach_fn_t,
				   fake_xpmem_detach_fn_t);
extern int xpmem_attach_body_result(void *, long, long, size_t, unsigned long,
				   unsigned long *, int, void *, int,
				   unsigned long, unsigned long,
				   unsigned long, unsigned long,
				   unsigned long,
				   const struct fake_xpmem_attach_offsets *,
				   fake_xpmem_id_ref_fn_t,
				   fake_xpmem_ref_by_id_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_validate_access_fn_t,
				   fake_xpmem_alloc_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_ptr_void_fn_t,
				   fake_xpmem_rwspin_lock_fn_t,
				   fake_xpmem_rwspin_unlock_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_spin_fn_t,
				   fake_xpmem_list_add_tail_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_next_range_fn_t,
				   fake_xpmem_mmap_fn_t,
				   fake_xpmem_list_fn_t,
				   fake_xpmem_ptr_void_fn_t);
extern int xpmem_pin_page_body_result(void *, void *, void *, void *,
				   unsigned long, int,
				   const struct fake_xpmem_pin_page_offsets *,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_rwspin_noirq_fn_t,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_page_fault_vm_fn_t,
				   fake_xpmem_page_fault_range_fn_t,
				   fake_xpmem_atomic_inc_fn_t);
extern int xpmem_ensure_valid_page_body_result(void *, unsigned long, int,
				   const struct fake_xpmem_ensure_valid_page_offsets *,
				   fake_xpmem_pin_page_fn_t);
extern void *xpmem_vaddr_to_pte_body_result(void *, unsigned long, size_t *,
				   const struct fake_xpmem_vaddr_to_pte_offsets *,
				   fake_xpmem_lookup_range_fn_t,
				   fake_xpmem_pt_lookup_pte_fn_t);
extern int xpmem_unpin_pages_body_result(void *, void *, unsigned long,
				   size_t,
				   const struct fake_xpmem_unpin_pages_offsets *,
				   fake_xpmem_vaddr_to_pte_fn_t,
				   fake_xpmem_pte_present_fn_t,
				   fake_xpmem_atomic_sub_fn_t);

struct fake_xpmem_mckfd {
	struct fake_xpmem_mckfd *next;
	int fd;
	int sig_no;
	long data;
	void *opt;
	unsigned long read_cb;
	unsigned long ioctl_cb;
	unsigned long mmap_cb;
	unsigned long close_cb;
	unsigned long fcntl_cb;
	unsigned long dup_cb;
};

struct fake_xpmem_list {
	struct fake_xpmem_list *next;
	struct fake_xpmem_list *prev;
};

struct fake_xpmem_rb_node {
	unsigned long parent_color;
	struct fake_xpmem_rb_node *right;
	struct fake_xpmem_rb_node *left;
};

struct fake_xpmem_rb_root {
	struct fake_xpmem_rb_node *node;
};

static void fake_xpmem_list_init(struct fake_xpmem_list *list)
{
	list->next = list;
	list->prev = list;
}

static void fake_xpmem_list_add_tail(struct fake_xpmem_list *entry,
				     struct fake_xpmem_list *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

struct fake_xpmem_hashlist {
	unsigned long lock;
	struct fake_xpmem_list list;
};

struct fake_xpmem_proc {
	int pid;
	int ruid;
	int rgid;
	unsigned long pad;
	void *vm;
	unsigned long mckfd_lock;
	struct fake_xpmem_mckfd *mckfd;
	void *straight_va;
	size_t straight_len;
	unsigned long straight_pa;
};

struct fake_xpmem_perm {
	int uid;
	int gid;
	unsigned long mode;
};

struct fake_xpmem_address_space {
	void *page_table;
};

struct fake_xpmem_vm {
	struct fake_xpmem_address_space *address_space;
	struct fake_xpmem_proc *proc;
	unsigned long page_table_lock;
	struct fake_xpmem_rb_root vm_range_tree;
	struct fake_xpmem_range *range_cache[4];
	unsigned long memory_range_lock;
	unsigned long stack_start;
	unsigned long stack_end;
};

struct fake_xpmem_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	int pgshift;
	void *private_data;
	void *memobj;
	struct fake_xpmem_rb_node rb_node;
};

struct fake_xpmem_pte {
	int present;
	unsigned long phys;
};

struct fake_xpmem_part {
	int n_opened;
	struct fake_xpmem_hashlist tg_hashtable[8];
};

struct fake_xpmem_tg {
	unsigned long lock;
	int tgid;
	int uid;
	int gid;
	int flags;
	int uniq_segid;
	int uniq_apid;
	unsigned long seg_list_lock;
	struct fake_xpmem_list seg_list;
	int refcnt;
	int n_pinned;
	struct fake_xpmem_list tg_hashlist;
	void *group_leader;
	void *vm;
	struct fake_xpmem_hashlist ap_hashtable[8];
};

struct fake_xpmem_seg {
	unsigned long lock;
	long segid;
	unsigned long vaddr;
	size_t size;
	int permit_type;
	void *permit_value;
	int flags;
	int refcnt;
	struct fake_xpmem_tg *tg;
	struct fake_xpmem_list ap_list;
	struct fake_xpmem_list seg_list;
};

struct fake_xpmem_ap {
	unsigned long lock;
	long apid;
	int mode;
	int flags;
	int refcnt;
	struct fake_xpmem_seg *seg;
	struct fake_xpmem_tg *tg;
	struct fake_xpmem_list att_list;
	struct fake_xpmem_list ap_list;
	struct fake_xpmem_list ap_hashlist;
};

struct fake_xpmem_att {
	long id;
	unsigned long at_lock;
	unsigned long vaddr;
	unsigned long at_vaddr;
	void *at_vmr;
	size_t at_size;
	int flags;
	int refcnt;
	struct fake_xpmem_ap *ap;
	struct fake_xpmem_vm *vm;
	struct fake_xpmem_list att_list;
};

struct fake_xpmem_cmd_make {
	unsigned long vaddr;
	size_t size;
	int permit_type;
	unsigned long permit_value;
	long segid;
};

struct fake_xpmem_cmd_remove {
	long segid;
};

struct fake_xpmem_cmd_get {
	long segid;
	int flags;
	int permit_type;
	unsigned long permit_value;
	long apid;
};

struct fake_xpmem_cmd_release {
	long apid;
};

struct fake_xpmem_cmd_attach {
	long apid;
	long offset;
	size_t size;
	unsigned long vaddr;
	int fd;
	int flags;
};

struct fake_xpmem_cmd_detach {
	unsigned long vaddr;
};

static struct fake_xpmem_part fake_xpmem_part;
static void *fake_xpmem_partp;
static int fake_xpmem_init_calls;
static int fake_xpmem_forward_calls;
static int fake_xpmem_open_calls;
static int fake_xpmem_alloc_calls;
static int fake_xpmem_lock_calls;
static int fake_xpmem_unlock_calls;
static int fake_xpmem_atomic_calls;
static int fake_xpmem_atomic_set_calls;
static int fake_xpmem_atomic_set_value_sum;
static int fake_xpmem_log_count;
static long fake_xpmem_forward_rc;
static int fake_xpmem_open_rc;
static void *fake_xpmem_alloc_rc;
static long fake_xpmem_unlock_irq;
static int fake_xpmem_log_event_sum;
static long fake_xpmem_log_value_sum;
static int fake_xpmem_atomic_dec_calls;
static int fake_xpmem_atomic_read_calls;
static int fake_xpmem_bug_on_calls;
static int fake_xpmem_bug_on_condition_sum;
static int fake_xpmem_free_calls;
static void *fake_xpmem_free_ptr;
static int fake_xpmem_deref_log_calls;
static void *fake_xpmem_deref_log_ptr;
static int fake_xpmem_flush_calls;
static int fake_xpmem_flush_fd_sum;
static int fake_xpmem_exit_calls;
static int fake_xpmem_close_log_count;
static int fake_xpmem_close_log_event_sum;
static int fake_xpmem_close_log_value_sum;
static int fake_xpmem_tg_ref_calls;
static int fake_xpmem_tg_ref_pid;
static void *fake_xpmem_tg_ref_rc;
static int fake_xpmem_rwlock_lock_calls;
static int fake_xpmem_rwlock_unlock_calls;
static int fake_xpmem_rwlock_init_calls;
static void *fake_xpmem_rwlock_last_lock;
static void *fake_xpmem_rwlock_last_node;
static int fake_xpmem_list_del_calls;
static void *fake_xpmem_list_del_entry;
static int fake_xpmem_spin_lock_calls;
static int fake_xpmem_spin_unlock_calls;
static int fake_xpmem_spin_init_calls;
static void *fake_xpmem_spin_last_lock;
static int fake_xpmem_make_segid_calls;
static long fake_xpmem_make_segid_rc;
static int fake_xpmem_make_apid_calls;
static long fake_xpmem_make_apid_rc;
static int fake_xpmem_check_permit_calls;
static int fake_xpmem_check_permit_flags;
static void *fake_xpmem_check_permit_seg;
static int fake_xpmem_check_permit_rc;
static int fake_xpmem_seg_not_destroyable_calls;
static void *fake_xpmem_seg_not_destroyable_seg;
static int fake_xpmem_list_add_tail_calls;
static void *fake_xpmem_list_add_tail_entry;
static void *fake_xpmem_list_add_tail_head;
static int fake_xpmem_release_aps_calls;
static int fake_xpmem_remove_segs_calls;
static int fake_xpmem_destroy_tg_calls;
static void *fake_xpmem_release_aps_tg;
static void *fake_xpmem_remove_segs_tg;
static void *fake_xpmem_destroy_tg;
static int fake_xpmem_flush_log_count;
static int fake_xpmem_flush_log_event_sum;
static long fake_xpmem_flush_log_value_sum;
static void *fake_xpmem_flush_log_tg;
static int fake_xpmem_clear_ptes_calls;
static void *fake_xpmem_clear_ptes_seg;
static int fake_xpmem_seg_destroyable_calls;
static void *fake_xpmem_seg_destroyable_seg;
static int fake_xpmem_remove_seg_log_count;
static int fake_xpmem_remove_seg_log_event_sum;
static long fake_xpmem_remove_seg_log_value_sum;
static int fake_xpmem_seg_ref_calls;
static int fake_xpmem_seg_deref_calls;
static long fake_xpmem_seg_ref_id_sum;
static long fake_xpmem_seg_deref_id_sum;
static int fake_xpmem_remove_seg_cb_calls;
static long fake_xpmem_remove_seg_cb_id_sum;
static void *fake_xpmem_remove_seg_cb_tg;
static int fake_xpmem_remove_segs_log_count;
static int fake_xpmem_remove_segs_log_event_sum;
static int fake_xpmem_att_ref_calls;
static int fake_xpmem_att_deref_calls;
static long fake_xpmem_att_ref_id_sum;
static long fake_xpmem_att_deref_id_sum;
static int fake_xpmem_detach_att_calls;
static long fake_xpmem_detach_att_id_sum;
static void *fake_xpmem_detach_att_ap;
static int fake_xpmem_tg_deref_calls;
static int fake_xpmem_tg_deref_tgid_sum;
static int fake_xpmem_tg_destroyable_calls;
static int fake_xpmem_tg_destroyable_tgid_sum;
static int fake_xpmem_destroyable_log_calls;
static int fake_xpmem_destroyable_log_event_sum;
static int fake_xpmem_refcnt_ptr_calls;
static int fake_xpmem_refcnt_ptr_kind_sum;
static int fake_xpmem_refcnt_log_calls;
static int fake_xpmem_refcnt_log_kind_sum;
static int fake_xpmem_refcnt_log_value_sum;
static int fake_xpmem_tg_not_destroyable_calls;
static int fake_xpmem_tg_not_destroyable_tgid_sum;
static int fake_xpmem_tg_ref_object_calls;
static int fake_xpmem_tg_ref_object_tgid_sum;
static int fake_xpmem_tg_lookup_log_calls;
static int fake_xpmem_tg_lookup_log_event_sum;
static int fake_xpmem_tg_lookup_log_tgid_sum;
static int fake_xpmem_tg_lookup_log_destroy_sum;
static int fake_xpmem_tg_lookup_log_part_count;
static int fake_xpmem_tg_lookup_log_result_count;
static int fake_xpmem_ap_ref_calls;
static int fake_xpmem_ap_deref_calls;
static long fake_xpmem_ap_ref_id_sum;
static long fake_xpmem_ap_deref_id_sum;
static int fake_xpmem_ap_destroyable_calls;
static void *fake_xpmem_ap_destroyable_ap;
static int fake_xpmem_ap_not_destroyable_calls;
static void *fake_xpmem_ap_not_destroyable_ap;
static int fake_xpmem_release_ap_log_count;
static int fake_xpmem_release_ap_log_event_sum;
static long fake_xpmem_release_ap_log_value_sum;
static int fake_xpmem_release_ap_cb_calls;
static long fake_xpmem_release_ap_cb_id_sum;
static void *fake_xpmem_release_ap_cb_tg;
static int fake_xpmem_tg_ref_by_id_calls;
static long fake_xpmem_tg_ref_by_id_value;
static void *fake_xpmem_tg_ref_by_id_rc;
static int fake_xpmem_seg_ref_by_id_calls;
static long fake_xpmem_seg_ref_by_id_value;
static void *fake_xpmem_seg_ref_by_id_parent;
static void *fake_xpmem_seg_ref_by_id_rc;
static int fake_xpmem_ap_ref_by_id_calls;
static long fake_xpmem_ap_ref_by_id_value;
static void *fake_xpmem_ap_ref_by_id_parent;
static void *fake_xpmem_ap_ref_by_id_rc;
static int fake_xpmem_write_lock_noirq_calls;
static int fake_xpmem_write_unlock_noirq_calls;
static int fake_xpmem_read_lock_noirq_calls;
static int fake_xpmem_read_unlock_noirq_calls;
static void *fake_xpmem_noirq_last_lock;
static int fake_xpmem_att_write_lock_calls;
static int fake_xpmem_att_write_unlock_calls;
static unsigned long fake_xpmem_att_write_unlock_state_sum;
static int fake_xpmem_lookup_range_calls;
static void *fake_xpmem_lookup_range_vm;
static unsigned long fake_xpmem_lookup_range_start;
static unsigned long fake_xpmem_lookup_range_end;
static void *fake_xpmem_lookup_range_rc;
static void *fake_xpmem_lookup_range_seq[4];
static int fake_xpmem_lookup_range_seq_len;
static int fake_xpmem_unpin_pages_calls;
static void *fake_xpmem_unpin_pages_seg;
static void *fake_xpmem_unpin_pages_vm;
static unsigned long fake_xpmem_unpin_pages_vaddr;
static size_t fake_xpmem_unpin_pages_size;
static int fake_xpmem_munmap_calls;
static void *fake_xpmem_munmap_vm;
static unsigned long fake_xpmem_munmap_addr;
static size_t fake_xpmem_munmap_len;
static int fake_xpmem_munmap_rc;
static int fake_xpmem_begin_pending_calls;
static int fake_xpmem_finish_pending_calls;
static int fake_xpmem_remove_range_calls;
static void *fake_xpmem_remove_range_vm;
static unsigned long fake_xpmem_remove_range_start;
static unsigned long fake_xpmem_remove_range_end;
static int fake_xpmem_remove_range_ro_freed;
static int fake_xpmem_remove_range_rc;
static int fake_xpmem_next_range_calls;
static void *fake_xpmem_next_range_vm;
static void *fake_xpmem_next_range_arg;
static void *fake_xpmem_next_range_rc;
static void *fake_xpmem_next_range_seq[4];
static int fake_xpmem_next_range_seq_len;
static int fake_xpmem_split_range_calls;
static void *fake_xpmem_split_range_vm;
static void *fake_xpmem_split_range_arg;
static unsigned long fake_xpmem_split_range_addr;
static unsigned long fake_xpmem_split_range_addr_sum;
static int fake_xpmem_split_range_null_out_calls;
static int fake_xpmem_split_range_set_out_calls;
static void *fake_xpmem_split_range_new_rc;
static int fake_xpmem_split_range_rc;
static int fake_xpmem_remove_private_range_calls;
static void *fake_xpmem_remove_private_range_vm;
static void *fake_xpmem_remove_private_range_arg;
static int fake_xpmem_free_range_calls;
static void *fake_xpmem_free_range_vm;
static void *fake_xpmem_free_range_arg;
static int fake_xpmem_free_range_rc;
static int fake_xpmem_remove_process_range_log_calls;
static void *fake_xpmem_remove_process_range_log_vm;
static unsigned long fake_xpmem_remove_process_range_log_start;
static unsigned long fake_xpmem_remove_process_range_log_end;
static int fake_xpmem_remove_process_range_log_error_sum;
static int fake_xpmem_remove_process_range_log_free_sum;
static int fake_xpmem_free_process_pt_clear_calls;
static void *fake_xpmem_free_process_pt_clear_page_table;
static void *fake_xpmem_free_process_pt_clear_vm;
static unsigned long fake_xpmem_free_process_pt_clear_start;
static unsigned long fake_xpmem_free_process_pt_clear_end;
static int fake_xpmem_free_process_pt_clear_rc;
static int fake_xpmem_free_process_memobj_unref_calls;
static void *fake_xpmem_free_process_memobj_unref_arg;
static int fake_xpmem_free_process_erase_calls;
static void *fake_xpmem_free_process_erase_root;
static void *fake_xpmem_free_process_erase_node;
static int fake_xpmem_free_process_free_calls;
static void *fake_xpmem_free_process_free_arg;
static int fake_xpmem_free_process_log_calls;
static int fake_xpmem_free_process_log_event_sum;
static int fake_xpmem_free_process_log_error_sum;
static void *fake_xpmem_free_process_log_vm;
static void *fake_xpmem_free_process_log_range;
static int fake_xpmem_update_fault_calls;
static void *fake_xpmem_update_fault_vm;
static void *fake_xpmem_update_fault_range;
static unsigned long fake_xpmem_update_fault_vaddr;
static unsigned long fake_xpmem_update_fault_vaddr_sum;
static unsigned long fake_xpmem_update_fault_reason_sum;
static int fake_xpmem_update_fault_page_in_sum;
static int fake_xpmem_update_fault_rc;
static int fake_xpmem_update_log_calls;
static int fake_xpmem_update_log_event_sum;
static int fake_xpmem_update_log_error_sum;
static void *fake_xpmem_update_log_vm;
static void *fake_xpmem_update_log_range;
static unsigned long fake_xpmem_update_log_vaddr_sum;
static int fake_xpmem_att_destroyable_calls;
static void *fake_xpmem_att_destroyable_att;
static int fake_xpmem_att_not_destroyable_calls;
static void *fake_xpmem_att_not_destroyable_att;
static int fake_xpmem_attach_validate_calls;
static void *fake_xpmem_attach_validate_ap;
static long fake_xpmem_attach_validate_offset;
static size_t fake_xpmem_attach_validate_size;
static int fake_xpmem_attach_validate_mode;
static unsigned long fake_xpmem_attach_validate_seg_vaddr;
static int fake_xpmem_attach_validate_rc;
static int fake_xpmem_attach_mmap_calls;
static unsigned long fake_xpmem_attach_mmap_addr;
static size_t fake_xpmem_attach_mmap_len;
static unsigned long fake_xpmem_attach_mmap_prot;
static unsigned long fake_xpmem_attach_mmap_flags;
static int fake_xpmem_attach_mmap_fd;
static long fake_xpmem_attach_mmap_offset;
static unsigned long fake_xpmem_attach_mmap_vm_flags;
static void *fake_xpmem_attach_mmap_private_data;
static unsigned long fake_xpmem_attach_mmap_rc;
static int fake_xpmem_ioctl_copy_from_calls;
static unsigned long fake_xpmem_ioctl_copy_from_src;
static size_t fake_xpmem_ioctl_copy_from_size;
static int fake_xpmem_ioctl_copy_from_rc;
static int fake_xpmem_ioctl_copy_to_calls;
static unsigned long fake_xpmem_ioctl_copy_to_dst;
static size_t fake_xpmem_ioctl_copy_to_size;
static int fake_xpmem_ioctl_copy_to_rc;
static int fake_xpmem_ioctl_make_calls;
static unsigned long fake_xpmem_ioctl_make_vaddr;
static size_t fake_xpmem_ioctl_make_size;
static int fake_xpmem_ioctl_make_permit_type;
static void *fake_xpmem_ioctl_make_permit_value;
static long fake_xpmem_ioctl_make_out;
static int fake_xpmem_ioctl_make_rc;
static int fake_xpmem_ioctl_remove_calls;
static long fake_xpmem_ioctl_remove_id;
static int fake_xpmem_ioctl_remove_rc;
static int fake_xpmem_ioctl_get_calls;
static long fake_xpmem_ioctl_get_segid;
static int fake_xpmem_ioctl_get_flags;
static int fake_xpmem_ioctl_get_permit_type;
static void *fake_xpmem_ioctl_get_permit_value;
static long fake_xpmem_ioctl_get_out;
static int fake_xpmem_ioctl_get_rc;
static int fake_xpmem_ioctl_release_calls;
static long fake_xpmem_ioctl_release_id;
static int fake_xpmem_ioctl_release_rc;
static int fake_xpmem_ioctl_attach_calls;
static void *fake_xpmem_ioctl_attach_mckfd;
static long fake_xpmem_ioctl_attach_apid;
static long fake_xpmem_ioctl_attach_offset;
static size_t fake_xpmem_ioctl_attach_size;
static unsigned long fake_xpmem_ioctl_attach_vaddr;
static int fake_xpmem_ioctl_attach_fd;
static int fake_xpmem_ioctl_attach_flags;
static unsigned long fake_xpmem_ioctl_attach_out;
static int fake_xpmem_ioctl_attach_rc;
static int fake_xpmem_ioctl_detach_calls;
static unsigned long fake_xpmem_ioctl_detach_vaddr;
static int fake_xpmem_ioctl_detach_rc;
static int fake_xpmem_clear_range_calls;
static void *fake_xpmem_clear_range_object;
static unsigned long fake_xpmem_clear_range_start;
static unsigned long fake_xpmem_clear_range_end;
static int fake_xpmem_page_fault_vm_calls;
static void *fake_xpmem_page_fault_vm_vm;
static unsigned long fake_xpmem_page_fault_vm_vaddr;
static unsigned long fake_xpmem_page_fault_vm_reason;
static int fake_xpmem_page_fault_vm_rc;
static int fake_xpmem_page_fault_range_calls;
static void *fake_xpmem_page_fault_range_vm;
static void *fake_xpmem_page_fault_range_range;
static unsigned long fake_xpmem_page_fault_range_vaddr;
static unsigned long fake_xpmem_page_fault_range_reason;
static int fake_xpmem_page_fault_range_rc;
static int fake_xpmem_pin_page_calls;
static void *fake_xpmem_pin_page_tg;
static void *fake_xpmem_pin_page_thread;
static void *fake_xpmem_pin_page_vm;
static unsigned long fake_xpmem_pin_page_vaddr;
static int fake_xpmem_pin_page_page_in;
static int fake_xpmem_pin_page_rc;
static int fake_xpmem_pt_lookup_pte_calls;
static void *fake_xpmem_pt_lookup_pte_page_table;
static unsigned long fake_xpmem_pt_lookup_pte_vaddr;
static unsigned long fake_xpmem_pt_lookup_pte_vaddr_sum;
static int fake_xpmem_pt_lookup_pte_pgshift;
static size_t fake_xpmem_pt_lookup_pte_pgsize;
static void *fake_xpmem_pt_lookup_pte_rc;
static int fake_xpmem_vaddr_to_pte_calls;
static void *fake_xpmem_vaddr_to_pte_vm;
static unsigned long fake_xpmem_vaddr_to_pte_vaddr;
static size_t fake_xpmem_vaddr_to_pte_sizes[4];
static void *fake_xpmem_vaddr_to_pte_ptes[4];
static int fake_xpmem_pte_present_calls;
static int fake_xpmem_atomic_sub_calls;
static int fake_xpmem_atomic_sub_value;
static void *fake_xpmem_atomic_sub_counter;
static int fake_xpmem_fault_ensure_calls;
static void *fake_xpmem_fault_ensure_seg;
static unsigned long fake_xpmem_fault_ensure_vaddr;
static int fake_xpmem_fault_ensure_page_in;
static int fake_xpmem_fault_ensure_rc;
static int fake_xpmem_pte_phys_calls;
static unsigned long fake_xpmem_pte_phys_sum;
static int fake_xpmem_smaller_page_calls;
static size_t fake_xpmem_smaller_page_last_pgsize;
static size_t fake_xpmem_smaller_page_out;
static int fake_xpmem_smaller_page_align_out;
static int fake_xpmem_smaller_page_rc;
static int fake_xpmem_adjust_page_calls;
static void *fake_xpmem_adjust_page_table;
static unsigned long fake_xpmem_adjust_fault_addr;
static void *fake_xpmem_adjust_pte;
static size_t fake_xpmem_adjust_pgsize;
static int fake_xpmem_vrflag_calls;
static unsigned long fake_xpmem_vrflag_flag;
static unsigned long fake_xpmem_vrflag_reason;
static unsigned long fake_xpmem_vrflag_rc;
static int fake_xpmem_pgsize_contiguous_calls;
static int fake_xpmem_pgsize_contiguous_rc;
static int fake_xpmem_pt_set_pte_calls;
static void *fake_xpmem_pt_set_pte_page_table;
static void *fake_xpmem_pt_set_pte_pte;
static size_t fake_xpmem_pt_set_pte_pgsize;
static unsigned long fake_xpmem_pt_set_pte_phys;
static unsigned long fake_xpmem_pt_set_pte_attr;
static int fake_xpmem_pt_set_pte_rc;
static int fake_xpmem_pt_set_range_calls;
static void *fake_xpmem_pt_set_range_page_table;
static void *fake_xpmem_pt_set_range_vm;
static unsigned long fake_xpmem_pt_set_range_start;
static unsigned long fake_xpmem_pt_set_range_end;
static unsigned long fake_xpmem_pt_set_range_phys;
static unsigned long fake_xpmem_pt_set_range_attr;
static int fake_xpmem_pt_set_range_pgshift;
static void *fake_xpmem_pt_set_range_vmr;
static int fake_xpmem_pt_set_range_replace;
static int fake_xpmem_pt_set_range_rc;
static int fake_xpmem_flush_single_calls;
static unsigned long fake_xpmem_flush_single_vaddr;
static int fake_xpmem_fault_log_calls;
static int fake_xpmem_fault_log_event_sum;
static unsigned long fake_xpmem_fault_log_a_sum;
static unsigned long fake_xpmem_fault_log_b_sum;
static unsigned long fake_xpmem_fault_log_c_sum;
static size_t fake_xpmem_fault_log_size_sum;
static int fake_xpmem_fault_log_error_sum;

static int fake_xpmem_init(void)
{
	fake_xpmem_init_calls++;
	fake_xpmem_part.n_opened = 0;
	fake_xpmem_partp = &fake_xpmem_part;
	return 0;
}

static long fake_xpmem_forward(int syscall_num, void *ctx)
{
	fake_xpmem_forward_calls++;
	return fake_xpmem_forward_rc + syscall_num + (ctx != NULL);
}

static int fake_xpmem_open_primitive(void)
{
	fake_xpmem_open_calls++;
	return fake_xpmem_open_rc;
}

static void *fake_xpmem_alloc(size_t size)
{
	fake_xpmem_alloc_calls++;
	(void)size;
	return fake_xpmem_alloc_rc;
}

static long fake_xpmem_lock(void *lock)
{
	fake_xpmem_lock_calls++;
	return 0x700 + fake_xpmem_lock_calls + (lock != NULL);
}

static void fake_xpmem_unlock(void *lock, long irqstate)
{
	fake_xpmem_unlock_calls++;
	fake_xpmem_unlock_irq = irqstate + (lock != NULL);
}

static int fake_xpmem_atomic_inc(void *counter)
{
	int *value = counter;

	fake_xpmem_atomic_calls++;
	return ++*value;
}

static void fake_xpmem_atomic_set(void *counter, int value)
{
	int *target = counter;

	fake_xpmem_atomic_set_calls++;
	fake_xpmem_atomic_set_value_sum += value;
	*target = value;
}

static int fake_xpmem_atomic_dec(void *counter)
{
	int *value = counter;

	fake_xpmem_atomic_dec_calls++;
	return --*value;
}

static int fake_xpmem_atomic_read(void *counter)
{
	int *value = counter;

	fake_xpmem_atomic_read_calls++;
	return *value;
}

static void fake_xpmem_bug_on(int condition)
{
	fake_xpmem_bug_on_calls++;
	fake_xpmem_bug_on_condition_sum += condition != 0;
}

static void fake_xpmem_free_cb(void *ptr)
{
	fake_xpmem_free_calls++;
	fake_xpmem_free_ptr = ptr;
}

static void fake_xpmem_deref_log_cb(void *ptr)
{
	fake_xpmem_deref_log_calls++;
	fake_xpmem_deref_log_ptr = ptr;
}

static void fake_xpmem_mckfd_flush(void *mckfd)
{
	struct fake_xpmem_mckfd *file = mckfd;

	fake_xpmem_flush_calls++;
	fake_xpmem_flush_fd_sum += file ? file->fd : 0;
}

static void fake_xpmem_exit(void)
{
	fake_xpmem_exit_calls++;
}

static void fake_xpmem_open_log(int event, int syscall_num, const char *pathname,
				int flags, long value, void *ptr)
{
	fake_xpmem_log_count++;
	fake_xpmem_log_event_sum += event + syscall_num + flags +
		(pathname != NULL) + (ptr != NULL);
	fake_xpmem_log_value_sum += value;
}

static void fake_xpmem_close_log(int event, void *mckfd, int value)
{
	struct fake_xpmem_mckfd *file = mckfd;

	fake_xpmem_close_log_count++;
	fake_xpmem_close_log_event_sum += event + (file ? file->fd : 0);
	fake_xpmem_close_log_value_sum += value;
}

static void *fake_xpmem_tg_ref(int pid)
{
	fake_xpmem_tg_ref_calls++;
	fake_xpmem_tg_ref_pid = pid;
	return fake_xpmem_tg_ref_rc;
}

static void fake_xpmem_rwlock_lock(void *lock, void *node)
{
	fake_xpmem_rwlock_lock_calls++;
	fake_xpmem_rwlock_last_lock = lock;
	fake_xpmem_rwlock_last_node = node;
}

static void fake_xpmem_rwlock_unlock(void *lock, void *node)
{
	fake_xpmem_rwlock_unlock_calls++;
	fake_xpmem_rwlock_last_lock = lock;
	fake_xpmem_rwlock_last_node = node;
}

static void fake_xpmem_rwlock_init_cb(void *lock)
{
	fake_xpmem_rwlock_init_calls++;
	fake_xpmem_rwlock_last_lock = lock;
}

static void fake_xpmem_list_del_init(void *entry)
{
	struct fake_xpmem_list *list = entry;

	fake_xpmem_list_del_calls++;
	fake_xpmem_list_del_entry = entry;
	list->next = list;
	list->prev = list;
}

static void fake_xpmem_list_init_cb(void *entry)
{
	struct fake_xpmem_list *list = entry;

	fake_xpmem_list_del_calls++;
	fake_xpmem_list_del_entry = entry;
	list->next = list;
	list->prev = list;
}

static void fake_xpmem_list_add_tail_cb(void *entryp, void *headp)
{
	struct fake_xpmem_list *entry = entryp;
	struct fake_xpmem_list *head = headp;

	fake_xpmem_list_add_tail_calls++;
	fake_xpmem_list_add_tail_entry = entryp;
	fake_xpmem_list_add_tail_head = headp;
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static void fake_xpmem_spin_init_cb(void *lock)
{
	fake_xpmem_spin_init_calls++;
	fake_xpmem_spin_last_lock = lock;
}

static void fake_xpmem_spin_lock(void *lock)
{
	fake_xpmem_spin_lock_calls++;
	fake_xpmem_spin_last_lock = lock;
}

static void fake_xpmem_spin_unlock(void *lock)
{
	fake_xpmem_spin_unlock_calls++;
	fake_xpmem_spin_last_lock = lock;
}

static void fake_xpmem_release_aps(void *tg)
{
	fake_xpmem_release_aps_calls++;
	fake_xpmem_release_aps_tg = tg;
}

static void fake_xpmem_remove_segs(void *tg)
{
	fake_xpmem_remove_segs_calls++;
	fake_xpmem_remove_segs_tg = tg;
}

static void fake_xpmem_destroy_tg_cb(void *tg)
{
	fake_xpmem_destroy_tg_calls++;
	fake_xpmem_destroy_tg = tg;
}

static void fake_xpmem_flush_log(int event, void *tg, long value)
{
	fake_xpmem_flush_log_count++;
	fake_xpmem_flush_log_event_sum += event;
	fake_xpmem_flush_log_value_sum += value;
	fake_xpmem_flush_log_tg = tg;
}

static void fake_xpmem_clear_ptes(void *seg)
{
	fake_xpmem_clear_ptes_calls++;
	fake_xpmem_clear_ptes_seg = seg;
}

static void fake_xpmem_seg_destroyable(void *seg)
{
	fake_xpmem_seg_destroyable_calls++;
	fake_xpmem_seg_destroyable_seg = seg;
}

static void fake_xpmem_seg_not_destroyable_cb(void *seg)
{
	struct fake_xpmem_seg *segment = seg;

	fake_xpmem_seg_not_destroyable_calls++;
	fake_xpmem_seg_not_destroyable_seg = seg;
	if (segment)
		segment->refcnt = 1;
}

static long fake_xpmem_make_segid_cb(void *tg)
{
	(void)tg;

	fake_xpmem_make_segid_calls++;
	return fake_xpmem_make_segid_rc;
}

static long fake_xpmem_make_apid_cb(void *tg)
{
	(void)tg;

	fake_xpmem_make_apid_calls++;
	return fake_xpmem_make_apid_rc;
}

static int fake_xpmem_check_permit_cb(int flags, void *seg)
{
	fake_xpmem_check_permit_calls++;
	fake_xpmem_check_permit_flags = flags;
	fake_xpmem_check_permit_seg = seg;
	return fake_xpmem_check_permit_rc;
}

static void fake_xpmem_remove_seg_log(int event, void *tg, void *seg,
				      long value)
{
	struct fake_xpmem_tg *group = tg;
	struct fake_xpmem_seg *segment = seg;

	fake_xpmem_remove_seg_log_count++;
	fake_xpmem_remove_seg_log_event_sum += event +
		(group ? group->tgid : 0) + (segment ? segment->segid : 0);
	fake_xpmem_remove_seg_log_value_sum += value;
}

static void fake_xpmem_seg_ref_cb(void *seg)
{
	struct fake_xpmem_seg *segment = seg;

	fake_xpmem_seg_ref_calls++;
	fake_xpmem_seg_ref_id_sum += segment ? segment->segid : 0;
}

static void fake_xpmem_seg_deref_cb(void *seg)
{
	struct fake_xpmem_seg *segment = seg;

	fake_xpmem_seg_deref_calls++;
	fake_xpmem_seg_deref_id_sum += segment ? segment->segid : 0;
}

static void fake_xpmem_remove_seg_cb(void *tg, void *seg)
{
	struct fake_xpmem_seg *segment = seg;
	struct fake_xpmem_list *entry = &segment->seg_list;

	fake_xpmem_remove_seg_cb_calls++;
	fake_xpmem_remove_seg_cb_id_sum += segment->segid;
	fake_xpmem_remove_seg_cb_tg = tg;
	entry->prev->next = entry->next;
	entry->next->prev = entry->prev;
	entry->next = entry;
	entry->prev = entry;
}

static void fake_xpmem_remove_segs_log(int event, void *tg, void *seg,
				       long value)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_remove_segs_log_count++;
	fake_xpmem_remove_segs_log_event_sum += event +
		(group ? group->tgid : 0) + (seg != NULL) + (int)value;
}

static void fake_xpmem_att_ref_cb(void *att)
{
	struct fake_xpmem_att *attachment = att;

	fake_xpmem_att_ref_calls++;
	fake_xpmem_att_ref_id_sum += attachment ? attachment->id : 0;
}

static void fake_xpmem_att_deref_cb(void *att)
{
	struct fake_xpmem_att *attachment = att;

	fake_xpmem_att_deref_calls++;
	fake_xpmem_att_deref_id_sum += attachment ? attachment->id : 0;
}

static void fake_xpmem_detach_att_cb(void *ap, void *att)
{
	struct fake_xpmem_att *attachment = att;
	struct fake_xpmem_list *entry = &attachment->att_list;

	fake_xpmem_detach_att_calls++;
	fake_xpmem_detach_att_id_sum += attachment->id;
	fake_xpmem_detach_att_ap = ap;
	entry->prev->next = entry->next;
	entry->next->prev = entry->prev;
	entry->next = entry;
	entry->prev = entry;
}

static void fake_xpmem_tg_deref_cb(void *tg)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_tg_deref_calls++;
	fake_xpmem_tg_deref_tgid_sum += group ? group->tgid : 0;
}

static void fake_xpmem_tg_destroyable_cb(void *tg)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_tg_destroyable_calls++;
	fake_xpmem_tg_destroyable_tgid_sum += group ? group->tgid : 0;
}

static void fake_xpmem_destroyable_log_cb(int event)
{
	fake_xpmem_destroyable_log_calls++;
	fake_xpmem_destroyable_log_event_sum += event;
}

static void *fake_xpmem_refcnt_ptr_cb(void *object, int kind)
{
	fake_xpmem_refcnt_ptr_calls++;
	fake_xpmem_refcnt_ptr_kind_sum += kind;

	switch (kind) {
	case XPMEM_REF_KIND_TG:
		return object ? &((struct fake_xpmem_tg *)object)->refcnt : NULL;
	case XPMEM_REF_KIND_SEG:
		return object ? &((struct fake_xpmem_seg *)object)->refcnt : NULL;
	case XPMEM_REF_KIND_AP:
		return object ? &((struct fake_xpmem_ap *)object)->refcnt : NULL;
	case XPMEM_REF_KIND_ATT:
		return object ? &((struct fake_xpmem_att *)object)->refcnt : NULL;
	default:
		return NULL;
	}
}

static void fake_xpmem_refcnt_log_cb(int kind, int value)
{
	fake_xpmem_refcnt_log_calls++;
	fake_xpmem_refcnt_log_kind_sum += kind;
	fake_xpmem_refcnt_log_value_sum += value;
}

static void fake_xpmem_tg_not_destroyable_cb(void *tg)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_tg_not_destroyable_calls++;
	fake_xpmem_tg_not_destroyable_tgid_sum += group ? group->tgid : 0;
	if (group)
		group->refcnt = 1;
}

static void fake_xpmem_tg_ref_object_cb(void *tg)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_tg_ref_object_calls++;
	fake_xpmem_tg_ref_object_tgid_sum += group ? group->tgid : 0;
}

static void fake_xpmem_tg_lookup_log_cb(int event, int tgid,
					int return_destroying, void *part,
					void *result)
{
	fake_xpmem_tg_lookup_log_calls++;
	fake_xpmem_tg_lookup_log_event_sum += event;
	fake_xpmem_tg_lookup_log_tgid_sum += tgid;
	fake_xpmem_tg_lookup_log_destroy_sum += return_destroying;
	if (part)
		fake_xpmem_tg_lookup_log_part_count++;
	if (result)
		fake_xpmem_tg_lookup_log_result_count++;
}

static void fake_xpmem_ap_ref_cb(void *ap)
{
	struct fake_xpmem_ap *permit = ap;

	fake_xpmem_ap_ref_calls++;
	fake_xpmem_ap_ref_id_sum += permit ? permit->apid : 0;
}

static void fake_xpmem_ap_deref_cb(void *ap)
{
	struct fake_xpmem_ap *permit = ap;

	fake_xpmem_ap_deref_calls++;
	fake_xpmem_ap_deref_id_sum += permit ? permit->apid : 0;
}

static void fake_xpmem_ap_destroyable_cb(void *ap)
{
	fake_xpmem_ap_destroyable_calls++;
	fake_xpmem_ap_destroyable_ap = ap;
}

static void fake_xpmem_ap_not_destroyable_cb(void *ap)
{
	struct fake_xpmem_ap *permit = ap;

	fake_xpmem_ap_not_destroyable_calls++;
	fake_xpmem_ap_not_destroyable_ap = ap;
	if (permit)
		permit->refcnt = 1;
}

static void fake_xpmem_release_ap_cb(void *tg, void *ap)
{
	struct fake_xpmem_ap *permit = ap;
	struct fake_xpmem_list *entry = &permit->ap_hashlist;

	fake_xpmem_release_ap_cb_calls++;
	fake_xpmem_release_ap_cb_id_sum += permit->apid;
	fake_xpmem_release_ap_cb_tg = tg;
	entry->prev->next = entry->next;
	entry->next->prev = entry->prev;
	entry->next = entry;
	entry->prev = entry;
}

static void *fake_xpmem_tg_ref_by_id_cb(long id)
{
	fake_xpmem_tg_ref_by_id_calls++;
	fake_xpmem_tg_ref_by_id_value = id;
	return fake_xpmem_tg_ref_by_id_rc;
}

static void *fake_xpmem_seg_ref_by_id_cb(void *tg, long id)
{
	fake_xpmem_seg_ref_by_id_calls++;
	fake_xpmem_seg_ref_by_id_parent = tg;
	fake_xpmem_seg_ref_by_id_value = id;
	return fake_xpmem_seg_ref_by_id_rc;
}

static void *fake_xpmem_ap_ref_by_id_cb(void *tg, long id)
{
	fake_xpmem_ap_ref_by_id_calls++;
	fake_xpmem_ap_ref_by_id_parent = tg;
	fake_xpmem_ap_ref_by_id_value = id;
	return fake_xpmem_ap_ref_by_id_rc;
}

static void fake_xpmem_release_ap_log(int event, void *tg, void *ap,
				      long value)
{
	struct fake_xpmem_tg *group = tg;

	fake_xpmem_release_ap_log_count++;
	fake_xpmem_release_ap_log_event_sum += event +
		(group ? group->tgid : 0) + (ap != NULL);
	fake_xpmem_release_ap_log_value_sum += value;
}

static void fake_xpmem_write_lock_noirq(void *lock)
{
	fake_xpmem_write_lock_noirq_calls++;
	fake_xpmem_noirq_last_lock = lock;
}

static void fake_xpmem_write_unlock_noirq(void *lock)
{
	fake_xpmem_write_unlock_noirq_calls++;
	fake_xpmem_noirq_last_lock = lock;
}

static void fake_xpmem_read_lock_noirq(void *lock)
{
	fake_xpmem_read_lock_noirq_calls++;
	fake_xpmem_noirq_last_lock = lock;
}

static void fake_xpmem_read_unlock_noirq(void *lock)
{
	fake_xpmem_read_unlock_noirq_calls++;
	fake_xpmem_noirq_last_lock = lock;
}

static unsigned long fake_xpmem_att_write_lock(void *lock)
{
	fake_xpmem_att_write_lock_calls++;
	fake_xpmem_noirq_last_lock = lock;
	return 0xabc0 + fake_xpmem_att_write_lock_calls;
}

static void fake_xpmem_att_write_unlock(void *lock, unsigned long state)
{
	fake_xpmem_att_write_unlock_calls++;
	fake_xpmem_noirq_last_lock = lock;
	fake_xpmem_att_write_unlock_state_sum += state;
}

static void *fake_xpmem_lookup_range(void *vm, unsigned long start,
				     unsigned long end)
{
	fake_xpmem_lookup_range_calls++;
	fake_xpmem_lookup_range_vm = vm;
	fake_xpmem_lookup_range_start = start;
	fake_xpmem_lookup_range_end = end;
	if (fake_xpmem_lookup_range_calls <= fake_xpmem_lookup_range_seq_len)
		return fake_xpmem_lookup_range_seq[
			fake_xpmem_lookup_range_calls - 1];
	return fake_xpmem_lookup_range_rc;
}

static int fake_xpmem_page_fault_vm(void *vm, unsigned long vaddr,
				    unsigned long reason)
{
	fake_xpmem_page_fault_vm_calls++;
	fake_xpmem_page_fault_vm_vm = vm;
	fake_xpmem_page_fault_vm_vaddr = vaddr;
	fake_xpmem_page_fault_vm_reason = reason;
	return fake_xpmem_page_fault_vm_rc;
}

static int fake_xpmem_page_fault_range(void *vm, void *range,
				       unsigned long vaddr,
				       unsigned long reason)
{
	fake_xpmem_page_fault_range_calls++;
	fake_xpmem_page_fault_range_vm = vm;
	fake_xpmem_page_fault_range_range = range;
	fake_xpmem_page_fault_range_vaddr = vaddr;
	fake_xpmem_page_fault_range_reason = reason;
	return fake_xpmem_page_fault_range_rc;
}

static int fake_xpmem_pin_page(void *tg, void *thread, void *vm,
			       unsigned long vaddr, int page_in)
{
	fake_xpmem_pin_page_calls++;
	fake_xpmem_pin_page_tg = tg;
	fake_xpmem_pin_page_thread = thread;
	fake_xpmem_pin_page_vm = vm;
	fake_xpmem_pin_page_vaddr = vaddr;
	fake_xpmem_pin_page_page_in = page_in;
	return fake_xpmem_pin_page_rc;
}

static void *fake_xpmem_pt_lookup_pte(void *page_table, unsigned long vaddr,
				      int pgshift, void **basep,
				      size_t *pgsizep, int *p2alignp)
{
	fake_xpmem_pt_lookup_pte_calls++;
	fake_xpmem_pt_lookup_pte_page_table = page_table;
	fake_xpmem_pt_lookup_pte_vaddr = vaddr;
	fake_xpmem_pt_lookup_pte_vaddr_sum += vaddr;
	fake_xpmem_pt_lookup_pte_pgshift = pgshift;
	if (basep)
		*basep = (void *)(vaddr & ~0xfffUL);
	if (pgsizep)
		*pgsizep = fake_xpmem_pt_lookup_pte_pgsize;
	if (p2alignp)
		*p2alignp = 0;
	return fake_xpmem_pt_lookup_pte_rc;
}

static void *fake_xpmem_vaddr_to_pte(void *vm, unsigned long vaddr,
				     size_t *pgsizep)
{
	int index = fake_xpmem_vaddr_to_pte_calls;

	fake_xpmem_vaddr_to_pte_calls++;
	fake_xpmem_vaddr_to_pte_vm = vm;
	fake_xpmem_vaddr_to_pte_vaddr = vaddr;
	if (pgsizep) {
		if (index < 4)
			*pgsizep = fake_xpmem_vaddr_to_pte_sizes[index];
		else
			*pgsizep = PAGE_SIZE;
	}
	if (index < 4)
		return fake_xpmem_vaddr_to_pte_ptes[index];
	return NULL;
}

static int fake_xpmem_pte_present(void *pte)
{
	struct fake_xpmem_pte *entry = pte;

	fake_xpmem_pte_present_calls++;
	return entry ? entry->present : 0;
}

static int fake_xpmem_fault_ensure(void *seg, unsigned long vaddr,
				   int page_in)
{
	fake_xpmem_fault_ensure_calls++;
	fake_xpmem_fault_ensure_seg = seg;
	fake_xpmem_fault_ensure_vaddr = vaddr;
	fake_xpmem_fault_ensure_page_in = page_in;
	return fake_xpmem_fault_ensure_rc;
}

static unsigned long fake_xpmem_pte_phys(void *pte)
{
	struct fake_xpmem_pte *entry = pte;

	fake_xpmem_pte_phys_calls++;
	if (!entry)
		return 0;
	fake_xpmem_pte_phys_sum += entry->phys;
	return entry->phys;
}

static int fake_xpmem_smaller_page(size_t pgsize, size_t *new_pgsize,
				   int *p2align)
{
	fake_xpmem_smaller_page_calls++;
	fake_xpmem_smaller_page_last_pgsize = pgsize;
	if (new_pgsize)
		*new_pgsize = fake_xpmem_smaller_page_out;
	if (p2align)
		*p2align = fake_xpmem_smaller_page_align_out;
	return fake_xpmem_smaller_page_rc;
}

static void fake_xpmem_adjust_page(void *page_table, unsigned long fault_addr,
				   void *pte, void **pgaddr, size_t *pgsize)
{
	fake_xpmem_adjust_page_calls++;
	fake_xpmem_adjust_page_table = page_table;
	fake_xpmem_adjust_fault_addr = fault_addr;
	fake_xpmem_adjust_pte = pte;
	if (pgsize)
		fake_xpmem_adjust_pgsize = *pgsize;
	(void)pgaddr;
}

static unsigned long fake_xpmem_vrflag_to_ptattr(unsigned long flag,
						 unsigned long reason)
{
	fake_xpmem_vrflag_calls++;
	fake_xpmem_vrflag_flag = flag;
	fake_xpmem_vrflag_reason = reason;
	return fake_xpmem_vrflag_rc;
}

static int fake_xpmem_pgsize_contiguous(size_t pgsize)
{
	fake_xpmem_pgsize_contiguous_calls++;
	(void)pgsize;
	return fake_xpmem_pgsize_contiguous_rc;
}

static int fake_xpmem_pt_set_pte(void *page_table, void *pte, size_t pgsize,
				 unsigned long phys, unsigned long attr)
{
	fake_xpmem_pt_set_pte_calls++;
	fake_xpmem_pt_set_pte_page_table = page_table;
	fake_xpmem_pt_set_pte_pte = pte;
	fake_xpmem_pt_set_pte_pgsize = pgsize;
	fake_xpmem_pt_set_pte_phys = phys;
	fake_xpmem_pt_set_pte_attr = attr;
	return fake_xpmem_pt_set_pte_rc;
}

static int fake_xpmem_pt_set_range(void *page_table, void *vm,
				   unsigned long start, unsigned long end,
				   unsigned long phys, unsigned long attr,
				   int pgshift, void *vmr, int replace)
{
	fake_xpmem_pt_set_range_calls++;
	fake_xpmem_pt_set_range_page_table = page_table;
	fake_xpmem_pt_set_range_vm = vm;
	fake_xpmem_pt_set_range_start = start;
	fake_xpmem_pt_set_range_end = end;
	fake_xpmem_pt_set_range_phys = phys;
	fake_xpmem_pt_set_range_attr = attr;
	fake_xpmem_pt_set_range_pgshift = pgshift;
	fake_xpmem_pt_set_range_vmr = vmr;
	fake_xpmem_pt_set_range_replace = replace;
	return fake_xpmem_pt_set_range_rc;
}

static void fake_xpmem_flush_single(unsigned long vaddr)
{
	fake_xpmem_flush_single_calls++;
	fake_xpmem_flush_single_vaddr = vaddr;
}

static void fake_xpmem_fault_log(int event, unsigned long a,
				 unsigned long b, unsigned long c,
				 size_t size, int error)
{
	fake_xpmem_fault_log_calls++;
	fake_xpmem_fault_log_event_sum += event;
	fake_xpmem_fault_log_a_sum += a;
	fake_xpmem_fault_log_b_sum += b;
	fake_xpmem_fault_log_c_sum += c;
	fake_xpmem_fault_log_size_sum += size;
	fake_xpmem_fault_log_error_sum += error;
}

static void fake_xpmem_atomic_sub(int value, void *counter)
{
	int *intp = counter;

	fake_xpmem_atomic_sub_calls++;
	fake_xpmem_atomic_sub_value += value;
	fake_xpmem_atomic_sub_counter = counter;
	if (intp)
		*intp -= value;
}

static void fake_xpmem_clear_range(void *object, unsigned long start,
				   unsigned long end)
{
	fake_xpmem_clear_range_calls++;
	fake_xpmem_clear_range_object = object;
	fake_xpmem_clear_range_start = start;
	fake_xpmem_clear_range_end = end;
}

static void fake_xpmem_unpin_pages(void *seg, void *vm,
				   unsigned long vaddr, size_t size)
{
	fake_xpmem_unpin_pages_calls++;
	fake_xpmem_unpin_pages_seg = seg;
	fake_xpmem_unpin_pages_vm = vm;
	fake_xpmem_unpin_pages_vaddr = vaddr;
	fake_xpmem_unpin_pages_size = size;
}

static int fake_xpmem_munmap(void *vm, unsigned long addr, size_t len)
{
	fake_xpmem_munmap_calls++;
	fake_xpmem_munmap_vm = vm;
	fake_xpmem_munmap_addr = addr;
	fake_xpmem_munmap_len = len;
	return fake_xpmem_munmap_rc;
}

static void fake_xpmem_begin_pending(void)
{
	fake_xpmem_begin_pending_calls++;
}

static void fake_xpmem_finish_pending(void)
{
	fake_xpmem_finish_pending_calls++;
}

static int fake_xpmem_remove_range(void *vm, unsigned long start,
				   unsigned long end, int *ro_freedp)
{
	fake_xpmem_remove_range_calls++;
	fake_xpmem_remove_range_vm = vm;
	fake_xpmem_remove_range_start = start;
	fake_xpmem_remove_range_end = end;
	fake_xpmem_remove_range_ro_freed = 1;
	if (ro_freedp)
		*ro_freedp = 1;
	return fake_xpmem_remove_range_rc;
}

static void *fake_xpmem_next_range(void *vm, void *range)
{
	fake_xpmem_next_range_calls++;
	fake_xpmem_next_range_vm = vm;
	fake_xpmem_next_range_arg = range;
	if (fake_xpmem_next_range_calls <= fake_xpmem_next_range_seq_len)
		return fake_xpmem_next_range_seq[
			fake_xpmem_next_range_calls - 1];
	return fake_xpmem_next_range_rc;
}

static int fake_xpmem_split_range(void *vm, void *range,
				  unsigned long addr, void **newrangep)
{
	fake_xpmem_split_range_calls++;
	fake_xpmem_split_range_vm = vm;
	fake_xpmem_split_range_arg = range;
	fake_xpmem_split_range_addr = addr;
	fake_xpmem_split_range_addr_sum += addr;
	if (newrangep) {
		fake_xpmem_split_range_set_out_calls++;
		*newrangep = fake_xpmem_split_range_new_rc;
	} else {
		fake_xpmem_split_range_null_out_calls++;
	}
	return fake_xpmem_split_range_rc;
}

static int fake_xpmem_remove_private_range(void *vm, void *range)
{
	fake_xpmem_remove_private_range_calls++;
	fake_xpmem_remove_private_range_vm = vm;
	fake_xpmem_remove_private_range_arg = range;
	return 0;
}

static int fake_xpmem_free_range(void *vm, void *range)
{
	fake_xpmem_free_range_calls++;
	fake_xpmem_free_range_vm = vm;
	fake_xpmem_free_range_arg = range;
	return fake_xpmem_free_range_rc;
}

static void fake_xpmem_remove_process_range_log(void *vm,
						unsigned long start,
						unsigned long end,
						int error, int free_error)
{
	fake_xpmem_remove_process_range_log_calls++;
	fake_xpmem_remove_process_range_log_vm = vm;
	fake_xpmem_remove_process_range_log_start = start;
	fake_xpmem_remove_process_range_log_end = end;
	fake_xpmem_remove_process_range_log_error_sum += error;
	fake_xpmem_remove_process_range_log_free_sum += free_error;
}

static int fake_xpmem_free_process_pt_clear(void *page_table, void *vm,
					    unsigned long start,
					    unsigned long end)
{
	fake_xpmem_free_process_pt_clear_calls++;
	fake_xpmem_free_process_pt_clear_page_table = page_table;
	fake_xpmem_free_process_pt_clear_vm = vm;
	fake_xpmem_free_process_pt_clear_start = start;
	fake_xpmem_free_process_pt_clear_end = end;
	return fake_xpmem_free_process_pt_clear_rc;
}

static void fake_xpmem_free_process_memobj_unref(void *memobj)
{
	fake_xpmem_free_process_memobj_unref_calls++;
	fake_xpmem_free_process_memobj_unref_arg = memobj;
}

static void fake_xpmem_free_process_erase(void *root, void *node)
{
	fake_xpmem_free_process_erase_calls++;
	fake_xpmem_free_process_erase_root = root;
	fake_xpmem_free_process_erase_node = node;
}

static void fake_xpmem_free_process_free(void *range)
{
	fake_xpmem_free_process_free_calls++;
	fake_xpmem_free_process_free_arg = range;
}

static void fake_xpmem_free_process_log(int event, void *vm, void *range,
					unsigned long start, unsigned long end,
					int error)
{
	(void)start;
	(void)end;
	fake_xpmem_free_process_log_calls++;
	fake_xpmem_free_process_log_event_sum += event;
	fake_xpmem_free_process_log_error_sum += error;
	fake_xpmem_free_process_log_vm = vm;
	fake_xpmem_free_process_log_range = range;
}

static int fake_xpmem_update_fault(void *vm, void *range,
				   unsigned long vaddr,
				   unsigned long reason, int page_in_remote)
{
	fake_xpmem_update_fault_calls++;
	fake_xpmem_update_fault_vm = vm;
	fake_xpmem_update_fault_range = range;
	fake_xpmem_update_fault_vaddr = vaddr;
	fake_xpmem_update_fault_vaddr_sum += vaddr;
	fake_xpmem_update_fault_reason_sum += reason;
	fake_xpmem_update_fault_page_in_sum += page_in_remote;
	return fake_xpmem_update_fault_rc;
}

static void fake_xpmem_update_log(int event, void *vm, void *range,
				  unsigned long vaddr, int error)
{
	fake_xpmem_update_log_calls++;
	fake_xpmem_update_log_event_sum += event;
	fake_xpmem_update_log_error_sum += error;
	fake_xpmem_update_log_vm = vm;
	fake_xpmem_update_log_range = range;
	fake_xpmem_update_log_vaddr_sum += vaddr;
}

static void fake_xpmem_att_destroyable_cb(void *att)
{
	fake_xpmem_att_destroyable_calls++;
	fake_xpmem_att_destroyable_att = att;
}

static void fake_xpmem_att_not_destroyable_cb(void *att)
{
	struct fake_xpmem_att *attachment = att;

	fake_xpmem_att_not_destroyable_calls++;
	fake_xpmem_att_not_destroyable_att = att;
	if (attachment)
		attachment->refcnt = 1;
}

static int fake_xpmem_attach_validate(void *ap, long offset, size_t size,
				      int mode, unsigned long *vaddrp)
{
	fake_xpmem_attach_validate_calls++;
	fake_xpmem_attach_validate_ap = ap;
	fake_xpmem_attach_validate_offset = offset;
	fake_xpmem_attach_validate_size = size;
	fake_xpmem_attach_validate_mode = mode;
	if (vaddrp)
		*vaddrp = fake_xpmem_attach_validate_seg_vaddr;
	return fake_xpmem_attach_validate_rc;
}

static unsigned long fake_xpmem_attach_mmap(unsigned long addr, size_t len,
					    unsigned long prot,
					    unsigned long flags, int fd,
					    long offset,
					    unsigned long vm_flags,
					    void *private_data)
{
	fake_xpmem_attach_mmap_calls++;
	fake_xpmem_attach_mmap_addr = addr;
	fake_xpmem_attach_mmap_len = len;
	fake_xpmem_attach_mmap_prot = prot;
	fake_xpmem_attach_mmap_flags = flags;
	fake_xpmem_attach_mmap_fd = fd;
	fake_xpmem_attach_mmap_offset = offset;
	fake_xpmem_attach_mmap_vm_flags = vm_flags;
	fake_xpmem_attach_mmap_private_data = private_data;
	return fake_xpmem_attach_mmap_rc;
}

static int fake_xpmem_ioctl_copy_from(void *dst, unsigned long src,
				      size_t size)
{
	fake_xpmem_ioctl_copy_from_calls++;
	fake_xpmem_ioctl_copy_from_src = src;
	fake_xpmem_ioctl_copy_from_size = size;
	if (fake_xpmem_ioctl_copy_from_rc)
		return fake_xpmem_ioctl_copy_from_rc;
	memcpy(dst, (void *)src, size);
	return 0;
}

static int fake_xpmem_ioctl_copy_to(unsigned long dst, const void *src,
				    size_t size)
{
	fake_xpmem_ioctl_copy_to_calls++;
	fake_xpmem_ioctl_copy_to_dst = dst;
	fake_xpmem_ioctl_copy_to_size = size;
	if (fake_xpmem_ioctl_copy_to_rc)
		return fake_xpmem_ioctl_copy_to_rc;
	memcpy((void *)dst, src, size);
	return 0;
}

static int fake_xpmem_ioctl_make(unsigned long vaddr, size_t size,
				 int permit_type, void *permit_value,
				 long *segidp)
{
	fake_xpmem_ioctl_make_calls++;
	fake_xpmem_ioctl_make_vaddr = vaddr;
	fake_xpmem_ioctl_make_size = size;
	fake_xpmem_ioctl_make_permit_type = permit_type;
	fake_xpmem_ioctl_make_permit_value = permit_value;
	if (!fake_xpmem_ioctl_make_rc && segidp)
		*segidp = fake_xpmem_ioctl_make_out;
	return fake_xpmem_ioctl_make_rc;
}

static int fake_xpmem_ioctl_remove(long segid)
{
	fake_xpmem_ioctl_remove_calls++;
	fake_xpmem_ioctl_remove_id = segid;
	return fake_xpmem_ioctl_remove_rc;
}

static int fake_xpmem_ioctl_get(long segid, int flags, int permit_type,
				void *permit_value, long *apidp)
{
	fake_xpmem_ioctl_get_calls++;
	fake_xpmem_ioctl_get_segid = segid;
	fake_xpmem_ioctl_get_flags = flags;
	fake_xpmem_ioctl_get_permit_type = permit_type;
	fake_xpmem_ioctl_get_permit_value = permit_value;
	if (!fake_xpmem_ioctl_get_rc && apidp)
		*apidp = fake_xpmem_ioctl_get_out;
	return fake_xpmem_ioctl_get_rc;
}

static int fake_xpmem_ioctl_release(long apid)
{
	fake_xpmem_ioctl_release_calls++;
	fake_xpmem_ioctl_release_id = apid;
	return fake_xpmem_ioctl_release_rc;
}

static int fake_xpmem_ioctl_attach(void *mckfd, long apid, long offset,
				   size_t size, unsigned long vaddr, int fd,
				   int flags, unsigned long *at_vaddrp)
{
	fake_xpmem_ioctl_attach_calls++;
	fake_xpmem_ioctl_attach_mckfd = mckfd;
	fake_xpmem_ioctl_attach_apid = apid;
	fake_xpmem_ioctl_attach_offset = offset;
	fake_xpmem_ioctl_attach_size = size;
	fake_xpmem_ioctl_attach_vaddr = vaddr;
	fake_xpmem_ioctl_attach_fd = fd;
	fake_xpmem_ioctl_attach_flags = flags;
	if (!fake_xpmem_ioctl_attach_rc && at_vaddrp)
		*at_vaddrp = fake_xpmem_ioctl_attach_out;
	return fake_xpmem_ioctl_attach_rc;
}

static int fake_xpmem_ioctl_detach(unsigned long vaddr)
{
	fake_xpmem_ioctl_detach_calls++;
	fake_xpmem_ioctl_detach_vaddr = vaddr;
	return fake_xpmem_ioctl_detach_rc;
}

static void fake_xpmem_open_reset(struct fake_xpmem_proc *proc,
				  struct fake_xpmem_mckfd *slot,
				  struct fake_xpmem_mckfd *old_head)
{
	fake_xpmem_init_calls = 0;
	fake_xpmem_forward_calls = 0;
	fake_xpmem_open_calls = 0;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_lock_calls = 0;
	fake_xpmem_unlock_calls = 0;
	fake_xpmem_atomic_calls = 0;
	fake_xpmem_log_count = 0;
	fake_xpmem_log_event_sum = 0;
	fake_xpmem_log_value_sum = 0;
	fake_xpmem_forward_rc = 0;
	fake_xpmem_open_rc = 0;
	fake_xpmem_alloc_rc = slot;
	fake_xpmem_unlock_irq = 0;
	fake_xpmem_part.n_opened = 0;
	proc->pid = 1001;
	proc->mckfd_lock = 0x1234;
	proc->mckfd = old_head;
	if (slot)
		memset(slot, 0xa5, sizeof(*slot));
}

static void fake_xpmem_close_reset(void)
{
	fake_xpmem_atomic_calls = 0;
	fake_xpmem_atomic_dec_calls = 0;
	fake_xpmem_flush_calls = 0;
	fake_xpmem_flush_fd_sum = 0;
	fake_xpmem_exit_calls = 0;
	fake_xpmem_close_log_count = 0;
	fake_xpmem_close_log_event_sum = 0;
	fake_xpmem_close_log_value_sum = 0;
}

static void fake_xpmem_partition_reset(void)
{
	memset(&fake_xpmem_part, 0xa5, sizeof(fake_xpmem_part));
	fake_xpmem_partp = NULL;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_alloc_rc = &fake_xpmem_part;
	fake_xpmem_rwlock_init_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_atomic_set_calls = 0;
	fake_xpmem_atomic_set_value_sum = 0;
	fake_xpmem_free_calls = 0;
	fake_xpmem_free_ptr = NULL;
}

static void fake_xpmem_flush_reset(struct fake_xpmem_proc *proc,
				   struct fake_xpmem_mckfd *mckfd,
				   struct fake_xpmem_tg *tg)
{
	for (int i = 0; i < 8; i++) {
		fake_xpmem_part.tg_hashtable[i].lock = 0x7000 + i;
		fake_xpmem_part.tg_hashtable[i].list.next =
			&fake_xpmem_part.tg_hashtable[i].list;
		fake_xpmem_part.tg_hashtable[i].list.prev =
			&fake_xpmem_part.tg_hashtable[i].list;
	}
	proc->pid = 1001;
	mckfd->fd = 77;
	mckfd->data = (long)proc;
	tg->lock = 0xfeed1000;
	tg->flags = 0x10;
	tg->tg_hashlist.next = (struct fake_xpmem_list *)0x10101010UL;
	tg->tg_hashlist.prev = (struct fake_xpmem_list *)0x20202020UL;
	tg->vm = (void *)0xabcdef00UL;
	fake_xpmem_partp = &fake_xpmem_part;
	fake_xpmem_tg_ref_calls = 0;
	fake_xpmem_tg_ref_pid = 0;
	fake_xpmem_tg_ref_rc = tg;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_release_aps_calls = 0;
	fake_xpmem_remove_segs_calls = 0;
	fake_xpmem_destroy_tg_calls = 0;
	fake_xpmem_release_aps_tg = NULL;
	fake_xpmem_remove_segs_tg = NULL;
	fake_xpmem_destroy_tg = NULL;
	fake_xpmem_flush_log_count = 0;
	fake_xpmem_flush_log_event_sum = 0;
	fake_xpmem_flush_log_value_sum = 0;
	fake_xpmem_flush_log_tg = NULL;
}

static void fake_xpmem_open_tg_reset(struct fake_xpmem_proc *proc,
				     struct fake_xpmem_tg *tg,
				     struct fake_xpmem_vm *vm)
{
	memset(proc, 0, sizeof(*proc));
	memset(tg, 0xa5, sizeof(*tg));
	memset(vm, 0, sizeof(*vm));
	memset(&fake_xpmem_part, 0, sizeof(fake_xpmem_part));

	proc->pid = 1003;
	proc->ruid = 1200;
	proc->rgid = 3400;
	proc->vm = vm;
	for (int i = 0; i < 8; i++) {
		fake_xpmem_part.tg_hashtable[i].lock = 0x7700 + i;
		fake_xpmem_list_init(&fake_xpmem_part.tg_hashtable[i].list);
	}
	fake_xpmem_partp = &fake_xpmem_part;
	fake_xpmem_tg_ref_calls = 0;
	fake_xpmem_tg_ref_pid = 0;
	fake_xpmem_tg_ref_rc = (void *)-2L;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_alloc_rc = tg;
	fake_xpmem_spin_init_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_rwlock_init_calls = 0;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_atomic_set_calls = 0;
	fake_xpmem_atomic_set_value_sum = 0;
	fake_xpmem_tg_not_destroyable_calls = 0;
	fake_xpmem_tg_not_destroyable_tgid_sum = 0;
	fake_xpmem_list_add_tail_calls = 0;
	fake_xpmem_list_add_tail_entry = NULL;
	fake_xpmem_list_add_tail_head = NULL;
}

static void fake_xpmem_remove_seg_reset(struct fake_xpmem_tg *tg,
					struct fake_xpmem_seg *seg)
{
	tg->lock = 0x8800;
	tg->tgid = 1234;
	tg->flags = 0;
	tg->seg_list_lock = 0x8801;
	tg->seg_list.next = &seg->seg_list;
	tg->seg_list.prev = &seg->seg_list;
	seg->lock = 0x9900;
	seg->segid = 0x12345678;
	seg->flags = 0x20;
	seg->seg_list.next = (struct fake_xpmem_list *)0x30303030UL;
	seg->seg_list.prev = (struct fake_xpmem_list *)0x40404040UL;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_clear_ptes_calls = 0;
	fake_xpmem_clear_ptes_seg = NULL;
	fake_xpmem_seg_destroyable_calls = 0;
	fake_xpmem_seg_destroyable_seg = NULL;
	fake_xpmem_remove_seg_log_count = 0;
	fake_xpmem_remove_seg_log_event_sum = 0;
	fake_xpmem_remove_seg_log_value_sum = 0;
}

static void fake_xpmem_remove_segs_reset(struct fake_xpmem_tg *tg,
					 struct fake_xpmem_seg *seg1,
					 struct fake_xpmem_seg *seg2)
{
	tg->lock = 0x8800;
	tg->tgid = 1234;
	tg->flags = 0;
	tg->seg_list_lock = 0x8801;
	tg->seg_list.next = &seg1->seg_list;
	tg->seg_list.prev = &seg2->seg_list;
	seg1->lock = 0x9901;
	seg1->segid = 0x1111;
	seg1->flags = 0x20;
	seg1->seg_list.next = &seg2->seg_list;
	seg1->seg_list.prev = &tg->seg_list;
	seg2->lock = 0x9902;
	seg2->segid = 0x2222;
	seg2->flags = 0x30;
	seg2->seg_list.next = &tg->seg_list;
	seg2->seg_list.prev = &seg1->seg_list;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_seg_ref_calls = 0;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_ref_id_sum = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_remove_seg_cb_calls = 0;
	fake_xpmem_remove_seg_cb_id_sum = 0;
	fake_xpmem_remove_seg_cb_tg = NULL;
	fake_xpmem_remove_segs_log_count = 0;
	fake_xpmem_remove_segs_log_event_sum = 0;
}

static void fake_xpmem_release_ap_reset(struct fake_xpmem_tg *ap_tg,
					struct fake_xpmem_tg *seg_tg,
					struct fake_xpmem_seg *seg,
					struct fake_xpmem_ap *ap,
					struct fake_xpmem_att *att1,
					struct fake_xpmem_att *att2)
{
	int index = 5;

	memset(ap_tg, 0, sizeof(*ap_tg));
	memset(seg_tg, 0, sizeof(*seg_tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0, sizeof(*ap));
	memset(att1, 0, sizeof(*att1));
	memset(att2, 0, sizeof(*att2));
	ap_tg->tgid = 1234;
	seg_tg->tgid = 4321;
	for (int i = 0; i < 8; i++) {
		ap_tg->ap_hashtable[i].lock = 0x7000 + i;
		ap_tg->ap_hashtable[i].list.next =
			&ap_tg->ap_hashtable[i].list;
		ap_tg->ap_hashtable[i].list.prev =
			&ap_tg->ap_hashtable[i].list;
	}
	seg->lock = 0x9900;
	seg->segid = 0x5555;
	seg->flags = 0;
	seg->tg = seg_tg;
	ap->lock = 0x8800;
	ap->apid = ((long)index << 32) | ap_tg->tgid;
	ap->flags = 0x20;
	ap->seg = seg;
	ap->tg = ap_tg;
	ap->att_list.next = &att1->att_list;
	ap->att_list.prev = &att2->att_list;
	ap->ap_list.next = (struct fake_xpmem_list *)0x11110000UL;
	ap->ap_list.prev = (struct fake_xpmem_list *)0x22220000UL;
	ap->ap_hashlist.next = &ap_tg->ap_hashtable[index].list;
	ap->ap_hashlist.prev = &ap_tg->ap_hashtable[index].list;
	ap_tg->ap_hashtable[index].list.next = &ap->ap_hashlist;
	ap_tg->ap_hashtable[index].list.prev = &ap->ap_hashlist;
	att1->id = 0x101;
	att1->ap = ap;
	att1->att_list.next = &att2->att_list;
	att1->att_list.prev = &ap->att_list;
	att2->id = 0x202;
	att2->ap = ap;
	att2->att_list.next = &ap->att_list;
	att2->att_list.prev = &att1->att_list;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_att_ref_calls = 0;
	fake_xpmem_att_deref_calls = 0;
	fake_xpmem_att_ref_id_sum = 0;
	fake_xpmem_att_deref_id_sum = 0;
	fake_xpmem_detach_att_calls = 0;
	fake_xpmem_detach_att_id_sum = 0;
	fake_xpmem_detach_att_ap = NULL;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_tg_destroyable_calls = 0;
	fake_xpmem_tg_destroyable_tgid_sum = 0;
	fake_xpmem_ap_ref_calls = 0;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_ref_id_sum = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_ap_destroyable_calls = 0;
	fake_xpmem_ap_destroyable_ap = NULL;
	fake_xpmem_release_ap_log_count = 0;
	fake_xpmem_release_ap_log_event_sum = 0;
	fake_xpmem_release_ap_log_value_sum = 0;
	fake_xpmem_release_ap_cb_calls = 0;
	fake_xpmem_release_ap_cb_id_sum = 0;
	fake_xpmem_release_ap_cb_tg = NULL;
	fake_xpmem_tg_ref_by_id_calls = 0;
	fake_xpmem_tg_ref_by_id_value = 0;
	fake_xpmem_tg_ref_by_id_rc = NULL;
	fake_xpmem_seg_ref_by_id_calls = 0;
	fake_xpmem_seg_ref_by_id_value = 0;
	fake_xpmem_seg_ref_by_id_parent = NULL;
	fake_xpmem_seg_ref_by_id_rc = NULL;
	fake_xpmem_ap_ref_by_id_calls = 0;
	fake_xpmem_ap_ref_by_id_value = 0;
	fake_xpmem_ap_ref_by_id_parent = NULL;
	fake_xpmem_ap_ref_by_id_rc = NULL;
}

static void fake_xpmem_release_aps_reset(struct fake_xpmem_tg *ap_tg,
					 struct fake_xpmem_ap *ap1,
					 struct fake_xpmem_ap *ap2)
{
	memset(ap_tg, 0, sizeof(*ap_tg));
	memset(ap1, 0, sizeof(*ap1));
	memset(ap2, 0, sizeof(*ap2));
	ap_tg->tgid = 1234;
	for (int i = 0; i < 8; i++) {
		ap_tg->ap_hashtable[i].lock = 0x8000 + i;
		ap_tg->ap_hashtable[i].list.next =
			&ap_tg->ap_hashtable[i].list;
		ap_tg->ap_hashtable[i].list.prev =
			&ap_tg->ap_hashtable[i].list;
	}
	ap1->apid = ((long)1 << 32) | ap_tg->tgid;
	ap1->ap_hashlist.next = &ap_tg->ap_hashtable[1].list;
	ap1->ap_hashlist.prev = &ap_tg->ap_hashtable[1].list;
	ap_tg->ap_hashtable[1].list.next = &ap1->ap_hashlist;
	ap_tg->ap_hashtable[1].list.prev = &ap1->ap_hashlist;
	ap2->apid = ((long)5 << 32) | ap_tg->tgid;
	ap2->ap_hashlist.next = &ap_tg->ap_hashtable[5].list;
	ap2->ap_hashlist.prev = &ap_tg->ap_hashtable[5].list;
	ap_tg->ap_hashtable[5].list.next = &ap2->ap_hashlist;
	ap_tg->ap_hashtable[5].list.prev = &ap2->ap_hashlist;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_ap_ref_calls = 0;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_ref_id_sum = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_release_ap_cb_calls = 0;
	fake_xpmem_release_ap_cb_id_sum = 0;
	fake_xpmem_release_ap_cb_tg = NULL;
	fake_xpmem_remove_segs_log_count = 0;
	fake_xpmem_remove_segs_log_event_sum = 0;
}

static void fake_xpmem_lookup_ref_reset(struct fake_xpmem_tg *tg,
					struct fake_xpmem_tg *tg2,
					struct fake_xpmem_seg *seg,
					struct fake_xpmem_seg *seg2,
					struct fake_xpmem_ap *ap,
					struct fake_xpmem_ap *ap2)
{
	memset(&fake_xpmem_part, 0, sizeof(fake_xpmem_part));
	memset(tg, 0, sizeof(*tg));
	memset(tg2, 0, sizeof(*tg2));
	memset(seg, 0, sizeof(*seg));
	memset(seg2, 0, sizeof(*seg2));
	memset(ap, 0, sizeof(*ap));
	memset(ap2, 0, sizeof(*ap2));

	for (int i = 0; i < 8; i++) {
		fake_xpmem_part.tg_hashtable[i].lock = 0x5000 + i;
		fake_xpmem_list_init(&fake_xpmem_part.tg_hashtable[i].list);
		tg->ap_hashtable[i].lock = 0x6000 + i;
		fake_xpmem_list_init(&tg->ap_hashtable[i].list);
	}

	tg->tgid = 1003;
	tg->seg_list_lock = 0x7100;
	fake_xpmem_list_init(&tg->seg_list);
	fake_xpmem_list_add_tail(&tg->tg_hashlist,
		&fake_xpmem_part.tg_hashtable[3].list);
	tg2->tgid = 1011;
	fake_xpmem_list_add_tail(&tg2->tg_hashlist,
		&fake_xpmem_part.tg_hashtable[3].list);

	seg->segid = 0x33330001;
	seg->tg = tg;
	fake_xpmem_list_add_tail(&seg->seg_list, &tg->seg_list);
	seg2->segid = 0x33330002;
	seg2->tg = tg;
	fake_xpmem_list_add_tail(&seg2->seg_list, &tg->seg_list);

	ap->apid = ((long)5 << 32) | tg->tgid;
	ap->tg = tg;
	ap->seg = seg;
	fake_xpmem_list_add_tail(&ap->ap_hashlist,
		&tg->ap_hashtable[5].list);
	ap2->apid = ((long)5 << 32) | tg2->tgid;
	ap2->tg = tg;
	ap2->seg = seg2;
	fake_xpmem_list_add_tail(&ap2->ap_hashlist,
		&tg->ap_hashtable[5].list);

	fake_xpmem_tg_ref_object_calls = 0;
	fake_xpmem_tg_ref_object_tgid_sum = 0;
	fake_xpmem_tg_lookup_log_calls = 0;
	fake_xpmem_tg_lookup_log_event_sum = 0;
	fake_xpmem_tg_lookup_log_tgid_sum = 0;
	fake_xpmem_tg_lookup_log_destroy_sum = 0;
	fake_xpmem_tg_lookup_log_part_count = 0;
	fake_xpmem_tg_lookup_log_result_count = 0;
	fake_xpmem_seg_ref_calls = 0;
	fake_xpmem_seg_ref_id_sum = 0;
	fake_xpmem_ap_ref_calls = 0;
	fake_xpmem_ap_ref_id_sum = 0;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
}

static void fake_xpmem_deref_reset(void)
{
	fake_xpmem_atomic_read_calls = 0;
	fake_xpmem_atomic_dec_calls = 0;
	fake_xpmem_bug_on_calls = 0;
	fake_xpmem_bug_on_condition_sum = 0;
	fake_xpmem_free_calls = 0;
	fake_xpmem_free_ptr = NULL;
	fake_xpmem_deref_log_calls = 0;
	fake_xpmem_deref_log_ptr = NULL;
}

static void fake_xpmem_make_segment_reset(struct fake_xpmem_proc *proc,
					  struct fake_xpmem_tg *tg,
					  struct fake_xpmem_seg *seg)
{
	memset(proc, 0, sizeof(*proc));
	memset(tg, 0, sizeof(*tg));
	memset(seg, 0xa5, sizeof(*seg));

	proc->pid = 1003;
	tg->tgid = proc->pid;
	tg->seg_list_lock = 0x7100;
	fake_xpmem_list_init(&tg->seg_list);
	fake_xpmem_tg_ref_calls = 0;
	fake_xpmem_tg_ref_pid = 0;
	fake_xpmem_tg_ref_rc = tg;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_make_segid_calls = 0;
	fake_xpmem_make_segid_rc = ((long)7 << 32) | proc->pid;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_alloc_rc = seg;
	fake_xpmem_spin_init_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_seg_not_destroyable_calls = 0;
	fake_xpmem_seg_not_destroyable_seg = NULL;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_add_tail_calls = 0;
	fake_xpmem_list_add_tail_entry = NULL;
	fake_xpmem_list_add_tail_head = NULL;
	fake_xpmem_bug_on_calls = 0;
	fake_xpmem_bug_on_condition_sum = 0;
}

static void fake_xpmem_get_reset(struct fake_xpmem_proc *proc,
				 struct fake_xpmem_tg *seg_tg,
				 struct fake_xpmem_tg *ap_tg,
				 struct fake_xpmem_seg *seg,
				 struct fake_xpmem_ap *ap)
{
	memset(proc, 0, sizeof(*proc));
	memset(seg_tg, 0, sizeof(*seg_tg));
	memset(ap_tg, 0, sizeof(*ap_tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0xa5, sizeof(*ap));

	proc->pid = 2007;
	seg_tg->tgid = 1003;
	seg_tg->refcnt = 1;
	ap_tg->tgid = proc->pid;
	ap_tg->refcnt = 1;
	for (int i = 0; i < 8; i++) {
		ap_tg->ap_hashtable[i].lock = 0x9100 + i;
		fake_xpmem_list_init(&ap_tg->ap_hashtable[i].list);
	}
	seg->lock = 0x8300;
	seg->segid = ((long)7 << 32) | seg_tg->tgid;
	seg->permit_type = XPMEM_PERMIT_MODE;
	seg->permit_value = (void *)0600UL;
	seg->tg = seg_tg;
	fake_xpmem_list_init(&seg->ap_list);
	fake_xpmem_tg_ref_by_id_calls = 0;
	fake_xpmem_tg_ref_by_id_value = 0;
	fake_xpmem_tg_ref_by_id_rc = seg_tg;
	fake_xpmem_seg_ref_by_id_calls = 0;
	fake_xpmem_seg_ref_by_id_value = 0;
	fake_xpmem_seg_ref_by_id_parent = NULL;
	fake_xpmem_seg_ref_by_id_rc = seg;
	fake_xpmem_check_permit_calls = 0;
	fake_xpmem_check_permit_flags = 0;
	fake_xpmem_check_permit_seg = NULL;
	fake_xpmem_check_permit_rc = 0;
	fake_xpmem_tg_ref_calls = 0;
	fake_xpmem_tg_ref_pid = 0;
	fake_xpmem_tg_ref_rc = ap_tg;
	fake_xpmem_make_apid_calls = 0;
	fake_xpmem_make_apid_rc = ((long)6 << 32) | proc->pid;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_alloc_rc = ap;
	fake_xpmem_spin_init_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_ap_destroyable_calls = 0;
	fake_xpmem_ap_destroyable_ap = NULL;
	fake_xpmem_ap_not_destroyable_calls = 0;
	fake_xpmem_ap_not_destroyable_ap = NULL;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_rwlock_lock_calls = 0;
	fake_xpmem_rwlock_unlock_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_rwlock_last_node = NULL;
	fake_xpmem_list_add_tail_calls = 0;
	fake_xpmem_list_add_tail_entry = NULL;
	fake_xpmem_list_add_tail_head = NULL;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_bug_on_calls = 0;
	fake_xpmem_bug_on_condition_sum = 0;
}

static void fake_xpmem_release_wrapper_reset(struct fake_xpmem_tg *tg,
					     struct fake_xpmem_seg *seg,
					     struct fake_xpmem_ap *ap)
{
	memset(tg, 0, sizeof(*tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0, sizeof(*ap));
	tg->tgid = 1234;
	seg->segid = ((long)3 << 32) | tg->tgid;
	seg->tg = tg;
	seg->seg_list.next = &seg->seg_list;
	seg->seg_list.prev = &seg->seg_list;
	ap->apid = ((long)4 << 32) | tg->tgid;
	ap->tg = tg;
	ap->ap_hashlist.next = &ap->ap_hashlist;
	ap->ap_hashlist.prev = &ap->ap_hashlist;
	fake_xpmem_tg_ref_by_id_calls = 0;
	fake_xpmem_tg_ref_by_id_value = 0;
	fake_xpmem_tg_ref_by_id_rc = tg;
	fake_xpmem_seg_ref_by_id_calls = 0;
	fake_xpmem_seg_ref_by_id_value = 0;
	fake_xpmem_seg_ref_by_id_parent = NULL;
	fake_xpmem_seg_ref_by_id_rc = seg;
	fake_xpmem_ap_ref_by_id_calls = 0;
	fake_xpmem_ap_ref_by_id_value = 0;
	fake_xpmem_ap_ref_by_id_parent = NULL;
	fake_xpmem_ap_ref_by_id_rc = ap;
	fake_xpmem_remove_seg_cb_calls = 0;
	fake_xpmem_remove_seg_cb_id_sum = 0;
	fake_xpmem_remove_seg_cb_tg = NULL;
	fake_xpmem_release_ap_cb_calls = 0;
	fake_xpmem_release_ap_cb_id_sum = 0;
	fake_xpmem_release_ap_cb_tg = NULL;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_tg_destroyable_calls = 0;
	fake_xpmem_tg_destroyable_tgid_sum = 0;
}

static void fake_xpmem_detach_reset(struct fake_xpmem_vm *vm,
				    struct fake_xpmem_range *range,
				    struct fake_xpmem_tg *tg,
				    struct fake_xpmem_seg *seg,
				    struct fake_xpmem_ap *ap,
				    struct fake_xpmem_att *att)
{
	memset(vm, 0, sizeof(*vm));
	memset(range, 0, sizeof(*range));
	memset(tg, 0, sizeof(*tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0, sizeof(*ap));
	memset(att, 0, sizeof(*att));

	vm->memory_range_lock = 0x1100;
	range->start = 0x4000;
	range->end = 0x5000;
	range->private_data = att;
	tg->tgid = 1234;
	seg->lock = 0x2200;
	seg->segid = 0x7070;
	seg->vaddr = 0x6000;
	seg->size = 0x3000;
	seg->tg = tg;
	seg->ap_list.next = &ap->ap_list;
	seg->ap_list.prev = &ap->ap_list;
	ap->lock = 0x3300;
	ap->apid = ((long)7 << 32) | tg->tgid;
	ap->seg = seg;
	ap->tg = tg;
	ap->att_list.next = &att->att_list;
	ap->att_list.prev = &att->att_list;
	ap->ap_list.next = &seg->ap_list;
	ap->ap_list.prev = &seg->ap_list;
	att->id = 0x909;
	att->at_lock = 0x4400;
	att->vaddr = 0x6000;
	att->at_vaddr = 0x4200;
	att->at_size = 0x1000;
	att->flags = XPMEM_FLAG_VALIDPTEs | 0x20;
	att->ap = ap;
	att->vm = vm;
	att->att_list.next = &ap->att_list;
	att->att_list.prev = &ap->att_list;

	fake_xpmem_write_lock_noirq_calls = 0;
	fake_xpmem_write_unlock_noirq_calls = 0;
	fake_xpmem_read_lock_noirq_calls = 0;
	fake_xpmem_read_unlock_noirq_calls = 0;
	fake_xpmem_noirq_last_lock = NULL;
	fake_xpmem_att_write_lock_calls = 0;
	fake_xpmem_att_write_unlock_calls = 0;
	fake_xpmem_att_write_unlock_state_sum = 0;
	fake_xpmem_lookup_range_calls = 0;
	fake_xpmem_lookup_range_vm = NULL;
	fake_xpmem_lookup_range_start = 0;
	fake_xpmem_lookup_range_end = 0;
	fake_xpmem_lookup_range_rc = range;
	memset(fake_xpmem_lookup_range_seq, 0,
	       sizeof(fake_xpmem_lookup_range_seq));
	fake_xpmem_lookup_range_seq_len = 0;
	fake_xpmem_unpin_pages_calls = 0;
	fake_xpmem_unpin_pages_seg = NULL;
	fake_xpmem_unpin_pages_vm = NULL;
	fake_xpmem_unpin_pages_vaddr = 0;
	fake_xpmem_unpin_pages_size = 0;
	fake_xpmem_munmap_calls = 0;
	fake_xpmem_munmap_vm = NULL;
	fake_xpmem_munmap_addr = 0;
	fake_xpmem_munmap_len = 0;
	fake_xpmem_munmap_rc = 0;
	fake_xpmem_begin_pending_calls = 0;
	fake_xpmem_finish_pending_calls = 0;
	fake_xpmem_remove_range_calls = 0;
	fake_xpmem_remove_range_vm = NULL;
	fake_xpmem_remove_range_start = 0;
	fake_xpmem_remove_range_end = 0;
	fake_xpmem_remove_range_ro_freed = 0;
	fake_xpmem_remove_range_rc = 0;
	fake_xpmem_att_ref_calls = 0;
	fake_xpmem_att_deref_calls = 0;
	fake_xpmem_att_ref_id_sum = 0;
	fake_xpmem_att_deref_id_sum = 0;
	fake_xpmem_ap_ref_calls = 0;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_ref_id_sum = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_att_destroyable_calls = 0;
	fake_xpmem_att_destroyable_att = NULL;
	fake_xpmem_clear_range_calls = 0;
	fake_xpmem_clear_range_object = NULL;
	fake_xpmem_clear_range_start = 0;
	fake_xpmem_clear_range_end = 0;
}

static void fake_xpmem_remove_process_range_reset(struct fake_xpmem_vm *vm,
						  struct fake_xpmem_range *range,
						  struct fake_xpmem_range *range2,
						  struct fake_xpmem_range *range3)
{
	memset(vm, 0, sizeof(*vm));
	memset(range, 0, sizeof(*range));
	memset(range2, 0, sizeof(*range2));
	memset(range3, 0, sizeof(*range3));

	range->start = 0x4000;
	range->end = 0x5000;
	range->flag = VR_PROT_WRITE;
	range->private_data = &fake_xpmem_part;
	range2->start = 0x5000;
	range2->end = 0x6000;
	range2->flag = VR_PROT_WRITE;
	range2->private_data = &fake_xpmem_part;
	range3->start = 0x6000;
	range3->end = 0x7000;
	range3->flag = VR_PROT_WRITE;
	range3->private_data = &fake_xpmem_part;

	fake_xpmem_lookup_range_calls = 0;
	fake_xpmem_lookup_range_vm = NULL;
	fake_xpmem_lookup_range_start = 0;
	fake_xpmem_lookup_range_end = 0;
	fake_xpmem_lookup_range_rc = range;
	memset(fake_xpmem_lookup_range_seq, 0,
	       sizeof(fake_xpmem_lookup_range_seq));
	fake_xpmem_lookup_range_seq_len = 0;
	fake_xpmem_next_range_calls = 0;
	fake_xpmem_next_range_vm = NULL;
	fake_xpmem_next_range_arg = NULL;
	fake_xpmem_next_range_rc = NULL;
	memset(fake_xpmem_next_range_seq, 0,
	       sizeof(fake_xpmem_next_range_seq));
	fake_xpmem_next_range_seq_len = 0;
	fake_xpmem_split_range_calls = 0;
	fake_xpmem_split_range_vm = NULL;
	fake_xpmem_split_range_arg = NULL;
	fake_xpmem_split_range_addr = 0;
	fake_xpmem_split_range_addr_sum = 0;
	fake_xpmem_split_range_null_out_calls = 0;
	fake_xpmem_split_range_set_out_calls = 0;
	fake_xpmem_split_range_new_rc = range2;
	fake_xpmem_split_range_rc = 0;
	fake_xpmem_remove_private_range_calls = 0;
	fake_xpmem_remove_private_range_vm = NULL;
	fake_xpmem_remove_private_range_arg = NULL;
	fake_xpmem_free_range_calls = 0;
	fake_xpmem_free_range_vm = NULL;
	fake_xpmem_free_range_arg = NULL;
	fake_xpmem_free_range_rc = 0;
	fake_xpmem_remove_process_range_log_calls = 0;
	fake_xpmem_remove_process_range_log_vm = NULL;
	fake_xpmem_remove_process_range_log_start = 0;
	fake_xpmem_remove_process_range_log_end = 0;
	fake_xpmem_remove_process_range_log_error_sum = 0;
	fake_xpmem_remove_process_range_log_free_sum = 0;
}

static void fake_xpmem_free_process_range_reset(struct fake_xpmem_vm *vm,
						struct fake_xpmem_address_space *asp,
						struct fake_xpmem_range *range,
						struct fake_xpmem_range *range2)
{
	memset(vm, 0, sizeof(*vm));
	memset(asp, 0, sizeof(*asp));
	memset(range, 0, sizeof(*range));
	memset(range2, 0, sizeof(*range2));

	asp->page_table = (void *)0xcafebeefUL;
	vm->address_space = asp;
	vm->page_table_lock = 0x9900;
	vm->vm_range_tree.node = &range->rb_node;
	vm->range_cache[0] = range;
	vm->range_cache[1] = range2;
	vm->range_cache[2] = range;
	range->start = 0x4000;
	range->end = 0x7000;
	range->memobj = &fake_xpmem_part;
	range2->start = 0x8000;
	range2->end = 0x9000;

	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_free_process_pt_clear_calls = 0;
	fake_xpmem_free_process_pt_clear_page_table = NULL;
	fake_xpmem_free_process_pt_clear_vm = NULL;
	fake_xpmem_free_process_pt_clear_start = 0;
	fake_xpmem_free_process_pt_clear_end = 0;
	fake_xpmem_free_process_pt_clear_rc = 0;
	fake_xpmem_free_process_memobj_unref_calls = 0;
	fake_xpmem_free_process_memobj_unref_arg = NULL;
	fake_xpmem_free_process_erase_calls = 0;
	fake_xpmem_free_process_erase_root = NULL;
	fake_xpmem_free_process_erase_node = NULL;
	fake_xpmem_free_process_free_calls = 0;
	fake_xpmem_free_process_free_arg = NULL;
	fake_xpmem_free_process_log_calls = 0;
	fake_xpmem_free_process_log_event_sum = 0;
	fake_xpmem_free_process_log_error_sum = 0;
	fake_xpmem_free_process_log_vm = NULL;
	fake_xpmem_free_process_log_range = NULL;
}

static void fake_xpmem_ioctl_reset(void)
{
	fake_xpmem_ioctl_copy_from_calls = 0;
	fake_xpmem_ioctl_copy_from_src = 0;
	fake_xpmem_ioctl_copy_from_size = 0;
	fake_xpmem_ioctl_copy_from_rc = 0;
	fake_xpmem_ioctl_copy_to_calls = 0;
	fake_xpmem_ioctl_copy_to_dst = 0;
	fake_xpmem_ioctl_copy_to_size = 0;
	fake_xpmem_ioctl_copy_to_rc = 0;
	fake_xpmem_ioctl_make_calls = 0;
	fake_xpmem_ioctl_make_vaddr = 0;
	fake_xpmem_ioctl_make_size = 0;
	fake_xpmem_ioctl_make_permit_type = 0;
	fake_xpmem_ioctl_make_permit_value = NULL;
	fake_xpmem_ioctl_make_out = 0x123456789abcdef0L;
	fake_xpmem_ioctl_make_rc = 0;
	fake_xpmem_ioctl_remove_calls = 0;
	fake_xpmem_ioctl_remove_id = 0;
	fake_xpmem_ioctl_remove_rc = 0;
	fake_xpmem_ioctl_get_calls = 0;
	fake_xpmem_ioctl_get_segid = 0;
	fake_xpmem_ioctl_get_flags = 0;
	fake_xpmem_ioctl_get_permit_type = 0;
	fake_xpmem_ioctl_get_permit_value = NULL;
	fake_xpmem_ioctl_get_out = 0x23456789abcdef01L;
	fake_xpmem_ioctl_get_rc = 0;
	fake_xpmem_ioctl_release_calls = 0;
	fake_xpmem_ioctl_release_id = 0;
	fake_xpmem_ioctl_release_rc = 0;
	fake_xpmem_ioctl_attach_calls = 0;
	fake_xpmem_ioctl_attach_mckfd = NULL;
	fake_xpmem_ioctl_attach_apid = 0;
	fake_xpmem_ioctl_attach_offset = 0;
	fake_xpmem_ioctl_attach_size = 0;
	fake_xpmem_ioctl_attach_vaddr = 0;
	fake_xpmem_ioctl_attach_fd = 0;
	fake_xpmem_ioctl_attach_flags = 0;
	fake_xpmem_ioctl_attach_out = 0x44445000UL;
	fake_xpmem_ioctl_attach_rc = 0;
	fake_xpmem_ioctl_detach_calls = 0;
	fake_xpmem_ioctl_detach_vaddr = 0;
	fake_xpmem_ioctl_detach_rc = 0;
}

static void fake_xpmem_attach_reset(struct fake_xpmem_mckfd *mckfd,
				    struct fake_xpmem_vm *vm,
				    struct fake_xpmem_range *range,
				    struct fake_xpmem_range *range2,
				    struct fake_xpmem_tg *ap_tg,
				    struct fake_xpmem_tg *seg_tg,
				    struct fake_xpmem_seg *seg,
				    struct fake_xpmem_ap *ap,
				    struct fake_xpmem_att *att)
{
	memset(mckfd, 0, sizeof(*mckfd));
	memset(vm, 0, sizeof(*vm));
	memset(range, 0, sizeof(*range));
	memset(range2, 0, sizeof(*range2));
	memset(ap_tg, 0, sizeof(*ap_tg));
	memset(seg_tg, 0, sizeof(*seg_tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0, sizeof(*ap));
	memset(att, 0, sizeof(*att));

	mckfd->fd = 77;
	vm->memory_range_lock = 0x1100;
	range->start = 0x4000;
	range->end = 0x5000;
	range->private_data = NULL;
	range2->start = 0x5000;
	range2->end = 0x6000;
	range2->private_data = NULL;
	ap_tg->tgid = 2007;
	seg_tg->tgid = 1003;
	seg->lock = 0x2200;
	seg->segid = ((long)5 << 32) | seg_tg->tgid;
	seg->vaddr = 0x9000;
	seg->size = 0x9000;
	seg->tg = seg_tg;
	ap->lock = 0x3300;
	ap->apid = ((long)6 << 32) | ap_tg->tgid;
	ap->mode = XPMEM_RDWR;
	ap->seg = seg;
	ap->tg = ap_tg;
	fake_xpmem_list_init(&ap->att_list);
	att->id = 0x909;

	fake_xpmem_tg_ref_by_id_calls = 0;
	fake_xpmem_tg_ref_by_id_value = 0;
	fake_xpmem_tg_ref_by_id_rc = ap_tg;
	fake_xpmem_ap_ref_by_id_calls = 0;
	fake_xpmem_ap_ref_by_id_value = 0;
	fake_xpmem_ap_ref_by_id_parent = NULL;
	fake_xpmem_ap_ref_by_id_rc = ap;
	fake_xpmem_alloc_calls = 0;
	fake_xpmem_alloc_rc = att;
	fake_xpmem_rwlock_init_calls = 0;
	fake_xpmem_rwlock_last_lock = NULL;
	fake_xpmem_list_del_calls = 0;
	fake_xpmem_list_del_entry = NULL;
	fake_xpmem_list_add_tail_calls = 0;
	fake_xpmem_list_add_tail_entry = NULL;
	fake_xpmem_list_add_tail_head = NULL;
	fake_xpmem_att_not_destroyable_calls = 0;
	fake_xpmem_att_not_destroyable_att = NULL;
	fake_xpmem_att_ref_calls = 0;
	fake_xpmem_att_deref_calls = 0;
	fake_xpmem_att_ref_id_sum = 0;
	fake_xpmem_att_deref_id_sum = 0;
	fake_xpmem_att_destroyable_calls = 0;
	fake_xpmem_att_destroyable_att = NULL;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_seg_ref_calls = 0;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_ref_id_sum = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_tg_ref_object_calls = 0;
	fake_xpmem_tg_ref_object_tgid_sum = 0;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_spin_lock_calls = 0;
	fake_xpmem_spin_unlock_calls = 0;
	fake_xpmem_spin_last_lock = NULL;
	fake_xpmem_write_lock_noirq_calls = 0;
	fake_xpmem_write_unlock_noirq_calls = 0;
	fake_xpmem_read_lock_noirq_calls = 0;
	fake_xpmem_read_unlock_noirq_calls = 0;
	fake_xpmem_noirq_last_lock = NULL;
	fake_xpmem_att_write_lock_calls = 0;
	fake_xpmem_att_write_unlock_calls = 0;
	fake_xpmem_att_write_unlock_state_sum = 0;
	fake_xpmem_lookup_range_calls = 0;
	fake_xpmem_lookup_range_vm = NULL;
	fake_xpmem_lookup_range_start = 0;
	fake_xpmem_lookup_range_end = 0;
	fake_xpmem_lookup_range_rc = range;
	memset(fake_xpmem_lookup_range_seq, 0,
	       sizeof(fake_xpmem_lookup_range_seq));
	fake_xpmem_lookup_range_seq_len = 0;
	fake_xpmem_next_range_calls = 0;
	fake_xpmem_next_range_vm = NULL;
	fake_xpmem_next_range_arg = NULL;
	fake_xpmem_next_range_rc = NULL;
	memset(fake_xpmem_next_range_seq, 0,
	       sizeof(fake_xpmem_next_range_seq));
	fake_xpmem_next_range_seq_len = 0;
	fake_xpmem_attach_validate_calls = 0;
	fake_xpmem_attach_validate_ap = NULL;
	fake_xpmem_attach_validate_offset = 0;
	fake_xpmem_attach_validate_size = 0;
	fake_xpmem_attach_validate_mode = 0;
	fake_xpmem_attach_validate_seg_vaddr = 0x9123;
	fake_xpmem_attach_validate_rc = 0;
	fake_xpmem_attach_mmap_calls = 0;
	fake_xpmem_attach_mmap_addr = 0;
	fake_xpmem_attach_mmap_len = 0;
	fake_xpmem_attach_mmap_prot = 0;
	fake_xpmem_attach_mmap_flags = 0;
	fake_xpmem_attach_mmap_fd = 0;
	fake_xpmem_attach_mmap_offset = 0;
	fake_xpmem_attach_mmap_vm_flags = 0;
	fake_xpmem_attach_mmap_private_data = NULL;
	fake_xpmem_attach_mmap_rc = 0x500000;
}

static void fake_xpmem_update_page_table_reset(struct fake_xpmem_vm *vm,
					       struct fake_xpmem_address_space *asp,
					       struct fake_xpmem_range *range,
					       struct fake_xpmem_tg *ap_tg,
					       struct fake_xpmem_tg *seg_tg,
					       struct fake_xpmem_seg *seg,
					       struct fake_xpmem_ap *ap,
					       struct fake_xpmem_att *att,
					       struct fake_xpmem_pte *pte)
{
	memset(vm, 0, sizeof(*vm));
	memset(asp, 0, sizeof(*asp));
	memset(range, 0, sizeof(*range));
	memset(ap_tg, 0, sizeof(*ap_tg));
	memset(seg_tg, 0, sizeof(*seg_tg));
	memset(seg, 0, sizeof(*seg));
	memset(ap, 0, sizeof(*ap));
	memset(att, 0, sizeof(*att));
	memset(pte, 0, sizeof(*pte));

	asp->page_table = (void *)0xabcddcbaUL;
	vm->address_space = asp;
	range->start = 0x4000;
	range->end = 0x7000;
	range->pgshift = 12;
	range->private_data = att;
	ap_tg->tgid = 2007;
	seg_tg->tgid = 1003;
	seg->segid = ((long)5 << 32) | seg_tg->tgid;
	seg->tg = seg_tg;
	ap->apid = ((long)6 << 32) | ap_tg->tgid;
	ap->mode = XPMEM_RDWR;
	ap->tg = ap_tg;
	ap->seg = seg;
	att->id = 0x909;
	att->ap = ap;
	pte->present = 1;

	fake_xpmem_att_ref_calls = 0;
	fake_xpmem_att_deref_calls = 0;
	fake_xpmem_att_ref_id_sum = 0;
	fake_xpmem_att_deref_id_sum = 0;
	fake_xpmem_ap_ref_calls = 0;
	fake_xpmem_ap_deref_calls = 0;
	fake_xpmem_ap_ref_id_sum = 0;
	fake_xpmem_ap_deref_id_sum = 0;
	fake_xpmem_tg_ref_object_calls = 0;
	fake_xpmem_tg_ref_object_tgid_sum = 0;
	fake_xpmem_tg_deref_calls = 0;
	fake_xpmem_tg_deref_tgid_sum = 0;
	fake_xpmem_seg_ref_calls = 0;
	fake_xpmem_seg_deref_calls = 0;
	fake_xpmem_seg_ref_id_sum = 0;
	fake_xpmem_seg_deref_id_sum = 0;
	fake_xpmem_bug_on_calls = 0;
	fake_xpmem_bug_on_condition_sum = 0;
	fake_xpmem_update_fault_calls = 0;
	fake_xpmem_update_fault_vm = NULL;
	fake_xpmem_update_fault_range = NULL;
	fake_xpmem_update_fault_vaddr = 0;
	fake_xpmem_update_fault_vaddr_sum = 0;
	fake_xpmem_update_fault_reason_sum = 0;
	fake_xpmem_update_fault_page_in_sum = 0;
	fake_xpmem_update_fault_rc = 0;
	fake_xpmem_update_log_calls = 0;
	fake_xpmem_update_log_event_sum = 0;
	fake_xpmem_update_log_error_sum = 0;
	fake_xpmem_update_log_vm = NULL;
	fake_xpmem_update_log_range = NULL;
	fake_xpmem_update_log_vaddr_sum = 0;
	fake_xpmem_pt_lookup_pte_calls = 0;
	fake_xpmem_pt_lookup_pte_page_table = NULL;
	fake_xpmem_pt_lookup_pte_vaddr = 0;
	fake_xpmem_pt_lookup_pte_vaddr_sum = 0;
	fake_xpmem_pt_lookup_pte_pgshift = 0;
	fake_xpmem_pt_lookup_pte_pgsize = PAGE_SIZE;
	fake_xpmem_pt_lookup_pte_rc = pte;
	fake_xpmem_pte_present_calls = 0;
}

static void fake_xpmem_fault_reset(struct fake_xpmem_proc *proc,
				   struct fake_xpmem_vm *vm,
				   struct fake_xpmem_address_space *asp,
				   struct fake_xpmem_range *range,
				   struct fake_xpmem_tg *ap_tg,
				   struct fake_xpmem_tg *seg_tg,
				   struct fake_xpmem_seg *seg,
				   struct fake_xpmem_ap *ap,
				   struct fake_xpmem_att *att,
				   struct fake_xpmem_pte *att_pte,
				   struct fake_xpmem_pte *seg_pte)
{
	fake_xpmem_update_page_table_reset(vm, asp, range, ap_tg, seg_tg,
					   seg, ap, att, att_pte);
	memset(proc, 0, sizeof(*proc));
	memset(seg_pte, 0, sizeof(*seg_pte));

	proc->pid = ap_tg->tgid;
	proc->vm = vm;
	vm->proc = proc;
	seg_tg->vm = vm;
	range->flag = VR_PROT_WRITE;
	range->private_data = att;
	att->vaddr = 0x9000;
	att->at_vaddr = range->start;
	att->at_size = range->end - range->start;
	seg_pte->present = 1;
	seg_pte->phys = 0x300000;
	att_pte->present = 0;
	att_pte->phys = 0;

	fake_xpmem_pt_lookup_pte_pgsize = PAGE_SIZE;
	fake_xpmem_vaddr_to_pte_calls = 0;
	fake_xpmem_vaddr_to_pte_vm = NULL;
	fake_xpmem_vaddr_to_pte_vaddr = 0;
	memset(fake_xpmem_vaddr_to_pte_sizes, 0,
	       sizeof(fake_xpmem_vaddr_to_pte_sizes));
	memset(fake_xpmem_vaddr_to_pte_ptes, 0,
	       sizeof(fake_xpmem_vaddr_to_pte_ptes));
	fake_xpmem_vaddr_to_pte_sizes[0] = PAGE_SIZE;
	fake_xpmem_vaddr_to_pte_ptes[0] = seg_pte;
	fake_xpmem_fault_ensure_calls = 0;
	fake_xpmem_fault_ensure_seg = NULL;
	fake_xpmem_fault_ensure_vaddr = 0;
	fake_xpmem_fault_ensure_page_in = 0;
	fake_xpmem_fault_ensure_rc = 0;
	fake_xpmem_pte_phys_calls = 0;
	fake_xpmem_pte_phys_sum = 0;
	fake_xpmem_atomic_dec_calls = 0;
	fake_xpmem_smaller_page_calls = 0;
	fake_xpmem_smaller_page_last_pgsize = 0;
	fake_xpmem_smaller_page_out = PAGE_SIZE;
	fake_xpmem_smaller_page_align_out = 0;
	fake_xpmem_smaller_page_rc = 0;
	fake_xpmem_adjust_page_calls = 0;
	fake_xpmem_adjust_page_table = NULL;
	fake_xpmem_adjust_fault_addr = 0;
	fake_xpmem_adjust_pte = NULL;
	fake_xpmem_adjust_pgsize = 0;
	fake_xpmem_vrflag_calls = 0;
	fake_xpmem_vrflag_flag = 0;
	fake_xpmem_vrflag_reason = 0;
	fake_xpmem_vrflag_rc = 0xa5;
	fake_xpmem_pgsize_contiguous_calls = 0;
	fake_xpmem_pgsize_contiguous_rc = 0;
	fake_xpmem_pt_set_pte_calls = 0;
	fake_xpmem_pt_set_pte_page_table = NULL;
	fake_xpmem_pt_set_pte_pte = NULL;
	fake_xpmem_pt_set_pte_pgsize = 0;
	fake_xpmem_pt_set_pte_phys = 0;
	fake_xpmem_pt_set_pte_attr = 0;
	fake_xpmem_pt_set_pte_rc = 0;
	fake_xpmem_pt_set_range_calls = 0;
	fake_xpmem_pt_set_range_page_table = NULL;
	fake_xpmem_pt_set_range_vm = NULL;
	fake_xpmem_pt_set_range_start = 0;
	fake_xpmem_pt_set_range_end = 0;
	fake_xpmem_pt_set_range_phys = 0;
	fake_xpmem_pt_set_range_attr = 0;
	fake_xpmem_pt_set_range_pgshift = 0;
	fake_xpmem_pt_set_range_vmr = NULL;
	fake_xpmem_pt_set_range_replace = 0;
	fake_xpmem_pt_set_range_rc = 0;
	fake_xpmem_flush_single_calls = 0;
	fake_xpmem_flush_single_vaddr = 0;
	fake_xpmem_fault_log_calls = 0;
	fake_xpmem_fault_log_event_sum = 0;
	fake_xpmem_fault_log_a_sum = 0;
	fake_xpmem_fault_log_b_sum = 0;
	fake_xpmem_fault_log_c_sum = 0;
	fake_xpmem_fault_log_size_sum = 0;
	fake_xpmem_fault_log_error_sum = 0;
}

static void fake_xpmem_pin_reset(struct fake_xpmem_vm *vm,
				 struct fake_xpmem_vm *current_vm,
				 struct fake_xpmem_range *range,
				 struct fake_xpmem_tg *tg,
				 struct fake_xpmem_seg *seg)
{
	memset(vm, 0, sizeof(*vm));
	memset(current_vm, 0, sizeof(*current_vm));
	memset(range, 0, sizeof(*range));
	memset(tg, 0, sizeof(*tg));
	memset(seg, 0, sizeof(*seg));

	vm->memory_range_lock = 0x5511;
	vm->stack_start = 0x7000;
	vm->stack_end = 0x9000;
	range->start = 0x4000;
	range->end = 0x5000;
	tg->tgid = 3210;
	tg->n_pinned = 3;
	tg->group_leader = (void *)0xabc01000UL;
	tg->vm = vm;
	seg->segid = 0x6060;
	seg->flags = 0;
	seg->tg = tg;

	fake_xpmem_write_lock_noirq_calls = 0;
	fake_xpmem_write_unlock_noirq_calls = 0;
	fake_xpmem_read_lock_noirq_calls = 0;
	fake_xpmem_read_unlock_noirq_calls = 0;
	fake_xpmem_noirq_last_lock = NULL;
	fake_xpmem_lookup_range_calls = 0;
	fake_xpmem_lookup_range_vm = NULL;
	fake_xpmem_lookup_range_start = 0;
	fake_xpmem_lookup_range_end = 0;
	fake_xpmem_lookup_range_rc = range;
	memset(fake_xpmem_lookup_range_seq, 0,
	       sizeof(fake_xpmem_lookup_range_seq));
	fake_xpmem_lookup_range_seq_len = 0;
	fake_xpmem_page_fault_vm_calls = 0;
	fake_xpmem_page_fault_vm_vm = NULL;
	fake_xpmem_page_fault_vm_vaddr = 0;
	fake_xpmem_page_fault_vm_reason = 0;
	fake_xpmem_page_fault_vm_rc = 0;
	fake_xpmem_page_fault_range_calls = 0;
	fake_xpmem_page_fault_range_vm = NULL;
	fake_xpmem_page_fault_range_range = NULL;
	fake_xpmem_page_fault_range_vaddr = 0;
	fake_xpmem_page_fault_range_reason = 0;
	fake_xpmem_page_fault_range_rc = 0;
	fake_xpmem_atomic_calls = 0;
	fake_xpmem_pin_page_calls = 0;
	fake_xpmem_pin_page_tg = NULL;
	fake_xpmem_pin_page_thread = NULL;
	fake_xpmem_pin_page_vm = NULL;
	fake_xpmem_pin_page_vaddr = 0;
	fake_xpmem_pin_page_page_in = 0;
	fake_xpmem_pin_page_rc = 0;
}

static void fake_xpmem_pte_reset(struct fake_xpmem_vm *vm,
				 struct fake_xpmem_address_space *asp,
				 struct fake_xpmem_range *range,
				 struct fake_xpmem_tg *tg,
				 struct fake_xpmem_seg *seg,
				 struct fake_xpmem_pte *pte1,
				 struct fake_xpmem_pte *pte2)
{
	memset(vm, 0, sizeof(*vm));
	memset(asp, 0, sizeof(*asp));
	memset(range, 0, sizeof(*range));
	memset(tg, 0, sizeof(*tg));
	memset(seg, 0, sizeof(*seg));
	memset(pte1, 0, sizeof(*pte1));
	memset(pte2, 0, sizeof(*pte2));

	asp->page_table = (void *)0xabcddcbaUL;
	vm->address_space = asp;
	range->start = 0x4000;
	range->end = 0x9000;
	range->pgshift = 12;
	tg->n_pinned = 7;
	seg->tg = tg;
	pte1->present = 1;
	pte2->present = 0;

	fake_xpmem_lookup_range_calls = 0;
	fake_xpmem_lookup_range_vm = NULL;
	fake_xpmem_lookup_range_start = 0;
	fake_xpmem_lookup_range_end = 0;
	fake_xpmem_lookup_range_rc = range;
	memset(fake_xpmem_lookup_range_seq, 0,
	       sizeof(fake_xpmem_lookup_range_seq));
	fake_xpmem_lookup_range_seq_len = 0;
	fake_xpmem_pt_lookup_pte_calls = 0;
	fake_xpmem_pt_lookup_pte_page_table = NULL;
	fake_xpmem_pt_lookup_pte_vaddr = 0;
	fake_xpmem_pt_lookup_pte_vaddr_sum = 0;
	fake_xpmem_pt_lookup_pte_pgshift = 0;
	fake_xpmem_pt_lookup_pte_pgsize = 0x2000;
	fake_xpmem_pt_lookup_pte_rc = pte1;
	fake_xpmem_vaddr_to_pte_calls = 0;
	fake_xpmem_vaddr_to_pte_vm = NULL;
	fake_xpmem_vaddr_to_pte_vaddr = 0;
	memset(fake_xpmem_vaddr_to_pte_sizes, 0,
	       sizeof(fake_xpmem_vaddr_to_pte_sizes));
	memset(fake_xpmem_vaddr_to_pte_ptes, 0,
	       sizeof(fake_xpmem_vaddr_to_pte_ptes));
	fake_xpmem_pte_present_calls = 0;
	fake_xpmem_atomic_sub_calls = 0;
	fake_xpmem_atomic_sub_value = 0;
	fake_xpmem_atomic_sub_counter = NULL;
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static void require_line(int condition, int line)
{
	if (!condition) {
		fprintf(stderr, "xpmem helper equivalence assertion failed at line %d\n",
			line);
		exit(1);
	}
}

#define require(condition) require_line((condition), __LINE__)

int main(void)
{
	static const int permit_types[] = { 0, XPMEM_PERMIT_MODE, 2 };
	static const unsigned long permit_values[] = { 0, 0600, 0666, 0777, 01000 };
	static const size_t sizes[] = { 0, 1, 4095, 4096, 8192, ULONG_MAX };
	static const unsigned long addrs[] = {
		0, 1, 4095, 4096, 0x10000UL, ULONG_MAX - 1,
	};
	static const long segids[] = { LONG_MIN, -1, 0, 1, LONG_MAX };
	static const int flags[] = {
		0, XPMEM_RDONLY, XPMEM_RDWR,
		XPMEM_RDONLY | XPMEM_RDWR, 4,
	};
	static const int bools[] = { 0, 1 };
	static const int ids[] = { 0, 1, 1000, 1001 };
	static const int uniqs[] = {
		-1, 0, 1, 7, 8, INT_MAX >> 1, (INT_MAX >> 1) + 1, INT_MAX,
	};
	static const unsigned long modes[] = {
		0, 0001, 0002, 0004, 0020, 0040, 0200, 0400, 0600, 0640, 0666,
	};
	static const short perm_flags[] = { XPMEM_PERM_IRUSR, XPMEM_PERM_IWUSR };
	static const long offsets[] = { LONG_MIN, -1, 0, 1, 4095, 4096, LONG_MAX };
	static const unsigned long seg_vaddrs[] = {
		0, 0x10000UL, 0x18000UL, ULONG_MAX - 0xfffUL,
	};
	static const int destroy_flags[] = {
		0, XPMEM_FLAG_DESTROYING, 0x00080,
		XPMEM_FLAG_DESTROYING | 0x00080, 0x00200,
	};
	static const int error_values[] = { -22, -14, -2, -1, 0, 1 };
	static const int ref_counts[] = { -2, -1, 0, 1, 2, 3 };
	static const unsigned long range_starts[] = {
		0, 1, 4096, 8192, ULONG_MAX,
	};
	unsigned long digest = 0x78706d656d527573UL;

	for (unsigned int id = 0; id < sizeof(segids) / sizeof(segids[0]); id++) {
		mix_signed(&digest, xpmem_id_to_tgid_result(segids[id]));
		mix_signed(&digest, xpmem_ap_hashtable_index_result(segids[id]));
		mix_signed(&digest, xpmem_positive_id_result(segids[id]));
		if (segids[id] > 0) {
			require(xpmem_segid_to_tgid(segids[id]) ==
				xpmem_id_to_tgid_result(segids[id]));
			require(xpmem_apid_to_tgid(segids[id]) ==
				xpmem_id_to_tgid_result(segids[id]));
			require(xpmem_ap_hashtable_index(segids[id]) ==
				xpmem_ap_hashtable_index_result(segids[id]));
			mix_signed(&digest, xpmem_segid_to_tgid(segids[id]));
			mix_signed(&digest, xpmem_apid_to_tgid(segids[id]));
			mix_signed(&digest,
				xpmem_ap_hashtable_index(segids[id]));
		}
	}

	for (unsigned int t = 0; t < sizeof(ids) / sizeof(ids[0]); t++) {
		require(xpmem_tg_hashtable_index(ids[t]) ==
			xpmem_tg_hashtable_index_result(ids[t]));
		mix_signed(&digest, xpmem_tg_hashtable_index_result(ids[t]));
		mix_signed(&digest, xpmem_tg_hashtable_index(ids[t]));
		for (unsigned int u = 0; u < sizeof(uniqs) / sizeof(uniqs[0]); u++) {
			long id = 0x13579bdf2468ace0L;
			int ret = xpmem_make_id_result(ids[t], uniqs[u], &id);

			mix_signed(&digest, ret);
			mix_signed(&digest, id);
			if (!ret && id > 0) {
				require(xpmem_segid_to_tgid(id) == ids[t]);
				require(xpmem_apid_to_tgid(id) == ids[t]);
				require(xpmem_ap_hashtable_index(id) ==
					xpmem_ap_hashtable_index_result(id));
				mix_signed(&digest, xpmem_id_to_tgid_result(id));
				mix_signed(&digest, xpmem_segid_to_tgid(id));
				mix_signed(&digest, xpmem_apid_to_tgid(id));
				mix_signed(&digest, xpmem_ap_hashtable_index_result(id));
				mix_signed(&digest, xpmem_ap_hashtable_index(id));
			}
		}
	}

	{
		struct fake_xpmem_tg tg = { .tgid = 101 };
		struct fake_xpmem_seg seg = { .segid = 202 };
		struct fake_xpmem_ap ap = { .apid = 303 };
		struct fake_xpmem_att att = { .id = 404 };

		fake_xpmem_destroyable_log_calls = 0;
		fake_xpmem_destroyable_log_event_sum = 0;
		fake_xpmem_tg_deref_calls = 0;
		fake_xpmem_tg_deref_tgid_sum = 0;
		fake_xpmem_seg_deref_calls = 0;
		fake_xpmem_seg_deref_id_sum = 0;
		fake_xpmem_ap_deref_calls = 0;
		fake_xpmem_ap_deref_id_sum = 0;
		fake_xpmem_att_deref_calls = 0;
		fake_xpmem_att_deref_id_sum = 0;

		require(xpmem_destroyable_wrapper_result(&tg,
			fake_xpmem_destroyable_log_cb,
			fake_xpmem_tg_deref_cb) == 0);
		require(xpmem_destroyable_wrapper_result(&seg,
			fake_xpmem_destroyable_log_cb,
			fake_xpmem_seg_deref_cb) == 0);
		require(xpmem_destroyable_wrapper_result(&ap,
			fake_xpmem_destroyable_log_cb,
			fake_xpmem_ap_deref_cb) == 0);
		require(xpmem_destroyable_wrapper_result(&att,
			fake_xpmem_destroyable_log_cb,
			fake_xpmem_att_deref_cb) == 0);
		require(fake_xpmem_destroyable_log_calls == 8);
		require(fake_xpmem_destroyable_log_event_sum == 12);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_tg_deref_tgid_sum == tg.tgid);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_seg_deref_id_sum == seg.segid);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_ap_deref_id_sum == ap.apid);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_att_deref_id_sum == att.id);
		require(xpmem_destroyable_wrapper_result(&tg,
			fake_xpmem_destroyable_log_cb, NULL) == -22);
		require(fake_xpmem_destroyable_log_calls == 8);

		mix_signed(&digest, fake_xpmem_destroyable_log_calls);
		mix_signed(&digest, fake_xpmem_destroyable_log_event_sum);
		mix_signed(&digest, fake_xpmem_tg_deref_tgid_sum);
		mix_signed(&digest, fake_xpmem_seg_deref_id_sum);
		mix_signed(&digest, fake_xpmem_ap_deref_id_sum);
		mix_signed(&digest, fake_xpmem_att_deref_id_sum);
	}

	{
		struct fake_xpmem_tg tg = { .tgid = 11, .refcnt = 5 };
		struct fake_xpmem_seg seg = { .segid = 22, .refcnt = 6 };
		struct fake_xpmem_ap ap = { .apid = 33, .refcnt = 7 };
		struct fake_xpmem_att att = { .id = 44, .refcnt = 8 };

		fake_xpmem_refcnt_ptr_calls = 0;
		fake_xpmem_refcnt_ptr_kind_sum = 0;
		fake_xpmem_refcnt_log_calls = 0;
		fake_xpmem_refcnt_log_kind_sum = 0;
		fake_xpmem_refcnt_log_value_sum = 0;
		fake_xpmem_atomic_set_calls = 0;
		fake_xpmem_atomic_set_value_sum = 0;
		fake_xpmem_atomic_read_calls = 0;

		require(xpmem_not_destroyable_wrapper_result(&tg,
			XPMEM_REF_KIND_TG, fake_xpmem_refcnt_ptr_cb,
			fake_xpmem_atomic_set, fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == 0);
		require(xpmem_not_destroyable_wrapper_result(&seg,
			XPMEM_REF_KIND_SEG, fake_xpmem_refcnt_ptr_cb,
			fake_xpmem_atomic_set, fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == 0);
		require(xpmem_not_destroyable_wrapper_result(&ap,
			XPMEM_REF_KIND_AP, fake_xpmem_refcnt_ptr_cb,
			fake_xpmem_atomic_set, fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == 0);
		require(xpmem_not_destroyable_wrapper_result(&att,
			XPMEM_REF_KIND_ATT, fake_xpmem_refcnt_ptr_cb,
			fake_xpmem_atomic_set, fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == 0);
		require(tg.refcnt == 1 && seg.refcnt == 1);
		require(ap.refcnt == 1 && att.refcnt == 1);
		require(fake_xpmem_refcnt_ptr_calls == 4);
		require(fake_xpmem_refcnt_ptr_kind_sum == 10);
		require(fake_xpmem_atomic_set_calls == 4);
		require(fake_xpmem_atomic_set_value_sum == 4);
		require(fake_xpmem_atomic_read_calls == 4);
		require(fake_xpmem_refcnt_log_calls == 4);
		require(fake_xpmem_refcnt_log_kind_sum == 10);
		require(fake_xpmem_refcnt_log_value_sum == 4);
		require(xpmem_not_destroyable_wrapper_result(NULL,
			XPMEM_REF_KIND_TG, fake_xpmem_refcnt_ptr_cb,
			fake_xpmem_atomic_set, fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == -22);
		require(xpmem_not_destroyable_wrapper_result(&tg, 99,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_set,
			fake_xpmem_atomic_read,
			fake_xpmem_refcnt_log_cb) == -22);

		tg.refcnt = 1;
		seg.refcnt = 2;
		ap.refcnt = 3;
		att.refcnt = 4;
		fake_xpmem_refcnt_ptr_calls = 0;
		fake_xpmem_refcnt_ptr_kind_sum = 0;
		fake_xpmem_atomic_read_calls = 0;
		fake_xpmem_atomic_calls = 0;
		fake_xpmem_bug_on_calls = 0;
		fake_xpmem_bug_on_condition_sum = 0;

		require(xpmem_ref_wrapper_result(&tg, XPMEM_REF_KIND_TG,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == 0);
		require(xpmem_ref_wrapper_result(&seg, XPMEM_REF_KIND_SEG,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == 0);
		require(xpmem_ref_wrapper_result(&ap, XPMEM_REF_KIND_AP,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == 0);
		require(xpmem_ref_wrapper_result(&att, XPMEM_REF_KIND_ATT,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == 0);
		require(tg.refcnt == 2 && seg.refcnt == 3);
		require(ap.refcnt == 4 && att.refcnt == 5);
		require(fake_xpmem_refcnt_ptr_calls == 4);
		require(fake_xpmem_refcnt_ptr_kind_sum == 10);
		require(fake_xpmem_atomic_read_calls == 4);
		require(fake_xpmem_atomic_calls == 4);
		require(fake_xpmem_bug_on_calls == 4);
		require(fake_xpmem_bug_on_condition_sum == 0);

		tg.refcnt = 0;
		require(xpmem_ref_wrapper_result(&tg, XPMEM_REF_KIND_TG,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == 0);
		require(tg.refcnt == 1);
		require(fake_xpmem_bug_on_condition_sum == 1);
		require(xpmem_ref_wrapper_result(&tg, 99,
			fake_xpmem_refcnt_ptr_cb, fake_xpmem_atomic_read,
			fake_xpmem_atomic_inc, fake_xpmem_bug_on) == -22);

		mix_signed(&digest, fake_xpmem_refcnt_ptr_kind_sum);
		mix_signed(&digest, fake_xpmem_refcnt_log_kind_sum);
		mix_signed(&digest, fake_xpmem_refcnt_log_value_sum);
		mix_signed(&digest, tg.refcnt + seg.refcnt + ap.refcnt +
			att.refcnt);
		mix_signed(&digest, fake_xpmem_bug_on_condition_sum);
	}

	for (unsigned int cp = 0; cp < sizeof(ids) / sizeof(ids[0]); cp++) {
		for (unsigned int tg = 0; tg < sizeof(ids) / sizeof(ids[0]); tg++)
			mix_signed(&digest, xpmem_owner_policy_result(ids[cp],
				ids[tg]));
	}

	for (unsigned int t = 0; t < sizeof(permit_types) / sizeof(permit_types[0]); t++) {
		for (unsigned int v = 0; v < sizeof(permit_values) / sizeof(permit_values[0]); v++) {
			for (unsigned int s = 0; s < sizeof(sizes) / sizeof(sizes[0]); s++)
				mix_signed(&digest, xpmem_make_initial_policy_result(
					permit_types[t], permit_values[v], sizes[s]));
		}
	}

	for (unsigned int a = 0; a < sizeof(addrs) / sizeof(addrs[0]); a++) {
		for (unsigned int s = 0; s < sizeof(sizes) / sizeof(sizes[0]); s++)
			mix_signed(&digest, xpmem_make_alignment_result(addrs[a],
				sizes[s]));
	}

	for (unsigned int id = 0; id < sizeof(segids) / sizeof(segids[0]); id++) {
		for (unsigned int f = 0; f < sizeof(flags) / sizeof(flags[0]); f++) {
			for (unsigned int t = 0; t < sizeof(permit_types) / sizeof(permit_types[0]); t++) {
				for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++)
					mix_signed(&digest, xpmem_get_policy_result(
						segids[id], flags[f], permit_types[t],
						bools[h]));
			}
		}
	}

	for (unsigned int u = 0; u < sizeof(ids) / sizeof(ids[0]); u++) {
		for (unsigned int g = 0; g < sizeof(ids) / sizeof(ids[0]); g++) {
			for (unsigned int m = 0; m < sizeof(modes) / sizeof(modes[0]); m++) {
				for (unsigned int p = 0; p < sizeof(perm_flags) / sizeof(perm_flags[0]); p++) {
					for (unsigned int cu = 0; cu < sizeof(ids) / sizeof(ids[0]); cu++) {
						for (unsigned int cg = 0; cg < sizeof(ids) / sizeof(ids[0]); cg++)
							mix_signed(&digest, xpmem_perms_result(
								ids[u], ids[g], modes[m],
								perm_flags[p], ids[cu], ids[cg]));
					}
				}
			}
		}
	}

	for (unsigned int f = 0; f < sizeof(flags) / sizeof(flags[0]); f++) {
		for (unsigned int m = 0; m < sizeof(modes) / sizeof(modes[0]); m++) {
			for (unsigned int cu = 0; cu < sizeof(ids) / sizeof(ids[0]); cu++) {
				for (unsigned int cg = 0; cg < sizeof(ids) / sizeof(ids[0]); cg++)
					mix_signed(&digest, xpmem_check_permit_mode_result(
						flags[f], ids[1], ids[2], modes[m],
						ids[cu], ids[cg]));
			}
		}
	}

	for (unsigned int id = 0; id < sizeof(segids) / sizeof(segids[0]); id++) {
		for (unsigned int o = 0; o < sizeof(offsets) / sizeof(offsets[0]); o++) {
			for (unsigned int a = 0; a < sizeof(addrs) / sizeof(addrs[0]); a++) {
				for (unsigned int s = 0; s < sizeof(sizes) / sizeof(sizes[0]); s++) {
					for (unsigned int f = 0; f < sizeof(bools) / sizeof(bools[0]); f++) {
						size_t adjusted = 0x12345678abcdef00UL;
						mix_signed(&digest, xpmem_attach_initial_policy_result(
							segids[id], offsets[o], addrs[a],
							sizes[s], bools[f], &adjusted));
						mix(&digest, adjusted);
					}
				}
			}
		}
	}

	for (unsigned int cp = 0; cp < sizeof(ids) / sizeof(ids[0]); cp++) {
		for (unsigned int tg = 0; tg < sizeof(ids) / sizeof(ids[0]); tg++) {
			for (unsigned int apm = 0; apm < sizeof(flags) / sizeof(flags[0]); apm++) {
				for (unsigned int sv = 0; sv < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); sv++) {
					for (unsigned int ss = 0; ss < sizeof(sizes) / sizeof(sizes[0]); ss++) {
						for (unsigned int o = 0; o < sizeof(offsets) / sizeof(offsets[0]); o++) {
							for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
								unsigned long vaddr = 0xdeadbeefUL;
								mix_signed(&digest, xpmem_validate_access_result(
									ids[cp], ids[tg], flags[apm],
									seg_vaddrs[sv], sizes[ss],
									offsets[o], sizes[sz], XPMEM_RDWR,
									&vaddr));
								mix(&digest, vaddr);
							}
						}
					}
				}
			}
		}
	}

	for (unsigned int n = 0; n < sizeof(ref_counts) / sizeof(ref_counts[0]); n++) {
		for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++) {
			int flush_objects = 0x1234;
			int exit_partition = 0x5678;

			mix_signed(&digest, xpmem_close_decision_result(
				ref_counts[n], bools[h], &flush_objects,
				&exit_partition));
			mix_signed(&digest, flush_objects);
			mix_signed(&digest, exit_partition);
			mix_signed(&digest, xpmem_ref_drop_should_free_result(
				ref_counts[n]));
		}
	}

	for (unsigned int fl = 0; fl < sizeof(destroy_flags) / sizeof(destroy_flags[0]); fl++) {
		mix_signed(&digest, xpmem_is_destroying_result(destroy_flags[fl]));
		for (unsigned int rd = 0; rd < sizeof(bools) / sizeof(bools[0]); rd++)
			mix_signed(&digest, xpmem_destroying_state_result(
				destroy_flags[fl], bools[rd]));
		{
			int new_flags = 0x2468;

			mix_signed(&digest, xpmem_begin_destroy_result(
				destroy_flags[fl], &new_flags));
			mix_signed(&digest, new_flags);
			mix_signed(&digest, xpmem_finish_destroy_result(
				destroy_flags[fl]));
		}
		for (unsigned int e = 0; e < sizeof(error_values) / sizeof(error_values[0]); e++)
			mix_signed(&digest, xpmem_destroying_error_result(
				destroy_flags[fl], error_values[e]));
		for (unsigned int tg = 0; tg < sizeof(destroy_flags) / sizeof(destroy_flags[0]); tg++)
			mix_signed(&digest, xpmem_attach_destroying_result(
				destroy_flags[fl], destroy_flags[tg]));
		for (unsigned int tg = 0; tg < sizeof(destroy_flags) / sizeof(destroy_flags[0]); tg++) {
			for (unsigned int e = 0; e < sizeof(error_values) / sizeof(error_values[0]); e++)
				mix_signed(&digest, xpmem_two_destroying_error_result(
					destroy_flags[fl], destroy_flags[tg],
					error_values[e]));
			for (unsigned int att = 0; att < sizeof(destroy_flags) / sizeof(destroy_flags[0]); att++) {
				for (unsigned int e = 0; e < sizeof(error_values) / sizeof(error_values[0]); e++)
					mix_signed(&digest, xpmem_three_destroying_error_result(
						destroy_flags[fl], destroy_flags[tg],
						destroy_flags[att], error_values[e]));
			}
		}
	}

	for (unsigned int c = 0; c < sizeof(segids) / sizeof(segids[0]); c++) {
		for (unsigned int r = 0; r < sizeof(segids) / sizeof(segids[0]); r++) {
			for (unsigned int fl = 0; fl < sizeof(destroy_flags) / sizeof(destroy_flags[0]); fl++) {
				for (unsigned int rd = 0; rd < sizeof(bools) / sizeof(bools[0]); rd++) {
					for (unsigned int stop = 0; stop < sizeof(bools) / sizeof(bools[0]); stop++)
						mix_signed(&digest,
							xpmem_object_lookup_decision_result(
								segids[c], segids[r],
								destroy_flags[fl],
								bools[rd], bools[stop]));
				}
			}
		}
	}

	for (unsigned int hr = 0; hr < sizeof(bools) / sizeof(bools[0]); hr++) {
		for (unsigned int rs = 0; rs < sizeof(range_starts) / sizeof(range_starts[0]); rs++) {
			for (unsigned int a = 0; a < sizeof(addrs) / sizeof(addrs[0]); a++) {
				for (unsigned int hp = 0; hp < sizeof(bools) / sizeof(bools[0]); hp++)
					mix_signed(&digest, xpmem_detach_lookup_result(
						bools[hr], range_starts[rs],
						addrs[a], bools[hp]));
			}
		}
	}

	for (unsigned int cp = 0; cp < sizeof(ids) / sizeof(ids[0]); cp++) {
		for (unsigned int tg = 0; tg < sizeof(ids) / sizeof(ids[0]); tg++) {
			for (unsigned int rv = 0; rv < sizeof(addrs) / sizeof(addrs[0]); rv++) {
				for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
					for (unsigned int sv = 0; sv < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); sv++)
						mix_signed(&digest, xpmem_attach_overlap_result(
							ids[cp], ids[tg], addrs[rv],
							sizes[sz], seg_vaddrs[sv]));
				}
			}
		}
	}

	for (unsigned int rs = 0; rs < sizeof(range_starts) / sizeof(range_starts[0]); rs++) {
		for (unsigned int re = 0; re < sizeof(range_starts) / sizeof(range_starts[0]); re++) {
			for (unsigned int st = 0; st < sizeof(range_starts) / sizeof(range_starts[0]); st++) {
				for (unsigned int en = 0; en < sizeof(range_starts) / sizeof(range_starts[0]); en++) {
					int split_start = 0x1234;
					int split_end = 0x1234;
					int ro_freed = 0x1234;
					int remove_private = 0x1234;

					mix_signed(&digest, xpmem_remove_range_step_result(
						range_starts[rs], range_starts[re],
						range_starts[st], range_starts[en],
						(en & 1) ? VR_PROT_WRITE : 0,
						en & 1, &split_start, &split_end,
						&ro_freed, &remove_private));
					mix_signed(&digest, split_start);
					mix_signed(&digest, split_end);
					mix_signed(&digest, ro_freed);
					mix_signed(&digest, remove_private);
				}
			}
		}
	}

	for (unsigned int vs = 0; vs < sizeof(range_starts) / sizeof(range_starts[0]); vs++) {
		for (unsigned int ve = 0; ve < sizeof(range_starts) / sizeof(range_starts[0]); ve++) {
			for (unsigned int av = 0; av < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); av++) {
				for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
					unsigned long remaining = 0x1111;
					unsigned long middle = 0x2222;
					int full = 0x3333;
					int needs_middle = 0x4444;

					mix_signed(&digest,
						xpmem_remove_memory_range_action_result(
							range_starts[vs], range_starts[ve],
							seg_vaddrs[av], sizes[sz],
							&remaining, &middle, &full,
							&needs_middle));
					mix(&digest, remaining);
					mix(&digest, middle);
					mix_signed(&digest, full);
					mix_signed(&digest, needs_middle);
				}
			}
		}
	}

	for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++) {
		for (unsigned int rs = 0; rs < sizeof(range_starts) / sizeof(range_starts[0]); rs++) {
			for (unsigned int v = 0; v < sizeof(addrs) / sizeof(addrs[0]); v++) {
				for (unsigned int m = 0; m < sizeof(bools) / sizeof(bools[0]); m++)
					mix_signed(&digest, xpmem_range_private_invalid_result(
						bools[h], range_starts[rs], addrs[v],
						bools[m]));
			}
		}
	}

	for (unsigned int fl = 0; fl < sizeof(destroy_flags) / sizeof(destroy_flags[0]); fl++) {
		for (unsigned int av = 0; av < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); av++) {
			for (unsigned int at = 0; at < sizeof(addrs) / sizeof(addrs[0]); at++) {
				for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
					for (unsigned int st = 0; st < sizeof(addrs) / sizeof(addrs[0]); st++) {
						unsigned long unpin_at = 0xaaaa;
						unsigned long invalidate_len = 0xbbbb;
						int clear_valid = 0xcccc;

						mix_signed(&digest, xpmem_clear_pte_range_result(
							destroy_flags[fl], seg_vaddrs[av],
							addrs[at], sizes[sz], addrs[st],
							addrs[(st + 1) % (sizeof(addrs) / sizeof(addrs[0]))],
							&unpin_at, &invalidate_len,
							&clear_valid));
						mix(&digest, unpin_at);
						mix(&digest, invalidate_len);
						mix_signed(&digest, clear_valid);

						unpin_at = 0xaaaa;
						invalidate_len = 0xbbbb;
						clear_valid = 0xcccc;
						mix_signed(&digest, xpmem_clear_pte_range_result(
							destroy_flags[fl] | XPMEM_FLAG_VALIDPTEs,
							seg_vaddrs[av], addrs[at], sizes[sz],
							addrs[st],
							addrs[(st + 1) % (sizeof(addrs) / sizeof(addrs[0]))],
							&unpin_at, &invalidate_len,
							&clear_valid));
						mix(&digest, unpin_at);
						mix(&digest, invalidate_len);
						mix_signed(&digest, clear_valid);
					}
				}
			}
		}
	}

	for (unsigned int v = 0; v < sizeof(addrs) / sizeof(addrs[0]); v++) {
		for (unsigned int at = 0; at < sizeof(addrs) / sizeof(addrs[0]); at++) {
			for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
				for (unsigned int av = 0; av < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); av++) {
					unsigned long seg_vaddr = 0xfeedfaceUL;

					mix_signed(&digest, xpmem_fault_vaddr_result(
						addrs[v], addrs[at], sizes[sz],
						seg_vaddrs[av], &seg_vaddr));
					mix(&digest, seg_vaddr);
				}
			}
		}
	}

	for (unsigned int sv = 0; sv < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); sv++) {
		for (unsigned int base = 0; base < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); base++) {
			for (unsigned int sz = 0; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
				unsigned long seg_phys = 0x12345678UL;
				size_t seg_pgsize = 0x1234;

				mix_signed(&digest, xpmem_straight_phys_result(
					seg_vaddrs[sv], seg_vaddrs[base],
					sizes[sz], 0x40000000UL, &seg_phys,
					&seg_pgsize));
				mix(&digest, seg_phys);
				mix(&digest, seg_pgsize);
			}
		}
	}

	for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++) {
		for (unsigned int empty = 0; empty < sizeof(bools) / sizeof(bools[0]); empty++) {
			for (unsigned int page_in = 0; page_in < sizeof(bools) / sizeof(bools[0]); page_in++)
				mix_signed(&digest, xpmem_remote_pte_missing_result(
					bools[h], bools[empty], bools[page_in]));
		}
	}

	for (unsigned int phys = 0; phys < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); phys++) {
		for (unsigned int sz = 1; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
			for (unsigned int sv = 0; sv < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); sv++)
				mix(&digest, xpmem_seg_phys_plus_off_result(
					seg_vaddrs[phys], sizes[sz], seg_vaddrs[sv]));
		}
	}

	for (unsigned int pg = 0; pg < sizeof(addrs) / sizeof(addrs[0]); pg++) {
		for (unsigned int sz = 1; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
			for (unsigned int st = 0; st < sizeof(range_starts) / sizeof(range_starts[0]); st++) {
				for (unsigned int en = 0; en < sizeof(range_starts) / sizeof(range_starts[0]); en++)
					mix_signed(&digest, xpmem_att_page_fits_result(
						addrs[pg], sizes[sz], range_starts[st],
						range_starts[en], sizes[sz]));
			}
		}
	}

	for (unsigned int a = 0; a < sizeof(addrs) / sizeof(addrs[0]); a++) {
		for (unsigned int b = 0; b < sizeof(seg_vaddrs) / sizeof(seg_vaddrs[0]); b++)
			mix_signed(&digest, xpmem_pte_mismatch_result(
				addrs[a], seg_vaddrs[b]));
	}

	for (unsigned int v = 0; v < sizeof(addrs) / sizeof(addrs[0]); v++) {
		for (unsigned int sz = 1; sz < sizeof(sizes) / sizeof(sizes[0]); sz++) {
			for (unsigned int h = 0; h < sizeof(bools) / sizeof(bools[0]); h++) {
				unsigned long next_vaddr = 0x1234;
				int unpinned = 0x5678;

				mix_signed(&digest, xpmem_unpin_step_result(
					addrs[v], sizes[sz], bools[h],
					&next_vaddr, &unpinned));
				mix(&digest, next_vaddr);
				mix_signed(&digest, unpinned);
			}
		}
	}

	{
		static const struct fake_xpmem_open_offsets open_offsets = {
			.proc_mckfd_lock_offset =
				offsetof(struct fake_xpmem_proc, mckfd_lock),
			.proc_mckfd_offset =
				offsetof(struct fake_xpmem_proc, mckfd),
			.part_n_opened_offset =
				offsetof(struct fake_xpmem_part, n_opened),
			.mckfd_size = sizeof(struct fake_xpmem_mckfd),
			.mckfd_next_offset =
				offsetof(struct fake_xpmem_mckfd, next),
			.mckfd_fd_offset =
				offsetof(struct fake_xpmem_mckfd, fd),
			.mckfd_sig_no_offset =
				offsetof(struct fake_xpmem_mckfd, sig_no),
			.mckfd_data_offset =
				offsetof(struct fake_xpmem_mckfd, data),
			.mckfd_ioctl_cb_offset =
				offsetof(struct fake_xpmem_mckfd, ioctl_cb),
			.mckfd_close_cb_offset =
				offsetof(struct fake_xpmem_mckfd, close_cb),
			.mckfd_dup_cb_offset =
				offsetof(struct fake_xpmem_mckfd, dup_cb),
		};
		static const struct fake_xpmem_close_offsets close_offsets = {
			.part_n_opened_offset =
				offsetof(struct fake_xpmem_part, n_opened),
			.mckfd_fd_offset =
				offsetof(struct fake_xpmem_mckfd, fd),
			.mckfd_data_offset =
				offsetof(struct fake_xpmem_mckfd, data),
		};
		static const struct fake_xpmem_partition_offsets
		partition_offsets = {
			.part_size = sizeof(struct fake_xpmem_part),
			.part_n_opened_offset =
				offsetof(struct fake_xpmem_part, n_opened),
			.part_tg_hashtable_offset =
				offsetof(struct fake_xpmem_part, tg_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
		};
		static const struct fake_xpmem_open_tg_offsets
		open_tg_offsets = {
			.proc_pid_offset =
				offsetof(struct fake_xpmem_proc, pid),
			.proc_ruid_offset =
				offsetof(struct fake_xpmem_proc, ruid),
			.proc_rgid_offset =
				offsetof(struct fake_xpmem_proc, rgid),
			.tg_size = sizeof(struct fake_xpmem_tg),
			.tg_lock_offset =
				offsetof(struct fake_xpmem_tg, lock),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_uid_offset =
				offsetof(struct fake_xpmem_tg, uid),
			.tg_gid_offset =
				offsetof(struct fake_xpmem_tg, gid),
			.tg_uniq_segid_offset =
				offsetof(struct fake_xpmem_tg, uniq_segid),
			.tg_uniq_apid_offset =
				offsetof(struct fake_xpmem_tg, uniq_apid),
			.tg_seg_list_lock_offset =
				offsetof(struct fake_xpmem_tg, seg_list_lock),
			.tg_seg_list_offset =
				offsetof(struct fake_xpmem_tg, seg_list),
			.tg_n_pinned_offset =
				offsetof(struct fake_xpmem_tg, n_pinned),
			.tg_tg_hashlist_offset =
				offsetof(struct fake_xpmem_tg, tg_hashlist),
			.tg_group_leader_offset =
				offsetof(struct fake_xpmem_tg, group_leader),
			.tg_vm_offset =
				offsetof(struct fake_xpmem_tg, vm),
			.tg_ap_hashtable_offset =
				offsetof(struct fake_xpmem_tg, ap_hashtable),
			.part_tg_hashtable_offset =
				offsetof(struct fake_xpmem_part, tg_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
		};
		static const struct fake_xpmem_flush_offsets flush_offsets = {
			.part_tg_hashtable_offset =
				offsetof(struct fake_xpmem_part, tg_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
			.mckfd_data_offset =
				offsetof(struct fake_xpmem_mckfd, data),
			.proc_pid_offset =
				offsetof(struct fake_xpmem_proc, pid),
			.tg_lock_offset =
				offsetof(struct fake_xpmem_tg, lock),
			.tg_flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
			.tg_hashlist_offset =
				offsetof(struct fake_xpmem_tg, tg_hashlist),
			.tg_vm_offset =
				offsetof(struct fake_xpmem_tg, vm),
		};
		static const struct fake_xpmem_remove_seg_offsets
		remove_seg_offsets = {
			.tg_seg_list_lock_offset =
				offsetof(struct fake_xpmem_tg, seg_list_lock),
			.seg_lock_offset =
				offsetof(struct fake_xpmem_seg, lock),
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_list_offset =
				offsetof(struct fake_xpmem_seg, seg_list),
		};
		static const struct fake_xpmem_remove_segs_offsets
		remove_segs_offsets = {
			.tg_seg_list_lock_offset =
				offsetof(struct fake_xpmem_tg, seg_list_lock),
			.tg_seg_list_offset =
				offsetof(struct fake_xpmem_tg, seg_list),
			.seg_list_offset =
				offsetof(struct fake_xpmem_seg, seg_list),
		};
		static const struct fake_xpmem_release_ap_offsets
		release_ap_offsets = {
			.tg_ap_hashtable_offset =
				offsetof(struct fake_xpmem_tg, ap_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.ap_lock_offset = offsetof(struct fake_xpmem_ap, lock),
			.ap_apid_offset = offsetof(struct fake_xpmem_ap, apid),
			.ap_flags_offset = offsetof(struct fake_xpmem_ap, flags),
			.ap_seg_offset = offsetof(struct fake_xpmem_ap, seg),
			.ap_att_list_offset =
				offsetof(struct fake_xpmem_ap, att_list),
			.ap_ap_list_offset =
				offsetof(struct fake_xpmem_ap, ap_list),
			.ap_hashlist_offset =
				offsetof(struct fake_xpmem_ap, ap_hashlist),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
			.seg_lock_offset = offsetof(struct fake_xpmem_seg, lock),
			.seg_tg_offset = offsetof(struct fake_xpmem_seg, tg),
		};
		static const struct fake_xpmem_release_aps_offsets
		release_aps_offsets = {
			.tg_ap_hashtable_offset =
				offsetof(struct fake_xpmem_tg, ap_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
			.ap_hashlist_offset =
				offsetof(struct fake_xpmem_ap, ap_hashlist),
		};
		static const struct fake_xpmem_tg_lookup_offsets
		tg_lookup_offsets = {
			.part_tg_hashtable_offset =
				offsetof(struct fake_xpmem_part, tg_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
			.tg_hashlist_offset =
				offsetof(struct fake_xpmem_tg, tg_hashlist),
		};
		static const struct fake_xpmem_seg_lookup_offsets
		seg_lookup_offsets = {
			.tg_seg_list_lock_offset =
				offsetof(struct fake_xpmem_tg, seg_list_lock),
			.tg_seg_list_offset =
				offsetof(struct fake_xpmem_tg, seg_list),
			.seg_segid_offset =
				offsetof(struct fake_xpmem_seg, segid),
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_list_offset =
				offsetof(struct fake_xpmem_seg, seg_list),
		};
		static const struct fake_xpmem_ap_lookup_offsets
		ap_lookup_offsets = {
			.tg_ap_hashtable_offset =
				offsetof(struct fake_xpmem_tg, ap_hashtable),
			.hashlist_stride = sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
			.ap_apid_offset =
				offsetof(struct fake_xpmem_ap, apid),
			.ap_flags_offset =
				offsetof(struct fake_xpmem_ap, flags),
			.ap_hashlist_offset =
				offsetof(struct fake_xpmem_ap, ap_hashlist),
		};
		static const struct fake_xpmem_deref_offsets tg_deref_offsets = {
			.refcnt_offset =
				offsetof(struct fake_xpmem_tg, refcnt),
			.flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
		};
		static const struct fake_xpmem_deref_offsets seg_deref_offsets = {
			.refcnt_offset =
				offsetof(struct fake_xpmem_seg, refcnt),
			.flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
		};
		static const struct fake_xpmem_deref_offsets ap_deref_offsets = {
			.refcnt_offset =
				offsetof(struct fake_xpmem_ap, refcnt),
			.flags_offset =
				offsetof(struct fake_xpmem_ap, flags),
		};
		static const struct fake_xpmem_deref_offsets att_deref_offsets = {
			.refcnt_offset =
				offsetof(struct fake_xpmem_att, refcnt),
			.flags_offset =
				offsetof(struct fake_xpmem_att, flags),
		};
		static const struct fake_xpmem_make_id_offsets
		make_segid_offsets = {
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_uniq_offset =
				offsetof(struct fake_xpmem_tg, uniq_segid),
		};
		static const struct fake_xpmem_make_id_offsets
		make_apid_offsets = {
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_uniq_offset =
				offsetof(struct fake_xpmem_tg, uniq_apid),
		};
		static const struct fake_xpmem_validate_access_offsets
		validate_access_offsets = {
			.proc_pid_offset =
				offsetof(struct fake_xpmem_proc, pid),
			.proc_vm_offset =
				offsetof(struct fake_xpmem_proc, vm),
			.ap_mode_offset =
				offsetof(struct fake_xpmem_ap, mode),
			.ap_tg_offset =
				offsetof(struct fake_xpmem_ap, tg),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.seg_vaddr_offset =
				offsetof(struct fake_xpmem_seg, vaddr),
			.seg_size_offset =
				offsetof(struct fake_xpmem_seg, size),
		};
		static const struct fake_xpmem_perm_offsets perm_offsets = {
			.proc_ruid_offset =
				offsetof(struct fake_xpmem_proc, ruid),
			.proc_rgid_offset =
				offsetof(struct fake_xpmem_proc, rgid),
			.perm_uid_offset =
				offsetof(struct fake_xpmem_perm, uid),
			.perm_gid_offset =
				offsetof(struct fake_xpmem_perm, gid),
			.perm_mode_offset =
				offsetof(struct fake_xpmem_perm, mode),
			.seg_permit_type_offset =
				offsetof(struct fake_xpmem_seg, permit_type),
			.seg_permit_value_offset =
				offsetof(struct fake_xpmem_seg, permit_value),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
			.tg_uid_offset =
				offsetof(struct fake_xpmem_tg, uid),
			.tg_gid_offset =
				offsetof(struct fake_xpmem_tg, gid),
		};
		static const struct fake_xpmem_make_segment_offsets
		make_segment_offsets = {
			.proc_pid_offset =
				offsetof(struct fake_xpmem_proc, pid),
			.seg_size = sizeof(struct fake_xpmem_seg),
			.seg_lock_offset =
				offsetof(struct fake_xpmem_seg, lock),
			.seg_segid_offset =
				offsetof(struct fake_xpmem_seg, segid),
			.seg_vaddr_offset =
				offsetof(struct fake_xpmem_seg, vaddr),
			.seg_size_offset =
				offsetof(struct fake_xpmem_seg, size),
			.seg_permit_type_offset =
				offsetof(struct fake_xpmem_seg, permit_type),
			.seg_permit_value_offset =
				offsetof(struct fake_xpmem_seg, permit_value),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
			.seg_ap_list_offset =
				offsetof(struct fake_xpmem_seg, ap_list),
			.seg_seg_list_offset =
				offsetof(struct fake_xpmem_seg, seg_list),
			.tg_seg_list_lock_offset =
				offsetof(struct fake_xpmem_tg, seg_list_lock),
			.tg_seg_list_offset =
				offsetof(struct fake_xpmem_tg, seg_list),
		};
		static const struct fake_xpmem_get_offsets get_offsets = {
			.proc_pid_offset =
				offsetof(struct fake_xpmem_proc, pid),
			.ap_size = sizeof(struct fake_xpmem_ap),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
			.ap_apid_offset =
				offsetof(struct fake_xpmem_ap, apid),
			.ap_mode_offset =
				offsetof(struct fake_xpmem_ap, mode),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.ap_tg_offset =
				offsetof(struct fake_xpmem_ap, tg),
			.ap_att_list_offset =
				offsetof(struct fake_xpmem_ap, att_list),
			.ap_ap_list_offset =
				offsetof(struct fake_xpmem_ap, ap_list),
			.ap_hashlist_offset =
				offsetof(struct fake_xpmem_ap, ap_hashlist),
			.seg_lock_offset =
				offsetof(struct fake_xpmem_seg, lock),
			.seg_ap_list_offset =
				offsetof(struct fake_xpmem_seg, ap_list),
			.tg_ap_hashtable_offset =
				offsetof(struct fake_xpmem_tg, ap_hashtable),
			.hashlist_stride =
				sizeof(struct fake_xpmem_hashlist),
			.hashlist_lock_offset =
				offsetof(struct fake_xpmem_hashlist, lock),
			.hashlist_list_offset =
				offsetof(struct fake_xpmem_hashlist, list),
		};
		static const struct fake_xpmem_tg_id_offsets tg_id_offsets = {
			.tg_tgid_offset = offsetof(struct fake_xpmem_tg, tgid),
		};
		static const struct fake_xpmem_detach_offsets detach_offsets = {
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.att_at_lock_offset =
				offsetof(struct fake_xpmem_att, at_lock),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.att_vm_offset =
				offsetof(struct fake_xpmem_att, vm),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
			.ap_tg_offset =
				offsetof(struct fake_xpmem_ap, tg),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
		};
		static const struct fake_xpmem_detach_att_offsets
		detach_att_offsets = {
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.att_at_lock_offset =
				offsetof(struct fake_xpmem_att, at_lock),
			.att_vaddr_offset =
				offsetof(struct fake_xpmem_att, vaddr),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_vm_offset =
				offsetof(struct fake_xpmem_att, vm),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
		};
		static const struct fake_xpmem_clear_ptes_offsets
		clear_ptes_offsets = {
			.seg_lock_offset =
				offsetof(struct fake_xpmem_seg, lock),
			.seg_vaddr_offset =
				offsetof(struct fake_xpmem_seg, vaddr),
			.seg_size_offset =
				offsetof(struct fake_xpmem_seg, size),
			.seg_ap_list_offset =
				offsetof(struct fake_xpmem_seg, ap_list),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.ap_att_list_offset =
				offsetof(struct fake_xpmem_ap, att_list),
			.ap_ap_list_offset =
				offsetof(struct fake_xpmem_ap, ap_list),
			.att_at_lock_offset =
				offsetof(struct fake_xpmem_att, at_lock),
			.att_vaddr_offset =
				offsetof(struct fake_xpmem_att, vaddr),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.att_vm_offset =
				offsetof(struct fake_xpmem_att, vm),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
		};
		static const struct fake_xpmem_remove_process_memory_range_offsets
		remove_vmr_offsets = {
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.att_at_lock_offset =
				offsetof(struct fake_xpmem_att, at_lock),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
		};
		static const struct fake_xpmem_remove_process_range_offsets
		remove_range_offsets = {
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_flag_offset =
				offsetof(struct fake_xpmem_range, flag),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
		};
		static const struct fake_xpmem_free_process_range_offsets
		free_range_offsets = {
			.vm_address_space_offset =
				offsetof(struct fake_xpmem_vm, address_space),
			.vm_page_table_lock_offset =
				offsetof(struct fake_xpmem_vm, page_table_lock),
			.vm_range_tree_offset =
				offsetof(struct fake_xpmem_vm, vm_range_tree),
			.vm_range_cache_offset =
				offsetof(struct fake_xpmem_vm, range_cache),
			.vm_range_cache_count = 4,
			.address_space_page_table_offset =
				offsetof(struct fake_xpmem_address_space,
					 page_table),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_memobj_offset =
				offsetof(struct fake_xpmem_range, memobj),
			.range_rb_node_offset =
				offsetof(struct fake_xpmem_range, rb_node),
		};
		static const struct fake_xpmem_update_page_table_offsets
		update_page_table_offsets = {
			.vm_address_space_offset =
				offsetof(struct fake_xpmem_vm, address_space),
			.address_space_page_table_offset =
				offsetof(struct fake_xpmem_address_space,
					 page_table),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_pgshift_offset =
				offsetof(struct fake_xpmem_range, pgshift),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_vmr_offset =
				offsetof(struct fake_xpmem_att, at_vmr),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.ap_flags_offset =
				offsetof(struct fake_xpmem_ap, flags),
			.ap_mode_offset =
				offsetof(struct fake_xpmem_ap, mode),
			.ap_tg_offset =
				offsetof(struct fake_xpmem_ap, tg),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
		};
		static const struct fake_xpmem_fault_process_range_offsets
		fault_range_offsets = {
			.vm_address_space_offset =
				offsetof(struct fake_xpmem_vm, address_space),
			.vm_proc_offset =
				offsetof(struct fake_xpmem_vm, proc),
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
			.address_space_page_table_offset =
				offsetof(struct fake_xpmem_address_space,
					 page_table),
			.proc_straight_va_offset =
				offsetof(struct fake_xpmem_proc, straight_va),
			.proc_straight_len_offset =
				offsetof(struct fake_xpmem_proc, straight_len),
			.proc_straight_pa_offset =
				offsetof(struct fake_xpmem_proc, straight_pa),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_flag_offset =
				offsetof(struct fake_xpmem_range, flag),
			.range_pgshift_offset =
				offsetof(struct fake_xpmem_range, pgshift),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.att_at_vaddr_offset =
				offsetof(struct fake_xpmem_att, at_vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_vaddr_offset =
				offsetof(struct fake_xpmem_att, vaddr),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.ap_flags_offset =
				offsetof(struct fake_xpmem_ap, flags),
			.ap_mode_offset =
				offsetof(struct fake_xpmem_ap, mode),
			.ap_tg_offset =
				offsetof(struct fake_xpmem_ap, tg),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
			.tg_vm_offset =
				offsetof(struct fake_xpmem_tg, vm),
			.tg_n_pinned_offset =
				offsetof(struct fake_xpmem_tg, n_pinned),
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
		};
		static const struct fake_xpmem_fault_process_range_ops
		fault_range_ops = {
			.att_ref_fn = fake_xpmem_att_ref_cb,
			.att_deref_fn = fake_xpmem_att_deref_cb,
			.ap_ref_fn = fake_xpmem_ap_ref_cb,
			.ap_deref_fn = fake_xpmem_ap_deref_cb,
			.tg_ref_fn = fake_xpmem_tg_ref_object_cb,
			.tg_deref_fn = fake_xpmem_tg_deref_cb,
			.seg_ref_fn = fake_xpmem_seg_ref_cb,
			.seg_deref_fn = fake_xpmem_seg_deref_cb,
			.bug_on_fn = fake_xpmem_bug_on,
			.ensure_valid_fn = fake_xpmem_fault_ensure,
			.read_lock_noirq_fn = fake_xpmem_read_lock_noirq,
			.read_unlock_noirq_fn = fake_xpmem_read_unlock_noirq,
			.vaddr_to_pte_fn = fake_xpmem_vaddr_to_pte,
			.pte_present_fn = fake_xpmem_pte_present,
			.pte_phys_fn = fake_xpmem_pte_phys,
			.pt_lookup_pte_fn = fake_xpmem_pt_lookup_pte,
			.smaller_page_fn = fake_xpmem_smaller_page,
			.adjust_page_fn = fake_xpmem_adjust_page,
			.vrflag_to_ptattr_fn = fake_xpmem_vrflag_to_ptattr,
			.pgsize_contiguous_fn = fake_xpmem_pgsize_contiguous,
			.pt_set_pte_fn = fake_xpmem_pt_set_pte,
			.pt_set_range_fn = fake_xpmem_pt_set_range,
			.atomic_dec_fn = fake_xpmem_atomic_dec,
			.flush_tlb_single_fn = fake_xpmem_flush_single,
			.log_fn = fake_xpmem_fault_log,
		};
		static const struct fake_xpmem_attach_offsets attach_offsets = {
			.mckfd_fd_offset =
				offsetof(struct fake_xpmem_mckfd, fd),
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_end_offset =
				offsetof(struct fake_xpmem_range, end),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
			.tg_tgid_offset =
				offsetof(struct fake_xpmem_tg, tgid),
			.tg_flags_offset =
				offsetof(struct fake_xpmem_tg, flags),
			.ap_lock_offset =
				offsetof(struct fake_xpmem_ap, lock),
			.ap_flags_offset =
				offsetof(struct fake_xpmem_ap, flags),
			.ap_seg_offset =
				offsetof(struct fake_xpmem_ap, seg),
			.ap_att_list_offset =
				offsetof(struct fake_xpmem_ap, att_list),
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
			.att_size = sizeof(struct fake_xpmem_att),
			.att_at_lock_offset =
				offsetof(struct fake_xpmem_att, at_lock),
			.att_vaddr_offset =
				offsetof(struct fake_xpmem_att, vaddr),
			.att_at_size_offset =
				offsetof(struct fake_xpmem_att, at_size),
			.att_flags_offset =
				offsetof(struct fake_xpmem_att, flags),
			.att_ap_offset =
				offsetof(struct fake_xpmem_att, ap),
			.att_vm_offset =
				offsetof(struct fake_xpmem_att, vm),
			.att_att_list_offset =
				offsetof(struct fake_xpmem_att, att_list),
		};
		static const struct fake_xpmem_ioctl_offsets ioctl_offsets = {
			.cmd_version = XPMEM_CMD_VERSION,
			.cmd_make = XPMEM_CMD_MAKE,
			.cmd_remove = XPMEM_CMD_REMOVE,
			.cmd_get = XPMEM_CMD_GET,
			.cmd_release = XPMEM_CMD_RELEASE,
			.cmd_attach = XPMEM_CMD_ATTACH,
			.cmd_detach = XPMEM_CMD_DETACH,
			.current_version = XPMEM_CURRENT_VERSION,
			.make_size = sizeof(struct fake_xpmem_cmd_make),
			.make_vaddr_offset =
				offsetof(struct fake_xpmem_cmd_make, vaddr),
			.make_size_offset =
				offsetof(struct fake_xpmem_cmd_make, size),
			.make_permit_type_offset =
				offsetof(struct fake_xpmem_cmd_make,
					 permit_type),
			.make_permit_value_offset =
				offsetof(struct fake_xpmem_cmd_make,
					 permit_value),
			.make_segid_offset =
				offsetof(struct fake_xpmem_cmd_make, segid),
			.remove_size = sizeof(struct fake_xpmem_cmd_remove),
			.remove_segid_offset =
				offsetof(struct fake_xpmem_cmd_remove, segid),
			.get_size = sizeof(struct fake_xpmem_cmd_get),
			.get_segid_offset =
				offsetof(struct fake_xpmem_cmd_get, segid),
			.get_flags_offset =
				offsetof(struct fake_xpmem_cmd_get, flags),
			.get_permit_type_offset =
				offsetof(struct fake_xpmem_cmd_get,
					 permit_type),
			.get_permit_value_offset =
				offsetof(struct fake_xpmem_cmd_get,
					 permit_value),
			.get_apid_offset =
				offsetof(struct fake_xpmem_cmd_get, apid),
			.release_size = sizeof(struct fake_xpmem_cmd_release),
			.release_apid_offset =
				offsetof(struct fake_xpmem_cmd_release, apid),
			.attach_size = sizeof(struct fake_xpmem_cmd_attach),
			.attach_apid_offset =
				offsetof(struct fake_xpmem_cmd_attach, apid),
			.attach_offset_offset =
				offsetof(struct fake_xpmem_cmd_attach, offset),
			.attach_size_offset =
				offsetof(struct fake_xpmem_cmd_attach, size),
			.attach_vaddr_offset =
				offsetof(struct fake_xpmem_cmd_attach, vaddr),
			.attach_fd_offset =
				offsetof(struct fake_xpmem_cmd_attach, fd),
			.attach_flags_offset =
				offsetof(struct fake_xpmem_cmd_attach, flags),
			.detach_size = sizeof(struct fake_xpmem_cmd_detach),
			.detach_vaddr_offset =
				offsetof(struct fake_xpmem_cmd_detach, vaddr),
		};
		static const struct fake_xpmem_pin_page_offsets
		pin_page_offsets = {
			.tg_n_pinned_offset =
				offsetof(struct fake_xpmem_tg, n_pinned),
			.vm_memory_range_lock_offset =
				offsetof(struct fake_xpmem_vm,
					 memory_range_lock),
			.vm_stack_start_offset =
				offsetof(struct fake_xpmem_vm, stack_start),
			.vm_stack_end_offset =
				offsetof(struct fake_xpmem_vm, stack_end),
			.range_start_offset =
				offsetof(struct fake_xpmem_range, start),
			.range_private_data_offset =
				offsetof(struct fake_xpmem_range, private_data),
		};
		static const struct fake_xpmem_ensure_valid_page_offsets
		ensure_valid_offsets = {
			.seg_flags_offset =
				offsetof(struct fake_xpmem_seg, flags),
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
			.tg_group_leader_offset =
				offsetof(struct fake_xpmem_tg, group_leader),
			.tg_vm_offset =
				offsetof(struct fake_xpmem_tg, vm),
		};
		static const struct fake_xpmem_vaddr_to_pte_offsets
		vaddr_to_pte_offsets = {
			.vm_address_space_offset =
				offsetof(struct fake_xpmem_vm, address_space),
			.address_space_page_table_offset =
				offsetof(struct fake_xpmem_address_space,
					 page_table),
			.range_pgshift_offset =
				offsetof(struct fake_xpmem_range, pgshift),
		};
		static const struct fake_xpmem_unpin_pages_offsets
		unpin_pages_offsets = {
			.seg_tg_offset =
				offsetof(struct fake_xpmem_seg, tg),
			.tg_n_pinned_offset =
				offsetof(struct fake_xpmem_tg, n_pinned),
		};
		struct fake_xpmem_proc proc;
		struct fake_xpmem_mckfd slot;
		struct fake_xpmem_mckfd old_head;
		struct fake_xpmem_address_space asp;
		struct fake_xpmem_vm vm;
		struct fake_xpmem_vm current_vm;
		struct fake_xpmem_range range;
		struct fake_xpmem_range range2;
		struct fake_xpmem_range range3;
		struct fake_xpmem_perm perm;
		struct fake_xpmem_tg tg;
		struct fake_xpmem_tg tg2;
		struct fake_xpmem_seg seg;
		struct fake_xpmem_seg seg2;
		struct fake_xpmem_ap ap;
		struct fake_xpmem_ap ap2;
		struct fake_xpmem_att att;
		struct fake_xpmem_att att2;
		struct fake_xpmem_pte pte1;
		struct fake_xpmem_pte pte2;
		unsigned char rwlock_node[32];
		long ctx_word = 0x12345678;
		long id_result;
		void *ptr;
		int ret;

#define XPMEM_UPDATE_PAGE_TABLE_CALL(vm_arg, range_arg, pid_arg, page_in_arg) \
		xpmem_update_process_page_table_body_result((vm_arg), \
			(range_arg), (pid_arg), (page_in_arg), \
			&update_page_table_offsets, fake_xpmem_att_ref_cb, \
			fake_xpmem_att_deref_cb, fake_xpmem_ap_ref_cb, \
			fake_xpmem_ap_deref_cb, fake_xpmem_tg_ref_object_cb, \
			fake_xpmem_tg_deref_cb, fake_xpmem_seg_ref_cb, \
			fake_xpmem_seg_deref_cb, fake_xpmem_bug_on, \
			fake_xpmem_update_fault, fake_xpmem_pt_lookup_pte, \
			fake_xpmem_pte_present, fake_xpmem_update_log)

#define XPMEM_FAULT_CALL(vm_arg, range_arg, vaddr_arg, reason_arg, \
		page_in_arg, pid_arg, current_vm_arg) \
		xpmem_fault_process_memory_range_body_result((vm_arg), \
			(range_arg), (vaddr_arg), (reason_arg), \
			(page_in_arg), (pid_arg), (current_vm_arg), \
			&fault_range_offsets, &fault_range_ops)

#define XPMEM_ATTACH_CALL(apid_arg, offset_arg, size_arg, vaddr_arg, \
		outp_arg, pid_arg, vm_arg, fjmpi_arg) \
		xpmem_attach_body_result(&slot, (apid_arg), (offset_arg), \
			(size_arg), (vaddr_arg), (outp_arg), (pid_arg), \
			(vm_arg), (fjmpi_arg), PROT_READ | PROT_WRITE, \
			MAP_SHARED, MAP_FIXED, MAP_ANONYMOUS, VR_XPMEM, \
			&attach_offsets, fake_xpmem_tg_ref_by_id_cb, \
			fake_xpmem_ap_ref_by_id_cb, fake_xpmem_seg_ref_cb, \
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_ref_object_cb, \
			fake_xpmem_tg_deref_cb, fake_xpmem_ap_deref_cb, \
			fake_xpmem_attach_validate, fake_xpmem_alloc, \
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb, \
			fake_xpmem_att_not_destroyable_cb, \
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb, \
			fake_xpmem_att_write_lock, \
			fake_xpmem_att_write_unlock, fake_xpmem_spin_lock, \
			fake_xpmem_spin_unlock, fake_xpmem_list_add_tail_cb, \
			fake_xpmem_read_lock_noirq, \
			fake_xpmem_read_unlock_noirq, fake_xpmem_lookup_range, \
			fake_xpmem_next_range, fake_xpmem_attach_mmap, \
			fake_xpmem_list_del_init, fake_xpmem_att_destroyable_cb)

#define XPMEM_IOCTL_CALL(cmd_arg, arg_addr) \
		xpmem_ioctl_body_result(&slot, (cmd_arg), (arg_addr), \
			&ioctl_offsets, fake_xpmem_ioctl_copy_from, \
			fake_xpmem_ioctl_copy_to, fake_xpmem_ioctl_make, \
			fake_xpmem_ioctl_remove, fake_xpmem_ioctl_get, \
			fake_xpmem_ioctl_release, fake_xpmem_ioctl_attach, \
			fake_xpmem_ioctl_detach)

		{
			struct fake_xpmem_cmd_make make_cmd = {
				.vaddr = 0x400000,
				.size = 0x3000,
				.permit_type = XPMEM_PERMIT_MODE,
				.permit_value = 0600,
				.segid = 0,
			};
			struct fake_xpmem_cmd_remove remove_cmd = {
				.segid = 0x13579,
			};
			struct fake_xpmem_cmd_get get_cmd = {
				.segid = 0x24680,
				.flags = XPMEM_RDWR,
				.permit_type = XPMEM_PERMIT_MODE,
				.permit_value = 0,
				.apid = 0,
			};
			struct fake_xpmem_cmd_release release_cmd = {
				.apid = 0xabcdef,
			};
			struct fake_xpmem_cmd_attach attach_cmd = {
				.apid = 0x4567,
				.offset = 0x2000,
				.size = 0x5000,
				.vaddr = 0x700000,
				.fd = 33,
				.flags = 0x55,
			};
			struct fake_xpmem_cmd_detach detach_cmd = {
				.vaddr = 0x7788000,
			};

			memset(&slot, 0, sizeof(slot));
			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_VERSION, 0);
			require(ret == XPMEM_CURRENT_VERSION);
			require(fake_xpmem_ioctl_copy_from_calls == 0);
			require(fake_xpmem_ioctl_copy_to_calls == 0);
			mix_signed(&digest, ret);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_MAKE,
				(unsigned long)&make_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_copy_from_calls == 1);
			require(fake_xpmem_ioctl_copy_from_src ==
				(unsigned long)&make_cmd);
			require(fake_xpmem_ioctl_copy_from_size ==
				sizeof(make_cmd));
			require(fake_xpmem_ioctl_make_calls == 1);
			require(fake_xpmem_ioctl_make_vaddr == make_cmd.vaddr);
			require(fake_xpmem_ioctl_make_size == make_cmd.size);
			require(fake_xpmem_ioctl_make_permit_type ==
				make_cmd.permit_type);
			require(fake_xpmem_ioctl_make_permit_value ==
				(void *)make_cmd.permit_value);
			require(fake_xpmem_ioctl_copy_to_calls == 1);
			require(fake_xpmem_ioctl_copy_to_dst ==
				(unsigned long)&make_cmd.segid);
			require(fake_xpmem_ioctl_copy_to_size ==
				sizeof(make_cmd.segid));
			require(make_cmd.segid == fake_xpmem_ioctl_make_out);
			require(fake_xpmem_ioctl_remove_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, make_cmd.segid);

			make_cmd.segid = 0;
			fake_xpmem_ioctl_reset();
			fake_xpmem_ioctl_make_rc = -5;
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_MAKE,
				(unsigned long)&make_cmd);
			require(ret == -5);
			require(fake_xpmem_ioctl_make_calls == 1);
			require(fake_xpmem_ioctl_copy_to_calls == 0);
			require(fake_xpmem_ioctl_remove_calls == 0);
			mix_signed(&digest, ret);

			fake_xpmem_ioctl_reset();
			fake_xpmem_ioctl_copy_to_rc = 1;
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_MAKE,
				(unsigned long)&make_cmd);
			require(ret == -14);
			require(fake_xpmem_ioctl_copy_to_calls == 1);
			require(fake_xpmem_ioctl_remove_calls == 1);
			require(fake_xpmem_ioctl_remove_id ==
				fake_xpmem_ioctl_make_out);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_ioctl_remove_calls);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_REMOVE,
				(unsigned long)&remove_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_copy_from_size ==
				sizeof(remove_cmd));
			require(fake_xpmem_ioctl_remove_calls == 1);
			require(fake_xpmem_ioctl_remove_id == remove_cmd.segid);
			mix_signed(&digest, fake_xpmem_ioctl_remove_id);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_GET,
				(unsigned long)&get_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_get_calls == 1);
			require(fake_xpmem_ioctl_get_segid == get_cmd.segid);
			require(fake_xpmem_ioctl_get_flags == get_cmd.flags);
			require(fake_xpmem_ioctl_get_permit_type ==
				get_cmd.permit_type);
			require(fake_xpmem_ioctl_get_permit_value ==
				(void *)get_cmd.permit_value);
			require(fake_xpmem_ioctl_copy_to_dst ==
				(unsigned long)&get_cmd.apid);
			require(get_cmd.apid == fake_xpmem_ioctl_get_out);
			mix_signed(&digest, get_cmd.apid);

			get_cmd.apid = 0;
			fake_xpmem_ioctl_reset();
			fake_xpmem_ioctl_copy_to_rc = 1;
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_GET,
				(unsigned long)&get_cmd);
			require(ret == -14);
			require(fake_xpmem_ioctl_release_calls == 1);
			require(fake_xpmem_ioctl_release_id ==
				fake_xpmem_ioctl_get_out);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_ioctl_release_calls);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_RELEASE,
				(unsigned long)&release_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_release_calls == 1);
			require(fake_xpmem_ioctl_release_id ==
				release_cmd.apid);
			mix_signed(&digest, fake_xpmem_ioctl_release_id);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_ATTACH,
				(unsigned long)&attach_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_attach_calls == 1);
			require(fake_xpmem_ioctl_attach_mckfd == &slot);
			require(fake_xpmem_ioctl_attach_apid == attach_cmd.apid);
			require(fake_xpmem_ioctl_attach_offset ==
				attach_cmd.offset);
			require(fake_xpmem_ioctl_attach_size == attach_cmd.size);
			require(fake_xpmem_ioctl_attach_vaddr == 0x700000);
			require(fake_xpmem_ioctl_attach_fd == attach_cmd.fd);
			require(fake_xpmem_ioctl_attach_flags ==
				attach_cmd.flags);
			require(fake_xpmem_ioctl_copy_to_dst ==
				(unsigned long)&attach_cmd.vaddr);
			require(attach_cmd.vaddr == fake_xpmem_ioctl_attach_out);
			require(fake_xpmem_ioctl_detach_calls == 0);
			mix_signed(&digest, ret);
			mix(&digest, attach_cmd.vaddr);

			attach_cmd.vaddr = 0x700000;
			fake_xpmem_ioctl_reset();
			fake_xpmem_ioctl_copy_to_rc = 1;
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_ATTACH,
				(unsigned long)&attach_cmd);
			require(ret == -14);
			require(fake_xpmem_ioctl_attach_calls == 1);
			require(fake_xpmem_ioctl_detach_calls == 1);
			require(fake_xpmem_ioctl_detach_vaddr ==
				fake_xpmem_ioctl_attach_out);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_ioctl_detach_calls);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_DETACH,
				(unsigned long)&detach_cmd);
			require(ret == 0);
			require(fake_xpmem_ioctl_detach_calls == 1);
			require(fake_xpmem_ioctl_detach_vaddr ==
				detach_cmd.vaddr);
			mix(&digest, fake_xpmem_ioctl_detach_vaddr);

			fake_xpmem_ioctl_reset();
			fake_xpmem_ioctl_copy_from_rc = 1;
			ret = XPMEM_IOCTL_CALL(XPMEM_CMD_REMOVE,
				(unsigned long)&remove_cmd);
			require(ret == -14);
			require(fake_xpmem_ioctl_remove_calls == 0);
			mix_signed(&digest, ret);

			fake_xpmem_ioctl_reset();
			ret = XPMEM_IOCTL_CALL(0x9999, (unsigned long)&make_cmd);
			require(ret == -22);
			require(fake_xpmem_ioctl_copy_from_calls == 0);
			mix_signed(&digest, ret);
		}

		{
			unsigned long at_out = 0xfeedfaceUL;

			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			ret = XPMEM_ATTACH_CALL(0, 0, 0x2000, 0, &at_out,
				tg.tgid, &vm, 0);
			require(ret == -22);
			require(at_out == 0xfeedfaceUL);
			require(fake_xpmem_tg_ref_by_id_calls == 0);
			require(fake_xpmem_alloc_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_tg_ref_by_id_calls);

			at_out = 0;
			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0,
				&at_out, tg.tgid, &vm, 0);
			require(ret == 0);
			require(fake_xpmem_tg_ref_by_id_calls == 1);
			require(fake_xpmem_tg_ref_by_id_value == ap.apid);
			require(fake_xpmem_ap_ref_by_id_calls == 1);
			require(fake_xpmem_ap_ref_by_id_parent == &tg);
			require(fake_xpmem_ap_ref_by_id_value == ap.apid);
			require(fake_xpmem_seg_ref_calls == 1);
			require(fake_xpmem_tg_ref_object_calls == 1);
			require(fake_xpmem_attach_validate_calls == 1);
			require(fake_xpmem_attach_validate_ap == &ap);
			require(fake_xpmem_attach_validate_offset == 0);
			require(fake_xpmem_attach_validate_size == 0x3000);
			require(fake_xpmem_attach_validate_mode == XPMEM_RDWR);
			require(fake_xpmem_alloc_calls == 1);
			require(fake_xpmem_rwlock_init_calls == 1);
			require(fake_xpmem_att_not_destroyable_calls == 1);
			require(fake_xpmem_att_not_destroyable_att == &att);
			require(fake_xpmem_att_ref_calls == 1);
			require(fake_xpmem_att_deref_calls == 1);
			require(fake_xpmem_att_destroyable_calls == 0);
			require(fake_xpmem_att_write_lock_calls == 1);
			require(fake_xpmem_att_write_unlock_calls == 1);
			require(fake_xpmem_spin_lock_calls == 1);
			require(fake_xpmem_spin_unlock_calls == 1);
			require(fake_xpmem_list_add_tail_calls == 1);
			require(fake_xpmem_list_add_tail_entry == &att.att_list);
			require(fake_xpmem_list_add_tail_head == &ap.att_list);
			require(fake_xpmem_list_del_calls == 1);
			require(fake_xpmem_read_lock_noirq_calls == 0);
			require(fake_xpmem_lookup_range_calls == 0);
			require(fake_xpmem_attach_mmap_calls == 1);
			require(fake_xpmem_attach_mmap_addr == 0);
			require(fake_xpmem_attach_mmap_len == 0x3123);
			require(fake_xpmem_attach_mmap_prot ==
				(PROT_READ | PROT_WRITE));
			require(fake_xpmem_attach_mmap_flags ==
				(MAP_SHARED | MAP_ANONYMOUS));
			require(fake_xpmem_attach_mmap_fd == 77);
			require(fake_xpmem_attach_mmap_offset == 0);
			require(fake_xpmem_attach_mmap_vm_flags == VR_XPMEM);
			require(fake_xpmem_attach_mmap_private_data == &att);
			require(att.vaddr == 0x9123);
			require(att.at_size == 0x3123);
			require(att.ap == &ap);
			require(att.vm == &vm);
			require(at_out == 0x500123);
			require(ap.att_list.next == &att.att_list);
			require(ap.att_list.prev == &att.att_list);
			require(att.att_list.next == &ap.att_list);
			require(att.att_list.prev == &ap.att_list);
			require(fake_xpmem_ap_deref_calls == 1);
			require(fake_xpmem_seg_deref_calls == 1);
			require(fake_xpmem_tg_deref_calls == 2);
			require(fake_xpmem_tg_deref_tgid_sum ==
				tg.tgid + tg2.tgid);
			mix_signed(&digest, ret);
			mix(&digest, at_out);
			mix(&digest, fake_xpmem_attach_mmap_len);
			mix_signed(&digest, fake_xpmem_tg_deref_tgid_sum);

			at_out = 0;
			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0x4000,
				&at_out, tg.tgid, &vm, 0);
			require(ret == 0);
			require(fake_xpmem_read_lock_noirq_calls == 1);
			require(fake_xpmem_read_unlock_noirq_calls == 1);
			require(fake_xpmem_lookup_range_calls == 1);
			require(fake_xpmem_lookup_range_vm == &vm);
			require(fake_xpmem_lookup_range_start == 0x4000);
			require(fake_xpmem_lookup_range_end == 0x7123);
			require(fake_xpmem_next_range_calls == 1);
			require(fake_xpmem_next_range_arg == &range);
			require(fake_xpmem_attach_mmap_calls == 1);
			require(fake_xpmem_attach_mmap_addr == 0x4000);
			require(fake_xpmem_attach_mmap_flags ==
				(MAP_SHARED | MAP_FIXED | MAP_ANONYMOUS));
			require(at_out == 0x500123);
			mix_signed(&digest, ret);
			mix(&digest, fake_xpmem_lookup_range_end);
			mix_signed(&digest, fake_xpmem_next_range_calls);

			at_out = 0;
			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			range.private_data = &fake_xpmem_part;
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0x4000,
				&at_out, tg.tgid, &vm, 0);
			require(ret == -22);
			require(fake_xpmem_read_lock_noirq_calls == 1);
			require(fake_xpmem_read_unlock_noirq_calls == 1);
			require(fake_xpmem_attach_mmap_calls == 0);
			require(fake_xpmem_list_del_calls == 2);
			require(fake_xpmem_att_destroyable_calls == 1);
			require(fake_xpmem_spin_lock_calls == 2);
			require(fake_xpmem_spin_unlock_calls == 2);
			require(att.flags == XPMEM_FLAG_DESTROYING);
			require(fake_xpmem_att_deref_calls == 1);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_att_destroyable_calls);
			mix_signed(&digest, att.flags);

			at_out = 0;
			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			ap.flags = XPMEM_FLAG_DESTROYING;
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0,
				&at_out, tg.tgid, &vm, 0);
			require(ret == -2);
			require(fake_xpmem_attach_mmap_calls == 0);
			require(fake_xpmem_read_lock_noirq_calls == 0);
			require(fake_xpmem_list_add_tail_calls == 1);
			require(fake_xpmem_list_del_calls == 2);
			require(fake_xpmem_att_destroyable_calls == 1);
			require(fake_xpmem_spin_lock_calls == 2);
			require(fake_xpmem_spin_unlock_calls == 2);
			require(fake_xpmem_att_deref_calls == 1);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_list_del_calls);

			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			fake_xpmem_attach_validate_rc = -13;
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0,
				&at_out, tg.tgid, &vm, 0);
			require(ret == -13);
			require(fake_xpmem_attach_validate_calls == 1);
			require(fake_xpmem_alloc_calls == 0);
			require(fake_xpmem_att_ref_calls == 0);
			require(fake_xpmem_ap_deref_calls == 1);
			require(fake_xpmem_seg_deref_calls == 1);
			require(fake_xpmem_tg_deref_calls == 2);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_tg_deref_calls);

			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			fake_xpmem_alloc_rc = NULL;
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0,
				&at_out, tg.tgid, &vm, 0);
			require(ret == -12);
			require(fake_xpmem_alloc_calls == 1);
			require(fake_xpmem_att_not_destroyable_calls == 0);
			require(fake_xpmem_att_ref_calls == 0);
			require(fake_xpmem_attach_mmap_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_alloc_calls);

			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			fake_xpmem_attach_mmap_rc = (unsigned long)-12L;
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2100, 0,
				&at_out, tg.tgid, &vm, 0);
			require(ret == -12);
			require(fake_xpmem_attach_mmap_calls == 1);
			require(fake_xpmem_list_del_calls == 2);
			require(fake_xpmem_att_destroyable_calls == 1);
			require(att.flags == XPMEM_FLAG_DESTROYING);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_attach_mmap_calls);

			fake_xpmem_attach_reset(&slot, &vm, &range, &range2,
				&tg, &tg2, &seg, &ap, &att);
			ret = XPMEM_ATTACH_CALL(ap.apid, 0, 0x2345, 0,
				&at_out, tg.tgid, &vm, 1);
			require(ret == 0);
			require(fake_xpmem_attach_validate_size == 0x2000);
			require(att.at_size == 0x2123);
			require(fake_xpmem_attach_mmap_len == 0x2123);
			mix_signed(&digest, ret);
			mix(&digest, fake_xpmem_attach_mmap_len);
		}

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_tg_ref_by_tgid_nolock_body_result(
			&fake_xpmem_part, tg.tgid, 3, 0, &tg_lookup_offsets,
			fake_xpmem_tg_ref_object_cb);
		require(ptr == &tg);
		require(fake_xpmem_tg_ref_object_calls == 1);
		require(fake_xpmem_tg_ref_object_tgid_sum == tg.tgid);
		mix_signed(&digest, fake_xpmem_tg_ref_object_tgid_sum);
		mix_signed(&digest, ptr == &tg);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_tg_ref_by_tgid_nolock_body_result(
			&fake_xpmem_part, 1999, 3, 0, &tg_lookup_offsets,
			fake_xpmem_tg_ref_object_cb);
		require(ptr == (void *)-2L);
		require(fake_xpmem_tg_ref_object_calls == 0);
		mix_signed(&digest, ptr == (void *)-2L);
		mix_signed(&digest, fake_xpmem_tg_ref_object_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		tg.flags = XPMEM_FLAG_DESTROYING;
		ptr = xpmem_tg_ref_by_tgid_nolock_body_result(
			&fake_xpmem_part, tg.tgid, 3, 0, &tg_lookup_offsets,
			fake_xpmem_tg_ref_object_cb);
		require(ptr == (void *)-2L);
		require(fake_xpmem_tg_ref_object_calls == 0);
		ptr = xpmem_tg_ref_by_tgid_nolock_body_result(
			&fake_xpmem_part, tg.tgid, 3, 1, &tg_lookup_offsets,
			fake_xpmem_tg_ref_object_cb);
		require(ptr == &tg);
		require(fake_xpmem_tg_ref_object_calls == 1);
		mix_signed(&digest, ptr == &tg);
		mix_signed(&digest, fake_xpmem_tg_ref_object_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_tg_ref_by_tgid_wrapper_result(&fake_xpmem_part,
			tg.tgid, 0, 1, &tg_lookup_offsets, &partition_offsets,
			rwlock_node, fake_xpmem_rwlock_lock,
			fake_xpmem_rwlock_unlock, fake_xpmem_tg_ref_object_cb,
			fake_xpmem_tg_lookup_log_cb);
		require(ptr == &tg);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock ==
			&fake_xpmem_part.tg_hashtable[3].lock);
		require(fake_xpmem_rwlock_last_node == rwlock_node);
		require(fake_xpmem_tg_ref_object_calls == 1);
		require(fake_xpmem_tg_lookup_log_calls == 3);
		require(fake_xpmem_tg_lookup_log_event_sum == 6);
		require(fake_xpmem_tg_lookup_log_tgid_sum == tg.tgid * 3);
		require(fake_xpmem_tg_lookup_log_destroy_sum == 0);
		require(fake_xpmem_tg_lookup_log_part_count == 3);
		require(fake_xpmem_tg_lookup_log_result_count == 1);
		mix_signed(&digest, fake_xpmem_tg_lookup_log_event_sum);
		mix_signed(&digest, fake_xpmem_tg_lookup_log_tgid_sum);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_tg_ref_by_tgid_wrapper_result(&fake_xpmem_part,
			tg.tgid, 1, 0, &tg_lookup_offsets, &partition_offsets,
			rwlock_node, fake_xpmem_rwlock_lock,
			fake_xpmem_rwlock_unlock, fake_xpmem_tg_ref_object_cb,
			fake_xpmem_tg_lookup_log_cb);
		require(ptr == &tg);
		require(fake_xpmem_rwlock_lock_calls == 0);
		require(fake_xpmem_rwlock_unlock_calls == 0);
		require(fake_xpmem_tg_ref_object_calls == 1);
		require(fake_xpmem_tg_lookup_log_calls == 2);
		require(fake_xpmem_tg_lookup_log_event_sum == 4);
		require(fake_xpmem_tg_lookup_log_tgid_sum == tg.tgid * 2);
		require(fake_xpmem_tg_lookup_log_destroy_sum == 2);
		require(fake_xpmem_tg_lookup_log_part_count == 2);
		require(fake_xpmem_tg_lookup_log_result_count == 1);
		mix_signed(&digest, fake_xpmem_tg_lookup_log_destroy_sum);
		mix_signed(&digest, fake_xpmem_tg_lookup_log_part_count);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_tg_ref_by_tgid_wrapper_result(&fake_xpmem_part,
			tg.tgid, 0, 1, &tg_lookup_offsets, NULL,
			rwlock_node, fake_xpmem_rwlock_lock,
			fake_xpmem_rwlock_unlock, fake_xpmem_tg_ref_object_cb,
			fake_xpmem_tg_lookup_log_cb);
		require(ptr == (void *)-22L);
		require(fake_xpmem_rwlock_lock_calls == 0);
		require(fake_xpmem_tg_lookup_log_calls == 0);
		mix_signed(&digest, ptr == (void *)-22L);

		range.private_data = NULL;
		require(xpmem_is_private_data_result(&range,
			offsetof(struct fake_xpmem_range, private_data)) == 0);
		range.private_data = &tg;
		require(xpmem_is_private_data_result(&range,
			offsetof(struct fake_xpmem_range, private_data)) == 1);
		require(xpmem_is_private_data_result(NULL,
			offsetof(struct fake_xpmem_range, private_data)) == 0);
		mix_signed(&digest, xpmem_is_private_data_result(&range,
			offsetof(struct fake_xpmem_range, private_data)));

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_seg_ref_by_segid_body_result(&tg, seg2.segid,
			&seg_lookup_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_seg_ref_cb);
		require(ptr == &seg2);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock == &tg.seg_list_lock);
		require(fake_xpmem_rwlock_last_node == rwlock_node);
		require(fake_xpmem_seg_ref_calls == 1);
		require(fake_xpmem_seg_ref_id_sum == seg2.segid);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_seg_ref_id_sum);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		seg2.flags = XPMEM_FLAG_DESTROYING;
		ptr = xpmem_seg_ref_by_segid_body_result(&tg, seg2.segid,
			&seg_lookup_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_seg_ref_cb);
		require(ptr == (void *)-2L);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_seg_ref_calls == 0);
		mix_signed(&digest, ptr == (void *)-2L);
		mix_signed(&digest, fake_xpmem_seg_ref_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ptr = xpmem_ap_ref_by_apid_body_result(&tg, ap2.apid,
			&ap_lookup_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_ap_ref_cb);
		require(ptr == &ap2);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock == &tg.ap_hashtable[5].lock);
		require(fake_xpmem_ap_ref_calls == 1);
		require(fake_xpmem_ap_ref_id_sum == ap2.apid);
		mix_signed(&digest, fake_xpmem_ap_ref_id_sum);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		ap.flags = XPMEM_FLAG_DESTROYING;
		ap2.apid = ap.apid;
		ptr = xpmem_ap_ref_by_apid_body_result(&tg, ap.apid,
			&ap_lookup_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_ap_ref_cb);
		require(ptr == (void *)-2L);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_ap_ref_calls == 0);
		mix_signed(&digest, ptr == (void *)-2L);
		mix_signed(&digest, fake_xpmem_ap_ref_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		tg.refcnt = 2;
		ret = xpmem_deref_body_result(&tg, &tg_deref_offsets, 0,
			fake_xpmem_atomic_read, fake_xpmem_atomic_dec,
			fake_xpmem_bug_on, fake_xpmem_deref_log_cb,
			fake_xpmem_free_cb);
		require(ret == 0);
		require(tg.refcnt == 1);
		require(fake_xpmem_atomic_read_calls == 1);
		require(fake_xpmem_atomic_dec_calls == 1);
		require(fake_xpmem_bug_on_calls == 1);
		require(fake_xpmem_bug_on_condition_sum == 0);
		require(fake_xpmem_free_calls == 0);
		require(fake_xpmem_deref_log_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, tg.refcnt);
		mix_signed(&digest, fake_xpmem_atomic_read_calls +
			fake_xpmem_atomic_dec_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		seg.refcnt = 1;
		seg.flags = XPMEM_FLAG_DESTROYING;
		ret = xpmem_deref_body_result(&seg, &seg_deref_offsets, 1,
			fake_xpmem_atomic_read, fake_xpmem_atomic_dec,
			fake_xpmem_bug_on, fake_xpmem_deref_log_cb,
			fake_xpmem_free_cb);
		require(ret == 1);
		require(seg.refcnt == 0);
		require(fake_xpmem_bug_on_calls == 2);
		require(fake_xpmem_bug_on_condition_sum == 0);
		require(fake_xpmem_deref_log_calls == 1);
		require(fake_xpmem_deref_log_ptr == &seg);
		require(fake_xpmem_free_calls == 1);
		require(fake_xpmem_free_ptr == &seg);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_deref_log_calls);
		mix_signed(&digest, fake_xpmem_free_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		ap.refcnt = 3;
		ret = xpmem_deref_body_result(&ap, &ap_deref_offsets, 1,
			fake_xpmem_atomic_read, fake_xpmem_atomic_dec,
			fake_xpmem_bug_on, fake_xpmem_deref_log_cb,
			fake_xpmem_free_cb);
		require(ret == 0);
		require(ap.refcnt == 2);
		require(fake_xpmem_bug_on_calls == 1);
		require(fake_xpmem_free_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, ap.refcnt);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		att.refcnt = 1;
		att.flags = XPMEM_FLAG_DESTROYING;
		ret = xpmem_deref_body_result(&att, &att_deref_offsets, 1,
			fake_xpmem_atomic_read, fake_xpmem_atomic_dec,
			fake_xpmem_bug_on, fake_xpmem_deref_log_cb,
			fake_xpmem_free_cb);
		require(ret == 1);
		require(att.refcnt == 0);
		require(fake_xpmem_bug_on_calls == 2);
		require(fake_xpmem_deref_log_ptr == &att);
		require(fake_xpmem_free_ptr == &att);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_bug_on_calls);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		fake_xpmem_atomic_calls = 0;
		tg.tgid = 1003;
		tg.uniq_segid = 0;
		id_result = xpmem_make_object_id_body_result(&tg,
			&make_segid_offsets, fake_xpmem_atomic_inc,
			fake_xpmem_atomic_dec, fake_xpmem_bug_on);
		require(id_result == (((long)1 << 32) | 1003));
		require(tg.uniq_segid == 1);
		require(fake_xpmem_atomic_calls == 1);
		require(fake_xpmem_atomic_dec_calls == 0);
		require(fake_xpmem_bug_on_calls == 1);
		require(fake_xpmem_bug_on_condition_sum == 0);
		mix_signed(&digest, id_result);
		mix_signed(&digest, tg.uniq_segid);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		fake_xpmem_deref_reset();
		fake_xpmem_atomic_calls = 0;
		tg.tgid = 1003;
		tg.uniq_apid = INT_MAX >> 1;
		id_result = xpmem_make_object_id_body_result(&tg,
			&make_apid_offsets, fake_xpmem_atomic_inc,
			fake_xpmem_atomic_dec, fake_xpmem_bug_on);
		require(id_result == -16);
		require(tg.uniq_apid == (INT_MAX >> 1));
		require(fake_xpmem_atomic_calls == 1);
		require(fake_xpmem_atomic_dec_calls == 1);
		require(fake_xpmem_bug_on_calls == 0);
		mix_signed(&digest, id_result);
		mix_signed(&digest, tg.uniq_apid);

		fake_xpmem_lookup_ref_reset(&tg, &tg2, &seg, &seg2,
			&ap, &ap2);
		proc.pid = tg.tgid;
		proc.vm = &vm;
		seg.vaddr = 0x800000;
		seg.size = 0x4000;
		ap.mode = XPMEM_RDWR;
		ap.tg = &tg;
		ap.seg = &seg;
		{
			unsigned long access_vaddr = 0xdeadbeefUL;

			ret = xpmem_validate_access_body_result(&ap, &proc,
				0x1000, 0x1000, XPMEM_RDWR, &access_vaddr,
				&validate_access_offsets);
			require(ret == 0);
			require(access_vaddr == 0x801000);
			mix_signed(&digest, ret);
			mix(&digest, access_vaddr);
		}

		proc.pid = tg.tgid + 1;
		{
			unsigned long access_vaddr = 0xdeadbeefUL;

			ret = xpmem_validate_access_body_result(&ap, &proc,
				0, 0x1000, XPMEM_RDWR, &access_vaddr,
				&validate_access_offsets);
			require(ret == -13);
			require(access_vaddr == 0xdeadbeefUL);
			mix_signed(&digest, ret);
			mix(&digest, access_vaddr);
		}

		proc.vm = &vm;
		require(xpmem_is_remote_vm_body_result(&proc, &vm,
			&validate_access_offsets) == 0);
		require(xpmem_is_remote_vm_body_result(&proc, &current_vm,
			&validate_access_offsets) == 1);
		require(xpmem_is_remote_vm_body_result(NULL, &vm,
			&validate_access_offsets) == 1);
		mix_signed(&digest, xpmem_is_remote_vm_body_result(&proc, &vm,
			&validate_access_offsets));
		mix_signed(&digest, xpmem_is_remote_vm_body_result(&proc,
			&current_vm, &validate_access_offsets));

		proc.ruid = 1200;
		proc.rgid = 3400;
		perm.uid = 1200;
		perm.gid = 1;
		perm.mode = 0600;
		ret = xpmem_perms_body_result(&perm, XPMEM_PERM_IRUSR, &proc,
			&perm_offsets);
		require(ret == 0);
		ret = xpmem_perms_body_result(&perm, XPMEM_PERM_IWUSR, &proc,
			&perm_offsets);
		require(ret == 0);
		proc.ruid = 9999;
		proc.rgid = 3400;
		perm.gid = 3400;
		perm.mode = 0040;
		ret = xpmem_perms_body_result(&perm, XPMEM_PERM_IRUSR, &proc,
			&perm_offsets);
		require(ret == 0);
		ret = xpmem_perms_body_result(&perm, XPMEM_PERM_IWUSR, &proc,
			&perm_offsets);
		require(ret == -1);
		mix_signed(&digest, ret);
		mix_signed(&digest, proc.ruid + proc.rgid);

		fake_xpmem_deref_reset();
		proc.ruid = 1200;
		proc.rgid = 3400;
		tg.uid = 1200;
		tg.gid = 3400;
		seg.permit_type = XPMEM_PERMIT_MODE;
		seg.permit_value = (void *)0600UL;
		seg.tg = &tg;
		ret = xpmem_check_permit_mode_body_result(XPMEM_RDWR, &seg,
			&proc, &perm_offsets, fake_xpmem_bug_on);
		require(ret == 0);
		require(fake_xpmem_bug_on_calls == 1);
		require(fake_xpmem_bug_on_condition_sum == 0);
		seg.permit_type = 99;
		ret = xpmem_check_permit_mode_body_result(XPMEM_RDWR, &seg,
			&proc, &perm_offsets, fake_xpmem_bug_on);
		require(ret == 0);
		require(fake_xpmem_bug_on_condition_sum == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_bug_on_condition_sum);

		fake_xpmem_make_segment_reset(&proc, &tg, &seg);
		id_result = 0;
		ret = xpmem_make_segment_body_result(0x8000, 0x2000,
			XPMEM_PERMIT_MODE, (void *)0600UL, &id_result, &proc,
			&make_segment_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_tg_deref_cb, fake_xpmem_make_segid_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_list_init_cb,
			fake_xpmem_seg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_bug_on);
		require(ret == 0);
		require(id_result == fake_xpmem_make_segid_rc);
		require(seg.segid == fake_xpmem_make_segid_rc);
		require(seg.vaddr == 0x8000);
		require(seg.size == 0x2000);
		require(seg.permit_type == XPMEM_PERMIT_MODE);
		require(seg.permit_value == (void *)0600UL);
		require(seg.tg == &tg);
		require(seg.refcnt == 1);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_tg_ref_pid == proc.pid);
		require(fake_xpmem_make_segid_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_spin_init_calls == 1);
		require(fake_xpmem_list_del_calls == 2);
		require(fake_xpmem_seg_not_destroyable_calls == 1);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_list_add_tail_calls == 1);
		require(fake_xpmem_list_add_tail_entry == &seg.seg_list);
		require(fake_xpmem_list_add_tail_head == &tg.seg_list);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, id_result);
		mix_signed(&digest, seg.refcnt);
		mix_signed(&digest, fake_xpmem_tg_ref_calls +
			fake_xpmem_make_segid_calls + fake_xpmem_alloc_calls);

		fake_xpmem_make_segment_reset(&proc, &tg, &seg);
		id_result = 0x12345678;
		ret = xpmem_make_segment_body_result(0x8000, 0x2000, 0,
			(void *)0600UL, &id_result, &proc,
			&make_segment_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_tg_deref_cb, fake_xpmem_make_segid_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_list_init_cb,
			fake_xpmem_seg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_bug_on);
		require(ret == -22);
		require(id_result == 0x12345678);
		require(fake_xpmem_tg_ref_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_ref_calls);

		fake_xpmem_make_segment_reset(&proc, &tg, &seg);
		ret = xpmem_make_segment_body_result(0x8001, 0x2000,
			XPMEM_PERMIT_MODE, (void *)0600UL, &id_result, &proc,
			&make_segment_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_tg_deref_cb, fake_xpmem_make_segid_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_list_init_cb,
			fake_xpmem_seg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_bug_on);
		require(ret == -22);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_make_segid_calls == 0);
		require(fake_xpmem_alloc_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_make_segment_reset(&proc, &tg, &seg);
		fake_xpmem_alloc_rc = NULL;
		ret = xpmem_make_segment_body_result(0x8000, 0x2000,
			XPMEM_PERMIT_MODE, (void *)0600UL, &id_result, &proc,
			&make_segment_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_tg_deref_cb, fake_xpmem_make_segid_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_list_init_cb,
			fake_xpmem_seg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_bug_on);
		require(ret == -12);
		require(fake_xpmem_make_segid_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_list_add_tail_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_alloc_calls);

		fake_xpmem_get_reset(&proc, &tg, &tg2, &seg, &ap);
		id_result = 0;
		ret = xpmem_get_body_result(seg.segid, XPMEM_RDWR,
			XPMEM_PERMIT_MODE, NULL, &id_result, &proc,
			&get_offsets, rwlock_node, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb,
			fake_xpmem_check_permit_cb, fake_xpmem_tg_ref,
			fake_xpmem_make_apid_cb, fake_xpmem_alloc,
			fake_xpmem_spin_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_ap_not_destroyable_cb,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_seg_deref_cb,
			fake_xpmem_tg_deref_cb, fake_xpmem_bug_on);
		require(ret == 0);
		require(id_result == fake_xpmem_make_apid_rc);
		require(ap.apid == fake_xpmem_make_apid_rc);
		require(ap.mode == XPMEM_RDWR);
		require(ap.seg == &seg);
		require(ap.tg == &tg2);
		require(ap.refcnt == 1);
		require(fake_xpmem_tg_ref_by_id_calls == 1);
		require(fake_xpmem_seg_ref_by_id_calls == 1);
		require(fake_xpmem_check_permit_calls == 1);
		require(fake_xpmem_check_permit_flags == XPMEM_RDWR);
		require(fake_xpmem_check_permit_seg == &seg);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_tg_ref_pid == proc.pid);
		require(fake_xpmem_make_apid_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_spin_init_calls == 1);
		require(fake_xpmem_list_del_calls == 3);
		require(fake_xpmem_ap_not_destroyable_calls == 1);
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_spin_unlock_calls == 1);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock == &tg2.ap_hashtable[6].lock);
		require(fake_xpmem_list_add_tail_calls == 2);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_tg_deref_tgid_sum == tg2.tgid);
		require(fake_xpmem_seg_deref_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, id_result);
		mix_signed(&digest, fake_xpmem_tg_ref_by_id_calls +
			fake_xpmem_seg_ref_by_id_calls +
			fake_xpmem_check_permit_calls);
		mix_signed(&digest, fake_xpmem_list_add_tail_calls +
			fake_xpmem_tg_deref_calls);

		fake_xpmem_get_reset(&proc, &tg, &tg2, &seg, &ap);
		id_result = 0x12345678;
		ret = xpmem_get_body_result(0, XPMEM_RDWR, XPMEM_PERMIT_MODE,
			NULL, &id_result, &proc, &get_offsets, rwlock_node,
			fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb,
			fake_xpmem_check_permit_cb, fake_xpmem_tg_ref,
			fake_xpmem_make_apid_cb, fake_xpmem_alloc,
			fake_xpmem_spin_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_ap_not_destroyable_cb,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_seg_deref_cb,
			fake_xpmem_tg_deref_cb, fake_xpmem_bug_on);
		require(ret == -22);
		require(id_result == 0x12345678);
		require(fake_xpmem_tg_ref_by_id_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_ref_by_id_calls);

		fake_xpmem_get_reset(&proc, &tg, &tg2, &seg, &ap);
		fake_xpmem_check_permit_rc = -1;
		ret = xpmem_get_body_result(seg.segid, XPMEM_RDWR,
			XPMEM_PERMIT_MODE, NULL, &id_result, &proc,
			&get_offsets, rwlock_node, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb,
			fake_xpmem_check_permit_cb, fake_xpmem_tg_ref,
			fake_xpmem_make_apid_cb, fake_xpmem_alloc,
			fake_xpmem_spin_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_ap_not_destroyable_cb,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_seg_deref_cb,
			fake_xpmem_tg_deref_cb, fake_xpmem_bug_on);
		require(ret == -13);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_tg_ref_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_seg_deref_calls +
			fake_xpmem_tg_deref_calls);

		fake_xpmem_get_reset(&proc, &tg, &tg2, &seg, &ap);
		fake_xpmem_tg_ref_rc = (void *)-2L;
		ret = xpmem_get_body_result(seg.segid, XPMEM_RDWR,
			XPMEM_PERMIT_MODE, NULL, &id_result, &proc,
			&get_offsets, rwlock_node, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb,
			fake_xpmem_check_permit_cb, fake_xpmem_tg_ref,
			fake_xpmem_make_apid_cb, fake_xpmem_alloc,
			fake_xpmem_spin_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_ap_not_destroyable_cb,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_seg_deref_cb,
			fake_xpmem_tg_deref_cb, fake_xpmem_bug_on);
		require(ret == -2004);
		require(fake_xpmem_bug_on_calls == 1);
		require(fake_xpmem_bug_on_condition_sum == 0);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_make_apid_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_bug_on_calls +
			fake_xpmem_seg_deref_calls);

		fake_xpmem_get_reset(&proc, &tg, &tg2, &seg, &ap);
		fake_xpmem_alloc_rc = NULL;
		ret = xpmem_get_body_result(seg.segid, XPMEM_RDWR,
			XPMEM_PERMIT_MODE, NULL, &id_result, &proc,
			&get_offsets, rwlock_node, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb,
			fake_xpmem_check_permit_cb, fake_xpmem_tg_ref,
			fake_xpmem_make_apid_cb, fake_xpmem_alloc,
			fake_xpmem_spin_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_ap_not_destroyable_cb,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb, fake_xpmem_seg_deref_cb,
			fake_xpmem_tg_deref_cb, fake_xpmem_bug_on);
		require(ret == -12);
		require(fake_xpmem_make_apid_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 2);
		require(fake_xpmem_list_add_tail_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		seg.flags = XPMEM_FLAG_DESTROYING;
		ret = xpmem_ensure_valid_page_body_result(&seg, 0x4100, 1,
			&ensure_valid_offsets, fake_xpmem_pin_page);
		require(ret == -2);
		require(fake_xpmem_pin_page_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_pin_page_calls);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		fake_xpmem_pin_page_rc = -11;
		ret = xpmem_ensure_valid_page_body_result(&seg, 0x4200, 1,
			&ensure_valid_offsets, fake_xpmem_pin_page);
		require(ret == -11);
		require(fake_xpmem_pin_page_calls == 1);
		require(fake_xpmem_pin_page_tg == &tg);
		require(fake_xpmem_pin_page_thread == tg.group_leader);
		require(fake_xpmem_pin_page_vm == &vm);
		require(fake_xpmem_pin_page_vaddr == 0x4200);
		require(fake_xpmem_pin_page_page_in == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_pin_page_calls);
		mix(&digest, fake_xpmem_pin_page_vaddr);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm, &vm,
			0x4100, 0, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == 0);
		require(fake_xpmem_lookup_range_calls == 1);
		require(fake_xpmem_lookup_range_vm == &vm);
		require(fake_xpmem_lookup_range_start == 0x4100);
		require(fake_xpmem_lookup_range_end == 0x4101);
		require(fake_xpmem_read_lock_noirq_calls == 0);
		require(fake_xpmem_page_fault_range_calls == 0);
		require(fake_xpmem_atomic_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_lookup_range_calls);
		mix_signed(&digest, tg.n_pinned);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm, &vm,
			0x4100, 1, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == 0);
		require(fake_xpmem_page_fault_range_calls == 1);
		require(fake_xpmem_page_fault_range_vm == &vm);
		require(fake_xpmem_page_fault_range_range == &range);
		require(fake_xpmem_page_fault_range_vaddr == 0x4100);
		require(fake_xpmem_page_fault_range_reason ==
			(PF_POPULATE | PF_WRITE | PF_USER));
		require(fake_xpmem_atomic_calls == 1);
		require(tg.n_pinned == 4);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_page_fault_range_calls);
		mix_signed(&digest, tg.n_pinned);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		fake_xpmem_lookup_range_seq[0] = NULL;
		fake_xpmem_lookup_range_seq[1] = &range;
		fake_xpmem_lookup_range_seq_len = 2;
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm,
			&current_vm, 0x8000, 0, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == 0);
		require(fake_xpmem_lookup_range_calls == 2);
		require(fake_xpmem_read_lock_noirq_calls == 2);
		require(fake_xpmem_read_unlock_noirq_calls == 2);
		require(fake_xpmem_page_fault_vm_calls == 1);
		require(fake_xpmem_page_fault_vm_vm == &vm);
		require(fake_xpmem_page_fault_vm_vaddr == 0x8000);
		require(fake_xpmem_page_fault_vm_reason ==
			(PF_POPULATE | PF_WRITE | PF_USER));
		require(fake_xpmem_noirq_last_lock == &vm.memory_range_lock);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_lookup_range_calls);
		mix_signed(&digest, fake_xpmem_read_unlock_noirq_calls);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		fake_xpmem_lookup_range_rc = NULL;
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm,
			&current_vm, 0x5000, 0, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == -2);
		require(fake_xpmem_lookup_range_calls == 1);
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_page_fault_vm_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_lookup_range_calls);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		range.private_data = &att;
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm,
			&current_vm, 0x4100, 1, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == -2);
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_page_fault_range_calls == 0);
		require(fake_xpmem_atomic_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_read_unlock_noirq_calls);

		fake_xpmem_pin_reset(&vm, &current_vm, &range, &tg, &seg);
		fake_xpmem_page_fault_range_rc = -5;
		ret = xpmem_pin_page_body_result(&tg, tg.group_leader, &vm,
			&current_vm, 0x4100, 1, &pin_page_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_lookup_range, fake_xpmem_page_fault_vm,
			fake_xpmem_page_fault_range,
			fake_xpmem_atomic_inc);
		require(ret == -5);
		require(fake_xpmem_page_fault_range_calls == 1);
		require(fake_xpmem_atomic_calls == 0);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(tg.n_pinned == 3);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_page_fault_range_calls);

		fake_xpmem_pte_reset(&vm, &asp, &range, &tg, &seg, &pte1,
			&pte2);
		{
			size_t pgsize = 0xaaaa;
			void *pte = xpmem_vaddr_to_pte_body_result(&vm,
				0x4567, &pgsize, &vaddr_to_pte_offsets,
				fake_xpmem_lookup_range,
				fake_xpmem_pt_lookup_pte);

			require(pte == &pte1);
			require(pgsize == 0x2000);
			require(fake_xpmem_lookup_range_calls == 1);
			require(fake_xpmem_lookup_range_vm == &vm);
			require(fake_xpmem_lookup_range_start == 0x4567);
			require(fake_xpmem_lookup_range_end == 0x4568);
			require(fake_xpmem_pt_lookup_pte_calls == 1);
			require(fake_xpmem_pt_lookup_pte_page_table ==
				asp.page_table);
			require(fake_xpmem_pt_lookup_pte_vaddr == 0x4567);
			require(fake_xpmem_pt_lookup_pte_pgshift == 12);
			mix_signed(&digest, pte != NULL);
			mix(&digest, pgsize);
		}

		fake_xpmem_pte_reset(&vm, &asp, &range, &tg, &seg, &pte1,
			&pte2);
		fake_xpmem_pt_lookup_pte_rc = NULL;
		{
			size_t pgsize = 0xaaaa;
			void *pte = xpmem_vaddr_to_pte_body_result(&vm,
				0x4567, &pgsize, &vaddr_to_pte_offsets,
				fake_xpmem_lookup_range,
				fake_xpmem_pt_lookup_pte);

			require(pte == NULL);
			require(pgsize == PAGE_SIZE);
			require(fake_xpmem_pt_lookup_pte_calls == 1);
			mix(&digest, pgsize);
			mix_signed(&digest, fake_xpmem_pt_lookup_pte_calls);
		}

		fake_xpmem_pte_reset(&vm, &asp, &range, &tg, &seg, &pte1,
			&pte2);
		fake_xpmem_lookup_range_rc = NULL;
		{
			size_t pgsize = 0xaaaa;
			void *pte = xpmem_vaddr_to_pte_body_result(&vm,
				0x4567, &pgsize, &vaddr_to_pte_offsets,
				fake_xpmem_lookup_range,
				fake_xpmem_pt_lookup_pte);

			require(pte == NULL);
			require(pgsize == 0xaaaa);
			require(fake_xpmem_pt_lookup_pte_calls == 0);
			mix(&digest, pgsize);
			mix_signed(&digest, fake_xpmem_lookup_range_calls);
		}

		fake_xpmem_pte_reset(&vm, &asp, &range, &tg, &seg, &pte1,
			&pte2);
		fake_xpmem_vaddr_to_pte_sizes[0] = 0x1000;
		fake_xpmem_vaddr_to_pte_sizes[1] = 0x1000;
		fake_xpmem_vaddr_to_pte_ptes[0] = &pte1;
		fake_xpmem_vaddr_to_pte_ptes[1] = &pte2;
		ret = xpmem_unpin_pages_body_result(&seg, &vm, 0x4103,
			0x1800, &unpin_pages_offsets,
			fake_xpmem_vaddr_to_pte,
			fake_xpmem_pte_present, fake_xpmem_atomic_sub);
		require(ret == 1);
		require(fake_xpmem_vaddr_to_pte_calls == 2);
		require(fake_xpmem_vaddr_to_pte_vm == &vm);
		require(fake_xpmem_vaddr_to_pte_vaddr == 0x5000);
		require(fake_xpmem_pte_present_calls == 2);
		require(fake_xpmem_atomic_sub_calls == 1);
		require(fake_xpmem_atomic_sub_value == 1);
		require(fake_xpmem_atomic_sub_counter == &tg.n_pinned);
		require(tg.n_pinned == 6);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_vaddr_to_pte_calls);
		mix_signed(&digest, tg.n_pinned);

		fake_xpmem_pte_reset(&vm, &asp, &range, &tg, &seg, &pte1,
			&pte2);
		fake_xpmem_vaddr_to_pte_sizes[0] = 0x2000;
		fake_xpmem_vaddr_to_pte_ptes[0] = NULL;
		ret = xpmem_unpin_pages_body_result(&seg, &vm, 0x4000,
			0x1000, &unpin_pages_offsets,
			fake_xpmem_vaddr_to_pte,
			fake_xpmem_pte_present, fake_xpmem_atomic_sub);
		require(ret == 0);
		require(fake_xpmem_vaddr_to_pte_calls == 1);
		require(fake_xpmem_pte_present_calls == 0);
		require(fake_xpmem_atomic_sub_calls == 1);
		require(fake_xpmem_atomic_sub_value == 0);
		require(tg.n_pinned == 7);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_atomic_sub_calls);

		memset(&old_head, 0, sizeof(old_head));
		old_head.fd = 9;
		fake_xpmem_partp = NULL;
		fake_xpmem_open_reset(&proc, &slot, &old_head);
		fake_xpmem_forward_rc = 100;
		ret = xpmem_open_body_result(43, "/dev/xpmem", 0x55,
			&ctx_word, &fake_xpmem_partp, &proc, &open_offsets,
			0x1111, 0x2222, 0x3333, fake_xpmem_init,
			fake_xpmem_forward, fake_xpmem_open_primitive,
			fake_xpmem_alloc, fake_xpmem_lock,
			fake_xpmem_unlock, fake_xpmem_atomic_inc,
			fake_xpmem_open_log);
		require(ret == 144);
		require(proc.mckfd == &slot);
		require(slot.next == &old_head);
		require(slot.fd == 144);
		require(slot.sig_no == -1);
		require(slot.data == (long)&proc);
		require(slot.ioctl_cb == 0x1111);
		require(slot.close_cb == 0x2222);
		require(slot.dup_cb == 0x3333);
		require(fake_xpmem_init_calls == 1);
		require(fake_xpmem_forward_calls == 1);
		require(fake_xpmem_open_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_lock_calls == 1);
		require(fake_xpmem_unlock_calls == 1);
		require(fake_xpmem_atomic_calls == 1);
		require(fake_xpmem_part.n_opened == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_log_count);
		mix_signed(&digest, fake_xpmem_log_event_sum);
		mix_signed(&digest, fake_xpmem_log_value_sum);
		mix_signed(&digest, fake_xpmem_unlock_irq);
		mix_signed(&digest, slot.fd + slot.sig_no + old_head.fd);

		fake_xpmem_open_reset(&proc, &slot, &old_head);
		fake_xpmem_partp = &fake_xpmem_part;
		fake_xpmem_part.n_opened = 4;
		fake_xpmem_forward_rc = 200;
		ret = xpmem_open_body_result(10, "/dev/xpmem", 0x22,
			&ctx_word, &fake_xpmem_partp, &proc, &open_offsets,
			0x4444, 0x5555, 0x6666, fake_xpmem_init,
			fake_xpmem_forward, fake_xpmem_open_primitive,
			fake_xpmem_alloc, fake_xpmem_lock,
			fake_xpmem_unlock, fake_xpmem_atomic_inc,
			fake_xpmem_open_log);
		require(ret == 211);
		require(fake_xpmem_init_calls == 0);
		require(fake_xpmem_part.n_opened == 5);
		require(proc.mckfd == &slot && slot.next == &old_head);
		require(slot.ioctl_cb == 0x4444 && slot.close_cb == 0x5555);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_part.n_opened);
		mix_signed(&digest, fake_xpmem_log_event_sum);

		fake_xpmem_open_reset(&proc, &slot, &old_head);
		fake_xpmem_partp = &fake_xpmem_part;
		fake_xpmem_forward_rc = -80;
		ret = xpmem_open_body_result(13, "/dev/xpmem", 0x33,
			&ctx_word, &fake_xpmem_partp, &proc, &open_offsets,
			0x1111, 0x2222, 0x3333, fake_xpmem_init,
			fake_xpmem_forward, fake_xpmem_open_primitive,
			fake_xpmem_alloc, fake_xpmem_lock,
			fake_xpmem_unlock, fake_xpmem_atomic_inc,
			fake_xpmem_open_log);
		require(ret == -66);
		require(proc.mckfd == &old_head);
		require(fake_xpmem_open_calls == 0);
		require(fake_xpmem_alloc_calls == 0);
		require(fake_xpmem_atomic_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_log_value_sum);

		fake_xpmem_open_reset(&proc, &slot, &old_head);
		fake_xpmem_partp = &fake_xpmem_part;
		fake_xpmem_forward_rc = 5;
		fake_xpmem_open_rc = -19;
		ret = xpmem_open_body_result(6, "/dev/xpmem", 0x44,
			&ctx_word, &fake_xpmem_partp, &proc, &open_offsets,
			0x1111, 0x2222, 0x3333, fake_xpmem_init,
			fake_xpmem_forward, fake_xpmem_open_primitive,
			fake_xpmem_alloc, fake_xpmem_lock,
			fake_xpmem_unlock, fake_xpmem_atomic_inc,
			fake_xpmem_open_log);
		require(ret == -19);
		require(fake_xpmem_open_calls == 1);
		require(fake_xpmem_alloc_calls == 0);
		require(fake_xpmem_atomic_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_log_value_sum);

		fake_xpmem_open_reset(&proc, &slot, &old_head);
		fake_xpmem_partp = &fake_xpmem_part;
		fake_xpmem_alloc_rc = NULL;
		ret = xpmem_open_body_result(6, "/dev/xpmem", 0x45,
			&ctx_word, &fake_xpmem_partp, &proc, &open_offsets,
			0x1111, 0x2222, 0x3333, fake_xpmem_init,
			fake_xpmem_forward, fake_xpmem_open_primitive,
			fake_xpmem_alloc, fake_xpmem_lock,
			fake_xpmem_unlock, fake_xpmem_atomic_inc,
			fake_xpmem_open_log);
		require(ret == -12);
		require(proc.mckfd == &old_head);
		require(fake_xpmem_open_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_atomic_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_log_count);

		fake_xpmem_close_reset();
		fake_xpmem_partp = &fake_xpmem_part;
		fake_xpmem_part.n_opened = 4;
		slot.fd = 55;
		slot.data = (long)&proc;
		ret = xpmem_dup_body_result(&slot, &fake_xpmem_partp,
			&close_offsets, fake_xpmem_atomic_inc);
		require(ret == 0);
		require(slot.data == 0);
		require(fake_xpmem_part.n_opened == 5);
		require(fake_xpmem_atomic_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, slot.data);
		mix_signed(&digest, fake_xpmem_part.n_opened);
		mix_signed(&digest, fake_xpmem_atomic_calls);

		fake_xpmem_close_reset();
		fake_xpmem_part.n_opened = 2;
		slot.fd = 61;
		slot.data = (long)&proc;
		ret = xpmem_close_body_result(&slot, &fake_xpmem_partp,
			&close_offsets, fake_xpmem_atomic_dec,
			fake_xpmem_mckfd_flush, fake_xpmem_exit,
			fake_xpmem_close_log);
		require(ret == 0);
		require(fake_xpmem_part.n_opened == 1);
		require(fake_xpmem_atomic_dec_calls == 1);
		require(fake_xpmem_flush_calls == 1);
		require(fake_xpmem_flush_fd_sum == 61);
		require(fake_xpmem_exit_calls == 0);
		require(fake_xpmem_close_log_count == 3);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_part.n_opened);
		mix_signed(&digest, fake_xpmem_flush_fd_sum);
		mix_signed(&digest, fake_xpmem_close_log_event_sum);
		mix_signed(&digest, fake_xpmem_close_log_value_sum);

		fake_xpmem_close_reset();
		fake_xpmem_part.n_opened = 1;
		slot.fd = 62;
		slot.data = 0;
		ret = xpmem_close_body_result(&slot, &fake_xpmem_partp,
			&close_offsets, fake_xpmem_atomic_dec,
			fake_xpmem_mckfd_flush, fake_xpmem_exit,
			fake_xpmem_close_log);
		require(ret == 0);
		require(fake_xpmem_part.n_opened == 0);
		require(fake_xpmem_flush_calls == 0);
		require(fake_xpmem_exit_calls == 1);
		require(fake_xpmem_close_log_count == 3);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_part.n_opened);
		mix_signed(&digest, fake_xpmem_exit_calls);
		mix_signed(&digest, fake_xpmem_close_log_event_sum);

		fake_xpmem_partition_reset();
		ret = xpmem_partition_init_body_result(&fake_xpmem_partp,
			&partition_offsets, fake_xpmem_alloc,
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_atomic_set);
		require(ret == 0);
		require(fake_xpmem_partp == &fake_xpmem_part);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_rwlock_init_calls == 8);
		require(fake_xpmem_list_del_calls == 8);
		require(fake_xpmem_atomic_set_calls == 1);
		require(fake_xpmem_part.n_opened == 0);
		for (int idx = 0; idx < 8; idx++) {
			require(fake_xpmem_part.tg_hashtable[idx].list.next ==
				&fake_xpmem_part.tg_hashtable[idx].list);
			require(fake_xpmem_part.tg_hashtable[idx].list.prev ==
				&fake_xpmem_part.tg_hashtable[idx].list);
		}
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_rwlock_init_calls +
			fake_xpmem_list_del_calls + fake_xpmem_atomic_set_calls);

		ret = xpmem_partition_exit_body_result(&fake_xpmem_partp,
			fake_xpmem_free_cb);
		require(ret == 0);
		require(fake_xpmem_partp == NULL);
		require(fake_xpmem_free_calls == 1);
		require(fake_xpmem_free_ptr == &fake_xpmem_part);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_free_calls);

		fake_xpmem_partition_reset();
		fake_xpmem_alloc_rc = NULL;
		ret = xpmem_partition_init_body_result(&fake_xpmem_partp,
			&partition_offsets, fake_xpmem_alloc,
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_atomic_set);
		require(ret == -12);
		require(fake_xpmem_partp == NULL);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_rwlock_init_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_alloc_calls);

		fake_xpmem_partition_reset();
		fake_xpmem_partp = NULL;
		ret = xpmem_partition_exit_body_result(&fake_xpmem_partp,
			fake_xpmem_free_cb);
		require(ret == 0);
		require(fake_xpmem_free_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_free_calls);

		fake_xpmem_open_tg_reset(&proc, &tg, &vm);
		ret = xpmem_open_tg_body_result(&fake_xpmem_partp, &ctx_word,
			&proc, &vm, &open_tg_offsets, rwlock_node,
			fake_xpmem_tg_ref, fake_xpmem_tg_deref_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_atomic_set, fake_xpmem_tg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb);
		require(ret == 0);
		require(tg.tgid == proc.pid);
		require(tg.uid == proc.ruid);
		require(tg.gid == proc.rgid);
		require(tg.uniq_segid == 0);
		require(tg.uniq_apid == 0);
		require(tg.n_pinned == 0);
		require(tg.refcnt == 1);
		require(tg.vm == &vm);
		require(tg.group_leader == &ctx_word);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_tg_ref_pid == proc.pid);
		require(fake_xpmem_tg_deref_calls == 0);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_spin_init_calls == 1);
		require(fake_xpmem_rwlock_init_calls == 9);
		require(fake_xpmem_list_del_calls == 10);
		require(fake_xpmem_atomic_set_calls == 3);
		require(fake_xpmem_tg_not_destroyable_calls == 1);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock ==
			&fake_xpmem_part.tg_hashtable[3].lock);
		require(fake_xpmem_list_add_tail_calls == 1);
		require(fake_xpmem_list_add_tail_entry == &tg.tg_hashlist);
		require(fake_xpmem_list_add_tail_head ==
			&fake_xpmem_part.tg_hashtable[3].list);
		mix_signed(&digest, ret);
		mix_signed(&digest, tg.tgid + tg.uid + tg.gid);
		mix_signed(&digest, fake_xpmem_rwlock_init_calls +
			fake_xpmem_list_del_calls + fake_xpmem_atomic_set_calls);
		mix_signed(&digest, fake_xpmem_list_add_tail_calls);

		fake_xpmem_open_tg_reset(&proc, &tg, &vm);
		fake_xpmem_tg_ref_rc = &tg;
		ret = xpmem_open_tg_body_result(&fake_xpmem_partp, &ctx_word,
			&proc, &vm, &open_tg_offsets, rwlock_node,
			fake_xpmem_tg_ref, fake_xpmem_tg_deref_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_atomic_set, fake_xpmem_tg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb);
		require(ret == 0);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_alloc_calls == 0);
		require(fake_xpmem_list_add_tail_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_open_tg_reset(&proc, &tg, &vm);
		fake_xpmem_alloc_rc = NULL;
		ret = xpmem_open_tg_body_result(&fake_xpmem_partp, &ctx_word,
			&proc, &vm, &open_tg_offsets, rwlock_node,
			fake_xpmem_tg_ref, fake_xpmem_tg_deref_cb,
			fake_xpmem_alloc, fake_xpmem_spin_init_cb,
			fake_xpmem_rwlock_init_cb, fake_xpmem_list_init_cb,
			fake_xpmem_atomic_set, fake_xpmem_tg_not_destroyable_cb,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_add_tail_cb);
		require(ret == -12);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_alloc_calls == 1);
		require(fake_xpmem_tg_not_destroyable_calls == 0);
		require(fake_xpmem_list_add_tail_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_alloc_calls);

		fake_xpmem_flush_reset(&proc, &slot, &tg);
		fake_xpmem_tg_ref_rc = (void *)-2L;
		ret = xpmem_flush_body_result(&slot, &fake_xpmem_partp,
			&flush_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_release_aps,
			fake_xpmem_remove_segs, fake_xpmem_destroy_tg_cb,
			fake_xpmem_flush_log);
		require(ret == 0);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_tg_ref_pid == proc.pid);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_list_del_calls == 0);
		require(fake_xpmem_spin_lock_calls == 0);
		require(fake_xpmem_release_aps_calls == 0);
		require(fake_xpmem_destroy_tg_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_ref_pid);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_list_del_calls);

		fake_xpmem_flush_reset(&proc, &slot, &tg);
		ret = xpmem_flush_body_result(&slot, &fake_xpmem_partp,
			&flush_offsets, rwlock_node, fake_xpmem_tg_ref,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_release_aps,
			fake_xpmem_remove_segs, fake_xpmem_destroy_tg_cb,
			fake_xpmem_flush_log);
		require(ret == 0);
		require(fake_xpmem_tg_ref_calls == 1);
		require(fake_xpmem_list_del_calls == 1);
		require(fake_xpmem_list_del_entry == &tg.tg_hashlist);
		require(tg.tg_hashlist.next == &tg.tg_hashlist);
		require(tg.tg_hashlist.prev == &tg.tg_hashlist);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_spin_lock_calls == 2);
		require(fake_xpmem_spin_unlock_calls == 2);
		require(fake_xpmem_release_aps_calls == 1);
		require(fake_xpmem_remove_segs_calls == 1);
		require(fake_xpmem_destroy_tg_calls == 1);
		require(fake_xpmem_release_aps_tg == &tg);
		require(fake_xpmem_remove_segs_tg == &tg);
		require(fake_xpmem_destroy_tg == &tg);
		require(tg.flags == (0x10 | XPMEM_FLAG_DESTROYING |
			XPMEM_FLAG_DESTROYED));
		require(fake_xpmem_flush_log_count == 1);
		require(fake_xpmem_flush_log_tg == &tg);
		require(fake_xpmem_flush_log_value_sum == (long)tg.vm);
		mix_signed(&digest, ret);
		mix_signed(&digest, tg.flags);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix_signed(&digest, fake_xpmem_release_aps_calls +
			fake_xpmem_remove_segs_calls +
			fake_xpmem_destroy_tg_calls);
		mix_signed(&digest, fake_xpmem_flush_log_event_sum);
		mix_signed(&digest, fake_xpmem_flush_log_value_sum);

		fake_xpmem_remove_seg_reset(&tg, &seg);
		ret = xpmem_remove_seg_body_result(&tg, &seg,
			&remove_seg_offsets, rwlock_node,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_clear_ptes,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_seg_destroyable,
			fake_xpmem_remove_seg_log);
		require(ret == 0);
		require(seg.flags == (0x20 | XPMEM_FLAG_DESTROYING |
			XPMEM_FLAG_DESTROYED));
		require(fake_xpmem_spin_lock_calls == 2);
		require(fake_xpmem_spin_unlock_calls == 2);
		require(fake_xpmem_clear_ptes_calls == 1);
		require(fake_xpmem_clear_ptes_seg == &seg);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock == &tg.seg_list_lock);
		require(fake_xpmem_list_del_calls == 1);
		require(fake_xpmem_list_del_entry == &seg.seg_list);
		require(seg.seg_list.next == &seg.seg_list);
		require(seg.seg_list.prev == &seg.seg_list);
		require(fake_xpmem_seg_destroyable_calls == 1);
		require(fake_xpmem_seg_destroyable_seg == &seg);
		require(fake_xpmem_remove_seg_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, seg.flags);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix_signed(&digest, fake_xpmem_clear_ptes_calls);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_list_del_calls);
		mix_signed(&digest, fake_xpmem_seg_destroyable_calls);
		mix_signed(&digest, fake_xpmem_remove_seg_log_event_sum);

		fake_xpmem_remove_seg_reset(&tg, &seg);
		seg.flags = XPMEM_FLAG_DESTROYING | 0x20;
		ret = xpmem_remove_seg_body_result(&tg, &seg,
			&remove_seg_offsets, rwlock_node,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_clear_ptes,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_seg_destroyable,
			fake_xpmem_remove_seg_log);
		require(ret == 0);
		require(seg.flags == (XPMEM_FLAG_DESTROYING | 0x20));
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_spin_unlock_calls == 1);
		require(fake_xpmem_clear_ptes_calls == 0);
		require(fake_xpmem_rwlock_lock_calls == 0);
		require(fake_xpmem_list_del_calls == 0);
		require(fake_xpmem_seg_destroyable_calls == 0);
		require(fake_xpmem_remove_seg_log_count == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, seg.flags);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix_signed(&digest, fake_xpmem_clear_ptes_calls);
		mix_signed(&digest, fake_xpmem_remove_seg_log_event_sum);

		fake_xpmem_remove_segs_reset(&tg, &seg, &seg2);
		ret = xpmem_remove_segs_of_tg_body_result(&tg,
			&remove_segs_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_seg_ref_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_remove_segs_log);
		require(ret == 0);
		require(fake_xpmem_rwlock_lock_calls == 3);
		require(fake_xpmem_rwlock_unlock_calls == 3);
		require(fake_xpmem_rwlock_last_lock == &tg.seg_list_lock);
		require(fake_xpmem_seg_ref_calls == 2);
		require(fake_xpmem_seg_deref_calls == 2);
		require(fake_xpmem_seg_ref_id_sum == 0x3333);
		require(fake_xpmem_seg_deref_id_sum == 0x3333);
		require(fake_xpmem_remove_seg_cb_calls == 2);
		require(fake_xpmem_remove_seg_cb_id_sum == 0x3333);
		require(fake_xpmem_remove_seg_cb_tg == &tg);
		require(tg.seg_list.next == &tg.seg_list);
		require(tg.seg_list.prev == &tg.seg_list);
		require(seg.seg_list.next == &seg.seg_list);
		require(seg2.seg_list.next == &seg2.seg_list);
		require(fake_xpmem_remove_segs_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_seg_ref_id_sum);
		mix_signed(&digest, fake_xpmem_seg_deref_id_sum);
		mix_signed(&digest, fake_xpmem_remove_seg_cb_id_sum);
		mix_signed(&digest, fake_xpmem_remove_segs_log_event_sum);

		fake_xpmem_remove_segs_reset(&tg, &seg, &seg2);
		tg.seg_list.next = &tg.seg_list;
		tg.seg_list.prev = &tg.seg_list;
		ret = xpmem_remove_segs_of_tg_body_result(&tg,
			&remove_segs_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_seg_ref_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_remove_segs_log);
		require(ret == 0);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_seg_ref_calls == 0);
		require(fake_xpmem_remove_seg_cb_calls == 0);
		require(fake_xpmem_seg_deref_calls == 0);
		require(fake_xpmem_remove_segs_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_remove_segs_log_event_sum);

		fake_xpmem_release_ap_reset(&tg, &tg2, &seg, &ap, &att,
			&att2);
		ret = xpmem_release_ap_body_result(&tg, &ap,
			&release_ap_offsets, rwlock_node,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init, fake_xpmem_att_ref_cb,
			fake_xpmem_detach_att_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb,
			fake_xpmem_ap_destroyable_cb,
			fake_xpmem_release_ap_log);
		require(ret == 0);
		require(ap.flags == (0x20 | XPMEM_FLAG_DESTROYING |
			XPMEM_FLAG_DESTROYED));
		require(ap.att_list.next == &ap.att_list);
		require(ap.att_list.prev == &ap.att_list);
		require(fake_xpmem_att_ref_calls == 2);
		require(fake_xpmem_att_deref_calls == 2);
		require(fake_xpmem_att_ref_id_sum == 0x303);
		require(fake_xpmem_att_deref_id_sum == 0x303);
		require(fake_xpmem_detach_att_calls == 2);
		require(fake_xpmem_detach_att_id_sum == 0x303);
		require(fake_xpmem_detach_att_ap == &ap);
		require(fake_xpmem_spin_lock_calls == 4);
		require(fake_xpmem_spin_unlock_calls == 4);
		require(fake_xpmem_rwlock_lock_calls == 1);
		require(fake_xpmem_rwlock_unlock_calls == 1);
		require(fake_xpmem_rwlock_last_lock ==
			&tg.ap_hashtable[5].lock);
		require(fake_xpmem_list_del_calls == 2);
		require(fake_xpmem_list_del_entry == &ap.ap_list);
		require(ap.ap_hashlist.next == &ap.ap_hashlist);
		require(ap.ap_list.next == &ap.ap_list);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_seg_deref_id_sum == seg.segid);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_tg_deref_tgid_sum == tg2.tgid);
		require(fake_xpmem_ap_destroyable_calls == 1);
		require(fake_xpmem_ap_destroyable_ap == &ap);
		require(fake_xpmem_release_ap_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, ap.flags);
		mix_signed(&digest, fake_xpmem_att_ref_id_sum);
		mix_signed(&digest, fake_xpmem_detach_att_id_sum);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_list_del_calls);
		mix_signed(&digest, fake_xpmem_tg_deref_tgid_sum);
		mix_signed(&digest, fake_xpmem_release_ap_log_event_sum);
		mix_signed(&digest, fake_xpmem_release_ap_log_value_sum);

		fake_xpmem_release_ap_reset(&tg, &tg2, &seg, &ap, &att,
			&att2);
		ap.flags = XPMEM_FLAG_DESTROYING | 0x20;
		ret = xpmem_release_ap_body_result(&tg, &ap,
			&release_ap_offsets, rwlock_node,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_list_del_init, fake_xpmem_att_ref_cb,
			fake_xpmem_detach_att_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb,
			fake_xpmem_ap_destroyable_cb,
			fake_xpmem_release_ap_log);
		require(ret == 0);
		require(ap.flags == (XPMEM_FLAG_DESTROYING | 0x20));
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_spin_unlock_calls == 1);
		require(fake_xpmem_att_ref_calls == 0);
		require(fake_xpmem_detach_att_calls == 0);
		require(fake_xpmem_rwlock_lock_calls == 0);
		require(fake_xpmem_list_del_calls == 0);
		require(fake_xpmem_seg_deref_calls == 0);
		require(fake_xpmem_tg_deref_calls == 0);
		require(fake_xpmem_ap_destroyable_calls == 0);
		require(fake_xpmem_release_ap_log_count == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, ap.flags);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix_signed(&digest, fake_xpmem_release_ap_log_event_sum);

		fake_xpmem_release_aps_reset(&tg, &ap, &ap2);
		ret = xpmem_release_aps_of_tg_body_result(&tg,
			&release_aps_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_remove_segs_log);
		require(ret == 0);
		require(fake_xpmem_rwlock_lock_calls == 10);
		require(fake_xpmem_rwlock_unlock_calls == 10);
		require(fake_xpmem_rwlock_last_lock ==
			&tg.ap_hashtable[7].lock);
		require(fake_xpmem_ap_ref_calls == 2);
		require(fake_xpmem_ap_deref_calls == 2);
		require(fake_xpmem_ap_ref_id_sum == ap.apid + ap2.apid);
		require(fake_xpmem_ap_deref_id_sum == ap.apid + ap2.apid);
		require(fake_xpmem_release_ap_cb_calls == 2);
		require(fake_xpmem_release_ap_cb_id_sum == ap.apid + ap2.apid);
		require(fake_xpmem_release_ap_cb_tg == &tg);
		require(tg.ap_hashtable[1].list.next ==
			&tg.ap_hashtable[1].list);
		require(tg.ap_hashtable[5].list.next ==
			&tg.ap_hashtable[5].list);
		require(ap.ap_hashlist.next == &ap.ap_hashlist);
		require(ap2.ap_hashlist.next == &ap2.ap_hashlist);
		require(fake_xpmem_remove_segs_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_ap_ref_id_sum);
		mix_signed(&digest, fake_xpmem_release_ap_cb_id_sum);
		mix_signed(&digest, fake_xpmem_remove_segs_log_event_sum);

		fake_xpmem_release_aps_reset(&tg, &ap, &ap2);
		for (int i = 0; i < 8; i++) {
			tg.ap_hashtable[i].list.next =
				&tg.ap_hashtable[i].list;
			tg.ap_hashtable[i].list.prev =
				&tg.ap_hashtable[i].list;
		}
		ret = xpmem_release_aps_of_tg_body_result(&tg,
			&release_aps_offsets, rwlock_node,
			fake_xpmem_rwlock_lock, fake_xpmem_rwlock_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_remove_segs_log);
		require(ret == 0);
		require(fake_xpmem_rwlock_lock_calls == 8);
		require(fake_xpmem_rwlock_unlock_calls == 8);
		require(fake_xpmem_ap_ref_calls == 0);
		require(fake_xpmem_release_ap_cb_calls == 0);
		require(fake_xpmem_ap_deref_calls == 0);
		require(fake_xpmem_remove_segs_log_count == 2);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_rwlock_lock_calls +
			fake_xpmem_rwlock_unlock_calls);
		mix_signed(&digest, fake_xpmem_remove_segs_log_event_sum);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_destroy_tg_body_result(&tg,
			fake_xpmem_tg_destroyable_cb,
			fake_xpmem_tg_deref_cb);
		require(ret == 0);
		require(fake_xpmem_tg_destroyable_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_tg_destroyable_tgid_sum == tg.tgid);
		require(fake_xpmem_tg_deref_tgid_sum == tg.tgid);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_destroyable_tgid_sum);
		mix_signed(&digest, fake_xpmem_tg_deref_tgid_sum);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_remove_body_result(seg.segid, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == 0);
		require(fake_xpmem_tg_ref_by_id_calls == 1);
		require(fake_xpmem_tg_ref_by_id_value == seg.segid);
		require(fake_xpmem_seg_ref_by_id_calls == 1);
		require(fake_xpmem_seg_ref_by_id_parent == &tg);
		require(fake_xpmem_seg_ref_by_id_value == seg.segid);
		require(fake_xpmem_remove_seg_cb_calls == 1);
		require(fake_xpmem_remove_seg_cb_tg == &tg);
		require(fake_xpmem_seg_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_ref_by_id_value);
		mix_signed(&digest, fake_xpmem_seg_ref_by_id_value);
		mix_signed(&digest, fake_xpmem_remove_seg_cb_id_sum);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_remove_body_result(0, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -22);
		require(fake_xpmem_tg_ref_by_id_calls == 0);
		mix_signed(&digest, ret);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_remove_body_result(seg.segid, tg.tgid + 1,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -13);
		require(fake_xpmem_tg_ref_by_id_calls == 1);
		require(fake_xpmem_seg_ref_by_id_calls == 0);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		fake_xpmem_seg_ref_by_id_rc = (void *)-2L;
		ret = xpmem_remove_body_result(seg.segid, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_seg_ref_by_id_cb, fake_xpmem_remove_seg_cb,
			fake_xpmem_seg_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -2);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_remove_seg_cb_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_release_body_result(ap.apid, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_ap_ref_by_id_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == 0);
		require(fake_xpmem_tg_ref_by_id_calls == 1);
		require(fake_xpmem_tg_ref_by_id_value == ap.apid);
		require(fake_xpmem_ap_ref_by_id_calls == 1);
		require(fake_xpmem_ap_ref_by_id_parent == &tg);
		require(fake_xpmem_ap_ref_by_id_value == ap.apid);
		require(fake_xpmem_release_ap_cb_calls == 1);
		require(fake_xpmem_release_ap_cb_tg == &tg);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_ref_by_id_value);
		mix_signed(&digest, fake_xpmem_ap_ref_by_id_value);
		mix_signed(&digest, fake_xpmem_release_ap_cb_id_sum);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_release_body_result(0, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_ap_ref_by_id_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -22);
		require(fake_xpmem_tg_ref_by_id_calls == 0);
		mix_signed(&digest, ret);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		ret = xpmem_release_body_result(ap.apid, tg.tgid + 1,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_ap_ref_by_id_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -13);
		require(fake_xpmem_ap_ref_by_id_calls == 0);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_release_wrapper_reset(&tg, &seg, &ap);
		fake_xpmem_ap_ref_by_id_rc = (void *)-2L;
		ret = xpmem_release_body_result(ap.apid, tg.tgid,
			&tg_id_offsets, fake_xpmem_tg_ref_by_id_cb,
			fake_xpmem_ap_ref_by_id_cb, fake_xpmem_release_ap_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_tg_deref_cb);
		require(ret == -2);
		require(fake_xpmem_tg_deref_calls == 1);
		require(fake_xpmem_release_ap_cb_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_remove_range_rc = -14;
		ret = xpmem_vm_munmap_body_result(&vm, 0x7000, 0x3000,
			fake_xpmem_begin_pending, fake_xpmem_remove_range,
			fake_xpmem_finish_pending);
		require(ret == -14);
		require(fake_xpmem_begin_pending_calls == 1);
		require(fake_xpmem_finish_pending_calls == 1);
		require(fake_xpmem_remove_range_calls == 1);
		require(fake_xpmem_remove_range_vm == &vm);
		require(fake_xpmem_remove_range_start == 0x7000);
		require(fake_xpmem_remove_range_end == 0xa000);
		require(fake_xpmem_remove_range_ro_freed == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_begin_pending_calls +
			fake_xpmem_finish_pending_calls +
			fake_xpmem_remove_range_calls);
		mix(&digest, fake_xpmem_remove_range_end);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_lookup_range_rc = NULL;
		ret = xpmem_detach_body_result(att.at_vaddr, tg.tgid, &vm,
			&detach_offsets, fake_xpmem_write_lock_noirq,
			fake_xpmem_write_unlock_noirq, fake_xpmem_lookup_range,
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_ap_deref_cb,
			fake_xpmem_unpin_pages, fake_xpmem_munmap,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(fake_xpmem_write_lock_noirq_calls == 1);
		require(fake_xpmem_write_unlock_noirq_calls == 1);
		require(fake_xpmem_lookup_range_calls == 1);
		require(fake_xpmem_att_ref_calls == 0);
		require(fake_xpmem_unpin_pages_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_write_lock_noirq_calls +
			fake_xpmem_write_unlock_noirq_calls +
			fake_xpmem_lookup_range_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		range.private_data = NULL;
		ret = xpmem_detach_body_result(att.at_vaddr, tg.tgid, &vm,
			&detach_offsets, fake_xpmem_write_lock_noirq,
			fake_xpmem_write_unlock_noirq, fake_xpmem_lookup_range,
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_ap_deref_cb,
			fake_xpmem_unpin_pages, fake_xpmem_munmap,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == -22);
		require(fake_xpmem_write_lock_noirq_calls == 1);
		require(fake_xpmem_write_unlock_noirq_calls == 1);
		require(fake_xpmem_att_ref_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_write_unlock_noirq_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		att.flags = XPMEM_FLAG_DESTROYING | XPMEM_FLAG_VALIDPTEs |
			0x20;
		ret = xpmem_detach_body_result(att.at_vaddr, tg.tgid, &vm,
			&detach_offsets, fake_xpmem_write_lock_noirq,
			fake_xpmem_write_unlock_noirq, fake_xpmem_lookup_range,
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_ap_deref_cb,
			fake_xpmem_unpin_pages, fake_xpmem_munmap,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(fake_xpmem_att_ref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_ap_ref_calls == 0);
		require(fake_xpmem_unpin_pages_calls == 0);
		require(att.flags == (XPMEM_FLAG_DESTROYING |
			XPMEM_FLAG_VALIDPTEs | 0x20));
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_ref_id_sum);
		mix_signed(&digest, att.flags);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		ret = xpmem_detach_body_result(att.at_vaddr, tg.tgid + 1, &vm,
			&detach_offsets, fake_xpmem_write_lock_noirq,
			fake_xpmem_write_unlock_noirq, fake_xpmem_lookup_range,
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_ap_deref_cb,
			fake_xpmem_unpin_pages, fake_xpmem_munmap,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == -13);
		require(att.flags == (XPMEM_FLAG_VALIDPTEs | 0x20));
		require(fake_xpmem_ap_ref_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_unpin_pages_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_ap_ref_id_sum +
			fake_xpmem_ap_deref_id_sum);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_munmap_rc = -14;
		ret = xpmem_detach_body_result(att.at_vaddr, tg.tgid, &vm,
			&detach_offsets, fake_xpmem_write_lock_noirq,
			fake_xpmem_write_unlock_noirq, fake_xpmem_lookup_range,
			fake_xpmem_att_ref_cb, fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_ap_ref_cb, fake_xpmem_ap_deref_cb,
			fake_xpmem_unpin_pages, fake_xpmem_munmap,
			fake_xpmem_spin_lock, fake_xpmem_spin_unlock,
			fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == NULL);
		require(att.flags == (XPMEM_FLAG_DESTROYING | 0x20));
		require(fake_xpmem_unpin_pages_calls == 1);
		require(fake_xpmem_unpin_pages_seg == &seg);
		require(fake_xpmem_unpin_pages_vm == &vm);
		require(fake_xpmem_unpin_pages_vaddr == att.at_vaddr);
		require(fake_xpmem_unpin_pages_size == att.at_size);
		require(fake_xpmem_munmap_calls == 1);
		require(fake_xpmem_munmap_vm == &vm);
		require(fake_xpmem_munmap_addr == range.start);
		require(fake_xpmem_munmap_len == att.at_size);
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_spin_unlock_calls == 1);
		require(fake_xpmem_list_del_calls == 1);
		require(att.att_list.next == &att.att_list);
		require(fake_xpmem_att_destroyable_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_unpin_pages_calls +
			fake_xpmem_munmap_calls + fake_xpmem_list_del_calls);
		mix(&digest, fake_xpmem_munmap_addr);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		att.flags = XPMEM_FLAG_DESTROYING | XPMEM_FLAG_VALIDPTEs |
			0x20;
		ret = xpmem_detach_att_body_result(&ap, &att,
			&detach_att_offsets, fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(fake_xpmem_att_write_lock_calls == 1);
		require(fake_xpmem_att_write_unlock_calls == 1);
		require(fake_xpmem_read_lock_noirq_calls == 0);
		require(fake_xpmem_unpin_pages_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_write_lock_calls +
			fake_xpmem_att_write_unlock_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_lookup_range_rc = NULL;
		ret = xpmem_detach_att_body_result(&ap, &att,
			&detach_att_offsets, fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(att.flags == (XPMEM_FLAG_DESTROYING |
			XPMEM_FLAG_VALIDPTEs | 0x20));
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_list_del_calls == 1);
		require(fake_xpmem_att_destroyable_calls == 1);
		require(fake_xpmem_munmap_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_read_lock_noirq_calls +
			fake_xpmem_read_unlock_noirq_calls +
			fake_xpmem_list_del_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_munmap_rc = -14;
		ret = xpmem_detach_att_body_result(&ap, &att,
			&detach_att_offsets, fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == NULL);
		require(att.flags == (XPMEM_FLAG_DESTROYING | 0x20));
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_unpin_pages_calls == 1);
		require(fake_xpmem_munmap_calls == 1);
		require(fake_xpmem_munmap_addr == range.start);
		require(fake_xpmem_list_del_calls == 1);
		require(fake_xpmem_att_destroyable_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_unpin_pages_calls +
			fake_xpmem_munmap_calls + fake_xpmem_list_del_calls);
		mix(&digest, fake_xpmem_munmap_addr);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		ret = xpmem_clear_ptes_body_result(&seg, &clear_ptes_offsets,
			fake_xpmem_clear_range);
		require(ret == 0);
		require(fake_xpmem_clear_range_calls == 1);
		require(fake_xpmem_clear_range_object == &seg);
		require(fake_xpmem_clear_range_start == seg.vaddr);
		require(fake_xpmem_clear_range_end == seg.vaddr + seg.size);
		mix_signed(&digest, ret);
		mix(&digest, fake_xpmem_clear_range_end);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		ret = xpmem_clear_ptes_range_body_result(&seg, 0x6100,
			0x7100, &clear_ptes_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_ap_ref_cb,
			fake_xpmem_clear_range, fake_xpmem_ap_deref_cb);
		require(ret == 0);
		require(fake_xpmem_spin_lock_calls == 2);
		require(fake_xpmem_spin_unlock_calls == 2);
		require(fake_xpmem_ap_ref_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_clear_range_calls == 1);
		require(fake_xpmem_clear_range_object == &ap);
		require(fake_xpmem_clear_range_start == 0x6100);
		require(fake_xpmem_clear_range_end == 0x7100);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);
		mix(&digest, fake_xpmem_clear_range_start);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		memset(&att2, 0, sizeof(att2));
		att2.id = 0x303;
		att2.ap = &ap;
		att2.flags = 0;
		ap.att_list.next = &att.att_list;
		ap.att_list.prev = &att2.att_list;
		att.att_list.next = &att2.att_list;
		att.att_list.prev = &ap.att_list;
		att2.att_list.next = &ap.att_list;
		att2.att_list.prev = &att.att_list;
		ret = xpmem_clear_ptes_of_ap_body_result(&ap, 0x6000,
			0x7000, &clear_ptes_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_att_ref_cb,
			fake_xpmem_clear_range, fake_xpmem_att_deref_cb);
		require(ret == 0);
		require(fake_xpmem_att_ref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_att_ref_id_sum == att.id);
		require(fake_xpmem_clear_range_calls == 1);
		require(fake_xpmem_clear_range_object == &att);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_ref_id_sum);
		mix_signed(&digest, fake_xpmem_spin_lock_calls +
			fake_xpmem_spin_unlock_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		ret = xpmem_clear_ptes_of_att_body_result(&att, att.vaddr,
			att.vaddr + att.at_size, &clear_ptes_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap);
		require(ret == 0);
		require((att.flags & XPMEM_FLAG_VALIDPTEs) == 0);
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_att_write_lock_calls == 2);
		require(fake_xpmem_att_write_unlock_calls == 2);
		require(fake_xpmem_unpin_pages_calls == 1);
		require(fake_xpmem_unpin_pages_seg == &seg);
		require(fake_xpmem_unpin_pages_vaddr == att.at_vaddr);
		require(fake_xpmem_munmap_calls == 1);
		require(fake_xpmem_munmap_addr == att.at_vaddr);
		require(fake_xpmem_munmap_len == att.at_size);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_att_write_lock_calls +
			fake_xpmem_att_write_unlock_calls);
		mix(&digest, fake_xpmem_munmap_addr);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		fake_xpmem_lookup_range_rc = NULL;
		ret = xpmem_clear_ptes_of_att_body_result(&att, att.vaddr,
			att.vaddr + att.at_size, &clear_ptes_offsets,
			fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap);
		require(ret == 0);
		require((att.flags & XPMEM_FLAG_VALIDPTEs) != 0);
		require(fake_xpmem_unpin_pages_calls == 1);
		require(fake_xpmem_munmap_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_unpin_pages_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		ret = xpmem_clear_ptes_of_att_body_result(&att,
			att.vaddr + att.at_size + 0x1000,
			att.vaddr + att.at_size + 0x2000,
			&clear_ptes_offsets, fake_xpmem_read_lock_noirq,
			fake_xpmem_read_unlock_noirq,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_unpin_pages,
			fake_xpmem_munmap);
		require(ret == 0);
		require(fake_xpmem_unpin_pages_calls == 0);
		require(fake_xpmem_lookup_range_calls == 0);
		require(fake_xpmem_munmap_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_write_lock_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		range.private_data = NULL;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(fake_xpmem_att_ref_calls == 0);
		require(fake_xpmem_att_write_lock_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_ref_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		att.flags |= XPMEM_FLAG_DESTROYING;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == &att);
		require(fake_xpmem_att_ref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_list_del_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_ref_id_sum);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		range.start = att.at_vaddr;
		range.end = att.at_vaddr + att.at_size;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require((att.flags & XPMEM_FLAG_DESTROYING) != 0);
		require(fake_xpmem_ap_ref_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_list_del_calls == 1);
		require(att.att_list.next == &att.att_list);
		require(fake_xpmem_att_destroyable_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, att.flags);
		mix_signed(&digest, fake_xpmem_list_del_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		memset(&range2, 0, sizeof(range2));
		range.start = att.at_vaddr;
		range.end = att.at_vaddr + 0x400;
		range2.start = range.end;
		range2.end = att.at_vaddr + att.at_size;
		range2.private_data = &att;
		fake_xpmem_lookup_range_rc = &range2;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == NULL);
		require(att.at_vaddr == range2.start);
		require(att.at_size == range2.end - range2.start);
		require(fake_xpmem_lookup_range_calls == 1);
		require(fake_xpmem_list_del_calls == 0);
		mix_signed(&digest, ret);
		mix(&digest, att.at_vaddr);
		mix(&digest, att.at_size);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		memset(&range2, 0, sizeof(range2));
		memset(&range3, 0, sizeof(range3));
		range.start = att.at_vaddr + 0x400;
		range.end = att.at_vaddr + 0x800;
		range2.start = att.at_vaddr;
		range2.end = range.start;
		range2.private_data = &att;
		range3.start = range.end;
		range3.end = att.at_vaddr + att.at_size;
		range3.private_data = &att;
		fake_xpmem_lookup_range_seq[0] = &range3;
		fake_xpmem_lookup_range_seq[1] = &range2;
		fake_xpmem_lookup_range_seq_len = 2;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == NULL);
		require(range3.private_data == NULL);
		require(att.at_vaddr == range2.start);
		require(att.at_size == range2.end - range2.start);
		require(fake_xpmem_lookup_range_calls == 2);
		mix_signed(&digest, ret);
		mix(&digest, att.at_vaddr);
		mix(&digest, att.at_size);
		mix_signed(&digest, fake_xpmem_lookup_range_calls);

		fake_xpmem_detach_reset(&vm, &range, &tg, &seg, &ap, &att);
		range.start = att.at_vaddr + 0x400;
		range.end = att.at_vaddr + 0x800;
		fake_xpmem_lookup_range_seq[0] = NULL;
		fake_xpmem_lookup_range_seq_len = 1;
		ret = xpmem_remove_process_memory_range_body_result(&vm,
			&range, &remove_vmr_offsets, fake_xpmem_att_ref_cb,
			fake_xpmem_att_deref_cb,
			fake_xpmem_att_write_lock,
			fake_xpmem_att_write_unlock,
			fake_xpmem_lookup_range, fake_xpmem_ap_ref_cb,
			fake_xpmem_ap_deref_cb, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock, fake_xpmem_list_del_init,
			fake_xpmem_att_destroyable_cb);
		require(ret == 0);
		require(range.private_data == &att);
		require(att.at_vaddr == 0x4200);
		require(att.at_size == 0x1000);
		require(fake_xpmem_lookup_range_calls == 1);
		mix_signed(&digest, ret);
		mix(&digest, att.at_vaddr);
		mix_signed(&digest, fake_xpmem_lookup_range_calls);

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			fake_xpmem_lookup_range_rc = NULL;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_lookup_range_calls == 1);
			require(fake_xpmem_next_range_calls == 0);
			require(fake_xpmem_free_range_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, ro_freed);
			mix_signed(&digest, fake_xpmem_lookup_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.start = 0x6000;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_next_range_calls == 0);
			require(fake_xpmem_free_range_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, ro_freed);
			mix_signed(&digest, fake_xpmem_free_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_next_range_calls == 1);
			require(fake_xpmem_remove_private_range_calls == 1);
			require(fake_xpmem_remove_private_range_arg == &range);
			require(fake_xpmem_free_range_calls == 1);
			require(fake_xpmem_free_range_arg == &range);
			require(fake_xpmem_remove_process_range_log_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, ro_freed);
			mix_signed(&digest, fake_xpmem_remove_private_range_calls +
				fake_xpmem_free_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.flag = 0;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 1);
			require(fake_xpmem_free_range_calls == 1);
			mix_signed(&digest, ret);
			mix_signed(&digest, ro_freed);
			mix_signed(&digest, fake_xpmem_free_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.start = 0x3000;
			range.end = 0x5000;
			range2.start = 0x4000;
			range2.end = 0x5000;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_split_range_calls == 1);
			require(fake_xpmem_split_range_set_out_calls == 1);
			require(fake_xpmem_split_range_null_out_calls == 0);
			require(fake_xpmem_split_range_addr == 0x4000);
			require(fake_xpmem_remove_private_range_arg == &range2);
			require(fake_xpmem_free_range_arg == &range2);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_split_range_calls);
			mix(&digest, fake_xpmem_split_range_addr);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.start = 0x4000;
			range.end = 0x6000;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_split_range_calls == 1);
			require(fake_xpmem_split_range_set_out_calls == 0);
			require(fake_xpmem_split_range_null_out_calls == 1);
			require(fake_xpmem_split_range_addr == 0x5000);
			require(fake_xpmem_free_range_arg == &range);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_split_range_null_out_calls);
			mix(&digest, fake_xpmem_split_range_addr);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range2.start = 0x5000;
			range2.end = 0x5800;
			fake_xpmem_next_range_seq[0] = &range2;
			fake_xpmem_next_range_seq_len = 1;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5800, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == 0);
			require(ro_freed == 0);
			require(fake_xpmem_next_range_calls == 2);
			require(fake_xpmem_free_range_calls == 2);
			require(fake_xpmem_remove_private_range_calls == 2);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_next_range_calls);
			mix_signed(&digest, fake_xpmem_free_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.start = 0x3000;
			range.end = 0x5000;
			fake_xpmem_split_range_rc = -5;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == -5);
			require(ro_freed == 0x55);
			require(fake_xpmem_free_range_calls == 0);
			require(fake_xpmem_remove_process_range_log_calls == 1);
			require(fake_xpmem_remove_process_range_log_error_sum == -5);
			require(fake_xpmem_remove_process_range_log_free_sum == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest,
				fake_xpmem_remove_process_range_log_error_sum);
			mix_signed(&digest, fake_xpmem_free_range_calls);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			fake_xpmem_free_range_rc = -6;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == -6);
			require(ro_freed == 0x55);
			require(fake_xpmem_remove_private_range_calls == 1);
			require(fake_xpmem_remove_process_range_log_calls == 1);
			require(fake_xpmem_remove_process_range_log_error_sum == -6);
			require(fake_xpmem_remove_process_range_log_free_sum == 1);
			mix_signed(&digest, ret);
			mix_signed(&digest,
				fake_xpmem_remove_process_range_log_error_sum);
			mix_signed(&digest,
				fake_xpmem_remove_process_range_log_free_sum);
		}

		{
			int ro_freed = 0x55;

			fake_xpmem_remove_process_range_reset(&vm, &range,
				&range2, &range3);
			range.start = 0x3000;
			fake_xpmem_split_range_new_rc = NULL;
			ret = xpmem_remove_process_range_body_result(&vm,
				0x4000, 0x5000, &ro_freed,
				&remove_range_offsets, fake_xpmem_lookup_range,
				fake_xpmem_next_range, fake_xpmem_split_range,
				fake_xpmem_remove_private_range,
				fake_xpmem_free_range,
				fake_xpmem_remove_process_range_log);
			require(ret == -22);
			require(ro_freed == 0x55);
			require(fake_xpmem_free_range_calls == 0);
			require(fake_xpmem_remove_process_range_log_calls == 0);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_xpmem_split_range_calls);
			mix_signed(&digest, fake_xpmem_free_range_calls);
		}

		fake_xpmem_free_process_range_reset(&vm, &asp, &range,
			&range2);
		ret = xpmem_free_process_range_body_result(&vm, &range,
			&free_range_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock,
			fake_xpmem_free_process_pt_clear,
			fake_xpmem_free_process_memobj_unref,
			fake_xpmem_free_process_erase,
			fake_xpmem_free_process_free,
			fake_xpmem_free_process_log);
		require(ret == 0);
		require(fake_xpmem_spin_lock_calls == 1);
		require(fake_xpmem_spin_unlock_calls == 1);
		require(fake_xpmem_free_process_pt_clear_calls == 1);
		require(fake_xpmem_free_process_pt_clear_page_table ==
			asp.page_table);
		require(fake_xpmem_free_process_pt_clear_vm == &vm);
		require(fake_xpmem_free_process_pt_clear_start == range.start);
		require(fake_xpmem_free_process_pt_clear_end == range.end);
		require(fake_xpmem_free_process_memobj_unref_calls == 1);
		require(fake_xpmem_free_process_memobj_unref_arg ==
			range.memobj);
		require(fake_xpmem_free_process_erase_calls == 1);
		require(fake_xpmem_free_process_erase_root ==
			&vm.vm_range_tree);
		require(fake_xpmem_free_process_erase_node == &range.rb_node);
		require(vm.range_cache[0] == NULL);
		require(vm.range_cache[1] == &range2);
		require(vm.range_cache[2] == NULL);
		require(fake_xpmem_free_process_free_arg == &range);
		require(fake_xpmem_free_process_log_calls == 0);
		mix_signed(&digest, ret);
		mix(&digest, fake_xpmem_free_process_pt_clear_start ^
			fake_xpmem_free_process_pt_clear_end);
		mix_signed(&digest, fake_xpmem_free_process_memobj_unref_calls);

		fake_xpmem_free_process_range_reset(&vm, &asp, &range,
			&range2);
		fake_xpmem_free_process_pt_clear_rc = -2;
		ret = xpmem_free_process_range_body_result(&vm, &range,
			&free_range_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock,
			fake_xpmem_free_process_pt_clear,
			fake_xpmem_free_process_memobj_unref,
			fake_xpmem_free_process_erase,
			fake_xpmem_free_process_free,
			fake_xpmem_free_process_log);
		require(ret == 0);
		require(fake_xpmem_free_process_log_calls == 0);
		require(fake_xpmem_free_process_free_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_free_process_log_calls);
		mix_signed(&digest, fake_xpmem_free_process_free_calls);

		fake_xpmem_free_process_range_reset(&vm, &asp, &range,
			&range2);
		fake_xpmem_free_process_pt_clear_rc = -5;
		ret = xpmem_free_process_range_body_result(&vm, &range,
			&free_range_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock,
			fake_xpmem_free_process_pt_clear,
			fake_xpmem_free_process_memobj_unref,
			fake_xpmem_free_process_erase,
			fake_xpmem_free_process_free,
			fake_xpmem_free_process_log);
		require(ret == 0);
		require(fake_xpmem_free_process_log_calls == 1);
		require(fake_xpmem_free_process_log_event_sum == 1);
		require(fake_xpmem_free_process_log_error_sum == -5);
		require(fake_xpmem_free_process_log_vm == &vm);
		require(fake_xpmem_free_process_log_range == &range);
		require(fake_xpmem_free_process_free_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_free_process_log_error_sum);
		mix_signed(&digest, fake_xpmem_free_process_free_calls);

		fake_xpmem_free_process_range_reset(&vm, &asp, &range,
			&range2);
		range.memobj = NULL;
		ret = xpmem_free_process_range_body_result(&vm, &range,
			&free_range_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock,
			fake_xpmem_free_process_pt_clear,
			fake_xpmem_free_process_memobj_unref,
			fake_xpmem_free_process_erase,
			fake_xpmem_free_process_free,
			fake_xpmem_free_process_log);
		require(ret == 0);
		require(fake_xpmem_free_process_memobj_unref_calls == 0);
		require(fake_xpmem_free_process_free_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest,
			fake_xpmem_free_process_memobj_unref_calls);

		fake_xpmem_free_process_range_reset(&vm, &asp, &range,
			&range2);
		ret = xpmem_free_process_range_body_result(NULL, &range,
			&free_range_offsets, fake_xpmem_spin_lock,
			fake_xpmem_spin_unlock,
			fake_xpmem_free_process_pt_clear,
			fake_xpmem_free_process_memobj_unref,
			fake_xpmem_free_process_erase,
			fake_xpmem_free_process_free,
			fake_xpmem_free_process_log);
		require(ret == -22);
		require(fake_xpmem_free_process_pt_clear_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_free_process_pt_clear_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		range.private_data = NULL;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == -14);
		require(fake_xpmem_att_ref_calls == 0);
		require(fake_xpmem_update_fault_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_att_ref_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == 0);
		require(att.at_vaddr == range.start);
		require(att.at_vmr == &range);
		require(fake_xpmem_update_fault_calls == 3);
		require(fake_xpmem_update_fault_vm == &vm);
		require(fake_xpmem_update_fault_range == &range);
		require(fake_xpmem_update_fault_vaddr == 0x6000);
		require(fake_xpmem_update_fault_vaddr_sum == 0xf000);
		require(fake_xpmem_update_fault_reason_sum == 0);
		require(fake_xpmem_update_fault_page_in_sum == 3);
		require(fake_xpmem_pt_lookup_pte_calls == 3);
		require(fake_xpmem_pt_lookup_pte_page_table == asp.page_table);
		require(fake_xpmem_pt_lookup_pte_vaddr == 0x6000);
		require(fake_xpmem_pt_lookup_pte_vaddr_sum == 0xf000);
		require(fake_xpmem_pt_lookup_pte_pgshift == 12);
		require(fake_xpmem_pte_present_calls == 3);
		require(fake_xpmem_update_log_calls == 0);
		require(fake_xpmem_att_ref_calls == 1);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_ap_ref_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_tg_ref_object_calls == 2);
		require(fake_xpmem_tg_ref_object_tgid_sum ==
			tg.tgid + tg2.tgid);
		require(fake_xpmem_tg_deref_calls == 2);
		require(fake_xpmem_tg_deref_tgid_sum ==
			tg.tgid + tg2.tgid);
		require(fake_xpmem_seg_ref_calls == 1);
		require(fake_xpmem_seg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix(&digest, att.at_vaddr);
		mix_signed(&digest, fake_xpmem_update_fault_calls);
		mix(&digest, fake_xpmem_update_fault_vaddr_sum);
		mix_signed(&digest, fake_xpmem_tg_ref_object_tgid_sum);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		fake_xpmem_pt_lookup_pte_rc = NULL;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == 0);
		require(fake_xpmem_update_fault_calls == 3);
		require(fake_xpmem_pt_lookup_pte_calls == 3);
		require(fake_xpmem_pte_present_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_pte_present_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		ap.flags = XPMEM_FLAG_DESTROYING;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == -14);
		require(fake_xpmem_seg_ref_calls == 0);
		require(fake_xpmem_update_fault_calls == 0);
		require(fake_xpmem_att_deref_calls == 1);
		require(fake_xpmem_ap_deref_calls == 1);
		require(fake_xpmem_tg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_seg_ref_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		seg.flags = XPMEM_FLAG_DESTROYING;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == -2);
		require(att.at_vmr == NULL);
		require(fake_xpmem_update_fault_calls == 0);
		require(fake_xpmem_tg_deref_calls == 2);
		require(fake_xpmem_seg_deref_calls == 1);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_tg_deref_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		att.flags = XPMEM_FLAG_DESTROYING;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == 0);
		require(att.at_vaddr == range.start);
		require(att.at_vmr == &range);
		require(fake_xpmem_update_fault_calls == 0);
		require(fake_xpmem_pt_lookup_pte_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_update_fault_calls);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		fake_xpmem_update_fault_rc = -5;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range, tg.tgid, 1);
		require(ret == -5);
		require(fake_xpmem_update_fault_calls == 3);
		require(fake_xpmem_update_log_calls == 3);
		require(fake_xpmem_update_log_event_sum == 3);
		require(fake_xpmem_update_log_error_sum == -15);
		require(fake_xpmem_update_log_vm == &vm);
		require(fake_xpmem_update_log_range == &range);
		require(fake_xpmem_update_log_vaddr_sum == 0xf000);
		require(fake_xpmem_pt_lookup_pte_calls == 3);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_update_log_error_sum);
		mix(&digest, fake_xpmem_update_log_vaddr_sum);

		fake_xpmem_update_page_table_reset(&vm, &asp, &range,
			&tg, &tg2, &seg, &ap, &att, &pte1);
		range.end = range.start;
		ap.mode = XPMEM_RDONLY;
		ret = XPMEM_UPDATE_PAGE_TABLE_CALL(&vm, &range,
			tg.tgid + 1, 1);
		require(ret == 0);
		require(fake_xpmem_bug_on_calls == 2);
		require(fake_xpmem_bug_on_condition_sum == 2);
		require(fake_xpmem_update_fault_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_bug_on_condition_sum);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		range.private_data = NULL;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == -14);
		require(fake_xpmem_att_ref_calls == 0);
		require(fake_xpmem_fault_ensure_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_fault_ensure_calls);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == 0);
		require(fake_xpmem_fault_ensure_calls == 1);
		require(fake_xpmem_fault_ensure_seg == &seg);
		require(fake_xpmem_fault_ensure_vaddr == 0xa000);
		require(fake_xpmem_fault_ensure_page_in == 1);
		require(fake_xpmem_vaddr_to_pte_calls == 1);
		require(fake_xpmem_pt_lookup_pte_calls == 1);
		require(fake_xpmem_pt_lookup_pte_page_table == asp.page_table);
		require(fake_xpmem_pt_lookup_pte_vaddr == 0x5000);
		require(fake_xpmem_pte_present_calls == 2);
		require(fake_xpmem_pte_phys_calls == 1);
		require(fake_xpmem_adjust_page_calls == 1);
		require(fake_xpmem_vrflag_calls == 1);
		require(fake_xpmem_vrflag_flag == range.flag);
		require(fake_xpmem_vrflag_reason == 0x44);
		require(fake_xpmem_pt_set_pte_calls == 1);
		require(fake_xpmem_pt_set_pte_page_table == asp.page_table);
		require(fake_xpmem_pt_set_pte_pte == &pte1);
		require(fake_xpmem_pt_set_pte_pgsize == PAGE_SIZE);
		require(fake_xpmem_pt_set_pte_phys == 0x300000);
		require(fake_xpmem_pt_set_pte_attr == fake_xpmem_vrflag_rc);
		require(fake_xpmem_pt_set_range_calls == 0);
		require(fake_xpmem_flush_single_calls == 1);
		require(fake_xpmem_flush_single_vaddr == 0x5000);
		require((att.flags & XPMEM_FLAG_VALIDPTEs) != 0);
		require(fake_xpmem_fault_log_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_fault_ensure_calls);
		mix(&digest, fake_xpmem_pt_set_pte_phys);
		mix_signed(&digest, att.flags);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		pte1.present = 1;
		pte1.phys = 0x300000;
		tg2.n_pinned = 3;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == 0);
		require(fake_xpmem_pte_phys_calls == 2);
		require(fake_xpmem_pt_set_pte_calls == 0);
		require(fake_xpmem_pt_set_range_calls == 0);
		require(fake_xpmem_atomic_dec_calls == 1);
		require(tg2.n_pinned == 2);
		require(fake_xpmem_flush_single_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, tg2.n_pinned);
		mix_signed(&digest, fake_xpmem_pte_phys_calls);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		fake_xpmem_pt_lookup_pte_rc = NULL;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == 0);
		require(fake_xpmem_pt_set_pte_calls == 0);
		require(fake_xpmem_pt_set_range_calls == 1);
		require(fake_xpmem_pt_set_range_page_table == asp.page_table);
		require(fake_xpmem_pt_set_range_vm == &vm);
		require(fake_xpmem_pt_set_range_start == 0x5000);
		require(fake_xpmem_pt_set_range_end == 0x6000);
		require(fake_xpmem_pt_set_range_phys == 0x300000);
		require(fake_xpmem_pt_set_range_attr == fake_xpmem_vrflag_rc);
		require(fake_xpmem_pt_set_range_pgshift == range.pgshift);
		require(fake_xpmem_pt_set_range_vmr == &range);
		require(fake_xpmem_pt_set_range_replace == 1);
		require(fake_xpmem_flush_single_calls == 1);
		mix_signed(&digest, ret);
		mix(&digest, fake_xpmem_pt_set_range_start ^
			fake_xpmem_pt_set_range_end);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x3000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == -14);
		require(fake_xpmem_fault_ensure_calls == 0);
		require(fake_xpmem_fault_log_calls == 1);
		require(fake_xpmem_fault_log_event_sum == 2);
		require(fake_xpmem_fault_log_error_sum == -14);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_fault_log_event_sum);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		fake_xpmem_fault_ensure_rc = -2;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == -2);
		require(fake_xpmem_fault_ensure_calls == 1);
		require(fake_xpmem_vaddr_to_pte_calls == 0);
		require(fake_xpmem_pt_set_pte_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_vaddr_to_pte_calls);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		memset(&current_vm, 0, sizeof(current_vm));
		fake_xpmem_vaddr_to_pte_ptes[0] = NULL;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 0,
			tg.tgid, &current_vm);
		require(ret == 0);
		require(fake_xpmem_read_lock_noirq_calls == 1);
		require(fake_xpmem_read_unlock_noirq_calls == 1);
		require(fake_xpmem_pt_lookup_pte_calls == 0);
		require(fake_xpmem_pt_set_pte_calls == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_read_lock_noirq_calls +
			fake_xpmem_read_unlock_noirq_calls);

		fake_xpmem_fault_reset(&proc, &vm, &asp, &range, &tg,
			&tg2, &seg, &ap, &att, &pte1, &pte2);
		fake_xpmem_pt_set_pte_rc = -5;
		ret = XPMEM_FAULT_CALL(&vm, &range, 0x5000, 0x44, 1,
			tg.tgid, &vm);
		require(ret == -14);
		require(fake_xpmem_pt_set_pte_calls == 1);
		require(fake_xpmem_flush_single_calls == 0);
		require(fake_xpmem_fault_log_calls == 1);
		require(fake_xpmem_fault_log_event_sum == 5);
		require(fake_xpmem_fault_log_error_sum == -5);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_xpmem_fault_log_error_sum);
	}

#undef XPMEM_IOCTL_CALL
#undef XPMEM_ATTACH_CALL
#undef XPMEM_FAULT_CALL
#undef XPMEM_UPDATE_PAGE_TABLE_CALL
	printf("xpmem_helpers ok digest=%016lx\n", digest);
	return 0;
}
