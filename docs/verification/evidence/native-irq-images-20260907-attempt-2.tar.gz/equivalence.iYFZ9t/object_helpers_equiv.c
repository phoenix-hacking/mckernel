#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

#define PS_STOPPED 0x20
#define VR_PRIVATE 0x2000UL
#define VR_LOCKED 0x4000UL
#define VR_PROT_READ 0x00010000UL
#define VR_PROT_WRITE 0x00020000UL
#define VR_PROT_EXEC 0x00040000UL
#define PM_NONE 0x00
#define PM_WILL_PAGEIO 0x02
#define PM_PAGEIO 0x03
#define PM_DONE_PAGEIO 0x04
#define PM_PAGEIO_EOF 0x05
#define PM_PAGEIO_ERROR 0x06
#define PM_MAPPED 0x07
#define ENOMEM 12
#define ERANGE 34
#define ERESTART 85
#define MF_HAS_PAGER 0x0001
#define MF_IS_REMOVABLE 0x0004
#define MF_ZEROFILL 0x0010
#define MF_PREMAP 0x8000
#define MF_XPMEM 0x10000
#define MF_PRIVATE 0x200000
#define MF_REMAP_FILE_PAGES 0x400000
#define MPOL_SHM_PREMAP 0x08UL
#define FILEOBJ_LOG_PAGEIO_SCHEDULE 4
#define FILEOBJ_LOG_PAGEIO_EOF 5
#define FILEOBJ_LOG_PAGEIO_READ_ERROR 6
#define FILEOBJ_LOG_FREE_INVALID_COUNT 7
#define FILEOBJ_LOG_FREE_RSS_SUB 8
#define FILEOBJ_LOG_FREE_RELEASE_ERROR 9
#define FILEOBJ_LOG_FREE_DONE 10
#define FILEOBJ_CREATE_LOG_PATH_ALLOC_FAILED 11
#define FILEOBJ_CREATE_LOG_PREMAP_START 12
#define FILEOBJ_CREATE_LOG_PREMAP_ARRAY_ALLOC_FAILED 13
#define FILEOBJ_CREATE_LOG_PREMAP_PAGE_ALLOC_FAILED 14
#define FILEOBJ_CREATE_LOG_PREMAP_RSS_ADD 15
#define FILEOBJ_CREATE_LOG_PREMAP_INTERLEAVED_DONE 16
#define FILEOBJ_GET_LOG_PREMAP_ALLOC_FAILED 17
#define FILEOBJ_GET_LOG_PREMAP_ALLOCATED 18
#define FILEOBJ_GET_LOG_PREMAP_RSS_ADD 19
#define FILEOBJ_GET_LOG_PREMAP_RESOLVED 20
#define FILEOBJ_GET_LOG_KMALLOC_FAILED 21
#define FILEOBJ_GET_LOG_ALLOC_FAILED 22
#define FILEOBJ_GET_LOG_NEW_PAGE 23
#define FILEOBJ_GET_LOG_MAP_DONE 24
#define FILEOBJ_GET_LOG_USE_PAGE 25
#define FILEOBJ_GET_LOG_RETURN 26

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

typedef struct {
	int counter;
} ihk_atomic_t;

typedef struct {
	long counter64;
} ihk_atomic64_t;

struct page {
	struct list_head list;
	struct list_head hash;
	uint8_t mode;
	uint64_t phys;
	ihk_atomic_t count;
	ihk_atomic64_t mapped;
	int64_t offset;
	int pgshift;
};

struct memobj;
struct memobj_ops {
	void (*free)(struct memobj *);
	int (*get_page)(struct memobj *, long, int, uintptr_t *,
			unsigned long *, uintptr_t);
	uintptr_t (*copy_page)(struct memobj *, uintptr_t, int);
	int (*flush_page)(struct memobj *, uintptr_t, size_t);
	int (*invalidate_page)(struct memobj *, uintptr_t, size_t);
	int (*lookup_page)(struct memobj *, long, int, uintptr_t *,
			   unsigned long *);
	int (*update_page)(struct memobj *, void *, struct page *, void *);
};

struct memobj {
	struct memobj_ops *ops;
	uint32_t flags;
	uint32_t status;
	size_t size;
	ihk_atomic_t refcnt;
	void **pages;
	int nr_pages;
	char *path;
};

extern int memobj_unref_should_free_result(int);
extern int memobj_op_present_result(uintptr_t);
extern int memobj_missing_page_op_result(void);
extern uintptr_t memobj_missing_copy_page_result(void);
extern int memobj_default_page_op_result(void);
extern int memobj_has_pager_flags_result(unsigned int);
extern int memobj_is_removable_flags_result(unsigned int);
extern int memobj_flushable_page_result(int, int);
extern int memobj_flushable_obj_result(int, unsigned int);
extern int memobj_is_freeable_result(int, unsigned int);
extern int memobj_callable_remap_file_pages_result(int, unsigned int);
extern int memobj_get_page(struct memobj *, long, int, uintptr_t *,
			   unsigned long *, uintptr_t);
extern uintptr_t memobj_copy_page(struct memobj *, uintptr_t, int);
extern int memobj_flush_page(struct memobj *, uintptr_t, size_t);
extern int memobj_invalidate_page(struct memobj *, uintptr_t, size_t);
extern int memobj_lookup_page(struct memobj *, long, int, uintptr_t *,
			      unsigned long *);
extern int memobj_update_page(struct memobj *, void *, struct page *, void *);
extern int memobj_has_pager(struct memobj *);
extern int memobj_is_removable(struct memobj *);
extern int is_flushable(struct page *, struct memobj *);
extern int is_freeable(struct memobj *);
extern int is_callable_remap_file_pages(struct memobj *);
extern int fileobj_page_hash_result(long);
extern int fileobj_page_mode_valid_result(int);
extern int fileobj_lookup_ref_keep_result(int);
extern int fileobj_create_base_flags_result(int);
extern int fileobj_apply_result_flags_result(int, int);
extern int fileobj_status_from_flags_result(int);
extern int fileobj_hugetlbfs_result(int);
extern int fileobj_premap_zerofill_result(int);
extern int fileobj_premap_npages_result(size_t);
extern int fileobj_validate_p2align_result(int);
extern int fileobj_get_page_action_result(int, int, int *);
extern int fileobj_pageio_zero_result(int);
extern int fileobj_pageio_mode_after_read_result(ssize_t, size_t);
extern int fileobj_flush_skip_result(int, int);
extern int fileobj_initial_refcnt_result(void);
extern unsigned long fileobj_initial_sref_result(void);
extern int fileobj_premap_start_node_result(int);
extern int fileobj_premap_next_node_result(int, int);
extern size_t fileobj_pages_bytes_result(int);
extern int fileobj_premap_page_index_result(long);
extern int fileobj_alloc_npages_result(int);
extern unsigned long fileobj_alloc_flags_result(int);
extern size_t fileobj_alloc_size_result(int);
extern size_t fileobj_pageio_pgsize_result(int);
extern int fileobj_pageio_should_schedule_result(int);
extern int fileobj_new_page_mode_result(void);
extern int fileobj_mapped_mode_result(void);
extern int fileobj_path_present_result(unsigned long);
extern int fileobj_invalid_page_count_result(int);
extern int fileobj_should_free_hashed_page_result(int, int);
extern int fileobj_premap_page_present_result(uintptr_t);
extern int fileobj_lookup_page_error_result(int);
extern unsigned long fileobj_next_sref_result(unsigned long);
extern int fileobj_premap_interleave_result(unsigned long);
extern int fileobj_flush_page_body_result(void *, void *, int, uintptr_t,
	uintptr_t, size_t, void *(*)(uintptr_t), long (*)(void *),
	long (*)(uintptr_t, long, size_t, uintptr_t),
	void (*)(int, void *, void *, uintptr_t, size_t, long));
extern int fileobj_invalidate_page_body_result(void *, uintptr_t, size_t,
	void (*)(int, void *, void *, uintptr_t, size_t, long));
extern int fileobj_lookup_page_body_result(void *, long, int, uintptr_t *,
	void *, void *, void (*)(void *, void *), void (*)(void *, void *),
	void *(*)(void *, int, long), uintptr_t (*)(void *));
extern void *fileobj_obj_list_lookup_body_result(uintptr_t, void *,
	void *(*)(void *), void *(*)(void *, void *),
	uintptr_t (*)(void *), int (*)(void *), void (*)(void *));
extern int fileobj_create_publish_body_result(void *, int, int, int, size_t,
	void (*)(void *), void (*)(void *, size_t), void (*)(void *, int),
	void (*)(void *, int), void (*)(void *, int),
	unsigned long (*)(void *), void (*)(void *, unsigned long));
extern int fileobj_create_path_body_result(void *, int, const void *, size_t,
	unsigned long, void *(*)(size_t, unsigned long),
	void (*)(void *, const void *, size_t), void (*)(void *, void *),
	void (*)(int, void *, const void *, long));
extern int fileobj_create_premap_body_result(void *, int, size_t,
	unsigned long, int, uintptr_t, unsigned long,
	void *(*)(size_t, unsigned long), void (*)(void *, void *),
	void (*)(void *, int), void (*)(void *, size_t),
	void *(*)(int, int, unsigned long, int, uintptr_t),
	void (*)(void *, int, void *), void (*)(size_t, size_t),
	void (*)(int, void *, void *, long));
extern int fileobj_get_premap_body_result(void *, void *, long, int,
	uintptr_t, uintptr_t *, unsigned long,
	void *(*)(int, unsigned long, uintptr_t), void (*)(void *, size_t),
	void *(*)(void *, int), void *(*)(void *, int, void *, void *),
	void (*)(void *, int), uintptr_t (*)(void *),
	void (*)(size_t, size_t),
	void (*)(int, void *, long, int, uintptr_t, uintptr_t, void *,
		 uintptr_t, long));
extern int fileobj_get_regular_body_result(void *, int, long, int, uintptr_t,
	uintptr_t *, void *, void *, void *, void *, size_t, unsigned long,
	void (*)(void *, void *), void (*)(void *, void *),
	void *(*)(void *, int, long), void *(*)(size_t, unsigned long),
	void (*)(void *), void *(*)(int, unsigned long, uintptr_t),
	uintptr_t (*)(void *), void *(*)(uintptr_t), int (*)(void *),
	void (*)(void *, long), void (*)(void *, long),
	void (*)(void *, long), void (*)(void *, void *, int),
	void (*)(void *, int), int (*)(void *),
	void (*)(void *, void *, long, size_t),
	void (*)(void *, void *, void *), void (*)(void *),
	uintptr_t (*)(void *), int (*)(void *), void (*)(void *),
	void *(*)(uintptr_t), int (*)(void *), void (*)(void *, int),
	void (*)(int, void *, long, int, uintptr_t, uintptr_t, void *,
		 uintptr_t, uintptr_t, size_t, int, int),
	void (*)(void *, long, void *, int));
extern int fileobj_do_pageio_body_result(void *, int, uintptr_t, long,
	size_t, void *, void *, void (*)(void *, void *),
	void (*)(void *, void *), void *(*)(void *, int, long),
	int (*)(void *), void (*)(void *, int), uintptr_t (*)(void *),
	void (*)(uintptr_t), long (*)(uintptr_t, long, size_t, uintptr_t),
	void (*)(void), void (*)(void),
	void (*)(int, void *, long, size_t, long),
	void (*)(void *, long, size_t, int));
extern int fileobj_free_body_result(void *, int, uintptr_t, unsigned long,
	void *, int, void *, void *, void *, void (*)(void *, void *),
	void (*)(void *, void *), void (*)(void *), void *(*)(void *),
	void (*)(void *), uintptr_t (*)(void *), void *(*)(uintptr_t),
	int (*)(void *), int (*)(void *), void (*)(void *, int),
	void (*)(size_t, size_t), void (*)(void *),
	int (*)(uintptr_t, unsigned long), void *(*)(void *, int),
	void (*)(int, void *, void *, uintptr_t, long, unsigned long));
extern size_t devobj_npages_result(size_t);
extern size_t devobj_pfn_table_npages_result(size_t);
extern size_t devobj_pfn_table_bytes_result(size_t);
extern long devobj_pgoff_result(long);
extern int devobj_get_page_index_result(long, long, size_t, int *);
extern int devobj_cached_pfn_needs_fetch_result(uintptr_t);
extern int devobj_pfn_present_result(uintptr_t);
extern uintptr_t devobj_pfn_attr_result(uintptr_t);
extern uintptr_t devobj_pfn_phys_result(uintptr_t);
extern int devobj_pfn_absent_error_result(uintptr_t);
extern int devobj_base_flags_result(void);
extern int devobj_initial_refcnt_result(void);
extern long devobj_pfn_request_offset_result(long);
extern int devobj_should_store_pfn_result(uintptr_t);
extern size_t devobj_map_size_result(void);
extern int devobj_path_present_result(unsigned long);
extern int devobj_pfn_table_present_result(uintptr_t);
extern uintptr_t devobj_mapped_pfn_result(uintptr_t, uintptr_t);
extern int devobj_free_body_result(void *, void *, void *, uintptr_t, size_t,
	int (*)(uintptr_t), void (*)(void *, size_t), void (*)(void *),
	void (*)(int, void *, void *, long, long, int, int, int, uintptr_t));
extern int devobj_get_page_body_result(void *, void *, uintptr_t, long, int,
	long, size_t, void *, uintptr_t *, unsigned long *, void (*)(void),
	unsigned long (*)(void *), void (*)(void *, unsigned long),
	uintptr_t (*)(void *, int),
	int (*)(void *, void *, uintptr_t, long, int, uintptr_t *),
	int (*)(uintptr_t), uintptr_t (*)(uintptr_t, size_t),
	void (*)(void *, int, uintptr_t),
	void (*)(int, void *, void *, long, long, int, int, int, uintptr_t));
#define SCD_MSG_PROCFS_ANSWER 0x13
#define SCD_MSG_PREPARE_PROCESS 0x1
#define SCD_MSG_REMOTE_PAGE_FAULT_ANSWER 0x19
#define SCD_MSG_PREPARE_PROCESS_ACKED 0x2
#define SCD_MSG_SCHEDULE_PROCESS 0x3
#define SCD_MSG_INIT_CHANNEL_ACKED 0x6
#define SCD_MSG_SEND_SIGNAL 0x7
#define SCD_MSG_SEND_SIGNAL_ACK 0x8
#define SCD_MSG_CLEANUP_PROCESS 0x9
#define SCD_MSG_CLEANUP_PROCESS_RESP 0xa
#define SCD_MSG_PROCFS_REQUEST 0x12
#define SCD_MSG_WAKE_UP_SYSCALL_THREAD 0x14
#define SCD_MSG_PROCFS_RELEASE 0x15
#define SCD_MSG_REMOTE_PAGE_FAULT 0x18
#define SCD_MSG_DEBUG_LOG 0x20
#define SCD_MSG_SYSFS_REQ_SHOW 0x3a
#define SCD_MSG_SYSFS_REQ_STORE 0x3c
#define SCD_MSG_SYSFS_REQ_RELEASE 0x3e
#define SCD_MSG_PERF_CTRL 0x50
#define SCD_MSG_CLEANUP_FD_RESP 0x55
#define SCD_MSG_PERF_ACK 0x51
#define SCD_MSG_CPU_RW_REG 0x52
#define SCD_MSG_CPU_RW_REG_RESP 0x53
#define SCD_MSG_CLEANUP_FD 0x54
#define SCD_MSG_PROCFS_TID_CREATE 0x44
#define SCD_MSG_PROCFS_TID_DELETE 0x45
struct ihk_ikc_packet_header {
	void *channel;
};
struct syscall_request {
	int rtid;
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};
struct ikc_scd_packet {
	struct ihk_ikc_packet_header header;
	int msg;
	int err;
	void *reply;
	union {
		struct {
			int ref;
			int osnum;
			int pid;
			unsigned long arg;
			struct syscall_request req;
			unsigned long resp_pa;
		};
		struct {
			long sysfs_arg1;
			long sysfs_arg2;
			long sysfs_arg3;
		};
		struct {
			int ttid;
		};
		struct {
			unsigned long pdesc;
			int op;
			void *resp;
		};
		struct {
			int target_cpu;
			int fault_tid;
			unsigned long fault_address;
			unsigned long fault_reason;
		};
	};
};
typedef unsigned long (*procfs_thread_phys_fn_t)(void *);
typedef int (*procfs_thread_send_fn_t)(void *, struct ikc_scd_packet *);
typedef void (*procfs_thread_pause_fn_t)(void);
extern int procfs_thread_ctl_result(void *, struct ikc_scd_packet *, int *,
				    int, int, int, int, int,
				    procfs_thread_phys_fn_t,
				    procfs_thread_send_fn_t,
				    procfs_thread_pause_fn_t);
typedef void (*procfs_answer_send_fn_t)(void *, struct ikc_scd_packet *);
extern int procfs_answer_result(void *, struct ikc_scd_packet *, int,
				procfs_answer_send_fn_t);
typedef void (*host_ikc_packet_send_fn_t)(void *, struct ikc_scd_packet *);
typedef int (*host_thread_profile_enabled_fn_t)(void *);
typedef unsigned long (*host_timestamp_fn_t)(void);
typedef void (*host_preempt_fn_t)(void);
typedef void (*host_remote_page_fault_fn_t)(void *, unsigned long,
					    unsigned long);
typedef void (*host_profile_event_fn_t)(int, unsigned long);
typedef void (*host_remote_page_fault_log_fn_t)(void *, unsigned long,
						unsigned long);
typedef void (*host_remote_page_fault_body_fn_t)(struct ikc_scd_packet *,
						 int);
typedef void *(*host_alloc_fn_t)(unsigned long, unsigned long);
typedef void (*host_packet_copy_fn_t)(void *, struct ikc_scd_packet *,
				      unsigned long);
typedef void (*host_backlog_fn_t)(void *);
typedef void (*host_remote_page_fault_defer_fn_t)(void *, void *,
						  host_backlog_fn_t);
typedef int (*host_sched_wakeup_fn_t)(void *, int);
typedef void (*host_remote_page_fault_missing_log_fn_t)(int);
typedef void *(*host_find_thread_fn_t)(int, int);
typedef void (*host_thread_unlock_fn_t)(void *);
typedef void *(*host_thread_proc_fn_t)(void *);
typedef int (*host_current_cpu_fn_t)(void);
typedef int (*host_thread_cpu_allowed_fn_t)(void *, int);
typedef int (*host_thread_obtain_cpuid_fn_t)(void *);
typedef int (*host_proc_pid_fn_t)(void *);
typedef unsigned long (*host_thread_reg_fn_t)(void *);
typedef void (*host_schedule_invalid_log_fn_t)(void *);
typedef void (*host_schedule_received_log_fn_t)(void *, int, unsigned long,
						unsigned long, int);
typedef void (*host_schedule_no_cpu_log_fn_t)(void);
typedef void (*host_thread_set_tid_fn_t)(void *, int);
typedef void (*host_status_set_fn_t)(void *, int);
typedef void (*host_chain_thread_fn_t)(void *);
typedef void (*host_chain_process_fn_t)(void *);
typedef void (*host_runq_add_thread_fn_t)(void *, int);
typedef void (*host_schedule_queued_log_fn_t)(int, int, int, int);
extern int host_thread_profile_enabled_result(void *,
					host_thread_profile_enabled_fn_t);
extern unsigned long host_timestamp_result(host_timestamp_fn_t);
extern int host_preempt_result(host_preempt_fn_t);
extern int host_remote_page_fault_process_result(void *, unsigned long,
					unsigned long,
					host_remote_page_fault_fn_t);
extern int host_profile_event_result(int, unsigned long,
					host_profile_event_fn_t);
extern int host_remote_page_fault_log_result(void *, unsigned long,
					unsigned long,
					host_remote_page_fault_log_fn_t);
extern void *host_alloc_result(unsigned long, unsigned long,
					host_alloc_fn_t);
extern int host_packet_copy_result(void *, struct ikc_scd_packet *,
					unsigned long,
					host_packet_copy_fn_t);
extern int host_remote_page_fault_defer_result(void *, void *,
					host_backlog_fn_t,
					host_remote_page_fault_defer_fn_t);
extern int host_sched_wakeup_result(void *, int, host_sched_wakeup_fn_t);
extern int host_remote_page_fault_missing_log_result(int,
					host_remote_page_fault_missing_log_fn_t);
extern void *host_thread_proc_result(void *, host_thread_proc_fn_t);
extern int host_current_cpu_result(host_current_cpu_fn_t);
extern int host_thread_cpu_allowed_result(void *, int,
					host_thread_cpu_allowed_fn_t);
extern int host_thread_obtain_cpuid_result(void *,
					host_thread_obtain_cpuid_fn_t);
extern int host_proc_pid_result(void *, host_proc_pid_fn_t);
extern unsigned long host_thread_reg_result(void *, host_thread_reg_fn_t);
extern int host_schedule_invalid_log_result(void *,
					host_schedule_invalid_log_fn_t);
extern int host_schedule_received_log_result(void *, int, unsigned long,
					unsigned long, int,
					host_schedule_received_log_fn_t);
extern int host_schedule_no_cpu_log_result(host_schedule_no_cpu_log_fn_t);
extern int host_thread_set_tid_result(void *, int, host_thread_set_tid_fn_t);
extern int host_status_set_result(void *, int, host_status_set_fn_t);
extern int host_chain_thread_result(void *, host_chain_thread_fn_t);
extern int host_chain_process_result(void *, host_chain_process_fn_t);
extern int host_runq_add_thread_result(void *, int, host_runq_add_thread_fn_t);
extern int host_schedule_queued_log_result(int, int, int, int,
					host_schedule_queued_log_fn_t);
extern int host_schedule_process_request_result(struct ikc_scd_packet *,
					host_thread_proc_fn_t,
					host_current_cpu_fn_t,
					host_thread_cpu_allowed_fn_t,
					host_thread_obtain_cpuid_fn_t,
					host_proc_pid_fn_t,
					host_thread_reg_fn_t,
					host_thread_reg_fn_t,
					host_schedule_invalid_log_fn_t,
					host_schedule_received_log_fn_t,
					host_schedule_no_cpu_log_fn_t,
					host_thread_set_tid_fn_t,
					host_status_set_fn_t,
					host_status_set_fn_t,
					host_chain_thread_fn_t,
					host_chain_process_fn_t,
					host_runq_add_thread_fn_t,
					host_schedule_queued_log_fn_t,
					int);
extern int host_remote_page_fault_answer_result(void *, struct ikc_scd_packet *,
						int,
						host_ikc_packet_send_fn_t);
extern int host_remote_page_fault_body_result(void *, struct ikc_scd_packet *,
					int, void *, unsigned long, int,
					host_thread_profile_enabled_fn_t,
					host_timestamp_fn_t,
					host_preempt_fn_t,
					host_remote_page_fault_fn_t,
					host_preempt_fn_t,
					host_profile_event_fn_t,
					host_remote_page_fault_log_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_remote_page_fault_body_dispatch_result(
					struct ikc_scd_packet *, int,
					host_remote_page_fault_body_fn_t);
extern int host_remote_page_fault_request_result(struct ikc_scd_packet *,
					host_find_thread_fn_t, void *,
					host_remote_page_fault_body_fn_t,
					host_alloc_fn_t,
					host_packet_copy_fn_t,
					host_remote_page_fault_defer_fn_t,
					host_sched_wakeup_fn_t,
					host_thread_unlock_fn_t,
					host_remote_page_fault_missing_log_fn_t,
					host_backlog_fn_t,
					unsigned long, unsigned long, int);
extern int host_traditional_reply_result(void *, struct ikc_scd_packet *,
					 int, int,
					 host_ikc_packet_send_fn_t);
extern int host_arg_reply_result(void *, struct ikc_scd_packet *, int, int,
				 host_ikc_packet_send_fn_t);
extern int host_reply_only_result(void *, struct ikc_scd_packet *, int, int,
				  host_ikc_packet_send_fn_t);
#define PERF_CTRL_SET 0
#define PERF_CTRL_GET 1
#define PERF_CTRL_ENABLE 2
#define PERF_CTRL_DISABLE 3
#define PERFCTR_USER_MODE 0x01
#define PERFCTR_KERNEL_MODE 0x02
#define IHK_MC_PERFCTR_DISABLE_INTERRUPT 1
#define PF_POPULATE (1UL << 30)
#define PROFILE_remote_page_fault 0x5f
#define PAGE_SIZE 4096UL
#define PAGE_SHIFT 12
#define PAGE_MASK (~(PAGE_SIZE - 1))
#define LARGE_PAGE_SHIFT 21
#define LARGE_PAGE_SIZE (1UL << LARGE_PAGE_SHIFT)
#define LARGE_PAGE_MASK (~(LARGE_PAGE_SIZE - 1))
#define TASK_UNMAPPED_BASE 0x00002AAAAAA00000UL
#define IHK_MC_AP_NOWAIT 0x000002UL
#define IHK_MC_AP_USER 0x001000UL
#define MPOL_NO_BSS 0x04UL
#define IHK_UCR_PROGRAM_COUNTER 2
#define VR_NONE 0x0UL
#define VR_AP_USER 0x4UL
#define VR_DEMAND_PAGING 0x1000UL
#define VR_PROT_MASK 0x00070000UL
#define VR_PROT_EXEC 0x00040000UL
#define PROT_EXEC 0x04
#define PROT_TO_VR_FLAG(prot) (((unsigned long)(prot) << 16) & VR_PROT_MASK)
#define VRFLAG_PROT_TO_MAXPROT(vrflag) (((vrflag) & VR_PROT_MASK) << 4)
struct perf_ctrl_desc {
	int ctrl_type;
	int err;
	union {
		struct {
			unsigned int target_cntr;
			unsigned long config;
			unsigned long read_value;
			unsigned disabled        :1,
				 pinned          :1,
				 exclude_user    :1,
				 exclude_kernel  :1,
				 exclude_hv      :1,
				 exclude_idle    :1;
		};
		struct {
			unsigned long target_cntr_mask;
		};
	};
};
typedef int (*host_perf_init_raw_fn_t)(int, unsigned int, int);
typedef int (*host_perf_stop_fn_t)(unsigned long, int);
typedef int (*host_perf_reset_fn_t)(int);
typedef int (*host_perf_start_fn_t)(unsigned long);
typedef unsigned long (*host_perf_read_fn_t)(int);
typedef void (*host_perf_unexpected_fn_t)(void);
extern int host_perf_init_raw_result(int, unsigned int, int,
					host_perf_init_raw_fn_t);
extern int host_perf_stop_result(unsigned long, int, host_perf_stop_fn_t);
extern int host_perf_reset_result(int, host_perf_reset_fn_t);
extern int host_perf_start_result(unsigned long, host_perf_start_fn_t);
extern unsigned long host_perf_read_result(int, host_perf_read_fn_t);
extern int host_perf_unexpected_result(host_perf_unexpected_fn_t);
typedef unsigned long (*host_map_memory_fn_t)(void *, unsigned long,
					      unsigned long);
typedef void *(*host_map_virtual_fn_t)(unsigned long, int, int);
typedef void *(*host_prepare_map_virtual_fn_t)(unsigned long, int,
					       unsigned long);
typedef void (*host_unmap_virtual_fn_t)(void *, int);
typedef void (*host_unmap_memory_fn_t)(void *, unsigned long, unsigned long);
typedef int (*host_cpu_rw_register_fn_t)(void *, int);
typedef int (*host_cleanup_process_fn_t)(int);
typedef void (*host_terminate_host_fn_t)(int, void *);
typedef void (*host_cleanup_process_log_fn_t)(int, unsigned long);
typedef int (*host_cleanup_fd_fn_t)(int, int);
typedef void (*host_cleanup_fd_log_fn_t)(int, unsigned long, int);
typedef unsigned long (*host_do_kill_fn_t)(int, int, int, void *);
typedef void (*host_send_signal_log_fn_t)(int, int, int, int);
typedef void (*host_wakeup_thread_fn_t)(void *);
typedef void (*host_wake_syscall_log_fn_t)(int, int);
typedef void (*host_debug_log_fn_t)(unsigned long);
typedef void (*host_debug_log_print_fn_t)(unsigned long);
typedef void (*host_init_ack_log_fn_t)(void);
typedef void (*host_schedule_process_log_fn_t)(unsigned long);
typedef int (*host_response_packet_fn_t)(void *, struct ikc_scd_packet *);
typedef int (*host_packet_dispatch_fn_t)(struct ikc_scd_packet *);
typedef int (*host_remote_page_fault_dispatch_fn_t)(struct ikc_scd_packet *,
						    void *);
typedef int (*host_procfs_request_fn_t)(struct ikc_scd_packet *);
typedef int (*host_prepare_process_fn_t)(unsigned long);
extern int host_prepare_process_result(unsigned long,
					host_prepare_process_fn_t);
typedef void (*host_sysfs_packet_fn_t)(void *, int, int, long, long, long);
typedef void (*host_unknown_packet_log_fn_t)(struct ikc_scd_packet *);
typedef void (*host_release_packet_fn_t)(struct ikc_scd_packet *);
typedef void *(*host_current_ptr_fn_t)(void);
extern void *host_current_ptr_result(host_current_ptr_fn_t);
extern int host_cpu_rw_register_result(void *, int,
					host_cpu_rw_register_fn_t);
extern int host_cleanup_process_result(int, host_cleanup_process_fn_t);
extern int host_cleanup_fd_result(int, int, host_cleanup_fd_fn_t);
extern int host_cleanup_process_log_result(int, unsigned long,
					host_cleanup_process_log_fn_t);
extern int host_terminate_host_result(int, void *,
					host_terminate_host_fn_t);
extern int host_cleanup_fd_log_result(int, unsigned long, int,
					host_cleanup_fd_log_fn_t);
extern unsigned long host_do_kill_result(int, int, int, void *,
					host_do_kill_fn_t);
extern int host_send_signal_log_result(int, int, int, int,
					host_send_signal_log_fn_t);
extern void *host_find_thread_result(int, int, host_find_thread_fn_t);
extern int host_wakeup_thread_result(void *, host_wakeup_thread_fn_t);
extern int host_thread_unlock_result(void *, host_thread_unlock_fn_t);
extern int host_wake_syscall_log_result(int, int,
					host_wake_syscall_log_fn_t);
extern int host_debug_log_result(unsigned long, host_debug_log_fn_t);
extern int host_debug_log_print_result(unsigned long,
					host_debug_log_print_fn_t);
extern int host_ikc_packet_send_result(void *, struct ikc_scd_packet *,
					host_ikc_packet_send_fn_t);
extern unsigned long host_map_memory_result(void *, unsigned long,
					unsigned long, host_map_memory_fn_t);
extern void *host_map_virtual_result(unsigned long, int, int,
					host_map_virtual_fn_t);
extern void *host_prepare_map_virtual_result(unsigned long, int,
					unsigned long,
					host_prepare_map_virtual_fn_t);
extern int host_unmap_virtual_result(void *, int, host_unmap_virtual_fn_t);
extern int host_unmap_memory_result(void *, unsigned long, unsigned long,
					host_unmap_memory_fn_t);
extern int host_init_ack_log_result(host_init_ack_log_fn_t);
extern int host_schedule_process_log_result(struct ikc_scd_packet *,
					host_schedule_process_log_fn_t);
extern int host_remote_page_fault_current_result(struct ikc_scd_packet *,
					int, unsigned long, int,
					host_current_ptr_fn_t,
					host_current_ptr_fn_t,
					host_thread_profile_enabled_fn_t,
					host_timestamp_fn_t,
					host_preempt_fn_t,
					host_remote_page_fault_fn_t,
					host_preempt_fn_t,
					host_profile_event_fn_t,
					host_remote_page_fault_log_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_procfs_answer_current_result(struct ikc_scd_packet *, int,
					host_current_ptr_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_prepare_process_request_result(void *,
					struct ikc_scd_packet *,
					host_prepare_process_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_procfs_request_result(struct ikc_scd_packet *,
					host_procfs_request_fn_t);
extern int host_response_packet_result(void *, struct ikc_scd_packet *,
					host_response_packet_fn_t);
extern int host_packet_dispatch_result(struct ikc_scd_packet *,
					host_packet_dispatch_fn_t);
extern int host_remote_page_fault_dispatch_result(struct ikc_scd_packet *,
					void *,
					host_remote_page_fault_dispatch_fn_t);
extern int host_procfs_packet_dispatch_result(struct ikc_scd_packet *,
					host_procfs_request_fn_t);
extern int host_sysfs_packet_result(void *, int, int, long, long, long,
					host_sysfs_packet_fn_t);
extern int host_unknown_packet_log_result(struct ikc_scd_packet *,
					host_unknown_packet_log_fn_t);
extern int host_release_packet_result(struct ikc_scd_packet *,
					host_release_packet_fn_t);
extern int host_release_packet_dispatch_result(struct ikc_scd_packet *,
					host_release_packet_fn_t);
struct ihk_ikc_channel_desc {
	int id;
};
typedef int (*host_ikc_packet_handler_fn_t)(struct ihk_ikc_channel_desc *,
					    void *, void *);
struct ihk_ikc_connect_param {
	int port;
	int pkt_size;
	int queue_size;
	int magic;
	int intr_cpu;
	host_ikc_packet_handler_fn_t handler;
	struct ihk_ikc_channel_desc *channel;
};
typedef int (*host_ikc_connect_fn_t)(struct ihk_ikc_connect_param *);
typedef void (*host_delay_fn_t)(unsigned long);
typedef void (*host_set_current_ikc2linux_fn_t)(void *);
typedef void (*host_ikc_set_regular_channel_fn_t)(void *, int);
typedef void (*host_init_ikc_log_fn_t)(int);
typedef void (*host_panic_fn_t)(void);
extern int host_ikc_connect_result(struct ihk_ikc_connect_param *,
				   host_ikc_connect_fn_t);
extern int host_delay_result(unsigned long, host_delay_fn_t);
extern int host_set_current_ikc2linux_result(void *,
				   host_set_current_ikc2linux_fn_t);
extern int host_ikc_set_regular_channel_result(void *, int,
				   host_ikc_set_regular_channel_fn_t);
extern int host_panic_result(host_panic_fn_t);
extern int host_init_ikc_log_result(int, host_init_ikc_log_fn_t);
typedef int (*host_monitor_status_fn_t)(int);
extern int host_monitor_status_result(int, host_monitor_status_fn_t);
#define MCK_RLIM_MAX 20
#define PLD_CPU_SET_MAX_CPUS 1024
#define PLD_CPU_SET_SIZE (PLD_CPU_SET_MAX_CPUS / (8 * sizeof(unsigned long)))
#define PLD_PROCESS_NUMA_MASK_BITS 256
#define PLD_NUMA_MASK_WORDS \
	(PLD_PROCESS_NUMA_MASK_BITS / (sizeof(unsigned long) * 8))
#define PLD_MAGIC 0xcafecafe44332211UL
#define HOST_PREPARE_LOG_BROKEN_DESC 1
#define HOST_PREPARE_LOG_INVALID_SECTIONS 2
#define HOST_PREPARE_LOG_NUM_SECTIONS 3
#define HOST_PREPARE_LOG_NUMA_BIND_ERROR 4
#define HOST_PREPARE_LOG_NUMA_NODEMASK_ERROR 5
#define HOST_PREPARE_LOG_NUMA_POLICY 6
#define HOST_PREPARE_LOG_PID_FLAGS 7
#define HOST_PREPARE_LOG_RLIMIT 8
#define HOST_PREPARE_LOG_PREPARE_ERROR 9
#define HOST_PREPARE_LOG_NEW_PROCESS 10
#define HOST_PREPARE_RANGES_LOG_AP_USER 20
	#define HOST_PREPARE_RANGES_LOG_ADD_FAILED 21
	#define HOST_PREPARE_RANGES_LOG_ALLOC_FAILED 22
	#define HOST_PREPARE_RANGES_LOG_PT_FAILED 23
	#define HOST_PREPARE_RANGES_LOG_DATA_TOO_LARGE 24
	#define HOST_PREPARE_ARGS_LOG_ALLOC_FAILED 25
	#define HOST_PREPARE_ARGS_LOG_ADD_FAILED 26
	#define HOST_PREPARE_ARGS_LOG_ARGS_MAP_FAILED 27
	#define HOST_PREPARE_ARGS_LOG_ENVS_MAP_FAILED 28
	#define HOST_PREPARE_ARGS_LOG_CMDLINE_ALLOC_FAILED 29
	#define HOST_PREPARE_ARGS_LOG_VDSO_FAILED 30
	#define HOST_PREPARE_ARGS_LOG_INIT_STACK_FAILED 31
	#define HOST_PREPARE_ARGS_LOG_CMDLINE 32
struct rlimit {
	unsigned long rlim_cur;
	unsigned long rlim_max;
};
struct program_image_section {
	unsigned long vaddr;
	unsigned long len;
	unsigned long remote_pa;
	unsigned long filesz;
	unsigned long offset;
	int prot;
	char interp;
	char padding[3];
	void *fp;
};
struct program_load_desc {
	unsigned long magic;
	int num_sections;
	int cpu;
	int pid;
	int stack_prot;
	int pgid;
	int cred[8];
	int reloc;
	char enable_vdso;
	char padding[7];
	unsigned long entry;
	unsigned long user_start;
	unsigned long user_end;
	unsigned long rprocess;
	unsigned long rpgtable;
	unsigned long at_phdr;
	unsigned long at_phent;
	unsigned long at_phnum;
	unsigned long at_entry;
	unsigned long at_clktck;
	char *args;
	unsigned long args_len;
	char *envs;
	unsigned long envs_len;
	struct rlimit rlimit[MCK_RLIM_MAX];
	unsigned long interp_align;
	unsigned long mpol_flags;
	unsigned long mpol_threshold;
	unsigned long heap_extension;
	long stack_premap;
	unsigned long mpol_bind_mask;
	int mpol_mode;
	unsigned long mpol_nodemask[PLD_NUMA_MASK_WORDS];
	int thp_disable;
	int enable_uti;
	int uti_thread_rank;
	int uti_use_last_cpu;
	int straight_map;
	size_t straight_map_threshold;
	unsigned long mcexec_flags;
	int nr_processes;
	int process_rank;
	unsigned long cpu_set[PLD_CPU_SET_SIZE];
	int profile;
	struct program_image_section sections[0];
};
typedef void (*host_free_fn_t)(void *);
typedef void (*host_copy_long_fn_t)(void *, const void *, unsigned long);
typedef void *(*host_create_thread_fn_t)(unsigned long, unsigned long *,
					 unsigned long);
typedef void (*host_destroy_thread_fn_t)(void *);
typedef int (*host_prepare_ranges_fn_t)(void *, struct program_load_desc *,
					struct program_load_desc *,
					unsigned long, char *, int, char *,
					int);
extern int host_prepare_ranges_result(void *, struct program_load_desc *,
					struct program_load_desc *,
					unsigned long, char *, int, char *,
					int, host_prepare_ranges_fn_t);
typedef int (*host_nr_numa_nodes_fn_t)(void);
typedef void (*host_flush_tlb_fn_t)(void);
typedef void (*host_tofu_finalize_fn_t)(void);
typedef void (*host_prepare_process_log_fn_t)(int, unsigned long,
					      unsigned long, unsigned long);
extern int host_tofu_finalize_result(host_tofu_finalize_fn_t);
extern int host_prepare_process_log_result(int, unsigned long,
					unsigned long, unsigned long,
					host_prepare_process_log_fn_t);
typedef int (*host_prepare_add_range_fn_t)(void *, unsigned long,
					   unsigned long, unsigned long,
					   unsigned long, int, void **);
typedef void *(*host_prepare_alloc_pages_user_fn_t)(int, unsigned long,
						    unsigned long);
typedef void (*host_prepare_free_pages_user_fn_t)(void *, int);
typedef unsigned long (*host_virt_to_phys_fn_t)(void *);
typedef unsigned long (*host_arch_vrflag_to_ptattr_fn_t)(unsigned long,
							 unsigned long,
							 void *);
typedef int (*host_pt_set_range_fn_t)(void *, void *, unsigned long,
				      unsigned long, unsigned long,
				      unsigned long, int, void *, int);
	typedef void (*host_modify_user_context_fn_t)(void *, int, unsigned long);
	typedef void (*host_prepare_ranges_log_fn_t)(int, unsigned long,
						     unsigned long, unsigned long);
	extern int host_prepare_ranges_log_result(int, unsigned long,
					unsigned long, unsigned long,
					host_prepare_ranges_log_fn_t);
	typedef int (*host_arch_map_vdso_fn_t)(void *);
		typedef int (*host_init_process_stack_fn_t)(void *,
					struct program_load_desc *,
					unsigned long, int, char **, int,
					char **);
		typedef void (*host_prepare_args_log_fn_t)(int, unsigned long,
							   unsigned long,
							   unsigned long);
		extern int host_prepare_args_log_result(int, unsigned long,
					unsigned long, unsigned long,
					host_prepare_args_log_fn_t);
	extern int host_prepare_add_range_result(void *, unsigned long,
					unsigned long, unsigned long,
					unsigned long, int, void **,
					host_prepare_add_range_fn_t);
	extern void *host_prepare_alloc_pages_user_result(int, unsigned long,
					unsigned long,
					host_prepare_alloc_pages_user_fn_t);
	extern int host_prepare_free_pages_user_result(void *, int,
					host_prepare_free_pages_user_fn_t);
	extern unsigned long host_virt_to_phys_result(void *,
					host_virt_to_phys_fn_t);
	extern unsigned long host_arch_vrflag_to_ptattr_result(unsigned long,
					unsigned long, void *,
					host_arch_vrflag_to_ptattr_fn_t);
	extern int host_pt_set_range_result(void *, void *, unsigned long,
					unsigned long, unsigned long,
					unsigned long, int, void *, int,
					host_pt_set_range_fn_t);
	extern int host_modify_user_context_result(void *, int, unsigned long,
					host_modify_user_context_fn_t);
	extern void *host_prepare_alloc_result(unsigned long, unsigned long,
					host_alloc_fn_t);
	extern int host_prepare_free_result(void *, host_free_fn_t);
	extern int host_prepare_copy_long_result(void *, const void *,
					unsigned long, host_copy_long_fn_t);
	extern void *host_create_thread_result(unsigned long, unsigned long *,
					unsigned long, host_create_thread_fn_t);
	extern int host_destroy_thread_result(void *, host_destroy_thread_fn_t);
	extern int host_nr_numa_nodes_result(host_nr_numa_nodes_fn_t);
	extern int host_flush_tlb_result(host_flush_tlb_fn_t);
	extern int host_arch_map_vdso_result(void *, host_arch_map_vdso_fn_t);
	extern int host_init_process_stack_result(void *, struct program_load_desc *,
					unsigned long, int, char **, int,
					char **, host_init_process_stack_fn_t);
	extern int host_prepare_process_body_result(unsigned long, int, int,
						unsigned long, unsigned long,
						unsigned long, unsigned long, int,
					int, int, host_monitor_status_fn_t,
					host_map_memory_fn_t,
					host_prepare_map_virtual_fn_t,
					host_unmap_virtual_fn_t,
					host_unmap_memory_fn_t,
					host_alloc_fn_t, host_free_fn_t,
					host_copy_long_fn_t,
					host_create_thread_fn_t,
					host_destroy_thread_fn_t,
					host_prepare_ranges_fn_t,
					host_nr_numa_nodes_fn_t,
					host_flush_tlb_fn_t,
					host_tofu_finalize_fn_t,
					host_prepare_process_log_fn_t);
	extern int host_prepare_ranges_sections_result(void *,
						struct program_load_desc *,
						struct program_load_desc *,
					unsigned long *, unsigned long,
					unsigned long, unsigned long,
					unsigned long, unsigned long, int,
					int, unsigned long, unsigned long,
					unsigned long, unsigned long, int,
					host_prepare_add_range_fn_t,
					host_prepare_alloc_pages_user_fn_t,
					host_prepare_free_pages_user_fn_t,
					host_virt_to_phys_fn_t,
						host_arch_vrflag_to_ptattr_fn_t,
						host_pt_set_range_fn_t,
						host_modify_user_context_fn_t,
						host_prepare_ranges_log_fn_t);
	extern int host_prepare_ranges_args_envs_result(void *,
						struct program_load_desc *,
						struct program_load_desc *,
						unsigned long, char *, int,
						char *, int, unsigned long,
						unsigned long, unsigned long,
						int, unsigned long,
						host_prepare_add_range_fn_t,
						host_prepare_alloc_pages_user_fn_t,
						host_prepare_free_pages_user_fn_t,
						host_virt_to_phys_fn_t,
						host_map_memory_fn_t,
						host_prepare_map_virtual_fn_t,
						host_unmap_virtual_fn_t,
						host_unmap_memory_fn_t,
						host_copy_long_fn_t,
						host_alloc_fn_t,
						host_free_fn_t,
						host_flush_tlb_fn_t,
						host_arch_map_vdso_fn_t,
						host_init_process_stack_fn_t,
						host_prepare_args_log_fn_t);
#define HOST_INIT_IKC_LOG_ALLOC_ERROR 1
#define HOST_INIT_IKC_LOG_TRY_CONNECT 2
#define HOST_INIT_IKC_LOG_RETRY_DOT 3
#define HOST_INIT_IKC_LOG_CONNECTED 4
struct host_scd_dispatch_ops {
	host_init_ack_log_fn_t init_ack_log_fn;
	host_response_packet_fn_t prepare_process_fn;
	host_packet_dispatch_fn_t schedule_process_fn;
	host_packet_dispatch_fn_t wake_syscall_thread_fn;
	host_remote_page_fault_dispatch_fn_t remote_page_fault_fn;
	host_response_packet_fn_t send_signal_fn;
	host_procfs_request_fn_t procfs_request_fn;
	host_response_packet_fn_t cleanup_process_fn;
	host_response_packet_fn_t cleanup_fd_fn;
	host_packet_dispatch_fn_t debug_log_fn;
	host_sysfs_packet_fn_t sysfs_packet_fn;
	host_response_packet_fn_t perf_ctrl_fn;
	host_response_packet_fn_t cpu_rw_reg_fn;
	host_unknown_packet_log_fn_t unknown_packet_log_fn;
	host_release_packet_fn_t release_packet_fn;
};
extern int host_scd_packet_dispatch_result(void *, struct ikc_scd_packet *,
					void *, void *,
					const struct host_scd_dispatch_ops *,
					unsigned long, int, unsigned long,
					unsigned long, int, int);
extern int host_syscall_packet_handler_result(void *, void *, void *,
					const struct host_scd_dispatch_ops *,
					host_current_ptr_fn_t,
					host_current_ptr_fn_t,
					unsigned long, int, unsigned long,
					unsigned long, int, int);
extern int host_dummy_packet_handler_result(void *, void *, void *,
					host_release_packet_fn_t);
extern int host_init_ikc2linux_result(int,
					struct ihk_ikc_channel_desc ***,
					int, int, unsigned long,
					unsigned long, unsigned long,
					host_alloc_fn_t,
					host_ikc_connect_fn_t,
					host_delay_fn_t,
					host_set_current_ikc2linux_fn_t,
					host_ikc_packet_handler_fn_t,
					host_init_ikc_log_fn_t,
					host_panic_fn_t);
extern int host_init_ikc2mckernel_result(unsigned long, unsigned long, int,
					host_ikc_packet_handler_fn_t,
					host_ikc_connect_fn_t,
					host_delay_fn_t,
					host_ikc_set_regular_channel_fn_t,
					host_init_ikc_log_fn_t);
extern int host_init_ikc2linux_public_result(int,
					struct ihk_ikc_channel_desc ***,
					int, int, unsigned long,
					unsigned long, unsigned long,
					host_alloc_fn_t,
					host_ikc_connect_fn_t,
					host_delay_fn_t,
					host_set_current_ikc2linux_fn_t,
					host_ikc_packet_handler_fn_t,
					host_init_ikc_log_fn_t,
					host_panic_fn_t);
extern int host_init_ikc2mckernel_public_result(unsigned long, unsigned long,
					int, host_ikc_packet_handler_fn_t,
					host_ikc_connect_fn_t,
					host_delay_fn_t,
					host_ikc_set_regular_channel_fn_t,
					host_init_ikc_log_fn_t,
					host_panic_fn_t);
struct mcctrl_signal {
	int cond;
	int sig;
	int pid;
	int tid;
	unsigned char info[128];
};
struct fake_host_schedule_proc {
	int pid;
	int status;
};
struct fake_host_schedule_thread {
	struct fake_host_schedule_proc *proc;
	int tid;
	int status;
	unsigned long allowed_mask;
	unsigned long pc;
	unsigned long sp;
};
extern int host_perf_ctrl_result(struct perf_ctrl_desc *,
				 host_perf_init_raw_fn_t,
				 host_perf_stop_fn_t,
				 host_perf_reset_fn_t,
				 host_perf_start_fn_t,
				 host_perf_read_fn_t,
				 host_perf_unexpected_fn_t);
extern int host_perf_ctrl_request_result(void *, struct ikc_scd_packet *,
					host_map_memory_fn_t,
					host_map_virtual_fn_t,
					host_unmap_virtual_fn_t,
					host_unmap_memory_fn_t,
					host_perf_init_raw_fn_t,
					host_perf_stop_fn_t,
					host_perf_reset_fn_t,
					host_perf_start_fn_t,
					host_perf_read_fn_t,
					host_perf_unexpected_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_cpu_rw_reg_request_result(void *, struct ikc_scd_packet *,
					host_map_memory_fn_t,
					host_map_virtual_fn_t,
					host_unmap_virtual_fn_t,
					host_unmap_memory_fn_t,
					host_cpu_rw_register_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_cleanup_process_request_result(void *,
					struct ikc_scd_packet *,
					host_cleanup_process_fn_t,
					host_terminate_host_fn_t,
					host_cleanup_process_log_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_cleanup_fd_request_result(void *, struct ikc_scd_packet *,
					host_cleanup_fd_fn_t,
					host_cleanup_fd_log_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_send_signal_request_result(void *, struct ikc_scd_packet *,
					host_map_memory_fn_t,
					host_map_virtual_fn_t,
					host_unmap_virtual_fn_t,
					host_unmap_memory_fn_t,
					host_do_kill_fn_t,
					host_send_signal_log_fn_t,
					host_ikc_packet_send_fn_t);
extern int host_wake_syscall_thread_request_result(struct ikc_scd_packet *,
					host_find_thread_fn_t,
					host_wakeup_thread_fn_t,
					host_thread_unlock_fn_t,
					host_wake_syscall_log_fn_t);
extern int host_debug_log_request_result(struct ikc_scd_packet *,
					host_debug_log_fn_t,
					host_debug_log_print_fn_t);
struct ihk_os_cpu_register {
	unsigned long addr;
	unsigned long val;
	unsigned long addr_ext;
	int sync;
};
struct mckernel_procfs_buffer {
	unsigned long next_pa;
	unsigned long pos;
	unsigned long size;
	char buf[0];
};
#define PROCFS_NAME_MAX 768
struct procfs_read {
	unsigned long pbuf;
	unsigned long offset;
	int count;
	int eof;
	int ret;
	int newcpu;
	int readwrite;
	char fname[PROCFS_NAME_MAX];
};
typedef struct mckernel_procfs_buffer *(*procfs_buf_alloc_fn_t)(
		unsigned long *, long);
typedef void (*procfs_buf_free_top_fn_t)(struct mckernel_procfs_buffer *);
typedef void *(*procfs_buf_copy_fn_t)(void *, const void *, size_t);
typedef struct mckernel_procfs_buffer *(*procfs_buf_phys_to_virt_fn_t)(
		unsigned long);
typedef void (*procfs_buf_free_page_fn_t)(struct mckernel_procfs_buffer *);
typedef unsigned long (*procfs_buf_phys_fn_t)(
		struct mckernel_procfs_buffer *);
typedef void *(*procfs_buf_page_alloc_fn_t)(int, unsigned long);
typedef int (*procfs_mem_page_fault_fn_t)(void *, unsigned long,
					  unsigned long);
typedef int (*procfs_mem_virt_to_phys_fn_t)(void *, unsigned long,
					    unsigned long *);
typedef int (*procfs_mem_is_memory_fn_t)(unsigned long, unsigned long);
typedef void *(*procfs_mem_phys_to_virt_fn_t)(unsigned long);
typedef void *(*procfs_mem_copy_fn_t)(void *, const void *, size_t);
typedef unsigned long (*procfs_pagemap_value_fn_t)(void *, unsigned long);
typedef unsigned long (*procfs_range_ulong_fn_t)(void *, int);
typedef const char *(*procfs_range_path_fn_t)(void *);
typedef void *(*procfs_range_next_fn_t)(void *, void *);
extern int procfs_buf_release_result(unsigned long,
				     procfs_buf_phys_to_virt_fn_t,
				     procfs_buf_free_page_fn_t);
extern struct mckernel_procfs_buffer *procfs_buf_alloc_result(unsigned long *,
		long, procfs_buf_page_alloc_fn_t, procfs_buf_phys_fn_t,
		unsigned long);
extern int procfs_buf_add_result(struct mckernel_procfs_buffer **,
				 struct mckernel_procfs_buffer **,
				 const void *, int, procfs_buf_alloc_fn_t,
				 procfs_buf_free_top_fn_t,
				 procfs_buf_copy_fn_t);
extern int procfs_release_request_result(struct procfs_read *,
					 procfs_buf_phys_to_virt_fn_t,
					 procfs_buf_free_page_fn_t);
extern int procfs_finish_request_result(struct procfs_read *, int, int,
					struct mckernel_procfs_buffer *,
					procfs_buf_phys_fn_t);
typedef int (*procfs_backlog_fn_t)(void *);
typedef void *(*procfs_backlog_alloc_fn_t)(unsigned long, unsigned long);
typedef void (*procfs_backlog_copy_fn_t)(void *, struct ikc_scd_packet *,
					 unsigned long);
typedef int (*procfs_backlog_add_fn_t)(procfs_backlog_fn_t, void *);
typedef void (*procfs_backlog_free_fn_t)(void *);
extern int procfs_backlog_result(struct ikc_scd_packet *,
				 procfs_backlog_fn_t,
				 procfs_backlog_alloc_fn_t,
				 procfs_backlog_copy_fn_t,
				 procfs_backlog_add_fn_t,
				 procfs_backlog_free_fn_t,
				 unsigned long, unsigned long);
#define PROCFS_ENTRY_MCKERNEL 1
#define PROCFS_ENTRY_STAT 2
#define PROCFS_ENTRY_MAPS 5
#define PROCFS_ENTRY_PAGEMAP 6
#define PROCFS_ENTRY_STATUS 7
#define PROCFS_ENTRY_AUXV 8
#define PROCFS_ENTRY_CMDLINE 9
#define PROCFS_ENTRY_COMM 10
#define PROCFS_RANGE_FIELD_START 1
#define PROCFS_RANGE_FIELD_END 2
#define PROCFS_RANGE_FIELD_FLAG 3
struct procfs_status_body_input {
	int pid;
	int ruid;
	int euid;
	int suid;
	int fsuid;
	int rgid;
	int egid;
	int sgid;
	int fsgid;
	int status;
	int nr_threads;
	unsigned long lockedsize;
	const char *cpu_bitmask;
	const char *cpu_list;
	const char *numa_bitmask;
	const char *numa_list;
};
struct procfs_stat_body_input {
	int tid;
	const char *comm;
	char state;
	int ppid;
	int pid;
	int nr_threads;
	int cpu_id;
};
extern int procfs_root_entry_body_result(int, const char *, const char *, int,
					 int, struct mckernel_procfs_buffer **,
					 struct mckernel_procfs_buffer **,
					 procfs_buf_alloc_fn_t,
					 procfs_buf_free_top_fn_t,
					 procfs_buf_copy_fn_t);
extern int procfs_pid_simple_entry_body_result(int, const void *, const char *,
					       unsigned int, const char *,
					       struct mckernel_procfs_buffer **,
					       struct mckernel_procfs_buffer **,
					       procfs_buf_alloc_fn_t,
					       procfs_buf_free_top_fn_t,
					       procfs_buf_copy_fn_t);
extern int procfs_maps_body_result(void *, void *, unsigned long,
				   unsigned long, unsigned long,
				   unsigned long, int,
				   struct mckernel_procfs_buffer **,
				   struct mckernel_procfs_buffer **,
				   procfs_buf_alloc_fn_t,
				   procfs_buf_free_top_fn_t,
				   procfs_buf_copy_fn_t,
				   procfs_range_ulong_fn_t,
				   procfs_range_path_fn_t,
				   procfs_range_next_fn_t);
extern unsigned long procfs_locked_size_body_result(
		void *, void *, procfs_range_ulong_fn_t,
		procfs_range_next_fn_t);
extern int procfs_status_body_result(const struct procfs_status_body_input *,
				     int, struct mckernel_procfs_buffer **,
				     struct mckernel_procfs_buffer **,
				     procfs_buf_alloc_fn_t,
				     procfs_buf_free_top_fn_t,
				     procfs_buf_copy_fn_t);
extern int procfs_stat_body_result(const struct procfs_stat_body_input *,
				   int, struct mckernel_procfs_buffer **,
				   struct mckernel_procfs_buffer **,
				   procfs_buf_alloc_fn_t,
				   procfs_buf_free_top_fn_t,
				   procfs_buf_copy_fn_t);
extern int sysfs_path_error_result(ssize_t, int, size_t);
extern int sysfs_special_kind_result(long);
extern int sysfs_string_nbits_result(size_t);
extern int sysfs_response_error_result(ssize_t);
extern int sysfs_param_sizes_valid_result(size_t, size_t, size_t, size_t,
					  size_t, size_t);
extern size_t sysfs_data_bufsize_result(void);
extern int sysfs_packet_error_result(int, int);
extern int sysfs_request_busy_result(int);
extern int sysfs_handle_pointer_valid_result(uintptr_t);
extern ssize_t sysfs_default_response_ssize_result(void);
extern int sysfs_release_response_error_result(void);
extern int sysfss_packet_prepare_result(struct ikc_scd_packet *, int, int,
					long, long);
extern int sysfs_request_packet_prepare_result(struct ikc_scd_packet *, int,
					       long);
extern int sysfs_request_handler_kind_result(int);
extern int sysfs_pointer_missing_result(uintptr_t);
extern int sysfs_should_call_show_result(uintptr_t);
extern int sysfs_should_call_store_result(uintptr_t);
extern int sysfs_should_call_release_result(uintptr_t);
#define SYSFS_REQUEST_PHASE_NONE 0
#define SYSFS_REQUEST_PHASE_SEND 1
#define SYSFS_REQUEST_PHASE_RESPONSE 2
#define SYSFS_INIT_STAGE_NONE 0
#define SYSFS_INIT_STAGE_SIZE 1
#define SYSFS_INIT_STAGE_DATA_ALLOC 2
#define SYSFS_INIT_STAGE_PARAM_ALLOC 3
#define SYSFS_INIT_STAGE_REQUEST 4
#define SYSFS_REQUEST_LOG_SEND_ERROR 1
#define SYSFS_REQUEST_LOG_RESPONSE_ERROR 2
#define SYSFSS_REQ_LOG_CALLBACK_ERROR 1
#define SYSFSS_REQ_LOG_SEND_ERROR 2
#define SYSFSS_REQ_LOG_PACKET_ERROR 3
#define SYSFSS_REQ_LOG_DEBUG 4
#define SYSFS_SNOOPING_OPS_d32 ((void *)1)
#define SYSFS_SNOOPING_OPS_s ((void *)5)
#define SYSFS_SNOOPING_OPS_pbl ((void *)6)
#define SCD_MSG_SYSFS_REQ_CREATE 0x30
#define SCD_MSG_SYSFS_REQ_MKDIR 0x32
#define SCD_MSG_SYSFS_REQ_SYMLINK 0x34
#define SCD_MSG_SYSFS_REQ_LOOKUP 0x36
#define SCD_MSG_SYSFS_REQ_UNLINK 0x38
#define SCD_MSG_SYSFS_RESP_SHOW 0x3b
#define SCD_MSG_SYSFS_REQ_SETUP 0x40
#define SYSFS_PATH_MAX 1024
struct sysfs_req_create_param {
	int mode;
	int error;
	long client_ops;
	long client_instance;
	char path[SYSFS_PATH_MAX];
	int padding;
	int busy;
};
struct sysfs_req_mkdir_param {
	int error;
	int padding;
	long handle;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};
struct sysfs_req_symlink_param {
	int error;
	int padding;
	long target;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};
struct sysfs_req_lookup_param {
	int error;
	int padding;
	long handle;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};
struct sysfs_req_unlink_param {
	int flags;
	int error;
	char path[SYSFS_PATH_MAX];
	int padding;
	int busy;
};
struct sysfs_req_setup_param {
	int error;
	int padding;
	long buf_rpa;
	long bufsize;
	char padding3[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};
struct sysfs_bitmap_param {
	int nbits;
	int padding;
	void *ptr;
};
typedef int (*sysfs_request_send_fn_t)(int, long);
typedef void (*sysfs_request_pause_fn_t)(void);
typedef void (*sysfs_request_barrier_fn_t)(void);
typedef void (*sysfs_request_log_fn_t)(int, int, int);
typedef void *(*sysfs_init_alloc_fn_t)(int, unsigned long);
typedef void (*sysfs_init_free_fn_t)(void *, int);
typedef long (*sysfs_init_phys_fn_t)(void *);
extern int sysfs_setup_special_create_result(struct sysfs_req_create_param *,
					     struct sysfs_bitmap_param *,
					     sysfs_init_phys_fn_t);
extern int sysfs_request_body_result(int, void *, long,
				     sysfs_request_send_fn_t,
				     sysfs_request_pause_fn_t,
				     sysfs_request_barrier_fn_t,
				     long *, int *);
extern int sysfs_request_logged_result(int, void *, long,
				       sysfs_request_send_fn_t,
				       sysfs_request_pause_fn_t,
				       sysfs_request_barrier_fn_t,
				       long *, sysfs_request_log_fn_t,
				       int *);
extern int sysfs_init_body_result(size_t, size_t, size_t, size_t, size_t,
				  size_t, void **, size_t *,
				  sysfs_init_alloc_fn_t,
				  sysfs_init_free_fn_t,
				  sysfs_init_phys_fn_t,
				  sysfs_request_send_fn_t,
				  sysfs_request_pause_fn_t,
				  sysfs_request_barrier_fn_t,
				  int *, int *);
typedef ssize_t (*sysfss_show_fn_t)(void *, void *, void *, size_t);
typedef ssize_t (*sysfss_store_fn_t)(void *, void *, void *, size_t);
typedef void (*sysfss_release_fn_t)(void *, void *);
typedef int (*sysfss_send_fn_t)(int, int, long, long);
typedef void (*sysfss_packet_show_fn_t)(long, void *, void *);
typedef void (*sysfss_packet_store_fn_t)(long, void *, void *, size_t);
typedef void (*sysfss_packet_release_fn_t)(long, void *, void *);
typedef void (*sysfss_packet_unknown_fn_t)(int, int, long, long, long);
typedef void (*sysfss_req_log_fn_t)(int, long, void *, void *, size_t,
				    int, int, ssize_t);
extern int sysfss_req_show_body_result(long, void *, void *, void *, size_t,
				       sysfss_show_fn_t, sysfss_send_fn_t,
				       ssize_t *, int *);
extern int sysfss_req_show_logged_result(long, void *, void *, void *, size_t,
					 uintptr_t, sysfss_show_fn_t,
					 sysfss_send_fn_t, sysfss_req_log_fn_t,
					 ssize_t *, int *);
extern int sysfss_req_store_body_result(long, void *, void *, void *, size_t,
					sysfss_store_fn_t, sysfss_send_fn_t,
					ssize_t *, int *);
extern int sysfss_req_store_logged_result(long, void *, void *, void *,
					  size_t, uintptr_t,
					  sysfss_store_fn_t,
					  sysfss_send_fn_t,
					  sysfss_req_log_fn_t,
					  ssize_t *, int *);
extern int sysfss_req_release_body_result(long, void *, void *,
					  sysfss_release_fn_t,
					  sysfss_send_fn_t, int *);
extern int sysfss_req_release_logged_result(long, void *, void *, uintptr_t,
					    sysfss_release_fn_t,
					    sysfss_send_fn_t,
					    sysfss_req_log_fn_t, int *);
extern int sysfss_packet_handler_body_result(int, int, long, long, long,
					     sysfss_packet_show_fn_t,
					     sysfss_packet_store_fn_t,
					     sysfss_packet_release_fn_t,
					     int *);
extern int sysfss_packet_handler_logged_result(int, int, long, long, long,
					      sysfss_packet_show_fn_t,
					      sysfss_packet_store_fn_t,
					      sysfss_packet_release_fn_t,
					      sysfss_packet_unknown_fn_t,
					      int *);
extern unsigned long procfs_mem_reason_result(int);
extern int procfs_mem_chunk_size_result(unsigned long, unsigned long);
extern int procfs_mem_copy_body_result(void *, void *, void *, unsigned long,
				       unsigned long, int,
				       procfs_mem_page_fault_fn_t,
				       procfs_mem_virt_to_phys_fn_t,
				       procfs_mem_is_memory_fn_t,
				       procfs_mem_phys_to_virt_fn_t,
				       procfs_mem_copy_fn_t);
extern int procfs_pagemap_range_result(unsigned long, int,
				       unsigned long *, unsigned long *);
extern int procfs_pagemap_body_result(void *, unsigned long *, unsigned long,
				      unsigned long, int,
				      procfs_pagemap_value_fn_t);
extern int procfs_status_state_result(int);
extern char procfs_thread_stat_state_result(int, int);
extern int procfs_default_count_result(void);
extern int procfs_remote_count_result(unsigned long, int);
extern int procfs_remote_npages_result(int);
extern int procfs_format_error_result(int, int);
extern unsigned long procfs_locked_kb_result(unsigned long);
extern char procfs_maps_read_char_result(unsigned long);
extern char procfs_maps_write_char_result(unsigned long);
extern char procfs_maps_exec_char_result(unsigned long);
extern char procfs_maps_private_char_result(unsigned long);
extern int procfs_maps_path_kind_result(unsigned long, unsigned long,
					unsigned long, unsigned long,
					unsigned long, unsigned long,
					unsigned long);
extern unsigned long procfs_pagemap_next_result(unsigned long);
extern unsigned int procfs_auxv_limit_result(void);
extern unsigned int procfs_cmdline_limit_result(uintptr_t, unsigned int);
extern int procfs_is_release_result(int);
extern int procfs_root_matched_result(int);
extern int procfs_osnum_match_result(int, int);
extern int procfs_zero_length_result(unsigned long);
extern unsigned long procfs_locked_size_add_result(unsigned long,
						   unsigned long,
						   unsigned long,
						   unsigned long);
extern int procfs_bitmask_next_offset_result(int, int);
extern int procfs_pbuf_is_empty_result(unsigned long);
extern int procfs_backlog_needed_result(uintptr_t);
extern int procfs_lock_failed_action_result(uintptr_t);
extern int procfs_lock_retry_result(void);
extern int procfs_thread_tid_result(int, int, int);
extern int procfs_task_missing_terminal_result(int);
extern int procfs_pointer_present_result(uintptr_t);
extern int procfs_buffer_chain_attach_result(unsigned long, uintptr_t);
extern int procfs_entry_kind_result(const char *);
extern uintptr_t procfs_comm_basename_result(uintptr_t);
extern uintptr_t procfs_comm_name_result(uintptr_t, uintptr_t);
extern int pager_linux_io_retry_result(ssize_t);
extern int pager_linux_io_stop_result(ssize_t);
extern int pager_linux_io_first_result(ssize_t);
extern ssize_t pager_linux_io_advance_result(ssize_t, ssize_t);
extern size_t pager_linux_io_remaining_result(size_t, ssize_t);
extern uintptr_t pager_linux_io_next_buf_result(uintptr_t, ssize_t);
extern int pager_linux_io_complete_result(ssize_t, size_t);
extern int pager_copy_fault_retry_result(int);
extern int pager_copy_fault_error_result(int);
extern int pager_myalloc_fits_result(size_t, size_t, size_t);
extern size_t pager_myalloc_next_alloced_result(size_t, size_t);
extern int pager_copy_size_error_result(size_t);
extern unsigned long pager_fault_addr_result(unsigned long);
extern size_t pager_read_chunk_size_result(size_t, size_t);
extern int pager_arealist_tail_room_result(int);
extern int pager_arealist_count_add_result(int, int);
extern ssize_t pager_addrpair_size_result(unsigned long, unsigned long);
extern ssize_t pager_file_pos_result(ssize_t, ssize_t);
extern ssize_t pager_arealist_write_result(ssize_t, int, size_t);
extern int pager_mlock_more_result(unsigned long);
extern unsigned long pager_mlock_next_start_result(unsigned long);
extern int pager_mlock_container_empty_result(uintptr_t, uintptr_t, int, int);
extern int pager_mlock_needs_next_result(int, int);
extern int pager_mlock_reset_count_result(void);
extern int pager_mlock_next_count_result(int);
extern ssize_t pager_pagein_data_pos_result(unsigned int, unsigned int,
					    size_t, size_t);
extern int pager_pageout_args_result(uintptr_t, uintptr_t, size_t,
				     unsigned long, unsigned long);
extern int pager_skip_anon_range_result(int, unsigned long, unsigned long,
					unsigned long, unsigned long,
					unsigned long, unsigned long);
extern int pager_range_locked_result(unsigned long);
extern int pager_skip_physical_removal_result(int);
extern int pager_fd_valid_result(int);
extern int pager_should_unlink_swap_result(long);
extern long pager_io_short_result(long);
extern int zeroobj_initial_flags_result(void);
extern int zeroobj_initial_refcnt_result(void);
extern int zeroobj_initial_page_mode_result(void);
extern long zeroobj_initial_page_offset_result(void);
extern int zeroobj_get_page_validate_result(long, int, int);
extern int zeroobj_alloc_body_result(void *, size_t, void *, void *,
	void (*)(int, int, void *, void *, uintptr_t), void (*)(void *),
	void (*)(void *), void *(*)(size_t, unsigned long), void (*)(void *),
	void *(*)(void *, int, size_t), void (*)(void *, void *),
	void *(*)(int, unsigned long), void (*)(void *, int),
	uintptr_t (*)(void *), void *(*)(uintptr_t), int (*)(void *),
	void (*)(void *), void (*)(void *), void (*)(void *, void *),
	void (*)(void *));
extern int zeroobj_create_body_result(void **, void *, int (*)(void),
	void *(*)(void), void (*)(void *),
	void (*)(int, int, void *, void *, uintptr_t));
extern int zeroobj_get_page_body_result(void);
extern int shmobj_init_pgshift_result(int);
extern size_t shmobj_pgsize_result(int);
extern int shmobj_initial_flags_result(void);
extern int shmobj_indexed_flags_result(int);
extern size_t shmobj_real_segsz_result(size_t, size_t);
extern int shmobj_page_contains_offset_result(long, int, long);
extern int shmobj_destroy_page_npages_result(int);
extern size_t shmobj_destroy_page_size_result(int);
extern int shmobj_destroy_index_word_result(int);
extern unsigned long shmobj_destroy_index_mask_result(int);
extern int shmlock_user_locked_result(size_t);
extern int shmlock_user_match_result(int, int);
extern int shmlock_user_is_list_head_result(uintptr_t, uintptr_t);
extern size_t shmlock_user_after_unlock_result(size_t, size_t);
extern int shmlock_user_should_free_result(size_t);
extern int shmobj_has_user_result(uintptr_t);
extern int shmobj_destroy_page_count_invalid_result(int);
extern int shmobj_destroy_page_should_free_result(int, int);
extern int shmobj_should_free_direct_result(int);
extern int shmobj_destroy_missing_flag_result(int);
extern int shmobj_initial_refcnt_result(void);
extern int shmobj_initial_index_result(void);
extern int shmobj_initial_ds_pgshift_result(void);
extern int shmobj_get_page_validate_result(size_t, long, int);
extern int shmobj_lookup_page_validate_result(size_t, long);
extern int shmobj_page_npages_result(int);
extern int shmobj_page_pgshift_result(int);
extern int shmobj_need_alloc_page_result(uintptr_t);
extern int shmobj_new_page_mode_result(void);
extern int shmobj_new_page_count_result(void);
extern long shmobj_new_page_mapped_result(void);
extern int shmobj_page_mode_valid_for_new_result(int);
extern int shmobj_lookup_page_missing_error_result(uintptr_t);
extern int shmobj_lookup_should_store_phys_result(uintptr_t);
extern int shmobj_lookup_page_body_result(void *, void *, size_t, long, int,
	uintptr_t *, uintptr_t *, void (*)(void *), void (*)(void *),
	void (*)(void *), void (*)(void *), void *(*)(void *, long),
	uintptr_t (*)(void *),
	void (*)(int, void *, long, int, void *, int, uintptr_t));
extern int shmobj_update_args_result(int, int, int);
extern size_t shmobj_update_orig_pgsize_result(int);
extern uintptr_t shmobj_update_page_phys_result(uintptr_t, size_t);
extern long shmobj_update_page_offset_result(long, size_t);
extern int shmobj_pte_missing_result(uintptr_t);
extern int shmobj_update_has_more_pages_result(size_t, size_t);
extern size_t shmobj_update_next_page_off_result(size_t, size_t);
extern int shmobj_update_page_body_result(void *, void *, void *, void *,
	void *, void (*)(void *), void (*)(void *), uintptr_t (*)(void *),
	void *(*)(void *, void *, size_t *, int *), int (*)(void *),
	void (*)(void *, int), int (*)(void *), void (*)(void *, int),
	long (*)(void *), void (*)(void *, long), int (*)(void *),
	void (*)(void *, int), long (*)(void *), void (*)(void *, long),
	void *(*)(uintptr_t), void (*)(void *, void *),
	void (*)(int, void *, void *, void *, void *, int));
extern int shmobj_get_page_body_result(void *, void *, size_t, long, int,
	uintptr_t *, uintptr_t, void (*)(void *), void (*)(void *),
	void (*)(void *), void (*)(void *), void *(*)(void *, long),
	void *(*)(int, int, unsigned long, uintptr_t), void (*)(void *, int),
	uintptr_t (*)(void *), void *(*)(uintptr_t), int (*)(void *),
	void (*)(void *, int), void (*)(void *, long), void (*)(void *, int),
	void (*)(void *, int), void (*)(void *, long), void (*)(void *, void *),
	void (*)(void *), uintptr_t (*)(void *),
	void *(*)(void *, int, size_t), void (*)(void),
	void (*)(int, void *, long, int, void *, int, void *, uintptr_t));
extern int shmobj_destroy_body_result(void *, void *, size_t, int,
	void (*)(void *), size_t (*)(void *), void (*)(void *, size_t),
	void (*)(void *), void (*)(void *), void (*)(void *),
	void *(*)(void *), void (*)(void *, void *), uintptr_t (*)(void *),
	void *(*)(uintptr_t), int (*)(void *), int (*)(void *),
	int (*)(void *), void (*)(void *, int), void (*)(size_t, size_t),
	void (*)(void *), void (*)(void *, int, unsigned long),
	void (*)(int, void *, void *, uintptr_t, size_t, size_t));
extern int shmobj_free_body_result(void *, void *, int, void (*)(void *),
	void (*)(void *), void (*)(void *), void (*)(int, void *));
extern int shmobj_create_body_result(void *, void **, size_t, int, size_t,
	void *(*)(size_t, unsigned long), void (*)(void *),
	void *(*)(void *, int, size_t), int (*)(void),
	void *(*)(void *, void *, int, size_t, size_t, int),
	void (*)(int, void *, void *, int));
extern int shmobj_create_indexed_body_result(void *, void **,
	int (*)(void *, void **), int (*)(void *), void (*)(void *, int),
	void *(*)(void *));
extern int shmlock_user_free_body_result(void *, size_t (*)(void *),
	void (*)(void *), void (*)(void *), void (*)(void));
extern int shmlock_user_get_body_result(int, void **, size_t, void *(*)(void),
	void *(*)(void *), int (*)(void *), void *(*)(size_t, unsigned long),
	void (*)(void *, int), void (*)(void *));
extern size_t gencore_align32_result(size_t);
extern size_t gencore_alignpage_result(size_t);
extern int gencore_range_inaccessible_result(unsigned long);
extern int gencore_prstatus_size_result(void);
extern int gencore_prpsinfo_size_result(void);
extern int gencore_auxv_size_result(void);
extern int gencore_fill_elf_header_body_result(void *, int);
extern int gencore_fill_prstatus_body_result(void *, void *, void *, int,
	void (*)(void *, void *, void *, int));
extern int gencore_fill_prpsinfo_body_result(void *, int, int, const char *);
extern int gencore_fill_auxv_body_result(void *, const unsigned long *);
extern int gencore_fill_note_phdr_body_result(void *, unsigned long, long);
extern int gencore_fill_load_phdr_body_result(void *, unsigned long,
	unsigned long, unsigned long, unsigned long);
extern int gencore_fill_initial_coretable_body_result(void *, unsigned long,
	unsigned long, unsigned long, long, long);
extern int gencore_count_range_chunks_body_result(unsigned long, unsigned long,
	unsigned long, void *, int *,
	int (*)(void *, unsigned long, unsigned long *));
extern int gencore_scan_ranges_for_counts_body_result(void *, void *, int *,
	int *, void *(*)(void *), void *(*)(void *, void *),
	unsigned long (*)(void *), unsigned long (*)(void *),
	unsigned long (*)(void *), long (*)(void *),
	void (*)(unsigned long, unsigned long, unsigned long, long),
	int (*)(void *, unsigned long, unsigned long *));
extern int gencore_fill_load_phdrs_body_result(void *, void *, int *,
	unsigned long *, void *(*)(void *), void *(*)(void *, void *),
	unsigned long (*)(void *), unsigned long (*)(void *),
	unsigned long (*)(void *));
extern int gencore_emit_demand_coretable_body_result(void *, int *,
	unsigned long, unsigned long, void *,
	int (*)(void *, unsigned long, unsigned long *),
	void (*)(int, long, unsigned long, unsigned long));
extern int gencore_emit_linear_coretable_body_result(void *, int *,
	unsigned long, unsigned long, unsigned long, unsigned long, void *,
	int (*)(void *, unsigned long, unsigned long *),
	unsigned long (*)(unsigned long),
	void (*)(int, long, unsigned long, unsigned long));
extern int gencore_emit_coretable_ranges_body_result(void *, void *, int *,
	unsigned long, unsigned long, void *, unsigned long *,
	void *(*)(void *), void *(*)(void *, void *),
	unsigned long (*)(void *), unsigned long (*)(void *),
	unsigned long (*)(void *), int (*)(void *, unsigned long, unsigned long *),
	unsigned long (*)(unsigned long),
	void (*)(int, long, unsigned long, unsigned long));
extern int gencore_freecore_body_result(void **, void *(*)(unsigned long),
	void (*)(void *));
extern int gencore_generate_image_body_result(void *, void *, void *, void **,
	int *, int, unsigned long, unsigned long, char *, int, size_t, size_t,
	size_t, void *(*)(size_t, unsigned long), void (*)(void *, size_t),
	void (*)(void *), int (*)(void *),
	void (*)(void *, void *, char *, int), unsigned long (*)(unsigned long),
	void *(*)(void *), void *(*)(void *, void *),
	unsigned long (*)(void *), unsigned long (*)(void *),
	unsigned long (*)(void *), int (*)(void *, unsigned long, unsigned long *),
	void (*)(int, long, unsigned long, unsigned long),
	void (*)(int), void (*)(unsigned long, int));
extern int gencore_note_size_threads_body_result(void *, int,
	void *(*)(void *), void *(*)(void *, void *), int (*)(void *),
	int (*)(void));
extern int gencore_fill_note_threads_body_result(void *, void *, char *, int,
	int, void **, void *(*)(void *), void *(*)(void *, void *),
	int (*)(void *), void *(*)(void *), int (*)(void),
	void (*)(void *, void *, int), void (*)(void *, void *, void *),
	void (*)(void *, void *, char *), void (*)(void *, void *));
extern int hugefileobj_expected_p2align_result(int);
extern int hugefileobj_validate_p2align_result(int, int);
extern long hugefileobj_page_index_result(long, int);
extern int hugefileobj_npages_per_page_result(size_t);
extern size_t hugefileobj_pgsize_result(int);
extern int hugefileobj_initial_status_result(void);
extern int hugefileobj_initial_refcnt_result(void);
extern int hugefileobj_pointer_present_result(uintptr_t);
extern int hugefileobj_pointer_missing_result(uintptr_t);
extern int hugefileobj_page_present_result(uintptr_t);
extern size_t hugefileobj_page_array_bytes_result(size_t);
extern int hugefileobj_create_nr_pages_result(long, size_t, int);
extern int hugefileobj_needs_grow_result(size_t, int);
extern size_t hugefileobj_copy_bytes_result(size_t);
extern size_t hugefileobj_zero_bytes_result(size_t, size_t);
extern size_t hugefileobj_zero_start_index_result(size_t);
extern int hugefileobj_free_body_result(void *, void *,
	void (*)(void *), void (*)(void *), void (*)(void *), void (*)(void *));
extern int hugefileobj_cleanup_body_result(void *, void *,
	void (*)(void *), void (*)(void *), int (*)(void *),
	void *(*)(void *), void (*)(void *), void (*)(void *));
extern int hugefileobj_inner_free_body_result(void *, void *, void *, void *,
	size_t, size_t, void (*)(void *), void (*)(void *), void (*)(void *),
	void (*)(void *, int), void *(*)(void *, long), void (*)(void *),
	void (*)(int, void *, long, long, size_t, uintptr_t));
extern int hugefileobj_get_page_body_result(void *, void *, long, int, int,
	size_t, uintptr_t, uintptr_t *, void (*)(void *), void (*)(void *),
	void *(*)(void *, long), void (*)(void *, long, void *),
	void *(*)(int, int, unsigned long, uintptr_t),
	void *(*)(void *, int, size_t), uintptr_t (*)(void *),
	void (*)(int, void *, long, long, size_t, uintptr_t));
extern int hugefileobj_create_body_result(void *, void *, size_t, long, int,
	size_t, size_t, void *, int *, uintptr_t, unsigned long,
	void (*)(void *), void (*)(void *),
	void *(*)(size_t, unsigned long), void (*)(void *),
	void *(*)(void *, const void *, size_t), void *(*)(void *, int, size_t),
	void (*)(void *, size_t), void (*)(void *, void *),
	void (*)(void *, size_t),
	void (*)(int, void *, long, long, size_t, uintptr_t));
extern int hugefileobj_pre_create_body_result(void *, uintptr_t, int,
	unsigned int, int, const char *, size_t, size_t, void *, void **,
	int *, void (*)(void *), void (*)(void *), void *(*)(uintptr_t),
	void *(*)(size_t, unsigned long), void (*)(void *), void *(*)(void *),
	void (*)(void *, uintptr_t), void (*)(void *, size_t),
	void (*)(void *, int), void (*)(void *, void *),
	void (*)(void *, size_t), void (*)(void *),
	void (*)(void *, unsigned int), void (*)(void *, int),
	void (*)(void *, void *), void (*)(void *, int),
	void (*)(void *, void *), void (*)(void *, const void *, size_t),
	void (*)(void *), void (*)(int, void *), void (*)(int));
extern void *hugefileobj_lookup_body_result(uintptr_t, void *,
	void *(*)(void *), void *(*)(void *, void *),
	uintptr_t (*)(void *), int (*)(void *), void (*)(void *));

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static void require_expr(int condition, int line, const char *expr)
{
	if (!condition) {
		fprintf(stderr, "object_helpers require failed at line %d: %s\n",
			line, expr);
		exit(31);
	}
}
#define require(condition) require_expr((condition), __LINE__, #condition)

static long ptr_offset(const char *base, uintptr_t ptr)
{
	if (!ptr)
		return -1;
	return (const char *)ptr - base;
}

static int fake_sysfs_send_error;
static int fake_sysfs_send_calls;
static int fake_sysfs_release_calls;
static int fake_sysfs_req_log_calls;
static int fake_sysfs_req_log_mask;
static int fake_sysfs_req_last_event;
static long fake_sysfs_req_last_nodeh;
static long fake_sysfs_req_last_ops;
static long fake_sysfs_req_last_instance;
static size_t fake_sysfs_req_last_size;
static int fake_sysfs_req_last_error;
static int fake_sysfs_req_last_packet_err;
static ssize_t fake_sysfs_req_last_ssize;
static int fake_sysfs_last_msg;
static int fake_sysfs_last_err;
static long fake_sysfs_last_arg1;
static long fake_sysfs_last_arg2;
static int fake_sysfs_packet_show_calls;
static int fake_sysfs_packet_store_calls;
static int fake_sysfs_packet_release_calls;
static int fake_sysfs_packet_unknown_calls;
static long fake_sysfs_packet_last_nodeh;
static long fake_sysfs_packet_last_ops;
static long fake_sysfs_packet_last_instance;
static size_t fake_sysfs_packet_last_size;
static int fake_sysfs_packet_last_msg;
static int fake_sysfs_packet_last_error;
static long fake_sysfs_packet_last_arg1;
static long fake_sysfs_packet_last_arg2;
static long fake_sysfs_packet_last_arg3;
static int fake_sysfs_request_send_error;
static int fake_sysfs_request_send_calls;
static int fake_sysfs_request_last_msg;
static long fake_sysfs_request_last_arg1;
static int fake_sysfs_request_pause_calls;
static int fake_sysfs_request_barrier_calls;
static int fake_sysfs_request_log_calls;
static int fake_sysfs_request_last_event;
static int fake_sysfs_request_log_last_msg;
static int fake_sysfs_request_log_last_error;
static int *fake_sysfs_request_busy_ptr;
static int fake_sysfs_init_alloc_calls;
static int fake_sysfs_init_free_calls;
static int fake_sysfs_init_fail_alloc_call;
static unsigned char fake_sysfs_init_data_buf[4096];
static struct sysfs_req_setup_param fake_sysfs_init_param;
static void *fake_sysfs_special_direct_ptr;
static void *fake_sysfs_special_string_ptr;
static void *fake_sysfs_special_bitmap_data_ptr;
static void *fake_sysfs_special_dest_ptr;
static int fake_procfs_thread_send_calls;
static int fake_procfs_thread_pause_calls;
static int fake_procfs_thread_send_rc;
static void *fake_procfs_thread_last_channel;
static struct ikc_scd_packet *fake_procfs_thread_last_packet;
static int *fake_procfs_thread_done_ptr;
static int fake_procfs_answer_send_calls;
static void *fake_procfs_answer_last_channel;
static int fake_procfs_answer_last_msg;
static int fake_procfs_answer_last_err;
static int fake_procfs_answer_last_ref;
static int fake_procfs_answer_last_pid;
static unsigned long fake_procfs_answer_last_arg;
static void *fake_procfs_answer_last_reply;
static unsigned long fake_procfs_answer_last_req_valid;
static unsigned long fake_procfs_answer_last_resp_pa;
static void *fake_procfs_answer_last_header_channel;
static int fake_host_perf_init_calls;
static int fake_host_perf_stop_calls;
static int fake_host_perf_reset_calls;
static int fake_host_perf_start_calls;
static int fake_host_perf_read_calls;
static int fake_host_perf_unexpected_calls;
static int fake_host_perf_init_rc;
static int fake_host_perf_stop_rc;
static int fake_host_perf_reset_rc;
static int fake_host_perf_start_rc;
static int fake_host_perf_last_counter;
static unsigned int fake_host_perf_last_config;
static int fake_host_perf_last_mode;
static unsigned long fake_host_perf_last_mask;
static int fake_host_perf_last_flags;
static int fake_host_cpu_rw_calls;
static int fake_host_cpu_rw_rc;
static void *fake_host_cpu_rw_last_desc;
static int fake_host_cpu_rw_last_op;
static int fake_host_cleanup_process_calls;
static int fake_host_cleanup_process_rc;
static int fake_host_cleanup_process_last_pid;
static int fake_host_terminate_calls;
static int fake_host_terminate_last_pid;
static void *fake_host_terminate_last_thread;
static int fake_host_cleanup_process_log_calls;
static int fake_host_cleanup_process_log_last_pid;
static unsigned long fake_host_cleanup_process_log_last_thread;
static int fake_host_cleanup_fd_calls;
static int fake_host_cleanup_fd_rc;
static int fake_host_cleanup_fd_last_pid;
static int fake_host_cleanup_fd_last_fd;
static int fake_host_cleanup_fd_log_calls;
static int fake_host_cleanup_fd_log_last_pid;
static unsigned long fake_host_cleanup_fd_log_last_fd;
static int fake_host_cleanup_fd_log_last_err;
static int fake_host_send_signal_kill_calls;
static int fake_host_send_signal_kill_last_pid;
static int fake_host_send_signal_kill_last_tid;
static int fake_host_send_signal_kill_last_sig;
static int fake_host_send_signal_info_matches;
static int fake_host_send_signal_rc;
static int fake_host_send_signal_log_calls;
static int fake_host_send_signal_log_last_pid;
static int fake_host_send_signal_log_last_tid;
static int fake_host_send_signal_log_last_sig;
static int fake_host_send_signal_log_last_rc;
static int fake_host_send_signal_event_seq;
static int fake_host_send_signal_track_events;
static int fake_host_send_signal_reply_event;
static int fake_host_send_signal_kill_event;
static int fake_host_send_signal_log_event;
static int fake_host_find_thread_calls;
static int fake_host_find_thread_last_pid;
static int fake_host_find_thread_last_tid;
static int fake_host_find_thread_missing;
static int fake_host_find_thread_storage;
static void *fake_host_find_thread_result;
static int fake_host_wakeup_thread_calls;
static void *fake_host_wakeup_thread_last_thread;
static int fake_host_unlock_thread_calls;
static void *fake_host_unlock_thread_last_thread;
static int fake_host_wake_log_calls;
static int fake_host_wake_log_last_tid;
static int fake_host_wake_log_last_found;
static int fake_host_wake_event_seq;
static int fake_host_wake_log_event;
static int fake_host_wake_event;
static int fake_host_unlock_event;
static int fake_host_debug_log_calls;
static unsigned long fake_host_debug_log_last_code;
static int fake_host_debug_print_calls;
static unsigned long fake_host_debug_print_last_code;
static int fake_host_debug_event_seq;
static int fake_host_debug_print_event;
static int fake_host_debug_log_event;
static int fake_host_rpf_profile_enabled_calls;
static int fake_host_rpf_profile_enabled_result;
static void *fake_host_rpf_profile_last_thread;
static int fake_host_rpf_timestamp_calls;
static int fake_host_rpf_preempt_disable_calls;
static int fake_host_rpf_preempt_enable_calls;
static int fake_host_rpf_page_fault_calls;
static void *fake_host_rpf_page_fault_last_thread;
static unsigned long fake_host_rpf_page_fault_last_addr;
static unsigned long fake_host_rpf_page_fault_last_reason;
static int fake_host_rpf_profile_event_calls;
static int fake_host_rpf_profile_event_last_event;
static unsigned long fake_host_rpf_profile_event_last_delta;
static int fake_host_rpf_log_calls;
static void *fake_host_rpf_log_last_thread;
static unsigned long fake_host_rpf_log_last_addr;
static unsigned long fake_host_rpf_log_last_reason;
static int fake_host_rpf_event_seq;
static int fake_host_rpf_log_event;
static int fake_host_rpf_preempt_disable_event;
static int fake_host_rpf_page_fault_event;
static int fake_host_rpf_preempt_enable_event;
static int fake_host_rpf_profile_event_event;
static int fake_host_rpf_answer_event;
static int fake_host_rpf_request_body_calls;
static int fake_host_rpf_request_body_last_err;
static int fake_host_rpf_request_body_last_ref;
static int fake_host_rpf_request_body_last_tid;
static unsigned long fake_host_rpf_request_body_last_addr;
static unsigned long fake_host_rpf_request_body_last_reason;
static int fake_host_rpf_request_alloc_calls;
static unsigned long fake_host_rpf_request_alloc_last_size;
static unsigned long fake_host_rpf_request_alloc_last_flags;
static int fake_host_rpf_request_alloc_fail;
static int fake_host_rpf_request_copy_calls;
static void *fake_host_rpf_request_copy_last_dst;
static struct ikc_scd_packet *fake_host_rpf_request_copy_last_src;
static unsigned long fake_host_rpf_request_copy_last_size;
static int fake_host_rpf_request_defer_calls;
static void *fake_host_rpf_request_defer_last_thread;
static void *fake_host_rpf_request_defer_last_arg;
static host_backlog_fn_t fake_host_rpf_request_defer_last_backlog;
static int fake_host_rpf_request_wakeup_calls;
static void *fake_host_rpf_request_wakeup_last_thread;
static int fake_host_rpf_request_wakeup_last_state;
static int fake_host_rpf_request_unlock_calls;
static void *fake_host_rpf_request_unlock_last_thread;
static int fake_host_rpf_request_missing_log_calls;
static int fake_host_rpf_request_missing_log_last_tid;
static int fake_host_rpf_request_event_seq;
static int fake_host_rpf_request_body_event;
static int fake_host_rpf_request_copy_event;
static int fake_host_rpf_request_defer_event;
static int fake_host_rpf_request_wakeup_event;
static int fake_host_rpf_request_unlock_event;
static int fake_host_rpf_request_missing_log_event;
static struct ikc_scd_packet fake_host_rpf_request_copy_packet;
static struct fake_host_schedule_proc fake_host_schedule_proc;
static struct fake_host_schedule_thread fake_host_schedule_thread;
static int fake_host_schedule_current_cpu;
static int fake_host_schedule_obtain_cpuid;
static int fake_host_schedule_proc_calls;
static int fake_host_schedule_current_cpu_calls;
static int fake_host_schedule_cpu_allowed_calls;
static int fake_host_schedule_obtain_calls;
static int fake_host_schedule_proc_pid_calls;
static int fake_host_schedule_pc_calls;
static int fake_host_schedule_sp_calls;
static int fake_host_schedule_invalid_log_calls;
static void *fake_host_schedule_invalid_log_last_thread;
static int fake_host_schedule_received_log_calls;
static void *fake_host_schedule_received_last_thread;
static int fake_host_schedule_received_last_pid;
static unsigned long fake_host_schedule_received_last_pc;
static unsigned long fake_host_schedule_received_last_sp;
static int fake_host_schedule_received_last_cpu;
static int fake_host_schedule_no_cpu_log_calls;
static int fake_host_schedule_set_tid_calls;
static int fake_host_schedule_set_tid_last_tid;
static int fake_host_schedule_set_proc_status_calls;
static int fake_host_schedule_set_thread_status_calls;
static int fake_host_schedule_chain_thread_calls;
static int fake_host_schedule_chain_process_calls;
static int fake_host_schedule_runq_add_calls;
static void *fake_host_schedule_runq_last_thread;
static int fake_host_schedule_runq_last_cpu;
static int fake_host_schedule_queued_log_calls;
static int fake_host_schedule_queued_last_pid;
static int fake_host_schedule_queued_last_tid;
static int fake_host_schedule_queued_last_cpu;
static int fake_host_schedule_queued_last_status;
static int fake_host_schedule_event_seq;
static int fake_host_schedule_set_tid_event;
static int fake_host_schedule_set_proc_status_event;
static int fake_host_schedule_set_thread_status_event;
static int fake_host_schedule_chain_thread_event;
static int fake_host_schedule_chain_process_event;
static int fake_host_schedule_runq_event;
static int fake_host_schedule_queued_log_event;
static int fake_host_cleanup_event_seq;
static int fake_host_cleanup_process_log_event;
static int fake_host_cleanup_process_event;
static int fake_host_cleanup_fd_event;
static int fake_host_cleanup_fd_log_event;
static int fake_host_reply_event;
static int fake_host_terminate_event;
static int fake_host_map_memory_calls;
static int fake_host_map_virtual_calls;
static int fake_host_unmap_virtual_calls;
static int fake_host_unmap_memory_calls;
static int fake_host_map_virtual_fail;
static unsigned long fake_host_map_memory_result;
static unsigned long fake_host_map_last_in_phys;
static unsigned long fake_host_map_last_size;
static unsigned long fake_host_map_virtual_last_phys;
static int fake_host_map_virtual_last_npages;
static int fake_host_map_virtual_last_attr;
static void *fake_host_unmap_virtual_last_addr;
static int fake_host_unmap_virtual_last_npages;
static unsigned long fake_host_unmap_memory_last_phys;
static unsigned long fake_host_unmap_memory_last_size;
static void *fake_host_map_virtual_result;
static struct perf_ctrl_desc fake_host_mapped_perf_desc;
static struct ihk_os_cpu_register fake_host_mapped_cpu_reg;
static struct mcctrl_signal fake_host_mapped_signal;
static int fake_host_dispatch_init_ack_log_calls;
static int fake_host_dispatch_prepare_calls;
static unsigned long fake_host_dispatch_prepare_last_arg;
static int fake_host_dispatch_prepare_rc;
static int fake_host_dispatch_schedule_log_calls;
static unsigned long fake_host_dispatch_schedule_last_arg;
static int fake_host_dispatch_procfs_calls;
static int fake_host_dispatch_procfs_last_msg;
static int fake_host_dispatch_procfs_rc;
static struct ikc_scd_packet *fake_host_dispatch_procfs_last_packet;
static int fake_host_dispatch_sysfs_calls;
static void *fake_host_dispatch_sysfs_last_channel;
static int fake_host_dispatch_sysfs_last_msg;
static int fake_host_dispatch_sysfs_last_err;
static long fake_host_dispatch_sysfs_last_arg1;
static long fake_host_dispatch_sysfs_last_arg2;
static long fake_host_dispatch_sysfs_last_arg3;
static int fake_host_dispatch_unknown_calls;
static int fake_host_dispatch_unknown_last_msg;
static int fake_host_dispatch_unknown_last_ref;
static int fake_host_dispatch_release_calls;
static struct ikc_scd_packet *fake_host_dispatch_release_last_packet;
static int fake_host_handler_response_calls;
static int fake_host_handler_current_calls;
static struct ihk_ikc_channel_desc fake_host_ikc_channels[4];
static struct ihk_ikc_channel_desc *fake_host_ikc_table_storage[4];
static struct ihk_ikc_channel_desc **fake_host_ikc_table_ptr;
static int fake_host_ikc_alloc_calls;
static unsigned long fake_host_ikc_alloc_last_size;
static unsigned long fake_host_ikc_alloc_last_flags;
static int fake_host_ikc_alloc_fail;
static int fake_host_ikc_connect_calls;
static int fake_host_ikc_connect_failures;
static int fake_host_ikc_connect_last_port;
static int fake_host_ikc_connect_last_pkt_size;
static int fake_host_ikc_connect_last_queue_size;
static int fake_host_ikc_connect_last_magic;
static int fake_host_ikc_connect_last_intr_cpu;
static int fake_host_ikc_connect_handler_matches;
static int fake_host_ikc_delay_calls;
static unsigned long fake_host_ikc_delay_last_usec;
static int fake_host_ikc_set_current_calls;
static void *fake_host_ikc_set_current_last_channel;
static int fake_host_ikc_set_regular_calls;
static void *fake_host_ikc_set_regular_last_channel;
static int fake_host_ikc_set_regular_last_cpu;
static int fake_host_ikc_log_counts[5];
static int fake_host_ikc_log_last_event;
static int fake_host_ikc_panic_calls;
static int fake_host_prepare_monitor_status[4];
static int fake_host_prepare_monitor_calls;
static int fake_host_prepare_monitor_last_cpu;
static int fake_host_prepare_alloc_calls;
static int fake_host_prepare_alloc_fail;
static unsigned long fake_host_prepare_alloc_last_size;
static unsigned long fake_host_prepare_alloc_last_flags;
static int fake_host_prepare_free_calls;
static void *fake_host_prepare_free_last_ptr;
static int fake_host_prepare_copy_calls;
static unsigned long fake_host_prepare_copy_last_size;
static int fake_host_prepare_create_calls;
static int fake_host_prepare_create_fail;
static unsigned long fake_host_prepare_create_last_entry;
static void *fake_host_prepare_create_last_cpuset;
static unsigned long fake_host_prepare_create_last_cpuset_size;
static int fake_host_prepare_destroy_calls;
static int fake_host_prepare_ranges_calls;
static int fake_host_prepare_ranges_rc;
static void *fake_host_prepare_ranges_last_thread;
static struct program_load_desc *fake_host_prepare_ranges_last_pn;
static struct program_load_desc *fake_host_prepare_ranges_last_p;
static unsigned long fake_host_prepare_ranges_last_attr;
static int fake_host_prepare_nr_numa_nodes;
static int fake_host_prepare_nr_numa_calls;
static int fake_host_prepare_flush_calls;
static int fake_host_prepare_tofu_calls;
static int fake_host_prepare_log_counts[16];
static int fake_host_prepare_log_last_event;
static unsigned long fake_host_prepare_log_arg0;
static unsigned long fake_host_prepare_log_arg1;
static unsigned long fake_host_prepare_log_arg2;
#define FAKE_HOST_PREPARE_THREAD_SIZE 5568
#define FAKE_HOST_PREPARE_PROCESS_SIZE 1728
#define FAKE_HOST_PREPARE_VM_SIZE 512
#define FAKE_HOST_PREPARE_ASPACE_SIZE 256
#define FAKE_HOST_PREPARE_THREAD_ROUTINE_OFF 24
#define FAKE_HOST_PREPARE_THREAD_VM_OFF 4200
#define FAKE_HOST_PREPARE_THREAD_PROC_OFF 4304
#define FAKE_HOST_PREPARE_PROCESS_VM_OFF 128
#define FAKE_HOST_PREPARE_PROCESS_PID_OFF 456
	#define FAKE_HOST_PREPARE_PROCESS_PGID_OFF 460
	#define FAKE_HOST_PREPARE_PROCESS_RLIMIT_OFF 512
	#define FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_OFF 1136
	#define FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_LEN_OFF 1144
	#define FAKE_HOST_PREPARE_PROCESS_TERMSIG_OFF 1280
	#define FAKE_HOST_PREPARE_VM_ASPACE_OFF 0
#define FAKE_HOST_PREPARE_VM_TEXT_START_OFF 32
#define FAKE_HOST_PREPARE_VM_TEXT_END_OFF 40
#define FAKE_HOST_PREPARE_VM_DATA_START_OFF 48
#define FAKE_HOST_PREPARE_VM_DATA_END_OFF 56
#define FAKE_HOST_PREPARE_VM_BRK_START_OFF 64
#define FAKE_HOST_PREPARE_VM_BRK_END_OFF 72
#define FAKE_HOST_PREPARE_VM_BRK_ALLOC_OFF 80
#define FAKE_HOST_PREPARE_VM_MAP_START_OFF 88
#define FAKE_HOST_PREPARE_VM_MAP_END_OFF 96
	#define FAKE_HOST_PREPARE_VM_USER_START_OFF 120
	#define FAKE_HOST_PREPARE_VM_USER_END_OFF 128
	#define FAKE_HOST_PREPARE_VM_VDSO_ADDR_OFF 160
	#define FAKE_HOST_PREPARE_VM_NUMA_MASK_OFF 208
	#define FAKE_HOST_PREPARE_VM_NUMA_POLICY_OFF 240
#define FAKE_HOST_PREPARE_ASPACE_PIDS_OFF 168
static unsigned char fake_host_prepare_thread[FAKE_HOST_PREPARE_THREAD_SIZE]
	__attribute__((aligned(64)));
static unsigned char fake_host_prepare_process[FAKE_HOST_PREPARE_PROCESS_SIZE]
	__attribute__((aligned(64)));
static unsigned char fake_host_prepare_vm[FAKE_HOST_PREPARE_VM_SIZE]
	__attribute__((aligned(64)));
static unsigned char fake_host_prepare_aspace[FAKE_HOST_PREPARE_ASPACE_SIZE]
	__attribute__((aligned(8)));
static unsigned char fake_host_prepare_clone[
	sizeof(struct program_load_desc) + sizeof(struct program_image_section) * 4]
	__attribute__((aligned(8)));
static struct program_load_desc fake_host_prepare_desc;
struct fake_host_prepare_vm_range {
	unsigned char rb_node[24];
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	unsigned long straight_start;
	void *memobj;
	long objoff;
	int pgshift;
	int padding;
	void *private_data;
};
static unsigned char fake_host_prepare_sections_pn_storage[
	sizeof(struct program_load_desc) + sizeof(struct program_image_section) * 4]
	__attribute__((aligned(8)));
static unsigned char fake_host_prepare_sections_p_storage[
	sizeof(struct program_load_desc) + sizeof(struct program_image_section) * 4]
	__attribute__((aligned(8)));
static struct fake_host_prepare_vm_range fake_host_prepare_vm_ranges[8];
	static unsigned char fake_host_prepare_page_pool[8][PAGE_SIZE]
		__attribute__((aligned(64)));
	static unsigned char fake_host_prepare_args_remote_args[PAGE_SIZE]
		__attribute__((aligned(8)));
	static unsigned char fake_host_prepare_args_remote_envs[PAGE_SIZE]
		__attribute__((aligned(8)));
	static unsigned char fake_host_prepare_args_local_args[PAGE_SIZE]
		__attribute__((aligned(8)));
	static unsigned char fake_host_prepare_args_local_envs[PAGE_SIZE]
		__attribute__((aligned(8)));
	static char fake_host_prepare_args_old_cmdline[32];
	static int fake_host_prepare_add_range_calls;
static int fake_host_prepare_add_range_fail_call;
static int fake_host_prepare_add_range_rc;
static void *fake_host_prepare_add_range_last_vm;
static unsigned long fake_host_prepare_add_range_last_start;
static unsigned long fake_host_prepare_add_range_last_end;
static unsigned long fake_host_prepare_add_range_last_phys;
static unsigned long fake_host_prepare_add_range_last_flag;
static int fake_host_prepare_add_range_last_pgshift;
static int fake_host_prepare_alloc_pages_calls;
static int fake_host_prepare_alloc_pages_fail_call;
static int fake_host_prepare_alloc_pages_last_npages;
static unsigned long fake_host_prepare_alloc_pages_last_flags;
static unsigned long fake_host_prepare_alloc_pages_last_addr;
static int fake_host_prepare_free_pages_calls;
static void *fake_host_prepare_free_pages_last_addr;
static int fake_host_prepare_free_pages_last_npages;
static int fake_host_prepare_virt_to_phys_calls;
static void *fake_host_prepare_virt_to_phys_last_addr;
static int fake_host_prepare_ptattr_calls;
static unsigned long fake_host_prepare_ptattr_last_flag;
static unsigned long fake_host_prepare_ptattr_last_fault;
static int fake_host_prepare_pt_set_calls;
static int fake_host_prepare_pt_set_fail_call;
static int fake_host_prepare_pt_set_rc;
static void *fake_host_prepare_pt_set_last_pt;
static void *fake_host_prepare_pt_set_last_vm;
static unsigned long fake_host_prepare_pt_set_last_start;
static unsigned long fake_host_prepare_pt_set_last_end;
static unsigned long fake_host_prepare_pt_set_last_phys;
static unsigned long fake_host_prepare_pt_set_last_attr;
static int fake_host_prepare_pt_set_last_pgshift;
static void *fake_host_prepare_pt_set_last_range;
static int fake_host_prepare_modify_context_calls;
static void *fake_host_prepare_modify_context_last_uctx;
static int fake_host_prepare_modify_context_last_reg;
static unsigned long fake_host_prepare_modify_context_last_value;
static int fake_host_prepare_ranges_log_counts[32];
	static int fake_host_prepare_ranges_log_last_event;
	static unsigned long fake_host_prepare_ranges_log_arg0;
	static unsigned long fake_host_prepare_ranges_log_arg1;
	static unsigned long fake_host_prepare_ranges_log_arg2;
	static int fake_host_prepare_args_map_memory_calls;
	static unsigned long fake_host_prepare_args_map_memory_last_phys;
	static unsigned long fake_host_prepare_args_map_memory_last_size;
	static int fake_host_prepare_args_map_virtual_calls;
	static int fake_host_prepare_args_map_virtual_fail_call;
	static unsigned long fake_host_prepare_args_map_virtual_last_phys;
	static int fake_host_prepare_args_map_virtual_last_npages;
	static unsigned long fake_host_prepare_args_map_virtual_last_attr;
	static int fake_host_prepare_args_vdso_calls;
	static int fake_host_prepare_args_vdso_rc;
	static void *fake_host_prepare_args_vdso_last_vm;
	static int fake_host_prepare_args_init_calls;
	static int fake_host_prepare_args_init_rc;
	static void *fake_host_prepare_args_init_last_thread;
	static struct program_load_desc *fake_host_prepare_args_init_last_pn;
	static unsigned long fake_host_prepare_args_init_last_at_base;
	static int fake_host_prepare_args_init_last_argc;
	static int fake_host_prepare_args_init_last_envc;
	static unsigned long fake_host_prepare_args_init_last_argv0;
	static unsigned long fake_host_prepare_args_init_last_argv1;
	static unsigned long fake_host_prepare_args_init_last_env0;
	static int fake_host_prepare_args_log_counts[40];
	static int fake_host_prepare_args_log_last_event;
	static unsigned long fake_host_prepare_args_log_arg0;
	static unsigned long fake_host_prepare_args_log_arg1;
	static unsigned long fake_host_prepare_args_log_arg2;
struct fake_procfs_page {
	struct mckernel_procfs_buffer buffer;
	unsigned char data[8192];
};
struct fake_procfs_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	const char *path;
	int next;
};
static struct fake_procfs_page fake_procfs_pages[4];
static struct fake_procfs_range fake_procfs_ranges[5];
static int fake_procfs_buf_alloc_calls;
static int fake_procfs_buf_fail_alloc_call;
static int fake_procfs_buf_free_top_calls;
static int fake_procfs_buf_free_page_calls;
static int fake_procfs_buf_copy_calls;
static size_t fake_procfs_buf_copy_bytes;
static unsigned long fake_procfs_buf_free_mask;
static int fake_procfs_buf_page_alloc_calls;
static int fake_procfs_buf_fail_page_alloc_call;
static int fake_procfs_buf_page_alloc_last_npages;
static unsigned long fake_procfs_buf_page_alloc_last_flags;
static unsigned char fake_procfs_mem_space[12288];
static int fake_procfs_mem_page_fault_calls;
static int fake_procfs_mem_page_fault_fail_call;
static unsigned long fake_procfs_mem_page_fault_last_offset;
static unsigned long fake_procfs_mem_page_fault_last_reason;
static int fake_procfs_mem_vtop_calls;
static int fake_procfs_mem_vtop_fail_call;
static unsigned long fake_procfs_mem_vtop_last_offset;
static int fake_procfs_mem_is_memory_calls;
static int fake_procfs_mem_is_memory_fail_call;
static unsigned long fake_procfs_mem_is_memory_last_start;
static unsigned long fake_procfs_mem_is_memory_last_end;
static int fake_procfs_mem_phys_to_virt_calls;
static int fake_procfs_mem_copy_calls;
static size_t fake_procfs_mem_copy_bytes;
static int fake_procfs_pagemap_calls;
static unsigned long fake_procfs_pagemap_last_addr;
static struct ikc_scd_packet fake_procfs_backlog_packet_storage;
static int fake_procfs_backlog_alloc_calls;
static int fake_procfs_backlog_alloc_fail;
static unsigned long fake_procfs_backlog_alloc_last_size;
static unsigned long fake_procfs_backlog_alloc_last_flags;
static int fake_procfs_backlog_copy_calls;
static void *fake_procfs_backlog_copy_last_dst;
static struct ikc_scd_packet *fake_procfs_backlog_copy_last_src;
static unsigned long fake_procfs_backlog_copy_last_size;
static int fake_procfs_backlog_add_calls;
static int fake_procfs_backlog_add_rc;
static procfs_backlog_fn_t fake_procfs_backlog_add_last_fn;
static void *fake_procfs_backlog_add_last_arg;
static int fake_procfs_backlog_free_calls;
static void *fake_procfs_backlog_free_last_arg;

static void reset_fake_sysfs(void)
{
	fake_sysfs_send_error = 0;
	fake_sysfs_send_calls = 0;
	fake_sysfs_release_calls = 0;
	fake_sysfs_req_log_calls = 0;
	fake_sysfs_req_log_mask = 0;
	fake_sysfs_req_last_event = 0;
	fake_sysfs_req_last_nodeh = 0;
	fake_sysfs_req_last_ops = 0;
	fake_sysfs_req_last_instance = 0;
	fake_sysfs_req_last_size = 0;
	fake_sysfs_req_last_error = 0;
	fake_sysfs_req_last_packet_err = 0;
	fake_sysfs_req_last_ssize = 0;
	fake_sysfs_last_msg = 0;
	fake_sysfs_last_err = 0;
	fake_sysfs_last_arg1 = 0;
	fake_sysfs_last_arg2 = 0;
	fake_sysfs_packet_show_calls = 0;
	fake_sysfs_packet_store_calls = 0;
	fake_sysfs_packet_release_calls = 0;
	fake_sysfs_packet_unknown_calls = 0;
	fake_sysfs_packet_last_nodeh = 0;
	fake_sysfs_packet_last_ops = 0;
	fake_sysfs_packet_last_instance = 0;
	fake_sysfs_packet_last_size = 0;
	fake_sysfs_packet_last_msg = 0;
	fake_sysfs_packet_last_error = 0;
	fake_sysfs_packet_last_arg1 = 0;
	fake_sysfs_packet_last_arg2 = 0;
	fake_sysfs_packet_last_arg3 = 0;
	fake_sysfs_request_send_error = 0;
	fake_sysfs_request_send_calls = 0;
	fake_sysfs_request_last_msg = 0;
	fake_sysfs_request_last_arg1 = 0;
	fake_sysfs_request_pause_calls = 0;
	fake_sysfs_request_barrier_calls = 0;
	fake_sysfs_request_log_calls = 0;
	fake_sysfs_request_last_event = 0;
	fake_sysfs_request_log_last_msg = 0;
	fake_sysfs_request_log_last_error = 0;
	fake_sysfs_request_busy_ptr = NULL;
	fake_sysfs_init_alloc_calls = 0;
	fake_sysfs_init_free_calls = 0;
	fake_sysfs_init_fail_alloc_call = 0;
	memset(fake_sysfs_init_data_buf, 0, sizeof(fake_sysfs_init_data_buf));
	memset(&fake_sysfs_init_param, 0, sizeof(fake_sysfs_init_param));
	fake_sysfs_special_direct_ptr = NULL;
	fake_sysfs_special_string_ptr = NULL;
	fake_sysfs_special_bitmap_data_ptr = NULL;
	fake_sysfs_special_dest_ptr = NULL;
}

static void reset_fake_procfs_thread(int *donep, int send_rc)
{
	fake_procfs_thread_send_calls = 0;
	fake_procfs_thread_pause_calls = 0;
	fake_procfs_thread_send_rc = send_rc;
	fake_procfs_thread_last_channel = NULL;
	fake_procfs_thread_last_packet = NULL;
	fake_procfs_thread_done_ptr = donep;
}

static void reset_fake_procfs_answer(void)
{
	fake_procfs_answer_send_calls = 0;
	fake_procfs_answer_last_channel = NULL;
	fake_procfs_answer_last_msg = 0;
	fake_procfs_answer_last_err = 0;
	fake_procfs_answer_last_ref = 0;
	fake_procfs_answer_last_pid = 0;
	fake_procfs_answer_last_arg = 0;
	fake_procfs_answer_last_reply = NULL;
	fake_procfs_answer_last_req_valid = 0;
	fake_procfs_answer_last_resp_pa = 0;
	fake_procfs_answer_last_header_channel = NULL;
}

static void reset_fake_host_perf(void)
{
	fake_host_perf_init_calls = 0;
	fake_host_perf_stop_calls = 0;
	fake_host_perf_reset_calls = 0;
	fake_host_perf_start_calls = 0;
	fake_host_perf_read_calls = 0;
	fake_host_perf_unexpected_calls = 0;
	fake_host_perf_init_rc = 0;
	fake_host_perf_stop_rc = 0;
	fake_host_perf_reset_rc = 0;
	fake_host_perf_start_rc = 0;
	fake_host_perf_last_counter = 0;
	fake_host_perf_last_config = 0;
	fake_host_perf_last_mode = 0;
	fake_host_perf_last_mask = 0;
	fake_host_perf_last_flags = 0;
}

static void reset_fake_host_cpu_rw(void)
{
	fake_host_cpu_rw_calls = 0;
	fake_host_cpu_rw_rc = 0;
	fake_host_cpu_rw_last_desc = NULL;
	fake_host_cpu_rw_last_op = 0;
	memset(&fake_host_mapped_cpu_reg, 0, sizeof(fake_host_mapped_cpu_reg));
}

static void reset_fake_host_cleanup(void)
{
	fake_host_cleanup_process_calls = 0;
	fake_host_cleanup_process_rc = 0;
	fake_host_cleanup_process_last_pid = 0;
	fake_host_terminate_calls = 0;
	fake_host_terminate_last_pid = 0;
	fake_host_terminate_last_thread = NULL;
	fake_host_cleanup_process_log_calls = 0;
	fake_host_cleanup_process_log_last_pid = 0;
	fake_host_cleanup_process_log_last_thread = 0;
	fake_host_cleanup_fd_calls = 0;
	fake_host_cleanup_fd_rc = 0;
	fake_host_cleanup_fd_last_pid = 0;
	fake_host_cleanup_fd_last_fd = 0;
	fake_host_cleanup_fd_log_calls = 0;
	fake_host_cleanup_fd_log_last_pid = 0;
	fake_host_cleanup_fd_log_last_fd = 0;
	fake_host_cleanup_fd_log_last_err = 0;
	fake_host_cleanup_event_seq = 0;
	fake_host_cleanup_process_log_event = 0;
	fake_host_cleanup_process_event = 0;
	fake_host_cleanup_fd_event = 0;
	fake_host_cleanup_fd_log_event = 0;
	fake_host_reply_event = 0;
	fake_host_terminate_event = 0;
}

static void reset_fake_host_send_signal(void)
{
	fake_host_send_signal_kill_calls = 0;
	fake_host_send_signal_kill_last_pid = 0;
	fake_host_send_signal_kill_last_tid = 0;
	fake_host_send_signal_kill_last_sig = 0;
	fake_host_send_signal_info_matches = 0;
	fake_host_send_signal_rc = 0;
	fake_host_send_signal_log_calls = 0;
	fake_host_send_signal_log_last_pid = 0;
	fake_host_send_signal_log_last_tid = 0;
	fake_host_send_signal_log_last_sig = 0;
	fake_host_send_signal_log_last_rc = 0;
	fake_host_send_signal_event_seq = 0;
	fake_host_send_signal_track_events = 0;
	fake_host_send_signal_reply_event = 0;
	fake_host_send_signal_kill_event = 0;
	fake_host_send_signal_log_event = 0;
	memset(&fake_host_mapped_signal, 0, sizeof(fake_host_mapped_signal));
}

static void reset_fake_host_wake_syscall(void)
{
	fake_host_find_thread_calls = 0;
	fake_host_find_thread_last_pid = 0;
	fake_host_find_thread_last_tid = 0;
	fake_host_find_thread_missing = 0;
	fake_host_find_thread_storage = 0;
	fake_host_find_thread_result = NULL;
	fake_host_wakeup_thread_calls = 0;
	fake_host_wakeup_thread_last_thread = NULL;
	fake_host_unlock_thread_calls = 0;
	fake_host_unlock_thread_last_thread = NULL;
	fake_host_wake_log_calls = 0;
	fake_host_wake_log_last_tid = 0;
	fake_host_wake_log_last_found = 0;
	fake_host_wake_event_seq = 0;
	fake_host_wake_log_event = 0;
	fake_host_wake_event = 0;
	fake_host_unlock_event = 0;
}

static void reset_fake_host_debug_log(void)
{
	fake_host_debug_log_calls = 0;
	fake_host_debug_log_last_code = 0;
	fake_host_debug_print_calls = 0;
	fake_host_debug_print_last_code = 0;
	fake_host_debug_event_seq = 0;
	fake_host_debug_print_event = 0;
	fake_host_debug_log_event = 0;
}

static void reset_fake_host_schedule(void)
{
	memset(&fake_host_schedule_proc, 0, sizeof(fake_host_schedule_proc));
	memset(&fake_host_schedule_thread, 0, sizeof(fake_host_schedule_thread));
	fake_host_schedule_proc.pid = 4242;
	fake_host_schedule_proc.status = -1;
	fake_host_schedule_thread.proc = &fake_host_schedule_proc;
	fake_host_schedule_thread.tid = -1;
	fake_host_schedule_thread.status = -1;
	fake_host_schedule_thread.allowed_mask = 1UL << 3;
	fake_host_schedule_thread.pc = 0x12345000UL;
	fake_host_schedule_thread.sp = 0xabcdef00UL;
	fake_host_schedule_current_cpu = 3;
	fake_host_schedule_obtain_cpuid = 5;
	fake_host_schedule_proc_calls = 0;
	fake_host_schedule_current_cpu_calls = 0;
	fake_host_schedule_cpu_allowed_calls = 0;
	fake_host_schedule_obtain_calls = 0;
	fake_host_schedule_proc_pid_calls = 0;
	fake_host_schedule_pc_calls = 0;
	fake_host_schedule_sp_calls = 0;
	fake_host_schedule_invalid_log_calls = 0;
	fake_host_schedule_invalid_log_last_thread = NULL;
	fake_host_schedule_received_log_calls = 0;
	fake_host_schedule_received_last_thread = NULL;
	fake_host_schedule_received_last_pid = 0;
	fake_host_schedule_received_last_pc = 0;
	fake_host_schedule_received_last_sp = 0;
	fake_host_schedule_received_last_cpu = 0;
	fake_host_schedule_no_cpu_log_calls = 0;
	fake_host_schedule_set_tid_calls = 0;
	fake_host_schedule_set_tid_last_tid = 0;
	fake_host_schedule_set_proc_status_calls = 0;
	fake_host_schedule_set_thread_status_calls = 0;
	fake_host_schedule_chain_thread_calls = 0;
	fake_host_schedule_chain_process_calls = 0;
	fake_host_schedule_runq_add_calls = 0;
	fake_host_schedule_runq_last_thread = NULL;
	fake_host_schedule_runq_last_cpu = 0;
	fake_host_schedule_queued_log_calls = 0;
	fake_host_schedule_queued_last_pid = 0;
	fake_host_schedule_queued_last_tid = 0;
	fake_host_schedule_queued_last_cpu = 0;
	fake_host_schedule_queued_last_status = 0;
	fake_host_schedule_event_seq = 0;
	fake_host_schedule_set_tid_event = 0;
	fake_host_schedule_set_proc_status_event = 0;
	fake_host_schedule_set_thread_status_event = 0;
	fake_host_schedule_chain_thread_event = 0;
	fake_host_schedule_chain_process_event = 0;
	fake_host_schedule_runq_event = 0;
	fake_host_schedule_queued_log_event = 0;
}

static void reset_fake_host_remote_page_fault(void)
{
	fake_host_rpf_profile_enabled_calls = 0;
	fake_host_rpf_profile_enabled_result = 1;
	fake_host_rpf_profile_last_thread = NULL;
	fake_host_rpf_timestamp_calls = 0;
	fake_host_rpf_preempt_disable_calls = 0;
	fake_host_rpf_preempt_enable_calls = 0;
	fake_host_rpf_page_fault_calls = 0;
	fake_host_rpf_page_fault_last_thread = NULL;
	fake_host_rpf_page_fault_last_addr = 0;
	fake_host_rpf_page_fault_last_reason = 0;
	fake_host_rpf_profile_event_calls = 0;
	fake_host_rpf_profile_event_last_event = 0;
	fake_host_rpf_profile_event_last_delta = 0;
	fake_host_rpf_log_calls = 0;
	fake_host_rpf_log_last_thread = NULL;
	fake_host_rpf_log_last_addr = 0;
	fake_host_rpf_log_last_reason = 0;
	fake_host_rpf_event_seq = 0;
	fake_host_rpf_log_event = 0;
	fake_host_rpf_preempt_disable_event = 0;
	fake_host_rpf_page_fault_event = 0;
	fake_host_rpf_preempt_enable_event = 0;
	fake_host_rpf_profile_event_event = 0;
	fake_host_rpf_answer_event = 0;
}

static void reset_fake_host_remote_page_fault_request(void)
{
	fake_host_rpf_request_body_calls = 0;
	fake_host_rpf_request_body_last_err = 0;
	fake_host_rpf_request_body_last_ref = 0;
	fake_host_rpf_request_body_last_tid = 0;
	fake_host_rpf_request_body_last_addr = 0;
	fake_host_rpf_request_body_last_reason = 0;
	fake_host_rpf_request_alloc_calls = 0;
	fake_host_rpf_request_alloc_last_size = 0;
	fake_host_rpf_request_alloc_last_flags = 0;
	fake_host_rpf_request_alloc_fail = 0;
	fake_host_rpf_request_copy_calls = 0;
	fake_host_rpf_request_copy_last_dst = NULL;
	fake_host_rpf_request_copy_last_src = NULL;
	fake_host_rpf_request_copy_last_size = 0;
	fake_host_rpf_request_defer_calls = 0;
	fake_host_rpf_request_defer_last_thread = NULL;
	fake_host_rpf_request_defer_last_arg = NULL;
	fake_host_rpf_request_defer_last_backlog = NULL;
	fake_host_rpf_request_wakeup_calls = 0;
	fake_host_rpf_request_wakeup_last_thread = NULL;
	fake_host_rpf_request_wakeup_last_state = 0;
	fake_host_rpf_request_unlock_calls = 0;
	fake_host_rpf_request_unlock_last_thread = NULL;
	fake_host_rpf_request_missing_log_calls = 0;
	fake_host_rpf_request_missing_log_last_tid = 0;
	fake_host_rpf_request_event_seq = 0;
	fake_host_rpf_request_body_event = 0;
	fake_host_rpf_request_copy_event = 0;
	fake_host_rpf_request_defer_event = 0;
	fake_host_rpf_request_wakeup_event = 0;
	fake_host_rpf_request_unlock_event = 0;
	fake_host_rpf_request_missing_log_event = 0;
	memset(&fake_host_rpf_request_copy_packet, 0,
	       sizeof(fake_host_rpf_request_copy_packet));
}

static void reset_fake_host_mapping(void)
{
	fake_host_map_memory_calls = 0;
	fake_host_map_virtual_calls = 0;
	fake_host_unmap_virtual_calls = 0;
	fake_host_unmap_memory_calls = 0;
	fake_host_map_virtual_fail = 0;
	fake_host_map_memory_result = 0xfeedc000UL;
	fake_host_map_last_in_phys = 0;
	fake_host_map_last_size = 0;
	fake_host_map_virtual_last_phys = 0;
	fake_host_map_virtual_last_npages = 0;
	fake_host_map_virtual_last_attr = 0;
	fake_host_unmap_virtual_last_addr = NULL;
	fake_host_unmap_virtual_last_npages = 0;
	fake_host_unmap_memory_last_phys = 0;
	fake_host_unmap_memory_last_size = 0;
	fake_host_map_virtual_result = &fake_host_mapped_perf_desc;
	memset(&fake_host_mapped_perf_desc, 0, sizeof(fake_host_mapped_perf_desc));
	memset(&fake_host_mapped_signal, 0, sizeof(fake_host_mapped_signal));
}

static void reset_fake_host_dispatch(void)
{
	fake_host_dispatch_init_ack_log_calls = 0;
	fake_host_dispatch_prepare_calls = 0;
	fake_host_dispatch_prepare_last_arg = 0;
	fake_host_dispatch_prepare_rc = 0;
	fake_host_dispatch_schedule_log_calls = 0;
	fake_host_dispatch_schedule_last_arg = 0;
	fake_host_dispatch_procfs_calls = 0;
	fake_host_dispatch_procfs_last_msg = 0;
	fake_host_dispatch_procfs_rc = 0;
	fake_host_dispatch_procfs_last_packet = NULL;
	fake_host_dispatch_sysfs_calls = 0;
	fake_host_dispatch_sysfs_last_channel = NULL;
	fake_host_dispatch_sysfs_last_msg = 0;
	fake_host_dispatch_sysfs_last_err = 0;
	fake_host_dispatch_sysfs_last_arg1 = 0;
	fake_host_dispatch_sysfs_last_arg2 = 0;
	fake_host_dispatch_sysfs_last_arg3 = 0;
	fake_host_dispatch_unknown_calls = 0;
	fake_host_dispatch_unknown_last_msg = 0;
	fake_host_dispatch_unknown_last_ref = 0;
	fake_host_dispatch_release_calls = 0;
	fake_host_dispatch_release_last_packet = NULL;
	fake_host_handler_response_calls = 0;
	fake_host_handler_current_calls = 0;
}

static unsigned long fake_procfs_buf_phys(struct mckernel_procfs_buffer *pbuf)
{
	for (unsigned int i = 0;
	     i < sizeof(fake_procfs_pages) / sizeof(fake_procfs_pages[0]); i++) {
		if (pbuf == &fake_procfs_pages[i].buffer)
			return 0x70000000UL + (i * 0x1000UL);
	}
	return ~0UL;
}

static int fake_procfs_buf_index(struct mckernel_procfs_buffer *pbuf)
{
	for (unsigned int i = 0;
	     i < sizeof(fake_procfs_pages) / sizeof(fake_procfs_pages[0]); i++) {
		if (pbuf == &fake_procfs_pages[i].buffer)
			return (int)i;
	}
	return -1;
}

static void reset_fake_procfs_buf(void)
{
	memset(fake_procfs_pages, 0, sizeof(fake_procfs_pages));
	fake_procfs_buf_alloc_calls = 0;
	fake_procfs_buf_fail_alloc_call = 0;
	fake_procfs_buf_free_top_calls = 0;
	fake_procfs_buf_free_page_calls = 0;
	fake_procfs_buf_copy_calls = 0;
	fake_procfs_buf_copy_bytes = 0;
	fake_procfs_buf_free_mask = 0;
	fake_procfs_buf_page_alloc_calls = 0;
	fake_procfs_buf_fail_page_alloc_call = 0;
	fake_procfs_buf_page_alloc_last_npages = 0;
	fake_procfs_buf_page_alloc_last_flags = 0;
	for (unsigned int i = 0;
	     i < sizeof(fake_procfs_pages) / sizeof(fake_procfs_pages[0]); i++)
		fake_procfs_pages[i].buffer.next_pa = ~0UL;
}

static void reset_fake_procfs_mem(void)
{
	memset(fake_procfs_mem_space, 0, sizeof(fake_procfs_mem_space));
	fake_procfs_mem_page_fault_calls = 0;
	fake_procfs_mem_page_fault_fail_call = 0;
	fake_procfs_mem_page_fault_last_offset = 0;
	fake_procfs_mem_page_fault_last_reason = 0;
	fake_procfs_mem_vtop_calls = 0;
	fake_procfs_mem_vtop_fail_call = 0;
	fake_procfs_mem_vtop_last_offset = 0;
	fake_procfs_mem_is_memory_calls = 0;
	fake_procfs_mem_is_memory_fail_call = 0;
	fake_procfs_mem_is_memory_last_start = 0;
	fake_procfs_mem_is_memory_last_end = 0;
	fake_procfs_mem_phys_to_virt_calls = 0;
	fake_procfs_mem_copy_calls = 0;
	fake_procfs_mem_copy_bytes = 0;
	fake_procfs_pagemap_calls = 0;
	fake_procfs_pagemap_last_addr = 0;
}

static void reset_fake_procfs_backlog(void)
{
	memset(&fake_procfs_backlog_packet_storage, 0,
	       sizeof(fake_procfs_backlog_packet_storage));
	fake_procfs_backlog_alloc_calls = 0;
	fake_procfs_backlog_alloc_fail = 0;
	fake_procfs_backlog_alloc_last_size = 0;
	fake_procfs_backlog_alloc_last_flags = 0;
	fake_procfs_backlog_copy_calls = 0;
	fake_procfs_backlog_copy_last_dst = NULL;
	fake_procfs_backlog_copy_last_src = NULL;
	fake_procfs_backlog_copy_last_size = 0;
	fake_procfs_backlog_add_calls = 0;
	fake_procfs_backlog_add_rc = 0;
	fake_procfs_backlog_add_last_fn = NULL;
	fake_procfs_backlog_add_last_arg = NULL;
	fake_procfs_backlog_free_calls = 0;
	fake_procfs_backlog_free_last_arg = NULL;
}

static struct mckernel_procfs_buffer *
fake_procfs_buf_alloc(unsigned long *phys, long pos)
{
	struct mckernel_procfs_buffer *pbuf;
	int index;

	fake_procfs_buf_alloc_calls++;
	if (fake_procfs_buf_fail_alloc_call == fake_procfs_buf_alloc_calls)
		return NULL;
	index = fake_procfs_buf_alloc_calls - 1;
	if (index < 0 ||
	    index >= (int)(sizeof(fake_procfs_pages) /
		    sizeof(fake_procfs_pages[0])))
		return NULL;

	pbuf = &fake_procfs_pages[index].buffer;
	pbuf->next_pa = ~0UL;
	pbuf->pos = (unsigned long)pos;
	pbuf->size = 0;
	if (phys)
		*phys = fake_procfs_buf_phys(pbuf);
	return pbuf;
}

static struct mckernel_procfs_buffer *
fake_procfs_buf_phys_to_virt(unsigned long phys)
{
	for (unsigned int i = 0;
	     i < sizeof(fake_procfs_pages) / sizeof(fake_procfs_pages[0]); i++) {
		if (phys == fake_procfs_buf_phys(&fake_procfs_pages[i].buffer))
			return &fake_procfs_pages[i].buffer;
	}
	return NULL;
}

static void fake_procfs_buf_free_page(struct mckernel_procfs_buffer *pbuf)
{
	int index = fake_procfs_buf_index(pbuf);

	fake_procfs_buf_free_page_calls++;
	if (index >= 0)
		fake_procfs_buf_free_mask |= 1UL << index;
}

static void fake_procfs_buf_free_top(struct mckernel_procfs_buffer *top)
{
	fake_procfs_buf_free_top_calls++;
	procfs_buf_release_result(fake_procfs_buf_phys(top),
		fake_procfs_buf_phys_to_virt, fake_procfs_buf_free_page);
}

static void *fake_procfs_buf_copy(void *dst, const void *src, size_t len)
{
	fake_procfs_buf_copy_calls++;
	fake_procfs_buf_copy_bytes += len;
	return memcpy(dst, src, len);
}

static void *fake_procfs_buf_page_alloc(int npages, unsigned long flags)
{
	int index;

	fake_procfs_buf_page_alloc_calls++;
	fake_procfs_buf_page_alloc_last_npages = npages;
	fake_procfs_buf_page_alloc_last_flags = flags;
	if (fake_procfs_buf_fail_page_alloc_call ==
			fake_procfs_buf_page_alloc_calls)
		return NULL;
	index = fake_procfs_buf_page_alloc_calls - 1;
	if (index < 0 ||
	    index >= (int)(sizeof(fake_procfs_pages) /
		    sizeof(fake_procfs_pages[0])))
		return NULL;
	return &fake_procfs_pages[index].buffer;
}

#define FAKE_PROCFS_MEM_BASE 0x81000000UL

static int fake_procfs_mem_page_fault(void *vm, unsigned long offset,
				      unsigned long reason)
{
	fake_procfs_mem_page_fault_calls++;
	fake_procfs_mem_page_fault_last_offset = offset;
	fake_procfs_mem_page_fault_last_reason = reason;
	mix((unsigned long *)vm, offset ^ reason);
	return fake_procfs_mem_page_fault_fail_call ==
		fake_procfs_mem_page_fault_calls ? -5 : 0;
}

static int fake_procfs_mem_virt_to_phys(void *page_table, unsigned long offset,
					unsigned long *physp)
{
	fake_procfs_mem_vtop_calls++;
	fake_procfs_mem_vtop_last_offset = offset;
	mix((unsigned long *)page_table, offset);
	if (fake_procfs_mem_vtop_fail_call == fake_procfs_mem_vtop_calls)
		return -7;
	*physp = FAKE_PROCFS_MEM_BASE + offset;
	return 0;
}

static int fake_procfs_mem_is_memory(unsigned long start, unsigned long end)
{
	fake_procfs_mem_is_memory_calls++;
	fake_procfs_mem_is_memory_last_start = start;
	fake_procfs_mem_is_memory_last_end = end;
	if (fake_procfs_mem_is_memory_fail_call ==
			fake_procfs_mem_is_memory_calls)
		return 0;
	return start >= FAKE_PROCFS_MEM_BASE &&
		end <= FAKE_PROCFS_MEM_BASE + sizeof(fake_procfs_mem_space);
}

static void *fake_procfs_mem_phys_to_virt(unsigned long phys)
{
	fake_procfs_mem_phys_to_virt_calls++;
	return &fake_procfs_mem_space[phys - FAKE_PROCFS_MEM_BASE];
}

static void *fake_procfs_mem_copy(void *dst, const void *src, size_t len)
{
	fake_procfs_mem_copy_calls++;
	fake_procfs_mem_copy_bytes += len;
	return memcpy(dst, src, len);
}

static unsigned long fake_procfs_pagemap_value(void *page_table,
					       unsigned long addr)
{
	fake_procfs_pagemap_calls++;
	fake_procfs_pagemap_last_addr = addr;
	mix((unsigned long *)page_table, addr);
	return addr ^ 0xabcddcbaUL;
}

static unsigned long fake_procfs_range_ulong(void *range, int field)
{
	struct fake_procfs_range *r = range;

	if (!r)
		return 0;
	switch (field) {
	case PROCFS_RANGE_FIELD_START:
		return r->start;
	case PROCFS_RANGE_FIELD_END:
		return r->end;
	case PROCFS_RANGE_FIELD_FLAG:
		return r->flag;
	default:
		return 0;
	}
}

static const char *fake_procfs_range_path(void *range)
{
	struct fake_procfs_range *r = range;

	return r ? r->path : NULL;
}

static void *fake_procfs_range_next(void *vm, void *range)
{
	struct fake_procfs_range *base = vm;
	struct fake_procfs_range *r = range;

	if (!base || !r || r->next < 0)
		return NULL;
	return &base[r->next];
}

static int fake_procfs_backlog_func(void *arg)
{
	(void)arg;
	return 0;
}

static void *fake_procfs_backlog_alloc(unsigned long size,
				       unsigned long flags)
{
	fake_procfs_backlog_alloc_calls++;
	fake_procfs_backlog_alloc_last_size = size;
	fake_procfs_backlog_alloc_last_flags = flags;
	if (fake_procfs_backlog_alloc_fail)
		return NULL;
	return &fake_procfs_backlog_packet_storage;
}

static void fake_procfs_backlog_copy(void *dst, struct ikc_scd_packet *src,
				     unsigned long size)
{
	fake_procfs_backlog_copy_calls++;
	fake_procfs_backlog_copy_last_dst = dst;
	fake_procfs_backlog_copy_last_src = src;
	fake_procfs_backlog_copy_last_size = size;
	memcpy(dst, src, size);
}

static int fake_procfs_backlog_add(procfs_backlog_fn_t backlog_fn, void *arg)
{
	fake_procfs_backlog_add_calls++;
	fake_procfs_backlog_add_last_fn = backlog_fn;
	fake_procfs_backlog_add_last_arg = arg;
	return fake_procfs_backlog_add_rc;
}

static void fake_procfs_backlog_free(void *arg)
{
	fake_procfs_backlog_free_calls++;
	fake_procfs_backlog_free_last_arg = arg;
}

static int fake_sysfs_send(int msg, int err, long arg1, long arg2)
{
	fake_sysfs_send_calls++;
	fake_sysfs_last_msg = msg;
	fake_sysfs_last_err = err;
	fake_sysfs_last_arg1 = arg1;
	fake_sysfs_last_arg2 = arg2;
	return fake_sysfs_send_error;
}

static void fake_sysfs_req_log(int event, long nodeh, void *ops,
			       void *instance, size_t size, int error,
			       int packet_err, ssize_t ssize)
{
	fake_sysfs_req_log_calls++;
	fake_sysfs_req_log_mask |= 1 << event;
	fake_sysfs_req_last_event = event;
	fake_sysfs_req_last_nodeh = nodeh;
	fake_sysfs_req_last_ops = (long)ops;
	fake_sysfs_req_last_instance = (long)instance;
	fake_sysfs_req_last_size = size;
	fake_sysfs_req_last_error = error;
	fake_sysfs_req_last_packet_err = packet_err;
	fake_sysfs_req_last_ssize = ssize;
}

static int fake_sysfs_request_send(int msg, long arg1)
{
	fake_sysfs_request_send_calls++;
	fake_sysfs_request_last_msg = msg;
	fake_sysfs_request_last_arg1 = arg1;
	return fake_sysfs_request_send_error;
}

static void fake_sysfs_request_pause(void)
{
	fake_sysfs_request_pause_calls++;
	if (fake_sysfs_request_busy_ptr &&
	    fake_sysfs_request_pause_calls >= 2) {
		*fake_sysfs_request_busy_ptr = 0;
	}
}

static void fake_sysfs_request_barrier(void)
{
	fake_sysfs_request_barrier_calls++;
}

static void fake_sysfs_request_log(int event, int msg, int error)
{
	fake_sysfs_request_log_calls++;
	fake_sysfs_request_last_event = event;
	fake_sysfs_request_log_last_msg = msg;
	fake_sysfs_request_log_last_error = error;
}

static void *fake_sysfs_init_alloc(int npages, unsigned long flags)
{
	(void)npages;
	(void)flags;
	fake_sysfs_init_alloc_calls++;
	if (fake_sysfs_init_fail_alloc_call == fake_sysfs_init_alloc_calls)
		return NULL;
	if (fake_sysfs_init_alloc_calls == 1)
		return fake_sysfs_init_data_buf;
	if (fake_sysfs_init_alloc_calls == 2)
		return &fake_sysfs_init_param;
	return NULL;
}

static void fake_sysfs_init_free(void *addr, int npages)
{
	(void)addr;
	(void)npages;
	fake_sysfs_init_free_calls++;
}

static long fake_sysfs_init_phys(void *addr)
{
	if (addr == fake_sysfs_init_data_buf)
		return 0x810000;
	if (addr == &fake_sysfs_init_param)
		return 0x820000;
	return 0;
}

static long fake_sysfs_special_phys(void *addr)
{
	if (addr == fake_sysfs_special_direct_ptr)
		return 0x910000;
	if (addr == fake_sysfs_special_string_ptr)
		return 0x920000;
	if (addr == fake_sysfs_special_bitmap_data_ptr)
		return 0x930000;
	if (addr == fake_sysfs_special_dest_ptr)
		return 0x940000;
	return -1;
}

static unsigned long fake_procfs_thread_phys(void *addr)
{
	if (addr == fake_procfs_thread_done_ptr)
		return 0x55550000UL;
	return 0;
}

static int fake_procfs_thread_send(void *channel, struct ikc_scd_packet *packet)
{
	fake_procfs_thread_send_calls++;
	fake_procfs_thread_last_channel = channel;
	fake_procfs_thread_last_packet = packet;
	return fake_procfs_thread_send_rc;
}

static void fake_procfs_answer_send(void *channel, struct ikc_scd_packet *packet)
{
	fake_procfs_answer_send_calls++;
	if (fake_host_cleanup_event_seq)
		fake_host_reply_event = ++fake_host_cleanup_event_seq;
	if (fake_host_send_signal_track_events)
		fake_host_send_signal_reply_event =
			++fake_host_send_signal_event_seq;
	if (fake_host_rpf_event_seq)
		fake_host_rpf_answer_event = ++fake_host_rpf_event_seq;
	fake_procfs_answer_last_channel = channel;
	fake_procfs_answer_last_header_channel = packet->header.channel;
	fake_procfs_answer_last_msg = packet->msg;
	fake_procfs_answer_last_err = packet->err;
	fake_procfs_answer_last_ref = packet->ref;
	fake_procfs_answer_last_pid = packet->pid;
	fake_procfs_answer_last_arg = packet->arg;
	fake_procfs_answer_last_reply = packet->reply;
	fake_procfs_answer_last_req_valid = packet->req.valid;
	fake_procfs_answer_last_resp_pa = packet->resp_pa;
}

static int fake_host_perf_init_raw(int counter, unsigned int config, int mode)
{
	fake_host_perf_init_calls++;
	fake_host_perf_last_counter = counter;
	fake_host_perf_last_config = config;
	fake_host_perf_last_mode = mode;
	return fake_host_perf_init_rc;
}

static int fake_host_perf_stop(unsigned long mask, int flags)
{
	fake_host_perf_stop_calls++;
	fake_host_perf_last_mask = mask;
	fake_host_perf_last_flags = flags;
	return fake_host_perf_stop_rc;
}

static int fake_host_perf_reset(int counter)
{
	fake_host_perf_reset_calls++;
	fake_host_perf_last_counter = counter;
	return fake_host_perf_reset_rc;
}

static int fake_host_perf_start(unsigned long mask)
{
	fake_host_perf_start_calls++;
	fake_host_perf_last_mask = mask;
	return fake_host_perf_start_rc;
}

static unsigned long fake_host_perf_read(int counter)
{
	fake_host_perf_read_calls++;
	fake_host_perf_last_counter = counter;
	return 0xabcdef0123456789UL;
}

static void fake_host_perf_unexpected(void)
{
	fake_host_perf_unexpected_calls++;
}

static int fake_host_cpu_rw_register(void *desc, int op)
{
	struct ihk_os_cpu_register *reg = desc;

	fake_host_cpu_rw_calls++;
	fake_host_cpu_rw_last_desc = desc;
	fake_host_cpu_rw_last_op = op;
	if (reg)
		reg->val ^= 0x55aa55aa55aa55aaUL;
	return fake_host_cpu_rw_rc;
}

static int fake_host_cleanup_process(int pid)
{
	fake_host_cleanup_process_calls++;
	fake_host_cleanup_process_event = ++fake_host_cleanup_event_seq;
	fake_host_cleanup_process_last_pid = pid;
	return fake_host_cleanup_process_rc;
}

static void fake_host_terminate(int pid, void *thread)
{
	fake_host_terminate_calls++;
	fake_host_terminate_event = ++fake_host_cleanup_event_seq;
	fake_host_terminate_last_pid = pid;
	fake_host_terminate_last_thread = thread;
}

static void fake_host_cleanup_process_log(int pid, unsigned long thread_arg)
{
	fake_host_cleanup_process_log_calls++;
	fake_host_cleanup_process_log_event = ++fake_host_cleanup_event_seq;
	fake_host_cleanup_process_log_last_pid = pid;
	fake_host_cleanup_process_log_last_thread = thread_arg;
}

static int fake_host_cleanup_fd(int pid, int fd)
{
	fake_host_cleanup_fd_calls++;
	fake_host_cleanup_fd_event = ++fake_host_cleanup_event_seq;
	fake_host_cleanup_fd_last_pid = pid;
	fake_host_cleanup_fd_last_fd = fd;
	return fake_host_cleanup_fd_rc;
}

static void fake_host_cleanup_fd_log(int pid, unsigned long fd, int err)
{
	fake_host_cleanup_fd_log_calls++;
	fake_host_cleanup_fd_log_event = ++fake_host_cleanup_event_seq;
	fake_host_cleanup_fd_log_last_pid = pid;
	fake_host_cleanup_fd_log_last_fd = fd;
	fake_host_cleanup_fd_log_last_err = err;
}

static unsigned long fake_host_do_kill(int pid, int tid, int sig, void *info)
{
	fake_host_send_signal_kill_calls++;
	fake_host_send_signal_kill_event =
		++fake_host_send_signal_event_seq;
	fake_host_send_signal_kill_last_pid = pid;
	fake_host_send_signal_kill_last_tid = tid;
	fake_host_send_signal_kill_last_sig = sig;
	fake_host_send_signal_info_matches =
		!memcmp(info, fake_host_mapped_signal.info,
			sizeof(fake_host_mapped_signal.info));
	return (unsigned long)fake_host_send_signal_rc;
}

static void fake_host_send_signal_log(int pid, int tid, int sig, int rc)
{
	fake_host_send_signal_log_calls++;
	fake_host_send_signal_log_event = ++fake_host_send_signal_event_seq;
	fake_host_send_signal_log_last_pid = pid;
	fake_host_send_signal_log_last_tid = tid;
	fake_host_send_signal_log_last_sig = sig;
	fake_host_send_signal_log_last_rc = rc;
}

static void *fake_host_find_thread(int pid, int tid)
{
	fake_host_find_thread_calls++;
	fake_host_find_thread_last_pid = pid;
	fake_host_find_thread_last_tid = tid;
	if (fake_host_find_thread_missing)
		return NULL;
	if (fake_host_find_thread_result)
		return fake_host_find_thread_result;
	return &fake_host_find_thread_storage;
}

static void fake_host_wakeup_thread(void *thread)
{
	fake_host_wakeup_thread_calls++;
	fake_host_wake_event = ++fake_host_wake_event_seq;
	fake_host_wakeup_thread_last_thread = thread;
}

static void fake_host_unlock_thread(void *thread)
{
	fake_host_unlock_thread_calls++;
	fake_host_unlock_event = ++fake_host_wake_event_seq;
	fake_host_unlock_thread_last_thread = thread;
}

static void fake_host_wake_syscall_log(int tid, int found)
{
	fake_host_wake_log_calls++;
	fake_host_wake_log_event = ++fake_host_wake_event_seq;
	fake_host_wake_log_last_tid = tid;
	fake_host_wake_log_last_found = found;
}

static void fake_host_debug_log(unsigned long code)
{
	fake_host_debug_log_calls++;
	fake_host_debug_log_event = ++fake_host_debug_event_seq;
	fake_host_debug_log_last_code = code;
}

static void fake_host_debug_print(unsigned long code)
{
	fake_host_debug_print_calls++;
	fake_host_debug_print_event = ++fake_host_debug_event_seq;
	fake_host_debug_print_last_code = code;
}

static void *fake_host_schedule_get_proc(void *thread)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_proc_calls++;
	return t ? t->proc : NULL;
}

static int fake_host_schedule_get_current_cpu(void)
{
	fake_host_schedule_current_cpu_calls++;
	return fake_host_schedule_current_cpu;
}

static int fake_host_schedule_cpu_allowed(void *thread, int cpuid)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_cpu_allowed_calls++;
	return t && cpuid >= 0 &&
		(t->allowed_mask & (1UL << (unsigned int)cpuid));
}

static int fake_host_schedule_obtain_cpu(void *thread)
{
	(void)thread;
	fake_host_schedule_obtain_calls++;
	return fake_host_schedule_obtain_cpuid;
}

static int fake_host_schedule_proc_pid(void *proc)
{
	struct fake_host_schedule_proc *p = proc;

	fake_host_schedule_proc_pid_calls++;
	return p ? p->pid : -1;
}

static unsigned long fake_host_schedule_pc(void *thread)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_pc_calls++;
	return t ? t->pc : 0;
}

static unsigned long fake_host_schedule_sp(void *thread)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_sp_calls++;
	return t ? t->sp : 0;
}

static void fake_host_schedule_invalid_log(void *thread)
{
	fake_host_schedule_invalid_log_calls++;
	fake_host_schedule_invalid_log_last_thread = thread;
}

static void fake_host_schedule_received_log(void *thread, int pid,
					    unsigned long pc,
					    unsigned long sp, int cpuid)
{
	fake_host_schedule_received_log_calls++;
	fake_host_schedule_received_last_thread = thread;
	fake_host_schedule_received_last_pid = pid;
	fake_host_schedule_received_last_pc = pc;
	fake_host_schedule_received_last_sp = sp;
	fake_host_schedule_received_last_cpu = cpuid;
}

static void fake_host_schedule_no_cpu_log(void)
{
	fake_host_schedule_no_cpu_log_calls++;
}

static void fake_host_schedule_set_tid(void *thread, int tid)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_set_tid_calls++;
	fake_host_schedule_set_tid_event = ++fake_host_schedule_event_seq;
	fake_host_schedule_set_tid_last_tid = tid;
	t->tid = tid;
}

static void fake_host_schedule_set_proc_status(void *proc, int status)
{
	struct fake_host_schedule_proc *p = proc;

	fake_host_schedule_set_proc_status_calls++;
	fake_host_schedule_set_proc_status_event =
		++fake_host_schedule_event_seq;
	p->status = status;
}

static void fake_host_schedule_set_thread_status(void *thread, int status)
{
	struct fake_host_schedule_thread *t = thread;

	fake_host_schedule_set_thread_status_calls++;
	fake_host_schedule_set_thread_status_event =
		++fake_host_schedule_event_seq;
	t->status = status;
}

static void fake_host_schedule_chain_thread(void *thread)
{
	(void)thread;
	fake_host_schedule_chain_thread_calls++;
	fake_host_schedule_chain_thread_event =
		++fake_host_schedule_event_seq;
}

static void fake_host_schedule_chain_process(void *proc)
{
	(void)proc;
	fake_host_schedule_chain_process_calls++;
	fake_host_schedule_chain_process_event =
		++fake_host_schedule_event_seq;
}

static void fake_host_schedule_runq_add(void *thread, int cpuid)
{
	fake_host_schedule_runq_add_calls++;
	fake_host_schedule_runq_event = ++fake_host_schedule_event_seq;
	fake_host_schedule_runq_last_thread = thread;
	fake_host_schedule_runq_last_cpu = cpuid;
}

static void fake_host_schedule_queued_log(int pid, int tid, int cpuid,
					  int status)
{
	fake_host_schedule_queued_log_calls++;
	fake_host_schedule_queued_log_event = ++fake_host_schedule_event_seq;
	fake_host_schedule_queued_last_pid = pid;
	fake_host_schedule_queued_last_tid = tid;
	fake_host_schedule_queued_last_cpu = cpuid;
	fake_host_schedule_queued_last_status = status;
}

static int fake_host_rpf_profile_enabled(void *thread)
{
	fake_host_rpf_profile_enabled_calls++;
	fake_host_rpf_profile_last_thread = thread;
	return fake_host_rpf_profile_enabled_result;
}

static unsigned long fake_host_rpf_timestamp(void)
{
	fake_host_rpf_timestamp_calls++;
	if (fake_host_rpf_timestamp_calls == 1)
		return 1000;
	return 1234;
}

static void fake_host_rpf_preempt_disable(void)
{
	fake_host_rpf_preempt_disable_calls++;
	fake_host_rpf_preempt_disable_event = ++fake_host_rpf_event_seq;
}

static void fake_host_rpf_preempt_enable(void)
{
	fake_host_rpf_preempt_enable_calls++;
	fake_host_rpf_preempt_enable_event = ++fake_host_rpf_event_seq;
}

static void fake_host_rpf_page_fault(void *thread, unsigned long addr,
				     unsigned long reason)
{
	fake_host_rpf_page_fault_calls++;
	fake_host_rpf_page_fault_event = ++fake_host_rpf_event_seq;
	fake_host_rpf_page_fault_last_thread = thread;
	fake_host_rpf_page_fault_last_addr = addr;
	fake_host_rpf_page_fault_last_reason = reason;
}

static void fake_host_rpf_profile_event(int event, unsigned long delta)
{
	fake_host_rpf_profile_event_calls++;
	fake_host_rpf_profile_event_event = ++fake_host_rpf_event_seq;
	fake_host_rpf_profile_event_last_event = event;
	fake_host_rpf_profile_event_last_delta = delta;
}

static void fake_host_rpf_log(void *thread, unsigned long addr,
			      unsigned long reason)
{
	fake_host_rpf_log_calls++;
	fake_host_rpf_log_event = ++fake_host_rpf_event_seq;
	fake_host_rpf_log_last_thread = thread;
	fake_host_rpf_log_last_addr = addr;
	fake_host_rpf_log_last_reason = reason;
}

static void fake_host_rpf_request_body(struct ikc_scd_packet *packet, int err)
{
	fake_host_rpf_request_body_calls++;
	fake_host_rpf_request_body_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_body_last_err = err;
	if (packet) {
		fake_host_rpf_request_body_last_ref = packet->ref;
		fake_host_rpf_request_body_last_tid = packet->fault_tid;
		fake_host_rpf_request_body_last_addr =
			packet->fault_address;
		fake_host_rpf_request_body_last_reason =
			packet->fault_reason;
	}
}

static void *fake_host_rpf_request_alloc(unsigned long size,
					 unsigned long flags)
{
	fake_host_rpf_request_alloc_calls++;
	fake_host_rpf_request_alloc_last_size = size;
	fake_host_rpf_request_alloc_last_flags = flags;
	if (fake_host_rpf_request_alloc_fail)
		return NULL;
	return &fake_host_rpf_request_copy_packet;
}

static void fake_host_rpf_request_copy(void *dst, struct ikc_scd_packet *src,
				       unsigned long size)
{
	fake_host_rpf_request_copy_calls++;
	fake_host_rpf_request_copy_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_copy_last_dst = dst;
	fake_host_rpf_request_copy_last_src = src;
	fake_host_rpf_request_copy_last_size = size;
	memcpy(dst, src, size);
}

static void fake_host_rpf_request_backlog(void *arg)
{
	(void)arg;
}

static void fake_host_rpf_request_defer(void *thread, void *arg,
					host_backlog_fn_t backlog)
{
	fake_host_rpf_request_defer_calls++;
	fake_host_rpf_request_defer_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_defer_last_thread = thread;
	fake_host_rpf_request_defer_last_arg = arg;
	fake_host_rpf_request_defer_last_backlog = backlog;
}

static int fake_host_rpf_request_wakeup(void *thread, int state)
{
	fake_host_rpf_request_wakeup_calls++;
	fake_host_rpf_request_wakeup_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_wakeup_last_thread = thread;
	fake_host_rpf_request_wakeup_last_state = state;
	return 0;
}

static void fake_host_rpf_request_unlock(void *thread)
{
	fake_host_rpf_request_unlock_calls++;
	fake_host_rpf_request_unlock_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_unlock_last_thread = thread;
}

static void fake_host_rpf_request_missing_log(int tid)
{
	fake_host_rpf_request_missing_log_calls++;
	fake_host_rpf_request_missing_log_event =
		++fake_host_rpf_request_event_seq;
	fake_host_rpf_request_missing_log_last_tid = tid;
}

static unsigned long fake_host_map_memory(void *os, unsigned long phys,
					  unsigned long size)
{
	(void)os;
	fake_host_map_memory_calls++;
	fake_host_map_last_in_phys = phys;
	fake_host_map_last_size = size;
	return fake_host_map_memory_result;
}

static void *fake_host_map_virtual(unsigned long phys, int npages, int attr)
{
	fake_host_map_virtual_calls++;
	fake_host_map_virtual_last_phys = phys;
	fake_host_map_virtual_last_npages = npages;
	fake_host_map_virtual_last_attr = attr;
	if (fake_host_map_virtual_fail)
		return NULL;
	return fake_host_map_virtual_result;
}

static void *fake_host_prepare_map_virtual(unsigned long phys, int npages,
					   unsigned long attr)
{
	return fake_host_map_virtual(phys, npages, (int)attr);
}

static void fake_host_unmap_virtual(void *addr, int npages)
{
	fake_host_unmap_virtual_calls++;
	fake_host_unmap_virtual_last_addr = addr;
	fake_host_unmap_virtual_last_npages = npages;
}

static void fake_host_unmap_memory(void *os, unsigned long phys,
				   unsigned long size)
{
	(void)os;
	fake_host_unmap_memory_calls++;
	fake_host_unmap_memory_last_phys = phys;
	fake_host_unmap_memory_last_size = size;
}

static void fake_host_dispatch_init_ack_log(void)
{
	fake_host_dispatch_init_ack_log_calls++;
}

static void fake_host_schedule_process_log(unsigned long arg)
{
	fake_host_dispatch_schedule_log_calls++;
	fake_host_dispatch_schedule_last_arg = arg;
}

static int fake_host_prepare_process_call(unsigned long rphys)
{
	fake_host_dispatch_prepare_calls++;
	fake_host_dispatch_prepare_last_arg = rphys;
	return fake_host_dispatch_prepare_rc;
}

static int fake_host_dispatch_prepare_process(void *response_channel,
					      struct ikc_scd_packet *packet)
{
	return host_prepare_process_request_result(response_channel, packet,
		fake_host_prepare_process_call, fake_procfs_answer_send);
}

static int fake_host_dispatch_schedule_process(struct ikc_scd_packet *packet)
{
	fake_host_dispatch_schedule_log_calls++;
	fake_host_dispatch_schedule_last_arg = packet ? packet->arg : 0;
	return host_schedule_process_request_result(packet,
		fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 9);
}

static int fake_host_dispatch_procfs_request(struct ikc_scd_packet *packet)
{
	fake_host_dispatch_procfs_calls++;
	fake_host_dispatch_procfs_last_packet = packet;
	fake_host_dispatch_procfs_last_msg = packet ? packet->msg : 0;
	return fake_host_dispatch_procfs_rc;
}

static int fake_host_dispatch_wake_syscall_thread(struct ikc_scd_packet *packet)
{
	return host_wake_syscall_thread_request_result(packet,
		fake_host_find_thread, fake_host_wakeup_thread,
		fake_host_unlock_thread, fake_host_wake_syscall_log);
}

static int fake_host_dispatch_remote_page_fault(struct ikc_scd_packet *packet,
						void *current_thread)
{
	return host_remote_page_fault_request_result(packet, fake_host_find_thread,
		current_thread, fake_host_rpf_request_body,
		fake_host_rpf_request_alloc, fake_host_rpf_request_copy,
		fake_host_rpf_request_defer, fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(*packet), 0x44, 2);
}

static int fake_host_dispatch_send_signal(void *response_channel,
					  struct ikc_scd_packet *packet)
{
	host_send_signal_request_result(response_channel, packet,
		fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, fake_host_send_signal_log,
		fake_procfs_answer_send);
	return 0;
}

static int fake_host_dispatch_cleanup_process(void *response_channel,
					      struct ikc_scd_packet *packet)
{
	host_cleanup_process_request_result(response_channel, packet,
		fake_host_cleanup_process, fake_host_terminate,
		fake_host_cleanup_process_log, fake_procfs_answer_send);
	return 0;
}

static int fake_host_dispatch_cleanup_fd(void *response_channel,
					 struct ikc_scd_packet *packet)
{
	host_cleanup_fd_request_result(response_channel, packet,
		fake_host_cleanup_fd, fake_host_cleanup_fd_log,
		fake_procfs_answer_send);
	return 0;
}

static int fake_host_dispatch_debug_log(struct ikc_scd_packet *packet)
{
	return host_debug_log_request_result(packet, fake_host_debug_log,
		fake_host_debug_print);
}

static int fake_host_dispatch_perf_ctrl(void *response_channel,
					struct ikc_scd_packet *packet)
{
	return host_perf_ctrl_request_result(response_channel, packet,
		fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send);
}

static int fake_host_dispatch_cpu_rw_reg(void *response_channel,
					 struct ikc_scd_packet *packet)
{
	host_cpu_rw_reg_request_result(response_channel, packet,
		fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_cpu_rw_register, fake_procfs_answer_send);
	return 0;
}

static void fake_host_dispatch_sysfs_packet(void *channel, int msg, int err,
					    long arg1, long arg2, long arg3)
{
	fake_host_dispatch_sysfs_calls++;
	fake_host_dispatch_sysfs_last_channel = channel;
	fake_host_dispatch_sysfs_last_msg = msg;
	fake_host_dispatch_sysfs_last_err = err;
	fake_host_dispatch_sysfs_last_arg1 = arg1;
	fake_host_dispatch_sysfs_last_arg2 = arg2;
	fake_host_dispatch_sysfs_last_arg3 = arg3;
}

static void fake_host_dispatch_unknown_packet(struct ikc_scd_packet *packet)
{
	fake_host_dispatch_unknown_calls++;
	if (packet) {
		fake_host_dispatch_unknown_last_msg = packet->msg;
		fake_host_dispatch_unknown_last_ref = packet->ref;
	}
}

static void fake_host_dispatch_release_packet(struct ikc_scd_packet *packet)
{
	fake_host_dispatch_release_calls++;
	fake_host_dispatch_release_last_packet = packet;
}

static void *fake_host_handler_response_channel(void)
{
	fake_host_handler_response_calls++;
	return (void *)0x424200UL;
}

static void *fake_host_handler_current_thread(void)
{
	fake_host_handler_current_calls++;
	return (void *)0x515100UL;
}

static int fake_host_ikc_packet_handler(struct ihk_ikc_channel_desc *channel,
					void *packet, void *os)
{
	(void)channel;
	(void)packet;
	(void)os;
	return 0;
}

static void reset_fake_host_ikc(void)
{
	memset(fake_host_ikc_channels, 0, sizeof(fake_host_ikc_channels));
	memset(fake_host_ikc_table_storage, 0, sizeof(fake_host_ikc_table_storage));
	fake_host_ikc_table_ptr = NULL;
	fake_host_ikc_alloc_calls = 0;
	fake_host_ikc_alloc_last_size = 0;
	fake_host_ikc_alloc_last_flags = 0;
	fake_host_ikc_alloc_fail = 0;
	fake_host_ikc_connect_calls = 0;
	fake_host_ikc_connect_failures = 0;
	fake_host_ikc_connect_last_port = 0;
	fake_host_ikc_connect_last_pkt_size = 0;
	fake_host_ikc_connect_last_queue_size = 0;
	fake_host_ikc_connect_last_magic = 0;
	fake_host_ikc_connect_last_intr_cpu = 0;
	fake_host_ikc_connect_handler_matches = 0;
	fake_host_ikc_delay_calls = 0;
	fake_host_ikc_delay_last_usec = 0;
	fake_host_ikc_set_current_calls = 0;
	fake_host_ikc_set_current_last_channel = NULL;
	fake_host_ikc_set_regular_calls = 0;
	fake_host_ikc_set_regular_last_channel = NULL;
	fake_host_ikc_set_regular_last_cpu = 0;
	memset(fake_host_ikc_log_counts, 0, sizeof(fake_host_ikc_log_counts));
	fake_host_ikc_log_last_event = 0;
	fake_host_ikc_panic_calls = 0;
}

static void fake_host_prepare_ptr_store(unsigned char *base, unsigned long off,
					void *value)
{
	*(void **)(base + off) = value;
}

static unsigned long fake_host_prepare_ulong_load(unsigned char *base,
						  unsigned long off)
{
	return *(unsigned long *)(base + off);
}

static void fake_host_prepare_ulong_store(unsigned char *base,
					  unsigned long off,
					  unsigned long value)
{
	*(unsigned long *)(base + off) = value;
}

static int fake_host_prepare_int_load(unsigned char *base, unsigned long off)
{
	return *(int *)(base + off);
}

static void reset_fake_host_prepare(void)
{
	memset(fake_host_prepare_monitor_status, 0,
	       sizeof(fake_host_prepare_monitor_status));
	fake_host_prepare_monitor_calls = 0;
	fake_host_prepare_monitor_last_cpu = -1;
	fake_host_prepare_alloc_calls = 0;
	fake_host_prepare_alloc_fail = 0;
	fake_host_prepare_alloc_last_size = 0;
	fake_host_prepare_alloc_last_flags = 0;
	fake_host_prepare_free_calls = 0;
	fake_host_prepare_free_last_ptr = NULL;
	fake_host_prepare_copy_calls = 0;
	fake_host_prepare_copy_last_size = 0;
	fake_host_prepare_create_calls = 0;
	fake_host_prepare_create_fail = 0;
	fake_host_prepare_create_last_entry = 0;
	fake_host_prepare_create_last_cpuset = NULL;
	fake_host_prepare_create_last_cpuset_size = 0;
	fake_host_prepare_destroy_calls = 0;
	fake_host_prepare_ranges_calls = 0;
	fake_host_prepare_ranges_rc = 0;
	fake_host_prepare_ranges_last_thread = NULL;
	fake_host_prepare_ranges_last_pn = NULL;
	fake_host_prepare_ranges_last_p = NULL;
	fake_host_prepare_ranges_last_attr = 0;
	fake_host_prepare_nr_numa_nodes = 8;
	fake_host_prepare_nr_numa_calls = 0;
	fake_host_prepare_flush_calls = 0;
	fake_host_prepare_tofu_calls = 0;
	memset(fake_host_prepare_log_counts, 0,
	       sizeof(fake_host_prepare_log_counts));
	fake_host_prepare_log_last_event = 0;
	fake_host_prepare_log_arg0 = 0;
	fake_host_prepare_log_arg1 = 0;
	fake_host_prepare_log_arg2 = 0;
	memset(fake_host_prepare_thread, 0, sizeof(fake_host_prepare_thread));
	memset(fake_host_prepare_process, 0, sizeof(fake_host_prepare_process));
	memset(fake_host_prepare_vm, 0, sizeof(fake_host_prepare_vm));
	memset(fake_host_prepare_aspace, 0, sizeof(fake_host_prepare_aspace));
	memset(fake_host_prepare_clone, 0, sizeof(fake_host_prepare_clone));
	memset(&fake_host_prepare_desc, 0, sizeof(fake_host_prepare_desc));
	memset(fake_host_prepare_sections_pn_storage, 0,
	       sizeof(fake_host_prepare_sections_pn_storage));
		memset(fake_host_prepare_sections_p_storage, 0,
		       sizeof(fake_host_prepare_sections_p_storage));
		memset(fake_host_prepare_vm_ranges, 0, sizeof(fake_host_prepare_vm_ranges));
		memset(fake_host_prepare_page_pool, 0, sizeof(fake_host_prepare_page_pool));
		memset(fake_host_prepare_args_remote_args, 0,
		       sizeof(fake_host_prepare_args_remote_args));
		memset(fake_host_prepare_args_remote_envs, 0,
		       sizeof(fake_host_prepare_args_remote_envs));
		memset(fake_host_prepare_args_local_args, 0,
		       sizeof(fake_host_prepare_args_local_args));
		memset(fake_host_prepare_args_local_envs, 0,
		       sizeof(fake_host_prepare_args_local_envs));
		memset(fake_host_prepare_args_old_cmdline, 0,
		       sizeof(fake_host_prepare_args_old_cmdline));
		fake_host_prepare_add_range_calls = 0;
	fake_host_prepare_add_range_fail_call = 0;
	fake_host_prepare_add_range_rc = -22;
	fake_host_prepare_add_range_last_vm = NULL;
	fake_host_prepare_add_range_last_start = 0;
	fake_host_prepare_add_range_last_end = 0;
	fake_host_prepare_add_range_last_phys = 0;
	fake_host_prepare_add_range_last_flag = 0;
	fake_host_prepare_add_range_last_pgshift = 0;
	fake_host_prepare_alloc_pages_calls = 0;
	fake_host_prepare_alloc_pages_fail_call = 0;
	fake_host_prepare_alloc_pages_last_npages = 0;
	fake_host_prepare_alloc_pages_last_flags = 0;
	fake_host_prepare_alloc_pages_last_addr = 0;
	fake_host_prepare_free_pages_calls = 0;
	fake_host_prepare_free_pages_last_addr = NULL;
	fake_host_prepare_free_pages_last_npages = 0;
	fake_host_prepare_virt_to_phys_calls = 0;
	fake_host_prepare_virt_to_phys_last_addr = NULL;
	fake_host_prepare_ptattr_calls = 0;
	fake_host_prepare_ptattr_last_flag = 0;
	fake_host_prepare_ptattr_last_fault = 0;
	fake_host_prepare_pt_set_calls = 0;
	fake_host_prepare_pt_set_fail_call = 0;
	fake_host_prepare_pt_set_rc = -5;
	fake_host_prepare_pt_set_last_pt = NULL;
	fake_host_prepare_pt_set_last_vm = NULL;
	fake_host_prepare_pt_set_last_start = 0;
	fake_host_prepare_pt_set_last_end = 0;
	fake_host_prepare_pt_set_last_phys = 0;
	fake_host_prepare_pt_set_last_attr = 0;
	fake_host_prepare_pt_set_last_pgshift = 0;
	fake_host_prepare_pt_set_last_range = NULL;
	fake_host_prepare_modify_context_calls = 0;
	fake_host_prepare_modify_context_last_uctx = NULL;
	fake_host_prepare_modify_context_last_reg = 0;
	fake_host_prepare_modify_context_last_value = 0;
	memset(fake_host_prepare_ranges_log_counts, 0,
	       sizeof(fake_host_prepare_ranges_log_counts));
	fake_host_prepare_ranges_log_last_event = 0;
		fake_host_prepare_ranges_log_arg0 = 0;
		fake_host_prepare_ranges_log_arg1 = 0;
		fake_host_prepare_ranges_log_arg2 = 0;
		fake_host_prepare_args_map_memory_calls = 0;
		fake_host_prepare_args_map_memory_last_phys = 0;
		fake_host_prepare_args_map_memory_last_size = 0;
		fake_host_prepare_args_map_virtual_calls = 0;
		fake_host_prepare_args_map_virtual_fail_call = 0;
		fake_host_prepare_args_map_virtual_last_phys = 0;
		fake_host_prepare_args_map_virtual_last_npages = 0;
		fake_host_prepare_args_map_virtual_last_attr = 0;
		fake_host_prepare_args_vdso_calls = 0;
		fake_host_prepare_args_vdso_rc = 0;
		fake_host_prepare_args_vdso_last_vm = NULL;
		fake_host_prepare_args_init_calls = 0;
		fake_host_prepare_args_init_rc = 0;
		fake_host_prepare_args_init_last_thread = NULL;
		fake_host_prepare_args_init_last_pn = NULL;
		fake_host_prepare_args_init_last_at_base = 0;
		fake_host_prepare_args_init_last_argc = 0;
		fake_host_prepare_args_init_last_envc = 0;
		fake_host_prepare_args_init_last_argv0 = 0;
		fake_host_prepare_args_init_last_argv1 = 0;
		fake_host_prepare_args_init_last_env0 = 0;
		memset(fake_host_prepare_args_log_counts, 0,
		       sizeof(fake_host_prepare_args_log_counts));
		fake_host_prepare_args_log_last_event = 0;
		fake_host_prepare_args_log_arg0 = 0;
		fake_host_prepare_args_log_arg1 = 0;
		fake_host_prepare_args_log_arg2 = 0;
		fake_host_prepare_ptr_store(fake_host_prepare_thread,
			FAKE_HOST_PREPARE_THREAD_VM_OFF, fake_host_prepare_vm);
	fake_host_prepare_ptr_store(fake_host_prepare_thread,
		FAKE_HOST_PREPARE_THREAD_PROC_OFF, fake_host_prepare_process);
	fake_host_prepare_ptr_store(fake_host_prepare_process,
		FAKE_HOST_PREPARE_PROCESS_VM_OFF, fake_host_prepare_vm);
	fake_host_prepare_ptr_store(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_ASPACE_OFF, fake_host_prepare_aspace);
	fake_host_prepare_ptr_store(fake_host_prepare_aspace, 0,
		(void *)0x12345678000UL);
	fake_host_map_memory_result = 0xfee000UL;
	fake_host_map_virtual_result = &fake_host_prepare_desc;
}

static int fake_host_prepare_monitor_status_fn(int cpu)
{
	fake_host_prepare_monitor_calls++;
	fake_host_prepare_monitor_last_cpu = cpu;
	return fake_host_prepare_monitor_status[cpu];
}

static void *fake_host_prepare_alloc(unsigned long size, unsigned long flags)
{
	fake_host_prepare_alloc_calls++;
	fake_host_prepare_alloc_last_size = size;
	fake_host_prepare_alloc_last_flags = flags;
	if (fake_host_prepare_alloc_fail)
		return NULL;
	return fake_host_prepare_clone;
}

static void fake_host_prepare_free(void *ptr)
{
	fake_host_prepare_free_calls++;
	fake_host_prepare_free_last_ptr = ptr;
}

static void fake_host_prepare_copy_long(void *dst, const void *src,
					unsigned long size)
{
	fake_host_prepare_copy_calls++;
	fake_host_prepare_copy_last_size = size;
	memcpy(dst, src, size);
}

static void *fake_host_prepare_create_thread(unsigned long entry,
					     unsigned long *cpu_set,
					     unsigned long cpu_set_size)
{
	fake_host_prepare_create_calls++;
	fake_host_prepare_create_last_entry = entry;
	fake_host_prepare_create_last_cpuset = cpu_set;
	fake_host_prepare_create_last_cpuset_size = cpu_set_size;
	if (fake_host_prepare_create_fail)
		return NULL;
	return fake_host_prepare_thread;
}

static void fake_host_prepare_destroy_thread(void *thread)
{
	(void)thread;
	fake_host_prepare_destroy_calls++;
}

static int fake_host_prepare_ranges(void *thread, struct program_load_desc *pn,
				    struct program_load_desc *p,
				    unsigned long attr,
				    char *args, int args_len,
				    char *envs, int envs_len)
{
	require(args == NULL);
	require(args_len == 0);
	require(envs == NULL);
	require(envs_len == 0);
	fake_host_prepare_ranges_calls++;
	fake_host_prepare_ranges_last_thread = thread;
	fake_host_prepare_ranges_last_pn = pn;
	fake_host_prepare_ranges_last_p = p;
	fake_host_prepare_ranges_last_attr = attr;
	return fake_host_prepare_ranges_rc;
}

static int fake_host_prepare_nr_numa_nodes_fn(void)
{
	fake_host_prepare_nr_numa_calls++;
	return fake_host_prepare_nr_numa_nodes;
}

static void fake_host_prepare_flush_tlb(void)
{
	fake_host_prepare_flush_calls++;
}

static void fake_host_prepare_tofu_finalize(void)
{
	fake_host_prepare_tofu_calls++;
}

static void fake_host_prepare_log(int event, unsigned long arg0,
				  unsigned long arg1, unsigned long arg2)
{
	if (event >= 0 && event < (int)(sizeof(fake_host_prepare_log_counts) /
				       sizeof(fake_host_prepare_log_counts[0])))
		fake_host_prepare_log_counts[event]++;
	fake_host_prepare_log_last_event = event;
	fake_host_prepare_log_arg0 = arg0;
	fake_host_prepare_log_arg1 = arg1;
	fake_host_prepare_log_arg2 = arg2;
}

static int fake_host_prepare_call(unsigned long rphys)
{
	return host_prepare_process_body_result(rphys, 3, 0x700, 4096, 0x77,
		0x00007ffffffff000UL, 0x40000000UL, 17, 5, 2,
		fake_host_prepare_monitor_status_fn, fake_host_map_memory,
		fake_host_prepare_map_virtual, fake_host_unmap_virtual,
		fake_host_unmap_memory, fake_host_prepare_alloc,
		fake_host_prepare_free, fake_host_prepare_copy_long,
		fake_host_prepare_create_thread, fake_host_prepare_destroy_thread,
		fake_host_prepare_ranges, fake_host_prepare_nr_numa_nodes_fn,
		fake_host_prepare_flush_tlb, fake_host_prepare_tofu_finalize,
		fake_host_prepare_log);
}

static int fake_host_prepare_add_range(void *vm, unsigned long start,
				       unsigned long end, unsigned long phys,
				       unsigned long flag, int pgshift,
				       void **rangep)
{
	struct fake_host_prepare_vm_range *range;

	fake_host_prepare_add_range_calls++;
	fake_host_prepare_add_range_last_vm = vm;
	fake_host_prepare_add_range_last_start = start;
	fake_host_prepare_add_range_last_end = end;
	fake_host_prepare_add_range_last_phys = phys;
	fake_host_prepare_add_range_last_flag = flag;
	fake_host_prepare_add_range_last_pgshift = pgshift;
	if (fake_host_prepare_add_range_fail_call &&
	    fake_host_prepare_add_range_calls ==
	    fake_host_prepare_add_range_fail_call)
		return fake_host_prepare_add_range_rc;
	range = &fake_host_prepare_vm_ranges[
		fake_host_prepare_add_range_calls - 1];
	range->start = start;
	range->end = end;
	range->flag = flag;
	range->pgshift = pgshift;
	if (rangep)
		*rangep = range;
	return 0;
}

static void *fake_host_prepare_alloc_pages_user(int npages,
						unsigned long flags,
						unsigned long virt_addr)
{
	fake_host_prepare_alloc_pages_calls++;
	fake_host_prepare_alloc_pages_last_npages = npages;
	fake_host_prepare_alloc_pages_last_flags = flags;
	fake_host_prepare_alloc_pages_last_addr = virt_addr;
	if (fake_host_prepare_alloc_pages_fail_call &&
	    fake_host_prepare_alloc_pages_calls ==
	    fake_host_prepare_alloc_pages_fail_call)
		return NULL;
	return fake_host_prepare_page_pool[
		fake_host_prepare_alloc_pages_calls - 1];
}

static void fake_host_prepare_free_pages_user(void *addr, int npages)
{
	fake_host_prepare_free_pages_calls++;
	fake_host_prepare_free_pages_last_addr = addr;
	fake_host_prepare_free_pages_last_npages = npages;
}

static unsigned long fake_host_prepare_virt_to_phys(void *addr)
{
	fake_host_prepare_virt_to_phys_calls++;
	fake_host_prepare_virt_to_phys_last_addr = addr;
	return (unsigned long)(uintptr_t)addr + 0x100000000UL;
}

static unsigned long fake_host_prepare_arch_vrflag_to_ptattr(
		unsigned long flag, unsigned long fault, void *ptep)
{
	(void)ptep;
	fake_host_prepare_ptattr_calls++;
	fake_host_prepare_ptattr_last_flag = flag;
	fake_host_prepare_ptattr_last_fault = fault;
	return flag ^ 0xa5a5UL;
}

static int fake_host_prepare_pt_set_range(void *page_table, void *vm,
					  unsigned long start,
					  unsigned long end,
					  unsigned long phys,
					  unsigned long attr,
					  int pgshift, void *range,
					  int flags)
{
	(void)flags;
	fake_host_prepare_pt_set_calls++;
	fake_host_prepare_pt_set_last_pt = page_table;
	fake_host_prepare_pt_set_last_vm = vm;
	fake_host_prepare_pt_set_last_start = start;
	fake_host_prepare_pt_set_last_end = end;
	fake_host_prepare_pt_set_last_phys = phys;
	fake_host_prepare_pt_set_last_attr = attr;
	fake_host_prepare_pt_set_last_pgshift = pgshift;
	fake_host_prepare_pt_set_last_range = range;
	if (fake_host_prepare_pt_set_fail_call &&
	    fake_host_prepare_pt_set_calls == fake_host_prepare_pt_set_fail_call)
		return fake_host_prepare_pt_set_rc;
	return 0;
}

static void fake_host_prepare_modify_user_context(void *uctx, int reg,
						  unsigned long value)
{
	fake_host_prepare_modify_context_calls++;
	fake_host_prepare_modify_context_last_uctx = uctx;
	fake_host_prepare_modify_context_last_reg = reg;
	fake_host_prepare_modify_context_last_value = value;
}

static void fake_host_prepare_ranges_log(int event, unsigned long arg0,
					 unsigned long arg1,
					 unsigned long arg2)
{
	if (event >= 0 && event < (int)(sizeof(fake_host_prepare_ranges_log_counts) /
				       sizeof(fake_host_prepare_ranges_log_counts[0])))
		fake_host_prepare_ranges_log_counts[event]++;
	fake_host_prepare_ranges_log_last_event = event;
	fake_host_prepare_ranges_log_arg0 = arg0;
	fake_host_prepare_ranges_log_arg1 = arg1;
	fake_host_prepare_ranges_log_arg2 = arg2;
}

	static int fake_host_prepare_sections_call(struct program_load_desc *pn,
						   struct program_load_desc *p,
						   unsigned long *at_base)
	{
		return host_prepare_ranges_sections_result(fake_host_prepare_thread,
		pn, p, at_base, PAGE_SIZE, PAGE_MASK, LARGE_PAGE_SIZE,
		LARGE_PAGE_MASK, TASK_UNMAPPED_BASE, PAGE_SHIFT,
		LARGE_PAGE_SHIFT, IHK_MC_AP_NOWAIT, IHK_MC_AP_USER,
		MPOL_NO_BSS, PF_POPULATE, IHK_UCR_PROGRAM_COUNTER,
		fake_host_prepare_add_range,
		fake_host_prepare_alloc_pages_user,
		fake_host_prepare_free_pages_user,
		fake_host_prepare_virt_to_phys,
		fake_host_prepare_arch_vrflag_to_ptattr,
		fake_host_prepare_pt_set_range,
		fake_host_prepare_modify_user_context,
			fake_host_prepare_ranges_log);
	}

	static unsigned long fake_host_prepare_fill_args(unsigned char *buf)
	{
		long *argc = (long *)buf;
		char **argv = (char **)(buf + sizeof(long));
		unsigned long strings_off = 4 * sizeof(char *);

		memset(buf, 0, PAGE_SIZE);
		*argc = 2;
		argv[0] = (char *)0;
		argv[1] = (char *)6;
		argv[2] = NULL;
		memcpy(buf + strings_off, "hello\0world\0", 12);
		return strings_off + 12;
	}

	static unsigned long fake_host_prepare_fill_envs(unsigned char *buf)
	{
		long *envc = (long *)buf;
		char **env = (char **)(buf + sizeof(long));
		unsigned long strings_off = 3 * sizeof(char *);

		memset(buf, 0, PAGE_SIZE);
		*envc = 1;
		env[0] = (char *)0;
		env[1] = NULL;
		memcpy(buf + strings_off, "A=B\0", 4);
		return strings_off + 4;
	}

	static void fake_host_prepare_args_setup_remote(struct program_load_desc *pn,
							struct program_load_desc *p)
	{
		memset(pn, 0, sizeof(*pn));
		memset(p, 0, sizeof(*p));
		fake_host_prepare_ulong_store(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_MAP_START_OFF, TASK_UNMAPPED_BASE);
		p->args = (char *)0xaaa000UL;
		p->args_len = fake_host_prepare_fill_args(
			fake_host_prepare_args_remote_args);
		p->envs = (char *)0xbbb000UL;
		p->envs_len = fake_host_prepare_fill_envs(
			fake_host_prepare_args_remote_envs);
	}

	static unsigned long fake_host_prepare_args_map_memory(void *os,
							       unsigned long phys,
							       unsigned long size)
	{
		(void)os;
		fake_host_prepare_args_map_memory_calls++;
		fake_host_prepare_args_map_memory_last_phys = phys;
		fake_host_prepare_args_map_memory_last_size = size;
		if (phys == 0xaaa000UL)
			return 0xa0000UL;
		if (phys == 0xbbb000UL)
			return 0xb0000UL;
		return 0xc0000UL + fake_host_prepare_args_map_memory_calls;
	}

	static void *fake_host_prepare_args_map_virtual(unsigned long phys,
							int npages,
							unsigned long attr)
	{
		fake_host_prepare_args_map_virtual_calls++;
		fake_host_prepare_args_map_virtual_last_phys = phys;
		fake_host_prepare_args_map_virtual_last_npages = npages;
		fake_host_prepare_args_map_virtual_last_attr = attr;
		if (fake_host_prepare_args_map_virtual_fail_call &&
		    fake_host_prepare_args_map_virtual_calls ==
		    fake_host_prepare_args_map_virtual_fail_call)
			return NULL;
		if (phys == 0xa0000UL)
			return fake_host_prepare_args_remote_args;
		if (phys == 0xb0000UL)
			return fake_host_prepare_args_remote_envs;
		return NULL;
	}

	static int fake_host_prepare_args_arch_map_vdso(void *vm)
	{
		fake_host_prepare_args_vdso_calls++;
		fake_host_prepare_args_vdso_last_vm = vm;
		return fake_host_prepare_args_vdso_rc;
	}

	static int fake_host_prepare_args_init_stack(void *thread,
			struct program_load_desc *pn, unsigned long at_base,
			int argc, char **argv, int envc, char **env)
	{
		fake_host_prepare_args_init_calls++;
		fake_host_prepare_args_init_last_thread = thread;
		fake_host_prepare_args_init_last_pn = pn;
		fake_host_prepare_args_init_last_at_base = at_base;
		fake_host_prepare_args_init_last_argc = argc;
		fake_host_prepare_args_init_last_envc = envc;
		fake_host_prepare_args_init_last_argv0 =
			argc > 0 ? (unsigned long)argv[0] : 0;
		fake_host_prepare_args_init_last_argv1 =
			argc > 1 ? (unsigned long)argv[1] : 0;
		fake_host_prepare_args_init_last_env0 =
			envc > 0 ? (unsigned long)env[0] : 0;
		return fake_host_prepare_args_init_rc;
	}

	static void fake_host_prepare_args_log(int event, unsigned long arg0,
					       unsigned long arg1,
					       unsigned long arg2)
	{
		if (event >= 0 && event < (int)(sizeof(fake_host_prepare_args_log_counts) /
					       sizeof(fake_host_prepare_args_log_counts[0])))
			fake_host_prepare_args_log_counts[event]++;
		fake_host_prepare_args_log_last_event = event;
		fake_host_prepare_args_log_arg0 = arg0;
		fake_host_prepare_args_log_arg1 = arg1;
		fake_host_prepare_args_log_arg2 = arg2;
	}

	static int fake_host_prepare_args_envs_call(struct program_load_desc *pn,
			struct program_load_desc *p, unsigned long at_base,
			char *args, int args_len, char *envs, int envs_len)
	{
		return host_prepare_ranges_args_envs_result(
			fake_host_prepare_thread, pn, p, 0x712, args, args_len,
			envs, envs_len, at_base, PAGE_SIZE, PAGE_MASK, PAGE_SHIFT,
			IHK_MC_AP_NOWAIT, fake_host_prepare_add_range,
			fake_host_prepare_alloc_pages_user,
			fake_host_prepare_free_pages_user,
			fake_host_prepare_virt_to_phys,
			fake_host_prepare_args_map_memory,
			fake_host_prepare_args_map_virtual,
			fake_host_unmap_virtual, fake_host_unmap_memory,
			fake_host_prepare_copy_long, fake_host_prepare_alloc,
			fake_host_prepare_free, fake_host_prepare_flush_tlb,
			fake_host_prepare_args_arch_map_vdso,
			fake_host_prepare_args_init_stack,
			fake_host_prepare_args_log);
	}

	static void *fake_host_ikc_alloc(unsigned long size, unsigned long flags)
	{
	fake_host_ikc_alloc_calls++;
	fake_host_ikc_alloc_last_size = size;
	fake_host_ikc_alloc_last_flags = flags;
	if (fake_host_ikc_alloc_fail)
		return NULL;
	return fake_host_ikc_table_storage;
}

static int fake_host_ikc_connect(struct ihk_ikc_connect_param *param)
{
	fake_host_ikc_connect_calls++;
	fake_host_ikc_connect_last_port = param->port;
	fake_host_ikc_connect_last_pkt_size = param->pkt_size;
	fake_host_ikc_connect_last_queue_size = param->queue_size;
	fake_host_ikc_connect_last_magic = param->magic;
	fake_host_ikc_connect_last_intr_cpu = param->intr_cpu;
	fake_host_ikc_connect_handler_matches =
		param->handler == fake_host_ikc_packet_handler;
	if (fake_host_ikc_connect_calls <= fake_host_ikc_connect_failures)
		return -1;
	param->channel = &fake_host_ikc_channels[
		fake_host_ikc_connect_calls % 4];
	return 0;
}

static void fake_host_ikc_delay(unsigned long usec)
{
	fake_host_ikc_delay_calls++;
	fake_host_ikc_delay_last_usec = usec;
}

static void fake_host_ikc_set_current(void *channel)
{
	fake_host_ikc_set_current_calls++;
	fake_host_ikc_set_current_last_channel = channel;
}

static void fake_host_ikc_set_regular(void *channel, int cpu)
{
	fake_host_ikc_set_regular_calls++;
	fake_host_ikc_set_regular_last_channel = channel;
	fake_host_ikc_set_regular_last_cpu = cpu;
}

static void fake_host_ikc_log(int event)
{
	if (event >= 0 && event < (int)(sizeof(fake_host_ikc_log_counts) /
				       sizeof(fake_host_ikc_log_counts[0])))
		fake_host_ikc_log_counts[event]++;
	fake_host_ikc_log_last_event = event;
}

static void fake_host_ikc_panic(void)
{
	fake_host_ikc_panic_calls++;
}

static struct host_scd_dispatch_ops make_fake_host_dispatch_ops(void)
{
	struct host_scd_dispatch_ops ops;

	memset(&ops, 0, sizeof(ops));
	ops.init_ack_log_fn = fake_host_dispatch_init_ack_log;
	ops.prepare_process_fn = fake_host_dispatch_prepare_process;
	ops.schedule_process_fn = fake_host_dispatch_schedule_process;
	ops.wake_syscall_thread_fn = fake_host_dispatch_wake_syscall_thread;
	ops.remote_page_fault_fn = fake_host_dispatch_remote_page_fault;
	ops.send_signal_fn = fake_host_dispatch_send_signal;
	ops.procfs_request_fn = fake_host_dispatch_procfs_request;
	ops.cleanup_process_fn = fake_host_dispatch_cleanup_process;
	ops.cleanup_fd_fn = fake_host_dispatch_cleanup_fd;
	ops.debug_log_fn = fake_host_dispatch_debug_log;
	ops.sysfs_packet_fn = fake_host_dispatch_sysfs_packet;
	ops.perf_ctrl_fn = fake_host_dispatch_perf_ctrl;
	ops.cpu_rw_reg_fn = fake_host_dispatch_cpu_rw_reg;
	ops.unknown_packet_log_fn = fake_host_dispatch_unknown_packet;
	ops.release_packet_fn = fake_host_dispatch_release_packet;
	return ops;
}

static void fake_procfs_thread_pause(void)
{
	fake_procfs_thread_pause_calls++;
	if (fake_procfs_thread_done_ptr &&
	    fake_procfs_thread_pause_calls >= 2) {
		*fake_procfs_thread_done_ptr = 1;
	}
}

static ssize_t fake_sysfs_show(void *ops, void *instance, void *buf,
			       size_t bufsize)
{
	(void)ops;
	(void)instance;
	(void)buf;
	return (ssize_t)bufsize - 3;
}

static ssize_t fake_sysfs_store(void *ops, void *instance, void *buf,
				size_t size)
{
	(void)ops;
	(void)instance;
	(void)buf;
	return -((ssize_t)size + 5);
}

static void fake_sysfs_release(void *ops, void *instance)
{
	(void)ops;
	(void)instance;
	fake_sysfs_release_calls++;
}

static void fake_sysfs_packet_show(long nodeh, void *ops, void *instance)
{
	fake_sysfs_packet_show_calls++;
	fake_sysfs_packet_last_nodeh = nodeh;
	fake_sysfs_packet_last_ops = (long)ops;
	fake_sysfs_packet_last_instance = (long)instance;
}

static void fake_sysfs_packet_store(long nodeh, void *ops, void *instance,
				    size_t size)
{
	fake_sysfs_packet_store_calls++;
	fake_sysfs_packet_last_nodeh = nodeh;
	fake_sysfs_packet_last_ops = (long)ops;
	fake_sysfs_packet_last_instance = (long)instance;
	fake_sysfs_packet_last_size = size;
}

static void fake_sysfs_packet_release(long nodeh, void *ops, void *instance)
{
	fake_sysfs_packet_release_calls++;
	fake_sysfs_packet_last_nodeh = nodeh;
	fake_sysfs_packet_last_ops = (long)ops;
	fake_sysfs_packet_last_instance = (long)instance;
}

static void fake_sysfs_packet_unknown(int msg, int error, long arg1,
				      long arg2, long arg3)
{
	fake_sysfs_packet_unknown_calls++;
	fake_sysfs_packet_last_msg = msg;
	fake_sysfs_packet_last_error = error;
	fake_sysfs_packet_last_arg1 = arg1;
	fake_sysfs_packet_last_arg2 = arg2;
	fake_sysfs_packet_last_arg3 = arg3;
}

struct fake_file_page {
	long offset;
	uintptr_t phys;
	int mode;
	int count;
	long mapped;
};

struct fake_file_thread {
	void *pgio_fp;
	void *pgio_arg;
};

struct fake_file_pageio_args {
	void *fileobj;
	long objoff;
	size_t pgsize;
};

struct fake_file_obj {
	uintptr_t handle;
	int ref_after_inc;
	size_t size;
	int flags;
	int status;
	int refcnt;
	unsigned long sref;
	int listed;
	void *path;
	void *pages;
	int nr_pages;
};

static int fake_file_phys_to_page_calls;
static uintptr_t fake_file_last_phys_to_page;
static int fake_file_page_offset_calls;
static int fake_file_write_calls;
static uintptr_t fake_file_last_write_handle;
static long fake_file_last_write_offset;
static size_t fake_file_last_write_pgsize;
static uintptr_t fake_file_last_write_phys;
static long fake_file_write_ret;
static int fake_file_log_calls;
static int fake_file_last_log_event;
static uintptr_t fake_file_last_log_phys;
static size_t fake_file_last_log_pgsize;
static long fake_file_last_log_result;
static int fake_file_lock_calls;
static int fake_file_unlock_calls;
static void *fake_file_last_lock;
static void *fake_file_last_node;
static int fake_file_lookup_calls;
static int fake_file_last_lookup_hash;
static long fake_file_last_lookup_off;
static int fake_file_page_phys_calls;
static void *fake_file_page_result;
static void *fake_file_lookup_result;
static int fake_file_page_mode_calls;
static int fake_file_page_set_mode_calls;
static int fake_file_last_set_mode;
static int fake_file_zero_calls;
static uintptr_t fake_file_last_zero_phys;
static int fake_file_schedule_calls;
static int fake_file_pause_calls;
static int fake_file_pageio_log_calls;
static int fake_file_last_pageio_log_event;
static long fake_file_last_pageio_log_off;
static size_t fake_file_last_pageio_log_pgsize;
static long fake_file_last_pageio_log_value;
static int fake_file_panic_calls;
static int fake_file_last_panic_mode;
static void *fake_file_free_first_result;
static int fake_file_list_remove_calls;
static int fake_file_page_remove_calls;
static int fake_file_phys_to_virt_calls;
static uintptr_t fake_file_last_phys_to_virt;
static int fake_file_page_count_calls;
static int fake_file_page_unmap_calls;
static int fake_file_page_unmap_ret;
static int fake_file_free_pages_calls;
static void *fake_file_last_free_pages_addr;
static int fake_file_last_free_pages_npages;
static int fake_file_rss_sub_calls;
static size_t fake_file_last_rss_size;
static size_t fake_file_last_rss_pgsize;
static int fake_file_free_calls;
static void *fake_file_last_free_ptr;
static int fake_file_release_calls;
static uintptr_t fake_file_last_release_handle;
static unsigned long fake_file_last_release_sref;
static int fake_file_release_ret;
static int fake_file_page_at_calls;
static void *fake_file_page_array[4];
static int fake_file_free_log_calls;
static int fake_file_last_free_log_event;
static uintptr_t fake_file_last_free_log_phys;
static long fake_file_last_free_log_value;
static unsigned long fake_file_last_free_log_flags;
static void *fake_file_items[5];
static int fake_file_list_first_calls;
static int fake_file_list_next_calls;
static int fake_file_handle_calls;
static int fake_file_ref_calls;
static int fake_file_dec_calls;
static void *fake_file_last_dec_obj;
static int fake_file_list_insert_calls;
static int fake_file_size_set_calls;
static size_t fake_file_last_size_set;
static int fake_file_flags_set_calls;
static int fake_file_last_flags_set;
static int fake_file_status_set_calls;
static int fake_file_last_status_set;
static int fake_file_refcnt_set_calls;
static int fake_file_last_refcnt_set;
static int fake_file_sref_get_calls;
static int fake_file_sref_set_calls;
static unsigned long fake_file_last_sref_set;
static int fake_file_alloc_calls;
static size_t fake_file_last_alloc_size;
static unsigned long fake_file_last_alloc_flags;
static void *fake_file_alloc_result;
static int fake_file_copy_calls;
static void *fake_file_last_copy_dst;
static const void *fake_file_last_copy_src;
static size_t fake_file_last_copy_len;
static int fake_file_path_set_calls;
static void *fake_file_last_path_set;
static int fake_file_create_log_calls;
static int fake_file_last_create_log_event;
static const void *fake_file_last_create_log_path;
static long fake_file_last_create_log_value;
static int fake_file_zero_mem_calls;
static void *fake_file_last_zero_mem_ptr;
static size_t fake_file_last_zero_mem_len;
static int fake_file_pages_set_calls;
static void *fake_file_last_pages_set;
static int fake_file_nr_pages_set_calls;
static int fake_file_last_nr_pages_set;
static int fake_file_alloc_node_calls;
static int fake_file_last_alloc_node_npages;
static int fake_file_last_alloc_node_p2align;
static unsigned long fake_file_last_alloc_node_flags;
static int fake_file_last_alloc_node_node;
static uintptr_t fake_file_last_alloc_node_virt;
static void *fake_file_alloc_node_results[4];
static int fake_file_alloc_node_nodes[4];
static int fake_file_page_slot_set_calls;
static int fake_file_last_page_slot_index;
static void *fake_file_last_page_slot_page;
static int fake_file_rss_add_calls;
static size_t fake_file_last_rss_add_size;
static size_t fake_file_last_rss_add_pgsize;
static int fake_file_premap_log_calls;
static int fake_file_last_premap_log_event;
static void *fake_file_last_premap_log_page;
static long fake_file_last_premap_log_value;
static int fake_file_premap_log_counts[32];
static int fake_file_alloc_user_calls;
static int fake_file_last_alloc_user_npages;
static unsigned long fake_file_last_alloc_user_flags;
static uintptr_t fake_file_last_alloc_user_virt;
static void *fake_file_alloc_user_result;
static int fake_file_cmpxchg_calls;
static int fake_file_last_cmpxchg_index;
static void *fake_file_last_cmpxchg_old;
static void *fake_file_last_cmpxchg_new;
static void *fake_file_cmpxchg_forced_return;
static int fake_file_virt_phys_calls;
static void *fake_file_last_virt_phys_ptr;
static int fake_file_get_log_calls;
static int fake_file_last_get_log_event;
static long fake_file_last_get_log_off;
static uintptr_t fake_file_last_get_log_phys;
static long fake_file_last_get_log_value;
static int fake_file_get_log_counts[32];
static int fake_file_page_insert_calls;
static uintptr_t fake_file_last_page_insert_phys;
static int fake_file_page_offset_set_calls;
static long fake_file_last_page_offset_set;
static int fake_file_page_count_set_calls;
static long fake_file_last_page_count_set;
static int fake_file_page_mapped_set_calls;
static long fake_file_last_page_mapped_set;
static int fake_file_hash_insert_calls;
static void *fake_file_last_hash_insert_obj;
static void *fake_file_last_hash_insert_page;
static int fake_file_last_hash_insert_hash;
static int fake_file_page_count_inc_calls;
static int fake_file_args_set_calls;
static void *fake_file_last_args_set_args;
static void *fake_file_last_args_set_obj;
static long fake_file_last_args_set_off;
static size_t fake_file_last_args_set_pgsize;
static int fake_file_pgio_set_calls;
static void *fake_file_last_pgio_thread;
static void *fake_file_last_pgio_fn;
static void *fake_file_last_pgio_arg;
static int fake_file_get_regular_log_calls;
static int fake_file_last_get_regular_log_event;
static long fake_file_last_get_regular_log_off;
static uintptr_t fake_file_last_get_regular_log_phys;
static uintptr_t fake_file_last_get_regular_log_value;
static size_t fake_file_last_get_regular_log_size;
static int fake_file_last_get_regular_log_mode;
static int fake_file_last_get_regular_log_count;
static int fake_file_get_regular_log_counts[40];
static int fake_file_get_regular_panic_calls;

static void fake_file_reset(void)
{
	fake_file_phys_to_page_calls = 0;
	fake_file_last_phys_to_page = 0;
	fake_file_page_offset_calls = 0;
	fake_file_write_calls = 0;
	fake_file_last_write_handle = 0;
	fake_file_last_write_offset = 0;
	fake_file_last_write_pgsize = 0;
	fake_file_last_write_phys = 0;
	fake_file_write_ret = 0;
	fake_file_log_calls = 0;
	fake_file_last_log_event = 0;
	fake_file_last_log_phys = 0;
	fake_file_last_log_pgsize = 0;
	fake_file_last_log_result = 0;
	fake_file_lock_calls = 0;
	fake_file_unlock_calls = 0;
	fake_file_last_lock = NULL;
	fake_file_last_node = NULL;
	fake_file_lookup_calls = 0;
	fake_file_last_lookup_hash = 0;
	fake_file_last_lookup_off = 0;
	fake_file_page_phys_calls = 0;
	fake_file_page_result = NULL;
	fake_file_lookup_result = NULL;
	fake_file_page_mode_calls = 0;
	fake_file_page_set_mode_calls = 0;
	fake_file_last_set_mode = 0;
	fake_file_zero_calls = 0;
	fake_file_last_zero_phys = 0;
	fake_file_schedule_calls = 0;
	fake_file_pause_calls = 0;
	fake_file_pageio_log_calls = 0;
	fake_file_last_pageio_log_event = 0;
	fake_file_last_pageio_log_off = 0;
	fake_file_last_pageio_log_pgsize = 0;
	fake_file_last_pageio_log_value = 0;
	fake_file_panic_calls = 0;
	fake_file_last_panic_mode = 0;
	fake_file_free_first_result = NULL;
	fake_file_list_remove_calls = 0;
	fake_file_page_remove_calls = 0;
	fake_file_phys_to_virt_calls = 0;
	fake_file_last_phys_to_virt = 0;
	fake_file_page_count_calls = 0;
	fake_file_page_unmap_calls = 0;
	fake_file_page_unmap_ret = 1;
	fake_file_free_pages_calls = 0;
	fake_file_last_free_pages_addr = NULL;
	fake_file_last_free_pages_npages = 0;
	fake_file_rss_sub_calls = 0;
	fake_file_last_rss_size = 0;
	fake_file_last_rss_pgsize = 0;
	fake_file_free_calls = 0;
	fake_file_last_free_ptr = NULL;
	fake_file_release_calls = 0;
	fake_file_last_release_handle = 0;
	fake_file_last_release_sref = 0;
	fake_file_release_ret = 0;
	fake_file_page_at_calls = 0;
	memset(fake_file_page_array, 0, sizeof(fake_file_page_array));
	fake_file_free_log_calls = 0;
	fake_file_last_free_log_event = 0;
	fake_file_last_free_log_phys = 0;
	fake_file_last_free_log_value = 0;
	fake_file_last_free_log_flags = 0;
	memset(fake_file_items, 0, sizeof(fake_file_items));
	fake_file_list_first_calls = 0;
	fake_file_list_next_calls = 0;
	fake_file_handle_calls = 0;
	fake_file_ref_calls = 0;
	fake_file_dec_calls = 0;
	fake_file_last_dec_obj = NULL;
	fake_file_list_insert_calls = 0;
	fake_file_size_set_calls = 0;
	fake_file_last_size_set = 0;
	fake_file_flags_set_calls = 0;
	fake_file_last_flags_set = 0;
	fake_file_status_set_calls = 0;
	fake_file_last_status_set = 0;
	fake_file_refcnt_set_calls = 0;
	fake_file_last_refcnt_set = 0;
	fake_file_sref_get_calls = 0;
	fake_file_sref_set_calls = 0;
	fake_file_last_sref_set = 0;
	fake_file_alloc_calls = 0;
	fake_file_last_alloc_size = 0;
	fake_file_last_alloc_flags = 0;
	fake_file_alloc_result = NULL;
	fake_file_copy_calls = 0;
	fake_file_last_copy_dst = NULL;
	fake_file_last_copy_src = NULL;
	fake_file_last_copy_len = 0;
	fake_file_path_set_calls = 0;
	fake_file_last_path_set = NULL;
	fake_file_create_log_calls = 0;
	fake_file_last_create_log_event = 0;
	fake_file_last_create_log_path = NULL;
	fake_file_last_create_log_value = 0;
	fake_file_zero_mem_calls = 0;
	fake_file_last_zero_mem_ptr = NULL;
	fake_file_last_zero_mem_len = 0;
	fake_file_pages_set_calls = 0;
	fake_file_last_pages_set = NULL;
	fake_file_nr_pages_set_calls = 0;
	fake_file_last_nr_pages_set = 0;
	fake_file_alloc_node_calls = 0;
	fake_file_last_alloc_node_npages = 0;
	fake_file_last_alloc_node_p2align = 0;
	fake_file_last_alloc_node_flags = 0;
	fake_file_last_alloc_node_node = 0;
	fake_file_last_alloc_node_virt = 0;
	memset(fake_file_alloc_node_results, 0,
	       sizeof(fake_file_alloc_node_results));
	memset(fake_file_alloc_node_nodes, 0,
	       sizeof(fake_file_alloc_node_nodes));
	fake_file_page_slot_set_calls = 0;
	fake_file_last_page_slot_index = 0;
	fake_file_last_page_slot_page = NULL;
	fake_file_rss_add_calls = 0;
	fake_file_last_rss_add_size = 0;
	fake_file_last_rss_add_pgsize = 0;
	fake_file_premap_log_calls = 0;
	fake_file_last_premap_log_event = 0;
	fake_file_last_premap_log_page = NULL;
	fake_file_last_premap_log_value = 0;
	memset(fake_file_premap_log_counts, 0,
	       sizeof(fake_file_premap_log_counts));
	fake_file_alloc_user_calls = 0;
	fake_file_last_alloc_user_npages = 0;
	fake_file_last_alloc_user_flags = 0;
	fake_file_last_alloc_user_virt = 0;
	fake_file_alloc_user_result = NULL;
	fake_file_cmpxchg_calls = 0;
	fake_file_last_cmpxchg_index = 0;
	fake_file_last_cmpxchg_old = NULL;
	fake_file_last_cmpxchg_new = NULL;
	fake_file_cmpxchg_forced_return = NULL;
	fake_file_virt_phys_calls = 0;
	fake_file_last_virt_phys_ptr = NULL;
	fake_file_get_log_calls = 0;
	fake_file_last_get_log_event = 0;
	fake_file_last_get_log_off = 0;
	fake_file_last_get_log_phys = 0;
	fake_file_last_get_log_value = 0;
	memset(fake_file_get_log_counts, 0, sizeof(fake_file_get_log_counts));
	fake_file_page_insert_calls = 0;
	fake_file_last_page_insert_phys = 0;
	fake_file_page_offset_set_calls = 0;
	fake_file_last_page_offset_set = 0;
	fake_file_page_count_set_calls = 0;
	fake_file_last_page_count_set = 0;
	fake_file_page_mapped_set_calls = 0;
	fake_file_last_page_mapped_set = 0;
	fake_file_hash_insert_calls = 0;
	fake_file_last_hash_insert_obj = NULL;
	fake_file_last_hash_insert_page = NULL;
	fake_file_last_hash_insert_hash = 0;
	fake_file_page_count_inc_calls = 0;
	fake_file_args_set_calls = 0;
	fake_file_last_args_set_args = NULL;
	fake_file_last_args_set_obj = NULL;
	fake_file_last_args_set_off = 0;
	fake_file_last_args_set_pgsize = 0;
	fake_file_pgio_set_calls = 0;
	fake_file_last_pgio_thread = NULL;
	fake_file_last_pgio_fn = NULL;
	fake_file_last_pgio_arg = NULL;
	fake_file_get_regular_log_calls = 0;
	fake_file_last_get_regular_log_event = 0;
	fake_file_last_get_regular_log_off = 0;
	fake_file_last_get_regular_log_phys = 0;
	fake_file_last_get_regular_log_value = 0;
	fake_file_last_get_regular_log_size = 0;
	fake_file_last_get_regular_log_mode = 0;
	fake_file_last_get_regular_log_count = 0;
	memset(fake_file_get_regular_log_counts, 0,
	       sizeof(fake_file_get_regular_log_counts));
	fake_file_get_regular_panic_calls = 0;
}

static void *fake_file_phys_to_page(uintptr_t phys)
{
	fake_file_phys_to_page_calls++;
	fake_file_last_phys_to_page = phys;
	return fake_file_page_result;
}

static long fake_file_page_offset(void *page)
{
	fake_file_page_offset_calls++;
	return ((struct fake_file_page *)page)->offset;
}

static long fake_file_write(uintptr_t handle, long offset, size_t pgsize,
			    uintptr_t phys)
{
	fake_file_write_calls++;
	fake_file_last_write_handle = handle;
	fake_file_last_write_offset = offset;
	fake_file_last_write_pgsize = pgsize;
	fake_file_last_write_phys = phys;
	return fake_file_write_ret;
}

static void fake_file_log(int event, void *memobj, void *obj, uintptr_t phys,
			  size_t pgsize, long result)
{
	(void)memobj;
	(void)obj;
	fake_file_log_calls++;
	fake_file_last_log_event = event;
	fake_file_last_log_phys = phys;
	fake_file_last_log_pgsize = pgsize;
	fake_file_last_log_result = result;
}

static void fake_file_lock(void *lock, void *node)
{
	fake_file_lock_calls++;
	fake_file_last_lock = lock;
	fake_file_last_node = node;
}

static void fake_file_unlock(void *lock, void *node)
{
	(void)lock;
	(void)node;
	fake_file_unlock_calls++;
}

static void *fake_file_lookup(void *obj, int hash, long off)
{
	(void)obj;
	fake_file_lookup_calls++;
	fake_file_last_lookup_hash = hash;
	fake_file_last_lookup_off = off;
	return fake_file_lookup_result;
}

static uintptr_t fake_file_page_phys(void *page)
{
	fake_file_page_phys_calls++;
	return ((struct fake_file_page *)page)->phys;
}

static int fake_file_page_mode(void *page)
{
	fake_file_page_mode_calls++;
	return ((struct fake_file_page *)page)->mode;
}

static void fake_file_page_set_mode(void *page, int mode)
{
	fake_file_page_set_mode_calls++;
	fake_file_last_set_mode = mode;
	((struct fake_file_page *)page)->mode = mode;
}

static void fake_file_zero_page(uintptr_t phys)
{
	fake_file_zero_calls++;
	fake_file_last_zero_phys = phys;
}

static void fake_file_schedule(void)
{
	fake_file_schedule_calls++;
}

static void fake_file_pause(void)
{
	fake_file_pause_calls++;
	if (fake_file_lookup_result && fake_file_pause_calls == 51) {
		((struct fake_file_page *)fake_file_lookup_result)->mode =
			PM_WILL_PAGEIO;
	}
}

static void fake_file_pageio_log(int event, void *obj, long off,
				 size_t pgsize, long value)
{
	(void)obj;
	fake_file_pageio_log_calls++;
	fake_file_last_pageio_log_event = event;
	fake_file_last_pageio_log_off = off;
	fake_file_last_pageio_log_pgsize = pgsize;
	fake_file_last_pageio_log_value = value;
}

static void fake_file_panic(void *obj, long off, size_t pgsize, int mode)
{
	(void)obj;
	(void)off;
	(void)pgsize;
	fake_file_panic_calls++;
	fake_file_last_panic_mode = mode;
}

static void fake_file_list_remove(void *obj)
{
	(void)obj;
	fake_file_list_remove_calls++;
}

static void *fake_file_free_first(void *obj)
{
	(void)obj;
	return fake_file_free_first_result;
}

static void fake_file_page_remove(void *page)
{
	(void)page;
	fake_file_page_remove_calls++;
	fake_file_free_first_result = NULL;
}

static void *fake_file_phys_to_virt(uintptr_t phys)
{
	fake_file_phys_to_virt_calls++;
	fake_file_last_phys_to_virt = phys;
	return (void *)(phys + 0x1000UL);
}

static int fake_file_page_count(void *page)
{
	fake_file_page_count_calls++;
	return ((struct fake_file_page *)page)->count;
}

static int fake_file_page_unmap(void *page)
{
	(void)page;
	fake_file_page_unmap_calls++;
	return fake_file_page_unmap_ret;
}

static void fake_file_free_pages(void *addr, int npages)
{
	fake_file_free_pages_calls++;
	fake_file_last_free_pages_addr = addr;
	fake_file_last_free_pages_npages = npages;
}

static void fake_file_rss_sub(size_t size, size_t pgsize)
{
	fake_file_rss_sub_calls++;
	fake_file_last_rss_size = size;
	fake_file_last_rss_pgsize = pgsize;
}

static void fake_file_free_ptr(void *ptr)
{
	fake_file_free_calls++;
	fake_file_last_free_ptr = ptr;
}

static int fake_file_release(uintptr_t handle, unsigned long sref)
{
	fake_file_release_calls++;
	fake_file_last_release_handle = handle;
	fake_file_last_release_sref = sref;
	return fake_file_release_ret;
}

static void *fake_file_page_at(void *pages, int index)
{
	fake_file_page_at_calls++;
	if (index < 0 || index >= 4)
		return NULL;
	return ((void **)pages)[index];
}

static void fake_file_free_log(int event, void *obj, void *page,
			       uintptr_t phys, long value, unsigned long flags)
{
	(void)obj;
	(void)page;
	fake_file_free_log_calls++;
	fake_file_last_free_log_event = event;
	fake_file_last_free_log_phys = phys;
	fake_file_last_free_log_value = value;
	fake_file_last_free_log_flags = flags;
}

static void *fake_file_list_first(void *head)
{
	(void)head;
	fake_file_list_first_calls++;
	return fake_file_items[0];
}

static void *fake_file_list_next(void *head, void *obj)
{
	(void)head;
	fake_file_list_next_calls++;
	for (int i = 0; i < 4; i++) {
		if (fake_file_items[i] == obj) {
			return fake_file_items[i + 1];
		}
	}
	return NULL;
}

static uintptr_t fake_file_handle(void *obj)
{
	fake_file_handle_calls++;
	return ((struct fake_file_obj *)obj)->handle;
}

static int fake_file_ref(void *obj)
{
	fake_file_ref_calls++;
	return ((struct fake_file_obj *)obj)->ref_after_inc;
}

static void fake_file_dec(void *obj)
{
	fake_file_dec_calls++;
	fake_file_last_dec_obj = obj;
}

static void fake_file_list_insert(void *obj)
{
	fake_file_list_insert_calls++;
	((struct fake_file_obj *)obj)->listed = 1;
}

static void fake_file_size_set(void *obj, size_t size)
{
	fake_file_size_set_calls++;
	fake_file_last_size_set = size;
	((struct fake_file_obj *)obj)->size = size;
}

static void fake_file_flags_set(void *obj, int flags)
{
	fake_file_flags_set_calls++;
	fake_file_last_flags_set = flags;
	((struct fake_file_obj *)obj)->flags = flags;
}

static void fake_file_status_set(void *obj, int status)
{
	fake_file_status_set_calls++;
	fake_file_last_status_set = status;
	((struct fake_file_obj *)obj)->status = status;
}

static void fake_file_refcnt_set(void *obj, int refcnt)
{
	fake_file_refcnt_set_calls++;
	fake_file_last_refcnt_set = refcnt;
	((struct fake_file_obj *)obj)->refcnt = refcnt;
}

static unsigned long fake_file_sref_get(void *obj)
{
	fake_file_sref_get_calls++;
	return ((struct fake_file_obj *)obj)->sref;
}

static void fake_file_sref_set(void *obj, unsigned long sref)
{
	fake_file_sref_set_calls++;
	fake_file_last_sref_set = sref;
	((struct fake_file_obj *)obj)->sref = sref;
}

static void *fake_file_alloc(size_t size, unsigned long flags)
{
	fake_file_alloc_calls++;
	fake_file_last_alloc_size = size;
	fake_file_last_alloc_flags = flags;
	return fake_file_alloc_result;
}

static void fake_file_copy(void *dst, const void *src, size_t len)
{
	fake_file_copy_calls++;
	fake_file_last_copy_dst = dst;
	fake_file_last_copy_src = src;
	fake_file_last_copy_len = len;
	memcpy(dst, src, len);
}

static void fake_file_path_set(void *obj, void *path)
{
	fake_file_path_set_calls++;
	fake_file_last_path_set = path;
	((struct fake_file_obj *)obj)->path = path;
}

static void fake_file_create_log(int event, void *obj, const void *path,
				 long value)
{
	(void)obj;
	fake_file_create_log_calls++;
	fake_file_last_create_log_event = event;
	fake_file_last_create_log_path = path;
	fake_file_last_create_log_value = value;
}

static void fake_file_zero_mem(void *ptr, size_t len)
{
	fake_file_zero_mem_calls++;
	fake_file_last_zero_mem_ptr = ptr;
	fake_file_last_zero_mem_len = len;
	memset(ptr, 0, len);
}

static void fake_file_pages_set(void *obj, void *pages)
{
	fake_file_pages_set_calls++;
	fake_file_last_pages_set = pages;
	((struct fake_file_obj *)obj)->pages = pages;
}

static void fake_file_nr_pages_set(void *obj, int nr_pages)
{
	fake_file_nr_pages_set_calls++;
	fake_file_last_nr_pages_set = nr_pages;
	((struct fake_file_obj *)obj)->nr_pages = nr_pages;
}

static void *fake_file_alloc_pages_node(int npages, int p2align,
					unsigned long flags, int node,
					uintptr_t virt_addr)
{
	int index = fake_file_alloc_node_calls;

	fake_file_alloc_node_calls++;
	fake_file_last_alloc_node_npages = npages;
	fake_file_last_alloc_node_p2align = p2align;
	fake_file_last_alloc_node_flags = flags;
	fake_file_last_alloc_node_node = node;
	fake_file_last_alloc_node_virt = virt_addr;
	if (index >= 0 && index < 4) {
		fake_file_alloc_node_nodes[index] = node;
		return fake_file_alloc_node_results[index];
	}
	return NULL;
}

static void fake_file_page_slot_set(void *pages, int index, void *page)
{
	fake_file_page_slot_set_calls++;
	fake_file_last_page_slot_index = index;
	fake_file_last_page_slot_page = page;
	((void **)pages)[index] = page;
}

static void fake_file_rss_add(size_t size, size_t pgsize)
{
	fake_file_rss_add_calls++;
	fake_file_last_rss_add_size = size;
	fake_file_last_rss_add_pgsize = pgsize;
}

static void fake_file_premap_log(int event, void *obj, void *page,
				 long value)
{
	(void)obj;
	fake_file_premap_log_calls++;
	fake_file_last_premap_log_event = event;
	fake_file_last_premap_log_page = page;
	fake_file_last_premap_log_value = value;
	if (event >= 0 && event < (int)(sizeof(fake_file_premap_log_counts) /
				       sizeof(fake_file_premap_log_counts[0]))) {
		fake_file_premap_log_counts[event]++;
	}
}

static void *fake_file_alloc_user_pages(int npages, unsigned long flags,
					uintptr_t virt_addr)
{
	fake_file_alloc_user_calls++;
	fake_file_last_alloc_user_npages = npages;
	fake_file_last_alloc_user_flags = flags;
	fake_file_last_alloc_user_virt = virt_addr;
	return fake_file_alloc_user_result;
}

static void *fake_file_page_slot_cmpxchg(void *pages, int index, void *old,
					 void *new_value)
{
	void **slot = pages;
	void *current = slot[index];

	fake_file_cmpxchg_calls++;
	fake_file_last_cmpxchg_index = index;
	fake_file_last_cmpxchg_old = old;
	fake_file_last_cmpxchg_new = new_value;
	if (fake_file_cmpxchg_forced_return) {
		slot[index] = fake_file_cmpxchg_forced_return;
		return fake_file_cmpxchg_forced_return;
	}
	if (current == old) {
		slot[index] = new_value;
	}
	return current;
}

static uintptr_t fake_file_virt_phys(void *ptr)
{
	fake_file_virt_phys_calls++;
	fake_file_last_virt_phys_ptr = ptr;
	return (uintptr_t)ptr + 0x100000UL;
}

static void fake_file_get_log(int event, void *obj, long off, int p2align,
			      uintptr_t virt_addr, uintptr_t physp_addr,
			      void *page, uintptr_t phys, long value)
{
	(void)obj;
	(void)p2align;
	(void)virt_addr;
	(void)physp_addr;
	(void)page;
	fake_file_get_log_calls++;
	fake_file_last_get_log_event = event;
	fake_file_last_get_log_off = off;
	fake_file_last_get_log_phys = phys;
	fake_file_last_get_log_value = value;
	if (event >= 0 && event < (int)(sizeof(fake_file_get_log_counts) /
				       sizeof(fake_file_get_log_counts[0]))) {
		fake_file_get_log_counts[event]++;
	}
}

static void *fake_file_phys_to_page_insert(uintptr_t phys)
{
	fake_file_page_insert_calls++;
	fake_file_last_page_insert_phys = phys;
	return fake_file_page_result;
}

static void fake_file_page_offset_set(void *page, long off)
{
	fake_file_page_offset_set_calls++;
	fake_file_last_page_offset_set = off;
	((struct fake_file_page *)page)->offset = off;
}

static void fake_file_page_count_set(void *page, long value)
{
	fake_file_page_count_set_calls++;
	fake_file_last_page_count_set = value;
	((struct fake_file_page *)page)->count = (int)value;
}

static void fake_file_page_mapped_set(void *page, long value)
{
	fake_file_page_mapped_set_calls++;
	fake_file_last_page_mapped_set = value;
	((struct fake_file_page *)page)->mapped = value;
}

static void fake_file_page_hash_insert(void *obj, void *page, int hash)
{
	fake_file_hash_insert_calls++;
	fake_file_last_hash_insert_obj = obj;
	fake_file_last_hash_insert_page = page;
	fake_file_last_hash_insert_hash = hash;
	(void)obj;
	(void)page;
}

static void fake_file_page_count_inc(void *page)
{
	fake_file_page_count_inc_calls++;
	((struct fake_file_page *)page)->count++;
}

static void fake_file_pageio_args_set(void *args0, void *obj, long off,
				      size_t pgsize)
{
	struct fake_file_pageio_args *args = args0;

	fake_file_args_set_calls++;
	fake_file_last_args_set_args = args0;
	fake_file_last_args_set_obj = obj;
	fake_file_last_args_set_off = off;
	fake_file_last_args_set_pgsize = pgsize;
	args->fileobj = obj;
	args->objoff = off;
	args->pgsize = pgsize;
}

static void fake_file_pgio_set(void *thread0, void *pageio_fn, void *args)
{
	struct fake_file_thread *thread = thread0;

	fake_file_pgio_set_calls++;
	fake_file_last_pgio_thread = thread0;
	fake_file_last_pgio_fn = pageio_fn;
	fake_file_last_pgio_arg = args;
	thread->pgio_fp = pageio_fn;
	thread->pgio_arg = args;
}

static void fake_file_get_regular_log(int event, void *obj, long off,
				      int p2align, uintptr_t virt_addr,
				      uintptr_t physp_addr, void *page,
				      uintptr_t phys, uintptr_t value,
				      size_t size, int mode, int count)
{
	(void)obj;
	(void)p2align;
	(void)virt_addr;
	(void)physp_addr;
	(void)page;
	fake_file_get_regular_log_calls++;
	fake_file_last_get_regular_log_event = event;
	fake_file_last_get_regular_log_off = off;
	fake_file_last_get_regular_log_phys = phys;
	fake_file_last_get_regular_log_value = value;
	fake_file_last_get_regular_log_size = size;
	fake_file_last_get_regular_log_mode = mode;
	fake_file_last_get_regular_log_count = count;
	if (event >= 0 &&
	    event < (int)(sizeof(fake_file_get_regular_log_counts) /
			  sizeof(fake_file_get_regular_log_counts[0]))) {
		fake_file_get_regular_log_counts[event]++;
	}
}

static void fake_file_get_regular_panic(void *obj, long off, void *page,
					int mode)
{
	(void)obj;
	(void)off;
	(void)page;
	fake_file_get_regular_panic_calls++;
	fake_file_last_panic_mode = mode;
}

static int fake_file_get_regular_call(void *obj, int flags, long off,
				      int p2align, uintptr_t virt_addr,
				      uintptr_t *physp, void *thread,
				      void *pageio_fn, void *lock, void *node,
				      size_t args_size,
				      unsigned long args_alloc_flags)
{
	return fileobj_get_regular_body_result(
		obj, flags, off, p2align, virt_addr, physp, thread, pageio_fn,
		lock, node, args_size, args_alloc_flags, fake_file_lock,
		fake_file_unlock, fake_file_lookup, fake_file_alloc,
		fake_file_free_ptr, fake_file_alloc_user_pages,
		fake_file_virt_phys, fake_file_phys_to_page_insert,
		fake_file_page_mode, fake_file_page_offset_set,
		fake_file_page_count_set, fake_file_page_mapped_set,
		fake_file_page_hash_insert, fake_file_page_set_mode,
		fake_file_ref, fake_file_pageio_args_set, fake_file_pgio_set,
		fake_file_page_count_inc, fake_file_page_phys,
		fake_file_page_count, fake_file_page_remove,
		fake_file_phys_to_virt, fake_file_page_unmap,
		fake_file_free_pages, fake_file_get_regular_log,
		fake_file_get_regular_panic);
}

#define FAKE_PFN_VALID (1UL << 63)
#define FAKE_PFN_PRESENT 1UL
#define FAKE_VR_WRITE_COMBINED 0x400UL

struct fake_dev_obj {
	uintptr_t pfn_table[4];
};

static int fake_dev_unmap_calls;
static int fake_dev_unmap_ret;
static uintptr_t fake_dev_last_unmap_handle;
static int fake_dev_free_pages_calls;
static void *fake_dev_last_free_pages_addr;
static size_t fake_dev_last_free_pages_npages;
static int fake_dev_free_calls;
static void *fake_dev_last_free;
static int fake_dev_log_calls;
static int fake_dev_last_log_event;
static int fake_dev_last_log_error;
static uintptr_t fake_dev_last_log_pfn;
static int fake_dev_profile_calls;
static int fake_dev_lock_calls;
static int fake_dev_unlock_calls;
static void *fake_dev_last_lock;
static unsigned long fake_dev_last_unlock_irq;
static int fake_dev_load_calls;
static int fake_dev_last_load_ix;
static int fake_dev_fetch_calls;
static uintptr_t fake_dev_fetch_pfn;
static int fake_dev_fetch_ret;
static uintptr_t fake_dev_last_fetch_handle;
static long fake_dev_last_fetch_off;
static int fake_dev_last_fetch_p2align;
static int fake_dev_wc_calls;
static int fake_dev_wc_ret;
static uintptr_t fake_dev_last_wc_pfn;
static int fake_dev_map_calls;
static uintptr_t fake_dev_last_map_phys;
static size_t fake_dev_last_map_size;
static uintptr_t fake_dev_map_result;
static int fake_dev_store_calls;
static int fake_dev_last_store_ix;
static uintptr_t fake_dev_last_store_pfn;

static void fake_dev_reset(void)
{
	fake_dev_unmap_calls = 0;
	fake_dev_unmap_ret = 0;
	fake_dev_last_unmap_handle = 0;
	fake_dev_free_pages_calls = 0;
	fake_dev_last_free_pages_addr = NULL;
	fake_dev_last_free_pages_npages = 0;
	fake_dev_free_calls = 0;
	fake_dev_last_free = NULL;
	fake_dev_log_calls = 0;
	fake_dev_last_log_event = 0;
	fake_dev_last_log_error = 0;
	fake_dev_last_log_pfn = 0;
	fake_dev_profile_calls = 0;
	fake_dev_lock_calls = 0;
	fake_dev_unlock_calls = 0;
	fake_dev_last_lock = NULL;
	fake_dev_last_unlock_irq = 0;
	fake_dev_load_calls = 0;
	fake_dev_last_load_ix = 0;
	fake_dev_fetch_calls = 0;
	fake_dev_fetch_pfn = 0;
	fake_dev_fetch_ret = 0;
	fake_dev_last_fetch_handle = 0;
	fake_dev_last_fetch_off = 0;
	fake_dev_last_fetch_p2align = 0;
	fake_dev_wc_calls = 0;
	fake_dev_wc_ret = 0;
	fake_dev_last_wc_pfn = 0;
	fake_dev_map_calls = 0;
	fake_dev_last_map_phys = 0;
	fake_dev_last_map_size = 0;
	fake_dev_map_result = 0;
	fake_dev_store_calls = 0;
	fake_dev_last_store_ix = 0;
	fake_dev_last_store_pfn = 0;
}

static int fake_dev_unmap(uintptr_t handle)
{
	fake_dev_unmap_calls++;
	fake_dev_last_unmap_handle = handle;
	return fake_dev_unmap_ret;
}

static void fake_dev_free_pages(void *addr, size_t npages)
{
	fake_dev_free_pages_calls++;
	fake_dev_last_free_pages_addr = addr;
	fake_dev_last_free_pages_npages = npages;
}

static void fake_dev_free(void *addr)
{
	fake_dev_free_calls++;
	fake_dev_last_free = addr;
}

static void fake_dev_log(int event, void *memobj, void *obj, long off,
			 long pgoff, int p2align, int ix, int error,
			 uintptr_t pfn)
{
	(void)memobj;
	(void)obj;
	(void)off;
	(void)pgoff;
	(void)p2align;
	(void)ix;
	fake_dev_log_calls++;
	fake_dev_last_log_event = event;
	fake_dev_last_log_error = error;
	fake_dev_last_log_pfn = pfn;
}

static void fake_dev_profile(void)
{
	fake_dev_profile_calls++;
}

static unsigned long fake_dev_lock(void *lock)
{
	fake_dev_lock_calls++;
	fake_dev_last_lock = lock;
	return 0xabc0UL + (unsigned long)fake_dev_lock_calls;
}

static void fake_dev_unlock(void *lock, unsigned long irqstate)
{
	(void)lock;
	fake_dev_unlock_calls++;
	fake_dev_last_unlock_irq = irqstate;
}

static uintptr_t fake_dev_pfn_load(void *obj, int ix)
{
	fake_dev_load_calls++;
	fake_dev_last_load_ix = ix;
	return ((struct fake_dev_obj *)obj)->pfn_table[ix];
}

static int fake_dev_fetch(void *memobj, void *obj, uintptr_t handle,
			  long off, int p2align, uintptr_t *pfnp)
{
	(void)memobj;
	(void)obj;
	fake_dev_fetch_calls++;
	fake_dev_last_fetch_handle = handle;
	fake_dev_last_fetch_off = off;
	fake_dev_last_fetch_p2align = p2align;
	*pfnp = fake_dev_fetch_pfn;
	return fake_dev_fetch_ret;
}

static int fake_dev_wc(uintptr_t pfn)
{
	fake_dev_wc_calls++;
	fake_dev_last_wc_pfn = pfn;
	return fake_dev_wc_ret;
}

static uintptr_t fake_dev_map(uintptr_t phys, size_t size)
{
	fake_dev_map_calls++;
	fake_dev_last_map_phys = phys;
	fake_dev_last_map_size = size;
	return fake_dev_map_result;
}

static void fake_dev_store(void *obj, int ix, uintptr_t pfn)
{
	struct fake_dev_obj *dev = obj;

	fake_dev_store_calls++;
	fake_dev_last_store_ix = ix;
	fake_dev_last_store_pfn = pfn;
	if (devobj_should_store_pfn_result(dev->pfn_table[ix]))
		dev->pfn_table[ix] = pfn;
}

static int fake_zero_lock_calls;
static int fake_zero_unlock_calls;
static int fake_zero_alloc_calls;
static int fake_zero_free_calls;
static int fake_zero_memset_calls;
static int fake_zero_obj_init_calls;
static int fake_zero_page_alloc_calls;
static int fake_zero_page_free_calls;
static int fake_zero_phys_calls;
static int fake_zero_page_insert_calls;
static int fake_zero_duplicate_calls;
static int fake_zero_page_init_calls;
static int fake_zero_page_list_insert_calls;
static int fake_zero_publish_calls;
static int fake_zero_alloc_singleton_calls;
static int fake_zero_ref_calls;
static int fake_zero_log_calls;
static int fake_zero_last_log_event;
static int fake_zero_last_log_error;
static void *fake_zero_alloc_result;
static void *fake_zero_page_alloc_result;
static void *fake_zero_page_insert_result;
static void *fake_zero_singleton;
static void *fake_zero_alloc_singleton_obj;
static int fake_zero_alloc_singleton_result;
static int fake_zero_page_mode;
static size_t fake_zero_last_alloc_size;
static unsigned long fake_zero_last_alloc_flags;
static int fake_zero_last_page_alloc_npages;
static unsigned long fake_zero_last_page_alloc_flags;
static void *fake_zero_last_free;
static void *fake_zero_last_page_free;
static int fake_zero_last_page_free_npages;
static void *fake_zero_last_memset_dst;
static int fake_zero_last_memset_value;
static size_t fake_zero_last_memset_len;
static void *fake_zero_last_obj_init_obj;
static void *fake_zero_last_obj_init_ops;
static uintptr_t fake_zero_last_insert_phys;
static void *fake_zero_last_list_obj;
static void *fake_zero_last_list_page;
static void *fake_zero_last_ref;

static void fake_zero_reset(void)
{
	fake_zero_lock_calls = 0;
	fake_zero_unlock_calls = 0;
	fake_zero_alloc_calls = 0;
	fake_zero_free_calls = 0;
	fake_zero_memset_calls = 0;
	fake_zero_obj_init_calls = 0;
	fake_zero_page_alloc_calls = 0;
	fake_zero_page_free_calls = 0;
	fake_zero_phys_calls = 0;
	fake_zero_page_insert_calls = 0;
	fake_zero_duplicate_calls = 0;
	fake_zero_page_init_calls = 0;
	fake_zero_page_list_insert_calls = 0;
	fake_zero_publish_calls = 0;
	fake_zero_alloc_singleton_calls = 0;
	fake_zero_ref_calls = 0;
	fake_zero_log_calls = 0;
	fake_zero_last_log_event = 0;
	fake_zero_last_log_error = 0;
	fake_zero_alloc_result = NULL;
	fake_zero_page_alloc_result = NULL;
	fake_zero_page_insert_result = NULL;
	fake_zero_singleton = NULL;
	fake_zero_alloc_singleton_obj = NULL;
	fake_zero_alloc_singleton_result = 0;
	fake_zero_page_mode = 0;
	fake_zero_last_alloc_size = 0;
	fake_zero_last_alloc_flags = 0;
	fake_zero_last_page_alloc_npages = 0;
	fake_zero_last_page_alloc_flags = 0;
	fake_zero_last_free = NULL;
	fake_zero_last_page_free = NULL;
	fake_zero_last_page_free_npages = 0;
	fake_zero_last_memset_dst = NULL;
	fake_zero_last_memset_value = 0;
	fake_zero_last_memset_len = 0;
	fake_zero_last_obj_init_obj = NULL;
	fake_zero_last_obj_init_ops = NULL;
	fake_zero_last_insert_phys = 0;
	fake_zero_last_list_obj = NULL;
	fake_zero_last_list_page = NULL;
	fake_zero_last_ref = NULL;
}

static void fake_zero_lock(void *lock)
{
	(void)lock;
	fake_zero_lock_calls++;
}

static void fake_zero_unlock(void *lock)
{
	(void)lock;
	fake_zero_unlock_calls++;
}

static void *fake_zero_alloc(size_t size, unsigned long flags)
{
	fake_zero_alloc_calls++;
	fake_zero_last_alloc_size = size;
	fake_zero_last_alloc_flags = flags;
	return fake_zero_alloc_result;
}

static void fake_zero_free(void *ptr)
{
	fake_zero_free_calls++;
	fake_zero_last_free = ptr;
}

static void *fake_zero_memset(void *dst, int value, size_t len)
{
	fake_zero_memset_calls++;
	fake_zero_last_memset_dst = dst;
	fake_zero_last_memset_value = value;
	fake_zero_last_memset_len = len;
	return dst;
}

static void fake_zero_obj_init(void *obj, void *ops)
{
	fake_zero_obj_init_calls++;
	fake_zero_last_obj_init_obj = obj;
	fake_zero_last_obj_init_ops = ops;
}

static void *fake_zero_page_alloc(int npages, unsigned long flags)
{
	fake_zero_page_alloc_calls++;
	fake_zero_last_page_alloc_npages = npages;
	fake_zero_last_page_alloc_flags = flags;
	return fake_zero_page_alloc_result;
}

static void fake_zero_page_free(void *virt, int npages)
{
	fake_zero_page_free_calls++;
	fake_zero_last_page_free = virt;
	fake_zero_last_page_free_npages = npages;
}

static uintptr_t fake_zero_phys(void *virt)
{
	(void)virt;
	fake_zero_phys_calls++;
	return 0x12345000UL;
}

static void *fake_zero_page_insert(uintptr_t phys)
{
	fake_zero_page_insert_calls++;
	fake_zero_last_insert_phys = phys;
	return fake_zero_page_insert_result;
}

static int fake_zero_page_mode_fn(void *page)
{
	(void)page;
	return fake_zero_page_mode;
}

static void fake_zero_duplicate(void *page)
{
	(void)page;
	fake_zero_duplicate_calls++;
}

static void fake_zero_page_init(void *page)
{
	(void)page;
	fake_zero_page_init_calls++;
}

static void fake_zero_page_list_insert(void *obj, void *page)
{
	fake_zero_page_list_insert_calls++;
	fake_zero_last_list_obj = obj;
	fake_zero_last_list_page = page;
}

static void fake_zero_publish(void *obj)
{
	fake_zero_publish_calls++;
	fake_zero_singleton = obj;
}

static int fake_zero_alloc_singleton(void)
{
	fake_zero_alloc_singleton_calls++;
	if (!fake_zero_alloc_singleton_result)
		fake_zero_singleton = fake_zero_alloc_singleton_obj;
	return fake_zero_alloc_singleton_result;
}

static void *fake_zero_get_singleton(void)
{
	return fake_zero_singleton;
}

static void fake_zero_ref(void *memobj)
{
	fake_zero_ref_calls++;
	fake_zero_last_ref = memobj;
}

static void fake_zero_log(int event, int error, void *obj, void *page,
			  uintptr_t phys)
{
	(void)obj;
	(void)page;
	(void)phys;
	fake_zero_log_calls++;
	fake_zero_last_log_event = event;
	fake_zero_last_log_error = error;
}

struct fake_shm_page {
	uintptr_t phys;
	int pgshift;
	int mode;
	long offset;
	int count;
	long mapped;
};

struct fake_shm_user {
	size_t locked;
	int ruid;
	void *next;
};

struct fake_shm_memobj {
	int flags;
};

static int fake_shm_ref_calls;
static int fake_shm_unref_calls;
static int fake_shm_lock_calls;
static int fake_shm_unlock_calls;
static int fake_shm_lookup_calls;
static long fake_shm_last_lookup_off;
static void *fake_shm_lookup_result;
static int fake_shm_page_phys_calls;
static int fake_shm_log_calls;
static int fake_shm_last_log_event;
static int fake_shm_last_log_error;
static uintptr_t fake_shm_last_log_phys;
static int fake_shm_pte_lookup_calls;
static int fake_shm_pte_missing_at;
static size_t fake_shm_pte_size;
static int fake_shm_p2align;
static void *fake_shm_last_pte_vaddr;
static int fake_shm_insert_hash_calls;
static uintptr_t fake_shm_last_insert_phys;
static void *fake_shm_insert_result;
static int fake_shm_list_insert_calls;
static void *fake_shm_last_insert_obj;
static void *fake_shm_last_insert_page;
static int fake_shm_alloc_page_calls;
static int fake_shm_last_alloc_npages;
static int fake_shm_last_alloc_p2align;
static unsigned long fake_shm_last_alloc_flags;
static uintptr_t fake_shm_last_alloc_virt_addr;
static void *fake_shm_alloc_result;
static int fake_shm_free_page_calls;
static void *fake_shm_last_free_virt;
static int fake_shm_last_free_npages;
static int fake_shm_virt_to_phys_calls;
static uintptr_t fake_shm_virt_phys;
static int fake_shm_memset_calls;
static void *fake_shm_last_memset_dst;
static size_t fake_shm_last_memset_len;
static int fake_shm_count_inc_calls;
static int fake_shm_panic_calls;
static void *fake_shm_user_clear_obj;
static int fake_shm_user_clear_calls;
static int fake_shm_user_lock_calls;
static int fake_shm_user_unlock_calls;
static int fake_shm_user_free_calls;
static void *fake_shm_last_user_free;
static int fake_shm_user_first_calls;
static void *fake_shm_user_first_result;
static int fake_shm_user_next_calls;
static int fake_shm_user_ruid_calls;
static int fake_shm_user_init_calls;
static int fake_shm_last_user_init_ruid;
static int fake_shm_user_list_add_calls;
static int fake_shm_user_list_del_calls;
static void *fake_shm_last_user_list_arg;
static int fake_shm_first_calls;
static int fake_shm_first_index;
static void *fake_shm_pages[4];
static int fake_shm_remove_calls;
static void *fake_shm_last_removed_page;
static int fake_shm_phys_to_virt_calls;
static uintptr_t fake_shm_last_phys_to_virt;
static void *fake_shm_last_page_va;
static int fake_shm_unmap_calls;
static int fake_shm_unmap_ret;
static int fake_shm_rss_sub_calls;
static size_t fake_shm_last_rss_size;
static size_t fake_shm_last_rss_pgsize;
static int fake_shm_free_calls;
static void *fake_shm_last_free;
static int fake_shm_indexed_free_calls;
static int fake_shm_last_index_word;
static unsigned long fake_shm_last_index_mask;
static int fake_shm_destroy_dispatch_calls;
static int fake_shm_free_log_calls;
static int fake_shm_alloc_obj_calls;
static size_t fake_shm_last_alloc_obj_size;
static unsigned long fake_shm_last_alloc_obj_flags;
static void *fake_shm_alloc_obj_result;
static int fake_shm_next_seq_calls;
static int fake_shm_next_seq_value;
static int fake_shm_create_init_calls;
static void *fake_shm_last_create_obj;
static void *fake_shm_last_create_ds;
static int fake_shm_last_create_pgshift;
static size_t fake_shm_last_create_pgsize;
static size_t fake_shm_last_create_real_segsz;
static int fake_shm_last_create_seq;
static void *fake_shm_create_memobj_result;
static int fake_shm_create_log_calls;
static int fake_shm_last_create_log_event;
static int fake_shm_last_create_log_error;
static void *fake_shm_last_create_log_ds;
static void *fake_shm_last_create_log_objp;
static int fake_shm_create_callback_calls;
static int fake_shm_create_callback_result;
static void *fake_shm_create_callback_memobj;
static int fake_shm_flags_calls;
static int fake_shm_set_flags_calls;
static int fake_shm_last_set_flags;
static int fake_shm_to_shmobj_calls;
static void *fake_shm_to_shmobj_result;

static void fake_shm_reset(void)
{
	fake_shm_ref_calls = 0;
	fake_shm_unref_calls = 0;
	fake_shm_lock_calls = 0;
	fake_shm_unlock_calls = 0;
	fake_shm_lookup_calls = 0;
	fake_shm_last_lookup_off = 0;
	fake_shm_lookup_result = NULL;
	fake_shm_page_phys_calls = 0;
	fake_shm_log_calls = 0;
	fake_shm_last_log_event = 0;
	fake_shm_last_log_error = 0;
	fake_shm_last_log_phys = 0;
	fake_shm_pte_lookup_calls = 0;
	fake_shm_pte_missing_at = 0;
	fake_shm_pte_size = 4096;
	fake_shm_p2align = 0;
	fake_shm_last_pte_vaddr = NULL;
	fake_shm_insert_hash_calls = 0;
	fake_shm_last_insert_phys = 0;
	fake_shm_insert_result = NULL;
	fake_shm_list_insert_calls = 0;
	fake_shm_last_insert_obj = NULL;
	fake_shm_last_insert_page = NULL;
	fake_shm_alloc_page_calls = 0;
	fake_shm_last_alloc_npages = 0;
	fake_shm_last_alloc_p2align = 0;
	fake_shm_last_alloc_flags = 0;
	fake_shm_last_alloc_virt_addr = 0;
	fake_shm_alloc_result = NULL;
	fake_shm_free_page_calls = 0;
	fake_shm_last_free_virt = NULL;
	fake_shm_last_free_npages = 0;
	fake_shm_virt_to_phys_calls = 0;
	fake_shm_virt_phys = 0;
	fake_shm_memset_calls = 0;
	fake_shm_last_memset_dst = NULL;
	fake_shm_last_memset_len = 0;
	fake_shm_count_inc_calls = 0;
	fake_shm_panic_calls = 0;
	fake_shm_user_clear_obj = NULL;
	fake_shm_user_clear_calls = 0;
	fake_shm_user_lock_calls = 0;
	fake_shm_user_unlock_calls = 0;
	fake_shm_user_free_calls = 0;
	fake_shm_last_user_free = NULL;
	fake_shm_user_first_calls = 0;
	fake_shm_user_first_result = NULL;
	fake_shm_user_next_calls = 0;
	fake_shm_user_ruid_calls = 0;
	fake_shm_user_init_calls = 0;
	fake_shm_last_user_init_ruid = 0;
	fake_shm_user_list_add_calls = 0;
	fake_shm_user_list_del_calls = 0;
	fake_shm_last_user_list_arg = NULL;
	fake_shm_first_calls = 0;
	fake_shm_first_index = 0;
	fake_shm_pages[0] = NULL;
	fake_shm_pages[1] = NULL;
	fake_shm_pages[2] = NULL;
	fake_shm_pages[3] = NULL;
	fake_shm_remove_calls = 0;
	fake_shm_last_removed_page = NULL;
	fake_shm_phys_to_virt_calls = 0;
	fake_shm_last_phys_to_virt = 0;
	fake_shm_last_page_va = NULL;
	fake_shm_unmap_calls = 0;
	fake_shm_unmap_ret = 0;
	fake_shm_rss_sub_calls = 0;
	fake_shm_last_rss_size = 0;
	fake_shm_last_rss_pgsize = 0;
	fake_shm_free_calls = 0;
	fake_shm_last_free = NULL;
	fake_shm_indexed_free_calls = 0;
	fake_shm_last_index_word = 0;
	fake_shm_last_index_mask = 0;
	fake_shm_destroy_dispatch_calls = 0;
	fake_shm_free_log_calls = 0;
	fake_shm_alloc_obj_calls = 0;
	fake_shm_last_alloc_obj_size = 0;
	fake_shm_last_alloc_obj_flags = 0;
	fake_shm_alloc_obj_result = NULL;
	fake_shm_next_seq_calls = 0;
	fake_shm_next_seq_value = 0;
	fake_shm_create_init_calls = 0;
	fake_shm_last_create_obj = NULL;
	fake_shm_last_create_ds = NULL;
	fake_shm_last_create_pgshift = 0;
	fake_shm_last_create_pgsize = 0;
	fake_shm_last_create_real_segsz = 0;
	fake_shm_last_create_seq = 0;
	fake_shm_create_memobj_result = NULL;
	fake_shm_create_log_calls = 0;
	fake_shm_last_create_log_event = 0;
	fake_shm_last_create_log_error = 0;
	fake_shm_last_create_log_ds = NULL;
	fake_shm_last_create_log_objp = NULL;
	fake_shm_create_callback_calls = 0;
	fake_shm_create_callback_result = 0;
	fake_shm_create_callback_memobj = NULL;
	fake_shm_flags_calls = 0;
	fake_shm_set_flags_calls = 0;
	fake_shm_last_set_flags = 0;
	fake_shm_to_shmobj_calls = 0;
	fake_shm_to_shmobj_result = NULL;
}

static void fake_shm_ref(void *memobj)
{
	(void)memobj;
	fake_shm_ref_calls++;
}

static void fake_shm_unref(void *memobj)
{
	(void)memobj;
	fake_shm_unref_calls++;
}

static void fake_shm_lock(void *obj)
{
	(void)obj;
	fake_shm_lock_calls++;
}

static void fake_shm_unlock(void *obj)
{
	(void)obj;
	fake_shm_unlock_calls++;
}

static void *fake_shm_lookup(void *obj, long off)
{
	(void)obj;
	fake_shm_lookup_calls++;
	fake_shm_last_lookup_off = off;
	return fake_shm_lookup_result;
}

static uintptr_t fake_shm_page_phys(void *page)
{
	fake_shm_page_phys_calls++;
	return ((struct fake_shm_page *)page)->phys;
}

static void *fake_shm_pte_lookup(void *pt, void *vaddr, size_t *pte_sizep,
				 int *p2alignp)
{
	(void)pt;
	fake_shm_pte_lookup_calls++;
	fake_shm_last_pte_vaddr = vaddr;
	*pte_sizep = fake_shm_pte_size;
	*p2alignp = fake_shm_p2align;
	if (fake_shm_pte_missing_at == fake_shm_pte_lookup_calls)
		return NULL;
	return &fake_shm_pte_lookup_calls;
}

static int fake_shm_page_pgshift(void *page)
{
	return ((struct fake_shm_page *)page)->pgshift;
}

static void fake_shm_page_set_pgshift(void *page, int pgshift)
{
	((struct fake_shm_page *)page)->pgshift = pgshift;
}

static int fake_shm_page_mode(void *page)
{
	return ((struct fake_shm_page *)page)->mode;
}

static void fake_shm_page_set_mode(void *page, int mode)
{
	((struct fake_shm_page *)page)->mode = mode;
}

static long fake_shm_page_offset(void *page)
{
	return ((struct fake_shm_page *)page)->offset;
}

static void fake_shm_page_set_offset(void *page, long offset)
{
	((struct fake_shm_page *)page)->offset = offset;
}

static int fake_shm_page_count(void *page)
{
	return ((struct fake_shm_page *)page)->count;
}

static void fake_shm_page_set_count(void *page, int count)
{
	((struct fake_shm_page *)page)->count = count;
}

static long fake_shm_page_mapped(void *page)
{
	return ((struct fake_shm_page *)page)->mapped;
}

static void fake_shm_page_set_mapped(void *page, long mapped)
{
	((struct fake_shm_page *)page)->mapped = mapped;
}

static void *fake_shm_insert_hash(uintptr_t phys)
{
	fake_shm_insert_hash_calls++;
	fake_shm_last_insert_phys = phys;
	if (fake_shm_insert_result)
		((struct fake_shm_page *)fake_shm_insert_result)->phys = phys;
	return fake_shm_insert_result;
}

static void fake_shm_list_insert(void *obj, void *page)
{
	fake_shm_list_insert_calls++;
	fake_shm_last_insert_obj = obj;
	fake_shm_last_insert_page = page;
}

static void *fake_shm_alloc_page(int npages, int p2align,
				 unsigned long flags, uintptr_t virt_addr)
{
	fake_shm_alloc_page_calls++;
	fake_shm_last_alloc_npages = npages;
	fake_shm_last_alloc_p2align = p2align;
	fake_shm_last_alloc_flags = flags;
	fake_shm_last_alloc_virt_addr = virt_addr;
	return fake_shm_alloc_result;
}

static void fake_shm_free_page(void *virt, int npages)
{
	fake_shm_free_page_calls++;
	fake_shm_last_free_virt = virt;
	fake_shm_last_free_npages = npages;
}

static uintptr_t fake_shm_virt_to_phys(void *virt)
{
	(void)virt;
	fake_shm_virt_to_phys_calls++;
	return fake_shm_virt_phys;
}

static void *fake_shm_memset(void *dst, int value, size_t len)
{
	(void)value;
	fake_shm_memset_calls++;
	fake_shm_last_memset_dst = dst;
	fake_shm_last_memset_len = len;
	return dst;
}

static void fake_shm_count_inc(void *page)
{
	((struct fake_shm_page *)page)->count++;
	fake_shm_count_inc_calls++;
}

static void fake_shm_panic(void)
{
	fake_shm_panic_calls++;
}

static void fake_shm_user_clear(void *obj)
{
	fake_shm_user_clear_calls++;
	fake_shm_user_clear_obj = obj;
}

static size_t fake_shm_user_locked(void *user)
{
	return ((struct fake_shm_user *)user)->locked;
}

static void fake_shm_user_set_locked(void *user, size_t locked)
{
	((struct fake_shm_user *)user)->locked = locked;
}

static void fake_shm_user_lock(void *obj)
{
	(void)obj;
	fake_shm_user_lock_calls++;
}

static void fake_shm_user_unlock(void *obj)
{
	(void)obj;
	fake_shm_user_unlock_calls++;
}

static void fake_shm_user_free(void *user)
{
	fake_shm_user_free_calls++;
	fake_shm_last_user_free = user;
}

static void *fake_shm_user_first(void)
{
	fake_shm_user_first_calls++;
	return fake_shm_user_first_result;
}

static void *fake_shm_user_next(void *user)
{
	fake_shm_user_next_calls++;
	return ((struct fake_shm_user *)user)->next;
}

static int fake_shm_user_ruid(void *user)
{
	fake_shm_user_ruid_calls++;
	return ((struct fake_shm_user *)user)->ruid;
}

static void fake_shm_user_init(void *user, int ruid)
{
	fake_shm_user_init_calls++;
	fake_shm_last_user_init_ruid = ruid;
	((struct fake_shm_user *)user)->ruid = ruid;
	((struct fake_shm_user *)user)->locked = 0;
}

static void fake_shm_user_list_add(void *user)
{
	fake_shm_user_list_add_calls++;
	fake_shm_last_user_list_arg = user;
}

static void fake_shm_user_list_del(void *user)
{
	fake_shm_user_list_del_calls++;
	fake_shm_last_user_list_arg = user;
}

static void *fake_shm_page_first(void *obj)
{
	(void)obj;
	fake_shm_first_calls++;
	return fake_shm_pages[fake_shm_first_index++];
}

static void fake_shm_page_remove(void *obj, void *page)
{
	(void)obj;
	fake_shm_remove_calls++;
	fake_shm_last_removed_page = page;
}

static void *fake_shm_phys_to_virt(uintptr_t phys)
{
	fake_shm_phys_to_virt_calls++;
	fake_shm_last_phys_to_virt = phys;
	fake_shm_last_page_va = (void *)(phys + 0x1000UL);
	return fake_shm_last_page_va;
}

static int fake_shm_page_unmap(void *page)
{
	(void)page;
	fake_shm_unmap_calls++;
	return fake_shm_unmap_ret;
}

static void fake_shm_rss_sub(size_t size, size_t pgsize)
{
	fake_shm_rss_sub_calls++;
	fake_shm_last_rss_size = size;
	fake_shm_last_rss_pgsize = pgsize;
}

static void fake_shm_free(void *ptr)
{
	fake_shm_free_calls++;
	fake_shm_last_free = ptr;
}

static void fake_shm_indexed_free(void *obj, int word, unsigned long mask)
{
	fake_shm_indexed_free_calls++;
	fake_shm_last_free = obj;
	fake_shm_last_index_word = word;
	fake_shm_last_index_mask = mask;
}

static void fake_shm_destroy_dispatch(void *obj)
{
	(void)obj;
	fake_shm_destroy_dispatch_calls++;
}

static void fake_shm_log(int event, void *memobj, long off, int p2align,
			 void *physp, int error, uintptr_t phys)
{
	(void)memobj;
	(void)off;
	(void)p2align;
	(void)physp;
	fake_shm_log_calls++;
	fake_shm_last_log_event = event;
	fake_shm_last_log_error = error;
	fake_shm_last_log_phys = phys;
}

static void fake_shm_update_log(int event, void *memobj, void *pt,
				void *orig_page, void *vaddr, int error)
{
	(void)memobj;
	(void)pt;
	(void)orig_page;
	(void)vaddr;
	fake_shm_log_calls++;
	fake_shm_last_log_event = event;
	fake_shm_last_log_error = error;
}

static void fake_shm_get_log(int event, void *memobj, long off, int p2align,
			     void *physp, int error, void *page,
			     uintptr_t phys)
{
	(void)memobj;
	(void)off;
	(void)p2align;
	(void)physp;
	(void)page;
	fake_shm_log_calls++;
	fake_shm_last_log_event = event;
	fake_shm_last_log_error = error;
	fake_shm_last_log_phys = phys;
}

static void fake_shm_destroy_log(int event, void *obj, void *page,
				 uintptr_t phys, size_t size, size_t pgsize)
{
	(void)obj;
	(void)page;
	fake_shm_log_calls++;
	fake_shm_last_log_event = event;
	fake_shm_last_log_phys = phys;
	fake_shm_last_rss_size = size;
	fake_shm_last_rss_pgsize = pgsize;
}

static void fake_shm_free_log(int event, void *memobj)
{
	(void)memobj;
	fake_shm_free_log_calls++;
	fake_shm_last_log_event = event;
}

static void *fake_shm_alloc_obj(size_t size, unsigned long flags)
{
	fake_shm_alloc_obj_calls++;
	fake_shm_last_alloc_obj_size = size;
	fake_shm_last_alloc_obj_flags = flags;
	return fake_shm_alloc_obj_result;
}

static int fake_shm_next_seq(void)
{
	fake_shm_next_seq_calls++;
	return fake_shm_next_seq_value++;
}

static void *fake_shm_create_init(void *obj, void *ds, int pgshift,
				  size_t pgsize, size_t real_segsz, int seq)
{
	fake_shm_create_init_calls++;
	fake_shm_last_create_obj = obj;
	fake_shm_last_create_ds = ds;
	fake_shm_last_create_pgshift = pgshift;
	fake_shm_last_create_pgsize = pgsize;
	fake_shm_last_create_real_segsz = real_segsz;
	fake_shm_last_create_seq = seq;
	return fake_shm_create_memobj_result;
}

static void fake_shm_create_log(int event, void *ds, void *objp, int error)
{
	fake_shm_create_log_calls++;
	fake_shm_last_create_log_event = event;
	fake_shm_last_create_log_ds = ds;
	fake_shm_last_create_log_objp = objp;
	fake_shm_last_create_log_error = error;
}

static int fake_shm_create_callback(void *ds, void **objp)
{
	(void)ds;
	fake_shm_create_callback_calls++;
	if (!fake_shm_create_callback_result)
		*objp = fake_shm_create_callback_memobj;
	return fake_shm_create_callback_result;
}

static int fake_shm_memobj_flags(void *memobj)
{
	fake_shm_flags_calls++;
	return ((struct fake_shm_memobj *)memobj)->flags;
}

static void fake_shm_memobj_set_flags(void *memobj, int flags)
{
	fake_shm_set_flags_calls++;
	fake_shm_last_set_flags = flags;
	((struct fake_shm_memobj *)memobj)->flags = flags;
}

static void *fake_shm_to_shmobj(void *memobj)
{
	(void)memobj;
	fake_shm_to_shmobj_calls++;
	return fake_shm_to_shmobj_result;
}

struct fake_gencore_ehdr {
	unsigned char e_ident[16];
	uint16_t e_type;
	uint16_t e_machine;
	uint32_t e_version;
	uint64_t e_entry;
	uint64_t e_phoff;
	uint64_t e_shoff;
	uint32_t e_flags;
	uint16_t e_ehsize;
	uint16_t e_phentsize;
	uint16_t e_phnum;
	uint16_t e_shentsize;
	uint16_t e_shnum;
	uint16_t e_shstrndx;
};

struct fake_gencore_coretable {
	long len;
	unsigned long addr;
};

struct fake_gencore_phdr {
	uint32_t p_type;
	uint32_t p_flags;
	uint64_t p_offset;
	uint64_t p_vaddr;
	uint64_t p_paddr;
	uint64_t p_filesz;
	uint64_t p_memsz;
	uint64_t p_align;
};

struct fake_gencore_note {
	uint32_t namesz;
	uint32_t descsz;
	uint32_t type;
};

struct fake_gencore_prstatus {
	unsigned char bytes[336];
};

struct fake_gencore_prpsinfo {
	int8_t pr_state;
	int8_t pr_sname;
	int8_t pr_zomb;
	int8_t pr_nice;
	uint64_t pr_flag;
	uint32_t pr_uid;
	uint32_t pr_gid;
	int32_t pr_pid;
	int32_t pr_ppid;
	int32_t pr_pgrp;
	int32_t pr_sid;
	int8_t pr_fname[16];
	int8_t pr_psargs[80];
};

struct fake_gencore_range {
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	long objoff;
	int next;
};

struct fake_gencore_thread {
	int tid;
	void *regs;
	int next;
};

static struct fake_gencore_range fake_gencore_ranges[4];
static struct fake_gencore_thread fake_gencore_threads[4];
static int fake_gencore_lookup_calls;
static int fake_gencore_next_calls;
static int fake_gencore_first_thread_calls;
static int fake_gencore_next_thread_calls;
static int fake_gencore_arch_size_calls;
static int fake_gencore_fill_prstatus_note_calls;
static void *fake_gencore_fill_prstatus_note_ptr[4];
static void *fake_gencore_fill_prstatus_thread[4];
static int fake_gencore_fill_prstatus_sig[4];
static int fake_gencore_arch_fill_calls;
static void *fake_gencore_arch_fill_note_ptr[4];
static void *fake_gencore_arch_fill_thread[4];
static void *fake_gencore_arch_fill_regs[4];
static int fake_gencore_fill_prpsinfo_note_calls;
static void *fake_gencore_fill_prpsinfo_note_ptr[4];
static void *fake_gencore_fill_prpsinfo_proc[4];
static char *fake_gencore_fill_prpsinfo_cmdline[4];
static int fake_gencore_fill_auxv_note_calls;
static void *fake_gencore_fill_auxv_note_ptr[4];
static void *fake_gencore_fill_auxv_proc[4];
static int fake_gencore_range_log_calls;
static unsigned long fake_gencore_range_log_start[8];
static unsigned long fake_gencore_range_log_end[8];
static unsigned long fake_gencore_range_log_flag[8];
static long fake_gencore_range_log_objoff[8];

static int fake_gencore_phys_to_virt_calls;
static unsigned long fake_gencore_last_phys;
static unsigned long fake_gencore_phys_log[4];
static int fake_gencore_free_calls;
static void *fake_gencore_last_free;
static void *fake_gencore_free_log[4];
static int fake_gencore_arch_prstatus_calls;
static void *fake_gencore_last_prstatus;
static void *fake_gencore_last_thread;
static void *fake_gencore_last_regs;
static int fake_gencore_last_sig;
static int fake_gencore_pt_calls;
static unsigned long fake_gencore_pt_base;
static unsigned long fake_gencore_pt_missing_mask;
static unsigned long fake_gencore_pt_error_addr;
static int fake_gencore_pt_error_code;
static unsigned long fake_gencore_pt_log[8];
static int fake_gencore_coretable_log_calls;
static int fake_gencore_coretable_log_index[8];
static long fake_gencore_coretable_log_len[8];
static unsigned long fake_gencore_coretable_log_addr[8];
static unsigned long fake_gencore_coretable_log_start[8];
static struct fake_gencore_ehdr fake_gencore_ehdr_storage;
static struct fake_gencore_phdr fake_gencore_phdr_storage[4];
static unsigned long fake_gencore_note_storage[1024];
static struct fake_gencore_coretable fake_gencore_coretable_storage[16];
static int fake_gencore_alloc_calls;
static int fake_gencore_alloc_fail_call;
static size_t fake_gencore_alloc_size[4];
static unsigned long fake_gencore_alloc_flags[4];
static int fake_gencore_zero_calls;
static void *fake_gencore_zero_ptr[4];
static size_t fake_gencore_zero_size[4];
static int fake_gencore_get_note_size_calls;
static int fake_gencore_get_note_size_value;
static int fake_gencore_fill_note_calls;
static void *fake_gencore_last_fill_note_proc;
static char *fake_gencore_last_fill_note_cmdline;
static int fake_gencore_last_fill_note_sig;
static int fake_gencore_alloc_error_log_calls;
static int fake_gencore_last_alloc_error_stage;
static int fake_gencore_pt_error_log_calls;
static unsigned long fake_gencore_last_pt_error_start;
static int fake_gencore_last_pt_error_code;

static void fake_gencore_reset(void)
{
	fake_gencore_phys_to_virt_calls = 0;
	fake_gencore_last_phys = 0;
	fake_gencore_phys_log[0] = 0;
	fake_gencore_phys_log[1] = 0;
	fake_gencore_phys_log[2] = 0;
	fake_gencore_phys_log[3] = 0;
	fake_gencore_free_calls = 0;
	fake_gencore_last_free = NULL;
	fake_gencore_free_log[0] = NULL;
	fake_gencore_free_log[1] = NULL;
	fake_gencore_free_log[2] = NULL;
	fake_gencore_free_log[3] = NULL;
	fake_gencore_arch_prstatus_calls = 0;
	fake_gencore_last_prstatus = NULL;
	fake_gencore_last_thread = NULL;
	fake_gencore_last_regs = NULL;
	fake_gencore_last_sig = 0;
	fake_gencore_pt_calls = 0;
	fake_gencore_pt_base = 0x4000UL;
	fake_gencore_pt_missing_mask = 0;
	fake_gencore_pt_error_addr = 0;
	fake_gencore_pt_error_code = 0;
	for (int i = 0; i < 8; i++) {
		fake_gencore_pt_log[i] = 0;
		fake_gencore_range_log_start[i] = 0;
		fake_gencore_range_log_end[i] = 0;
		fake_gencore_range_log_flag[i] = 0;
		fake_gencore_range_log_objoff[i] = 0;
		fake_gencore_coretable_log_index[i] = 0;
		fake_gencore_coretable_log_len[i] = 0;
		fake_gencore_coretable_log_addr[i] = 0;
		fake_gencore_coretable_log_start[i] = 0;
	}
	fake_gencore_lookup_calls = 0;
	fake_gencore_next_calls = 0;
	fake_gencore_first_thread_calls = 0;
	fake_gencore_next_thread_calls = 0;
	fake_gencore_arch_size_calls = 0;
	fake_gencore_fill_prstatus_note_calls = 0;
	fake_gencore_arch_fill_calls = 0;
	fake_gencore_fill_prpsinfo_note_calls = 0;
	fake_gencore_fill_auxv_note_calls = 0;
	fake_gencore_range_log_calls = 0;
	fake_gencore_coretable_log_calls = 0;
	fake_gencore_alloc_calls = 0;
	fake_gencore_alloc_fail_call = 0;
	fake_gencore_zero_calls = 0;
	fake_gencore_get_note_size_calls = 0;
	fake_gencore_get_note_size_value = 300;
	fake_gencore_fill_note_calls = 0;
	fake_gencore_last_fill_note_proc = NULL;
	fake_gencore_last_fill_note_cmdline = NULL;
	fake_gencore_last_fill_note_sig = 0;
	fake_gencore_alloc_error_log_calls = 0;
	fake_gencore_last_alloc_error_stage = -1;
	fake_gencore_pt_error_log_calls = 0;
	fake_gencore_last_pt_error_start = 0;
	fake_gencore_last_pt_error_code = 0;
	memset(&fake_gencore_ehdr_storage, 0xcc,
	       sizeof(fake_gencore_ehdr_storage));
	memset(fake_gencore_phdr_storage, 0xcc,
	       sizeof(fake_gencore_phdr_storage));
	memset(fake_gencore_note_storage, 0xcc,
	       sizeof(fake_gencore_note_storage));
	memset(fake_gencore_coretable_storage, 0xcc,
	       sizeof(fake_gencore_coretable_storage));
	for (int i = 0; i < 4; i++) {
		fake_gencore_alloc_size[i] = 0;
		fake_gencore_alloc_flags[i] = 0;
		fake_gencore_zero_ptr[i] = NULL;
		fake_gencore_zero_size[i] = 0;
		fake_gencore_fill_prstatus_note_ptr[i] = NULL;
		fake_gencore_fill_prstatus_thread[i] = NULL;
		fake_gencore_fill_prstatus_sig[i] = 0;
		fake_gencore_arch_fill_note_ptr[i] = NULL;
		fake_gencore_arch_fill_thread[i] = NULL;
		fake_gencore_arch_fill_regs[i] = NULL;
		fake_gencore_fill_prpsinfo_note_ptr[i] = NULL;
		fake_gencore_fill_prpsinfo_proc[i] = NULL;
		fake_gencore_fill_prpsinfo_cmdline[i] = NULL;
		fake_gencore_fill_auxv_note_ptr[i] = NULL;
		fake_gencore_fill_auxv_proc[i] = NULL;
	}
}

static void fake_gencore_range_setup(void)
{
	fake_gencore_ranges[0].start = 0x4000UL;
	fake_gencore_ranges[0].end = 0x9000UL;
	fake_gencore_ranges[0].flag = 0x1000UL | 0x00010000UL | 0x00020000UL;
	fake_gencore_ranges[0].objoff = 0x10;
	fake_gencore_ranges[0].next = 1;
	fake_gencore_ranges[1].start = 0xa000UL;
	fake_gencore_ranges[1].end = 0xb000UL;
	fake_gencore_ranges[1].flag = 0x2UL;
	fake_gencore_ranges[1].objoff = 0x20;
	fake_gencore_ranges[1].next = 2;
	fake_gencore_ranges[2].start = 0xc000UL;
	fake_gencore_ranges[2].end = 0xe000UL;
	fake_gencore_ranges[2].flag = 0x00010000UL | 0x00040000UL;
	fake_gencore_ranges[2].objoff = 0x30;
	fake_gencore_ranges[2].next = -1;
}

static void fake_gencore_thread_setup(void)
{
	fake_gencore_threads[0].tid = 20;
	fake_gencore_threads[0].regs = (void *)0x2000UL;
	fake_gencore_threads[0].next = 1;
	fake_gencore_threads[1].tid = 10;
	fake_gencore_threads[1].regs = (void *)0x3000UL;
	fake_gencore_threads[1].next = 2;
	fake_gencore_threads[2].tid = 30;
	fake_gencore_threads[2].regs = (void *)0x4000UL;
	fake_gencore_threads[2].next = -1;
}

static void *fake_gencore_lookup_range(void *vm)
{
	(void)vm;
	fake_gencore_lookup_calls++;
	return &fake_gencore_ranges[0];
}

static void *fake_gencore_next_range(void *vm, void *range)
{
	struct fake_gencore_range *fake = range;

	(void)vm;
	fake_gencore_next_calls++;
	if (fake->next < 0)
		return NULL;
	return &fake_gencore_ranges[fake->next];
}

static void *fake_gencore_first_thread(void *proc)
{
	(void)proc;
	fake_gencore_first_thread_calls++;
	return &fake_gencore_threads[0];
}

static void *fake_gencore_next_thread(void *proc, void *thread)
{
	struct fake_gencore_thread *fake = thread;

	(void)proc;
	fake_gencore_next_thread_calls++;
	if (fake->next < 0)
		return NULL;
	return &fake_gencore_threads[fake->next];
}

static int fake_gencore_thread_tid(void *thread)
{
	return ((struct fake_gencore_thread *)thread)->tid;
}

static void *fake_gencore_thread_regs(void *thread)
{
	return ((struct fake_gencore_thread *)thread)->regs;
}

static int fake_gencore_arch_thread_info_size(void)
{
	fake_gencore_arch_size_calls++;
	return 32;
}

static void fake_gencore_fill_prstatus_note(void *note, void *thread, int sig)
{
	if (fake_gencore_fill_prstatus_note_calls < 4) {
		fake_gencore_fill_prstatus_note_ptr[fake_gencore_fill_prstatus_note_calls] =
			note;
		fake_gencore_fill_prstatus_thread[fake_gencore_fill_prstatus_note_calls] =
			thread;
		fake_gencore_fill_prstatus_sig[fake_gencore_fill_prstatus_note_calls] =
			sig;
	}
	fake_gencore_fill_prstatus_note_calls++;
	((unsigned char *)note)[0] = 0xa1;
}

static void fake_gencore_arch_fill_thread_info(void *note, void *thread,
					       void *regs)
{
	if (fake_gencore_arch_fill_calls < 4) {
		fake_gencore_arch_fill_note_ptr[fake_gencore_arch_fill_calls] =
			note;
		fake_gencore_arch_fill_thread[fake_gencore_arch_fill_calls] =
			thread;
		fake_gencore_arch_fill_regs[fake_gencore_arch_fill_calls] =
			regs;
	}
	fake_gencore_arch_fill_calls++;
	((unsigned char *)note)[0] = 0xb2;
}

static void fake_gencore_fill_prpsinfo_note(void *note, void *proc,
					    char *cmdline)
{
	if (fake_gencore_fill_prpsinfo_note_calls < 4) {
		fake_gencore_fill_prpsinfo_note_ptr[fake_gencore_fill_prpsinfo_note_calls] =
			note;
		fake_gencore_fill_prpsinfo_proc[fake_gencore_fill_prpsinfo_note_calls] =
			proc;
		fake_gencore_fill_prpsinfo_cmdline[fake_gencore_fill_prpsinfo_note_calls] =
			cmdline;
	}
	fake_gencore_fill_prpsinfo_note_calls++;
	((unsigned char *)note)[0] = 0xc3;
}

static void fake_gencore_fill_auxv_note(void *note, void *proc)
{
	if (fake_gencore_fill_auxv_note_calls < 4) {
		fake_gencore_fill_auxv_note_ptr[fake_gencore_fill_auxv_note_calls] =
			note;
		fake_gencore_fill_auxv_proc[fake_gencore_fill_auxv_note_calls] =
			proc;
	}
	fake_gencore_fill_auxv_note_calls++;
	((unsigned char *)note)[0] = 0xd4;
}

static unsigned long fake_gencore_range_start(void *range)
{
	return ((struct fake_gencore_range *)range)->start;
}

static unsigned long fake_gencore_range_end(void *range)
{
	return ((struct fake_gencore_range *)range)->end;
}

static unsigned long fake_gencore_range_flag(void *range)
{
	return ((struct fake_gencore_range *)range)->flag;
}

static long fake_gencore_range_objoff(void *range)
{
	return ((struct fake_gencore_range *)range)->objoff;
}

static void fake_gencore_range_log(unsigned long start, unsigned long end,
				   unsigned long flag, long objoff)
{
	if (fake_gencore_range_log_calls < 8) {
		fake_gencore_range_log_start[fake_gencore_range_log_calls] =
			start;
		fake_gencore_range_log_end[fake_gencore_range_log_calls] =
			end;
		fake_gencore_range_log_flag[fake_gencore_range_log_calls] =
			flag;
		fake_gencore_range_log_objoff[fake_gencore_range_log_calls] =
			objoff;
	}
	fake_gencore_range_log_calls++;
}

static void *fake_gencore_phys_to_virt(unsigned long phys)
{
	fake_gencore_phys_to_virt_calls++;
	fake_gencore_last_phys = phys;
	if (fake_gencore_phys_to_virt_calls <= 4)
		fake_gencore_phys_log[fake_gencore_phys_to_virt_calls - 1] =
			phys;
	return (void *)(phys + 0x1000UL);
}

static void fake_gencore_free(void *ptr)
{
	fake_gencore_free_calls++;
	fake_gencore_last_free = ptr;
	if (fake_gencore_free_calls <= 4)
		fake_gencore_free_log[fake_gencore_free_calls - 1] = ptr;
}

static void *fake_gencore_alloc(size_t size, unsigned long flags)
{
	void *ptr = NULL;

	fake_gencore_alloc_calls++;
	if (fake_gencore_alloc_calls <= 4) {
		fake_gencore_alloc_size[fake_gencore_alloc_calls - 1] =
			size;
		fake_gencore_alloc_flags[fake_gencore_alloc_calls - 1] =
			flags;
	}
	if (fake_gencore_alloc_fail_call == fake_gencore_alloc_calls)
		return NULL;

	switch (fake_gencore_alloc_calls) {
	case 1:
		ptr = &fake_gencore_ehdr_storage;
		break;
	case 2:
		ptr = fake_gencore_phdr_storage;
		break;
	case 3:
		ptr = fake_gencore_note_storage;
		break;
	case 4:
		ptr = fake_gencore_coretable_storage;
		break;
	default:
		break;
	}
	return ptr;
}

static void fake_gencore_zero(void *ptr, size_t size)
{
	if (fake_gencore_zero_calls < 4) {
		fake_gencore_zero_ptr[fake_gencore_zero_calls] = ptr;
		fake_gencore_zero_size[fake_gencore_zero_calls] = size;
	}
	fake_gencore_zero_calls++;
	memset(ptr, 0, size);
}

static int fake_gencore_get_note_size(void *proc)
{
	(void)proc;
	fake_gencore_get_note_size_calls++;
	return fake_gencore_get_note_size_value;
}

static void fake_gencore_fill_note(void *note, void *proc, char *cmdline,
				   int sig)
{
	fake_gencore_fill_note_calls++;
	fake_gencore_last_fill_note_proc = proc;
	fake_gencore_last_fill_note_cmdline = cmdline;
	fake_gencore_last_fill_note_sig = sig;
	((unsigned char *)note)[0] = 0x77;
	((unsigned char *)note)[fake_gencore_get_note_size_value - 1] = 0x88;
}

static void fake_gencore_alloc_error_log(int stage)
{
	fake_gencore_alloc_error_log_calls++;
	fake_gencore_last_alloc_error_stage = stage;
}

static void fake_gencore_pt_error_log(unsigned long start, int error)
{
	fake_gencore_pt_error_log_calls++;
	fake_gencore_last_pt_error_start = start;
	fake_gencore_last_pt_error_code = error;
}

static void fake_gencore_arch_fill_prstatus(void *prstatus, void *thread,
					    void *regs, int sig)
{
	struct fake_gencore_prstatus *fake = prstatus;

	fake_gencore_arch_prstatus_calls++;
	fake_gencore_last_prstatus = prstatus;
	fake_gencore_last_thread = thread;
	fake_gencore_last_regs = regs;
	fake_gencore_last_sig = sig;
	fake->bytes[0] = 0x5a;
	fake->bytes[335] = 0xa5;
}

static int fake_gencore_pt_virt_to_phys(void *page_table,
					unsigned long vaddr,
					unsigned long *phys)
{
	unsigned long page;

	(void)page_table;
	if (fake_gencore_pt_calls < 8)
		fake_gencore_pt_log[fake_gencore_pt_calls] = vaddr;
	fake_gencore_pt_calls++;
	if (vaddr == fake_gencore_pt_error_addr)
		return fake_gencore_pt_error_code;
	page = (vaddr - fake_gencore_pt_base) / 4096UL;
	if (fake_gencore_pt_missing_mask & (1UL << page))
		return -14;
	*phys = 0x900000UL + page * 4096UL;
	return 0;
}

static unsigned long fake_gencore_virt_to_phys(unsigned long vaddr)
{
	return vaddr + 0xabc000UL;
}

static void fake_gencore_coretable_log(int index, long len,
				       unsigned long addr, unsigned long start)
{
	if (fake_gencore_coretable_log_calls < 8) {
		fake_gencore_coretable_log_index[fake_gencore_coretable_log_calls] =
			index;
		fake_gencore_coretable_log_len[fake_gencore_coretable_log_calls] =
			len;
		fake_gencore_coretable_log_addr[fake_gencore_coretable_log_calls] =
			addr;
		fake_gencore_coretable_log_start[fake_gencore_coretable_log_calls] =
			start;
	}
	fake_gencore_coretable_log_calls++;
}

static int fake_huge_lock_calls;
static int fake_huge_unlock_calls;
static int fake_huge_del_calls;
static int fake_huge_free_calls;
static int fake_huge_empty_calls;
static int fake_huge_first_calls;
static int fake_huge_empty_after;
static int fake_huge_first_index;
static void *fake_huge_items[4];
static void *fake_huge_last_lock;
static void *fake_huge_last_unlock;
static void *fake_huge_last_del;
static void *fake_huge_last_free;
static int fake_huge_alloc_calls;
static int fake_huge_alloc_page_calls;
static int fake_huge_free_page_calls;
static int fake_huge_clear_path_calls;
static int fake_huge_set_page_calls;
static int fake_huge_memcpy_calls;
static int fake_huge_memset_calls;
static int fake_huge_phys_calls;
static int fake_huge_set_nr_pages_calls;
static int fake_huge_set_pages_calls;
static int fake_huge_set_size_calls;
static int fake_huge_lookup_calls;
static int fake_huge_lookup_first_calls;
static int fake_huge_lookup_next_calls;
static int fake_huge_ref_calls;
static int fake_huge_dec_calls;
static int fake_huge_to_memobj_calls;
static int fake_huge_set_handle_calls;
static int fake_huge_set_pgsize_calls;
static int fake_huge_set_pgshift_calls;
static int fake_huge_init_lock_calls;
static int fake_huge_set_flags_calls;
static int fake_huge_set_status_calls;
static int fake_huge_set_ops_calls;
static int fake_huge_set_refcnt_calls;
static int fake_huge_set_path_calls;
static int fake_huge_copy_path_calls;
static int fake_huge_list_add_calls;
static int fake_huge_pre_log_calls;
static int fake_huge_alloc_error_calls;
static int fake_huge_log_calls;
static size_t fake_huge_last_alloc_size;
static size_t fake_huge_alloc_size_log[4];
static unsigned long fake_huge_last_alloc_flags;
static unsigned long fake_huge_alloc_flags_log[4];
static int fake_huge_last_alloc_npages;
static int fake_huge_last_alloc_p2align;
static uintptr_t fake_huge_last_alloc_virt;
static void *fake_huge_alloc_result;
static void *fake_huge_alloc_results[4];
static void *fake_huge_alloc_page_result;
static void *fake_huge_last_free_page;
static int fake_huge_last_free_npages;
static long fake_huge_last_set_index;
static void *fake_huge_last_set_page;
static void *fake_huge_last_memcpy_dst;
static const void *fake_huge_last_memcpy_src;
static size_t fake_huge_last_memcpy_len;
static void *fake_huge_last_memset_dst;
static int fake_huge_last_memset_value;
static size_t fake_huge_last_memset_len;
static size_t fake_huge_last_nr_pages;
static void *fake_huge_last_pages;
static size_t fake_huge_last_size;
static uintptr_t fake_huge_last_lookup_handle;
static int fake_huge_ref_results[4];
static void *fake_huge_last_ref_obj;
static void *fake_huge_last_dec_obj;
static void *fake_huge_lookup_result;
static void *fake_huge_last_to_memobj;
static void *fake_huge_to_memobj_result;
static uintptr_t fake_huge_last_handle;
static int fake_huge_last_pgshift;
static unsigned int fake_huge_last_flags;
static int fake_huge_last_status;
static void *fake_huge_last_ops;
static int fake_huge_last_refcnt;
static void *fake_huge_last_path;
static void *fake_huge_last_copy_dst;
static const void *fake_huge_last_copy_src;
static size_t fake_huge_last_copy_len;
static void *fake_huge_last_list_add;
static int fake_huge_last_pre_log_event;
static void *fake_huge_last_pre_log_obj;
static int fake_huge_last_alloc_error_stage;
static int fake_huge_last_log_event;
static long fake_huge_last_log_off;
static long fake_huge_last_log_index;
static size_t fake_huge_last_log_pgsize;
static uintptr_t fake_huge_last_log_virt;

struct fake_huge_obj {
	void *slots[8];
	void *pages;
	size_t nr_pages;
	size_t size;
	uintptr_t handle;
	size_t pgsize;
	int pgshift;
	unsigned int flags;
	int status;
	void *ops;
	int refcnt;
	void *path;
	int lock_initialized;
	int listed;
};

static void fake_huge_reset(void)
{
	fake_huge_lock_calls = 0;
	fake_huge_unlock_calls = 0;
	fake_huge_del_calls = 0;
	fake_huge_free_calls = 0;
	fake_huge_empty_calls = 0;
	fake_huge_first_calls = 0;
	fake_huge_empty_after = 0;
	fake_huge_first_index = 0;
	fake_huge_items[0] = NULL;
	fake_huge_items[1] = NULL;
	fake_huge_items[2] = NULL;
	fake_huge_items[3] = NULL;
	fake_huge_last_lock = NULL;
	fake_huge_last_unlock = NULL;
	fake_huge_last_del = NULL;
	fake_huge_last_free = NULL;
	fake_huge_alloc_calls = 0;
	fake_huge_alloc_page_calls = 0;
	fake_huge_free_page_calls = 0;
	fake_huge_clear_path_calls = 0;
	fake_huge_set_page_calls = 0;
	fake_huge_memcpy_calls = 0;
	fake_huge_memset_calls = 0;
	fake_huge_phys_calls = 0;
	fake_huge_set_nr_pages_calls = 0;
	fake_huge_set_pages_calls = 0;
	fake_huge_set_size_calls = 0;
	fake_huge_lookup_calls = 0;
	fake_huge_lookup_first_calls = 0;
	fake_huge_lookup_next_calls = 0;
	fake_huge_ref_calls = 0;
	fake_huge_dec_calls = 0;
	fake_huge_to_memobj_calls = 0;
	fake_huge_set_handle_calls = 0;
	fake_huge_set_pgsize_calls = 0;
	fake_huge_set_pgshift_calls = 0;
	fake_huge_init_lock_calls = 0;
	fake_huge_set_flags_calls = 0;
	fake_huge_set_status_calls = 0;
	fake_huge_set_ops_calls = 0;
	fake_huge_set_refcnt_calls = 0;
	fake_huge_set_path_calls = 0;
	fake_huge_copy_path_calls = 0;
	fake_huge_list_add_calls = 0;
	fake_huge_pre_log_calls = 0;
	fake_huge_alloc_error_calls = 0;
	fake_huge_log_calls = 0;
	fake_huge_last_alloc_size = 0;
	fake_huge_last_alloc_flags = 0;
	for (int i = 0; i < 4; i++) {
		fake_huge_alloc_size_log[i] = 0;
		fake_huge_alloc_flags_log[i] = 0;
		fake_huge_alloc_results[i] = NULL;
	}
	fake_huge_last_alloc_npages = 0;
	fake_huge_last_alloc_p2align = 0;
	fake_huge_last_alloc_virt = 0;
	fake_huge_alloc_result = NULL;
	fake_huge_alloc_page_result = NULL;
	fake_huge_last_free_page = NULL;
	fake_huge_last_free_npages = 0;
	fake_huge_last_set_index = 0;
	fake_huge_last_set_page = NULL;
	fake_huge_last_memcpy_dst = NULL;
	fake_huge_last_memcpy_src = NULL;
	fake_huge_last_memcpy_len = 0;
	fake_huge_last_memset_dst = NULL;
	fake_huge_last_memset_value = 0;
	fake_huge_last_memset_len = 0;
	fake_huge_last_nr_pages = 0;
	fake_huge_last_pages = NULL;
	fake_huge_last_size = 0;
	fake_huge_last_lookup_handle = 0;
	for (int i = 0; i < 4; i++)
		fake_huge_ref_results[i] = 0;
	fake_huge_last_ref_obj = NULL;
	fake_huge_last_dec_obj = NULL;
	fake_huge_lookup_result = NULL;
	fake_huge_last_to_memobj = NULL;
	fake_huge_to_memobj_result = NULL;
	fake_huge_last_handle = 0;
	fake_huge_last_pgshift = 0;
	fake_huge_last_flags = 0;
	fake_huge_last_status = 0;
	fake_huge_last_ops = NULL;
	fake_huge_last_refcnt = 0;
	fake_huge_last_path = NULL;
	fake_huge_last_copy_dst = NULL;
	fake_huge_last_copy_src = NULL;
	fake_huge_last_copy_len = 0;
	fake_huge_last_list_add = NULL;
	fake_huge_last_pre_log_event = 0;
	fake_huge_last_pre_log_obj = NULL;
	fake_huge_last_alloc_error_stage = 0;
	fake_huge_last_log_event = 0;
	fake_huge_last_log_off = 0;
	fake_huge_last_log_index = 0;
	fake_huge_last_log_pgsize = 0;
	fake_huge_last_log_virt = 0;
}

static void fake_huge_lock(void *lock)
{
	fake_huge_lock_calls++;
	fake_huge_last_lock = lock;
}

static void fake_huge_unlock(void *lock)
{
	fake_huge_unlock_calls++;
	fake_huge_last_unlock = lock;
}

static int fake_huge_list_empty(void *head)
{
	(void)head;
	fake_huge_empty_calls++;
	return fake_huge_first_index >= fake_huge_empty_after;
}

static void *fake_huge_first(void *head)
{
	(void)head;
	fake_huge_first_calls++;
	return fake_huge_items[fake_huge_first_index++];
}

static void fake_huge_list_del(void *obj)
{
	fake_huge_del_calls++;
	fake_huge_last_del = obj;
}

static void fake_huge_free(void *obj)
{
	fake_huge_free_calls++;
	fake_huge_last_free = obj;
}

static void *fake_huge_alloc(size_t size, unsigned long flags)
{
	fake_huge_alloc_calls++;
	fake_huge_last_alloc_size = size;
	fake_huge_last_alloc_flags = flags;
	if (fake_huge_alloc_calls <= 4) {
		fake_huge_alloc_size_log[fake_huge_alloc_calls - 1] = size;
		fake_huge_alloc_flags_log[fake_huge_alloc_calls - 1] = flags;
		if (fake_huge_alloc_results[fake_huge_alloc_calls - 1])
			return fake_huge_alloc_results[
				fake_huge_alloc_calls - 1];
	}
	return fake_huge_alloc_result;
}

static void *fake_huge_alloc_page(int npages, int p2align,
				  unsigned long flags, uintptr_t virt_addr)
{
	fake_huge_alloc_page_calls++;
	fake_huge_last_alloc_npages = npages;
	fake_huge_last_alloc_p2align = p2align;
	fake_huge_last_alloc_flags = flags;
	fake_huge_last_alloc_virt = virt_addr;
	return fake_huge_alloc_page_result;
}

static void fake_huge_free_page(void *page, int npages)
{
	fake_huge_free_page_calls++;
	fake_huge_last_free_page = page;
	fake_huge_last_free_npages = npages;
}

static void *fake_huge_page_at(void *obj, long index)
{
	return ((struct fake_huge_obj *)obj)->slots[index];
}

static void fake_huge_set_page(void *obj, long index, void *page)
{
	fake_huge_set_page_calls++;
	fake_huge_last_set_index = index;
	fake_huge_last_set_page = page;
	((struct fake_huge_obj *)obj)->slots[index] = page;
}

static void fake_huge_clear_path(void *obj)
{
	(void)obj;
	fake_huge_clear_path_calls++;
}

static void *fake_huge_memcpy(void *dst, const void *src, size_t len)
{
	fake_huge_memcpy_calls++;
	fake_huge_last_memcpy_dst = dst;
	fake_huge_last_memcpy_src = src;
	fake_huge_last_memcpy_len = len;
	return dst;
}

static void *fake_huge_memset(void *dst, int value, size_t len)
{
	fake_huge_memset_calls++;
	fake_huge_last_memset_dst = dst;
	fake_huge_last_memset_value = value;
	fake_huge_last_memset_len = len;
	return dst;
}

static uintptr_t fake_huge_phys(void *addr)
{
	fake_huge_phys_calls++;
	return (uintptr_t)addr + 0x123000UL;
}

static void fake_huge_set_nr_pages(void *obj, size_t nr_pages)
{
	fake_huge_set_nr_pages_calls++;
	fake_huge_last_nr_pages = nr_pages;
	((struct fake_huge_obj *)obj)->nr_pages = nr_pages;
}

static void fake_huge_set_pages(void *obj, void *pages)
{
	fake_huge_set_pages_calls++;
	fake_huge_last_pages = pages;
	((struct fake_huge_obj *)obj)->pages = pages;
}

static void fake_huge_set_size(void *obj, size_t size)
{
	fake_huge_set_size_calls++;
	fake_huge_last_size = size;
	((struct fake_huge_obj *)obj)->size = size;
}

static void *fake_huge_lookup(uintptr_t handle)
{
	fake_huge_lookup_calls++;
	fake_huge_last_lookup_handle = handle;
	return fake_huge_lookup_result;
}

static void *fake_huge_lookup_first(void *head)
{
	(void)head;
	fake_huge_lookup_first_calls++;
	return fake_huge_items[0];
}

static void *fake_huge_lookup_next(void *head, void *obj)
{
	(void)head;
	fake_huge_lookup_next_calls++;
	for (int i = 0; i < 3; i++) {
		if (fake_huge_items[i] == obj)
			return fake_huge_items[i + 1];
	}
	return NULL;
}

static uintptr_t fake_huge_handle(void *obj)
{
	return ((struct fake_huge_obj *)obj)->handle;
}

static int fake_huge_ref(void *obj)
{
	fake_huge_ref_calls++;
	fake_huge_last_ref_obj = obj;
	if (fake_huge_ref_calls <= 4)
		return fake_huge_ref_results[fake_huge_ref_calls - 1];
	return 0;
}

static void fake_huge_dec(void *obj)
{
	fake_huge_dec_calls++;
	fake_huge_last_dec_obj = obj;
}

static void *fake_huge_to_memobj(void *obj)
{
	fake_huge_to_memobj_calls++;
	fake_huge_last_to_memobj = obj;
	return fake_huge_to_memobj_result ? fake_huge_to_memobj_result : obj;
}

static void fake_huge_set_handle(void *obj, uintptr_t handle)
{
	fake_huge_set_handle_calls++;
	fake_huge_last_handle = handle;
	((struct fake_huge_obj *)obj)->handle = handle;
}

static void fake_huge_set_pgsize(void *obj, size_t pgsize)
{
	fake_huge_set_pgsize_calls++;
	((struct fake_huge_obj *)obj)->pgsize = pgsize;
}

static void fake_huge_set_pgshift(void *obj, int pgshift)
{
	fake_huge_set_pgshift_calls++;
	fake_huge_last_pgshift = pgshift;
	((struct fake_huge_obj *)obj)->pgshift = pgshift;
}

static void fake_huge_init_lock(void *obj)
{
	fake_huge_init_lock_calls++;
	((struct fake_huge_obj *)obj)->lock_initialized = 1;
}

static void fake_huge_set_flags(void *obj, unsigned int flags)
{
	fake_huge_set_flags_calls++;
	fake_huge_last_flags = flags;
	((struct fake_huge_obj *)obj)->flags = flags;
}

static void fake_huge_set_status(void *obj, int status)
{
	fake_huge_set_status_calls++;
	fake_huge_last_status = status;
	((struct fake_huge_obj *)obj)->status = status;
}

static void fake_huge_set_ops(void *obj, void *ops)
{
	fake_huge_set_ops_calls++;
	fake_huge_last_ops = ops;
	((struct fake_huge_obj *)obj)->ops = ops;
}

static void fake_huge_set_refcnt(void *obj, int refcnt)
{
	fake_huge_set_refcnt_calls++;
	fake_huge_last_refcnt = refcnt;
	((struct fake_huge_obj *)obj)->refcnt = refcnt;
}

static void fake_huge_set_path(void *obj, void *path)
{
	fake_huge_set_path_calls++;
	fake_huge_last_path = path;
	((struct fake_huge_obj *)obj)->path = path;
}

static void fake_huge_copy_path(void *dst, const void *src, size_t len)
{
	fake_huge_copy_path_calls++;
	fake_huge_last_copy_dst = dst;
	fake_huge_last_copy_src = src;
	fake_huge_last_copy_len = len;
}

static void fake_huge_list_add(void *obj)
{
	fake_huge_list_add_calls++;
	fake_huge_last_list_add = obj;
	((struct fake_huge_obj *)obj)->listed = 1;
}

static void fake_huge_pre_log(int event, void *obj)
{
	fake_huge_pre_log_calls++;
	fake_huge_last_pre_log_event = event;
	fake_huge_last_pre_log_obj = obj;
}

static void fake_huge_alloc_error(int stage)
{
	fake_huge_alloc_error_calls++;
	fake_huge_last_alloc_error_stage = stage;
}

static void fake_huge_log(int event, void *obj, long off, long index,
			  size_t pgsize, uintptr_t virt_addr)
{
	(void)obj;
	fake_huge_log_calls++;
	fake_huge_last_log_event = event;
	fake_huge_last_log_off = off;
	fake_huge_last_log_index = index;
	fake_huge_last_log_pgsize = pgsize;
	fake_huge_last_log_virt = virt_addr;
}

__attribute__((weak)) int page_is_in_memobj(struct page *page)
{
	if (!page)
		return 0;

	return page->mode == PM_MAPPED || page->mode == PM_PAGEIO ||
	       page->mode == PM_WILL_PAGEIO || page->mode == PM_DONE_PAGEIO ||
	       page->mode == PM_PAGEIO_EOF || page->mode == PM_PAGEIO_ERROR;
}

static int fake_memobj_get_calls;
static int fake_memobj_copy_calls;
static int fake_memobj_flush_calls;
static int fake_memobj_invalidate_calls;
static int fake_memobj_lookup_calls;
static int fake_memobj_update_calls;
static struct memobj *fake_memobj_last_obj;
static long fake_memobj_last_off;
static int fake_memobj_last_p2align;
static uintptr_t fake_memobj_last_phys;
static size_t fake_memobj_last_pgsize;
static uintptr_t fake_memobj_last_virt;
static void *fake_memobj_last_pt;
static struct page *fake_memobj_last_page;
static void *fake_memobj_last_vaddr;

static int fake_memobj_get_page(struct memobj *obj, long off, int p2align,
				uintptr_t *physp, unsigned long *pflag,
				uintptr_t virt_addr)
{
	fake_memobj_get_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_off = off;
	fake_memobj_last_p2align = p2align;
	fake_memobj_last_virt = virt_addr;
	if (physp)
		*physp = virt_addr + (uintptr_t)off + ((uintptr_t)p2align << 8);
	if (pflag)
		*pflag = 0xa500UL | (unsigned long)p2align;
	return 40 + p2align;
}

static uintptr_t fake_memobj_copy_page(struct memobj *obj, uintptr_t orgphys,
				       int p2align)
{
	fake_memobj_copy_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_phys = orgphys;
	fake_memobj_last_p2align = p2align;
	return orgphys ^ ((uintptr_t)p2align << 12) ^ 0x55UL;
}

static int fake_memobj_flush_page(struct memobj *obj, uintptr_t phys,
				  size_t pgsize)
{
	fake_memobj_flush_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_phys = phys;
	fake_memobj_last_pgsize = pgsize;
	return 50 + (int)(phys & 0xf) + (int)(pgsize & 0xf);
}

static int fake_memobj_invalidate_page(struct memobj *obj, uintptr_t phys,
				       size_t pgsize)
{
	fake_memobj_invalidate_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_phys = phys;
	fake_memobj_last_pgsize = pgsize;
	return 60 + (int)(phys & 0xf) + (int)(pgsize & 0xf);
}

static int fake_memobj_lookup_page(struct memobj *obj, long off, int p2align,
				   uintptr_t *physp, unsigned long *pflag)
{
	fake_memobj_lookup_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_off = off;
	fake_memobj_last_p2align = p2align;
	if (physp)
		*physp = 0xbeef000UL + (uintptr_t)off;
	if (pflag)
		*pflag = 0x5a00UL | (unsigned long)p2align;
	return 70 + p2align;
}

static int fake_memobj_update_page(struct memobj *obj, void *pt,
				   struct page *orig_page, void *vaddr)
{
	fake_memobj_update_calls++;
	fake_memobj_last_obj = obj;
	fake_memobj_last_pt = pt;
	fake_memobj_last_page = orig_page;
	fake_memobj_last_vaddr = vaddr;
	return 80 + (orig_page ? orig_page->pgshift : 0);
}

int main(void)
{
	const long offsets[] = { -8192, -1, 0, 1, 4095, 4096, 1048576 };
	const int modes[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, -1 };
	const int flags[] = { 0, 2, 0x8, 0x10, 0x8000, 0x8010,
			      0x100000, 0x200000, 0x400000, 0x401010 };
	const unsigned int memobj_flags[] = {
		0, 0x1, 0x4, 0x10, 0x10000, 0x200000, 0x400000,
		0x11, 0x10001, 0x210010, 0x600000, 0xffffffffU,
	};
	const unsigned long mpol_flags[] = { 0, 1, 2, 4, 8, 9, 0xffffffffUL };
	const size_t sizes[] = { 0, 1, 4095, 4096, 4097, 8191,
				 8192, ~0UL - 2048 };
	const uintptr_t pfns[] = { 0, 1, 0x1001, 0x8000000000000000UL,
				   0x8000000000001001UL,
				   0x0100000000003001UL };
	const long ops[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 999, -1 };
	const int statuses[] = { 1, 2, 4, 8, 0x10, 0x20, 0x40, 0x60, 0 };
	const ssize_t io_rets[] = { -4, -1, 0, 1, 4096 };
	const unsigned long addrs[] = { 0, 1, 4095, 4096, 0x12345 };
	const int pgshifts[] = { 0, 12, 21, 30 };
	const long page_offsets[] = { 0, 1, 4096, 8192 };
	const size_t seg_sizes[] = { 0, 1, 4095, 4096, 4097, 8192 };
	const int p2aligns[] = { 0, 1, 2 };
	const int counts[] = { 0, 1, 8, 1024, 4095, 4096, 4097 };
	const int messages[] = { 0x14, 0x15, 0x3a, 0x3b, 0x3c, 0x3e, 0x40 };
	const char *procfs_names[] = {
		"", "mckernel", "stat", "cpuinfo", "mem", "maps",
		"pagemap", "status", "auxv", "cmdline", "comm",
		"unknown", "maps/", "command",
	};
	const char *cmdlines[] = {
		"", "exe", "/bin/sh", "/usr/bin/python3", "relative/path",
		"/trailing/",
	};
	const unsigned long map_flags[] = {
		0, 0x1, 0x2000, 0x10000, 0x20000, 0x40000,
		0x70000, 0x12001, 0x4000, 0x54000,
	};
	unsigned long digest = 0x0b1ec75eed5eedUL;
	unsigned long start = 0;
	unsigned long end = 0;
	uintptr_t memobj_phys = 0;
	unsigned long memobj_flag = 0;
	char pt_token;
	char vaddr_token;
	struct page memobj_mapped_page = { .mode = PM_MAPPED, .pgshift = 3 };
	struct page memobj_unmapped_page = { .mode = PM_NONE, .pgshift = 5 };
	struct memobj_ops memobj_present_ops = {
		.get_page = fake_memobj_get_page,
		.copy_page = fake_memobj_copy_page,
		.flush_page = fake_memobj_flush_page,
		.invalidate_page = fake_memobj_invalidate_page,
		.lookup_page = fake_memobj_lookup_page,
		.update_page = fake_memobj_update_page,
	};
	struct memobj_ops memobj_missing_ops = { 0 };
	struct memobj memobj_present = {
		.ops = &memobj_present_ops,
		.flags = MF_HAS_PAGER | MF_IS_REMOVABLE | MF_REMAP_FILE_PAGES,
		.refcnt = { 1 },
	};
	struct memobj memobj_not_flushable = {
		.ops = &memobj_missing_ops,
		.flags = MF_ZEROFILL | MF_PRIVATE | MF_XPMEM,
		.refcnt = { 1 },
	};
	int err = 0;
	int ix = 0;

	for (int ref = -2; ref <= 2; ref++)
		mix_signed(&digest, memobj_unref_should_free_result(ref));
	for (unsigned long ptr = 0; ptr <= 2; ptr++)
		mix_signed(&digest, memobj_op_present_result(ptr));
	mix_signed(&digest, memobj_missing_page_op_result());
	mix(&digest, memobj_missing_copy_page_result());
	mix_signed(&digest, memobj_default_page_op_result());
	for (int has_page = 0; has_page <= 1; has_page++) {
		for (int in_memobj = 0; in_memobj <= 1; in_memobj++)
			mix_signed(&digest,
				memobj_flushable_page_result(has_page, in_memobj));
	}
	for (unsigned int i = 0; i < sizeof(memobj_flags) / sizeof(memobj_flags[0]); i++) {
		for (int has_memobj = 0; has_memobj <= 1; has_memobj++) {
			mix_signed(&digest,
				memobj_flushable_obj_result(has_memobj,
					memobj_flags[i]));
			mix_signed(&digest,
				memobj_is_freeable_result(has_memobj,
					memobj_flags[i]));
			mix_signed(&digest,
				memobj_callable_remap_file_pages_result(
					has_memobj, memobj_flags[i]));
		}
		mix_signed(&digest,
			memobj_has_pager_flags_result(memobj_flags[i]));
		mix_signed(&digest,
			memobj_is_removable_flags_result(memobj_flags[i]));
	}

	mix_signed(&digest, memobj_get_page(&memobj_present, 0x34, 2,
					    &memobj_phys, &memobj_flag,
					    0x1000));
	require(fake_memobj_get_calls == 1);
	require(fake_memobj_last_obj == &memobj_present);
	require(fake_memobj_last_off == 0x34);
	require(fake_memobj_last_p2align == 2);
	require(fake_memobj_last_virt == 0x1000);
	require(memobj_phys == 0x1234);
	require(memobj_flag == 0xa502UL);
	mix(&digest, memobj_phys);
	mix(&digest, memobj_flag);

	mix(&digest, memobj_copy_page(&memobj_present, 0x12345000UL, 3));
	require(fake_memobj_copy_calls == 1);
	require(fake_memobj_last_phys == 0x12345000UL);

	mix_signed(&digest,
		memobj_flush_page(&memobj_present, 0xabcUL, 0x1000));
	require(fake_memobj_flush_calls == 1);
	require(fake_memobj_last_phys == 0xabcUL);
	require(fake_memobj_last_pgsize == 0x1000);

	mix_signed(&digest,
		memobj_invalidate_page(&memobj_present, 0x111UL, 0x2000));
	require(fake_memobj_invalidate_calls == 1);
	require(fake_memobj_last_phys == 0x111UL);
	require(fake_memobj_last_pgsize == 0x2000);

	memobj_phys = 0;
	memobj_flag = 0;
	mix_signed(&digest, memobj_lookup_page(&memobj_present, 0x44, 4,
					       &memobj_phys, &memobj_flag));
	require(fake_memobj_lookup_calls == 1);
	require(fake_memobj_last_off == 0x44);
	require(fake_memobj_last_p2align == 4);
	require(memobj_phys == 0xbeef044UL);
	require(memobj_flag == 0x5a04UL);
	mix(&digest, memobj_phys);
	mix(&digest, memobj_flag);

	mix_signed(&digest, memobj_update_page(&memobj_present, &pt_token,
					       &memobj_mapped_page,
					       &vaddr_token));
	require(fake_memobj_update_calls == 1);
	require(fake_memobj_last_pt == &pt_token);
	require(fake_memobj_last_page == &memobj_mapped_page);
	require(fake_memobj_last_vaddr == &vaddr_token);

	mix_signed(&digest, memobj_get_page(&memobj_not_flushable, 0, 0,
					    &memobj_phys, &memobj_flag, 0));
	mix(&digest, memobj_copy_page(&memobj_not_flushable, 0x1234, 1));
	mix_signed(&digest,
		memobj_flush_page(&memobj_not_flushable, 0x1234, 4096));
	mix_signed(&digest,
		memobj_invalidate_page(&memobj_not_flushable, 0x1234, 4096));
	mix_signed(&digest, memobj_lookup_page(&memobj_not_flushable, 0, 0,
					       &memobj_phys, &memobj_flag));
	mix_signed(&digest, memobj_update_page(&memobj_not_flushable, NULL,
					       NULL, NULL));
	require(fake_memobj_get_calls == 1);
	require(fake_memobj_copy_calls == 1);
	require(fake_memobj_flush_calls == 1);
	require(fake_memobj_invalidate_calls == 1);
	require(fake_memobj_lookup_calls == 1);
	require(fake_memobj_update_calls == 1);

	mix_signed(&digest, memobj_has_pager(&memobj_present));
	mix_signed(&digest, memobj_is_removable(&memobj_present));
	mix_signed(&digest, memobj_has_pager(&memobj_not_flushable));
	mix_signed(&digest, memobj_is_removable(&memobj_not_flushable));
	require(memobj_has_pager(&memobj_present) == 1);
	require(memobj_is_removable(&memobj_present) == 1);
	require(memobj_has_pager(&memobj_not_flushable) == 0);
	require(memobj_is_removable(&memobj_not_flushable) == 0);

	mix_signed(&digest, is_flushable(&memobj_mapped_page, &memobj_present));
	mix_signed(&digest, is_flushable(&memobj_unmapped_page, &memobj_present));
	mix_signed(&digest, is_flushable(&memobj_mapped_page,
					 &memobj_not_flushable));
	mix_signed(&digest, is_flushable(NULL, &memobj_present));
	mix_signed(&digest, is_freeable(NULL));
	mix_signed(&digest, is_freeable(&memobj_present));
	mix_signed(&digest, is_freeable(&memobj_not_flushable));
	mix_signed(&digest, is_callable_remap_file_pages(&memobj_present));
	mix_signed(&digest,
		is_callable_remap_file_pages(&memobj_not_flushable));
	require(is_flushable(&memobj_mapped_page, &memobj_present) == 1);
	require(is_flushable(&memobj_unmapped_page, &memobj_present) == 0);
	require(is_flushable(&memobj_mapped_page, &memobj_not_flushable) == 0);
	require(is_freeable(NULL) == 1);
	require(is_freeable(&memobj_present) == 1);
	require(is_freeable(&memobj_not_flushable) == 0);
	require(is_callable_remap_file_pages(&memobj_present) == 1);
	require(is_callable_remap_file_pages(&memobj_not_flushable) == 0);

	for (unsigned int i = 0; i < sizeof(offsets) / sizeof(offsets[0]); i++) {
		mix_signed(&digest, fileobj_page_hash_result(offsets[i]));
		mix_signed(&digest, devobj_pgoff_result(offsets[i]));
	}
	for (unsigned long sref = 0; sref <= 4; sref++)
		mix(&digest, fileobj_next_sref_result(sref));
	for (unsigned int i = 0; i < sizeof(mpol_flags) / sizeof(mpol_flags[0]); i++)
		mix_signed(&digest, fileobj_premap_interleave_result(mpol_flags[i]));

	for (unsigned int i = 0; i < sizeof(modes) / sizeof(modes[0]); i++) {
		mix_signed(&digest, fileobj_page_mode_valid_result(modes[i]));
		mix_signed(&digest, fileobj_get_page_action_result(0, modes[i], &err));
		mix_signed(&digest, err);
		mix_signed(&digest, fileobj_get_page_action_result(1, modes[i], &err));
		mix_signed(&digest, err);
	}

	for (int ref = -1; ref <= 4; ref++)
		mix_signed(&digest, fileobj_lookup_ref_keep_result(ref));

	for (unsigned int i = 0; i < sizeof(flags) / sizeof(flags[0]); i++) {
		int base = fileobj_create_base_flags_result(flags[i]);
		int applied = fileobj_apply_result_flags_result(base, flags[i]);

		mix_signed(&digest, base);
		mix_signed(&digest, applied);
		mix_signed(&digest, fileobj_status_from_flags_result(applied));
		mix_signed(&digest, fileobj_hugetlbfs_result(flags[i]));
		mix_signed(&digest, fileobj_premap_zerofill_result(flags[i]));
		mix_signed(&digest, fileobj_pageio_zero_result(flags[i]));
		mix_signed(&digest, fileobj_flush_skip_result(flags[i], 0));
		mix_signed(&digest, fileobj_flush_skip_result(flags[i], 1));
		mix(&digest, fileobj_alloc_flags_result(flags[i]));
	}

	mix_signed(&digest, fileobj_initial_refcnt_result());
	mix(&digest, fileobj_initial_sref_result());
	mix_signed(&digest, fileobj_new_page_mode_result());
	mix_signed(&digest, fileobj_mapped_mode_result());
	for (unsigned long value = 0; value <= 2; value++) {
		mix_signed(&digest, fileobj_path_present_result(value));
		mix_signed(&digest, devobj_path_present_result(value));
		mix_signed(&digest, devobj_pfn_table_present_result(value));
		mix_signed(&digest, fileobj_premap_page_present_result(value));
	}
	for (int count = -1; count <= 3; count++) {
		mix_signed(&digest, fileobj_invalid_page_count_result(count));
		mix_signed(&digest, fileobj_should_free_hashed_page_result(count, 0));
		mix_signed(&digest, fileobj_should_free_hashed_page_result(count, 1));
	}
	mix_signed(&digest, fileobj_lookup_page_error_result(0));
	mix_signed(&digest, fileobj_lookup_page_error_result(1));
	for (int nodes = 1; nodes <= 8; nodes++) {
		int node = fileobj_premap_start_node_result(nodes);

		mix_signed(&digest, node);
		for (int step = 0; step < 10; step++) {
			node = fileobj_premap_next_node_result(node, nodes);
			mix_signed(&digest, node);
		}
	}
	for (int pages = 0; pages <= 7; pages++)
		mix(&digest, fileobj_pages_bytes_result(pages));
	for (unsigned int i = 0; i < sizeof(offsets) / sizeof(offsets[0]); i++)
		mix_signed(&digest, fileobj_premap_page_index_result(offsets[i]));
	for (unsigned int i = 0; i < sizeof(p2aligns) / sizeof(p2aligns[0]); i++) {
		int npages = fileobj_alloc_npages_result(p2aligns[i]);

		mix_signed(&digest, npages);
		mix(&digest, fileobj_alloc_size_result(npages));
		mix(&digest, fileobj_pageio_pgsize_result(p2aligns[i]));
	}
	for (int attempts = 0; attempts <= 100; attempts += 25)
		mix_signed(&digest, fileobj_pageio_should_schedule_result(attempts));

	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++) {
		mix_signed(&digest, fileobj_premap_npages_result(sizes[i]));
		mix(&digest, devobj_npages_result(sizes[i]));
		mix(&digest, devobj_pfn_table_npages_result(sizes[i]));
		mix(&digest, devobj_pfn_table_bytes_result(sizes[i]));
		mix_signed(&digest, sysfs_string_nbits_result(sizes[i]));
	}

	for (int align = -1; align <= 2; align++)
		mix_signed(&digest, fileobj_validate_p2align_result(align));

	for (long ssize = -5; ssize <= 8192; ssize += 4096)
		mix_signed(&digest, fileobj_pageio_mode_after_read_result(ssize, 4096));

	for (long base = -1; base <= 2; base++) {
		for (long pgoff = -1; pgoff <= 5; pgoff++) {
			ix = 0x76543210;
			mix_signed(&digest, devobj_get_page_index_result(pgoff, base, 3, &ix));
			mix_signed(&digest, ix);
		}
	}

	for (unsigned int i = 0; i < sizeof(pfns) / sizeof(pfns[0]); i++) {
		mix_signed(&digest, devobj_cached_pfn_needs_fetch_result(pfns[i]));
		mix_signed(&digest, devobj_pfn_present_result(pfns[i]));
		mix(&digest, devobj_pfn_attr_result(pfns[i]));
		mix(&digest, devobj_pfn_phys_result(pfns[i]));
		mix_signed(&digest, devobj_pfn_absent_error_result(pfns[i]));
		mix_signed(&digest, devobj_should_store_pfn_result(pfns[i]));
	}
	mix_signed(&digest, devobj_base_flags_result());
	mix_signed(&digest, devobj_initial_refcnt_result());
	mix(&digest, devobj_map_size_result());
	for (unsigned int i = 0; i < sizeof(offsets) / sizeof(offsets[0]); i++)
		mix_signed(&digest, devobj_pfn_request_offset_result(offsets[i]));
	for (unsigned int i = 0; i < sizeof(pfns) / sizeof(pfns[0]); i++) {
		for (unsigned int j = 0; j < sizeof(pfns) / sizeof(pfns[0]); j++)
			mix(&digest, devobj_mapped_pfn_result(pfns[i], pfns[j]));
	}
	char file_memobj_token = 5;
	char file_obj_token = 6;
	char file_lock_token = 7;
	char file_node_token = 8;
	struct fake_file_page file_page = { 8192, 0xabc000UL };
	uintptr_t file_phys = 0;

	fake_file_reset();
	fake_file_page_result = &file_page;
	fake_file_write_ret = 4096;
	mix_signed(&digest, fileobj_flush_page_body_result(&file_memobj_token,
		&file_obj_token, 0, 0x44, 0x123000UL, 4096,
		fake_file_phys_to_page, fake_file_page_offset,
		fake_file_write, fake_file_log));
	require(fake_file_phys_to_page_calls == 1);
	require(fake_file_last_phys_to_page == 0x123000UL);
	require(fake_file_page_offset_calls == 1);
	require(fake_file_write_calls == 1);
	require(fake_file_last_write_handle == 0x44);
	require(fake_file_last_write_offset == 8192);
	require(fake_file_last_write_pgsize == 4096);
	require(fake_file_last_write_phys == 0x123000UL);
	require(fake_file_log_calls == 0);
	mix(&digest, (unsigned long)fake_file_write_calls);
	mix(&digest, fake_file_last_write_offset);

	fake_file_reset();
	fake_file_page_result = &file_page;
	fake_file_write_ret = 1024;
	mix_signed(&digest, fileobj_flush_page_body_result(&file_memobj_token,
		&file_obj_token, 0, 0x45, 0x123000UL, 4096,
		fake_file_phys_to_page, fake_file_page_offset,
		fake_file_write, fake_file_log));
	require(fake_file_log_calls == 1);
	require(fake_file_last_log_event == 2);
	require(fake_file_last_log_result == 1024);
	mix_signed(&digest, fake_file_last_log_event);
	mix_signed(&digest, fake_file_last_log_result);

	fake_file_reset();
	mix_signed(&digest, fileobj_flush_page_body_result(&file_memobj_token,
		&file_obj_token, 0x10, 0x46, 0x123000UL, 4096,
		fake_file_phys_to_page, fake_file_page_offset,
		fake_file_write, fake_file_log));
	require(fake_file_phys_to_page_calls == 0);
	require(fake_file_write_calls == 0);
	mix(&digest, (unsigned long)fake_file_phys_to_page_calls);

	fake_file_reset();
	fake_file_page_result = NULL;
	mix_signed(&digest, fileobj_flush_page_body_result(&file_memobj_token,
		&file_obj_token, 0, 0x47, 0x123000UL, 4096,
		fake_file_phys_to_page, fake_file_page_offset,
		fake_file_write, fake_file_log));
	require(fake_file_log_calls == 1);
	require(fake_file_last_log_event == 1);
	require(fake_file_write_calls == 0);
	mix_signed(&digest, fake_file_last_log_event);

	fake_file_reset();
	mix_signed(&digest, fileobj_invalidate_page_body_result(
		&file_memobj_token, 0x12000UL, 4096, fake_file_log));
	require(fake_file_log_calls == 1);
	require(fake_file_last_log_event == 3);
	require(fake_file_last_log_phys == 0x12000UL);
	mix_signed(&digest, fake_file_last_log_event);

	fake_file_reset();
	fake_file_lookup_result = &file_page;
	file_phys = 0;
	mix_signed(&digest, fileobj_lookup_page_body_result(&file_obj_token,
		8192, 0, &file_phys, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_lookup,
		fake_file_page_phys));
	require(file_phys == 0xabc000UL);
	require(fake_file_lock_calls == 1);
	require(fake_file_unlock_calls == 1);
	require(fake_file_lookup_calls == 1);
	require(fake_file_last_lookup_hash == fileobj_page_hash_result(8192));
	require(fake_file_page_phys_calls == 1);
	mix(&digest, file_phys);
	mix(&digest, (unsigned long)fake_file_lookup_calls);

	fake_file_reset();
	file_phys = 0x55UL;
	mix_signed(&digest, fileobj_lookup_page_body_result(&file_obj_token,
		8192, 0, &file_phys, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_lookup,
		fake_file_page_phys));
	require(file_phys == 0x55UL);
	require(fake_file_lock_calls == 1);
	require(fake_file_unlock_calls == 1);
	require(fake_file_page_phys_calls == 0);
	mix_signed(&digest, -1);
	mix(&digest, file_phys);

	fake_file_reset();
	file_phys = 0;
	mix_signed(&digest, fileobj_lookup_page_body_result(&file_obj_token,
		8192, 1, &file_phys, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_lookup,
		fake_file_page_phys));
	require(fake_file_lock_calls == 0);
	require(file_phys == 0);
	mix_signed(&digest, fake_file_lock_calls);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, PM_WILL_PAGEIO };
	fake_file_lookup_result = &file_page;
	mix_signed(&digest, fileobj_do_pageio_body_result(&file_obj_token,
		MF_ZEROFILL, 0x88, 8192, 4096, &file_lock_token,
		&file_node_token, fake_file_lock, fake_file_unlock,
		fake_file_lookup, fake_file_page_mode, fake_file_page_set_mode,
		fake_file_page_phys, fake_file_zero_page, fake_file_write,
		fake_file_schedule, fake_file_pause, fake_file_pageio_log,
		fake_file_panic));
	require(file_page.mode == PM_DONE_PAGEIO);
	require(fake_file_zero_calls == 1);
	require(fake_file_last_zero_phys == 0xabc000UL);
	require(fake_file_write_calls == 0);
	require(fake_file_pageio_log_calls == 0);
	mix_signed(&digest, file_page.mode);
	mix_signed(&digest, fake_file_zero_calls);
	mix(&digest, fake_file_last_zero_phys);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, PM_WILL_PAGEIO };
	fake_file_lookup_result = &file_page;
	fake_file_write_ret = 4096;
	mix_signed(&digest, fileobj_do_pageio_body_result(&file_obj_token,
		0, 0x89, 8192, 4096, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_lookup,
		fake_file_page_mode, fake_file_page_set_mode,
		fake_file_page_phys, fake_file_zero_page, fake_file_write,
		fake_file_schedule, fake_file_pause, fake_file_pageio_log,
		fake_file_panic));
	require(file_page.mode == PM_DONE_PAGEIO);
	require(fake_file_write_calls == 1);
	require(fake_file_last_write_handle == 0x89);
	require(fake_file_last_write_offset == 8192);
	require(fake_file_pageio_log_calls == 0);
	require(fake_file_panic_calls == 0);
	mix_signed(&digest, file_page.mode);
	mix_signed(&digest, fake_file_write_calls);
	mix(&digest, fake_file_last_write_handle);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, PM_WILL_PAGEIO };
	fake_file_lookup_result = &file_page;
	fake_file_write_ret = 0;
	mix_signed(&digest, fileobj_do_pageio_body_result(&file_obj_token,
		0, 0x8a, 8192, 4096, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_lookup,
		fake_file_page_mode, fake_file_page_set_mode,
		fake_file_page_phys, fake_file_zero_page, fake_file_write,
		fake_file_schedule, fake_file_pause, fake_file_pageio_log,
		fake_file_panic));
	require(file_page.mode == PM_PAGEIO_EOF);
	require(fake_file_pageio_log_calls == 1);
	require(fake_file_last_pageio_log_event == FILEOBJ_LOG_PAGEIO_EOF);
	require(fake_file_last_pageio_log_value == 0);
	mix_signed(&digest, file_page.mode);
	mix_signed(&digest, fake_file_last_pageio_log_event);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, PM_PAGEIO };
	fake_file_lookup_result = &file_page;
	mix_signed(&digest, fileobj_do_pageio_body_result(&file_obj_token,
		MF_ZEROFILL, 0x8b, 8192, 4096, &file_lock_token,
		&file_node_token, fake_file_lock, fake_file_unlock,
		fake_file_lookup, fake_file_page_mode, fake_file_page_set_mode,
		fake_file_page_phys, fake_file_zero_page, fake_file_write,
		fake_file_schedule, fake_file_pause, fake_file_pageio_log,
		fake_file_panic));
	require(file_page.mode == PM_DONE_PAGEIO);
	require(fake_file_pause_calls == 51);
	require(fake_file_schedule_calls == 2);
	require(fake_file_pageio_log_calls == 2);
	require(fake_file_zero_calls == 1);
	mix_signed(&digest, fake_file_pause_calls);
	mix_signed(&digest, fake_file_schedule_calls);
	mix_signed(&digest, fake_file_pageio_log_calls);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, 0, 1 };
	fake_file_free_first_result = &file_page;
	mix_signed(&digest, fileobj_free_body_result(&file_obj_token,
		0, 0x99, 2, NULL, 0, NULL, &file_lock_token,
		&file_node_token, fake_file_lock, fake_file_unlock,
		fake_file_list_remove, fake_file_free_first,
		fake_file_page_remove, fake_file_page_phys,
		fake_file_phys_to_virt, fake_file_page_count,
		fake_file_page_unmap, fake_file_free_pages,
		fake_file_rss_sub, fake_file_free_ptr, fake_file_release,
		fake_file_page_at, fake_file_free_log));
	require(fake_file_list_remove_calls == 1);
	require(fake_file_page_remove_calls == 1);
	require(fake_file_page_unmap_calls == 1);
	require(fake_file_free_pages_calls == 1);
	require(fake_file_last_free_pages_addr == (void *)0xabd000UL);
	require(fake_file_rss_sub_calls == 1);
	require(fake_file_release_calls == 1);
	require(fake_file_last_release_handle == 0x99);
	require(fake_file_last_release_sref == 2);
	require(fake_file_free_calls == 2);
	require(fake_file_last_free_ptr == &file_obj_token);
	require(fake_file_free_log_calls == 2);
	require(fake_file_last_free_log_event == FILEOBJ_LOG_FREE_DONE);
	mix_signed(&digest, fake_file_free_pages_calls);
	mix_signed(&digest, fake_file_rss_sub_calls);
	mix_signed(&digest, fake_file_free_calls);
	mix(&digest, fake_file_last_release_handle);

	fake_file_reset();
	file_page = (struct fake_file_page){ 8192, 0xabc000UL, 0, 2 };
	fake_file_free_first_result = &file_page;
	mix_signed(&digest, fileobj_free_body_result(&file_obj_token,
		0, 0x9a, 3, NULL, 0, NULL, &file_lock_token,
		&file_node_token, fake_file_lock, fake_file_unlock,
		fake_file_list_remove, fake_file_free_first,
		fake_file_page_remove, fake_file_page_phys,
		fake_file_phys_to_virt, fake_file_page_count,
		fake_file_page_unmap, fake_file_free_pages,
		fake_file_rss_sub, fake_file_free_ptr, fake_file_release,
		fake_file_page_at, fake_file_free_log));
	require(fake_file_page_unmap_calls == 0);
	require(fake_file_free_pages_calls == 0);
	require(fake_file_free_calls == 1);
	require(fake_file_free_log_calls == 2);
	require(fake_file_last_free_log_event == FILEOBJ_LOG_FREE_DONE);
	mix_signed(&digest, fake_file_page_unmap_calls);
	mix_signed(&digest, fake_file_free_pages_calls);
	mix_signed(&digest, fake_file_free_log_calls);

	fake_file_reset();
	char file_path_token = 11;
	fake_file_page_array[0] = (void *)0x10000UL;
	fake_file_page_array[2] = (void *)0x12000UL;
	fake_file_release_ret = -5;
	mix_signed(&digest, fileobj_free_body_result(&file_obj_token,
		MF_PREMAP | MF_ZEROFILL, 0x9b, 4, fake_file_page_array, 3,
		&file_path_token, &file_lock_token, &file_node_token,
		fake_file_lock, fake_file_unlock, fake_file_list_remove,
		fake_file_free_first, fake_file_page_remove,
		fake_file_page_phys, fake_file_phys_to_virt,
		fake_file_page_count, fake_file_page_unmap,
		fake_file_free_pages, fake_file_rss_sub, fake_file_free_ptr,
		fake_file_release, fake_file_page_at, fake_file_free_log));
	require(fake_file_page_at_calls == 3);
	require(fake_file_free_pages_calls == 2);
	require(fake_file_rss_sub_calls == 2);
	require(fake_file_free_calls == 3);
	require(fake_file_release_calls == 1);
	require(fake_file_free_log_calls == 4);
	require(fake_file_last_free_log_event == FILEOBJ_LOG_FREE_DONE);
	require(fake_file_last_free_log_value == -5);
	mix_signed(&digest, fake_file_page_at_calls);
	mix_signed(&digest, fake_file_free_pages_calls);
	mix_signed(&digest, fake_file_release_ret);
	mix_signed(&digest, fake_file_free_log_calls);

	struct fake_file_obj file_miss_obj = { 0x1111UL, 9 };
	struct fake_file_obj file_stale_obj = { 0x7777UL, 1 };
	struct fake_file_obj file_existing_obj = { 0x7777UL, 3 };
	char file_head_token = 9;

	fake_file_reset();
	fake_file_items[0] = &file_miss_obj;
	fake_file_items[1] = &file_stale_obj;
	fake_file_items[2] = &file_existing_obj;
	void *file_lookup = fileobj_obj_list_lookup_body_result(
		0x7777UL, &file_head_token, fake_file_list_first,
		fake_file_list_next, fake_file_handle, fake_file_ref,
		fake_file_dec);
	require(file_lookup == &file_existing_obj);
	require(fake_file_list_first_calls == 1);
	require(fake_file_list_next_calls == 2);
	require(fake_file_handle_calls == 3);
	require(fake_file_ref_calls == 2);
	require(fake_file_dec_calls == 1);
	require(fake_file_last_dec_obj == &file_stale_obj);
	mix(&digest, (unsigned long)fake_file_list_next_calls);
	mix(&digest, (unsigned long)fake_file_ref_calls);
	mix(&digest, (unsigned long)fake_file_dec_calls);

	fake_file_reset();
	fake_file_items[0] = &file_miss_obj;
	file_lookup = fileobj_obj_list_lookup_body_result(
		0x9999UL, &file_head_token, fake_file_list_first,
		fake_file_list_next, fake_file_handle, fake_file_ref,
		fake_file_dec);
	require(file_lookup == NULL);
	require(fake_file_ref_calls == 0);
	require(fake_file_list_next_calls == 1);
	mix(&digest, (unsigned long)fake_file_list_next_calls);

	struct fake_file_obj file_new_obj = { 0 };
	int file_expected_flags = fileobj_apply_result_flags_result(
		fileobj_create_base_flags_result(MF_ZEROFILL), MF_PREMAP);

	fake_file_reset();
	mix_signed(&digest, fileobj_create_publish_body_result(&file_new_obj,
		1, MF_ZEROFILL, MF_PREMAP, 0x9000,
		fake_file_list_insert, fake_file_size_set,
		fake_file_flags_set, fake_file_status_set,
		fake_file_refcnt_set, fake_file_sref_get,
		fake_file_sref_set));
	require(fake_file_list_insert_calls == 1);
	require(fake_file_size_set_calls == 1);
	require(fake_file_last_size_set == 0x9000);
	require(fake_file_flags_set_calls == 1);
	require(fake_file_last_flags_set == file_expected_flags);
	require(fake_file_status_set_calls == 1);
	require(fake_file_last_status_set ==
		fileobj_status_from_flags_result(file_expected_flags));
	require(fake_file_refcnt_set_calls == 1);
	require(fake_file_last_refcnt_set == fileobj_initial_refcnt_result());
	require(fake_file_sref_get_calls == 0);
	require(fake_file_sref_set_calls == 1);
	require(file_new_obj.listed == 1);
	require(file_new_obj.size == 0x9000);
	require(file_new_obj.flags == file_expected_flags);
	require(file_new_obj.refcnt == fileobj_initial_refcnt_result());
	require(file_new_obj.sref == fileobj_initial_sref_result());
	mix(&digest, file_new_obj.size);
	mix_signed(&digest, file_new_obj.flags);
	mix_signed(&digest, file_new_obj.refcnt);
	mix(&digest, file_new_obj.sref);

	file_existing_obj.sref = 41;
	fake_file_reset();
	mix_signed(&digest, fileobj_create_publish_body_result(
		&file_existing_obj, 0, 0, 0, 0,
		fake_file_list_insert, fake_file_size_set,
		fake_file_flags_set, fake_file_status_set,
		fake_file_refcnt_set, fake_file_sref_get,
		fake_file_sref_set));
	require(fake_file_list_insert_calls == 0);
	require(fake_file_size_set_calls == 0);
	require(fake_file_flags_set_calls == 0);
	require(fake_file_status_set_calls == 0);
	require(fake_file_refcnt_set_calls == 0);
	require(fake_file_sref_get_calls == 1);
	require(fake_file_sref_set_calls == 1);
	require(file_existing_obj.sref == 42);
	mix_signed(&digest, fake_file_sref_get_calls);
	mix(&digest, file_existing_obj.sref);

	char file_path_src[4096];
	char file_path_dst[4096];
	struct fake_file_obj file_path_obj = { 0 };
	memset(file_path_src, 0, sizeof(file_path_src));
	memset(file_path_dst, 0, sizeof(file_path_dst));
	strcpy(file_path_src, "/tmp/fileobj-path");

	fake_file_reset();
	fake_file_alloc_result = file_path_dst;
	mix_signed(&digest, fileobj_create_path_body_result(&file_path_obj,
		0, file_path_src, sizeof(file_path_src), 0x2,
		fake_file_alloc, fake_file_copy, fake_file_path_set,
		fake_file_create_log));
	require(fake_file_alloc_calls == 0);
	require(fake_file_copy_calls == 0);
	require(fake_file_path_set_calls == 0);
	require(file_path_obj.path == NULL);
	mix_signed(&digest, fake_file_alloc_calls);

	fake_file_reset();
	fake_file_alloc_result = file_path_dst;
	mix_signed(&digest, fileobj_create_path_body_result(&file_path_obj,
		file_path_src[0], file_path_src, sizeof(file_path_src), 0x2,
		fake_file_alloc, fake_file_copy, fake_file_path_set,
		fake_file_create_log));
	require(fake_file_alloc_calls == 1);
	require(fake_file_last_alloc_size == sizeof(file_path_src));
	require(fake_file_last_alloc_flags == 0x2);
	require(fake_file_path_set_calls == 1);
	require(fake_file_last_path_set == file_path_dst);
	require(file_path_obj.path == file_path_dst);
	require(fake_file_copy_calls == 1);
	require(fake_file_last_copy_dst == file_path_dst);
	require(fake_file_last_copy_src == file_path_src);
	require(fake_file_last_copy_len == sizeof(file_path_src));
	require(strcmp(file_path_dst, file_path_src) == 0);
	require(fake_file_create_log_calls == 0);
	mix_signed(&digest, fake_file_alloc_calls);
	mix_signed(&digest, fake_file_copy_calls);
	mix(&digest, fake_file_last_alloc_size);

	fake_file_reset();
	fake_file_alloc_result = NULL;
	mix_signed(&digest, fileobj_create_path_body_result(&file_path_obj,
		file_path_src[0], file_path_src, sizeof(file_path_src), 0x2,
		fake_file_alloc, fake_file_copy, fake_file_path_set,
		fake_file_create_log));
	require(fake_file_alloc_calls == 1);
	require(fake_file_copy_calls == 0);
	require(fake_file_path_set_calls == 0);
	require(fake_file_create_log_calls == 1);
	require(fake_file_last_create_log_event ==
		FILEOBJ_CREATE_LOG_PATH_ALLOC_FAILED);
	require(fake_file_last_create_log_path == file_path_src);
	require(fake_file_last_create_log_value == (long)sizeof(file_path_src));
	mix_signed(&digest, fake_file_last_create_log_event);
	mix_signed(&digest, fake_file_copy_calls);

	void *file_premap_pages[4] = {
		(void *)0x1111UL, (void *)0x2222UL,
		(void *)0x3333UL, (void *)0x4444UL
	};
	char file_premap_page0[4096];
	char file_premap_page1[4096];
	struct fake_file_obj file_premap_obj = { 0 };
	memset(file_premap_page0, 0x5a, sizeof(file_premap_page0));
	memset(file_premap_page1, 0x6b, sizeof(file_premap_page1));

	fake_file_reset();
	fake_file_alloc_result = file_premap_pages;
	mix_signed(&digest, fileobj_create_premap_body_result(
		&file_premap_obj, 0, 8192, MPOL_SHM_PREMAP, 4, 0x900000UL,
		0x2, fake_file_alloc, fake_file_pages_set,
		fake_file_nr_pages_set, fake_file_zero_mem,
		fake_file_alloc_pages_node, fake_file_page_slot_set,
		fake_file_rss_add, fake_file_premap_log));
	require(fake_file_alloc_calls == 0);
	require(fake_file_pages_set_calls == 0);
	require(fake_file_premap_log_calls == 0);
	require(file_premap_obj.pages == NULL);
	mix_signed(&digest, fake_file_premap_log_calls);

	fake_file_reset();
	fake_file_alloc_result = NULL;
	mix_signed(&digest, fileobj_create_premap_body_result(
		&file_premap_obj, MF_ZEROFILL | MF_PREMAP, 8192, 0, 4,
		0x900000UL, 0x2, fake_file_alloc, fake_file_pages_set,
		fake_file_nr_pages_set, fake_file_zero_mem,
		fake_file_alloc_pages_node, fake_file_page_slot_set,
		fake_file_rss_add, fake_file_premap_log));
	require(fake_file_alloc_calls == 1);
	require(fake_file_last_alloc_size == fileobj_pages_bytes_result(2));
	require(fake_file_pages_set_calls == 0);
	require(fake_file_zero_mem_calls == 0);
	require(fake_file_premap_log_counts[
		FILEOBJ_CREATE_LOG_PREMAP_START] == 1);
	require(fake_file_premap_log_counts[
		FILEOBJ_CREATE_LOG_PREMAP_ARRAY_ALLOC_FAILED] == 1);
	mix_signed(&digest, fake_file_last_alloc_size);
	mix_signed(&digest, fake_file_premap_log_calls);

	fake_file_reset();
	file_premap_pages[0] = (void *)0x1111UL;
	file_premap_pages[1] = (void *)0x2222UL;
	fake_file_alloc_result = file_premap_pages;
	mix_signed(&digest, fileobj_create_premap_body_result(
		&file_premap_obj, MF_ZEROFILL | MF_PREMAP, 8192, 0, 4,
		0x900000UL, 0x2, fake_file_alloc, fake_file_pages_set,
		fake_file_nr_pages_set, fake_file_zero_mem,
		fake_file_alloc_pages_node, fake_file_page_slot_set,
		fake_file_rss_add, fake_file_premap_log));
	require(fake_file_alloc_calls == 1);
	require(fake_file_pages_set_calls == 1);
	require(fake_file_last_pages_set == file_premap_pages);
	require(fake_file_nr_pages_set_calls == 1);
	require(fake_file_last_nr_pages_set == 2);
	require(file_premap_obj.pages == file_premap_pages);
	require(file_premap_obj.nr_pages == 2);
	require(fake_file_zero_mem_calls == 1);
	require(fake_file_last_zero_mem_ptr == file_premap_pages);
	require(fake_file_last_zero_mem_len == fileobj_pages_bytes_result(2));
	require(file_premap_pages[0] == NULL);
	require(file_premap_pages[1] == NULL);
	require(fake_file_alloc_node_calls == 0);
	mix_signed(&digest, fake_file_zero_mem_calls);
	mix_signed(&digest, fake_file_nr_pages_set_calls);

	fake_file_reset();
	file_premap_pages[0] = NULL;
	file_premap_pages[1] = NULL;
	fake_file_alloc_result = file_premap_pages;
	fake_file_alloc_node_results[0] = file_premap_page0;
	fake_file_alloc_node_results[1] = file_premap_page1;
	mix_signed(&digest, fileobj_create_premap_body_result(
		&file_premap_obj, MF_ZEROFILL | MF_PREMAP, 8192,
		MPOL_SHM_PREMAP, 4, 0x900000UL, 0x2, fake_file_alloc,
		fake_file_pages_set, fake_file_nr_pages_set,
		fake_file_zero_mem, fake_file_alloc_pages_node,
		fake_file_page_slot_set, fake_file_rss_add,
		fake_file_premap_log));
	require(fake_file_alloc_node_calls == 2);
	require(fake_file_alloc_node_nodes[0] == 2);
	require(fake_file_alloc_node_nodes[1] == 3);
	require(fake_file_last_alloc_node_npages == 1);
	require(fake_file_last_alloc_node_p2align == 0);
	require(fake_file_last_alloc_node_flags == 0x2);
	require(fake_file_last_alloc_node_virt == 0x900000UL);
	require(fake_file_page_slot_set_calls == 2);
	require(file_premap_pages[0] == file_premap_page0);
	require(file_premap_pages[1] == file_premap_page1);
	require(fake_file_rss_add_calls == 2);
	require(fake_file_last_rss_add_size == 4096);
	require(fake_file_last_rss_add_pgsize == 4096);
	require(fake_file_zero_mem_calls == 3);
	require(file_premap_page0[0] == 0);
	require(file_premap_page1[0] == 0);
	require(fake_file_premap_log_counts[
		FILEOBJ_CREATE_LOG_PREMAP_RSS_ADD] == 2);
	require(fake_file_premap_log_counts[
		FILEOBJ_CREATE_LOG_PREMAP_INTERLEAVED_DONE] == 1);
	mix_signed(&digest, fake_file_alloc_node_calls);
	mix_signed(&digest, fake_file_page_slot_set_calls);
	mix_signed(&digest, fake_file_rss_add_calls);

	char file_get_page0[4096];
	char file_get_page1[4096];
	char file_get_existing[4096];
	void *file_get_pages[4] = { file_get_existing, NULL, NULL, NULL };
	uintptr_t file_get_phys = 0;
	memset(file_get_page0, 0x7c, sizeof(file_get_page0));
	memset(file_get_page1, 0x7d, sizeof(file_get_page1));
	memset(file_get_existing, 0x7e, sizeof(file_get_existing));

	fake_file_reset();
	mix_signed(&digest, fileobj_get_premap_body_result(&file_premap_obj,
		file_get_pages, 0, 0, 0x880000UL, &file_get_phys, 0x1002,
		fake_file_alloc_user_pages, fake_file_zero_mem,
		fake_file_page_at, fake_file_page_slot_cmpxchg,
		fake_file_free_pages, fake_file_virt_phys,
		fake_file_rss_add, fake_file_get_log));
	require(fake_file_alloc_user_calls == 0);
	require(fake_file_cmpxchg_calls == 0);
	require(fake_file_virt_phys_calls == 1);
	require(file_get_phys == (uintptr_t)file_get_existing + 0x100000UL);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_RESOLVED] == 1);
	mix_signed(&digest, fake_file_virt_phys_calls);
	mix_signed(&digest, fake_file_alloc_user_calls);

	fake_file_reset();
	file_get_pages[0] = NULL;
	file_get_phys = 0;
	mix_signed(&digest, fileobj_get_premap_body_result(&file_premap_obj,
		file_get_pages, 0, 0, 0x880000UL, &file_get_phys, 0x1002,
		fake_file_alloc_user_pages, fake_file_zero_mem,
		fake_file_page_at, fake_file_page_slot_cmpxchg,
		fake_file_free_pages, fake_file_virt_phys,
		fake_file_rss_add, fake_file_get_log));
	require(fake_file_alloc_user_calls == 1);
	require(fake_file_last_alloc_user_npages == 1);
	require(fake_file_last_alloc_user_flags == 0x1002);
	require(fake_file_last_alloc_user_virt == 0x880000UL);
	require(fake_file_zero_mem_calls == 0);
	require(fake_file_cmpxchg_calls == 0);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_ALLOC_FAILED] == 1);
	require(fake_file_last_get_log_value == -12);
	require(file_get_phys == 0);
	mix_signed(&digest, fake_file_last_get_log_event);
	mix_signed(&digest, fake_file_last_get_log_value);

	fake_file_reset();
	file_get_pages[0] = NULL;
	fake_file_alloc_user_result = file_get_page0;
	file_get_phys = 0;
	mix_signed(&digest, fileobj_get_premap_body_result(&file_premap_obj,
		file_get_pages, 0, 0, 0x880000UL, &file_get_phys, 0x1002,
		fake_file_alloc_user_pages, fake_file_zero_mem,
		fake_file_page_at, fake_file_page_slot_cmpxchg,
		fake_file_free_pages, fake_file_virt_phys,
		fake_file_rss_add, fake_file_get_log));
	require(fake_file_alloc_user_calls == 1);
	require(fake_file_zero_mem_calls == 1);
	require(file_get_page0[0] == 0);
	require(fake_file_cmpxchg_calls == 1);
	require(fake_file_last_cmpxchg_index == 0);
	require(fake_file_last_cmpxchg_old == NULL);
	require(fake_file_last_cmpxchg_new == file_get_page0);
	require(file_get_pages[0] == file_get_page0);
	require(fake_file_free_pages_calls == 0);
	require(fake_file_rss_add_calls == 1);
	require(file_get_phys == (uintptr_t)file_get_page0 + 0x100000UL);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_ALLOCATED] == 1);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_RSS_ADD] == 1);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_RESOLVED] == 1);
	mix_signed(&digest, fake_file_virt_phys_calls);
	mix_signed(&digest, fake_file_rss_add_calls);

	fake_file_reset();
	file_get_pages[0] = NULL;
	fake_file_alloc_user_result = file_get_page1;
	fake_file_cmpxchg_forced_return = file_get_existing;
	file_get_phys = 0;
	mix_signed(&digest, fileobj_get_premap_body_result(&file_premap_obj,
		file_get_pages, 0, 0, 0x880000UL, &file_get_phys, 0x1002,
		fake_file_alloc_user_pages, fake_file_zero_mem,
		fake_file_page_at, fake_file_page_slot_cmpxchg,
		fake_file_free_pages, fake_file_virt_phys,
		fake_file_rss_add, fake_file_get_log));
	require(fake_file_alloc_user_calls == 1);
	require(fake_file_cmpxchg_calls == 1);
	require(fake_file_free_pages_calls == 1);
	require(fake_file_last_free_pages_addr == file_get_page1);
	require(file_get_pages[0] == file_get_existing);
	require(fake_file_rss_add_calls == 0);
	require(file_get_phys == (uintptr_t)file_get_existing + 0x100000UL);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_ALLOCATED] == 0);
	require(fake_file_get_log_counts[
		FILEOBJ_GET_LOG_PREMAP_RESOLVED] == 1);
	mix_signed(&digest, fake_file_free_pages_calls);
	mix_signed(&digest, fake_file_virt_phys_calls);

	struct fake_file_obj file_regular_obj = { 0x2222UL, 6 };
	struct fake_file_thread file_regular_thread = { 0 };
	struct fake_file_pageio_args file_regular_args = { 0 };
	struct fake_file_page file_regular_new = {
		0, 0x180000UL, PM_NONE, 0, -1
	};
	char file_regular_virt[4096];
	char file_regular_lock = 12;
	char file_regular_node = 13;
	char file_regular_pageio = 14;
	uintptr_t file_regular_phys = 0;
	int file_regular_ret;
	memset(file_regular_virt, 0x33, sizeof(file_regular_virt));

	fake_file_reset();
	fake_file_alloc_result = &file_regular_args;
	fake_file_alloc_user_result = file_regular_virt;
	fake_file_page_result = &file_regular_new;
	file_regular_ret = fake_file_get_regular_call(
		&file_regular_obj, MF_ZEROFILL, 0x3000, 0, 0x990000UL,
		&file_regular_phys, &file_regular_thread, &file_regular_pageio,
		&file_regular_lock, &file_regular_node,
		sizeof(file_regular_args), 0x2);
	mix_signed(&digest, file_regular_ret);
	require(file_regular_ret == -ERESTART);
	require(fake_file_lock_calls == 1);
	require(fake_file_unlock_calls == 1);
	require(fake_file_lookup_calls == 1);
	require(fake_file_alloc_calls == 1);
	require(fake_file_last_alloc_size == sizeof(file_regular_args));
	require(fake_file_last_alloc_flags == 0x2);
	require(fake_file_alloc_user_calls == 1);
	require(fake_file_last_alloc_user_npages == 1);
	require(fake_file_last_alloc_user_flags == 0x1002);
	require(fake_file_last_alloc_user_virt == 0x990000UL);
	require(fake_file_page_insert_calls == 1);
	require(fake_file_last_page_insert_phys ==
		(uintptr_t)file_regular_virt + 0x100000UL);
	require(file_regular_new.offset == 0x3000);
	require(file_regular_new.count == 1);
	require(file_regular_new.mapped == 0);
	require(file_regular_new.mode == PM_WILL_PAGEIO);
	require(fake_file_last_hash_insert_hash ==
		fileobj_page_hash_result(0x3000));
	require(fake_file_ref_calls == 1);
	require(fake_file_args_set_calls == 1);
	require(file_regular_args.fileobj == &file_regular_obj);
	require(file_regular_args.objoff == 0x3000);
	require(file_regular_args.pgsize == 4096);
	require(fake_file_pgio_set_calls == 1);
	require(file_regular_thread.pgio_fp == &file_regular_pageio);
	require(file_regular_thread.pgio_arg == &file_regular_args);
	require(file_regular_phys == 0);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_NEW_PAGE] == 1);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_RETURN] == 1);
	mix_signed(&digest, fake_file_alloc_user_calls);
	mix_signed(&digest, fake_file_page_insert_calls);
	mix_signed(&digest, file_regular_new.mode);
	mix_signed(&digest, file_regular_new.count);
	mix_signed(&digest, fake_file_pgio_set_calls);

	fake_file_reset();
	file_regular_phys = 0;
	file_regular_ret = fake_file_get_regular_call(
		&file_regular_obj, MF_ZEROFILL, 0x3000, 0, 0x990000UL,
		&file_regular_phys, &file_regular_thread, &file_regular_pageio,
		&file_regular_lock, &file_regular_node,
		sizeof(file_regular_args), 0x2);
	mix_signed(&digest, file_regular_ret);
	require(file_regular_ret == -ENOMEM);
	require(fake_file_alloc_calls == 1);
	require(fake_file_alloc_user_calls == 0);
	require(fake_file_free_calls == 0);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_KMALLOC_FAILED] == 1);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_RETURN] == 1);
	require(fake_file_last_get_regular_log_value == (uintptr_t)-ENOMEM);
	require(file_regular_phys == 0);
	mix_signed(&digest, fake_file_last_get_regular_log_event);
	mix(&digest, fake_file_last_get_regular_log_value);

	struct fake_file_page file_regular_done = {
		0x4000, 0xabc000UL, PM_DONE_PAGEIO, 3, 0
	};
	fake_file_reset();
	fake_file_lookup_result = &file_regular_done;
	file_regular_phys = 0;
	file_regular_ret = fake_file_get_regular_call(
		&file_regular_obj, 0, 0x4000, 0, 0x991000UL,
		&file_regular_phys, &file_regular_thread, &file_regular_pageio,
		&file_regular_lock, &file_regular_node,
		sizeof(file_regular_args), 0x2);
	mix_signed(&digest, file_regular_ret);
	require(file_regular_ret == 0);
	require(file_regular_done.mode == PM_MAPPED);
	require(file_regular_done.count == 4);
	require(file_regular_phys == 0xabc000UL);
	require(fake_file_alloc_calls == 0);
	require(fake_file_page_count_inc_calls == 1);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_MAP_DONE] == 1);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_USE_PAGE] == 1);
	mix_signed(&digest, file_regular_done.mode);
	mix_signed(&digest, file_regular_done.count);
	mix(&digest, file_regular_phys);

	struct fake_file_page file_regular_error = {
		0x5000, 0xdef000UL, PM_PAGEIO_EOF, 1, 0
	};
	fake_file_reset();
	fake_file_lookup_result = &file_regular_error;
	fake_file_page_unmap_ret = 1;
	file_regular_phys = 0;
	file_regular_ret = fake_file_get_regular_call(
		&file_regular_obj, 0, 0x5000, 0, 0x992000UL,
		&file_regular_phys, &file_regular_thread, &file_regular_pageio,
		&file_regular_lock, &file_regular_node,
		sizeof(file_regular_args), 0x2);
	mix_signed(&digest, file_regular_ret);
	require(file_regular_ret == -ERANGE);
	require(fake_file_page_remove_calls == 1);
	require(fake_file_phys_to_virt_calls == 1);
	require(fake_file_free_pages_calls == 1);
	require((uintptr_t)fake_file_last_free_pages_addr == 0xdef000UL + 0x1000UL);
	require(fake_file_free_calls == 1);
	require(fake_file_last_free_ptr == &file_regular_error);
	require(fake_file_page_count_inc_calls == 0);
	require(file_regular_phys == 0);
	require(fake_file_get_regular_log_counts[
		FILEOBJ_GET_LOG_RETURN] == 1);
	require(fake_file_last_get_regular_log_value == (uintptr_t)-ERANGE);
	mix_signed(&digest, fake_file_page_remove_calls);
	mix_signed(&digest, fake_file_free_pages_calls);
	mix_signed(&digest, fake_file_free_calls);

	char dev_obj_token = 1;
	char dev_path_token = 2;
	char dev_pfn_table_token = 3;
	char dev_lock_token = 4;
	struct fake_dev_obj dev_obj = { { 0 } };
	uintptr_t dev_phys = 0;
	unsigned long dev_flag = 0;

	fake_dev_reset();
	fake_dev_unmap_ret = -7;
	mix_signed(&digest, devobj_free_body_result(&dev_obj_token,
		&dev_path_token, &dev_pfn_table_token, 0x77, 600,
		fake_dev_unmap, fake_dev_free_pages, fake_dev_free,
		fake_dev_log));
	require(fake_dev_unmap_calls == 1);
	require(fake_dev_last_unmap_handle == 0x77);
	require(fake_dev_free_pages_calls == 1);
	require(fake_dev_last_free_pages_addr == &dev_pfn_table_token);
	require(fake_dev_last_free_pages_npages == 2);
	require(fake_dev_free_calls == 2);
	require(fake_dev_last_free == &dev_obj_token);
	require(fake_dev_log_calls == 2);
	require(fake_dev_last_log_event == 2);
	mix(&digest, (unsigned long)fake_dev_free_pages_calls);
	mix(&digest, fake_dev_last_free_pages_npages);
	mix(&digest, (unsigned long)fake_dev_free_calls);
	mix(&digest, (unsigned long)fake_dev_log_calls);

	fake_dev_reset();
	dev_obj.pfn_table[0] = 0;
	dev_obj.pfn_table[1] = FAKE_PFN_VALID | FAKE_PFN_PRESENT | 0x5000UL;
	dev_phys = 0;
	dev_flag = 0;
	mix_signed(&digest, devobj_get_page_body_result(&dev_obj_token,
		&dev_obj, 0x88, 3 * 4096, 0, 2, 4, &dev_lock_token,
		&dev_phys, &dev_flag, fake_dev_profile, fake_dev_lock,
		fake_dev_unlock, fake_dev_pfn_load, fake_dev_fetch,
		fake_dev_wc, fake_dev_map, fake_dev_store, fake_dev_log));
	require(dev_phys == 0x5000UL);
	require(dev_flag == 0);
	require(fake_dev_profile_calls == 1);
	require(fake_dev_lock_calls == 1);
	require(fake_dev_unlock_calls == 1);
	require(fake_dev_last_load_ix == 1);
	require(fake_dev_fetch_calls == 0);
	require(fake_dev_store_calls == 0);
	mix(&digest, dev_phys);
	mix(&digest, (unsigned long)fake_dev_lock_calls);
	mix(&digest, (unsigned long)fake_dev_fetch_calls);

	fake_dev_reset();
	dev_obj.pfn_table[1] = 0;
	dev_phys = 0;
	dev_flag = 0;
	fake_dev_fetch_pfn = FAKE_PFN_VALID | FAKE_PFN_PRESENT | 0x8000UL;
	fake_dev_wc_ret = 1;
	fake_dev_map_result = 0x22000UL;
	mix_signed(&digest, devobj_get_page_body_result(&dev_obj_token,
		&dev_obj, 0x99, 3 * 4096, 0, 2, 4, &dev_lock_token,
		&dev_phys, &dev_flag, fake_dev_profile, fake_dev_lock,
		fake_dev_unlock, fake_dev_pfn_load, fake_dev_fetch,
		fake_dev_wc, fake_dev_map, fake_dev_store, fake_dev_log));
	require(dev_phys == 0x22000UL);
	require((dev_flag & FAKE_VR_WRITE_COMBINED) != 0);
	require(fake_dev_fetch_calls == 1);
	require(fake_dev_last_fetch_handle == 0x99);
	require(fake_dev_last_fetch_off == 3 * 4096);
	require(fake_dev_wc_calls == 1);
	require(fake_dev_last_wc_pfn == fake_dev_fetch_pfn);
	require(fake_dev_map_calls == 1);
	require(fake_dev_last_map_phys == 0x8000UL);
	require(fake_dev_last_map_size == 4096);
	require(fake_dev_store_calls == 1);
	require(fake_dev_last_store_ix == 1);
	require(devobj_pfn_phys_result(dev_obj.pfn_table[1]) == 0x22000UL);
	mix(&digest, dev_phys);
	mix(&digest, dev_flag);
	mix(&digest, (unsigned long)fake_dev_fetch_calls);
	mix(&digest, (unsigned long)fake_dev_store_calls);

	fake_dev_reset();
	dev_obj.pfn_table[1] = 0;
	dev_phys = 0;
	dev_flag = 0;
	fake_dev_fetch_pfn = FAKE_PFN_VALID;
	mix_signed(&digest, devobj_get_page_body_result(&dev_obj_token,
		&dev_obj, 0xaa, 3 * 4096, 0, 2, 4, &dev_lock_token,
		&dev_phys, &dev_flag, fake_dev_profile, fake_dev_lock,
		fake_dev_unlock, fake_dev_pfn_load, fake_dev_fetch,
		fake_dev_wc, fake_dev_map, fake_dev_store, fake_dev_log));
	require(fake_dev_store_calls == 1);
	require(fake_dev_map_calls == 0);
	require(fake_dev_last_log_event == 5);
	require(fake_dev_last_log_error == -14);
	require(dev_phys == 0);
	mix_signed(&digest, fake_dev_last_log_error);
	mix(&digest, (unsigned long)fake_dev_store_calls);

	fake_dev_reset();
	dev_obj.pfn_table[1] = 0;
	fake_dev_fetch_ret = -5;
	mix_signed(&digest, devobj_get_page_body_result(&dev_obj_token,
		&dev_obj, 0xbb, 3 * 4096, 0, 2, 4, &dev_lock_token,
		&dev_phys, &dev_flag, fake_dev_profile, fake_dev_lock,
		fake_dev_unlock, fake_dev_pfn_load, fake_dev_fetch,
		fake_dev_wc, fake_dev_map, fake_dev_store, fake_dev_log));
	require(fake_dev_fetch_calls == 1);
	require(fake_dev_store_calls == 0);
	require(fake_dev_last_log_event == 4);
	require(fake_dev_last_log_error == -5);
	mix_signed(&digest, fake_dev_last_log_error);

	fake_dev_reset();
	mix_signed(&digest, devobj_get_page_body_result(&dev_obj_token,
		&dev_obj, 0xcc, 8 * 4096, 0, 2, 4, &dev_lock_token,
		&dev_phys, &dev_flag, fake_dev_profile, fake_dev_lock,
		fake_dev_unlock, fake_dev_pfn_load, fake_dev_fetch,
		fake_dev_wc, fake_dev_map, fake_dev_store, fake_dev_log));
	require(fake_dev_lock_calls == 0);
	require(fake_dev_last_log_event == 3);
	require(fake_dev_last_log_error == -27);
	mix_signed(&digest, fake_dev_last_log_error);

	for (ssize_t n = -1; n <= 1025; n += 513) {
		mix_signed(&digest, sysfs_path_error_result(n, 0, 1024));
		mix_signed(&digest, sysfs_path_error_result(n, 1, 1024));
	}

	for (unsigned int i = 0; i < sizeof(ops) / sizeof(ops[0]); i++)
		mix_signed(&digest, sysfs_special_kind_result(ops[i]));

	for (ssize_t ssize = -5; ssize <= 5; ssize += 5)
		mix_signed(&digest, sysfs_response_error_result(ssize));
	mix_signed(&digest, sysfs_param_sizes_valid_result(1024, 1024,
		1024, 1024, 1024, 1024));
	mix_signed(&digest, sysfs_param_sizes_valid_result(4097, 1024,
		1024, 1024, 1024, 1024));
	mix(&digest, sysfs_data_bufsize_result());
	for (int send_error = -1; send_error <= 1; send_error++) {
		for (int packet_error = -1; packet_error <= 1; packet_error++)
			mix_signed(&digest, sysfs_packet_error_result(send_error,
				packet_error));
	}
	for (int busy = -1; busy <= 1; busy++)
		mix_signed(&digest, sysfs_request_busy_result(busy));
	for (unsigned long handlep = 0; handlep <= 2; handlep++)
		mix_signed(&digest, sysfs_handle_pointer_valid_result(handlep));
	mix_signed(&digest, sysfs_default_response_ssize_result());
	mix_signed(&digest, sysfs_release_response_error_result());
	for (unsigned int i = 0; i < sizeof(messages) / sizeof(messages[0]); i++)
		mix_signed(&digest, sysfs_request_handler_kind_result(messages[i]));
	for (unsigned long ptr = 0; ptr <= 2; ptr++) {
		mix_signed(&digest, sysfs_pointer_missing_result(ptr));
		mix_signed(&digest, sysfs_should_call_show_result(ptr));
		mix_signed(&digest, sysfs_should_call_store_result(ptr));
		mix_signed(&digest, sysfs_should_call_release_result(ptr));
	}

	struct ikc_scd_packet procfs_packet;
	int procfs_done = 0;
	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	reset_fake_procfs_thread(&procfs_done, 0);
	mix_signed(&digest, procfs_thread_ctl_result((void *)0xcafe,
		&procfs_packet, &procfs_done, SCD_MSG_PROCFS_TID_CREATE,
		3, 7, 1234, 5678, fake_procfs_thread_phys,
		fake_procfs_thread_send, fake_procfs_thread_pause));
	mix_signed(&digest, procfs_done);
	mix_signed(&digest, fake_procfs_thread_send_calls);
	mix_signed(&digest, fake_procfs_thread_pause_calls);
	mix_signed(&digest, fake_procfs_thread_last_channel == (void *)0xcafe);
	mix_signed(&digest, fake_procfs_thread_last_packet == &procfs_packet);
	mix_signed(&digest, procfs_packet.header.channel == NULL);
	mix_signed(&digest, procfs_packet.msg);
	mix_signed(&digest, procfs_packet.err);
	mix_signed(&digest, procfs_packet.reply == NULL);
	mix_signed(&digest, procfs_packet.ref);
	mix_signed(&digest, procfs_packet.osnum);
	mix_signed(&digest, procfs_packet.pid);
	mix_signed(&digest, procfs_packet.arg);
	mix_signed(&digest, procfs_packet.resp_pa);
	mix_signed(&digest, procfs_packet.req.valid);
	mix_signed(&digest, procfs_packet.req.number);
	mix_signed(&digest, procfs_packet.req.args[0]);

	procfs_done = 0;
	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	reset_fake_procfs_thread(&procfs_done, 0);
	mix_signed(&digest, procfs_thread_ctl_result((void *)0xbeef,
		&procfs_packet, &procfs_done, SCD_MSG_PROCFS_TID_DELETE,
		4, 8, 4321, 8765, fake_procfs_thread_phys,
		fake_procfs_thread_send, fake_procfs_thread_pause));
	mix_signed(&digest, procfs_done);
	mix_signed(&digest, fake_procfs_thread_send_calls);
	mix_signed(&digest, fake_procfs_thread_pause_calls);
	mix_signed(&digest, procfs_packet.msg);
	mix_signed(&digest, procfs_packet.ref);
	mix_signed(&digest, procfs_packet.osnum);
	mix_signed(&digest, procfs_packet.pid);
	mix_signed(&digest, procfs_packet.arg);
	mix_signed(&digest, procfs_packet.resp_pa);

	procfs_done = 1;
	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	reset_fake_procfs_thread(&procfs_done, -7);
	mix_signed(&digest, procfs_thread_ctl_result((void *)0xd00d,
		&procfs_packet, &procfs_done, SCD_MSG_PROCFS_TID_CREATE,
		5, 9, 2468, 1357, fake_procfs_thread_phys,
		fake_procfs_thread_send, fake_procfs_thread_pause));
	mix_signed(&digest, fake_procfs_thread_send_calls);
	mix_signed(&digest, fake_procfs_thread_pause_calls);
	mix_signed(&digest, procfs_packet.msg);
	mix_signed(&digest, procfs_packet.ref);
	mix_signed(&digest, procfs_packet.pid);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 42;
	procfs_packet.arg = 0x12345678UL;
	procfs_packet.reply = (void *)0xc001d00dUL;
	procfs_packet.pid = 777;
	reset_fake_procfs_answer();
	mix_signed(&digest, procfs_answer_result((void *)0xabcd,
		&procfs_packet, -22, fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xabcd);
	mix_signed(&digest, fake_procfs_answer_last_header_channel == NULL);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0xc001d00dUL);
	mix(&digest, fake_procfs_answer_last_req_valid);
	mix(&digest, fake_procfs_answer_last_resp_pa);
	mix_signed(&digest, procfs_answer_result((void *)0xabcd,
		NULL, 0, fake_procfs_answer_send));
	mix_signed(&digest, procfs_answer_result((void *)0xabcd,
		&procfs_packet, 0, NULL));

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_proc_result(&fake_host_schedule_thread,
		fake_host_schedule_get_proc) == &fake_host_schedule_proc);
	require(fake_host_schedule_proc_calls == 1);
	mix_signed(&digest, fake_host_schedule_proc_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_proc_result(&fake_host_schedule_thread,
		NULL) == NULL);
	require(fake_host_schedule_proc_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_current_cpu_result(
		fake_host_schedule_get_current_cpu));
	require(fake_host_schedule_current_cpu_calls == 1);
	mix_signed(&digest, fake_host_schedule_current_cpu_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_current_cpu_result(NULL));
	require(fake_host_schedule_current_cpu_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_cpu_allowed_result(
		&fake_host_schedule_thread, 3, fake_host_schedule_cpu_allowed));
	require(fake_host_schedule_cpu_allowed_calls == 1);
	mix_signed(&digest, fake_host_schedule_cpu_allowed_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_cpu_allowed_result(
		&fake_host_schedule_thread, 3, NULL));
	require(fake_host_schedule_cpu_allowed_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_obtain_cpuid_result(
		&fake_host_schedule_thread, fake_host_schedule_obtain_cpu));
	require(fake_host_schedule_obtain_calls == 1);
	mix_signed(&digest, fake_host_schedule_obtain_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_obtain_cpuid_result(
		&fake_host_schedule_thread, NULL));
	require(fake_host_schedule_obtain_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_proc_pid_result(&fake_host_schedule_proc,
		fake_host_schedule_proc_pid));
	require(fake_host_schedule_proc_pid_calls == 1);
	mix_signed(&digest, fake_host_schedule_proc_pid_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_proc_pid_result(&fake_host_schedule_proc, NULL));
	require(fake_host_schedule_proc_pid_calls == 0);

	reset_fake_host_schedule();
	mix(&digest, host_thread_reg_result(&fake_host_schedule_thread,
		fake_host_schedule_pc));
	require(fake_host_schedule_pc_calls == 1);
	mix_signed(&digest, fake_host_schedule_pc_calls);

	reset_fake_host_schedule();
	mix(&digest, host_thread_reg_result(&fake_host_schedule_thread, NULL));
	require(fake_host_schedule_pc_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_invalid_log_result(
		&fake_host_schedule_thread, fake_host_schedule_invalid_log));
	require(fake_host_schedule_invalid_log_calls == 1);
	require(fake_host_schedule_invalid_log_last_thread ==
		&fake_host_schedule_thread);
	mix_signed(&digest, fake_host_schedule_invalid_log_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_invalid_log_result(
		&fake_host_schedule_thread, NULL));
	require(fake_host_schedule_invalid_log_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_received_log_result(
		&fake_host_schedule_thread, 123, 0x456UL, 0x789UL, 4,
		fake_host_schedule_received_log));
	require(fake_host_schedule_received_log_calls == 1);
	require(fake_host_schedule_received_last_thread ==
		&fake_host_schedule_thread);
	require(fake_host_schedule_received_last_pid == 123);
	require(fake_host_schedule_received_last_pc == 0x456UL);
	require(fake_host_schedule_received_last_sp == 0x789UL);
	require(fake_host_schedule_received_last_cpu == 4);
	mix_signed(&digest, fake_host_schedule_received_log_calls);
	mix_signed(&digest, fake_host_schedule_received_last_pid);
	mix(&digest, fake_host_schedule_received_last_pc);
	mix(&digest, fake_host_schedule_received_last_sp);
	mix_signed(&digest, fake_host_schedule_received_last_cpu);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_received_log_result(
		&fake_host_schedule_thread, 123, 0x456UL, 0x789UL, 4, NULL));
	require(fake_host_schedule_received_log_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_no_cpu_log_result(
		fake_host_schedule_no_cpu_log));
	require(fake_host_schedule_no_cpu_log_calls == 1);
	mix_signed(&digest, fake_host_schedule_no_cpu_log_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_no_cpu_log_result(NULL));
	require(fake_host_schedule_no_cpu_log_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_set_tid_result(&fake_host_schedule_thread,
		77, fake_host_schedule_set_tid));
	require(fake_host_schedule_set_tid_calls == 1);
	require(fake_host_schedule_thread.tid == 77);
	mix_signed(&digest, fake_host_schedule_set_tid_calls);
	mix_signed(&digest, fake_host_schedule_thread.tid);

	reset_fake_host_schedule();
	mix_signed(&digest, host_thread_set_tid_result(&fake_host_schedule_thread,
		77, NULL));
	require(fake_host_schedule_set_tid_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_status_set_result(&fake_host_schedule_proc, 8,
		fake_host_schedule_set_proc_status));
	require(fake_host_schedule_set_proc_status_calls == 1);
	require(fake_host_schedule_proc.status == 8);
	mix_signed(&digest, fake_host_schedule_set_proc_status_calls);
	mix_signed(&digest, fake_host_schedule_proc.status);

	reset_fake_host_schedule();
	mix_signed(&digest, host_status_set_result(&fake_host_schedule_proc, 8,
		NULL));
	require(fake_host_schedule_set_proc_status_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_chain_thread_result(&fake_host_schedule_thread,
		fake_host_schedule_chain_thread));
	require(fake_host_schedule_chain_thread_calls == 1);
	mix_signed(&digest, fake_host_schedule_chain_thread_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_chain_thread_result(&fake_host_schedule_thread,
		NULL));
	require(fake_host_schedule_chain_thread_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_chain_process_result(&fake_host_schedule_proc,
		fake_host_schedule_chain_process));
	require(fake_host_schedule_chain_process_calls == 1);
	mix_signed(&digest, fake_host_schedule_chain_process_calls);

	reset_fake_host_schedule();
	mix_signed(&digest, host_chain_process_result(&fake_host_schedule_proc,
		NULL));
	require(fake_host_schedule_chain_process_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_runq_add_thread_result(
		&fake_host_schedule_thread, 6, fake_host_schedule_runq_add));
	require(fake_host_schedule_runq_add_calls == 1);
	require(fake_host_schedule_runq_last_thread == &fake_host_schedule_thread);
	require(fake_host_schedule_runq_last_cpu == 6);
	mix_signed(&digest, fake_host_schedule_runq_add_calls);
	mix_signed(&digest, fake_host_schedule_runq_last_cpu);

	reset_fake_host_schedule();
	mix_signed(&digest, host_runq_add_thread_result(
		&fake_host_schedule_thread, 6, NULL));
	require(fake_host_schedule_runq_add_calls == 0);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_queued_log_result(1, 2, 3, 4,
		fake_host_schedule_queued_log));
	require(fake_host_schedule_queued_log_calls == 1);
	require(fake_host_schedule_queued_last_pid == 1);
	require(fake_host_schedule_queued_last_tid == 2);
	require(fake_host_schedule_queued_last_cpu == 3);
	require(fake_host_schedule_queued_last_status == 4);
	mix_signed(&digest, fake_host_schedule_queued_log_calls);
	mix_signed(&digest, fake_host_schedule_queued_last_pid);
	mix_signed(&digest, fake_host_schedule_queued_last_tid);
	mix_signed(&digest, fake_host_schedule_queued_last_cpu);
	mix_signed(&digest, fake_host_schedule_queued_last_status);

	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_queued_log_result(1, 2, 3, 4, NULL));
	require(fake_host_schedule_queued_log_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.arg = (unsigned long)&fake_host_schedule_thread;
	reset_fake_host_schedule();
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, fake_host_schedule_proc_calls);
	mix_signed(&digest, fake_host_schedule_current_cpu_calls);
	mix_signed(&digest, fake_host_schedule_cpu_allowed_calls);
	mix_signed(&digest, fake_host_schedule_obtain_calls);
	mix_signed(&digest, fake_host_schedule_proc_pid_calls);
	mix_signed(&digest, fake_host_schedule_pc_calls);
	mix_signed(&digest, fake_host_schedule_sp_calls);
	mix_signed(&digest, fake_host_schedule_received_log_calls);
	mix_signed(&digest,
		fake_host_schedule_received_last_thread ==
		&fake_host_schedule_thread);
	mix_signed(&digest, fake_host_schedule_received_last_pid);
	mix(&digest, fake_host_schedule_received_last_pc);
	mix(&digest, fake_host_schedule_received_last_sp);
	mix_signed(&digest, fake_host_schedule_received_last_cpu);
	mix_signed(&digest, fake_host_schedule_set_tid_calls);
	mix_signed(&digest, fake_host_schedule_set_tid_last_tid);
	mix_signed(&digest, fake_host_schedule_thread.tid);
	mix_signed(&digest, fake_host_schedule_proc.status);
	mix_signed(&digest, fake_host_schedule_thread.status);
	mix_signed(&digest, fake_host_schedule_runq_add_calls);
	mix_signed(&digest,
		fake_host_schedule_runq_last_thread ==
		&fake_host_schedule_thread);
	mix_signed(&digest, fake_host_schedule_runq_last_cpu);
	mix_signed(&digest, fake_host_schedule_queued_log_calls);
	mix_signed(&digest, fake_host_schedule_queued_last_pid);
	mix_signed(&digest, fake_host_schedule_queued_last_tid);
	mix_signed(&digest, fake_host_schedule_queued_last_cpu);
	mix_signed(&digest, fake_host_schedule_queued_last_status);
	mix_signed(&digest, fake_host_schedule_set_tid_event <
		fake_host_schedule_set_proc_status_event);
	mix_signed(&digest, fake_host_schedule_set_proc_status_event <
		fake_host_schedule_set_thread_status_event);
	mix_signed(&digest, fake_host_schedule_set_thread_status_event <
		fake_host_schedule_chain_thread_event);
	mix_signed(&digest, fake_host_schedule_chain_thread_event <
		fake_host_schedule_chain_process_event);
	mix_signed(&digest, fake_host_schedule_chain_process_event <
		fake_host_schedule_runq_event);
	mix_signed(&digest, fake_host_schedule_runq_event <
		fake_host_schedule_queued_log_event);

	reset_fake_host_schedule();
	fake_host_schedule_current_cpu = 2;
	fake_host_schedule_thread.allowed_mask = 1UL << 5;
	fake_host_schedule_obtain_cpuid = 5;
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, fake_host_schedule_obtain_calls);
	mix_signed(&digest, fake_host_schedule_runq_last_cpu);
	mix_signed(&digest, fake_host_schedule_no_cpu_log_calls);

	reset_fake_host_schedule();
	fake_host_schedule_current_cpu = 2;
	fake_host_schedule_thread.allowed_mask = 0;
	fake_host_schedule_obtain_cpuid = -1;
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, fake_host_schedule_obtain_calls);
	mix_signed(&digest, fake_host_schedule_no_cpu_log_calls);
	mix_signed(&digest, fake_host_schedule_set_tid_calls);
	mix_signed(&digest, fake_host_schedule_runq_add_calls);

	reset_fake_host_schedule();
	procfs_packet.arg = 0;
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, fake_host_schedule_invalid_log_calls);
	mix_signed(&digest, fake_host_schedule_set_tid_calls);

	reset_fake_host_schedule();
	procfs_packet.arg = (unsigned long)&fake_host_schedule_thread;
	fake_host_schedule_thread.proc = NULL;
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, fake_host_schedule_invalid_log_calls);
	mix_signed(&digest, fake_host_schedule_set_tid_calls);
	mix_signed(&digest, host_schedule_process_request_result(
		NULL, fake_host_schedule_get_proc,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));
	mix_signed(&digest, host_schedule_process_request_result(
		&procfs_packet, NULL,
		fake_host_schedule_get_current_cpu,
		fake_host_schedule_cpu_allowed,
		fake_host_schedule_obtain_cpu,
		fake_host_schedule_proc_pid,
		fake_host_schedule_pc, fake_host_schedule_sp,
		fake_host_schedule_invalid_log,
		fake_host_schedule_received_log,
		fake_host_schedule_no_cpu_log,
		fake_host_schedule_set_tid,
		fake_host_schedule_set_proc_status,
		fake_host_schedule_set_thread_status,
		fake_host_schedule_chain_thread,
		fake_host_schedule_chain_process,
		fake_host_schedule_runq_add,
		fake_host_schedule_queued_log, 1));

	reset_fake_host_remote_page_fault();
	mix_signed(&digest, host_thread_profile_enabled_result(
		(void *)0x515100UL, fake_host_rpf_profile_enabled));
	require(fake_host_rpf_profile_enabled_calls == 1);
	require(fake_host_rpf_profile_last_thread == (void *)0x515100UL);
	mix_signed(&digest, fake_host_rpf_profile_enabled_calls);
	mix_signed(&digest,
		fake_host_rpf_profile_last_thread == (void *)0x515100UL);
	mix_signed(&digest, host_thread_profile_enabled_result(
		(void *)0x515100UL, NULL));
	mix(&digest, host_timestamp_result(fake_host_rpf_timestamp));
	mix_signed(&digest, fake_host_rpf_timestamp_calls);
	mix(&digest, host_timestamp_result(NULL));
	mix_signed(&digest, host_preempt_result(fake_host_rpf_preempt_disable));
	mix_signed(&digest, fake_host_rpf_preempt_disable_calls);
	mix_signed(&digest, host_preempt_result(NULL));
	mix_signed(&digest, host_remote_page_fault_process_result(
		(void *)0x515100UL, 0x7fff33330000UL, 0x41,
		fake_host_rpf_page_fault));
	require(fake_host_rpf_page_fault_calls == 1);
	require(fake_host_rpf_page_fault_last_thread == (void *)0x515100UL);
	mix_signed(&digest, fake_host_rpf_page_fault_calls);
	mix(&digest, fake_host_rpf_page_fault_last_addr);
	mix(&digest, fake_host_rpf_page_fault_last_reason);
	mix_signed(&digest, host_remote_page_fault_process_result(
		(void *)0x515100UL, 0, 0, NULL));
	mix_signed(&digest, host_profile_event_result(
		PROFILE_remote_page_fault, 222, fake_host_rpf_profile_event));
	require(fake_host_rpf_profile_event_calls == 1);
	mix_signed(&digest, fake_host_rpf_profile_event_last_event);
	mix(&digest, fake_host_rpf_profile_event_last_delta);
	mix_signed(&digest, host_profile_event_result(0, 0, NULL));
	mix_signed(&digest, host_remote_page_fault_log_result(
		(void *)0x515100UL, 0x7fff44440000UL, 0x42,
		fake_host_rpf_log));
	require(fake_host_rpf_log_calls == 1);
	mix_signed(&digest, fake_host_rpf_log_calls);
	mix(&digest, fake_host_rpf_log_last_addr);
	mix(&digest, fake_host_rpf_log_last_reason);
	mix_signed(&digest, host_remote_page_fault_log_result(
		(void *)0x515100UL, 0, 0, NULL));

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.ref = 83;
	procfs_packet.fault_tid = 4141;
	procfs_packet.fault_address = 0x7fff55550000UL;
	procfs_packet.fault_reason = 0x43;
	reset_fake_host_remote_page_fault_request();
	void *rpf_alloc_ptr = host_alloc_result(128, 0x44,
		fake_host_rpf_request_alloc);
	require(rpf_alloc_ptr == &fake_host_rpf_request_copy_packet);
	mix_signed(&digest,
		rpf_alloc_ptr == &fake_host_rpf_request_copy_packet);
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix(&digest, fake_host_rpf_request_alloc_last_size);
	mix(&digest, fake_host_rpf_request_alloc_last_flags);
	mix_signed(&digest, host_alloc_result(128, 0x44, NULL) == NULL);
	mix_signed(&digest, host_packet_copy_result(rpf_alloc_ptr,
		&procfs_packet, sizeof(procfs_packet),
		fake_host_rpf_request_copy));
	require(fake_host_rpf_request_copy_calls == 1);
	require(fake_host_rpf_request_copy_packet.ref == 83);
	mix_signed(&digest, fake_host_rpf_request_copy_calls);
	mix_signed(&digest, fake_host_rpf_request_copy_packet.fault_tid);
	mix(&digest, fake_host_rpf_request_copy_packet.fault_address);
	mix_signed(&digest, host_packet_copy_result(rpf_alloc_ptr,
		&procfs_packet, sizeof(procfs_packet), NULL));
	mix_signed(&digest, host_remote_page_fault_defer_result(
		(void *)0x616161UL, rpf_alloc_ptr,
		fake_host_rpf_request_backlog, fake_host_rpf_request_defer));
	require(fake_host_rpf_request_defer_calls == 1);
	require(fake_host_rpf_request_defer_last_thread == (void *)0x616161UL);
	mix_signed(&digest, fake_host_rpf_request_defer_calls);
	mix_signed(&digest, fake_host_rpf_request_defer_last_arg ==
		rpf_alloc_ptr);
	mix_signed(&digest, host_remote_page_fault_defer_result(
		(void *)0x616161UL, rpf_alloc_ptr, NULL,
		fake_host_rpf_request_defer));
	mix_signed(&digest, host_remote_page_fault_defer_result(
		(void *)0x616161UL, rpf_alloc_ptr,
		fake_host_rpf_request_backlog, NULL));
	mix_signed(&digest, host_sched_wakeup_result(
		(void *)0x616161UL, 2, fake_host_rpf_request_wakeup));
	require(fake_host_rpf_request_wakeup_calls == 1);
	mix_signed(&digest, fake_host_rpf_request_wakeup_calls);
	mix_signed(&digest, fake_host_rpf_request_wakeup_last_state);
	mix_signed(&digest, host_sched_wakeup_result(
		(void *)0x616161UL, 2, NULL));
	mix_signed(&digest, host_remote_page_fault_missing_log_result(
		4141, fake_host_rpf_request_missing_log));
	require(fake_host_rpf_request_missing_log_calls == 1);
	mix_signed(&digest, fake_host_rpf_request_missing_log_last_tid);
	mix_signed(&digest, host_remote_page_fault_missing_log_result(
		4141, NULL));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 84;
	procfs_packet.arg = 0xabcdef01UL;
	procfs_packet.reply = (void *)0xfeedfaceUL;
	procfs_packet.pid = 1551;
	reset_fake_procfs_answer();
	mix_signed(&digest, host_remote_page_fault_answer_result((void *)0xbed,
		&procfs_packet, -14, fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xbed);
	mix_signed(&digest, fake_procfs_answer_last_header_channel == NULL);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0xfeedfaceUL);
	mix(&digest, fake_procfs_answer_last_req_valid);
	mix(&digest, fake_procfs_answer_last_resp_pa);
	mix_signed(&digest, host_remote_page_fault_answer_result((void *)0xbed,
		NULL, 0, fake_procfs_answer_send));
	mix_signed(&digest, host_remote_page_fault_answer_result((void *)0xbed,
		&procfs_packet, 0, NULL));

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_procfs_answer_current_result(&procfs_packet,
		-16, fake_host_handler_response_channel,
		fake_procfs_answer_send));
	require(fake_host_handler_response_calls == 1);
	require(fake_procfs_answer_send_calls == 1);
	require(fake_procfs_answer_last_channel == (void *)0x424200UL);
	require(fake_procfs_answer_last_msg == SCD_MSG_PROCFS_ANSWER);
	require(fake_procfs_answer_last_err == -16);
	mix_signed(&digest, fake_host_handler_response_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel ==
		(void *)0x424200UL);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_procfs_answer_current_result(&procfs_packet,
		0, NULL, fake_procfs_answer_send));
	require(fake_host_handler_response_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 85;
	procfs_packet.arg = 0xabcdef02UL;
	procfs_packet.reply = (void *)0xfeedfac1UL;
	procfs_packet.pid = 1552;
	procfs_packet.fault_address = 0x7fff12345000UL;
	procfs_packet.fault_reason = 0x123UL;
	reset_fake_procfs_answer();
	reset_fake_host_remote_page_fault();
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, 0, (void *)0x515100UL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		fake_host_rpf_timestamp, fake_host_rpf_preempt_disable,
		fake_host_rpf_page_fault, fake_host_rpf_preempt_enable,
		fake_host_rpf_profile_event, fake_host_rpf_log,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_rpf_profile_enabled_calls);
	mix_signed(&digest,
		fake_host_rpf_profile_last_thread == (void *)0x515100UL);
	mix_signed(&digest, fake_host_rpf_timestamp_calls);
	mix_signed(&digest, fake_host_rpf_log_calls);
	mix_signed(&digest,
		fake_host_rpf_log_last_thread == (void *)0x515100UL);
	mix(&digest, fake_host_rpf_log_last_addr);
	mix(&digest, fake_host_rpf_log_last_reason);
	mix_signed(&digest, fake_host_rpf_preempt_disable_calls);
	mix_signed(&digest, fake_host_rpf_page_fault_calls);
	mix_signed(&digest,
		fake_host_rpf_page_fault_last_thread == (void *)0x515100UL);
	mix(&digest, fake_host_rpf_page_fault_last_addr);
	mix(&digest, fake_host_rpf_page_fault_last_reason);
	mix_signed(&digest, fake_host_rpf_preempt_enable_calls);
	mix_signed(&digest, fake_host_rpf_profile_event_calls);
	mix_signed(&digest, fake_host_rpf_profile_event_last_event);
	mix(&digest, fake_host_rpf_profile_event_last_delta);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xbeef);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix_signed(&digest, fake_host_rpf_log_event <
		fake_host_rpf_preempt_disable_event);
	mix_signed(&digest, fake_host_rpf_preempt_disable_event <
		fake_host_rpf_page_fault_event);
	mix_signed(&digest, fake_host_rpf_page_fault_event <
		fake_host_rpf_preempt_enable_event);
	mix_signed(&digest, fake_host_rpf_preempt_enable_event <
		fake_host_rpf_profile_event_event);
	mix_signed(&digest, fake_host_rpf_profile_event_event <
		fake_host_rpf_answer_event);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	reset_fake_host_remote_page_fault();
	mix_signed(&digest, host_remote_page_fault_current_result(&procfs_packet,
		0, PF_POPULATE, PROFILE_remote_page_fault,
		fake_host_handler_response_channel,
		fake_host_handler_current_thread,
		fake_host_rpf_profile_enabled, fake_host_rpf_timestamp,
		fake_host_rpf_preempt_disable, fake_host_rpf_page_fault,
		fake_host_rpf_preempt_enable, fake_host_rpf_profile_event,
		fake_host_rpf_log, fake_procfs_answer_send));
	require(fake_host_handler_response_calls == 1);
	require(fake_host_handler_current_calls == 1);
	require(fake_host_rpf_profile_last_thread == (void *)0x515100UL);
	require(fake_host_rpf_page_fault_last_thread == (void *)0x515100UL);
	require(fake_procfs_answer_last_channel == (void *)0x424200UL);
	require(fake_procfs_answer_send_calls == 1);
	mix_signed(&digest, fake_host_handler_response_calls);
	mix_signed(&digest, fake_host_handler_current_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel ==
		(void *)0x424200UL);
	mix_signed(&digest, fake_host_rpf_page_fault_calls);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	reset_fake_host_remote_page_fault();
	mix_signed(&digest, host_remote_page_fault_current_result(&procfs_packet,
		0, PF_POPULATE, PROFILE_remote_page_fault,
		fake_host_handler_response_channel, NULL,
		fake_host_rpf_profile_enabled, fake_host_rpf_timestamp,
		fake_host_rpf_preempt_disable, fake_host_rpf_page_fault,
		fake_host_rpf_preempt_enable, fake_host_rpf_profile_event,
		fake_host_rpf_log, fake_procfs_answer_send));
	require(fake_host_handler_response_calls == 0);
	require(fake_host_handler_current_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	reset_fake_procfs_answer();
	reset_fake_host_remote_page_fault();
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, -22, NULL, PF_POPULATE,
		PROFILE_remote_page_fault, NULL, NULL, NULL, NULL, NULL, NULL,
		NULL, fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_rpf_profile_enabled_calls);
	mix_signed(&digest, fake_host_rpf_page_fault_calls);

	reset_fake_procfs_answer();
	reset_fake_host_remote_page_fault();
	fake_host_rpf_profile_enabled_result = 0;
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, 0, (void *)0x515100UL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		NULL, fake_host_rpf_preempt_disable,
		fake_host_rpf_page_fault, fake_host_rpf_preempt_enable,
		NULL, fake_host_rpf_log, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_rpf_profile_enabled_calls);
	mix_signed(&digest, fake_host_rpf_timestamp_calls);
	mix_signed(&digest, fake_host_rpf_profile_event_calls);
	mix_signed(&digest, fake_host_rpf_page_fault_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		NULL, 0, (void *)0x515100UL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		fake_host_rpf_timestamp, fake_host_rpf_preempt_disable,
		fake_host_rpf_page_fault, fake_host_rpf_preempt_enable,
		fake_host_rpf_profile_event, fake_host_rpf_log,
		fake_procfs_answer_send));
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, 0, NULL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		fake_host_rpf_timestamp, fake_host_rpf_preempt_disable,
		fake_host_rpf_page_fault, fake_host_rpf_preempt_enable,
		fake_host_rpf_profile_event, fake_host_rpf_log,
		fake_procfs_answer_send));
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, 0, (void *)0x515100UL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		fake_host_rpf_timestamp, fake_host_rpf_preempt_disable,
		NULL, fake_host_rpf_preempt_enable,
		fake_host_rpf_profile_event, fake_host_rpf_log,
		fake_procfs_answer_send));
	mix_signed(&digest, host_remote_page_fault_body_result((void *)0xbeef,
		&procfs_packet, 0, (void *)0x515100UL, PF_POPULATE,
		PROFILE_remote_page_fault, fake_host_rpf_profile_enabled,
		fake_host_rpf_timestamp, fake_host_rpf_preempt_disable,
		fake_host_rpf_page_fault, fake_host_rpf_preempt_enable,
		fake_host_rpf_profile_event, fake_host_rpf_log, NULL));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 85;
	procfs_packet.fault_tid = 4000;
	procfs_packet.fault_address = 0x7fff11110000UL;
	procfs_packet.fault_reason = 0x221UL;
	reset_fake_host_remote_page_fault_request();
	mix_signed(&digest, host_remote_page_fault_body_dispatch_result(
		&procfs_packet, -31, fake_host_rpf_request_body));
	require(fake_host_rpf_request_body_calls == 1);
	require(fake_host_rpf_request_body_last_err == -31);
	require(fake_host_rpf_request_body_last_ref == 85);
	require(fake_host_rpf_request_body_last_tid == 4000);
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_body_last_err);
	mix_signed(&digest, fake_host_rpf_request_body_last_ref);
	mix_signed(&digest, fake_host_rpf_request_body_last_tid);

	reset_fake_host_remote_page_fault_request();
	mix_signed(&digest, host_remote_page_fault_body_dispatch_result(
		&procfs_packet, -31, NULL));
	require(fake_host_rpf_request_body_calls == 0);

	reset_fake_host_remote_page_fault_request();
	mix_signed(&digest, host_remote_page_fault_body_dispatch_result(
		NULL, -31, fake_host_rpf_request_body));
	require(fake_host_rpf_request_body_calls == 0);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 86;
	procfs_packet.pid = 1553;
	procfs_packet.fault_tid = 4001;
	procfs_packet.fault_address = 0x7fff22220000UL;
	procfs_packet.fault_reason = 0x321UL;
	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	fake_host_find_thread_missing = 1;
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, fake_host_find_thread, (void *)0x1111,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, fake_host_find_thread_calls);
	mix_signed(&digest, fake_host_find_thread_last_pid);
	mix_signed(&digest, fake_host_find_thread_last_tid);
	mix_signed(&digest, fake_host_rpf_request_missing_log_calls);
	mix_signed(&digest, fake_host_rpf_request_missing_log_last_tid);
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_body_last_err);
	mix_signed(&digest, fake_host_rpf_request_body_last_ref);
	mix_signed(&digest, fake_host_rpf_request_body_last_tid);
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest, fake_host_rpf_request_missing_log_event <
		fake_host_rpf_request_body_event);

	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	fake_host_find_thread_result = (void *)0x515151UL;
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, fake_host_find_thread, (void *)0x515151UL,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_body_last_err);
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix_signed(&digest, fake_host_rpf_request_copy_calls);
	mix_signed(&digest, fake_host_rpf_request_wakeup_calls);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest,
		fake_host_rpf_request_unlock_last_thread == (void *)0x515151UL);
	mix_signed(&digest, fake_host_rpf_request_body_event <
		fake_host_rpf_request_unlock_event);

	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	fake_host_find_thread_result = (void *)0x616161UL;
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, fake_host_find_thread, (void *)0x717171UL,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix(&digest, fake_host_rpf_request_alloc_last_size);
	mix(&digest, fake_host_rpf_request_alloc_last_flags);
	mix_signed(&digest, fake_host_rpf_request_copy_calls);
	mix_signed(&digest, fake_host_rpf_request_copy_last_dst ==
		&fake_host_rpf_request_copy_packet);
	mix_signed(&digest, fake_host_rpf_request_copy_last_src ==
		&procfs_packet);
	mix(&digest, fake_host_rpf_request_copy_last_size);
	mix_signed(&digest, fake_host_rpf_request_copy_packet.ref);
	mix_signed(&digest, fake_host_rpf_request_copy_packet.fault_tid);
	mix(&digest, fake_host_rpf_request_copy_packet.fault_address);
	mix(&digest, fake_host_rpf_request_copy_packet.fault_reason);
	mix_signed(&digest, fake_host_rpf_request_defer_calls);
	mix_signed(&digest, fake_host_rpf_request_defer_last_thread ==
		(void *)0x616161UL);
	mix_signed(&digest, fake_host_rpf_request_defer_last_arg ==
		&fake_host_rpf_request_copy_packet);
	mix_signed(&digest, fake_host_rpf_request_defer_last_backlog ==
		fake_host_rpf_request_backlog);
	mix_signed(&digest, fake_host_rpf_request_wakeup_calls);
	mix_signed(&digest, fake_host_rpf_request_wakeup_last_thread ==
		(void *)0x616161UL);
	mix_signed(&digest, fake_host_rpf_request_wakeup_last_state);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest, fake_host_rpf_request_copy_event <
		fake_host_rpf_request_defer_event);
	mix_signed(&digest, fake_host_rpf_request_defer_event <
		fake_host_rpf_request_wakeup_event);
	mix_signed(&digest, fake_host_rpf_request_wakeup_event <
		fake_host_rpf_request_unlock_event);

	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	fake_host_find_thread_result = (void *)0x616161UL;
	fake_host_rpf_request_alloc_fail = 1;
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, fake_host_find_thread, (void *)0x717171UL,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix_signed(&digest, fake_host_rpf_request_copy_calls);
	mix_signed(&digest, fake_host_rpf_request_wakeup_calls);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest, host_remote_page_fault_request_result(
		NULL, fake_host_find_thread, (void *)0x717171UL,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, NULL, (void *)0x717171UL,
		fake_host_rpf_request_body, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));
	mix_signed(&digest, host_remote_page_fault_request_result(
		&procfs_packet, fake_host_find_thread, (void *)0x717171UL,
		NULL, fake_host_rpf_request_alloc,
		fake_host_rpf_request_copy, fake_host_rpf_request_defer,
		fake_host_rpf_request_wakeup,
		fake_host_rpf_request_unlock,
		fake_host_rpf_request_missing_log,
		fake_host_rpf_request_backlog, sizeof(procfs_packet),
		0x44, 2));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 91;
	procfs_packet.arg = 0x1111222233334444UL;
	procfs_packet.reply = (void *)0xabcdef00UL;
	procfs_packet.pid = 2222;
	reset_fake_procfs_answer();
	mix_signed(&digest, host_traditional_reply_result((void *)0xdad,
		&procfs_packet, SCD_MSG_CLEANUP_FD_RESP, -9,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xdad);
	mix_signed(&digest, fake_procfs_answer_last_header_channel == NULL);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0xabcdef00UL);
	mix(&digest, fake_procfs_answer_last_req_valid);
	mix(&digest, fake_procfs_answer_last_resp_pa);
	reset_fake_procfs_answer();
	mix_signed(&digest, host_traditional_reply_result((void *)0xdad,
		&procfs_packet, SCD_MSG_SEND_SIGNAL_ACK, 0,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, host_traditional_reply_result((void *)0xdad,
		NULL, SCD_MSG_PREPARE_PROCESS_ACKED, 0,
		fake_procfs_answer_send));
	mix_signed(&digest, host_traditional_reply_result((void *)0xdad,
		&procfs_packet, SCD_MSG_CLEANUP_PROCESS_RESP, 0, NULL));

	procfs_packet.msg = SCD_MSG_SEND_SIGNAL_ACK;
	reset_fake_procfs_answer();
	mix_signed(&digest, host_ikc_packet_send_result((void *)0xdac,
		&procfs_packet, fake_procfs_answer_send));
	require(fake_procfs_answer_send_calls == 1);
	require(fake_procfs_answer_last_channel == (void *)0xdac);
	require(fake_procfs_answer_last_msg == SCD_MSG_SEND_SIGNAL_ACK);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xdac);
	mix_signed(&digest, fake_procfs_answer_last_msg);

	reset_fake_procfs_answer();
	mix_signed(&digest, host_ikc_packet_send_result((void *)0xdac,
		&procfs_packet, NULL));
	require(fake_procfs_answer_send_calls == 0);

	reset_fake_procfs_answer();
	mix_signed(&digest, host_ikc_packet_send_result((void *)0xdac,
		NULL, fake_procfs_answer_send));
	require(fake_procfs_answer_send_calls == 0);

	reset_fake_host_cpu_rw();
	{
		struct ihk_os_cpu_register reg;

		memset(&reg, 0, sizeof(reg));
		reg.val = 0x12345678000UL;
		fake_host_cpu_rw_rc = -7;
		mix_signed(&digest, host_cpu_rw_register_result(&reg, 5,
			fake_host_cpu_rw_register));
		require(fake_host_cpu_rw_calls == 1);
		require(fake_host_cpu_rw_last_desc == &reg);
		require(fake_host_cpu_rw_last_op == 5);
		require(reg.val == (0x12345678000UL ^ 0x55aa55aa55aa55aaUL));
		mix_signed(&digest, fake_host_cpu_rw_calls);
		mix_signed(&digest, fake_host_cpu_rw_last_op);
		mix(&digest, reg.val);
		mix_signed(&digest, host_cpu_rw_register_result(&reg, 5, NULL));
	}

	reset_fake_host_cleanup();
	mix_signed(&digest, host_cleanup_process_log_result(
		101, 0x12345000UL, fake_host_cleanup_process_log));
	require(fake_host_cleanup_process_log_calls == 1);
	require(fake_host_cleanup_process_log_last_pid == 101);
	require(fake_host_cleanup_process_log_last_thread == 0x12345000UL);
	mix_signed(&digest, fake_host_cleanup_process_log_calls);
	mix_signed(&digest, fake_host_cleanup_process_log_last_pid);
	mix(&digest, fake_host_cleanup_process_log_last_thread);
	mix_signed(&digest, host_cleanup_process_log_result(
		101, 0x12345000UL, NULL));
	mix_signed(&digest, host_terminate_host_result(
		101, (void *)0xfeed1000UL, fake_host_terminate));
	require(fake_host_terminate_calls == 1);
	require(fake_host_terminate_last_pid == 101);
	require(fake_host_terminate_last_thread == (void *)0xfeed1000UL);
	mix_signed(&digest, fake_host_terminate_calls);
	mix_signed(&digest, fake_host_terminate_last_pid);
	mix_signed(&digest, fake_host_terminate_last_thread ==
		(void *)0xfeed1000UL);
	mix_signed(&digest, host_terminate_host_result(
		101, (void *)0xfeed1000UL, NULL));
	mix_signed(&digest, host_cleanup_fd_log_result(
		202, 33, -22, fake_host_cleanup_fd_log));
	require(fake_host_cleanup_fd_log_calls == 1);
	require(fake_host_cleanup_fd_log_last_pid == 202);
	require(fake_host_cleanup_fd_log_last_fd == 33);
	require(fake_host_cleanup_fd_log_last_err == -22);
	mix_signed(&digest, fake_host_cleanup_fd_log_calls);
	mix_signed(&digest, fake_host_cleanup_fd_log_last_pid);
	mix(&digest, fake_host_cleanup_fd_log_last_fd);
	mix_signed(&digest, fake_host_cleanup_fd_log_last_err);
	mix_signed(&digest, host_cleanup_fd_log_result(202, 33, -22, NULL));

	reset_fake_host_send_signal();
	memset(fake_host_mapped_signal.info, 0x5a,
		sizeof(fake_host_mapped_signal.info));
	fake_host_send_signal_rc = -45;
	mix(&digest, host_do_kill_result(303, 404, 12,
		fake_host_mapped_signal.info, fake_host_do_kill));
	require(fake_host_send_signal_kill_calls == 1);
	require(fake_host_send_signal_kill_last_pid == 303);
	require(fake_host_send_signal_kill_last_tid == 404);
	require(fake_host_send_signal_kill_last_sig == 12);
	require(fake_host_send_signal_info_matches == 1);
	mix_signed(&digest, fake_host_send_signal_kill_calls);
	mix_signed(&digest, fake_host_send_signal_kill_last_pid);
	mix_signed(&digest, fake_host_send_signal_kill_last_tid);
	mix_signed(&digest, fake_host_send_signal_info_matches);
	mix(&digest, host_do_kill_result(303, 404, 12,
		fake_host_mapped_signal.info, NULL));
	mix_signed(&digest, host_send_signal_log_result(
		303, 404, 12, -45, fake_host_send_signal_log));
	require(fake_host_send_signal_log_calls == 1);
	require(fake_host_send_signal_log_last_pid == 303);
	require(fake_host_send_signal_log_last_tid == 404);
	require(fake_host_send_signal_log_last_sig == 12);
	require(fake_host_send_signal_log_last_rc == -45);
	mix_signed(&digest, fake_host_send_signal_log_calls);
	mix_signed(&digest, fake_host_send_signal_log_last_rc);
	mix_signed(&digest, host_send_signal_log_result(
		303, 404, 12, -45, NULL));

	reset_fake_host_wake_syscall();
	fake_host_find_thread_result = (void *)0x515151UL;
	void *found_thread = host_find_thread_result(
		0, 9090, fake_host_find_thread);
	require(found_thread == (void *)0x515151UL);
	require(fake_host_find_thread_calls == 1);
	require(fake_host_find_thread_last_tid == 9090);
	mix_signed(&digest, found_thread == (void *)0x515151UL);
	mix_signed(&digest, fake_host_find_thread_calls);
	mix_signed(&digest, fake_host_find_thread_last_tid);
	mix_signed(&digest, host_find_thread_result(0, 9090, NULL) == NULL);
	mix_signed(&digest, host_wakeup_thread_result(
		found_thread, fake_host_wakeup_thread));
	require(fake_host_wakeup_thread_calls == 1);
	require(fake_host_wakeup_thread_last_thread == found_thread);
	mix_signed(&digest, fake_host_wakeup_thread_calls);
	mix_signed(&digest, fake_host_wakeup_thread_last_thread ==
		found_thread);
	mix_signed(&digest, host_wakeup_thread_result(found_thread, NULL));
	mix_signed(&digest, host_thread_unlock_result(
		found_thread, fake_host_unlock_thread));
	require(fake_host_unlock_thread_calls == 1);
	require(fake_host_unlock_thread_last_thread == found_thread);
	mix_signed(&digest, fake_host_unlock_thread_calls);
	mix_signed(&digest, fake_host_unlock_thread_last_thread ==
		found_thread);
	mix_signed(&digest, host_thread_unlock_result(found_thread, NULL));
	mix_signed(&digest, host_wake_syscall_log_result(
		9090, 1, fake_host_wake_syscall_log));
	require(fake_host_wake_log_calls == 1);
	require(fake_host_wake_log_last_tid == 9090);
	require(fake_host_wake_log_last_found == 1);
	mix_signed(&digest, fake_host_wake_log_calls);
	mix_signed(&digest, fake_host_wake_log_last_found);
	mix_signed(&digest, host_wake_syscall_log_result(9090, 1, NULL));

	reset_fake_host_debug_log();
	mix_signed(&digest, host_debug_log_print_result(
		0x77770000UL, fake_host_debug_print));
	mix_signed(&digest, host_debug_log_result(
		0x77770000UL, fake_host_debug_log));
	require(fake_host_debug_print_calls == 1);
	require(fake_host_debug_log_calls == 1);
	require(fake_host_debug_print_last_code == 0x77770000UL);
	require(fake_host_debug_log_last_code == 0x77770000UL);
	mix_signed(&digest, fake_host_debug_print_calls);
	mix_signed(&digest, fake_host_debug_log_calls);
	mix(&digest, fake_host_debug_print_last_code);
	mix(&digest, fake_host_debug_log_last_code);
	mix_signed(&digest, host_debug_log_print_result(0x77770000UL, NULL));
	mix_signed(&digest, host_debug_log_result(0x77770000UL, NULL));

	reset_fake_host_mapping();
	mix(&digest, host_map_memory_result((void *)0xabc, 0x550000UL,
		0x6000UL, fake_host_map_memory));
	require(fake_host_map_memory_calls == 1);
	require(fake_host_map_last_in_phys == 0x550000UL);
	require(fake_host_map_last_size == 0x6000UL);
	mix_signed(&digest, fake_host_map_memory_calls);
	mix(&digest, fake_host_map_last_in_phys);
	mix(&digest, fake_host_map_last_size);

	reset_fake_host_mapping();
	mix(&digest, host_map_memory_result((void *)0xabc, 0x550000UL,
		0x6000UL, NULL));
	require(fake_host_map_memory_calls == 0);

	reset_fake_host_mapping();
	mix_signed(&digest, host_map_virtual_result(0x440000UL, 3, 0x55,
		fake_host_map_virtual) == fake_host_map_virtual_result);
	require(fake_host_map_virtual_calls == 1);
	require(fake_host_map_virtual_last_phys == 0x440000UL);
	require(fake_host_map_virtual_last_npages == 3);
	require(fake_host_map_virtual_last_attr == 0x55);
	mix_signed(&digest, fake_host_map_virtual_calls);
	mix(&digest, fake_host_map_virtual_last_phys);
	mix_signed(&digest, fake_host_map_virtual_last_npages);
	mix_signed(&digest, fake_host_map_virtual_last_attr);

	reset_fake_host_mapping();
	mix_signed(&digest, host_map_virtual_result(0x440000UL, 3, 0x55,
		NULL) == NULL);
	require(fake_host_map_virtual_calls == 0);

	reset_fake_host_mapping();
	mix_signed(&digest, host_prepare_map_virtual_result(0x450000UL, 4,
		0x66UL, fake_host_prepare_map_virtual) ==
		fake_host_map_virtual_result);
	require(fake_host_map_virtual_calls == 1);
	require(fake_host_map_virtual_last_phys == 0x450000UL);
	require(fake_host_map_virtual_last_npages == 4);
	require(fake_host_map_virtual_last_attr == 0x66);
	mix_signed(&digest, fake_host_map_virtual_calls);
	mix(&digest, fake_host_map_virtual_last_phys);
	mix_signed(&digest, fake_host_map_virtual_last_npages);
	mix_signed(&digest, fake_host_map_virtual_last_attr);

	reset_fake_host_mapping();
	mix_signed(&digest, host_prepare_map_virtual_result(0x450000UL, 4,
		0x66UL, NULL) == NULL);
	require(fake_host_map_virtual_calls == 0);

	reset_fake_host_mapping();
	mix_signed(&digest, host_unmap_virtual_result((void *)0x660000UL, 4,
		fake_host_unmap_virtual));
	require(fake_host_unmap_virtual_calls == 1);
	require(fake_host_unmap_virtual_last_addr == (void *)0x660000UL);
	require(fake_host_unmap_virtual_last_npages == 4);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_virtual_last_addr ==
		(void *)0x660000UL);
	mix_signed(&digest, fake_host_unmap_virtual_last_npages);

	reset_fake_host_mapping();
	mix_signed(&digest, host_unmap_virtual_result((void *)0x660000UL, 4,
		NULL));
	require(fake_host_unmap_virtual_calls == 0);

	reset_fake_host_mapping();
	mix_signed(&digest, host_unmap_memory_result((void *)0xabc, 0x770000UL,
		0x8000UL, fake_host_unmap_memory));
	require(fake_host_unmap_memory_calls == 1);
	require(fake_host_unmap_memory_last_phys == 0x770000UL);
	require(fake_host_unmap_memory_last_size == 0x8000UL);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix(&digest, fake_host_unmap_memory_last_phys);
	mix(&digest, fake_host_unmap_memory_last_size);

	reset_fake_host_mapping();
	mix_signed(&digest, host_unmap_memory_result((void *)0xabc, 0x770000UL,
		0x8000UL, NULL));
	require(fake_host_unmap_memory_calls == 0);

	reset_fake_host_prepare();
	{
		void *range_out = NULL;

		mix_signed(&digest, host_prepare_add_range_result(
			(void *)0x1234, 0x1000UL, 0x3000UL, 0x9000UL,
			0x55UL, PAGE_SHIFT, &range_out,
			fake_host_prepare_add_range));
		require(fake_host_prepare_add_range_calls == 1);
		require(fake_host_prepare_add_range_last_vm == (void *)0x1234);
		require(fake_host_prepare_add_range_last_start == 0x1000UL);
		require(fake_host_prepare_add_range_last_end == 0x3000UL);
		require(fake_host_prepare_add_range_last_phys == 0x9000UL);
		require(fake_host_prepare_add_range_last_flag == 0x55UL);
		require(fake_host_prepare_add_range_last_pgshift == PAGE_SHIFT);
		require(range_out != NULL);
		mix_signed(&digest, fake_host_prepare_add_range_calls);
		mix(&digest, fake_host_prepare_add_range_last_start);
		mix(&digest, fake_host_prepare_add_range_last_end);
		mix_signed(&digest, range_out != NULL);
	}

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_add_range_result((void *)0x1234,
		0x1000UL, 0x3000UL, 0x9000UL, 0x55UL, PAGE_SHIFT, NULL,
		NULL));
	require(fake_host_prepare_add_range_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_alloc_pages_user_result(2, 0x77UL,
		0x4000UL, fake_host_prepare_alloc_pages_user) ==
		fake_host_prepare_page_pool[0]);
	require(fake_host_prepare_alloc_pages_calls == 1);
	require(fake_host_prepare_alloc_pages_last_npages == 2);
	require(fake_host_prepare_alloc_pages_last_flags == 0x77UL);
	require(fake_host_prepare_alloc_pages_last_addr == 0x4000UL);
	mix_signed(&digest, fake_host_prepare_alloc_pages_calls);
	mix_signed(&digest, fake_host_prepare_alloc_pages_last_npages);
	mix(&digest, fake_host_prepare_alloc_pages_last_flags);
	mix(&digest, fake_host_prepare_alloc_pages_last_addr);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_alloc_pages_user_result(2, 0x77UL,
		0x4000UL, NULL) == NULL);
	require(fake_host_prepare_alloc_pages_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_free_pages_user_result(
		fake_host_prepare_page_pool[1], 3,
		fake_host_prepare_free_pages_user));
	require(fake_host_prepare_free_pages_calls == 1);
	require(fake_host_prepare_free_pages_last_addr ==
		fake_host_prepare_page_pool[1]);
	require(fake_host_prepare_free_pages_last_npages == 3);
	mix_signed(&digest, fake_host_prepare_free_pages_calls);
	mix_signed(&digest, fake_host_prepare_free_pages_last_addr ==
		fake_host_prepare_page_pool[1]);
	mix_signed(&digest, fake_host_prepare_free_pages_last_npages);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_free_pages_user_result(
		fake_host_prepare_page_pool[1], 3, NULL));
	require(fake_host_prepare_free_pages_calls == 0);

	reset_fake_host_prepare();
	{
		unsigned long phys = host_virt_to_phys_result(
			fake_host_prepare_page_pool[2],
			fake_host_prepare_virt_to_phys);

		require(phys - (unsigned long)(uintptr_t)fake_host_prepare_page_pool[2] ==
			0x100000000UL);
		mix(&digest, phys - (unsigned long)(uintptr_t)fake_host_prepare_page_pool[2]);
	}
	require(fake_host_prepare_virt_to_phys_calls == 1);
	require(fake_host_prepare_virt_to_phys_last_addr ==
		fake_host_prepare_page_pool[2]);
	mix_signed(&digest, fake_host_prepare_virt_to_phys_calls);
	mix_signed(&digest, fake_host_prepare_virt_to_phys_last_addr ==
		fake_host_prepare_page_pool[2]);

	reset_fake_host_prepare();
	mix(&digest, host_virt_to_phys_result(fake_host_prepare_page_pool[2],
		NULL));
	require(fake_host_prepare_virt_to_phys_calls == 0);

	reset_fake_host_prepare();
	mix(&digest, host_arch_vrflag_to_ptattr_result(0x5aUL, 0x33UL,
		(void *)0x7000, fake_host_prepare_arch_vrflag_to_ptattr));
	require(fake_host_prepare_ptattr_calls == 1);
	require(fake_host_prepare_ptattr_last_flag == 0x5aUL);
	require(fake_host_prepare_ptattr_last_fault == 0x33UL);
	mix_signed(&digest, fake_host_prepare_ptattr_calls);
	mix(&digest, fake_host_prepare_ptattr_last_flag);
	mix(&digest, fake_host_prepare_ptattr_last_fault);

	reset_fake_host_prepare();
	mix(&digest, host_arch_vrflag_to_ptattr_result(0x5aUL, 0x33UL,
		(void *)0x7000, NULL));
	require(fake_host_prepare_ptattr_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_pt_set_range_result((void *)0x11,
		(void *)0x22, 0x1000UL, 0x2000UL, 0x3000UL, 0x44UL,
		PAGE_SHIFT, (void *)0x55, 0,
		fake_host_prepare_pt_set_range));
	require(fake_host_prepare_pt_set_calls == 1);
	require(fake_host_prepare_pt_set_last_pt == (void *)0x11);
	require(fake_host_prepare_pt_set_last_vm == (void *)0x22);
	require(fake_host_prepare_pt_set_last_start == 0x1000UL);
	require(fake_host_prepare_pt_set_last_end == 0x2000UL);
	require(fake_host_prepare_pt_set_last_phys == 0x3000UL);
	require(fake_host_prepare_pt_set_last_attr == 0x44UL);
	require(fake_host_prepare_pt_set_last_pgshift == PAGE_SHIFT);
	require(fake_host_prepare_pt_set_last_range == (void *)0x55);
	mix_signed(&digest, fake_host_prepare_pt_set_calls);
	mix(&digest, fake_host_prepare_pt_set_last_attr);
	mix_signed(&digest, fake_host_prepare_pt_set_last_range == (void *)0x55);

	reset_fake_host_prepare();
	mix_signed(&digest, host_pt_set_range_result((void *)0x11,
		(void *)0x22, 0x1000UL, 0x2000UL, 0x3000UL, 0x44UL,
		PAGE_SHIFT, (void *)0x55, 0, NULL));
	require(fake_host_prepare_pt_set_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_modify_user_context_result((void *)0x8888,
		9, 0x123456UL, fake_host_prepare_modify_user_context));
	require(fake_host_prepare_modify_context_calls == 1);
	require(fake_host_prepare_modify_context_last_uctx == (void *)0x8888);
	require(fake_host_prepare_modify_context_last_reg == 9);
	require(fake_host_prepare_modify_context_last_value == 0x123456UL);
	mix_signed(&digest, fake_host_prepare_modify_context_calls);
	mix_signed(&digest, fake_host_prepare_modify_context_last_reg);
	mix(&digest, fake_host_prepare_modify_context_last_value);

	reset_fake_host_prepare();
	mix_signed(&digest, host_modify_user_context_result((void *)0x8888,
		9, 0x123456UL, NULL));
	require(fake_host_prepare_modify_context_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_alloc_result(128, 0x44UL,
		fake_host_prepare_alloc) == fake_host_prepare_clone);
	require(fake_host_prepare_alloc_calls == 1);
	require(fake_host_prepare_alloc_last_size == 128);
	require(fake_host_prepare_alloc_last_flags == 0x44UL);
	mix_signed(&digest, fake_host_prepare_alloc_calls);
	mix(&digest, fake_host_prepare_alloc_last_size);
	mix(&digest, fake_host_prepare_alloc_last_flags);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_alloc_result(128, 0x44UL, NULL) ==
		NULL);
	require(fake_host_prepare_alloc_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_free_result(fake_host_prepare_clone,
		fake_host_prepare_free));
	require(fake_host_prepare_free_calls == 1);
	require(fake_host_prepare_free_last_ptr == fake_host_prepare_clone);
	mix_signed(&digest, fake_host_prepare_free_calls);
	mix_signed(&digest, fake_host_prepare_free_last_ptr ==
		fake_host_prepare_clone);

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_free_result(fake_host_prepare_clone,
		NULL));
	require(fake_host_prepare_free_calls == 0);

	reset_fake_host_prepare();
	{
		unsigned char src[8] = { 1, 2, 3, 4, 5, 6, 7, 8 };
		unsigned char dst[8] = { 0 };

		mix_signed(&digest, host_prepare_copy_long_result(dst, src,
			sizeof(src), fake_host_prepare_copy_long));
		require(fake_host_prepare_copy_calls == 1);
		require(fake_host_prepare_copy_last_size == sizeof(src));
		require(!memcmp(dst, src, sizeof(src)));
		mix_signed(&digest, fake_host_prepare_copy_calls);
		mix(&digest, dst[3]);
	}

	reset_fake_host_prepare();
	mix_signed(&digest, host_prepare_copy_long_result(fake_host_prepare_clone,
		fake_host_prepare_page_pool[0], 4, NULL));
	require(fake_host_prepare_copy_calls == 0);

	reset_fake_host_prepare();
	{
		unsigned long cpuset[2] = { 0x1UL, 0x2UL };

		mix_signed(&digest, host_create_thread_result(0xdeadbeefUL,
			cpuset, sizeof(cpuset), fake_host_prepare_create_thread) ==
			fake_host_prepare_thread);
		require(fake_host_prepare_create_calls == 1);
		require(fake_host_prepare_create_last_entry == 0xdeadbeefUL);
		require(fake_host_prepare_create_last_cpuset == cpuset);
		require(fake_host_prepare_create_last_cpuset_size == sizeof(cpuset));
		mix_signed(&digest, fake_host_prepare_create_calls);
		mix(&digest, fake_host_prepare_create_last_entry);
		mix_signed(&digest, fake_host_prepare_create_last_cpuset == cpuset);
	}

	reset_fake_host_prepare();
	mix_signed(&digest, host_create_thread_result(0xdeadbeefUL, NULL, 0,
		NULL) == NULL);
	require(fake_host_prepare_create_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_destroy_thread_result(fake_host_prepare_thread,
		fake_host_prepare_destroy_thread));
	require(fake_host_prepare_destroy_calls == 1);
	mix_signed(&digest, fake_host_prepare_destroy_calls);

	reset_fake_host_prepare();
	mix_signed(&digest, host_destroy_thread_result(fake_host_prepare_thread,
		NULL));
	require(fake_host_prepare_destroy_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_nr_numa_nodes_result(
		fake_host_prepare_nr_numa_nodes_fn));
	require(fake_host_prepare_nr_numa_calls == 1);
	mix_signed(&digest, fake_host_prepare_nr_numa_calls);

	reset_fake_host_prepare();
	mix_signed(&digest, host_nr_numa_nodes_result(NULL));
	require(fake_host_prepare_nr_numa_calls == 0);

	reset_fake_host_prepare();
	mix_signed(&digest, host_flush_tlb_result(fake_host_prepare_flush_tlb));
	require(fake_host_prepare_flush_calls == 1);
	mix_signed(&digest, fake_host_prepare_flush_calls);

	reset_fake_host_prepare();
	mix_signed(&digest, host_flush_tlb_result(NULL));
	require(fake_host_prepare_flush_calls == 0);

	reset_fake_host_prepare();
	fake_host_prepare_args_vdso_rc = -33;
	mix_signed(&digest, host_arch_map_vdso_result(fake_host_prepare_vm,
		fake_host_prepare_args_arch_map_vdso));
	require(fake_host_prepare_args_vdso_calls == 1);
	require(fake_host_prepare_args_vdso_last_vm == fake_host_prepare_vm);
	mix_signed(&digest, fake_host_prepare_args_vdso_calls);

	reset_fake_host_prepare();
	mix_signed(&digest, host_arch_map_vdso_result(fake_host_prepare_vm,
		NULL));
	require(fake_host_prepare_args_vdso_calls == 0);

	reset_fake_host_prepare();
	{
		char *argv[2] = { (char *)0x111, NULL };
		char *env[2] = { (char *)0x222, NULL };

		mix_signed(&digest, host_init_process_stack_result(
			fake_host_prepare_thread, &fake_host_prepare_desc,
			0xabc000UL, 1, argv, 1, env,
			fake_host_prepare_args_init_stack));
		require(fake_host_prepare_args_init_calls == 1);
		require(fake_host_prepare_args_init_last_thread ==
			fake_host_prepare_thread);
		require(fake_host_prepare_args_init_last_pn ==
			&fake_host_prepare_desc);
		require(fake_host_prepare_args_init_last_at_base == 0xabc000UL);
		require(fake_host_prepare_args_init_last_argc == 1);
		require(fake_host_prepare_args_init_last_envc == 1);
		require(fake_host_prepare_args_init_last_argv0 == 0x111UL);
		require(fake_host_prepare_args_init_last_env0 == 0x222UL);
		mix_signed(&digest, fake_host_prepare_args_init_calls);
		mix(&digest, fake_host_prepare_args_init_last_at_base);
	}

	reset_fake_host_prepare();
	mix_signed(&digest, host_init_process_stack_result(
		fake_host_prepare_thread, &fake_host_prepare_desc, 0xabc000UL,
		0, NULL, 0, NULL, NULL));
	require(fake_host_prepare_args_init_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_init_ack_log_result(
		fake_host_dispatch_init_ack_log));
	require(fake_host_dispatch_init_ack_log_calls == 1);
	mix_signed(&digest, fake_host_dispatch_init_ack_log_calls);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_init_ack_log_result(NULL));
	require(fake_host_dispatch_init_ack_log_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.arg = 0x22221111UL;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_schedule_process_log_result(&procfs_packet,
		fake_host_schedule_process_log));
	require(fake_host_dispatch_schedule_log_calls == 1);
	require(fake_host_dispatch_schedule_last_arg == 0x22221111UL);
	mix_signed(&digest, fake_host_dispatch_schedule_log_calls);
	mix(&digest, fake_host_dispatch_schedule_last_arg);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_schedule_process_log_result(&procfs_packet,
		NULL));
	require(fake_host_dispatch_schedule_log_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_schedule_process_log_result(NULL,
		fake_host_schedule_process_log));
	require(fake_host_dispatch_schedule_log_calls == 0);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 92;
	procfs_packet.arg = 0x2222333344445555UL;
	procfs_packet.reply = (void *)0xabcdef01UL;
	procfs_packet.pid = 2223;
	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	fake_host_dispatch_prepare_rc = -18;
	mix_signed(&digest, host_prepare_process_request_result((void *)0xdaf,
		&procfs_packet, fake_host_prepare_process_call,
		fake_procfs_answer_send));
	require(fake_host_dispatch_prepare_calls == 1);
	require(fake_host_dispatch_prepare_last_arg == 0x2222333344445555UL);
	require(fake_procfs_answer_send_calls == 1);
	require(fake_procfs_answer_last_channel == (void *)0xdaf);
	require(fake_procfs_answer_last_msg == SCD_MSG_PREPARE_PROCESS_ACKED);
	require(fake_procfs_answer_last_err == -18);
	mix_signed(&digest, fake_host_dispatch_prepare_calls);
	mix(&digest, fake_host_dispatch_prepare_last_arg);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xdaf);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_prepare_process_request_result((void *)0xdaf,
		&procfs_packet, NULL, fake_procfs_answer_send));
	require(fake_host_dispatch_prepare_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_prepare_process_request_result((void *)0xdaf,
		NULL, fake_host_prepare_process_call, fake_procfs_answer_send));
	require(fake_host_dispatch_prepare_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 93;
	procfs_packet.arg = 0x3132333435363738UL;
	procfs_packet.reply = (void *)0xabcdef02UL;
	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	fake_host_dispatch_prepare_rc = -21;
	mix_signed(&digest, host_response_packet_result((void *)0xdb0,
		&procfs_packet, fake_host_dispatch_prepare_process));
	require(fake_host_dispatch_prepare_calls == 1);
	require(fake_host_dispatch_prepare_last_arg == 0x3132333435363738UL);
	require(fake_procfs_answer_last_channel == (void *)0xdb0);
	require(fake_procfs_answer_last_err == -21);
	mix_signed(&digest, fake_host_dispatch_prepare_calls);
	mix_signed(&digest,
		fake_procfs_answer_last_channel == (void *)0xdb0);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_response_packet_result((void *)0xdb0,
		&procfs_packet, NULL));
	require(fake_host_dispatch_prepare_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_response_packet_result((void *)0xdb0,
		NULL, fake_host_dispatch_prepare_process));
	require(fake_host_dispatch_prepare_calls == 0);
	require(fake_procfs_answer_send_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.arg = 0x70090000UL;
	reset_fake_host_dispatch();
	reset_fake_host_debug_log();
	mix_signed(&digest, host_packet_dispatch_result(&procfs_packet,
		fake_host_dispatch_debug_log));
	require(fake_host_debug_print_calls == 1);
	require(fake_host_debug_log_calls == 1);
	require(fake_host_debug_log_last_code == 0x70090000UL);
	mix_signed(&digest, fake_host_debug_print_calls);
	mix_signed(&digest, fake_host_debug_log_calls);
	mix(&digest, fake_host_debug_log_last_code);

	reset_fake_host_debug_log();
	mix_signed(&digest, host_packet_dispatch_result(&procfs_packet, NULL));
	require(fake_host_debug_log_calls == 0);

	reset_fake_host_debug_log();
	mix_signed(&digest, host_packet_dispatch_result(NULL,
		fake_host_dispatch_debug_log));
	require(fake_host_debug_log_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_REMOTE_PAGE_FAULT;
	procfs_packet.ref = 94;
	procfs_packet.fault_tid = 9090;
	procfs_packet.fault_address = 0x90900000UL;
	procfs_packet.fault_reason = 0x82;
	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	fake_host_find_thread_result = (void *)0x909090UL;
	mix_signed(&digest, host_remote_page_fault_dispatch_result(
		&procfs_packet, (void *)0x909090UL,
		fake_host_dispatch_remote_page_fault));
	require(fake_host_find_thread_last_tid == 9090);
	require(fake_host_rpf_request_body_calls == 1);
	require(fake_host_rpf_request_unlock_calls == 1);
	mix_signed(&digest, fake_host_find_thread_last_tid);
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);

	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	mix_signed(&digest, host_remote_page_fault_dispatch_result(
		&procfs_packet, (void *)0x909090UL, NULL));
	require(fake_host_rpf_request_body_calls == 0);

	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	mix_signed(&digest, host_remote_page_fault_dispatch_result(
		NULL, (void *)0x909090UL,
		fake_host_dispatch_remote_page_fault));
	require(fake_host_rpf_request_body_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PROCFS_REQUEST;
	reset_fake_host_dispatch();
	fake_host_dispatch_procfs_rc = -23;
	mix_signed(&digest, host_procfs_request_result(&procfs_packet,
		fake_host_dispatch_procfs_request));
	require(fake_host_dispatch_procfs_calls == 1);
	require(fake_host_dispatch_procfs_last_packet == &procfs_packet);
	require(fake_host_dispatch_procfs_last_msg == SCD_MSG_PROCFS_REQUEST);
	mix_signed(&digest, fake_host_dispatch_procfs_calls);
	mix_signed(&digest, fake_host_dispatch_procfs_last_msg);
	mix_signed(&digest,
		fake_host_dispatch_procfs_last_packet == &procfs_packet);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_procfs_request_result(&procfs_packet, NULL));
	require(fake_host_dispatch_procfs_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_procfs_request_result(NULL,
		fake_host_dispatch_procfs_request));
	require(fake_host_dispatch_procfs_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PROCFS_RELEASE;
	reset_fake_host_dispatch();
	fake_host_dispatch_procfs_rc = -63;
	mix_signed(&digest, host_procfs_packet_dispatch_result(&procfs_packet,
		fake_host_dispatch_procfs_request));
	require(fake_host_dispatch_procfs_calls == 1);
	require(fake_host_dispatch_procfs_last_packet == &procfs_packet);
	require(fake_host_dispatch_procfs_last_msg == SCD_MSG_PROCFS_RELEASE);
	mix_signed(&digest, fake_host_dispatch_procfs_calls);
	mix_signed(&digest, fake_host_dispatch_procfs_last_msg);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_procfs_packet_dispatch_result(&procfs_packet,
		NULL));
	require(fake_host_dispatch_procfs_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_procfs_packet_dispatch_result(NULL,
		fake_host_dispatch_procfs_request));
	require(fake_host_dispatch_procfs_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_sysfs_packet_result((void *)0xdbe,
		SCD_MSG_SYSFS_REQ_RELEASE, -24, 0x2401, 0x2402, 0x2403,
		fake_host_dispatch_sysfs_packet));
	require(fake_host_dispatch_sysfs_calls == 1);
	require(fake_host_dispatch_sysfs_last_channel == (void *)0xdbe);
	require(fake_host_dispatch_sysfs_last_msg == SCD_MSG_SYSFS_REQ_RELEASE);
	require(fake_host_dispatch_sysfs_last_err == -24);
	require(fake_host_dispatch_sysfs_last_arg1 == 0x2401);
	require(fake_host_dispatch_sysfs_last_arg2 == 0x2402);
	require(fake_host_dispatch_sysfs_last_arg3 == 0x2403);
	mix_signed(&digest, fake_host_dispatch_sysfs_calls);
	mix_signed(&digest,
		fake_host_dispatch_sysfs_last_channel == (void *)0xdbe);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_msg);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_err);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg1);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg2);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg3);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_sysfs_packet_result((void *)0xdbe,
		SCD_MSG_SYSFS_REQ_RELEASE, -24, 0x2401, 0x2402, 0x2403,
		NULL));
	require(fake_host_dispatch_sysfs_calls == 0);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = 0x4242;
	procfs_packet.ref = 424;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_unknown_packet_log_result(&procfs_packet,
		fake_host_dispatch_unknown_packet));
	require(fake_host_dispatch_unknown_calls == 1);
	require(fake_host_dispatch_unknown_last_msg == 0x4242);
	require(fake_host_dispatch_unknown_last_ref == 424);
	mix_signed(&digest, fake_host_dispatch_unknown_calls);
	mix_signed(&digest, fake_host_dispatch_unknown_last_msg);
	mix_signed(&digest, fake_host_dispatch_unknown_last_ref);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_unknown_packet_log_result(&procfs_packet, NULL));
	require(fake_host_dispatch_unknown_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_unknown_packet_log_result(NULL,
		fake_host_dispatch_unknown_packet));
	require(fake_host_dispatch_unknown_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_result(&procfs_packet,
		fake_host_dispatch_release_packet));
	require(fake_host_dispatch_release_calls == 1);
	require(fake_host_dispatch_release_last_packet == &procfs_packet);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest,
		fake_host_dispatch_release_last_packet == &procfs_packet);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_result(&procfs_packet, NULL));
	require(fake_host_dispatch_release_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_result(NULL,
		fake_host_dispatch_release_packet));
	require(fake_host_dispatch_release_calls == 0);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_dispatch_result(&procfs_packet,
		fake_host_dispatch_release_packet));
	require(fake_host_dispatch_release_calls == 1);
	require(fake_host_dispatch_release_last_packet == &procfs_packet);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest,
		fake_host_dispatch_release_last_packet == &procfs_packet);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_dispatch_result(NULL,
		fake_host_dispatch_release_packet));
	require(fake_host_dispatch_release_calls == 1);
	require(fake_host_dispatch_release_last_packet == NULL);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest, fake_host_dispatch_release_last_packet == NULL);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_release_packet_dispatch_result(&procfs_packet,
		NULL));
	require(fake_host_dispatch_release_calls == 0);

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 1234;
	procfs_packet.arg = 0x445566778899aabbUL;
	procfs_packet.reply = (void *)0x98765000UL;
	procfs_packet.pid = 3333;
	reset_fake_procfs_answer();
	mix_signed(&digest, host_arg_reply_result((void *)0xeef,
		&procfs_packet, SCD_MSG_PERF_ACK, -5,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xeef);
	mix_signed(&digest, fake_procfs_answer_last_header_channel == NULL);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0x98765000UL);
	mix(&digest, fake_procfs_answer_last_req_valid);
	mix(&digest, fake_procfs_answer_last_resp_pa);
	mix_signed(&digest, host_arg_reply_result((void *)0xeef,
		NULL, SCD_MSG_PERF_ACK, 0, fake_procfs_answer_send));
	mix_signed(&digest, host_arg_reply_result((void *)0xeef,
		&procfs_packet, SCD_MSG_PERF_ACK, 0, NULL));

	reset_fake_procfs_answer();
	mix_signed(&digest, host_reply_only_result((void *)0xf00,
		&procfs_packet, SCD_MSG_CPU_RW_REG_RESP, -16,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xf00);
	mix_signed(&digest, fake_procfs_answer_last_header_channel == NULL);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_procfs_answer_last_ref);
	mix_signed(&digest, fake_procfs_answer_last_pid);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0x98765000UL);
	mix(&digest, fake_procfs_answer_last_req_valid);
	mix(&digest, fake_procfs_answer_last_resp_pa);
	mix_signed(&digest, host_reply_only_result((void *)0xf00,
		NULL, SCD_MSG_CPU_RW_REG_RESP, 0, fake_procfs_answer_send));
	mix_signed(&digest, host_reply_only_result((void *)0xf00,
		&procfs_packet, SCD_MSG_CPU_RW_REG_RESP, 0, NULL));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.pid = 2468;
	procfs_packet.arg = 0xfeedbeefUL;
	procfs_packet.reply = (void *)0xface1111UL;
	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	fake_host_cleanup_process_rc = -31;
	mix_signed(&digest, host_cleanup_process_request_result((void *)0xc10,
		&procfs_packet, fake_host_cleanup_process,
		fake_host_terminate, fake_host_cleanup_process_log,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cleanup_process_log_calls);
	mix_signed(&digest, fake_host_cleanup_process_log_last_pid);
	mix(&digest, fake_host_cleanup_process_log_last_thread);
	mix_signed(&digest, fake_host_cleanup_process_calls);
	mix_signed(&digest, fake_host_cleanup_process_last_pid);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xc10);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0xface1111UL);
	mix_signed(&digest, fake_host_terminate_calls);
	mix_signed(&digest, fake_host_terminate_last_pid);
	mix_signed(&digest,
		fake_host_terminate_last_thread == (void *)0xfeedbeefUL);
	mix_signed(&digest, fake_host_cleanup_process_log_event);
	mix_signed(&digest, fake_host_cleanup_process_event);
	mix_signed(&digest, fake_host_reply_event);
	mix_signed(&digest, fake_host_terminate_event);

	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_cleanup_process_request_result((void *)0xc10,
		&procfs_packet, fake_host_cleanup_process,
		fake_host_terminate, NULL, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cleanup_process_log_calls);
	mix_signed(&digest, fake_host_cleanup_process_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_host_terminate_calls);
	mix_signed(&digest, host_cleanup_process_request_result((void *)0xc10,
		NULL, fake_host_cleanup_process, fake_host_terminate,
		fake_host_cleanup_process_log, fake_procfs_answer_send));
	mix_signed(&digest, host_cleanup_process_request_result((void *)0xc10,
		&procfs_packet, NULL, fake_host_terminate,
		fake_host_cleanup_process_log, fake_procfs_answer_send));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.pid = 1357;
	procfs_packet.arg = 19;
	procfs_packet.reply = (void *)0xface2222UL;
	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	fake_host_cleanup_fd_rc = -44;
	mix_signed(&digest, host_cleanup_fd_request_result((void *)0xfd0,
		&procfs_packet, fake_host_cleanup_fd,
		fake_host_cleanup_fd_log, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cleanup_fd_calls);
	mix_signed(&digest, fake_host_cleanup_fd_last_pid);
	mix_signed(&digest, fake_host_cleanup_fd_last_fd);
	mix_signed(&digest, fake_host_cleanup_fd_log_calls);
	mix_signed(&digest, fake_host_cleanup_fd_log_last_pid);
	mix(&digest, fake_host_cleanup_fd_log_last_fd);
	mix_signed(&digest, fake_host_cleanup_fd_log_last_err);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xfd0);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0xface2222UL);
	mix_signed(&digest, fake_host_cleanup_fd_event);
	mix_signed(&digest, fake_host_cleanup_fd_log_event);
	mix_signed(&digest, fake_host_reply_event);

	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_cleanup_fd_request_result((void *)0xfd0,
		&procfs_packet, fake_host_cleanup_fd,
		NULL, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cleanup_fd_log_calls);
	mix_signed(&digest, fake_host_cleanup_fd_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, host_cleanup_fd_request_result((void *)0xfd0,
		NULL, fake_host_cleanup_fd, fake_host_cleanup_fd_log,
		fake_procfs_answer_send));
	mix_signed(&digest, host_cleanup_fd_request_result((void *)0xfd0,
		&procfs_packet, NULL, fake_host_cleanup_fd_log,
		fake_procfs_answer_send));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ref = 0x51;
	procfs_packet.pid = 0x2468;
	procfs_packet.arg = 0x45678000UL;
	procfs_packet.reply = (void *)0x51515151UL;
	reset_fake_host_mapping();
	reset_fake_host_send_signal();
	reset_fake_procfs_answer();
	fake_host_map_virtual_result = &fake_host_mapped_signal;
	fake_host_mapped_signal.cond = 1;
	fake_host_mapped_signal.sig = 15;
	fake_host_mapped_signal.pid = 4321;
	fake_host_mapped_signal.tid = 8765;
	for (unsigned int i = 0; i < sizeof(fake_host_mapped_signal.info); i++)
		fake_host_mapped_signal.info[i] = (unsigned char)(i ^ 0x5a);
	fake_host_send_signal_rc = -33;
	fake_host_send_signal_track_events = 1;
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, fake_host_send_signal_log,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_host_map_virtual_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix(&digest, fake_host_map_last_in_phys);
	mix(&digest, fake_host_map_last_size);
	mix(&digest, fake_host_map_virtual_last_phys);
	mix_signed(&digest, fake_host_map_virtual_last_npages);
	mix_signed(&digest, fake_host_map_virtual_last_attr);
	mix_signed(&digest, fake_host_unmap_virtual_last_addr ==
		&fake_host_mapped_signal);
	mix_signed(&digest, fake_host_unmap_virtual_last_npages);
	mix(&digest, fake_host_unmap_memory_last_phys);
	mix(&digest, fake_host_unmap_memory_last_size);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0x515);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0x51515151UL);
	mix_signed(&digest, fake_host_send_signal_kill_calls);
	mix_signed(&digest, fake_host_send_signal_kill_last_pid);
	mix_signed(&digest, fake_host_send_signal_kill_last_tid);
	mix_signed(&digest, fake_host_send_signal_kill_last_sig);
	mix_signed(&digest, fake_host_send_signal_info_matches);
	mix_signed(&digest, fake_host_send_signal_log_calls);
	mix_signed(&digest, fake_host_send_signal_log_last_pid);
	mix_signed(&digest, fake_host_send_signal_log_last_tid);
	mix_signed(&digest, fake_host_send_signal_log_last_sig);
	mix_signed(&digest, fake_host_send_signal_log_last_rc);
	mix_signed(&digest, fake_host_send_signal_reply_event);
	mix_signed(&digest, fake_host_send_signal_kill_event);
	mix_signed(&digest, fake_host_send_signal_log_event);

	reset_fake_host_mapping();
	reset_fake_host_send_signal();
	reset_fake_procfs_answer();
	fake_host_map_virtual_result = &fake_host_mapped_signal;
	fake_host_mapped_signal.sig = 9;
	fake_host_mapped_signal.pid = 246;
	fake_host_mapped_signal.tid = 135;
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, NULL, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_send_signal_log_calls);
	mix_signed(&digest, fake_host_send_signal_kill_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);

	reset_fake_host_mapping();
	reset_fake_host_send_signal();
	reset_fake_procfs_answer();
	fake_host_map_virtual_fail = 1;
	fake_host_send_signal_track_events = 1;
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, fake_host_send_signal_log,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_send_signal_kill_calls);
	mix_signed(&digest, fake_host_send_signal_log_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_send_signal_reply_event);

	reset_fake_host_mapping();
	reset_fake_host_send_signal();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		NULL, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, fake_host_send_signal_log,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		&procfs_packet, NULL, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_do_kill, fake_host_send_signal_log,
		fake_procfs_answer_send));
	mix_signed(&digest, host_send_signal_request_result((void *)0x515,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		NULL, fake_host_send_signal_log,
		fake_procfs_answer_send));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.ttid = 4242;
	reset_fake_host_wake_syscall();
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, fake_host_find_thread, fake_host_wakeup_thread,
		fake_host_unlock_thread, fake_host_wake_syscall_log));
	mix_signed(&digest, fake_host_find_thread_calls);
	mix_signed(&digest, fake_host_find_thread_last_pid);
	mix_signed(&digest, fake_host_find_thread_last_tid);
	mix_signed(&digest, fake_host_wake_log_calls);
	mix_signed(&digest, fake_host_wake_log_last_tid);
	mix_signed(&digest, fake_host_wake_log_last_found);
	mix_signed(&digest, fake_host_wakeup_thread_calls);
	mix_signed(&digest, fake_host_wakeup_thread_last_thread != NULL);
	mix_signed(&digest, fake_host_unlock_thread_calls);
	mix_signed(&digest, fake_host_unlock_thread_last_thread ==
		fake_host_wakeup_thread_last_thread);
	mix_signed(&digest, fake_host_wake_log_event);
	mix_signed(&digest, fake_host_wake_event);
	mix_signed(&digest, fake_host_unlock_event);

	reset_fake_host_wake_syscall();
	fake_host_find_thread_missing = 1;
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, fake_host_find_thread, fake_host_wakeup_thread,
		fake_host_unlock_thread, fake_host_wake_syscall_log));
	mix_signed(&digest, fake_host_find_thread_calls);
	mix_signed(&digest, fake_host_wake_log_calls);
	mix_signed(&digest, fake_host_wake_log_last_found);
	mix_signed(&digest, fake_host_wakeup_thread_calls);
	mix_signed(&digest, fake_host_unlock_thread_calls);

	reset_fake_host_wake_syscall();
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, fake_host_find_thread, fake_host_wakeup_thread,
		fake_host_unlock_thread, NULL));
	mix_signed(&digest, fake_host_wake_log_calls);
	mix_signed(&digest, fake_host_wakeup_thread_calls);
	mix_signed(&digest, fake_host_unlock_thread_calls);
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		NULL, fake_host_find_thread, fake_host_wakeup_thread,
		fake_host_unlock_thread, fake_host_wake_syscall_log));
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, NULL, fake_host_wakeup_thread,
		fake_host_unlock_thread, fake_host_wake_syscall_log));
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, fake_host_find_thread, NULL,
		fake_host_unlock_thread, fake_host_wake_syscall_log));
	mix_signed(&digest, host_wake_syscall_thread_request_result(
		&procfs_packet, fake_host_find_thread, fake_host_wakeup_thread,
		NULL, fake_host_wake_syscall_log));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.arg = 0x1234abcd55aa7700UL;
	reset_fake_host_debug_log();
	mix_signed(&digest, host_debug_log_request_result(&procfs_packet,
		fake_host_debug_log, fake_host_debug_print));
	mix_signed(&digest, fake_host_debug_print_calls);
	mix(&digest, fake_host_debug_print_last_code);
	mix_signed(&digest, fake_host_debug_log_calls);
	mix(&digest, fake_host_debug_log_last_code);
	mix_signed(&digest, fake_host_debug_print_event);
	mix_signed(&digest, fake_host_debug_log_event);

	reset_fake_host_debug_log();
	mix_signed(&digest, host_debug_log_request_result(&procfs_packet,
		fake_host_debug_log, NULL));
	mix_signed(&digest, fake_host_debug_print_calls);
	mix_signed(&digest, fake_host_debug_log_calls);
	mix_signed(&digest, host_debug_log_request_result(NULL,
		fake_host_debug_log, fake_host_debug_print));
	mix_signed(&digest, host_debug_log_request_result(&procfs_packet,
		NULL, fake_host_debug_print));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.pdesc = 0x77770000UL;
	procfs_packet.op = 1;
	procfs_packet.reply = (void *)0x12344321UL;
	reset_fake_host_mapping();
	reset_fake_host_cpu_rw();
	reset_fake_procfs_answer();
	fake_host_map_virtual_result = &fake_host_mapped_cpu_reg;
	fake_host_mapped_cpu_reg.addr = 0x1f0;
	fake_host_mapped_cpu_reg.val = 0xabcdefUL;
	mix_signed(&digest, host_cpu_rw_reg_request_result((void *)0xcee,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_cpu_rw_register, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_host_map_virtual_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix(&digest, fake_host_map_last_in_phys);
	mix(&digest, fake_host_map_last_size);
	mix(&digest, fake_host_map_virtual_last_phys);
	mix_signed(&digest, fake_host_map_virtual_last_npages);
	mix_signed(&digest, fake_host_map_virtual_last_attr);
	mix_signed(&digest, fake_host_unmap_virtual_last_addr ==
		&fake_host_mapped_cpu_reg);
	mix_signed(&digest, fake_host_unmap_virtual_last_npages);
	mix(&digest, fake_host_unmap_memory_last_phys);
	mix(&digest, fake_host_unmap_memory_last_size);
	mix_signed(&digest, fake_host_cpu_rw_calls);
	mix_signed(&digest, fake_host_cpu_rw_last_desc ==
		&fake_host_mapped_cpu_reg);
	mix_signed(&digest, fake_host_cpu_rw_last_op);
	mix(&digest, fake_host_mapped_cpu_reg.val);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xcee);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0x12344321UL);

	reset_fake_host_mapping();
	reset_fake_host_cpu_rw();
	reset_fake_procfs_answer();
	fake_host_map_virtual_result = &fake_host_mapped_cpu_reg;
	fake_host_cpu_rw_rc = -19;
	mix_signed(&digest, host_cpu_rw_reg_request_result((void *)0xcee,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_cpu_rw_register, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cpu_rw_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_mapping();
	reset_fake_host_cpu_rw();
	reset_fake_procfs_answer();
	fake_host_map_virtual_fail = 1;
	mix_signed(&digest, host_cpu_rw_reg_request_result((void *)0xcee,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_cpu_rw_register, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_cpu_rw_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_mapping();
	reset_fake_host_cpu_rw();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_cpu_rw_reg_request_result((void *)0xcee,
		NULL, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_cpu_rw_register, fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, host_cpu_rw_reg_request_result((void *)0xcee,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory, NULL,
		fake_procfs_answer_send));

	reset_fake_host_perf();
	fake_host_perf_init_rc = -11;
	mix_signed(&digest, host_perf_init_raw_result(
		4, 0x1234abcdU, 3, fake_host_perf_init_raw));
	require(fake_host_perf_init_calls == 1);
	require(fake_host_perf_last_counter == 4);
	require(fake_host_perf_last_config == 0x1234abcdU);
	require(fake_host_perf_last_mode == 3);
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix(&digest, fake_host_perf_last_config);
	mix_signed(&digest, fake_host_perf_last_mode);
	mix_signed(&digest, host_perf_init_raw_result(4, 0, 0, NULL));
	fake_host_perf_stop_rc = -12;
	mix_signed(&digest, host_perf_stop_result(
		0x55, 7, fake_host_perf_stop));
	require(fake_host_perf_stop_calls == 1);
	require(fake_host_perf_last_mask == 0x55);
	require(fake_host_perf_last_flags == 7);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix(&digest, fake_host_perf_last_mask);
	mix_signed(&digest, fake_host_perf_last_flags);
	mix_signed(&digest, host_perf_stop_result(0x55, 7, NULL));
	fake_host_perf_reset_rc = -13;
	mix_signed(&digest, host_perf_reset_result(
		6, fake_host_perf_reset));
	require(fake_host_perf_reset_calls == 1);
	require(fake_host_perf_last_counter == 6);
	mix_signed(&digest, fake_host_perf_reset_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix_signed(&digest, host_perf_reset_result(6, NULL));
	fake_host_perf_start_rc = -14;
	mix_signed(&digest, host_perf_start_result(
		0xaa, fake_host_perf_start));
	require(fake_host_perf_start_calls == 1);
	require(fake_host_perf_last_mask == 0xaa);
	mix_signed(&digest, fake_host_perf_start_calls);
	mix(&digest, fake_host_perf_last_mask);
	mix_signed(&digest, host_perf_start_result(0xaa, NULL));
	mix(&digest, host_perf_read_result(8, fake_host_perf_read));
	require(fake_host_perf_read_calls == 1);
	require(fake_host_perf_last_counter == 8);
	mix_signed(&digest, fake_host_perf_read_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix(&digest, host_perf_read_result(8, NULL));
	mix_signed(&digest, host_perf_unexpected_result(
		fake_host_perf_unexpected));
	require(fake_host_perf_unexpected_calls == 1);
	mix_signed(&digest, fake_host_perf_unexpected_calls);
	mix_signed(&digest, host_perf_unexpected_result(NULL));

	reset_fake_host_dispatch();
	mix_signed(&digest,
		host_current_ptr_result(fake_host_handler_response_channel) ==
		(void *)0x424200UL);
	require(fake_host_handler_response_calls == 1);
	mix_signed(&digest, fake_host_handler_response_calls);
	mix_signed(&digest, host_current_ptr_result(NULL) == NULL);

	reset_fake_host_prepare();
	fake_host_prepare_monitor_status[2] = 13;
	mix_signed(&digest, host_monitor_status_result(
		2, fake_host_prepare_monitor_status_fn));
	require(fake_host_prepare_monitor_calls == 1);
	require(fake_host_prepare_monitor_last_cpu == 2);
	mix_signed(&digest, fake_host_prepare_monitor_calls);
	mix_signed(&digest, fake_host_prepare_monitor_last_cpu);
	mix_signed(&digest, host_monitor_status_result(2, NULL));
	mix_signed(&digest, host_tofu_finalize_result(
		fake_host_prepare_tofu_finalize));
	require(fake_host_prepare_tofu_calls == 1);
	mix_signed(&digest, fake_host_prepare_tofu_calls);
	mix_signed(&digest, host_tofu_finalize_result(NULL));
	mix_signed(&digest, host_prepare_process_log_result(
		HOST_PREPARE_LOG_PID_FLAGS, 0x11, 0x22, 0x33,
		fake_host_prepare_log));
	require(fake_host_prepare_log_counts[HOST_PREPARE_LOG_PID_FLAGS] == 1);
	require(fake_host_prepare_log_arg0 == 0x11);
	require(fake_host_prepare_log_arg1 == 0x22);
	require(fake_host_prepare_log_arg2 == 0x33);
	mix_signed(&digest, fake_host_prepare_log_last_event);
	mix(&digest, fake_host_prepare_log_arg0);
	mix(&digest, fake_host_prepare_log_arg1);
	mix(&digest, fake_host_prepare_log_arg2);
	mix_signed(&digest, host_prepare_process_log_result(
		HOST_PREPARE_LOG_PID_FLAGS, 0, 0, 0, NULL));
	mix_signed(&digest, host_prepare_ranges_log_result(
		HOST_PREPARE_RANGES_LOG_ADD_FAILED, 0x44, 0x55, 0x66,
		fake_host_prepare_ranges_log));
	require(fake_host_prepare_ranges_log_counts[
		HOST_PREPARE_RANGES_LOG_ADD_FAILED] == 1);
	require(fake_host_prepare_ranges_log_arg0 == 0x44);
	require(fake_host_prepare_ranges_log_arg1 == 0x55);
	require(fake_host_prepare_ranges_log_arg2 == 0x66);
	mix_signed(&digest, fake_host_prepare_ranges_log_last_event);
	mix(&digest, fake_host_prepare_ranges_log_arg0);
	mix(&digest, fake_host_prepare_ranges_log_arg1);
	mix(&digest, fake_host_prepare_ranges_log_arg2);
	mix_signed(&digest, host_prepare_ranges_log_result(
		HOST_PREPARE_RANGES_LOG_ADD_FAILED, 0, 0, 0, NULL));
	mix_signed(&digest, host_prepare_args_log_result(
		HOST_PREPARE_ARGS_LOG_INIT_STACK_FAILED, 0x77, 0x88, 0x99,
		fake_host_prepare_args_log));
	require(fake_host_prepare_args_log_counts[
		HOST_PREPARE_ARGS_LOG_INIT_STACK_FAILED] == 1);
	require(fake_host_prepare_args_log_arg0 == 0x77);
	require(fake_host_prepare_args_log_arg1 == 0x88);
	require(fake_host_prepare_args_log_arg2 == 0x99);
	mix_signed(&digest, fake_host_prepare_args_log_last_event);
	mix(&digest, fake_host_prepare_args_log_arg0);
	mix(&digest, fake_host_prepare_args_log_arg1);
	mix(&digest, fake_host_prepare_args_log_arg2);
	mix_signed(&digest, host_prepare_args_log_result(
		HOST_PREPARE_ARGS_LOG_INIT_STACK_FAILED, 0, 0, 0, NULL));

	reset_fake_host_dispatch();
	fake_host_dispatch_prepare_rc = -21;
	mix_signed(&digest, host_prepare_process_result(
		0xabcddcba11223344UL, fake_host_prepare_process_call));
	require(fake_host_dispatch_prepare_calls == 1);
	require(fake_host_dispatch_prepare_last_arg == 0xabcddcba11223344UL);
	mix_signed(&digest, fake_host_dispatch_prepare_calls);
	mix(&digest, fake_host_dispatch_prepare_last_arg);
	mix_signed(&digest, host_prepare_process_result(0, NULL));

	reset_fake_host_prepare();
	fake_host_prepare_ranges_rc = -23;
	mix_signed(&digest, host_prepare_ranges_result(
		fake_host_prepare_thread, &fake_host_prepare_desc,
		&fake_host_prepare_desc, 0x712, NULL, 0, NULL, 0,
		fake_host_prepare_ranges));
	require(fake_host_prepare_ranges_calls == 1);
	require(fake_host_prepare_ranges_last_thread ==
		fake_host_prepare_thread);
	require(fake_host_prepare_ranges_last_attr == 0x712);
	mix_signed(&digest, fake_host_prepare_ranges_calls);
	mix_signed(&digest, fake_host_prepare_ranges_last_thread ==
		fake_host_prepare_thread);
	mix(&digest, fake_host_prepare_ranges_last_attr);
	mix_signed(&digest, host_prepare_ranges_result(
		fake_host_prepare_thread, &fake_host_prepare_desc,
		&fake_host_prepare_desc, 0, NULL, 0, NULL, 0, NULL));

	reset_fake_host_cleanup();
	fake_host_cleanup_process_rc = -24;
	mix_signed(&digest, host_cleanup_process_result(
		909, fake_host_cleanup_process));
	require(fake_host_cleanup_process_calls == 1);
	require(fake_host_cleanup_process_last_pid == 909);
	mix_signed(&digest, fake_host_cleanup_process_calls);
	mix_signed(&digest, fake_host_cleanup_process_last_pid);
	mix_signed(&digest, host_cleanup_process_result(909, NULL));
	fake_host_cleanup_fd_rc = -25;
	mix_signed(&digest, host_cleanup_fd_result(
		910, 26, fake_host_cleanup_fd));
	require(fake_host_cleanup_fd_calls == 1);
	require(fake_host_cleanup_fd_last_pid == 910);
	require(fake_host_cleanup_fd_last_fd == 26);
	mix_signed(&digest, fake_host_cleanup_fd_calls);
	mix_signed(&digest, fake_host_cleanup_fd_last_pid);
	mix_signed(&digest, fake_host_cleanup_fd_last_fd);
	mix_signed(&digest, host_cleanup_fd_result(910, 26, NULL));

	struct perf_ctrl_desc perf_desc;
	memset(&perf_desc, 0, sizeof(perf_desc));
	perf_desc.ctrl_type = PERF_CTRL_SET;
	perf_desc.target_cntr = 3;
	perf_desc.config = 0x1234abcdUL;
	perf_desc.exclude_kernel = 0;
	perf_desc.exclude_user = 1;
	reset_fake_host_perf();
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix_signed(&digest, fake_host_perf_reset_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix(&digest, fake_host_perf_last_config);
	mix_signed(&digest, fake_host_perf_last_mode);
	mix(&digest, fake_host_perf_last_mask);
	mix_signed(&digest, fake_host_perf_last_flags);

	reset_fake_host_perf();
	fake_host_perf_init_rc = -5;
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix_signed(&digest, fake_host_perf_reset_calls);

	reset_fake_host_perf();
	fake_host_perf_stop_rc = -7;
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix_signed(&digest, fake_host_perf_reset_calls);

	memset(&perf_desc, 0, sizeof(perf_desc));
	perf_desc.ctrl_type = PERF_CTRL_ENABLE;
	perf_desc.target_cntr_mask = 0x55aaUL;
	reset_fake_host_perf();
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_start_calls);
	mix(&digest, fake_host_perf_last_mask);

	memset(&perf_desc, 0, sizeof(perf_desc));
	perf_desc.ctrl_type = PERF_CTRL_DISABLE;
	perf_desc.target_cntr_mask = 0xaa55UL;
	reset_fake_host_perf();
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix(&digest, fake_host_perf_last_mask);
	mix_signed(&digest, fake_host_perf_last_flags);

	memset(&perf_desc, 0, sizeof(perf_desc));
	perf_desc.ctrl_type = PERF_CTRL_GET;
	perf_desc.target_cntr = 6;
	reset_fake_host_perf();
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_read_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix(&digest, perf_desc.read_value);

	perf_desc.ctrl_type = 99;
	reset_fake_host_perf();
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	mix_signed(&digest, fake_host_perf_unexpected_calls);
	mix_signed(&digest, host_perf_ctrl_result(NULL,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected));
	perf_desc.ctrl_type = PERF_CTRL_SET;
	mix_signed(&digest, host_perf_ctrl_result(&perf_desc, NULL,
		fake_host_perf_stop, fake_host_perf_reset,
		fake_host_perf_start, fake_host_perf_read,
		fake_host_perf_unexpected));

	memset(&procfs_packet, 0xa5, sizeof(procfs_packet));
	procfs_packet.arg = 0x12345000UL;
	procfs_packet.reply = (void *)0x98761234UL;
	reset_fake_host_mapping();
	reset_fake_host_perf();
	reset_fake_procfs_answer();
	fake_host_mapped_perf_desc.ctrl_type = PERF_CTRL_SET;
	fake_host_mapped_perf_desc.target_cntr = 4;
	fake_host_mapped_perf_desc.config = 0xaabbccddUL;
	fake_host_mapped_perf_desc.exclude_kernel = 1;
	fake_host_mapped_perf_desc.exclude_user = 0;
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_host_map_virtual_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix(&digest, fake_host_map_last_in_phys);
	mix(&digest, fake_host_map_last_size);
	mix(&digest, fake_host_map_virtual_last_phys);
	mix_signed(&digest, fake_host_map_virtual_last_npages);
	mix_signed(&digest, fake_host_map_virtual_last_attr);
	mix_signed(&digest, fake_host_unmap_virtual_last_addr ==
		&fake_host_mapped_perf_desc);
	mix_signed(&digest, fake_host_unmap_virtual_last_npages);
	mix(&digest, fake_host_unmap_memory_last_phys);
	mix(&digest, fake_host_unmap_memory_last_size);
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix_signed(&digest, fake_host_perf_reset_calls);
	mix_signed(&digest, fake_host_perf_last_counter);
	mix_signed(&digest, fake_host_perf_last_mode);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0xabc);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix(&digest, fake_procfs_answer_last_arg);
	mix_signed(&digest,
		fake_procfs_answer_last_reply == (void *)0x98761234UL);

	reset_fake_host_mapping();
	reset_fake_host_perf();
	reset_fake_procfs_answer();
	fake_host_perf_init_rc = -11;
	fake_host_mapped_perf_desc.ctrl_type = PERF_CTRL_SET;
	fake_host_mapped_perf_desc.target_cntr = 1;
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_perf_stop_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_mapping();
	reset_fake_host_perf();
	reset_fake_procfs_answer();
	fake_host_mapped_perf_desc.ctrl_type = PERF_CTRL_GET;
	fake_host_mapped_perf_desc.target_cntr = 7;
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_perf_read_calls);
	mix(&digest, fake_host_mapped_perf_desc.read_value);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_mapping();
	reset_fake_host_perf();
	reset_fake_procfs_answer();
	fake_host_map_virtual_fail = 1;
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		&procfs_packet, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_perf_init_calls);
	mix_signed(&digest, fake_host_unmap_virtual_calls);
	mix_signed(&digest, fake_host_unmap_memory_calls);
	mix_signed(&digest, fake_procfs_answer_last_err);

	reset_fake_host_mapping();
	reset_fake_procfs_answer();
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		NULL, fake_host_map_memory, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));
	mix_signed(&digest, fake_host_map_memory_calls);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, host_perf_ctrl_request_result((void *)0xabc,
		&procfs_packet, NULL, fake_host_map_virtual,
		fake_host_unmap_virtual, fake_host_unmap_memory,
		fake_host_perf_init_raw, fake_host_perf_stop,
		fake_host_perf_reset, fake_host_perf_start,
		fake_host_perf_read, fake_host_perf_unexpected,
		fake_procfs_answer_send));

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_monitor_status[1] = 8;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_monitor_calls == 2);
	require(fake_host_map_memory_calls == 0);
	mix_signed(&digest, fake_host_prepare_monitor_last_cpu);
	mix_signed(&digest, fake_host_map_memory_calls);

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = 0;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_map_memory_calls == 1);
	require(fake_host_map_virtual_calls == 1);
	require(fake_host_unmap_virtual_calls == 1);
	require(fake_host_unmap_memory_calls == 1);
	require(fake_host_prepare_log_counts[HOST_PREPARE_LOG_BROKEN_DESC] == 1);
	mix_signed(&digest, fake_host_prepare_log_last_event);
	mix_signed(&digest, fake_host_unmap_virtual_calls);

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 17;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_alloc_calls == 0);
	require(fake_host_unmap_virtual_calls == 0);
	require(fake_host_prepare_log_counts[HOST_PREPARE_LOG_INVALID_SECTIONS] == 1);
	mix_signed(&digest, fake_host_prepare_log_arg0);
	mix_signed(&digest, fake_host_unmap_virtual_calls);

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 2;
	fake_host_prepare_desc.pid = 3210;
	fake_host_prepare_desc.pgid = 3211;
	fake_host_prepare_desc.cred[0] = 11;
	fake_host_prepare_desc.cred[1] = 12;
	fake_host_prepare_desc.entry = 0x44445555UL;
	fake_host_prepare_desc.user_start = 0x1000UL;
	fake_host_prepare_desc.user_end = 0x0000800000000000UL;
	fake_host_prepare_desc.mpol_bind_mask = 1UL << 3;
	fake_host_prepare_desc.rlimit[3].rlim_cur = 0xaaa1;
	fake_host_prepare_desc.rlimit[3].rlim_max = 0xbbb2;
	fake_host_prepare_desc.stack_premap = 0xccc3;
	fake_host_prepare_desc.mcexec_flags = 0x51515151UL;
	fake_host_prepare_desc.profile = 7;
	fake_host_prepare_desc.cpu_set[0] = 0x5a5aUL;
	mix_signed(&digest, fake_host_prepare_call(0x12345UL));
	require(fake_host_prepare_alloc_calls == 1);
	require(fake_host_prepare_copy_calls == 1);
	require(fake_host_prepare_create_calls == 1);
	require(fake_host_prepare_ranges_calls == 1);
	require(fake_host_prepare_free_calls == 1);
	require(fake_host_unmap_virtual_calls == 1);
	require(fake_host_unmap_memory_calls == 1);
	require(fake_host_prepare_flush_calls == 1);
	require(fake_host_prepare_ranges_last_thread == fake_host_prepare_thread);
	require(fake_host_prepare_ranges_last_pn ==
		(struct program_load_desc *)fake_host_prepare_clone);
	require(fake_host_prepare_ranges_last_p == &fake_host_prepare_desc);
	require(fake_host_prepare_ranges_last_attr == 0x700);
	require(fake_host_prepare_create_last_entry == 0x44445555UL);
	require(fake_host_prepare_create_last_cpuset ==
		&fake_host_prepare_desc.cpu_set[0]);
	require(fake_host_prepare_create_last_cpuset_size ==
		sizeof(fake_host_prepare_desc.cpu_set));
	require(fake_host_prepare_int_load(fake_host_prepare_process,
		FAKE_HOST_PREPARE_PROCESS_PID_OFF) == 3210);
	require(fake_host_prepare_int_load(fake_host_prepare_process,
		FAKE_HOST_PREPARE_PROCESS_PGID_OFF) == 3211);
	require(fake_host_prepare_int_load(fake_host_prepare_process,
		FAKE_HOST_PREPARE_PROCESS_TERMSIG_OFF) == 17);
	require(fake_host_prepare_int_load(fake_host_prepare_aspace,
		FAKE_HOST_PREPARE_ASPACE_PIDS_OFF) == 3210);
	require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_MAP_START_OFF) == 0x40000000UL);
	require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_MAP_END_OFF) == 0x40000000UL);
	require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_USER_END_OFF) == 0x00007ffffffff000UL);
	require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_MASK_OFF) == (1UL << 3));
	require(fake_host_prepare_int_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_POLICY_OFF) == 2);
	require(!memcmp(fake_host_prepare_thread +
		FAKE_HOST_PREPARE_THREAD_ROUTINE_OFF, "[main]",
		sizeof("[main]")));
	mix_signed(&digest, fake_host_prepare_alloc_calls);
	mix_signed(&digest, fake_host_prepare_ranges_calls);
	mix_signed(&digest, fake_host_prepare_flush_calls);
	mix_signed(&digest, fake_host_prepare_int_load(fake_host_prepare_process,
		FAKE_HOST_PREPARE_PROCESS_PID_OFF));
	mix(&digest, fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_MASK_OFF));

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 1;
	fake_host_prepare_alloc_fail = 1;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_alloc_calls == 1);
	require(fake_host_prepare_create_calls == 0);
	require(fake_host_unmap_virtual_calls == 1);
	mix_signed(&digest, fake_host_prepare_alloc_calls);
	mix_signed(&digest, fake_host_prepare_create_calls);

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 1;
	fake_host_prepare_create_fail = 1;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_create_calls == 1);
	require(fake_host_prepare_free_calls == 1);
	require(fake_host_unmap_virtual_calls == 1);
	mix_signed(&digest, fake_host_prepare_free_calls);
	mix_signed(&digest, fake_host_prepare_create_calls);

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 1;
	fake_host_prepare_desc.pid = 4001;
	fake_host_prepare_desc.entry = 0x40010000UL;
	fake_host_prepare_desc.mpol_mode = 3;
	fake_host_prepare_desc.mpol_nodemask[0] = 1UL << 4;
	fake_host_prepare_ranges_rc = -9;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_ranges_calls == 1);
	require(fake_host_prepare_destroy_calls == 1);
	require(fake_host_prepare_free_calls == 1);
	require(fake_host_prepare_log_counts[HOST_PREPARE_LOG_PREPARE_ERROR] == 1);
	require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_MASK_OFF) == (1UL << 4));
	require(fake_host_prepare_int_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_POLICY_OFF) == 3);
	mix_signed(&digest, fake_host_prepare_destroy_calls);
	mix(&digest, fake_host_prepare_ulong_load(fake_host_prepare_vm,
		FAKE_HOST_PREPARE_VM_NUMA_MASK_OFF));

	reset_fake_host_mapping();
	reset_fake_host_prepare();
	fake_host_prepare_desc.magic = PLD_MAGIC;
	fake_host_prepare_desc.num_sections = 1;
	fake_host_prepare_desc.mpol_bind_mask = 1UL << 9;
	fake_host_prepare_nr_numa_nodes = 4;
	mix_signed(&digest, fake_host_prepare_call(0x12345000UL));
	require(fake_host_prepare_nr_numa_calls == 1);
	require(fake_host_prepare_log_counts[HOST_PREPARE_LOG_NUMA_BIND_ERROR] == 1);
	require(fake_host_prepare_ranges_calls == 0);
	require(fake_host_unmap_virtual_calls == 0);
	mix_signed(&digest, fake_host_prepare_log_arg0);
	mix_signed(&digest, fake_host_prepare_ranges_calls);

		reset_fake_host_prepare();
		{
			struct program_load_desc *pn =
				(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0xdeadbeefUL;

		p->num_sections = 2;
		pn->mpol_threshold = 0x2000;
		pn->sections[0].vaddr = 0x401234;
		pn->sections[0].len = 0x2000;
		pn->sections[0].filesz = 0x1800;
		pn->sections[0].prot = PROT_EXEC;
		pn->sections[1].vaddr = 0x500000;
		pn->sections[1].len = 0x3000;
		pn->sections[1].filesz = 0x1000;
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_add_range_calls == 2);
		require(fake_host_prepare_alloc_pages_calls == 2);
		require(fake_host_prepare_pt_set_calls == 2);
		require(fake_host_prepare_virt_to_phys_calls == 2);
		require(fake_host_prepare_ptattr_calls == 2);
		require(fake_host_prepare_ranges_log_counts[
			HOST_PREPARE_RANGES_LOG_AP_USER] == 1);
		require(fake_host_prepare_add_range_last_start == 0x500000UL);
		require(fake_host_prepare_add_range_last_end == 0x503000UL);
		require(fake_host_prepare_add_range_last_pgshift == PAGE_SHIFT);
		require(fake_host_prepare_add_range_last_flag & VR_AP_USER);
		require(fake_host_prepare_alloc_pages_last_npages == 1);
		require(fake_host_prepare_alloc_pages_last_flags ==
			(IHK_MC_AP_NOWAIT | IHK_MC_AP_USER));
		require(fake_host_prepare_pt_set_last_pt ==
			(void *)0x12345678000UL);
		require(fake_host_prepare_pt_set_last_start == 0x500000UL);
		require(fake_host_prepare_pt_set_last_end == 0x501000UL);
		require(fake_host_prepare_pt_set_last_pgshift == PAGE_SHIFT);
		require(fake_host_prepare_ptattr_last_fault == PF_POPULATE);
		require(p->sections[0].remote_pa != 0);
		require(p->sections[1].remote_pa != 0);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_TEXT_START_OFF) == 0x401000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_TEXT_END_OFF) == 0x404000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_DATA_START_OFF) == 0x500000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_DATA_END_OFF) == 0x503000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_BRK_START_OFF) == 0x600000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_BRK_ALLOC_OFF) == 0x600000UL);
		require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_MAP_START_OFF) ==
			TASK_UNMAPPED_BASE);
		require(at_base == 0);
		mix_signed(&digest, fake_host_prepare_pt_set_calls);
		mix(&digest, fake_host_prepare_add_range_last_flag);
		mix(&digest, fake_host_prepare_ulong_load(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_BRK_START_OFF));
		require(p->sections[1].remote_pa -
			(unsigned long)(uintptr_t)fake_host_prepare_page_pool[1] ==
			0x100000000UL);
		mix(&digest, p->sections[1].remote_pa -
			(unsigned long)(uintptr_t)fake_host_prepare_page_pool[1]);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;

		p->num_sections = 2;
		pn->reloc = 1;
		pn->entry = 0x11123UL;
		pn->at_phdr = 0x200UL;
		pn->at_entry = 0x1000UL;
		pn->interp_align = 0x1000UL;
		pn->sections[0].vaddr = 0x1000UL;
		pn->sections[0].len = 0x1000UL;
		pn->sections[0].filesz = 0x1000UL;
		pn->sections[0].prot = PROT_EXEC;
		pn->sections[1].vaddr = 0x10123UL;
		pn->sections[1].len = 0x1000UL;
		pn->sections[1].filesz = 0x1000UL;
		pn->sections[1].prot = PROT_EXEC;
		pn->sections[1].interp = 1;
		fake_host_prepare_ulong_store(fake_host_prepare_vm,
			FAKE_HOST_PREPARE_VM_MAP_END_OFF, 0x700000UL);
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_modify_context_calls == 1);
		require(fake_host_prepare_modify_context_last_reg ==
			IHK_UCR_PROGRAM_COUNTER);
		require(fake_host_prepare_modify_context_last_value ==
			0x703123UL);
		require(pn->entry == 0x703123UL);
		require(p->entry == 0x703123UL);
		require(at_base == 0x6f2000UL);
		require(pn->at_phdr == 0x700200UL);
		require(pn->at_entry == 0x701000UL);
		require(p->sections[0].vaddr == 0x701000UL);
		require(p->sections[1].vaddr == 0x702123UL);
		mix(&digest, at_base);
		mix(&digest, pn->at_phdr);
		mix(&digest, fake_host_prepare_modify_context_last_value);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;
		int rc;

		p->num_sections = 1;
		pn->sections[0].vaddr = 0x10123UL;
		pn->sections[0].len = 0x1000UL;
		pn->sections[0].filesz = 0x1000UL;
		pn->sections[0].interp = 1;
		pn->interp_align = 0;
		rc = fake_host_prepare_sections_call(pn, p, &at_base);
		mix_signed(&digest, rc);
		require(rc == -22);
		require(fake_host_prepare_add_range_calls == 0);
		require(fake_host_prepare_alloc_pages_calls == 0);
		mix_signed(&digest, fake_host_prepare_add_range_calls);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;

		p->num_sections = 1;
		pn->sections[0].vaddr = 0x800000UL;
		pn->sections[0].len = 0x1000UL;
		pn->sections[0].filesz = 0x1000UL;
		fake_host_prepare_add_range_fail_call = 1;
		fake_host_prepare_add_range_rc = -44;
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_add_range_calls == 1);
		require(fake_host_prepare_alloc_pages_calls == 0);
		require(fake_host_prepare_ranges_log_counts[
			HOST_PREPARE_RANGES_LOG_ADD_FAILED] == 1);
		mix_signed(&digest, fake_host_prepare_add_range_calls);
		mix_signed(&digest, fake_host_prepare_alloc_pages_calls);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;

		p->num_sections = 1;
		pn->sections[0].vaddr = 0x810000UL;
		pn->sections[0].len = 0x1000UL;
		pn->sections[0].filesz = 0x1000UL;
		fake_host_prepare_alloc_pages_fail_call = 1;
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_add_range_calls == 1);
		require(fake_host_prepare_alloc_pages_calls == 1);
		require(fake_host_prepare_pt_set_calls == 0);
		require(fake_host_prepare_ranges_log_counts[
			HOST_PREPARE_RANGES_LOG_ALLOC_FAILED] == 1);
		mix_signed(&digest, fake_host_prepare_alloc_pages_calls);
		mix_signed(&digest, fake_host_prepare_pt_set_calls);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;

		p->num_sections = 1;
		pn->sections[0].vaddr = 0x820000UL;
		pn->sections[0].len = 0x1000UL;
		pn->sections[0].filesz = 0x1000UL;
		fake_host_prepare_pt_set_fail_call = 1;
		fake_host_prepare_pt_set_rc = -55;
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_pt_set_calls == 1);
		require(fake_host_prepare_free_pages_calls == 1);
		require(fake_host_prepare_ranges_log_counts[
			HOST_PREPARE_RANGES_LOG_PT_FAILED] == 1);
		mix_signed(&digest, fake_host_prepare_pt_set_calls);
		mix_signed(&digest, fake_host_prepare_free_pages_calls);
	}

	reset_fake_host_prepare();
	{
		struct program_load_desc *pn =
			(struct program_load_desc *)fake_host_prepare_sections_pn_storage;
		struct program_load_desc *p =
			(struct program_load_desc *)fake_host_prepare_sections_p_storage;
		unsigned long at_base = 0;

		p->num_sections = 1;
		pn->sections[0].vaddr = TASK_UNMAPPED_BASE - PAGE_SIZE;
		pn->sections[0].len = PAGE_SIZE * 2;
		pn->sections[0].filesz = PAGE_SIZE;
		mix_signed(&digest, fake_host_prepare_sections_call(pn, p,
			&at_base));
		require(fake_host_prepare_ranges_log_counts[
			HOST_PREPARE_RANGES_LOG_DATA_TOO_LARGE] == 1);
		require(fake_host_prepare_pt_set_calls == 1);
			mix_signed(&digest, fake_host_prepare_ranges_log_last_event);
			mix(&digest, fake_host_prepare_ranges_log_arg0);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;
			unsigned long expected_addr;
			unsigned long envs_offset;

			fake_host_prepare_args_setup_remote(&pn, &p);
			pn.enable_vdso = 1;
			strcpy(fake_host_prepare_args_old_cmdline, "old-cmd");
			fake_host_prepare_ptr_store(fake_host_prepare_process,
				FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_OFF,
				fake_host_prepare_args_old_cmdline);
			fake_host_prepare_ulong_store(fake_host_prepare_process,
				FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_LEN_OFF, 7);
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0x77770000UL, NULL, 0, NULL, 0));
			expected_addr = TASK_UNMAPPED_BASE - 2 * PAGE_SIZE;
			envs_offset = (p.args_len + sizeof(long) - 1) &
				~(sizeof(long) - 1);
			require(fake_host_prepare_alloc_pages_calls == 1);
			require(fake_host_prepare_alloc_pages_last_npages == 2);
			require(fake_host_prepare_alloc_pages_last_addr == ~0UL);
			require(fake_host_prepare_add_range_calls == 1);
			require(fake_host_prepare_add_range_last_start == expected_addr);
			require(fake_host_prepare_add_range_last_end == TASK_UNMAPPED_BASE);
			require(fake_host_prepare_add_range_last_flag & VR_PRIVATE);
			require(fake_host_prepare_add_range_last_flag & VR_PROT_READ);
			require(fake_host_prepare_add_range_last_flag & VR_PROT_WRITE);
			require(fake_host_prepare_args_map_memory_calls == 2);
			require(fake_host_prepare_args_map_virtual_calls == 2);
			require(fake_host_prepare_args_map_virtual_last_attr == 0x712);
			require(fake_host_unmap_virtual_calls == 2);
			require(fake_host_unmap_memory_calls == 2);
			require(fake_host_prepare_flush_calls == 2);
			require(fake_host_prepare_copy_calls == 2);
			require(fake_host_prepare_free_calls == 1);
			require(fake_host_prepare_free_last_ptr ==
				fake_host_prepare_args_old_cmdline);
			require(fake_host_prepare_alloc_calls == 1);
			require(fake_host_prepare_alloc_last_size == 12);
			require(fake_host_prepare_alloc_last_flags == IHK_MC_AP_NOWAIT);
			require(fake_host_prepare_ulong_load(fake_host_prepare_process,
				FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_OFF) ==
				(unsigned long)(uintptr_t)fake_host_prepare_clone);
			require(fake_host_prepare_ulong_load(fake_host_prepare_process,
				FAKE_HOST_PREPARE_PROCESS_SAVED_CMDLINE_LEN_OFF) == 12);
			require(!memcmp(fake_host_prepare_clone, "hello\0world\0", 12));
			require(fake_host_prepare_args_vdso_calls == 1);
			require(fake_host_prepare_args_vdso_last_vm == fake_host_prepare_vm);
			require(p.rprocess == (unsigned long)(uintptr_t)fake_host_prepare_thread);
			require(p.rpgtable == 0x12345678000UL + 0x100000000UL);
			require(fake_host_prepare_args_init_calls == 1);
			require(fake_host_prepare_args_init_last_thread ==
				fake_host_prepare_thread);
			require(fake_host_prepare_args_init_last_pn == &pn);
			require(fake_host_prepare_args_init_last_at_base == 0x77770000UL);
			require(fake_host_prepare_args_init_last_argc == 2);
			require(fake_host_prepare_args_init_last_envc == 1);
			require(fake_host_prepare_args_init_last_argv0 == expected_addr);
			require(fake_host_prepare_args_init_last_argv1 ==
				expected_addr + 6);
			require(fake_host_prepare_args_init_last_env0 ==
				expected_addr + envs_offset);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_CMDLINE] == 1);
			require(fake_host_prepare_virt_to_phys_calls == 2);
			require(fake_host_prepare_add_range_last_phys -
				(unsigned long)(uintptr_t)fake_host_prepare_page_pool[0] ==
				0x100000000UL);
			mix_signed(&digest, fake_host_prepare_args_init_last_argc);
			mix_signed(&digest, fake_host_prepare_args_init_last_envc);
			mix(&digest, fake_host_prepare_args_init_last_argv1 -
				expected_addr);
			mix(&digest, fake_host_prepare_args_init_last_env0 -
				expected_addr);
			mix(&digest, p.rpgtable);
			mix_signed(&digest, fake_host_prepare_free_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;
			unsigned long args_len;
			unsigned long envs_len;
			unsigned long expected_addr;

			memset(&pn, 0, sizeof(pn));
			memset(&p, 0, sizeof(p));
			args_len = fake_host_prepare_fill_args(
				fake_host_prepare_args_local_args);
			envs_len = fake_host_prepare_fill_envs(
				fake_host_prepare_args_local_envs);
			fake_host_prepare_ulong_store(fake_host_prepare_vm,
				FAKE_HOST_PREPARE_VM_MAP_START_OFF, TASK_UNMAPPED_BASE);
			fake_host_prepare_ulong_store(fake_host_prepare_vm,
				FAKE_HOST_PREPARE_VM_VDSO_ADDR_OFF, 0x515151UL);
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0x11110000UL, (char *)fake_host_prepare_args_local_args,
				args_len, (char *)fake_host_prepare_args_local_envs,
				envs_len));
			expected_addr = TASK_UNMAPPED_BASE - 2 * PAGE_SIZE;
			require(p.args_len == args_len);
			require(p.envs_len == envs_len);
			require(fake_host_prepare_args_map_memory_calls == 0);
			require(fake_host_prepare_args_map_virtual_calls == 0);
			require(fake_host_unmap_virtual_calls == 0);
			require(fake_host_unmap_memory_calls == 0);
			require(fake_host_prepare_args_vdso_calls == 0);
			require(fake_host_prepare_ulong_load(fake_host_prepare_vm,
				FAKE_HOST_PREPARE_VM_VDSO_ADDR_OFF) == 0);
			require(fake_host_prepare_args_init_last_argv1 ==
				expected_addr + 6);
			require(fake_host_prepare_args_init_last_env0 ==
				expected_addr + ((args_len + sizeof(long) - 1) &
				~(sizeof(long) - 1)));
			mix_signed(&digest, fake_host_prepare_args_map_memory_calls);
			mix_signed(&digest, fake_host_unmap_virtual_calls);
			mix(&digest, p.args_len);
			mix(&digest, p.envs_len);
			mix(&digest, fake_host_prepare_ulong_load(fake_host_prepare_vm,
				FAKE_HOST_PREPARE_VM_VDSO_ADDR_OFF));
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_alloc_pages_fail_call = 1;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_alloc_pages_calls == 1);
			require(fake_host_prepare_add_range_calls == 0);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_ALLOC_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_alloc_pages_calls);
			mix_signed(&digest, fake_host_prepare_add_range_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_add_range_fail_call = 1;
			fake_host_prepare_add_range_rc = -44;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_add_range_calls == 1);
			require(fake_host_prepare_free_pages_calls == 1);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_ADD_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_add_range_calls);
			mix_signed(&digest, fake_host_prepare_free_pages_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_args_map_virtual_fail_call = 1;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_args_map_memory_calls == 1);
			require(fake_host_prepare_args_map_virtual_calls == 1);
			require(fake_host_unmap_virtual_calls == 0);
			require(fake_host_prepare_flush_calls == 0);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_ARGS_MAP_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_args_map_virtual_calls);
			mix_signed(&digest, fake_host_prepare_flush_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_args_map_virtual_fail_call = 2;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_args_map_memory_calls == 2);
			require(fake_host_prepare_args_map_virtual_calls == 2);
			require(fake_host_unmap_virtual_calls == 1);
			require(fake_host_prepare_flush_calls == 1);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_ENVS_MAP_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_args_map_virtual_calls);
			mix_signed(&digest, fake_host_prepare_flush_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_alloc_fail = 1;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_alloc_calls == 1);
			require(fake_host_prepare_args_init_calls == 0);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_CMDLINE_ALLOC_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_alloc_calls);
			mix_signed(&digest, fake_host_prepare_args_init_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			pn.enable_vdso = 1;
			fake_host_prepare_args_vdso_rc = -77;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_args_vdso_calls == 1);
			require(fake_host_prepare_args_init_calls == 0);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_VDSO_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_args_vdso_calls);
			mix_signed(&digest, fake_host_prepare_args_init_calls);
		}

		reset_fake_host_mapping();
		reset_fake_host_prepare();
		{
			struct program_load_desc pn;
			struct program_load_desc p;

			fake_host_prepare_args_setup_remote(&pn, &p);
			fake_host_prepare_args_init_rc = -66;
			mix_signed(&digest, fake_host_prepare_args_envs_call(&pn, &p,
				0, NULL, 0, NULL, 0));
			require(fake_host_prepare_args_init_calls == 1);
			require(fake_host_prepare_args_log_counts[
				HOST_PREPARE_ARGS_LOG_INIT_STACK_FAILED] == 1);
			mix_signed(&digest, fake_host_prepare_args_init_calls);
			mix_signed(&digest, fake_host_prepare_args_log_last_event);
		}

		reset_fake_host_ikc();
		{
			struct ihk_ikc_connect_param connect_param;

			memset(&connect_param, 0, sizeof(connect_param));
			connect_param.port = 501;
			connect_param.pkt_size = sizeof(procfs_packet);
			connect_param.queue_size = 4096 * 4;
			connect_param.magic = 0x1329;
			connect_param.intr_cpu = -1;
			connect_param.handler = fake_host_ikc_packet_handler;
			mix_signed(&digest, host_ikc_connect_result(&connect_param,
				fake_host_ikc_connect));
			require(fake_host_ikc_connect_calls == 1);
			require(fake_host_ikc_connect_last_port == 501);
			require(fake_host_ikc_connect_handler_matches == 1);
			require(connect_param.channel == &fake_host_ikc_channels[1]);
			mix_signed(&digest, fake_host_ikc_connect_calls);
			mix_signed(&digest, fake_host_ikc_connect_last_magic);
			mix_signed(&digest, fake_host_ikc_connect_last_intr_cpu);
			mix_signed(&digest, connect_param.channel ==
				&fake_host_ikc_channels[1]);
			mix_signed(&digest, host_ikc_connect_result(&connect_param,
				NULL));
			mix_signed(&digest, host_delay_result(123456,
				fake_host_ikc_delay));
			require(fake_host_ikc_delay_calls == 1);
			require(fake_host_ikc_delay_last_usec == 123456);
			mix_signed(&digest, fake_host_ikc_delay_calls);
			mix(&digest, fake_host_ikc_delay_last_usec);
			mix_signed(&digest, host_delay_result(1, NULL));
			mix_signed(&digest, host_set_current_ikc2linux_result(
				(void *)0x424242UL, fake_host_ikc_set_current));
			require(fake_host_ikc_set_current_calls == 1);
			require(fake_host_ikc_set_current_last_channel ==
				(void *)0x424242UL);
			mix_signed(&digest, fake_host_ikc_set_current_calls);
			mix_signed(&digest, fake_host_ikc_set_current_last_channel ==
				(void *)0x424242UL);
			mix_signed(&digest, host_set_current_ikc2linux_result(
				(void *)0x424242UL, NULL));
			mix_signed(&digest, host_ikc_set_regular_channel_result(
				(void *)0x515151UL, 7, fake_host_ikc_set_regular));
			require(fake_host_ikc_set_regular_calls == 1);
			require(fake_host_ikc_set_regular_last_channel ==
				(void *)0x515151UL);
			require(fake_host_ikc_set_regular_last_cpu == 7);
			mix_signed(&digest, fake_host_ikc_set_regular_calls);
			mix_signed(&digest, fake_host_ikc_set_regular_last_cpu);
			mix_signed(&digest, host_ikc_set_regular_channel_result(
				(void *)0x515151UL, 7, NULL));
			mix_signed(&digest, host_init_ikc_log_result(
				HOST_INIT_IKC_LOG_CONNECTED, fake_host_ikc_log));
			require(fake_host_ikc_log_counts[
				HOST_INIT_IKC_LOG_CONNECTED] == 1);
			mix_signed(&digest, fake_host_ikc_log_last_event);
			mix_signed(&digest, host_init_ikc_log_result(1, NULL));
			mix_signed(&digest, host_panic_result(fake_host_ikc_panic));
			require(fake_host_ikc_panic_calls == 1);
			mix_signed(&digest, fake_host_ikc_panic_calls);
			mix_signed(&digest, host_panic_result(NULL));
		}

		reset_fake_host_ikc();
		fake_host_ikc_connect_failures = 2;
	mix_signed(&digest, host_init_ikc2linux_result(1,
		&fake_host_ikc_table_ptr, 3, 1, sizeof(procfs_packet),
		4096, 0x77, fake_host_ikc_alloc, fake_host_ikc_connect,
		fake_host_ikc_delay, fake_host_ikc_set_current,
		fake_host_ikc_packet_handler, fake_host_ikc_log,
		fake_host_ikc_panic));
	require(fake_host_ikc_table_ptr == fake_host_ikc_table_storage);
	require(fake_host_ikc_table_storage[0] == NULL);
	require(fake_host_ikc_table_storage[1] != NULL);
	require(fake_host_ikc_table_storage[2] == NULL);
	require(fake_host_ikc_alloc_calls == 1);
	require(fake_host_ikc_alloc_last_size ==
		sizeof(fake_host_ikc_table_storage[0]) * 3);
	require(fake_host_ikc_alloc_last_flags == 0x77);
	require(fake_host_ikc_connect_calls == 3);
	require(fake_host_ikc_connect_last_port == 503);
	require(fake_host_ikc_connect_last_pkt_size ==
		(int)sizeof(procfs_packet));
	require(fake_host_ikc_connect_last_queue_size == 4096 * 4);
	require(fake_host_ikc_connect_last_magic == 0x1129);
	require(fake_host_ikc_connect_last_intr_cpu == 1);
	require(fake_host_ikc_connect_handler_matches == 1);
	require(fake_host_ikc_delay_calls == 2);
	require(fake_host_ikc_delay_last_usec == 1000UL * 1000UL);
	require(fake_host_ikc_set_current_calls == 1);
	require(fake_host_ikc_set_current_last_channel ==
		fake_host_ikc_table_storage[1]);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_TRY_CONNECT] == 1);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_RETRY_DOT] == 2);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_CONNECTED] == 1);
	mix_signed(&digest, fake_host_ikc_alloc_calls);
	mix_signed(&digest, fake_host_ikc_connect_calls);
	mix_signed(&digest, fake_host_ikc_delay_calls);
	mix_signed(&digest, fake_host_ikc_connect_last_queue_size);
	mix_signed(&digest, fake_host_ikc_connect_handler_matches);
	mix_signed(&digest, fake_host_ikc_set_current_last_channel ==
		fake_host_ikc_table_storage[1]);

	fake_host_ikc_alloc_calls = 0;
	fake_host_ikc_connect_calls = 0;
	fake_host_ikc_set_current_calls = 0;
	mix_signed(&digest, host_init_ikc2linux_result(1,
		&fake_host_ikc_table_ptr, 3, 4, sizeof(procfs_packet),
		4096, 0x88, fake_host_ikc_alloc, fake_host_ikc_connect,
		fake_host_ikc_delay, fake_host_ikc_set_current,
		fake_host_ikc_packet_handler, fake_host_ikc_log,
		fake_host_ikc_panic));
	require(fake_host_ikc_alloc_calls == 0);
	require(fake_host_ikc_connect_calls == 0);
	require(fake_host_ikc_set_current_calls == 1);
	require(fake_host_ikc_set_current_last_channel ==
		fake_host_ikc_table_storage[1]);
	mix_signed(&digest, fake_host_ikc_connect_calls);
	mix_signed(&digest, fake_host_ikc_set_current_calls);

	reset_fake_host_ikc();
	fake_host_ikc_alloc_fail = 1;
	mix_signed(&digest, host_init_ikc2linux_result(0,
		&fake_host_ikc_table_ptr, 2, 2, sizeof(procfs_packet),
		4096, 0x99, fake_host_ikc_alloc, fake_host_ikc_connect,
		fake_host_ikc_delay, fake_host_ikc_set_current,
		fake_host_ikc_packet_handler, fake_host_ikc_log,
		fake_host_ikc_panic));
	require(fake_host_ikc_alloc_calls == 1);
	require(fake_host_ikc_connect_calls == 0);
	require(fake_host_ikc_panic_calls == 1);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_ALLOC_ERROR] == 1);
	mix_signed(&digest, fake_host_ikc_panic_calls);
	mix_signed(&digest,
		fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_ALLOC_ERROR]);

	reset_fake_host_ikc();
	fake_host_ikc_connect_failures = 1;
	mix_signed(&digest, host_init_ikc2mckernel_result(
		sizeof(procfs_packet), 4096, 17,
		fake_host_ikc_packet_handler, fake_host_ikc_connect,
		fake_host_ikc_delay, fake_host_ikc_set_regular,
		fake_host_ikc_log));
	require(fake_host_ikc_connect_calls == 2);
	require(fake_host_ikc_connect_last_port == 501);
	require(fake_host_ikc_connect_last_pkt_size ==
		(int)sizeof(procfs_packet));
	require(fake_host_ikc_connect_last_queue_size == 4096 * 4);
	require(fake_host_ikc_connect_last_magic == 0x1329);
	require(fake_host_ikc_connect_last_intr_cpu == -1);
	require(fake_host_ikc_connect_handler_matches == 1);
	require(fake_host_ikc_delay_calls == 1);
	require(fake_host_ikc_set_regular_calls == 1);
	require(fake_host_ikc_set_regular_last_channel != NULL);
	require(fake_host_ikc_set_regular_last_cpu == 17);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_TRY_CONNECT] == 1);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_RETRY_DOT] == 1);
	require(fake_host_ikc_log_counts[HOST_INIT_IKC_LOG_CONNECTED] == 1);
	mix_signed(&digest, fake_host_ikc_connect_calls);
	mix_signed(&digest, fake_host_ikc_delay_calls);
	mix_signed(&digest, fake_host_ikc_set_regular_last_cpu);
	mix_signed(&digest, fake_host_ikc_connect_last_intr_cpu);

	mix_signed(&digest, host_init_ikc2linux_result(0, NULL, 1, 1,
		sizeof(procfs_packet), 4096, 0, fake_host_ikc_alloc,
		fake_host_ikc_connect, fake_host_ikc_delay,
		fake_host_ikc_set_current, fake_host_ikc_packet_handler,
		fake_host_ikc_log, fake_host_ikc_panic));
	mix_signed(&digest, host_init_ikc2mckernel_result(
		sizeof(procfs_packet), 4096, 17, NULL,
		fake_host_ikc_connect, fake_host_ikc_delay,
		fake_host_ikc_set_regular, fake_host_ikc_log));

	reset_fake_host_ikc();
	fake_host_ikc_alloc_fail = 1;
	mix_signed(&digest, host_init_ikc2linux_public_result(0,
		&fake_host_ikc_table_ptr, 2, 2, sizeof(procfs_packet),
		4096, 0x99, fake_host_ikc_alloc, fake_host_ikc_connect,
		fake_host_ikc_delay, fake_host_ikc_set_current,
		fake_host_ikc_packet_handler, fake_host_ikc_log,
		fake_host_ikc_panic));
	require(fake_host_ikc_alloc_calls == 1);
	require(fake_host_ikc_connect_calls == 0);
	require(fake_host_ikc_panic_calls == 2);
	mix_signed(&digest, fake_host_ikc_panic_calls);

	reset_fake_host_ikc();
	mix_signed(&digest, host_init_ikc2mckernel_public_result(
		sizeof(procfs_packet), 4096, 17, NULL,
		fake_host_ikc_connect, fake_host_ikc_delay,
		fake_host_ikc_set_regular, fake_host_ikc_log,
		fake_host_ikc_panic));
	require(fake_host_ikc_connect_calls == 0);
	require(fake_host_ikc_panic_calls == 1);
	mix_signed(&digest, fake_host_ikc_panic_calls);

	struct host_scd_dispatch_ops dispatch_ops =
		make_fake_host_dispatch_ops();

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_INIT_CHANNEL_ACKED;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x100,
		&procfs_packet, (void *)0x200, (void *)0x300,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_init_ack_log_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest,
		fake_host_dispatch_release_last_packet == &procfs_packet);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PREPARE_PROCESS;
	procfs_packet.ref = 7001;
	procfs_packet.arg = 0x1234567000UL;
	procfs_packet.reply = (void *)0x7010;
	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	fake_host_dispatch_prepare_rc = -17;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x101,
		&procfs_packet, (void *)0x201, (void *)0x301,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_prepare_calls);
	mix(&digest, fake_host_dispatch_prepare_last_arg);
	mix_signed(&digest, fake_procfs_answer_send_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0x201);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	reset_fake_host_schedule();
	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_SCHEDULE_PROCESS;
	procfs_packet.arg = (unsigned long)&fake_host_schedule_thread;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x102,
		&procfs_packet, (void *)0x202, (void *)0x302,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_schedule_log_calls);
	mix_signed(&digest, fake_host_dispatch_schedule_last_arg ==
		(unsigned long)&fake_host_schedule_thread);
	mix_signed(&digest, fake_host_schedule_runq_add_calls);
	mix_signed(&digest, fake_host_schedule_proc.status);
	mix_signed(&digest, fake_host_schedule_thread.status);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_WAKE_UP_SYSCALL_THREAD;
	procfs_packet.ttid = 4242;
	reset_fake_host_wake_syscall();
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x103,
		&procfs_packet, (void *)0x203, (void *)0x303,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_find_thread_calls);
	mix_signed(&digest, fake_host_wakeup_thread_calls);
	mix_signed(&digest, fake_host_unlock_thread_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_REMOTE_PAGE_FAULT;
	procfs_packet.ref = 7002;
	procfs_packet.fault_tid = 8080;
	procfs_packet.fault_address = 0x88880000UL;
	procfs_packet.fault_reason = 0x81;
	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	reset_fake_host_dispatch();
	fake_host_find_thread_result = (void *)0x515151UL;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x104,
		&procfs_packet, (void *)0x204, (void *)0x515151UL,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_find_thread_last_tid);
	mix_signed(&digest, fake_host_rpf_request_body_calls);
	mix_signed(&digest, fake_host_rpf_request_body_last_err);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_SEND_SIGNAL;
	procfs_packet.ref = 7003;
	procfs_packet.arg = 0x51510000UL;
	procfs_packet.reply = (void *)0x51515151UL;
	reset_fake_host_mapping();
	reset_fake_host_send_signal();
	reset_fake_procfs_answer();
	reset_fake_host_dispatch();
	fake_host_map_virtual_result = &fake_host_mapped_signal;
	fake_host_mapped_signal.sig = 12;
	fake_host_mapped_signal.pid = 3456;
	fake_host_mapped_signal.tid = 6543;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x105,
		&procfs_packet, (void *)0x205, (void *)0x305,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_host_send_signal_kill_calls);
	mix_signed(&digest, fake_host_send_signal_log_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PROCFS_REQUEST;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x106,
		&procfs_packet, (void *)0x206, (void *)0x306,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_procfs_calls);
	mix_signed(&digest, fake_host_dispatch_procfs_last_msg);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	procfs_packet.msg = SCD_MSG_PROCFS_RELEASE;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x107,
		&procfs_packet, (void *)0x207, (void *)0x307,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_procfs_calls);
	mix_signed(&digest, fake_host_dispatch_procfs_last_msg);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_CLEANUP_PROCESS;
	procfs_packet.pid = 7004;
	procfs_packet.arg = 0x70040000UL;
	procfs_packet.reply = (void *)0x7040;
	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	reset_fake_host_dispatch();
	fake_host_cleanup_process_rc = -4;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x108,
		&procfs_packet, (void *)0x208, (void *)0x308,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_cleanup_process_calls);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_terminate_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_CLEANUP_FD;
	procfs_packet.pid = 7005;
	procfs_packet.arg = 23;
	procfs_packet.reply = (void *)0x7050;
	reset_fake_host_cleanup();
	reset_fake_procfs_answer();
	reset_fake_host_dispatch();
	fake_host_cleanup_fd_rc = -5;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x109,
		&procfs_packet, (void *)0x209, (void *)0x309,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_cleanup_fd_calls);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_DEBUG_LOG;
	procfs_packet.arg = 0x70060000UL;
	reset_fake_host_debug_log();
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10a,
		&procfs_packet, (void *)0x20a, (void *)0x30a,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_debug_print_calls);
	mix_signed(&digest, fake_host_debug_log_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_SYSFS_REQ_STORE;
	procfs_packet.err = -6;
	procfs_packet.sysfs_arg1 = 0x7101;
	procfs_packet.sysfs_arg2 = 0x7102;
	procfs_packet.sysfs_arg3 = 0x7103;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10b,
		&procfs_packet, (void *)0x20b, (void *)0x30b,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_sysfs_calls);
	mix_signed(&digest,
		fake_host_dispatch_sysfs_last_channel == (void *)0x10b);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_msg);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_err);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg1);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg2);
	mix_signed(&digest, fake_host_dispatch_sysfs_last_arg3);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PERF_CTRL;
	procfs_packet.arg = 0x70070000UL;
	procfs_packet.reply = (void *)0x7070;
	reset_fake_host_mapping();
	reset_fake_host_perf();
	reset_fake_procfs_answer();
	reset_fake_host_dispatch();
	fake_host_mapped_perf_desc.ctrl_type = PERF_CTRL_GET;
	fake_host_mapped_perf_desc.target_cntr = 2;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10c,
		&procfs_packet, (void *)0x20c, (void *)0x30c,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_perf_read_calls);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_procfs_answer_last_err);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_CPU_RW_REG;
	procfs_packet.pdesc = 0x70080000UL;
	procfs_packet.op = 3;
	procfs_packet.reply = (void *)0x7080;
	reset_fake_host_mapping();
	reset_fake_host_cpu_rw();
	reset_fake_procfs_answer();
	reset_fake_host_dispatch();
	fake_host_map_virtual_result = &fake_host_mapped_cpu_reg;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10d,
		&procfs_packet, (void *)0x20d, (void *)0x30d,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_cpu_rw_calls);
	mix_signed(&digest, fake_procfs_answer_last_msg);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = 0x7777;
	procfs_packet.ref = 123;
	reset_fake_host_dispatch();
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10e,
		&procfs_packet, (void *)0x20e, (void *)0x30e,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	mix_signed(&digest, fake_host_dispatch_unknown_calls);
	mix_signed(&digest, fake_host_dispatch_unknown_last_msg);
	mix_signed(&digest, fake_host_dispatch_unknown_last_ref);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x10f,
		NULL, (void *)0x20f, (void *)0x30f, &dispatch_ops,
		PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	dispatch_ops.release_packet_fn = NULL;
	mix_signed(&digest, host_scd_packet_dispatch_result((void *)0x110,
		&procfs_packet, (void *)0x210, (void *)0x310,
		&dispatch_ops, PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	dispatch_ops = make_fake_host_dispatch_ops();

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_PREPARE_PROCESS;
	procfs_packet.ref = 7011;
	procfs_packet.arg = 0x90110000UL;
	procfs_packet.reply = (void *)0x9011;
	reset_fake_host_dispatch();
	reset_fake_procfs_answer();
	fake_host_dispatch_prepare_rc = -19;
	mix_signed(&digest, host_syscall_packet_handler_result((void *)0x111,
		&procfs_packet, (void *)0x444, &dispatch_ops,
		fake_host_handler_response_channel,
		fake_host_handler_current_thread,
		PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	require(fake_host_handler_response_calls == 1);
	require(fake_host_handler_current_calls == 1);
	require(fake_host_dispatch_prepare_calls == 1);
	require(fake_procfs_answer_last_channel == (void *)0x424200UL);
	require(fake_host_dispatch_release_calls == 1);
	mix_signed(&digest, fake_host_handler_response_calls);
	mix_signed(&digest, fake_host_handler_current_calls);
	mix_signed(&digest, fake_procfs_answer_last_channel == (void *)0x424200UL);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	memset(&procfs_packet, 0, sizeof(procfs_packet));
	procfs_packet.msg = SCD_MSG_REMOTE_PAGE_FAULT;
	procfs_packet.ref = 7012;
	procfs_packet.fault_tid = 9090;
	procfs_packet.fault_address = 0x90900000UL;
	procfs_packet.fault_reason = 0x91;
	reset_fake_host_wake_syscall();
	reset_fake_host_remote_page_fault_request();
	reset_fake_host_dispatch();
	fake_host_find_thread_result = (void *)0x515100UL;
	mix_signed(&digest, host_syscall_packet_handler_result((void *)0x112,
		&procfs_packet, (void *)0x445, &dispatch_ops,
		fake_host_handler_response_channel,
		fake_host_handler_current_thread,
		PF_POPULATE, PROFILE_remote_page_fault,
		sizeof(procfs_packet), 0x44, 2, 9));
	require(fake_host_handler_response_calls == 1);
	require(fake_host_handler_current_calls == 1);
	require(fake_host_rpf_request_body_calls == 1);
	require(fake_host_rpf_request_body_last_err == 0);
	require(fake_host_rpf_request_alloc_calls == 0);
	require(fake_host_rpf_request_defer_calls == 0);
	require(fake_host_rpf_request_unlock_calls == 1);
	require(fake_host_dispatch_release_calls == 1);
	mix_signed(&digest, fake_host_rpf_request_body_last_err);
	mix_signed(&digest, fake_host_rpf_request_alloc_calls);
	mix_signed(&digest, fake_host_rpf_request_unlock_calls);
	mix_signed(&digest, fake_host_dispatch_release_calls);

	reset_fake_host_dispatch();
	mix_signed(&digest, host_dummy_packet_handler_result((void *)0x113,
		&procfs_packet, (void *)0x446,
		fake_host_dispatch_release_packet));
	require(fake_host_dispatch_release_calls == 1);
	require(fake_host_dispatch_release_last_packet == &procfs_packet);
	mix_signed(&digest, fake_host_dispatch_release_calls);
	mix_signed(&digest,
		fake_host_dispatch_release_last_packet == &procfs_packet);
	mix_signed(&digest, host_dummy_packet_handler_result((void *)0x114,
		&procfs_packet, (void *)0x447, NULL));

	struct sysfs_req_create_param create_param;
	struct sysfs_req_mkdir_param mkdir_param;
	struct sysfs_req_symlink_param symlink_param;
	struct sysfs_req_lookup_param lookup_param;
	struct sysfs_req_unlink_param unlink_param;
	struct sysfs_req_setup_param setup_param;
	struct sysfs_bitmap_param bitmap_param;
	struct sysfs_bitmap_param bitmap_source;
	char sysfs_special_string[] = "abcd";
	int sysfs_special_direct = 0;
	int sysfs_special_bitmap_data = 0;
	long sysfs_handle = 0xabcdef;
	int sysfs_phase = -1;

	memset(&create_param, 0, sizeof(create_param));
	memset(&bitmap_param, 0, sizeof(bitmap_param));
	create_param.client_ops = (long)SYSFS_SNOOPING_OPS_d32;
	create_param.client_instance = (long)&sysfs_special_direct;
	reset_fake_sysfs();
	fake_sysfs_special_direct_ptr = &sysfs_special_direct;
	fake_sysfs_special_dest_ptr = &bitmap_param;
	mix_signed(&digest, sysfs_setup_special_create_result(&create_param,
		&bitmap_param, fake_sysfs_special_phys));
	mix_signed(&digest, create_param.client_instance);
	mix_signed(&digest, bitmap_param.nbits);
	mix_signed(&digest, bitmap_param.padding);
	mix_signed(&digest, (long)bitmap_param.ptr);

	memset(&create_param, 0, sizeof(create_param));
	memset(&bitmap_param, 0, sizeof(bitmap_param));
	create_param.client_ops = (long)SYSFS_SNOOPING_OPS_s;
	create_param.client_instance = (long)sysfs_special_string;
	reset_fake_sysfs();
	fake_sysfs_special_string_ptr = sysfs_special_string;
	fake_sysfs_special_dest_ptr = &bitmap_param;
	mix_signed(&digest, sysfs_setup_special_create_result(&create_param,
		&bitmap_param, fake_sysfs_special_phys));
	mix_signed(&digest, create_param.client_instance);
	mix_signed(&digest, bitmap_param.nbits);
	mix_signed(&digest, bitmap_param.padding);
	mix_signed(&digest, (long)bitmap_param.ptr);

	memset(&create_param, 0, sizeof(create_param));
	memset(&bitmap_param, 0, sizeof(bitmap_param));
	memset(&bitmap_source, 0, sizeof(bitmap_source));
	bitmap_source.nbits = 123;
	bitmap_source.padding = 77;
	bitmap_source.ptr = &sysfs_special_bitmap_data;
	create_param.client_ops = (long)SYSFS_SNOOPING_OPS_pbl;
	create_param.client_instance = (long)&bitmap_source;
	reset_fake_sysfs();
	fake_sysfs_special_bitmap_data_ptr = &sysfs_special_bitmap_data;
	fake_sysfs_special_dest_ptr = &bitmap_param;
	mix_signed(&digest, sysfs_setup_special_create_result(&create_param,
		&bitmap_param, fake_sysfs_special_phys));
	mix_signed(&digest, create_param.client_instance);
	mix_signed(&digest, bitmap_param.nbits);
	mix_signed(&digest, bitmap_param.padding);
	mix_signed(&digest, (long)bitmap_param.ptr);

	memset(&create_param, 0, sizeof(create_param));
	memset(&bitmap_param, 0, sizeof(bitmap_param));
	create_param.client_ops = 999;
	create_param.client_instance = (long)&sysfs_special_direct;
	reset_fake_sysfs();
	mix_signed(&digest, sysfs_setup_special_create_result(&create_param,
		&bitmap_param, fake_sysfs_special_phys));
		mix_signed(&digest,
			create_param.client_instance == (long)&sysfs_special_direct);

		{
			struct ikc_scd_packet packet = {
				.header = { .channel = (void *)0x1111 },
				.msg = -1,
				.err = -2,
				.reply = (void *)0x2222,
				.sysfs_arg1 = -3,
				.sysfs_arg2 = -4,
				.sysfs_arg3 = -5,
			};

			require(sysfss_packet_prepare_result(&packet,
				SCD_MSG_SYSFS_RESP_SHOW, -12, 0x1234,
				0x5678) == 0);
			require(packet.header.channel == (void *)0x1111);
			require(packet.msg == SCD_MSG_SYSFS_RESP_SHOW);
			require(packet.err == -12);
			require(packet.reply == (void *)0x2222);
			require(packet.sysfs_arg1 == 0x1234);
			require(packet.sysfs_arg2 == 0x5678);
			require(packet.sysfs_arg3 == -5);
			require(sysfss_packet_prepare_result(NULL,
				SCD_MSG_SYSFS_RESP_SHOW, 0, 0, 0) == -22);
			mix_signed(&digest, packet.msg);
			mix_signed(&digest, packet.err);
			mix_signed(&digest, packet.sysfs_arg1);
			mix_signed(&digest, packet.sysfs_arg2);
		}
		{
			struct ikc_scd_packet packet = {
				.header = { .channel = (void *)0x3333 },
				.msg = -1,
				.err = -2,
				.reply = (void *)0x4444,
				.sysfs_arg1 = -3,
				.sysfs_arg2 = -4,
				.sysfs_arg3 = -5,
			};

			require(sysfs_request_packet_prepare_result(&packet,
				SCD_MSG_SYSFS_REQ_LOOKUP, 0x7788) == 0);
			require(packet.header.channel == (void *)0x3333);
			require(packet.msg == SCD_MSG_SYSFS_REQ_LOOKUP);
			require(packet.err == -2);
			require(packet.reply == (void *)0x4444);
			require(packet.sysfs_arg1 == 0x7788);
			require(packet.sysfs_arg2 == -4);
			require(packet.sysfs_arg3 == -5);
			require(sysfs_request_packet_prepare_result(NULL,
				SCD_MSG_SYSFS_REQ_LOOKUP, 0) == -22);
			mix_signed(&digest, packet.msg);
			mix_signed(&digest, packet.err);
			mix_signed(&digest, packet.sysfs_arg1);
			mix_signed(&digest, packet.sysfs_arg2);
		}

		memset(&create_param, 0, sizeof(create_param));
		create_param.busy = 1;
	reset_fake_sysfs();
	fake_sysfs_request_busy_ptr = &create_param.busy;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_CREATE,
		&create_param, 0x8100, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		NULL, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_send_calls);
	mix_signed(&digest, fake_sysfs_request_last_msg);
	mix_signed(&digest, fake_sysfs_request_last_arg1);
	mix_signed(&digest, fake_sysfs_request_pause_calls);
	mix_signed(&digest, fake_sysfs_request_barrier_calls);
	mix_signed(&digest, create_param.busy);

	memset(&mkdir_param, 0, sizeof(mkdir_param));
	mkdir_param.handle = 0x12345678;
	reset_fake_sysfs();
	sysfs_handle = 0;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_MKDIR,
		&mkdir_param, 0x8200, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_handle, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_handle);
	mix_signed(&digest, fake_sysfs_request_barrier_calls);

	memset(&lookup_param, 0, sizeof(lookup_param));
	lookup_param.error = -19;
	lookup_param.handle = 0x22446688;
	reset_fake_sysfs();
	sysfs_handle = 0xabcdef;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_LOOKUP,
		&lookup_param, 0x8300, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_handle, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_handle);
	mix_signed(&digest, fake_sysfs_request_barrier_calls);

	memset(&symlink_param, 0, sizeof(symlink_param));
	symlink_param.busy = 0;
	reset_fake_sysfs();
	fake_sysfs_request_send_error = -14;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_SYMLINK,
		&symlink_param, 0x8400, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		NULL, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_send_calls);
	mix_signed(&digest, fake_sysfs_request_barrier_calls);

	memset(&unlink_param, 0, sizeof(unlink_param));
	reset_fake_sysfs();
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_UNLINK,
		&unlink_param, 0x8500, NULL, fake_sysfs_request_pause,
		fake_sysfs_request_barrier, NULL, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_send_calls);

	memset(&setup_param, 0, sizeof(setup_param));
	reset_fake_sysfs();
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(SCD_MSG_SYSFS_REQ_SETUP,
		&setup_param, 0x8600, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		NULL, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_last_msg);

	sysfs_phase = -1;
	mix_signed(&digest, sysfs_request_body_result(0x99, &setup_param,
		0x8700, fake_sysfs_request_send, fake_sysfs_request_pause,
		fake_sysfs_request_barrier, NULL, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);

	memset(&mkdir_param, 0, sizeof(mkdir_param));
	mkdir_param.handle = 0x13579;
	sysfs_handle = 0;
	sysfs_phase = -1;
	reset_fake_sysfs();
	mix_signed(&digest, sysfs_request_logged_result(SCD_MSG_SYSFS_REQ_MKDIR,
		&mkdir_param, 0x8800, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_handle, fake_sysfs_request_log, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_handle);
	mix_signed(&digest, fake_sysfs_request_log_calls);
	mix_signed(&digest, fake_sysfs_request_send_calls);
	mix_signed(&digest, fake_sysfs_request_last_msg);
	mix_signed(&digest, fake_sysfs_request_last_arg1);

	memset(&lookup_param, 0, sizeof(lookup_param));
	lookup_param.error = -19;
	lookup_param.handle = 0x2468;
	sysfs_handle = 0xabcdef;
	sysfs_phase = -1;
	reset_fake_sysfs();
	mix_signed(&digest, sysfs_request_logged_result(SCD_MSG_SYSFS_REQ_LOOKUP,
		&lookup_param, 0x8900, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_handle, fake_sysfs_request_log, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_handle);
	mix_signed(&digest, fake_sysfs_request_log_calls);
	mix_signed(&digest, fake_sysfs_request_last_event);
	mix_signed(&digest, fake_sysfs_request_log_last_msg);
	mix_signed(&digest, fake_sysfs_request_log_last_error);

	memset(&symlink_param, 0, sizeof(symlink_param));
	sysfs_phase = -1;
	reset_fake_sysfs();
	fake_sysfs_request_send_error = -14;
	mix_signed(&digest, sysfs_request_logged_result(
		SCD_MSG_SYSFS_REQ_SYMLINK, &symlink_param, 0x8a00,
		fake_sysfs_request_send, fake_sysfs_request_pause,
		fake_sysfs_request_barrier, NULL, fake_sysfs_request_log,
		&sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_log_calls);
	mix_signed(&digest, fake_sysfs_request_last_event);
	mix_signed(&digest, fake_sysfs_request_log_last_msg);
	mix_signed(&digest, fake_sysfs_request_log_last_error);

	memset(&create_param, 0, sizeof(create_param));
	sysfs_phase = -1;
	reset_fake_sysfs();
	mix_signed(&digest, sysfs_request_logged_result(SCD_MSG_SYSFS_REQ_CREATE,
		&create_param, 0x8b00, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		NULL, fake_sysfs_request_log, &sysfs_phase));
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_request_log_calls);
	mix_signed(&digest, fake_sysfs_request_last_msg);
	mix_signed(&digest, fake_sysfs_request_last_arg1);

	void *sysfs_data_buf = NULL;
	size_t sysfs_data_bufsize = 0;
	int sysfs_init_stage = -1;
	reset_fake_sysfs();
	fake_sysfs_request_busy_ptr = &fake_sysfs_init_param.busy;
	mix_signed(&digest, sysfs_init_body_result(1024, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_data_buf == fake_sysfs_init_data_buf);
	mix(&digest, sysfs_data_bufsize);
	mix_signed(&digest, fake_sysfs_init_alloc_calls);
	mix_signed(&digest, fake_sysfs_init_free_calls);
	mix_signed(&digest, fake_sysfs_request_last_msg);
	mix_signed(&digest, fake_sysfs_request_last_arg1);
	mix_signed(&digest, fake_sysfs_request_pause_calls);
	mix_signed(&digest, fake_sysfs_request_barrier_calls);
	mix_signed(&digest, fake_sysfs_init_param.busy);
	mix_signed(&digest, fake_sysfs_init_param.buf_rpa);
	mix_signed(&digest, fake_sysfs_init_param.bufsize);

	reset_fake_sysfs();
	fake_sysfs_init_fail_alloc_call = 1;
	sysfs_init_stage = -1;
	sysfs_phase = -1;
	sysfs_data_buf = NULL;
	sysfs_data_bufsize = 0;
	mix_signed(&digest, sysfs_init_body_result(1024, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_init_alloc_calls);
	mix_signed(&digest, fake_sysfs_init_free_calls);

	reset_fake_sysfs();
	fake_sysfs_init_fail_alloc_call = 2;
	sysfs_init_stage = -1;
	sysfs_phase = -1;
	sysfs_data_buf = NULL;
	sysfs_data_bufsize = 0;
	mix_signed(&digest, sysfs_init_body_result(1024, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, sysfs_data_buf == fake_sysfs_init_data_buf);
	mix_signed(&digest, fake_sysfs_init_alloc_calls);
	mix_signed(&digest, fake_sysfs_init_free_calls);

	reset_fake_sysfs();
	fake_sysfs_request_send_error = -14;
	sysfs_init_stage = -1;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_init_body_result(1024, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_init_free_calls);

	reset_fake_sysfs();
	fake_sysfs_init_param.error = -19;
	fake_sysfs_request_busy_ptr = &fake_sysfs_init_param.busy;
	sysfs_init_stage = -1;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_init_body_result(1024, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_init_free_calls);

	reset_fake_sysfs();
	sysfs_init_stage = -1;
	sysfs_phase = -1;
	mix_signed(&digest, sysfs_init_body_result(4097, 1024, 1024, 1024,
		1024, 1024, &sysfs_data_buf, &sysfs_data_bufsize,
		fake_sysfs_init_alloc, fake_sysfs_init_free,
		fake_sysfs_init_phys, fake_sysfs_request_send,
		fake_sysfs_request_pause, fake_sysfs_request_barrier,
		&sysfs_init_stage, &sysfs_phase));
	mix_signed(&digest, sysfs_init_stage);
	mix_signed(&digest, sysfs_phase);
	mix_signed(&digest, fake_sysfs_init_alloc_calls);

	ssize_t sysfs_ssize = 0;
	int sysfs_packet_err = 0;
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_req_show_body_result(0x1234,
		(void *)0x10, (void *)0x20, (void *)0x30, 128,
		fake_sysfs_show, fake_sysfs_send, &sysfs_ssize,
		&sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_send_calls);
	mix_signed(&digest, fake_sysfs_last_msg);
	mix_signed(&digest, fake_sysfs_last_err);
	mix_signed(&digest, fake_sysfs_last_arg1);
	mix_signed(&digest, fake_sysfs_last_arg2);
	reset_fake_sysfs();
	fake_sysfs_send_error = -14;
	mix_signed(&digest, sysfss_req_show_body_result(0x55, NULL, NULL,
		NULL, 4096, NULL, fake_sysfs_send, &sysfs_ssize,
		&sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_send_error);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_req_store_body_result(0x2233,
		(void *)0x11, (void *)0x22, (void *)0x33, 9,
		fake_sysfs_store, fake_sysfs_send, &sysfs_ssize,
		&sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_last_msg);
	mix_signed(&digest, fake_sysfs_last_err);
	mix_signed(&digest, fake_sysfs_last_arg2);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_req_release_body_result(0x3344,
		(void *)0x44, (void *)0x55, fake_sysfs_release,
		fake_sysfs_send, &sysfs_packet_err));
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_release_calls);
	mix_signed(&digest, fake_sysfs_last_msg);
	mix_signed(&digest, fake_sysfs_last_arg1);
	reset_fake_sysfs();
	sysfs_ssize = 0;
	sysfs_packet_err = 0;
	mix_signed(&digest, sysfss_req_show_logged_result(0x4455,
		(void *)0x101, (void *)0x202, (void *)0x303, 64,
		0x1, fake_sysfs_show, fake_sysfs_send, fake_sysfs_req_log,
		&sysfs_ssize, &sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_req_log_calls);
	mix_signed(&digest, fake_sysfs_req_log_mask);
	mix_signed(&digest, fake_sysfs_req_last_event);
	mix_signed(&digest, fake_sysfs_req_last_nodeh);
	mix_signed(&digest, fake_sysfs_req_last_ops);
	mix_signed(&digest, fake_sysfs_req_last_instance);
	mix_signed(&digest, fake_sysfs_req_last_size);
	mix_signed(&digest, fake_sysfs_req_last_error);
	mix_signed(&digest, fake_sysfs_req_last_packet_err);
	mix_signed(&digest, fake_sysfs_req_last_ssize);
	reset_fake_sysfs();
	fake_sysfs_send_error = -14;
	sysfs_ssize = 0;
	sysfs_packet_err = 0;
	mix_signed(&digest, sysfss_req_show_logged_result(0x5566,
		(void *)0x111, (void *)0x222, (void *)0x333, 4096,
		0, fake_sysfs_show, fake_sysfs_send, fake_sysfs_req_log,
		&sysfs_ssize, &sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_req_log_calls);
	mix_signed(&digest, fake_sysfs_req_log_mask);
	mix_signed(&digest, fake_sysfs_req_last_event);
	mix_signed(&digest, fake_sysfs_req_last_error);
	mix_signed(&digest, fake_sysfs_req_last_packet_err);
	reset_fake_sysfs();
	sysfs_ssize = 0;
	sysfs_packet_err = 0;
	mix_signed(&digest, sysfss_req_store_logged_result(0x6677,
		(void *)0x121, (void *)0x232, (void *)0x343, 12,
		0x1, fake_sysfs_store, fake_sysfs_send, fake_sysfs_req_log,
		&sysfs_ssize, &sysfs_packet_err));
	mix_signed(&digest, sysfs_ssize);
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_req_log_calls);
	mix_signed(&digest, fake_sysfs_req_log_mask);
	mix_signed(&digest, fake_sysfs_req_last_event);
	mix_signed(&digest, fake_sysfs_req_last_size);
	mix_signed(&digest, fake_sysfs_req_last_packet_err);
	mix_signed(&digest, fake_sysfs_req_last_ssize);
	reset_fake_sysfs();
	sysfs_packet_err = -1;
	mix_signed(&digest, sysfss_req_release_logged_result(0x7788,
		(void *)0x131, (void *)0x242, 0x1, fake_sysfs_release,
		fake_sysfs_send, fake_sysfs_req_log, &sysfs_packet_err));
	mix_signed(&digest, sysfs_packet_err);
	mix_signed(&digest, fake_sysfs_release_calls);
	mix_signed(&digest, fake_sysfs_req_log_calls);
	mix_signed(&digest, fake_sysfs_req_log_mask);
	mix_signed(&digest, fake_sysfs_req_last_event);
	mix_signed(&digest, fake_sysfs_req_last_nodeh);
	int sysfs_handler_kind = 0;
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_body_result(0x3a, 77,
		0x4001, 0x4002, 0x4003, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		&sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_show_calls);
	mix_signed(&digest, fake_sysfs_packet_last_nodeh);
	mix_signed(&digest, fake_sysfs_packet_last_ops);
	mix_signed(&digest, fake_sysfs_packet_last_instance);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_body_result(0x3c, 99,
		0x5001, 0x5002, 0x5003, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		&sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_store_calls);
	mix_signed(&digest, fake_sysfs_packet_last_nodeh);
	mix_signed(&digest, fake_sysfs_packet_last_ops);
	mix_signed(&digest, fake_sysfs_packet_last_instance);
	mix(&digest, fake_sysfs_packet_last_size);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_body_result(0x3e, 0,
		0x6001, 0x6002, 0x6003, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		&sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_release_calls);
	mix_signed(&digest, fake_sysfs_packet_last_nodeh);
	mix_signed(&digest, fake_sysfs_packet_last_ops);
	mix_signed(&digest, fake_sysfs_packet_last_instance);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_body_result(0x41, -1,
		0x7001, 0x7002, 0x7003, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		&sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_show_calls);
	mix_signed(&digest, fake_sysfs_packet_store_calls);
	mix_signed(&digest, fake_sysfs_packet_release_calls);
	mix_signed(&digest, fake_sysfs_packet_unknown_calls);

	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_logged_result(0x3a, 11,
		0x7101, 0x7102, 0x7103, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		fake_sysfs_packet_unknown, &sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_show_calls);
	mix_signed(&digest, fake_sysfs_packet_unknown_calls);
	mix_signed(&digest, fake_sysfs_packet_last_nodeh);
	mix_signed(&digest, fake_sysfs_packet_last_ops);
	mix_signed(&digest, fake_sysfs_packet_last_instance);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_logged_result(0x41, -5,
		0x7201, 0x7202, 0x7203, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		fake_sysfs_packet_unknown, &sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_unknown_calls);
	mix_signed(&digest, fake_sysfs_packet_last_msg);
	mix_signed(&digest, fake_sysfs_packet_last_error);
	mix_signed(&digest, fake_sysfs_packet_last_arg1);
	mix_signed(&digest, fake_sysfs_packet_last_arg2);
	mix_signed(&digest, fake_sysfs_packet_last_arg3);
	reset_fake_sysfs();
	mix_signed(&digest, sysfss_packet_handler_logged_result(0x41, -6,
		0x7301, 0x7302, 0x7303, fake_sysfs_packet_show,
		fake_sysfs_packet_store, fake_sysfs_packet_release,
		NULL, &sysfs_handler_kind));
	mix_signed(&digest, sysfs_handler_kind);
	mix_signed(&digest, fake_sysfs_packet_unknown_calls);

	mix(&digest, procfs_mem_reason_result(0));
		mix(&digest, procfs_mem_reason_result(1));
		for (unsigned long left = 0; left <= 8192; left += 2048)
			mix_signed(&digest, procfs_mem_chunk_size_result(4095, left));
		{
			unsigned long procfs_mem_vm_digest = 0x1001;
			unsigned long procfs_mem_pt_digest = 0x2002;
			char procfs_mem_user[6000];

			reset_fake_procfs_mem();
			for (unsigned int i = 0; i < sizeof(fake_procfs_mem_space); i++)
				fake_procfs_mem_space[i] = (unsigned char)(i & 0xff);
			memset(procfs_mem_user, 0xa5, sizeof(procfs_mem_user));
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 4095, 5000, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix(&digest, procfs_mem_vm_digest);
			mix(&digest, procfs_mem_pt_digest);
			mix_signed(&digest, fake_procfs_mem_page_fault_calls);
			mix_signed(&digest, fake_procfs_mem_vtop_calls);
			mix_signed(&digest, fake_procfs_mem_is_memory_calls);
			mix_signed(&digest, fake_procfs_mem_phys_to_virt_calls);
			mix_signed(&digest, fake_procfs_mem_copy_calls);
			mix(&digest, fake_procfs_mem_copy_bytes);
			mix_signed(&digest, memcmp(procfs_mem_user,
				&fake_procfs_mem_space[4095], 5000));

			reset_fake_procfs_mem();
			for (unsigned int i = 0; i < sizeof(procfs_mem_user); i++)
				procfs_mem_user[i] = (char)('a' + (i % 26));
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 8190, 17, 1,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix_signed(&digest, fake_procfs_mem_copy_calls);
			mix(&digest, fake_procfs_mem_copy_bytes);
			mix_signed(&digest, fake_procfs_mem_space[8190]);
			mix_signed(&digest, fake_procfs_mem_space[8206]);

			reset_fake_procfs_mem();
			fake_procfs_mem_page_fault_fail_call = 2;
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 4095, 10, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix_signed(&digest, fake_procfs_mem_page_fault_calls);
			mix_signed(&digest, fake_procfs_mem_copy_calls);
			mix(&digest, fake_procfs_mem_copy_bytes);

			reset_fake_procfs_mem();
			fake_procfs_mem_vtop_fail_call = 1;
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 4095, 10, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix_signed(&digest, fake_procfs_mem_vtop_calls);
			mix_signed(&digest, fake_procfs_mem_copy_calls);

			reset_fake_procfs_mem();
			fake_procfs_mem_is_memory_fail_call = 2;
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 4095, 4098, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix_signed(&digest, fake_procfs_mem_is_memory_calls);
			mix_signed(&digest, fake_procfs_mem_copy_calls);
			mix(&digest, fake_procfs_mem_copy_bytes);

			reset_fake_procfs_mem();
			mix_signed(&digest, procfs_mem_copy_body_result(
				&procfs_mem_vm_digest, &procfs_mem_pt_digest,
				procfs_mem_user, 0, 0, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
			mix_signed(&digest, fake_procfs_mem_page_fault_calls);
			mix_signed(&digest, procfs_mem_copy_body_result(
				NULL, &procfs_mem_pt_digest, procfs_mem_user, 0, 1, 0,
				fake_procfs_mem_page_fault,
				fake_procfs_mem_virt_to_phys,
				fake_procfs_mem_is_memory,
				fake_procfs_mem_phys_to_virt,
				fake_procfs_mem_copy));
		}
		mix_signed(&digest, procfs_default_count_result());
		for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++) {
		for (unsigned int j = 0; j < sizeof(counts) / sizeof(counts[0]); j++) {
			mix_signed(&digest, procfs_remote_count_result(addrs[i],
				counts[j]));
			mix_signed(&digest, procfs_remote_npages_result(counts[j]));
			mix_signed(&digest, procfs_format_error_result(addrs[i] &
				0xffff, counts[j]));
		}
	}
	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++)
		mix(&digest, procfs_locked_kb_result(sizes[i]));

	for (int count = -8; count <= 24; count += 8) {
		mix_signed(&digest, procfs_pagemap_range_result(16, count, &start, &end));
		mix(&digest, start);
		mix(&digest, end);
		}
		mix_signed(&digest, procfs_pagemap_range_result(3, 8, &start, &end));
		{
			unsigned long procfs_pagemap_pt_digest = 0x3003;
			unsigned long pagemap_out[4] = { 0 };

			reset_fake_procfs_mem();
			mix_signed(&digest, procfs_pagemap_body_result(
				&procfs_pagemap_pt_digest, pagemap_out,
				0x1000, 0x4000, 24, fake_procfs_pagemap_value));
			mix_signed(&digest, fake_procfs_pagemap_calls);
			mix(&digest, fake_procfs_pagemap_last_addr);
			mix(&digest, procfs_pagemap_pt_digest);
			mix(&digest, pagemap_out[0]);
			mix(&digest, pagemap_out[2]);
			mix_signed(&digest, procfs_pagemap_body_result(
				NULL, pagemap_out, 0x1000, 0x2000, 8,
				fake_procfs_pagemap_value));
		}

		for (unsigned int i = 0; i < sizeof(statuses) / sizeof(statuses[0]); i++) {
		mix_signed(&digest, procfs_status_state_result(statuses[i]));
		mix_signed(&digest, procfs_thread_stat_state_result(statuses[i], 0));
		mix_signed(&digest, procfs_thread_stat_state_result(statuses[i], 1));
	}
	for (unsigned int i = 0; i < sizeof(map_flags) / sizeof(map_flags[0]); i++) {
		mix_signed(&digest, procfs_maps_read_char_result(map_flags[i]));
		mix_signed(&digest, procfs_maps_write_char_result(map_flags[i]));
		mix_signed(&digest, procfs_maps_exec_char_result(map_flags[i]));
		mix_signed(&digest, procfs_maps_private_char_result(map_flags[i]));
		mix_signed(&digest, procfs_maps_path_kind_result(0x1000,
			0x2000, map_flags[i], 0x1000, 0x3000, 0x4000, 0x8000));
		mix_signed(&digest, procfs_maps_path_kind_result(0x3000,
			0x4000, map_flags[i], 0x1000, 0x3000, 0x4000, 0x8000));
		mix_signed(&digest, procfs_maps_path_kind_result(0x5000,
			0x6000, map_flags[i], 0x1000, 0x3000, 0x4000, 0x8000));
	}
	for (unsigned long pos = 0; pos <= 8192; pos += 4096)
		mix(&digest, procfs_pagemap_next_result(pos));
	mix(&digest, procfs_auxv_limit_result());
	for (unsigned long ptr = 0; ptr <= 1; ptr++)
		mix(&digest, procfs_cmdline_limit_result(ptr, 1234));
	for (unsigned int i = 0; i < sizeof(messages) / sizeof(messages[0]); i++)
		mix_signed(&digest, procfs_is_release_result(messages[i]));
	for (int ret = -1; ret <= 2; ret++)
		mix_signed(&digest, procfs_root_matched_result(ret));
	for (int osnum = 0; osnum <= 2; osnum++) {
		for (int req = 0; req <= 2; req++)
			mix_signed(&digest, procfs_osnum_match_result(osnum, req));
	}
	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++)
		mix_signed(&digest, procfs_zero_length_result(sizes[i]));
	for (unsigned int i = 0; i < sizeof(map_flags) / sizeof(map_flags[0]); i++)
		mix(&digest, procfs_locked_size_add_result(1024, 4096,
			8192, map_flags[i]));
	for (int offset = -2; offset <= 8; offset += 5) {
		for (int written = -1; written <= 4; written += 5)
			mix_signed(&digest,
				procfs_bitmask_next_offset_result(offset, written));
	}
	mix_signed(&digest, procfs_pbuf_is_empty_result(~0UL));
	mix_signed(&digest, procfs_pbuf_is_empty_result(0));
	for (unsigned long ptr = 0; ptr <= 2; ptr++) {
		mix_signed(&digest, procfs_backlog_needed_result(ptr));
		mix_signed(&digest, procfs_lock_failed_action_result(ptr));
		mix_signed(&digest, procfs_pointer_present_result(ptr));
	}
	mix_signed(&digest, procfs_lock_retry_result());
	mix_signed(&digest, procfs_entry_kind_result(NULL));
	for (unsigned int i = 0; i < sizeof(procfs_names) / sizeof(procfs_names[0]); i++)
		mix_signed(&digest, procfs_entry_kind_result(procfs_names[i]));
	mix_signed(&digest, ptr_offset(NULL, procfs_comm_basename_result(0)));
	for (unsigned int i = 0; i < sizeof(cmdlines) / sizeof(cmdlines[0]); i++)
		mix_signed(&digest, ptr_offset(cmdlines[i],
			procfs_comm_basename_result((uintptr_t)cmdlines[i])));
	mix(&digest, procfs_comm_name_result((uintptr_t)"exe", 0) ==
		(uintptr_t)"exe");
	mix(&digest, procfs_comm_name_result((uintptr_t)"exe",
		(uintptr_t)"bash") == (uintptr_t)"bash");
	for (int task = 0; task <= 1; task++) {
		mix_signed(&digest, procfs_thread_tid_result(task, 77, 42));
		mix_signed(&digest, procfs_task_missing_terminal_result(task));
	}
	{
		const unsigned long pbufs[] = { 0, ~0UL - 1, ~0UL };

		for (unsigned int p = 0; p < sizeof(pbufs) / sizeof(pbufs[0]); p++) {
		for (unsigned long top = 0; top <= 1; top++)
			mix_signed(&digest,
				procfs_buffer_chain_attach_result(pbufs[p], top));
		}
	}
	{
		char procfs_src[5000];
		struct mckernel_procfs_buffer *top = NULL;
		struct mckernel_procfs_buffer *cur = NULL;
		struct procfs_read request;

			for (unsigned int i = 0; i < sizeof(procfs_src); i++)
				procfs_src[i] = (char)('A' + (i % 26));

			reset_fake_procfs_buf();
			fake_procfs_pages[0].buffer.next_pa = 0x1234;
			fake_procfs_pages[0].buffer.pos = 99;
			fake_procfs_pages[0].buffer.size = 88;
			{
				unsigned long phys = 0;
				struct mckernel_procfs_buffer *pbuf =
					procfs_buf_alloc_result(&phys, 123,
						fake_procfs_buf_page_alloc,
						fake_procfs_buf_phys, 0x55UL);
				mix_signed(&digest,
					pbuf == &fake_procfs_pages[0].buffer);
				mix_signed(&digest, fake_procfs_buf_page_alloc_calls);
				mix_signed(&digest,
					fake_procfs_buf_page_alloc_last_npages);
				mix(&digest, fake_procfs_buf_page_alloc_last_flags);
				mix(&digest, phys);
				mix(&digest, fake_procfs_pages[0].buffer.next_pa);
				mix(&digest, fake_procfs_pages[0].buffer.pos);
				mix(&digest, fake_procfs_pages[0].buffer.size);
			}

			reset_fake_procfs_buf();
			mix_signed(&digest, procfs_buf_alloc_result(NULL, 55,
				fake_procfs_buf_page_alloc, NULL, 0x44UL) ==
				&fake_procfs_pages[0].buffer);
			mix_signed(&digest, fake_procfs_buf_page_alloc_calls);
			reset_fake_procfs_buf();
			fake_procfs_buf_fail_page_alloc_call = 1;
			mix_signed(&digest, procfs_buf_alloc_result(NULL, 55,
				fake_procfs_buf_page_alloc, NULL, 0x44UL) == NULL);
			mix_signed(&digest, fake_procfs_buf_page_alloc_calls);
			mix_signed(&digest, procfs_buf_alloc_result(NULL, 55,
				NULL, NULL, 0x44UL) == NULL);
			{
				unsigned long phys = 0;
				mix_signed(&digest, procfs_buf_alloc_result(&phys, 55,
					fake_procfs_buf_page_alloc, NULL, 0x44UL) ==
					NULL);
			}

			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_root_entry_body_result(
				PROCFS_ENTRY_MCKERNEL, "1.2.3", "build7", 0, 64,
				&top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top, fake_procfs_buf_copy));
			mix_signed(&digest, fake_procfs_buf_alloc_calls);
			mix_signed(&digest, fake_procfs_buf_copy_calls);
			mix(&digest, fake_procfs_buf_copy_bytes);
			mix(&digest, top->size);
			mix_signed(&digest, memcmp(top->buf, "1.2.3-build7\n", 13));

			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_root_entry_body_result(
				PROCFS_ENTRY_STAT, NULL, NULL, 3, 32,
				&top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top, fake_procfs_buf_copy));
			mix_signed(&digest, fake_procfs_buf_alloc_calls);
			mix_signed(&digest, fake_procfs_buf_copy_calls);
			mix(&digest, fake_procfs_buf_copy_bytes);
			mix_signed(&digest, memcmp(top->buf, "cpu0\ncpu1\ncpu2\n", 15));
			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_root_entry_body_result(
				PROCFS_ENTRY_STAT, NULL, NULL, 1, 1,
				&top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top, fake_procfs_buf_copy));
			mix_signed(&digest, fake_procfs_buf_alloc_calls);

			{
				unsigned long auxv[38];
				char cmdline[] = "/sbin/init";
				char commline[] = "/usr/bin/bash";

				for (unsigned int i = 0; i < 38; i++)
					auxv[i] = 0xabc000UL + i;

				reset_fake_procfs_buf();
				top = NULL;
				cur = NULL;
				mix_signed(&digest, procfs_pid_simple_entry_body_result(
					PROCFS_ENTRY_AUXV, auxv, cmdline,
					sizeof(cmdline), "exe", &top, &cur,
					fake_procfs_buf_alloc, fake_procfs_buf_free_top,
					fake_procfs_buf_copy));
				mix(&digest, top->size);
				mix_signed(&digest, memcmp(top->buf, auxv, sizeof(auxv)));

				reset_fake_procfs_buf();
				top = NULL;
				cur = NULL;
				mix_signed(&digest, procfs_pid_simple_entry_body_result(
					PROCFS_ENTRY_CMDLINE, auxv, cmdline,
					sizeof(cmdline), "exe", &top, &cur,
					fake_procfs_buf_alloc, fake_procfs_buf_free_top,
					fake_procfs_buf_copy));
				mix(&digest, top->size);
				mix_signed(&digest, memcmp(top->buf, cmdline, sizeof(cmdline)));

				reset_fake_procfs_buf();
				top = NULL;
				cur = NULL;
				mix_signed(&digest, procfs_pid_simple_entry_body_result(
					PROCFS_ENTRY_CMDLINE, auxv, NULL, 99, "exe",
					&top, &cur, fake_procfs_buf_alloc,
					fake_procfs_buf_free_top, fake_procfs_buf_copy));
				mix_signed(&digest, fake_procfs_buf_alloc_calls);
				mix(&digest, top ? top->size : 0);

				reset_fake_procfs_buf();
				top = NULL;
				cur = NULL;
				mix_signed(&digest, procfs_pid_simple_entry_body_result(
					PROCFS_ENTRY_COMM, auxv, commline,
					sizeof(commline), "exe", &top, &cur,
					fake_procfs_buf_alloc, fake_procfs_buf_free_top,
					fake_procfs_buf_copy));
				mix(&digest, top->size);
				mix_signed(&digest, memcmp(top->buf, "bash\n", 5));

				reset_fake_procfs_buf();
				top = NULL;
				cur = NULL;
				mix_signed(&digest, procfs_pid_simple_entry_body_result(
					PROCFS_ENTRY_COMM, auxv, NULL, 0, "exe",
					&top, &cur, fake_procfs_buf_alloc,
					fake_procfs_buf_free_top, fake_procfs_buf_copy));
				mix(&digest, top->size);
				mix_signed(&digest, memcmp(top->buf, "exe\n", 4));
			}

			reset_fake_procfs_buf();
			mix_signed(&digest, procfs_buf_add_result(&top, &cur,
				procfs_src, 3, fake_procfs_buf_alloc,
			fake_procfs_buf_free_top, fake_procfs_buf_copy));
		mix_signed(&digest, top == &fake_procfs_pages[0].buffer);
		mix_signed(&digest, cur == &fake_procfs_pages[0].buffer);
		mix_signed(&digest, fake_procfs_buf_alloc_calls);
		mix_signed(&digest, fake_procfs_buf_copy_calls);
		mix(&digest, fake_procfs_buf_copy_bytes);
		mix(&digest, top->size);
		mix(&digest, top->next_pa);
		mix_signed(&digest, memcmp(top->buf, "ABC", 3));

		reset_fake_procfs_buf();
		top = NULL;
		cur = NULL;
		mix_signed(&digest, procfs_buf_add_result(&top, &cur,
			procfs_src, sizeof(procfs_src), fake_procfs_buf_alloc,
			fake_procfs_buf_free_top, fake_procfs_buf_copy));
		mix_signed(&digest, fake_procfs_buf_alloc_calls);
		mix_signed(&digest, fake_procfs_buf_copy_calls);
		mix(&digest, fake_procfs_buf_copy_bytes);
		mix(&digest, fake_procfs_pages[0].buffer.size);
		mix(&digest, fake_procfs_pages[0].buffer.next_pa);
		mix(&digest, fake_procfs_pages[1].buffer.pos);
		mix(&digest, fake_procfs_pages[1].buffer.size);
		mix_signed(&digest,
			cur == &fake_procfs_pages[1].buffer);
		mix_signed(&digest,
			fake_procfs_pages[1].buffer.buf[0] == procfs_src[4072]);
		mix_signed(&digest,
			fake_procfs_pages[1].buffer.buf[927] == procfs_src[4999]);

		reset_fake_procfs_buf();
		top = NULL;
		cur = NULL;
		fake_procfs_buf_fail_alloc_call = 2;
		mix_signed(&digest, procfs_buf_add_result(&top, &cur,
			procfs_src, sizeof(procfs_src), fake_procfs_buf_alloc,
			fake_procfs_buf_free_top, fake_procfs_buf_copy));
		mix_signed(&digest, top == NULL);
		mix_signed(&digest, cur == NULL);
		mix_signed(&digest, fake_procfs_buf_alloc_calls);
		mix_signed(&digest, fake_procfs_buf_free_top_calls);
		mix_signed(&digest, fake_procfs_buf_free_page_calls);
		mix(&digest, fake_procfs_buf_free_mask);

		reset_fake_procfs_buf();
		fake_procfs_pages[0].buffer.next_pa =
			fake_procfs_buf_phys(&fake_procfs_pages[1].buffer);
		fake_procfs_pages[1].buffer.next_pa = ~0UL;
		mix_signed(&digest, procfs_buf_release_result(
			fake_procfs_buf_phys(&fake_procfs_pages[0].buffer),
			fake_procfs_buf_phys_to_virt,
			fake_procfs_buf_free_page));
		mix_signed(&digest, fake_procfs_buf_free_page_calls);
		mix(&digest, fake_procfs_buf_free_mask);

		mix_signed(&digest, procfs_buf_release_result(~0UL,
			fake_procfs_buf_phys_to_virt,
			fake_procfs_buf_free_page));
		mix_signed(&digest, procfs_buf_add_result(NULL, &cur,
			procfs_src, 1, fake_procfs_buf_alloc,
			fake_procfs_buf_free_top, fake_procfs_buf_copy));

		reset_fake_procfs_buf();
		memset(&request, 0, sizeof(request));
		request.pbuf = fake_procfs_buf_phys(&fake_procfs_pages[0].buffer);
		request.eof = 77;
		fake_procfs_pages[0].buffer.next_pa =
			fake_procfs_buf_phys(&fake_procfs_pages[1].buffer);
		fake_procfs_pages[1].buffer.next_pa = ~0UL;
		mix_signed(&digest, procfs_release_request_result(&request,
			fake_procfs_buf_phys_to_virt,
			fake_procfs_buf_free_page));
		mix_signed(&digest, request.ret);
		mix_signed(&digest, request.eof);
		mix_signed(&digest, fake_procfs_buf_free_page_calls);
		mix(&digest, fake_procfs_buf_free_mask);

		mix_signed(&digest, procfs_release_request_result(NULL,
			fake_procfs_buf_phys_to_virt,
			fake_procfs_buf_free_page));

		reset_fake_procfs_buf();
		memset(&request, 0, sizeof(request));
		request.pbuf = ~0UL;
		mix_signed(&digest, procfs_finish_request_result(&request,
			123, 1, &fake_procfs_pages[2].buffer,
			fake_procfs_buf_phys));
		mix_signed(&digest, request.ret);
		mix_signed(&digest, request.eof);
		mix(&digest, request.pbuf);

		memset(&request, 0, sizeof(request));
		request.pbuf = 0x1234UL;
		mix_signed(&digest, procfs_finish_request_result(&request,
			-7, 0, &fake_procfs_pages[1].buffer,
			fake_procfs_buf_phys));
		mix_signed(&digest, request.ret);
		mix_signed(&digest, request.eof);
		mix(&digest, request.pbuf);

		memset(&request, 0, sizeof(request));
		request.pbuf = ~0UL;
		mix_signed(&digest, procfs_finish_request_result(&request,
			5, 0, NULL, NULL));
		mix_signed(&digest, request.ret);
		mix_signed(&digest, request.eof);
		mix(&digest, request.pbuf);

		mix_signed(&digest, procfs_finish_request_result(NULL,
			0, 0, NULL, fake_procfs_buf_phys));

		{
			const char maps_expected[] =
				"000000400000-000000401000 r-xp 0 0:0 0\t\t\t/bin/app\n"
				"000000700000-000000701000 r--s 0 0:0 0\t\t\t[vdso]\n"
				"000000800000-000000802000 rw-p 0 0:0 0\t\t\t[heap]\n";
			const char status_expected[] =
				"Pid:\t42\n"
				"Uid:\t1\t2\t3\t4\n"
				"Gid:\t5\t6\t7\t8\n"
				"State:\tT (stopped)\n"
				"VmLck:\t        8 kB\n"
				"Threads:\t3\n"
				"Cpus_allowed:\t0000000f\n"
				"Cpus_allowed_list:\t0-3\n"
				"Mems_allowed:\t00000003\n"
				"Mems_allowed_list:\t0-1\n";
			struct procfs_status_body_input status_input;
			struct procfs_stat_body_input stat_input;
			char stat_expected[512];
			int expected_len;

			fake_procfs_ranges[0].start = 0x400000UL;
			fake_procfs_ranges[0].end = 0x401000UL;
			fake_procfs_ranges[0].flag =
				VR_PROT_READ | VR_PROT_EXEC | VR_PRIVATE;
			fake_procfs_ranges[0].path = "/bin/app";
			fake_procfs_ranges[0].next = 1;
			fake_procfs_ranges[1].start = 0x700000UL;
			fake_procfs_ranges[1].end = 0x701000UL;
			fake_procfs_ranges[1].flag = VR_PROT_READ;
			fake_procfs_ranges[1].path = NULL;
			fake_procfs_ranges[1].next = 2;
			fake_procfs_ranges[2].start = 0x800000UL;
			fake_procfs_ranges[2].end = 0x802000UL;
			fake_procfs_ranges[2].flag = VR_PROT_READ |
				VR_PROT_WRITE | VR_PRIVATE | VR_LOCKED;
			fake_procfs_ranges[2].path = NULL;
			fake_procfs_ranges[2].next = -1;

			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_maps_body_result(
				fake_procfs_ranges, &fake_procfs_ranges[0],
				0x700000UL, 0x710000UL, 0x800000UL,
				0x802000UL, sizeof(maps_expected),
				&top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top,
				fake_procfs_buf_copy, fake_procfs_range_ulong,
				fake_procfs_range_path,
				fake_procfs_range_next));
			mix_signed(&digest, top != NULL);
			if (top) {
				mix(&digest, top->size);
				mix_signed(&digest, top->size ==
					sizeof(maps_expected) - 1);
				mix_signed(&digest, memcmp(top->buf, maps_expected,
					sizeof(maps_expected) - 1));
			}
			mix_signed(&digest, procfs_maps_body_result(
				fake_procfs_ranges, &fake_procfs_ranges[0],
				0x700000UL, 0x710000UL, 0x800000UL,
				0x802000UL, 16, &top, &cur,
				fake_procfs_buf_alloc, fake_procfs_buf_free_top,
				fake_procfs_buf_copy, fake_procfs_range_ulong,
				fake_procfs_range_path,
				fake_procfs_range_next));
			mix(&digest, procfs_locked_size_body_result(
				fake_procfs_ranges, &fake_procfs_ranges[0],
				fake_procfs_range_ulong,
				fake_procfs_range_next));

			memset(&status_input, 0, sizeof(status_input));
			status_input.pid = 42;
			status_input.ruid = 1;
			status_input.euid = 2;
			status_input.suid = 3;
			status_input.fsuid = 4;
			status_input.rgid = 5;
			status_input.egid = 6;
			status_input.sgid = 7;
			status_input.fsgid = 8;
			status_input.status = PS_STOPPED;
			status_input.nr_threads = 3;
			status_input.lockedsize = 8192;
			status_input.cpu_bitmask = "0000000f";
			status_input.cpu_list = "0-3";
			status_input.numa_bitmask = "00000003";
			status_input.numa_list = "0-1";

			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_status_body_result(
				&status_input, sizeof(status_expected),
				&top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top,
				fake_procfs_buf_copy));
			mix_signed(&digest, top != NULL);
			if (top) {
				mix(&digest, top->size);
				mix_signed(&digest, top->size ==
					sizeof(status_expected) - 1);
				mix_signed(&digest, memcmp(top->buf, status_expected,
					sizeof(status_expected) - 1));
			}
			mix_signed(&digest, procfs_status_body_result(
				&status_input, 16, &top, &cur,
				fake_procfs_buf_alloc, fake_procfs_buf_free_top,
				fake_procfs_buf_copy));

			memset(&stat_input, 0, sizeof(stat_input));
			stat_input.tid = 44;
			stat_input.comm = "bash";
			stat_input.state = 'R';
			stat_input.ppid = 1;
			stat_input.pid = 42;
			stat_input.nr_threads = 3;
			stat_input.cpu_id = 7;
			expected_len = snprintf(stat_expected,
				sizeof(stat_expected),
				"%d (%s) %c %d "
				"%d %d %d %d "
				"%u %lu %lu %lu "
				"%lu %lu %lu %ld "
				"%ld %ld %ld %ld "
				"%ld %llu %lu %ld "
				"%lu %lu %lu %lu "
				"%lu %lu %lu %lu "
				"%lu %lu %lu %lu "
				"%lu %d %d %u "
				"%u %llu %lu %ld\n",
				44, "bash", 'R', 1,
				42, 0, 0, 0,
				0, 0UL, 0UL, 0UL,
				0UL, 0UL, 0UL, 0L,
				0L, 0L, 0L, 3L,
				0L, 0ULL, 0UL, 0L,
				0UL, 0UL, 0UL, 0UL,
				0UL, 0UL, 0UL, 0UL,
				0UL, 0UL, 0UL, 0UL,
				0UL, 0, 7, 0,
				0, 0ULL, 0UL, 0L);
			mix_signed(&digest, expected_len > 0);
			reset_fake_procfs_buf();
			top = NULL;
			cur = NULL;
			mix_signed(&digest, procfs_stat_body_result(&stat_input,
				sizeof(stat_expected), &top, &cur,
				fake_procfs_buf_alloc, fake_procfs_buf_free_top,
				fake_procfs_buf_copy));
			mix_signed(&digest, top != NULL);
			if (top && expected_len > 0) {
				mix(&digest, top->size);
				mix_signed(&digest, top->size ==
					(unsigned long)expected_len);
				mix_signed(&digest, memcmp(top->buf, stat_expected,
					(size_t)expected_len));
			}
			mix_signed(&digest, procfs_stat_body_result(&stat_input,
				16, &top, &cur, fake_procfs_buf_alloc,
				fake_procfs_buf_free_top,
				fake_procfs_buf_copy));
		}

		{
			struct ikc_scd_packet backlog_request;

			memset(&backlog_request, 0, sizeof(backlog_request));
			backlog_request.msg = 0x14;
			backlog_request.ref = 31;
			backlog_request.pid = 123;
			backlog_request.arg = 0xabcdef00UL;
			backlog_request.reply = (void *)0x12345678UL;

			reset_fake_procfs_backlog();
			mix_signed(&digest, procfs_backlog_result(
				&backlog_request, fake_procfs_backlog_func,
				fake_procfs_backlog_alloc,
				fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0x22UL));
			mix_signed(&digest, fake_procfs_backlog_alloc_calls);
			mix(&digest, fake_procfs_backlog_alloc_last_size);
			mix(&digest, fake_procfs_backlog_alloc_last_flags);
			mix_signed(&digest, fake_procfs_backlog_copy_calls);
			mix_signed(&digest,
				fake_procfs_backlog_copy_last_dst ==
				&fake_procfs_backlog_packet_storage);
			mix_signed(&digest,
				fake_procfs_backlog_copy_last_src ==
				&backlog_request);
			mix(&digest, fake_procfs_backlog_copy_last_size);
			mix_signed(&digest, fake_procfs_backlog_add_calls);
			mix_signed(&digest,
				fake_procfs_backlog_add_last_fn ==
				fake_procfs_backlog_func);
			mix_signed(&digest,
				fake_procfs_backlog_add_last_arg ==
				&fake_procfs_backlog_packet_storage);
			mix_signed(&digest, fake_procfs_backlog_free_calls);
			mix_signed(&digest, fake_procfs_backlog_packet_storage.msg);
			mix_signed(&digest, fake_procfs_backlog_packet_storage.ref);
			mix_signed(&digest, fake_procfs_backlog_packet_storage.pid);
			mix(&digest, fake_procfs_backlog_packet_storage.arg);
			mix(&digest, (uintptr_t)fake_procfs_backlog_packet_storage.reply);

			reset_fake_procfs_backlog();
			fake_procfs_backlog_alloc_fail = 1;
			mix_signed(&digest, procfs_backlog_result(
				&backlog_request, fake_procfs_backlog_func,
				fake_procfs_backlog_alloc,
				fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0x33UL));
			mix_signed(&digest, fake_procfs_backlog_alloc_calls);
			mix_signed(&digest, fake_procfs_backlog_copy_calls);
			mix_signed(&digest, fake_procfs_backlog_add_calls);
			mix_signed(&digest, fake_procfs_backlog_free_calls);

			reset_fake_procfs_backlog();
			fake_procfs_backlog_add_rc = -123;
			mix_signed(&digest, procfs_backlog_result(
				&backlog_request, fake_procfs_backlog_func,
				fake_procfs_backlog_alloc,
				fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0x44UL));
			mix_signed(&digest, fake_procfs_backlog_alloc_calls);
			mix_signed(&digest, fake_procfs_backlog_copy_calls);
			mix_signed(&digest, fake_procfs_backlog_add_calls);
			mix_signed(&digest, fake_procfs_backlog_free_calls);
			mix_signed(&digest,
				fake_procfs_backlog_free_last_arg ==
				&fake_procfs_backlog_packet_storage);

			mix_signed(&digest, procfs_backlog_result(NULL,
				fake_procfs_backlog_func,
				fake_procfs_backlog_alloc,
				fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0));
			mix_signed(&digest, procfs_backlog_result(
				&backlog_request, NULL,
				fake_procfs_backlog_alloc,
				fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0));
			mix_signed(&digest, procfs_backlog_result(
				&backlog_request, fake_procfs_backlog_func,
				NULL, fake_procfs_backlog_copy,
				fake_procfs_backlog_add,
				fake_procfs_backlog_free,
				sizeof(backlog_request), 0));
		}
	}

	for (unsigned int i = 0; i < sizeof(io_rets) / sizeof(io_rets[0]); i++)
		mix_signed(&digest, pager_linux_io_retry_result(io_rets[i]));
	for (long done = -1; done <= 3; done++) {
		mix_signed(&digest, pager_linux_io_first_result(done));
		for (unsigned int i = 0; i < sizeof(io_rets) / sizeof(io_rets[0]); i++) {
			mix_signed(&digest, pager_linux_io_stop_result(io_rets[i]));
			mix_signed(&digest,
				pager_linux_io_advance_result(done, io_rets[i]));
			mix(&digest, pager_linux_io_remaining_result(8192,
				io_rets[i]));
			mix(&digest, pager_linux_io_next_buf_result(0x10000,
				io_rets[i]));
			mix_signed(&digest,
				pager_linux_io_complete_result(done, 4096));
		}
	}
	for (int faulted = 0; faulted <= 2; faulted++)
		mix_signed(&digest, pager_copy_fault_retry_result(faulted));
	for (int ret = -1; ret <= 1; ret++)
		mix_signed(&digest, pager_copy_fault_error_result(ret));

	for (unsigned int i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++) {
		mix_signed(&digest, pager_copy_size_error_result(sizes[i]));
		mix(&digest, pager_myalloc_next_alloced_result(0, sizes[i]));
		mix_signed(&digest, pager_myalloc_fits_result(0, sizes[i], 8192));
		mix_signed(&digest, pager_myalloc_fits_result(sizes[i], 1, 8192));
	}
	mix_signed(&digest, pager_myalloc_fits_result(~0UL, 1, 4));
	for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++)
		mix(&digest, pager_fault_addr_result(addrs[i]));
	for (size_t off = 0; off <= 8192; off += 4096) {
		mix(&digest, pager_read_chunk_size_result(off, off));
		mix(&digest, pager_read_chunk_size_result(off, off + 1));
		mix(&digest, pager_read_chunk_size_result(off, off + 4097));
	}
	for (int tail = -1; tail <= 130; tail += 17)
		mix_signed(&digest, pager_arealist_tail_room_result(tail));
	for (int base = -2; base <= 4; base += 3) {
		for (int add = -1; add <= 3; add += 2)
			mix_signed(&digest,
				pager_arealist_count_add_result(base, add));
	}
	for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++) {
		for (unsigned int j = 0; j < sizeof(addrs) / sizeof(addrs[0]); j++) {
			mix_signed(&digest,
				pager_addrpair_size_result(addrs[i], addrs[j]));
			mix_signed(&digest,
				pager_file_pos_result(addrs[i], addrs[j]));
		}
	}
	for (long written = -1; written <= 8192; written += 2049) {
		for (int count = 0; count <= 4; count++)
			mix_signed(&digest,
				pager_arealist_write_result(written, count, 32));
	}
	for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++) {
		mix_signed(&digest, pager_mlock_more_result(addrs[i]));
		mix(&digest, pager_mlock_next_start_result(addrs[i]));
	}
	mix_signed(&digest, pager_mlock_more_result(~0UL));
	for (unsigned long from = 0; from <= 1; from++) {
		for (unsigned long tail = 0; tail <= 1; tail++)
			mix_signed(&digest,
				pager_mlock_container_empty_result(from, tail,
					from, tail));
	}
	for (int ccount = 0; ccount <= 3; ccount++) {
		for (int cur_count = 0; cur_count <= 3; cur_count++)
			mix_signed(&digest,
				pager_mlock_needs_next_result(ccount, cur_count));
		mix_signed(&digest, pager_mlock_next_count_result(ccount));
	}
	mix_signed(&digest, pager_mlock_reset_count_result());
	for (unsigned int swap_count = 0; swap_count <= 3; swap_count++) {
		for (unsigned int mlock_count = 0; mlock_count <= 3; mlock_count++)
			mix_signed(&digest,
				pager_pagein_data_pos_result(swap_count,
					mlock_count, 64, 32));
	}
	for (unsigned int i = 0; i < sizeof(addrs) / sizeof(addrs[0]); i++) {
		mix_signed(&digest, pager_pageout_args_result(addrs[i],
			0x2000, 4096, 0x1000, 0x9000));
		mix_signed(&digest, pager_pageout_args_result(0x2000,
			addrs[i], 4096, 0x1000, 0x9000));
	}
	mix_signed(&digest, pager_pageout_args_result(0x2000, 0x3000,
		0x9000, 0x1000, 0x9000));
	for (unsigned int i = 0; i < sizeof(map_flags) / sizeof(map_flags[0]); i++) {
		mix_signed(&digest, pager_skip_anon_range_result(0, 0x5000,
			0x2000, 0x8000, 0x1000, 0x9000, map_flags[i]));
		mix_signed(&digest, pager_skip_anon_range_result(1, 0x5000,
			0x2000, 0x8000, 0x1000, 0x9000, map_flags[i]));
		mix_signed(&digest, pager_range_locked_result(map_flags[i]));
	}
	for (int flag = 0; flag <= 8; flag++)
		mix_signed(&digest, pager_skip_physical_removal_result(flag));
	for (int fd = -2; fd <= 2; fd++)
		mix_signed(&digest, pager_fd_valid_result(fd));
	for (long result = -2; result <= 2; result++) {
		mix_signed(&digest, pager_should_unlink_swap_result(result));
		mix_signed(&digest, pager_io_short_result(result));
	}

	mix_signed(&digest, zeroobj_initial_flags_result());
	mix_signed(&digest, zeroobj_initial_refcnt_result());
	mix_signed(&digest, zeroobj_initial_page_mode_result());
	mix_signed(&digest, zeroobj_initial_page_offset_result());
	for (unsigned int i = 0; i < sizeof(page_offsets) / sizeof(page_offsets[0]); i++) {
		for (int p2 = 0; p2 <= 1; p2++) {
			mix_signed(&digest, zeroobj_get_page_validate_result(
				page_offsets[i], p2, 0));
			mix_signed(&digest, zeroobj_get_page_validate_result(
				page_offsets[i], p2, 1));
		}
	}
	char zero_lock_token = 1;
	char zero_ops_token = 2;
	char zero_obj_token = 3;
	char zero_virt_token = 4;
	char zero_page_token = 5;
	void *zero_created = NULL;

	fake_zero_reset();
	mix_signed(&digest, zeroobj_alloc_body_result(&zero_obj_token,
		sizeof(zero_obj_token), &zero_ops_token, &zero_lock_token,
		fake_zero_log, fake_zero_lock, fake_zero_unlock,
		fake_zero_alloc, fake_zero_free, fake_zero_memset,
		fake_zero_obj_init, fake_zero_page_alloc, fake_zero_page_free,
		fake_zero_phys, fake_zero_page_insert, fake_zero_page_mode_fn,
		fake_zero_duplicate, fake_zero_page_init,
		fake_zero_page_list_insert, fake_zero_publish));
	require(fake_zero_lock_calls == 1);
	require(fake_zero_unlock_calls == 1);
	require(fake_zero_alloc_calls == 0);
	require(fake_zero_last_log_event == 1);
	mix(&digest, (unsigned long)fake_zero_log_calls);

	fake_zero_reset();
	mix_signed(&digest, zeroobj_alloc_body_result(NULL,
		sizeof(zero_obj_token), &zero_ops_token, &zero_lock_token,
		fake_zero_log, fake_zero_lock, fake_zero_unlock,
		fake_zero_alloc, fake_zero_free, fake_zero_memset,
		fake_zero_obj_init, fake_zero_page_alloc, fake_zero_page_free,
		fake_zero_phys, fake_zero_page_insert, fake_zero_page_mode_fn,
		fake_zero_duplicate, fake_zero_page_init,
		fake_zero_page_list_insert, fake_zero_publish));
	require(fake_zero_alloc_calls == 1);
	require(fake_zero_last_alloc_size == sizeof(zero_obj_token));
	require(fake_zero_last_alloc_flags == 0x2UL);
	require(fake_zero_free_calls == 0);
	require(fake_zero_last_log_event == 2);
	require(fake_zero_last_log_error == -12);
	mix(&digest, (unsigned long)fake_zero_alloc_calls);

	fake_zero_reset();
	fake_zero_alloc_result = &zero_obj_token;
	mix_signed(&digest, zeroobj_alloc_body_result(NULL,
		sizeof(zero_obj_token), &zero_ops_token, &zero_lock_token,
		fake_zero_log, fake_zero_lock, fake_zero_unlock,
		fake_zero_alloc, fake_zero_free, fake_zero_memset,
		fake_zero_obj_init, fake_zero_page_alloc, fake_zero_page_free,
		fake_zero_phys, fake_zero_page_insert, fake_zero_page_mode_fn,
		fake_zero_duplicate, fake_zero_page_init,
		fake_zero_page_list_insert, fake_zero_publish));
	require(fake_zero_obj_init_calls == 1);
	require(fake_zero_page_alloc_calls == 1);
	require(fake_zero_free_calls == 1);
	require(fake_zero_last_free == &zero_obj_token);
	require(fake_zero_last_log_event == 3);
	require(fake_zero_last_log_error == -12);

	fake_zero_reset();
	fake_zero_alloc_result = &zero_obj_token;
	fake_zero_page_alloc_result = &zero_virt_token;
	fake_zero_page_insert_result = &zero_page_token;
	mix_signed(&digest, zeroobj_alloc_body_result(NULL,
		sizeof(zero_obj_token), &zero_ops_token, &zero_lock_token,
		fake_zero_log, fake_zero_lock, fake_zero_unlock,
		fake_zero_alloc, fake_zero_free, fake_zero_memset,
		fake_zero_obj_init, fake_zero_page_alloc, fake_zero_page_free,
		fake_zero_phys, fake_zero_page_insert, fake_zero_page_mode_fn,
		fake_zero_duplicate, fake_zero_page_init,
		fake_zero_page_list_insert, fake_zero_publish));
	require(fake_zero_lock_calls == 1);
	require(fake_zero_unlock_calls == 1);
	require(fake_zero_alloc_calls == 1);
	require(fake_zero_memset_calls == 2);
	require(fake_zero_last_memset_dst == &zero_virt_token);
	require(fake_zero_last_memset_len == 4096);
	require(fake_zero_obj_init_calls == 1);
	require(fake_zero_last_obj_init_obj == &zero_obj_token);
	require(fake_zero_last_obj_init_ops == &zero_ops_token);
	require(fake_zero_page_alloc_calls == 1);
	require(fake_zero_last_page_alloc_npages == 1);
	require(fake_zero_last_page_alloc_flags == 0x2UL);
	require(fake_zero_phys_calls == 1);
	require(fake_zero_page_insert_calls == 1);
	require(fake_zero_last_insert_phys == 0x12345000UL);
	require(fake_zero_page_init_calls == 1);
	require(fake_zero_page_list_insert_calls == 1);
	require(fake_zero_last_list_obj == &zero_obj_token);
	require(fake_zero_last_list_page == &zero_page_token);
	require(fake_zero_publish_calls == 1);
	require(fake_zero_singleton == &zero_obj_token);
	require(fake_zero_page_free_calls == 0);
	require(fake_zero_free_calls == 0);
	mix(&digest, (unsigned long)fake_zero_memset_calls);
	mix(&digest, (unsigned long)fake_zero_page_list_insert_calls);
	mix(&digest, (unsigned long)fake_zero_publish_calls);

	fake_zero_reset();
	zero_created = NULL;
	mix_signed(&digest, zeroobj_create_body_result(&zero_created,
		&zero_obj_token, fake_zero_alloc_singleton,
		fake_zero_get_singleton, fake_zero_ref, fake_zero_log));
	require(zero_created == &zero_obj_token);
	require(fake_zero_alloc_singleton_calls == 0);
	require(fake_zero_ref_calls == 1);
	require(fake_zero_last_ref == &zero_obj_token);

	fake_zero_reset();
	zero_created = NULL;
	fake_zero_alloc_singleton_obj = &zero_obj_token;
	mix_signed(&digest, zeroobj_create_body_result(&zero_created,
		NULL, fake_zero_alloc_singleton, fake_zero_get_singleton,
		fake_zero_ref, fake_zero_log));
	require(fake_zero_alloc_singleton_calls == 1);
	require(zero_created == &zero_obj_token);
	require(fake_zero_ref_calls == 1);

	fake_zero_reset();
	zero_created = NULL;
	fake_zero_alloc_singleton_result = -12;
	mix_signed(&digest, zeroobj_create_body_result(&zero_created,
		NULL, fake_zero_alloc_singleton, fake_zero_get_singleton,
		fake_zero_ref, fake_zero_log));
	require(zero_created == NULL);
	require(fake_zero_ref_calls == 0);
	mix_signed(&digest, zeroobj_get_page_body_result());

	mix_signed(&digest, shmobj_initial_flags_result());
	mix_signed(&digest, shmobj_initial_refcnt_result());
	mix_signed(&digest, shmobj_initial_index_result());
	mix_signed(&digest, shmobj_initial_ds_pgshift_result());
	for (unsigned int i = 0; i < sizeof(flags) / sizeof(flags[0]); i++)
		mix_signed(&digest, shmobj_indexed_flags_result(flags[i]));
	for (unsigned int i = 0; i < sizeof(pgshifts) / sizeof(pgshifts[0]); i++) {
		int pgshift = shmobj_init_pgshift_result(pgshifts[i]);
		size_t pgsize = shmobj_pgsize_result(pgshift);

		mix_signed(&digest, pgshift);
		mix(&digest, pgsize);
		for (unsigned int j = 0; j < sizeof(seg_sizes) / sizeof(seg_sizes[0]); j++)
			mix(&digest, shmobj_real_segsz_result(seg_sizes[j], pgsize));
		for (unsigned int j = 0; j < sizeof(page_offsets) / sizeof(page_offsets[0]); j++)
			mix_signed(&digest, shmobj_page_contains_offset_result(
				page_offsets[j], pgshift, page_offsets[(j + 1) %
				(sizeof(page_offsets) / sizeof(page_offsets[0]))]));
	}
	for (unsigned int i = 1; i < sizeof(pgshifts) / sizeof(pgshifts[0]); i++) {
		mix_signed(&digest, shmobj_destroy_page_npages_result(pgshifts[i]));
		mix(&digest, shmobj_destroy_page_size_result(pgshifts[i]));
	}
	for (int index = 0; index <= 129; index += 31) {
		mix_signed(&digest, shmobj_destroy_index_word_result(index));
		mix(&digest, shmobj_destroy_index_mask_result(index));
	}
	for (size_t locked = 0; locked <= 8192; locked += 4096) {
		mix_signed(&digest, shmlock_user_locked_result(locked));
		mix(&digest, shmlock_user_after_unlock_result(locked, 4096));
		mix_signed(&digest, shmlock_user_should_free_result(locked));
	}
	for (int ruid = -1; ruid <= 2; ruid++) {
		mix_signed(&digest, shmlock_user_match_result(ruid, 1));
		mix_signed(&digest, shmlock_user_match_result(1, ruid));
	}
	for (unsigned long chain = 0; chain <= 1; chain++) {
		for (unsigned long head = 0; head <= 1; head++)
			mix_signed(&digest,
				shmlock_user_is_list_head_result(chain, head));
	}
	struct fake_shm_user shm_user_a = { .locked = 0, .ruid = 1 };
	struct fake_shm_user shm_user_b = { .locked = 0, .ruid = 2 };
	struct fake_shm_user shm_user_new = { .locked = 99, .ruid = 0 };
	void *shm_lock_user = NULL;

	shm_user_a.next = &shm_user_b;
	fake_shm_reset();
	fake_shm_user_first_result = &shm_user_a;
	mix_signed(&digest, shmlock_user_get_body_result(2, &shm_lock_user,
		64, fake_shm_user_first, fake_shm_user_next,
		fake_shm_user_ruid, fake_shm_alloc_obj,
		fake_shm_user_init, fake_shm_user_list_add));
	require(shm_lock_user == &shm_user_b);
	require(fake_shm_user_first_calls == 1);
	require(fake_shm_user_next_calls == 1);
	require(fake_shm_user_ruid_calls == 2);
	require(fake_shm_alloc_obj_calls == 0);
	require(fake_shm_user_list_add_calls == 0);
	mix(&digest, (unsigned long)fake_shm_user_ruid_calls);

	fake_shm_reset();
	shm_lock_user = NULL;
	fake_shm_alloc_obj_result = &shm_user_new;
	mix_signed(&digest, shmlock_user_get_body_result(7, &shm_lock_user,
		64, fake_shm_user_first, fake_shm_user_next,
		fake_shm_user_ruid, fake_shm_alloc_obj,
		fake_shm_user_init, fake_shm_user_list_add));
	require(shm_lock_user == &shm_user_new);
	require(fake_shm_alloc_obj_calls == 1);
	require(fake_shm_last_alloc_obj_size == 64);
	require(fake_shm_last_alloc_obj_flags == 2);
	require(fake_shm_user_init_calls == 1);
	require(fake_shm_last_user_init_ruid == 7);
	require(shm_user_new.locked == 0);
	require(shm_user_new.ruid == 7);
	require(fake_shm_user_list_add_calls == 1);
	require(fake_shm_last_user_list_arg == &shm_user_new);
	mix_signed(&digest, shm_user_new.ruid);

	fake_shm_reset();
	shm_lock_user = &shm_user_a;
	mix_signed(&digest, shmlock_user_get_body_result(7, &shm_lock_user,
		64, fake_shm_user_first, fake_shm_user_next,
		fake_shm_user_ruid, fake_shm_alloc_obj,
		fake_shm_user_init, fake_shm_user_list_add));
	require(shm_lock_user == &shm_user_a);
	require(fake_shm_alloc_obj_calls == 1);
	require(fake_shm_user_init_calls == 0);
	mix_signed(&digest, -12);

	fake_shm_reset();
	shm_user_a.locked = 0;
	mix_signed(&digest, shmlock_user_free_body_result(&shm_user_a,
		fake_shm_user_locked, fake_shm_user_list_del,
		fake_shm_user_free, fake_shm_panic));
	require(fake_shm_panic_calls == 0);
	require(fake_shm_user_list_del_calls == 1);
	require(fake_shm_user_free_calls == 1);
	require(fake_shm_last_user_free == &shm_user_a);

	fake_shm_reset();
	shm_user_a.locked = 1;
	mix_signed(&digest, shmlock_user_free_body_result(&shm_user_a,
		fake_shm_user_locked, fake_shm_user_list_del,
		fake_shm_user_free, fake_shm_panic));
	require(fake_shm_panic_calls == 1);
	require(fake_shm_user_list_del_calls == 1);
	require(fake_shm_user_free_calls == 1);
	mix_signed(&digest, fake_shm_panic_calls);

	for (size_t value = 0; value <= 17; value += 3) {
		mix(&digest, gencore_align32_result(value));
		mix(&digest, gencore_alignpage_result(value));
	}
	for (unsigned long f = 0; f <= 0x20000002UL; f += 0x1000000UL)
		mix_signed(&digest, gencore_range_inaccessible_result(f));
	require(gencore_align32_result(5) == 8);
	require(gencore_alignpage_result(4097) == 8192);
	require(gencore_range_inaccessible_result(0) == 0);
	require(gencore_range_inaccessible_result(0x2) == 1);
	require(gencore_range_inaccessible_result(0x01000000UL) == 1);
	require(gencore_range_inaccessible_result(0x20000000UL) == 1);
	require(gencore_prstatus_size_result() == 356);
	require(gencore_prpsinfo_size_result() == 156);
	require(gencore_auxv_size_result() == 324);
	mix_signed(&digest, gencore_prstatus_size_result());
	mix_signed(&digest, gencore_prpsinfo_size_result());
	mix_signed(&digest, gencore_auxv_size_result());

	fake_gencore_reset();
	fake_gencore_thread_setup();
	int fake_note_loop_size = gencore_note_size_threads_body_result(
		(void *)0xfaceUL, 10, fake_gencore_first_thread,
		fake_gencore_next_thread, fake_gencore_thread_tid,
		fake_gencore_arch_thread_info_size);
	mix_signed(&digest, fake_note_loop_size);
	require(fake_gencore_first_thread_calls == 1);
	require(fake_gencore_next_thread_calls == 3);
	require(fake_gencore_arch_size_calls == 3);
	require(fake_note_loop_size == 1644);
	mix_signed(&digest, fake_gencore_next_thread_calls);
	mix_signed(&digest, fake_gencore_arch_size_calls);

	unsigned char fake_note_loop_buf[2048];
	void *fake_note_end = NULL;
	char fake_note_cmdline[] = "note-loop-cmdline";

	memset(fake_note_loop_buf, 0, sizeof(fake_note_loop_buf));
	fake_gencore_reset();
	fake_gencore_thread_setup();
	mix_signed(&digest, gencore_fill_note_threads_body_result(
		fake_note_loop_buf, (void *)0xfaceUL, fake_note_cmdline,
		15, 10, &fake_note_end, fake_gencore_first_thread,
		fake_gencore_next_thread, fake_gencore_thread_tid,
		fake_gencore_thread_regs, fake_gencore_arch_thread_info_size,
		fake_gencore_fill_prstatus_note,
		fake_gencore_arch_fill_thread_info,
		fake_gencore_fill_prpsinfo_note,
		fake_gencore_fill_auxv_note));
	require(fake_note_end == fake_note_loop_buf + 1644);
	require(fake_gencore_first_thread_calls == 1);
	require(fake_gencore_next_thread_calls == 3);
	require(fake_gencore_fill_prstatus_note_calls == 3);
	require(fake_gencore_arch_fill_calls == 3);
	require(fake_gencore_fill_prpsinfo_note_calls == 1);
	require(fake_gencore_fill_auxv_note_calls == 1);
	require(fake_gencore_fill_prstatus_note_ptr[0] ==
		fake_note_loop_buf);
	require(fake_gencore_arch_fill_note_ptr[0] ==
		fake_note_loop_buf + 356);
	require(fake_gencore_fill_prstatus_note_ptr[1] ==
		fake_note_loop_buf + 388);
	require(fake_gencore_arch_fill_note_ptr[1] ==
		fake_note_loop_buf + 744);
	require(fake_gencore_fill_prpsinfo_note_ptr[0] ==
		fake_note_loop_buf + 776);
	require(fake_gencore_fill_auxv_note_ptr[0] ==
		fake_note_loop_buf + 932);
	require(fake_gencore_fill_prstatus_note_ptr[2] ==
		fake_note_loop_buf + 1256);
	require(fake_gencore_arch_fill_note_ptr[2] ==
		fake_note_loop_buf + 1612);
	require(fake_gencore_fill_prstatus_thread[1] ==
		&fake_gencore_threads[1]);
	require(fake_gencore_fill_prstatus_sig[2] == 15);
	require(fake_gencore_arch_fill_regs[2] == (void *)0x4000UL);
	require(fake_gencore_fill_prpsinfo_proc[0] == (void *)0xfaceUL);
	require(fake_gencore_fill_prpsinfo_cmdline[0] == fake_note_cmdline);
	require(fake_gencore_fill_auxv_proc[0] == (void *)0xfaceUL);
	require(fake_note_loop_buf[0] == 0xa1);
	require(fake_note_loop_buf[356] == 0xb2);
	require(fake_note_loop_buf[776] == 0xc3);
	require(fake_note_loop_buf[932] == 0xd4);
	mix(&digest, (unsigned long)((char *)fake_note_end -
		(char *)fake_note_loop_buf));
	mix_signed(&digest, fake_gencore_fill_prstatus_note_calls);
	mix_signed(&digest, fake_gencore_fill_auxv_note_calls);

	struct fake_gencore_ehdr fake_ehdr;

	memset(&fake_ehdr, 0xa5, sizeof(fake_ehdr));
	mix_signed(&digest, gencore_fill_elf_header_body_result(&fake_ehdr, 7));
	require(fake_ehdr.e_ident[0] == 0x7f);
	require(fake_ehdr.e_ident[1] == 'E');
	require(fake_ehdr.e_ident[2] == 'L');
	require(fake_ehdr.e_ident[3] == 'F');
	require(fake_ehdr.e_ident[4] == 2);
	require(fake_ehdr.e_ident[5] == 1);
	require(fake_ehdr.e_ident[6] == 1);
	require(fake_ehdr.e_ident[7] == 0);
	require(fake_ehdr.e_ident[8] == 0);
	require(fake_ehdr.e_type == 4);
	require(fake_ehdr.e_machine == 62);
	require(fake_ehdr.e_version == 1);
	require(fake_ehdr.e_entry == 0);
	require(fake_ehdr.e_phoff == 64);
	require(fake_ehdr.e_shoff == 0);
	require(fake_ehdr.e_flags == 0);
	require(fake_ehdr.e_ehsize == 64);
	require(fake_ehdr.e_phentsize == 56);
	require(fake_ehdr.e_phnum == 7);
	require(fake_ehdr.e_shentsize == 0);
	require(fake_ehdr.e_shnum == 0);
	require(fake_ehdr.e_shstrndx == 0);
	mix(&digest, fake_ehdr.e_phoff);
	mix_signed(&digest, fake_ehdr.e_phnum);

	unsigned char fake_note_buf[512];
	struct fake_gencore_note *fake_note =
		(struct fake_gencore_note *)fake_note_buf;

	char fake_thread;
	char fake_regs;

	memset(fake_note_buf, 0, sizeof(fake_note_buf));
	fake_gencore_reset();
	mix_signed(&digest, gencore_fill_prstatus_body_result(fake_note,
		&fake_thread, &fake_regs, 9, fake_gencore_arch_fill_prstatus));
	struct fake_gencore_prstatus *fake_prstatus =
		(struct fake_gencore_prstatus *)(fake_note_buf + 12 + 8);
	require(fake_note->namesz == 5);
	require(fake_note->descsz == 336);
	require(fake_note->type == 1);
	require(!memcmp(fake_note_buf + 12, "CORE", 5));
	require(fake_gencore_arch_prstatus_calls == 1);
	require(fake_gencore_last_prstatus == fake_prstatus);
	require(fake_gencore_last_thread == &fake_thread);
	require(fake_gencore_last_regs == &fake_regs);
	require(fake_gencore_last_sig == 9);
	require(fake_prstatus->bytes[0] == 0x5a);
	require(fake_prstatus->bytes[335] == 0xa5);
	mix_signed(&digest, fake_note->type);
	mix_signed(&digest, fake_gencore_arch_prstatus_calls);
	mix_signed(&digest, fake_gencore_last_sig);
	mix(&digest, fake_prstatus->bytes[335]);

	const char fake_cmdline[] = "0123456789abcdefignored";

	memset(fake_note_buf, 0, sizeof(fake_note_buf));
	mix_signed(&digest, gencore_fill_prpsinfo_body_result(fake_note,
		0x21, 1234, fake_cmdline));
	struct fake_gencore_prpsinfo *fake_prps =
		(struct fake_gencore_prpsinfo *)(fake_note_buf + 12 + 8);
	require(fake_note->namesz == 5);
	require(fake_note->descsz == 136);
	require(fake_note->type == 3);
	require(!memcmp(fake_note_buf + 12, "CORE", 5));
	require(fake_prps->pr_state == 0x21);
	require(fake_prps->pr_pid == 1234);
	require(!memcmp(fake_prps->pr_fname, "0123456789abcdef", 16));
	mix_signed(&digest, fake_note->type);
	mix_signed(&digest, fake_prps->pr_pid);
	mix(&digest, (unsigned char)fake_prps->pr_fname[15]);

	unsigned long fake_auxv[38];
	for (int aux = 0; aux < 38; aux++)
		fake_auxv[aux] = 0x1000UL + aux;
	memset(fake_note_buf, 0, sizeof(fake_note_buf));
	mix_signed(&digest, gencore_fill_auxv_body_result(fake_note,
		fake_auxv));
	unsigned long *fake_auxv_out = (unsigned long *)(fake_note_buf + 12 + 8);
	require(fake_note->namesz == 5);
	require(fake_note->descsz == 304);
	require(fake_note->type == 6);
	require(!memcmp(fake_note_buf + 12, "CORE", 5));
	require(fake_auxv_out[0] == 0x1000UL);
	require(fake_auxv_out[37] == 0x1000UL + 37);
	mix_signed(&digest, fake_note->type);
	mix(&digest, fake_auxv_out[37]);

	struct fake_gencore_phdr fake_phdr;

	memset(&fake_phdr, 0xa5, sizeof(fake_phdr));
	mix_signed(&digest, gencore_fill_note_phdr_body_result(&fake_phdr,
		0x440, 0x123));
	require(fake_phdr.p_type == 4);
	require(fake_phdr.p_flags == 0);
	require(fake_phdr.p_offset == 0x440);
	require(fake_phdr.p_vaddr == 0);
	require(fake_phdr.p_paddr == 0);
	require(fake_phdr.p_filesz == 0x123);
	require(fake_phdr.p_memsz == 0x123);
	require(fake_phdr.p_align == 0);
	mix(&digest, fake_phdr.p_type);
	mix(&digest, fake_phdr.p_filesz);

	memset(&fake_phdr, 0xa5, sizeof(fake_phdr));
	mix_signed(&digest, gencore_fill_load_phdr_body_result(&fake_phdr,
		0x00010000UL | 0x00040000UL, 0x2000, 0x700000, 0x3000));
	require(fake_phdr.p_type == 1);
	require(fake_phdr.p_flags == (4 | 1));
	require(fake_phdr.p_offset == 0x2000);
	require(fake_phdr.p_vaddr == 0x700000);
	require(fake_phdr.p_paddr == 0);
	require(fake_phdr.p_filesz == 0x3000);
	require(fake_phdr.p_memsz == 0x3000);
	require(fake_phdr.p_align == 4096);
	mix(&digest, fake_phdr.p_flags);
	mix(&digest, fake_phdr.p_vaddr);

	struct fake_gencore_coretable fake_coretable[3] = {
		{ 0, 0 },
		{ 0, 0 },
		{ 0, 0 },
	};

	mix_signed(&digest, gencore_fill_initial_coretable_body_result(
		fake_coretable, 0x111000UL, 0x222000UL, 0x333000UL,
		128, 256));
	require(fake_coretable[0].len == 64);
	require(fake_coretable[0].addr == 0x111000UL);
	require(fake_coretable[1].len == 128);
	require(fake_coretable[1].addr == 0x222000UL);
	require(fake_coretable[2].len == 256);
	require(fake_coretable[2].addr == 0x333000UL);
	mix(&digest, fake_coretable[0].len);
	mix(&digest, fake_coretable[2].addr);

	int fake_chunks;

	fake_gencore_reset();
	fake_chunks = 3;
	mix_signed(&digest, gencore_count_range_chunks_body_result(
		0x4000UL, 0x9000UL, 0, (void *)0x123, &fake_chunks,
		fake_gencore_pt_virt_to_phys));
	require(fake_chunks == 4);
	require(fake_gencore_pt_calls == 0);
	mix_signed(&digest, fake_chunks);

	fake_gencore_reset();
	fake_chunks = 3;
	fake_gencore_pt_missing_mask = (1UL << 0) | (1UL << 1) | (1UL << 3);
	mix_signed(&digest, gencore_count_range_chunks_body_result(
		0x4000UL, 0x9000UL, 0x1000UL, (void *)0x123, &fake_chunks,
		fake_gencore_pt_virt_to_phys));
	require(fake_chunks == 7);
	require(fake_gencore_pt_calls == 5);
	require(fake_gencore_pt_log[0] == 0x4000UL);
	require(fake_gencore_pt_log[4] == 0x8000UL);
	mix_signed(&digest, fake_chunks);
	mix_signed(&digest, fake_gencore_pt_calls);

	int fake_segs;

	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_chunks = 3;
	fake_segs = 1;
	fake_gencore_pt_missing_mask = (1UL << 0) | (1UL << 1) | (1UL << 3);
	mix_signed(&digest, gencore_scan_ranges_for_counts_body_result(
		(void *)0x456, (void *)0x123, &fake_chunks, &fake_segs,
		fake_gencore_lookup_range, fake_gencore_next_range,
		fake_gencore_range_start, fake_gencore_range_end,
		fake_gencore_range_flag, fake_gencore_range_objoff,
		fake_gencore_range_log, fake_gencore_pt_virt_to_phys));
	require(fake_chunks == 8);
	require(fake_segs == 3);
	require(fake_gencore_lookup_calls == 1);
	require(fake_gencore_next_calls == 3);
	require(fake_gencore_range_log_calls == 3);
	require(fake_gencore_range_log_start[0] == 0x4000UL);
	require(fake_gencore_range_log_start[1] == 0xa000UL);
	require(fake_gencore_range_log_start[2] == 0xc000UL);
	require(fake_gencore_range_log_objoff[2] == 0x30);
	mix_signed(&digest, fake_chunks);
	mix_signed(&digest, fake_segs);
	mix_signed(&digest, fake_gencore_range_log_calls);

	struct fake_gencore_phdr fake_phdrs[4];
	unsigned long fake_offset = 0x1000UL;
	int fake_index = 1;
	memset(fake_phdrs, 0, sizeof(fake_phdrs));
	fake_gencore_reset();
	fake_gencore_range_setup();
	mix_signed(&digest, gencore_fill_load_phdrs_body_result(
		(void *)0x456, fake_phdrs, &fake_index, &fake_offset,
		fake_gencore_lookup_range, fake_gencore_next_range,
		fake_gencore_range_start, fake_gencore_range_end,
		fake_gencore_range_flag));
	require(fake_index == 3);
	require(fake_offset == 0x8000UL);
	require(fake_phdrs[1].p_type == 1);
	require(fake_phdrs[1].p_flags == (4 | 2));
	require(fake_phdrs[1].p_offset == 0x1000UL);
	require(fake_phdrs[1].p_vaddr == 0x4000UL);
	require(fake_phdrs[1].p_filesz == 0x5000UL);
	require(fake_phdrs[2].p_type == 1);
	require(fake_phdrs[2].p_flags == (4 | 1));
	require(fake_phdrs[2].p_offset == 0x6000UL);
	require(fake_phdrs[2].p_vaddr == 0xc000UL);
	require(fake_phdrs[2].p_filesz == 0x2000UL);
	mix_signed(&digest, fake_index);
	mix(&digest, fake_offset);
	mix(&digest, fake_phdrs[2].p_flags);

	struct fake_gencore_coretable fake_coretable_more[8];
	memset(fake_coretable_more, 0, sizeof(fake_coretable_more));
	fake_index = 3;
	fake_gencore_reset();
	fake_gencore_pt_missing_mask = (1UL << 0) | (1UL << 1) | (1UL << 3);
	mix_signed(&digest, gencore_emit_demand_coretable_body_result(
		fake_coretable_more, &fake_index, 0x4000UL, 0x9000UL,
		(void *)0x123, fake_gencore_pt_virt_to_phys,
		fake_gencore_coretable_log));
	require(fake_index == 7);
	require(fake_coretable_more[3].addr == 0);
	require(fake_coretable_more[3].len == 8192);
	require(fake_coretable_more[4].addr == 0x902000UL);
	require(fake_coretable_more[4].len == 4096);
	require(fake_coretable_more[5].addr == 0);
	require(fake_coretable_more[5].len == 4096);
	require(fake_coretable_more[6].addr == 0x904000UL);
	require(fake_coretable_more[6].len == 4096);
	require(fake_gencore_coretable_log_calls == 4);
	require(fake_gencore_coretable_log_index[0] == 3);
	require(fake_gencore_coretable_log_start[0] == 0x4000UL);
	require(fake_gencore_coretable_log_start[3] == 0x8000UL);
	mix_signed(&digest, fake_index);
	mix(&digest, fake_coretable_more[4].addr);
	mix_signed(&digest, fake_gencore_coretable_log_calls);

	fake_index = 7;
	fake_gencore_reset();
	mix_signed(&digest, gencore_emit_linear_coretable_body_result(
		fake_coretable_more, &fake_index, 0x6000UL, 0x7000UL,
		0x1000UL, 0x10000UL, (void *)0x123,
		fake_gencore_pt_virt_to_phys, fake_gencore_virt_to_phys,
		fake_gencore_coretable_log));
	require(fake_index == 8);
	require(fake_coretable_more[7].addr == 0x902000UL);
	require(fake_coretable_more[7].len == 4096);
	require(fake_gencore_coretable_log_calls == 1);
	require(fake_gencore_coretable_log_start[0] == 0x6000UL);
	mix(&digest, fake_coretable_more[7].addr);

	fake_index = 7;
	fake_gencore_reset();
	fake_gencore_pt_error_addr = 0x6000UL;
	fake_gencore_pt_error_code = -14;
	mix_signed(&digest, gencore_emit_linear_coretable_body_result(
		fake_coretable_more, &fake_index, 0x6000UL, 0x7000UL,
		0x1000UL, 0x10000UL, (void *)0x123,
		fake_gencore_pt_virt_to_phys, fake_gencore_virt_to_phys,
		fake_gencore_coretable_log));
	require(fake_index == 8);
	require(fake_coretable_more[7].addr == 0);
	require(fake_coretable_more[7].len == 4096);
	mix(&digest, fake_coretable_more[7].addr);

	fake_index = 7;
	fake_gencore_reset();
	fake_gencore_pt_error_addr = 0x6000UL;
	fake_gencore_pt_error_code = -5;
	mix_signed(&digest, gencore_emit_linear_coretable_body_result(
		fake_coretable_more, &fake_index, 0x6000UL, 0x7000UL,
		0x1000UL, 0x10000UL, (void *)0x123,
		fake_gencore_pt_virt_to_phys, fake_gencore_virt_to_phys,
		fake_gencore_coretable_log));
	require(fake_index == 7);
	require(fake_gencore_coretable_log_calls == 0);
	mix_signed(&digest, fake_index);

	fake_index = 7;
	fake_gencore_reset();
	mix_signed(&digest, gencore_emit_linear_coretable_body_result(
		fake_coretable_more, &fake_index, 0x20000UL, 0x23000UL,
		0x1000UL, 0x10000UL, (void *)0x123,
		fake_gencore_pt_virt_to_phys, fake_gencore_virt_to_phys,
		fake_gencore_coretable_log));
	require(fake_index == 8);
	require(fake_coretable_more[7].addr == 0xadc000UL);
	require(fake_coretable_more[7].len == 0x3000);
	require(fake_gencore_pt_calls == 0);
	mix(&digest, fake_coretable_more[7].addr);

	memset(fake_coretable_more, 0, sizeof(fake_coretable_more));
	fake_index = 3;
	unsigned long fake_error_start = 0;
	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_gencore_pt_missing_mask = (1UL << 0) | (1UL << 1) | (1UL << 3);
	mix_signed(&digest, gencore_emit_coretable_ranges_body_result(
		(void *)0x456, fake_coretable_more, &fake_index,
		0x1000UL, 0x10000UL, (void *)0x123, &fake_error_start,
		fake_gencore_lookup_range, fake_gencore_next_range,
		fake_gencore_range_start, fake_gencore_range_end,
		fake_gencore_range_flag, fake_gencore_pt_virt_to_phys,
		fake_gencore_virt_to_phys, fake_gencore_coretable_log));
	require(fake_index == 8);
	require(fake_error_start == 0);
	require(fake_coretable_more[3].addr == 0);
	require(fake_coretable_more[3].len == 8192);
	require(fake_coretable_more[4].addr == 0x902000UL);
	require(fake_coretable_more[5].addr == 0);
	require(fake_coretable_more[6].addr == 0x904000UL);
	require(fake_coretable_more[7].addr == 0x908000UL);
	require(fake_coretable_more[7].len == 8192);
	require(fake_gencore_lookup_calls == 1);
	require(fake_gencore_next_calls == 3);
	require(fake_gencore_coretable_log_calls == 5);
	mix_signed(&digest, fake_index);
	mix(&digest, fake_coretable_more[7].addr);
	mix_signed(&digest, fake_gencore_coretable_log_calls);

	memset(fake_coretable_more, 0, sizeof(fake_coretable_more));
	fake_index = 3;
	fake_error_start = 0;
	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_gencore_pt_error_addr = 0xc000UL;
	fake_gencore_pt_error_code = -5;
	mix_signed(&digest, gencore_emit_coretable_ranges_body_result(
		(void *)0x456, fake_coretable_more, &fake_index,
		0x1000UL, 0x10000UL, (void *)0x123, &fake_error_start,
		fake_gencore_lookup_range, fake_gencore_next_range,
		fake_gencore_range_start, fake_gencore_range_end,
		fake_gencore_range_flag, fake_gencore_pt_virt_to_phys,
		fake_gencore_virt_to_phys, fake_gencore_coretable_log));
	require(fake_index == 8);
	require(fake_error_start == 0xc000UL);
	require(fake_gencore_coretable_log_calls == 5);
	mix(&digest, fake_error_start);

	char fake_core_cmdline[] = "core-command-line";
	void *fake_coretable_out = NULL;

	memset(fake_gencore_coretable_storage, 0,
	       sizeof(fake_gencore_coretable_storage));
	fake_chunks = 8;
	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_gencore_pt_missing_mask = (1UL << 0) | (1UL << 1) |
		(1UL << 3);
	mix_signed(&digest, gencore_generate_image_body_result(
		(void *)0xfaceUL, (void *)0x456UL, (void *)0x123UL,
		&fake_coretable_out, &fake_chunks, 3, 0x1000UL, 0x10000UL,
		fake_core_cmdline, 11, sizeof(struct fake_gencore_ehdr),
		sizeof(struct fake_gencore_phdr),
		sizeof(struct fake_gencore_coretable),
		fake_gencore_alloc, fake_gencore_zero, fake_gencore_free,
		fake_gencore_get_note_size, fake_gencore_fill_note,
		fake_gencore_virt_to_phys, fake_gencore_lookup_range,
		fake_gencore_next_range, fake_gencore_range_start,
		fake_gencore_range_end, fake_gencore_range_flag,
		fake_gencore_pt_virt_to_phys, fake_gencore_coretable_log,
		fake_gencore_alloc_error_log, fake_gencore_pt_error_log));
	require(fake_coretable_out == fake_gencore_coretable_storage);
	require(fake_gencore_alloc_calls == 4);
	require(fake_gencore_alloc_size[0] ==
		sizeof(struct fake_gencore_ehdr));
	require(fake_gencore_alloc_size[1] ==
		sizeof(struct fake_gencore_phdr) * 3);
	require(fake_gencore_alloc_size[2] == 3864);
	require(fake_gencore_alloc_size[3] ==
		sizeof(struct fake_gencore_coretable) * 8);
	require(fake_gencore_alloc_flags[0] == 2);
	require(fake_gencore_zero_calls == 4);
	require(fake_gencore_zero_ptr[2] == fake_gencore_note_storage);
	require(fake_gencore_zero_size[3] ==
		sizeof(struct fake_gencore_coretable) * 8);
	require(fake_gencore_get_note_size_calls == 1);
	require(fake_gencore_fill_note_calls == 1);
	require(fake_gencore_last_fill_note_proc == (void *)0xfaceUL);
	require(fake_gencore_last_fill_note_cmdline == fake_core_cmdline);
	require(fake_gencore_last_fill_note_sig == 11);
	require(((unsigned char *)fake_gencore_note_storage)[0] == 0x77);
	require(((unsigned char *)fake_gencore_note_storage)[299] == 0x88);
	require(fake_gencore_ehdr_storage.e_phnum == 3);
	require(fake_gencore_phdr_storage[0].p_type == 4);
	require(fake_gencore_phdr_storage[0].p_offset == 232);
	require(fake_gencore_phdr_storage[0].p_filesz == 300);
	require(fake_gencore_phdr_storage[1].p_offset == 4096);
	require(fake_gencore_phdr_storage[1].p_vaddr == 0x4000UL);
	require(fake_gencore_phdr_storage[2].p_offset == 0x6000UL);
	require(fake_gencore_coretable_storage[0].len == 64);
	require(fake_gencore_coretable_storage[1].len ==
		(long)(sizeof(struct fake_gencore_phdr) * 3));
	require(fake_gencore_coretable_storage[2].len == 3864);
	require(fake_gencore_coretable_storage[3].addr == 0);
	require(fake_gencore_coretable_storage[3].len == 8192);
	require(fake_gencore_coretable_storage[4].addr == 0x902000UL);
	require(fake_gencore_coretable_storage[7].addr == 0x908000UL);
	require(fake_gencore_coretable_log_calls == 8);
	require(fake_gencore_coretable_log_index[0] == 0);
	require(fake_gencore_coretable_log_index[3] == 3);
	require(fake_gencore_free_calls == 0);
	require(fake_gencore_pt_error_log_calls == 0);
	mix_signed(&digest, fake_gencore_alloc_calls);
	mix(&digest, fake_gencore_phdr_storage[2].p_offset);
	mix(&digest, fake_gencore_coretable_storage[7].addr);
	mix_signed(&digest, fake_gencore_coretable_log_calls);

	fake_coretable_out = (void *)0xdeadbeefUL;
	fake_chunks = 8;
	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_gencore_alloc_fail_call = 3;
	mix_signed(&digest, gencore_generate_image_body_result(
		(void *)0xfaceUL, (void *)0x456UL, (void *)0x123UL,
		&fake_coretable_out, &fake_chunks, 3, 0x1000UL, 0x10000UL,
		fake_core_cmdline, 11, sizeof(struct fake_gencore_ehdr),
		sizeof(struct fake_gencore_phdr),
		sizeof(struct fake_gencore_coretable),
		fake_gencore_alloc, fake_gencore_zero, fake_gencore_free,
		fake_gencore_get_note_size, fake_gencore_fill_note,
		fake_gencore_virt_to_phys, fake_gencore_lookup_range,
		fake_gencore_next_range, fake_gencore_range_start,
		fake_gencore_range_end, fake_gencore_range_flag,
		fake_gencore_pt_virt_to_phys, fake_gencore_coretable_log,
		fake_gencore_alloc_error_log, fake_gencore_pt_error_log));
	require(fake_coretable_out == (void *)0xdeadbeefUL);
	require(fake_gencore_alloc_calls == 3);
	require(fake_gencore_alloc_error_log_calls == 1);
	require(fake_gencore_last_alloc_error_stage == 2);
	require(fake_gencore_free_calls == 4);
	require(fake_gencore_free_log[0] == &fake_gencore_ehdr_storage);
	require(fake_gencore_free_log[1] == NULL);
	require(fake_gencore_free_log[2] == fake_gencore_phdr_storage);
	require(fake_gencore_free_log[3] == NULL);
	require(fake_gencore_fill_note_calls == 0);
	mix_signed(&digest, fake_gencore_last_alloc_error_stage);

	fake_coretable_out = NULL;
	fake_chunks = 8;
	fake_gencore_reset();
	fake_gencore_range_setup();
	fake_gencore_pt_error_addr = 0xc000UL;
	fake_gencore_pt_error_code = -5;
	mix_signed(&digest, gencore_generate_image_body_result(
		(void *)0xfaceUL, (void *)0x456UL, (void *)0x123UL,
		&fake_coretable_out, &fake_chunks, 3, 0x1000UL, 0x10000UL,
		fake_core_cmdline, 11, sizeof(struct fake_gencore_ehdr),
		sizeof(struct fake_gencore_phdr),
		sizeof(struct fake_gencore_coretable),
		fake_gencore_alloc, fake_gencore_zero, fake_gencore_free,
		fake_gencore_get_note_size, fake_gencore_fill_note,
		fake_gencore_virt_to_phys, fake_gencore_lookup_range,
		fake_gencore_next_range, fake_gencore_range_start,
		fake_gencore_range_end, fake_gencore_range_flag,
		fake_gencore_pt_virt_to_phys, fake_gencore_coretable_log,
		fake_gencore_alloc_error_log, fake_gencore_pt_error_log));
	require(fake_coretable_out == NULL);
	require(fake_gencore_pt_error_log_calls == 1);
	require(fake_gencore_last_pt_error_start == 0xc000UL);
	require(fake_gencore_last_pt_error_code == -5);
	require(fake_gencore_free_calls == 4);
	require(fake_gencore_free_log[0] == &fake_gencore_ehdr_storage);
	require(fake_gencore_free_log[1] == fake_gencore_coretable_storage);
	require(fake_gencore_free_log[2] == fake_gencore_phdr_storage);
	require(fake_gencore_free_log[3] == fake_gencore_note_storage);
	mix(&digest, fake_gencore_last_pt_error_start);
	mix_signed(&digest, fake_gencore_free_calls);

	void *fake_coretablep = fake_coretable;

	fake_gencore_reset();
	mix_signed(&digest, gencore_freecore_body_result(&fake_coretablep,
		fake_gencore_phys_to_virt, fake_gencore_free));
	require(fake_gencore_phys_to_virt_calls == 3);
	require(fake_gencore_free_calls == 4);
	require(fake_gencore_phys_log[0] == 0x333000UL);
	require(fake_gencore_phys_log[1] == 0x222000UL);
	require(fake_gencore_phys_log[2] == 0x111000UL);
	require(fake_gencore_free_log[0] == (void *)0x334000UL);
	require(fake_gencore_free_log[1] == (void *)0x223000UL);
	require(fake_gencore_free_log[2] == (void *)0x112000UL);
	require(fake_gencore_free_log[3] == fake_coretable);
	mix(&digest, fake_gencore_phys_log[0]);
	mix(&digest, (unsigned long)fake_gencore_free_calls);

	for (unsigned long ptr = 0; ptr <= 2; ptr++) {
		mix_signed(&digest, shmobj_has_user_result(ptr));
		mix_signed(&digest, shmobj_need_alloc_page_result(ptr));
		mix_signed(&digest, shmobj_lookup_page_missing_error_result(ptr));
		mix_signed(&digest, shmobj_lookup_should_store_phys_result(ptr));
		mix_signed(&digest, shmobj_pte_missing_result(ptr));
	}
	for (int count = -1; count <= 3; count++) {
		mix_signed(&digest, shmobj_destroy_page_count_invalid_result(count));
		mix_signed(&digest, shmobj_destroy_page_should_free_result(count, 0));
		mix_signed(&digest, shmobj_destroy_page_should_free_result(count, 1));
	}
	for (int index = -2; index <= 2; index++)
		mix_signed(&digest, shmobj_should_free_direct_result(index));
	for (unsigned int i = 0; i < sizeof(flags) / sizeof(flags[0]); i++)
		mix_signed(&digest, shmobj_destroy_missing_flag_result(flags[i]));
	for (unsigned int i = 0; i < sizeof(seg_sizes) / sizeof(seg_sizes[0]); i++) {
		for (unsigned int j = 0; j < sizeof(page_offsets) / sizeof(page_offsets[0]); j++) {
			for (unsigned int k = 0; k < sizeof(p2aligns) / sizeof(p2aligns[0]); k++) {
				mix_signed(&digest, shmobj_get_page_validate_result(
					seg_sizes[i], page_offsets[j], p2aligns[k]));
			}
			mix_signed(&digest, shmobj_lookup_page_validate_result(
				seg_sizes[i], page_offsets[j]));
		}
	}
	for (unsigned int i = 0; i < sizeof(p2aligns) / sizeof(p2aligns[0]); i++) {
		mix_signed(&digest, shmobj_page_npages_result(p2aligns[i]));
		mix_signed(&digest, shmobj_page_pgshift_result(p2aligns[i]));
	}
	mix_signed(&digest, shmobj_new_page_mode_result());
	mix_signed(&digest, shmobj_new_page_count_result());
	mix_signed(&digest, shmobj_new_page_mapped_result());
	for (unsigned int i = 0; i < sizeof(modes) / sizeof(modes[0]); i++)
		mix_signed(&digest,
			shmobj_page_mode_valid_for_new_result(modes[i]));
	for (int has_pt = 0; has_pt <= 1; has_pt++) {
		for (int has_page = 0; has_page <= 1; has_page++) {
			for (int has_vaddr = 0; has_vaddr <= 1; has_vaddr++) {
				mix_signed(&digest, shmobj_update_args_result(
					has_pt, has_page, has_vaddr));
			}
		}
	}
	for (unsigned int i = 1; i < sizeof(pgshifts) / sizeof(pgshifts[0]); i++)
		mix(&digest, shmobj_update_orig_pgsize_result(pgshifts[i]));
	for (unsigned long off = 0; off <= 8192; off += 4096) {
		mix(&digest, shmobj_update_page_phys_result(0x100000, off));
		mix_signed(&digest, shmobj_update_page_offset_result(0x200000, off));
		mix_signed(&digest,
			shmobj_update_has_more_pages_result(off, 8192));
		mix(&digest, shmobj_update_next_page_off_result(off, 4096));
	}
	char shm_ds_token = 8;
	char shm_create_obj_token = 9;
	struct fake_shm_memobj shm_create_memobj = { 0x20 };
	struct fake_shm_memobj shm_indexed_memobj = { 0x40 };
	char shm_indexed_obj_token = 10;
	void *shm_created = NULL;
	void *shm_indexed = NULL;

	fake_shm_reset();
	fake_shm_alloc_obj_result = &shm_create_obj_token;
	fake_shm_create_memobj_result = &shm_create_memobj;
	fake_shm_next_seq_value = 17;
	mix_signed(&digest, shmobj_create_body_result(&shm_ds_token,
		&shm_created, 5000, 0, 128, fake_shm_alloc_obj,
		fake_shm_free, fake_shm_memset, fake_shm_next_seq,
		fake_shm_create_init, fake_shm_create_log));
	require(shm_created == &shm_create_memobj);
	require(fake_shm_alloc_obj_calls == 1);
	require(fake_shm_last_alloc_obj_size == 128);
	require(fake_shm_last_alloc_obj_flags == 2);
	require(fake_shm_memset_calls == 1);
	require(fake_shm_last_memset_dst == &shm_create_obj_token);
	require(fake_shm_last_memset_len == 128);
	require(fake_shm_next_seq_calls == 1);
	require(fake_shm_create_init_calls == 1);
	require(fake_shm_last_create_obj == &shm_create_obj_token);
	require(fake_shm_last_create_ds == &shm_ds_token);
	require(fake_shm_last_create_pgshift == 12);
	require(fake_shm_last_create_pgsize == 4096);
	require(fake_shm_last_create_real_segsz == 8192);
	require(fake_shm_last_create_seq == 17);
	require(fake_shm_create_log_calls == 0);
	mix(&digest, fake_shm_last_create_real_segsz);
	mix_signed(&digest, fake_shm_last_create_seq);

	fake_shm_reset();
	shm_created = &shm_create_obj_token;
	mix_signed(&digest, shmobj_create_body_result(&shm_ds_token,
		&shm_created, 5000, 0, 128, fake_shm_alloc_obj,
		fake_shm_free, fake_shm_memset, fake_shm_next_seq,
		fake_shm_create_init, fake_shm_create_log));
	require(shm_created == &shm_create_obj_token);
	require(fake_shm_alloc_obj_calls == 1);
	require(fake_shm_create_init_calls == 0);
	require(fake_shm_create_log_calls == 1);
	require(fake_shm_last_create_log_event == 15);
	require(fake_shm_last_create_log_error == -12);
	mix_signed(&digest, fake_shm_last_create_log_error);

	fake_shm_reset();
	fake_shm_create_callback_memobj = &shm_indexed_memobj;
	fake_shm_to_shmobj_result = &shm_indexed_obj_token;
	mix_signed(&digest, shmobj_create_indexed_body_result(&shm_ds_token,
		&shm_indexed, fake_shm_create_callback, fake_shm_memobj_flags,
		fake_shm_memobj_set_flags, fake_shm_to_shmobj));
	require(shm_indexed == &shm_indexed_obj_token);
	require(fake_shm_create_callback_calls == 1);
	require(fake_shm_flags_calls == 1);
	require(fake_shm_set_flags_calls == 1);
	require(shm_indexed_memobj.flags ==
		shmobj_indexed_flags_result(0x40));
	require(fake_shm_to_shmobj_calls == 1);
	mix_signed(&digest, shm_indexed_memobj.flags);

	fake_shm_reset();
	shm_indexed = &shm_indexed_obj_token;
	fake_shm_create_callback_result = -12;
	mix_signed(&digest, shmobj_create_indexed_body_result(&shm_ds_token,
		&shm_indexed, fake_shm_create_callback, fake_shm_memobj_flags,
		fake_shm_memobj_set_flags, fake_shm_to_shmobj));
	require(shm_indexed == &shm_indexed_obj_token);
	require(fake_shm_flags_calls == 0);
	require(fake_shm_set_flags_calls == 0);
	mix_signed(&digest, fake_shm_create_callback_result);

	char shm_memobj_token = 9;
	char shm_obj_token = 11;
	struct fake_shm_page shm_page = { 0x567000UL };
	uintptr_t shm_phys = 0;
	uintptr_t shm_resolved = 0;

	fake_shm_reset();
	fake_shm_lookup_result = &shm_page;
	mix_signed(&digest, shmobj_lookup_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 4096, 0, &shm_phys, &shm_resolved,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_page_phys,
		fake_shm_log));
	require(shm_phys == 0x567000UL);
	require(shm_resolved == 0x567000UL);
	require(fake_shm_ref_calls == 1);
	require(fake_shm_unref_calls == 1);
	require(fake_shm_lock_calls == 1);
	require(fake_shm_unlock_calls == 1);
	require(fake_shm_lookup_calls == 1);
	require(fake_shm_last_lookup_off == 4096);
	require(fake_shm_page_phys_calls == 1);
	require(fake_shm_log_calls == 0);
	mix(&digest, shm_phys);
	mix(&digest, (unsigned long)fake_shm_lookup_calls);

	fake_shm_reset();
	shm_phys = 0x55UL;
	shm_resolved = 0;
	mix_signed(&digest, shmobj_lookup_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 4096, 0, &shm_phys, &shm_resolved,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_page_phys,
		fake_shm_log));
	require(shm_phys == 0x55UL);
	require(shm_resolved == 0);
	require(fake_shm_lock_calls == 1);
	require(fake_shm_unlock_calls == 1);
	require(fake_shm_page_phys_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 3);
	require(fake_shm_last_log_error == -2);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	shm_phys = 0;
	shm_resolved = 0;
	mix_signed(&digest, shmobj_lookup_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 1, 0, &shm_phys, &shm_resolved,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_page_phys,
		fake_shm_log));
	require(fake_shm_lock_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 1);
	require(fake_shm_last_log_error == -22);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	mix_signed(&digest, shmobj_lookup_page_body_result(&shm_memobj_token,
		&shm_obj_token, 4096, 4096, 0, NULL, &shm_resolved,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_page_phys,
		fake_shm_log));
	require(fake_shm_lock_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 2);
	require(fake_shm_last_log_error == -34);
	mix_signed(&digest, fake_shm_last_log_error);

	char shm_pt_token = 11;
	char shm_vaddr_token = 12;
	struct fake_shm_page shm_orig = {
		0x800000UL, 13, 5, 0x20000, 7, 9
	};
	struct fake_shm_page shm_new = { 0 };

	fake_shm_reset();
	fake_shm_insert_result = &shm_new;
	mix_signed(&digest, shmobj_update_page_body_result(
		&shm_memobj_token, &shm_obj_token, &shm_pt_token,
		&shm_orig, &shm_vaddr_token, fake_shm_ref,
		fake_shm_unref, fake_shm_page_phys, fake_shm_pte_lookup,
		fake_shm_page_pgshift, fake_shm_page_set_pgshift,
		fake_shm_page_mode, fake_shm_page_set_mode,
		fake_shm_page_offset, fake_shm_page_set_offset,
		fake_shm_page_count, fake_shm_page_set_count,
		fake_shm_page_mapped, fake_shm_page_set_mapped,
		fake_shm_insert_hash, fake_shm_list_insert,
		fake_shm_update_log));
	require(fake_shm_ref_calls == 1);
	require(fake_shm_unref_calls == 1);
	require(fake_shm_pte_lookup_calls == 2);
	require(shm_orig.pgshift == 12);
	require(fake_shm_insert_hash_calls == 1);
	require(fake_shm_last_insert_phys == 0x801000UL);
	require(shm_new.mode == 5);
	require(shm_new.offset == 0x21000);
	require(shm_new.pgshift == 12);
	require(shm_new.count == 7);
	require(shm_new.mapped == 9);
	require(fake_shm_list_insert_calls == 1);
	require(fake_shm_last_insert_obj == &shm_obj_token);
	require(fake_shm_last_insert_page == &shm_new);
	require(fake_shm_log_calls == 0);
	mix(&digest, (unsigned long)fake_shm_pte_lookup_calls);
	mix(&digest, fake_shm_last_insert_phys);
	mix_signed(&digest, shm_new.pgshift);
	mix(&digest, shm_new.offset);

	fake_shm_reset();
	mix_signed(&digest, shmobj_update_page_body_result(
		&shm_memobj_token, &shm_obj_token, NULL,
		&shm_orig, &shm_vaddr_token, fake_shm_ref,
		fake_shm_unref, fake_shm_page_phys, fake_shm_pte_lookup,
		fake_shm_page_pgshift, fake_shm_page_set_pgshift,
		fake_shm_page_mode, fake_shm_page_set_mode,
		fake_shm_page_offset, fake_shm_page_set_offset,
		fake_shm_page_count, fake_shm_page_set_count,
		fake_shm_page_mapped, fake_shm_page_set_mapped,
		fake_shm_insert_hash, fake_shm_list_insert,
		fake_shm_update_log));
	require(fake_shm_pte_lookup_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 4);
	require(fake_shm_last_log_error == -2);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	fake_shm_pte_missing_at = 1;
	mix_signed(&digest, shmobj_update_page_body_result(
		&shm_memobj_token, &shm_obj_token, &shm_pt_token,
		&shm_orig, &shm_vaddr_token, fake_shm_ref,
		fake_shm_unref, fake_shm_page_phys, fake_shm_pte_lookup,
		fake_shm_page_pgshift, fake_shm_page_set_pgshift,
		fake_shm_page_mode, fake_shm_page_set_mode,
		fake_shm_page_offset, fake_shm_page_set_offset,
		fake_shm_page_count, fake_shm_page_set_count,
		fake_shm_page_mapped, fake_shm_page_set_mapped,
		fake_shm_insert_hash, fake_shm_list_insert,
		fake_shm_update_log));
	require(fake_shm_pte_lookup_calls == 1);
	require(fake_shm_insert_hash_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 5);
	require(fake_shm_last_log_error == -2);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	fake_shm_pte_missing_at = 2;
	shm_orig.pgshift = 13;
	mix_signed(&digest, shmobj_update_page_body_result(
		&shm_memobj_token, &shm_obj_token, &shm_pt_token,
		&shm_orig, &shm_vaddr_token, fake_shm_ref,
		fake_shm_unref, fake_shm_page_phys, fake_shm_pte_lookup,
		fake_shm_page_pgshift, fake_shm_page_set_pgshift,
		fake_shm_page_mode, fake_shm_page_set_mode,
		fake_shm_page_offset, fake_shm_page_set_offset,
		fake_shm_page_count, fake_shm_page_set_count,
		fake_shm_page_mapped, fake_shm_page_set_mapped,
		fake_shm_insert_hash, fake_shm_list_insert,
		fake_shm_update_log));
	require(fake_shm_pte_lookup_calls == 2);
	require(shm_orig.pgshift == 12);
	require(fake_shm_insert_hash_calls == 0);
	require(fake_shm_log_calls == 1);
	require(fake_shm_last_log_event == 5);
	require(fake_shm_last_log_error == -2);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	shm_page.phys = 0x567000UL;
	shm_page.count = 2;
	shm_phys = 0;
	fake_shm_lookup_result = &shm_page;
	mix_signed(&digest, shmobj_get_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 4096, 0, &shm_phys, 0x1234,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_alloc_page,
		fake_shm_free_page, fake_shm_virt_to_phys,
		fake_shm_insert_hash, fake_shm_page_mode,
		fake_shm_page_set_mode, fake_shm_page_set_offset,
		fake_shm_page_set_pgshift, fake_shm_page_set_count,
		fake_shm_page_set_mapped, fake_shm_list_insert,
		fake_shm_count_inc, fake_shm_page_phys, fake_shm_memset,
		fake_shm_panic, fake_shm_get_log));
	require(shm_phys == 0x567000UL);
	require(shm_page.count == 3);
	require(fake_shm_lock_calls == 1);
	require(fake_shm_unlock_calls == 1);
	require(fake_shm_alloc_page_calls == 0);
	require(fake_shm_count_inc_calls == 1);
	require(fake_shm_log_calls == 0);
	mix(&digest, shm_phys);
	mix(&digest, (unsigned long)fake_shm_count_inc_calls);

	char shm_virt_token = 13;
	shm_new = (struct fake_shm_page){ 0 };
	fake_shm_reset();
	shm_phys = 0;
	fake_shm_alloc_result = &shm_virt_token;
	fake_shm_virt_phys = 0x900000UL;
	fake_shm_insert_result = &shm_new;
	mix_signed(&digest, shmobj_get_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 0, 0, &shm_phys, 0xdeadUL,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_alloc_page,
		fake_shm_free_page, fake_shm_virt_to_phys,
		fake_shm_insert_hash, fake_shm_page_mode,
		fake_shm_page_set_mode, fake_shm_page_set_offset,
		fake_shm_page_set_pgshift, fake_shm_page_set_count,
		fake_shm_page_set_mapped, fake_shm_list_insert,
		fake_shm_count_inc, fake_shm_page_phys, fake_shm_memset,
		fake_shm_panic, fake_shm_get_log));
	require(shm_phys == 0x900000UL);
	require(fake_shm_last_alloc_npages == 1);
	require(fake_shm_last_alloc_p2align == 0);
	require(fake_shm_last_alloc_flags == 0x2UL);
	require(fake_shm_last_alloc_virt_addr == 0xdeadUL);
	require(fake_shm_virt_to_phys_calls == 1);
	require(fake_shm_insert_hash_calls == 1);
	require(fake_shm_last_insert_phys == 0x900000UL);
	require(fake_shm_memset_calls == 1);
	require(fake_shm_last_memset_dst == &shm_virt_token);
	require(fake_shm_last_memset_len == 4096);
	require(shm_new.mode == shmobj_new_page_mode_result());
	require(shm_new.offset == 0);
	require(shm_new.pgshift == 12);
	require(shm_new.count == 2);
	require(shm_new.mapped == 0);
	require(fake_shm_list_insert_calls == 1);
	require(fake_shm_free_page_calls == 0);
	require(fake_shm_last_log_event == 11);
	mix(&digest, shm_phys);
	mix(&digest, (unsigned long)fake_shm_alloc_page_calls);
	mix_signed(&digest, shm_new.count);

	fake_shm_reset();
	mix_signed(&digest, shmobj_get_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 0, 0, &shm_phys, 0x1234,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_alloc_page,
		fake_shm_free_page, fake_shm_virt_to_phys,
		fake_shm_insert_hash, fake_shm_page_mode,
		fake_shm_page_set_mode, fake_shm_page_set_offset,
		fake_shm_page_set_pgshift, fake_shm_page_set_count,
		fake_shm_page_set_mapped, fake_shm_list_insert,
		fake_shm_count_inc, fake_shm_page_phys, fake_shm_memset,
		fake_shm_panic, fake_shm_get_log));
	require(fake_shm_last_log_event == 9);
	require(fake_shm_last_log_error == -12);
	require(fake_shm_unlock_calls == 1);
	require(fake_shm_count_inc_calls == 0);
	mix_signed(&digest, fake_shm_last_log_error);

	fake_shm_reset();
	mix_signed(&digest, shmobj_get_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 1, 0, &shm_phys, 0,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_alloc_page,
		fake_shm_free_page, fake_shm_virt_to_phys,
		fake_shm_insert_hash, fake_shm_page_mode,
		fake_shm_page_set_mode, fake_shm_page_set_offset,
		fake_shm_page_set_pgshift, fake_shm_page_set_count,
		fake_shm_page_set_mapped, fake_shm_list_insert,
		fake_shm_count_inc, fake_shm_page_phys, fake_shm_memset,
		fake_shm_panic, fake_shm_get_log));
	require(fake_shm_lock_calls == 0);
	require(fake_shm_last_log_event == 6);
	require(fake_shm_last_log_error == -22);
	mix_signed(&digest, fake_shm_last_log_error);

	shm_new = (struct fake_shm_page){ .mode = 1 };
	fake_shm_reset();
	fake_shm_alloc_result = &shm_virt_token;
	fake_shm_virt_phys = 0x910000UL;
	fake_shm_insert_result = &shm_new;
	mix_signed(&digest, shmobj_get_page_body_result(&shm_memobj_token,
		&shm_obj_token, 8192, 0, 0, &shm_phys, 0,
		fake_shm_ref, fake_shm_unref, fake_shm_lock,
		fake_shm_unlock, fake_shm_lookup, fake_shm_alloc_page,
		fake_shm_free_page, fake_shm_virt_to_phys,
		fake_shm_insert_hash, fake_shm_page_mode,
		fake_shm_page_set_mode, fake_shm_page_set_offset,
		fake_shm_page_set_pgshift, fake_shm_page_set_count,
		fake_shm_page_set_mapped, fake_shm_list_insert,
		fake_shm_count_inc, fake_shm_page_phys, fake_shm_memset,
		fake_shm_panic, fake_shm_get_log));
	require(fake_shm_last_log_event == 10);
	require(fake_shm_panic_calls == 1);
	require(fake_shm_free_page_calls == 1);
	require(fake_shm_last_free_virt == &shm_virt_token);
	require(fake_shm_last_free_npages == 1);
	require(fake_shm_count_inc_calls == 0);
	mix_signed(&digest, fake_shm_panic_calls);

	struct fake_shm_user shm_user = { 4096 };
	struct fake_shm_page shm_bad_count = {
		0x300000UL, 12, 0, 0, 2, 0
	};
	struct fake_shm_page shm_free_page = {
		0x301000UL, 12, 0, 0, 1, 0
	};

	fake_shm_reset();
	fake_shm_pages[0] = &shm_bad_count;
	fake_shm_pages[1] = &shm_free_page;
	fake_shm_pages[2] = NULL;
	fake_shm_unmap_ret = 1;
	mix_signed(&digest, shmobj_destroy_body_result(
		&shm_obj_token, &shm_user, 4096, -1,
		fake_shm_user_clear, fake_shm_user_locked,
		fake_shm_user_set_locked, fake_shm_user_lock,
		fake_shm_user_unlock, fake_shm_user_free,
		fake_shm_page_first, fake_shm_page_remove,
		fake_shm_page_phys, fake_shm_phys_to_virt,
		fake_shm_page_pgshift, fake_shm_page_count,
		fake_shm_page_unmap, fake_shm_free_page,
		fake_shm_rss_sub, fake_shm_free, fake_shm_indexed_free,
		fake_shm_destroy_log));
	require(shm_user.locked == 0);
	require(fake_shm_user_clear_calls == 1);
	require(fake_shm_user_lock_calls == 1);
	require(fake_shm_user_unlock_calls == 1);
	require(fake_shm_user_free_calls == 1);
	require(fake_shm_first_calls == 3);
	require(fake_shm_remove_calls == 2);
	require(fake_shm_unmap_calls == 1);
	require(fake_shm_free_page_calls == 1);
	require(fake_shm_last_free_virt == (void *)(0x301000UL + 0x1000UL));
	require(fake_shm_rss_sub_calls == 1);
	require(fake_shm_last_rss_size == 4096);
	require(fake_shm_last_rss_pgsize == 4096);
	require(fake_shm_free_calls == 2);
	require(fake_shm_last_free == &shm_obj_token);
	require(fake_shm_log_calls == 2);
	require(fake_shm_indexed_free_calls == 0);
	mix(&digest, (unsigned long)fake_shm_free_calls);
	mix(&digest, (unsigned long)fake_shm_log_calls);
	mix(&digest, fake_shm_last_rss_size);

	fake_shm_reset();
	mix_signed(&digest, shmobj_destroy_body_result(
		&shm_obj_token, NULL, 0, 65,
		fake_shm_user_clear, fake_shm_user_locked,
		fake_shm_user_set_locked, fake_shm_user_lock,
		fake_shm_user_unlock, fake_shm_user_free,
		fake_shm_page_first, fake_shm_page_remove,
		fake_shm_page_phys, fake_shm_phys_to_virt,
		fake_shm_page_pgshift, fake_shm_page_count,
		fake_shm_page_unmap, fake_shm_free_page,
		fake_shm_rss_sub, fake_shm_free, fake_shm_indexed_free,
		fake_shm_destroy_log));
	require(fake_shm_user_clear_calls == 0);
	require(fake_shm_first_calls == 1);
	require(fake_shm_indexed_free_calls == 1);
	require(fake_shm_last_index_word == 1);
	require(fake_shm_last_index_mask == 2);
	require(fake_shm_free_calls == 0);
	mix_signed(&digest, fake_shm_last_index_word);
	mix(&digest, fake_shm_last_index_mask);

	fake_shm_reset();
	mix_signed(&digest, shmobj_free_body_result(&shm_memobj_token,
		&shm_obj_token, 0, fake_shm_lock, fake_shm_unlock,
		fake_shm_destroy_dispatch, fake_shm_free_log));
	require(fake_shm_lock_calls == 1);
	require(fake_shm_unlock_calls == 1);
	require(fake_shm_destroy_dispatch_calls == 1);
	require(fake_shm_free_log_calls == 1);
	require(fake_shm_last_log_event == 14);
	mix(&digest, (unsigned long)fake_shm_destroy_dispatch_calls);
	mix(&digest, (unsigned long)fake_shm_free_log_calls);

	mix_signed(&digest, hugefileobj_initial_status_result());
	mix_signed(&digest, hugefileobj_initial_refcnt_result());
	for (unsigned long ptr = 0; ptr <= 2; ptr++) {
		mix_signed(&digest, hugefileobj_pointer_present_result(ptr));
		mix_signed(&digest, hugefileobj_pointer_missing_result(ptr));
		mix_signed(&digest, hugefileobj_page_present_result(ptr));
	}
	for (unsigned int i = 1; i < sizeof(pgshifts) / sizeof(pgshifts[0]); i++) {
		int pgshift = pgshifts[i];
		int expected = hugefileobj_expected_p2align_result(pgshift);
		size_t pgsize = hugefileobj_pgsize_result(pgshift);

		mix_signed(&digest, expected);
		mix_signed(&digest, hugefileobj_validate_p2align_result(
			expected, pgshift));
		mix_signed(&digest, hugefileobj_validate_p2align_result(
			expected + 1, pgshift));
		mix(&digest, pgsize);
		mix_signed(&digest, hugefileobj_npages_per_page_result(pgsize));
		for (unsigned int j = 0; j < sizeof(page_offsets) / sizeof(page_offsets[0]); j++)
			mix_signed(&digest, hugefileobj_page_index_result(
				page_offsets[j], pgshift));
		mix_signed(&digest, hugefileobj_create_nr_pages_result(0,
			pgsize, pgshift));
		mix_signed(&digest, hugefileobj_create_nr_pages_result(pgsize,
			pgsize * 3, pgshift));
	}
	for (size_t old = 0; old <= 4; old += 2) {
		for (int needed = 0; needed <= 6; needed += 3) {
			mix_signed(&digest, hugefileobj_needs_grow_result(old,
				needed));
			mix(&digest, hugefileobj_page_array_bytes_result(old));
			mix(&digest, hugefileobj_copy_bytes_result(old));
			mix(&digest, hugefileobj_zero_bytes_result(old,
				old + (size_t)needed));
			mix(&digest, hugefileobj_zero_start_index_result(old));
		}
	}
	int huge_lock_token = 1;
	int huge_head_token = 2;
	int huge_obj_a = 3;
	int huge_obj_b = 4;

	fake_huge_reset();
	mix_signed(&digest, hugefileobj_free_body_result(&huge_obj_a,
		&huge_lock_token, fake_huge_lock, fake_huge_unlock,
		fake_huge_list_del, fake_huge_free));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_del_calls == 1);
	require(fake_huge_free_calls == 1);
	require(fake_huge_last_lock == &huge_lock_token);
	require(fake_huge_last_unlock == &huge_lock_token);
	require(fake_huge_last_del == &huge_obj_a);
	require(fake_huge_last_free == &huge_obj_a);
	mix(&digest, (unsigned long)fake_huge_lock_calls);
	mix(&digest, (unsigned long)fake_huge_unlock_calls);
	mix(&digest, (unsigned long)fake_huge_del_calls);
	mix(&digest, (unsigned long)fake_huge_free_calls);

	fake_huge_reset();
	fake_huge_items[0] = &huge_obj_a;
	fake_huge_items[1] = &huge_obj_b;
	fake_huge_empty_after = 2;
	mix_signed(&digest, hugefileobj_cleanup_body_result(&huge_lock_token,
		&huge_head_token, fake_huge_lock, fake_huge_unlock,
		fake_huge_list_empty, fake_huge_first, fake_huge_list_del,
		fake_huge_free));
	require(fake_huge_lock_calls == 3);
	require(fake_huge_unlock_calls == 3);
	require(fake_huge_empty_calls == 3);
	require(fake_huge_first_calls == 2);
	require(fake_huge_del_calls == 2);
	require(fake_huge_free_calls == 2);
	require(fake_huge_last_lock == &huge_lock_token);
	require(fake_huge_last_unlock == &huge_lock_token);
	require(fake_huge_last_del == &huge_obj_b);
	require(fake_huge_last_free == &huge_obj_b);
	mix(&digest, (unsigned long)fake_huge_lock_calls);
	mix(&digest, (unsigned long)fake_huge_unlock_calls);
	mix(&digest, (unsigned long)fake_huge_empty_calls);
	mix(&digest, (unsigned long)fake_huge_first_calls);
	mix(&digest, (unsigned long)fake_huge_del_calls);
	mix(&digest, (unsigned long)fake_huge_free_calls);

	fake_huge_reset();
	fake_huge_empty_after = 1;
	mix_signed(&digest, hugefileobj_cleanup_body_result(&huge_lock_token,
		&huge_head_token, fake_huge_lock, fake_huge_unlock,
		fake_huge_list_empty, fake_huge_first, fake_huge_list_del,
		fake_huge_free));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_empty_calls == 1);
	require(fake_huge_first_calls == 1);
	require(fake_huge_del_calls == 0);
	require(fake_huge_free_calls == 0);

	fake_huge_reset();
	mix_signed(&digest, hugefileobj_cleanup_body_result(NULL,
		&huge_head_token, fake_huge_lock, fake_huge_unlock,
		fake_huge_list_empty, fake_huge_first, fake_huge_list_del,
		fake_huge_free));
	require(fake_huge_lock_calls == 0);

	struct fake_huge_obj huge_obj = { 0 };
	int huge_page_a = 5;
	int huge_page_b = 6;
	int huge_page_c = 7;
	char huge_path = 'p';
	void *huge_pages_old[2] = { &huge_page_a, NULL };
	void *huge_pages_new[8] = { 0 };
	size_t huge_pgsize = 1UL << 21;
	int huge_pgshift = 21;
	int huge_expected_p2align =
		hugefileobj_expected_p2align_result(huge_pgshift);

	huge_obj.slots[0] = &huge_page_a;
	huge_obj.slots[1] = NULL;
	huge_obj.slots[2] = &huge_page_b;
	fake_huge_reset();
	mix_signed(&digest, hugefileobj_inner_free_body_result(&huge_obj,
		&huge_lock_token, &huge_path, huge_pages_old, 3,
		huge_pgsize, fake_huge_lock, fake_huge_unlock,
		fake_huge_free, fake_huge_free_page, fake_huge_page_at,
		fake_huge_clear_path, fake_huge_log));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_free_page_calls == 2);
	require(fake_huge_free_calls == 3);
	require(fake_huge_clear_path_calls == 1);
	require(fake_huge_log_calls == 2);
	require(fake_huge_last_free_page == &huge_page_b);
	require(fake_huge_last_free_npages == 512);
	require(fake_huge_last_free == &huge_obj);
	mix(&digest, (unsigned long)fake_huge_free_page_calls);
	mix(&digest, (unsigned long)fake_huge_clear_path_calls);
	mix(&digest, (unsigned long)fake_huge_log_calls);

	uintptr_t huge_phys = 0;
	huge_obj.slots[1] = &huge_page_a;
	fake_huge_reset();
	mix_signed(&digest, hugefileobj_get_page_body_result(&huge_obj,
		&huge_lock_token, huge_pgsize, huge_expected_p2align,
		huge_pgshift, huge_pgsize, 0xabc000, &huge_phys,
		fake_huge_lock, fake_huge_unlock, fake_huge_page_at,
		fake_huge_set_page, fake_huge_alloc_page, fake_huge_memset,
		fake_huge_phys, fake_huge_log));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_alloc_page_calls == 0);
	require(fake_huge_set_page_calls == 0);
	require(fake_huge_phys_calls == 1);
	require(huge_phys == (uintptr_t)&huge_page_a + 0x123000UL);

	huge_obj.slots[2] = NULL;
	fake_huge_reset();
	fake_huge_alloc_page_result = &huge_page_c;
	mix_signed(&digest, hugefileobj_get_page_body_result(&huge_obj,
		&huge_lock_token, huge_pgsize * 2, huge_expected_p2align,
		huge_pgshift, huge_pgsize, 0xdef000, &huge_phys,
		fake_huge_lock, fake_huge_unlock, fake_huge_page_at,
		fake_huge_set_page, fake_huge_alloc_page, fake_huge_memset,
		fake_huge_phys, fake_huge_log));
	require(fake_huge_alloc_page_calls == 1);
	require(fake_huge_last_alloc_npages == 512);
	require(fake_huge_last_alloc_p2align == huge_expected_p2align);
	require(fake_huge_last_alloc_flags == 0x1002UL);
	require(fake_huge_last_alloc_virt == 0xdef000UL);
	require(fake_huge_set_page_calls == 1);
	require(fake_huge_last_set_index == 2);
	require(huge_obj.slots[2] == &huge_page_c);
	require(fake_huge_memset_calls == 1);
	require(fake_huge_last_memset_dst == &huge_page_c);
	require(fake_huge_last_memset_len == huge_pgsize);
	require(fake_huge_last_log_event == 2);
	require(huge_phys == (uintptr_t)&huge_page_c + 0x123000UL);
	mix(&digest, (unsigned long)fake_huge_alloc_page_calls);
	mix(&digest, (unsigned long)fake_huge_set_page_calls);
	mix(&digest, (unsigned long)fake_huge_memset_calls);

	huge_obj.slots[3] = NULL;
	fake_huge_reset();
	huge_phys = 0xfeed;
	mix_signed(&digest, hugefileobj_get_page_body_result(&huge_obj,
		&huge_lock_token, huge_pgsize * 3, huge_expected_p2align,
		huge_pgshift, huge_pgsize, 0x123000, &huge_phys,
		fake_huge_lock, fake_huge_unlock, fake_huge_page_at,
		fake_huge_set_page, fake_huge_alloc_page, fake_huge_memset,
		fake_huge_phys, fake_huge_log));
	require(fake_huge_alloc_page_calls == 1);
	require(fake_huge_set_page_calls == 0);
	require(fake_huge_last_log_event == 1);
	require(huge_phys == 0xfeed);

	fake_huge_reset();
	mix_signed(&digest, hugefileobj_get_page_body_result(&huge_obj,
		&huge_lock_token, 0, huge_expected_p2align + 1,
		huge_pgshift, huge_pgsize, 0, &huge_phys,
		fake_huge_lock, fake_huge_unlock, fake_huge_page_at,
		fake_huge_set_page, fake_huge_alloc_page, fake_huge_memset,
		fake_huge_phys, fake_huge_log));
	require(fake_huge_lock_calls == 0);
	require(fake_huge_last_log_event == 5);
	require(fake_huge_last_log_index == huge_expected_p2align + 1);
	require(fake_huge_last_log_virt == (uintptr_t)huge_expected_p2align);

	int huge_out_pgshift = 0;
	huge_obj.size = 0;
	fake_huge_reset();
	mix_signed(&digest, hugefileobj_create_body_result(&huge_obj,
		&huge_lock_token, huge_pgsize, 0, huge_pgshift,
		huge_pgsize, 4, huge_pages_old, &huge_out_pgshift,
		0x100000, 0x2, fake_huge_lock, fake_huge_unlock,
		fake_huge_alloc, fake_huge_free, fake_huge_memcpy,
		fake_huge_memset, fake_huge_set_nr_pages,
		fake_huge_set_pages, fake_huge_set_size, fake_huge_log));
	require(fake_huge_alloc_calls == 0);
	require(fake_huge_set_nr_pages_calls == 0);
	require(fake_huge_set_size_calls == 1);
	require(huge_obj.size == huge_pgsize);
	require(huge_out_pgshift == huge_pgshift);

	huge_out_pgshift = 0;
	fake_huge_reset();
	fake_huge_alloc_result = huge_pages_new;
	mix_signed(&digest, hugefileobj_create_body_result(&huge_obj,
		&huge_lock_token, huge_pgsize * 4, 0, huge_pgshift,
		huge_pgsize, 1, huge_pages_old, &huge_out_pgshift,
		0x200000, 0x2, fake_huge_lock, fake_huge_unlock,
		fake_huge_alloc, fake_huge_free, fake_huge_memcpy,
		fake_huge_memset, fake_huge_set_nr_pages,
		fake_huge_set_pages, fake_huge_set_size, fake_huge_log));
	require(fake_huge_alloc_calls == 1);
	require(fake_huge_last_alloc_size == 4 * sizeof(void *));
	require(fake_huge_last_alloc_flags == 0x2UL);
	require(fake_huge_memcpy_calls == 1);
	require(fake_huge_last_memcpy_dst == huge_pages_new);
	require(fake_huge_last_memcpy_src == huge_pages_old);
	require(fake_huge_last_memcpy_len == sizeof(void *));
	require(fake_huge_memset_calls == 1);
	require(fake_huge_last_memset_dst == &huge_pages_new[1]);
	require(fake_huge_last_memset_len == 3 * sizeof(void *));
	require(fake_huge_free_calls == 1);
	require(fake_huge_last_free == huge_pages_old);
	require(fake_huge_set_nr_pages_calls == 1);
	require(huge_obj.nr_pages == 4);
	require(fake_huge_set_pages_calls == 1);
	require(huge_obj.pages == huge_pages_new);
	require(fake_huge_set_size_calls == 1);
	require(huge_out_pgshift == huge_pgshift);
	require(fake_huge_last_log_event == 4);
	require(fake_huge_last_log_index == 4);
	mix(&digest, (unsigned long)fake_huge_alloc_calls);
	mix(&digest, (unsigned long)fake_huge_memcpy_calls);
	mix(&digest, (unsigned long)fake_huge_memset_calls);
	mix(&digest, (unsigned long)fake_huge_set_nr_pages_calls);

	struct fake_huge_obj huge_existing = { 0 };
	struct fake_huge_obj huge_stale = { 0 };
	struct fake_huge_obj huge_new = { 0 };
	char huge_memobj_token = 11;
	char huge_ops_token = 12;
	char huge_path_buf[32] = { 0 };
	char huge_src_path[] = "/huge/path";
	void *huge_objp = NULL;
	int huge_maxprot = 0;

	huge_existing.handle = 0x5555UL;
	huge_stale.handle = 0x5555UL;
	fake_huge_reset();
	fake_huge_items[0] = &huge_obj;
	fake_huge_items[1] = &huge_stale;
	fake_huge_items[2] = &huge_existing;
	fake_huge_items[3] = NULL;
	fake_huge_ref_results[0] = 1;
	fake_huge_ref_results[1] = 3;
	void *huge_lookup = hugefileobj_lookup_body_result(
		0x5555UL, &huge_head_token, fake_huge_lookup_first,
		fake_huge_lookup_next, fake_huge_handle, fake_huge_ref,
		fake_huge_dec);
	require(huge_lookup == &huge_existing);
	require(fake_huge_lookup_first_calls == 1);
	require(fake_huge_lookup_next_calls == 2);
	require(fake_huge_ref_calls == 2);
	require(fake_huge_dec_calls == 1);
	require(fake_huge_last_dec_obj == &huge_stale);
	mix(&digest, (unsigned long)fake_huge_lookup_next_calls);
	mix(&digest, (unsigned long)fake_huge_ref_calls);
	mix(&digest, (unsigned long)fake_huge_dec_calls);

	fake_huge_reset();
	fake_huge_items[0] = &huge_obj;
	fake_huge_items[1] = NULL;
	huge_lookup = hugefileobj_lookup_body_result(
		0xaaaaUL, &huge_head_token, fake_huge_lookup_first,
		fake_huge_lookup_next, fake_huge_handle, fake_huge_ref,
		fake_huge_dec);
	require(huge_lookup == NULL);
	require(fake_huge_ref_calls == 0);
	require(fake_huge_lookup_next_calls == 1);
	mix(&digest, (unsigned long)fake_huge_lookup_next_calls);

	fake_huge_reset();
	fake_huge_lookup_result = &huge_existing;
	fake_huge_to_memobj_result = &huge_memobj_token;
	mix_signed(&digest, hugefileobj_pre_create_body_result(
		&huge_lock_token, 0x5555UL, 7, 0x100000U, huge_pgshift,
		huge_src_path, sizeof(struct fake_huge_obj), 32,
		&huge_ops_token, &huge_objp, &huge_maxprot,
		fake_huge_lock, fake_huge_unlock, fake_huge_lookup,
		fake_huge_alloc, fake_huge_free, fake_huge_to_memobj,
		fake_huge_set_handle, fake_huge_set_pgsize,
		fake_huge_set_pgshift, fake_huge_set_pages,
		fake_huge_set_nr_pages, fake_huge_init_lock,
		fake_huge_set_flags, fake_huge_set_status,
		fake_huge_set_ops, fake_huge_set_refcnt,
		fake_huge_set_path, fake_huge_copy_path,
		fake_huge_list_add, fake_huge_pre_log,
		fake_huge_alloc_error));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_lookup_calls == 1);
	require(fake_huge_last_lookup_handle == 0x5555UL);
	require(fake_huge_alloc_calls == 0);
	require(fake_huge_to_memobj_calls == 1);
	require(fake_huge_last_to_memobj == &huge_existing);
	require(huge_objp == &huge_memobj_token);
	require(huge_maxprot == 7);
	require(fake_huge_pre_log_calls == 1);
	require(fake_huge_last_pre_log_event == 6);
	require(fake_huge_last_pre_log_obj == &huge_existing);
	mix(&digest, (unsigned long)fake_huge_pre_log_calls);
	mix(&digest, (unsigned long)huge_maxprot);

	huge_objp = NULL;
	huge_maxprot = 0;
	memset(&huge_new, 0, sizeof(huge_new));
	fake_huge_reset();
	fake_huge_alloc_results[0] = &huge_new;
	fake_huge_alloc_results[1] = huge_path_buf;
	fake_huge_to_memobj_result = &huge_memobj_token;
	mix_signed(&digest, hugefileobj_pre_create_body_result(
		&huge_lock_token, 0x7777UL, 5, 0x101000U, huge_pgshift,
		huge_src_path, sizeof(struct fake_huge_obj), 32,
		&huge_ops_token, &huge_objp, &huge_maxprot,
		fake_huge_lock, fake_huge_unlock, fake_huge_lookup,
		fake_huge_alloc, fake_huge_free, fake_huge_to_memobj,
		fake_huge_set_handle, fake_huge_set_pgsize,
		fake_huge_set_pgshift, fake_huge_set_pages,
		fake_huge_set_nr_pages, fake_huge_init_lock,
		fake_huge_set_flags, fake_huge_set_status,
		fake_huge_set_ops, fake_huge_set_refcnt,
		fake_huge_set_path, fake_huge_copy_path,
		fake_huge_list_add, fake_huge_pre_log,
		fake_huge_alloc_error));
	require(fake_huge_lock_calls == 1);
	require(fake_huge_unlock_calls == 1);
	require(fake_huge_lookup_calls == 1);
	require(fake_huge_alloc_calls == 2);
	require(fake_huge_alloc_size_log[0] ==
		sizeof(struct fake_huge_obj));
	require(fake_huge_alloc_size_log[1] == 32);
	require(fake_huge_alloc_flags_log[0] == 0x2UL);
	require(fake_huge_alloc_flags_log[1] == 0x2UL);
	require(fake_huge_set_handle_calls == 1);
	require(fake_huge_last_handle == 0x7777UL);
	require(huge_new.handle == 0x7777UL);
	require(fake_huge_set_pgsize_calls == 1);
	require(huge_new.pgsize == huge_pgsize);
	require(fake_huge_set_pgshift_calls == 1);
	require(huge_new.pgshift == huge_pgshift);
	require(fake_huge_set_pages_calls == 1);
	require(huge_new.pages == NULL);
	require(fake_huge_set_nr_pages_calls == 1);
	require(huge_new.nr_pages == 0);
	require(fake_huge_init_lock_calls == 1);
	require(huge_new.lock_initialized == 1);
	require(fake_huge_set_flags_calls == 1);
	require(huge_new.flags == 0x101000U);
	require(fake_huge_set_status_calls == 1);
	require(huge_new.status == 0);
	require(fake_huge_set_ops_calls == 1);
	require(huge_new.ops == &huge_ops_token);
	require(fake_huge_set_refcnt_calls == 1);
	require(huge_new.refcnt == 2);
	require(fake_huge_set_path_calls == 1);
	require(huge_new.path == huge_path_buf);
	require(fake_huge_copy_path_calls == 1);
	require(fake_huge_last_copy_dst == huge_path_buf);
	require(fake_huge_last_copy_src == huge_src_path);
	require(fake_huge_last_copy_len == 32);
	require(fake_huge_list_add_calls == 1);
	require(huge_new.listed == 1);
	require(fake_huge_to_memobj_calls == 1);
	require(huge_objp == &huge_memobj_token);
	require(huge_maxprot == 5);
	require(fake_huge_last_pre_log_event == 7);
	mix(&digest, (unsigned long)fake_huge_alloc_calls);
	mix(&digest, huge_new.handle);
	mix(&digest, (unsigned long)fake_huge_copy_path_calls);
	mix(&digest, (unsigned long)fake_huge_last_pre_log_event);

	huge_objp = (void *)0xbeefUL;
	huge_maxprot = 0;
	fake_huge_reset();
	mix_signed(&digest, hugefileobj_pre_create_body_result(
		&huge_lock_token, 0x8888UL, 3, 0x101000U, huge_pgshift,
		huge_src_path, sizeof(struct fake_huge_obj), 32,
		&huge_ops_token, &huge_objp, &huge_maxprot,
		fake_huge_lock, fake_huge_unlock, fake_huge_lookup,
		fake_huge_alloc, fake_huge_free, fake_huge_to_memobj,
		fake_huge_set_handle, fake_huge_set_pgsize,
		fake_huge_set_pgshift, fake_huge_set_pages,
		fake_huge_set_nr_pages, fake_huge_init_lock,
		fake_huge_set_flags, fake_huge_set_status,
		fake_huge_set_ops, fake_huge_set_refcnt,
		fake_huge_set_path, fake_huge_copy_path,
		fake_huge_list_add, fake_huge_pre_log,
		fake_huge_alloc_error));
	require(fake_huge_alloc_calls == 1);
	require(fake_huge_alloc_error_calls == 1);
	require(fake_huge_last_alloc_error_stage == 1);
	require(fake_huge_free_calls == 0);
	require(fake_huge_list_add_calls == 0);
	require(huge_objp == (void *)0xbeefUL);
	mix_signed(&digest, fake_huge_last_alloc_error_stage);

	huge_objp = (void *)0xcafeUL;
	huge_maxprot = 0;
	memset(&huge_new, 0, sizeof(huge_new));
	fake_huge_reset();
	fake_huge_alloc_results[0] = &huge_new;
	mix_signed(&digest, hugefileobj_pre_create_body_result(
		&huge_lock_token, 0x9999UL, 4, 0x101000U, huge_pgshift,
		huge_src_path, sizeof(struct fake_huge_obj), 32,
		&huge_ops_token, &huge_objp, &huge_maxprot,
		fake_huge_lock, fake_huge_unlock, fake_huge_lookup,
		fake_huge_alloc, fake_huge_free, fake_huge_to_memobj,
		fake_huge_set_handle, fake_huge_set_pgsize,
		fake_huge_set_pgshift, fake_huge_set_pages,
		fake_huge_set_nr_pages, fake_huge_init_lock,
		fake_huge_set_flags, fake_huge_set_status,
		fake_huge_set_ops, fake_huge_set_refcnt,
		fake_huge_set_path, fake_huge_copy_path,
		fake_huge_list_add, fake_huge_pre_log,
		fake_huge_alloc_error));
	require(fake_huge_alloc_calls == 2);
	require(fake_huge_alloc_error_calls == 1);
	require(fake_huge_last_alloc_error_stage == 2);
	require(fake_huge_free_calls == 1);
	require(fake_huge_last_free == &huge_new);
	require(fake_huge_set_path_calls == 0);
	require(fake_huge_list_add_calls == 0);
	require(huge_objp == (void *)0xcafeUL);
	mix_signed(&digest, fake_huge_last_alloc_error_stage);
	mix(&digest, (unsigned long)fake_huge_free_calls);

	printf("object_helpers ok digest=%016lx\n", digest);
	return 0;
}
