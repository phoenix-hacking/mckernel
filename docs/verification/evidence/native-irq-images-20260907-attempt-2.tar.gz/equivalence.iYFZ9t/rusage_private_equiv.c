#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#define IHK_MAX_NUM_PGSIZES 8
#define IHK_MAX_NUM_NUMA_NODES 1024
#define IHK_MAX_NUM_CPUS 1024
#define IHK_OS_PGSIZE_4KB 0
#define IHK_OS_PGSIZE_2MB 2
#define IHK_OS_PGSIZE_1GB 4
#define IHK_OS_EVENTFD_TYPE_OOM 0
#define OVERCOMMIT_ALWAYS 1
#define ENOMEM 12
#define PAGE_SIZE 4096UL
#define RUSAGE_OOM_MARGIN (8 * 1024 * 1024UL)
#define VR_RESERVED 0x2UL
#define VR_IO_NOCACHE 0x100UL
#define VR_REMOTE 0x200UL
#define MF_REG_FILE 0x1000U
#define MF_DEV_FILE 0x2000U
#define MF_PREMAP 0x8000U
#define MF_XPMEM 0x10000U
#define MF_ZEROOBJ 0x20000U
#define MF_SHM 0x40000U
#define MF_HUGETLBFS 0x100000U
#define RUSAGE_TEST_CPU_LOCAL_SIZE 8128
#define RUSAGE_TEST_CPU_CURRENT_OFFSET 7848
#define RUSAGE_TEST_CPU_ON_FORK_VM_OFFSET 8040
#define RUSAGE_TEST_THREAD_VM_OFFSET 4200
#define RUSAGE_TEST_PROCESS_VM_PROC_OFFSET 136
#define RUSAGE_TEST_PROCESS_VM_CURRSS_OFFSET 200
#define RUSAGE_TEST_PROCESS_MAXRSS_OFFSET 1360

struct rusage_percpu {
	unsigned long user_tsc;
	unsigned long system_tsc;
};

struct rusage_global {
	long memory_stat_rss[IHK_MAX_NUM_PGSIZES];
	long memory_stat_mapped_file[IHK_MAX_NUM_PGSIZES];
	long rss_current;
	unsigned long memory_max_usage;
	unsigned long max_num_threads;
	unsigned long num_threads;
	unsigned long memory_kmem_usage;
	unsigned long memory_kmem_max_usage;
	unsigned long memory_numa_stat[IHK_MAX_NUM_NUMA_NODES];
	struct rusage_percpu cpu[IHK_MAX_NUM_CPUS];
	unsigned long total_memory;
	unsigned long total_memory_usage;
	unsigned long total_memory_max_usage;
	unsigned long num_numa_nodes;
	unsigned long num_processors;
	unsigned long ns_per_tsc;
};

struct memobj {
	void *ops;
	unsigned int flags;
	unsigned int status;
	unsigned long size;
	int refcnt;
	int padding;
	void **pages;
	int nr_pages;
	int padding2;
	char *path;
};

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct page {
	struct list_head list;
	struct list_head hash;
	uint8_t mode;
	uint64_t phys;
	struct {
		int counter;
	} count;
	struct {
		long counter64;
	} mapped;
	long offset;
	int pgshift;
};

struct vm_range {
	unsigned char rb_node[24];
	unsigned long start;
	unsigned long end;
	unsigned long flag;
	unsigned long straight_start;
	struct memobj *memobj;
	long objoff;
	int pgshift;
	int padding;
	void *private_data;
};

struct process {
	unsigned char pad_maxrss[RUSAGE_TEST_PROCESS_MAXRSS_OFFSET];
	long maxrss;
};

struct process_vm {
	unsigned char pad_proc[RUSAGE_TEST_PROCESS_VM_PROC_OFFSET];
	struct process *proc;
	unsigned char pad_currss[
		RUSAGE_TEST_PROCESS_VM_CURRSS_OFFSET -
		RUSAGE_TEST_PROCESS_VM_PROC_OFFSET - sizeof(void *)];
	long currss;
};

struct thread {
	unsigned char pad_vm[RUSAGE_TEST_THREAD_VM_OFFSET];
	struct process_vm *vm;
};

struct cpu_local_var {
	unsigned char raw[RUSAGE_TEST_CPU_LOCAL_SIZE];
};

static struct cpu_local_var fake_cpu_local __attribute__((aligned(64)));
static struct thread fake_current_thread;
struct cpu_local_var *clv = &fake_cpu_local;
static struct page *fake_phys_to_page_result;
static int fake_phys_to_page_calls;
static unsigned long fake_phys_to_page_last_phys;

struct page *phys_to_page(uintptr_t phys)
{
	fake_phys_to_page_calls++;
	fake_phys_to_page_last_phys = phys;
	return fake_phys_to_page_result;
}

static void reset_fake_phys_to_page(void)
{
	fake_phys_to_page_result = NULL;
	fake_phys_to_page_calls = 0;
	fake_phys_to_page_last_phys = 0;
}

static void fake_cpu_store_ptr(size_t offset, void *ptr)
{
	*(void **)(fake_cpu_local.raw + offset) = ptr;
}

static void *fake_cpu_load_ptr(size_t offset)
{
	return *(void **)(fake_cpu_local.raw + offset);
}

static void reset_fake_cpu_local(void)
{
	for (size_t i = 0; i < sizeof(fake_cpu_local.raw); i++) {
		fake_cpu_local.raw[i] = 0;
	}
	fake_current_thread.vm = NULL;
	fake_cpu_store_ptr(RUSAGE_TEST_CPU_CURRENT_OFFSET,
		&fake_current_thread);
}

static void fake_set_current_vm(struct process_vm *vm)
{
	fake_current_thread.vm = vm;
	fake_cpu_store_ptr(RUSAGE_TEST_CPU_CURRENT_OFFSET,
		&fake_current_thread);
}

static void fake_set_on_fork_vm(struct process_vm *vm)
{
	fake_cpu_store_ptr(RUSAGE_TEST_CPU_ON_FORK_VM_OFFSET, vm);
}

static struct process_vm *fake_rusage_vm_for_add(void)
{
	struct process_vm *vm =
		(struct process_vm *)fake_cpu_load_ptr(
			RUSAGE_TEST_CPU_ON_FORK_VM_OFFSET);
	struct thread *thread;

	if (vm) {
		return vm;
	}
	thread = (struct thread *)fake_cpu_load_ptr(
		RUSAGE_TEST_CPU_CURRENT_OFFSET);
	return thread->vm;
}

static struct process_vm *fake_rusage_vm_for_sub(void)
{
	struct thread *thread = (struct thread *)fake_cpu_load_ptr(
		RUSAGE_TEST_CPU_CURRENT_OFFSET);

	return thread->vm;
}

extern struct rusage_global rusage;
extern int rusage_pgsize_to_pgtype(size_t pgsize);
extern void rusage_total_memory_add(unsigned long size);
extern unsigned long rusage_get_total_memory(void);
extern unsigned long rusage_get_free_memory(void);
extern unsigned long rusage_get_usage_memory(void);
extern void rusage_rss_add(unsigned long size);
extern void rusage_rss_sub(unsigned long size);
extern void memory_stat_rss_add(unsigned long size, int pgsize);
extern void memory_stat_rss_sub(unsigned long size, int pgsize);
extern void rusage_memory_stat_mapped_file_add(unsigned long size, int pgsize);
extern void rusage_memory_stat_mapped_file_sub(unsigned long size, int pgsize);
extern void rusage_memory_stat_sub(struct memobj *memobj, unsigned long size,
		int pgsize);
extern int rusage_memory_stat_add(struct vm_range *range, uintptr_t phys,
		unsigned long size, int pgsize);
extern int rusage_memory_stat_add_with_page(struct vm_range *range,
		uintptr_t phys, unsigned long size, int pgsize,
		struct page *page);
extern void rusage_numa_add(int numa_id, unsigned long size);
extern void rusage_numa_sub(int numa_id, unsigned long size);
extern void rusage_page_add(int numa_id, unsigned long pages, int is_user);
extern void rusage_page_sub(int numa_id, unsigned long pages, int is_user);
extern void rusage_kmem_add(unsigned long size);
extern void rusage_kmem_sub(unsigned long size);
extern void rusage_num_threads_inc(void);
extern void rusage_num_threads_dec(void);
extern int rusage_check_oom(int numa_id, unsigned long pages, int is_user);
extern int rusage_check_overmap(size_t len, int pgshift);

struct rusage_global rusage;
int sysctl_overcommit_memory;
static int eventfd_count;
static int eventfd_last_type;
static int kprintf_count;

void eventfd(int type)
{
	eventfd_count++;
	eventfd_last_type = type;
}

int kprintf(const char *format, ...)
{
	va_list ap;

	(void)format;
	va_start(ap, format);
	va_end(ap);
	kprintf_count++;
	return 0;
}

#ifdef USE_C_RUSAGE_PRIVATE_MODEL
static int pgsize_to_pgshift(size_t pgsize)
{
	switch (pgsize) {
	case 0x1000:
		return 12;
	case 0x20UL * 0x10000UL:
		return 21;
	case 0x4000UL * 0x10000UL:
		return 30;
	default:
		return -22;
	}
}

int rusage_pgsize_to_pgtype(size_t pgsize)
{
	int ret = IHK_OS_PGSIZE_4KB;
	int pgshift = pgsize_to_pgshift(pgsize);

	switch (pgshift) {
	case 12:
		ret = IHK_OS_PGSIZE_4KB;
		break;
	case 21:
		ret = IHK_OS_PGSIZE_2MB;
		break;
	case 30:
		ret = IHK_OS_PGSIZE_1GB;
		break;
	default:
		break;
	}

	return ret;
}

void rusage_total_memory_add(unsigned long size)
{
	rusage.total_memory += size;
}

unsigned long rusage_get_total_memory(void)
{
	return rusage.total_memory;
}

unsigned long rusage_get_free_memory(void)
{
	return rusage.total_memory - rusage.total_memory_usage;
}

unsigned long rusage_get_usage_memory(void)
{
	return rusage.total_memory_usage;
}

void rusage_rss_add(unsigned long size)
{
	unsigned long newval;
	unsigned long oldval;
	unsigned long retval;
	struct process_vm *vm;

	newval = __sync_add_and_fetch(&rusage.rss_current, size);
	oldval = rusage.memory_max_usage;
	while (newval > oldval) {
		retval = __sync_val_compare_and_swap(&rusage.memory_max_usage,
			oldval, newval);
		if (retval == oldval) {
			break;
		}
		oldval = retval;
	}

	vm = fake_rusage_vm_for_add();
	vm->currss += size;
	if (vm->proc && vm->currss > vm->proc->maxrss) {
		vm->proc->maxrss = vm->currss;
	}
}

void rusage_rss_sub(unsigned long size)
{
	struct process_vm *vm = fake_rusage_vm_for_sub();

	__sync_sub_and_fetch(&rusage.rss_current, size);
	vm->currss -= size;
}

void memory_stat_rss_add(unsigned long size, int pgsize)
{
	__sync_add_and_fetch(
		&rusage.memory_stat_rss[rusage_pgsize_to_pgtype(pgsize)], size);
}

void memory_stat_rss_sub(unsigned long size, int pgsize)
{
	__sync_add_and_fetch(
		&rusage.memory_stat_rss[rusage_pgsize_to_pgtype(pgsize)], -size);
}

void rusage_memory_stat_mapped_file_add(unsigned long size, int pgsize)
{
	__sync_add_and_fetch(
		&rusage.memory_stat_mapped_file[
			rusage_pgsize_to_pgtype(pgsize)], size);
}

void rusage_memory_stat_mapped_file_sub(unsigned long size, int pgsize)
{
	__sync_add_and_fetch(
		&rusage.memory_stat_mapped_file[
			rusage_pgsize_to_pgtype(pgsize)], -size);
}

static int rusage_memory_stat_add_common(struct vm_range *range,
		uintptr_t phys, unsigned long size, int pgsize,
		struct page *page, int lookup_page, unsigned int cow_flags)
{
	if (range->flag & (VR_REMOTE | VR_IO_NOCACHE | VR_RESERVED)) {
		return 0;
	}
	if (!range->memobj) {
		memory_stat_rss_add(size, pgsize);
		return 1;
	}
	if ((range->memobj->flags & MF_DEV_FILE) ||
			(range->memobj->flags & MF_PREMAP) ||
			(range->memobj->flags & MF_XPMEM)) {
		return 0;
	}
	if (range->memobj->flags & MF_ZEROOBJ) {
		memory_stat_rss_add(size, pgsize);
		return 1;
	}
	if (lookup_page) {
		page = phys_to_page(phys);
	}
	if ((range->memobj->flags & cow_flags) && !page) {
		memory_stat_rss_add(size, pgsize);
		return 1;
	}
	if (!page) {
		kprintf("%s: WARNING !page,phys=%lx\n", __FUNCTION__, phys);
		return 0;
	}
	if (__sync_bool_compare_and_swap(&page->mapped.counter64, 0, 1)) {
		if (range->memobj->flags & MF_SHM) {
			memory_stat_rss_add(size, pgsize);
		} else {
			rusage_memory_stat_mapped_file_add(size, pgsize);
		}
		return 1;
	}
	return 0;
}

int rusage_memory_stat_add(struct vm_range *range, uintptr_t phys,
		unsigned long size, int pgsize)
{
	return rusage_memory_stat_add_common(range, phys, size, pgsize,
		NULL, 1, MF_DEV_FILE | MF_REG_FILE | MF_HUGETLBFS);
}

int rusage_memory_stat_add_with_page(struct vm_range *range, uintptr_t phys,
		unsigned long size, int pgsize, struct page *page)
{
	return rusage_memory_stat_add_common(range, phys, size, pgsize, page,
		0, MF_DEV_FILE | MF_REG_FILE);
}

void rusage_memory_stat_sub(struct memobj *memobj, unsigned long size,
		int pgsize)
{
	if (memobj->flags & MF_SHM) {
		memory_stat_rss_sub(size, pgsize);
	} else {
		rusage_memory_stat_mapped_file_sub(size, pgsize);
	}
}

void rusage_numa_add(int numa_id, unsigned long size)
{
	__sync_add_and_fetch(rusage.memory_numa_stat + numa_id, size);
	rusage_rss_add(size);
}

void rusage_numa_sub(int numa_id, unsigned long size)
{
	rusage_rss_sub(size);
	__sync_sub_and_fetch(rusage.memory_numa_stat + numa_id, size);
}

void rusage_page_add(int numa_id, unsigned long pages, int is_user)
{
	unsigned long size = pages * PAGE_SIZE;
	unsigned long newval;
	unsigned long oldval;
	unsigned long retval;

	if (is_user)
		rusage_numa_add(numa_id, size);
	else
		rusage_kmem_add(size);

	newval = __sync_add_and_fetch(&rusage.total_memory_usage, size);
	oldval = rusage.total_memory_max_usage;
	while (newval > oldval) {
		retval = __sync_val_compare_and_swap(
			&rusage.total_memory_max_usage, oldval, newval);
		if (retval == oldval) {
			break;
		}
		oldval = retval;
	}
}

void rusage_page_sub(int numa_id, unsigned long pages, int is_user)
{
	unsigned long size = pages * PAGE_SIZE;

	__sync_sub_and_fetch(&rusage.total_memory_usage, size);

	if (is_user)
		rusage_numa_sub(numa_id, size);
	else
		rusage_kmem_sub(size);
}

void rusage_kmem_add(unsigned long size)
{
	unsigned long newval;
	unsigned long oldval;
	unsigned long retval;

	newval = __sync_add_and_fetch(&rusage.memory_kmem_usage, size);
	oldval = rusage.memory_kmem_max_usage;
	while (newval > oldval) {
		retval = __sync_val_compare_and_swap(
			&rusage.memory_kmem_max_usage, oldval, newval);
		if (retval == oldval) {
			break;
		}
		oldval = retval;
	}
}

void rusage_kmem_sub(unsigned long size)
{
	__sync_sub_and_fetch(&rusage.memory_kmem_usage, size);
}

void rusage_num_threads_inc(void)
{
	unsigned long newval;
	unsigned long oldval;
	unsigned long retval;

	newval = __sync_add_and_fetch(&rusage.num_threads, 1);
	oldval = rusage.max_num_threads;
	while (newval > oldval) {
		retval = __sync_val_compare_and_swap(
			&rusage.max_num_threads, oldval, newval);
		if (retval == oldval) {
			break;
		}
		oldval = retval;
	}
}

void rusage_num_threads_dec(void)
{
	__sync_sub_and_fetch(&rusage.num_threads, 1);
}

int rusage_check_oom(int numa_id, unsigned long pages, int is_user)
{
	unsigned long size = pages * PAGE_SIZE;

	(void)numa_id;
	if (rusage.total_memory_usage + size >
			rusage.total_memory - RUSAGE_OOM_MARGIN) {
		kprintf("%s: memory used:%ld available:%ld\n",
			__FUNCTION__, rusage.total_memory_usage,
			rusage.total_memory);
		eventfd(IHK_OS_EVENTFD_TYPE_OOM);
		if (is_user) {
			return -ENOMEM;
		}
	}

	return 0;
}

int rusage_check_overmap(size_t len, int pgshift)
{
	int npages = 0, remain_pages = 0;

	if (sysctl_overcommit_memory == OVERCOMMIT_ALWAYS)
		return 0;

	npages = (len + (1UL << pgshift) - 1) >> pgshift;
	remain_pages = (rusage.total_memory - rusage.total_memory_usage)
			>> pgshift;

	if (npages > remain_pages) {
		return 1;
	}

	return 0;
}
#endif

static void require(int cond)
{
	if (!cond) {
		fprintf(stderr, "rusage_private equivalence assertion failed\n");
		abort();
	}
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void reset_rusage(void)
{
	unsigned char *p = (unsigned char *)&rusage;
	for (size_t i = 0; i < sizeof(rusage); i++) {
		p[i] = 0;
	}
	eventfd_count = 0;
	eventfd_last_type = -1;
	kprintf_count = 0;
	sysctl_overcommit_memory = 0;
	reset_fake_phys_to_page();
	reset_fake_cpu_local();
}

int main(void)
{
	unsigned long digest = 0x5255534147455052UL;
	size_t sizes[] = { 0x1000, 0x20UL * 0x10000UL,
		0x4000UL * 0x10000UL, 0x10000, 123 };
	int expected[] = { IHK_OS_PGSIZE_4KB, IHK_OS_PGSIZE_2MB,
		IHK_OS_PGSIZE_1GB, IHK_OS_PGSIZE_4KB, IHK_OS_PGSIZE_4KB };

	for (size_t i = 0; i < sizeof(sizes) / sizeof(sizes[0]); i++) {
		int got = rusage_pgsize_to_pgtype(sizes[i]);
		require(got == expected[i]);
		mix(&digest, (unsigned long)got);
	}

	reset_rusage();
	rusage.total_memory = 1000;
	rusage.total_memory_usage = 333;
	require(rusage_get_total_memory() == 1000);
	require(rusage_get_free_memory() == 667);
	require(rusage_get_usage_memory() == 333);
	mix(&digest, rusage_get_total_memory());
	mix(&digest, rusage_get_free_memory());
	mix(&digest, rusage_get_usage_memory());

	rusage_total_memory_add(25);
	require(rusage.total_memory == 1025);
	require(rusage_get_total_memory() == 1025);
	require(rusage_get_free_memory() == 692);
	mix(&digest, rusage_get_total_memory());
	mix(&digest, rusage_get_free_memory());

	reset_rusage();
	rusage.total_memory = ~0UL - 3;
	rusage.total_memory_usage = ~0UL - 9;
	rusage_total_memory_add(16);
	require(rusage_get_total_memory() == 12);
	require(rusage_get_free_memory() == 22);
	mix(&digest, rusage_get_total_memory());
	mix(&digest, rusage_get_free_memory());

	reset_rusage();
	{
		struct process current_proc = { 0 };
		struct process fork_proc = { 0 };
		struct process_vm current_vm = { 0 };
		struct process_vm fork_vm = { 0 };

		current_vm.proc = &current_proc;
		current_vm.currss = 10;
		fork_vm.proc = &fork_proc;
		fork_vm.currss = 3;
		fake_set_current_vm(&current_vm);
		fake_set_on_fork_vm(NULL);

		rusage.rss_current = 4;
		rusage.memory_max_usage = 20;
		rusage_rss_add(5);
		require(rusage.rss_current == 9);
		require(rusage.memory_max_usage == 20);
		require(current_vm.currss == 15);
		require(current_proc.maxrss == 15);

		rusage_rss_add(20);
		require(rusage.rss_current == 29);
		require(rusage.memory_max_usage == 29);
		require(current_vm.currss == 35);
		require(current_proc.maxrss == 35);

		rusage_rss_sub(7);
		require(rusage.rss_current == 22);
		require(current_vm.currss == 28);
		require(current_proc.maxrss == 35);

		fake_set_on_fork_vm(&fork_vm);
		rusage_rss_add(11);
		require(rusage.rss_current == 33);
		require(rusage.memory_max_usage == 33);
		require(current_vm.currss == 28);
		require(fork_vm.currss == 14);
		require(fork_proc.maxrss == 14);

		rusage_rss_sub(3);
		require(rusage.rss_current == 30);
		require(current_vm.currss == 25);
		require(fork_vm.currss == 14);
		mix(&digest, (unsigned long)rusage.rss_current);
		mix(&digest, rusage.memory_max_usage);
		mix(&digest, (unsigned long)current_vm.currss);
		mix(&digest, (unsigned long)fork_vm.currss);
		mix(&digest, (unsigned long)current_proc.maxrss);
		mix(&digest, (unsigned long)fork_proc.maxrss);
	}

	reset_rusage();
	{
		struct process proc = { 0 };
		struct process_vm vm = { 0 };

		vm.proc = &proc;
		fake_set_current_vm(&vm);
		rusage_numa_add(3, 8);
		require(rusage.memory_numa_stat[3] == 8);
		require(rusage.rss_current == 8);
		require(rusage.memory_max_usage == 8);
		require(vm.currss == 8);
		require(proc.maxrss == 8);
		rusage_numa_sub(3, 5);
		require(rusage.memory_numa_stat[3] == 3);
		require(rusage.rss_current == 3);
		require(vm.currss == 3);
		require(proc.maxrss == 8);
		mix(&digest, rusage.memory_numa_stat[3]);
		mix(&digest, (unsigned long)rusage.rss_current);
		mix(&digest, (unsigned long)vm.currss);
		mix(&digest, (unsigned long)proc.maxrss);
	}

	reset_rusage();
	{
		struct process proc = { 0 };
		struct process_vm vm = { 0 };

		vm.proc = &proc;
		fake_set_current_vm(&vm);
		rusage.total_memory_usage = PAGE_SIZE;
		rusage.total_memory_max_usage = 3 * PAGE_SIZE;
		rusage_page_add(5, 2, 1);
		require(rusage.total_memory_usage == 3 * PAGE_SIZE);
		require(rusage.total_memory_max_usage == 3 * PAGE_SIZE);
		require(rusage.memory_numa_stat[5] == 2 * PAGE_SIZE);
		require(rusage.rss_current == 2 * PAGE_SIZE);
		require(vm.currss == 2 * PAGE_SIZE);
		require(proc.maxrss == 2 * PAGE_SIZE);
		rusage_page_add(5, 1, 1);
		require(rusage.total_memory_usage == 4 * PAGE_SIZE);
		require(rusage.total_memory_max_usage == 4 * PAGE_SIZE);
		require(rusage.memory_numa_stat[5] == 3 * PAGE_SIZE);
		require(rusage.rss_current == 3 * PAGE_SIZE);
		require(vm.currss == 3 * PAGE_SIZE);
		require(proc.maxrss == 3 * PAGE_SIZE);
		rusage_page_sub(5, 2, 1);
		require(rusage.total_memory_usage == 2 * PAGE_SIZE);
		require(rusage.memory_numa_stat[5] == PAGE_SIZE);
		require(rusage.rss_current == PAGE_SIZE);
		require(vm.currss == PAGE_SIZE);
		require(proc.maxrss == 3 * PAGE_SIZE);
		mix(&digest, rusage.total_memory_usage);
		mix(&digest, rusage.total_memory_max_usage);
		mix(&digest, rusage.memory_numa_stat[5]);
		mix(&digest, (unsigned long)vm.currss);
		mix(&digest, (unsigned long)proc.maxrss);
	}

	reset_rusage();
	rusage.total_memory_usage = 7 * PAGE_SIZE;
	rusage.total_memory_max_usage = 10 * PAGE_SIZE;
	rusage.memory_kmem_usage = PAGE_SIZE;
	rusage.memory_kmem_max_usage = 8 * PAGE_SIZE;
	rusage_page_add(1, 2, 0);
	require(rusage.total_memory_usage == 9 * PAGE_SIZE);
	require(rusage.total_memory_max_usage == 10 * PAGE_SIZE);
	require(rusage.memory_kmem_usage == 3 * PAGE_SIZE);
	require(rusage.memory_kmem_max_usage == 8 * PAGE_SIZE);
	rusage_page_add(1, 3, 0);
	require(rusage.total_memory_usage == 12 * PAGE_SIZE);
	require(rusage.total_memory_max_usage == 12 * PAGE_SIZE);
	require(rusage.memory_kmem_usage == 6 * PAGE_SIZE);
	require(rusage.memory_kmem_max_usage == 8 * PAGE_SIZE);
	rusage_page_sub(1, 4, 0);
	require(rusage.total_memory_usage == 8 * PAGE_SIZE);
	require(rusage.memory_kmem_usage == 2 * PAGE_SIZE);
	require(rusage.memory_kmem_max_usage == 8 * PAGE_SIZE);
	mix(&digest, rusage.total_memory_usage);
	mix(&digest, rusage.total_memory_max_usage);
	mix(&digest, rusage.memory_kmem_usage);
	mix(&digest, rusage.memory_kmem_max_usage);

	reset_rusage();
	memory_stat_rss_add(11, 0x1000);
	memory_stat_rss_add(7, 0x20UL * 0x10000UL);
	memory_stat_rss_sub(3, 0x1000);
	memory_stat_rss_sub(2, 123);
	rusage_memory_stat_mapped_file_add(19, 0x4000UL * 0x10000UL);
	rusage_memory_stat_mapped_file_add(5, 0x10000);
	rusage_memory_stat_mapped_file_sub(4, 0x4000UL * 0x10000UL);
	rusage_memory_stat_mapped_file_sub(1, 0x10000);
	require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 6);
	require(rusage.memory_stat_rss[IHK_OS_PGSIZE_2MB] == 7);
	require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_4KB] == 4);
	require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_1GB] == 15);
	mix(&digest, (unsigned long)rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB]);
	mix(&digest, (unsigned long)rusage.memory_stat_rss[IHK_OS_PGSIZE_2MB]);
	mix(&digest,
		(unsigned long)rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_4KB]);
	mix(&digest,
		(unsigned long)rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_1GB]);

	reset_rusage();
	{
		struct memobj shm = { .flags = MF_SHM };
		struct memobj regular = { .flags = 0 };
		struct memobj shm_with_flags = { .flags = MF_SHM | 0x10 };

		rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] = 30;
		rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_2MB] = 40;
		rusage_memory_stat_sub(&shm, 5, 0x1000);
		rusage_memory_stat_sub(&regular, 7, 0x20UL * 0x10000UL);
		rusage_memory_stat_sub(&shm_with_flags, 3, 0x1000);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 22);
		require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_2MB] == 33);
		mix(&digest, (unsigned long)rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB]);
		mix(&digest,
			(unsigned long)rusage.memory_stat_mapped_file[
				IHK_OS_PGSIZE_2MB]);
	}

	reset_rusage();
	{
		struct memobj regular = { .flags = 0 };
		struct memobj reg_file = { .flags = MF_REG_FILE };
		struct memobj dev_file = { .flags = MF_DEV_FILE };
		struct memobj premap = { .flags = MF_PREMAP };
		struct memobj xpmem = { .flags = MF_XPMEM };
		struct memobj zeroobj = { .flags = MF_ZEROOBJ };
		struct memobj shm = { .flags = MF_SHM };
		struct memobj huge = { .flags = MF_HUGETLBFS };
		struct vm_range range = { .memobj = &regular };
		struct page page = { 0 };
		struct page page2 = { 0 };
		int ret;

		range.flag = VR_REMOTE | VR_IO_NOCACHE | VR_RESERVED;
		ret = rusage_memory_stat_add(&range, 0x111000, 13, 0x1000);
		require(ret == 0);
		require(fake_phys_to_page_calls == 0);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 0);

		range.flag = 0;
		range.memobj = NULL;
		ret = rusage_memory_stat_add(&range, 0x222000, 17, 0x1000);
		require(ret == 1);
		require(fake_phys_to_page_calls == 0);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 17);

		range.memobj = &dev_file;
		ret = rusage_memory_stat_add(&range, 0x333000, 19, 0x1000);
		require(ret == 0);
		require(fake_phys_to_page_calls == 0);
		range.memobj = &premap;
		ret = rusage_memory_stat_add(&range, 0x444000, 23, 0x1000);
		require(ret == 0);
		require(fake_phys_to_page_calls == 0);
		range.memobj = &xpmem;
		ret = rusage_memory_stat_add(&range, 0x555000, 29, 0x1000);
		require(ret == 0);
		require(fake_phys_to_page_calls == 0);

		range.memobj = &zeroobj;
		ret = rusage_memory_stat_add(&range, 0x666000, 31, 0x1000);
		require(ret == 1);
		require(fake_phys_to_page_calls == 0);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 48);

		range.memobj = &reg_file;
		ret = rusage_memory_stat_add(&range, 0x777000, 37, 0x1000);
		require(ret == 1);
		require(fake_phys_to_page_calls == 1);
		require(fake_phys_to_page_last_phys == 0x777000);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 85);

		reset_fake_phys_to_page();
		range.memobj = &huge;
		ret = rusage_memory_stat_add(&range, 0x778000, 39, 0x1000);
		require(ret == 1);
		require(fake_phys_to_page_calls == 1);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 124);

		range.memobj = &regular;
		reset_fake_phys_to_page();
		ret = rusage_memory_stat_add(&range, 0x888000, 41, 0x1000);
		require(ret == 0);
		require(fake_phys_to_page_calls == 1);
		require(kprintf_count == 1);

		page.mapped.counter64 = 0;
		fake_phys_to_page_result = &page;
		ret = rusage_memory_stat_add(&range, 0x999000, 43, 0x1000);
		require(ret == 1);
		require(page.mapped.counter64 == 1);
		require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_4KB] == 43);

		ret = rusage_memory_stat_add(&range, 0x999000, 47, 0x1000);
		require(ret == 0);
		require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_4KB] == 43);

		page2.mapped.counter64 = 0;
		range.memobj = &shm;
		reset_fake_phys_to_page();
		fake_phys_to_page_result = &page2;
		ret = rusage_memory_stat_add(&range, 0xaaa000, 53, 0x1000);
		require(ret == 1);
		require(page2.mapped.counter64 == 1);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 177);

		range.memobj = &reg_file;
		reset_fake_phys_to_page();
		ret = rusage_memory_stat_add_with_page(&range, 0xbbb000, 59,
			0x1000, NULL);
		require(ret == 1);
		require(fake_phys_to_page_calls == 0);
		require(rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB] == 236);

		range.memobj = &huge;
		ret = rusage_memory_stat_add_with_page(&range, 0xccc000, 61,
			0x1000, NULL);
		require(ret == 0);
		require(kprintf_count == 2);
		require(fake_phys_to_page_calls == 0);

		page2.mapped.counter64 = 0;
		range.memobj = &regular;
		ret = rusage_memory_stat_add_with_page(&range, 0xddd000, 67,
			0x1000, &page2);
		require(ret == 1);
		require(page2.mapped.counter64 == 1);
		require(rusage.memory_stat_mapped_file[IHK_OS_PGSIZE_4KB] == 110);
		require(fake_phys_to_page_calls == 0);

		mix(&digest,
			(unsigned long)rusage.memory_stat_rss[IHK_OS_PGSIZE_4KB]);
		mix(&digest,
			(unsigned long)rusage.memory_stat_mapped_file[
				IHK_OS_PGSIZE_4KB]);
		mix(&digest, (unsigned long)kprintf_count);
		mix(&digest, (unsigned long)fake_phys_to_page_calls);
	}

	reset_rusage();
	rusage.memory_kmem_usage = 5;
	rusage.memory_kmem_max_usage = 9;
	rusage_kmem_add(3);
	require(rusage.memory_kmem_usage == 8);
	require(rusage.memory_kmem_max_usage == 9);
	rusage_kmem_add(4);
	require(rusage.memory_kmem_usage == 12);
	require(rusage.memory_kmem_max_usage == 12);
	rusage_kmem_sub(5);
	require(rusage.memory_kmem_usage == 7);
	require(rusage.memory_kmem_max_usage == 12);
	mix(&digest, rusage.memory_kmem_usage);
	mix(&digest, rusage.memory_kmem_max_usage);

	reset_rusage();
	rusage.num_threads = 2;
	rusage.max_num_threads = 5;
	rusage_num_threads_inc();
	require(rusage.num_threads == 3);
	require(rusage.max_num_threads == 5);
	rusage.max_num_threads = 3;
	rusage_num_threads_inc();
	require(rusage.num_threads == 4);
	require(rusage.max_num_threads == 4);
	rusage_num_threads_dec();
	require(rusage.num_threads == 3);
	require(rusage.max_num_threads == 4);
	mix(&digest, rusage.num_threads);
	mix(&digest, rusage.max_num_threads);

	reset_rusage();
	rusage.total_memory = RUSAGE_OOM_MARGIN + 4096;
	rusage.total_memory_usage = 0;
	require(rusage_check_oom(2, 1, 1) == 0);
	require(eventfd_count == 0);
	rusage.total_memory_usage = RUSAGE_OOM_MARGIN + 1;
	require(rusage_check_oom(2, 2, 0) == 0);
	require(eventfd_count == 1);
	require(eventfd_last_type == IHK_OS_EVENTFD_TYPE_OOM);
	require(kprintf_count == 1);
	require(rusage_check_oom(2, 2, 1) == -ENOMEM);
	require(eventfd_count == 2);
	mix(&digest, (unsigned long)eventfd_count);
	mix(&digest, (unsigned long)kprintf_count);

	reset_rusage();
	rusage.total_memory = 20UL << 12;
	rusage.total_memory_usage = 8UL << 12;
	sysctl_overcommit_memory = OVERCOMMIT_ALWAYS;
	require(rusage_check_overmap(13UL << 12, 12) == 0);
	sysctl_overcommit_memory = 0;
	require(rusage_check_overmap(12UL << 12, 12) == 0);
	require(rusage_check_overmap((12UL << 12) + 1, 12) == 1);
	mix(&digest, (unsigned long)rusage_check_overmap(1UL << 21, 21));

	printf("rusage_private ok digest=%016lx\n", digest);
	return 0;
}
