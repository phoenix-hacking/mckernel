#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

extern int __bitmap_parse(const char *, unsigned int, int, unsigned long *, int);
extern int bitmap_parse_user(const char *, unsigned int, unsigned long *, int);
extern int bitmap_parselist(const char *, unsigned long *, int);
extern int bitmap_parselist_user(const char *, unsigned int, unsigned long *, int);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static size_t local_len(const char *s)
{
	size_t len = 0;

	while (s[len])
		len++;
	return len;
}

static void reset_words(unsigned long *words, unsigned long seed)
{
	for (unsigned int i = 0; i < 4; i++)
		words[i] = seed ^ (0x0101010101010101UL * i);
}

static void mix_words(unsigned long *digest, const unsigned long *words)
{
	for (unsigned int i = 0; i < 4; i++)
		mix(digest, words[i]);
}

static void run_hex_parse(unsigned long *digest, const char *input,
			  unsigned int len, int nbits, int user)
{
	unsigned long mask[4];
	int ret;

	reset_words(mask, 0xa5a55a5adead0000UL);
	if (user)
		ret = bitmap_parse_user(input, len, mask, nbits);
	else
		ret = __bitmap_parse(input, len, 0, mask, nbits);
	mix_signed(digest, ret);
	mix_signed(digest, nbits);
	mix_signed(digest, user);
	mix_words(digest, mask);
}

static void run_list_parse(unsigned long *digest, const char *input,
			   unsigned int len, int nbits, int user)
{
	unsigned long mask[4];
	int ret;

	reset_words(mask, 0x5a5aa5a512340000UL);
	if (user)
		ret = bitmap_parselist_user(input, len, mask, nbits);
	else
		ret = bitmap_parselist(input, mask, nbits);
	mix_signed(digest, ret);
	mix_signed(digest, nbits);
	mix_signed(digest, user);
	mix_words(digest, mask);
}

int main(void)
{
	const char *hex_inputs[] = {
		"", "0", "00", "1", "f", "deadBEEF", "000000001",
		"00000000,00000001", "1,0", "0,1", "ffffffff,ffffffff",
		"100000000", "1,,5", ",44", ",", " 1", "1 ", "1 2",
		" 0000000f,\n00000001", "0x1", "g", "00000000,00000000,1",
	};
	const char *list_inputs[] = {
		"", "0", "0-3,8,10-12", "1,2\nignored", "1, 2", "1 2",
		"3-1", "999", ",", "5-", "-5", " 4 ", "0,64", "63",
		"31-33", "0-0,2-2,4", "0007", "7,7",
	};
	int nbits[] = { 0, 1, 4, 8, 31, 32, 33, 64, 65, 96, 128 };
	unsigned long digest = 0xb17a95eUL;

	for (unsigned int i = 0; i < sizeof(hex_inputs) / sizeof(hex_inputs[0]); i++) {
		for (unsigned int n = 0; n < sizeof(nbits) / sizeof(nbits[0]); n++) {
			run_hex_parse(&digest, hex_inputs[i],
				      (unsigned int)(local_len(hex_inputs[i]) + 1),
				      nbits[n], 0);
			run_hex_parse(&digest, hex_inputs[i],
				      (unsigned int)local_len(hex_inputs[i]),
				      nbits[n], 0);
			run_hex_parse(&digest, hex_inputs[i],
				      (unsigned int)local_len(hex_inputs[i]),
				      nbits[n], 1);
		}
	}

	for (unsigned int i = 0; i < sizeof(list_inputs) / sizeof(list_inputs[0]); i++) {
		for (unsigned int n = 0; n < sizeof(nbits) / sizeof(nbits[0]); n++) {
			run_list_parse(&digest, list_inputs[i],
				       (unsigned int)(local_len(list_inputs[i]) + 1),
				       nbits[n], 0);
			run_list_parse(&digest, list_inputs[i],
				       (unsigned int)local_len(list_inputs[i]),
				       nbits[n], 1);
		}
	}

	printf("bitmap_parse ok digest=%016lx\n", digest);
	return 0;
}
