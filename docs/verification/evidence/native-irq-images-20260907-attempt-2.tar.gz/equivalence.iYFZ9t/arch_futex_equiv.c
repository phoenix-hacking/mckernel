#include <stdio.h>
#include <stdlib.h>

#define EFAULT 14
#define ENOSYS 38
#define FUTEX_OP_SET 0
#define FUTEX_OP_ADD 1
#define FUTEX_OP_OR 2
#define FUTEX_OP_ANDN 3
#define FUTEX_OP_XOR 4
#define FUTEX_OP_OPARG_SHIFT 8
#define FUTEX_OP_CMP_EQ 0
#define FUTEX_OP_CMP_NE 1
#define FUTEX_OP_CMP_LT 2
#define FUTEX_OP_CMP_LE 3
#define FUTEX_OP_CMP_GT 4
#define FUTEX_OP_CMP_GE 5

extern int futex_atomic_cmpxchg_inatomic(int *uaddr, int oldval, int newval);
extern int futex_atomic_op_inuser(int encoded_op, int *uaddr);

static void require(int condition)
{
	if (!condition)
		exit(13);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static int encode_op(int op, int oparg, int cmp, int cmparg)
{
	unsigned int encoded = (((unsigned int)op & 0x0f) << 28) |
		(((unsigned int)cmp & 0x0f) << 24) |
		(((unsigned int)oparg & 0x0fff) << 12) |
		((unsigned int)cmparg & 0x0fff);

	return (int)encoded;
}

#ifdef USE_C_ARCH_FUTEX_MODEL
int futex_atomic_cmpxchg_inatomic(int *uaddr, int oldval, int newval)
{
	int current;

	if (!uaddr)
		return -EFAULT;
	current = *uaddr;
	if (current == oldval)
		*uaddr = newval;
	return current;
}

static int arch_futex_atomic_op_primitive(int op, int *uaddr, int oparg,
					  int *oldval)
{
	int old;

	if (!uaddr)
		return -EFAULT;

	old = *uaddr;
	switch (op) {
	case FUTEX_OP_SET:
		*uaddr = oparg;
		break;
	case FUTEX_OP_ADD:
		*uaddr = old + oparg;
		break;
	case FUTEX_OP_OR:
		*uaddr = old | oparg;
		break;
	case FUTEX_OP_ANDN:
		*uaddr = old & oparg;
		break;
	case FUTEX_OP_XOR:
		*uaddr = old ^ oparg;
		break;
	default:
		return -ENOSYS;
	}

	*oldval = old;
	return 0;
}

int futex_atomic_op_inuser(int encoded_op, int *uaddr)
{
	int op = (encoded_op >> 28) & 7;
	int cmp = (encoded_op >> 24) & 15;
	int oparg = (encoded_op & 0x00fff000) >> 12;
	int cmparg = encoded_op & 0xfff;
	int oldval = 0;
	int ret;

	if (encoded_op & (FUTEX_OP_OPARG_SHIFT << 28))
		oparg = 1 << oparg;
	if (!uaddr)
		return -EFAULT;
	if (op == FUTEX_OP_ANDN)
		oparg = ~oparg;

	ret = arch_futex_atomic_op_primitive(op, uaddr, oparg, &oldval);
	if (ret)
		return ret;

	switch (cmp) {
	case FUTEX_OP_CMP_EQ:
		return oldval == cmparg;
	case FUTEX_OP_CMP_NE:
		return oldval != cmparg;
	case FUTEX_OP_CMP_LT:
		return oldval < cmparg;
	case FUTEX_OP_CMP_GE:
		return oldval >= cmparg;
	case FUTEX_OP_CMP_LE:
		return oldval <= cmparg;
	case FUTEX_OP_CMP_GT:
		return oldval > cmparg;
	default:
		return -ENOSYS;
	}
}
#endif

int main(void)
{
	unsigned long digest = 0x6172636866757465UL;
	int value;
	int ret;

	value = 11;
	ret = futex_atomic_cmpxchg_inatomic(&value, 10, 77);
	require(ret == 11);
	require(value == 11);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	ret = futex_atomic_cmpxchg_inatomic(&value, 11, 77);
	require(ret == 11);
	require(value == 77);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 5;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_SET, 9, FUTEX_OP_CMP_EQ, 5), &value);
	require(ret == 1);
	require(value == 9);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 5;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_ADD, 7, FUTEX_OP_CMP_LT, 9), &value);
	require(ret == 1);
	require(value == 12);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 0x12;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_OR, 0x21, FUTEX_OP_CMP_NE, 0x13), &value);
	require(ret == 1);
	require(value == 0x33);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 0x3f;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_ANDN, 0x0f, FUTEX_OP_CMP_GE, 0x20),
		&value);
	require(ret == 1);
	require(value == 0x30);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 0x55;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_XOR, 0x0f, FUTEX_OP_CMP_GT, 0x60),
		&value);
	require(ret == 0);
	require(value == 0x5a);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 3;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_OPARG_SHIFT | FUTEX_OP_ADD, 3,
			  FUTEX_OP_CMP_LE, 3),
		&value);
	require(ret == 1);
	require(value == 11);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 42;
	ret = futex_atomic_op_inuser(
		encode_op(7, 5, FUTEX_OP_CMP_EQ, 42), &value);
	require(ret == -ENOSYS);
	require(value == 42);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	value = 7;
	ret = futex_atomic_op_inuser(
		encode_op(FUTEX_OP_ADD, 1, 9, 0), &value);
	require(ret == -ENOSYS);
	require(value == 8);
	mix_signed(&digest, ret);
	mix_signed(&digest, value);

	printf("arch_futex ok digest=%016lx value=%d\n", digest, value);
	return 0;
}
