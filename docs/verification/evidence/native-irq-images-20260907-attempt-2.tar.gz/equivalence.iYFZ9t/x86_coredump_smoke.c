#include <process.h>
#include <elfcore.h>

int printf(const char *fmt, ...);

extern void x86_coredump_fill_prstatus_body_result(
	struct elf_prstatus64 *prstatus, struct thread *thread, void *regs0,
	int sig, unsigned long r12, unsigned long r13, unsigned long r14,
	unsigned long r15, unsigned long fs_base, unsigned long gs_base);
extern void arch_fill_thread_core_info(struct note *head,
				       struct thread *thread, void *regs);
extern int arch_get_thread_core_info_size(void);

#define require(expr) do { if (!(expr)) return 12; } while (0)

static void fill_bytes(void *ptr, unsigned char value, unsigned long size)
{
	unsigned char *bytes = ptr;
	unsigned long i;

	for (i = 0; i < size; i++)
		bytes[i] = value;
}

static unsigned long poison64(void)
{
	return 0xa5a5a5a5a5a5a5a5UL;
}

int main(void)
{
	struct elf_prstatus64 prstatus;
	struct x86_user_context regs;
	struct thread thread;
	struct process proc;
	struct process parent;
	struct note note;

	fill_bytes(&prstatus, 0xa5, sizeof(prstatus));
	fill_bytes(&regs, 0, sizeof(regs));
	fill_bytes(&thread, 0, sizeof(thread));
	fill_bytes(&proc, 0, sizeof(proc));
	fill_bytes(&parent, 0, sizeof(parent));
	fill_bytes(&note, 0x5a, sizeof(note));

	thread.tid = 1234;
	thread.proc = &proc;
	proc.parent = &parent;
	proc.pid = 77;
	parent.pid = 55;

	regs.gpr.rbp = 0x1004;
	regs.gpr.rbx = 0x1005;
	regs.gpr.r11 = 0x1006;
	regs.gpr.r10 = 0x1007;
	regs.gpr.r9 = 0x1008;
	regs.gpr.r8 = 0x1009;
	regs.gpr.rax = 0x100a;
	regs.gpr.rcx = 0x100b;
	regs.gpr.rdx = 0x100c;
	regs.gpr.rsi = 0x100d;
	regs.gpr.rdi = 0x100e;
	regs.gpr.rip = 0x1010;
	regs.gpr.cs = 0x1011;
	regs.gpr.rflags = 0x1012;
	regs.gpr.rsp = 0x1013;
	regs.gpr.ss = 0x1014;

	x86_coredump_fill_prstatus_body_result(&prstatus, &thread, &regs, 9,
		0x1200, 0x1300, 0x1400, 0x1500, 0x2100, 0x2200);

	require(prstatus.pr_pid == 1234);
	require(prstatus.pr_ppid == 55);
	require(prstatus.pr_info.si_signo == 9);
	require(prstatus.pr_cursig == 9);
	require(prstatus.pr_reg[0] == 0x1500);
	require(prstatus.pr_reg[1] == 0x1400);
	require(prstatus.pr_reg[2] == 0x1300);
	require(prstatus.pr_reg[3] == 0x1200);
	require(prstatus.pr_reg[4] == 0x1004);
	require(prstatus.pr_reg[5] == 0x1005);
	require(prstatus.pr_reg[6] == 0x1006);
	require(prstatus.pr_reg[7] == 0x1007);
	require(prstatus.pr_reg[8] == 0x1008);
	require(prstatus.pr_reg[9] == 0x1009);
	require(prstatus.pr_reg[10] == 0x100a);
	require(prstatus.pr_reg[11] == 0x100b);
	require(prstatus.pr_reg[12] == 0x100c);
	require(prstatus.pr_reg[13] == 0x100d);
	require(prstatus.pr_reg[14] == 0x100e);
	require(prstatus.pr_reg[15] == 0x100a);
	require(prstatus.pr_reg[16] == 0x1010);
	require(prstatus.pr_reg[17] == 0x1011);
	require(prstatus.pr_reg[18] == 0x1012);
	require(prstatus.pr_reg[19] == 0x1013);
	require(prstatus.pr_reg[20] == 0x1014);
	require(prstatus.pr_reg[21] == 0x2100);
	require(prstatus.pr_reg[22] == 0x2200);
	require(prstatus.pr_reg[23] == poison64());
	require(prstatus.pr_pgrp == (int)0xa5a5a5a5U);
	require(prstatus.pr_fpvalid == 0);

	proc.parent = 0;
	prstatus.pr_ppid = 777;
	x86_coredump_fill_prstatus_body_result(&prstatus, &thread, &regs, 11,
		0x12, 0x13, 0x14, 0x15, 0x21, 0x22);
	require(prstatus.pr_ppid == 777);
	require(prstatus.pr_info.si_signo == 11);
	require(prstatus.pr_cursig == 11);

	arch_fill_thread_core_info(&note, &thread, &regs);
	require(arch_get_thread_core_info_size() == 0);
	require(note.namesz == 0x5a5a5a5aU);

	printf("x86_coredump ok pid=%d ppid=%d rip=%lx\n",
	       prstatus.pr_pid, prstatus.pr_ppid, prstatus.pr_reg[16]);
	return 0;
}
