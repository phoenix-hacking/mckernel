#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

extern int snprintf(char *, size_t, const char *, ...);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static size_t bounded_len(const char *buf, size_t max)
{
	size_t len = 0;

	while (len < max && buf[len])
		len++;
	return len;
}

static void mix_buf(unsigned long *digest, const char *buf, size_t max)
{
	size_t len = bounded_len(buf, max);

	mix(digest, len);
	for (size_t i = 0; i < len; i++)
		mix(digest, (unsigned char)buf[i]);
}

#define RUN(size_value, fmt, ...) do {					\
	char buf[96];							\
	size_t out_size = (size_value);					\
	for (size_t i = 0; i < sizeof(buf); i++)			\
		buf[i] = (char)(0x30 + (i % 10));			\
	int rc = snprintf(buf, out_size, fmt, __VA_ARGS__);		\
	mix_signed(&digest, rc);					\
	if (out_size > sizeof(buf))					\
		out_size = sizeof(buf);				\
	mix_buf(&digest, buf, out_size);				\
} while (0)

int main(void)
{
	unsigned long digest = 0xdec1a1f0cafed00dUL;

	RUN(96, "%u", 0U);
	RUN(96, "%u", 99999U);
	RUN(96, "%u", 100000U);
	RUN(96, "%u", 1234567890U);
	RUN(96, "%d", -2147483647);
	RUN(96, "%+d:% d:%08u", 17, 17, 42U);
	RUN(96, "%-12u:%12u:%.6u", 123U, 123U, 123U);
	RUN(96, "%*d:%*.*s:%.*u", 6, 42, -8, 3, "abcdef", 4, 123U);
	RUN(96, "%llu", 0xffffffffffffffffULL);
	RUN(96, "%020llu", 1234567890123456789ULL);
	RUN(96, "%lld", -9223372036854775807LL);
	RUN(96, "%#x:%#o:%llu", 0x2aU, 052U, 9876543210123ULL);
	RUN(96, "%#X:%#08x:%#-8o", 0xABCDU, 0x2aU, 052U);
	RUN(96, "%hhd:%hhu:%hd:%hu", -3, 250U, -1234, 65000U);
	RUN(96, "chars:%%:%c:%5c:%-5c:bad:%q:end", 'A', 'B', 'C', 0);
	RUN(96, "%p:%16p", (void *)(uintptr_t)0x1234,
	    (void *)(uintptr_t)0x1234);
	RUN(96, "%p:%pS:%p", (void *)0, (void *)(uintptr_t)0x5678,
	    (void *)(uintptr_t)0x9abc);
	RUN(96, "%10.3s:%-8s:%s", "abcdef", "xy", (char *)0);
	RUN(7, "%-8.5s", "abcdef");
	RUN(16, "%020llu", 1234567890123456789ULL);
	RUN(8, "%-12u", 123456U);
	RUN(1, "%u", 123456U);
	RUN(0, "%u", 123456U);

	{
		char buf[96];
		int n_int = -1;
		long n_long = -1;
		size_t n_size = (size_t)-1;
		for (size_t i = 0; i < sizeof(buf); i++)
			buf[i] = (char)(0x41 + (i % 26));
		int rc = snprintf(buf, sizeof(buf), "ab%ncd%lnef%zn/end",
				  &n_int, &n_long, &n_size);
		mix_signed(&digest, rc);
		mix_signed(&digest, n_int);
		mix_signed(&digest, n_long);
		mix(&digest, (unsigned long)n_size);
		mix_buf(&digest, buf, sizeof(buf));
	}

	{
		char text[32];
		char chars[8];
		int d = -1;
		unsigned int x = 0;
		unsigned int o = 0;
		int n = -1;
		int rc = sscanf("  -42 0xff 077 text Z",
				"%d %x %o %5s %c%n",
				&d, &x, &o, text, chars, &n);
		mix_signed(&digest, rc);
		mix_signed(&digest, d);
		mix(&digest, x + o + (unsigned long)n);
		mix_buf(&digest, text, sizeof(text));
		mix(&digest, (unsigned char)chars[0]);
	}

	{
		char text[32];
		char chars[8] = { 0 };
		int value = -1;
		int n = -1;
		int rc = sscanf("A BCD", "%2c %s%n", chars, text, &n);
		mix_signed(&digest, rc);
		mix(&digest, (unsigned char)chars[0]);
		mix(&digest, (unsigned char)chars[1]);
		mix_buf(&digest, text, sizeof(text));
		mix_signed(&digest, n);

		rc = sscanf("skip 123 done", "%*s %d %s", &value, text);
		mix_signed(&digest, rc);
		mix_signed(&digest, value);
		mix_buf(&digest, text, sizeof(text));
	}

	{
		unsigned char uc = 0;
		signed char sc = 0;
		unsigned short us = 0;
		short ss = 0;
		unsigned long long ull = 0;
		int rc = sscanf("250 -3 65000 -1234 1234567890123",
				"%hhu %hhd %hu %hd %llu",
				&uc, &sc, &us, &ss, &ull);
		mix_signed(&digest, rc);
		mix(&digest, uc);
		mix_signed(&digest, sc);
		mix(&digest, us);
		mix_signed(&digest, ss);
		mix(&digest, (unsigned long)ull);
	}

	{
		int i = 0;
		long l = 0;
		size_t z = 0;
		int n = -1;
		int rc = sscanf("0x10 -020 17", "%i %li %zu", &i, &l, &z);
		mix_signed(&digest, rc);
		mix_signed(&digest, i);
		mix_signed(&digest, l);
		mix(&digest, (unsigned long)z);
		rc = sscanf("abc", "abc%n", &n);
		mix_signed(&digest, rc);
		mix_signed(&digest, n);
	}

	printf("printf_decimal ok digest=%016lx\n", digest);
	return 0;
}
