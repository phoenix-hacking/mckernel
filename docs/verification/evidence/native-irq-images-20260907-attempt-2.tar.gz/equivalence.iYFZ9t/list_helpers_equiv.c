#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

extern void INIT_LIST_HEAD(struct list_head *list);
extern void list_add(struct list_head *new, struct list_head *head);
extern void list_add_tail(struct list_head *new, struct list_head *head);
extern void list_del(struct list_head *entry);
extern void list_del_init(struct list_head *entry);
extern void list_move(struct list_head *list, struct list_head *head);
extern void list_move_tail(struct list_head *list, struct list_head *head);
extern int list_empty(const struct list_head *head);
extern int list_empty_careful(const struct list_head *head);
extern int list_is_last(const struct list_head *list,
			const struct list_head *head);
extern int list_is_singular(const struct list_head *head);
extern void list_replace_init(struct list_head *old, struct list_head *new);
extern void list_cut_position(struct list_head *list, struct list_head *head,
			      struct list_head *entry);
extern void list_splice_init(struct list_head *list, struct list_head *head);
extern void list_splice_tail_init(struct list_head *list,
				  struct list_head *head);

#ifdef USE_C_LIST_MODEL
void INIT_LIST_HEAD(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

static void __list_add(struct list_head *new, struct list_head *prev,
		       struct list_head *next)
{
	next->prev = new;
	new->next = next;
	new->prev = prev;
	prev->next = new;
}

void list_add(struct list_head *new, struct list_head *head)
{
	__list_add(new, head, head->next);
}

void list_add_tail(struct list_head *new, struct list_head *head)
{
	__list_add(new, head->prev, head);
}

static void __list_del(struct list_head *prev, struct list_head *next)
{
	next->prev = prev;
	prev->next = next;
}

static void __list_del_entry(struct list_head *entry)
{
	__list_del(entry->prev, entry->next);
}

void list_del(struct list_head *entry)
{
	__list_del_entry(entry);
	entry->next = (void *)0x00100129;
	entry->prev = (void *)0x00200229;
}

static void list_replace(struct list_head *old, struct list_head *new)
{
	new->next = old->next;
	new->next->prev = new;
	new->prev = old->prev;
	new->prev->next = new;
}

void list_replace_init(struct list_head *old, struct list_head *new)
{
	list_replace(old, new);
	INIT_LIST_HEAD(old);
}

void list_del_init(struct list_head *entry)
{
	__list_del_entry(entry);
	INIT_LIST_HEAD(entry);
}

void list_move(struct list_head *list, struct list_head *head)
{
	__list_del_entry(list);
	list_add(list, head);
}

void list_move_tail(struct list_head *list, struct list_head *head)
{
	__list_del_entry(list);
	list_add_tail(list, head);
}

int list_empty(const struct list_head *head)
{
	return head->next == head;
}

int list_empty_careful(const struct list_head *head)
{
	struct list_head *next = head->next;
	return next == head && next == head->prev;
}

int list_is_last(const struct list_head *list, const struct list_head *head)
{
	return list->next == head;
}

int list_is_singular(const struct list_head *head)
{
	return !list_empty(head) && head->next == head->prev;
}

static void __list_cut_position(struct list_head *list, struct list_head *head,
				struct list_head *entry)
{
	struct list_head *new_first = entry->next;
	list->next = head->next;
	list->next->prev = list;
	list->prev = entry;
	entry->next = list;
	head->next = new_first;
	new_first->prev = head;
}

void list_cut_position(struct list_head *list, struct list_head *head,
		       struct list_head *entry)
{
	if (list_empty(head))
		return;
	if (list_is_singular(head) &&
	    (head->next != entry && head != entry))
		return;
	if (entry == head)
		INIT_LIST_HEAD(list);
	else
		__list_cut_position(list, head, entry);
}

static void __list_splice(const struct list_head *list,
			  struct list_head *prev, struct list_head *next)
{
	struct list_head *first = list->next;
	struct list_head *last = list->prev;

	first->prev = prev;
	prev->next = first;
	last->next = next;
	next->prev = last;
}

void list_splice_init(struct list_head *list, struct list_head *head)
{
	if (!list_empty(list)) {
		__list_splice(list, head, head->next);
		INIT_LIST_HEAD(list);
	}
}

void list_splice_tail_init(struct list_head *list, struct list_head *head)
{
	if (!list_empty(list)) {
		__list_splice(list, head->prev, head);
		INIT_LIST_HEAD(list);
	}
}
#endif

struct item {
	int value;
	struct list_head list;
};

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static struct item *entry(struct list_head *list)
{
	return (struct item *)((char *)list - offsetof(struct item, list));
}

static int digest_list(struct list_head *head)
{
	struct list_head *pos;
	int digest = 0;

	for (pos = head->next; pos != head; pos = pos->next)
		digest = digest * 10 + entry(pos)->value;
	return digest;
}

int main(void)
{
	struct list_head head;
	struct list_head cut;
	struct list_head extra;
	struct item items[8];
	struct item replacement = { .value = 9 };

	INIT_LIST_HEAD(&head);
	INIT_LIST_HEAD(&cut);
	INIT_LIST_HEAD(&extra);
	for (int i = 0; i < 8; i++) {
		items[i].value = i + 1;
		INIT_LIST_HEAD(&items[i].list);
	}
	INIT_LIST_HEAD(&replacement.list);

	require(list_empty(&head));
	require(list_empty_careful(&head));
	list_add(&items[0].list, &head);
	list_add_tail(&items[1].list, &head);
	list_add(&items[2].list, &head);
	require(digest_list(&head) == 312);
	require(list_is_last(&items[1].list, &head));

	list_move_tail(&items[2].list, &head);
	require(digest_list(&head) == 123);
	list_move(&items[1].list, &head);
	require(digest_list(&head) == 213);

	list_replace_init(&items[0].list, &replacement.list);
	require(digest_list(&head) == 293);
	require(list_empty(&items[0].list));

	list_cut_position(&cut, &head, &replacement.list);
	require(digest_list(&cut) == 29);
	require(digest_list(&head) == 3);

	list_add_tail(&items[3].list, &extra);
	list_add_tail(&items[4].list, &extra);
	list_splice_init(&extra, &head);
	require(digest_list(&head) == 453);
	require(list_empty(&extra));

	list_add_tail(&items[5].list, &extra);
	list_add_tail(&items[6].list, &extra);
	list_splice_tail_init(&extra, &head);
	require(digest_list(&head) == 45367);
	require(list_empty_careful(&extra));

	list_add_tail(&items[7].list, &extra);
	require(list_is_singular(&extra));
	list_del_init(&items[7].list);
	require(list_empty(&extra));
	list_del_init(&items[6].list);
	require(digest_list(&head) == 4536);
	list_del(&items[5].list);
	require(digest_list(&head) == 453);

	printf("list_helpers ok digest=%d cut=%d\n",
	       digest_list(&head), digest_list(&cut));
	return 0;
}
