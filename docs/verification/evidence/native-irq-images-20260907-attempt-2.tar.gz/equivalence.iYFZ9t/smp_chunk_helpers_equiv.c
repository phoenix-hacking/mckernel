#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct rb_node {
	unsigned long __rb_parent_color;
	struct rb_node *rb_right;
	struct rb_node *rb_left;
} __attribute__((aligned(sizeof(long))));

struct rb_root {
	struct rb_node *rb_node;
};

struct chunk {
	struct list_head chain;
	struct rb_node node;
	uintptr_t addr;
	size_t size;
	int numa_id;
};

#define ENOMEM 12
#define EACCES 13
#define E2BIG 7
#define EFAULT 14
#define EIO 5
#define ENOENT 2
#define EBUSY 16
#define EINVAL 22
#define ENOSPC 28
#define ENOSYS 38
#define ENAMETOOLONG 36
#define FAKE_CPUMASK_WORDS 4
#define BUILTIN_OS_STATUS_INITIAL 0
#define BUILTIN_OS_STATUS_LOADING 1
#define BUILTIN_OS_STATUS_HUNGUP 5
#define IHK_SMP_CPU_NONE 0
#define IHK_SMP_CPU_ONLINE 1
#define IHK_SMP_CPU_AVAILABLE 2
#define IHK_SMP_CPU_ASSIGNED 3
#define IHK_SMP_CPU_TO_OFFLINE 4
#define IHK_SMP_CPU_OFFLINED 5
#define IHK_SMP_CPU_TO_ONLINE 6
#define IHK_OS_DEBUG_START 0x122a00U
#define SMP_IRQ_LIST_POISON1 0x00100129UL
#define SMP_IRQ_LIST_POISON2 0x00200229UL

struct fake_cache_topology {
	struct list_head chain;
	int index;
	int padding;
	long level;
	char *type;
	long size;
	char *size_str;
	long coherency_line_size;
	long number_of_sets;
	long physical_line_partition;
	long ways_of_associativity;
	unsigned long shared_cpu_map[FAKE_CPUMASK_WORDS];
};

struct fake_cpu_topology {
	struct list_head chain;
	int cpu_number;
	int hw_id;
	long physical_package_id;
	long core_id;
	unsigned long core_siblings[FAKE_CPUMASK_WORDS];
	unsigned long thread_siblings[FAKE_CPUMASK_WORDS];
	struct list_head cache_topology_list;
};

struct fake_node_topology {
	struct list_head chain;
	int node_number;
	int padding;
	unsigned long cpumap[FAKE_CPUMASK_WORDS];
};

struct fake_smp_cpu {
	int id;
	int hw_id;
	int status;
	int padding;
	unsigned long os;
	int ikc_map_cpu;
};

struct fake_builtin_device_data {
	unsigned long lock;
	unsigned long ihk_dev;
	int status;
};

struct ihk_cpu_req {
	int *cpus;
	int num_cpus;
};

struct ihk_ikc_req {
	int *src_cpus;
	int *dst_cpus;
	int num_cpus;
};

struct ihk_mem_req {
	size_t *sizes;
	int *numa_ids;
	int num_chunks;
	int min_chunk_size;
	int max_size_ratio_all;
	int timeout;
};

struct fake_mem_chunk {
	struct list_head chain;
	size_t size;
	int numa_id;
};

struct fake_os_mem_chunk {
	struct list_head list;
	uintptr_t addr;
	size_t size;
	void *os;
	int numa_id;
};

struct fake_interrupt_handler {
	struct list_head list;
	void (*func)(unsigned long os, unsigned long os_priv,
		     unsigned long priv);
	void *priv;
	unsigned long os;
	void *os_priv;
};

struct fake_perf_param {
	unsigned int nr_extra_regs;
	unsigned long hw_event_map[3];
	unsigned long hw_cache_event_ids[2][2][2];
	unsigned long hw_cache_extra_regs[2][2][2];
	unsigned int ereg_event[4];
	unsigned int ereg_msr[4];
	unsigned long ereg_valid_mask[4];
	int ereg_idx[4];
};

struct fake_extra_reg {
	unsigned int event;
	unsigned int msr;
	unsigned long config_mask;
	unsigned long valid_mask;
	int idx;
	int extra_msr_access;
};

struct ihk_smp_collect_cache_topology_offsets {
	unsigned long cpu_cache_topology_list;
	unsigned long cache_chain;
	unsigned long cache_index;
	unsigned long cache_level;
	unsigned long cache_type;
	unsigned long cache_size;
	unsigned long cache_size_str;
	unsigned long cache_coherency_line_size;
	unsigned long cache_number_of_sets;
	unsigned long cache_physical_line_partition;
	unsigned long cache_ways_of_associativity;
	unsigned long cache_shared_cpu_map;
};

struct ihk_smp_collect_cpu_topology_offsets {
	unsigned long cpu_chain;
	unsigned long cpu_number;
	unsigned long hw_id;
	unsigned long physical_package_id;
	unsigned long core_id;
	unsigned long core_siblings;
	unsigned long thread_siblings;
	unsigned long cache_topology_list;
};

struct ihk_smp_collect_node_topology_offsets {
	unsigned long node_chain;
	unsigned long node_number;
	unsigned long cpumap;
};

struct ihk_smp_arch_symbol_slots {
	unsigned long *real_mode_header;
	unsigned long *vector_irq;
	unsigned long *lapic_get_maxlvt;
	unsigned long *irq_desc_tree;
	unsigned long *get_uv_system_type;
	unsigned long *init_deasserted;
	unsigned long *alloc_desc;
	unsigned long *default_send_ipi_dest_field;
	unsigned long *init_level4_pgt;
	unsigned long *used_vectors;
};

struct ihk_smp_symbol_slots {
	unsigned long *ioremap_page_range;
	unsigned long *vmap_area_lock;
	unsigned long *vmap_area_root;
	unsigned long *insert_vmap_area;
	unsigned long *free_vmap_area_old;
	unsigned long *alloc_vmap_area;
	unsigned long *free_vmap_area_new;
	unsigned long *unmap_kernel_range_noflush;
	unsigned long *raised_list;
	unsigned long *hstates;
	unsigned long *default_hstate_idx;
};

struct fake_mem_info {
	int n_available;
	int n_fixed;
	int n_mappable;
	void *available;
	void *fixed;
	void *mappable;
	int n_numa_nodes;
	void *numa_mapping;
};

struct fake_cpu_info {
	int n_cpus;
	void *mapping;
};

struct fake_os_data {
	int lock;
	void *dev;
	struct fake_mem_info mem_info;
	struct fake_cpu_info cpu_info;
	char kernel_args[32];
	int nr_numa_nodes;
	int nr_cpus;
	int cpu_mapping[8];
	int bootstrap_numa_id;
	void *boot_pt;
	int status;
	int cpu_ikc_mapped;
	unsigned long mem_start;
	unsigned long mem_end;
	unsigned long boot_rip;
};

struct fake_trampoline_os {
	void *param;
	unsigned long boot_rip;
};

struct fake_trampoline_param {
	unsigned long linux_kernel_pgt_phys;
	unsigned long page_offset_base;
	void *ihk_ikc_cpu_raised_list[8];
	void *ikc_irq_work_func;
	unsigned int ihk_ikc_irq;
	unsigned int ihk_ikc_irq_apicids[8];
};

struct fake_trampoline_header {
	unsigned long reserved;
	unsigned long page_table;
	unsigned long next_ip;
	unsigned long stack_ptr;
	unsigned long notify_address;
};

struct fake_startup_os {
	void *boot_pt;
	unsigned long bootstrap_mem_end;
	unsigned long boot_rip;
};

struct fake_device_data {
	int lock;
	void *ihk_dev;
	int status;
};

struct fake_register_os_data {
	char *name;
	void *ops;
	void *priv;
	int flag;
};

struct ihk_smp_control_offsets {
	unsigned long os_lock;
	unsigned long os_dev;
	unsigned long os_mem_info;
	unsigned long os_cpu_info;
	unsigned long os_kernel_args;
	unsigned long os_nr_numa_nodes;
	unsigned long os_nr_cpus;
	unsigned long os_bootstrap_numa_id;
	unsigned long os_boot_pt;
	unsigned long os_status;
	unsigned long mem_info_n_numa_nodes;
	unsigned long regdata_priv;
	unsigned long dev_status;
	unsigned long os_cpu_mapping;
	unsigned long os_mem_start;
	unsigned long os_mem_end;
	unsigned long os_boot_rip;
};

struct ihk_smp_cpu_req_offsets {
	unsigned long cpus;
	unsigned long num_cpus;
};

struct ihk_smp_ikc_req_offsets {
	unsigned long src_cpus;
	unsigned long dst_cpus;
	unsigned long num_cpus;
};

struct ihk_smp_set_ikc_map_offsets {
	unsigned long os_lock;
	unsigned long os_status;
	unsigned long os_cpu_ikc_mapped;
	unsigned long req_src_cpus;
	unsigned long req_dst_cpus;
	unsigned long req_num_cpus;
	unsigned long cpu_status;
	unsigned long cpu_os;
	unsigned long cpu_ikc_map_cpu;
};

struct ihk_smp_mem_req_offsets {
	unsigned long sizes;
	unsigned long numa_ids;
	unsigned long num_chunks;
	unsigned long min_chunk_size;
	unsigned long max_size_ratio_all;
};

struct ihk_smp_mem_query_offsets {
	unsigned long list_next;
	unsigned long entry_list;
	unsigned long entry_size;
	unsigned long entry_numa_id;
	unsigned long entry_os;
};

struct ihk_smp_map_virtual_list_offsets {
	unsigned long list_next;
	unsigned long entry_list;
	unsigned long entry_addr;
	unsigned long entry_size;
};

struct ihk_smp_setup_trampoline_offsets {
	unsigned long os_param;
	unsigned long os_boot_rip;
	unsigned long param_ihk_ikc_irq_apicids;
	unsigned long param_ihk_ikc_irq_apicid_stride;
	unsigned long param_ihk_ikc_cpu_raised_list;
	unsigned long param_ihk_ikc_cpu_raised_list_stride;
	unsigned long param_ikc_irq_work_func;
	unsigned long param_ihk_ikc_irq;
	unsigned long param_page_offset_base;
	unsigned long param_linux_kernel_pgt_phys;
	unsigned long header_page_table;
	unsigned long header_next_ip;
	unsigned long header_notify_address;
};

struct ihk_smp_setup_startup_offsets {
	unsigned long os_boot_pt;
	unsigned long os_bootstrap_mem_end;
	unsigned long os_boot_rip;
};

struct ihk_smp_topology_lookup_offsets {
	unsigned long list_next;
	unsigned long cpu_chain;
	unsigned long cpu_cpu_number;
	unsigned long cpu_hw_id;
	unsigned long node_chain;
	unsigned long node_node_number;
};

struct ihk_smp_free_info_offsets {
	unsigned long list_next;
	unsigned long cpu_chain;
	unsigned long cpu_cache_topology_list;
	unsigned long cache_chain;
	unsigned long cache_type;
	unsigned long cache_size_str;
	unsigned long node_chain;
};

struct ihk_smp_interrupt_handler_offsets {
	unsigned long list_next;
	unsigned long handler_list;
	unsigned long handler_func;
	unsigned long handler_priv;
	unsigned long handler_os;
	unsigned long handler_os_priv;
};

extern void rb_insert_color(struct rb_node *node, struct rb_root *root);
extern void rb_erase(struct rb_node *node, struct rb_root *root);
extern struct rb_node *rb_next(const struct rb_node *node);
extern struct rb_node *rb_prev(const struct rb_node *node);
extern struct rb_node *rb_first(const struct rb_root *root);

extern int ihk_smp_cache_sysfs_prefix_result(char *, long, int, int);
extern int ihk_smp_cpu_sysfs_prefix_result(char *, long, int);
extern int ihk_smp_snprintf_overflow_result(int, int);
extern long ihk_smp_cache_size_bytes_result(long);
extern int ihk_smp_collect_cache_topology_body_result(
	void *cpu_topo, int index, int cpu_number, int nr_cpumask_bits,
	size_t cache_topology_size, size_t path_max,
	const struct ihk_smp_collect_cache_topology_offsets *offsets,
	void *(*alloc_fn)(size_t),
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*file_readable_fn)(const char *, const char *),
	int (*read_long_fn)(long *, const char *, const char *),
	int (*read_string_fn)(char **, const char *, const char *),
	int (*read_bitmap_fn)(void *, int, const char *, const char *),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int));
extern int ihk_smp_collect_cpu_topology_body_result(
	int cpu, int nr_cpumask_bits, size_t cpu_topology_size,
	size_t path_max, void *cpu_topology_list_head,
	const struct ihk_smp_collect_cpu_topology_offsets *offsets,
	void *(*alloc_fn)(size_t),
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*read_long_fn)(long *, const char *, const char *),
	int (*read_bitmap_fn)(void *, int, const char *, const char *),
	void (*init_list_head_fn)(void *),
	int (*get_hw_id_fn)(int),
	int (*collect_cache_fn)(void *, int),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int));
extern int ihk_smp_collect_node_topology_body_result(
	int node, int nr_cpumask_bits, size_t node_topology_size,
	void *node_topology_list_head,
	const struct ihk_smp_collect_node_topology_offsets *offsets,
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*read_node_cpumap_fn)(void *, int, int),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int));
extern int ihk_smp_collect_topology_body_result(
	int (*next_cpu_fn)(int),
	int (*collect_cpu_fn)(int),
	int (*next_node_fn)(int),
	int (*collect_node_fn)(int),
	void (*log_fn)(int, int));
extern int ihk_smp_arch_symbols_init_body_result(
	const struct ihk_smp_arch_symbol_slots *slots,
	unsigned long (*lookup_fn)(const char *),
	int (*warn_fn)(int));
extern int ihk_smp_symbols_init_body_result(
	const struct ihk_smp_symbol_slots *slots, int use_old_vmap_api,
	int use_linux_work_irq, unsigned long (*lookup_fn)(const char *),
	int (*warn_fn)(int));
extern int ihk_smp_os_notify_hungup_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long));
extern unsigned long ihk_smp_os_get_memory_info_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets);
extern unsigned long ihk_smp_os_get_cpu_info_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets);
extern int ihk_smp_os_get_num_numa_nodes_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets);
extern int ihk_smp_os_get_num_cpus_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets);
extern int ihk_smp_os_set_kargs_body_result(
	unsigned long os, const char *args,
	const struct ihk_smp_control_offsets *offsets,
	unsigned long kernel_args_len,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	void (*log_fn)(int, const char *));
extern long ihk_smp_os_debug_request_body_result(
	unsigned long ihk_os, unsigned long priv_data, unsigned int req,
	unsigned long arg, unsigned int start_req,
	int (*issue_interrupt_fn)(unsigned long, unsigned long, int, int));
extern int ihk_smp_os_freeze_thaw_body_result(
	unsigned long ihk_os, unsigned long priv_data, int mode,
	int (*send_multi_intr_fn)(unsigned long, unsigned long, int));
extern int ihk_smp_create_os_body_result(
	unsigned long device_data, unsigned long ihk_os, unsigned long regdata,
	unsigned long builtin_regdata,
	const struct ihk_smp_control_offsets *offsets,
	unsigned long regdata_size, unsigned long os_size,
	void *(*alloc_fn)(unsigned long),
	void (*spin_init_fn)(unsigned long),
	void (*log_fn)(int));
extern int ihk_smp_destroy_os_body_result(
	unsigned long os_priv, void (*free_fn)(unsigned long));
extern long ihk_smp_device_debug_request_body_result(void);
extern unsigned long ihk_smp_get_dma_channel_body_result(
	unsigned long dev, unsigned long priv_data, int channel);
extern int ihk_smp_unmap_virtual_body_result(
	unsigned long virt, void (*unmap_fn)(unsigned long));
extern void ihk_smp_direct_unmap_virtual_body_result(
	unsigned long virt, unsigned long page_size,
	void (*flush_fn)(unsigned long, unsigned long));
extern unsigned long ihk_smp_map_virtual_body_result(
	unsigned long ihk_dev, unsigned long phys, unsigned long size,
	unsigned long virt, int flags,
	unsigned long (*direct_map_fn)(unsigned long, unsigned long),
	unsigned long (*host_map_fn)(unsigned long, unsigned long,
				     unsigned long, unsigned long, int),
	void (*log_fn)(int, unsigned long, unsigned long));
extern unsigned long ihk_smp_direct_map_virtual_body_result(
	unsigned long list_head, unsigned long phys, unsigned long size,
	const struct ihk_smp_map_virtual_list_offsets *offsets,
	unsigned long (*phys_to_virt_fn)(unsigned long));
extern int ihk_smp_get_buildid_body_result(
	unsigned long user_addr, const char *buildid, unsigned long buildid_len,
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long));
extern int ihk_smp_os_vtop_body_result(
	unsigned long bootstrap_mem_start, unsigned long virt,
	unsigned long *phys, unsigned long map_start, unsigned long map_end,
	unsigned long large_page, unsigned long large_page_mask,
	unsigned long (*virt_to_phys_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long));
extern int ihk_smp_os_load_mem_body_result(
	unsigned long os, int has_cpu, unsigned long mem_start,
	unsigned long mem_end, const char *buf, unsigned long size,
	long offset, const struct ihk_smp_control_offsets *offsets,
	unsigned long page_size, unsigned long page_mask,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	unsigned long (*map_fn)(unsigned long, unsigned long),
	void (*copy_fn)(unsigned long, const char *, unsigned long),
	void (*unmap_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long,
		       unsigned long, unsigned long));
extern int ihk_smp_interrupt_cpu_valid_result(int cpu, int nr_cpus);
extern unsigned long ihk_smp_adjust_entry_body_result(unsigned long entry,
						      unsigned long phys);
extern unsigned long ihk_smp_identity_map_memory_body_result(
	unsigned long remote_phys);
extern int ihk_smp_identity_unmap_memory_body_result(void);
extern int ihk_smp_arch_dcache_flush_body_result(unsigned long addr,
						 unsigned long len);
extern int ihk_smp_setup_warm_reset_vector_body_result(
	unsigned long start_eip, unsigned long trampoline_phys_high,
	unsigned long trampoline_phys_low,
	unsigned long (*lock_fn)(void),
	void (*cmos_write_fn)(unsigned char, unsigned char),
	void (*unlock_fn)(unsigned long), void (*flush_tlb_fn)(void),
	void (*write_word_fn)(unsigned long, unsigned short));
extern int ihk_smp_setup_trampoline_body_result(
	unsigned long os, int nr_cpu_ids,
	const struct ihk_smp_setup_trampoline_offsets *offsets,
	int linux_work_irq_enabled, unsigned int linux_work_irq_vector,
	unsigned int smp_irq, unsigned long page_offset_base,
	unsigned long init_level4_pgt, unsigned long linux_kernel_pgt_phys,
	int using_linux_trampoline, unsigned long trampoline_va,
	unsigned long linux_trampoline_backup, unsigned long trampoline_data,
	unsigned long trampoline_size, unsigned long ident_page_table,
	unsigned long param_phys, unsigned long ikc_irq_work_func,
	unsigned int (*apicid_fn)(int),
	unsigned long (*raised_list_phys_fn)(int),
	void (*log_fn)(int, unsigned long, unsigned long));
extern int ihk_smp_os_setup_startup_body_result(
	unsigned long os, unsigned long phys, unsigned long entry,
	const struct ihk_smp_setup_startup_offsets *offsets,
	unsigned long identity_len, unsigned long large_page,
	unsigned long large_page_mask, unsigned long map_st_start,
	unsigned long map_kernel_start, unsigned long kernel_map_len,
	unsigned long page_size, unsigned int ptl2_shift,
	unsigned long startup_data, unsigned long startup_data_len,
	unsigned long trampoline_phys, unsigned long (*alloc_page_fn)(void),
	unsigned long (*page_phys_fn)(unsigned long),
	int (*map_kernel_fn)(unsigned long, unsigned long, unsigned long),
	unsigned long (*map_virtual_fn)(unsigned long, unsigned long),
	void (*unmap_virtual_fn)(unsigned long),
	void (*log_fn)(int));
extern int ihk_smp_arch_init_trampoline_body_result(
	unsigned long preallocated_phys, unsigned long page_size,
	unsigned int trampoline_order, int max_attempts,
	unsigned long trampoline_size, unsigned long trampoline_limit,
	unsigned long (*linux_trampoline_phys_fn)(void),
	unsigned long *trampoline_page_slot,
	unsigned long *trampoline_phys_slot,
	unsigned long *trampoline_va_slot,
	int *using_linux_trampoline_slot,
	unsigned long (*ioremap_fn)(unsigned long, unsigned long),
	unsigned long (*alloc_fn)(void),
	unsigned long (*page_phys_fn)(unsigned long),
	unsigned long (*page_virt_fn)(unsigned long),
	void (*free_fn)(unsigned long, unsigned int),
	unsigned long (*direct_virt_fn)(unsigned long),
	void (*log_fn)(int, unsigned long));
extern int ihk_smp_arch_init_linux_work_tail_body_result(
	int linux_work_irq_vector, int (*init_ident_page_table_fn)(void),
	int (*collect_topology_fn)(void), void (*log_fn)(int, int));
extern int ihk_smp_init_ident_page_table_body_result(
	unsigned long maxmem, unsigned long page_size, unsigned int pud_shift,
	unsigned int pmd_shift, int ptrs_per_pud, int ptrs_per_pmd,
	unsigned long first_level_flags, unsigned long leaf_flags,
	unsigned long *ident_page_table_slot,
	unsigned long *ident_page_table_virt_slot,
	int *ident_npages_order_slot,
	unsigned long (*alloc_pages_fn)(unsigned int),
	unsigned long (*page_phys_fn)(unsigned long),
	unsigned long (*page_virt_fn)(unsigned long),
	void (*zero_fn)(unsigned long, unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long));
extern int ihk_smp_reset_cpu_body_result(
	int phys_apicid, int apic_esr, unsigned int assert_init_value,
	unsigned int deassert_init_value, void (*preempt_disable_fn)(void),
	void (*preempt_enable_fn)(void), int (*get_maxlvt_fn)(void),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	void (*icr_write_fn)(unsigned int, int),
	unsigned long (*wait_icr_idle_fn)(void),
	void (*delay_fn)(unsigned long), void (*log_fn)(int, int));
extern int ihk_smp_wakeup_secondary_cpu_via_init_body_result(
	int phys_apicid, unsigned long start_eip, int apic_esr,
	unsigned int assert_init_value, unsigned int deassert_init_value,
	unsigned int startup_value, int (*get_maxlvt_fn)(void),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	void (*icr_write_fn)(unsigned int, int),
	unsigned long (*wait_icr_idle_fn)(void),
	void (*mdelay_fn)(unsigned long),
	void (*udelay_fn)(unsigned long), void (*barrier_fn)(void),
	void (*init_deasserted_fn)(void),
	void (*log_fn)(int, unsigned long));
extern int ihk_smp_wakeup_secondary_cpu_body_result(
	int apicid, unsigned long start_eip, int boot_cpu_physical_apicid,
	int apic_esr, void (*clear_init_deasserted_fn)(void),
	int (*non_unique_apic_fn)(void),
	void (*setup_warm_reset_vector_fn)(unsigned long),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	int (*apic_wakeup_available_fn)(void),
	int (*apic_wakeup_fn)(int, unsigned long),
	void (*preempt_disable_fn)(void),
	int (*via_init_fn)(int, unsigned long),
	void (*preempt_enable_fn)(void), void (*log_fn)(int));
extern int ihk_smp_arch_exit_body_result(
	unsigned long trampoline_page, int using_linux_trampoline,
	unsigned long trampoline_va, unsigned int trampoline_order,
	unsigned long ident_page_table_virt, unsigned int ident_npages_order,
	void (*free_trampoline_fn)(unsigned long, unsigned int),
	void (*unmap_fn)(unsigned long),
	void (*free_pages_fn)(unsigned long, unsigned int));
extern unsigned long ihk_smp_calc_ns_per_tsc_body_result(
	int invariant_tsc, unsigned int ratio, unsigned long tsc_khz);
extern unsigned long ihk_smp_x2apic_is_enabled_body_result(
	unsigned long msr);
extern int ihk_smp_vector_entry_used_result(unsigned long entry,
					    unsigned long unused);
extern int ihk_smp_vector_set_needed_result(unsigned long entry,
					    unsigned long unused);
extern unsigned long ihk_smp_vector_release_value_result(
	unsigned long unused);
extern int ihk_smp_os_issue_interrupt_body_result(
	int cpu, int nr_cpus, const int *hw_ids, int vector,
	int apic_dest_physical,
	unsigned long (*irq_save_fn)(void),
	void (*irq_restore_fn)(unsigned long),
	int (*x2apic_enabled_fn)(void),
	void (*x2apic_write_fn)(int, int),
	void (*legacy_ipi_fn)(int, int, int));
extern int ihk_smp_os_broadcast_interrupt_body_result(
	unsigned long ihk_os, unsigned long priv_data, int mode, int nr_cpus,
	const int *hw_ids, int x2apic_vector, int legacy_vector,
	int apic_dest_physical, int wrap_irq, int wait_x2apic,
	int (*set_mode_fn)(unsigned long, unsigned long, int),
	unsigned long (*irq_save_fn)(void),
	void (*irq_restore_fn)(unsigned long),
	int (*x2apic_enabled_fn)(void),
	void (*x2apic_wait_fn)(void),
	void (*x2apic_write_fn)(int, int),
	void (*legacy_ipi_fn)(int, int, int));
extern int ihk_smp_check_ikc_map_body_result(void);
extern int ihk_smp_ikc_irq_work_body_result(
	int (*handler_fn)(int, void *));
extern int ihk_smp_init_body_result(
	unsigned long free_list_head, unsigned long used_list_head,
	unsigned long list_next_offset, int ihk_cores, int present_cpus,
	unsigned long cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long status_offset, int online_status,
	void (*zero_fn)(unsigned long, unsigned long),
	int (*online_cpu_fn)(unsigned long, void (*)(unsigned long, int)),
	int (*arch_init_fn)(void), unsigned long fake_chunks,
	unsigned long fake_chunks_size, void (*log_fn)(int));
extern int ihk_smp_exit_body_result(
	unsigned long cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_id_offset, unsigned long cpu_hw_id_offset,
	unsigned long cpu_status_offset, unsigned long free_list_head,
	void (*arch_exit_fn)(void), int (*reset_cpu_fn)(int),
	int (*online_cpu_fn)(int), int (*free_list_fn)(unsigned long),
	void (*free_info_fn)(void), void (*log_fn)(int, int));
extern int ihk_smp_module_init_body_result(
	unsigned long builtin_data, unsigned long ihk_dev_offset,
	unsigned long lock_offset, unsigned long reg_data,
	int (*symbols_init_fn)(void), int (*arch_symbols_init_fn)(void),
	void (*spin_lock_init_fn)(unsigned long),
	unsigned long (*register_device_fn)(unsigned long),
	void (*log_fn)(int));
extern int ihk_smp_module_exit_body_result(
	unsigned long builtin_data, unsigned long ihk_dev_offset,
	void (*unregister_device_fn)(unsigned long), void (*log_fn)(int));
extern int ihk_smp_os_register_handler_body_result(
	unsigned long os, unsigned long os_priv, unsigned long handler,
	unsigned long list_head,
	const struct ihk_smp_interrupt_handler_offsets *offsets);
extern int ihk_smp_os_unregister_handler_body_result(
	unsigned long handler,
	const struct ihk_smp_interrupt_handler_offsets *offsets,
	unsigned long poison_next, unsigned long poison_prev);
extern int ihk_smp_irq_call_handlers_body_result(
	unsigned long list_head,
	const struct ihk_smp_interrupt_handler_offsets *offsets,
	int irq_handled, void (*log_no_handler_fn)(void));
struct ihk_smp_perf_offsets {
	unsigned long nr_extra_regs;
	unsigned long hw_event_map;
	unsigned long hw_cache_event_ids;
	unsigned long hw_cache_extra_regs;
	unsigned long ereg_event;
	unsigned long ereg_msr;
	unsigned long ereg_valid_mask;
	unsigned long ereg_idx;
	unsigned long extra_event;
	unsigned long extra_msr;
	unsigned long extra_valid_mask;
	unsigned long extra_idx;
	unsigned long extra_stride;
};
extern int ihk_smp_arch_get_perf_event_map_body_result(
	unsigned long param, unsigned long extra_regs,
	unsigned long hw_event_map, unsigned long hw_cache_event_ids,
	unsigned long hw_cache_extra_regs,
	const struct ihk_smp_perf_offsets *offsets,
	unsigned long max_extra_regs, unsigned long hw_event_map_bytes,
	unsigned long hw_cache_event_ids_bytes,
	unsigned long hw_cache_extra_regs_bytes,
	void (*log_fn)(int, int));
extern int ihk_smp_device_get_num_cpus_body_result(
	const void *cpus, int cpu_count, unsigned long stride,
	unsigned long status_offset, int available_status);
extern int ihk_smp_device_query_cpu_body_result(
	unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_cpu_req_offsets *req_offsets,
	const void *cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_status_offset, int available_status,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int));
extern int ihk_smp_os_query_cpu_body_result(
	unsigned long os, unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_cpu_req_offsets *req_offsets,
	const struct ihk_smp_control_offsets *os_offsets,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int));
extern int ihk_smp_os_get_ikc_map_body_result(
	unsigned long ihk_os, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	const struct ihk_smp_ikc_req_offsets *req_offsets,
	const void *cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_status_offset, unsigned long cpu_os_offset,
	unsigned long cpu_ikc_offset, int assigned_status,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int));
extern int ihk_smp_os_set_ikc_map_body_result(
	unsigned long ihk_os, unsigned long os, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	char *req_string, long req_string_len,
	const struct ihk_smp_set_ikc_map_offsets *offsets,
	void *cpus, int cpu_count, unsigned long cpu_stride,
	int assigned_status, int initial_status, unsigned long int_size,
	int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	int (*cpu_present_fn)(int),
	int (*cpu_online_fn)(int),
	int (*check_ikc_map_fn)(unsigned long),
	void (*log_fn)(int, int, int));
extern int ihk_smp_query_mem_body_result(
	unsigned long list_head, unsigned long target_os, int filter_os,
	int require_exact, const unsigned long *fake_chunks,
	unsigned long fake_count, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	const struct ihk_smp_mem_req_offsets *req_offsets,
	const struct ihk_smp_mem_query_offsets *query_offsets,
	unsigned long size_elem, unsigned long int_size,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int));
extern unsigned long ihk_smp_get_cpu_topology_body_result(
	unsigned long list_head, int hw_id,
	const struct ihk_smp_topology_lookup_offsets *offsets);
extern unsigned long ihk_smp_get_node_topology_body_result(
	unsigned long list_head, int node, int nr_nodes,
	unsigned long einval_ptr,
	const struct ihk_smp_topology_lookup_offsets *offsets);
extern int ihk_smp_linux_cpu_to_hw_id_body_result(
	unsigned long list_head, int cpu,
	const struct ihk_smp_topology_lookup_offsets *offsets);
extern int ihk_smp_free_info_body_result(
	unsigned long cpu_list_head, unsigned long node_list_head,
	const struct ihk_smp_free_info_offsets *offsets,
	void (*list_del_fn)(unsigned long), void (*free_fn)(unsigned long),
	void (*log_fn)(int));
extern int ihk_smp_read_long_body_result(
	unsigned long valuep, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	int (*parse_long_fn)(unsigned long, unsigned long),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, char *, int));
extern int ihk_smp_read_bitmap_body_result(
	unsigned long map, int nbits, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	int (*bitmap_parse_fn)(unsigned long, unsigned long, unsigned long,
			       int),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, int, char *, int));
extern int ihk_smp_read_string_body_result(
	unsigned long valuep, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	unsigned long (*kstrdup_fn)(unsigned long),
	void (*kfree_fn)(unsigned long),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, char *, int));
extern int ihk_smp_file_readable_body_result(
	char *fmt, unsigned long va_list, unsigned long path_max,
	void *(*alloc_fn)(unsigned long),
	int (*vsnprintf_fn)(char *, unsigned long, char *, unsigned long),
	unsigned long (*open_fn)(char *),
	void (*close_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int));
extern int ihk_smp_read_file_body_result(
	unsigned long buf, unsigned long size, char *fmt, unsigned long va_list,
	unsigned long path_max, void *(*alloc_fn)(unsigned long),
	int (*vsnprintf_fn)(char *, unsigned long, char *, unsigned long),
	unsigned long (*open_fn)(char *, unsigned long),
	long (*kernel_read_fn)(unsigned long, unsigned long, unsigned long),
	int (*close_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long, char *, int));
extern int ihk_smp_write_cpu_sys_file_body_result(
	int cpu_id, const char *val, char *path, size_t path_size,
	unsigned long (*open_fn)(char *, unsigned long),
	long (*write_fn)(unsigned long, const char *, unsigned long),
	int (*close_fn)(unsigned long),
	void (*log_fn)(int, const char *, int));

#define container_of(ptr, type, member) \
	((type *)((char *)(ptr) - offsetof(type, member)))

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 1; \
	} \
} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) +
		(*digest >> 2);
}

static void rb_link_node_local(struct rb_node *node, struct rb_node *parent,
			       struct rb_node **link)
{
	node->__rb_parent_color = (unsigned long)parent;
	node->rb_left = NULL;
	node->rb_right = NULL;
	*link = node;
}

static struct rb_node *rb_first_bridge(const struct rb_root *root)
{
	return rb_first(root);
}

static struct rb_node *rb_next_bridge(const struct rb_node *node)
{
	return rb_next(node);
}

static struct rb_node *rb_prev_bridge(const struct rb_node *node)
{
	return rb_prev(node);
}

static void rb_erase_bridge(struct rb_node *node, struct rb_root *root)
{
	rb_erase(node, root);
}

static void rb_link_node_bridge(struct rb_node *node, struct rb_node *parent,
				struct rb_node **link)
{
	rb_link_node_local(node, parent, link);
}

static void rb_insert_color_bridge(struct rb_node *node, struct rb_root *root)
{
	rb_insert_color(node, root);
}

#ifdef USE_C_SMP_CHUNK_MODEL
int ihk_smp_cache_sysfs_prefix_result(char *buf, long len, int cpu, int index)
{
	return snprintf(buf, len,
			"/sys/devices/system/cpu/cpu%d/cache/index%d",
			cpu, index);
}

int ihk_smp_cpu_sysfs_prefix_result(char *buf, long len, int cpu)
{
	return snprintf(buf, len, "/sys/devices/system/cpu/cpu%d", cpu);
}

int ihk_smp_cpu_online_path_result(char *buf, long len, int cpu)
{
	return snprintf(buf, len, "/sys/devices/system/cpu/cpu%d/online", cpu);
}

int ihk_smp_snprintf_overflow_result(int n, int limit)
{
	return n >= limit;
}

long ihk_smp_cache_size_bytes_result(long size_kb)
{
	return size_kb * 1024;
}

int ihk_smp_ikc_irq_work_body_result(int (*handler_fn)(int, void *))
{
	if (!handler_fn)
		return -EINVAL;
	return handler_fn(0, NULL);
}

static void smp_init_model_list_head(struct list_head *head)
{
	head->next = head;
	head->prev = head;
}

static void smp_init_model_mark_online(unsigned long ctx, int cpu)
{
	struct {
		unsigned long cpus;
		int cpu_count;
		unsigned long cpu_stride;
		unsigned long status_offset;
		int online_status;
	} *cpu_ctx = (void *)ctx;
	char *entry;

	if (!cpu_ctx || cpu < 0 || cpu >= cpu_ctx->cpu_count)
		return;

	entry = (char *)cpu_ctx->cpus + (cpu_ctx->cpu_stride * cpu);
	*(int *)(entry + cpu_ctx->status_offset) = cpu_ctx->online_status;
}

int ihk_smp_init_body_result(
	unsigned long free_list_head, unsigned long used_list_head,
	unsigned long list_next_offset, int ihk_cores, int present_cpus,
	unsigned long cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long status_offset, int online_status,
	void (*zero_fn)(unsigned long, unsigned long),
	int (*online_cpu_fn)(unsigned long, void (*)(unsigned long, int)),
	int (*arch_init_fn)(void), unsigned long fake_chunks,
	unsigned long fake_chunks_size, void (*log_fn)(int))
{
	struct {
		unsigned long cpus;
		int cpu_count;
		unsigned long cpu_stride;
		unsigned long status_offset;
		int online_status;
	} cpu_ctx;
	int ret;

	(void)list_next_offset;
	if (!free_list_head || !used_list_head || !cpus || cpu_count < 0)
		return -EINVAL;

	smp_init_model_list_head((struct list_head *)free_list_head);
	smp_init_model_list_head((struct list_head *)used_list_head);

	if (ihk_cores && ihk_cores > present_cpus - 1) {
		if (log_fn)
			log_fn(present_cpus);
		return EINVAL;
	}

	if (zero_fn)
		zero_fn(cpus, cpu_stride * (unsigned long)cpu_count);

	cpu_ctx.cpus = cpus;
	cpu_ctx.cpu_count = cpu_count;
	cpu_ctx.cpu_stride = cpu_stride;
	cpu_ctx.status_offset = status_offset;
	cpu_ctx.online_status = online_status;
	if (online_cpu_fn)
		(void)online_cpu_fn((unsigned long)&cpu_ctx,
				    smp_init_model_mark_online);

	ret = arch_init_fn ? arch_init_fn() : 0;

	if (fake_chunks && fake_chunks_size && zero_fn)
		zero_fn(fake_chunks, fake_chunks_size);

	return ret;
}

int ihk_smp_exit_body_result(
	unsigned long cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_id_offset, unsigned long cpu_hw_id_offset,
	unsigned long cpu_status_offset, unsigned long free_list_head,
	void (*arch_exit_fn)(void), int (*reset_cpu_fn)(int),
	int (*online_cpu_fn)(int), int (*free_list_fn)(unsigned long),
	void (*free_info_fn)(void), void (*log_fn)(int, int))
{
	int cpu;
	int ret = 0;

	if (!cpus || cpu_count < 0 || !free_list_head || !arch_exit_fn ||
	    !reset_cpu_fn || !online_cpu_fn || !free_list_fn || !free_info_fn)
		return -EINVAL;

	arch_exit_fn();

	for (cpu = 0; cpu < cpu_count; cpu++) {
		char *entry = (char *)cpus + cpu_stride * (unsigned long)cpu;
		int status = *(int *)(entry + cpu_status_offset);
		int hw_id;

		if (status == IHK_SMP_CPU_ONLINE || status == IHK_SMP_CPU_NONE)
			continue;

		hw_id = *(int *)(entry + cpu_hw_id_offset);
		ret = reset_cpu_fn(hw_id);
		if (online_cpu_fn(cpu) == 0 && log_fn) {
			int id = *(int *)(entry + cpu_id_offset);
			log_fn(id, hw_id);
		}
	}

	(void)free_list_fn(free_list_head);
	free_info_fn();
	return ret;
}

int ihk_smp_module_init_body_result(
	unsigned long builtin_data, unsigned long ihk_dev_offset,
	unsigned long lock_offset, unsigned long reg_data,
	int (*symbols_init_fn)(void), int (*arch_symbols_init_fn)(void),
	void (*spin_lock_init_fn)(unsigned long),
	unsigned long (*register_device_fn)(unsigned long),
	void (*log_fn)(int))
{
	unsigned long ihkd;
	int ret;

	if (!builtin_data || !reg_data || !symbols_init_fn ||
	    !arch_symbols_init_fn || !spin_lock_init_fn ||
	    !register_device_fn)
		return -EINVAL;

	if (log_fn)
		log_fn(0);

	ret = symbols_init_fn();
	if (ret)
		return ret;

	ret = arch_symbols_init_fn();
	if (ret)
		return ret;

	spin_lock_init_fn(builtin_data + lock_offset);

	ihkd = register_device_fn(reg_data);
	if (!ihkd) {
		if (log_fn)
			log_fn(1);
		return -ENOMEM;
	}

	*(unsigned long *)(builtin_data + ihk_dev_offset) = ihkd;
	return 0;
}

int ihk_smp_module_exit_body_result(
	unsigned long builtin_data, unsigned long ihk_dev_offset,
	void (*unregister_device_fn)(unsigned long), void (*log_fn)(int))
{
	if (!builtin_data || !unregister_device_fn)
		return -EINVAL;

	if (log_fn)
		log_fn(2);

	unregister_device_fn(*(unsigned long *)(builtin_data + ihk_dev_offset));
	return 0;
}

int ihk_smp_os_register_handler_body_result(
	unsigned long os, unsigned long os_priv, unsigned long handler,
	unsigned long list_head,
	const struct ihk_smp_interrupt_handler_offsets *offsets)
{
	char *h = (char *)handler;
	struct list_head *node;
	struct list_head *head;

	if (!handler || !list_head || !offsets)
		return -EINVAL;

	*(unsigned long *)(h + offsets->handler_os) = os;
	*(unsigned long *)(h + offsets->handler_os_priv) = os_priv;
	node = (struct list_head *)(h + offsets->handler_list);
	head = (struct list_head *)list_head;
	node->next = head;
	node->prev = head->prev;
	head->prev->next = node;
	head->prev = node;
	return 0;
}

int ihk_smp_os_unregister_handler_body_result(
	unsigned long handler,
	const struct ihk_smp_interrupt_handler_offsets *offsets,
	unsigned long poison_next, unsigned long poison_prev)
{
	char *h = (char *)handler;
	struct list_head *node;

	if (!handler || !offsets)
		return -EINVAL;

	node = (struct list_head *)(h + offsets->handler_list);
	node->next->prev = node->prev;
	node->prev->next = node->next;
	node->next = (struct list_head *)poison_next;
	node->prev = (struct list_head *)poison_prev;
	return 0;
}

int ihk_smp_irq_call_handlers_body_result(
	unsigned long list_head,
	const struct ihk_smp_interrupt_handler_offsets *offsets,
	int irq_handled, void (*log_no_handler_fn)(void))
{
	struct list_head *head;
	struct list_head *node;
	int found = 0;

	if (!list_head || !offsets)
		return -EINVAL;

	head = (struct list_head *)list_head;
	for (node = head->next; node && node != head; node = node->next) {
		char *handler = (char *)node - offsets->handler_list;
		void (*func)(unsigned long, unsigned long, unsigned long) =
			*(void (**)(unsigned long, unsigned long, unsigned long))
			 (handler + offsets->handler_func);

		if (func) {
			func(*(unsigned long *)(handler + offsets->handler_os),
			     *(unsigned long *)(handler + offsets->handler_os_priv),
			     *(unsigned long *)(handler + offsets->handler_priv));
			found = 1;
		}
	}

	if (!found && log_no_handler_fn)
		log_no_handler_fn();

	return irq_handled;
}

int ihk_smp_collect_cache_topology_body_result(
	void *cpu_topo, int index, int cpu_number, int nr_cpumask_bits,
	size_t cache_topology_size, size_t path_max,
	const struct ihk_smp_collect_cache_topology_offsets *offsets,
	void *(*alloc_fn)(size_t),
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*file_readable_fn)(const char *, const char *),
	int (*read_long_fn)(long *, const char *, const char *),
	int (*read_string_fn)(char **, const char *, const char *),
	int (*read_bitmap_fn)(void *, int, const char *, const char *),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int))
{
	char *prefix;
	char *cache = NULL;
	long *sizep;
	int error;
	int n;

	if (!cpu_topo || !offsets || !alloc_fn || !zalloc_fn || !free_fn ||
	    !file_readable_fn || !read_long_fn || !read_string_fn ||
	    !read_bitmap_fn || !list_add_fn) {
		return -22;
	}

	prefix = alloc_fn(path_max);
	if (!prefix) {
		if (log_fn)
			log_fn(1, -ENOMEM);
		return -ENOMEM;
	}

	n = ihk_smp_cache_sysfs_prefix_result(prefix, path_max, cpu_number,
			index);
	if (ihk_smp_snprintf_overflow_result(n, path_max)) {
		if (log_fn)
			log_fn(2, -ENAMETOOLONG);
		free_fn(prefix);
		return -ENAMETOOLONG;
	}

	if (!file_readable_fn(prefix, "level")) {
		free_fn(prefix);
		return 0;
	}

	cache = zalloc_fn(cache_topology_size);
	if (!cache) {
		if (log_fn)
			log_fn(3, -ENOMEM);
		free_fn(prefix);
		return -ENOMEM;
	}

	*(int *)(cache + offsets->cache_index) = index;

	error = read_long_fn((long *)(cache + offsets->cache_level),
			prefix, "level");
	if (error) {
		if (log_fn)
			log_fn(4, error);
		goto out;
	}
	error = read_string_fn((char **)(cache + offsets->cache_type),
			prefix, "type");
	if (error) {
		if (log_fn)
			log_fn(5, error);
		goto out;
	}
	sizep = (long *)(cache + offsets->cache_size);
	error = read_long_fn(sizep, prefix, "size");
	if (error) {
		if (log_fn)
			log_fn(6, error);
		goto out;
	}
	*sizep = ihk_smp_cache_size_bytes_result(*sizep);
	error = read_string_fn((char **)(cache + offsets->cache_size_str),
			prefix, "size");
	if (error) {
		if (log_fn)
			log_fn(7, error);
		goto out;
	}
	error = read_long_fn((long *)(cache +
			offsets->cache_coherency_line_size), prefix,
			"coherency_line_size");
	if (error) {
		if (log_fn)
			log_fn(8, error);
		goto out;
	}
	error = read_long_fn((long *)(cache + offsets->cache_number_of_sets),
			prefix, "number_of_sets");
	if (error) {
		if (log_fn)
			log_fn(9, error);
		goto out;
	}
	error = read_long_fn((long *)(cache +
			offsets->cache_physical_line_partition), prefix,
			"physical_line_partition");
	if (error) {
		if (log_fn)
			log_fn(10, error);
		goto out;
	}
	error = read_long_fn((long *)(cache +
			offsets->cache_ways_of_associativity), prefix,
			"ways_of_associativity");
	if (error) {
		if (log_fn)
			log_fn(11, error);
		goto out;
	}
	error = read_bitmap_fn(cache + offsets->cache_shared_cpu_map,
			nr_cpumask_bits, prefix, "shared_cpu_map");
	if (error) {
		if (log_fn)
			log_fn(12, error);
		goto out;
	}

	list_add_fn(cache + offsets->cache_chain,
			(char *)cpu_topo + offsets->cpu_cache_topology_list);
	cache = NULL;
	error = 0;

out:
	if (cache) {
		free_fn(*(char **)(cache + offsets->cache_type));
		free_fn(*(char **)(cache + offsets->cache_size_str));
		free_fn(cache);
	}
	free_fn(prefix);
	return error;
}

int ihk_smp_collect_cpu_topology_body_result(
	int cpu, int nr_cpumask_bits, size_t cpu_topology_size,
	size_t path_max, void *cpu_topology_list_head,
	const struct ihk_smp_collect_cpu_topology_offsets *offsets,
	void *(*alloc_fn)(size_t),
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*read_long_fn)(long *, const char *, const char *),
	int (*read_bitmap_fn)(void *, int, const char *, const char *),
	void (*init_list_head_fn)(void *),
	int (*get_hw_id_fn)(int),
	int (*collect_cache_fn)(void *, int),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int))
{
	char *prefix;
	char *topo;
	int error;
	int index;
	int n;

	if (!cpu_topology_list_head || !offsets || !alloc_fn || !zalloc_fn ||
	    !free_fn || !read_long_fn || !read_bitmap_fn ||
	    !init_list_head_fn || !get_hw_id_fn || !collect_cache_fn ||
	    !list_add_fn) {
		return -22;
	}

	prefix = alloc_fn(path_max);
	if (!prefix) {
		if (log_fn)
			log_fn(13, -ENOMEM);
		return -ENOMEM;
	}

	n = ihk_smp_cpu_sysfs_prefix_result(prefix, path_max, cpu);
	if (ihk_smp_snprintf_overflow_result(n, path_max)) {
		if (log_fn)
			log_fn(14, -ENAMETOOLONG);
		free_fn(prefix);
		return -ENAMETOOLONG;
	}

	topo = zalloc_fn(cpu_topology_size);
	if (!topo) {
		if (log_fn)
			log_fn(15, -ENOMEM);
		free_fn(prefix);
		return -ENOMEM;
	}

	init_list_head_fn(topo + offsets->cache_topology_list);
	*(int *)(topo + offsets->cpu_number) = cpu;
	*(int *)(topo + offsets->hw_id) = get_hw_id_fn(cpu);

	error = read_long_fn((long *)(topo + offsets->core_id),
			prefix, "topology/core_id");
	if (error) {
		if (log_fn)
			log_fn(16, error);
		free_fn(topo);
		free_fn(prefix);
		return error;
	}

	error = read_bitmap_fn(topo + offsets->core_siblings,
			nr_cpumask_bits, prefix, "topology/core_siblings");
	if (error) {
		if (log_fn)
			log_fn(17, error);
		free_fn(topo);
		free_fn(prefix);
		return error;
	}

	error = read_long_fn((long *)(topo + offsets->physical_package_id),
			prefix, "topology/physical_package_id");
	if (error) {
		if (log_fn)
			log_fn(18, error);
		free_fn(topo);
		free_fn(prefix);
		return error;
	}

	error = read_bitmap_fn(topo + offsets->thread_siblings,
			nr_cpumask_bits, prefix, "topology/thread_siblings");
	if (error) {
		if (log_fn)
			log_fn(19, error);
		free_fn(topo);
		free_fn(prefix);
		return error;
	}

	for (index = 0; index < 10; ++index) {
		error = collect_cache_fn(topo, index);
		if (error) {
			if (log_fn)
				log_fn(20, error);
			break;
		}
	}

	list_add_fn(topo + offsets->cpu_chain, cpu_topology_list_head);
	free_fn(prefix);
	return 0;
}

int ihk_smp_collect_node_topology_body_result(
	int node, int nr_cpumask_bits, size_t node_topology_size,
	void *node_topology_list_head,
	const struct ihk_smp_collect_node_topology_offsets *offsets,
	void *(*zalloc_fn)(size_t),
	void (*free_fn)(void *),
	int (*read_node_cpumap_fn)(void *, int, int),
	void (*list_add_fn)(void *, void *),
	void (*log_fn)(int, int))
{
	char *topo;
	int error;

	if (!node_topology_list_head || !offsets || !zalloc_fn || !free_fn ||
	    !read_node_cpumap_fn || !list_add_fn) {
		return -22;
	}

	topo = zalloc_fn(node_topology_size);
	if (!topo) {
		if (log_fn)
			log_fn(21, -ENOMEM);
		return -ENOMEM;
	}

	*(int *)(topo + offsets->node_number) = node;

	error = read_node_cpumap_fn(topo + offsets->cpumap,
			nr_cpumask_bits, node);
	if (error) {
		if (log_fn)
			log_fn(22, error);
		free_fn(topo);
		return error;
	}

	list_add_fn(topo + offsets->node_chain, node_topology_list_head);
	return 0;
}

int ihk_smp_collect_topology_body_result(
	int (*next_cpu_fn)(int),
	int (*collect_cpu_fn)(int),
	int (*next_node_fn)(int),
	int (*collect_node_fn)(int),
	void (*log_fn)(int, int))
{
	int cpu;
	int node;
	int error;

	if (!next_cpu_fn || !collect_cpu_fn || !next_node_fn ||
	    !collect_node_fn)
		return -EINVAL;

	if (log_fn)
		log_fn(23, 0);

	for (cpu = next_cpu_fn(-1); cpu >= 0; cpu = next_cpu_fn(cpu)) {
		error = collect_cpu_fn(cpu);
		if (error) {
			if (log_fn) {
				log_fn(24, error);
				log_fn(26, error);
			}
			return error;
		}
	}

	for (node = next_node_fn(-1); node >= 0; node = next_node_fn(node)) {
		error = collect_node_fn(node);
		if (error) {
			if (log_fn) {
				log_fn(25, error);
				log_fn(26, error);
			}
			return error;
		}
	}

	if (log_fn)
		log_fn(26, 0);
	return 0;
}

static unsigned long smp_arch_lookup_symbol(unsigned long (*lookup_fn)(const char *),
					    const char *name)
{
	return lookup_fn ? lookup_fn(name) : 0;
}

static int smp_arch_warn_failed(int (*warn_fn)(int), int failed)
{
	return warn_fn ? warn_fn(failed) : failed;
}

static int smp_arch_publish_required_symbol(unsigned long *slot,
					    const char *name,
					    unsigned long (*lookup_fn)(const char *),
					    int (*warn_fn)(int))
{
	unsigned long value = smp_arch_lookup_symbol(lookup_fn, name);

	if (slot)
		*slot = value;
	return smp_arch_warn_failed(warn_fn, value == 0) ? -EFAULT : 0;
}

static int smp_arch_publish_required_symbol_with_fallback(unsigned long *slot,
							  const char *primary,
							  const char *fallback,
							  unsigned long (*lookup_fn)(const char *),
							  int (*warn_fn)(int))
{
	unsigned long value = smp_arch_lookup_symbol(lookup_fn, primary);

	if (!value)
		value = smp_arch_lookup_symbol(lookup_fn, fallback);
	if (slot)
		*slot = value;
	return smp_arch_warn_failed(warn_fn, value == 0) ? -EFAULT : 0;
}

int ihk_smp_arch_symbols_init_body_result(
	const struct ihk_smp_arch_symbol_slots *slots,
	unsigned long (*lookup_fn)(const char *),
	int (*warn_fn)(int))
{
	if (!slots || !lookup_fn)
		return -22;
	if (smp_arch_publish_required_symbol(slots->real_mode_header,
			"real_mode_header", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->vector_irq,
			"vector_irq", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->lapic_get_maxlvt,
			"lapic_get_maxlvt", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->irq_desc_tree,
			"irq_desc_tree", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->get_uv_system_type,
			"get_uv_system_type", lookup_fn, warn_fn))
		return -EFAULT;
	if (slots->init_deasserted &&
	    smp_arch_publish_required_symbol(slots->init_deasserted,
			"init_deasserted", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->alloc_desc,
			"alloc_desc", lookup_fn, warn_fn))
		return -EFAULT;
	if (slots->default_send_ipi_dest_field &&
	    smp_arch_publish_required_symbol(slots->default_send_ipi_dest_field,
			"__default_send_IPI_dest_field", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol_with_fallback(slots->init_level4_pgt,
			"init_top_pgt", "init_level4_pgt", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol_with_fallback(slots->used_vectors,
			"system_vectors", "used_vectors", lookup_fn, warn_fn))
		return -EFAULT;
	return 0;
}

int ihk_smp_symbols_init_body_result(
	const struct ihk_smp_symbol_slots *slots, int use_old_vmap_api,
	int use_linux_work_irq, unsigned long (*lookup_fn)(const char *),
	int (*warn_fn)(int))
{
	if (!slots || !lookup_fn)
		return -EINVAL;
	if (smp_arch_publish_required_symbol(slots->ioremap_page_range,
			"ioremap_page_range", lookup_fn, warn_fn))
		return -EFAULT;
	if (use_old_vmap_api) {
		if (smp_arch_publish_required_symbol(slots->vmap_area_lock,
				"vmap_area_lock", lookup_fn, warn_fn))
			return -EFAULT;
		if (smp_arch_publish_required_symbol(slots->vmap_area_root,
				"vmap_area_root", lookup_fn, warn_fn))
			return -EFAULT;
		if (smp_arch_publish_required_symbol(slots->insert_vmap_area,
				"__insert_vmap_area", lookup_fn, warn_fn))
			return -EFAULT;
		if (smp_arch_publish_required_symbol(slots->free_vmap_area_old,
				"__free_vmap_area", lookup_fn, warn_fn))
			return -EFAULT;
	} else {
		if (smp_arch_publish_required_symbol(slots->alloc_vmap_area,
				"alloc_vmap_area", lookup_fn, warn_fn))
			return -EFAULT;
		if (smp_arch_publish_required_symbol_with_fallback(
				slots->free_vmap_area_new, "free_vmap_area",
				"free_vmap_area_noflush", lookup_fn, warn_fn))
			return -EFAULT;
	}
	if (smp_arch_publish_required_symbol(slots->unmap_kernel_range_noflush,
			"unmap_kernel_range_noflush", lookup_fn, warn_fn))
		return -EFAULT;
	if (use_linux_work_irq &&
	    smp_arch_publish_required_symbol(slots->raised_list,
			"raised_list", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->hstates,
			"hstates", lookup_fn, warn_fn))
		return -EFAULT;
	if (smp_arch_publish_required_symbol(slots->default_hstate_idx,
			"default_hstate_idx", lookup_fn, warn_fn))
		return -EFAULT;
	return 0;
}

static void smp_lock_status_model(unsigned long object,
				  unsigned long lock_offset,
				  unsigned long status_offset, int status,
				  unsigned long (*lock_fn)(unsigned long),
				  void (*unlock_fn)(unsigned long,
						    unsigned long))
{
	unsigned long lock_addr = object + lock_offset;
	unsigned long flags = lock_fn ? lock_fn(lock_addr) : 0;

	*(int *)(object + status_offset) = status;
	if (unlock_fn)
		unlock_fn(lock_addr, flags);
}

int ihk_smp_os_notify_hungup_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	if (!os || !offsets)
		return -EINVAL;
	smp_lock_status_model(os, offsets->os_lock, offsets->os_status,
			      BUILTIN_OS_STATUS_HUNGUP, lock_fn, unlock_fn);
	return 0;
}

unsigned long ihk_smp_os_get_memory_info_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets)
{
	return (!os || !offsets) ? 0 : os + offsets->os_mem_info;
}

unsigned long ihk_smp_os_get_cpu_info_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets)
{
	return (!os || !offsets) ? 0 : os + offsets->os_cpu_info;
}

int ihk_smp_os_get_num_numa_nodes_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets)
{
	if (!os || !offsets)
		return -EINVAL;
	return *(int *)(os + offsets->os_mem_info +
			offsets->mem_info_n_numa_nodes);
}

int ihk_smp_os_get_num_cpus_body_result(
	unsigned long os, const struct ihk_smp_control_offsets *offsets)
{
	if (!os || !offsets)
		return -EINVAL;
	return *(int *)(os + offsets->os_nr_cpus);
}

static void smp_strncpy_kernel_args_model(char *dst, const char *src,
					  size_t len)
{
	size_t i;
	int copied_nul = 0;

	if (!len)
		return;
	for (i = 0; i + 1 < len; i++) {
		char value;
		if (copied_nul) {
			value = 0;
		} else {
			value = src[i];
			if (value == '\0')
				copied_nul = 1;
		}
		dst[i] = value;
	}
	dst[len - 1] = '\0';
}

int ihk_smp_os_set_kargs_body_result(
	unsigned long os, const char *args,
	const struct ihk_smp_control_offsets *offsets,
	unsigned long kernel_args_len,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	void (*log_fn)(int, const char *))
{
	unsigned long lock_addr;
	unsigned long flags;
	char *kernel_args;

	if (!os || !args || !offsets)
		return -EINVAL;
	lock_addr = os + offsets->os_lock;
	flags = lock_fn ? lock_fn(lock_addr) : 0;
	if (*(int *)(os + offsets->os_status) != BUILTIN_OS_STATUS_INITIAL) {
		if (unlock_fn)
			unlock_fn(lock_addr, flags);
		if (log_fn)
			log_fn(1, NULL);
		return -EBUSY;
	}
	*(int *)(os + offsets->os_status) = BUILTIN_OS_STATUS_LOADING;
	if (unlock_fn)
		unlock_fn(lock_addr, flags);

	kernel_args = (char *)(os + offsets->os_kernel_args);
	smp_strncpy_kernel_args_model(kernel_args, args, kernel_args_len);
	if (log_fn)
		log_fn(2, kernel_args);
	smp_lock_status_model(os, offsets->os_lock, offsets->os_status,
			      BUILTIN_OS_STATUS_INITIAL, lock_fn, unlock_fn);
	return 0;
}

long ihk_smp_os_debug_request_body_result(
	unsigned long ihk_os, unsigned long priv_data, unsigned int req,
	unsigned long arg, unsigned int start_req,
	int (*issue_interrupt_fn)(unsigned long, unsigned long, int, int))
{
	if (req == start_req) {
		if (issue_interrupt_fn)
			issue_interrupt_fn(ihk_os, priv_data, (int)(arg >> 8),
					   (int)(arg & 0xff));
		return 0;
	}
	return -EINVAL;
}

int ihk_smp_os_freeze_thaw_body_result(
	unsigned long ihk_os, unsigned long priv_data, int mode,
	int (*send_multi_intr_fn)(unsigned long, unsigned long, int))
{
	if (send_multi_intr_fn)
		send_multi_intr_fn(ihk_os, priv_data, mode);
	return 0;
}

int ihk_smp_create_os_body_result(
	unsigned long device_data, unsigned long ihk_os, unsigned long regdata,
	unsigned long builtin_regdata,
	const struct ihk_smp_control_offsets *offsets,
	unsigned long regdata_size, unsigned long os_size,
	void *(*alloc_fn)(unsigned long),
	void (*spin_init_fn)(unsigned long),
	void (*log_fn)(int))
{
	unsigned char *dst = (unsigned char *)regdata;
	const unsigned char *src = (const unsigned char *)builtin_regdata;
	unsigned long os;
	unsigned long i;

	(void)ihk_os;
	if (!device_data || !regdata || !builtin_regdata || !offsets)
		return -EFAULT;
	if (!alloc_fn)
		return -ENOMEM;
	for (i = 0; i < regdata_size; i++)
		dst[i] = src[i];
	os = (unsigned long)alloc_fn(os_size);
	if (!os) {
		*(int *)(device_data + offsets->dev_status) = 0;
		if (log_fn)
			log_fn(1);
		return -ENOMEM;
	}
	if (spin_init_fn)
		spin_init_fn(os + offsets->os_lock);
	*(unsigned long *)(os + offsets->os_dev) = device_data;
	*(unsigned long *)(regdata + offsets->regdata_priv) = os;
	*(int *)(os + offsets->os_bootstrap_numa_id) = -1;
	*(unsigned long *)(os + offsets->os_boot_pt) = 0;
	return 0;
}

int ihk_smp_destroy_os_body_result(
	unsigned long os_priv, void (*free_fn)(unsigned long))
{
	if (free_fn)
		free_fn(os_priv);
	return 0;
}

long ihk_smp_device_debug_request_body_result(void)
{
	return -EINVAL;
}

unsigned long ihk_smp_get_dma_channel_body_result(
	unsigned long dev, unsigned long priv_data, int channel)
{
	(void)dev;
	(void)priv_data;
	(void)channel;
	return 0;
}

int ihk_smp_unmap_virtual_body_result(
	unsigned long virt, void (*unmap_fn)(unsigned long))
{
	if (unmap_fn)
		unmap_fn(virt);
	return 0;
}

void ihk_smp_direct_unmap_virtual_body_result(
	unsigned long virt, unsigned long page_size,
	void (*flush_fn)(unsigned long, unsigned long))
{
	if (flush_fn)
		flush_fn(virt, page_size);
}

unsigned long ihk_smp_map_virtual_body_result(
	unsigned long ihk_dev, unsigned long phys, unsigned long size,
	unsigned long virt, int flags,
	unsigned long (*direct_map_fn)(unsigned long, unsigned long),
	unsigned long (*host_map_fn)(unsigned long, unsigned long,
				     unsigned long, unsigned long, int),
	void (*log_fn)(int, unsigned long, unsigned long))
{
	unsigned long mapped;

	if (!virt) {
		mapped = direct_map_fn ? direct_map_fn(phys, size) : 0;
		if (!mapped && log_fn)
			log_fn(1, phys, size);
		return mapped;
	}
	return host_map_fn ? host_map_fn(ihk_dev, phys, virt, size, flags) : 0;
}

unsigned long ihk_smp_direct_map_virtual_body_result(
	unsigned long list_head, unsigned long phys, unsigned long size,
	const struct ihk_smp_map_virtual_list_offsets *offsets,
	unsigned long (*phys_to_virt_fn)(unsigned long))
{
	unsigned long node;

	if (!list_head || !offsets || !phys_to_virt_fn)
		return 0;

	node = *(unsigned long *)(list_head + offsets->list_next);
	while (node && node != list_head) {
		unsigned long entry = node - offsets->entry_list;
		unsigned long start =
			*(unsigned long *)(entry + offsets->entry_addr);
		unsigned long chunk_size =
			*(unsigned long *)(entry + offsets->entry_size);

		if (phys >= start && phys + size <= start + chunk_size) {
			unsigned long base = phys_to_virt_fn(start);

			if (!base)
				return 0;
			return base + (phys - start);
		}
		node = *(unsigned long *)(node + offsets->list_next);
	}

	return 0;
}

int ihk_smp_get_buildid_body_result(
	unsigned long user_addr, const char *buildid, unsigned long buildid_len,
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long))
{
	if (!user_addr || !buildid || !copy_to_user_fn)
		return -EFAULT;
	if (copy_to_user_fn(user_addr, buildid, buildid_len))
		return -EFAULT;
	return 0;
}

int ihk_smp_kernel_virt_in_map_result(
	unsigned long virt, unsigned long map_start, unsigned long map_end)
{
	return virt > map_start && virt < map_end;
}

unsigned long ihk_smp_bootstrap_base_phys_result(
	unsigned long bootstrap_start, unsigned long large_page,
	unsigned long large_page_mask)
{
	return (bootstrap_start + large_page * 2 - 1) & large_page_mask;
}

unsigned long ihk_smp_kernel_vtop_result(
	unsigned long base_phys, unsigned long virt, unsigned long map_start)
{
	return base_phys + (virt - map_start);
}

int ihk_smp_os_vtop_body_result(
	unsigned long bootstrap_mem_start, unsigned long virt,
	unsigned long *phys, unsigned long map_start, unsigned long map_end,
	unsigned long large_page, unsigned long large_page_mask,
	unsigned long (*virt_to_phys_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long))
{
	if (!phys)
		return -EINVAL;
	if (ihk_smp_kernel_virt_in_map_result(virt, map_start, map_end)) {
		unsigned long base =
			ihk_smp_bootstrap_base_phys_result(bootstrap_mem_start,
							   large_page,
							   large_page_mask);
		*phys = ihk_smp_kernel_vtop_result(base, virt, map_start);
		if (log_fn)
			log_fn(1, virt, *phys);
	} else {
		*phys = virt_to_phys_fn ? virt_to_phys_fn(virt) : 0;
		if (log_fn)
			log_fn(2, virt, *phys);
	}
	return 0;
}

int ihk_smp_ready_to_load_result(
	int has_cpu, unsigned long mem_start, unsigned long mem_end)
{
	return has_cpu && mem_end >= mem_start;
}

int ihk_smp_load_too_big_result(
	unsigned long mem_start, unsigned long size, unsigned long mem_end)
{
	return mem_start + size > mem_end;
}

unsigned long ihk_smp_load_mem_phys_result(
	unsigned long offset, unsigned long page_mask)
{
	return offset & page_mask;
}

unsigned long ihk_smp_load_mem_page_offset_result(
	unsigned long offset, unsigned long phys)
{
	return offset - phys;
}

unsigned long ihk_smp_load_mem_copy_len_result(
	unsigned long offset, unsigned long size, unsigned long page_size)
{
	unsigned long page_offset = offset & (page_size - 1);

	return page_offset + size > page_size ? page_size - page_offset : size;
}

unsigned long ihk_smp_next_page_offset_result(
	unsigned long offset, unsigned long page_size)
{
	return offset + page_size;
}

static void smp_lock_status_model(unsigned long object,
				  unsigned long lock_offset,
				  unsigned long status_offset, int status,
				  unsigned long (*lock_fn)(unsigned long),
				  void (*unlock_fn)(unsigned long,
						    unsigned long));

int ihk_smp_os_load_mem_body_result(
	unsigned long os, int has_cpu, unsigned long mem_start,
	unsigned long mem_end, const char *buf, unsigned long size,
	long offset, const struct ihk_smp_control_offsets *offsets,
	unsigned long page_size, unsigned long page_mask,
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	unsigned long (*map_fn)(unsigned long, unsigned long),
	void (*copy_fn)(unsigned long, const char *, unsigned long),
	void (*unmap_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long,
		       unsigned long, unsigned long))
{
	unsigned long lock_addr;
	unsigned long flags;
	unsigned long remaining;
	unsigned long source_offset;
	unsigned long phys;

	if (!os || !buf || !offsets || !page_size)
		return -EINVAL;
	if (!ihk_smp_ready_to_load_result(has_cpu, mem_start, mem_end)) {
		if (log_fn)
			log_fn(1, 0, 0, 0, 0);
		return -EINVAL;
	}
	if (ihk_smp_load_too_big_result(mem_start, size, mem_end)) {
		if (log_fn)
			log_fn(2, 0, 0, 0, 0);
		return -E2BIG;
	}

	lock_addr = os + offsets->os_lock;
	flags = lock_fn ? lock_fn(lock_addr) : 0;
	if (*(int *)(os + offsets->os_status) != BUILTIN_OS_STATUS_INITIAL) {
		if (unlock_fn)
			unlock_fn(lock_addr, flags);
		if (log_fn)
			log_fn(3, 0, 0, 0, 0);
		return -EBUSY;
	}
	*(int *)(os + offsets->os_status) = BUILTIN_OS_STATUS_LOADING;
	if (unlock_fn)
		unlock_fn(lock_addr, flags);

	remaining = size;
	source_offset = (unsigned long)offset + mem_start;
	phys = ihk_smp_load_mem_phys_result(source_offset, page_mask);
	source_offset = ihk_smp_load_mem_page_offset_result(source_offset, phys);

	while (remaining > 0) {
		unsigned long virt = map_fn ? map_fn(phys, page_size) : 0;
		unsigned long to_read;

		if (!virt) {
			if (log_fn)
				log_fn(4, phys, 0, 0, 0);
			smp_lock_status_model(os, offsets->os_lock,
					      offsets->os_status,
					      BUILTIN_OS_STATUS_INITIAL,
					      lock_fn, unlock_fn);
			return -ENOMEM;
		}

		to_read = ihk_smp_load_mem_copy_len_result(source_offset,
							   remaining,
							   page_size);
		if (log_fn)
			log_fn(5, virt, phys, source_offset, to_read);
		if (copy_fn)
			copy_fn(virt, buf + source_offset, to_read);
		source_offset += to_read;
		remaining -= to_read;
		if (unmap_fn)
			unmap_fn(virt);
		phys = ihk_smp_next_page_offset_result(phys, page_size);
	}

	*(unsigned long *)(os + offsets->os_boot_rip) = mem_start;
	smp_lock_status_model(os, offsets->os_lock, offsets->os_status,
			      BUILTIN_OS_STATUS_INITIAL, lock_fn, unlock_fn);
	return 0;
}

int ihk_smp_interrupt_cpu_valid_result(int cpu, int nr_cpus)
{
	return cpu >= 0 && cpu < nr_cpus;
}

unsigned long ihk_smp_adjust_entry_body_result(unsigned long entry,
					       unsigned long phys)
{
	(void)phys;
	return entry;
}

unsigned long ihk_smp_identity_map_memory_body_result(unsigned long remote_phys)
{
	return remote_phys;
}

int ihk_smp_identity_unmap_memory_body_result(void)
{
	return 0;
}

int ihk_smp_arch_dcache_flush_body_result(unsigned long addr,
					  unsigned long len)
{
	(void)addr;
	(void)len;
	return 0;
}

int ihk_smp_setup_warm_reset_vector_body_result(
	unsigned long start_eip, unsigned long trampoline_phys_high,
	unsigned long trampoline_phys_low,
	unsigned long (*lock_fn)(void),
	void (*cmos_write_fn)(unsigned char, unsigned char),
	void (*unlock_fn)(unsigned long), void (*flush_tlb_fn)(void),
	void (*write_word_fn)(unsigned long, unsigned short))
{
	unsigned long flags = lock_fn ? lock_fn() : 0;

	if (cmos_write_fn)
		cmos_write_fn(0x0a, 0x0f);
	if (unlock_fn)
		unlock_fn(flags);
	if (flush_tlb_fn)
		flush_tlb_fn();
	if (write_word_fn) {
		write_word_fn(trampoline_phys_high, start_eip >> 4);
		write_word_fn(trampoline_phys_low, start_eip & 0x0f);
	}
	return 0;
}

int ihk_smp_setup_trampoline_body_result(
	unsigned long os, int nr_cpu_ids,
	const struct ihk_smp_setup_trampoline_offsets *offsets,
	int linux_work_irq_enabled, unsigned int linux_work_irq_vector,
	unsigned int smp_irq, unsigned long page_offset_base,
	unsigned long init_level4_pgt, unsigned long linux_kernel_pgt_phys,
	int using_linux_trampoline, unsigned long trampoline_va,
	unsigned long linux_trampoline_backup, unsigned long trampoline_data,
	unsigned long trampoline_size, unsigned long ident_page_table,
	unsigned long param_phys, unsigned long ikc_irq_work_func,
	unsigned int (*apicid_fn)(int),
	unsigned long (*raised_list_phys_fn)(int),
	void (*log_fn)(int, unsigned long, unsigned long))
{
	unsigned long param;
	int cpu;

	if (!os || !offsets || !trampoline_va || !trampoline_data)
		return -EINVAL;
	if (nr_cpu_ids < 0)
		return -EINVAL;

	param = *(unsigned long *)(os + offsets->os_param);
	if (!param)
		return -EINVAL;

	for (cpu = 0; cpu < nr_cpu_ids; cpu++) {
		unsigned int apicid = apicid_fn ? apicid_fn(cpu) : 0;

		*(unsigned int *)(param + offsets->param_ihk_ikc_irq_apicids +
			cpu * offsets->param_ihk_ikc_irq_apicid_stride) =
			apicid;
		if (linux_work_irq_enabled) {
			unsigned long raised_phys = raised_list_phys_fn ?
				raised_list_phys_fn(cpu) : 0;

			*(unsigned long *)(param +
				offsets->param_ihk_ikc_cpu_raised_list +
				cpu * offsets->param_ihk_ikc_cpu_raised_list_stride) =
				raised_phys;
		}
	}

	if (linux_work_irq_enabled) {
		*(unsigned long *)(param + offsets->param_ikc_irq_work_func) =
			ikc_irq_work_func;
		*(unsigned int *)(param + offsets->param_ihk_ikc_irq) =
			linux_work_irq_vector;
	} else {
		*(unsigned int *)(param + offsets->param_ihk_ikc_irq) =
			smp_irq;
	}

	*(unsigned long *)(param + offsets->param_page_offset_base) =
		page_offset_base;
	*(unsigned long *)(param + offsets->param_linux_kernel_pgt_phys) =
		linux_kernel_pgt_phys;
	if (log_fn)
		log_fn(1, init_level4_pgt, linux_kernel_pgt_phys);

	if (using_linux_trampoline) {
		if (!linux_trampoline_backup)
			return -EINVAL;
		memcpy((void *)linux_trampoline_backup, (void *)trampoline_va,
		       trampoline_size);
	}
	memcpy((void *)trampoline_va, (void *)trampoline_data,
	       trampoline_size);

	*(unsigned long *)(trampoline_va + offsets->header_page_table) =
		ident_page_table;
	*(unsigned long *)(trampoline_va + offsets->header_next_ip) =
		*(unsigned long *)(os + offsets->os_boot_rip);
	*(unsigned long *)(trampoline_va + offsets->header_notify_address) =
		param_phys;
	return 0;
}

static int smp_setup_startup_map_range_model(
	unsigned long page_table, unsigned long virt, unsigned long phys,
	unsigned long len, unsigned long step,
	int (*map_kernel_fn)(unsigned long, unsigned long, unsigned long),
	void (*log_fn)(int), int log_event)
{
	unsigned long remaining = len;

	if (!step || !map_kernel_fn)
		return -EINVAL;
	while (remaining > 0) {
		if (map_kernel_fn(page_table, virt, phys) < 0) {
			if (log_fn)
				log_fn(log_event);
			return -ENOMEM;
		}
		virt += step;
		phys += step;
		remaining = remaining > step ? remaining - step : 0;
	}
	return 0;
}

int ihk_smp_os_setup_startup_body_result(
	unsigned long os, unsigned long phys, unsigned long entry,
	const struct ihk_smp_setup_startup_offsets *offsets,
	unsigned long identity_len, unsigned long large_page,
	unsigned long large_page_mask, unsigned long map_st_start,
	unsigned long map_kernel_start, unsigned long kernel_map_len,
	unsigned long page_size, unsigned int ptl2_shift,
	unsigned long startup_data, unsigned long startup_data_len,
	unsigned long trampoline_phys, unsigned long (*alloc_page_fn)(void),
	unsigned long (*page_phys_fn)(unsigned long),
	int (*map_kernel_fn)(unsigned long, unsigned long, unsigned long),
	unsigned long (*map_virtual_fn)(unsigned long, unsigned long),
	void (*unmap_virtual_fn)(unsigned long),
	void (*log_fn)(int))
{
	unsigned long boot_pt;
	unsigned long bootstrap_mem_end;
	unsigned long stack_p;
	unsigned long startup_p;
	unsigned long startup;
	unsigned long boot_pt_phys;
	int ret;

	if (!os || !offsets || !startup_data || !page_size)
		return -EINVAL;
	boot_pt = alloc_page_fn ? alloc_page_fn() : 0;
	if (!boot_pt) {
		if (log_fn)
			log_fn(1);
		return -ENOMEM;
	}
	*(unsigned long *)(os + offsets->os_boot_pt) = boot_pt;

	ret = smp_setup_startup_map_range_model(boot_pt, 0, 0,
		identity_len, large_page, map_kernel_fn, log_fn, 2);
	if (ret)
		return ret;
	ret = smp_setup_startup_map_range_model(boot_pt, map_st_start, 0,
		identity_len, large_page, map_kernel_fn, log_fn, 3);
	if (ret)
		return ret;
	ret = smp_setup_startup_map_range_model(boot_pt, map_kernel_start,
		phys, kernel_map_len, large_page, map_kernel_fn, log_fn, 4);
	if (ret)
		return ret;

	bootstrap_mem_end =
		*(unsigned long *)(os + offsets->os_bootstrap_mem_end);
	stack_p = bootstrap_mem_end - page_size;
	startup_p = (bootstrap_mem_end & large_page_mask) -
		(2UL << ptl2_shift);
	startup = map_virtual_fn ? map_virtual_fn(startup_p, page_size) : 0;
	if (!startup) {
		if (log_fn)
			log_fn(5);
		return -ENOMEM;
	}
	memcpy((void *)startup, (void *)startup_data, startup_data_len);
	boot_pt_phys = page_phys_fn ? page_phys_fn(boot_pt) : 0;
	((unsigned long *)startup)[2] = boot_pt_phys;
	((unsigned long *)startup)[3] = stack_p;
	((unsigned long *)startup)[4] = phys;
	((unsigned long *)startup)[5] = trampoline_phys;
	((unsigned long *)startup)[6] = entry;
	if (unmap_virtual_fn)
		unmap_virtual_fn(startup);
	*(unsigned long *)(os + offsets->os_boot_rip) = startup_p;
	return 0;
}

int ihk_smp_arch_init_trampoline_body_result(
	unsigned long preallocated_phys, unsigned long page_size,
	unsigned int trampoline_order, int max_attempts,
	unsigned long trampoline_size, unsigned long trampoline_limit,
	unsigned long (*linux_trampoline_phys_fn)(void),
	unsigned long *trampoline_page_slot,
	unsigned long *trampoline_phys_slot,
	unsigned long *trampoline_va_slot,
	int *using_linux_trampoline_slot,
	unsigned long (*ioremap_fn)(unsigned long, unsigned long),
	unsigned long (*alloc_fn)(void),
	unsigned long (*page_phys_fn)(unsigned long),
	unsigned long (*page_virt_fn)(unsigned long),
	void (*free_fn)(unsigned long, unsigned int),
	unsigned long (*direct_virt_fn)(unsigned long),
	void (*log_fn)(int, unsigned long))
{
	unsigned long bad_pages[64] = { 0 };
	unsigned long page = 0;
	unsigned long page_phys = 0;
	unsigned long linux_trampoline_phys;
	size_t attempts = 0;
	size_t i;

	if (!trampoline_page_slot || !trampoline_phys_slot ||
	    !trampoline_va_slot || !using_linux_trampoline_slot ||
	    !page_size || max_attempts <= 0 || max_attempts > 64)
		return -EINVAL;

	if (preallocated_phys) {
		if (log_fn)
			log_fn(1, preallocated_phys);
		*trampoline_page_slot = 0;
		*trampoline_phys_slot = preallocated_phys;
		*trampoline_va_slot = ioremap_fn ?
			ioremap_fn(preallocated_phys, page_size) : 0;
		*using_linux_trampoline_slot = 0;
		return 0;
	}

	while (attempts < (size_t)max_attempts) {
		page = alloc_fn ? alloc_fn() : 0;
		page_phys = page && page_phys_fn ? page_phys_fn(page) : 0;
		if (page && page_phys + trampoline_size <= trampoline_limit)
			break;
		bad_pages[attempts] = page;
		attempts++;
	}

	for (i = 0; i < (size_t)max_attempts; i++) {
		if (bad_pages[i] && free_fn)
			free_fn(bad_pages[i], trampoline_order);
	}

	page_phys = page && page_phys_fn ? page_phys_fn(page) : 0;
	if (!page || page_phys + trampoline_size > trampoline_limit) {
		linux_trampoline_phys = linux_trampoline_phys_fn ?
			linux_trampoline_phys_fn() : 0;
		*trampoline_page_slot = 0;
		*using_linux_trampoline_slot = 1;
		if (log_fn)
			log_fn(2, linux_trampoline_phys);
		*trampoline_phys_slot = linux_trampoline_phys;
		*trampoline_va_slot = direct_virt_fn ?
			direct_virt_fn(linux_trampoline_phys) : 0;
	} else {
		*trampoline_page_slot = page;
		*using_linux_trampoline_slot = 0;
		*trampoline_phys_slot = page_phys;
		*trampoline_va_slot = page_virt_fn ? page_virt_fn(page) : 0;
	}
	if (log_fn)
		log_fn(3, *trampoline_phys_slot);
	return 0;
}

int ihk_smp_arch_init_linux_work_tail_body_result(
	int linux_work_irq_vector, int (*init_ident_page_table_fn)(void),
	int (*collect_topology_fn)(void), void (*log_fn)(int, int))
{
	int error;

	if (log_fn)
		log_fn(1, linux_work_irq_vector);
	error = init_ident_page_table_fn ? init_ident_page_table_fn() : -EINVAL;
	if (error) {
		if (log_fn)
			log_fn(2, error);
		return error;
	}
	error = collect_topology_fn ? collect_topology_fn() : -EINVAL;
	if (error) {
		if (log_fn)
			log_fn(3, error);
		return error;
	}
	return 0;
}

int ihk_smp_init_ident_page_table_body_result(
	unsigned long maxmem, unsigned long page_size, unsigned int pud_shift,
	unsigned int pmd_shift, int ptrs_per_pud, int ptrs_per_pmd,
	unsigned long first_level_flags, unsigned long leaf_flags,
	unsigned long *ident_page_table_slot,
	unsigned long *ident_page_table_virt_slot,
	int *ident_npages_order_slot,
	unsigned long (*alloc_pages_fn)(unsigned int),
	unsigned long (*page_phys_fn)(unsigned long),
	unsigned long (*page_virt_fn)(unsigned long),
	void (*zero_fn)(unsigned long, unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long))
{
	const unsigned int bits = sizeof(unsigned long) * 8;
	unsigned long pud_size = pud_shift < bits ? (1UL << pud_shift) : 0;
	int ident_npages = pud_size ? (int)((maxmem + pud_size - 1) / pud_size) : 0;
	unsigned long target = (unsigned long)ident_npages + 2;
	int ident_npages_order = 0;
	unsigned long ident_pages;
	unsigned long ident_page_table;
	unsigned long ident_page_table_virt;
	unsigned long *table;
	unsigned long *p;
	int i;
	int j;
	int k;

	if (!page_size || ptrs_per_pud < 0 || ptrs_per_pmd < 0 ||
	    !ident_page_table_slot || !ident_page_table_virt_slot ||
	    !ident_npages_order_slot)
		return -EINVAL;

	if (target) {
		ident_npages_order =
			(int)(bits - (unsigned int)__builtin_clzl(target)) - 1;
		if ((2UL << ident_npages_order) != target)
			ident_npages_order++;
	}
	if (log_fn)
		log_fn(1, ident_npages, ident_npages_order);
	*ident_npages_order_slot = ident_npages_order;

	ident_pages = alloc_pages_fn ?
		alloc_pages_fn((unsigned int)ident_npages_order) : 0;
	if (!ident_pages) {
		if (log_fn)
			log_fn(2, ident_npages, ident_npages_order);
		return ENOMEM;
	}

	ident_page_table = page_phys_fn ? page_phys_fn(ident_pages) : 0;
	ident_page_table_virt = page_virt_fn ? page_virt_fn(ident_pages) : 0;
	*ident_page_table_slot = ident_page_table;
	*ident_page_table_virt_slot = ident_page_table_virt;
	if (zero_fn)
		zero_fn(ident_page_table_virt, ident_npages);

	table = (unsigned long *)ident_page_table_virt;
	table[0] = (ident_page_table + page_size) | first_level_flags;

	p = table + (page_size / sizeof(*p));
	for (i = 0; i < ptrs_per_pud; i++) {
		if ((i >= 0 ? (1UL * (unsigned long)i << pud_shift) : 0) >= maxmem)
			break;
		*p = (ident_page_table + page_size * (2 + i)) |
			first_level_flags;
		p++;
	}
	if (i != ident_npages && log_fn)
		log_fn(3, i, ident_npages);

	p = table + (page_size * 2 / sizeof(*p));
	for (j = 0; j < ident_npages; j++) {
		for (k = 0; k < ptrs_per_pmd; k++) {
			unsigned long physaddr =
				((unsigned long)j << pud_shift) |
				((unsigned long)k << pmd_shift);
			if (physaddr >= maxmem)
				break;
			*p = physaddr | leaf_flags;
			p++;
		}
	}

	if (log_fn)
		log_fn(4, ident_page_table, ident_page_table_virt);
	return 0;
}

int ihk_smp_reset_cpu_body_result(
	int phys_apicid, int apic_esr, unsigned int assert_init_value,
	unsigned int deassert_init_value, void (*preempt_disable_fn)(void),
	void (*preempt_enable_fn)(void), int (*get_maxlvt_fn)(void),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	void (*icr_write_fn)(unsigned int, int),
	unsigned long (*wait_icr_idle_fn)(void),
	void (*delay_fn)(unsigned long), void (*log_fn)(int, int))
{
	int maxlvt;
	int integrated;

	if (preempt_disable_fn)
		preempt_disable_fn();
	if (log_fn)
		log_fn(1, phys_apicid);

	maxlvt = get_maxlvt_fn ? get_maxlvt_fn() : 0;
	integrated = apic_integrated_fn && apic_integrated_fn(phys_apicid);
	if (integrated) {
		if (maxlvt > 3 && apic_write_fn)
			apic_write_fn(apic_esr, 0);
		if (apic_read_fn)
			(void)apic_read_fn(apic_esr);
	}

	if (log_fn)
		log_fn(2, phys_apicid);
	if (icr_write_fn)
		icr_write_fn(assert_init_value, phys_apicid);
	if (log_fn)
		log_fn(3, phys_apicid);
	if (wait_icr_idle_fn)
		(void)wait_icr_idle_fn();
	if (delay_fn)
		delay_fn(10);
	if (log_fn)
		log_fn(4, phys_apicid);
	if (icr_write_fn)
		icr_write_fn(deassert_init_value, phys_apicid);
	if (log_fn)
		log_fn(5, phys_apicid);
	if (wait_icr_idle_fn)
		(void)wait_icr_idle_fn();
	if (preempt_enable_fn)
		preempt_enable_fn();

	return 0;
}

int ihk_smp_wakeup_secondary_cpu_via_init_body_result(
	int phys_apicid, unsigned long start_eip, int apic_esr,
	unsigned int assert_init_value, unsigned int deassert_init_value,
	unsigned int startup_value, int (*get_maxlvt_fn)(void),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	void (*icr_write_fn)(unsigned int, int),
	unsigned long (*wait_icr_idle_fn)(void),
	void (*mdelay_fn)(unsigned long),
	void (*udelay_fn)(unsigned long), void (*barrier_fn)(void),
	void (*init_deasserted_fn)(void),
	void (*log_fn)(int, unsigned long))
{
	unsigned long send_status = 0;
	unsigned long accept_status = 0;
	int maxlvt;
	int integrated;
	int num_starts;
	int j;

	maxlvt = get_maxlvt_fn ? get_maxlvt_fn() : 0;
	integrated = apic_integrated_fn && apic_integrated_fn(phys_apicid);

	if (integrated) {
		if (maxlvt > 3 && apic_write_fn)
			apic_write_fn(apic_esr, 0);
		if (apic_read_fn)
			(void)apic_read_fn(apic_esr);
	}

	if (log_fn)
		log_fn(1, 0);
	if (icr_write_fn)
		icr_write_fn(assert_init_value, phys_apicid);
	if (log_fn)
		log_fn(2, 0);
	if (wait_icr_idle_fn)
		send_status = wait_icr_idle_fn();
	if (mdelay_fn)
		mdelay_fn(10);
	if (log_fn)
		log_fn(3, 0);
	if (icr_write_fn)
		icr_write_fn(deassert_init_value, phys_apicid);
	if (log_fn)
		log_fn(2, 0);
	if (wait_icr_idle_fn)
		send_status = wait_icr_idle_fn();
	if (barrier_fn)
		barrier_fn();
	if (init_deasserted_fn)
		init_deasserted_fn();

	num_starts = integrated ? 2 : 0;
	if (log_fn)
		log_fn(4, num_starts);

	for (j = 1; j <= num_starts; j++) {
		if (log_fn)
			log_fn(5, j);
		if (maxlvt > 3 && apic_write_fn)
			apic_write_fn(apic_esr, 0);
		if (apic_read_fn)
			(void)apic_read_fn(apic_esr);
		if (log_fn)
			log_fn(6, 0);
		if (icr_write_fn)
			icr_write_fn((unsigned int)(startup_value |
				      (start_eip >> 12)), phys_apicid);
		if (udelay_fn)
			udelay_fn(300);
		if (log_fn) {
			log_fn(7, 0);
			log_fn(2, 0);
		}
		if (wait_icr_idle_fn)
			send_status = wait_icr_idle_fn();
		if (udelay_fn)
			udelay_fn(200);
		if (maxlvt > 3 && apic_write_fn)
			apic_write_fn(apic_esr, 0);
		if (apic_read_fn)
			accept_status = apic_read_fn(apic_esr) & 0xef;
		if (send_status || accept_status)
			break;
	}

	if (log_fn) {
		log_fn(8, 0);
		if (send_status)
			log_fn(9, send_status);
		if (accept_status)
			log_fn(10, accept_status);
	}

	return send_status | accept_status;
}

int ihk_smp_wakeup_secondary_cpu_body_result(
	int apicid, unsigned long start_eip, int boot_cpu_physical_apicid,
	int apic_esr, void (*clear_init_deasserted_fn)(void),
	int (*non_unique_apic_fn)(void),
	void (*setup_warm_reset_vector_fn)(unsigned long),
	int (*apic_integrated_fn)(int),
	void (*apic_write_fn)(int, unsigned int),
	unsigned int (*apic_read_fn)(int),
	int (*apic_wakeup_available_fn)(void),
	int (*apic_wakeup_fn)(int, unsigned long),
	void (*preempt_disable_fn)(void),
	int (*via_init_fn)(int, unsigned long),
	void (*preempt_enable_fn)(void), void (*log_fn)(int))
{
	int non_unique_apic;
	int apic_wakeup_available;
	int ret;

	if (clear_init_deasserted_fn)
		clear_init_deasserted_fn();

	non_unique_apic = non_unique_apic_fn && non_unique_apic_fn();
	if (!non_unique_apic) {
		if (log_fn)
			log_fn(1);
		if (setup_warm_reset_vector_fn)
			setup_warm_reset_vector_fn(start_eip);
		if (apic_integrated_fn &&
		    apic_integrated_fn(boot_cpu_physical_apicid)) {
			if (apic_write_fn)
				apic_write_fn(apic_esr, 0);
			if (apic_read_fn)
				(void)apic_read_fn(apic_esr);
		}
	}

	apic_wakeup_available = apic_wakeup_available_fn &&
		apic_wakeup_available_fn();
	if (apic_wakeup_available) {
		if (log_fn)
			log_fn(2);
		return apic_wakeup_fn ? apic_wakeup_fn(apicid, start_eip) :
			-ENOSYS;
	}

	if (log_fn)
		log_fn(3);
	if (preempt_disable_fn)
		preempt_disable_fn();
	ret = via_init_fn ? via_init_fn(apicid, start_eip) : -ENOSYS;
	if (preempt_enable_fn)
		preempt_enable_fn();
	return ret;
}

int ihk_smp_arch_exit_body_result(
	unsigned long trampoline_page, int using_linux_trampoline,
	unsigned long trampoline_va, unsigned int trampoline_order,
	unsigned long ident_page_table_virt, unsigned int ident_npages_order,
	void (*free_trampoline_fn)(unsigned long, unsigned int),
	void (*unmap_fn)(unsigned long),
	void (*free_pages_fn)(unsigned long, unsigned int))
{
	if (trampoline_page) {
		if (free_trampoline_fn)
			free_trampoline_fn(trampoline_page, trampoline_order);
	} else if (!using_linux_trampoline) {
		if (unmap_fn)
			unmap_fn(trampoline_va);
	}

	if (ident_npages_order && free_pages_fn)
		free_pages_fn(ident_page_table_virt, ident_npages_order);

	return 0;
}

unsigned long ihk_smp_calc_ns_per_tsc_body_result(int invariant_tsc,
						  unsigned int ratio,
						  unsigned long tsc_khz)
{
	if (invariant_tsc && ratio)
		return 10000UL / ratio;
	return 1000000000UL / tsc_khz;
}

unsigned long ihk_smp_x2apic_is_enabled_body_result(unsigned long msr)
{
	return msr & (1UL << 10);
}

int ihk_smp_vector_entry_used_result(unsigned long entry,
				     unsigned long unused)
{
	return entry != unused;
}

int ihk_smp_vector_set_needed_result(unsigned long entry,
				     unsigned long unused)
{
	return entry == unused;
}

unsigned long ihk_smp_vector_release_value_result(unsigned long unused)
{
	return unused;
}

int ihk_smp_os_issue_interrupt_body_result(
	int cpu, int nr_cpus, const int *hw_ids, int vector,
	int apic_dest_physical,
	unsigned long (*irq_save_fn)(void),
	void (*irq_restore_fn)(unsigned long),
	int (*x2apic_enabled_fn)(void),
	void (*x2apic_write_fn)(int, int),
	void (*legacy_ipi_fn)(int, int, int))
{
	unsigned long flags;
	int hw_id;

	if (!ihk_smp_interrupt_cpu_valid_result(cpu, nr_cpus) || !hw_ids)
		return -EINVAL;

	flags = irq_save_fn ? irq_save_fn() : 0;
	hw_id = hw_ids[cpu];
	if (x2apic_enabled_fn && x2apic_enabled_fn()) {
		if (x2apic_write_fn)
			x2apic_write_fn(vector, hw_id);
	} else if (legacy_ipi_fn) {
		legacy_ipi_fn(hw_id, vector, apic_dest_physical);
	}
	if (irq_restore_fn)
		irq_restore_fn(flags);
	return -EINVAL;
}

int ihk_smp_os_broadcast_interrupt_body_result(
	unsigned long ihk_os, unsigned long priv_data, int mode, int nr_cpus,
	const int *hw_ids, int x2apic_vector, int legacy_vector,
	int apic_dest_physical, int wrap_irq, int wait_x2apic,
	int (*set_mode_fn)(unsigned long, unsigned long, int),
	unsigned long (*irq_save_fn)(void),
	void (*irq_restore_fn)(unsigned long),
	int (*x2apic_enabled_fn)(void),
	void (*x2apic_wait_fn)(void),
	void (*x2apic_write_fn)(int, int),
	void (*legacy_ipi_fn)(int, int, int))
{
	unsigned long flags = 0;
	int x2apic_enabled;
	int ret;
	int i;

	if (nr_cpus < 0 || !hw_ids)
		return -EINVAL;

	if (set_mode_fn) {
		ret = set_mode_fn(ihk_os, priv_data, mode);
		if (ret)
			return ret;
	}

	if (wrap_irq && irq_save_fn)
		flags = irq_save_fn();

	x2apic_enabled = x2apic_enabled_fn && x2apic_enabled_fn();
	for (i = 0; i < nr_cpus; i++) {
		if (x2apic_enabled) {
			if (wait_x2apic && x2apic_wait_fn)
				x2apic_wait_fn();
			if (x2apic_write_fn)
				x2apic_write_fn(x2apic_vector, hw_ids[i]);
		} else if (legacy_ipi_fn) {
			legacy_ipi_fn(hw_ids[i], legacy_vector,
				      apic_dest_physical);
		}
	}

	if (wrap_irq && irq_restore_fn)
		irq_restore_fn(flags);

	return 0;
}

int ihk_smp_check_ikc_map_body_result(void)
{
	return 0;
}

int ihk_smp_arch_get_perf_event_map_body_result(
	unsigned long param, unsigned long extra_regs,
	unsigned long hw_event_map, unsigned long hw_cache_event_ids,
	unsigned long hw_cache_extra_regs,
	const struct ihk_smp_perf_offsets *offsets,
	unsigned long max_extra_regs, unsigned long hw_event_map_bytes,
	unsigned long hw_cache_event_ids_bytes,
	unsigned long hw_cache_extra_regs_bytes,
	void (*log_fn)(int, int))
{
	unsigned long er = extra_regs;
	unsigned long er_cnt = 0;

	if (!param || !offsets)
		return -EINVAL;

	while (er && *(unsigned int *)(er + offsets->extra_msr)) {
		if (er_cnt >= max_extra_regs) {
			if (log_fn)
				log_fn(1, (int)(er_cnt + 1));
			return -EINVAL;
		}

		*(unsigned int *)(param + offsets->ereg_event +
				er_cnt * sizeof(unsigned int)) =
			*(unsigned int *)(er + offsets->extra_event);
		*(unsigned int *)(param + offsets->ereg_msr +
				er_cnt * sizeof(unsigned int)) =
			*(unsigned int *)(er + offsets->extra_msr);
		*(unsigned long *)(param + offsets->ereg_valid_mask +
				er_cnt * sizeof(unsigned long)) =
			*(unsigned long *)(er + offsets->extra_valid_mask);
		*(int *)(param + offsets->ereg_idx + er_cnt * sizeof(int)) =
			*(int *)(er + offsets->extra_idx);

		er_cnt++;
		er += offsets->extra_stride;
	}

	*(unsigned int *)(param + offsets->nr_extra_regs) =
		(unsigned int)er_cnt;

	if (hw_event_map_bytes) {
		if (!hw_event_map)
			return -EINVAL;
		memcpy((void *)(param + offsets->hw_event_map),
				(void *)hw_event_map, hw_event_map_bytes);
	}
	if (hw_cache_event_ids_bytes) {
		if (!hw_cache_event_ids)
			return -EINVAL;
		memcpy((void *)(param + offsets->hw_cache_event_ids),
				(void *)hw_cache_event_ids,
				hw_cache_event_ids_bytes);
	}
	if (hw_cache_extra_regs_bytes) {
		if (!hw_cache_extra_regs)
			return -EINVAL;
		memcpy((void *)(param + offsets->hw_cache_extra_regs),
				(void *)hw_cache_extra_regs,
				hw_cache_extra_regs_bytes);
	}

	return 0;
}

int ihk_smp_device_get_num_cpus_body_result(
	const void *cpus, int cpu_count, unsigned long stride,
	unsigned long status_offset, int available_status)
{
	int num_cpus = 0;
	int i;

	if (!cpus || cpu_count < 0 || !stride)
		return -EINVAL;
	for (i = 0; i < cpu_count; i++) {
		const char *base = cpus;
		const int *status = (const int *)(base + i * stride +
						  status_offset);
		if (*status == available_status)
			num_cpus++;
	}
	return num_cpus;
}

static void smp_query_cpu_log_model(void (*log_fn)(int, int, int),
				    int event, int requested, int actual)
{
	if (log_fn)
		log_fn(event, requested, actual);
}

static int smp_query_cpu_copy_request_model(
	unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_cpu_req_offsets *req_offsets,
	int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int *req_num_cpus_out, unsigned long *req_cpus_out,
	void (*log_fn)(int, int, int))
{
	struct ihk_cpu_req *req;

	if (!user_arg || !req_scratch || !req_offsets || !req_size ||
	    !copy_from_user_fn) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	if (copy_from_user_fn((void *)req_scratch, user_arg, req_size)) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	req = (struct ihk_cpu_req *)req_scratch;
	*req_cpus_out = *(unsigned long *)((char *)req + req_offsets->cpus);
	*req_num_cpus_out = *(int *)((char *)req + req_offsets->num_cpus);
	if (*req_num_cpus_out < 0 || *req_num_cpus_out > max_cpus ||
	    (*req_num_cpus_out > 0 && !*req_cpus_out)) {
		smp_query_cpu_log_model(log_fn, 2, *req_num_cpus_out,
					*req_num_cpus_out);
		return -EINVAL;
	}
	return 0;
}

static void *smp_query_cpu_alloc_model(int req_num_cpus,
				       unsigned long int_size,
				       void *(*alloc_fn)(unsigned long),
				       void (*log_fn)(int, int, int),
				       int *ret)
{
	void *ptr;

	*ret = 0;
	if (!int_size) {
		*ret = -EINVAL;
		return NULL;
	}
	if (!req_num_cpus)
		return NULL;
	if (!alloc_fn) {
		smp_query_cpu_log_model(log_fn, 4, req_num_cpus, 0);
		*ret = -ENOMEM;
		return NULL;
	}
	ptr = alloc_fn((unsigned long)req_num_cpus * int_size);
	if (!ptr) {
		smp_query_cpu_log_model(log_fn, 4, req_num_cpus, 0);
		*ret = -ENOMEM;
	}
	return ptr;
}

static int smp_query_cpu_copy_results_model(
	unsigned long user_arg, unsigned long req_cpus, int req_num_cpus,
	const struct ihk_smp_cpu_req_offsets *req_offsets, void *res_cpus,
	unsigned long int_size,
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void (*log_fn)(int, int, int))
{
	if (!copy_to_user_fn) {
		smp_query_cpu_log_model(log_fn, 7, req_num_cpus, 0);
		return -EFAULT;
	}
	if (req_num_cpus > 0 &&
	    copy_to_user_fn(req_cpus, res_cpus,
			    (unsigned long)req_num_cpus * int_size)) {
		smp_query_cpu_log_model(log_fn, 6, req_num_cpus, 0);
		return -EFAULT;
	}
	if (copy_to_user_fn(user_arg + req_offsets->num_cpus,
			    &req_num_cpus, int_size)) {
		smp_query_cpu_log_model(log_fn, 7, req_num_cpus, 0);
		return -EFAULT;
	}
	return 0;
}

int ihk_smp_device_query_cpu_body_result(
	unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_cpu_req_offsets *req_offsets,
	const void *cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_status_offset, int available_status,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int))
{
	int req_num_cpus, actual, ret = 0;
	unsigned long req_cpus;
	int *res_cpus;

	ret = smp_query_cpu_copy_request_model(user_arg, req_scratch,
			req_size, req_offsets, max_cpus, copy_from_user_fn,
			&req_num_cpus, &req_cpus, log_fn);
	if (ret)
		return ret;
	actual = ihk_smp_device_get_num_cpus_body_result(cpus, cpu_count,
			cpu_stride, cpu_status_offset, available_status);
	if (actual != req_num_cpus) {
		smp_query_cpu_log_model(log_fn, 3, req_num_cpus, actual);
		return -EINVAL;
	}
	res_cpus = smp_query_cpu_alloc_model(req_num_cpus, int_size,
			alloc_fn, log_fn, &ret);
	if (ret)
		return ret;
	if (req_num_cpus > 0) {
		int i, pos = 0;
		const char *base = cpus;
		for (i = 0; i < cpu_count; i++) {
			const int *status = (const int *)(base +
				i * cpu_stride + cpu_status_offset);
			if (*status == available_status)
				res_cpus[pos++] = i;
		}
		if (pos > req_num_cpus) {
			smp_query_cpu_log_model(log_fn, 5, req_num_cpus, pos);
			ret = -EINVAL;
			goto out;
		}
	}
	ret = smp_query_cpu_copy_results_model(user_arg, req_cpus,
			req_num_cpus, req_offsets, res_cpus, int_size,
			copy_to_user_fn, log_fn);
out:
	if (res_cpus && free_fn)
		free_fn((unsigned long)res_cpus);
	return ret;
}

int ihk_smp_os_query_cpu_body_result(
	unsigned long os, unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_cpu_req_offsets *req_offsets,
	const struct ihk_smp_control_offsets *os_offsets,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int))
{
	int req_num_cpus, actual, ret = 0;
	unsigned long req_cpus;
	int *res_cpus;

	if (!os || !os_offsets)
		return -EINVAL;
	ret = smp_query_cpu_copy_request_model(user_arg, req_scratch,
			req_size, req_offsets, max_cpus, copy_from_user_fn,
			&req_num_cpus, &req_cpus, log_fn);
	if (ret)
		return ret;
	actual = *(int *)(os + os_offsets->os_nr_cpus);
	if (actual != req_num_cpus) {
		smp_query_cpu_log_model(log_fn, 3, req_num_cpus, actual);
		return -EINVAL;
	}
	res_cpus = smp_query_cpu_alloc_model(req_num_cpus, int_size,
			alloc_fn, log_fn, &ret);
	if (ret)
		return ret;
	if (req_num_cpus > 0) {
		memcpy(res_cpus, (void *)(os + os_offsets->os_cpu_mapping),
		       (unsigned long)actual * int_size);
	}
	ret = smp_query_cpu_copy_results_model(user_arg, req_cpus,
			req_num_cpus, req_offsets, res_cpus, int_size,
			copy_to_user_fn, log_fn);
	if (res_cpus && free_fn)
		free_fn((unsigned long)res_cpus);
	return ret;
}

int ihk_smp_os_get_ikc_map_body_result(
	unsigned long ihk_os, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	const struct ihk_smp_ikc_req_offsets *req_offsets,
	const void *cpus, int cpu_count, unsigned long cpu_stride,
	unsigned long cpu_status_offset, unsigned long cpu_os_offset,
	unsigned long cpu_ikc_offset, int assigned_status,
	unsigned long int_size, int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int))
{
	unsigned long req_src_cpus, req_dst_cpus;
	int req_num_cpus;
	int *res_src_cpus = NULL;
	int *res_dst_cpus = NULL;
	int idx = 0;
	int ret = 0;
	int i;

	if (!user_arg || !req_scratch || !req_offsets || !req_size ||
	    !copy_from_user_fn) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	if (copy_from_user_fn((void *)req_scratch, user_arg, req_size)) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	req_src_cpus = *(unsigned long *)(req_scratch + req_offsets->src_cpus);
	req_dst_cpus = *(unsigned long *)(req_scratch + req_offsets->dst_cpus);
	req_num_cpus = *(int *)(req_scratch + req_offsets->num_cpus);
	if (req_num_cpus < 0 || req_num_cpus > max_cpus ||
	    (req_num_cpus > 0 && (!req_src_cpus || !req_dst_cpus))) {
		smp_query_cpu_log_model(log_fn, 2, 0, req_num_cpus);
		return -EINVAL;
	}
	if (!int_size)
		return -EINVAL;
	if (req_num_cpus > 0) {
		unsigned long bytes = (unsigned long)req_num_cpus * int_size;

		if (!alloc_fn) {
			smp_query_cpu_log_model(log_fn, 3, req_num_cpus, 0);
			return -ENOMEM;
		}
		res_src_cpus = alloc_fn(bytes);
		if (!res_src_cpus) {
			smp_query_cpu_log_model(log_fn, 3, req_num_cpus, 0);
			return -ENOMEM;
		}
		res_dst_cpus = alloc_fn(bytes);
		if (!res_dst_cpus) {
			smp_query_cpu_log_model(log_fn, 4, req_num_cpus, 0);
			ret = -ENOMEM;
			goto out;
		}
		if (copy_from_user_fn(res_src_cpus, req_src_cpus, bytes)) {
			smp_query_cpu_log_model(log_fn, 5, req_num_cpus, 0);
			ret = -EFAULT;
			goto out;
		}
		if (copy_from_user_fn(res_dst_cpus, req_dst_cpus, bytes)) {
			smp_query_cpu_log_model(log_fn, 6, req_num_cpus, 0);
			ret = -EFAULT;
			goto out;
		}
	}
	if (!cpus || cpu_count < 0 || cpu_stride == 0) {
		smp_query_cpu_log_model(log_fn, 7, req_num_cpus, idx);
		ret = -EINVAL;
		goto out;
	}
	for (i = 0; i < cpu_count; i++) {
		const char *base = (const char *)cpus + (unsigned long)i * cpu_stride;
		int status = *(const int *)(base + cpu_status_offset);
		unsigned long os = *(const unsigned long *)(base + cpu_os_offset);
		int dst = *(const int *)(base + cpu_ikc_offset);

		if (status != assigned_status || os != ihk_os)
			continue;
		if (idx >= req_num_cpus) {
			idx++;
			smp_query_cpu_log_model(log_fn, 7, req_num_cpus, idx);
			ret = -EINVAL;
			goto out;
		}
		res_src_cpus[idx] = i;
		res_dst_cpus[idx] = dst;
		idx++;
	}
	if (!copy_to_user_fn) {
		smp_query_cpu_log_model(log_fn, 10, idx, 0);
		ret = -EFAULT;
		goto out;
	}
	if (idx > 0) {
		unsigned long bytes = (unsigned long)idx * int_size;

		if (copy_to_user_fn(req_src_cpus, res_src_cpus, bytes)) {
			smp_query_cpu_log_model(log_fn, 8, idx, 0);
			ret = -EFAULT;
			goto out;
		}
		if (copy_to_user_fn(req_dst_cpus, res_dst_cpus, bytes)) {
			smp_query_cpu_log_model(log_fn, 9, idx, 0);
			ret = -EFAULT;
			goto out;
		}
	}
	if (copy_to_user_fn(user_arg + req_offsets->num_cpus, &idx, int_size)) {
		smp_query_cpu_log_model(log_fn, 10, idx, 0);
		ret = -EFAULT;
	}

out:
	if (res_src_cpus && free_fn)
		free_fn((unsigned long)res_src_cpus);
	if (res_dst_cpus && free_fn)
		free_fn((unsigned long)res_dst_cpus);
	return ret;
}

static int smp_ikc_req_policy_model(int num_cpus, int has_src_cpus,
				    int has_dst_cpus, int max_cpus)
{
	if (num_cpus < 0 || num_cpus > max_cpus)
		return 1;
	if (num_cpus > 0 && (!has_src_cpus || !has_dst_cpus))
		return 2;
	return 0;
}

static int smp_ikc_pair_bounds_model(
	const int *src_cpus, const int *dst_cpus, int num_cpus, int limit,
	int *invalid_is_dst, int *invalid_cpu)
{
	int i;

	if (invalid_is_dst)
		*invalid_is_dst = 0;
	if (invalid_cpu)
		*invalid_cpu = -1;
	if (num_cpus < 0 || limit < 0 ||
	    (num_cpus > 0 && (!src_cpus || !dst_cpus)))
		return -EINVAL;
	for (i = 0; i < num_cpus; i++) {
		if (src_cpus[i] < 0 || src_cpus[i] >= limit) {
			if (invalid_is_dst)
				*invalid_is_dst = 0;
			if (invalid_cpu)
				*invalid_cpu = src_cpus[i];
			return -EINVAL;
		}
		if (dst_cpus[i] < 0 || dst_cpus[i] >= limit) {
			if (invalid_is_dst)
				*invalid_is_dst = 1;
			if (invalid_cpu)
				*invalid_cpu = dst_cpus[i];
			return -EINVAL;
		}
	}
	return 0;
}

static int smp_cpu_is_assigned_model(int status)
{
	return status == IHK_SMP_CPU_ASSIGNED;
}

static int smp_cpu_assigned_to_os_model(int status, int same_os)
{
	return status == IHK_SMP_CPU_ASSIGNED && same_os;
}

static void smp_set_ikc_out_model(
	unsigned long ihk_os, unsigned long os, void *cpus, int cpu_count,
	unsigned long cpu_stride,
	const struct ihk_smp_set_ikc_map_offsets *offsets,
	int assigned_status, int *req_src_cpus, int *req_dst_cpus,
	void (*free_fn)(unsigned long))
{
	int i;

	if (*(int *)(os + offsets->os_cpu_ikc_mapped) != 1) {
		for (i = 0; i < cpu_count; i++) {
			char *base = (char *)cpus + (unsigned long)i * cpu_stride;
			int status = *(int *)(base + offsets->cpu_status);
			unsigned long cpu_os =
				*(unsigned long *)(base + offsets->cpu_os);

			if (status != assigned_status ||
			    !smp_cpu_assigned_to_os_model(status,
							  cpu_os == ihk_os))
				continue;
			*(int *)(base + offsets->cpu_ikc_map_cpu) = 0;
		}
	}
	if (req_src_cpus && free_fn)
		free_fn((unsigned long)req_src_cpus);
	if (req_dst_cpus && free_fn)
		free_fn((unsigned long)req_dst_cpus);
}

int ihk_smp_os_set_ikc_map_body_result(
	unsigned long ihk_os, unsigned long os, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	char *req_string, long req_string_len,
	const struct ihk_smp_set_ikc_map_offsets *offsets,
	void *cpus, int cpu_count, unsigned long cpu_stride,
	int assigned_status, int initial_status, unsigned long int_size,
	int max_cpus,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	unsigned long (*lock_fn)(unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	int (*cpu_present_fn)(int),
	int (*cpu_online_fn)(int),
	int (*check_ikc_map_fn)(unsigned long),
	void (*log_fn)(int, int, int))
{
	unsigned long req_src_user, req_dst_user;
	int req_num_cpus;
	int *req_src_cpus = NULL;
	int *req_dst_cpus = NULL;
	int invalid_is_dst = 0;
	int invalid_cpu = -1;
	unsigned long flags = 0;
	int ret = 0;
	int reason;
	int i;

	if (!ihk_os || !os || !req_scratch || !req_size || !offsets) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	if (cpu_count < max_cpus || cpu_stride == 0 || !cpus || !int_size) {
		smp_query_cpu_log_model(log_fn, 8, 0, max_cpus);
		return -EINVAL;
	}
	if (!copy_from_user_fn || !user_arg ||
	    copy_from_user_fn((void *)req_scratch, user_arg, req_size)) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus,
				      cpu_stride, offsets, assigned_status,
				      NULL, NULL, free_fn);
		return -EFAULT;
	}

	req_src_user = *(unsigned long *)(req_scratch + offsets->req_src_cpus);
	req_dst_user = *(unsigned long *)(req_scratch + offsets->req_dst_cpus);
	req_num_cpus = *(int *)(req_scratch + offsets->req_num_cpus);
	reason = smp_ikc_req_policy_model(req_num_cpus, req_src_user != 0,
					  req_dst_user != 0, max_cpus);
	if (reason) {
		smp_query_cpu_log_model(log_fn, 2, reason, req_num_cpus);
		smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus,
				      cpu_stride, offsets, assigned_status,
				      NULL, NULL, free_fn);
		return -EINVAL;
	}

	if (lock_fn)
		flags = lock_fn(os + offsets->os_lock);
	if (*(int *)(os + offsets->os_status) != initial_status) {
		if (unlock_fn)
			unlock_fn(os + offsets->os_lock, flags);
		smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus,
				      cpu_stride, offsets, assigned_status,
				      NULL, NULL, free_fn);
		return -EBUSY;
	}
	if (unlock_fn)
		unlock_fn(os + offsets->os_lock, flags);

	if (req_num_cpus > 0) {
		unsigned long bytes = (unsigned long)req_num_cpus * int_size;

		if (!alloc_fn) {
			smp_query_cpu_log_model(log_fn, 3, req_num_cpus, 0);
			smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus,
					      cpu_stride, offsets,
					      assigned_status, NULL, NULL,
					      free_fn);
			return -ENOMEM;
		}
		req_src_cpus = alloc_fn(bytes);
		if (!req_src_cpus) {
			smp_query_cpu_log_model(log_fn, 3, req_num_cpus, 0);
			smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus,
					      cpu_stride, offsets,
					      assigned_status, NULL, NULL,
					      free_fn);
			return -ENOMEM;
		}
		if (copy_from_user_fn(req_src_cpus, req_src_user, bytes)) {
			smp_query_cpu_log_model(log_fn, 4, req_num_cpus, 0);
			ret = -EFAULT;
			goto out;
		}
		req_dst_cpus = alloc_fn(bytes);
		if (!req_dst_cpus) {
			smp_query_cpu_log_model(log_fn, 5, req_num_cpus, 0);
			ret = -ENOMEM;
			goto out;
		}
		if (copy_from_user_fn(req_dst_cpus, req_dst_user, bytes)) {
			smp_query_cpu_log_model(log_fn, 6, req_num_cpus, 0);
			ret = -EFAULT;
			goto out;
		}
	}

	if (req_string && req_string_len > 0)
		req_string[0] = '\0';

	if (smp_ikc_pair_bounds_model(req_src_cpus, req_dst_cpus,
				      req_num_cpus, max_cpus,
				      &invalid_is_dst, &invalid_cpu)) {
		smp_query_cpu_log_model(log_fn, 8, invalid_is_dst,
					invalid_cpu);
		ret = -EINVAL;
		goto out;
	}

	for (i = 0; i < req_num_cpus; i++) {
		int src_cpu = req_src_cpus[i];
		int dst_cpu = req_dst_cpus[i];
		char *src = (char *)cpus + (unsigned long)src_cpu * cpu_stride;
		char *dst = (char *)cpus + (unsigned long)dst_cpu * cpu_stride;

		smp_query_cpu_log_model(log_fn, 9, src_cpu, dst_cpu);
		if (!smp_cpu_is_assigned_model(
			    *(int *)(src + offsets->cpu_status))) {
			smp_query_cpu_log_model(log_fn, 10, src_cpu, 0);
			ret = -EINVAL;
			goto out;
		}
		if (smp_cpu_is_assigned_model(
			    *(int *)(dst + offsets->cpu_status))) {
			smp_query_cpu_log_model(log_fn, 11, dst_cpu, 0);
			ret = -EINVAL;
			goto out;
		}
		if (cpu_present_fn && !cpu_present_fn(dst_cpu)) {
			smp_query_cpu_log_model(log_fn, 12, dst_cpu, 0);
			ret = -EINVAL;
			goto out;
		}
		if (cpu_online_fn && !cpu_online_fn(dst_cpu)) {
			smp_query_cpu_log_model(log_fn, 13, dst_cpu, 0);
			ret = -EINVAL;
			goto out;
		}
		*(int *)(src + offsets->cpu_ikc_map_cpu) = dst_cpu;
	}

	if (check_ikc_map_fn && check_ikc_map_fn(ihk_os) == 0)
		*(int *)(os + offsets->os_cpu_ikc_mapped) = 1;

	for (i = 0; i < max_cpus; i++) {
		char *base = (char *)cpus + (unsigned long)i * cpu_stride;
		int status = *(int *)(base + offsets->cpu_status);
		unsigned long cpu_os = *(unsigned long *)(base + offsets->cpu_os);

		if (!smp_cpu_assigned_to_os_model(status, cpu_os == ihk_os))
			continue;
		smp_query_cpu_log_model(log_fn, 14, i,
			*(int *)(base + offsets->cpu_ikc_map_cpu));
	}

out:
	smp_set_ikc_out_model(ihk_os, os, cpus, max_cpus, cpu_stride,
			      offsets, assigned_status, req_src_cpus,
			      req_dst_cpus, free_fn);
	return ret;
}

static int smp_validate_mem_req_model(const struct ihk_mem_req *req)
{
	if (req->num_chunks < 0)
		return -EINVAL;
	if (req->num_chunks > 0 && (!req->sizes || !req->numa_ids))
		return -EINVAL;
	if (req->min_chunk_size < 0)
		return -EINVAL;
	if (req->max_size_ratio_all < 0 || req->max_size_ratio_all > 100)
		return -EINVAL;
	return 0;
}

static int smp_query_mem_copy_request_model(
	unsigned long user_arg, unsigned long req_scratch,
	unsigned long req_size,
	const struct ihk_smp_mem_req_offsets *req_offsets,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	size_t **req_sizes_out, int **req_numa_ids_out,
	int *req_num_chunks_out, void (*log_fn)(int, int, int))
{
	struct ihk_mem_req *req;

	if (!user_arg || !req_scratch || !req_size || !req_offsets ||
	    !copy_from_user_fn) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	if (copy_from_user_fn((void *)req_scratch, user_arg, req_size)) {
		smp_query_cpu_log_model(log_fn, 1, 0, 0);
		return -EFAULT;
	}
	req = (struct ihk_mem_req *)req_scratch;
	*req_sizes_out = *(size_t **)((char *)req + req_offsets->sizes);
	*req_numa_ids_out = *(int **)((char *)req + req_offsets->numa_ids);
	*req_num_chunks_out =
		*(int *)((char *)req + req_offsets->num_chunks);
	if (smp_validate_mem_req_model(req)) {
		smp_query_cpu_log_model(log_fn, 2, *req_num_chunks_out, 0);
		return -EINVAL;
	}
	return 0;
}

static int smp_query_mem_entry_matches_model(
	unsigned long entry, const struct ihk_smp_mem_query_offsets *offsets,
	int filter_os, unsigned long target_os)
{
	if (!filter_os)
		return 1;
	return *(unsigned long *)(entry + offsets->entry_os) == target_os;
}

static int smp_query_mem_count_entries_model(
	unsigned long list_head,
	const struct ihk_smp_mem_query_offsets *offsets,
	int filter_os, unsigned long target_os,
	const unsigned long *fake_chunks, unsigned long fake_count)
{
	int count = 0;
	unsigned long node;
	unsigned long i;

	if (list_head) {
		node = *(unsigned long *)(list_head + offsets->list_next);
		while (node && node != list_head) {
			unsigned long entry = node - offsets->entry_list;
			if (smp_query_mem_entry_matches_model(entry, offsets,
							      filter_os,
							      target_os))
				count++;
			node = *(unsigned long *)(node + offsets->list_next);
		}
	}
	for (i = 0; fake_chunks && i < fake_count; i++) {
		if (fake_chunks[i])
			count++;
	}
	return count;
}

static void *smp_query_mem_alloc_array_model(
	int count, unsigned long elem_size, int event,
	void *(*alloc_fn)(unsigned long), void (*log_fn)(int, int, int),
	int *ret)
{
	void *ptr;

	*ret = 0;
	if (!elem_size) {
		*ret = -EINVAL;
		return NULL;
	}
	if (count <= 0)
		return NULL;
	if (!alloc_fn) {
		smp_query_cpu_log_model(log_fn, event, count, 0);
		*ret = -ENOMEM;
		return NULL;
	}
	ptr = alloc_fn((unsigned long)count * elem_size);
	if (!ptr) {
		smp_query_cpu_log_model(log_fn, event, count, 0);
		*ret = -ENOMEM;
	}
	return ptr;
}

static int smp_query_mem_collect_entries_model(
	unsigned long list_head,
	const struct ihk_smp_mem_query_offsets *offsets,
	int filter_os, unsigned long target_os,
	const unsigned long *fake_chunks, unsigned long fake_count,
	size_t *size_out, int *numa_out)
{
	int idx = 0;
	unsigned long node;
	unsigned long i;

	if (list_head) {
		node = *(unsigned long *)(list_head + offsets->list_next);
		while (node && node != list_head) {
			unsigned long entry = node - offsets->entry_list;
			if (smp_query_mem_entry_matches_model(entry, offsets,
							      filter_os,
							      target_os)) {
				size_out[idx] =
					*(size_t *)(entry + offsets->entry_size);
				numa_out[idx] =
					*(int *)(entry + offsets->entry_numa_id);
				idx++;
			}
			node = *(unsigned long *)(node + offsets->list_next);
		}
	}
	for (i = 0; fake_chunks && i < fake_count; i++) {
		if (fake_chunks[i]) {
			size_out[idx] = fake_chunks[i];
			numa_out[idx] = (int)i;
			idx++;
		}
	}
	return idx;
}

static int smp_query_mem_copy_results_model(
	unsigned long user_arg, size_t *req_sizes, int *req_numa_ids,
	const struct ihk_smp_mem_req_offsets *req_offsets,
	size_t *size_out, int *numa_out, int count,
	unsigned long size_elem, unsigned long int_size,
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void (*log_fn)(int, int, int))
{
	if (!copy_to_user_fn) {
		smp_query_cpu_log_model(log_fn, 8, count, 0);
		return -EFAULT;
	}
	if (count > 0 && size_out && numa_out) {
		if (copy_to_user_fn((unsigned long)req_sizes, size_out,
				    (unsigned long)count * size_elem)) {
			smp_query_cpu_log_model(log_fn, 6, count, 0);
			return -EFAULT;
		}
		if (copy_to_user_fn((unsigned long)req_numa_ids, numa_out,
				    (unsigned long)count * int_size)) {
			smp_query_cpu_log_model(log_fn, 7, count, 0);
			return -EFAULT;
		}
	}
	if (copy_to_user_fn(user_arg + req_offsets->num_chunks, &count,
			    int_size)) {
		smp_query_cpu_log_model(log_fn, 8, count, 0);
		return -EFAULT;
	}
	return 0;
}

int ihk_smp_query_mem_body_result(
	unsigned long list_head, unsigned long target_os, int filter_os,
	int require_exact, const unsigned long *fake_chunks,
	unsigned long fake_count, unsigned long user_arg,
	unsigned long req_scratch, unsigned long req_size,
	const struct ihk_smp_mem_req_offsets *req_offsets,
	const struct ihk_smp_mem_query_offsets *query_offsets,
	unsigned long size_elem, unsigned long int_size,
	int (*copy_from_user_fn)(void *, unsigned long, unsigned long),
	int (*copy_to_user_fn)(unsigned long, const void *, unsigned long),
	void *(*alloc_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int, int))
{
	size_t *req_sizes;
	int *req_numa_ids;
	int req_num_chunks;
	int actual, out_count, idx, ret;
	size_t *size_out;
	int *numa_out;

	if (!query_offsets || !req_offsets)
		return -EINVAL;
	ret = smp_query_mem_copy_request_model(user_arg, req_scratch,
			req_size, req_offsets, copy_from_user_fn, &req_sizes,
			&req_numa_ids, &req_num_chunks, log_fn);
	if (ret)
		return ret;
	actual = smp_query_mem_count_entries_model(list_head, query_offsets,
			filter_os, target_os, fake_chunks, fake_count);
	if (req_num_chunks == 0)
		return smp_query_mem_copy_results_model(user_arg, req_sizes,
				req_numa_ids, req_offsets, NULL, NULL, actual,
				size_elem, int_size, copy_to_user_fn, log_fn);
	if (require_exact && actual != req_num_chunks) {
		smp_query_cpu_log_model(log_fn, 3, req_num_chunks, actual);
		return -EINVAL;
	}
	out_count = require_exact ? req_num_chunks : actual;
	size_out = smp_query_mem_alloc_array_model(out_count, size_elem, 4,
			alloc_fn, log_fn, &ret);
	if (ret)
		return ret;
	numa_out = smp_query_mem_alloc_array_model(out_count, int_size, 5,
			alloc_fn, log_fn, &ret);
	if (ret) {
		if (size_out && free_fn)
			free_fn((unsigned long)size_out);
		return ret;
	}
	idx = out_count > 0 ? smp_query_mem_collect_entries_model(list_head,
			query_offsets, filter_os, target_os, fake_chunks,
			fake_count, size_out, numa_out) : 0;
	ret = smp_query_mem_copy_results_model(user_arg, req_sizes,
			req_numa_ids, req_offsets, size_out, numa_out, idx,
			size_elem, int_size, copy_to_user_fn, log_fn);
	if (size_out && free_fn)
		free_fn((unsigned long)size_out);
	if (numa_out && free_fn)
		free_fn((unsigned long)numa_out);
	return ret;
}

static unsigned long smp_lookup_list_next(
	unsigned long entry,
	const struct ihk_smp_topology_lookup_offsets *offsets)
{
	return *(unsigned long *)(entry + offsets->list_next);
}

unsigned long ihk_smp_get_cpu_topology_body_result(
	unsigned long list_head, int hw_id,
	const struct ihk_smp_topology_lookup_offsets *offsets)
{
	unsigned long entry;

	if (!list_head || !offsets)
		return 0;
	for (entry = smp_lookup_list_next(list_head, offsets);
	     entry && entry != list_head;
	     entry = smp_lookup_list_next(entry, offsets)) {
		unsigned long topo = entry - offsets->cpu_chain;
		if (*(int *)(topo + offsets->cpu_hw_id) == hw_id)
			return topo;
	}
	return 0;
}

unsigned long ihk_smp_get_node_topology_body_result(
	unsigned long list_head, int node, int nr_nodes,
	unsigned long einval_ptr,
	const struct ihk_smp_topology_lookup_offsets *offsets)
{
	unsigned long entry;

	if (!list_head || !offsets)
		return 0;
	if (node >= nr_nodes)
		return einval_ptr;
	for (entry = smp_lookup_list_next(list_head, offsets);
	     entry && entry != list_head;
	     entry = smp_lookup_list_next(entry, offsets)) {
		unsigned long topo = entry - offsets->node_chain;
		if (*(int *)(topo + offsets->node_node_number) == node)
			return topo;
	}
	return 0;
}

int ihk_smp_linux_cpu_to_hw_id_body_result(
	unsigned long list_head, int cpu,
	const struct ihk_smp_topology_lookup_offsets *offsets)
{
	unsigned long entry;

	if (!list_head || !offsets)
		return -1;
	for (entry = smp_lookup_list_next(list_head, offsets);
	     entry && entry != list_head;
	     entry = smp_lookup_list_next(entry, offsets)) {
		unsigned long topo = entry - offsets->cpu_chain;
		if (*(int *)(topo + offsets->cpu_cpu_number) == cpu)
			return *(int *)(topo + offsets->cpu_hw_id);
	}
	return -1;
}

static void smp_free_info_log_model(void (*log_fn)(int), int event)
{
	if (log_fn)
		log_fn(event);
}

static void smp_free_info_drain_cache_model(
	unsigned long cache_list_head,
	const struct ihk_smp_free_info_offsets *offsets,
	void (*list_del_fn)(unsigned long),
	void (*free_fn)(unsigned long))
{
	unsigned long cache_node;

	for (cache_node = *(unsigned long *)(cache_list_head +
					     offsets->list_next);
	     cache_node && cache_node != cache_list_head;) {
		unsigned long next_cache =
			*(unsigned long *)(cache_node + offsets->list_next);
		unsigned long cache = cache_node - offsets->cache_chain;

		list_del_fn(cache_node);
		free_fn(*(unsigned long *)(cache + offsets->cache_type));
		free_fn(*(unsigned long *)(cache + offsets->cache_size_str));
		free_fn(cache);
		cache_node = next_cache;
	}
}

int ihk_smp_free_info_body_result(
	unsigned long cpu_list_head, unsigned long node_list_head,
	const struct ihk_smp_free_info_offsets *offsets,
	void (*list_del_fn)(unsigned long), void (*free_fn)(unsigned long),
	void (*log_fn)(int))
{
	unsigned long cpu_node;
	unsigned long node_node;

	if (!cpu_list_head || !node_list_head || !offsets ||
	    !list_del_fn || !free_fn)
		return -EINVAL;

	smp_free_info_log_model(log_fn, 0);
	for (cpu_node = *(unsigned long *)(cpu_list_head + offsets->list_next);
	     cpu_node && cpu_node != cpu_list_head;) {
		unsigned long next_cpu =
			*(unsigned long *)(cpu_node + offsets->list_next);
		unsigned long cpu = cpu_node - offsets->cpu_chain;

		list_del_fn(cpu_node);
		smp_free_info_drain_cache_model(
			cpu + offsets->cpu_cache_topology_list, offsets,
			list_del_fn, free_fn);
		free_fn(cpu);
		cpu_node = next_cpu;
	}

	for (node_node = *(unsigned long *)(node_list_head + offsets->list_next);
	     node_node && node_node != node_list_head;) {
		unsigned long next_node =
			*(unsigned long *)(node_node + offsets->list_next);

		list_del_fn(node_node);
		free_fn(node_node - offsets->node_chain);
		node_node = next_node;
	}
	smp_free_info_log_model(log_fn, 1);
	return 0;
}

static void smp_read_long_log_model(
	void (*log_fn)(int, unsigned long, char *, int), int event,
	unsigned long valuep, char *fmt, int error)
{
	if (log_fn)
		log_fn(event, valuep, fmt, error);
}

int ihk_smp_read_long_body_result(
	unsigned long valuep, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	int (*parse_long_fn)(unsigned long, unsigned long),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, char *, int))
{
	unsigned long buf;
	int error;

	if (!valuep || !fmt || !page_size || !alloc_page_fn ||
	    !read_file_fn || !parse_long_fn || !free_pages_fn)
		return -EINVAL;

	smp_read_long_log_model(log_fn, 0, valuep, fmt, 0);
	buf = alloc_page_fn();
	if (!buf) {
		error = -ENOMEM;
		smp_read_long_log_model(log_fn, 1, valuep, fmt, error);
		goto out;
	}

	error = read_file_fn(buf, page_size, fmt, va_list);
	if (error) {
		smp_read_long_log_model(log_fn, 2, valuep, fmt, error);
		goto out;
	}

	if (parse_long_fn(buf, valuep) != 1) {
		error = -EIO;
		smp_read_long_log_model(log_fn, 3, valuep, fmt, error);
		goto out;
	}

	error = 0;
out:
	free_pages_fn(buf);
	smp_read_long_log_model(log_fn, 4, valuep, fmt, error);
	return error;
}

static void smp_read_bitmap_log_model(
	void (*log_fn)(int, unsigned long, int, char *, int), int event,
	unsigned long map, int nbits, char *fmt, int error)
{
	if (log_fn)
		log_fn(event, map, nbits, fmt, error);
}

int ihk_smp_read_bitmap_body_result(
	unsigned long map, int nbits, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	int (*bitmap_parse_fn)(unsigned long, unsigned long, unsigned long,
			       int),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, int, char *, int))
{
	unsigned long buf;
	int error;

	if (!map || nbits < 0 || !fmt || !page_size || !alloc_page_fn ||
	    !read_file_fn || !bitmap_parse_fn || !free_pages_fn)
		return -EINVAL;

	smp_read_bitmap_log_model(log_fn, 0, map, nbits, fmt, 0);
	buf = alloc_page_fn();
	if (!buf) {
		error = -ENOMEM;
		smp_read_bitmap_log_model(log_fn, 1, map, nbits, fmt, error);
		goto out;
	}

	error = read_file_fn(buf, page_size, fmt, va_list);
	if (error) {
		smp_read_bitmap_log_model(log_fn, 2, map, nbits, fmt, error);
		goto out;
	}

	error = bitmap_parse_fn(buf, page_size, map, nbits);
	if (error) {
		smp_read_bitmap_log_model(log_fn, 3, map, nbits, fmt, error);
		goto out;
	}

	error = 0;
out:
	free_pages_fn(buf);
	smp_read_bitmap_log_model(log_fn, 4, map, nbits, fmt, error);
	return error;
}

static void smp_read_string_log_model(
	void (*log_fn)(int, unsigned long, char *, int), int event,
	unsigned long valuep, char *fmt, int error)
{
	if (log_fn)
		log_fn(event, valuep, fmt, error);
}

static void smp_trim_trailing_newline_model(char *buf)
{
	size_t len;

	if (!buf)
		return;
	len = strlen(buf);
	if (len && buf[len - 1] == '\n')
		buf[len - 1] = '\0';
}

int ihk_smp_read_string_body_result(
	unsigned long valuep, char *fmt, unsigned long va_list,
	unsigned long page_size, unsigned long (*alloc_page_fn)(void),
	int (*read_file_fn)(unsigned long, unsigned long, char *,
			    unsigned long),
	unsigned long (*kstrdup_fn)(unsigned long),
	void (*kfree_fn)(unsigned long),
	void (*free_pages_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, char *, int))
{
	unsigned long buf;
	unsigned long p = 0;
	int error;

	if (!valuep || !fmt || !page_size || !alloc_page_fn ||
	    !read_file_fn || !kstrdup_fn || !kfree_fn || !free_pages_fn)
		return -EINVAL;

	smp_read_string_log_model(log_fn, 0, valuep, fmt, 0);
	buf = alloc_page_fn();
	if (!buf) {
		error = -ENOMEM;
		smp_read_string_log_model(log_fn, 1, valuep, fmt, error);
		goto out;
	}

	error = read_file_fn(buf, page_size, fmt, va_list);
	if (error) {
		smp_read_string_log_model(log_fn, 2, valuep, fmt, error);
		goto out;
	}

	p = kstrdup_fn(buf);
	if (!p) {
		error = -ENOMEM;
		smp_read_string_log_model(log_fn, 3, valuep, fmt, error);
		goto out;
	}

	smp_trim_trailing_newline_model((char *)p);
	*(unsigned long *)valuep = p;
	p = 0;
	error = 0;
out:
	kfree_fn(p);
	free_pages_fn(buf);
	smp_read_string_log_model(log_fn, 4, valuep, fmt, error);
	return error;
}

int ihk_smp_file_readable_body_result(
	char *fmt, unsigned long va_list, unsigned long path_max,
	void *(*alloc_fn)(unsigned long),
	int (*vsnprintf_fn)(char *, unsigned long, char *, unsigned long),
	unsigned long (*open_fn)(char *),
	void (*close_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, int))
{
	char *filename;
	unsigned long fp;
	int ret;
	int n;

	if (!fmt || !path_max || !alloc_fn || !vsnprintf_fn ||
	    !open_fn || !close_fn || !free_fn)
		return 0;

	filename = alloc_fn(path_max);
	if (!filename) {
		if (log_fn)
			log_fn(1, -ENOMEM);
		ret = 0;
		goto out;
	}

	n = vsnprintf_fn(filename, path_max, fmt, va_list);
	if (n >= (int)path_max) {
		if (log_fn)
			log_fn(2, -ENAMETOOLONG);
		ret = 0;
		goto out;
	}

	fp = open_fn(filename);
	if (!fp) {
		ret = 0;
		goto out;
	}

	close_fn(fp);
	ret = 1;

out:
	free_fn((unsigned long)filename);
	return ret;
}

static void smp_read_file_log_model(
	void (*log_fn)(int, unsigned long, unsigned long, char *, int),
	int event, unsigned long buf, unsigned long size, char *fmt, int error)
{
	if (log_fn)
		log_fn(event, buf, size, fmt, error);
}

int ihk_smp_read_file_body_result(
	unsigned long buf, unsigned long size, char *fmt, unsigned long va_list,
	unsigned long path_max, void *(*alloc_fn)(unsigned long),
	int (*vsnprintf_fn)(char *, unsigned long, char *, unsigned long),
	unsigned long (*open_fn)(char *, unsigned long),
	long (*kernel_read_fn)(unsigned long, unsigned long, unsigned long),
	int (*close_fn)(unsigned long),
	void (*free_fn)(unsigned long),
	void (*log_fn)(int, unsigned long, unsigned long, char *, int))
{
	char *filename;
	unsigned long fp = 0;
	int error;
	int n;

	if (!buf || !size || !fmt || !path_max || !alloc_fn ||
	    !vsnprintf_fn || !open_fn || !kernel_read_fn || !close_fn ||
	    !free_fn)
		return -EINVAL;

	smp_read_file_log_model(log_fn, 0, buf, size, fmt, 0);
	filename = alloc_fn(path_max);
	if (!filename) {
		error = -ENOMEM;
		smp_read_file_log_model(log_fn, 1, buf, size, fmt, error);
		goto out;
	}

	n = vsnprintf_fn(filename, path_max, fmt, va_list);
	if (n >= (int)path_max) {
		error = -ENAMETOOLONG;
		smp_read_file_log_model(log_fn, 2, buf, size, fmt, error);
		goto out;
	}

	error = 0;
	fp = open_fn(filename, (unsigned long)&error);
	if (!fp) {
		smp_read_file_log_model(log_fn, 3, buf, size, fmt, error);
		goto out;
	}

	{
		long ss = kernel_read_fn(fp, buf, size);

		if (ss < 0) {
			error = (int)ss;
			smp_read_file_log_model(log_fn, 4, buf, size, fmt,
						error);
			goto out;
		}
		if ((unsigned long)ss >= size) {
			error = -ENOSPC;
			smp_read_file_log_model(log_fn, 5, buf, size, fmt,
						error);
			goto out;
		}
		*(char *)(buf + (unsigned long)ss) = '\0';
	}

	error = 0;
out:
	if (fp) {
		int er = close_fn(fp);

		if (er)
			smp_read_file_log_model(log_fn, 6, buf, size, fmt, er);
	}
	free_fn((unsigned long)filename);
	smp_read_file_log_model(log_fn, 7, buf, size, fmt, error);
	return error;
}

static void smp_write_cpu_sys_file_log_model(
	void (*log_fn)(int, const char *, int), int event, const char *path,
	int error)
{
	if (log_fn)
		log_fn(event, path, error);
}

int ihk_smp_write_cpu_sys_file_body_result(
	int cpu_id, const char *val, char *path, size_t path_size,
	unsigned long (*open_fn)(char *, unsigned long),
	long (*write_fn)(unsigned long, const char *, unsigned long),
	int (*close_fn)(unsigned long),
	void (*log_fn)(int, const char *, int))
{
	unsigned long fp;
	int open_error = 0;
	long written;
	int n;

	if (!val || !path || !path_size || path_size > 2147483647UL ||
	    !open_fn || !write_fn || !close_fn)
		return -EINVAL;

	n = ihk_smp_cpu_online_path_result(path, (long)path_size, cpu_id);
	if (n < 0 || ihk_smp_snprintf_overflow_result(n, (int)path_size)) {
		smp_write_cpu_sys_file_log_model(log_fn, 1, path, n);
		return -1;
	}

	fp = open_fn(path, (unsigned long)&open_error);
	if (!fp) {
		smp_write_cpu_sys_file_log_model(log_fn, 2, path, open_error);
		return -1;
	}

	written = write_fn(fp, val, 1);
	if (written != 1) {
		close_fn(fp);
		smp_write_cpu_sys_file_log_model(log_fn, 3, path,
						 (int)written);
		return -1;
	}

	close_fn(fp);
	return 0;
}

static size_t smp_max_size_mem_chunk_body(struct rb_root *root)
{
	size_t max = 0;
	struct rb_node *node;

	for (node = rb_first(root); node; node = rb_next(node)) {
		struct chunk *chunk = container_of(node, struct chunk, node);

		if (max < chunk->size) {
			max = chunk->size;
		}
	}

	return max;
}

static int smp_mem_chunk_insert_body(struct rb_root *root, struct chunk *chunk)
{
	struct rb_node **iter = &(root->rb_node), *parent = NULL;

	while (*iter) {
		struct chunk *ichunk = container_of(*iter, struct chunk, node);
		parent = *iter;

		if (ichunk->addr + ichunk->size == chunk->addr) {
			struct rb_node *right;

			ichunk->size += chunk->size;
			right = rb_next(*iter);
			if (right) {
				struct chunk *right_chunk =
					container_of(right, struct chunk, node);

				if (ichunk->addr + ichunk->size ==
				    right_chunk->addr) {
					ichunk->size += right_chunk->size;
					rb_erase(right, root);
				}
			}

			return 1;
		}

		if (chunk->addr + chunk->size == ichunk->addr) {
			struct rb_node *left;

			ichunk->addr -= chunk->size;
			ichunk->size += chunk->size;
			left = rb_prev(*iter);
			if (left) {
				struct chunk *left_chunk =
					container_of(left, struct chunk, node);

				if (left_chunk->addr + left_chunk->size ==
				    ichunk->addr) {
					ichunk->addr -= left_chunk->size;
					ichunk->size += left_chunk->size;
					rb_erase(left, root);
				}
			}

			return 2;
		}

		if (chunk->addr < ichunk->addr) {
			iter = &((*iter)->rb_left);
		} else {
			iter = &((*iter)->rb_right);
		}
	}

	rb_link_node_local(&chunk->node, parent, iter);
	rb_insert_color(&chunk->node, root);

	return 0;
}
#else
extern size_t ihk_smp_max_size_mem_chunk_body_result(
	const struct rb_root *root,
	struct rb_node *(*rb_first_fn)(const struct rb_root *),
	struct rb_node *(*rb_next_fn)(const struct rb_node *));
extern int ihk_smp_mem_chunk_insert_body_result(
	struct rb_root *root, struct chunk *chunk,
	struct rb_node *(*rb_next_fn)(const struct rb_node *),
	struct rb_node *(*rb_prev_fn)(const struct rb_node *),
	void (*rb_erase_fn)(struct rb_node *, struct rb_root *),
	void (*rb_link_node_fn)(struct rb_node *, struct rb_node *,
				struct rb_node **),
	void (*rb_insert_color_fn)(struct rb_node *, struct rb_root *));

static size_t smp_max_size_mem_chunk_body(struct rb_root *root)
{
	return ihk_smp_max_size_mem_chunk_body_result(
		root, rb_first_bridge, rb_next_bridge);
}

static int smp_mem_chunk_insert_body(struct rb_root *root, struct chunk *chunk)
{
	return ihk_smp_mem_chunk_insert_body_result(
		root, chunk, rb_next_bridge, rb_prev_bridge, rb_erase_bridge,
		rb_link_node_bridge, rb_insert_color_bridge);
}
#endif

static void init_chunk(struct chunk *chunk, uintptr_t addr, size_t size,
		       int numa_id)
{
	memset(chunk, 0, sizeof(*chunk));
	chunk->addr = addr;
	chunk->size = size;
	chunk->numa_id = numa_id;
}

static int expect_tree(struct rb_root *root, const uintptr_t *addrs,
		       const size_t *sizes, size_t nr, size_t want_max,
		       unsigned long *digest)
{
	struct rb_node *node;
	size_t i = 0;

	for (node = rb_first(root); node; node = rb_next(node)) {
		struct chunk *chunk = container_of(node, struct chunk, node);

		require(i < nr);
		require(chunk->addr == addrs[i]);
		require(chunk->size == sizes[i]);
		mix(digest, chunk->addr);
		mix(digest, chunk->size);
		mix(digest, (unsigned long)(unsigned int)chunk->numa_id);
		i++;
	}

	require(i == nr);
	require(smp_max_size_mem_chunk_body(root) == want_max);
	mix(digest, want_max);
	mix(digest, nr);
	return 0;
}

static int insert_chunk(struct rb_root *root, struct chunk *chunk,
			unsigned long *digest)
{
	int ret = smp_mem_chunk_insert_body(root, chunk);

	require(ret >= 0);
	mix(digest, (unsigned long)(unsigned int)ret);
	return 0;
}

static const struct ihk_smp_collect_cache_topology_offsets topo_offsets = {
	.cpu_cache_topology_list =
		offsetof(struct fake_cpu_topology, cache_topology_list),
	.cache_chain = offsetof(struct fake_cache_topology, chain),
	.cache_index = offsetof(struct fake_cache_topology, index),
	.cache_level = offsetof(struct fake_cache_topology, level),
	.cache_type = offsetof(struct fake_cache_topology, type),
	.cache_size = offsetof(struct fake_cache_topology, size),
	.cache_size_str = offsetof(struct fake_cache_topology, size_str),
	.cache_coherency_line_size =
		offsetof(struct fake_cache_topology, coherency_line_size),
	.cache_number_of_sets =
		offsetof(struct fake_cache_topology, number_of_sets),
	.cache_physical_line_partition =
		offsetof(struct fake_cache_topology, physical_line_partition),
	.cache_ways_of_associativity =
		offsetof(struct fake_cache_topology, ways_of_associativity),
	.cache_shared_cpu_map =
		offsetof(struct fake_cache_topology, shared_cpu_map),
};

static const struct ihk_smp_collect_cpu_topology_offsets cpu_topo_offsets = {
	.cpu_chain = offsetof(struct fake_cpu_topology, chain),
	.cpu_number = offsetof(struct fake_cpu_topology, cpu_number),
	.hw_id = offsetof(struct fake_cpu_topology, hw_id),
	.physical_package_id =
		offsetof(struct fake_cpu_topology, physical_package_id),
	.core_id = offsetof(struct fake_cpu_topology, core_id),
	.core_siblings = offsetof(struct fake_cpu_topology, core_siblings),
	.thread_siblings =
		offsetof(struct fake_cpu_topology, thread_siblings),
	.cache_topology_list =
		offsetof(struct fake_cpu_topology, cache_topology_list),
};

static const struct ihk_smp_collect_node_topology_offsets node_topo_offsets = {
	.node_chain = offsetof(struct fake_node_topology, chain),
	.node_number = offsetof(struct fake_node_topology, node_number),
	.cpumap = offsetof(struct fake_node_topology, cpumap),
};

static const struct ihk_smp_topology_lookup_offsets topo_lookup_offsets = {
	.list_next = offsetof(struct list_head, next),
	.cpu_chain = offsetof(struct fake_cpu_topology, chain),
	.cpu_cpu_number = offsetof(struct fake_cpu_topology, cpu_number),
	.cpu_hw_id = offsetof(struct fake_cpu_topology, hw_id),
	.node_chain = offsetof(struct fake_node_topology, chain),
	.node_node_number = offsetof(struct fake_node_topology, node_number),
};
static const struct ihk_smp_free_info_offsets free_info_offsets = {
	.list_next = offsetof(struct list_head, next),
	.cpu_chain = offsetof(struct fake_cpu_topology, chain),
	.cpu_cache_topology_list =
		offsetof(struct fake_cpu_topology, cache_topology_list),
	.cache_chain = offsetof(struct fake_cache_topology, chain),
	.cache_type = offsetof(struct fake_cache_topology, type),
	.cache_size_str = offsetof(struct fake_cache_topology, size_str),
	.node_chain = offsetof(struct fake_node_topology, chain),
};

static const struct ihk_smp_interrupt_handler_offsets irq_handler_offsets = {
	.list_next = offsetof(struct list_head, next),
	.handler_list = offsetof(struct fake_interrupt_handler, list),
	.handler_func = offsetof(struct fake_interrupt_handler, func),
	.handler_priv = offsetof(struct fake_interrupt_handler, priv),
	.handler_os = offsetof(struct fake_interrupt_handler, os),
	.handler_os_priv = offsetof(struct fake_interrupt_handler, os_priv),
};

static const struct ihk_smp_perf_offsets perf_offsets = {
	.nr_extra_regs = offsetof(struct fake_perf_param, nr_extra_regs),
	.hw_event_map = offsetof(struct fake_perf_param, hw_event_map),
	.hw_cache_event_ids =
		offsetof(struct fake_perf_param, hw_cache_event_ids),
	.hw_cache_extra_regs =
		offsetof(struct fake_perf_param, hw_cache_extra_regs),
	.ereg_event = offsetof(struct fake_perf_param, ereg_event),
	.ereg_msr = offsetof(struct fake_perf_param, ereg_msr),
	.ereg_valid_mask = offsetof(struct fake_perf_param, ereg_valid_mask),
	.ereg_idx = offsetof(struct fake_perf_param, ereg_idx),
	.extra_event = offsetof(struct fake_extra_reg, event),
	.extra_msr = offsetof(struct fake_extra_reg, msr),
	.extra_valid_mask = offsetof(struct fake_extra_reg, valid_mask),
	.extra_idx = offsetof(struct fake_extra_reg, idx),
	.extra_stride = sizeof(struct fake_extra_reg),
};

static const struct ihk_smp_control_offsets control_offsets = {
	.os_lock = offsetof(struct fake_os_data, lock),
	.os_dev = offsetof(struct fake_os_data, dev),
	.os_mem_info = offsetof(struct fake_os_data, mem_info),
	.os_cpu_info = offsetof(struct fake_os_data, cpu_info),
	.os_kernel_args = offsetof(struct fake_os_data, kernel_args),
	.os_nr_numa_nodes = offsetof(struct fake_os_data, nr_numa_nodes),
	.os_nr_cpus = offsetof(struct fake_os_data, nr_cpus),
	.os_bootstrap_numa_id = offsetof(struct fake_os_data,
					 bootstrap_numa_id),
	.os_boot_pt = offsetof(struct fake_os_data, boot_pt),
	.os_status = offsetof(struct fake_os_data, status),
	.mem_info_n_numa_nodes = offsetof(struct fake_mem_info,
					  n_numa_nodes),
	.regdata_priv = offsetof(struct fake_register_os_data, priv),
	.dev_status = offsetof(struct fake_device_data, status),
	.os_cpu_mapping = offsetof(struct fake_os_data, cpu_mapping),
	.os_mem_start = offsetof(struct fake_os_data, mem_start),
	.os_mem_end = offsetof(struct fake_os_data, mem_end),
	.os_boot_rip = offsetof(struct fake_os_data, boot_rip),
};

static const struct ihk_smp_setup_trampoline_offsets setup_trampoline_offsets = {
	.os_param = offsetof(struct fake_trampoline_os, param),
	.os_boot_rip = offsetof(struct fake_trampoline_os, boot_rip),
	.param_ihk_ikc_irq_apicids =
		offsetof(struct fake_trampoline_param, ihk_ikc_irq_apicids),
	.param_ihk_ikc_irq_apicid_stride =
		sizeof(((struct fake_trampoline_param *)0)->ihk_ikc_irq_apicids[0]),
	.param_ihk_ikc_cpu_raised_list =
		offsetof(struct fake_trampoline_param, ihk_ikc_cpu_raised_list),
	.param_ihk_ikc_cpu_raised_list_stride =
		sizeof(((struct fake_trampoline_param *)0)->ihk_ikc_cpu_raised_list[0]),
	.param_ikc_irq_work_func =
		offsetof(struct fake_trampoline_param, ikc_irq_work_func),
	.param_ihk_ikc_irq = offsetof(struct fake_trampoline_param, ihk_ikc_irq),
	.param_page_offset_base =
		offsetof(struct fake_trampoline_param, page_offset_base),
	.param_linux_kernel_pgt_phys =
		offsetof(struct fake_trampoline_param, linux_kernel_pgt_phys),
	.header_page_table = offsetof(struct fake_trampoline_header, page_table),
	.header_next_ip = offsetof(struct fake_trampoline_header, next_ip),
	.header_notify_address =
		offsetof(struct fake_trampoline_header, notify_address),
};

static const struct ihk_smp_setup_startup_offsets setup_startup_offsets = {
	.os_boot_pt = offsetof(struct fake_startup_os, boot_pt),
	.os_bootstrap_mem_end =
		offsetof(struct fake_startup_os, bootstrap_mem_end),
	.os_boot_rip = offsetof(struct fake_startup_os, boot_rip),
};

static const struct ihk_smp_cpu_req_offsets cpu_req_offsets = {
	.cpus = offsetof(struct ihk_cpu_req, cpus),
	.num_cpus = offsetof(struct ihk_cpu_req, num_cpus),
};

static const struct ihk_smp_ikc_req_offsets ikc_req_offsets = {
	.src_cpus = offsetof(struct ihk_ikc_req, src_cpus),
	.dst_cpus = offsetof(struct ihk_ikc_req, dst_cpus),
	.num_cpus = offsetof(struct ihk_ikc_req, num_cpus),
};

static const struct ihk_smp_set_ikc_map_offsets set_ikc_offsets = {
	.os_lock = offsetof(struct fake_os_data, lock),
	.os_status = offsetof(struct fake_os_data, status),
	.os_cpu_ikc_mapped = offsetof(struct fake_os_data, cpu_ikc_mapped),
	.req_src_cpus = offsetof(struct ihk_ikc_req, src_cpus),
	.req_dst_cpus = offsetof(struct ihk_ikc_req, dst_cpus),
	.req_num_cpus = offsetof(struct ihk_ikc_req, num_cpus),
	.cpu_status = offsetof(struct fake_smp_cpu, status),
	.cpu_os = offsetof(struct fake_smp_cpu, os),
	.cpu_ikc_map_cpu = offsetof(struct fake_smp_cpu, ikc_map_cpu),
};

static const struct ihk_smp_mem_req_offsets mem_req_offsets = {
	.sizes = offsetof(struct ihk_mem_req, sizes),
	.numa_ids = offsetof(struct ihk_mem_req, numa_ids),
	.num_chunks = offsetof(struct ihk_mem_req, num_chunks),
	.min_chunk_size = offsetof(struct ihk_mem_req, min_chunk_size),
	.max_size_ratio_all = offsetof(struct ihk_mem_req, max_size_ratio_all),
};

static const struct ihk_smp_mem_query_offsets free_mem_query_offsets = {
	.list_next = offsetof(struct list_head, next),
	.entry_list = offsetof(struct fake_mem_chunk, chain),
	.entry_size = offsetof(struct fake_mem_chunk, size),
	.entry_numa_id = offsetof(struct fake_mem_chunk, numa_id),
	.entry_os = 0,
};

static const struct ihk_smp_mem_query_offsets os_mem_query_offsets = {
	.list_next = offsetof(struct list_head, next),
	.entry_list = offsetof(struct fake_os_mem_chunk, list),
	.entry_size = offsetof(struct fake_os_mem_chunk, size),
	.entry_numa_id = offsetof(struct fake_os_mem_chunk, numa_id),
	.entry_os = offsetof(struct fake_os_mem_chunk, os),
};

static const struct ihk_smp_map_virtual_list_offsets map_virtual_offsets = {
	.list_next = offsetof(struct list_head, next),
	.entry_list = offsetof(struct fake_os_mem_chunk, list),
	.entry_addr = offsetof(struct fake_os_mem_chunk, addr),
	.entry_size = offsetof(struct fake_os_mem_chunk, size),
};

static int control_lock_calls;
static int control_unlock_calls;
static int control_spin_init_calls;
static unsigned long control_last_lock;
static unsigned long control_last_unlock;
static int control_log_event;
static const char *control_log_args;
static int control_issue_calls;
static unsigned long control_issue_os;
static unsigned long control_issue_priv;
static int control_issue_cpu;
static int control_issue_vector;
static int control_send_calls;
static int control_send_mode;
static int control_set_mode_calls;
static int control_set_mode_fail;
static unsigned long control_set_mode_os;
static unsigned long control_set_mode_priv;
static int control_set_mode_mode;
static unsigned long control_unmap_virt;
static int control_unmap_calls;
static int control_flush_calls;
static unsigned long control_flush_virt;
static unsigned long control_flush_size;
static unsigned long control_map_result_base;
static int control_map_calls;
static int control_map_fail_at;
static unsigned long control_map_phys[4];
static unsigned long control_map_size[4];
static int control_host_map_calls;
static unsigned long control_host_map_dev;
static unsigned long control_host_map_phys;
static unsigned long control_host_map_virt;
static unsigned long control_host_map_size;
static int control_host_map_flags;
static int control_map_log_event;
static unsigned long control_map_log_phys;
static unsigned long control_map_log_size;
static int control_phys_to_virt_calls;
static unsigned long control_phys_to_virt_phys;
static int control_vtop_calls;
static unsigned long control_vtop_arg;
static int control_vtop_log_event;
static unsigned long control_vtop_log_virt;
static unsigned long control_vtop_log_phys;
static int control_load_copy_calls;
static unsigned long control_load_copy_dst[4];
static unsigned long control_load_copy_size[4];
static char control_load_pages[2][4096];
static int control_load_log_event;
static unsigned long control_load_log_a;
static unsigned long control_load_log_b;
static unsigned long control_load_log_c;
static unsigned long control_load_log_d;
static int control_irq_save_calls;
static int control_irq_restore_calls;
static unsigned long control_irq_restore_flags;
static int control_x2apic_enabled;
static int control_x2apic_enabled_calls;
static int control_x2apic_wait_calls;
static int control_x2apic_write_calls;
static int control_x2apic_vector;
static int control_x2apic_hw_id;
static int control_legacy_ipi_calls;
static int control_legacy_hw_id;
static int control_legacy_vector;
static int control_legacy_dest;
static int control_perf_log_calls;
static int control_perf_log_event;
static int control_perf_log_value;
static int control_irq_work_calls;
static int control_irq_work_irq;
static void *control_irq_work_data;
static int control_irq_work_ret;
static int irq_handler_calls;
static unsigned long irq_handler_os[4];
static unsigned long irq_handler_os_priv[4];
static unsigned long irq_handler_priv[4];
static int irq_no_handler_log_calls;
static int control_free_calls;
static int control_create_log_event;
static int control_alloc_fail;
static void *control_last_alloc;
static int smp_copy_to_calls;
static int smp_copy_to_fail;
static int smp_copy_from_calls;
static int smp_copy_from_fail;
static int smp_alloc_calls;
static int smp_alloc_fail;
static int smp_free_calls;
static int smp_query_log_event;
static int smp_query_log_requested;
static int smp_query_log_actual;
static int smp_set_ikc_log_event;
static int smp_set_ikc_log_value0;
static int smp_set_ikc_log_value1;
static int smp_set_ikc_route_count;
static int smp_set_ikc_route_cpu[8];
static int smp_set_ikc_route_dst[8];
static int smp_cpu_present_mask[8];
static int smp_cpu_online_mask[8];
static int smp_check_ikc_calls;
static int smp_check_ikc_result;
static int smp_init_zero_calls;
static unsigned long smp_init_zero_ptr[4];
static unsigned long smp_init_zero_size[4];
static int smp_init_online_count;
static int smp_init_online_cpus[8];
static int smp_init_for_each_calls;
static int smp_init_arch_calls;
static int smp_init_arch_ret;
static int smp_init_log_present;
static int smp_exit_arch_calls;
static int smp_exit_reset_calls;
static int smp_exit_reset_hw_id[8];
static int smp_exit_reset_ret[8];
static int smp_exit_online_calls;
static int smp_exit_online_cpu[8];
static int smp_exit_online_ret[8];
static int smp_exit_free_list_calls;
static unsigned long smp_exit_free_list_arg;
static int smp_exit_free_info_calls;
static int smp_exit_log_calls;
static int smp_exit_log_cpu_id[8];
static int smp_exit_log_hw_id[8];
static int smp_module_symbols_calls;
static int smp_module_symbols_ret;
static int smp_module_arch_symbols_calls;
static int smp_module_arch_symbols_ret;
static int smp_module_lock_init_calls;
static unsigned long smp_module_lock_arg;
static int smp_module_register_calls;
static unsigned long smp_module_register_arg;
static unsigned long smp_module_register_ret;
static int smp_module_unregister_calls;
static unsigned long smp_module_unregister_arg;
static int smp_module_log_count;
static int smp_module_log_event[8];
static int reset_event_seq;
static int reset_preempt_disable_calls;
static int reset_preempt_enable_calls;
static int reset_preempt_disable_event;
static int reset_preempt_enable_event;
static int reset_get_maxlvt_calls;
static int reset_get_maxlvt_event;
static int reset_maxlvt;
static int reset_integrated;
static int reset_integrated_calls;
static int reset_integrated_event;
static int reset_integrated_phys;
static int reset_apic_write_count;
static int reset_apic_write_event[8];
static int reset_apic_write_regs[8];
static unsigned int reset_apic_write_values[8];
static int reset_apic_read_count;
static int reset_apic_read_event[8];
static int reset_apic_read_regs[8];
static unsigned int reset_apic_read_value;
static int reset_icr_write_count;
static int reset_icr_write_event[8];
static unsigned int reset_icr_write_values[8];
static int reset_icr_write_phys[8];
static int reset_wait_count;
static int reset_wait_event[8];
static unsigned long reset_wait_value;
static unsigned long reset_wait_values[8];
static int reset_wait_use_sequence;
static int reset_delay_count;
static int reset_delay_event;
static unsigned long reset_delay_msecs;
static int reset_udelay_count;
static int reset_udelay_event[8];
static unsigned long reset_udelay_usecs[8];
static int reset_barrier_calls;
static int reset_barrier_event;
static int reset_init_deasserted_calls;
static int reset_init_deasserted_event;
static int wakeup_non_unique;
static int wakeup_non_unique_calls;
static int wakeup_non_unique_event;
static int wakeup_setup_calls;
static int wakeup_setup_event;
static unsigned long wakeup_setup_start_eip;
static int wakeup_apic_available;
static int wakeup_apic_available_calls;
static int wakeup_apic_available_event;
static int wakeup_apic_calls;
static int wakeup_apic_event;
static int wakeup_apic_apicid;
static unsigned long wakeup_apic_start_eip;
static int wakeup_apic_ret;
static int wakeup_via_calls;
static int wakeup_via_event;
static int wakeup_via_apicid;
static unsigned long wakeup_via_start_eip;
static int wakeup_via_ret;
static int wakeup_top_log_count;
static int wakeup_top_log_event[8];
static int warm_lock_calls;
static int warm_lock_event;
static unsigned long warm_lock_flags;
static int warm_cmos_calls;
static int warm_cmos_event;
static unsigned char warm_cmos_value;
static unsigned char warm_cmos_reg;
static int warm_unlock_calls;
static int warm_unlock_event;
static unsigned long warm_unlock_flags;
static int warm_flush_calls;
static int warm_flush_event;
static int warm_write_count;
static int warm_write_event[4];
static unsigned long warm_write_phys[4];
static unsigned short warm_write_value[4];
static int setup_apicid_calls;
static int setup_raised_calls;
static int setup_log_calls;
static int setup_log_event;
static unsigned long setup_log_value0;
static unsigned long setup_log_value1;
static int startup_alloc_calls;
static unsigned long startup_alloc_result;
static int startup_phys_calls;
static unsigned long startup_last_phys_virt;
static int startup_map_calls;
static int startup_map_fail_at;
static unsigned long startup_map_pt[16];
static unsigned long startup_map_virt[16];
static unsigned long startup_map_phys[16];
static int startup_map_virtual_calls;
static unsigned long startup_map_virtual_phys;
static unsigned long startup_map_virtual_size;
static unsigned long startup_map_virtual_result;
static int startup_unmap_calls;
static unsigned long startup_unmap_virt;
static int startup_log_event;
static int arch_init_ioremap_calls;
static unsigned long arch_init_ioremap_phys;
static unsigned long arch_init_ioremap_size;
static int arch_init_alloc_calls;
static unsigned long arch_init_alloc_sequence[8];
static int arch_init_page_phys_calls;
static unsigned long arch_init_page_phys_arg[16];
static int arch_init_page_virt_calls;
static unsigned long arch_init_page_virt_arg[16];
static int arch_init_free_calls;
static unsigned long arch_init_free_page[8];
static unsigned int arch_init_free_order[8];
static int arch_init_linux_phys_calls;
static unsigned long arch_init_linux_phys;
static int arch_init_direct_virt_calls;
static unsigned long arch_init_direct_virt_phys;
static int arch_init_log_count;
static int arch_init_log_event[8];
static unsigned long arch_init_log_value[8];
static int arch_init_tail_ident_calls;
static int arch_init_tail_ident_result;
static int arch_init_tail_topology_calls;
static int arch_init_tail_topology_result;
static int arch_init_tail_log_count;
static int arch_init_tail_log_event[8];
static int arch_init_tail_log_value[8];
static unsigned long ident_alloc_result;
static int ident_alloc_calls;
static unsigned int ident_alloc_order;
static int ident_page_phys_calls;
static unsigned long ident_page_phys_arg;
static unsigned long ident_page_phys_result;
static int ident_page_virt_calls;
static unsigned long ident_page_virt_arg;
static unsigned long ident_page_virt_result;
static int ident_zero_calls;
static unsigned long ident_zero_addr;
static unsigned long ident_zero_len;
static int ident_log_count;
static int ident_log_event[8];
static unsigned long ident_log_value0[8];
static unsigned long ident_log_value1[8];
static int reset_log_count;
static int reset_log_event[16];
static unsigned long reset_log_value[16];
static int reset_log_phys[16];
static int exit_event_seq;
static int exit_free_trampoline_calls;
static int exit_free_trampoline_event;
static unsigned long exit_free_trampoline_page;
static unsigned int exit_free_trampoline_order;
static int exit_unmap_calls;
static int exit_unmap_event;
static unsigned long exit_unmap_virt;
static int exit_free_pages_calls;
static int exit_free_pages_event;
static unsigned long exit_free_pages_addr;
static unsigned int exit_free_pages_order;

static int topo_alloc_fail_after = -1;
static int topo_alloc_calls;
static int topo_free_calls;
static int topo_file_readable = 1;
static const char *topo_fail_leaf;
static int topo_fail_error = -5;
static int topo_log_event;
static int topo_log_error;
static int topo_collect_cache_calls;
static int topo_collect_cache_fail_index = -1;
static int topo_collect_cache_last_index = -1;
static int topo_node_fail_error;
static int topo_log_count;
static int topo_log_events[8];
static int topo_log_errors[8];
static int topo_online_cpus[8];
static int topo_online_cpu_count;
static int topo_online_nodes[8];
static int topo_online_node_count;
static int topo_next_cpu_calls;
static int topo_next_node_calls;
static int topo_collect_cpu_calls;
static int topo_collect_node_calls;
static int topo_collected_cpus[8];
static int topo_collected_nodes[8];
static int topo_collect_cpu_fail_at;
static int topo_collect_node_fail_at;
static int free_info_list_del_calls;
static int free_info_log_calls;
static int free_info_log_events[4];
static char read_long_page[4096];
static int read_long_alloc_fail;
static int read_long_alloc_calls;
static int read_long_read_calls;
static int read_long_read_result;
static unsigned long read_long_read_buf;
static unsigned long read_long_read_size;
static char *read_long_read_fmt;
static unsigned long read_long_read_va;
static int read_long_parse_calls;
static int read_long_parse_result;
static long read_long_parse_value;
static int read_long_free_calls;
static unsigned long read_long_free_addr;
static int read_long_log_calls;
static int read_long_log_event[8];
static int read_long_log_error[8];
static unsigned long read_bitmap_map_words[4];
static int read_bitmap_alloc_fail;
static int read_bitmap_alloc_calls;
static int read_bitmap_read_calls;
static int read_bitmap_read_result;
static unsigned long read_bitmap_read_buf;
static unsigned long read_bitmap_read_size;
static char *read_bitmap_read_fmt;
static unsigned long read_bitmap_read_va;
static int read_bitmap_parse_calls;
static int read_bitmap_parse_result;
static unsigned long read_bitmap_parse_buf;
static unsigned long read_bitmap_parse_size;
static unsigned long read_bitmap_parse_map;
static int read_bitmap_parse_nbits;
static int read_bitmap_free_calls;
static unsigned long read_bitmap_free_addr;
static int read_bitmap_log_calls;
static int read_bitmap_log_event[8];
static int read_bitmap_log_error[8];
static char *read_string_value;
static int read_string_alloc_fail;
static int read_string_alloc_calls;
static int read_string_read_calls;
static int read_string_read_result;
static unsigned long read_string_read_buf;
static unsigned long read_string_read_size;
static char *read_string_read_fmt;
static unsigned long read_string_read_va;
static int read_string_dup_calls;
static int read_string_dup_fail;
static unsigned long read_string_dup_buf;
static int read_string_kfree_calls;
static unsigned long read_string_kfree_addr;
static int read_string_free_calls;
static unsigned long read_string_free_addr;
static int read_string_log_calls;
static int read_string_log_event[8];
static int read_string_log_error[8];
static char file_readable_filename[128];
static int file_readable_alloc_fail;
static int file_readable_alloc_calls;
static unsigned long file_readable_alloc_size;
static int file_readable_vsnprintf_calls;
static int file_readable_vsnprintf_result;
static char *file_readable_vsnprintf_fmt;
static unsigned long file_readable_vsnprintf_size;
static unsigned long file_readable_vsnprintf_va;
static int file_readable_open_calls;
static int file_readable_open_fail;
static char *file_readable_open_filename;
static int file_readable_close_calls;
static unsigned long file_readable_close_file;
static int file_readable_free_calls;
static unsigned long file_readable_free_addr;
static int file_readable_log_calls;
static int file_readable_log_event[4];
static int file_readable_log_error[4];
static char read_file_buf[32];
static char read_file_filename[128];
static int read_file_alloc_fail;
static int read_file_alloc_calls;
static unsigned long read_file_alloc_size;
static int read_file_vsnprintf_calls;
static int read_file_vsnprintf_result;
static char *read_file_vsnprintf_fmt;
static unsigned long read_file_vsnprintf_size;
static unsigned long read_file_vsnprintf_va;
static int read_file_open_calls;
static int read_file_open_fail;
static int read_file_open_error;
static char *read_file_open_filename;
static unsigned long read_file_open_errorp;
static int read_file_kernel_read_calls;
static long read_file_kernel_read_result;
static unsigned long read_file_kernel_file;
static unsigned long read_file_kernel_buf;
static unsigned long read_file_kernel_size;
static int read_file_close_calls;
static int read_file_close_result;
static unsigned long read_file_close_file;
static int read_file_free_calls;
static unsigned long read_file_free_addr;
static int read_file_log_calls;
static int read_file_log_event[8];
static int read_file_log_error[8];
static int write_cpu_open_calls;
static int write_cpu_open_fail;
static int write_cpu_open_error;
static char *write_cpu_open_path;
static unsigned long write_cpu_open_errorp;
static int write_cpu_write_calls;
static long write_cpu_write_result;
static unsigned long write_cpu_write_file;
static const char *write_cpu_write_buf;
static unsigned long write_cpu_write_size;
static int write_cpu_close_calls;
static unsigned long write_cpu_close_file;
static int write_cpu_log_calls;
static int write_cpu_log_event[4];
static int write_cpu_log_error[4];
static const char *write_cpu_log_path[4];

static void init_list_head(struct list_head *head)
{
	head->next = head;
	head->prev = head;
}

static int list_empty(const struct list_head *head)
{
	return head->next == head;
}

static void topo_list_add_tail(struct list_head *new, struct list_head *head)
{
	struct list_head *prev = head->prev;

	new->next = head;
	new->prev = prev;
	prev->next = new;
	head->prev = new;
}

static void topo_list_del(struct list_head *entry)
{
	struct list_head *prev = entry->prev;
	struct list_head *next = entry->next;

	next->prev = prev;
	prev->next = next;
	entry->next = (void *)0x00100129;
	entry->prev = (void *)0x00200229;
}

static void *topo_alloc_common(size_t size, int zero)
{
	void *ptr;

	topo_alloc_calls++;
	if (topo_alloc_fail_after >= 0 &&
	    topo_alloc_calls > topo_alloc_fail_after) {
		return NULL;
	}
	ptr = malloc(size);
	if (ptr && zero)
		memset(ptr, 0, size);
	return ptr;
}

static void *fake_topo_alloc(size_t size)
{
	return topo_alloc_common(size, 0);
}

static void *fake_topo_zalloc(size_t size)
{
	return topo_alloc_common(size, 1);
}

static void fake_topo_free(void *ptr)
{
	if (ptr)
		topo_free_calls++;
	free(ptr);
}

static int fake_topo_file_readable(const char *prefix, const char *leaf)
{
	require(prefix != NULL);
	require(strstr(prefix, "/cache/index") != NULL);
	require(!strcmp(leaf, "level"));
	return topo_file_readable;
}

static int topo_leaf_failed(const char *leaf)
{
	return topo_fail_leaf && !strcmp(topo_fail_leaf, leaf);
}

static int fake_topo_read_long(long *valuep, const char *prefix,
			       const char *leaf)
{
	require(prefix != NULL);
	if (topo_leaf_failed(leaf))
		return topo_fail_error;
	if (!strcmp(leaf, "level"))
		*valuep = 3;
	else if (!strcmp(leaf, "size"))
		*valuep = 48;
	else if (!strcmp(leaf, "coherency_line_size"))
		*valuep = 64;
	else if (!strcmp(leaf, "number_of_sets"))
		*valuep = 1024;
	else if (!strcmp(leaf, "physical_line_partition"))
		*valuep = 1;
	else if (!strcmp(leaf, "ways_of_associativity"))
		*valuep = 12;
	else if (!strcmp(leaf, "topology/core_id"))
		*valuep = 8;
	else if (!strcmp(leaf, "topology/physical_package_id"))
		*valuep = 2;
	else
		return -9;
	return 0;
}

static char *topo_dup_string(const char *src)
{
	size_t len = strlen(src) + 1;
	char *dst = malloc(len);

	if (!dst)
		return NULL;
	memcpy(dst, src, len);
	return dst;
}

static int fake_topo_read_string(char **valuep, const char *prefix,
				 const char *leaf)
{
	require(prefix != NULL);
	if (topo_leaf_failed(leaf))
		return topo_fail_error;
	if (!strcmp(leaf, "type"))
		*valuep = topo_dup_string("Unified");
	else if (!strcmp(leaf, "size"))
		*valuep = topo_dup_string("48K");
	else
		return -9;
	return *valuep ? 0 : -ENOMEM;
}

static int fake_topo_read_bitmap(void *map, int nbits, const char *prefix,
				 const char *leaf)
{
	unsigned long *words = map;

	require(prefix != NULL);
	require(nbits == 128);
	if (topo_leaf_failed(leaf))
		return topo_fail_error;
	if (!strcmp(leaf, "shared_cpu_map")) {
		words[0] = 0x5;
		words[1] = 0x10;
	} else if (!strcmp(leaf, "topology/core_siblings")) {
		words[0] = 0xaa;
		words[1] = 0x40;
	} else if (!strcmp(leaf, "topology/thread_siblings")) {
		words[0] = 0x55;
		words[1] = 0x20;
	} else {
		return -9;
	}
	return 0;
}

static void fake_topo_init_list_head(void *head)
{
	init_list_head(head);
}

static int fake_topo_get_hw_id(int cpu)
{
	return 1000 + cpu;
}

static int fake_topo_collect_cache(void *cpu_topo, int index)
{
	require(cpu_topo != NULL);
	topo_collect_cache_calls++;
	topo_collect_cache_last_index = index;
	if (index == topo_collect_cache_fail_index)
		return topo_fail_error;
	return 0;
}

static int fake_topo_read_node_cpumap(void *map, int nbits, int node)
{
	unsigned long *words = map;

	require(map != NULL);
	require(nbits == 128);
	if (topo_node_fail_error)
		return topo_node_fail_error;
	words[0] = 0x100UL | (unsigned long)node;
	words[1] = 0x200UL | (unsigned long)node;
	return 0;
}

static void fake_topo_list_add(void *node, void *head)
{
	struct list_head *new_node = node;
	struct list_head *head_node = head;

	new_node->next = head_node->next;
	new_node->prev = head_node;
	head_node->next->prev = new_node;
	head_node->next = new_node;
}

static void fake_topo_log(int event, int error)
{
	topo_log_event = event;
	topo_log_error = error;
	if (topo_log_count < (int)(sizeof(topo_log_events) /
				   sizeof(topo_log_events[0]))) {
		topo_log_events[topo_log_count] = event;
		topo_log_errors[topo_log_count] = error;
	}
	topo_log_count++;
}

static void reset_cpu_trace(void)
{
	reset_event_seq = 0;
	reset_preempt_disable_calls = 0;
	reset_preempt_enable_calls = 0;
	reset_preempt_disable_event = 0;
	reset_preempt_enable_event = 0;
	reset_get_maxlvt_calls = 0;
	reset_get_maxlvt_event = 0;
	reset_maxlvt = 0;
	reset_integrated = 0;
	reset_integrated_calls = 0;
	reset_integrated_event = 0;
	reset_integrated_phys = 0;
	reset_apic_write_count = 0;
	memset(reset_apic_write_event, 0, sizeof(reset_apic_write_event));
	memset(reset_apic_write_regs, 0, sizeof(reset_apic_write_regs));
	memset(reset_apic_write_values, 0, sizeof(reset_apic_write_values));
	reset_apic_read_count = 0;
	memset(reset_apic_read_event, 0, sizeof(reset_apic_read_event));
	memset(reset_apic_read_regs, 0, sizeof(reset_apic_read_regs));
	reset_apic_read_value = 0x5aU;
	reset_icr_write_count = 0;
	memset(reset_icr_write_event, 0, sizeof(reset_icr_write_event));
	memset(reset_icr_write_values, 0, sizeof(reset_icr_write_values));
	memset(reset_icr_write_phys, 0, sizeof(reset_icr_write_phys));
	reset_wait_count = 0;
	memset(reset_wait_event, 0, sizeof(reset_wait_event));
	reset_wait_value = 0x6000UL;
	memset(reset_wait_values, 0, sizeof(reset_wait_values));
	reset_wait_use_sequence = 0;
	reset_delay_count = 0;
	reset_delay_event = 0;
	reset_delay_msecs = 0;
	reset_udelay_count = 0;
	memset(reset_udelay_event, 0, sizeof(reset_udelay_event));
	memset(reset_udelay_usecs, 0, sizeof(reset_udelay_usecs));
	reset_barrier_calls = 0;
	reset_barrier_event = 0;
	reset_init_deasserted_calls = 0;
	reset_init_deasserted_event = 0;
	wakeup_non_unique = 0;
	wakeup_non_unique_calls = 0;
	wakeup_non_unique_event = 0;
	wakeup_setup_calls = 0;
	wakeup_setup_event = 0;
	wakeup_setup_start_eip = 0;
	wakeup_apic_available = 0;
	wakeup_apic_available_calls = 0;
	wakeup_apic_available_event = 0;
	wakeup_apic_calls = 0;
	wakeup_apic_event = 0;
	wakeup_apic_apicid = 0;
	wakeup_apic_start_eip = 0;
	wakeup_apic_ret = 0;
	wakeup_via_calls = 0;
	wakeup_via_event = 0;
	wakeup_via_apicid = 0;
	wakeup_via_start_eip = 0;
	wakeup_via_ret = 0;
	wakeup_top_log_count = 0;
	memset(wakeup_top_log_event, 0, sizeof(wakeup_top_log_event));
	warm_lock_calls = 0;
	warm_lock_event = 0;
	warm_lock_flags = 0x123abcUL;
	warm_cmos_calls = 0;
	warm_cmos_event = 0;
	warm_cmos_value = 0;
	warm_cmos_reg = 0;
	warm_unlock_calls = 0;
	warm_unlock_event = 0;
	warm_unlock_flags = 0;
	warm_flush_calls = 0;
	warm_flush_event = 0;
	warm_write_count = 0;
	memset(warm_write_event, 0, sizeof(warm_write_event));
	memset(warm_write_phys, 0, sizeof(warm_write_phys));
	memset(warm_write_value, 0, sizeof(warm_write_value));
	setup_apicid_calls = 0;
	setup_raised_calls = 0;
	setup_log_calls = 0;
	setup_log_event = 0;
	setup_log_value0 = 0;
	setup_log_value1 = 0;
	startup_alloc_calls = 0;
	startup_alloc_result = 0xabcdef000UL;
	startup_phys_calls = 0;
	startup_last_phys_virt = 0;
	startup_map_calls = 0;
	startup_map_fail_at = 0;
	memset(startup_map_pt, 0, sizeof(startup_map_pt));
	memset(startup_map_virt, 0, sizeof(startup_map_virt));
	memset(startup_map_phys, 0, sizeof(startup_map_phys));
	startup_map_virtual_calls = 0;
	startup_map_virtual_phys = 0;
	startup_map_virtual_size = 0;
	startup_map_virtual_result = 0;
	startup_unmap_calls = 0;
	startup_unmap_virt = 0;
	startup_log_event = 0;
	arch_init_ioremap_calls = 0;
	arch_init_ioremap_phys = 0;
	arch_init_ioremap_size = 0;
	arch_init_alloc_calls = 0;
	memset(arch_init_alloc_sequence, 0, sizeof(arch_init_alloc_sequence));
	arch_init_page_phys_calls = 0;
	memset(arch_init_page_phys_arg, 0, sizeof(arch_init_page_phys_arg));
	arch_init_page_virt_calls = 0;
	memset(arch_init_page_virt_arg, 0, sizeof(arch_init_page_virt_arg));
	arch_init_free_calls = 0;
	memset(arch_init_free_page, 0, sizeof(arch_init_free_page));
	memset(arch_init_free_order, 0, sizeof(arch_init_free_order));
	arch_init_linux_phys_calls = 0;
	arch_init_linux_phys = 0x9f000UL;
	arch_init_direct_virt_calls = 0;
	arch_init_direct_virt_phys = 0;
	arch_init_log_count = 0;
	memset(arch_init_log_event, 0, sizeof(arch_init_log_event));
	memset(arch_init_log_value, 0, sizeof(arch_init_log_value));
	arch_init_tail_ident_calls = 0;
	arch_init_tail_ident_result = 0;
	arch_init_tail_topology_calls = 0;
	arch_init_tail_topology_result = 0;
	arch_init_tail_log_count = 0;
	memset(arch_init_tail_log_event, 0, sizeof(arch_init_tail_log_event));
	memset(arch_init_tail_log_value, 0, sizeof(arch_init_tail_log_value));
	ident_alloc_result = 0xabc0UL;
	ident_alloc_calls = 0;
	ident_alloc_order = 0;
	ident_page_phys_calls = 0;
	ident_page_phys_arg = 0;
	ident_page_phys_result = 0x400000UL;
	ident_page_virt_calls = 0;
	ident_page_virt_arg = 0;
	ident_page_virt_result = 0;
	ident_zero_calls = 0;
	ident_zero_addr = 0;
	ident_zero_len = 0;
	ident_log_count = 0;
	memset(ident_log_event, 0, sizeof(ident_log_event));
	memset(ident_log_value0, 0, sizeof(ident_log_value0));
	memset(ident_log_value1, 0, sizeof(ident_log_value1));
	reset_log_count = 0;
	memset(reset_log_event, 0, sizeof(reset_log_event));
	memset(reset_log_value, 0, sizeof(reset_log_value));
	memset(reset_log_phys, 0, sizeof(reset_log_phys));
}

static void reset_arch_exit_trace(void)
{
	exit_event_seq = 0;
	exit_free_trampoline_calls = 0;
	exit_free_trampoline_event = 0;
	exit_free_trampoline_page = 0;
	exit_free_trampoline_order = 0;
	exit_unmap_calls = 0;
	exit_unmap_event = 0;
	exit_unmap_virt = 0;
	exit_free_pages_calls = 0;
	exit_free_pages_event = 0;
	exit_free_pages_addr = 0;
	exit_free_pages_order = 0;
}

static void reset_control_trace(void)
{
	control_lock_calls = 0;
	control_unlock_calls = 0;
	control_spin_init_calls = 0;
	control_last_lock = 0;
	control_last_unlock = 0;
	control_log_event = 0;
	control_log_args = NULL;
	control_issue_calls = 0;
	control_issue_os = 0;
	control_issue_priv = 0;
	control_issue_cpu = 0;
	control_issue_vector = 0;
	control_send_calls = 0;
	control_send_mode = 0;
	control_set_mode_calls = 0;
	control_set_mode_fail = 0;
	control_set_mode_os = 0;
	control_set_mode_priv = 0;
	control_set_mode_mode = 0;
	control_unmap_virt = 0;
	control_unmap_calls = 0;
	control_flush_calls = 0;
	control_flush_virt = 0;
	control_flush_size = 0;
	control_map_result_base = 0;
	control_map_calls = 0;
	control_map_fail_at = 0;
	memset(control_map_phys, 0, sizeof(control_map_phys));
	memset(control_map_size, 0, sizeof(control_map_size));
	control_host_map_calls = 0;
	control_host_map_dev = 0;
	control_host_map_phys = 0;
	control_host_map_virt = 0;
	control_host_map_size = 0;
	control_host_map_flags = 0;
	control_map_log_event = 0;
	control_map_log_phys = 0;
	control_map_log_size = 0;
	control_phys_to_virt_calls = 0;
	control_phys_to_virt_phys = 0;
	control_vtop_calls = 0;
	control_vtop_arg = 0;
	control_vtop_log_event = 0;
	control_vtop_log_virt = 0;
	control_vtop_log_phys = 0;
	control_load_copy_calls = 0;
	memset(control_load_copy_dst, 0, sizeof(control_load_copy_dst));
	memset(control_load_copy_size, 0, sizeof(control_load_copy_size));
	memset(control_load_pages, 0, sizeof(control_load_pages));
	control_load_log_event = 0;
	control_load_log_a = 0;
	control_load_log_b = 0;
	control_load_log_c = 0;
	control_load_log_d = 0;
	control_irq_save_calls = 0;
	control_irq_restore_calls = 0;
	control_irq_restore_flags = 0;
	control_x2apic_enabled = 0;
	control_x2apic_enabled_calls = 0;
	control_x2apic_wait_calls = 0;
	control_x2apic_write_calls = 0;
	control_x2apic_vector = 0;
	control_x2apic_hw_id = 0;
	control_legacy_ipi_calls = 0;
	control_legacy_hw_id = 0;
	control_legacy_vector = 0;
	control_legacy_dest = 0;
	control_perf_log_calls = 0;
	control_perf_log_event = 0;
	control_perf_log_value = 0;
	control_irq_work_calls = 0;
	control_irq_work_irq = 0;
	control_irq_work_data = NULL;
	control_irq_work_ret = 0;
	control_free_calls = 0;
	control_create_log_event = 0;
	control_alloc_fail = 0;
	control_last_alloc = NULL;
	smp_copy_to_calls = 0;
	smp_copy_to_fail = 0;
	smp_copy_from_calls = 0;
	smp_copy_from_fail = 0;
	smp_alloc_calls = 0;
	smp_alloc_fail = 0;
	smp_free_calls = 0;
	smp_query_log_event = 0;
	smp_query_log_requested = 0;
	smp_query_log_actual = 0;
	smp_set_ikc_log_event = 0;
	smp_set_ikc_log_value0 = 0;
	smp_set_ikc_log_value1 = 0;
	smp_set_ikc_route_count = 0;
	memset(smp_set_ikc_route_cpu, 0, sizeof(smp_set_ikc_route_cpu));
	memset(smp_set_ikc_route_dst, 0, sizeof(smp_set_ikc_route_dst));
	memset(smp_cpu_present_mask, 0, sizeof(smp_cpu_present_mask));
	memset(smp_cpu_online_mask, 0, sizeof(smp_cpu_online_mask));
	smp_check_ikc_calls = 0;
	smp_check_ikc_result = 0;
	smp_init_zero_calls = 0;
	memset(smp_init_zero_ptr, 0, sizeof(smp_init_zero_ptr));
	memset(smp_init_zero_size, 0, sizeof(smp_init_zero_size));
	smp_init_online_count = 0;
	memset(smp_init_online_cpus, 0, sizeof(smp_init_online_cpus));
	smp_init_for_each_calls = 0;
	smp_init_arch_calls = 0;
	smp_init_arch_ret = 0;
	smp_init_log_present = 0;
	smp_exit_arch_calls = 0;
	smp_exit_reset_calls = 0;
	memset(smp_exit_reset_hw_id, 0, sizeof(smp_exit_reset_hw_id));
	memset(smp_exit_reset_ret, 0, sizeof(smp_exit_reset_ret));
	smp_exit_online_calls = 0;
	memset(smp_exit_online_cpu, 0, sizeof(smp_exit_online_cpu));
	memset(smp_exit_online_ret, 0, sizeof(smp_exit_online_ret));
	smp_exit_free_list_calls = 0;
	smp_exit_free_list_arg = 0;
	smp_exit_free_info_calls = 0;
	smp_exit_log_calls = 0;
	memset(smp_exit_log_cpu_id, 0, sizeof(smp_exit_log_cpu_id));
	memset(smp_exit_log_hw_id, 0, sizeof(smp_exit_log_hw_id));
	smp_module_symbols_calls = 0;
	smp_module_symbols_ret = 0;
	smp_module_arch_symbols_calls = 0;
	smp_module_arch_symbols_ret = 0;
	smp_module_lock_init_calls = 0;
	smp_module_lock_arg = 0;
	smp_module_register_calls = 0;
	smp_module_register_arg = 0;
	smp_module_register_ret = 0;
	smp_module_unregister_calls = 0;
	smp_module_unregister_arg = 0;
	smp_module_log_count = 0;
	memset(smp_module_log_event, 0, sizeof(smp_module_log_event));
}

static void fake_reset_preempt_disable(void)
{
	reset_preempt_disable_calls++;
	reset_preempt_disable_event = ++reset_event_seq;
}

static void fake_reset_preempt_enable(void)
{
	reset_preempt_enable_calls++;
	reset_preempt_enable_event = ++reset_event_seq;
}

static int fake_reset_get_maxlvt(void)
{
	reset_get_maxlvt_calls++;
	reset_get_maxlvt_event = ++reset_event_seq;
	return reset_maxlvt;
}

static int fake_reset_apic_integrated(int phys_apicid)
{
	reset_integrated_calls++;
	reset_integrated_event = ++reset_event_seq;
	reset_integrated_phys = phys_apicid;
	return reset_integrated;
}

static void fake_reset_apic_write(int reg, unsigned int value)
{
	int idx = reset_apic_write_count;

	if (idx < 8) {
		reset_apic_write_event[idx] = ++reset_event_seq;
		reset_apic_write_regs[idx] = reg;
		reset_apic_write_values[idx] = value;
	} else {
		++reset_event_seq;
	}
	reset_apic_write_count++;
}

static unsigned int fake_reset_apic_read(int reg)
{
	int idx = reset_apic_read_count;

	if (idx < 8) {
		reset_apic_read_event[idx] = ++reset_event_seq;
		reset_apic_read_regs[idx] = reg;
	} else {
		++reset_event_seq;
	}
	reset_apic_read_count++;
	return reset_apic_read_value;
}

static void fake_reset_icr_write(unsigned int value, int phys_apicid)
{
	int idx = reset_icr_write_count;

	if (idx < 8) {
		reset_icr_write_event[idx] = ++reset_event_seq;
		reset_icr_write_values[idx] = value;
		reset_icr_write_phys[idx] = phys_apicid;
	} else {
		++reset_event_seq;
	}
	reset_icr_write_count++;
}

static unsigned long fake_reset_wait(void)
{
	int idx = reset_wait_count;
	unsigned long value;

	if (idx < 8)
		reset_wait_event[idx] = ++reset_event_seq;
	else
		++reset_event_seq;
	reset_wait_count++;
	if (reset_wait_use_sequence && idx < 8)
		value = reset_wait_values[idx];
	else
		value = reset_wait_value + (unsigned long)reset_wait_count;
	return value;
}

static void fake_reset_delay(unsigned long msecs)
{
	reset_delay_count++;
	reset_delay_event = ++reset_event_seq;
	reset_delay_msecs = msecs;
}

static void fake_reset_udelay(unsigned long usecs)
{
	int idx = reset_udelay_count;

	if (idx < 8) {
		reset_udelay_event[idx] = ++reset_event_seq;
		reset_udelay_usecs[idx] = usecs;
	} else {
		++reset_event_seq;
	}
	reset_udelay_count++;
}

static void fake_reset_barrier(void)
{
	reset_barrier_calls++;
	reset_barrier_event = ++reset_event_seq;
}

static void fake_reset_init_deasserted(void)
{
	reset_init_deasserted_calls++;
	reset_init_deasserted_event = ++reset_event_seq;
}

static void fake_reset_log(int event, int phys_apicid)
{
	int idx = reset_log_count;

	if (idx < 8) {
		reset_log_event[idx] = event;
		reset_log_phys[idx] = phys_apicid;
	}
	reset_log_count++;
}

static void fake_wakeup_log(int event, unsigned long value)
{
	int idx = reset_log_count;

	if (idx < 16) {
		reset_log_event[idx] = event;
		reset_log_value[idx] = value;
	}
	reset_log_count++;
}

static void fake_wakeup_clear_init_deasserted(void)
{
	reset_init_deasserted_calls++;
	reset_init_deasserted_event = ++reset_event_seq;
}

static int fake_wakeup_non_unique_apic(void)
{
	wakeup_non_unique_calls++;
	wakeup_non_unique_event = ++reset_event_seq;
	return wakeup_non_unique;
}

static void fake_wakeup_setup_warm_reset_vector(unsigned long start_eip)
{
	wakeup_setup_calls++;
	wakeup_setup_event = ++reset_event_seq;
	wakeup_setup_start_eip = start_eip;
}

static int fake_wakeup_apic_available(void)
{
	wakeup_apic_available_calls++;
	wakeup_apic_available_event = ++reset_event_seq;
	return wakeup_apic_available;
}

static int fake_wakeup_apic(int apicid, unsigned long start_eip)
{
	wakeup_apic_calls++;
	wakeup_apic_event = ++reset_event_seq;
	wakeup_apic_apicid = apicid;
	wakeup_apic_start_eip = start_eip;
	return wakeup_apic_ret;
}

static int fake_wakeup_via_init(int apicid, unsigned long start_eip)
{
	wakeup_via_calls++;
	wakeup_via_event = ++reset_event_seq;
	wakeup_via_apicid = apicid;
	wakeup_via_start_eip = start_eip;
	return wakeup_via_ret;
}

static void fake_wakeup_top_log(int event)
{
	int idx = wakeup_top_log_count;

	if (idx < 8)
		wakeup_top_log_event[idx] = event;
	wakeup_top_log_count++;
}

static unsigned long fake_warm_lock(void)
{
	warm_lock_calls++;
	warm_lock_event = ++reset_event_seq;
	return warm_lock_flags;
}

static void fake_warm_cmos_write(unsigned char value, unsigned char reg)
{
	warm_cmos_calls++;
	warm_cmos_event = ++reset_event_seq;
	warm_cmos_value = value;
	warm_cmos_reg = reg;
}

static void fake_warm_unlock(unsigned long flags)
{
	warm_unlock_calls++;
	warm_unlock_event = ++reset_event_seq;
	warm_unlock_flags = flags;
}

static void fake_warm_flush_tlb(void)
{
	warm_flush_calls++;
	warm_flush_event = ++reset_event_seq;
}

static void fake_warm_write_word(unsigned long phys, unsigned short value)
{
	int idx = warm_write_count;

	if (idx < 4) {
		warm_write_event[idx] = ++reset_event_seq;
		warm_write_phys[idx] = phys;
		warm_write_value[idx] = value;
	} else {
		++reset_event_seq;
	}
	warm_write_count++;
}

static unsigned int fake_setup_apicid(int cpu)
{
	setup_apicid_calls++;
	return 0x80U + (unsigned int)cpu;
}

static unsigned long fake_setup_raised_list_phys(int cpu)
{
	setup_raised_calls++;
	return 0x500000UL + (unsigned long)cpu * 0x1000UL;
}

static void fake_setup_log(int event, unsigned long value0,
			   unsigned long value1)
{
	setup_log_calls++;
	setup_log_event = event;
	setup_log_value0 = value0;
	setup_log_value1 = value1;
}

static unsigned long fake_startup_alloc_page(void)
{
	startup_alloc_calls++;
	return startup_alloc_result;
}

static unsigned long fake_startup_page_phys(unsigned long virt)
{
	startup_phys_calls++;
	startup_last_phys_virt = virt;
	return virt + 0x10000000UL;
}

static int fake_startup_map_kernel(unsigned long page_table,
				   unsigned long virt, unsigned long phys)
{
	int idx = startup_map_calls;

	if (idx < 16) {
		startup_map_pt[idx] = page_table;
		startup_map_virt[idx] = virt;
		startup_map_phys[idx] = phys;
	}
	startup_map_calls++;
	if (startup_map_fail_at && startup_map_calls == startup_map_fail_at)
		return -1;
	return 0;
}

static unsigned long fake_startup_map_virtual(unsigned long phys,
					      unsigned long size)
{
	startup_map_virtual_calls++;
	startup_map_virtual_phys = phys;
	startup_map_virtual_size = size;
	return startup_map_virtual_result;
}

static void fake_startup_unmap_virtual(unsigned long virt)
{
	startup_unmap_calls++;
	startup_unmap_virt = virt;
}

static void fake_startup_log(int event)
{
	startup_log_event = event;
}

static unsigned long fake_arch_init_ioremap(unsigned long phys,
					    unsigned long size)
{
	arch_init_ioremap_calls++;
	arch_init_ioremap_phys = phys;
	arch_init_ioremap_size = size;
	return phys + 0x100000UL;
}

static unsigned long fake_arch_init_alloc(void)
{
	unsigned long page = 0;

	if (arch_init_alloc_calls < 8)
		page = arch_init_alloc_sequence[arch_init_alloc_calls];
	arch_init_alloc_calls++;
	return page;
}

static unsigned long fake_arch_init_page_phys(unsigned long page)
{
	int idx = arch_init_page_phys_calls;

	if (idx < 16)
		arch_init_page_phys_arg[idx] = page;
	arch_init_page_phys_calls++;
	return page;
}

static unsigned long fake_arch_init_page_virt(unsigned long page)
{
	int idx = arch_init_page_virt_calls;

	if (idx < 16)
		arch_init_page_virt_arg[idx] = page;
	arch_init_page_virt_calls++;
	return page + 0x200000UL;
}

static void fake_arch_init_free(unsigned long page, unsigned int order)
{
	int idx = arch_init_free_calls;

	if (idx < 8) {
		arch_init_free_page[idx] = page;
		arch_init_free_order[idx] = order;
	}
	arch_init_free_calls++;
}

static unsigned long fake_arch_init_linux_phys(void)
{
	arch_init_linux_phys_calls++;
	return arch_init_linux_phys;
}

static unsigned long fake_arch_init_direct_virt(unsigned long phys)
{
	arch_init_direct_virt_calls++;
	arch_init_direct_virt_phys = phys;
	return phys + 0x300000UL;
}

static void fake_arch_init_log(int event, unsigned long value)
{
	int idx = arch_init_log_count;

	if (idx < 8) {
		arch_init_log_event[idx] = event;
		arch_init_log_value[idx] = value;
	}
	arch_init_log_count++;
}

static int fake_arch_init_tail_ident(void)
{
	arch_init_tail_ident_calls++;
	return arch_init_tail_ident_result;
}

static int fake_arch_init_tail_topology(void)
{
	arch_init_tail_topology_calls++;
	return arch_init_tail_topology_result;
}

static void fake_arch_init_tail_log(int event, int value)
{
	int idx = arch_init_tail_log_count;

	if (idx < 8) {
		arch_init_tail_log_event[idx] = event;
		arch_init_tail_log_value[idx] = value;
	}
	arch_init_tail_log_count++;
}

static unsigned long fake_ident_alloc(unsigned int order)
{
	ident_alloc_calls++;
	ident_alloc_order = order;
	return ident_alloc_result;
}

static unsigned long fake_ident_page_phys(unsigned long page)
{
	ident_page_phys_calls++;
	ident_page_phys_arg = page;
	return ident_page_phys_result;
}

static unsigned long fake_ident_page_virt(unsigned long page)
{
	ident_page_virt_calls++;
	ident_page_virt_arg = page;
	return ident_page_virt_result;
}

static void fake_ident_zero(unsigned long addr, unsigned long len)
{
	ident_zero_calls++;
	ident_zero_addr = addr;
	ident_zero_len = len;
	memset((void *)addr, 0, len);
}

static void fake_ident_log(int event, unsigned long value0,
			   unsigned long value1)
{
	int idx = ident_log_count;

	if (idx < 8) {
		ident_log_event[idx] = event;
		ident_log_value0[idx] = value0;
		ident_log_value1[idx] = value1;
	}
	ident_log_count++;
}

static void fake_exit_free_trampoline(unsigned long page, unsigned int order)
{
	exit_free_trampoline_calls++;
	exit_free_trampoline_event = ++exit_event_seq;
	exit_free_trampoline_page = page;
	exit_free_trampoline_order = order;
}

static void fake_exit_unmap(unsigned long virt)
{
	exit_unmap_calls++;
	exit_unmap_event = ++exit_event_seq;
	exit_unmap_virt = virt;
}

static void fake_exit_free_pages(unsigned long addr, unsigned int order)
{
	exit_free_pages_calls++;
	exit_free_pages_event = ++exit_event_seq;
	exit_free_pages_addr = addr;
	exit_free_pages_order = order;
}

static unsigned long fake_control_lock(unsigned long lock_addr)
{
	control_lock_calls++;
	control_last_lock = lock_addr;
	return 0x5a5aUL + (unsigned long)control_lock_calls;
}

static void fake_control_unlock(unsigned long lock_addr, unsigned long flags)
{
	control_unlock_calls++;
	control_last_unlock = lock_addr ^ flags;
}

static void fake_control_log(int event, const char *args)
{
	control_log_event = event;
	control_log_args = args;
}

static int fake_control_issue_interrupt(unsigned long os, unsigned long priv,
					int cpu, int vector)
{
	control_issue_calls++;
	control_issue_os = os;
	control_issue_priv = priv;
	control_issue_cpu = cpu;
	control_issue_vector = vector;
	return 0;
}

static int fake_control_send_multi_intr(unsigned long os, unsigned long priv,
					int mode)
{
	(void)os;
	(void)priv;
	control_send_calls++;
	control_send_mode = mode;
	return 0;
}

static int fake_control_set_mode(unsigned long os, unsigned long priv,
				 int mode)
{
	control_set_mode_calls++;
	control_set_mode_os = os;
	control_set_mode_priv = priv;
	control_set_mode_mode = mode;
	return control_set_mode_fail;
}

static void *fake_control_alloc(unsigned long size)
{
	if (control_alloc_fail)
		return NULL;
	control_last_alloc = calloc(1, size);
	return control_last_alloc;
}

static void fake_control_spin_init(unsigned long lock_addr)
{
	(void)lock_addr;
	control_spin_init_calls++;
}

static void fake_control_create_log(int event)
{
	control_create_log_event = event;
}

static void fake_control_free(unsigned long ptr)
{
	if (ptr)
		control_free_calls++;
	free((void *)ptr);
}

static void fake_control_unmap(unsigned long virt)
{
	control_unmap_calls++;
	control_unmap_virt = virt;
}

static void fake_control_dcache_flush(unsigned long virt, unsigned long size)
{
	control_flush_calls++;
	control_flush_virt = virt;
	control_flush_size = size;
}

static unsigned long fake_control_direct_map(unsigned long phys,
					     unsigned long size)
{
	int idx = control_map_calls;

	control_map_calls++;
	if (idx < 4) {
		control_map_phys[idx] = phys;
		control_map_size[idx] = size;
	}
	if (control_map_fail_at && control_map_calls == control_map_fail_at)
		return 0;
	return control_map_result_base + (unsigned long)idx * 4096UL;
}

static unsigned long fake_control_host_map(unsigned long dev,
					   unsigned long phys,
					   unsigned long virt,
					   unsigned long size,
					   int flags)
{
	control_host_map_calls++;
	control_host_map_dev = dev;
	control_host_map_phys = phys;
	control_host_map_virt = virt;
	control_host_map_size = size;
	control_host_map_flags = flags;
	return virt + 0x55;
}

static void fake_control_map_log(int event, unsigned long phys,
				 unsigned long size)
{
	control_map_log_event = event;
	control_map_log_phys = phys;
	control_map_log_size = size;
}

static unsigned long fake_control_phys_to_virt(unsigned long phys)
{
	control_phys_to_virt_calls++;
	control_phys_to_virt_phys = phys;
	return phys + 0x10000000UL;
}

static unsigned long fake_control_vtop(unsigned long virt)
{
	control_vtop_calls++;
	control_vtop_arg = virt;
	return virt + 0x100000UL;
}

static void fake_control_vtop_log(int event, unsigned long virt,
				  unsigned long phys)
{
	control_vtop_log_event = event;
	control_vtop_log_virt = virt;
	control_vtop_log_phys = phys;
}

static void fake_control_load_copy(unsigned long dst, const char *src,
				   unsigned long size)
{
	int idx = control_load_copy_calls;

	control_load_copy_calls++;
	if (idx < 4) {
		control_load_copy_dst[idx] = dst;
		control_load_copy_size[idx] = size;
	}
	memcpy((void *)dst, src, size);
}

static void fake_control_load_log(int event, unsigned long a,
				  unsigned long b, unsigned long c,
				  unsigned long d)
{
	control_load_log_event = event;
	control_load_log_a = a;
	control_load_log_b = b;
	control_load_log_c = c;
	control_load_log_d = d;
}

static unsigned long fake_control_irq_save(void)
{
	control_irq_save_calls++;
	return 0x5000UL + (unsigned long)control_irq_save_calls;
}

static void fake_control_irq_restore(unsigned long flags)
{
	control_irq_restore_calls++;
	control_irq_restore_flags = flags;
}

static int fake_control_x2apic_enabled(void)
{
	control_x2apic_enabled_calls++;
	return control_x2apic_enabled;
}

static void fake_control_x2apic_wait(void)
{
	control_x2apic_wait_calls++;
}

static void fake_control_x2apic_write(int vector, int hw_id)
{
	control_x2apic_write_calls++;
	control_x2apic_vector = vector;
	control_x2apic_hw_id = hw_id;
}

static void fake_control_legacy_ipi(int hw_id, int vector, int dest)
{
	control_legacy_ipi_calls++;
	control_legacy_hw_id = hw_id;
	control_legacy_vector = vector;
	control_legacy_dest = dest;
}

static void fake_control_perf_log(int event, int value)
{
	control_perf_log_calls++;
	control_perf_log_event = event;
	control_perf_log_value = value;
}

static int fake_control_irq_work_handler(int irq, void *data)
{
	control_irq_work_calls++;
	control_irq_work_irq = irq;
	control_irq_work_data = data;
	return control_irq_work_ret;
}

static void reset_irq_handler_trace(void)
{
	irq_handler_calls = 0;
	memset(irq_handler_os, 0, sizeof(irq_handler_os));
	memset(irq_handler_os_priv, 0, sizeof(irq_handler_os_priv));
	memset(irq_handler_priv, 0, sizeof(irq_handler_priv));
	irq_no_handler_log_calls = 0;
}

static void fake_irq_handler_func(unsigned long os, unsigned long os_priv,
				  unsigned long priv)
{
	if (irq_handler_calls >=
	    (int)(sizeof(irq_handler_os) / sizeof(irq_handler_os[0]))) {
		fprintf(stderr, "irq handler trace overflow\n");
		exit(1);
	}
	irq_handler_os[irq_handler_calls] = os;
	irq_handler_os_priv[irq_handler_calls] = os_priv;
	irq_handler_priv[irq_handler_calls] = priv;
	irq_handler_calls++;
}

static void fake_irq_no_handler_log(void)
{
	irq_no_handler_log_calls++;
}

static int fake_smp_copy_to_user(unsigned long dst, const void *src,
				 unsigned long size)
{
	smp_copy_to_calls++;
	if (smp_copy_to_fail)
		return 1;
	memcpy((void *)dst, src, size);
	return 0;
}

static int fake_smp_copy_from_user(void *dst, unsigned long src,
				   unsigned long size)
{
	smp_copy_from_calls++;
	if (smp_copy_from_fail)
		return 1;
	memcpy(dst, (void *)src, size);
	return 0;
}

static void *fake_smp_alloc(unsigned long size)
{
	smp_alloc_calls++;
	if (smp_alloc_fail)
		return NULL;
	return malloc(size);
}

static void fake_smp_free(unsigned long ptr)
{
	if (ptr)
		smp_free_calls++;
	free((void *)ptr);
}

static void fake_smp_query_log(int event, int requested, int actual)
{
	smp_query_log_event = event;
	smp_query_log_requested = requested;
	smp_query_log_actual = actual;
}

static int fake_smp_cpu_present(int cpu)
{
	if (cpu < 0 || cpu >= (int)(sizeof(smp_cpu_present_mask) /
				   sizeof(smp_cpu_present_mask[0])))
		return 0;
	return smp_cpu_present_mask[cpu];
}

static int fake_smp_cpu_online(int cpu)
{
	if (cpu < 0 || cpu >= (int)(sizeof(smp_cpu_online_mask) /
				   sizeof(smp_cpu_online_mask[0])))
		return 0;
	return smp_cpu_online_mask[cpu];
}

static int fake_smp_check_ikc_map(unsigned long ihk_os)
{
	(void)ihk_os;
	smp_check_ikc_calls++;
	return smp_check_ikc_result;
}

static void fake_smp_init_zero(unsigned long ptr, unsigned long size)
{
	int idx = smp_init_zero_calls;

	if (idx < (int)(sizeof(smp_init_zero_ptr) /
			sizeof(smp_init_zero_ptr[0]))) {
		smp_init_zero_ptr[idx] = ptr;
		smp_init_zero_size[idx] = size;
	}
	smp_init_zero_calls++;
	memset((void *)ptr, 0, size);
}

static int fake_smp_init_for_each_online(
	unsigned long ctx, void (*visit_fn)(unsigned long, int))
{
	int i;

	smp_init_for_each_calls++;
	if (!visit_fn)
		return -EINVAL;
	for (i = 0; i < smp_init_online_count; i++)
		visit_fn(ctx, smp_init_online_cpus[i]);
	return 0;
}

static int fake_smp_init_arch(void)
{
	smp_init_arch_calls++;
	return smp_init_arch_ret;
}

static void fake_smp_init_log(int present_cpus)
{
	smp_init_log_present = present_cpus;
}

static void fake_smp_exit_arch(void)
{
	smp_exit_arch_calls++;
}

static int fake_smp_exit_reset_cpu(int hw_id)
{
	int idx = smp_exit_reset_calls;

	if (idx < (int)(sizeof(smp_exit_reset_hw_id) /
			sizeof(smp_exit_reset_hw_id[0]))) {
		smp_exit_reset_hw_id[idx] = hw_id;
	}
	smp_exit_reset_calls++;
	if (idx < (int)(sizeof(smp_exit_reset_ret) /
			sizeof(smp_exit_reset_ret[0]))) {
		return smp_exit_reset_ret[idx];
	}
	return 0;
}

static int fake_smp_exit_online_cpu(int cpu)
{
	int idx = smp_exit_online_calls;

	if (idx < (int)(sizeof(smp_exit_online_cpu) /
			sizeof(smp_exit_online_cpu[0]))) {
		smp_exit_online_cpu[idx] = cpu;
	}
	smp_exit_online_calls++;
	if (idx < (int)(sizeof(smp_exit_online_ret) /
			sizeof(smp_exit_online_ret[0]))) {
		return smp_exit_online_ret[idx];
	}
	return 0;
}

static int fake_smp_exit_free_list(unsigned long list_head)
{
	smp_exit_free_list_calls++;
	smp_exit_free_list_arg = list_head;
	return -123;
}

static void fake_smp_exit_free_info(void)
{
	smp_exit_free_info_calls++;
}

static void fake_smp_exit_log(int cpu_id, int hw_id)
{
	int idx = smp_exit_log_calls;

	if (idx < (int)(sizeof(smp_exit_log_cpu_id) /
			sizeof(smp_exit_log_cpu_id[0]))) {
		smp_exit_log_cpu_id[idx] = cpu_id;
		smp_exit_log_hw_id[idx] = hw_id;
	}
	smp_exit_log_calls++;
}

static int fake_smp_module_symbols_init(void)
{
	smp_module_symbols_calls++;
	return smp_module_symbols_ret;
}

static int fake_smp_module_arch_symbols_init(void)
{
	smp_module_arch_symbols_calls++;
	return smp_module_arch_symbols_ret;
}

static void fake_smp_module_spin_lock_init(unsigned long lock)
{
	smp_module_lock_init_calls++;
	smp_module_lock_arg = lock;
}

static unsigned long fake_smp_module_register_device(unsigned long reg_data)
{
	smp_module_register_calls++;
	smp_module_register_arg = reg_data;
	return smp_module_register_ret;
}

static void fake_smp_module_unregister_device(unsigned long ihk_dev)
{
	smp_module_unregister_calls++;
	smp_module_unregister_arg = ihk_dev;
}

static void fake_smp_module_log(int event)
{
	int idx = smp_module_log_count;

	if (idx < (int)(sizeof(smp_module_log_event) /
			sizeof(smp_module_log_event[0]))) {
		smp_module_log_event[idx] = event;
	}
	smp_module_log_count++;
}

static void fake_smp_set_ikc_log(int event, int value0, int value1)
{
	smp_set_ikc_log_event = event;
	smp_set_ikc_log_value0 = value0;
	smp_set_ikc_log_value1 = value1;
	if (event == 14 && smp_set_ikc_route_count <
	    (int)(sizeof(smp_set_ikc_route_cpu) /
		  sizeof(smp_set_ikc_route_cpu[0]))) {
		smp_set_ikc_route_cpu[smp_set_ikc_route_count] = value0;
		smp_set_ikc_route_dst[smp_set_ikc_route_count] = value1;
		smp_set_ikc_route_count++;
	}
}

static struct fake_cache_topology *first_fake_cache(
	struct fake_cpu_topology *cpu)
{
	if (list_empty(&cpu->cache_topology_list))
		return NULL;
	return container_of(cpu->cache_topology_list.next,
			struct fake_cache_topology, chain);
}

static struct fake_cpu_topology *first_fake_cpu(struct list_head *head)
{
	if (list_empty(head))
		return NULL;
	return container_of(head->next, struct fake_cpu_topology, chain);
}

static struct fake_node_topology *first_fake_node(struct list_head *head)
{
	if (list_empty(head))
		return NULL;
	return container_of(head->next, struct fake_node_topology, chain);
}

static void reset_topo_trace(struct fake_cpu_topology *cpu)
{
	memset(cpu, 0, sizeof(*cpu));
	init_list_head(&cpu->cache_topology_list);
	cpu->cpu_number = 2;
	topo_alloc_fail_after = -1;
	topo_alloc_calls = 0;
	topo_free_calls = 0;
	topo_file_readable = 1;
	topo_fail_leaf = NULL;
	topo_fail_error = -5;
	topo_log_event = 0;
	topo_log_error = 0;
	topo_log_count = 0;
	memset(topo_log_events, 0, sizeof(topo_log_events));
	memset(topo_log_errors, 0, sizeof(topo_log_errors));
	topo_collect_cache_calls = 0;
	topo_collect_cache_fail_index = -1;
	topo_collect_cache_last_index = -1;
	topo_node_fail_error = 0;
	memset(topo_online_cpus, 0, sizeof(topo_online_cpus));
	topo_online_cpu_count = 0;
	memset(topo_online_nodes, 0, sizeof(topo_online_nodes));
	topo_online_node_count = 0;
	topo_next_cpu_calls = 0;
	topo_next_node_calls = 0;
	topo_collect_cpu_calls = 0;
	topo_collect_node_calls = 0;
	memset(topo_collected_cpus, 0, sizeof(topo_collected_cpus));
	memset(topo_collected_nodes, 0, sizeof(topo_collected_nodes));
	topo_collect_cpu_fail_at = -1;
	topo_collect_node_fail_at = -1;
	free_info_list_del_calls = 0;
	free_info_log_calls = 0;
	memset(free_info_log_events, 0, sizeof(free_info_log_events));
	memset(read_long_page, 0, sizeof(read_long_page));
	read_long_alloc_fail = 0;
	read_long_alloc_calls = 0;
	read_long_read_calls = 0;
	read_long_read_result = 0;
	read_long_read_buf = 0;
	read_long_read_size = 0;
	read_long_read_fmt = NULL;
	read_long_read_va = 0;
	read_long_parse_calls = 0;
	read_long_parse_result = 1;
	read_long_parse_value = 12345;
	read_long_free_calls = 0;
	read_long_free_addr = 0;
	read_long_log_calls = 0;
	memset(read_long_log_event, 0, sizeof(read_long_log_event));
	memset(read_long_log_error, 0, sizeof(read_long_log_error));
	memset(read_bitmap_map_words, 0, sizeof(read_bitmap_map_words));
	read_bitmap_alloc_fail = 0;
	read_bitmap_alloc_calls = 0;
	read_bitmap_read_calls = 0;
	read_bitmap_read_result = 0;
	read_bitmap_read_buf = 0;
	read_bitmap_read_size = 0;
	read_bitmap_read_fmt = NULL;
	read_bitmap_read_va = 0;
	read_bitmap_parse_calls = 0;
	read_bitmap_parse_result = 0;
	read_bitmap_parse_buf = 0;
	read_bitmap_parse_size = 0;
	read_bitmap_parse_map = 0;
	read_bitmap_parse_nbits = 0;
	read_bitmap_free_calls = 0;
	read_bitmap_free_addr = 0;
	read_bitmap_log_calls = 0;
	memset(read_bitmap_log_event, 0, sizeof(read_bitmap_log_event));
	memset(read_bitmap_log_error, 0, sizeof(read_bitmap_log_error));
	free(read_string_value);
	read_string_value = NULL;
	read_string_alloc_fail = 0;
	read_string_alloc_calls = 0;
	read_string_read_calls = 0;
	read_string_read_result = 0;
	read_string_read_buf = 0;
	read_string_read_size = 0;
	read_string_read_fmt = NULL;
	read_string_read_va = 0;
	read_string_dup_calls = 0;
	read_string_dup_fail = 0;
	read_string_dup_buf = 0;
	read_string_kfree_calls = 0;
	read_string_kfree_addr = 0;
	read_string_free_calls = 0;
	read_string_free_addr = 0;
	read_string_log_calls = 0;
	memset(read_string_log_event, 0, sizeof(read_string_log_event));
	memset(read_string_log_error, 0, sizeof(read_string_log_error));
	memset(file_readable_filename, 0, sizeof(file_readable_filename));
	file_readable_alloc_fail = 0;
	file_readable_alloc_calls = 0;
	file_readable_alloc_size = 0;
	file_readable_vsnprintf_calls = 0;
	file_readable_vsnprintf_result = 12;
	file_readable_vsnprintf_fmt = NULL;
	file_readable_vsnprintf_size = 0;
	file_readable_vsnprintf_va = 0;
	file_readable_open_calls = 0;
	file_readable_open_fail = 0;
	file_readable_open_filename = NULL;
	file_readable_close_calls = 0;
	file_readable_close_file = 0;
	file_readable_free_calls = 0;
	file_readable_free_addr = 0;
	file_readable_log_calls = 0;
	memset(file_readable_log_event, 0, sizeof(file_readable_log_event));
	memset(file_readable_log_error, 0, sizeof(file_readable_log_error));
	memset(read_file_buf, 0, sizeof(read_file_buf));
	memset(read_file_filename, 0, sizeof(read_file_filename));
	read_file_alloc_fail = 0;
	read_file_alloc_calls = 0;
	read_file_alloc_size = 0;
	read_file_vsnprintf_calls = 0;
	read_file_vsnprintf_result = 14;
	read_file_vsnprintf_fmt = NULL;
	read_file_vsnprintf_size = 0;
	read_file_vsnprintf_va = 0;
	read_file_open_calls = 0;
	read_file_open_fail = 0;
	read_file_open_error = -ENOENT;
	read_file_open_filename = NULL;
	read_file_open_errorp = 0;
	read_file_kernel_read_calls = 0;
	read_file_kernel_read_result = 5;
	read_file_kernel_file = 0;
	read_file_kernel_buf = 0;
	read_file_kernel_size = 0;
	read_file_close_calls = 0;
	read_file_close_result = 0;
	read_file_close_file = 0;
	read_file_free_calls = 0;
	read_file_free_addr = 0;
	read_file_log_calls = 0;
	memset(read_file_log_event, 0, sizeof(read_file_log_event));
	memset(read_file_log_error, 0, sizeof(read_file_log_error));
	write_cpu_open_calls = 0;
	write_cpu_open_fail = 0;
	write_cpu_open_error = -EACCES;
	write_cpu_open_path = NULL;
	write_cpu_open_errorp = 0;
	write_cpu_write_calls = 0;
	write_cpu_write_result = 1;
	write_cpu_write_file = 0;
	write_cpu_write_buf = NULL;
	write_cpu_write_size = 0;
	write_cpu_close_calls = 0;
	write_cpu_close_file = 0;
	write_cpu_log_calls = 0;
	memset(write_cpu_log_event, 0, sizeof(write_cpu_log_event));
	memset(write_cpu_log_error, 0, sizeof(write_cpu_log_error));
	memset(write_cpu_log_path, 0, sizeof(write_cpu_log_path));
}

static void fake_free_info_list_del(unsigned long node)
{
	free_info_list_del_calls++;
	topo_list_del((struct list_head *)node);
}

static void fake_free_info_log(int event)
{
	if (free_info_log_calls >=
	    (int)(sizeof(free_info_log_events) /
		  sizeof(free_info_log_events[0]))) {
		fprintf(stderr, "free_info log overflow\n");
		exit(1);
	}
	free_info_log_events[free_info_log_calls++] = event;
}

static unsigned long fake_read_long_alloc_page(void)
{
	read_long_alloc_calls++;
	if (read_long_alloc_fail)
		return 0;
	return (unsigned long)read_long_page;
}

static int fake_read_long_read_file(unsigned long buf, unsigned long size,
				    char *fmt, unsigned long va_list)
{
	read_long_read_calls++;
	read_long_read_buf = buf;
	read_long_read_size = size;
	read_long_read_fmt = fmt;
	read_long_read_va = va_list;
	if (!read_long_read_result)
		strcpy((char *)buf, "12345\n");
	return read_long_read_result;
}

static int fake_read_long_parse(unsigned long buf, unsigned long valuep)
{
	read_long_parse_calls++;
	(void)buf;
	if (read_long_parse_result == 1)
		*(long *)valuep = read_long_parse_value;
	return read_long_parse_result;
}

static void fake_read_long_free_pages(unsigned long addr)
{
	read_long_free_calls++;
	read_long_free_addr = addr;
}

static void fake_read_long_log(int event, unsigned long valuep, char *fmt,
			       int error)
{
	if (read_long_log_calls >=
	    (int)(sizeof(read_long_log_event) /
		  sizeof(read_long_log_event[0]))) {
		fprintf(stderr, "read_long log overflow\n");
		exit(1);
	}
	(void)valuep;
	(void)fmt;
	read_long_log_event[read_long_log_calls] = event;
	read_long_log_error[read_long_log_calls] = error;
	read_long_log_calls++;
}

static unsigned long fake_read_bitmap_alloc_page(void)
{
	read_bitmap_alloc_calls++;
	if (read_bitmap_alloc_fail)
		return 0;
	return (unsigned long)read_long_page;
}

static int fake_read_bitmap_read_file(unsigned long buf, unsigned long size,
				      char *fmt, unsigned long va_list)
{
	read_bitmap_read_calls++;
	read_bitmap_read_buf = buf;
	read_bitmap_read_size = size;
	read_bitmap_read_fmt = fmt;
	read_bitmap_read_va = va_list;
	if (!read_bitmap_read_result)
		strcpy((char *)buf, "0-3\n");
	return read_bitmap_read_result;
}

static int fake_read_bitmap_parse(unsigned long buf, unsigned long size,
				  unsigned long map, int nbits)
{
	read_bitmap_parse_calls++;
	read_bitmap_parse_buf = buf;
	read_bitmap_parse_size = size;
	read_bitmap_parse_map = map;
	read_bitmap_parse_nbits = nbits;
	if (!read_bitmap_parse_result)
		((unsigned long *)map)[0] = 0x0fUL;
	return read_bitmap_parse_result;
}

static void fake_read_bitmap_free_pages(unsigned long addr)
{
	read_bitmap_free_calls++;
	read_bitmap_free_addr = addr;
}

static void fake_read_bitmap_log(int event, unsigned long map, int nbits,
				 char *fmt, int error)
{
	if (read_bitmap_log_calls >=
	    (int)(sizeof(read_bitmap_log_event) /
		  sizeof(read_bitmap_log_event[0]))) {
		fprintf(stderr, "read_bitmap log overflow\n");
		exit(1);
	}
	(void)map;
	(void)nbits;
	(void)fmt;
	read_bitmap_log_event[read_bitmap_log_calls] = event;
	read_bitmap_log_error[read_bitmap_log_calls] = error;
	read_bitmap_log_calls++;
}

static unsigned long fake_read_string_alloc_page(void)
{
	read_string_alloc_calls++;
	if (read_string_alloc_fail)
		return 0;
	return (unsigned long)read_long_page;
}

static int fake_read_string_read_file(unsigned long buf, unsigned long size,
				      char *fmt, unsigned long va_list)
{
	read_string_read_calls++;
	read_string_read_buf = buf;
	read_string_read_size = size;
	read_string_read_fmt = fmt;
	read_string_read_va = va_list;
	if (!read_string_read_result)
		strcpy((char *)buf, "Cache line\n");
	return read_string_read_result;
}

static unsigned long fake_read_string_dup(unsigned long buf)
{
	char *src = (char *)buf;
	size_t len = strlen(src) + 1;
	char *dst;

	read_string_dup_calls++;
	read_string_dup_buf = buf;
	if (read_string_dup_fail)
		return 0;
	dst = malloc(len);
	if (!dst)
		return 0;
	memcpy(dst, src, len);
	return (unsigned long)dst;
}

static void fake_read_string_kfree(unsigned long addr)
{
	read_string_kfree_calls++;
	read_string_kfree_addr = addr;
	if (addr)
		free((void *)addr);
}

static void fake_read_string_free_pages(unsigned long addr)
{
	read_string_free_calls++;
	read_string_free_addr = addr;
}

static void fake_read_string_log(int event, unsigned long valuep, char *fmt,
				 int error)
{
	if (read_string_log_calls >=
	    (int)(sizeof(read_string_log_event) /
		  sizeof(read_string_log_event[0]))) {
		fprintf(stderr, "read_string log overflow\n");
		exit(1);
	}
	(void)valuep;
	(void)fmt;
	read_string_log_event[read_string_log_calls] = event;
	read_string_log_error[read_string_log_calls] = error;
	read_string_log_calls++;
}

static void *fake_file_readable_alloc(unsigned long size)
{
	file_readable_alloc_calls++;
	file_readable_alloc_size = size;
	if (file_readable_alloc_fail)
		return NULL;
	if (size > sizeof(file_readable_filename)) {
		fprintf(stderr, "file_readable allocation too large\n");
		exit(1);
	}
	return file_readable_filename;
}

static int fake_file_readable_vsnprintf(char *buf, unsigned long size,
					char *fmt, unsigned long va_list)
{
	file_readable_vsnprintf_calls++;
	file_readable_vsnprintf_fmt = fmt;
	file_readable_vsnprintf_size = size;
	file_readable_vsnprintf_va = va_list;
	if (file_readable_vsnprintf_result < (int)size)
		strcpy(buf, "/tmp/readable");
	return file_readable_vsnprintf_result;
}

static unsigned long fake_file_readable_open(char *filename)
{
	file_readable_open_calls++;
	file_readable_open_filename = filename;
	if (file_readable_open_fail)
		return 0;
	return 0x515100UL;
}

static void fake_file_readable_close(unsigned long file)
{
	file_readable_close_calls++;
	file_readable_close_file = file;
}

static void fake_file_readable_free(unsigned long ptr)
{
	file_readable_free_calls++;
	file_readable_free_addr = ptr;
}

static void fake_file_readable_log(int event, int error)
{
	if (file_readable_log_calls >=
	    (int)(sizeof(file_readable_log_event) /
		  sizeof(file_readable_log_event[0]))) {
		fprintf(stderr, "file_readable log overflow\n");
		exit(1);
	}
	file_readable_log_event[file_readable_log_calls] = event;
	file_readable_log_error[file_readable_log_calls] = error;
	file_readable_log_calls++;
}

static void *fake_read_file_alloc(unsigned long size)
{
	read_file_alloc_calls++;
	read_file_alloc_size = size;
	if (read_file_alloc_fail)
		return NULL;
	if (size > sizeof(read_file_filename)) {
		fprintf(stderr, "read_file allocation too large\n");
		exit(1);
	}
	return read_file_filename;
}

static int fake_read_file_vsnprintf(char *buf, unsigned long size,
				    char *fmt, unsigned long va_list)
{
	read_file_vsnprintf_calls++;
	read_file_vsnprintf_fmt = fmt;
	read_file_vsnprintf_size = size;
	read_file_vsnprintf_va = va_list;
	if (read_file_vsnprintf_result < (int)size)
		strcpy(buf, "/tmp/read_file");
	return read_file_vsnprintf_result;
}

static unsigned long fake_read_file_open(char *filename,
					 unsigned long errorp)
{
	read_file_open_calls++;
	read_file_open_filename = filename;
	read_file_open_errorp = errorp;
	if (read_file_open_fail) {
		*(int *)errorp = read_file_open_error;
		return 0;
	}
	*(int *)errorp = 0;
	return 0x525200UL;
}

static long fake_read_file_kernel_read(unsigned long file, unsigned long buf,
				       unsigned long size)
{
	read_file_kernel_read_calls++;
	read_file_kernel_file = file;
	read_file_kernel_buf = buf;
	read_file_kernel_size = size;
	if (read_file_kernel_read_result >= 0 &&
	    read_file_kernel_read_result < (long)size)
		memcpy((void *)buf, "abcde",
		       (size_t)read_file_kernel_read_result);
	return read_file_kernel_read_result;
}

static int fake_read_file_close(unsigned long file)
{
	read_file_close_calls++;
	read_file_close_file = file;
	return read_file_close_result;
}

static void fake_read_file_free(unsigned long ptr)
{
	read_file_free_calls++;
	read_file_free_addr = ptr;
}

static void fake_read_file_log(int event, unsigned long buf,
			       unsigned long size, char *fmt, int error)
{
	if (read_file_log_calls >=
	    (int)(sizeof(read_file_log_event) /
		  sizeof(read_file_log_event[0]))) {
		fprintf(stderr, "read_file log overflow\n");
		exit(1);
	}
	(void)buf;
	(void)size;
	(void)fmt;
	read_file_log_event[read_file_log_calls] = event;
	read_file_log_error[read_file_log_calls] = error;
	read_file_log_calls++;
}

static unsigned long fake_write_cpu_open(char *path, unsigned long errorp)
{
	write_cpu_open_calls++;
	write_cpu_open_path = path;
	write_cpu_open_errorp = errorp;
	if (write_cpu_open_fail) {
		*(int *)errorp = write_cpu_open_error;
		return 0;
	}
	*(int *)errorp = 0;
	return 0x616100UL;
}

static long fake_write_cpu_write(unsigned long file, const char *buf,
				 unsigned long size)
{
	write_cpu_write_calls++;
	write_cpu_write_file = file;
	write_cpu_write_buf = buf;
	write_cpu_write_size = size;
	return write_cpu_write_result;
}

static int fake_write_cpu_close(unsigned long file)
{
	write_cpu_close_calls++;
	write_cpu_close_file = file;
	return 0;
}

static void fake_write_cpu_log(int event, const char *path, int error)
{
	if (write_cpu_log_calls >=
	    (int)(sizeof(write_cpu_log_event) /
		  sizeof(write_cpu_log_event[0]))) {
		fprintf(stderr, "write_cpu log overflow\n");
		exit(1);
	}
	write_cpu_log_event[write_cpu_log_calls] = event;
	write_cpu_log_error[write_cpu_log_calls] = error;
	write_cpu_log_path[write_cpu_log_calls] = path;
	write_cpu_log_calls++;
}

static struct fake_cpu_topology *alloc_free_info_cpu(int cpu_number,
						     struct list_head *head)
{
	struct fake_cpu_topology *cpu = fake_topo_zalloc(sizeof(*cpu));

	if (!cpu) {
		fprintf(stderr, "free_info cpu allocation failed\n");
		exit(1);
	}
	init_list_head(&cpu->cache_topology_list);
	cpu->cpu_number = cpu_number;
	topo_list_add_tail(&cpu->chain, head);
	return cpu;
}

static struct fake_cache_topology *alloc_free_info_cache(
	struct fake_cpu_topology *cpu, const char *type, const char *size_str)
{
	struct fake_cache_topology *cache = fake_topo_zalloc(sizeof(*cache));

	if (!cache) {
		fprintf(stderr, "free_info cache allocation failed\n");
		exit(1);
	}
	cache->type = topo_dup_string(type);
	cache->size_str = topo_dup_string(size_str);
	if (!cache->type || !cache->size_str) {
		fprintf(stderr, "free_info cache string allocation failed\n");
		exit(1);
	}
	topo_list_add_tail(&cache->chain, &cpu->cache_topology_list);
	return cache;
}

static struct fake_node_topology *alloc_free_info_node(int node_number,
						       struct list_head *head)
{
	struct fake_node_topology *node = fake_topo_zalloc(sizeof(*node));

	if (!node) {
		fprintf(stderr, "free_info node allocation failed\n");
		exit(1);
	}
	node->node_number = node_number;
	topo_list_add_tail(&node->chain, head);
	return node;
}

static int run_collect_cache_topology(struct fake_cpu_topology *cpu,
				      int index)
{
	return ihk_smp_collect_cache_topology_body_result(
		cpu, index, cpu->cpu_number, 128,
		sizeof(struct fake_cache_topology), 128, &topo_offsets,
		fake_topo_alloc, fake_topo_zalloc, fake_topo_free,
		fake_topo_file_readable, fake_topo_read_long,
		fake_topo_read_string, fake_topo_read_bitmap,
		fake_topo_list_add, fake_topo_log);
}

static int run_collect_cpu_topology(int cpu, struct list_head *cpu_list)
{
	return ihk_smp_collect_cpu_topology_body_result(
		cpu, 128, sizeof(struct fake_cpu_topology), 128, cpu_list,
		&cpu_topo_offsets, fake_topo_alloc, fake_topo_zalloc,
		fake_topo_free, fake_topo_read_long, fake_topo_read_bitmap,
		fake_topo_init_list_head, fake_topo_get_hw_id,
		fake_topo_collect_cache, fake_topo_list_add, fake_topo_log);
}

static int run_collect_node_topology(int node, struct list_head *node_list)
{
	return ihk_smp_collect_node_topology_body_result(
		node, 128, sizeof(struct fake_node_topology), node_list,
		&node_topo_offsets, fake_topo_zalloc, fake_topo_free,
		fake_topo_read_node_cpumap, fake_topo_list_add,
		fake_topo_log);
}

static int fake_topo_next_cpu(int previous)
{
	int i;

	topo_next_cpu_calls++;
	for (i = 0; i < topo_online_cpu_count; i++) {
		if (topo_online_cpus[i] > previous)
			return topo_online_cpus[i];
	}
	return -1;
}

static int fake_topo_next_node(int previous)
{
	int i;

	topo_next_node_calls++;
	for (i = 0; i < topo_online_node_count; i++) {
		if (topo_online_nodes[i] > previous)
			return topo_online_nodes[i];
	}
	return -1;
}

static int fake_topo_collect_cpu_index(int cpu)
{
	require(topo_collect_cpu_calls < (int)(sizeof(topo_collected_cpus) /
					       sizeof(topo_collected_cpus[0])));
	topo_collected_cpus[topo_collect_cpu_calls++] = cpu;
	if (cpu == topo_collect_cpu_fail_at)
		return topo_fail_error;
	return 0;
}

static int fake_topo_collect_node_index(int node)
{
	require(topo_collect_node_calls < (int)(sizeof(topo_collected_nodes) /
						sizeof(topo_collected_nodes[0])));
	topo_collected_nodes[topo_collect_node_calls++] = node;
	if (node == topo_collect_node_fail_at)
		return topo_fail_error;
	return 0;
}

static int run_collect_topology(void)
{
	return ihk_smp_collect_topology_body_result(
		fake_topo_next_cpu, fake_topo_collect_cpu_index,
		fake_topo_next_node, fake_topo_collect_node_index,
		fake_topo_log);
}

static const char *arch_symbol_lookup_names[16];
static int arch_symbol_lookup_calls;
static int arch_symbol_warn_calls;
static int arch_symbol_warn_failures;
static const char *arch_symbol_missing_name;

static void reset_arch_symbol_trace(const char *missing_name)
{
	memset(arch_symbol_lookup_names, 0, sizeof(arch_symbol_lookup_names));
	arch_symbol_lookup_calls = 0;
	arch_symbol_warn_calls = 0;
	arch_symbol_warn_failures = 0;
	arch_symbol_missing_name = missing_name;
}

static unsigned long fake_arch_symbol_lookup(const char *name)
{
	static const struct {
		const char *name;
		unsigned long value;
	} values[] = {
		{ "real_mode_header", 0x1000UL },
		{ "vector_irq", 0x2000UL },
		{ "lapic_get_maxlvt", 0x3000UL },
		{ "irq_desc_tree", 0x4000UL },
		{ "get_uv_system_type", 0x5000UL },
		{ "init_deasserted", 0x6000UL },
		{ "alloc_desc", 0x7000UL },
		{ "__default_send_IPI_dest_field", 0x8000UL },
		{ "init_level4_pgt", 0x9000UL },
		{ "used_vectors", 0xa000UL },
		{ "ioremap_page_range", 0xb100UL },
		{ "vmap_area_lock", 0xb200UL },
		{ "vmap_area_root", 0xb300UL },
		{ "__insert_vmap_area", 0xb400UL },
		{ "__free_vmap_area", 0xb500UL },
		{ "alloc_vmap_area", 0xb600UL },
		{ "free_vmap_area", 0xb700UL },
		{ "free_vmap_area_noflush", 0xb701UL },
		{ "unmap_kernel_range_noflush", 0xb800UL },
		{ "raised_list", 0xb900UL },
		{ "hstates", 0xba00UL },
		{ "default_hstate_idx", 0xbb00UL },
	};
	size_t i;

	require(arch_symbol_lookup_calls <
			(int)(sizeof(arch_symbol_lookup_names) /
			      sizeof(arch_symbol_lookup_names[0])));
	arch_symbol_lookup_names[arch_symbol_lookup_calls++] = name;
	if (arch_symbol_missing_name && !strcmp(name, arch_symbol_missing_name))
		return 0;
	for (i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
		if (!strcmp(name, values[i].name))
			return values[i].value;
	}
	return 0;
}

static int fake_arch_symbol_warn(int condition)
{
	arch_symbol_warn_calls++;
	if (condition)
		arch_symbol_warn_failures++;
	return condition;
}

int main(void)
{
	struct rb_root root = { NULL };
	struct chunk chunks[9];
	struct fake_cpu_topology cpu_topo;
	struct fake_cpu_topology *cpu_added;
	struct fake_cache_topology *cache_topo;
	struct fake_node_topology *node_added;
	struct list_head cpu_list;
	struct list_head node_list;
	struct list_head lookup_cpu_list;
	struct list_head lookup_node_list;
	struct fake_cpu_topology lookup_cpus[2];
	struct fake_node_topology lookup_nodes[2];
	struct fake_smp_cpu fake_cpus[5];
	unsigned long init_fake_chunks[2];
	struct fake_builtin_device_data fake_builtin;
	unsigned long fake_register_data = 0xabcdef1234UL;
	struct ihk_cpu_req user_req;
	struct ihk_cpu_req req_scratch;
	struct ihk_mem_req mem_user_req;
	struct ihk_mem_req mem_req_scratch;
	int query_out[5];
	struct ihk_ikc_req ikc_user_req;
	struct ihk_ikc_req ikc_req_scratch;
	int ikc_src_out[5];
	int ikc_dst_out[5];
	char ikc_req_string[128];
	size_t mem_sizes_out[6];
	int mem_numa_out[6];
	struct list_head free_mem_list;
	struct list_head os_mem_list;
	struct fake_mem_chunk free_chunks[3];
	struct fake_os_mem_chunk os_chunks[3];
	struct list_head irq_head;
	struct fake_interrupt_handler irq_handlers[3];
	unsigned long fake_chunks[3];
	long read_long_value;
	char buildid_dst[16];
	char load_src[8192];
	unsigned long translated_phys = 0;
	unsigned long digest = 0x736d706368756e6bUL;
	unsigned long sym_real = 0;
	unsigned long sym_vector = 0;
	unsigned long sym_lapic = 0;
	unsigned long sym_irq_desc = 0;
	unsigned long sym_uv = 0;
	unsigned long sym_deassert = 0;
	unsigned long sym_alloc = 0;
	unsigned long sym_default_ipi = 0;
	unsigned long sym_init_pgt = 0;
	unsigned long sym_vectors = 0;
	unsigned long sym_ioremap = 0;
	unsigned long sym_vmap_lock = 0;
	unsigned long sym_vmap_root = 0;
	unsigned long sym_insert_vmap = 0;
	unsigned long sym_free_vmap_old = 0;
	unsigned long sym_alloc_vmap = 0;
	unsigned long sym_free_vmap_new = 0;
	unsigned long sym_unmap_noflush = 0;
	unsigned long sym_raised_list = 0;
	unsigned long sym_hstates = 0;
	unsigned long sym_default_hstate = 0;
	struct fake_os_data control_os;
	struct fake_device_data control_dev;
	struct fake_register_os_data builtin_reg = {
		.name = (char *)"builtinos",
		.ops = (void *)0x12345678UL,
		.priv = (void *)0xfeedUL,
		.flag = 7,
	};
	struct fake_register_os_data out_reg;
		struct fake_os_data *created_os;
		int fill_i;
		int irq_hw_ids[3] = { 101, 202, 303 };
		struct fake_perf_param perf_param;
		struct fake_extra_reg perf_extra_regs[5];
		unsigned long perf_hw_event_map[3] = {
			0x1010UL, 0x2020UL, 0x3030UL
		};
		unsigned long perf_cache_ids[2][2][2] = {
			{ { 0x11UL, 0x12UL }, { 0x13UL, 0x14UL } },
			{ { 0x21UL, 0x22UL }, { 0x23UL, 0x24UL } },
		};
		unsigned long perf_cache_extra[2][2][2] = {
			{ { 0x31UL, 0x32UL }, { 0x33UL, 0x34UL } },
			{ { 0x41UL, 0x42UL }, { 0x43UL, 0x44UL } },
		};
		const struct ihk_smp_arch_symbol_slots symbol_slots = {
		.real_mode_header = &sym_real,
		.vector_irq = &sym_vector,
		.lapic_get_maxlvt = &sym_lapic,
		.irq_desc_tree = &sym_irq_desc,
		.get_uv_system_type = &sym_uv,
		.init_deasserted = &sym_deassert,
		.alloc_desc = &sym_alloc,
		.default_send_ipi_dest_field = &sym_default_ipi,
		.init_level4_pgt = &sym_init_pgt,
		.used_vectors = &sym_vectors,
	};
	const struct ihk_smp_symbol_slots smp_symbol_slots = {
		.ioremap_page_range = &sym_ioremap,
		.vmap_area_lock = &sym_vmap_lock,
		.vmap_area_root = &sym_vmap_root,
		.insert_vmap_area = &sym_insert_vmap,
		.free_vmap_area_old = &sym_free_vmap_old,
		.alloc_vmap_area = &sym_alloc_vmap,
		.free_vmap_area_new = &sym_free_vmap_new,
		.unmap_kernel_range_noflush = &sym_unmap_noflush,
		.raised_list = &sym_raised_list,
		.hstates = &sym_hstates,
		.default_hstate_idx = &sym_default_hstate,
	};

	memset(&control_os, 0, sizeof(control_os));
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	control_os.mem_info.n_numa_nodes = 6;
	control_os.nr_cpus = 4;
	reset_control_trace();
	require(ihk_smp_os_notify_hungup_body_result((unsigned long)&control_os,
			&control_offsets, fake_control_lock,
			fake_control_unlock) == 0);
	require(control_os.status == BUILTIN_OS_STATUS_HUNGUP);
	require(control_lock_calls == 1);
	require(control_unlock_calls == 1);
	mix(&digest, (unsigned long)control_os.status);

	require(ihk_smp_os_get_memory_info_body_result(
			(unsigned long)&control_os, &control_offsets) ==
		(unsigned long)&control_os.mem_info);
	require(ihk_smp_os_get_cpu_info_body_result(
			(unsigned long)&control_os, &control_offsets) ==
		(unsigned long)&control_os.cpu_info);
	require(ihk_smp_os_get_num_numa_nodes_body_result(
			(unsigned long)&control_os, &control_offsets) == 6);
	require(ihk_smp_os_get_num_cpus_body_result(
			(unsigned long)&control_os, &control_offsets) == 4);
	require(ihk_smp_os_get_num_cpus_body_result(0, &control_offsets) ==
		-EINVAL);
	mix(&digest, (unsigned long)control_os.nr_cpus);

	memset(control_os.kernel_args, 0x7f, sizeof(control_os.kernel_args));
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	reset_control_trace();
	require(ihk_smp_os_set_kargs_body_result((unsigned long)&control_os,
			"root=/dev/null console=ttyS0 extra-overflow",
			&control_offsets, sizeof(control_os.kernel_args),
			fake_control_lock, fake_control_unlock,
			fake_control_log) == 0);
	require(control_os.status == BUILTIN_OS_STATUS_INITIAL);
	require(control_lock_calls == 2);
	require(control_unlock_calls == 2);
	require(control_log_event == 2);
	require(control_log_args == control_os.kernel_args);
	require(control_os.kernel_args[sizeof(control_os.kernel_args) - 1] ==
		'\0');
	require(!strncmp(control_os.kernel_args, "root=/dev/null", 14));
	mix(&digest, strlen(control_os.kernel_args));

	control_os.status = BUILTIN_OS_STATUS_HUNGUP;
	reset_control_trace();
	require(ihk_smp_os_set_kargs_body_result((unsigned long)&control_os,
			"ignored", &control_offsets,
			sizeof(control_os.kernel_args), fake_control_lock,
			fake_control_unlock, fake_control_log) == -EBUSY);
	require(control_os.status == BUILTIN_OS_STATUS_HUNGUP);
	require(control_lock_calls == 1);
	require(control_log_event == 1);
	mix(&digest, (unsigned long)control_log_event);

	reset_control_trace();
	require(ihk_smp_os_debug_request_body_result(0x11, 0x22,
			IHK_OS_DEBUG_START, 0x1234, IHK_OS_DEBUG_START,
			fake_control_issue_interrupt) == 0);
	require(control_issue_calls == 1);
	require(control_issue_os == 0x11);
	require(control_issue_priv == 0x22);
	require(control_issue_cpu == 0x12);
	require(control_issue_vector == 0x34);
	require(ihk_smp_os_debug_request_body_result(0x11, 0x22,
			IHK_OS_DEBUG_START + 1, 0x1234,
			IHK_OS_DEBUG_START,
			fake_control_issue_interrupt) == -EINVAL);
	mix(&digest, (unsigned long)control_issue_cpu);
	mix(&digest, (unsigned long)control_issue_vector);

	reset_control_trace();
	require(ihk_smp_os_freeze_thaw_body_result(0x11, 0x22, 1,
			fake_control_send_multi_intr) == 0);
	require(control_send_calls == 1);
	require(control_send_mode == 1);
	require(ihk_smp_os_freeze_thaw_body_result(0x11, 0x22, 2,
			fake_control_send_multi_intr) == 0);
	require(control_send_calls == 2);
	require(control_send_mode == 2);
	mix(&digest, (unsigned long)control_send_calls);

	memset(&control_dev, 0, sizeof(control_dev));
	control_dev.status = 99;
	memset(&out_reg, 0, sizeof(out_reg));
	reset_control_trace();
	require(ihk_smp_create_os_body_result((unsigned long)&control_dev,
			0xabc, (unsigned long)&out_reg,
			(unsigned long)&builtin_reg, &control_offsets,
			sizeof(out_reg), sizeof(struct fake_os_data),
			fake_control_alloc, fake_control_spin_init,
			fake_control_create_log) == 0);
	created_os = out_reg.priv;
	require(created_os != NULL);
	require(out_reg.name == builtin_reg.name);
	require(out_reg.ops == builtin_reg.ops);
	require(out_reg.flag == builtin_reg.flag);
	require(created_os->dev == &control_dev);
	require(created_os->bootstrap_numa_id == -1);
	require(created_os->boot_pt == NULL);
	require(control_spin_init_calls == 1);
	mix(&digest, (unsigned long)(unsigned int)created_os->bootstrap_numa_id);
	mix(&digest, (unsigned long)control_spin_init_calls);
	require(ihk_smp_destroy_os_body_result((unsigned long)created_os,
			fake_control_free) == 0);
	require(control_free_calls == 1);

	memset(&out_reg, 0, sizeof(out_reg));
	control_dev.status = 77;
	reset_control_trace();
	control_alloc_fail = 1;
	require(ihk_smp_create_os_body_result((unsigned long)&control_dev,
			0xabc, (unsigned long)&out_reg,
			(unsigned long)&builtin_reg, &control_offsets,
			sizeof(out_reg), sizeof(struct fake_os_data),
			fake_control_alloc, fake_control_spin_init,
			fake_control_create_log) == -ENOMEM);
	require(control_dev.status == 0);
	require(out_reg.name == builtin_reg.name);
	require(control_create_log_event == 1);
	mix(&digest, (unsigned long)control_create_log_event);

	reset_control_trace();
	require(ihk_smp_device_debug_request_body_result() == -EINVAL);
	require(ihk_smp_get_dma_channel_body_result(0x10UL, 0x20UL, 3) == 0);
	require(ihk_smp_get_dma_channel_body_result(0, 0, -1) == 0);
	require(ihk_smp_unmap_virtual_body_result(0xdeadbeefUL,
			fake_control_unmap) == 0);
	require(control_unmap_calls == 1);
	require(control_unmap_virt == 0xdeadbeefUL);
	mix(&digest, control_unmap_virt);
	reset_control_trace();
	ihk_smp_direct_unmap_virtual_body_result(
		0xcafebabeUL, 4096UL, fake_control_dcache_flush);
	require(control_flush_calls == 1);
	require(control_flush_virt == 0xcafebabeUL);
	require(control_flush_size == 4096UL);
	ihk_smp_direct_unmap_virtual_body_result(0x1234UL, 8192UL, NULL);
	require(control_flush_calls == 1);
	mix(&digest, control_flush_virt);

	reset_control_trace();
	control_map_result_base = 0xabc000UL;
	require(ihk_smp_map_virtual_body_result(0x11, 0x22000UL, 4096,
			0, 0, fake_control_direct_map,
			fake_control_host_map, fake_control_map_log) ==
		0xabc000UL);
	require(control_map_calls == 1);
	require(control_map_phys[0] == 0x22000UL);
	require(control_map_size[0] == 4096);
	require(control_map_log_event == 0);
	require(ihk_smp_map_virtual_body_result(0x11, 0x33000UL, 8192,
			0x44000UL, 5, fake_control_direct_map,
			fake_control_host_map, fake_control_map_log) ==
		0x44055UL);
	require(control_host_map_calls == 1);
	require(control_host_map_dev == 0x11);
	require(control_host_map_phys == 0x33000UL);
	require(control_host_map_virt == 0x44000UL);
	require(control_host_map_size == 8192);
	require(control_host_map_flags == 5);
	reset_control_trace();
	control_map_fail_at = 1;
	require(ihk_smp_map_virtual_body_result(0x11, 0x55000UL, 4096,
			0, 0, fake_control_direct_map,
			fake_control_host_map, fake_control_map_log) == 0);
	require(control_map_log_event == 1);
	require(control_map_log_phys == 0x55000UL);
	mix(&digest, (unsigned long)control_host_map_flags);
	mix(&digest, control_map_log_phys);

	init_list_head(&os_mem_list);
	memset(os_chunks, 0, sizeof(os_chunks));
	os_chunks[0].addr = 0x100000UL;
	os_chunks[0].size = 0x4000UL;
	os_chunks[1].addr = 0x200000UL;
	os_chunks[1].size = 0x1000UL;
	fake_topo_list_add(&os_chunks[0].list, &os_mem_list);
	fake_topo_list_add(&os_chunks[1].list, &os_mem_list);
	reset_control_trace();
	require(ihk_smp_direct_map_virtual_body_result(
			(unsigned long)&os_mem_list, 0x200800UL, 0x100UL,
			&map_virtual_offsets, fake_control_phys_to_virt) ==
		0x10200800UL);
	require(control_phys_to_virt_calls == 1);
	require(control_phys_to_virt_phys == 0x200000UL);
	reset_control_trace();
	require(ihk_smp_direct_map_virtual_body_result(
			(unsigned long)&os_mem_list, 0x101000UL, 0x2000UL,
			&map_virtual_offsets, fake_control_phys_to_virt) ==
		0x10101000UL);
	require(control_phys_to_virt_calls == 1);
	require(control_phys_to_virt_phys == 0x100000UL);
	reset_control_trace();
	require(ihk_smp_direct_map_virtual_body_result(
			(unsigned long)&os_mem_list, 0x203000UL, 0x10UL,
			&map_virtual_offsets, fake_control_phys_to_virt) == 0);
	require(control_phys_to_virt_calls == 0);
	require(ihk_smp_direct_map_virtual_body_result(
			(unsigned long)&os_mem_list, 0x100000UL, 0x10UL,
			&map_virtual_offsets, NULL) == 0);
	mix(&digest, control_phys_to_virt_phys);

	reset_control_trace();
	require(ihk_smp_os_vtop_body_result(0x12345000UL, 0x401234UL,
			&translated_phys, 0x400000UL, 0x500000UL,
			0x200000UL, ~0x1fffffUL, fake_control_vtop,
			fake_control_vtop_log) == 0);
	require(translated_phys ==
		((0x12345000UL + 0x3fffffUL) & ~0x1fffffUL) + 0x1234UL);
	require(control_vtop_calls == 0);
	require(control_vtop_log_event == 1);
	require(control_vtop_log_phys == translated_phys);
	require(ihk_smp_os_vtop_body_result(0x12345000UL, 0x700000UL,
			&translated_phys, 0x400000UL, 0x500000UL,
			0x200000UL, ~0x1fffffUL, fake_control_vtop,
			fake_control_vtop_log) == 0);
	require(translated_phys == 0x800000UL);
	require(control_vtop_calls == 1);
	require(control_vtop_arg == 0x700000UL);
	require(control_vtop_log_event == 2);
	mix(&digest, translated_phys);

	for (fill_i = 0; fill_i < (int)sizeof(load_src); fill_i++)
		load_src[fill_i] = (char)(fill_i * 17 + 3);
	memset(&control_os, 0, sizeof(control_os));
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	control_os.mem_start = 0x1000UL;
	control_os.mem_end = 0x4000UL;
	reset_control_trace();
	control_map_result_base = (unsigned long)control_load_pages[0];
	require(ihk_smp_os_load_mem_body_result((unsigned long)&control_os,
			1, control_os.mem_start, control_os.mem_end,
			load_src, 5000, 128, &control_offsets, 4096,
			~4095UL, fake_control_lock, fake_control_unlock,
			fake_control_direct_map, fake_control_load_copy,
			fake_control_unmap, fake_control_load_log) == 0);
	require(control_os.status == BUILTIN_OS_STATUS_INITIAL);
	require(control_os.boot_rip == control_os.mem_start);
	require(control_lock_calls == 2);
	require(control_unlock_calls == 2);
	require(control_map_calls == 2);
	require(control_map_phys[0] == 0x1000UL);
	require(control_map_phys[1] == 0x2000UL);
	require(control_load_copy_calls == 2);
	require(control_load_copy_dst[0] ==
		(unsigned long)control_load_pages[0]);
	require(control_load_copy_dst[1] ==
		(unsigned long)control_load_pages[1]);
	require(control_load_copy_size[0] == 3968);
	require(control_load_copy_size[1] == 1032);
	require(!memcmp(control_load_pages[0], load_src + 128, 3968));
	require(!memcmp(control_load_pages[1], load_src + 4096, 1032));
	require(control_unmap_calls == 2);
	require(control_load_log_event == 5);
	require(control_load_log_b == 0x2000UL);
	require(control_load_log_c == 4096);
	require(control_load_log_d == 1032);
	mix(&digest, control_os.boot_rip);
	mix(&digest, (unsigned long)control_load_copy_calls);

	reset_control_trace();
	require(ihk_smp_os_load_mem_body_result((unsigned long)&control_os,
			0, control_os.mem_start, control_os.mem_end,
			load_src, 100, 0, &control_offsets, 4096,
			~4095UL, fake_control_lock, fake_control_unlock,
			fake_control_direct_map, fake_control_load_copy,
			fake_control_unmap, fake_control_load_log) == -EINVAL);
	require(control_load_log_event == 1);
	reset_control_trace();
	require(ihk_smp_os_load_mem_body_result((unsigned long)&control_os,
			1, control_os.mem_start, 0x1100UL, load_src, 0x200,
			0, &control_offsets, 4096, ~4095UL,
			fake_control_lock, fake_control_unlock,
			fake_control_direct_map, fake_control_load_copy,
			fake_control_unmap, fake_control_load_log) == -E2BIG);
	require(control_load_log_event == 2);
	control_os.status = BUILTIN_OS_STATUS_HUNGUP;
	reset_control_trace();
	require(ihk_smp_os_load_mem_body_result((unsigned long)&control_os,
			1, control_os.mem_start, control_os.mem_end,
			load_src, 100, 0, &control_offsets, 4096,
			~4095UL, fake_control_lock, fake_control_unlock,
			fake_control_direct_map, fake_control_load_copy,
			fake_control_unmap, fake_control_load_log) == -EBUSY);
	require(control_os.status == BUILTIN_OS_STATUS_HUNGUP);
	require(control_lock_calls == 1);
	require(control_load_log_event == 3);
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	reset_control_trace();
	control_map_fail_at = 1;
	require(ihk_smp_os_load_mem_body_result((unsigned long)&control_os,
			1, control_os.mem_start, control_os.mem_end,
			load_src, 100, 0, &control_offsets, 4096,
			~4095UL, fake_control_lock, fake_control_unlock,
			fake_control_direct_map, fake_control_load_copy,
			fake_control_unmap, fake_control_load_log) == -ENOMEM);
	require(control_os.status == BUILTIN_OS_STATUS_INITIAL);
	require(control_load_log_event == 4);
	require(control_load_log_a == 0x1000UL);
	mix(&digest, (unsigned long)control_load_log_event);

	require(ihk_smp_adjust_entry_body_result(0x12345678UL,
			0x900000UL) == 0x12345678UL);
	require(ihk_smp_identity_map_memory_body_result(0xabcdef00UL) ==
		0xabcdef00UL);
	require(ihk_smp_identity_unmap_memory_body_result() == 0);
	mix(&digest, ihk_smp_identity_map_memory_body_result(0x123000UL));
	require(ihk_smp_arch_dcache_flush_body_result(0x11110000UL,
			4096) == 0);
	reset_cpu_trace();
	require(ihk_smp_setup_warm_reset_vector_body_result(
			0x12345abcUL, 0x467UL, 0x469UL,
			fake_warm_lock, fake_warm_cmos_write,
			fake_warm_unlock, fake_warm_flush_tlb,
			fake_warm_write_word) == 0);
	require(warm_lock_calls == 1);
	require(warm_cmos_calls == 1);
	require(warm_cmos_value == 0x0a);
	require(warm_cmos_reg == 0x0f);
	require(warm_unlock_calls == 1);
	require(warm_unlock_flags == warm_lock_flags);
	require(warm_flush_calls == 1);
	require(warm_write_count == 2);
	require(warm_write_phys[0] == 0x467UL);
	require(warm_write_phys[1] == 0x469UL);
	require(warm_write_value[0] ==
		(unsigned short)(0x12345abcUL >> 4));
	require(warm_write_value[1] ==
		(unsigned short)(0x12345abcUL & 0x0f));
	require(warm_lock_event < warm_cmos_event);
	require(warm_cmos_event < warm_unlock_event);
	require(warm_unlock_event < warm_flush_event);
	require(warm_flush_event < warm_write_event[0]);
	require(warm_write_event[0] < warm_write_event[1]);
	mix(&digest, (unsigned long)warm_write_value[0]);
	mix(&digest, (unsigned long)warm_write_value[1]);

	{
		struct fake_trampoline_param param;
		struct fake_trampoline_os os;
		struct fake_trampoline_header *header;
		unsigned char trampoline[64];
		unsigned char trampoline_data[64];
		unsigned char backup[64];
		int i;

		reset_cpu_trace();
		memset(&param, 0, sizeof(param));
		memset(trampoline, 0xa5, sizeof(trampoline));
		memset(trampoline_data, 0x5a, sizeof(trampoline_data));
		memset(backup, 0, sizeof(backup));
		os.param = &param;
		os.boot_rip = 0x12345678000UL;
		require(ihk_smp_setup_trampoline_body_result(
				(unsigned long)&os, 3,
				&setup_trampoline_offsets, 1, 0xf6U,
				0x44U, 0xffff888000000000UL, 0x11110000UL,
				0x22220000UL, 1, (unsigned long)trampoline,
				(unsigned long)backup,
				(unsigned long)trampoline_data,
				sizeof(trampoline), 0x33330000UL,
				0x44440000UL, 0x55550000UL,
				fake_setup_apicid,
				fake_setup_raised_list_phys,
				fake_setup_log) == 0);
		for (i = 0; i < 3; i++) {
			require(param.ihk_ikc_irq_apicids[i] ==
				(unsigned int)(0x80 + i));
			require(param.ihk_ikc_cpu_raised_list[i] ==
				(void *)(0x500000UL +
					  (unsigned long)i * 0x1000UL));
		}
		require(setup_apicid_calls == 3);
		require(setup_raised_calls == 3);
		require(param.ikc_irq_work_func == (void *)0x55550000UL);
		require(param.ihk_ikc_irq == 0xf6U);
		require(param.page_offset_base == 0xffff888000000000UL);
		require(param.linux_kernel_pgt_phys == 0x22220000UL);
		require(setup_log_calls == 1 && setup_log_event == 1);
		require(setup_log_value0 == 0x11110000UL);
		require(setup_log_value1 == 0x22220000UL);
		for (i = 0; i < (int)sizeof(backup); i++)
			require(backup[i] == 0xa5);
		require(memcmp(trampoline + sizeof(*header),
			       trampoline_data + sizeof(*header),
			       sizeof(trampoline) - sizeof(*header)) == 0);
		header = (struct fake_trampoline_header *)trampoline;
		require(header->page_table == 0x33330000UL);
		require(header->next_ip == os.boot_rip);
		require(header->notify_address == 0x44440000UL);
		mix(&digest, header->page_table ^ header->next_ip);
		mix(&digest, param.ihk_ikc_irq);
	}

	{
		struct fake_trampoline_param param;
		struct fake_trampoline_os os;
		struct fake_trampoline_header *header;
		unsigned char trampoline[64];
		unsigned char trampoline_data[64];
		unsigned char backup[64];

		reset_cpu_trace();
		memset(&param, 0, sizeof(param));
		memset(trampoline, 0xcc, sizeof(trampoline));
		memset(trampoline_data, 0x11, sizeof(trampoline_data));
		memset(backup, 0xee, sizeof(backup));
		os.param = &param;
		os.boot_rip = 0x77770000UL;
		require(ihk_smp_setup_trampoline_body_result(
				(unsigned long)&os, 2,
				&setup_trampoline_offsets, 0, 0xf6U,
				0x45U, 0xffff800000000000UL, 0xaaaa0000UL,
				0xbbbb0000UL, 0, (unsigned long)trampoline,
				(unsigned long)backup,
				(unsigned long)trampoline_data,
				sizeof(trampoline), 0xcccc0000UL,
				0xdddd0000UL, 0, fake_setup_apicid,
				fake_setup_raised_list_phys,
				fake_setup_log) == 0);
		require(setup_apicid_calls == 2);
		require(setup_raised_calls == 0);
		require(param.ihk_ikc_irq == 0x45U);
		require(param.ikc_irq_work_func == NULL);
		require(param.ihk_ikc_cpu_raised_list[0] == NULL);
		require(backup[0] == 0xee);
		header = (struct fake_trampoline_header *)trampoline;
		require(header->page_table == 0xcccc0000UL);
		require(header->next_ip == os.boot_rip);
		require(header->notify_address == 0xdddd0000UL);
		require(memcmp(trampoline + sizeof(*header),
			       trampoline_data + sizeof(*header),
			       sizeof(trampoline) - sizeof(*header)) == 0);
		mix(&digest, param.ihk_ikc_irq_apicids[1]);
	}

	{
		struct fake_startup_os os;
		unsigned long startup[8];
		unsigned long startup_data_words[8] = {
			0x10, 0x11, 0x12, 0x13,
			0x14, 0x15, 0x16, 0x17,
		};

		reset_cpu_trace();
		memset(&os, 0, sizeof(os));
		memset(startup, 0, sizeof(startup));
		os.bootstrap_mem_end = 0x100000UL;
		startup_map_virtual_result = (unsigned long)startup;
		require(ihk_smp_os_setup_startup_body_result(
				(unsigned long)&os, 0x700000UL, 0x900000UL,
				&setup_startup_offsets, 0x3000UL, 0x1000UL,
				~0xfffUL, 0x80000000UL, 0xf0000000UL,
				0x2000UL, 0x1000UL, 12,
				(unsigned long)startup_data_words,
				sizeof(startup_data_words), 0x600000UL,
				fake_startup_alloc_page,
				fake_startup_page_phys,
				fake_startup_map_kernel,
				fake_startup_map_virtual,
				fake_startup_unmap_virtual,
				fake_startup_log) == 0);
		require(os.boot_pt == (void *)0xabcdef000UL);
		require(startup_map_calls == 8);
		require(startup_map_pt[0] == 0xabcdef000UL);
		require(startup_map_virt[0] == 0);
		require(startup_map_phys[0] == 0);
		require(startup_map_virt[3] == 0x80000000UL);
		require(startup_map_phys[3] == 0);
		require(startup_map_virt[6] == 0xf0000000UL);
		require(startup_map_phys[6] == 0x700000UL);
		require(startup_map_virtual_calls == 1);
		require(startup_map_virtual_phys == 0xfe000UL);
		require(startup_map_virtual_size == 0x1000UL);
		require(startup_phys_calls == 1);
		require(startup_last_phys_virt == 0xabcdef000UL);
		require(startup[0] == 0x10 && startup[1] == 0x11);
		require(startup[2] == 0xaccdef000UL);
		require(startup[3] == 0xff000UL);
		require(startup[4] == 0x700000UL);
		require(startup[5] == 0x600000UL);
		require(startup[6] == 0x900000UL);
		require(startup[7] == 0x17);
		require(startup_unmap_calls == 1);
		require(startup_unmap_virt == (unsigned long)startup);
		require(os.boot_rip == 0xfe000UL);
		require(startup_log_event == 0);
		mix(&digest, os.boot_rip ^ startup[2] ^ startup[6]);
	}

	{
		struct fake_startup_os os;
		unsigned long startup_data_words[2] = { 0x1, 0x2 };

		reset_cpu_trace();
		memset(&os, 0, sizeof(os));
		startup_alloc_result = 0;
		require(ihk_smp_os_setup_startup_body_result(
				(unsigned long)&os, 0x700000UL, 0x900000UL,
				&setup_startup_offsets, 0x1000UL, 0x1000UL,
				~0xfffUL, 0x80000000UL, 0xf0000000UL,
				0x1000UL, 0x1000UL, 12,
				(unsigned long)startup_data_words,
				sizeof(startup_data_words), 0x600000UL,
				fake_startup_alloc_page,
				fake_startup_page_phys,
				fake_startup_map_kernel,
				fake_startup_map_virtual,
				fake_startup_unmap_virtual,
				fake_startup_log) == -ENOMEM);
		require(startup_log_event == 1);
		require(startup_map_calls == 0);

		reset_cpu_trace();
		memset(&os, 0, sizeof(os));
		os.bootstrap_mem_end = 0x100000UL;
		startup_map_fail_at = 2;
		require(ihk_smp_os_setup_startup_body_result(
				(unsigned long)&os, 0x700000UL, 0x900000UL,
				&setup_startup_offsets, 0x3000UL, 0x1000UL,
				~0xfffUL, 0x80000000UL, 0xf0000000UL,
				0x1000UL, 0x1000UL, 12,
				(unsigned long)startup_data_words,
				sizeof(startup_data_words), 0x600000UL,
				fake_startup_alloc_page,
				fake_startup_page_phys,
				fake_startup_map_kernel,
				fake_startup_map_virtual,
				fake_startup_unmap_virtual,
				fake_startup_log) == -ENOMEM);
		require(startup_log_event == 2);
		require(startup_map_calls == 2);

		reset_cpu_trace();
		memset(&os, 0, sizeof(os));
		os.bootstrap_mem_end = 0x100000UL;
		startup_map_virtual_result = 0;
		require(ihk_smp_os_setup_startup_body_result(
				(unsigned long)&os, 0x700000UL, 0x900000UL,
				&setup_startup_offsets, 0x1000UL, 0x1000UL,
				~0xfffUL, 0x80000000UL, 0xf0000000UL,
				0x1000UL, 0x1000UL, 12,
				(unsigned long)startup_data_words,
				sizeof(startup_data_words), 0x600000UL,
				fake_startup_alloc_page,
				fake_startup_page_phys,
				fake_startup_map_kernel,
				fake_startup_map_virtual,
				fake_startup_unmap_virtual,
				fake_startup_log) == -ENOMEM);
		require(startup_log_event == 5);
		require(startup_unmap_calls == 0);
	}

	{
		unsigned long page = 0x5555UL;
		unsigned long phys = 0;
		unsigned long va = 0;
		int using_linux = -1;

		reset_cpu_trace();
		require(ihk_smp_arch_init_trampoline_body_result(
				0x70000UL, 0x1000UL, 2, 3, 0x1000UL,
				0x100000UL, fake_arch_init_linux_phys,
				&page, &phys, &va, &using_linux,
				fake_arch_init_ioremap, fake_arch_init_alloc,
				fake_arch_init_page_phys,
				fake_arch_init_page_virt,
				fake_arch_init_free,
				fake_arch_init_direct_virt,
				fake_arch_init_log) == 0);
		require(page == 0);
		require(phys == 0x70000UL);
		require(va == 0x170000UL);
		require(using_linux == 0);
		require(arch_init_ioremap_calls == 1);
		require(arch_init_ioremap_phys == 0x70000UL);
		require(arch_init_ioremap_size == 0x1000UL);
		require(arch_init_alloc_calls == 0);
		require(arch_init_linux_phys_calls == 0);
		require(arch_init_log_count == 1);
		require(arch_init_log_event[0] == 1);
		require(arch_init_log_value[0] == 0x70000UL);
		mix(&digest, phys ^ va);
	}

	{
		unsigned long page = 0;
		unsigned long phys = 0;
		unsigned long va = 0;
		int using_linux = -1;

		reset_cpu_trace();
		arch_init_alloc_sequence[0] = 0x200000UL;
		arch_init_alloc_sequence[1] = 0x70000UL;
		require(ihk_smp_arch_init_trampoline_body_result(
				0, 0x1000UL, 2, 3, 0x1000UL,
				0x100000UL, fake_arch_init_linux_phys,
				&page, &phys, &va, &using_linux,
				fake_arch_init_ioremap, fake_arch_init_alloc,
				fake_arch_init_page_phys,
				fake_arch_init_page_virt,
				fake_arch_init_free,
				fake_arch_init_direct_virt,
				fake_arch_init_log) == 0);
		require(page == 0x70000UL);
		require(phys == 0x70000UL);
		require(va == 0x270000UL);
		require(using_linux == 0);
		require(arch_init_alloc_calls == 2);
		require(arch_init_page_phys_calls == 3);
		require(arch_init_page_phys_arg[0] == 0x200000UL);
		require(arch_init_page_phys_arg[1] == 0x70000UL);
		require(arch_init_page_phys_arg[2] == 0x70000UL);
		require(arch_init_free_calls == 1);
		require(arch_init_free_page[0] == 0x200000UL);
		require(arch_init_free_order[0] == 2);
		require(arch_init_page_virt_calls == 1);
		require(arch_init_page_virt_arg[0] == 0x70000UL);
		require(arch_init_linux_phys_calls == 0);
		require(arch_init_direct_virt_calls == 0);
		require(arch_init_log_count == 1);
		require(arch_init_log_event[0] == 3);
		require(arch_init_log_value[0] == 0x70000UL);
		mix(&digest, page ^ arch_init_free_page[0]);
	}

	{
		unsigned long page = 0x1234UL;
		unsigned long phys = 0;
		unsigned long va = 0;
		int using_linux = 0;

		reset_cpu_trace();
		arch_init_alloc_sequence[0] = 0x200000UL;
		arch_init_alloc_sequence[1] = 0;
		arch_init_alloc_sequence[2] = 0x300000UL;
		require(ihk_smp_arch_init_trampoline_body_result(
				0, 0x1000UL, 2, 3, 0x1000UL,
				0x100000UL, fake_arch_init_linux_phys,
				&page, &phys, &va, &using_linux,
				fake_arch_init_ioremap, fake_arch_init_alloc,
				fake_arch_init_page_phys,
				fake_arch_init_page_virt,
				fake_arch_init_free,
				fake_arch_init_direct_virt,
				fake_arch_init_log) == 0);
		require(page == 0);
		require(phys == 0x9f000UL);
		require(va == 0x39f000UL);
		require(using_linux == 1);
		require(arch_init_alloc_calls == 3);
		require(arch_init_page_phys_calls == 3);
		require(arch_init_free_calls == 2);
		require(arch_init_free_page[0] == 0x200000UL);
		require(arch_init_free_page[1] == 0x300000UL);
		require(arch_init_linux_phys_calls == 1);
		require(arch_init_direct_virt_calls == 1);
		require(arch_init_direct_virt_phys == 0x9f000UL);
		require(arch_init_log_count == 2);
		require(arch_init_log_event[0] == 2);
		require(arch_init_log_value[0] == 0x9f000UL);
		require(arch_init_log_event[1] == 3);
		require(arch_init_log_value[1] == 0x9f000UL);
		mix(&digest, phys ^ va ^ (unsigned long)using_linux);
	}

	{
		reset_cpu_trace();
		require(ihk_smp_arch_init_linux_work_tail_body_result(
				0xef, fake_arch_init_tail_ident,
				fake_arch_init_tail_topology,
				fake_arch_init_tail_log) == 0);
		require(arch_init_tail_ident_calls == 1);
		require(arch_init_tail_topology_calls == 1);
		require(arch_init_tail_log_count == 1);
		require(arch_init_tail_log_event[0] == 1);
		require(arch_init_tail_log_value[0] == 0xef);
		mix(&digest, arch_init_tail_log_value[0]);

		reset_cpu_trace();
		arch_init_tail_ident_result = -14;
		require(ihk_smp_arch_init_linux_work_tail_body_result(
				0xee, fake_arch_init_tail_ident,
				fake_arch_init_tail_topology,
				fake_arch_init_tail_log) == -14);
		require(arch_init_tail_ident_calls == 1);
		require(arch_init_tail_topology_calls == 0);
		require(arch_init_tail_log_count == 2);
		require(arch_init_tail_log_event[0] == 1);
		require(arch_init_tail_log_event[1] == 2);
		require(arch_init_tail_log_value[1] == -14);
		mix(&digest, (unsigned long)arch_init_tail_log_value[1]);

		reset_cpu_trace();
		arch_init_tail_topology_result = -22;
		require(ihk_smp_arch_init_linux_work_tail_body_result(
				0xed, fake_arch_init_tail_ident,
				fake_arch_init_tail_topology,
				fake_arch_init_tail_log) == -22);
		require(arch_init_tail_ident_calls == 1);
		require(arch_init_tail_topology_calls == 1);
		require(arch_init_tail_log_count == 2);
		require(arch_init_tail_log_event[0] == 1);
		require(arch_init_tail_log_event[1] == 3);
		require(arch_init_tail_log_value[1] == -22);
		mix(&digest, (unsigned long)arch_init_tail_log_value[1]);
	}

	{
		unsigned long ident_table[64];
		unsigned long ident_phys = 0;
		unsigned long ident_virt = 0;
		int ident_order = 0;

		reset_cpu_trace();
		memset(ident_table, 0xa5, sizeof(ident_table));
		ident_page_virt_result = (unsigned long)ident_table;
		require(ihk_smp_init_ident_page_table_body_result(
				128, 64, 6, 3, 8, 8, 0x63, 0xe3,
				&ident_phys, &ident_virt, &ident_order,
				fake_ident_alloc, fake_ident_page_phys,
				fake_ident_page_virt, fake_ident_zero,
				fake_ident_log) == 0);
		require(ident_alloc_calls == 1);
		require(ident_alloc_order == 3);
		require(ident_page_phys_calls == 1);
		require(ident_page_phys_arg == 0xabc0UL);
		require(ident_page_virt_calls == 1);
		require(ident_page_virt_arg == 0xabc0UL);
		require(ident_zero_calls == 1);
		require(ident_zero_addr == (unsigned long)ident_table);
		require(ident_zero_len == 2);
		require(ident_phys == 0x400000UL);
		require(ident_virt == (unsigned long)ident_table);
		require(ident_order == 3);
		require(ident_table[0] == 0x400063UL);
		require(ident_table[8] == 0x4000e3UL);
		require(ident_table[9] == 0x4000e3UL);
		require(ident_table[16] == 0xe3UL);
		require(ident_table[17] == 0xebUL);
		require(ident_table[31] == 0xfbUL);
		require(ident_log_count == 2);
		require(ident_log_event[0] == 1);
		require(ident_log_value0[0] == 2);
		require(ident_log_value1[0] == 3);
		require(ident_log_event[1] == 4);
		require(ident_log_value0[1] == 0x400000UL);
		require(ident_log_value1[1] == (unsigned long)ident_table);
		mix(&digest, ident_table[0] ^ ident_table[31]);

		reset_cpu_trace();
		ident_alloc_result = 0;
		require(ihk_smp_init_ident_page_table_body_result(
				128, 64, 6, 3, 8, 8, 0x63, 0xe3,
				&ident_phys, &ident_virt, &ident_order,
				fake_ident_alloc, fake_ident_page_phys,
				fake_ident_page_virt, fake_ident_zero,
				fake_ident_log) == ENOMEM);
		require(ident_alloc_calls == 1);
		require(ident_page_phys_calls == 0);
		require(ident_zero_calls == 0);
		require(ident_log_count == 2);
		require(ident_log_event[0] == 1);
		require(ident_log_event[1] == 2);
		mix(&digest, (unsigned long)ident_log_event[1]);

		reset_cpu_trace();
		memset(ident_table, 0, sizeof(ident_table));
		ident_page_virt_result = (unsigned long)ident_table;
		require(ihk_smp_init_ident_page_table_body_result(
				128, 64, 6, 3, 1, 1, 0x63, 0xe3,
				&ident_phys, &ident_virt, &ident_order,
				fake_ident_alloc, fake_ident_page_phys,
				fake_ident_page_virt, fake_ident_zero,
				fake_ident_log) == 0);
		require(ident_log_count == 3);
		require(ident_log_event[1] == 3);
		require(ident_log_value0[1] == 1);
		require(ident_log_value1[1] == 2);
		mix(&digest, ident_log_value0[1] ^ ident_log_value1[1]);
	}

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 1;
	require(ihk_smp_reset_cpu_body_result(7, 0x280, 0x4500,
			0x500, fake_reset_preempt_disable,
			fake_reset_preempt_enable, fake_reset_get_maxlvt,
			fake_reset_apic_integrated, fake_reset_apic_write,
			fake_reset_apic_read, fake_reset_icr_write,
			fake_reset_wait, fake_reset_delay, fake_reset_log) == 0);
	require(reset_preempt_disable_calls == 1);
	require(reset_preempt_enable_calls == 1);
	require(reset_get_maxlvt_calls == 1);
	require(reset_integrated_calls == 1);
	require(reset_integrated_phys == 7);
	require(reset_apic_write_count == 1);
	require(reset_apic_write_regs[0] == 0x280);
	require(reset_apic_write_values[0] == 0);
	require(reset_apic_read_count == 1);
	require(reset_apic_read_regs[0] == 0x280);
	require(reset_icr_write_count == 2);
	require(reset_icr_write_values[0] == 0x4500);
	require(reset_icr_write_values[1] == 0x500);
	require(reset_icr_write_phys[0] == 7);
	require(reset_icr_write_phys[1] == 7);
	require(reset_wait_count == 2);
	require(reset_delay_count == 1);
	require(reset_delay_msecs == 10);
	require(reset_log_count == 5);
	require(reset_log_event[0] == 1 && reset_log_phys[0] == 7);
	require(reset_log_event[4] == 5 && reset_log_phys[4] == 7);
	require(reset_preempt_disable_event < reset_get_maxlvt_event);
	require(reset_get_maxlvt_event < reset_integrated_event);
	require(reset_integrated_event < reset_apic_write_event[0]);
	require(reset_apic_write_event[0] < reset_apic_read_event[0]);
	require(reset_apic_read_event[0] < reset_icr_write_event[0]);
	require(reset_icr_write_event[0] < reset_wait_event[0]);
	require(reset_wait_event[0] < reset_delay_event);
	require(reset_delay_event < reset_icr_write_event[1]);
	require(reset_icr_write_event[1] < reset_wait_event[1]);
	require(reset_wait_event[1] < reset_preempt_enable_event);
	mix(&digest, (unsigned long)reset_icr_write_values[0]);
	mix(&digest, (unsigned long)reset_wait_count);

	reset_cpu_trace();
	reset_maxlvt = 3;
	reset_integrated = 1;
	require(ihk_smp_reset_cpu_body_result(5, 0x280, 0x4500,
			0x500, fake_reset_preempt_disable,
			fake_reset_preempt_enable, fake_reset_get_maxlvt,
			fake_reset_apic_integrated, fake_reset_apic_write,
			fake_reset_apic_read, fake_reset_icr_write,
			fake_reset_wait, fake_reset_delay, fake_reset_log) == 0);
	require(reset_apic_write_count == 0);
	require(reset_apic_read_count == 1);
	require(reset_icr_write_count == 2);
	require(reset_preempt_enable_calls == 1);
	mix(&digest, (unsigned long)reset_apic_read_count);

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 0;
	require(ihk_smp_reset_cpu_body_result(4, 0x280, 0x4500,
			0x500, fake_reset_preempt_disable,
			fake_reset_preempt_enable, fake_reset_get_maxlvt,
			fake_reset_apic_integrated, fake_reset_apic_write,
			fake_reset_apic_read, fake_reset_icr_write,
			fake_reset_wait, fake_reset_delay, fake_reset_log) == 0);
	require(reset_apic_write_count == 0);
	require(reset_apic_read_count == 0);
	require(reset_icr_write_count == 2);
	require(reset_wait_count == 2);
	mix(&digest, (unsigned long)reset_apic_write_count);

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 1;
	reset_apic_read_value = 0;
	reset_wait_use_sequence = 1;
	require(ihk_smp_wakeup_secondary_cpu_via_init_body_result(
			7, 0x12345000UL, 0x280, 0x4500, 0x500, 0x600,
			fake_reset_get_maxlvt, fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_reset_icr_write, fake_reset_wait,
			fake_reset_delay, fake_reset_udelay,
			fake_reset_barrier, fake_reset_init_deasserted,
			fake_wakeup_log) == 0);
	require(reset_get_maxlvt_calls == 1);
	require(reset_integrated_calls == 1);
	require(reset_integrated_phys == 7);
	require(reset_apic_write_count == 5);
	require(reset_apic_read_count == 5);
	require(reset_icr_write_count == 4);
	require(reset_icr_write_values[0] == 0x4500);
	require(reset_icr_write_values[1] == 0x500);
	require(reset_icr_write_values[2] == (0x600 | 0x12345));
	require(reset_icr_write_values[3] == (0x600 | 0x12345));
	require(reset_icr_write_phys[2] == 7);
	require(reset_wait_count == 4);
	require(reset_delay_count == 1);
	require(reset_delay_msecs == 10);
	require(reset_udelay_count == 4);
	require(reset_udelay_usecs[0] == 300);
	require(reset_udelay_usecs[1] == 200);
	require(reset_udelay_usecs[2] == 300);
	require(reset_udelay_usecs[3] == 200);
	require(reset_barrier_calls == 1);
	require(reset_init_deasserted_calls == 1);
	require(reset_log_count == 14);
	require(reset_log_event[0] == 1);
	require(reset_log_event[4] == 4 && reset_log_value[4] == 2);
	require(reset_log_event[5] == 5 && reset_log_value[5] == 1);
	require(reset_log_event[9] == 5 && reset_log_value[9] == 2);
	require(reset_log_event[13] == 8);
	require(reset_apic_read_event[0] < reset_icr_write_event[0]);
	require(reset_icr_write_event[0] < reset_wait_event[0]);
	require(reset_wait_event[0] < reset_delay_event);
	require(reset_delay_event < reset_icr_write_event[1]);
	require(reset_icr_write_event[1] < reset_wait_event[1]);
	require(reset_wait_event[1] < reset_barrier_event);
	require(reset_barrier_event < reset_init_deasserted_event);
	require(reset_init_deasserted_event < reset_icr_write_event[2]);
	require(reset_icr_write_event[2] < reset_udelay_event[0]);
	require(reset_udelay_event[0] < reset_wait_event[2]);
	require(reset_wait_event[2] < reset_udelay_event[1]);
	require(reset_udelay_event[1] < reset_apic_read_event[2]);
	require(reset_apic_read_event[2] < reset_icr_write_event[3]);
	mix(&digest, (unsigned long)reset_icr_write_values[2]);
	mix(&digest, (unsigned long)reset_udelay_count);

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 0;
	reset_wait_use_sequence = 1;
	require(ihk_smp_wakeup_secondary_cpu_via_init_body_result(
			4, 0x100000UL, 0x280, 0x4500, 0x500, 0x600,
			fake_reset_get_maxlvt, fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_reset_icr_write, fake_reset_wait,
			fake_reset_delay, fake_reset_udelay,
			fake_reset_barrier, fake_reset_init_deasserted,
			fake_wakeup_log) == 0);
	require(reset_apic_write_count == 0);
	require(reset_apic_read_count == 0);
	require(reset_icr_write_count == 2);
	require(reset_wait_count == 2);
	require(reset_udelay_count == 0);
	require(reset_barrier_calls == 1);
	require(reset_init_deasserted_calls == 1);
	require(reset_log_count == 6);
	require(reset_log_event[4] == 4 && reset_log_value[4] == 0);
	require(reset_log_event[5] == 8);
	mix(&digest, (unsigned long)reset_log_count);

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 1;
	reset_apic_read_value = 0;
	reset_wait_use_sequence = 1;
	reset_wait_values[2] = 0x40;
	require(ihk_smp_wakeup_secondary_cpu_via_init_body_result(
			8, 0x200000UL, 0x280, 0x4500, 0x500, 0x600,
			fake_reset_get_maxlvt, fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_reset_icr_write, fake_reset_wait,
			fake_reset_delay, fake_reset_udelay,
			fake_reset_barrier, fake_reset_init_deasserted,
			fake_wakeup_log) == 0x40);
	require(reset_icr_write_count == 3);
	require(reset_wait_count == 3);
	require(reset_udelay_count == 2);
	require(reset_log_event[9] == 8);
	require(reset_log_event[10] == 9 && reset_log_value[10] == 0x40);
	mix(&digest, (unsigned long)reset_wait_values[2]);

	reset_cpu_trace();
	reset_maxlvt = 4;
	reset_integrated = 1;
	reset_apic_read_value = 0x2;
	reset_wait_use_sequence = 1;
	require(ihk_smp_wakeup_secondary_cpu_via_init_body_result(
			9, 0x300000UL, 0x280, 0x4500, 0x500, 0x600,
			fake_reset_get_maxlvt, fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_reset_icr_write, fake_reset_wait,
			fake_reset_delay, fake_reset_udelay,
			fake_reset_barrier, fake_reset_init_deasserted,
			fake_wakeup_log) == 0x2);
	require(reset_icr_write_count == 3);
	require(reset_wait_count == 3);
	require(reset_apic_read_count == 3);
	require(reset_log_event[9] == 8);
	require(reset_log_event[10] == 10 && reset_log_value[10] == 0x2);
	mix(&digest, (unsigned long)reset_apic_read_count);

	reset_cpu_trace();
	reset_integrated = 1;
	wakeup_via_ret = -17;
	require(ihk_smp_wakeup_secondary_cpu_body_result(
			3, 0x444000UL, 99, 0x280,
			fake_wakeup_clear_init_deasserted,
			fake_wakeup_non_unique_apic,
			fake_wakeup_setup_warm_reset_vector,
			fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_wakeup_apic_available, fake_wakeup_apic,
			fake_reset_preempt_disable, fake_wakeup_via_init,
			fake_reset_preempt_enable, fake_wakeup_top_log) == -17);
	require(reset_init_deasserted_calls == 1);
	require(wakeup_non_unique_calls == 1);
	require(wakeup_setup_calls == 1);
	require(wakeup_setup_start_eip == 0x444000UL);
	require(reset_integrated_calls == 1);
	require(reset_integrated_phys == 99);
	require(reset_apic_write_count == 1);
	require(reset_apic_read_count == 1);
	require(wakeup_apic_available_calls == 1);
	require(wakeup_apic_calls == 0);
	require(reset_preempt_disable_calls == 1);
	require(reset_preempt_enable_calls == 1);
	require(wakeup_via_calls == 1);
	require(wakeup_via_apicid == 3);
	require(wakeup_via_start_eip == 0x444000UL);
	require(wakeup_top_log_count == 2);
	require(wakeup_top_log_event[0] == 1);
	require(wakeup_top_log_event[1] == 3);
	require(reset_init_deasserted_event < wakeup_non_unique_event);
	require(wakeup_non_unique_event < wakeup_setup_event);
	require(wakeup_setup_event < reset_integrated_event);
	require(reset_integrated_event < reset_apic_write_event[0]);
	require(reset_apic_write_event[0] < reset_apic_read_event[0]);
	require(reset_apic_read_event[0] < wakeup_apic_available_event);
	require(wakeup_apic_available_event < reset_preempt_disable_event);
	require(reset_preempt_disable_event < wakeup_via_event);
	require(wakeup_via_event < reset_preempt_enable_event);
	mix(&digest, (unsigned long)wakeup_via_ret);
	mix(&digest, wakeup_setup_start_eip);

	reset_cpu_trace();
	wakeup_non_unique = 1;
	wakeup_apic_available = 1;
	wakeup_apic_ret = 77;
	require(ihk_smp_wakeup_secondary_cpu_body_result(
			4, 0x555000UL, 98, 0x280,
			fake_wakeup_clear_init_deasserted,
			fake_wakeup_non_unique_apic,
			fake_wakeup_setup_warm_reset_vector,
			fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_wakeup_apic_available, fake_wakeup_apic,
			fake_reset_preempt_disable, fake_wakeup_via_init,
			fake_reset_preempt_enable, fake_wakeup_top_log) == 77);
	require(wakeup_setup_calls == 0);
	require(reset_integrated_calls == 0);
	require(reset_apic_write_count == 0);
	require(reset_apic_read_count == 0);
	require(wakeup_apic_available_calls == 1);
	require(wakeup_apic_calls == 1);
	require(wakeup_apic_apicid == 4);
	require(wakeup_apic_start_eip == 0x555000UL);
	require(wakeup_via_calls == 0);
	require(reset_preempt_disable_calls == 0);
	require(reset_preempt_enable_calls == 0);
	require(wakeup_top_log_count == 1);
	require(wakeup_top_log_event[0] == 2);
	require(reset_init_deasserted_event < wakeup_non_unique_event);
	require(wakeup_non_unique_event < wakeup_apic_available_event);
	require(wakeup_apic_available_event < wakeup_apic_event);
	mix(&digest, (unsigned long)wakeup_apic_ret);

	reset_cpu_trace();
	reset_integrated = 0;
	wakeup_apic_available = 1;
	wakeup_apic_ret = -5;
	require(ihk_smp_wakeup_secondary_cpu_body_result(
			5, 0x666000UL, 97, 0x280,
			fake_wakeup_clear_init_deasserted,
			fake_wakeup_non_unique_apic,
			fake_wakeup_setup_warm_reset_vector,
			fake_reset_apic_integrated,
			fake_reset_apic_write, fake_reset_apic_read,
			fake_wakeup_apic_available, fake_wakeup_apic,
			fake_reset_preempt_disable, fake_wakeup_via_init,
			fake_reset_preempt_enable, fake_wakeup_top_log) == -5);
	require(wakeup_setup_calls == 1);
	require(reset_integrated_calls == 1);
	require(reset_integrated_phys == 97);
	require(reset_apic_write_count == 0);
	require(reset_apic_read_count == 0);
	require(wakeup_apic_calls == 1);
	require(wakeup_via_calls == 0);
	require(reset_preempt_disable_calls == 0);
	require(reset_preempt_enable_calls == 0);
	require(wakeup_top_log_count == 2);
	require(wakeup_top_log_event[0] == 1);
	require(wakeup_top_log_event[1] == 2);
	mix(&digest, (unsigned long)wakeup_apic_calls);

	reset_arch_exit_trace();
	require(ihk_smp_arch_exit_body_result(0x123400UL, 0,
			0x567800UL, 2, 0x900000UL, 3,
			fake_exit_free_trampoline, fake_exit_unmap,
			fake_exit_free_pages) == 0);
	require(exit_free_trampoline_calls == 1);
	require(exit_free_trampoline_page == 0x123400UL);
	require(exit_free_trampoline_order == 2);
	require(exit_unmap_calls == 0);
	require(exit_free_pages_calls == 1);
	require(exit_free_pages_addr == 0x900000UL);
	require(exit_free_pages_order == 3);
	require(exit_free_trampoline_event < exit_free_pages_event);
	mix(&digest, exit_free_trampoline_page);
	mix(&digest, (unsigned long)exit_free_pages_order);

	reset_arch_exit_trace();
	require(ihk_smp_arch_exit_body_result(0, 1, 0x567800UL, 2,
			0x900000UL, 0, fake_exit_free_trampoline,
			fake_exit_unmap, fake_exit_free_pages) == 0);
	require(exit_free_trampoline_calls == 0);
	require(exit_unmap_calls == 0);
	require(exit_free_pages_calls == 0);
	mix(&digest, (unsigned long)exit_unmap_calls);

	reset_arch_exit_trace();
	require(ihk_smp_arch_exit_body_result(0, 0, 0x567800UL, 2,
			0x900000UL, 1, fake_exit_free_trampoline,
			fake_exit_unmap, fake_exit_free_pages) == 0);
	require(exit_free_trampoline_calls == 0);
	require(exit_unmap_calls == 1);
	require(exit_unmap_virt == 0x567800UL);
	require(exit_free_pages_calls == 1);
	require(exit_free_pages_addr == 0x900000UL);
	require(exit_free_pages_order == 1);
	require(exit_unmap_event < exit_free_pages_event);
	mix(&digest, exit_unmap_virt);
	require(ihk_smp_calc_ns_per_tsc_body_result(1, 25, 1234567) ==
		400);
	require(ihk_smp_calc_ns_per_tsc_body_result(1, 0, 2500000) ==
		400);
	require(ihk_smp_calc_ns_per_tsc_body_result(0, 25, 2000000) ==
		500);
	require(ihk_smp_x2apic_is_enabled_body_result(1UL << 10) ==
		(1UL << 10));
	require(ihk_smp_x2apic_is_enabled_body_result(0x200UL) == 0);
	require(ihk_smp_vector_entry_used_result(0x1234UL, 0) == 1);
	require(ihk_smp_vector_entry_used_result(0, 0) == 0);
	require(ihk_smp_vector_set_needed_result(0, 0) == 1);
	require(ihk_smp_vector_set_needed_result(0x1234UL, 0) == 0);
	require(ihk_smp_vector_release_value_result((unsigned long)-1) ==
		(unsigned long)-1);
	mix(&digest, ihk_smp_calc_ns_per_tsc_body_result(1, 25, 1234567));
	mix(&digest, ihk_smp_x2apic_is_enabled_body_result(1UL << 10));

	require(ihk_smp_interrupt_cpu_valid_result(1, 3) == 1);
	require(ihk_smp_interrupt_cpu_valid_result(3, 3) == 0);
	reset_control_trace();
	require(ihk_smp_os_issue_interrupt_body_result(1, 3, irq_hw_ids,
			0xf1, 7, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_write, fake_control_legacy_ipi) ==
		-EINVAL);
	require(control_irq_save_calls == 1);
	require(control_irq_restore_calls == 1);
	require(control_irq_restore_flags == 0x5001UL);
	require(control_x2apic_enabled_calls == 1);
	require(control_x2apic_write_calls == 0);
	require(control_legacy_ipi_calls == 1);
	require(control_legacy_hw_id == 202);
	require(control_legacy_vector == 0xf1);
	require(control_legacy_dest == 7);
	mix(&digest, (unsigned long)control_legacy_hw_id);
	mix(&digest, (unsigned long)control_legacy_vector);

	reset_control_trace();
	control_x2apic_enabled = 1;
	require(ihk_smp_os_issue_interrupt_body_result(2, 3, irq_hw_ids,
			0xf2, 7, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_write, fake_control_legacy_ipi) ==
		-EINVAL);
	require(control_irq_save_calls == 1);
	require(control_irq_restore_calls == 1);
	require(control_x2apic_enabled_calls == 1);
	require(control_x2apic_write_calls == 1);
	require(control_x2apic_hw_id == 303);
	require(control_x2apic_vector == 0xf2);
	require(control_legacy_ipi_calls == 0);
	mix(&digest, (unsigned long)control_x2apic_hw_id);

	reset_control_trace();
	require(ihk_smp_os_issue_interrupt_body_result(3, 3, irq_hw_ids,
			0xf3, 7, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_write, fake_control_legacy_ipi) ==
		-EINVAL);
	require(control_irq_save_calls == 0);
	require(control_irq_restore_calls == 0);
	require(control_x2apic_write_calls == 0);
	require(control_legacy_ipi_calls == 0);
	require(ihk_smp_os_issue_interrupt_body_result(0, 3, NULL,
			0xf4, 7, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_write, fake_control_legacy_ipi) ==
		-EINVAL);
	require(control_irq_save_calls == 0);
	mix(&digest, (unsigned long)control_irq_save_calls);

	reset_control_trace();
	require(ihk_smp_os_broadcast_interrupt_body_result(0x11, 0x22, 4,
			3, irq_hw_ids, 0xaa, 0xbb, 7, 0, 1,
			fake_control_set_mode, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_wait, fake_control_x2apic_write,
			fake_control_legacy_ipi) == 0);
	require(control_set_mode_calls == 1);
	require(control_set_mode_os == 0x11);
	require(control_set_mode_priv == 0x22);
	require(control_set_mode_mode == 4);
	require(control_irq_save_calls == 0);
	require(control_irq_restore_calls == 0);
	require(control_x2apic_enabled_calls == 1);
	require(control_x2apic_wait_calls == 0);
	require(control_x2apic_write_calls == 0);
	require(control_legacy_ipi_calls == 3);
	require(control_legacy_hw_id == 303);
	require(control_legacy_vector == 0xbb);
	require(control_legacy_dest == 7);
	mix(&digest, (unsigned long)control_legacy_ipi_calls);

	reset_control_trace();
	control_x2apic_enabled = 1;
	require(ihk_smp_os_broadcast_interrupt_body_result(0x33, 0x44, 5,
			3, irq_hw_ids, 0xcc, 0xdd, 7, 1, 1,
			fake_control_set_mode, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_wait, fake_control_x2apic_write,
			fake_control_legacy_ipi) == 0);
	require(control_set_mode_calls == 1);
	require(control_set_mode_os == 0x33);
	require(control_set_mode_priv == 0x44);
	require(control_set_mode_mode == 5);
	require(control_irq_save_calls == 1);
	require(control_irq_restore_calls == 1);
	require(control_irq_restore_flags == 0x5001UL);
	require(control_x2apic_enabled_calls == 1);
	require(control_x2apic_wait_calls == 3);
	require(control_x2apic_write_calls == 3);
	require(control_x2apic_hw_id == 303);
	require(control_x2apic_vector == 0xcc);
	require(control_legacy_ipi_calls == 0);
	mix(&digest, (unsigned long)control_x2apic_wait_calls);

	reset_control_trace();
	control_set_mode_fail = -5;
	require(ihk_smp_os_broadcast_interrupt_body_result(0x55, 0x66, 6,
			3, irq_hw_ids, 0xee, 0xff, 7, 1, 1,
			fake_control_set_mode, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_wait, fake_control_x2apic_write,
			fake_control_legacy_ipi) == -5);
	require(control_set_mode_calls == 1);
	require(control_irq_save_calls == 0);
	require(control_x2apic_enabled_calls == 0);
	require(control_x2apic_write_calls == 0);
	require(control_legacy_ipi_calls == 0);
	require(ihk_smp_os_broadcast_interrupt_body_result(0x55, 0x66, 6,
			-1, irq_hw_ids, 0xee, 0xff, 7, 1, 1,
			fake_control_set_mode, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_wait, fake_control_x2apic_write,
			fake_control_legacy_ipi) == -EINVAL);
	require(control_set_mode_calls == 1);
	require(ihk_smp_os_broadcast_interrupt_body_result(0x55, 0x66, 6,
			3, NULL, 0xee, 0xff, 7, 1, 1,
			fake_control_set_mode, fake_control_irq_save,
			fake_control_irq_restore, fake_control_x2apic_enabled,
			fake_control_x2apic_wait, fake_control_x2apic_write,
			fake_control_legacy_ipi) == -EINVAL);
	require(control_set_mode_calls == 1);
	mix(&digest, (unsigned long)control_set_mode_calls);

	require(ihk_smp_check_ikc_map_body_result() == 0);
	reset_control_trace();
	memset(fake_cpus, 0x5a, sizeof(fake_cpus));
	init_fake_chunks[0] = 0xdeadbeefUL;
	init_fake_chunks[1] = 0xcafebabeUL;
	smp_init_online_count = 3;
	smp_init_online_cpus[0] = 0;
	smp_init_online_cpus[1] = 3;
	smp_init_online_cpus[2] = 99;
	smp_init_arch_ret = -7;
	require(ihk_smp_init_body_result(
			(unsigned long)&free_mem_list,
			(unsigned long)&os_mem_list,
			offsetof(struct list_head, next), 2, 6,
			(unsigned long)fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status), 88,
			fake_smp_init_zero, fake_smp_init_for_each_online,
			fake_smp_init_arch, (unsigned long)init_fake_chunks,
			sizeof(init_fake_chunks), fake_smp_init_log) == -7);
	require(free_mem_list.next == &free_mem_list);
	require(free_mem_list.prev == &free_mem_list);
	require(os_mem_list.next == &os_mem_list);
	require(os_mem_list.prev == &os_mem_list);
	require(smp_init_zero_calls == 2);
	require(smp_init_zero_ptr[0] == (unsigned long)fake_cpus);
	require(smp_init_zero_size[0] == sizeof(fake_cpus));
	require(smp_init_zero_ptr[1] == (unsigned long)init_fake_chunks);
	require(smp_init_zero_size[1] == sizeof(init_fake_chunks));
	require(smp_init_for_each_calls == 1);
	require(smp_init_arch_calls == 1);
	require(fake_cpus[0].status == 88);
	require(fake_cpus[1].status == 0);
	require(fake_cpus[3].status == 88);
	require(fake_cpus[4].status == 0);
	require(init_fake_chunks[0] == 0);
	require(init_fake_chunks[1] == 0);
	mix(&digest, (unsigned long)fake_cpus[3].status);
	reset_control_trace();
	free_mem_list.next = NULL;
	free_mem_list.prev = NULL;
	os_mem_list.next = NULL;
	os_mem_list.prev = NULL;
	require(ihk_smp_init_body_result(
			(unsigned long)&free_mem_list,
			(unsigned long)&os_mem_list,
			offsetof(struct list_head, next), 6, 4,
			(unsigned long)fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status), 88,
			fake_smp_init_zero, fake_smp_init_for_each_online,
			fake_smp_init_arch, 0, 0, fake_smp_init_log) ==
		EINVAL);
	require(free_mem_list.next == &free_mem_list);
	require(os_mem_list.next == &os_mem_list);
	require(smp_init_log_present == 4);
	require(smp_init_zero_calls == 0);
	require(smp_init_arch_calls == 0);
	mix(&digest, (unsigned long)smp_init_log_present);

	reset_control_trace();
	memset(fake_cpus, 0, sizeof(fake_cpus));
	init_list_head(&free_mem_list);
	fake_cpus[0].id = 10;
	fake_cpus[0].hw_id = 100;
	fake_cpus[0].status = IHK_SMP_CPU_ONLINE;
	fake_cpus[1].id = 11;
	fake_cpus[1].hw_id = 101;
	fake_cpus[1].status = IHK_SMP_CPU_TO_OFFLINE;
	fake_cpus[2].id = 12;
	fake_cpus[2].hw_id = 102;
	fake_cpus[2].status = IHK_SMP_CPU_NONE;
	fake_cpus[3].id = 13;
	fake_cpus[3].hw_id = 103;
	fake_cpus[3].status = IHK_SMP_CPU_OFFLINED;
	smp_exit_reset_ret[0] = -5;
	smp_exit_reset_ret[1] = 7;
	smp_exit_online_ret[0] = 0;
	smp_exit_online_ret[1] = 1;
	require(ihk_smp_exit_body_result((unsigned long)fake_cpus, 5,
			sizeof(fake_cpus[0]), offsetof(struct fake_smp_cpu, id),
			offsetof(struct fake_smp_cpu, hw_id),
			offsetof(struct fake_smp_cpu, status),
			(unsigned long)&free_mem_list, fake_smp_exit_arch,
			fake_smp_exit_reset_cpu, fake_smp_exit_online_cpu,
			fake_smp_exit_free_list, fake_smp_exit_free_info,
			fake_smp_exit_log) == 7);
	require(smp_exit_arch_calls == 1);
	require(smp_exit_reset_calls == 2);
	require(smp_exit_reset_hw_id[0] == 101);
	require(smp_exit_reset_hw_id[1] == 103);
	require(smp_exit_online_calls == 2);
	require(smp_exit_online_cpu[0] == 1);
	require(smp_exit_online_cpu[1] == 3);
	require(smp_exit_log_calls == 1);
	require(smp_exit_log_cpu_id[0] == 11);
	require(smp_exit_log_hw_id[0] == 101);
	require(smp_exit_free_list_calls == 1);
	require(smp_exit_free_list_arg == (unsigned long)&free_mem_list);
	require(smp_exit_free_info_calls == 1);
	mix(&digest, (unsigned long)smp_exit_reset_hw_id[1]);
	mix(&digest, (unsigned long)smp_exit_log_hw_id[0]);
	reset_control_trace();
	require(ihk_smp_exit_body_result(0, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, id),
			offsetof(struct fake_smp_cpu, hw_id),
			offsetof(struct fake_smp_cpu, status),
			(unsigned long)&free_mem_list, fake_smp_exit_arch,
			fake_smp_exit_reset_cpu, fake_smp_exit_online_cpu,
			fake_smp_exit_free_list, fake_smp_exit_free_info,
			fake_smp_exit_log) == -EINVAL);
	require(smp_exit_arch_calls == 0);

	reset_control_trace();
	memset(&fake_builtin, 0, sizeof(fake_builtin));
	smp_module_register_ret = 0x987654321UL;
	require(ihk_smp_module_init_body_result((unsigned long)&fake_builtin,
			offsetof(struct fake_builtin_device_data, ihk_dev),
			offsetof(struct fake_builtin_device_data, lock),
			(unsigned long)&fake_register_data,
			fake_smp_module_symbols_init,
			fake_smp_module_arch_symbols_init,
			fake_smp_module_spin_lock_init,
			fake_smp_module_register_device,
			fake_smp_module_log) == 0);
	require(smp_module_log_count == 1);
	require(smp_module_log_event[0] == 0);
	require(smp_module_symbols_calls == 1);
	require(smp_module_arch_symbols_calls == 1);
	require(smp_module_lock_init_calls == 1);
	require(smp_module_lock_arg ==
		(unsigned long)&fake_builtin +
		offsetof(struct fake_builtin_device_data, lock));
	require(smp_module_register_calls == 1);
	require(smp_module_register_arg == (unsigned long)&fake_register_data);
	require(fake_builtin.ihk_dev == 0x987654321UL);
	mix(&digest, fake_builtin.ihk_dev);
	reset_control_trace();
	smp_module_symbols_ret = -11;
	require(ihk_smp_module_init_body_result((unsigned long)&fake_builtin,
			offsetof(struct fake_builtin_device_data, ihk_dev),
			offsetof(struct fake_builtin_device_data, lock),
			(unsigned long)&fake_register_data,
			fake_smp_module_symbols_init,
			fake_smp_module_arch_symbols_init,
			fake_smp_module_spin_lock_init,
			fake_smp_module_register_device,
			fake_smp_module_log) == -11);
	require(smp_module_symbols_calls == 1);
	require(smp_module_arch_symbols_calls == 0);
	require(smp_module_register_calls == 0);
	reset_control_trace();
	smp_module_register_ret = 0;
	require(ihk_smp_module_init_body_result((unsigned long)&fake_builtin,
			offsetof(struct fake_builtin_device_data, ihk_dev),
			offsetof(struct fake_builtin_device_data, lock),
			(unsigned long)&fake_register_data,
			fake_smp_module_symbols_init,
			fake_smp_module_arch_symbols_init,
			fake_smp_module_spin_lock_init,
			fake_smp_module_register_device,
			fake_smp_module_log) == -ENOMEM);
	require(smp_module_register_calls == 1);
	require(smp_module_log_count == 2);
	require(smp_module_log_event[0] == 0);
	require(smp_module_log_event[1] == 1);
	mix(&digest, (unsigned long)smp_module_log_event[1]);
	reset_control_trace();
	fake_builtin.ihk_dev = 0x22223333UL;
	require(ihk_smp_module_exit_body_result((unsigned long)&fake_builtin,
			offsetof(struct fake_builtin_device_data, ihk_dev),
			fake_smp_module_unregister_device,
			fake_smp_module_log) == 0);
	require(smp_module_log_count == 1);
	require(smp_module_log_event[0] == 2);
	require(smp_module_unregister_calls == 1);
	require(smp_module_unregister_arg == 0x22223333UL);
	require(ihk_smp_module_exit_body_result(0,
			offsetof(struct fake_builtin_device_data, ihk_dev),
			fake_smp_module_unregister_device,
			fake_smp_module_log) == -EINVAL);
	mix(&digest, smp_module_unregister_arg);

	reset_control_trace();
	control_irq_work_ret = 7;
	require(ihk_smp_ikc_irq_work_body_result(
			fake_control_irq_work_handler) == 7);
	require(control_irq_work_calls == 1);
	require(control_irq_work_irq == 0);
	require(control_irq_work_data == NULL);
	require(ihk_smp_ikc_irq_work_body_result(NULL) == -EINVAL);
	require(control_irq_work_calls == 1);
	mix(&digest, (unsigned long)control_irq_work_calls);

	init_list_head(&irq_head);
	memset(irq_handlers, 0, sizeof(irq_handlers));
	irq_handlers[0].func = fake_irq_handler_func;
	irq_handlers[0].priv = (void *)0x30UL;
	irq_handlers[1].func = fake_irq_handler_func;
	irq_handlers[1].priv = (void *)0x60UL;
	require(ihk_smp_os_register_handler_body_result(
			0x10UL, 0x20UL, (unsigned long)&irq_handlers[0],
			(unsigned long)&irq_head, &irq_handler_offsets) == 0);
	require(ihk_smp_os_register_handler_body_result(
			0x40UL, 0x50UL, (unsigned long)&irq_handlers[1],
			(unsigned long)&irq_head, &irq_handler_offsets) == 0);
	require(irq_handlers[0].os == 0x10UL);
	require(irq_handlers[0].os_priv == (void *)0x20UL);
	require(irq_handlers[1].os == 0x40UL);
	require(irq_handlers[1].os_priv == (void *)0x50UL);
	reset_irq_handler_trace();
	require(ihk_smp_irq_call_handlers_body_result((unsigned long)&irq_head,
			&irq_handler_offsets, 1, fake_irq_no_handler_log) == 1);
	require(irq_handler_calls == 2);
	require(irq_handler_priv[0] == 0x30UL);
	require(irq_handler_priv[1] == 0x60UL);
	require(ihk_smp_os_unregister_handler_body_result(
			(unsigned long)&irq_handlers[0], &irq_handler_offsets,
			SMP_IRQ_LIST_POISON1, SMP_IRQ_LIST_POISON2) == 0);
	require(irq_handlers[0].list.next ==
			(struct list_head *)SMP_IRQ_LIST_POISON1);
	require(irq_handlers[0].list.prev ==
			(struct list_head *)SMP_IRQ_LIST_POISON2);
	reset_irq_handler_trace();
	require(ihk_smp_irq_call_handlers_body_result((unsigned long)&irq_head,
			&irq_handler_offsets, 1, fake_irq_no_handler_log) == 1);
	require(irq_handler_calls == 1);
	require(irq_handler_priv[0] == 0x60UL);
	require(ihk_smp_os_register_handler_body_result(
			0, 0, 0, (unsigned long)&irq_head,
			&irq_handler_offsets) == -EINVAL);
	require(ihk_smp_os_unregister_handler_body_result(
			0, &irq_handler_offsets, SMP_IRQ_LIST_POISON1,
			SMP_IRQ_LIST_POISON2) == -EINVAL);
	mix(&digest, irq_handler_priv[0]);

	init_list_head(&irq_head);
	memset(irq_handlers, 0, sizeof(irq_handlers));
	irq_handlers[0].func = fake_irq_handler_func;
	irq_handlers[0].os = 0x10UL;
	irq_handlers[0].os_priv = (void *)0x20UL;
	irq_handlers[0].priv = (void *)0x30UL;
	irq_handlers[1].os = 0x40UL;
	irq_handlers[1].os_priv = (void *)0x50UL;
	irq_handlers[1].priv = (void *)0x60UL;
	irq_handlers[2].func = fake_irq_handler_func;
	irq_handlers[2].os = 0x100UL;
	irq_handlers[2].os_priv = (void *)0x200UL;
	irq_handlers[2].priv = (void *)0x300UL;
	fake_topo_list_add(&irq_handlers[2].list, &irq_head);
	fake_topo_list_add(&irq_handlers[1].list, &irq_head);
	fake_topo_list_add(&irq_handlers[0].list, &irq_head);
	reset_irq_handler_trace();
	require(ihk_smp_irq_call_handlers_body_result((unsigned long)&irq_head,
			&irq_handler_offsets, 1, fake_irq_no_handler_log) == 1);
	require(irq_handler_calls == 2);
	require(irq_handler_os[0] == 0x10UL);
	require(irq_handler_os_priv[0] == 0x20UL);
	require(irq_handler_priv[0] == 0x30UL);
	require(irq_handler_os[1] == 0x100UL);
	require(irq_handler_os_priv[1] == 0x200UL);
	require(irq_handler_priv[1] == 0x300UL);
	require(irq_no_handler_log_calls == 0);
	mix(&digest, irq_handler_priv[1]);
	init_list_head(&irq_head);
	reset_irq_handler_trace();
	require(ihk_smp_irq_call_handlers_body_result((unsigned long)&irq_head,
			&irq_handler_offsets, 9, fake_irq_no_handler_log) == 9);
	require(irq_handler_calls == 0);
	require(irq_no_handler_log_calls == 1);
	require(ihk_smp_irq_call_handlers_body_result(0, &irq_handler_offsets,
			1, fake_irq_no_handler_log) == -EINVAL);
	require(ihk_smp_irq_call_handlers_body_result((unsigned long)&irq_head,
			NULL, 1, fake_irq_no_handler_log) == -EINVAL);
	mix(&digest, (unsigned long)irq_handler_calls);
	mix(&digest, (unsigned long)irq_no_handler_log_calls);

	memset(&perf_param, 0, sizeof(perf_param));
	memset(perf_extra_regs, 0, sizeof(perf_extra_regs));
	perf_extra_regs[0].event = 0x1001U;
	perf_extra_regs[0].msr = 0x2001U;
	perf_extra_regs[0].valid_mask = 0x30010001UL;
	perf_extra_regs[0].idx = 3;
	perf_extra_regs[1].event = 0x1002U;
	perf_extra_regs[1].msr = 0x2002U;
	perf_extra_regs[1].valid_mask = 0x30020002UL;
	perf_extra_regs[1].idx = 4;
	reset_control_trace();
	require(ihk_smp_arch_get_perf_event_map_body_result(
			(unsigned long)&perf_param,
			(unsigned long)perf_extra_regs,
			(unsigned long)perf_hw_event_map,
			(unsigned long)perf_cache_ids,
			(unsigned long)perf_cache_extra, &perf_offsets, 4,
			sizeof(perf_param.hw_event_map),
			sizeof(perf_param.hw_cache_event_ids),
			sizeof(perf_param.hw_cache_extra_regs),
			fake_control_perf_log) == 0);
	require(perf_param.nr_extra_regs == 2);
	require(perf_param.ereg_event[0] == 0x1001U);
	require(perf_param.ereg_msr[1] == 0x2002U);
	require(perf_param.ereg_valid_mask[1] == 0x30020002UL);
	require(perf_param.ereg_idx[1] == 4);
	require(!memcmp(perf_param.hw_event_map, perf_hw_event_map,
			sizeof(perf_hw_event_map)));
	require(!memcmp(perf_param.hw_cache_event_ids, perf_cache_ids,
			sizeof(perf_cache_ids)));
	require(!memcmp(perf_param.hw_cache_extra_regs, perf_cache_extra,
			sizeof(perf_cache_extra)));
	require(control_perf_log_calls == 0);
	mix(&digest, perf_param.hw_event_map[2]);
	mix(&digest, perf_param.hw_cache_event_ids[1][1][1]);

	memset(&perf_param, 0, sizeof(perf_param));
	require(ihk_smp_arch_get_perf_event_map_body_result(
			(unsigned long)&perf_param, 0, 0,
			(unsigned long)perf_cache_ids,
			(unsigned long)perf_cache_extra, &perf_offsets, 4,
			sizeof(perf_param.hw_event_map),
			sizeof(perf_param.hw_cache_event_ids),
			sizeof(perf_param.hw_cache_extra_regs),
			fake_control_perf_log) == -EINVAL);
	memset(&perf_param, 0, sizeof(perf_param));
	memset(perf_extra_regs, 0, sizeof(perf_extra_regs));
	perf_extra_regs[0].msr = 0x1U;
	perf_extra_regs[1].msr = 0x2U;
	perf_extra_regs[2].msr = 0x3U;
	reset_control_trace();
	require(ihk_smp_arch_get_perf_event_map_body_result(
			(unsigned long)&perf_param,
			(unsigned long)perf_extra_regs,
			(unsigned long)perf_hw_event_map,
			(unsigned long)perf_cache_ids,
			(unsigned long)perf_cache_extra, &perf_offsets, 2,
			sizeof(perf_param.hw_event_map),
			sizeof(perf_param.hw_cache_event_ids),
			sizeof(perf_param.hw_cache_extra_regs),
			fake_control_perf_log) == -EINVAL);
	require(control_perf_log_calls == 1);
	require(control_perf_log_event == 1);
	require(control_perf_log_value == 3);
	mix(&digest, (unsigned long)control_perf_log_value);

	memset(buildid_dst, 0, sizeof(buildid_dst));
	reset_control_trace();
	require(ihk_smp_get_buildid_body_result((unsigned long)buildid_dst,
			"build-123", sizeof("build-123"),
			fake_smp_copy_to_user) == 0);
	require(!strcmp(buildid_dst, "build-123"));
	require(smp_copy_to_calls == 1);
	smp_copy_to_fail = 1;
	require(ihk_smp_get_buildid_body_result((unsigned long)buildid_dst,
			"build-123", sizeof("build-123"),
			fake_smp_copy_to_user) == -EFAULT);
	require(smp_copy_to_calls == 2);
	mix(&digest, (unsigned long)smp_copy_to_calls);

	fake_cpus[0].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[1].status = 0;
	fake_cpus[2].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[3].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[4].status = 3;
	require(ihk_smp_device_get_num_cpus_body_result(fake_cpus, 5,
			sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			IHK_SMP_CPU_AVAILABLE) == 3);
	mix(&digest, (unsigned long)fake_cpus[2].status);

	memset(query_out, 0, sizeof(query_out));
	user_req.cpus = query_out;
	user_req.num_cpus = 3;
	reset_control_trace();
	require(ihk_smp_device_query_cpu_body_result(
			(unsigned long)&user_req, (unsigned long)&req_scratch,
			sizeof(req_scratch), &cpu_req_offsets, fake_cpus, 5,
			sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			IHK_SMP_CPU_AVAILABLE, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(query_out[0] == 0);
	require(query_out[1] == 2);
	require(query_out[2] == 3);
	require(user_req.num_cpus == 3);
	require(smp_copy_from_calls == 1);
	require(smp_copy_to_calls == 2);
	require(smp_alloc_calls == 1);
	require(smp_free_calls == 1);
	mix(&digest, (unsigned long)query_out[1]);
	mix(&digest, (unsigned long)smp_copy_to_calls);

	user_req.num_cpus = 2;
	reset_control_trace();
	require(ihk_smp_device_query_cpu_body_result(
			(unsigned long)&user_req, (unsigned long)&req_scratch,
			sizeof(req_scratch), &cpu_req_offsets, fake_cpus, 5,
			sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			IHK_SMP_CPU_AVAILABLE, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EINVAL);
	require(smp_query_log_event == 3);
	require(smp_query_log_requested == 2);
	require(smp_query_log_actual == 3);
	mix(&digest, (unsigned long)smp_query_log_actual);

	user_req.num_cpus = 3;
	reset_control_trace();
	smp_copy_to_fail = 1;
	require(ihk_smp_device_query_cpu_body_result(
			(unsigned long)&user_req, (unsigned long)&req_scratch,
			sizeof(req_scratch), &cpu_req_offsets, fake_cpus, 5,
			sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			IHK_SMP_CPU_AVAILABLE, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EFAULT);
	require(smp_free_calls == 1);
	require(smp_query_log_event == 6);
	mix(&digest, (unsigned long)smp_query_log_event);

	memset(query_out, 0, sizeof(query_out));
	control_os.nr_cpus = 3;
	control_os.cpu_mapping[0] = 7;
	control_os.cpu_mapping[1] = 5;
	control_os.cpu_mapping[2] = 8;
	user_req.cpus = query_out;
	user_req.num_cpus = 3;
	reset_control_trace();
	require(ihk_smp_os_query_cpu_body_result((unsigned long)&control_os,
			(unsigned long)&user_req, (unsigned long)&req_scratch,
			sizeof(req_scratch), &cpu_req_offsets,
			&control_offsets, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(query_out[0] == 7);
	require(query_out[1] == 5);
	require(query_out[2] == 8);
	require(smp_alloc_calls == 1);
	require(smp_free_calls == 1);
	mix(&digest, (unsigned long)query_out[0]);
	mix(&digest, (unsigned long)query_out[2]);

	user_req.num_cpus = 4;
	reset_control_trace();
	require(ihk_smp_os_query_cpu_body_result((unsigned long)&control_os,
			(unsigned long)&user_req, (unsigned long)&req_scratch,
			sizeof(req_scratch), &cpu_req_offsets,
			&control_offsets, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EINVAL);
	require(smp_query_log_event == 3);
	require(smp_query_log_requested == 4);
	require(smp_query_log_actual == 3);
	mix(&digest, (unsigned long)smp_query_log_requested);

	memset(fake_cpus, 0, sizeof(fake_cpus));
	fake_cpus[0].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[0].os = 0xabcUL;
	fake_cpus[0].ikc_map_cpu = 10;
	fake_cpus[1].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[1].os = 0xabcUL;
	fake_cpus[1].ikc_map_cpu = 11;
	fake_cpus[2].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[2].os = 0xdefUL;
	fake_cpus[2].ikc_map_cpu = 12;
	fake_cpus[3].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[3].os = 0xabcUL;
	fake_cpus[3].ikc_map_cpu = 13;
	fake_cpus[4].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[4].os = 0xabcUL;
	fake_cpus[4].ikc_map_cpu = 14;
	memset(ikc_src_out, 0, sizeof(ikc_src_out));
	memset(ikc_dst_out, 0, sizeof(ikc_dst_out));
	ikc_user_req.src_cpus = ikc_src_out;
	ikc_user_req.dst_cpus = ikc_dst_out;
	ikc_user_req.num_cpus = 3;
	reset_control_trace();
	require(ihk_smp_os_get_ikc_map_body_result(
			0xabcUL, (unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), &ikc_req_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			offsetof(struct fake_smp_cpu, os),
			offsetof(struct fake_smp_cpu, ikc_map_cpu),
			IHK_SMP_CPU_ASSIGNED, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(ikc_src_out[0] == 0);
	require(ikc_dst_out[0] == 10);
	require(ikc_src_out[1] == 3);
	require(ikc_dst_out[1] == 13);
	require(ikc_src_out[2] == 4);
	require(ikc_dst_out[2] == 14);
	require(ikc_user_req.num_cpus == 3);
	require(smp_copy_from_calls == 3);
	require(smp_copy_to_calls == 3);
	require(smp_alloc_calls == 2);
	require(smp_free_calls == 2);
	mix(&digest, (unsigned long)ikc_dst_out[1]);
	mix(&digest, (unsigned long)smp_copy_from_calls);

	ikc_user_req.num_cpus = 2;
	reset_control_trace();
	require(ihk_smp_os_get_ikc_map_body_result(
			0xabcUL, (unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), &ikc_req_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			offsetof(struct fake_smp_cpu, os),
			offsetof(struct fake_smp_cpu, ikc_map_cpu),
			IHK_SMP_CPU_ASSIGNED, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EINVAL);
	require(smp_query_log_event == 7);
	require(smp_query_log_requested == 2);
	require(smp_query_log_actual == 3);
	require(smp_free_calls == 2);
	mix(&digest, (unsigned long)smp_query_log_actual);

	ikc_user_req.num_cpus = 3;
	reset_control_trace();
	smp_copy_to_fail = 1;
	require(ihk_smp_os_get_ikc_map_body_result(
			0xabcUL, (unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), &ikc_req_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			offsetof(struct fake_smp_cpu, os),
			offsetof(struct fake_smp_cpu, ikc_map_cpu),
			IHK_SMP_CPU_ASSIGNED, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EFAULT);
	require(smp_query_log_event == 8);
	require(smp_free_calls == 2);
	mix(&digest, (unsigned long)smp_query_log_event);

	ikc_user_req.src_cpus = NULL;
	ikc_user_req.dst_cpus = NULL;
	ikc_user_req.num_cpus = 0;
	reset_control_trace();
	require(ihk_smp_os_get_ikc_map_body_result(
			0x999UL, (unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), &ikc_req_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			offsetof(struct fake_smp_cpu, status),
			offsetof(struct fake_smp_cpu, os),
			offsetof(struct fake_smp_cpu, ikc_map_cpu),
			IHK_SMP_CPU_ASSIGNED, sizeof(int), 8,
			fake_smp_copy_from_user, fake_smp_copy_to_user,
			fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(ikc_user_req.num_cpus == 0);
	require(smp_copy_from_calls == 1);
	require(smp_copy_to_calls == 1);
	require(smp_alloc_calls == 0);
	require(smp_free_calls == 0);
	mix(&digest, (unsigned long)smp_copy_to_calls);

	memset(fake_cpus, 0, sizeof(fake_cpus));
	fake_cpus[0].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[0].os = 0xabcUL;
	fake_cpus[1].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[2].status = IHK_SMP_CPU_AVAILABLE;
	fake_cpus[3].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[3].os = 0xabcUL;
	fake_cpus[4].status = IHK_SMP_CPU_ASSIGNED;
	fake_cpus[4].os = 0xabcUL;
	ikc_src_out[0] = 0;
	ikc_src_out[1] = 3;
	ikc_dst_out[0] = 1;
	ikc_dst_out[1] = 2;
	ikc_user_req.src_cpus = ikc_src_out;
	ikc_user_req.dst_cpus = ikc_dst_out;
	ikc_user_req.num_cpus = 2;
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	for (fill_i = 0; fill_i < 5; fill_i++) {
		smp_cpu_present_mask[fill_i] = 1;
		smp_cpu_online_mask[fill_i] = 1;
	}
	smp_check_ikc_result = 0;
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == 0);
	require(fake_cpus[0].ikc_map_cpu == 1);
	require(fake_cpus[3].ikc_map_cpu == 2);
	require(fake_cpus[4].ikc_map_cpu == 0);
	require(control_os.cpu_ikc_mapped == 1);
	require(smp_copy_from_calls == 3);
	require(smp_alloc_calls == 2);
	require(smp_free_calls == 2);
	require(control_lock_calls == 1);
	require(control_unlock_calls == 1);
	require(smp_check_ikc_calls == 1);
	require(smp_set_ikc_route_count == 3);
	require(smp_set_ikc_route_cpu[0] == 0);
	require(smp_set_ikc_route_dst[0] == 1);
	require(smp_set_ikc_route_cpu[1] == 3);
	require(smp_set_ikc_route_dst[1] == 2);
	mix(&digest, (unsigned long)smp_set_ikc_route_count);
	mix(&digest, (unsigned long)fake_cpus[3].ikc_map_cpu);

	fake_cpus[0].ikc_map_cpu = 1;
	fake_cpus[3].ikc_map_cpu = 2;
	control_os.status = BUILTIN_OS_STATUS_HUNGUP;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == -EBUSY);
	require(control_lock_calls == 1);
	require(control_unlock_calls == 1);
	require(fake_cpus[0].ikc_map_cpu == 0);
	require(fake_cpus[3].ikc_map_cpu == 0);
	require(smp_alloc_calls == 0);
	mix(&digest, (unsigned long)control_unlock_calls);

	ikc_user_req.dst_cpus = NULL;
	ikc_user_req.num_cpus = 1;
	fake_cpus[0].ikc_map_cpu = 9;
	control_os.status = BUILTIN_OS_STATUS_INITIAL;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == -EINVAL);
	require(smp_set_ikc_log_event == 2);
	require(smp_set_ikc_log_value0 == 2);
	require(fake_cpus[0].ikc_map_cpu == 0);
	require(smp_alloc_calls == 0);
	mix(&digest, (unsigned long)smp_set_ikc_log_value0);

	ikc_user_req.dst_cpus = ikc_dst_out;
	ikc_user_req.num_cpus = 1;
	ikc_src_out[0] = 1;
	ikc_dst_out[0] = 2;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	for (fill_i = 0; fill_i < 5; fill_i++) {
		smp_cpu_present_mask[fill_i] = 1;
		smp_cpu_online_mask[fill_i] = 1;
	}
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == -EINVAL);
	require(smp_set_ikc_log_event == 10);
	require(smp_set_ikc_log_value0 == 1);
	require(smp_free_calls == 2);
	mix(&digest, (unsigned long)smp_set_ikc_log_event);

	ikc_src_out[0] = 0;
	ikc_dst_out[0] = 3;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	for (fill_i = 0; fill_i < 5; fill_i++) {
		smp_cpu_present_mask[fill_i] = 1;
		smp_cpu_online_mask[fill_i] = 1;
	}
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == -EINVAL);
	require(smp_set_ikc_log_event == 11);
	require(smp_set_ikc_log_value0 == 3);
	require(fake_cpus[0].ikc_map_cpu == 0);
	mix(&digest, (unsigned long)smp_set_ikc_log_value0);

	ikc_dst_out[0] = 2;
	control_os.cpu_ikc_mapped = 0;
	reset_control_trace();
	for (fill_i = 0; fill_i < 5; fill_i++) {
		smp_cpu_present_mask[fill_i] = 1;
		smp_cpu_online_mask[fill_i] = 1;
	}
	smp_cpu_present_mask[2] = 0;
	require(ihk_smp_os_set_ikc_map_body_result(
			0xabcUL, (unsigned long)&control_os,
			(unsigned long)&ikc_user_req,
			(unsigned long)&ikc_req_scratch,
			sizeof(ikc_req_scratch), ikc_req_string,
			sizeof(ikc_req_string), &set_ikc_offsets,
			fake_cpus, 5, sizeof(fake_cpus[0]),
			IHK_SMP_CPU_ASSIGNED, BUILTIN_OS_STATUS_INITIAL,
			sizeof(int), 5, fake_smp_copy_from_user,
			fake_smp_alloc, fake_smp_free, fake_control_lock,
			fake_control_unlock, fake_smp_cpu_present,
			fake_smp_cpu_online, fake_smp_check_ikc_map,
			fake_smp_set_ikc_log) == -EINVAL);
	require(smp_set_ikc_log_event == 12);
	require(smp_set_ikc_log_value0 == 2);
	mix(&digest, (unsigned long)smp_set_ikc_log_value0);

	init_list_head(&free_mem_list);
	memset(free_chunks, 0, sizeof(free_chunks));
	free_chunks[0].size = 0x1000;
	free_chunks[0].numa_id = 1;
	free_chunks[1].size = 0x3000;
	free_chunks[1].numa_id = 2;
	fake_topo_list_add(&free_chunks[0].chain, &free_mem_list);
	fake_topo_list_add(&free_chunks[1].chain, &free_mem_list);
	memset(fake_chunks, 0, sizeof(fake_chunks));
	fake_chunks[2] = 0x5000;
	memset(&mem_user_req, 0, sizeof(mem_user_req));
	memset(&mem_req_scratch, 0, sizeof(mem_req_scratch));
	mem_user_req.num_chunks = 0;
	reset_control_trace();
	require(ihk_smp_query_mem_body_result((unsigned long)&free_mem_list,
			0, 0, 0, fake_chunks, 3,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &free_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(mem_user_req.num_chunks == 3);
	require(smp_copy_from_calls == 1);
	require(smp_copy_to_calls == 1);
	require(smp_alloc_calls == 0);
	mix(&digest, (unsigned long)mem_user_req.num_chunks);

	memset(mem_sizes_out, 0, sizeof(mem_sizes_out));
	memset(mem_numa_out, 0, sizeof(mem_numa_out));
	mem_user_req.sizes = mem_sizes_out;
	mem_user_req.numa_ids = mem_numa_out;
	mem_user_req.num_chunks = 1;
	reset_control_trace();
	require(ihk_smp_query_mem_body_result((unsigned long)&free_mem_list,
			0, 0, 0, fake_chunks, 3,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &free_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(mem_user_req.num_chunks == 3);
	require(mem_sizes_out[0] == 0x3000);
	require(mem_numa_out[0] == 2);
	require(mem_sizes_out[1] == 0x1000);
	require(mem_numa_out[1] == 1);
	require(mem_sizes_out[2] == 0x5000);
	require(mem_numa_out[2] == 2);
	require(smp_alloc_calls == 2);
	require(smp_free_calls == 2);
	mix(&digest, mem_sizes_out[0]);
	mix(&digest, (unsigned long)mem_numa_out[2]);

	reset_control_trace();
	smp_copy_to_fail = 1;
	require(ihk_smp_query_mem_body_result((unsigned long)&free_mem_list,
			0, 0, 0, fake_chunks, 3,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &free_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EFAULT);
	require(smp_free_calls == 2);
	require(smp_query_log_event == 6);
	mix(&digest, (unsigned long)smp_query_log_event);

	init_list_head(&os_mem_list);
	memset(os_chunks, 0, sizeof(os_chunks));
	os_chunks[0].size = 0x7000;
	os_chunks[0].numa_id = 4;
	os_chunks[0].os = &control_os;
	os_chunks[1].size = 0x9000;
	os_chunks[1].numa_id = 5;
	os_chunks[1].os = (void *)0x4444UL;
	os_chunks[2].size = 0xb000;
	os_chunks[2].numa_id = 6;
	os_chunks[2].os = &control_os;
	fake_topo_list_add(&os_chunks[0].list, &os_mem_list);
	fake_topo_list_add(&os_chunks[1].list, &os_mem_list);
	fake_topo_list_add(&os_chunks[2].list, &os_mem_list);
	memset(mem_sizes_out, 0, sizeof(mem_sizes_out));
	memset(mem_numa_out, 0, sizeof(mem_numa_out));
	mem_user_req.sizes = mem_sizes_out;
	mem_user_req.numa_ids = mem_numa_out;
	mem_user_req.num_chunks = 2;
	reset_control_trace();
	require(ihk_smp_query_mem_body_result((unsigned long)&os_mem_list,
			(unsigned long)&control_os, 1, 1, NULL, 0,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &os_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == 0);
	require(mem_user_req.num_chunks == 2);
	require(mem_sizes_out[0] == 0xb000);
	require(mem_numa_out[0] == 6);
	require(mem_sizes_out[1] == 0x7000);
	require(mem_numa_out[1] == 4);
	require(smp_alloc_calls == 2);
	require(smp_free_calls == 2);
	mix(&digest, mem_sizes_out[0]);
	mix(&digest, (unsigned long)mem_numa_out[1]);

	mem_user_req.num_chunks = 3;
	reset_control_trace();
	require(ihk_smp_query_mem_body_result((unsigned long)&os_mem_list,
			(unsigned long)&control_os, 1, 1, NULL, 0,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &os_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EINVAL);
	require(smp_query_log_event == 3);
	require(smp_query_log_requested == 3);
	require(smp_query_log_actual == 2);
	mix(&digest, (unsigned long)smp_query_log_actual);

	reset_control_trace();
	smp_alloc_fail = 1;
	require(ihk_smp_query_mem_body_result((unsigned long)&os_mem_list,
			(unsigned long)&control_os, 1, 1, NULL, 0,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &os_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -EINVAL);
	require(smp_alloc_calls == 0);
	mix(&digest, (unsigned long)smp_alloc_calls);

	mem_user_req.num_chunks = 2;
	reset_control_trace();
	smp_alloc_fail = 1;
	require(ihk_smp_query_mem_body_result((unsigned long)&os_mem_list,
			(unsigned long)&control_os, 1, 1, NULL, 0,
			(unsigned long)&mem_user_req,
			(unsigned long)&mem_req_scratch, sizeof(mem_req_scratch),
			&mem_req_offsets, &os_mem_query_offsets, sizeof(size_t),
			sizeof(int), fake_smp_copy_from_user,
			fake_smp_copy_to_user, fake_smp_alloc, fake_smp_free,
			fake_smp_query_log) == -ENOMEM);
	require(smp_alloc_calls == 1);
	require(smp_query_log_event == 4);
	mix(&digest, (unsigned long)smp_query_log_event);

	memset(lookup_cpus, 0, sizeof(lookup_cpus));
	memset(lookup_nodes, 0, sizeof(lookup_nodes));
	init_list_head(&lookup_cpu_list);
	init_list_head(&lookup_node_list);
	lookup_cpus[0].cpu_number = 7;
	lookup_cpus[0].hw_id = 70;
	lookup_cpus[1].cpu_number = 9;
	lookup_cpus[1].hw_id = 90;
	fake_topo_list_add(&lookup_cpus[0].chain, &lookup_cpu_list);
	fake_topo_list_add(&lookup_cpus[1].chain, &lookup_cpu_list);
	lookup_nodes[0].node_number = 3;
	lookup_nodes[1].node_number = 5;
	fake_topo_list_add(&lookup_nodes[0].chain, &lookup_node_list);
	fake_topo_list_add(&lookup_nodes[1].chain, &lookup_node_list);
	require(ihk_smp_get_cpu_topology_body_result(
			(unsigned long)&lookup_cpu_list, 70,
			&topo_lookup_offsets) ==
		(unsigned long)&lookup_cpus[0]);
	require(ihk_smp_get_cpu_topology_body_result(
			(unsigned long)&lookup_cpu_list, 1234,
			&topo_lookup_offsets) == 0);
	require(ihk_smp_get_node_topology_body_result(
			(unsigned long)&lookup_node_list, 5, 8,
			(unsigned long)-EINVAL, &topo_lookup_offsets) ==
		(unsigned long)&lookup_nodes[1]);
	require(ihk_smp_get_node_topology_body_result(
			(unsigned long)&lookup_node_list, 9, 8,
			(unsigned long)-EINVAL, &topo_lookup_offsets) ==
		(unsigned long)-EINVAL);
	require(ihk_smp_linux_cpu_to_hw_id_body_result(
			(unsigned long)&lookup_cpu_list, 9,
			&topo_lookup_offsets) == 90);
	require(ihk_smp_linux_cpu_to_hw_id_body_result(
			(unsigned long)&lookup_cpu_list, 99,
			&topo_lookup_offsets) == -1);
	mix(&digest, (unsigned long)lookup_cpus[1].hw_id);
	mix(&digest, (unsigned long)lookup_nodes[1].node_number);

	reset_arch_symbol_trace(NULL);
	require(ihk_smp_arch_symbols_init_body_result(&symbol_slots,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) == 0);
	require(sym_real == 0x1000UL);
	require(sym_vector == 0x2000UL);
	require(sym_lapic == 0x3000UL);
	require(sym_irq_desc == 0x4000UL);
	require(sym_uv == 0x5000UL);
	require(sym_deassert == 0x6000UL);
	require(sym_alloc == 0x7000UL);
	require(sym_default_ipi == 0x8000UL);
	require(sym_init_pgt == 0x9000UL);
	require(sym_vectors == 0xa000UL);
	require(arch_symbol_lookup_calls == 12);
	require(!strcmp(arch_symbol_lookup_names[0], "real_mode_header"));
	require(!strcmp(arch_symbol_lookup_names[8], "init_top_pgt"));
	require(!strcmp(arch_symbol_lookup_names[9], "init_level4_pgt"));
	require(!strcmp(arch_symbol_lookup_names[10], "system_vectors"));
	require(!strcmp(arch_symbol_lookup_names[11], "used_vectors"));
	require(arch_symbol_warn_calls == 10);
	require(arch_symbol_warn_failures == 0);
	mix(&digest, sym_real ^ sym_init_pgt ^ sym_vectors);

	reset_arch_symbol_trace("alloc_desc");
	sym_alloc = 0x7777UL;
	require(ihk_smp_arch_symbols_init_body_result(&symbol_slots,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) ==
			-EFAULT);
	require(sym_alloc == 0);
	require(arch_symbol_warn_calls == 7);
	require(arch_symbol_warn_failures == 1);
	mix(&digest, (unsigned long)arch_symbol_warn_calls);

	require(ihk_smp_arch_symbols_init_body_result(NULL,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) == -22);
	require(ihk_smp_arch_symbols_init_body_result(&symbol_slots,
			NULL, fake_arch_symbol_warn) == -22);

	reset_arch_symbol_trace(NULL);
	sym_ioremap = sym_vmap_lock = sym_vmap_root = sym_insert_vmap = 0;
	sym_free_vmap_old = sym_alloc_vmap = sym_free_vmap_new = 0;
	sym_unmap_noflush = sym_raised_list = sym_hstates = 0;
	sym_default_hstate = 0;
	require(ihk_smp_symbols_init_body_result(&smp_symbol_slots, 1, 0,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) == 0);
	require(sym_ioremap == 0xb100UL);
	require(sym_vmap_lock == 0xb200UL);
	require(sym_vmap_root == 0xb300UL);
	require(sym_insert_vmap == 0xb400UL);
	require(sym_free_vmap_old == 0xb500UL);
	require(sym_alloc_vmap == 0);
	require(sym_unmap_noflush == 0xb800UL);
	require(sym_hstates == 0xba00UL);
	require(sym_default_hstate == 0xbb00UL);
	require(arch_symbol_lookup_calls == 8);
	require(!strcmp(arch_symbol_lookup_names[0],
			"ioremap_page_range"));
	require(!strcmp(arch_symbol_lookup_names[4],
			"__free_vmap_area"));
	require(!strcmp(arch_symbol_lookup_names[7],
			"default_hstate_idx"));
	require(arch_symbol_warn_calls == 8);
	require(arch_symbol_warn_failures == 0);
	mix(&digest, sym_ioremap ^ sym_free_vmap_old ^ sym_default_hstate);

	reset_arch_symbol_trace("free_vmap_area");
	sym_alloc_vmap = sym_free_vmap_new = sym_unmap_noflush = 0;
	sym_raised_list = sym_hstates = sym_default_hstate = 0;
	require(ihk_smp_symbols_init_body_result(&smp_symbol_slots, 0, 1,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) == 0);
	require(sym_alloc_vmap == 0xb600UL);
	require(sym_free_vmap_new == 0xb701UL);
	require(sym_unmap_noflush == 0xb800UL);
	require(sym_raised_list == 0xb900UL);
	require(sym_hstates == 0xba00UL);
	require(sym_default_hstate == 0xbb00UL);
	require(arch_symbol_lookup_calls == 8);
	require(!strcmp(arch_symbol_lookup_names[1], "alloc_vmap_area"));
	require(!strcmp(arch_symbol_lookup_names[2], "free_vmap_area"));
	require(!strcmp(arch_symbol_lookup_names[3],
			"free_vmap_area_noflush"));
	require(!strcmp(arch_symbol_lookup_names[5], "raised_list"));
	require(arch_symbol_warn_calls == 7);
	require(arch_symbol_warn_failures == 0);
	mix(&digest, sym_free_vmap_new ^ sym_raised_list);

	reset_arch_symbol_trace("hstates");
	sym_hstates = 0x7777UL;
	require(ihk_smp_symbols_init_body_result(&smp_symbol_slots, 0, 0,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) ==
			-EFAULT);
	require(sym_hstates == 0);
	require(arch_symbol_warn_calls == 5);
	require(arch_symbol_warn_failures == 1);
	mix(&digest, (unsigned long)arch_symbol_warn_calls);

	require(ihk_smp_symbols_init_body_result(NULL, 0, 0,
			fake_arch_symbol_lookup, fake_arch_symbol_warn) == -EINVAL);
	require(ihk_smp_symbols_init_body_result(&smp_symbol_slots, 0, 0,
			NULL, fake_arch_symbol_warn) == -EINVAL);

	reset_topo_trace(&cpu_topo);
	require(run_collect_cache_topology(&cpu_topo, 4) == 0);
	cache_topo = first_fake_cache(&cpu_topo);
	require(cache_topo != NULL);
	require(cache_topo->index == 4);
	require(cache_topo->level == 3);
	require(cache_topo->size == 48 * 1024);
	require(cache_topo->coherency_line_size == 64);
	require(cache_topo->number_of_sets == 1024);
	require(cache_topo->physical_line_partition == 1);
	require(cache_topo->ways_of_associativity == 12);
	require(cache_topo->shared_cpu_map[0] == 0x5);
	require(cache_topo->shared_cpu_map[1] == 0x10);
	require(!strcmp(cache_topo->type, "Unified"));
	require(!strcmp(cache_topo->size_str, "48K"));
	mix(&digest, (unsigned long)cache_topo->size);
	mix(&digest, cache_topo->shared_cpu_map[0]);
	mix(&digest, (unsigned long)topo_free_calls);

	reset_topo_trace(&cpu_topo);
	topo_file_readable = 0;
	require(run_collect_cache_topology(&cpu_topo, 0) == 0);
	require(first_fake_cache(&cpu_topo) == NULL);
	require(topo_alloc_calls == 1);
	require(topo_free_calls == 1);
	mix(&digest, (unsigned long)topo_free_calls);

	reset_topo_trace(&cpu_topo);
	topo_fail_leaf = "ways_of_associativity";
	topo_fail_error = -19;
	require(run_collect_cache_topology(&cpu_topo, 1) == -19);
	require(first_fake_cache(&cpu_topo) == NULL);
	require(topo_log_event == 11);
	require(topo_log_error == -19);
	require(topo_free_calls == 4);
	mix(&digest, (unsigned long)(unsigned int)topo_log_error);
	mix(&digest, (unsigned long)topo_free_calls);

	reset_topo_trace(&cpu_topo);
	topo_alloc_fail_after = 0;
	require(run_collect_cache_topology(&cpu_topo, 1) == -ENOMEM);
	require(first_fake_cache(&cpu_topo) == NULL);
	require(topo_log_event == 1);
	require(topo_log_error == -ENOMEM);
	require(topo_free_calls == 0);
	mix(&digest, (unsigned long)(unsigned int)topo_log_error);

	reset_topo_trace(&cpu_topo);
	init_list_head(&cpu_list);
	require(run_collect_cpu_topology(7, &cpu_list) == 0);
	cpu_added = first_fake_cpu(&cpu_list);
	require(cpu_added != NULL);
	require(cpu_added->cpu_number == 7);
	require(cpu_added->hw_id == 1007);
	require(cpu_added->core_id == 8);
	require(cpu_added->physical_package_id == 2);
	require(cpu_added->core_siblings[0] == 0xaa);
	require(cpu_added->core_siblings[1] == 0x40);
	require(cpu_added->thread_siblings[0] == 0x55);
	require(cpu_added->thread_siblings[1] == 0x20);
	require(list_empty(&cpu_added->cache_topology_list));
	require(topo_collect_cache_calls == 10);
	require(topo_collect_cache_last_index == 9);
	require(topo_free_calls == 1);
	mix(&digest, (unsigned long)cpu_added->hw_id);
	mix(&digest, cpu_added->core_siblings[0]);
	mix(&digest, (unsigned long)topo_collect_cache_calls);

	reset_topo_trace(&cpu_topo);
	init_list_head(&cpu_list);
	topo_fail_leaf = "topology/thread_siblings";
	topo_fail_error = -19;
	require(run_collect_cpu_topology(7, &cpu_list) == -19);
	require(first_fake_cpu(&cpu_list) == NULL);
	require(topo_log_event == 19);
	require(topo_log_error == -19);
	require(topo_free_calls == 2);
	mix(&digest, (unsigned long)(unsigned int)topo_log_error);
	mix(&digest, (unsigned long)topo_free_calls);

	reset_topo_trace(&cpu_topo);
	init_list_head(&cpu_list);
	topo_collect_cache_fail_index = 3;
	topo_fail_error = -24;
	require(run_collect_cpu_topology(4, &cpu_list) == 0);
	cpu_added = first_fake_cpu(&cpu_list);
	require(cpu_added != NULL);
	require(cpu_added->cpu_number == 4);
	require(topo_collect_cache_calls == 4);
	require(topo_collect_cache_last_index == 3);
	require(topo_log_event == 20);
	require(topo_log_error == -24);
	mix(&digest, (unsigned long)topo_collect_cache_calls);
	mix(&digest, (unsigned long)(unsigned int)topo_log_error);

	reset_topo_trace(&cpu_topo);
	init_list_head(&node_list);
	require(run_collect_node_topology(5, &node_list) == 0);
	node_added = first_fake_node(&node_list);
	require(node_added != NULL);
	require(node_added->node_number == 5);
	require(node_added->cpumap[0] == 0x105);
	require(node_added->cpumap[1] == 0x205);
	require(topo_free_calls == 0);
	mix(&digest, node_added->cpumap[0]);
	mix(&digest, node_added->cpumap[1]);

	reset_topo_trace(&cpu_topo);
	init_list_head(&node_list);
	topo_node_fail_error = -17;
	require(run_collect_node_topology(2, &node_list) == -17);
	require(first_fake_node(&node_list) == NULL);
	require(topo_log_event == 22);
	require(topo_log_error == -17);
	require(topo_free_calls == 1);
	mix(&digest, (unsigned long)(unsigned int)topo_log_error);
	mix(&digest, (unsigned long)topo_free_calls);

	reset_topo_trace(&cpu_topo);
	topo_online_cpus[0] = 1;
	topo_online_cpus[1] = 3;
	topo_online_cpu_count = 2;
	topo_online_nodes[0] = 0;
	topo_online_nodes[1] = 2;
	topo_online_node_count = 2;
	require(run_collect_topology() == 0);
	require(topo_next_cpu_calls == 3);
	require(topo_next_node_calls == 3);
	require(topo_collect_cpu_calls == 2);
	require(topo_collected_cpus[0] == 1);
	require(topo_collected_cpus[1] == 3);
	require(topo_collect_node_calls == 2);
	require(topo_collected_nodes[0] == 0);
	require(topo_collected_nodes[1] == 2);
	require(topo_log_count == 2);
	require(topo_log_events[0] == 23);
	require(topo_log_events[1] == 26);
	require(topo_log_errors[1] == 0);
	mix(&digest, (unsigned long)topo_collect_cpu_calls);
	mix(&digest, (unsigned long)topo_collect_node_calls);

	reset_topo_trace(&cpu_topo);
	topo_online_cpus[0] = 2;
	topo_online_cpus[1] = 5;
	topo_online_cpu_count = 2;
	topo_online_nodes[0] = 1;
	topo_online_node_count = 1;
	topo_collect_cpu_fail_at = 5;
	topo_fail_error = -31;
	require(run_collect_topology() == -31);
	require(topo_collect_cpu_calls == 2);
	require(topo_collected_cpus[1] == 5);
	require(topo_collect_node_calls == 0);
	require(topo_log_count == 3);
	require(topo_log_events[0] == 23);
	require(topo_log_events[1] == 24);
	require(topo_log_events[2] == 26);
	require(topo_log_errors[1] == -31);
	require(topo_log_errors[2] == -31);
	mix(&digest, (unsigned long)(unsigned int)topo_log_errors[2]);

	reset_topo_trace(&cpu_topo);
	topo_online_cpus[0] = 4;
	topo_online_cpu_count = 1;
	topo_online_nodes[0] = 0;
	topo_online_nodes[1] = 3;
	topo_online_node_count = 2;
	topo_collect_node_fail_at = 3;
	topo_fail_error = -32;
	require(run_collect_topology() == -32);
	require(topo_collect_cpu_calls == 1);
	require(topo_collect_node_calls == 2);
	require(topo_collected_nodes[1] == 3);
	require(topo_log_count == 3);
	require(topo_log_events[1] == 25);
	require(topo_log_events[2] == 26);
	require(topo_log_errors[1] == -32);
	require(topo_log_errors[2] == -32);
	mix(&digest, (unsigned long)(unsigned int)topo_log_errors[2]);

	require(ihk_smp_collect_topology_body_result(
			NULL, fake_topo_collect_cpu_index, fake_topo_next_node,
			fake_topo_collect_node_index, fake_topo_log) == -EINVAL);
	require(ihk_smp_collect_topology_body_result(
			fake_topo_next_cpu, NULL, fake_topo_next_node,
			fake_topo_collect_node_index, fake_topo_log) == -EINVAL);

	reset_topo_trace(&cpu_topo);
	init_list_head(&cpu_list);
	init_list_head(&node_list);
	cpu_added = alloc_free_info_cpu(11, &cpu_list);
	alloc_free_info_cache(cpu_added, "Data", "32K");
	alloc_free_info_cache(cpu_added, "Unified", "48K");
	cpu_added = alloc_free_info_cpu(12, &cpu_list);
	alloc_free_info_cache(cpu_added, "Instruction", "64K");
	node_added = alloc_free_info_node(2, &node_list);
	require(node_added != NULL);
	node_added = alloc_free_info_node(3, &node_list);
	require(node_added != NULL);
	require(ihk_smp_free_info_body_result(
			(unsigned long)&cpu_list, (unsigned long)&node_list,
			&free_info_offsets, fake_free_info_list_del,
			(void (*)(unsigned long))fake_topo_free,
			fake_free_info_log) == 0);
	require(list_empty(&cpu_list));
	require(list_empty(&node_list));
	require(free_info_list_del_calls == 7);
	require(topo_free_calls == 13);
	require(free_info_log_calls == 2);
	require(free_info_log_events[0] == 0);
	require(free_info_log_events[1] == 1);
	mix(&digest, (unsigned long)free_info_list_del_calls);
	mix(&digest, (unsigned long)topo_free_calls);

	require(ihk_smp_free_info_body_result(0, (unsigned long)&node_list,
			&free_info_offsets, fake_free_info_list_del,
			(void (*)(unsigned long))fake_topo_free,
			fake_free_info_log) == -EINVAL);
	require(ihk_smp_free_info_body_result((unsigned long)&cpu_list,
			(unsigned long)&node_list, &free_info_offsets, NULL,
			(void (*)(unsigned long))fake_topo_free,
			fake_free_info_log) == -EINVAL);

	reset_topo_trace(&cpu_topo);
	require(ihk_smp_file_readable_body_result(
			(char *)"node%u", 0x333UL,
			sizeof(file_readable_filename),
			fake_file_readable_alloc,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 1);
	require(file_readable_alloc_calls == 1);
	require(file_readable_alloc_size == sizeof(file_readable_filename));
	require(file_readable_vsnprintf_calls == 1);
	require(!strcmp(file_readable_vsnprintf_fmt, "node%u"));
	require(file_readable_vsnprintf_size == sizeof(file_readable_filename));
	require(file_readable_vsnprintf_va == 0x333UL);
	require(file_readable_open_calls == 1);
	require(file_readable_open_filename == file_readable_filename);
	require(file_readable_close_calls == 1);
	require(file_readable_close_file == 0x515100UL);
	require(file_readable_free_calls == 1);
	require(file_readable_free_addr == (unsigned long)file_readable_filename);
	require(file_readable_log_calls == 0);
	mix(&digest, file_readable_close_file);
	mix(&digest, file_readable_alloc_size);

	reset_topo_trace(&cpu_topo);
	file_readable_alloc_fail = 1;
	require(ihk_smp_file_readable_body_result(
			(char *)"node%u", 0x333UL,
			sizeof(file_readable_filename),
			fake_file_readable_alloc,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 0);
	require(file_readable_vsnprintf_calls == 0);
	require(file_readable_open_calls == 0);
	require(file_readable_close_calls == 0);
	require(file_readable_free_calls == 1);
	require(file_readable_free_addr == 0);
	require(file_readable_log_calls == 1);
	require(file_readable_log_event[0] == 1);
	require(file_readable_log_error[0] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)file_readable_log_error[0]);

	reset_topo_trace(&cpu_topo);
	file_readable_vsnprintf_result = sizeof(file_readable_filename);
	require(ihk_smp_file_readable_body_result(
			(char *)"node%u", 0x333UL,
			sizeof(file_readable_filename),
			fake_file_readable_alloc,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 0);
	require(file_readable_open_calls == 0);
	require(file_readable_close_calls == 0);
	require(file_readable_free_calls == 1);
	require(file_readable_log_calls == 1);
	require(file_readable_log_event[0] == 2);
	require(file_readable_log_error[0] == -ENAMETOOLONG);
	mix(&digest, (unsigned long)(unsigned int)file_readable_log_error[0]);

	reset_topo_trace(&cpu_topo);
	file_readable_open_fail = 1;
	require(ihk_smp_file_readable_body_result(
			(char *)"node%u", 0x333UL,
			sizeof(file_readable_filename),
			fake_file_readable_alloc,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 0);
	require(file_readable_open_calls == 1);
	require(file_readable_close_calls == 0);
	require(file_readable_free_calls == 1);
	require(file_readable_log_calls == 0);
	mix(&digest, (unsigned long)file_readable_open_calls);

	require(ihk_smp_file_readable_body_result(
			NULL, 0x333UL, sizeof(file_readable_filename),
			fake_file_readable_alloc,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 0);
	require(ihk_smp_file_readable_body_result(
			(char *)"node%u", 0x333UL,
			sizeof(file_readable_filename), NULL,
			fake_file_readable_vsnprintf,
			fake_file_readable_open,
			fake_file_readable_close,
			fake_file_readable_free,
			fake_file_readable_log) == 0);

	reset_topo_trace(&cpu_topo);
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == 0);
	require(!strcmp(read_file_buf, "abcde"));
	require(read_file_alloc_calls == 1);
	require(read_file_alloc_size == sizeof(read_file_filename));
	require(read_file_vsnprintf_calls == 1);
	require(!strcmp(read_file_vsnprintf_fmt, "node%u"));
	require(read_file_vsnprintf_size == sizeof(read_file_filename));
	require(read_file_vsnprintf_va == 0x444UL);
	require(read_file_open_calls == 1);
	require(read_file_open_filename == read_file_filename);
	require(read_file_open_errorp != 0);
	require(read_file_kernel_read_calls == 1);
	require(read_file_kernel_file == 0x525200UL);
	require(read_file_kernel_buf == (unsigned long)read_file_buf);
	require(read_file_kernel_size == sizeof(read_file_buf));
	require(read_file_close_calls == 1);
	require(read_file_close_file == 0x525200UL);
	require(read_file_free_calls == 1);
	require(read_file_free_addr == (unsigned long)read_file_filename);
	require(read_file_log_calls == 2);
	require(read_file_log_event[0] == 0);
	require(read_file_log_event[1] == 7);
	require(read_file_log_error[1] == 0);
	mix(&digest, (unsigned long)strlen(read_file_buf));
	mix(&digest, read_file_kernel_file);

	reset_topo_trace(&cpu_topo);
	read_file_alloc_fail = 1;
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == -ENOMEM);
	require(read_file_vsnprintf_calls == 0);
	require(read_file_open_calls == 0);
	require(read_file_kernel_read_calls == 0);
	require(read_file_close_calls == 0);
	require(read_file_free_calls == 1);
	require(read_file_free_addr == 0);
	require(read_file_log_event[1] == 1);
	require(read_file_log_error[1] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_file_vsnprintf_result = sizeof(read_file_filename);
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == -ENAMETOOLONG);
	require(read_file_open_calls == 0);
	require(read_file_kernel_read_calls == 0);
	require(read_file_close_calls == 0);
	require(read_file_free_calls == 1);
	require(read_file_log_event[1] == 2);
	require(read_file_log_error[1] == -ENAMETOOLONG);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_file_open_fail = 1;
	read_file_open_error = -EACCES;
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == -EACCES);
	require(read_file_open_calls == 1);
	require(read_file_kernel_read_calls == 0);
	require(read_file_close_calls == 0);
	require(read_file_free_calls == 1);
	require(read_file_log_event[1] == 3);
	require(read_file_log_error[1] == -EACCES);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_file_kernel_read_result = -EFAULT;
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == -EFAULT);
	require(read_file_kernel_read_calls == 1);
	require(read_file_close_calls == 1);
	require(read_file_free_calls == 1);
	require(read_file_log_event[1] == 4);
	require(read_file_log_error[1] == -EFAULT);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_file_kernel_read_result = sizeof(read_file_buf);
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == -ENOSPC);
	require(read_file_kernel_read_calls == 1);
	require(read_file_close_calls == 1);
	require(read_file_free_calls == 1);
	require(read_file_log_event[1] == 5);
	require(read_file_log_error[1] == -ENOSPC);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_file_close_result = -EIO;
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			fake_read_file_alloc, fake_read_file_vsnprintf,
			fake_read_file_open, fake_read_file_kernel_read,
			fake_read_file_close, fake_read_file_free,
			fake_read_file_log) == 0);
	require(read_file_close_calls == 1);
	require(read_file_log_calls == 3);
	require(read_file_log_event[1] == 6);
	require(read_file_log_error[1] == -EIO);
	require(read_file_log_event[2] == 7);
	require(read_file_log_error[2] == 0);
	mix(&digest, (unsigned long)(unsigned int)read_file_log_error[1]);

	require(ihk_smp_read_file_body_result(
			0, sizeof(read_file_buf), (char *)"node%u", 0x444UL,
			sizeof(read_file_filename), fake_read_file_alloc,
			fake_read_file_vsnprintf, fake_read_file_open,
			fake_read_file_kernel_read, fake_read_file_close,
			fake_read_file_free, fake_read_file_log) == -EINVAL);
	require(ihk_smp_read_file_body_result(
			(unsigned long)read_file_buf, sizeof(read_file_buf),
			(char *)"node%u", 0x444UL, sizeof(read_file_filename),
			NULL, fake_read_file_vsnprintf, fake_read_file_open,
			fake_read_file_kernel_read, fake_read_file_close,
			fake_read_file_free, fake_read_file_log) == -EINVAL);

	{
		char path[128];

		reset_topo_trace(&cpu_topo);
		memset(path, 0, sizeof(path));
		require(ihk_smp_write_cpu_sys_file_body_result(
				7, "0", path, sizeof(path),
				fake_write_cpu_open, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == 0);
		require(!strcmp(path,
				"/sys/devices/system/cpu/cpu7/online"));
		require(write_cpu_open_calls == 1);
		require(write_cpu_open_path == path);
		require(write_cpu_open_errorp != 0);
		require(write_cpu_write_calls == 1);
		require(write_cpu_write_file == 0x616100UL);
		require(write_cpu_write_buf[0] == '0');
		require(write_cpu_write_size == 1);
		require(write_cpu_close_calls == 1);
		require(write_cpu_close_file == 0x616100UL);
		require(write_cpu_log_calls == 0);
		mix(&digest, write_cpu_write_file);
		mix(&digest, (unsigned long)strlen(path));

		reset_topo_trace(&cpu_topo);
		memset(path, 0, sizeof(path));
		require(ihk_smp_write_cpu_sys_file_body_result(
				12345, "1", path, 16, fake_write_cpu_open,
				fake_write_cpu_write, fake_write_cpu_close,
				fake_write_cpu_log) == -1);
		require(write_cpu_open_calls == 0);
		require(write_cpu_write_calls == 0);
		require(write_cpu_close_calls == 0);
		require(write_cpu_log_calls == 1);
		require(write_cpu_log_event[0] == 1);
		mix(&digest, (unsigned long)write_cpu_log_error[0]);

		reset_topo_trace(&cpu_topo);
		memset(path, 0, sizeof(path));
		write_cpu_open_fail = 1;
		write_cpu_open_error = -EACCES;
		require(ihk_smp_write_cpu_sys_file_body_result(
				8, "0", path, sizeof(path),
				fake_write_cpu_open, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == -1);
		require(write_cpu_open_calls == 1);
		require(write_cpu_write_calls == 0);
		require(write_cpu_close_calls == 0);
		require(write_cpu_log_calls == 1);
		require(write_cpu_log_event[0] == 2);
		require(write_cpu_log_error[0] == -EACCES);
		require(write_cpu_log_path[0] == path);
		mix(&digest, (unsigned long)(unsigned int)write_cpu_log_error[0]);

		reset_topo_trace(&cpu_topo);
		memset(path, 0, sizeof(path));
		write_cpu_write_result = -EIO;
		require(ihk_smp_write_cpu_sys_file_body_result(
				9, "1", path, sizeof(path),
				fake_write_cpu_open, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == -1);
		require(write_cpu_open_calls == 1);
		require(write_cpu_write_calls == 1);
		require(write_cpu_close_calls == 1);
		require(write_cpu_log_calls == 1);
		require(write_cpu_log_event[0] == 3);
		require(write_cpu_log_error[0] == -EIO);
		mix(&digest, (unsigned long)(unsigned int)write_cpu_log_error[0]);

		require(ihk_smp_write_cpu_sys_file_body_result(
				1, NULL, path, sizeof(path),
				fake_write_cpu_open, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == -EINVAL);
		require(ihk_smp_write_cpu_sys_file_body_result(
				1, "0", NULL, sizeof(path),
				fake_write_cpu_open, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == -EINVAL);
		require(ihk_smp_write_cpu_sys_file_body_result(
				1, "0", path, sizeof(path),
				NULL, fake_write_cpu_write,
				fake_write_cpu_close, fake_write_cpu_log) == -EINVAL);
	}

	reset_topo_trace(&cpu_topo);
	read_long_value = 0;
	require(ihk_smp_read_long_body_result(
			(unsigned long)&read_long_value, (char *)"node%u",
			0xfeedUL, sizeof(read_long_page),
			fake_read_long_alloc_page, fake_read_long_read_file,
			fake_read_long_parse, fake_read_long_free_pages,
			fake_read_long_log) == 0);
	require(read_long_value == 12345);
	require(read_long_alloc_calls == 1);
	require(read_long_read_calls == 1);
	require(read_long_read_buf == (unsigned long)read_long_page);
	require(read_long_read_size == sizeof(read_long_page));
	require(!strcmp(read_long_read_fmt, "node%u"));
	require(read_long_read_va == 0xfeedUL);
	require(read_long_parse_calls == 1);
	require(read_long_free_calls == 1);
	require(read_long_free_addr == (unsigned long)read_long_page);
	require(read_long_log_calls == 2);
	require(read_long_log_event[0] == 0);
	require(read_long_log_event[1] == 4);
	require(read_long_log_error[1] == 0);
	mix(&digest, (unsigned long)read_long_value);
	mix(&digest, (unsigned long)read_long_read_size);

	reset_topo_trace(&cpu_topo);
	read_long_alloc_fail = 1;
	require(ihk_smp_read_long_body_result(
			(unsigned long)&read_long_value, (char *)"node%u",
			0xfeedUL, sizeof(read_long_page),
			fake_read_long_alloc_page, fake_read_long_read_file,
			fake_read_long_parse, fake_read_long_free_pages,
			fake_read_long_log) == -ENOMEM);
	require(read_long_read_calls == 0);
	require(read_long_parse_calls == 0);
	require(read_long_free_calls == 1);
	require(read_long_free_addr == 0);
	require(read_long_log_calls == 3);
	require(read_long_log_event[1] == 1);
	require(read_long_log_error[1] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)read_long_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_long_read_result = -EFAULT;
	require(ihk_smp_read_long_body_result(
			(unsigned long)&read_long_value, (char *)"node%u",
			0xfeedUL, sizeof(read_long_page),
			fake_read_long_alloc_page, fake_read_long_read_file,
			fake_read_long_parse, fake_read_long_free_pages,
			fake_read_long_log) == -EFAULT);
	require(read_long_read_calls == 1);
	require(read_long_parse_calls == 0);
	require(read_long_free_calls == 1);
	require(read_long_log_event[1] == 2);
	require(read_long_log_error[1] == -EFAULT);
	mix(&digest, (unsigned long)(unsigned int)read_long_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_long_parse_result = 0;
	require(ihk_smp_read_long_body_result(
			(unsigned long)&read_long_value, (char *)"node%u",
			0xfeedUL, sizeof(read_long_page),
			fake_read_long_alloc_page, fake_read_long_read_file,
			fake_read_long_parse, fake_read_long_free_pages,
			fake_read_long_log) == -EIO);
	require(read_long_read_calls == 1);
	require(read_long_parse_calls == 1);
	require(read_long_free_calls == 1);
	require(read_long_log_event[1] == 3);
	require(read_long_log_error[1] == -EIO);
	mix(&digest, (unsigned long)(unsigned int)read_long_log_error[1]);

	require(ihk_smp_read_long_body_result(
			0, (char *)"node%u", 0xfeedUL,
			sizeof(read_long_page), fake_read_long_alloc_page,
			fake_read_long_read_file, fake_read_long_parse,
			fake_read_long_free_pages, fake_read_long_log) ==
		-EINVAL);
	require(ihk_smp_read_long_body_result(
			(unsigned long)&read_long_value, (char *)"node%u",
			0xfeedUL, sizeof(read_long_page), NULL,
			fake_read_long_read_file, fake_read_long_parse,
			fake_read_long_free_pages, fake_read_long_log) ==
		-EINVAL);

	reset_topo_trace(&cpu_topo);
	require(ihk_smp_read_bitmap_body_result(
			(unsigned long)read_bitmap_map_words, 128,
			(char *)"node%u", 0xbeefUL, sizeof(read_long_page),
			fake_read_bitmap_alloc_page,
			fake_read_bitmap_read_file, fake_read_bitmap_parse,
			fake_read_bitmap_free_pages, fake_read_bitmap_log) == 0);
	require(read_bitmap_map_words[0] == 0x0fUL);
	require(read_bitmap_alloc_calls == 1);
	require(read_bitmap_read_calls == 1);
	require(read_bitmap_read_buf == (unsigned long)read_long_page);
	require(read_bitmap_read_size == sizeof(read_long_page));
	require(!strcmp(read_bitmap_read_fmt, "node%u"));
	require(read_bitmap_read_va == 0xbeefUL);
	require(read_bitmap_parse_calls == 1);
	require(read_bitmap_parse_buf == (unsigned long)read_long_page);
	require(read_bitmap_parse_size == sizeof(read_long_page));
	require(read_bitmap_parse_map == (unsigned long)read_bitmap_map_words);
	require(read_bitmap_parse_nbits == 128);
	require(read_bitmap_free_calls == 1);
	require(read_bitmap_free_addr == (unsigned long)read_long_page);
	require(read_bitmap_log_calls == 2);
	require(read_bitmap_log_event[0] == 0);
	require(read_bitmap_log_event[1] == 4);
	require(read_bitmap_log_error[1] == 0);
	mix(&digest, read_bitmap_map_words[0]);
	mix(&digest, (unsigned long)read_bitmap_parse_nbits);

	reset_topo_trace(&cpu_topo);
	read_bitmap_alloc_fail = 1;
	require(ihk_smp_read_bitmap_body_result(
			(unsigned long)read_bitmap_map_words, 128,
			(char *)"node%u", 0xbeefUL, sizeof(read_long_page),
			fake_read_bitmap_alloc_page,
			fake_read_bitmap_read_file, fake_read_bitmap_parse,
			fake_read_bitmap_free_pages, fake_read_bitmap_log) ==
		-ENOMEM);
	require(read_bitmap_read_calls == 0);
	require(read_bitmap_parse_calls == 0);
	require(read_bitmap_free_calls == 1);
	require(read_bitmap_free_addr == 0);
	require(read_bitmap_log_event[1] == 1);
	require(read_bitmap_log_error[1] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)read_bitmap_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_bitmap_read_result = -EFAULT;
	require(ihk_smp_read_bitmap_body_result(
			(unsigned long)read_bitmap_map_words, 128,
			(char *)"node%u", 0xbeefUL, sizeof(read_long_page),
			fake_read_bitmap_alloc_page,
			fake_read_bitmap_read_file, fake_read_bitmap_parse,
			fake_read_bitmap_free_pages, fake_read_bitmap_log) ==
		-EFAULT);
	require(read_bitmap_read_calls == 1);
	require(read_bitmap_parse_calls == 0);
	require(read_bitmap_free_calls == 1);
	require(read_bitmap_log_event[1] == 2);
	require(read_bitmap_log_error[1] == -EFAULT);
	mix(&digest, (unsigned long)(unsigned int)read_bitmap_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_bitmap_parse_result = -EINVAL;
	require(ihk_smp_read_bitmap_body_result(
			(unsigned long)read_bitmap_map_words, 128,
			(char *)"node%u", 0xbeefUL, sizeof(read_long_page),
			fake_read_bitmap_alloc_page,
			fake_read_bitmap_read_file, fake_read_bitmap_parse,
			fake_read_bitmap_free_pages, fake_read_bitmap_log) ==
		-EINVAL);
	require(read_bitmap_read_calls == 1);
	require(read_bitmap_parse_calls == 1);
	require(read_bitmap_free_calls == 1);
	require(read_bitmap_log_event[1] == 3);
	require(read_bitmap_log_error[1] == -EINVAL);
	mix(&digest, (unsigned long)(unsigned int)read_bitmap_log_error[1]);

	require(ihk_smp_read_bitmap_body_result(
			0, 128, (char *)"node%u", 0xbeefUL,
			sizeof(read_long_page), fake_read_bitmap_alloc_page,
			fake_read_bitmap_read_file, fake_read_bitmap_parse,
			fake_read_bitmap_free_pages, fake_read_bitmap_log) ==
		-EINVAL);
	require(ihk_smp_read_bitmap_body_result(
			(unsigned long)read_bitmap_map_words, 128,
			(char *)"node%u", 0xbeefUL, sizeof(read_long_page),
			NULL, fake_read_bitmap_read_file,
			fake_read_bitmap_parse, fake_read_bitmap_free_pages,
			fake_read_bitmap_log) == -EINVAL);

	reset_topo_trace(&cpu_topo);
	read_string_value = NULL;
	require(ihk_smp_read_string_body_result(
			(unsigned long)&read_string_value, (char *)"node%u",
			0xcafeUL, sizeof(read_long_page),
			fake_read_string_alloc_page,
			fake_read_string_read_file, fake_read_string_dup,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == 0);
	require(read_string_value != NULL);
	require(!strcmp(read_string_value, "Cache line"));
	require(read_string_alloc_calls == 1);
	require(read_string_read_calls == 1);
	require(read_string_read_buf == (unsigned long)read_long_page);
	require(read_string_read_size == sizeof(read_long_page));
	require(!strcmp(read_string_read_fmt, "node%u"));
	require(read_string_read_va == 0xcafeUL);
	require(read_string_dup_calls == 1);
	require(read_string_dup_buf == (unsigned long)read_long_page);
	require(read_string_kfree_calls == 1);
	require(read_string_kfree_addr == 0);
	require(read_string_free_calls == 1);
	require(read_string_free_addr == (unsigned long)read_long_page);
	require(read_string_log_calls == 2);
	require(read_string_log_event[0] == 0);
	require(read_string_log_event[1] == 4);
	require(read_string_log_error[1] == 0);
	mix(&digest, (unsigned long)strlen(read_string_value));
	mix(&digest, (unsigned long)read_string_read_size);

	reset_topo_trace(&cpu_topo);
	read_string_alloc_fail = 1;
	require(ihk_smp_read_string_body_result(
			(unsigned long)&read_string_value, (char *)"node%u",
			0xcafeUL, sizeof(read_long_page),
			fake_read_string_alloc_page,
			fake_read_string_read_file, fake_read_string_dup,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == -ENOMEM);
	require(read_string_read_calls == 0);
	require(read_string_dup_calls == 0);
	require(read_string_kfree_calls == 1);
	require(read_string_kfree_addr == 0);
	require(read_string_free_calls == 1);
	require(read_string_free_addr == 0);
	require(read_string_log_event[1] == 1);
	require(read_string_log_error[1] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)read_string_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_string_read_result = -EFAULT;
	require(ihk_smp_read_string_body_result(
			(unsigned long)&read_string_value, (char *)"node%u",
			0xcafeUL, sizeof(read_long_page),
			fake_read_string_alloc_page,
			fake_read_string_read_file, fake_read_string_dup,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == -EFAULT);
	require(read_string_read_calls == 1);
	require(read_string_dup_calls == 0);
	require(read_string_kfree_calls == 1);
	require(read_string_free_calls == 1);
	require(read_string_log_event[1] == 2);
	require(read_string_log_error[1] == -EFAULT);
	mix(&digest, (unsigned long)(unsigned int)read_string_log_error[1]);

	reset_topo_trace(&cpu_topo);
	read_string_dup_fail = 1;
	require(ihk_smp_read_string_body_result(
			(unsigned long)&read_string_value, (char *)"node%u",
			0xcafeUL, sizeof(read_long_page),
			fake_read_string_alloc_page,
			fake_read_string_read_file, fake_read_string_dup,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == -ENOMEM);
	require(read_string_read_calls == 1);
	require(read_string_dup_calls == 1);
	require(read_string_kfree_calls == 1);
	require(read_string_free_calls == 1);
	require(read_string_log_event[1] == 3);
	require(read_string_log_error[1] == -ENOMEM);
	mix(&digest, (unsigned long)(unsigned int)read_string_log_error[1]);

	require(ihk_smp_read_string_body_result(
			0, (char *)"node%u", 0xcafeUL,
			sizeof(read_long_page), fake_read_string_alloc_page,
			fake_read_string_read_file, fake_read_string_dup,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == -EINVAL);
	require(ihk_smp_read_string_body_result(
			(unsigned long)&read_string_value, (char *)"node%u",
			0xcafeUL, sizeof(read_long_page),
			fake_read_string_alloc_page,
			fake_read_string_read_file, NULL,
			fake_read_string_kfree, fake_read_string_free_pages,
			fake_read_string_log) == -EINVAL);

	require(offsetof(struct chunk, chain) == 0);
	require(offsetof(struct chunk, node) == sizeof(struct list_head));
	require(offsetof(struct chunk, addr) ==
		sizeof(struct list_head) + sizeof(struct rb_node));
	require(smp_max_size_mem_chunk_body(&root) == 0);

	init_chunk(&chunks[0], 100, 20, 0);
	require(insert_chunk(&root, &chunks[0], &digest) == 0);
	{
		const uintptr_t addrs[] = { 100 };
		const size_t sizes[] = { 20 };
		require(expect_tree(&root, addrs, sizes, 1, 20, &digest) == 0);
	}

	init_chunk(&chunks[1], 50, 10, 0);
	require(insert_chunk(&root, &chunks[1], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 100 };
		const size_t sizes[] = { 10, 20 };
		require(expect_tree(&root, addrs, sizes, 2, 20, &digest) == 0);
	}

	init_chunk(&chunks[2], 200, 20, 0);
	require(insert_chunk(&root, &chunks[2], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 100, 200 };
		const size_t sizes[] = { 10, 20, 20 };
		require(expect_tree(&root, addrs, sizes, 3, 20, &digest) == 0);
	}

	init_chunk(&chunks[3], 60, 40, 0);
	require(insert_chunk(&root, &chunks[3], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 200 };
		const size_t sizes[] = { 70, 20 };
		require(expect_tree(&root, addrs, sizes, 2, 70, &digest) == 0);
	}

	init_chunk(&chunks[4], 120, 80, 0);
	require(insert_chunk(&root, &chunks[4], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50 };
		const size_t sizes[] = { 170 };
		require(expect_tree(&root, addrs, sizes, 1, 170, &digest) == 0);
	}

	init_chunk(&chunks[5], 300, 10, 0);
	require(insert_chunk(&root, &chunks[5], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 300 };
		const size_t sizes[] = { 170, 10 };
		require(expect_tree(&root, addrs, sizes, 2, 170, &digest) == 0);
	}

	init_chunk(&chunks[6], 280, 20, 0);
	require(insert_chunk(&root, &chunks[6], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 280 };
		const size_t sizes[] = { 170, 30 };
		require(expect_tree(&root, addrs, sizes, 2, 170, &digest) == 0);
	}

	init_chunk(&chunks[7], 270, 10, 0);
	require(insert_chunk(&root, &chunks[7], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50, 270 };
		const size_t sizes[] = { 170, 40 };
		require(expect_tree(&root, addrs, sizes, 2, 170, &digest) == 0);
	}

	init_chunk(&chunks[8], 220, 50, 0);
	require(insert_chunk(&root, &chunks[8], &digest) == 0);
	{
		const uintptr_t addrs[] = { 50 };
		const size_t sizes[] = { 260 };
		require(expect_tree(&root, addrs, sizes, 1, 260, &digest) == 0);
	}

	printf("smp_chunk_helpers ok digest=%016lx\n", digest);
	return 0;
}
