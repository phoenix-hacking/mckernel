extern int printf(const char *, ...);
extern void exit(int);
extern void abort(void);

#ifndef PAGE_ALLOC_USE_C
extern void *memset(void *, int, unsigned long);
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

#define ARENA_BASE 0x1000000UL
#define ARENA_SIZE (128UL * 4096UL)
#define LOCAL_PAGE_SIZE 4096UL

#define rb_entry(ptr, type, member) \
	((type *)((char *)(ptr) - __builtin_offsetof(type, member)))

#ifndef PAGE_ALLOC_USE_C
struct rb_node {
	unsigned long __rb_parent_color;
	struct rb_node *rb_right;
	struct rb_node *rb_left;
} __attribute__((aligned(sizeof(long))));

struct rb_root {
	struct rb_node *rb_node;
};

struct llist_node {
	struct llist_node *next;
};

struct free_chunk {
	unsigned long addr, size;
	struct rb_node node;
	struct llist_node list;
};

extern struct rb_node *rb_first(const struct rb_root *);
extern struct rb_node *rb_next(const struct rb_node *);
#endif

static unsigned char arena[ARENA_SIZE];

#ifndef PAGE_ALLOC_USE_C
extern unsigned long linux_page_offset_base;
#endif

void *phys_to_virt(unsigned long p)
{
	if (p < ARENA_BASE || p >= ARENA_BASE + ARENA_SIZE)
		exit(80);
	return arena + (p - ARENA_BASE);
}

unsigned long virt_to_phys(void *v)
{
	return ARENA_BASE + (unsigned long)((unsigned char *)v - arena);
}

int ihk_mc_chk_page_address(unsigned long mem_addr)
{
	(void)mem_addr;
	return 0;
}

__attribute__((weak)) int kprintf(const char *format, ...)
{
	(void)format;
	return 0;
}

__attribute__((weak)) void panic(const char *message)
{
	(void)message;
	abort();
}

struct ihk_mc_numa_node;

int ihk_mc_get_nr_numa_nodes(void)
{
	return 0;
}

struct ihk_mc_numa_node *ihk_mc_get_numa_node_by_distance(int i)
{
	(void)i;
	return NULL;
}

#ifdef PAGE_ALLOC_USE_C
#include "lib/page_alloc.c"
#else
__attribute__((weak)) int zero_at_free = 1;

extern int __page_alloc_rbtree_free_range(struct rb_root *root,
					  unsigned long addr,
					  unsigned long size);
extern unsigned long __page_alloc_rbtree_alloc_pages(struct rb_root *root,
						     int npages,
						     int p2align);
extern unsigned long __page_alloc_rbtree_reserve_pages(struct rb_root *root,
						       unsigned long aligned_addr,
						       int npages);
extern struct free_chunk *__page_alloc_rbtree_get_root_chunk(struct rb_root *root);
extern int __ihk_numa_cpu_cache_try_result(int);
extern int __ihk_numa_cpu_cache_alloc_hit_result(unsigned long);
extern int __ihk_numa_cpu_cache_free_success_result(int);
	extern unsigned long __ihk_numa_cpu_cache_alloc_nolock(struct rb_root *,
							       int, int);
	extern int __ihk_numa_cpu_cache_free_nolock(struct rb_root *, unsigned long,
						    int);
	extern unsigned long __ihk_numa_cpu_cache_alloc_try_result(int,
								   struct rb_root *,
								   int, int,
								   unsigned long (*)(void),
								   void (*)(unsigned long));
	extern int __ihk_numa_cpu_cache_free_try_result(int, struct rb_root *,
							unsigned long, int,
								   unsigned long (*)(void),
								   void (*)(unsigned long));
	extern int __ihk_numa_linux_zero_request_action(int, int, int, int, int);
	extern int ihk_numa_free_pages_finish_result(int, int, int,
		unsigned long, unsigned long, int, int, unsigned long,
		int (*)(unsigned long),
		void (*)(int, unsigned long, unsigned long, int, int, int));
	#endif

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static unsigned long digest_tree(struct rb_root *root)
{
	struct rb_node *node;
	unsigned long digest = 0xcbf29ce484222325UL;
	unsigned long last_end = 0;
	int count = 0;

	for (node = rb_first(root); node; node = rb_next(node)) {
		struct free_chunk *chunk = rb_entry(node, struct free_chunk, node);

		if ((void *)chunk != phys_to_virt(chunk->addr))
			exit(81);
		if (count && chunk->addr <= last_end)
			exit(82);

		mix(&digest, chunk->addr);
		mix(&digest, chunk->size);
		last_end = chunk->addr + chunk->size;
		count++;
	}

	mix(&digest, (unsigned long)count);
	return digest;
}

	static void require(int condition)
	{
		if (!condition)
			exit(83);
	}

	static unsigned long irq_cookie = 0x123456789abcdef0UL;
	static int irq_save_calls;
	static int irq_restore_calls;
	static unsigned long restored_irq_cookie;

	static unsigned long fake_irq_save(void)
	{
		irq_save_calls++;
		return irq_cookie;
	}

	static void fake_irq_restore(unsigned long irqstate)
	{
		irq_restore_calls++;
		restored_irq_cookie = irqstate;
	}

	static void reset_irq_trace(void)
	{
		irq_save_calls = 0;
		irq_restore_calls = 0;
		restored_irq_cookie = 0;
	}

	static int finish_send_count;
	static int finish_send_rc;
	static unsigned long finish_send_packet;
	static int finish_log_count;
	static unsigned long finish_log_digest;

	static int fake_finish_send(unsigned long packet_addr)
	{
		finish_send_count++;
		finish_send_packet = packet_addr;
		return finish_send_rc;
	}

	static void fake_finish_log(int event, unsigned long node_addr,
			unsigned long addr, int npages, int zero_at_free_value,
			int detail)
	{
		finish_log_count++;
		mix(&finish_log_digest, (unsigned long)event);
		mix(&finish_log_digest, node_addr);
		mix(&finish_log_digest, addr);
		mix(&finish_log_digest, (unsigned long)npages);
		mix(&finish_log_digest, (unsigned long)zero_at_free_value);
		mix(&finish_log_digest, (unsigned long)(int)detail);
	}

	static void reset_finish_trace(int send_rc)
	{
		finish_send_count = 0;
		finish_send_rc = send_rc;
		finish_send_packet = 0;
		finish_log_count = 0;
		finish_log_digest = 0x6672656566696e69UL;
	}

	static unsigned long numa_free_finish_digest(void)
	{
		unsigned long digest = 0x66726565646f6e65UL;

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(0, 0, 0,
			0x11110000UL, ARENA_BASE, 2, 1, 0xaaaa0000UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(0, 5, 0,
			0x11110000UL, ARENA_BASE, 3, 0, 0xaaaa0001UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(2, 0, 0,
			0x11110000UL, ARENA_BASE, 4, 1, 0xaaaa0002UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 0);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(1, 0, -22,
			0x11110000UL, ARENA_BASE, 5, 1, 0xaaaa0003UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(1, 0, 2,
			0x11110000UL, ARENA_BASE, 6, 1, 0xaaaa0004UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(1, 0, 1,
			0x11110000UL, ARENA_BASE, 7, 1, 0xaaaa0005UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 1);
		require(finish_send_packet == 0xaaaa0005UL);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);
		mix(&digest, finish_send_packet);

		reset_finish_trace(-7);
		require(ihk_numa_free_pages_finish_result(1, 0, 1,
			0x11110000UL, ARENA_BASE, 8, 1, 0xaaaa0006UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 1);
		require(finish_send_packet == 0xaaaa0006UL);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);
		mix(&digest, finish_send_packet);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(1, 0, 0,
			0x11110000UL, ARENA_BASE, 9, 1, 0xaaaa0007UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 0);
		mix(&digest, finish_log_digest);

		reset_finish_trace(0);
		require(ihk_numa_free_pages_finish_result(9, 0, 0,
			0x11110000UL, ARENA_BASE, 10, 1, 0xaaaa0008UL,
			fake_finish_send, fake_finish_log) == 0);
		require(finish_send_count == 0);
		require(finish_log_count == 1);
		mix(&digest, finish_log_digest);

		return digest;
	}

	int main(void)
	{
	struct rb_root root = { NULL };
	unsigned long digest = 0;
	unsigned long a, b, c;

#ifndef PAGE_ALLOC_USE_C
	linux_page_offset_base = (unsigned long)arena - ARENA_BASE;
#endif
	memset(arena, 0xa5, sizeof(arena));

	require(__page_alloc_rbtree_free_range(&root, ARENA_BASE, 4 * LOCAL_PAGE_SIZE) == 0);
	mix(&digest, digest_tree(&root));
	require(__page_alloc_rbtree_free_range(&root, ARENA_BASE + 8 * LOCAL_PAGE_SIZE,
					       2 * LOCAL_PAGE_SIZE) == 0);
	mix(&digest, digest_tree(&root));
	require(__page_alloc_rbtree_free_range(&root, ARENA_BASE + 4 * LOCAL_PAGE_SIZE,
					       4 * LOCAL_PAGE_SIZE) == 0);
	mix(&digest, digest_tree(&root));

	a = __page_alloc_rbtree_alloc_pages(&root, 1, 0);
	require(a == ARENA_BASE);
	mix(&digest, a);
	mix(&digest, digest_tree(&root));

	b = __page_alloc_rbtree_alloc_pages(&root, 2, 2);
	require(b == ARENA_BASE + 4 * LOCAL_PAGE_SIZE);
	mix(&digest, b);
	mix(&digest, digest_tree(&root));

	require(__page_alloc_rbtree_free_range(&root, a, LOCAL_PAGE_SIZE) == 0);
	mix(&digest, digest_tree(&root));
	require(__page_alloc_rbtree_free_range(&root, b, 2 * LOCAL_PAGE_SIZE) == 0);
	mix(&digest, digest_tree(&root));

	zero_at_free = 0;
	c = __page_alloc_rbtree_alloc_pages(&root, 10, 0);
	require(c == ARENA_BASE);
	mix(&digest, c);
	mix(&digest, digest_tree(&root));
	require(root.rb_node == NULL);

	require(__page_alloc_rbtree_free_range(&root, ARENA_BASE, 10 * LOCAL_PAGE_SIZE) == 0);
	require(__page_alloc_rbtree_free_range(&root, ARENA_BASE + LOCAL_PAGE_SIZE,
					       LOCAL_PAGE_SIZE) == 22);
	mix(&digest, digest_tree(&root));
	require(__page_alloc_rbtree_alloc_pages(&root, 16, 0) == 0);
	mix(&digest, digest_tree(&root));

	require(__page_alloc_rbtree_reserve_pages(&root,
						  ARENA_BASE + 2 * LOCAL_PAGE_SIZE,
						  3) == ARENA_BASE + 2 * LOCAL_PAGE_SIZE);
	mix(&digest, digest_tree(&root));
	require(__page_alloc_rbtree_reserve_pages(&root,
						  ARENA_BASE + 2 * LOCAL_PAGE_SIZE,
						  1) == 0);
	mix(&digest, digest_tree(&root));
	for (int initialized = 0; initialized <= 1; initialized++) {
		mix(&digest, (unsigned long)__ihk_numa_cpu_cache_try_result(
			initialized));
	}
	mix(&digest, (unsigned long)__ihk_numa_cpu_cache_alloc_hit_result(0));
	mix(&digest, (unsigned long)__ihk_numa_cpu_cache_alloc_hit_result(
		ARENA_BASE));
	mix(&digest, (unsigned long)__ihk_numa_cpu_cache_free_success_result(0));
	mix(&digest, (unsigned long)__ihk_numa_cpu_cache_free_success_result(1));
	mix(&digest, (unsigned long)__ihk_numa_cpu_cache_free_success_result(-5));
		{
			unsigned long cache_addr;

			cache_addr = __ihk_numa_cpu_cache_alloc_nolock(&root, 1, 0);
		require(cache_addr == ARENA_BASE);
		mix(&digest, cache_addr);
		mix(&digest, digest_tree(&root));
		require(__ihk_numa_cpu_cache_free_nolock(&root, cache_addr, 1) == 0);
		mix(&digest, digest_tree(&root));
		require(__ihk_numa_cpu_cache_alloc_nolock(NULL, 1, 0) == 0);
			require(__ihk_numa_cpu_cache_free_nolock(NULL, cache_addr, 1) == 22);
			require(__ihk_numa_cpu_cache_free_nolock(&root, cache_addr, 0) == 22);
		}
		{
			unsigned long cache_addr;
			int cache_action;

			reset_irq_trace();
			cache_addr = __ihk_numa_cpu_cache_alloc_try_result(0, &root,
									   1, 0,
									   fake_irq_save,
									   fake_irq_restore);
			require(cache_addr == 0);
			require(irq_save_calls == 0);
			require(irq_restore_calls == 0);
			mix(&digest, cache_addr);
			mix(&digest, (unsigned long)irq_save_calls);
			mix(&digest, (unsigned long)irq_restore_calls);

			reset_irq_trace();
			cache_addr = __ihk_numa_cpu_cache_alloc_try_result(1, &root,
									   1, 0,
									   fake_irq_save,
									   fake_irq_restore);
			require(cache_addr == ARENA_BASE);
			require(irq_save_calls == 1);
			require(irq_restore_calls == 1);
			require(restored_irq_cookie == irq_cookie);
			mix(&digest, cache_addr);
			mix(&digest, restored_irq_cookie);
			mix(&digest, digest_tree(&root));

			reset_irq_trace();
			cache_action = __ihk_numa_cpu_cache_free_try_result(1, &root,
									    cache_addr,
									    1,
									    fake_irq_save,
									    fake_irq_restore);
			require(cache_action == 1);
			require(irq_save_calls == 1);
			require(irq_restore_calls == 1);
			require(restored_irq_cookie == irq_cookie);
			mix(&digest, (unsigned long)cache_action);
			mix(&digest, digest_tree(&root));

			reset_irq_trace();
			cache_action = __ihk_numa_cpu_cache_free_try_result(0, &root,
									    cache_addr,
									    1,
									    fake_irq_save,
									    fake_irq_restore);
			require(cache_action == 0);
			require(irq_save_calls == 0);
			require(irq_restore_calls == 0);
			mix(&digest, (unsigned long)cache_action);

			reset_irq_trace();
			cache_action = __ihk_numa_cpu_cache_free_try_result(1, NULL,
									    cache_addr,
									    1,
									    fake_irq_save,
									    fake_irq_restore);
			require(cache_action == 2);
			require(irq_save_calls == 1);
			require(irq_restore_calls == 1);
			mix(&digest, (unsigned long)cache_action);

			reset_irq_trace();
			cache_addr = __ihk_numa_cpu_cache_alloc_try_result(1, &root,
									   1, 0,
									   NULL,
									   fake_irq_restore);
			require(cache_addr == 0);
			require(irq_save_calls == 0);
			require(irq_restore_calls == 0);
			mix(&digest, cache_addr);

			cache_action = __ihk_numa_cpu_cache_free_try_result(1, &root,
									    cache_addr,
									    1,
									    fake_irq_save,
									    NULL);
			require(cache_action == 0);
			mix(&digest, (unsigned long)cache_action);
		}
		for (int cpu_initialized = 0; cpu_initialized <= 1; cpu_initialized++) {
		for (int has_current = 0; has_current <= 1; has_current++) {
			for (int is_idle = 0; is_idle <= 1; is_idle++) {
				for (int nohost = 0; nohost <= 1; nohost++) {
					for (int workers = 0; workers <= 2; workers++) {
						mix(&digest,
						    __ihk_numa_linux_zero_request_action(
							    cpu_initialized,
							    has_current, is_idle,
							    nohost, workers));
					}
				}
			}
		}
	}
	{
		struct free_chunk *chunk;
		int chunks = 0;

		while ((chunk = __page_alloc_rbtree_get_root_chunk(&root))) {
			require((void *)chunk == phys_to_virt(chunk->addr));
			mix(&digest, chunk->addr);
			mix(&digest, chunk->size);
			chunks++;
		}

		require(chunks == 2);
		require(root.rb_node == NULL);
	}
	mix(&digest, digest_tree(&root));
	mix(&digest, numa_free_finish_digest());

	printf("page_alloc ok digest=%016lx\n", digest);
	return 0;
}
