#include <stdio.h>
#include <string.h>

extern int hex_to_bin(char);
extern int __bitmap_empty(const unsigned long *, int);
extern int __bitmap_full(const unsigned long *, int);
extern int __bitmap_equal(const unsigned long *, const unsigned long *, int);
extern void __bitmap_complement(unsigned long *, const unsigned long *, int);
extern void __bitmap_shift_right(unsigned long *, const unsigned long *, int, int);
extern void __bitmap_shift_left(unsigned long *, const unsigned long *, int, int);
extern int __bitmap_and(unsigned long *, const unsigned long *, const unsigned long *, int);
extern void __bitmap_or(unsigned long *, const unsigned long *, const unsigned long *, int);
extern void __bitmap_xor(unsigned long *, const unsigned long *, const unsigned long *, int);
extern int __bitmap_andnot(unsigned long *, const unsigned long *, const unsigned long *, int);
extern int __bitmap_intersects(const unsigned long *, const unsigned long *, int);
extern int __bitmap_subset(const unsigned long *, const unsigned long *, int);
extern int __bitmap_weight(const unsigned long *, int);
extern void bitmap_set(unsigned long *, int, int);
extern void bitmap_clear(unsigned long *, int, int);
extern unsigned long bitmap_find_next_zero_area(unsigned long *, unsigned long,
						unsigned long, unsigned int,
						unsigned long);
extern int bitmap_find_free_region(unsigned long *, int, int);
extern void bitmap_release_region(unsigned long *, int, int);
extern int bitmap_allocate_region(unsigned long *, int, int);
extern int bitmap_ord_to_pos(const unsigned long *, int, int);
extern void bitmap_remap(unsigned long *, const unsigned long *,
			 const unsigned long *, const unsigned long *, int);
extern int bitmap_bitremap(int, const unsigned long *,
			   const unsigned long *, int);
extern void bitmap_onto(unsigned long *, const unsigned long *,
			const unsigned long *, int);
extern void bitmap_fold(unsigned long *, const unsigned long *, int, int);
extern int bitmap_scnprintf(char *, unsigned int, const unsigned long *, int);
extern int bitmap_scnlistprintf(char *, unsigned int, const unsigned long *, int);

static unsigned long rng_state = 0x123456789abcdef0UL;

static unsigned long rnd(void)
{
	rng_state = rng_state * 6364136223846793005UL + 1442695040888963407UL;
	return rng_state;
}

static void fill(unsigned long *dst, int words)
{
	for (int i = 0; i < words; i++)
		dst[i] = rnd();
}

static unsigned long digest_words(const unsigned long *src, int words)
{
	unsigned long d = 0xcbf29ce484222325UL;
	for (int i = 0; i < words; i++) {
		d ^= src[i];
		d *= 0x100000001b3UL;
	}
	return d;
}

static void mix_value(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_bytes(unsigned long *digest, const char *buf, unsigned int len)
{
	for (unsigned int i = 0; i < len; i++)
		mix_value(digest, (unsigned long)(unsigned char)buf[i] |
			   ((unsigned long)i << 8));
}

static void run_print_case(unsigned long *digest, const unsigned long *map,
			   int bits, unsigned int buflen)
{
	char buf[160];
	int ret;

	memset(buf, 0xcc, sizeof(buf));
	ret = bitmap_scnprintf(buf, buflen, map, bits);
	mix_value(digest, (unsigned long)(long)ret);
	mix_value(digest, (unsigned long)buflen);
	mix_value(digest, (unsigned long)(unsigned int)bits);
	mix_bytes(digest, buf, sizeof(buf));

	memset(buf, 0xdd, sizeof(buf));
	ret = bitmap_scnlistprintf(buf, buflen, map, bits);
	mix_value(digest, (unsigned long)(long)ret);
	mix_value(digest, (unsigned long)buflen << 16);
	mix_value(digest, (unsigned long)(unsigned int)bits << 1);
	mix_bytes(digest, buf, sizeof(buf));
}

int main(void)
{
	unsigned long a[5], b[5], c[5];
	unsigned long digest = 0;
	int bit_sizes[] = { 1, 2, 7, 31, 32, 63, 64, 65, 95, 127, 128, 129, 191, 255, 256, 257 };
	int shifts[] = { 0, 1, 7, 31, 32, 63, 64, 65, 129, 255, 300 };
	unsigned long aligns[] = { 0, 1, 3, 7, 15, 31, 63 };
	unsigned int zero_area_sizes[] = { 0, 1, 2, 5, 17, 64, 130 };
	int region_orders[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
	unsigned int print_buflens[] = { 0, 1, 2, 3, 8, 17, 33, 64, 128 };

	for (int h = 0; h < 256; h++)
		digest = digest * 131 + (unsigned long)(hex_to_bin((char)h) + 2);

	for (unsigned int bi = 0; bi < sizeof(bit_sizes) / sizeof(bit_sizes[0]); bi++) {
		int bits = bit_sizes[bi];
		int words = (bits + 63) / 64;
		fill(a, 5);
		fill(b, 5);
		for (unsigned int pi = 0; pi < sizeof(print_buflens) / sizeof(print_buflens[0]); pi++) {
			run_print_case(&digest, a, bits, print_buflens[pi]);
			run_print_case(&digest, NULL, bits, print_buflens[pi]);
		}
		digest ^= (unsigned long)__bitmap_empty(a, bits);
		digest ^= (unsigned long)__bitmap_full(a, bits) << 1;
		digest ^= (unsigned long)__bitmap_equal(a, b, bits) << 2;
		digest ^= (unsigned long)__bitmap_intersects(a, b, bits) << 3;
		digest ^= (unsigned long)__bitmap_subset(a, b, bits) << 4;
		digest ^= (unsigned long)__bitmap_weight(a, bits) << 8;
		memset(c, 0xa5, sizeof(c)); __bitmap_complement(c, a, bits); digest ^= digest_words(c, words);
		memset(c, 0x5a, sizeof(c)); digest ^= (unsigned long)__bitmap_and(c, a, b, bits); digest ^= digest_words(c, words);
		memset(c, 0x5a, sizeof(c)); __bitmap_or(c, a, b, bits); digest ^= digest_words(c, words);
		memset(c, 0x5a, sizeof(c)); __bitmap_xor(c, a, b, bits); digest ^= digest_words(c, words);
		memset(c, 0x5a, sizeof(c)); digest ^= (unsigned long)__bitmap_andnot(c, a, b, bits); digest ^= digest_words(c, words);
		for (unsigned int si = 0; si < sizeof(shifts) / sizeof(shifts[0]); si++) {
			int shift_words = shifts[si] / (int)(sizeof(unsigned long) * 8);
			if (shift_words > words)
				continue;
			memset(c, 0x5a, sizeof(c)); __bitmap_shift_left(c, a, shifts[si], bits); digest ^= digest_words(c, words);
			memset(c, 0x5a, sizeof(c)); __bitmap_shift_right(c, a, shifts[si], bits); digest ^= digest_words(c, words);
		}
		memset(c, 0, sizeof(c));
		for (int start = 0; start < bits; start += 17) {
			int nr = (start * 7 + bits) % 41;
			if (start + nr > bits)
				nr = bits - start;
			bitmap_set(c, start, nr);
			if (nr > 2)
				bitmap_clear(c, start + 1, nr - 2);
		}
		digest ^= digest_words(c, words);
		{
			int ords[] = { -1, 0, 1, 2, 7, bits / 2, bits - 1, bits, bits + 3 };
			int oldbits[] = { -1, 0, 1, bits / 2, bits - 1, bits, bits + 9 };
			int fold_sizes[] = { 1, 2, 3, 7, bits > 1 ? bits / 2 : 1, bits };
			for (unsigned int oi = 0; oi < sizeof(ords) / sizeof(ords[0]); oi++)
				mix_value(&digest, (unsigned long)(long)bitmap_ord_to_pos(a, ords[oi], bits));
			for (unsigned int oi = 0; oi < sizeof(oldbits) / sizeof(oldbits[0]); oi++)
				mix_value(&digest, (unsigned long)(long)bitmap_bitremap(oldbits[oi], a, b, bits));
			memset(c, 0x5a, sizeof(c)); bitmap_remap(c, a, b, a, bits); digest ^= digest_words(c, words);
			memset(c, 0x5a, sizeof(c)); bitmap_remap(c, a, a, b, bits); digest ^= digest_words(c, words);
			memset(c, 0x5a, sizeof(c)); bitmap_onto(c, a, b, bits); digest ^= digest_words(c, words);
			for (unsigned int fi = 0; fi < sizeof(fold_sizes) / sizeof(fold_sizes[0]); fi++) {
				memset(c, 0x5a, sizeof(c)); bitmap_fold(c, a, fold_sizes[fi], bits); digest ^= digest_words(c, words);
			}
		}
		for (unsigned int ai = 0; ai < sizeof(aligns) / sizeof(aligns[0]); ai++) {
			for (unsigned int zi = 0; zi < sizeof(zero_area_sizes) / sizeof(zero_area_sizes[0]); zi++) {
				for (unsigned long start = 0; start <= (unsigned long)bits + 5; start += 13) {
					unsigned long area = bitmap_find_next_zero_area(c, bits, start,
						zero_area_sizes[zi], aligns[ai]);
					mix_value(&digest, area);
				}
			}
		}
		for (unsigned int oi = 0; oi < sizeof(region_orders) / sizeof(region_orders[0]); oi++) {
			int order = region_orders[oi];
			int region_bits = 1 << order;
			memset(c, 0, sizeof(c));
			mix_value(&digest, (unsigned long)bitmap_find_free_region(c, bits, order));
			digest ^= digest_words(c, words);
			for (int pos = 0; pos + region_bits <= bits; pos += region_bits * 3) {
				mix_value(&digest, (unsigned long)bitmap_allocate_region(c, pos, order));
				digest ^= digest_words(c, words);
				mix_value(&digest, (unsigned long)bitmap_allocate_region(c, pos, order));
				bitmap_release_region(c, pos, order);
				digest ^= digest_words(c, words);
				mix_value(&digest, (unsigned long)bitmap_allocate_region(c, pos, order));
			}
			digest ^= digest_words(c, words);
		}
	}
	printf("bitmap ok digest=%016lx\n", digest);
	return 0;
}
