#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

extern int NICE_TO_PRIO(int);
extern int PRIO_TO_NICE(int);
extern int USER_PRIO(int);
extern long nice_to_rlimit(long);
extern long rlimit_to_nice(long);
extern int sched_get_priority_max_value(int);
extern int sched_get_priority_min_value(int);
extern long sched_get_priority_max_body_result(int);
extern long sched_get_priority_min_body_result(int);
extern int sched_policy_is_valid(int);
extern int sched_policy_needs_root(int);
extern int setscheduler_validate(int, int);
extern long sched_rr_interval_nsec(int);
extern int sched_affinity_permission_result(unsigned int, unsigned int,
					    unsigned int);
extern int sched_getaffinity_len_result(unsigned long, int);
extern unsigned long sched_affinity_copy_len(unsigned long, unsigned long);
extern unsigned long timer_spin_sleep_remaining_result(unsigned long,
						       unsigned long);
	extern int timer_runq_should_schedule_result(int);
	extern unsigned long timer_after_spin_remaining_result(unsigned long,
							       unsigned long);
	extern unsigned long timer_after_tick_remaining_result(unsigned long,
							       unsigned long);
	struct timer_runtime_offsets {
		unsigned long thread_status_offset;
		unsigned long thread_sched_list_offset;
		unsigned long thread_spin_sleep_lock_offset;
		unsigned long thread_spin_sleep_offset;
		unsigned long thread_itimer_enabled_offset;
		unsigned long cpu_runq_lock_offset;
		unsigned long cpu_runq_offset;
		unsigned long cpu_runq_len_offset;
		unsigned long cpu_current_offset;
		unsigned long cpu_timer_enabled_offset;
		unsigned long cpu_backlog_list_offset;
		unsigned long timer_timeout_offset;
		unsigned long timer_waitq_offset;
		unsigned long timer_list_offset;
		unsigned long timer_thread_offset;
	};
	struct sched_migrate_offsets {
		unsigned long req_list_offset;
		unsigned long req_thread_offset;
		unsigned long req_wq_offset;
		unsigned long thread_cpu_id_offset;
		unsigned long thread_tid_offset;
		unsigned long cpu_migq_lock_offset;
		unsigned long cpu_migq_offset;
		unsigned long cpu_runq_lock_offset;
		unsigned long cpu_flags_offset;
		unsigned long cpu_status_offset;
	};
	struct sched_do_migrate_offsets {
		unsigned long req_list_offset;
		unsigned long req_thread_offset;
		unsigned long req_wq_offset;
		unsigned long thread_cpu_id_offset;
		unsigned long thread_tid_offset;
		unsigned long thread_cpu_set_offset;
		unsigned long thread_sched_list_offset;
		unsigned long thread_vm_offset;
		unsigned long vm_address_space_offset;
		unsigned long address_space_cpu_set_offset;
		unsigned long address_space_cpu_set_lock_offset;
		unsigned long cpu_migq_lock_offset;
		unsigned long cpu_migq_offset;
		unsigned long cpu_runq_lock_offset;
		unsigned long cpu_runq_offset;
		unsigned long cpu_runq_len_offset;
		unsigned long cpu_flags_offset;
	};
	struct sched_runqueue_offsets {
		unsigned long thread_cpu_id_offset;
		unsigned long thread_tid_offset;
		unsigned long thread_status_offset;
		unsigned long thread_spin_sleep_lock_offset;
		unsigned long thread_spin_sleep_offset;
		unsigned long thread_sched_list_offset;
		unsigned long thread_sigpending_offset;
		unsigned long thread_sigcommon_offset;
		unsigned long sigcommon_sigpending_offset;
		unsigned long thread_proc_offset;
			unsigned long thread_mod_clone_offset;
			unsigned long proc_pid_offset;
			unsigned long proc_status_offset;
			unsigned long proc_update_lock_offset;
			unsigned long proc_clone_count_offset;
			unsigned long cpu_runq_lock_offset;
		unsigned long cpu_runq_irqstate_offset;
		unsigned long cpu_current_offset;
		unsigned long cpu_prevpid_offset;
		unsigned long cpu_runq_offset;
		unsigned long cpu_runq_len_offset;
		unsigned long cpu_runq_reserved_offset;
		unsigned long cpu_flags_offset;
		unsigned long cpu_status_offset;
		unsigned long cpu_in_interrupt_offset;
		unsigned long cpu_nr_ctx_switches_offset;
	};
	struct sched_schedule_result {
		unsigned long cpu_addr;
		unsigned long prev_thread_addr;
		unsigned long next_thread_addr;
		int prevpid;
		int switch_ctx;
		int action;
	};
	extern int timer_init_timers_result(unsigned long, unsigned long,
					    void (*)(unsigned long));
	extern unsigned long timer_schedule_timeout_body_result(
		unsigned long, unsigned long, unsigned long, unsigned long,
		const struct timer_runtime_offsets *,
		unsigned long (*)(void), unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long, int), void (*)(void), void (*)(void),
		void (*)(void));
	extern int timer_wake_tick_result(
		unsigned long, unsigned long, unsigned long,
		const struct timer_runtime_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long, unsigned long));
	extern int timer_wake_loop_body_result(
		unsigned long, unsigned long, unsigned long, int,
		const struct timer_runtime_offsets *,
		unsigned long (*)(void), void (*)(void),
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long, unsigned long));
	extern int timer_set_timer_body_result(
		unsigned long, int, int, const struct timer_runtime_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned int), void (*)(void));
	extern int sched_request_migrate_body_result(
		int, unsigned long, unsigned long, unsigned long,
		unsigned long, int, int, unsigned int, unsigned int, int, int,
		const struct sched_migrate_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long),
		void (*)(unsigned long),
		void (*)(unsigned long, unsigned long, int),
		void (*)(unsigned long, unsigned long), int (*)(int),
		void (*)(int, int), void (*)(void),
		void (*)(unsigned long, int, int));
	extern int sched_do_migrate_body_result(
		int, unsigned long, int, unsigned int, int,
		const struct sched_do_migrate_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long),
		unsigned long (*)(int), void (*)(unsigned long), int (*)(int),
		void (*)(int, int), void (*)(unsigned long, int, int, int));
	extern int sched_release_cpuid_body_result(
		int, unsigned long, unsigned long, int,
		const struct sched_runqueue_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long));
	extern int sched_check_need_resched_body_result(
		unsigned long, unsigned int, unsigned int,
		const struct sched_runqueue_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long), void (*)(void),
		void (*)(int, unsigned long, unsigned long, int, int));
		extern int sched_runq_add_thread_locked_result(
			unsigned long, unsigned long, int, unsigned int, int,
			const struct sched_runqueue_offsets *,
			void (*)(int, unsigned long, unsigned long, int, int));
		extern int sched_runq_add_thread_body_result(
			unsigned long, unsigned long, unsigned long, int, int,
			unsigned int, int, int, const struct sched_runqueue_offsets *,
			unsigned long (*)(unsigned long),
			void (*)(unsigned long, unsigned long),
			void (*)(unsigned long), void (*)(unsigned long),
			void (*)(unsigned long), void (*)(unsigned long),
			int (*)(unsigned long), void (*)(void), void (*)(void),
			int (*)(int), void (*)(int, int),
			void (*)(int, unsigned long, unsigned long, int, int));
		extern int sched_runq_del_thread_body_result(
		unsigned long, unsigned long, int,
		const struct sched_runqueue_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long));
	extern int sched_wakeup_thread_body_result(
		unsigned long, unsigned long, unsigned long, int, int, int, int,
		int, unsigned int, int, const struct sched_runqueue_offsets *,
		unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long, int), void (*)(int), int (*)(int),
		void (*)(int, int),
		void (*)(int, unsigned long, unsigned long, int, int));
	extern int sched_spin_sleep_or_schedule_body_result(
		unsigned long, unsigned long, int, int, unsigned int,
		const struct sched_runqueue_offsets *, unsigned long (*)(void),
		void (*)(unsigned long), unsigned long (*)(unsigned long),
		void (*)(unsigned long, unsigned long),
		void (*)(unsigned long), void (*)(unsigned long),
		void (*)(void), void (*)(void), void (*)(void),
		int (*)(unsigned long),
		void (*)(int, unsigned long, unsigned long, int, int));
	extern int sched_schedule_prepare_body_result(
		unsigned long, unsigned long, int, unsigned int, unsigned int,
		int, int, int, int, int, int,
		const struct sched_runqueue_offsets *,
		struct sched_schedule_result *, unsigned long (*)(void),
		void (*)(unsigned long), void (*)(unsigned long),
		void (*)(unsigned long), void (*)(int), void (*)(void),
		int (*)(unsigned long),
		void (*)(int, unsigned long, unsigned long, int, int));
	extern int futex_key_match_result(int, int, unsigned long, unsigned long,
					  unsigned long, unsigned long, unsigned long,
					  unsigned long);
extern int futex_key_prepare_result(unsigned long, int, unsigned long *,
				    unsigned long *, int *);
extern int futex_get_key_result(unsigned long, int, unsigned long,
				unsigned long, unsigned long, unsigned long,
				unsigned long, unsigned long, int,
				void (*)(unsigned long),
				int (*)(unsigned long, unsigned long,
					unsigned long),
				int (*)(unsigned long, unsigned long, int),
				void (*)(int));
extern int futex_wake_bitset_valid_result(unsigned int);
extern int futex_waiter_matches_bitset_result(unsigned int, unsigned int);
extern int futex_wake_limit_reached_result(int, int);
extern int futex_wake_scan_result(unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, int, unsigned int,
				  int, int, void (*)(unsigned long));
extern int futex_wake_body_result(unsigned long, int, int,
				  unsigned int, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  unsigned long, unsigned long,
				  int (*)(unsigned long, int,
					  unsigned long),
				  unsigned long (*)(unsigned long),
				  unsigned long (*)(unsigned long),
				  void (*)(unsigned long, unsigned long),
				  void (*)(int, unsigned long),
				  void (*)(unsigned long));
extern int futex_wake_op_body_result(
	unsigned long, int, unsigned long, int, int, int, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int (*)(unsigned long, int, unsigned long),
	unsigned long (*)(unsigned long), void (*)(unsigned long),
	void (*)(unsigned long), int (*)(int, unsigned long),
	void (*)(int, unsigned long), void (*)(unsigned long));
extern int futex_requeue_should_move_result(unsigned long, unsigned long);
extern int futex_requeue_loop_done_result(int, int, int);
extern int futex_requeue_should_wake_result(int, int);
extern int futex_requeue_scan_result(unsigned long, unsigned long,
				     unsigned long, unsigned long,
				     unsigned long, unsigned long,
				     unsigned long, unsigned long,
				     int, int, int, int *,
				     void (*)(unsigned long, unsigned long),
				     void (*)(unsigned long, unsigned long),
				     unsigned long);
extern int futex_requeue_body_result(
	unsigned long, int, unsigned long, int, int, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int (*)(unsigned long, int, unsigned long),
	unsigned long (*)(unsigned long), void (*)(unsigned long),
	void (*)(unsigned long), int (*)(unsigned long, unsigned long),
	void (*)(int, unsigned long), void (*)(unsigned long),
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern void futex_double_lock_hb_result(unsigned long, unsigned long,
					unsigned long,
					void (*)(unsigned long));
extern void futex_double_unlock_hb_result(unsigned long, unsigned long,
					  unsigned long,
					  void (*)(unsigned long));
extern void futex_wake_mark_woken_result(unsigned long, unsigned long,
					 unsigned long, unsigned long);
extern int futex_unqueue_detach_result(unsigned long, unsigned long,
				       unsigned long);
extern int futex_unqueue_me_result(unsigned long, unsigned long,
				   unsigned long, unsigned long,
				   unsigned long, void (*)(unsigned long),
				   void (*)(unsigned long),
				   void (*)(unsigned long));
extern int futex_requeue_move_result(unsigned long, unsigned long,
				     unsigned long, unsigned long,
				     unsigned long, unsigned long,
				     unsigned long);
extern int futex_requeue_key_update_result(unsigned long, unsigned long,
					   unsigned long, unsigned long,
					   void (*)(unsigned long));
extern void futex_queue_publish_waiter_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, int, int);
extern void futex_queue_insert_result(unsigned long, unsigned long,
				      unsigned long, int, unsigned long,
				      unsigned long);
extern int futex_queue_me_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, int, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, int, unsigned long (*)(unsigned long),
	int (*)(int), int (*)(int), void (*)(unsigned long));
extern void futex_wait_prepare_q_result(unsigned long, unsigned long,
					unsigned long, unsigned long,
					unsigned int, unsigned long);
extern void futex_wait_key_init_result(unsigned long, unsigned long,
				       unsigned long);
extern void futex_queue_lock_ptr_store_result(unsigned long, unsigned long,
					      unsigned long);
extern int futex_wait_setup_result(unsigned long, unsigned int, int,
				   unsigned long, unsigned long *,
				   unsigned long, unsigned long,
				   int (*)(unsigned long, int,
					   unsigned long),
				   unsigned long (*)(unsigned long),
				   int (*)(unsigned long, unsigned long),
				   void (*)(unsigned long, unsigned long),
				   void (*)(int, unsigned long));
extern int futex_wait_mark_interruptible_result(unsigned long, unsigned long,
						int);
extern int futex_wait_spin_sleep_store_result(unsigned long, unsigned long,
					      int);
extern int futex_wait_finish_state_result(unsigned long, unsigned long,
					  unsigned long, int);
extern int futex_wait_schedule_action_result(int, unsigned long);
extern long futex_wait_queue_me_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, int, unsigned long, int, int,
	unsigned long (*)(unsigned long),
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long),
	long (*)(unsigned long), void (*)(void),
	void (*)(int, unsigned long, int));
extern int futex_wait_post_action_result(int, unsigned long, long, int, int);
extern int futex_wait_body_result(
	unsigned long, int, unsigned int, unsigned long, unsigned int,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	int (*)(unsigned long, unsigned int, int, unsigned long,
		unsigned long),
	long (*)(unsigned long, unsigned long, unsigned long),
	int (*)(unsigned long), int (*)(unsigned long),
	void (*)(int, unsigned long),
	void (*)(int, unsigned long, int, int));
extern int futex_wait_entry_result(
	unsigned long, int, unsigned int, unsigned long, unsigned int,
	unsigned long, unsigned long, unsigned long, int, unsigned long,
	unsigned long, unsigned long, unsigned long (*)(void),
	int (*)(unsigned long, int, unsigned int, unsigned long,
		unsigned int, unsigned long, unsigned long, unsigned long));
extern int futex_wake_target_result(unsigned long);
extern unsigned long futex_wake_linux_channel_result(unsigned long,
						     unsigned long);
extern void futex_wake_ikc_packet_fill_result(unsigned long, unsigned long,
					      unsigned long, unsigned long,
					      int, unsigned long,
					      unsigned long);
extern int futex_wake_orchestrate_result(
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long, unsigned long, unsigned long, int,
	unsigned long, int, unsigned long (*)(int),
	int (*)(unsigned long, unsigned long),
	void (*)(unsigned long, int),
	void (*)(int, unsigned long, unsigned long, int, unsigned long, int));
extern int futex_hash_bucket_table_init_result(unsigned long, int,
					       unsigned long, unsigned long,
					       unsigned long, unsigned long,
					       unsigned long, unsigned long,
					       unsigned long, unsigned long);
extern int futex_init_table_result(unsigned long, int, unsigned long, int,
				   unsigned long (*)(unsigned long, int),
				   unsigned long, unsigned long, unsigned long,
				   unsigned long, unsigned long, unsigned long,
				   unsigned long);
extern unsigned long futex_hash_bucket_result(unsigned long, unsigned long,
					      int, unsigned long,
					      unsigned int (*)(unsigned long));
extern int futex_dispatch_result(int, unsigned long, unsigned int,
				 unsigned long, unsigned long,
				 unsigned int, unsigned int, int,
				 int (*)(unsigned long, int,
					 unsigned int, unsigned long,
					 unsigned int, int),
				 int (*)(unsigned long, int,
					 unsigned int, unsigned int),
				 int (*)(unsigned long, int,
					 unsigned long, unsigned int,
					 unsigned int, int, unsigned int,
					 int),
				 int (*)(unsigned long, int,
					 unsigned long, unsigned int,
					 unsigned int, unsigned int),
				 void (*)(int));
extern int FUTEX_OP(int, int, int, int);
extern int get_futex_value_locked(unsigned int *, unsigned int *);
extern unsigned int mc_jhash2(const unsigned int *, unsigned int,
			      unsigned int);
extern int syscall_offload_should_schedule_result(int, int, int, int, int);

struct sched_syscall_offsets {
	unsigned long thread_proc_offset;
	unsigned long thread_sched_param_offset;
	unsigned long thread_sched_policy_offset;
	unsigned long thread_cpu_id_offset;
	unsigned long thread_cpu_set_offset;
	unsigned long proc_pid_offset;
	unsigned long proc_ruid_offset;
	unsigned long proc_euid_offset;
	unsigned long proc_cpu_set_offset;
};

typedef unsigned long (*sched_find_thread_fn_t)(int);
typedef void (*sched_thread_unlock_fn_t)(unsigned long);
typedef int (*sched_hold_thread_fn_t)(unsigned long);
typedef void (*sched_release_thread_fn_t)(unsigned long);
typedef long (*sched_copy_from_user_fn_t)(void *, unsigned long, unsigned long);
typedef long (*sched_copy_to_user_fn_t)(unsigned long, const void *,
					unsigned long);
typedef long (*sched_do_syscall2_fn_t)(int, unsigned long, unsigned long);
typedef int (*sched_apply_scheduler_fn_t)(unsigned long, int, unsigned long);
typedef void (*sched_request_migrate_fn_t)(int, unsigned long);

extern long sched_setparam_body_result(int, unsigned long, unsigned long,
				       unsigned long, unsigned long,
				       const struct sched_syscall_offsets *,
				       int, sched_find_thread_fn_t,
				       sched_thread_unlock_fn_t,
				       sched_copy_from_user_fn_t,
				       sched_do_syscall2_fn_t,
				       sched_apply_scheduler_fn_t);
extern long sched_getparam_body_result(int, unsigned long, unsigned long,
				       unsigned long,
				       const struct sched_syscall_offsets *,
				       sched_find_thread_fn_t,
				       sched_thread_unlock_fn_t,
				       sched_copy_to_user_fn_t);
extern long sched_setscheduler_body_result(int, int, unsigned long,
					   unsigned long, unsigned long,
					   unsigned long,
					   const struct sched_syscall_offsets *,
					   int, sched_find_thread_fn_t,
					   sched_thread_unlock_fn_t,
					   sched_copy_from_user_fn_t,
					   sched_do_syscall2_fn_t,
					   sched_apply_scheduler_fn_t);
extern long sched_getscheduler_body_result(int, unsigned long,
					   const struct sched_syscall_offsets *,
					   sched_find_thread_fn_t,
					   sched_thread_unlock_fn_t);
extern long sched_rr_get_interval_body_result(int, unsigned long,
					      unsigned long,
					      const struct sched_syscall_offsets *,
					      sched_find_thread_fn_t,
					      sched_thread_unlock_fn_t,
					      sched_copy_to_user_fn_t);
extern long sched_setaffinity_body_result(int, unsigned long, unsigned long,
					  unsigned long, unsigned long,
					  unsigned long, unsigned long, int,
					  const struct sched_syscall_offsets *,
					  sched_find_thread_fn_t,
					  sched_thread_unlock_fn_t,
					  sched_hold_thread_fn_t,
					  sched_release_thread_fn_t,
					  sched_copy_from_user_fn_t,
					  sched_request_migrate_fn_t);
extern long sched_getaffinity_body_result(int, unsigned long, unsigned long,
					  unsigned long, unsigned long, int,
					  const struct sched_syscall_offsets *,
					  sched_find_thread_fn_t,
					  sched_thread_unlock_fn_t,
					  sched_hold_thread_fn_t,
					  sched_release_thread_fn_t,
					  sched_copy_to_user_fn_t);

#define FUTEX_WAIT 0
#define FUTEX_WAKE 1
#define FUTEX_REQUEUE 3
#define FUTEX_CMP_REQUEUE 4
#define FUTEX_WAKE_OP 5
#define FUTEX_WAIT_BITSET 9
#define FUTEX_WAKE_BITSET 10
#define FUTEX_WAIT_REQUEUE_PI 11
#define FUTEX_PRIVATE_FLAG 128
#define FUTEX_CLOCK_REALTIME 256
#define FUTEX_BITSET_MATCH_ANY 0xffffffffU
#define ENOSYS 38
#define EFAULT 14
#define EINVAL 22
#define EIO 5
#define EPERM 1
#define ENOMEM 12
#define ENOSYS 38
#define ESRCH 3
#define ENOTSUPP 524
#define EPERM 1
#define ESRCH 3
#define SCHED_NORMAL 0
#define SCHED_FIFO 1
#define SCHED_RR 2
#define SCHED_CHECK_SAME_OWNER 1
#define SCHED_CHECK_ROOT 2
#define SCHED_FAKE_CPU_WORDS 2
#define SCHED_FAKE_CPUSET_BYTES (SCHED_FAKE_CPU_WORDS * sizeof(unsigned long))
#define SCHED_CPU_FLAG_NEED_RESCHED 0x1U
#define SCHED_CPU_FLAG_NEED_MIGRATE 0x2U
#define SCHED_CPU_STATUS_IDLE 1
#define SCHED_CPU_STATUS_RUNNING 2
#define SCHED_CPU_STATUS_RESERVED 3
#define SCHED_PS_RUNNING 0x1
#define SCHED_PS_INTERRUPTIBLE 0x2
#define SCHED_PS_UNINTERRUPTIBLE 0x4
#define SCHED_PS_EXITED 0x10
#define SCHED_IHK_GV_IKC 14
#define SCHED_SCHEDULE_ACTION_RESCHED_ONLY 1
#define SCHED_SCHEDULE_ACTION_NO_SWITCH 2
#define SCHED_SCHEDULE_ACTION_SWITCH 3
#define SCHED_FAKE_CPUSET_BITS (SCHED_FAKE_CPU_WORDS * 8 * sizeof(unsigned long))
#define SCHED_LIST_POISON1 0x00100129UL
#define SCHED_LIST_POISON2 0x00200229UL

#define FUTEX_WAIT_SCHEDULE_NONE 0
#define FUTEX_WAIT_SCHEDULE_TIMEOUT 1
#define FUTEX_WAIT_SCHEDULE_DIRECT 2
#define FUTEX_WAKE_TARGET_MCKERNEL 0
#define FUTEX_WAKE_TARGET_LINUX 1
#define FUTEX_WAIT_QUEUE_LOG_TIMEOUT 1
#define FUTEX_WAIT_QUEUE_LOG_DIRECT 2
#define FUTEX_WAIT_QUEUE_LOG_WOKEN 3
#define FUTEX_WAIT_LOG_SETUP_RET 1
#define FUTEX_WAIT_LOG_SUCCESS 2
#define FUTEX_WAIT_LOG_TIMEOUT 3
#define FUTEX_WAIT_LOG_INTERRUPT 4
#define FUTEX_GET_KEY_LOG_VTOP_FAILED 1
#define FUTEX_WAKE_LOG_LINUX_TARGET 1
#define FUTEX_WAKE_LOG_SEND_FAILED 2
#define FUTEX_WAKE_LOG_SEND_OK 3
#define FUTEX_WAKE_LOG_MCKERNEL_TARGET 4
#define FUT_OFF_MMSHARED 2

#ifdef USE_C_FUTEX_OP_MODEL
int FUTEX_OP(int op, int oparg, int cmp, int cmparg)
{
	unsigned int encoded = (((unsigned int)op & 0x0f) << 28) |
		(((unsigned int)cmp & 0x0f) << 24) |
		(((unsigned int)oparg & 0x0fff) << 12) |
		((unsigned int)cmparg & 0x0fff);

	return (int)encoded;
}

int get_futex_value_locked(unsigned int *dest, unsigned int *from)
{
	*dest = *(volatile unsigned int *)from;

	return 0;
}

static void mc_jhash_mix(unsigned int *a, unsigned int *b, unsigned int *c)
{
	*a -= *b; *a -= *c; *a ^= (*c >> 13);
	*b -= *c; *b -= *a; *b ^= (*a << 8);
	*c -= *a; *c -= *b; *c ^= (*b >> 13);
	*a -= *b; *a -= *c; *a ^= (*c >> 12);
	*b -= *c; *b -= *a; *b ^= (*a << 16);
	*c -= *a; *c -= *b; *c ^= (*b >> 5);
	*a -= *b; *a -= *c; *a ^= (*c >> 3);
	*b -= *c; *b -= *a; *b ^= (*a << 10);
	*c -= *a; *c -= *b; *c ^= (*b >> 15);
}

unsigned int mc_jhash2(const unsigned int *k, unsigned int length,
		       unsigned int initval)
{
	unsigned int a, b, c, len;

	a = b = 0x9e3779b9U;
	c = initval;
	len = length;

	while (len >= 3) {
		a += k[0];
		b += k[1];
		c += k[2];
		mc_jhash_mix(&a, &b, &c);
		k += 3;
		len -= 3;
	}

	c += length * 4;
	switch (len) {
	case 2:
		b += k[1];
	case 1:
		a += k[0];
	};

	mc_jhash_mix(&a, &b, &c);
	return c;
}
#endif

struct futex_key {
	unsigned long opaque[3];
};

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct plist_head {
	struct list_head prio_list;
	struct list_head node_list;
};

struct plist_node {
	int prio;
	struct plist_head plist;
};

struct fake_futex_q {
	struct plist_node list;
	void *task;
	void *lock_ptr;
	struct futex_key key;
	struct futex_key *requeue_pi_key;
	unsigned int bitset;
	void *uti_futex_resp;
	int linux_cpu;
	void *th_spin_sleep;
	void *th_status;
	void *th_spin_sleep_lock;
	void *proc_status;
	void *proc_update_lock;
	void *runq_lock;
	void *clv_flags;
	int intr_id;
	int intr_vector;
	unsigned long th_spin_sleep_pa;
	unsigned long th_status_pa;
	unsigned long th_spin_sleep_lock_pa;
	unsigned long proc_status_pa;
	unsigned long proc_update_lock_pa;
	unsigned long runq_lock_pa;
	unsigned long clv_flags_pa;
};

struct fake_thread_state {
	int pad;
	int status;
	int spin_sleep;
	unsigned long spin_sleep_lock;
	int tid;
	int profile;
	unsigned long profile_start_ts;
	unsigned long profile_elapsed_ts;
};

struct fake_wake_packet {
	unsigned long header;
	int msg;
	int err;
	void *reply;
	struct {
		void *resp;
		int *spin_sleep;
	} futex;
	unsigned long tail;
};

struct fake_sched_param {
	int sched_priority;
};

struct fake_sched_proc {
	int pid;
	unsigned int ruid;
	unsigned int euid;
	unsigned long cpu_set[SCHED_FAKE_CPU_WORDS];
};

struct fake_sched_address_space {
	unsigned long cpu_set[SCHED_FAKE_CPU_WORDS];
	unsigned long cpu_set_lock;
};

struct fake_sched_vm {
	struct fake_sched_address_space *address_space;
};

struct fake_sched_thread {
	struct fake_sched_proc *proc;
	struct fake_sched_param sched_param;
	int sched_policy;
	int cpu_id;
	int tid;
	unsigned long cpu_set[SCHED_FAKE_CPU_WORDS];
	struct list_head sched_list;
	struct fake_sched_vm *vm;
};

struct fake_sched_timespec {
	long tv_sec;
	long tv_nsec;
};

static struct fake_sched_thread *sched_remote_thread;
static int sched_find_calls;
static int sched_find_fail_on_call;
static int sched_unlock_calls;
static int sched_copy_from_calls;
static int sched_copy_from_fail;
static int sched_copy_to_calls;
static int sched_copy_to_fail;
static int sched_syscall_calls;
static int sched_syscall_nr;
static unsigned long sched_syscall_arg0;
static unsigned long sched_syscall_arg1;
static long sched_syscall_ret;
static int sched_apply_calls;
static int sched_apply_policy;
static unsigned long sched_apply_thread;
static int sched_hold_calls;
static int sched_release_calls;
static int sched_migrate_calls;
static int sched_migrate_cpu;
static unsigned long sched_migrate_thread;

static void reset_sched_trace(void)
{
	sched_find_calls = 0;
	sched_find_fail_on_call = 0;
	sched_unlock_calls = 0;
	sched_copy_from_calls = 0;
	sched_copy_from_fail = 0;
	sched_copy_to_calls = 0;
	sched_copy_to_fail = 0;
	sched_syscall_calls = 0;
	sched_syscall_nr = 0;
	sched_syscall_arg0 = 0;
	sched_syscall_arg1 = 0;
	sched_syscall_ret = 0;
	sched_apply_calls = 0;
	sched_apply_policy = -1;
	sched_apply_thread = 0;
	sched_hold_calls = 0;
	sched_release_calls = 0;
	sched_migrate_calls = 0;
	sched_migrate_cpu = -1;
	sched_migrate_thread = 0;
}

static unsigned long fake_sched_find_thread(int pid)
{
	sched_find_calls++;
	if (sched_find_fail_on_call == sched_find_calls)
		return 0;
	if (!sched_remote_thread || !sched_remote_thread->proc)
		return 0;
	return (sched_remote_thread->proc->pid == pid ||
		sched_remote_thread->tid == pid) ?
		(unsigned long)sched_remote_thread : 0;
}

static void fake_sched_unlock(unsigned long thread_addr)
{
	if (!thread_addr)
		exit(97);
	sched_unlock_calls++;
}

static long fake_sched_copy_from(void *dst, unsigned long src,
				 unsigned long bytes)
{
	sched_copy_from_calls++;
	if (sched_copy_from_fail)
		return -1;
	memcpy(dst, (const void *)src, bytes);
	return 0;
}

static long fake_sched_copy_to(unsigned long dst, const void *src,
			       unsigned long bytes)
{
	sched_copy_to_calls++;
	if (sched_copy_to_fail || dst == 0)
		return -1;
	memcpy((void *)dst, src, bytes);
	return 0;
}

static long fake_sched_syscall2(int syscall_nr, unsigned long arg0,
				unsigned long arg1)
{
	sched_syscall_calls++;
	sched_syscall_nr = syscall_nr;
	sched_syscall_arg0 = arg0;
	sched_syscall_arg1 = arg1;
	return sched_syscall_ret;
}

static int fake_sched_apply(unsigned long thread_addr, int policy,
			    unsigned long param_addr)
{
	struct fake_sched_thread *thread = (struct fake_sched_thread *)thread_addr;
	struct fake_sched_param *param = (struct fake_sched_param *)param_addr;
	int ret;

	sched_apply_calls++;
	sched_apply_policy = policy;
	sched_apply_thread = thread_addr;
	ret = setscheduler_validate(policy, param->sched_priority);
	if (ret)
		return ret;
	thread->sched_param = *param;
	thread->sched_policy = policy;
	return 0;
}

static int fake_sched_hold(unsigned long thread_addr)
{
	if (!thread_addr)
		exit(96);
	sched_hold_calls++;
	return 0;
}

static void fake_sched_release(unsigned long thread_addr)
{
	if (!thread_addr)
		exit(95);
	sched_release_calls++;
}

static void fake_sched_migrate(int cpu_id, unsigned long thread_addr)
{
	sched_migrate_calls++;
	sched_migrate_cpu = cpu_id;
	sched_migrate_thread = thread_addr;
}

static void fake_sched_cpuset_zero(unsigned long *set)
{
	for (int i = 0; i < SCHED_FAKE_CPU_WORDS; i++)
		set[i] = 0;
}

static void fake_sched_cpuset_set(unsigned long *set, int cpu)
{
	set[cpu / (int)(8 * sizeof(unsigned long))] |=
		1UL << (cpu % (int)(8 * sizeof(unsigned long)));
}

static int fake_sched_cpuset_isset(const unsigned long *set, int cpu)
{
	return !!(set[cpu / (int)(8 * sizeof(unsigned long))] &
		(1UL << (cpu % (int)(8 * sizeof(unsigned long)))));
}

struct fake_futex_bucket {
	unsigned long pad;
	unsigned long lock;
};

struct fake_wake_body_bucket {
	unsigned long pad;
	unsigned long lock;
	struct plist_head chain;
};

struct fake_futex_table_bucket {
	unsigned long prefix;
	unsigned int lock_word;
	unsigned int lock_guard;
	struct plist_head chain;
	unsigned long debug_spinlock;
	unsigned long debug_rawlock;
	unsigned long suffix;
};

struct fake_queue_me_process {
	unsigned long prefix;
	int status;
	unsigned long update_lock;
};

struct fake_queue_me_thread {
	unsigned long prefix;
	int spin_sleep;
	int status;
	unsigned long spin_sleep_lock;
	struct fake_queue_me_process *proc;
	int cpu_id;
};

extern void plist_add(struct plist_node *, struct plist_head *);

#define container_of(ptr, type, member) \
	((type *)((char *)(ptr) - offsetof(type, member)))
#define plist_from_node(ptr) container_of(ptr, struct plist_node, plist.node_list)
#define plist_from_prio(ptr) container_of(ptr, struct plist_node, plist.prio_list)

static void init_list_head(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

static void plist_head_init(struct plist_head *head)
{
	init_list_head(&head->prio_list);
	init_list_head(&head->node_list);
}

static void plist_node_init(struct plist_node *node, int prio)
{
	node->prio = prio;
	plist_head_init(&node->plist);
}

static int plist_node_empty(const struct plist_node *node)
{
	return node->plist.node_list.next == &node->plist.node_list;
}

static void require(int condition)
{
	if (!condition)
		exit(13);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

	static void mix_signed(unsigned long *digest, long value)
	{
		mix(digest, (unsigned long)value);
	}

static int futex_op_expected(int op, int oparg, int cmp, int cmparg)
{
	unsigned int encoded = (((unsigned int)op & 0x0f) << 28) |
		(((unsigned int)cmp & 0x0f) << 24) |
		(((unsigned int)oparg & 0x0fff) << 12) |
		((unsigned int)cmparg & 0x0fff);

	return (int)encoded;
}

static unsigned long futex_op_digest(void)
{
	static const int cases[][4] = {
		{ 0, 0, 1, 0 },
		{ FUTEX_WAKE_OP, 0x123, FUTEX_WAIT_BITSET, 0x456 },
		{ 0x1f, 0x1abc, 0x15, 0x2def },
		{ -1, -2, -3, -4 },
	};
	unsigned long digest = 0x66757465786f7021UL;

	for (unsigned int i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
		int actual = FUTEX_OP(cases[i][0], cases[i][1],
				      cases[i][2], cases[i][3]);
		int expected = futex_op_expected(cases[i][0], cases[i][1],
						 cases[i][2], cases[i][3]);

		require(actual == expected);
		mix_signed(&digest, actual);
	}

	return digest;
}

static unsigned long futex_value_load_digest(void)
{
	unsigned int source = 0x11223344U;
	unsigned int dest = 0;
	unsigned long digest = 0x66757465786c6f64UL;
	int ret;

	ret = get_futex_value_locked(&dest, &source);
	require(ret == 0);
	require(dest == 0x11223344U);
	mix(&digest, dest);
	source = 0x55667788U;
	ret = get_futex_value_locked(&dest, &source);
	require(ret == 0);
	require(dest == 0x55667788U);
	mix(&digest, dest);

	return digest;
}

static unsigned long mc_jhash2_digest(void)
{
	static const unsigned int data[] = {
		0x00000000U, 0x01234567U, 0x89abcdefU, 0xffffffffU,
		0x13579bdfU, 0x2468ace0U, 0xdeadbeefU
	};
	static const unsigned int lengths[] = { 0, 1, 2, 3, 4, 7 };
	unsigned long digest = 0x6a68617368322121UL;

	for (unsigned int i = 0; i < sizeof(lengths) / sizeof(lengths[0]); i++) {
		unsigned int hash = mc_jhash2(data, lengths[i],
					      0xa5a50000U + lengths[i]);

		mix(&digest, hash);
	}

	return digest;
}

	#define PS_RUNNING 0x1

	struct fake_timer_thread {
		int status;
		struct list_head sched_list;
		unsigned long spin_sleep_lock;
		int spin_sleep;
		int itimer_enabled;
	};

	struct fake_timer_cpu {
		unsigned long runq_lock;
		struct list_head runq;
		size_t runq_len;
		struct fake_timer_thread *current;
		int timer_enabled;
		struct list_head backlog_list;
	};

	struct fake_timer {
		unsigned long timeout;
		unsigned long waitq;
		struct list_head list;
		struct fake_timer_thread *thread;
	};

	static const struct timer_runtime_offsets fake_timer_offsets = {
		.thread_status_offset = offsetof(struct fake_timer_thread, status),
		.thread_sched_list_offset =
			offsetof(struct fake_timer_thread, sched_list),
		.thread_spin_sleep_lock_offset =
			offsetof(struct fake_timer_thread, spin_sleep_lock),
		.thread_spin_sleep_offset =
			offsetof(struct fake_timer_thread, spin_sleep),
		.thread_itimer_enabled_offset =
			offsetof(struct fake_timer_thread, itimer_enabled),
		.cpu_runq_lock_offset = offsetof(struct fake_timer_cpu, runq_lock),
		.cpu_runq_offset = offsetof(struct fake_timer_cpu, runq),
		.cpu_runq_len_offset = offsetof(struct fake_timer_cpu, runq_len),
		.cpu_current_offset = offsetof(struct fake_timer_cpu, current),
		.cpu_timer_enabled_offset =
			offsetof(struct fake_timer_cpu, timer_enabled),
		.cpu_backlog_list_offset =
			offsetof(struct fake_timer_cpu, backlog_list),
		.timer_timeout_offset = offsetof(struct fake_timer, timeout),
		.timer_waitq_offset = offsetof(struct fake_timer, waitq),
		.timer_list_offset = offsetof(struct fake_timer, list),
		.timer_thread_offset = offsetof(struct fake_timer, thread),
	};

	static int timer_spin_init_calls;
	static int timer_lock_calls;
	static int timer_unlock_calls;
	static int timer_status_calls;
	static int timer_schedule_calls;
	static int timer_zero_free_calls;
	static int timer_pause_calls;
	static int timer_enable_calls;
	static int timer_disable_calls;
	static int timer_wake_calls;
	static int timer_log_calls;
	static unsigned int timer_last_enable_clocks;
	static unsigned long timer_last_wake_addr;
	static unsigned long timer_last_log_timer;
	static unsigned long timer_last_log_thread;
	static unsigned long timer_rdtsc_value;
	static unsigned long timer_rdtsc_step;
	static int timer_rdtsc_calls;
	static struct fake_timer_cpu *timer_schedule_cpu;
	static struct fake_timer_thread *timer_schedule_thread;

	static void reset_timer_trace(void)
	{
		timer_spin_init_calls = 0;
		timer_lock_calls = 0;
		timer_unlock_calls = 0;
		timer_status_calls = 0;
		timer_schedule_calls = 0;
		timer_zero_free_calls = 0;
		timer_pause_calls = 0;
		timer_enable_calls = 0;
		timer_disable_calls = 0;
		timer_wake_calls = 0;
		timer_log_calls = 0;
		timer_last_enable_clocks = 0;
		timer_last_wake_addr = 0;
		timer_last_log_timer = 0;
		timer_last_log_thread = 0;
		timer_rdtsc_value = 0;
		timer_rdtsc_step = 1;
		timer_rdtsc_calls = 0;
		timer_schedule_cpu = NULL;
		timer_schedule_thread = NULL;
	}

	static void list_add_tail_local(struct list_head *entry,
					struct list_head *head)
	{
		entry->next = head;
		entry->prev = head->prev;
		head->prev->next = entry;
		head->prev = entry;
	}

	static int list_empty_local(const struct list_head *head)
	{
		return head->next == head && head->prev == head;
	}

	struct fake_sched_waitq {
		int initialized;
		int prepared;
		int finished;
		int wakeups;
		unsigned long entry;
		int status;
	};

	struct fake_migrate_request {
		struct list_head list;
		struct fake_sched_thread *thread;
		struct fake_sched_waitq wq;
	};

	struct fake_migrate_cpu {
		unsigned long migq_lock;
		struct list_head migq;
		unsigned long runq_lock;
		struct list_head runq;
		unsigned long runq_len;
		unsigned int flags;
		int status;
	};

		struct fake_runq_proc {
			int pid;
			int status;
			unsigned long update_lock;
			int clone_count;
		};

	struct fake_runq_sigcommon {
		struct list_head sigpending;
	};

	struct fake_runq_thread {
		int cpu_id;
		int tid;
		int status;
		unsigned long spin_sleep_lock;
		int spin_sleep;
		struct list_head sched_list;
		struct list_head sigpending;
		struct fake_runq_sigcommon *sigcommon;
		struct fake_runq_proc *proc;
		int mod_clone;
	};

	struct fake_runq_cpu {
		unsigned long runq_lock;
		unsigned long runq_irqstate;
		struct fake_runq_thread *current;
		int prevpid;
		struct list_head runq;
		unsigned long runq_len;
		unsigned long runq_reserved;
		unsigned int flags;
		int status;
		int in_interrupt;
		unsigned long nr_ctx_switches;
	};

	static const struct sched_migrate_offsets fake_sched_migrate_offsets = {
		.req_list_offset = offsetof(struct fake_migrate_request, list),
		.req_thread_offset = offsetof(struct fake_migrate_request, thread),
		.req_wq_offset = offsetof(struct fake_migrate_request, wq),
		.thread_cpu_id_offset =
			offsetof(struct fake_sched_thread, cpu_id),
		.thread_tid_offset = offsetof(struct fake_sched_thread, tid),
		.cpu_migq_lock_offset =
			offsetof(struct fake_migrate_cpu, migq_lock),
		.cpu_migq_offset = offsetof(struct fake_migrate_cpu, migq),
		.cpu_runq_lock_offset =
			offsetof(struct fake_migrate_cpu, runq_lock),
		.cpu_flags_offset = offsetof(struct fake_migrate_cpu, flags),
		.cpu_status_offset = offsetof(struct fake_migrate_cpu, status),
	};

	static const struct sched_do_migrate_offsets fake_sched_do_migrate_offsets = {
		.req_list_offset = offsetof(struct fake_migrate_request, list),
		.req_thread_offset = offsetof(struct fake_migrate_request, thread),
		.req_wq_offset = offsetof(struct fake_migrate_request, wq),
		.thread_cpu_id_offset =
			offsetof(struct fake_sched_thread, cpu_id),
		.thread_tid_offset = offsetof(struct fake_sched_thread, tid),
		.thread_cpu_set_offset =
			offsetof(struct fake_sched_thread, cpu_set),
		.thread_sched_list_offset =
			offsetof(struct fake_sched_thread, sched_list),
		.thread_vm_offset = offsetof(struct fake_sched_thread, vm),
		.vm_address_space_offset =
			offsetof(struct fake_sched_vm, address_space),
		.address_space_cpu_set_offset =
			offsetof(struct fake_sched_address_space, cpu_set),
		.address_space_cpu_set_lock_offset =
			offsetof(struct fake_sched_address_space, cpu_set_lock),
		.cpu_migq_lock_offset =
			offsetof(struct fake_migrate_cpu, migq_lock),
		.cpu_migq_offset = offsetof(struct fake_migrate_cpu, migq),
		.cpu_runq_lock_offset =
			offsetof(struct fake_migrate_cpu, runq_lock),
		.cpu_runq_offset = offsetof(struct fake_migrate_cpu, runq),
		.cpu_runq_len_offset =
			offsetof(struct fake_migrate_cpu, runq_len),
		.cpu_flags_offset = offsetof(struct fake_migrate_cpu, flags),
	};

	static const struct sched_runqueue_offsets fake_sched_runqueue_offsets = {
		.thread_cpu_id_offset = offsetof(struct fake_runq_thread, cpu_id),
		.thread_tid_offset = offsetof(struct fake_runq_thread, tid),
		.thread_status_offset = offsetof(struct fake_runq_thread, status),
		.thread_spin_sleep_lock_offset =
			offsetof(struct fake_runq_thread, spin_sleep_lock),
		.thread_spin_sleep_offset =
			offsetof(struct fake_runq_thread, spin_sleep),
		.thread_sched_list_offset =
			offsetof(struct fake_runq_thread, sched_list),
		.thread_sigpending_offset =
			offsetof(struct fake_runq_thread, sigpending),
		.thread_sigcommon_offset =
			offsetof(struct fake_runq_thread, sigcommon),
		.sigcommon_sigpending_offset =
			offsetof(struct fake_runq_sigcommon, sigpending),
		.thread_proc_offset = offsetof(struct fake_runq_thread, proc),
		.thread_mod_clone_offset =
			offsetof(struct fake_runq_thread, mod_clone),
		.proc_pid_offset = offsetof(struct fake_runq_proc, pid),
			.proc_status_offset = offsetof(struct fake_runq_proc, status),
			.proc_update_lock_offset =
				offsetof(struct fake_runq_proc, update_lock),
			.proc_clone_count_offset =
				offsetof(struct fake_runq_proc, clone_count),
			.cpu_runq_lock_offset = offsetof(struct fake_runq_cpu, runq_lock),
		.cpu_runq_irqstate_offset =
			offsetof(struct fake_runq_cpu, runq_irqstate),
		.cpu_current_offset = offsetof(struct fake_runq_cpu, current),
		.cpu_prevpid_offset = offsetof(struct fake_runq_cpu, prevpid),
		.cpu_runq_offset = offsetof(struct fake_runq_cpu, runq),
		.cpu_runq_len_offset = offsetof(struct fake_runq_cpu, runq_len),
		.cpu_runq_reserved_offset =
			offsetof(struct fake_runq_cpu, runq_reserved),
		.cpu_flags_offset = offsetof(struct fake_runq_cpu, flags),
		.cpu_status_offset = offsetof(struct fake_runq_cpu, status),
		.cpu_in_interrupt_offset =
			offsetof(struct fake_runq_cpu, in_interrupt),
		.cpu_nr_ctx_switches_offset =
			offsetof(struct fake_runq_cpu, nr_ctx_switches),
	};

	static int sched_migrate_body_order;
	static int sched_migrate_body_lock_calls;
	static int sched_migrate_body_unlock_calls;
	static int sched_migrate_body_noirq_lock_calls;
	static int sched_migrate_body_noirq_unlock_calls;
	static int sched_migrate_body_waitq_init_calls;
	static int sched_migrate_body_waitq_prepare_calls;
	static int sched_migrate_body_waitq_finish_calls;
	static int sched_migrate_body_vector_calls;
	static int sched_migrate_body_interrupt_calls;
	static int sched_migrate_body_schedule_calls;
	static int sched_migrate_body_log_calls;
	static int sched_migrate_body_lock_order;
	static int sched_migrate_body_waitq_init_order;
	static int sched_migrate_body_waitq_prepare_order;
	static int sched_migrate_body_noirq_lock_order;
	static int sched_migrate_body_noirq_unlock_order;
	static int sched_migrate_body_vector_order;
	static int sched_migrate_body_interrupt_order;
	static int sched_migrate_body_log_order;
	static int sched_migrate_body_unlock_order;
	static int sched_migrate_body_schedule_order;
	static int sched_migrate_body_finish_order;
	static unsigned long sched_migrate_body_lock_addr;
	static unsigned long sched_migrate_body_unlock_addr;
	static unsigned long sched_migrate_body_unlock_irqstate;
	static unsigned long sched_migrate_body_noirq_lock_addr;
	static unsigned long sched_migrate_body_noirq_unlock_addr;
	static unsigned long sched_migrate_body_waitq_addr;
	static unsigned long sched_migrate_body_entry_addr;
	static int sched_migrate_body_wait_status;
	static int sched_migrate_body_vector_key;
	static int sched_migrate_body_interrupt_cpu;
	static int sched_migrate_body_interrupt_vector;
	static unsigned long sched_migrate_body_log_thread;
	static int sched_migrate_body_log_tid;
	static int sched_migrate_body_log_cpu;

	static int sched_runq_lock_calls;
	static int sched_runq_unlock_calls;
	static int sched_runq_noirq_lock_calls;
	static int sched_runq_noirq_unlock_calls;
	static int sched_runq_rwlock_calls;
	static int sched_runq_rwunlock_calls;
	static int sched_runq_status_set_calls;
	static int sched_runq_set_timer_calls;
	static int sched_runq_schedule_calls;
	static int sched_runq_interrupt_calls;
	static int sched_runq_vector_calls;
	static int sched_runq_log_counts[16];
	static int sched_runq_procfs_calls;
	static int sched_runq_counter_inc_calls;
	static int sched_runq_counter_dec_calls;
	static int sched_runq_rusage_inc_calls;
	static int sched_runq_rusage_debug_calls;
	static int sched_runq_irq_save_calls;
	static int sched_runq_irq_restore_calls;
	static int sched_runq_zero_free_calls;
	static int sched_runq_pause_calls;
	static int sched_runq_has_signal_calls;
	static int sched_runq_has_signal_value;
	static int sched_runq_reset_cputime_calls;
	static struct fake_runq_thread *sched_runq_pause_wake_thread;
	static unsigned long sched_runq_last_lock_addr;
	static unsigned long sched_runq_last_unlock_addr;
	static unsigned long sched_runq_last_rwlock_addr;
	static unsigned long sched_runq_last_rwunlock_addr;
	static unsigned long sched_runq_last_status_addr;
	static int sched_runq_last_status_value;
	static int sched_runq_last_set_timer_runq_locked;
	static int sched_runq_last_interrupt_cpu;
	static int sched_runq_last_interrupt_vector;
	static int sched_runq_last_vector_key;
	static unsigned long sched_runq_last_procfs_thread;
	static unsigned long sched_runq_last_counter_addr;

	static void reset_sched_migrate_body_trace(void)
	{
		sched_migrate_body_order = 0;
		sched_migrate_body_lock_calls = 0;
		sched_migrate_body_unlock_calls = 0;
		sched_migrate_body_noirq_lock_calls = 0;
		sched_migrate_body_noirq_unlock_calls = 0;
		sched_migrate_body_waitq_init_calls = 0;
		sched_migrate_body_waitq_prepare_calls = 0;
		sched_migrate_body_waitq_finish_calls = 0;
		sched_migrate_body_vector_calls = 0;
		sched_migrate_body_interrupt_calls = 0;
		sched_migrate_body_schedule_calls = 0;
		sched_migrate_body_log_calls = 0;
		sched_migrate_body_lock_order = 0;
		sched_migrate_body_waitq_init_order = 0;
		sched_migrate_body_waitq_prepare_order = 0;
		sched_migrate_body_noirq_lock_order = 0;
		sched_migrate_body_noirq_unlock_order = 0;
		sched_migrate_body_vector_order = 0;
		sched_migrate_body_interrupt_order = 0;
		sched_migrate_body_log_order = 0;
		sched_migrate_body_unlock_order = 0;
		sched_migrate_body_schedule_order = 0;
		sched_migrate_body_finish_order = 0;
		sched_migrate_body_lock_addr = 0;
		sched_migrate_body_unlock_addr = 0;
		sched_migrate_body_unlock_irqstate = 0;
		sched_migrate_body_noirq_lock_addr = 0;
		sched_migrate_body_noirq_unlock_addr = 0;
		sched_migrate_body_waitq_addr = 0;
		sched_migrate_body_entry_addr = 0;
		sched_migrate_body_wait_status = 0;
		sched_migrate_body_vector_key = 0;
		sched_migrate_body_interrupt_cpu = -1;
		sched_migrate_body_interrupt_vector = 0;
		sched_migrate_body_log_thread = 0;
		sched_migrate_body_log_tid = 0;
		sched_migrate_body_log_cpu = -1;
	}

	static void reset_sched_runq_trace(void)
	{
		sched_runq_lock_calls = 0;
		sched_runq_unlock_calls = 0;
		sched_runq_noirq_lock_calls = 0;
		sched_runq_noirq_unlock_calls = 0;
		sched_runq_rwlock_calls = 0;
		sched_runq_rwunlock_calls = 0;
		sched_runq_status_set_calls = 0;
		sched_runq_set_timer_calls = 0;
		sched_runq_schedule_calls = 0;
		sched_runq_interrupt_calls = 0;
		sched_runq_vector_calls = 0;
		sched_runq_procfs_calls = 0;
		sched_runq_counter_inc_calls = 0;
		sched_runq_counter_dec_calls = 0;
		sched_runq_rusage_inc_calls = 0;
		sched_runq_rusage_debug_calls = 0;
		sched_runq_irq_save_calls = 0;
		sched_runq_irq_restore_calls = 0;
		sched_runq_zero_free_calls = 0;
		sched_runq_pause_calls = 0;
		sched_runq_has_signal_calls = 0;
		sched_runq_has_signal_value = 0;
		sched_runq_reset_cputime_calls = 0;
		sched_runq_pause_wake_thread = NULL;
		memset(sched_runq_log_counts, 0, sizeof(sched_runq_log_counts));
		sched_runq_last_lock_addr = 0;
		sched_runq_last_unlock_addr = 0;
		sched_runq_last_rwlock_addr = 0;
		sched_runq_last_rwunlock_addr = 0;
		sched_runq_last_status_addr = 0;
		sched_runq_last_status_value = 0;
		sched_runq_last_set_timer_runq_locked = -1;
		sched_runq_last_interrupt_cpu = -1;
		sched_runq_last_interrupt_vector = 0;
		sched_runq_last_vector_key = 0;
		sched_runq_last_procfs_thread = 0;
		sched_runq_last_counter_addr = 0;
	}

	static unsigned long fake_sched_runq_irq_save(void)
	{
		sched_runq_irq_save_calls++;
		return 0x9100UL + (unsigned long)sched_runq_irq_save_calls;
	}

	static void fake_sched_runq_irq_restore(unsigned long irqstate)
	{
		(void)irqstate;
		sched_runq_irq_restore_calls++;
	}

	static void fake_sched_runq_zero_free(void)
	{
		sched_runq_zero_free_calls++;
	}

	static void fake_sched_runq_pause(void)
	{
		sched_runq_pause_calls++;
		if (sched_runq_pause_wake_thread)
			sched_runq_pause_wake_thread->spin_sleep = 0;
	}

	static int fake_sched_runq_has_signal(unsigned long thread_addr)
	{
		(void)thread_addr;
		sched_runq_has_signal_calls++;
		return sched_runq_has_signal_value;
	}

	static unsigned long fake_sched_runq_lock(unsigned long lock_addr)
	{
		sched_runq_lock_calls++;
		sched_runq_last_lock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
		return 0x5100UL + (unsigned long)sched_runq_lock_calls;
	}

	static void fake_sched_runq_unlock(unsigned long lock_addr,
					   unsigned long irqstate)
	{
		sched_runq_unlock_calls++;
		sched_runq_last_unlock_addr = lock_addr;
		*(unsigned long *)lock_addr += (irqstate & 0xfUL) + 1;
	}

	static void fake_sched_runq_noirq_lock(unsigned long lock_addr)
	{
		sched_runq_noirq_lock_calls++;
		sched_runq_last_lock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
	}

	static void fake_sched_runq_noirq_unlock(unsigned long lock_addr)
	{
		sched_runq_noirq_unlock_calls++;
		sched_runq_last_unlock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
	}

	static void fake_sched_runq_rwlock(unsigned long lock_addr,
					   unsigned long node_addr)
	{
		require(node_addr != 0);
		sched_runq_rwlock_calls++;
		sched_runq_last_rwlock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
	}

	static void fake_sched_runq_rwunlock(unsigned long lock_addr,
					     unsigned long node_addr)
	{
		require(node_addr != 0);
		sched_runq_rwunlock_calls++;
		sched_runq_last_rwunlock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
	}

	static void fake_sched_runq_status_set(unsigned long status_addr,
					       int status)
	{
		sched_runq_status_set_calls++;
		sched_runq_last_status_addr = status_addr;
		sched_runq_last_status_value = status;
		*(int *)status_addr = status;
	}

	static void fake_sched_runq_set_timer(int runq_locked)
	{
		sched_runq_set_timer_calls++;
		sched_runq_last_set_timer_runq_locked = runq_locked;
	}

	static void fake_sched_runq_schedule(void)
	{
		sched_runq_schedule_calls++;
	}

	static void fake_sched_runq_reset_cputime(void)
	{
		sched_runq_reset_cputime_calls++;
	}

	static void fake_sched_runq_procfs_create(unsigned long thread_addr)
	{
		sched_runq_procfs_calls++;
		sched_runq_last_procfs_thread = thread_addr;
	}

	static int fake_sched_runq_counter_inc(unsigned long counter_addr)
	{
		sched_runq_counter_inc_calls++;
		sched_runq_last_counter_addr = counter_addr;
		return ++(*(int *)counter_addr);
	}

	static void fake_sched_runq_counter_dec(unsigned long counter_addr)
	{
		sched_runq_counter_dec_calls++;
		sched_runq_last_counter_addr = counter_addr;
		--(*(unsigned long *)counter_addr);
	}

	static void fake_sched_runq_rusage_inc(void)
	{
		sched_runq_rusage_inc_calls++;
	}

	static void fake_sched_runq_rusage_debug(void)
	{
		sched_runq_rusage_debug_calls++;
	}

	static int fake_sched_runq_vector(int vector_key)
	{
		sched_runq_vector_calls++;
		sched_runq_last_vector_key = vector_key;
		return vector_key + 40;
	}

	static void fake_sched_runq_interrupt(int cpu, int vector)
	{
		sched_runq_interrupt_calls++;
		sched_runq_last_interrupt_cpu = cpu;
		sched_runq_last_interrupt_vector = vector;
	}

	static void fake_sched_runq_log(int event, unsigned long arg0,
					unsigned long arg1, int arg2, int arg3)
	{
		if (event >= 0 && event < (int)(sizeof(sched_runq_log_counts) /
				sizeof(sched_runq_log_counts[0])))
			sched_runq_log_counts[event]++;
		mix((unsigned long *)&sched_runq_last_unlock_addr, arg0 ^ arg1);
		sched_runq_last_status_value ^= arg2 ^ arg3;
	}

	static unsigned long fake_sched_migrate_body_lock(unsigned long lock_addr)
	{
		sched_migrate_body_lock_calls++;
		sched_migrate_body_lock_order = ++sched_migrate_body_order;
		sched_migrate_body_lock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
		return 0xabc000UL + (unsigned long)sched_migrate_body_lock_calls;
	}

	static void fake_sched_migrate_body_unlock(unsigned long lock_addr,
						   unsigned long irqstate)
	{
		sched_migrate_body_unlock_calls++;
		sched_migrate_body_unlock_order = ++sched_migrate_body_order;
		sched_migrate_body_unlock_addr = lock_addr;
		sched_migrate_body_unlock_irqstate = irqstate;
		*(unsigned long *)lock_addr += 7;
	}

	static void fake_sched_migrate_body_noirq_lock(unsigned long lock_addr)
	{
		sched_migrate_body_noirq_lock_calls++;
		sched_migrate_body_noirq_lock_order = ++sched_migrate_body_order;
		sched_migrate_body_noirq_lock_addr = lock_addr;
		(*(unsigned long *)lock_addr)++;
	}

	static void fake_sched_migrate_body_noirq_unlock(unsigned long lock_addr)
	{
		sched_migrate_body_noirq_unlock_calls++;
		sched_migrate_body_noirq_unlock_order = ++sched_migrate_body_order;
		sched_migrate_body_noirq_unlock_addr = lock_addr;
		*(unsigned long *)lock_addr += 3;
	}

	static void fake_sched_migrate_body_waitq_init(unsigned long waitq_addr)
	{
		struct fake_sched_waitq *wq =
			(struct fake_sched_waitq *)waitq_addr;

		sched_migrate_body_waitq_init_calls++;
		sched_migrate_body_waitq_init_order = ++sched_migrate_body_order;
		sched_migrate_body_waitq_addr = waitq_addr;
		memset(wq, 0, sizeof(*wq));
		wq->initialized = 1;
	}

	static void fake_sched_migrate_body_waitq_prepare(
		unsigned long waitq_addr, unsigned long entry_addr, int status)
	{
		struct fake_sched_waitq *wq =
			(struct fake_sched_waitq *)waitq_addr;

		require(wq->initialized == 1);
		sched_migrate_body_waitq_prepare_calls++;
		sched_migrate_body_waitq_prepare_order =
			++sched_migrate_body_order;
		sched_migrate_body_waitq_addr = waitq_addr;
		sched_migrate_body_entry_addr = entry_addr;
		sched_migrate_body_wait_status = status;
		wq->prepared = 1;
		wq->entry = entry_addr;
		wq->status = status;
	}

	static void fake_sched_migrate_body_waitq_finish(
		unsigned long waitq_addr, unsigned long entry_addr)
	{
		struct fake_sched_waitq *wq =
			(struct fake_sched_waitq *)waitq_addr;

		require(wq->prepared == 1);
		sched_migrate_body_waitq_finish_calls++;
		sched_migrate_body_finish_order = ++sched_migrate_body_order;
		sched_migrate_body_waitq_addr = waitq_addr;
		sched_migrate_body_entry_addr = entry_addr;
		wq->finished = 1;
	}

	static int fake_sched_migrate_body_vector(int vector_key)
	{
		sched_migrate_body_vector_calls++;
		sched_migrate_body_vector_order = ++sched_migrate_body_order;
		sched_migrate_body_vector_key = vector_key;
		return vector_key + 2000;
	}

	static void fake_sched_migrate_body_interrupt(int cpu, int vector)
	{
		sched_migrate_body_interrupt_calls++;
		sched_migrate_body_interrupt_order = ++sched_migrate_body_order;
		sched_migrate_body_interrupt_cpu = cpu;
		sched_migrate_body_interrupt_vector = vector;
	}

	static void fake_sched_migrate_body_schedule(void)
	{
		sched_migrate_body_schedule_calls++;
		sched_migrate_body_schedule_order = ++sched_migrate_body_order;
	}

	static void fake_sched_migrate_body_log(unsigned long thread_addr,
						int tid, int cpu_id)
	{
		sched_migrate_body_log_calls++;
		sched_migrate_body_log_order = ++sched_migrate_body_order;
		sched_migrate_body_log_thread = thread_addr;
		sched_migrate_body_log_tid = tid;
		sched_migrate_body_log_cpu = cpu_id;
	}

	static struct fake_migrate_cpu *sched_do_migrate_cpus[8];
	static int sched_do_migrate_cpu_local_calls;
	static int sched_do_migrate_cpu_local_cpu;
	static int sched_do_migrate_wake_calls;
	static unsigned long sched_do_migrate_last_waitq;
	static int sched_do_migrate_log_calls;
	static unsigned long sched_do_migrate_log_thread;
	static int sched_do_migrate_log_tid;
	static int sched_do_migrate_log_old_cpu;
	static int sched_do_migrate_log_new_cpu;

	static void reset_sched_do_migrate_trace(void)
	{
		reset_sched_migrate_body_trace();
		memset(sched_do_migrate_cpus, 0, sizeof(sched_do_migrate_cpus));
		sched_do_migrate_cpu_local_calls = 0;
		sched_do_migrate_cpu_local_cpu = -1;
		sched_do_migrate_wake_calls = 0;
		sched_do_migrate_last_waitq = 0;
		sched_do_migrate_log_calls = 0;
		sched_do_migrate_log_thread = 0;
		sched_do_migrate_log_tid = 0;
		sched_do_migrate_log_old_cpu = -1;
		sched_do_migrate_log_new_cpu = -1;
	}

	static unsigned long fake_sched_do_migrate_cpu_local(int cpu_id)
	{
		sched_do_migrate_cpu_local_calls++;
		sched_do_migrate_cpu_local_cpu = cpu_id;
		if (cpu_id < 0 || cpu_id >= (int)(sizeof(sched_do_migrate_cpus) /
				sizeof(sched_do_migrate_cpus[0])))
			return 0;
		return (unsigned long)sched_do_migrate_cpus[cpu_id];
	}

	static void fake_sched_do_migrate_waitq_wakeup(unsigned long waitq_addr)
	{
		struct fake_sched_waitq *wq =
			(struct fake_sched_waitq *)waitq_addr;

		sched_do_migrate_wake_calls++;
		sched_do_migrate_last_waitq = waitq_addr;
		wq->wakeups++;
	}

	static void fake_sched_do_migrate_log(unsigned long thread_addr,
					      int tid, int old_cpu_id,
					      int new_cpu_id)
	{
		sched_do_migrate_log_calls++;
		sched_do_migrate_log_thread = thread_addr;
		sched_do_migrate_log_tid = tid;
		sched_do_migrate_log_old_cpu = old_cpu_id;
		sched_do_migrate_log_new_cpu = new_cpu_id;
	}

	static void fake_timer_thread_init(struct fake_timer_thread *thread,
					   int status, int spin_sleep,
					   int itimer_enabled)
	{
		memset(thread, 0, sizeof(*thread));
		thread->status = status;
		thread->spin_sleep = spin_sleep;
		thread->itimer_enabled = itimer_enabled;
		init_list_head(&thread->sched_list);
	}

	static void fake_timer_cpu_init(struct fake_timer_cpu *cpu,
					struct fake_timer_thread *current)
	{
		memset(cpu, 0, sizeof(*cpu));
		init_list_head(&cpu->runq);
		init_list_head(&cpu->backlog_list);
		cpu->current = current;
	}

	static void fake_timer_init(struct fake_timer *timer,
				    struct fake_timer_thread *thread,
				    unsigned long timeout)
	{
		memset(timer, 0, sizeof(*timer));
		timer->timeout = timeout;
		timer->thread = thread;
		init_list_head(&timer->list);
	}

	static void fake_runq_cpu_init(struct fake_runq_cpu *cpu)
	{
		memset(cpu, 0, sizeof(*cpu));
		init_list_head(&cpu->runq);
	}

	static void fake_runq_thread_init(struct fake_runq_thread *thread,
					  struct fake_runq_proc *proc, int tid,
					  int cpu_id, int status, int spin_sleep)
	{
		memset(thread, 0, sizeof(*thread));
		thread->proc = proc;
		thread->tid = tid;
		thread->cpu_id = cpu_id;
		thread->status = status;
		thread->spin_sleep = spin_sleep;
		init_list_head(&thread->sched_list);
		init_list_head(&thread->sigpending);
	}

	static void fake_timer_spin_init(unsigned long lock_addr)
	{
		timer_spin_init_calls++;
		*(unsigned long *)lock_addr = 0x51515151UL;
	}

	static unsigned long fake_timer_lock(unsigned long lock_addr)
	{
		timer_lock_calls++;
		(*(unsigned long *)lock_addr)++;
		return 0x7000UL + (unsigned long)timer_lock_calls;
	}

	static void fake_timer_unlock(unsigned long lock_addr,
				      unsigned long irqstate)
	{
		timer_unlock_calls++;
		*(unsigned long *)lock_addr += (irqstate & 0xfUL) + 1;
	}

	static unsigned long fake_timer_rdtsc(void)
	{
		timer_rdtsc_calls++;
		timer_rdtsc_value += timer_rdtsc_step;
		return timer_rdtsc_value;
	}

	static void fake_timer_set_status(unsigned long status_addr, int status)
	{
		timer_status_calls++;
		*(int *)status_addr = status;
	}

	static void fake_timer_schedule(void)
	{
		timer_schedule_calls++;
		if (timer_schedule_cpu)
			timer_schedule_cpu->runq_len = 1;
		if (timer_schedule_thread)
			timer_schedule_thread->spin_sleep = 0;
	}

	static void fake_timer_zero_free(void)
	{
		timer_zero_free_calls++;
	}

	static void fake_timer_pause(void)
	{
		timer_pause_calls++;
	}

	static void fake_timer_enable(unsigned int clocks)
	{
		timer_enable_calls++;
		timer_last_enable_clocks = clocks;
	}

	static void fake_timer_disable(void)
	{
		timer_disable_calls++;
	}

	static void fake_timer_wake(unsigned long waitq_addr)
	{
		timer_wake_calls++;
		timer_last_wake_addr = waitq_addr;
	}

	static void fake_timer_log(unsigned long timer_addr,
				   unsigned long thread_addr)
	{
		timer_log_calls++;
		timer_last_log_timer = timer_addr;
		timer_last_log_thread = thread_addr;
	}

	static int call_sched_spin_sleep(struct fake_runq_thread *thread,
					 struct fake_runq_cpu *cpu,
					 int current_cpu_id,
					 int idle_halt_enabled)
	{
		return sched_spin_sleep_or_schedule_body_result(
			(unsigned long)thread, (unsigned long)cpu, current_cpu_id,
			idle_halt_enabled, SCHED_CPU_FLAG_NEED_RESCHED,
			&fake_sched_runqueue_offsets, fake_sched_runq_irq_save,
			fake_sched_runq_irq_restore, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_noirq_lock,
			fake_sched_runq_noirq_unlock, fake_sched_runq_schedule,
			fake_sched_runq_zero_free, fake_sched_runq_pause,
			fake_sched_runq_has_signal, fake_sched_runq_log);
	}

	static int call_sched_schedule_prepare(struct fake_runq_cpu *cpu,
					       struct fake_runq_thread *idle,
					       int no_preempt_count,
					       struct sched_schedule_result *result)
	{
		return sched_schedule_prepare_body_result(
			(unsigned long)cpu, (unsigned long)idle,
			no_preempt_count, SCHED_CPU_FLAG_NEED_RESCHED,
			SCHED_CPU_FLAG_NEED_MIGRATE, SCHED_PS_RUNNING,
			SCHED_PS_INTERRUPTIBLE, SCHED_PS_EXITED,
			1001, SCHED_CPU_STATUS_IDLE,
			SCHED_CPU_STATUS_RESERVED, &fake_sched_runqueue_offsets,
			result, fake_sched_runq_irq_save,
			fake_sched_runq_irq_restore,
			fake_sched_runq_noirq_lock,
			fake_sched_runq_noirq_unlock,
			fake_sched_runq_set_timer,
			fake_sched_runq_reset_cputime,
			fake_sched_runq_has_signal,
			fake_sched_runq_log);
	}

	static unsigned long timer_runtime_body_digest(void)
	{
		struct list_head timers;
		struct fake_timer_cpu cpu;
		struct fake_timer_thread thread;
		struct fake_timer_thread second;
		struct fake_timer_thread expired_thread;
		struct fake_timer keep_timer;
		struct fake_timer expire_timer;
		struct list_head backlog;
		unsigned long lock = 0;
		unsigned long digest = 0x74696d657272756eUL;
		unsigned long ret;
		int rc;

		init_list_head(&timers);
		reset_timer_trace();
		rc = timer_init_timers_result((unsigned long)&lock,
			(unsigned long)&timers, fake_timer_spin_init);
		require(rc == 0);
		require(lock == 0x51515151UL);
		require(list_empty_local(&timers));
		mix_signed(&digest, rc);
		mix(&digest, lock);
		mix_signed(&digest, timer_spin_init_calls);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 0, 0);
		fake_timer_cpu_init(&cpu, &thread);
		cpu.runq_len = 1;
		timer_rdtsc_value = 900;
		timer_rdtsc_step = 100;
		ret = timer_schedule_timeout_body_result((unsigned long)&thread,
			(unsigned long)&cpu, 1000, 500, &fake_timer_offsets,
			fake_timer_rdtsc, fake_timer_lock, fake_timer_unlock,
			fake_timer_set_status, fake_timer_schedule,
			fake_timer_zero_free, fake_timer_pause);
		require(ret == 900);
		require(timer_schedule_calls == 0);
		require(timer_zero_free_calls == 0);
		require(timer_lock_calls == 1);
		require(timer_unlock_calls == 1);
		mix(&digest, ret);
		mix_signed(&digest, timer_rdtsc_calls);
		mix_signed(&digest, timer_lock_calls);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 1, 0);
		fake_timer_cpu_init(&cpu, &thread);
		cpu.runq_len = 2;
		timer_schedule_cpu = &cpu;
		timer_schedule_thread = &thread;
		timer_rdtsc_value = 900;
		timer_rdtsc_step = 100;
		ret = timer_schedule_timeout_body_result((unsigned long)&thread,
			(unsigned long)&cpu, 1000, 500, &fake_timer_offsets,
			fake_timer_rdtsc, fake_timer_lock, fake_timer_unlock,
			fake_timer_set_status, fake_timer_schedule,
			fake_timer_zero_free, fake_timer_pause);
		require(ret == 900);
		require(timer_schedule_calls == 1);
		require(timer_status_calls == 1);
		require(thread.status == PS_RUNNING);
		require(thread.spin_sleep == 0);
		mix(&digest, ret);
		mix_signed(&digest, timer_schedule_calls);
		mix_signed(&digest, thread.status);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 1, 0);
		fake_timer_cpu_init(&cpu, &thread);
		cpu.runq_len = 1;
		timer_rdtsc_value = 900;
		timer_rdtsc_step = 100;
		ret = timer_schedule_timeout_body_result((unsigned long)&thread,
			(unsigned long)&cpu, 500, 500, &fake_timer_offsets,
			fake_timer_rdtsc, fake_timer_lock, fake_timer_unlock,
			fake_timer_set_status, fake_timer_schedule,
			fake_timer_zero_free, fake_timer_pause);
		require(ret == 0);
		require(thread.spin_sleep == 0);
		require(timer_zero_free_calls == 4);
		require(timer_pause_calls == 4);
		mix(&digest, ret);
		mix_signed(&digest, timer_zero_free_calls);
		mix_signed(&digest, timer_pause_calls);

		reset_timer_trace();
		init_list_head(&timers);
		fake_timer_thread_init(&thread, 0, 0, 0);
		fake_timer_thread_init(&expired_thread, 0, 0, 0);
		fake_timer_init(&keep_timer, &thread, 1200);
		fake_timer_init(&expire_timer, &expired_thread, 900);
		list_add_tail_local(&keep_timer.list, &timers);
		list_add_tail_local(&expire_timer.list, &timers);
		rc = timer_wake_tick_result((unsigned long)&lock,
			(unsigned long)&timers, 500, &fake_timer_offsets,
			fake_timer_lock, fake_timer_unlock, fake_timer_wake,
			fake_timer_log);
		require(rc == 1);
		require(keep_timer.timeout == 700);
		require(expire_timer.timeout == 0);
		require(timers.next == &keep_timer.list);
		require(timers.prev == &keep_timer.list);
		require(keep_timer.list.next == &timers);
		require(keep_timer.list.prev == &timers);
		require(timer_wake_calls == 1);
		require(timer_log_calls == 1);
		require(timer_last_wake_addr == (unsigned long)&expire_timer.waitq);
		require(timer_last_log_timer == (unsigned long)&expire_timer);
		require(timer_last_log_thread == (unsigned long)&expired_thread);
		mix_signed(&digest, rc);
		mix(&digest, keep_timer.timeout);
		mix_signed(&digest, timer_wake_calls);
		mix_signed(&digest, timer_log_calls);

		reset_timer_trace();
		init_list_head(&timers);
		lock = 0;
		timer_rdtsc_value = 0;
		timer_rdtsc_step = 2;
		rc = timer_wake_loop_body_result((unsigned long)&lock,
			(unsigned long)&timers, 5, 2, &fake_timer_offsets,
			fake_timer_rdtsc, fake_timer_pause, fake_timer_lock,
			fake_timer_unlock, fake_timer_wake, fake_timer_log);
		require(rc == 2);
		require(timer_rdtsc_calls == 8);
		require(timer_pause_calls == 4);
		require(timer_lock_calls == 2);
		require(timer_unlock_calls == 2);
		require(timer_wake_calls == 0);
		require(timer_log_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, timer_rdtsc_calls);
		mix_signed(&digest, timer_pause_calls);
		mix(&digest, lock);

		reset_timer_trace();
		rc = timer_wake_loop_body_result((unsigned long)&lock,
			(unsigned long)&timers, 5, -1, &fake_timer_offsets,
			fake_timer_rdtsc, fake_timer_pause, fake_timer_lock,
			fake_timer_unlock, fake_timer_wake, fake_timer_log);
		require(rc == -22);
		require(timer_rdtsc_calls == 0);
		mix_signed(&digest, rc);

		reset_timer_trace();
		fake_timer_thread_init(&thread, PS_RUNNING, 0, 0);
		fake_timer_thread_init(&second, PS_RUNNING, 0, 0);
		fake_timer_cpu_init(&cpu, &thread);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		list_add_tail_local(&second.sched_list, &cpu.runq);
		rc = timer_set_timer_body_result((unsigned long)&cpu, 1, 0,
			&fake_timer_offsets, fake_timer_lock, fake_timer_unlock,
			fake_timer_enable, fake_timer_disable);
		require(rc == 2);
		require(cpu.timer_enabled == 1);
		require(timer_enable_calls == 1);
		require(timer_last_enable_clocks == 1000000U);
		require(timer_disable_calls == 0);
		require(timer_lock_calls == 1);
		require(timer_unlock_calls == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.timer_enabled);
		mix_signed(&digest, timer_enable_calls);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 0, 0);
		fake_timer_cpu_init(&cpu, &thread);
		cpu.timer_enabled = 1;
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		rc = timer_set_timer_body_result((unsigned long)&cpu, 1, 0,
			&fake_timer_offsets, fake_timer_lock, fake_timer_unlock,
			fake_timer_enable, fake_timer_disable);
		require(rc == 0);
		require(cpu.timer_enabled == 0);
		require(timer_enable_calls == 0);
		require(timer_disable_calls == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.timer_enabled);
		mix_signed(&digest, timer_disable_calls);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 0, 1);
		fake_timer_cpu_init(&cpu, &thread);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		rc = timer_set_timer_body_result((unsigned long)&cpu, 1, 1,
			&fake_timer_offsets, fake_timer_lock, fake_timer_unlock,
			fake_timer_enable, fake_timer_disable);
		require(rc == 0);
		require(cpu.timer_enabled == 1);
		require(timer_enable_calls == 1);
		require(timer_lock_calls == 0);
		require(timer_unlock_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.timer_enabled);
		mix_signed(&digest, timer_lock_calls);

		reset_timer_trace();
		fake_timer_thread_init(&thread, 0, 0, 0);
		fake_timer_cpu_init(&cpu, &thread);
		init_list_head(&backlog);
		list_add_tail_local(&backlog, &cpu.backlog_list);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		rc = timer_set_timer_body_result((unsigned long)&cpu, 1, 0,
			&fake_timer_offsets, fake_timer_lock, fake_timer_unlock,
			fake_timer_enable, fake_timer_disable);
		require(rc == 0);
		require(cpu.timer_enabled == 1);
		require(timer_enable_calls == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.timer_enabled);

		reset_timer_trace();
		fake_timer_thread_init(&thread, PS_RUNNING, 0, 0);
		fake_timer_cpu_init(&cpu, &thread);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		rc = timer_set_timer_body_result((unsigned long)&cpu, 0, 0,
			&fake_timer_offsets, fake_timer_lock, fake_timer_unlock,
			fake_timer_enable, fake_timer_disable);
		require(rc == 0);
		require(cpu.timer_enabled == 0);
		require(timer_lock_calls == 0);
		require(timer_enable_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, timer_lock_calls);
		mix_signed(&digest, timer_enable_calls);

		return digest;
	}

	static unsigned long sched_runqueue_body_digest(void)
	{
		struct fake_runq_cpu cpu;
		struct fake_runq_thread thread;
		struct fake_runq_thread second;
		struct fake_runq_thread third;
		struct fake_runq_thread idle;
		struct fake_runq_proc proc = {
			.pid = 4242,
			.status = 0x55,
			.update_lock = 0x9000,
		};
		struct fake_runq_proc second_proc = {
			.pid = 5151,
			.status = 0x66,
			.update_lock = 0x9100,
		};
		struct fake_runq_sigcommon sigcommon;
		struct list_head pending;
		struct sched_schedule_result sched_result;
		unsigned long reservation_lock = 0x3300;
		unsigned long node = 0x7700;
		unsigned long digest = 0x72756e7175657565UL;
		int rc;

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		cpu.runq_reserved = 3;
		cpu.status = SCHED_CPU_STATUS_RUNNING;
		rc = sched_release_cpuid_body_result(1, (unsigned long)&cpu,
			(unsigned long)&reservation_lock, SCHED_CPU_STATUS_IDLE,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_noirq_lock,
			fake_sched_runq_noirq_unlock);
		require(rc == 0);
		require(cpu.status == SCHED_CPU_STATUS_IDLE);
		require(cpu.runq_reserved == 2);
		require(sched_runq_lock_calls == 1);
		require(sched_runq_noirq_lock_calls == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.runq_reserved);
		mix_signed(&digest, cpu.status);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		cpu.flags = SCHED_CPU_FLAG_NEED_RESCHED |
			SCHED_CPU_FLAG_NEED_MIGRATE | 0x80U;
		cpu.in_interrupt = 1;
		rc = sched_check_need_resched_body_result((unsigned long)&cpu,
			SCHED_CPU_FLAG_NEED_RESCHED, SCHED_CPU_FLAG_NEED_MIGRATE,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_schedule,
			fake_sched_runq_log);
		require(rc == 0);
		require(cpu.flags == (SCHED_CPU_FLAG_NEED_RESCHED |
			SCHED_CPU_FLAG_NEED_MIGRATE | 0x80U));
		require(sched_runq_schedule_calls == 0);
		require(sched_runq_log_counts[1] == 1);
		mix(&digest, cpu.flags);
		mix_signed(&digest, sched_runq_log_counts[1]);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		cpu.flags = SCHED_CPU_FLAG_NEED_RESCHED | 0x20U;
		rc = sched_check_need_resched_body_result((unsigned long)&cpu,
			SCHED_CPU_FLAG_NEED_RESCHED, SCHED_CPU_FLAG_NEED_MIGRATE,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_schedule,
			fake_sched_runq_log);
		require(rc == 1);
		require(cpu.flags == 0x20U);
		require(sched_runq_schedule_calls == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.flags);
		mix_signed(&digest, sched_runq_schedule_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 77, -1, 0, 0);
		rc = sched_runq_add_thread_locked_result((unsigned long)&thread,
			(unsigned long)&cpu, 2, SCHED_CPU_FLAG_NEED_RESCHED,
			SCHED_CPU_STATUS_RUNNING, &fake_sched_runqueue_offsets,
			fake_sched_runq_log);
		require(rc == 0);
		require(cpu.runq_len == 1);
		require(cpu.flags == SCHED_CPU_FLAG_NEED_RESCHED);
		require(cpu.status == SCHED_CPU_STATUS_RUNNING);
		require(thread.cpu_id == 2);
		require(cpu.runq.next == &thread.sched_list);
		require(sched_runq_log_counts[5] == 1);
		mix(&digest, cpu.runq_len);
		mix(&digest, cpu.flags);
		mix_signed(&digest, thread.cpu_id);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 91, -1, 0, 0);
		reservation_lock = 0x4400;
		cpu.runq_reserved = 4;
		proc.clone_count = 8;
		rc = sched_runq_add_thread_body_result((unsigned long)&thread,
			(unsigned long)&cpu, (unsigned long)&reservation_lock, 3, 1,
			SCHED_CPU_FLAG_NEED_RESCHED, SCHED_CPU_STATUS_RUNNING, 19,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_noirq_lock,
			fake_sched_runq_noirq_unlock, fake_sched_runq_counter_dec,
			fake_sched_runq_procfs_create, fake_sched_runq_counter_inc,
			fake_sched_runq_rusage_inc, fake_sched_runq_rusage_debug,
			fake_sched_runq_vector, fake_sched_runq_interrupt,
			fake_sched_runq_log);
		require(rc == 0);
		require(cpu.runq_len == 1);
		require(cpu.runq_reserved == 3);
		require(cpu.status == SCHED_CPU_STATUS_RUNNING);
		require(thread.cpu_id == 3);
		require(proc.clone_count == 9);
		require(sched_runq_lock_calls == 1);
		require(sched_runq_noirq_lock_calls == 1);
		require(sched_runq_noirq_unlock_calls == 1);
		require(sched_runq_unlock_calls == 1);
		require(sched_runq_procfs_calls == 1);
		require(sched_runq_counter_dec_calls == 1);
		require(sched_runq_counter_inc_calls == 1);
		require(sched_runq_rusage_inc_calls == 1);
		require(sched_runq_rusage_debug_calls == 1);
		require(sched_runq_vector_calls == 1);
		require(sched_runq_interrupt_calls == 1);
		require(sched_runq_last_interrupt_cpu == 3);
		require(sched_runq_last_interrupt_vector == 59);
		require(sched_runq_log_counts[5] == 1);
		require(sched_runq_log_counts[11] == 1);
		mix(&digest, cpu.runq_reserved);
		mix_signed(&digest, proc.clone_count);
		mix_signed(&digest, sched_runq_procfs_calls);
		mix_signed(&digest, sched_runq_counter_inc_calls);
		mix_signed(&digest, sched_runq_rusage_inc_calls);
		mix_signed(&digest, sched_runq_interrupt_calls);
		mix_signed(&digest, sched_runq_log_counts[11]);

		reset_sched_runq_trace();
		rc = sched_runq_del_thread_body_result((unsigned long)&thread,
			(unsigned long)&cpu, SCHED_CPU_STATUS_IDLE,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock);
		require(rc == 0);
		require(cpu.runq_len == 0);
		require(cpu.status == SCHED_CPU_STATUS_IDLE);
		require(sched_runq_lock_calls == 1);
		mix(&digest, cpu.runq_len);
		mix_signed(&digest, cpu.status);
		mix_signed(&digest, sched_runq_unlock_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 88, 0,
			SCHED_PS_UNINTERRUPTIBLE, 1);
		proc.status = 0;
		rc = sched_wakeup_thread_body_result((unsigned long)&thread,
			(unsigned long)&cpu, (unsigned long)&node, 0,
			SCHED_PS_UNINTERRUPTIBLE, 0, SCHED_PS_RUNNING,
			SCHED_PS_EXITED, SCHED_CPU_FLAG_NEED_RESCHED,
			SCHED_IHK_GV_IKC, &fake_sched_runqueue_offsets,
			fake_sched_runq_lock, fake_sched_runq_unlock,
			fake_sched_runq_rwlock, fake_sched_runq_rwunlock,
			fake_sched_runq_status_set, fake_sched_runq_set_timer,
			fake_sched_runq_vector, fake_sched_runq_interrupt,
			fake_sched_runq_log);
		require(rc == 0);
		require(thread.spin_sleep == 0);
		require(thread.status == SCHED_PS_RUNNING);
		require(proc.status == SCHED_PS_RUNNING);
		require(cpu.flags == SCHED_CPU_FLAG_NEED_RESCHED);
		require(sched_runq_set_timer_calls == 1);
		require(sched_runq_last_set_timer_runq_locked == 1);
		require(sched_runq_interrupt_calls == 0);
		require(sched_runq_log_counts[2] == 1);
		require(sched_runq_log_counts[3] == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, thread.status);
		mix_signed(&digest, proc.status);
		mix_signed(&digest, sched_runq_set_timer_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 89, 3,
			SCHED_PS_UNINTERRUPTIBLE, 0);
		rc = sched_wakeup_thread_body_result((unsigned long)&thread,
			(unsigned long)&cpu, (unsigned long)&node, 0,
			SCHED_PS_RUNNING, 1, SCHED_PS_RUNNING, SCHED_PS_EXITED,
			SCHED_CPU_FLAG_NEED_RESCHED, SCHED_IHK_GV_IKC,
			&fake_sched_runqueue_offsets, fake_sched_runq_lock,
			fake_sched_runq_unlock, fake_sched_runq_rwlock,
			fake_sched_runq_rwunlock, fake_sched_runq_status_set,
			fake_sched_runq_set_timer, fake_sched_runq_vector,
			fake_sched_runq_interrupt, fake_sched_runq_log);
		require(rc == -EINVAL);
		require(thread.status == SCHED_PS_UNINTERRUPTIBLE);
		require(cpu.flags == 0);
		require(sched_runq_interrupt_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, thread.status);
		mix_signed(&digest, sched_runq_interrupt_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&second, &proc, 90, 3,
			SCHED_PS_UNINTERRUPTIBLE, 0);
		rc = sched_wakeup_thread_body_result((unsigned long)&second,
			(unsigned long)&cpu, (unsigned long)&node, 0,
			SCHED_PS_UNINTERRUPTIBLE, 1, SCHED_PS_RUNNING,
			SCHED_PS_EXITED, SCHED_CPU_FLAG_NEED_RESCHED,
			SCHED_IHK_GV_IKC, &fake_sched_runqueue_offsets,
			fake_sched_runq_lock, fake_sched_runq_unlock,
			fake_sched_runq_rwlock, fake_sched_runq_rwunlock,
			fake_sched_runq_status_set, fake_sched_runq_set_timer,
			fake_sched_runq_vector, fake_sched_runq_interrupt,
			fake_sched_runq_log);
		require(rc == 0);
		require(second.status == SCHED_PS_RUNNING);
		require(sched_runq_set_timer_calls == 0);
		require(sched_runq_interrupt_calls == 1);
		require(sched_runq_last_interrupt_cpu == 3);
		require(sched_runq_last_interrupt_vector ==
			SCHED_IHK_GV_IKC + 40);
		require(sched_runq_log_counts[4] == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, second.status);
		mix_signed(&digest, sched_runq_last_interrupt_vector);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 91, 0, 0, 1);
		rc = call_sched_spin_sleep(&thread, &cpu, 0, 1);
		require(rc == 2);
		require(sched_runq_schedule_calls == 1);
		require(sched_runq_log_counts[6] == 1);
		require(sched_runq_log_counts[9] == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, sched_runq_schedule_calls);
		mix_signed(&digest, sched_runq_log_counts[6]);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 92, 0, 0, 0);
		cpu.runq_len = 1;
		rc = call_sched_spin_sleep(&thread, &cpu, 0, 0);
		require(rc == 1);
		require(sched_runq_schedule_calls == 0);
		require(sched_runq_zero_free_calls == 0);
		require(sched_runq_log_counts[7] == 1);
		require(sched_runq_log_counts[8] == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, sched_runq_log_counts[7]);
		mix_signed(&digest, sched_runq_log_counts[8]);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 93, 0, 0, 1);
		cpu.runq_len = 1;
		cpu.flags = SCHED_CPU_FLAG_NEED_RESCHED | 0x40U;
		rc = call_sched_spin_sleep(&thread, &cpu, 0, 0);
		require(rc == 2);
		require(thread.spin_sleep == 0);
		require(cpu.flags == 0x40U);
		require(sched_runq_schedule_calls == 1);
		require(sched_runq_log_counts[9] == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.flags);
		mix_signed(&digest, sched_runq_schedule_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		init_list_head(&sigcommon.sigpending);
		init_list_head(&pending);
		list_add_tail_local(&pending, &sigcommon.sigpending);
		fake_runq_thread_init(&thread, &proc, 94, 0, 0, 1);
		thread.sigcommon = &sigcommon;
		cpu.runq_len = 1;
		cpu.flags = SCHED_CPU_FLAG_NEED_RESCHED;
		sched_runq_has_signal_value = 1;
		rc = call_sched_spin_sleep(&thread, &cpu, 0, 0);
		require(rc == 1);
		require(thread.spin_sleep == 0);
		require(cpu.flags == SCHED_CPU_FLAG_NEED_RESCHED);
		require(sched_runq_schedule_calls == 0);
		require(sched_runq_has_signal_calls == 1);
		require(sched_runq_log_counts[8] == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.flags);
		mix_signed(&digest, sched_runq_has_signal_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 95, 0, 0, 1);
		cpu.runq_len = 1;
		sched_runq_pause_wake_thread = &thread;
		rc = call_sched_spin_sleep(&thread, &cpu, 0, 0);
		require(rc == 1);
		require(thread.spin_sleep == 0);
		require(sched_runq_zero_free_calls == 1);
		require(sched_runq_pause_calls == 1);
		require(sched_runq_schedule_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, sched_runq_zero_free_calls);
		mix_signed(&digest, sched_runq_pause_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		cpu.flags = 0x20U;
		rc = call_sched_schedule_prepare(&cpu, &idle, 3,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_RESCHED_ONLY);
		require(sched_result.action ==
			SCHED_SCHEDULE_ACTION_RESCHED_ONLY);
		require(cpu.flags == (0x20U | SCHED_CPU_FLAG_NEED_RESCHED));
		require(sched_runq_irq_save_calls == 1);
		require(sched_runq_irq_restore_calls == 1);
		require(sched_runq_noirq_lock_calls == 1);
		require(sched_runq_noirq_unlock_calls == 1);
		require(sched_runq_set_timer_calls == 0);
		require(sched_runq_log_counts[10] == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.flags);
		mix_signed(&digest, sched_runq_log_counts[10]);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		cpu.current = &idle;
		cpu.status = SCHED_CPU_STATUS_RUNNING;
		rc = call_sched_schedule_prepare(&cpu, &idle, 0,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_NO_SWITCH);
		require(sched_result.prev_thread_addr == (unsigned long)&idle);
		require(sched_result.next_thread_addr == (unsigned long)&idle);
		require(cpu.current == &idle);
		require(cpu.status == SCHED_CPU_STATUS_IDLE);
		require(cpu.nr_ctx_switches == 0);
		require(sched_runq_set_timer_calls == 1);
		require(sched_runq_reset_cputime_calls == 0);
		require(sched_runq_noirq_unlock_calls == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.status);
		mix_signed(&digest, sched_runq_set_timer_calls);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 101, 0,
			SCHED_PS_RUNNING, 0);
		fake_runq_thread_init(&second, &second_proc, 102, 0,
			SCHED_PS_RUNNING, 0);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		list_add_tail_local(&second.sched_list, &cpu.runq);
		cpu.runq_len = 2;
		cpu.current = &thread;
		cpu.prevpid = 111;
		rc = call_sched_schedule_prepare(&cpu, &idle, 0,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_SWITCH);
		require(sched_result.prev_thread_addr == (unsigned long)&thread);
		require(sched_result.next_thread_addr == (unsigned long)&second);
		require(sched_result.prevpid == 111);
		require(cpu.current == &second);
		require(cpu.prevpid == proc.pid);
		require(cpu.runq_len == 2);
		require(cpu.runq.next == &second.sched_list);
		require(cpu.runq.prev == &thread.sched_list);
		require(cpu.nr_ctx_switches == 1);
		require(sched_runq_reset_cputime_calls == 1);
		require(sched_runq_noirq_unlock_calls == 0);
		mix_signed(&digest, rc);
		mix_signed(&digest, cpu.prevpid);
		mix(&digest, cpu.nr_ctx_switches);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 103, 0,
			SCHED_PS_RUNNING, 0);
		fake_runq_thread_init(&second, &second_proc, 104, 0,
			SCHED_PS_RUNNING, 0);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		second.mod_clone = 1001;
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		list_add_tail_local(&second.sched_list, &cpu.runq);
		cpu.runq_len = 2;
		cpu.current = &idle;
		rc = call_sched_schedule_prepare(&cpu, &idle, 0,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_SWITCH);
		require(sched_result.next_thread_addr == (unsigned long)&second);
		require(cpu.current == &second);
		require(cpu.nr_ctx_switches == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, second.tid);
		mix(&digest, cpu.nr_ctx_switches);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 105, 0,
			SCHED_PS_INTERRUPTIBLE, 0);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		init_list_head(&sigcommon.sigpending);
		init_list_head(&pending);
		list_add_tail_local(&pending, &sigcommon.sigpending);
		thread.sigcommon = &sigcommon;
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		cpu.runq_len = 1;
		cpu.current = &idle;
		sched_runq_has_signal_value = 1;
		rc = call_sched_schedule_prepare(&cpu, &idle, 0,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_SWITCH);
		require(sched_result.next_thread_addr == (unsigned long)&thread);
		require(cpu.current == &thread);
		require(sched_runq_has_signal_calls == 1);
		mix_signed(&digest, rc);
		mix_signed(&digest, sched_runq_has_signal_calls);
		mix_signed(&digest, thread.tid);

		reset_sched_runq_trace();
		fake_runq_cpu_init(&cpu);
		fake_runq_thread_init(&thread, &proc, 106, 0,
			SCHED_PS_EXITED, 0);
		fake_runq_thread_init(&idle, &proc, 0, 0, SCHED_PS_RUNNING, 0);
		list_add_tail_local(&thread.sched_list, &cpu.runq);
		cpu.runq_len = 1;
		cpu.current = &thread;
		cpu.flags = SCHED_CPU_FLAG_NEED_MIGRATE;
		rc = call_sched_schedule_prepare(&cpu, &idle, 0,
			&sched_result);
		require(rc == SCHED_SCHEDULE_ACTION_SWITCH);
		require(sched_result.prev_thread_addr == (unsigned long)&thread);
		require(sched_result.next_thread_addr == (unsigned long)&idle);
		require(cpu.current == &idle);
		require(cpu.runq_len == 0);
		require(cpu.nr_ctx_switches == 1);
		mix_signed(&digest, rc);
		mix(&digest, cpu.runq_len);
		mix(&digest, cpu.flags);

		return digest;
	}

	static unsigned long sched_syscall_body_digest(void)
	{
	struct fake_sched_proc current_proc = { .pid = 101 };
	struct fake_sched_proc remote_proc = { .pid = 202 };
	struct fake_sched_thread current = {
		.proc = &current_proc,
		.sched_param = { .sched_priority = 0 },
		.sched_policy = SCHED_NORMAL,
		.cpu_id = 0,
		.tid = 101,
	};
	struct fake_sched_thread remote = {
		.proc = &remote_proc,
		.sched_param = { .sched_priority = 5 },
		.sched_policy = SCHED_RR,
		.cpu_id = 2,
		.tid = 202,
	};
	struct sched_syscall_offsets offsets = {
		.thread_proc_offset = offsetof(struct fake_sched_thread, proc),
		.thread_sched_param_offset =
			offsetof(struct fake_sched_thread, sched_param),
		.thread_sched_policy_offset =
			offsetof(struct fake_sched_thread, sched_policy),
		.thread_cpu_id_offset = offsetof(struct fake_sched_thread, cpu_id),
		.thread_cpu_set_offset =
			offsetof(struct fake_sched_thread, cpu_set),
		.proc_pid_offset = offsetof(struct fake_sched_proc, pid),
		.proc_ruid_offset = offsetof(struct fake_sched_proc, ruid),
		.proc_euid_offset = offsetof(struct fake_sched_proc, euid),
		.proc_cpu_set_offset = offsetof(struct fake_sched_proc, cpu_set),
	};
	struct fake_sched_param in = { 0 };
	struct fake_sched_param out = { 0 };
	struct fake_sched_timespec ts = { 0 };
	unsigned long digest = 0x5c7ed5ced5ced5ceUL;
	long ret;

	sched_remote_thread = &remote;

	reset_sched_trace();
	in.sched_priority = 0;
	out.sched_priority = -1;
	ret = sched_setparam_body_result(0, (unsigned long)&in,
		(unsigned long)&current, (unsigned long)&out, sizeof(out),
		&offsets, 142, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_copy_from, fake_sched_syscall2, fake_sched_apply);
	require(ret == 0);
	require(current.sched_param.sched_priority == 0);
	require(current.sched_policy == SCHED_NORMAL);
	require(sched_find_calls == 0);
	require(sched_unlock_calls == 0);
	require(sched_copy_from_calls == 1);
	require(sched_syscall_calls == 0);
	require(sched_apply_calls == 1);
	require(sched_apply_thread == (unsigned long)&current);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_apply_calls);
	mix_signed(&digest, current.sched_policy);

	reset_sched_trace();
	remote.sched_policy = SCHED_RR;
	remote.sched_param.sched_priority = 4;
	in.sched_priority = 8;
	ret = sched_setparam_body_result(202, (unsigned long)&in,
		(unsigned long)&current, (unsigned long)&out, sizeof(out),
		&offsets, 142, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_copy_from, fake_sched_syscall2, fake_sched_apply);
	require(ret == 0);
	require(remote.sched_param.sched_priority == 8);
	require(remote.sched_policy == SCHED_RR);
	require(sched_find_calls == 2);
	require(sched_unlock_calls == 2);
	require(sched_syscall_calls == 1);
	require(sched_syscall_nr == 142);
	require(sched_syscall_arg0 == SCHED_CHECK_SAME_OWNER);
	require(sched_syscall_arg1 == 202);
	require(sched_apply_policy == SCHED_RR);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_find_calls);
	mix_signed(&digest, sched_unlock_calls);
	mix_signed(&digest, remote.sched_param.sched_priority);

	reset_sched_trace();
	sched_copy_from_fail = 1;
	in.sched_priority = 0;
	ret = sched_setparam_body_result(0, (unsigned long)&in,
		(unsigned long)&current, (unsigned long)&out, sizeof(out),
		&offsets, 142, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_copy_from, fake_sched_syscall2, fake_sched_apply);
	require(ret == -EFAULT);
	require(sched_apply_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_copy_from_calls);

	reset_sched_trace();
	sched_find_fail_on_call = 2;
	in.sched_priority = 6;
	ret = sched_setparam_body_result(202, (unsigned long)&in,
		(unsigned long)&current, (unsigned long)&out, sizeof(out),
		&offsets, 142, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_copy_from, fake_sched_syscall2, fake_sched_apply);
	require(ret == -ESRCH);
	require(sched_find_calls == 2);
	require(sched_unlock_calls == 1);
	require(sched_syscall_calls == 1);
	require(sched_copy_from_calls == 1);
	require(sched_apply_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_find_calls);
	mix_signed(&digest, sched_unlock_calls);

	reset_sched_trace();
	remote.sched_param.sched_priority = 12;
	out.sched_priority = -1;
	ret = sched_getparam_body_result(202, (unsigned long)&out,
		(unsigned long)&current, sizeof(out), &offsets,
		fake_sched_find_thread, fake_sched_unlock, fake_sched_copy_to);
	require(ret == 0);
	require(out.sched_priority == 12);
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	require(sched_copy_to_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, out.sched_priority);

	reset_sched_trace();
	in.sched_priority = 11;
	ret = sched_setscheduler_body_result(0, SCHED_FIFO,
		(unsigned long)&in, (unsigned long)&current, (unsigned long)&out,
		sizeof(out), &offsets, 142, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_copy_from, fake_sched_syscall2,
		fake_sched_apply);
	require(ret == 0);
	require(current.sched_policy == SCHED_FIFO);
	require(current.sched_param.sched_priority == 11);
	require(sched_syscall_calls == 1);
	require(sched_syscall_arg0 == SCHED_CHECK_ROOT);
	require(sched_copy_from_calls == 1);
	require(sched_apply_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, current.sched_policy);
	mix_signed(&digest, current.sched_param.sched_priority);

	reset_sched_trace();
	ret = sched_setscheduler_body_result(0, 99, (unsigned long)&in,
		(unsigned long)&current, (unsigned long)&out, sizeof(out),
		&offsets, 142, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_copy_from, fake_sched_syscall2, fake_sched_apply);
	require(ret == -EINVAL);
	require(sched_syscall_calls == 0);
	require(sched_copy_from_calls == 0);
	require(sched_apply_calls == 0);
	mix_signed(&digest, ret);

	reset_sched_trace();
	sched_syscall_ret = -EPERM;
	ret = sched_setscheduler_body_result(0, SCHED_FIFO,
		(unsigned long)&in, (unsigned long)&current, (unsigned long)&out,
		sizeof(out), &offsets, 142, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_copy_from, fake_sched_syscall2,
		fake_sched_apply);
	require(ret == -EPERM);
	require(sched_syscall_calls == 1);
	require(sched_copy_from_calls == 0);
	require(sched_apply_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_syscall_calls);

	reset_sched_trace();
	in.sched_priority = 0;
	remote.sched_policy = SCHED_RR;
	remote.sched_param.sched_priority = 8;
	ret = sched_setscheduler_body_result(202, SCHED_NORMAL,
		(unsigned long)&in, (unsigned long)&current, (unsigned long)&out,
		sizeof(out), &offsets, 142, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_copy_from, fake_sched_syscall2,
		fake_sched_apply);
	require(ret == 0);
	require(remote.sched_policy == SCHED_NORMAL);
	require(remote.sched_param.sched_priority == 0);
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	require(sched_syscall_calls == 1);
	require(sched_syscall_arg0 == SCHED_CHECK_SAME_OWNER);
	require(sched_apply_thread == (unsigned long)&remote);
	mix_signed(&digest, ret);
	mix_signed(&digest, remote.sched_policy);
	mix_signed(&digest, sched_find_calls);

	reset_sched_trace();
	remote.sched_policy = SCHED_RR;
	ret = sched_getscheduler_body_result(202, (unsigned long)&current,
		&offsets, fake_sched_find_thread, fake_sched_unlock);
	require(ret == SCHED_RR);
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_unlock_calls);

	reset_sched_trace();
	ts.tv_sec = -1;
	ts.tv_nsec = -1;
	ret = sched_rr_get_interval_body_result(202, (unsigned long)&ts,
		(unsigned long)&current, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_copy_to);
	require(ret == 0);
	require(ts.tv_sec == 0);
	require(ts.tv_nsec == 10000);
	require(sched_copy_to_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, ts.tv_nsec);

	reset_sched_trace();
	sched_copy_to_fail = 1;
	ret = sched_rr_get_interval_body_result(0, (unsigned long)&ts,
		(unsigned long)&current, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_copy_to);
	require(ret == -EFAULT);
	require(sched_copy_to_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_copy_to_calls);

	return digest;
}

static unsigned long sched_affinity_body_digest(void)
{
	struct fake_sched_proc current_proc = {
		.pid = 101,
		.ruid = 1000,
		.euid = 1000,
	};
	struct fake_sched_proc remote_proc = {
		.pid = 202,
		.ruid = 1000,
		.euid = 2000,
	};
	struct fake_sched_thread current = {
		.proc = &current_proc,
		.sched_param = { .sched_priority = 0 },
		.sched_policy = SCHED_NORMAL,
		.cpu_id = 0,
		.tid = 101,
	};
	struct fake_sched_thread remote = {
		.proc = &remote_proc,
		.sched_param = { .sched_priority = 4 },
		.sched_policy = SCHED_RR,
		.cpu_id = 2,
		.tid = 202,
	};
	struct sched_syscall_offsets offsets = {
		.thread_proc_offset = offsetof(struct fake_sched_thread, proc),
		.thread_sched_param_offset =
			offsetof(struct fake_sched_thread, sched_param),
		.thread_sched_policy_offset =
			offsetof(struct fake_sched_thread, sched_policy),
		.thread_cpu_id_offset = offsetof(struct fake_sched_thread, cpu_id),
		.thread_cpu_set_offset =
			offsetof(struct fake_sched_thread, cpu_set),
		.proc_pid_offset = offsetof(struct fake_sched_proc, pid),
		.proc_ruid_offset = offsetof(struct fake_sched_proc, ruid),
		.proc_euid_offset = offsetof(struct fake_sched_proc, euid),
		.proc_cpu_set_offset = offsetof(struct fake_sched_proc, cpu_set),
	};
	unsigned long user_set[SCHED_FAKE_CPU_WORDS] = { 0 };
	unsigned long work_set[SCHED_FAKE_CPU_WORDS] = { 0 };
	unsigned long filtered_set[SCHED_FAKE_CPU_WORDS] = { 0 };
	unsigned long out_set[SCHED_FAKE_CPU_WORDS] = { 0 };
	unsigned long digest = 0x5c7edaff17171717UL;
	long ret;

	sched_remote_thread = &remote;
	fake_sched_cpuset_zero(current_proc.cpu_set);
	fake_sched_cpuset_zero(remote_proc.cpu_set);
	fake_sched_cpuset_zero(current.cpu_set);
	fake_sched_cpuset_zero(remote.cpu_set);
	fake_sched_cpuset_set(current_proc.cpu_set, 1);
	fake_sched_cpuset_set(current_proc.cpu_set, 2);
	fake_sched_cpuset_set(remote_proc.cpu_set, 2);
	fake_sched_cpuset_set(remote_proc.cpu_set, 3);
	fake_sched_cpuset_set(current.cpu_set, 0);
	fake_sched_cpuset_set(remote.cpu_set, 2);

	reset_sched_trace();
	ret = sched_setaffinity_body_result(0, SCHED_FAKE_CPUSET_BYTES, 0,
		(unsigned long)&current, (unsigned long)work_set,
		(unsigned long)filtered_set, SCHED_FAKE_CPUSET_BYTES, 4,
		&offsets, fake_sched_find_thread, fake_sched_unlock,
		fake_sched_hold, fake_sched_release, fake_sched_copy_from,
		fake_sched_migrate);
	require(ret == -EFAULT);
	require(sched_copy_from_calls == 0);
	require(sched_hold_calls == 0);
	mix_signed(&digest, ret);

	reset_sched_trace();
	fake_sched_cpuset_zero(user_set);
	fake_sched_cpuset_set(user_set, 1);
	fake_sched_cpuset_set(user_set, 3);
	current.cpu_id = 0;
	ret = sched_setaffinity_body_result(0, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == 0);
	require(fake_sched_cpuset_isset(current.cpu_set, 1));
	require(!fake_sched_cpuset_isset(current.cpu_set, 3));
	require(sched_hold_calls == 1);
	require(sched_release_calls == 1);
	require(sched_migrate_calls == 1);
	require(sched_migrate_cpu == 0);
	require(sched_migrate_thread == (unsigned long)&current);
	mix_signed(&digest, ret);
	mix(&digest, current.cpu_set[0]);
	mix_signed(&digest, sched_migrate_calls);

	reset_sched_trace();
	fake_sched_cpuset_zero(user_set);
	fake_sched_cpuset_set(user_set, 3);
	current.cpu_id = 1;
	ret = sched_setaffinity_body_result(0, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == -EINVAL);
	require(sched_hold_calls == 1);
	require(sched_release_calls == 1);
	require(sched_migrate_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_release_calls);

	reset_sched_trace();
	sched_copy_from_fail = 1;
	ret = sched_setaffinity_body_result(0, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == -EFAULT);
	require(sched_copy_from_calls == 1);
	require(sched_hold_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_copy_from_calls);

	reset_sched_trace();
	current_proc.euid = 3000;
	ret = sched_setaffinity_body_result(202, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == -EPERM);
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	require(sched_hold_calls == 0);
	require(sched_release_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_unlock_calls);

	reset_sched_trace();
	current_proc.euid = 1000;
	fake_sched_cpuset_zero(user_set);
	fake_sched_cpuset_set(user_set, 2);
	fake_sched_cpuset_set(user_set, 3);
	remote.cpu_id = 2;
	ret = sched_setaffinity_body_result(202, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == 0);
	require(fake_sched_cpuset_isset(remote.cpu_set, 2));
	require(fake_sched_cpuset_isset(remote.cpu_set, 3));
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	require(sched_hold_calls == 1);
	require(sched_release_calls == 1);
	require(sched_migrate_calls == 0);
	mix_signed(&digest, ret);
	mix(&digest, remote.cpu_set[0]);
	mix_signed(&digest, sched_find_calls);

	reset_sched_trace();
	sched_find_fail_on_call = 1;
	ret = sched_setaffinity_body_result(202, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)user_set, (unsigned long)&current,
		(unsigned long)work_set, (unsigned long)filtered_set,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_from, fake_sched_migrate);
	require(ret == -ESRCH);
	require(sched_find_calls == 1);
	require(sched_hold_calls == 0);
	mix_signed(&digest, ret);

	reset_sched_trace();
	ret = sched_getaffinity_body_result(0, 1, (unsigned long)out_set,
		(unsigned long)&current, SCHED_FAKE_CPUSET_BYTES, 16, &offsets,
		fake_sched_find_thread, fake_sched_unlock, fake_sched_hold,
		fake_sched_release, fake_sched_copy_to);
	require(ret == -EINVAL);
	require(sched_copy_to_calls == 0);
	require(sched_hold_calls == 0);
	mix_signed(&digest, ret);

	reset_sched_trace();
	fake_sched_cpuset_zero(out_set);
	ret = sched_getaffinity_body_result(0, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)out_set, (unsigned long)&current,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_to);
	require(ret == SCHED_FAKE_CPUSET_BYTES);
	require(out_set[0] == current.cpu_set[0]);
	require(sched_hold_calls == 1);
	require(sched_release_calls == 1);
	require(sched_copy_to_calls == 1);
	mix_signed(&digest, ret);
	mix(&digest, out_set[0]);

	reset_sched_trace();
	sched_copy_to_fail = 1;
	ret = sched_getaffinity_body_result(202, SCHED_FAKE_CPUSET_BYTES,
		(unsigned long)out_set, (unsigned long)&current,
		SCHED_FAKE_CPUSET_BYTES, 4, &offsets, fake_sched_find_thread,
		fake_sched_unlock, fake_sched_hold, fake_sched_release,
		fake_sched_copy_to);
	require(ret == -EFAULT);
	require(sched_find_calls == 1);
	require(sched_unlock_calls == 1);
	require(sched_hold_calls == 1);
	require(sched_release_calls == 1);
	require(sched_copy_to_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_release_calls);

	return digest;
}

static unsigned long sched_migrate_body_digest(void)
{
	struct fake_sched_thread remote_thread = {
		.cpu_id = 7,
		.tid = 313,
	};
	struct fake_sched_thread local_thread = {
		.cpu_id = 4,
		.tid = 414,
	};
	struct fake_migrate_cpu remote_cpu;
	struct fake_migrate_cpu local_cpu;
	struct fake_migrate_cpu invalid_cpu;
	struct fake_migrate_request remote_req;
	struct fake_migrate_request local_req;
	struct fake_migrate_request invalid_req;
	struct list_head remote_entry;
	struct list_head local_entry;
	unsigned long digest = 0x6d69677261746521UL;
	int ret;

	memset(&remote_cpu, 0, sizeof(remote_cpu));
	remote_cpu.migq_lock = 9;
	remote_cpu.runq_lock = 41;
	remote_cpu.flags = 0x80;
	init_list_head(&remote_cpu.migq);
	memset(&remote_req, 0xa5, sizeof(remote_req));
	init_list_head(&remote_entry);
	reset_sched_migrate_body_trace();
	ret = sched_request_migrate_body_result(2,
		(unsigned long)&remote_cpu, (unsigned long)&remote_req,
		(unsigned long)&remote_entry, (unsigned long)&remote_thread, 0,
		SCHED_PS_UNINTERRUPTIBLE, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_CPU_FLAG_NEED_MIGRATE, SCHED_CPU_STATUS_RUNNING,
		SCHED_IHK_GV_IKC, &fake_sched_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_migrate_body_waitq_init,
		fake_sched_migrate_body_waitq_prepare,
		fake_sched_migrate_body_waitq_finish,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_migrate_body_schedule,
		fake_sched_migrate_body_log);
	require(ret == 1);
	require(remote_req.thread == &remote_thread);
	require(remote_req.list.next == &remote_cpu.migq);
	require(remote_req.list.prev == &remote_cpu.migq);
	require(remote_cpu.migq.next == &remote_req.list);
	require(remote_cpu.migq.prev == &remote_req.list);
	require(remote_req.wq.initialized == 1);
	require(remote_req.wq.prepared == 1);
	require(remote_req.wq.finished == 1);
	require(remote_req.wq.entry == (unsigned long)&remote_entry);
	require(remote_req.wq.status == SCHED_PS_UNINTERRUPTIBLE);
	require(remote_cpu.flags == (0x80U | SCHED_CPU_FLAG_NEED_RESCHED |
				    SCHED_CPU_FLAG_NEED_MIGRATE));
	require(remote_cpu.status == SCHED_CPU_STATUS_RUNNING);
	require(remote_cpu.migq_lock == 17);
	require(remote_cpu.runq_lock == 45);
	require(sched_migrate_body_lock_addr ==
		(unsigned long)&remote_cpu.migq_lock);
	require(sched_migrate_body_unlock_addr ==
		(unsigned long)&remote_cpu.migq_lock);
	require(sched_migrate_body_unlock_irqstate == 0xabc001UL);
	require(sched_migrate_body_noirq_lock_addr ==
		(unsigned long)&remote_cpu.runq_lock);
	require(sched_migrate_body_noirq_unlock_addr ==
		(unsigned long)&remote_cpu.runq_lock);
	require(sched_migrate_body_lock_order <
		sched_migrate_body_waitq_init_order);
	require(sched_migrate_body_waitq_init_order <
		sched_migrate_body_waitq_prepare_order);
	require(sched_migrate_body_waitq_prepare_order <
		sched_migrate_body_noirq_lock_order);
	require(sched_migrate_body_noirq_lock_order <
		sched_migrate_body_noirq_unlock_order);
	require(sched_migrate_body_noirq_unlock_order <
		sched_migrate_body_vector_order);
	require(sched_migrate_body_vector_order <
		sched_migrate_body_interrupt_order);
	require(sched_migrate_body_interrupt_order <
		sched_migrate_body_log_order);
	require(sched_migrate_body_log_order <
		sched_migrate_body_unlock_order);
	require(sched_migrate_body_unlock_order <
		sched_migrate_body_schedule_order);
	require(sched_migrate_body_schedule_order <
		sched_migrate_body_finish_order);
	require(sched_migrate_body_vector_key == SCHED_IHK_GV_IKC);
	require(sched_migrate_body_interrupt_cpu == remote_thread.cpu_id);
	require(sched_migrate_body_interrupt_vector ==
		SCHED_IHK_GV_IKC + 2000);
	require(sched_migrate_body_log_thread ==
		(unsigned long)&remote_thread);
	require(sched_migrate_body_log_tid == remote_thread.tid);
	require(sched_migrate_body_log_cpu == 2);
	mix_signed(&digest, ret);
	mix(&digest, remote_cpu.flags);
	mix_signed(&digest, sched_migrate_body_interrupt_cpu);
	mix_signed(&digest, sched_migrate_body_finish_order);

	memset(&local_cpu, 0, sizeof(local_cpu));
	local_cpu.migq_lock = 3;
	local_cpu.runq_lock = 5;
	init_list_head(&local_cpu.migq);
	memset(&local_req, 0, sizeof(local_req));
	init_list_head(&local_entry);
	reset_sched_migrate_body_trace();
	ret = sched_request_migrate_body_result(3,
		(unsigned long)&local_cpu, (unsigned long)&local_req,
		(unsigned long)&local_entry, (unsigned long)&local_thread, 3,
		SCHED_PS_UNINTERRUPTIBLE, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_CPU_FLAG_NEED_MIGRATE, SCHED_CPU_STATUS_RUNNING,
		SCHED_IHK_GV_IKC, &fake_sched_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_migrate_body_waitq_init,
		fake_sched_migrate_body_waitq_prepare,
		fake_sched_migrate_body_waitq_finish,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_migrate_body_schedule,
		fake_sched_migrate_body_log);
	require(ret == 1);
	require(local_req.thread == &local_thread);
	require(local_cpu.migq.next == &local_req.list);
	require(local_cpu.migq.prev == &local_req.list);
	require(local_cpu.flags == (SCHED_CPU_FLAG_NEED_RESCHED |
				   SCHED_CPU_FLAG_NEED_MIGRATE));
	require(local_cpu.status == SCHED_CPU_STATUS_RUNNING);
	require(sched_migrate_body_vector_calls == 0);
	require(sched_migrate_body_interrupt_calls == 0);
	require(sched_migrate_body_log_calls == 1);
	require(sched_migrate_body_unlock_order <
		sched_migrate_body_schedule_order);
	require(sched_migrate_body_schedule_order <
		sched_migrate_body_finish_order);
	require(local_req.wq.finished == 1);
	mix_signed(&digest, ret);
	mix(&digest, local_cpu.flags);
	mix_signed(&digest, sched_migrate_body_vector_calls);
	mix_signed(&digest, sched_migrate_body_finish_order);

	memset(&invalid_cpu, 0, sizeof(invalid_cpu));
	invalid_cpu.migq_lock = 11;
	invalid_cpu.runq_lock = 13;
	init_list_head(&invalid_cpu.migq);
	memset(&invalid_req, 0, sizeof(invalid_req));
	reset_sched_migrate_body_trace();
	ret = sched_request_migrate_body_result(4,
		(unsigned long)&invalid_cpu, 0,
		(unsigned long)&local_entry, (unsigned long)&local_thread, 1,
		SCHED_PS_UNINTERRUPTIBLE, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_CPU_FLAG_NEED_MIGRATE, SCHED_CPU_STATUS_RUNNING,
		SCHED_IHK_GV_IKC, &fake_sched_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_migrate_body_waitq_init,
		fake_sched_migrate_body_waitq_prepare,
		fake_sched_migrate_body_waitq_finish,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_migrate_body_schedule,
		fake_sched_migrate_body_log);
	require(ret == -EINVAL);
	require(sched_migrate_body_lock_calls == 0);
	require(invalid_cpu.migq_lock == 11);
	require(invalid_cpu.runq_lock == 13);
	require(list_empty_local(&invalid_cpu.migq));
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_migrate_body_lock_calls);

	reset_sched_migrate_body_trace();
	ret = sched_request_migrate_body_result(4,
		(unsigned long)&invalid_cpu, (unsigned long)&invalid_req,
		(unsigned long)&local_entry, (unsigned long)&local_thread, 1,
		SCHED_PS_UNINTERRUPTIBLE, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_CPU_FLAG_NEED_MIGRATE, SCHED_CPU_STATUS_RUNNING,
		SCHED_IHK_GV_IKC, &fake_sched_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_migrate_body_waitq_init,
		fake_sched_migrate_body_waitq_prepare,
		fake_sched_migrate_body_waitq_finish,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt, NULL,
		fake_sched_migrate_body_log);
	require(ret == -EINVAL);
	require(sched_migrate_body_lock_calls == 0);
	require(invalid_req.thread == NULL);
	require(list_empty_local(&invalid_cpu.migq));
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_migrate_body_lock_calls);

	return digest;
}

static unsigned long sched_do_migrate_body_digest(void)
{
	struct fake_migrate_cpu cpus[4];
	struct fake_sched_address_space as;
	struct fake_sched_vm vm = { .address_space = &as };
	struct fake_sched_thread moving;
	struct fake_sched_thread sibling;
	struct fake_migrate_request req;
	unsigned long digest = 0x646f5f6d696772UL;
	int ret;

	memset(cpus, 0, sizeof(cpus));
	for (int i = 0; i < 4; i++) {
		cpus[i].migq_lock = 10 + i;
		cpus[i].runq_lock = 30 + i;
		init_list_head(&cpus[i].migq);
		init_list_head(&cpus[i].runq);
	}
	memset(&as, 0, sizeof(as));
	memset(&moving, 0, sizeof(moving));
	memset(&sibling, 0, sizeof(sibling));
	memset(&req, 0, sizeof(req));
	moving.cpu_id = 0;
	moving.tid = 501;
	moving.vm = &vm;
	sibling.cpu_id = 0;
	sibling.tid = 502;
	sibling.vm = &vm;
	init_list_head(&moving.sched_list);
	init_list_head(&sibling.sched_list);
	fake_sched_cpuset_set(moving.cpu_set, 2);
	fake_sched_cpuset_set(as.cpu_set, 0);
	list_add_tail_local(&moving.sched_list, &cpus[0].runq);
	list_add_tail_local(&sibling.sched_list, &cpus[0].runq);
	cpus[0].runq_len = 2;
	init_list_head(&req.list);
	req.thread = &moving;
	list_add_tail_local(&req.list, &cpus[0].migq);
	reset_sched_do_migrate_trace();
	sched_do_migrate_cpus[0] = &cpus[0];
	sched_do_migrate_cpus[2] = &cpus[2];
	ret = sched_do_migrate_body_result(0, (unsigned long)&cpus[0],
		(int)SCHED_FAKE_CPUSET_BITS, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_IHK_GV_IKC, &fake_sched_do_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_do_migrate_cpu_local,
		fake_sched_do_migrate_waitq_wakeup,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_do_migrate_log);
	require(ret == 1);
	require(list_empty_local(&cpus[0].migq));
	require(req.list.next == (struct list_head *)SCHED_LIST_POISON1);
	require(req.list.prev == (struct list_head *)SCHED_LIST_POISON2);
	require(cpus[0].runq_len == 1);
	require(cpus[2].runq_len == 1);
	require(moving.cpu_id == 2);
	require(cpus[2].runq.next == &moving.sched_list);
	require(cpus[2].runq.prev == &moving.sched_list);
	require(cpus[0].runq.next == &sibling.sched_list);
	require(fake_sched_cpuset_isset(as.cpu_set, 0));
	require(fake_sched_cpuset_isset(as.cpu_set, 2));
	require(req.wq.wakeups == 1);
	require(sched_do_migrate_wake_calls == 1);
	require(sched_migrate_body_interrupt_calls == 1);
	require(sched_migrate_body_interrupt_cpu == 2);
	require(sched_migrate_body_interrupt_vector ==
		SCHED_IHK_GV_IKC + 2000);
	require(cpus[2].flags == SCHED_CPU_FLAG_NEED_RESCHED);
	require(sched_do_migrate_log_calls == 1);
	require(sched_do_migrate_log_thread == (unsigned long)&moving);
	require(sched_do_migrate_log_tid == 501);
	require(sched_do_migrate_log_old_cpu == 0);
	require(sched_do_migrate_log_new_cpu == 2);
	mix_signed(&digest, ret);
	mix_signed(&digest, moving.cpu_id);
	mix(&digest, cpus[0].runq_len);
	mix(&digest, cpus[2].runq_len);
	mix(&digest, as.cpu_set[0]);
	mix_signed(&digest, sched_migrate_body_interrupt_cpu);

	memset(cpus, 0, sizeof(cpus));
	for (int i = 0; i < 4; i++) {
		cpus[i].migq_lock = 110 + i;
		cpus[i].runq_lock = 130 + i;
		init_list_head(&cpus[i].migq);
		init_list_head(&cpus[i].runq);
	}
	memset(&as, 0, sizeof(as));
	memset(&moving, 0, sizeof(moving));
	memset(&req, 0, sizeof(req));
	moving.cpu_id = 0;
	moving.tid = 601;
	moving.vm = &vm;
	init_list_head(&moving.sched_list);
	fake_sched_cpuset_set(moving.cpu_set, 1);
	fake_sched_cpuset_set(as.cpu_set, 0);
	list_add_tail_local(&moving.sched_list, &cpus[0].runq);
	cpus[0].runq_len = 1;
	init_list_head(&req.list);
	req.thread = &moving;
	list_add_tail_local(&req.list, &cpus[0].migq);
	reset_sched_do_migrate_trace();
	sched_do_migrate_cpus[0] = &cpus[0];
	sched_do_migrate_cpus[1] = &cpus[1];
	ret = sched_do_migrate_body_result(0, (unsigned long)&cpus[0],
		(int)SCHED_FAKE_CPUSET_BITS, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_IHK_GV_IKC, &fake_sched_do_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_do_migrate_cpu_local,
		fake_sched_do_migrate_waitq_wakeup,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_do_migrate_log);
	require(ret == 1);
	require(cpus[0].runq_len == 0);
	require(cpus[1].runq_len == 1);
	require(moving.cpu_id == 1);
	require(!fake_sched_cpuset_isset(as.cpu_set, 0));
	require(fake_sched_cpuset_isset(as.cpu_set, 1));
	require(req.wq.wakeups == 1);
	require(sched_migrate_body_interrupt_cpu == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, moving.cpu_id);
	mix(&digest, as.cpu_set[0]);
	mix_signed(&digest, sched_migrate_body_interrupt_cpu);

	{
		struct fake_sched_thread already_remote;
		struct fake_sched_thread current_allowed;
		struct fake_sched_thread empty_affinity;
		struct fake_migrate_request ack_reqs[3];

		memset(cpus, 0, sizeof(cpus));
		for (int i = 0; i < 4; i++) {
			cpus[i].migq_lock = 210 + i;
			cpus[i].runq_lock = 230 + i;
			init_list_head(&cpus[i].migq);
			init_list_head(&cpus[i].runq);
		}
		memset(&already_remote, 0, sizeof(already_remote));
		memset(&current_allowed, 0, sizeof(current_allowed));
		memset(&empty_affinity, 0, sizeof(empty_affinity));
		memset(ack_reqs, 0, sizeof(ack_reqs));
		already_remote.cpu_id = 3;
		already_remote.tid = 701;
		current_allowed.cpu_id = 0;
		current_allowed.tid = 702;
		empty_affinity.cpu_id = 0;
		empty_affinity.tid = 703;
		fake_sched_cpuset_set(already_remote.cpu_set, 2);
		fake_sched_cpuset_set(current_allowed.cpu_set, 0);
		ack_reqs[0].thread = &already_remote;
		ack_reqs[1].thread = &current_allowed;
		ack_reqs[2].thread = &empty_affinity;
		for (int i = 0; i < 3; i++) {
			init_list_head(&ack_reqs[i].list);
			list_add_tail_local(&ack_reqs[i].list, &cpus[0].migq);
		}
		reset_sched_do_migrate_trace();
		sched_do_migrate_cpus[0] = &cpus[0];
		ret = sched_do_migrate_body_result(0, (unsigned long)&cpus[0],
			(int)SCHED_FAKE_CPUSET_BITS,
			SCHED_CPU_FLAG_NEED_RESCHED, SCHED_IHK_GV_IKC,
			&fake_sched_do_migrate_offsets,
			fake_sched_migrate_body_lock,
			fake_sched_migrate_body_unlock,
			fake_sched_migrate_body_noirq_lock,
			fake_sched_migrate_body_noirq_unlock,
			fake_sched_do_migrate_cpu_local,
			fake_sched_do_migrate_waitq_wakeup,
			fake_sched_migrate_body_vector,
			fake_sched_migrate_body_interrupt,
			fake_sched_do_migrate_log);
		require(ret == 3);
		require(list_empty_local(&cpus[0].migq));
		require(ack_reqs[0].wq.wakeups == 1);
		require(ack_reqs[1].wq.wakeups == 1);
		require(ack_reqs[2].wq.wakeups == 1);
		require(sched_do_migrate_wake_calls == 3);
		require(sched_migrate_body_interrupt_calls == 0);
		require(sched_do_migrate_log_calls == 0);
		require(cpus[0].runq_len == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, sched_do_migrate_wake_calls);
		mix_signed(&digest, sched_migrate_body_interrupt_calls);
	}

	reset_sched_do_migrate_trace();
	ret = sched_do_migrate_body_result(0, 0,
		(int)SCHED_FAKE_CPUSET_BITS, SCHED_CPU_FLAG_NEED_RESCHED,
		SCHED_IHK_GV_IKC, &fake_sched_do_migrate_offsets,
		fake_sched_migrate_body_lock,
		fake_sched_migrate_body_unlock,
		fake_sched_migrate_body_noirq_lock,
		fake_sched_migrate_body_noirq_unlock,
		fake_sched_do_migrate_cpu_local,
		fake_sched_do_migrate_waitq_wakeup,
		fake_sched_migrate_body_vector,
		fake_sched_migrate_body_interrupt,
		fake_sched_do_migrate_log);
	require(ret == -EINVAL);
	require(sched_migrate_body_lock_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, sched_migrate_body_lock_calls);

	return digest;
}

static unsigned long futex_hash_bucket_table_init_digest(void)
{
	struct fake_futex_table_bucket buckets[3];
	unsigned long digest = 0x6675746578686269UL;
	unsigned long chain_offset =
		offsetof(struct fake_futex_table_bucket, chain);
	int ret;

	memset(buckets, 0xa5, sizeof(buckets));
	ret = futex_hash_bucket_table_init_result((unsigned long)buckets,
		3, sizeof(buckets[0]),
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list),
		offsetof(struct fake_futex_table_bucket, debug_spinlock) -
			chain_offset,
		offsetof(struct fake_futex_table_bucket, debug_rawlock) -
			chain_offset);

	require(ret == 3);
	for (int i = 0; i < 3; i++) {
		struct fake_futex_table_bucket *bucket = &buckets[i];

		require(bucket->prefix == 0xa5a5a5a5a5a5a5a5UL);
		require(bucket->lock_word == 0);
		require(bucket->lock_guard == 0xa5a5a5a5U);
		require(bucket->chain.prio_list.next ==
			&bucket->chain.prio_list);
		require(bucket->chain.prio_list.prev ==
			&bucket->chain.prio_list);
		require(bucket->chain.node_list.next ==
			&bucket->chain.node_list);
		require(bucket->chain.node_list.prev ==
			&bucket->chain.node_list);
		require(bucket->debug_spinlock ==
			(unsigned long)&bucket->lock_word);
		require(bucket->debug_rawlock == 0);
		require(bucket->suffix == 0xa5a5a5a5a5a5a5a5UL);

		mix(&digest, (unsigned long)ret);
		mix(&digest, bucket->lock_word);
		mix(&digest, (unsigned long)bucket->lock_guard);
		mix(&digest, (unsigned long)bucket->chain.prio_list.next -
			(unsigned long)bucket);
		mix(&digest, (unsigned long)bucket->chain.node_list.next -
			(unsigned long)bucket);
		mix(&digest, bucket->debug_spinlock - (unsigned long)bucket);
		mix(&digest, bucket->debug_rawlock);
	}

	mix_signed(&digest, futex_hash_bucket_table_init_result(0, 0,
		sizeof(buckets[0]), offsetof(struct fake_futex_table_bucket,
		lock_word), 0, chain_offset, offsetof(struct plist_head,
		prio_list), offsetof(struct plist_head, node_list), 0, 0));
	mix_signed(&digest, futex_hash_bucket_table_init_result(0, 1,
		sizeof(buckets[0]), offsetof(struct fake_futex_table_bucket,
		lock_word), 0, chain_offset, offsetof(struct plist_head,
		prio_list), offsetof(struct plist_head, node_list), 0, 0));
	mix_signed(&digest, futex_hash_bucket_table_init_result(
		(unsigned long)buckets, -1, sizeof(buckets[0]),
		offsetof(struct fake_futex_table_bucket, lock_word), 0,
		chain_offset, offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0));
	mix_signed(&digest, futex_hash_bucket_table_init_result(
		(unsigned long)buckets, 1, 0,
		offsetof(struct fake_futex_table_bucket, lock_word), 0,
		chain_offset, offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0));

	return digest;
}

static void *futex_alloc_ptr;
static unsigned long futex_alloc_size;
static int futex_alloc_flag;
static int futex_alloc_fail;

static unsigned long fake_futex_alloc(unsigned long size, int flag)
{
	futex_alloc_size = size;
	futex_alloc_flag = flag;
	return futex_alloc_fail ? 0 : (unsigned long)futex_alloc_ptr;
}

static unsigned long futex_init_table_digest(void)
{
	struct fake_futex_table_bucket buckets[4];
	unsigned long slot = 0;
	unsigned long digest = 0x6675746578696e69UL;
	unsigned long chain_offset =
		offsetof(struct fake_futex_table_bucket, chain);
	int ret;

	memset(buckets, 0xa5, sizeof(buckets));
	futex_alloc_ptr = buckets;
	futex_alloc_size = 0;
	futex_alloc_flag = 0;
	futex_alloc_fail = 0;
	ret = futex_init_table_result((unsigned long)&slot, 2,
		sizeof(buckets[0]), 77, fake_futex_alloc,
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list),
		offsetof(struct fake_futex_table_bucket, debug_spinlock) -
			chain_offset,
		offsetof(struct fake_futex_table_bucket, debug_rawlock) -
			chain_offset);
	require(ret == 4);
	require(slot == (unsigned long)buckets);
	require(futex_alloc_size == sizeof(buckets));
	require(futex_alloc_flag == 77);
	require(buckets[0].lock_word == 0);
	require(buckets[3].chain.node_list.next ==
		&buckets[3].chain.node_list);
	mix_signed(&digest, ret);
	mix(&digest, slot == (unsigned long)buckets);
	mix(&digest, futex_alloc_size);
	mix_signed(&digest, futex_alloc_flag);
	mix(&digest, buckets[3].debug_spinlock -
		(unsigned long)&buckets[3]);

	slot = 0x1234;
	futex_alloc_fail = 1;
	ret = futex_init_table_result((unsigned long)&slot, 2,
		sizeof(buckets[0]), 88, fake_futex_alloc,
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0);
	require(ret < 0);
	require(slot == 0);
	mix_signed(&digest, ret);
	mix(&digest, slot);
	mix_signed(&digest, futex_init_table_result(0, 2,
		sizeof(buckets[0]), 88, fake_futex_alloc,
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0));
	mix_signed(&digest, futex_init_table_result((unsigned long)&slot, -1,
		sizeof(buckets[0]), 88, fake_futex_alloc,
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0));
	mix_signed(&digest, futex_init_table_result((unsigned long)&slot, 2,
		sizeof(buckets[0]), 88, NULL,
		offsetof(struct fake_futex_table_bucket, lock_word),
		0, chain_offset,
		offsetof(struct plist_head, prio_list),
		offsetof(struct plist_head, node_list), 0, 0));

	return digest;
}

static unsigned int fake_futex_hash(unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	return (unsigned int)(key->opaque[0] ^ (key->opaque[1] << 7) ^
		(key->opaque[2] >> 3));
}

static unsigned long futex_hash_bucket_digest(void)
{
	struct fake_futex_table_bucket buckets[4];
	struct futex_key key = { .opaque = { 0x11, 0x20, 0x88 } };
	unsigned long digest = 0x6675746578686173UL;
	unsigned long bucket;

	bucket = futex_hash_bucket_result((unsigned long)&key,
		(unsigned long)buckets, 2, sizeof(buckets[0]),
		fake_futex_hash);
	mix(&digest, bucket - (unsigned long)buckets);
	mix(&digest, bucket == (unsigned long)&buckets[
		fake_futex_hash((unsigned long)&key) & 3]);
	key.opaque[0] = 0xdeadbeef;
	key.opaque[1] = 0x1234;
	key.opaque[2] = 0x5678;
	bucket = futex_hash_bucket_result((unsigned long)&key,
		(unsigned long)buckets, 2, sizeof(buckets[0]),
		fake_futex_hash);
	mix(&digest, bucket - (unsigned long)buckets);
	mix(&digest, futex_hash_bucket_result(0, (unsigned long)buckets, 2,
		sizeof(buckets[0]), fake_futex_hash));
	mix(&digest, futex_hash_bucket_result((unsigned long)&key, 0, 2,
		sizeof(buckets[0]), fake_futex_hash));
	mix(&digest, futex_hash_bucket_result((unsigned long)&key,
		(unsigned long)buckets, -1, sizeof(buckets[0]),
		fake_futex_hash));
	mix(&digest, futex_hash_bucket_result((unsigned long)&key,
		(unsigned long)buckets, 2, 0, fake_futex_hash));
	mix(&digest, futex_hash_bucket_result((unsigned long)&key,
		(unsigned long)buckets, 2, sizeof(buckets[0]), NULL));

	return digest;
}

struct futex_dispatch_trace {
	int wait_count;
	int wake_count;
	int requeue_count;
	int wake_op_count;
	int invalid_count;
	unsigned long uaddr;
	unsigned long uaddr2;
	unsigned int val;
	unsigned int val2;
	unsigned int val3;
	int fshared;
	int cmpval_present;
	unsigned int cmpval;
	int requeue_pi;
	int clockrt;
	int invalid_cmd;
};

static struct futex_dispatch_trace dispatch_trace;

static void reset_futex_dispatch_trace(void)
{
	memset(&dispatch_trace, 0, sizeof(dispatch_trace));
	dispatch_trace.invalid_cmd = -1;
}

static int fake_dispatch_wait(unsigned long uaddr, int fshared,
			      unsigned int val, unsigned long timeout,
			      unsigned int val3, int clockrt)
{
	dispatch_trace.wait_count++;
	dispatch_trace.uaddr = uaddr;
	dispatch_trace.val = val;
	dispatch_trace.val3 = val3;
	dispatch_trace.fshared = fshared;
	dispatch_trace.clockrt = clockrt;
	mix(&timeout, uaddr);
	return 1000 + (int)(val3 & 0xffU) + (clockrt ? 20 : 0) +
		(int)(timeout & 3UL);
}

static int fake_dispatch_wake(unsigned long uaddr, int fshared,
			      unsigned int val, unsigned int val3)
{
	dispatch_trace.wake_count++;
	dispatch_trace.uaddr = uaddr;
	dispatch_trace.val = val;
	dispatch_trace.val3 = val3;
	dispatch_trace.fshared = fshared;
	return 2000 + (int)(val3 & 0xffU);
}

static int fake_dispatch_requeue(unsigned long uaddr, int fshared,
				 unsigned long uaddr2, unsigned int val,
				 unsigned int val2, int cmpval_present,
				 unsigned int cmpval, int requeue_pi)
{
	dispatch_trace.requeue_count++;
	dispatch_trace.uaddr = uaddr;
	dispatch_trace.uaddr2 = uaddr2;
	dispatch_trace.val = val;
	dispatch_trace.val2 = val2;
	dispatch_trace.fshared = fshared;
	dispatch_trace.cmpval_present = cmpval_present;
	dispatch_trace.cmpval = cmpval;
	dispatch_trace.requeue_pi = requeue_pi;
	return 3000 + cmpval_present * 10 + (int)(cmpval & 0xffU) +
		requeue_pi;
}

static int fake_dispatch_wake_op(unsigned long uaddr, int fshared,
				 unsigned long uaddr2, unsigned int val,
				 unsigned int val2, unsigned int val3)
{
	dispatch_trace.wake_op_count++;
	dispatch_trace.uaddr = uaddr;
	dispatch_trace.uaddr2 = uaddr2;
	dispatch_trace.val = val;
	dispatch_trace.val2 = val2;
	dispatch_trace.val3 = val3;
	dispatch_trace.fshared = fshared;
	return 4000 + (int)(val2 & 0xffU) + (int)(val3 & 0xffU);
}

static void fake_dispatch_invalid(int cmd)
{
	dispatch_trace.invalid_count++;
	dispatch_trace.invalid_cmd = cmd;
}

static unsigned long futex_dispatch_digest(void)
{
	unsigned long digest = 0x6675746578646973UL;
	int ret;

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAIT, 0x1000, 0x22, 0x3000,
		0x2000, 0x44, 0x55, 1, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.wait_count == 1);
	require(dispatch_trace.val3 == FUTEX_BITSET_MATCH_ANY);
	require(dispatch_trace.clockrt == 0);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.val3);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAIT_BITSET, 0x1004, 0x23, 0x3001,
		0x2004, 0x45, 0xa5, 0, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.wait_count == 1);
	require(dispatch_trace.val3 == 0xa5U);
	require(dispatch_trace.fshared == 0);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.val3);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAKE, 0x1010, 0x24, 0x3002,
		0x2010, 0x46, 0x88, 1, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.wake_count == 1);
	require(dispatch_trace.val3 == FUTEX_BITSET_MATCH_ANY);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.val3);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAKE_BITSET, 0x1014, 0x25, 0x3003,
		0x2014, 0x47, 0x77, 0, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.wake_count == 1);
	require(dispatch_trace.val3 == 0x77U);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.val3);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_REQUEUE, 0x1020, 0x26, 0x3004,
		0x2020, 0x48, 0x66, 1, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.requeue_count == 1);
	require(dispatch_trace.cmpval_present == 0);
	require(dispatch_trace.cmpval == 0);
	require(dispatch_trace.requeue_pi == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.cmpval_present);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_CMP_REQUEUE, 0x1024, 0x27, 0x3005,
		0x2024, 0x49, 0x65, 0, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.requeue_count == 1);
	require(dispatch_trace.cmpval_present == 1);
	require(dispatch_trace.cmpval == 0x65U);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.cmpval);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAKE_OP, 0x1030, 0x28, 0x3006,
		0x2030, 0x4a, 0x64, 1, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(dispatch_trace.wake_op_count == 1);
	require(dispatch_trace.val2 == 0x4aU);
	require(dispatch_trace.val3 == 0x64U);
	mix_signed(&digest, ret);
	mix(&digest, dispatch_trace.val2);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME,
		0x1040, 0x29, 0x3007, 0x2040, 0x4b, 0x63, 0,
		fake_dispatch_wait, fake_dispatch_wake,
		fake_dispatch_requeue, fake_dispatch_wake_op,
		fake_dispatch_invalid);
	require(dispatch_trace.wait_count == 1);
	require(dispatch_trace.clockrt == FUTEX_CLOCK_REALTIME);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.clockrt);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAKE | FUTEX_CLOCK_REALTIME, 0x1050,
		0x2a, 0x3008, 0x2050, 0x4c, 0x62, 1,
		fake_dispatch_wait, fake_dispatch_wake,
		fake_dispatch_requeue, fake_dispatch_wake_op,
		fake_dispatch_invalid);
	require(ret == -ENOSYS);
	require(dispatch_trace.invalid_count == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.invalid_count);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAIT_REQUEUE_PI | FUTEX_CLOCK_REALTIME,
		0x1060, 0x2b, 0x3009, 0x2060, 0x4d, 0x61, 0,
		fake_dispatch_wait, fake_dispatch_wake,
		fake_dispatch_requeue, fake_dispatch_wake_op,
		fake_dispatch_invalid);
	require(ret == -ENOSYS);
	require(dispatch_trace.invalid_count == 1);
	require(dispatch_trace.invalid_cmd == FUTEX_WAIT_REQUEUE_PI);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.invalid_cmd);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(99, 0x1070, 0x2c, 0x300a,
		0x2070, 0x4e, 0x60, 1, fake_dispatch_wait,
		fake_dispatch_wake, fake_dispatch_requeue,
		fake_dispatch_wake_op, fake_dispatch_invalid);
	require(ret == -ENOSYS);
	require(dispatch_trace.invalid_count == 1);
	require(dispatch_trace.invalid_cmd == 99);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.invalid_cmd);

	reset_futex_dispatch_trace();
	ret = futex_dispatch_result(FUTEX_WAIT, 0x1080, 0x2d, 0x300b,
		0x2080, 0x4f, 0x5f, 1, NULL, fake_dispatch_wake,
		fake_dispatch_requeue, fake_dispatch_wake_op,
		fake_dispatch_invalid);
	require(ret == -ENOSYS);
	require(dispatch_trace.wait_count == 0);
	require(dispatch_trace.invalid_count == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, dispatch_trace.wait_count);
	return digest;
}

static unsigned long hb_lock_log[8];
static int hb_lock_count;
static unsigned long hb_unlock_log[8];
static int hb_unlock_count;

static void reset_hb_lock_trace(void)
{
	for (int i = 0; i < 8; i++) {
		hb_lock_log[i] = 0;
		hb_unlock_log[i] = 0;
	}
	hb_lock_count = 0;
	hb_unlock_count = 0;
}

static void fake_hb_lock(unsigned long lock_addr)
{
	require(hb_lock_count < 8);
	hb_lock_log[hb_lock_count++] = lock_addr;
}

static void fake_hb_unlock(unsigned long lock_addr)
{
	require(hb_unlock_count < 8);
	hb_unlock_log[hb_unlock_count++] = lock_addr;
}

static unsigned long digest_plist_prios(struct plist_head *head);

static unsigned long futex_double_lock_digest(void)
{
	struct fake_futex_bucket buckets[2] = {
		{ .pad = 0x1111, .lock = 0xaaaa },
		{ .pad = 0x2222, .lock = 0xbbbb },
	};
	unsigned long low_hb = (unsigned long)&buckets[0];
	unsigned long high_hb = (unsigned long)&buckets[1];
	unsigned long low_lock = (unsigned long)&buckets[0].lock;
	unsigned long high_lock = (unsigned long)&buckets[1].lock;
	unsigned long lock_offset = offsetof(struct fake_futex_bucket, lock);
	unsigned long digest = 0x6675746578646c6bUL;

	reset_hb_lock_trace();
	futex_double_lock_hb_result(low_hb, high_hb, lock_offset,
		fake_hb_lock);
	futex_double_unlock_hb_result(low_hb, high_hb, lock_offset,
		fake_hb_unlock);
	require(hb_lock_count == 2);
	require(hb_unlock_count == 2);
	require(hb_lock_log[0] == low_lock);
	require(hb_lock_log[1] == high_lock);
	require(hb_unlock_log[0] == low_lock);
	require(hb_unlock_log[1] == high_lock);
	mix(&digest, hb_lock_log[0] - low_lock);
	mix(&digest, hb_lock_log[1] - low_lock);
	mix(&digest, hb_unlock_log[0] - low_lock);
	mix(&digest, hb_unlock_log[1] - low_lock);
	mix_signed(&digest, hb_lock_count);
	mix_signed(&digest, hb_unlock_count);

	reset_hb_lock_trace();
	futex_double_lock_hb_result(high_hb, low_hb, lock_offset,
		fake_hb_lock);
	futex_double_unlock_hb_result(high_hb, low_hb, lock_offset,
		fake_hb_unlock);
	require(hb_lock_count == 2);
	require(hb_unlock_count == 2);
	require(hb_lock_log[0] == low_lock);
	require(hb_lock_log[1] == high_lock);
	require(hb_unlock_log[0] == high_lock);
	require(hb_unlock_log[1] == low_lock);
	mix(&digest, hb_lock_log[0] - low_lock);
	mix(&digest, hb_lock_log[1] - low_lock);
	mix(&digest, hb_unlock_log[0] - low_lock);
	mix(&digest, hb_unlock_log[1] - low_lock);
	mix_signed(&digest, hb_lock_count);
	mix_signed(&digest, hb_unlock_count);

	reset_hb_lock_trace();
	futex_double_lock_hb_result(low_hb, low_hb, lock_offset,
		fake_hb_lock);
	futex_double_unlock_hb_result(low_hb, low_hb, lock_offset,
		fake_hb_unlock);
	require(hb_lock_count == 1);
	require(hb_unlock_count == 1);
	require(hb_lock_log[0] == low_lock);
	require(hb_unlock_log[0] == low_lock);
	mix(&digest, hb_lock_log[0] - low_lock);
	mix(&digest, hb_unlock_log[0] - low_lock);
	mix_signed(&digest, hb_lock_count);
	mix_signed(&digest, hb_unlock_count);

	reset_hb_lock_trace();
	futex_double_lock_hb_result(low_hb, high_hb, lock_offset, NULL);
	futex_double_unlock_hb_result(low_hb, high_hb, lock_offset, NULL);
	require(hb_lock_count == 0);
	require(hb_unlock_count == 0);
	mix_signed(&digest, hb_lock_count);
	mix_signed(&digest, hb_unlock_count);
	return digest;
}

static unsigned long futex_wake_mark_woken_digest(void)
{
	struct plist_head head;
	struct fake_futex_q first;
	struct fake_futex_q second;
	unsigned long digest = 0x667574657877616bUL;
	struct list_head *pos;
	int node_count = 0;
	int prio_count = 0;

	plist_head_init(&head);
	plist_node_init(&first.list, 3);
	plist_node_init(&second.list, 7);
	first.task = (void *)0x1111UL;
	first.lock_ptr = (void *)0x2222UL;
	second.task = (void *)0x3333UL;
	second.lock_ptr = (void *)0x4444UL;

	plist_add(&first.list, &head);
	plist_add(&second.list, &head);
	futex_wake_mark_woken_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));

	require(first.task == (void *)0x1111UL);
	require(first.lock_ptr == NULL);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));

	for (pos = head.node_list.next; pos != &head.node_list; pos = pos->next) {
		struct plist_node *node = plist_from_node(pos);

		require(++node_count < 8);
		mix(&digest, (unsigned long)(unsigned int)node->prio);
	}
	for (pos = head.prio_list.next; pos != &head.prio_list; pos = pos->next) {
		struct plist_node *node = plist_from_prio(pos);

		require(++prio_count < 8);
		mix(&digest, ((unsigned long)(unsigned int)node->prio) << 32);
	}

	mix(&digest, (unsigned long)node_count);
	mix(&digest, (unsigned long)prio_count << 16);
	mix(&digest, (unsigned long)second.lock_ptr);
	return digest;
}

static int wake_orch_send_rc;
static int wake_orch_send_count;
static int wake_orch_wake_count;
static int wake_orch_log_count;
static int wake_orch_last_event;
static int wake_orch_last_cpu;
static int wake_orch_last_status;
static unsigned long wake_orch_last_channel;
static unsigned long wake_orch_last_packet;
static unsigned long wake_orch_last_thread;

static void reset_wake_orch_trace(void)
{
	wake_orch_send_rc = 0;
	wake_orch_send_count = 0;
	wake_orch_wake_count = 0;
	wake_orch_log_count = 0;
	wake_orch_last_event = 0;
	wake_orch_last_cpu = 0;
	wake_orch_last_status = 0;
	wake_orch_last_channel = 0;
	wake_orch_last_packet = 0;
	wake_orch_last_thread = 0;
}

static unsigned long fake_wake_orch_linux_channel(int linux_cpu)
{
	return 0xabc00000UL + (unsigned long)(unsigned int)linux_cpu;
}

static int fake_wake_orch_send(unsigned long channel, unsigned long packet)
{
	wake_orch_send_count++;
	wake_orch_last_channel = channel;
	wake_orch_last_packet = packet;
	return wake_orch_send_rc;
}

static void fake_wake_orch_thread(unsigned long thread, int status)
{
	struct fake_thread_state *state = (struct fake_thread_state *)thread;

	wake_orch_wake_count++;
	wake_orch_last_thread = thread;
	wake_orch_last_status = status;
	state->status = status;
}

static void fake_wake_orch_log(int event, unsigned long thread,
			       unsigned long uti_futex_resp, int linux_cpu,
			       unsigned long channel, int rc)
{
	(void)thread;
	(void)uti_futex_resp;
	(void)rc;
	wake_orch_log_count++;
	wake_orch_last_event = event;
	wake_orch_last_cpu = linux_cpu;
	wake_orch_last_channel = channel;
}

static unsigned long futex_wake_orchestrate_digest(void)
{
	struct plist_head head;
	struct fake_thread_state thread = { 0 };
	struct fake_futex_q q = { 0 };
	struct fake_wake_packet packet = { 0 };
	unsigned long digest = 0x66757465776f7263UL;
	int target;

	plist_head_init(&head);
	plist_node_init(&q.list, 9);
	plist_add(&q.list, &head);
	q.task = &thread;
	q.lock_ptr = (void *)0x12345678UL;
	q.uti_futex_resp = (void *)0x77770000UL;
	q.linux_cpu = 5;

	reset_wake_orch_trace();
	target = futex_wake_orchestrate_result((unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, task),
		offsetof(struct fake_futex_q, uti_futex_resp),
		offsetof(struct fake_futex_q, linux_cpu),
		offsetof(struct fake_thread_state, spin_sleep),
		(unsigned long)&packet,
		offsetof(struct fake_wake_packet, msg),
		offsetof(struct fake_wake_packet, futex.resp),
		offsetof(struct fake_wake_packet, futex.spin_sleep),
		99, 0xeeee0000UL, 17, fake_wake_orch_linux_channel,
		fake_wake_orch_send, fake_wake_orch_thread,
		fake_wake_orch_log);
	require(target == FUTEX_WAKE_TARGET_LINUX);
	require(q.lock_ptr == NULL);
	require(plist_node_empty(&q.list));
	require(wake_orch_send_count == 1);
	require(wake_orch_wake_count == 0);
	require(wake_orch_log_count == 2);
	require(wake_orch_last_event == FUTEX_WAKE_LOG_SEND_OK);
	require(wake_orch_last_cpu == 5);
	require(wake_orch_last_channel == 0xabc00005UL);
	require(wake_orch_last_packet == (unsigned long)&packet);
	require(packet.msg == 99);
	require(packet.futex.resp == (void *)0x77770000UL);
	require(packet.futex.spin_sleep == &thread.spin_sleep);
	mix(&digest, (unsigned long)target);
	mix(&digest, wake_orch_last_channel);
	mix(&digest, (unsigned long)packet.futex.spin_sleep -
		(unsigned long)&thread);

	plist_node_init(&q.list, 4);
	plist_add(&q.list, &head);
	q.lock_ptr = (void *)0x12345678UL;
	q.uti_futex_resp = NULL;
	q.linux_cpu = 0;
	thread.status = 0;
	packet = (struct fake_wake_packet){ 0 };

	reset_wake_orch_trace();
	target = futex_wake_orchestrate_result((unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, task),
		offsetof(struct fake_futex_q, uti_futex_resp),
		offsetof(struct fake_futex_q, linux_cpu),
		offsetof(struct fake_thread_state, spin_sleep),
		(unsigned long)&packet,
		offsetof(struct fake_wake_packet, msg),
		offsetof(struct fake_wake_packet, futex.resp),
		offsetof(struct fake_wake_packet, futex.spin_sleep),
		99, 0xeeee0000UL, 23, fake_wake_orch_linux_channel,
		fake_wake_orch_send, fake_wake_orch_thread,
		fake_wake_orch_log);
	require(target == FUTEX_WAKE_TARGET_MCKERNEL);
	require(q.lock_ptr == NULL);
	require(plist_node_empty(&q.list));
	require(wake_orch_send_count == 0);
	require(wake_orch_wake_count == 1);
	require(wake_orch_log_count == 1);
	require(wake_orch_last_event == FUTEX_WAKE_LOG_MCKERNEL_TARGET);
	require(thread.status == 23);
	mix(&digest, (unsigned long)target);
	mix_signed(&digest, thread.status);
	mix_signed(&digest, wake_orch_log_count);

	return digest;
}

static unsigned long futex_unqueue_detach_digest(void)
{
	struct plist_head head;
	struct fake_futex_q first;
	struct fake_futex_q second;
	unsigned long digest = 0x6675746578756e71UL;
	int detached;

	plist_head_init(&head);
	plist_node_init(&first.list, 4);
	plist_node_init(&second.list, 6);
	first.task = (void *)0x1111UL;
	first.lock_ptr = (void *)0x2222UL;
	second.task = (void *)0x3333UL;
	second.lock_ptr = (void *)0x4444UL;

	plist_add(&first.list, &head);
	plist_add(&second.list, &head);
	detached = futex_unqueue_detach_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist));

	require(detached == 1);
	require(first.task == (void *)0x1111UL);
	require(first.lock_ptr == (void *)0x2222UL);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	mix(&digest, digest_plist_prios(&head));
	mix(&digest, (unsigned long)first.lock_ptr);
	return digest;
}

static int unqueue_me_lock_calls;
static int unqueue_me_unlock_calls;
static int unqueue_me_drop_calls;
static unsigned long unqueue_me_lock_trace[4];
static unsigned long unqueue_me_unlock_trace[4];
static unsigned long unqueue_me_drop_addr;
static struct fake_futex_q *unqueue_me_race_q;
static unsigned long unqueue_me_race_lock;

static void fake_unqueue_me_lock(unsigned long lock_addr)
{
	if (unqueue_me_lock_calls < 4)
		unqueue_me_lock_trace[unqueue_me_lock_calls] = lock_addr;
	unqueue_me_lock_calls++;
	if (unqueue_me_race_q && unqueue_me_lock_calls == 1)
		unqueue_me_race_q->lock_ptr = (void *)unqueue_me_race_lock;
}

static void fake_unqueue_me_unlock(unsigned long lock_addr)
{
	if (unqueue_me_unlock_calls < 4)
		unqueue_me_unlock_trace[unqueue_me_unlock_calls] = lock_addr;
	unqueue_me_unlock_calls++;
}

static void fake_unqueue_me_drop(unsigned long key_addr)
{
	unqueue_me_drop_calls++;
	unqueue_me_drop_addr = key_addr;
}

static void reset_unqueue_me_trace(void)
{
	unqueue_me_lock_calls = 0;
	unqueue_me_unlock_calls = 0;
	unqueue_me_drop_calls = 0;
	unqueue_me_drop_addr = 0;
	unqueue_me_race_q = NULL;
	unqueue_me_race_lock = 0;
	for (int i = 0; i < 4; i++) {
		unqueue_me_lock_trace[i] = 0;
		unqueue_me_unlock_trace[i] = 0;
	}
}

static unsigned long futex_unqueue_me_digest(void)
{
	struct plist_head head;
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	unsigned long lock1 = 0x1111222233334444UL;
	unsigned long lock2 = 0x5555666677778888UL;
	unsigned long digest = 0x6675746578756d65UL;
	int ret;

	plist_head_init(&head);
	plist_node_init(&first.list, 4);
	plist_node_init(&second.list, 6);
	first.lock_ptr = &lock1;
	second.lock_ptr = &lock2;
	plist_add(&first.list, &head);
	plist_add(&second.list, &head);
	reset_unqueue_me_trace();
	ret = futex_unqueue_me_result((unsigned long)&first,
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, key),
		fake_unqueue_me_lock, fake_unqueue_me_unlock,
		fake_unqueue_me_drop);
	require(ret == 1);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(first.lock_ptr == &lock1);
	require(unqueue_me_lock_calls == 1);
	require(unqueue_me_unlock_calls == 1);
	require(unqueue_me_lock_trace[0] == (unsigned long)&lock1);
	require(unqueue_me_unlock_trace[0] == (unsigned long)&lock1);
	require(unqueue_me_drop_calls == 1);
	require(unqueue_me_drop_addr ==
		(unsigned long)&first + offsetof(struct fake_futex_q, key));
	mix_signed(&digest, ret);
	mix(&digest, digest_plist_prios(&head));
	mix(&digest, first.lock_ptr == &lock1);
	mix_signed(&digest, unqueue_me_lock_calls);
	mix_signed(&digest, unqueue_me_unlock_calls);
	mix_signed(&digest, unqueue_me_drop_calls);

	plist_head_init(&head);
	plist_node_init(&first.list, 4);
	plist_node_init(&second.list, 6);
	first.lock_ptr = &lock1;
	second.lock_ptr = &lock2;
	plist_add(&first.list, &head);
	plist_add(&second.list, &head);
	reset_unqueue_me_trace();
	unqueue_me_race_q = &first;
	unqueue_me_race_lock = (unsigned long)&lock2;
	ret = futex_unqueue_me_result((unsigned long)&first,
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, key),
		fake_unqueue_me_lock, fake_unqueue_me_unlock,
		fake_unqueue_me_drop);
	require(ret == 1);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(first.lock_ptr == &lock2);
	require(unqueue_me_lock_calls == 2);
	require(unqueue_me_unlock_calls == 2);
	require(unqueue_me_lock_trace[0] == (unsigned long)&lock1);
	require(unqueue_me_lock_trace[1] == (unsigned long)&lock2);
	require(unqueue_me_unlock_trace[0] == (unsigned long)&lock1);
	require(unqueue_me_unlock_trace[1] == (unsigned long)&lock2);
	require(unqueue_me_drop_calls == 1);
	mix_signed(&digest, ret);
	mix(&digest, digest_plist_prios(&head));
	mix(&digest, first.lock_ptr == &lock2);
	mix_signed(&digest, unqueue_me_lock_calls);
	mix_signed(&digest, unqueue_me_unlock_calls);
	mix_signed(&digest, unqueue_me_drop_calls);

	reset_unqueue_me_trace();
	first.lock_ptr = NULL;
	ret = futex_unqueue_me_result((unsigned long)&first,
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, key),
		fake_unqueue_me_lock, fake_unqueue_me_unlock,
		fake_unqueue_me_drop);
	require(ret == 0);
	require(unqueue_me_lock_calls == 0);
	require(unqueue_me_unlock_calls == 0);
	require(unqueue_me_drop_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, unqueue_me_drop_calls);
	mix_signed(&digest, futex_unqueue_me_result(0,
		offsetof(struct fake_futex_q, lock_ptr),
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, key),
		fake_unqueue_me_lock, fake_unqueue_me_unlock,
		fake_unqueue_me_drop));
	return digest;
}

static unsigned long digest_plist_prios(struct plist_head *head)
{
	unsigned long digest = 0x706c697374707269UL;
	struct list_head *pos;
	int node_count = 0;
	int prio_count = 0;

	for (pos = head->node_list.next; pos != &head->node_list; pos = pos->next) {
		struct plist_node *node = plist_from_node(pos);

		require(++node_count < 8);
		mix(&digest, (unsigned long)(unsigned int)node->prio);
	}
	for (pos = head->prio_list.next; pos != &head->prio_list; pos = pos->next) {
		struct plist_node *node = plist_from_prio(pos);

		require(++prio_count < 8);
		mix(&digest, ((unsigned long)(unsigned int)node->prio) << 32);
	}

	mix(&digest, (unsigned long)node_count);
	mix(&digest, (unsigned long)prio_count << 16);
	return digest;
}

static int wake_scan_count;
static int wake_scan_log[8];

static void reset_wake_scan_trace(void)
{
	for (int i = 0; i < 8; i++)
		wake_scan_log[i] = 0;
	wake_scan_count = 0;
}

static void fake_wake_scan(unsigned long q_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;

	require(wake_scan_count < 8);
	wake_scan_log[wake_scan_count++] = q->linux_cpu;
	futex_wake_mark_woken_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));
}

static void init_fake_futex_q(struct fake_futex_q *q, int prio,
			      unsigned long word, unsigned long ptr,
			      unsigned long offset, unsigned int bitset,
			      int marker)
{
	plist_node_init(&q->list, prio);
	q->lock_ptr = (void *)0x51515151UL;
	q->key.opaque[0] = word;
	q->key.opaque[1] = ptr;
	q->key.opaque[2] = offset;
	q->bitset = bitset;
	q->linux_cpu = marker;
}

static unsigned long futex_wake_scan_digest(void)
{
	struct plist_head head;
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	struct fake_futex_q third = { 0 };
	struct fake_futex_q fourth = { 0 };
	unsigned long digest = 0x6675746578777363UL;
	int woken;

	plist_head_init(&head);
	init_fake_futex_q(&first, 1, 0xabcUL, 0xdefUL, 0x10UL, 0x1, 11);
	init_fake_futex_q(&second, 2, 0xabcUL, 0xbeefUL, 0x10UL, 0x1, 22);
	init_fake_futex_q(&third, 3, 0xabcUL, 0xdefUL, 0x10UL, 0x4, 33);
	init_fake_futex_q(&fourth, 4, 0xabcUL, 0xdefUL, 0x10UL, 0x2, 44);
	plist_add(&first.list, &head);
	plist_add(&second.list, &head);
	plist_add(&third.list, &head);
	plist_add(&fourth.list, &head);

	reset_wake_scan_trace();
	woken = futex_wake_scan_result((unsigned long)&head,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xabcUL, 0xdefUL, 0x10, 0x1, 1, 2,
		fake_wake_scan);
	require(woken == 1);
	require(wake_scan_count == 1);
	require(wake_scan_log[0] == 11);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&third.list));
	require(!plist_node_empty(&fourth.list));
	mix(&digest, (unsigned long)woken);
	mix(&digest, (unsigned long)wake_scan_count);
	mix(&digest, (unsigned long)wake_scan_log[0]);
	mix(&digest, digest_plist_prios(&head));

	reset_wake_scan_trace();
	woken = futex_wake_scan_result((unsigned long)&head,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xabcUL, 0xdefUL, 0x10, 0, 0, 1,
		fake_wake_scan);
	require(woken == 1);
	require(wake_scan_count == 1);
	require(wake_scan_log[0] == 33);
	require(plist_node_empty(&third.list));
	require(!plist_node_empty(&fourth.list));
	mix(&digest, (unsigned long)woken);
	mix(&digest, (unsigned long)wake_scan_log[0]);
	mix(&digest, digest_plist_prios(&head));

	reset_wake_scan_trace();
	woken = futex_wake_scan_result((unsigned long)&head,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xabcUL, 0xdefUL, 0x10, 0, 0, 0,
		fake_wake_scan);
	require(woken == 1);
	require(wake_scan_count == 1);
	require(wake_scan_log[0] == 44);
	require(plist_node_empty(&fourth.list));
	mix(&digest, (unsigned long)woken);
	mix(&digest, (unsigned long)wake_scan_log[0]);
	mix(&digest, digest_plist_prios(&head));

	woken = futex_wake_scan_result((unsigned long)&head,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xabcUL, 0xdefUL, 0x10, 0, 0, 1, NULL);
	require(woken == 0);
	mix(&digest, (unsigned long)woken);

	return digest;
}

static int wake_body_get_key_calls;
static int wake_body_hash_calls;
static int wake_body_lock_calls;
static int wake_body_unlock_calls;
static int wake_body_put_key_calls;
static int wake_body_get_key_rc;
static unsigned long wake_body_hash_addr;
static unsigned long wake_body_last_lock;
static unsigned long wake_body_last_irqstate;
static unsigned long wake_body_last_put_key;

static void reset_wake_body_trace(void)
{
	wake_body_get_key_calls = 0;
	wake_body_hash_calls = 0;
	wake_body_lock_calls = 0;
	wake_body_unlock_calls = 0;
	wake_body_put_key_calls = 0;
	wake_body_get_key_rc = 0;
	wake_body_hash_addr = 0;
	wake_body_last_lock = 0;
	wake_body_last_irqstate = 0;
	wake_body_last_put_key = 0;
	reset_wake_scan_trace();
}

static int fake_wake_body_get_key(unsigned long uaddr, int fshared,
				  unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(uaddr == 0x505000UL);
	require(fshared == 1);
	wake_body_get_key_calls++;
	if (wake_body_get_key_rc)
		return wake_body_get_key_rc;
	key->opaque[0] = 0xabcUL;
	key->opaque[1] = 0xdefUL;
	key->opaque[2] = 0x10UL;
	return 0;
}

static unsigned long fake_wake_body_hash(unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(key->opaque[0] == 0xabcUL);
	require(key->opaque[1] == 0xdefUL);
	require(key->opaque[2] == 0x10UL);
	wake_body_hash_calls++;
	return wake_body_hash_addr;
}

static unsigned long fake_wake_body_lock(unsigned long lock_addr)
{
	wake_body_lock_calls++;
	wake_body_last_lock = lock_addr;
	return lock_addr ^ 0xabcdef1234567890UL;
}

static void fake_wake_body_unlock(unsigned long lock_addr,
				  unsigned long irqstate)
{
	wake_body_unlock_calls++;
	wake_body_last_lock = lock_addr;
	wake_body_last_irqstate = irqstate;
}

static void fake_wake_body_put_key(int fshared, unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(fshared == 1);
	wake_body_put_key_calls++;
	wake_body_last_put_key = key_addr;
	key->opaque[0] = 0;
	key->opaque[1] = 0;
	key->opaque[2] = 0;
}

static unsigned long futex_wake_body_digest(void)
{
	struct fake_wake_body_bucket bucket = { 0 };
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	struct fake_futex_q third = { 0 };
	struct futex_key key = { { 0 } };
	unsigned long digest = 0x667574657877626fUL;
	int ret;

	plist_head_init(&bucket.chain);
	bucket.lock = 0x51525354UL;
	init_fake_futex_q(&first, 1, 0xabcUL, 0xdefUL, 0x10UL, 0x1, 11);
	init_fake_futex_q(&second, 2, 0xabcUL, 0xdefUL, 0x10UL, 0x4, 22);
	init_fake_futex_q(&third, 3, 0xabcUL, 0xbeefUL, 0x10UL, 0x1, 33);
	plist_add(&first.list, &bucket.chain);
	plist_add(&second.list, &bucket.chain);
	plist_add(&third.list, &bucket.chain);

	reset_wake_body_trace();
	wake_body_hash_addr = (unsigned long)&bucket;
	ret = futex_wake_body_result(0x505000UL, 1, 1, 0x1,
		(unsigned long)&key,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		fake_wake_body_get_key, fake_wake_body_hash,
		fake_wake_body_lock, fake_wake_body_unlock,
		fake_wake_body_put_key, fake_wake_scan);
	require(ret == 1);
	require(wake_body_get_key_calls == 1);
	require(wake_body_hash_calls == 1);
	require(wake_body_lock_calls == 1);
	require(wake_body_unlock_calls == 1);
	require(wake_body_put_key_calls == 1);
	require(wake_scan_count == 1);
	require(wake_scan_log[0] == 11);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(!plist_node_empty(&third.list));
	require(wake_body_last_lock ==
		(unsigned long)&bucket + offsetof(struct fake_wake_body_bucket, lock));
	require(wake_body_last_irqstate ==
		(wake_body_last_lock ^ 0xabcdef1234567890UL));
	require(wake_body_last_put_key == (unsigned long)&key);
	require(key.opaque[0] == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_body_get_key_calls);
	mix_signed(&digest, wake_body_lock_calls);
	mix_signed(&digest, wake_body_put_key_calls);
	mix_signed(&digest, wake_scan_log[0]);
	mix(&digest, digest_plist_prios(&bucket.chain));

	reset_wake_body_trace();
	wake_body_hash_addr = (unsigned long)&bucket;
	wake_body_get_key_rc = -5;
	ret = futex_wake_body_result(0x505000UL, 1, 1, 0x1,
		(unsigned long)&key,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		fake_wake_body_get_key, fake_wake_body_hash,
		fake_wake_body_lock, fake_wake_body_unlock,
		fake_wake_body_put_key, fake_wake_scan);
	require(ret == -5);
	require(wake_body_get_key_calls == 1);
	require(wake_body_hash_calls == 0);
	require(wake_body_put_key_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_body_hash_calls);

	reset_wake_body_trace();
	ret = futex_wake_body_result(0x505000UL, 1, 1, 0,
		(unsigned long)&key,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		fake_wake_body_get_key, fake_wake_body_hash,
		fake_wake_body_lock, fake_wake_body_unlock,
		fake_wake_body_put_key, fake_wake_scan);
	require(ret == -22);
	require(wake_body_get_key_calls == 0);
	require(wake_body_put_key_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_body_get_key_calls);

	reset_wake_body_trace();
	ret = futex_wake_body_result(0x505000UL, 1, 1, 0x1,
		(unsigned long)&key,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		fake_wake_body_get_key, fake_wake_body_hash,
		fake_wake_body_lock, fake_wake_body_unlock,
		fake_wake_body_put_key, fake_wake_scan);
	require(ret == -22);
	require(wake_body_get_key_calls == 1);
	require(wake_body_hash_calls == 1);
	require(wake_body_lock_calls == 0);
	require(wake_body_put_key_calls == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_body_put_key_calls);

	return digest;
}

static int wake_op_get_key_calls;
static int wake_op_hash_calls;
static int wake_op_lock_calls;
static int wake_op_unlock_calls;
static int wake_op_atomic_calls;
static int wake_op_put_key_calls;
static int wake_op_key1_rc;
static int wake_op_key2_rc;
static int wake_op_atomic_seq[8];
static int wake_op_atomic_count;
static unsigned long wake_op_source_bucket;
static unsigned long wake_op_target_bucket;
static unsigned long wake_op_lock_log[8];
static unsigned long wake_op_unlock_log[8];
static unsigned long wake_op_put_key_log[8];

static void reset_wake_op_trace(void)
{
	wake_op_get_key_calls = 0;
	wake_op_hash_calls = 0;
	wake_op_lock_calls = 0;
	wake_op_unlock_calls = 0;
	wake_op_atomic_calls = 0;
	wake_op_put_key_calls = 0;
	wake_op_key1_rc = 0;
	wake_op_key2_rc = 0;
	wake_op_atomic_count = 0;
	wake_op_source_bucket = 0;
	wake_op_target_bucket = 0;
	for (int i = 0; i < 8; i++) {
		wake_op_atomic_seq[i] = 0;
		wake_op_lock_log[i] = 0;
		wake_op_unlock_log[i] = 0;
		wake_op_put_key_log[i] = 0;
	}
	reset_wake_scan_trace();
}

static int fake_wake_op_get_key(unsigned long uaddr, int fshared,
				unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	wake_op_get_key_calls++;
	if (uaddr == 0x7000UL) {
		if (wake_op_key1_rc)
			return wake_op_key1_rc;
		key->opaque[0] = 0x1111UL;
		key->opaque[1] = 0x2222UL;
		key->opaque[2] = 0x10UL;
		return 0;
	}
	require(uaddr == 0x8000UL);
	if (wake_op_key2_rc)
		return wake_op_key2_rc;
	key->opaque[0] = 0x3333UL;
	key->opaque[1] = 0x4444UL;
	key->opaque[2] = 0x20UL;
	(void)fshared;
	return 0;
}

static unsigned long fake_wake_op_hash(unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	wake_op_hash_calls++;
	if (key->opaque[0] == 0x1111UL)
		return wake_op_source_bucket;
	require(key->opaque[0] == 0x3333UL);
	return wake_op_target_bucket;
}

static void fake_wake_op_lock(unsigned long lock_addr)
{
	require(wake_op_lock_calls < 8);
	wake_op_lock_log[wake_op_lock_calls++] = lock_addr;
}

static void fake_wake_op_unlock(unsigned long lock_addr)
{
	require(wake_op_unlock_calls < 8);
	wake_op_unlock_log[wake_op_unlock_calls++] = lock_addr;
}

static int fake_wake_op_atomic(int op, unsigned long uaddr)
{
	require(op == 0x5a);
	require(uaddr == 0x8000UL);
	require(wake_op_atomic_calls < 8);
	return wake_op_atomic_seq[wake_op_atomic_calls++];
}

static void fake_wake_op_put_key(int fshared, unsigned long key_addr)
{
	require(wake_op_put_key_calls < 8);
	wake_op_put_key_log[wake_op_put_key_calls++] = key_addr;
	(void)fshared;
}

static int call_wake_op_body(int fshared, struct futex_key *key1,
			     struct futex_key *key2, int nr_wake,
			     int nr_wake2)
{
	return futex_wake_op_body_result(0x7000UL, fshared, 0x8000UL,
		nr_wake, nr_wake2, 0x5a, (unsigned long)key1,
		(unsigned long)key2,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		fake_wake_op_get_key, fake_wake_op_hash,
		fake_wake_op_lock, fake_wake_op_unlock,
		fake_wake_op_atomic, fake_wake_op_put_key,
		fake_wake_scan);
}

static unsigned long futex_wake_op_body_digest(void)
{
	struct fake_wake_body_bucket source = { 0 };
	struct fake_wake_body_bucket target = { 0 };
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	struct fake_futex_q third = { 0 };
	struct fake_futex_q fourth = { 0 };
	struct futex_key key1 = { { 0 } };
	struct futex_key key2 = { { 0 } };
	unsigned long digest = 0x6675746578776f70UL;
	int ret;

	plist_head_init(&source.chain);
	plist_head_init(&target.chain);
	source.lock = 0x11110000UL;
	target.lock = 0x22220000UL;
	init_fake_futex_q(&first, 1, 0x1111UL, 0x2222UL, 0x10UL, 0, 11);
	init_fake_futex_q(&second, 2, 0x1111UL, 0x9999UL, 0x10UL, 0, 22);
	init_fake_futex_q(&third, 3, 0x3333UL, 0x4444UL, 0x20UL, 0, 33);
	plist_add(&first.list, &source.chain);
	plist_add(&second.list, &source.chain);
	plist_add(&third.list, &target.chain);

	reset_wake_op_trace();
	wake_op_source_bucket = (unsigned long)&source;
	wake_op_target_bucket = (unsigned long)&target;
	wake_op_atomic_seq[0] = 1;
	ret = call_wake_op_body(1, &key1, &key2, 1, 1);
	require(ret == 2);
	require(wake_op_get_key_calls == 2);
	require(wake_op_hash_calls == 2);
	require(wake_op_lock_calls == 2);
	require(wake_op_unlock_calls == 2);
	require(wake_op_atomic_calls == 1);
	require(wake_op_put_key_calls == 2);
	require(wake_scan_count == 2);
	require(wake_scan_log[0] == 11);
	require(wake_scan_log[1] == 33);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(plist_node_empty(&third.list));
	require(wake_op_put_key_log[0] == (unsigned long)&key2);
	require(wake_op_put_key_log[1] == (unsigned long)&key1);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_op_lock_calls);
	mix_signed(&digest, wake_op_unlock_calls);
	mix_signed(&digest, wake_scan_log[0]);
	mix_signed(&digest, wake_scan_log[1]);
	mix(&digest, digest_plist_prios(&source.chain));
	mix(&digest, digest_plist_prios(&target.chain));

	plist_head_init(&source.chain);
	plist_head_init(&target.chain);
	init_fake_futex_q(&first, 1, 0x1111UL, 0x2222UL, 0x10UL, 0, 44);
	init_fake_futex_q(&third, 3, 0x3333UL, 0x4444UL, 0x20UL, 0, 55);
	plist_add(&first.list, &source.chain);
	plist_add(&third.list, &target.chain);
	reset_wake_op_trace();
	wake_op_source_bucket = (unsigned long)&source;
	wake_op_target_bucket = (unsigned long)&target;
	wake_op_atomic_seq[0] = 0;
	ret = call_wake_op_body(1, &key1, &key2, 1, 1);
	require(ret == 1);
	require(wake_scan_count == 1);
	require(wake_scan_log[0] == 44);
	require(!plist_node_empty(&third.list));
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_scan_count);
	mix_signed(&digest, wake_scan_log[0]);
	mix(&digest, digest_plist_prios(&target.chain));

	reset_wake_op_trace();
	wake_op_source_bucket = (unsigned long)&source;
	wake_op_target_bucket = (unsigned long)&target;
	wake_op_atomic_seq[0] = -5;
	ret = call_wake_op_body(1, &key1, &key2, 1, 1);
	require(ret == -5);
	require(wake_op_lock_calls == 2);
	require(wake_op_unlock_calls == 2);
	require(wake_op_put_key_calls == 2);
	require(wake_scan_count == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_op_put_key_calls);

	plist_head_init(&source.chain);
	init_fake_futex_q(&fourth, 4, 0x1111UL, 0x2222UL, 0x10UL, 0, 66);
	plist_add(&fourth.list, &source.chain);
	reset_wake_op_trace();
	wake_op_source_bucket = (unsigned long)&source;
	wake_op_target_bucket = (unsigned long)&target;
	wake_op_atomic_seq[0] = -EFAULT;
	wake_op_atomic_seq[1] = 0;
	ret = call_wake_op_body(0, &key1, &key2, 1, 1);
	require(ret == 1);
	require(wake_op_get_key_calls == 2);
	require(wake_op_atomic_calls == 2);
	require(wake_op_lock_calls == 4);
	require(wake_op_unlock_calls == 4);
	require(wake_op_put_key_calls == 2);
	require(wake_scan_log[0] == 66);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_op_atomic_calls);
	mix_signed(&digest, wake_op_lock_calls);

	plist_head_init(&source.chain);
	init_fake_futex_q(&fourth, 4, 0x1111UL, 0x2222UL, 0x10UL, 0, 77);
	plist_add(&fourth.list, &source.chain);
	reset_wake_op_trace();
	wake_op_source_bucket = (unsigned long)&source;
	wake_op_target_bucket = (unsigned long)&target;
	wake_op_atomic_seq[0] = -EFAULT;
	wake_op_atomic_seq[1] = 0;
	ret = call_wake_op_body(1, &key1, &key2, 1, 1);
	require(ret == 1);
	require(wake_op_get_key_calls == 4);
	require(wake_op_atomic_calls == 2);
	require(wake_op_put_key_calls == 4);
	require(wake_scan_log[0] == 77);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_op_get_key_calls);
	mix_signed(&digest, wake_op_put_key_calls);

	reset_wake_op_trace();
	wake_op_key2_rc = -6;
	ret = call_wake_op_body(1, &key1, &key2, 1, 1);
	require(ret == -6);
	require(wake_op_get_key_calls == 2);
	require(wake_op_hash_calls == 0);
	require(wake_op_put_key_calls == 1);
	require(wake_op_put_key_log[0] == (unsigned long)&key1);
	mix_signed(&digest, ret);
	mix_signed(&digest, wake_op_put_key_calls);

	return digest;
}

static unsigned long futex_requeue_move_digest(void)
{
	struct plist_head source;
	struct plist_head target;
	struct fake_futex_q first;
	struct fake_futex_q second;
	unsigned long source_lock = 0x51515151UL;
	unsigned long target_lock = 0x71717171UL;
	unsigned long digest = 0x6675746578726571UL;
	int moved;

	plist_head_init(&source);
	plist_head_init(&target);
	plist_node_init(&first.list, 2);
	plist_node_init(&second.list, 9);
	first.task = (void *)0x1111UL;
	first.lock_ptr = &source_lock;
	second.task = (void *)0x2222UL;
	second.lock_ptr = &source_lock;

	plist_add(&first.list, &source);
	plist_add(&second.list, &source);
	moved = futex_requeue_move_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&source,
		(unsigned long)&target,
		(unsigned long)&target_lock,
		0);
	require(moved == 1);
	require(first.lock_ptr == &target_lock);
	require(!plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	mix(&digest, digest_plist_prios(&source));
	mix(&digest, digest_plist_prios(&target));

	moved = futex_requeue_move_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&target,
		(unsigned long)&target,
		(unsigned long)&source_lock,
		0);
	require(moved == 0);
	require(first.lock_ptr == &target_lock);
	mix(&digest, digest_plist_prios(&source));
	mix(&digest, digest_plist_prios(&target));
	return digest;
}

static int key_ref_count;
static unsigned long key_ref_log[8];
static struct futex_key key_ref_snapshot[8];

static void reset_key_ref_trace(void)
{
	for (int i = 0; i < 8; i++) {
		key_ref_log[i] = 0;
		key_ref_snapshot[i].opaque[0] = 0;
		key_ref_snapshot[i].opaque[1] = 0;
		key_ref_snapshot[i].opaque[2] = 0;
	}
	key_ref_count = 0;
}

static void fake_key_refs(unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(key_ref_count < 8);
	key_ref_log[key_ref_count] = key_addr;
	key_ref_snapshot[key_ref_count] = *key;
	key_ref_count++;
}

static unsigned long futex_requeue_key_update_digest(void)
{
	struct fake_futex_q q = { 0 };
	struct futex_key key = { .opaque = {
		0x1111222233334444UL,
		0x5555666677778888UL,
		0x9999aaaabbbbccccUL,
	} };
	unsigned long digest = 0x6675746578726b65UL;
	int ret;

	q.key.opaque[0] = 0xaaaaaaaaaaaaaaaaUL;
	q.key.opaque[1] = 0xbbbbbbbbbbbbbbbbUL;
	q.key.opaque[2] = 0xccccccccccccccccUL;

	reset_key_ref_trace();
	ret = futex_requeue_key_update_result((unsigned long)&q,
		offsetof(struct fake_futex_q, key),
		(unsigned long)&key, sizeof(key), fake_key_refs);
	require(ret == 0);
	require(key_ref_count == 1);
	require(key_ref_log[0] == (unsigned long)&key);
	require(key_ref_snapshot[0].opaque[0] == key.opaque[0]);
	require(key_ref_snapshot[0].opaque[1] == key.opaque[1]);
	require(key_ref_snapshot[0].opaque[2] == key.opaque[2]);
	require(q.key.opaque[0] == key.opaque[0]);
	require(q.key.opaque[1] == key.opaque[1]);
	require(q.key.opaque[2] == key.opaque[2]);
	mix_signed(&digest, ret);
	mix_signed(&digest, key_ref_count);
	mix(&digest, q.key.opaque[0]);
	mix(&digest, q.key.opaque[1]);
	mix(&digest, q.key.opaque[2]);

	mix_signed(&digest, futex_requeue_key_update_result(0,
		offsetof(struct fake_futex_q, key), (unsigned long)&key,
		sizeof(key), fake_key_refs));
	mix_signed(&digest, futex_requeue_key_update_result((unsigned long)&q,
		offsetof(struct fake_futex_q, key), 0, sizeof(key),
		fake_key_refs));
	mix_signed(&digest, futex_requeue_key_update_result((unsigned long)&q,
		offsetof(struct fake_futex_q, key), (unsigned long)&key, 0,
		fake_key_refs));
	mix_signed(&digest, futex_requeue_key_update_result((unsigned long)&q,
		offsetof(struct fake_futex_q, key), (unsigned long)&key,
		sizeof(key), NULL));

	return digest;
}

struct fake_requeue_context {
	struct plist_head *source;
	struct plist_head *target;
	unsigned long target_lock;
	struct futex_key target_key;
	int wake_count;
	int requeue_count;
	int wake_log[8];
	int requeue_log[8];
};

static void fake_requeue_wake(unsigned long q_addr, unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_requeue_context *ctx =
		(struct fake_requeue_context *)ctx_addr;

	require(ctx->wake_count < 8);
	ctx->wake_log[ctx->wake_count++] = q->linux_cpu;
	futex_wake_mark_woken_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));
}

static void fake_requeue_move(unsigned long q_addr, unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_requeue_context *ctx =
		(struct fake_requeue_context *)ctx_addr;

	require(ctx->requeue_count < 8);
	ctx->requeue_log[ctx->requeue_count++] = q->linux_cpu;
	futex_requeue_move_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)ctx->source,
		(unsigned long)ctx->target,
		ctx->target_lock, 0);
	q->key = ctx->target_key;
}

static unsigned long futex_requeue_scan_digest(void)
{
	struct plist_head source;
	struct plist_head target;
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	struct fake_futex_q third = { 0 };
	struct fake_futex_q fourth = { 0 };
	struct fake_futex_q fifth = { 0 };
	struct fake_requeue_context ctx;
	unsigned long digest = 0x6675746578727363UL;
	int task_count;
	int drop_count = -1;

	memset(&ctx, 0, sizeof(ctx));
	plist_head_init(&source);
	plist_head_init(&target);
	ctx.source = &source;
	ctx.target = &target;
	ctx.target_lock = 0x77770000UL;
	ctx.target_key.opaque[0] = 0x2222UL;
	ctx.target_key.opaque[1] = 0x3333UL;
	ctx.target_key.opaque[2] = 0x44UL;

	init_fake_futex_q(&first, 1, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 11);
	init_fake_futex_q(&second, 2, 0xaaaaUL, 0xccccUL, 0x10UL, 0, 22);
	init_fake_futex_q(&third, 3, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 33);
	init_fake_futex_q(&fourth, 4, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 44);
	init_fake_futex_q(&fifth, 5, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 55);
	plist_add(&first.list, &source);
	plist_add(&second.list, &source);
	plist_add(&third.list, &source);
	plist_add(&fourth.list, &source);
	plist_add(&fifth.list, &source);

	task_count = futex_requeue_scan_result((unsigned long)&source,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xaaaaUL, 0xbbbbUL, 0x10, 1, 2, &drop_count,
		fake_requeue_wake, fake_requeue_move, (unsigned long)&ctx);
	require(task_count == 3);
	require(drop_count == 2);
	require(ctx.wake_count == 1);
	require(ctx.requeue_count == 2);
	require(ctx.wake_log[0] == 11);
	require(ctx.requeue_log[0] == 33);
	require(ctx.requeue_log[1] == 44);
	require(plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(!plist_node_empty(&fifth.list));
	require(third.lock_ptr == (void *)ctx.target_lock);
	require(fourth.lock_ptr == (void *)ctx.target_lock);
	require(third.key.opaque[0] == ctx.target_key.opaque[0]);
	require(fourth.key.opaque[1] == ctx.target_key.opaque[1]);
	mix(&digest, (unsigned long)task_count);
	mix(&digest, (unsigned long)drop_count);
	mix(&digest, (unsigned long)ctx.wake_log[0]);
	mix(&digest, (unsigned long)ctx.requeue_log[0]);
	mix(&digest, (unsigned long)ctx.requeue_log[1]);
	mix(&digest, digest_plist_prios(&source));
	mix(&digest, digest_plist_prios(&target));

	ctx.source = &source;
	ctx.target = &source;
	ctx.wake_count = 0;
	ctx.requeue_count = 0;
	drop_count = -1;
	task_count = futex_requeue_scan_result((unsigned long)&source,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xaaaaUL, 0xbbbbUL, 0x10, 0, 1, &drop_count,
		fake_requeue_wake, fake_requeue_move, (unsigned long)&ctx);
	require(task_count == 1);
	require(drop_count == 1);
	require(ctx.wake_count == 0);
	require(ctx.requeue_count == 1);
	require(ctx.requeue_log[0] == 55);
	require(fifth.key.opaque[0] == ctx.target_key.opaque[0]);
	require(!plist_node_empty(&fifth.list));
	mix(&digest, (unsigned long)task_count);
	mix(&digest, (unsigned long)drop_count);
	mix(&digest, (unsigned long)ctx.requeue_log[0]);
	mix(&digest, digest_plist_prios(&source));

	drop_count = -1;
	task_count = futex_requeue_scan_result((unsigned long)&source,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		0xaaaaUL, 0xbbbbUL, 0x10, 1, 1, &drop_count,
		NULL, fake_requeue_move, (unsigned long)&ctx);
	require(task_count == 0);
	require(drop_count == 0);
	mix(&digest, (unsigned long)task_count);
	mix(&digest, (unsigned long)drop_count);

	return digest;
}

struct fake_requeue_body_context {
	struct fake_wake_body_bucket *hb1;
	struct fake_wake_body_bucket *hb2;
	struct futex_key *key2;
	int wake_count;
	int move_count;
	int wake_log[8];
	int move_log[8];
};

static int requeue_body_get_key_calls;
static int requeue_body_hash_calls;
static int requeue_body_lock_calls;
static int requeue_body_unlock_calls;
static int requeue_body_get_value_calls;
static int requeue_body_put_key_calls;
static int requeue_body_drop_key_calls;
static int requeue_body_key1_rc;
static int requeue_body_key2_rc;
static int requeue_body_get_value_rc;
static int requeue_body_hash_zero_target;
static unsigned long requeue_body_source_bucket;
static unsigned long requeue_body_target_bucket;
static unsigned long requeue_body_lock_log[8];
static unsigned long requeue_body_unlock_log[8];
static unsigned long requeue_body_put_key_log[8];
static unsigned long requeue_body_drop_key_log[8];
static unsigned int requeue_body_curval;

static void reset_requeue_body_trace(void)
{
	requeue_body_get_key_calls = 0;
	requeue_body_hash_calls = 0;
	requeue_body_lock_calls = 0;
	requeue_body_unlock_calls = 0;
	requeue_body_get_value_calls = 0;
	requeue_body_put_key_calls = 0;
	requeue_body_drop_key_calls = 0;
	requeue_body_key1_rc = 0;
	requeue_body_key2_rc = 0;
	requeue_body_get_value_rc = 0;
	requeue_body_hash_zero_target = 0;
	requeue_body_source_bucket = 0;
	requeue_body_target_bucket = 0;
	requeue_body_curval = 0;
	for (int i = 0; i < 8; i++) {
		requeue_body_lock_log[i] = 0;
		requeue_body_unlock_log[i] = 0;
		requeue_body_put_key_log[i] = 0;
		requeue_body_drop_key_log[i] = 0;
	}
	reset_key_ref_trace();
}

static int fake_requeue_body_get_key(unsigned long uaddr, int fshared,
				     unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(fshared == 1);
	requeue_body_get_key_calls++;
	if (uaddr == 0x1000UL) {
		if (requeue_body_key1_rc)
			return requeue_body_key1_rc;
		key->opaque[0] = 0xaaaaUL;
		key->opaque[1] = 0xbbbbUL;
		key->opaque[2] = 0x10UL;
		return 0;
	}
	require(uaddr == 0x2000UL);
	if (requeue_body_key2_rc)
		return requeue_body_key2_rc;
	key->opaque[0] = 0x2222UL;
	key->opaque[1] = 0x3333UL;
	key->opaque[2] = 0x44UL;
	return 0;
}

static unsigned long fake_requeue_body_hash(unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	requeue_body_hash_calls++;
	if (key->opaque[0] == 0xaaaaUL)
		return requeue_body_source_bucket;
	require(key->opaque[0] == 0x2222UL);
	if (requeue_body_hash_zero_target)
		return 0;
	return requeue_body_target_bucket;
}

static void fake_requeue_body_lock(unsigned long lock_addr)
{
	require(requeue_body_lock_calls < 8);
	requeue_body_lock_log[requeue_body_lock_calls++] = lock_addr;
}

static void fake_requeue_body_unlock(unsigned long lock_addr)
{
	require(requeue_body_unlock_calls < 8);
	requeue_body_unlock_log[requeue_body_unlock_calls++] = lock_addr;
}

static int fake_requeue_body_get_value(unsigned long value_addr,
				       unsigned long uaddr)
{
	require(uaddr == 0x1000UL);
	requeue_body_get_value_calls++;
	*(unsigned int *)value_addr = requeue_body_curval;
	return requeue_body_get_value_rc;
}

static void fake_requeue_body_put_key(int fshared, unsigned long key_addr)
{
	require(fshared == 1);
	require(requeue_body_put_key_calls < 8);
	requeue_body_put_key_log[requeue_body_put_key_calls++] = key_addr;
}

static void fake_requeue_body_drop_key(unsigned long key_addr)
{
	require(requeue_body_drop_key_calls < 8);
	requeue_body_drop_key_log[requeue_body_drop_key_calls++] = key_addr;
}

static void fake_requeue_body_wake(unsigned long q_addr, unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_requeue_body_context *ctx =
		(struct fake_requeue_body_context *)ctx_addr;

	require(ctx->hb1 == (struct fake_wake_body_bucket *)
		requeue_body_source_bucket);
	require(ctx->hb2 == (struct fake_wake_body_bucket *)
		requeue_body_target_bucket);
	require(ctx->wake_count < 8);
	ctx->wake_log[ctx->wake_count++] = q->linux_cpu;
	futex_wake_mark_woken_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));
}

static void fake_requeue_body_move(unsigned long q_addr, unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_requeue_body_context *ctx =
		(struct fake_requeue_body_context *)ctx_addr;

	require(ctx->hb1 == (struct fake_wake_body_bucket *)
		requeue_body_source_bucket);
	require(ctx->hb2 == (struct fake_wake_body_bucket *)
		requeue_body_target_bucket);
	require(ctx->key2 != NULL);
	require(ctx->move_count < 8);
	ctx->move_log[ctx->move_count++] = q->linux_cpu;
	futex_requeue_move_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&ctx->hb1->chain,
		(unsigned long)&ctx->hb2->chain,
		(unsigned long)&ctx->hb2->lock, 0);
	futex_requeue_key_update_result(q_addr,
		offsetof(struct fake_futex_q, key),
		(unsigned long)ctx->key2, sizeof(*ctx->key2),
		fake_key_refs);
}

static int call_requeue_body(struct futex_key *key1, struct futex_key *key2,
			     struct fake_requeue_body_context *ctx,
			     unsigned int *cmpval, int nr_wake,
			     int nr_requeue)
{
	return futex_requeue_body_result(0x1000UL, 1, 0x2000UL, nr_wake,
		nr_requeue, (unsigned long)cmpval, (unsigned long)key1,
		(unsigned long)key2, (unsigned long)ctx,
		offsetof(struct fake_wake_body_bucket, lock),
		offsetof(struct fake_wake_body_bucket, chain),
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, key),
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		offsetof(struct fake_requeue_body_context, hb1),
		offsetof(struct fake_requeue_body_context, hb2),
		offsetof(struct fake_requeue_body_context, key2),
		fake_requeue_body_get_key, fake_requeue_body_hash,
		fake_requeue_body_lock, fake_requeue_body_unlock,
		fake_requeue_body_get_value, fake_requeue_body_put_key,
		fake_requeue_body_drop_key, fake_requeue_body_wake,
		fake_requeue_body_move);
}

static unsigned long futex_requeue_body_digest(void)
{
	struct fake_wake_body_bucket source = { 0 };
	struct fake_wake_body_bucket target = { 0 };
	struct fake_futex_q first = { 0 };
	struct fake_futex_q second = { 0 };
	struct fake_futex_q third = { 0 };
	struct fake_futex_q fourth = { 0 };
	struct fake_requeue_body_context ctx = { 0 };
	struct futex_key key1 = { { 0 } };
	struct futex_key key2 = { { 0 } };
	unsigned int cmpval = 0x12345678U;
	unsigned long digest = 0x667574657872626fUL;
	int ret;

	plist_head_init(&source.chain);
	plist_head_init(&target.chain);
	source.lock = 0x51525354UL;
	target.lock = 0x61626364UL;
	init_fake_futex_q(&first, 1, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 11);
	init_fake_futex_q(&second, 2, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 22);
	init_fake_futex_q(&third, 3, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 33);
	plist_add(&first.list, &source.chain);
	plist_add(&second.list, &source.chain);
	plist_add(&third.list, &source.chain);

	reset_requeue_body_trace();
	requeue_body_source_bucket = (unsigned long)&source;
	requeue_body_target_bucket = (unsigned long)&target;
	requeue_body_curval = cmpval;
	ret = call_requeue_body(&key1, &key2, &ctx, &cmpval, 1, 2);
	require(ret == 3);
	require(requeue_body_get_key_calls == 2);
	require(requeue_body_hash_calls == 2);
	require(requeue_body_lock_calls == 2);
	require(requeue_body_unlock_calls == 2);
	require(requeue_body_get_value_calls == 1);
	require(requeue_body_put_key_calls == 2);
	require(requeue_body_put_key_log[0] == (unsigned long)&key2);
	require(requeue_body_put_key_log[1] == (unsigned long)&key1);
	require(requeue_body_drop_key_calls == 2);
	require(ctx.wake_count == 1);
	require(ctx.move_count == 2);
	require(ctx.wake_log[0] == 11);
	require(ctx.move_log[0] == 22);
	require(ctx.move_log[1] == 33);
	require(key_ref_count == 2);
	require(plist_node_empty(&first.list));
	require(second.lock_ptr == &target.lock);
	require(third.lock_ptr == &target.lock);
	require(second.key.opaque[0] == key2.opaque[0]);
	require(third.key.opaque[1] == key2.opaque[1]);
	mix_signed(&digest, ret);
	mix_signed(&digest, requeue_body_lock_calls);
	mix_signed(&digest, requeue_body_unlock_calls);
	mix_signed(&digest, requeue_body_drop_key_calls);
	mix_signed(&digest, ctx.wake_log[0]);
	mix_signed(&digest, ctx.move_log[0]);
	mix_signed(&digest, ctx.move_log[1]);
	mix(&digest, digest_plist_prios(&source.chain));
	mix(&digest, digest_plist_prios(&target.chain));

	plist_head_init(&source.chain);
	plist_head_init(&target.chain);
	memset(&ctx, 0, sizeof(ctx));
	init_fake_futex_q(&fourth, 4, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 44);
	plist_add(&fourth.list, &source.chain);
	reset_requeue_body_trace();
	requeue_body_source_bucket = (unsigned long)&source;
	requeue_body_target_bucket = (unsigned long)&target;
	requeue_body_curval = 0;
	ret = call_requeue_body(&key1, &key2, &ctx, &cmpval, 1, 1);
	require(ret == -11);
	require(requeue_body_get_value_calls == 1);
	require(requeue_body_put_key_calls == 2);
	require(requeue_body_drop_key_calls == 0);
	require(ctx.wake_count == 0);
	require(ctx.move_count == 0);
	require(!plist_node_empty(&fourth.list));
	mix_signed(&digest, ret);
	mix_signed(&digest, requeue_body_put_key_calls);
	mix_signed(&digest, ctx.wake_count);
	mix(&digest, digest_plist_prios(&source.chain));

	reset_requeue_body_trace();
	requeue_body_source_bucket = (unsigned long)&source;
	requeue_body_target_bucket = (unsigned long)&target;
	requeue_body_key2_rc = -6;
	ret = call_requeue_body(&key1, &key2, &ctx, NULL, 1, 1);
	require(ret == -6);
	require(requeue_body_get_key_calls == 2);
	require(requeue_body_hash_calls == 0);
	require(requeue_body_put_key_calls == 1);
	require(requeue_body_put_key_log[0] == (unsigned long)&key1);
	mix_signed(&digest, ret);
	mix_signed(&digest, requeue_body_put_key_calls);

	reset_requeue_body_trace();
	requeue_body_source_bucket = (unsigned long)&source;
	requeue_body_target_bucket = (unsigned long)&target;
	requeue_body_hash_zero_target = 1;
	ret = call_requeue_body(&key1, &key2, &ctx, NULL, 1, 1);
	require(ret == -22);
	require(requeue_body_hash_calls == 2);
	require(requeue_body_lock_calls == 0);
	require(requeue_body_put_key_calls == 2);
	mix_signed(&digest, ret);
	mix_signed(&digest, requeue_body_hash_calls);

	plist_head_init(&source.chain);
	plist_head_init(&target.chain);
	memset(&ctx, 0, sizeof(ctx));
	init_fake_futex_q(&first, 1, 0xaaaaUL, 0xbbbbUL, 0x10UL, 0, 55);
	plist_add(&first.list, &source.chain);
	reset_requeue_body_trace();
	requeue_body_source_bucket = (unsigned long)&source;
	requeue_body_target_bucket = (unsigned long)&target;
	ret = call_requeue_body(&key1, &key2, &ctx, NULL, 1, 1);
	require(ret == 1);
	require(requeue_body_get_value_calls == 0);
	require(ctx.wake_count == 1);
	require(ctx.wake_log[0] == 55);
	mix_signed(&digest, ret);
	mix_signed(&digest, requeue_body_get_value_calls);
	mix_signed(&digest, ctx.wake_log[0]);

	return digest;
}

static unsigned long futex_queue_publish_waiter_digest(void)
{
	struct fake_futex_q q = { 0 };
	unsigned long digest = 0x6675746578717077UL;

	futex_queue_publish_waiter_result((unsigned long)&q,
		offsetof(struct fake_futex_q, task),
		offsetof(struct fake_futex_q, th_spin_sleep_pa),
		offsetof(struct fake_futex_q, th_status_pa),
		offsetof(struct fake_futex_q, th_spin_sleep_lock_pa),
		offsetof(struct fake_futex_q, proc_status_pa),
		offsetof(struct fake_futex_q, proc_update_lock_pa),
		offsetof(struct fake_futex_q, runq_lock_pa),
		offsetof(struct fake_futex_q, clv_flags_pa),
		offsetof(struct fake_futex_q, intr_id),
		offsetof(struct fake_futex_q, intr_vector),
		0x11110000UL,
		0x2000, 0x3000, 0x4000, 0x5000, 0x6000, 0x7000, 0x8000,
		17, 23);
	require(q.task == (void *)0x11110000UL);
	require(q.th_spin_sleep_pa == 0x2000);
	require(q.th_status_pa == 0x3000);
	require(q.th_spin_sleep_lock_pa == 0x4000);
	require(q.proc_status_pa == 0x5000);
	require(q.proc_update_lock_pa == 0x6000);
	require(q.runq_lock_pa == 0x7000);
	require(q.clv_flags_pa == 0x8000);
	require(q.intr_id == 17);
	require(q.intr_vector == 23);

	mix(&digest, (unsigned long)q.task);
	mix(&digest, q.th_spin_sleep_pa);
	mix(&digest, q.th_status_pa);
	mix(&digest, q.th_spin_sleep_lock_pa);
	mix(&digest, q.proc_status_pa);
	mix(&digest, q.proc_update_lock_pa);
	mix(&digest, q.runq_lock_pa);
	mix(&digest, q.clv_flags_pa);
	mix_signed(&digest, q.intr_id);
	mix_signed(&digest, q.intr_vector);
	return digest;
}

static unsigned long futex_queue_insert_digest(void)
{
	struct plist_head head;
	struct fake_futex_q first;
	struct fake_futex_q second;
	struct fake_futex_q third;
	unsigned long lock = 0x51525354UL;
	unsigned long digest = 0x667574657871696eUL;

	plist_head_init(&head);
	first.task = (void *)0x1111UL;
	first.lock_ptr = (void *)0xaaaaUL;
	second.task = (void *)0x2222UL;
	second.lock_ptr = (void *)0xbbbbUL;
	third.task = (void *)0x3333UL;
	third.lock_ptr = (void *)0xccccUL;

	futex_queue_insert_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list),
		(unsigned long)&head, 10, 0, (unsigned long)&lock);
	futex_queue_insert_result((unsigned long)&second,
		offsetof(struct fake_futex_q, list),
		(unsigned long)&head, 4, 0, (unsigned long)&lock);
	futex_queue_insert_result((unsigned long)&third,
		offsetof(struct fake_futex_q, list),
		(unsigned long)&head, 10, 0, (unsigned long)&lock);

	require(first.task == (void *)0x1111UL);
	require(second.task == (void *)0x2222UL);
	require(third.task == (void *)0x3333UL);
	require(first.lock_ptr == (void *)0xaaaaUL);
	require(second.lock_ptr == (void *)0xbbbbUL);
	require(third.lock_ptr == (void *)0xccccUL);
	require(!plist_node_empty(&first.list));
	require(!plist_node_empty(&second.list));
	require(!plist_node_empty(&third.list));

	mix(&digest, digest_plist_prios(&head));
	mix_signed(&digest, first.list.prio);
	mix_signed(&digest, second.list.prio);
	mix_signed(&digest, third.list.prio);
	futex_queue_insert_result(0, offsetof(struct fake_futex_q, list),
		(unsigned long)&head, 1, 0, (unsigned long)&lock);
	futex_queue_insert_result((unsigned long)&first,
		offsetof(struct fake_futex_q, list), 0, 1, 0,
		(unsigned long)&lock);
	mix(&digest, digest_plist_prios(&head));
	return digest;
}

static int queue_me_unlock_calls;
static unsigned long queue_me_unlock_addr;
static int queue_me_interrupt_cpu;
static int queue_me_vector_key;

static unsigned long fake_queue_me_phys(unsigned long addr)
{
	return addr ^ 0xabc00000UL;
}

static int fake_queue_me_interrupt_id(int cpu_id)
{
	queue_me_interrupt_cpu = cpu_id;
	return cpu_id + 1000;
}

static int fake_queue_me_vector(int vector_key)
{
	queue_me_vector_key = vector_key;
	return vector_key + 2000;
}

static void fake_queue_me_unlock(unsigned long lock_addr)
{
	queue_me_unlock_calls++;
	queue_me_unlock_addr = lock_addr;
}

static unsigned long futex_queue_me_digest(void)
{
	struct plist_head head;
	struct fake_futex_q q = { 0 };
	struct fake_queue_me_process proc = {
		.prefix = 0x1111,
		.status = 0x2222,
		.update_lock = 0x3333,
	};
	struct fake_queue_me_thread thread = {
		.prefix = 0x4444,
		.spin_sleep = 0x55,
		.status = 0x66,
		.spin_sleep_lock = 0x7777,
		.proc = &proc,
		.cpu_id = 7,
	};
	unsigned long runq_lock = 0x8888;
	unsigned int clv_flags = 0x9999;
	unsigned long lock = 0x51525354UL;
	unsigned long digest = 0x6675746578716d65UL;
	int ret;

	plist_head_init(&head);
	queue_me_unlock_calls = 0;
	queue_me_unlock_addr = 0;
	queue_me_interrupt_cpu = -1;
	queue_me_vector_key = -1;
	ret = futex_queue_me_result((unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, task),
		offsetof(struct fake_futex_q, th_spin_sleep_pa),
		offsetof(struct fake_futex_q, th_status_pa),
		offsetof(struct fake_futex_q, th_spin_sleep_lock_pa),
		offsetof(struct fake_futex_q, proc_status_pa),
		offsetof(struct fake_futex_q, proc_update_lock_pa),
		offsetof(struct fake_futex_q, runq_lock_pa),
		offsetof(struct fake_futex_q, clv_flags_pa),
		offsetof(struct fake_futex_q, intr_id),
		offsetof(struct fake_futex_q, intr_vector),
		(unsigned long)&head, (unsigned long)&lock, 10, 0,
		(unsigned long)&thread,
		offsetof(struct fake_queue_me_thread, spin_sleep),
		offsetof(struct fake_queue_me_thread, status),
		offsetof(struct fake_queue_me_thread, spin_sleep_lock),
		offsetof(struct fake_queue_me_thread, proc),
		offsetof(struct fake_queue_me_thread, cpu_id),
		offsetof(struct fake_queue_me_process, status),
		offsetof(struct fake_queue_me_process, update_lock),
		(unsigned long)&runq_lock, (unsigned long)&clv_flags, 44,
		fake_queue_me_phys, fake_queue_me_interrupt_id,
		fake_queue_me_vector, fake_queue_me_unlock);

	require(ret == 0);
	require(q.task == &thread);
	require(q.list.prio == 10);
	require(!plist_node_empty(&q.list));
	require(q.th_spin_sleep_pa ==
		fake_queue_me_phys((unsigned long)&thread.spin_sleep));
	require(q.th_status_pa ==
		fake_queue_me_phys((unsigned long)&thread.status));
	require(q.th_spin_sleep_lock_pa ==
		fake_queue_me_phys((unsigned long)&thread.spin_sleep_lock));
	require(q.proc_status_pa ==
		fake_queue_me_phys((unsigned long)&proc.status));
	require(q.proc_update_lock_pa ==
		fake_queue_me_phys((unsigned long)&proc.update_lock));
	require(q.runq_lock_pa == fake_queue_me_phys((unsigned long)&runq_lock));
	require(q.clv_flags_pa == fake_queue_me_phys((unsigned long)&clv_flags));
	require(q.intr_id == 1007);
	require(q.intr_vector == 2044);
	require(queue_me_interrupt_cpu == 7);
	require(queue_me_vector_key == 44);
	require(queue_me_unlock_calls == 1);
	require(queue_me_unlock_addr == (unsigned long)&lock);

	mix_signed(&digest, ret);
	mix(&digest, digest_plist_prios(&head));
	mix(&digest, q.th_spin_sleep_pa ==
		fake_queue_me_phys((unsigned long)&thread.spin_sleep));
	mix(&digest, q.proc_update_lock_pa ==
		fake_queue_me_phys((unsigned long)&proc.update_lock));
	mix(&digest, q.runq_lock_pa ==
		fake_queue_me_phys((unsigned long)&runq_lock));
	mix_signed(&digest, q.intr_id);
	mix_signed(&digest, q.intr_vector);
	mix(&digest, queue_me_unlock_addr == (unsigned long)&lock);

	ret = futex_queue_me_result(0, offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, task),
		offsetof(struct fake_futex_q, th_spin_sleep_pa),
		offsetof(struct fake_futex_q, th_status_pa),
		offsetof(struct fake_futex_q, th_spin_sleep_lock_pa),
		offsetof(struct fake_futex_q, proc_status_pa),
		offsetof(struct fake_futex_q, proc_update_lock_pa),
		offsetof(struct fake_futex_q, runq_lock_pa),
		offsetof(struct fake_futex_q, clv_flags_pa),
		offsetof(struct fake_futex_q, intr_id),
		offsetof(struct fake_futex_q, intr_vector),
		(unsigned long)&head, (unsigned long)&lock, 10, 0,
		(unsigned long)&thread,
		offsetof(struct fake_queue_me_thread, spin_sleep),
		offsetof(struct fake_queue_me_thread, status),
		offsetof(struct fake_queue_me_thread, spin_sleep_lock),
		offsetof(struct fake_queue_me_thread, proc),
		offsetof(struct fake_queue_me_thread, cpu_id),
		offsetof(struct fake_queue_me_process, status),
		offsetof(struct fake_queue_me_process, update_lock),
		(unsigned long)&runq_lock, (unsigned long)&clv_flags, 44,
		fake_queue_me_phys, fake_queue_me_interrupt_id,
		fake_queue_me_vector, fake_queue_me_unlock);
	require(ret == -22);
	mix_signed(&digest, ret);
	return digest;
}

static int wait_setup_get_key_calls;
static int wait_setup_queue_lock_calls;
static int wait_setup_get_value_calls;
static int wait_setup_queue_unlock_calls;
static int wait_setup_put_key_calls;
static int wait_setup_get_key_rc;
static int wait_setup_get_value_rc;
static unsigned int wait_setup_loaded_value;
static unsigned long wait_setup_hb = 0x777788889999aaaaUL;

static int get_key_refs_calls;
static int get_key_vtop_calls;
static int get_key_fault_calls;
static int get_key_log_count;
static int get_key_vtop_failures;
static int get_key_fault_rc;
static unsigned long get_key_phys_value;
static unsigned long get_key_last_mm;
static unsigned long get_key_last_uaddr;
static int get_key_last_fault_flags;

static void reset_get_key_trace(void)
{
	get_key_refs_calls = 0;
	get_key_vtop_calls = 0;
	get_key_fault_calls = 0;
	get_key_log_count = 0;
	get_key_vtop_failures = 0;
	get_key_fault_rc = 0;
	get_key_phys_value = 0xfeedcafe000UL;
	get_key_last_mm = 0;
	get_key_last_uaddr = 0;
	get_key_last_fault_flags = 0;
}

static void fake_get_key_refs(unsigned long key_addr)
{
	(void)key_addr;
	get_key_refs_calls++;
}

static int fake_get_key_vtop(unsigned long mm_addr, unsigned long uaddr,
			     unsigned long phys_out_addr)
{
	get_key_vtop_calls++;
	get_key_last_mm = mm_addr;
	get_key_last_uaddr = uaddr;
	if (get_key_vtop_calls <= get_key_vtop_failures)
		return -1;
	*(unsigned long *)phys_out_addr =
		get_key_phys_value + (unsigned long)get_key_vtop_calls;
	return 0;
}

static int fake_get_key_fault(unsigned long mm_addr, unsigned long uaddr,
			      int flags)
{
	get_key_fault_calls++;
	get_key_last_mm = mm_addr;
	get_key_last_uaddr = uaddr;
	get_key_last_fault_flags = flags;
	return get_key_fault_rc;
}

static void fake_get_key_log(int event)
{
	require(event == FUTEX_GET_KEY_LOG_VTOP_FAILED);
	get_key_log_count++;
}

static unsigned long futex_get_key_digest(void)
{
	struct futex_key key = { { 0 } };
	unsigned long digest = 0x66757465786b6579UL;
	const unsigned long mm = 0xabcdef000UL;
	const int fault_flags = 0x26;
	int ret;

	reset_get_key_trace();
	ret = futex_get_key_result(0x1234UL, 0, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, fake_get_key_refs,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == 0);
	require(key.opaque[0] == 0x1000UL);
	require(key.opaque[1] == mm);
	require((int)key.opaque[2] == 0x234);
	require(get_key_refs_calls == 1);
	require(get_key_vtop_calls == 0);
	require(get_key_fault_calls == 0);
	mix_signed(&digest, ret);
	mix(&digest, key.opaque[0]);
	mix(&digest, key.opaque[1]);
	mix_signed(&digest, (int)key.opaque[2]);
	mix_signed(&digest, get_key_refs_calls);

	reset_get_key_trace();
	key.opaque[0] = 0x11111111UL;
	key.opaque[1] = 0x22222222UL;
	key.opaque[2] = 0x33333333UL;
	ret = futex_get_key_result(0x1235UL, 0, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, fake_get_key_refs,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == -22);
	require(key.opaque[0] == 0x11111111UL);
	require(key.opaque[1] == 0x22222222UL);
	require(key.opaque[2] == 0x33333333UL);
	require(get_key_refs_calls == 0);
	require(get_key_vtop_calls == 0);
	mix_signed(&digest, ret);
	mix(&digest, key.opaque[0]);
	mix_signed(&digest, get_key_vtop_calls);

	reset_get_key_trace();
	key.opaque[0] = 0;
	key.opaque[1] = 0;
	key.opaque[2] = 0;
	get_key_phys_value = 0x90000000UL;
	ret = futex_get_key_result(0x2018UL, 1, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, fake_get_key_refs,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == 0);
	require(key.opaque[0] == 0);
	require(key.opaque[1] == 0x90000001UL);
	require((int)key.opaque[2] == (0x18 | FUT_OFF_MMSHARED));
	require(get_key_refs_calls == 0);
	require(get_key_vtop_calls == 1);
	require(get_key_fault_calls == 0);
	require(get_key_last_mm == mm);
	require(get_key_last_uaddr == 0x2018UL);
	mix_signed(&digest, ret);
	mix(&digest, key.opaque[1]);
	mix_signed(&digest, (int)key.opaque[2]);
	mix_signed(&digest, get_key_vtop_calls);

	reset_get_key_trace();
	get_key_vtop_failures = 1;
	get_key_phys_value = 0x91000000UL;
	ret = futex_get_key_result(0x3004UL, 1, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, fake_get_key_refs,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == 0);
	require(key.opaque[1] == 0x91000002UL);
	require((int)key.opaque[2] == (0x4 | FUT_OFF_MMSHARED));
	require(get_key_vtop_calls == 2);
	require(get_key_fault_calls == 1);
	require(get_key_last_fault_flags == fault_flags);
	mix_signed(&digest, ret);
	mix(&digest, key.opaque[1]);
	mix_signed(&digest, get_key_fault_calls);

	reset_get_key_trace();
	get_key_vtop_failures = 1;
	get_key_fault_rc = -5;
	ret = futex_get_key_result(0x4008UL, 1, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, fake_get_key_refs,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == -14);
	require(get_key_vtop_calls == 1);
	require(get_key_fault_calls == 1);
	require(get_key_log_count == 1);
	mix_signed(&digest, ret);
	mix_signed(&digest, get_key_log_count);

	ret = futex_get_key_result(0x4008UL, 1, (unsigned long)&key, mm,
		offsetof(struct futex_key, opaque[0]),
		offsetof(struct futex_key, opaque[1]),
		offsetof(struct futex_key, opaque[2]),
		FUT_OFF_MMSHARED, fault_flags, NULL,
		fake_get_key_vtop, fake_get_key_fault, fake_get_key_log);
	require(ret == -22);
	mix_signed(&digest, ret);

	return digest;
}

static void reset_wait_setup_trace(void)
{
	wait_setup_get_key_calls = 0;
	wait_setup_queue_lock_calls = 0;
	wait_setup_get_value_calls = 0;
	wait_setup_queue_unlock_calls = 0;
	wait_setup_put_key_calls = 0;
	wait_setup_get_key_rc = 0;
	wait_setup_get_value_rc = 0;
	wait_setup_loaded_value = 0;
}

static int fake_wait_setup_get_key(unsigned long uaddr, int fshared,
				   unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	(void)uaddr;
	wait_setup_get_key_calls++;
	if (wait_setup_get_key_rc)
		return wait_setup_get_key_rc;
	key->opaque[0] = 0x1234UL;
	key->opaque[1] = (unsigned long)(unsigned int)fshared;
	key->opaque[2] = 0x5678UL;
	return 0;
}

static unsigned long fake_wait_setup_queue_lock(unsigned long q_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;

	wait_setup_queue_lock_calls++;
	q->lock_ptr = (void *)wait_setup_hb;
	return wait_setup_hb;
}

static int fake_wait_setup_get_value(unsigned long value_addr,
				     unsigned long uaddr)
{
	(void)uaddr;
	wait_setup_get_value_calls++;
	*(unsigned int *)value_addr = wait_setup_loaded_value;
	return wait_setup_get_value_rc;
}

static void fake_wait_setup_queue_unlock(unsigned long q_addr,
					 unsigned long hb_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;

	wait_setup_queue_unlock_calls++;
	require(hb_addr == wait_setup_hb);
	q->lock_ptr = NULL;
}

static void fake_wait_setup_put_key(int fshared, unsigned long key_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	(void)fshared;
	wait_setup_put_key_calls++;
	key->opaque[0] = 0;
	key->opaque[1] = 0;
	key->opaque[2] = 0;
}

static unsigned long futex_wait_setup_digest(void)
{
	struct fake_futex_q q = { 0 };
	unsigned long hb_out = 0;
	unsigned long digest = 0x6675746578777375UL;
	int ret;

	reset_wait_setup_trace();
	q.key.opaque[0] = 0xaaaaaaaaUL;
	q.key.opaque[1] = 0xbbbbbbbbUL;
	q.key.opaque[2] = 0xccccccccUL;
	wait_setup_loaded_value = 0x31415926U;
	ret = futex_wait_setup_result(0x12345678UL, 0x31415926U, 1,
		(unsigned long)&q, &hb_out,
		offsetof(struct fake_futex_q, key), sizeof(q.key),
		fake_wait_setup_get_key, fake_wait_setup_queue_lock,
		fake_wait_setup_get_value, fake_wait_setup_queue_unlock,
		fake_wait_setup_put_key);
	require(ret == 0);
	require(hb_out == wait_setup_hb);
	require(q.lock_ptr == (void *)wait_setup_hb);
	require(q.key.opaque[0] == 0x1234UL);
	require(q.key.opaque[1] == 1);
	require(wait_setup_get_key_calls == 1);
	require(wait_setup_queue_lock_calls == 1);
	require(wait_setup_get_value_calls == 1);
	require(wait_setup_queue_unlock_calls == 0);
	require(wait_setup_put_key_calls == 0);
	mix_signed(&digest, ret);
	mix(&digest, (unsigned long)(hb_out == wait_setup_hb));
	mix(&digest, q.key.opaque[0]);
	mix(&digest, q.key.opaque[1]);
	mix(&digest, (unsigned long)wait_setup_get_value_calls);

	reset_wait_setup_trace();
	q.key.opaque[0] = 0xaaaaaaaaUL;
	hb_out = 0;
	wait_setup_loaded_value = 0x11111111U;
	ret = futex_wait_setup_result(0x12345678UL, 0x22222222U, 0,
		(unsigned long)&q, &hb_out,
		offsetof(struct fake_futex_q, key), sizeof(q.key),
		fake_wait_setup_get_key, fake_wait_setup_queue_lock,
		fake_wait_setup_get_value, fake_wait_setup_queue_unlock,
		fake_wait_setup_put_key);
	require(ret == -11);
	require(wait_setup_queue_unlock_calls == 1);
	require(wait_setup_put_key_calls == 1);
	require(q.lock_ptr == NULL);
	require(q.key.opaque[0] == 0);
	mix_signed(&digest, ret);
	mix(&digest, (unsigned long)wait_setup_queue_unlock_calls);
	mix(&digest, (unsigned long)wait_setup_put_key_calls);

	reset_wait_setup_trace();
	wait_setup_loaded_value = 0x22222222U;
	wait_setup_get_value_rc = -5;
	ret = futex_wait_setup_result(0x12345678UL, 0x22222222U, 0,
		(unsigned long)&q, &hb_out,
		offsetof(struct fake_futex_q, key), sizeof(q.key),
		fake_wait_setup_get_key, fake_wait_setup_queue_lock,
		fake_wait_setup_get_value, fake_wait_setup_queue_unlock,
		fake_wait_setup_put_key);
	require(ret == -5);
	require(wait_setup_queue_unlock_calls == 1);
	require(wait_setup_put_key_calls == 1);
	mix_signed(&digest, ret);
	mix(&digest, (unsigned long)wait_setup_queue_unlock_calls);

	reset_wait_setup_trace();
	q.key.opaque[0] = 0xaaaaaaaaUL;
	wait_setup_get_key_rc = -6;
	ret = futex_wait_setup_result(0x12345678UL, 0x22222222U, 0,
		(unsigned long)&q, &hb_out,
		offsetof(struct fake_futex_q, key), sizeof(q.key),
		fake_wait_setup_get_key, fake_wait_setup_queue_lock,
		fake_wait_setup_get_value, fake_wait_setup_queue_unlock,
		fake_wait_setup_put_key);
	require(ret == -6);
	require(q.key.opaque[0] == 0);
	require(wait_setup_queue_lock_calls == 0);
	require(wait_setup_put_key_calls == 0);
	mix_signed(&digest, ret);
	mix(&digest, (unsigned long)wait_setup_queue_lock_calls);

	ret = futex_wait_setup_result(0x12345678UL, 0x22222222U, 0,
		0, &hb_out, offsetof(struct fake_futex_q, key),
		sizeof(q.key), fake_wait_setup_get_key,
		fake_wait_setup_queue_lock, fake_wait_setup_get_value,
		fake_wait_setup_queue_unlock, fake_wait_setup_put_key);
	require(ret == -22);
	mix_signed(&digest, ret);

	return digest;
}

static unsigned long futex_wait_q_init_digest(void)
{
	struct fake_futex_q q = { 0 };
	unsigned long lock = 0x52535455UL;
	unsigned long digest = 0x6675746578716969UL;

	q.task = (void *)0x11112222UL;
	q.lock_ptr = (void *)0xaabbccddUL;
	q.key.opaque[0] = 0x11111111UL;
	q.key.opaque[1] = 0x22222222UL;
	q.key.opaque[2] = 0x33333333UL;
	q.requeue_pi_key = (struct futex_key *)0x44444444UL;
	q.bitset = 0x55555555U;
	q.uti_futex_resp = (void *)0x66666666UL;

	futex_wait_prepare_q_result((unsigned long)&q,
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct fake_futex_q, requeue_pi_key),
		offsetof(struct fake_futex_q, uti_futex_resp),
		0xaaaabbbbU, 0x77778888UL);
	require(q.task == (void *)0x11112222UL);
	require(q.lock_ptr == (void *)0xaabbccddUL);
	require(q.key.opaque[0] == 0x11111111UL);
	require(q.key.opaque[1] == 0x22222222UL);
	require(q.key.opaque[2] == 0x33333333UL);
	require(q.requeue_pi_key == NULL);
	require(q.bitset == 0xaaaabbbbU);
	require(q.uti_futex_resp == (void *)0x77778888UL);

	futex_wait_key_init_result((unsigned long)&q,
		offsetof(struct fake_futex_q, key), sizeof(q.key));
	require(q.key.opaque[0] == 0);
	require(q.key.opaque[1] == 0);
	require(q.key.opaque[2] == 0);

	futex_queue_lock_ptr_store_result((unsigned long)&q,
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&lock);
	require(q.lock_ptr == &lock);

	futex_wait_prepare_q_result(0, offsetof(struct fake_futex_q, bitset),
		offsetof(struct fake_futex_q, requeue_pi_key),
		offsetof(struct fake_futex_q, uti_futex_resp), 1, 2);
	futex_wait_key_init_result(0, offsetof(struct fake_futex_q, key),
		sizeof(q.key));
	futex_queue_lock_ptr_store_result(0,
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&lock);

	mix(&digest, (unsigned long)q.task);
	mix(&digest, q.lock_ptr == &lock);
	mix(&digest, q.key.opaque[0]);
	mix(&digest, q.key.opaque[1]);
	mix(&digest, q.key.opaque[2]);
	mix(&digest, (unsigned long)q.requeue_pi_key);
	mix(&digest, q.bitset);
	mix(&digest, (unsigned long)q.uti_futex_resp);
	return digest;
}

static unsigned long futex_wait_state_digest(void)
{
	struct fake_thread_state thread = {
		.pad = 0x1234,
		.status = 9,
		.spin_sleep = 3,
	};
	unsigned long digest = 0x6675746578777374UL;
	int old;

	old = futex_wait_mark_interruptible_result((unsigned long)&thread,
		offsetof(struct fake_thread_state, status), 2);
	require(old == 9);
	require(thread.status == 2);
	require(thread.spin_sleep == 3);
	mix_signed(&digest, old);
	mix_signed(&digest, thread.status);
	mix_signed(&digest, thread.spin_sleep);

	old = futex_wait_spin_sleep_store_result((unsigned long)&thread,
		offsetof(struct fake_thread_state, spin_sleep), 1);
	require(old == 3);
	require(thread.status == 2);
	require(thread.spin_sleep == 1);
	mix_signed(&digest, old);
	mix_signed(&digest, thread.status);
	mix_signed(&digest, thread.spin_sleep);

	old = futex_wait_finish_state_result((unsigned long)&thread,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep), 1);
	require(old == 2);
	require(thread.status == 1);
	require(thread.spin_sleep == 0);
	mix_signed(&digest, old);
	mix_signed(&digest, thread.status);
	mix_signed(&digest, thread.spin_sleep);
	mix_signed(&digest, futex_wait_mark_interruptible_result(0,
		offsetof(struct fake_thread_state, status), 2));
	mix_signed(&digest, futex_wait_spin_sleep_store_result(0,
		offsetof(struct fake_thread_state, spin_sleep), 1));
	mix_signed(&digest, futex_wait_finish_state_result(0,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep), 1));
	return digest;
}

static unsigned long futex_wait_post_action_digest(void)
{
	static const int unqueued_values[] = { 0, 1 };
	static const unsigned long timeout_values[] = { 0, 1, 1000 };
	static const long remain_values[] = { -512, -1, 0, 1, 99 };
	static const int binary[] = { 0, 1 };
	unsigned long digest = 0x6675746578706f73UL;

	for (unsigned int u = 0;
			u < sizeof(unqueued_values) / sizeof(unqueued_values[0]);
			u++) {
		for (unsigned int t = 0;
				t < sizeof(timeout_values) / sizeof(timeout_values[0]);
				t++) {
			for (unsigned int r = 0;
					r < sizeof(remain_values) / sizeof(remain_values[0]);
					r++) {
				for (unsigned int s = 0;
						s < sizeof(binary) / sizeof(binary[0]);
						s++) {
					for (unsigned int e = 0;
							e < sizeof(binary) / sizeof(binary[0]);
							e++) {
						mix_signed(&digest,
							futex_wait_post_action_result(
								unqueued_values[u],
								timeout_values[t],
								remain_values[r],
								binary[s],
								binary[e]));
					}
				}
			}
		}
	}
	return digest;
}

static unsigned long futex_wait_schedule_action_digest(void)
{
	static const int queued_values[] = { 0, 1 };
	static const unsigned long timeout_values[] = { 0, 1, 1000 };
	unsigned long digest = 0x6675746578736368UL;

	require(futex_wait_schedule_action_result(0, 0) ==
		FUTEX_WAIT_SCHEDULE_NONE);
	require(futex_wait_schedule_action_result(1, 0) ==
		FUTEX_WAIT_SCHEDULE_DIRECT);
	require(futex_wait_schedule_action_result(1, 1000) ==
		FUTEX_WAIT_SCHEDULE_TIMEOUT);

	for (unsigned int q = 0;
			q < sizeof(queued_values) / sizeof(queued_values[0]);
			q++) {
		for (unsigned int t = 0;
				t < sizeof(timeout_values) / sizeof(timeout_values[0]);
				t++) {
			mix_signed(&digest, futex_wait_schedule_action_result(
				queued_values[q], timeout_values[t]));
		}
	}
	return digest;
}

static int wait_queue_me_enqueue;
static int wait_queue_me_queue_calls;
static int wait_queue_me_spin_lock_calls;
static int wait_queue_me_spin_unlock_calls;
static int wait_queue_me_timeout_calls;
static int wait_queue_me_direct_calls;
static int wait_queue_me_log_count;
static int wait_queue_me_log_events[4];
static int wait_queue_me_log_tid[4];
static unsigned long wait_queue_me_last_q;
static unsigned long wait_queue_me_last_hb;
static unsigned long wait_queue_me_last_lock;
static unsigned long wait_queue_me_last_irqstate;
static long wait_queue_me_timeout_ret;

static void reset_wait_queue_me_trace(void)
{
	wait_queue_me_enqueue = 0;
	wait_queue_me_queue_calls = 0;
	wait_queue_me_spin_lock_calls = 0;
	wait_queue_me_spin_unlock_calls = 0;
	wait_queue_me_timeout_calls = 0;
	wait_queue_me_direct_calls = 0;
	wait_queue_me_log_count = 0;
	wait_queue_me_last_q = 0;
	wait_queue_me_last_hb = 0;
	wait_queue_me_last_lock = 0;
	wait_queue_me_last_irqstate = 0;
	wait_queue_me_timeout_ret = 0;
	for (int i = 0; i < 4; i++) {
		wait_queue_me_log_events[i] = 0;
		wait_queue_me_log_tid[i] = 0;
	}
}

static unsigned long fake_wait_queue_me_spin_lock(unsigned long lock_addr)
{
	wait_queue_me_spin_lock_calls++;
	wait_queue_me_last_lock = lock_addr;
	return lock_addr ^ 0x5a5a5a5aUL;
}

static void fake_wait_queue_me_spin_unlock(unsigned long lock_addr,
					   unsigned long irqstate)
{
	wait_queue_me_spin_unlock_calls++;
	wait_queue_me_last_lock = lock_addr;
	wait_queue_me_last_irqstate = irqstate;
}

static void fake_wait_queue_me_queue(unsigned long q_addr, unsigned long hb_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct plist_head *head = (struct plist_head *)hb_addr;

	wait_queue_me_queue_calls++;
	wait_queue_me_last_q = q_addr;
	wait_queue_me_last_hb = hb_addr;
	if (wait_queue_me_enqueue)
		plist_add(&q->list, head);
}

static long fake_wait_queue_me_timeout(unsigned long timeout)
{
	wait_queue_me_timeout_calls++;
	return wait_queue_me_timeout_ret + (long)timeout;
}

static void fake_wait_queue_me_direct(void)
{
	wait_queue_me_direct_calls++;
}

static void fake_wait_queue_me_log(int event, unsigned long thread_addr, int tid)
{
	(void)thread_addr;
	if (wait_queue_me_log_count < 4) {
		wait_queue_me_log_events[wait_queue_me_log_count] = event;
		wait_queue_me_log_tid[wait_queue_me_log_count] = tid;
	}
	wait_queue_me_log_count++;
}

static unsigned long futex_wait_queue_me_digest(void)
{
	struct plist_head head;
	struct fake_futex_q q = { 0 };
	struct fake_thread_state thread = {
		.status = 9,
		.spin_sleep = 5,
		.spin_sleep_lock = 0x1111222233334444UL,
		.tid = 123,
	};
	unsigned long digest = 0x667574657877716dUL;
	long ret;

	plist_head_init(&head);
	plist_node_init(&q.list, 4);
	reset_wait_queue_me_trace();
	wait_queue_me_enqueue = 1;
	wait_queue_me_timeout_ret = 900;
	ret = futex_wait_queue_me_result((unsigned long)&head,
		(unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct plist_head, node_list),
		(unsigned long)&thread,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep),
		offsetof(struct fake_thread_state, spin_sleep_lock),
		offsetof(struct fake_thread_state, tid),
		0, 77, 2, 1,
		fake_wait_queue_me_spin_lock,
		fake_wait_queue_me_spin_unlock,
		fake_wait_queue_me_queue,
		fake_wait_queue_me_timeout,
		fake_wait_queue_me_direct,
		fake_wait_queue_me_log);
	require(ret == 977);
	require(thread.status == 1);
	require(thread.spin_sleep == 0);
	require(!plist_node_empty(&q.list));
	require(wait_queue_me_queue_calls == 1);
	require(wait_queue_me_spin_lock_calls == 1);
	require(wait_queue_me_spin_unlock_calls == 1);
	require(wait_queue_me_timeout_calls == 1);
	require(wait_queue_me_direct_calls == 0);
	require(wait_queue_me_log_count == 2);
	require(wait_queue_me_log_events[0] == FUTEX_WAIT_QUEUE_LOG_TIMEOUT);
	require(wait_queue_me_log_events[1] == FUTEX_WAIT_QUEUE_LOG_WOKEN);
	require(wait_queue_me_log_tid[0] == 123);
	mix_signed(&digest, ret);
	mix_signed(&digest, thread.status);
	mix_signed(&digest, thread.spin_sleep);
	mix(&digest, digest_plist_prios(&head));
	mix_signed(&digest, wait_queue_me_spin_lock_calls);
	mix_signed(&digest, wait_queue_me_timeout_calls);
	mix_signed(&digest, wait_queue_me_log_events[0]);
	mix_signed(&digest, wait_queue_me_log_events[1]);

	plist_head_init(&head);
	plist_node_init(&q.list, 6);
	thread.status = 9;
	thread.spin_sleep = 5;
	thread.tid = 456;
	reset_wait_queue_me_trace();
	wait_queue_me_enqueue = 1;
	ret = futex_wait_queue_me_result((unsigned long)&head,
		(unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct plist_head, node_list),
		(unsigned long)&thread,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep),
		offsetof(struct fake_thread_state, spin_sleep_lock),
		offsetof(struct fake_thread_state, tid),
		1, 0, 2, 1,
		fake_wait_queue_me_spin_lock,
		fake_wait_queue_me_spin_unlock,
		fake_wait_queue_me_queue,
		fake_wait_queue_me_timeout,
		fake_wait_queue_me_direct,
		fake_wait_queue_me_log);
	require(ret == 0);
	require(thread.status == 1);
	require(thread.spin_sleep == 0);
	require(wait_queue_me_spin_lock_calls == 0);
	require(wait_queue_me_timeout_calls == 0);
	require(wait_queue_me_direct_calls == 1);
	require(wait_queue_me_log_count == 2);
	require(wait_queue_me_log_events[0] == FUTEX_WAIT_QUEUE_LOG_DIRECT);
	require(wait_queue_me_log_events[1] == FUTEX_WAIT_QUEUE_LOG_WOKEN);
	mix_signed(&digest, ret);
	mix(&digest, digest_plist_prios(&head));
	mix_signed(&digest, wait_queue_me_spin_lock_calls);
	mix_signed(&digest, wait_queue_me_direct_calls);
	mix_signed(&digest, wait_queue_me_log_events[0]);
	mix_signed(&digest, wait_queue_me_log_events[1]);

	plist_head_init(&head);
	plist_node_init(&q.list, 8);
	thread.status = 9;
	thread.spin_sleep = 5;
	thread.tid = 789;
	reset_wait_queue_me_trace();
	wait_queue_me_enqueue = 0;
	ret = futex_wait_queue_me_result((unsigned long)&head,
		(unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct plist_head, node_list),
		(unsigned long)&thread,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep),
		offsetof(struct fake_thread_state, spin_sleep_lock),
		offsetof(struct fake_thread_state, tid),
		0, 0, 2, 1,
		fake_wait_queue_me_spin_lock,
		fake_wait_queue_me_spin_unlock,
		fake_wait_queue_me_queue,
		fake_wait_queue_me_timeout,
		fake_wait_queue_me_direct,
		fake_wait_queue_me_log);
	require(ret == 0);
	require(thread.status == 1);
	require(thread.spin_sleep == 0);
	require(plist_node_empty(&q.list));
	require(wait_queue_me_spin_lock_calls == 1);
	require(wait_queue_me_timeout_calls == 0);
	require(wait_queue_me_direct_calls == 0);
	require(wait_queue_me_log_count == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_queue_me_spin_lock_calls);
	mix_signed(&digest, wait_queue_me_queue_calls);
	mix_signed(&digest, wait_queue_me_log_count);

	mix_signed(&digest, futex_wait_queue_me_result(0,
		(unsigned long)&q,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct plist_head, node_list),
		(unsigned long)&thread,
		offsetof(struct fake_thread_state, status),
		offsetof(struct fake_thread_state, spin_sleep),
		offsetof(struct fake_thread_state, spin_sleep_lock),
		offsetof(struct fake_thread_state, tid),
		0, 0, 2, 1,
		fake_wait_queue_me_spin_lock,
		fake_wait_queue_me_spin_unlock,
		fake_wait_queue_me_queue,
		fake_wait_queue_me_timeout,
		fake_wait_queue_me_direct,
		fake_wait_queue_me_log));
	return digest;
}

static int wait_body_setup_calls;
static int wait_body_wait_calls;
static int wait_body_unqueue_calls;
static int wait_body_signal_calls;
static int wait_body_put_key_calls;
static int wait_body_log_count;
static int wait_body_setup_rc[4];
static long wait_body_wait_rc[4];
static int wait_body_unqueue_rc[4];
static int wait_body_signal_rc[4];
static int wait_body_log_events[6];
static int wait_body_log_tid[6];
static int wait_body_log_ret[6];
static unsigned long wait_body_last_hb_out;
static unsigned long wait_body_last_put_key;

static void reset_wait_body_trace(void)
{
	wait_body_setup_calls = 0;
	wait_body_wait_calls = 0;
	wait_body_unqueue_calls = 0;
	wait_body_signal_calls = 0;
	wait_body_put_key_calls = 0;
	wait_body_log_count = 0;
	wait_body_last_hb_out = 0;
	wait_body_last_put_key = 0;
	for (int i = 0; i < 4; i++) {
		wait_body_setup_rc[i] = 0;
		wait_body_wait_rc[i] = 0;
		wait_body_unqueue_rc[i] = 0;
		wait_body_signal_rc[i] = 0;
	}
	for (int i = 0; i < 6; i++) {
		wait_body_log_events[i] = 0;
		wait_body_log_tid[i] = 0;
		wait_body_log_ret[i] = 0;
	}
}

static int fake_wait_body_setup(unsigned long uaddr, unsigned int val,
		int fshared, unsigned long q_addr, unsigned long hb_out_addr)
{
	(void)uaddr;
	(void)val;
	(void)fshared;
	(void)q_addr;
	int idx = wait_body_setup_calls++;
	if (hb_out_addr) {
		wait_body_last_hb_out = 0xabc000UL + (unsigned long)idx;
		*(unsigned long *)hb_out_addr = wait_body_last_hb_out;
	}
	return wait_body_setup_rc[idx];
}

static long fake_wait_body_wait(unsigned long hb_addr, unsigned long q_addr,
		unsigned long timeout)
{
	(void)hb_addr;
	(void)q_addr;
	(void)timeout;
	return wait_body_wait_rc[wait_body_wait_calls++];
}

static int fake_wait_body_unqueue(unsigned long q_addr)
{
	(void)q_addr;
	return wait_body_unqueue_rc[wait_body_unqueue_calls++];
}

static int fake_wait_body_has_signal(unsigned long thread_addr)
{
	(void)thread_addr;
	return wait_body_signal_rc[wait_body_signal_calls++];
}

static void fake_wait_body_put_key(int fshared, unsigned long key_addr)
{
	(void)fshared;
	wait_body_put_key_calls++;
	wait_body_last_put_key = key_addr;
}

static void fake_wait_body_log(int event, unsigned long thread_addr,
		int tid, int ret)
{
	(void)thread_addr;
	if (wait_body_log_count < 6) {
		wait_body_log_events[wait_body_log_count] = event;
		wait_body_log_tid[wait_body_log_count] = tid;
		wait_body_log_ret[wait_body_log_count] = ret;
	}
	wait_body_log_count++;
}

static int call_wait_body(struct fake_futex_q *q,
		struct fake_thread_state *thread, unsigned long timeout,
		unsigned int bitset)
{
	return futex_wait_body_result(0x10002000UL, 1, 0x12345678U,
		timeout, bitset, (unsigned long)q, (unsigned long)thread,
		0xcafebabeUL,
		offsetof(struct fake_futex_q, bitset),
		offsetof(struct fake_futex_q, requeue_pi_key),
		offsetof(struct fake_futex_q, uti_futex_resp),
		offsetof(struct fake_futex_q, key),
		offsetof(struct fake_thread_state, tid),
		fake_wait_body_setup, fake_wait_body_wait,
		fake_wait_body_unqueue, fake_wait_body_has_signal,
		fake_wait_body_put_key, fake_wait_body_log);
}

static unsigned long futex_wait_body_digest(void)
{
	struct fake_futex_q q = { 0 };
	struct fake_thread_state thread = { .tid = 321 };
	unsigned long digest = 0x6675746578776264UL;
	int ret;

	reset_wait_body_trace();
	q.bitset = 0x11111111U;
	q.requeue_pi_key = (void *)0x22222222UL;
	q.uti_futex_resp = (void *)0x33333333UL;
	wait_body_setup_rc[0] = -7;
	ret = call_wait_body(&q, &thread, 0, 0xffffffffU);
	require(ret == -7);
	require(q.bitset == 0xffffffffU);
	require(q.requeue_pi_key == NULL);
	require(q.uti_futex_resp == (void *)0xcafebabeUL);
	require(wait_body_setup_calls == 1);
	require(wait_body_wait_calls == 0);
	require(wait_body_put_key_calls == 0);
	require(wait_body_log_count == 1);
	require(wait_body_log_events[0] == FUTEX_WAIT_LOG_SETUP_RET);
	require(wait_body_log_tid[0] == 321);
	require(wait_body_log_ret[0] == -7);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_setup_calls);
	mix_signed(&digest, wait_body_log_events[0]);
	mix_signed(&digest, wait_body_log_ret[0]);

	reset_wait_body_trace();
	thread.tid = 322;
	wait_body_unqueue_rc[0] = 0;
	ret = call_wait_body(&q, &thread, 0, 0x11111111U);
	require(ret == 0);
	require(wait_body_setup_calls == 1);
	require(wait_body_wait_calls == 1);
	require(wait_body_unqueue_calls == 1);
	require(wait_body_signal_calls == 0);
	require(wait_body_put_key_calls == 1);
	require(wait_body_last_put_key ==
		(unsigned long)&q + offsetof(struct fake_futex_q, key));
	require(wait_body_log_count == 1);
	require(wait_body_log_events[0] == FUTEX_WAIT_LOG_SUCCESS);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_wait_calls);
	mix_signed(&digest, wait_body_signal_calls);
	mix_signed(&digest, wait_body_put_key_calls);
	mix_signed(&digest, wait_body_log_events[0]);

	reset_wait_body_trace();
	thread.tid = 323;
	wait_body_wait_rc[0] = 0;
	wait_body_unqueue_rc[0] = 1;
	ret = call_wait_body(&q, &thread, 55, 0x22222222U);
	require(ret == -110);
	require(wait_body_signal_calls == 0);
	require(wait_body_put_key_calls == 1);
	require(wait_body_log_count == 1);
	require(wait_body_log_events[0] == FUTEX_WAIT_LOG_TIMEOUT);
	require(wait_body_log_ret[0] == -110);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_signal_calls);
	mix_signed(&digest, wait_body_log_events[0]);

	reset_wait_body_trace();
	thread.tid = 324;
	wait_body_wait_rc[0] = -512;
	wait_body_unqueue_rc[0] = 1;
	wait_body_signal_rc[0] = 0;
	ret = call_wait_body(&q, &thread, 0, 0x33333333U);
	require(ret == -4);
	require(wait_body_signal_calls == 1);
	require(wait_body_put_key_calls == 1);
	require(wait_body_log_count == 1);
	require(wait_body_log_events[0] == FUTEX_WAIT_LOG_INTERRUPT);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_signal_calls);
	mix_signed(&digest, wait_body_log_events[0]);

	reset_wait_body_trace();
	thread.tid = 325;
	wait_body_wait_rc[0] = 7;
	wait_body_unqueue_rc[0] = 1;
	wait_body_signal_rc[0] = 0;
	wait_body_setup_rc[1] = -6;
	ret = call_wait_body(&q, &thread, 0, 0x44444444U);
	require(ret == -6);
	require(wait_body_setup_calls == 2);
	require(wait_body_wait_calls == 1);
	require(wait_body_unqueue_calls == 1);
	require(wait_body_signal_calls == 1);
	require(wait_body_put_key_calls == 1);
	require(wait_body_log_count == 1);
	require(wait_body_log_events[0] == FUTEX_WAIT_LOG_SETUP_RET);
	require(wait_body_log_ret[0] == -6);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_setup_calls);
	mix_signed(&digest, wait_body_put_key_calls);
	mix_signed(&digest, wait_body_log_ret[0]);

	reset_wait_body_trace();
	ret = call_wait_body(&q, &thread, 0, 0);
	require(ret == -22);
	require(wait_body_setup_calls == 0);
	require(wait_body_put_key_calls == 0);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_body_setup_calls);

	return digest;
}

static int wait_entry_body_calls;
static int wait_entry_body_rc;
static unsigned long wait_entry_body_uaddr;
static unsigned long wait_entry_body_timeout;
static unsigned long wait_entry_body_q_addr;
static unsigned long wait_entry_body_thread_addr;
static unsigned long wait_entry_body_resp;
static unsigned int wait_entry_body_val;
static unsigned int wait_entry_body_bitset;
static int wait_entry_body_fshared;
static int wait_entry_timestamp_calls;
static unsigned long wait_entry_timestamp_values[8];

static void reset_wait_entry_trace(void)
{
	wait_entry_body_calls = 0;
	wait_entry_body_rc = 0;
	wait_entry_body_uaddr = 0;
	wait_entry_body_timeout = 0;
	wait_entry_body_q_addr = 0;
	wait_entry_body_thread_addr = 0;
	wait_entry_body_resp = 0;
	wait_entry_body_val = 0;
	wait_entry_body_bitset = 0;
	wait_entry_body_fshared = 0;
	wait_entry_timestamp_calls = 0;
	for (int i = 0; i < 8; i++)
		wait_entry_timestamp_values[i] = 0;
}

static unsigned long fake_wait_entry_timestamp(void)
{
	require(wait_entry_timestamp_calls < 8);
	return wait_entry_timestamp_values[wait_entry_timestamp_calls++];
}

static int fake_wait_entry_body(unsigned long uaddr, int fshared,
				unsigned int val, unsigned long timeout,
				unsigned int bitset, unsigned long q_addr,
				unsigned long thread_addr,
				unsigned long uti_futex_resp)
{
	wait_entry_body_calls++;
	wait_entry_body_uaddr = uaddr;
	wait_entry_body_timeout = timeout;
	wait_entry_body_q_addr = q_addr;
	wait_entry_body_thread_addr = thread_addr;
	wait_entry_body_resp = uti_futex_resp;
	wait_entry_body_val = val;
	wait_entry_body_bitset = bitset;
	wait_entry_body_fshared = fshared;
	return wait_entry_body_rc;
}

static int call_wait_entry(struct fake_futex_q *q,
			   struct fake_thread_state *thread,
			   int profile_enabled, unsigned int bitset)
{
	return futex_wait_entry_result(0x45450000UL, 1, 0x12345678U,
		0x9999UL, bitset, (unsigned long)q, (unsigned long)thread,
		0xabcdefUL, profile_enabled,
		offsetof(struct fake_thread_state, profile),
		offsetof(struct fake_thread_state, profile_start_ts),
		offsetof(struct fake_thread_state, profile_elapsed_ts),
		fake_wait_entry_timestamp, fake_wait_entry_body);
}

static unsigned long futex_wait_entry_digest(void)
{
	struct fake_futex_q q = { 0 };
	struct fake_thread_state thread = { 0 };
	unsigned long digest = 0x667574657877656eUL;
	int ret;

	reset_wait_entry_trace();
	thread.profile = 1;
	thread.profile_start_ts = 900;
	thread.profile_elapsed_ts = 40;
	wait_entry_timestamp_values[0] = 1000;
	wait_entry_timestamp_values[1] = 2000;
	ret = call_wait_entry(&q, &thread, 1, 0xffffffffU);
	require(ret == 0);
	require(wait_entry_body_calls == 1);
	require(wait_entry_body_uaddr == 0x45450000UL);
	require(wait_entry_body_fshared == 1);
	require(wait_entry_body_val == 0x12345678U);
	require(wait_entry_body_timeout == 0x9999UL);
	require(wait_entry_body_bitset == 0xffffffffU);
	require(wait_entry_body_q_addr == (unsigned long)&q);
	require(wait_entry_body_thread_addr == (unsigned long)&thread);
	require(wait_entry_body_resp == 0xabcdefUL);
	require(wait_entry_timestamp_calls == 2);
	require(thread.profile_elapsed_ts == 140);
	require(thread.profile_start_ts == 2000);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_entry_body_calls);
	mix_signed(&digest, wait_entry_timestamp_calls);
	mix(&digest, thread.profile_elapsed_ts);
	mix(&digest, thread.profile_start_ts);

	reset_wait_entry_trace();
	thread.profile = 1;
	thread.profile_start_ts = 0;
	thread.profile_elapsed_ts = 77;
	wait_entry_body_rc = -5;
	wait_entry_timestamp_values[0] = 3000;
	ret = call_wait_entry(&q, &thread, 1, 0x11111111U);
	require(ret == -5);
	require(wait_entry_body_calls == 1);
	require(wait_entry_timestamp_calls == 1);
	require(thread.profile_elapsed_ts == 77);
	require(thread.profile_start_ts == 3000);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_entry_timestamp_calls);
	mix(&digest, thread.profile_start_ts);

	reset_wait_entry_trace();
	thread.profile = 0;
	thread.profile_start_ts = 500;
	thread.profile_elapsed_ts = 12;
	ret = call_wait_entry(&q, &thread, 1, 0x22222222U);
	require(ret == 0);
	require(wait_entry_body_calls == 1);
	require(wait_entry_timestamp_calls == 0);
	require(thread.profile_start_ts == 500);
	require(thread.profile_elapsed_ts == 12);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_entry_timestamp_calls);
	mix(&digest, thread.profile_elapsed_ts);

	reset_wait_entry_trace();
	thread.profile = 1;
	thread.profile_start_ts = 500;
	thread.profile_elapsed_ts = 12;
	ret = call_wait_entry(&q, &thread, 0, 0x33333333U);
	require(ret == 0);
	require(wait_entry_body_calls == 1);
	require(wait_entry_timestamp_calls == 0);
	require(thread.profile_start_ts == 500);
	require(thread.profile_elapsed_ts == 12);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_entry_timestamp_calls);

	reset_wait_entry_trace();
	thread.profile = 1;
	thread.profile_start_ts = 500;
	thread.profile_elapsed_ts = 12;
	ret = call_wait_entry(&q, &thread, 1, 0);
	require(ret == -22);
	require(wait_entry_body_calls == 0);
	require(wait_entry_timestamp_calls == 0);
	require(thread.profile_start_ts == 500);
	require(thread.profile_elapsed_ts == 12);
	mix_signed(&digest, ret);
	mix_signed(&digest, wait_entry_body_calls);

	return digest;
}

static unsigned long futex_wake_packet_digest(void)
{
	struct fake_wake_packet packet = {
		.header = 0x12345678UL,
		.msg = -1,
		.err = -2,
		.reply = (void *)0xaaaabbbbUL,
		.futex = {
			.resp = (void *)0x1111UL,
			.spin_sleep = (int *)0x2222UL,
		},
		.tail = 0xfeedfaceUL,
	};
	unsigned long digest = 0x667574657877706bUL;
	int spin_sleep = 1;

	require(futex_wake_target_result(0) == 0);
	require(futex_wake_target_result(0x1000) == 1);
	require(futex_wake_linux_channel_result(0x1234, 0xabcd) == 0x1234);
	require(futex_wake_linux_channel_result(0, 0xabcd) == 0xabcd);

	futex_wake_ikc_packet_fill_result((unsigned long)&packet,
		offsetof(struct fake_wake_packet, msg),
		offsetof(struct fake_wake_packet, futex.resp),
		offsetof(struct fake_wake_packet, futex.spin_sleep),
		0x60, 0x80808080UL, (unsigned long)&spin_sleep);
	require(packet.header == 0x12345678UL);
	require(packet.msg == 0x60);
	require(packet.err == -2);
	require(packet.reply == (void *)0xaaaabbbbUL);
	require(packet.futex.resp == (void *)0x80808080UL);
	require(packet.futex.spin_sleep == &spin_sleep);
	require(packet.tail == 0xfeedfaceUL);
	futex_wake_ikc_packet_fill_result(0,
		offsetof(struct fake_wake_packet, msg),
		offsetof(struct fake_wake_packet, futex.resp),
		offsetof(struct fake_wake_packet, futex.spin_sleep),
		0x61, 0x90909090UL, 0);

	mix_signed(&digest, futex_wake_target_result(0));
	mix_signed(&digest, futex_wake_target_result(0x1000));
	mix(&digest, futex_wake_linux_channel_result(0x1234, 0xabcd));
	mix(&digest, futex_wake_linux_channel_result(0, 0xabcd));
	mix_signed(&digest, packet.msg);
	mix_signed(&digest, packet.err);
	mix(&digest, (unsigned long)packet.reply);
	mix(&digest, (unsigned long)packet.futex.resp);
	mix_signed(&digest, packet.futex.spin_sleep == &spin_sleep);
	mix(&digest, packet.header);
	mix(&digest, packet.tail);
	return digest;
}

int main(void)
{
	static const int policies[] = {
		-100, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 99,
	};
	static const int priorities[] = {
		-1, 0, 1, 2, 50, 99, 100,
	};
	static const int nice_values[] = {
		-100, -20, -1, 0, 1, 19, 40, 100,
	};
	static const unsigned int ids[][3] = {
		{ 0, 10, 20 },
		{ 10, 10, 20 },
		{ 20, 10, 20 },
		{ 30, 10, 20 },
		{ 99, 99, 99 },
	};
	static const unsigned long lens[] = {
		0, 1, 4, 7, 8, 16, 128, 129,
	};
	static const int cpu_counts[] = {
		1, 2, 8, 63, 64, 65, 1024,
	};
	static const unsigned long timeouts[] = {
		0, 1, 499, 500, 501, 999, 1000, ~0UL,
	};
	static const int runq_lens[] = {
		-1, 0, 1, 2, 8,
	};
	static const unsigned long futex_keys[][6] = {
		{ 0x1000, 0x2000, 0, 0x1000, 0x2000, 0 },
		{ 0x1000, 0x2000, 4, 0x1000, 0x2000, 8 },
		{ 0x1000, 0x2000, 4, 0x1001, 0x2000, 4 },
		{ 0x1000, 0x2000, 4, 0x1000, 0x3000, 4 },
	};
	static const unsigned long futex_addrs[] = {
		0, 1, 3, 4, 0xfff, 0x1000, 0x1004, 0x1ffc,
	};
	static const unsigned int bitsets[] = {
		0, 1, 2, 3, 0x80000000U, 0xffffffffU,
	};
	static const int wake_counts[] = {
		-1, 0, 1, 2, 5,
	};
	static const int binary[] = { 0, 1 };
	unsigned long digest = 0x5c7ed123456789abUL;

	for (unsigned int i = 0; i < sizeof(nice_values) / sizeof(nice_values[0]); i++) {
		int nice = nice_values[i];
		int prio = NICE_TO_PRIO(nice);
		mix_signed(&digest, prio);
		mix_signed(&digest, PRIO_TO_NICE(prio));
		mix_signed(&digest, USER_PRIO(prio));
		mix_signed(&digest, nice_to_rlimit(nice));
		mix_signed(&digest, rlimit_to_nice(nice_to_rlimit(nice)));
		require(PRIO_TO_NICE(prio) == nice);
		require(rlimit_to_nice(nice_to_rlimit(nice)) == nice);
	}

	for (unsigned int i = 0; i < sizeof(policies) / sizeof(policies[0]); i++) {
		mix_signed(&digest, sched_get_priority_max_value(policies[i]));
		mix_signed(&digest, sched_get_priority_min_value(policies[i]));
		mix_signed(&digest, sched_get_priority_max_body_result(policies[i]));
		mix_signed(&digest, sched_get_priority_min_body_result(policies[i]));
		mix_signed(&digest, sched_policy_is_valid(policies[i]));
		mix_signed(&digest, sched_policy_needs_root(policies[i]));
		mix_signed(&digest, sched_rr_interval_nsec(policies[i]));
		for (unsigned int p = 0; p < sizeof(priorities) / sizeof(priorities[0]); p++)
			mix_signed(&digest, setscheduler_validate(policies[i], priorities[p]));
	}

	for (unsigned int i = 0; i < sizeof(ids) / sizeof(ids[0]); i++) {
		mix_signed(&digest, sched_affinity_permission_result(ids[i][0],
			ids[i][1], ids[i][2]));
	}

	for (unsigned int i = 0; i < sizeof(lens) / sizeof(lens[0]); i++) {
		for (unsigned int j = 0; j < sizeof(cpu_counts) / sizeof(cpu_counts[0]); j++)
			mix_signed(&digest, sched_getaffinity_len_result(lens[i], cpu_counts[j]));
		mix(&digest, sched_affinity_copy_len(lens[i], 128));
		mix(&digest, sched_affinity_copy_len(lens[i], 1024));
	}
	mix(&digest, sched_syscall_body_digest());
	mix(&digest, sched_affinity_body_digest());
	mix(&digest, sched_migrate_body_digest());
	mix(&digest, sched_do_migrate_body_digest());
	mix(&digest, sched_runqueue_body_digest());

	for (unsigned int i = 0; i < sizeof(timeouts) / sizeof(timeouts[0]); i++) {
		for (unsigned int j = 0; j < sizeof(timeouts) / sizeof(timeouts[0]); j++) {
			mix(&digest, timer_spin_sleep_remaining_result(timeouts[i], timeouts[j]));
			mix(&digest, timer_after_spin_remaining_result(timeouts[i], timeouts[j]));
			mix(&digest, timer_after_tick_remaining_result(timeouts[i], timeouts[j]));
		}
	}

	for (unsigned int i = 0; i < sizeof(runq_lens) / sizeof(runq_lens[0]); i++)
		mix_signed(&digest, timer_runq_should_schedule_result(runq_lens[i]));
	mix(&digest, timer_runtime_body_digest());

	for (unsigned int i = 0; i < sizeof(futex_keys) / sizeof(futex_keys[0]); i++) {
		mix_signed(&digest, futex_key_match_result(1, 1,
			futex_keys[i][0], futex_keys[i][1], futex_keys[i][2],
			futex_keys[i][3], futex_keys[i][4], futex_keys[i][5]));
		mix_signed(&digest, futex_key_match_result(0, 1,
			futex_keys[i][0], futex_keys[i][1], futex_keys[i][2],
			futex_keys[i][3], futex_keys[i][4], futex_keys[i][5]));
		mix_signed(&digest, futex_key_match_result(1, 0,
			futex_keys[i][0], futex_keys[i][1], futex_keys[i][2],
			futex_keys[i][3], futex_keys[i][4], futex_keys[i][5]));
	}

	for (unsigned int i = 0; i < sizeof(futex_addrs) / sizeof(futex_addrs[0]); i++) {
		for (unsigned int s = 0; s < sizeof(binary) / sizeof(binary[0]); s++) {
			unsigned long base = 0xdeadbeefUL;
			unsigned long offset = 0xfeedfaceUL;
			int is_private = -99;
			int rc = futex_key_prepare_result(futex_addrs[i],
				binary[s], &base, &offset, &is_private);

			mix_signed(&digest, rc);
			mix(&digest, base);
			mix(&digest, offset);
			mix_signed(&digest, is_private);
		}
	}

	for (unsigned int i = 0; i < sizeof(bitsets) / sizeof(bitsets[0]); i++) {
		mix_signed(&digest, futex_wake_bitset_valid_result(bitsets[i]));
		for (unsigned int j = 0; j < sizeof(bitsets) / sizeof(bitsets[0]); j++) {
			mix_signed(&digest, futex_waiter_matches_bitset_result(
				bitsets[i], bitsets[j]));
		}
	}

	for (unsigned int w = 0; w < sizeof(wake_counts) / sizeof(wake_counts[0]); w++) {
		for (unsigned int n = 0; n < sizeof(wake_counts) / sizeof(wake_counts[0]); n++) {
			mix_signed(&digest, futex_wake_limit_reached_result(
				wake_counts[w], wake_counts[n]));
			mix_signed(&digest, futex_requeue_loop_done_result(
				wake_counts[w], wake_counts[n],
				wake_counts[(w + n) % (sizeof(wake_counts) / sizeof(wake_counts[0]))]));
			mix_signed(&digest, futex_requeue_should_wake_result(
				wake_counts[w], wake_counts[n]));
		}
	}
	mix_signed(&digest, futex_requeue_should_move_result(0x1000, 0x1000));
	mix_signed(&digest, futex_requeue_should_move_result(0x1000, 0x2000));
	mix(&digest, futex_op_digest());
	mix(&digest, futex_value_load_digest());
	mix(&digest, mc_jhash2_digest());
	mix(&digest, futex_hash_bucket_table_init_digest());
	mix(&digest, futex_init_table_digest());
	mix(&digest, futex_hash_bucket_digest());
	mix(&digest, futex_dispatch_digest());
	mix(&digest, futex_double_lock_digest());
	mix(&digest, futex_wake_mark_woken_digest());
	mix(&digest, futex_wake_orchestrate_digest());
	mix(&digest, futex_unqueue_detach_digest());
	mix(&digest, futex_unqueue_me_digest());
	mix(&digest, futex_wake_scan_digest());
	mix(&digest, futex_wake_body_digest());
	mix(&digest, futex_wake_op_body_digest());
	mix(&digest, futex_requeue_move_digest());
	mix(&digest, futex_requeue_key_update_digest());
	mix(&digest, futex_requeue_scan_digest());
	mix(&digest, futex_requeue_body_digest());
	mix(&digest, futex_queue_publish_waiter_digest());
	mix(&digest, futex_queue_insert_digest());
	mix(&digest, futex_queue_me_digest());
	mix(&digest, futex_get_key_digest());
	mix(&digest, futex_wait_setup_digest());
	mix(&digest, futex_wait_q_init_digest());
	mix(&digest, futex_wait_state_digest());
	mix(&digest, futex_wait_schedule_action_digest());
	mix(&digest, futex_wait_queue_me_digest());
	mix(&digest, futex_wait_post_action_digest());
	mix(&digest, futex_wait_body_digest());
	mix(&digest, futex_wait_entry_digest());
	mix(&digest, futex_wake_packet_digest());

	for (unsigned int n = 0; n < sizeof(binary) / sizeof(binary[0]); n++) {
		for (int tid = 0; tid <= 2; tid++) {
			for (int runq = 0; runq <= 3; runq++) {
				mix_signed(&digest,
					syscall_offload_should_schedule_result(
						binary[n], tid, binary[tid & 1],
						runq, binary[runq & 1]));
			}
		}
	}

	printf("sched_helpers ok digest=%016lx\n", digest);
	return 0;
}
