#include <bitops.h>

int printf(const char *fmt, ...);

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void fill_words(unsigned long *words, unsigned int pattern)
{
	unsigned long seed = 0x123456789abcdef0UL + pattern * 0x102030405060708UL;

	for (unsigned int i = 0; i < 4; i++) {
		seed = seed * 2862933555777941757UL + 3037000493UL;
		words[i] = seed;
	}

	if ((pattern & 7) == 0) {
		for (unsigned int i = 0; i < 4; i++)
			words[i] = 0;
	} else if ((pattern & 7) == 1) {
		for (unsigned int i = 0; i < 4; i++)
			words[i] = ~0UL;
	} else if ((pattern & 7) == 2) {
		for (unsigned int i = 0; i < 4; i++)
			words[i] = 1UL << ((pattern + i * 17) & 63);
	}
}

int main(void)
{
	unsigned long words[4];
	int bits[] = { 0, 1, 2, 7, 15, 31, 32, 33, 47, 63, 64, 65, 95, 96,
		97, 111, 127 };
	unsigned int values[] = { 0, 1, 2, 3, 0x80000000U, 0x7fffffffU,
		0xffffffffU, 0x01010101U, 0x00f00000U };
	unsigned long aligns[] = { 1, 2, 8, 64, 4096 };
	unsigned long digest = 0xb170059eade7UL;

	for (unsigned int vi = 0; vi < sizeof(values) / sizeof(values[0]); vi++) {
		unsigned int value = values[vi];

		mix(&digest, (unsigned long)fls((int)value));
		mix(&digest, (unsigned long)ffs((int)value));
		if (value != 0)
			mix(&digest, __ffs((unsigned long)value));
		if (value != 0xffffffffU)
			mix(&digest, ffz((unsigned long)value));
		mix(&digest, hweight_long((unsigned long)value));
		mix(&digest, ihk_bit_word((unsigned long)value));
		for (unsigned int ai = 0; ai < sizeof(aligns) / sizeof(aligns[0]); ai++) {
			unsigned long aligned = ihk_align((unsigned long)value, aligns[ai]);
			mix(&digest, aligned);
			mix(&digest, ihk_align_mask((unsigned long)value, aligns[ai] - 1));
			mix(&digest, (unsigned long)ihk_is_aligned(aligned, aligns[ai]));
			mix(&digest, (unsigned long)ihk_is_aligned((unsigned long)value, aligns[ai]));
		}
	}

	for (unsigned int pattern = 0; pattern < 64; pattern++) {
		fill_words(words, pattern);
		for (unsigned int bi = 0; bi < sizeof(bits) / sizeof(bits[0]); bi++)
			mix(&digest, (unsigned long)test_bit(bits[bi], words));

		for (unsigned int bi = 0; bi < sizeof(bits) / sizeof(bits[0]); bi += 2)
			set_bit(bits[bi], words);
		for (unsigned int bi = 0; bi < sizeof(bits) / sizeof(bits[0]); bi++)
			mix(&digest, (unsigned long)test_bit(bits[bi], words));

		for (unsigned int bi = 1; bi < sizeof(bits) / sizeof(bits[0]); bi += 3)
			clear_bit(bits[bi], words);
		for (unsigned int bi = 0; bi < sizeof(bits) / sizeof(bits[0]); bi++)
			mix(&digest, (unsigned long)test_bit(bits[bi], words));

		for (unsigned int i = 0; i < 4; i++)
			mix(&digest, words[i]);
	}

	printf("bitops_header ok digest=%016lx\n", digest);
	return 0;
}
