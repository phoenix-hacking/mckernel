#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#define SCD_MSG_PROCFS_TID_CREATE 0x44
#define SCD_MSG_PROCFS_TID_DELETE 0x45
#define SCD_MSG_SYSFS_REQ_CREATE 0x30
#define SCD_MSG_SYSFS_REQ_MKDIR 0x32
#define SCD_MSG_SYSFS_REQ_SYMLINK 0x34
#define SCD_MSG_SYSFS_REQ_LOOKUP 0x36
#define SCD_MSG_SYSFS_REQ_UNLINK 0x38
#define SCD_MSG_SYSFS_REQ_SHOW 0x3a
#define SCD_MSG_SYSFS_RESP_SHOW 0x3b
#define SCD_MSG_SYSFS_REQ_STORE 0x3c
#define SCD_MSG_SYSFS_RESP_STORE 0x3d
#define SCD_MSG_SYSFS_REQ_RELEASE 0x3e
#define SCD_MSG_SYSFS_RESP_RELEASE 0x3f
#define SCD_MSG_SYSFS_REQ_SETUP 0x40

struct futex_key {
	unsigned long opaque[3];
};

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct plist_head {
	struct list_head prio_list;
	struct list_head node_list;
};

struct plist_node {
	int prio;
	struct plist_head plist;
};

struct fake_futex_q {
	struct plist_node list;
	void *task;
	void *lock_ptr;
	struct futex_key key;
	struct futex_key *requeue_pi_key;
	unsigned int bitset;
	void *uti_futex_resp;
	int linux_cpu;
};

struct fake_wake_body_bucket {
	unsigned long pad;
	unsigned long lock;
	struct plist_head chain;
};

static void init_list_head(struct list_head *list)
{
	list->next = list;
	list->prev = list;
}

static void plist_head_init(struct plist_head *head)
{
	init_list_head(&head->prio_list);
	init_list_head(&head->node_list);
}

static void plist_node_init(struct plist_node *node, int prio)
{
	node->prio = prio;
	plist_head_init(&node->plist);
}

static int plist_node_empty(const struct plist_node *node)
{
	return node->plist.node_list.next == &node->plist.node_list;
}

static void list_add_tail_local(struct list_head *entry,
		struct list_head *head)
{
	struct list_head *prev = head->prev;

	entry->next = head;
	entry->prev = prev;
	prev->next = entry;
	head->prev = entry;
}

static void list_del_init_local(struct list_head *entry)
{
	entry->next->prev = entry->prev;
	entry->prev->next = entry->next;
	init_list_head(entry);
}

static void plist_add(struct plist_node *node, struct plist_head *head)
{
	list_add_tail_local(&node->plist.prio_list, &head->prio_list);
	list_add_tail_local(&node->plist.node_list, &head->node_list);
}

static void futex_wake_mark_woken_result(unsigned long q_addr,
		unsigned long list_offset, unsigned long node_plist_offset,
		unsigned long lock_ptr_offset)
{
	struct plist_node *node =
		(struct plist_node *)(q_addr + list_offset);

	(void)node_plist_offset;
	if (!plist_node_empty(node)) {
		list_del_init_local(&node->plist.node_list);
		list_del_init_local(&node->plist.prio_list);
	}
	*(void **)(q_addr + lock_ptr_offset) = NULL;
}

static int futex_requeue_move_result(unsigned long q_addr,
		unsigned long list_offset, unsigned long lock_ptr_offset,
		unsigned long source_chain_addr, unsigned long target_chain_addr,
		unsigned long target_lock_addr, unsigned long debug_offset)
{
	struct plist_node *node =
		(struct plist_node *)(q_addr + list_offset);
	struct plist_head *target = (struct plist_head *)target_chain_addr;

	(void)debug_offset;
	if (source_chain_addr == target_chain_addr)
		return 0;
	list_del_init_local(&node->plist.node_list);
	list_del_init_local(&node->plist.prio_list);
	plist_add(node, target);
	*(void **)(q_addr + lock_ptr_offset) = (void *)target_lock_addr;
	return 1;
}

static int futex_requeue_key_update_result(unsigned long q_addr,
		unsigned long key_offset, unsigned long key_addr,
		unsigned long key_size, void (*key_refs)(unsigned long))
{
	if (!q_addr || !key_addr || !key_size || !key_refs)
		return -22;
	key_refs(key_addr);
	memcpy((void *)(q_addr + key_offset), (void *)key_addr, key_size);
	return 0;
}

#define SYSFS_PATH_MAX 1024
#define SYSFS_SNOOPING_OPS_d32 ((void *)1)
#define SYSFS_SNOOPING_OPS_d64 ((void *)2)
#define SYSFS_SNOOPING_OPS_u32 ((void *)3)
#define SYSFS_SNOOPING_OPS_u64 ((void *)4)
#define SYSFS_SNOOPING_OPS_s ((void *)5)
#define SYSFS_SNOOPING_OPS_pbl ((void *)6)
#define SYSFS_SNOOPING_OPS_pb ((void *)7)
#define SYSFS_SNOOPING_OPS_u32K ((void *)8)
#define SNT_FILE 1
#define SNT_DIR 2
#define PROCFS_DIR_MODE_0555 0040555
#define MCEXEC_UP_PREPARE_IMAGE 0x30a02900UL
#define MCEXEC_UP_TRANSFER 0x30a02901UL
#define MCEXEC_UP_TRANSFER_TO_REMOTE 0
#define MCEXEC_UP_TRANSFER_FROM_REMOTE 1
#define MCEXEC_UP_START_IMAGE 0x30a02902UL
#define MCEXEC_UP_WAIT_SYSCALL 0x30a02903UL
#define MCEXEC_UP_RET_SYSCALL 0x30a02904UL
#define MCEXEC_UP_LOAD_SYSCALL 0x30a02905UL
#define MCEXEC_UP_SEND_SIGNAL 0x30a02906UL
#define MCEXEC_UP_GET_CPU 0x30a02907UL
#define MCEXEC_UP_STRNCPY_FROM_USER 0x30a02908UL
#define MCEXEC_UP_GET_CRED 0x30a0290aUL
#define MCEXEC_UP_GET_CREDV 0x30a0290bUL
#define MCEXEC_UP_GET_NODES 0x30a0290cUL
#define MCEXEC_UP_GET_CPUSET 0x30a0290dUL
#define MCEXEC_UP_CREATE_PPD 0x30a0290eUL
#define MCEXEC_UP_PREPARE_DMA 0x30a02910UL
#define MCEXEC_UP_FREE_DMA 0x30a02911UL
#define MCEXEC_UP_OPEN_EXEC 0x30a02912UL
#define MCEXEC_UP_CLOSE_EXEC 0x30a02913UL
#define MCEXEC_UP_SYS_MOUNT 0x30a02914UL
#define MCEXEC_UP_SYS_UMOUNT 0x30a02915UL
#define MCEXEC_UP_SYS_UNSHARE 0x30a02916UL
#define MCEXEC_UP_UTI_GET_CTX 0x30a02920UL
#define MCEXEC_UP_UTI_SWITCH_CTX 0x30a02921UL
#define MCEXEC_UP_SIG_THREAD 0x30a02922UL
#define MCEXEC_UP_SYSCALL_THREAD 0x30a02924UL
#define MCEXEC_UP_TERMINATE_THREAD 0x30a02925UL
#define MCEXEC_UP_GET_NUM_POOL_THREADS 0x30a02926UL
#define MCEXEC_UP_UTI_ATTR 0x30a02927UL
#define MCEXEC_UP_RELEASE_USER_SPACE 0x30a02928UL
#define MCEXEC_UP_DEBUG_LOG 0x40000000UL
#define SCD_MSG_SEND_SIGNAL 0x7
#define SCD_MSG_DEBUG_LOG 0x20
#define SCD_MSG_CPU_RW_REG 0x52
#define MCCTRL_OS_CPU_READ_REGISTER 0
#define MCCTRL_OS_CPU_WRITE_REGISTER 1
#define IHK_OS_AUX_PERF_NUM 0x11290100UL
#define IHK_OS_AUX_PERF_SET 0x11290101UL
#define IHK_OS_AUX_PERF_GET 0x11290102UL
#define IHK_OS_AUX_PERF_ENABLE 0x11290103UL
#define IHK_OS_AUX_PERF_DISABLE 0x11290104UL
#define IHK_OS_AUX_PERF_DESTROY 0x11290105UL
#define IHK_OS_GETRUSAGE 0x11290106UL
#define IHK_MAX_NUM_PGSIZES 8
#define IHK_MAX_NUM_NUMA_NODES 1024
#define IHK_MAX_NUM_CPUS 1024
#define FAKE_NR_CLOSE 3UL
#define FAKE_NR_MMAP 9UL
#define FAKE_NR_MPROTECT 10UL
#define FAKE_NR_MUNMAP 11UL
#define FAKE_NR_SCHED_SETPARAM 142UL
#define FAKE_NR_EXIT_GROUP 231UL
#define FAKE_NR_MOVE_PAGES 279UL
#define FAKE_NR_COREDUMP 999UL
#define FAKE_SCHED_CHECK_SAME_OWNER 1UL
#define FAKE_SCHED_CHECK_ROOT 2UL
#define PAGER_REQ_CREATE 1UL
#define PAGER_REQ_RELEASE 2UL
#define PAGER_REQ_READ 3UL
#define PAGER_REQ_WRITE 4UL
#define PAGER_REQ_MAP 5UL
#define PAGER_REQ_PFN 6UL
#define PAGER_REQ_UNMAP 7UL
#define PAGER_REQ_MLOCK_LIST 8UL
#define SCD_MSG_REMOTE_PAGE_FAULT 0x18
#define FAKE_VM_PFNMAP 0x400UL
#define FUTEX_WAIT 0
#define FUTEX_WAKE 1
#define FUTEX_REQUEUE 3
#define FUTEX_CMP_REQUEUE 4
#define FUTEX_WAKE_OP 5
#define FUTEX_WAIT_BITSET 9
#define FUTEX_WAKE_BITSET 10
#define FUTEX_WAIT_REQUEUE_PI 11
#define FUTEX_CLOCK_REALTIME 256
#define FUTEX_BITSET_MATCH_ANY 0xffffffffU
#define EINVAL 22
#define ENOSPC 28
#define ENOSYS 38
#define EINTR 4
#define ETIMEDOUT 110
#define ENOENT 2
#define ENOTDIR 20

struct mcctrl_procfs_work_prefix {
	void *os;
	int msg;
	int pid;
	unsigned long arg;
	unsigned long resp_pa;
	unsigned char work_tail[64];
};

struct mcctrl_sysfs_work_prefix {
	void *os;
	int msg;
	int err;
	long arg1;
	long arg2;
	unsigned char work_tail[64];
};

struct mcctrl_sysfs_req_create_param {
	int mode;
	int error;
	long client_ops;
	long client_instance;
	char path[SYSFS_PATH_MAX];
	int padding;
	int busy;
};

struct mcctrl_sysfs_req_mkdir_param {
	int error;
	int padding;
	long handle;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};

struct mcctrl_sysfs_req_symlink_param {
	int error;
	int padding;
	long target;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};

struct mcctrl_sysfs_req_lookup_param {
	int error;
	int padding;
	long handle;
	char path[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};

struct mcctrl_sysfs_req_unlink_param {
	int flags;
	int error;
	char path[SYSFS_PATH_MAX];
	int padding;
	int busy;
};

struct mcctrl_sysfs_req_setup_param {
	int error;
	int padding;
	long buf_rpa;
	long bufsize;
	char padding3[SYSFS_PATH_MAX];
	int padding2;
	int busy;
};

struct mcctrl_sysfsm_bitmap_param {
	int nbits;
	int padding;
	void *ptr;
};

struct mcctrl_sysfsm_ops {
	ssize_t (*show)(struct mcctrl_sysfsm_ops *, void *, void *, size_t);
	ssize_t (*store)(struct mcctrl_sysfsm_ops *, void *, const void *,
			size_t);
	void (*release)(struct mcctrl_sysfsm_ops *, void *);
};

struct mcctrl_sysfs_local_node {
	int type;
	long client_ops;
	long client_instance;
};

struct mcctrl_rb_node {
	unsigned long parent_color;
	struct mcctrl_rb_node *right;
	struct mcctrl_rb_node *left;
};

struct mcctrl_rb_root {
	struct mcctrl_rb_node *node;
};

struct fake_rva_to_rpa_cache_node {
	struct mcctrl_rb_node node;
	unsigned long rva;
	unsigned long rpa;
	int freed;
};

struct fake_mcctrl_list_head {
	struct fake_mcctrl_list_head *next;
	struct fake_mcctrl_list_head *prev;
};

struct fake_mcctrl_ptd {
	void *ppd;
	struct fake_mcctrl_list_head hash;
	void *task;
	void *data;
	int tid;
	int refcount;
};

struct fake_mcctrl_ppd {
	struct fake_mcctrl_list_head thread_hash[256];
	unsigned char thread_lock[256];
};

struct fake_mcctrl_pidfd_entry {
	void *filp;
	unsigned long os;
	void *group_leader;
	int pid;
	int fd;
	struct fake_mcctrl_list_head hash;
	char tofu_dev_path[128];
	void *pde_data;
};

struct fake_mcctrl_pager {
	struct fake_mcctrl_list_head list;
	void *inode;
	unsigned long ref;
	void *rofile;
	void *rwfile;
	unsigned long map_uaddr;
	unsigned long map_len;
	unsigned long map_off;
};

struct fake_mcctrl_pager_ppd {
	struct fake_mcctrl_list_head devobj_pager_list;
	unsigned char devobj_pager_lock;
};

struct mcctrl_syscall_ptd_offsets {
	unsigned long ppd_thread_hash;
	unsigned long ppd_thread_lock;
	unsigned long ptd_ppd;
	unsigned long ptd_hash;
	unsigned long ptd_task;
	unsigned long ptd_data;
	unsigned long ptd_tid;
	unsigned long ptd_refcount;
	unsigned long list_head_size;
	unsigned long rwlock_size;
};

struct mcctrl_syscall_pidfd_offsets {
	unsigned long entry_filp;
	unsigned long entry_os;
	unsigned long entry_group_leader;
	unsigned long entry_pid;
	unsigned long entry_fd;
	unsigned long entry_hash;
	unsigned long entry_tofu_dev_path;
	unsigned long entry_pde_data;
	unsigned long list_head_size;
	unsigned long tofu_dev_path_size;
};

struct mcctrl_syscall_pager_offsets {
	unsigned long ppd_devobj_pager_list;
	unsigned long ppd_devobj_pager_lock;
	unsigned long pager_list;
	unsigned long pager_rofile;
	unsigned long pager_rwfile;
};

typedef struct mcctrl_procfs_work_prefix *(*mcctrl_procfs_work_alloc_fn_t)(
		unsigned long);
typedef void (*mcctrl_procfs_work_init_schedule_fn_t)(
		struct mcctrl_procfs_work_prefix *);
typedef void (*mcctrl_procfs_alloc_failed_fn_t)(void);
typedef int (*mcctrl_procfs_get_index_fn_t)(void *);
typedef void (*mcctrl_procfs_entry_fn_t)(int, int, int);
typedef void *(*mcctrl_procfs_os_to_dev_fn_t)(void *);
typedef unsigned long (*mcctrl_procfs_map_memory_fn_t)(void *,
		unsigned long, unsigned long);
typedef void *(*mcctrl_procfs_map_virtual_fn_t)(void *, unsigned long,
		unsigned long, void *, int);
typedef void (*mcctrl_procfs_unmap_virtual_fn_t)(void *, void *,
		unsigned long);
typedef void (*mcctrl_procfs_unmap_memory_fn_t)(void *, unsigned long,
		unsigned long);
typedef void (*mcctrl_procfs_unknown_work_fn_t)(int, int, unsigned long);
typedef void (*mcctrl_procfs_free_work_fn_t)(void *);
typedef int (*mcctrl_procfs_format_name_fn_t)(char *, unsigned long, int);
typedef void *(*mcctrl_procfs_find_entry_fn_t)(void *, const char *);
typedef void *(*mcctrl_procfs_add_entry_fn_t)(void *, const char *, int);
typedef void (*mcctrl_procfs_set_osnum_fn_t)(void *, int);
typedef const char *(*mcctrl_procfs_entry_name_fn_t)(const void *);
typedef void *(*mcctrl_procfs_entry_parent_fn_t)(const void *);
typedef unsigned int (*mcctrl_procfs_entry_mode_fn_t)(const void *);
typedef const void *(*mcctrl_procfs_entry_fops_fn_t)(const void *);
typedef const void *(*mcctrl_procfs_entry_next_fn_t)(const void *,
		unsigned long);
typedef void (*mcctrl_procfs_add_entry_with_ids_fn_t)(void *,
		const char *, unsigned int, const void *, const void *,
		const void *);
typedef void *(*mcctrl_procfs_first_entry_fn_t)(void *);
typedef void *(*mcctrl_procfs_next_entry_fn_t)(void *, void *);
typedef void (*mcctrl_procfs_delete_entry_fn_t)(void *);
typedef void *(*mcctrl_procfs_alloc_entry_fn_t)(unsigned long);
typedef void (*mcctrl_procfs_init_entry_fn_t)(void *, const char *);
typedef void *(*mcctrl_procfs_create_pde_fn_t)(void *, const char *,
		unsigned int, const void *, const void *, const void *, void *);
typedef void (*mcctrl_procfs_commit_entry_fn_t)(void *, void *, void *,
		const void *, const void *);
typedef void (*mcctrl_procfs_entry_log_fn_t)(const char *);
typedef void (*mcctrl_procfs_entry_void_fn_t)(void *);
typedef void *(*mcctrl_procfs_entry_data_fn_t)(void *);
typedef void (*mcctrl_procfs_void_fn_t)(void);
typedef void *(*mcctrl_procfs_find_vpid_fn_t)(int);
typedef void *(*mcctrl_procfs_pid_task_fn_t)(void *, int);
typedef void *(*mcctrl_procfs_task_cred_fn_t)(void *);
typedef struct mcctrl_sysfs_work_prefix *(*mcctrl_sysfs_work_alloc_fn_t)(
		unsigned long);
typedef void (*mcctrl_sysfs_work_init_schedule_fn_t)(
		struct mcctrl_sysfs_work_prefix *);
typedef void (*mcctrl_sysfs_alloc_failed_fn_t)(void);
typedef void (*mcctrl_sysfs_request_fn_t)(void *, long);
typedef void (*mcctrl_sysfs_response_fn_t)(void *, void *, long);
typedef void (*mcctrl_sysfs_release_response_fn_t)(void *, void *, int);
typedef void (*mcctrl_sysfs_unknown_work_fn_t)(int, void *, long, long);
typedef void (*mcctrl_sysfs_free_work_fn_t)(void *);
typedef void *(*mcctrl_sysfs_local_alloc_fn_t)(unsigned long);
typedef void (*mcctrl_sysfs_local_copy_fn_t)(void *, const void *,
		unsigned long);
typedef void (*mcctrl_sysfs_unknown_ops_fn_t)(long);
typedef long (*mcctrl_sysfs_node_long_fn_t)(void *);
typedef int (*mcctrl_sysfs_node_type_fn_t)(void *);
typedef const char *(*mcctrl_sysfs_node_name_fn_t)(void *);
typedef void *(*mcctrl_sysfs_node_ptr_fn_t)(void *);
typedef void *(*mcctrl_sysfs_node_next_fn_t)(void *, void *);
typedef void *(*mcctrl_sysfs_err_ptr_fn_t)(int);
typedef void (*mcctrl_sysfs_free_fn_t)(void *);
typedef int (*mcctrl_sysfs_local_create_fn_t)(
		void *, struct mcctrl_sysfs_req_create_param *);
typedef int (*mcctrl_sysfs_local_mkdir_fn_t)(
		void *, struct mcctrl_sysfs_req_mkdir_param *);
typedef int (*mcctrl_sysfs_local_symlink_fn_t)(
		void *, struct mcctrl_sysfs_req_symlink_param *);
typedef int (*mcctrl_sysfs_local_lookup_fn_t)(
		void *, struct mcctrl_sysfs_req_lookup_param *);
typedef int (*mcctrl_sysfs_local_unlink_fn_t)(
		void *, struct mcctrl_sysfs_req_unlink_param *);
typedef void (*mcctrl_sysfs_cleanup_special_fn_t)(void *, void *);
typedef void (*mcctrl_sysfs_error_fn_t)(int);
typedef int (*mcctrl_sysfs_sem_down_fn_t)(void *);
typedef void (*mcctrl_sysfs_sem_up_fn_t)(void *);
typedef int (*mcctrl_sysfs_wait_ready_fn_t)(void *);
typedef void (*mcctrl_sysfs_set_busy_fn_t)(void *, int);
typedef int (*mcctrl_sysfs_send_fn_t)(void *, int, int, long, long, long,
		int);
typedef long (*mcctrl_sysfs_req_result_fn_t)(void *);
typedef unsigned long (*mcctrl_sysfs_bitmap_format_fn_t)(void *,
		unsigned long, void *, int);
typedef void *(*mcctrl_sysfs_os_to_dev_fn_t)(void *);
typedef unsigned long (*mcctrl_sysfs_map_memory_fn_t)(void *,
		unsigned long, unsigned long);
typedef void *(*mcctrl_sysfs_map_virtual_simple_fn_t)(void *,
		unsigned long, unsigned long);
typedef void (*mcctrl_sysfs_unmap_virtual_fn_t)(void *, void *,
		unsigned long);
typedef void (*mcctrl_sysfs_unmap_memory_fn_t)(void *, unsigned long,
		unsigned long);
typedef void (*mcctrl_sysfs_wmb_fn_t)(void);
typedef int (*mcctrl_sysfs_req_setup_local_fn_t)(void *, void *,
		unsigned long, unsigned long);
typedef int (*mcctrl_sysfs_req_create_local_fn_t)(void *,
		struct mcctrl_sysfs_req_create_param *);
typedef int (*mcctrl_sysfs_req_mkdir_local_fn_t)(void *,
		struct mcctrl_sysfs_req_mkdir_param *);
typedef int (*mcctrl_sysfs_req_symlink_local_fn_t)(void *,
		struct mcctrl_sysfs_req_symlink_param *);
typedef int (*mcctrl_sysfs_req_lookup_local_fn_t)(void *,
		struct mcctrl_sysfs_req_lookup_param *);
typedef int (*mcctrl_sysfs_req_unlink_local_fn_t)(void *,
		struct mcctrl_sysfs_req_unlink_param *);
typedef int (*mcctrl_futex_wait_fn_t)(uint32_t *, int, uint32_t,
		uint64_t, uint32_t, int, void *);
typedef int (*mcctrl_futex_wake_fn_t)(uint32_t *, int, int, uint32_t,
		void *);
typedef int (*mcctrl_futex_requeue_fn_t)(uint32_t *, int, uint32_t *,
		int, int, uint32_t *, int, void *);
typedef int (*mcctrl_futex_wake_op_fn_t)(uint32_t *, int, uint32_t *,
		int, int, int, void *);
typedef void (*mcctrl_futex_warn_fn_t)(int);
typedef void *(*mcctrl_futex_info_ptr_fn_t)(void *);
typedef int (*mcctrl_futex_current_cpu_fn_t)(void);
typedef void (*mcctrl_futex_prepare_wait_q_fn_t)(void *, uint32_t,
		void *, int);
typedef int (*mcctrl_futex_wait_setup_fn_t)(uint32_t *, uint32_t,
		int, void *, void **, void *);
typedef long long (*mcctrl_futex_wait_queue_fn_t)(void *, void *,
		uint64_t, void *);
typedef int (*mcctrl_futex_unqueue_fn_t)(void *);
typedef void (*mcctrl_futex_put_q_key_fn_t)(int, void *);
typedef void (*mcctrl_futex_wait_log_fn_t)(int, void *);
typedef int (*mcctrl_futex_get_key_body_fn_t)(unsigned long, int,
		unsigned long, unsigned long);
typedef unsigned long (*mcctrl_futex_hash_key_fn_t)(unsigned long,
		unsigned long);
typedef unsigned long (*mcctrl_futex_wake_lock_fn_t)(unsigned long);
typedef void (*mcctrl_futex_wake_unlock_fn_t)(unsigned long,
		unsigned long);
typedef void (*mcctrl_futex_hb_lock_fn_t)(unsigned long);
typedef void (*mcctrl_futex_hb_unlock_fn_t)(unsigned long);
typedef void (*mcctrl_futex_put_key_fn_t)(int, unsigned long);
typedef void (*mcctrl_futex_wake_entry_fn_t)(unsigned long,
		unsigned long);
typedef int (*mcctrl_futex_atomic_op_fn_t)(int, unsigned long);
typedef int (*mcctrl_futex_get_value_fn_t)(unsigned long, unsigned long);
typedef void (*mcctrl_futex_drop_key_refs_fn_t)(unsigned long);
typedef void (*mcctrl_futex_requeue_entry_fn_t)(unsigned long,
		unsigned long);
typedef void *(*mcctrl_syscall_ptd_alloc_fn_t)(unsigned long);
typedef void (*mcctrl_syscall_ptd_free_fn_t)(void *);
typedef unsigned long (*mcctrl_syscall_ptd_lock_fn_t)(void *);
typedef void (*mcctrl_syscall_ptd_unlock_fn_t)(void *, unsigned long);
typedef void (*mcctrl_syscall_ptd_log_fn_t)(int, int, void *);
typedef void *(*mcctrl_syscall_pidfd_alloc_fn_t)(unsigned long);
typedef void (*mcctrl_syscall_pidfd_free_fn_t)(void *);
typedef void (*mcctrl_syscall_pidfd_lock_init_fn_t)(void *);
typedef unsigned long (*mcctrl_syscall_pidfd_lock_fn_t)(void *);
typedef void (*mcctrl_syscall_pidfd_unlock_fn_t)(void *, unsigned long);
typedef void (*mcctrl_syscall_pidfd_log_fn_t)(int, void *, int, int);
typedef unsigned long (*mcctrl_syscall_pager_lock_fn_t)(void *);
typedef void (*mcctrl_syscall_pager_unlock_fn_t)(void *, unsigned long);
typedef int (*mcctrl_syscall_pager_predicate_fn_t)(void);
typedef int (*mcctrl_syscall_pager_sem_down_fn_t)(void *);
typedef void (*mcctrl_syscall_pager_sem_up_fn_t)(void *);
typedef void (*mcctrl_syscall_pager_ptr_fn_t)(void *);
typedef void (*mcctrl_syscall_pager_log_fn_t)(int, void *, int);
typedef long (*mcctrl_control_dispatch_fn_t)(unsigned long, unsigned long,
		unsigned long);
struct mcctrl_syscall_request {
	int rtid;
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};

struct mcctrl_ikc_packet_header {
	void *channel;
};

struct mcctrl_ikc_scd_packet_traditional {
	int ref;
	int osnum;
	int pid;
	unsigned long arg;
	struct mcctrl_syscall_request req;
	unsigned long resp_pa;
};

struct mcctrl_ikc_scd_packet_cpu_rw {
	unsigned long pdesc;
	int op;
	void *resp;
};

struct mcctrl_ikc_scd_packet_remote_page_fault {
	int target_cpu;
	int fault_tid;
	unsigned long fault_address;
	unsigned long fault_reason;
};

union mcctrl_ikc_scd_packet_body {
	struct mcctrl_ikc_scd_packet_traditional traditional;
	struct mcctrl_ikc_scd_packet_cpu_rw cpu_rw;
	struct mcctrl_ikc_scd_packet_remote_page_fault remote_page_fault;
	unsigned char raw[104];
};

struct mcctrl_ikc_scd_packet {
	struct mcctrl_ikc_packet_header header;
	int msg;
	int err;
	void *reply;
	union mcctrl_ikc_scd_packet_body body;
};

struct ihk_os_cpu_register {
	unsigned long addr;
	unsigned long val;
	unsigned long addr_ext;
	int sync;
};

struct prepare_dma_desc {
	unsigned long size;
	unsigned long pa;
};

struct free_dma_desc {
	unsigned long pa;
	unsigned long size;
};

struct sys_mount_desc {
	char *dev_name;
	char *dir_name;
	char *type_name;
	unsigned long flags;
	void *data;
};

struct sys_umount_desc {
	char *dir_name;
};

struct sys_unshare_desc {
	unsigned long unshare_flags;
};

struct release_user_space_desc {
	unsigned long user_start;
	unsigned long user_end;
};

struct mcctrl_ioctl_getrusage_desc {
	void *rusage;
	unsigned long size_rusage;
};

struct fake_rusage_percpu {
	unsigned long user_tsc;
	unsigned long system_tsc;
};

struct fake_rusage_global {
	long memory_stat_rss[IHK_MAX_NUM_PGSIZES];
	long memory_stat_mapped_file[IHK_MAX_NUM_PGSIZES];
	long rss_current;
	unsigned long memory_max_usage;
	unsigned long max_num_threads;
	unsigned long num_threads;
	unsigned long memory_kmem_usage;
	unsigned long memory_kmem_max_usage;
	unsigned long memory_numa_stat[IHK_MAX_NUM_NUMA_NODES];
	struct fake_rusage_percpu cpu[IHK_MAX_NUM_CPUS];
	unsigned long total_memory;
	unsigned long total_memory_usage;
	unsigned long total_memory_max_usage;
	unsigned long num_numa_nodes;
	unsigned long num_processors;
	unsigned long ns_per_tsc;
};

struct fake_ihk_os_rusage {
	unsigned long memory_stat_rss[IHK_MAX_NUM_PGSIZES];
	unsigned long memory_stat_mapped_file[IHK_MAX_NUM_PGSIZES];
	unsigned long memory_max_usage;
	unsigned long memory_kmem_usage;
	unsigned long memory_kmem_max_usage;
	unsigned long memory_numa_stat[IHK_MAX_NUM_NUMA_NODES];
	unsigned long cpuacct_stat_system;
	unsigned long cpuacct_stat_user;
	unsigned long cpuacct_usage;
	unsigned long cpuacct_usage_percpu[IHK_MAX_NUM_CPUS];
	int num_threads;
	int max_num_threads;
};

#define PERF_CTRL_SET 0
#define PERF_CTRL_GET 1
#define PERF_CTRL_ENABLE 2
#define PERF_CTRL_DISABLE 3

struct ihk_perf_event_attr {
	unsigned long config;
	unsigned disabled:1;
	unsigned pinned:1;
	unsigned exclude_user:1;
	unsigned exclude_kernel:1;
	unsigned exclude_hv:1;
	unsigned exclude_idle:1;
};

struct fake_control_perf_desc {
	int ctrl_type;
	int err;
	unsigned int target_cntr;
	unsigned long config;
	unsigned long read_value;
	unsigned long target_cntr_mask;
	unsigned exclude_user;
	unsigned exclude_kernel;
};

struct fake_control_remote_transfer {
	unsigned long rphys;
	void *userp;
	unsigned long size;
	char direction;
};

struct fake_control_syscall_load_desc {
	unsigned long cpu;
	unsigned long src;
	unsigned long dest;
	unsigned long size;
};

struct fake_control_syscall_ret_desc {
	long cpu;
	long ret;
	unsigned long src;
	unsigned long dest;
	unsigned long size;
};

struct fake_control_uti_get_ctx_desc {
	unsigned long rp_rctx;
	void *rctx;
	void *lctx;
	int uti_refill_tid;
	unsigned long key;
};

struct fake_user_vma {
	unsigned long start;
	unsigned long end;
	unsigned long flags;
};

typedef int (*mcctrl_control_ikc_send_fn_t)(unsigned long, int,
		struct mcctrl_ikc_scd_packet *);
typedef void *(*mcctrl_control_get_ptr_fn_t)(unsigned long);
typedef void *(*mcctrl_control_ptr_field_fn_t)(void *);
typedef int (*mcctrl_control_ptr_int_fn_t)(void *);
typedef void (*mcctrl_control_log_fn_t)(int);
typedef void *(*mcctrl_control_alloc_fn_t)(unsigned long);
typedef void (*mcctrl_control_free_fn_t)(void *);
typedef unsigned long (*mcctrl_control_virt_to_phys_fn_t)(void *);
typedef int (*mcctrl_control_copy_user_fn_t)(void *, const void *,
		unsigned long);
typedef void *(*mcctrl_control_os_to_dev_fn_t)(unsigned long);
typedef unsigned long (*mcctrl_control_map_memory_fn_t)(void *,
		unsigned long, unsigned long);
typedef void *(*mcctrl_control_map_virtual_fn_t)(void *, unsigned long,
		unsigned long);
typedef void (*mcctrl_control_unmap_virtual_fn_t)(void *, void *,
		unsigned long);
typedef void (*mcctrl_control_unmap_memory_fn_t)(void *, unsigned long,
		unsigned long);
typedef void (*mcctrl_control_transfer_log_fn_t)(int);
typedef void (*mcctrl_control_load_log_fn_t)(void *, unsigned long);
typedef int (*mcctrl_control_cred_value_fn_t)(void);
typedef void *(*mcctrl_control_alloc_page_fn_t)(void);
typedef void (*mcctrl_control_free_page_fn_t)(void *);
typedef long (*mcctrl_control_strncpy_from_user_fn_t)(void *, const void *,
		unsigned long);
typedef int (*mcctrl_control_drop_exec_fn_t)(unsigned long, int);
typedef void (*mcctrl_control_destroy_ppd_log_fn_t)(int, int, void *);
typedef void *(*mcctrl_control_new_info_fn_t)(unsigned long, void *);
typedef void (*mcctrl_control_set_info_pid_fn_t)(void *, int);
typedef void (*mcctrl_control_register_release_fn_t)(void *, void *);
typedef void (*mcctrl_control_set_private_fn_t)(void *, void *);
typedef void *(*mcctrl_control_file_ptr_fn_t)(void *);
typedef int (*mcctrl_control_desc_int_fn_t)(void *);
typedef unsigned long (*mcctrl_control_desc_ulong_fn_t)(void *);
typedef unsigned long (*mcctrl_control_info_ulong_fn_t)(void *);
typedef void (*mcctrl_control_set_start_info_fn_t)(
		void *, int, int, unsigned long, unsigned long,
		unsigned long);
typedef void (*mcctrl_control_ptr_ulong_fn_t)(void *, unsigned long);
typedef void (*mcctrl_control_os_cpu_void_fn_t)(unsigned long, int);
typedef int (*mcctrl_control_schedule_send_fn_t)(
		unsigned long, int, unsigned long);
typedef void (*mcctrl_control_start_log_fn_t)(int, int);
typedef void (*mcctrl_control_signal_log_fn_t)(int, int);
typedef int (*mcctrl_control_get_order_fn_t)(unsigned long);
typedef unsigned long (*mcctrl_control_alloc_pages_fn_t)(int);
typedef void (*mcctrl_control_free_pages_fn_t)(unsigned long, int);
typedef unsigned long (*mcctrl_control_phys_to_virt_fn_t)(unsigned long);
typedef void *(*mcctrl_control_prepare_creds_fn_t)(void);
typedef void (*mcctrl_control_cap_raise_admin_fn_t)(void *);
typedef const void *(*mcctrl_control_override_creds_fn_t)(void *);
typedef void (*mcctrl_control_revert_creds_fn_t)(const void *);
typedef int (*mcctrl_control_mount_fn_t)(char *, char *, char *,
		unsigned long, void *);
typedef int (*mcctrl_control_umount_fn_t)(char *, int);
typedef int (*mcctrl_control_unshare_fn_t)(unsigned long);
typedef long (*mcctrl_control_clear_pte_range_fn_t)(unsigned long,
		unsigned long);
typedef void (*mcctrl_control_perf_set_num_fn_t)(void *, unsigned long);
typedef int (*mcctrl_control_perf_event_num_fn_t)(void *);
typedef void *(*mcctrl_control_perf_alloc_set_desc_fn_t)(
		const void *, int, unsigned int, int *);
typedef void (*mcctrl_control_perf_init_desc_fn_t)(void *, unsigned int);
typedef void (*mcctrl_control_perf_init_mask_desc_fn_t)(
		void *, int, unsigned long);
typedef int (*mcctrl_control_perf_send_wait_fn_t)(unsigned long, int,
		void *, long, int *);
typedef int (*mcctrl_control_perf_desc_err_fn_t)(void *);
typedef unsigned long (*mcctrl_control_perf_desc_read_value_fn_t)(void *);
typedef long (*mcctrl_control_long_fn_t)(unsigned long);
typedef void (*mcctrl_control_getrusage_log_fn_t)(
		int, unsigned long, unsigned long);
typedef int (*mcctrl_control_cpu_register_send_wait_fn_t)(
		unsigned long, int, struct mcctrl_ikc_scd_packet *, long,
		int *, void *);
typedef void (*mcctrl_control_cpu_register_error_log_fn_t)(int, int, int);
typedef void (*mcctrl_control_cpu_register_done_log_fn_t)(
		int, int, int, unsigned long, unsigned long);
typedef int (*mcctrl_control_validate_os_fn_t)(unsigned long);
typedef int (*mcctrl_control_current_int_fn_t)(void);
typedef void *(*mcctrl_control_current_task_fn_t)(void);
typedef unsigned long (*mcctrl_control_current_ulong_fn_t)(void);
typedef void *(*mcctrl_control_get_ppd_fn_t)(void *, int);
typedef void *(*mcctrl_control_get_ptd_fn_t)(void *, void *);
typedef void (*mcctrl_control_put_fn_t)(void *);
typedef void (*mcctrl_control_return_syscall_fn_t)(
		unsigned long, void *, void *, long, int);
typedef void (*mcctrl_control_ret_syscall_log_fn_t)(int, int, int);
typedef void (*mcctrl_control_terminate_thread_log_fn_t)(
		int, int, int, void *, int);
typedef void (*mcctrl_control_uti_log_fn_t)(int);
typedef int (*mcctrl_control_packet_ref_fn_t)(void *);
typedef int (*mcctrl_control_channel_read_cpu_fn_t)(void *, int);
typedef void (*mcctrl_control_request_cpu_error_log_fn_t)(
		int, unsigned long, int, int);
typedef void (*mcctrl_control_request_cpu_ptd_log_fn_t)(
		int, int, void *);
typedef void (*mcctrl_control_request_cpu_result_log_fn_t)(
		unsigned long, int);
typedef long (*mcctrl_in_kernel_req_fn_t)(unsigned long,
		struct mcctrl_syscall_request *);
typedef long (*mcctrl_in_kernel_clear_pte_fn_t)(unsigned long,
		unsigned long);
typedef long (*mcctrl_in_kernel_remap_fn_t)(unsigned long, unsigned long,
		int);
typedef void (*mcctrl_in_kernel_zero_pages_fn_t)(unsigned long);
typedef long (*mcctrl_in_kernel_writecore_fn_t)(unsigned long,
		unsigned long, int, unsigned long, unsigned long);
typedef long (*mcctrl_in_kernel_sched_fn_t)(int);
typedef void (*mcctrl_in_kernel_return_fn_t)(unsigned long,
		struct mcctrl_ikc_scd_packet *, long, int);
typedef void (*mcctrl_in_kernel_release_fn_t)(
		struct mcctrl_ikc_scd_packet *);
typedef long (*mcctrl_pager_create_fn_t)(unsigned long, int,
		unsigned long);
typedef long (*mcctrl_pager_release_fn_t)(unsigned long, unsigned long,
		unsigned long);
typedef long (*mcctrl_pager_io_fn_t)(unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long);
typedef long (*mcctrl_pager_map_fn_t)(unsigned long, int, unsigned long,
		unsigned long, unsigned long, int);
typedef long (*mcctrl_pager_pfn_fn_t)(unsigned long, unsigned long,
		unsigned long, unsigned long);
typedef long (*mcctrl_pager_unmap_fn_t)(unsigned long, unsigned long);
typedef long (*mcctrl_pager_mlock_list_fn_t)(unsigned long, unsigned long,
		unsigned long, unsigned long, int);
typedef void (*mcctrl_pager_unknown_fn_t)(unsigned long, long);
typedef int (*mcctrl_remote_page_fault_send_fn_t)(unsigned long, int,
		struct mcctrl_ikc_scd_packet *);
typedef void (*mcctrl_remote_page_fault_log_fn_t)(int, int, int,
		unsigned long, unsigned long);
typedef void (*mcctrl_user_space_lock_fn_t)(void);
typedef void *(*mcctrl_user_space_find_vma_fn_t)(unsigned long);
typedef unsigned long (*mcctrl_user_space_vma_ulong_fn_t)(void *);
typedef void (*mcctrl_user_space_vma_void_fn_t)(void *);
typedef int (*mcctrl_user_space_vma_zap_fn_t)(void *, unsigned long,
		unsigned long);
typedef void (*mcctrl_user_space_vma_zap_range_fn_t)(void *,
		unsigned long, unsigned long);
typedef int (*mcctrl_user_space_munmap_fn_t)(unsigned long, unsigned long);
typedef void (*mcctrl_user_space_error_log_fn_t)(int);

struct mcctrl_in_kernel_syscall_ops {
	mcctrl_in_kernel_req_fn_t pager_irq;
	mcctrl_in_kernel_req_fn_t pager;
	mcctrl_in_kernel_clear_pte_fn_t clear_pte;
	mcctrl_in_kernel_remap_fn_t remap;
	mcctrl_in_kernel_zero_pages_fn_t zero_pages;
	mcctrl_in_kernel_writecore_fn_t writecore;
	mcctrl_in_kernel_sched_fn_t sched_same_owner;
	mcctrl_in_kernel_sched_fn_t sched_root;
	mcctrl_in_kernel_req_fn_t tofu_close;
	mcctrl_in_kernel_return_fn_t return_syscall;
	mcctrl_in_kernel_release_fn_t release_packet;
};

struct mcctrl_pager_call_ops {
	mcctrl_pager_create_fn_t create;
	mcctrl_pager_release_fn_t release;
	mcctrl_pager_io_fn_t read;
	mcctrl_pager_io_fn_t write;
	mcctrl_pager_map_fn_t map;
	mcctrl_pager_pfn_fn_t pfn;
	mcctrl_pager_unmap_fn_t unmap;
	mcctrl_pager_mlock_list_fn_t mlock_list;
	mcctrl_pager_unknown_fn_t unknown;
};

struct mcctrl_clear_pte_range_ops {
	mcctrl_user_space_lock_fn_t read_lock;
	mcctrl_user_space_lock_fn_t read_unlock;
	mcctrl_user_space_find_vma_fn_t find_vma;
	mcctrl_user_space_vma_ulong_fn_t vma_start;
	mcctrl_user_space_vma_ulong_fn_t vma_end;
	mcctrl_user_space_vma_ulong_fn_t vma_flags;
	mcctrl_user_space_vma_void_fn_t set_rw_exec;
	mcctrl_user_space_vma_zap_fn_t zap_vma_ptes;
	mcctrl_user_space_vma_zap_range_fn_t zap_page_range;
};

struct mcctrl_user_space_release_ops {
	mcctrl_user_space_find_vma_fn_t find_vma;
	mcctrl_user_space_vma_ulong_fn_t vma_start;
	mcctrl_user_space_vma_ulong_fn_t vma_end;
	mcctrl_user_space_munmap_fn_t munmap;
	mcctrl_user_space_error_log_fn_t log_error;
};

struct mcctrl_control_dispatch_ops {
	mcctrl_control_dispatch_fn_t prepare_image;
	mcctrl_control_dispatch_fn_t transfer_image;
	mcctrl_control_dispatch_fn_t start_image;
	mcctrl_control_dispatch_fn_t wait_syscall;
	mcctrl_control_dispatch_fn_t ret_syscall;
	mcctrl_control_dispatch_fn_t load_syscall;
	mcctrl_control_dispatch_fn_t send_signal;
	mcctrl_control_dispatch_fn_t get_cpu;
	mcctrl_control_dispatch_fn_t create_ppd;
	mcctrl_control_dispatch_fn_t get_nodes;
	mcctrl_control_dispatch_fn_t get_cpuset;
	mcctrl_control_dispatch_fn_t strncpy_from_user;
	mcctrl_control_dispatch_fn_t open_exec;
	mcctrl_control_dispatch_fn_t close_exec;
	mcctrl_control_dispatch_fn_t prepare_dma;
	mcctrl_control_dispatch_fn_t free_dma;
	mcctrl_control_dispatch_fn_t get_cred;
	mcctrl_control_dispatch_fn_t get_credv;
	mcctrl_control_dispatch_fn_t sys_mount;
	mcctrl_control_dispatch_fn_t sys_umount;
	mcctrl_control_dispatch_fn_t sys_unshare;
	mcctrl_control_dispatch_fn_t uti_get_ctx;
	mcctrl_control_dispatch_fn_t uti_switch_ctx;
	mcctrl_control_dispatch_fn_t sig_thread;
	mcctrl_control_dispatch_fn_t syscall_thread;
	mcctrl_control_dispatch_fn_t terminate_thread;
	mcctrl_control_dispatch_fn_t release_user_space;
	mcctrl_control_dispatch_fn_t get_num_pool_threads;
	mcctrl_control_dispatch_fn_t uti_attr;
	mcctrl_control_dispatch_fn_t debug_log;
	mcctrl_control_dispatch_fn_t perf_num;
	mcctrl_control_dispatch_fn_t perf_set;
	mcctrl_control_dispatch_fn_t perf_get;
	mcctrl_control_dispatch_fn_t perf_enable;
	mcctrl_control_dispatch_fn_t perf_disable;
	mcctrl_control_dispatch_fn_t perf_destroy;
	mcctrl_control_dispatch_fn_t getrusage;
};

typedef long (*mcctrl_driver_control_fn_t)(unsigned long, unsigned int,
		unsigned long, unsigned long);
typedef void *(*mcctrl_driver_os_get_fn_t)(int);
typedef void (*mcctrl_driver_os_set_fn_t)(int, void *);
typedef void (*mcctrl_driver_void_fn_t)(void);
typedef int (*mcctrl_driver_int_fn_t)(void);
typedef int (*mcctrl_driver_os_int_fn_t)(void *);
typedef void (*mcctrl_driver_os_void_fn_t)(void *);
typedef void (*mcctrl_driver_index_void_fn_t)(int);
typedef int (*mcctrl_driver_os_index_int_fn_t)(void *, int);
typedef void (*mcctrl_driver_os_index_void_fn_t)(void *, int);
typedef void (*mcctrl_driver_log_fn_t)(int, int);
typedef void *(*mcctrl_driver_lookup_fn_t)(void);
typedef void (*mcctrl_driver_publish_fn_t)(void *);
typedef int (*mcctrl_driver_warn_missing_fn_t)(void *);

struct mcctrl_driver_boot_ops {
	mcctrl_driver_os_get_fn_t find_os;
	mcctrl_driver_os_set_fn_t set_os;
	mcctrl_driver_os_int_fn_t prepare_channels;
	mcctrl_driver_index_void_fn_t copy_user_call_proto;
	mcctrl_driver_os_int_fn_t set_kernel_handlers;
	mcctrl_driver_os_index_int_fn_t register_user_handlers;
	mcctrl_driver_index_void_fn_t procfs_init;
	mcctrl_driver_os_void_fn_t clear_kernel_handlers;
	mcctrl_driver_os_void_fn_t destroy_channels;
	mcctrl_driver_log_fn_t log;
};

struct mcctrl_driver_shutdown_ops {
	mcctrl_driver_os_get_fn_t get_os;
	mcctrl_driver_os_set_fn_t set_os;
	mcctrl_driver_void_fn_t pager_cleanup;
	mcctrl_driver_os_void_fn_t sysfs_cleanup;
	mcctrl_driver_os_void_fn_t free_topology_info;
	mcctrl_driver_os_index_void_fn_t unregister_user_handlers;
	mcctrl_driver_os_void_fn_t clear_kernel_handlers;
	mcctrl_driver_os_void_fn_t destroy_channels;
	mcctrl_driver_index_void_fn_t procfs_exit;
	mcctrl_driver_log_fn_t log;
};

struct mcctrl_driver_symbols_ops {
	mcctrl_driver_lookup_fn_t lookup_mount;
	mcctrl_driver_publish_fn_t set_mount;
	mcctrl_driver_lookup_fn_t lookup_umount;
	mcctrl_driver_publish_fn_t set_umount;
	mcctrl_driver_lookup_fn_t lookup_unshare;
	mcctrl_driver_publish_fn_t set_unshare;
	mcctrl_driver_lookup_fn_t lookup_sched_setaffinity;
	mcctrl_driver_publish_fn_t set_sched_setaffinity;
	mcctrl_driver_lookup_fn_t lookup_sched_setscheduler_nocheck;
	mcctrl_driver_publish_fn_t set_sched_setscheduler_nocheck;
	mcctrl_driver_lookup_fn_t lookup_readlinkat;
	mcctrl_driver_publish_fn_t set_readlinkat;
	mcctrl_driver_lookup_fn_t lookup_zap_page_range;
	mcctrl_driver_publish_fn_t set_zap_page_range;
	mcctrl_driver_lookup_fn_t lookup_hugetlbfs_inode_operations;
	mcctrl_driver_publish_fn_t set_hugetlbfs_inode_operations;
	mcctrl_driver_warn_missing_fn_t warn_missing;
	mcctrl_driver_int_fn_t arch_symbols_init;
};

struct mcctrl_driver_module_ops {
	mcctrl_driver_void_fn_t syscall_init;
	mcctrl_driver_os_set_fn_t set_os;
	mcctrl_driver_void_fn_t binfmt_init;
	mcctrl_driver_void_fn_t tofu_hash_init;
	mcctrl_driver_int_fn_t symbols_init;
	mcctrl_driver_void_fn_t tofu_hijack;
	mcctrl_driver_int_fn_t register_notifier;
	mcctrl_driver_void_fn_t binfmt_exit;
	mcctrl_driver_int_fn_t deregister_notifier;
	mcctrl_driver_void_fn_t uti_finalize;
	mcctrl_driver_void_fn_t tofu_restore;
	mcctrl_driver_log_fn_t log;
};

extern int mcctrl_procfs_packet_handler_body_result(void *, int, int,
		unsigned long, unsigned long, unsigned long,
		mcctrl_procfs_work_alloc_fn_t,
		mcctrl_procfs_work_init_schedule_fn_t,
		mcctrl_procfs_alloc_failed_fn_t);
extern long mcctrl_control_dispatch_body_result(
		unsigned long, unsigned int, unsigned long, unsigned long,
		const struct mcctrl_control_dispatch_ops *);
extern long mcctrl_control_debug_log_body_result(unsigned long,
		unsigned long, mcctrl_control_ikc_send_fn_t);
extern long mcctrl_control_get_cpu_body_result(unsigned long,
		mcctrl_control_get_ptr_fn_t, mcctrl_control_ptr_int_fn_t,
		mcctrl_control_log_fn_t);
extern long mcctrl_control_get_nodes_body_result(unsigned long,
		mcctrl_control_get_ptr_fn_t, mcctrl_control_ptr_field_fn_t,
		mcctrl_control_ptr_int_fn_t, mcctrl_control_log_fn_t);
extern int mcctrl_control_cpu_register_body_result(unsigned long, int,
		struct ihk_os_cpu_register *, int, mcctrl_control_get_ptr_fn_t,
		mcctrl_control_ptr_int_fn_t, mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t, mcctrl_control_virt_to_phys_fn_t,
		mcctrl_control_cpu_register_send_wait_fn_t,
		mcctrl_control_cpu_register_error_log_fn_t,
		mcctrl_control_cpu_register_done_log_fn_t);
extern int mcctrl_control_get_request_os_cpu_body_result(
		unsigned long, int *, mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_current_int_fn_t,
		mcctrl_control_current_int_fn_t,
		mcctrl_control_current_task_fn_t,
		mcctrl_control_get_ppd_fn_t, mcctrl_control_put_fn_t,
		mcctrl_control_get_ptd_fn_t, mcctrl_control_put_fn_t,
		mcctrl_control_ptr_field_fn_t,
		mcctrl_control_packet_ref_fn_t,
		mcctrl_control_channel_read_cpu_fn_t,
		mcctrl_control_request_cpu_error_log_fn_t,
		mcctrl_control_request_cpu_ptd_log_fn_t,
		mcctrl_control_request_cpu_result_log_fn_t);
extern long mcctrl_control_pin_region_body_result(
		const void *, int, int, mcctrl_control_copy_user_fn_t,
		mcctrl_control_get_order_fn_t,
		mcctrl_control_alloc_pages_fn_t,
		mcctrl_control_virt_to_phys_fn_t,
		mcctrl_control_copy_user_fn_t);
extern long mcctrl_control_free_region_body_result(
		const void *, int, int, mcctrl_control_copy_user_fn_t,
		mcctrl_control_get_order_fn_t,
		mcctrl_control_phys_to_virt_fn_t,
		mcctrl_control_free_pages_fn_t);
extern long mcctrl_control_sys_mount_body_result(
		const void *, mcctrl_control_copy_user_fn_t,
		mcctrl_control_prepare_creds_fn_t,
		mcctrl_control_cap_raise_admin_fn_t,
		mcctrl_control_override_creds_fn_t,
		mcctrl_control_mount_fn_t,
		mcctrl_control_revert_creds_fn_t, mcctrl_control_put_fn_t);
extern long mcctrl_control_sys_umount_body_result(
		const void *, int, mcctrl_control_copy_user_fn_t,
		mcctrl_control_prepare_creds_fn_t,
		mcctrl_control_cap_raise_admin_fn_t,
		mcctrl_control_override_creds_fn_t,
		mcctrl_control_umount_fn_t,
		mcctrl_control_revert_creds_fn_t, mcctrl_control_put_fn_t);
extern long mcctrl_control_sys_unshare_body_result(
		const void *, mcctrl_control_copy_user_fn_t,
		mcctrl_control_prepare_creds_fn_t,
		mcctrl_control_cap_raise_admin_fn_t,
		mcctrl_control_override_creds_fn_t,
		mcctrl_control_unshare_fn_t,
		mcctrl_control_revert_creds_fn_t, mcctrl_control_put_fn_t);
extern long mcctrl_control_release_user_space_body_result(
		const void *, mcctrl_control_copy_user_fn_t,
		mcctrl_control_clear_pte_range_fn_t);
extern long mcctrl_control_perf_num_body_result(
		unsigned long, unsigned long, mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_perf_set_num_fn_t,
		mcctrl_control_log_fn_t);
extern long mcctrl_control_perf_destroy_body_result(
		unsigned long, mcctrl_control_long_fn_t,
		mcctrl_control_long_fn_t);
extern long mcctrl_control_perf_set_body_result(
		unsigned long, const void *, unsigned int, unsigned long,
		mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_perf_event_num_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_ptr_int_fn_t,
		mcctrl_control_free_fn_t,
		mcctrl_control_perf_alloc_set_desc_fn_t,
		mcctrl_control_perf_send_wait_fn_t,
		mcctrl_control_perf_desc_err_fn_t,
		mcctrl_control_perf_set_num_fn_t,
		mcctrl_control_log_fn_t);
extern long mcctrl_control_perf_get_body_result(
		unsigned long, void *, unsigned int, unsigned long,
		unsigned long, mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_perf_event_num_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_ptr_int_fn_t,
		mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t,
		mcctrl_control_perf_init_desc_fn_t,
		mcctrl_control_perf_send_wait_fn_t,
		mcctrl_control_perf_desc_err_fn_t,
		mcctrl_control_perf_desc_read_value_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_log_fn_t);
extern long mcctrl_control_perf_enable_disable_body_result(
		unsigned long, int, unsigned int, unsigned long,
		mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_perf_event_num_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_ptr_int_fn_t,
		mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t,
		mcctrl_control_perf_init_mask_desc_fn_t,
		mcctrl_control_perf_send_wait_fn_t,
		mcctrl_control_perf_desc_err_fn_t,
		mcctrl_control_log_fn_t);
extern long mcctrl_control_getrusage_body_result(
		unsigned long, const void *, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long,
		mcctrl_control_validate_os_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t,
		mcctrl_control_getrusage_log_fn_t);
extern long mcctrl_control_transfer_image_body_result(
		unsigned long, const void *, unsigned long, int, int,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_os_to_dev_fn_t,
		mcctrl_control_map_memory_fn_t,
		mcctrl_control_map_virtual_fn_t,
		mcctrl_control_unmap_virtual_fn_t,
		mcctrl_control_unmap_memory_fn_t,
		mcctrl_control_transfer_log_fn_t);
extern long mcctrl_control_load_syscall_body_result(
		unsigned long, const void *, unsigned long,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_os_to_dev_fn_t,
		mcctrl_control_map_memory_fn_t,
		mcctrl_control_map_virtual_fn_t,
		mcctrl_control_unmap_virtual_fn_t,
		mcctrl_control_unmap_memory_fn_t,
		mcctrl_control_load_log_fn_t);
extern long mcctrl_control_ret_syscall_body_result(
		unsigned long, const void *, unsigned long,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_current_int_fn_t,
		mcctrl_control_current_int_fn_t,
		mcctrl_control_current_task_fn_t,
		mcctrl_control_get_ppd_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_get_ptd_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_ptr_field_fn_t,
		mcctrl_control_os_to_dev_fn_t,
		mcctrl_control_map_memory_fn_t,
		mcctrl_control_map_virtual_fn_t,
		mcctrl_control_unmap_virtual_fn_t,
		mcctrl_control_unmap_memory_fn_t,
		mcctrl_control_return_syscall_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_ret_syscall_log_fn_t);
extern long mcctrl_control_terminate_thread_unsafe_body_result(
		unsigned long, int, int, long, void *,
		mcctrl_control_get_ptr_fn_t,
		mcctrl_control_info_ulong_fn_t,
		mcctrl_control_get_ppd_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_get_ptd_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_ptr_int_fn_t,
		mcctrl_control_ptr_field_fn_t,
		mcctrl_control_ptr_int_fn_t,
		mcctrl_control_return_syscall_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_terminate_thread_log_fn_t);
extern long mcctrl_control_uti_get_ctx_body_result(
		unsigned long, void *, unsigned long, unsigned long,
		unsigned long, mcctrl_control_copy_user_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_os_to_dev_fn_t,
		mcctrl_control_map_memory_fn_t,
		mcctrl_control_map_virtual_fn_t,
		mcctrl_control_unmap_virtual_fn_t,
		mcctrl_control_unmap_memory_fn_t,
		mcctrl_control_current_ulong_fn_t,
		mcctrl_control_uti_log_fn_t);
extern int mcctrl_control_getcred_body_result(
		unsigned long, mcctrl_control_phys_to_virt_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t);
extern int mcctrl_control_getcredv_body_result(
		int *, mcctrl_control_copy_user_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t,
		mcctrl_control_cred_value_fn_t);
struct mcctrl_control_strncpy_desc {
	void *dest;
	void *src;
	unsigned long n;
	long result;
};
extern long mcctrl_control_strncpy_from_user_body_result(
		struct mcctrl_control_strncpy_desc *, unsigned long,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_copy_user_fn_t,
		mcctrl_control_alloc_page_fn_t,
		mcctrl_control_free_page_fn_t,
		mcctrl_control_strncpy_from_user_fn_t);
extern int mcctrl_control_destroy_ppd_body_result(
		unsigned long, int, mcctrl_control_get_ptr_fn_t,
		mcctrl_control_get_ppd_fn_t, mcctrl_control_put_fn_t,
		mcctrl_control_destroy_ppd_log_fn_t);
extern int mcctrl_control_close_exec_body_result(
		unsigned long, int, mcctrl_control_validate_os_fn_t,
		mcctrl_control_drop_exec_fn_t);
extern long mcctrl_control_newprocess_body_result(
		unsigned long, void *, mcctrl_control_current_int_fn_t,
		mcctrl_control_new_info_fn_t,
		mcctrl_control_set_info_pid_fn_t,
		mcctrl_control_register_release_fn_t,
		mcctrl_control_set_private_fn_t);
extern long mcctrl_control_start_image_body_result(
		unsigned long, const void *, void *, unsigned long,
		mcctrl_control_copy_user_fn_t, mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t, mcctrl_control_get_ptr_fn_t,
		mcctrl_control_file_ptr_fn_t,
		mcctrl_control_new_info_fn_t,
		mcctrl_control_desc_int_fn_t,
		mcctrl_control_desc_int_fn_t,
		mcctrl_control_desc_ulong_fn_t,
		mcctrl_control_desc_ulong_fn_t,
		mcctrl_control_desc_ulong_fn_t,
		mcctrl_control_info_ulong_fn_t,
		mcctrl_control_set_start_info_fn_t,
		mcctrl_control_register_release_fn_t,
		mcctrl_control_set_private_fn_t,
		mcctrl_control_os_cpu_void_fn_t,
		mcctrl_control_ptr_ulong_fn_t,
		mcctrl_control_schedule_send_fn_t,
		mcctrl_control_put_fn_t,
		mcctrl_control_start_log_fn_t);
extern long mcctrl_control_send_signal_body_result(
		unsigned long, const void *, unsigned long, unsigned long,
		mcctrl_control_copy_user_fn_t, mcctrl_control_alloc_fn_t,
		mcctrl_control_free_fn_t, mcctrl_control_get_ptr_fn_t,
		mcctrl_control_virt_to_phys_fn_t,
		mcctrl_control_cpu_register_send_wait_fn_t,
		mcctrl_control_signal_log_fn_t);
extern long mcctrl_driver_ioctl_body_result(unsigned long, unsigned int,
		unsigned long, unsigned long, mcctrl_driver_control_fn_t);
extern unsigned long mcctrl_driver_osnum_to_os_body_result(
		int, mcctrl_driver_os_get_fn_t);
extern int mcctrl_driver_os_alive_body_result(
		int, mcctrl_driver_os_get_fn_t);
extern int mcctrl_driver_boot_notifier_body_result(
		int, const struct mcctrl_driver_boot_ops *);
extern int mcctrl_driver_shutdown_notifier_body_result(
		int, const struct mcctrl_driver_shutdown_ops *);
extern int mcctrl_driver_symbols_init_body_result(
		const struct mcctrl_driver_symbols_ops *);
extern int mcctrl_driver_init_body_result(
		int, const struct mcctrl_driver_module_ops *);
extern void mcctrl_driver_exit_body_result(
		const struct mcctrl_driver_module_ops *);
extern int mcctrl_in_kernel_irq_syscall_body_result(
		unsigned long, struct mcctrl_ikc_scd_packet *,
		const struct mcctrl_in_kernel_syscall_ops *, long *);
extern int mcctrl_in_kernel_syscall_body_result(
		unsigned long, struct mcctrl_ikc_scd_packet *,
		const struct mcctrl_in_kernel_syscall_ops *, long *);
extern long mcctrl_pager_call_irq_body_result(
		unsigned long, struct mcctrl_syscall_request *,
		const struct mcctrl_pager_call_ops *);
extern long mcctrl_pager_call_body_result(
		unsigned long, struct mcctrl_syscall_request *,
		const struct mcctrl_pager_call_ops *);
extern int mcctrl_remote_page_fault_body_result(
		unsigned long, void *, unsigned long,
		struct mcctrl_ikc_scd_packet *,
		mcctrl_remote_page_fault_send_fn_t,
		mcctrl_remote_page_fault_log_fn_t);
extern int mcctrl_clear_pte_range_body_result(
		unsigned long, unsigned long, unsigned long, int,
		const struct mcctrl_clear_pte_range_ops *);
extern int mcctrl_user_space_release_body_result(
		unsigned long, unsigned long,
		const struct mcctrl_user_space_release_ops *);
extern int mcctrl_procfs_work_main_body_result(
		struct mcctrl_procfs_work_prefix *, unsigned long,
		mcctrl_procfs_get_index_fn_t, mcctrl_procfs_entry_fn_t,
		mcctrl_procfs_entry_fn_t, mcctrl_procfs_os_to_dev_fn_t,
		mcctrl_procfs_map_memory_fn_t, mcctrl_procfs_map_virtual_fn_t,
		mcctrl_procfs_unmap_virtual_fn_t,
		mcctrl_procfs_unmap_memory_fn_t, mcctrl_procfs_unknown_work_fn_t,
		mcctrl_procfs_free_work_fn_t);
extern char *mcctrl_procfs_getpath_body_result(
		void *, char *, unsigned long, mcctrl_procfs_entry_name_fn_t,
		mcctrl_procfs_entry_parent_fn_t);
extern long mcctrl_procfs_add_entries_body_result(
		void *, const void *, unsigned long, const void *,
		const void *, mcctrl_procfs_entry_name_fn_t,
		mcctrl_procfs_entry_mode_fn_t,
		mcctrl_procfs_entry_fops_fn_t,
		mcctrl_procfs_entry_next_fn_t,
		mcctrl_procfs_add_entry_with_ids_fn_t);
extern void *mcctrl_procfs_find_entry_body_result(
		void *, const char *, mcctrl_procfs_first_entry_fn_t,
		mcctrl_procfs_next_entry_fn_t,
		mcctrl_procfs_entry_name_fn_t);
extern void *mcctrl_procfs_add_entry_body_result(
		void *, const char *, unsigned int, const void *, const void *,
		const void *, unsigned long, mcctrl_procfs_find_entry_fn_t,
		mcctrl_procfs_delete_entry_fn_t,
		mcctrl_procfs_alloc_entry_fn_t,
		mcctrl_procfs_init_entry_fn_t,
		mcctrl_procfs_create_pde_fn_t,
		mcctrl_procfs_commit_entry_fn_t,
		mcctrl_procfs_entry_void_fn_t, mcctrl_procfs_void_fn_t,
		mcctrl_procfs_entry_log_fn_t);
extern int mcctrl_procfs_delete_entries_body_result(
		void *, mcctrl_procfs_first_entry_fn_t,
		mcctrl_procfs_delete_entry_fn_t,
		mcctrl_procfs_entry_void_fn_t,
		mcctrl_procfs_entry_void_fn_t,
		mcctrl_procfs_entry_data_fn_t,
		mcctrl_procfs_entry_void_fn_t);
extern void *mcctrl_procfs_get_pid_cred_body_result(
		int, int, mcctrl_procfs_void_fn_t, mcctrl_procfs_void_fn_t,
		mcctrl_procfs_find_vpid_fn_t, mcctrl_procfs_pid_task_fn_t,
		mcctrl_procfs_task_cred_fn_t);
extern void *mcctrl_procfs_find_base_entry_body_result(
		int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t);
extern void *mcctrl_procfs_find_pid_entry_body_result(
		int, int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t);
extern void *mcctrl_procfs_find_tid_entry_body_result(
		int, int, int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t);
extern void *mcctrl_procfs_get_base_entry_body_result(
		int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t,
		mcctrl_procfs_add_entry_fn_t,
		mcctrl_procfs_set_osnum_fn_t);
extern void *mcctrl_procfs_get_pid_entry_body_result(
		int, int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t,
		mcctrl_procfs_add_entry_fn_t);
extern void *mcctrl_procfs_get_tid_entry_body_result(
		int, int, int, mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_format_name_fn_t,
		mcctrl_procfs_find_entry_fn_t,
		mcctrl_procfs_add_entry_fn_t);
extern int mcctrl_procfs_add_tid_entry_body_result(
		int, int, int, void *(*)(int), void (*)(void),
		void (*)(void), void *(*)(int, int), void *(*)(int, int),
		void (*)(void *, void *), void (*)(int, int, int, void *));
extern int mcctrl_procfs_add_tid_with_cred_body_result(
		int, int, int, void *, void *(*)(int, int, int),
		void (*)(void *, void *), void *(*)(void *),
		void (*)(void *, void *, void *));
extern int mcctrl_procfs_add_pid_entry_body_result(
		int, int, void *(*)(int), void (*)(void), void (*)(void),
		void *(*)(int, int), void (*)(void *, void *),
		void (*)(int, int, int, void *));
extern int mcctrl_procfs_delete_tid_entry_body_result(
		int, int, int, void (*)(void), void (*)(void),
		void *(*)(int, int, int), void (*)(void *));
extern int mcctrl_procfs_delete_pid_entry_body_result(
		int, int, void (*)(void), void (*)(void),
		void *(*)(int, int), void (*)(void *));
extern int mcctrl_procfs_init_body_result(
		int, void (*)(void), void (*)(void), void *(*)(int),
		void (*)(void *));
extern int mcctrl_procfs_exit_body_result(
		int, void (*)(void), void (*)(void), void *(*)(int),
		void (*)(void *));
extern int mcctrl_procfs_exe_link_body_result(
		int, int, const char *, void (*)(void), void (*)(void),
		void *(*)(int, int), void *(*)(void *, const char *),
		void (*)(void *, const char *), void (*)(void *, const char *));
extern long mcctrl_procfs_lseek_body_result(long, long, int, long *);
extern int mcctrl_syscall_ptd_hash_result(void *, int);
extern int mcctrl_syscall_put_ptd_unsafe_body_result(
		void *, const struct mcctrl_syscall_ptd_offsets *,
		mcctrl_syscall_ptd_free_fn_t,
		mcctrl_syscall_ptd_log_fn_t);
extern int mcctrl_syscall_put_ptd_body_result(
		void *, int, const struct mcctrl_syscall_ptd_offsets *,
		mcctrl_syscall_ptd_free_fn_t,
		mcctrl_syscall_ptd_lock_fn_t,
		mcctrl_syscall_ptd_unlock_fn_t,
		mcctrl_syscall_ptd_log_fn_t);
extern int mcctrl_syscall_add_ptd_body_result(
		void *, void *, void *, int, unsigned long, int,
		const struct mcctrl_syscall_ptd_offsets *,
		mcctrl_syscall_ptd_alloc_fn_t,
		mcctrl_syscall_ptd_free_fn_t,
		mcctrl_syscall_ptd_lock_fn_t,
		mcctrl_syscall_ptd_unlock_fn_t,
		mcctrl_syscall_ptd_log_fn_t);
extern void *mcctrl_syscall_get_ptd_body_result(
		void *, void *, int, const struct mcctrl_syscall_ptd_offsets *,
		mcctrl_syscall_ptd_lock_fn_t,
		mcctrl_syscall_ptd_unlock_fn_t,
		mcctrl_syscall_ptd_log_fn_t);
extern int mcctrl_syscall_pidfd_hash_init_body_result(
		void *, unsigned long, unsigned long, void *,
		mcctrl_syscall_pidfd_lock_init_fn_t);
extern int mcctrl_syscall_pidfd_hash_insert_body_result(
		void *, void *, void *, unsigned long, int, void *, int,
		const char *, void *, unsigned long, unsigned long,
		const struct mcctrl_syscall_pidfd_offsets *,
		mcctrl_syscall_pidfd_alloc_fn_t,
		mcctrl_syscall_pidfd_free_fn_t,
		mcctrl_syscall_pidfd_lock_fn_t,
		mcctrl_syscall_pidfd_unlock_fn_t,
		mcctrl_syscall_pidfd_log_fn_t);
extern void *mcctrl_syscall_pidfd_hash_lookup_body_result(
		void *, void *, void *, void *, unsigned long,
		const struct mcctrl_syscall_pidfd_offsets *,
		mcctrl_syscall_pidfd_lock_fn_t,
		mcctrl_syscall_pidfd_unlock_fn_t,
		mcctrl_syscall_pidfd_log_fn_t);
extern int mcctrl_syscall_pidfd_hash_remove_body_result(
		void *, void *, void *, unsigned long, void *, int,
		unsigned long, const struct mcctrl_syscall_pidfd_offsets *,
		mcctrl_syscall_pidfd_free_fn_t,
		mcctrl_syscall_pidfd_lock_fn_t,
		mcctrl_syscall_pidfd_unlock_fn_t,
		mcctrl_syscall_pidfd_log_fn_t);
extern int mcctrl_syscall_pager_add_process_body_result(
		int *, void *, mcctrl_syscall_pager_lock_fn_t,
		mcctrl_syscall_pager_unlock_fn_t);
extern int mcctrl_syscall_pager_remove_process_body_result(
		void *, int *, void *,
		const struct mcctrl_syscall_pager_offsets *,
		mcctrl_syscall_pager_predicate_fn_t,
		mcctrl_syscall_pager_predicate_fn_t,
		mcctrl_syscall_pager_sem_down_fn_t,
		mcctrl_syscall_pager_sem_up_fn_t,
		mcctrl_syscall_pager_ptr_fn_t,
		mcctrl_syscall_pager_lock_fn_t,
		mcctrl_syscall_pager_unlock_fn_t,
		mcctrl_syscall_pager_log_fn_t);
extern int mcctrl_syscall_pager_cleanup_body_result(
		void *, void *, const struct mcctrl_syscall_pager_offsets *,
		mcctrl_syscall_pager_ptr_fn_t,
		mcctrl_syscall_pager_ptr_fn_t,
		mcctrl_syscall_pager_lock_fn_t,
		mcctrl_syscall_pager_unlock_fn_t,
		mcctrl_syscall_pager_log_fn_t);
extern void *mcctrl_rva_to_rpa_cache_search_body_result(void *,
		unsigned long);
extern int mcctrl_rva_to_rpa_cache_insert_body_result(
		void *, void *, void (*)(void *, void *, void *),
		void (*)(void *, void *));
extern int mcctrl_futex_remove_process_body_result(
		void *, void *(*)(void *), void (*)(void *, void *),
		void (*)(void *));
extern int mcctrl_futex_dispatch_body_result(
		uint32_t *, int, uint32_t, uint64_t, uint32_t *, uint32_t,
		uint32_t, int, void *, mcctrl_futex_wait_fn_t,
		mcctrl_futex_wake_fn_t, mcctrl_futex_requeue_fn_t,
		mcctrl_futex_wake_op_fn_t, mcctrl_futex_warn_fn_t);
extern int mcctrl_futex_wait_body_result(
		uint32_t *, int, uint32_t, uint64_t, uint32_t, void *,
		mcctrl_futex_info_ptr_fn_t, mcctrl_futex_info_ptr_fn_t,
		mcctrl_futex_current_cpu_fn_t,
		mcctrl_futex_prepare_wait_q_fn_t,
		mcctrl_futex_wait_setup_fn_t,
		mcctrl_futex_wait_queue_fn_t, mcctrl_futex_unqueue_fn_t,
		mcctrl_futex_put_q_key_fn_t, mcctrl_futex_wait_log_fn_t);
extern int mcctrl_futex_wake_body_result(
		unsigned long, int, int, uint32_t, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, mcctrl_futex_get_key_body_fn_t,
		mcctrl_futex_hash_key_fn_t, mcctrl_futex_wake_lock_fn_t,
		mcctrl_futex_wake_unlock_fn_t, mcctrl_futex_put_key_fn_t,
		mcctrl_futex_wake_entry_fn_t);
extern int mcctrl_futex_wake_op_body_result(
		unsigned long, int, unsigned long, int, int, int,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		mcctrl_futex_get_key_body_fn_t,
		mcctrl_futex_hash_key_fn_t, mcctrl_futex_hb_lock_fn_t,
		mcctrl_futex_hb_unlock_fn_t, mcctrl_futex_atomic_op_fn_t,
		mcctrl_futex_put_key_fn_t, mcctrl_futex_wake_entry_fn_t);
extern int mcctrl_futex_requeue_body_result(
		unsigned long, int, unsigned long, int, int, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, unsigned long, unsigned long,
		unsigned long, unsigned long, mcctrl_futex_get_key_body_fn_t,
		mcctrl_futex_hash_key_fn_t, mcctrl_futex_hb_lock_fn_t,
		mcctrl_futex_hb_unlock_fn_t, mcctrl_futex_get_value_fn_t,
		mcctrl_futex_put_key_fn_t, mcctrl_futex_drop_key_refs_fn_t,
		mcctrl_futex_requeue_entry_fn_t,
		mcctrl_futex_requeue_entry_fn_t);
extern int mcctrl_procfs_buff_open_body_result(
		void *, void *, unsigned long, unsigned long, unsigned long,
		int (*)(void *), void *(*)(int), void *(*)(unsigned long),
		void (*)(void *), const char *(*)(void *, char *, unsigned long),
		void (*)(void *, void *, int, unsigned long, const char *),
		void (*)(void *, void *));
extern long mcctrl_procfs_read_write_body_result(
		void *, void *, unsigned long, long *, int, char *,
		unsigned long, unsigned long, int (*)(void *),
		const char *(*)(void *, char *, unsigned long),
		void *(*)(int), void *(*)(void *), void *(*)(void *, int),
		void (*)(void *), int (*)(void *), int (*)(unsigned long),
		void *(*)(int), void (*)(void *, int),
		unsigned long (*)(void *), void *(*)(void),
		void (*)(void *, unsigned long, long, int, int, const char *),
		int (*)(void *, int, int, void *, int *), int (*)(void *),
		int (*)(void *), void (*)(void *),
		int (*)(void *, void *, unsigned long), void (*)(void),
		void (*)(int, int), void (*)(int), void (*)(int),
		void (*)(int), void (*)(void), void (*)(void), void (*)(void));
extern int mcctrl_procfs_buff_release_body_result(
		void *, unsigned long, void *(*)(void *),
		void (*)(void *, void *), unsigned long (*)(void *),
		void *(*)(void *), void *(*)(void),
		void (*)(void *, unsigned long),
		int (*)(void *, void *, int *), int (*)(void *),
		void (*)(void *), void (*)(void));
extern long mcctrl_procfs_buff_read_body_result(
		void *, void *, unsigned long, long *, unsigned long,
		unsigned long, void *(*)(void *), void *(*)(void *),
		int (*)(void *), unsigned long (*)(void *),
		unsigned long (*)(void *), const char *(*)(void *),
		void (*)(void *, unsigned long, unsigned long),
		void (*)(void *, unsigned long), void *(*)(void *),
		void *(*)(void *, int), void (*)(void *), int (*)(void *),
		void *(*)(void),
		void (*)(void *, unsigned long, const char *),
		int (*)(void *, int, int, void *, int *), int (*)(void *),
		unsigned long (*)(void *), void (*)(void *),
		void *(*)(void *),
		unsigned long (*)(void *, unsigned long, unsigned long),
		void *(*)(void *, unsigned long, unsigned long, void *, int),
		void (*)(void *, void *, unsigned long),
		void (*)(void *, unsigned long, unsigned long),
		unsigned long (*)(void *), unsigned long (*)(void *),
		unsigned long (*)(void *),
		int (*)(void *, void *, unsigned long, unsigned long),
		void (*)(void), void (*)(int), void (*)(void));
extern int mcctrl_sysfs_packet_handler_body_result(void *, int, int,
		long, long, unsigned long, mcctrl_sysfs_work_alloc_fn_t,
		mcctrl_sysfs_work_init_schedule_fn_t,
		mcctrl_sysfs_alloc_failed_fn_t);
extern int mcctrl_sysfs_work_main_body_result(
		struct mcctrl_sysfs_work_prefix *,
		mcctrl_sysfs_request_fn_t, mcctrl_sysfs_request_fn_t,
		mcctrl_sysfs_request_fn_t, mcctrl_sysfs_request_fn_t,
		mcctrl_sysfs_request_fn_t, mcctrl_sysfs_request_fn_t,
		mcctrl_sysfs_response_fn_t, mcctrl_sysfs_response_fn_t,
		mcctrl_sysfs_release_response_fn_t,
		mcctrl_sysfs_unknown_work_fn_t, mcctrl_sysfs_free_work_fn_t);
extern int mcctrl_sysfs_resp_body_result(
		void *, long, void *(*)(void *), void (*)(void *, long));
extern long mcctrl_sysfs_remote_show_body_result(
		void *, void *, unsigned long, void *, void *, void *,
		void *, long, long, int *, mcctrl_sysfs_sem_down_fn_t,
		mcctrl_sysfs_sem_up_fn_t, mcctrl_sysfs_wait_ready_fn_t,
		mcctrl_sysfs_set_busy_fn_t, mcctrl_sysfs_send_fn_t,
		mcctrl_sysfs_req_result_fn_t, mcctrl_sysfs_local_copy_fn_t);
extern long mcctrl_sysfs_remote_store_body_result(
		void *, const void *, unsigned long, void *, unsigned long,
		void *, void *, void *, long, long, int *,
		mcctrl_sysfs_sem_down_fn_t, mcctrl_sysfs_sem_up_fn_t,
		mcctrl_sysfs_wait_ready_fn_t, mcctrl_sysfs_set_busy_fn_t,
		mcctrl_sysfs_send_fn_t, mcctrl_sysfs_req_result_fn_t,
		mcctrl_sysfs_local_copy_fn_t);
extern int mcctrl_sysfs_remote_release_body_result(
		void *, int, void *, void *, void *, void *, long, long, int,
		int *, mcctrl_sysfs_sem_down_fn_t, mcctrl_sysfs_sem_up_fn_t,
		mcctrl_sysfs_wait_ready_fn_t, mcctrl_sysfs_set_busy_fn_t,
		mcctrl_sysfs_send_fn_t);
extern void *mcctrl_sysfs_lookup_i_body_result(
		void *, const char *, int, mcctrl_sysfs_node_type_fn_t,
		mcctrl_sysfs_node_name_fn_t, mcctrl_sysfs_node_ptr_fn_t,
		mcctrl_sysfs_node_next_fn_t, mcctrl_sysfs_err_ptr_fn_t);
extern int mcctrl_sysfs_setup_special_local_create_body_result(
		struct mcctrl_sysfs_req_create_param *, void * const *,
		unsigned long, mcctrl_sysfs_local_alloc_fn_t,
		mcctrl_sysfs_local_copy_fn_t,
		mcctrl_sysfs_unknown_ops_fn_t);
extern long mcctrl_sysfs_local_show_body_result(
		void *, void *, unsigned long, unsigned long,
		mcctrl_sysfs_node_long_fn_t, mcctrl_sysfs_node_long_fn_t);
extern long mcctrl_sysfs_local_store_body_result(
		void *, const void *, unsigned long,
		mcctrl_sysfs_node_long_fn_t, mcctrl_sysfs_node_long_fn_t);
extern int mcctrl_sysfs_local_release_body_result(
		void *, int, mcctrl_sysfs_node_type_fn_t,
		mcctrl_sysfs_node_long_fn_t, mcctrl_sysfs_node_long_fn_t);
extern long mcctrl_sysfs_show_body_result(
		void *, void *, unsigned long, mcctrl_sysfs_node_long_fn_t);
extern long mcctrl_sysfs_store_body_result(
		void *, const void *, unsigned long,
		mcctrl_sysfs_node_long_fn_t);
extern int mcctrl_sysfs_release_body_result(
		void *, mcctrl_sysfs_node_long_fn_t);
extern long mcctrl_sysfs_snooping_show_i32_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_i64_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_u32_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_u64_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_string_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_u32k_body_result(
		void *, void *, unsigned long);
extern long mcctrl_sysfs_snooping_show_bitmap_body_result(
		void *, void *, unsigned long, mcctrl_sysfs_bitmap_format_fn_t);
extern int mcctrl_sysfs_cleanup_special_local_create_body_result(
		void *, mcctrl_sysfs_free_fn_t);
extern int mcctrl_sysfs_createf_post_path_body_result(
		void *, struct mcctrl_sysfs_req_create_param *, void * const *,
		unsigned long, mcctrl_sysfs_local_alloc_fn_t,
		mcctrl_sysfs_local_copy_fn_t,
		mcctrl_sysfs_unknown_ops_fn_t,
		mcctrl_sysfs_local_create_fn_t,
		mcctrl_sysfs_cleanup_special_fn_t,
		mcctrl_sysfs_error_fn_t);
extern int mcctrl_sysfs_mkdirf_post_path_body_result(
		void *, struct mcctrl_sysfs_req_mkdir_param *,
		mcctrl_sysfs_local_mkdir_fn_t);
extern int mcctrl_sysfs_symlinkf_post_path_body_result(
		void *, struct mcctrl_sysfs_req_symlink_param *,
		mcctrl_sysfs_local_symlink_fn_t);
extern int mcctrl_sysfs_lookupf_post_path_body_result(
		void *, struct mcctrl_sysfs_req_lookup_param *,
		mcctrl_sysfs_local_lookup_fn_t);
extern int mcctrl_sysfs_unlinkf_post_path_body_result(
		void *, struct mcctrl_sysfs_req_unlink_param *,
		mcctrl_sysfs_local_unlink_fn_t);
extern int mcctrl_sysfs_req_setup_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_setup_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);
extern int mcctrl_sysfs_req_create_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_create_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);
extern int mcctrl_sysfs_req_mkdir_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_mkdir_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);
extern int mcctrl_sysfs_req_symlink_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_symlink_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);
extern int mcctrl_sysfs_req_lookup_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_lookup_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);
extern int mcctrl_sysfs_req_unlink_body_result(
		void *, unsigned long, unsigned long,
		mcctrl_sysfs_os_to_dev_fn_t,
		mcctrl_sysfs_map_memory_fn_t,
		mcctrl_sysfs_map_virtual_simple_fn_t,
		mcctrl_sysfs_unmap_virtual_fn_t,
		mcctrl_sysfs_unmap_memory_fn_t,
		mcctrl_sysfs_req_unlink_local_fn_t,
		mcctrl_sysfs_wmb_fn_t);

static void require(int cond)
{
	if (!cond)
		exit(1);
}

static void mix(unsigned long long *digest, unsigned long value)
{
	*digest ^= (unsigned long long)value + 0x9e3779b97f4a7c15ULL +
		(*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static struct mcctrl_procfs_work_prefix fake_work;
static int fake_alloc_calls;
static int fake_fail_alloc;
static unsigned long fake_alloc_size;
static int fake_init_schedule_calls;
static struct mcctrl_procfs_work_prefix *fake_scheduled_work;
static int fake_alloc_failed_calls;
static void *fake_last_os;
static int fake_add_calls;
static int fake_delete_calls;
static int fake_last_osnum;
static int fake_last_pid;
static int fake_last_tid;
static int fake_os_to_dev_calls;
static void *fake_last_dev;
static int fake_map_memory_calls;
static unsigned long fake_last_resp_pa;
static unsigned long fake_last_map_size;
static unsigned long fake_mapped_phys;
static int fake_map_virtual_calls;
static void *fake_last_attr;
static int fake_last_flags;
static int fake_done_value;
static int fake_unmap_virtual_calls;
static int fake_unmap_memory_calls;
static int fake_unknown_calls;
static int fake_unknown_msg;
static int fake_free_calls;
static void *fake_freed_work;
static int fake_procfs_base_entry;
static int fake_procfs_pid_entry;
static int fake_procfs_task_entry;
static int fake_procfs_tid_entry;
static int fake_procfs_new_base_entry;
static int fake_procfs_new_pid_entry;
static int fake_procfs_new_tid_entry;
static int fake_procfs_format_mcos_calls;
static int fake_procfs_format_decimal_calls;
static int fake_procfs_last_format_value;
static int fake_procfs_find_calls;
static int fake_procfs_add_calls;
static int fake_procfs_set_osnum_calls;
static int fake_procfs_last_set_osnum;
static int fake_procfs_last_mode;
static int fake_procfs_missing_base;
static int fake_procfs_missing_pid;
static int fake_procfs_missing_task;
static int fake_procfs_missing_tid;
static int fake_procfs_fail_add;
static void *fake_procfs_last_parent;
static char fake_procfs_last_name[32];
static int fake_procfs_cred;
static int fake_procfs_no_cred;
static int fake_procfs_get_cred_calls;
static int fake_procfs_lock_calls;
static int fake_procfs_unlock_calls;
static int fake_procfs_find_pid_direct_calls;
static int fake_procfs_get_pid_direct_calls;
static int fake_procfs_find_tid_direct_calls;
static int fake_procfs_get_tid_direct_calls;
static int fake_procfs_find_base_direct_calls;
static int fake_procfs_get_base_direct_calls;
static int fake_procfs_add_pid_entries_calls;
static int fake_procfs_add_base_entries_calls;
static int fake_procfs_add_tid_entries_calls;
static int fake_procfs_add_tid_cred_calls;
static int fake_procfs_delete_entry_calls;
static int fake_procfs_find_exe_data_calls;
static int fake_procfs_add_exe_link_calls;
static int fake_procfs_add_pid_exe_calls;
static int fake_procfs_store_exe_path_calls;
static int fake_procfs_add_task_exe_links_calls;
static int fake_procfs_missing_exe;
static int fake_procfs_last_osnum;
static int fake_procfs_last_pid;
static int fake_procfs_last_tid;
static void *fake_procfs_last_cred;
static void *fake_procfs_last_target;
static void *fake_procfs_deleted_entry;
static char fake_procfs_last_path[64];
struct fake_procfs_file {
	void *private_data;
};
struct fake_procfs_buffer_info {
	unsigned long top_pa;
	unsigned long cur_pa;
	void *os;
	int pid;
	char path[64];
};
struct fake_procfs_read {
	unsigned long pbuf;
	int ret;
	char fname[64];
};
struct fake_procfs_buffer_page {
	unsigned long phys;
	unsigned long next_pa;
	unsigned long pos;
	unsigned long size;
	char buf[32];
};
struct fake_procfs_path_entry {
	const char *name;
	struct fake_procfs_path_entry *parent;
};
struct fake_procfs_entry_table {
	const char *name;
	unsigned int mode;
	const void *fops;
};
struct fake_procfs_list_node {
	const char *name;
	struct fake_procfs_list_node *next;
};
static struct fake_procfs_file fake_procfs_file;
static struct fake_procfs_buffer_info fake_procfs_info;
static struct fake_procfs_read fake_procfs_read;
static struct fake_procfs_buffer_page fake_procfs_pages[2];
static char fake_procfs_user_buf[64];
static char fake_procfs_kernel_page[8192];
static char fake_procfs_path_buf[64];
static char fake_procfs_forced_path[64];
static int fake_procfs_entry_osnum_value;
static int fake_procfs_os_missing;
static int fake_procfs_open_alloc_calls;
static int fake_procfs_open_fail_alloc_call;
static unsigned long fake_procfs_open_last_size;
static int fake_procfs_open_free_calls;
static int fake_procfs_init_info_calls;
static int fake_procfs_set_private_calls;
static int fake_procfs_get_private_calls;
static int fake_procfs_release_alloc_read_calls;
static int fake_procfs_release_fail_alloc_read;
static int fake_procfs_init_release_read_calls;
static int fake_procfs_release_send_calls;
static int fake_procfs_release_send_ret;
static int fake_procfs_release_do_free;
static int fake_procfs_release_read_ret;
static int fake_procfs_release_timeout_calls;
static int fake_procfs_read_get_usrdata_calls;
static int fake_procfs_read_missing_usrdata;
static int fake_procfs_read_get_ppd_calls;
static int fake_procfs_read_missing_ppd;
static int fake_procfs_read_put_ppd_calls;
static int fake_procfs_read_ppd_cpu_calls;
static int fake_procfs_init_request_read_calls;
static int fake_procfs_request_send_calls;
static int fake_procfs_request_send_ret;
static int fake_procfs_request_do_free;
static int fake_procfs_request_read_ret;
static unsigned long fake_procfs_request_pbuf;
static int fake_procfs_read_timeout_calls;
static int fake_procfs_read_no_usrdata_calls;
static int fake_procfs_read_no_ppd_calls;
static int fake_procfs_add_entries_calls;
static void *fake_procfs_add_entries_parent;
static const char *fake_procfs_add_entries_name;
static unsigned int fake_procfs_add_entries_mode;
static const void *fake_procfs_add_entries_fops;
static const void *fake_procfs_add_entries_uid;
static const void *fake_procfs_add_entries_gid;
static int fake_procfs_entry_alloc_calls;
static int fake_procfs_entry_alloc_fail;
static unsigned long fake_procfs_entry_alloc_size;
static int fake_procfs_entry_init_calls;
static char fake_procfs_entry_init_name[32];
static int fake_procfs_entry_create_calls;
static int fake_procfs_entry_create_fail;
static unsigned int fake_procfs_entry_create_mode;
static const void *fake_procfs_entry_create_uid;
static const void *fake_procfs_entry_create_gid;
static const void *fake_procfs_entry_create_opaque;
static void *fake_procfs_entry_create_entry;
static int fake_procfs_entry_commit_calls;
static void *fake_procfs_entry_commit_parent;
static void *fake_procfs_entry_commit_pde;
static const void *fake_procfs_entry_commit_uid;
static const void *fake_procfs_entry_commit_gid;
static int fake_procfs_entry_free_calls;
static void *fake_procfs_entry_free_last;
static int fake_procfs_entry_alloc_failed_calls;
static int fake_procfs_entry_create_failed_calls;
static char fake_procfs_entry_create_failed_name[32];
static int fake_procfs_delete_lifecycle_child_present;
static int fake_procfs_delete_lifecycle_first_calls;
static int fake_procfs_delete_lifecycle_unlink_calls;
static int fake_procfs_delete_lifecycle_remove_calls;
static int fake_procfs_delete_lifecycle_data_calls;
static int fake_procfs_delete_lifecycle_free_calls;
static void *fake_procfs_delete_lifecycle_freed[4];
static int fake_procfs_lifecycle_entry;
static int fake_procfs_lifecycle_pde;
static int fake_procfs_lifecycle_data;
static int fake_procfs_first_child_calls;
static int fake_procfs_next_child_calls;
static int fake_procfs_entry_name_calls;
static int fake_procfs_rcu_lock_calls;
static int fake_procfs_rcu_unlock_calls;
static int fake_procfs_find_vpid_calls;
static int fake_procfs_pid_task_calls;
static int fake_procfs_task_cred_calls;
static int fake_procfs_pid_task_missing;
static int fake_procfs_last_pid_type;
static int fake_procfs_pid_token;
static int fake_procfs_task_token;
static int fake_procfs_cred_token;
static int fake_procfs_read_map_memory_calls;
static int fake_procfs_read_map_virtual_calls;
static int fake_procfs_read_unmap_virtual_calls;
static int fake_procfs_read_unmap_memory_calls;
static int fake_procfs_read_copy_calls;
static int fake_procfs_read_copy_fail;
static unsigned long fake_procfs_read_last_map_phys;
static unsigned long fake_procfs_read_last_map_size;
static int fake_procfs_rw_get_order_calls;
static int fake_procfs_rw_get_order_result;
static int fake_procfs_rw_alloc_pages_calls;
static int fake_procfs_rw_alloc_pages_fail;
static int fake_procfs_rw_last_order;
static int fake_procfs_rw_free_pages_calls;
static void *fake_procfs_rw_last_free_pages_ptr;
static int fake_procfs_rw_last_free_pages_order;
static int fake_procfs_rw_virt_to_phys_calls;
static int fake_procfs_rw_init_calls;
static unsigned long fake_procfs_rw_last_pbuf;
static long fake_procfs_rw_last_offset;
static int fake_procfs_rw_last_count;
static int fake_procfs_rw_last_read_write;
static char fake_procfs_rw_last_path[64];
static int fake_procfs_rw_eof;
static int fake_procfs_rw_copy_calls;
static int fake_procfs_rw_copy_fail;
static int fake_procfs_rw_bad_osnum_logs;
static int fake_procfs_rw_mismatch_logs;
static int fake_procfs_rw_no_os_logs;
static int fake_procfs_rw_no_usrdata_logs;
static int fake_procfs_rw_no_ppd_logs;
static int fake_procfs_rw_alloc_error_logs;
static int fake_procfs_rw_copy_error_logs;
static int fake_procfs_rw_timeout_logs;
static struct mcctrl_sysfs_work_prefix fake_sysfs_work;
static int fake_sysfs_alloc_calls;
static int fake_sysfs_fail_alloc;
static unsigned long fake_sysfs_alloc_size;
static int fake_sysfs_init_schedule_calls;
static struct mcctrl_sysfs_work_prefix *fake_sysfs_scheduled_work;
static int fake_sysfs_alloc_failed_calls;
static int fake_sysfs_req_calls[6];
static int fake_sysfs_resp_show_calls;
static int fake_sysfs_resp_store_calls;
static int fake_sysfs_resp_release_calls;
static int fake_sysfs_unknown_calls;
static int fake_sysfs_unknown_msg;
static void *fake_sysfs_last_os;
static void *fake_sysfs_last_node;
static long fake_sysfs_last_arg;
static long fake_sysfs_last_result;
static int fake_sysfs_last_error;
static int fake_sysfs_free_calls;
static void *fake_sysfs_freed_work;
struct fake_sysfs_remote_req {
	int busy;
	long lresult;
};
static struct fake_sysfs_remote_req fake_sysfs_remote_req;
static int fake_sysfs_remote_sem;
static char fake_sysfs_remote_kernel_buf[64];
static char fake_sysfs_remote_user_buf[64];
static int fake_sysfs_remote_down_calls;
static int fake_sysfs_remote_down_ret;
static int fake_sysfs_remote_up_calls;
static int fake_sysfs_remote_wait_calls;
static int fake_sysfs_remote_wait_fail_at;
static int fake_sysfs_remote_set_busy_calls;
static int fake_sysfs_remote_send_calls;
static int fake_sysfs_remote_send_ret;
static int fake_sysfs_remote_req_result_calls;
static int fake_sysfs_remote_copy_calls;
static void *fake_sysfs_remote_last_sem;
static void *fake_sysfs_remote_last_os;
static int fake_sysfs_remote_last_cpu;
static int fake_sysfs_remote_last_msg;
static long fake_sysfs_remote_last_arg1;
static long fake_sysfs_remote_last_arg2;
static long fake_sysfs_remote_last_arg3;
static int fake_sysfs_remote_last_err;
static unsigned long fake_sysfs_remote_last_copy_size;
static void *fake_sysfs_local_ops_table[9];
static struct mcctrl_sysfsm_bitmap_param fake_sysfs_local_bitmap;
static int fake_sysfs_local_alloc_calls;
static int fake_sysfs_local_fail_alloc;
static unsigned long fake_sysfs_local_alloc_size;
static int fake_sysfs_local_copy_calls;
static unsigned long fake_sysfs_local_copy_size;
static int fake_sysfs_local_unknown_calls;
static long fake_sysfs_local_unknown_ops_seen;
static struct mcctrl_sysfs_local_node fake_sysfs_local_node;
static struct mcctrl_sysfsm_ops fake_sysfs_client_ops;
static int fake_sysfs_local_show_calls;
static int fake_sysfs_local_store_calls;
static int fake_sysfs_local_release_calls;
static int fake_sysfs_local_free_calls;
static void *fake_sysfs_local_last_instance;
static void *fake_sysfs_local_last_buf;
static unsigned long fake_sysfs_local_last_size;
static int fake_sysfs_local_create_calls;
static int fake_sysfs_local_create_ret;
static void *fake_sysfs_local_create_os;
static struct mcctrl_sysfs_req_create_param *fake_sysfs_local_create_param;
static int fake_sysfs_local_mkdir_calls;
static int fake_sysfs_local_mkdir_ret;
static void *fake_sysfs_local_mkdir_os;
static struct mcctrl_sysfs_req_mkdir_param *fake_sysfs_local_mkdir_param;
static int fake_sysfs_local_symlink_calls;
static int fake_sysfs_local_symlink_ret;
static void *fake_sysfs_local_symlink_os;
static struct mcctrl_sysfs_req_symlink_param *fake_sysfs_local_symlink_param;
static int fake_sysfs_local_lookup_calls;
static int fake_sysfs_local_lookup_ret;
static void *fake_sysfs_local_lookup_os;
static struct mcctrl_sysfs_req_lookup_param *fake_sysfs_local_lookup_param;
static int fake_sysfs_local_unlink_calls;
static int fake_sysfs_local_unlink_ret;
static void *fake_sysfs_local_unlink_os;
static struct mcctrl_sysfs_req_unlink_param *fake_sysfs_local_unlink_param;
static int fake_sysfs_local_cleanup_calls;
static void *fake_sysfs_local_cleanup_ops;
static void *fake_sysfs_local_cleanup_instance;
static int fake_sysfs_local_setup_failed_calls;
static int fake_sysfs_local_setup_failed_error;
static int fake_sysfs_req_os_to_dev_calls;
static void *fake_sysfs_req_last_os;
static int fake_sysfs_req_map_memory_calls;
static int fake_sysfs_req_map_virtual_calls;
static int fake_sysfs_req_unmap_virtual_calls;
static int fake_sysfs_req_unmap_memory_calls;
static int fake_sysfs_req_wmb_calls;
static int fake_sysfs_req_setup_local_calls;
static int fake_sysfs_req_setup_local_ret;
static void *fake_sysfs_req_setup_os;
static void *fake_sysfs_req_setup_buf;
static unsigned long fake_sysfs_req_setup_buf_pa;
static unsigned long fake_sysfs_req_setup_bufsize;
static unsigned long fake_sysfs_req_last_rpa;
static unsigned long fake_sysfs_req_last_pa;
static unsigned long fake_sysfs_req_last_size;
static void *fake_sysfs_req_last_virt;
static int fake_sysfs_req_fail_virtual_on_call;
struct fake_sysfs_resp_req {
	long result;
	int complete_calls;
};
struct fake_sysfs_lookup_node {
	const char *name;
	int type;
	struct fake_sysfs_lookup_node *first_child;
	struct fake_sysfs_lookup_node *next_sibling;
};
static struct fake_sysfs_resp_req fake_sysfs_resp_req;
static int fake_sysfs_resp_get_req_calls;
static int fake_sysfs_resp_complete_calls;
static int fake_sysfs_lookup_type_calls;
static int fake_sysfs_lookup_name_calls;
static int fake_sysfs_lookup_first_calls;
static int fake_sysfs_lookup_next_calls;
static int fake_sysfs_lookup_err_calls;
static int fake_sysfs_lookup_last_error;
static int fake_sysfs_bitmap_format_calls;
static void *fake_sysfs_bitmap_last_ptr;
static int fake_sysfs_bitmap_last_nbits;
static unsigned long fake_sysfs_bitmap_last_size;
struct fake_mcctrl_futex_wait_q {
	uint32_t bitset;
	void *resp;
	int linux_cpu;
};
struct fake_mcctrl_futex_uti {
	struct fake_mcctrl_futex_wait_q *q;
	void *resp;
};
struct fake_mcctrl_futex_dispatch_trace {
	int wait_calls;
	int wake_calls;
	int requeue_calls;
	int wake_op_calls;
	int warn_calls;
	uint32_t *uaddr;
	uint32_t *uaddr2;
	uint32_t val;
	uint32_t val2;
	uint32_t val3;
	uint32_t cmpval;
	uint64_t timeout;
	int fshared;
	int clockrt;
	int warn_cmd;
	void *uti_info;
};
static struct fake_mcctrl_futex_wait_q fake_mcctrl_futex_q;
static struct fake_mcctrl_futex_uti fake_mcctrl_futex_uti;
static struct fake_mcctrl_futex_dispatch_trace fake_mcctrl_futex_dispatch;
static int fake_mcctrl_futex_prepare_calls;
static int fake_mcctrl_futex_cpu;
static int fake_mcctrl_futex_setup_calls;
static int fake_mcctrl_futex_setup_ret[4];
static int fake_mcctrl_futex_queue_calls;
static long long fake_mcctrl_futex_queue_ret[4];
static int fake_mcctrl_futex_unqueue_calls;
static int fake_mcctrl_futex_unqueue_ret[4];
static int fake_mcctrl_futex_put_key_calls;
static int fake_mcctrl_futex_last_put_fshared;
static void *fake_mcctrl_futex_last_put_q;
static int fake_mcctrl_futex_log_calls;
static int fake_mcctrl_futex_log_stage[4];
static uint32_t *fake_mcctrl_futex_last_uaddr;
static uint32_t fake_mcctrl_futex_last_val;
static uint64_t fake_mcctrl_futex_last_timeout;
static void *fake_mcctrl_futex_last_hb;
static int fake_mcctrl_futex_hb;
static int fake_control_calls;
static int fake_control_last_id;
static unsigned long fake_control_last_os;
static unsigned long fake_control_last_arg;
static unsigned long fake_control_last_file;
static long fake_control_ret_base;
static int fake_control_send_calls;
static int fake_control_send_ret;
static unsigned long fake_control_send_os;
static int fake_control_send_cpu;
static int fake_control_send_msg;
static unsigned long fake_control_send_arg;
static int fake_control_cpu_info_token;
static int fake_control_cpu_info_missing;
static int fake_control_cpu_count;
static int fake_control_get_cpu_info_calls;
static int fake_control_cpu_count_calls;
static int fake_control_usrdata_token;
static int fake_control_usrdata_missing;
static int fake_control_mem_info_token;
static int fake_control_mem_info_missing;
static int fake_control_nodes_count;
static int fake_control_get_usrdata_calls;
static int fake_control_mem_info_calls;
static int fake_control_nodes_count_calls;
static int fake_control_log_calls;
static int fake_control_log_stage;
static struct ihk_os_cpu_register fake_control_cpu_reg_local;
static int fake_control_cpu_reg_alloc_calls;
static int fake_control_cpu_reg_alloc_fail;
static unsigned long fake_control_cpu_reg_alloc_size;
static int fake_control_cpu_reg_free_calls;
static void *fake_control_cpu_reg_freed;
static int fake_control_cpu_reg_cpu_count;
static int fake_control_cpu_reg_cpu_count_calls;
static int fake_control_cpu_reg_send_calls;
static int fake_control_cpu_reg_send_ret;
static int fake_control_cpu_reg_send_do_free;
static unsigned long fake_control_cpu_reg_send_os;
static int fake_control_cpu_reg_send_cpu;
static int fake_control_cpu_reg_send_msg;
static int fake_control_cpu_reg_send_op;
static unsigned long fake_control_cpu_reg_send_pdesc;
static long fake_control_cpu_reg_send_timeout;
static void *fake_control_cpu_reg_send_desc;
static unsigned long fake_control_cpu_reg_phys;
static int fake_control_cpu_reg_error_calls;
static int fake_control_cpu_reg_error_stage;
static int fake_control_cpu_reg_error_cpu;
static int fake_control_cpu_reg_error_ret;
static int fake_control_cpu_reg_done_calls;
static int fake_control_cpu_reg_done_op;
static int fake_control_cpu_reg_done_is_read;
static int fake_control_cpu_reg_done_cpu;
static unsigned long fake_control_cpu_reg_done_addr_ext;
static unsigned long fake_control_cpu_reg_done_val;
static unsigned long fake_control_cpu_reg_mutate_val;
static int fake_control_validate_os_calls;
static int fake_control_validate_os_ret;
static unsigned long fake_control_validate_os_seen;
static int fake_control_current_pid_calls;
static int fake_control_current_tid_calls;
static int fake_control_current_pid_value;
static int fake_control_current_tid_value;
static int fake_control_current_task_calls;
static int fake_control_task_token;
static int fake_control_ppd_token;
static int fake_control_get_ppd_calls;
static int fake_control_missing_ppd;
static void *fake_control_get_ppd_usrdata;
static int fake_control_get_ppd_pid;
static int fake_control_put_ppd_calls;
static void *fake_control_put_ppd_seen;
static int fake_control_ptd_token;
static int fake_control_get_ptd_calls;
static int fake_control_missing_ptd;
static void *fake_control_get_ptd_ppd;
static void *fake_control_get_ptd_task;
static int fake_control_put_ptd_calls;
static void *fake_control_put_ptd_seen;
static struct mcctrl_ikc_scd_packet fake_control_request_packet;
static int fake_control_packet_missing;
static int fake_control_ptd_data_calls;
static int fake_control_ptd_tid_calls;
static int fake_control_ptd_tid_value;
static int fake_control_ptd_refcount_calls;
static int fake_control_ptd_refcount_value;
static int fake_control_usrdata_os_calls;
static unsigned long fake_control_usrdata_os_value;
static int fake_control_packet_ref_calls;
static int fake_control_channel_read_cpu_calls;
static int fake_control_channel_read_cpu_result;
static int fake_control_channel_packet_ref;
static int fake_control_request_log_error_calls;
static int fake_control_request_log_error_stage;
static unsigned long fake_control_request_log_error_os;
static int fake_control_request_log_error_pid;
static int fake_control_request_log_error_tid;
static int fake_control_request_log_ptd_calls;
static int fake_control_request_log_ptd_get_calls;
static int fake_control_request_log_ptd_put_calls;
static int fake_control_request_log_ptd_stage;
static int fake_control_request_log_ptd_tid;
static void *fake_control_request_log_ptd_seen;
static int fake_control_request_log_result_calls;
static unsigned long fake_control_request_log_result_os;
static int fake_control_request_log_result_cpu;
static int fake_control_request_release_order;
static int fake_control_request_put_ptd_order;
static int fake_control_request_log_ptd_put_order;
static int fake_control_request_put_ppd_order;
static int fake_control_copy_from_calls;
static int fake_control_copy_from_fail;
static int fake_control_copy_from_fail_at;
static const void *fake_control_copy_from_src;
static void *fake_control_copy_from_dst;
static unsigned long fake_control_copy_from_size;
static int fake_control_copy_to_calls;
static int fake_control_copy_to_fail;
static int fake_control_copy_to_fail_at;
static const void *fake_control_copy_to_src;
static void *fake_control_copy_to_dst;
static unsigned long fake_control_copy_to_size;
static const void *fake_control_copy_to_src_history[4];
static void *fake_control_copy_to_dst_history[4];
static unsigned long fake_control_copy_to_size_history[4];
static int fake_control_get_order_calls;
static unsigned long fake_control_get_order_size;
static int fake_control_get_order_result;
static int fake_control_alloc_pages_calls;
static int fake_control_alloc_pages_order;
static unsigned long fake_control_alloc_pages_result;
static int fake_control_free_pages_calls;
static unsigned long fake_control_free_pages_addr;
static int fake_control_free_pages_order;
static int fake_control_region_virt_to_phys_calls;
static void *fake_control_region_virt_to_phys_ptr;
static unsigned long fake_control_region_virt_to_phys_result;
static int fake_control_region_phys_to_virt_calls;
static unsigned long fake_control_region_phys_to_virt_phys;
static unsigned long fake_control_region_phys_to_virt_result;
static int fake_control_cred_token;
static int fake_control_original_cred_token;
static int fake_control_cred_order;
static int fake_control_prepare_creds_calls;
static int fake_control_prepare_creds_fail;
static int fake_control_prepare_creds_order;
static int fake_control_cap_raise_calls;
static int fake_control_cap_raise_order;
static int fake_control_override_creds_calls;
static int fake_control_override_creds_order;
static int fake_control_revert_creds_calls;
static int fake_control_revert_creds_order;
static int fake_control_put_cred_calls;
static int fake_control_put_cred_order;
static int fake_control_mount_calls;
static int fake_control_mount_ret;
static int fake_control_mount_order;
static char *fake_control_mount_dev;
static char *fake_control_mount_dir;
static char *fake_control_mount_type;
static unsigned long fake_control_mount_flags;
static void *fake_control_mount_data;
static int fake_control_umount_calls;
static int fake_control_umount_ret;
static int fake_control_umount_order;
static char *fake_control_umount_dir;
static int fake_control_umount_flags;
static int fake_control_unshare_calls;
static int fake_control_unshare_ret;
static int fake_control_unshare_order;
static unsigned long fake_control_unshare_flags;
static int fake_control_clear_pte_calls;
static unsigned long fake_control_clear_pte_start;
static unsigned long fake_control_clear_pte_len;
static long fake_control_clear_pte_ret;
static int fake_control_perf_set_num_calls;
static void *fake_control_perf_set_num_usrdata;
static unsigned long fake_control_perf_set_num_value;
static int fake_control_perf_event_num;
static struct ihk_perf_event_attr fake_control_perf_attrs[4];
static struct fake_control_perf_desc fake_control_perf_descs[4];
static unsigned long fake_control_perf_user_values[4];
static int fake_control_perf_event_num_calls;
static int fake_control_perf_alloc_set_calls;
static int fake_control_perf_alloc_set_fail_index;
static int fake_control_perf_copy_fail_index;
static int fake_control_perf_alloc_desc_calls;
static unsigned long fake_control_perf_alloc_desc_size;
static int fake_control_perf_alloc_desc_fail;
static int fake_control_perf_free_calls;
static void *fake_control_perf_freed_desc;
static int fake_control_perf_init_get_calls;
static int fake_control_perf_init_mask_calls;
static int fake_control_perf_init_mask_type;
static unsigned long fake_control_perf_init_mask_value;
static int fake_control_perf_send_calls;
static unsigned long fake_control_perf_send_os;
static int fake_control_perf_send_cpu;
static long fake_control_perf_send_timeout;
static int fake_control_perf_send_ret;
static int fake_control_perf_send_fail_call;
static int fake_control_perf_send_need_free;
static int fake_control_perf_desc_err_calls;
static int fake_control_perf_desc_err_value;
static int fake_control_perf_desc_err_after_cpu;
static int fake_control_perf_desc_read_calls;
static int fake_control_perf_copyout_fail;
static int fake_control_perf_log_calls;
static int fake_control_perf_log_stage;
static int fake_control_perf_disable_calls;
static unsigned long fake_control_perf_disable_os;
static long fake_control_perf_disable_ret;
static int fake_control_perf_num_zero_calls;
static unsigned long fake_control_perf_num_zero_os;
static long fake_control_perf_num_zero_ret;
static struct fake_rusage_global fake_control_rusage_global;
static struct mcctrl_ioctl_getrusage_desc fake_control_rusage_desc;
static struct fake_ihk_os_rusage fake_control_rusage_user_out;
static struct fake_ihk_os_rusage fake_control_rusage_alloc_out;
static int fake_control_getrusage_calls;
static unsigned long fake_control_getrusage_os;
static int fake_control_getrusage_alloc_calls;
static unsigned long fake_control_getrusage_alloc_size;
static int fake_control_getrusage_alloc_fail;
static int fake_control_getrusage_free_calls;
static void *fake_control_getrusage_freed;
static int fake_control_getrusage_log_calls;
static int fake_control_getrusage_log_stage;
static unsigned long fake_control_getrusage_log_size;
static unsigned long fake_control_getrusage_log_max;
static struct fake_control_remote_transfer fake_control_transfer_desc;
static struct fake_control_syscall_load_desc fake_control_load_desc;
static struct fake_control_syscall_ret_desc fake_control_ret_desc;
static struct fake_control_uti_get_ctx_desc fake_control_uti_desc;
static unsigned char fake_control_user_buf[64];
static unsigned char fake_control_remote_buf[64];
static unsigned char fake_control_uti_remote_ctx[4096];
static unsigned char fake_control_uti_user_ctx[4096];
static int fake_control_os_to_dev_calls;
static unsigned long fake_control_os_to_dev_os;
static int fake_control_map_memory_calls;
static unsigned long fake_control_map_memory_phys;
static unsigned long fake_control_map_memory_size;
static int fake_control_map_virtual_calls;
static unsigned long fake_control_map_virtual_phys;
static unsigned long fake_control_map_virtual_size;
static int fake_control_map_virtual_fail;
static int fake_control_unmap_virtual_calls;
static void *fake_control_unmap_virtual_ptr;
static unsigned long fake_control_unmap_virtual_size;
static int fake_control_unmap_memory_calls;
static unsigned long fake_control_unmap_memory_phys;
static unsigned long fake_control_unmap_memory_size;
static int fake_control_transfer_log_calls;
static int fake_control_transfer_log_stage;
static int fake_control_load_log_calls;
static void *fake_control_load_log_rpm;
static unsigned long fake_control_load_log_size;
static int fake_control_return_syscall_calls;
static unsigned long fake_control_return_syscall_os;
static void *fake_control_return_syscall_ppd;
static void *fake_control_return_syscall_packet;
static long fake_control_return_syscall_ret;
static int fake_control_return_syscall_tid;
static int fake_control_release_packet_calls;
static void *fake_control_release_packet_seen;
static int fake_control_release_packet_order;
static int fake_control_ret_log_calls;
static int fake_control_ret_log_stage[4];
static int fake_control_ret_log_pid[4];
static int fake_control_ret_log_tid[4];
static int fake_control_terminate_log_calls;
static int fake_control_terminate_log_stage[8];
static int fake_control_terminate_log_pid[8];
static int fake_control_terminate_log_tid[8];
static void *fake_control_terminate_log_ptr[8];
static int fake_control_terminate_log_value[8];
static int fake_control_current_key_calls;
static unsigned long fake_control_current_key_value;
static int fake_control_uti_log_calls;
static int fake_control_uti_log_stage[4];
static int fake_control_cred_values[8];
static int fake_control_cred_calls[8];
static int fake_control_cred_kernel_values[8];
static int fake_control_cred_phys_to_virt_calls;
static unsigned long fake_control_cred_phys_to_virt_phys;
static unsigned char fake_control_strncpy_page[4096];
static int fake_control_strncpy_alloc_calls;
static int fake_control_strncpy_alloc_fail;
static int fake_control_strncpy_free_calls;
static void *fake_control_strncpy_freed;
static int fake_control_strncpy_calls;
static long fake_control_strncpy_ret[4];
static unsigned long fake_control_strncpy_want[4];
static const void *fake_control_strncpy_src[4];
static int fake_control_strncpy_copy_to_calls;
static int fake_control_strncpy_fail_data_copy;
static int fake_control_strncpy_fail_desc_copy;
static void *fake_control_strncpy_desc_arg;
static int fake_control_destroy_log_calls;
static int fake_control_destroy_log_stage[4];
static int fake_control_destroy_log_pid[4];
static void *fake_control_destroy_log_ppd[4];
static int fake_control_drop_exec_calls;
static int fake_control_drop_exec_ret;
static unsigned long fake_control_drop_exec_os;
static int fake_control_drop_exec_pid;
struct fake_control_new_info {
	int pid;
};
static struct fake_control_new_info fake_control_new_info_token;
static int fake_control_new_info_calls;
static int fake_control_new_info_fail;
static unsigned long fake_control_new_info_os;
static void *fake_control_new_info_file;
static int fake_control_set_info_pid_calls;
static int fake_control_set_info_pid_value;
static int fake_control_register_release_calls;
static void *fake_control_register_release_file;
static void *fake_control_register_release_info;
static int fake_control_set_private_calls;
static void *fake_control_set_private_file;
static void *fake_control_set_private_info;
struct fake_control_start_desc {
	int cpu;
	int pid;
	unsigned long user_start;
	unsigned long user_end;
	unsigned long rprocess;
};
struct fake_control_start_info {
	int pid;
	int cpu;
	unsigned long user_start;
	unsigned long user_end;
	unsigned long prepare_thread;
};
static struct fake_control_start_desc fake_control_start_user_desc;
static struct fake_control_start_desc fake_control_start_local_desc;
static struct fake_control_start_info fake_control_start_prev_info;
static struct fake_control_start_info fake_control_start_new_info;
static int fake_control_start_alloc_calls;
static int fake_control_start_alloc_fail;
static unsigned long fake_control_start_alloc_size;
static int fake_control_start_free_calls;
static void *fake_control_start_freed;
static int fake_control_start_get_private_calls;
static void *fake_control_start_private_file;
static int fake_control_start_new_info_calls;
static int fake_control_start_new_info_fail;
static unsigned long fake_control_start_new_info_os;
static void *fake_control_start_new_info_file;
static int fake_control_start_set_info_calls;
static unsigned long fake_control_start_set_info_prepare_thread;
static int fake_control_start_info_prepare_calls;
static int fake_control_start_set_recv_calls;
static unsigned long fake_control_start_set_recv_os;
static int fake_control_start_set_recv_cpu;
static int fake_control_start_set_last_calls;
static void *fake_control_start_set_last_usrdata;
static unsigned long fake_control_start_set_last_cpu;
static int fake_control_start_send_calls;
static int fake_control_start_send_ret;
static unsigned long fake_control_start_send_os;
static int fake_control_start_send_cpu;
static unsigned long fake_control_start_send_rprocess;
static int fake_control_start_clear_calls;
static int fake_control_start_log_calls;
static int fake_control_start_log_stage[4];
static int fake_control_start_log_ret[4];
struct fake_control_signal_desc {
	int cpu;
	int pid;
	int tid;
	int sig;
	unsigned char info[128];
};
struct fake_control_signal {
	int cond;
	int sig;
	int pid;
	int tid;
	unsigned char info[128];
};
struct fake_control_signal_wrapper {
	struct fake_control_signal msig;
};
static struct fake_control_signal_desc fake_control_signal_user_desc;
static struct fake_control_signal_wrapper fake_control_signal_local_desc;
static int fake_control_signal_alloc_calls;
static int fake_control_signal_alloc_fail;
static unsigned long fake_control_signal_alloc_size;
static int fake_control_signal_free_calls;
static void *fake_control_signal_freed;
static int fake_control_signal_vtop_calls;
static void *fake_control_signal_vtop_ptr;
static unsigned long fake_control_signal_vtop_result;
static int fake_control_signal_send_calls;
static int fake_control_signal_send_ret;
static int fake_control_signal_send_do_free;
static unsigned long fake_control_signal_send_os;
static int fake_control_signal_send_cpu;
static int fake_control_signal_send_msg;
static int fake_control_signal_send_ref;
static int fake_control_signal_send_pid;
static unsigned long fake_control_signal_send_arg;
static long fake_control_signal_send_timeout;
static void *fake_control_signal_send_desc;
static int fake_control_signal_log_calls;
static int fake_control_signal_log_stage[4];
static int fake_control_signal_log_ret[4];
static void *fake_driver_os_slots[64];
static void *fake_driver_find_result;
static int fake_driver_control_calls;
static unsigned int fake_driver_control_request;
static unsigned long fake_driver_control_os;
static unsigned long fake_driver_control_arg;
static unsigned long fake_driver_control_file;
static int fake_driver_get_os_calls;
static int fake_driver_set_os_calls;
static int fake_driver_last_index;
static void *fake_driver_last_os;
static int fake_driver_prepare_calls;
static int fake_driver_prepare_ret;
static int fake_driver_copy_proto_calls;
static int fake_driver_set_kernel_calls;
static int fake_driver_set_kernel_ret;
static int fake_driver_register_user_calls;
static int fake_driver_register_user_ret;
static int fake_driver_procfs_init_calls;
static int fake_driver_clear_kernel_calls;
static int fake_driver_destroy_calls;
static int fake_driver_pager_cleanup_calls;
static int fake_driver_sysfs_cleanup_calls;
static int fake_driver_free_topology_calls;
static int fake_driver_unregister_user_calls;
static int fake_driver_procfs_exit_calls;
static int fake_driver_log_stage;
static int fake_driver_log_index;
static int fake_driver_log_calls;
static int fake_driver_lookup_calls;
static int fake_driver_publish_calls;
static int fake_driver_warn_calls;
static int fake_driver_arch_calls;
static int fake_driver_arch_ret;
static int fake_driver_symbol_missing;
static void *fake_driver_symbol_values[8];
static void *fake_driver_published_symbols[8];
static int fake_driver_syscall_init_calls;
static int fake_driver_binfmt_init_calls;
static int fake_driver_tofu_hash_calls;
static int fake_driver_symbols_init_calls;
static int fake_driver_symbols_init_ret;
static int fake_driver_tofu_hijack_calls;
static int fake_driver_register_notifier_calls;
static int fake_driver_register_notifier_ret;
static int fake_driver_binfmt_exit_calls;
static int fake_driver_deregister_notifier_calls;
static int fake_driver_deregister_notifier_ret;
static int fake_driver_uti_finalize_calls;
static int fake_driver_tofu_restore_calls;
static char fake_driver_order[64];
static int fake_driver_order_len;
static int fake_in_kernel_pager_irq_calls;
static int fake_in_kernel_pager_calls;
static int fake_in_kernel_clear_calls;
static int fake_in_kernel_remap_calls;
static int fake_in_kernel_zero_calls;
static int fake_in_kernel_writecore_calls;
static int fake_in_kernel_sched_same_calls;
static int fake_in_kernel_sched_root_calls;
static int fake_in_kernel_tofu_close_calls;
static int fake_in_kernel_return_calls;
static int fake_in_kernel_release_calls;
static unsigned long fake_in_kernel_last_os;
static unsigned long fake_in_kernel_last_number;
static unsigned long fake_in_kernel_last_arg0;
static unsigned long fake_in_kernel_last_arg1;
static unsigned long fake_in_kernel_last_arg2;
static unsigned long fake_in_kernel_last_arg3;
static int fake_in_kernel_last_int;
static long fake_in_kernel_last_ret;
static int fake_in_kernel_last_stid;
static struct mcctrl_ikc_scd_packet *fake_in_kernel_last_packet;
static long fake_in_kernel_pager_irq_ret;
static long fake_in_kernel_pager_ret;
static long fake_in_kernel_clear_ret;
static long fake_in_kernel_remap_ret;
static long fake_in_kernel_writecore_ret;
static long fake_in_kernel_sched_same_ret;
static long fake_in_kernel_sched_root_ret;
static int fake_pager_create_calls;
static int fake_pager_release_calls;
static int fake_pager_read_calls;
static int fake_pager_write_calls;
static int fake_pager_map_calls;
static int fake_pager_pfn_calls;
static int fake_pager_unmap_calls;
static int fake_pager_mlock_calls;
static int fake_pager_unknown_calls;
static unsigned long fake_pager_last_os;
static unsigned long fake_pager_last_request;
static unsigned long fake_pager_last_arg1;
static unsigned long fake_pager_last_arg2;
static unsigned long fake_pager_last_arg3;
static unsigned long fake_pager_last_arg4;
static unsigned long fake_pager_last_arg5;
static int fake_pager_last_int;
static long fake_pager_create_ret;
static long fake_pager_release_ret;
static long fake_pager_read_ret;
static long fake_pager_write_ret;
static long fake_pager_map_ret;
static long fake_pager_pfn_ret;
static long fake_pager_unmap_ret;
static long fake_pager_mlock_ret;
static int fake_remote_pf_send_calls;
static int fake_remote_pf_log_calls;
static int fake_remote_pf_last_stage;
static int fake_remote_pf_last_cpu;
static int fake_remote_pf_last_pid;
static int fake_remote_pf_last_error;
static unsigned long fake_remote_pf_last_os;
static unsigned long fake_remote_pf_last_addr;
static unsigned long fake_remote_pf_last_reason;
static struct mcctrl_ikc_scd_packet *fake_remote_pf_last_packet;
static int fake_remote_pf_send_ret;
static struct fake_user_vma fake_user_vmas[4];
static int fake_user_vma_count;
static int fake_user_space_lock_calls;
static int fake_user_space_unlock_calls;
static int fake_user_space_find_calls;
static unsigned long fake_user_space_last_find;
static int fake_user_space_set_rw_calls;
static int fake_user_space_zap_ptes_calls;
static int fake_user_space_zap_range_calls;
static int fake_user_space_munmap_calls;
static int fake_user_space_log_calls;
static int fake_user_space_zap_ptes_ret;
static int fake_user_space_munmap_ret;
static unsigned long fake_user_space_last_start;
static unsigned long fake_user_space_last_len;
static unsigned long fake_user_space_munmap_total;
static int fake_user_space_last_error;

#define FAKE_CONTROL_DISPATCHES(_) \
	_(prepare_image, 1, MCEXEC_UP_PREPARE_IMAGE) \
	_(transfer_image, 2, MCEXEC_UP_TRANSFER) \
	_(start_image, 3, MCEXEC_UP_START_IMAGE) \
	_(wait_syscall, 4, MCEXEC_UP_WAIT_SYSCALL) \
	_(ret_syscall, 5, MCEXEC_UP_RET_SYSCALL) \
	_(load_syscall, 6, MCEXEC_UP_LOAD_SYSCALL) \
	_(send_signal, 7, MCEXEC_UP_SEND_SIGNAL) \
	_(get_cpu, 8, MCEXEC_UP_GET_CPU) \
	_(create_ppd, 9, MCEXEC_UP_CREATE_PPD) \
	_(get_nodes, 10, MCEXEC_UP_GET_NODES) \
	_(get_cpuset, 11, MCEXEC_UP_GET_CPUSET) \
	_(strncpy_from_user, 12, MCEXEC_UP_STRNCPY_FROM_USER) \
	_(open_exec, 13, MCEXEC_UP_OPEN_EXEC) \
	_(close_exec, 14, MCEXEC_UP_CLOSE_EXEC) \
	_(prepare_dma, 15, MCEXEC_UP_PREPARE_DMA) \
	_(free_dma, 16, MCEXEC_UP_FREE_DMA) \
	_(get_cred, 17, MCEXEC_UP_GET_CRED) \
	_(get_credv, 18, MCEXEC_UP_GET_CREDV) \
	_(sys_mount, 19, MCEXEC_UP_SYS_MOUNT) \
	_(sys_umount, 20, MCEXEC_UP_SYS_UMOUNT) \
	_(sys_unshare, 21, MCEXEC_UP_SYS_UNSHARE) \
	_(uti_get_ctx, 22, MCEXEC_UP_UTI_GET_CTX) \
	_(uti_switch_ctx, 23, MCEXEC_UP_UTI_SWITCH_CTX) \
	_(sig_thread, 24, MCEXEC_UP_SIG_THREAD) \
	_(syscall_thread, 25, MCEXEC_UP_SYSCALL_THREAD) \
	_(terminate_thread, 26, MCEXEC_UP_TERMINATE_THREAD) \
	_(release_user_space, 27, MCEXEC_UP_RELEASE_USER_SPACE) \
	_(get_num_pool_threads, 28, MCEXEC_UP_GET_NUM_POOL_THREADS) \
	_(uti_attr, 29, MCEXEC_UP_UTI_ATTR) \
	_(debug_log, 30, MCEXEC_UP_DEBUG_LOG) \
	_(perf_num, 31, IHK_OS_AUX_PERF_NUM) \
	_(perf_set, 32, IHK_OS_AUX_PERF_SET) \
	_(perf_get, 33, IHK_OS_AUX_PERF_GET) \
	_(perf_enable, 34, IHK_OS_AUX_PERF_ENABLE) \
	_(perf_disable, 35, IHK_OS_AUX_PERF_DISABLE) \
	_(perf_destroy, 36, IHK_OS_AUX_PERF_DESTROY) \
	_(getrusage, 37, IHK_OS_GETRUSAGE)

#define DEFINE_FAKE_CONTROL_CB(name, id, request) \
static long fake_control_##name(unsigned long os, unsigned long arg, \
		unsigned long file) \
{ \
	(void)request; \
	fake_control_calls++; \
	fake_control_last_id = id; \
	fake_control_last_os = os; \
	fake_control_last_arg = arg; \
	fake_control_last_file = file; \
	return fake_control_ret_base + id; \
}
FAKE_CONTROL_DISPATCHES(DEFINE_FAKE_CONTROL_CB)

static const struct mcctrl_control_dispatch_ops fake_control_ops = {
#define INIT_FAKE_CONTROL_CB(name, id, request) .name = fake_control_##name,
	FAKE_CONTROL_DISPATCHES(INIT_FAKE_CONTROL_CB)
#undef INIT_FAKE_CONTROL_CB
};

static int fake_control_ikc_send(unsigned long os, int cpu,
		struct mcctrl_ikc_scd_packet *packet)
{
	fake_control_send_calls++;
	fake_control_send_os = os;
	fake_control_send_cpu = cpu;
	fake_control_send_msg = packet->msg;
	fake_control_send_arg = packet->body.traditional.arg;
	return fake_control_send_ret;
}

static void *fake_control_get_cpu_info(unsigned long os)
{
	fake_control_get_cpu_info_calls++;
	fake_control_last_os = os;
	if (fake_control_cpu_info_missing)
		return NULL;
	return &fake_control_cpu_info_token;
}

static int fake_control_cpu_info_n_cpus(void *info)
{
	require(info == &fake_control_cpu_info_token);
	fake_control_cpu_count_calls++;
	return fake_control_cpu_count;
}

static void *fake_control_get_usrdata(unsigned long os)
{
	fake_control_get_usrdata_calls++;
	fake_control_last_os = os;
	if (fake_control_usrdata_missing)
		return NULL;
	return &fake_control_usrdata_token;
}

static void *fake_control_usrdata_mem_info(void *usrdata)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_mem_info_calls++;
	if (fake_control_mem_info_missing)
		return NULL;
	return &fake_control_mem_info_token;
}

static int fake_control_mem_info_n_nodes(void *mem_info)
{
	require(mem_info == &fake_control_mem_info_token);
	fake_control_nodes_count_calls++;
	return fake_control_nodes_count;
}

static void fake_control_log_error(int stage)
{
	fake_control_log_calls++;
	fake_control_log_stage = stage;
}

static int fake_control_usrdata_cpu_count(void *usrdata)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_cpu_reg_cpu_count_calls++;
	return fake_control_cpu_reg_cpu_count;
}

static void *fake_control_cpu_reg_alloc(unsigned long size)
{
	fake_control_cpu_reg_alloc_calls++;
	fake_control_cpu_reg_alloc_size = size;
	if (fake_control_cpu_reg_alloc_fail)
		return NULL;
	memset(&fake_control_cpu_reg_local, 0,
			sizeof(fake_control_cpu_reg_local));
	return &fake_control_cpu_reg_local;
}

static void fake_control_cpu_reg_free(void *ptr)
{
	fake_control_cpu_reg_free_calls++;
	fake_control_cpu_reg_freed = ptr;
}

static unsigned long fake_control_cpu_reg_virt_to_phys(void *ptr)
{
	require(ptr == &fake_control_cpu_reg_local);
	return fake_control_cpu_reg_phys;
}

static int fake_control_cpu_reg_send_wait(unsigned long os, int cpu,
		struct mcctrl_ikc_scd_packet *packet, long timeout,
		int *do_free, void *desc)
{
	fake_control_cpu_reg_send_calls++;
	fake_control_cpu_reg_send_os = os;
	fake_control_cpu_reg_send_cpu = cpu;
	fake_control_cpu_reg_send_msg = packet->msg;
	fake_control_cpu_reg_send_op = packet->body.cpu_rw.op;
	fake_control_cpu_reg_send_pdesc = packet->body.cpu_rw.pdesc;
	fake_control_cpu_reg_send_timeout = timeout;
	fake_control_cpu_reg_send_desc = desc;
	require(desc == &fake_control_cpu_reg_local);
	fake_control_cpu_reg_local.val = fake_control_cpu_reg_mutate_val;
	*do_free = fake_control_cpu_reg_send_do_free;
	return fake_control_cpu_reg_send_ret;
}

static void fake_control_cpu_reg_error_log(int stage, int cpu, int ret)
{
	fake_control_cpu_reg_error_calls++;
	fake_control_cpu_reg_error_stage = stage;
	fake_control_cpu_reg_error_cpu = cpu;
	fake_control_cpu_reg_error_ret = ret;
}

static void fake_control_cpu_reg_done_log(int op, int is_read, int cpu,
		unsigned long addr_ext, unsigned long val)
{
	fake_control_cpu_reg_done_calls++;
	fake_control_cpu_reg_done_op = op;
	fake_control_cpu_reg_done_is_read = is_read;
	fake_control_cpu_reg_done_cpu = cpu;
	fake_control_cpu_reg_done_addr_ext = addr_ext;
	fake_control_cpu_reg_done_val = val;
}

static int fake_control_validate_os(unsigned long os)
{
	fake_control_validate_os_calls++;
	fake_control_validate_os_seen = os;
	return fake_control_validate_os_ret;
}

static int fake_control_current_pid(void)
{
	fake_control_current_pid_calls++;
	return fake_control_current_pid_value;
}

static int fake_control_current_tid(void)
{
	fake_control_current_tid_calls++;
	return fake_control_current_tid_value;
}

static void *fake_control_current_task(void)
{
	fake_control_current_task_calls++;
	return &fake_control_task_token;
}

static void *fake_control_get_ppd(void *usrdata, int pid)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_get_ppd_calls++;
	fake_control_get_ppd_usrdata = usrdata;
	fake_control_get_ppd_pid = pid;
	if (fake_control_missing_ppd)
		return NULL;
	return &fake_control_ppd_token;
}

static void fake_control_put_ppd(void *ppd)
{
	require(ppd == &fake_control_ppd_token);
	fake_control_put_ppd_calls++;
	fake_control_put_ppd_seen = ppd;
	fake_control_request_put_ppd_order =
		++fake_control_request_release_order;
}

static void *fake_control_get_ptd(void *ppd, void *task)
{
	require(ppd == &fake_control_ppd_token);
	require(task == &fake_control_task_token);
	fake_control_get_ptd_calls++;
	fake_control_get_ptd_ppd = ppd;
	fake_control_get_ptd_task = task;
	if (fake_control_missing_ptd)
		return NULL;
	return &fake_control_ptd_token;
}

static void fake_control_put_ptd(void *ptd)
{
	require(ptd == &fake_control_ptd_token);
	fake_control_put_ptd_calls++;
	fake_control_put_ptd_seen = ptd;
	fake_control_request_put_ptd_order =
		++fake_control_request_release_order;
}

static void *fake_control_ptd_data(void *ptd)
{
	require(ptd == &fake_control_ptd_token);
	fake_control_ptd_data_calls++;
	if (fake_control_packet_missing)
		return NULL;
	return &fake_control_request_packet;
}

static int fake_control_ptd_tid(void *ptd)
{
	require(ptd == &fake_control_ptd_token);
	fake_control_ptd_tid_calls++;
	return fake_control_ptd_tid_value;
}

static int fake_control_ptd_refcount(void *ptd)
{
	require(ptd == &fake_control_ptd_token);
	fake_control_ptd_refcount_calls++;
	return fake_control_ptd_refcount_value;
}

static unsigned long fake_control_usrdata_os(void *usrdata)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_usrdata_os_calls++;
	return fake_control_usrdata_os_value;
}

static int fake_control_packet_ref(void *packet)
{
	struct mcctrl_ikc_scd_packet *p = packet;

	require(p == &fake_control_request_packet);
	fake_control_packet_ref_calls++;
	return p->body.traditional.ref;
}

static int fake_control_channel_read_cpu(void *usrdata, int packet_ref)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_channel_read_cpu_calls++;
	fake_control_channel_packet_ref = packet_ref;
	return fake_control_channel_read_cpu_result;
}

static void fake_control_request_cpu_error_log(int stage, unsigned long os,
		int pid, int tid)
{
	fake_control_request_log_error_calls++;
	fake_control_request_log_error_stage = stage;
	fake_control_request_log_error_os = os;
	fake_control_request_log_error_pid = pid;
	fake_control_request_log_error_tid = tid;
}

static void fake_control_request_cpu_ptd_log(int stage, int tid, void *ptd)
{
	require(ptd == &fake_control_ptd_token);
	fake_control_request_log_ptd_calls++;
	fake_control_request_log_ptd_stage = stage;
	fake_control_request_log_ptd_tid = tid;
	fake_control_request_log_ptd_seen = ptd;
	if (stage == 0) {
		fake_control_request_log_ptd_get_calls++;
	} else {
		fake_control_request_log_ptd_put_calls++;
		fake_control_request_log_ptd_put_order =
			++fake_control_request_release_order;
	}
}

static void fake_control_request_cpu_result_log(unsigned long os, int cpu)
{
	fake_control_request_log_result_calls++;
	fake_control_request_log_result_os = os;
	fake_control_request_log_result_cpu = cpu;
}

static int fake_control_request_cpu_call(unsigned long os, int *ret_cpu)
{
	return mcctrl_control_get_request_os_cpu_body_result(
		os, ret_cpu, fake_control_validate_os,
		fake_control_get_usrdata, fake_control_current_pid,
		fake_control_current_tid, fake_control_current_task,
		fake_control_get_ppd, fake_control_put_ppd,
		fake_control_get_ptd, fake_control_put_ptd,
		fake_control_ptd_data, fake_control_packet_ref,
		fake_control_channel_read_cpu,
		fake_control_request_cpu_error_log,
		fake_control_request_cpu_ptd_log,
		fake_control_request_cpu_result_log);
}

static int fake_control_copy_from_user(void *dst, const void *src,
		unsigned long size)
{
	fake_control_copy_from_calls++;
	fake_control_copy_from_dst = dst;
	fake_control_copy_from_src = src;
	fake_control_copy_from_size = size;
	if (fake_control_copy_from_fail ||
			(fake_control_copy_from_fail_at > 0 &&
			 fake_control_copy_from_calls == fake_control_copy_from_fail_at))
		return -1;
	memcpy(dst, src, size);
	return 0;
}

static int fake_control_copy_to_user(void *dst, const void *src,
		unsigned long size)
{
	fake_control_copy_to_calls++;
	fake_control_copy_to_dst = dst;
	fake_control_copy_to_src = src;
	fake_control_copy_to_size = size;
	if (fake_control_copy_to_calls <=
			(int)(sizeof(fake_control_copy_to_dst_history) /
			      sizeof(fake_control_copy_to_dst_history[0]))) {
		int index = fake_control_copy_to_calls - 1;

		fake_control_copy_to_dst_history[index] = dst;
		fake_control_copy_to_src_history[index] = src;
		fake_control_copy_to_size_history[index] = size;
	}
	if (fake_control_copy_to_fail ||
			(fake_control_copy_to_fail_at > 0 &&
			 fake_control_copy_to_calls == fake_control_copy_to_fail_at))
		return -1;
	memcpy(dst, src, size);
	return 0;
}

static int fake_control_get_order(unsigned long size)
{
	fake_control_get_order_calls++;
	fake_control_get_order_size = size;
	return fake_control_get_order_result;
}

static unsigned long fake_control_alloc_pages(int order)
{
	fake_control_alloc_pages_calls++;
	fake_control_alloc_pages_order = order;
	return fake_control_alloc_pages_result;
}

static void fake_control_free_pages(unsigned long addr, int order)
{
	fake_control_free_pages_calls++;
	fake_control_free_pages_addr = addr;
	fake_control_free_pages_order = order;
}

static unsigned long fake_control_region_virt_to_phys(void *ptr)
{
	fake_control_region_virt_to_phys_calls++;
	fake_control_region_virt_to_phys_ptr = ptr;
	return fake_control_region_virt_to_phys_result;
}

static unsigned long fake_control_region_phys_to_virt(unsigned long phys)
{
	fake_control_region_phys_to_virt_calls++;
	fake_control_region_phys_to_virt_phys = phys;
	return fake_control_region_phys_to_virt_result;
}

static void *fake_control_prepare_creds(void)
{
	fake_control_prepare_creds_calls++;
	if (fake_control_prepare_creds_fail)
		return NULL;
	fake_control_prepare_creds_order = ++fake_control_cred_order;
	return &fake_control_cred_token;
}

static void fake_control_cap_raise_admin(void *cred)
{
	require(cred == &fake_control_cred_token);
	fake_control_cap_raise_calls++;
	fake_control_cap_raise_order = ++fake_control_cred_order;
}

static const void *fake_control_override_creds(void *cred)
{
	require(cred == &fake_control_cred_token);
	fake_control_override_creds_calls++;
	fake_control_override_creds_order = ++fake_control_cred_order;
	return &fake_control_original_cred_token;
}

static void fake_control_revert_creds(const void *cred)
{
	require(cred == &fake_control_original_cred_token);
	fake_control_revert_creds_calls++;
	fake_control_revert_creds_order = ++fake_control_cred_order;
}

static void fake_control_put_cred(void *cred)
{
	require(cred == &fake_control_cred_token);
	fake_control_put_cred_calls++;
	fake_control_put_cred_order = ++fake_control_cred_order;
}

static int fake_control_mount(char *dev_name, char *dir_name,
		char *type_name, unsigned long flags, void *data)
{
	fake_control_mount_calls++;
	fake_control_mount_order = ++fake_control_cred_order;
	fake_control_mount_dev = dev_name;
	fake_control_mount_dir = dir_name;
	fake_control_mount_type = type_name;
	fake_control_mount_flags = flags;
	fake_control_mount_data = data;
	return fake_control_mount_ret;
}

static int fake_control_umount(char *dir_name, int flags)
{
	fake_control_umount_calls++;
	fake_control_umount_order = ++fake_control_cred_order;
	fake_control_umount_dir = dir_name;
	fake_control_umount_flags = flags;
	return fake_control_umount_ret;
}

static int fake_control_unshare(unsigned long flags)
{
	fake_control_unshare_calls++;
	fake_control_unshare_order = ++fake_control_cred_order;
	fake_control_unshare_flags = flags;
	return fake_control_unshare_ret;
}

static long fake_control_clear_pte_range(unsigned long start,
		unsigned long len)
{
	fake_control_clear_pte_calls++;
	fake_control_clear_pte_start = start;
	fake_control_clear_pte_len = len;
	return fake_control_clear_pte_ret;
}

static void fake_control_perf_set_num(void *usrdata, unsigned long value)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_perf_set_num_calls++;
	fake_control_perf_set_num_usrdata = usrdata;
	fake_control_perf_set_num_value = value;
}

static int fake_control_perf_event_num_fn(void *usrdata)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_perf_event_num_calls++;
	return fake_control_perf_event_num;
}

static void *fake_control_perf_alloc_set_desc(const void *arg, int index,
		unsigned int target_cntr, int *error)
{
	const struct ihk_perf_event_attr *attrs = arg;
	struct fake_control_perf_desc *desc;

	fake_control_perf_alloc_set_calls++;
	if (index == fake_control_perf_copy_fail_index) {
		*error = -22;
		return NULL;
	}
	if (index == fake_control_perf_alloc_set_fail_index) {
		*error = -12;
		return NULL;
	}

	desc = &fake_control_perf_descs[index];
	memset(desc, 0, sizeof(*desc));
	desc->ctrl_type = PERF_CTRL_SET;
	desc->target_cntr = target_cntr;
	desc->config = attrs[index].config;
	desc->exclude_user = attrs[index].exclude_user;
	desc->exclude_kernel = attrs[index].exclude_kernel;
	*error = 0;
	return desc;
}

static void *fake_control_perf_alloc_desc(unsigned long size)
{
	fake_control_perf_alloc_desc_calls++;
	fake_control_perf_alloc_desc_size = size;
	if (fake_control_perf_alloc_desc_fail)
		return NULL;
	memset(&fake_control_perf_descs[0], 0, sizeof(fake_control_perf_descs[0]));
	return &fake_control_perf_descs[0];
}

static void fake_control_perf_free_desc(void *desc)
{
	fake_control_perf_free_calls++;
	fake_control_perf_freed_desc = desc;
}

static void fake_control_perf_init_get_desc(void *desc,
		unsigned int target_cntr)
{
	struct fake_control_perf_desc *perf_desc = desc;

	fake_control_perf_init_get_calls++;
	memset(perf_desc, 0, sizeof(*perf_desc));
	perf_desc->ctrl_type = PERF_CTRL_GET;
	perf_desc->target_cntr = target_cntr;
}

static void fake_control_perf_init_mask_desc(void *desc, int ctrl_type,
		unsigned long cntr_mask)
{
	struct fake_control_perf_desc *perf_desc = desc;

	fake_control_perf_init_mask_calls++;
	fake_control_perf_init_mask_type = ctrl_type;
	fake_control_perf_init_mask_value = cntr_mask;
	memset(perf_desc, 0, sizeof(*perf_desc));
	perf_desc->ctrl_type = ctrl_type;
	perf_desc->target_cntr_mask = cntr_mask;
}

static int fake_control_perf_send_wait(unsigned long os, int cpu, void *desc,
		long timeout, int *need_free)
{
	struct fake_control_perf_desc *perf_desc = desc;

	fake_control_perf_send_calls++;
	fake_control_perf_send_os = os;
	fake_control_perf_send_cpu = cpu;
	fake_control_perf_send_timeout = timeout;
	*need_free = fake_control_perf_send_need_free;
	if (fake_control_perf_send_calls == fake_control_perf_send_fail_call)
		return fake_control_perf_send_ret;

	if (fake_control_perf_desc_err_after_cpu == cpu)
		perf_desc->err = fake_control_perf_desc_err_value;
	else
		perf_desc->err = 0;
	perf_desc->read_value = 10 + cpu + fake_control_perf_send_calls;
	return 0;
}

static int fake_control_perf_desc_err(void *desc)
{
	fake_control_perf_desc_err_calls++;
	return ((struct fake_control_perf_desc *)desc)->err;
}

static unsigned long fake_control_perf_desc_read_value(void *desc)
{
	fake_control_perf_desc_read_calls++;
	return ((struct fake_control_perf_desc *)desc)->read_value;
}

static int fake_control_perf_copy_to_user(void *dst, const void *src,
		unsigned long size)
{
	fake_control_copy_to_calls++;
	fake_control_copy_to_dst = dst;
	fake_control_copy_to_src = src;
	fake_control_copy_to_size = size;
	if (fake_control_perf_copyout_fail)
		return -1;
	memcpy(dst, src, size);
	return 0;
}

static void fake_control_perf_log(int stage)
{
	fake_control_perf_log_calls++;
	fake_control_perf_log_stage = stage;
}

static long fake_control_perf_destroy_disable(unsigned long os)
{
	fake_control_perf_disable_calls++;
	fake_control_perf_disable_os = os;
	return fake_control_perf_disable_ret;
}

static long fake_control_perf_num_zero(unsigned long os)
{
	fake_control_perf_num_zero_calls++;
	fake_control_perf_num_zero_os = os;
	return fake_control_perf_num_zero_ret;
}

static void *fake_control_getrusage_global(unsigned long os)
{
	fake_control_getrusage_calls++;
	fake_control_getrusage_os = os;
	return &fake_control_rusage_global;
}

static void *fake_control_getrusage_alloc(unsigned long size)
{
	fake_control_getrusage_alloc_calls++;
	fake_control_getrusage_alloc_size = size;
	if (fake_control_getrusage_alloc_fail)
		return NULL;
	memset(&fake_control_rusage_alloc_out, 0,
			sizeof(fake_control_rusage_alloc_out));
	return &fake_control_rusage_alloc_out;
}

static void fake_control_getrusage_free(void *ptr)
{
	fake_control_getrusage_free_calls++;
	fake_control_getrusage_freed = ptr;
}

static void fake_control_getrusage_log(int stage, unsigned long size,
		unsigned long max_size)
{
	fake_control_getrusage_log_calls++;
	fake_control_getrusage_log_stage = stage;
	fake_control_getrusage_log_size = size;
	fake_control_getrusage_log_max = max_size;
}

static long fake_control_getrusage_call(unsigned long os)
{
	return mcctrl_control_getrusage_body_result(
		os, &fake_control_rusage_desc,
		sizeof(struct mcctrl_ioctl_getrusage_desc),
		sizeof(struct fake_ihk_os_rusage), IHK_MAX_NUM_PGSIZES,
		IHK_MAX_NUM_NUMA_NODES, IHK_MAX_NUM_CPUS,
		fake_control_validate_os, fake_control_getrusage_global,
		fake_control_copy_from_user, fake_control_copy_to_user,
		fake_control_getrusage_alloc, fake_control_getrusage_free,
		fake_control_getrusage_log);
}

static void *fake_control_os_to_dev(unsigned long os)
{
	fake_control_os_to_dev_calls++;
	fake_control_os_to_dev_os = os;
	return (void *)0x1234abcdUL;
}

static unsigned long fake_control_map_memory(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == (void *)0x1234abcdUL);
	fake_control_map_memory_calls++;
	fake_control_map_memory_phys = phys;
	fake_control_map_memory_size = size;
	return phys + 0x1000UL;
}

static void *fake_control_map_virtual(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == (void *)0x1234abcdUL);
	fake_control_map_virtual_calls++;
	fake_control_map_virtual_phys = phys;
	fake_control_map_virtual_size = size;
	if (fake_control_map_virtual_fail)
		return NULL;
	if (size > sizeof(fake_control_remote_buf))
		return fake_control_uti_remote_ctx;
	return fake_control_remote_buf;
}

static void fake_control_unmap_virtual(void *dev, void *virt,
		unsigned long size)
{
	require(dev == (void *)0x1234abcdUL);
	fake_control_unmap_virtual_calls++;
	fake_control_unmap_virtual_ptr = virt;
	fake_control_unmap_virtual_size = size;
}

static void fake_control_unmap_memory(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == (void *)0x1234abcdUL);
	fake_control_unmap_memory_calls++;
	fake_control_unmap_memory_phys = phys;
	fake_control_unmap_memory_size = size;
}

static void fake_control_transfer_log(int stage)
{
	fake_control_transfer_log_calls++;
	fake_control_transfer_log_stage = stage;
}

static void fake_control_load_log(void *rpm, unsigned long size)
{
	fake_control_load_log_calls++;
	fake_control_load_log_rpm = rpm;
	fake_control_load_log_size = size;
}

static long fake_control_transfer_call(unsigned long os)
{
	return mcctrl_control_transfer_image_body_result(
		os, &fake_control_transfer_desc,
		sizeof(struct fake_control_remote_transfer),
		MCEXEC_UP_TRANSFER_TO_REMOTE, MCEXEC_UP_TRANSFER_FROM_REMOTE,
		fake_control_copy_from_user, fake_control_copy_to_user,
		fake_control_os_to_dev, fake_control_map_memory,
		fake_control_map_virtual, fake_control_unmap_virtual,
		fake_control_unmap_memory, fake_control_transfer_log);
}

static long fake_control_load_call(unsigned long os)
{
	return mcctrl_control_load_syscall_body_result(
		os, &fake_control_load_desc,
		sizeof(struct fake_control_syscall_load_desc),
		fake_control_copy_from_user, fake_control_copy_to_user,
		fake_control_os_to_dev, fake_control_map_memory,
		fake_control_map_virtual, fake_control_unmap_virtual,
		fake_control_unmap_memory, fake_control_load_log);
}

static void fake_control_return_syscall(unsigned long os, void *ppd,
		void *packet, long ret, int tid)
{
	require(ppd == &fake_control_ppd_token);
	require(packet == &fake_control_request_packet);
	fake_control_return_syscall_calls++;
	fake_control_return_syscall_os = os;
	fake_control_return_syscall_ppd = ppd;
	fake_control_return_syscall_packet = packet;
	fake_control_return_syscall_ret = ret;
	fake_control_return_syscall_tid = tid;
}

static void fake_control_release_packet(void *packet)
{
	require(packet == &fake_control_request_packet);
	fake_control_release_packet_calls++;
	fake_control_release_packet_seen = packet;
	fake_control_release_packet_order =
		++fake_control_request_release_order;
}

static void fake_control_ret_syscall_log(int stage, int pid, int tid)
{
	int index = fake_control_ret_log_calls++;

	require(index < 4);
	fake_control_ret_log_stage[index] = stage;
	fake_control_ret_log_pid[index] = pid;
	fake_control_ret_log_tid[index] = tid;
}

static void fake_control_terminate_thread_log(int stage, int pid, int tid,
		void *ptr, int value)
{
	int index = fake_control_terminate_log_calls++;

	require(index < 8);
	fake_control_terminate_log_stage[index] = stage;
	fake_control_terminate_log_pid[index] = pid;
	fake_control_terminate_log_tid[index] = tid;
	fake_control_terminate_log_ptr[index] = ptr;
	fake_control_terminate_log_value[index] = value;
}

static long fake_control_ret_syscall_call(unsigned long os)
{
	return mcctrl_control_ret_syscall_body_result(
		os, &fake_control_ret_desc,
		sizeof(struct fake_control_syscall_ret_desc),
		fake_control_copy_from_user, fake_control_get_usrdata,
		fake_control_current_pid, fake_control_current_tid,
		fake_control_current_task, fake_control_get_ppd,
		fake_control_put_ppd, fake_control_get_ptd,
		fake_control_put_ptd, fake_control_ptd_data,
		fake_control_os_to_dev, fake_control_map_memory,
		fake_control_map_virtual, fake_control_unmap_virtual,
		fake_control_unmap_memory, fake_control_return_syscall,
		fake_control_release_packet, fake_control_ret_syscall_log);
}

static long fake_control_terminate_thread_call(unsigned long os, int pid,
		int tid, long code)
{
	return mcctrl_control_terminate_thread_unsafe_body_result(
		os, pid, tid, code, &fake_control_task_token,
		fake_control_get_usrdata, fake_control_usrdata_os,
		fake_control_get_ppd, fake_control_put_ppd,
		fake_control_get_ptd, fake_control_put_ptd,
		fake_control_ptd_tid, fake_control_ptd_data,
		fake_control_ptd_refcount, fake_control_return_syscall,
		fake_control_release_packet,
		fake_control_terminate_thread_log);
}

static unsigned long fake_control_current_key(void)
{
	fake_control_current_key_calls++;
	return fake_control_current_key_value;
}

static void fake_control_uti_log(int stage)
{
	int index = fake_control_uti_log_calls++;

	require(index < 4);
	fake_control_uti_log_stage[index] = stage;
}

static long fake_control_uti_get_ctx_call(unsigned long os)
{
	return mcctrl_control_uti_get_ctx_body_result(
		os, &fake_control_uti_desc,
		sizeof(struct fake_control_uti_get_ctx_desc),
		sizeof(fake_control_uti_remote_ctx),
		offsetof(struct fake_control_uti_get_ctx_desc, key),
		fake_control_copy_from_user, fake_control_copy_to_user,
		fake_control_os_to_dev, fake_control_map_memory,
		fake_control_map_virtual, fake_control_unmap_virtual,
		fake_control_unmap_memory, fake_control_current_key,
		fake_control_uti_log);
}

static unsigned long fake_control_cred_phys_to_virt(unsigned long phys)
{
	fake_control_cred_phys_to_virt_calls++;
	fake_control_cred_phys_to_virt_phys = phys;
	return (unsigned long)fake_control_cred_kernel_values;
}

#define DEFINE_FAKE_CONTROL_CRED_VALUE(name, index) \
static int fake_control_current_##name(void) \
{ \
	fake_control_cred_calls[index]++; \
	return fake_control_cred_values[index]; \
}
DEFINE_FAKE_CONTROL_CRED_VALUE(uid, 0)
DEFINE_FAKE_CONTROL_CRED_VALUE(euid, 1)
DEFINE_FAKE_CONTROL_CRED_VALUE(suid, 2)
DEFINE_FAKE_CONTROL_CRED_VALUE(fsuid, 3)
DEFINE_FAKE_CONTROL_CRED_VALUE(gid, 4)
DEFINE_FAKE_CONTROL_CRED_VALUE(egid, 5)
DEFINE_FAKE_CONTROL_CRED_VALUE(sgid, 6)
DEFINE_FAKE_CONTROL_CRED_VALUE(fsgid, 7)
#undef DEFINE_FAKE_CONTROL_CRED_VALUE

static int fake_control_getcred_call(unsigned long phys)
{
	return mcctrl_control_getcred_body_result(
		phys, fake_control_cred_phys_to_virt,
		fake_control_current_uid, fake_control_current_euid,
		fake_control_current_suid, fake_control_current_fsuid,
		fake_control_current_gid, fake_control_current_egid,
		fake_control_current_sgid, fake_control_current_fsgid);
}

static int fake_control_getcredv_call(int *virt)
{
	return mcctrl_control_getcredv_body_result(
		virt, fake_control_copy_to_user,
		fake_control_current_uid, fake_control_current_euid,
		fake_control_current_suid, fake_control_current_fsuid,
		fake_control_current_gid, fake_control_current_egid,
		fake_control_current_sgid, fake_control_current_fsgid);
}

static void *fake_control_strncpy_alloc_page(void)
{
	fake_control_strncpy_alloc_calls++;
	if (fake_control_strncpy_alloc_fail)
		return NULL;
	memset(fake_control_strncpy_page, 0, sizeof(fake_control_strncpy_page));
	return fake_control_strncpy_page;
}

static void fake_control_strncpy_free_page(void *ptr)
{
	fake_control_strncpy_free_calls++;
	fake_control_strncpy_freed = ptr;
}

static long fake_control_strncpy_user_copy(void *dst, const void *src,
		unsigned long size)
{
	int index = fake_control_strncpy_calls++;
	long ret;
	unsigned long bytes;

	require(index < 4);
	fake_control_strncpy_src[index] = src;
	fake_control_strncpy_want[index] = size;
	ret = fake_control_strncpy_ret[index];
	if (ret < 0)
		return ret;
	bytes = (ret == (long)size) ? size : (unsigned long)ret + 1;
	memset(dst, 'a' + index, bytes);
	if (ret != (long)size)
		((char *)dst)[ret] = '\0';
	return ret;
}

static int fake_control_strncpy_copy_to_user(void *dst, const void *src,
		unsigned long size)
{
	fake_control_strncpy_copy_to_calls++;
	if (dst == fake_control_strncpy_desc_arg) {
		if (fake_control_strncpy_fail_desc_copy)
			return -1;
	} else if (fake_control_strncpy_fail_data_copy) {
		return -1;
	}
	memcpy(dst, src, size);
	return 0;
}

static long fake_control_strncpy_call(
		struct mcctrl_control_strncpy_desc *desc,
		unsigned long page_size)
{
	fake_control_strncpy_desc_arg = desc;
	return mcctrl_control_strncpy_from_user_body_result(
		desc, page_size, fake_control_copy_from_user,
		fake_control_strncpy_copy_to_user,
		fake_control_strncpy_alloc_page,
		fake_control_strncpy_free_page,
		fake_control_strncpy_user_copy);
}

static void fake_control_destroy_ppd_log(int stage, int pid, void *ppd)
{
	int index = fake_control_destroy_log_calls++;

	require(index < 4);
	fake_control_destroy_log_stage[index] = stage;
	fake_control_destroy_log_pid[index] = pid;
	fake_control_destroy_log_ppd[index] = ppd;
}

static int fake_control_destroy_ppd_call(unsigned long os, int pid)
{
	return mcctrl_control_destroy_ppd_body_result(
		os, pid, fake_control_get_usrdata, fake_control_get_ppd,
		fake_control_put_ppd, fake_control_destroy_ppd_log);
}

static int fake_control_drop_exec(unsigned long os, int pid)
{
	fake_control_drop_exec_calls++;
	fake_control_drop_exec_os = os;
	fake_control_drop_exec_pid = pid;
	return fake_control_drop_exec_ret;
}

static int fake_control_close_exec_call(unsigned long os, int pid)
{
	return mcctrl_control_close_exec_body_result(
		os, pid, fake_control_validate_os, fake_control_drop_exec);
}

static void *fake_control_new_info(unsigned long os, void *file)
{
	fake_control_new_info_calls++;
	fake_control_new_info_os = os;
	fake_control_new_info_file = file;
	if (fake_control_new_info_fail)
		return NULL;
	return &fake_control_new_info_token;
}

static void fake_control_set_info_pid(void *info, int pid)
{
	fake_control_set_info_pid_calls++;
	fake_control_set_info_pid_value = pid;
	((struct fake_control_new_info *)info)->pid = pid;
}

static void fake_control_register_release(void *file, void *info)
{
	fake_control_register_release_calls++;
	fake_control_register_release_file = file;
	fake_control_register_release_info = info;
}

static void fake_control_set_private(void *file, void *info)
{
	fake_control_set_private_calls++;
	fake_control_set_private_file = file;
	fake_control_set_private_info = info;
}

static long fake_control_newprocess_call(unsigned long os, void *file)
{
	return mcctrl_control_newprocess_body_result(
		os, file, fake_control_current_pid, fake_control_new_info,
		fake_control_set_info_pid, fake_control_register_release,
		fake_control_set_private);
}

static void *fake_control_start_alloc(unsigned long size)
{
	fake_control_start_alloc_calls++;
	fake_control_start_alloc_size = size;
	if (fake_control_start_alloc_fail)
		return NULL;
	memset(&fake_control_start_local_desc, 0,
			sizeof(fake_control_start_local_desc));
	return &fake_control_start_local_desc;
}

static void fake_control_start_free(void *ptr)
{
	fake_control_start_free_calls++;
	fake_control_start_freed = ptr;
}

static void *fake_control_start_get_private(void *file)
{
	fake_control_start_get_private_calls++;
	fake_control_start_private_file = file;
	return &fake_control_start_prev_info;
}

static void *fake_control_start_new_info_alloc(unsigned long os, void *file)
{
	fake_control_start_new_info_calls++;
	fake_control_start_new_info_os = os;
	fake_control_start_new_info_file = file;
	if (fake_control_start_new_info_fail)
		return NULL;
	return &fake_control_start_new_info;
}

static int fake_control_start_desc_cpu(void *desc)
{
	require(desc == &fake_control_start_local_desc);
	return ((struct fake_control_start_desc *)desc)->cpu;
}

static int fake_control_start_desc_pid(void *desc)
{
	require(desc == &fake_control_start_local_desc);
	return ((struct fake_control_start_desc *)desc)->pid;
}

static unsigned long fake_control_start_desc_user_start(void *desc)
{
	require(desc == &fake_control_start_local_desc);
	return ((struct fake_control_start_desc *)desc)->user_start;
}

static unsigned long fake_control_start_desc_user_end(void *desc)
{
	require(desc == &fake_control_start_local_desc);
	return ((struct fake_control_start_desc *)desc)->user_end;
}

static unsigned long fake_control_start_desc_rprocess(void *desc)
{
	require(desc == &fake_control_start_local_desc);
	return ((struct fake_control_start_desc *)desc)->rprocess;
}

static unsigned long fake_control_start_info_prepare(void *info)
{
	require(info == &fake_control_start_prev_info);
	fake_control_start_info_prepare_calls++;
	return ((struct fake_control_start_info *)info)->prepare_thread;
}

static void fake_control_start_set_info(void *info, int pid, int cpu,
		unsigned long user_start, unsigned long user_end,
		unsigned long prepare_thread)
{
	struct fake_control_start_info *start = info;

	require(info == &fake_control_start_new_info);
	fake_control_start_set_info_calls++;
	fake_control_start_set_info_prepare_thread = prepare_thread;
	start->pid = pid;
	start->cpu = cpu;
	start->user_start = user_start;
	start->user_end = user_end;
	start->prepare_thread = prepare_thread;
}

static void fake_control_start_set_recv(unsigned long os, int cpu)
{
	fake_control_start_set_recv_calls++;
	fake_control_start_set_recv_os = os;
	fake_control_start_set_recv_cpu = cpu;
}

static void fake_control_start_set_last(void *usrdata, unsigned long cpu)
{
	require(usrdata == &fake_control_usrdata_token);
	fake_control_start_set_last_calls++;
	fake_control_start_set_last_usrdata = usrdata;
	fake_control_start_set_last_cpu = cpu;
}

static int fake_control_start_send(unsigned long os, int cpu,
		unsigned long rprocess)
{
	fake_control_start_send_calls++;
	fake_control_start_send_os = os;
	fake_control_start_send_cpu = cpu;
	fake_control_start_send_rprocess = rprocess;
	return fake_control_start_send_ret;
}

static void fake_control_start_clear(void *info)
{
	require(info == &fake_control_start_new_info);
	fake_control_start_clear_calls++;
	((struct fake_control_start_info *)info)->prepare_thread = 0;
}

static void fake_control_start_log(int stage, int ret)
{
	int index = fake_control_start_log_calls++;

	require(index < 4);
	fake_control_start_log_stage[index] = stage;
	fake_control_start_log_ret[index] = ret;
}

static long fake_control_start_image_call(unsigned long os, void *file)
{
	return mcctrl_control_start_image_body_result(
		os, &fake_control_start_user_desc, file,
		sizeof(fake_control_start_user_desc),
		fake_control_copy_from_user, fake_control_start_alloc,
		fake_control_start_free, fake_control_get_usrdata,
		fake_control_start_get_private,
		fake_control_start_new_info_alloc, fake_control_start_desc_cpu,
		fake_control_start_desc_pid,
		fake_control_start_desc_user_start,
		fake_control_start_desc_user_end,
		fake_control_start_desc_rprocess,
		fake_control_start_info_prepare,
		fake_control_start_set_info,
		fake_control_register_release,
		fake_control_set_private,
		fake_control_start_set_recv,
		fake_control_start_set_last,
		fake_control_start_send,
		fake_control_start_clear,
		fake_control_start_log);
}

static void *fake_control_signal_alloc(unsigned long size)
{
	fake_control_signal_alloc_calls++;
	fake_control_signal_alloc_size = size;
	if (fake_control_signal_alloc_fail)
		return NULL;
	memset(&fake_control_signal_local_desc, 0,
			sizeof(fake_control_signal_local_desc));
	return &fake_control_signal_local_desc;
}

static void fake_control_signal_free(void *ptr)
{
	fake_control_signal_free_calls++;
	fake_control_signal_freed = ptr;
}

static unsigned long fake_control_signal_vtop(void *ptr)
{
	require(ptr == &fake_control_signal_local_desc.msig);
	fake_control_signal_vtop_calls++;
	fake_control_signal_vtop_ptr = ptr;
	return fake_control_signal_vtop_result;
}

static int fake_control_signal_send_wait(unsigned long os, int cpu,
		struct mcctrl_ikc_scd_packet *packet, long timeout,
		int *do_free, void *desc)
{
	require(desc == &fake_control_signal_local_desc);
	fake_control_signal_send_calls++;
	fake_control_signal_send_os = os;
	fake_control_signal_send_cpu = cpu;
	fake_control_signal_send_msg = packet->msg;
	fake_control_signal_send_ref = packet->body.traditional.ref;
	fake_control_signal_send_pid = packet->body.traditional.pid;
	fake_control_signal_send_arg = packet->body.traditional.arg;
	fake_control_signal_send_timeout = timeout;
	fake_control_signal_send_desc = desc;
	*do_free = fake_control_signal_send_do_free;
	return fake_control_signal_send_ret;
}

static void fake_control_signal_log(int stage, int ret)
{
	int index = fake_control_signal_log_calls++;

	require(index < 4);
	fake_control_signal_log_stage[index] = stage;
	fake_control_signal_log_ret[index] = ret;
}

static long fake_control_send_signal_call(unsigned long os)
{
	return mcctrl_control_send_signal_body_result(
		os, &fake_control_signal_user_desc,
		sizeof(fake_control_signal_user_desc),
		sizeof(fake_control_signal_local_desc),
		fake_control_copy_from_user, fake_control_signal_alloc,
		fake_control_signal_free, fake_control_get_usrdata,
		fake_control_signal_vtop, fake_control_signal_send_wait,
		fake_control_signal_log);
}

static long fake_control_pin_region_call(const struct prepare_dma_desc *desc)
{
	return mcctrl_control_pin_region_body_result(
		desc, 16, 12, fake_control_copy_from_user,
		fake_control_get_order, fake_control_alloc_pages,
		fake_control_region_virt_to_phys,
		fake_control_copy_to_user);
}

static long fake_control_free_region_call(const struct free_dma_desc *desc)
{
	return mcctrl_control_free_region_body_result(
		desc, 16, 12, fake_control_copy_from_user,
		fake_control_get_order, fake_control_region_phys_to_virt,
		fake_control_free_pages);
}

static long fake_control_sys_mount_call(const struct sys_mount_desc *desc)
{
	return mcctrl_control_sys_mount_body_result(
		desc, fake_control_copy_from_user,
		fake_control_prepare_creds,
		fake_control_cap_raise_admin,
		fake_control_override_creds, fake_control_mount,
		fake_control_revert_creds, fake_control_put_cred);
}

static long fake_control_sys_umount_call(const struct sys_umount_desc *desc,
		int force)
{
	return mcctrl_control_sys_umount_body_result(
		desc, force, fake_control_copy_from_user,
		fake_control_prepare_creds,
		fake_control_cap_raise_admin,
		fake_control_override_creds, fake_control_umount,
		fake_control_revert_creds, fake_control_put_cred);
}

static long fake_control_sys_unshare_call(
		const struct sys_unshare_desc *desc)
{
	return mcctrl_control_sys_unshare_body_result(
		desc, fake_control_copy_from_user,
		fake_control_prepare_creds,
		fake_control_cap_raise_admin,
		fake_control_override_creds, fake_control_unshare,
		fake_control_revert_creds, fake_control_put_cred);
}

static long fake_control_release_user_space_call(
		const struct release_user_space_desc *desc)
{
	return mcctrl_control_release_user_space_body_result(
		desc, fake_control_copy_from_user,
		fake_control_clear_pte_range);
}

static long fake_control_perf_num_call(unsigned long os, unsigned long value)
{
	return mcctrl_control_perf_num_body_result(
		os, value, fake_control_validate_os,
		fake_control_get_usrdata, fake_control_perf_set_num,
		fake_control_log_error);
}

static long fake_control_perf_destroy_call(unsigned long os)
{
	return mcctrl_control_perf_destroy_body_result(
		os, fake_control_perf_destroy_disable,
		fake_control_perf_num_zero);
}

static long fake_control_perf_set_call(unsigned long os)
{
	return mcctrl_control_perf_set_body_result(
		os, fake_control_perf_attrs, 0, sizeof(struct fake_control_perf_desc),
		fake_control_validate_os, fake_control_get_usrdata,
		fake_control_perf_event_num_fn, fake_control_get_cpu_info,
		fake_control_cpu_info_n_cpus, fake_control_perf_free_desc,
		fake_control_perf_alloc_set_desc, fake_control_perf_send_wait,
		fake_control_perf_desc_err, fake_control_perf_set_num,
		fake_control_perf_log);
}

static long fake_control_perf_get_call(unsigned long os)
{
	return mcctrl_control_perf_get_body_result(
		os, fake_control_perf_user_values, 0,
		sizeof(struct fake_control_perf_desc), sizeof(unsigned long),
		fake_control_validate_os, fake_control_get_usrdata,
		fake_control_perf_event_num_fn, fake_control_get_cpu_info,
		fake_control_cpu_info_n_cpus, fake_control_perf_alloc_desc,
		fake_control_perf_free_desc, fake_control_perf_init_get_desc,
		fake_control_perf_send_wait, fake_control_perf_desc_err,
		fake_control_perf_desc_read_value,
		fake_control_perf_copy_to_user, fake_control_perf_log);
}

static long fake_control_perf_enable_disable_call(unsigned long os,
		int ctrl_type)
{
	return mcctrl_control_perf_enable_disable_body_result(
		os, ctrl_type, 0, sizeof(struct fake_control_perf_desc),
		fake_control_validate_os, fake_control_get_usrdata,
		fake_control_perf_event_num_fn, fake_control_get_cpu_info,
		fake_control_cpu_info_n_cpus, fake_control_perf_alloc_desc,
		fake_control_perf_free_desc,
		fake_control_perf_init_mask_desc,
		fake_control_perf_send_wait, fake_control_perf_desc_err,
		fake_control_perf_log);
}

static void fake_driver_note(char code)
{
	if (fake_driver_order_len < (int)sizeof(fake_driver_order) - 1) {
		fake_driver_order[fake_driver_order_len++] = code;
		fake_driver_order[fake_driver_order_len] = '\0';
	}
}

static void reset_fake_driver(void)
{
	memset(fake_driver_os_slots, 0, sizeof(fake_driver_os_slots));
	memset(fake_driver_symbol_values, 0, sizeof(fake_driver_symbol_values));
	memset(fake_driver_published_symbols, 0,
			sizeof(fake_driver_published_symbols));
	for (int i = 0; i < 8; i++)
		fake_driver_symbol_values[i] =
			(void *)(0xd000UL + (unsigned long)i * 0x100UL);
	fake_driver_find_result = (void *)0xb007UL;
	fake_driver_control_calls = 0;
	fake_driver_control_request = 0;
	fake_driver_control_os = 0;
	fake_driver_control_arg = 0;
	fake_driver_control_file = 0;
	fake_driver_get_os_calls = 0;
	fake_driver_set_os_calls = 0;
	fake_driver_last_index = -1;
	fake_driver_last_os = NULL;
	fake_driver_prepare_calls = 0;
	fake_driver_prepare_ret = 0;
	fake_driver_copy_proto_calls = 0;
	fake_driver_set_kernel_calls = 0;
	fake_driver_set_kernel_ret = 0;
	fake_driver_register_user_calls = 0;
	fake_driver_register_user_ret = 0;
	fake_driver_procfs_init_calls = 0;
	fake_driver_clear_kernel_calls = 0;
	fake_driver_destroy_calls = 0;
	fake_driver_pager_cleanup_calls = 0;
	fake_driver_sysfs_cleanup_calls = 0;
	fake_driver_free_topology_calls = 0;
	fake_driver_unregister_user_calls = 0;
	fake_driver_procfs_exit_calls = 0;
	fake_driver_log_stage = -1;
	fake_driver_log_index = -1;
	fake_driver_log_calls = 0;
	fake_driver_lookup_calls = 0;
	fake_driver_publish_calls = 0;
	fake_driver_warn_calls = 0;
	fake_driver_arch_calls = 0;
	fake_driver_arch_ret = 0;
	fake_driver_symbol_missing = -1;
	fake_driver_syscall_init_calls = 0;
	fake_driver_binfmt_init_calls = 0;
	fake_driver_tofu_hash_calls = 0;
	fake_driver_symbols_init_calls = 0;
	fake_driver_symbols_init_ret = 0;
	fake_driver_tofu_hijack_calls = 0;
	fake_driver_register_notifier_calls = 0;
	fake_driver_register_notifier_ret = 0;
	fake_driver_binfmt_exit_calls = 0;
	fake_driver_deregister_notifier_calls = 0;
	fake_driver_deregister_notifier_ret = 0;
	fake_driver_uti_finalize_calls = 0;
	fake_driver_tofu_restore_calls = 0;
	memset(fake_driver_order, 0, sizeof(fake_driver_order));
	fake_driver_order_len = 0;
}

static long fake_driver_control(unsigned long os, unsigned int request,
		unsigned long arg, unsigned long file)
{
	fake_driver_control_calls++;
	fake_driver_control_os = os;
	fake_driver_control_request = request;
	fake_driver_control_arg = arg;
	fake_driver_control_file = file;
	return 0x660000L + request;
}

static void *fake_driver_get_os(int index)
{
	fake_driver_get_os_calls++;
	fake_driver_last_index = index;
	return fake_driver_os_slots[index];
}

static void fake_driver_set_os(int index, void *os)
{
	fake_driver_set_os_calls++;
	fake_driver_last_index = index;
	fake_driver_last_os = os;
	fake_driver_os_slots[index] = os;
}

static void *fake_driver_find_os(int index)
{
	fake_driver_last_index = index;
	return fake_driver_find_result;
}

static int fake_driver_prepare_channels(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_prepare_calls++;
	return fake_driver_prepare_ret;
}

static void fake_driver_copy_user_call_proto(int index)
{
	fake_driver_copy_proto_calls++;
	fake_driver_last_index = index;
}

static int fake_driver_set_kernel_handlers(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_set_kernel_calls++;
	return fake_driver_set_kernel_ret;
}

static int fake_driver_register_user_handlers(void *os, int index)
{
	require(os == fake_driver_find_result);
	fake_driver_register_user_calls++;
	fake_driver_last_index = index;
	return fake_driver_register_user_ret;
}

static void fake_driver_procfs_init(int index)
{
	fake_driver_procfs_init_calls++;
	fake_driver_last_index = index;
}

static void fake_driver_clear_kernel_handlers(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_clear_kernel_calls++;
}

static void fake_driver_destroy_channels(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_destroy_calls++;
}

static void fake_driver_pager_cleanup(void)
{
	fake_driver_pager_cleanup_calls++;
}

static void fake_driver_sysfs_cleanup(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_sysfs_cleanup_calls++;
}

static void fake_driver_free_topology_info(void *os)
{
	require(os == fake_driver_find_result);
	fake_driver_free_topology_calls++;
}

static void fake_driver_unregister_user_handlers(void *os, int index)
{
	require(os == fake_driver_find_result);
	fake_driver_unregister_user_calls++;
	fake_driver_last_index = index;
}

static void fake_driver_procfs_exit(int index)
{
	fake_driver_procfs_exit_calls++;
	fake_driver_last_index = index;
}

static void fake_driver_log(int stage, int index)
{
	fake_driver_log_calls++;
	fake_driver_log_stage = stage;
	fake_driver_log_index = index;
}

#define DEFINE_FAKE_DRIVER_LOOKUP(id) \
static void *fake_driver_lookup_##id(void) \
{ \
	fake_driver_lookup_calls++; \
	if (fake_driver_symbol_missing == id) \
		return NULL; \
	return fake_driver_symbol_values[id]; \
} \
static void fake_driver_publish_##id(void *ptr) \
{ \
	fake_driver_publish_calls++; \
	fake_driver_published_symbols[id] = ptr; \
}
DEFINE_FAKE_DRIVER_LOOKUP(0)
DEFINE_FAKE_DRIVER_LOOKUP(1)
DEFINE_FAKE_DRIVER_LOOKUP(2)
DEFINE_FAKE_DRIVER_LOOKUP(3)
DEFINE_FAKE_DRIVER_LOOKUP(4)
DEFINE_FAKE_DRIVER_LOOKUP(5)
DEFINE_FAKE_DRIVER_LOOKUP(6)
DEFINE_FAKE_DRIVER_LOOKUP(7)

static int fake_driver_warn_missing(void *ptr)
{
	fake_driver_warn_calls++;
	return ptr == NULL;
}

static int fake_driver_arch_symbols_init(void)
{
	fake_driver_arch_calls++;
	return fake_driver_arch_ret;
}

static const struct mcctrl_driver_boot_ops fake_driver_boot_ops = {
	.find_os = fake_driver_find_os,
	.set_os = fake_driver_set_os,
	.prepare_channels = fake_driver_prepare_channels,
	.copy_user_call_proto = fake_driver_copy_user_call_proto,
	.set_kernel_handlers = fake_driver_set_kernel_handlers,
	.register_user_handlers = fake_driver_register_user_handlers,
	.procfs_init = fake_driver_procfs_init,
	.clear_kernel_handlers = fake_driver_clear_kernel_handlers,
	.destroy_channels = fake_driver_destroy_channels,
	.log = fake_driver_log,
};

static const struct mcctrl_driver_shutdown_ops fake_driver_shutdown_ops = {
	.get_os = fake_driver_get_os,
	.set_os = fake_driver_set_os,
	.pager_cleanup = fake_driver_pager_cleanup,
	.sysfs_cleanup = fake_driver_sysfs_cleanup,
	.free_topology_info = fake_driver_free_topology_info,
	.unregister_user_handlers = fake_driver_unregister_user_handlers,
	.clear_kernel_handlers = fake_driver_clear_kernel_handlers,
	.destroy_channels = fake_driver_destroy_channels,
	.procfs_exit = fake_driver_procfs_exit,
	.log = fake_driver_log,
};

static const struct mcctrl_driver_symbols_ops fake_driver_symbols_ops = {
	.lookup_mount = fake_driver_lookup_0,
	.set_mount = fake_driver_publish_0,
	.lookup_umount = fake_driver_lookup_1,
	.set_umount = fake_driver_publish_1,
	.lookup_unshare = fake_driver_lookup_2,
	.set_unshare = fake_driver_publish_2,
	.lookup_sched_setaffinity = fake_driver_lookup_3,
	.set_sched_setaffinity = fake_driver_publish_3,
	.lookup_sched_setscheduler_nocheck = fake_driver_lookup_4,
	.set_sched_setscheduler_nocheck = fake_driver_publish_4,
	.lookup_readlinkat = fake_driver_lookup_5,
	.set_readlinkat = fake_driver_publish_5,
	.lookup_zap_page_range = fake_driver_lookup_6,
	.set_zap_page_range = fake_driver_publish_6,
	.lookup_hugetlbfs_inode_operations = fake_driver_lookup_7,
	.set_hugetlbfs_inode_operations = fake_driver_publish_7,
	.warn_missing = fake_driver_warn_missing,
	.arch_symbols_init = fake_driver_arch_symbols_init,
};

static void fake_driver_syscall_init(void)
{
	fake_driver_syscall_init_calls++;
	fake_driver_note('s');
}

static void fake_driver_binfmt_init(void)
{
	fake_driver_binfmt_init_calls++;
	fake_driver_note('b');
}

static void fake_driver_tofu_hash_init(void)
{
	fake_driver_tofu_hash_calls++;
	fake_driver_note('h');
}

static int fake_driver_symbols_init(void)
{
	fake_driver_symbols_init_calls++;
	fake_driver_note('y');
	return fake_driver_symbols_init_ret;
}

static void fake_driver_tofu_hijack(void)
{
	fake_driver_tofu_hijack_calls++;
	fake_driver_note('j');
}

static int fake_driver_register_notifier(void)
{
	fake_driver_register_notifier_calls++;
	fake_driver_note('r');
	return fake_driver_register_notifier_ret;
}

static void fake_driver_binfmt_exit(void)
{
	fake_driver_binfmt_exit_calls++;
	fake_driver_note('x');
}

static int fake_driver_deregister_notifier(void)
{
	fake_driver_deregister_notifier_calls++;
	fake_driver_note('d');
	return fake_driver_deregister_notifier_ret;
}

static void fake_driver_uti_finalize(void)
{
	fake_driver_uti_finalize_calls++;
	fake_driver_note('u');
}

static void fake_driver_tofu_restore(void)
{
	fake_driver_tofu_restore_calls++;
	fake_driver_note('t');
}

static const struct mcctrl_driver_module_ops fake_driver_module_ops = {
	.syscall_init = fake_driver_syscall_init,
	.set_os = fake_driver_set_os,
	.binfmt_init = fake_driver_binfmt_init,
	.tofu_hash_init = fake_driver_tofu_hash_init,
	.symbols_init = fake_driver_symbols_init,
	.tofu_hijack = fake_driver_tofu_hijack,
	.register_notifier = fake_driver_register_notifier,
	.binfmt_exit = fake_driver_binfmt_exit,
	.deregister_notifier = fake_driver_deregister_notifier,
	.uti_finalize = fake_driver_uti_finalize,
	.tofu_restore = fake_driver_tofu_restore,
	.log = fake_driver_log,
};

static void reset_fake_in_kernel(void)
{
	fake_in_kernel_pager_irq_calls = 0;
	fake_in_kernel_pager_calls = 0;
	fake_in_kernel_clear_calls = 0;
	fake_in_kernel_remap_calls = 0;
	fake_in_kernel_zero_calls = 0;
	fake_in_kernel_writecore_calls = 0;
	fake_in_kernel_sched_same_calls = 0;
	fake_in_kernel_sched_root_calls = 0;
	fake_in_kernel_tofu_close_calls = 0;
	fake_in_kernel_return_calls = 0;
	fake_in_kernel_release_calls = 0;
	fake_in_kernel_last_os = 0;
	fake_in_kernel_last_number = 0;
	fake_in_kernel_last_arg0 = 0;
	fake_in_kernel_last_arg1 = 0;
	fake_in_kernel_last_arg2 = 0;
	fake_in_kernel_last_arg3 = 0;
	fake_in_kernel_last_int = 0;
	fake_in_kernel_last_ret = 0;
	fake_in_kernel_last_stid = 0;
	fake_in_kernel_last_packet = NULL;
	fake_in_kernel_pager_irq_ret = 0x7100;
	fake_in_kernel_pager_ret = 0x7200;
	fake_in_kernel_clear_ret = 0x7300;
	fake_in_kernel_remap_ret = 0x7400;
	fake_in_kernel_writecore_ret = 0x7500;
	fake_in_kernel_sched_same_ret = 0x7600;
	fake_in_kernel_sched_root_ret = 0x7700;
}

static void fake_in_kernel_prepare_packet(struct mcctrl_ikc_scd_packet *packet,
		unsigned long number)
{
	memset(packet, 0, sizeof(*packet));
	packet->body.traditional.req.number = number;
}

static long fake_in_kernel_pager_irq(unsigned long os,
		struct mcctrl_syscall_request *req)
{
	fake_in_kernel_pager_irq_calls++;
	fake_in_kernel_last_os = os;
	fake_in_kernel_last_number = req->number;
	fake_in_kernel_last_arg0 = req->args[0];
	return fake_in_kernel_pager_irq_ret;
}

static long fake_in_kernel_pager(unsigned long os,
		struct mcctrl_syscall_request *req)
{
	fake_in_kernel_pager_calls++;
	fake_in_kernel_last_os = os;
	fake_in_kernel_last_number = req->number;
	fake_in_kernel_last_arg0 = req->args[0];
	return fake_in_kernel_pager_ret;
}

static long fake_in_kernel_clear(unsigned long start, unsigned long len)
{
	fake_in_kernel_clear_calls++;
	fake_in_kernel_last_arg0 = start;
	fake_in_kernel_last_arg1 = len;
	return fake_in_kernel_clear_ret;
}

static long fake_in_kernel_remap(unsigned long start, unsigned long len,
		int prot)
{
	fake_in_kernel_remap_calls++;
	fake_in_kernel_last_arg0 = start;
	fake_in_kernel_last_arg1 = len;
	fake_in_kernel_last_int = prot;
	return fake_in_kernel_remap_ret;
}

static void fake_in_kernel_zero(unsigned long arg)
{
	fake_in_kernel_zero_calls++;
	fake_in_kernel_last_arg0 = arg;
}

static long fake_in_kernel_writecore(unsigned long os,
		unsigned long rcoretable, int chunks, unsigned long offset,
		unsigned long filename)
{
	fake_in_kernel_writecore_calls++;
	fake_in_kernel_last_os = os;
	fake_in_kernel_last_arg0 = rcoretable;
	fake_in_kernel_last_int = chunks;
	fake_in_kernel_last_arg2 = offset;
	fake_in_kernel_last_arg3 = filename;
	return fake_in_kernel_writecore_ret;
}

static long fake_in_kernel_sched_same(int pid)
{
	fake_in_kernel_sched_same_calls++;
	fake_in_kernel_last_int = pid;
	return fake_in_kernel_sched_same_ret;
}

static long fake_in_kernel_sched_root(int unused)
{
	fake_in_kernel_sched_root_calls++;
	fake_in_kernel_last_int = unused;
	return fake_in_kernel_sched_root_ret;
}

static long fake_in_kernel_tofu_close(unsigned long os,
		struct mcctrl_syscall_request *req)
{
	fake_in_kernel_tofu_close_calls++;
	fake_in_kernel_last_os = os;
	fake_in_kernel_last_arg0 = req->args[0];
	return 0;
}

static void fake_in_kernel_return(unsigned long os,
		struct mcctrl_ikc_scd_packet *packet, long ret, int stid)
{
	fake_in_kernel_return_calls++;
	fake_in_kernel_last_os = os;
	fake_in_kernel_last_packet = packet;
	fake_in_kernel_last_ret = ret;
	fake_in_kernel_last_stid = stid;
}

static void fake_in_kernel_release(struct mcctrl_ikc_scd_packet *packet)
{
	fake_in_kernel_release_calls++;
	fake_in_kernel_last_packet = packet;
}

static const struct mcctrl_in_kernel_syscall_ops fake_in_kernel_ops = {
	.pager_irq = fake_in_kernel_pager_irq,
	.pager = fake_in_kernel_pager,
	.clear_pte = fake_in_kernel_clear,
	.remap = fake_in_kernel_remap,
	.zero_pages = fake_in_kernel_zero,
	.writecore = fake_in_kernel_writecore,
	.sched_same_owner = fake_in_kernel_sched_same,
	.sched_root = fake_in_kernel_sched_root,
	.tofu_close = fake_in_kernel_tofu_close,
	.return_syscall = fake_in_kernel_return,
	.release_packet = fake_in_kernel_release,
};

static void reset_fake_pager(void)
{
	fake_pager_create_calls = 0;
	fake_pager_release_calls = 0;
	fake_pager_read_calls = 0;
	fake_pager_write_calls = 0;
	fake_pager_map_calls = 0;
	fake_pager_pfn_calls = 0;
	fake_pager_unmap_calls = 0;
	fake_pager_mlock_calls = 0;
	fake_pager_unknown_calls = 0;
	fake_pager_last_os = 0;
	fake_pager_last_request = 0;
	fake_pager_last_arg1 = 0;
	fake_pager_last_arg2 = 0;
	fake_pager_last_arg3 = 0;
	fake_pager_last_arg4 = 0;
	fake_pager_last_arg5 = 0;
	fake_pager_last_int = 0;
	fake_pager_create_ret = 0x8101;
	fake_pager_release_ret = 0x8102;
	fake_pager_read_ret = 0x8103;
	fake_pager_write_ret = 0x8104;
	fake_pager_map_ret = 0x8105;
	fake_pager_pfn_ret = 0x8106;
	fake_pager_unmap_ret = 0x8107;
	fake_pager_mlock_ret = 0x8108;
}

static void fake_pager_prepare_req(struct mcctrl_syscall_request *req,
		unsigned long request)
{
	memset(req, 0, sizeof(*req));
	req->args[0] = request;
}

static long fake_pager_create(unsigned long os, int fd,
		unsigned long result_pa)
{
	fake_pager_create_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = (unsigned long)fd;
	fake_pager_last_arg2 = result_pa;
	return fake_pager_create_ret;
}

static long fake_pager_release(unsigned long os, unsigned long handle,
		unsigned long sref)
{
	fake_pager_release_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = handle;
	fake_pager_last_arg2 = sref;
	return fake_pager_release_ret;
}

static long fake_pager_read(unsigned long os, unsigned long handle,
		unsigned long off, unsigned long size, unsigned long rpa)
{
	fake_pager_read_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = handle;
	fake_pager_last_arg2 = off;
	fake_pager_last_arg3 = size;
	fake_pager_last_arg4 = rpa;
	return fake_pager_read_ret;
}

static long fake_pager_write(unsigned long os, unsigned long handle,
		unsigned long off, unsigned long size, unsigned long rpa)
{
	fake_pager_write_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = handle;
	fake_pager_last_arg2 = off;
	fake_pager_last_arg3 = size;
	fake_pager_last_arg4 = rpa;
	return fake_pager_write_ret;
}

static long fake_pager_map(unsigned long os, int fd, unsigned long len,
		unsigned long off, unsigned long result_rpa, int prot)
{
	fake_pager_map_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = (unsigned long)fd;
	fake_pager_last_arg2 = len;
	fake_pager_last_arg3 = off;
	fake_pager_last_arg4 = result_rpa;
	fake_pager_last_int = prot;
	return fake_pager_map_ret;
}

static long fake_pager_pfn(unsigned long os, unsigned long handle,
		unsigned long off, unsigned long ppfn_rpa)
{
	fake_pager_pfn_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = handle;
	fake_pager_last_arg2 = off;
	fake_pager_last_arg3 = ppfn_rpa;
	return fake_pager_pfn_ret;
}

static long fake_pager_unmap(unsigned long os, unsigned long handle)
{
	fake_pager_unmap_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = handle;
	return fake_pager_unmap_ret;
}

static long fake_pager_mlock_list(unsigned long os, unsigned long start,
		unsigned long end, unsigned long addr, int nent)
{
	fake_pager_mlock_calls++;
	fake_pager_last_os = os;
	fake_pager_last_arg1 = start;
	fake_pager_last_arg2 = end;
	fake_pager_last_arg3 = addr;
	fake_pager_last_int = nent;
	return fake_pager_mlock_ret;
}

static void fake_pager_unknown(unsigned long request, long ret)
{
	fake_pager_unknown_calls++;
	fake_pager_last_request = request;
	fake_pager_last_arg1 = (unsigned long)ret;
}

static const struct mcctrl_pager_call_ops fake_pager_ops = {
	.create = fake_pager_create,
	.release = fake_pager_release,
	.read = fake_pager_read,
	.write = fake_pager_write,
	.map = fake_pager_map,
	.pfn = fake_pager_pfn,
	.unmap = fake_pager_unmap,
	.mlock_list = fake_pager_mlock_list,
	.unknown = fake_pager_unknown,
};

static void reset_fake_remote_pf(void)
{
	fake_remote_pf_send_calls = 0;
	fake_remote_pf_log_calls = 0;
	fake_remote_pf_last_stage = 0;
	fake_remote_pf_last_cpu = 0;
	fake_remote_pf_last_pid = 0;
	fake_remote_pf_last_error = 0;
	fake_remote_pf_last_os = 0;
	fake_remote_pf_last_addr = 0;
	fake_remote_pf_last_reason = 0;
	fake_remote_pf_last_packet = NULL;
	fake_remote_pf_send_ret = 0;
}

static int fake_remote_pf_send(unsigned long os, int cpu,
		struct mcctrl_ikc_scd_packet *packet)
{
	fake_remote_pf_send_calls++;
	fake_remote_pf_last_os = os;
	fake_remote_pf_last_cpu = cpu;
	fake_remote_pf_last_packet = packet;
	return fake_remote_pf_send_ret;
}

static void fake_remote_pf_log(int stage, int pid, int error,
		unsigned long fault_addr, unsigned long reason)
{
	fake_remote_pf_log_calls++;
	fake_remote_pf_last_stage = stage;
	fake_remote_pf_last_pid = pid;
	fake_remote_pf_last_error = error;
	fake_remote_pf_last_addr = fault_addr;
	fake_remote_pf_last_reason = reason;
}

static void reset_fake_user_space(void)
{
	memset(fake_user_vmas, 0, sizeof(fake_user_vmas));
	fake_user_vma_count = 0;
	fake_user_space_lock_calls = 0;
	fake_user_space_unlock_calls = 0;
	fake_user_space_find_calls = 0;
	fake_user_space_last_find = 0;
	fake_user_space_set_rw_calls = 0;
	fake_user_space_zap_ptes_calls = 0;
	fake_user_space_zap_range_calls = 0;
	fake_user_space_munmap_calls = 0;
	fake_user_space_log_calls = 0;
	fake_user_space_zap_ptes_ret = 0;
	fake_user_space_munmap_ret = 0;
	fake_user_space_last_start = 0;
	fake_user_space_last_len = 0;
	fake_user_space_munmap_total = 0;
	fake_user_space_last_error = 0;
}

static void fake_user_space_read_lock(void)
{
	fake_user_space_lock_calls++;
}

static void fake_user_space_read_unlock(void)
{
	fake_user_space_unlock_calls++;
}

static void *fake_user_space_find_vma(unsigned long addr)
{
	fake_user_space_find_calls++;
	fake_user_space_last_find = addr;
	for (int i = 0; i < fake_user_vma_count; i++) {
		if (fake_user_vmas[i].end > addr)
			return &fake_user_vmas[i];
	}
	return NULL;
}

static unsigned long fake_user_space_vma_start(void *vma)
{
	return ((struct fake_user_vma *)vma)->start;
}

static unsigned long fake_user_space_vma_end(void *vma)
{
	return ((struct fake_user_vma *)vma)->end;
}

static unsigned long fake_user_space_vma_flags(void *vma)
{
	return ((struct fake_user_vma *)vma)->flags;
}

static void fake_user_space_set_rw_exec(void *vma)
{
	(void)vma;
	fake_user_space_set_rw_calls++;
}

static int fake_user_space_zap_vma_ptes(void *vma, unsigned long addr,
		unsigned long len)
{
	(void)vma;
	fake_user_space_zap_ptes_calls++;
	fake_user_space_last_start = addr;
	fake_user_space_last_len = len;
	return fake_user_space_zap_ptes_ret;
}

static void fake_user_space_zap_page_range(void *vma, unsigned long addr,
		unsigned long len)
{
	(void)vma;
	fake_user_space_zap_range_calls++;
	fake_user_space_last_start = addr;
	fake_user_space_last_len = len;
}

static int fake_user_space_munmap(unsigned long addr, unsigned long len)
{
	fake_user_space_munmap_calls++;
	fake_user_space_last_start = addr;
	fake_user_space_last_len = len;
	fake_user_space_munmap_total += len;
	return fake_user_space_munmap_ret;
}

static void fake_user_space_log_error(int error)
{
	fake_user_space_log_calls++;
	fake_user_space_last_error = error;
}

static const struct mcctrl_clear_pte_range_ops fake_clear_pte_ops = {
	.read_lock = fake_user_space_read_lock,
	.read_unlock = fake_user_space_read_unlock,
	.find_vma = fake_user_space_find_vma,
	.vma_start = fake_user_space_vma_start,
	.vma_end = fake_user_space_vma_end,
	.vma_flags = fake_user_space_vma_flags,
	.set_rw_exec = fake_user_space_set_rw_exec,
	.zap_vma_ptes = fake_user_space_zap_vma_ptes,
	.zap_page_range = fake_user_space_zap_page_range,
};

static const struct mcctrl_user_space_release_ops fake_release_space_ops = {
	.find_vma = fake_user_space_find_vma,
	.vma_start = fake_user_space_vma_start,
	.vma_end = fake_user_space_vma_end,
	.munmap = fake_user_space_munmap,
	.log_error = fake_user_space_log_error,
};

static void reset_fake_work(void)
{
	memset(&fake_work, 0, sizeof(fake_work));
	fake_alloc_calls = 0;
	fake_fail_alloc = 0;
	fake_alloc_size = 0;
	fake_init_schedule_calls = 0;
	fake_scheduled_work = NULL;
	fake_alloc_failed_calls = 0;
	fake_last_os = NULL;
	fake_add_calls = 0;
	fake_delete_calls = 0;
	fake_last_osnum = 0;
	fake_last_pid = 0;
	fake_last_tid = 0;
	fake_os_to_dev_calls = 0;
	fake_last_dev = NULL;
	fake_map_memory_calls = 0;
	fake_last_resp_pa = 0;
	fake_last_map_size = 0;
	fake_mapped_phys = 0;
	fake_map_virtual_calls = 0;
	fake_last_attr = NULL;
	fake_last_flags = 0;
	fake_done_value = 0;
	fake_unmap_virtual_calls = 0;
	fake_unmap_memory_calls = 0;
	fake_unknown_calls = 0;
	fake_unknown_msg = 0;
	fake_free_calls = 0;
	fake_freed_work = NULL;
	fake_procfs_format_mcos_calls = 0;
	fake_procfs_format_decimal_calls = 0;
	fake_procfs_last_format_value = 0;
	fake_procfs_find_calls = 0;
	fake_procfs_add_calls = 0;
	fake_procfs_set_osnum_calls = 0;
	fake_procfs_last_set_osnum = 0;
	fake_procfs_last_mode = 0;
	fake_procfs_missing_base = 0;
	fake_procfs_missing_pid = 0;
	fake_procfs_missing_task = 0;
	fake_procfs_missing_tid = 0;
	fake_procfs_fail_add = 0;
	fake_procfs_last_parent = NULL;
	memset(fake_procfs_last_name, 0, sizeof(fake_procfs_last_name));
	fake_procfs_cred = 0x43524544;
	fake_procfs_no_cred = 0;
	fake_procfs_get_cred_calls = 0;
	fake_procfs_lock_calls = 0;
	fake_procfs_unlock_calls = 0;
	fake_procfs_find_pid_direct_calls = 0;
	fake_procfs_get_pid_direct_calls = 0;
	fake_procfs_find_tid_direct_calls = 0;
	fake_procfs_get_tid_direct_calls = 0;
	fake_procfs_find_base_direct_calls = 0;
	fake_procfs_get_base_direct_calls = 0;
	fake_procfs_add_pid_entries_calls = 0;
	fake_procfs_add_base_entries_calls = 0;
	fake_procfs_add_tid_entries_calls = 0;
	fake_procfs_add_tid_cred_calls = 0;
	fake_procfs_delete_entry_calls = 0;
	fake_procfs_find_exe_data_calls = 0;
	fake_procfs_add_exe_link_calls = 0;
	fake_procfs_add_pid_exe_calls = 0;
	fake_procfs_store_exe_path_calls = 0;
	fake_procfs_add_task_exe_links_calls = 0;
	fake_procfs_missing_exe = 0;
	fake_procfs_last_osnum = 0;
	fake_procfs_last_pid = 0;
	fake_procfs_last_tid = 0;
	fake_procfs_last_cred = NULL;
	fake_procfs_last_target = NULL;
	fake_procfs_deleted_entry = NULL;
	memset(fake_procfs_last_path, 0, sizeof(fake_procfs_last_path));
	memset(&fake_procfs_file, 0, sizeof(fake_procfs_file));
	memset(&fake_procfs_info, 0, sizeof(fake_procfs_info));
	memset(&fake_procfs_read, 0, sizeof(fake_procfs_read));
	memset(fake_procfs_pages, 0, sizeof(fake_procfs_pages));
	memset(fake_procfs_user_buf, 0, sizeof(fake_procfs_user_buf));
	memset(fake_procfs_kernel_page, 0, sizeof(fake_procfs_kernel_page));
	memset(fake_procfs_path_buf, 0, sizeof(fake_procfs_path_buf));
	memset(fake_procfs_forced_path, 0, sizeof(fake_procfs_forced_path));
	fake_procfs_entry_osnum_value = 9;
	fake_procfs_os_missing = 0;
	fake_procfs_open_alloc_calls = 0;
	fake_procfs_open_fail_alloc_call = 0;
	fake_procfs_open_last_size = 0;
	fake_procfs_open_free_calls = 0;
	fake_procfs_init_info_calls = 0;
	fake_procfs_set_private_calls = 0;
	fake_procfs_get_private_calls = 0;
	fake_procfs_release_alloc_read_calls = 0;
	fake_procfs_release_fail_alloc_read = 0;
	fake_procfs_init_release_read_calls = 0;
	fake_procfs_release_send_calls = 0;
	fake_procfs_release_send_ret = 0;
	fake_procfs_release_do_free = 1;
	fake_procfs_release_read_ret = 0;
	fake_procfs_release_timeout_calls = 0;
	fake_procfs_read_get_usrdata_calls = 0;
	fake_procfs_read_missing_usrdata = 0;
	fake_procfs_read_get_ppd_calls = 0;
	fake_procfs_read_missing_ppd = 0;
	fake_procfs_read_put_ppd_calls = 0;
	fake_procfs_read_ppd_cpu_calls = 0;
	fake_procfs_init_request_read_calls = 0;
	fake_procfs_request_send_calls = 0;
	fake_procfs_request_send_ret = 0;
	fake_procfs_request_do_free = 1;
	fake_procfs_request_read_ret = 0;
	fake_procfs_request_pbuf = 0x1000UL;
	fake_procfs_read_timeout_calls = 0;
	fake_procfs_read_no_usrdata_calls = 0;
	fake_procfs_read_no_ppd_calls = 0;
	fake_procfs_add_entries_calls = 0;
	fake_procfs_add_entries_parent = NULL;
	fake_procfs_add_entries_name = NULL;
	fake_procfs_add_entries_mode = 0;
	fake_procfs_add_entries_fops = NULL;
	fake_procfs_add_entries_uid = NULL;
	fake_procfs_add_entries_gid = NULL;
	fake_procfs_entry_alloc_calls = 0;
	fake_procfs_entry_alloc_fail = 0;
	fake_procfs_entry_alloc_size = 0;
	fake_procfs_entry_init_calls = 0;
	memset(fake_procfs_entry_init_name, 0,
	       sizeof(fake_procfs_entry_init_name));
	fake_procfs_entry_create_calls = 0;
	fake_procfs_entry_create_fail = 0;
	fake_procfs_entry_create_mode = 0;
	fake_procfs_entry_create_uid = NULL;
	fake_procfs_entry_create_gid = NULL;
	fake_procfs_entry_create_opaque = NULL;
	fake_procfs_entry_create_entry = NULL;
	fake_procfs_entry_commit_calls = 0;
	fake_procfs_entry_commit_parent = NULL;
	fake_procfs_entry_commit_pde = NULL;
	fake_procfs_entry_commit_uid = NULL;
	fake_procfs_entry_commit_gid = NULL;
	fake_procfs_entry_free_calls = 0;
	fake_procfs_entry_free_last = NULL;
	fake_procfs_entry_alloc_failed_calls = 0;
	fake_procfs_entry_create_failed_calls = 0;
	memset(fake_procfs_entry_create_failed_name, 0,
	       sizeof(fake_procfs_entry_create_failed_name));
	fake_procfs_delete_lifecycle_child_present = 0;
	fake_procfs_delete_lifecycle_first_calls = 0;
	fake_procfs_delete_lifecycle_unlink_calls = 0;
	fake_procfs_delete_lifecycle_remove_calls = 0;
	fake_procfs_delete_lifecycle_data_calls = 0;
	fake_procfs_delete_lifecycle_free_calls = 0;
	memset(fake_procfs_delete_lifecycle_freed, 0,
	       sizeof(fake_procfs_delete_lifecycle_freed));
	fake_procfs_first_child_calls = 0;
	fake_procfs_next_child_calls = 0;
	fake_procfs_entry_name_calls = 0;
	fake_procfs_rcu_lock_calls = 0;
	fake_procfs_rcu_unlock_calls = 0;
	fake_procfs_find_vpid_calls = 0;
	fake_procfs_pid_task_calls = 0;
	fake_procfs_task_cred_calls = 0;
	fake_procfs_pid_task_missing = 0;
	fake_procfs_last_pid_type = -1;
	fake_procfs_pid_token = 0x706964;
	fake_procfs_task_token = 0x7461736b;
	fake_procfs_cred_token = 0x63726564;
	fake_procfs_read_map_memory_calls = 0;
	fake_procfs_read_map_virtual_calls = 0;
	fake_procfs_read_unmap_virtual_calls = 0;
	fake_procfs_read_unmap_memory_calls = 0;
	fake_procfs_read_copy_calls = 0;
	fake_procfs_read_copy_fail = 0;
	fake_procfs_read_last_map_phys = 0;
	fake_procfs_read_last_map_size = 0;
	fake_procfs_rw_get_order_calls = 0;
	fake_procfs_rw_get_order_result = 0;
	fake_procfs_rw_alloc_pages_calls = 0;
	fake_procfs_rw_alloc_pages_fail = 0;
	fake_procfs_rw_last_order = -1;
	fake_procfs_rw_free_pages_calls = 0;
	fake_procfs_rw_last_free_pages_ptr = NULL;
	fake_procfs_rw_last_free_pages_order = -1;
	fake_procfs_rw_virt_to_phys_calls = 0;
	fake_procfs_rw_init_calls = 0;
	fake_procfs_rw_last_pbuf = 0;
	fake_procfs_rw_last_offset = 0;
	fake_procfs_rw_last_count = 0;
	fake_procfs_rw_last_read_write = 0;
	memset(fake_procfs_rw_last_path, 0, sizeof(fake_procfs_rw_last_path));
	fake_procfs_rw_eof = 0;
	fake_procfs_rw_copy_calls = 0;
	fake_procfs_rw_copy_fail = 0;
	fake_procfs_rw_bad_osnum_logs = 0;
	fake_procfs_rw_mismatch_logs = 0;
	fake_procfs_rw_no_os_logs = 0;
	fake_procfs_rw_no_usrdata_logs = 0;
	fake_procfs_rw_no_ppd_logs = 0;
	fake_procfs_rw_alloc_error_logs = 0;
	fake_procfs_rw_copy_error_logs = 0;
	fake_procfs_rw_timeout_logs = 0;
	memset(&fake_sysfs_work, 0, sizeof(fake_sysfs_work));
	fake_sysfs_alloc_calls = 0;
	fake_sysfs_fail_alloc = 0;
	fake_sysfs_alloc_size = 0;
	fake_sysfs_init_schedule_calls = 0;
	fake_sysfs_scheduled_work = NULL;
	fake_sysfs_alloc_failed_calls = 0;
	memset(fake_sysfs_req_calls, 0, sizeof(fake_sysfs_req_calls));
	fake_sysfs_resp_show_calls = 0;
	fake_sysfs_resp_store_calls = 0;
	fake_sysfs_resp_release_calls = 0;
	fake_sysfs_unknown_calls = 0;
	fake_sysfs_unknown_msg = 0;
	fake_sysfs_last_os = NULL;
	fake_sysfs_last_node = NULL;
	fake_sysfs_last_arg = 0;
	fake_sysfs_last_result = 0;
	fake_sysfs_last_error = 0;
	fake_sysfs_free_calls = 0;
	fake_sysfs_freed_work = NULL;
	memset(&fake_sysfs_remote_req, 0, sizeof(fake_sysfs_remote_req));
	memset(fake_sysfs_remote_kernel_buf, 0,
			sizeof(fake_sysfs_remote_kernel_buf));
	memset(fake_sysfs_remote_user_buf, 0,
			sizeof(fake_sysfs_remote_user_buf));
	fake_sysfs_remote_sem = 0x53534d;
	fake_sysfs_remote_down_calls = 0;
	fake_sysfs_remote_down_ret = 0;
	fake_sysfs_remote_up_calls = 0;
	fake_sysfs_remote_wait_calls = 0;
	fake_sysfs_remote_wait_fail_at = 0;
	fake_sysfs_remote_set_busy_calls = 0;
	fake_sysfs_remote_send_calls = 0;
	fake_sysfs_remote_send_ret = 0;
	fake_sysfs_remote_req_result_calls = 0;
	fake_sysfs_remote_copy_calls = 0;
	fake_sysfs_remote_last_sem = NULL;
	fake_sysfs_remote_last_os = NULL;
	fake_sysfs_remote_last_cpu = -1;
	fake_sysfs_remote_last_msg = 0;
	fake_sysfs_remote_last_arg1 = 0;
	fake_sysfs_remote_last_arg2 = 0;
	fake_sysfs_remote_last_arg3 = 0;
	fake_sysfs_remote_last_err = 0;
	fake_sysfs_remote_last_copy_size = 0;
	memset(fake_sysfs_local_ops_table, 0, sizeof(fake_sysfs_local_ops_table));
	memset(&fake_sysfs_local_bitmap, 0, sizeof(fake_sysfs_local_bitmap));
	fake_sysfs_local_alloc_calls = 0;
	fake_sysfs_local_fail_alloc = 0;
	fake_sysfs_local_alloc_size = 0;
	fake_sysfs_local_copy_calls = 0;
	fake_sysfs_local_copy_size = 0;
	fake_sysfs_local_unknown_calls = 0;
	fake_sysfs_local_unknown_ops_seen = 0;
	memset(&fake_sysfs_local_node, 0, sizeof(fake_sysfs_local_node));
	memset(&fake_sysfs_client_ops, 0, sizeof(fake_sysfs_client_ops));
	fake_sysfs_local_show_calls = 0;
	fake_sysfs_local_store_calls = 0;
	fake_sysfs_local_release_calls = 0;
	fake_sysfs_local_free_calls = 0;
	fake_sysfs_local_last_instance = NULL;
	fake_sysfs_local_last_buf = NULL;
	fake_sysfs_local_last_size = 0;
	fake_sysfs_local_create_calls = 0;
	fake_sysfs_local_create_ret = 0;
	fake_sysfs_local_create_os = NULL;
	fake_sysfs_local_create_param = NULL;
	fake_sysfs_local_mkdir_calls = 0;
	fake_sysfs_local_mkdir_ret = 0;
	fake_sysfs_local_mkdir_os = NULL;
	fake_sysfs_local_mkdir_param = NULL;
	fake_sysfs_local_symlink_calls = 0;
	fake_sysfs_local_symlink_ret = 0;
	fake_sysfs_local_symlink_os = NULL;
	fake_sysfs_local_symlink_param = NULL;
	fake_sysfs_local_lookup_calls = 0;
	fake_sysfs_local_lookup_ret = 0;
	fake_sysfs_local_lookup_os = NULL;
	fake_sysfs_local_lookup_param = NULL;
	fake_sysfs_local_unlink_calls = 0;
	fake_sysfs_local_unlink_ret = 0;
	fake_sysfs_local_unlink_os = NULL;
	fake_sysfs_local_unlink_param = NULL;
	fake_sysfs_local_cleanup_calls = 0;
	fake_sysfs_local_cleanup_ops = NULL;
	fake_sysfs_local_cleanup_instance = NULL;
	fake_sysfs_local_setup_failed_calls = 0;
	fake_sysfs_local_setup_failed_error = 0;
	fake_sysfs_req_os_to_dev_calls = 0;
	fake_sysfs_req_last_os = NULL;
	fake_sysfs_req_map_memory_calls = 0;
	fake_sysfs_req_map_virtual_calls = 0;
	fake_sysfs_req_unmap_virtual_calls = 0;
	fake_sysfs_req_unmap_memory_calls = 0;
	fake_sysfs_req_wmb_calls = 0;
	fake_sysfs_req_setup_local_calls = 0;
	fake_sysfs_req_setup_local_ret = 0;
	fake_sysfs_req_setup_os = NULL;
	fake_sysfs_req_setup_buf = NULL;
	fake_sysfs_req_setup_buf_pa = 0;
	fake_sysfs_req_setup_bufsize = 0;
	fake_sysfs_req_last_rpa = 0;
	fake_sysfs_req_last_pa = 0;
	fake_sysfs_req_last_size = 0;
	fake_sysfs_req_last_virt = NULL;
	fake_sysfs_req_fail_virtual_on_call = 0;
	memset(&fake_sysfs_resp_req, 0, sizeof(fake_sysfs_resp_req));
	fake_sysfs_resp_get_req_calls = 0;
	fake_sysfs_resp_complete_calls = 0;
	fake_sysfs_lookup_type_calls = 0;
	fake_sysfs_lookup_name_calls = 0;
	fake_sysfs_lookup_first_calls = 0;
	fake_sysfs_lookup_next_calls = 0;
	fake_sysfs_lookup_err_calls = 0;
	fake_sysfs_lookup_last_error = 0;
	fake_sysfs_bitmap_format_calls = 0;
	fake_sysfs_bitmap_last_ptr = NULL;
	fake_sysfs_bitmap_last_nbits = 0;
	fake_sysfs_bitmap_last_size = 0;
	memset(&fake_mcctrl_futex_q, 0, sizeof(fake_mcctrl_futex_q));
	memset(&fake_mcctrl_futex_uti, 0, sizeof(fake_mcctrl_futex_uti));
	memset(&fake_mcctrl_futex_dispatch, 0,
			sizeof(fake_mcctrl_futex_dispatch));
	fake_mcctrl_futex_dispatch.warn_cmd = -1;
	fake_mcctrl_futex_prepare_calls = 0;
	fake_mcctrl_futex_cpu = 7;
	fake_mcctrl_futex_setup_calls = 0;
	memset(fake_mcctrl_futex_setup_ret, 0,
			sizeof(fake_mcctrl_futex_setup_ret));
	fake_mcctrl_futex_queue_calls = 0;
	memset(fake_mcctrl_futex_queue_ret, 0,
			sizeof(fake_mcctrl_futex_queue_ret));
	fake_mcctrl_futex_unqueue_calls = 0;
	memset(fake_mcctrl_futex_unqueue_ret, 0,
			sizeof(fake_mcctrl_futex_unqueue_ret));
	fake_mcctrl_futex_put_key_calls = 0;
	fake_mcctrl_futex_last_put_fshared = -1;
	fake_mcctrl_futex_last_put_q = NULL;
	fake_mcctrl_futex_log_calls = 0;
	memset(fake_mcctrl_futex_log_stage, 0,
			sizeof(fake_mcctrl_futex_log_stage));
	fake_mcctrl_futex_last_uaddr = NULL;
	fake_mcctrl_futex_last_val = 0;
	fake_mcctrl_futex_last_timeout = 0;
	fake_mcctrl_futex_last_hb = NULL;
	fake_mcctrl_futex_hb = 0x46555458;
	fake_control_calls = 0;
	fake_control_last_id = 0;
	fake_control_last_os = 0;
	fake_control_last_arg = 0;
	fake_control_last_file = 0;
	fake_control_ret_base = 0x5000;
	fake_control_send_calls = 0;
	fake_control_send_ret = 0;
	fake_control_send_os = 0;
	fake_control_send_cpu = -1;
	fake_control_send_msg = 0;
	fake_control_send_arg = 0;
	fake_control_cpu_info_token = 0x435055;
	fake_control_cpu_info_missing = 0;
	fake_control_cpu_count = 4;
	fake_control_get_cpu_info_calls = 0;
	fake_control_cpu_count_calls = 0;
	fake_control_usrdata_token = 0x555344;
	fake_control_usrdata_missing = 0;
	fake_control_mem_info_token = 0x4d454d;
	fake_control_mem_info_missing = 0;
	fake_control_nodes_count = 2;
	fake_control_get_usrdata_calls = 0;
	fake_control_mem_info_calls = 0;
	fake_control_nodes_count_calls = 0;
	fake_control_log_calls = 0;
	fake_control_log_stage = -1;
	memset(&fake_control_cpu_reg_local, 0,
			sizeof(fake_control_cpu_reg_local));
	fake_control_cpu_reg_alloc_calls = 0;
	fake_control_cpu_reg_alloc_fail = 0;
	fake_control_cpu_reg_alloc_size = 0;
	fake_control_cpu_reg_free_calls = 0;
	fake_control_cpu_reg_freed = NULL;
	fake_control_cpu_reg_cpu_count = 4;
	fake_control_cpu_reg_cpu_count_calls = 0;
	fake_control_cpu_reg_send_calls = 0;
	fake_control_cpu_reg_send_ret = 0;
	fake_control_cpu_reg_send_do_free = 1;
	fake_control_cpu_reg_send_os = 0;
	fake_control_cpu_reg_send_cpu = -1;
	fake_control_cpu_reg_send_msg = 0;
	fake_control_cpu_reg_send_op = -1;
	fake_control_cpu_reg_send_pdesc = 0;
	fake_control_cpu_reg_send_timeout = 0;
	fake_control_cpu_reg_send_desc = NULL;
	fake_control_cpu_reg_phys = 0xc0410000UL;
	fake_control_cpu_reg_error_calls = 0;
	fake_control_cpu_reg_error_stage = -1;
	fake_control_cpu_reg_error_cpu = -1;
	fake_control_cpu_reg_error_ret = 0;
	fake_control_cpu_reg_done_calls = 0;
	fake_control_cpu_reg_done_op = -1;
	fake_control_cpu_reg_done_is_read = -1;
	fake_control_cpu_reg_done_cpu = -1;
	fake_control_cpu_reg_done_addr_ext = 0;
	fake_control_cpu_reg_done_val = 0;
	fake_control_cpu_reg_mutate_val = 0xabcdefUL;
	fake_control_validate_os_calls = 0;
	fake_control_validate_os_ret = 0;
	fake_control_validate_os_seen = 0;
	fake_control_current_pid_calls = 0;
	fake_control_current_tid_calls = 0;
	fake_control_current_pid_value = 2468;
	fake_control_current_tid_value = 3579;
	fake_control_current_task_calls = 0;
	fake_control_task_token = 0x5441534b;
	fake_control_ppd_token = 0x505044;
	fake_control_get_ppd_calls = 0;
	fake_control_missing_ppd = 0;
	fake_control_get_ppd_usrdata = NULL;
	fake_control_get_ppd_pid = 0;
	fake_control_put_ppd_calls = 0;
	fake_control_put_ppd_seen = NULL;
	fake_control_ptd_token = 0x505444;
	fake_control_get_ptd_calls = 0;
	fake_control_missing_ptd = 0;
	fake_control_get_ptd_ppd = NULL;
	fake_control_get_ptd_task = NULL;
	fake_control_put_ptd_calls = 0;
	fake_control_put_ptd_seen = NULL;
	memset(&fake_control_request_packet, 0,
			sizeof(fake_control_request_packet));
	fake_control_request_packet.body.traditional.ref = 3;
	fake_control_packet_missing = 0;
	fake_control_ptd_data_calls = 0;
	fake_control_ptd_tid_calls = 0;
	fake_control_ptd_tid_value = 3579;
	fake_control_ptd_refcount_calls = 0;
	fake_control_ptd_refcount_value = 1;
	fake_control_usrdata_os_calls = 0;
	fake_control_usrdata_os_value = 0x55440000UL;
	fake_control_packet_ref_calls = 0;
	fake_control_channel_read_cpu_calls = 0;
	fake_control_channel_read_cpu_result = 6;
	fake_control_channel_packet_ref = -1;
	fake_control_request_log_error_calls = 0;
	fake_control_request_log_error_stage = -1;
	fake_control_request_log_error_os = 0;
	fake_control_request_log_error_pid = 0;
	fake_control_request_log_error_tid = 0;
	fake_control_request_log_ptd_calls = 0;
	fake_control_request_log_ptd_get_calls = 0;
	fake_control_request_log_ptd_put_calls = 0;
	fake_control_request_log_ptd_stage = -1;
	fake_control_request_log_ptd_tid = 0;
	fake_control_request_log_ptd_seen = NULL;
	fake_control_request_log_result_calls = 0;
	fake_control_request_log_result_os = 0;
	fake_control_request_log_result_cpu = -1;
	fake_control_request_release_order = 0;
	fake_control_request_put_ptd_order = 0;
	fake_control_request_log_ptd_put_order = 0;
	fake_control_request_put_ppd_order = 0;
	fake_control_copy_from_calls = 0;
	fake_control_copy_from_fail = 0;
	fake_control_copy_from_fail_at = 0;
	fake_control_copy_from_src = NULL;
	fake_control_copy_from_dst = NULL;
	fake_control_copy_from_size = 0;
	fake_control_copy_to_calls = 0;
	fake_control_copy_to_fail = 0;
	fake_control_copy_to_fail_at = 0;
	fake_control_copy_to_src = NULL;
	fake_control_copy_to_dst = NULL;
	fake_control_copy_to_size = 0;
	memset(fake_control_copy_to_src_history, 0,
			sizeof(fake_control_copy_to_src_history));
	memset(fake_control_copy_to_dst_history, 0,
			sizeof(fake_control_copy_to_dst_history));
	memset(fake_control_copy_to_size_history, 0,
			sizeof(fake_control_copy_to_size_history));
	fake_control_get_order_calls = 0;
	fake_control_get_order_size = 0;
	fake_control_get_order_result = 3;
	fake_control_alloc_pages_calls = 0;
	fake_control_alloc_pages_order = -1;
	fake_control_alloc_pages_result = 0x100000UL;
	fake_control_free_pages_calls = 0;
	fake_control_free_pages_addr = 0;
	fake_control_free_pages_order = -1;
	fake_control_region_virt_to_phys_calls = 0;
	fake_control_region_virt_to_phys_ptr = NULL;
	fake_control_region_virt_to_phys_result = 0x200000UL;
	fake_control_region_phys_to_virt_calls = 0;
	fake_control_region_phys_to_virt_phys = 0;
	fake_control_region_phys_to_virt_result = 0x300000UL;
	fake_control_cred_token = 0x43524544;
	fake_control_original_cred_token = 0x4f435245;
	fake_control_cred_order = 0;
	fake_control_prepare_creds_calls = 0;
	fake_control_prepare_creds_fail = 0;
	fake_control_prepare_creds_order = 0;
	fake_control_cap_raise_calls = 0;
	fake_control_cap_raise_order = 0;
	fake_control_override_creds_calls = 0;
	fake_control_override_creds_order = 0;
	fake_control_revert_creds_calls = 0;
	fake_control_revert_creds_order = 0;
	fake_control_put_cred_calls = 0;
	fake_control_put_cred_order = 0;
	fake_control_mount_calls = 0;
	fake_control_mount_ret = 0;
	fake_control_mount_order = 0;
	fake_control_mount_dev = NULL;
	fake_control_mount_dir = NULL;
	fake_control_mount_type = NULL;
	fake_control_mount_flags = 0;
	fake_control_mount_data = NULL;
	fake_control_umount_calls = 0;
	fake_control_umount_ret = 0;
	fake_control_umount_order = 0;
	fake_control_umount_dir = NULL;
	fake_control_umount_flags = 0;
	fake_control_unshare_calls = 0;
	fake_control_unshare_ret = 0;
	fake_control_unshare_order = 0;
	fake_control_unshare_flags = 0;
	fake_control_clear_pte_calls = 0;
	fake_control_clear_pte_start = 0;
	fake_control_clear_pte_len = 0;
	fake_control_clear_pte_ret = 0;
	fake_control_perf_set_num_calls = 0;
	fake_control_perf_set_num_usrdata = NULL;
	fake_control_perf_set_num_value = 0;
	fake_control_perf_event_num = 2;
	memset(fake_control_perf_attrs, 0, sizeof(fake_control_perf_attrs));
	memset(fake_control_perf_descs, 0, sizeof(fake_control_perf_descs));
	memset(fake_control_perf_user_values, 0, sizeof(fake_control_perf_user_values));
	fake_control_perf_attrs[0].config = 0x101UL;
	fake_control_perf_attrs[0].exclude_user = 1;
	fake_control_perf_attrs[1].config = 0x202UL;
	fake_control_perf_attrs[1].exclude_kernel = 1;
	fake_control_perf_event_num_calls = 0;
	fake_control_perf_alloc_set_calls = 0;
	fake_control_perf_alloc_set_fail_index = -1;
	fake_control_perf_copy_fail_index = -1;
	fake_control_perf_alloc_desc_calls = 0;
	fake_control_perf_alloc_desc_size = 0;
	fake_control_perf_alloc_desc_fail = 0;
	fake_control_perf_free_calls = 0;
	fake_control_perf_freed_desc = NULL;
	fake_control_perf_init_get_calls = 0;
	fake_control_perf_init_mask_calls = 0;
	fake_control_perf_init_mask_type = -1;
	fake_control_perf_init_mask_value = 0;
	fake_control_perf_send_calls = 0;
	fake_control_perf_send_os = 0;
	fake_control_perf_send_cpu = -1;
	fake_control_perf_send_timeout = 0;
	fake_control_perf_send_ret = 0;
	fake_control_perf_send_fail_call = -1;
	fake_control_perf_send_need_free = 1;
	fake_control_perf_desc_err_calls = 0;
	fake_control_perf_desc_err_value = 0;
	fake_control_perf_desc_err_after_cpu = -1;
	fake_control_perf_desc_read_calls = 0;
	fake_control_perf_copyout_fail = 0;
	fake_control_perf_log_calls = 0;
	fake_control_perf_log_stage = -1;
	fake_control_perf_disable_calls = 0;
	fake_control_perf_disable_os = 0;
	fake_control_perf_disable_ret = -5;
	fake_control_perf_num_zero_calls = 0;
	fake_control_perf_num_zero_os = 0;
	fake_control_perf_num_zero_ret = -6;
	memset(&fake_control_rusage_global, 0,
			sizeof(fake_control_rusage_global));
	memset(&fake_control_rusage_desc, 0,
			sizeof(fake_control_rusage_desc));
	memset(&fake_control_rusage_user_out, 0,
			sizeof(fake_control_rusage_user_out));
	memset(&fake_control_rusage_alloc_out, 0,
			sizeof(fake_control_rusage_alloc_out));
	fake_control_rusage_global.memory_stat_rss[0] = 11;
	fake_control_rusage_global.memory_stat_rss[1] = -2;
	fake_control_rusage_global.memory_stat_mapped_file[0] = 13;
	fake_control_rusage_global.memory_stat_mapped_file[1] = 17;
	fake_control_rusage_global.memory_max_usage = 1000;
	fake_control_rusage_global.memory_kmem_usage = 55;
	fake_control_rusage_global.memory_kmem_max_usage = 66;
	fake_control_rusage_global.num_numa_nodes = 3;
	fake_control_rusage_global.memory_numa_stat[0] = 101;
	fake_control_rusage_global.memory_numa_stat[1] = 202;
	fake_control_rusage_global.memory_numa_stat[2] = 303;
	fake_control_rusage_global.num_processors = 2;
	fake_control_rusage_global.ns_per_tsc = 2000;
	fake_control_rusage_global.cpu[0].user_tsc = 100;
	fake_control_rusage_global.cpu[0].system_tsc = 50;
	fake_control_rusage_global.cpu[1].user_tsc = 3;
	fake_control_rusage_global.cpu[1].system_tsc = 4;
	fake_control_rusage_global.num_threads = 5;
	fake_control_rusage_global.max_num_threads = 9;
	fake_control_rusage_desc.rusage = &fake_control_rusage_user_out;
	fake_control_rusage_desc.size_rusage =
		sizeof(fake_control_rusage_user_out);
	fake_control_getrusage_calls = 0;
	fake_control_getrusage_os = 0;
	fake_control_getrusage_alloc_calls = 0;
	fake_control_getrusage_alloc_size = 0;
	fake_control_getrusage_alloc_fail = 0;
	fake_control_getrusage_free_calls = 0;
	fake_control_getrusage_freed = NULL;
	fake_control_getrusage_log_calls = 0;
	fake_control_getrusage_log_stage = -1;
	fake_control_getrusage_log_size = 0;
	fake_control_getrusage_log_max = 0;
	memset(&fake_control_transfer_desc, 0,
			sizeof(fake_control_transfer_desc));
	memset(&fake_control_load_desc, 0, sizeof(fake_control_load_desc));
	memset(&fake_control_ret_desc, 0, sizeof(fake_control_ret_desc));
	memset(&fake_control_uti_desc, 0, sizeof(fake_control_uti_desc));
	memset(fake_control_user_buf, 0x5a, sizeof(fake_control_user_buf));
	memset(fake_control_remote_buf, 0xa5, sizeof(fake_control_remote_buf));
	for (unsigned long i = 0; i < sizeof(fake_control_uti_remote_ctx); i++)
		fake_control_uti_remote_ctx[i] = (unsigned char)(i & 0xffU);
	memset(fake_control_uti_user_ctx, 0xa5,
			sizeof(fake_control_uti_user_ctx));
	memcpy(fake_control_user_buf, "transfer-source", 16);
	memcpy(fake_control_remote_buf, "remote-source", 14);
	fake_control_transfer_desc.rphys = 0x8800UL;
	fake_control_transfer_desc.userp = fake_control_user_buf;
	fake_control_transfer_desc.size = 16;
	fake_control_transfer_desc.direction = MCEXEC_UP_TRANSFER_TO_REMOTE;
	fake_control_load_desc.cpu = 3;
	fake_control_load_desc.src = 0x9900UL;
	fake_control_load_desc.dest = (unsigned long)fake_control_user_buf;
	fake_control_load_desc.size = 14;
	fake_control_ret_desc.cpu = 3;
	fake_control_ret_desc.ret = -37;
	fake_control_ret_desc.src = (unsigned long)fake_control_user_buf;
	fake_control_ret_desc.dest = 0x8a00UL;
	fake_control_ret_desc.size = 16;
	fake_control_uti_desc.rp_rctx = 0xb000UL;
	fake_control_uti_desc.rctx = fake_control_uti_user_ctx;
	fake_control_uti_desc.lctx = (void *)0xc000UL;
	fake_control_uti_desc.uti_refill_tid = 0x12345678;
	fake_control_uti_desc.key = 0;
	fake_control_os_to_dev_calls = 0;
	fake_control_os_to_dev_os = 0;
	fake_control_map_memory_calls = 0;
	fake_control_map_memory_phys = 0;
	fake_control_map_memory_size = 0;
	fake_control_map_virtual_calls = 0;
	fake_control_map_virtual_phys = 0;
	fake_control_map_virtual_size = 0;
	fake_control_map_virtual_fail = 0;
	fake_control_unmap_virtual_calls = 0;
	fake_control_unmap_virtual_ptr = NULL;
	fake_control_unmap_virtual_size = 0;
	fake_control_unmap_memory_calls = 0;
	fake_control_unmap_memory_phys = 0;
	fake_control_unmap_memory_size = 0;
	fake_control_transfer_log_calls = 0;
	fake_control_transfer_log_stage = -1;
	fake_control_load_log_calls = 0;
	fake_control_load_log_rpm = NULL;
	fake_control_load_log_size = 0;
	fake_control_return_syscall_calls = 0;
	fake_control_return_syscall_os = 0;
	fake_control_return_syscall_ppd = NULL;
	fake_control_return_syscall_packet = NULL;
	fake_control_return_syscall_ret = 0;
	fake_control_return_syscall_tid = 0;
	fake_control_release_packet_calls = 0;
	fake_control_release_packet_seen = NULL;
	fake_control_release_packet_order = 0;
	fake_control_ret_log_calls = 0;
	memset(fake_control_ret_log_stage, 0,
			sizeof(fake_control_ret_log_stage));
	memset(fake_control_ret_log_pid, 0,
			sizeof(fake_control_ret_log_pid));
	memset(fake_control_ret_log_tid, 0,
			sizeof(fake_control_ret_log_tid));
	fake_control_terminate_log_calls = 0;
	memset(fake_control_terminate_log_stage, 0,
			sizeof(fake_control_terminate_log_stage));
	memset(fake_control_terminate_log_pid, 0,
			sizeof(fake_control_terminate_log_pid));
	memset(fake_control_terminate_log_tid, 0,
			sizeof(fake_control_terminate_log_tid));
	memset(fake_control_terminate_log_ptr, 0,
			sizeof(fake_control_terminate_log_ptr));
	memset(fake_control_terminate_log_value, 0,
			sizeof(fake_control_terminate_log_value));
	fake_control_current_key_calls = 0;
	fake_control_current_key_value = 0xf00dcafe12345678UL;
	fake_control_uti_log_calls = 0;
	memset(fake_control_uti_log_stage, 0,
			sizeof(fake_control_uti_log_stage));
	for (int i = 0; i < 8; i++) {
		fake_control_cred_values[i] = 1000 + i;
		fake_control_cred_calls[i] = 0;
		fake_control_cred_kernel_values[i] = 0;
	}
	fake_control_cred_phys_to_virt_calls = 0;
	fake_control_cred_phys_to_virt_phys = 0;
	memset(fake_control_strncpy_page, 0, sizeof(fake_control_strncpy_page));
	fake_control_strncpy_alloc_calls = 0;
	fake_control_strncpy_alloc_fail = 0;
	fake_control_strncpy_free_calls = 0;
	fake_control_strncpy_freed = NULL;
	fake_control_strncpy_calls = 0;
	fake_control_strncpy_ret[0] = 0;
	fake_control_strncpy_ret[1] = 0;
	fake_control_strncpy_ret[2] = 0;
	fake_control_strncpy_ret[3] = 0;
	memset(fake_control_strncpy_want, 0,
			sizeof(fake_control_strncpy_want));
	memset(fake_control_strncpy_src, 0,
			sizeof(fake_control_strncpy_src));
	fake_control_strncpy_copy_to_calls = 0;
	fake_control_strncpy_fail_data_copy = 0;
	fake_control_strncpy_fail_desc_copy = 0;
	fake_control_strncpy_desc_arg = NULL;
	fake_control_destroy_log_calls = 0;
	memset(fake_control_destroy_log_stage, 0,
			sizeof(fake_control_destroy_log_stage));
	memset(fake_control_destroy_log_pid, 0,
			sizeof(fake_control_destroy_log_pid));
	memset(fake_control_destroy_log_ppd, 0,
			sizeof(fake_control_destroy_log_ppd));
	fake_control_drop_exec_calls = 0;
	fake_control_drop_exec_ret = 1;
	fake_control_drop_exec_os = 0;
	fake_control_drop_exec_pid = 0;
	memset(&fake_control_new_info_token, 0,
			sizeof(fake_control_new_info_token));
	fake_control_new_info_calls = 0;
	fake_control_new_info_fail = 0;
	fake_control_new_info_os = 0;
	fake_control_new_info_file = NULL;
	fake_control_set_info_pid_calls = 0;
	fake_control_set_info_pid_value = 0;
	fake_control_register_release_calls = 0;
	fake_control_register_release_file = NULL;
	fake_control_register_release_info = NULL;
	fake_control_set_private_calls = 0;
	fake_control_set_private_file = NULL;
	fake_control_set_private_info = NULL;
	memset(&fake_control_start_user_desc, 0,
			sizeof(fake_control_start_user_desc));
	memset(&fake_control_start_local_desc, 0,
			sizeof(fake_control_start_local_desc));
	memset(&fake_control_start_prev_info, 0,
			sizeof(fake_control_start_prev_info));
	memset(&fake_control_start_new_info, 0,
			sizeof(fake_control_start_new_info));
	fake_control_start_alloc_calls = 0;
	fake_control_start_alloc_fail = 0;
	fake_control_start_alloc_size = 0;
	fake_control_start_free_calls = 0;
	fake_control_start_freed = NULL;
	fake_control_start_get_private_calls = 0;
	fake_control_start_private_file = NULL;
	fake_control_start_new_info_calls = 0;
	fake_control_start_new_info_fail = 0;
	fake_control_start_new_info_os = 0;
	fake_control_start_new_info_file = NULL;
	fake_control_start_set_info_calls = 0;
	fake_control_start_set_info_prepare_thread = 0;
	fake_control_start_info_prepare_calls = 0;
	fake_control_start_set_recv_calls = 0;
	fake_control_start_set_recv_os = 0;
	fake_control_start_set_recv_cpu = -1;
	fake_control_start_set_last_calls = 0;
	fake_control_start_set_last_usrdata = NULL;
	fake_control_start_set_last_cpu = 0;
	fake_control_start_send_calls = 0;
	fake_control_start_send_ret = 0;
	fake_control_start_send_os = 0;
	fake_control_start_send_cpu = -1;
	fake_control_start_send_rprocess = 0;
	fake_control_start_clear_calls = 0;
	fake_control_start_log_calls = 0;
	memset(fake_control_start_log_stage, 0,
			sizeof(fake_control_start_log_stage));
	memset(fake_control_start_log_ret, 0,
			sizeof(fake_control_start_log_ret));
	memset(&fake_control_signal_user_desc, 0,
			sizeof(fake_control_signal_user_desc));
	memset(&fake_control_signal_local_desc, 0,
			sizeof(fake_control_signal_local_desc));
	fake_control_signal_alloc_calls = 0;
	fake_control_signal_alloc_fail = 0;
	fake_control_signal_alloc_size = 0;
	fake_control_signal_free_calls = 0;
	fake_control_signal_freed = NULL;
	fake_control_signal_vtop_calls = 0;
	fake_control_signal_vtop_ptr = NULL;
	fake_control_signal_vtop_result = 0x51510000UL;
	fake_control_signal_send_calls = 0;
	fake_control_signal_send_ret = 0;
	fake_control_signal_send_do_free = 1;
	fake_control_signal_send_os = 0;
	fake_control_signal_send_cpu = -1;
	fake_control_signal_send_msg = 0;
	fake_control_signal_send_ref = -1;
	fake_control_signal_send_pid = 0;
	fake_control_signal_send_arg = 0;
	fake_control_signal_send_timeout = 0;
	fake_control_signal_send_desc = NULL;
	fake_control_signal_log_calls = 0;
	memset(fake_control_signal_log_stage, 0,
			sizeof(fake_control_signal_log_stage));
	memset(fake_control_signal_log_ret, 0,
			sizeof(fake_control_signal_log_ret));
}

static struct mcctrl_procfs_work_prefix *fake_alloc(unsigned long size)
{
	fake_alloc_calls++;
	fake_alloc_size = size;
	if (fake_fail_alloc)
		return NULL;
	memset(&fake_work, 0, sizeof(fake_work));
	return &fake_work;
}

static void fake_init_schedule(struct mcctrl_procfs_work_prefix *work)
{
	fake_init_schedule_calls++;
	fake_scheduled_work = work;
}

static void fake_alloc_failed(void)
{
	fake_alloc_failed_calls++;
}

static int fake_get_index(void *os)
{
	fake_last_os = os;
	return 19;
}

static void fake_add_tid(int osnum, int pid, int tid)
{
	fake_add_calls++;
	fake_last_osnum = osnum;
	fake_last_pid = pid;
	fake_last_tid = tid;
}

static void fake_delete_tid(int osnum, int pid, int tid)
{
	fake_delete_calls++;
	fake_last_osnum = osnum;
	fake_last_pid = pid;
	fake_last_tid = tid;
}

static void *fake_os_to_dev(void *os)
{
	fake_os_to_dev_calls++;
	fake_last_os = os;
	fake_last_dev = (void *)0xdec0deUL;
	return fake_last_dev;
}

static unsigned long fake_map_memory(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == fake_last_dev);
	fake_map_memory_calls++;
	fake_last_resp_pa = phys;
	fake_last_map_size = size;
	fake_mapped_phys = phys + 0x1000UL;
	return fake_mapped_phys;
}

static void *fake_map_virtual(void *dev, unsigned long phys,
		unsigned long size, void *attr, int flags)
{
	require(dev == fake_last_dev);
	require(phys == fake_mapped_phys);
	fake_map_virtual_calls++;
	fake_last_map_size = size;
	fake_last_attr = attr;
	fake_last_flags = flags;
	return &fake_done_value;
}

static void fake_unmap_virtual(void *dev, void *virt, unsigned long size)
{
	require(dev == fake_last_dev);
	require(virt == &fake_done_value);
	fake_unmap_virtual_calls++;
	fake_last_map_size = size;
}

static void fake_unmap_memory(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == fake_last_dev);
	require(phys == fake_mapped_phys);
	fake_unmap_memory_calls++;
	fake_last_map_size = size;
}

static void fake_unknown_work(int msg, int pid, unsigned long arg)
{
	fake_unknown_calls++;
	fake_unknown_msg = msg;
	fake_last_pid = pid;
	fake_last_tid = (int)arg;
}

static void fake_free_work(void *work)
{
	fake_free_calls++;
	fake_freed_work = work;
}

static int fake_procfs_format_mcos(char *buf, unsigned long buflen, int osnum)
{
	fake_procfs_format_mcos_calls++;
	fake_procfs_last_format_value = osnum;
	return snprintf(buf, buflen, "mcos%d", osnum);
}

static int fake_procfs_format_decimal(char *buf, unsigned long buflen,
		int value)
{
	fake_procfs_format_decimal_calls++;
	fake_procfs_last_format_value = value;
	return snprintf(buf, buflen, "%d", value);
}

static void *fake_procfs_find_entry(void *parent, const char *name)
{
	fake_procfs_find_calls++;
	fake_procfs_last_parent = parent;
	snprintf(fake_procfs_last_name, sizeof(fake_procfs_last_name), "%s",
		 name);

	if (!parent && !fake_procfs_missing_base &&
			!strncmp(name, "mcos", 4))
		return &fake_procfs_base_entry;
	if (parent == &fake_procfs_base_entry &&
			!fake_procfs_missing_pid && strcmp(name, "task"))
		return &fake_procfs_pid_entry;
	if (parent == &fake_procfs_pid_entry &&
			!fake_procfs_missing_task && !strcmp(name, "task"))
		return &fake_procfs_task_entry;
	if (parent == &fake_procfs_task_entry &&
			!fake_procfs_missing_tid)
		return &fake_procfs_tid_entry;
	return NULL;
}

static void *fake_procfs_add_entry(void *parent, const char *name, int mode)
{
	fake_procfs_add_calls++;
	fake_procfs_last_parent = parent;
	fake_procfs_last_mode = mode;
	snprintf(fake_procfs_last_name, sizeof(fake_procfs_last_name), "%s",
		 name);
	if (fake_procfs_fail_add)
		return NULL;
	if (!parent)
		return &fake_procfs_new_base_entry;
	if (parent == &fake_procfs_base_entry)
		return &fake_procfs_new_pid_entry;
	if (parent == &fake_procfs_task_entry)
		return &fake_procfs_new_tid_entry;
	return NULL;
}

static void fake_procfs_set_osnum(void *entry, int osnum)
{
	require(entry == &fake_procfs_new_base_entry);
	fake_procfs_set_osnum_calls++;
	fake_procfs_last_set_osnum = osnum;
}

static void *fake_procfs_get_cred(int pid)
{
	fake_procfs_get_cred_calls++;
	fake_procfs_last_pid = pid;
	if (fake_procfs_no_cred)
		return NULL;
	return &fake_procfs_cred;
}

static void fake_procfs_lock(void)
{
	fake_procfs_lock_calls++;
}

static void fake_procfs_unlock(void)
{
	fake_procfs_unlock_calls++;
}

static void *fake_procfs_find_pid_direct(int osnum, int pid)
{
	fake_procfs_find_pid_direct_calls++;
	fake_procfs_last_osnum = osnum;
	fake_procfs_last_pid = pid;
	if (fake_procfs_missing_pid)
		return NULL;
	return &fake_procfs_pid_entry;
}

static void *fake_procfs_get_pid_direct(int osnum, int pid)
{
	fake_procfs_get_pid_direct_calls++;
	fake_procfs_last_osnum = osnum;
	fake_procfs_last_pid = pid;
	return &fake_procfs_new_pid_entry;
}

static void *fake_procfs_find_tid_direct(int osnum, int pid, int tid)
{
	fake_procfs_find_tid_direct_calls++;
	fake_procfs_last_osnum = osnum;
	fake_procfs_last_pid = pid;
	fake_procfs_last_tid = tid;
	if (fake_procfs_missing_tid)
		return NULL;
	return &fake_procfs_tid_entry;
}

static void *fake_procfs_get_tid_direct(int osnum, int pid, int tid)
{
	fake_procfs_get_tid_direct_calls++;
	fake_procfs_last_osnum = osnum;
	fake_procfs_last_pid = pid;
	fake_procfs_last_tid = tid;
	if (fake_procfs_missing_tid)
		return NULL;
	return &fake_procfs_tid_entry;
}

static void *fake_procfs_find_base_direct(int osnum)
{
	fake_procfs_find_base_direct_calls++;
	fake_procfs_last_osnum = osnum;
	if (fake_procfs_missing_base)
		return NULL;
	return &fake_procfs_base_entry;
}

static void *fake_procfs_get_base_direct(int osnum)
{
	fake_procfs_get_base_direct_calls++;
	fake_procfs_last_osnum = osnum;
	return &fake_procfs_new_base_entry;
}

static void fake_procfs_add_pid_entries(void *parent, void *cred)
{
	fake_procfs_add_pid_entries_calls++;
	fake_procfs_last_parent = parent;
	fake_procfs_last_cred = cred;
}

static void fake_procfs_add_base_entries(void *parent)
{
	fake_procfs_add_base_entries_calls++;
	fake_procfs_last_parent = parent;
}

static void fake_procfs_add_tid_entries(void *parent, void *cred)
{
	fake_procfs_add_tid_entries_calls++;
	fake_procfs_last_parent = parent;
	fake_procfs_last_cred = cred;
}

static void fake_procfs_add_tid_cred(int osnum, int pid, int tid, void *cred)
{
	fake_procfs_add_tid_cred_calls++;
	fake_procfs_last_osnum = osnum;
	fake_procfs_last_pid = pid;
	fake_procfs_last_tid = tid;
	fake_procfs_last_cred = cred;
}

static void fake_procfs_delete_entry(void *entry)
{
	fake_procfs_delete_entry_calls++;
	fake_procfs_deleted_entry = entry;
}

static void *fake_procfs_find_exe_data(void *parent)
{
	fake_procfs_find_exe_data_calls++;
	fake_procfs_last_parent = parent;
	if (fake_procfs_missing_exe)
		return NULL;
	return (void *)0x657865UL;
}

static void fake_procfs_add_exe_link(void *parent, void *target, void *cred)
{
	fake_procfs_add_exe_link_calls++;
	fake_procfs_last_parent = parent;
	fake_procfs_last_target = target;
	fake_procfs_last_cred = cred;
}

static void *fake_procfs_add_pid_exe(void *parent, const char *path)
{
	fake_procfs_add_pid_exe_calls++;
	fake_procfs_last_parent = parent;
	snprintf(fake_procfs_last_path, sizeof(fake_procfs_last_path), "%s",
		 path);
	if (fake_procfs_fail_add)
		return NULL;
	return &fake_procfs_new_base_entry;
}

static void fake_procfs_store_exe_path(void *entry, const char *path)
{
	require(entry == &fake_procfs_new_base_entry);
	fake_procfs_store_exe_path_calls++;
	snprintf(fake_procfs_last_path, sizeof(fake_procfs_last_path), "%s",
		 path);
}

static void fake_procfs_add_task_exe_links(void *parent, const char *path)
{
	fake_procfs_add_task_exe_links_calls++;
	fake_procfs_last_parent = parent;
	snprintf(fake_procfs_last_path, sizeof(fake_procfs_last_path), "%s",
		 path);
}

static const char *fake_procfs_path_name(const void *entry)
{
	return ((const struct fake_procfs_path_entry *)entry)->name;
}

static void *fake_procfs_path_parent(const void *entry)
{
	return ((const struct fake_procfs_path_entry *)entry)->parent;
}

static const char *fake_procfs_entry_table_name(const void *entry)
{
	return ((const struct fake_procfs_entry_table *)entry)->name;
}

static unsigned int fake_procfs_entry_table_mode(const void *entry)
{
	return ((const struct fake_procfs_entry_table *)entry)->mode;
}

static const void *fake_procfs_entry_table_fops(const void *entry)
{
	return ((const struct fake_procfs_entry_table *)entry)->fops;
}

static const void *fake_procfs_entry_table_next(const void *entry,
		unsigned long size)
{
	return (const char *)entry + size;
}

static void fake_procfs_add_entry_with_ids(void *parent, const char *name,
		unsigned int mode, const void *fops, const void *uid,
		const void *gid)
{
	fake_procfs_add_entries_calls++;
	fake_procfs_add_entries_parent = parent;
	fake_procfs_add_entries_name = name;
	fake_procfs_add_entries_mode = mode;
	fake_procfs_add_entries_fops = fops;
	fake_procfs_add_entries_uid = uid;
	fake_procfs_add_entries_gid = gid;
}

static void *fake_procfs_entry_alloc(unsigned long size)
{
	fake_procfs_entry_alloc_calls++;
	fake_procfs_entry_alloc_size = size;
	if (fake_procfs_entry_alloc_fail)
		return NULL;
	return &fake_procfs_lifecycle_entry;
}

static void fake_procfs_entry_init(void *entry, const char *name)
{
	fake_procfs_entry_init_calls++;
	require(entry == &fake_procfs_lifecycle_entry);
	snprintf(fake_procfs_entry_init_name, sizeof(fake_procfs_entry_init_name),
		 "%s", name);
}

static void *fake_procfs_entry_create_pde(void *parent, const char *name,
		unsigned int mode, const void *uid, const void *gid,
		const void *opaque, void *entry)
{
	fake_procfs_entry_create_calls++;
	fake_procfs_last_parent = parent;
	snprintf(fake_procfs_last_name, sizeof(fake_procfs_last_name), "%s",
		 name);
	fake_procfs_entry_create_mode = mode;
	fake_procfs_entry_create_uid = uid;
	fake_procfs_entry_create_gid = gid;
	fake_procfs_entry_create_opaque = opaque;
	fake_procfs_entry_create_entry = entry;
	if (fake_procfs_entry_create_fail)
		return NULL;
	return &fake_procfs_lifecycle_pde;
}

static void fake_procfs_entry_commit(void *entry, void *parent, void *pde,
		const void *uid, const void *gid)
{
	fake_procfs_entry_commit_calls++;
	require(entry == &fake_procfs_lifecycle_entry);
	fake_procfs_entry_commit_parent = parent;
	fake_procfs_entry_commit_pde = pde;
	fake_procfs_entry_commit_uid = uid;
	fake_procfs_entry_commit_gid = gid;
}

static void fake_procfs_entry_free(void *entry)
{
	if (fake_procfs_entry_free_calls <
			(int)(sizeof(fake_procfs_delete_lifecycle_freed) /
			      sizeof(fake_procfs_delete_lifecycle_freed[0])))
		fake_procfs_delete_lifecycle_freed[
			fake_procfs_entry_free_calls] = entry;
	fake_procfs_entry_free_calls++;
	fake_procfs_entry_free_last = entry;
}

static void fake_procfs_entry_alloc_failed(void)
{
	fake_procfs_entry_alloc_failed_calls++;
}

static void fake_procfs_entry_create_failed(const char *name)
{
	fake_procfs_entry_create_failed_calls++;
	snprintf(fake_procfs_entry_create_failed_name,
		 sizeof(fake_procfs_entry_create_failed_name), "%s", name);
}

static void *fake_procfs_delete_lifecycle_first_child(void *parent)
{
	fake_procfs_delete_lifecycle_first_calls++;
	require(parent == &fake_procfs_lifecycle_entry);
	if (fake_procfs_delete_lifecycle_child_present)
		return &fake_procfs_task_entry;
	return NULL;
}

static void fake_procfs_delete_lifecycle_delete(void *entry)
{
	fake_procfs_delete_entry_calls++;
	fake_procfs_deleted_entry = entry;
	fake_procfs_delete_lifecycle_child_present = 0;
}

static void fake_procfs_delete_lifecycle_unlink(void *entry)
{
	fake_procfs_delete_lifecycle_unlink_calls++;
	require(entry == &fake_procfs_lifecycle_entry);
}

static void fake_procfs_delete_lifecycle_remove(void *entry)
{
	fake_procfs_delete_lifecycle_remove_calls++;
	require(entry == &fake_procfs_lifecycle_entry);
}

static void *fake_procfs_delete_lifecycle_data(void *entry)
{
	fake_procfs_delete_lifecycle_data_calls++;
	require(entry == &fake_procfs_lifecycle_entry);
	return &fake_procfs_lifecycle_data;
}

static void *fake_procfs_first_child(void *parent)
{
	fake_procfs_first_child_calls++;
	return parent;
}

static void *fake_procfs_next_child(void *parent, void *entry)
{
	struct fake_procfs_list_node *node = entry;

	(void)parent;
	fake_procfs_next_child_calls++;
	return node->next;
}

static const char *fake_procfs_list_node_name(const void *entry)
{
	fake_procfs_entry_name_calls++;
	return ((const struct fake_procfs_list_node *)entry)->name;
}

static void fake_procfs_rcu_read_lock(void)
{
	fake_procfs_rcu_lock_calls++;
}

static void fake_procfs_rcu_read_unlock(void)
{
	fake_procfs_rcu_unlock_calls++;
}

static void *fake_procfs_find_vpid(int pid)
{
	fake_procfs_find_vpid_calls++;
	fake_procfs_last_pid = pid;
	return &fake_procfs_pid_token;
}

static void *fake_procfs_pid_task(void *pid, int type)
{
	require(pid == &fake_procfs_pid_token);
	fake_procfs_pid_task_calls++;
	fake_procfs_last_pid_type = type;
	if (fake_procfs_pid_task_missing)
		return NULL;
	return &fake_procfs_task_token;
}

static void *fake_procfs_task_cred(void *task)
{
	require(task == &fake_procfs_task_token);
	fake_procfs_task_cred_calls++;
	return &fake_procfs_cred_token;
}

static int fake_procfs_entry_osnum(void *entry)
{
	require(entry == &fake_procfs_base_entry);
	return fake_procfs_entry_osnum_value;
}

static void *fake_procfs_lookup_os(int osnum)
{
	fake_procfs_last_osnum = osnum;
	return fake_procfs_os_missing ? NULL : (void *)0x9000UL;
}

static void *fake_procfs_open_alloc(unsigned long size)
{
	fake_procfs_open_alloc_calls++;
	fake_procfs_open_last_size = size;
	if (fake_procfs_open_fail_alloc_call ==
			fake_procfs_open_alloc_calls)
		return NULL;
	if (fake_procfs_open_alloc_calls == 1)
		return fake_procfs_path_buf;
	return &fake_procfs_info;
}

static void fake_procfs_open_free(void *ptr)
{
	fake_procfs_open_free_calls++;
	fake_procfs_last_target = ptr;
}

static const char *fake_procfs_get_path(void *entry, char *buf,
		unsigned long size)
{
	require(entry == &fake_procfs_base_entry);
	if (fake_procfs_forced_path[0])
		snprintf(buf, size, "%s", fake_procfs_forced_path);
	else
		snprintf(buf, size, "mcos9/123/status");
	return buf;
}

static void fake_procfs_init_info(void *opaque, void *os, int pid,
		unsigned long pa_null, const char *path)
{
	struct fake_procfs_buffer_info *info = opaque;

	require(info == &fake_procfs_info);
	fake_procfs_init_info_calls++;
	info->top_pa = pa_null;
	info->cur_pa = pa_null;
	info->os = os;
	info->pid = pid;
	snprintf(info->path, sizeof(info->path), "%s", path);
}

static void fake_procfs_set_file_private(void *file, void *data)
{
	struct fake_procfs_file *f = file;

	fake_procfs_set_private_calls++;
	f->private_data = data;
}

static void *fake_procfs_get_file_private(void *file)
{
	struct fake_procfs_file *f = file;

	fake_procfs_get_private_calls++;
	return f->private_data;
}

static unsigned long fake_procfs_info_top_pa(void *opaque)
{
	return ((struct fake_procfs_buffer_info *)opaque)->top_pa;
}

static void *fake_procfs_info_os(void *opaque)
{
	return ((struct fake_procfs_buffer_info *)opaque)->os;
}

static void *fake_procfs_alloc_read(void)
{
	fake_procfs_release_alloc_read_calls++;
	if (fake_procfs_release_fail_alloc_read)
		return NULL;
	return &fake_procfs_read;
}

static void fake_procfs_init_release_read(void *opaque,
		unsigned long top_pa)
{
	struct fake_procfs_read *r = opaque;

	fake_procfs_init_release_read_calls++;
	r->pbuf = top_pa;
	r->ret = -5;
	r->fname[0] = '\0';
}

static int fake_procfs_send_release(void *os, void *opaque, int *do_free)
{
	struct fake_procfs_read *r = opaque;

	require(os == (void *)0x9000UL);
	require(r == &fake_procfs_read);
	fake_procfs_release_send_calls++;
	*do_free = fake_procfs_release_do_free;
	return fake_procfs_release_send_ret;
}

static int fake_procfs_read_ret(void *opaque)
{
	require(opaque == &fake_procfs_read);
	return fake_procfs_release_read_ret;
}

static void fake_procfs_release_timeout(void)
{
	fake_procfs_release_timeout_calls++;
}

static int fake_procfs_info_pid(void *opaque)
{
	return ((struct fake_procfs_buffer_info *)opaque)->pid;
}

static unsigned long fake_procfs_info_cur_pa(void *opaque)
{
	return ((struct fake_procfs_buffer_info *)opaque)->cur_pa;
}

static const char *fake_procfs_info_path(void *opaque)
{
	return ((struct fake_procfs_buffer_info *)opaque)->path;
}

static void fake_procfs_info_set_top_cur(void *opaque, unsigned long top_pa,
		unsigned long cur_pa)
{
	struct fake_procfs_buffer_info *info = opaque;

	info->top_pa = top_pa;
	info->cur_pa = cur_pa;
}

static void fake_procfs_info_set_cur(void *opaque, unsigned long cur_pa)
{
	((struct fake_procfs_buffer_info *)opaque)->cur_pa = cur_pa;
}

static void *fake_procfs_get_usrdata(void *os)
{
	require(os == (void *)0x9000UL);
	fake_procfs_read_get_usrdata_calls++;
	return fake_procfs_read_missing_usrdata ? NULL : (void *)0x12345000UL;
}

static void *fake_procfs_get_per_proc(void *usrdata, int pid)
{
	require(usrdata == (void *)0x12345000UL);
	fake_procfs_read_get_ppd_calls++;
	fake_procfs_last_pid = pid;
	return fake_procfs_read_missing_ppd ? NULL : (void *)0x23456000UL;
}

static void fake_procfs_put_per_proc(void *ppd)
{
	require(ppd == (void *)0x23456000UL);
	fake_procfs_read_put_ppd_calls++;
}

static int fake_procfs_ppd_cpu(void *ppd)
{
	require(ppd == (void *)0x23456000UL);
	fake_procfs_read_ppd_cpu_calls++;
	return 7;
}

static void fake_procfs_init_request_read(void *opaque, unsigned long pbuf,
		const char *path)
{
	struct fake_procfs_read *r = opaque;

	require(r == &fake_procfs_read);
	fake_procfs_init_request_read_calls++;
	r->pbuf = pbuf;
	r->ret = -5;
	snprintf(r->fname, sizeof(r->fname), "%s", path);
}

static int fake_procfs_send_request(void *os, int cpu, int pid,
		void *opaque, int *do_free)
{
	struct fake_procfs_read *r = opaque;

	require(os == (void *)0x9000UL);
	require(r == &fake_procfs_read);
	fake_procfs_request_send_calls++;
	fake_procfs_last_tid = cpu;
	fake_procfs_last_pid = pid;
	*do_free = fake_procfs_request_do_free;
	r->ret = fake_procfs_request_read_ret;
	r->pbuf = fake_procfs_request_pbuf;
	return fake_procfs_request_send_ret;
}

static int fake_procfs_request_ret(void *opaque)
{
	require(opaque == &fake_procfs_read);
	return fake_procfs_read.ret;
}

static unsigned long fake_procfs_read_pbuf(void *opaque)
{
	require(opaque == &fake_procfs_read);
	return fake_procfs_read.pbuf;
}

static void *fake_procfs_read_os_to_dev(void *os)
{
	require(os == (void *)0x9000UL);
	return (void *)0x34567000UL;
}

static unsigned long fake_procfs_read_map_memory(void *dev,
		unsigned long phys, unsigned long size)
{
	require(dev == (void *)0x34567000UL);
	fake_procfs_read_map_memory_calls++;
	fake_procfs_read_last_map_phys = phys;
	fake_procfs_read_last_map_size = size;
	return phys;
}

static void *fake_procfs_read_map_virtual(void *dev, unsigned long phys,
		unsigned long size, void *attr, int flags)
{
	require(dev == (void *)0x34567000UL);
	require(size == fake_procfs_read_last_map_size);
	require(attr == NULL);
	require(flags == 0);
	fake_procfs_read_map_virtual_calls++;
	if (phys == fake_procfs_pages[0].phys)
		return &fake_procfs_pages[0];
	if (phys == fake_procfs_pages[1].phys)
		return &fake_procfs_pages[1];
	return NULL;
}

static void fake_procfs_read_unmap_virtual(void *dev, void *virt,
		unsigned long size)
{
	require(dev == (void *)0x34567000UL);
	require(size == fake_procfs_read_last_map_size);
	require(virt == &fake_procfs_pages[0] || virt == &fake_procfs_pages[1]);
	fake_procfs_read_unmap_virtual_calls++;
}

static void fake_procfs_read_unmap_memory(void *dev, unsigned long phys,
		unsigned long size)
{
	require(dev == (void *)0x34567000UL);
	require(phys == fake_procfs_read_last_map_phys);
	require(size == fake_procfs_read_last_map_size);
	fake_procfs_read_unmap_memory_calls++;
}

static unsigned long fake_procfs_buffer_pos(void *opaque)
{
	return ((struct fake_procfs_buffer_page *)opaque)->pos;
}

static unsigned long fake_procfs_buffer_size(void *opaque)
{
	return ((struct fake_procfs_buffer_page *)opaque)->size;
}

static unsigned long fake_procfs_buffer_next_pa(void *opaque)
{
	return ((struct fake_procfs_buffer_page *)opaque)->next_pa;
}

static int fake_procfs_copy_buffer_to_user(void *ubuf, void *opaque,
		unsigned long offset, unsigned long size)
{
	struct fake_procfs_buffer_page *buf = opaque;

	fake_procfs_read_copy_calls++;
	if (fake_procfs_read_copy_fail)
		return -1;
	memcpy(ubuf, buf->buf + offset, size);
	return 0;
}

static void fake_procfs_read_no_usrdata(void)
{
	fake_procfs_read_no_usrdata_calls++;
}

static void fake_procfs_read_no_ppd(int pid)
{
	fake_procfs_read_no_ppd_calls++;
	fake_procfs_last_pid = pid;
}

static void fake_procfs_read_timeout(void)
{
	fake_procfs_read_timeout_calls++;
}

static long fake_procfs_buff_read_call(unsigned long nbytes, long *pos)
{
	return mcctrl_procfs_buff_read_body_result(&fake_procfs_file,
		fake_procfs_user_buf, nbytes, pos, ~0UL, 4096,
		fake_procfs_get_file_private, fake_procfs_info_os,
		fake_procfs_info_pid, fake_procfs_info_top_pa,
		fake_procfs_info_cur_pa, fake_procfs_info_path,
		fake_procfs_info_set_top_cur, fake_procfs_info_set_cur,
		fake_procfs_get_usrdata, fake_procfs_get_per_proc,
		fake_procfs_put_per_proc, fake_procfs_ppd_cpu,
		fake_procfs_alloc_read, fake_procfs_init_request_read,
		fake_procfs_send_request, fake_procfs_request_ret,
		fake_procfs_read_pbuf, fake_procfs_open_free,
		fake_procfs_read_os_to_dev, fake_procfs_read_map_memory,
		fake_procfs_read_map_virtual, fake_procfs_read_unmap_virtual,
		fake_procfs_read_unmap_memory, fake_procfs_buffer_pos,
		fake_procfs_buffer_size, fake_procfs_buffer_next_pa,
		fake_procfs_copy_buffer_to_user, fake_procfs_read_no_usrdata,
		fake_procfs_read_no_ppd, fake_procfs_read_timeout);
}

static int fake_procfs_rw_get_order(unsigned long count)
{
	fake_procfs_rw_get_order_calls++;
	fake_procfs_rw_last_count = (int)count;
	return fake_procfs_rw_get_order_result;
}

static void *fake_procfs_rw_alloc_pages(int order)
{
	fake_procfs_rw_alloc_pages_calls++;
	fake_procfs_rw_last_order = order;
	if (fake_procfs_rw_alloc_pages_fail)
		return NULL;
	return fake_procfs_kernel_page;
}

static void fake_procfs_rw_free_pages(void *ptr, int order)
{
	fake_procfs_rw_free_pages_calls++;
	fake_procfs_rw_last_free_pages_ptr = ptr;
	fake_procfs_rw_last_free_pages_order = order;
}

static unsigned long fake_procfs_rw_virt_to_phys(void *ptr)
{
	fake_procfs_rw_virt_to_phys_calls++;
	if (ptr == fake_procfs_kernel_page)
		return 0xabc000UL;
	if (ptr == &fake_procfs_read)
		return 0xdef000UL;
	return (unsigned long)ptr;
}

static void fake_procfs_init_read_write_read(void *opaque,
		unsigned long pbuf, long offset, int count, int read_write,
		const char *path)
{
	struct fake_procfs_read *r = opaque;

	require(r == &fake_procfs_read);
	fake_procfs_rw_init_calls++;
	fake_procfs_rw_last_pbuf = pbuf;
	fake_procfs_rw_last_offset = offset;
	fake_procfs_rw_last_count = count;
	fake_procfs_rw_last_read_write = read_write;
	snprintf(fake_procfs_rw_last_path, sizeof(fake_procfs_rw_last_path),
		 "%s", path);
	r->pbuf = pbuf;
	r->ret = -5;
}

static int fake_procfs_rw_read_eof(void *opaque)
{
	require(opaque == &fake_procfs_read);
	return fake_procfs_rw_eof;
}

static int fake_procfs_rw_copy_to_user(void *ubuf, void *kbuf,
		unsigned long size)
{
	require(kbuf == fake_procfs_kernel_page);
	fake_procfs_rw_copy_calls++;
	if (fake_procfs_rw_copy_fail)
		return -1;
	memcpy(ubuf, kbuf, size);
	return 0;
}

static void fake_procfs_rw_bad_osnum(void)
{
	fake_procfs_rw_bad_osnum_logs++;
}

static void fake_procfs_rw_mismatch(int path_osnum, int entry_osnum)
{
	fake_procfs_rw_mismatch_logs++;
	fake_procfs_last_osnum = path_osnum;
	fake_procfs_last_pid = entry_osnum;
}

static void fake_procfs_rw_no_os(int osnum)
{
	fake_procfs_rw_no_os_logs++;
	fake_procfs_last_osnum = osnum;
}

static void fake_procfs_rw_no_usrdata(int osnum)
{
	fake_procfs_rw_no_usrdata_logs++;
	fake_procfs_last_osnum = osnum;
}

static void fake_procfs_rw_no_ppd(int pid)
{
	fake_procfs_rw_no_ppd_logs++;
	fake_procfs_last_pid = pid;
}

static void fake_procfs_rw_alloc_error(void)
{
	fake_procfs_rw_alloc_error_logs++;
}

static void fake_procfs_rw_copy_error(void)
{
	fake_procfs_rw_copy_error_logs++;
}

static void fake_procfs_rw_timeout(void)
{
	fake_procfs_rw_timeout_logs++;
}

static long fake_procfs_read_write_call(unsigned long nbytes, long *pos,
		int read_write)
{
	char path_buf[64];

	return mcctrl_procfs_read_write_body_result(
		&fake_procfs_base_entry, fake_procfs_user_buf, nbytes, pos,
		read_write, path_buf, sizeof(path_buf), 4096,
		fake_procfs_entry_osnum, fake_procfs_get_path,
		fake_procfs_lookup_os, fake_procfs_get_usrdata,
		fake_procfs_get_per_proc, fake_procfs_put_per_proc,
		fake_procfs_ppd_cpu, fake_procfs_rw_get_order,
		fake_procfs_rw_alloc_pages, fake_procfs_rw_free_pages,
		fake_procfs_rw_virt_to_phys, fake_procfs_alloc_read,
		fake_procfs_init_read_write_read, fake_procfs_send_request,
		fake_procfs_request_ret, fake_procfs_rw_read_eof,
		fake_procfs_open_free, fake_procfs_rw_copy_to_user,
		fake_procfs_rw_bad_osnum, fake_procfs_rw_mismatch,
		fake_procfs_rw_no_os, fake_procfs_rw_no_usrdata,
		fake_procfs_rw_no_ppd, fake_procfs_rw_alloc_error,
		fake_procfs_rw_copy_error, fake_procfs_rw_timeout);
}

static struct mcctrl_sysfs_work_prefix *fake_sysfs_alloc(unsigned long size)
{
	fake_sysfs_alloc_calls++;
	fake_sysfs_alloc_size = size;
	if (fake_sysfs_fail_alloc)
		return NULL;
	memset(&fake_sysfs_work, 0, sizeof(fake_sysfs_work));
	return &fake_sysfs_work;
}

static void fake_sysfs_init_schedule(struct mcctrl_sysfs_work_prefix *work)
{
	fake_sysfs_init_schedule_calls++;
	fake_sysfs_scheduled_work = work;
}

static void fake_sysfs_alloc_failed(void)
{
	fake_sysfs_alloc_failed_calls++;
}

static void fake_sysfs_req_setup(void *os, long arg)
{
	fake_sysfs_req_calls[0]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_req_create(void *os, long arg)
{
	fake_sysfs_req_calls[1]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_req_mkdir(void *os, long arg)
{
	fake_sysfs_req_calls[2]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_req_symlink(void *os, long arg)
{
	fake_sysfs_req_calls[3]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_req_lookup(void *os, long arg)
{
	fake_sysfs_req_calls[4]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_req_unlink(void *os, long arg)
{
	fake_sysfs_req_calls[5]++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg;
}

static void fake_sysfs_resp_show(void *os, void *node, long result)
{
	fake_sysfs_resp_show_calls++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_node = node;
	fake_sysfs_last_result = result;
}

static void fake_sysfs_resp_store(void *os, void *node, long result)
{
	fake_sysfs_resp_store_calls++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_node = node;
	fake_sysfs_last_result = result;
}

static void fake_sysfs_resp_release(void *os, void *node, int error)
{
	fake_sysfs_resp_release_calls++;
	fake_sysfs_last_os = os;
	fake_sysfs_last_node = node;
	fake_sysfs_last_error = error;
}

static void fake_sysfs_unknown_work(int msg, void *os, long arg1, long arg2)
{
	fake_sysfs_unknown_calls++;
	fake_sysfs_unknown_msg = msg;
	fake_sysfs_last_os = os;
	fake_sysfs_last_arg = arg1;
	fake_sysfs_last_result = arg2;
}

static void fake_sysfs_free_work(void *work)
{
	fake_sysfs_free_calls++;
	fake_sysfs_freed_work = work;
}

static int fake_sysfs_remote_down(void *sem)
{
	fake_sysfs_remote_down_calls++;
	fake_sysfs_remote_last_sem = sem;
	return fake_sysfs_remote_down_ret;
}

static void fake_sysfs_remote_up(void *sem)
{
	fake_sysfs_remote_up_calls++;
	fake_sysfs_remote_last_sem = sem;
}

static int fake_sysfs_remote_wait_ready(void *req0)
{
	struct fake_sysfs_remote_req *req = req0;

	fake_sysfs_remote_wait_calls++;
	if (fake_sysfs_remote_wait_fail_at == fake_sysfs_remote_wait_calls)
		return -512;
	if (fake_sysfs_remote_wait_calls == 2)
		req->busy = 0;
	return 0;
}

static void fake_sysfs_remote_set_busy(void *req0, int busy)
{
	struct fake_sysfs_remote_req *req = req0;

	fake_sysfs_remote_set_busy_calls++;
	req->busy = busy;
}

static int fake_sysfs_remote_send(void *os, int cpu, int msg, long arg1,
		long arg2, long arg3, int err)
{
	fake_sysfs_remote_send_calls++;
	fake_sysfs_remote_last_os = os;
	fake_sysfs_remote_last_cpu = cpu;
	fake_sysfs_remote_last_msg = msg;
	fake_sysfs_remote_last_arg1 = arg1;
	fake_sysfs_remote_last_arg2 = arg2;
	fake_sysfs_remote_last_arg3 = arg3;
	fake_sysfs_remote_last_err = err;
	return fake_sysfs_remote_send_ret;
}

static long fake_sysfs_remote_req_lresult(void *req0)
{
	struct fake_sysfs_remote_req *req = req0;

	fake_sysfs_remote_req_result_calls++;
	return req->lresult;
}

static void fake_sysfs_remote_copy(void *dst, const void *src,
		unsigned long size)
{
	fake_sysfs_remote_copy_calls++;
	fake_sysfs_remote_last_copy_size = size;
	memcpy(dst, src, size);
}

static void *fake_sysfs_local_alloc(unsigned long size)
{
	fake_sysfs_local_alloc_calls++;
	fake_sysfs_local_alloc_size = size;
	if (fake_sysfs_local_fail_alloc)
		return NULL;
	memset(&fake_sysfs_local_bitmap, 0, sizeof(fake_sysfs_local_bitmap));
	return &fake_sysfs_local_bitmap;
}

static void fake_sysfs_local_copy(void *dst, const void *src,
		unsigned long size)
{
	fake_sysfs_local_copy_calls++;
	fake_sysfs_local_copy_size = size;
	memcpy(dst, src, size);
}

static void fake_sysfs_local_unknown_ops(long ops)
{
	fake_sysfs_local_unknown_calls++;
	fake_sysfs_local_unknown_ops_seen = ops;
}

static long fake_sysfs_node_client_ops(void *node)
{
	return ((struct mcctrl_sysfs_local_node *)node)->client_ops;
}

static long fake_sysfs_node_client_instance(void *node)
{
	return ((struct mcctrl_sysfs_local_node *)node)->client_instance;
}

static int fake_sysfs_node_type(void *node)
{
	return ((struct mcctrl_sysfs_local_node *)node)->type;
}

static int fake_sysfs_lookup_node_type(void *node)
{
	fake_sysfs_lookup_type_calls++;
	return ((struct fake_sysfs_lookup_node *)node)->type;
}

static const char *fake_sysfs_lookup_node_name(void *node)
{
	fake_sysfs_lookup_name_calls++;
	return ((struct fake_sysfs_lookup_node *)node)->name;
}

static void *fake_sysfs_lookup_first_child(void *node)
{
	fake_sysfs_lookup_first_calls++;
	return ((struct fake_sysfs_lookup_node *)node)->first_child;
}

static void *fake_sysfs_lookup_next_child(void *parent, void *node)
{
	(void)parent;
	fake_sysfs_lookup_next_calls++;
	return ((struct fake_sysfs_lookup_node *)node)->next_sibling;
}

static void *fake_sysfs_lookup_err_ptr(int error)
{
	fake_sysfs_lookup_err_calls++;
	fake_sysfs_lookup_last_error = error;
	return (void *)(intptr_t)error;
}

static ssize_t fake_sysfs_client_show(struct mcctrl_sysfsm_ops *ops,
		void *instance, void *buf, size_t bufsize)
{
	require(ops == &fake_sysfs_client_ops);
	fake_sysfs_local_show_calls++;
	fake_sysfs_local_last_instance = instance;
	fake_sysfs_local_last_buf = buf;
	fake_sysfs_local_last_size = bufsize;
	return 123;
}

static ssize_t fake_sysfs_client_store(struct mcctrl_sysfsm_ops *ops,
		void *instance, const void *buf, size_t bufsize)
{
	require(ops == &fake_sysfs_client_ops);
	fake_sysfs_local_store_calls++;
	fake_sysfs_local_last_instance = instance;
	fake_sysfs_local_last_buf = (void *)buf;
	fake_sysfs_local_last_size = bufsize;
	return 456;
}

static void fake_sysfs_client_release(struct mcctrl_sysfsm_ops *ops,
		void *instance)
{
	require(ops == &fake_sysfs_client_ops);
	fake_sysfs_local_release_calls++;
	fake_sysfs_local_last_instance = instance;
}

static void fake_sysfs_local_free(void *ptr)
{
	fake_sysfs_local_free_calls++;
	fake_sysfs_local_last_instance = ptr;
}

static void *fake_sysfs_resp_get_req(void *node)
{
	require(node == &fake_sysfs_local_node);
	fake_sysfs_resp_get_req_calls++;
	return &fake_sysfs_resp_req;
}

static void *fake_sysfs_resp_get_null_req(void *node)
{
	require(node == &fake_sysfs_local_node);
	fake_sysfs_resp_get_req_calls++;
	return NULL;
}

static void fake_sysfs_resp_complete_req(void *req, long result)
{
	require(req == &fake_sysfs_resp_req);
	fake_sysfs_resp_complete_calls++;
	fake_sysfs_resp_req.complete_calls++;
	fake_sysfs_resp_req.result = result;
}

static unsigned long fake_sysfs_bitmap_format(void *buf, unsigned long size,
		void *ptr, int nbits)
{
	int ret;

	fake_sysfs_bitmap_format_calls++;
	fake_sysfs_bitmap_last_ptr = ptr;
	fake_sysfs_bitmap_last_nbits = nbits;
	fake_sysfs_bitmap_last_size = size;
	ret = snprintf(buf, size, "bits:%d:%lx", nbits, (unsigned long)ptr);
	return ret < 0 ? 0 : (unsigned long)ret;
}

static int fake_mcctrl_futex_wait(uint32_t *uaddr, int fshared,
		uint32_t val, uint64_t timeout, uint32_t bitset,
		int clockrt, void *uti_info)
{
	fake_mcctrl_futex_dispatch.wait_calls++;
	fake_mcctrl_futex_dispatch.uaddr = uaddr;
	fake_mcctrl_futex_dispatch.val = val;
	fake_mcctrl_futex_dispatch.val3 = bitset;
	fake_mcctrl_futex_dispatch.timeout = timeout;
	fake_mcctrl_futex_dispatch.fshared = fshared;
	fake_mcctrl_futex_dispatch.clockrt = clockrt;
	fake_mcctrl_futex_dispatch.uti_info = uti_info;
	return 100 + (int)(bitset & 0xffU) + clockrt;
}

static int fake_mcctrl_futex_wake(uint32_t *uaddr, int fshared,
		int nr_wake, uint32_t bitset, void *uti_info)
{
	fake_mcctrl_futex_dispatch.wake_calls++;
	fake_mcctrl_futex_dispatch.uaddr = uaddr;
	fake_mcctrl_futex_dispatch.val = (uint32_t)nr_wake;
	fake_mcctrl_futex_dispatch.val3 = bitset;
	fake_mcctrl_futex_dispatch.fshared = fshared;
	fake_mcctrl_futex_dispatch.uti_info = uti_info;
	return 200 + (int)(bitset & 0xffU);
}

static int fake_mcctrl_futex_requeue(uint32_t *uaddr1, int fshared,
		uint32_t *uaddr2, int nr_wake, int nr_requeue,
		uint32_t *cmpval, int requeue_pi, void *uti_info)
{
	fake_mcctrl_futex_dispatch.requeue_calls++;
	fake_mcctrl_futex_dispatch.uaddr = uaddr1;
	fake_mcctrl_futex_dispatch.uaddr2 = uaddr2;
	fake_mcctrl_futex_dispatch.val = (uint32_t)nr_wake;
	fake_mcctrl_futex_dispatch.val2 = (uint32_t)nr_requeue;
	fake_mcctrl_futex_dispatch.cmpval = cmpval ? *cmpval : 0;
	fake_mcctrl_futex_dispatch.val3 = (uint32_t)requeue_pi;
	fake_mcctrl_futex_dispatch.fshared = fshared;
	fake_mcctrl_futex_dispatch.uti_info = uti_info;
	return 300 + nr_wake + nr_requeue + requeue_pi;
}

static int fake_mcctrl_futex_wake_op(uint32_t *uaddr1, int fshared,
		uint32_t *uaddr2, int nr_wake, int nr_wake2, int op,
		void *uti_info)
{
	fake_mcctrl_futex_dispatch.wake_op_calls++;
	fake_mcctrl_futex_dispatch.uaddr = uaddr1;
	fake_mcctrl_futex_dispatch.uaddr2 = uaddr2;
	fake_mcctrl_futex_dispatch.val = (uint32_t)nr_wake;
	fake_mcctrl_futex_dispatch.val2 = (uint32_t)nr_wake2;
	fake_mcctrl_futex_dispatch.val3 = (uint32_t)op;
	fake_mcctrl_futex_dispatch.fshared = fshared;
	fake_mcctrl_futex_dispatch.uti_info = uti_info;
	return 400 + nr_wake + nr_wake2 + op;
}

static void fake_mcctrl_futex_warn(int cmd)
{
	fake_mcctrl_futex_dispatch.warn_calls++;
	fake_mcctrl_futex_dispatch.warn_cmd = cmd;
}

static void *fake_mcctrl_futex_get_q(void *uti_info)
{
	return ((struct fake_mcctrl_futex_uti *)uti_info)->q;
}

static void *fake_mcctrl_futex_get_resp(void *uti_info)
{
	return ((struct fake_mcctrl_futex_uti *)uti_info)->resp;
}

static int fake_mcctrl_futex_get_cpu(void)
{
	return fake_mcctrl_futex_cpu;
}

static void fake_mcctrl_futex_prepare_q(void *q, uint32_t bitset,
		void *resp, int linux_cpu)
{
	struct fake_mcctrl_futex_wait_q *waitq = q;

	fake_mcctrl_futex_prepare_calls++;
	waitq->bitset = bitset;
	waitq->resp = resp;
	waitq->linux_cpu = linux_cpu;
}

static int fake_mcctrl_futex_wait_setup(uint32_t *uaddr, uint32_t val,
		int fshared, void *q, void **hb, void *uti_info)
{
	int index = fake_mcctrl_futex_setup_calls++;

	require(q == &fake_mcctrl_futex_q);
	require(uti_info == &fake_mcctrl_futex_uti);
	fake_mcctrl_futex_last_uaddr = uaddr;
	fake_mcctrl_futex_last_val = val;
	fake_mcctrl_futex_last_put_fshared = fshared;
	fake_mcctrl_futex_last_hb = &fake_mcctrl_futex_hb;
	*hb = &fake_mcctrl_futex_hb;
	return fake_mcctrl_futex_setup_ret[index];
}

static long long fake_mcctrl_futex_wait_queue(void *hb, void *q,
		uint64_t timeout, void *uti_info)
{
	int index = fake_mcctrl_futex_queue_calls++;

	require(hb == &fake_mcctrl_futex_hb);
	require(q == &fake_mcctrl_futex_q);
	require(uti_info == &fake_mcctrl_futex_uti);
	fake_mcctrl_futex_last_timeout = timeout;
	return fake_mcctrl_futex_queue_ret[index];
}

static int fake_mcctrl_futex_unqueue(void *q)
{
	int index = fake_mcctrl_futex_unqueue_calls++;

	require(q == &fake_mcctrl_futex_q);
	return fake_mcctrl_futex_unqueue_ret[index];
}

static void fake_mcctrl_futex_put_q_key(int fshared, void *q)
{
	require(q == &fake_mcctrl_futex_q);
	fake_mcctrl_futex_put_key_calls++;
	fake_mcctrl_futex_last_put_fshared = fshared;
	fake_mcctrl_futex_last_put_q = q;
}

static void fake_mcctrl_futex_log_event(int stage, void *uti_info)
{
	require(uti_info == &fake_mcctrl_futex_uti);
	if (fake_mcctrl_futex_log_calls < 4)
		fake_mcctrl_futex_log_stage[fake_mcctrl_futex_log_calls] =
			stage;
	fake_mcctrl_futex_log_calls++;
}

struct fake_mcctrl_futex_requeue_ctx {
	struct fake_wake_body_bucket *hb1;
	struct fake_wake_body_bucket *hb2;
	struct futex_key *key2;
	void *uti_info;
};

static struct fake_wake_body_bucket *fake_mcctrl_body_source_bucket;
static struct fake_wake_body_bucket *fake_mcctrl_body_target_bucket;
static int fake_mcctrl_body_get_key_calls;
static int fake_mcctrl_body_hash_calls;
static int fake_mcctrl_body_wake_lock_calls;
static int fake_mcctrl_body_wake_unlock_calls;
static int fake_mcctrl_body_hb_lock_calls;
static int fake_mcctrl_body_hb_unlock_calls;
static int fake_mcctrl_body_put_key_calls;
static int fake_mcctrl_body_wake_calls;
static int fake_mcctrl_body_requeue_calls;
static int fake_mcctrl_body_atomic_calls;
static int fake_mcctrl_body_get_value_calls;
static int fake_mcctrl_body_drop_key_calls;
static int fake_mcctrl_body_key_ref_calls;
static int fake_mcctrl_body_get_key2_ret;
static int fake_mcctrl_body_atomic_seq[4];
static int fake_mcctrl_body_wake_log[8];
static int fake_mcctrl_body_requeue_log[8];
static unsigned int fake_mcctrl_body_curval;
static unsigned long fake_mcctrl_body_last_lock;
static unsigned long fake_mcctrl_body_last_irqstate;
static unsigned long fake_mcctrl_body_put_key_log[8];

static void fake_mcctrl_body_reset(void)
{
	fake_mcctrl_body_source_bucket = NULL;
	fake_mcctrl_body_target_bucket = NULL;
	fake_mcctrl_body_get_key_calls = 0;
	fake_mcctrl_body_hash_calls = 0;
	fake_mcctrl_body_wake_lock_calls = 0;
	fake_mcctrl_body_wake_unlock_calls = 0;
	fake_mcctrl_body_hb_lock_calls = 0;
	fake_mcctrl_body_hb_unlock_calls = 0;
	fake_mcctrl_body_put_key_calls = 0;
	fake_mcctrl_body_wake_calls = 0;
	fake_mcctrl_body_requeue_calls = 0;
	fake_mcctrl_body_atomic_calls = 0;
	fake_mcctrl_body_get_value_calls = 0;
	fake_mcctrl_body_drop_key_calls = 0;
	fake_mcctrl_body_key_ref_calls = 0;
	fake_mcctrl_body_get_key2_ret = 0;
	fake_mcctrl_body_curval = 0;
	fake_mcctrl_body_last_lock = 0;
	fake_mcctrl_body_last_irqstate = 0;
	memset(fake_mcctrl_body_atomic_seq, 0,
			sizeof(fake_mcctrl_body_atomic_seq));
	memset(fake_mcctrl_body_wake_log, 0,
			sizeof(fake_mcctrl_body_wake_log));
	memset(fake_mcctrl_body_requeue_log, 0,
			sizeof(fake_mcctrl_body_requeue_log));
	memset(fake_mcctrl_body_put_key_log, 0,
			sizeof(fake_mcctrl_body_put_key_log));
}

static int fake_mcctrl_body_get_key(unsigned long uaddr, int fshared,
		unsigned long key_addr, unsigned long ctx_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(ctx_addr != 0);
	require(fshared == 1);
	fake_mcctrl_body_get_key_calls++;
	if (uaddr == 0x505000UL || uaddr == 0x7000UL ||
			uaddr == 0x1000UL) {
		key->opaque[0] = 0x1111UL;
		key->opaque[1] = 0x2222UL;
		key->opaque[2] = 0x10UL;
		return 0;
	}
	require(uaddr == 0x8000UL || uaddr == 0x2000UL);
	if (fake_mcctrl_body_get_key2_ret)
		return fake_mcctrl_body_get_key2_ret;
	key->opaque[0] = 0x3333UL;
	key->opaque[1] = 0x4444UL;
	key->opaque[2] = 0x20UL;
	return 0;
}

static unsigned long fake_mcctrl_body_hash_key(unsigned long key_addr,
		unsigned long queue_addr)
{
	struct futex_key *key = (struct futex_key *)key_addr;

	require(queue_addr == 0xfeedbabeUL);
	fake_mcctrl_body_hash_calls++;
	if (key->opaque[0] == 0x1111UL)
		return (unsigned long)fake_mcctrl_body_source_bucket;
	require(key->opaque[0] == 0x3333UL);
	return (unsigned long)fake_mcctrl_body_target_bucket;
}

static unsigned long fake_mcctrl_body_wake_lock(unsigned long lock_addr)
{
	fake_mcctrl_body_wake_lock_calls++;
	fake_mcctrl_body_last_lock = lock_addr;
	return lock_addr ^ 0x13579bdfUL;
}

static void fake_mcctrl_body_wake_unlock(unsigned long lock_addr,
		unsigned long irqstate)
{
	fake_mcctrl_body_wake_unlock_calls++;
	fake_mcctrl_body_last_lock = lock_addr;
	fake_mcctrl_body_last_irqstate = irqstate;
}

static void fake_mcctrl_body_hb_lock(unsigned long lock_addr)
{
	fake_mcctrl_body_hb_lock_calls++;
	fake_mcctrl_body_last_lock = lock_addr;
}

static void fake_mcctrl_body_hb_unlock(unsigned long lock_addr)
{
	fake_mcctrl_body_hb_unlock_calls++;
	fake_mcctrl_body_last_lock = lock_addr;
}

static void fake_mcctrl_body_put_key(int fshared, unsigned long key_addr)
{
	require(fshared == 1);
	require(fake_mcctrl_body_put_key_calls < 8);
	fake_mcctrl_body_put_key_log[fake_mcctrl_body_put_key_calls++] =
		key_addr;
}

static void fake_mcctrl_body_wake_entry(unsigned long q_addr,
		unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;

	require(ctx_addr == (unsigned long)&fake_mcctrl_futex_uti);
	require(fake_mcctrl_body_wake_calls < 8);
	fake_mcctrl_body_wake_log[fake_mcctrl_body_wake_calls++] =
		q->linux_cpu;
	futex_wake_mark_woken_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));
}

static int fake_mcctrl_body_atomic_op(int op, unsigned long uaddr)
{
	require(op == 0x5a);
	require(uaddr == 0x8000UL);
	require(fake_mcctrl_body_atomic_calls < 4);
	return fake_mcctrl_body_atomic_seq[fake_mcctrl_body_atomic_calls++];
}

static int fake_mcctrl_body_get_value(unsigned long value_addr,
		unsigned long uaddr)
{
	require(uaddr == 0x1000UL);
	fake_mcctrl_body_get_value_calls++;
	*(unsigned int *)value_addr = fake_mcctrl_body_curval;
	return 0;
}

static void fake_mcctrl_body_drop_key_refs(unsigned long key_addr)
{
	require(key_addr != 0);
	fake_mcctrl_body_drop_key_calls++;
}

static void fake_mcctrl_body_key_ref(unsigned long key_addr)
{
	require(key_addr != 0);
	fake_mcctrl_body_key_ref_calls++;
}

static void fake_mcctrl_body_requeue_wake(unsigned long q_addr,
		unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_mcctrl_futex_requeue_ctx *ctx =
		(struct fake_mcctrl_futex_requeue_ctx *)ctx_addr;

	require(ctx->uti_info == &fake_mcctrl_futex_uti);
	require(fake_mcctrl_body_wake_calls < 8);
	fake_mcctrl_body_wake_log[fake_mcctrl_body_wake_calls++] =
		q->linux_cpu;
	futex_wake_mark_woken_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct plist_node, plist),
		offsetof(struct fake_futex_q, lock_ptr));
}

static void fake_mcctrl_body_requeue_move(unsigned long q_addr,
		unsigned long ctx_addr)
{
	struct fake_futex_q *q = (struct fake_futex_q *)q_addr;
	struct fake_mcctrl_futex_requeue_ctx *ctx =
		(struct fake_mcctrl_futex_requeue_ctx *)ctx_addr;

	require(ctx->hb1 == fake_mcctrl_body_source_bucket);
	require(ctx->hb2 == fake_mcctrl_body_target_bucket);
	require(ctx->key2 != NULL);
	require(fake_mcctrl_body_requeue_calls < 8);
	fake_mcctrl_body_requeue_log[fake_mcctrl_body_requeue_calls++] =
		q->linux_cpu;
	futex_requeue_move_result(q_addr,
		offsetof(struct fake_futex_q, list),
		offsetof(struct fake_futex_q, lock_ptr),
		(unsigned long)&ctx->hb1->chain,
		(unsigned long)&ctx->hb2->chain,
		(unsigned long)&ctx->hb2->lock, 0);
	futex_requeue_key_update_result(q_addr,
		offsetof(struct fake_futex_q, key),
		(unsigned long)ctx->key2, sizeof(*ctx->key2),
		fake_mcctrl_body_key_ref);
}

static int fake_sysfs_local_create(void *os,
		struct mcctrl_sysfs_req_create_param *param)
{
	fake_sysfs_local_create_calls++;
	fake_sysfs_local_create_os = os;
	fake_sysfs_local_create_param = param;
	return fake_sysfs_local_create_ret;
}

static int fake_sysfs_local_mkdir(void *os,
		struct mcctrl_sysfs_req_mkdir_param *param)
{
	fake_sysfs_local_mkdir_calls++;
	fake_sysfs_local_mkdir_os = os;
	fake_sysfs_local_mkdir_param = param;
	if (!fake_sysfs_local_mkdir_ret)
		param->handle = 0x6d6b646972UL;
	return fake_sysfs_local_mkdir_ret;
}

static int fake_sysfs_local_symlink(void *os,
		struct mcctrl_sysfs_req_symlink_param *param)
{
	fake_sysfs_local_symlink_calls++;
	fake_sysfs_local_symlink_os = os;
	fake_sysfs_local_symlink_param = param;
	return fake_sysfs_local_symlink_ret;
}

static int fake_sysfs_local_lookup(void *os,
		struct mcctrl_sysfs_req_lookup_param *param)
{
	fake_sysfs_local_lookup_calls++;
	fake_sysfs_local_lookup_os = os;
	fake_sysfs_local_lookup_param = param;
	if (!fake_sysfs_local_lookup_ret)
		param->handle = 0x6c6f6f6bUL;
	return fake_sysfs_local_lookup_ret;
}

static int fake_sysfs_local_unlink(void *os,
		struct mcctrl_sysfs_req_unlink_param *param)
{
	fake_sysfs_local_unlink_calls++;
	fake_sysfs_local_unlink_os = os;
	fake_sysfs_local_unlink_param = param;
	return fake_sysfs_local_unlink_ret;
}

static void *fake_sysfs_req_os_to_dev(void *os)
{
	fake_sysfs_req_os_to_dev_calls++;
	fake_sysfs_req_last_os = os;
	return (void *)0x5359534653524551UL;
}

static unsigned long fake_sysfs_req_map_memory(void *dev, unsigned long rpa,
		unsigned long size)
{
	require(dev == (void *)0x5359534653524551UL);
	fake_sysfs_req_map_memory_calls++;
	fake_sysfs_req_last_rpa = rpa;
	fake_sysfs_req_last_pa = rpa + 0x100000UL;
	fake_sysfs_req_last_size = size;
	return fake_sysfs_req_last_pa;
}

static void *fake_sysfs_req_map_virtual(void *dev, unsigned long pa,
		unsigned long size)
{
	require(dev == (void *)0x5359534653524551UL);
	fake_sysfs_req_map_virtual_calls++;
	fake_sysfs_req_last_pa = pa;
	fake_sysfs_req_last_size = size;
	if (fake_sysfs_req_fail_virtual_on_call ==
			fake_sysfs_req_map_virtual_calls)
		return NULL;
	fake_sysfs_req_last_virt = (void *)(uintptr_t)(pa - 0x100000UL);
	return fake_sysfs_req_last_virt;
}

static void fake_sysfs_req_unmap_virtual(void *dev, void *virt,
		unsigned long size)
{
	require(dev == (void *)0x5359534653524551UL);
	fake_sysfs_req_unmap_virtual_calls++;
	fake_sysfs_req_last_virt = virt;
	fake_sysfs_req_last_size = size;
}

static void fake_sysfs_req_unmap_memory(void *dev, unsigned long pa,
		unsigned long size)
{
	require(dev == (void *)0x5359534653524551UL);
	fake_sysfs_req_unmap_memory_calls++;
	fake_sysfs_req_last_pa = pa;
	fake_sysfs_req_last_size = size;
}

static void fake_sysfs_req_wmb(void)
{
	fake_sysfs_req_wmb_calls++;
}

static int fake_sysfs_req_setup_local(void *os, void *buf,
		unsigned long buf_pa, unsigned long bufsize)
{
	fake_sysfs_req_setup_local_calls++;
	fake_sysfs_req_setup_os = os;
	fake_sysfs_req_setup_buf = buf;
	fake_sysfs_req_setup_buf_pa = buf_pa;
	fake_sysfs_req_setup_bufsize = bufsize;
	return fake_sysfs_req_setup_local_ret;
}

static void fake_sysfs_local_cleanup_special(void *ops, void *instance)
{
	fake_sysfs_local_cleanup_calls++;
	fake_sysfs_local_cleanup_ops = ops;
	fake_sysfs_local_cleanup_instance = instance;
}

static void fake_sysfs_local_setup_failed(int error)
{
	fake_sysfs_local_setup_failed_calls++;
	fake_sysfs_local_setup_failed_error = error;
}

static struct fake_mcctrl_ptd fake_ptd_pool[8];
static int fake_ptd_alloc_calls;
static int fake_ptd_alloc_fail;
static unsigned long fake_ptd_alloc_size;
static int fake_ptd_free_calls;
static void *fake_ptd_freed[8];
static int fake_ptd_write_lock_calls;
static int fake_ptd_write_unlock_calls;
static int fake_ptd_read_lock_calls;
static int fake_ptd_read_unlock_calls;
static void *fake_ptd_last_lock;
static unsigned long fake_ptd_last_flags;
static int fake_ptd_log_calls;
static int fake_ptd_log_stage[8];
static int fake_ptd_log_value[8];
static void *fake_ptd_log_ptr[8];

static const struct mcctrl_syscall_ptd_offsets fake_ptd_offsets = {
	.ppd_thread_hash = offsetof(struct fake_mcctrl_ppd, thread_hash),
	.ppd_thread_lock = offsetof(struct fake_mcctrl_ppd, thread_lock),
	.ptd_ppd = offsetof(struct fake_mcctrl_ptd, ppd),
	.ptd_hash = offsetof(struct fake_mcctrl_ptd, hash),
	.ptd_task = offsetof(struct fake_mcctrl_ptd, task),
	.ptd_data = offsetof(struct fake_mcctrl_ptd, data),
	.ptd_tid = offsetof(struct fake_mcctrl_ptd, tid),
	.ptd_refcount = offsetof(struct fake_mcctrl_ptd, refcount),
	.list_head_size = sizeof(struct fake_mcctrl_list_head),
	.rwlock_size = sizeof(unsigned char),
};

static void fake_list_head_init(struct fake_mcctrl_list_head *head)
{
	head->next = head;
	head->prev = head;
}

static int fake_list_empty(struct fake_mcctrl_list_head *head)
{
	return head->next == head && head->prev == head;
}

static void fake_ptd_reset(struct fake_mcctrl_ppd *ppd)
{
	memset(fake_ptd_pool, 0, sizeof(fake_ptd_pool));
	fake_ptd_alloc_calls = 0;
	fake_ptd_alloc_fail = 0;
	fake_ptd_alloc_size = 0;
	fake_ptd_free_calls = 0;
	memset(fake_ptd_freed, 0, sizeof(fake_ptd_freed));
	fake_ptd_write_lock_calls = 0;
	fake_ptd_write_unlock_calls = 0;
	fake_ptd_read_lock_calls = 0;
	fake_ptd_read_unlock_calls = 0;
	fake_ptd_last_lock = NULL;
	fake_ptd_last_flags = 0;
	fake_ptd_log_calls = 0;
	memset(fake_ptd_log_stage, 0, sizeof(fake_ptd_log_stage));
	memset(fake_ptd_log_value, 0, sizeof(fake_ptd_log_value));
	memset(fake_ptd_log_ptr, 0, sizeof(fake_ptd_log_ptr));
	memset(ppd, 0, sizeof(*ppd));
	for (int i = 0; i < 256; i++)
		fake_list_head_init(&ppd->thread_hash[i]);
}

static void *fake_ptd_alloc(unsigned long size)
{
	fake_ptd_alloc_size = size;
	if (fake_ptd_alloc_fail)
		return NULL;
	return &fake_ptd_pool[fake_ptd_alloc_calls++];
}

static void fake_ptd_free(void *ptr)
{
	fake_ptd_freed[fake_ptd_free_calls++] = ptr;
}

static unsigned long fake_ptd_write_lock(void *lock)
{
	fake_ptd_write_lock_calls++;
	fake_ptd_last_lock = lock;
	return 0xabc000UL + fake_ptd_write_lock_calls;
}

static void fake_ptd_write_unlock(void *lock, unsigned long flags)
{
	require(lock == fake_ptd_last_lock);
	fake_ptd_write_unlock_calls++;
	fake_ptd_last_flags = flags;
}

static unsigned long fake_ptd_read_lock(void *lock)
{
	fake_ptd_read_lock_calls++;
	fake_ptd_last_lock = lock;
	return 0xdef000UL + fake_ptd_read_lock_calls;
}

static void fake_ptd_read_unlock(void *lock, unsigned long flags)
{
	require(lock == fake_ptd_last_lock);
	fake_ptd_read_unlock_calls++;
	fake_ptd_last_flags = flags;
}

static void fake_ptd_log(int stage, int value, void *ptd)
{
	fake_ptd_log_stage[fake_ptd_log_calls] = stage;
	fake_ptd_log_value[fake_ptd_log_calls] = value;
	fake_ptd_log_ptr[fake_ptd_log_calls] = ptd;
	fake_ptd_log_calls++;
}

static struct fake_mcctrl_list_head fake_pidfd_table[16];
static unsigned char fake_pidfd_lock_obj;
static struct fake_mcctrl_pidfd_entry fake_pidfd_pool[8];
static int fake_pidfd_alloc_calls;
static int fake_pidfd_alloc_fail;
static unsigned long fake_pidfd_alloc_size;
static int fake_pidfd_free_calls;
static void *fake_pidfd_freed[8];
static int fake_pidfd_lock_init_calls;
static int fake_pidfd_lock_calls;
static int fake_pidfd_unlock_calls;
static void *fake_pidfd_last_lock;
static unsigned long fake_pidfd_last_flags;
static int fake_pidfd_log_calls;
static int fake_pidfd_log_stage[8];
static void *fake_pidfd_log_filp[8];
static int fake_pidfd_log_pid[8];
static int fake_pidfd_log_fd[8];

static const struct mcctrl_syscall_pidfd_offsets fake_pidfd_offsets = {
	.entry_filp = offsetof(struct fake_mcctrl_pidfd_entry, filp),
	.entry_os = offsetof(struct fake_mcctrl_pidfd_entry, os),
	.entry_group_leader =
		offsetof(struct fake_mcctrl_pidfd_entry, group_leader),
	.entry_pid = offsetof(struct fake_mcctrl_pidfd_entry, pid),
	.entry_fd = offsetof(struct fake_mcctrl_pidfd_entry, fd),
	.entry_hash = offsetof(struct fake_mcctrl_pidfd_entry, hash),
	.entry_tofu_dev_path =
		offsetof(struct fake_mcctrl_pidfd_entry, tofu_dev_path),
	.entry_pde_data = offsetof(struct fake_mcctrl_pidfd_entry, pde_data),
	.list_head_size = sizeof(struct fake_mcctrl_list_head),
	.tofu_dev_path_size =
		sizeof(((struct fake_mcctrl_pidfd_entry *)0)->tofu_dev_path),
};

static void fake_pidfd_reset(void)
{
	memset(fake_pidfd_table, 0, sizeof(fake_pidfd_table));
	memset(fake_pidfd_pool, 0, sizeof(fake_pidfd_pool));
	fake_pidfd_lock_obj = 0;
	fake_pidfd_alloc_calls = 0;
	fake_pidfd_alloc_fail = 0;
	fake_pidfd_alloc_size = 0;
	fake_pidfd_free_calls = 0;
	memset(fake_pidfd_freed, 0, sizeof(fake_pidfd_freed));
	fake_pidfd_lock_init_calls = 0;
	fake_pidfd_lock_calls = 0;
	fake_pidfd_unlock_calls = 0;
	fake_pidfd_last_lock = NULL;
	fake_pidfd_last_flags = 0;
	fake_pidfd_log_calls = 0;
	memset(fake_pidfd_log_stage, 0, sizeof(fake_pidfd_log_stage));
	memset(fake_pidfd_log_filp, 0, sizeof(fake_pidfd_log_filp));
	memset(fake_pidfd_log_pid, 0, sizeof(fake_pidfd_log_pid));
	memset(fake_pidfd_log_fd, 0, sizeof(fake_pidfd_log_fd));
}

static void *fake_pidfd_alloc(unsigned long size)
{
	fake_pidfd_alloc_size = size;
	if (fake_pidfd_alloc_fail)
		return NULL;
	return &fake_pidfd_pool[fake_pidfd_alloc_calls++];
}

static void fake_pidfd_free(void *ptr)
{
	fake_pidfd_freed[fake_pidfd_free_calls++] = ptr;
}

static void fake_pidfd_lock_init(void *lock)
{
	require(lock == &fake_pidfd_lock_obj);
	fake_pidfd_lock_init_calls++;
	*(unsigned char *)lock = 1;
}

static unsigned long fake_pidfd_lock(void *lock)
{
	require(lock == &fake_pidfd_lock_obj);
	fake_pidfd_lock_calls++;
	fake_pidfd_last_lock = lock;
	return 0xbeef000UL + fake_pidfd_lock_calls;
}

static void fake_pidfd_unlock(void *lock, unsigned long flags)
{
	require(lock == fake_pidfd_last_lock);
	fake_pidfd_unlock_calls++;
	fake_pidfd_last_flags = flags;
}

static void fake_pidfd_log(int stage, void *filp, int pid, int fd)
{
	fake_pidfd_log_stage[fake_pidfd_log_calls] = stage;
	fake_pidfd_log_filp[fake_pidfd_log_calls] = filp;
	fake_pidfd_log_pid[fake_pidfd_log_calls] = pid;
	fake_pidfd_log_fd[fake_pidfd_log_calls] = fd;
	fake_pidfd_log_calls++;
}

static struct fake_mcctrl_pager fake_pager_pool[8];
static struct fake_mcctrl_list_head fake_pager_global_list;
static unsigned char fake_pager_lock_obj;
static int fake_pager_lock_calls;
static int fake_pager_unlock_calls;
static void *fake_pager_last_lock;
static unsigned long fake_pager_last_flags;
static int fake_pager_in_atomic_value;
static int fake_pager_in_interrupt_value;
static int fake_pager_down_calls;
static int fake_pager_down_ret;
static int fake_pager_up_calls;
static void *fake_pager_fput_ptrs[8];
static int fake_pager_fput_calls;
static void *fake_pager_freed[8];
static int fake_pager_free_calls;
static int fake_pager_log_calls;
static int fake_pager_log_stage[8];
static void *fake_pager_log_ptr[8];
static int fake_pager_log_value[8];

static const struct mcctrl_syscall_pager_offsets fake_pager_offsets = {
	.ppd_devobj_pager_list =
		offsetof(struct fake_mcctrl_pager_ppd, devobj_pager_list),
	.ppd_devobj_pager_lock =
		offsetof(struct fake_mcctrl_pager_ppd, devobj_pager_lock),
	.pager_list = offsetof(struct fake_mcctrl_pager, list),
	.pager_rofile = offsetof(struct fake_mcctrl_pager, rofile),
	.pager_rwfile = offsetof(struct fake_mcctrl_pager, rwfile),
};

static void fake_list_add_tail(struct fake_mcctrl_list_head *entry,
		struct fake_mcctrl_list_head *head)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static void fake_pager_reset(struct fake_mcctrl_pager_ppd *ppd)
{
	memset(fake_pager_pool, 0, sizeof(fake_pager_pool));
	fake_list_head_init(&fake_pager_global_list);
	fake_pager_lock_obj = 0;
	fake_pager_lock_calls = 0;
	fake_pager_unlock_calls = 0;
	fake_pager_last_lock = NULL;
	fake_pager_last_flags = 0;
	fake_pager_in_atomic_value = 0;
	fake_pager_in_interrupt_value = 0;
	fake_pager_down_calls = 0;
	fake_pager_down_ret = 0;
	fake_pager_up_calls = 0;
	memset(fake_pager_fput_ptrs, 0, sizeof(fake_pager_fput_ptrs));
	fake_pager_fput_calls = 0;
	memset(fake_pager_freed, 0, sizeof(fake_pager_freed));
	fake_pager_free_calls = 0;
	fake_pager_log_calls = 0;
	memset(fake_pager_log_stage, 0, sizeof(fake_pager_log_stage));
	memset(fake_pager_log_ptr, 0, sizeof(fake_pager_log_ptr));
	memset(fake_pager_log_value, 0, sizeof(fake_pager_log_value));
	memset(ppd, 0, sizeof(*ppd));
	fake_list_head_init(&ppd->devobj_pager_list);
}

static unsigned long fake_pager_lock(void *lock)
{
	require(lock == &fake_pager_lock_obj);
	fake_pager_lock_calls++;
	fake_pager_last_lock = lock;
	return 0xca11000UL + fake_pager_lock_calls;
}

static void fake_pager_unlock(void *lock, unsigned long flags)
{
	require(lock == fake_pager_last_lock);
	fake_pager_unlock_calls++;
	fake_pager_last_flags = flags;
}

static int fake_pager_in_atomic(void)
{
	return fake_pager_in_atomic_value;
}

static int fake_pager_in_interrupt(void)
{
	return fake_pager_in_interrupt_value;
}

static int fake_pager_down(void *sem)
{
	require(sem != NULL);
	fake_pager_down_calls++;
	return fake_pager_down_ret;
}

static void fake_pager_up(void *sem)
{
	require(sem != NULL);
	fake_pager_up_calls++;
}

static void fake_pager_fput(void *ptr)
{
	fake_pager_fput_ptrs[fake_pager_fput_calls++] = ptr;
}

static void fake_pager_free(void *ptr)
{
	fake_pager_freed[fake_pager_free_calls++] = ptr;
}

static void fake_pager_log(int stage, void *pager, int value)
{
	fake_pager_log_stage[fake_pager_log_calls] = stage;
	fake_pager_log_ptr[fake_pager_log_calls] = pager;
	fake_pager_log_value[fake_pager_log_calls] = value;
	fake_pager_log_calls++;
}

static int fake_futex_cache_link_calls;
static int fake_futex_cache_insert_calls;
static int fake_futex_cache_erase_calls;
static int fake_futex_cache_free_calls;

static void fake_futex_cache_reset(void)
{
	fake_futex_cache_link_calls = 0;
	fake_futex_cache_insert_calls = 0;
	fake_futex_cache_erase_calls = 0;
	fake_futex_cache_free_calls = 0;
}

static void fake_futex_rb_link_node(void *node0, void *parent0,
		void *link0)
{
	struct mcctrl_rb_node *node = node0;
	struct mcctrl_rb_node **link = link0;

	node->parent_color = (unsigned long)parent0;
	node->left = NULL;
	node->right = NULL;
	*link = node;
	fake_futex_cache_link_calls++;
}

static void fake_futex_rb_insert_color(void *node, void *root)
{
	(void)node;
	(void)root;
	fake_futex_cache_insert_calls++;
}

static void *fake_futex_rb_first(void *root0)
{
	struct mcctrl_rb_root *root = root0;

	return root->node;
}

static void fake_futex_rb_erase(void *node0, void *root0)
{
	struct mcctrl_rb_node *node = node0;
	struct mcctrl_rb_root *root = root0;

	if (root->node == node)
		root->node = node->right;
	fake_futex_cache_erase_calls++;
}

static void fake_futex_cache_free(void *ptr)
{
	struct fake_rva_to_rpa_cache_node *node = ptr;

	node->freed = 1;
	fake_futex_cache_free_calls++;
}

int main(void)
{
	unsigned long long digest = 0xfeedface12345678ULL;
	void *procfs_result;

	{
		struct fake_mcctrl_ppd ppd;
		struct fake_mcctrl_ptd *ptd;
		void *task = (void *)0x1010UL;
		void *data = (void *)0xdada0001UL;
		int hash;
		int ret;

		fake_ptd_reset(&ppd);
		hash = mcctrl_syscall_ptd_hash_result(task, 255);
		require(hash == 1);
		ret = mcctrl_syscall_add_ptd_body_result(
			&ppd, data, task, 101, sizeof(*ptd), 255,
			&fake_ptd_offsets, fake_ptd_alloc, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log);
		require(ret == 0);
		require(fake_ptd_alloc_calls == 1);
		require(fake_ptd_alloc_size == sizeof(*ptd));
		require(fake_ptd_write_lock_calls == 1);
		require(fake_ptd_write_unlock_calls == 1);
		ptd = &fake_ptd_pool[0];
		require(ptd->ppd == &ppd);
		require(ptd->task == task);
		require(ptd->data == data);
		require(ptd->tid == 101);
		require(ptd->refcount == 1);
		require(ppd.thread_hash[hash].next == &ptd->hash);
		require(ppd.thread_hash[hash].prev == &ptd->hash);
		require(fake_ptd_log_calls == 0);

		require(mcctrl_syscall_get_ptd_body_result(
			&ppd, task, 255, &fake_ptd_offsets,
			fake_ptd_read_lock, fake_ptd_read_unlock,
			fake_ptd_log) == ptd);
		require(ptd->refcount == 2);
		require(fake_ptd_read_lock_calls == 1);
		require(fake_ptd_read_unlock_calls == 1);

		require(mcctrl_syscall_put_ptd_body_result(
			ptd, 255, &fake_ptd_offsets, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log) == 0);
		require(ptd->refcount == 1);
		require(fake_ptd_free_calls == 0);
		require(mcctrl_syscall_put_ptd_body_result(
			ptd, 255, &fake_ptd_offsets, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log) == 1);
		require(fake_ptd_free_calls == 1);
		require(fake_ptd_freed[0] == ptd);
		require(fake_list_empty(&ppd.thread_hash[hash]));
		mix_signed(&digest, hash);
		mix_signed(&digest, fake_ptd_write_unlock_calls);
	}

	{
		struct fake_mcctrl_ppd ppd;
		struct fake_mcctrl_ptd stray;
		void *task = (void *)0x2020UL;
		int ret;

		fake_ptd_reset(&ppd);
		ret = mcctrl_syscall_add_ptd_body_result(
			&ppd, (void *)0xabcdUL, task, 202,
			sizeof(struct fake_mcctrl_ptd), 255,
			&fake_ptd_offsets, fake_ptd_alloc, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log);
		require(ret == 0);
		ret = mcctrl_syscall_add_ptd_body_result(
			&ppd, (void *)0xeeeeUL, task, 202,
			sizeof(struct fake_mcctrl_ptd), 255,
			&fake_ptd_offsets, fake_ptd_alloc, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log);
		require(ret == -16);
		require(fake_ptd_alloc_calls == 2);
		require(fake_ptd_free_calls == 1);
		require(fake_ptd_freed[0] == &fake_ptd_pool[1]);
		require(fake_ptd_log_calls == 1);
		require(fake_ptd_log_stage[0] == 3);
		require(fake_ptd_log_value[0] == 202);
		mix_signed(&digest, fake_ptd_log_stage[0]);

		fake_ptd_reset(&ppd);
		memset(&stray, 0, sizeof(stray));
		stray.ppd = &ppd;
		stray.task = task;
		stray.refcount = 1;
		fake_list_head_init(&stray.hash);
		ret = mcctrl_syscall_put_ptd_body_result(
			&stray, 255, &fake_ptd_offsets, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log);
		require(ret == -2);
		require(fake_ptd_log_calls == 1);
		require(fake_ptd_log_stage[0] == 1);
		require(fake_ptd_free_calls == 0);
		mix_signed(&digest, ret);
	}

	{
		struct fake_mcctrl_ppd ppd;
		struct fake_mcctrl_ptd stray;
		void *task = (void *)0x3030UL;

		fake_ptd_reset(&ppd);
		require(mcctrl_syscall_add_ptd_body_result(
			&ppd, (void *)0x303000UL, task, 303,
			sizeof(struct fake_mcctrl_ptd), 255,
			&fake_ptd_offsets, fake_ptd_alloc, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log) == 0);
		fake_ptd_pool[0].refcount = 0;
		require(mcctrl_syscall_get_ptd_body_result(
			&ppd, task, 255, &fake_ptd_offsets,
			fake_ptd_read_lock, fake_ptd_read_unlock,
			fake_ptd_log) == NULL);
		require(fake_ptd_log_calls == 1);
		require(fake_ptd_log_stage[0] == 4);
		require(fake_ptd_log_value[0] == 0);
		mix_signed(&digest, fake_ptd_log_stage[0]);

		fake_ptd_reset(&ppd);
		memset(&stray, 0, sizeof(stray));
		stray.refcount = 0;
		fake_list_head_init(&stray.hash);
		require(mcctrl_syscall_put_ptd_unsafe_body_result(
			&stray, &fake_ptd_offsets, fake_ptd_free,
			fake_ptd_log) == 0);
		require(stray.refcount == -1);
		require(fake_ptd_log_calls == 1);
		require(fake_ptd_log_stage[0] == 0);
		require(fake_ptd_log_value[0] == -1);

		require(mcctrl_syscall_add_ptd_body_result(
			&ppd, NULL, task, 303,
			sizeof(struct fake_mcctrl_ptd), 255,
			&fake_ptd_offsets, NULL, fake_ptd_free,
			fake_ptd_write_lock, fake_ptd_write_unlock,
			fake_ptd_log) == -22);
		require(mcctrl_syscall_get_ptd_body_result(
			&ppd, task, 255, &fake_ptd_offsets,
			NULL, fake_ptd_read_unlock, fake_ptd_log) == NULL);
		mix_signed(&digest, stray.refcount);
	}

	{
		void *filp = (void *)0x1234UL;
		void *group = (void *)0x5678UL;
		void *pde_data = (void *)0x9abcUL;
		struct fake_mcctrl_pidfd_entry *entry;
		int hash = ((unsigned long)filp) & 15;
		int ret;

		fake_pidfd_reset();
		require(mcctrl_syscall_pidfd_hash_init_body_result(
			fake_pidfd_table, 16, sizeof(fake_pidfd_table[0]),
			&fake_pidfd_lock_obj, fake_pidfd_lock_init) == 0);
		require(fake_pidfd_lock_init_calls == 1);
		require(fake_pidfd_lock_obj == 1);
		for (int i = 0; i < 16; i++)
			require(fake_list_empty(&fake_pidfd_table[i]));

		ret = mcctrl_syscall_pidfd_hash_insert_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp,
			0xfeed0001UL, 321, group, 7,
			"/proc/tofu/dev/tni1cq2", pde_data, sizeof(*entry), 15,
			&fake_pidfd_offsets, fake_pidfd_alloc, fake_pidfd_free,
			fake_pidfd_lock, fake_pidfd_unlock, fake_pidfd_log);
		require(ret == 0);
		require(fake_pidfd_alloc_calls == 1);
		require(fake_pidfd_alloc_size == sizeof(*entry));
		require(fake_pidfd_lock_calls == 1);
		require(fake_pidfd_unlock_calls == 1);
		entry = &fake_pidfd_pool[0];
		require(entry->filp == filp);
		require(entry->os == 0xfeed0001UL);
		require(entry->group_leader == group);
		require(entry->pid == 321);
		require(entry->fd == 7);
		require(entry->pde_data == pde_data);
		require(strcmp(entry->tofu_dev_path, "tni1cq2") == 0);
		require(fake_pidfd_table[hash].next == &entry->hash);
		require(fake_pidfd_table[hash].prev == &entry->hash);
		require(fake_pidfd_log_calls == 1);
		require(fake_pidfd_log_stage[0] == 1);

		require(mcctrl_syscall_pidfd_hash_lookup_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp, group, 15,
			&fake_pidfd_offsets, fake_pidfd_lock,
			fake_pidfd_unlock, fake_pidfd_log) == entry);
		require(fake_pidfd_log_calls == 2);
		require(fake_pidfd_log_stage[1] == 2);
		require(fake_pidfd_log_pid[1] == 321);

		ret = mcctrl_syscall_pidfd_hash_insert_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp,
			0xfeed0001UL, 654, group, 8,
			"/proc/tofu/dev/tni9cq9", pde_data, sizeof(*entry), 15,
			&fake_pidfd_offsets, fake_pidfd_alloc, fake_pidfd_free,
			fake_pidfd_lock, fake_pidfd_unlock, fake_pidfd_log);
		require(ret == -16);
		require(fake_pidfd_alloc_calls == 2);
		require(fake_pidfd_free_calls == 1);
		require(fake_pidfd_freed[0] == &fake_pidfd_pool[1]);
		require(fake_pidfd_log_calls == 3);
		require(fake_pidfd_log_stage[2] == 0);
		require(fake_pidfd_log_pid[2] == 654);

		ret = mcctrl_syscall_pidfd_hash_remove_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp,
			0xfeed0001UL, group, 7, 15, &fake_pidfd_offsets,
			fake_pidfd_free, fake_pidfd_lock,
			fake_pidfd_unlock, fake_pidfd_log);
		require(ret == 0);
		require(fake_pidfd_free_calls == 2);
		require(fake_pidfd_freed[1] == entry);
		require(fake_list_empty(&fake_pidfd_table[hash]));
		require(fake_pidfd_log_calls == 4);
		require(fake_pidfd_log_stage[3] == 3);

		ret = mcctrl_syscall_pidfd_hash_remove_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp,
			0xfeed0001UL, group, 7, 15, &fake_pidfd_offsets,
			fake_pidfd_free, fake_pidfd_lock,
			fake_pidfd_unlock, fake_pidfd_log);
		require(ret == -2);
		require(fake_pidfd_free_calls == 2);
		require(fake_pidfd_log_calls == 5);
		require(fake_pidfd_log_stage[4] == 4);

		require(mcctrl_syscall_pidfd_hash_init_body_result(
			fake_pidfd_table, 16, sizeof(fake_pidfd_table[0]),
			&fake_pidfd_lock_obj, NULL) == -22);
		fake_pidfd_alloc_fail = 1;
		require(mcctrl_syscall_pidfd_hash_insert_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp,
			0xfeed0001UL, 321, group, 7,
			"/proc/tofu/dev/tni1cq2", pde_data, sizeof(*entry), 15,
			&fake_pidfd_offsets, fake_pidfd_alloc, fake_pidfd_free,
			fake_pidfd_lock, fake_pidfd_unlock, fake_pidfd_log) == -12);
		require(mcctrl_syscall_pidfd_hash_lookup_body_result(
			fake_pidfd_table, &fake_pidfd_lock_obj, filp, group, 15,
			&fake_pidfd_offsets, NULL,
			fake_pidfd_unlock, fake_pidfd_log) == NULL);
		mix_signed(&digest, hash);
		mix_signed(&digest, fake_pidfd_log_stage[4]);
		mix_signed(&digest, fake_pidfd_free_calls);
	}

	{
		struct fake_mcctrl_pager_ppd ppd;
		int nr_processes = 2;
		int ret;

		fake_pager_reset(&ppd);
		ret = mcctrl_syscall_pager_add_process_body_result(
			&nr_processes, &fake_pager_lock_obj,
			fake_pager_lock, fake_pager_unlock);
		require(ret == 3);
		require(nr_processes == 3);
		require(fake_pager_lock_calls == 1);
		require(fake_pager_unlock_calls == 1);

		fake_list_add_tail(&fake_pager_pool[0].list,
			&ppd.devobj_pager_list);
		fake_list_add_tail(&fake_pager_pool[1].list,
			&ppd.devobj_pager_list);
		ret = mcctrl_syscall_pager_remove_process_body_result(
			&ppd, &nr_processes, &fake_pager_lock_obj,
			&fake_pager_offsets, fake_pager_in_atomic,
			fake_pager_in_interrupt, fake_pager_down, fake_pager_up,
			fake_pager_free, fake_pager_lock, fake_pager_unlock,
			fake_pager_log);
		require(ret == 2);
		require(nr_processes == 2);
		require(fake_pager_down_calls == 1);
		require(fake_pager_up_calls == 1);
		require(fake_pager_free_calls == 2);
		require(fake_pager_freed[0] == &fake_pager_pool[0]);
		require(fake_pager_freed[1] == &fake_pager_pool[1]);
		require(fake_list_empty(&ppd.devobj_pager_list));
		require(fake_pager_log_calls == 3);
		require(fake_pager_log_stage[0] == 1);
		require(fake_pager_log_stage[1] == 1);
		require(fake_pager_log_stage[2] == 3);

		fake_pager_reset(&ppd);
		nr_processes = 4;
		fake_pager_in_atomic_value = 1;
		ret = mcctrl_syscall_pager_remove_process_body_result(
			&ppd, &nr_processes, &fake_pager_lock_obj,
			&fake_pager_offsets, fake_pager_in_atomic,
			fake_pager_in_interrupt, fake_pager_down, fake_pager_up,
			fake_pager_free, fake_pager_lock, fake_pager_unlock,
			fake_pager_log);
		require(ret == -22);
		require(nr_processes == 4);
		require(fake_pager_down_calls == 0);
		require(fake_pager_log_calls == 1);
		require(fake_pager_log_stage[0] == 0);

		fake_pager_reset(&ppd);
		nr_processes = 4;
		fake_pager_down_ret = -4;
		ret = mcctrl_syscall_pager_remove_process_body_result(
			&ppd, &nr_processes, &fake_pager_lock_obj,
			&fake_pager_offsets, fake_pager_in_atomic,
			fake_pager_in_interrupt, fake_pager_down, fake_pager_up,
			fake_pager_free, fake_pager_lock, fake_pager_unlock,
			fake_pager_log);
		require(ret == -4);
		require(nr_processes == 4);
		require(fake_pager_down_calls == 1);
		require(fake_pager_up_calls == 0);

		fake_pager_reset(&ppd);
		fake_pager_pool[0].rofile = (void *)0x1111UL;
		fake_pager_pool[0].rwfile = (void *)0x2222UL;
		fake_pager_pool[1].rwfile = (void *)0x3333UL;
		fake_list_add_tail(&fake_pager_pool[0].list,
			&fake_pager_global_list);
		fake_list_add_tail(&fake_pager_pool[1].list,
			&fake_pager_global_list);
		ret = mcctrl_syscall_pager_cleanup_body_result(
			&fake_pager_global_list, &fake_pager_lock_obj,
			&fake_pager_offsets, fake_pager_fput, fake_pager_free,
			fake_pager_lock, fake_pager_unlock, fake_pager_log);
		require(ret == 2);
		require(fake_pager_fput_calls == 3);
		require(fake_pager_fput_ptrs[0] == (void *)0x1111UL);
		require(fake_pager_fput_ptrs[1] == (void *)0x2222UL);
		require(fake_pager_fput_ptrs[2] == (void *)0x3333UL);
		require(fake_pager_free_calls == 2);
		require(fake_pager_freed[0] == &fake_pager_pool[0]);
		require(fake_pager_freed[1] == &fake_pager_pool[1]);
		require(fake_list_empty(&fake_pager_global_list));
		require(fake_pager_log_calls == 2);
		require(fake_pager_log_stage[0] == 2);
		require(fake_pager_log_stage[1] == 2);

		require(mcctrl_syscall_pager_add_process_body_result(
			&nr_processes, &fake_pager_lock_obj,
			NULL, fake_pager_unlock) == -22);
		require(mcctrl_syscall_pager_cleanup_body_result(
			&fake_pager_global_list, &fake_pager_lock_obj,
			&fake_pager_offsets, fake_pager_fput, NULL,
			fake_pager_lock, fake_pager_unlock,
			fake_pager_log) == -22);
		mix_signed(&digest, nr_processes);
		mix_signed(&digest, fake_pager_fput_calls);
		mix_signed(&digest, fake_pager_log_stage[1]);
	}

	{
		struct mcctrl_rb_root root = { NULL };
		struct fake_rva_to_rpa_cache_node nodes[4];

		memset(nodes, 0, sizeof(nodes));
		nodes[0].rva = 0x3000;
		nodes[0].rpa = 0xa000;
		nodes[1].rva = 0x1000;
		nodes[1].rpa = 0xb000;
		nodes[2].rva = 0x5000;
		nodes[2].rpa = 0xc000;
		nodes[3].rva = 0x3000;
		nodes[3].rpa = 0xd000;
		fake_futex_cache_reset();
		require(mcctrl_rva_to_rpa_cache_insert_body_result(
			&root, &nodes[0], fake_futex_rb_link_node,
			fake_futex_rb_insert_color) == 0);
		require(mcctrl_rva_to_rpa_cache_insert_body_result(
			&root, &nodes[1], fake_futex_rb_link_node,
			fake_futex_rb_insert_color) == 0);
		require(mcctrl_rva_to_rpa_cache_insert_body_result(
			&root, &nodes[2], fake_futex_rb_link_node,
			fake_futex_rb_insert_color) == 0);
		require(mcctrl_rva_to_rpa_cache_insert_body_result(
			&root, &nodes[3], fake_futex_rb_link_node,
			fake_futex_rb_insert_color) == -22);
		require(fake_futex_cache_link_calls == 3);
		require(fake_futex_cache_insert_calls == 3);
		require(mcctrl_rva_to_rpa_cache_search_body_result(
			&root, 0x1000) == &nodes[1]);
		require(mcctrl_rva_to_rpa_cache_search_body_result(
			&root, 0x5000) == &nodes[2]);
		require(mcctrl_rva_to_rpa_cache_search_body_result(
			&root, 0x4000) == NULL);
		mix_signed(&digest, fake_futex_cache_link_calls);
		mix(&digest, nodes[1].rpa);
	}

	{
		struct mcctrl_rb_root root = { NULL };
		struct fake_rva_to_rpa_cache_node nodes[2];

		memset(nodes, 0, sizeof(nodes));
		root.node = &nodes[0].node;
		nodes[0].node.right = &nodes[1].node;
		fake_futex_cache_reset();
		require(mcctrl_futex_remove_process_body_result(
			&root, fake_futex_rb_first, fake_futex_rb_erase,
			fake_futex_cache_free) == 0);
		require(root.node == NULL);
		require(nodes[0].freed == 1);
		require(nodes[1].freed == 1);
		require(fake_futex_cache_erase_calls == 2);
		require(fake_futex_cache_free_calls == 2);
		mix_signed(&digest, fake_futex_cache_free_calls);
	}

	{
		uint32_t uaddr = 0;
		uint32_t uaddr2 = 0;
		int ret;

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAIT, 0x22, 0x3333, &uaddr2,
			0x44, 0x55, 1, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == 100 + (int)(FUTEX_BITSET_MATCH_ANY & 0xffU));
		require(fake_mcctrl_futex_dispatch.wait_calls == 1);
		require(fake_mcctrl_futex_dispatch.val3 ==
				FUTEX_BITSET_MATCH_ANY);
		require(fake_mcctrl_futex_dispatch.clockrt == 0);
		mix_signed(&digest, ret);
		mix(&digest, fake_mcctrl_futex_dispatch.val3);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAIT_BITSET | FUTEX_CLOCK_REALTIME,
			0x23, 0x3334, &uaddr2, 0x45, 0x5a, 0,
			&fake_mcctrl_futex_uti, fake_mcctrl_futex_wait,
			fake_mcctrl_futex_wake, fake_mcctrl_futex_requeue,
			fake_mcctrl_futex_wake_op, fake_mcctrl_futex_warn);
		require(ret == 100 + 0x5a + 1);
		require(fake_mcctrl_futex_dispatch.wait_calls == 1);
		require(fake_mcctrl_futex_dispatch.clockrt == 1);
		require(fake_mcctrl_futex_dispatch.fshared == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_mcctrl_futex_dispatch.clockrt);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAKE, 0x24, 0x3335, &uaddr2,
			0x46, 0x57, 1, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == 200 + (int)(FUTEX_BITSET_MATCH_ANY & 0xffU));
		require(fake_mcctrl_futex_dispatch.wake_calls == 1);
		require(fake_mcctrl_futex_dispatch.val3 ==
				FUTEX_BITSET_MATCH_ANY);
		mix_signed(&digest, ret);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_CMP_REQUEUE, 2, 0x3336, &uaddr2,
			3, 0x58, 1, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == 305);
		require(fake_mcctrl_futex_dispatch.requeue_calls == 1);
		require(fake_mcctrl_futex_dispatch.uaddr2 == &uaddr2);
		require(fake_mcctrl_futex_dispatch.cmpval == 0);
		mix_signed(&digest, ret);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAKE_OP, 4, 0x3337, &uaddr2,
			5, 6, 0, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == 415);
		require(fake_mcctrl_futex_dispatch.wake_op_calls == 1);
		require(fake_mcctrl_futex_dispatch.val3 == 6);
		mix_signed(&digest, ret);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAKE | FUTEX_CLOCK_REALTIME, 0, 0,
			&uaddr2, 0, 0, 0, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == -ENOSYS);
		require(fake_mcctrl_futex_dispatch.warn_calls == 0);
		mix_signed(&digest, ret);

		reset_fake_work();
		ret = mcctrl_futex_dispatch_body_result(
			&uaddr, FUTEX_WAIT_REQUEUE_PI, 0, 0, &uaddr2,
			0, 0, 0, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_wait, fake_mcctrl_futex_wake,
			fake_mcctrl_futex_requeue, fake_mcctrl_futex_wake_op,
			fake_mcctrl_futex_warn);
		require(ret == -ENOSYS);
		require(fake_mcctrl_futex_dispatch.warn_calls == 1);
		require(fake_mcctrl_futex_dispatch.warn_cmd ==
				FUTEX_WAIT_REQUEUE_PI);
		mix_signed(&digest, fake_mcctrl_futex_dispatch.warn_cmd);
	}

	{
		uint32_t uaddr = 0;
		int ret;

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_uti.resp = (void *)0x51525354UL;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x66, 0, 0, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == -EINVAL);
		require(fake_mcctrl_futex_prepare_calls == 0);
		mix_signed(&digest, ret);

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_uti.resp = (void *)0x51525354UL;
		fake_mcctrl_futex_setup_ret[0] = -7;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x67, 0, 0x77, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == -7);
		require(fake_mcctrl_futex_prepare_calls == 1);
		require(fake_mcctrl_futex_q.bitset == 0x77);
		require(fake_mcctrl_futex_q.resp == (void *)0x51525354UL);
		require(fake_mcctrl_futex_q.linux_cpu == 7);
		require(fake_mcctrl_futex_setup_calls == 1);
		require(fake_mcctrl_futex_queue_calls == 0);
		require(fake_mcctrl_futex_put_key_calls == 0);
		mix_signed(&digest, ret);

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_uti.resp = (void *)0x61626364UL;
		fake_mcctrl_futex_unqueue_ret[0] = 0;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x68, 0, 0x78, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == 0);
		require(fake_mcctrl_futex_queue_calls == 1);
		require(fake_mcctrl_futex_put_key_calls == 1);
		require(fake_mcctrl_futex_log_calls == 1);
		require(fake_mcctrl_futex_log_stage[0] == 0);
		require(fake_mcctrl_futex_last_put_q == &fake_mcctrl_futex_q);
		mix_signed(&digest, fake_mcctrl_futex_log_stage[0]);

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_unqueue_ret[0] = 1;
		fake_mcctrl_futex_queue_ret[0] = 0;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x69, 99, 0x79, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == -ETIMEDOUT);
		require(fake_mcctrl_futex_log_stage[0] == 1);
		require(fake_mcctrl_futex_last_timeout == 99);
		mix_signed(&digest, ret);

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_unqueue_ret[0] = 1;
		fake_mcctrl_futex_queue_ret[0] = -512;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x6a, 0, 0x7a, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == -EINTR);
		require(fake_mcctrl_futex_log_stage[0] == 2);
		mix_signed(&digest, ret);

		reset_fake_work();
		fake_mcctrl_futex_uti.q = &fake_mcctrl_futex_q;
		fake_mcctrl_futex_unqueue_ret[0] = 1;
		fake_mcctrl_futex_queue_ret[0] = 5;
		fake_mcctrl_futex_setup_ret[1] = -6;
		ret = mcctrl_futex_wait_body_result(
			&uaddr, 1, 0x6b, 0, 0x7b, &fake_mcctrl_futex_uti,
			fake_mcctrl_futex_get_q, fake_mcctrl_futex_get_resp,
			fake_mcctrl_futex_get_cpu, fake_mcctrl_futex_prepare_q,
			fake_mcctrl_futex_wait_setup,
			fake_mcctrl_futex_wait_queue,
			fake_mcctrl_futex_unqueue,
			fake_mcctrl_futex_put_q_key,
			fake_mcctrl_futex_log_event);
		require(ret == -6);
		require(fake_mcctrl_futex_setup_calls == 2);
		require(fake_mcctrl_futex_put_key_calls == 1);
		mix_signed(&digest, fake_mcctrl_futex_setup_calls);
	}

	{
		struct fake_wake_body_bucket bucket = { 0 };
		struct fake_futex_q first = { 0 };
		struct fake_futex_q second = { 0 };
		struct fake_futex_q third = { 0 };
		struct futex_key key = { { 0 } };
		int ret;

		plist_head_init(&bucket.chain);
		bucket.lock = 0x51525354UL;
		plist_node_init(&first.list, 1);
		plist_node_init(&second.list, 2);
		plist_node_init(&third.list, 3);
		first.lock_ptr = (void *)0x1111UL;
		second.lock_ptr = (void *)0x2222UL;
		third.lock_ptr = (void *)0x3333UL;
		first.key.opaque[0] = second.key.opaque[0] = 0x1111UL;
		first.key.opaque[1] = second.key.opaque[1] = 0x2222UL;
		first.key.opaque[2] = second.key.opaque[2] = 0x10UL;
		third.key.opaque[0] = 0x3333UL;
		third.key.opaque[1] = 0x4444UL;
		third.key.opaque[2] = 0x20UL;
		first.bitset = 0x1;
		second.bitset = 0x4;
		third.bitset = 0x1;
		first.linux_cpu = 11;
		second.linux_cpu = 22;
		third.linux_cpu = 33;
		plist_add(&first.list, &bucket.chain);
		plist_add(&second.list, &bucket.chain);
		plist_add(&third.list, &bucket.chain);

		fake_mcctrl_body_reset();
		fake_mcctrl_body_source_bucket = &bucket;
		ret = mcctrl_futex_wake_body_result(0x505000UL, 1, 1,
			0x1, (unsigned long)&key, 0xfeedbabeUL,
			(unsigned long)&fake_mcctrl_futex_uti,
			offsetof(struct fake_wake_body_bucket, lock),
			offsetof(struct fake_wake_body_bucket, chain),
			offsetof(struct fake_futex_q, list),
			offsetof(struct fake_futex_q, key),
			offsetof(struct fake_futex_q, bitset),
			offsetof(struct futex_key, opaque[0]),
			offsetof(struct futex_key, opaque[1]),
			offsetof(struct futex_key, opaque[2]),
			fake_mcctrl_body_get_key,
			fake_mcctrl_body_hash_key,
			fake_mcctrl_body_wake_lock,
			fake_mcctrl_body_wake_unlock,
			fake_mcctrl_body_put_key,
			fake_mcctrl_body_wake_entry);
		require(ret == 1);
		require(fake_mcctrl_body_get_key_calls == 1);
		require(fake_mcctrl_body_hash_calls == 1);
		require(fake_mcctrl_body_wake_lock_calls == 1);
		require(fake_mcctrl_body_wake_unlock_calls == 1);
		require(fake_mcctrl_body_put_key_calls == 1);
		require(fake_mcctrl_body_wake_log[0] == 11);
		require(plist_node_empty(&first.list));
		require(!plist_node_empty(&second.list));
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_mcctrl_body_wake_log[0]);
		mix(&digest, fake_mcctrl_body_last_irqstate);
	}

	{
		struct fake_wake_body_bucket source = { 0 };
		struct fake_wake_body_bucket target = { 0 };
		struct fake_futex_q first = { 0 };
		struct fake_futex_q second = { 0 };
		struct futex_key key1 = { { 0 } };
		struct futex_key key2 = { { 0 } };
		int ret;

		plist_head_init(&source.chain);
		plist_head_init(&target.chain);
		source.lock = 0x61626364UL;
		target.lock = 0x71727374UL;
		plist_node_init(&first.list, 1);
		plist_node_init(&second.list, 2);
		first.lock_ptr = (void *)0x1111UL;
		second.lock_ptr = (void *)0x2222UL;
		first.key.opaque[0] = 0x1111UL;
		first.key.opaque[1] = 0x2222UL;
		first.key.opaque[2] = 0x10UL;
		second.key.opaque[0] = 0x3333UL;
		second.key.opaque[1] = 0x4444UL;
		second.key.opaque[2] = 0x20UL;
		first.linux_cpu = 44;
		second.linux_cpu = 55;
		plist_add(&first.list, &source.chain);
		plist_add(&second.list, &target.chain);

		fake_mcctrl_body_reset();
		fake_mcctrl_body_source_bucket = &source;
		fake_mcctrl_body_target_bucket = &target;
		fake_mcctrl_body_atomic_seq[0] = 1;
		ret = mcctrl_futex_wake_op_body_result(0x7000UL, 1,
			0x8000UL, 1, 1, 0x5a, (unsigned long)&key1,
			(unsigned long)&key2, 0xfeedbabeUL,
			(unsigned long)&fake_mcctrl_futex_uti,
			offsetof(struct fake_wake_body_bucket, lock),
			offsetof(struct fake_wake_body_bucket, chain),
			offsetof(struct fake_futex_q, list),
			offsetof(struct fake_futex_q, key),
			offsetof(struct fake_futex_q, bitset),
			offsetof(struct futex_key, opaque[0]),
			offsetof(struct futex_key, opaque[1]),
			offsetof(struct futex_key, opaque[2]),
			fake_mcctrl_body_get_key,
			fake_mcctrl_body_hash_key,
			fake_mcctrl_body_hb_lock,
			fake_mcctrl_body_hb_unlock,
			fake_mcctrl_body_atomic_op,
			fake_mcctrl_body_put_key,
			fake_mcctrl_body_wake_entry);
		require(ret == 2);
		require(fake_mcctrl_body_hb_lock_calls == 2);
		require(fake_mcctrl_body_hb_unlock_calls == 2);
		require(fake_mcctrl_body_atomic_calls == 1);
		require(fake_mcctrl_body_put_key_calls == 2);
		require(fake_mcctrl_body_wake_log[0] == 44);
		require(fake_mcctrl_body_wake_log[1] == 55);
		require(plist_node_empty(&first.list));
		require(plist_node_empty(&second.list));
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_mcctrl_body_wake_log[1]);
	}

	{
		struct fake_wake_body_bucket source = { 0 };
		struct fake_wake_body_bucket target = { 0 };
		struct fake_futex_q first = { 0 };
		struct fake_futex_q second = { 0 };
		struct fake_futex_q third = { 0 };
		struct futex_key key1 = { { 0 } };
		struct futex_key key2 = { { 0 } };
		struct fake_mcctrl_futex_requeue_ctx ctx = {
			.uti_info = &fake_mcctrl_futex_uti,
		};
		unsigned int cmpval = 0x12345678U;
		int ret;

		plist_head_init(&source.chain);
		plist_head_init(&target.chain);
		source.lock = 0x81828384UL;
		target.lock = 0x91929394UL;
		plist_node_init(&first.list, 1);
		plist_node_init(&second.list, 2);
		plist_node_init(&third.list, 3);
		first.lock_ptr = (void *)&source.lock;
		second.lock_ptr = (void *)&source.lock;
		third.lock_ptr = (void *)&source.lock;
		first.key.opaque[0] = second.key.opaque[0] =
			third.key.opaque[0] = 0x1111UL;
		first.key.opaque[1] = second.key.opaque[1] =
			third.key.opaque[1] = 0x2222UL;
		first.key.opaque[2] = second.key.opaque[2] =
			third.key.opaque[2] = 0x10UL;
		first.linux_cpu = 66;
		second.linux_cpu = 77;
		third.linux_cpu = 88;
		plist_add(&first.list, &source.chain);
		plist_add(&second.list, &source.chain);
		plist_add(&third.list, &source.chain);

		fake_mcctrl_body_reset();
		fake_mcctrl_body_source_bucket = &source;
		fake_mcctrl_body_target_bucket = &target;
		fake_mcctrl_body_curval = cmpval;
		ret = mcctrl_futex_requeue_body_result(0x1000UL, 1,
			0x2000UL, 1, 2, (unsigned long)&cmpval,
			(unsigned long)&key1, (unsigned long)&key2,
			(unsigned long)&ctx, 0xfeedbabeUL,
			offsetof(struct fake_wake_body_bucket, lock),
			offsetof(struct fake_wake_body_bucket, chain),
			offsetof(struct fake_futex_q, list),
			offsetof(struct fake_futex_q, key),
			offsetof(struct futex_key, opaque[0]),
			offsetof(struct futex_key, opaque[1]),
			offsetof(struct futex_key, opaque[2]),
			offsetof(struct fake_mcctrl_futex_requeue_ctx, hb1),
			offsetof(struct fake_mcctrl_futex_requeue_ctx, hb2),
			offsetof(struct fake_mcctrl_futex_requeue_ctx, key2),
			fake_mcctrl_body_get_key,
			fake_mcctrl_body_hash_key,
			fake_mcctrl_body_hb_lock,
			fake_mcctrl_body_hb_unlock,
			fake_mcctrl_body_get_value,
			fake_mcctrl_body_put_key,
			fake_mcctrl_body_drop_key_refs,
			fake_mcctrl_body_requeue_wake,
			fake_mcctrl_body_requeue_move);
		require(ret == 3);
		require(fake_mcctrl_body_get_value_calls == 1);
		require(fake_mcctrl_body_wake_calls == 1);
		require(fake_mcctrl_body_requeue_calls == 2);
		require(fake_mcctrl_body_drop_key_calls == 2);
		require(fake_mcctrl_body_key_ref_calls == 2);
		require(fake_mcctrl_body_wake_log[0] == 66);
		require(fake_mcctrl_body_requeue_log[0] == 77);
		require(fake_mcctrl_body_requeue_log[1] == 88);
		require(ctx.hb1 == &source);
		require(ctx.hb2 == &target);
		require(ctx.key2 == &key2);
		require(plist_node_empty(&first.list));
		require(second.lock_ptr == &target.lock);
		require(third.lock_ptr == &target.lock);
		require(second.key.opaque[0] == key2.opaque[0]);
		require(third.key.opaque[1] == key2.opaque[1]);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_mcctrl_body_requeue_log[1]);
		mix_signed(&digest, fake_mcctrl_body_drop_key_calls);
	}

	{
#define ASSERT_CONTROL_DISPATCH(name, id, request) do { \
		long control_ret; \
		reset_fake_work(); \
		control_ret = mcctrl_control_dispatch_body_result( \
			0xc0010000UL + id, request, 0xa0000000UL + id, \
			0xf0000000UL + id, &fake_control_ops); \
		require(control_ret == fake_control_ret_base + id); \
		require(fake_control_calls == 1); \
		require(fake_control_last_id == id); \
		require(fake_control_last_os == 0xc0010000UL + id); \
		require(fake_control_last_arg == 0xa0000000UL + id); \
		require(fake_control_last_file == 0xf0000000UL + id); \
		mix_signed(&digest, control_ret); \
	} while (0);
		FAKE_CONTROL_DISPATCHES(ASSERT_CONTROL_DISPATCH)
#undef ASSERT_CONTROL_DISPATCH

		reset_fake_work();
		require(mcctrl_control_dispatch_body_result(
			0x1, 0xdeadbeefU, 0x2, 0x3,
			&fake_control_ops) == -22);
		require(fake_control_calls == 0);
		require(mcctrl_control_dispatch_body_result(
			0x1, MCEXEC_UP_TRANSFER, 0x2, 0x3, NULL) == -22);
		require(fake_control_calls == 0);

		{
			struct mcctrl_control_dispatch_ops missing =
				fake_control_ops;

			missing.perf_get = NULL;
			require(mcctrl_control_dispatch_body_result(
				0x1, IHK_OS_AUX_PERF_GET, 0x2, 0x3,
				&missing) == -22);
			require(fake_control_calls == 0);
		}
	}

	reset_fake_work();
	fake_control_send_ret = -5;
	require(mcctrl_control_debug_log_body_result(0xc0ffeeUL, 0xd06UL,
			fake_control_ikc_send) == 0);
	require(fake_control_send_calls == 1);
	require(fake_control_send_os == 0xc0ffeeUL);
	require(fake_control_send_cpu == 0);
	require(fake_control_send_msg == SCD_MSG_DEBUG_LOG);
	require(fake_control_send_arg == 0xd06UL);
	require(mcctrl_control_debug_log_body_result(0, 0, NULL) == -22);
	mix_signed(&digest, fake_control_send_calls);
	mix(&digest, fake_control_send_arg);

	reset_fake_work();
	fake_control_cpu_count = 12;
	require(mcctrl_control_get_cpu_body_result(0x5100UL,
			fake_control_get_cpu_info,
			fake_control_cpu_info_n_cpus,
			fake_control_log_error) == 12);
	require(fake_control_get_cpu_info_calls == 1);
	require(fake_control_cpu_count_calls == 1);
	require(fake_control_log_calls == 0);
	fake_control_cpu_info_missing = 1;
	require(mcctrl_control_get_cpu_body_result(0x5101UL,
			fake_control_get_cpu_info,
			fake_control_cpu_info_n_cpus,
			fake_control_log_error) == -22);
	require(fake_control_log_calls == 1);
	require(fake_control_log_stage == 0);
	fake_control_cpu_info_missing = 0;
	fake_control_cpu_count = 0;
	require(mcctrl_control_get_cpu_body_result(0x5102UL,
			fake_control_get_cpu_info,
			fake_control_cpu_info_n_cpus,
			fake_control_log_error) == -22);
	require(fake_control_log_calls == 2);
	require(fake_control_log_stage == 1);
	require(mcctrl_control_get_cpu_body_result(0, NULL,
			fake_control_cpu_info_n_cpus,
			fake_control_log_error) == -22);
	mix_signed(&digest, fake_control_cpu_count_calls);

	reset_fake_work();
	fake_control_nodes_count = 6;
	require(mcctrl_control_get_nodes_body_result(0x5200UL,
			fake_control_get_usrdata,
			fake_control_usrdata_mem_info,
			fake_control_mem_info_n_nodes,
			fake_control_log_error) == 6);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_mem_info_calls == 1);
	require(fake_control_nodes_count_calls == 1);
	require(fake_control_log_calls == 0);
	fake_control_usrdata_missing = 1;
	require(mcctrl_control_get_nodes_body_result(0x5201UL,
			fake_control_get_usrdata,
			fake_control_usrdata_mem_info,
			fake_control_mem_info_n_nodes,
			fake_control_log_error) == -22);
	require(fake_control_log_calls == 1);
	require(fake_control_log_stage == 0);
	fake_control_usrdata_missing = 0;
	fake_control_mem_info_missing = 1;
	require(mcctrl_control_get_nodes_body_result(0x5202UL,
			fake_control_get_usrdata,
			fake_control_usrdata_mem_info,
			fake_control_mem_info_n_nodes,
			fake_control_log_error) == -22);
	require(fake_control_log_calls == 2);
	require(fake_control_log_stage == 1);
	require(mcctrl_control_get_nodes_body_result(0, NULL,
			fake_control_usrdata_mem_info,
			fake_control_mem_info_n_nodes,
			fake_control_log_error) == -22);
	mix_signed(&digest, fake_control_nodes_count_calls);

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = {
			.addr = 0x1000UL,
			.val = 0x2222UL,
			.addr_ext = 0x3333UL,
			.sync = 0,
		};

		fake_control_cpu_reg_mutate_val = 0x9999UL;
		require(mcctrl_control_cpu_register_body_result(0x5300UL, 2,
			&reg, MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == 0);
		require(fake_control_cpu_reg_alloc_calls == 1);
		require(fake_control_cpu_reg_alloc_size == sizeof(reg));
		require(fake_control_cpu_reg_send_calls == 1);
		require(fake_control_cpu_reg_send_os == 0x5300UL);
		require(fake_control_cpu_reg_send_cpu == 2);
		require(fake_control_cpu_reg_send_msg == SCD_MSG_CPU_RW_REG);
		require(fake_control_cpu_reg_send_op ==
				MCCTRL_OS_CPU_READ_REGISTER);
		require(fake_control_cpu_reg_send_pdesc ==
				fake_control_cpu_reg_phys);
		require(fake_control_cpu_reg_send_timeout == -10000);
		require(reg.val == 0x9999UL);
		require(reg.sync == 1);
		require(fake_control_cpu_reg_free_calls == 1);
		require(fake_control_cpu_reg_freed ==
				&fake_control_cpu_reg_local);
		require(fake_control_cpu_reg_done_calls == 1);
		require(fake_control_cpu_reg_done_is_read == 1);
		require(fake_control_cpu_reg_done_val == 0x9999UL);
		mix(&digest, reg.val);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = {
			.addr = 0x1000UL,
			.val = 0x4444UL,
			.addr_ext = 0x5555UL,
			.sync = 0,
		};

		fake_control_cpu_reg_mutate_val = 0xaaaaUL;
		require(mcctrl_control_cpu_register_body_result(0x5301UL, 1,
			&reg, MCCTRL_OS_CPU_WRITE_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == 0);
		require(reg.val == 0x4444UL);
		require(reg.sync == 1);
		require(fake_control_cpu_reg_done_calls == 1);
		require(fake_control_cpu_reg_done_is_read == 0);
		require(fake_control_cpu_reg_done_op ==
				MCCTRL_OS_CPU_WRITE_REGISTER);
		require(fake_control_cpu_reg_done_addr_ext == 0x5555UL);
		mix(&digest, reg.val);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = { 0 };

		fake_control_usrdata_missing = 1;
		require(mcctrl_control_cpu_register_body_result(0x5302UL, 0,
			&reg, MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -22);
		require(fake_control_cpu_reg_error_calls == 1);
		require(fake_control_cpu_reg_error_stage == 0);
		require(fake_control_cpu_reg_alloc_calls == 0);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = { 0 };

		fake_control_cpu_reg_cpu_count = 2;
		require(mcctrl_control_cpu_register_body_result(0x5303UL, 2,
			&reg, MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -22);
		require(fake_control_cpu_reg_error_calls == 1);
		require(fake_control_cpu_reg_error_stage == 1);
		require(fake_control_cpu_reg_error_cpu == 2);
		require(fake_control_cpu_reg_alloc_calls == 0);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = { 0 };

		fake_control_cpu_reg_alloc_fail = 1;
		require(mcctrl_control_cpu_register_body_result(0x5304UL, 1,
			&reg, MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -12);
		require(fake_control_cpu_reg_error_calls == 1);
		require(fake_control_cpu_reg_error_stage == 2);
		require(fake_control_cpu_reg_send_calls == 0);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = { .val = 0x7777UL };

		fake_control_cpu_reg_send_ret = -19;
		fake_control_cpu_reg_send_do_free = 1;
		require(mcctrl_control_cpu_register_body_result(0x5305UL, 1,
			&reg, MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -19);
		require(fake_control_cpu_reg_error_calls == 1);
		require(fake_control_cpu_reg_error_stage == 3);
		require(fake_control_cpu_reg_error_ret == -19);
		require(fake_control_cpu_reg_free_calls == 1);
		require(reg.sync == 0);
	}

	reset_fake_work();
	{
		struct ihk_os_cpu_register reg = { 0 };

		require(mcctrl_control_cpu_register_body_result(0, 0, &reg,
			MCCTRL_OS_CPU_READ_REGISTER, NULL,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -22);
		require(mcctrl_control_cpu_register_body_result(0, 0, NULL,
			MCCTRL_OS_CPU_READ_REGISTER,
			fake_control_get_usrdata,
			fake_control_usrdata_cpu_count,
			fake_control_cpu_reg_alloc,
			fake_control_cpu_reg_free,
			fake_control_cpu_reg_virt_to_phys,
			fake_control_cpu_reg_send_wait,
			fake_control_cpu_reg_error_log,
			fake_control_cpu_reg_done_log) == -22);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_request_packet.body.traditional.ref = 4;
		fake_control_channel_read_cpu_result = 11;
		require(fake_control_request_cpu_call(0x5400UL,
				&request_cpu) == 0);
		require(request_cpu == 11);
		require(fake_control_validate_os_calls == 1);
		require(fake_control_validate_os_seen == 0x5400UL);
		require(fake_control_get_usrdata_calls == 1);
		require(fake_control_get_ppd_calls == 1);
		require(fake_control_get_ppd_pid ==
				fake_control_current_pid_value);
		require(fake_control_current_pid_calls == 1);
		require(fake_control_current_task_calls == 1);
		require(fake_control_get_ptd_calls == 1);
		require(fake_control_current_tid_calls == 1);
		require(fake_control_request_log_ptd_calls == 2);
		require(fake_control_request_log_ptd_get_calls == 1);
		require(fake_control_request_log_ptd_put_calls == 1);
		require(fake_control_ptd_data_calls == 1);
		require(fake_control_packet_ref_calls == 1);
		require(fake_control_channel_read_cpu_calls == 1);
		require(fake_control_channel_packet_ref == 4);
		require(fake_control_request_log_result_calls == 1);
		require(fake_control_request_log_result_os == 0x5400UL);
		require(fake_control_request_log_result_cpu == 11);
		require(fake_control_put_ptd_calls == 1);
		require(fake_control_put_ppd_calls == 1);
		require(fake_control_request_put_ptd_order == 1);
		require(fake_control_request_log_ptd_put_order == 2);
		require(fake_control_request_put_ppd_order == 3);
		mix_signed(&digest, request_cpu);
		mix_signed(&digest, fake_control_request_put_ppd_order);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		require(fake_control_request_cpu_call(0, &request_cpu) == -22);
		require(request_cpu == -1);
		require(fake_control_validate_os_calls == 0);
		require(fake_control_get_usrdata_calls == 0);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_validate_os_ret = -1;
		require(fake_control_request_cpu_call(0x5401UL,
				&request_cpu) == -22);
		require(request_cpu == -1);
		require(fake_control_validate_os_calls == 1);
		require(fake_control_get_usrdata_calls == 0);
		require(fake_control_request_log_error_calls == 0);
	}

	reset_fake_work();
	require(mcctrl_control_get_request_os_cpu_body_result(
		0x5402UL, NULL, fake_control_validate_os,
		fake_control_get_usrdata, fake_control_current_pid,
		fake_control_current_tid, fake_control_current_task,
		fake_control_get_ppd, fake_control_put_ppd,
		fake_control_get_ptd, fake_control_put_ptd,
		fake_control_ptd_data, fake_control_packet_ref,
		fake_control_channel_read_cpu,
		fake_control_request_cpu_error_log,
		fake_control_request_cpu_ptd_log,
		fake_control_request_cpu_result_log) == -22);
	require(fake_control_validate_os_calls == 0);
	require(fake_control_get_usrdata_calls == 0);

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_usrdata_missing = 1;
		require(fake_control_request_cpu_call(0x5403UL,
				&request_cpu) == -22);
		require(fake_control_request_log_error_calls == 1);
		require(fake_control_request_log_error_stage == 0);
		require(fake_control_request_log_error_os == 0x5403UL);
		require(fake_control_get_ppd_calls == 0);
		require(fake_control_put_ppd_calls == 0);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_missing_ppd = 1;
		require(fake_control_request_cpu_call(0x5404UL,
				&request_cpu) == -22);
		require(fake_control_request_log_error_calls == 1);
		require(fake_control_request_log_error_stage == 1);
		require(fake_control_request_log_error_pid ==
				fake_control_current_pid_value);
		require(fake_control_get_ppd_calls == 1);
		require(fake_control_get_ptd_calls == 0);
		require(fake_control_put_ppd_calls == 0);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_missing_ptd = 1;
		require(fake_control_request_cpu_call(0x5405UL,
				&request_cpu) == -22);
		require(fake_control_request_log_error_calls == 1);
		require(fake_control_request_log_error_stage == 2);
		require(fake_control_request_log_error_tid ==
				fake_control_current_tid_value);
		require(fake_control_current_tid_calls == 1);
		require(fake_control_put_ppd_calls == 1);
		require(fake_control_put_ptd_calls == 0);
		require(fake_control_request_log_ptd_calls == 0);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		fake_control_packet_missing = 1;
		require(fake_control_request_cpu_call(0x5406UL,
				&request_cpu) == -22);
		require(fake_control_request_log_error_calls == 1);
		require(fake_control_request_log_error_stage == 3);
		require(fake_control_request_log_error_tid ==
				fake_control_current_tid_value);
		require(fake_control_packet_ref_calls == 0);
		require(fake_control_channel_read_cpu_calls == 0);
		require(fake_control_put_ptd_calls == 1);
		require(fake_control_request_log_ptd_calls == 2);
		require(fake_control_put_ppd_calls == 1);
		require(fake_control_request_put_ptd_order == 1);
		require(fake_control_request_log_ptd_put_order == 2);
		require(fake_control_request_put_ppd_order == 3);
	}

	reset_fake_work();
	{
		int request_cpu = -1;

		require(mcctrl_control_get_request_os_cpu_body_result(
			0x5407UL, &request_cpu, NULL,
			fake_control_get_usrdata, fake_control_current_pid,
			fake_control_current_tid, fake_control_current_task,
			fake_control_get_ppd, fake_control_put_ppd,
			fake_control_get_ptd, fake_control_put_ptd,
			fake_control_ptd_data, fake_control_packet_ref,
			fake_control_channel_read_cpu,
			fake_control_request_cpu_error_log,
			fake_control_request_cpu_ptd_log,
			fake_control_request_cpu_result_log) == -22);
		require(fake_control_get_usrdata_calls == 0);
	}

	reset_fake_work();
	{
		struct prepare_dma_desc desc;
		unsigned long user_pa = 0;

		desc.size = 0x6000UL;
		desc.pa = (unsigned long)&user_pa;
		fake_control_get_order_result = 5;
		fake_control_alloc_pages_result = 0x12345000UL;
		fake_control_region_virt_to_phys_result = 0x54321000UL;
		require(fake_control_pin_region_call(&desc) == 0);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_copy_from_size == sizeof(desc));
		require(fake_control_get_order_calls == 1);
		require(fake_control_get_order_size == desc.size);
		require(fake_control_alloc_pages_calls == 1);
		require(fake_control_alloc_pages_order == 5);
		require(fake_control_region_virt_to_phys_calls == 1);
		require(fake_control_region_virt_to_phys_ptr ==
				(void *)0x12345000UL);
		require(fake_control_copy_to_calls == 1);
		require(fake_control_copy_to_dst == &user_pa);
		require(fake_control_copy_to_size == sizeof(user_pa));
		require(user_pa == 0x54321000UL);
		mix(&digest, user_pa);
	}

	reset_fake_work();
	{
		struct prepare_dma_desc desc;

		desc.size = 0x1000UL;
		desc.pa = 0;
		fake_control_copy_from_fail = 1;
		require(fake_control_pin_region_call(&desc) == -14);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_alloc_pages_calls == 0);
	}

	reset_fake_work();
	{
		struct prepare_dma_desc desc;

		desc.size = 0;
		desc.pa = 0x1000UL;
		fake_control_alloc_pages_result = 0;
		require(fake_control_pin_region_call(&desc) == -12);
		require(fake_control_get_order_calls == 0);
		require(fake_control_alloc_pages_order == 4);
		require(fake_control_copy_to_calls == 0);
	}

	reset_fake_work();
	{
		struct prepare_dma_desc desc;
		unsigned long user_pa = 0;

		desc.size = 0x2000UL;
		desc.pa = (unsigned long)&user_pa;
		fake_control_copy_to_fail = 1;
		require(fake_control_pin_region_call(&desc) == -14);
		require(fake_control_alloc_pages_calls == 1);
		require(fake_control_region_virt_to_phys_calls == 1);
		require(user_pa == 0);
	}

	reset_fake_work();
	require(mcctrl_control_pin_region_body_result(
		NULL, 16, 12, NULL, fake_control_get_order,
		fake_control_alloc_pages, fake_control_region_virt_to_phys,
		fake_control_copy_to_user) == -22);
	require(fake_control_copy_from_calls == 0);

	reset_fake_work();
	{
		struct free_dma_desc desc;

		desc.pa = 0xfeed0000UL;
		desc.size = 0x8000UL;
		fake_control_get_order_result = 6;
		fake_control_region_phys_to_virt_result = 0xbeef0000UL;
		require(fake_control_free_region_call(&desc) == 0);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_get_order_calls == 1);
		require(fake_control_region_phys_to_virt_calls == 1);
		require(fake_control_region_phys_to_virt_phys == desc.pa);
		require(fake_control_free_pages_calls == 1);
		require(fake_control_free_pages_addr == 0xbeef0000UL);
		require(fake_control_free_pages_order == 6);
		mix(&digest, fake_control_free_pages_addr);
	}

	reset_fake_work();
	{
		struct free_dma_desc desc;

		desc.pa = 0;
		desc.size = 0;
		require(fake_control_free_region_call(&desc) == 0);
		require(fake_control_get_order_calls == 0);
		require(fake_control_region_phys_to_virt_calls == 0);
		require(fake_control_free_pages_calls == 0);
	}

	reset_fake_work();
	{
		struct sys_mount_desc desc;
		char dev[] = "dev0";
		char dir[] = "/mnt";
		char type[] = "mck";
		int data = 0x64617461;

		desc.dev_name = dev;
		desc.dir_name = dir;
		desc.type_name = type;
		desc.flags = 0x123UL;
		desc.data = &data;
		fake_control_mount_ret = -37;
		require(fake_control_sys_mount_call(&desc) == -37);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_copy_from_size == sizeof(desc));
		require(fake_control_prepare_creds_calls == 1);
		require(fake_control_cap_raise_calls == 1);
		require(fake_control_override_creds_calls == 1);
		require(fake_control_mount_calls == 1);
		require(fake_control_mount_dev == dev);
		require(fake_control_mount_dir == dir);
		require(fake_control_mount_type == type);
		require(fake_control_mount_flags == 0x123UL);
		require(fake_control_mount_data == &data);
		require(fake_control_revert_creds_calls == 1);
		require(fake_control_put_cred_calls == 1);
		require(fake_control_prepare_creds_order == 1);
		require(fake_control_cap_raise_order == 2);
		require(fake_control_override_creds_order == 3);
		require(fake_control_mount_order == 4);
		require(fake_control_revert_creds_order == 5);
		require(fake_control_put_cred_order == 6);
		mix_signed(&digest, fake_control_mount_ret);
	}

	reset_fake_work();
	{
		struct sys_mount_desc desc;

		memset(&desc, 0, sizeof(desc));
		fake_control_copy_from_fail = 1;
		require(fake_control_sys_mount_call(&desc) == -14);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_prepare_creds_calls == 0);
	}

	reset_fake_work();
	{
		struct sys_mount_desc desc;

		memset(&desc, 0, sizeof(desc));
		fake_control_prepare_creds_fail = 1;
		require(fake_control_sys_mount_call(&desc) == -12);
		require(fake_control_prepare_creds_calls == 1);
		require(fake_control_cap_raise_calls == 0);
		require(fake_control_put_cred_calls == 0);
	}

	reset_fake_work();
	{
		struct sys_umount_desc desc;
		char dir[] = "/mnt";

		desc.dir_name = dir;
		fake_control_umount_ret = -16;
		require(fake_control_sys_umount_call(&desc, 1) == -16);
		require(fake_control_umount_calls == 1);
		require(fake_control_umount_dir == dir);
		require(fake_control_umount_flags == 1);
		require(fake_control_umount_order == 4);
		require(fake_control_put_cred_order == 6);
		mix_signed(&digest, fake_control_umount_ret);
	}

	reset_fake_work();
	{
		struct sys_unshare_desc desc;

		desc.unshare_flags = 0x7fUL;
		fake_control_unshare_ret = -33;
		require(fake_control_sys_unshare_call(&desc) == -33);
		require(fake_control_unshare_calls == 1);
		require(fake_control_unshare_flags == 0x7fUL);
		require(fake_control_unshare_order == 4);
		require(fake_control_put_cred_order == 6);
		mix_signed(&digest, fake_control_unshare_ret);
	}

	reset_fake_work();
	{
		struct release_user_space_desc desc;

		desc.user_start = 0x4000UL;
		desc.user_end = 0x4c00UL;
		fake_control_clear_pte_ret = -44;
		require(fake_control_release_user_space_call(&desc) == -44);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_clear_pte_calls == 1);
		require(fake_control_clear_pte_start == 0x4000UL);
		require(fake_control_clear_pte_len == 0xc00UL);
		mix(&digest, fake_control_clear_pte_len);
	}

	reset_fake_work();
	{
		struct release_user_space_desc desc;

		memset(&desc, 0, sizeof(desc));
		fake_control_copy_from_fail = 1;
		require(fake_control_release_user_space_call(&desc) == -14);
		require(fake_control_clear_pte_calls == 0);
	}

	reset_fake_work();
	require(fake_control_perf_num_call(0x6100UL, 42) == 0);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_validate_os_seen == 0x6100UL);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_perf_set_num_calls == 1);
	require(fake_control_perf_set_num_usrdata ==
			&fake_control_usrdata_token);
	require(fake_control_perf_set_num_value == 42);
	mix(&digest, fake_control_perf_set_num_value);

	reset_fake_work();
	fake_control_validate_os_ret = -1;
	require(fake_control_perf_num_call(0x6101UL, 11) == -22);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_get_usrdata_calls == 0);
	require(fake_control_perf_set_num_calls == 0);

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_perf_num_call(0x6102UL, 12) == -22);
	require(fake_control_log_calls == 1);
	require(fake_control_log_stage == 0);
	require(fake_control_perf_set_num_calls == 0);

	reset_fake_work();
	require(fake_control_perf_num_call(0, 12) == -22);
	require(fake_control_validate_os_calls == 0);
	require(fake_control_get_usrdata_calls == 0);

	reset_fake_work();
	require(fake_control_perf_set_call(0x6300UL) == 2);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_get_cpu_info_calls == 1);
	require(fake_control_cpu_count_calls == 1);
	require(fake_control_perf_event_num_calls == 1);
	require(fake_control_perf_alloc_set_calls == 2);
	require(fake_control_perf_send_calls == 8);
	require(fake_control_perf_free_calls == 2);
	require(fake_control_perf_set_num_calls == 1);
	require(fake_control_perf_set_num_value == 2);
	require(fake_control_perf_descs[0].ctrl_type == PERF_CTRL_SET);
	require(fake_control_perf_descs[0].target_cntr == 0);
	require(fake_control_perf_descs[0].config == 0x101UL);
	require(fake_control_perf_descs[0].exclude_user == 1);
	require(fake_control_perf_descs[1].target_cntr == 1);
	require(fake_control_perf_descs[1].exclude_kernel == 1);
	mix_signed(&digest, fake_control_perf_send_calls);
	mix(&digest, fake_control_perf_descs[1].config);

	reset_fake_work();
	fake_control_perf_copy_fail_index = 0;
	require(fake_control_perf_set_call(0x6301UL) == -22);
	require(fake_control_perf_alloc_set_calls == 1);
	require(fake_control_perf_send_calls == 0);
	require(fake_control_perf_free_calls == 0);

	reset_fake_work();
	fake_control_perf_send_fail_call = 2;
	fake_control_perf_send_ret = -19;
	fake_control_perf_send_need_free = 1;
	require(fake_control_perf_set_call(0x6302UL) == -19);
	require(fake_control_perf_send_calls == 2);
	require(fake_control_perf_free_calls == 1);

	reset_fake_work();
	require(fake_control_perf_get_call(0x6400UL) == 0);
	require(fake_control_perf_alloc_desc_calls == 2);
	require(fake_control_perf_init_get_calls == 2);
	require(fake_control_perf_send_calls == 8);
	require(fake_control_perf_desc_read_calls == 8);
	require(fake_control_copy_to_calls == 2);
	require(fake_control_perf_user_values[0] == 56);
	require(fake_control_perf_user_values[1] == 72);
	mix(&digest, fake_control_perf_user_values[0]);
	mix(&digest, fake_control_perf_user_values[1]);

	reset_fake_work();
	fake_control_perf_copyout_fail = 1;
	require(fake_control_perf_get_call(0x6401UL) == -22);
	require(fake_control_perf_log_calls == 1);
	require(fake_control_perf_log_stage == 2);
	require(fake_control_perf_free_calls == 1);

	reset_fake_work();
	require(fake_control_perf_enable_disable_call(
		0x6500UL, PERF_CTRL_ENABLE) == 0);
	require(fake_control_perf_init_mask_calls == 1);
	require(fake_control_perf_init_mask_type == PERF_CTRL_ENABLE);
	require(fake_control_perf_init_mask_value == 3);
	require(fake_control_perf_send_calls == 4);
	require(fake_control_perf_free_calls == 1);
	mix(&digest, fake_control_perf_init_mask_value);

	reset_fake_work();
	require(fake_control_perf_enable_disable_call(
		0x6501UL, PERF_CTRL_DISABLE) == 0);
	require(fake_control_perf_init_mask_type == PERF_CTRL_DISABLE);
	require(fake_control_perf_send_calls == 4);

	reset_fake_work();
	fake_control_perf_send_fail_call = 1;
	fake_control_perf_send_ret = -19;
	fake_control_perf_send_need_free = 1;
	require(fake_control_perf_enable_disable_call(
		0x6502UL, PERF_CTRL_ENABLE) == -22);
	require(fake_control_perf_send_calls == 1);
	require(fake_control_perf_free_calls == 1);

	reset_fake_work();
	fake_control_perf_desc_err_after_cpu = 1;
	fake_control_perf_desc_err_value = -7;
	require(fake_control_perf_enable_disable_call(
		0x6503UL, PERF_CTRL_ENABLE) == -7);
	require(fake_control_perf_send_calls == 2);
	require(fake_control_perf_free_calls == 1);

	reset_fake_work();
	require(fake_control_perf_destroy_call(0x6200UL) == 0);
	require(fake_control_perf_disable_calls == 1);
	require(fake_control_perf_disable_os == 0x6200UL);
	require(fake_control_perf_num_zero_calls == 1);
	require(fake_control_perf_num_zero_os == 0x6200UL);
	mix_signed(&digest, fake_control_perf_disable_calls);

	reset_fake_work();
	require(mcctrl_control_perf_destroy_body_result(
		0x6201UL, NULL, fake_control_perf_num_zero) == -22);
	require(fake_control_perf_disable_calls == 0);
	require(fake_control_perf_num_zero_calls == 0);

	reset_fake_work();
	require(fake_control_getrusage_call(0x7200UL) == 0);
	require(fake_control_getrusage_calls == 1);
	require(fake_control_getrusage_os == 0x7200UL);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_copy_from_size ==
			sizeof(struct mcctrl_ioctl_getrusage_desc));
	require(fake_control_getrusage_alloc_calls == 1);
	require(fake_control_getrusage_alloc_size ==
			sizeof(struct fake_ihk_os_rusage));
	require(fake_control_copy_to_calls == 1);
	require(fake_control_copy_to_size == sizeof(fake_control_rusage_user_out));
	require(fake_control_getrusage_free_calls == 1);
	require(fake_control_rusage_user_out.memory_stat_rss[0] == 11);
	require(fake_control_rusage_user_out.memory_stat_rss[1] == ~1UL);
	require(fake_control_rusage_user_out.memory_stat_mapped_file[1] == 17);
	require(fake_control_rusage_user_out.memory_max_usage == 1000);
	require(fake_control_rusage_user_out.memory_kmem_usage == 55);
	require(fake_control_rusage_user_out.memory_kmem_max_usage == 66);
	require(fake_control_rusage_user_out.memory_numa_stat[2] == 303);
	require(fake_control_rusage_user_out.cpuacct_usage_percpu[0] == 200);
	require(fake_control_rusage_user_out.cpuacct_usage_percpu[1] == 6);
	require(fake_control_rusage_user_out.cpuacct_usage == 206);
	require(fake_control_rusage_user_out.cpuacct_stat_user == 1);
	require(fake_control_rusage_user_out.cpuacct_stat_system == 1);
	require(fake_control_rusage_user_out.num_threads == 5);
	require(fake_control_rusage_user_out.max_num_threads == 9);
	mix(&digest, fake_control_rusage_user_out.cpuacct_usage);
	mix(&digest, fake_control_rusage_user_out.memory_numa_stat[2]);

	reset_fake_work();
	fake_control_validate_os_ret = -1;
	require(fake_control_getrusage_call(0x7201UL) == -22);
	require(fake_control_getrusage_calls == 1);
	require(fake_control_copy_from_calls == 0);
	require(fake_control_getrusage_alloc_calls == 0);
	mix_signed(&digest, fake_control_validate_os_ret);

	reset_fake_work();
	fake_control_copy_from_fail = 1;
	require(fake_control_getrusage_call(0x7202UL) == -1);
	require(fake_control_getrusage_log_calls == 1);
	require(fake_control_getrusage_log_stage == 0);
	require(fake_control_getrusage_alloc_calls == 0);
	mix_signed(&digest, fake_control_getrusage_log_stage);

	reset_fake_work();
	fake_control_getrusage_alloc_fail = 1;
	require(fake_control_getrusage_call(0x7203UL) == -12);
	require(fake_control_getrusage_log_stage == 1);
	require(fake_control_getrusage_free_calls == 0);
	mix_signed(&digest, fake_control_getrusage_log_stage);

	reset_fake_work();
	fake_control_rusage_desc.size_rusage =
		sizeof(fake_control_rusage_user_out) + 1;
	require(fake_control_getrusage_call(0x7204UL) == -22);
	require(fake_control_getrusage_log_stage == 2);
	require(fake_control_getrusage_log_size ==
			sizeof(fake_control_rusage_user_out) + 1);
	require(fake_control_getrusage_log_max ==
			sizeof(fake_control_rusage_user_out));
	require(fake_control_getrusage_free_calls == 1);
	require(fake_control_copy_to_calls == 0);
	mix(&digest, fake_control_getrusage_log_size);

	reset_fake_work();
	fake_control_copy_to_fail = 1;
	require(fake_control_getrusage_call(0x7205UL) == -1);
	require(fake_control_getrusage_log_stage == 3);
	require(fake_control_getrusage_free_calls == 1);
	mix_signed(&digest, fake_control_getrusage_log_stage);

	reset_fake_work();
	require(fake_control_transfer_call(0x7300UL) == 0);
	require(fake_control_copy_from_calls == 2);
	require(fake_control_copy_to_calls == 0);
	require(fake_control_os_to_dev_calls == 4);
	require(fake_control_map_memory_calls == 1);
	require(fake_control_map_memory_phys == 0x8800UL);
	require(fake_control_map_memory_size == 16);
	require(fake_control_map_virtual_calls == 1);
	require(fake_control_map_virtual_phys == 0x9800UL);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_virtual_ptr == fake_control_remote_buf);
	require(fake_control_unmap_memory_calls == 1);
	require(!memcmp(fake_control_remote_buf, fake_control_user_buf, 16));
	mix(&digest, fake_control_map_virtual_phys);

	reset_fake_work();
	fake_control_transfer_desc.direction = MCEXEC_UP_TRANSFER_FROM_REMOTE;
	require(fake_control_transfer_call(0x7301UL) == 0);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_copy_to_calls == 1);
	require(!memcmp(fake_control_user_buf, "remote-source", 14));
	mix(&digest, fake_control_copy_to_size);

	reset_fake_work();
	fake_control_transfer_desc.direction = 9;
	require(fake_control_transfer_call(0x7302UL) == -22);
	require(fake_control_transfer_log_calls == 1);
	require(fake_control_transfer_log_stage == 1);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);
	mix_signed(&digest, fake_control_transfer_log_stage);

	reset_fake_work();
	fake_control_map_virtual_fail = 1;
	require(fake_control_transfer_call(0x7303UL) == -14);
	require(fake_control_transfer_log_calls == 1);
	require(fake_control_transfer_log_stage == 0);
	require(fake_control_unmap_virtual_calls == 0);
	require(fake_control_unmap_memory_calls == 0);
	mix_signed(&digest, fake_control_transfer_log_stage);

	reset_fake_work();
	require(fake_control_load_call(0x7400UL) == 0);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_copy_to_calls == 1);
	require(fake_control_load_log_calls == 1);
	require(fake_control_load_log_rpm == fake_control_remote_buf);
	require(fake_control_load_log_size == 14);
	require(fake_control_map_memory_phys == 0x9900UL);
	require(fake_control_map_virtual_phys == 0xa900UL);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);
	require(!memcmp(fake_control_user_buf, "remote-source", 14));
	mix(&digest, fake_control_load_log_size);

	reset_fake_work();
	fake_control_copy_to_fail = 1;
	require(fake_control_load_call(0x7401UL) == -14);
	require(fake_control_load_log_calls == 1);
	require(fake_control_unmap_virtual_calls == 0);
	require(fake_control_unmap_memory_calls == 0);
	mix_signed(&digest, fake_control_copy_to_fail);

	reset_fake_work();
	require(fake_control_ret_syscall_call(0x7410UL) == 0);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_copy_from_calls == 2);
	require(fake_control_copy_from_src == fake_control_user_buf);
	require(fake_control_copy_from_size == 16);
	require(fake_control_current_pid_calls == 1);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_current_task_calls == 1);
	require(fake_control_get_ptd_calls == 1);
	require(fake_control_current_tid_calls == 1);
	require(fake_control_ptd_data_calls == 1);
	require(fake_control_os_to_dev_calls == 1);
	require(fake_control_map_memory_calls == 1);
	require(fake_control_map_memory_phys == 0x8a00UL);
	require(fake_control_map_virtual_calls == 1);
	require(fake_control_map_virtual_phys == 0x9a00UL);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);
	require(!memcmp(fake_control_remote_buf, fake_control_user_buf, 16));
	require(fake_control_return_syscall_calls == 1);
	require(fake_control_return_syscall_os == 0x7410UL);
	require(fake_control_return_syscall_ppd == &fake_control_ppd_token);
	require(fake_control_return_syscall_packet ==
			&fake_control_request_packet);
	require(fake_control_return_syscall_ret == -37);
	require(fake_control_return_syscall_tid ==
			fake_control_current_tid_value);
	require(fake_control_release_packet_calls == 1);
	require(fake_control_put_ptd_calls == 2);
	require(fake_control_put_ppd_calls == 1);
	require(fake_control_release_packet_order == 1);
	require(fake_control_request_put_ptd_order == 3);
	require(fake_control_request_put_ppd_order == 4);
	mix_signed(&digest, fake_control_return_syscall_ret);
	mix_signed(&digest, fake_control_release_packet_order);

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_ret_syscall_call(0x7411UL) == -22);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_copy_from_calls == 0);
	require(fake_control_ret_log_calls == 1);
	require(fake_control_ret_log_stage[0] == 0);
	require(fake_control_ret_log_pid[0] == 0);
	require(fake_control_ret_log_tid[0] == 0);
	require(fake_control_get_ppd_calls == 0);
	mix_signed(&digest, fake_control_ret_log_stage[0]);

	reset_fake_work();
	fake_control_copy_from_fail = 1;
	require(fake_control_ret_syscall_call(0x7412UL) == -14);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_get_ppd_calls == 0);
	require(fake_control_release_packet_calls == 0);

	reset_fake_work();
	fake_control_missing_ppd = 1;
	require(fake_control_ret_syscall_call(0x7413UL) == -22);
	require(fake_control_current_pid_calls == 1);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_ret_log_calls == 1);
	require(fake_control_ret_log_stage[0] == 1);
	require(fake_control_ret_log_pid[0] ==
			fake_control_current_pid_value);
	require(fake_control_get_ptd_calls == 0);
	require(fake_control_put_ppd_calls == 0);
	mix_signed(&digest, fake_control_ret_log_stage[0]);

	reset_fake_work();
	fake_control_missing_ptd = 1;
	require(fake_control_ret_syscall_call(0x7414UL) == -22);
	require(fake_control_get_ptd_calls == 1);
	require(fake_control_ret_log_calls == 1);
	require(fake_control_ret_log_stage[0] == 2);
	require(fake_control_ret_log_tid[0] ==
			fake_control_current_tid_value);
	require(fake_control_put_ppd_calls == 1);
	require(fake_control_put_ptd_calls == 0);
	mix_signed(&digest, fake_control_ret_log_stage[0]);

	reset_fake_work();
	fake_control_packet_missing = 1;
	require(fake_control_ret_syscall_call(0x7415UL) == -22);
	require(fake_control_ptd_data_calls == 1);
	require(fake_control_ret_log_calls == 1);
	require(fake_control_ret_log_stage[0] == 3);
	require(fake_control_release_packet_calls == 0);
	require(fake_control_put_ptd_calls == 2);
	require(fake_control_put_ppd_calls == 1);
	require(fake_control_request_put_ptd_order == 2);
	require(fake_control_request_put_ppd_order == 3);
	mix_signed(&digest, fake_control_ret_log_stage[0]);

	reset_fake_work();
	fake_control_copy_from_fail_at = 2;
	require(fake_control_ret_syscall_call(0x7416UL) == -14);
	require(fake_control_copy_from_calls == 2);
	require(fake_control_map_memory_calls == 1);
	require(fake_control_map_virtual_calls == 1);
	require(fake_control_unmap_virtual_calls == 0);
	require(fake_control_unmap_memory_calls == 0);
	require(fake_control_return_syscall_calls == 0);
	require(fake_control_release_packet_calls == 1);
	require(fake_control_put_ptd_calls == 2);
	require(fake_control_put_ppd_calls == 1);
	mix_signed(&digest, fake_control_copy_from_fail_at);

	reset_fake_work();
	require(fake_control_terminate_thread_call(0x7417UL, 2468, 3579,
			-99) == 0);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_last_os == 0x7417UL);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_get_ppd_pid == 2468);
	require(fake_control_get_ptd_calls == 1);
	require(fake_control_get_ptd_task == &fake_control_task_token);
	require(fake_control_ptd_tid_calls == 1);
	require(fake_control_ptd_data_calls == 1);
	require(fake_control_usrdata_os_calls == 1);
	require(fake_control_return_syscall_calls == 1);
	require(fake_control_return_syscall_os ==
			fake_control_usrdata_os_value);
	require(fake_control_return_syscall_ret == -99);
	require(fake_control_return_syscall_tid == 3579);
	require(fake_control_release_packet_calls == 1);
	require(fake_control_ptd_refcount_calls == 1);
	require(fake_control_put_ptd_calls == 3);
	require(fake_control_put_ppd_calls == 2);
	require(fake_control_release_packet_order == 1);
	require(fake_control_request_put_ptd_order == 4);
	require(fake_control_request_put_ppd_order == 6);
	require(fake_control_terminate_log_calls == 6);
	require(fake_control_terminate_log_stage[0] == 4);
	require(fake_control_terminate_log_stage[1] == 6);
	require(fake_control_terminate_log_stage[2] == 6);
	require(fake_control_terminate_log_stage[3] == 6);
	require(fake_control_terminate_log_stage[4] == 8);
	require(fake_control_terminate_log_stage[5] == 8);
	mix_signed(&digest, fake_control_request_put_ppd_order);
	mix_signed(&digest, fake_control_return_syscall_ret);

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_terminate_thread_call(0x7418UL, 2468, 3579,
			-98) == 0);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_get_ppd_calls == 0);
	require(fake_control_put_ppd_calls == 0);
	require(fake_control_terminate_log_calls == 1);
	require(fake_control_terminate_log_stage[0] == 0);
	mix_signed(&digest, fake_control_terminate_log_stage[0]);

	reset_fake_work();
	fake_control_missing_ppd = 1;
	require(fake_control_terminate_thread_call(0x7419UL, 2468, 3579,
			-97) == 0);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_get_ptd_calls == 0);
	require(fake_control_put_ppd_calls == 0);
	require(fake_control_terminate_log_calls == 1);
	require(fake_control_terminate_log_stage[0] == 1);
	require(fake_control_terminate_log_pid[0] == 2468);
	mix_signed(&digest, fake_control_terminate_log_stage[0]);

	reset_fake_work();
	fake_control_missing_ptd = 1;
	require(fake_control_terminate_thread_call(0x741aUL, 2468, 3579,
			-96) == 0);
	require(fake_control_get_ptd_calls == 1);
	require(fake_control_ptd_tid_calls == 0);
	require(fake_control_put_ptd_calls == 0);
	require(fake_control_put_ppd_calls == 2);
	require(fake_control_terminate_log_calls == 3);
	require(fake_control_terminate_log_stage[0] == 2);
	require(fake_control_terminate_log_stage[1] == 8);
	require(fake_control_terminate_log_stage[2] == 8);
	mix_signed(&digest, fake_control_terminate_log_stage[0]);

	reset_fake_work();
	fake_control_ptd_tid_value = 3580;
	require(fake_control_terminate_thread_call(0x741bUL, 2468, 3579,
			-95) == 0);
	require(fake_control_ptd_tid_calls == 1);
	require(fake_control_ptd_data_calls == 0);
	require(fake_control_put_ptd_calls == 0);
	require(fake_control_put_ppd_calls == 2);
	require(fake_control_terminate_log_calls == 3);
	require(fake_control_terminate_log_stage[0] == 3);
	require(fake_control_terminate_log_value[0] == 3580);
	mix_signed(&digest, fake_control_terminate_log_value[0]);

	reset_fake_work();
	fake_control_packet_missing = 1;
	require(fake_control_terminate_thread_call(0x741cUL, 2468, 3579,
			-94) == 0);
	require(fake_control_ptd_tid_calls == 1);
	require(fake_control_ptd_data_calls == 1);
	require(fake_control_return_syscall_calls == 0);
	require(fake_control_release_packet_calls == 0);
	require(fake_control_put_ptd_calls == 0);
	require(fake_control_put_ppd_calls == 2);
	require(fake_control_terminate_log_calls == 4);
	require(fake_control_terminate_log_stage[0] == 4);
	require(fake_control_terminate_log_stage[1] == 5);
	require(fake_control_terminate_log_stage[2] == 8);
	require(fake_control_terminate_log_stage[3] == 8);
	mix_signed(&digest, fake_control_terminate_log_stage[1]);

	reset_fake_work();
	fake_control_ptd_refcount_value = 4;
	require(fake_control_terminate_thread_call(0x741dUL, 2468, 3579,
			-93) == 0);
	require(fake_control_ptd_refcount_calls == 1);
	require(fake_control_terminate_log_calls == 7);
	require(fake_control_terminate_log_stage[3] == 7);
	require(fake_control_terminate_log_value[3] == 4);
	require(fake_control_put_ptd_calls == 3);
	require(fake_control_put_ppd_calls == 2);
	mix_signed(&digest, fake_control_terminate_log_value[3]);

	reset_fake_work();
	require(fake_control_uti_get_ctx_call(0x7420UL) == 0);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_copy_from_src == &fake_control_uti_desc);
	require(fake_control_copy_from_size ==
			sizeof(struct fake_control_uti_get_ctx_desc));
	require(fake_control_os_to_dev_calls == 1);
	require(fake_control_map_memory_calls == 1);
	require(fake_control_map_memory_phys == 0xb000UL);
	require(fake_control_map_memory_size == sizeof(fake_control_uti_remote_ctx));
	require(fake_control_map_virtual_calls == 1);
	require(fake_control_map_virtual_phys == 0xc000UL);
	require(fake_control_copy_to_calls == 2);
	require(fake_control_copy_to_dst_history[0] ==
			fake_control_uti_user_ctx);
	require(fake_control_copy_to_size_history[0] ==
			sizeof(fake_control_uti_remote_ctx));
	require(fake_control_copy_to_dst_history[1] ==
			&fake_control_uti_desc.key);
	require(fake_control_copy_to_size_history[1] ==
			sizeof(unsigned long));
	require(fake_control_current_key_calls == 1);
	require(fake_control_uti_desc.key == 0xf00dcafe12345678UL);
	require(fake_control_uti_user_ctx[0] == 0);
	require(fake_control_uti_user_ctx[1] == 1);
	require(fake_control_uti_user_ctx[2] == 2);
	require(fake_control_uti_user_ctx[3] == 3);
	require(!memcmp(fake_control_uti_user_ctx + sizeof(int),
			fake_control_uti_remote_ctx + sizeof(int),
			sizeof(fake_control_uti_remote_ctx) - sizeof(int)));
	require(*(int *)fake_control_uti_remote_ctx == 0x12345678);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);
	mix(&digest, fake_control_uti_desc.key);
	mix_signed(&digest, *(int *)fake_control_uti_remote_ctx);

	reset_fake_work();
	fake_control_copy_from_fail = 1;
	require(fake_control_uti_get_ctx_call(0x7421UL) == -14);
	require(fake_control_uti_log_calls == 1);
	require(fake_control_uti_log_stage[0] == 0);
	require(fake_control_map_memory_calls == 0);
	mix_signed(&digest, fake_control_uti_log_stage[0]);

	reset_fake_work();
	fake_control_copy_to_fail_at = 1;
	require(fake_control_uti_get_ctx_call(0x7422UL) == -14);
	require(fake_control_copy_to_calls == 1);
	require(fake_control_current_key_calls == 0);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);

	reset_fake_work();
	fake_control_copy_to_fail_at = 2;
	require(fake_control_uti_get_ctx_call(0x7423UL) == -14);
	require(fake_control_copy_to_calls == 2);
	require(fake_control_current_key_calls == 1);
	require(fake_control_uti_desc.key == 0);
	require(fake_control_unmap_virtual_calls == 1);
	require(fake_control_unmap_memory_calls == 1);
	mix_signed(&digest, fake_control_copy_to_fail_at);

	reset_fake_work();
	require(fake_control_getcred_call(0x7500UL) == 0);
	require(fake_control_cred_phys_to_virt_calls == 1);
	require(fake_control_cred_phys_to_virt_phys == 0x7500UL);
	for (int i = 0; i < 8; i++) {
		require(fake_control_cred_calls[i] == 1);
		require(fake_control_cred_kernel_values[i] == 1000 + i);
	}
	mix_signed(&digest, fake_control_cred_kernel_values[0]);
	mix_signed(&digest, fake_control_cred_kernel_values[7]);

	reset_fake_work();
	{
		int user_cred[8] = { 0 };

		require(fake_control_getcredv_call(user_cred) == 0);
		require(fake_control_copy_to_calls == 1);
		require(fake_control_copy_to_dst == user_cred);
		require(fake_control_copy_to_size == sizeof(user_cred));
		for (int i = 0; i < 8; i++) {
			require(fake_control_cred_calls[i] == 1);
			require(user_cred[i] == 1000 + i);
		}
		mix_signed(&digest, user_cred[3]);
		mix_signed(&digest, user_cred[6]);
	}

	reset_fake_work();
	{
		int user_cred[8] = { 0 };

		fake_control_copy_to_fail = 1;
		require(fake_control_getcredv_call(user_cred) == -14);
		require(fake_control_copy_to_calls == 1);
		require(user_cred[0] == 0);
		mix_signed(&digest, fake_control_copy_to_fail);
	}

	reset_fake_work();
	require(mcctrl_control_getcred_body_result(
		0x7501UL, NULL, fake_control_current_uid,
		fake_control_current_euid, fake_control_current_suid,
		fake_control_current_fsuid, fake_control_current_gid,
		fake_control_current_egid, fake_control_current_sgid,
		fake_control_current_fsgid) == -22);
	require(fake_control_cred_phys_to_virt_calls == 0);

	reset_fake_work();
	require(mcctrl_control_getcredv_body_result(
		fake_control_cred_kernel_values, fake_control_copy_to_user,
		NULL, fake_control_current_euid, fake_control_current_suid,
		fake_control_current_fsuid, fake_control_current_gid,
		fake_control_current_egid, fake_control_current_sgid,
		fake_control_current_fsgid) == -22);
	require(fake_control_copy_to_calls == 0);

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };
		char src[32] = "abcdef";

		desc.dest = dest;
		desc.src = src;
		desc.n = 6;
		desc.result = -1;
		fake_control_strncpy_ret[0] = 6;
		require(fake_control_strncpy_call(&desc, 4096) == 0);
		require(fake_control_copy_from_calls == 1);
		require(fake_control_strncpy_alloc_calls == 1);
		require(fake_control_strncpy_calls == 1);
		require(fake_control_strncpy_want[0] == 6);
		require(fake_control_strncpy_src[0] == src);
		require(fake_control_strncpy_copy_to_calls == 2);
		require(fake_control_strncpy_free_calls == 1);
		require(fake_control_strncpy_freed == fake_control_strncpy_page);
		require(desc.result == 6);
		require(!memcmp(dest, "aaaaaa", 6));
		mix_signed(&digest, desc.result);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };
		char src[32] = "abcdef";

		desc.dest = dest;
		desc.src = src;
		desc.n = 10;
		desc.result = -1;
		fake_control_strncpy_ret[0] = 3;
		require(fake_control_strncpy_call(&desc, 4096) == 0);
		require(fake_control_strncpy_copy_to_calls == 2);
		require(desc.result == 3);
		require(dest[0] == 'a');
		require(dest[3] == '\0');
		mix_signed(&digest, desc.result);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };
		char src[32] = "abcdef";

		desc.dest = dest;
		desc.src = src;
		desc.n = 10;
		desc.result = 0;
		fake_control_strncpy_ret[0] = 5;
		fake_control_strncpy_fail_data_copy = 1;
		require(fake_control_strncpy_call(&desc, 4096) == 0);
		require(fake_control_strncpy_copy_to_calls == 2);
		require(desc.result == -14);
		require(dest[0] == 0);
		mix_signed(&digest, desc.result);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };
		char src[32] = "abcdef";

		desc.dest = dest;
		desc.src = src;
		desc.n = 10;
		desc.result = 0;
		fake_control_strncpy_ret[0] = -5;
		require(fake_control_strncpy_call(&desc, 4096) == 0);
		require(fake_control_strncpy_copy_to_calls == 1);
		require(desc.result == -5);
		mix_signed(&digest, desc.result);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };

		memset(&desc, 0, sizeof(desc));
		desc.dest = dest;
		fake_control_copy_from_fail = 1;
		require(fake_control_strncpy_call(&desc, 4096) == -14);
		require(fake_control_strncpy_alloc_calls == 0);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };

		memset(&desc, 0, sizeof(desc));
		desc.dest = dest;
		fake_control_strncpy_alloc_fail = 1;
		require(fake_control_strncpy_call(&desc, 4096) == -12);
		require(fake_control_strncpy_alloc_calls == 1);
		require(fake_control_strncpy_free_calls == 0);
	}

	reset_fake_work();
	{
		struct mcctrl_control_strncpy_desc desc;
		char dest[32] = { 0 };
		char src[32] = "abcdef";

		desc.dest = dest;
		desc.src = src;
		desc.n = 6;
		desc.result = 0;
		fake_control_strncpy_ret[0] = 2;
		fake_control_strncpy_fail_desc_copy = 1;
		require(fake_control_strncpy_call(&desc, 4096) == -14);
		require(fake_control_strncpy_free_calls == 1);
		require(desc.result == 0);
	}

	reset_fake_work();
	require(fake_control_destroy_ppd_call(0x7600UL, 1234) == 0);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_get_ppd_pid == 1234);
	require(fake_control_put_ppd_calls == 2);
	require(fake_control_put_ppd_seen == &fake_control_ppd_token);
	require(fake_control_destroy_log_calls == 2);
	require(fake_control_destroy_log_stage[0] == 1);
	require(fake_control_destroy_log_stage[1] == 1);
	require(fake_control_destroy_log_ppd[0] == &fake_control_ppd_token);
	mix_signed(&digest, fake_control_put_ppd_calls);

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_destroy_ppd_call(0x7601UL, 1235) == 0);
	require(fake_control_get_ppd_calls == 0);
	require(fake_control_put_ppd_calls == 0);
	require(fake_control_destroy_log_calls == 1);
	require(fake_control_destroy_log_stage[0] == 0);
	require(fake_control_destroy_log_pid[0] == 1235);
	mix_signed(&digest, fake_control_destroy_log_stage[0]);

	reset_fake_work();
	fake_control_missing_ppd = 1;
	require(fake_control_destroy_ppd_call(0x7602UL, 1236) == 0);
	require(fake_control_get_ppd_calls == 1);
	require(fake_control_put_ppd_calls == 0);
	require(fake_control_destroy_log_calls == 1);
	require(fake_control_destroy_log_stage[0] == 2);
	mix_signed(&digest, fake_control_destroy_log_stage[0]);

	reset_fake_work();
	require(mcctrl_control_destroy_ppd_body_result(
		0x7603UL, 1237, NULL, fake_control_get_ppd,
		fake_control_put_ppd, fake_control_destroy_ppd_log) == -22);
	require(fake_control_get_ppd_calls == 0);

	reset_fake_work();
	require(fake_control_close_exec_call(0x7700UL, 41) == 0);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_validate_os_seen == 0x7700UL);
	require(fake_control_drop_exec_calls == 1);
	require(fake_control_drop_exec_os == 0x7700UL);
	require(fake_control_drop_exec_pid == 41);
	mix_signed(&digest, fake_control_drop_exec_pid);

	reset_fake_work();
	fake_control_drop_exec_ret = 0;
	require(fake_control_close_exec_call(0x7701UL, 42) == 22);
	require(fake_control_drop_exec_calls == 1);
	mix_signed(&digest, fake_control_drop_exec_ret);

	reset_fake_work();
	fake_control_validate_os_ret = -1;
	require(fake_control_close_exec_call(0x7702UL, 43) == 22);
	require(fake_control_validate_os_calls == 1);
	require(fake_control_drop_exec_calls == 0);

	reset_fake_work();
	require(mcctrl_control_close_exec_body_result(
		0x7703UL, 44, NULL, fake_control_drop_exec) == -22);
	require(fake_control_drop_exec_calls == 0);

	reset_fake_work();
	{
		int fake_file;

		require(fake_control_newprocess_call(0x7800UL,
			&fake_file) == 0);
		require(fake_control_new_info_calls == 1);
		require(fake_control_new_info_os == 0x7800UL);
		require(fake_control_new_info_file == &fake_file);
		require(fake_control_current_pid_calls == 1);
		require(fake_control_set_info_pid_calls == 1);
		require(fake_control_set_info_pid_value ==
				fake_control_current_pid_value);
		require(fake_control_new_info_token.pid ==
				fake_control_current_pid_value);
		require(fake_control_register_release_calls == 1);
		require(fake_control_register_release_file == &fake_file);
		require(fake_control_register_release_info ==
				&fake_control_new_info_token);
		require(fake_control_set_private_calls == 1);
		require(fake_control_set_private_file == &fake_file);
		require(fake_control_set_private_info ==
				&fake_control_new_info_token);
		mix_signed(&digest, fake_control_new_info_token.pid);
	}

	reset_fake_work();
	fake_control_new_info_fail = 1;
	require(fake_control_newprocess_call(0x7801UL,
		(void *)0xbeefUL) == -12);
	require(fake_control_new_info_calls == 1);
	require(fake_control_current_pid_calls == 0);
	require(fake_control_register_release_calls == 0);
	require(fake_control_set_private_calls == 0);

	reset_fake_work();
	require(mcctrl_control_newprocess_body_result(
		0x7802UL, (void *)0xbeefUL, NULL, fake_control_new_info,
		fake_control_set_info_pid, fake_control_register_release,
		fake_control_set_private) == -22);
	require(fake_control_new_info_calls == 0);

	reset_fake_work();
	{
		int fake_file;

		fake_control_start_user_desc.cpu = 6;
		fake_control_start_user_desc.pid = 4321;
		fake_control_start_user_desc.user_start = 0x1000UL;
		fake_control_start_user_desc.user_end = 0x9000UL;
		fake_control_start_user_desc.rprocess = 0xbeefcafeUL;
		fake_control_start_prev_info.prepare_thread = 0x12345678UL;
		require(fake_control_start_image_call(0x7900UL,
			&fake_file) == 0);
		require(fake_control_get_usrdata_calls == 1);
		require(fake_control_last_os == 0x7900UL);
		require(fake_control_start_alloc_calls == 1);
		require(fake_control_start_alloc_size ==
				sizeof(fake_control_start_user_desc));
		require(fake_control_copy_from_calls == 1);
		require(fake_control_copy_from_src ==
				&fake_control_start_user_desc);
		require(fake_control_copy_from_dst ==
				&fake_control_start_local_desc);
		require(fake_control_copy_from_size ==
				sizeof(fake_control_start_user_desc));
		require(fake_control_start_get_private_calls == 1);
		require(fake_control_start_private_file == &fake_file);
		require(fake_control_start_new_info_calls == 1);
		require(fake_control_start_new_info_os == 0x7900UL);
		require(fake_control_start_new_info_file == &fake_file);
		require(fake_control_start_info_prepare_calls == 1);
		require(fake_control_start_set_info_calls == 1);
		require(fake_control_start_new_info.pid == 4321);
		require(fake_control_start_new_info.cpu == 6);
		require(fake_control_start_new_info.user_start == 0x1000UL);
		require(fake_control_start_new_info.user_end == 0x9000UL);
		require(fake_control_start_set_info_prepare_thread ==
				0x12345678UL);
		require(fake_control_register_release_calls == 1);
		require(fake_control_register_release_file == &fake_file);
		require(fake_control_register_release_info ==
				&fake_control_start_new_info);
		require(fake_control_set_private_calls == 1);
		require(fake_control_set_private_file == &fake_file);
		require(fake_control_set_private_info ==
				&fake_control_start_new_info);
		require(fake_control_start_set_recv_calls == 1);
		require(fake_control_start_set_recv_os == 0x7900UL);
		require(fake_control_start_set_recv_cpu == 6);
		require(fake_control_start_set_last_calls == 1);
		require(fake_control_start_set_last_usrdata ==
				&fake_control_usrdata_token);
		require(fake_control_start_set_last_cpu == 6);
		require(fake_control_start_send_calls == 1);
		require(fake_control_start_send_os == 0x7900UL);
		require(fake_control_start_send_cpu == 6);
		require(fake_control_start_send_rprocess == 0xbeefcafeUL);
		require(fake_control_start_clear_calls == 1);
		require(fake_control_start_new_info.prepare_thread == 0);
		require(fake_control_start_free_calls == 1);
		require(fake_control_start_freed == &fake_control_start_local_desc);
		require(fake_control_start_log_calls == 0);
		mix_signed(&digest, fake_control_start_new_info.pid);
		mix(&digest, fake_control_start_send_rprocess);
	}

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_start_image_call(0x7901UL,
		(void *)0xc001UL) == -22);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_start_alloc_calls == 0);
	require(fake_control_start_log_calls == 1);
	require(fake_control_start_log_stage[0] == 0);
	mix_signed(&digest, fake_control_start_log_stage[0]);

	reset_fake_work();
	fake_control_start_alloc_fail = 1;
	require(fake_control_start_image_call(0x7902UL,
		(void *)0xc002UL) == -12);
	require(fake_control_start_alloc_calls == 1);
	require(fake_control_copy_from_calls == 0);
	require(fake_control_start_free_calls == 0);
	require(fake_control_start_log_calls == 1);
	require(fake_control_start_log_stage[0] == 1);
	mix_signed(&digest, fake_control_start_log_stage[0]);

	reset_fake_work();
	fake_control_copy_from_fail = 1;
	require(fake_control_start_image_call(0x7903UL,
		(void *)0xc003UL) == -14);
	require(fake_control_start_alloc_calls == 1);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_start_free_calls == 1);
	require(fake_control_start_new_info_calls == 0);
	require(fake_control_start_send_calls == 0);

	reset_fake_work();
	fake_control_start_user_desc.cpu = 2;
	fake_control_start_new_info_fail = 1;
	require(fake_control_start_image_call(0x7904UL,
		(void *)0xc004UL) == -12);
	require(fake_control_start_get_private_calls == 1);
	require(fake_control_start_new_info_calls == 1);
	require(fake_control_start_free_calls == 1);
	require(fake_control_register_release_calls == 0);
	require(fake_control_start_send_calls == 0);

	reset_fake_work();
	fake_control_start_user_desc.cpu = 3;
	fake_control_start_user_desc.pid = 9876;
	fake_control_start_user_desc.user_start = 0x2200UL;
	fake_control_start_user_desc.user_end = 0x3300UL;
	fake_control_start_user_desc.rprocess = 0xabcddcbaUL;
	fake_control_start_prev_info.prepare_thread = 0x55667788UL;
	fake_control_start_send_ret = -5;
	require(fake_control_start_image_call(0x7905UL,
		(void *)0xc005UL) == -5);
	require(fake_control_start_set_info_prepare_thread == 0x55667788UL);
	require(fake_control_start_clear_calls == 0);
	require(fake_control_start_new_info.prepare_thread == 0x55667788UL);
	require(fake_control_start_log_calls == 1);
	require(fake_control_start_log_stage[0] == 2);
	require(fake_control_start_log_ret[0] == -5);
	require(fake_control_start_free_calls == 1);
	mix_signed(&digest, fake_control_start_log_ret[0]);

	reset_fake_work();
	for (int i = 0; i < 128; i++)
		fake_control_signal_user_desc.info[i] = (unsigned char)(i + 7);
	fake_control_signal_user_desc.cpu = 4;
	fake_control_signal_user_desc.pid = 24680;
	fake_control_signal_user_desc.tid = 13579;
	fake_control_signal_user_desc.sig = 12;
	require(fake_control_send_signal_call(0x7a00UL) == 0);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_last_os == 0x7a00UL);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_copy_from_src == &fake_control_signal_user_desc);
	require(fake_control_copy_from_size ==
			sizeof(fake_control_signal_user_desc));
	require(fake_control_signal_alloc_calls == 1);
	require(fake_control_signal_alloc_size ==
			sizeof(fake_control_signal_local_desc));
	require(fake_control_signal_local_desc.msig.cond == 0);
	require(fake_control_signal_local_desc.msig.sig == 12);
	require(fake_control_signal_local_desc.msig.pid == 24680);
	require(fake_control_signal_local_desc.msig.tid == 13579);
	require(memcmp(fake_control_signal_local_desc.msig.info,
			fake_control_signal_user_desc.info, 128) == 0);
	require(fake_control_signal_vtop_calls == 1);
	require(fake_control_signal_vtop_ptr ==
			&fake_control_signal_local_desc.msig);
	require(fake_control_signal_send_calls == 1);
	require(fake_control_signal_send_os == 0x7a00UL);
	require(fake_control_signal_send_cpu == 4);
	require(fake_control_signal_send_msg == SCD_MSG_SEND_SIGNAL);
	require(fake_control_signal_send_ref == 4);
	require(fake_control_signal_send_pid == 24680);
	require(fake_control_signal_send_arg == fake_control_signal_vtop_result);
	require(fake_control_signal_send_timeout == -1000);
	require(fake_control_signal_send_desc ==
			&fake_control_signal_local_desc);
	require(fake_control_signal_free_calls == 1);
	require(fake_control_signal_freed == &fake_control_signal_local_desc);
	require(fake_control_signal_log_calls == 0);
	mix_signed(&digest, fake_control_signal_local_desc.msig.sig);
	mix(&digest, fake_control_signal_send_arg);

	reset_fake_work();
	fake_control_usrdata_missing = 1;
	require(fake_control_send_signal_call(0x7a01UL) == -22);
	require(fake_control_get_usrdata_calls == 1);
	require(fake_control_copy_from_calls == 0);
	require(fake_control_signal_alloc_calls == 0);
	require(fake_control_signal_log_calls == 1);
	require(fake_control_signal_log_stage[0] == 0);

	reset_fake_work();
	fake_control_copy_from_fail = 1;
	require(fake_control_send_signal_call(0x7a02UL) == -14);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_signal_alloc_calls == 0);
	require(fake_control_signal_send_calls == 0);

	reset_fake_work();
	fake_control_signal_alloc_fail = 1;
	require(fake_control_send_signal_call(0x7a03UL) == -12);
	require(fake_control_copy_from_calls == 1);
	require(fake_control_signal_alloc_calls == 1);
	require(fake_control_signal_send_calls == 0);
	require(fake_control_signal_free_calls == 0);

	reset_fake_work();
	fake_control_signal_user_desc.cpu = 2;
	fake_control_signal_user_desc.pid = 12345;
	fake_control_signal_user_desc.tid = 54321;
	fake_control_signal_user_desc.sig = 15;
	fake_control_signal_send_ret = -9;
	fake_control_signal_send_do_free = 1;
	require(fake_control_send_signal_call(0x7a04UL) == -9);
	require(fake_control_signal_send_calls == 1);
	require(fake_control_signal_free_calls == 1);
	require(fake_control_signal_log_calls == 1);
	require(fake_control_signal_log_stage[0] == 1);
	require(fake_control_signal_log_ret[0] == -9);

	reset_fake_work();
	fake_control_signal_user_desc.cpu = 1;
	fake_control_signal_user_desc.pid = 543;
	fake_control_signal_user_desc.tid = 654;
	fake_control_signal_user_desc.sig = 9;
	fake_control_signal_send_ret = -11;
	fake_control_signal_send_do_free = 0;
	require(fake_control_send_signal_call(0x7a05UL) == -11);
	require(fake_control_signal_send_calls == 1);
	require(fake_control_signal_free_calls == 0);
	require(fake_control_signal_log_calls == 1);
	require(fake_control_signal_log_ret[0] == -11);
	mix_signed(&digest, fake_control_signal_log_ret[0]);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_packet_handler_body_result(
		(void *)0xabc0, SCD_MSG_PROCFS_TID_CREATE, 321, 654,
		0xfeed0000UL, sizeof(fake_work), fake_alloc,
		fake_init_schedule, fake_alloc_failed));
	require(fake_alloc_calls == 1);
	require(fake_alloc_size == sizeof(fake_work));
	require(fake_init_schedule_calls == 1);
	require(fake_scheduled_work == &fake_work);
	require(fake_work.os == (void *)0xabc0);
	require(fake_work.msg == SCD_MSG_PROCFS_TID_CREATE);
	require(fake_work.pid == 321);
	require(fake_work.arg == 654);
	require(fake_work.resp_pa == 0xfeed0000UL);
	mix_signed(&digest, fake_init_schedule_calls);
	mix(&digest, fake_work.resp_pa);

	reset_fake_work();
	fake_fail_alloc = 1;
	mix_signed(&digest, mcctrl_procfs_packet_handler_body_result(
		(void *)0xabc0, SCD_MSG_PROCFS_TID_DELETE, 1, 2, 3,
		sizeof(fake_work), fake_alloc, fake_init_schedule,
		fake_alloc_failed));
	require(fake_alloc_calls == 1);
	require(fake_alloc_failed_calls == 1);
	require(fake_init_schedule_calls == 0);
	mix_signed(&digest, fake_alloc_failed_calls);

	reset_fake_work();
	fake_work.os = (void *)0xbeef0;
	fake_work.msg = SCD_MSG_PROCFS_TID_CREATE;
	fake_work.pid = 777;
	fake_work.arg = 888;
	fake_work.resp_pa = 0xcafe0000UL;
	mix_signed(&digest, mcctrl_procfs_work_main_body_result(
		&fake_work, sizeof(int), fake_get_index, fake_add_tid,
		fake_delete_tid, fake_os_to_dev, fake_map_memory,
		fake_map_virtual, fake_unmap_virtual, fake_unmap_memory,
		fake_unknown_work, fake_free_work));
	require(fake_add_calls == 1);
	require(fake_delete_calls == 0);
	require(fake_last_osnum == 19);
	require(fake_last_pid == 777);
	require(fake_last_tid == 888);
	require(fake_map_memory_calls == 1);
	require(fake_map_virtual_calls == 1);
	require(fake_done_value == 1);
	require(fake_unmap_virtual_calls == 1);
	require(fake_unmap_memory_calls == 1);
	require(fake_free_calls == 1);
	require(fake_freed_work == &fake_work);
	mix_signed(&digest, fake_add_calls);
	mix_signed(&digest, fake_done_value);
	mix(&digest, fake_last_resp_pa);

	reset_fake_work();
	fake_work.os = (void *)0xbeef0;
	fake_work.msg = SCD_MSG_PROCFS_TID_DELETE;
	fake_work.pid = 111;
	fake_work.arg = 222;
	mix_signed(&digest, mcctrl_procfs_work_main_body_result(
		&fake_work, sizeof(int), fake_get_index, fake_add_tid,
		fake_delete_tid, fake_os_to_dev, fake_map_memory,
		fake_map_virtual, fake_unmap_virtual, fake_unmap_memory,
		fake_unknown_work, fake_free_work));
	require(fake_add_calls == 0);
	require(fake_delete_calls == 1);
	require(fake_last_osnum == 19);
	require(fake_last_pid == 111);
	require(fake_last_tid == 222);
	require(fake_map_memory_calls == 0);
	require(fake_free_calls == 1);
	mix_signed(&digest, fake_delete_calls);

	reset_fake_work();
	fake_work.msg = 12345;
	fake_work.pid = 12;
	fake_work.arg = 34;
	mix_signed(&digest, mcctrl_procfs_work_main_body_result(
		&fake_work, sizeof(int), fake_get_index, fake_add_tid,
		fake_delete_tid, fake_os_to_dev, fake_map_memory,
		fake_map_virtual, fake_unmap_virtual, fake_unmap_memory,
		fake_unknown_work, fake_free_work));
	require(fake_unknown_calls == 1);
	require(fake_unknown_msg == 12345);
	require(fake_free_calls == 1);
	mix_signed(&digest, fake_unknown_calls);

	reset_fake_work();
	procfs_result = mcctrl_procfs_find_base_entry_body_result(
		7, fake_procfs_format_mcos, fake_procfs_find_entry);
	require(procfs_result == &fake_procfs_base_entry);
	require(fake_procfs_format_mcos_calls == 1);
	require(fake_procfs_find_calls == 1);
	require(!strcmp(fake_procfs_last_name, "mcos7"));
	mix_signed(&digest, fake_procfs_find_calls);

	reset_fake_work();
	procfs_result = mcctrl_procfs_find_pid_entry_body_result(
		7, 321, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry);
	require(procfs_result == &fake_procfs_pid_entry);
	require(fake_procfs_format_mcos_calls == 1);
	require(fake_procfs_format_decimal_calls == 1);
	require(fake_procfs_find_calls == 2);
	require(!strcmp(fake_procfs_last_name, "321"));
	mix_signed(&digest, fake_procfs_find_calls);

	reset_fake_work();
	fake_procfs_missing_base = 1;
	procfs_result = mcctrl_procfs_find_pid_entry_body_result(
		7, 321, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry);
	require(procfs_result == NULL);
	require(fake_procfs_format_decimal_calls == 0);
	require(fake_procfs_find_calls == 1);
	mix_signed(&digest, fake_procfs_format_decimal_calls);

	reset_fake_work();
	procfs_result = mcctrl_procfs_find_tid_entry_body_result(
		7, 321, 654, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry);
	require(procfs_result == &fake_procfs_tid_entry);
	require(fake_procfs_format_mcos_calls == 1);
	require(fake_procfs_format_decimal_calls == 2);
	require(fake_procfs_find_calls == 4);
	require(!strcmp(fake_procfs_last_name, "654"));
	mix_signed(&digest, fake_procfs_format_decimal_calls);

	reset_fake_work();
	fake_procfs_missing_task = 1;
	procfs_result = mcctrl_procfs_find_tid_entry_body_result(
		7, 321, 654, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry);
	require(procfs_result == NULL);
	require(fake_procfs_find_calls == 3);
	mix_signed(&digest, fake_procfs_find_calls);

	reset_fake_work();
	procfs_result = mcctrl_procfs_get_base_entry_body_result(
		8, fake_procfs_format_mcos, fake_procfs_find_entry,
		fake_procfs_add_entry, fake_procfs_set_osnum);
	require(procfs_result == &fake_procfs_base_entry);
	require(fake_procfs_add_calls == 0);
	require(fake_procfs_set_osnum_calls == 0);
	mix_signed(&digest, fake_procfs_add_calls);

	reset_fake_work();
	fake_procfs_missing_base = 1;
	procfs_result = mcctrl_procfs_get_base_entry_body_result(
		8, fake_procfs_format_mcos, fake_procfs_find_entry,
		fake_procfs_add_entry, fake_procfs_set_osnum);
	require(procfs_result == &fake_procfs_new_base_entry);
	require(fake_procfs_add_calls == 1);
	require(fake_procfs_set_osnum_calls == 1);
	require(fake_procfs_last_set_osnum == 8);
	require(fake_procfs_last_mode == PROCFS_DIR_MODE_0555);
	mix_signed(&digest, fake_procfs_set_osnum_calls);

	reset_fake_work();
	fake_procfs_missing_pid = 1;
	procfs_result = mcctrl_procfs_get_pid_entry_body_result(
		8, 444, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry,
		fake_procfs_add_entry);
	require(procfs_result == &fake_procfs_new_pid_entry);
	require(fake_procfs_add_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_base_entry);
	require(!strcmp(fake_procfs_last_name, "444"));
	require(fake_procfs_last_mode == PROCFS_DIR_MODE_0555);
	mix_signed(&digest, fake_procfs_add_calls);

	reset_fake_work();
	fake_procfs_missing_tid = 1;
	procfs_result = mcctrl_procfs_get_tid_entry_body_result(
		8, 444, 555, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry,
		fake_procfs_add_entry);
	require(procfs_result == &fake_procfs_new_tid_entry);
	require(fake_procfs_add_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_task_entry);
	require(!strcmp(fake_procfs_last_name, "555"));
	mix_signed(&digest, fake_procfs_add_calls);

	reset_fake_work();
	fake_procfs_missing_tid = 1;
	fake_procfs_fail_add = 1;
	procfs_result = mcctrl_procfs_get_tid_entry_body_result(
		8, 444, 555, fake_procfs_format_mcos,
		fake_procfs_format_decimal, fake_procfs_find_entry,
		fake_procfs_add_entry);
	require(procfs_result == NULL);
	require(fake_procfs_add_calls == 1);
	mix_signed(&digest, fake_procfs_fail_add);

	reset_fake_work();
	procfs_result = mcctrl_procfs_find_base_entry_body_result(
		1, NULL, fake_procfs_find_entry);
	require(procfs_result == NULL);
	require(fake_procfs_find_calls == 0);
	mix_signed(&digest, fake_procfs_find_calls);

	reset_fake_work();
	fake_procfs_no_cred = 1;
	mix_signed(&digest, mcctrl_procfs_add_tid_entry_body_result(
		9, 101, 202, fake_procfs_get_cred, fake_procfs_lock,
		fake_procfs_unlock, fake_procfs_find_pid_direct,
		fake_procfs_get_pid_direct, fake_procfs_add_pid_entries,
		fake_procfs_add_tid_cred));
	require(fake_procfs_get_cred_calls == 1);
	require(fake_procfs_lock_calls == 0);
	require(fake_procfs_add_tid_cred_calls == 0);
	mix_signed(&digest, fake_procfs_get_cred_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_add_tid_entry_body_result(
		9, 101, 202, fake_procfs_get_cred, fake_procfs_lock,
		fake_procfs_unlock, fake_procfs_find_pid_direct,
		fake_procfs_get_pid_direct, fake_procfs_add_pid_entries,
		fake_procfs_add_tid_cred));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_find_pid_direct_calls == 1);
	require(fake_procfs_get_pid_direct_calls == 0);
	require(fake_procfs_add_pid_entries_calls == 0);
	require(fake_procfs_add_tid_cred_calls == 1);
	require(fake_procfs_last_osnum == 9);
	require(fake_procfs_last_pid == 101);
	require(fake_procfs_last_tid == 202);
	require(fake_procfs_last_cred == &fake_procfs_cred);
	mix_signed(&digest, fake_procfs_add_tid_cred_calls);

	reset_fake_work();
	fake_procfs_missing_pid = 1;
	mix_signed(&digest, mcctrl_procfs_add_tid_entry_body_result(
		9, 101, 202, fake_procfs_get_cred, fake_procfs_lock,
		fake_procfs_unlock, fake_procfs_find_pid_direct,
		fake_procfs_get_pid_direct, fake_procfs_add_pid_entries,
		fake_procfs_add_tid_cred));
	require(fake_procfs_find_pid_direct_calls == 1);
	require(fake_procfs_get_pid_direct_calls == 1);
	require(fake_procfs_add_pid_entries_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_new_pid_entry);
	require(fake_procfs_last_cred == &fake_procfs_cred);
	require(fake_procfs_add_tid_cred_calls == 1);
	mix_signed(&digest, fake_procfs_add_pid_entries_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_add_pid_entry_body_result(
		9, 303, fake_procfs_get_cred, fake_procfs_lock,
		fake_procfs_unlock, fake_procfs_get_pid_direct,
		fake_procfs_add_pid_entries, fake_procfs_add_tid_cred));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_get_pid_direct_calls == 1);
	require(fake_procfs_add_pid_entries_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_new_pid_entry);
	require(fake_procfs_add_tid_cred_calls == 1);
	require(fake_procfs_last_tid == 303);
	mix_signed(&digest, fake_procfs_get_pid_direct_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_add_pid_entry_body_result(
		9, 303, NULL, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_get_pid_direct, fake_procfs_add_pid_entries,
		fake_procfs_add_tid_cred));
	require(fake_procfs_lock_calls == 0);
	mix_signed(&digest, fake_procfs_lock_calls);

	reset_fake_work();
	fake_procfs_missing_tid = 1;
	mix_signed(&digest, mcctrl_procfs_delete_tid_entry_body_result(
		9, 101, 202, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_tid_direct, fake_procfs_delete_entry));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_delete_entry_calls == 0);
	mix_signed(&digest, fake_procfs_delete_entry_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_delete_tid_entry_body_result(
		9, 101, 202, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_tid_direct, fake_procfs_delete_entry));
	require(fake_procfs_delete_entry_calls == 1);
	require(fake_procfs_deleted_entry == &fake_procfs_tid_entry);
	mix_signed(&digest, fake_procfs_delete_entry_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_delete_pid_entry_body_result(
		9, 101, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_pid_direct, fake_procfs_delete_entry));
	require(fake_procfs_delete_entry_calls == 1);
	require(fake_procfs_deleted_entry == &fake_procfs_pid_entry);
	mix_signed(&digest, fake_procfs_find_pid_direct_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_init_body_result(
		9, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_get_base_direct, fake_procfs_add_base_entries));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_get_base_direct_calls == 1);
	require(fake_procfs_add_base_entries_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_new_base_entry);
	mix_signed(&digest, fake_procfs_add_base_entries_calls);

	reset_fake_work();
	fake_procfs_missing_base = 1;
	mix_signed(&digest, mcctrl_procfs_exit_body_result(
		9, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_base_direct, fake_procfs_delete_entry));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_delete_entry_calls == 0);
	mix_signed(&digest, fake_procfs_find_base_direct_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_exit_body_result(
		9, fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_base_direct, fake_procfs_delete_entry));
	require(fake_procfs_delete_entry_calls == 1);
	require(fake_procfs_deleted_entry == &fake_procfs_base_entry);
	mix_signed(&digest, fake_procfs_delete_entry_calls);

	reset_fake_work();
	fake_procfs_missing_tid = 1;
	mix_signed(&digest, mcctrl_procfs_add_tid_with_cred_body_result(
		9, 101, 202, &fake_procfs_cred, fake_procfs_get_tid_direct,
		fake_procfs_add_tid_entries, fake_procfs_find_exe_data,
		fake_procfs_add_exe_link));
	require(fake_procfs_get_tid_direct_calls == 1);
	require(fake_procfs_add_tid_entries_calls == 0);
	require(fake_procfs_find_exe_data_calls == 0);
	require(fake_procfs_add_exe_link_calls == 0);
	mix_signed(&digest, fake_procfs_get_tid_direct_calls);

	reset_fake_work();
	fake_procfs_missing_exe = 1;
	mix_signed(&digest, mcctrl_procfs_add_tid_with_cred_body_result(
		9, 101, 202, &fake_procfs_cred, fake_procfs_get_tid_direct,
		fake_procfs_add_tid_entries, fake_procfs_find_exe_data,
		fake_procfs_add_exe_link));
	require(fake_procfs_add_tid_entries_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_tid_entry);
	require(fake_procfs_last_cred == &fake_procfs_cred);
	require(fake_procfs_find_exe_data_calls == 1);
	require(fake_procfs_add_exe_link_calls == 0);
	mix_signed(&digest, fake_procfs_add_tid_entries_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_add_tid_with_cred_body_result(
		9, 101, 202, &fake_procfs_cred, fake_procfs_get_tid_direct,
		fake_procfs_add_tid_entries, fake_procfs_find_exe_data,
		fake_procfs_add_exe_link));
	require(fake_procfs_add_tid_entries_calls == 1);
	require(fake_procfs_find_exe_data_calls == 1);
	require(fake_procfs_add_exe_link_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_tid_entry);
	require(fake_procfs_last_target == (void *)0x657865UL);
	require(fake_procfs_last_cred == &fake_procfs_cred);
	mix_signed(&digest, fake_procfs_add_exe_link_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_add_tid_with_cred_body_result(
		9, 101, 202, &fake_procfs_cred, NULL,
		fake_procfs_add_tid_entries, fake_procfs_find_exe_data,
		fake_procfs_add_exe_link));
	require(fake_procfs_get_tid_direct_calls == 0);
	mix_signed(&digest, fake_procfs_get_tid_direct_calls);

	reset_fake_work();
	fake_procfs_missing_pid = 1;
	mix_signed(&digest, mcctrl_procfs_exe_link_body_result(
		9, 101, "/bin/app", fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_pid_direct, fake_procfs_add_pid_exe,
		fake_procfs_store_exe_path, fake_procfs_add_task_exe_links));
	require(fake_procfs_lock_calls == 1);
	require(fake_procfs_unlock_calls == 1);
	require(fake_procfs_find_pid_direct_calls == 1);
	require(fake_procfs_add_pid_exe_calls == 0);
	mix_signed(&digest, fake_procfs_find_pid_direct_calls);

	reset_fake_work();
	fake_procfs_fail_add = 1;
	mix_signed(&digest, mcctrl_procfs_exe_link_body_result(
		9, 101, "/bin/app", fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_pid_direct, fake_procfs_add_pid_exe,
		fake_procfs_store_exe_path, fake_procfs_add_task_exe_links));
	require(fake_procfs_add_pid_exe_calls == 1);
	require(fake_procfs_store_exe_path_calls == 0);
	require(fake_procfs_add_task_exe_links_calls == 0);
	require(!strcmp(fake_procfs_last_path, "/bin/app"));
	mix_signed(&digest, fake_procfs_add_pid_exe_calls);

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_exe_link_body_result(
		9, 101, "/bin/app", fake_procfs_lock, fake_procfs_unlock,
		fake_procfs_find_pid_direct, fake_procfs_add_pid_exe,
		fake_procfs_store_exe_path, fake_procfs_add_task_exe_links));
	require(fake_procfs_add_pid_exe_calls == 1);
	require(fake_procfs_store_exe_path_calls == 1);
	require(fake_procfs_add_task_exe_links_calls == 1);
	require(fake_procfs_last_parent == &fake_procfs_pid_entry);
	require(!strcmp(fake_procfs_last_path, "/bin/app"));
	mix_signed(&digest, fake_procfs_add_task_exe_links_calls);

	{
		struct fake_procfs_path_entry base = { "mcos9", NULL };
		struct fake_procfs_path_entry pid = { "123", &base };
		struct fake_procfs_path_entry task = { "task", &pid };
		struct fake_procfs_path_entry tid = { "456", &task };
		char path[64];
		char *start;

		reset_fake_work();
		memset(path, 0x5a, sizeof(path));
		start = mcctrl_procfs_getpath_body_result(
			&tid, path, sizeof(path), fake_procfs_path_name,
			fake_procfs_path_parent);
		require(start != NULL);
		require(start >= path && start < path + sizeof(path));
		require(!strcmp(start, "mcos9/123/task/456"));
		require(path[sizeof(path) - 1] == '\0');
		mix(&digest, (unsigned long)(start - path));
		mix(&digest, strlen(start));

		require(mcctrl_procfs_getpath_body_result(
			NULL, path, sizeof(path), fake_procfs_path_name,
			fake_procfs_path_parent) == NULL);
		require(mcctrl_procfs_getpath_body_result(
			&tid, path, 0, fake_procfs_path_name,
			fake_procfs_path_parent) == NULL);
		require(mcctrl_procfs_getpath_body_result(
			&tid, path, sizeof(path), NULL,
			fake_procfs_path_parent) == NULL);
	}

	{
		struct fake_procfs_entry_table entries[] = {
			{ "stat", 0444, (void *)0x1111UL },
			{ "mem", 0600, (void *)0x2222UL },
			{ NULL, 0, NULL },
		};
		int uid = 77;
		int gid = 88;
		long count;

		reset_fake_work();
		count = mcctrl_procfs_add_entries_body_result(
			(void *)0xabc0UL, entries, sizeof(entries[0]), &uid,
			&gid, fake_procfs_entry_table_name,
			fake_procfs_entry_table_mode,
			fake_procfs_entry_table_fops,
			fake_procfs_entry_table_next,
			fake_procfs_add_entry_with_ids);
		require(count == 2);
		require(fake_procfs_add_entries_calls == 2);
		require(fake_procfs_add_entries_parent == (void *)0xabc0UL);
		require(fake_procfs_add_entries_name == entries[1].name);
		require(fake_procfs_add_entries_mode == 0600);
		require(fake_procfs_add_entries_fops == (void *)0x2222UL);
		require(fake_procfs_add_entries_uid == &uid);
		require(fake_procfs_add_entries_gid == &gid);
		mix_signed(&digest, count);
		mix_signed(&digest, fake_procfs_add_entries_calls);

		reset_fake_work();
		require(mcctrl_procfs_add_entries_body_result(
			(void *)0xabc0UL, NULL, sizeof(entries[0]), &uid,
			&gid, fake_procfs_entry_table_name,
			fake_procfs_entry_table_mode,
			fake_procfs_entry_table_fops,
			fake_procfs_entry_table_next,
			fake_procfs_add_entry_with_ids) == -22);
		require(fake_procfs_add_entries_calls == 0);

			require(mcctrl_procfs_add_entries_body_result(
				(void *)0xabc0UL, entries, sizeof(entries[0]), &uid,
				&gid, fake_procfs_entry_table_name, NULL,
				fake_procfs_entry_table_fops,
				fake_procfs_entry_table_next,
				fake_procfs_add_entry_with_ids) == -22);
		}

		{
			int uid = 101;
			int gid = 202;
			void *entry;

			reset_fake_work();
			fake_procfs_missing_pid = 1;
			entry = mcctrl_procfs_add_entry_body_result(
				&fake_procfs_base_entry, "leaf", 0600, &uid,
				&gid, (void *)0x5555UL, 24,
				fake_procfs_find_entry, fake_procfs_delete_entry,
				fake_procfs_entry_alloc, fake_procfs_entry_init,
				fake_procfs_entry_create_pde,
				fake_procfs_entry_commit,
				fake_procfs_entry_free,
				fake_procfs_entry_alloc_failed,
				fake_procfs_entry_create_failed);
			require(entry == &fake_procfs_lifecycle_entry);
			require(fake_procfs_find_calls == 1);
			require(fake_procfs_delete_entry_calls == 0);
			require(fake_procfs_entry_alloc_calls == 1);
			require(fake_procfs_entry_alloc_size == 29);
			require(fake_procfs_entry_init_calls == 1);
			require(!strcmp(fake_procfs_entry_init_name, "leaf"));
			require(fake_procfs_entry_create_calls == 1);
			require(fake_procfs_entry_create_mode == 0600);
			require(fake_procfs_entry_create_uid == &uid);
			require(fake_procfs_entry_create_gid == &gid);
			require(fake_procfs_entry_create_opaque == (void *)0x5555UL);
			require(fake_procfs_entry_create_entry ==
				&fake_procfs_lifecycle_entry);
			require(fake_procfs_entry_commit_calls == 1);
			require(fake_procfs_entry_commit_parent ==
				&fake_procfs_base_entry);
			require(fake_procfs_entry_commit_pde ==
				&fake_procfs_lifecycle_pde);
			require(fake_procfs_entry_commit_uid == &uid);
			require(fake_procfs_entry_commit_gid == &gid);
			require(fake_procfs_entry_free_calls == 0);
			mix_signed(&digest, fake_procfs_entry_alloc_size);
			mix_signed(&digest, fake_procfs_entry_commit_calls);

			reset_fake_work();
			entry = mcctrl_procfs_add_entry_body_result(
				&fake_procfs_base_entry, "leaf", 0444, &uid,
				&gid, NULL, 24, fake_procfs_find_entry,
				fake_procfs_delete_entry,
				fake_procfs_entry_alloc, fake_procfs_entry_init,
				fake_procfs_entry_create_pde,
				fake_procfs_entry_commit,
				fake_procfs_entry_free,
				fake_procfs_entry_alloc_failed,
				fake_procfs_entry_create_failed);
			require(entry == &fake_procfs_lifecycle_entry);
			require(fake_procfs_delete_entry_calls == 1);
			require(fake_procfs_deleted_entry == &fake_procfs_pid_entry);
			mix_signed(&digest, fake_procfs_delete_entry_calls);

			reset_fake_work();
			fake_procfs_missing_pid = 1;
			fake_procfs_entry_alloc_fail = 1;
			entry = mcctrl_procfs_add_entry_body_result(
				&fake_procfs_base_entry, "leaf", 0444, &uid,
				&gid, NULL, 24, fake_procfs_find_entry,
				fake_procfs_delete_entry,
				fake_procfs_entry_alloc, fake_procfs_entry_init,
				fake_procfs_entry_create_pde,
				fake_procfs_entry_commit,
				fake_procfs_entry_free,
				fake_procfs_entry_alloc_failed,
				fake_procfs_entry_create_failed);
			require(entry == NULL);
			require(fake_procfs_entry_alloc_failed_calls == 1);
			require(fake_procfs_entry_init_calls == 0);
			require(fake_procfs_entry_create_calls == 0);
			require(fake_procfs_entry_free_calls == 0);

			reset_fake_work();
			fake_procfs_missing_pid = 1;
			fake_procfs_entry_create_fail = 1;
			entry = mcctrl_procfs_add_entry_body_result(
				&fake_procfs_base_entry, "leaf", 0444, &uid,
				&gid, NULL, 24, fake_procfs_find_entry,
				fake_procfs_delete_entry,
				fake_procfs_entry_alloc, fake_procfs_entry_init,
				fake_procfs_entry_create_pde,
				fake_procfs_entry_commit,
				fake_procfs_entry_free,
				fake_procfs_entry_alloc_failed,
				fake_procfs_entry_create_failed);
			require(entry == NULL);
			require(fake_procfs_entry_create_failed_calls == 1);
			require(!strcmp(fake_procfs_entry_create_failed_name,
				"leaf"));
			require(fake_procfs_entry_free_calls == 1);
			require(fake_procfs_entry_free_last ==
				&fake_procfs_lifecycle_entry);
			require(fake_procfs_entry_commit_calls == 0);

			reset_fake_work();
			require(mcctrl_procfs_add_entry_body_result(
				&fake_procfs_base_entry, "leaf", 0444, &uid,
				&gid, NULL, 24, NULL, fake_procfs_delete_entry,
				fake_procfs_entry_alloc, fake_procfs_entry_init,
				fake_procfs_entry_create_pde,
				fake_procfs_entry_commit,
				fake_procfs_entry_free,
				fake_procfs_entry_alloc_failed,
				fake_procfs_entry_create_failed) == NULL);
			require(fake_procfs_find_calls == 0);
		}

		{
			int ret;

			reset_fake_work();
			fake_procfs_delete_lifecycle_child_present = 1;
			ret = mcctrl_procfs_delete_entries_body_result(
				&fake_procfs_lifecycle_entry,
				fake_procfs_delete_lifecycle_first_child,
				fake_procfs_delete_lifecycle_delete,
				fake_procfs_delete_lifecycle_unlink,
				fake_procfs_delete_lifecycle_remove,
				fake_procfs_delete_lifecycle_data,
				fake_procfs_entry_free);
			require(ret == 0);
			require(fake_procfs_delete_lifecycle_unlink_calls == 1);
			require(fake_procfs_delete_lifecycle_first_calls == 2);
			require(fake_procfs_delete_entry_calls == 1);
			require(fake_procfs_deleted_entry == &fake_procfs_task_entry);
			require(fake_procfs_delete_lifecycle_remove_calls == 1);
			require(fake_procfs_delete_lifecycle_data_calls == 1);
			require(fake_procfs_entry_free_calls == 2);
			require(fake_procfs_delete_lifecycle_freed[0] ==
				&fake_procfs_lifecycle_data);
			require(fake_procfs_delete_lifecycle_freed[1] ==
				&fake_procfs_lifecycle_entry);
			mix_signed(&digest, ret);
			mix_signed(&digest, fake_procfs_entry_free_calls);

			reset_fake_work();
			require(mcctrl_procfs_delete_entries_body_result(
				&fake_procfs_lifecycle_entry, NULL,
				fake_procfs_delete_lifecycle_delete,
				fake_procfs_delete_lifecycle_unlink,
				fake_procfs_delete_lifecycle_remove,
				fake_procfs_delete_lifecycle_data,
				fake_procfs_entry_free) == -22);
			require(fake_procfs_delete_lifecycle_unlink_calls == 0);
		}

		{
			struct fake_procfs_list_node exe = { "exe", NULL };
			struct fake_procfs_list_node task = { "task", &exe };
		struct fake_procfs_list_node stat = { "stat", &task };
		void *entry;

		reset_fake_work();
		entry = mcctrl_procfs_find_entry_body_result(
			&stat, "task", fake_procfs_first_child,
			fake_procfs_next_child, fake_procfs_list_node_name);
		require(entry == &task);
		require(fake_procfs_first_child_calls == 1);
		require(fake_procfs_entry_name_calls == 2);
		require(fake_procfs_next_child_calls == 1);
		mix_signed(&digest, fake_procfs_entry_name_calls);

		reset_fake_work();
		entry = mcctrl_procfs_find_entry_body_result(
			&stat, "missing", fake_procfs_first_child,
			fake_procfs_next_child, fake_procfs_list_node_name);
		require(entry == NULL);
		require(fake_procfs_entry_name_calls == 3);
		require(fake_procfs_next_child_calls == 3);
		mix_signed(&digest, fake_procfs_next_child_calls);

		reset_fake_work();
		entry = mcctrl_procfs_find_entry_body_result(
			&stat, "task", fake_procfs_first_child, NULL,
			fake_procfs_list_node_name);
		require(entry == NULL);
		require(fake_procfs_first_child_calls == 0);
	}

	reset_fake_work();
	procfs_result = mcctrl_procfs_get_pid_cred_body_result(
		4321, 0, fake_procfs_rcu_read_lock,
		fake_procfs_rcu_read_unlock, fake_procfs_find_vpid,
		fake_procfs_pid_task, fake_procfs_task_cred);
	require(procfs_result == &fake_procfs_cred_token);
	require(fake_procfs_rcu_lock_calls == 1);
	require(fake_procfs_rcu_unlock_calls == 1);
	require(fake_procfs_find_vpid_calls == 1);
	require(fake_procfs_pid_task_calls == 1);
	require(fake_procfs_task_cred_calls == 1);
	require(fake_procfs_last_pid == 4321);
	require(fake_procfs_last_pid_type == 0);
	mix_signed(&digest, fake_procfs_task_cred_calls);

	reset_fake_work();
	procfs_result = mcctrl_procfs_get_pid_cred_body_result(
		0, 0, fake_procfs_rcu_read_lock,
		fake_procfs_rcu_read_unlock, fake_procfs_find_vpid,
		fake_procfs_pid_task, fake_procfs_task_cred);
	require(procfs_result == NULL);
	require(fake_procfs_rcu_lock_calls == 0);
	require(fake_procfs_find_vpid_calls == 0);

	reset_fake_work();
	fake_procfs_pid_task_missing = 1;
	procfs_result = mcctrl_procfs_get_pid_cred_body_result(
		4321, 0, fake_procfs_rcu_read_lock,
		fake_procfs_rcu_read_unlock, fake_procfs_find_vpid,
		fake_procfs_pid_task, fake_procfs_task_cred);
	require(procfs_result == NULL);
	require(fake_procfs_rcu_lock_calls == 1);
	require(fake_procfs_rcu_unlock_calls == 1);
	require(fake_procfs_task_cred_calls == 0);
	mix_signed(&digest, fake_procfs_pid_task_missing);

	reset_fake_work();
	procfs_result = mcctrl_procfs_get_pid_cred_body_result(
		4321, 0, fake_procfs_rcu_read_lock, NULL,
		fake_procfs_find_vpid, fake_procfs_pid_task,
		fake_procfs_task_cred);
	require(procfs_result == NULL);
	require(fake_procfs_rcu_lock_calls == 0);

	{
		long new_pos = 99;

		reset_fake_work();
		require(mcctrl_procfs_lseek_body_result(10, 5, 0,
				&new_pos) == 5);
		require(new_pos == 5);
		require(mcctrl_procfs_lseek_body_result(10, -3, 1,
				&new_pos) == 7);
		require(new_pos == 7);
		require(mcctrl_procfs_lseek_body_result(10, 1, 2,
				&new_pos) == -22);
		require(new_pos == 7);
		mix_signed(&digest, new_pos);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_procfs_buff_open_body_result(
		&fake_procfs_base_entry, &fake_procfs_file,
		sizeof(fake_procfs_path_buf),
		sizeof(fake_procfs_info) - sizeof(fake_procfs_info.path),
		~0UL, fake_procfs_entry_osnum, fake_procfs_lookup_os,
		fake_procfs_open_alloc, fake_procfs_open_free,
		fake_procfs_get_path, fake_procfs_init_info,
		fake_procfs_set_file_private));
	require(fake_procfs_open_alloc_calls == 2);
	require(fake_procfs_init_info_calls == 1);
	require(fake_procfs_set_private_calls == 1);
	require(fake_procfs_file.private_data == &fake_procfs_info);
	require(fake_procfs_info.top_pa == ~0UL);
	require(fake_procfs_info.cur_pa == ~0UL);
	require(fake_procfs_info.os == (void *)0x9000UL);
	require(fake_procfs_info.pid == 123);
	require(!strcmp(fake_procfs_info.path, "mcos9/123/status"));
	require(fake_procfs_open_free_calls == 1);
	mix_signed(&digest, fake_procfs_info.pid);

	reset_fake_work();
	fake_procfs_os_missing = 1;
	require(mcctrl_procfs_buff_open_body_result(
		&fake_procfs_base_entry, &fake_procfs_file,
		sizeof(fake_procfs_path_buf),
		sizeof(fake_procfs_info) - sizeof(fake_procfs_info.path),
		~0UL, fake_procfs_entry_osnum, fake_procfs_lookup_os,
		fake_procfs_open_alloc, fake_procfs_open_free,
		fake_procfs_get_path, fake_procfs_init_info,
		fake_procfs_set_file_private) == -22);
	require(fake_procfs_open_alloc_calls == 0);
	mix_signed(&digest, fake_procfs_os_missing);

	reset_fake_work();
	fake_procfs_open_fail_alloc_call = 1;
	require(mcctrl_procfs_buff_open_body_result(
		&fake_procfs_base_entry, &fake_procfs_file,
		sizeof(fake_procfs_path_buf),
		sizeof(fake_procfs_info) - sizeof(fake_procfs_info.path),
		~0UL, fake_procfs_entry_osnum, fake_procfs_lookup_os,
		fake_procfs_open_alloc, fake_procfs_open_free,
		fake_procfs_get_path, fake_procfs_init_info,
		fake_procfs_set_file_private) == -12);
	require(fake_procfs_open_alloc_calls == 1);
	require(fake_procfs_open_free_calls == 0);
	mix_signed(&digest, fake_procfs_open_alloc_calls);

	reset_fake_work();
	fake_procfs_open_fail_alloc_call = 2;
	require(mcctrl_procfs_buff_open_body_result(
		&fake_procfs_base_entry, &fake_procfs_file,
		sizeof(fake_procfs_path_buf),
		sizeof(fake_procfs_info) - sizeof(fake_procfs_info.path),
		~0UL, fake_procfs_entry_osnum, fake_procfs_lookup_os,
		fake_procfs_open_alloc, fake_procfs_open_free,
		fake_procfs_get_path, fake_procfs_init_info,
		fake_procfs_set_file_private) == -12);
	require(fake_procfs_open_alloc_calls == 2);
	require(fake_procfs_open_free_calls == 1);
	mix_signed(&digest, fake_procfs_open_free_calls);

	reset_fake_work();
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -5);
	require(fake_procfs_get_private_calls == 1);
	require(fake_procfs_set_private_calls == 0);
	mix_signed(&digest, fake_procfs_get_private_calls);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = ~0UL;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == 0);
	require(fake_procfs_file.private_data == NULL);
	require(fake_procfs_release_alloc_read_calls == 0);
	require(fake_procfs_open_free_calls == 1);
	mix_signed(&digest, fake_procfs_open_free_calls);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_info.os = (void *)0x9000UL;
	fake_procfs_release_send_ret = 0;
	fake_procfs_release_do_free = 1;
	fake_procfs_release_read_ret = 0;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == 0);
	require(fake_procfs_release_alloc_read_calls == 1);
	require(fake_procfs_init_release_read_calls == 1);
	require(fake_procfs_release_send_calls == 1);
	require(fake_procfs_open_free_calls == 2);
	mix_signed(&digest, fake_procfs_release_send_calls);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_info.os = (void *)0x9000UL;
	fake_procfs_release_read_ret = -7;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -7);
	require(fake_procfs_open_free_calls == 2);
	mix_signed(&digest, fake_procfs_release_read_ret);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_release_fail_alloc_read = 1;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -12);
	require(fake_procfs_open_free_calls == 1);
	mix_signed(&digest, fake_procfs_release_fail_alloc_read);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_info.os = (void *)0x9000UL;
	fake_procfs_release_send_ret = -62;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -62);
	require(fake_procfs_release_timeout_calls == 1);
	require(fake_procfs_open_free_calls == 2);
	mix_signed(&digest, fake_procfs_release_timeout_calls);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_info.os = (void *)0x9000UL;
	fake_procfs_release_send_ret = -512;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -85);
	require(fake_procfs_open_free_calls == 2);
	mix_signed(&digest, fake_procfs_release_send_ret);

	reset_fake_work();
	fake_procfs_file.private_data = &fake_procfs_info;
	fake_procfs_info.top_pa = 0xabcdUL;
	fake_procfs_info.os = (void *)0x9000UL;
	fake_procfs_release_send_ret = 0;
	fake_procfs_release_do_free = 0;
	require(mcctrl_procfs_buff_release_body_result(
		&fake_procfs_file, ~0UL, fake_procfs_get_file_private,
		fake_procfs_set_file_private, fake_procfs_info_top_pa,
		fake_procfs_info_os, fake_procfs_alloc_read,
		fake_procfs_init_release_read, fake_procfs_send_release,
		fake_procfs_read_ret, fake_procfs_open_free,
		fake_procfs_release_timeout) == -5);
	require(fake_procfs_open_free_calls == 1);
	mix_signed(&digest, fake_procfs_release_do_free);

	{
		long pos = 0;

		reset_fake_work();
		require(fake_procfs_buff_read_call(4, &pos) == -5);
		require(fake_procfs_get_private_calls == 1);
		mix_signed(&digest, fake_procfs_get_private_calls);
	}

	{
		long pos = 1;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = 123;
		snprintf(fake_procfs_info.path, sizeof(fake_procfs_info.path),
			 "mcos9/123/status");
		fake_procfs_request_pbuf = 0x1000UL;
		fake_procfs_request_read_ret = 0;
		fake_procfs_pages[0].phys = 0x1000UL;
		fake_procfs_pages[0].next_pa = ~0UL;
		fake_procfs_pages[0].pos = 0;
		fake_procfs_pages[0].size = 5;
		memcpy(fake_procfs_pages[0].buf, "abcde", 5);
		require(fake_procfs_buff_read_call(3, &pos) == 3);
		require(pos == 4);
		require(!memcmp(fake_procfs_user_buf, "bcd", 3));
		require(fake_procfs_info.top_pa == 0x1000UL);
		require(fake_procfs_info.cur_pa == 0x1000UL);
		require(fake_procfs_read_get_usrdata_calls == 1);
		require(fake_procfs_read_get_ppd_calls == 1);
		require(fake_procfs_read_put_ppd_calls == 1);
		require(fake_procfs_read_ppd_cpu_calls == 1);
		require(fake_procfs_init_request_read_calls == 1);
		require(fake_procfs_request_send_calls == 1);
		require(fake_procfs_last_tid == 7);
		require(fake_procfs_open_free_calls == 1);
		require(fake_procfs_read_map_memory_calls == 1);
		require(fake_procfs_read_map_virtual_calls == 1);
		require(fake_procfs_read_unmap_virtual_calls == 1);
		require(fake_procfs_read_unmap_memory_calls == 1);
		require(fake_procfs_read_copy_calls == 1);
		mix_signed(&digest, pos);
		mix_signed(&digest, fake_procfs_request_send_calls);
	}

	{
		long pos = 6;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = 0x1000UL;
		fake_procfs_info.cur_pa = 0x1000UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		fake_procfs_pages[0].phys = 0x1000UL;
		fake_procfs_pages[0].next_pa = 0x2000UL;
		fake_procfs_pages[0].pos = 0;
		fake_procfs_pages[0].size = 5;
		fake_procfs_pages[1].phys = 0x2000UL;
		fake_procfs_pages[1].next_pa = ~0UL;
		fake_procfs_pages[1].pos = 5;
		fake_procfs_pages[1].size = 5;
		memcpy(fake_procfs_pages[1].buf, "fghij", 5);
		require(fake_procfs_buff_read_call(2, &pos) == 2);
		require(pos == 8);
		require(!memcmp(fake_procfs_user_buf, "gh", 2));
		require(fake_procfs_request_send_calls == 0);
		require(fake_procfs_read_map_memory_calls == 2);
		require(fake_procfs_info.cur_pa == 0x2000UL);
		mix_signed(&digest, fake_procfs_read_map_memory_calls);
	}

	{
		long pos = 1;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = 0x1000UL;
		fake_procfs_info.cur_pa = 0x1000UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_pages[0].phys = 0x1000UL;
		fake_procfs_pages[0].next_pa = ~0UL;
		fake_procfs_pages[0].pos = 0;
		fake_procfs_pages[0].size = 5;
		memcpy(fake_procfs_pages[0].buf, "abcde", 5);
		fake_procfs_read_copy_fail = 1;
		require(fake_procfs_buff_read_call(3, &pos) == -14);
		require(pos == 1);
		require(fake_procfs_read_copy_calls == 1);
		mix_signed(&digest, fake_procfs_read_copy_fail);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		fake_procfs_read_missing_usrdata = 1;
		require(fake_procfs_buff_read_call(4, &pos) == -22);
		require(fake_procfs_read_no_usrdata_calls == 1);
		mix_signed(&digest, fake_procfs_read_no_usrdata_calls);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = 77;
		fake_procfs_read_missing_ppd = 1;
		require(fake_procfs_buff_read_call(4, &pos) == -22);
		require(fake_procfs_read_no_ppd_calls == 1);
		require(fake_procfs_last_pid == 77);
		require(fake_procfs_read_put_ppd_calls == 0);
		mix_signed(&digest, fake_procfs_read_no_ppd_calls);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		snprintf(fake_procfs_info.path, sizeof(fake_procfs_info.path),
			 "mcos9/status");
		fake_procfs_request_send_ret = -62;
		require(fake_procfs_buff_read_call(4, &pos) == -62);
		require(fake_procfs_read_timeout_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_read_timeout_calls);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		snprintf(fake_procfs_info.path, sizeof(fake_procfs_info.path),
			 "mcos9/status");
		fake_procfs_request_send_ret = -512;
		require(fake_procfs_buff_read_call(4, &pos) == -85);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_request_send_ret);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		snprintf(fake_procfs_info.path, sizeof(fake_procfs_info.path),
			 "mcos9/status");
		fake_procfs_request_send_ret = 0;
		fake_procfs_request_do_free = 0;
		require(fake_procfs_buff_read_call(4, &pos) == -5);
		require(fake_procfs_open_free_calls == 0);
		mix_signed(&digest, fake_procfs_request_do_free);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_file.private_data = &fake_procfs_info;
		fake_procfs_info.top_pa = ~0UL;
		fake_procfs_info.cur_pa = ~0UL;
		fake_procfs_info.os = (void *)0x9000UL;
		fake_procfs_info.pid = -1;
		snprintf(fake_procfs_info.path, sizeof(fake_procfs_info.path),
			 "mcos9/status");
		fake_procfs_request_read_ret = -7;
		require(fake_procfs_buff_read_call(4, &pos) == -7);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_request_read_ret);
	}

	{
		long pos = 2;

		reset_fake_work();
		memcpy(fake_procfs_kernel_page, "abcdef", 6);
		fake_procfs_request_read_ret = 3;
		fake_procfs_rw_eof = 1;
		require(fake_procfs_read_write_call(5, &pos, 0) == 3);
		require(pos == 5);
		require(!memcmp(fake_procfs_user_buf, "abc", 3));
		require(fake_procfs_read_get_usrdata_calls == 1);
		require(fake_procfs_read_get_ppd_calls == 1);
		require(fake_procfs_read_put_ppd_calls == 1);
		require(fake_procfs_read_ppd_cpu_calls == 1);
		require(fake_procfs_rw_get_order_calls == 1);
		require(fake_procfs_rw_alloc_pages_calls == 1);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_release_alloc_read_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		require(fake_procfs_rw_init_calls == 1);
		require(fake_procfs_rw_last_offset == 2);
		require(fake_procfs_rw_last_count == 5);
		require(fake_procfs_rw_last_read_write == 0);
		require(!strcmp(fake_procfs_rw_last_path, "mcos9/123/status"));
		require(fake_procfs_request_send_calls == 1);
		require(fake_procfs_last_tid == 7);
		require(fake_procfs_rw_copy_calls == 1);
		mix_signed(&digest, pos);
		mix_signed(&digest, fake_procfs_rw_copy_calls);
	}

	{
		long pos = 10;

		reset_fake_work();
		fake_procfs_request_read_ret = 4;
		fake_procfs_rw_eof = 1;
		require(fake_procfs_read_write_call(4, &pos, 1) == 4);
		require(pos == 14);
		require(fake_procfs_rw_copy_calls == 0);
		require(fake_procfs_rw_last_read_write == 1);
		mix_signed(&digest, fake_procfs_rw_last_read_write);
	}

	{
		long pos = 4;

		reset_fake_work();
		fake_procfs_request_read_ret = -7;
		require(fake_procfs_read_write_call(8, &pos, 0) == -7);
		require(pos == 4);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_request_read_ret);
	}

	{
		long pos = 4;

		reset_fake_work();
		fake_procfs_request_read_ret = 3;
		fake_procfs_rw_copy_fail = 1;
		require(fake_procfs_read_write_call(8, &pos, 0) == -14);
		require(pos == 4);
		require(fake_procfs_rw_copy_error_logs == 1);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_rw_copy_error_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		snprintf(fake_procfs_forced_path, sizeof(fake_procfs_forced_path),
			 "bad9/123/status");
		require(fake_procfs_read_write_call(4, &pos, 0) == -22);
		require(fake_procfs_rw_bad_osnum_logs == 1);
		require(fake_procfs_rw_alloc_pages_calls == 0);
		mix_signed(&digest, fake_procfs_rw_bad_osnum_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_entry_osnum_value = 8;
		require(fake_procfs_read_write_call(4, &pos, 0) == -22);
		require(fake_procfs_rw_mismatch_logs == 1);
		require(fake_procfs_last_osnum == 9);
		require(fake_procfs_last_pid == 8);
		mix_signed(&digest, fake_procfs_rw_mismatch_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_os_missing = 1;
		require(fake_procfs_read_write_call(4, &pos, 0) == -22);
		require(fake_procfs_rw_no_os_logs == 1);
		require(fake_procfs_read_get_usrdata_calls == 0);
		mix_signed(&digest, fake_procfs_rw_no_os_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_read_missing_usrdata = 1;
		require(fake_procfs_read_write_call(4, &pos, 0) == -22);
		require(fake_procfs_rw_no_usrdata_logs == 1);
		require(fake_procfs_read_get_ppd_calls == 0);
		mix_signed(&digest, fake_procfs_rw_no_usrdata_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_read_missing_ppd = 1;
		require(fake_procfs_read_write_call(4, &pos, 0) == -22);
		require(fake_procfs_rw_no_ppd_logs == 1);
		require(fake_procfs_last_pid == 123);
		require(fake_procfs_read_put_ppd_calls == 0);
		mix_signed(&digest, fake_procfs_rw_no_ppd_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_rw_alloc_pages_fail = 1;
		require(fake_procfs_read_write_call(4, &pos, 0) == -12);
		require(fake_procfs_rw_alloc_error_logs == 1);
		require(fake_procfs_read_put_ppd_calls == 1);
		require(fake_procfs_rw_free_pages_calls == 0);
		mix_signed(&digest, fake_procfs_rw_alloc_error_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_request_send_ret = -62;
		require(fake_procfs_read_write_call(4, &pos, 0) == -62);
		require(fake_procfs_rw_timeout_logs == 1);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_rw_timeout_logs);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_request_send_ret = -512;
		require(fake_procfs_read_write_call(4, &pos, 0) == -85);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_open_free_calls == 1);
		mix_signed(&digest, fake_procfs_request_send_ret);
	}

	{
		long pos = 0;

		reset_fake_work();
		fake_procfs_request_send_ret = 0;
		fake_procfs_request_do_free = 0;
		require(fake_procfs_read_write_call(4, &pos, 0) == -5);
		require(fake_procfs_rw_free_pages_calls == 1);
		require(fake_procfs_open_free_calls == 0);
		mix_signed(&digest, fake_procfs_request_do_free);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_sysfs_packet_handler_body_result(
		(void *)0xa550, SCD_MSG_SYSFS_REQ_CREATE, -7, 0x111,
		0x222, sizeof(fake_sysfs_work), fake_sysfs_alloc,
		fake_sysfs_init_schedule, fake_sysfs_alloc_failed));
	require(fake_sysfs_alloc_calls == 1);
	require(fake_sysfs_alloc_size == sizeof(fake_sysfs_work));
	require(fake_sysfs_init_schedule_calls == 1);
	require(fake_sysfs_scheduled_work == &fake_sysfs_work);
	require(fake_sysfs_work.os == (void *)0xa550);
	require(fake_sysfs_work.msg == SCD_MSG_SYSFS_REQ_CREATE);
	require(fake_sysfs_work.err == -7);
	require(fake_sysfs_work.arg1 == 0x111);
	require(fake_sysfs_work.arg2 == 0x222);
	mix_signed(&digest, fake_sysfs_init_schedule_calls);
	mix(&digest, fake_sysfs_work.arg1);

	reset_fake_work();
	fake_sysfs_fail_alloc = 1;
	mix_signed(&digest, mcctrl_sysfs_packet_handler_body_result(
		(void *)0xa550, SCD_MSG_SYSFS_REQ_SETUP, 0, 1, 2,
		sizeof(fake_sysfs_work), fake_sysfs_alloc,
		fake_sysfs_init_schedule, fake_sysfs_alloc_failed));
	require(fake_sysfs_alloc_calls == 1);
	require(fake_sysfs_alloc_failed_calls == 1);
	require(fake_sysfs_init_schedule_calls == 0);
	mix_signed(&digest, fake_sysfs_alloc_failed_calls);

	reset_fake_work();
	memcpy(fake_sysfs_remote_kernel_buf, "remote-show", 11);
	fake_sysfs_remote_req.lresult = 11;
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5110, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, (void *)0x5f5100,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6001, 0x7001, &stage, fake_sysfs_remote_down,
			fake_sysfs_remote_up, fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == 11);
		require(stage == 0);
		require(fake_sysfs_remote_down_calls == 1);
		require(fake_sysfs_remote_wait_calls == 2);
		require(fake_sysfs_remote_set_busy_calls == 1);
		require(fake_sysfs_remote_send_calls == 1);
		require(fake_sysfs_remote_up_calls == 1);
		require(fake_sysfs_remote_req.busy == 0);
		require(fake_sysfs_remote_last_os == (void *)0x5f5100);
		require(fake_sysfs_remote_last_cpu == 0);
		require(fake_sysfs_remote_last_msg == SCD_MSG_SYSFS_REQ_SHOW);
		require(fake_sysfs_remote_last_arg1 == 0x5110);
		require(fake_sysfs_remote_last_arg2 == 0x6001);
		require(fake_sysfs_remote_last_arg3 == 0x7001);
		require(!memcmp(fake_sysfs_remote_user_buf, "remote-show", 11));
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_sysfs_remote_wait_calls);
		mix(&digest, fake_sysfs_remote_last_arg3);
	}

	reset_fake_work();
	memcpy(fake_sysfs_remote_user_buf, "store-data", 10);
	fake_sysfs_remote_req.lresult = 10;
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_store_body_result(
			(void *)0x5220, fake_sysfs_remote_user_buf, 10,
			fake_sysfs_remote_kernel_buf,
			sizeof(fake_sysfs_remote_kernel_buf),
			(void *)0x5f5200, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6002, 0x7002, &stage,
			fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == 10);
		require(stage == 0);
		require(fake_sysfs_remote_copy_calls == 1);
		require(fake_sysfs_remote_last_copy_size == 10);
		require(fake_sysfs_remote_last_msg == SCD_MSG_SYSFS_REQ_STORE);
		require(fake_sysfs_remote_last_err == 10);
		require(!memcmp(fake_sysfs_remote_kernel_buf, "store-data", 10));
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_sysfs_remote_last_err);
	}

	reset_fake_work();
	{
		int stage = -1;
		int ret = mcctrl_sysfs_remote_release_body_result(
			(void *)0x52e0, SNT_FILE, fake_sysfs_remote_kernel_buf,
			(void *)0x5f52e0, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6002, 0x7002, SNT_FILE,
			&stage, fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send);
		require(ret == 0);
		require(stage == 0);
		require(fake_sysfs_remote_down_calls == 1);
		require(fake_sysfs_remote_wait_calls == 2);
		require(fake_sysfs_remote_set_busy_calls == 1);
		require(fake_sysfs_remote_send_calls == 1);
		require(fake_sysfs_remote_up_calls == 1);
		require(fake_sysfs_remote_last_msg == SCD_MSG_SYSFS_REQ_RELEASE);
		require(fake_sysfs_remote_last_arg1 == 0x52e0);
		require(fake_sysfs_remote_last_arg2 == 0x6002);
		require(fake_sysfs_remote_last_arg3 == 0x7002);
		require(fake_sysfs_remote_last_err == 0);
		mix_signed(&digest, ret);
		mix_signed(&digest, fake_sysfs_remote_last_msg);
	}

	reset_fake_work();
	{
		int stage = -1;
		int ret = mcctrl_sysfs_remote_release_body_result(
			(void *)0x52f0, 2, fake_sysfs_remote_kernel_buf,
			(void *)0x5f52f0, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6002, 0x7002, SNT_FILE,
			&stage, fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send);
		require(ret == 0);
		require(stage == 0);
		require(fake_sysfs_remote_down_calls == 0);
		mix_signed(&digest, fake_sysfs_remote_down_calls);
	}

	reset_fake_work();
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5330, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf), NULL,
			(void *)0x5f5300, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6003, 0x7003, &stage,
			fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == 0);
		require(stage == 1);
		require(fake_sysfs_remote_down_calls == 0);
		mix_signed(&digest, stage);
	}

	reset_fake_work();
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_store_body_result(
			(void *)0x5440, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, 4, (void *)0x5f5400,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6004, 0x7004, &stage, fake_sysfs_remote_down,
			fake_sysfs_remote_up, fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == -28);
		require(stage == 4);
		require(fake_sysfs_remote_up_calls == 1);
		require(fake_sysfs_remote_send_calls == 0);
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	fake_sysfs_remote_send_ret = -5;
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5550, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, (void *)0x5f5500,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6005, 0x7005, &stage, fake_sysfs_remote_down,
			fake_sysfs_remote_up, fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == -5);
		require(stage == 5);
		require(fake_sysfs_remote_up_calls == 1);
		require(fake_sysfs_remote_wait_calls == 1);
		mix_signed(&digest, stage);
	}

	reset_fake_work();
	fake_sysfs_remote_wait_fail_at = 2;
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5660, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, (void *)0x5f5600,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6006, 0x7006, &stage, fake_sysfs_remote_down,
			fake_sysfs_remote_up, fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == -4);
		require(stage == 6);
		require(fake_sysfs_remote_up_calls == 1);
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	fake_sysfs_remote_req.lresult = -123;
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5770, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, (void *)0x5f5700,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6007, 0x7007, &stage, fake_sysfs_remote_down,
			fake_sysfs_remote_up, fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == -123);
		require(stage == 7);
		require(fake_sysfs_remote_copy_calls == 0);
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	{
		int stage = -1;
		long ret = mcctrl_sysfs_remote_show_body_result(
			(void *)0x5880, fake_sysfs_remote_user_buf,
			sizeof(fake_sysfs_remote_user_buf),
			fake_sysfs_remote_kernel_buf, (void *)0x5f5800,
			&fake_sysfs_remote_sem, &fake_sysfs_remote_req,
			0x6008, 0x7008, &stage, NULL, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send,
			fake_sysfs_remote_req_lresult, fake_sysfs_remote_copy);
		require(ret == -22);
		require(stage == 7);
		require(fake_sysfs_remote_down_calls == 0);
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	fake_sysfs_remote_wait_fail_at = 1;
	{
		int stage = -1;
		int ret = mcctrl_sysfs_remote_release_body_result(
			(void *)0x5888, SNT_FILE, fake_sysfs_remote_kernel_buf,
			(void *)0x5f5888, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6008, 0x7008, SNT_FILE,
			&stage, fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send);
		require(ret == -4);
		require(stage == 3);
		require(fake_sysfs_remote_up_calls == 1);
		require(fake_sysfs_remote_send_calls == 0);
		mix_signed(&digest, stage);
	}

	reset_fake_work();
	fake_sysfs_remote_send_ret = -5;
	{
		int stage = -1;
		int ret = mcctrl_sysfs_remote_release_body_result(
			(void *)0x5890, SNT_FILE, fake_sysfs_remote_kernel_buf,
			(void *)0x5f5890, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x6009, 0x7009, SNT_FILE,
			&stage, fake_sysfs_remote_down, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send);
		require(ret == -5);
		require(stage == 5);
		require(fake_sysfs_remote_up_calls == 1);
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	{
		int stage = -1;
		int ret = mcctrl_sysfs_remote_release_body_result(
			(void *)0x58a0, SNT_FILE, fake_sysfs_remote_kernel_buf,
			(void *)0x5f58a0, &fake_sysfs_remote_sem,
			&fake_sysfs_remote_req, 0x600a, 0x700a, SNT_FILE,
			&stage, NULL, fake_sysfs_remote_up,
			fake_sysfs_remote_wait_ready,
			fake_sysfs_remote_set_busy, fake_sysfs_remote_send);
		require(ret == -22);
		require(stage == 7);
		require(fake_sysfs_remote_down_calls == 0);
		mix_signed(&digest, ret);
	}

#define RUN_SYSFS_REQ(index, message, arg_value) do { \
		reset_fake_work(); \
		fake_sysfs_work.os = (void *)0x5f5000UL; \
		fake_sysfs_work.msg = (message); \
		fake_sysfs_work.arg1 = (arg_value); \
		mix_signed(&digest, mcctrl_sysfs_work_main_body_result( \
			&fake_sysfs_work, fake_sysfs_req_setup, \
			fake_sysfs_req_create, fake_sysfs_req_mkdir, \
			fake_sysfs_req_symlink, fake_sysfs_req_lookup, \
			fake_sysfs_req_unlink, fake_sysfs_resp_show, \
			fake_sysfs_resp_store, fake_sysfs_resp_release, \
			fake_sysfs_unknown_work, fake_sysfs_free_work)); \
		require(fake_sysfs_req_calls[(index)] == 1); \
		require(fake_sysfs_last_os == (void *)0x5f5000UL); \
		require(fake_sysfs_last_arg == (arg_value)); \
		require(fake_sysfs_free_calls == 1); \
		require(fake_sysfs_freed_work == &fake_sysfs_work); \
		mix_signed(&digest, fake_sysfs_req_calls[(index)]); \
		mix(&digest, fake_sysfs_last_arg); \
	} while (0)

	RUN_SYSFS_REQ(0, SCD_MSG_SYSFS_REQ_SETUP, 0x4100);
	RUN_SYSFS_REQ(1, SCD_MSG_SYSFS_REQ_CREATE, 0x4200);
	RUN_SYSFS_REQ(2, SCD_MSG_SYSFS_REQ_MKDIR, 0x4300);
	RUN_SYSFS_REQ(3, SCD_MSG_SYSFS_REQ_SYMLINK, 0x4400);
	RUN_SYSFS_REQ(4, SCD_MSG_SYSFS_REQ_LOOKUP, 0x4500);
	RUN_SYSFS_REQ(5, SCD_MSG_SYSFS_REQ_UNLINK, 0x4600);

#undef RUN_SYSFS_REQ

	reset_fake_work();
	fake_sysfs_work.os = (void *)0x5f5001UL;
	fake_sysfs_work.msg = SCD_MSG_SYSFS_RESP_SHOW;
	fake_sysfs_work.arg1 = 0xabc;
	fake_sysfs_work.arg2 = 77;
	mix_signed(&digest, mcctrl_sysfs_work_main_body_result(
		&fake_sysfs_work, fake_sysfs_req_setup, fake_sysfs_req_create,
		fake_sysfs_req_mkdir, fake_sysfs_req_symlink,
		fake_sysfs_req_lookup, fake_sysfs_req_unlink,
		fake_sysfs_resp_show, fake_sysfs_resp_store,
		fake_sysfs_resp_release, fake_sysfs_unknown_work,
		fake_sysfs_free_work));
	require(fake_sysfs_resp_show_calls == 1);
	require(fake_sysfs_last_node == (void *)0xabcUL);
	require(fake_sysfs_last_result == 77);
	require(fake_sysfs_free_calls == 1);
	mix_signed(&digest, fake_sysfs_resp_show_calls);
	mix_signed(&digest, fake_sysfs_last_result);

	reset_fake_work();
	fake_sysfs_work.os = (void *)0x5f5002UL;
	fake_sysfs_work.msg = SCD_MSG_SYSFS_RESP_STORE;
	fake_sysfs_work.arg1 = 0xabd;
	fake_sysfs_work.arg2 = -5;
	mix_signed(&digest, mcctrl_sysfs_work_main_body_result(
		&fake_sysfs_work, fake_sysfs_req_setup, fake_sysfs_req_create,
		fake_sysfs_req_mkdir, fake_sysfs_req_symlink,
		fake_sysfs_req_lookup, fake_sysfs_req_unlink,
		fake_sysfs_resp_show, fake_sysfs_resp_store,
		fake_sysfs_resp_release, fake_sysfs_unknown_work,
		fake_sysfs_free_work));
	require(fake_sysfs_resp_store_calls == 1);
	require(fake_sysfs_last_node == (void *)0xabdUL);
	require(fake_sysfs_last_result == -5);
	require(fake_sysfs_free_calls == 1);
	mix_signed(&digest, fake_sysfs_resp_store_calls);
	mix_signed(&digest, fake_sysfs_last_result);

	reset_fake_work();
	fake_sysfs_work.os = (void *)0x5f5003UL;
	fake_sysfs_work.msg = SCD_MSG_SYSFS_RESP_RELEASE;
	fake_sysfs_work.err = -9;
	fake_sysfs_work.arg1 = 0xabe;
	mix_signed(&digest, mcctrl_sysfs_work_main_body_result(
		&fake_sysfs_work, fake_sysfs_req_setup, fake_sysfs_req_create,
		fake_sysfs_req_mkdir, fake_sysfs_req_symlink,
		fake_sysfs_req_lookup, fake_sysfs_req_unlink,
		fake_sysfs_resp_show, fake_sysfs_resp_store,
		fake_sysfs_resp_release, fake_sysfs_unknown_work,
		fake_sysfs_free_work));
	require(fake_sysfs_resp_release_calls == 1);
	require(fake_sysfs_last_node == (void *)0xabeUL);
	require(fake_sysfs_last_error == -9);
	require(fake_sysfs_free_calls == 1);
	mix_signed(&digest, fake_sysfs_resp_release_calls);
	mix_signed(&digest, fake_sysfs_last_error);

	reset_fake_work();
	fake_sysfs_work.os = (void *)0x5f5004UL;
	fake_sysfs_work.msg = 0x7fff;
	fake_sysfs_work.arg1 = 0x123;
	fake_sysfs_work.arg2 = 0x456;
	mix_signed(&digest, mcctrl_sysfs_work_main_body_result(
		&fake_sysfs_work, fake_sysfs_req_setup, fake_sysfs_req_create,
		fake_sysfs_req_mkdir, fake_sysfs_req_symlink,
		fake_sysfs_req_lookup, fake_sysfs_req_unlink,
		fake_sysfs_resp_show, fake_sysfs_resp_store,
		fake_sysfs_resp_release, fake_sysfs_unknown_work,
		fake_sysfs_free_work));
	require(fake_sysfs_unknown_calls == 1);
	require(fake_sysfs_unknown_msg == 0x7fff);
	require(fake_sysfs_free_calls == 1);
	mix_signed(&digest, fake_sysfs_unknown_calls);

	reset_fake_work();
	fake_sysfs_work.msg = SCD_MSG_SYSFS_REQ_CREATE;
	mix_signed(&digest, mcctrl_sysfs_work_main_body_result(
		&fake_sysfs_work, fake_sysfs_req_setup, NULL,
		fake_sysfs_req_mkdir, fake_sysfs_req_symlink,
		fake_sysfs_req_lookup, fake_sysfs_req_unlink,
		fake_sysfs_resp_show, fake_sysfs_resp_store,
		fake_sysfs_resp_release, fake_sysfs_unknown_work,
		fake_sysfs_free_work));
		require(fake_sysfs_free_calls == 1);
		mix_signed(&digest, fake_sysfs_free_calls);

		{
			struct fake_sysfs_lookup_node leaf2 = {
				.name = "needle",
				.type = SNT_FILE,
			};
			struct fake_sysfs_lookup_node leaf1 = {
				.name = "other",
				.type = SNT_FILE,
				.next_sibling = &leaf2,
			};
			struct fake_sysfs_lookup_node dir = {
				.name = "dir",
				.type = SNT_DIR,
				.first_child = &leaf1,
			};
			struct fake_sysfs_lookup_node file = {
				.name = "file",
				.type = SNT_FILE,
			};
			void *result;

			reset_fake_work();
			result = mcctrl_sysfs_lookup_i_body_result(
				&dir, "needle", SNT_DIR, fake_sysfs_lookup_node_type,
				fake_sysfs_lookup_node_name,
				fake_sysfs_lookup_first_child,
				fake_sysfs_lookup_next_child,
				fake_sysfs_lookup_err_ptr);
			require(result == &leaf2);
			require(fake_sysfs_lookup_type_calls == 1);
			require(fake_sysfs_lookup_first_calls == 1);
			require(fake_sysfs_lookup_name_calls == 2);
			require(fake_sysfs_lookup_next_calls == 1);
			require(fake_sysfs_lookup_err_calls == 0);
			mix_signed(&digest, fake_sysfs_lookup_name_calls);

			reset_fake_work();
			result = mcctrl_sysfs_lookup_i_body_result(
				&dir, "missing", SNT_DIR,
				fake_sysfs_lookup_node_type,
				fake_sysfs_lookup_node_name,
				fake_sysfs_lookup_first_child,
				fake_sysfs_lookup_next_child,
				fake_sysfs_lookup_err_ptr);
			require(result == (void *)(intptr_t)-ENOENT);
			require(fake_sysfs_lookup_err_calls == 1);
			require(fake_sysfs_lookup_last_error == -ENOENT);
			require(fake_sysfs_lookup_next_calls == 2);
			mix_signed(&digest, fake_sysfs_lookup_last_error);

			reset_fake_work();
			result = mcctrl_sysfs_lookup_i_body_result(
				&dir, "", SNT_DIR, fake_sysfs_lookup_node_type,
				fake_sysfs_lookup_node_name,
				fake_sysfs_lookup_first_child,
				fake_sysfs_lookup_next_child,
				fake_sysfs_lookup_err_ptr);
			require(result == (void *)(intptr_t)-ENOENT);
			require(fake_sysfs_lookup_first_calls == 0);
			require(fake_sysfs_lookup_last_error == -ENOENT);

			reset_fake_work();
			result = mcctrl_sysfs_lookup_i_body_result(
				&file, "needle", SNT_DIR,
				fake_sysfs_lookup_node_type,
				fake_sysfs_lookup_node_name,
				fake_sysfs_lookup_first_child,
				fake_sysfs_lookup_next_child,
				fake_sysfs_lookup_err_ptr);
			require(result == (void *)(intptr_t)-ENOTDIR);
			require(fake_sysfs_lookup_first_calls == 0);
			require(fake_sysfs_lookup_last_error == -ENOTDIR);

			reset_fake_work();
			require(mcctrl_sysfs_lookup_i_body_result(
				&dir, "needle", SNT_DIR, NULL,
				fake_sysfs_lookup_node_name,
				fake_sysfs_lookup_first_child,
				fake_sysfs_lookup_next_child,
				fake_sysfs_lookup_err_ptr) == NULL);
			require(fake_sysfs_lookup_type_calls == 0);
		}

		reset_fake_work();
		{
			char buf[32];
		fake_sysfs_client_ops.show = fake_sysfs_client_show;
		fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
		fake_sysfs_local_node.client_instance = 0x77770000L;
		mix_signed(&digest, mcctrl_sysfs_local_show_body_result(
			&fake_sysfs_local_node, buf, sizeof(buf), 4096,
			fake_sysfs_node_client_ops,
			fake_sysfs_node_client_instance));
		require(fake_sysfs_local_show_calls == 1);
		require(fake_sysfs_local_last_instance == (void *)0x77770000UL);
		require(fake_sysfs_local_last_buf == buf);
		require(fake_sysfs_local_last_size == 4096);
		mix_signed(&digest, fake_sysfs_local_show_calls);
		mix(&digest, fake_sysfs_local_last_size);
	}

	reset_fake_work();
	{
		char buf[32];
		fake_sysfs_local_node.client_ops = 0;
		mix_signed(&digest, mcctrl_sysfs_local_show_body_result(
			&fake_sysfs_local_node, buf, sizeof(buf), 4096,
			fake_sysfs_node_client_ops,
			fake_sysfs_node_client_instance));
		require(fake_sysfs_local_show_calls == 0);
	}

	reset_fake_work();
	{
		char buf[32];
		fake_sysfs_client_ops.store = fake_sysfs_client_store;
		fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
		fake_sysfs_local_node.client_instance = 0x88880000L;
		mix_signed(&digest, mcctrl_sysfs_local_store_body_result(
			&fake_sysfs_local_node, buf, sizeof(buf),
			fake_sysfs_node_client_ops,
			fake_sysfs_node_client_instance));
		require(fake_sysfs_local_store_calls == 1);
		require(fake_sysfs_local_last_instance == (void *)0x88880000UL);
		require(fake_sysfs_local_last_buf == buf);
		require(fake_sysfs_local_last_size == sizeof(buf));
		mix_signed(&digest, fake_sysfs_local_store_calls);
		mix(&digest, fake_sysfs_local_last_size);
	}

	reset_fake_work();
	fake_sysfs_client_ops.release = fake_sysfs_client_release;
	fake_sysfs_local_node.type = SNT_FILE;
	fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
	fake_sysfs_local_node.client_instance = 0x99990000L;
	mix_signed(&digest, mcctrl_sysfs_local_release_body_result(
		&fake_sysfs_local_node, SNT_FILE, fake_sysfs_node_type,
		fake_sysfs_node_client_ops, fake_sysfs_node_client_instance));
	require(fake_sysfs_local_release_calls == 1);
	require(fake_sysfs_local_last_instance == (void *)0x99990000UL);
	mix_signed(&digest, fake_sysfs_local_release_calls);

	reset_fake_work();
	fake_sysfs_client_ops.release = fake_sysfs_client_release;
	fake_sysfs_local_node.type = 2;
	fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
	mix_signed(&digest, mcctrl_sysfs_local_release_body_result(
		&fake_sysfs_local_node, SNT_FILE, fake_sysfs_node_type,
		fake_sysfs_node_client_ops, fake_sysfs_node_client_instance));
	require(fake_sysfs_local_release_calls == 0);

	reset_fake_work();
	fake_sysfs_resp_req.result = -1;
	mix_signed(&digest, mcctrl_sysfs_resp_body_result(
		&fake_sysfs_local_node, 0x1234, fake_sysfs_resp_get_req,
		fake_sysfs_resp_complete_req));
	require(fake_sysfs_resp_get_req_calls == 1);
	require(fake_sysfs_resp_complete_calls == 1);
	require(fake_sysfs_resp_req.complete_calls == 1);
	require(fake_sysfs_resp_req.result == 0x1234);
	mix_signed(&digest, fake_sysfs_resp_req.result);

	reset_fake_work();
	require(mcctrl_sysfs_resp_body_result(
		&fake_sysfs_local_node, 0x1234, fake_sysfs_resp_get_null_req,
		fake_sysfs_resp_complete_req) == -EINVAL);
	require(fake_sysfs_resp_get_req_calls == 1);
	require(fake_sysfs_resp_complete_calls == 0);

	reset_fake_work();
	{
		char buf[32];

		fake_sysfs_client_ops.show = fake_sysfs_client_show;
		fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
		mix_signed(&digest, mcctrl_sysfs_show_body_result(
			&fake_sysfs_local_node, buf, 4096,
			fake_sysfs_node_client_ops));
		require(fake_sysfs_local_show_calls == 1);
		require(fake_sysfs_local_last_instance ==
				&fake_sysfs_local_node);
		require(fake_sysfs_local_last_buf == buf);
		require(fake_sysfs_local_last_size == 4096);
		mix_signed(&digest, fake_sysfs_local_show_calls);
	}

	reset_fake_work();
	{
		char buf[32];

		fake_sysfs_client_ops.store = fake_sysfs_client_store;
		fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
		mix_signed(&digest, mcctrl_sysfs_store_body_result(
			&fake_sysfs_local_node, buf, 7,
			fake_sysfs_node_client_ops));
		require(fake_sysfs_local_store_calls == 1);
		require(fake_sysfs_local_last_instance ==
				&fake_sysfs_local_node);
		require(fake_sysfs_local_last_buf == buf);
		require(fake_sysfs_local_last_size == 7);
		mix_signed(&digest, fake_sysfs_local_store_calls);
	}

	reset_fake_work();
	fake_sysfs_client_ops.release = fake_sysfs_client_release;
	fake_sysfs_local_node.client_ops = (long)&fake_sysfs_client_ops;
	mix_signed(&digest, mcctrl_sysfs_release_body_result(
		&fake_sysfs_local_node, fake_sysfs_node_client_ops));
	require(fake_sysfs_local_release_calls == 1);
	require(fake_sysfs_local_last_instance == &fake_sysfs_local_node);
	mix_signed(&digest, fake_sysfs_local_release_calls);

	reset_fake_work();
	require(mcctrl_sysfs_show_body_result(&fake_sysfs_local_node,
			NULL, 0, fake_sysfs_node_client_ops) == -ENOSPC);
	require(mcctrl_sysfs_store_body_result(&fake_sysfs_local_node,
			NULL, 0, fake_sysfs_node_client_ops) == -ENOSPC);
	require(mcctrl_sysfs_release_body_result(&fake_sysfs_local_node,
			fake_sysfs_node_client_ops) == 0);

	reset_fake_work();
	{
		char buf[64];
		int i32 = -42;
		long i64 = -4200000000L;
		unsigned int u32 = 1234;
		unsigned long u64 = 1234567890123UL;
		char str[] = "mcctrl";
		unsigned int pages = 4096;
		struct mcctrl_sysfsm_bitmap_param bitmap = {
			.nbits = 12,
			.ptr = (void *)0x1234UL,
		};
		long ret;

		ret = mcctrl_sysfs_snooping_show_i32_body_result(
			&i32, buf, sizeof(buf));
		require(ret == (long)strlen("-42\n"));
		require(!strcmp(buf, "-42\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_i64_body_result(
			&i64, buf, sizeof(buf));
		require(ret == (long)strlen("-4200000000\n"));
		require(!strcmp(buf, "-4200000000\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_u32_body_result(
			&u32, buf, sizeof(buf));
		require(ret == (long)strlen("1234\n"));
		require(!strcmp(buf, "1234\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_u64_body_result(
			&u64, buf, sizeof(buf));
		require(ret == (long)strlen("1234567890123\n"));
		require(!strcmp(buf, "1234567890123\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_string_body_result(
			str, buf, sizeof(buf));
		require(ret == (long)strlen("mcctrl\n"));
		require(!strcmp(buf, "mcctrl\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_u32k_body_result(
			&pages, buf, sizeof(buf));
		require(ret == (long)strlen("4K\n"));
		require(!strcmp(buf, "4K\n"));
		mix_signed(&digest, ret);

		ret = mcctrl_sysfs_snooping_show_bitmap_body_result(
			&bitmap, buf, sizeof(buf), fake_sysfs_bitmap_format);
		require(ret == (long)strlen("bits:12:1234\n"));
		require(!strcmp(buf, "bits:12:1234\n"));
		require(fake_sysfs_bitmap_format_calls == 1);
		require(fake_sysfs_bitmap_last_ptr == (void *)0x1234UL);
		require(fake_sysfs_bitmap_last_nbits == 12);
		require(fake_sysfs_bitmap_last_size == sizeof(buf));
		mix_signed(&digest, ret);
	}

	reset_fake_work();
	mix_signed(&digest,
		mcctrl_sysfs_cleanup_special_local_create_body_result(
			(void *)0xabcdefUL, fake_sysfs_local_free));
	require(fake_sysfs_local_free_calls == 1);
	require(fake_sysfs_local_last_instance == (void *)0xabcdefUL);
	mix_signed(&digest, fake_sysfs_local_free_calls);

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = 0x2000,
			.client_instance = 0x3000,
		};
		mix_signed(&digest,
			mcctrl_sysfs_createf_post_path_body_result(
				(void *)0x515100UL, &param,
				fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops,
				fake_sysfs_local_create,
				fake_sysfs_local_cleanup_special,
				fake_sysfs_local_setup_failed));
		require(fake_sysfs_local_create_calls == 1);
		require(fake_sysfs_local_create_os == (void *)0x515100UL);
		require(fake_sysfs_local_create_param == &param);
		require(fake_sysfs_local_alloc_calls == 0);
		require(fake_sysfs_local_cleanup_calls == 0);
		mix_signed(&digest, fake_sysfs_local_create_calls);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_d64,
			.client_instance = 0x44440000L,
		};
		mix_signed(&digest,
			mcctrl_sysfs_createf_post_path_body_result(
				(void *)0x515101UL, &param,
				fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops,
				fake_sysfs_local_create,
				fake_sysfs_local_cleanup_special,
				fake_sysfs_local_setup_failed));
		require(fake_sysfs_local_create_calls == 1);
		require(param.client_ops == (long)fake_sysfs_local_ops_table[2]);
		require(param.client_instance == 0x44440000L);
		require(fake_sysfs_local_cleanup_calls == 0);
		mix(&digest, param.client_ops);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 23,
			.ptr = (void *)0x23232323UL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pbl,
			.client_instance = (long)&source,
		};
		fake_sysfs_local_fail_alloc = 1;
		mix_signed(&digest,
			mcctrl_sysfs_createf_post_path_body_result(
				(void *)0x515102UL, &param,
				fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops,
				fake_sysfs_local_create,
				fake_sysfs_local_cleanup_special,
				fake_sysfs_local_setup_failed));
		require(fake_sysfs_local_setup_failed_calls == 1);
		require(fake_sysfs_local_setup_failed_error == -12);
		require(fake_sysfs_local_create_calls == 0);
		require(fake_sysfs_local_cleanup_calls == 0);
		mix_signed(&digest, fake_sysfs_local_setup_failed_error);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 47,
			.ptr = (void *)0x47474747UL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pb,
			.client_instance = (long)&source,
		};
		fake_sysfs_local_create_ret = -5;
		mix_signed(&digest,
			mcctrl_sysfs_createf_post_path_body_result(
				(void *)0x515103UL, &param,
				fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops,
				fake_sysfs_local_create,
				fake_sysfs_local_cleanup_special,
				fake_sysfs_local_setup_failed));
		require(fake_sysfs_local_create_calls == 1);
		require(fake_sysfs_local_cleanup_calls == 1);
		require(fake_sysfs_local_cleanup_ops ==
			fake_sysfs_local_ops_table[7]);
		require(fake_sysfs_local_cleanup_instance ==
			&fake_sysfs_local_bitmap);
		mix_signed(&digest, fake_sysfs_local_cleanup_calls);
	}

	reset_fake_work();
	mix_signed(&digest,
		mcctrl_sysfs_createf_post_path_body_result(
			(void *)0x515104UL, NULL, fake_sysfs_local_ops_table,
			sizeof(fake_sysfs_local_bitmap),
			fake_sysfs_local_alloc, fake_sysfs_local_copy,
			fake_sysfs_local_unknown_ops, fake_sysfs_local_create,
			fake_sysfs_local_cleanup_special,
			fake_sysfs_local_setup_failed));
	require(fake_sysfs_local_create_calls == 0);

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_mkdir_param param = { 0 };
		mix_signed(&digest,
			mcctrl_sysfs_mkdirf_post_path_body_result(
				(void *)0x6d6b0100UL, &param,
				fake_sysfs_local_mkdir));
		require(fake_sysfs_local_mkdir_calls == 1);
		require(fake_sysfs_local_mkdir_os == (void *)0x6d6b0100UL);
		require(fake_sysfs_local_mkdir_param == &param);
		require(param.handle == 0x6d6b646972UL);
		mix(&digest, param.handle);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_mkdir_param param = { 0 };
		fake_sysfs_local_mkdir_ret = -5;
		mix_signed(&digest,
			mcctrl_sysfs_mkdirf_post_path_body_result(
				(void *)0x6d6b0200UL, &param,
				fake_sysfs_local_mkdir));
		require(fake_sysfs_local_mkdir_calls == 1);
		require(param.handle == 0);
		mix_signed(&digest, fake_sysfs_local_mkdir_ret);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_sysfs_mkdirf_post_path_body_result(
		(void *)0x6d6b0300UL, NULL, fake_sysfs_local_mkdir));
	require(fake_sysfs_local_mkdir_calls == 0);
	mix_signed(&digest, mcctrl_sysfs_mkdirf_post_path_body_result(
		(void *)0x6d6b0400UL,
		(struct mcctrl_sysfs_req_mkdir_param *)0x1UL, NULL));

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_symlink_param param = {
			.target = 0x51525354L,
		};
		mix_signed(&digest,
			mcctrl_sysfs_symlinkf_post_path_body_result(
				(void *)0x73796d01UL, &param,
				fake_sysfs_local_symlink));
		require(fake_sysfs_local_symlink_calls == 1);
		require(fake_sysfs_local_symlink_os ==
			(void *)0x73796d01UL);
		require(fake_sysfs_local_symlink_param == &param);
		require(param.target == 0x51525354L);
		mix_signed(&digest, fake_sysfs_local_symlink_calls);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_symlink_param param = { 0 };
		fake_sysfs_local_symlink_ret = -17;
		mix_signed(&digest,
			mcctrl_sysfs_symlinkf_post_path_body_result(
				(void *)0x73796d02UL, &param,
				fake_sysfs_local_symlink));
		require(fake_sysfs_local_symlink_calls == 1);
		mix_signed(&digest, fake_sysfs_local_symlink_ret);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_sysfs_symlinkf_post_path_body_result(
		(void *)0x73796d03UL, NULL, fake_sysfs_local_symlink));
	require(fake_sysfs_local_symlink_calls == 0);
	mix_signed(&digest, mcctrl_sysfs_symlinkf_post_path_body_result(
		(void *)0x73796d04UL,
		(struct mcctrl_sysfs_req_symlink_param *)0x1UL, NULL));

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_lookup_param param = { 0 };
		mix_signed(&digest,
			mcctrl_sysfs_lookupf_post_path_body_result(
				(void *)0x6c6f6f01UL, &param,
				fake_sysfs_local_lookup));
		require(fake_sysfs_local_lookup_calls == 1);
		require(fake_sysfs_local_lookup_os == (void *)0x6c6f6f01UL);
		require(fake_sysfs_local_lookup_param == &param);
		require(param.handle == 0x6c6f6f6bUL);
		mix(&digest, param.handle);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_lookup_param param = { 0 };
		fake_sysfs_local_lookup_ret = -2;
		mix_signed(&digest,
			mcctrl_sysfs_lookupf_post_path_body_result(
				(void *)0x6c6f6f02UL, &param,
				fake_sysfs_local_lookup));
		require(fake_sysfs_local_lookup_calls == 1);
		require(param.handle == 0);
		mix_signed(&digest, fake_sysfs_local_lookup_ret);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_sysfs_lookupf_post_path_body_result(
		(void *)0x6c6f6f03UL, NULL, fake_sysfs_local_lookup));
	require(fake_sysfs_local_lookup_calls == 0);
	mix_signed(&digest, mcctrl_sysfs_lookupf_post_path_body_result(
		(void *)0x6c6f6f04UL,
		(struct mcctrl_sysfs_req_lookup_param *)0x1UL, NULL));

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_unlink_param param = {
			.flags = 1,
		};
		mix_signed(&digest,
			mcctrl_sysfs_unlinkf_post_path_body_result(
				(void *)0x756e6c01UL, &param,
				fake_sysfs_local_unlink));
		require(fake_sysfs_local_unlink_calls == 1);
		require(fake_sysfs_local_unlink_os == (void *)0x756e6c01UL);
		require(fake_sysfs_local_unlink_param == &param);
		require(param.flags == 1);
		mix_signed(&digest, fake_sysfs_local_unlink_calls);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_unlink_param param = { 0 };
		fake_sysfs_local_unlink_ret = -39;
		mix_signed(&digest,
			mcctrl_sysfs_unlinkf_post_path_body_result(
				(void *)0x756e6c02UL, &param,
				fake_sysfs_local_unlink));
		require(fake_sysfs_local_unlink_calls == 1);
		mix_signed(&digest, fake_sysfs_local_unlink_ret);
	}

	reset_fake_work();
	mix_signed(&digest, mcctrl_sysfs_unlinkf_post_path_body_result(
		(void *)0x756e6c03UL, NULL, fake_sysfs_local_unlink));
	require(fake_sysfs_local_unlink_calls == 0);
	mix_signed(&digest, mcctrl_sysfs_unlinkf_post_path_body_result(
		(void *)0x756e6c04UL,
		(struct mcctrl_sysfs_req_unlink_param *)0x1UL, NULL));

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_setup_param param = {
			.buf_rpa = (long)(uintptr_t)fake_sysfs_remote_kernel_buf,
			.bufsize = 64,
			.busy = 1,
		};
		mix_signed(&digest, mcctrl_sysfs_req_setup_body_result(
			(void *)0x51535100UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_req_setup_local, fake_sysfs_req_wmb));
		require(fake_sysfs_req_os_to_dev_calls == 1);
		require(fake_sysfs_req_map_memory_calls == 2);
		require(fake_sysfs_req_map_virtual_calls == 2);
		require(fake_sysfs_req_setup_local_calls == 1);
		require(fake_sysfs_req_setup_os == (void *)0x51535100UL);
		require(fake_sysfs_req_setup_buf == fake_sysfs_remote_kernel_buf);
		require(fake_sysfs_req_setup_buf_pa ==
			(unsigned long)(uintptr_t)fake_sysfs_remote_kernel_buf +
			0x100000UL);
		require(fake_sysfs_req_setup_bufsize == 64);
		require(param.error == 0);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		require(fake_sysfs_req_unmap_virtual_calls == 1);
		require(fake_sysfs_req_unmap_memory_calls == 1);
		mix_signed(&digest, fake_sysfs_req_setup_local_calls);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_setup_param param = {
			.buf_rpa = (long)(uintptr_t)fake_sysfs_remote_kernel_buf,
			.bufsize = 32,
			.busy = 1,
		};
		fake_sysfs_req_setup_local_ret = -5;
		mix_signed(&digest, mcctrl_sysfs_req_setup_body_result(
			(void *)0x51535101UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_req_setup_local, fake_sysfs_req_wmb));
		require(param.error == -5);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		require(fake_sysfs_req_unmap_virtual_calls == 2);
		require(fake_sysfs_req_unmap_memory_calls == 2);
		mix_signed(&digest, param.error);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_create_param param = {
			.mode = 0644,
			.busy = 1,
		};
		mix_signed(&digest, mcctrl_sysfs_req_create_body_result(
			(void *)0x43524551UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_local_create, fake_sysfs_req_wmb));
		require(fake_sysfs_local_create_calls == 1);
		require(fake_sysfs_local_create_os == (void *)0x43524551UL);
		require(fake_sysfs_local_create_param == &param);
		require(param.error == 0);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		require(fake_sysfs_req_unmap_virtual_calls == 1);
		require(fake_sysfs_req_unmap_memory_calls == 1);
		mix_signed(&digest, fake_sysfs_local_create_calls);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_mkdir_param param = {
			.busy = 1,
		};
		mix_signed(&digest, mcctrl_sysfs_req_mkdir_body_result(
			(void *)0x4d4b5251UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_local_mkdir, fake_sysfs_req_wmb));
		require(fake_sysfs_local_mkdir_calls == 1);
		require(fake_sysfs_local_mkdir_os == (void *)0x4d4b5251UL);
		require(fake_sysfs_local_mkdir_param == &param);
		require(param.handle == 0x6d6b646972UL);
		require(param.error == 0);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		mix(&digest, param.handle);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_symlink_param param = {
			.target = 0xabcdefUL,
			.busy = 1,
		};
		fake_sysfs_local_symlink_ret = -17;
		mix_signed(&digest, mcctrl_sysfs_req_symlink_body_result(
			(void *)0x53594d51UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_local_symlink, fake_sysfs_req_wmb));
		require(fake_sysfs_local_symlink_calls == 1);
		require(fake_sysfs_local_symlink_os == (void *)0x53594d51UL);
		require(fake_sysfs_local_symlink_param == &param);
		require(param.error == -17);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		mix_signed(&digest, param.error);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_lookup_param param = {
			.busy = 1,
		};
		mix_signed(&digest, mcctrl_sysfs_req_lookup_body_result(
			(void *)0x4c4b5551UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_local_lookup, fake_sysfs_req_wmb));
		require(fake_sysfs_local_lookup_calls == 1);
		require(fake_sysfs_local_lookup_os == (void *)0x4c4b5551UL);
		require(fake_sysfs_local_lookup_param == &param);
		require(param.handle == 0x6c6f6f6bUL);
		require(param.error == 0);
		require(param.busy == 0);
		mix(&digest, param.handle);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_unlink_param param = {
			.flags = 3,
			.busy = 1,
		};
		fake_sysfs_local_unlink_ret = -39;
		mix_signed(&digest, mcctrl_sysfs_req_unlink_body_result(
			(void *)0x554e4c51UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			fake_sysfs_local_unlink, fake_sysfs_req_wmb));
		require(fake_sysfs_local_unlink_calls == 1);
		require(fake_sysfs_local_unlink_os == (void *)0x554e4c51UL);
		require(fake_sysfs_local_unlink_param == &param);
		require(param.error == -39);
		require(param.busy == 0);
		require(fake_sysfs_req_wmb_calls == 1);
		mix_signed(&digest, param.error);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_create_param param = {
			.busy = 1,
		};
		mix_signed(&digest, mcctrl_sysfs_req_create_body_result(
			(void *)0x43524e55UL, (unsigned long)(uintptr_t)&param,
			sizeof(param), fake_sysfs_req_os_to_dev,
			fake_sysfs_req_map_memory, fake_sysfs_req_map_virtual,
			fake_sysfs_req_unmap_virtual,
			fake_sysfs_req_unmap_memory,
			NULL, fake_sysfs_req_wmb));
		require(fake_sysfs_local_create_calls == 0);
		require(fake_sysfs_req_map_memory_calls == 0);
		require(param.busy == 1);
		mix_signed(&digest, param.busy);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);

	{
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_d32,
			.client_instance = 0x12345678L,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(param.client_ops == (long)fake_sysfs_local_ops_table[1]);
		require(param.client_instance == 0x12345678L);
		require(fake_sysfs_local_alloc_calls == 0);
		require(fake_sysfs_local_copy_calls == 0);
		mix(&digest, param.client_ops);
	}

	{
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_s,
			.client_instance = 0x22334455L,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(param.client_ops == (long)fake_sysfs_local_ops_table[5]);
		require(param.client_instance == 0x22334455L);
		mix(&digest, param.client_ops);
	}

	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 77,
			.ptr = (void *)0xfeed7000UL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pbl,
			.client_instance = (long)&source,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(fake_sysfs_local_alloc_calls == 1);
		require(fake_sysfs_local_alloc_size ==
			sizeof(fake_sysfs_local_bitmap));
		require(fake_sysfs_local_copy_calls == 1);
		require(fake_sysfs_local_copy_size ==
			sizeof(fake_sysfs_local_bitmap));
		require(fake_sysfs_local_bitmap.nbits == 77);
		require(fake_sysfs_local_bitmap.ptr == (void *)0xfeed7000UL);
		require(param.client_ops == (long)fake_sysfs_local_ops_table[6]);
		require(param.client_instance == (long)&fake_sysfs_local_bitmap);
		mix_signed(&digest, fake_sysfs_local_bitmap.nbits);
		mix(&digest, param.client_instance);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 13,
			.ptr = (void *)0xc001d00dUL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pb,
			.client_instance = (long)&source,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(fake_sysfs_local_alloc_calls == 1);
		require(fake_sysfs_local_copy_calls == 1);
		require(fake_sysfs_local_bitmap.nbits == 13);
		require(fake_sysfs_local_bitmap.ptr == (void *)0xc001d00dUL);
		require(param.client_ops == (long)fake_sysfs_local_ops_table[7]);
		require(param.client_instance == (long)&fake_sysfs_local_bitmap);
		mix_signed(&digest, fake_sysfs_local_bitmap.nbits);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 9,
			.ptr = (void *)0x11111111UL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pbl,
			.client_instance = (long)&source,
		};
		fake_sysfs_local_fail_alloc = 1;
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(fake_sysfs_local_alloc_calls == 1);
		require(fake_sysfs_local_copy_calls == 0);
		require(param.client_ops == (long)SYSFS_SNOOPING_OPS_pbl);
		require(param.client_instance == (long)&source);
		mix_signed(&digest, fake_sysfs_local_alloc_calls);
	}

	reset_fake_work();
	{
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = 999,
			.client_instance = 0x99L,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				fake_sysfs_local_alloc, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(fake_sysfs_local_unknown_calls == 1);
		require(fake_sysfs_local_unknown_ops_seen == 999);
		require(param.client_ops == 999);
		require(fake_sysfs_local_alloc_calls == 0);
		mix_signed(&digest, fake_sysfs_local_unknown_calls);
	}

	reset_fake_work();
	for (int i = 1; i < 9; ++i)
		fake_sysfs_local_ops_table[i] =
			(void *)(0xabc000UL + (unsigned long)i * 0x10UL);
	{
		struct mcctrl_sysfsm_bitmap_param source = {
			.nbits = 31,
			.ptr = (void *)0x31313131UL,
		};
		struct mcctrl_sysfs_req_create_param param = {
			.client_ops = (long)SYSFS_SNOOPING_OPS_pb,
			.client_instance = (long)&source,
		};
		mix_signed(&digest,
			mcctrl_sysfs_setup_special_local_create_body_result(
				&param, fake_sysfs_local_ops_table,
				sizeof(fake_sysfs_local_bitmap),
				NULL, fake_sysfs_local_copy,
				fake_sysfs_local_unknown_ops));
		require(param.client_ops == (long)SYSFS_SNOOPING_OPS_pb);
		require(fake_sysfs_local_copy_calls == 0);
		mix(&digest, param.client_ops);
	}

	reset_fake_driver();
	require(mcctrl_driver_ioctl_body_result(0x1100, 0x22, 0x3300,
			0x4400, fake_driver_control) == 0x660022L);
	require(fake_driver_control_calls == 1);
	require(fake_driver_control_os == 0x1100);
	require(fake_driver_control_request == 0x22);
	require(fake_driver_control_arg == 0x3300);
	require(fake_driver_control_file == 0x4400);
	require(mcctrl_driver_ioctl_body_result(0, 0, 0, 0, NULL) == -22);
	mix_signed(&digest, fake_driver_control_calls);

	reset_fake_driver();
	fake_driver_os_slots[3] = (void *)0x330033UL;
	fake_driver_os_slots[7] = (void *)0x770077UL;
	require(mcctrl_driver_osnum_to_os_body_result(
			3, fake_driver_get_os) == 0x330033UL);
	require(fake_driver_get_os_calls == 1);
	require(mcctrl_driver_os_alive_body_result(
			8, fake_driver_get_os) == 3);
	fake_driver_os_slots[3] = NULL;
	require(mcctrl_driver_os_alive_body_result(
			8, fake_driver_get_os) == 7);
	fake_driver_os_slots[7] = NULL;
	require(mcctrl_driver_os_alive_body_result(
			8, fake_driver_get_os) == -1);
	require(mcctrl_driver_os_alive_body_result(8, NULL) == -1);
	mix_signed(&digest, fake_driver_last_index);

	reset_fake_driver();
	require(mcctrl_driver_boot_notifier_body_result(
			5, &fake_driver_boot_ops) == 0);
	require(fake_driver_os_slots[5] == fake_driver_find_result);
	require(fake_driver_prepare_calls == 1);
	require(fake_driver_copy_proto_calls == 1);
	require(fake_driver_set_kernel_calls == 1);
	require(fake_driver_register_user_calls == 1);
	require(fake_driver_procfs_init_calls == 1);
	require(fake_driver_clear_kernel_calls == 0);
	require(fake_driver_destroy_calls == 0);
	require(fake_driver_log_stage == 4);
	require(fake_driver_log_index == 5);
	mix_signed(&digest, fake_driver_procfs_init_calls);

	reset_fake_driver();
	fake_driver_find_result = NULL;
	require(mcctrl_driver_boot_notifier_body_result(
			6, &fake_driver_boot_ops) == -22);
	require(fake_driver_prepare_calls == 0);
	require(fake_driver_log_stage == 0);
	require(fake_driver_os_slots[6] == NULL);
	mix_signed(&digest, fake_driver_log_stage);

	reset_fake_driver();
	fake_driver_prepare_ret = -9;
	require(mcctrl_driver_boot_notifier_body_result(
			7, &fake_driver_boot_ops) == -14);
	require(fake_driver_prepare_calls == 1);
	require(fake_driver_destroy_calls == 0);
	require(fake_driver_os_slots[7] == NULL);
	require(fake_driver_log_stage == 1);
	mix_signed(&digest, fake_driver_prepare_ret);

	reset_fake_driver();
	fake_driver_set_kernel_ret = -5;
	require(mcctrl_driver_boot_notifier_body_result(
			8, &fake_driver_boot_ops) == -5);
	require(fake_driver_set_kernel_calls == 1);
	require(fake_driver_register_user_calls == 0);
	require(fake_driver_clear_kernel_calls == 0);
	require(fake_driver_destroy_calls == 1);
	require(fake_driver_os_slots[8] == NULL);
	require(fake_driver_log_stage == 2);
	mix_signed(&digest, fake_driver_destroy_calls);

	reset_fake_driver();
	fake_driver_register_user_ret = -6;
	require(mcctrl_driver_boot_notifier_body_result(
			9, &fake_driver_boot_ops) == -6);
	require(fake_driver_register_user_calls == 1);
	require(fake_driver_clear_kernel_calls == 1);
	require(fake_driver_destroy_calls == 1);
	require(fake_driver_os_slots[9] == NULL);
	require(fake_driver_log_stage == 3);
	mix_signed(&digest, fake_driver_clear_kernel_calls);

	reset_fake_driver();
	fake_driver_os_slots[4] = fake_driver_find_result;
	require(mcctrl_driver_shutdown_notifier_body_result(
			4, &fake_driver_shutdown_ops) == 0);
	require(fake_driver_pager_cleanup_calls == 1);
	require(fake_driver_sysfs_cleanup_calls == 1);
	require(fake_driver_free_topology_calls == 1);
	require(fake_driver_unregister_user_calls == 1);
	require(fake_driver_clear_kernel_calls == 1);
	require(fake_driver_destroy_calls == 1);
	require(fake_driver_procfs_exit_calls == 1);
	require(fake_driver_os_slots[4] == NULL);
	require(fake_driver_log_stage == 5);
	mix_signed(&digest, fake_driver_unregister_user_calls);

	reset_fake_driver();
	require(mcctrl_driver_shutdown_notifier_body_result(
			4, &fake_driver_shutdown_ops) == 0);
	require(fake_driver_pager_cleanup_calls == 0);
	require(fake_driver_set_os_calls == 1);
	require(fake_driver_log_stage == 5);
	mix_signed(&digest, fake_driver_set_os_calls);

	reset_fake_driver();
	require(mcctrl_driver_symbols_init_body_result(
			&fake_driver_symbols_ops) == 0);
	require(fake_driver_lookup_calls == 8);
	require(fake_driver_publish_calls == 8);
	require(fake_driver_warn_calls == 8);
	require(fake_driver_arch_calls == 1);
	for (int i = 0; i < 8; i++)
		require(fake_driver_published_symbols[i] ==
				fake_driver_symbol_values[i]);
	mix_signed(&digest, fake_driver_arch_calls);

	reset_fake_driver();
	fake_driver_symbol_missing = 2;
	require(mcctrl_driver_symbols_init_body_result(
			&fake_driver_symbols_ops) == -14);
	require(fake_driver_lookup_calls == 3);
	require(fake_driver_publish_calls == 3);
	require(fake_driver_warn_calls == 3);
	require(fake_driver_arch_calls == 0);
	mix_signed(&digest, fake_driver_warn_calls);

	reset_fake_driver();
	fake_driver_arch_ret = -17;
	require(mcctrl_driver_symbols_init_body_result(
			&fake_driver_symbols_ops) == -17);
	require(fake_driver_lookup_calls == 8);
	require(fake_driver_arch_calls == 1);
	mix_signed(&digest, fake_driver_arch_ret);

	reset_fake_driver();
	require(mcctrl_driver_init_body_result(
			4, &fake_driver_module_ops) == 0);
	require(fake_driver_syscall_init_calls == 1);
	require(fake_driver_set_os_calls == 4);
	require(fake_driver_binfmt_init_calls == 1);
	require(fake_driver_tofu_hash_calls == 1);
	require(fake_driver_symbols_init_calls == 1);
	require(fake_driver_tofu_hijack_calls == 1);
	require(fake_driver_register_notifier_calls == 1);
	require(fake_driver_binfmt_exit_calls == 0);
	require(!strcmp(fake_driver_order, "sbhyjr"));
	require(fake_driver_log_stage == 7);
	mix_signed(&digest, fake_driver_set_os_calls);

	reset_fake_driver();
	fake_driver_symbols_init_ret = -11;
	require(mcctrl_driver_init_body_result(
			4, &fake_driver_module_ops) == -11);
	require(fake_driver_register_notifier_calls == 0);
	require(fake_driver_binfmt_exit_calls == 1);
	require(!strcmp(fake_driver_order, "sbhyx"));
	mix_signed(&digest, fake_driver_symbols_init_ret);

	reset_fake_driver();
	fake_driver_register_notifier_ret = -13;
	require(mcctrl_driver_init_body_result(
			4, &fake_driver_module_ops) == -13);
	require(fake_driver_tofu_hijack_calls == 1);
	require(fake_driver_binfmt_exit_calls == 1);
	require(fake_driver_log_stage == 6);
	require(!strcmp(fake_driver_order, "sbhyjrx"));
	mix_signed(&digest, fake_driver_register_notifier_ret);

	reset_fake_driver();
	fake_driver_deregister_notifier_ret = -1;
	mcctrl_driver_exit_body_result(&fake_driver_module_ops);
	require(fake_driver_deregister_notifier_calls == 1);
	require(fake_driver_binfmt_exit_calls == 1);
	require(fake_driver_uti_finalize_calls == 1);
	require(fake_driver_tofu_restore_calls == 1);
	require(fake_driver_log_calls == 2);
	require(fake_driver_log_stage == 9);
	require(!strcmp(fake_driver_order, "dxut"));
	mix_signed(&digest, fake_driver_log_calls);

	{
		struct mcctrl_ikc_scd_packet packet;
		struct mcctrl_in_kernel_syscall_ops missing_ops =
			fake_in_kernel_ops;
		long ret_out;

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MMAP);
		packet.body.traditional.req.args[0] = 0xabc001UL;
		ret_out = -99;
		require(mcctrl_in_kernel_syscall_body_result(0x515000UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(ret_out == fake_in_kernel_pager_ret);
		require(fake_in_kernel_pager_calls == 1);
		require(fake_in_kernel_return_calls == 1);
		require(fake_in_kernel_release_calls == 1);
		require(fake_in_kernel_last_os == 0x515000UL);
		require(fake_in_kernel_last_number == FAKE_NR_MMAP);
		require(fake_in_kernel_last_arg0 == 0xabc001UL);
		require(fake_in_kernel_last_ret == fake_in_kernel_pager_ret);
		require(fake_in_kernel_last_stid == 0);
		require(fake_in_kernel_last_packet == &packet);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MUNMAP);
		packet.body.traditional.req.args[0] = 0x1000UL;
		packet.body.traditional.req.args[1] = 0x2000UL;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515001UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_clear_calls == 1);
		require(fake_in_kernel_last_arg0 == 0x1000UL);
		require(fake_in_kernel_last_arg1 == 0x2000UL);
		require(ret_out == fake_in_kernel_clear_ret);
		require(fake_in_kernel_return_calls == 1);
		require(fake_in_kernel_release_calls == 1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MPROTECT);
		packet.body.traditional.req.args[0] = 0x3000UL;
		packet.body.traditional.req.args[1] = 0x4000UL;
		packet.body.traditional.req.args[2] = 7;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515002UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_remap_calls == 1);
		require(fake_in_kernel_last_arg0 == 0x3000UL);
		require(fake_in_kernel_last_arg1 == 0x4000UL);
		require(fake_in_kernel_last_int == 7);
		require(ret_out == fake_in_kernel_remap_ret);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MOVE_PAGES);
		packet.body.traditional.req.args[0] = 0xfeed000UL;
		ret_out = 1234;
		require(mcctrl_in_kernel_syscall_body_result(0x515003UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_zero_calls == 1);
		require(fake_in_kernel_last_arg0 == 0xfeed000UL);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 1);
		require(ret_out == -1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_COREDUMP);
		packet.body.traditional.req.args[0] = 3;
		packet.body.traditional.req.args[1] = 0xc0deUL;
		packet.body.traditional.req.args[2] = 0x55UL;
		packet.body.traditional.req.args[3] = 0xf17eUL;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515004UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_writecore_calls == 1);
		require(fake_in_kernel_last_os == 0x515004UL);
		require(fake_in_kernel_last_arg0 == 0xc0deUL);
		require(fake_in_kernel_last_int == 3);
		require(fake_in_kernel_last_arg2 == 0x55UL);
		require(fake_in_kernel_last_arg3 == 0xf17eUL);
		require(ret_out == fake_in_kernel_writecore_ret);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_SCHED_SETPARAM);
		packet.body.traditional.req.args[0] =
			FAKE_SCHED_CHECK_SAME_OWNER;
		packet.body.traditional.req.args[1] = 123;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515005UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_sched_same_calls == 1);
		require(fake_in_kernel_last_int == 123);
		require(ret_out == fake_in_kernel_sched_same_ret);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_SCHED_SETPARAM);
		packet.body.traditional.req.args[0] = FAKE_SCHED_CHECK_ROOT;
		packet.body.traditional.req.args[1] = 456;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515006UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_sched_root_calls == 1);
		require(fake_in_kernel_last_int == 456);
		require(ret_out == fake_in_kernel_sched_root_ret);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_SCHED_SETPARAM);
		packet.body.traditional.req.args[0] = 0x777;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515007UL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_sched_same_calls == 0);
		require(fake_in_kernel_sched_root_calls == 0);
		require(fake_in_kernel_return_calls == 1);
		require(fake_in_kernel_release_calls == 1);
		require(ret_out == -1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_CLOSE);
		packet.body.traditional.req.args[0] = 9;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515008UL,
			&packet, &fake_in_kernel_ops, &ret_out) == -38);
		require(fake_in_kernel_tofu_close_calls == 1);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 0);
		require(ret_out == -1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_EXIT_GROUP);
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x515009UL,
			&packet, &fake_in_kernel_ops, &ret_out) == -38);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 0);
		require(ret_out == -1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, 0x123456UL);
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x51500aUL,
			&packet, &fake_in_kernel_ops, &ret_out) == -38);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 0);
		require(ret_out == -1);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MMAP);
		packet.body.traditional.req.args[0] = 0x777000UL;
		ret_out = 0;
		require(mcctrl_in_kernel_irq_syscall_body_result(0x51500bUL,
			&packet, &fake_in_kernel_ops, &ret_out) == 0);
		require(fake_in_kernel_pager_irq_calls == 1);
		require(fake_in_kernel_return_calls == 1);
		require(fake_in_kernel_release_calls == 0);
		require(ret_out == fake_in_kernel_pager_irq_ret);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MMAP);
		fake_in_kernel_pager_irq_ret = -38;
		ret_out = 0;
		require(mcctrl_in_kernel_irq_syscall_body_result(0x51500cUL,
			&packet, &fake_in_kernel_ops, &ret_out) == -38);
		require(fake_in_kernel_pager_irq_calls == 1);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 0);
		require(ret_out == -38);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, 0xabcdefUL);
		ret_out = 0;
		require(mcctrl_in_kernel_irq_syscall_body_result(0x51500dUL,
			&packet, &fake_in_kernel_ops, &ret_out) == -38);
		require(fake_in_kernel_pager_irq_calls == 0);
		require(ret_out == 0);
		mix_signed(&digest, ret_out);

		reset_fake_in_kernel();
		fake_in_kernel_prepare_packet(&packet, FAKE_NR_MMAP);
		missing_ops.pager = NULL;
		ret_out = 0;
		require(mcctrl_in_kernel_syscall_body_result(0x51500eUL,
			&packet, &missing_ops, &ret_out) == -22);
		require(fake_in_kernel_pager_calls == 0);
		require(fake_in_kernel_return_calls == 0);
		require(fake_in_kernel_release_calls == 0);
		mix_signed(&digest, ret_out);

		require(mcctrl_in_kernel_syscall_body_result(0x51500fUL,
			NULL, &fake_in_kernel_ops, &ret_out) == -22);
		require(mcctrl_in_kernel_syscall_body_result(0x515010UL,
			&packet, NULL, &ret_out) == -22);
		require(mcctrl_in_kernel_irq_syscall_body_result(0x515011UL,
			NULL, &fake_in_kernel_ops, &ret_out) == -22);
		require(mcctrl_in_kernel_irq_syscall_body_result(0x515012UL,
			&packet, NULL, &ret_out) == -22);
		mix_signed(&digest, fake_in_kernel_release_calls);
	}

	{
		struct mcctrl_syscall_request req;
		struct mcctrl_pager_call_ops missing_ops = fake_pager_ops;

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_CREATE);
		req.args[1] = 17;
		req.args[2] = 0xc001UL;
		require(mcctrl_pager_call_body_result(
			0x616000UL, &req, &fake_pager_ops) ==
			fake_pager_create_ret);
		require(fake_pager_create_calls == 1);
		require(fake_pager_last_os == 0x616000UL);
		require(fake_pager_last_arg1 == 17);
		require(fake_pager_last_arg2 == 0xc001UL);
		mix_signed(&digest, fake_pager_create_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_RELEASE);
		req.args[1] = 0xabcUL;
		req.args[2] = 9;
		require(mcctrl_pager_call_irq_body_result(
			0x616001UL, &req, &fake_pager_ops) ==
			fake_pager_release_ret);
		require(fake_pager_release_calls == 1);
		require(fake_pager_last_os == 0x616001UL);
		require(fake_pager_last_arg1 == 0xabcUL);
		require(fake_pager_last_arg2 == 9);
		mix_signed(&digest, fake_pager_release_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_READ);
		req.args[1] = 0x10UL;
		req.args[2] = 0x20UL;
		req.args[3] = 0x30UL;
		req.args[4] = 0x40UL;
		require(mcctrl_pager_call_body_result(
			0x616002UL, &req, &fake_pager_ops) ==
			fake_pager_read_ret);
		require(fake_pager_read_calls == 1);
		require(fake_pager_last_arg1 == 0x10UL);
		require(fake_pager_last_arg2 == 0x20UL);
		require(fake_pager_last_arg3 == 0x30UL);
		require(fake_pager_last_arg4 == 0x40UL);
		mix_signed(&digest, fake_pager_read_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_WRITE);
		req.args[1] = 0x11UL;
		req.args[2] = 0x22UL;
		req.args[3] = 0x33UL;
		req.args[4] = 0x44UL;
		require(mcctrl_pager_call_body_result(
			0x616003UL, &req, &fake_pager_ops) ==
			fake_pager_write_ret);
		require(fake_pager_write_calls == 1);
		require(fake_pager_last_arg1 == 0x11UL);
		require(fake_pager_last_arg4 == 0x44UL);
		mix_signed(&digest, fake_pager_write_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_MAP);
		req.args[1] = 19;
		req.args[2] = 0x2000UL;
		req.args[3] = 0x3000UL;
		req.args[4] = 0x4000UL;
		req.args[5] = 7;
		require(mcctrl_pager_call_body_result(
			0x616004UL, &req, &fake_pager_ops) ==
			fake_pager_map_ret);
		require(fake_pager_map_calls == 1);
		require(fake_pager_last_arg1 == 19);
		require(fake_pager_last_arg2 == 0x2000UL);
		require(fake_pager_last_arg3 == 0x3000UL);
		require(fake_pager_last_arg4 == 0x4000UL);
		require(fake_pager_last_int == 7);
		mix_signed(&digest, fake_pager_map_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_PFN);
		req.args[1] = 0x55UL;
		req.args[2] = 0x66UL;
		req.args[3] = 0x77UL;
		require(mcctrl_pager_call_body_result(
			0x616005UL, &req, &fake_pager_ops) ==
			fake_pager_pfn_ret);
		require(fake_pager_pfn_calls == 1);
		require(fake_pager_last_arg3 == 0x77UL);
		mix_signed(&digest, fake_pager_pfn_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_UNMAP);
		req.args[1] = 0x88UL;
		require(mcctrl_pager_call_body_result(
			0x616006UL, &req, &fake_pager_ops) ==
			fake_pager_unmap_ret);
		require(fake_pager_unmap_calls == 1);
		require(fake_pager_last_arg1 == 0x88UL);
		mix_signed(&digest, fake_pager_unmap_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, PAGER_REQ_MLOCK_LIST);
		req.args[1] = 0x100UL;
		req.args[2] = 0x200UL;
		req.args[3] = 0x300UL;
		req.args[4] = 4;
		require(mcctrl_pager_call_body_result(
			0x616007UL, &req, &fake_pager_ops) ==
			fake_pager_mlock_ret);
		require(fake_pager_mlock_calls == 1);
		require(fake_pager_last_arg1 == 0x100UL);
		require(fake_pager_last_arg2 == 0x200UL);
		require(fake_pager_last_arg3 == 0x300UL);
		require(fake_pager_last_int == 4);
		mix_signed(&digest, fake_pager_mlock_ret);

		reset_fake_pager();
		fake_pager_prepare_req(&req, 0x999UL);
		require(mcctrl_pager_call_body_result(
			0x616008UL, &req, &fake_pager_ops) == -38);
		require(fake_pager_unknown_calls == 1);
		require(fake_pager_last_request == 0x999UL);
		require((long)fake_pager_last_arg1 == -38);
		require(mcctrl_pager_call_irq_body_result(
			0x616009UL, &req, &fake_pager_ops) == -38);
		require(fake_pager_unknown_calls == 1);
		mix_signed(&digest, fake_pager_unknown_calls);

		missing_ops.map = NULL;
		fake_pager_prepare_req(&req, PAGER_REQ_MAP);
		require(mcctrl_pager_call_body_result(
			0x61600aUL, &req, &missing_ops) == -22);
		require(mcctrl_pager_call_body_result(
			0x61600bUL, NULL, &fake_pager_ops) == -22);
		require(mcctrl_pager_call_body_result(
			0x61600cUL, &req, NULL) == -22);
		require(mcctrl_pager_call_irq_body_result(
			0x61600dUL, NULL, &fake_pager_ops) == -22);
		require(mcctrl_pager_call_irq_body_result(
			0x61600eUL, &req, NULL) == -22);
		mix_signed(&digest, fake_pager_map_calls);
	}

	{
		struct mcctrl_ikc_scd_packet packet;

		reset_fake_remote_pf();
		memset(&packet, 0, sizeof(packet));
		packet.body.remote_page_fault.target_cpu = 6;
		packet.body.remote_page_fault.fault_tid = 44;
		require(mcctrl_remote_page_fault_body_result(
			0x717000UL, (void *)0xdead000UL, 2, &packet,
			fake_remote_pf_send, fake_remote_pf_log) == 0);
		require(packet.msg == SCD_MSG_REMOTE_PAGE_FAULT);
		require(packet.body.remote_page_fault.fault_address ==
			0xdead000UL);
		require(packet.body.remote_page_fault.fault_reason == 2);
		require(fake_remote_pf_send_calls == 1);
		require(fake_remote_pf_last_os == 0x717000UL);
		require(fake_remote_pf_last_cpu == 6);
		require(fake_remote_pf_last_packet == &packet);
		require(fake_remote_pf_log_calls == 2);
		require(fake_remote_pf_last_stage == 2);
		require(fake_remote_pf_last_pid == 44);
		require(fake_remote_pf_last_addr == 0xdead000UL);
		require(fake_remote_pf_last_reason == 2);
		mix_signed(&digest, fake_remote_pf_log_calls);

		reset_fake_remote_pf();
		memset(&packet, 0, sizeof(packet));
		packet.body.remote_page_fault.target_cpu = 7;
		packet.body.remote_page_fault.fault_tid = 45;
		fake_remote_pf_send_ret = -5;
		require(mcctrl_remote_page_fault_body_result(
			0x717001UL, (void *)0xbeef000UL, 3, &packet,
			fake_remote_pf_send, fake_remote_pf_log) == -5);
		require(fake_remote_pf_send_calls == 1);
		require(fake_remote_pf_log_calls == 3);
		require(fake_remote_pf_last_stage == 2);
		require(fake_remote_pf_last_error == -5);
		require(fake_remote_pf_last_cpu == 7);
		mix_signed(&digest, fake_remote_pf_last_error);

		require(mcctrl_remote_page_fault_body_result(
			0x717002UL, (void *)0, 0, NULL,
			fake_remote_pf_send, fake_remote_pf_log) == -22);
		require(mcctrl_remote_page_fault_body_result(
			0x717003UL, (void *)0, 0, &packet,
			NULL, fake_remote_pf_log) == -22);
		mix_signed(&digest, fake_remote_pf_send_calls);
	}

	{
		struct mcctrl_clear_pte_range_ops missing_clear_ops =
			fake_clear_pte_ops;

		reset_fake_user_space();
		fake_user_vmas[0].start = 0x1000UL;
		fake_user_vmas[0].end = 0x1800UL;
		fake_user_vmas[0].flags = FAKE_VM_PFNMAP;
		fake_user_vmas[1].start = 0x2000UL;
		fake_user_vmas[1].end = 0x2800UL;
		fake_user_vmas[1].flags = 0;
		fake_user_vma_count = 2;
		require(mcctrl_clear_pte_range_body_result(0x800UL, 0x2000UL,
			FAKE_VM_PFNMAP, 0, &fake_clear_pte_ops) == 0);
		require(fake_user_space_lock_calls == 1);
		require(fake_user_space_unlock_calls == 1);
		require(fake_user_space_find_calls == 2);
		require(fake_user_space_set_rw_calls == 1);
		require(fake_user_space_zap_ptes_calls == 1);
		require(fake_user_space_zap_range_calls == 1);
		require(fake_user_space_last_start == 0x2000UL);
		require(fake_user_space_last_len == 0x800UL);
		mix_signed(&digest, fake_user_space_zap_range_calls);
		mix(&digest, fake_user_space_last_len);

		reset_fake_user_space();
		fake_user_vmas[0].start = 0x3000UL;
		fake_user_vmas[0].end = 0x3800UL;
		fake_user_vmas[0].flags = 0;
		fake_user_vma_count = 1;
		fake_user_space_zap_ptes_ret = -12;
		require(mcctrl_clear_pte_range_body_result(0x3000UL, 0x800UL,
			FAKE_VM_PFNMAP, 1, &fake_clear_pte_ops) == 0);
		require(fake_user_space_set_rw_calls == 1);
		require(fake_user_space_zap_ptes_calls == 1);
		require(fake_user_space_zap_range_calls == 1);
		require(fake_user_space_last_start == 0x3000UL);
		require(fake_user_space_last_len == 0x800UL);
		mix_signed(&digest, fake_user_space_zap_ptes_ret);

		reset_fake_user_space();
		require(mcctrl_clear_pte_range_body_result(0x5000UL, 0x900UL,
			FAKE_VM_PFNMAP, 0, &fake_clear_pte_ops) == 0);
		require(fake_user_space_lock_calls == 1);
		require(fake_user_space_unlock_calls == 1);
		require(fake_user_space_find_calls == 1);
		require(fake_user_space_zap_ptes_calls == 0);
		require(fake_user_space_zap_range_calls == 0);
		mix_signed(&digest, fake_user_space_find_calls);

		missing_clear_ops.find_vma = NULL;
		require(mcctrl_clear_pte_range_body_result(0x6000UL, 0x100UL,
			FAKE_VM_PFNMAP, 0, &missing_clear_ops) == -22);
		require(mcctrl_clear_pte_range_body_result(0x6000UL, 0x100UL,
			FAKE_VM_PFNMAP, 0, NULL) == -22);
		mix_signed(&digest, fake_user_space_lock_calls);
	}

	{
		struct mcctrl_user_space_release_ops missing_release_ops =
			fake_release_space_ops;

		reset_fake_user_space();
		fake_user_vmas[0].start = 0x1000UL;
		fake_user_vmas[0].end = 0x1800UL;
		fake_user_vmas[1].start = 0x2000UL;
		fake_user_vmas[1].end = 0x2800UL;
		fake_user_vma_count = 2;
		require(mcctrl_user_space_release_body_result(0x800UL,
			0x3000UL, &fake_release_space_ops) == 0);
		require(fake_user_space_find_calls == 3);
		require(fake_user_space_munmap_calls == 2);
		require(fake_user_space_munmap_total == 0x1000UL);
		require(fake_user_space_last_start == 0x2000UL);
		require(fake_user_space_last_len == 0x800UL);
		require(fake_user_space_log_calls == 0);
		mix(&digest, fake_user_space_munmap_total);

		reset_fake_user_space();
		fake_user_vmas[0].start = 0x4000UL;
		fake_user_vmas[0].end = 0x4800UL;
		fake_user_vma_count = 1;
		fake_user_space_munmap_ret = -33;
		require(mcctrl_user_space_release_body_result(0x4000UL,
			0x800UL, &fake_release_space_ops) == -33);
		require(fake_user_space_munmap_calls == 1);
		require(fake_user_space_log_calls == 1);
		require(fake_user_space_last_error == -33);
		mix_signed(&digest, fake_user_space_last_error);

		missing_release_ops.munmap = NULL;
		require(mcctrl_user_space_release_body_result(0x5000UL,
			0x100UL, &missing_release_ops) == -22);
		require(mcctrl_user_space_release_body_result(0x5000UL,
			0x100UL, NULL) == -22);
		mix_signed(&digest, fake_user_space_log_calls);
	}

	printf("mcctrl_helpers ok digest=%llx\n", digest);
	return 0;
}
