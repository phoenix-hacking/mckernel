#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

extern size_t strlen(const char *);
extern size_t strnlen(const char *, size_t);
extern char *strcpy(char *, const char *);
extern char *strncpy(char *, const char *, size_t);
extern int strcmp(const char *, const char *);
extern int strncmp(const char *, const char *, size_t);
extern char *strchr(const char *, int);
extern char *strrchr(const char *, int);
extern char *strpbrk(const char *, const char *);
extern char *strstr(const char *, const char *);
extern void *memcpy(void *, const void *, size_t);
extern void *__inline_memcpy(void *, const void *, size_t);
extern void *memcpy_long(void *, const void *, size_t);
extern void *__inline_memset(void *, unsigned long, size_t);
extern int memcmp(const void *, const void *, size_t);
extern int flatten_strings_from_user(char *, char **, char **);
extern int flatten_strings_from_user_body_result(
	char *, char **, char **, unsigned long,
	long (*)(long *, const long *), int (*)(const char *),
	int (*)(char *, const char *), void *(*)(size_t, unsigned long));

#define IHK_MC_AP_NOWAIT 0x000002UL

#define require(expr) do { \
	if (!(expr)) { \
		fprintf(stderr, "require failed at %s:%d: %s\n", \
			__FILE__, __LINE__, #expr); \
		return 9; \
	} \
	} while (0)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static void fill_bytes(unsigned char *dst, size_t len, unsigned char seed)
{
	for (size_t i = 0; i < len; i++)
		dst[i] = (unsigned char)(seed + i * 17);
}

static void mix_bytes(unsigned long *digest, const unsigned char *src, size_t len)
{
	for (size_t i = 0; i < len; i++)
		mix(digest, ((unsigned long)i << 8) | src[i]);
}

static long ptr_offset(const char *base, const char *ptr)
{
	if (!ptr)
		return -1;
	return ptr - base;
}

static unsigned char flatten_allocs[4][256];
static size_t flatten_alloc_size[4];
static unsigned long flatten_alloc_flags[4];
static int flatten_alloc_count;
static int flatten_alloc_fail_after;
static int flatten_getlong_count;
static int flatten_strlen_count;
static int flatten_strcpy_count;
static unsigned char fake_flatten_cpu_local[8192];

static void local_zero(void *ptr, size_t len)
{
	unsigned char *p = ptr;

	for (size_t i = 0; i < len; i++)
		p[i] = 0;
}

static size_t local_strlen(const char *s)
{
	size_t len = 0;

	while (s[len])
		len++;
	return len;
}

static void reset_flatten_trace(void)
{
	local_zero(flatten_allocs, sizeof(flatten_allocs));
	local_zero(flatten_alloc_size, sizeof(flatten_alloc_size));
	local_zero(flatten_alloc_flags, sizeof(flatten_alloc_flags));
	flatten_alloc_count = 0;
	flatten_alloc_fail_after = 0;
	flatten_getlong_count = 0;
	flatten_strlen_count = 0;
	flatten_strcpy_count = 0;
}

void *kmalloc(size_t size, unsigned long flags)
{
	int index = flatten_alloc_count++;

	if (index >= (int)(sizeof(flatten_allocs) / sizeof(flatten_allocs[0])))
		return NULL;
	flatten_alloc_size[index] = size;
	flatten_alloc_flags[index] = flags;
	if (flatten_alloc_fail_after && flatten_alloc_count == flatten_alloc_fail_after)
		return NULL;
	if (size > sizeof(flatten_allocs[index]))
		return NULL;
	return flatten_allocs[index];
}

void *_kmalloc(int size, unsigned long flags, char *file, int line)
{
	(void)file;
	(void)line;
	return kmalloc((size_t)size, flags);
}

void *kmalloc_tracked(int size, unsigned long flags, char *file, int line)
{
	return _kmalloc(size, flags, file, line);
}

__attribute__((weak)) int kprintf(const char *format, ...)
{
	(void)format;
	return 0;
}

__attribute__((weak)) int ihk_mc_get_processor_id(void)
{
	return 0;
}

void *get_cpu_local_var(int id)
{
	(void)id;
	return fake_flatten_cpu_local;
}

__attribute__((weak)) void *get_this_cpu_local_var(void)
{
	return get_cpu_local_var(ihk_mc_get_processor_id());
}

long getlong_user(long *dest, const long *src)
{
	flatten_getlong_count++;
	*dest = *src;
	return 0;
}

int strlen_user(const char *src)
{
	flatten_strlen_count++;
	return (int)local_strlen(src);
}

int strcpy_from_user(char *dst, const char *src)
{
	flatten_strcpy_count++;
	while ((*dst++ = *src++))
		;
	return 0;
}

static int run_flatten_strings_from_user(char *pre_strings, char **strings,
					 char **flat)
{
#ifdef STRING_RUST_SIDE
	return flatten_strings_from_user_body_result(pre_strings, strings, flat,
		IHK_MC_AP_NOWAIT, getlong_user, strlen_user,
		strcpy_from_user, kmalloc);
#else
	return flatten_strings_from_user(pre_strings, strings, flat);
#endif
}

int main(void)
{
	const char *strings[] = {
		"",
		"a",
		"abcdef",
		"abcabc",
		"prefix-suffix",
	};
	const char high[] = { 'A', (char)0xff, 'B', (char)0x80, '\0' };
	const char embedded[] = { 'a', 'b', 'c', '\0', 't', 'a', 'i', 'l', '\0' };
	unsigned char src[96], dst[96], dst2[96];
	unsigned long lsrc[8], ldst[8];
	unsigned long digest = 0x51f15eada5c0deUL;

	for (size_t i = 0; i < sizeof(strings) / sizeof(strings[0]); i++) {
		mix(&digest, strlen(strings[i]));
		for (size_t max = 0; max < 12; max++)
			mix(&digest, strnlen(strings[i], max));
	}
	mix(&digest, strlen(embedded));
	mix(&digest, strnlen(embedded, sizeof(embedded)));
	mix(&digest, strlen(high));

	for (size_t i = 0; i < sizeof(strings) / sizeof(strings[0]); i++) {
		for (size_t j = 0; j < sizeof(strings) / sizeof(strings[0]); j++) {
			mix_signed(&digest, strcmp(strings[i], strings[j]));
			for (size_t n = 0; n < 10; n++)
				mix_signed(&digest, strncmp(strings[i], strings[j], n));
		}
	}
	mix_signed(&digest, strcmp(high, "A"));
	mix_signed(&digest, strncmp(high, "A", 2));
	mix_signed(&digest, memcmp(high, "A", 2));

	fill_bytes(dst, sizeof(dst), 0xa0);
	if (strcpy((char *)dst, "copy-source") != (char *)dst)
		return 2;
	mix_bytes(&digest, dst, 24);

	fill_bytes(dst, sizeof(dst), 0xb0);
	if (strncpy((char *)dst, "xy", 8) != (char *)dst)
		return 3;
	mix_bytes(&digest, dst, 16);

	fill_bytes(dst, sizeof(dst), 0xc0);
	strncpy((char *)dst, "abcdef", 3);
	mix_bytes(&digest, dst, 12);

	fill_bytes(dst, sizeof(dst), 0xd0);
	strncpy((char *)dst, "", 4);
	mix_bytes(&digest, dst, 12);

	fill_bytes(dst, sizeof(dst), 0xe0);
	strncpy((char *)dst, "unchanged", 0);
	mix_bytes(&digest, dst, 12);

	for (int ch = -2; ch <= 260; ch += 17) {
		mix_signed(&digest, ptr_offset(strings[3], strchr(strings[3], ch)));
		mix_signed(&digest, ptr_offset(strings[3], strrchr(strings[3], ch)));
		mix_signed(&digest, ptr_offset(high, strchr(high, ch)));
		mix_signed(&digest, ptr_offset(high, strrchr(high, ch)));
	}
	mix_signed(&digest, ptr_offset(strings[3], strchr(strings[3], '\0')));
	mix_signed(&digest, ptr_offset(strings[3], strrchr(strings[3], '\0')));
	mix_signed(&digest, ptr_offset(strings[4], strpbrk(strings[4], "xyz-f")));
	mix_signed(&digest, ptr_offset(strings[4], strpbrk(strings[4], "")));
	mix_signed(&digest, ptr_offset("", strpbrk("", "abc")));
	mix_signed(&digest, ptr_offset(strings[3], strstr(strings[3], "abc")));
	mix_signed(&digest, ptr_offset(strings[3], strstr(strings[3], "cab")));
	mix_signed(&digest, ptr_offset(strings[3], strstr(strings[3], "")));
	mix_signed(&digest, ptr_offset("", strstr("", "")));

	fill_bytes(src, sizeof(src), 0x11);
	fill_bytes(dst, sizeof(dst), 0x77);
	if (memcpy(dst + 7, src + 3, 41) != dst + 7)
		return 4;
	mix_bytes(&digest, dst, sizeof(dst));

	fill_bytes(dst, sizeof(dst), 0x33);
	if (__inline_memcpy(dst + 5, src + 11, 37) != dst + 5)
		return 41;
	mix_bytes(&digest, dst, sizeof(dst));

	fill_bytes(dst, sizeof(dst), 0xee);
	if (__inline_memset(dst + 1, 0x11223344UL, 11) != dst + 1)
		return 42;
	{
		const unsigned char expected[] = {
			0xee, 0x44, 0x33, 0x22, 0x11, 0x44, 0x33, 0x22,
			0x11, 0x44, 0x33, 0x44, 0xba, 0xcb, 0xdc, 0xed,
		};
		require(!memcmp(dst, expected, sizeof(expected)));
	}
	mix_bytes(&digest, dst, 24);

	for (size_t i = 0; i < sizeof(lsrc) / sizeof(lsrc[0]); i++) {
		lsrc[i] = 0x1122334455667788UL ^ (0x0101010101010101UL * i);
		ldst[i] = 0xfeedfacecafebeefUL;
	}
	if (memcpy_long(ldst + 1, lsrc + 2, sizeof(unsigned long) * 3 + 5) != ldst + 1)
		return 5;
	mix_bytes(&digest, (const unsigned char *)ldst, sizeof(ldst));

	fill_bytes(dst, sizeof(dst), 0x21);
	fill_bytes(dst2, sizeof(dst2), 0x21);
	dst2[0] = 0x22;
	dst2[10] = 0x7f;
	dst2[11] = 0x80;
	for (size_t n = 0; n < 24; n++) {
		mix_signed(&digest, memcmp(dst, dst2, n));
		mix_signed(&digest, memcmp(dst2, dst, n));
	}

	{
		char *flat = NULL;
		char *flat2 = NULL;
		char one[] = "cmd";
		char two[] = "arg";
		char three[] = "tail";
		char *argv0[] = { one, two, NULL };
		char *argv1[] = { three, NULL };
		long *words;
		int rc;

		reset_flatten_trace();
		rc = run_flatten_strings_from_user(NULL, NULL, &flat);
		require(rc == (int)(sizeof(long) + sizeof(char *)));
		require(flat == (char *)flatten_allocs[0]);
		words = (long *)flat;
		require(words[0] == 0 && words[1] == 0);
		require(flatten_alloc_count == 1);
		require(flatten_alloc_size[0] == sizeof(long) + sizeof(char *));
		require(flatten_alloc_flags[0] == IHK_MC_AP_NOWAIT);
		mix(&digest, (unsigned long)rc);
		mix(&digest, flatten_alloc_size[0]);

		reset_flatten_trace();
		rc = run_flatten_strings_from_user(NULL, argv0, &flat);
		require(rc == 40);
		require(flat == (char *)flatten_allocs[0]);
		require(flatten_getlong_count == 7);
		require(flatten_strlen_count == 2);
		require(flatten_strcpy_count == 2);
		words = (long *)flat;
		require(words[0] == 2);
		require(words[1] == 32);
		require(words[2] == 36);
		require(words[3] == 40);
		require(!strcmp(flat + words[1], "cmd"));
		require(!strcmp(flat + words[2], "arg"));
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)words[1] ^ (unsigned long)words[2]);
		mix_bytes(&digest, (const unsigned char *)flat, (size_t)rc);

		rc = run_flatten_strings_from_user(flat, argv1, &flat2);
		require(rc == 53);
		require(flat2 == (char *)flatten_allocs[1]);
		require(flatten_alloc_count == 2);
		words = (long *)flat2;
		require(words[0] == 3);
		require(words[1] == 40);
		require(words[2] == 44);
		require(words[3] == 48);
		require(words[4] == 53);
		require(!strcmp(flat2 + words[1], "cmd"));
		require(!strcmp(flat2 + words[2], "arg"));
		require(!strcmp(flat2 + words[3], "tail"));
		require(flat2[53] == 0 && flat2[54] == 0 && flat2[55] == 0);
		mix(&digest, (unsigned long)rc);
		mix(&digest, (unsigned long)words[4]);
		mix_bytes(&digest, (const unsigned char *)flat2, 56);

		reset_flatten_trace();
		flatten_alloc_fail_after = 1;
		rc = run_flatten_strings_from_user(NULL, argv0, &flat);
		require(rc == -12);
		mix_signed(&digest, rc);
	}

	printf("string ok digest=%016lx\n", digest);
	return 0;
}
