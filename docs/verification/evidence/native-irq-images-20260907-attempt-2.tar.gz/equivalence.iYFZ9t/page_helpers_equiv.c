#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

typedef struct {
	int counter;
} ihk_atomic_t;

typedef struct {
	long counter64;
} ihk_atomic64_t;

struct page {
	struct list_head list;
	struct list_head hash;
	uint8_t mode;
	uint64_t phys;
	ihk_atomic_t count;
	ihk_atomic64_t mapped;
	int64_t offset;
	int pgshift;
};

enum {
	PM_NONE = 0x00,
	PM_PENDING_FREE = 0x01,
	PM_WILL_PAGEIO = 0x02,
	PM_PAGEIO = 0x03,
	PM_DONE_PAGEIO = 0x04,
	PM_PAGEIO_EOF = 0x05,
	PM_PAGEIO_ERROR = 0x06,
	PM_MAPPED = 0x07,
	MF_REG_FILE = 0x1000,
	MF_SHM = 0x40000,
};

extern uintptr_t page_to_phys(struct page *);
extern int is_splitable(struct page *, uint32_t);
extern int page_mode_in_memobj_result(int);
extern int page_multi_mapped_result(int);
extern int page_is_in_memobj_body_result(struct page *);
extern int page_is_multi_mapped_body_result(struct page *);
extern void page_map_count_inc_result(struct page *);
extern void page_map_body_result(struct page *, void (*)(struct page *));
extern int page_unmap_locked_result(struct page *);
extern int page_insert_hash_init_result(struct page *, struct list_head *,
					uint64_t);
extern struct page *page_hash_lookup_result(struct list_head *, uint64_t);
extern int page_hash_bucket_init_result(struct list_head *);
extern int page_hash_tables_init_body_result(unsigned long, unsigned long, int,
				      unsigned long, unsigned long,
				      void (*)(unsigned long),
				      int (*)(struct list_head *));
extern int page_hash_count_bucket_result(struct list_head *);
extern int page_hash_count_all_result(unsigned long, unsigned long, int,
				      unsigned long, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long));
extern int page_hash_count_pages_body_result(unsigned long, unsigned long, int,
				      unsigned long, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long),
				      int (*)(unsigned long, unsigned long, int,
					unsigned long, unsigned long,
					unsigned long (*)(unsigned long),
					void (*)(unsigned long,
						 unsigned long)));
extern struct page *phys_to_page_lookup_orchestrate_result(uint64_t,
				      unsigned long, unsigned long, int,
				      uint64_t, unsigned long, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long));
extern struct page *phys_to_page_insert_hash_orchestrate_result(uint64_t,
				      unsigned long, unsigned long, int,
				      uint64_t, unsigned long, unsigned long,
				      unsigned long, int,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long),
				      struct page *(*)(unsigned long, int));
extern struct page *phys_to_page_lookup_body_result(uint64_t,
				      unsigned long, unsigned long, int,
				      uint64_t, unsigned long, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long),
				      struct page *(*)(uint64_t,
					unsigned long, unsigned long, int,
					uint64_t, unsigned long, unsigned long,
					unsigned long (*)(unsigned long),
					void (*)(unsigned long, unsigned long)));
extern struct page *phys_to_page_insert_hash_body_result(uint64_t,
				      unsigned long, unsigned long, int,
				      uint64_t, unsigned long, unsigned long,
				      unsigned long, int,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long),
				      struct page *(*)(unsigned long, int),
				      struct page *(*)(uint64_t,
					unsigned long, unsigned long, int,
					uint64_t, unsigned long, unsigned long,
					unsigned long, int,
					unsigned long (*)(unsigned long),
					void (*)(unsigned long, unsigned long),
					struct page *(*)(unsigned long, int)),
				      void (*)(uint64_t));
extern int page_unmap_orchestrate_result(struct page *, unsigned long, int,
				      uint64_t, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long));
extern int page_unmap_body_result(struct page *, unsigned long, int,
				      uint64_t, unsigned long,
				      unsigned long (*)(unsigned long),
				      void (*)(unsigned long, unsigned long),
				      int (*)(struct page *, unsigned long, int,
					uint64_t, unsigned long,
					unsigned long (*)(unsigned long),
					void (*)(unsigned long, unsigned long)),
				      void (*)(int, struct page *, int));

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void mix_signed(unsigned long *digest, long value)
{
	mix(digest, (unsigned long)value);
}

static struct page make_page(uint8_t mode, int count, uint64_t phys)
{
	struct page page = {
		.mode = mode,
		.phys = phys,
		.count = { .counter = count },
		.mapped = { .counter64 = 0x1234 },
		.offset = 0x5678,
		.pgshift = 12,
	};

	page.list.next = &page.list;
	page.list.prev = &page.list;
	page.hash.next = &page.hash;
	page.hash.prev = &page.hash;
	return page;
}

static int fake_page_map_body_inc_count;
static struct page *fake_page_map_body_inc_page;

static void fake_page_map_body_inc(struct page *page)
{
	fake_page_map_body_inc_count++;
	fake_page_map_body_inc_page = page;
	page_map_count_inc_result(page);
}

static void reset_fake_page_map_body(void)
{
	fake_page_map_body_inc_count = 0;
	fake_page_map_body_inc_page = NULL;
}

static void list_add_tail(struct list_head *new, struct list_head *head)
{
	struct list_head *prev = head->prev;

	new->next = head;
	new->prev = prev;
	prev->next = new;
	head->prev = new;
}

struct fake_lock {
	unsigned long id;
	unsigned long locks;
	unsigned long unlocks;
	unsigned long last_flags;
};

static unsigned long fake_page_hash_lock(unsigned long lock_addr)
{
	struct fake_lock *lock = (struct fake_lock *)lock_addr;

	lock->locks++;
	return 0xabc000UL + (lock->id << 8) + lock->locks;
}

static void fake_page_hash_unlock(unsigned long lock_addr, unsigned long flags)
{
	struct fake_lock *lock = (struct fake_lock *)lock_addr;

	lock->unlocks++;
	lock->last_flags = flags;
}

static int fake_page_hash_lock_init_count;
static unsigned long fake_page_hash_lock_init_last;
static int fake_page_hash_bucket_init_count;
static unsigned long fake_page_hash_bucket_init_last;
static int fake_page_hash_bucket_init_return = 1;

static void fake_page_hash_lock_init(unsigned long lock_addr)
{
	struct fake_lock *lock = (struct fake_lock *)lock_addr;

	fake_page_hash_lock_init_count++;
	fake_page_hash_lock_init_last = lock_addr;
	lock->locks = 0;
	lock->unlocks = 0;
	lock->last_flags = 0xfeed0000UL + fake_page_hash_lock_init_count;
}

static int fake_page_hash_bucket_init(struct list_head *hash_head)
{
	fake_page_hash_bucket_init_count++;
	fake_page_hash_bucket_init_last = (unsigned long)hash_head;
	page_hash_bucket_init_result(hash_head);
	return fake_page_hash_bucket_init_return;
}

static void reset_fake_page_hash_tables_init(void)
{
	fake_page_hash_lock_init_count = 0;
	fake_page_hash_lock_init_last = 0;
	fake_page_hash_bucket_init_count = 0;
	fake_page_hash_bucket_init_last = 0;
	fake_page_hash_bucket_init_return = 1;
}

static int fake_page_hash_count_all_count;
static unsigned long fake_page_hash_count_all_hash_heads;
static unsigned long fake_page_hash_count_all_locks;
static int fake_page_hash_count_all_bucket_count;
static unsigned long fake_page_hash_count_all_hash_head_stride;
static unsigned long fake_page_hash_count_all_lock_stride;
static unsigned long (*fake_page_hash_count_all_lock_fn)(unsigned long);
static void (*fake_page_hash_count_all_unlock_fn)(unsigned long,
						  unsigned long);
static int fake_page_hash_count_all_ret;

static int fake_page_hash_count_all(unsigned long hash_heads,
				    unsigned long locks_addr, int bucket_count,
				    unsigned long hash_head_stride,
				    unsigned long lock_stride,
				    unsigned long (*lock_fn)(unsigned long),
				    void (*unlock_fn)(unsigned long,
						      unsigned long))
{
	fake_page_hash_count_all_count++;
	fake_page_hash_count_all_hash_heads = hash_heads;
	fake_page_hash_count_all_locks = locks_addr;
	fake_page_hash_count_all_bucket_count = bucket_count;
	fake_page_hash_count_all_hash_head_stride = hash_head_stride;
	fake_page_hash_count_all_lock_stride = lock_stride;
	fake_page_hash_count_all_lock_fn = lock_fn;
	fake_page_hash_count_all_unlock_fn = unlock_fn;
	return fake_page_hash_count_all_ret;
}

static void reset_fake_page_hash_count_all(void)
{
	fake_page_hash_count_all_count = 0;
	fake_page_hash_count_all_hash_heads = 0;
	fake_page_hash_count_all_locks = 0;
	fake_page_hash_count_all_bucket_count = 0;
	fake_page_hash_count_all_hash_head_stride = 0;
	fake_page_hash_count_all_lock_stride = 0;
	fake_page_hash_count_all_lock_fn = NULL;
	fake_page_hash_count_all_unlock_fn = NULL;
	fake_page_hash_count_all_ret = 0;
}

static struct page fake_alloc_pages[4];
static int fake_alloc_next;
static unsigned long fake_alloc_size;
static int fake_alloc_flag;
static int fake_phys_lookup_body_count;
static uint64_t fake_phys_lookup_body_phys;
static unsigned long fake_phys_lookup_body_hash_heads;
static unsigned long fake_phys_lookup_body_locks;
static int fake_phys_lookup_body_hash_shift;
static uint64_t fake_phys_lookup_body_hash_mask;
static unsigned long fake_phys_lookup_body_hash_head_stride;
static unsigned long fake_phys_lookup_body_lock_stride;
static unsigned long (*fake_phys_lookup_body_lock_fn)(unsigned long);
static void (*fake_phys_lookup_body_unlock_fn)(unsigned long,
					       unsigned long);
static struct page *fake_phys_lookup_body_ret;
static int fake_phys_insert_body_count;
static uint64_t fake_phys_insert_body_phys;
static unsigned long fake_phys_insert_body_hash_heads;
static unsigned long fake_phys_insert_body_locks;
static int fake_phys_insert_body_hash_shift;
static uint64_t fake_phys_insert_body_hash_mask;
static unsigned long fake_phys_insert_body_hash_head_stride;
static unsigned long fake_phys_insert_body_lock_stride;
static unsigned long fake_phys_insert_body_page_size;
static int fake_phys_insert_body_alloc_flag;
static unsigned long (*fake_phys_insert_body_lock_fn)(unsigned long);
static void (*fake_phys_insert_body_unlock_fn)(unsigned long,
					       unsigned long);
static struct page *(*fake_phys_insert_body_alloc_fn)(unsigned long, int);
static struct page *fake_phys_insert_body_ret;
static int fake_phys_insert_log_count;
static uint64_t fake_phys_insert_log_phys;
static int fake_unmap_body_orchestrate_count;
static struct page *fake_unmap_body_orchestrate_page;
static unsigned long fake_unmap_body_orchestrate_locks;
static int fake_unmap_body_orchestrate_hash_shift;
static uint64_t fake_unmap_body_orchestrate_hash_mask;
static unsigned long fake_unmap_body_orchestrate_lock_stride;
static unsigned long (*fake_unmap_body_orchestrate_lock_fn)(unsigned long);
static void (*fake_unmap_body_orchestrate_unlock_fn)(unsigned long,
						     unsigned long);
static int fake_unmap_body_orchestrate_ret;
static int fake_unmap_body_log_count;
static int fake_unmap_body_log_event[4];
static struct page *fake_unmap_body_log_page[4];
static int fake_unmap_body_log_ret[4];

static struct page *fake_page_alloc(unsigned long size, int flag)
{
	fake_alloc_size = size;
	fake_alloc_flag = flag;
	if (fake_alloc_next >= 4)
		return NULL;

	return &fake_alloc_pages[fake_alloc_next++];
}

static struct page *fake_phys_lookup_body(uint64_t phys,
					  unsigned long hash_heads,
					  unsigned long locks_addr,
					  int hash_shift,
					  uint64_t hash_mask,
					  unsigned long hash_head_stride,
					  unsigned long lock_stride,
					  unsigned long (*lock_fn)(unsigned long),
					  void (*unlock_fn)(unsigned long,
							    unsigned long))
{
	fake_phys_lookup_body_count++;
	fake_phys_lookup_body_phys = phys;
	fake_phys_lookup_body_hash_heads = hash_heads;
	fake_phys_lookup_body_locks = locks_addr;
	fake_phys_lookup_body_hash_shift = hash_shift;
	fake_phys_lookup_body_hash_mask = hash_mask;
	fake_phys_lookup_body_hash_head_stride = hash_head_stride;
	fake_phys_lookup_body_lock_stride = lock_stride;
	fake_phys_lookup_body_lock_fn = lock_fn;
	fake_phys_lookup_body_unlock_fn = unlock_fn;
	return fake_phys_lookup_body_ret;
}

static struct page *fake_phys_insert_body(uint64_t phys,
					  unsigned long hash_heads,
					  unsigned long locks_addr,
					  int hash_shift,
					  uint64_t hash_mask,
					  unsigned long hash_head_stride,
					  unsigned long lock_stride,
					  unsigned long page_size,
					  int alloc_flag,
					  unsigned long (*lock_fn)(unsigned long),
					  void (*unlock_fn)(unsigned long,
							    unsigned long),
					  struct page *(*alloc_fn)(unsigned long,
								   int))
{
	fake_phys_insert_body_count++;
	fake_phys_insert_body_phys = phys;
	fake_phys_insert_body_hash_heads = hash_heads;
	fake_phys_insert_body_locks = locks_addr;
	fake_phys_insert_body_hash_shift = hash_shift;
	fake_phys_insert_body_hash_mask = hash_mask;
	fake_phys_insert_body_hash_head_stride = hash_head_stride;
	fake_phys_insert_body_lock_stride = lock_stride;
	fake_phys_insert_body_page_size = page_size;
	fake_phys_insert_body_alloc_flag = alloc_flag;
	fake_phys_insert_body_lock_fn = lock_fn;
	fake_phys_insert_body_unlock_fn = unlock_fn;
	fake_phys_insert_body_alloc_fn = alloc_fn;
	return fake_phys_insert_body_ret;
}

static void fake_phys_insert_log(uint64_t phys)
{
	fake_phys_insert_log_count++;
	fake_phys_insert_log_phys = phys;
}

static void reset_fake_phys_body(void)
{
	fake_phys_lookup_body_count = 0;
	fake_phys_lookup_body_phys = 0;
	fake_phys_lookup_body_hash_heads = 0;
	fake_phys_lookup_body_locks = 0;
	fake_phys_lookup_body_hash_shift = 0;
	fake_phys_lookup_body_hash_mask = 0;
	fake_phys_lookup_body_hash_head_stride = 0;
	fake_phys_lookup_body_lock_stride = 0;
	fake_phys_lookup_body_lock_fn = NULL;
	fake_phys_lookup_body_unlock_fn = NULL;
	fake_phys_lookup_body_ret = NULL;
	fake_phys_insert_body_count = 0;
	fake_phys_insert_body_phys = 0;
	fake_phys_insert_body_hash_heads = 0;
	fake_phys_insert_body_locks = 0;
	fake_phys_insert_body_hash_shift = 0;
	fake_phys_insert_body_hash_mask = 0;
	fake_phys_insert_body_hash_head_stride = 0;
	fake_phys_insert_body_lock_stride = 0;
	fake_phys_insert_body_page_size = 0;
	fake_phys_insert_body_alloc_flag = 0;
	fake_phys_insert_body_lock_fn = NULL;
	fake_phys_insert_body_unlock_fn = NULL;
	fake_phys_insert_body_alloc_fn = NULL;
	fake_phys_insert_body_ret = NULL;
	fake_phys_insert_log_count = 0;
	fake_phys_insert_log_phys = 0;
}

static int fake_page_unmap_orchestrate(struct page *page,
				       unsigned long locks_addr,
				       int hash_shift, uint64_t hash_mask,
				       unsigned long lock_stride,
				       unsigned long (*lock_fn)(unsigned long),
				       void (*unlock_fn)(unsigned long,
							 unsigned long))
{
	fake_unmap_body_orchestrate_count++;
	fake_unmap_body_orchestrate_page = page;
	fake_unmap_body_orchestrate_locks = locks_addr;
	fake_unmap_body_orchestrate_hash_shift = hash_shift;
	fake_unmap_body_orchestrate_hash_mask = hash_mask;
	fake_unmap_body_orchestrate_lock_stride = lock_stride;
	fake_unmap_body_orchestrate_lock_fn = lock_fn;
	fake_unmap_body_orchestrate_unlock_fn = unlock_fn;
	if (page)
		page->count.counter -= 1;
	return fake_unmap_body_orchestrate_ret;
}

static void fake_page_unmap_log(int event, struct page *page, int ret)
{
	int index = fake_unmap_body_log_count;

	if (index < 4) {
		fake_unmap_body_log_event[index] = event;
		fake_unmap_body_log_page[index] = page;
		fake_unmap_body_log_ret[index] = ret;
	}
	fake_unmap_body_log_count++;
}

static void reset_fake_unmap_body(void)
{
	fake_unmap_body_orchestrate_count = 0;
	fake_unmap_body_orchestrate_page = NULL;
	fake_unmap_body_orchestrate_locks = 0;
	fake_unmap_body_orchestrate_hash_shift = 0;
	fake_unmap_body_orchestrate_hash_mask = 0;
	fake_unmap_body_orchestrate_lock_stride = 0;
	fake_unmap_body_orchestrate_lock_fn = NULL;
	fake_unmap_body_orchestrate_unlock_fn = NULL;
	fake_unmap_body_orchestrate_ret = 0;
	fake_unmap_body_log_count = 0;
	for (int i = 0; i < 4; i++) {
		fake_unmap_body_log_event[i] = 0;
		fake_unmap_body_log_page[i] = NULL;
		fake_unmap_body_log_ret[i] = 0;
	}
}

int main(void)
{
	static const uint8_t modes[] = {
		PM_NONE, PM_PENDING_FREE, PM_WILL_PAGEIO, PM_PAGEIO,
		PM_DONE_PAGEIO, PM_PAGEIO_EOF, PM_PAGEIO_ERROR, PM_MAPPED,
		0xff,
	};
	static const int counts[] = { 0, 1, 2, 7 };
	static const uint32_t flags[] = { 0, MF_REG_FILE, MF_SHM,
					  MF_REG_FILE | MF_SHM };
	unsigned long digest = 0x9a17c0de51ab1e5UL;

	if (sizeof(struct page) != 80 ||
	    offsetof(struct page, mode) != 32 ||
	    offsetof(struct page, phys) != 40 ||
	    offsetof(struct page, count) != 48 ||
	    offsetof(struct page, mapped) != 56 ||
	    offsetof(struct page, pgshift) != 72)
		exit(2);

	mix(&digest, page_to_phys(NULL));
	mix_signed(&digest, is_splitable(NULL, 0));
	mix_signed(&digest, is_splitable(NULL, MF_SHM));

	for (unsigned int i = 0; i < sizeof(modes) / sizeof(modes[0]); i++)
		mix_signed(&digest, page_mode_in_memobj_result(modes[i]));
	for (unsigned int i = 0; i < sizeof(counts) / sizeof(counts[0]); i++)
		mix_signed(&digest, page_multi_mapped_result(counts[i]));

	for (unsigned int i = 0; i < sizeof(modes) / sizeof(modes[0]); i++) {
		for (unsigned int j = 0; j < sizeof(counts) / sizeof(counts[0]); j++) {
			struct page page = make_page(modes[i], counts[j],
				0xabc000UL + (i << 12) + (j << 5));

			mix(&digest, page_to_phys(&page));
			mix_signed(&digest, page_is_in_memobj_body_result(&page));
			mix_signed(&digest, page_is_multi_mapped_body_result(&page));
			for (unsigned int k = 0; k < sizeof(flags) / sizeof(flags[0]); k++) {
				mix_signed(&digest, is_splitable(&page, flags[k]));
			}
		}
	}
	mix_signed(&digest, page_is_in_memobj_body_result(NULL));
	mix_signed(&digest, page_is_multi_mapped_body_result(NULL));
	{
		struct list_head hash_head = { &hash_head, &hash_head };
		struct page first = make_page(PM_MAPPED, 2, 0x400000);
		struct page second = make_page(PM_MAPPED, 1, 0x401000);

		list_add_tail(&first.hash, &hash_head);
		list_add_tail(&second.hash, &hash_head);
		page_map_count_inc_result(&first);
		mix_signed(&digest, first.count.counter);
		reset_fake_page_map_body();
		page_map_body_result(&first, fake_page_map_body_inc);
		mix_signed(&digest, fake_page_map_body_inc_count);
		mix(&digest, fake_page_map_body_inc_page == &first);
		mix_signed(&digest, first.count.counter);
		reset_fake_page_map_body();
		page_map_body_result(&first, NULL);
		mix_signed(&digest, fake_page_map_body_inc_count);
		mix_signed(&digest, first.count.counter);
		mix_signed(&digest, page_unmap_locked_result(&first));
		mix_signed(&digest, first.count.counter);
		mix(&digest, hash_head.next == &first.hash);
		mix(&digest, first.hash.next == &second.hash);
		mix_signed(&digest, page_unmap_locked_result(&first));
		mix_signed(&digest, first.count.counter);
		mix_signed(&digest, page_unmap_locked_result(&first));
		mix_signed(&digest, first.count.counter);
		mix(&digest, hash_head.next == &second.hash);
		mix(&digest, second.hash.prev == &hash_head);
		mix(&digest, first.hash.next == (void *)0x00100129);
		mix(&digest, first.hash.prev == (void *)0x00200229);
		mix_signed(&digest, page_unmap_locked_result(&second));
		mix_signed(&digest, second.count.counter);
		mix(&digest, hash_head.next == &hash_head);
		mix(&digest, hash_head.prev == &hash_head);
	}
	{
		struct list_head hash_head = { &hash_head, &hash_head };
		struct page existing = make_page(PM_MAPPED, 4, 0x500000);
		struct page inserted = make_page(PM_PAGEIO, 9, 0xdeadbeef);

		list_add_tail(&existing.hash, &hash_head);
		mix_signed(&digest, page_insert_hash_init_result(&inserted,
			&hash_head, 0x600000));
		mix(&digest, inserted.phys);
		mix_signed(&digest, inserted.mode);
		mix_signed(&digest, inserted.count.counter);
		mix(&digest, inserted.list.next == &inserted.list);
		mix(&digest, inserted.list.prev == &inserted.list);
		mix(&digest, hash_head.next == &inserted.hash);
		mix(&digest, inserted.hash.next == &existing.hash);
		mix(&digest, existing.hash.prev == &inserted.hash);
		mix_signed(&digest, page_insert_hash_init_result(NULL,
			&hash_head, 0x700000));
		mix_signed(&digest, page_insert_hash_init_result(&inserted,
			NULL, 0x700000));
		mix(&digest, page_hash_lookup_result(&hash_head, 0x600000) ==
			&inserted);
		mix(&digest, page_hash_lookup_result(&hash_head, 0x500000) ==
			&existing);
		mix(&digest, page_hash_lookup_result(&hash_head, 0x700000) ==
			NULL);
		mix(&digest, page_hash_lookup_result(NULL, 0x600000) == NULL);
		mix_signed(&digest, page_hash_count_bucket_result(&hash_head));
		mix_signed(&digest, page_hash_count_bucket_result(NULL));
		mix_signed(&digest, page_hash_bucket_init_result(&hash_head));
		mix(&digest, hash_head.next == &hash_head);
		mix(&digest, hash_head.prev == &hash_head);
		mix_signed(&digest, page_hash_bucket_init_result(NULL));
	}
	{
		struct list_head buckets[4];
		struct fake_lock locks[4] = {
			{ .id = 0 }, { .id = 1 }, { .id = 2 }, { .id = 3 },
		};
		struct page existing = make_page(PM_MAPPED, 3, 0x2000);
		struct page unmap_page = make_page(PM_MAPPED, 2, 0x3000);

		reset_fake_page_hash_tables_init();
		mix_signed(&digest, page_hash_tables_init_body_result(
			(unsigned long)buckets, (unsigned long)locks, 4,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock_init, fake_page_hash_bucket_init));
		mix_signed(&digest, fake_page_hash_lock_init_count);
		mix_signed(&digest, fake_page_hash_bucket_init_count);
		mix(&digest, fake_page_hash_lock_init_last ==
			(unsigned long)&locks[3]);
		mix(&digest, fake_page_hash_bucket_init_last ==
			(unsigned long)&buckets[3]);
		mix(&digest, buckets[0].next == &buckets[0]);
		mix(&digest, buckets[3].prev == &buckets[3]);
		mix(&digest, locks[3].last_flags);
		reset_fake_page_hash_tables_init();
		mix(&digest, page_hash_tables_init_body_result(
			(unsigned long)buckets, (unsigned long)locks, 4,
			sizeof(buckets[0]), sizeof(locks[0]),
			NULL, fake_page_hash_bucket_init) == -22);
		mix_signed(&digest, fake_page_hash_lock_init_count);
		mix_signed(&digest, fake_page_hash_bucket_init_count);
		list_add_tail(&existing.hash, &buckets[2]);
		list_add_tail(&unmap_page.hash, &buckets[3]);

		mix_signed(&digest, page_hash_count_all_result(
			(unsigned long)buckets, (unsigned long)locks, 4,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock));
		reset_fake_page_hash_count_all();
		fake_page_hash_count_all_ret = 17;
		mix_signed(&digest, page_hash_count_pages_body_result(
			(unsigned long)buckets, (unsigned long)locks, 4,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_hash_count_all));
		mix_signed(&digest, fake_page_hash_count_all_count);
		mix(&digest, fake_page_hash_count_all_hash_heads ==
			(unsigned long)buckets);
		mix(&digest, fake_page_hash_count_all_locks ==
			(unsigned long)locks);
		mix_signed(&digest, fake_page_hash_count_all_bucket_count);
		mix(&digest, fake_page_hash_count_all_hash_head_stride);
		mix(&digest, fake_page_hash_count_all_lock_stride);
		mix(&digest, fake_page_hash_count_all_lock_fn ==
			fake_page_hash_lock);
		mix(&digest, fake_page_hash_count_all_unlock_fn ==
			fake_page_hash_unlock);
		reset_fake_page_hash_count_all();
		mix(&digest, page_hash_count_pages_body_result(
			(unsigned long)buckets, (unsigned long)locks, 4,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock, NULL) == -22);
		mix_signed(&digest, fake_page_hash_count_all_count);
		for (unsigned int i = 0; i < 4; i++) {
			mix(&digest, locks[i].locks);
			mix(&digest, locks[i].unlocks);
			mix(&digest, locks[i].last_flags);
		}
		mix(&digest, phys_to_page_lookup_orchestrate_result(0x2000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock) == &existing);
		mix(&digest, phys_to_page_lookup_orchestrate_result(0x7000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock) == NULL);
		mix(&digest, locks[2].locks);
		mix(&digest, locks[3].locks);
		reset_fake_phys_body();
		fake_phys_lookup_body_ret = &existing;
		mix(&digest, phys_to_page_lookup_body_result(0x22000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock,
			fake_phys_lookup_body) == &existing);
		mix_signed(&digest, fake_phys_lookup_body_count);
		mix(&digest, fake_phys_lookup_body_phys);
		mix(&digest, fake_phys_lookup_body_hash_heads ==
			(unsigned long)buckets);
		mix(&digest, fake_phys_lookup_body_locks ==
			(unsigned long)locks);
		mix_signed(&digest, fake_phys_lookup_body_hash_shift);
		mix(&digest, fake_phys_lookup_body_hash_mask);
		mix(&digest, fake_phys_lookup_body_hash_head_stride);
		mix(&digest, fake_phys_lookup_body_lock_stride);
		mix(&digest, fake_phys_lookup_body_lock_fn ==
			fake_page_hash_lock);
		mix(&digest, fake_phys_lookup_body_unlock_fn ==
			fake_page_hash_unlock);
		reset_fake_phys_body();
		mix(&digest, phys_to_page_lookup_body_result(0x23000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock, NULL) == NULL);
		mix_signed(&digest, fake_phys_lookup_body_count);

		fake_alloc_next = 0;
		mix(&digest, phys_to_page_insert_hash_orchestrate_result(0x2000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			77, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc) == &existing);
		mix_signed(&digest, fake_alloc_next);
		mix(&digest, phys_to_page_insert_hash_orchestrate_result(0x5000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			77, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc) == &fake_alloc_pages[0]);
		mix(&digest, fake_alloc_size);
		mix_signed(&digest, fake_alloc_flag);
		mix(&digest, fake_alloc_pages[0].phys);
		mix_signed(&digest, fake_alloc_pages[0].mode);
		mix_signed(&digest, fake_alloc_pages[0].count.counter);
		mix(&digest, page_hash_lookup_result(&buckets[1], 0x5000) ==
			&fake_alloc_pages[0]);

		fake_alloc_next = 4;
		mix(&digest, phys_to_page_insert_hash_orchestrate_result(0x9000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			78, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc) == NULL);
		reset_fake_phys_body();
		fake_phys_insert_body_ret = &fake_alloc_pages[1];
		mix(&digest, phys_to_page_insert_hash_body_result(0x24000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			79, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc, fake_phys_insert_body,
			fake_phys_insert_log) == &fake_alloc_pages[1]);
		mix_signed(&digest, fake_phys_insert_body_count);
		mix(&digest, fake_phys_insert_body_phys);
		mix(&digest, fake_phys_insert_body_hash_heads ==
			(unsigned long)buckets);
		mix(&digest, fake_phys_insert_body_locks ==
			(unsigned long)locks);
		mix_signed(&digest, fake_phys_insert_body_hash_shift);
		mix(&digest, fake_phys_insert_body_hash_mask);
		mix(&digest, fake_phys_insert_body_hash_head_stride);
		mix(&digest, fake_phys_insert_body_lock_stride);
		mix(&digest, fake_phys_insert_body_page_size);
		mix_signed(&digest, fake_phys_insert_body_alloc_flag);
		mix(&digest, fake_phys_insert_body_lock_fn ==
			fake_page_hash_lock);
		mix(&digest, fake_phys_insert_body_unlock_fn ==
			fake_page_hash_unlock);
		mix(&digest, fake_phys_insert_body_alloc_fn == fake_page_alloc);
		mix_signed(&digest, fake_phys_insert_log_count);
		reset_fake_phys_body();
		mix(&digest, phys_to_page_insert_hash_body_result(0x25000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			80, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc, fake_phys_insert_body,
			fake_phys_insert_log) == NULL);
		mix_signed(&digest, fake_phys_insert_body_count);
		mix_signed(&digest, fake_phys_insert_log_count);
		mix(&digest, fake_phys_insert_log_phys);
		reset_fake_phys_body();
		mix(&digest, phys_to_page_insert_hash_body_result(0x26000,
			(unsigned long)buckets, (unsigned long)locks, 12, 3,
			sizeof(buckets[0]), sizeof(locks[0]), sizeof(struct page),
			81, fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_alloc, NULL, fake_phys_insert_log) == NULL);
		mix_signed(&digest, fake_phys_insert_body_count);
		mix_signed(&digest, fake_phys_insert_log_count);
		mix_signed(&digest, page_unmap_orchestrate_result(&unmap_page,
			(unsigned long)locks, 12, 3, sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock));
		mix_signed(&digest, unmap_page.count.counter);
		mix(&digest, buckets[3].next == &unmap_page.hash);
		reset_fake_unmap_body();
		unmap_page.count.counter = 4;
		fake_unmap_body_orchestrate_ret = 0;
		mix_signed(&digest, page_unmap_body_result(&unmap_page,
			(unsigned long)locks, 12, 3, sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_unmap_orchestrate, fake_page_unmap_log));
		mix_signed(&digest, fake_unmap_body_orchestrate_count);
		mix(&digest, fake_unmap_body_orchestrate_page == &unmap_page);
		mix(&digest, fake_unmap_body_orchestrate_locks ==
			(unsigned long)locks);
		mix_signed(&digest, fake_unmap_body_orchestrate_hash_shift);
		mix(&digest, fake_unmap_body_orchestrate_hash_mask);
		mix(&digest, fake_unmap_body_orchestrate_lock_stride);
		mix(&digest, fake_unmap_body_orchestrate_lock_fn ==
			fake_page_hash_lock);
		mix(&digest, fake_unmap_body_orchestrate_unlock_fn ==
			fake_page_hash_unlock);
		mix_signed(&digest, fake_unmap_body_log_count);
		mix_signed(&digest, fake_unmap_body_log_event[0]);
		mix_signed(&digest, fake_unmap_body_log_event[1]);
		mix(&digest, fake_unmap_body_log_page[0] == &unmap_page);
		mix_signed(&digest, fake_unmap_body_log_ret[1]);
		mix_signed(&digest, unmap_page.count.counter);
		reset_fake_unmap_body();
		unmap_page.count.counter = 1;
		fake_unmap_body_orchestrate_ret = 1;
		mix_signed(&digest, page_unmap_body_result(&unmap_page,
			(unsigned long)locks, 12, 3, sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_unmap_orchestrate, fake_page_unmap_log));
		mix_signed(&digest, fake_unmap_body_log_count);
		mix_signed(&digest, fake_unmap_body_log_event[0]);
		mix_signed(&digest, fake_unmap_body_log_event[1]);
		mix_signed(&digest, fake_unmap_body_log_ret[1]);
		mix_signed(&digest, unmap_page.count.counter);
		reset_fake_unmap_body();
		mix_signed(&digest, page_unmap_body_result(NULL,
			(unsigned long)locks, 12, 3, sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock,
			fake_page_unmap_orchestrate, fake_page_unmap_log));
		mix_signed(&digest, fake_unmap_body_orchestrate_count);
		mix_signed(&digest, fake_unmap_body_log_count);
		mix_signed(&digest, page_unmap_orchestrate_result(&unmap_page,
			(unsigned long)locks, 12, 3, sizeof(locks[0]),
			fake_page_hash_lock, fake_page_hash_unlock));
		mix_signed(&digest, unmap_page.count.counter);
		mix(&digest, buckets[3].next == &buckets[3]);
		mix(&digest, unmap_page.hash.next == (void *)0x00100129);
		mix_signed(&digest, page_hash_count_all_result(
			0, (unsigned long)locks, 4, sizeof(buckets[0]),
			sizeof(locks[0]), fake_page_hash_lock,
			fake_page_hash_unlock));
		mix(&digest, phys_to_page_lookup_orchestrate_result(0x2000,
			0, (unsigned long)locks, 12, 3, sizeof(buckets[0]),
			sizeof(locks[0]), fake_page_hash_lock,
			fake_page_hash_unlock) == NULL);
	}

	printf("page_helpers ok digest=%016lx\n", digest);
	return 0;
}
