#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define EINVAL 22

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

struct fake_atomic {
	int counter;
};

struct fake_kmsg_container {
	struct list_head list;
	int os_index;
	struct fake_atomic count;
	void *kmsg_buf;
	unsigned int order;
};

extern int ihk_core_delete_kmsg_buf_body_result(
	void *container,
	void (*free_pages_fn)(void *kmsg_buf, unsigned int order),
	void (*list_del_fn)(void *entry),
	void (*free_container_fn)(void *container),
	void (*log_fn)(int event, void *container, int value));
extern int ihk_core_release_kmsg_buf_body_result(
	void *container, int (*count_read_fn)(void *container),
	unsigned long (*lock_fn)(void),
	int (*count_dec_return_fn)(void *container),
	void (*delete_fn)(void *container),
	void (*unlock_fn)(unsigned long flags),
	void (*log_fn)(int event, void *container, int value));

static int free_pages_calls;
static void *free_pages_buf;
static unsigned int free_pages_order;
static int list_del_calls;
static void *list_del_entry;
static int free_container_calls;
static void *free_container_arg;
static int log_count;
static int log_events[8];
static int log_values[8];
static int lock_calls;
static int unlock_calls;
static unsigned long unlock_flags;
static int delete_calls;
static void *delete_arg;
static int sequence;
static int free_pages_seq;
static int log1_seq;
static int list_del_seq;
static int free_container_seq;
static int log2_seq;
static int lock_seq;
static int dec_seq;
static int delete_seq;
static int unlock_seq;

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) +
		(*digest >> 2);
}

static void reset_core_trace(void)
{
	free_pages_calls = 0;
	free_pages_buf = NULL;
	free_pages_order = 0;
	list_del_calls = 0;
	list_del_entry = NULL;
	free_container_calls = 0;
	free_container_arg = NULL;
	log_count = 0;
	for (int i = 0; i < 8; i++) {
		log_events[i] = 0;
		log_values[i] = 0;
	}
	lock_calls = 0;
	unlock_calls = 0;
	unlock_flags = 0;
	delete_calls = 0;
	delete_arg = NULL;
	sequence = 0;
	free_pages_seq = 0;
	log1_seq = 0;
	list_del_seq = 0;
	free_container_seq = 0;
	log2_seq = 0;
	lock_seq = 0;
	dec_seq = 0;
	delete_seq = 0;
	unlock_seq = 0;
}

static void fake_free_pages(void *kmsg_buf, unsigned int order)
{
	free_pages_calls++;
	free_pages_buf = kmsg_buf;
	free_pages_order = order;
	free_pages_seq = ++sequence;
}

static void fake_list_del(void *entry)
{
	list_del_calls++;
	list_del_entry = entry;
	list_del_seq = ++sequence;
}

static void fake_free_container(void *container)
{
	free_container_calls++;
	free_container_arg = container;
	free_container_seq = ++sequence;
}

static void fake_log(int event, void *container, int value)
{
	(void)container;
	if (log_count < 8) {
		log_events[log_count] = event;
		log_values[log_count] = value;
	}
	log_count++;
	if (event == 1)
		log1_seq = ++sequence;
	else if (event == 2)
		log2_seq = ++sequence;
	else
		sequence++;
}

static int fake_count_read(void *container)
{
	return ((struct fake_kmsg_container *)container)->count.counter;
}

static unsigned long fake_lock(void)
{
	lock_calls++;
	lock_seq = ++sequence;
	return 0x55667788UL;
}

static int fake_count_dec_return(void *container)
{
	struct fake_kmsg_container *cont = container;

	cont->count.counter--;
	dec_seq = ++sequence;
	return cont->count.counter;
}

static void fake_delete(void *container)
{
	delete_calls++;
	delete_arg = container;
	delete_seq = ++sequence;
}

static void fake_unlock(unsigned long flags)
{
	unlock_calls++;
	unlock_flags = flags;
	unlock_seq = ++sequence;
}

int main(void)
{
	struct fake_kmsg_container cont = { 0 };
	unsigned long digest = 0x69686b636f7265UL;
	char kmsg[16];

	cont.kmsg_buf = kmsg;
	cont.order = 3;
	reset_core_trace();
	require(ihk_core_delete_kmsg_buf_body_result(&cont,
			fake_free_pages, fake_list_del, fake_free_container,
			fake_log) == 1);
	require(free_pages_calls == 1 && free_pages_buf == kmsg);
	require(free_pages_order == 3);
	require(list_del_calls == 1 && list_del_entry == &cont.list);
	require(free_container_calls == 1 && free_container_arg == &cont);
	require(log_count == 2 && log_events[0] == 1 && log_events[1] == 2);
	require(free_pages_seq < log1_seq && log1_seq < list_del_seq);
	require(list_del_seq < free_container_seq && free_container_seq < log2_seq);
	mix(&digest, free_pages_order);
	mix(&digest, (unsigned long)log_count);

	reset_core_trace();
	require(ihk_core_delete_kmsg_buf_body_result(NULL,
			fake_free_pages, fake_list_del, fake_free_container,
			fake_log) == 0);
	require(free_pages_calls == 0 && log_count == 0);

	cont.count.counter = 2;
	reset_core_trace();
	require(ihk_core_release_kmsg_buf_body_result(&cont,
			fake_count_read, fake_lock, fake_count_dec_return,
			fake_delete, fake_unlock, fake_log) == 0);
	require(cont.count.counter == 1);
	require(lock_calls == 1 && unlock_calls == 1);
	require(delete_calls == 0);
	require(lock_seq < dec_seq && dec_seq < unlock_seq);
	require(unlock_flags == 0x55667788UL);
	mix(&digest, (unsigned long)cont.count.counter);

	cont.count.counter = 1;
	reset_core_trace();
	require(ihk_core_release_kmsg_buf_body_result(&cont,
			fake_count_read, fake_lock, fake_count_dec_return,
			fake_delete, fake_unlock, fake_log) == 0);
	require(cont.count.counter == 0);
	require(delete_calls == 1 && delete_arg == &cont);
	require(lock_seq < dec_seq && dec_seq < delete_seq);
	require(delete_seq < unlock_seq);
	mix(&digest, (unsigned long)delete_calls);

	cont.count.counter = 0;
	reset_core_trace();
	require(ihk_core_release_kmsg_buf_body_result(&cont,
			fake_count_read, fake_lock, fake_count_dec_return,
			fake_delete, fake_unlock, fake_log) == -EINVAL);
	require(lock_calls == 0 && delete_calls == 0);
	require(log_count == 1 && log_events[0] == 3 &&
		log_values[0] == -EINVAL);
	mix(&digest, (unsigned long)log_events[0]);

	require(ihk_core_release_kmsg_buf_body_result(NULL,
			fake_count_read, fake_lock, fake_count_dec_return,
			fake_delete, fake_unlock, fake_log) == -EINVAL);
	require(ihk_core_release_kmsg_buf_body_result(&cont,
			NULL, fake_lock, fake_count_dec_return, fake_delete,
			fake_unlock, fake_log) == -EINVAL);
	require(ihk_core_delete_kmsg_buf_body_result(&cont,
			NULL, fake_list_del, fake_free_container,
			fake_log) == -EINVAL);

	printf("ihk_core_helpers ok digest=%016lx\n", digest);
	return 0;
}
