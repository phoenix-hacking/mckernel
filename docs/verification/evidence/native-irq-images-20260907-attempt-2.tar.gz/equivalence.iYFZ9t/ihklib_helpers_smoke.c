#include <limits.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

struct ihkconfig_dispatch_ops {
	int (*get)(int);
	int (*reserve)(int);
	int (*create)(int);
	int (*destroy)(int);
	int (*scratch)(int);
	int (*sbox)(int);
	int (*read)(int);
	int (*mmap)(int);
	int (*ioctl)(int);
	int (*clear_kmsg)(int);
	int (*clear_kmsg_write)(int);
	int (*reserve_mem_max_ratio)(int);
	int (*release)(int);
	int (*query)(int);
};

struct ihkosctl_dispatch_ops {
	int (*get)(int);
	int (*dump)(int);
	int (*kmsg)(int);
	int (*load)(int);
	int (*boot)(int);
	int (*shutdown)(int);
	int (*alloc)(int);
	int (*reserve_cpu)(int);
	int (*reserve_mem)(int);
	int (*assign)(int);
	int (*release)(int);
	int (*set)(int);
	int (*query)(int);
	int (*query_free_mem)(int);
	int (*kargs)(int);
	int (*clear_kmsg)(int);
	int (*intr)(int);
	int (*ioctl)(int);
};

struct ihk_mem_chunk {
	unsigned long size;
	int numa_node_number;
};

struct ihk_mem_req {
	unsigned long *sizes;
	int *numa_ids;
	int num_chunks;
	int min_chunk_size;
	int max_size_ratio_all;
	int timeout;
};

struct ihk_cpu_req {
	int *cpus;
	int num_cpus;
};

struct ihk_ikc_cpu_map {
	int src_cpu;
	int dst_cpu;
};

struct ihk_os_ioctl_eventfd_desc {
	int fd;
	int type;
};

struct mcctrl_ioctl_getrusage_desc {
	void *rusage;
	size_t size_rusage;
};

extern int ihkconfig_action_result(const char *action);
extern int ihkosctl_action_result(const char *action);
extern int ihkconfig_dispatch_action_result(int action, int index, int fd,
		const struct ihkconfig_dispatch_ops *ops, int *fd_closed);
extern int ihkosctl_dispatch_action_result(int action, int index, int fd,
		const struct ihkosctl_dispatch_ops *ops, int *fd_closed);
extern int ihkmond_facility_index_result(const char *name);
extern int ihkmond_udev_action_result(const char *action);
extern int ihkmond_mcos_path_result(char *path, int os_index);
extern int ihkmond_tmp_dir_result(char *path);
extern int ihkmond_tmp_mcos_dir_result(char *path, int os_index);
extern int ihkmond_tmp_kmsg_path_result(char *path, int os_index, int slot);
extern int ihkmond_filebuf_rotate_needed_result(int current_size,
		ssize_t nread, size_t slot_size);
extern int ihkmond_next_slot_result(int slot, int slots);
extern int ihkmond_cons_start_result(int prod, int all_full, int slots);
extern int ihkmond_create_wait_timeout_result(int iteration, int limit);
extern int ihkmond_notify_targets_result(int action, int monitor_interval,
		int enable_kmsg, int *notify_monitor, int *notify_kmsg);
extern int ihklib_kargs_validate_result(const char *kargs,
		unsigned long max_size);
extern int ihklib_os_status_public_result(int raw_status);
extern int ihklib_os_boot_status_action_result(int raw_status);
extern int ihklib_eventfd_type_valid_result(int type);
extern int ihklib_perfctl_ioctl_cmd_result(int comm,
		unsigned long enable_cmd, unsigned long disable_cmd,
		unsigned long destroy_cmd, unsigned long *cmd_out);
extern int ihklib_cpu_request_validate_result(const int *cpus,
		int num_cpus, int max_cpus, int zero_mode,
		int null_policy, int null_errno);
extern int ihklib_mem_request_validate_result(
		const struct ihk_mem_chunk *chunks, int num_chunks,
		int max_chunks, int zero_mode, int null_policy,
		int null_errno);
extern int ihklib_ikc_map_validate_result(const void *map, int num_cpus,
		int max_cpus);
extern int ihklib_pagesizes_validate_result(const long *pgsizes,
		int num_pgsizes, int expected_pgsizes);
extern int ihklib_os_get_num_pagesizes_body_result(int index,
		int max_pgsizes, int (*open_fn)(int), int (*close_fn)(int),
		int *open_ret_out);
extern int ihklib_os_get_pagesizes_body_result(int index, long *pgsizes,
		int num_pgsizes, int expected_pgsizes, int (*open_fn)(int),
		int (*close_fn)(int), int *open_ret_out);
extern int ihklib_os_ioctl_noarg_body_result(int index,
		unsigned long request, int fail_only_negative,
		int (*open_fn)(int), int (*ioctl_fn)(int, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_get_num_cpus_raw_body_result(int index,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long), int (*close_fn)(int),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_mem_chunk_count_body_result(int index,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out, int *chunks_out);
extern int ihklib_os_get_kmsg_size_body_result(int index, int kmsg_size,
		int (*open_fn)(int), int (*close_fn)(int),
		int *open_ret_out);
extern int ihklib_os_kmsg_body_result(int index, char *kmsg,
		ssize_t sz_kmsg, ssize_t expected_size,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_get_status_body_result(int index,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long), int (*close_fn)(int),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_setperfevent_body_result(int index, void *attr, int n,
		unsigned long num_request, unsigned long set_request,
		int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *num_ret_out, int *set_ret_out);
extern int ihklib_os_getperfevent_body_result(int index,
		unsigned long *counter, int n, unsigned long get_request,
		int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_perfctl_body_result(int index, int comm,
		unsigned long enable_cmd, unsigned long disable_cmd,
		unsigned long destroy_cmd, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long), int (*close_fn)(int),
		int (*errno_fn)(void), int *open_ret_out,
		int *ioctl_ret_out);
extern int ihklib_os_get_eventfd_body_result(int index, int type,
		unsigned long register_request, int (*open_fn)(int),
		int (*eventfd_fn)(unsigned int, int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *eventfd_ret_out,
		int *ioctl_ret_out);
extern int ihklib_os_load_body_result(int index, char *filename,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_kargs_body_result(int index, char *kargs,
		unsigned long max_size, unsigned long request,
		int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_boot_body_result(int index, unsigned long boot_request,
		unsigned long status_request, int max_polls,
		unsigned int sleep_usec, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long), int (*close_fn)(int),
		int (*errno_fn)(void), int (*sleep_fn)(unsigned int),
		int *open_ret_out, int *boot_ret_out,
		int *status_ret_out, int *polls_out);
extern int ihklib_meminfo_line_value_result(const char *line,
		const char *type, unsigned long *value_kb);
extern int ihklib_mem_chunks_publish_result(unsigned long *result,
		int num_numa_nodes, const struct ihk_mem_chunk *chunks,
		int num_chunks);
extern int ihklib_device_readable_body_result(int index, int os_device,
		int (*access_fn)(const char *), int (*errno_fn)(void));
extern int ihklib_device_open_body_result(int index, int os_device,
		int (*access_fn)(const char *), int (*open_fn)(const char *),
		int (*errno_fn)(void));
extern int ihklib_mem_req_fill_result(unsigned long *sizes, int *numa_ids,
		const struct ihk_mem_chunk *chunks, int num_chunks,
		int use_all_size, unsigned long *total_out);
extern int ihklib_cpu_req_bind_result(int **req_cpus_out,
		int *req_num_cpus_out, int *cpus, int num_cpus);
extern int ihklib_os_cpu_request_body_result(int index, int *cpus,
		int num_cpus, unsigned long request, int max_cpus,
		int (*readable_fn)(int), int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *readable_ret_out, int *validate_ret_out,
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_os_query_cpu_body_result(int index, int *cpus,
		int num_cpus, unsigned long count_request,
		unsigned long query_request, int max_cpus,
		int (*readable_fn)(int), int (*open_fn)(int),
		int (*count_ioctl_fn)(int, unsigned long),
		int (*query_ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *readable_ret_out, int *validate_ret_out,
		int *open_ret_out, int *count_ret_out,
		int *query_ret_out);
extern int ihklib_os_mem_request_body_result(int index,
		struct ihk_mem_chunk *mem_chunks, int num_mem_chunks,
		unsigned long request, int max_chunks,
		int (*readable_fn)(int), int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *readable_ret_out, int *validate_ret_out,
		int *stage_out, int *open_ret_out,
		int *ioctl_ret_out);
extern int ihklib_os_query_mem_body_result(int index,
		struct ihk_mem_chunk *mem_chunks, int num_mem_chunks,
		unsigned long count_request, unsigned long query_request,
		int max_chunks, int (*readable_fn)(int),
		int (*count_fn)(int), int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *readable_ret_out, int *validate_ret_out,
		int *count_ret_out, int *stage_out, int *open_ret_out,
		int *ioctl_ret_out, int *publish_ret_out);
extern int ihklib_os_release_mem_body_result(int index,
		struct ihk_mem_chunk *mem_chunks, int num_mem_chunks,
		unsigned long release_request, int max_chunks,
		int (*readable_fn)(int), int (*count_fn)(int),
		int (*query_fn)(int, struct ihk_mem_chunk *, int),
		int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *readable_ret_out, int *validate_ret_out,
		int *count_ret_out, int *query_ret_out, int *stage_out,
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_cpu_string_dispatch_body_result(int index,
		char *list, int (*dispatch_fn)(int, int *, int));
extern int ihklib_mem_string_dispatch_body_result(int index,
		char *list,
		int (*dispatch_fn)(int, struct ihk_mem_chunk *, int));
extern int ihklib_ikc_string_dispatch_body_result(int index,
		char *list,
		int (*dispatch_fn)(int, struct ihk_ikc_cpu_map *, int));
extern int ihklib_env_value_callback_body_result(int index,
		const char *envp, int num_env, const char *key,
		int (*callback_fn)(int, char *, char *), char *err_msg);
extern int ihklib_reserve_mem_conf_str_body_result(int dev_index,
		const char *envp, int num_env,
		int (*reserve_mem_conf_fn)(int, int, void *));
extern int ihklib_os_kargs_str_body_result(int os_index,
		const char *envp, int num_env, char *default_kargs,
		int (*kargs_fn)(int, char *));
extern int ihklib_os_assign_cpu_all_body_result(int index, int *stage_out,
		int (*get_count_fn)(int), int (*query_fn)(int, int *, int),
		int (*assign_fn)(int, int *, int));
extern int ihklib_os_assign_mem_all_body_result(int index, int *stage_out,
		int (*get_count_fn)(int),
		int (*query_fn)(int, struct ihk_mem_chunk *, int),
		int (*assign_fn)(int, struct ihk_mem_chunk *, int));
extern int ihklib_os_release_cpu_all_body_result(int index,
		int (*get_count_fn)(int), int (*query_fn)(int, int *, int),
		int (*release_fn)(int, int *, int));
extern int ihklib_release_cpu_all_body_result(int index, int *stage_out,
		int (*get_count_fn)(int), int (*query_fn)(int, int *, int),
		int (*release_fn)(int, int *, int));
extern int ihklib_count_match_result(int actual, int requested);
extern int ihklib_positive_count_or_result(int count,
		int nonpositive_result);
extern int ihklib_required_count_result(int count, int zero_result);
extern int ihklib_argc_at_least_result(int argc, int min_argc,
		int fail_result);
extern int ihklib_argc_greater_than_result(int argc, int threshold);
extern int ihklib_positive_count_action_result(int count);
extern int ihklib_load_file_validate_result(const void *filename);
extern int ihklib_kmsg_validate_result(const void *kmsg, ssize_t size,
		ssize_t expected_size);
extern int ihklib_rusage_validate_result(const void *rusage,
		size_t size, size_t expected_size);
extern int ihklib_os_getrusage_body_result(int index, void *rusage,
		size_t size_rusage, size_t expected_size,
		unsigned long request, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out);
extern int ihklib_perf_attr_validate_result(const void *attr);
extern int ihklib_perf_event_count_validate_result(int count);
extern int ihklib_mcos_name_index_result(const char *name, int *index_out);
extern int ihklib_destroy_os_retry_result(int ioctl_ret, int errno_value,
		int ebusy_errno, int *ret_out);
extern int ihklib_destroy_os_body_result(int dev_index, int os_index,
		unsigned long request, int ebusy_errno, int max_retries,
		unsigned int retry_usec, int (*open_fn)(int),
		int (*ioctl_fn)(int, unsigned long, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int (*sleep_fn)(unsigned int), int *open_ret_out,
		int *ioctl_ret_out, int *attempts_out);
extern int ihklib_os_boot_final_result(int raw_status);
extern int ihklib_mem_chunks_from_req_result(struct ihk_mem_chunk *chunks,
		const unsigned long *sizes, const int *numa_ids,
		int num_chunks);
extern int ihklib_ikc_req_fill_result(int *src_cpus, int *dst_cpus,
		const struct ihk_ikc_cpu_map *map, int num_cpus);
extern int ihklib_ikc_map_from_req_result(struct ihk_ikc_cpu_map *map,
		const int *src_cpus, const int *dst_cpus, int num_cpus);
extern int ihklib_os_set_next_result(const unsigned long *os_set,
		int n, int start);
extern int ihklib_os_set_ioctl_loop_body_result(
		const unsigned long *os_set, int n, unsigned long request,
		int (*open_fn)(int), int (*ioctl_fn)(int, unsigned long),
		int (*close_fn)(int), int (*errno_fn)(void),
		int *open_ret_out, int *ioctl_ret_out, int *processed_out,
		int *failed_index_out);
extern int ihklib_create_os_apply_mem_conf_body_result(char **name,
		char **value, int num_env, int dev_index,
		int (*reserve_mem_conf_fn)(int, int, void *));
extern int ihklib_create_os_reserve_resources_body_result(char **name,
		char **value, int num_env, int dev_index, char *err_msg,
		int (*reserve_cpu_fn)(int, char *, char *),
		int (*reserve_mem_fn)(int, char *, char *));
extern int ihklib_create_os_apply_ikc_kargs_body_result(char **name,
		char **value, int num_env, int os_index, char *default_kargs,
		char **kargs_out, char *err_msg,
		int (*set_ikc_map_fn)(int, char *, char *));
extern int ihklib_create_os_preclean_body_result(int dev_index,
		struct ihk_mem_chunk *mem_chunks, char *err_msg,
		int *stage_out, int (*get_cpu_count_fn)(int),
		int (*release_cpu_all_fn)(int, char *),
		int (*get_mem_count_fn)(int),
		int (*release_mem_fn)(int, struct ihk_mem_chunk *, int));
extern int ihklib_create_os_load_kargs_body_result(int os_index,
		char *kernel_image, char *kargs, int *stage_out,
		int (*load_fn)(int, char *), int (*kargs_fn)(int, char *));
extern int ihkconfig_usage_result(char *buf, size_t buf_size,
		const char *program);
extern int ihkosctl_usage_result(char *buf, size_t buf_size,
		const char *program, int include_dump);

enum {
	IHK_OS_STATUS_NOT_BOOTED = 0,
	IHK_OS_STATUS_LOADING = 1,
	IHK_OS_STATUS_BOOTING = 2,
	IHK_OS_STATUS_BOOTED = 3,
	IHK_OS_STATUS_READY = 4,
	IHK_OS_STATUS_RUNNING = 5,
	IHK_OS_STATUS_FREEZING = 6,
	IHK_OS_STATUS_FROZEN = 7,
	IHK_OS_STATUS_SHUTDOWN = 8,
	IHK_OS_STATUS_FAILED = 9,
	IHK_OS_STATUS_HUNGUP = 10,
	IHK_STATUS_INACTIVE = 0,
	IHK_STATUS_BOOTING = 1,
	IHK_STATUS_RUNNING = 2,
	IHK_STATUS_SHUTDOWN = 3,
	IHK_STATUS_PANIC = 4,
	IHK_STATUS_HUNGUP = 5,
	IHK_STATUS_FREEZING = 6,
	IHK_STATUS_FROZEN = 7,
	IHK_OS_EVENTFD_TYPE_OOM = 0,
	IHK_OS_EVENTFD_TYPE_STATUS = 2,
	IHK_OS_EVENTFD_TYPE_KMSG = 101,
	PERF_EVENT_ENABLE = 0,
	PERF_EVENT_DISABLE = 1,
	PERF_EVENT_DESTROY = 2,
	IHKLIB_VALIDATE_ZERO_CONTINUE = 0,
	IHKLIB_VALIDATE_ZERO_NOOP = 1,
	IHKLIB_VALIDATE_NULL_ONLY_NONZERO = 0,
	IHKLIB_VALIDATE_NULL_ALWAYS = 1,
	IHKLIB_ALL_STAGE_COUNT = 1,
	IHKLIB_ALL_STAGE_QUERY = 2,
	IHKLIB_ALL_STAGE_ACTION = 3,
	IHKLIB_ALL_STAGE_EMPTY = 4,
	IHKLIB_CREATE_STAGE_GET_CPUS = 1,
	IHKLIB_CREATE_STAGE_RELEASE_CPUS = 2,
	IHKLIB_CREATE_STAGE_GET_MEM = 3,
	IHKLIB_CREATE_STAGE_RELEASE_MEM = 4,
	IHKLIB_CREATE_STAGE_LOAD = 5,
	IHKLIB_CREATE_STAGE_KARGS = 6,
	IHK_RESERVE_MEM_TIMEOUT = 5,
};

static int last_index;
static int last_fd;
static int last_closed_fd;
static int fake_open_ret = 77;
static int fake_open_calls;
static int fake_open_index_trace[16];
static int fake_open_index_count;
static int fake_close_calls;
static int fake_callback_index;
static int fake_ioctl_ret;
static int fake_ioctl_calls;
static int fake_errno_value = EIO;
static int fake_errno_calls;
static unsigned long fake_ioctl_request;
static unsigned long fake_ioctl_arg;
static int fake_ioctl_count_override = INT_MIN;
static int fake_ioctl_num_ret;
static int fake_ioctl_set_ret;
static int fake_cpu_req_num;
static int fake_cpu_req_first;
static int fake_cpu_req_second;
static int fake_mem_req_num;
static unsigned long fake_mem_req_first_size;
static unsigned long fake_mem_req_second_size;
static int fake_mem_req_first_numa;
static int fake_mem_req_second_numa;
static int fake_eventfd_ret = 120;
static int fake_eventfd_calls;
static unsigned int fake_eventfd_initval;
static int fake_eventfd_flags;
static int fake_eventfd_desc_fd;
static int fake_eventfd_desc_type;
static void *fake_rusage_desc_ptr;
static size_t fake_rusage_desc_size;
static int fake_sleep_calls;
static unsigned int fake_sleep_usec;
static int fake_access_ret;
static int fake_access_calls;
static int fake_readable_ret;
static int fake_readable_calls;
static int fake_readable_index;
static int fake_open_path_ret = 160;
static int fake_open_path_calls;
static char fake_last_path[128];
static int fake_status_seq[64];
static int fake_status_len;
static int fake_status_pos;
static int fake_ioctl_ulong_seq[64];
static int fake_ioctl_ulong_len;
static int fake_ioctl_ulong_pos;
static int fake_errno_seq[64];
static int fake_errno_len;
static int fake_errno_pos;
static int fake_query_mem_chunks = 7;
static int fake_create_os_ret;
static int fake_create_os_mem_conf_calls;
static int fake_create_os_mem_conf_index;
static int fake_create_os_mem_conf_key;
static int fake_create_os_mem_conf_value;
static int fake_create_os_cpu_calls;
static int fake_create_os_mem_calls;
static int fake_create_os_ikc_calls;
static int fake_create_os_last_index;
static char *fake_create_os_cpu_list;
static char *fake_create_os_mem_list;
static char *fake_create_os_ikc_list;
static char *fake_create_os_last_err;
static char fake_create_os_order[16];
static int fake_create_os_order_len;
static int fake_dispatch_calls;
static int fake_dispatch_index;
static int fake_dispatch_count;
static int fake_dispatch_cpus[8];
static struct ihk_mem_chunk fake_dispatch_chunks[8];
static struct ihk_ikc_cpu_map fake_dispatch_maps[8];
static char *fake_dispatch_kargs;
static char *fake_dispatch_err;
static char fake_dispatch_string[128];
static int fake_dispatch_ret;
static int fake_all_count_ret;
static int fake_all_mem_count_ret;
static int fake_all_query_ret;
static int fake_all_action_ret;
static int fake_all_count_calls;
static int fake_all_mem_count_calls;
static int fake_all_query_calls;
static int fake_all_action_calls;
static int fake_all_count_index;
static int fake_all_mem_count_index;
static int fake_all_query_index;
static int fake_all_action_index;
static int fake_all_query_count;
static int fake_all_action_count;
static char *fake_all_err;
static int fake_all_cpus[8];
static struct ihk_mem_chunk fake_all_chunks[8];
static int fake_char_load_ret;
static int fake_char_kargs_ret;
static int fake_char_load_calls;
static int fake_char_kargs_calls;
static int fake_char_load_index;
static int fake_char_kargs_index;
static char *fake_char_load_arg;
static char *fake_char_kargs_arg;

int close(int fd)
{
	last_closed_fd = fd;
	return 0;
}

static int fake_open_callback(int index)
{
	if (fake_open_index_count < (int)(sizeof(fake_open_index_trace) /
			sizeof(fake_open_index_trace[0])))
		fake_open_index_trace[fake_open_index_count] = index;
	fake_open_index_count++;
	fake_open_calls++;
	fake_callback_index = index;
	return fake_open_ret;
}

static int fake_close_callback(int fd)
{
	fake_close_calls++;
	last_closed_fd = fd;
	return 0;
}

static int fake_ioctl_noarg_callback(int fd, unsigned long request)
{
	fake_ioctl_calls++;
	last_fd = fd;
	fake_ioctl_request = request;
	if (request == 0x112a38 && fake_ioctl_count_override != INT_MIN)
		return fake_ioctl_count_override;
	if (request == 0x112a14 && fake_status_len > 0) {
		int idx = fake_status_pos;

		if (idx >= fake_status_len)
			idx = fake_status_len - 1;
		fake_status_pos++;
		return fake_status_seq[idx];
	}
	return fake_ioctl_ret;
}

static int fake_ioctl_ulong_callback(int fd, unsigned long request,
		unsigned long arg)
{
	fake_ioctl_calls++;
	last_fd = fd;
	fake_ioctl_request = request;
	fake_ioctl_arg = arg;
	if (request == 0x11290100)
		return fake_ioctl_num_ret;
	if (request == 0x11290101)
		return fake_ioctl_set_ret;
	if (request == 0x11290106) {
		struct mcctrl_ioctl_getrusage_desc *desc;

		desc = (struct mcctrl_ioctl_getrusage_desc *)arg;
		fake_rusage_desc_ptr = desc->rusage;
		fake_rusage_desc_size = desc->size_rusage;
	}
	if (request == 0x112a15) {
		struct ihk_os_ioctl_eventfd_desc *desc;

		desc = (struct ihk_os_ioctl_eventfd_desc *)arg;
		fake_eventfd_desc_fd = desc->fd;
		fake_eventfd_desc_type = desc->type;
	}
	if (request == 0x112a22 || request == 0x112a23 ||
			request == 0x112a26) {
		struct ihk_cpu_req *req;

		req = (struct ihk_cpu_req *)arg;
		fake_cpu_req_num = req->num_cpus;
		fake_cpu_req_first = req->num_cpus > 0 ? req->cpus[0] : -1;
		fake_cpu_req_second = req->num_cpus > 1 ? req->cpus[1] : -1;
	}
	if (request == 0x112a24 || request == 0x112a25) {
		struct ihk_mem_req *req;

		req = (struct ihk_mem_req *)arg;
		fake_mem_req_num = req->num_chunks;
		fake_mem_req_first_size =
			req->num_chunks > 0 ? req->sizes[0] : 0;
		fake_mem_req_second_size =
			req->num_chunks > 1 ? req->sizes[1] : 0;
		fake_mem_req_first_numa =
			req->num_chunks > 0 ? req->numa_ids[0] : -1;
		fake_mem_req_second_numa =
			req->num_chunks > 1 ? req->numa_ids[1] : -1;
	}
	if (request == 0x112901 && fake_ioctl_ulong_len > 0) {
		int idx = fake_ioctl_ulong_pos;

		if (idx >= fake_ioctl_ulong_len)
			idx = fake_ioctl_ulong_len - 1;
		fake_ioctl_ulong_pos++;
		return fake_ioctl_ulong_seq[idx];
	}
	if (request == 0x112907 || request == 0x112a27) {
		struct ihk_mem_req *req;

		req = (struct ihk_mem_req *)arg;
		req->num_chunks = fake_query_mem_chunks;
		if (req->sizes && req->numa_ids && req->num_chunks > 0) {
			req->sizes[0] = 16384;
			req->numa_ids[0] = 2;
		}
		if (req->sizes && req->numa_ids && req->num_chunks > 1) {
			req->sizes[1] = 32768;
			req->numa_ids[1] = 3;
		}
	}
	return fake_ioctl_ret;
}

static int fake_eventfd_callback(unsigned int initval, int flags)
{
	fake_eventfd_calls++;
	fake_eventfd_initval = initval;
	fake_eventfd_flags = flags;
	return fake_eventfd_ret;
}

static int fake_sleep_callback(unsigned int usec)
{
	fake_sleep_calls++;
	fake_sleep_usec = usec;
	return 0;
}

static int fake_access_callback(const char *path)
{
	fake_access_calls++;
	strncpy(fake_last_path, path, sizeof(fake_last_path) - 1);
	fake_last_path[sizeof(fake_last_path) - 1] = '\0';
	return fake_access_ret;
}

static int fake_open_path_callback(const char *path)
{
	fake_open_path_calls++;
	strncpy(fake_last_path, path, sizeof(fake_last_path) - 1);
	fake_last_path[sizeof(fake_last_path) - 1] = '\0';
	return fake_open_path_ret;
}

static int fake_readable_callback(int index)
{
	fake_readable_calls++;
	fake_readable_index = index;
	return fake_readable_ret;
}

static int fake_errno_callback(void)
{
	if (fake_errno_len > 0) {
		int idx = fake_errno_pos;

		if (idx >= fake_errno_len)
			idx = fake_errno_len - 1;
		fake_errno_pos++;
		fake_errno_calls++;
		return fake_errno_seq[idx];
	}
	fake_errno_calls++;
	return fake_errno_value;
}

static int fake_index_handler(int index)
{
	last_index = index;
	return index + 1000;
}

static int fake_fd_handler(int fd)
{
	last_fd = fd;
	return fd + 2000;
}

static void fake_create_os_reset(void)
{
	fake_create_os_ret = 0;
	fake_create_os_mem_conf_calls = 0;
	fake_create_os_mem_conf_index = -1;
	fake_create_os_mem_conf_key = -1;
	fake_create_os_mem_conf_value = -1;
	fake_create_os_cpu_calls = 0;
	fake_create_os_mem_calls = 0;
	fake_create_os_ikc_calls = 0;
	fake_create_os_last_index = -1;
	fake_create_os_cpu_list = NULL;
	fake_create_os_mem_list = NULL;
	fake_create_os_ikc_list = NULL;
	fake_create_os_last_err = NULL;
	memset(fake_create_os_order, 0, sizeof(fake_create_os_order));
	fake_create_os_order_len = 0;
}

static void fake_create_os_note(char code)
{
	if (fake_create_os_order_len < (int)sizeof(fake_create_os_order) - 1) {
		fake_create_os_order[fake_create_os_order_len++] = code;
		fake_create_os_order[fake_create_os_order_len] = '\0';
	}
}

static int fake_create_os_mem_conf_callback(int index, int key, void *value)
{
	fake_create_os_note('c');
	fake_create_os_mem_conf_calls++;
	fake_create_os_mem_conf_index = index;
	fake_create_os_mem_conf_key = key;
	fake_create_os_mem_conf_value = *(int *)value;
	return fake_create_os_ret;
}

static int fake_create_os_cpu_callback(int index, char *list, char *err_msg)
{
	fake_create_os_note('C');
	fake_create_os_cpu_calls++;
	fake_create_os_last_index = index;
	fake_create_os_cpu_list = list;
	fake_create_os_last_err = err_msg;
	return fake_create_os_ret;
}

static int fake_create_os_mem_callback(int index, char *list, char *err_msg)
{
	fake_create_os_note('M');
	fake_create_os_mem_calls++;
	fake_create_os_last_index = index;
	fake_create_os_mem_list = list;
	fake_create_os_last_err = err_msg;
	return fake_create_os_ret;
}

static int fake_create_os_ikc_callback(int index, char *list, char *err_msg)
{
	fake_create_os_note('I');
	fake_create_os_ikc_calls++;
	fake_create_os_last_index = index;
	fake_create_os_ikc_list = list;
	fake_create_os_last_err = err_msg;
	return fake_create_os_ret;
}

static void fake_dispatch_reset(void)
{
	fake_dispatch_calls = 0;
	fake_dispatch_index = -1;
	fake_dispatch_count = -1;
	fake_dispatch_kargs = NULL;
	fake_dispatch_err = NULL;
	fake_dispatch_ret = 0;
	memset(fake_dispatch_cpus, 0, sizeof(fake_dispatch_cpus));
	memset(fake_dispatch_chunks, 0, sizeof(fake_dispatch_chunks));
	memset(fake_dispatch_maps, 0, sizeof(fake_dispatch_maps));
	memset(fake_dispatch_string, 0, sizeof(fake_dispatch_string));
}

static int fake_cpu_dispatch_callback(int index, int *cpus, int num_cpus)
{
	int i;

	fake_dispatch_calls++;
	fake_dispatch_index = index;
	fake_dispatch_count = num_cpus;
	for (i = 0; i < num_cpus && i < 8; i++)
		fake_dispatch_cpus[i] = cpus[i];
	return fake_dispatch_ret;
}

static int fake_mem_dispatch_callback(int index, struct ihk_mem_chunk *chunks,
		int num_chunks)
{
	int i;

	fake_dispatch_calls++;
	fake_dispatch_index = index;
	fake_dispatch_count = num_chunks;
	for (i = 0; i < num_chunks && i < 8; i++)
		fake_dispatch_chunks[i] = chunks[i];
	return fake_dispatch_ret;
}

static int fake_ikc_dispatch_callback(int index, struct ihk_ikc_cpu_map *maps,
		int num_maps)
{
	int i;

	fake_dispatch_calls++;
	fake_dispatch_index = index;
	fake_dispatch_count = num_maps;
	for (i = 0; i < num_maps && i < 8; i++)
		fake_dispatch_maps[i] = maps[i];
	return fake_dispatch_ret;
}

static int fake_kargs_dispatch_callback(int index, char *kargs)
{
	fake_dispatch_calls++;
	fake_dispatch_index = index;
	fake_dispatch_kargs = kargs;
	if (kargs)
		snprintf(fake_dispatch_string, sizeof(fake_dispatch_string),
				"%s", kargs);
	return fake_dispatch_ret;
}

static int fake_env_string_dispatch_callback(int index, char *value,
		char *err_msg)
{
	fake_dispatch_calls++;
	fake_dispatch_index = index;
	fake_dispatch_err = err_msg;
	if (value)
		snprintf(fake_dispatch_string, sizeof(fake_dispatch_string),
				"%s", value);
	return fake_dispatch_ret;
}

static void fake_all_reset(void)
{
	fake_all_count_ret = 0;
	fake_all_mem_count_ret = 0;
	fake_all_query_ret = 0;
	fake_all_action_ret = 0;
	fake_all_count_calls = 0;
	fake_all_mem_count_calls = 0;
	fake_all_query_calls = 0;
	fake_all_action_calls = 0;
	fake_all_count_index = -1;
	fake_all_mem_count_index = -1;
	fake_all_query_index = -1;
	fake_all_action_index = -1;
	fake_all_query_count = -1;
	fake_all_action_count = -1;
	fake_all_err = NULL;
	memset(fake_all_cpus, 0, sizeof(fake_all_cpus));
	memset(fake_all_chunks, 0, sizeof(fake_all_chunks));
}

static int fake_all_count_callback(int index)
{
	fake_all_count_calls++;
	fake_all_count_index = index;
	return fake_all_count_ret;
}

static int fake_all_mem_count_callback(int index)
{
	fake_all_mem_count_calls++;
	fake_all_mem_count_index = index;
	return fake_all_mem_count_ret;
}

static int fake_cpu_all_query_callback(int index, int *cpus, int num_cpus)
{
	int i;

	fake_all_query_calls++;
	fake_all_query_index = index;
	fake_all_query_count = num_cpus;
	for (i = 0; i < num_cpus && i < 8; i++)
		cpus[i] = 20 + i;
	return fake_all_query_ret;
}

static int fake_cpu_all_action_callback(int index, int *cpus, int num_cpus)
{
	int i;

	fake_all_action_calls++;
	fake_all_action_index = index;
	fake_all_action_count = num_cpus;
	for (i = 0; i < num_cpus && i < 8; i++)
		fake_all_cpus[i] = cpus[i];
	return fake_all_action_ret;
}

static int fake_mem_all_query_callback(int index,
		struct ihk_mem_chunk *chunks, int num_chunks)
{
	int i;

	fake_all_query_calls++;
	fake_all_query_index = index;
	fake_all_query_count = num_chunks;
	for (i = 0; i < num_chunks && i < 8; i++) {
		chunks[i].size = 0x1000UL * (i + 1);
		chunks[i].numa_node_number = 4 + i;
	}
	return fake_all_query_ret;
}

static int fake_mem_all_action_callback(int index,
		struct ihk_mem_chunk *chunks, int num_chunks)
{
	int i;

	fake_all_action_calls++;
	fake_all_action_index = index;
	fake_all_action_count = num_chunks;
	for (i = 0; i < num_chunks && i < 8; i++)
		fake_all_chunks[i] = chunks[i];
	return fake_all_action_ret;
}

static int fake_release_cpu_all_callback(int index, char *err_msg)
{
	fake_all_action_calls++;
	fake_all_action_index = index;
	fake_all_err = err_msg;
	return fake_all_action_ret;
}

static void fake_char_reset(void)
{
	fake_char_load_ret = 0;
	fake_char_kargs_ret = 0;
	fake_char_load_calls = 0;
	fake_char_kargs_calls = 0;
	fake_char_load_index = -1;
	fake_char_kargs_index = -1;
	fake_char_load_arg = NULL;
	fake_char_kargs_arg = NULL;
}

static int fake_char_load_callback(int index, char *arg)
{
	fake_char_load_calls++;
	fake_char_load_index = index;
	fake_char_load_arg = arg;
	return fake_char_load_ret;
}

static int fake_char_kargs_callback(int index, char *arg)
{
	fake_char_kargs_calls++;
	fake_char_kargs_index = index;
	fake_char_kargs_arg = arg;
	return fake_char_kargs_ret;
}

static void require(int cond)
{
	if (!cond)
		exit(2);
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

int main(void)
{
	struct ihkconfig_dispatch_ops cfg_ops = {
		.get = fake_index_handler,
		.reserve = fake_index_handler,
		.create = fake_fd_handler,
		.destroy = fake_fd_handler,
		.scratch = fake_fd_handler,
		.sbox = fake_fd_handler,
		.read = fake_fd_handler,
		.mmap = fake_fd_handler,
		.ioctl = fake_fd_handler,
		.clear_kmsg = fake_fd_handler,
		.clear_kmsg_write = fake_fd_handler,
		.reserve_mem_max_ratio = NULL,
		.release = fake_fd_handler,
		.query = fake_fd_handler,
	};
	struct ihkosctl_dispatch_ops os_ops = {
		.get = fake_index_handler,
		.dump = fake_index_handler,
		.kmsg = fake_index_handler,
		.load = fake_fd_handler,
		.boot = fake_fd_handler,
		.shutdown = fake_fd_handler,
		.alloc = fake_fd_handler,
		.reserve_cpu = fake_fd_handler,
		.reserve_mem = fake_fd_handler,
		.assign = fake_fd_handler,
		.release = fake_fd_handler,
		.set = fake_fd_handler,
		.query = fake_fd_handler,
		.query_free_mem = fake_fd_handler,
		.kargs = fake_fd_handler,
		.clear_kmsg = fake_fd_handler,
		.intr = fake_fd_handler,
		.ioctl = fake_fd_handler,
	};
	unsigned long digest = 0x69686b6c696255L;
	char path[128];
	char usage_buf[2048];
	int notify_mon;
	int notify_kmsg;
	int fd_closed = 99;
	unsigned long cmd;
	unsigned long value_kb;
	unsigned long mem_results[2];
	unsigned long req_sizes[2];
	unsigned long os_set[2];
	unsigned long total;
	long pgsizes[2];
	long all_pgsizes[8];
	int cpus[2] = { 1, 3 };
	int *req_cpus;
	int req_num_cpus;
	int req_numa[2];
	int src_cpus[2];
	int dst_cpus[2];
	int parsed_index;
	int shaped_ret;
	int open_ret;
	int ioctl_ret;
	int readable_ret;
	int validate_ret;
	int count_ret;
	int query_ret;
	int num_ret;
	int set_ret;
	int chunks_ret;
	int eventfd_ret;
	int boot_ret;
	int status_ret;
	int polls;
	int failed_index;
	int stage;
	int publish_ret;
	char ikc_map[8] = { 0 };
	char dummy_buf[16] = { 0 };
	char image_name[] = "/tmp/kernel.img";
	char valid_kargs[] = "foo hidos bar";
	char invalid_kargs[] = "foo";
	char env_conf_timeout[] = "IHK_RESERVE_MEM_TIMEOUT";
	char env_cpus_name[] = "IHK_CPUS";
	char env_mem_name[] = "IHK_MEM";
	char env_ikc_name[] = "IHK_IKC_MAP";
	char env_kargs_name[] = "IHK_KARGS";
	char env_other_name[] = "OTHER";
	char env_timeout_value[] = "123";
	char env_bad_timeout_value[] = "12x";
	char env_cpus_value[] = "0-3";
	char env_mem_value[] = "1G@0";
	char env_ikc_value[] = "0:1";
	char env_kargs_value[] = "hidos create";
	char env_kargs_second_value[] = "hidos final";
	char env_other_value[] = "ignored";
	char env_default_kargs[] = "hidos default";
	char env_wrapper_block[] =
		"OTHER=ignored\0IHK_CPUS=0-2\0IHK_MEM=1G@0\0"
		"IHK_IKC_MAP=0-1:3+4:5\0IHK_KARGS=hidos wrapped\0";
	char env_mem_conf_block[] =
		"IHK_RESERVE_MEM_TIMEOUT=123\0OTHER=ignored\0";
	char env_bad_mem_conf_block[] =
		"IHK_RESERVE_MEM_TIMEOUT=12x\0";
	char env_no_kargs_block[] = "OTHER=ignored\0";
	char create_os_err[64] = { 0 };
	char *create_os_names[6];
	char *create_os_values[6];
	char *kargs_result;
	struct ihk_mem_chunk chunks[2] = {
		{ .size = 4096, .numa_node_number = 1 },
		{ .size = 8192, .numa_node_number = 0 },
	};
	struct ihk_mem_chunk copy_chunks[2];
	struct ihk_mem_chunk bad_chunks[1] = {
		{ .size = 1024, .numa_node_number = 2 },
	};
	struct ihk_ikc_cpu_map maps[2] = {
		{ .src_cpu = 10, .dst_cpu = 2 },
		{ .src_cpu = 11, .dst_cpu = 3 },
	};
	struct ihk_ikc_cpu_map map_copy[2];
	char no_nul_kargs[] = { 'h', 'i', 'd', 'o' };
	int ret;
	const char *expected_ihkconfig_usage =
		"Usage: ihkconfig (dev #) (action)\n"
		"action:\n"
		"    create\n"
		"    destroy\n"
		"    scratch\n"
		"    sbox\n"
		"    read\n"
		"    mmap\n"
		"    ioctl\n"
		"    clear_kmsg\n"
		"    clear_kmsg_write\n"
		"    reserve cpu|mem [resources]\n"
		"    release cpu|mem [resources]\n"
		"    query cpu|mem\n"
		"    get os_instances\n"
		"    get buildid\n";
	const char *expected_ihkosctl_usage =
		"Usage: ihkosctl (dev #) (action)\n"
		"action:\n"
		"    load (kernel.img)\n"
		"    boot\n"
		"    shutdown\n"
		"    assign cpu|mem \n"
		"           cpu (cpu_list) \n"
		"           mem (size@NUMA) \n"
		"    release cpu|mem \n"
		"            cpu (cpu_list) \n"
		"            mem (size@NUMA) \n"
		"    set ikc_map (cpu_list:cpu+cpu_list:cpu+..) \n"
		"    get ikc_map\n"
		"    query [cpu|mem]\n"
		"    query_free_mem\n"
		"    kargs (kernel arg)\n"
		"    get status\n"
		"    kmsg\n"
		"    clear_kmsg\n"
		"    intr cpu irq_vector\n"
		"    ioctl (req) (arg)\n";

	require(ihkconfig_action_result("get") == 1);
	require(ihkconfig_action_result("query") == 13);
	require(ihkconfig_action_result("unknown") == 0);
	require(ihkosctl_action_result("kmsg") == 3);
	require(ihkosctl_action_result("boot") == 5);
	require(ihkosctl_action_result("unknown") == 0);
	require(ihklib_argc_at_least_result(2, 3, 1) == 1);
	require(ihklib_argc_at_least_result(3, 3, 1) == 0);
	require(ihklib_argc_at_least_result(5, 3, -1) == 0);
	require(ihklib_argc_greater_than_result(4, 3) == 1);
	require(ihklib_argc_greater_than_result(3, 3) == 0);
	memset(usage_buf, 0, sizeof(usage_buf));
	ret = ihkconfig_usage_result(usage_buf, sizeof(usage_buf),
			"/usr/sbin/ihkconfig");
	require(ret == (int)strlen(expected_ihkconfig_usage));
	require(!strcmp(usage_buf, expected_ihkconfig_usage));
	require(ihkconfig_usage_result(usage_buf, 16,
			"ihkconfig") == -ENAMETOOLONG);
	memset(usage_buf, 0, sizeof(usage_buf));
	ret = ihkosctl_usage_result(usage_buf, sizeof(usage_buf),
			"/usr/bin/ihkosctl", 0);
	require(ret == (int)strlen(expected_ihkosctl_usage));
	require(!strcmp(usage_buf, expected_ihkosctl_usage));
	ret = ihkosctl_usage_result(usage_buf, sizeof(usage_buf),
			"ihkosctl", 1);
	require(ret == (int)(strlen(expected_ihkosctl_usage) +
			strlen("    dump [-d level] [file]\n")));
	require(strstr(usage_buf, "    dump [-d level] [file]\n") != NULL);
	require(ihkosctl_usage_result(NULL, sizeof(usage_buf),
			"ihkosctl", 0) == -EINVAL);
	mix(&digest, (unsigned long)ret);

	require(ihklib_kargs_validate_result("hidos", 1UL << 20) == 0);
	require(ihklib_kargs_validate_result("foo hidos bar", 1UL << 20) == 0);
	require(ihklib_kargs_validate_result("  hidos  ", 1UL << 20) == 0);
	require(ihklib_kargs_validate_result("foohidos", 1UL << 20) == -22);
	require(ihklib_kargs_validate_result("hidos=1", 1UL << 20) == -22);
	require(ihklib_kargs_validate_result(NULL, 1UL << 20) == -14);
	require(ihklib_kargs_validate_result(no_nul_kargs,
			sizeof(no_nul_kargs)) == -22);
	mix(&digest, (unsigned long)ihklib_kargs_validate_result("hidos", 0));

	require(ihklib_os_status_public_result(IHK_OS_STATUS_NOT_BOOTED) ==
			IHK_STATUS_INACTIVE);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_LOADING) ==
			IHK_STATUS_INACTIVE);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_BOOTING) ==
			IHK_STATUS_BOOTING);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_BOOTED) ==
			IHK_STATUS_BOOTING);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_READY) ==
			IHK_STATUS_BOOTING);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_RUNNING) ==
			IHK_STATUS_RUNNING);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_SHUTDOWN) ==
			IHK_STATUS_SHUTDOWN);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_FAILED) ==
			IHK_STATUS_PANIC);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_HUNGUP) ==
			IHK_STATUS_HUNGUP);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_FREEZING) ==
			IHK_STATUS_FREEZING);
	require(ihklib_os_status_public_result(IHK_OS_STATUS_FROZEN) ==
			IHK_STATUS_FROZEN);
	require(ihklib_os_status_public_result(99) == -22);
	mix(&digest, (unsigned long)ihklib_os_status_public_result(
			IHK_OS_STATUS_RUNNING));

	require(ihklib_os_boot_status_action_result(IHK_OS_STATUS_BOOTING) == 1);
	require(ihklib_os_boot_status_action_result(IHK_OS_STATUS_BOOTED) == 1);
	require(ihklib_os_boot_status_action_result(IHK_OS_STATUS_READY) == 1);
	require(ihklib_os_boot_status_action_result(IHK_OS_STATUS_RUNNING) == 0);
	require(ihklib_os_boot_status_action_result(-1) == 0);
	require(ihklib_os_boot_final_result(IHK_OS_STATUS_RUNNING) == 0);
	require(ihklib_os_boot_final_result(IHK_OS_STATUS_BOOTED) == -22);

	parsed_index = -99;
	require(ihklib_mcos_name_index_result("mcos0", &parsed_index) == 1);
	require(parsed_index == 0);
	require(ihklib_mcos_name_index_result("mcos12", &parsed_index) == 1);
	require(parsed_index == 12);
	require(ihklib_mcos_name_index_result("mcos-2", &parsed_index) == 1);
	require(parsed_index == -2);
	require(ihklib_mcos_name_index_result("mcos", &parsed_index) == 1);
	require(parsed_index == 0);
	require(ihklib_mcos_name_index_result("mcpu0", &parsed_index) == 0);
	require(ihklib_mcos_name_index_result(NULL, &parsed_index) == -22);
	require(ihklib_mcos_name_index_result("mcos4", NULL) == -22);
	mix(&digest, (unsigned long)parsed_index);

	shaped_ret = 99;
	require(ihklib_destroy_os_retry_result(0, EBUSY, EBUSY,
			&shaped_ret) == 0);
	require(shaped_ret == 0);
	require(ihklib_destroy_os_retry_result(-1, EBUSY, EBUSY,
			&shaped_ret) == 1);
	require(shaped_ret == -EBUSY);
	require(ihklib_destroy_os_retry_result(-1, EIO, EBUSY,
			&shaped_ret) == -1);
	require(shaped_ret == -EIO);
	require(ihklib_destroy_os_retry_result(-1, EIO, EBUSY,
			NULL) == -22);
	mix(&digest, (unsigned long)shaped_ret);

	fake_open_ret = 124;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ulong_seq[0] = 0;
	fake_ioctl_ulong_len = 1;
	fake_ioctl_ulong_pos = 0;
	fake_errno_len = 0;
	open_ret = 0;
	ioctl_ret = 99;
	polls = 0;
	require(ihklib_destroy_os_body_result(3, 9, 0x112901, EBUSY,
			5, 10000, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, fake_sleep_callback, &open_ret,
			&ioctl_ret, &polls) == 0);
	require(open_ret == 124 && ioctl_ret == 0 && polls == 1);
	require(fake_callback_index == 3 && last_fd == 124 &&
			fake_ioctl_request == 0x112901 && fake_ioctl_arg == 9);
	require(fake_close_calls == 1 && fake_errno_calls == 0 &&
			fake_sleep_calls == 0);

	fake_open_ret = 125;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ulong_seq[0] = -1;
	fake_ioctl_ulong_seq[1] = -1;
	fake_ioctl_ulong_seq[2] = 0;
	fake_ioctl_ulong_len = 3;
	fake_ioctl_ulong_pos = 0;
	fake_errno_seq[0] = EBUSY;
	fake_errno_seq[1] = EBUSY;
	fake_errno_len = 2;
	fake_errno_pos = 0;
	require(ihklib_destroy_os_body_result(4, 10, 0x112901, EBUSY,
			5, 10000, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, fake_sleep_callback, &open_ret,
			&ioctl_ret, &polls) == 0);
	require(open_ret == 125 && ioctl_ret == 0 && polls == 3);
	require(fake_ioctl_calls == 3 && fake_errno_calls == 2 &&
			fake_sleep_calls == 2 && fake_sleep_usec == 10000 &&
			fake_close_calls == 1);

	fake_open_ret = 126;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ulong_seq[0] = -1;
	fake_ioctl_ulong_len = 1;
	fake_ioctl_ulong_pos = 0;
	fake_errno_seq[0] = EIO;
	fake_errno_len = 1;
	fake_errno_pos = 0;
	require(ihklib_destroy_os_body_result(5, 11, 0x112901, EBUSY,
			5, 10000, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, fake_sleep_callback, &open_ret,
			&ioctl_ret, &polls) == -EIO);
	require(open_ret == 126 && ioctl_ret == -1 && polls == 1);
	require(fake_errno_calls == 1 && fake_sleep_calls == 0 &&
			fake_close_calls == 1);

	fake_open_ret = 127;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ulong_seq[0] = -1;
	fake_ioctl_ulong_seq[1] = -1;
	fake_ioctl_ulong_len = 2;
	fake_ioctl_ulong_pos = 0;
	fake_errno_seq[0] = EBUSY;
	fake_errno_seq[1] = EBUSY;
	fake_errno_len = 2;
	fake_errno_pos = 0;
	require(ihklib_destroy_os_body_result(6, 12, 0x112901, EBUSY,
			2, 10000, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, fake_sleep_callback, &open_ret,
			&ioctl_ret, &polls) == -EBUSY);
	require(open_ret == 127 && ioctl_ret == -1 && polls == 2);
	require(fake_errno_calls == 2 && fake_sleep_calls == 2 &&
			fake_close_calls == 1);
	require(ihklib_destroy_os_body_result(1, 1, 0x112901, EBUSY,
			5, 10000, NULL, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			fake_sleep_callback, &open_ret, &ioctl_ret,
			&polls) == -EINVAL);
	fake_ioctl_ulong_len = 0;
	fake_ioctl_ulong_pos = 0;
	fake_errno_len = 0;
	fake_errno_pos = 0;
	mix(&digest, (unsigned long)polls ^ (unsigned long)ioctl_ret);

	require(ihklib_eventfd_type_valid_result(IHK_OS_EVENTFD_TYPE_OOM) == 1);
	require(ihklib_eventfd_type_valid_result(IHK_OS_EVENTFD_TYPE_STATUS) == 1);
	require(ihklib_eventfd_type_valid_result(IHK_OS_EVENTFD_TYPE_KMSG) == 1);
	require(ihklib_eventfd_type_valid_result(1) == 0);
	require(ihklib_eventfd_type_valid_result(102) == 0);

	cmd = 0;
	require(ihklib_perfctl_ioctl_cmd_result(PERF_EVENT_ENABLE,
			0x1111, 0x2222, 0x3333, &cmd) == 0);
	require(cmd == 0x1111);
	require(ihklib_perfctl_ioctl_cmd_result(PERF_EVENT_DISABLE,
			0x1111, 0x2222, 0x3333, &cmd) == 0);
	require(cmd == 0x2222);
	require(ihklib_perfctl_ioctl_cmd_result(PERF_EVENT_DESTROY,
			0x1111, 0x2222, 0x3333, &cmd) == 0);
	require(cmd == 0x3333);
	require(ihklib_perfctl_ioctl_cmd_result(9, 0x1111, 0x2222,
			0x3333, &cmd) == -22);
	require(ihklib_perfctl_ioctl_cmd_result(PERF_EVENT_ENABLE,
			0x1111, 0x2222, 0x3333, NULL) == -22);
	mix(&digest, cmd);

	require(ihklib_cpu_request_validate_result(cpus, 2, 1024,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == 0);
	require(ihklib_cpu_request_validate_result(NULL, 0, 1024,
			IHKLIB_VALIDATE_ZERO_NOOP,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == 1);
	require(ihklib_cpu_request_validate_result(NULL, 2, 1024,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == -14);
	require(ihklib_cpu_request_validate_result(NULL, 0, 1024,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ALWAYS, -22) == -22);
	require(ihklib_cpu_request_validate_result(cpus, -1, 1024,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == -22);
	require(ihklib_cpu_request_validate_result(cpus, 1025, 1024,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == -22);

	req_cpus = NULL;
	req_num_cpus = -1;
	require(ihklib_cpu_req_bind_result(&req_cpus, &req_num_cpus,
			cpus, 2) == 0);
	require(req_cpus == cpus && req_num_cpus == 2);
	require(ihklib_cpu_req_bind_result(&req_cpus, &req_num_cpus,
			NULL, 0) == 0);
	require(req_cpus == NULL && req_num_cpus == 0);
	require(ihklib_cpu_req_bind_result(NULL, &req_num_cpus,
			cpus, 2) == -22);
	require(ihklib_cpu_req_bind_result(&req_cpus, &req_num_cpus,
			NULL, 2) == -14);
	require(ihklib_cpu_req_bind_result(&req_cpus, &req_num_cpus,
			cpus, -1) == -22);

	fake_readable_ret = 0;
	fake_readable_calls = 0;
	fake_readable_index = -1;
	fake_open_ret = 170;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_cpu_req_num = -1;
	fake_cpu_req_first = -1;
	fake_cpu_req_second = -1;
	readable_ret = -99;
	validate_ret = -99;
	open_ret = -99;
	ioctl_ret = -99;
	require(ihklib_os_cpu_request_body_result(71, cpus, 2, 0x112a22,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 &&
			open_ret == 170 && ioctl_ret == 0);
	require(fake_readable_calls == 1 && fake_readable_index == 71);
	require(fake_open_calls == 1 && fake_callback_index == 71);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	require(fake_ioctl_request == 0x112a22 && fake_cpu_req_num == 2);
	require(fake_cpu_req_first == 1 && fake_cpu_req_second == 3);

	fake_readable_calls = 0;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	open_ret = -99;
	ioctl_ret = -99;
	require(ihklib_os_cpu_request_body_result(72, NULL, 0, 0x112a23,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 1 &&
			open_ret == -1 && ioctl_ret == 0);
	require(fake_readable_calls == 1 && fake_open_calls == 0 &&
			fake_ioctl_calls == 0);

	fake_readable_ret = -EACCES;
	fake_readable_calls = 0;
	open_ret = -99;
	require(ihklib_os_cpu_request_body_result(73, cpus, 2, 0x112a22,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == -EACCES);
	require(readable_ret == -EACCES && open_ret == -1);
	require(fake_readable_calls == 1 && fake_open_calls == 0);
	fake_readable_ret = 0;

	fake_open_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	require(ihklib_os_cpu_request_body_result(74, NULL, 2, 0x112a22,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == -EFAULT);
	require(readable_ret == 0 && validate_ret == -EFAULT &&
			fake_open_calls == 0);

	fake_open_ret = -5;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	fake_close_calls = 0;
	open_ret = -99;
	require(ihklib_os_cpu_request_body_result(75, cpus, 2, 0x112a22,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == -5);
	require(open_ret == -5 && fake_ioctl_calls == 0 &&
			fake_close_calls == 0);

	fake_open_ret = 171;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	fake_errno_calls = 0;
	fake_close_calls = 0;
	ioctl_ret = -99;
	require(ihklib_os_cpu_request_body_result(76, cpus, 2, 0x112a23,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 171 && ioctl_ret == -1 &&
			fake_ioctl_request == 0x112a23);
	require(fake_errno_calls == 1 && fake_close_calls == 1);
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	mix(&digest, (unsigned long)(fake_cpu_req_num ^ fake_cpu_req_first ^
			fake_cpu_req_second ^ fake_ioctl_request));

	fake_readable_ret = 0;
	fake_readable_calls = 0;
	fake_open_ret = 172;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_count_override = 2;
	fake_ioctl_ret = 0;
	fake_cpu_req_num = -1;
	fake_cpu_req_first = -1;
	fake_cpu_req_second = -1;
	readable_ret = -99;
	validate_ret = -99;
	open_ret = -99;
	count_ret = -99;
	query_ret = -99;
	require(ihklib_os_query_cpu_body_result(77, cpus, 2, 0x112a38,
			0x112a26, 1024, fake_readable_callback,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &count_ret, &query_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 &&
			open_ret == 172 && count_ret == 2 && query_ret == 0);
	require(fake_ioctl_calls == 2 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	require(fake_ioctl_request == 0x112a26 && fake_cpu_req_num == 2);
	require(fake_cpu_req_first == 1 && fake_cpu_req_second == 3);

	fake_open_ret = 173;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_ioctl_count_override = 0;
	count_ret = -99;
	query_ret = -99;
	require(ihklib_os_query_cpu_body_result(78, NULL, 0, 0x112a38,
			0x112a26, 1024, fake_readable_callback,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &count_ret, &query_ret) == 0);
	require(open_ret == 173 && count_ret == 0 && query_ret == 0);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1);

	fake_open_ret = 174;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_ioctl_count_override = 1;
	count_ret = -99;
	require(ihklib_os_query_cpu_body_result(79, cpus, 2, 0x112a38,
			0x112a26, 1024, fake_readable_callback,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &count_ret, &query_ret) == -EINVAL);
	require(count_ret == 1 && fake_ioctl_calls == 1 &&
			fake_close_calls == 1);

	fake_open_ret = 175;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_count_override = -1;
	fake_errno_value = EIO;
	count_ret = -99;
	require(ihklib_os_query_cpu_body_result(80, cpus, 2, 0x112a38,
			0x112a26, 1024, fake_readable_callback,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &count_ret, &query_ret) == -EIO);
	require(count_ret == -1 && fake_errno_calls == 1 &&
			fake_close_calls == 1);

	fake_open_ret = 176;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_count_override = 2;
	fake_ioctl_ret = -1;
	query_ret = -99;
	require(ihklib_os_query_cpu_body_result(81, cpus, 2, 0x112a38,
			0x112a26, 1024, fake_readable_callback,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&open_ret, &count_ret, &query_ret) == -EIO);
	require(count_ret == 2 && query_ret == -1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);
	fake_ioctl_count_override = INT_MIN;
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	mix(&digest, (unsigned long)(count_ret ^ query_ret ^
			fake_ioctl_calls));

	fake_readable_ret = 0;
	fake_readable_calls = 0;
	fake_open_ret = 177;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_mem_req_num = -1;
	fake_mem_req_first_size = 0;
	fake_mem_req_second_size = 0;
	fake_mem_req_first_numa = -1;
	fake_mem_req_second_numa = -1;
	readable_ret = -99;
	validate_ret = -99;
	stage = -99;
	open_ret = -99;
	ioctl_ret = -99;
	require(ihklib_os_mem_request_body_result(82, chunks, 2, 0x112a24,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&stage, &open_ret, &ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 && stage == 0);
	require(open_ret == 177 && ioctl_ret == 0);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	require(fake_mem_req_num == 2);
	require(fake_mem_req_first_size == 4096 &&
			fake_mem_req_second_size == 8192);
	require(fake_mem_req_first_numa == 1 && fake_mem_req_second_numa == 0);

	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	stage = -99;
	open_ret = -99;
	ioctl_ret = -99;
	require(ihklib_os_mem_request_body_result(83, NULL, 0, 0x112a24,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&stage, &open_ret, &ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 1 && stage == 0);
	require(open_ret == -1 && ioctl_ret == 0);
	require(fake_open_calls == 0 && fake_ioctl_calls == 0);

	fake_open_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	require(ihklib_os_mem_request_body_result(84, NULL, 2, 0x112a24,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&stage, &open_ret, &ioctl_ret) == -EFAULT);
	require(readable_ret == 0 && validate_ret == -EFAULT &&
			fake_open_calls == 0);

	fake_open_ret = -6;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	fake_close_calls = 0;
	open_ret = -99;
	require(ihklib_os_mem_request_body_result(85, chunks, 2, 0x112a24,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&stage, &open_ret, &ioctl_ret) == -6);
	require(open_ret == -6 && fake_ioctl_calls == 0 &&
			fake_close_calls == 0);

	fake_open_ret = 178;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	fake_errno_calls = 0;
	fake_close_calls = 0;
	ioctl_ret = -99;
	require(ihklib_os_mem_request_body_result(86, chunks, 2, 0x112a24,
			1024, fake_readable_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&stage, &open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 178 && ioctl_ret == -1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	mix(&digest, fake_mem_req_first_size ^ fake_mem_req_second_size ^
			(unsigned long)fake_mem_req_num);

	memset(copy_chunks, 0, sizeof(copy_chunks));
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_readable_ret = 0;
	fake_readable_calls = 0;
	fake_open_ret = 179;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_query_mem_chunks = 2;
	readable_ret = -99;
	validate_ret = -99;
	count_ret = -99;
	stage = -99;
	open_ret = -99;
	ioctl_ret = -99;
	publish_ret = -99;
	require(ihklib_os_query_mem_body_result(87, copy_chunks, 2,
			0x112a27, 0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 && count_ret == 2 &&
			stage == 0 && open_ret == 179 && ioctl_ret == 0 &&
			publish_ret == 0);
	require(fake_all_count_calls == 1 && fake_all_count_index == 87);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0 && fake_ioctl_request == 0x112a27);
	require(copy_chunks[0].size == 16384 &&
			copy_chunks[0].numa_node_number == 2);
	require(copy_chunks[1].size == 32768 &&
			copy_chunks[1].numa_node_number == 3);

	fake_all_reset();
	fake_all_count_ret = 0;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	count_ret = -99;
	open_ret = -99;
	ioctl_ret = -99;
	publish_ret = -99;
	require(ihklib_os_query_mem_body_result(88, NULL, 0, 0x112a27,
			0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 && count_ret == 0);
	require(open_ret == -1 && ioctl_ret == 0 && publish_ret == 0);
	require(fake_open_calls == 0 && fake_ioctl_calls == 0);

	fake_all_reset();
	fake_all_count_ret = 1;
	fake_open_calls = 0;
	count_ret = -99;
	require(ihklib_os_query_mem_body_result(89, copy_chunks, 2,
			0x112a27, 0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == -EINVAL);
	require(count_ret == 1 && fake_open_calls == 0);

	fake_all_reset();
	fake_all_count_ret = -EIO;
	fake_open_calls = 0;
	count_ret = -99;
	require(ihklib_os_query_mem_body_result(90, copy_chunks, 2,
			0x112a27, 0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == -EIO);
	require(count_ret == -EIO && fake_open_calls == 0);

	fake_all_reset();
	fake_open_calls = 0;
	validate_ret = -99;
	require(ihklib_os_query_mem_body_result(91, NULL, 2, 0x112a27,
			0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == -EFAULT);
	require(validate_ret == -EFAULT && fake_all_count_calls == 0 &&
			fake_open_calls == 0);

	fake_all_reset();
	fake_all_count_ret = 2;
	fake_open_ret = -7;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	fake_close_calls = 0;
	open_ret = -99;
	require(ihklib_os_query_mem_body_result(92, copy_chunks, 2,
			0x112a27, 0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == -7);
	require(open_ret == -7 && fake_ioctl_calls == 0 &&
			fake_close_calls == 0);

	fake_open_ret = 180;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	fake_errno_calls = 0;
	fake_close_calls = 0;
	ioctl_ret = -99;
	require(ihklib_os_query_mem_body_result(93, copy_chunks, 2,
			0x112a27, 0x112a27, 1024, fake_readable_callback,
			fake_all_count_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &stage, &open_ret, &ioctl_ret,
			&publish_ret) == -EIO);
	require(open_ret == 180 && ioctl_ret == -1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	mix(&digest, copy_chunks[0].size ^ copy_chunks[1].size ^
			(unsigned long)count_ret);

	fake_all_reset();
	fake_readable_ret = 0;
	fake_readable_calls = 0;
	fake_open_ret = 181;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_mem_req_num = -1;
	fake_mem_req_first_size = 0;
	fake_mem_req_second_size = 0;
	fake_mem_req_first_numa = -1;
	fake_mem_req_second_numa = -1;
	readable_ret = -99;
	validate_ret = -99;
	count_ret = -99;
	query_ret = -99;
	stage = -99;
	open_ret = -99;
	ioctl_ret = -99;
	require(ihklib_os_release_mem_body_result(94, chunks, 2, 0x112a25,
			1024, fake_readable_callback, fake_all_count_callback,
			fake_mem_all_query_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &query_ret, &stage, &open_ret,
			&ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 0 && count_ret == 0 &&
			query_ret == 0 && stage == 0);
	require(open_ret == 181 && ioctl_ret == 0);
	require(fake_all_count_calls == 0 && fake_all_query_calls == 0);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0 && fake_ioctl_request == 0x112a25);
	require(fake_mem_req_num == 2 && fake_mem_req_first_size == 4096 &&
			fake_mem_req_second_size == 8192);
	require(fake_mem_req_first_numa == 1 && fake_mem_req_second_numa == 0);

	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	readable_ret = -99;
	validate_ret = -99;
	stage = -99;
	open_ret = -99;
	require(ihklib_os_release_mem_body_result(95, NULL, 0, 0x112a25,
			1024, fake_readable_callback, fake_all_count_callback,
			fake_mem_all_query_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &query_ret, &stage, &open_ret,
			&ioctl_ret) == 0);
	require(readable_ret == 0 && validate_ret == 1 && stage == 0 &&
			open_ret == -1);
	require(fake_open_calls == 0 && fake_ioctl_calls == 0);

	validate_ret = -99;
	fake_all_reset();
	require(ihklib_os_release_mem_body_result(96, NULL, 2, 0x112a25,
			1024, fake_readable_callback, fake_all_count_callback,
			fake_mem_all_query_callback, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &readable_ret, &validate_ret,
			&count_ret, &query_ret, &stage, &open_ret,
			&ioctl_ret) == -EFAULT);
	require(validate_ret == -EFAULT && fake_all_count_calls == 0);

	bad_chunks[0].size = ULONG_MAX;
	bad_chunks[0].numa_node_number = 0;
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_query_ret = 0;
	fake_open_ret = 182;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_mem_req_num = -1;
	fake_mem_req_first_size = 0;
	fake_mem_req_second_size = 0;
	fake_mem_req_first_numa = -1;
	fake_mem_req_second_numa = -1;
	count_ret = -99;
	query_ret = -99;
	stage = -99;
	require(ihklib_os_release_mem_body_result(97, bad_chunks, 1,
			0x112a25, 1024, fake_readable_callback,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&readable_ret, &validate_ret, &count_ret, &query_ret,
			&stage, &open_ret, &ioctl_ret) == 0);
	require(count_ret == 2 && query_ret == 0 && stage == 0);
	require(fake_all_count_calls == 1 && fake_all_count_index == 97);
	require(fake_all_query_calls == 1 && fake_all_query_index == 97 &&
			fake_all_query_count == 2);
	require(fake_mem_req_num == 2 && fake_mem_req_first_size == 0x1000 &&
			fake_mem_req_second_size == 0x2000);
	require(fake_mem_req_first_numa == 4 && fake_mem_req_second_numa == 5);

	fake_all_reset();
	fake_all_count_ret = 0;
	fake_open_calls = 0;
	stage = -99;
	count_ret = -99;
	require(ihklib_os_release_mem_body_result(98, bad_chunks, 1,
			0x112a25, 1024, fake_readable_callback,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&readable_ret, &validate_ret, &count_ret, &query_ret,
			&stage, &open_ret, &ioctl_ret) == -EINVAL);
	require(count_ret == 0 && stage == 5 && fake_open_calls == 0);

	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_query_ret = -5;
	fake_open_calls = 0;
	query_ret = -99;
	stage = -99;
	require(ihklib_os_release_mem_body_result(99, bad_chunks, 1,
			0x112a25, 1024, fake_readable_callback,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&readable_ret, &validate_ret, &count_ret, &query_ret,
			&stage, &open_ret, &ioctl_ret) == -5);
	require(query_ret == -5 && stage == 0 && fake_open_calls == 0);

	fake_all_reset();
	fake_open_ret = -8;
	fake_open_calls = 0;
	fake_ioctl_calls = 0;
	fake_close_calls = 0;
	open_ret = -99;
	require(ihklib_os_release_mem_body_result(100, chunks, 2,
			0x112a25, 1024, fake_readable_callback,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&readable_ret, &validate_ret, &count_ret, &query_ret,
			&stage, &open_ret, &ioctl_ret) == -8);
	require(open_ret == -8 && fake_ioctl_calls == 0 &&
			fake_close_calls == 0);

	fake_open_ret = 183;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	fake_errno_calls = 0;
	fake_close_calls = 0;
	ioctl_ret = -99;
	require(ihklib_os_release_mem_body_result(101, chunks, 2,
			0x112a25, 1024, fake_readable_callback,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&readable_ret, &validate_ret, &count_ret, &query_ret,
			&stage, &open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 183 && ioctl_ret == -1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	bad_chunks[0].size = 1024;
	bad_chunks[0].numa_node_number = 2;
	mix(&digest, fake_mem_req_first_size ^ fake_mem_req_second_size ^
			(unsigned long)fake_mem_req_first_numa);

	require(ihklib_count_match_result(2, 2) == 0);
	require(ihklib_count_match_result(2, 3) == -22);
	require(ihklib_positive_count_or_result(4, -22) == 4);
	require(ihklib_positive_count_or_result(0, -22) == -22);
	require(ihklib_positive_count_or_result(-7, -22) == -22);
	require(ihklib_required_count_result(4, -22) == 4);
	require(ihklib_required_count_result(0, -22) == -22);
	require(ihklib_required_count_result(-7, -22) == -7);
	require(ihklib_positive_count_action_result(3) == 1);
	require(ihklib_positive_count_action_result(0) == 0);
	require(ihklib_positive_count_action_result(-1) == 0);
	require(ihklib_load_file_validate_result("vmlinux") == 0);
	require(ihklib_load_file_validate_result(NULL) == -EINVAL);
	require(ihklib_kmsg_validate_result(dummy_buf, sizeof(dummy_buf),
			sizeof(dummy_buf)) == 0);
	require(ihklib_kmsg_validate_result(dummy_buf, sizeof(dummy_buf) - 1,
			sizeof(dummy_buf)) == -EINVAL);
	require(ihklib_kmsg_validate_result(NULL, sizeof(dummy_buf),
			sizeof(dummy_buf)) == -EFAULT);
	require(ihklib_kmsg_validate_result(NULL, sizeof(dummy_buf) - 1,
			sizeof(dummy_buf)) == -EINVAL);
	require(ihklib_rusage_validate_result(dummy_buf, sizeof(dummy_buf),
			sizeof(dummy_buf)) == 0);
	require(ihklib_rusage_validate_result(NULL, sizeof(dummy_buf),
			sizeof(dummy_buf)) == -EFAULT);
	require(ihklib_rusage_validate_result(dummy_buf, sizeof(dummy_buf) - 1,
			sizeof(dummy_buf)) == -EINVAL);

	fake_open_ret = 130;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_rusage_desc_ptr = NULL;
	fake_rusage_desc_size = 0;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_getrusage_body_result(36, dummy_buf,
			sizeof(dummy_buf), sizeof(dummy_buf), 0x11290106,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 0);
	require(open_ret == 130 && ioctl_ret == 0);
	require(fake_callback_index == 36 && fake_ioctl_request == 0x11290106);
	require(fake_rusage_desc_ptr == dummy_buf &&
			fake_rusage_desc_size == sizeof(dummy_buf));
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	require(ihklib_os_getrusage_body_result(36, NULL,
			sizeof(dummy_buf), sizeof(dummy_buf), 0x11290106,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EFAULT);
	require(open_ret == -1 && ioctl_ret == 0);
	require(ihklib_os_getrusage_body_result(36, dummy_buf,
			sizeof(dummy_buf) - 1, sizeof(dummy_buf), 0x11290106,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EINVAL);
	fake_open_ret = -8;
	fake_open_calls = 0;
	fake_close_calls = 0;
	require(ihklib_os_getrusage_body_result(37, dummy_buf,
			sizeof(dummy_buf), sizeof(dummy_buf), 0x11290106,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -8);
	require(open_ret == -8 && fake_open_calls == 1 &&
			fake_close_calls == 0);
	fake_open_ret = 131;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_getrusage_body_result(38, dummy_buf,
			sizeof(dummy_buf), sizeof(dummy_buf), 0x11290106,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 131 && ioctl_ret == -1);
	require(fake_ioctl_calls == 1 && fake_errno_calls == 1 &&
			fake_close_calls == 1);
	fake_ioctl_ret = 0;
	mix(&digest, (unsigned long)fake_rusage_desc_size);

	require(ihklib_perf_attr_validate_result(dummy_buf) == 0);
	require(ihklib_perf_attr_validate_result(NULL) == -EFAULT);
	require(ihklib_perf_event_count_validate_result(1) == 0);
	require(ihklib_perf_event_count_validate_result(0) == -EINVAL);
	require(ihklib_perf_event_count_validate_result(-1) == -EINVAL);
	mix(&digest, (unsigned long)req_num_cpus);

	require(ihklib_mem_request_validate_result(chunks, 2, 2048,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == 0);
	require(ihklib_mem_request_validate_result(NULL, 0, 2048,
			IHKLIB_VALIDATE_ZERO_NOOP,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == 1);
	require(ihklib_mem_request_validate_result(NULL, 2, 2048,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == -14);
	require(ihklib_mem_request_validate_result(chunks, 2049, 2048,
			IHKLIB_VALIDATE_ZERO_CONTINUE,
			IHKLIB_VALIDATE_NULL_ONLY_NONZERO, -14) == -22);

	require(ihklib_ikc_map_validate_result(ikc_map, 1, 1024) == 0);
	require(ihklib_ikc_map_validate_result(ikc_map, 0, 1024) == -22);
	require(ihklib_ikc_map_validate_result(NULL, 1, 1024) == -14);
	require(ihklib_ikc_map_validate_result(ikc_map, 1025, 1024) == -22);

	require(ihklib_pagesizes_validate_result(pgsizes, 2, 2) == 0);
	require(ihklib_pagesizes_validate_result(NULL, 2, 2) == -14);
	require(ihklib_pagesizes_validate_result(pgsizes, 1, 2) == -22);

	fake_open_ret = 77;
	fake_open_calls = 0;
	fake_close_calls = 0;
	last_closed_fd = -1;
	open_ret = 0;
	require(ihklib_os_get_num_pagesizes_body_result(3, 8,
			fake_open_callback, fake_close_callback, &open_ret) == 8);
	require(fake_callback_index == 3 && open_ret == 77);
	require(fake_open_calls == 1 && fake_close_calls == 1);
	require(last_closed_fd == 77);
	fake_open_ret = -5;
	fake_open_calls = 0;
	fake_close_calls = 0;
	open_ret = 0;
	require(ihklib_os_get_num_pagesizes_body_result(4, 8,
			fake_open_callback, fake_close_callback, &open_ret) == -5);
	require(open_ret == -5 && fake_open_calls == 1 &&
			fake_close_calls == 0);
	require(ihklib_os_get_num_pagesizes_body_result(4, 8,
			NULL, fake_close_callback, &open_ret) == -22);

	memset(all_pgsizes, 0, sizeof(all_pgsizes));
	fake_open_ret = 88;
	fake_open_calls = 0;
	fake_close_calls = 0;
	last_closed_fd = -1;
	open_ret = 0;
	require(ihklib_os_get_pagesizes_body_result(5, all_pgsizes, 8, 8,
			fake_open_callback, fake_close_callback, &open_ret) == 0);
	require(open_ret == 88 && fake_callback_index == 5);
	require(fake_open_calls == 1 && fake_close_calls == 1);
	require(last_closed_fd == 88);
	require(all_pgsizes[0] == (1L << 12));
	require(all_pgsizes[1] == (1L << 16));
	require(all_pgsizes[2] == (1L << 21));
	require(all_pgsizes[7] == (1L << 42));
	fake_open_ret = 89;
	fake_close_calls = 0;
	require(ihklib_os_get_pagesizes_body_result(5, NULL, 8, 8,
			fake_open_callback, fake_close_callback, &open_ret) == -14);
	require(open_ret == 89 && fake_close_calls == 1);
	fake_open_ret = 90;
	fake_close_calls = 0;
	require(ihklib_os_get_pagesizes_body_result(5, all_pgsizes, 7, 8,
			fake_open_callback, fake_close_callback, &open_ret) == -22);
	require(open_ret == 90 && fake_close_calls == 1);
	require(ihklib_os_get_pagesizes_body_result(5, all_pgsizes, 8, 8,
			fake_open_callback, NULL, &open_ret) == -22);
	mix(&digest, (unsigned long)all_pgsizes[7]);

	fake_open_ret = 91;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_ioctl_noarg_body_result(7, 0x112a21, 0,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 0);
	require(open_ret == 91 && ioctl_ret == 0);
	require(fake_open_calls == 1 && fake_ioctl_calls == 1 &&
			fake_close_calls == 1 && fake_errno_calls == 0);
	require(last_fd == 91 && last_closed_fd == 91 &&
			fake_ioctl_request == 0x112a21);

	fake_open_ret = 92;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 3;
	ioctl_ret = 0;
	require(ihklib_os_ioctl_noarg_body_result(8, 0x112a34, 1,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 3);
	require(open_ret == 92 && ioctl_ret == 3);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);

	fake_open_ret = 93;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_ioctl_noarg_body_result(9, 0x112a34, 1,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 93 && ioctl_ret == -1);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 1);

	fake_open_ret = 94;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 1;
	require(ihklib_os_ioctl_noarg_body_result(10, 0x112a21, 0,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 94 && ioctl_ret == 1);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 1);

	fake_open_ret = -6;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_ioctl_noarg_body_result(11, 0x112a21, 0,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -6);
	require(open_ret == -6 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 0 &&
			fake_errno_calls == 0);
	require(ihklib_os_ioctl_noarg_body_result(11, 0x112a21, 0,
			NULL, fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -22);

	fake_open_ret = 124;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 6;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_ioctl_noarg_body_result(36, 0x11290c, 1,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 6);
	require(open_ret == 124 && ioctl_ret == 6 &&
			fake_ioctl_request == 0x11290c);
	require(fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 125;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 42;
	require(ihklib_os_ioctl_noarg_body_result(37, 0x112900, 1,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 42);
	require(open_ret == 125 && ioctl_ret == 42 &&
			fake_ioctl_request == 0x112900);
	require(fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 126;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_ioctl_noarg_body_result(38, 0x112900, 1,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 126 && ioctl_ret == -1 &&
			fake_close_calls == 1 && fake_errno_calls == 1);

	fake_open_ret = 127;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 5;
	require(ihklib_os_get_num_cpus_raw_body_result(39, 0x112a38,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, &open_ret, &ioctl_ret) == 5);
	require(open_ret == 127 && ioctl_ret == 5 &&
			fake_ioctl_request == 0x112a38);
	require(fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 128;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	require(ihklib_os_get_num_cpus_raw_body_result(40, 0x112a38,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, &open_ret, &ioctl_ret) == -1);
	require(open_ret == 128 && ioctl_ret == -1 &&
			fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 129;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_query_mem_chunks = 9;
	chunks_ret = -1;
	require(ihklib_mem_chunk_count_body_result(41, 0x112907,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret, &chunks_ret) == 9);
	require(open_ret == 129 && ioctl_ret == 0 && chunks_ret == 9);
	require(fake_ioctl_request == 0x112907 &&
			fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 130;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	fake_query_mem_chunks = 11;
	chunks_ret = -1;
	require(ihklib_mem_chunk_count_body_result(42, 0x112907,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret, &chunks_ret) == -EIO);
	require(open_ret == 130 && ioctl_ret == -1 && chunks_ret == 11 &&
			fake_close_calls == 1 && fake_errno_calls == 1);

	fake_open_ret = 131;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	fake_query_mem_chunks = 4;
	chunks_ret = -1;
	require(ihklib_mem_chunk_count_body_result(43, 0x112a27,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret, &chunks_ret) == 4);
	require(open_ret == 131 && ioctl_ret == 0 && chunks_ret == 4 &&
			fake_ioctl_request == 0x112a27);

	fake_open_ret = -8;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	chunks_ret = 99;
	require(ihklib_mem_chunk_count_body_result(44, 0x112a27,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret, &chunks_ret) == -8);
	require(open_ret == -8 && ioctl_ret == 0 && chunks_ret == 0 &&
			fake_ioctl_calls == 0 && fake_close_calls == 0);

	fake_open_ret = 95;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_perfctl_body_result(12, PERF_EVENT_ENABLE,
			0x1111, 0x2222, 0x3333, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == 0);
	require(open_ret == 95 && ioctl_ret == 0);
	require(fake_ioctl_request == 0x1111 && fake_ioctl_calls == 1 &&
			fake_close_calls == 1 && fake_errno_calls == 0);

	fake_open_ret = 96;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	require(ihklib_os_perfctl_body_result(13, 99, 0x1111, 0x2222,
			0x3333, fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback, &open_ret,
			&ioctl_ret) == -22);
	require(open_ret == 96 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1 &&
			fake_errno_calls == 0);

	fake_open_ret = 97;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_perfctl_body_result(14, PERF_EVENT_DESTROY,
			0x1111, 0x2222, 0x3333, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 97 && ioctl_ret == -1);
	require(fake_ioctl_request == 0x3333 && fake_ioctl_calls == 1 &&
			fake_close_calls == 1 && fake_errno_calls == 1);
	mix(&digest, (unsigned long)fake_ioctl_request);

	fake_open_ret = 98;
	fake_open_calls = 0;
	fake_close_calls = 0;
	open_ret = 0;
	require(ihklib_os_get_kmsg_size_body_result(15, sizeof(dummy_buf),
			fake_open_callback, fake_close_callback, &open_ret) ==
			(int)sizeof(dummy_buf));
	require(open_ret == 98 && fake_open_calls == 1 &&
			fake_close_calls == 1);
	fake_open_ret = -7;
	fake_close_calls = 0;
	require(ihklib_os_get_kmsg_size_body_result(15, sizeof(dummy_buf),
			fake_open_callback, fake_close_callback, &open_ret) == -7);
	require(open_ret == -7 && fake_close_calls == 0);

	fake_open_ret = 99;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_kmsg_body_result(16, dummy_buf, sizeof(dummy_buf),
			sizeof(dummy_buf), 0x112a20, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == 0);
	require(open_ret == 99 && ioctl_ret == 0);
	require(fake_ioctl_request == 0x112a20 &&
			fake_ioctl_arg == (unsigned long)dummy_buf);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	fake_open_ret = 100;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_kmsg_body_result(17, dummy_buf,
			sizeof(dummy_buf) - 1, sizeof(dummy_buf), 0x112a20,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EINVAL);
	require(open_ret == 100 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1);
	require(ihklib_os_kmsg_body_result(17, NULL, sizeof(dummy_buf),
			sizeof(dummy_buf), 0x112a20, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EFAULT);
	fake_open_ret = 101;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_kmsg_body_result(18, dummy_buf, sizeof(dummy_buf),
			sizeof(dummy_buf), 0x112a20, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EIO);
	require(open_ret == 101 && ioctl_ret == -1);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 1);

	fake_open_ret = 102;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_ioctl_ret = IHK_OS_STATUS_RUNNING;
	require(ihklib_os_get_status_body_result(19, 0x112a14,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, &open_ret, &ioctl_ret) ==
			IHK_STATUS_RUNNING);
	require(open_ret == 102 && ioctl_ret == IHK_OS_STATUS_RUNNING);
	require(fake_ioctl_request == 0x112a14 && fake_close_calls == 1);
	fake_ioctl_ret = 99;
	require(ihklib_os_get_status_body_result(19, 0x112a14,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, &open_ret, &ioctl_ret) == -EINVAL);
	require(ioctl_ret == 99);
	fake_ioctl_ret = -1;
	require(ihklib_os_get_status_body_result(19, 0x112a14,
			fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, &open_ret, &ioctl_ret) == -1);
	require(ioctl_ret == -1);

	fake_open_ret = 103;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_num_ret = 0;
	fake_ioctl_set_ret = 0;
	open_ret = 0;
	num_ret = 99;
	set_ret = 99;
	require(ihklib_os_setperfevent_body_result(20, dummy_buf, 2,
			0x11290100, 0x11290101, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &num_ret,
			&set_ret) == 0);
	require(open_ret == 103 && num_ret == 0 && set_ret == 0);
	require(fake_ioctl_calls == 2 && fake_ioctl_request == 0x11290101 &&
			fake_ioctl_arg == (unsigned long)dummy_buf);
	require(fake_close_calls == 1 && fake_errno_calls == 0);
	require(ihklib_os_setperfevent_body_result(20, NULL, 2,
			0x11290100, 0x11290101, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &num_ret,
			&set_ret) == -EFAULT);
	fake_open_ret = 104;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_setperfevent_body_result(20, dummy_buf, 0,
			0x11290100, 0x11290101, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &num_ret,
			&set_ret) == -EINVAL);
	require(open_ret == 104 && fake_close_calls == 1 &&
			fake_ioctl_calls == 0);
	fake_open_ret = 105;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_num_ret = -1;
	fake_ioctl_set_ret = 0;
	fake_errno_value = EIO;
	require(ihklib_os_setperfevent_body_result(20, dummy_buf, 2,
			0x11290100, 0x11290101, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &num_ret,
			&set_ret) == -EIO);
	require(num_ret == -1 && set_ret == 0 && fake_ioctl_calls == 1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);
	fake_open_ret = 106;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_num_ret = 0;
	fake_ioctl_set_ret = -1;
	require(ihklib_os_setperfevent_body_result(20, dummy_buf, 2,
			0x11290100, 0x11290101, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &num_ret,
			&set_ret) == -EIO);
	require(num_ret == 0 && set_ret == -1 && fake_ioctl_calls == 2 &&
			fake_errno_calls == 1 && fake_close_calls == 1);

	fake_open_ret = 107;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_getperfevent_body_result(21, mem_results, 1,
			0x11290102, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == 0);
	require(open_ret == 107 && ioctl_ret == 0);
	require(fake_ioctl_request == 0x11290102 &&
			fake_ioctl_arg == (unsigned long)mem_results);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	fake_open_ret = 108;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_getperfevent_body_result(21, mem_results, 0,
			0x11290102, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EINVAL);
	require(open_ret == 108 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1);
	fake_open_ret = 109;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	require(ihklib_os_getperfevent_body_result(21, mem_results, 1,
			0x11290102, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EIO);
	require(ioctl_ret == -1 && fake_errno_calls == 1 &&
			fake_close_calls == 1);
	mix(&digest, (unsigned long)ioctl_ret ^ fake_ioctl_arg);

	fake_open_ret = 110;
	fake_open_calls = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_eventfd_calls = 0;
	fake_eventfd_ret = 123;
	fake_ioctl_ret = 0;
	open_ret = 0;
	eventfd_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_get_eventfd_body_result(22,
			IHK_OS_EVENTFD_TYPE_STATUS, 0x112a15,
			fake_open_callback, fake_eventfd_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &eventfd_ret,
			&ioctl_ret) == 123);
	require(open_ret == 110 && eventfd_ret == 123 && ioctl_ret == 0);
	require(fake_open_calls == 1 && fake_eventfd_calls == 1 &&
			fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	require(fake_callback_index == 22 && last_fd == 110 &&
			last_closed_fd == 110);
	require(fake_eventfd_initval == 0 && fake_eventfd_flags == 0);
	require(fake_eventfd_desc_fd == 123 &&
			fake_eventfd_desc_type == IHK_OS_EVENTFD_TYPE_STATUS);

	fake_open_ret = 111;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_eventfd_calls = 0;
	open_ret = 0;
	eventfd_ret = 77;
	ioctl_ret = 99;
	require(ihklib_os_get_eventfd_body_result(23, 777, 0x112a15,
			fake_open_callback, fake_eventfd_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &eventfd_ret,
			&ioctl_ret) == -EINVAL);
	require(open_ret == 111 && eventfd_ret == 0 && ioctl_ret == 0);
	require(fake_eventfd_calls == 0 && fake_ioctl_calls == 0 &&
			fake_close_calls == 1);

	fake_open_ret = 112;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_eventfd_calls = 0;
	fake_eventfd_ret = 124;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	require(ihklib_os_get_eventfd_body_result(24,
			IHK_OS_EVENTFD_TYPE_KMSG, 0x112a15,
			fake_open_callback, fake_eventfd_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &eventfd_ret,
			&ioctl_ret) == -EIO);
	require(open_ret == 112 && eventfd_ret == 124 &&
			ioctl_ret == -1);
	require(fake_eventfd_calls == 1 && fake_ioctl_calls == 1 &&
			fake_close_calls == 1 && fake_errno_calls == 1);

	fake_open_ret = 113;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	open_ret = 0;
	ioctl_ret = 99;
	require(ihklib_os_load_body_result(25, image_name, 0x112a00,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == 0);
	require(open_ret == 113 && ioctl_ret == 0);
	require(fake_ioctl_request == 0x112a00 &&
			fake_ioctl_arg == (unsigned long)image_name);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1 &&
			fake_errno_calls == 0);
	fake_open_ret = 114;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_load_body_result(26, NULL, 0x112a00,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EINVAL);
	require(open_ret == 114 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1);
	fake_open_ret = 115;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	require(ihklib_os_load_body_result(27, image_name, 0x112a00,
			fake_open_callback, fake_ioctl_ulong_callback,
			fake_close_callback, fake_errno_callback,
			&open_ret, &ioctl_ret) == -EIO);
	require(ioctl_ret == -1 && fake_errno_calls == 1 &&
			fake_close_calls == 1);

	fake_open_ret = 116;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	require(ihklib_os_kargs_body_result(28, valid_kargs, 1UL << 20,
			0x112a04, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == 0);
	require(open_ret == 116 && ioctl_ret == 0);
	require(fake_ioctl_request == 0x112a04 &&
			fake_ioctl_arg == (unsigned long)valid_kargs);
	require(fake_ioctl_calls == 1 && fake_close_calls == 1);
	fake_open_ret = 117;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_kargs_body_result(29, NULL, 1UL << 20,
			0x112a04, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EFAULT);
	require(open_ret == 117 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1);
	fake_open_ret = 118;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	require(ihklib_os_kargs_body_result(30, invalid_kargs, 1UL << 20,
			0x112a04, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EINVAL);
	require(open_ret == 118 && ioctl_ret == 0);
	require(fake_ioctl_calls == 0 && fake_close_calls == 1);
	fake_open_ret = 119;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	require(ihklib_os_kargs_body_result(31, valid_kargs, 1UL << 20,
			0x112a04, fake_open_callback,
			fake_ioctl_ulong_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret) == -EIO);
	require(ioctl_ret == -1 && fake_errno_calls == 1 &&
			fake_close_calls == 1);

	fake_open_ret = 120;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ret = 0;
	fake_status_seq[0] = IHK_OS_STATUS_BOOTING;
	fake_status_seq[1] = IHK_OS_STATUS_BOOTED;
	fake_status_seq[2] = IHK_OS_STATUS_READY;
	fake_status_seq[3] = IHK_OS_STATUS_RUNNING;
	fake_status_len = 4;
	fake_status_pos = 0;
	require(ihklib_os_boot_body_result(32, 0x112a01, 0x112a14, 4,
			200000, fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			fake_sleep_callback, &open_ret, &boot_ret,
			&status_ret, &polls) == 0);
	require(open_ret == 120 && boot_ret == 0 &&
			status_ret == IHK_OS_STATUS_RUNNING && polls == 4);
	require(fake_ioctl_calls == 5 && fake_sleep_calls == 3 &&
			fake_sleep_usec == 200000 && fake_close_calls == 1);
	require(fake_status_pos == 4);

	fake_open_ret = 121;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ret = 0;
	fake_status_seq[0] = -1;
	fake_status_len = 1;
	fake_status_pos = 0;
	fake_errno_value = EIO;
	require(ihklib_os_boot_body_result(33, 0x112a01, 0x112a14, 1,
			200000, fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			fake_sleep_callback, &open_ret, &boot_ret,
			&status_ret, &polls) == -EIO);
	require(boot_ret == 0 && status_ret == -1 && polls == 1);
	require(fake_ioctl_calls == 2 && fake_sleep_calls == 0 &&
			fake_errno_calls == 1 && fake_close_calls == 1);

	fake_open_ret = 122;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ret = 0;
	fake_status_seq[0] = IHK_OS_STATUS_BOOTED;
	fake_status_len = 1;
	fake_status_pos = 0;
	require(ihklib_os_boot_body_result(34, 0x112a01, 0x112a14, 2,
			200000, fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			fake_sleep_callback, &open_ret, &boot_ret,
			&status_ret, &polls) == -EINVAL);
	require(status_ret == IHK_OS_STATUS_BOOTED && polls == 2);
	require(fake_ioctl_calls == 3 && fake_sleep_calls == 2 &&
			fake_errno_calls == 0 && fake_close_calls == 1);

	fake_open_ret = 123;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_sleep_calls = 0;
	fake_ioctl_ret = -1;
	fake_status_len = 0;
	require(ihklib_os_boot_body_result(35, 0x112a01, 0x112a14, 4,
			200000, fake_open_callback, fake_ioctl_noarg_callback,
			fake_close_callback, fake_errno_callback,
			fake_sleep_callback, &open_ret, &boot_ret,
			&status_ret, &polls) == -EIO);
	require(open_ret == 123 && boot_ret == -1 && status_ret == 0 &&
			polls == 0);
	require(fake_ioctl_calls == 1 && fake_errno_calls == 1 &&
			fake_sleep_calls == 0 && fake_close_calls == 1);
	fake_status_len = 0;
	fake_status_pos = 0;
	fake_ioctl_ret = 0;
	fake_errno_value = EIO;
	mix(&digest, (unsigned long)status_ret ^ (unsigned long)polls);

	value_kb = 0;
	require(ihklib_meminfo_line_value_result("Node 0 MemTotal: 123 kB",
			"MemTotal", &value_kb) == 1);
	require(value_kb == 123);
	require(ihklib_meminfo_line_value_result("Node 0 MemTotal: 123 kB",
			"MemFree", &value_kb) == 0);
	require(ihklib_meminfo_line_value_result("Node 1 MemFree:       456 kB",
			"MemFree", &value_kb) == 1);
	require(value_kb == 456);
	require(ihklib_meminfo_line_value_result("Node X MemFree: 456 kB",
			"MemFree", &value_kb) == 0);
	require(ihklib_meminfo_line_value_result(NULL, "MemFree",
			&value_kb) == -22);
	require(ihklib_meminfo_line_value_result("Node 0 MemFree: 1 kB",
			NULL, &value_kb) == -22);
	mix(&digest, value_kb);

	mem_results[0] = 0;
	mem_results[1] = 0;
	require(ihklib_mem_chunks_publish_result(mem_results, 2, chunks, 2) == 0);
	require(mem_results[0] == 8192 && mem_results[1] == 4096);
	require(ihklib_mem_chunks_publish_result(mem_results, 2,
			bad_chunks, 1) == -22);
	require(ihklib_mem_chunks_publish_result(NULL, 2, chunks, 2) == -22);
	mix(&digest, mem_results[0] ^ mem_results[1]);

	fake_access_ret = 0;
	fake_access_calls = 0;
	fake_open_path_calls = 0;
	fake_errno_calls = 0;
	memset(fake_last_path, 0, sizeof(fake_last_path));
	require(ihklib_device_readable_body_result(2, 0,
			fake_access_callback, fake_errno_callback) == 0);
	require(fake_access_calls == 1 && fake_open_path_calls == 0);
	require(!strcmp(fake_last_path, "/dev/mcd2"));
	require(fake_errno_calls == 0);

	fake_access_ret = -1;
	fake_errno_value = EACCES;
	fake_errno_calls = 0;
	require(ihklib_device_readable_body_result(3, 1,
			fake_access_callback, fake_errno_callback) == -EACCES);
	require(fake_access_calls == 2);
	require(!strcmp(fake_last_path, "/dev/mcos3"));
	require(fake_errno_calls == 1);

	fake_access_ret = 0;
	fake_open_path_ret = 161;
	fake_access_calls = 0;
	fake_open_path_calls = 0;
	fake_errno_calls = 0;
	require(ihklib_device_open_body_result(4, 0, fake_access_callback,
			fake_open_path_callback, fake_errno_callback) == 161);
	require(fake_access_calls == 1 && fake_open_path_calls == 1);
	require(!strcmp(fake_last_path, "/dev/mcd4"));
	require(fake_errno_calls == 0);

	fake_open_path_ret = -1;
	fake_errno_value = ENOENT;
	fake_errno_calls = 0;
	require(ihklib_device_open_body_result(5, 1, fake_access_callback,
			fake_open_path_callback, fake_errno_callback) == -ENOENT);
	require(fake_access_calls == 2 && fake_open_path_calls == 2);
	require(!strcmp(fake_last_path, "/dev/mcos5"));
	require(fake_errno_calls == 1);
	require(ihklib_device_readable_body_result(1, 0, NULL,
			fake_errno_callback) == -EINVAL);
	require(ihklib_device_open_body_result(1, 0, fake_access_callback,
			NULL, fake_errno_callback) == -EINVAL);
	mix(&digest, (unsigned long)fake_open_path_calls);

	memset(req_sizes, 0, sizeof(req_sizes));
	memset(req_numa, 0, sizeof(req_numa));
	total = 999;
	require(ihklib_mem_req_fill_result(req_sizes, req_numa, chunks,
			2, 0, &total) == 0);
	require(req_sizes[0] == 4096 && req_sizes[1] == 8192);
	require(req_numa[0] == 1 && req_numa[1] == 0);
	require(total == 0);
	memset(copy_chunks, 0, sizeof(copy_chunks));
	require(ihklib_mem_chunks_from_req_result(copy_chunks, req_sizes,
			req_numa, 2) == 0);
	require(copy_chunks[0].size == 4096 &&
			copy_chunks[0].numa_node_number == 1);
	require(copy_chunks[1].size == 8192 &&
			copy_chunks[1].numa_node_number == 0);
	memset(req_sizes, 0, sizeof(req_sizes));
	total = 0;
	require(ihklib_mem_req_fill_result(req_sizes, req_numa, chunks,
			2, 1, &total) == 0);
	require(req_sizes[0] == ULONG_MAX && req_sizes[1] == ULONG_MAX);
	require(total == 12288);
	require(ihklib_mem_req_fill_result(NULL, req_numa, chunks,
			2, 0, &total) == -14);
	require(ihklib_mem_req_fill_result(req_sizes, req_numa, chunks,
			-1, 0, &total) == -22);
	require(ihklib_mem_req_fill_result(req_sizes, req_numa, chunks,
			2, 0, NULL) == -22);
	require(ihklib_mem_chunks_from_req_result(NULL, req_sizes,
			req_numa, 2) == -14);
	mix(&digest, total ^ req_sizes[0]);

	memset(src_cpus, 0, sizeof(src_cpus));
	memset(dst_cpus, 0, sizeof(dst_cpus));
	require(ihklib_ikc_req_fill_result(src_cpus, dst_cpus,
			maps, 2) == 0);
	require(src_cpus[0] == 10 && src_cpus[1] == 11);
	require(dst_cpus[0] == 2 && dst_cpus[1] == 3);
	memset(map_copy, 0, sizeof(map_copy));
	require(ihklib_ikc_map_from_req_result(map_copy, src_cpus,
			dst_cpus, 2) == 0);
	require(map_copy[0].src_cpu == 10 && map_copy[0].dst_cpu == 2);
	require(map_copy[1].src_cpu == 11 && map_copy[1].dst_cpu == 3);
	require(ihklib_ikc_req_fill_result(NULL, dst_cpus, maps, 2) == -14);
	require(ihklib_ikc_req_fill_result(src_cpus, dst_cpus,
			maps, -1) == -22);
	require(ihklib_ikc_map_from_req_result(NULL, src_cpus,
			dst_cpus, 2) == -14);
	mix(&digest, (unsigned long)(map_copy[1].src_cpu + map_copy[1].dst_cpu));

	os_set[0] = (1UL << 3) | (1UL << 63);
	os_set[1] = (1UL << 1);
	require(ihklib_os_set_next_result(os_set, 130, 0) == 3);
	require(ihklib_os_set_next_result(os_set, 130, 4) == 63);
	require(ihklib_os_set_next_result(os_set, 130, 64) == 65);
	require(ihklib_os_set_next_result(os_set, 66, 66) == -1);
	require(ihklib_os_set_next_result(NULL, 10, 0) == -14);
	require(ihklib_os_set_next_result(os_set, 0, 0) == -22);
	mix(&digest, (unsigned long)ihklib_os_set_next_result(os_set, 130, 64));

	fake_open_ret = 128;
	fake_open_calls = 0;
	fake_open_index_count = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = 0;
	open_ret = 0;
	ioctl_ret = 99;
	polls = 0;
	failed_index = 99;
	require(ihklib_os_set_ioctl_loop_body_result(os_set, 66,
			0x112a30, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret,
			&polls, &failed_index) == 0);
	require(open_ret == 128 && ioctl_ret == 0 && polls == 3);
	require(failed_index == -1 && fake_open_calls == 3 &&
			fake_close_calls == 3 && fake_ioctl_calls == 3 &&
			fake_errno_calls == 0);
	require(fake_open_index_trace[0] == 3 &&
			fake_open_index_trace[1] == 63 &&
			fake_open_index_trace[2] == 65);
	require(fake_ioctl_request == 0x112a30);

	fake_open_ret = -7;
	fake_open_calls = 0;
	fake_open_index_count = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	failed_index = -1;
	require(ihklib_os_set_ioctl_loop_body_result(os_set, 66,
			0x112a31, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret,
			&polls, &failed_index) == -7);
	require(open_ret == -7 && failed_index == 3);
	require(fake_open_calls == 1 && fake_ioctl_calls == 0 &&
			fake_close_calls == 0);

	fake_open_ret = 129;
	fake_open_calls = 0;
	fake_open_index_count = 0;
	fake_close_calls = 0;
	fake_ioctl_calls = 0;
	fake_errno_calls = 0;
	fake_ioctl_ret = -1;
	fake_errno_value = EIO;
	failed_index = -1;
	require(ihklib_os_set_ioctl_loop_body_result(os_set, 66,
			0x112a31, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret,
			&polls, &failed_index) == -EIO);
	require(open_ret == 129 && ioctl_ret == -1 && failed_index == 3);
	require(fake_open_calls == 1 && fake_ioctl_calls == 1 &&
			fake_errno_calls == 1 && fake_close_calls == 1);

	fake_ioctl_ret = 0;
	require(ihklib_os_set_ioctl_loop_body_result(os_set, 0,
			0x112a30, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret,
			&polls, &failed_index) == -EINVAL);
	require(ihklib_os_set_ioctl_loop_body_result(NULL, 66,
			0x112a30, fake_open_callback,
			fake_ioctl_noarg_callback, fake_close_callback,
			fake_errno_callback, &open_ret, &ioctl_ret,
			&polls, &failed_index) == -EFAULT);
	mix(&digest, (unsigned long)polls ^ (unsigned long)fake_open_index_count);

	fake_dispatch_reset();
	require(ihklib_cpu_string_dispatch_body_result(40, "1-3",
			fake_cpu_dispatch_callback) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 40);
	require(fake_dispatch_count == 3);
	require(fake_dispatch_cpus[0] == 1 && fake_dispatch_cpus[1] == 2 &&
			fake_dispatch_cpus[2] == 3);
	require(ihklib_cpu_string_dispatch_body_result(40, "1-x",
			fake_cpu_dispatch_callback) == -EINVAL);
	require(ihklib_cpu_string_dispatch_body_result(40, "1",
			NULL) == -EINVAL);

	fake_dispatch_reset();
	require(ihklib_mem_string_dispatch_body_result(41, "2M@1,all@0",
			fake_mem_dispatch_callback) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 41);
	require(fake_dispatch_count == 2);
	require(fake_dispatch_chunks[0].size == 2097152UL);
	require(fake_dispatch_chunks[0].numa_node_number == 1);
	require(fake_dispatch_chunks[1].size == ULONG_MAX);
	require(fake_dispatch_chunks[1].numa_node_number == 0);
	require(ihklib_mem_string_dispatch_body_result(41, "1G@x",
			fake_mem_dispatch_callback) == -EINVAL);

	fake_dispatch_reset();
	require(ihklib_ikc_string_dispatch_body_result(42, "0-1:3+4:5",
			fake_ikc_dispatch_callback) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 42);
	require(fake_dispatch_count == 3);
	require(fake_dispatch_maps[0].src_cpu == 0 &&
			fake_dispatch_maps[0].dst_cpu == 3);
	require(fake_dispatch_maps[1].src_cpu == 1 &&
			fake_dispatch_maps[1].dst_cpu == 3);
	require(fake_dispatch_maps[2].src_cpu == 4 &&
			fake_dispatch_maps[2].dst_cpu == 5);
	require(ihklib_ikc_string_dispatch_body_result(42, "0-1",
			fake_ikc_dispatch_callback) == -EINVAL);

	fake_dispatch_reset();
	require(ihklib_env_value_callback_body_result(43,
			env_wrapper_block, 5, "IHK_CPUS",
			fake_env_string_dispatch_callback, create_os_err) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 43);
	require(fake_dispatch_err == create_os_err);
	require(!strcmp(fake_dispatch_string, "0-2"));
	fake_dispatch_reset();
	require(ihklib_env_value_callback_body_result(43,
			env_wrapper_block, 5, "MISSING",
			fake_env_string_dispatch_callback, create_os_err) == 0);
	require(fake_dispatch_calls == 0);
	fake_dispatch_reset();
	fake_dispatch_ret = -6;
	require(ihklib_env_value_callback_body_result(43,
			env_wrapper_block, 5, "IHK_MEM",
			fake_env_string_dispatch_callback, create_os_err) == -6);
	require(fake_dispatch_calls == 1);

	fake_create_os_reset();
	require(ihklib_reserve_mem_conf_str_body_result(44,
			env_mem_conf_block, 2,
			fake_create_os_mem_conf_callback) == 0);
	require(fake_create_os_mem_conf_calls == 1);
	require(fake_create_os_mem_conf_index == 44);
	require(fake_create_os_mem_conf_key == IHK_RESERVE_MEM_TIMEOUT);
	require(fake_create_os_mem_conf_value == 123);
	require(ihklib_reserve_mem_conf_str_body_result(44,
			env_bad_mem_conf_block, 1,
			fake_create_os_mem_conf_callback) == -EINVAL);

	fake_dispatch_reset();
	require(ihklib_os_kargs_str_body_result(45, env_wrapper_block, 5,
			env_default_kargs, fake_kargs_dispatch_callback) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 45);
	require(!strcmp(fake_dispatch_string, "hidos wrapped"));
	fake_dispatch_reset();
	require(ihklib_os_kargs_str_body_result(46, env_no_kargs_block, 1,
			env_default_kargs, fake_kargs_dispatch_callback) == 0);
	require(fake_dispatch_calls == 1 && fake_dispatch_index == 46);
	require(!strcmp(fake_dispatch_string, env_default_kargs));

	fake_all_reset();
	fake_all_count_ret = 3;
	stage = -1;
	require(ihklib_os_assign_cpu_all_body_result(50, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == 0);
	require(stage == 0 && fake_all_count_calls == 1);
	require(fake_all_count_index == 50 && fake_all_query_index == 50);
	require(fake_all_action_index == 50 && fake_all_action_count == 3);
	require(fake_all_cpus[0] == 20 && fake_all_cpus[1] == 21 &&
			fake_all_cpus[2] == 22);
	fake_all_reset();
	fake_all_count_ret = -5;
	stage = -1;
	require(ihklib_os_assign_cpu_all_body_result(51, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == -5);
	require(stage == IHKLIB_ALL_STAGE_COUNT);
	require(fake_all_query_calls == 0 && fake_all_action_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 0;
	stage = -1;
	require(ihklib_os_assign_cpu_all_body_result(52, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == -EINVAL);
	require(stage == IHKLIB_ALL_STAGE_EMPTY);
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_query_ret = -6;
	stage = -1;
	require(ihklib_os_assign_cpu_all_body_result(53, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == -6);
	require(stage == IHKLIB_ALL_STAGE_QUERY &&
			fake_all_action_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_action_ret = -7;
	stage = -1;
	require(ihklib_os_assign_cpu_all_body_result(54, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == -7);
	require(stage == IHKLIB_ALL_STAGE_ACTION &&
			fake_all_action_calls == 1);

	fake_all_reset();
	fake_all_count_ret = 0;
	require(ihklib_os_release_cpu_all_body_result(55,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == 0);
	require(fake_all_query_calls == 0 && fake_all_action_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 2;
	require(ihklib_os_release_cpu_all_body_result(56,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == 0);
	require(fake_all_action_count == 2 && fake_all_cpus[1] == 21);
	fake_all_reset();
	fake_all_count_ret = 2;
	stage = -1;
	require(ihklib_release_cpu_all_body_result(57, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == 0);
	require(stage == 0 && fake_all_action_index == 57);
	fake_all_reset();
	fake_all_count_ret = 0;
	stage = -1;
	require(ihklib_release_cpu_all_body_result(58, &stage,
			fake_all_count_callback, fake_cpu_all_query_callback,
			fake_cpu_all_action_callback) == 0);
	require(stage == 0 && fake_all_action_calls == 0);

	fake_all_reset();
	fake_all_count_ret = 2;
	stage = -1;
	require(ihklib_os_assign_mem_all_body_result(59, &stage,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_mem_all_action_callback) == 0);
	require(stage == 0 && fake_all_count_index == 0);
	require(fake_all_query_index == 59 && fake_all_action_index == 59);
	require(fake_all_chunks[0].size == 0x1000UL &&
			fake_all_chunks[0].numa_node_number == 4);
	require(fake_all_chunks[1].size == 0x2000UL &&
			fake_all_chunks[1].numa_node_number == 5);
	fake_all_reset();
	fake_all_count_ret = 0;
	stage = -1;
	require(ihklib_os_assign_mem_all_body_result(60, &stage,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_mem_all_action_callback) == -EINVAL);
	require(stage == IHKLIB_ALL_STAGE_EMPTY);
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_query_ret = -8;
	stage = -1;
	require(ihklib_os_assign_mem_all_body_result(61, &stage,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_mem_all_action_callback) == -8);
	require(stage == IHKLIB_ALL_STAGE_QUERY &&
			fake_all_action_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_action_ret = -9;
	stage = -1;
	require(ihklib_os_assign_mem_all_body_result(62, &stage,
			fake_all_count_callback, fake_mem_all_query_callback,
			fake_mem_all_action_callback) == -9);
	require(stage == IHKLIB_ALL_STAGE_ACTION);
	mix(&digest, (unsigned long)(fake_dispatch_count ^
			fake_create_os_mem_conf_value ^
			fake_all_action_count));

	create_os_names[0] = env_conf_timeout;
	create_os_names[1] = env_cpus_name;
	create_os_names[2] = env_mem_name;
	create_os_names[3] = env_ikc_name;
	create_os_names[4] = env_kargs_name;
	create_os_names[5] = env_other_name;
	create_os_values[0] = env_timeout_value;
	create_os_values[1] = env_cpus_value;
	create_os_values[2] = env_mem_value;
	create_os_values[3] = env_ikc_value;
	create_os_values[4] = env_kargs_value;
	create_os_values[5] = env_other_value;

	fake_create_os_reset();
	require(ihklib_create_os_apply_mem_conf_body_result(
			create_os_names, create_os_values, 6, 17,
			fake_create_os_mem_conf_callback) == 0);
	require(fake_create_os_mem_conf_calls == 1);
	require(fake_create_os_mem_conf_index == 17);
	require(fake_create_os_mem_conf_key == IHK_RESERVE_MEM_TIMEOUT);
	require(fake_create_os_mem_conf_value == 123);
	require(!strcmp(fake_create_os_order, "c"));

	fake_create_os_reset();
	create_os_values[0] = env_bad_timeout_value;
	require(ihklib_create_os_apply_mem_conf_body_result(
			create_os_names, create_os_values, 6, 17,
			fake_create_os_mem_conf_callback) == -EINVAL);
	require(fake_create_os_mem_conf_calls == 0);
	create_os_values[0] = env_timeout_value;
	fake_create_os_ret = -9;
	require(ihklib_create_os_apply_mem_conf_body_result(
			create_os_names, create_os_values, 6, 17,
			fake_create_os_mem_conf_callback) == -9);
	require(fake_create_os_mem_conf_calls == 1);

	fake_create_os_reset();
	require(ihklib_create_os_reserve_resources_body_result(
			create_os_names, create_os_values, 6, 18, create_os_err,
			fake_create_os_cpu_callback,
			fake_create_os_mem_callback) == 0);
	require(fake_create_os_cpu_calls == 1);
	require(fake_create_os_mem_calls == 1);
	require(fake_create_os_last_index == 18);
	require(fake_create_os_cpu_list == env_cpus_value);
	require(fake_create_os_mem_list == env_mem_value);
	require(fake_create_os_last_err == create_os_err);
	require(!strcmp(fake_create_os_order, "CM"));
	fake_create_os_reset();
	fake_create_os_ret = -8;
	require(ihklib_create_os_reserve_resources_body_result(
			create_os_names, create_os_values, 6, 18, create_os_err,
			fake_create_os_cpu_callback,
			fake_create_os_mem_callback) == -8);
	require(fake_create_os_cpu_calls == 1);
	require(fake_create_os_mem_calls == 0);

	fake_create_os_reset();
	kargs_result = NULL;
	require(ihklib_create_os_apply_ikc_kargs_body_result(
			create_os_names, create_os_values, 6, 19,
			env_default_kargs, &kargs_result, create_os_err,
			fake_create_os_ikc_callback) == 0);
	require(fake_create_os_ikc_calls == 1);
	require(fake_create_os_last_index == 19);
	require(fake_create_os_ikc_list == env_ikc_value);
	require(fake_create_os_last_err == create_os_err);
	require(kargs_result == env_kargs_value);
	require(!strcmp(fake_create_os_order, "I"));
	create_os_values[4] = env_kargs_second_value;
	kargs_result = NULL;
	require(ihklib_create_os_apply_ikc_kargs_body_result(
			create_os_names, create_os_values, 6, 19,
			env_default_kargs, &kargs_result, create_os_err,
			fake_create_os_ikc_callback) == 0);
	require(kargs_result == env_kargs_second_value);
	create_os_values[4] = env_kargs_value;
	fake_create_os_reset();
	fake_create_os_ret = -7;
	kargs_result = NULL;
	require(ihklib_create_os_apply_ikc_kargs_body_result(
			create_os_names, create_os_values, 6, 19,
			env_default_kargs, &kargs_result, create_os_err,
			fake_create_os_ikc_callback) == -7);
	require(fake_create_os_ikc_calls == 1);
	require(kargs_result == env_default_kargs);
	require(ihklib_create_os_apply_ikc_kargs_body_result(
			create_os_names, create_os_values, 0, 19,
			env_default_kargs, &kargs_result, create_os_err,
			fake_create_os_ikc_callback) == 0);
	require(kargs_result == env_default_kargs);

	fake_all_reset();
	fake_all_count_ret = 2;
	fake_all_mem_count_ret = 1;
	stage = -1;
	require(ihklib_create_os_preclean_body_result(63, chunks,
			create_os_err, &stage, fake_all_count_callback,
			fake_release_cpu_all_callback,
			fake_all_mem_count_callback,
			fake_mem_all_action_callback) == 0);
	require(stage == 0 && fake_all_count_index == 63);
	require(fake_all_mem_count_index == 63);
	require(fake_all_action_calls == 2 && fake_all_err == create_os_err);
	require(fake_all_chunks[0].size == chunks[0].size &&
			fake_all_chunks[0].numa_node_number ==
			chunks[0].numa_node_number);
	fake_all_reset();
	fake_all_count_ret = -3;
	stage = -1;
	require(ihklib_create_os_preclean_body_result(64, chunks,
			create_os_err, &stage, fake_all_count_callback,
			fake_release_cpu_all_callback,
			fake_all_mem_count_callback,
			fake_mem_all_action_callback) == -3);
	require(stage == IHKLIB_CREATE_STAGE_GET_CPUS);
	require(fake_all_mem_count_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 1;
	fake_all_action_ret = -4;
	stage = -1;
	require(ihklib_create_os_preclean_body_result(65, chunks,
			create_os_err, &stage, fake_all_count_callback,
			fake_release_cpu_all_callback,
			fake_all_mem_count_callback,
			fake_mem_all_action_callback) == -4);
	require(stage == IHKLIB_CREATE_STAGE_RELEASE_CPUS);
	require(fake_all_mem_count_calls == 0);
	fake_all_reset();
	fake_all_count_ret = 0;
	fake_all_mem_count_ret = -5;
	stage = -1;
	require(ihklib_create_os_preclean_body_result(66, chunks,
			create_os_err, &stage, fake_all_count_callback,
			fake_release_cpu_all_callback,
			fake_all_mem_count_callback,
			fake_mem_all_action_callback) == -5);
	require(stage == IHKLIB_CREATE_STAGE_GET_MEM);
	fake_all_reset();
	fake_all_count_ret = 0;
	fake_all_mem_count_ret = 1;
	fake_all_action_ret = -6;
	stage = -1;
	require(ihklib_create_os_preclean_body_result(67, chunks,
			create_os_err, &stage, fake_all_count_callback,
			fake_release_cpu_all_callback,
			fake_all_mem_count_callback,
			fake_mem_all_action_callback) == -6);
	require(stage == IHKLIB_CREATE_STAGE_RELEASE_MEM);

	fake_char_reset();
	stage = -1;
	require(ihklib_create_os_load_kargs_body_result(68,
			image_name, valid_kargs, &stage,
			fake_char_load_callback,
			fake_char_kargs_callback) == 0);
	require(stage == 0 && fake_char_load_calls == 1 &&
			fake_char_kargs_calls == 1);
	require(fake_char_load_index == 68 && fake_char_kargs_index == 68);
	require(fake_char_load_arg == image_name &&
			fake_char_kargs_arg == valid_kargs);
	fake_char_reset();
	fake_char_load_ret = -7;
	stage = -1;
	require(ihklib_create_os_load_kargs_body_result(69,
			image_name, valid_kargs, &stage,
			fake_char_load_callback,
			fake_char_kargs_callback) == -7);
	require(stage == IHKLIB_CREATE_STAGE_LOAD);
	require(fake_char_load_calls == 1 && fake_char_kargs_calls == 0);
	fake_char_reset();
	fake_char_kargs_ret = -8;
	stage = -1;
	require(ihklib_create_os_load_kargs_body_result(70,
			image_name, valid_kargs, &stage,
			fake_char_load_callback,
			fake_char_kargs_callback) == -8);
	require(stage == IHKLIB_CREATE_STAGE_KARGS);
	require(fake_char_load_calls == 1 && fake_char_kargs_calls == 1);
	mix(&digest, (unsigned long)(fake_create_os_mem_conf_value ^
			fake_create_os_last_index ^ fake_all_action_calls ^
			fake_char_kargs_calls));

	last_index = -1;
	ret = ihkconfig_dispatch_action_result(1, 7, -1, &cfg_ops,
			&fd_closed);
	require(ret == 1007);
	require(last_index == 7);
	require(fd_closed == 0);
	mix(&digest, (unsigned long)ret);

	last_fd = -1;
	fd_closed = 99;
	ret = ihkconfig_dispatch_action_result(3, 0, -1, &cfg_ops,
			&fd_closed);
	require(ret == INT_MIN);
	require(last_fd == -1);
	require(fd_closed == 0);

	last_fd = -1;
	last_closed_fd = -1;
	fd_closed = 0;
	ret = ihkconfig_dispatch_action_result(3, 0, 77, &cfg_ops,
			&fd_closed);
	require(ret == 2077);
	require(last_fd == 77);
	require(last_closed_fd == 77);
	require(fd_closed == 1);
	mix(&digest, (unsigned long)ret);

	ret = ihkconfig_dispatch_action_result(14, 0, 88, &cfg_ops,
			&fd_closed);
	require(ret == INT_MIN);
	require(last_closed_fd == 77);

	last_index = -1;
	ret = ihkosctl_dispatch_action_result(3, 12, -1, &os_ops,
			&fd_closed);
	require(ret == 1012);
	require(last_index == 12);
	require(fd_closed == 0);
	mix(&digest, (unsigned long)ret);

	last_fd = -1;
	fd_closed = 99;
	ret = ihkosctl_dispatch_action_result(5, 0, -1, &os_ops,
			&fd_closed);
	require(ret == INT_MIN);
	require(last_fd == -1);
	require(fd_closed == 0);

	last_fd = -1;
	last_closed_fd = -1;
	fd_closed = 0;
	ret = ihkosctl_dispatch_action_result(5, 0, 55, &os_ops,
			&fd_closed);
	require(ret == 2055);
	require(last_fd == 55);
	require(last_closed_fd == 55);
	require(fd_closed == 1);
	mix(&digest, (unsigned long)ret);

	ret = ihkosctl_dispatch_action_result(99, 0, 55, &os_ops,
			&fd_closed);
	require(ret == INT_MIN);

	require(ihkmond_facility_index_result("LOG_LOCAL3") == 3);
	require(ihkmond_facility_index_result("LOG_LOCAL7") == 7);
	require(ihkmond_facility_index_result("LOG_AUTH") == -1);
	require(ihkmond_udev_action_result("add") == 1);
	require(ihkmond_udev_action_result("remove") == 2);
	require(ihkmond_udev_action_result("change") == 0);
	mix(&digest, (unsigned long)ihkmond_facility_index_result("LOG_LOCAL6"));

	memset(path, 0, sizeof(path));
	require(ihkmond_mcos_path_result(path, 4) > 0);
	require(!strcmp(path, "/dev/mcos4"));
	memset(path, 0, sizeof(path));
	require(ihkmond_tmp_dir_result(path) > 0);
	require(!strcmp(path, "/tmp/ihkmond"));
	memset(path, 0, sizeof(path));
	require(ihkmond_tmp_mcos_dir_result(path, 5) > 0);
	require(!strcmp(path, "/tmp/ihkmond/mcos5"));
	memset(path, 0, sizeof(path));
	require(ihkmond_tmp_kmsg_path_result(path, 6, 9) > 0);
	require(!strcmp(path, "/tmp/ihkmond/mcos6/kmsg9"));

	require(ihkmond_filebuf_rotate_needed_result(100, 20, 119) == 1);
	require(ihkmond_filebuf_rotate_needed_result(100, 19, 119) == 0);
	require(ihkmond_next_slot_result(63, 64) == 0);
	require(ihkmond_next_slot_result(8, 64) == 9);
	require(ihkmond_cons_start_result(7, 1, 64) == 8);
	require(ihkmond_cons_start_result(7, 0, 64) == 0);
	require(ihkmond_create_wait_timeout_result(50001, 50000) == 1);
	require(ihkmond_create_wait_timeout_result(50000, 50000) == 0);
	mix(&digest, (unsigned long)ihkmond_next_slot_result(63, 64));

	notify_mon = -1;
	notify_kmsg = -1;
	ret = ihkmond_notify_targets_result(1, 600, 1, &notify_mon,
			&notify_kmsg);
	require(ret == 1);
	require(notify_mon == 1);
	require(notify_kmsg == 1);
	notify_mon = -1;
	notify_kmsg = -1;
	ret = ihkmond_notify_targets_result(2, -1, 0, &notify_mon,
			&notify_kmsg);
	require(ret == 2);
	require(notify_mon == 0);
	require(notify_kmsg == 0);
	notify_mon = -1;
	notify_kmsg = -1;
	ret = ihkmond_notify_targets_result(0, 600, 1, &notify_mon,
			&notify_kmsg);
	require(ret == 0);
	require(notify_mon == 0);
	require(notify_kmsg == 0);
	require(ihkmond_notify_targets_result(1, 600, 1, NULL,
			&notify_kmsg) == -22);
	mix(&digest, (unsigned long)notify_mon);

	printf("ihklib_helpers ok digest=%016lx\n", digest);
	return 0;
}
