#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern const char *mcinspect_thread_status_label_result(int status);
extern const char *mcinspect_thread_active_marker_result(int active);
extern const char *mcinspect_thread_comm_result(const char *cmd_line,
		int is_idle);
extern int mcinspect_ps_header_result(char *buf, size_t buf_size);
extern int mcinspect_thread_line_result(char *buf, size_t buf_size, int cpu,
		const char *active_marker, int tid, int pid,
		unsigned long thread, const char *status, const char *comm);
extern int mcinspect_usage_result(char *buf, size_t buf_size,
		const char *prog);
extern int mcinspect_invalid_va_error_result(char *buf, size_t buf_size);
extern int mcinspect_missing_kernel_error_result(char *buf, size_t buf_size);
extern int mcinspect_pid_line_result(char *buf, size_t buf_size, int pid);
extern int mcinspect_no_symbols_line_result(char *buf, size_t buf_size);
extern int mcinspect_elf_image_error_result(char *buf, size_t buf_size,
		const char *path);
extern int mcinspect_open_os_device_error_result(char *buf, size_t buf_size);
extern int mcinspect_open_kernel_error_result(char *buf, size_t buf_size,
		const char *path);
extern int mcinspect_dwarf_info_error_result(char *buf, size_t buf_size);
extern int mcinspect_main_preflight_action_result(int help,
		const char *kernel_path, int ps, int vtop);
extern void usage(char **argv);
extern unsigned long lookup_bfd_symbol(char *name);
extern int init_bfd_symbols(char *fname);
extern void ihk_read_kernel(unsigned long addr, unsigned long len, void *buf,
		int flags);
extern int find_proc(void *dbg, int pid, unsigned long *rproc);
extern int mcinspect_init_globals_body_result(
		unsigned long mck_num_processors_addr,
		unsigned long clv_addr,
		unsigned long cpu_local_var_size,
		unsigned long clv_runq,
		unsigned long clv_idle,
		unsigned long clv_current,
		unsigned long thread_tid,
		unsigned long thread_proc,
		unsigned long thread_status,
		unsigned long thread_sched_list,
		unsigned long process_pid,
		unsigned long process_saved_cmdline,
		unsigned long process_saved_cmdline_len,
		unsigned long process_vm,
		unsigned long vm_address_space,
		unsigned long address_space_page_table);
extern int mcinspect_mcvtop_body_result(void *dbg, int pid,
		unsigned long vtop_addr,
		int (*find_proc_fn)(void *, int, unsigned long *),
		void (*get_swapper_page_table_fn)(void *, unsigned long *),
		void (*read_usize_fn)(unsigned long, unsigned long *),
		void (*print_init_pt_fn)(unsigned long));
extern int mcinspect_mcps_body_result(
		void (*read_usize_fn)(unsigned long, unsigned long *),
		void (*print_thread_fn)(int, unsigned long, unsigned long, int));
extern int mcinspect_main_body_result(char **argv, int help,
		char *kernel_path, int ps, int vtop, int pid,
		unsigned long vtop_addr, void (*usage_fn)(char **),
		int (*init_bfd_symbols_fn)(char *),
		int (*open_readonly_fn)(const char *),
		int (*dwarf_init_fn)(int, void **, void **),
		void (*init_globals_fn)(void *),
		int (*mcps_fn)(void *),
		int (*mcvtop_fn)(void *, int, unsigned long),
		int (*dwarf_finish_fn)(void *, void **),
		int (*close_fn)(int));
extern int mcinspect_option_body_result(int opt, char *optarg,
		char **kernel_path_out, unsigned long *vtop_addr_out,
		int *pid_out, char **argv, void (*usage_fn)(char **));
extern int mcinspect_option_loop_body_result(int argc, char **argv,
		const char *shortopts, const void *longopts,
		char **kernel_path_out, unsigned long *vtop_addr_out,
		int *pid_out,
		int (*getopt_long_fn)(int, char **, const char *, const void *,
			char **),
		void (*usage_fn)(char **));
extern int mcinspect_main_entry_result(int argc, char **argv,
		const char *shortopts, const void *longopts,
		int (*getopt_long_fn)(int, char **, const char *, const void *,
			char **),
		void (*usage_fn)(char **), int (*init_bfd_symbols_fn)(char *),
		int (*open_readonly_fn)(const char *),
		int (*dwarf_init_fn)(int, void **, void **),
		void (*init_globals_fn)(void *), int (*mcps_fn)(void *),
		int (*mcvtop_fn)(void *, int, unsigned long),
		int (*dwarf_finish_fn)(void *, void **), int (*close_fn)(int));
extern int mcps(void *dbg);
extern int mcvtop(void *dbg, int pid, unsigned long vtop_addr);
extern int dup(int oldfd);
extern int dup2(int oldfd, int newfd);
extern int close(int fd);

#define MCINSPECT_MAIN_CONTINUE 0
#define MCINSPECT_MAIN_HELP 1
#define MCINSPECT_MAIN_MISSING_KERNEL 2
#define MCINSPECT_MAIN_NO_ACTION 3
#define IHK_OS_READ_KADDR 0x112a39

static void require_line(int cond, int line)
{
	if (!cond) {
		fprintf(stderr, "mcinspect_helpers require failed at line %d\n", line);
		exit(2);
	}
}
#define require(cond) require_line((cond), __LINE__)

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

struct mcinspect_bfd_section {
	const char *name;
	unsigned int id;
	unsigned int index;
	struct mcinspect_bfd_section *next;
	struct mcinspect_bfd_section *prev;
	unsigned int flags;
	unsigned long vma;
};
struct mcinspect_bfd_symbol {
	void *the_bfd;
	const char *name;
	unsigned long value;
	unsigned int flags;
	struct mcinspect_bfd_section *section;
};
struct mcinspect_read_desc {
	unsigned long kaddr;
	unsigned long len;
	void *ubuf;
	int flags;
};
static char mcinspect_usage_written[2048];
static int ioctl_seen_fd;
static unsigned long ioctl_seen_request;
static unsigned long ioctl_seen_kaddr;
static unsigned long ioctl_seen_len;
static int ioctl_seen_flags;
static char bfd_openr_name[64];
int debug = 7;
int mcfd = 55;
int help = 8;
int ps = 9;
int vtop = 10;
int pid = 11;
unsigned long vtop_addr = 12;
int nr_cpus = 2;
unsigned long clv = 0x1000;
unsigned long clv_size = 0x100;
unsigned long clv_runq_offset = 0x20;
unsigned long clv_idle_offset = 0x28;
unsigned long clv_current_offset = 0x30;
unsigned long thread_tid_offset = 0x4;
unsigned long thread_sched_list_offset = 0x8;
unsigned long thread_proc_offset = 0x30;
unsigned long thread_status_offset = 0x34;
unsigned long process_pid_offset = 0x10;
unsigned long process_vm_offset = 0x18;
unsigned long process_saved_cmdline_offset = 0x20;
unsigned long process_saved_cmdline_len_offset = 0x28;
unsigned long vm_address_space_offset = 0x38;
unsigned long address_space_page_table_offset = 0x40;
void *symbfd = NULL;
static struct mcinspect_bfd_section mcinspect_symbol_sections[] = {
	{ .vma = 0x1000 },
	{ .vma = 0x2000 },
};
static struct mcinspect_bfd_symbol mcinspect_symbols[] = {
	{ .name = "first_symbol", .value = 0x110,
	  .section = &mcinspect_symbol_sections[0] },
	{ .name = "debug_constants", .value = 0x220,
	  .section = &mcinspect_symbol_sections[1] },
};
static struct mcinspect_bfd_symbol *mcinspect_symtab_storage[] = {
	&mcinspect_symbols[0],
	&mcinspect_symbols[1],
};
struct mcinspect_bfd_symbol **symtab = mcinspect_symtab_storage;
ssize_t nsyms = sizeof(mcinspect_symtab_storage) /
	sizeof(mcinspect_symtab_storage[0]);

void *bfd_openr(const char *name, const char *target)
{
	(void)target;
	strncpy(bfd_openr_name, name, sizeof(bfd_openr_name) - 1);
	bfd_openr_name[sizeof(bfd_openr_name) - 1] = '\0';
	return (void *)0x55667788UL;
}

int bfd_check_format(void *abfd, int format)
{
	return abfd == (void *)0x55667788UL && format == 1;
}

void bfd_perror(const char *message)
{
	fprintf(stderr, "bfd_perror: %s\n", message);
}

long mcinspect_bfd_get_symtab_upper_bound_bridge(void *abfd)
{
	require(abfd == (void *)0x55667788UL);
	return sizeof(mcinspect_symtab_storage);
}

long mcinspect_bfd_canonicalize_symtab_bridge(void *abfd,
		struct mcinspect_bfd_symbol **location)
{
	require(abfd == (void *)0x55667788UL);
	location[0] = &mcinspect_symbols[0];
	location[1] = &mcinspect_symbols[1];
	return sizeof(mcinspect_symtab_storage) /
		sizeof(mcinspect_symtab_storage[0]);
}

static unsigned long fake_kernel_read_ulong(unsigned long addr)
{
	if (addr == 0x5000)
		return 0x6000;
	if (addr == 0x5010)
		return 0x1000;
	if (addr == 0x1020)
		return 0x2008;
	if (addr == 0x2008)
		return 0x1020;
	if (addr == 0x1120)
		return 0x1120;
	if (addr == 0x2030)
		return 0x3000;
	return 0x1122334455667788UL;
}

static int fake_kernel_read_int(unsigned long addr)
{
	if (addr == 0x6000)
		return 2;
	if (addr == 0x3010)
		return 42;
	return -1;
}

static int fake_mcvtop_find_calls;
static void *fake_mcvtop_find_dbg;
static int fake_mcvtop_find_pid;
static int fake_mcvtop_find_ret;
static unsigned long fake_mcvtop_find_proc;
static int fake_mcvtop_get_calls;
static void *fake_mcvtop_get_dbg;
static int fake_mcvtop_read_calls;
static unsigned long fake_mcvtop_read_addr[4];
static int fake_mcvtop_print_calls;
static unsigned long fake_mcvtop_print_value;
static int fake_mcps_read_calls;
static int fake_mcps_print_calls;
static int fake_mcps_print_cpu[8];
static unsigned long fake_mcps_print_thread[8];
static unsigned long fake_mcps_print_idle[8];
static int fake_mcps_print_active[8];
static int fake_main_usage_calls;
static char *fake_main_usage_argv0;
static int fake_main_init_bfd_calls;
static char fake_main_init_bfd_name[64];
static int fake_main_init_bfd_ret;
static int fake_main_open_calls;
static const char *fake_main_open_path[4];
static int fake_main_open_fail_stage;
static int fake_main_dwarf_init_calls;
static int fake_main_dwarf_init_fd;
static int fake_main_dwarf_init_ret;
static int fake_main_init_globals_calls;
static void *fake_main_init_globals_dbg;
static int fake_main_mcps_calls;
static void *fake_main_mcps_dbg;
static int fake_main_mcvtop_calls;
static void *fake_main_mcvtop_dbg;
static int fake_main_mcvtop_pid;
static unsigned long fake_main_mcvtop_addr;
static int fake_main_dwarf_finish_calls;
static void *fake_main_dwarf_finish_dbg;
static int fake_main_close_calls;
static int fake_main_close_fd[4];
static int fake_option_loop_calls;
static int fake_option_loop_opts[8];
static char *fake_option_loop_args[8];
static int fake_option_loop_set_help[8];
static int fake_option_loop_set_ps[8];
static int fake_option_loop_set_vtop[8];
static int fake_option_loop_set_debug[8];
static int fake_option_loop_argc;
static char **fake_option_loop_argv;
static const char *fake_option_loop_shortopts;
static const void *fake_option_loop_longopts;
static int fake_public_header_calls;

static void reset_fake_mcvtop(void)
{
	fake_mcvtop_find_calls = 0;
	fake_mcvtop_find_dbg = NULL;
	fake_mcvtop_find_pid = 0;
	fake_mcvtop_find_ret = 0;
	fake_mcvtop_find_proc = 0x7000;
	fake_mcvtop_get_calls = 0;
	fake_mcvtop_get_dbg = NULL;
	fake_mcvtop_read_calls = 0;
	memset(fake_mcvtop_read_addr, 0, sizeof(fake_mcvtop_read_addr));
	fake_mcvtop_print_calls = 0;
	fake_mcvtop_print_value = 0;
}

static int fake_mcvtop_find_proc_cb(void *dbg, int pid,
		unsigned long *rproc)
{
	fake_mcvtop_find_calls++;
	fake_mcvtop_find_dbg = dbg;
	fake_mcvtop_find_pid = pid;
	if (fake_mcvtop_find_ret < 0)
		return fake_mcvtop_find_ret;
	*rproc = fake_mcvtop_find_proc;
	return 0;
}

static void fake_mcvtop_get_swapper_cb(void *dbg, unsigned long *out)
{
	fake_mcvtop_get_calls++;
	fake_mcvtop_get_dbg = dbg;
	*out = 0x9000;
}

static void fake_mcvtop_read_usize_cb(unsigned long addr, unsigned long *out)
{
	if (fake_mcvtop_read_calls < 4)
		fake_mcvtop_read_addr[fake_mcvtop_read_calls] = addr;
	fake_mcvtop_read_calls++;
	if (addr == 0x7018)
		*out = 0x8000;
	else if (addr == 0x8038)
		*out = 0x8100;
	else if (addr == 0x8140)
		*out = 0x8200;
	else
		*out = 0;
}

static void fake_mcvtop_print_init_pt_cb(unsigned long init_pt)
{
	fake_mcvtop_print_calls++;
	fake_mcvtop_print_value = init_pt;
}

static void reset_fake_mcps(void)
{
	fake_mcps_read_calls = 0;
	fake_mcps_print_calls = 0;
	memset(fake_mcps_print_cpu, 0, sizeof(fake_mcps_print_cpu));
	memset(fake_mcps_print_thread, 0, sizeof(fake_mcps_print_thread));
	memset(fake_mcps_print_idle, 0, sizeof(fake_mcps_print_idle));
	memset(fake_mcps_print_active, 0, sizeof(fake_mcps_print_active));
}

static void fake_mcps_read_usize_cb(unsigned long addr, unsigned long *out)
{
	fake_mcps_read_calls++;
	if (addr == 0x1030)
		*out = 0x2000;
	else if (addr == 0x1020)
		*out = 0x2008;
	else if (addr == 0x2008)
		*out = 0x1020;
	else if (addr == 0x1130)
		*out = 0x1128;
	else if (addr == 0x1120)
		*out = 0x3008;
	else if (addr == 0x3008)
		*out = 0x3108;
	else if (addr == 0x3108)
		*out = 0x1120;
	else
		*out = 0;
}

static void fake_mcps_print_thread_cb(int cpu, unsigned long thread,
		unsigned long idle, int active)
{
	int idx = fake_mcps_print_calls++;

	if (idx < 8) {
		fake_mcps_print_cpu[idx] = cpu;
		fake_mcps_print_thread[idx] = thread;
		fake_mcps_print_idle[idx] = idle;
		fake_mcps_print_active[idx] = active;
	}
}

static void reset_fake_main(void)
{
	fake_main_usage_calls = 0;
	fake_main_usage_argv0 = NULL;
	fake_main_init_bfd_calls = 0;
	memset(fake_main_init_bfd_name, 0, sizeof(fake_main_init_bfd_name));
	fake_main_init_bfd_ret = 0;
	fake_main_open_calls = 0;
	memset(fake_main_open_path, 0, sizeof(fake_main_open_path));
	fake_main_open_fail_stage = 0;
	fake_main_dwarf_init_calls = 0;
	fake_main_dwarf_init_fd = 0;
	fake_main_dwarf_init_ret = 0;
	fake_main_init_globals_calls = 0;
	fake_main_init_globals_dbg = NULL;
	fake_main_mcps_calls = 0;
	fake_main_mcps_dbg = NULL;
	fake_main_mcvtop_calls = 0;
	fake_main_mcvtop_dbg = NULL;
	fake_main_mcvtop_pid = 0;
	fake_main_mcvtop_addr = 0;
	fake_main_dwarf_finish_calls = 0;
	fake_main_dwarf_finish_dbg = NULL;
	fake_main_close_calls = 0;
	memset(fake_main_close_fd, 0, sizeof(fake_main_close_fd));
	mcfd = -1;
}

static void fake_main_usage_cb(char **argv)
{
	fake_main_usage_calls++;
	fake_main_usage_argv0 = argv ? argv[0] : NULL;
}

static int fake_main_init_bfd_cb(char *fname)
{
	fake_main_init_bfd_calls++;
	if (fname)
		strncpy(fake_main_init_bfd_name, fname,
				sizeof(fake_main_init_bfd_name) - 1);
	return fake_main_init_bfd_ret;
}

static int fake_main_open_cb(const char *path)
{
	int call = ++fake_main_open_calls;

	if (call <= 4)
		fake_main_open_path[call - 1] = path;
	if (fake_main_open_fail_stage == call)
		return -1;
	return call == 1 ? 77 : 88;
}

static int fake_main_dwarf_init_cb(int fd, void **dbg, void **error)
{
	fake_main_dwarf_init_calls++;
	fake_main_dwarf_init_fd = fd;
	if (dbg)
		*dbg = (void *)0xabcdef00UL;
	if (error)
		*error = (void *)0x98760000UL;
	return fake_main_dwarf_init_ret;
}

static void fake_main_init_globals_cb(void *dbg)
{
	fake_main_init_globals_calls++;
	fake_main_init_globals_dbg = dbg;
}

static int fake_main_mcps_cb(void *dbg)
{
	fake_main_mcps_calls++;
	fake_main_mcps_dbg = dbg;
	return 0;
}

static int fake_main_mcvtop_cb(void *dbg, int pid, unsigned long addr)
{
	fake_main_mcvtop_calls++;
	fake_main_mcvtop_dbg = dbg;
	fake_main_mcvtop_pid = pid;
	fake_main_mcvtop_addr = addr;
	return 0;
}

static int fake_main_dwarf_finish_cb(void *dbg, void **error)
{
	(void)error;
	fake_main_dwarf_finish_calls++;
	fake_main_dwarf_finish_dbg = dbg;
	return 0;
}

static int fake_main_close_cb(int fd)
{
	int idx = fake_main_close_calls++;

	if (idx < 4)
		fake_main_close_fd[idx] = fd;
	return 0;
}

static void reset_fake_option_loop(void)
{
	int i;

	fake_option_loop_calls = 0;
	fake_option_loop_argc = 0;
	fake_option_loop_argv = NULL;
	fake_option_loop_shortopts = NULL;
	fake_option_loop_longopts = NULL;
	for (i = 0; i < 8; i++) {
		fake_option_loop_opts[i] = -1;
		fake_option_loop_args[i] = NULL;
		fake_option_loop_set_help[i] = 0;
		fake_option_loop_set_ps[i] = 0;
		fake_option_loop_set_vtop[i] = 0;
		fake_option_loop_set_debug[i] = 0;
	}
}

void mcinspect_print_ps_header_bridge(void)
{
	fake_public_header_calls++;
}

void mcinspect_read_usize_bridge(unsigned long addr, unsigned long *out)
{
	fake_mcps_read_usize_cb(addr, out);
}

void mcinspect_get_swapper_page_table_bridge(void *dbg,
		unsigned long *out)
{
	fake_mcvtop_get_swapper_cb(dbg, out);
}

void mcinspect_print_init_pt_bridge(unsigned long init_pt)
{
	fake_mcvtop_print_init_pt_cb(init_pt);
}

void print_thread(int cpu, unsigned long thread, unsigned long idle,
		int active)
{
	fake_mcps_print_thread_cb(cpu, thread, idle, active);
}

static int fake_option_loop_getopt(int argc, char **argv,
		const char *shortopts, const void *longopts, char **optarg_out)
{
	int idx = fake_option_loop_calls++;

	fake_option_loop_argc = argc;
	fake_option_loop_argv = argv;
	fake_option_loop_shortopts = shortopts;
	fake_option_loop_longopts = longopts;
	if (idx >= 8) {
		if (optarg_out)
			*optarg_out = NULL;
		return -1;
	}
	if (fake_option_loop_set_help[idx])
		help = fake_option_loop_set_help[idx];
	if (fake_option_loop_set_ps[idx])
		ps = fake_option_loop_set_ps[idx];
	if (fake_option_loop_set_vtop[idx])
		vtop = fake_option_loop_set_vtop[idx];
	if (fake_option_loop_set_debug[idx])
		debug = fake_option_loop_set_debug[idx];
	if (optarg_out)
		*optarg_out = fake_option_loop_args[idx];
	return fake_option_loop_opts[idx];
}

int ioctl(int fd, unsigned long request, void *arg)
{
	struct mcinspect_read_desc *desc = arg;
	static const unsigned long payload = 0x1122334455667788UL;
	unsigned long value = fake_kernel_read_ulong(desc->kaddr);
	int ivalue = fake_kernel_read_int(desc->kaddr);

	ioctl_seen_fd = fd;
	ioctl_seen_request = request;
	ioctl_seen_kaddr = desc->kaddr;
	ioctl_seen_len = desc->len;
	ioctl_seen_flags = desc->flags;
	if (desc->len == sizeof(ivalue)) {
		memcpy(desc->ubuf, &ivalue, sizeof(ivalue));
	}
	else {
		if (desc->kaddr == 0xabc000)
			value = payload;
		memcpy(desc->ubuf, &value,
				desc->len < sizeof(value) ? desc->len : sizeof(value));
	}
	return 0;
}

static void capture_usage(char **argv)
{
	FILE *capture = tmpfile();
	int saved_stdout;
	size_t nread;

	require(capture != NULL);
	saved_stdout = dup(fileno(stdout));
	require(saved_stdout >= 0);
	require(fflush(stdout) == 0);
	require(dup2(fileno(capture), fileno(stdout)) >= 0);
	usage(argv);
	require(fflush(stdout) == 0);
	require(dup2(saved_stdout, fileno(stdout)) >= 0);
	close(saved_stdout);
	rewind(capture);
	nread = fread(mcinspect_usage_written, 1,
			sizeof(mcinspect_usage_written) - 1, capture);
	require(ferror(capture) == 0);
	mcinspect_usage_written[nread] = '\0';
	fclose(capture);
}

int main(void)
{
	const char *expected_usage =
		"Usage: mcinspect <options>\n"
		"Inspect internal state of McKernel.\n"
		"\n"
		"Mandatory arguments to long options are mandatory for short options too.\n"
		"    --help                      Display this help message.\n"
		"    --kernel PATH               Path to kernel image.\n"
		"    --ps                        List processes running on LWK.\n"
		"    --vtop                      Dump page tables.\n"
		"    -v, --va ADDR               Dump page tables for ADDR only.\n"
		"    -p, --pid PID               Use process PID for vtop.\n"
		"    --debug                     Enable debug mode.\n"
		"\n"
		"Examples: \n"
		"    mcinspect --kernel=smp-x86/kernel/mckernel.img --ps\n"
		"    mcinspect --kernel=smp-x86/kernel/mckernel.img --vtop --pid 100 --va 0x3fffff800000\n";
	unsigned long digest = 0x6d63696e73706563UL;
	char buf[1024];
	char *argv[] = { "/tmp/mcinspect", NULL };
	char *parsed_kernel_path = NULL;
	unsigned long parsed_vtop_addr = 0;
	int parsed_pid = 0;
	unsigned long read_value = 0;
	unsigned long found_proc = 0;
	int rc;

	require(!strcmp(mcinspect_thread_status_label_result(1), "R"));
	require(!strcmp(mcinspect_thread_status_label_result(2), "IN"));
	require(!strcmp(mcinspect_thread_status_label_result(123), "U"));
	require(!strcmp(mcinspect_thread_active_marker_result(1), ">"));
	require(!strcmp(mcinspect_thread_active_marker_result(0), " "));
	require(!strcmp(mcinspect_thread_comm_result("/sbin/init", 0), "init"));
	require(!strcmp(mcinspect_thread_comm_result(NULL, 1), "(idle)"));
	require(!strcmp(mcinspect_thread_comm_result(NULL, 0), "(unknown)"));
	require(mcinspect_main_preflight_action_result(1, NULL, 0, 0) ==
			MCINSPECT_MAIN_HELP);
	require(mcinspect_main_preflight_action_result(0, NULL, 1, 0) ==
			MCINSPECT_MAIN_MISSING_KERNEL);
	require(mcinspect_main_preflight_action_result(0, "kernel.img", 0, 0) ==
			MCINSPECT_MAIN_NO_ACTION);
	require(mcinspect_main_preflight_action_result(0, "kernel.img", 1, 0) ==
			MCINSPECT_MAIN_CONTINUE);
	require(mcinspect_option_body_result('k', "kernel.img",
			&parsed_kernel_path, &parsed_vtop_addr, &parsed_pid, argv,
			fake_main_usage_cb) == 0);
	require(parsed_kernel_path && !strcmp(parsed_kernel_path, "kernel.img"));
	parsed_vtop_addr = 0;
	require(mcinspect_option_body_result('v', "0x1234",
			&parsed_kernel_path, &parsed_vtop_addr, &parsed_pid, argv,
			fake_main_usage_cb) == 0);
	require(parsed_vtop_addr == 0x1234);
	parsed_pid = 0;
	require(mcinspect_option_body_result('p', "-42",
			&parsed_kernel_path, &parsed_vtop_addr, &parsed_pid, argv,
			fake_main_usage_cb) == 0);
	require(parsed_pid == -42);
	reset_fake_main();
	require(mcinspect_option_body_result('v', "not-hex",
			&parsed_kernel_path, &parsed_vtop_addr, &parsed_pid, argv,
			fake_main_usage_cb) == -1);
	require(fake_main_usage_calls == 1);
	require(mcinspect_option_body_result('k', "kernel.img",
			NULL, &parsed_vtop_addr, &parsed_pid, argv,
			fake_main_usage_cb) == -22);
	reset_fake_option_loop();
	parsed_kernel_path = NULL;
	parsed_vtop_addr = 0;
	parsed_pid = 0;
	fake_option_loop_opts[0] = 'k';
	fake_option_loop_args[0] = "loop.img";
	fake_option_loop_opts[1] = 'v';
	fake_option_loop_args[1] = "0x3456";
	fake_option_loop_opts[2] = 'p';
	fake_option_loop_args[2] = "321";
	fake_option_loop_opts[3] = -1;
	require(mcinspect_option_loop_body_result(3, argv, "+k:v:p:",
			(void *)0xfeedUL, &parsed_kernel_path, &parsed_vtop_addr,
			&parsed_pid, fake_option_loop_getopt,
			fake_main_usage_cb) == 0);
	require(fake_option_loop_calls == 4);
	require(fake_option_loop_argc == 3 && fake_option_loop_argv == argv);
	require(fake_option_loop_shortopts &&
			!strcmp(fake_option_loop_shortopts, "+k:v:p:"));
	require(fake_option_loop_longopts == (void *)0xfeedUL);
	require(parsed_kernel_path && !strcmp(parsed_kernel_path, "loop.img"));
	require(parsed_vtop_addr == 0x3456);
	require(parsed_pid == 321);
	reset_fake_main();
	reset_fake_option_loop();
	fake_option_loop_opts[0] = 'v';
	fake_option_loop_args[0] = "not-hex";
	fake_option_loop_opts[1] = -1;
	require(mcinspect_option_loop_body_result(2, argv, "+k:v:p:",
			NULL, &parsed_kernel_path, &parsed_vtop_addr, &parsed_pid,
			fake_option_loop_getopt, fake_main_usage_cb) == -1);
	require(fake_option_loop_calls == 1);
	require(fake_main_usage_calls == 1);
	require(mcinspect_option_loop_body_result(2, argv, "+k:v:p:",
			NULL, &parsed_kernel_path, &parsed_vtop_addr, &parsed_pid,
			NULL, fake_main_usage_cb) == -22);
	require(mcinspect_option_loop_body_result(2, argv, "+k:v:p:",
			NULL, NULL, &parsed_vtop_addr, &parsed_pid,
			fake_option_loop_getopt, fake_main_usage_cb) == -22);
	mcfd = 55;

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_ps_header_result(buf, sizeof(buf));
	require(rc == (int)strlen(buf));
	require(!strcmp(buf,
		"CPU     TID    PID             Thread ST exe\n"
		"-----------------------------------------------\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_thread_line_result(buf, sizeof(buf), 3, ">", 123,
			456, 0xabcdefUL, "IN", "bash");
	require(rc == (int)strlen(buf));
	require(!strcmp(buf,
		"  3 >   123    456 0x          abcdef IN bash\n"));
	mix(&digest, (unsigned long)rc);

	require(mcinspect_thread_line_result(buf, 8, 3, ">", 123, 456,
			0xabcdefUL, "IN", "bash") < 0);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_usage_result(buf, sizeof(buf), "mcinspect");
	require(rc == (int)strlen(expected_usage));
	require(!strcmp(buf, expected_usage));
	require(mcinspect_usage_result(buf, 24, "mcinspect") < 0);
	memset(mcinspect_usage_written, 0, sizeof(mcinspect_usage_written));
	capture_usage(argv);
	require(!strcmp(mcinspect_usage_written, expected_usage));
	symtab = NULL;
	nsyms = -1;
	require(init_bfd_symbols("kernel.img") == 0);
	require(symbfd == (void *)0x55667788UL);
	require(!strcmp(bfd_openr_name, "kernel.img"));
	require(nsyms == 2);
	require(lookup_bfd_symbol("debug_constants") == 0x2220);
	require(lookup_bfd_symbol("missing") == (unsigned long)-1);
	ihk_read_kernel(0xabc000, sizeof(read_value), &read_value, 1);
	require(read_value == 0x1122334455667788UL);
	require(ioctl_seen_fd == 55);
	require(ioctl_seen_request == IHK_OS_READ_KADDR);
	require(ioctl_seen_kaddr == 0xabc000);
	require(ioctl_seen_len == sizeof(read_value));
	require(ioctl_seen_flags == 1);
	mix(&digest, read_value);
	mix(&digest, ioctl_seen_kaddr);
	mix(&digest, (unsigned long)rc);
	require(mcinspect_init_globals_body_result(0x5000, 0x5010, 0x100,
			0x20, 0x28, 0x30, 0x4, 0x30, 0x34, 0x8,
			0x10, 0x20, 0x28, 0x18, 0x38, 0x40) == 0);
	require(nr_cpus == 2);
	require(clv == 0x1000);
	require(clv_size == 0x100);
	require(clv_runq_offset == 0x20);
	require(clv_idle_offset == 0x28);
	require(clv_current_offset == 0x30);
	require(thread_tid_offset == 0x4);
	require(thread_sched_list_offset == 0x8);
	require(thread_proc_offset == 0x30);
	require(thread_status_offset == 0x34);
	require(process_pid_offset == 0x10);
	require(process_saved_cmdline_offset == 0x20);
	require(process_saved_cmdline_len_offset == 0x28);
	require(process_vm_offset == 0x18);
	require(vm_address_space_offset == 0x38);
	require(address_space_page_table_offset == 0x40);
	mix(&digest, (unsigned long)nr_cpus);
	mix(&digest, clv_current_offset);
	require(find_proc(NULL, 42, &found_proc) == 0);
	require(found_proc == 0x3000);
	require(find_proc(NULL, 7, &found_proc) == -1);
	mix(&digest, found_proc);

	reset_fake_mcvtop();
	require(mcinspect_mcvtop_body_result((void *)0x1234, 99, 0xbeef,
			fake_mcvtop_find_proc_cb, fake_mcvtop_get_swapper_cb,
			fake_mcvtop_read_usize_cb,
			fake_mcvtop_print_init_pt_cb) == 0);
	require(fake_mcvtop_find_calls == 1 &&
			fake_mcvtop_find_dbg == (void *)0x1234 &&
			fake_mcvtop_find_pid == 99);
	require(fake_mcvtop_get_calls == 1 && fake_mcvtop_print_calls == 1 &&
			fake_mcvtop_get_dbg == (void *)0x1234 &&
			fake_mcvtop_print_value == 0x9000);
	require(fake_mcvtop_read_calls == 3);
	require(fake_mcvtop_read_addr[0] == 0x7018 &&
			fake_mcvtop_read_addr[1] == 0x8038 &&
			fake_mcvtop_read_addr[2] == 0x8140);
	reset_fake_mcvtop();
	require(mcinspect_mcvtop_body_result(NULL, 0, 0,
			fake_mcvtop_find_proc_cb, fake_mcvtop_get_swapper_cb,
			fake_mcvtop_read_usize_cb,
			fake_mcvtop_print_init_pt_cb) == 0);
	require(fake_mcvtop_find_calls == 0 && fake_mcvtop_get_calls == 1 &&
			fake_mcvtop_print_calls == 1 &&
			fake_mcvtop_read_calls == 0);
	reset_fake_mcvtop();
	fake_mcvtop_find_ret = -1;
	require(mcinspect_mcvtop_body_result(NULL, 99, 0,
			fake_mcvtop_find_proc_cb, fake_mcvtop_get_swapper_cb,
			fake_mcvtop_read_usize_cb,
			fake_mcvtop_print_init_pt_cb) == -1);
	require(fake_mcvtop_get_calls == 0 && fake_mcvtop_print_calls == 0 &&
			fake_mcvtop_read_calls == 0);
	require(mcinspect_mcvtop_body_result(NULL, 99, 0, NULL,
			fake_mcvtop_get_swapper_cb, fake_mcvtop_read_usize_cb,
			fake_mcvtop_print_init_pt_cb) == -22);
	mix(&digest, fake_mcvtop_read_addr[2]);

	reset_fake_mcps();
	require(mcinspect_mcps_body_result(fake_mcps_read_usize_cb,
			fake_mcps_print_thread_cb) == 0);
	require(fake_mcps_read_calls == 7);
	require(fake_mcps_print_calls == 5);
	require(fake_mcps_print_cpu[0] == 0 &&
			fake_mcps_print_thread[0] == 0x2000 &&
			fake_mcps_print_idle[0] == 0x1028 &&
			fake_mcps_print_active[0] == 1);
	require(fake_mcps_print_cpu[1] == 0 &&
			fake_mcps_print_thread[1] == 0x1028 &&
			fake_mcps_print_idle[1] == 0x1028 &&
			fake_mcps_print_active[1] == 0);
	require(fake_mcps_print_cpu[2] == 1 &&
			fake_mcps_print_thread[2] == 0x1128 &&
			fake_mcps_print_idle[2] == 0x1128 &&
			fake_mcps_print_active[2] == 1);
	require(fake_mcps_print_cpu[3] == 1 &&
			fake_mcps_print_thread[3] == 0x3000 &&
			fake_mcps_print_idle[3] == 0x1128 &&
			fake_mcps_print_active[3] == 0);
	require(fake_mcps_print_cpu[4] == 1 &&
			fake_mcps_print_thread[4] == 0x3100 &&
			fake_mcps_print_idle[4] == 0x1128 &&
			fake_mcps_print_active[4] == 0);
	require(mcinspect_mcps_body_result(NULL,
			fake_mcps_print_thread_cb) == -22);
	mix(&digest, (unsigned long)fake_mcps_print_calls);

	reset_fake_mcps();
	fake_public_header_calls = 0;
	require(mcps(NULL) == 0);
	require(fake_public_header_calls == 0);
	require(fake_mcps_read_calls == 7);
	require(fake_mcps_print_calls == 5);
	mix(&digest, (unsigned long)fake_mcps_read_calls);

	reset_fake_mcvtop();
	require(mcvtop((void *)0x4567, 0, 0x55) == 0);
	require(fake_mcvtop_get_calls == 1 &&
			fake_mcvtop_get_dbg == (void *)0x4567 &&
			fake_mcvtop_print_calls == 1 &&
			fake_mcvtop_read_calls == 0);
	mix(&digest, fake_mcvtop_print_value);

	reset_fake_main();
	rc = mcinspect_main_body_result(argv, 0, "kernel.img", 1, 1, 123,
			0xdeadbeefUL, fake_main_usage_cb,
			fake_main_init_bfd_cb, fake_main_open_cb,
			fake_main_dwarf_init_cb, fake_main_init_globals_cb,
			fake_main_mcps_cb, fake_main_mcvtop_cb,
			fake_main_dwarf_finish_cb, fake_main_close_cb);
	require(rc == 0);
	require(fake_main_usage_calls == 0);
	require(fake_main_init_bfd_calls == 1);
	require(!strcmp(fake_main_init_bfd_name, "kernel.img"));
	require(fake_main_open_calls == 2);
	require(!strcmp(fake_main_open_path[0], "/dev/mcos0"));
	require(!strcmp(fake_main_open_path[1], "kernel.img"));
	require(mcfd == 77);
	require(fake_main_dwarf_init_calls == 1);
	require(fake_main_dwarf_init_fd == 88);
	require(fake_main_init_globals_calls == 1 &&
			fake_main_init_globals_dbg == (void *)0xabcdef00UL);
	require(fake_main_mcps_calls == 1 &&
			fake_main_mcps_dbg == (void *)0xabcdef00UL);
	require(fake_main_mcvtop_calls == 1 &&
			fake_main_mcvtop_dbg == (void *)0xabcdef00UL &&
			fake_main_mcvtop_pid == 123 &&
			fake_main_mcvtop_addr == 0xdeadbeefUL);
	require(fake_main_dwarf_finish_calls == 1 &&
			fake_main_dwarf_finish_dbg == (void *)0xabcdef00UL);
	require(fake_main_close_calls == 2 &&
			fake_main_close_fd[0] == 88 &&
			fake_main_close_fd[1] == 77);
	mix(&digest, (unsigned long)fake_main_close_calls);
	mix(&digest, fake_main_mcvtop_addr);

	reset_fake_main();
	rc = mcinspect_main_body_result(argv, 1, NULL, 0, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 0 && fake_main_usage_calls == 1 &&
			fake_main_usage_argv0 == argv[0] &&
			fake_main_init_bfd_calls == 0);

	reset_fake_main();
	rc = mcinspect_main_body_result(argv, 0, NULL, 1, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 1 && fake_main_usage_calls == 1 &&
			fake_main_init_bfd_calls == 0);

	reset_fake_main();
	fake_main_init_bfd_ret = -1;
	rc = mcinspect_main_body_result(argv, 0, "kernel.img", 1, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 1 && fake_main_init_bfd_calls == 1 &&
			fake_main_open_calls == 0);

	reset_fake_main();
	fake_main_open_fail_stage = 1;
	rc = mcinspect_main_body_result(argv, 0, "kernel.img", 1, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 1 && fake_main_open_calls == 1 &&
			fake_main_dwarf_init_calls == 0);

	reset_fake_main();
	fake_main_open_fail_stage = 2;
	rc = mcinspect_main_body_result(argv, 0, "kernel.img", 1, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 1 && fake_main_open_calls == 2 &&
			fake_main_dwarf_init_calls == 0);

	reset_fake_main();
	fake_main_dwarf_init_ret = -1;
	rc = mcinspect_main_body_result(argv, 0, "kernel.img", 1, 0, 0, 0,
			fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb);
	require(rc == 1 && fake_main_dwarf_init_calls == 1 &&
			fake_main_init_globals_calls == 0);
	require(mcinspect_main_body_result(argv, 0, "kernel.img", 1, 0, 0, 0,
			NULL, fake_main_init_bfd_cb, fake_main_open_cb,
			fake_main_dwarf_init_cb, fake_main_init_globals_cb,
			fake_main_mcps_cb, fake_main_mcvtop_cb,
			fake_main_dwarf_finish_cb, fake_main_close_cb) == -22);

	reset_fake_main();
	reset_fake_option_loop();
	debug = 77;
	mcfd = 66;
	help = 55;
	ps = 44;
	vtop = 33;
	pid = 22;
	vtop_addr = 11;
	fake_option_loop_opts[0] = 'k';
	fake_option_loop_args[0] = "entry.img";
	fake_option_loop_opts[1] = 0;
	fake_option_loop_set_vtop[1] = 1;
	fake_option_loop_opts[2] = 'v';
	fake_option_loop_args[2] = "0x4444";
	fake_option_loop_opts[3] = 'p';
	fake_option_loop_args[3] = "654";
	fake_option_loop_opts[4] = -1;
	rc = mcinspect_main_entry_result(5, argv, "+k:v:p:", (void *)0xbeefUL,
			fake_option_loop_getopt, fake_main_usage_cb,
			fake_main_init_bfd_cb, fake_main_open_cb,
			fake_main_dwarf_init_cb, fake_main_init_globals_cb,
			fake_main_mcps_cb, fake_main_mcvtop_cb,
			fake_main_dwarf_finish_cb, fake_main_close_cb);
	require(rc == 0);
	require(fake_option_loop_calls == 5);
	require(fake_option_loop_argc == 5 && fake_option_loop_argv == argv);
	require(fake_option_loop_shortopts &&
			!strcmp(fake_option_loop_shortopts, "+k:v:p:"));
	require(fake_option_loop_longopts == (void *)0xbeefUL);
	require(debug == 0 && help == 0 && ps == 0 && vtop == 1);
	require(pid == 654 && vtop_addr == 0x4444);
	require(fake_main_init_bfd_calls == 1 &&
			!strcmp(fake_main_init_bfd_name, "entry.img"));
	require(fake_main_mcps_calls == 0 && fake_main_mcvtop_calls == 1);
	require(fake_main_mcvtop_pid == 654 &&
			fake_main_mcvtop_addr == 0x4444);
	require(fake_main_close_calls == 2 && mcfd == 77);
	mix(&digest, (unsigned long)fake_option_loop_calls);
	mix(&digest, vtop_addr);

	reset_fake_main();
	reset_fake_option_loop();
	fake_option_loop_opts[0] = 'v';
	fake_option_loop_args[0] = "not-hex";
	fake_option_loop_opts[1] = -1;
	rc = mcinspect_main_entry_result(2, argv, "+k:v:p:", NULL,
			fake_option_loop_getopt, fake_main_usage_cb,
			fake_main_init_bfd_cb, fake_main_open_cb,
			fake_main_dwarf_init_cb, fake_main_init_globals_cb,
			fake_main_mcps_cb, fake_main_mcvtop_cb,
			fake_main_dwarf_finish_cb, fake_main_close_cb);
	require(rc == 1 && fake_option_loop_calls == 1);
	require(fake_main_usage_calls == 1 && fake_main_init_bfd_calls == 0);
	require(mcfd == -1);
	require(mcinspect_main_entry_result(1, argv, "+k:v:p:", NULL,
			NULL, fake_main_usage_cb, fake_main_init_bfd_cb,
			fake_main_open_cb, fake_main_dwarf_init_cb,
			fake_main_init_globals_cb, fake_main_mcps_cb,
			fake_main_mcvtop_cb, fake_main_dwarf_finish_cb,
			fake_main_close_cb) == -22);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_invalid_va_error_result(buf, sizeof(buf));
	require(rc == (int)strlen("error: invalid VA? (expected format: 0xXXXX)\n\n"));
	require(!strcmp(buf, "error: invalid VA? (expected format: 0xXXXX)\n\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_missing_kernel_error_result(buf, sizeof(buf));
	require(rc == (int)strlen("error: you must specify the kernel image\n\n"));
	require(!strcmp(buf, "error: you must specify the kernel image\n\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_pid_line_result(buf, sizeof(buf), -42);
	require(rc == (int)strlen("PID: -42\n"));
	require(!strcmp(buf, "PID: -42\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_no_symbols_line_result(buf, sizeof(buf));
	require(rc == (int)strlen("no symbols\n"));
	require(!strcmp(buf, "no symbols\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_elf_image_error_result(buf, sizeof(buf),
			"/tmp/mckernel.img");
	require(rc == (int)strlen("error: accessing ELF image /tmp/mckernel.img\n"));
	require(!strcmp(buf, "error: accessing ELF image /tmp/mckernel.img\n"));
	require(mcinspect_elf_image_error_result(buf, 24,
			"/tmp/mckernel.img") < 0);
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_open_os_device_error_result(buf, sizeof(buf));
	require(rc == (int)strlen("error: opening IHK OS device file\n"));
	require(!strcmp(buf, "error: opening IHK OS device file\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_open_kernel_error_result(buf, sizeof(buf),
			"/tmp/mckernel.img");
	require(rc == (int)strlen("error: opening /tmp/mckernel.img\n"));
	require(!strcmp(buf, "error: opening /tmp/mckernel.img\n"));
	mix(&digest, (unsigned long)rc);

	memset(buf, 0, sizeof(buf));
	rc = mcinspect_dwarf_info_error_result(buf, sizeof(buf));
	require(rc == (int)strlen("error: accessing DWARF information\n"));
	require(!strcmp(buf, "error: accessing DWARF information\n"));
	mix(&digest, (unsigned long)rc);

	printf("mcinspect_helpers ok digest=%016lx\n", digest);
	return 0;
}
