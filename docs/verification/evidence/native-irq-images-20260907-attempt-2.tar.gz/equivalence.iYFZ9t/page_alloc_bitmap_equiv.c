extern int printf(const char *, ...);
extern void exit(int);
extern void abort(void);

#ifndef NULL
#define NULL ((void *)0)
#endif

#define ARENA_BASE 0x4000000UL
#define ARENA_PAGES 256
#define ARENA_SIZE (ARENA_PAGES * LOCAL_PAGE_SIZE)
#define LOCAL_PAGE_SIZE 4096UL

static unsigned char initial_desc[4096] __attribute__((aligned(64)));
static unsigned char page_arena[ARENA_SIZE];

#ifdef MCKERNEL_RUST_PAGEALLOC_BITMAP
extern unsigned long linux_page_offset_base;
#endif

int ihk_mc_chk_page_address(unsigned long mem_addr)
{
	(void)mem_addr;
	return 0;
}

unsigned long virt_to_phys(void *v)
{
	return (unsigned long)v;
}

void *phys_to_virt(unsigned long p)
{
	if (p < ARENA_BASE || p >= ARENA_BASE + ARENA_SIZE)
		exit(92);
	return page_arena + (p - ARENA_BASE);
}

__attribute__((weak)) int kprintf(const char *format, ...)
{
	(void)format;
	return 0;
}

__attribute__((weak)) void panic(const char *message)
{
	(void)message;
	abort();
}

void preempt_disable(void) {}
void preempt_enable(void) {}
void cpu_pause(void) {}
unsigned long cpu_disable_interrupt_save(void) { return 0; }
void cpu_restore_interrupt(unsigned long irqstate) { (void)irqstate; }
struct cpu_local_var;
static unsigned char fake_pagealloc_cpu_local[8192] __attribute__((aligned(64)));
__attribute__((weak)) struct cpu_local_var *get_this_cpu_local_var(void)
{
	return (struct cpu_local_var *)fake_pagealloc_cpu_local;
}

#include "lib/page_alloc.c"

#ifdef MCKERNEL_RUST_PAGEALLOC_BITMAP
extern unsigned long __ihk_pagealloc_alloc_locked_result(
	struct ihk_page_allocator_desc *, int, int, unsigned long,
	unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int __ihk_pagealloc_reserve_locked_result(
	struct ihk_page_allocator_desc *, unsigned long, unsigned long,
	unsigned long, unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int __ihk_pagealloc_free_locked_result(
	struct ihk_page_allocator_desc *, unsigned long, int, unsigned long *,
	unsigned long, unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern unsigned long __ihk_pagealloc_count_locked_result(
	struct ihk_page_allocator_desc *, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int __ihk_pagealloc_query_free_locked_result(
	struct ihk_page_allocator_desc *, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int __ihk_pagealloc_zero_free_pages_locked_result(
	struct ihk_page_allocator_desc *, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern void *pagealloc_public_init_result(unsigned long, unsigned long,
	unsigned long, void *, unsigned long *, unsigned long, int,
	unsigned long, unsigned long, void *(*)(int, int),
	void (*)(unsigned long), void (*)(unsigned long, unsigned long,
	unsigned long));
extern unsigned long pagealloc_public_alloc_result(void *, int, int,
	unsigned long, unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int pagealloc_public_reserve_result(void *, unsigned long,
	unsigned long, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int pagealloc_public_free_result(void *, unsigned long, int,
	unsigned long, unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long), void (*)(unsigned long));
extern unsigned long pagealloc_public_count_result(void *, unsigned long,
	unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int pagealloc_public_query_free_result(void *, unsigned long,
	unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int pagealloc_public_zero_free_pages_result(void *, unsigned long,
	unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long), void (*)(int));
#else
unsigned long __ihk_pagealloc_alloc_locked_result(
	struct ihk_page_allocator_desc *desc, int npages, int p2align,
	unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	unsigned long addr;

	if (!desc || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	addr = ihk_pagealloc_alloc(desc, npages, p2align);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return addr;
}

int __ihk_pagealloc_reserve_locked_result(
	struct ihk_page_allocator_desc *desc, unsigned long start,
	unsigned long end, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	if (!desc || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	ihk_pagealloc_reserve(desc, start, end);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return 1;
}

int __ihk_pagealloc_free_locked_result(
	struct ihk_page_allocator_desc *desc, unsigned long address, int npages,
	unsigned long *bad_address, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	if (!desc || npages <= 0 || !lock_fn || !unlock_fn)
		return EINVAL;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	ihk_pagealloc_free(desc, address, npages);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return 0;
}

unsigned long __ihk_pagealloc_count_locked_result(
	struct ihk_page_allocator_desc *desc, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	unsigned long count;

	if (!desc || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	count = ihk_pagealloc_count(desc);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return count;
}

int __ihk_pagealloc_query_free_locked_result(
	struct ihk_page_allocator_desc *desc, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	int count;

	if (!desc || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	count = ihk_pagealloc_query_free(desc);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return count;
}

int __ihk_pagealloc_zero_free_pages_locked_result(
	struct ihk_page_allocator_desc *desc, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	if (!desc || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	__ihk_pagealloc_zero_free_pages(desc);
	unlock_fn((unsigned long)desc + lock_offset, lock_node_addr);
	return 1;
}

void *pagealloc_public_init_result(unsigned long start, unsigned long size,
	unsigned long unit, void *initial, unsigned long *pdescsize,
	unsigned long desc_struct_size, int alloc_flag,
	unsigned long page_size, unsigned long lock_offset,
	void *(*alloc_pages_fn)(int, int), void (*lock_init_fn)(unsigned long),
	void (*init_fail_log_fn)(unsigned long, unsigned long, unsigned long))
{
	struct ihk_page_allocator_desc *desc;
	int page_shift = 0;
	int mapsize = 0;
	int mapaligned = 0;
	int desc_pages = 0;

	if (pagealloc_init_layout_result(size, unit, desc_struct_size,
			&page_shift, &mapsize, &mapaligned, &desc_pages))
		return NULL;

	if (initial) {
		desc = initial;
		if (pdescsize)
			*pdescsize = desc_pages;
	} else {
		if (!alloc_pages_fn)
			return NULL;
		desc = alloc_pages_fn(desc_pages, alloc_flag);
	}

	if (!desc) {
		if (init_fail_log_fn)
			init_fail_log_fn(start, size, unit);
		return NULL;
	}

	if (!lock_init_fn)
		return NULL;

	pagealloc_desc_reset_result(desc, desc_pages, page_size);
	pagealloc_desc_init_result(desc, start, size, page_shift, mapaligned,
		desc_pages);
	lock_init_fn((unsigned long)desc + lock_offset);
	pagealloc_reserve_tail_result(desc->map, mapsize, mapaligned * 8);

	return desc;
}

unsigned long pagealloc_public_alloc_result(void *desc, int npages,
	int p2align, unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	return __ihk_pagealloc_alloc_locked_result(desc, npages, p2align,
		lock_offset, lock_node_addr, lock_fn, unlock_fn);
}

int pagealloc_public_reserve_result(void *desc, unsigned long start,
	unsigned long end, unsigned long lock_offset,
	unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	return __ihk_pagealloc_reserve_locked_result(desc, start, end,
		lock_offset, lock_node_addr, lock_fn, unlock_fn);
}

int pagealloc_public_free_result(void *desc, unsigned long address,
	int npages, unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long),
	void (*error_fn)(unsigned long))
{
	unsigned long bad_address = address;
	int rc = __ihk_pagealloc_free_locked_result(desc, address, npages,
		&bad_address, lock_offset, lock_node_addr, lock_fn, unlock_fn);

	if (rc && error_fn)
		error_fn(bad_address);
	return rc;
}

unsigned long pagealloc_public_count_result(void *desc,
	unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	return __ihk_pagealloc_count_locked_result(desc, lock_offset,
		lock_node_addr, lock_fn, unlock_fn);
}

int pagealloc_public_query_free_result(void *desc, unsigned long lock_offset,
	unsigned long lock_node_addr, void (*lock_fn)(unsigned long,
	unsigned long), void (*unlock_fn)(unsigned long, unsigned long))
{
	return __ihk_pagealloc_query_free_locked_result(desc, lock_offset,
		lock_node_addr, lock_fn, unlock_fn);
}

int pagealloc_public_zero_free_pages_result(void *desc,
	unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long), void (*log_fn)(int))
{
	int rc;

	if (log_fn)
		log_fn(PAGEALLOC_ZERO_LOG_BEGIN);
	rc = __ihk_pagealloc_zero_free_pages_locked_result(desc, lock_offset,
		lock_node_addr, lock_fn, unlock_fn);
	if (log_fn)
		log_fn(PAGEALLOC_ZERO_LOG_DONE);
	return rc;
}
#endif

#ifdef MCKERNEL_RUST_PAGE_ALLOC_RBTREE
extern unsigned long __ihk_numa_alloc_pages_locked_result(
	struct ihk_mc_numa_node *, int, int, unsigned long, unsigned long,
	void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
extern int __ihk_numa_free_pages_direct_locked_result(
	struct ihk_mc_numa_node *, unsigned long, int, unsigned long,
	unsigned long, void (*)(unsigned long, unsigned long),
	void (*)(unsigned long, unsigned long));
#else
unsigned long __ihk_numa_alloc_pages_locked_result(
	struct ihk_mc_numa_node *node, int npages, int p2align,
	unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	unsigned long addr;

	if (!node || !lock_fn || !unlock_fn)
		return 0;

	lock_fn((unsigned long)node + lock_offset, lock_node_addr);
	addr = __page_alloc_rbtree_alloc_pages(&node->free_chunks,
					       npages, p2align);
	if (addr)
		node->nr_free_pages -= npages;
	unlock_fn((unsigned long)node + lock_offset, lock_node_addr);
	return addr;
}

int __ihk_numa_free_pages_direct_locked_result(
	struct ihk_mc_numa_node *node, unsigned long addr, int npages,
	unsigned long lock_offset, unsigned long lock_node_addr,
	void (*lock_fn)(unsigned long, unsigned long),
	void (*unlock_fn)(unsigned long, unsigned long))
{
	int rc;

	if (!node || npages <= 0 || !lock_fn || !unlock_fn)
		return EINVAL;

	lock_fn((unsigned long)node + lock_offset, lock_node_addr);
	rc = __page_alloc_rbtree_free_range(&node->free_chunks, addr,
					    npages << PAGE_SHIFT);
	if (!rc)
		node->nr_free_pages += npages;
	unlock_fn((unsigned long)node + lock_offset, lock_node_addr);
	return rc;
}
#endif

#ifndef MCKERNEL_RUST_PAGEALLOC_BITMAP
int cpu_local_var_initialized;
#endif

__attribute__((weak)) int ihk_mc_get_processor_id(void)
{
	return 0;
}

#ifndef MCKERNEL_RUST_PAGEALLOC_BITMAP
struct cpu_local_var *get_cpu_local_var(int id)
{
	(void)id;
	return NULL;
}
#endif

int ihk_ikc_send(struct ihk_ikc_channel_desc *channel, void *p, int opt)
{
	(void)channel;
	(void)p;
	(void)opt;
	return 0;
}

static struct ihk_mc_numa_node *test_numa_nodes[4];
static int test_nr_numa_nodes;

int ihk_mc_get_nr_numa_nodes(void)
{
	return test_nr_numa_nodes;
}

struct ihk_mc_numa_node *ihk_mc_get_numa_node_by_distance(int i)
{
	if (i < 0 || i >= test_nr_numa_nodes)
		return NULL;
	return test_numa_nodes[i];
}

static unsigned char page_cache_pages[256][LOCAL_PAGE_SIZE]
	__attribute__((aligned(4096)));
static int page_cache_alloc_cursor;
static int page_cache_alloc_limit;
static int page_cache_alloc_calls;

static void reset_page_cache_pool(int limit)
{
	memset(page_cache_pages, 0xa5, sizeof(page_cache_pages));
	page_cache_alloc_cursor = 0;
	page_cache_alloc_limit = limit;
	page_cache_alloc_calls = 0;
}

void *_ihk_mc_alloc_aligned_pages_node(int npages, int p2align,
	ihk_mc_ap_flag flag, int node, int is_user, uintptr_t virt_addr,
	char *file, int line)
{
	page_cache_alloc_calls++;
	if (npages != 1 || p2align != PAGE_P2ALIGN ||
			flag != IHK_MC_AP_NOWAIT)
		exit(95);
	(void)node;
	(void)is_user;
	(void)virt_addr;
	(void)file;
	(void)line;
	if (page_cache_alloc_cursor < page_cache_alloc_limit)
		return page_cache_pages[page_cache_alloc_cursor++];
	return NULL;
}

void _ihk_mc_free_pages(void *ptr, int npages, int is_user, char *file, int line)
{
	(void)ptr;
	(void)npages;
	(void)is_user;
	(void)file;
	(void)line;
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void require_at(int condition, int line)
{
	if (!condition) {
		printf("require failed line=%d\n", line);
		exit(91);
	}
}

#define require(condition) require_at((condition), __LINE__)

static unsigned long mcs_lock_log[8][2];
static unsigned long mcs_unlock_log[8][2];
static int mcs_lock_count;
static int mcs_unlock_count;

static void reset_mcs_trace(void)
{
	for (int i = 0; i < 8; i++) {
		mcs_lock_log[i][0] = 0;
		mcs_lock_log[i][1] = 0;
		mcs_unlock_log[i][0] = 0;
		mcs_unlock_log[i][1] = 0;
	}
	mcs_lock_count = 0;
	mcs_unlock_count = 0;
}

static void fake_mcs_lock(unsigned long lock_addr, unsigned long lock_node_addr)
{
	require(mcs_lock_count < 8);
	mcs_lock_log[mcs_lock_count][0] = lock_addr;
	mcs_lock_log[mcs_lock_count][1] = lock_node_addr;
	mcs_lock_count++;
}

static void fake_mcs_unlock(unsigned long lock_addr, unsigned long lock_node_addr)
{
	require(mcs_unlock_count < 8);
	mcs_unlock_log[mcs_unlock_count][0] = lock_addr;
	mcs_unlock_log[mcs_unlock_count][1] = lock_node_addr;
	mcs_unlock_count++;
}

static unsigned long irq_cookie = 0xfacefeed12345678UL;
static int irq_save_count;
static int irq_restore_count;
static unsigned long irq_restore_cookie;

static unsigned long fake_irq_save(void)
{
	irq_save_count++;
	return irq_cookie;
}

static void fake_irq_restore(unsigned long irqstate)
{
	irq_restore_count++;
	irq_restore_cookie = irqstate;
}

static void reset_irq_trace(void)
{
	irq_save_count = 0;
	irq_restore_count = 0;
	irq_restore_cookie = 0;
}

static int top_free_send_count;
static int top_free_send_rc;
static unsigned long top_free_send_packet;
static int top_free_log_count;
static unsigned long top_free_expected_node;
static unsigned long top_free_log_digest;
static int top_alloc_log_count;
static unsigned long top_alloc_expected_node;
static unsigned long top_alloc_log_digest;
static int top_add_free_log_count;
static unsigned long top_add_free_expected_node;
static unsigned long top_add_free_log_digest;

static int fake_top_free_send(unsigned long packet_addr)
{
	top_free_send_count++;
	top_free_send_packet = packet_addr;
	return top_free_send_rc;
}

static void fake_top_free_log(int event, unsigned long node_addr,
			      unsigned long addr, int npages,
			      int zero_at_free_value, int detail)
{
	top_free_log_count++;
	mix(&top_free_log_digest, (unsigned long)event);
	mix(&top_free_log_digest,
	    (unsigned long)(node_addr == top_free_expected_node));
	mix(&top_free_log_digest, addr);
	mix(&top_free_log_digest, (unsigned long)npages);
	mix(&top_free_log_digest, (unsigned long)zero_at_free_value);
	mix(&top_free_log_digest, (unsigned long)(int)detail);
}

static void reset_top_free_trace(int send_rc)
{
	top_free_send_count = 0;
	top_free_send_rc = send_rc;
	top_free_send_packet = 0;
	top_free_log_count = 0;
	top_free_expected_node = 0;
	top_free_log_digest = 0x746f706672656521UL;
}

static void fake_top_alloc_log(int event, unsigned long node_addr,
			       unsigned long addr, int npages, int source)
{
	top_alloc_log_count++;
	mix(&top_alloc_log_digest, (unsigned long)event);
	mix(&top_alloc_log_digest,
	    (unsigned long)(node_addr == top_alloc_expected_node));
	mix(&top_alloc_log_digest, addr);
	mix(&top_alloc_log_digest, (unsigned long)npages);
	mix(&top_alloc_log_digest, (unsigned long)source);
}

static void reset_top_alloc_trace(void)
{
	top_alloc_log_count = 0;
	top_alloc_expected_node = 0;
	top_alloc_log_digest = 0x746f70616c6c6f63UL;
}

static void fake_top_add_free_log(int event, unsigned long node_addr,
				  unsigned long addr, unsigned long size,
				  int rc)
{
	top_add_free_log_count++;
	mix(&top_add_free_log_digest, (unsigned long)event);
	mix(&top_add_free_log_digest,
	    (unsigned long)(node_addr == top_add_free_expected_node));
	mix(&top_add_free_log_digest, addr);
	mix(&top_add_free_log_digest, size);
	mix(&top_add_free_log_digest, (unsigned long)(int)rc);
}

static void reset_top_add_free_trace(void)
{
	top_add_free_log_count = 0;
	top_add_free_expected_node = 0;
	top_add_free_log_digest = 0x6164646672656521UL;
}

static void *pagealloc_destroy_free_ptr;
static int pagealloc_destroy_free_pages;
static int pagealloc_destroy_free_count;

static void reset_pagealloc_destroy_trace(void)
{
	pagealloc_destroy_free_ptr = NULL;
	pagealloc_destroy_free_pages = -1;
	pagealloc_destroy_free_count = 0;
}

static void fake_pagealloc_destroy_free_pages(void *ptr, int npages)
{
	pagealloc_destroy_free_ptr = ptr;
	pagealloc_destroy_free_pages = npages;
	pagealloc_destroy_free_count++;
}

static unsigned long pagealloc_destroy_orchestration_digest(void)
{
	struct ihk_page_allocator_desc desc;
	unsigned long digest = 0x706164657374726fUL;
	int pages;

	memset(&desc, 0, sizeof(desc));
	desc.flag = 7;

	reset_pagealloc_destroy_trace();
	pages = pagealloc_destroy_result(&desc, fake_pagealloc_destroy_free_pages);
	require(pages == 7);
	require(pagealloc_destroy_free_ptr == &desc);
	require(pagealloc_destroy_free_pages == 7);
	require(pagealloc_destroy_free_count == 1);
	mix(&digest, (unsigned long)pages);
	mix(&digest, (unsigned long)pagealloc_destroy_free_count);

	reset_pagealloc_destroy_trace();
	pages = pagealloc_destroy_result(NULL, fake_pagealloc_destroy_free_pages);
	require(pages == 0);
	require(pagealloc_destroy_free_count == 0);
	mix(&digest, (unsigned long)pages);

	reset_pagealloc_destroy_trace();
	pages = pagealloc_destroy_result(&desc, NULL);
	require(pages == 0);
	require(pagealloc_destroy_free_count == 0);
	mix(&digest, (unsigned long)pagealloc_destroy_free_count);

	desc.flag = 0;
	reset_pagealloc_destroy_trace();
	pages = pagealloc_destroy_result(&desc, fake_pagealloc_destroy_free_pages);
	require(pages == 0);
	require(pagealloc_destroy_free_ptr == &desc);
	require(pagealloc_destroy_free_pages == 0);
	require(pagealloc_destroy_free_count == 1);
	mix(&digest, (unsigned long)pagealloc_destroy_free_count);

	return digest;
}

static void fill_page_arena(unsigned char value);
static void require_page_bytes(int page, int start, unsigned char expected);

static unsigned long pagealloc_locked_orchestration_digest(void)
{
	unsigned char locked_desc[4096] __attribute__((aligned(64)));
	struct ihk_page_allocator_desc *desc;
	unsigned long desc_pages = 0;
	mcs_lock_node_t lock_node;
	unsigned long lock_offset =
		__builtin_offsetof(struct ihk_page_allocator_desc, lock);
	unsigned long lock_node_addr = (unsigned long)&lock_node;
	unsigned long lock_addr;
	unsigned long digest = 0x6269746d61706c6bUL;
	unsigned long addr;
	unsigned long bad_address = 0xdeadbeefUL;
	int rc;

	memset(locked_desc, 0xcc, sizeof(locked_desc));
	memset(&lock_node, 0, sizeof(lock_node));
	desc = __ihk_pagealloc_init(ARENA_BASE, 32 * LOCAL_PAGE_SIZE,
				    LOCAL_PAGE_SIZE, locked_desc, &desc_pages);
	require(desc == (struct ihk_page_allocator_desc *)locked_desc);
	require(desc_pages == 1);
	lock_addr = (unsigned long)&desc->lock;

	reset_mcs_trace();
	addr = __ihk_pagealloc_alloc_locked_result(desc, 1, 0,
		lock_offset, lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(addr == ARENA_BASE);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(mcs_lock_log[0][0] == lock_addr);
	require(mcs_lock_log[0][1] == lock_node_addr);
	require(mcs_unlock_log[0][0] == lock_addr);
	require(mcs_unlock_log[0][1] == lock_node_addr);
	mix(&digest, addr);
	mix(&digest, ihk_pagealloc_count(desc));
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	reset_mcs_trace();
	rc = __ihk_pagealloc_reserve_locked_result(desc,
		ARENA_BASE + 8 * LOCAL_PAGE_SIZE,
		ARENA_BASE + 10 * LOCAL_PAGE_SIZE, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 1);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	mix(&digest, (unsigned long)rc);
	mix(&digest, ihk_pagealloc_count(desc));

	reset_mcs_trace();
	require(__ihk_pagealloc_count_locked_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock) == 29);
	require(__ihk_pagealloc_query_free_locked_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock) == 29);
	require(mcs_lock_count == 2);
	require(mcs_unlock_count == 2);
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	reset_mcs_trace();
	rc = __ihk_pagealloc_free_locked_result(desc, addr, 1, &bad_address,
		lock_offset, lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 0);
	require(bad_address == 0xdeadbeefUL);
	require(ihk_pagealloc_count(desc) == 30);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	mix(&digest, (unsigned long)rc);
	mix(&digest, ihk_pagealloc_count(desc));

	fill_page_arena(0x99);
	reset_mcs_trace();
	rc = __ihk_pagealloc_zero_free_pages_locked_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 1);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require_page_bytes(0, 0, 0);
	require_page_bytes(8, 0, 0x99);
	mix(&digest, (unsigned long)rc);
	mix(&digest, (unsigned long)mcs_lock_count);

	reset_mcs_trace();
	require(__ihk_pagealloc_alloc_locked_result(desc, 1, 0,
		lock_offset, lock_node_addr, NULL, fake_mcs_unlock) == 0);
	require(__ihk_pagealloc_reserve_locked_result(desc, ARENA_BASE,
		ARENA_BASE + LOCAL_PAGE_SIZE, lock_offset, lock_node_addr,
		fake_mcs_lock, NULL) == 0);
	require(__ihk_pagealloc_free_locked_result(desc, addr, 1,
		&bad_address, lock_offset, lock_node_addr, NULL,
		fake_mcs_unlock) == EINVAL);
	require(__ihk_pagealloc_zero_free_pages_locked_result(NULL,
		lock_offset, lock_node_addr, fake_mcs_lock, fake_mcs_unlock) == 0);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	return digest;
}

static int public_init_fail_count;
static unsigned long public_init_fail_digest;
static int public_lock_init_count;
static unsigned long public_lock_init_addr;
static int public_alloc_pages_count;
static int public_alloc_pages_fail;
static unsigned char public_alloc_desc[4096] __attribute__((aligned(64)));
static int public_free_error_count;
static unsigned long public_free_error_addr;
static int public_zero_log_count;
static unsigned long public_zero_log_digest;

static void reset_public_pagealloc_trace(void)
{
	public_init_fail_count = 0;
	public_init_fail_digest = 0x707562696e697421UL;
	public_lock_init_count = 0;
	public_lock_init_addr = 0;
	public_alloc_pages_count = 0;
	public_alloc_pages_fail = 0;
	public_free_error_count = 0;
	public_free_error_addr = 0;
	public_zero_log_count = 0;
	public_zero_log_digest = 0x7075627a65726f21UL;
}

static void fake_public_init_fail_log(unsigned long start,
				      unsigned long size, unsigned long unit)
{
	public_init_fail_count++;
	mix(&public_init_fail_digest, start);
	mix(&public_init_fail_digest, size);
	mix(&public_init_fail_digest, unit);
}

static void fake_public_lock_init(unsigned long lock_addr)
{
	public_lock_init_count++;
	public_lock_init_addr = lock_addr;
}

static void *fake_public_alloc_pages(int npages, int flag)
{
	public_alloc_pages_count++;
	mix(&public_init_fail_digest, (unsigned long)npages);
	mix(&public_init_fail_digest, (unsigned long)flag);
	if (public_alloc_pages_fail)
		return NULL;
	return public_alloc_desc;
}

static void fake_public_free_error(unsigned long bad_address)
{
	public_free_error_count++;
	public_free_error_addr = bad_address;
}

static void fake_public_zero_log(int event)
{
	public_zero_log_count++;
	mix(&public_zero_log_digest, (unsigned long)event);
}

static unsigned long pagealloc_public_orchestration_digest(void)
{
	unsigned char public_desc[4096] __attribute__((aligned(64)));
	struct ihk_page_allocator_desc *desc;
	mcs_lock_node_t lock_node;
	unsigned long desc_pages = 0;
	unsigned long lock_offset =
		__builtin_offsetof(struct ihk_page_allocator_desc, lock);
	unsigned long lock_node_addr = (unsigned long)&lock_node;
	unsigned long digest = 0x7075627061676573UL;
	unsigned long addr;
	int rc;

	memset(public_desc, 0xcc, sizeof(public_desc));
	memset(public_alloc_desc, 0xdd, sizeof(public_alloc_desc));
	memset(&lock_node, 0, sizeof(lock_node));
	reset_public_pagealloc_trace();

	desc = pagealloc_public_init_result(ARENA_BASE,
		32 * LOCAL_PAGE_SIZE, LOCAL_PAGE_SIZE, public_desc,
		&desc_pages, sizeof(struct ihk_page_allocator_desc),
		IHK_MC_AP_CRITICAL, LOCAL_PAGE_SIZE, lock_offset,
		fake_public_alloc_pages, fake_public_lock_init,
		fake_public_init_fail_log);
	require(desc == (struct ihk_page_allocator_desc *)public_desc);
	require(desc_pages == 1);
	require(public_alloc_pages_count == 0);
	require(public_lock_init_count == 1);
	require(public_lock_init_addr == (unsigned long)&desc->lock);
	mix(&digest, desc_pages);
	mix(&digest, public_lock_init_addr - (unsigned long)desc);

	reset_mcs_trace();
	addr = pagealloc_public_alloc_result(desc, 2, 0, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(addr == ARENA_BASE);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	mix(&digest, addr);
	mix(&digest, pagealloc_public_count_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock));

	rc = pagealloc_public_reserve_result(desc,
		ARENA_BASE + 8 * LOCAL_PAGE_SIZE,
		ARENA_BASE + 10 * LOCAL_PAGE_SIZE, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 1);
	require(pagealloc_public_query_free_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock) == 28);
	mix(&digest, (unsigned long)rc);

	rc = pagealloc_public_free_result(desc, addr, 2, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock,
		fake_public_free_error);
	require(rc == 0);
	require(public_free_error_count == 0);
	require(pagealloc_public_count_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock) == 30);
	mix(&digest, (unsigned long)rc);

	rc = pagealloc_public_free_result(NULL, addr, 1, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock,
		fake_public_free_error);
	require(rc == EINVAL);
	require(public_free_error_count == 1);
	require(public_free_error_addr == addr);
	mix(&digest, (unsigned long)rc);
	mix(&digest, public_free_error_addr);

	fill_page_arena(0xaa);
	rc = pagealloc_public_zero_free_pages_result(desc, lock_offset,
		lock_node_addr, fake_mcs_lock, fake_mcs_unlock,
		fake_public_zero_log);
	require(rc == 1);
	require(public_zero_log_count == 2);
	require_page_bytes(0, 0, 0);
	require_page_bytes(8, 0, 0xaa);
	mix(&digest, public_zero_log_digest);

	memset(public_alloc_desc, 0xee, sizeof(public_alloc_desc));
	reset_public_pagealloc_trace();
	desc_pages = 0;
	desc = pagealloc_public_init_result(ARENA_BASE,
		16 * LOCAL_PAGE_SIZE, LOCAL_PAGE_SIZE, NULL, &desc_pages,
		sizeof(struct ihk_page_allocator_desc), IHK_MC_AP_CRITICAL,
		LOCAL_PAGE_SIZE, lock_offset, fake_public_alloc_pages,
		fake_public_lock_init, fake_public_init_fail_log);
	require(desc == (struct ihk_page_allocator_desc *)public_alloc_desc);
	require(public_alloc_pages_count == 1);
	require(public_lock_init_count == 1);
	mix(&digest, (unsigned long)(desc == (struct ihk_page_allocator_desc *)
		public_alloc_desc));
	mix(&digest, (unsigned long)public_alloc_pages_count);

	reset_public_pagealloc_trace();
	public_alloc_pages_fail = 1;
	desc = pagealloc_public_init_result(ARENA_BASE,
		16 * LOCAL_PAGE_SIZE, LOCAL_PAGE_SIZE, NULL, &desc_pages,
		sizeof(struct ihk_page_allocator_desc), IHK_MC_AP_CRITICAL,
		LOCAL_PAGE_SIZE, lock_offset, fake_public_alloc_pages,
		fake_public_lock_init, fake_public_init_fail_log);
	require(desc == NULL);
	require(public_alloc_pages_count == 1);
	require(public_init_fail_count == 1);
	mix(&digest, public_init_fail_digest);

	return digest;
}

static unsigned long page_cache_orchestration_digest(void)
{
	struct ihk_mc_page_cache_header cache;
	unsigned char local_pages[3][LOCAL_PAGE_SIZE]
		__attribute__((aligned(4096)));
	void *page;
	unsigned long digest = 0x7061676563616368UL;

	memset(&cache, 0, sizeof(cache));
	memset(local_pages, 0x5a, sizeof(local_pages));

	ihk_mc_page_cache_free(&cache, local_pages[0]);
	require(cache.next == (struct ihk_mc_page_cache_header *)local_pages[0]);
	require(cache.next->next == NULL);
	ihk_mc_page_cache_free(&cache, local_pages[1]);
	require(cache.next == (struct ihk_mc_page_cache_header *)local_pages[1]);
	require(cache.next->next ==
		(struct ihk_mc_page_cache_header *)local_pages[0]);
	ihk_mc_page_cache_free(&cache, NULL);
	require(cache.next == (struct ihk_mc_page_cache_header *)local_pages[1]);

	page = ihk_mc_page_cache_alloc(&cache, 1);
	require(page == local_pages[1]);
	page = ihk_mc_page_cache_alloc(&cache, 1);
	require(page == local_pages[0]);
	require(cache.next == NULL);
	mix(&digest, (unsigned long)(page == local_pages[0]));

	reset_page_cache_pool(3);
	ihk_mc_page_cache_prealloc(&cache, 1, 3);
	require(page_cache_alloc_calls == 3);
	require(cache.next ==
		(struct ihk_mc_page_cache_header *)page_cache_pages[2]);
	mix(&digest, (unsigned long)page_cache_alloc_calls);
	for (int i = 2; i >= 0; i--) {
		page = ihk_mc_page_cache_alloc(&cache, 1);
		require(page == page_cache_pages[i]);
		mix(&digest, (unsigned long)i);
	}
	require(cache.next == NULL);

	reset_page_cache_pool(256);
	page = ihk_mc_page_cache_alloc(&cache, 1);
	require(page == page_cache_pages[255]);
	require(page_cache_alloc_calls == 256);
	require(cache.next ==
		(struct ihk_mc_page_cache_header *)page_cache_pages[254]);
	mix(&digest, (unsigned long)page_cache_alloc_calls);
	mix(&digest, (unsigned long)(cache.next ==
		(struct ihk_mc_page_cache_header *)page_cache_pages[254]));

	return digest;
}

static void sample_state(unsigned long *digest, void *desc)
{
	mix(digest, ihk_pagealloc_count(desc));
	mix(digest, (unsigned long)ihk_pagealloc_query_free(desc));
}

static void fill_page_arena(unsigned char value)
{
	for (unsigned long i = 0; i < sizeof(page_arena); i++)
		page_arena[i] = value;
}

static int page_is_free(void *desc, int page)
{
	struct ihk_page_allocator_desc *d = desc;
	return !(d->map[page >> 6] & (1UL << (page & 63)));
}

static void verify_zeroed_free_pages(unsigned long *digest, void *desc)
{
	for (int page = 0; page < ARENA_PAGES; page++) {
		int expected = page_is_free(desc, page) ? 0 : 0x5a;
		unsigned char *base = page_arena + page * LOCAL_PAGE_SIZE;

		for (int offset = 0; offset < LOCAL_PAGE_SIZE; offset++) {
			if (base[offset] != (unsigned char)expected) {
				printf("zero mismatch page=%d offset=%d got=%u expected=%d\n",
				       page, offset, (unsigned int)base[offset], expected);
				exit(93);
			}
		}

		mix(digest, ((unsigned long)page << 8) | (unsigned long)expected);
	}
}

static unsigned long digest_free_tree(struct rb_root *root)
{
	unsigned long digest = 0;
	struct rb_node *node;

	for (node = rb_first(root); node; node = rb_next(node)) {
		struct free_chunk *chunk = (struct free_chunk *)((char *)node -
			offsetof(struct free_chunk, node));

		mix(&digest, chunk->addr);
		mix(&digest, chunk->size);
	}

	return digest;
}

static unsigned long numa_locked_orchestration_digest(void)
{
	struct ihk_mc_numa_node numa;
	struct rb_root cache_root = { NULL };
	mcs_lock_node_t lock_node;
	unsigned long base = ARENA_BASE + 232 * LOCAL_PAGE_SIZE;
	unsigned long cache_base = ARENA_BASE + 236 * LOCAL_PAGE_SIZE;
	unsigned long lock_offset = __builtin_offsetof(struct ihk_mc_numa_node,
						       lock);
	unsigned long lock_addr;
	unsigned long node_addr = (unsigned long)&lock_node;
	unsigned long digest = 0x6e756d616c6f636bUL;
	unsigned long addr;
	int source;
	int direct_rc;
	int zero_request_action;
	struct ikc_scd_packet packet;
	int rc;

	memset(&numa, 0, sizeof(numa));
	memset(&lock_node, 0, sizeof(lock_node));
	numa.min_addr = base;
	numa.max_addr = base + 4 * LOCAL_PAGE_SIZE;
	numa.nr_pages = 4;
	numa.nr_free_pages = 4;
	zero_at_free = 0;
	require(__page_alloc_rbtree_free_range(&numa.free_chunks, base,
					       4 * LOCAL_PAGE_SIZE) == 0);
	lock_addr = (unsigned long)&numa.lock;

	reset_mcs_trace();
	addr = __ihk_numa_alloc_pages_locked_result(&numa, 1, 0,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(addr == base);
	require(numa.nr_free_pages == 3);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(mcs_lock_log[0][0] == lock_addr);
	require(mcs_lock_log[0][1] == node_addr);
	require(mcs_unlock_log[0][0] == lock_addr);
	require(mcs_unlock_log[0][1] == node_addr);
	mix(&digest, addr - base);
	mix(&digest, numa.nr_free_pages);
	mix(&digest, digest_free_tree(&numa.free_chunks));
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	reset_mcs_trace();
	rc = __ihk_numa_free_pages_direct_locked_result(&numa, addr, 1,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 0);
	require(numa.nr_free_pages == 4);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(mcs_lock_log[0][0] == lock_addr);
	require(mcs_unlock_log[0][0] == lock_addr);
	mix(&digest, (unsigned long)rc);
	mix(&digest, numa.nr_free_pages);
	mix(&digest, digest_free_tree(&numa.free_chunks));
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	reset_mcs_trace();
	addr = __ihk_numa_alloc_pages_locked_result(&numa, 1, 0,
		lock_offset, node_addr, NULL, fake_mcs_unlock);
	require(addr == 0);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	mix(&digest, addr);
	mix(&digest, (unsigned long)mcs_lock_count);
	mix(&digest, (unsigned long)mcs_unlock_count);

	rc = __ihk_numa_free_pages_direct_locked_result(&numa, base, 0,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == EINVAL);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	mix(&digest, (unsigned long)rc);

	zero_at_free = 0;
	require(__page_alloc_rbtree_free_range(&cache_root, cache_base,
					       2 * LOCAL_PAGE_SIZE) == 0);

	reset_irq_trace();
	reset_mcs_trace();
	source = -1;
	addr = ihk_numa_alloc_pages_orchestrate_result(&numa, 1, &cache_root,
		1, 0, lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, &source);
	require(addr == cache_base);
	require(source == 1);
	require(irq_save_count == 1);
	require(irq_restore_count == 1);
	require(irq_restore_cookie == irq_cookie);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	mix(&digest, addr - cache_base);
	mix(&digest, (unsigned long)source);
	mix(&digest, (unsigned long)irq_save_count);
	mix(&digest, digest_free_tree(&cache_root));

	reset_irq_trace();
	reset_mcs_trace();
	source = -1;
	addr = ihk_numa_alloc_pages_orchestrate_result(&numa, 0, &cache_root,
		1, 0, lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, &source);
	require(addr == base);
	require(source == 2);
	require(numa.nr_free_pages == 3);
	require(irq_save_count == 0);
	require(irq_restore_count == 0);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(mcs_lock_log[0][0] == lock_addr);
	mix(&digest, addr - base);
	mix(&digest, (unsigned long)source);
	mix(&digest, numa.nr_free_pages);
	mix(&digest, (unsigned long)mcs_lock_count);

	rc = __ihk_numa_free_pages_direct_locked_result(&numa, addr, 1,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(rc == 0);
	require(numa.nr_free_pages == 4);
	mix(&digest, numa.nr_free_pages);

	reset_irq_trace();
	reset_mcs_trace();
	source = -1;
	addr = ihk_numa_alloc_pages_orchestrate_result(&numa, 0, &cache_root,
		1, 0, lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		NULL, fake_mcs_unlock, &source);
	require(addr == 0);
	require(source == 0);
	require(irq_save_count == 0);
	require(irq_restore_count == 0);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	mix(&digest, addr);
	mix(&digest, (unsigned long)source);

	zero_at_free = 0;
	addr = __ihk_numa_alloc_pages_locked_result(&numa, 1, 0,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(addr == base);
	require(numa.nr_free_pages == 3);
	reset_mcs_trace();
	direct_rc = -1;
	zero_request_action = -1;
	rc = ihk_numa_free_pages_orchestrate_result(&numa, addr, 1, 1,
		&packet, 0, 0, 0, 0, 0, 0, 0, 0, lock_offset, node_addr,
		fake_mcs_lock, fake_mcs_unlock, &direct_rc,
		&zero_request_action);
	require(rc == 0);
	require(direct_rc == 0);
	require(zero_request_action == 0);
	require(numa.nr_free_pages == 4);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	mix(&digest, (unsigned long)rc);
	mix(&digest, (unsigned long)direct_rc);
	mix(&digest, numa.nr_free_pages);

	direct_rc = -1;
	zero_request_action = -1;
	rc = ihk_numa_free_pages_orchestrate_result(&numa,
		base + 8 * LOCAL_PAGE_SIZE, 1, 1, &packet, 0, 0, 0, 0, 0, 0,
		0, 0, lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock,
		&direct_rc, &zero_request_action);
	require(rc == 2);
	require(direct_rc == 0);
	require(zero_request_action == 0);
	mix(&digest, (unsigned long)rc);

	addr = __ihk_numa_alloc_pages_locked_result(&numa, 1, 0,
		lock_offset, node_addr, fake_mcs_lock, fake_mcs_unlock);
	require(addr == base);
	zero_at_free = 1;
	numa.to_zero_list.first = NULL;
	numa.nr_to_zero_pages.counter = 0;
	direct_rc = -1;
	zero_request_action = -1;
	rc = ihk_numa_free_pages_orchestrate_result(&numa, addr, 1, 1,
		&packet, 0, 0, 0, 0, 0, 0, 0, 0, lock_offset, node_addr,
		fake_mcs_lock, fake_mcs_unlock, &direct_rc,
		&zero_request_action);
	require(rc == 1);
	require(direct_rc == 0);
	require(zero_request_action == 0);
	require(numa.nr_to_zero_pages.counter == 1);
	require(numa.to_zero_list.first != NULL);
	mix(&digest, (unsigned long)rc);
	mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);
	return digest;
}

static unsigned long numa_alloc_top_level_digest(void)
{
	struct ihk_mc_numa_node numa;
	struct rb_root cache_root = { NULL };
	mcs_lock_node_t lock_node;
	unsigned long base = ARENA_BASE + 248 * LOCAL_PAGE_SIZE;
	unsigned long cache_base = ARENA_BASE + 252 * LOCAL_PAGE_SIZE;
	unsigned long lock_offset = __builtin_offsetof(struct ihk_mc_numa_node,
						       lock);
	unsigned long node_addr = (unsigned long)&lock_node;
	unsigned long lock_addr;
	unsigned long digest = 0x746f70616c6c6f63UL;
	unsigned long addr;

	memset(&numa, 0, sizeof(numa));
	memset(&lock_node, 0, sizeof(lock_node));
	numa.min_addr = base;
	numa.max_addr = base + 4 * LOCAL_PAGE_SIZE;
	numa.nr_pages = 4;
	numa.nr_free_pages = 4;
	zero_at_free = 0;
	require(__page_alloc_rbtree_free_range(&numa.free_chunks, base,
					       4 * LOCAL_PAGE_SIZE) == 0);
	require(__page_alloc_rbtree_free_range(&cache_root, cache_base,
					       2 * LOCAL_PAGE_SIZE) == 0);
	lock_addr = (unsigned long)&numa.lock;

	reset_irq_trace();
	reset_mcs_trace();
	reset_top_alloc_trace();
	top_alloc_expected_node = (unsigned long)&numa;
	addr = ihk_numa_alloc_pages_result(&numa, 1, &cache_root, 1, 0,
		lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, fake_top_alloc_log);
	require(addr == cache_base);
	require(irq_save_count == 1);
	require(irq_restore_count == 1);
	require(irq_restore_cookie == irq_cookie);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	require(top_alloc_log_count == 1);
	require(numa.nr_free_pages == 4);
	mix(&digest, top_alloc_log_digest);
	mix(&digest, digest_free_tree(&cache_root));
	mix(&digest, numa.nr_free_pages);
	mix(&digest, (unsigned long)irq_save_count);

	reset_irq_trace();
	reset_mcs_trace();
	reset_top_alloc_trace();
	top_alloc_expected_node = (unsigned long)&numa;
	addr = ihk_numa_alloc_pages_result(&numa, 0, NULL, 1, 0,
		lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, fake_top_alloc_log);
	require(addr == base);
	require(irq_save_count == 0);
	require(irq_restore_count == 0);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(mcs_lock_log[0][0] == lock_addr);
	require(mcs_lock_log[0][1] == node_addr);
	require(mcs_unlock_log[0][0] == lock_addr);
	require(mcs_unlock_log[0][1] == node_addr);
	require(top_alloc_log_count == 1);
	require(numa.nr_free_pages == 3);
	mix(&digest, top_alloc_log_digest);
	mix(&digest, numa.nr_free_pages);
	mix(&digest, digest_free_tree(&numa.free_chunks));
	mix(&digest, (unsigned long)mcs_lock_count);

	reset_irq_trace();
	reset_mcs_trace();
	reset_top_alloc_trace();
	top_alloc_expected_node = (unsigned long)&numa;
	addr = ihk_numa_alloc_pages_result(&numa, 0, NULL, 1, 0,
		lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		NULL, fake_mcs_unlock, fake_top_alloc_log);
	require(addr == 0);
	require(irq_save_count == 0);
	require(irq_restore_count == 0);
	require(mcs_lock_count == 0);
	require(mcs_unlock_count == 0);
	require(top_alloc_log_count == 0);
	require(numa.nr_free_pages == 3);
	mix(&digest, top_alloc_log_digest);
	mix(&digest, numa.nr_free_pages);

	return digest;
}

static unsigned long numa_add_zero_top_level_digest(void)
{
	struct ihk_mc_numa_node numa;
	struct free_chunk *chunk =
		(struct free_chunk *)phys_to_virt(ARENA_BASE +
				212 * LOCAL_PAGE_SIZE);
	unsigned long base = ARENA_BASE + 208 * LOCAL_PAGE_SIZE;
	unsigned long zero_base = ARENA_BASE + 212 * LOCAL_PAGE_SIZE;
	unsigned long digest = 0x6164646672656521UL;
	int rc;

	memset(&numa, 0, sizeof(numa));
	memset(chunk, 0, sizeof(*chunk));
	numa.min_addr = ~0UL;
	zero_at_free = 1;
	fill_page_arena(0x88);

	reset_top_add_free_trace();
	top_add_free_expected_node = (unsigned long)&numa;
	rc = ihk_numa_add_free_pages_result(&numa, base,
		2 * LOCAL_PAGE_SIZE, fake_top_add_free_log);
	require(rc == 0);
	require(top_add_free_log_count == 1);
	require(numa.min_addr == base);
	require(numa.max_addr == base + 2 * LOCAL_PAGE_SIZE);
	require(numa.nr_pages == 2);
	require(numa.nr_free_pages == 2);
	require_page_bytes(208, sizeof(struct free_chunk), 0);
	require_page_bytes(209, 0, 0);
	mix(&digest, top_add_free_log_digest);
	mix(&digest, digest_free_tree(&numa.free_chunks));
	mix(&digest, numa.nr_free_pages);

	zero_at_free = 0;
	reset_top_add_free_trace();
	top_add_free_expected_node = (unsigned long)&numa;
	rc = ihk_numa_add_free_pages_result(&numa, base,
		LOCAL_PAGE_SIZE, fake_top_add_free_log);
	require(rc == EINVAL);
	require(top_add_free_log_count == 1);
	require(numa.nr_pages == 2);
	require(numa.nr_free_pages == 2);
	mix(&digest, top_add_free_log_digest);
	mix(&digest, digest_free_tree(&numa.free_chunks));

	memset(&numa, 0, sizeof(numa));
	memset(chunk, 0, sizeof(*chunk));
	fill_page_arena(0x99);
	zero_at_free = 1;
	chunk->addr = zero_base;
	chunk->size = LOCAL_PAGE_SIZE;
	numa.nr_to_zero_pages.counter = 1;
	llist_add(&chunk->list, &numa.to_zero_list);
	ihk_numa_zero_free_pages(&numa);
	require(numa.nr_to_zero_pages.counter == 0);
	require(numa.to_zero_list.first == NULL);
	require(numa.zeroed_list.first == &chunk->list);
	require_page_bytes(212, sizeof(struct free_chunk), 0);
	mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);
	mix(&digest, (unsigned long)(numa.zeroed_list.first == &chunk->list));

	return digest;
}

static unsigned long numa_free_top_level_digest(void)
{
	struct ihk_mc_numa_node numa;
	struct rb_root cache_root = { NULL };
	struct process proc;
	struct thread current;
	struct thread idle;
	struct ikc_scd_packet packet;
	mcs_lock_node_t lock_node;
	unsigned long base = ARENA_BASE + 240 * LOCAL_PAGE_SIZE;
	unsigned long cache_base = ARENA_BASE + 244 * LOCAL_PAGE_SIZE;
	unsigned long lock_offset = __builtin_offsetof(struct ihk_mc_numa_node,
						       lock);
	unsigned long node_addr = (unsigned long)&lock_node;
	unsigned long digest = 0x746f706672656521UL;

	memset(&numa, 0, sizeof(numa));
	memset(&proc, 0, sizeof(proc));
	memset(&current, 0, sizeof(current));
	memset(&idle, 0, sizeof(idle));
	memset(&lock_node, 0, sizeof(lock_node));
	memset(&packet, 0, sizeof(packet));
	numa.min_addr = base;
	numa.max_addr = base + 4 * LOCAL_PAGE_SIZE;
	numa.nr_pages = 4;
	proc.pid = 1357;
	proc.nohost = 0;
	current.proc = &proc;
	top_free_expected_node = (unsigned long)&numa;
	zero_at_free = 0;

	reset_irq_trace();
	reset_mcs_trace();
	reset_top_free_trace(0);
	top_free_expected_node = (unsigned long)&numa;
	ihk_numa_free_pages_result(&numa, cache_base, 1, 1, zero_at_free,
		&packet, 1, &cache_root, (unsigned long)&current,
		(unsigned long)&idle, __builtin_offsetof(struct thread, proc),
		__builtin_offsetof(struct process, nohost),
		__builtin_offsetof(struct process, pid), 3, 0x12345678UL,
		lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, fake_top_free_send,
		fake_top_free_log);
	require(irq_save_count == 1);
	require(irq_restore_count == 1);
	require(mcs_lock_count == 0);
	require(top_free_send_count == 0);
	require(top_free_log_count == 1);
	require(cache_root.rb_node != NULL);
	mix(&digest, top_free_log_digest);
	mix(&digest, digest_free_tree(&cache_root));
	mix(&digest, (unsigned long)irq_save_count);

	reset_irq_trace();
	reset_mcs_trace();
	reset_top_free_trace(0);
	top_free_expected_node = (unsigned long)&numa;
	ihk_numa_free_pages_result(&numa, cache_base, 0, 1, zero_at_free,
		&packet, 1, &cache_root, (unsigned long)&current,
		(unsigned long)&idle, __builtin_offsetof(struct thread, proc),
		__builtin_offsetof(struct process, nohost),
		__builtin_offsetof(struct process, pid), 3, 0x12345678UL,
		lock_offset, node_addr, fake_irq_save, fake_irq_restore,
		fake_mcs_lock, fake_mcs_unlock, fake_top_free_send,
		fake_top_free_log);
	require(irq_save_count == 1);
	require(irq_restore_count == 1);
	require(mcs_lock_count == 0);
	require(top_free_send_count == 0);
	require(top_free_log_count == 1);
	mix(&digest, top_free_log_digest);

	require(__page_alloc_rbtree_free_range(&numa.free_chunks, base,
					       LOCAL_PAGE_SIZE) == 0);
	require(numa.nr_free_pages == 0);
	reset_irq_trace();
	reset_mcs_trace();
	reset_top_free_trace(0);
	top_free_expected_node = (unsigned long)&numa;
	ihk_numa_free_pages_result(&numa, base + LOCAL_PAGE_SIZE, 1, 1,
		zero_at_free, &packet, 0, NULL, 0, 0, 0, 0, 0, 0,
		0x12345678UL, lock_offset, node_addr, fake_irq_save,
		fake_irq_restore, fake_mcs_lock, fake_mcs_unlock,
		fake_top_free_send, fake_top_free_log);
	require(irq_save_count == 0);
	require(mcs_lock_count == 1);
	require(mcs_unlock_count == 1);
	require(numa.nr_free_pages == 1);
	require(top_free_send_count == 0);
	require(top_free_log_count == 1);
	mix(&digest, top_free_log_digest);
	mix(&digest, numa.nr_free_pages);
	mix(&digest, digest_free_tree(&numa.free_chunks));

	zero_at_free = 1;
	memset(&packet, 0, sizeof(packet));
	reset_irq_trace();
	reset_mcs_trace();
	reset_top_free_trace(0);
	top_free_expected_node = (unsigned long)&numa;
	ihk_numa_free_pages_result(&numa, base + 2 * LOCAL_PAGE_SIZE, 1, 1,
		zero_at_free, &packet, 1, NULL, (unsigned long)&current,
		(unsigned long)&idle, __builtin_offsetof(struct thread, proc),
		__builtin_offsetof(struct process, nohost),
		__builtin_offsetof(struct process, pid), 7, 0x87654321UL,
		lock_offset, node_addr, NULL, NULL, fake_mcs_lock,
		fake_mcs_unlock, fake_top_free_send, fake_top_free_log);
	require(irq_save_count == 0);
	require(mcs_lock_count == 0);
	require(top_free_send_count == 1);
	require(top_free_send_packet == (unsigned long)&packet);
	require(top_free_log_count == 1);
	require(numa.nr_to_zero_pages.counter == 1);
	require(numa.zeroing_workers.counter == 1);
	require(numa.to_zero_list.first != NULL);
	require(packet.msg == SCD_MSG_SYSCALL_ONESIDE);
	require(packet.ref == 7);
	require(packet.pid == 1357);
	require(packet.req.valid == 1);
	require(packet.req.number == 0x87654321UL);
	require(packet.req.args[0] == (unsigned long)&numa);
	mix(&digest, top_free_log_digest);
	mix(&digest, top_free_send_packet == (unsigned long)&packet);
	mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);
	mix(&digest, (unsigned long)numa.zeroing_workers.counter);
	mix(&digest, packet.req.number);
	mix(&digest, packet.req.args[0] == (unsigned long)&numa);
	return digest;
}

static void require_page_bytes(int page, int start, unsigned char expected)
{
	unsigned char *base = page_arena + page * LOCAL_PAGE_SIZE;

	for (int offset = start; offset < LOCAL_PAGE_SIZE; offset++) {
		if (base[offset] != expected) {
			printf("page byte mismatch page=%d offset=%d got=%u expected=%u\n",
			       page, offset, (unsigned int)base[offset],
			       (unsigned int)expected);
			exit(94);
		}
	}
}

int main(void)
{
	unsigned long desc_pages = 0;
	unsigned long digest = 0;
	void *desc;
	unsigned long a, b, c, d;

#ifdef MCKERNEL_RUST_PAGEALLOC_BITMAP
	linux_page_offset_base = (unsigned long)page_arena - ARENA_BASE;
#endif
	memset(initial_desc, 0xcc, sizeof(initial_desc));
	desc = __ihk_pagealloc_init(ARENA_BASE, 256 * LOCAL_PAGE_SIZE,
				    LOCAL_PAGE_SIZE, initial_desc, &desc_pages);
	require(desc == initial_desc);
	require(desc_pages == 1);
	require(((struct ihk_page_allocator_desc *)desc)->end ==
		pagealloc_init_end_result(ARENA_BASE,
			256 * LOCAL_PAGE_SIZE));
	require(((struct ihk_page_allocator_desc *)desc)->count ==
		(unsigned int)pagealloc_init_count_result(32));
	require(pagealloc_destroy_pages_result(
		((struct ihk_page_allocator_desc *)desc)->flag) == 1);
	require(((struct ihk_page_allocator_desc *)desc)->start == ARENA_BASE);
	require(((struct ihk_page_allocator_desc *)desc)->last == 0);
	require(((struct ihk_page_allocator_desc *)desc)->shift == 12);
	memset(initial_desc, 0x7f, sizeof(initial_desc));
	pagealloc_desc_reset_result((struct ihk_page_allocator_desc *)initial_desc,
				    1, LOCAL_PAGE_SIZE);
	require(((unsigned char *)initial_desc)[0] == 0);
	require(((unsigned char *)initial_desc)[LOCAL_PAGE_SIZE - 1] == 0);
	pagealloc_desc_init_result((struct ihk_page_allocator_desc *)initial_desc,
				   ARENA_BASE + LOCAL_PAGE_SIZE,
				   128 * LOCAL_PAGE_SIZE, 12, 16, 1);
	require(((struct ihk_page_allocator_desc *)initial_desc)->start ==
		ARENA_BASE + LOCAL_PAGE_SIZE);
	require(((struct ihk_page_allocator_desc *)initial_desc)->end ==
		ARENA_BASE + 129 * LOCAL_PAGE_SIZE);
	require(((struct ihk_page_allocator_desc *)initial_desc)->count == 2);
	require(((struct ihk_page_allocator_desc *)initial_desc)->flag == 1);
	memset(initial_desc, 0xcc, sizeof(initial_desc));
	desc = __ihk_pagealloc_init(ARENA_BASE, 256 * LOCAL_PAGE_SIZE,
				    LOCAL_PAGE_SIZE, initial_desc, &desc_pages);
	require(desc == initial_desc);
	mix(&digest, ((struct ihk_page_allocator_desc *)desc)->end);
	mix(&digest, ((struct ihk_page_allocator_desc *)desc)->count);
	sample_state(&digest, desc);
	require(ihk_pagealloc_count(desc) == 256);
	require(ihk_pagealloc_query_free(desc) == 256);

	ihk_pagealloc_reserve(desc, ARENA_BASE + 8 * LOCAL_PAGE_SIZE,
			      ARENA_BASE + 12 * LOCAL_PAGE_SIZE);
	sample_state(&digest, desc);
	require(ihk_pagealloc_count(desc) == 252);

	a = ihk_pagealloc_alloc(desc, 1, 0);
	require(a == ARENA_BASE);
	mix(&digest, a);
	sample_state(&digest, desc);

	b = ihk_pagealloc_alloc(desc, 3, 2);
	require(b == ARENA_BASE + 4 * LOCAL_PAGE_SIZE);
	mix(&digest, b);
	sample_state(&digest, desc);

	c = ihk_pagealloc_alloc(desc, 32, 5);
	require(c == ARENA_BASE + 64 * LOCAL_PAGE_SIZE);
	mix(&digest, c);
	sample_state(&digest, desc);

	ihk_pagealloc_free(desc, a, 1);
	sample_state(&digest, desc);
	d = ihk_pagealloc_alloc(desc, 2, 0);
	require(d == ARENA_BASE);
	mix(&digest, d);
	sample_state(&digest, desc);

	ihk_pagealloc_free(desc, d, 2);
	ihk_pagealloc_free(desc, b, 3);
	ihk_pagealloc_free(desc, c, 32);
	sample_state(&digest, desc);
	require(ihk_pagealloc_count(desc) == 252);

	ihk_pagealloc_reserve(desc, ARENA_BASE + 128 * LOCAL_PAGE_SIZE,
			      ARENA_BASE + 192 * LOCAL_PAGE_SIZE);
	sample_state(&digest, desc);
	require(ihk_pagealloc_count(desc) == 188);

	c = ihk_pagealloc_alloc(desc, 64, 6);
	require(c == ARENA_BASE + 64 * LOCAL_PAGE_SIZE);
	mix(&digest, c);
	sample_state(&digest, desc);
	require(ihk_pagealloc_count(desc) == 124);

	fill_page_arena(0x5a);
	__ihk_pagealloc_zero_free_pages(desc);
	verify_zeroed_free_pages(&digest, desc);
	mix(&digest, pagealloc_destroy_orchestration_digest());
	mix(&digest, pagealloc_locked_orchestration_digest());
	mix(&digest, pagealloc_public_orchestration_digest());
	mix(&digest, page_cache_orchestration_digest());
	mix(&digest, numa_locked_orchestration_digest());
	mix(&digest, numa_alloc_top_level_digest());
	mix(&digest, numa_add_zero_top_level_digest());
	mix(&digest, numa_free_top_level_digest());

	{
		struct ihk_mc_numa_node numa;
		unsigned long base = ARENA_BASE + 200 * LOCAL_PAGE_SIZE;

		memset(&numa, 0, sizeof(numa));
		numa.min_addr = ~0UL;
		fill_page_arena(0x7b);
		zero_at_free = 1;

		require(ihk_numa_add_free_pages(&numa, base,
						4 * LOCAL_PAGE_SIZE) == 0);
		require(numa.nr_pages == 4);
		require(numa.nr_free_pages == 4);
		require(numa.min_addr == base);
		require(numa.max_addr == base + 4 * LOCAL_PAGE_SIZE);
		require_page_bytes(199, 0, 0x7b);
		require_page_bytes(200, sizeof(struct free_chunk), 0);
		require_page_bytes(201, 0, 0);
		require_page_bytes(202, 0, 0);
		require_page_bytes(203, 0, 0);
		require_page_bytes(204, 0, 0x7b);
		mix(&digest, digest_free_tree(&numa.free_chunks));

		require(ihk_numa_add_free_pages(&numa,
						base + 4 * LOCAL_PAGE_SIZE,
						2 * LOCAL_PAGE_SIZE) == 0);
		require(numa.nr_pages == 6);
		require(numa.nr_free_pages == 6);
		require(numa.min_addr == base);
		require(numa.max_addr == base + 6 * LOCAL_PAGE_SIZE);
		require_page_bytes(204, 0, 0);
		require_page_bytes(205, 0, 0);
		mix(&digest, digest_free_tree(&numa.free_chunks));

		require(ihk_numa_add_free_pages(&numa,
						base + 2 * LOCAL_PAGE_SIZE,
						LOCAL_PAGE_SIZE) == 22);
		require(numa.nr_pages == 6);
		require(numa.nr_free_pages == 6);
		mix(&digest, digest_free_tree(&numa.free_chunks));

		zero_at_free = 0;
		require(ihk_numa_add_free_pages(&numa,
						base - 2 * LOCAL_PAGE_SIZE,
						2 * LOCAL_PAGE_SIZE) == 0);
		require(numa.nr_pages == 8);
		require(numa.nr_free_pages == 8);
		require(numa.min_addr == base - 2 * LOCAL_PAGE_SIZE);
		require(numa.max_addr == base + 6 * LOCAL_PAGE_SIZE);
		mix(&digest, digest_free_tree(&numa.free_chunks));

		require(__page_alloc_rbtree_alloc_pages(&numa.free_chunks, 8, 0) ==
			base - 2 * LOCAL_PAGE_SIZE);
		require(numa.free_chunks.rb_node == NULL);

		{
			struct free_chunk *small =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						220 * LOCAL_PAGE_SIZE);
			struct free_chunk *big =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						224 * LOCAL_PAGE_SIZE);
			unsigned long small_addr;
			unsigned long big_addr;
			int zeroed;

			fill_page_arena(0x33);
			memset(small, 0, sizeof(*small));
			memset(big, 0, sizeof(*big));
			small->addr = ARENA_BASE + 220 * LOCAL_PAGE_SIZE;
			small->size = LOCAL_PAGE_SIZE;
			big->addr = ARENA_BASE + 224 * LOCAL_PAGE_SIZE;
			big->size = 3 * LOCAL_PAGE_SIZE;
			small_addr = small->addr;
			big_addr = big->addr;
			numa.to_zero_list.first = NULL;
			numa.zeroed_list.first = NULL;
			numa.nr_pages = 4;
			numa.nr_free_pages = 0;
			numa.nr_to_zero_pages.counter = 4;
			numa.zeroing_workers.counter = 0;
			zero_at_free = 1;

			llist_add(&big->list, &numa.to_zero_list);
			llist_add(&small->list, &numa.to_zero_list);

			zeroed = __ihk_numa_zero_free_pages(&numa, 2);
			require(zeroed == 3);
			require(numa.nr_to_zero_pages.counter == 1);
			require(numa.zeroed_list.first == &big->list);
			require(numa.to_zero_list.first == &small->list);
			require_page_bytes(220, sizeof(struct free_chunk), 0x33);
			require_page_bytes(224, sizeof(struct free_chunk), 0);
			require_page_bytes(225, 0, 0);
			require_page_bytes(226, 0, 0);
			mix(&digest, (unsigned long)zeroed);
			mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);
			__ihk_numa_zeroing_worker_inc(&numa);
			require(numa.zeroing_workers.counter == 1);
			mix(&digest, (unsigned long)numa.zeroing_workers.counter);
			__ihk_numa_zeroing_worker_inc(&numa);
			require(numa.zeroing_workers.counter == 2);
			mix(&digest, (unsigned long)numa.zeroing_workers.counter);

			zeroed = __ihk_numa_zero_free_pages(&numa, 0);
			require(zeroed == 1);
			require(numa.nr_to_zero_pages.counter == 0);
			require(numa.zeroed_list.first == &small->list);
			require(numa.to_zero_list.first == NULL);
			require_page_bytes(220, sizeof(struct free_chunk), 0);
			mix(&digest, (unsigned long)zeroed);
			mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);

			c = ihk_numa_alloc_pages(&numa, 3, 0);
			require(c == big_addr);
			require(numa.nr_free_pages == 1);
			require(numa.zeroed_list.first == NULL);
			require(numa.to_zero_list.first == NULL);
			mix(&digest, c);
			mix(&digest, numa.nr_free_pages);

			c = ihk_numa_alloc_pages(&numa, 1, 0);
			require(c == small_addr);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			mix(&digest, c);
			mix(&digest, numa.nr_free_pages);

			numa.min_addr = small_addr;
			numa.max_addr = big_addr + 3 * LOCAL_PAGE_SIZE;
			zero_at_free = 0;
			deferred_zero_at_free = 1;
			ihk_numa_free_pages(&numa, small_addr, 1);
			require(numa.nr_free_pages == 1);
			require(numa.to_zero_list.first == NULL);
			mix(&digest, digest_free_tree(&numa.free_chunks));
			c = ihk_numa_alloc_pages(&numa, 1, 0);
			require(c == small_addr);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			mix(&digest, c);
			mix(&digest, numa.nr_free_pages);

			fill_page_arena(0x44);
			zero_at_free = 1;
			deferred_zero_at_free = 0;
			ihk_numa_free_pages(&numa, small_addr, 1);
			require(numa.nr_free_pages == 1);
			require_page_bytes(220, sizeof(struct free_chunk), 0);
			mix(&digest, digest_free_tree(&numa.free_chunks));
			c = ihk_numa_alloc_pages(&numa, 1, 0);
			require(c == small_addr);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			mix(&digest, c);
			mix(&digest, numa.nr_free_pages);

			fill_page_arena(0x55);
			zero_at_free = 1;
			deferred_zero_at_free = 1;
			numa.nr_to_zero_pages.counter = 0;
			numa.to_zero_list.first = NULL;
			numa.zeroed_list.first = NULL;
			ihk_numa_free_pages(&numa, big_addr, 3);
			require(numa.nr_free_pages == 0);
			require(numa.nr_to_zero_pages.counter == 3);
			require(numa.to_zero_list.first == &big->list);
			require(numa.zeroed_list.first == NULL);
			require(big->addr == big_addr);
			require(big->size == 3 * LOCAL_PAGE_SIZE);
			require_page_bytes(224, sizeof(struct free_chunk), 0x55);
			require_page_bytes(225, 0, 0x55);
			mix(&digest, (unsigned long)numa.nr_to_zero_pages.counter);

			zeroed = __ihk_numa_zero_free_pages(&numa, 0);
			require(zeroed == 3);
			require(numa.nr_to_zero_pages.counter == 0);
			require(numa.to_zero_list.first == NULL);
			require(numa.zeroed_list.first == &big->list);
			require_page_bytes(224, sizeof(struct free_chunk), 0);
			require_page_bytes(225, 0, 0);
			require_page_bytes(226, 0, 0);
			mix(&digest, (unsigned long)zeroed);

			c = ihk_numa_alloc_pages(&numa, 3, 0);
			require(c == big_addr);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			require(numa.zeroed_list.first == NULL);
			mix(&digest, c);
			mix(&digest, numa.nr_free_pages);

			fill_page_arena(0x66);
			zero_at_free = 1;
			deferred_zero_at_free = 0;
			ihk_numa_free_pages(&numa,
					big_addr + 4 * LOCAL_PAGE_SIZE, 1);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			require_page_bytes(228, 0, 0x66);
			mix(&digest, numa.nr_free_pages);

			ihk_numa_free_pages(&numa, big_addr, 0);
			require(numa.nr_free_pages == 0);
			require(numa.free_chunks.rb_node == NULL);
			require_page_bytes(224, 0, 0x66);
			mix(&digest, numa.nr_free_pages);
		}

		{
			struct ihk_mc_numa_node node0;
			struct ihk_mc_numa_node node1;
			struct free_chunk *chunk0 =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						240 * LOCAL_PAGE_SIZE);
			struct free_chunk *chunk1 =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						244 * LOCAL_PAGE_SIZE);
			int zeroed;

			fill_page_arena(0x77);
			memset(&node0, 0, sizeof(node0));
			memset(&node1, 0, sizeof(node1));
			memset(chunk0, 0, sizeof(*chunk0));
			memset(chunk1, 0, sizeof(*chunk1));

			chunk0->addr = ARENA_BASE + 240 * LOCAL_PAGE_SIZE;
			chunk0->size = LOCAL_PAGE_SIZE;
			chunk1->addr = ARENA_BASE + 244 * LOCAL_PAGE_SIZE;
			chunk1->size = 2 * LOCAL_PAGE_SIZE;
			node0.nr_to_zero_pages.counter = 1;
			node1.nr_to_zero_pages.counter = 2;
			llist_add(&chunk0->list, &node0.to_zero_list);
			llist_add(&chunk1->list, &node1.to_zero_list);
			test_numa_nodes[0] = &node0;
			test_numa_nodes[1] = &node1;
			test_numa_nodes[2] = NULL;
			test_nr_numa_nodes = 3;
			zero_at_free = 1;

			zeroed = __ihk_numa_zero_free_pages(NULL, 0);
			require(zeroed == 3);
			require(node0.nr_to_zero_pages.counter == 0);
			require(node1.nr_to_zero_pages.counter == 0);
			require(node0.to_zero_list.first == NULL);
			require(node1.to_zero_list.first == NULL);
			require(node0.zeroed_list.first == &chunk0->list);
			require(node1.zeroed_list.first == &chunk1->list);
			require_page_bytes(240, sizeof(struct free_chunk), 0);
			require_page_bytes(244, sizeof(struct free_chunk), 0);
			require_page_bytes(245, 0, 0);
			mix(&digest, (unsigned long)zeroed);
			mix(&digest, (unsigned long)node0.nr_to_zero_pages.counter);
			mix(&digest, (unsigned long)node1.nr_to_zero_pages.counter);

			zero_at_free = 0;
			zeroed = __ihk_numa_zero_free_pages(NULL, 0);
			require(zeroed == 0);
			mix(&digest, (unsigned long)zeroed);
			test_nr_numa_nodes = 0;
			test_numa_nodes[0] = NULL;
			test_numa_nodes[1] = NULL;
			test_numa_nodes[2] = NULL;
		}

		{
			struct ikc_scd_packet packet;
			unsigned long node_addr = ARENA_BASE + 248 * LOCAL_PAGE_SIZE;
			unsigned long syscall_number = 0x12345678UL;
			int cpu_ref = 7;
			int pid = 4321;

			memset(&packet, 0xa5, sizeof(packet));
			__ihk_numa_zero_request_packet_fill(&packet, node_addr,
					cpu_ref, pid, syscall_number);
			require(packet.header.channel == NULL);
			require(packet.msg == SCD_MSG_SYSCALL_ONESIDE);
			require(packet.err == 0);
			require(packet.reply == NULL);
			require(packet.ref == cpu_ref);
			require(packet.osnum == 0);
			require(packet.pid == pid);
			require(packet.arg == 0);
			require(packet.req.rtid == 0);
			require(packet.req.ttid == 0);
			require(packet.req.valid == 1);
			require(packet.req.number == syscall_number);
			require(packet.req.args[0] == node_addr);
			for (int i = 1; i < 6; i++)
				require(packet.req.args[i] == 0);
			require(packet.resp_pa == 0);
			mix(&digest, (unsigned long)packet.msg);
			mix(&digest, (unsigned long)packet.ref);
			mix(&digest, (unsigned long)packet.pid);
			mix(&digest, packet.req.number);
			mix(&digest, packet.req.args[0]);
			mix(&digest, packet.req.valid);
		}

		{
			struct ihk_mc_numa_node prep_node;
			struct process proc;
			struct thread current;
			struct thread idle;
			struct ikc_scd_packet packet;
			unsigned long syscall_number = 0x87654321UL;
			int action;

			memset(&prep_node, 0, sizeof(prep_node));
			memset(&proc, 0, sizeof(proc));
			memset(&current, 0, sizeof(current));
			memset(&idle, 0, sizeof(idle));
			memset(&packet, 0xa5, sizeof(packet));
			proc.pid = 9876;
			proc.nohost = 0;
			current.proc = &proc;

			action = __ihk_numa_linux_zero_request_prepare(
				&prep_node, &packet, 1,
				(unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				11, syscall_number);
			require(action == 1);
			require(prep_node.zeroing_workers.counter == 1);
			require(packet.msg == SCD_MSG_SYSCALL_ONESIDE);
			require(packet.ref == 11);
			require(packet.pid == 9876);
			require(packet.req.valid == 1);
			require(packet.req.number == syscall_number);
			require(packet.req.args[0] == (unsigned long)&prep_node);
			require(packet.resp_pa == 0);
			mix(&digest, (unsigned long)action);
			mix(&digest, (unsigned long)prep_node.zeroing_workers.counter);
			mix(&digest, (unsigned long)packet.msg);
			mix(&digest, (unsigned long)packet.ref);
			mix(&digest, (unsigned long)packet.pid);
			mix(&digest, packet.req.number);
			mix(&digest, packet.req.args[0] == (unsigned long)&prep_node);
			mix(&digest, packet.req.valid);

			proc.nohost = 1;
			prep_node.zeroing_workers.counter = 0;
			memset(&packet, 0xa5, sizeof(packet));
			action = __ihk_numa_linux_zero_request_prepare(
				&prep_node, &packet, 1,
				(unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				11, syscall_number);
			require(action == 0);
			require(prep_node.zeroing_workers.counter == 0);
			mix(&digest, (unsigned long)action);

			proc.nohost = 0;
			prep_node.zeroing_workers.counter = 1;
			action = __ihk_numa_linux_zero_request_prepare(
				&prep_node, &packet, 1,
				(unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				11, syscall_number);
			require(action == 2);
			require(prep_node.zeroing_workers.counter == 1);
			mix(&digest, (unsigned long)action);

			prep_node.zeroing_workers.counter = 0;
			action = __ihk_numa_linux_zero_request_prepare(
				&prep_node, &packet, 1,
				(unsigned long)&idle,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				11, syscall_number);
			require(action == 0);
			mix(&digest, (unsigned long)action);

			action = __ihk_numa_linux_zero_request_prepare(
				&prep_node, NULL, 1,
				(unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				11, syscall_number);
			require(action == 0);
			mix(&digest, (unsigned long)action);
		}

		{
			struct ihk_mc_numa_node defer_node;
			struct process proc;
			struct thread current;
			struct thread idle;
			struct ikc_scd_packet packet;
			struct free_chunk *chunk0 =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						236 * LOCAL_PAGE_SIZE);
			struct free_chunk *chunk1 =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						238 * LOCAL_PAGE_SIZE);
			struct free_chunk *chunk2 =
				(struct free_chunk *)phys_to_virt(ARENA_BASE +
						239 * LOCAL_PAGE_SIZE);
			unsigned long syscall_number = 0x5a5a4321UL;
			int action;

			fill_page_arena(0x88);
			memset(&defer_node, 0, sizeof(defer_node));
			memset(&proc, 0, sizeof(proc));
			memset(&current, 0, sizeof(current));
			memset(&idle, 0, sizeof(idle));
			memset(chunk0, 0, sizeof(*chunk0));
			memset(chunk1, 0, sizeof(*chunk1));
			memset(chunk2, 0, sizeof(*chunk2));
			proc.pid = 2468;
			proc.nohost = 0;
			current.proc = &proc;

			memset(&packet, 0, sizeof(packet));
			action = __ihk_numa_free_pages_deferred_result(
				&defer_node, ARENA_BASE + 236 * LOCAL_PAGE_SIZE,
				2, &packet, 1, (unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				5, syscall_number);
			require(action == 1);
			require(defer_node.nr_to_zero_pages.counter == 2);
			require(defer_node.zeroing_workers.counter == 1);
			require(defer_node.to_zero_list.first == &chunk0->list);
			require(chunk0->list.next == NULL);
			require(chunk0->addr == ARENA_BASE + 236 * LOCAL_PAGE_SIZE);
			require(chunk0->size == 2 * LOCAL_PAGE_SIZE);
			require(packet.msg == SCD_MSG_SYSCALL_ONESIDE);
			require(packet.ref == 5);
			require(packet.pid == 2468);
			require(packet.req.valid == 1);
			require(packet.req.number == syscall_number);
			require(packet.req.args[0] == (unsigned long)&defer_node);
			require_page_bytes(236, sizeof(struct free_chunk), 0x88);
			mix(&digest, (unsigned long)action);
			mix(&digest, (unsigned long)defer_node.nr_to_zero_pages.counter);
			mix(&digest, (unsigned long)defer_node.zeroing_workers.counter);
			mix(&digest, (unsigned long)(defer_node.to_zero_list.first ==
					&chunk0->list));
			mix(&digest, chunk0->size);
			mix(&digest, (unsigned long)packet.ref);
			mix(&digest, (unsigned long)packet.pid);
			mix(&digest, packet.req.number);
			mix(&digest, packet.req.args[0] ==
					(unsigned long)&defer_node);
			mix(&digest, packet.req.valid);

			defer_node.zeroing_workers.counter = 3;
			memset(&packet, 0, sizeof(packet));
			action = __ihk_numa_free_pages_deferred_result(
				&defer_node, ARENA_BASE + 238 * LOCAL_PAGE_SIZE,
				1, &packet, 1, (unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				6, syscall_number);
			require(action == 2);
			require(defer_node.nr_to_zero_pages.counter == 3);
			require(defer_node.zeroing_workers.counter == 3);
			require(defer_node.to_zero_list.first == &chunk1->list);
			require(chunk1->list.next == &chunk0->list);
			require(chunk1->addr == ARENA_BASE + 238 * LOCAL_PAGE_SIZE);
			require(chunk1->size == LOCAL_PAGE_SIZE);
			require(packet.req.valid == 0);
			mix(&digest, (unsigned long)action);
			mix(&digest, (unsigned long)defer_node.nr_to_zero_pages.counter);
			mix(&digest, (unsigned long)defer_node.zeroing_workers.counter);
			mix(&digest, (unsigned long)(chunk1->list.next ==
					&chunk0->list));
			mix(&digest, (unsigned long)packet.req.valid);

			proc.nohost = 1;
			defer_node.zeroing_workers.counter = 0;
			memset(&packet, 0, sizeof(packet));
			action = __ihk_numa_free_pages_deferred_result(
				&defer_node, ARENA_BASE + 239 * LOCAL_PAGE_SIZE,
				1, &packet, 1, (unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				7, syscall_number);
			require(action == 0);
			require(defer_node.nr_to_zero_pages.counter == 4);
			require(defer_node.zeroing_workers.counter == 0);
			require(defer_node.to_zero_list.first == &chunk2->list);
			require(chunk2->list.next == &chunk1->list);
			require(chunk2->addr == ARENA_BASE + 239 * LOCAL_PAGE_SIZE);
			require(chunk2->size == LOCAL_PAGE_SIZE);
			require(packet.req.valid == 0);
			mix(&digest, (unsigned long)action);
			mix(&digest, (unsigned long)defer_node.nr_to_zero_pages.counter);
			mix(&digest, (unsigned long)(chunk2->list.next ==
					&chunk1->list));

			action = __ihk_numa_free_pages_deferred_result(
				&defer_node, ARENA_BASE + 241 * LOCAL_PAGE_SIZE,
				0, &packet, 1, (unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				8, syscall_number);
			require(action == -EINVAL);
			require(defer_node.nr_to_zero_pages.counter == 4);
			require(defer_node.to_zero_list.first == &chunk2->list);
			mix(&digest, (unsigned long)action);
			mix(&digest, (unsigned long)defer_node.nr_to_zero_pages.counter);

			action = __ihk_numa_free_pages_deferred_result(
				NULL, ARENA_BASE + 241 * LOCAL_PAGE_SIZE, 1,
				&packet, 1, (unsigned long)&current,
				(unsigned long)&idle,
				__builtin_offsetof(struct thread, proc),
				__builtin_offsetof(struct process, nohost),
				__builtin_offsetof(struct process, pid),
				9, syscall_number);
			require(action == -EINVAL);
			mix(&digest, (unsigned long)action);
		}
	}

	printf("page_alloc_bitmap ok digest=%016lx\n", digest);
	return 0;
}
