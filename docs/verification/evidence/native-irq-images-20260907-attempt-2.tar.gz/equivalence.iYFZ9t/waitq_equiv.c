#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct thread;
struct waitq_entry;

typedef int (*waitq_func_t)(struct waitq_entry *, unsigned, int, void *);

typedef struct ihk_spinlock {
	union {
		unsigned int head_tail;
		struct {
			unsigned short head;
			unsigned short tail;
		} tickets;
	};
} ihk_spinlock_t;

struct list_head {
	struct list_head *next;
	struct list_head *prev;
};

typedef struct waitq {
	ihk_spinlock_t lock;
	struct list_head waitq;
} waitq_t;

typedef struct waitq_entry {
	struct list_head link;
	void *private;
	unsigned int flags;
	waitq_func_t func;
} waitq_entry_t;

struct item {
	int id;
	int wakes;
	waitq_entry_t entry;
};

struct fake_thread {
	int pad;
	int status;
};

extern void waitq_init(waitq_t *);
extern void waitq_init_entry(waitq_entry_t *, struct thread *);
extern void waitq_init_locked_entry(waitq_entry_t *, struct thread *);
extern void waitq_add_entry_locked(waitq_t *, waitq_entry_t *);
extern void waitq_remove_entry_locked(waitq_t *, waitq_entry_t *);
extern int waitq_wake_nr_locked(waitq_t *, int);
extern int waitq_wake_schedule_needed_result(int);
extern int waitq_active(waitq_t *);
extern void waitq_add_entry(waitq_t *, waitq_entry_t *);
extern void waitq_remove_entry(waitq_t *, waitq_entry_t *);
extern void waitq_wakeup(waitq_t *);
extern int waitq_wake_nr(waitq_t *, int);
extern void waitq_prepare_to_wait_result(waitq_t *, waitq_entry_t *, int,
					 void *, unsigned long);
extern void waitq_finish_wait_result(waitq_t *, waitq_entry_t *, void *,
				     unsigned long, int);

int sched_wakeup_thread(struct thread *thread, int state)
{
	return ((uintptr_t)thread ^ (unsigned int)state) & 0x7fffffff;
}

int sched_wakeup_thread_locked(struct thread *thread, int state)
{
	return (((uintptr_t)thread << 1) ^ (unsigned int)state) & 0x7fffffff;
}

static int schedule_calls;
void schedule(void)
{
	schedule_calls++;
}
void preempt_disable(void) {}
void preempt_enable(void) {}
void cpu_pause(void) {}

void ihk_mc_spinlock_init(ihk_spinlock_t *lock)
{
	lock->head_tail = 0;
}

void __ihk_mc_spinlock_lock_noirq(ihk_spinlock_t *lock)
{
	unsigned int old;
	unsigned short wait_for;

	preempt_disable();
	old = __sync_fetch_and_add(&lock->head_tail, 2U << 16);
	wait_for = (unsigned short)(old >> 16);
	while ((unsigned short)lock->head_tail != wait_for)
		cpu_pause();
}

void __ihk_mc_spinlock_unlock_noirq(ihk_spinlock_t *lock)
{
	__sync_fetch_and_add(&lock->tickets.head, 2);
	preempt_enable();
}

static void mix(unsigned long *digest, unsigned long value)
{
	*digest ^= value + 0x9e3779b97f4a7c15UL + (*digest << 6) + (*digest >> 2);
}

static void require(int condition)
{
	if (!condition)
		exit(21);
}

static struct item *item_from_entry(waitq_entry_t *entry)
{
	return (struct item *)((char *)entry - offsetof(struct item, entry));
}

static struct item *item_from_link(struct list_head *link)
{
	return item_from_entry((waitq_entry_t *)((char *)link -
		offsetof(waitq_entry_t, link)));
}

static int record_wake(waitq_entry_t *entry, unsigned mode, int flags, void *key)
{
	struct item *item = item_from_entry(entry);

	item->wakes += 1 + (int)mode + flags + (key != NULL);
	return item->id;
}

static void digest_waitq(unsigned long *digest, waitq_t *waitq)
{
	struct list_head *head = &waitq->waitq;
	struct list_head *pos = head->next;
	int count = 0;

	require(head->prev->next == head);
	require(head->next->prev == head);
	mix(digest, waitq->lock.head_tail);
	while (pos != head) {
		struct item *item = item_from_link(pos);

		require(pos->next->prev == pos);
		require(pos->prev->next == pos);
		mix(digest, ((unsigned long)(unsigned int)item->id << 32) |
			    (unsigned int)item->wakes);
		pos = pos->next;
		require(++count < 32);
	}
	mix(digest, (unsigned long)count);
}

int main(void)
{
	waitq_t waitq;
	struct item items[5];
	unsigned long digest = 0x0bad5eed7157cafeUL;
	int ret;

	for (int i = 0; i < 5; i++) {
		items[i].id = i + 10;
		items[i].wakes = 0;
		items[i].entry.flags = 0xf00d0000U + i;
		waitq_init_entry(&items[i].entry,
				 (struct thread *)(uintptr_t)(0x1000 + i * 0x40));
		require(items[i].entry.func != NULL);
		mix(&digest, (unsigned long)items[i].entry.func(
			&items[i].entry, 0, 0, NULL));
		items[i].entry.func = record_wake;
		require(items[i].entry.private ==
			(void *)(uintptr_t)(0x1000 + i * 0x40));
		require(items[i].entry.flags == 0);
	}

	items[4].entry.flags = 0xbeef0004U;
	waitq_init_locked_entry(&items[4].entry,
				(struct thread *)(uintptr_t)0x5a5a);
	require(items[4].entry.private == (void *)(uintptr_t)0x5a5a);
	require(items[4].entry.flags == 0);
	require(items[4].entry.func != NULL);
	mix(&digest, (unsigned long)items[4].entry.func(
		&items[4].entry, 0, 0, NULL));

	waitq.lock.head_tail = 0xffffffffU;
	waitq_init(&waitq);
	require(waitq.lock.head_tail == 0);
	digest_waitq(&digest, &waitq);

	waitq_add_entry_locked(&waitq, &items[0].entry);
	waitq_add_entry_locked(&waitq, &items[1].entry);
	waitq_add_entry_locked(&waitq, &items[2].entry);
	digest_waitq(&digest, &waitq);

	ret = waitq_wake_nr_locked(&waitq, 0);
	require(ret == 0);
	require(waitq_wake_schedule_needed_result(ret) == 0);
	require(items[0].wakes == 0 && items[1].wakes == 0 && items[2].wakes == 0);
	mix(&digest, (unsigned long)(int)ret);

	ret = waitq_wake_nr_locked(&waitq, 2);
	require(ret == 2);
	require(waitq_wake_schedule_needed_result(ret) == 1);
	require(items[0].wakes == 1 && items[1].wakes == 1 && items[2].wakes == 0);
	mix(&digest, (unsigned long)(int)ret);
	digest_waitq(&digest, &waitq);

	waitq_remove_entry_locked(&waitq, &items[1].entry);
	require(items[1].entry.link.next == &items[1].entry.link);
	require(items[1].entry.link.prev == &items[1].entry.link);
	digest_waitq(&digest, &waitq);

	waitq_add_entry_locked(&waitq, &items[3].entry);
	waitq_add_entry_locked(&waitq, &items[1].entry);
	digest_waitq(&digest, &waitq);

	ret = waitq_wake_nr_locked(&waitq, 10);
	require(ret == 3);
	require(items[0].wakes == 2 && items[2].wakes == 1 &&
		items[3].wakes == 1 && items[1].wakes == 2);
	mix(&digest, (unsigned long)(int)ret);
	digest_waitq(&digest, &waitq);

	waitq_remove_entry_locked(&waitq, &items[0].entry);
	waitq_remove_entry_locked(&waitq, &items[2].entry);
	waitq_remove_entry_locked(&waitq, &items[3].entry);
	waitq_remove_entry_locked(&waitq, &items[1].entry);
	digest_waitq(&digest, &waitq);

	ret = waitq_wake_nr_locked(&waitq, 1);
	require(ret == -1);
	require(waitq_wake_schedule_needed_result(ret) == 0);
	mix(&digest, (unsigned long)(int)ret);

	for (int i = 0; i < 5; i++) {
		items[i].wakes = 0;
		waitq_init_entry(&items[i].entry,
				 (struct thread *)(uintptr_t)(0x3000 + i * 0x20));
		items[i].entry.func = record_wake;
	}
	waitq_init(&waitq);
	require(waitq_active(&waitq) == 0);
	waitq_add_entry(&waitq, &items[0].entry);
	waitq_add_entry(&waitq, &items[1].entry);
	require(waitq_active(&waitq) == 1);
	waitq_wakeup(&waitq);
	require(items[0].wakes == 1 && items[1].wakes == 1);
	schedule_calls = 0;
	ret = waitq_wake_nr(&waitq, 1);
	require(ret == 1);
	require(schedule_calls == 1);
	require(items[0].wakes == 2 && items[1].wakes == 1);
	waitq_remove_entry(&waitq, &items[0].entry);
	waitq_remove_entry(&waitq, &items[1].entry);
	require(waitq_active(&waitq) == 0);
	digest_waitq(&digest, &waitq);
	mix(&digest, (unsigned long)schedule_calls);

	{
		struct fake_thread current = { .pad = 0x55, .status = 0x66 };

		waitq_init(&waitq);
		waitq_init_entry(&items[4].entry,
				 (struct thread *)(uintptr_t)0x4444);
		items[4].entry.func = record_wake;
		waitq_prepare_to_wait_result(&waitq, &items[4].entry, 0x77,
			&current, offsetof(struct fake_thread, status));
		require(current.status == 0x77);
		require(waitq_active(&waitq) == 1);
		waitq_prepare_to_wait_result(&waitq, &items[4].entry, 0x88,
			&current, offsetof(struct fake_thread, status));
		require(current.status == 0x88);
		ret = waitq_wake_nr(&waitq, 10);
		require(ret == 0);
		require(items[4].wakes == 1);
		waitq_finish_wait_result(&waitq, &items[4].entry, &current,
			offsetof(struct fake_thread, status), 0x99);
		require(current.status == 0x99);
		require(waitq_active(&waitq) == 0);
		require(items[4].entry.link.next == &items[4].entry.link);
		require(items[4].entry.link.prev == &items[4].entry.link);
		digest_waitq(&digest, &waitq);
		mix(&digest, (unsigned long)(unsigned int)current.status);
	}

	printf("waitq ok digest=%016lx\n", digest);
	return 0;
}
