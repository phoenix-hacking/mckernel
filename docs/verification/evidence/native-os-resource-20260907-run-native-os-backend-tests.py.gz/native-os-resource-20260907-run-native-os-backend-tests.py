import os,sys,json,hashlib,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
repo=Path('/workspace');out=Path('/work/native-os-backend-tests-20260907');out.mkdir(exist_ok=True)
paths=['host-kernel/native-rust/'+s for s in ['abi/x86_64.rs','device_registry.rs','os_registry.rs','ihk_ioctl.rs','os_runtime.rs']]+['scripts/tests/fixtures/ihk_os_runtime_compile.rs','scripts/tests/test_ihk_os_runtime.py']
for rel in paths:
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/rel,target)
resource=out/'host-kernel/native-rust/os_runtime.rs'
record={'started_utc':datetime.now(timezone.utc).isoformat(),'paths':[],'repository_runtime_before_format_sha256':hashlib.sha256(resource.read_bytes()).hexdigest()}
subprocess.run(['rustfmt','--edition','2021',str(resource)],check=True)
for rel in paths:
 b=(out/rel).read_bytes();record['paths'].append({'path':rel,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',MCKERNEL_RUSTC_1_92='/usr/bin/rustc')
command=['python3','-m','unittest','discover','-s','scripts/tests','-p','test_ihk_os_runtime.py','-f']
with (out/'tests.log').open('wb') as log:
 result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(command=command,exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat())
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print('OS_BACKEND_TEST_EXIT',result.returncode,flush=True)
print((out/'tests.log').read_text()[-9000:],flush=True)
sys.exit(result.returncode)
