use std::marker::{PhantomData, PhantomPinned};
use std::sync::Arc;

struct PendingFreeBatch { _pin: PhantomPinned, _owner: PhantomData<*mut ()> }
fn require_sync<T: Sync>() {}
fn main() {
    require_sync::<PendingFreeBatch>();
    let _ = Arc::new(PendingFreeBatch { _pin: PhantomPinned, _owner: PhantomData });
}
