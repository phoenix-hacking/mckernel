use std::marker::{PhantomData, PhantomPinned};
use std::mem::needs_drop;
use std::pin::Pin;

struct PendingFreeBatch { _pin: PhantomPinned, _owner: PhantomData<*mut ()> }
fn require_unpin<T: Unpin>() {}
fn main() {
    let _ = Pin::new(&PendingFreeBatch { _pin: PhantomPinned, _owner: PhantomData });
    require_unpin::<PendingFreeBatch>();
    let _ = needs_drop::<PendingFreeBatch>();
}
