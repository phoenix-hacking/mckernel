"""Retain actual launcher progress, metadata/decoder fixes and all original failures."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile, re
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace'); work=Path('/work')
out=work/('native-application-launcher-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-launcher-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],linux_compiler_bindings=[],
    application_launch_attempted=True,mckernel_application_executed=False,production_gate_credit=False,
    declared_stage_integrated=False,application_acceptance='FAIL: START_IMAGE remains unimplemented')
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-mcctrl-image-checkpoint-20260908.json','storage-maintenance-20260908-8.json']:
        path=repo/'docs/verification'/name
        state=json.loads(path.read_text()); assert state['status']=='PASS'
        row=identity(path);row['path']=str(path.relative_to(repo));record['references'].append(row)
        for item in state['artifacts']:
            verify(dict(item,path=str(repo/item['path'])))
            with gzip.open(repo/item['path'],'rb') as stream:
                while stream.read(1<<20):pass
    captures=[
        ('native-application-launcher-20260908-1','FAIL'),
        ('native-application-launcher-20260908-2','PASS'),
        ('native-application-launcher-guest-20260908-1','FAIL'),
        ('native-application-launcher-guest-20260908-2','FAIL'),
        ('native-application-service-module-20260908-1','PASS'),
        ('native-application-service-module-20260908-2','PASS'),
        ('native-application-services-buildid-guest-20260908-1','PASS'),
        ('native-application-services-application-guest-20260908-1','FAIL'),
        ('native-application-services-application-guest-20260908-2','FAIL'),
        ('native-application-image-20260908-4','FAIL'),
        ('native-application-image-20260908-5','FAIL'),
        ('native-application-image-20260908-6','PASS'),
        ('native-application-services-regression-20260908-x86_64-1','PASS'),
        ('native-application-services-regression-20260908-i386-1','PASS'),
        ('native-launcher-compiler-reference-20260908-1','PASS')]
    assert len(captures)==15 and sum(status=='FAIL' for name,status in captures)==7
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text())
        assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[])+state.get('source_overlays',[]):verify(row)
        for row in state.get('overlay',[]):
            verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        for capture in state.get('captures',[]):
            for row in capture['artifacts']:verify(row)
        for selection in state.get('launchers',[]):
            for row in selection['outputs']:verify(row)
        for pair in state.get('runtime_libraries',[]):
            verify(pair['captured'])
            assert (pair['original']['size'],pair['original']['sha256'])==(pair['captured']['size'],pair['captured']['sha256'])
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,error=state.get('error'),
            physical_captures=len(state.get('captures',[])),complete_capture_retained=True,archive_exclusions={}))

    compiled=work/'native-application-service-module-20260908-2'
    replays=[]
    for saved in sorted((compiled/'staged-source').rglob('*.rs')):
        relative=saved.relative_to(compiled/'staged-source')
        current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if current.read_bytes()==saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs')
            shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='Exact pinned rustfmt replay; original and formatted files retained',
                compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,
                format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(row);replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'}
    for name in ['smp_trampoline.S','smp_startup_entry.S']:
        record['native_compiler_bindings'].append(binding(repo/'host-kernel/native-rust'/name,compiled/'staged-source'/name))
    assert len(record['native_compiler_bindings'])==49

    protocol=work/'native-application-image-20260908-6'
    state=json.loads((protocol/'record.json').read_text());assert state['status']=='PASS'
    assert state['c_layout']==[128,8,0,8,12,16,24,28,32,40,48,120,9,10]
    assert state['image_c_layout']==[776,8,56,8,776,14627351833160655377,8,12,16,28,72,80,88,96,104,152,160,168,176,504,640,768]
    assert '8 passed; 0 failed;' in (protocol/'protocol-tests.log').read_text()
    assert '11 passed; 0 failed;' in (protocol/'image-tests.log').read_text()
    record['protocol_compiler_bindings']=[]
    for row in state['inputs']:
        relative=Path(row['path']).relative_to(protocol/'original-inputs')
        record['protocol_compiler_bindings'].append(binding(repo/relative,protocol/'source'/relative))
    assert len(record['protocol_compiler_bindings'])==15
    for body in state['extracted_bodies']:
        raw=(protocol/'source'/body['source']).read_bytes()[body['start_byte']:body['end_byte']]
        assert hashlib.sha256(raw).hexdigest()==body['sha256'],body
    assert len(state['extracted_bodies'])==21
    record['protocol']=dict(tests_passed=19,original_tests_preserved=17,actual_launcher_producer_vectors=6,
        c_packet_layout_values=14,c_and_guest_rust_image_layout_values=22,exact_guest_rust_bodies=11,
        exact_launcher_rust_bodies=5,exact_launcher_c_body=1,exact_c_packet_declarations=4,
        reproduced_failure='native-application-image-20260908-5',original_zero_slot_encoding_still_accepted=True,
        terminal_length_bounds_enforced=True)
    launcher=work/'native-application-launcher-20260908-2'
    launcher_state=json.loads((launcher/'record.json').read_text());assert launcher_state['status']=='PASS'
    record['launcher_compiler_bindings']=[]
    for row in launcher_state['inputs']:
        relative=Path(row['path']).relative_to(launcher/'source')
        record['launcher_compiler_bindings'].append(binding(repo/relative,launcher/'source'/relative))
    assert len(record['launcher_compiler_bindings'])==7
    reference=work/'native-launcher-compiler-reference-20260908-1'
    reference_state=json.loads((reference/'record.json').read_text());assert reference_state['status']=='PASS'
    verify(reference_state['build_record'])
    actual_dependencies=[]
    for pair in reference_state['bindings']:
        verify(pair['captured'])
        assert (pair['captured']['size'],pair['captured']['sha256'])==(pair['original']['size'],pair['original']['sha256'])
        actual_dependencies.append(pair['original'])
    assert actual_dependencies==launcher_state['compiler_dependencies'] and len(actual_dependencies)==226
    record['launcher_dependencies']=reference_state['bindings']
    record['launchers']=launcher_state['launchers']
    assert {row['selection'] for row in record['launchers']}=={'rust','fallback'}
    assert launcher_state['linux_reference']==dict(exit_code=37,kernel='container Linux',mckernel=False,stdout='NATIVE_APPLICATION_HELLO\n')
    record['linux_reference']=launcher_state['linux_reference']
    for selection in ('rust','fallback'):
        flags=(launcher/selection/'executer/user/CMakeFiles/mcexec.dir/flags.make').read_text()
        assert not re.search(r'(?:^|\s)-O[0-9szg]',flags)
    record['c_producer_optimization']='-O0 matches both actual launcher Debug C builds; all fixture warnings remain errors'
    record['sparse_source_snapshot']=launcher_state['sparse_exclusion']
    assert record['sparse_source_snapshot']['source_code_excluded'] is False
    record['guest_peer_source_bindings']=[]
    for relative in ['kernel/rust/host_helpers.rs','kernel/rust/abi.rs','kernel/rust/syscall_policy.rs','kernel/syscall.c',
                     'kernel/rust/object_helpers.rs','kernel/rust/procfs.rs','kernel/procfs.c',
                     'kernel/rust/process_helpers.rs','kernel/process.c','kernel/host.c','kernel/rust/sched_helpers.rs']:
        record['guest_peer_source_bindings'].append(binding(repo/relative,work/'mckernel-native-sysfs-images-20260908-2/source'/relative))

    metadata=work/'native-application-services-buildid-guest-20260908-1'
    metadata_state=json.loads((metadata/'record.json').read_text())
    assert metadata_state['status']=='PASS' and len(metadata_state['captures'])==3
    assert all(row['status']==3 and row['validated'] for row in metadata_state['captures'])
    assert metadata_state['buildid']==dict(interfaces=2,states=4,guarded=8,faults=20,mcctrl_absent=True)
    record['metadata']=metadata_state['buildid']
    for relative in ['native-os-buildid.c','native-os-resource-assignment.c','native-memory-reservation.c','native-cpu-reservation.c']:
        record['linux_compiler_bindings'].append(binding(repo/'scripts/tests/fixtures'/relative,metadata/'probe-source'/relative))
    record['metadata_original_c_abi']=binding(repo/'ihk/linux/include/ihk/ihk_host_user.h',metadata/'probe-source/ihk_host_user.h.reference')
    record['compatibility_payload']=identity(compiled/'staged-source/ihk-compat-build-id.bin')
    expected_id=re.findall(r'^#define BUILDID ("[^"\n]+")$',(launcher/'rust/config.h').read_text(),re.M)
    assert len(expected_id)==1
    assert (compiled/'staged-source/ihk-compat-build-id.bin').read_bytes()==json.loads(expected_id[0]).encode()+b'\0'

    latest=work/'native-application-services-application-guest-20260908-2'
    latest_state=json.loads((latest/'record.json').read_text())
    assert latest_state['status']=='FAIL' and latest_state['application_attempted']
    assert latest_state['mckernel_application_executed'] is False
    serial=(latest/'serial.log').read_text()
    live=serial.split('NATIVE_APPLICATION_MCEXEC begin',1)[1].split('NATIVE_APPLICATION_GUEST FAIL',1)[0]
    prepared=re.findall(r'application prepare ACK os=0 generation=(\d+) pid=(\d+) token=(\d+) errno=0 abandoned=0 quarantined=0',live)
    assert len(prepared)==1
    generation,pid,token=prepared[0]
    assert f'application_image=prepared os=0 generation={generation} pid={pid} sections=1 cpu=0' in live
    assert 'exec: Invalid argument' in live and 'prepare: Invalid argument' not in live
    assert 'NATIVE_APPLICATION_HELLO' not in live and 'NATIVE_APPLICATION_MCEXEC exit=1' in live
    cleanup=re.findall(r'application cleanup ACK os=0 generation='+generation+r' pid='+pid+r' token=(\d+) errno=0 abandoned=0',live)
    assert len(cleanup)==1 and cleanup[0]!=token
    assert f'application unscheduled delete os=0 generation={generation} pid={pid} cpu=0 tid=0 cleanup_token={cleanup[0]}' in live
    assert f'application_process=release os=0 generation={generation} pid={pid} cleanup_errno=0' in live
    kmsg=(latest/'capture-emergency/kmsg.txt').read_text()
    thread=re.findall(r'mcexec_v10: prepared pid='+pid+r' thread=([0-9a-f]+) entry=(0x[0-9a-f]+) sp=(0x[0-9a-f]+) sections=1',kmsg)
    assert len(thread)==1 and thread[0][1]=='0x40010c'
    assert 'SCD_MSG_SCHEDULE_PROCESS:' not in kmsg
    record['actual_launcher']=dict(capture=str(latest),overall_result='FAIL',reached='START_IMAGE',start_errno=-22,
        native_pid=int(pid),generation=int(generation),prepared_sections=1,guest_thread=thread[0][0],
        entry=thread[0][1],stack=thread[0][2],prepare_token=int(token),cleanup_token=int(cleanup[0]),
        cleanup_ack=True,unscheduled_deletion=True,registration_released=True,application_instructions_executed=False,
        attribution='Exact unchanged launcher error bridge and guest prepare kmsg; emergency capture is diagnostic, not a passing application capture')

    prior=json.loads((repo/'docs/verification/native-mcctrl-image-checkpoint-20260908.json').read_text())
    record['regressions']=[]
    for interface,old,count in [('x86_64','native-mcctrl-image-guest-20260908-x86_64-4',4),('i386','native-mcctrl-image-regression-guest-20260908-i386-1',3)]:
        current=work/('native-application-services-regression-20260908-'+interface+'-1')
        state=json.loads((current/'record.json').read_text())
        original_state=json.loads((work/old/'record.json').read_text())
        assert state['status']=='PASS' and len(state['captures'])==count
        assert all(row['status']==3 and row['validated'] for row in state['captures'])
        for key in ['mcctrl_service','mcctrl_executable','mcctrl_process']:
            assert state[key]==original_state[key],(interface,key)
        if interface=='x86_64':
            assert state['mcctrl_image']==original_state['mcctrl_image']
            assert state['mcctrl_image']['checks']==47
        for path in sorted((current/'probe-source').iterdir()):
            relative='executer/include/uprotocol.h' if path.name=='native-image-c-abi.h' else 'scripts/tests/fixtures/'+path.name
            record['linux_compiler_bindings'].append(binding(repo/relative,path))
        record['regressions'].append(dict(interface=interface,capture=str(current),physical_captures=count,
            image_checks=47 if interface=='x86_64' else None,original_service_exec_process_assertions_unchanged=True,
            image_preparation_compatibility_proven=False if interface=='i386' else None))
    assert len(record['linux_compiler_bindings'])==20

    references=out/'source-references';references.mkdir()
    record['source_reference_bindings']=[]
    linux=work/'native-source/linux-6.12.0-211.44.1.el10_2'
    for source_root,relative in [(repo,'ihk/linux/core/host_driver.c'),(repo,'ihk/linux/driver/smp/smp-driver.c'),
                                (repo,'ihk/CMakeLists.txt'),(linux,'rust/kernel/uaccess.rs'),
                                (linux,'rust/kernel/sync/lock/mutex.rs')]:
        target=references/('linux' if source_root==linux else 'project')/relative
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source_root/relative,target)
        row=identity(source_root/relative);saved=identity(target)
        assert (row['size'],row['sha256'])==(saved['size'],saved['sha256'])
        record['source_reference_bindings'].append(dict(original=row,captured=saved))
    artifact(out/'format-replay','native-launcher-format-replay-20260908.tar.gz',True)
    artifact(references,'native-launcher-reference-sources-20260908.tar.gz',True)
    for name in ['build-native-application-launcher.py','build-native-application-services.py',
                 'run-native-application-launcher.py','run-native-application-services.py',
                 'run-native-application-regression.py','run-native-application-regression-compat.py',
                 'test-native-application-image.py','retain-native-launcher-compiler.py','retain-native-application-launcher.py']:
        artifact(work/name,'native-launcher-20260908-'+name+'.gz')
    record.update(status='PASS',scope='Verified native OS metadata and exact real launcher argument format; full preserved actual launcher failures, now reaching START_IMAGE; successful native and compat baseline regressions. Application execution and production acceptance remain incomplete.',
        artifact_bytes=sum(row['size'] for row in record['artifacts']),complete_captures=len(captures),original_failures_preserved=7,
        current_native_module=str(compiled),current_protocol=str(protocol),independent_acceptance=False)
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
