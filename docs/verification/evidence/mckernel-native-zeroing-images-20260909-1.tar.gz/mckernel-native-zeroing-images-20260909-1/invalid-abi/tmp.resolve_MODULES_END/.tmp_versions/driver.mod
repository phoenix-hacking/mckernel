/work/mckernel-native-zeroing-images-20260909-1/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-zeroing-images-20260909-1/invalid-abi/tmp.resolve_MODULES_END/driver.o

