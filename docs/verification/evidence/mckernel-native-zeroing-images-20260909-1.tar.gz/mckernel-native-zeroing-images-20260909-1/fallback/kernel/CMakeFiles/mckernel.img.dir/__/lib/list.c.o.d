kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o: \
 /work/mckernel-native-zeroing-images-20260909-1/source/lib/list.c \
 /work/mckernel-native-zeroing-images-20260909-1/source/lib/include/list.h
