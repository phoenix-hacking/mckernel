/work/mckernel-native-zeroing-images-20260909-1/invalid-sysfs-legacy/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-zeroing-images-20260909-1/invalid-sysfs-legacy/tmp.resolve_MODULES_END/driver.o

