"""Pinned native-container tests against unmodified C and Rust syscall peers."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace')
out=Path('/work/native-application-syscall-20260908-'+sys.argv[1]);out.mkdir()
source=out/'source';fixture=source/'scripts/tests/fixtures'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    commands=[],extracted_bodies=[],production_gate_credit=False,
    mckernel_application_executed=False,native_mailbox_integrated=False,
    scope='Native syscall protocol prerequisite: exact existing C/Rust request producers, actual original C completion bodies, exact guest Rust wake consumer, delivery ownership and atomic completion/queue-full tests; no guest transport or user ioctl acceptance')

def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())

def run(label,args):
    print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-16000:])

def extract(path,pattern,name,semicolon=False):
    data=path.read_text();match=re.search(pattern,data,re.M);assert match,name
    start=match.start();opening=data.index('{',start);end=opening+1;depth=1
    while depth:
        depth+=(data[end]=='{')-(data[end]=='}');end+=1
    if semicolon:
        assert data[end]==';';end+=1
    body=data[start:end]
    record['extracted_bodies'].append(dict(source=str(path.relative_to(source)),name=name,
        start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
    return body+'\n'

try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['host-kernel/native-rust/application_rpc.rs','host-kernel/native-rust/application_syscall.rs',
        'kernel/rust/abi.rs','kernel/rust/syscall_policy.rs','kernel/rust/host_helpers.rs',
        'kernel/include/syscall.h','kernel/syscall.c','executer/include/uprotocol.h',
        'executer/kernel/mcctrl/syscall.c','ihk/ikc/include/ikc/queue.h',
        'scripts/tests/fixtures/native-application-syscall.c','scripts/tests/fixtures/native-application-syscall.rs']
    for name in names:
        saved=out/'original-inputs'/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,saved)
        target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(saved,target)
    record['inputs']=[identity(out/'original-inputs'/name) for name in names]
    csource=source/'kernel/include/syscall.h'
    generated=extract(source/'ihk/ikc/include/ikc/queue.h',r'^struct ihk_ikc_packet_header \{','ihk_ikc_packet_header',True)
    for kind,name in [('enum','mcctrl_os_cpu_operation'),('struct','ikc_scd_packet')]:
        generated+=extract(csource,r'^'+kind+' '+name+r' \{',name,True)
    generated+='#define syscall_response guest_syscall_response\n'
    generated+=extract(csource,r'^struct syscall_response \{','guest_syscall_response',True)
    generated+='#undef syscall_response\n'
    for name in ['SCD_MSG_SYSCALL_ONESIDE','SCD_MSG_WAKE_UP_SYSCALL_THREAD']:
        match=re.search(r'^#define '+name+r'\s+[^\n]+',csource.read_text(),re.M);assert match,name
        generated+=match[0]+'\n'
    (fixture/'native-application-syscall-c-layout.h').write_text(generated)
    names_body=['syscall_use_requester_tid_result','syscall_target_tid_result','syscall_offload_prepare_result',
        'syscall_send_prepare_result','syscall_request_copy_result','syscall_request_publish_result','syscall_packet_traditional_prepare_result']
    generated=''
    for name in names_body:
        generated+=extract(source/'kernel/syscall.c',r'^SYSCALL_POLICY_HELPER_SCOPE int\n'+name+r'\(',name)
    (fixture/'native-application-syscall-c-producer.h').write_text(generated)
    generated=extract(source/'executer/kernel/mcctrl/syscall.c',r'^static int __notify_syscall_requester\(','__notify_syscall_requester')
    generated+=extract(source/'executer/kernel/mcctrl/syscall.c',r'^void __return_syscall\(','__return_syscall')
    (fixture/'native-application-syscall-c-completion.h').write_text(generated)
    generated='use crate::abi::*;\nuse core::{ffi::c_void,mem::size_of,ptr::{write,copy_nonoverlapping,addr_of_mut},sync::atomic::{AtomicU64,Ordering}};\n'
    rust=source/'kernel/rust/syscall_policy.rs';match=re.search(r'^const EINVAL:[^\n]+;',rust.read_text(),re.M);assert match
    generated+=match[0]+'\n'
    for name in names_body:
        generated+=extract(rust,r'^pub (?:unsafe )?(?:extern "C" )?fn '+name+r'\(',name)
    (fixture/'native-application-syscall-rust-producer.rs').write_text(generated)
    rust=source/'kernel/rust/host_helpers.rs';data=rust.read_text()
    generated='use crate::abi::*;\nuse core::ffi::c_void;\n'
    match=re.search(r'^const EINVAL:[^\n]+;',data,re.M);assert match;generated+=match[0]+'\n'
    for name in ['HostFindThreadFn','HostWakeupThreadFn','HostThreadUnlockFn','HostWakeSyscallLogFn']:
        match=re.search(r'^pub type '+name+r'\b[^;]+;',data,re.M);assert match,name;generated+=match[0]+'\n'
    for name in ['host_find_thread_result','host_wakeup_thread_result','host_thread_unlock_result','host_wake_syscall_log_result','host_wake_syscall_thread_request_result']:
        generated+=extract(rust,r'^pub unsafe extern "C" fn '+name+r'\(',name)
    (fixture/'native-application-syscall-rust-wake.rs').write_text(generated)
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',
        str(source/'host-kernel/native-rust/application_rpc.rs'),str(source/'host-kernel/native-rust/application_syscall.rs'),str(fixture/'native-application-syscall.rs')])
    # The untouched host C completion has a ppd argument used only under the
    # disabled Tofu build. Suppress only unused parameters for this C reference.
    run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter',str(fixture/'native-application-syscall.c'),'-o',str(out/'c-reference')])
    run('c-reference',[str(out/'c-reference')])
    shutil.copyfile(out/'c-reference.log',fixture/'native-application-syscall-c.txt')
    record['c_layout']=list(map(int,(out/'c-reference.log').read_text().splitlines()[0].split()[1:]))
    run('rust-build',['rustc','--edition','2021','--test',str(fixture/'native-application-syscall.rs'),'-o',str(out/'syscall-tests')])
    run('rust-tests',[str(out/'syscall-tests'),'--nocapture'])
    record['compiler_inputs']=[identity(path) for path in sorted(source.rglob('*')) if path.is_file()]
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
    record.update(status='PASS',exact_request_vectors=6,exact_completion_vectors=12,queue_full_retries=1024,atomic_race_rounds=256,concurrent_tokens=4096)
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
