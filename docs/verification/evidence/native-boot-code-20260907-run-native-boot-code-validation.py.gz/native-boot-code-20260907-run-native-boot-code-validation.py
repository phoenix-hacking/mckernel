from datetime import datetime, timezone
from pathlib import Path
import json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
base = Path('/work/native-boot-code-validation-20260907-1')
base.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[], production_gate_credit=False)
commands = [
    ['git', '-C', '/workspace', 'diff', '--check'],
    ['rustfmt', '--check', '--edition', '2021', '/workspace/scripts/tests/fixtures/mckernel_trampoline_region_verify.rs'],
] + [['python3', '-B', '/work/run-native-trampoline-region-guest.py', mode, '3', '2'] for mode in ('normal', 'reserved', 'hole')]
for index, command in enumerate(commands):
    print('Starting trampoline region validation', index, command, flush=True)
    with (base / ('step-' + str(index) + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd='/workspace', stdout=log, stderr=subprocess.STDOUT)
    record['results'].append(dict(command=command, exit_code=result.returncode))
    record['updated_utc'] = datetime.now(timezone.utc).isoformat()
    record['exit_code'] = result.returncode
    (base / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Finished trampoline region validation', index, 'exit', result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
