"""Build only; the same executable's Linux oracle runs inside the pinned guest."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
assert len(sys.argv) == 2 and re.fullmatch(r'[1-9][0-9]*', sys.argv[1])
repo = Path('/workspace')
out = Path('/work/native-ultra-futex-build-20260909-' + sys.argv[1])
out.mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    commands=[], inputs=[], runtime_libraries=[], compiler_dependencies=[],
    scope='Compile a bounded ordinary futex/pthread application; no Linux or McKernel execution at build time',
    linux_reference_executed=False, mckernel_application_executed=False, production_gate_credit=False)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as stream:
        result = subprocess.run(command, cwd=str(out), stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, result.returncode)
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'helper.py')
    original = repo / 'scripts/tests/fixtures/native-ultra-futex.c'
    source = out / 'native-ultra-futex.c'
    shutil.copyfile(original, source)
    record['inputs'] = [identity(original), identity(source), identity(Path(__file__))]
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    record['compiler'] = run('compiler', ['cc', '--version'])
    binary = out / 'native-ultra-futex'
    run('build', ['cc', '-std=gnu11', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
        '-fno-pie', '-no-pie', '-fno-stack-protector', '-Wl,-z,noexecstack', '-pthread', '-MD', '-MF',
        str(out / 'compiler.d'), str(source), '-o', str(binary)])
    header = run('elf', ['readelf', '-h', '-l', str(binary)])
    assert 'ELF64' in header and 'EXEC' in header and 'INTERP' in header
    record['linkage'] = 'x86_64 ET_EXEC, native dynamic libc/pthread, ordinary SYS_futex'
    run('disassembly', ['objdump', '-d', str(binary)])
    symbols = run('sized-symbols', ['nm', '-S', str(binary)])
    entries = [line.split() for line in symbols.splitlines() if line.split()[-1:] == ['raw_child_entry']]
    assert len(entries) == 1 and len(entries[0]) == 4, entries
    start, size = int(entries[0][0], 16), int(entries[0][1], 16)
    assert size > 0
    child_code = run('raw-child-disassembly', ['objdump', '-d', '--no-show-raw-insn',
        '--start-address=' + hex(start), '--stop-address=' + hex(start + size), str(binary)])
    assert len(re.findall(r'\bsyscall\b', child_code)) == 1, child_code
    assert not re.search(r'\bcallq?\b|%fs:|%gs:|__stack_chk|@plt', child_code), child_code
    record['raw_child_code'] = dict(symbol='raw_child_entry', address=start, size=size,
        exact_syscalls=1, no_call_instructions=True, no_tls_segments=True, stack_protector=False)
    libraries = run('libraries', ['ldd', str(binary)])
    assert 'not found' not in libraries
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', libraries))):
        path = Path(name)
        target = out / 'runtime' / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        record['runtime_libraries'].append(dict(original=identity(path), captured=identity(target)))
    assert record['runtime_libraries']
    for name in (out / 'compiler.d').read_text().replace('\\\n', ' ').split()[1:]:
        path = Path(name)
        if path.is_absolute() and path.is_file():
            record['compiler_dependencies'].append(identity(path))
    assert record['compiler_dependencies']
    record['application_contract'] = dict(
        stdout='NATIVE_ULTRA_FUTEX PASS cases=16 threads=2 raw_clone=1\n', exit_code=37,
        case_count=16, pthread_workers=2, maximum_live_application_threads=3,
        pthread_stack_bytes=262144, guard_bytes=4096,
        explicit_fixture_allocation_limit_bytes=1048576,
        total_virtual_size_or_rss_asserted=False,
        raw_clone=dict(threads=1, shared_vm=True, child_settid=True, child_cleartid=True,
            child_uses_libc_or_tls=False, parent_joins_shared_futex=True,
            flags=0x100 | 0x200 | 0x400 | 0x800 | 0x10000 | 0x40000 | 0x1000000 | 0x200000),
        reference_placement='Execute this exact binary directly in the isolated pinned Linux guest before mcexec',
        unsupported_or_unverified=['external signals', 'realtime clock steps', 'WAKE_OP', 'PI',
            'robust mutex owner death', 'UTI', 'fork/COW', 'invalid CLONE_CHILD_SETTID store cases'])
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['path'])) == row, row
    record.update(status='PASS', phase='complete', binary=identity(binary))
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name != 'record.json']
    save()
    print(record['status'], out, flush=True)
