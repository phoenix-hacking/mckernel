"""Update the pending review queue inside the isolated native container."""
import collections
import copy
import json
from pathlib import Path
import sys

sys.path.insert(0, '/workspace/scripts')
import native_rust_unsafe_ffi_ledger as checker

repo = '/workspace'
ledger = json.loads(Path(repo, checker.LEDGER_PATH).read_text())
discovery = checker.discover(repo)
allowed_changed = {'RS011-SMP-0014', 'RS011-SMP-0001', 'RS011-IHK-0046',
                   'RS011-IHK-0047', 'RS011-IHK-0048', 'RS011-IHK-0049', 'RS011-IHK-0063'}
remaining = {site['id']: site for site in ledger['sites']}
original_ids = set(remaining)
next_ids = {group: max(int(sid.rsplit('-', 1)[1]) for sid in remaining
                       if sid.startswith('RS011-' + group + '-')) + 1
            for group in ('IHK', 'SMP', 'MCC')}

def key(site):
    return (site['path'], site['kind'], site['expression_sha256'],
            json.dumps(site['macro_context'], sort_keys=True))

common = [
    'Pinned Linux 6.12 x86_64 ABI; no Rust object layout crosses IHK/SMP module boundaries.',
    'Only trusted module code supplies callbacks. IHK retains the SMP module owner before publication and until teardown finishes.',
    'A live IHK OsLease or exclusive NotBooted DestroyGuard supplies slot/generation authority; scalar bounds alone do not prove lifetime.',
    'Process context with a sleepable per-OS mutex; controller ordering is CPU then memory, with no callback reentry into OS operations.',
    'Copy/validate the complete userspace request before logical publication. Native pointers stay 64 bits; compat pointers are zero-extended once and borrowed only for the synchronous callback.',
    'Unbooted destruction preflights both resource classes before either commit and retains both locks through publication. A fallible preflight leaves the instance and resources live.',
    'Assigned CPUs/pages remain Linux-owned reservations. Boot, guest mappings, IKC and booted teardown require additional implementation and review.',
]
records = []
changed = []
new_ids = []
for found in discovery['sites']:
    candidates = [site for site in remaining.values() if key(site) == key(found)]
    if not candidates:
        candidates = [site for site in remaining.values() if site['id'] in allowed_changed
                      and site['path'] == found['path'] and site['kind'] == found['kind']
                      and site['safety_comment']['text'] == found['safety_comment']['text']]
        if candidates:
            if len(candidates) != 1:
                raise SystemExit('Ambiguous reviewed boundary identity')
            changed.append(candidates[0]['id'])
    if candidates:
        record = copy.deepcopy(candidates[0])
        del remaining[record['id']]
        record.update(checker.mechanical_site(found))
    else:
        if found['path'] not in {
            'host-kernel/native-rust/ihk_smp_x86_64.rs', 'host-kernel/native-rust/os_runtime.rs',
            'host-kernel/native-rust/smp_cpu.rs', 'host-kernel/native-rust/smp_memory.rs',
            'host-kernel/native-rust/smp_resource.rs',
        }:
            raise SystemExit('Unexpected new unsafe boundary: ' + found['path'])
        group = 'IHK' if found['path'].endswith('/os_runtime.rs') else 'SMP'
        record = checker.mechanical_site(found)
        record.update(id='RS011-%s-%04d' % (group, next_ids[group]),
                      owner={'component': 'native Rust IHK/SMP unbooted OS resource adapter',
                             'accountable_role': 'host-module maintainer'},
                      caller_obligations=[found['safety_comment']['text']],
                      context_constraints=list(common),
                      compiler_capture={'required': True, 'status': 'not_captured', 'evidence_sha256': None},
                      independent_review={'required': True, 'status': 'pending', 'reviewer': None, 'evidence_sha256': None})
        next_ids[group] += 1
        new_ids.append(record['id'])
    if record['id'] in allowed_changed:
        record['caller_obligations'] = [found['safety_comment']['text']]
        record['context_constraints'] = list(common)
        if record['id'] == 'RS011-SMP-0001':
            record['context_constraints'].append('All seven IHK import relocations resolve before SMP initialization; the retained provider lease owns that dependency until unload.')
    if found['path'].endswith('/smp_memory.rs') and record['id'] in original_ids:
        record['context_constraints'] = [
            line.replace('a live miscdevice file pins every ioctl and published mutex access.',
                         'a live miscdevice file or OS-owned SMP module reference pins every published mutex access.')
                .replace('OS assignment and guest access are not implemented by this adapter.',
                         'OS assignment reuses this canonical map; each whole compound allocation remains owned until all subranges are free. Native boot and guest access remain unimplemented.')
            for line in record['context_constraints']]
        record['context_constraints'].append('Coupled OS cleanup holds the CPU mutex before this memory mutex, preflights both transactions, then commits both without releasing either lock.')
    if found['path'].endswith('/smp_cpu.rs') and record['id'] in original_ids:
        record['context_constraints'].append('The OS module owner also pins published-controller access; assignment preserves CPU rank and reservation owners. Coupled cleanup takes CPU then memory locks.')
    records.append(record)
if remaining or set(changed) != allowed_changed:
    raise SystemExit('Unreviewed retirement or missing explicit boundary update: ' + repr((list(remaining), changed)))
ledger['sites'] = records
ledger['repository_locks'], ledger['target'] = checker.expected_locks(repo)
ledger['crate_roots'] = discovery['roots']
ledger['source_inputs'] = discovery['inputs']
ledger['source_closure_sha256'] = discovery['source_closure_sha256']
ledger['coverage'] = dict(source_input_count=len(discovery['inputs']), site_count=len(records),
    site_ids_sha256=checker.sha256_bytes(checker.canonical_bytes([site['id'] for site in records])),
    by_kind=dict(sorted(collections.Counter(site['kind'] for site in records).items())),
    by_crate={crate: sum(crate in site['crate_roots'] for site in records) for crate in checker.EXPECTED_CRATES},
    source_inventory_status='complete_for_locked_source_bytes')
ledger['ledger_sha256'] = checker.ledger_digest(ledger)
checker.validate_ledger(ledger, repo)
out = Path('/work/native-os-resource-updated-ffi-ledger-20260907.json')
if out.exists():
    raise SystemExit('Refusing to overwrite prior review-queue output')
out.write_text(checker.pretty(ledger))
out.with_suffix('.changes.json').write_text(checker.pretty(dict(changed_existing_ids=changed, new_ids=new_ids, preserved_ids=sorted(original_ids))))
print(checker.pretty(ledger['coverage']), flush=True)
