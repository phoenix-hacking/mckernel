"""Finite additive derivative; source/DATA only, no runtime authorization.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
"""
from pathlib import Path
import ast,hashlib,json,os,re,shutil
D=Path(__file__).resolve().parent;O=D/'bound-runtime-source-expert-correction-1'
G=Path('/home/holden/mckernel-work/host-preparation/m07-proc-acquisition-repair-20261022-1/retention-correction-1/coupled/bound-terminal-proc-v2-source-4')
A=Path('/home/holden/mckernel-work/host-preparation/current-focused-progress-recording-20261021-1/current-normalization-review-recording-1')
def ref(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(v if isinstance(v,str) else json.dumps(v,indent=2,sort_keys=True)+'\n')
def replace(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
def func(s,name):
 node=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name);return '\n'.join(s.splitlines()[node.lineno-1:node.end_lineno])
event=G.parents[2]/'RETAINED-INDEPENDENT-PHYSICAL-REVIEW-EVENT-1.json'
text=load(event)['event']['params']['item']['text'];projection=json.loads(re.findall(r'```json\s*(\{.*?\})\s*```',text,re.S)[0])
base=Path('/home/holden/mckernel-work/host-preparation/M07-current-profile-next-observation-preparation-20261021-1/remaining-components-functional-case-preparation-20261022-1/joint-mpx-exact-fault-correction-1')
ancestry=base/'current053d-stage-preparation-1/ordinary-normalization-runtime-integration-1/outer-runtime-preparation-1/bound-runtime-control-closure-correction-1/current-normal9-role-binding-1/CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json'
archive=base/'native-125-failure-evidence-correction-1/current053d-stage-preparation-1/ordinary-normalization-runtime-integration-1/outer-runtime-preparation-1/bound-runtime-source-expert-correction-1/execution-release-preparation-1/future-failed-owner-minimum-readback-capture-1/stdout'
shutil.copyfile(D/'released_image_record.py',O/'released_image_record.py')
released=dict(role='RELEASED_IMAGE_BUILD_RECORDS_ONLY',physical_acceptance=ref(event),projector=ref(O/'released_image_record.py'),projection=projection,actual_cleanup_result=ref(G/'actual-cleanup-result.json'),actual_cleanup_status=ref(G/'actual-cleanup-capture-1/status.json'),actual_postjoin_status=ref(G/'actual-postjoin-capture-1/status.json'),postjoin_archive_authentication=ref(G/'ROOT-POSTJOIN-ARCHIVE-AUTHENTICATION-1.json'),cleanup_release=ref(G/'cleanup-execution-release.json'),native_acceptance=False,application_acceptance=False,runtime_release=None)
roles=load(O/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json')
roles.update(current_heavy_released_record=released,external_latest_native_physical_review=ref(A/'M07-DIAGNOSTIC-CURRENT-FAILED-OWNER-PHYSICAL-RETIREMENT-ACCEPTANCE.json'),external_latest_native_physical_role='LATEST_SIGILL_FAILED_NATIVE_PHYSICAL_RETIREMENT_ONLY_NO_GLOBAL_CLEARANCE',latest_native_archive=ref(archive),historical_native_ancestry_bindings=ref(ancestry),physical_predecessor=projection,physical_review=ref(event),released_record_projection_source=released['projector'],released_record_review=ref(event),released_record_predecessor=projection,native_controller_source=None,native_controller_pair=None,runtime_execution_release=None,legacy_reference_scope='RELEASED_IMAGE_BUILD_ADMISSION_ONLY_DISTINCT_LATEST_FAILED_NATIVE_AND_HISTORICAL_NATIVE_ANCESTRY')
save(O/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json',roles)
snapshot=(O/'root_manual_snapshot_threads.py').read_text();before=snapshot
addition='''def admission_joins(t,b):
    # Latest heavy release is an IMAGE build. Native schemas remain unchanged.
    role=b['current_heavy_released_record']
    need(role['projector']==b['released_record_projection_source'] and role['physical_acceptance']==b['physical_review'], 'exact separate released-image role descriptors')
    source=Path(role['projector']['path']);need(ref(source)==role['projector'], 'exact released-image consumer source')
    spec=importlib.util.spec_from_file_location('exact_released_image_record',source);decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
    released=decoder.project(t,b['physical_review'],role)
    need(released==b['physical_predecessor']==b['released_record_predecessor'], 'latest heavy seven fields are released image only')
    decoder.latest_native(b)
    historical=checked(b['historical_native_ancestry_bindings'])
    need(historical['physical_review']!=b['external_latest_native_physical_review']!=b['physical_review'], 'distinct historical native, latest failed native, and heavy image roles')
    terminal_joins(checked(historical['physical_review']),historical)
    need(released['boot_id']==historical['physical_predecessor']['boot_id'] and released['filesystem_uuid']==historical['physical_predecessor']['filesystem_uuid'], 'same boot and scratch identity in distinct physical roles')
    need(all(not os.path.lexists(released[k]) for k in ('lease_path','common_exclusion','shared_heavy')), 'current released-image ownership names absent; future LAST repeats')
    need(b['root_lock_identity']==historical['root_lock_identity']==dict(device=27,inode=4,uid=0,gid=0,mode='0o644'), 'permanent mutex unchanged; live acquisition remains separate')

'''
snapshot=replace(snapshot,'def collect_live(b,proposal,owner):',addition+'def collect_live(b,proposal,owner):')
snapshot=replace(snapshot,'    terminal_joins(checked(terminal_ref),b)','    admission_joins(checked(terminal_ref),b)')
for name in ('successful_native_terminal_joins','failed_owner_join','terminal_joins'):assert func(snapshot,name)==func(before,name),name
save(O/'root_manual_snapshot_threads.py',snapshot)
binder=(O/'bind_numa_native_packet.py').read_text();binder=replace(binder,' snapshot.terminal_joins(load(P),roles)',' snapshot.admission_joins(load(P),roles)');binder=binder.replace('NATIVE_TERMINAL_ANCESTRY_ONLY_C9_RELEASED_BUILD_ANCESTRY',roles['legacy_reference_scope'])
binder=replace(binder,"b['source_pins']=c['runtime_source_refs']+[whole_ref,ref(D/'root_manual_snapshot_threads.py'),decoderref]","historical_roles=load(roles['historical_native_ancestry_bindings']['path'])\nb['source_pins']=c['runtime_source_refs']+[whole_ref,ref(D/'root_manual_snapshot_threads.py'),decoderref,roles['historical_native_ancestry_bindings'],historical_roles['released_record_projection_source']]")
binder=binder.replace('current native ownership records absent','current released-image ownership records absent').replace('Native87f/C9 retained ancestry only; separate latest external M05 physical requires genuine runtime preentry review plus fresh live snapshot','Latest source4 image-build heavy release; latest SIGILL failed-native f538 separately; native87f/C9 explicitly historical ancestry. Fresh runtime review and live snapshot remain mandatory')
save(O/'bind_numa_native_packet.py',binder)
c=load(O/'STATIC-NONTEMPORAL-INPUTS.json');c.update(latest_physical=ref(event),native_predecessor_binding=ref(O/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json'),physical_consumer_mapping=ref(O/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json'),current_heavy_released_record=released,external_latest_native_physical_review=roles['external_latest_native_physical_review'],legacy_reference_scope=roles['legacy_reference_scope']);save(O/'STATIC-NONTEMPORAL-INPUTS.json',c)
# Recompute complete selected source map from this materialization; never copy FD IDs.
paths={r['path'] for r in c['runtime_source_refs'] if r['path'].endswith('.py')}|{str(O/'root_manual_snapshot_threads.py'),str(O/'released_image_record.py'),load(ancestry)['released_record_projection_source']['path']}
fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns');identities={}
for path in sorted(paths):
 fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
 try:
  first=os.fstat(fd);last=os.fstat(fd);named=Path(path).lstat();assert all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in fields);identities[path]={k:getattr(first,k) for k in fields}
 finally:os.close(fd)
mapfile=O/'RUNTIME-SOURCE-FD-IDENTITIES.json';m=load(mapfile);m['identities']=identities;save(mapfile,m)
save(D/'AMENDMENT-RESULT.json',dict(status='SOURCE_DATA_AMENDMENT_ONLY',roles=ref(O/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json'),snapshot=ref(O/'root_manual_snapshot_threads.py'),binder=ref(O/'bind_numa_native_packet.py'),projector=ref(O/'released_image_record.py'),historical_native_guard_functions_unchanged=True,selected_runtime_python_paths=len(paths),latest_failed_native=roles['external_latest_native_physical_review'],latest_heavy_released_image=ref(event),runtime_release=None,snapshot_actual=None,guest_runs=0))
print(json.dumps(dict(status='PREPARED_RELEASED_IMAGE_AND_LATEST_FAILED_NATIVE_CONSUMER_AMENDMENT',selected_runtime_python_paths=len(paths))))
