"""Changed source4/latest-native boundary only; no privileged effects.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,runpy,socket,subprocess,sys,traceback
D=Path(__file__).resolve().parent;B=D/'bound-runtime-source-expert-correction-1';source=B/'root_manual_snapshot_threads.py'
def ref(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def forbidden(*a,**k):raise AssertionError('no process/socket/exec during in-process snapshot CLI test')
subprocess.Popen=forbidden;subprocess.run=forbidden;socket.socket=forbidden;os.execve=forbidden
pending={str(p).removesuffix('.PENDING-STATIC-CORRECTED'):p.read_bytes() for p in B.rglob('*.PENDING-STATIC-CORRECTED')}
bpath=str(B/'fresh-snapshot-bindings.json');braw=pending[bpath];bindings=json.loads(braw)
reports=[]
def run_main(kind):
 b=copy.deepcopy(bindings)
 if kind=='changed_native_authority':b['external_latest_native_physical_review']['sha256']='0'*64
 if kind=='changed_native_archive':b['latest_native_archive']['sha256']='0'*64
 if kind=='build_native_role_confusion':b['current_heavy_released_record']['role']='NATIVE_OWNER_RETIREMENT'
 if kind=='changed_build_projection':b['physical_predecessor']['container_id']='0'*64
 if kind=='latest_native_replaced_by_history':b['external_latest_native_physical_review']=b['historical_native_ancestry_bindings']
 entry=next(i for i,line in enumerate(source.read_text().splitlines(),1) if line=="if __name__=='__main__':raise SystemExit(main())")
 edges=[];calls=[];published=[]
 def install(g):
  real=g['checked']
  def checked(row):
   if row==dict(path=None,sha256=None,bytes=None):edges.append('UNAVAILABLE_FINAL_STATIC_REVIEW');return {'MOCK_BOUNDARY_ONLY':True}
   if row['path'] in pending:
    raw=pending[row['path']];assert hashlib.sha256(raw).hexdigest()==row['sha256']
    if row['path']==bpath:return copy.deepcopy(b)
    return json.loads(raw)
   return real(row)
  def collect(*args):edges.append('ROOT_LIVE_EDGE');return dict(boot_id='MOCK_BOUNDARY_ONLY',capacity={},mem_available_bytes=0,included_usage_percent=0,released_paths_absent={},image_id='MOCK_BOUNDARY_ONLY',cgroup={})
  def validate(*args):edges.append('LIVE_VALIDATION_EDGE')
  def publish(result):edges.append('ROOT_PUBLICATION_EDGE');published.append(result);return dict(path='/MOCK_BOUNDARY_ONLY/no-output',sha256='0'*64,bytes=0)
  g.update(checked=checked,collect_live=collect,validate_live=validate,publish=publish)
 def trace(frame,event,arg):
  if frame.f_code.co_filename==str(source):
   if event=='line' and frame.f_lineno==entry:install(frame.f_globals)
   if event=='call':calls.append(frame.f_code.co_name)
  return trace
 argv=sys.argv;uid,euid=os.getuid,os.geteuid;oldtrace=sys.gettrace();code=None;exc=None
 sys.argv=[str(source),'--bindings-sha256',hashlib.sha256(braw).hexdigest(),'--terminal',b['physical_review']['path'],'--terminal-sha256',b['physical_review']['sha256']];os.getuid=lambda:0;os.geteuid=lambda:0
 try:
  sys.settrace(trace)
  try:runpy.run_path(str(source),run_name='__main__')
  except SystemExit as e:code=e.code
  except Exception as e:exc=e;failure=traceback.format_exc()
 finally:sys.settrace(oldtrace);os.getuid=uid;os.geteuid=euid;sys.argv=argv
 record=dict(case=kind,code=code,exception=None if exc is None else str(exc),exception_type=None if exc is None else type(exc).__name__,publication_calls=len(published),admission_calls=calls.count('admission_joins'),historical_native_terminal_calls=calls.count('terminal_joins'),static_joins_calls=calls.count('static_joins'),normalization_calls=calls.count('accepted_current_normalization'),stage_calls=calls.count('accepted_current_stage'),mocked_edges=sorted(set(edges)),actual_effects=0)
 if exc:record['traceback']=failure
 reports.append(record)
 if kind=='positive':assert code==0 and exc is None and len(published)==1 and record['admission_calls']==record['historical_native_terminal_calls']==record['normalization_calls']==record['stage_calls']==1
 else:assert exc is not None and len(published)==0 and 'ROOT_LIVE_EDGE' not in edges
for kind in ('positive','changed_native_authority','changed_native_archive','build_native_role_confusion','changed_build_projection','latest_native_replaced_by_history'):run_main(kind)
# Current exact final-guard source-map decoder, with pending bindings supplied as
# explicit DATA only. Source hashes/full nine-field identities remain real.
path=B/'native-packet-1/review_final_threads_release.py';spec=importlib.util.spec_from_file_location('exact_guard',path);guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
cfg=json.loads(pending[str(B/'native-packet-1/FINAL-IHK-LOGGING-CHECK-CONFIG.json')]);read=guard.read

def pending_read(path,sha):
 if path in pending:
  raw=pending[path];assert hashlib.sha256(raw).hexdigest()==sha;return json.loads(raw),dict(path=path,sha256=sha,bytes=len(raw)),None
 return read(path,sha)
guard.read=pending_read
source_rows=guard.check_runtime_sources(cfg);selected={r['path'] for r in cfg['runtime_source_refs'] if r['path'].endswith('.py')};assert len(selected)==13
packet=json.loads(pending[str(B/'native-packet-1/NATIVE-COHERENT-REVIEW-PACKET.json')]);assert packet['static_decision']==dict(path=None,sha256=None,bytes=None) and packet['native_runtime_authority'] is False and packet['actual_guest_runs']==0
result=dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',status='PASS_ACTUAL_SNAPSHOT_MAIN_CHANGED_BOUNDARY_POSITIVE_AND_FIVE_ROLE_REFUSALS',cases=reports,actual_binder_cli=ref(D/'actual-binder-cli.result.json'),actual_projector_cli=ref(D/'actual-projector-cli.result.json'),final_guard_runtime_source_rows=source_rows,selected_runtime_python_paths=len(selected),static_review=None,snapshot=None,runtime_release=None,guest_runs=0,root_operations=0)
(D/'changed-consumer-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],cases=len(reports),selected_runtime_python_paths=len(selected),root_operations=0,guest_runs=0)))
