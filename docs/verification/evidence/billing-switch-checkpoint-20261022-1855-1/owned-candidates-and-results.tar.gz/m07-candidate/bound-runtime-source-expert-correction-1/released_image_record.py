"""Exact accepted source4 IMAGE-build release; latest failed native stays separate.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure retained-evidence consumer. No root, process census, build or runtime authority.
"""
from pathlib import Path
import argparse,hashlib,io,json,os,re,stat,tarfile
D=Path(__file__).resolve().parent
EVENT_SHA='7748c268b53229ae21c04eecf97c6546fa8aceaaa34aabc51fbdcb1231c61fd8'
NATIVE_SHA='f5386f83823b9e3c5c4a56908d62e9a9305b667722349eaa1a877e89358721de'
FIELDS=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
class Refusal(RuntimeError):pass
def need(ok,message):
    if not ok:raise Refusal(message)
def checked_bytes(row):
    p=Path(row['path']);need(p.is_absolute() and p.resolve(strict=True)==p,'canonical whole retained descriptor')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_size<=4*1024**2,'bounded retained regular file')
        raw=b''
        while True:
            part=os.read(fd,1<<20)
            if not part:break
            raw+=part;need(len(raw)<=4*1024**2,'bounded retained read')
        last=os.fstat(fd);named=p.lstat()
        need(all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in FIELDS),'stable retained descriptor')
        need(len(raw)==row.get('bytes',row.get('size')) and hashlib.sha256(raw).hexdigest()==row['sha256'],'exact retained descriptor hash/bytes')
        return raw
    finally:os.close(fd)
def checked(row):return json.loads(checked_bytes(row))
def captured(status):
    need(status['status']=='PASS' and status['returncode']==0 and all(status[k] is True for k in ('direct_child_joined','process_group_absent','streams_closed','cpu7_released')),'positive closed source4 capture')
    checked_bytes(status['stdout']);checked_bytes(status['stderr'])
def project(t,physical_ref,binding):
    need(binding['role']=='RELEASED_IMAGE_BUILD_RECORDS_ONLY' and binding['runtime_release'] is None,'explicit released-build role; no runtime release')
    need(physical_ref==binding['physical_acceptance'] and physical_ref['sha256']==EVENT_SHA and t==checked(physical_ref),'exact independent source4 image physical decision')
    event=t['event'];item=event['params']['item'];text=item['text']
    need(event['method']=='item/completed' and item['type']=='agentMessage' and '**PASS_ACTUAL_CURRENT_IMAGE_CONTAINER_AND_RECORD_RETIREMENT_ONLY**' in text and 'Reviewer: `/root/cleanup_execution_review_resumed`; `implementation_ownership: false`' in text,'genuine independent released-image decision')
    need('not native-owner retirement' not in text or 'released-image-build' in text,'released image scope')
    matches=re.findall(r'```json\s*(\{.*?\})\s*```',text,re.S);need(len(matches)==1,'one reviewed seven-field image projection')
    projection=json.loads(matches[0]);keys={'boot_id','filesystem_uuid','container_id','owner_nonce','lease_path','common_exclusion','shared_heavy'}
    need(set(projection)==keys and projection==binding['projection'],'exact accepted released-image seven fields')
    engine=checked(binding['actual_cleanup_result']);cleanup=checked(binding['actual_cleanup_status']);post=checked(binding['actual_postjoin_status']);auth=checked(binding['postjoin_archive_authentication'])
    captured(cleanup);captured(post)
    need(checked_bytes(cleanup['stderr'])==b'' and checked_bytes(cleanup['stdout'])==checked_bytes(binding['actual_cleanup_result']),'exact actual cleanup stdout and empty stderr')
    need(engine['schema']=='fp-save-image.cleanup-result.v1' and engine['status']=='PASS_EXECUTED' and engine['terminal'] is True and engine['container_absent'] is True,'positive actual released-image cleanup')
    release=checked(binding['cleanup_release']);obs=release['observation'];target=obs['target']
    need(engine['boot_id']==projection['boot_id'] and engine['filesystem_uuid']==projection['filesystem_uuid'] and engine['container_id']==projection['container_id']==target['container_id'] and target['owner_nonce']==projection['owner_nonce'],'actual cleanup projection identity')
    need(obs['request']['path'] and projection['common_exclusion']==str(Path(projection['lease_path']).parent/'common-exclusion.json') and projection['shared_heavy']=='/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock','exact released record path roles')
    need(post['stdout']['path']==auth['archive'] and post['stdout']['sha256']==auth['archive_sha256'] and binding['actual_postjoin_status']['sha256']==auth['postjoin_status_sha256'] and post['stderr']['sha256']==auth['postjoin_stderr_sha256'],'actual postjoin channel authorities')
    expected=[engine[k] for k in ('plan','journal','capture')]+engine['archives'];need(len(expected)==5 and len(auth['members'])==5,'actual exact five-member archive')
    raw=checked_bytes(post['stdout'])
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        members=archive.getmembers();need(len(members)==5 and len({m.name for m in members})==5,'five unique retained members')
        for member,row,reviewed in zip(members,expected,auth['members']):
            need(member.isreg() and member.name==Path(row['path']).name==reviewed['name'] and member.size==row['size']==reviewed['bytes'],'exact retained member geometry')
            payload=archive.extractfile(member).read((4<<20)+1)
            need(hashlib.sha256(payload).hexdigest()==row['sha256']==reviewed['sha256'],'exact retained member bytes')
    need(binding['native_acceptance'] is False and binding['application_acceptance'] is False,'image retirement grants no native or app acceptance')
    return projection

def latest_native(binding):
    row=binding['external_latest_native_physical_review'];need(row['sha256']==NATIVE_SHA,'exact latest failed native decision')
    a=checked(row)
    need(a['status']=='PASS_CURRENT_FAILED_OWNER_RETIREMENT_ONLY' and a['decision']=='ACCEPT_CURRENT_FAILED_OWNER_RETIREMENT_ONLY' and a['reviewer']=='/root/m07_outer_control_closure_expert' and a['implementation_ownership'] is False and a['missing_retirement_observations']==[],'genuine latest failed-native retirement only')
    for key in ('success_readbacks_executed','runtime_permission','native_acceptance','application_acceptance','kernel_cause_acceptance','continuing_global_clearance'):
        need(a[key] is False,'preserve unaccepted latest-native fact '+key)
    raw=checked_bytes(binding['latest_native_archive']);need(hashlib.sha256(raw).hexdigest()==a['archive_sha256'],'actual latest native archive authority')
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        members=archive.getmembers();need(len({m.name for m in members})==len(members),'unique latest native archive members')
        def member(name,sha):
            m=archive.getmember('./'+name);need(m.isreg() and m.size<=4*1024**2,'regular latest native member');payload=archive.extractfile(m).read((4<<20)+1);need(hashlib.sha256(payload).hexdigest()==sha,'latest native accepted member');return json.loads(payload)
        receipt=member('result.json',a['atomic_receipt_sha256']);owner=member('owner.json',a['owner_record_sha256'])
    need(receipt['status']=='FAIL' and receipt['failure']=='OwnerError' and receipt['absence_verified'] is True and receipt['lease_retained'] is False and receipt['secondary']==[] and receipt['secondary_omitted']==0 and receipt['signal_number'] is None and receipt['container']==a['container'],'latest actual failed-native atomic ownership')
    need(owner['nonce']==a['nonce'] and owner['outer']['pid']==a['owner_pid'] and owner['outer']['proc_starttime']==a['owner_start'] and owner['outer']['pgid']==owner['outer']['sid']==a['native_owner_caller_pid'],'latest native producer identity')
    need(owner['lock']==dict(dev=27,ino=4,uid=0,gid=0,mode=420,nlink=1) and a['lock_device_inode']==[27,4],'permanent native mutex identity retained')
    return a

def main(argv=None):
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--binding',required=True);p.add_argument('--binding-sha256',required=True);a=p.parse_args(argv)
    path=Path(a.binding);b=checked(dict(path=str(path),sha256=a.binding_sha256,bytes=path.stat().st_size));r=b['current_heavy_released_record'];projection=project(checked(r['physical_acceptance']),r['physical_acceptance'],r);native=latest_native(b)
    print(json.dumps(dict(status='PASS_RELEASED_IMAGE_BUILD_AND_DISTINCT_LATEST_FAILED_NATIVE_ONLY',projection=projection,latest_native_container=native['container'],runtime_release=None,snapshot=None,guest_runs=0),sort_keys=True));return 0
if __name__=='__main__':raise SystemExit(main())
