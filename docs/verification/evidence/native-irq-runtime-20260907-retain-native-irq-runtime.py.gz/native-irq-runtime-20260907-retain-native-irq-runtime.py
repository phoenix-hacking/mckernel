from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-irq-runtime-retained-20260907-1')
out.mkdir()
record = dict(created_utc=datetime.now(timezone.utc).isoformat(), artifacts=[], production_gate_credit=False,
              mckernel_boot_proven=False,
              passed=['IRQ guest 3 with idle=poll and guest 4 with original idle settings: 1024 callbacks and two unloads each',
                      'native image guest 3: 56 image readbacks, 56 startup-table readbacks, 64 forced startup allocation failures; both ABIs and two cycles',
                      'PCP parser node/zone scoping, partial reads and malformed input cases'],
              open=['IRQ guest 2 had an intermittent default-idle timer/RCU stall; later passes do not establish its cause or resolve acceptance',
                    'native image guests 1 and 2 failed a buddy-only free-memory assertion; guest 3 measured 4096 KiB buddy loss and 4088 KiB growth in free PCP pages',
                    'updated cleanup assertion includes free PCP pages without increasing its 4096 KiB allowance; final guest replay and full suite pending',
                    'actual McKernel boot, cross-kernel IRQ/IKC, workloads and full Rust/assembly completion'])
def add(path, name):
    data = path.read_bytes()
    target = out / name
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream: stream.write(data)
    assert gzip.decompress(target.read_bytes()) == data
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name, source=str(path),
        size=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
        unpacked_size=len(data), unpacked_sha256=hashlib.sha256(data).hexdigest()))
for name in ['native-irq-work-guest-20260907-2', 'native-irq-work-guest-20260907-3', 'native-irq-work-guest-20260907-4',
             'native-irq-image-load-guest-20260907-1', 'native-irq-image-load-guest-20260907-2', 'native-irq-image-load-guest-20260907-3',
             'native-irq-final-validation-20260907-1', 'native-irq-remaining-validation-20260907-1']:
    path = Path('/work') / name
    target = out / (name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive: archive.add(path, arcname=name)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name, source=str(path),
        size=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    metadata = path / ('local-run.json' if 'image-load' in name else 'record.json')
    add(metadata, name + '-' + metadata.name + '.gz')
    if (path / 'serial.log').exists(): add(path / 'serial.log', name + '-serial.log.gz')
for name in ['run-native-irq-work-timer-guest.py', 'run-native-irq-image-load-guest.py', 'run-native-irq-full-tests.py',
             'inventory-rust-consumers-irq-20260907.py', 'run-native-irq-final-validation.py',
             'run-native-irq-remaining-validation.py', 'retain-native-irq-runtime.py']:
    add(Path('/work') / name, 'native-irq-runtime-20260907-' + name + '.gz')
for relative in ['scripts/tests/fixtures/native-image-load.c', 'scripts/tests/test_native_image_memory_accounting.py']:
    path = Path('/workspace') / relative
    add(path, 'native-irq-runtime-20260907-current-' + path.name + '.gz')
    record.setdefault('current_probe_inputs', []).append(dict(path=relative, size=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out / 'native-irq-runtime-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained', len(record['artifacts']), 'artifacts in', out, flush=True)
