from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace')
attempt=sys.argv[1]
mode='native-trampoline-extraction-and-assembly'
out=Path('/work/native-trampoline-region-module-20260907-'+attempt)
source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build=Path('/work/native-build-base-24a151fe')
kernel=Path('/work/native-irq-transport-exact-stage-20260907-1')
prior=Path('/work/native-startup-exact-stage-20260907-1')
assert json.loads((kernel/'record.json').read_text())['status']=='PASS'
assert (build/'.config').read_bytes()==(kernel/'resolved.config').read_bytes()
assert (build/'Module.symvers').read_bytes()==(kernel/'Module.symvers').read_bytes()
out.mkdir()
def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),mode=mode,inputs=[],production_gate_credit=False,mckernel_boot_proven=False)
for relative in ['scripts/tests/fixtures/mckernel_trampoline_region_verify.rs','scripts/tests/fixtures/mckernel_trampoline_region_layout.c','host-kernel/native-rust/smp_trampoline.rs','host-kernel/native-rust/smp_boot_code.rs','host-kernel/native-rust/smp_trampoline.S','host-kernel/native-rust/smp_startup_entry.S','ihk/linux/driver/smp/arch/x86_64/smp-x86_64-trampoline.S','ihk/linux/driver/smp/arch/x86_64/smp-x86_64-startup.S']:
    path=out/'source'/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/relative,path)
    record['inputs'].append(identity(path))
for path in [build/'.config',build/'Module.symvers',build/'rust/bindings/bindings_generated.rs',source/'include/linux/ioport.h',source/'arch/x86/include/asm/e820/api.h',source/'arch/x86/include/asm/e820/types.h',source/'arch/x86/kernel/e820.c',source/'kernel/resource.c',source/'arch/x86/mm/ioremap.c',source/'arch/x86/realmode/init.c']:
    record['inputs'].append(identity(path))
    shutil.copyfile(path,out/path.name.lstrip('.'))
shutil.copyfile(__file__,out/'build-helper.py')
module=out/'source/scripts/tests/fixtures'
for original, name in [('smp-x86_64-trampoline.S','smp_original_trampoline.S'),('smp-x86_64-startup.S','smp_original_startup.S')]:
    shutil.copyfile(out/'source/ihk/linux/driver/smp/arch/x86_64'/original,module/name)
(module/'Kbuild').write_text("obj-m += mckernel_trampoline_region_verify.o\n")
base=shlex.split((prior/'module-build.command').read_text())[:-3]+['M='+str(module)]
commands=[['rustfmt','--edition','2021',str(module/'mckernel_trampoline_region_verify.rs')],['bash','-n',str(repo/'scripts/native-trampoline-region-init.sh')],base+['mckernel_trampoline_region_layout.o'],base+['smp_original_trampoline.o'],base+['smp_original_startup.o'],base+['modules']]
record['commands']=commands
try:
    with (out/'module-build.log').open('wb') as log:
        for command in commands:
            print('RUN',shlex.join(command),flush=True)
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    record['assembly_equivalence']=[]
    for name,section in [('trampoline','.rodata'),('startup','.text')]:
        original=module/('smp_original_'+name+'.o')
        reference=out/('original-'+name+'.bin')
        native=out/('native-'+name+'.bin')
        subprocess.run(['objcopy','--dump-section',section+'='+str(reference),str(original)],check=True)
        subprocess.run(['objcopy','--dump-section','.rodata.mckernel_smp_'+name+'='+str(native),str(module/'mckernel_trampoline_region_verify.o')],check=True)
        assert native.read_bytes()==reference.read_bytes(),(name,identity(native),identity(reference))
        shutil.copyfile(original,out/original.name)
        record['assembly_equivalence'].append(dict(body=name,native=identity(native),original=identity(reference),equal=True))
    linked=module/'mckernel_trampoline_region_verify.ko'
    raw=linked.read_bytes()
    shoff=struct.unpack_from('<Q',raw,40)[0]
    shsize,shcount,shstr=struct.unpack_from('<HHH',raw,58)
    headers=[struct.unpack_from('<IIQQQQIIQQ',raw,shoff+i*shsize) for i in range(shcount)]
    names=raw[headers[shstr][4]:headers[shstr][4]+headers[shstr][5]]
    sections={names[h[0]:].split(bytes([0]),1)[0].decode():h for h in headers}
    rodata=sections['.rodata']
    syms={line.split()[0]:int(line.split()[2],16) for line in subprocess.check_output(['nm','-P',str(linked)],text=True).splitlines() if len(line.split())>=3 and line.split()[1] in ('r','R')}
    for row in record['assembly_equivalence']:
        name=row['body']
        first=syms['mckernel_smp_'+name+'_data']-rodata[3]
        last=syms['mckernel_smp_'+name+'_end']-rodata[3]
        assert 0<=first<last<=rodata[5]
        emitted=raw[rodata[4]+first:rodata[4]+last]
        assert emitted==(out/('original-'+name+'.bin')).read_bytes(),name
        (out/('linked-'+name+'.bin')).write_bytes(emitted)
        row['linked']=identity(out/('linked-'+name+'.bin'))
    for section,name,count,expected in [('.mckernel_trampoline_region_layout','layout',6,[8,1,4,4,134217728,1])]:
        subprocess.run(['objcopy','--dump-section',section+'='+str(out/(name+'.bin')),str(module/'mckernel_trampoline_region_layout.o')],check=True)
        actual=list(struct.unpack('<'+str(count)+'Q',(out/(name+'.bin')).read_bytes()))
        assert actual==expected,(name,actual)
        record[name]=actual
    for name in ['mckernel_trampoline_region_verify.ko','mckernel_trampoline_region_layout.o']:
        shutil.copyfile(module/name,out/name)
    for command,name in [(['readelf','-h',str(out/'mckernel_trampoline_region_verify.ko')],'module-elf-header.txt'),
                         (['nm','-u',str(out/'mckernel_trampoline_region_verify.ko')],'module-undefined.txt'),
                         (['objdump','-d',str(out/'mckernel_trampoline_region_verify.ko')],'module-disassembly.txt')]:
        (out/name).write_bytes(subprocess.check_output(command))
    imports=(out/'module-undefined.txt').read_text()
    for symbol in ['e820__mapped_raw_any','e820__mapped_any','__request_region','__release_region','iomem_resource','ioremap_cache','iounmap']:
        assert ' U '+symbol+'\n' in imports,symbol
    elf=(out/'module-elf-header.txt').read_text()
    assert 'ELF64' in elf and 'Advanced Micro Devices X86-64' in elf
    assembly=(out/'module-disassembly.txt').read_text()
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b',assembly), 'SIMD/x87 register in fixture module'
    record['outputs']=[identity(out/name) for name in ['mckernel_trampoline_region_verify.ko','mckernel_trampoline_region_layout.o','layout.bin','module-elf-header.txt','module-undefined.txt','module-disassembly.txt']]
    for item in record['inputs']:
        if item['path'].endswith('.rs') and Path(item['path']).is_relative_to(out/'source'):
            item.update(identity(Path(item['path'])))
        else: assert identity(Path(item['path']))==item
    record['outputs'] += [identity(out/name) for name in ['original-trampoline.bin','native-trampoline.bin','original-startup.bin','native-startup.bin','smp_original_trampoline.o','smp_original_startup.o','linked-trampoline.bin','linked-startup.bin']]
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record.get('status','FAIL'),out,flush=True)
    if record.get('status')!='PASS': print((out/'module-build.log').read_text()[-12000:],flush=True)
