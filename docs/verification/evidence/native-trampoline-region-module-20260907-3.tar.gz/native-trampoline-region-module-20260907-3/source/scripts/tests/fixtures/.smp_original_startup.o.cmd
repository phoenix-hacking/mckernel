savedcmd_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o := clang -Wp,-MMD,/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/.smp_original_startup.o.d -nostdinc -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include -I./arch/x86/include/generated -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include -I./include -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi -I./include/generated/uapi -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h -D__KERNEL__ --target=x86_64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -Werror=option-ignored -Werror=unused-command-line-argument -fmacro-prefix-map=/work/native-source/linux-6.12.0-211.44.1.el10_2/= -D__ASSEMBLY__ -fno-PIE -m64 -DCC_USING_NOP_MCOUNT -DCC_USING_FENTRY -g    -DKBUILD_MODFILE='"/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup"' -DKBUILD_MODNAME='"smp_original_startup"' -D__KBUILD_MODNAME=smp_original_startup -c -o /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.S 

source_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o := /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.S

deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o := \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \

/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o: $(deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o)

$(deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_startup.o):
