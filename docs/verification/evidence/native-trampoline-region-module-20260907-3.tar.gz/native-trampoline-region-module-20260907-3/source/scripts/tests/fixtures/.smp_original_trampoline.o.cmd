savedcmd_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o := clang -Wp,-MMD,/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/.smp_original_trampoline.o.d -nostdinc -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include -I./arch/x86/include/generated -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include -I./include -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi -I./include/generated/uapi -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h -D__KERNEL__ --target=x86_64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -Werror=option-ignored -Werror=unused-command-line-argument -fmacro-prefix-map=/work/native-source/linux-6.12.0-211.44.1.el10_2/= -D__ASSEMBLY__ -fno-PIE -m64 -DCC_USING_NOP_MCOUNT -DCC_USING_FENTRY -g    -DKBUILD_MODFILE='"/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline"' -DKBUILD_MODNAME='"smp_original_trampoline"' -D__KBUILD_MODNAME=smp_original_trampoline -c -o /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.S 

source_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o := /work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.S

deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o := \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/linkage.h \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_SIGNED_WRAP) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/stringify.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/64BIT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  arch/x86/include/generated/asm/rwonce.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/rwonce.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/X86_32) \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/int-ll64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/int-ll64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/build_bug.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PROC_FS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/DYNAMIC_MEMORY_LAYOUT) \
    $(wildcard include/config/X86_5LEVEL) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
    $(wildcard include/config/KMSAN) \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/SPARSEMEM) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/msr.h \
    $(wildcard include/config/TRACEPOINTS) \
    $(wildcard include/config/PARAVIRT_XXL) \
    $(wildcard include/config/SMP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/msr-index.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/NOINSTR_VALIDATION) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/objtool_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/annotate.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/extable_fixup_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/MITIGATION_PAGE_TABLE_ISOLATION) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/processor-flags.h \

/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o: $(deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o)

$(deps_/work/native-trampoline-region-module-20260907-3/source/scripts/tests/fixtures/smp_original_trampoline.o):
