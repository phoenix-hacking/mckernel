#!/usr/bin/env python3
import hashlib
import json
from pathlib import PurePosixPath
import tarfile

archive_path = '/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.tar.gz'
inventory_path = '/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.inventory.json'

external = open(inventory_path, 'rb').read()
inventory = json.loads(external)
expected = {row['archive_path']: row for row in inventory['entries']}
if len(expected) != len(inventory['entries']):
    raise SystemExit('duplicate inventory archive path')

seen = set()
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    for member in members:
        path = PurePosixPath(member.name)
        if path.is_absolute() or '..' in path.parts or member.name in seen:
            raise SystemExit('unsafe or duplicate archive member: ' + member.name)
        seen.add(member.name)
        if member.name == 'retention/inventory.json':
            if archive.extractfile(member).read() != external:
                raise SystemExit('internal inventory differs')
            continue
        row = expected.get(member.name)
        if row is None:
            raise SystemExit('unexpected archive member: ' + member.name)
        if member.mode != int(row['mode'], 8) or member.uid != row['uid'] or member.gid != row['gid']:
            raise SystemExit('metadata differs: ' + member.name)
        if row['type'] == 'regular':
            if not member.isfile() or member.size != row['size']:
                raise SystemExit('regular metadata differs: ' + member.name)
            got = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
            if got != row['sha256']:
                raise SystemExit('regular digest differs: ' + member.name)
        elif row['type'] == 'directory':
            if not member.isdir():
                raise SystemExit('directory type differs: ' + member.name)
        elif row['type'] == 'symlink':
            if not member.issym() or member.linkname != row['link_target']:
                raise SystemExit('symlink differs: ' + member.name)
        else:
            raise SystemExit('unsupported inventory type')

missing = set(expected) - seen
if missing:
    raise SystemExit('missing members: ' + repr(sorted(missing)[:5]))
print('capsule verification PASS entries=%d archive_members=%d' % (len(expected), len(seen)))
