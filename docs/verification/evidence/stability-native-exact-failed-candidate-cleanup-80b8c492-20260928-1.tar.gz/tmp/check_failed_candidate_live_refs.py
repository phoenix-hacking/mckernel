#!/usr/bin/env python3
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat

targets = [
    Path('/dev/shm/mckernel-exact-candidate-80b8c492-1'),
    Path('/dev/shm/mckernel-exact-metadata-backup-80b8c492-1'),
]

def mount_unescape(value):
    return re.sub(r'\\([0-7]{3})', lambda match: chr(int(match.group(1), 8)), value)

def mount_rows(pid):
    result = []
    text = Path('/proc/%d/mountinfo' % pid).read_text(encoding='utf-8', errors='strict')
    for line in text.splitlines():
        left, separator, right = line.partition(' - ')
        fields = left.split()
        if not separator or len(fields) < 6:
            raise RuntimeError('malformed mountinfo for pid %d' % pid)
        result.append({'device': fields[2], 'root': mount_unescape(fields[3]),
                       'mountpoint': mount_unescape(fields[4]),
                       'filesystem': right.split()[0] if right else ''})
    return result

def filesystem_coordinate(target, rows):
    target_text = str(target)
    info = target.lstat()
    device = '%d:%d' % (os.major(info.st_dev), os.minor(info.st_dev))
    candidates = []
    for row in rows:
        mountpoint = row['mountpoint'].rstrip('/') or '/'
        if row['device'] == device and (target_text == mountpoint or
                target_text.startswith(mountpoint.rstrip('/') + '/')):
            candidates.append(row)
    if not candidates:
        raise RuntimeError('cannot map target to filesystem coordinate: ' + target_text)
    row = max(candidates, key=lambda item: len(item['mountpoint']))
    relative = os.path.relpath(target_text, row['mountpoint'])
    root = PurePosixPath(row['root'])
    coordinate = root if relative == '.' else root.joinpath(*Path(relative).parts)
    return device, '/' + str(coordinate).lstrip('/')

def collect_target_inodes(target):
    result = set()
    stack = [target]
    while stack:
        path = stack.pop()
        info = path.lstat()
        if not stat.S_ISLNK(info.st_mode):
            result.add((info.st_dev, info.st_ino))
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as stream:
                stack.extend(Path(entry.path) for entry in stream)
    return result

self_mounts = mount_rows(os.getpid())
coordinates = []
all_target_inodes = set()
roots = []
for target in targets:
    info = target.lstat()
    device, coordinate = filesystem_coordinate(target, self_mounts)
    coordinates.append((device, coordinate))
    inodes = collect_target_inodes(target)
    all_target_inodes.update(inodes)
    roots.append({'path': str(target), 'device_number': info.st_dev,
                  'device_coordinate': device, 'filesystem_root': coordinate,
                  'inode': info.st_ino, 'mode': format(stat.S_IMODE(info.st_mode), '04o'),
                  'tree_inode_count': len(inodes)})

def identity_match(path):
    info = os.stat(path)
    return (info.st_dev, info.st_ino) in all_target_inodes

references = []
permission_denials = []
transient_absences = []
processes = 0
mount_namespaces = {}

for entry in sorted(Path('/proc').iterdir(), key=lambda item: int(item.name) if item.name.isdigit() else -1):
    if not entry.name.isdigit():
        continue
    pid = int(entry.name)
    try:
        os.stat(entry)
    except FileNotFoundError:
        transient_absences.append([pid, 'proc-entry'])
        continue
    processes += 1
    try:
        namespace = os.readlink(entry / 'ns/mnt')
        mount_namespaces.setdefault(namespace, pid)
    except FileNotFoundError:
        transient_absences.append([pid, 'ns/mnt'])
    except PermissionError:
        permission_denials.append([pid, 'ns/mnt'])

    for field in ('cwd', 'root', 'exe'):
        probe = entry / field
        try:
            if identity_match(probe):
                references.append([pid, field, os.readlink(probe)])
        except FileNotFoundError:
            transient_absences.append([pid, field])
        except PermissionError:
            permission_denials.append([pid, field])

    for directory in ('fd', 'map_files'):
        probe_dir = entry / directory
        try:
            children = list(probe_dir.iterdir())
        except FileNotFoundError:
            transient_absences.append([pid, directory])
            continue
        except PermissionError:
            permission_denials.append([pid, directory])
            continue
        for probe in children:
            try:
                if identity_match(probe):
                    references.append([pid, directory + '/' + probe.name, os.readlink(probe)])
            except FileNotFoundError:
                transient_absences.append([pid, directory + '/' + probe.name])
            except PermissionError:
                permission_denials.append([pid, directory + '/' + probe.name])

    try:
        rows = mount_rows(pid)
    except FileNotFoundError:
        transient_absences.append([pid, 'mountinfo'])
        continue
    except PermissionError:
        permission_denials.append([pid, 'mountinfo'])
        continue
    for row in rows:
        for device, target_root in coordinates:
            root = row['root'].rstrip('/') or '/'
            prefix = target_root.rstrip('/') + '/'
            if row['device'] == device and (root == target_root or root.startswith(prefix)):
                references.append([pid, 'mount', row])

print(json.dumps({
    'schema': 'mckernel.read-only-live-reference-snapshot.v2',
    'roots': roots,
    'processes_scanned': processes,
    'mount_namespaces_scanned': len(mount_namespaces),
    'mount_namespace_representatives': sorted(mount_namespaces.values()),
    'permission_denials': permission_denials,
    'transient_absences': transient_absences,
    'target_references': references,
}, sort_keys=True))
