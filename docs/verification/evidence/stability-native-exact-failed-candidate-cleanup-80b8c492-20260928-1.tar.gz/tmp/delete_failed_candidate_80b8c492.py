#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

candidate = Path('/dev/shm/mckernel-exact-candidate-80b8c492-1')
backup = Path('/dev/shm/mckernel-exact-metadata-backup-80b8c492-1')
targets = [(candidate, 26, 3088), (backup, 26, 13660)]
lease = Path('/home/holden/mckernel-work/scratch/native-exact-build-lease-80b8c492-1.json')
snapshot_path = Path('/home/holden/mckernel-work/scratch/failed-candidate-live-reference-snapshot-80b8c492-20260928-4.json')
inventory_path = Path('/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.inventory.json')
capsule_path = Path('/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.tar.gz')

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def available(path):
    info = os.statvfs(path)
    return info.f_bavail * info.f_frsize

if lease.exists() or lease.is_symlink():
    raise SystemExit('lease reappeared')
for path, device, inode in targets:
    info = path.lstat()
    if (info.st_dev, info.st_ino, stat.S_IMODE(info.st_mode)) != (device, inode, 0o700):
        raise SystemExit('target identity drift: ' + str(path))

snapshot_bytes = snapshot_path.read_bytes()
snapshot = json.loads(snapshot_bytes)
if (snapshot.get('schema') != 'mckernel.read-only-live-reference-snapshot.v2' or
        snapshot.get('permission_denials') or snapshot.get('target_references')):
    raise SystemExit('live-reference snapshot does not release deletion')
observed_roots = {(row['path'], row['device_number'], row['inode']) for row in snapshot['roots']}
expected_roots = {(str(path), device, inode) for path, device, inode in targets}
if observed_roots != expected_roots:
    raise SystemExit('snapshot target identity differs')

if digest(capsule_path) != '4f634ee1694584b5ee7c2ca4f9cb61c7ee79e14566c1fee8c33da3d80a409691':
    raise SystemExit('capsule digest drift')
if digest(inventory_path) != '30577bf628f52cc4bbabd8cd9c1539162f58d84b30dc5bf28b887cf89e486b40':
    raise SystemExit('inventory digest drift')
inventory = json.loads(inventory_path.read_text(encoding='utf-8'))
for row in inventory['entries']:
    path = Path(row['source_path'])
    info = path.lstat()
    kind = ('regular' if stat.S_ISREG(info.st_mode) else
            'directory' if stat.S_ISDIR(info.st_mode) else
            'symlink' if stat.S_ISLNK(info.st_mode) else 'unsupported')
    if (kind != row['type'] or format(stat.S_IMODE(info.st_mode), '04o') != row['mode'] or
            info.st_uid != row['uid'] or info.st_gid != row['gid'] or
            info.st_size != row['size'] or info.st_mtime_ns != row['mtime_ns']):
        raise SystemExit('capsule live attribute drift: ' + str(path))
    if kind == 'regular' and digest(path) != row['sha256']:
        raise SystemExit('capsule live digest drift: ' + str(path))
    if kind == 'symlink' and os.readlink(path) != row['link_target']:
        raise SystemExit('capsule live link drift: ' + str(path))

env = os.environ.copy()
env['GIT_OPTIONAL_LOCKS'] = '0'
main_status = subprocess.run(
    ['git', '--no-optional-locks', '-C', str(candidate), 'status', '--porcelain=v1', '--untracked-files=all'],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, env=env).stdout.decode().splitlines()
ihk_status = subprocess.run(
    ['git', '--no-optional-locks', '-C', str(candidate / 'ihk'), 'status', '--porcelain=v1', '--untracked-files=all'],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, env=env).stdout.decode().splitlines()
expected_status = sorted([
    '?? scripts/__pycache__/native_rust_build_surface_audit.cpython-39.pyc',
    '?? scripts/__pycache__/rocky_kernel_rk006_patch_authority.cpython-39.pyc',
])
if sorted(main_status) != expected_status or ihk_status:
    raise SystemExit('candidate file set changed before deletion')

before = {'dev_shm': available('/dev/shm'), 'host': available('/home/holden/mckernel'),
          'scratch': available('/home/holden/mckernel-work/scratch')}
for path, unused_device, unused_inode in targets:
    shutil.rmtree(path)
for path, unused_device, unused_inode in targets:
    if path.exists() or path.is_symlink():
        raise SystemExit('target remains after deletion: ' + str(path))
after = {'dev_shm': available('/dev/shm'), 'host': available('/home/holden/mckernel'),
         'scratch': available('/home/holden/mckernel-work/scratch')}
if after['dev_shm'] < 4 * 1024 ** 3 or after['host'] < 16 * 1024 ** 3 or after['scratch'] < 12 * 1024 ** 3:
    raise SystemExit('post-delete free-space floor violated')
if digest(capsule_path) != '4f634ee1694584b5ee7c2ca4f9cb61c7ee79e14566c1fee8c33da3d80a409691':
    raise SystemExit('capsule changed after deletion')
if digest(inventory_path) != '30577bf628f52cc4bbabd8cd9c1539162f58d84b30dc5bf28b887cf89e486b40':
    raise SystemExit('inventory changed after deletion')

print(json.dumps({
    'schema': 'mckernel.failed-candidate-cleanup-result.v1',
    'status': 'PASS',
    'deleted': [str(candidate), str(backup)],
    'snapshot_sha256': hashlib.sha256(snapshot_bytes).hexdigest(),
    'before_available_bytes': before,
    'after_available_bytes': after,
    'dev_shm_recovered_bytes': after['dev_shm'] - before['dev_shm'],
    'capsule_sha256': digest(capsule_path),
    'inventory_sha256': digest(inventory_path),
    'terminal_containers_deleted': False,
}, sort_keys=True))
