#!/usr/bin/env python3
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

ROOTS = [
    (Path('/dev/shm/mckernel-exact-candidate-80b8c492-1/.git'), 'candidate/main.git'),
    (Path('/dev/shm/mckernel-exact-candidate-80b8c492-1/ihk/.git'), 'candidate/ihk.git'),
    (Path('/dev/shm/mckernel-exact-metadata-backup-80b8c492-1/main.git'), 'backup/main.git'),
    (Path('/dev/shm/mckernel-exact-metadata-backup-80b8c492-1/ihk.git'), 'backup/ihk.git'),
    (Path('/dev/shm/mckernel-exact-candidate-80b8c492-1/scripts/__pycache__/native_rust_build_surface_audit.cpython-39.pyc'), 'candidate/untracked/scripts/__pycache__/native_rust_build_surface_audit.cpython-39.pyc'),
    (Path('/dev/shm/mckernel-exact-candidate-80b8c492-1/scripts/__pycache__/rocky_kernel_rk006_patch_authority.cpython-39.pyc'), 'candidate/untracked/scripts/__pycache__/rocky_kernel_rk006_patch_authority.cpython-39.pyc'),
    (Path('/home/holden/mckernel-work/scratch/native-exact-metadata-evidence-80b8c492-1/receipt.json'), 'durable/metadata-receipt.json'),
    (Path('/home/holden/mckernel-work/scratch/native-exact-inputs-80b8c492-1.json'), 'durable/canonical-input-manifest.json'),
    (Path('/home/holden/mckernel-work/scratch/native-exact-build-request-80b8c492-1.json'), 'durable/build-request.json'),
    (Path('/home/holden/mckernel-work/scratch/candidate-placement-observer-80b8c492-1.py'), 'durable/candidate-placement-observer.py'),
    (Path('/home/holden/mckernel-work/scratch/source-git-closure-observer-80b8c492-1.py'), 'durable/source-git-closure-observer.py'),
]

OUT = Path('/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.tar.gz')
INV = Path('/home/holden/mckernel/docs/verification/evidence/stability-native-exact-failed-candidate-retention-capsule-80b8c492-20260928-1.inventory.json')

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def rows(source, archive):
    paths = [source]
    if source.is_dir():
        paths.extend(sorted(source.rglob('*'), key=lambda item: os.fsencode(str(item))))
    result = []
    for path in paths:
        info = path.lstat()
        relative = path.relative_to(source) if path != source else Path('.')
        name = archive if str(relative) == '.' else archive + '/' + relative.as_posix()
        kind = ('regular' if stat.S_ISREG(info.st_mode) else
                'directory' if stat.S_ISDIR(info.st_mode) else
                'symlink' if stat.S_ISLNK(info.st_mode) else 'unsupported')
        if kind == 'unsupported':
            raise RuntimeError('unsupported capsule entry: ' + str(path))
        row = {
            'archive_path': name,
            'source_path': str(path),
            'type': kind,
            'mode': format(stat.S_IMODE(info.st_mode), '04o'),
            'uid': info.st_uid,
            'gid': info.st_gid,
            'size': info.st_size,
            'mtime_ns': info.st_mtime_ns,
        }
        if kind == 'regular':
            row['sha256'] = digest(path)
        elif kind == 'symlink':
            row['link_target'] = os.readlink(path)
        result.append(row)
    return result

all_rows = []
for source, archive in ROOTS:
    if not source.exists() and not source.is_symlink():
        raise RuntimeError('missing capsule input: ' + str(source))
    all_rows.extend(rows(source, archive))

inventory = {
    'schema': 'mckernel.failed-candidate-retention-capsule.v1',
    'candidate_commit': '80b8c492be5fdaf227c5559f637a4473de6b7d0a',
    'ihk_commit': '3114d9e7101ad52030eb3effa849a5c108972a1f',
    'candidate_root_device': 26,
    'candidate_root_inode': 3088,
    'backup_root_device': 26,
    'backup_root_inode': 13660,
    'restoration': 'Restore tracked blobs from the exact commits with recorded 0600/0700 modes, then overlay these archive members at their mapped source paths. Historical replay requires a separate execution release.',
    'terminal_containers_retained': ['c6917efd...f9f0772', '110dfe01...799b0'],
    'entries': all_rows,
}
INV.write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n', encoding='utf-8')
os.chmod(INV, 0o644)

with OUT.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT, dereference=False) as archive:
            for source, name in ROOTS:
                archive.add(str(source), arcname=name, recursive=True)
            archive.add(str(INV), arcname='retention/inventory.json', recursive=False)
os.chmod(OUT, 0o644)

print(json.dumps({
    'archive': str(OUT),
    'archive_bytes': OUT.stat().st_size,
    'archive_sha256': digest(OUT),
    'inventory': str(INV),
    'inventory_bytes': INV.stat().st_size,
    'inventory_sha256': digest(INV),
    'entry_count': len(all_rows),
}, sort_keys=True))
