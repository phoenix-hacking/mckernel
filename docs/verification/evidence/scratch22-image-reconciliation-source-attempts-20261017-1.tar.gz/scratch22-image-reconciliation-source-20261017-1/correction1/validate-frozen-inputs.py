import importlib.util
from pathlib import Path
import json
import subprocess
p=Path('/home/holden/mckernel/scripts/native_exact_scratch22_image_retirement_reconcile.py')
spec=importlib.util.spec_from_file_location('frozen_input_validation',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.cleanup
row=c.observe_identity
request=c.parse(c.read_bounded(c.REQUEST))
receipt=c.parse(c.read_bounded(c.TERMINAL))
original=c.parse(c.read_bounded(m.ORIGINAL_RELEASE))
guard=Path(original['guard_capture'])
paths={c.EVIDENCE/'attempt/container.log',c.OUTPUT/'evidence/receipt.json',
       c.OUTPUT/'output/build/kernel/mckernel.img',c.OUTPUT/'evidence/artifacts/mckernel.img'}
for key in ('driver_path','provenance_path','host_owner_path','source_manifest','toolchain_manifest','gitlink_manifest'):
    if request.get(key) is not None: paths.add(Path(request[key]))
clients={guard/'docker.log',guard/'consumed-release.json'}
for directory in guard.glob('command-*'):
    clients.update(directory/name for name in ('status.json','stdout','stderr'))
mount=c.parse(subprocess.check_output(['/usr/bin/findmnt','-J','-T',str(m.ROOT),'-o','TARGET,SOURCE,FSTYPE,OPTIONS,UUID,MAJ:MIN'],timeout=10))['filesystems'][0]
obs=dict(mount=mount,root=row(m.ROOT),request=row(c.REQUEST),owner_receipt=row(c.TERMINAL),consumed_release=row(m.ORIGINAL_RELEASE),
         original_quarantine=row(m.ORIGINAL_QUARANTINE),retained_exclusions=[row(c.ATTEMPT),row(c.SHARED)],
         selected_files=[row(p) for p in sorted(paths)],candidate_root=row(Path(request['source_root'])),
         backup_root=row(Path(request['backup_root'])),
         inventories={str(p):c.metadata_inventory(p) for p in (c.OUTPUT,c.EVIDENCE)},
         container_inspect=receipt['terminal_container_info'],original_client_files=[row(p) for p in sorted(clients)])
out=Path('/home/holden/mckernel-work/scratch/scratch22-image-reconciliation-source-20261017-1/correction1/frozen-observation.json')
with out.open('xb') as f:f.write(m.core.canonical(obs))
m.validate_inputs(obs)
print('PASS ordinary-UID frozen selected bytes/identities/full metadata only; no Docker/root/build/guest')
