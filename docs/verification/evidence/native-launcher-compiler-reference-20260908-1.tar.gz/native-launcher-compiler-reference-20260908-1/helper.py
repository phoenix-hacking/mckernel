"""Capture actual Debug launcher compiler dependencies in their pinned environment."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
root=Path('/work/native-application-launcher-20260908-2')
out=Path('/work/native-launcher-compiler-reference-20260908-'+sys.argv[1])
out.mkdir()
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),bindings=[],application_execution=False)
def identity(path):
    raw=path.read_bytes()
    return dict(path=str(path),size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
try:
    shutil.copyfile(__file__,out/'helper.py')
    state=json.loads((root/'record.json').read_text())
    assert state['status']=='PASS'
    record['build_record']=identity(root/'record.json')
    for row in state['compiler_dependencies']:
        original=Path(row['path'])
        assert identity(original)==row,row
        relative=original.relative_to('/')
        target=out/'files'/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,target)
        saved=identity(target)
        assert (saved['size'],saved['sha256'])==(row['size'],row['sha256'])
        record['bindings'].append(dict(original=row,captured=saved))
    assert len(record['bindings'])==226
    for label in ('rust','fallback'):
        for row in state['launchers']:
            if row['selection']==label:
                for output in row['outputs']: assert identity(Path(output['path']))==output
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,len(record['bindings']),flush=True)
