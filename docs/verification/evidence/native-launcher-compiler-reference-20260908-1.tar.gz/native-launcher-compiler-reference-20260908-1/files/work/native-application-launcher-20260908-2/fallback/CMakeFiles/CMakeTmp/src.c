
	#include <zlib.h>
	int main()
	{
		Bytef dest[100];
		uLongf destlen = 100;
		Bytef *src = 0;
		uLong srclen = 3;
		int res = uncompress(dest,&destlen,src,srclen);
		if (res == Z_OK) {
			 /* ALL IS WELL */
		}
		return 0;
	}
