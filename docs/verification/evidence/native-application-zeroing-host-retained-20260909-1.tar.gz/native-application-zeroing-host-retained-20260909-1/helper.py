"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-zeroing-host-retained-20260909-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-zeroing-host-checkpoint-20260909.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Native allocator zeroing adapter, nine exact host tests, three modules, exact Rust noreturn objtool adaptation and 77 config/license checks; full original failures. Actual guest verification remains pending.',artifacts=[],captures=[],native_compiler_bindings=[],source_bindings=[],references=[],application_readiness_complete=False,actual_guest_pass=False,host_zeroing_integrated=True,full_capture_retention_pending=False)
captures=[('native-application-zeroing-host-protocol-20260909-1','FAIL'),('native-application-zeroing-host-protocol-20260909-2','PASS'),('native-application-zeroing-module-20260909-1','FAIL'),('native-application-zeroing-module-diagnosis-20260909-1','PASS'),('native-application-zeroing-objtool-review-20260909-1','PASS'),('native-application-zeroing-objtool-checks-20260909-1','PASS'),('native-application-zeroing-module-20260909-2','PASS'),('native-application-zeroing-patch-contract-20260909-1','FAIL'),('native-application-zeroing-patch-contract-20260909-2','PASS')]
try:
    shutil.copyfile(__file__,out/'helper.py')
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,(name,state['status'])
        for key in ('inputs','outputs','compiler_inputs','files','source_overlays'):
            for row in state.get(key,[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        if 'historical_evidence_omitted' in state:
            rows=json.loads((directory/'historical-evidence-restoration.json').read_text())
            listing=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rlz','--full-tree',state['source_parent'],'docs/verification/evidence'])
            expected_rows=[]
            for raw in listing.split(b'\0'):
                if not raw:continue
                meta,path=raw.split(b'\t',1);mode,kind,blob,size=meta.decode().split();assert kind=='blob'
                expected_rows.append(dict(path=os.fsdecode(path),mode=mode,git_blob=blob,size=int(size),source_commit=state['source_parent']))
            assert rows==expected_rows and len(rows)==state['historical_evidence_omitted']['count']
            for row in rows:assert not (directory/'source'/row['path']).exists()
            record['historical_evidence_restore']=dict(capture=name,source_commit=state['source_parent'],map='historical-evidence-restoration.json',count=len(rows),scope=state['historical_evidence_omitted']['scope'])
        record['captures'].append(dict(name=name,original_status=expected,record=identity(directory/'record.json')))
        artifact(directory,name+'.tar.gz',True)
    compiled=work/'native-application-zeroing-module-20260909-2'
    dependencies='\n'.join(path.read_text() for path in (compiled/'module-build').rglob('*.cmd'))
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert '/work/native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel/'+str(relative) in dependencies,str(relative)
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout);assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo));row.update(binding='exact pinned rustfmt replay',compiler_capture=str(saved),formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    assert len(record['native_compiler_bindings'])==57
    artifact(out/'format-replay','native-application-zeroing-host-20260909-format-replay.tar.gz',True)
    protocol=work/'native-application-zeroing-host-protocol-20260909-2'
    for relative in ['host-kernel/native-rust/sysfs_zeroing.rs','host-kernel/native-rust/sysfs_memory.rs','host-kernel/native-rust/smp_memory.rs','host-kernel/native-rust/smp_service.rs','host-kernel/native-rust/ihk_smp_x86_64.rs','scripts/tests/fixtures/native-application-zeroing-host.rs']:
        record['source_bindings'].append(binding(repo/relative,protocol/'source'/relative))
    contract=work/'native-application-zeroing-patch-contract-20260909-2'
    names=['scripts/rocky_kernel_config_resolution_v2.py','scripts/rocky_kernel_license_inventory.py','scripts/tests/test_rocky_kernel_config_resolution.py','scripts/tests/test_rocky_kernel_license_inventory.py','host-kernel/rocky/patches/0025-objtool-recognize-rust-1.92-vec-swap-remove-panic.patch']
    for relative in names:
        assert (contract/'original-inputs'/relative).read_bytes()==(contract/'source'/relative).read_bytes()
        record['source_bindings'].append(binding(repo/relative,contract/'source'/relative))
    assert 'Ran 77 tests in 10.433s' in (contract/'1.log').read_text() and (contract/'1.log').read_text().rstrip().endswith('OK')
    checks=work/'native-application-zeroing-objtool-checks-20260909-1';state=json.loads((checks/'record.json').read_text())
    assert [(row['label'],row['actual_failures']) for row in state['checks']]==[('before',2),('after',0),('unknown-suffix',2),('wrong-function',2),('not-rust',2)]
    assert (repo/names[-1]).read_bytes()==(checks/Path(names[-1]).name).read_bytes()
    assert (checks/'original.o').read_bytes()==(work/'native-application-zeroing-module-diagnosis-20260909-1/failed-module-build/ihk_smp_x86_64.o').read_bytes()
    assert (checks/'check-after.c').read_bytes()==(work/'native-source/linux-6.12.0-211.44.1.el10_2/tools/objtool/check.c').read_bytes()
    assert (checks/'objtool-after').read_bytes()==(work/'native-build-base-24a151fe/tools/objtool/objtool').read_bytes()
    record['objtool_controls']=dict(checks=state['checks'],panic_symbol=state['panic_symbol'],unchanged_failed_object=True,current_tool_matches=True,all_original_stack_orc_ibt_warnings_retained=True)
    record['test_results']=dict(host_tests=9,config_license_tests=77,native_modules=3,actual_guest_pass=False)
    for relative in ['docs/verification/native-application-zeroing-images-checkpoint-20260909.json','docs/verification/native-application-memory-images-checkpoint-20260909.json']:
        row=identity(repo/relative);row['path']=relative;record['references'].append(row)
    artifact(out/'helper.py','native-application-zeroing-host-20260909-retention-helper.gz')
    record.update(status='PASS',original_failures=3,finished_utc=datetime.now(timezone.utc).isoformat())
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],manifest,flush=True)
