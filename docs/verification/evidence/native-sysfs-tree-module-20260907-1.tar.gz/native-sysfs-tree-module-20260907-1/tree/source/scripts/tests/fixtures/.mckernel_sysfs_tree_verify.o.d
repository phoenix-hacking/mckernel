/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/.mckernel_sysfs_tree_verify.o.d: /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/mckernel_sysfs_tree_verify.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/native-sysfs-tree-cases.txt ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/mckernel_sysfs_tree_verify.o: /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/mckernel_sysfs_tree_verify.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs /work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/native-sysfs-tree-cases.txt ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/mckernel_sysfs_tree_verify.rs:
/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs:
/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs:
/work/native-sysfs-tree-module-20260907-1/tree/source/scripts/tests/fixtures/native-sysfs-tree-cases.txt:
./rust/libcore.rmeta:
./rust/libkernel.rmeta:
./rust/liballoc.rmeta:
./rust/libcompiler_builtins.rmeta:
./rust/libmacros.so:
./rust/libbindings.rmeta:
./rust/libuapi.rmeta:
./rust/libbuild_error.rmeta:
