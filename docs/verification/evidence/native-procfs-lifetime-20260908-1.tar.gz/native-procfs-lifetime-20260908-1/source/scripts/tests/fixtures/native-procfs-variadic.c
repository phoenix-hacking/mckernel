int kprintf(const char *format, ...) { (void)format; return 0; }
