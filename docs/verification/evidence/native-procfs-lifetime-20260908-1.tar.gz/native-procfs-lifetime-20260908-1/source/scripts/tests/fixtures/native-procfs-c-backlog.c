#include <stdio.h>
#include <assert.h>
struct ikc_scd_packet { int unused; };
static int status, retry, freed;
static int _process_procfs_request(struct ikc_scd_packet *p, int *result) { (void)p; *result=retry; return status; }
static void kfree_tracked(void *p, const char *file, int line) { (void)p; (void)file; (void)line; ++freed; }
static int do_procfs_backlog(void *arg)
{
	struct ikc_scd_packet *rpacket = arg;
	int result = 0;

	_process_procfs_request(rpacket, &result);
	if (!result) {
		kfree_tracked(arg, __FILE__, __LINE__);
	}
	return result;
}
int main(void) { struct ikc_scd_packet p; for (retry=0;retry<=1;++retry) for (status=-12;status<=0;status+=6) { freed=0; int result=do_procfs_backlog(&p); assert(result==retry && freed==!retry); printf("BACKLOG status=%d retry=%d returned=%d freed=%d\n",status,retry,result,freed); } return 0; }
