#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn ihk_mc_get_processor_id() -> CInt { panic!("unexpected external effect: ihk_mc_get_processor_id"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn get_cpu_local_var_result(id: CInt) -> *mut CpuLocalVar { panic!("unexpected external effect: get_cpu_local_var_result"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn ihk_ikc_send(channel: *mut c_void, packet: *mut IkcScdPacket, flags: CInt) -> CInt { panic!("unexpected external effect: ihk_ikc_send"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn cpu_pause() { panic!("unexpected external effect: cpu_pause"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn page_fault_process_vm(vm: *mut ProcessVm, offset: *mut c_void, reason: CULong) -> CInt { panic!("unexpected external effect: page_fault_process_vm"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn ihk_mc_pt_virt_to_phys(
        page_table: *mut c_void,
        offset: *mut c_void,
        physp: *mut CULong,
    ) -> CInt { panic!("unexpected external effect: ihk_mc_pt_virt_to_phys"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn is_mckernel_memory(start: CULong, end: CULong) -> CInt { panic!("unexpected external effect: is_mckernel_memory"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn ihk_mc_pt_virt_to_pagemap(page_table: *mut c_void, addr: CULong) -> CULong { panic!("unexpected external effect: ihk_mc_pt_virt_to_pagemap"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn bitmap_scnprintf(buf: *mut c_char, len: u32, src: *const CULong, nbits: CInt) -> CInt { panic!("unexpected external effect: bitmap_scnprintf"); }
#[allow(unused_variables)]
#[no_mangle]
pub unsafe extern "C" fn bitmap_scnlistprintf(buf: *mut c_char, len: u32, src: *const CULong, nbits: CInt) -> CInt { panic!("unexpected external effect: bitmap_scnlistprintf"); }
