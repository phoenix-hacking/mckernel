kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-signals-images-20260909-1/source/kernel/copy.c
