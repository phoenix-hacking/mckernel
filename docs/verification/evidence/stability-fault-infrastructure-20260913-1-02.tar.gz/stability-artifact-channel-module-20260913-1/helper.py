from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shlex,shutil
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
work,repo=Path('/work'),Path('/workspace');out=work/'stability-artifact-channel-module-20260913-1';out.mkdir()
base=work/'native-build-base-24a151fe';source=work/'native-source/linux-6.12.0-211.44.1.el10_2'
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],scope='Pinned Linux virtio-console transport for exact guest test artifacts only',production_gate_credit=False,guest_execution=False)
def identity(p):
 d=p.read_bytes();return dict(path=str(p),size=len(d),sha256=hashlib.sha256(d).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 assert shutil.disk_usage(work).free>3*1024**3
 shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(os.environ)
 def run(label,argv,timeout=120):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=20,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['raw_wait_status']==0 and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  return (out/(label+'-collection')/'stdout.bin').read_text()
 protected=[base/'drivers/misc/mckernel'/n for n in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko')]+[base/'.config',base/'arch/x86/boot/bzImage']
 record['protected_before']=[identity(p) for p in protected]
 for p in [source/'drivers/char/virtio_console.c',source/'drivers/char/Kconfig',source/'drivers/char/Makefile',base/'.config']:
  q=out/'source'/p.relative_to(source if source in p.parents else base);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);record['inputs'].append(dict(original=identity(p),retained=identity(q)))
 command=work/'native-irq-transport-exact-stage-20260907-1/module-build.command';argv=shlex.split(command.read_text())
 assert argv[-3:]==['drivers/misc/mckernel/ihk.ko','drivers/misc/mckernel/ihk-smp-x86_64.ko','drivers/misc/mckernel/mcctrl.ko']
 run('linux-virtio-console-module',argv[:-3]+['drivers/char/virtio_console.ko'],1200)
 for p in sorted((base/'drivers/char').glob('*virtio_console*')):
  if p.is_file():shutil.copyfile(p,out/p.name)
 for p in sorted((base/'drivers/char').glob('.*virtio_console*')):
  if p.is_file():shutil.copyfile(p,out/p.name)
 run('module-info',['modinfo',str(out/'virtio_console.ko')])
 deps=run('module-dependencies',['modinfo','-F','depends',str(out/'virtio_console.ko')]);assert deps.strip()=='',deps
 run('module-symbols',['nm','-u',str(out/'virtio_console.ko')])
 record['protected_after']=[identity(p) for p in protected];assert record['protected_after']==record['protected_before']
 record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json']
 record.update(status='PASS_BUILD_ONLY',mckernel_modules_and_kernel_unchanged=True)
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
