from pathlib import Path
import hashlib, json, os, shutil, stat, tarfile, tempfile

REPO = Path('/home/holden/mckernel')
OUT = Path(tempfile.mkdtemp(prefix='stability-held-harness-publication-20260913-'))
SOURCE_ROOTS = [
    ('author', Path('/tmp/stability-published-hold-harness-source-20260913-ie3ihcb0')),
    ('root-source-review', Path('/tmp/stability-held-native-harness-root-review-20260913-vquw2oe6')),
    ('independent-source-and-result-review', Path('/tmp/stability-published-native-results-independent-review-20260913-gqgt21sf')),
]
FILES = {
 'scripts/tests/fixtures/stability-published-hold-v1/native-harness.rs':'ec2ac4ddedbcadeb010d69936f4ece7125605659e3f98b5e50e499d7e00a93e6',
 'scripts/tests/fixtures/stability-published-hold-v1/native-expectations.json':'905de562ee0ccb6d2f453a31eee091956d474905cec2012055822e43f1806fc7',
 'scripts/tests/fixtures/stability-published-hold-v1/harness.md':'3445618283ef4242d4053450cde18e5c746de2e84bec879cead12ba62a4cb9eb',
 'scripts/tests/fixtures/stability-published-hold-v1/stage-tests.md':'a56e4cbac960fa92c2c9ffebdea4c3110f09ec3caabf2920ffd7b641a8110788',
 'scripts/tests/prepare_stability_published_hold_harness.py':'c1159d658f06566e8afd87f94810d8e10d674e4cb5b622b272bea79d9de03e78',
 'scripts/tests/test_stability_published_hold_stage.py':'8a30fd7e5688505e432a36b6b6ea3d52b3cd578a10823c38550f630de68573e9',
}
def identity(p, label=None):
    b=p.read_bytes()
    return {'path': label if label is not None else str(p), 'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p, data):
    with p.open('x') as f: json.dump(data,f,indent=2,sort_keys=True);f.write('\n')
def retain(src,dst):
    for p in sorted(src.rglob('*')):
        mode=p.lstat().st_mode
        q=dst/p.relative_to(src)
        if stat.S_ISDIR(mode): q.mkdir(parents=True,exist_ok=True)
        elif stat.S_ISREG(mode):
            assert p.stat().st_size <= 8*1024*1024,(str(p),'oversized source record')
            q.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(p,q)
            assert identity(p)['sha256']==identity(q)['sha256']
        else: raise ValueError('unexpected source-review special file '+str(p))
for name,source in SOURCE_ROOTS: retain(source,OUT/name)
current=[]
for rel,sha in FILES.items():
    p=REPO/rel;meta=identity(p,rel);assert meta['sha256']==sha,(rel,meta)
    q=OUT/'current-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
    assert identity(q)['sha256']==sha;current.append(meta)
shutil.copy2(Path(__file__),OUT/'publication-helper.py')
review=OUT/'independent-source-and-result-review/review.json'
root_review=OUT/'root-source-review/review.json'
assert identity(review)['sha256']=='fb2c78cc2c1775a34dac0b5f787400adadc53bc58bd3acaf2adf777070c9f310'
assert identity(root_review)['sha256']=='e964e2e99f23d3bbada73466f2fb6f2dfc06b9d03a6a615d40efd96850f41c12'
review_data=json.loads(review.read_text());actual=review_data['actual_record']
assert identity(Path(actual['path']))==actual
assert review_data['actual_process_cases']==48 and review_data['unique_process_identities']==48
actual_data=json.loads(Path(actual['path']).read_text())
assert actual_data['status']=='PASS_CONTROLLED_NATIVE_HOLD_INTERFACES_ONLY'
assert actual_data['passed_process_cases']==48
assert all(actual_data[k] is False for k in ['production_gate_credit','transport_acceptance','application_acceptance'])
for row in review_data['retained_inputs']:
    p=review.parent/row['retained'];meta=identity(p)
    assert meta['size']==row['size'] and meta['sha256']==row['sha256'],str(p)
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file(): manifest.append(identity(p,str(p.relative_to(OUT))))
dump(OUT/'members-before-manifest.json',manifest)
archive=REPO/'docs/verification/evidence/stability-published-hold-harness-source-20260913.tar.gz'
members=[]
with tarfile.open(str(archive),'x:gz') as tar:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            rel=str(p.relative_to(OUT));members.append(identity(p,rel));tar.add(str(p),arcname=rel,recursive=False)
with tarfile.open(str(archive),'r:gz') as tar:
    found=tar.getmembers();assert len(found)==len(members)
    for member,expected in zip(found,members):
        assert member.isfile() and member.name==expected['path'] and member.size==expected['size']
        b=tar.extractfile(member).read();assert hashlib.sha256(b).hexdigest()==expected['sha256']
for rel,sha in FILES.items():assert identity(REPO/rel)['sha256']==sha
record={
 'schema_version':1,'record_kind':'stability_published_hold_harness_source_and_result_retention',
 'status':'RETAINED_SOURCE_REVIEWS_AND_CONTROLLED_NATIVE_48_PASS',
 'source_retention':str(OUT),'original_source_roots':[{'archive_prefix':n,'path':str(p)} for n,p in SOURCE_ROOTS],
 'current_sources':current,'archive':identity(archive,str(archive.relative_to(REPO))),
 'archive_member_count':len(members),'archive_members':members,'all_archive_members_read_back_and_verified':True,
 'independent_source_and_result_review':identity(review,'independent-source-and-result-review/review.json'),
 'root_preexecution_review':identity(root_review,'root-source-review/review.json'),
 'actual_run_record':actual,'actual_run_status':actual_data['status'],
 'root_run_scope':actual_data['scope'],'actual_process_cases':48,'modes':[2,3],
 'reviewed_command_joins':len(review_data['commands']),'reviewed_ioctl_pairs':len(review_data['decoded_actual_ioctl_pairs']),
 'reviewed_mapped_identity_occurrences':len(review_data['verified_identity_occurrences']),
 'container_only_identity_occurrences_not_reopened_by_independent_reviewer':len(review_data['unmapped_container_identity_occurrences']),
 'stage_tests':{'count':18,'status':'SOURCE_REVIEW_ONLY_EXECUTION_PENDING','source':next(x for x in current if x['path'].endswith('test_stability_published_hold_stage.py')),
   'retention_correction':'Original ba68307a stage test source is retained. Final 8a30fd7e retains owned FIFO and symlink fixtures with exact type/mode/target in place; stage-tests.md supersedes the frozen harness.md cleanup paragraph. No subject tests were executed by this author or reviewer.'},
 'author_subject_execution':False,'independent_reviewer_subject_execution':False,
 'production_gate_credit':False,'transport_acceptance':False,'application_acceptance':False,
 'limitations':review_data['limitations']+['Full actual ELF/build/run artifacts remain in the root-owned attempt and its separate retention record; this archive retains the complete small independent review tree and source history.','A native module build, measured stack and actual guest publication modes remain separate gates. Controlled stdlib stub tests do not prove kernel scheduling or ownership.'],
}
publication=REPO/'docs/verification/stability-published-hold-harness-source-20260913.json'
dump(publication,record)
print(json.dumps({'source_retention':str(OUT),'publication':identity(publication),'archive':record['archive'],'members':len(members),'status':record['status']},indent=2))
