from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shlex,shutil
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work')
out=work/'stability-published-native-tests-20260913-1';out.mkdir();(out/'tmp').mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],modes=[],scope='Exact included native methods with concrete stdlib stubs;24 fresh processes per mode, no kernel/controller/guest execution',application_acceptance=False,transport_acceptance=False,production_gate_credit=False)
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 assert shutil.disk_usage(work).free>3*1024**3
 shutil.copyfile(__file__,out/'helper.py')
 src=repo/'scripts/application-tests/supervisor.py';assert identity(src)['sha256']=='8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
 shutil.copyfile(src,out/'supervisor.py');record['inputs'].append(identity(src))
 spec=importlib.util.spec_from_file_location('native_supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(out/'tmp'))
 def run(label,argv,timeout=120,cap=8*1024**2):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0],path=env['PATH'])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=15,stdout_limit_bytes=cap,stderr_limit_bytes=cap)
  record['commands'].append(dict(label=label,argv=argv,environment=env,collection=result));save()
  assert result['status']=='COMPLETED' and result['raw_wait_status']==0 and result['cleanup_complete'],(label,result)
  return (out/(label+'-collection/stdout.bin')).read_bytes()
 package=out/'source/scripts/tests';package.mkdir(parents=True)
 names=['prepare_stability_published_hold_harness.py']
 for name in names:
  src=repo/'scripts/tests'/name;shutil.copyfile(src,package/name);record['inputs'].append(identity(src))
 for name in ['stability_phase.rs','smp_application.append.rs','smp_application_syscall.append.rs','smp_service.append.rs','smp_memory.append.rs','send-gate.rs','native-harness.rs','native-expectations.json','harness.md']:
  src=repo/'scripts/tests/fixtures/stability-published-hold-v1'/name;dst=package/'fixtures/stability-published-hold-v1'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);record['inputs'].append(identity(src))
 src=repo/'scripts/tests/fixtures/stability-owner-observer/stability_observer.rs';dst=package/'fixtures/stability-owner-observer/stability_observer.rs';dst.parent.mkdir(parents=True);shutil.copyfile(src,dst);record['inputs'].append(identity(src))
 required={'native-harness.rs':'ec2ac4ddedbcadeb010d69936f4ece7125605659e3f98b5e50e499d7e00a93e6','native-expectations.json':'905de562ee0ccb6d2f453a31eee091956d474905cec2012055822e43f1806fc7','prepare_stability_published_hold_harness.py':'c1159d658f06566e8afd87f94810d8e10d674e4cb5b622b272bea79d9de03e78'}
 for name,prefix in required.items():
  path=package/name if name.endswith('.py') else package/'fixtures/stability-published-hold-v1'/name
  assert identity(path)['sha256']==prefix,(name,identity(path))
 expectations=json.loads((package/'fixtures/stability-published-hold-v1/native-expectations.json').read_text());assert len(expectations['cases'])==24
 run('rustc-version',['rustc','--version','--verbose'])
 compiler=Path(shutil.which('rustc',path=env['PATH']));record['compiler']=identity(compiler.resolve())
 sysroot=Path(run('rustc-sysroot',['rustc','--print','sysroot']).decode().strip());record['sysroot']=str(sysroot)
 record['sysroot_libraries']=[identity(p) for p in sorted((sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/lib').glob('*.rlib'))]
 for mode in [2,3]:
  prepared=out/('prepared-mode'+str(mode))
  run('prepare-mode'+str(mode),['python3','-B',str(package/'prepare_stability_published_hold_harness.py'),'--output',str(prepared),'--mode',str(mode)])
  preparation=json.loads((prepared/'record.json').read_text());assert preparation['status']=='PREPARED_HARNESS_SOURCE_NOT_COMPILED_NOT_EXECUTED'
  elf=out/('native-mode'+str(mode)+'.elf');deps=out/('native-mode'+str(mode)+'.d')
  run('compile-mode'+str(mode),['rustc','--edition=2021','-g','--emit=dep-info='+str(deps)+',link='+str(elf),str(prepared/'harness.rs')],180)
  dependent=[]
  for line in deps.read_text().splitlines():
   if ': ' in line:
    for path in shlex.split(line.split(': ',1)[1]):
     p=Path(path)
     if p.is_file() and str(p) not in [row['path'] for row in dependent]:dependent.append(identity(p))
  mode_record=dict(mode=mode,preparation=identity(prepared/'record.json'),elf=identity(elf),dependencies=dependent,cases=[])
  record['modes'].append(mode_record);save()
  run('elf-mode'+str(mode),['readelf','-h','-l','-d',str(elf)])
  loader=run('loader-mode'+str(mode),['ldd',str(elf)]).decode();mode_record['loader_dependencies']=[]
  for line in loader.splitlines():
   for item in line.split():
    if item.startswith('/') and Path(item).is_file():mode_record['loader_dependencies'].append(identity(Path(item)))
  for case in expectations['cases']:
   label='mode'+str(mode)+'-'+case['name'];data=run(label,[str(elf),case['name']],8,262144)
   marker=('HARNESS_CASE_PASS mode='+str(mode)+' case='+case['name']+' application_acceptance=false\n').encode()
   assert data.endswith(marker) and data.count(b'HARNESS_CASE_PASS ')==1
   assert data.startswith(('HARNESS_BEGIN mode='+str(mode)+' case='+case['name']+' scope=controlled_native_interfaces_only acceptance=false\n').encode())
   assert (out/(label+'-collection/stderr.bin')).read_bytes()==b''
   mode_record['cases'].append(dict(name=case['name'],oracle=case['oracle'],terminal_marker=marker.decode().strip(),collection_directory=label+'-collection'));save()
  for row in dependent+mode_record['loader_dependencies']:assert identity(Path(row['path']))==row
 for row in record['inputs']+record['sysroot_libraries']:assert identity(Path(row['path']))==row
 record.update(status='PASS_CONTROLLED_NATIVE_HOLD_INTERFACES_ONLY',passed_process_cases=48)
except BaseException as error:
 record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
