#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Tag {
    pub(crate) index: usize,
    pub(crate) serial: Option<u64>,
    pub(crate) physical: u64,
    pub(crate) end: u64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Claim {
    pub(crate) os: u32,
    pub(crate) generation: u64,
    pub(crate) response: Tag,
    pub(crate) payload: Option<Tag>,
}
#[derive(Clone, Copy, Debug)]
pub(crate) struct Delivery {
    pub(crate) serial: u64,
    pub(crate) phase: &'static str,
    pub(crate) phase_worker: Option<(u64, i32)>,
    pub(crate) pid: i32,
    pub(crate) cpu: i32,
    pub(crate) requester: i32,
    pub(crate) target: i32,
    pub(crate) number: u64,
    pub(crate) response: u64,
    pub(crate) arguments: [u64; 6],
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Selection {
    pub(crate) os: u32,
    pub(crate) generation: u64,
    pub(crate) pid: i32,
    pub(crate) cpu: i32,
    pub(crate) requester: i32,
    pub(crate) application: u64,
    pub(crate) worker: u64,
    pub(crate) delivery: u64,
    pub(crate) ledger_serial: u64,
    pub(crate) ledger_index: usize,
    pub(crate) response: u64,
    pub(crate) response_end: u64,
}
#[derive(Clone, Copy, Debug)]
pub(crate) enum Phase {
    BlockedRead,
    AcceptedReturn,
    Terminal,
    TerminalPlusFive,
    Recovery,
    AfterEightHello,
}

