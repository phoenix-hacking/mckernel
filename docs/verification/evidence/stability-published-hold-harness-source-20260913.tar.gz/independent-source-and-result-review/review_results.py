from pathlib import Path
import hashlib
import json
import re
import shutil
import struct

OUT = Path(__file__).resolve().parent
ATTEMPT = Path('/home/holden/mckernel-work/scratch/stability-published-native-tests-20260913-1')
REPO = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
CASES = ['decode','release_decode','identity_sequence','pending_poll','timer_none','timer_zero','deadline',
         'held_release','barrier_freeze','hold_cap','repeat_accepted','snapshot_failure','snapshot_deadline',
         'timer_recheck','release_duplicate','release_failed_once','release_expired','released_invalid',
         'copyout_ambiguity','permit_busy','copyin_failure','local_health','claim_recheck','phase_order']
retained = {}
verified = []
unmapped = []

def ident(data):
    return {'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def retain(path):
    data = path.read_bytes()
    if path not in retained:
        target = OUT/'inputs'/str(path).lstrip('/')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        retained[path] = {'original':str(path),'retained':str(target.relative_to(OUT)),**ident(data)}
    else:
        assert ident(data) == {k:retained[path][k] for k in ('size','sha256')}
    return data

def mapped(name):
    if name.startswith('/work/'):
        return WORK/name[len('/work/'):]
    if name.startswith('/workspace/'):
        if name == '/workspace/scripts/application-tests/supervisor.py':
            return ATTEMPT/'supervisor.py'
        return ATTEMPT/'source'/name[len('/workspace/'):]
    return None

def verify(row, local=None):
    path = local if local is not None else mapped(row['path'])
    if path is None:
        unmapped.append(row)
        return
    data = path.read_bytes()
    assert ident(data) == {k:row[k] for k in ('size','sha256')}, (path,row)
    verified.append({'declared':row,'actual':str(path),**ident(data)})
    if path.suffix != '.elf': retain(path)

def traverse(value):
    if isinstance(value,dict):
        if {'path','size','sha256'} <= value.keys() and str(value['path']).startswith('/'):
            verify(value)
        for child in value.values():traverse(child)
    elif isinstance(value,list):
        for child in value:traverse(child)

record = json.loads(retain(ATTEMPT/'record.json'))
assert record['status'] == 'PASS_CONTROLLED_NATIVE_HOLD_INTERFACES_ONLY'
assert record['passed_process_cases'] == 48
assert all(record[x] is False for x in ('application_acceptance','transport_acceptance','production_gate_credit'))
retain(ATTEMPT/'helper.py')
retain(ATTEMPT/'supervisor.py')
traverse(record)
commands = record['commands']
assert len(commands) == 58 and len({c['label'] for c in commands}) == 58
checks = []
processes = []
ioctl_rows = []
for command in commands:
    label = command['label']
    directory = ATTEMPT/(label+'-collection')
    report = json.loads(retain(directory/'report.json'))
    request = json.loads(retain(directory/'request.json'))
    assert report == command['collection']
    assert report['argv'] == request['argv'] == command['argv']
    assert report['env'] == request['env'] == command['environment']
    assert report['status'] == 'COMPLETED' and type(report['raw_wait_status']) is int and report['raw_wait_status'] == 0
    assert report['wait_status'] == {'kind':'exited','code':0}
    assert report['cleanup_complete'] is True and report['descendant_records_omitted'] == 0
    assert report['payload_monotonic_started'] <= report['payload_completion_observed_monotonic'] < report['payload_monotonic_deadline']
    assert report['monotonic_finished'] < report['payload_monotonic_deadline'] + report['cleanup_timeout_seconds']
    assert retain(directory/'worker.stderr') == b''
    streams = {}
    for which in ('stdout','stderr'):
        data = retain(directory/(which+'.bin')); streams[which]=data
        stream = report['streams'][which]
        assert stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes'] == 0
        assert stream['bytes_observed'] == stream['bytes_retained'] == len(data) <= stream['limit_bytes']
        assert ident(data) == {k:stream['artifact'][k] for k in ('size','sha256')}
    match = re.fullmatch(r'mode([23])-(.+)',label)
    if match:
        mode,case = int(match[1]),match[2]
        assert case in CASES and report['timeout_seconds'] == 8.0
        assert report['stdout_limit_bytes'] == report['stderr_limit_bytes'] == 262144
        assert report['descendants'] == []
        assert report['executable'] == record['modes'][mode-2]['elf']
        stdout = streams['stdout']
        assert streams['stderr'] == b''
        assert stdout.startswith(f'HARNESS_BEGIN mode={mode} case={case} scope=controlled_native_interfaces_only acceptance=false\n'.encode())
        assert stdout.endswith(f'HARNESS_CASE_PASS mode={mode} case={case} application_acceptance=false\n'.encode())
        assert stdout.count(b'HARNESS_CASE_PASS ') == 1
        proc = report['process']; processes.append((proc['pid'],proc['starttime_ticks']))
        assert proc['pid'] == proc['pgid'] == proc['session'] and proc['ppid'] == report['supervisor_pid']
        assert proc['starttime_ticks'] > 0 and report['uid'] == report['gid'] == 1000
        pending = None
        for line in stdout.decode('ascii').splitlines():
            if line.startswith('HARNESS_IOCTL_INPUT hex='):
                assert pending is None
                pending = bytes.fromhex(line.split('=',1)[1]);assert len(pending)==256
                version,operation,osid,pid=struct.unpack_from('<IIIi',pending)
                assert version==2 and operation in (1,6,7,8) and osid==0 and pid==1234
                assert struct.unpack_from('<QQQQ',pending,16)[0]==7
                assert struct.unpack_from('<QQ',pending,32)==(0x0102030405060708,0x1112131415161718)
                assert struct.unpack_from('<QQ',pending,48)==((0,0) if operation==1 else (44,45))
                if operation==8:
                    assert struct.unpack_from('<QQ',pending,64)==(2,2) and pending[80:112]==bytes(range(32)) and pending[112:]==bytes(144)
                else:assert pending[64:]==bytes(192)
            elif line.startswith('HARNESS_IOCTL_OUTPUT result='):
                assert pending is not None
                parsed=re.fullmatch(r'HARNESS_IOCTL_OUTPUT result=(Ok\(0\)|Err\(Error\((-?[0-9]+)\)\)) hex=([0-9a-f]{512})',line)
                assert parsed
                value=0 if parsed[2] is None else int(parsed[2]);output=bytes.fromhex(parsed[3])
                assert output[:64]==pending[:64]
                if output == pending:
                    assert value in (-11,-14,-116)
                else:
                    assert struct.unpack_from('<q',output,72)[0]==value
                    assert struct.unpack_from('<Q',output,200)[0]==struct.unpack_from('<Q',pending,24)[0]
                    assert struct.unpack_from('<QQQQQQQ',output,80)==(42,43,44,45,2,0x2000,0x2028)
                    assert struct.unpack_from('<iiiIQ',output,136)==(1234,0,1235,0,7)
                    assert struct.unpack_from('<QQ',output,240)[0]<=struct.unpack_from('<QQ',output,240)[1]
                ioctl_rows.append({'mode':mode,'case':case,'request_hex':pending.hex(),'reply_hex':output.hex(),'raw_result':value,'output_unchanged':output==pending})
                pending=None
        assert pending is None
    checks.append({'label':label,'raw_wait':0,'streams_complete':True,'owned_cleanup_complete':True,
                   'elapsed_seconds':report['elapsed_seconds'],'report':ident((directory/'report.json').read_bytes())})
assert len(processes)==len(set(processes))==48

package=ATTEMPT/'source/scripts/tests/fixtures/stability-published-hold-v1'
expectations=json.loads(retain(package/'native-expectations.json'))
assert [case['name'] for case in expectations['cases']]==CASES
harness=retain(package/'native-harness.rs')
assert re.findall(r'^        "([a-z_]+)" => \{',harness.decode(),re.M)==CASES
root_review=Path('/tmp/stability-held-native-harness-root-review-20260913-vquw2oe6/review.json')
review=json.loads(retain(root_review))
for row in review['inputs']:
    verify(row,ATTEMPT/'source'/row['path'])

for mode in record['modes']:
    number=mode['mode'];prepared=ATTEMPT/f'prepared-mode{number}'
    p=json.loads(retain(prepared/'record.json'));traverse(p)
    assert p['mode']==number and p['status']=='PREPARED_HARNESS_SOURCE_NOT_COMPILED_NOT_EXECUTED'
    assert p['subject_methods_modified'] is False
    assert p['cases']==expectations['cases'] and [c['name'] for c in mode['cases']]==CASES
    for row in p['outputs']:verify(row,prepared/row['path'])
    assert retain(prepared/'harness.rs')==harness
    for name in ('smp_application.append.rs','smp_application_syscall.append.rs','smp_service.append.rs','smp_memory.append.rs','send-gate.rs'):
        assert retain(prepared/name)==retain(package/name)
    assert retain(prepared/'stability_phase.rs')==retain(package/'stability_phase.rs').replace(b'@MODE@',str(number).encode())
    observer=retain(prepared/'inputs/stability_observer.rs')
    fragments=[]
    for frag in p['observer_type_fragments']:
        data=observer[frag['start_offset']:frag['end_offset']]
        assert ident(data)=={k:frag[k] for k in ('size','sha256')};fragments.append(data)
    assert retain(prepared/'observer-types.rs')==b'\n'.join(fragments)
    dependent=retain(ATTEMPT/f'native-mode{number}.d').decode().splitlines()[0].split(': ',1)[1].split()
    assert dependent==[r['path'] for r in mode['dependencies']]
    assert {Path(r['path']).name for r in mode['dependencies']}=={r['path'] for r in p['outputs']}
    elf=(ATTEMPT/f'native-mode{number}.elf').read_bytes()
    assert elf[:7]==b'\x7fELF\x02\x01\x01' and struct.unpack_from('<H',elf,18)[0]==62
    assert ident(elf)=={k:mode['elf'][k] for k in ('size','sha256')}

stage_test=REPO/'scripts/tests/test_stability_published_hold_stage.py'
stage_doc=REPO/'scripts/tests/fixtures/stability-published-hold-v1/stage-tests.md'
retain(stage_test);retain(stage_doc)
assert re.findall(r'^    def (test_\w+)\(',stage_test.read_text(),re.M).__len__()==18
assert 'retained_in_place' in stage_test.read_text() and 'unlink(' not in stage_test.read_text()

result={'schema_version':1,'status':'PASS_INDEPENDENT_RETAINED_CONTROLLED_NATIVE_RESULTS_REVIEW',
        'scope':'Actual48 fresh Linux harness processes executing exact included private native methods against explicit stdlib stubs; no new subject execution by reviewer.',
        'actual_record':{'path':str(ATTEMPT/'record.json'),**ident((ATTEMPT/'record.json').read_bytes())},
        'commands':checks,'actual_process_cases':48,'unique_process_identities':48,
        'decoded_actual_ioctl_pairs':ioctl_rows,'verified_identity_occurrences':verified,
        'unmapped_container_identity_occurrences':unmapped,'retained_inputs':list(retained.values()),
        'source_review':{'status':'PASS_SOURCE_ONLY','harness':'ec2ac4ddedbcadeb010d69936f4ece7125605659e3f98b5e50e499d7e00a93e6',
          'root_preexecution_review':ident(root_review.read_bytes()),
          'checks':['Exact actual Mailbox/Remote/Runtime/ioctl/send-gate and phase source bodies are included, with only frozen mode replacement and original observer type extraction.',
                    'Fresh static state per process, literal identities/errno/deadlines, original timer None/Some0, one-shot release, copyout ambiguity, local health and Claim mutations inspected independently.',
                    'Controlled clock/guard/usercopy/context/owner stubs remain explicit; no real production ownership, scheduling, stack or response access is represented.',
                    '18 stage-test source methods reviewed, no execution evidence credited here. stage-tests.md supersedes frozen harness.md cleanup paragraph: owned FIFO/symlink fixtures remain and require type-aware archival.']},
        'limitations':['Pinned container compiler/loader/sysroot paths without /work or /workspace mappings were not reopened; original recorded hashes retained, no complete toolchain freshness claim.',
                       'Two ELF artifacts were rehashed and headers independently decoded; original full binaries remain in root actual attempt/archive instead of duplicating them in this small review tree.',
                       'Synthetic EMITTING retries in barrier_freeze intentionally exercise the isolated gate interface, not the sole production Packets scheduling contract.',
                       'Actual native kernel build, compiled stack, real ioctl/user access, runtime timers and publication, controller/QMP/UART/physical proof and actual published mode outcomes remain required.'],
        'reviewer_subject_execution':False,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False}
(OUT/'review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for path,row in retained.items():assert ident(path.read_bytes())=={k:row[k] for k in ('size','sha256')}
print(json.dumps({'review':str(OUT/'review.json'),**ident((OUT/'review.json').read_bytes()),'commands':len(checks),
                  'cases':48,'ioctl_pairs':len(ioctl_rows),'retained_inputs':len(retained),
                  'verified_identity_occurrences':len(verified),'unmapped_container_identity_occurrences':len(unmapped)},indent=2))
