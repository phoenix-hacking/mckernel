"""Read retained identities and CPIO bytes; do not execute reviewed software."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat

ROOT = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
OUT = Path('/tmp/stability-guest6-source-binding-review-20260913-1')
OUT.mkdir()
shutil.copy2(__file__, OUT / 'review-helper.py')
findings, verified, unavailable = [], [], []


def local(path):
    if path.startswith('/work/'):
        return WORK / path[6:]
    if path.startswith('/workspace/'):
        return ROOT / path[11:]
    return None


def identity(path):
    size = 0
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while True:
            data = stream.read(1024 * 1024)
            if not data:
                break
            size += len(data)
            digest.update(data)
    return dict(path=str(path), size=size, sha256=digest.hexdigest())


def check(row, label):
    path = local(row['path'])
    if path is None:
        unavailable.append(dict(label=label, identity=row, reason='Container absolute path not mapped to the host.'))
        return
    got = identity(path)
    matches = got['size'] == row['size'] and got['sha256'] == row['sha256']
    verified.append(dict(label=label, recorded=row, observed=got, matches=matches))
    if not matches:
        findings.append(dict(label=label, recorded=row, observed=got))


def retain(path):
    rel = path.relative_to(WORK) if path.is_relative_to(WORK) else Path('repository') / path.relative_to(ROOT)
    dest = OUT / 'source' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)


names = dict(guest='stability-transport-fault-guest-20260913-prepublish-hard-6',
             prepared='stability-fault-guest-root-20260913-prepublish-hard-5',
             preparation='stability-fault-guest-preparation-20260913-5',
             module='stability-transport-fault-module-20260913-prepublish-hard-3',
             controller='stability-owner-terminal-controller-build-20260913-1',
             payload='stability-runnable-thread-payload-build-20260913-1')
records = {}
for name, dirname in names.items():
    path = WORK / dirname / 'record.json'
    records[name] = json.loads(path.read_bytes())
    retain(path)
for name in ('guest', 'prepared'):
    for row in records[name]['inputs']:
        check(row, name + ':input')
for name in ('controller', 'payload'):
    data = records[name]
    for row in data['inputs']:
        check(row['retained'], name + ':retained-source')
        retain(local(row['retained']['path']))
        original = local(row['original']['path'])
        if original is not None:
            check(row['original'], name + ':current-source')
    for row in data['compiled_outputs']:
        check(row, name + ':compiled-output')
    for row in data['loader_dependencies']:
        copied = dict(row, path=records['prepared']['root'] + row['path'])
        check(copied, name + ':prepared-loader')
    for row in data['compiler_dependencies']:
        if local(row['path']) is not None:
            check(row, name + ':local-compiler-dependency')
        else:
            unavailable.append(dict(label=name + ':compiler-dependency', identity=row,
                reason='Pinned container compiler header/library; no container execution in this review.'))
for row in records['module']['compiled_modules']:
    check(row, 'module:compiled-output')
compiler = {r['path']: r for r in records['module']['compiler_inputs']}
for row in records['module']['retained_compiler_bindings']:
    check(row['retained'], 'module:retained-compiler-input')
    expected = compiler.get(row['historical_compile_path'])
    if expected is None or any(expected[k] != row['retained'][k] for k in ('size', 'sha256')):
        findings.append(dict(label='module:compiler-input-mapping', binding=row, expected=expected))
for row in records['module']['overlays']:
    check(row, 'module:overlay-record')
    retain(local(row['path']))
for row in records['prepared']['bindings']:
    check(row['prepared'], 'root:prepared-binding')
    originals = [row['original']] if 'original' in row else row['compiler_outputs']
    for original in originals:
        if local(original['path']) is not None:
            check(original, 'root:original-binding')
        if any(original[k] != row['prepared'][k] for k in ('size', 'sha256')):
            findings.append(dict(label='root:copy-binding', row=row))

guest = WORK / names['guest']
root = local(records['prepared']['root'])
for path in [guest / 'helper.py', guest / 'initramfs.list', root / 'init',
             guest / 'guest-artifacts/files/boot-identity.txt',
             guest / 'guest-artifacts/files/mckernel/argv.nul',
             guest / 'guest-artifacts/files/linux/argv.nul']:
    retain(path)
for path in sorted((guest / 'source').iterdir()):
    if path.is_file(): retain(path)
runner = identity(guest / 'helper.py')
if runner['sha256'] != '3215065d832d18638bd3901c530d5a6bdd89569b6643ea6cd6c0162a804a0d7d':
    findings.append(dict(label='guest:runner-freeze', observed=runner))

# Independently read the archive passed to QEMU. This is data inspection, not
# mounting/extraction or execution. Bound names, member sizes and total bytes.
cpio_members = {}
total = 0
with gzip.open(str(guest / 'initramfs.cpio.gz'), 'rb') as stream:
    for ordinal in range(1000):
        raw = stream.read(110)
        if len(raw) != 110 or raw[:6] != b'070701':
            raise ValueError('unexpected retained newc header')
        words = [int(raw[6+8*i:14+8*i], 16) for i in range(13)]
        mode, size, namesize = words[1], words[6], words[11]
        if not 1 <= namesize <= 4096 or size > 64 * 1024 * 1024:
            raise ValueError('retained newc member exceeds bound')
        name_raw = stream.read(namesize)
        if len(name_raw) != namesize or name_raw[-1:] != b'\0':
            raise ValueError('retained newc name incomplete')
        name = name_raw[:-1].decode('utf-8')
        stream.read(-(110 + namesize) % 4)
        digest = hashlib.sha256()
        remaining = size
        symlink = bytearray()
        while remaining:
            chunk = stream.read(min(remaining, 1024 * 1024))
            if not chunk: raise ValueError('retained newc member incomplete')
            digest.update(chunk)
            if stat.S_ISLNK(mode): symlink.extend(chunk)
            remaining -= len(chunk)
        stream.read(-size % 4)
        total += 110 + namesize + size
        if total > 128 * 1024 * 1024:
            raise ValueError('retained newc total exceeds bound')
        if name == 'TRAILER!!!':
            break
        if name in cpio_members: raise ValueError('duplicate retained newc member')
        row = dict(path=name, mode=stat.S_IMODE(mode), native_mode=mode, size=size,
                   sha256=digest.hexdigest())
        if stat.S_ISLNK(mode): row['target'] = symlink.decode()
        cpio_members[name.lstrip('/')] = row
    else:
        raise ValueError('retained newc trailer absent')
inventory_checks = []
for row in records['prepared']['root_inventory']:
    p = root / row['path']
    st = p.lstat()
    native = cpio_members.get(row['path'])
    observed = dict(path=row['path'], mode=stat.S_IMODE(st.st_mode))
    if stat.S_ISREG(st.st_mode):
        observed.update(kind='file', **{k:v for k,v in identity(p).items() if k != 'path'})
    elif stat.S_ISDIR(st.st_mode): observed['kind'] = 'directory'
    elif stat.S_ISLNK(st.st_mode): observed.update(kind='symlink', target=os.readlink(str(p)))
    else: observed['kind'] = 'unsupported'
    root_match = observed == row
    archive_match = native is not None and native['mode'] == row['mode']
    if row['kind'] == 'file':
        archive_match = archive_match and stat.S_ISREG(native['native_mode']) and all(native[k] == row[k] for k in ('size', 'sha256'))
    elif row['kind'] == 'directory':
        archive_match = archive_match and stat.S_ISDIR(native['native_mode'])
    elif row['kind'] == 'symlink':
        archive_match = archive_match and stat.S_ISLNK(native['native_mode']) and native['target'] == row['target']
    inventory_checks.append(dict(recorded=row, root_matches=root_match, initramfs_matches=archive_match))
    if not root_match or not archive_match:
        findings.append(dict(label='root-and-actual-initramfs-inventory', recorded=row, observed=observed, cpio=native))

result = dict(schema_version=1,
    status='PASS_BOUNDED_SOURCE_AND_BINARY_BINDING_REVIEW_ONLY' if not findings else 'FAIL_BINDING_REVIEW',
    definite_findings=findings, verified_identities=verified,
    root_and_actual_initramfs=inventory_checks, cpio_members=list(cpio_members.values()),
    runner=runner, retained_compiler_inputs=len(records['module']['retained_compiler_bindings']),
    declared_profiles=dict(controller=records['prepared']['controller_profile'], payload=records['prepared']['payload_profile'], mode=records['prepared']['mode']),
    deliberately_unverified_container_inputs=unavailable,
    scope='Read retained bytes, source and metadata; no source helper imports, compiler, tests, container or guest execution. Runtime physical/owner/outcome review belongs to Completion.',
    actual_runtime_acceptance=False, application_acceptance=False, production_gate_credit=False,
    complete_compiler_closure_revalidated=False,
    record_inputs=[identity(WORK / name / 'record.json') for name in names.values()])
with (OUT / 'review.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(dict(review=identity(OUT / 'review.json'), findings=findings,
    checked_identities=len(verified), root_members=len(inventory_checks), cpio_members=len(cpio_members),
    retained_compiler_inputs=result['retained_compiler_inputs']), indent=2))
