from pathlib import Path
import base64, hashlib, json, re, stat, struct
ROOT = Path(__file__).resolve().parent / 'runtime'
ROOT.mkdir(exist_ok=False)
WORK = Path('/home/holden/mckernel-work/scratch')
REPO = Path('/home/holden/mckernel')
GUEST = WORK / 'stability-transport-fault-guest-20260913-prepublish-hard-6'
DIAG = WORK / 'stability-hard-physical-comparison-20260913-1'
rows, blobs = [], {}
sha = lambda b: hashlib.sha256(b).hexdigest()
def take(path, expected=None):
    path = Path(path)
    if path not in blobs:
        before = path.lstat()
        assert stat.S_ISREG(before.st_mode), path
        data = path.read_bytes()
        after = path.lstat()
        assert (before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), path
        rel = ('work/' + path.relative_to(WORK).as_posix()) if path.is_relative_to(WORK) else 'repository/' + path.relative_to(REPO).as_posix()
        destination = ROOT/'inputs'/rel
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(data)
        destination.chmod(stat.S_IMODE(before.st_mode))
        rows.append(dict(path=str(path),retained=destination.relative_to(ROOT).as_posix(),size=len(data),sha256=sha(data),mode=stat.S_IMODE(before.st_mode)))
        blobs[path] = data
    data = blobs[path]
    if expected is not None:
        assert len(data)==expected['size'] and sha(data)==expected['sha256'], path
    return data
def mapped(wire):
    if wire.startswith('/work/'): return WORK/wire.removeprefix('/work/')
    if wire.startswith('/workspace/'): return REPO/wire.removeprefix('/workspace/')
    raise AssertionError(wire)
def bound(row): return take(mapped(row['path']),row)
def read_json(path): return json.loads(take(path))
result=dict(schema_version=1,status='REVIEWING',scope='guest6 retained runtime artifacts only',application_acceptance=False,whole_transport_acceptance=False,tests_executed=False,subject_helpers_imported_or_executed=False,guest_execution=False)
try:
    original=read_json(GUEST/'record.json'); nonce=original['nonce']; F=GUEST/'guest-artifacts/files'
    for p in F.rglob('*'):
        if p.is_file():take(p)
    for rel in ('helper.py','serial.log','qmp-transcript.json','qmp-recovery.json','uart/events.jsonl','uart/report.json','uart/rx.bin','uart/tx.bin','native-prefix-mapping.json','native-dmesg.canonical.bin','owner-observations.json','native-phase-contract.json','guest-artifacts/wire.bin','guest-artifacts/manifest.json','guest-artifacts/ack.bin','guest-artifacts/ack-result.json','export-result.json'):
        take(GUEST/rel)
    for p in (GUEST/'source').iterdir():take(p)
    for p in GUEST.glob('capture-*/*'):
        if p.is_file():take(p)
    for p in [REPO/'docs/verification/ultra-transport-fault-runtime-plan-20260909.md',REPO/'docs/verification/ultra-application-test-plan-20260909.md',REPO/'scripts/tests/fixtures/stability-owner-phase/stability_phase.rs',REPO/'scripts/tests/fixtures/stability-transport-fault/owner-phase-v1/phase_client.h',REPO/'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2/controller.c']:
        take(p)
    assert sha(take(GUEST/'helper.py'))=='3215065d832d18638bd3901c530d5a6bdd89569b6643ea6cd6c0162a804a0d7d'
    # Exact native raw bytes, including every unmodified nonmarker line.
    source=take(F/'native-dmesg.txt');canonical=take(GUEST/'native-dmesg.canonical.bin')
    old=source.splitlines(keepends=True);new=canonical.splitlines(keepends=True);assert len(old)==len(new)
    change=[]
    for n,(a,b) in enumerate(zip(old,new),1):
        expected=re.sub(rb'^(\[ *[0-9]+\.[0-9]+\] )ihk_smp_x86_64: (?=STABILITY_(?:OWNER|RET|PHASE|FAULT)_)',rb'\1',a)
        assert b==expected, n
        if a!=b:change.append(dict(line=n,original_sha256=sha(a),canonical_sha256=sha(b)))
    assert change==read_json(GUEST/'native-prefix-mapping.json')['lines']
    phase=read_json(GUEST/'native-phase-contract.json');owner=read_json(GUEST/'owner-observations.json');snap=owner['snapshots'];key=snap[0]['selection'];ret=owner['ret'];tid=ret['key']['tid']
    pp=phase['phase_observations'];assert phase['status']=='NATIVE_METADATA_MATCH_ONLY'
    for item in pp['events']+[x[y] for x in pp['snapshots'] for y in ('begin','counts','end')]:
        assert sha(new[item['line']-1])==item['raw_sha256']
    assert [s['begin']['phase'] for s in pp['snapshots']]==['BlockedRead','AcceptedReturn','Terminal','TerminalPlusFive']
    for ordinal,s in enumerate(pp['snapshots'],1):
        assert s['owner']==snap[ordinal-1] and s['begin']['phase_sequence']==s['end']['phase_sequence']==ordinal
        assert (s['begin']['nonce_low'],s['begin']['nonce_high'])==(int(nonce[:16],16),int(nonce[16:],16))
        assert s['end']['errno']==s['end']['verification_errno']==0 and s['begin']['mono_ns']<s['counts']['mono_ns']<s['end']['mono_ns']
        c=s['counts'];assert c['mode']==1 and c['published']==c['notification_failures']==c['real_sends']==0
        assert c['attempts']==(0 if ordinal<3 else 1) and c['barrier_attempts']==(0 if ordinal==1 else 1)
        assert c['since_ns']==(0 if ordinal<3 else pp['events'][0]['mono_ns'])
        for row in snap[ordinal-1]['records']:
            if row['kind']=='DOMAIN':assert row['complete'] and row.get('claims_known',True)
            if row['kind']=='END':assert row['complete'] and row['counters_valid']
            if row['kind']=='RUNTIME':assert row['runtime_error']==(0 if ordinal<3 else -5)
            if row['kind']=='DOMAIN' and row['domain']=='applications': assert row['transport_error']==(0 if ordinal<3 else -5) and row['total']==1
    assert [x['kind'] for x in pp['events']]==['FAULT_SELECTED','FAULT_PREPUBLICATION']
    assert pp['events'][0]['selection']==key and pp['events'][0]['bytes']==16 and pp['events'][1]['errno']==-5 and pp['events'][1]['attempts']==1
    assert pp['snapshots'][1]['end']['line']<pp['events'][0]['line']<pp['events'][1]['line']<ret['records'][-1]['line']
    assert b'STABILITY_PHASE_INVALID' not in canonical
    # Both observed Linux process outcomes remain distinct from the McKernel payload.
    ce=[json.loads(x) for x in take(F/'mckernel/events.jsonl').splitlines()];le=[json.loads(x) for x in take(F/'linux/events.jsonl').splitlines()]
    def one(events,name):
        matches=[e for e in events if e['event']==name];assert len(matches)==1,name;return matches[0]
    controller=read_json(F/'mckernel/report.json');reference=read_json(F/'linux/report.json')
    assert controller==original['completed_controller'] and reference==original['linux_reference']
    for label,report,events,rawstatus in [('mckernel',controller,ce,0),('linux',reference,le,37<<8)]:
        assert report['nonce']==nonce and report['collection_status']=='COMPLETE' and report['failure']=='none' and report['failure_errno']==0
        assert report['raw_wait_status']==rawstatus and report['launcher_reaped'] and report['owned_linux_cleanup_complete'] and not report['launcher_kill_sent']
        assert report['finished_ns']-report['started_ns']<90_000_000_000 and report['first_failure_ns']==0 and not report['emergency_capture_attempted']
        assert all(a['monotonic_ns']<=b['monotonic_ns'] for a,b in zip(events,events[1:]))
        start=one(events,'controller-start'); assert (start['uid'],start['euid'],start['gid'],start['egid'])==(0,0,0,0)
        launch=one(events,'launch-request');assert launch['cwd']=='/case/work' and launch['stdin']=='owned-pipe' and launch['umask_octal']=='0022'
        inp=one(events,'ULTRA_FAULT_INPUT');assert inp['write_result']==16 and inp['errno']==0 and bytes.fromhex(inp['bytes_hex'])==b'\xa5'*16
        before=[e for e in events if e['event']=='worker-syscall' and e['monotonic_ns']<inp['begin_ns']][-1]
        fields=bytes.fromhex(before['raw_hex']).split();assert int(fields[0])==0 and int(fields[1],16)==0 and int(fields[3],16)==16
        assert one(events,'owned-child-reaped')['raw_wait_status']==rawstatus
        for stream in ('stdout','stderr'):
            data=take(F/label/(stream+'.bin'));meta=report[stream];assert len(data)==meta['bytes_seen']==meta['bytes_stored'] and meta['eof'] and not meta['truncated']
        assert take(F/label/'env.nul')==b'LANG=C\0LC_ALL=C\0TZ=UTC\0PATH=/bin:/usr/bin\0'
    assert take(F/'linux/argv.nul')==b'/bin/fault-payload\0'
    assert take(F/'mckernel/argv.nul')==b'/bin/mcexec\0-t\0'+b'1\0'+b'0\0/bin/fault-payload\0'
    assert take(F/'linux/stdout.bin')==b'NATIVE_FAILURE_READY\nNATIVE_FAILURE_PASS\n' and take(F/'linux/stderr.bin')==b''
    assert take(F/'mckernel/stdout.bin')==b'NATIVE_FAILURE_READY\n'
    assert take(F/'mckernel/stderr.bin')==b'objdump /proc/self/exe: 2\nwarning: did not set LD_PRELOAD\nret: Protocol error\n'
    assert (controller['launcher_tgid'],controller['linux_worker_tid'],controller['worker_start_ticks'])==tuple(original['control']['identity'])==(key['pid'],tid,3249)
    created=one(ce,'launcher-created');assert created['tgid']==key['pid'] and created['start_ticks']==controller['launcher_start_ticks']
    input_event=one(ce,'ULTRA_FAULT_INPUT');boundary=one(ce,'owner-terminal-waitid');reaped=one(ce,'owned-child-reaped')
    assert controller['input_begin_ns']<=ret['enter_ns']<ret['leave_ns']<boundary['monotonic_ns']<pp['snapshots'][2]['begin']['mono_ns']
    assert boundary['stdout_eof'] and boundary['stderr_eof'] and (boundary['si_code'],boundary['si_status'])==(1,0)
    assert boundary['deadline_ns']==min(controller['input_begin_ns']+15_000_000_000,controller['started_ns']+90_000_000_000)
    assert boundary['monotonic_ns']<boundary['deadline_ns'] and reaped['monotonic_ns']>controller['quiet_ack_ns']
    assert pp['snapshots'][3]['begin']['mono_ns']-pp['snapshots'][2]['end']['mono_ns']>=5_000_000_000
    admission=one(ce,'new-admission-result');probe=one(ce,'admission-probe')
    assert (admission['result'],admission['errno'])==(-1,5) and probe['reaped'] and probe['raw_wait_status']==0 and probe['ioctl_command']==0x30a0290e
    assert controller['new_admission_observed'] and controller['new_admission_errno']==5
    # Independently decode each fixed 256-byte phase request and successful reply.
    def w(b,o):return int.from_bytes(b[o:o+8],'little')
    def d(b,o):return int.from_bytes(b[o:o+4],'little')
    immutable=None;phase_joins=[]
    for n in range(1,4):
        prefix=f'owner-phase-{n:03d}';req=take(F/'mckernel'/(prefix+'-request.bin'));reply=take(F/'mckernel'/(prefix+'-response.bin'));meta=read_json(F/'mckernel'/(prefix+'-result.json'))
        assert len(req)==len(reply)==256 and req[:64]==reply[:64] and not any(req[64:]) and not any(reply[208:])
        assert [d(req,i) for i in (0,4,8,12)]==[1,n,key['os'],key['pid']]
        assert [w(req,i) for i in (16,24,32,40)]==[key['generation'],n,int(nonce[:16],16),int(nonce[16:],16)]
        assert [w(req,i) for i in (48,56)]==([0,0]if n==1 else[key['delivery'],key['ledger_serial']])
        assert [w(reply,i) for i in (80,88,96,104,112,120,128,152)]==[key['application'],key['worker'],key['delivery'],key['ledger_serial'],key['ledger_index'],key['response'],key['response_end'],key['generation']]
        assert [d(reply,i) for i in (136,140,144,148)]==[key['pid'],key['cpu'],key['requester'],key['os']]
        assert w(reply,64)==(1 if n==1 else n+1) and w(reply,72)==w(reply,184)==0 and w(reply,200)==n
        assert w(reply,160)==(1 if n==1 else 3) and w(reply,168)==(0 if n==1 else 2)
        assert (w(reply,176)==0)==(n==1) and w(reply,192)==(0 if n==1 else 1)
        if immutable is None:immutable=reply[80:160]
        assert reply[80:160]==immutable
        assert meta['probe_reaped'] and meta['probe_raw_wait']==0 and meta['response_received'] and not meta['timed_out'] and meta['request_consumed'] and meta['ioctl_called'] and meta['ioctl_result']==meta['ioctl_errno']==meta['client_result']==0
        phase_joins.append(dict(phase=n,request_sequence=n,snapshot=w(reply,64),probe_pid=meta['probe_pid'],probe_raw_wait=meta['probe_raw_wait']))
    # Every exact UART request is matched by both sides; each host ACK follows a successful continued capture.
    rx=take(GUEST/'uart/rx.bin');tx=take(GUEST/'uart/tx.bin');assert rx==take(F/'mckernel/uart.tx') and tx==take(F/'mckernel/uart.rx')
    ue=[json.loads(x) for x in take(GUEST/'uart/events.jsonl').splitlines()]
    for n,c in enumerate(original['phase_captures'],1):
        req=c['request'];m=json.loads(bound(c['manifest']));rec=m['recovery']
        assert rx.splitlines()[n-1]==f'STF1 REQ {nonce} {n} {req["phase"]} prepublish-hard {key["pid"]} {tid} 3249'.encode()
        entries=[e for e in ue if e.get('request',{}).get('sequence',e.get('sequence'))==n]
        by={e['event']:e for e in entries}
        assert by['capture-call']['monotonic_ns']<=int(rec['started_monotonic']*1e9)<int(rec['finished_monotonic']*1e9)<=by['capture-return']['monotonic_ns']<by['ack-written']['monotonic_ns']
        assert by['ack-written']['sha256']==c['manifest']['sha256'] and by['ack-written']['continued']
        ack=[e for e in ce if e['event']=='host-ack' and e['sequence']==n];assert len(ack)==1 and ack[0]['capture_sha256']==c['manifest']['sha256']
        if n==1:assert ack[0]['monotonic_ns']<input_event['begin_ns']
    # Parse the actual C-exporter byte stream independently; compare every path, metadata and content to retained extraction.
    wire=take(GUEST/'guest-artifacts/wire.bin');manifest=read_json(GUEST/'guest-artifacts/manifest.json');ackresult=read_json(GUEST/'guest-artifacts/ack-result.json')
    pos=0
    def consume(n):
        global pos
        assert n>=0 and pos+n<=len(wire);b=wire[pos:pos+n];pos+=n;return b
    assert struct.unpack('<8sII16sIIII',consume(48))==(b'STAF0001',1,48,bytes.fromhex(nonce),256,16777216,1024,0)
    parsed=[];dirs=files=content=0;seen=set();root_seen=False
    while True:
        kind,length,size=struct.unpack('<IIQ',consume(16));path=consume(length).decode('ascii');payload=consume(size)
        if kind==3:
            assert not path and struct.unpack('<4Q',payload)==(len(parsed),dirs,files,content);break
        assert kind in (1,2,4) and size>=64
        values=struct.unpack('<8Q',payload[:64]);mode,dev,ino,sz,ms,mn,cs,cn=values
        metadata=dict(mode=mode,device=dev,inode=ino,size=sz,mtime_seconds=ms,mtime_nanoseconds=mn,ctime_seconds=cs,ctime_nanoseconds=cn)
        if kind==4:
            assert not root_seen and path=='/stability' and metadata==manifest['source']['metadata'];root_seen=True;continue
        assert root_seen and path not in seen and not path.startswith('/') and '..' not in path.split('/');seen.add(path)
        assert stat.S_IFMT(mode)==(stat.S_IFDIR if kind==1 else stat.S_IFREG)
        item=dict(path=path,kind='directory'if kind==1 else'file',metadata=metadata,complete=True,bytes_stored=0 if kind==1 else sz)
        if kind==1:
            assert len(payload)==64 and (F/path).is_dir();dirs+=1
        else:
            assert len(payload)-64==sz and payload[64:]==take(F/path);item['sha256']=sha(payload[64:]);files+=1;content+=sz
        parsed.append(item)
    assert pos==len(wire) and parsed==manifest['entries'] and seen=={p.relative_to(F).as_posix()for p in F.rglob('*')}
    assert (len(parsed),dirs,files,content)==(42,2,40,192385) and manifest['wire_sha256']==sha(wire) and manifest['wire_bytes']==manifest['socket_bytes_received']==len(wire)
    assert manifest['status']=='CAPTURE_COMPLETE' and manifest['received_raw_fully_stored'] and manifest['error']is None
    expected_ack=struct.pack('<8s16sIIQQ32s32s',b'STAA0001',bytes.fromhex(nonce),0,0,content,len(parsed),hashlib.sha256(wire).digest(),hashlib.sha256(take(GUEST/'guest-artifacts/manifest.json')).digest())
    assert take(GUEST/'guest-artifacts/ack.bin')==expected_ack and ackresult['ack_complete'] and ackresult['within_deadline'] and ackresult['bytes_sent']==112 and ackresult['error']is None and ackresult['ack_status']==0
    assert manifest['capture_started_monotonic_ns']<manifest['parse_finished_monotonic_ns']<ackresult['finished_monotonic_ns']<manifest['deadline_monotonic_ns']
    recs=read_json(GUEST/'qmp-recovery.json');assert len(recs)==6 and all(r['resume_verified']for r in recs)
    assert manifest['parse_finished_monotonic_ns']<int(recs[-1]['started_monotonic']*1e9)<int(recs[-1]['finished_monotonic']*1e9)<ackresult['finished_monotonic_ns']
    serial=take(GUEST/'serial.log');marker=f'STAF EXPORT_ACK version=1 entries={len(parsed)} bytes={content} wire_sha256={sha(wire)} manifest_sha256={sha(take(GUEST/"guest-artifacts/manifest.json"))}'.encode()
    assert serial.count(marker)==1 and serial.index(marker)<serial.index(b'STABILITY_EXPORT_EXIT status=0')<serial.index(b'reboot: Power down')
    for mark in (b'STABILITY_CONTROLLER_EXIT status=0',b'STABILITY_GUEST_FINISH status=0'):assert serial.count(mark)==1 and serial.index(mark)<serial.index(marker)
    for bad in (b'Kernel panic',b'BUG:',b'Oops:',b'WARNING:',b'rcu_preempt detected stalls',b'soft lockup',b'hard LOCKUP'):assert bad not in serial
    assert take(F/'init-status.txt')==take(F/'controller-status.txt')==b'0\n'
    # All final QMP frame records, including final resume, shutdown and owned quit.
    decoded=[];pending={'sent':b'','received':b''}
    for row in read_json(GUEST/'qmp-transcript.json'):
        direction=row['direction'];pending[direction]+=bytes.fromhex(row['raw_hex'])
        while b'\n'in pending[direction]:
            line,pending[direction]=pending[direction].split(b'\n',1)
            if line.strip():decoded.append(dict(direction=direction,monotonic=row['monotonic'],wire=json.loads(line)))
    assert not any(pending.values())
    for rec in recs:
        interval=[e for e in decoded if rec['started_monotonic']<=e['monotonic']<=rec['finished_monotonic']]
        cmds=[e['wire']['execute']for e in interval if e['direction']=='sent']
        assert cmds[0]=='stop' and cmds.count('cont')==1
        assert any(e['wire'].get('return')==dict(status='paused',running=False)for e in interval)
        assert any(e['wire'].get('return')==dict(status='running',running=True)for e in interval)
    shutdown=[e for e in decoded if e['wire'].get('return')==dict(status='shutdown',running=False)];quitcmd=[e for e in decoded if e['direction']=='sent'and e['wire']['execute']=='quit']
    assert len(shutdown)==len(quitcmd)==1 and shutdown[0]['monotonic']<quitcmd[0]['monotonic']<original['launch_monotonic']+300
    assert ackresult['finished_monotonic_ns']<int(shutdown[0]['monotonic']*1e9)
    parent=read_json(WORK/'stability-transport-fault-run-20260913-prepublish-hard-6/record.json');collection=parent['collection']
    assert parent['status']=='COLLECTED_REQUIRES_INDEPENDENT_FAULT_REVIEW' and collection['status']=='COMPLETED' and collection['raw_wait_status']==0 and collection['cleanup_complete'] and collection['descendant_records_omitted']==0
    for stream in collection['streams'].values():
        assert stream['eof'] and not stream['truncated'] and stream['discarded_observed_bytes']==0
        assert len(bound(stream['artifact']))==stream['bytes_observed']==stream['bytes_retained']
    result.update(status='MATCH_RETAINED_RUNTIME_PROTOCOL_AND_OWNERSHIP',selected=key,linux_worker_tid=tid,native_ret_errno=ret['errno'],native_ret_elapsed_ns=ret['elapsed_ns'],terminal_boundary_ns=boundary['monotonic_ns'],terminal_plus_five_interval_ns=pp['snapshots'][3]['begin']['mono_ns']-pp['snapshots'][2]['end']['mono_ns'],normal_launcher_raw_wait=0,linux_reference_raw_wait=9472,admission_errno=5,export_entries=42,export_bytes=content,export_exact_wire_sha256=sha(wire),phase_requests=phase_joins,qmp_stop_continue_pairs=6,host_cleanup_complete=True,guest_export_ack_observed=True,source_claim_limits=['Guest exporter marker is source-bound acknowledgment receipt; fsync execution is established by exact successful receiver path, not a separate syscall trace.','Launcher raw exit0 does not prove guest payload completion; terminal payload remains quarantined.','No physical AcceptedReturn snapshot claimed; original hard-mode contract requires BlockedRead and retained Terminal/+5 bytes, all present. Recovery-only eight HELLO and physically full ring remain separate.'],reviewed_inputs=rows)
except BaseException as error:
    result.update(status='REVIEW_FAILED',error_type=type(error).__name__,error=str(error),reviewed_inputs=rows)
    raise
finally:
    (ROOT/'review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(status=result['status'],root=str(ROOT),inputs=len(rows))))
