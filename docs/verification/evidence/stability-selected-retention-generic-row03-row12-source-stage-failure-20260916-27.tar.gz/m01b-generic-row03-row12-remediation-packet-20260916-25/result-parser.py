import json
def parse(p):
 with open(p,encoding='utf8') as f:r=json.load(f)
 assert r['row03']['publish']=='Err(-11)' and r['row12']['publish']=='Ok(true)'
