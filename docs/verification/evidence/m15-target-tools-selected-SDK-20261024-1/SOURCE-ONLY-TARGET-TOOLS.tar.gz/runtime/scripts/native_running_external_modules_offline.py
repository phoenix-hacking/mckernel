"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Selected SDK source/default tool compiler operation using accepted h990 ownership.
No device/CLI execution, Rust library rebuild, root action, or native credit.
"""
from pathlib import Path
import ast,hashlib,json,os,re,resource,signal,stat,sys,time
entered=time.monotonic()
CONFIG=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/TARGET-DRIVER.COMPLETED-INPUTS.json')
CONFIG_SHA='c14a3829aa8ff66c55097f2f235c6b0071e5de99f0ae5f9686939b67079c3050'
TOOL_RULES={'/nightly/bin/rustc': ('readonly-mounted-nightly', '70ebcbbaa352a2d0ef5401eea226b0e61320840430b5c15ad016fb3dc8b54e09'), '/usr/bin/cc': ('readonly-image', '2092e32fa9abee9ccbf777a5f893b9cc608582b660c93e742a17c3eb7da109c2'), '/usr/include/bfd.h': ('readonly-image', 'de900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432'), '/usr/lib64/libbfd.so': ('readonly-image', '6cfd31804974c248c9512879e7b77a94862f92150c2171d901140464ea936ab3'), '/usr/bin/cmake': ('readonly-image', 'a2ec9c59d15b48b6abba45cfaa873df186e01a2e3ca99302ada1e51637f4cfd1'), '/usr/bin/nm': ('readonly-image', 'df99ae7b36cf9aa2da1e447026082ae5faddb7d7f12ebce911503c3022ed4bf1'), '/usr/bin/readelf': ('readonly-image', 'c5e0de5f419ed907fdc0b7b0a6087ff5c54a8c68db4da01097bdf84a296349b7')}
D=Path('/work/output/whole70-target-captures')
def need(ok, why):
    if not ok: raise RuntimeError(why)

def digest(p):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_nlink==1,'regular singlelink source')
        value=hashlib.sha256();size=0
        for block in iter(lambda:os.read(fd,65536),b''):
            size+=len(block);need(size<=32<<20,'bounded input hash');value.update(block)
        last=os.fstat(fd);path=p.lstat()
        fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        need(size==last.st_size and all(getattr(first,k)==getattr(last,k)==getattr(path,k) for k in fields),'stable input FD')
        return value.hexdigest()
    finally:os.close(fd)

def tool_digest(alias):
    target=None; first_metadata=None; final_metadata=None; path_metadata=None; fd=None
    try:
        need(alias in TOOL_RULES, 'fixed tool alias required')
        tool_class,expected=TOOL_RULES[alias]
        target=Path(alias).resolve(strict=True)
        fd=os.open(target,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        first=os.fstat(fd)
        first_metadata={k:getattr(first,k) for k in fields}
        need(stat.S_ISREG(first.st_mode) and
             (first.st_nlink==1 if tool_class=='readonly-mounted-nightly' else first.st_nlink>=1),
             'fixed tool regular/link policy')
        value=hashlib.sha256();size=0
        for block in iter(lambda:os.read(fd,65536),b''):
            size+=len(block);need(size<=32<<20,'bounded tool hash');value.update(block)
        last=os.fstat(fd);path=target.lstat()
        final_metadata={k:getattr(last,k) for k in fields}
        path_metadata={k:getattr(path,k) for k in fields}
        need(size==last.st_size and first_metadata==final_metadata==path_metadata,
             'stable fixed tool FD/path metadata')
        need(Path(alias).resolve(strict=True)==target,'fixed tool alias retargeted')
        digest_value=value.hexdigest();need(digest_value==expected,'exact pinned tool hash')
        return dict(alias=alias,tool_class=tool_class,resolved_path=str(target),sha256=digest_value,
                    first_metadata=first_metadata,final_metadata=final_metadata,path_metadata=path_metadata)
    except Exception as exc:
        raise RuntimeError('fixed tool alias='+str(alias)+' target='+str(target)+
                           ' first='+repr(first_metadata)+' final='+repr(final_metadata)+
                           ' path='+repr(path_metadata)+': '+str(exc)) from exc
    finally:
        if fd is not None:os.close(fd)

def retained_archive_snapshot(path):
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);last=os.fstat(fd);named=path.lstat()
        fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
        need(stat.S_ISREG(first.st_mode) and first.st_nlink==1 and
             all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in fields),'stable retained archive FD metadata')
        return dict(device=first.st_dev,inode=first.st_ino,mode=oct(stat.S_IMODE(first.st_mode)),
                    nlink=first.st_nlink,uid=first.st_uid,gid=first.st_gid,size=first.st_size,
                    mtime_ns=first.st_mtime_ns,ctime_ns=first.st_ctime_ns)
    finally:os.close(fd)

def positive(r):
 return r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and r['error'] is None and r['retirement_error'] is None and not r['timed_out']
def main():
 need(CONFIG_SHA is not None,'root must bind exact fresh materialization and independent SDK DSO authority')
 need(digest(CONFIG)==CONFIG_SHA,'exact input packet');p=json.loads(CONFIG.read_bytes())
 need(p['actual_independent_DSO_acceptance'] is not None and p['actual_fresh_materialized_source'] is not None,'genuine DSO/materialization prerequisites')
 for row in p['source_inputs']+p['accepted_input_records']:
  need(Path(row['path']).stat().st_size==row['bytes'] and digest(row['path'])==row['sha256'],'source/authority pin')
 verdict=json.loads(Path(p['actual_independent_DSO_acceptance']['path']).read_bytes())
 need(verdict['decision']=='PASS_ACTUAL_SDK_LIBRARY_RETAINED10_PLUS_FIVE_SUFFIX' and verdict['DSO_sha256']=='546dbe7604e8911e36ae9c10f07dee0dc279ae88d1d4584a0da5d1232be6db6e' and verdict['function_providers']==70 and verdict['data_providers']==6 and verdict['implementation_ownership'] is False,'exact independent SDK DSO verdict')
 materialized=p['actual_fresh_materialized_source'];need(materialized['sha256'] is not None and materialized['bytes'] is not None,'root must bind actual source copy result')
 need(digest(materialized['path'])==materialized['sha256'],'actual materialized source result pin')
 materialization=json.loads(Path(materialized['path']).read_bytes());need(materialization['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and materialization['source_root']=='/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/source-materialization-1/materialized-source','exact actual target source namespace')
 need(os.getuid()==os.getgid()==1000 and os.sched_getaffinity(0)=={2,3,4,5},'reviewed SDK UID/CPUs')
 need(p['target_tools']=={k:v[1] for k,v in TOOL_RULES.items()},'fixed tool aliases')
 before={k:tool_digest(k) for k in TOOL_RULES}
 archive=retained_archive_snapshot(p['retained_archive']['container_path']);need(archive==p['retained_archive']['expected_metadata'],'retained actual Rust archive stat')
 plan=json.loads(Path(p['operation']['path']).read_bytes());need(digest(p['operation']['path'])==p['operation']['sha256'],'exact operation')
 h=p['capture_helper'];need(digest(h['path'])==h['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8','h990')
 names={'need','write','hashed','stop','members','process_start','terminal_unreaped','wait_terminal','owned_capture'};assign={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
 nodes=[n for n in ast.parse(Path(h['path']).read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assign for t in n.targets)]
 ns={'__file__':h['path']};exec(compile(ast.Module(body=nodes,type_ignores=[]),h['path'],'exec'),ns)
 def budget():
  a=resource.getrusage(resource.RUSAGE_SELF);b=resource.getrusage(resource.RUSAGE_CHILDREN)
  need(a.ru_utime+a.ru_stime+b.ru_utime+b.ru_stime<=60,'whole CPU acceptance60')
  need(time.monotonic()-entered<90,'whole active wall90')
  need(sum(q.stat().st_size for q in Path('/work').rglob('*') if q.is_file())<=512<<20,'existing aggregate512MiB')
 def limits():
  for k,v in ((resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)):resource.setrlimit(k,(v,v))
  os.sched_setaffinity(0,{2,3,4,5})
 need(not D.exists() and not Path('/work/evidence').exists(),'fresh captures/evidence');Path('/work/output').mkdir(mode=0o700);D.mkdir(mode=0o700);Path('/work/output/tool-cohort').mkdir(mode=0o700);Path('/work/evidence').mkdir(mode=0o700);os.chdir(D)
 for s in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(s,ns['stop'])
 rows=[];artifacts={};receipt=dict(schema='mckernel.sdk-target-default-tools-receipt.v1',status='FAIL',commands=rows,artifacts=artifacts,native=False,default_acceptance=False,CLI_executed=False,C_library_TU=False,source_identity='269e4dea72a4bb862619f06d4e29c5cbcd5e4b9b854088c8f420da598cf520cd',configuration_sha256=CONFIG_SHA)
 budget();signal.setitimer(signal.ITIMER_REAL,90-(time.monotonic()-entered))
 try:
  for item in plan['commands']:
   budget();q=D/('%02d'%item['index']);q.mkdir(mode=0o700)
   cmd=dict(argv=item['argv'],purpose=item['purpose']);ns['write'](q/'command.json',cmd)
   remaining=90-(time.monotonic()-entered);need(remaining>0,'shared90 deadline before phase launch')
   result=ns['owned_capture'](cmd,q,remaining,limits)
   rows.append(dict(command=item,result=result));ns['write'](q/'RESULT.json',rows[-1]);budget()
   need(positive(result),'first target command failure STOP')
   if item['index']==0:need((q/'stdout').read_text().startswith('rustc 1.95.0-nightly (c04308580 2026-02-18)'),'actual pinned target compiler version')
   if item['index']==1:
    guard=plan['cache_guard'];need(digest(guard['path'])==guard['sha256'],'cache/config guard source')
    scope={'__name__':'target_config_guard'};exec(compile(Path(guard['path']).read_bytes(),guard['path'],'exec'),scope)
    old_argv=sys.argv;sys.argv=[guard['path'],'--qualify-config-only']
    try:scope['main']()
    finally:sys.argv=old_argv
   # Durable outputs are recorded immediately after each genuine target producer.
   produced={2:['ihk/linux/user/libihk.so'],3:['ihk/linux/user/rust/ihkconfig.o','ihk/linux/user/ihkconfig'],4:['ihk/linux/user/rust/ihkosctl.o','ihk/linux/user/ihkosctl'],5:['executer/user/rust/mcps.o','executer/user/mcps']}
   for rel in produced.get(item['index'],[]):
    path=Path('/work/output/whole70-tool-default')/rel;artifacts[str(path)]=ns['hashed'](path,32<<20)
   if item['index'] in produced:ns['write'](q/'DURABLE-ARTIFACTS.json',artifacts)
  observed={};text=(D/'07/stdout').read_text().splitlines()
  for name in p['functions']+p['data']:
   hits=[line.split() for line in text if line.split()[-1:]==[name]];need(len(hits)==1,'unique whole-library root '+name);kind=hits[0][-2]
   need(kind=='T' if name in p['functions'] else kind in 'BDRSG','real whole-library provider '+name);observed[name]=kind
  undefined=(D/'08/stdout').read_text().split();need(not any(name in undefined for name in p['functions']+p['data']+['rust_eh_personality','rust_begin_unwind']),'unresolved library provider')
  expected=json.loads(Path(p['expected_compiled_callers']['path']).read_bytes())['callers'];need(digest(p['expected_compiled_callers']['path'])==p['expected_compiled_callers']['sha256'],'actual caller contract')
  current=None;imports={k:[] for k in ('ihkconfig','ihkosctl','mcps')}
  for line in (D/'09/stdout').read_text().splitlines():
   if line.endswith('.o:'):
    found=[name for name in imports if line.endswith('/'+name+'.o:')];need(len(found)==1,'exact caller object label');current=found[0]
   elif line.split() and current:
    name=line.split()[-1]
    if name.startswith(('ihk_','ihklib_','cpu_str','cpu_req','mem_str','mem_req','ikc_')):imports[current].append(name)
  for name in imports:need(sorted(imports[name])==sorted(expected[name]['project_imports']),'actual target CLI imports '+name)
  dynamic=(D/'10/stdout').read_text();need(dynamic.count('Shared library: [libihk.so]')==2,'ihkconfig/ihkosctl genuine DSO linkage')
  for name in ('ihklib.c','ihklib.remaining.c','ihkconfig.c','ihkosctl.c'):
   for rel in ('ihk/linux/user/CMakeFiles/ihklib.dir/build.make','ihk/linux/user/CMakeFiles/ihkconfig.dir/build.make','ihk/linux/user/CMakeFiles/ihkosctl.dir/build.make'):
    need(name not in (Path('/work/output/whole70-tool-default')/rel).read_text(),'forbidden selected project C source '+name)
  after={k:tool_digest(k) for k in TOOL_RULES};need(after==before,'same actual tool inputs after build')
  need(retained_archive_snapshot(p['retained_archive']['container_path'])==archive,'retained archive unchanged')
  for row in p['source_inputs']:need(digest(row['path'])==row['sha256'],'source postflight')
  budget();receipt.update(status='PASS_SELECTED_SDK_TARGET_TOOLS_CMAKE_ABI_LINK_ONLY',whole_library_roots=observed,project_imports=imports,tool_preflight=before,tool_postflight=after,archive_stat_stable=True)
 except BaseException as exc:
  receipt['error']=str(exc);raise
 finally:
  ns['write'](Path('/work/evidence/receipt.json'),receipt);signal.setitimer(signal.ITIMER_REAL,0)
if __name__=='__main__':main()
