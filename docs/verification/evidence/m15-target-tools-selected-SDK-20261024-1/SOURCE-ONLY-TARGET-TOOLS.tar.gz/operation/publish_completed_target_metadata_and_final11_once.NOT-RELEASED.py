"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One ordinary UID1000 metadata publication: exclusive empty HOST candidate and
exact completed request/11-source map. No owner import/API/query/release execution.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,uuid
D=Path(__file__).resolve().parent
REQUEST={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/REQUEST.COMPLETE-SOURCE.NAMESPACE-TO-BE-CREATED.json', 'sha256': 'f996a23fbdcf76e53a29869d1786057ecf55dc88084520cf1fe34bbb67f1e39b', 'bytes': 2699}
RELEASE={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/RELEASE.COMPLETE-SOURCE.NO-CLOCK-NO-APPROVAL.json', 'sha256': '26b04096d137ef1b9b8739e259b1c864ae6fbaa4fbe1b61816199545ea499211', 'bytes': 4525}
OWNER={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/target_tools_sdk_owner.COMPLETED.py', 'sha256': '5838bd8686148a5be2c73d6047d78be9464d0cdfcf3f45925250a8a41b2b4d83', 'bytes': 94035}
DRIVER={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/target_tools_sdk_driver.COMPLETED.py', 'sha256': '62b74b931729426a0742a3874feec857eb5a0d6a4e52c38c6c810257f222cfa8', 'bytes': 13841}
MATERIAL={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/source-materialization-1/MATERIALIZATION-RESULT.json', 'sha256': '6e60ae59f0b3a5fa87bc612380dae7788c1756c386d7669c3331f428c1263b0b', 'bytes': 3542}
PROOF={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/COMPLETE-RUNTIME-READ-PATH-AND-MOUNT-JOIN.SOURCE-PROOF.json', 'sha256': '3de3bf0e56b118aa8466f758d7cdba3a02c8d4f0919c8d385ae71cb83a9cd45b', 'bytes': 90511}

PREPARATION={'bytes': 34522, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/preparation.COMPLETED.json', 'sha256': '9c09e0e56faab5afbec5184448df194ea2461b6be3d2df692f82171ebd56f1ed'}
CONFIGURATION={'bytes': 28024, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/TARGET-DRIVER.COMPLETED-INPUTS.json', 'sha256': 'c14a3829aa8ff66c55097f2f235c6b0071e5de99f0ae5f9686939b67079c3050'}

def need(ok,message):
 if not ok:raise ValueError(message)
def read(ref):
 p=Path(ref['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=32<<20,'bounded regular input');blocks=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   blocks.append(b)
  raw=b''.join(blocks);z=os.fstat(fd);n=p.lstat();keys=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(a,k)==getattr(z,k)==getattr(n,k) for k in keys) and len(raw)==z.st_size and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'stable9 pinned input');return raw
 finally:os.close(fd)
def node(path):
 p=Path(path);need(p.is_dir() and not p.is_symlink(),'owned directory');s=p.stat();need(s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700,'private directory identity');return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
def publish(path,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 parent=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(parent)
 finally:os.close(parent)
 return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def main():
 need(sys.argv[1:]==['--publish-metadata-once'] and os.getuid()==os.geteuid()==os.getgid()==1000,'exact ordinary UID1000 metadata invocation')
 request=json.loads(read(REQUEST));release=json.loads(read(RELEASE));read(OWNER);read(DRIVER);read(PREPARATION);read(CONFIGURATION);material=json.loads(read(MATERIAL));proof=json.loads(read(PROOF));need(proof['missing']==[],'complete static read-path join')
 need(material['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and node(material['source_root'])==material['source_identity'],'actual materialized source identity')
 need(not (D/'workspace').exists() and not (D/'REQUEST.ROOT.FINAL.json').exists(),'fresh finite namespace/publication')
 nonce=uuid.uuid4().hex;parent=D/'workspace';parent.mkdir(mode=0o700);candidate=parent/('native-running-modules-candidate-'+nonce);candidate.mkdir(mode=0o700);evidence=parent/('native-running-modules-owner-'+nonce)
 request.update(nonce=nonce,candidate_root=str(candidate),candidate_identity=node(candidate),owner_evidence_root=str(evidence),input_root=str(D),input_identity=node(D),output_parent_identity=node(parent))
 need(request['request_path']==str(D/'REQUEST.ROOT.FINAL.json') and not evidence.exists() and list(candidate.iterdir())==[],'exact nonce-bound request/freshness')
 rq=publish(D/'REQUEST.ROOT.FINAL.json',request);release.update(nonce=nonce,request=dict(path=rq['path'],sha256=rq['sha256']),status='PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW')
 rl=publish(D/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json',release)
 finalmap=publish(D/'ACTUAL-FINAL-ELEVEN-SOURCE-MAP.json',dict(source_sha256=release['source_sha256'],owner=OWNER,driver=DRIVER,preparation=PREPARATION,configuration=CONFIGURATION,request=rq,nonce=nonce,source_materialization=MATERIAL,execution_release=False))
 result=dict(status='PASS_EXCLUSIVE_TARGET_METADATA_NAMESPACE_AND_REQUEST_ONLY',request=rq,release_pending=rl,final_eleven_source_map=finalmap,nonce=nonce,owner=OWNER,driver=DRIVER,source_sha256=release['source_sha256'],candidate_identity=node(candidate),output_parent_identity=node(parent),input_identity=node(D),actual_source_materialization=MATERIAL,read_path_proof=PROOF,execution_release=False)
 rr=publish(D/'ACTUAL-METADATA-PUBLICATION-RECEIPT.json',result);print(json.dumps(dict(receipt=rr,**result),sort_keys=True))
if __name__=='__main__':main()
