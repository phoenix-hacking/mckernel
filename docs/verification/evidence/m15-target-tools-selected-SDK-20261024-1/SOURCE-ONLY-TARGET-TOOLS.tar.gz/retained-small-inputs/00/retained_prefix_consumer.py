"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure interpretation of one retained successful first10 compiler prefix.
The original overall FAIL remains FAIL; no future compiler-warning allowance.
"""
import hashlib,re,posixpath
DIAGNOSTIC_SHA='651f3d0eb160f660cd5f8b366becaf0248a7bf161c917122dfa70712b4e46782'
DIAGNOSTIC_BYTES=3384
NATIVE_FLAGS=['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc']
ARCHIVE='/work/sdk70-selected-successor-1/libihklib_whole70.a'
WARNING_SOURCES={
 'abort':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/held-OS-provider-composition-source-1/accepted_host_root.assigned_memory_dependency_join.rs',22,8,'ccbf20b1a1a0d303b34e123adcbdf8e125773d26f2f9d8883c96d0a41ccc9f8b'),
 'EINVAL':('constant','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',5,7,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
 'is':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',39,11,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
 'strcmp':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',26,5,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
 'strdup':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',27,5,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
 'strsep':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',28,5,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
 'strtol':('function','/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs',29,5,'75d8fa2c77104a2f119aff0c5ee60da23089e06003b56f67b7fd79d2469e6601'),
}
def need(ok,why):
    if not ok:raise ValueError(why)
def diagnostics(raw,source_map):
    need(len(raw)==DIAGNOSTIC_BYTES and hashlib.sha256(raw).hexdigest()==DIAGNOSTIC_SHA,'exact retained compiler diagnostics only')
    text=raw.decode('utf-8')
    starts=list(re.finditer(r'^warning: (function|constant) `([^`]+)` is never used$',text,re.M))
    need([m.group(2) for m in starts]==list(WARNING_SOURCES),'exact seven named warnings')
    result=[]
    for i,m in enumerate(starts):
        end=starts[i+1].start() if i+1<len(starts) else len(text)
        location=re.search(r'^\s*--> (.+):([0-9]+):([0-9]+)$',text[m.end():end],re.M)
        need(location is not None,'retained warning location')
        kind,path,line,column,pin=WARNING_SOURCES[m.group(2)]
        need(m.group(1)==kind and posixpath.normpath(location.group(1))==path and
             int(location.group(2))==line and int(location.group(3))==column and source_map.get(path)==pin,
             'warning exact source/line/hash join')
        result.append(dict(kind=kind,name=m.group(2),source=path,line=line,column=column,source_sha256=pin))
    flags=re.findall(r'^note: native-static-libs: (.+)$',text,re.M)
    need(flags==[' '.join(NATIVE_FLAGS)],'exact actual compiler native flags/order')
    need(text.count('warning: 7 warnings emitted')==1,'exact warning summary')
    return dict(status='QUALIFIED_EXACT_RETAINED_DEAD_CODE_DIAGNOSTICS_ONLY',warnings=result,
                native_static_libs=list(NATIVE_FLAGS),diagnostic_sha256=DIAGNOSTIC_SHA,
                diagnostic_bytes=DIAGNOSTIC_BYTES,future_warning_allowance=False)
def positive(r):
    return r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and not r['timed_out'] and r['error'] is None and r['retirement_error'] is None and r['remaining_group_members']==[] and r['unexpected_group_members']==[]
def interpret_prefix(receipt,prep,commands,streams,archive_snapshot):
    need(receipt['schema']=='mckernel.sdk-library-driver-receipt.v1' and receipt['status']=='FAIL' and
         receipt['error']=='unexpected compiler diagnostic','preserved exact overall driver failure')
    source_map={r['path']:r['sha256'] for r in prep['closure']}
    need(len(source_map)==57 and receipt['source_sha256']==source_map and receipt['source_identity']==prep['source_identity'],'exact57 producer source closure')
    rows=receipt['commands'];need(len(rows)==len(streams)==10 and len(commands)==15,'first10 actual only')
    for i,(row,stream) in enumerate(zip(rows,streams)):
        argv=list(commands[i]['argv'])
        if commands[i].get('late_stat_cfg'):
            argv=[prep['root_stat_cfg'] if a=='ACTUAL_STAT_CFG_FROM_SUCCESSFUL_SELECTED_HEADER_WITNESS' else a for a in argv]
        need(row['index']==i and row['label']==commands[i]['label'] and row['actual_argv']==argv and positive(row['result']),'exact positive prefix command '+str(i))
        for name in ('stdout','stderr'):
            raw=stream[name];saved=row['result']['captures'][name]
            need(len(raw)==saved['size'] and hashlib.sha256(raw).hexdigest()==saved['sha256'],'actual saved stream '+str(i)+name)
        if i!=9:need(stream['stderr']==b'','unchanged no-stderr prefix oracle')
    need(streams[8]['stdout']==b'ihklib_stat_abi_stat\n','actual platform witness')
    classified=diagnostics(streams[9]['stderr'],source_map)
    artifact=receipt['artifacts'][ARCHIVE]
    need(artifact['sha256']=='a7fec08c64f07fb4da00ca8038bfe50f21801ccc8a5039ee8dd4243a78be1e0f' and artifact['size']==21932706,'actual retained archive producer identity')
    for field in ('device','inode','mode','nlink','uid','gid','size','mtime_ns','ctime_ns'):
        need(archive_snapshot[field]==artifact[field],'retained archive stable metadata '+field)
    need(artifact['nlink']==1 and artifact['uid']==artifact['gid']==1000,'producer archive owned singlelink')
    need(receipt['native_credit'] is False and receipt['default_credit'] is False and receipt['CLI_executed'] is False and receipt['C_runtime_TU'] is False,'preserved qualification scope')
    return dict(status='QUALIFIED_RETAINED_FIRST10_ONLY_SDK_LINK_PENDING',original_driver_status='FAIL',
                original_driver_error=receipt['error'],diagnostics=classified,archive=artifact,
                first10_commands=rows,platform_cfg=prep['root_stat_cfg'],source_sha256=source_map,
                native_static_libs=classified['native_static_libs'],new_command_count=5,
                archive_rehashed=False,compiler_reexecuted=False,full_SDK_library_acceptance=False)
