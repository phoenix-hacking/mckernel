/* Compile-only metadata witness, never a production runtime object.
 * Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Use complete pinned target headers and the target's real include/config flags.
 * Do not replace headers with extracted structs or minimal fixture headers.
 */
#define _GNU_SOURCE
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/stat.h>
#include <ihk/ihklib.h>
#include <ihk/ihk_host_user.h>
#include <ihk/ihklib_private.h>

_Static_assert(sizeof(void *) == 8, "selected userspace pointer width");
_Static_assert(sizeof(int) == 4 && sizeof(long) == 8, "selected userspace LP64");
_Static_assert(sizeof(struct ihk_cpu_req) == 16, "CPU request size");
_Static_assert(_Alignof(struct ihk_cpu_req) == 8, "CPU request alignment");
_Static_assert(offsetof(struct ihk_cpu_req, num_cpus) == 8, "CPU count offset");
_Static_assert(sizeof(struct ihk_mem_req) == 32, "memory request size");
_Static_assert(offsetof(struct ihk_mem_req, num_chunks) == 16, "memory count offset");
_Static_assert(offsetof(struct ihk_mem_req, timeout) == 28, "memory timeout offset");
_Static_assert(sizeof(struct ihk_mem_chunk) == 16, "public memory chunk size");
_Static_assert(offsetof(struct ihk_mem_chunk, numa_node_number) == 8, "NUMA node offset");
_Static_assert(sizeof(struct ihk_ikc_req) == 24, "IKC request size");
_Static_assert(offsetof(struct ihk_ikc_req, num_cpus) == 16, "IKC count offset");
_Static_assert(sizeof(struct option) == 32, "getopt option size");
_Static_assert(offsetof(struct option, val) == 24, "getopt value offset");
_Static_assert(IHK_OS_STATUS == 0x112a14, "status request");
_Static_assert(IHK_OS_READ_KMSG == 0x112a20, "kmsg request");
_Static_assert(sizeof(struct ihklib_reserve_mem_conf) == 24, "remaining configuration provider size");
_Static_assert(sizeof(struct stat) == 144 && _Alignof(struct stat) == 8,
               "sysfs Rust successor needs exact selected libc storage");

/* Including ihklib_private.h defines ihklib_os_query_mem_type_str. Compile this
 * witness alone. Never link it into a library/CLI or alongside another TU that
 * includes that definition. The existing eventfd owner retains the real failure
 * and owns its separate header-context/link successor.
 */
