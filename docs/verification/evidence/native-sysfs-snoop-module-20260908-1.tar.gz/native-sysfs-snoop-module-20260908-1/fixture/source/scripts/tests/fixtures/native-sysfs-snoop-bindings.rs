mod memory_fixture {
use kernel::prelude::*;
use super::smp_resource::{MemoryExtent,MemoryMap};
const MAX_EXTENTS: usize=8;
pub(crate) const IDENTITY_WINDOW_END: u64 = 256 << 30;
trait GuestExtents {
    fn len(&self) -> usize;
    fn extent(&self, index: usize) -> Option<MemoryExtent>;
}
impl<const N: usize> GuestExtents for MemoryMap<N> {
    fn len(&self) -> usize {
        MemoryMap::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        MemoryMap::extent(self, index)
    }
}
impl GuestExtents for [MemoryExtent] {
    fn len(&self) -> usize {
        <[MemoryExtent]>::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        self.get(index).copied()
    }
}
fn checked_guest_bytes(
    map: &(impl GuestExtents + ?Sized),
    owner: super::smp_resource::OsToken,
    direct_map: u64,
    physical: u64,
    bytes: usize,
) -> Result<*mut u8> {
    let end = physical.checked_add(bytes as u64).ok_or(EINVAL)?;
    if physical == 0 || bytes == 0 || end > IDENTITY_WINDOW_END {
        return Err(EINVAL);
    }
    direct_map.checked_add(end - 1).ok_or(EINVAL)?;
    for index in 0..map.len() {
        let extent = map.extent(index).ok_or(EIO)?;
        if extent.owner() == Some(owner)
            && extent.start() <= physical
            && end <= extent.end().map_err(|_| EIO)?
        {
            return Ok(direct_map.checked_add(physical).ok_or(EINVAL)? as *mut u8);
        }
    }
    Err(EINVAL)
}
pub(crate) mod service {
use kernel::prelude::*;
use super::super::smp_resource::OsToken;
const METADATA_CAPACITY: usize=64;
fn errno(code:i32)->Error{kernel::error::to_result(code).err().unwrap_or(EIO)}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct AcceptSuccess {
    pub(crate) receive_queue: u64,
    pub(crate) accepted_channel_cookie: u64,
}
#[allow(dead_code)]
#[path = "/work/native-sysfs-snoop-module-20260908-1/fixture/source/host-kernel/native-rust/abi/sysfs_request.rs"] mod wire;
#[allow(dead_code)]
#[path = "/work/native-sysfs-snoop-module-20260908-1/fixture/source/host-kernel/native-rust/sysfs_memory.rs"] mod memory;
#[allow(dead_code)]
#[path = "/work/native-sysfs-snoop-module-20260908-1/fixture/source/host-kernel/native-rust/sysfs_snoop.rs"] mod snoop;
#[path = "/work/native-sysfs-snoop-module-20260908-1/fixture/source/scripts/tests/fixtures/mckernel_native_snoop_checks.rs"] pub(crate) mod checks;
}}
