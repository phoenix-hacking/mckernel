/work/native-sysfs-snoop-module-20260908-1/fixture/source/scripts/tests/fixtures/mckernel_sysfs_snoop_oracle.o
