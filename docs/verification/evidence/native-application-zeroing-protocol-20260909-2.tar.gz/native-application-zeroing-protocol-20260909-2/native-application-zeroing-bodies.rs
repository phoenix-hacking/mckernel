const PAGE_SHIFT: CULong = 12;
const SCD_MSG_SYSCALL_ONESIDE: CInt = 0x4;
const NR_MOVE_PAGES: CULong = 279;
#[repr(C)]
#[derive(Clone, Copy)]
pub struct RbNode {
    pub(crate) __rb_parent_color: CULong,
    pub(crate) rb_right: *mut RbNode,
    pub(crate) rb_left: *mut RbNode,
}
#[repr(C)]
pub struct RbRoot {
    pub(crate) rb_node: *mut RbNode,
}
#[repr(C)]
#[derive(Clone, Copy)]
struct LListNode {
    next: *mut LListNode,
}
#[repr(C)]
struct LListHead {
    first: *mut LListNode,
}
#[repr(C)]
struct ListHead {
    next: *mut ListHead,
    prev: *mut ListHead,
}
#[repr(C)]
struct IhkAtomic {
    counter: CInt,
}
#[repr(C, align(64))]
struct McsLockNode {
    locked: CULong,
    next: *mut McsLockNode,
    irqsave: CULong,
}
#[repr(C)]
pub(crate) struct FreeChunk {
    addr: CULong,
    size: CULong,
    node: RbNode,
    list: LListNode,
}
#[repr(C, align(64))]
pub(crate) struct IhkMcNumaNode {
    id: CInt,
    linux_numa_id: CInt,
    node_type: CInt,
    allocators: ListHead,
    nodes_by_distance: *mut c_void,
    zeroing_workers: IhkAtomic,
    nr_to_zero_pages: IhkAtomic,
    zeroed_list: LListHead,
    to_zero_list: LListHead,
    free_chunks: RbRoot,
    lock: McsLockNode,
    nr_pages: CULong,
    nr_free_pages: CULong,
    min_addr: CULong,
    max_addr: CULong,
}
unsafe fn list_to_chunk(node: *mut LListNode) -> *mut FreeChunk {
    (node.cast::<u8>())
        .sub(offset_of!(FreeChunk, list))
        .cast::<FreeChunk>()
}
unsafe fn chunk_list(chunk: *mut FreeChunk) -> *mut LListNode {
    &raw mut (*chunk).list
}
unsafe fn llist_head_first(head: *mut LListHead) -> &'static AtomicPtr<LListNode> {
    AtomicPtr::from_ptr(&raw mut (*head).first)
}
unsafe fn llist_add(node: *mut LListNode, head: *mut LListHead) {
    let first_slot = llist_head_first(head);
    let mut first = first_slot.load(Ordering::Acquire);

    loop {
        (*node).next = first;
        match first_slot.compare_exchange(first, node, Ordering::SeqCst, Ordering::SeqCst) {
            Ok(_) => return,
            Err(actual) => first = actual,
        }
    }
}
unsafe fn llist_del_first(head: *mut LListHead) -> *mut LListNode {
    let first_slot = llist_head_first(head);
    let mut entry = first_slot.load(Ordering::Acquire);

    loop {
        if entry.is_null() {
            return null_mut();
        }

        let old_entry = entry;
        let next = read_volatile(&(*entry).next);
        match first_slot.compare_exchange(old_entry, next, Ordering::SeqCst, Ordering::SeqCst) {
            Ok(_) => return old_entry,
            Err(actual) => entry = actual,
        }
    }
}
unsafe fn atomic_counter(atomic: *mut IhkAtomic) -> &'static AtomicI32 {
    AtomicI32::from_ptr(&raw mut (*atomic).counter)
}
unsafe fn ihk_atomic_sub(value: CInt, atomic: *mut IhkAtomic) {
    atomic_counter(atomic).fetch_sub(value, Ordering::SeqCst);
}
unsafe fn zero_phys_range(addr: CULong, size: CULong) {
    let ptr = phys_to_virt(addr);
    let words = (size as usize) / size_of::<CULong>();
    let bytes = (size as usize) % size_of::<CULong>();
    let word_ptr = ptr.cast::<CULong>();
    let byte_ptr = ptr.cast::<u8>().add(words * size_of::<CULong>());
    let mut i = 0usize;

    while i < words {
        write_volatile(word_ptr.add(i), 0);
        i += 1;
    }

    i = 0;
    while i < bytes {
        write_volatile(byte_ptr.add(i), 0);
        i += 1;
    }
}
#[cfg(native_linux_irq_work_v6_12)]
unsafe fn native_zero_free_pages_node(node: *mut IhkMcNumaNode, nr_pages: CInt) -> CInt {
    let pending = &raw mut (*node).to_zero_list;
    let mut cursor = crate::llist::llist_del_all(pending.cast()).cast::<LListNode>();
    let mut skipped_first: *mut LListNode = null_mut();
    let mut skipped_last: *mut LListNode = null_mut();
    let mut zeroed: CInt = 0;
    let requested_size = if nr_pages > 0 {
        (nr_pages as CULong) << PAGE_SHIFT
    } else {
        0
    };

    while !cursor.is_null() {
        let link = cursor;
        cursor = read_volatile(&(*link).next);
        let chunk = list_to_chunk(link);
        let addr = (*chunk).addr;
        let size = (*chunk).size;
        if nr_pages != 0 && size < requested_size {
            if skipped_last.is_null() {
                skipped_first = link;
            } else {
                (*skipped_last).next = link;
            }
            skipped_last = link;
            continue;
        }

        let pages = (size >> PAGE_SHIFT) as CInt;
        if size > size_of::<FreeChunk>() as CULong {
            zero_phys_range(
                addr + size_of::<FreeChunk>() as CULong,
                size - size_of::<FreeChunk>() as CULong,
            );
        }
        llist_add(link, &raw mut (*node).zeroed_list);
        // Publication transfers the chunk immediately. Never read its size or
        // next link again: the allocator can already be reusing that memory.
        compiler_fence(Ordering::SeqCst);
        ihk_atomic_sub(pages, &raw mut (*node).nr_to_zero_pages);
        zeroed = zeroed.wrapping_add(pages);
        if nr_pages != 0 {
            break;
        }
    }

    // Return the unselected private chain in its original order. Concurrent
    // arrivals stay on the shared head; this insertion is one atomic batch.
    let first = if skipped_first.is_null() {
        cursor
    } else {
        (*skipped_last).next = cursor;
        skipped_first
    };
    if !first.is_null() {
        let mut last = first;
        while !(*last).next.is_null() {
            last = (*last).next;
        }
        crate::llist::llist_add_batch(first.cast(), last.cast(), pending.cast());
    }
    zeroed
}
pub unsafe extern "C" fn __ihk_numa_zero_free_pages_node(
    node: *mut IhkMcNumaNode,
    nr_pages: CInt,
) -> CInt {
    if node.is_null() {
        return 0;
    }

    #[cfg(native_linux_irq_work_v6_12)]
    {
        return native_zero_free_pages_node(node, nr_pages);
    }
    #[cfg(not(native_linux_irq_work_v6_12))]
    {
    let mut nr_zeroed_pages: CInt = 0;
    let requested_size = if nr_pages > 0 {
        (nr_pages as CULong) << PAGE_SHIFT
    } else {
        0
    };

    if nr_pages != 0 {
        let mut tmp = LListHead { first: null_mut() };

        loop {
            let llnode = llist_del_first(&raw mut (*node).to_zero_list);
            if llnode.is_null() {
                break;
            }

            let chunk = list_to_chunk(llnode);
            let addr = (*chunk).addr;
            let size = (*chunk).size;

            if size < requested_size {
                llist_add(llnode, &raw mut tmp);
                continue;
            }

            if size > size_of::<FreeChunk>() as CULong {
                zero_phys_range(
                    addr + size_of::<FreeChunk>() as CULong,
                    size - size_of::<FreeChunk>() as CULong,
                );
            }
            llist_add(chunk_list(chunk), &raw mut (*node).zeroed_list);
            compiler_fence(Ordering::SeqCst);
            ihk_atomic_sub(
                (size >> PAGE_SHIFT) as CInt,
                &raw mut (*node).nr_to_zero_pages,
            );
            nr_zeroed_pages = nr_zeroed_pages.wrapping_add(((*chunk).size >> PAGE_SHIFT) as CInt);
            break;
        }

        loop {
            let llnode = llist_del_first(&raw mut tmp);
            if llnode.is_null() {
                break;
            }
            llist_add(llnode, &raw mut (*node).to_zero_list);
        }
    } else {
        loop {
            let llnode = llist_del_first(&raw mut (*node).to_zero_list);
            if llnode.is_null() {
                break;
            }

            let chunk = list_to_chunk(llnode);
            let addr = (*chunk).addr;
            let size = (*chunk).size;

            if size > size_of::<FreeChunk>() as CULong {
                zero_phys_range(
                    addr + size_of::<FreeChunk>() as CULong,
                    size - size_of::<FreeChunk>() as CULong,
                );
            }
            llist_add(chunk_list(chunk), &raw mut (*node).zeroed_list);
            compiler_fence(Ordering::SeqCst);
            ihk_atomic_sub(
                (size >> PAGE_SHIFT) as CInt,
                &raw mut (*node).nr_to_zero_pages,
            );
            nr_zeroed_pages = nr_zeroed_pages.wrapping_add(((*chunk).size >> PAGE_SHIFT) as CInt);
        }
    }

    nr_zeroed_pages
    }
}
pub unsafe extern "C" fn __ihk_numa_zero_request_packet_fill(
    packet: *mut IkcScdPacket,
    node_addr: CULong,
    cpu_ref: CInt,
    pid: CInt,
    syscall_number: CULong,
) {
    if packet.is_null() {
        return;
    }

    let words = packet.cast::<CULong>();
    let mut i = 0usize;
    while i < size_of::<IkcScdPacket>() / size_of::<CULong>() {
        write_volatile(words.add(i), 0);
        i += 1;
    }

    let traditional = (&raw mut (*packet).body).cast::<IkcScdPacketTraditional>();
    (*traditional).req.number = syscall_number;
    (*traditional).req.args[0] = node_addr;
    #[cfg(native_linux_irq_work_v6_12)]
    if syscall_number == NR_MOVE_PAGES {
        (*traditional).req.args[1] = crate::zero_pages::BATCH_MARKER;
    }

    compiler_fence(Ordering::Release);
    write_volatile(&raw mut (*traditional).req.valid, 1);
    (*packet).msg = SCD_MSG_SYSCALL_ONESIDE;
    (*traditional).ref_ = cpu_ref;
    (*traditional).pid = pid;
    (*traditional).resp_pa = 0;
}
#[cfg(native_linux_irq_work_v6_12)]
const _: () = {
    use crate::zero_pages as wire;
    assert!(size_of::<FreeChunk>() == wire::HEADER_BYTES);
    assert!(offset_of!(FreeChunk, list) as u64 == wire::LINK_OFFSET);
    assert!(size_of::<IhkMcNumaNode>() == wire::NODE_BYTES);
    assert!(align_of::<IhkMcNumaNode>() as u64 == wire::NODE_ALIGN);
    assert!(offset_of!(IhkMcNumaNode, zeroing_workers) as u64 == wire::CONTROL_OFFSET);
    assert!(offset_of!(IhkMcNumaNode, free_chunks)
        - offset_of!(IhkMcNumaNode, zeroing_workers) == wire::CONTROL_BYTES);
    assert!(size_of::<LListNode>() == size_of::<crate::llist::LListNode>());
    assert!(align_of::<LListNode>() == align_of::<crate::llist::LListNode>());
    assert!(size_of::<LListHead>() == size_of::<crate::llist::LListHead>());
    assert!(align_of::<LListHead>() == align_of::<crate::llist::LListHead>());
};
