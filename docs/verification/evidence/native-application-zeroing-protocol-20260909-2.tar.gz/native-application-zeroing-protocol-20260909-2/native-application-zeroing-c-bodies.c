void __ihk_numa_zero_request_packet_fill(struct ikc_scd_packet *packet,
		unsigned long node_addr, int cpu_ref, int pid,
		unsigned long syscall_number)
{
	memset(packet, 0, sizeof(*packet));
	packet->req.number = syscall_number;
	packet->req.args[0] = node_addr;

	barrier();
	smp_store_release_ulong(&packet->req.valid, 1);
	packet->msg = SCD_MSG_SYSCALL_ONESIDE;
	packet->ref = cpu_ref;
	packet->pid = pid;
	packet->resp_pa = 0;
}
int __ihk_numa_zero_free_pages(struct ihk_mc_numa_node *__node, int nr_pages)
{
#ifdef MCKERNEL_RUST_PAGE_ALLOC_RBTREE
	return __ihk_numa_zero_free_pages_dispatch(__node, nr_pages);
#else
	int i, max_i;
	int nr_zeroed_pages = 0;

	if (!zero_at_free)
		return 0;

	/* If explicitly specified, zero only in __node */
	max_i = __node ? 1 : ihk_mc_get_nr_numa_nodes();

	/* Look at NUMA nodes in the order of distance */
	for (i = 0; i < max_i; ++i) {
		struct ihk_mc_numa_node *node;
		struct llist_node *llnode;

		/* Unless explicitly specified.. */
		node = __node ? __node : ihk_mc_get_numa_node_by_distance(i);
		if (!node) {
			break;
		}

		/*
		 * If number of pages specified, look for a big enough chunk
		 */
		if (nr_pages) {
			struct llist_head tmp;

			init_llist_head(&tmp);

			/* Look for a suitable chunk */
			while ((llnode = llist_del_first(&node->to_zero_list))) {
				unsigned long addr;
				unsigned long size;
				struct free_chunk *chunk =
					((struct free_chunk *)((char *)(llnode) - offsetof(struct free_chunk, list)));

				addr = chunk->addr;
				size = chunk->size;

				if (size < (nr_pages << PAGE_SHIFT)) {
					llist_add(llnode, &tmp);
					continue;
				}

				memset(phys_to_virt(addr) + sizeof(*chunk), 0,
						size - sizeof(*chunk));
				llist_add(&chunk->list, &node->zeroed_list);
				barrier();
				ihk_atomic_sub((int)(size >> PAGE_SHIFT),
						&node->nr_to_zero_pages);
				nr_zeroed_pages += (chunk->size >> PAGE_SHIFT);
				kprintf("%s: zeroed chunk 0x%lx:%lu in allocate path\n",
						__func__, addr, size);
				break;
			}

			/* Add back the ones that didn't match */
			while ((llnode = llist_del_first(&tmp))) {
				llist_add(llnode, &node->to_zero_list);
			}
		}
		/* Otherwise iterate all to_zero chunks */
		else {
			while ((llnode = llist_del_first(&node->to_zero_list))) {
				unsigned long addr;
				unsigned long size;
				struct free_chunk *chunk =
					((struct free_chunk *)((char *)(llnode) - offsetof(struct free_chunk, list)));

				addr = chunk->addr;
				size = chunk->size;

				memset(phys_to_virt(addr) + sizeof(*chunk), 0,
						size - sizeof(*chunk));
				llist_add(&chunk->list, &node->zeroed_list);
				barrier();
				ihk_atomic_sub((int)(size >> PAGE_SHIFT),
						&node->nr_to_zero_pages);
				nr_zeroed_pages += (chunk->size >> PAGE_SHIFT);
			}
		}
	}

	return nr_zeroed_pages;
#endif
}
