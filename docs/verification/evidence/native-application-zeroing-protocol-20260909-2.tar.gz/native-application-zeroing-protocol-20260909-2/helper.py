"""Exact guest batch ownership, native wire geometry and preserved C oracle."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-application-zeroing-protocol-20260909-' + sys.argv[1]); out.mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    commands=[], extracted_bodies=[], production_gate_credit=False,
    scope='Exact C and selected guest Rust zeroing/producer bodies, actual Rust atomic list, guarded RAM, first fit and concurrent/reentrant consumers; host service and actual guest runtime still pending')

def identity(path):
    data=path.read_bytes(); return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def body(path, pattern, name, suffix=False):
    data=path.read_text(); match=re.search(pattern,data,re.M); assert match,name
    start=match.start(); end=data.index('{',start)+1; depth=1
    while depth:
        depth+=(data[end]=='{')-(data[end]=='}'); end+=1
    if suffix: end=data.index(';',end)+1
    return saved(path,data,start,end,name)
def saved(path,data,start,end,name):
    result=data[start:end]
    record['extracted_bodies'].append(dict(source=str(path),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(result.encode()).hexdigest()))
    return result+'\n'
def run(label,args):
    print('RUN',label,flush=True); (out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log:
        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-14000:])

try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['kernel/rust/page_alloc.rs','kernel/rust/rbtree.rs','kernel/rust/abi.rs','kernel/rust/llist.rs','kernel/rust/lib.rs','kernel/CMakeLists.txt',
        'host-kernel/native-rust/zero_pages.rs','host-kernel/native-rust/application_rpc.rs','host-kernel/native-rust/application_syscall.rs',
        'lib/page_alloc.c','lib/include/ihk/page_alloc.h','lib/include/ihk/lock.h','lib/include/list.h','kernel/include/rbtree.h','kernel/include/llist.h','arch/x86_64/kernel/include/ihk/atomic.h',
        'kernel/include/syscall.h','executer/include/uprotocol.h','ihk/ikc/include/ikc/queue.h',
        'scripts/tests/fixtures/native-application-zeroing.c','scripts/tests/fixtures/native-application-zeroing.rs']
    original=out/'original-inputs'
    for name in names:
        target=original/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(repo/name,target)
    record['inputs']=[identity(original/name) for name in names]
    for name in ['abi.rs','llist.rs']:
        shutil.copyfile(original/'kernel/rust'/name,out/name)
    for name in ['zero_pages.rs','application_rpc.rs','application_syscall.rs']:
        shutil.copyfile(original/'host-kernel/native-rust'/name,out/name)
    for ext in ['c','rs']:
        shutil.copyfile(original/('scripts/tests/fixtures/native-application-zeroing.'+ext),out/('native-application-zeroing.'+ext))
    rust=original/'kernel/rust/page_alloc.rs'; data=rust.read_text()
    generated=''
    for name in ['PAGE_SHIFT','SCD_MSG_SYSCALL_ONESIDE','NR_MOVE_PAGES']:
        match=re.search(r'^const '+name+r':[^;]+;',data,re.M); assert match,name; generated+=match[0]+'\n'
    for name in ['RbNode','RbRoot']:
        generated+=body(original/'kernel/rust/rbtree.rs',r'^#\[repr\(C\)\]\n(?:#\[[^\n]+\]\n)*pub struct '+name+r' \{',name)
    for name in ['LListNode','LListHead','ListHead','IhkAtomic','McsLockNode','FreeChunk','IhkMcNumaNode']:
        generated+=body(rust,r'^#\[repr\(C(?:, align\(64\))?\)\]\n(?:#\[[^\n]+\]\n)*(?:pub\(crate\) )?struct '+name+r' \{',name)
    for name in ['list_to_chunk','chunk_list','llist_head_first','llist_add','llist_del_first','atomic_counter','ihk_atomic_sub','zero_phys_range','native_zero_free_pages_node','__ihk_numa_zero_free_pages_node','__ihk_numa_zero_request_packet_fill']:
        if name=='native_zero_free_pages_node': generated+='#[cfg(native_linux_irq_work_v6_12)]\n'
        generated+=body(rust,r'^(?:pub )?unsafe (?:extern "C" )?fn '+name+r'\(',name)
    generated+=body(rust,r'^#\[cfg\(native_linux_irq_work_v6_12\)\]\nconst _: \(\) = \{','native zeroing layout binding',True)
    (out/'native-application-zeroing-bodies.rs').write_text(generated)
    generated='#define IHK_RBTREE_ALLOCATOR\n#define __aligned(n) __attribute__((aligned(n)))\n'
    for path,name in [('kernel/include/rbtree.h','rb_node'),('kernel/include/rbtree.h','rb_root'),('kernel/include/llist.h','llist_node'),('kernel/include/llist.h','llist_head'),('lib/include/list.h','list_head')]:
        generated+=body(original/path,r'^struct '+name+r' \{',name,True)
    atomic=original/'arch/x86_64/kernel/include/ihk/atomic.h'
    generated+=body(atomic,r'^typedef struct \{','ihk_atomic_t',True)
    lock=original/'lib/include/ihk/lock.h'; data=lock.read_text()
    match=re.search(r'^typedef struct mcs_lock_node \{[\s\S]*?^} mcs_lock_node_t;\n#endif',data,re.M); assert match
    generated+=saved(lock,data,match.start(),match.end(),'mcs_lock_node_t both C preprocessor alternatives')
    for name in ['free_chunk','ihk_mc_numa_node']:
        generated+=body(original/'lib/include/ihk/page_alloc.h',r'^struct '+name+r' \{',name,True)
    generated+=body(original/'executer/include/uprotocol.h',r'^struct syscall_request \{','syscall_request',True)
    generated+=body(original/'ihk/ikc/include/ikc/queue.h',r'^struct ihk_ikc_packet_header \{','ihk_ikc_packet_header',True)
    cwire=original/'kernel/include/syscall.h'
    for kind,name in [('enum','mcctrl_os_cpu_operation'),('struct','ikc_scd_packet')]:
        generated+=body(cwire,r'^'+kind+' '+name+r' \{',name,True)
    match=re.search(r'^#define SCD_MSG_SYSCALL_ONESIDE[^\n]+',cwire.read_text(),re.M); assert match; generated+=match[0]+'\n'
    (out/'native-application-zeroing-c-layout.h').write_text(generated)
    generated=''
    for result,name in [('void','__ihk_numa_zero_request_packet_fill'),('int','__ihk_numa_zero_free_pages')]:
        generated+=body(original/'lib/page_alloc.c',r'^'+result+' '+name+r'\([^;]+?\)\n\{',name)
    (out/'native-application-zeroing-c-bodies.c').write_text(generated)
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(out/'native-application-zeroing.rs'),str(out/'zero_pages.rs')])
    run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(out/'native-application-zeroing.c'),'-o',str(out/'c-reference')])
    run('c-reference',[str(out/'c-reference')])
    record['test_summaries']={}
    for kind,extra in [('legacy',[]),('native',['--cfg','native_linux_irq_work_v6_12'])]:
        run(kind+'-build',['rustc','--edition','2021','-D','warnings','--test',str(out/'native-application-zeroing.rs'),'-o',str(out/(kind+'-tests'))]+extra)
        run(kind+'-tests',[str(out/(kind+'-tests')),'--nocapture'])
        record['test_summaries'][kind]=[line for line in (out/(kind+'-tests.log')).read_text().splitlines() if line.startswith('test result:')]
    record['compiler_inputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.suffix in ('.rs','.c','.h')]
    for row in record['inputs']+record['compiler_inputs']: assert identity(Path(row['path']))==row
    record.update(status='PASS',legacy_c_vectors=30,producer_vectors=6,concurrent_chunks=2048,concurrent_zero_consumers=3)
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
