#define IHK_RBTREE_ALLOCATOR
#define __aligned(n) __attribute__((aligned(n)))
struct rb_node {
	unsigned long  __rb_parent_color;
	struct rb_node *rb_right;
	struct rb_node *rb_left;
} __attribute__((aligned(sizeof(long))));
struct rb_root {
	struct rb_node *rb_node;
};
struct llist_node {
	struct llist_node *next;
};
struct llist_head {
	struct llist_node *first;
};
struct list_head {
	struct list_head *next, *prev;
};
typedef struct {
	int counter;
} ihk_atomic_t;
typedef struct mcs_lock_node {
#ifndef SPIN_LOCK_IN_MCS
	unsigned long locked;
	struct mcs_lock_node *next;
#endif
	unsigned long irqsave;
#ifdef SPIN_LOCK_IN_MCS
	ihk_spinlock_t spinlock;
#endif
#ifndef ENABLE_UBSAN
} __aligned(64) mcs_lock_node_t;
#else
} mcs_lock_node_t;
#endif
struct free_chunk {
	unsigned long addr, size;
	struct rb_node node;
	struct llist_node list;
};
struct ihk_mc_numa_node {
	int id;
	int linux_numa_id;
	int type;
	struct list_head allocators;
	struct node_distance *nodes_by_distance;
#ifdef IHK_RBTREE_ALLOCATOR
	ihk_atomic_t zeroing_workers;
	ihk_atomic_t nr_to_zero_pages;
	struct llist_head zeroed_list;
	struct llist_head to_zero_list;
	struct rb_root free_chunks;
	mcs_lock_node_t lock;

	unsigned long nr_pages;
	/*
	 * nr_free_pages: all freed pages, zeroed if zero_at_free
	 */
	unsigned long nr_free_pages;
	unsigned long min_addr;
	unsigned long max_addr;
#endif
};
struct syscall_request {
	/* TID of requesting thread */
	int rtid;
	/*
	 * TID of target thread. Remote page fault response needs to designate the
	 * thread that must serve the request, 0 indicates any thread from the pool
	 */
	int ttid;
	unsigned long valid;
	unsigned long number;
	unsigned long args[6];
};
struct ihk_ikc_packet_header {
	struct ihk_ikc_channel_desc *channel;
};
enum mcctrl_os_cpu_operation {
	MCCTRL_OS_CPU_READ_REGISTER,
	MCCTRL_OS_CPU_WRITE_REGISTER,
	MCCTRL_OS_CPU_MAX_OP
};
struct ikc_scd_packet {
	struct ihk_ikc_packet_header header;
	int msg;
	int err;
	void *reply;
	union {
		/* for traditional SCD_MSG_* */
		struct {
			int ref;
			int osnum;
			int pid;
			unsigned long arg;
			struct syscall_request req;
			unsigned long resp_pa;
		};

		/* for SCD_MSG_SYSFS_* */
		struct {
			long sysfs_arg1;
			long sysfs_arg2;
			long sysfs_arg3;
		};

		/* SCD_MSG_WAKE_UP_SYSCALL_THREAD */
		struct {
			int ttid;
		};

		/* SCD_MSG_CPU_RW_REG */
		struct {
			unsigned long pdesc; /* Physical addr of the descriptor */
			enum mcctrl_os_cpu_operation op;
			void *resp;
		};

		/* SCD_MSG_EVENTFD */
		struct {
			int eventfd_type;
		};

		/* SCD_MSG_FUTEX_WAKE */
		struct {
			void *resp;
			int *spin_sleep; /* 1: waiting in linux_wait_event() 0: woken up by someone else */
		} futex;

		/* SCD_MSG_REMOTE_PAGE_FAULT */
		struct {
			int target_cpu;
			int fault_tid;
			unsigned long fault_address;
			unsigned long fault_reason;
		};
	};
	/* char padding[8]; */ /* We want the size to be 128 bytes */
};
#define SCD_MSG_SYSCALL_ONESIDE         0x4
