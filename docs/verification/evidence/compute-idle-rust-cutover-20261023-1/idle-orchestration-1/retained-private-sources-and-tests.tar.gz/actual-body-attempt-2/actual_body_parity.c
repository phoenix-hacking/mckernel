#include <process.h>
#include <sched_helpers.h>
#include <cls.h>
#include <cpulocal.h>
#include <ihk/monitor.h>
#include <string.h>
/* Ordinary actual-header fixture only: every primitive below is a safe stub. */
static struct cpu_local_var cpu;
static struct thread threads[4];
static struct ihk_os_cpu_monitor test_monitor;
static int scenario, phase, irq_on, held, bad, events_used;
struct event {
	unsigned long code, cpu_status, current_index, current_status, flags;
	unsigned long monitor_status, monitor_counter, irq, held;
};
static struct event events[64];
static struct cpu_local_var *test_current_cpu(void) { return &cpu; }
static unsigned long test_current_cpu_ulong(void) { return (unsigned long)&cpu; }
static void event(unsigned long code)
{
	if (events_used >= 64) { bad++; return; }
	struct event *e = &events[events_used++];
	e->code=code; e->cpu_status=cpu.status; e->current_index=cpu.current-threads;
	e->current_status=cpu.current->status; e->flags=cpu.flags;
	e->monitor_status=test_monitor.status; e->monitor_counter=test_monitor.counter;
	e->irq=irq_on; e->held=held;
}
static void queue_running(void)
{
	threads[3].status=PS_RUNNING;
	cpu.runq.next=&threads[3].sched_list; cpu.runq.prev=&threads[3].sched_list;
	threads[3].sched_list.next=&cpu.runq; threads[3].sched_list.prev=&cpu.runq;
}
static unsigned long test_lock(unsigned long address)
{
	if(address!=(unsigned long)&cpu.runq_lock || irq_on || held) bad++;
	event('L'); held=1;
	if(scenario==4) queue_running();
	return 0x11223344UL;
}
static void test_unlock(unsigned long address, unsigned long irqstate)
{
	if(address!=(unsigned long)&cpu.runq_lock || !held) bad++;
	if(irqstate!=(phase==0?0x5a5aUL:0x11223344UL)) bad++;
	event('U'); held=0; irq_on=0;
	if(phase && scenario==5) cpu.status=CPU_STATUS_RUNNING;
}
static unsigned long test_lock_pointer(ihk_spinlock_t *address)
{ return test_lock((unsigned long)address); }
static void test_unlock_pointer(ihk_spinlock_t *address, unsigned long irqstate)
{ test_unlock((unsigned long)address,irqstate); }
static void test_enable(void) { event('E'); irq_on=1; }
static void test_disable(void)
{
	if(cpu.current->status!=PS_RUNNING) bad++;
	event('D'); irq_on=0;
}
static void test_schedule(void)
{
	if(cpu.current->status!=PS_STOPPED) bad++;
	event('S');
	if(scenario==1) cpu.current=&threads[1];
	if(scenario==7) cpu.status=CPU_STATUS_RESERVED;
}
static void test_migrate(void)
{
	if(irq_on) bad++;
	event('M'); cpu.flags|=0x80;
	if(scenario==6) cpu.status=CPU_STATUS_RUNNING;
}
static void test_consolidate(void)
{
	if(irq_on || held || cpu.current->status!=PS_RUNNING) bad++;
	event('C');
}
static void test_zero(void)
{
	if(irq_on || held || cpu.current->status!=PS_RUNNING) bad++;
	event('Z');
}
static void *test_node(int distance)
{ if(distance) bad++; return &test_monitor; }
static void test_zero_pages(void *node)
{ if(node!=&test_monitor) bad++; test_zero(); }
static void test_halt(void)
{
	if(irq_on || held || test_monitor.status!=IHK_OS_MONITOR_IDLE ||
	   cpu.current->status!=PS_INTERRUPTIBLE) bad++;
	event('H'); irq_on=1;
	if(scenario==2) cpu.current=&threads[2];
}

#ifdef MCKERNEL_RUST_PROCESS_HELPERS
static const struct sched_idle_offsets process_idle_offsets = {
	.cpu_runq_lock_offset = offsetof(struct cpu_local_var, runq_lock),
	.cpu_runq_irqstate_offset = offsetof(struct cpu_local_var, runq_irqstate),
	.cpu_current_offset = offsetof(struct cpu_local_var, current),
	.cpu_flags_offset = offsetof(struct cpu_local_var, flags),
	.cpu_status_offset = offsetof(struct cpu_local_var, status),
	.cpu_runq_offset = offsetof(struct cpu_local_var, runq),
	.thread_sched_list_offset = offsetof(struct thread, sched_list),
	.thread_status_offset = offsetof(struct thread, status),
	.monitor_status_offset = offsetof(struct ihk_os_cpu_monitor, status),
	.monitor_counter_offset = offsetof(struct ihk_os_cpu_monitor, counter),
};
static const struct sched_idle_values process_idle_values = {
	.cpu_running = CPU_STATUS_RUNNING, .cpu_idle = CPU_STATUS_IDLE,
	.cpu_reserved = CPU_STATUS_RESERVED, .thread_running = PS_RUNNING,
	.thread_stopped = PS_STOPPED, .thread_interruptible = PS_INTERRUPTIBLE,
	.need_migrate = CPU_FLAG_NEED_MIGRATE,
	.monitor_idle = IHK_OS_MONITOR_IDLE, .monitor_kernel = IHK_OS_MONITOR_KERNEL,
};
static const struct sched_idle_callbacks process_idle_callbacks = {
	.current_cpu = test_current_cpu_ulong,
	.lock = test_lock, .unlock = test_unlock,
	.enable_interrupt = test_enable, .disable_interrupt = test_disable,
	.schedule = test_schedule, .migrate = test_migrate,
	.consolidate = test_consolidate,
	.zero_free = test_zero, .safe_halt = test_halt,
};
_Static_assert(sizeof(unsigned long) == 8 && sizeof(void *) == 8,
	"idle callback ABI requires supported LP64");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct thread *)0)->status), int)
	&& sizeof(((struct thread *)0)->status) == 4, "idle thread status is C int/i32");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct cpu_local_var *)0)->status), int)
	&& sizeof(((struct cpu_local_var *)0)->status) == 4, "idle CPU status is C int/i32");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct cpu_local_var *)0)->flags), unsigned int)
	&& sizeof(((struct cpu_local_var *)0)->flags) == 4, "idle CPU flags are u32");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct ihk_os_cpu_monitor *)0)->status), int)
	&& sizeof(((struct ihk_os_cpu_monitor *)0)->status) == 4, "idle monitor status is C int/i32");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct ihk_os_cpu_monitor *)0)->counter), unsigned long),
	"idle monitor counter is unsigned long");
_Static_assert(offsetof(struct list_head, next) == 0, "idle scan requires leading next");
_Static_assert(sizeof(struct sched_idle_offsets) == 80, "idle offsets ABI size");
_Static_assert(sizeof(struct sched_idle_values) == 36, "idle constants ABI size");
_Static_assert(sizeof(struct sched_idle_callbacks) == 80, "idle callback ABI size");


#endif


static void reset_case(int selected_scenario, int status, int queue)
{
	memset(&cpu,0,sizeof(cpu)); memset(threads,0,sizeof(threads));
	memset(&test_monitor,0,sizeof(test_monitor)); memset(events,0,sizeof(events));
	scenario=selected_scenario; phase=0; irq_on=0; held=1; bad=0; events_used=0;
	cpu.current=&threads[0]; cpu.monitor=&test_monitor; cpu.status=status;
	cpu.runq_irqstate=0x5a5aUL; cpu.runq.next=&cpu.runq; cpu.runq.prev=&cpu.runq;
	threads[0].status=PS_RUNNING; test_monitor.status=IHK_OS_MONITOR_KERNEL;
	test_monitor.counter=scenario==8?~0UL:17UL;
	if(scenario==3 || scenario==6) cpu.flags=CPU_FLAG_NEED_MIGRATE|0x40;
	if(queue) {
		queue_running();
		if(queue==1) { threads[3].status=PS_STOPPED; threads[3].spin_sleep=1; }
	}
}
struct snapshot {
	struct cpu_local_var cpu;
	struct thread threads[4];
	struct ihk_os_cpu_monitor monitor;
	struct event events[64];
	int irq_on,held,bad,events_used;
};
static struct snapshot expected,actual;
static void snapshot(struct snapshot *state)
{
	memset(state,0,sizeof(*state));
	memcpy(&state->cpu,&cpu,sizeof(cpu)); memcpy(state->threads,threads,sizeof(threads));
	memcpy(&state->monitor,&test_monitor,sizeof(test_monitor)); memcpy(state->events,events,sizeof(events));
	state->irq_on=irq_on; state->held=held; state->bad=bad; state->events_used=events_used;
}

static void original_begin(void) {

	struct cpu_local_var *v = test_current_cpu();
	struct ihk_os_cpu_monitor *monitor = v->monitor;

	/* Release runq_lock before starting the idle loop.
	 * See comments at release_runq_lock().
	 */
	test_unlock_pointer(&(test_current_cpu()->runq_lock),
			test_current_cpu()->runq_irqstate);

	if(v->status == CPU_STATUS_RUNNING)
		v->status = CPU_STATUS_IDLE;
	test_enable();

	
}
static void original_iteration(void) { struct cpu_local_var *v=&cpu; struct ihk_os_cpu_monitor *monitor=v->monitor;

		test_current_cpu()->current->status = PS_STOPPED;
		test_schedule();
		test_current_cpu()->current->status = PS_RUNNING;
		test_disable();

		/* See if we need to migrate a process somewhere */
		if (v->flags & CPU_FLAG_NEED_MIGRATE) {
#ifdef MCKERNEL_RUST_PROCESS_HELPERS
			test_migrate();
#else
			test_migrate();
#endif
			v->flags &= ~CPU_FLAG_NEED_MIGRATE;
		}

		/*
		 * XXX: KLUDGE: It is desirable to be resolved in test_schedule().
		 *
		 * There is a problem which causes wait4(2) hang when
		 * wait4(2) called by a process races with its child process
		 * termination. This is a quick fix for this problem.
		 *
		 * The problem occurrd in the following sequence.
		 * 1) The parent process called test_schedule() from sys_wait4() to
		 *    wait for an event generated by the child process.
		 * 2) test_schedule() resumed the idle process because there was no
		 *    runnable process in run queue.
		 * 3) At the moment, the child process began to end. It set
		 *    the parent process runnable, and sent an interrupt to
		 *    the parent process's cpu. But this interrupt had no
		 *    effect because the parent process's cpu had not halted.
		 * 4) The idle process was resumed, and halted for waiting for
		 *    the interrupt that had already been handled.
		 */
		if (v->status == CPU_STATUS_IDLE ||
		    v->status == CPU_STATUS_RESERVED) {
			long s;
			struct thread *t;

			s = test_lock_pointer(&v->runq_lock);
			for (t = ((typeof(*t) *)((char *)((&v->runq)->next) - offsetof(typeof(*t), sched_list))); &t->sched_list != (&v->runq); t = ((typeof(*t) *)((char *)(t->sched_list.next) - offsetof(typeof(*t), sched_list)))) {
				if (t->status == PS_RUNNING) {
					v->status = CPU_STATUS_RUNNING;
					break;
				}
			}
			test_unlock_pointer(&v->runq_lock, s);
		}
		if (v->status == CPU_STATUS_IDLE ||
		    v->status == CPU_STATUS_RESERVED) {
			/* No work to do? Consolidate the kmalloc free list */
			test_consolidate();
			test_zero_pages(test_node(0));
			monitor->status = IHK_OS_MONITOR_IDLE;
			test_current_cpu()->current->status = PS_INTERRUPTIBLE;
			test_halt();
			monitor->status = IHK_OS_MONITOR_KERNEL;
			monitor->counter++;
			test_current_cpu()->current->status = PS_RUNNING;
		}
		else {
			test_enable();
		}
	
}


extern long write(int fd,const void *buffer,unsigned long bytes);
int main(void)
{
	int checked=0;
	const int states[]={CPU_STATUS_DISABLE,CPU_STATUS_IDLE,CPU_STATUS_RESERVED,CPU_STATUS_RUNNING};
	for(int s=0;s<9;s++) for(unsigned i=0;i<4;i++) for(int q=0;q<3;q++) {
		reset_case(s,states[i],q); original_begin(); phase=1; original_iteration(); snapshot(&expected);
		if(expected.bad) return 51;
		reset_case(s,states[i],q);
		sched_idle_begin_body_result((unsigned long)&cpu,&process_idle_offsets,&process_idle_values,&process_idle_callbacks);
		phase=1;
		sched_idle_iteration_body_result((unsigned long)&cpu,(unsigned long)&test_monitor,
			&process_idle_offsets,&process_idle_values,&process_idle_callbacks);
		snapshot(&actual);
		if(actual.bad) return 52;
		if(memcmp(&expected,&actual,sizeof(actual))) return 53;
		if((s==3 || s==6) && cpu.flags!=(0x40|0x80)) return 54;
		checked++;
	}
	if(checked!=108) return 55;
	static const char message[]="PASS 108 original-C/Rust idle state and callback-order cases; actual production headers\n";
	if(write(1,message,sizeof(message)-1)!=(long)(sizeof(message)-1)) return 56;
	return 0;
}
