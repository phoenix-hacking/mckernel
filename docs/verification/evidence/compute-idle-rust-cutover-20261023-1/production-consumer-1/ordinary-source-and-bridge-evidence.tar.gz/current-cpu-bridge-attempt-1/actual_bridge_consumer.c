#include <process.h>
#include <sched_helpers.h>
#include <cls.h>
extern struct cpu_local_var *clv;
extern unsigned long process_sched_cpu_local_bridge(int);
extern unsigned long bridge_cpu_local_size(void);
extern unsigned long bridge_cpu_local_alignment(void);
static struct cpu_local_var cpu_array[6];
static int selected_cpu;
int ihk_mc_get_processor_id(void) { return selected_cpu; }
extern long write(int,const void *,unsigned long);
int main(void) {
 if(bridge_cpu_local_size()!=sizeof(struct cpu_local_var)) return 11;
 if(bridge_cpu_local_alignment()!=__alignof__(struct cpu_local_var)) return 12;
 clv=cpu_array;
 for(int id=0;id<6;id++) {
  selected_cpu=id;
  if((struct cpu_local_var *)sched_idle_current_cpu_bridge()!=&cpu_array[id]) return 21;
  if((struct cpu_local_var *)process_sched_cpu_local_bridge(id)!=&cpu_array[id]) return 22;
  if(get_cpu_local_var(id)!=&cpu_array[id]) return 23;
  if(get_this_cpu_local_var()!=&cpu_array[id]) return 24;
 }
 static const char message[]="PASS 6 current-CPU bridge chains; actual Rust abi.rs/cls.rs and C production type size/alignment\n";
 if(write(1,message,sizeof(message)-1)!=(long)(sizeof(message)-1)) return 31;
 return 0;
}
