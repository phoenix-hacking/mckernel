#![no_std]
#[path="/home/holden/mckernel-work/host-preparation/compute-idle-rust-cutover-20261023-1/production-consumer-1/materialized-source/kernel/rust/abi.rs"] mod abi;
#[path="/home/holden/mckernel-work/host-preparation/compute-idle-rust-cutover-20261023-1/production-consumer-1/materialized-source/kernel/rust/cls.rs"] mod cls;
mod process_bridge { use crate::abi::{CInt,CULong,CpuLocalVar};
unsafe extern "C" {fn get_cpu_local_var(id:CInt)->*mut CpuLocalVar;}
#[no_mangle]
pub unsafe extern "C" fn process_sched_cpu_local_bridge(cpu_id: CInt) -> CULong {
    get_cpu_local_var(cpu_id) as CULong
}
}
mod idle_bridge {use crate::abi::CInt;
unsafe extern "C" {fn ihk_mc_get_processor_id()->CInt; fn process_sched_cpu_local_bridge(id:CInt)->usize;}
#[no_mangle]
pub unsafe extern "C" fn sched_idle_current_cpu_bridge() -> usize {
    unsafe { process_sched_cpu_local_bridge(ihk_mc_get_processor_id()) }
}
}
#[no_mangle] pub extern "C" fn bridge_cpu_local_size()->usize {core::mem::size_of::<abi::CpuLocalVar>()}
#[no_mangle] pub extern "C" fn bridge_cpu_local_alignment()->usize {core::mem::align_of::<abi::CpuLocalVar>()}
