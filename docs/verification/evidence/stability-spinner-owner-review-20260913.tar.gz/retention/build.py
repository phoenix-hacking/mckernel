from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/holden/mckernel')
OUT = Path('/tmp/stability-audit-retention-20260913-1')
OUT.mkdir()
(OUT / 'build.py').write_bytes(Path(__file__).read_bytes())

def identity(path, data=None):
    path = Path(path)
    if data is None:
        data = path.read_bytes()
    return {'path': str(path), 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def retain(name, roots, record):
    archive = ROOT / 'docs/verification/evidence' / (name + '.tar.gz')
    report = ROOT / 'docs/verification' / (name + '.json')
    if archive.exists() or report.exists():
        raise ValueError('immutable output already exists: ' + name)
    members = []
    with archive.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:gz') as tar:
            for label, directory in roots:
                directory = Path(directory)
                for path in sorted(directory.rglob('*')):
                    if path.is_symlink():
                        raise ValueError('unexpected retained symlink: ' + str(path))
                    if not path.is_file():
                        continue
                    data = path.read_bytes()
                    member = label + '/' + path.relative_to(directory).as_posix()
                    info = tarfile.TarInfo(member)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
                    members.append(dict(identity(path, data), member=member))
    # Verify actual archive bytes against each original retained member, without
    # importing or executing any comparator, controller, parser, or test.
    with tarfile.open(archive, 'r:gz') as tar:
        actual = tar.getmembers()
        if len(actual) != len(members):
            raise ValueError('archive member count drift')
        for item, expected in zip(actual, members):
            data = tar.extractfile(item).read()
            if item.name != expected['member'] or identity(item.name, data)['sha256'] != expected['sha256']:
                raise ValueError('archive member identity drift: ' + item.name)
    record.update(archive=identity(archive), archive_members=members,
                  archive_member_hashes_verified=True,
                  retention_verification_scope='metadata and raw-byte hashing only; no reviewed helper/test imports or execution')
    report.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    result = {'report': identity(report), 'archive': identity(archive), 'members': len(members)}
    (OUT / (name + '-retention.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result))

capture = Path('/home/holden/mckernel-work/scratch/stability-physical-comparator-tests-20260913-1')
peer = Path('/tmp/stability-physical-tests-source-review-20260913-fzmu_2rp')
record = json.loads((capture / 'record.json').read_text())
if record['status'] != 'PASS_SYNTHETIC_PHYSICAL_COMPARATOR_ONLY' or record['cases'] != 16:
    raise ValueError('unexpected root test result')
if record['collection']['raw_wait_status'] != 0 or record['guest_execution'] is not False:
    raise ValueError('unexpected execution scope or wait result')
for rel, expected in [('scripts/application-tests/physical_observations.py', 'bf343ff9b3e59e2b92cf6481b6b181e45e9204afed5dfaf8ded4e7b063a0460a'),
                      ('scripts/tests/test_physical_observations.py', '0ec5a0564a78ca12fc6bb4a80fd4b11818ee1b17a8f2d21e1d4ed21cf23882b4')]:
    for path in (ROOT / rel, capture / rel, peer / Path(rel).name):
        if identity(path)['sha256'] != expected:
            raise ValueError('reviewed/tested/current source mismatch: ' + str(path))

prior_json = ROOT / 'docs/verification/stability-hard-physical-oracle-20260913.json'
prior_tar = ROOT / 'docs/verification/evidence/stability-hard-physical-oracle-20260913.tar.gz'
retain('stability-physical-comparator-validation-20260913',
       [('pinned-attempt', capture), ('independent-source-review', peer), ('retention', OUT)],
       {'schema_version': 1, 'record_kind': 'stability_physical_comparator_validation',
        'status': 'PASS_SYNTHETIC_PHYSICAL_COMPARATOR_ONLY', 'tests_passed': 16,
        'application_acceptance': False, 'transport_acceptance': False,
        'production_gate_credit': False, 'actual_selected_wake_verified': False,
        'guest_execution': False, 'tests_executed_by_retention_author': False,
        'actual_result': identity(capture / 'record.json'), 'actual_collection': identity(capture / 'collection/report.json'),
        'independent_review': identity(peer / 'review.json'),
        'original_source_derivation_and_prior_captures': {'manifest': identity(prior_json), 'archive': identity(prior_tar),
            'preserved_attempts': ['/tmp/stability-hard-physical-oracle-source-20260913-1',
                                   '/tmp/stability-hard-physical-oracle-source-20260913-2',
                                   '/tmp/stability-physical-ack-independent-review-20260913-46ogngi1']},
        'test_scope': ['independent literal packet/header/response bytes',
                       'consumed retention and publication interval off-by-one/overwrite rejection',
                       'stale, unpublished, ambiguous and wrong-target packet rejection',
                       'every selected request field and all six argument mutations',
                       'new selected wake versus unrelated/old publication',
                       'legal full126 queue accepted without physical credit',
                       'opaque response byte preservation and every forbidden/quiet field mutation',
                       'strict scalar/types/length/schema and u64 overflow checks'],
        'limitation': 'Synthetic comparator checks do not close actual guest read-wake2, injection, owner/RET/provenance or physical acceptance gates. Root reported guest4 correctly failed the unchanged wake2 prerequisite; no expected constants were derived from that capture.'})

spinner = Path('/tmp/stability-spinner-owner-source-review-20260913-1')
spinner_record = json.loads((spinner / 'review.json').read_text())
spinner_record['original_review'] = identity(spinner / 'review.json')
retain('stability-spinner-owner-review-20260913', [('source-review', spinner), ('retention', OUT)], spinner_record)
