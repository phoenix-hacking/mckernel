# Authority3 adaptation of the accepted authority2 read-only inline collector.
# Preparation only: this file has not been executed. No cleanup or release.
import fcntl, importlib.util, json, os, stat, subprocess, sys
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    'cleanup', '/home/holden/mckernel/scripts/native_exact_scratch22_authority3_terminal_cleanup.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
assert m.digest(m.read_bounded(Path(spec.origin))) == '8449b4b87b2286d4dc3d08e0c5921d2d79e44f17920d0aaee3eae646993fc995'
lock = os.open(str(m.ROOT_LOCK), os.O_RDONLY | os.O_NOFOLLOW)
try:
    meta = os.fstat(lock)
    assert stat.S_ISREG(meta.st_mode) and (meta.st_dev, meta.st_ino) == (27, 4)
    assert (meta.st_uid, meta.st_gid, stat.S_IMODE(meta.st_mode), meta.st_size, meta.st_nlink) == (0, 0, 0o644, 0, 1)
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not os.path.lexists(m.LEASE)
    assert not Path('/proc/270194').exists()
    assert not Path('/proc/269925').exists()
    assert not os.path.lexists(m.ROOT / 'native-exact-scratch-22-authority3-heavy-build.root-lock-quarantine.json')
    request = m.parse(m.read_bounded(m.REQUEST))
    assert m.observe_identity(m.REQUEST)['sha256'] == m.REQUEST_SHA
    owner = m.parse(m.read_bounded(m.ATTEMPT))
    ident = '153492d487bf1b66c47b43b03fc5552c9e912c1422265788d04722dcc7ebd4ab'
    item = json.loads(subprocess.check_output([
        '/usr/bin/docker', '--host=unix:///var/run/docker.sock', 'inspect', '--', ident], timeout=20))[0]
    target = {'container_id': ident, 'container_name': item['Name'].lstrip('/'),
              'owner_nonce': item['Config']['Labels']['mckernel.owner'], 'image_id': item['Image'],
              'owner_pid': owner['pid'], 'owner_starttime': owner['starttime'],
              'exit_code': item['State']['ExitCode']}
    m.validate_attempt_binding(target, {'path': str(m.REQUEST), 'sha256': m.REQUEST_SHA})
    assert item['Id'] == ident and target['exit_code'] == 1 and type(target['exit_code']) is int
    assert item['State']['Status'] == 'exited' and item['State']['Running'] is False and item['State']['Pid'] == 0
    assert item['State']['OOMKilled'] is False
    paths = {m.REQUEST, m.TERMINAL, m.ROOT_TERMINAL, m.EVIDENCE / 'container.log',
             m.EVIDENCE / 'receipt.json', m.EVIDENCE / 'build/receipt.json', m.EVIDENCE / 'build/driver.log',
             m.ROOT / 'native-exact-scratch-22-authority3-heavy-build.stdout'}
    paths.update(Path(request[k]) for k in ('driver_path', 'owner_path', 'input_manifest', 'image_receipt'))
    obs = {
        'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        'candidate_commit': request['candidate_sha'],
        'candidate_tree': subprocess.check_output([
            '/usr/bin/git', '-C', str(m.CANDIDATE), 'rev-parse', 'HEAD^{tree}'], timeout=10).decode().strip(),
        'candidate_root': m.observe_identity(m.CANDIDATE), 'container_inspect': item,
        'inventories': {str(p): m.metadata_inventory(p) for p in (m.OUTPUT, m.EVIDENCE)},
        'mount': json.loads(subprocess.check_output([
            '/usr/bin/findmnt', '-J', '-T', str(m.ROOT), '-o',
            'TARGET,SOURCE,FSTYPE,OPTIONS,UUID,MAJ:MIN'], timeout=10))['filesystems'][0],
        'request': m.observe_identity(m.REQUEST), 'request_lease_absent': True,
        'retained_exclusions': [m.observe_identity(p) for p in (m.ATTEMPT, m.SHARED)],
        'root': m.observe_identity(m.ROOT), 'root_lock': m.observe_identity(m.ROOT_LOCK),
        'selected_files': [m.observe_identity(p) for p in sorted(paths)], 'target': target}
    assert obs['mount']['uuid'] == m.UUID
    assert obs['root_lock']['device'] == 27 and obs['root_lock']['inode'] == 4
    assert (os.fstat(lock).st_dev, os.fstat(lock).st_ino) == (27, 4)
    assert not Path('/proc/270194').exists() and not Path('/proc/269925').exists()
    assert not os.path.lexists(m.LEASE)
    json.dump(obs, sys.stdout, sort_keys=True)
    sys.stdout.write('\n')
finally:
    fcntl.flock(lock, fcntl.LOCK_UN)
    os.close(lock)
