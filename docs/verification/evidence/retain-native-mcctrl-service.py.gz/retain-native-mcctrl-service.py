"""Retain the native mcctrl file-service implementation and real guest checks."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-mcctrl-service-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-mcctrl-service-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),artifacts=[],captures=[],references=[],native_compiler_bindings=[],linux_compiler_bindings=[],applications_tested=False,production_gate_credit=False,declared_stage_integrated=False)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-guest-sysfs-checkpoint-20260908.json','native-sysfs-snoop-boundary-checkpoint-20260908.json']:
        path=repo/'docs/verification'/name;state=json.loads(path.read_text());assert state['status']=='PASS'
        item=identity(path);item['path']=str(path.relative_to(repo));record['references'].append(item)
        for row in state['artifacts']:
            actual=identity(repo/row['path']);assert (actual['size'],actual['sha256'])==(row['size'],row['sha256']),row
            with gzip.open(repo/row['path'],'rb') as stream:
                while stream.read(1<<20):pass
    mapping=json.loads((work/'native-mcctrl-service-misnamed-capture-20260908.json').read_text())
    record['misnamed_capture']=mapping
    captures=['native-mcctrl-service-module-misnamed-20260908-1','native-mcctrl-service-module-20260908-2','native-mcctrl-service-guest-20260908-x86_64-1','native-mcctrl-service-guest-20260908-i386-1']
    for name in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text());assert state['status']=='PASS'
        old_prefix=Path(mapping['original_prefix']) if 'misnamed' in name else None
        retained_prefix=Path(mapping['retained_prefix']) if old_prefix else None
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row,old_prefix,retained_prefix)
        for item in state.get('captures',[]):
            for row in item['artifacts']:verify(row)
        artifact(capture,name+'.tar.gz',True)
        artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status='REJECTED_CAPTURE_NAME' if old_prefix else 'PASS',original_record_status=state['status']))
    compiled=work/captures[1]
    for saved in sorted((compiled/'staged-source').rglob('*.rs')):
        relative=saved.relative_to(compiled/'staged-source')
        current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if current.read_bytes() == saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs')
            shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            item=identity(current);item['path']=str(current.relative_to(repo))
            item.update(binding='Exact pinned rustfmt replay; original and formatted files retained',compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(item)
    for name in ['smp_trampoline.S','smp_startup_entry.S']:
        record['native_compiler_bindings'].append(binding(repo/'host-kernel/native-rust'/name,compiled/'staged-source'/name))
    for name in captures[2:]:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        assert state['full_ready_observed'] and state['observed_callback_exchanges']==130
        assert len(state['captures'])==2 and all(row['status']==3 for row in state['captures'])
        service=state['mcctrl_service']
        assert service==dict(topology_queries=1056,contexts=4,workers=8,cycles=2,unload_vetoes=8,absent_rejections=6,unsupported_rejections=2,pre_ready_rejections=2,module_loads=5,module_unloads=5,application_execution=False)
        for saved in sorted((capture/'probe-source').iterdir()):
            record['linux_compiler_bindings'].append(binding(repo/'scripts/tests/fixtures'/saved.name,saved))
    artifact(out/'format-replay','native-mcctrl-service-format-replay-20260908.tar.gz',True)
    failed=work/'native-mcctrl-service-retained-20260908-1'
    failed_state=json.loads((failed/'native-mcctrl-service-checkpoint-20260908.json').read_text())
    assert failed_state['status']=='FAIL' and failed_state['error']=='/workspace/host-kernel/native-rust/ihk_ioctl.rs'
    excluded={}
    for row in failed_state['artifacts']:
        name=Path(row['path']).name
        old=identity(failed/name);new=identity(out/name)
        assert (old['size'],old['sha256'])==(new['size'],new['sha256'])==(row['size'],row['sha256'])
        excluded[name]=dict(relative_capture=name,retained_path=row['path'],size=row['size'],sha256=row['sha256'])
    record['retention_failure']=dict(path=str(failed),status='FAIL',error=failed_state['error'],omitted_duplicate_archives=list(excluded.values()),reason='Only verified identical copies of the eight canonical archives are omitted; original failed manifest and helper are retained unchanged.')
    artifact(failed,'native-mcctrl-service-retention-failure-20260908-1.tar.gz',True,excluded)
    for name in ['build-native-mcctrl-service.py','run-native-mcctrl-service.py','native-mcctrl-service-misnamed-capture-20260908.json']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-mcctrl-service.py.gz')
    record['summary']=dict(native_modules=3,actual_starts=2,physical_ready_captures=4,topology_queries=2112,contexts_opened_and_closed=8,workers_joined=16,module_loads_and_unloads=10,unload_vetoes=16,absent_rejections=12,pre_ready_rejections=4,unsupported_rejections=4,continuing_sysfs_callback_exchanges=260,read_checks=132,store_checks=128,guest_store_payload_checks=128)
    record['limitations']=['This verifies existing application topology UAPI and file/module lifetime on a real one-CPU McKernel OS, not application execution. Executable/credentials, process data, VM/pinning, image launch and syscall forwarding remain open.','The first builder passed its compiler checks but reused an obsolete capture prefix. Its new files are preserved unchanged at a unique path, with an exact relocation map; only fresh module attempt 2 supplies the guest tests.','Declared staging/source graph, lifecycle and unsafe-FFI inventory integration and a fresh full suite remain open. The previous full suite predates this prototype. The first retention attempt stopped on preexisting staged formatting; the corrected retainer preserves that failure and verifies three exact formatter replays.','Both guests use the retained normal image. No guest image source, legacy host helper or launcher was changed; all preexisting consumers remain retained.','Multi-CPU/multi-OS, remaining sysfs fault/race work, full shutdown, full Rust/assembly completion and independent production acceptance remain required.']
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
