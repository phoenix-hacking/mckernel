import ast
import json
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent / "fixtures/native-lifecycle-model-v1"
FILES = {"README.md", "model.rs", "reference.c", "vectors.json", "expected.json", "harness.py"}

class NativeLifecycleModelSourceTests(unittest.TestCase):
    def test_exact_packet_and_labels(self):
        self.assertEqual({p.name for p in HERE.iterdir() if p.is_file()}, FILES)
        for name in FILES:
            self.assertIn("MODEL_ONLY", (HERE / name).read_text() if name.endswith((".md", ".rs", ".c", ".py")) else "MODEL_ONLY")

    def test_python_syntax_and_strict_vectors(self):
        ast.parse((HERE / "harness.py").read_text())
        vectors = json.loads((HERE / "vectors.json").read_text())
        expected = json.loads((HERE / "expected.json").read_text())
        self.assertTrue(vectors["model_only"] and expected["model_only"])
        self.assertEqual({v["name"] for v in vectors["vectors"]}, set(expected["expectations"]))
        self.assertTrue(all(0 < len(v["operations"]) <= 128 for v in vectors["vectors"]))

    def test_no_production_wiring(self):
        text = "\n".join((HERE / name).read_text() for name in ("model.rs", "reference.c"))
        for forbidden in ("host_schedule_process", "do_fork", "do_exit", "terminate(", "runq_add_thread", "mcctrl"):
            self.assertNotIn(forbidden, text)

if __name__ == "__main__":
    unittest.main()
