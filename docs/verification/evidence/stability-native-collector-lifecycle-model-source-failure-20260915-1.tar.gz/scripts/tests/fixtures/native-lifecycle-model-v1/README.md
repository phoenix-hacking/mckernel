# Native lifecycle publication model v1

`MODEL_ONLY`: this fixture models producer ownership and observation loss. It is
not a native collector ABI, production hook, application result, or runtime gate.

Authority: `docs/verification/stability-native-collector-lifecycle-model-design-20260915-1.md`.

Both standalone implementations consume the same bounded line protocol emitted
from `vectors.json`. They emit a complete result/snapshot row after every
operation. `harness.py` first compares each implementation with the independently
reviewed literal `expected.json`, then compares them with each other.

Limits are two applications, four processes, eight threads, 128 operations and
256 event attempts per vector. Event loss is sticky and never prevents state
cleanup. Numeric PID/TID values are attributes; the typed instance tuple is the
identity. This deterministic model does not test real concurrency, memory
ordering, transport durability, deadlines, or production lifetime hooks.
