#!/usr/bin/env python3
"""Bounded compiler/runner for the MODEL_ONLY lifecycle fixture."""
import argparse
import json
import os
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
MAX_JSON = 1 << 20

def strict(path):
    raw = path.read_bytes()
    assert len(raw) <= MAX_JSON and raw.strip().endswith(b"}")
    def pairs(items):
        out = {}
        for key, value in items:
            assert key not in out
            out[key] = value
        return out
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def checked_file(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    return path

def line_input(vector):
    operations = vector["operations"]
    assert 0 < len(operations) <= 128
    lines = [f'MODEL1 {vector["event_capacity"]}']
    for operation in operations:
        assert isinstance(operation, list) and len(operation) == 10
        assert isinstance(operation[0], str) and all(type(x) is int for x in operation[1:])
        lines.append(" ".join(map(str, operation)))
    return ("\n".join(lines) + "\n").encode()

def run(command, data, timeout):
    result = subprocess.run(command, input=data, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=timeout, check=False)
    assert result.returncode == 0, (command, result.returncode, result.stderr)
    assert not result.stderr and len(result.stdout) <= (1 << 20)
    rows = result.stdout.decode("ascii").splitlines()
    results, summary = [], None
    for row in rows:
        fields = row.split()
        if fields[0] == "R":
            assert len(fields) == 4
            results.append(int(fields[3]))
        elif fields[0] == "Z":
            assert len(fields) == 4 and summary is None
            summary = {"complete": fields[1] == "1", "lost": int(fields[2]),
                       "attempts": int(fields[3])}
        else:
            assert fields[0] in ("S", "E")
    assert summary is not None
    return results, summary, rows

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rustc", required=True)
    parser.add_argument("--cc", required=True)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    args = parser.parse_args()
    rustc, cc = checked_file(args.rustc), checked_file(args.cc)
    assert args.output.is_absolute() and not args.output.exists()
    args.output.mkdir(mode=0o700)
    rust_bin, c_bin = args.output / "model-rust", args.output / "model-c"
    subprocess.run([str(rustc), "--edition=2021", "-Dwarnings", "-o", str(rust_bin),
                    str(HERE / "model.rs")], check=True, timeout=60)
    subprocess.run([str(cc), "-std=c11", "-Wall", "-Wextra", "-Werror", "-O2",
                    "-o", str(c_bin), str(HERE / "reference.c")], check=True, timeout=60)
    vectors, expected = strict(HERE / "vectors.json"), strict(HERE / "expected.json")
    assert vectors["schema_version"] == expected["schema_version"] == 1
    assert vectors["model_only"] is expected["model_only"] is True
    seen = set()
    for vector in vectors["vectors"]:
        name = vector["name"]
        assert name not in seen and name in expected["expectations"]
        seen.add(name)
        data, want = line_input(vector), expected["expectations"][name]
        rust = run([str(rust_bin)], data, 10)
        cref = run([str(c_bin)], data, 10)
        assert rust == cref
        assert rust[0] == want["results"]
        assert rust[1]["complete"] is want["complete"]
        if "lost" in want:
            assert rust[1]["lost"] == want["lost"]
        else:
            assert rust[1]["lost"] >= want["lost_min"]
    assert seen == set(expected["expectations"])
    os.fsync(os.open(args.output, os.O_RDONLY | os.O_DIRECTORY))

if __name__ == "__main__":
    main()
