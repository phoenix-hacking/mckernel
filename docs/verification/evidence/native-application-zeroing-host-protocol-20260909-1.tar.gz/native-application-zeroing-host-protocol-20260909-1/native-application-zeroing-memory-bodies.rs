#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) struct Span {
    physical: u64,
    end: u64,
}
#[derive(Clone, Copy)]
struct Tagged {
    span: Span,
    serial: u64,
}
struct Ledger {
    fixed: Vec<Span>,
    requests: Vec<Option<Tagged>>,
    responses: Vec<Option<Tagged>>,
    payloads: Vec<Option<Tagged>>,
    snoops: Vec<Tagged>,
    procfs: Vec<Tagged>,
    zeroing: Vec<Tagged>,
    serial: u64,
}
impl Span {
    pub(super) fn new(physical: u64, bytes: usize) -> Result<Self> {
        if physical == 0 || bytes == 0 {
            return Err(EINVAL);
        }
        Ok(Self {
            physical,
            end: physical.checked_add(bytes as u64).ok_or(EINVAL)?,
        })
    }

    fn overlaps(self, other: Self) -> bool {
        self.physical < other.end && other.physical < self.end
    }
}
impl Ledger {
    fn conflicts(&self, span: Span, snoops: bool) -> bool {
        self.fixed.iter().any(|old| old.overlaps(span))
            || self
                .requests
                .iter()
                .flatten()
                .any(|old| old.span.overlaps(span))
            || self
                .payloads
                .iter()
                .flatten()
                .any(|old| old.span.overlaps(span))
            || self
                .responses
                .iter()
                .flatten()
                .any(|old| old.span.overlaps(span))
            || snoops && self.snoops.iter().any(|old| old.span.overlaps(span))
            || self.procfs.iter().any(|old| old.span.overlaps(span))
            || self.zeroing.iter().any(|old| old.span.overlaps(span))
    }

    fn tag(&mut self, span: Span) -> Result<Tagged> {
        self.serial = self.serial.checked_add(1).ok_or_else(|| errno(-75))?;
        Ok(Tagged {
            span,
            serial: self.serial,
        })
    }
}
pub(super) struct Memory {
    pub(super) owner: OsToken,
    pub(super) direct_map: u64,
    extents: Vec<MemoryExtent>,
    layout: crate::smp_image::BootLayout,
    numa_nodes: usize,
    ledger: Mutex<Ledger>,
}
trait GuestExtents {
    fn len(&self) -> usize;
    fn extent(&self, index: usize) -> Option<MemoryExtent>;
}
impl<const N: usize> GuestExtents for MemoryMap<N> {
    fn len(&self) -> usize {
        MemoryMap::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        MemoryMap::extent(self, index)
    }
}
impl GuestExtents for [MemoryExtent] {
    fn len(&self) -> usize {
        <[MemoryExtent]>::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        self.get(index).copied()
    }
}
fn checked_guest_bytes(
    map: &(impl GuestExtents + ?Sized),
    owner: super::smp_resource::OsToken,
    direct_map: u64,
    physical: u64,
    bytes: usize,
) -> Result<*mut u8> {
    let end = physical.checked_add(bytes as u64).ok_or(EINVAL)?;
    if physical == 0 || bytes == 0 || end > IDENTITY_WINDOW_END {
        return Err(EINVAL);
    }
    direct_map.checked_add(end - 1).ok_or(EINVAL)?;
    for index in 0..map.len() {
        let extent = map.extent(index).ok_or(EIO)?;
        if extent.owner() == Some(owner)
            && extent.start() <= physical
            && end <= extent.end().map_err(|_| EIO)?
        {
            return Ok(direct_map.checked_add(physical).ok_or(EINVAL)? as *mut u8);
        }
    }
    Err(EINVAL)
}
impl Memory {
    fn address(&self, physical: u64, bytes: usize) -> Result<u64> {
        checked_guest_bytes(
            self.extents.as_slice(),
            self.owner,
            self.direct_map,
            physical,
            bytes,
        )
        .map(|value| value as u64)
    }
    pub(super) fn application_range(&self, physical: u64, bytes: usize) -> Result {
        self.address(physical, bytes)?;
        if self
            .ledger
            .lock()
            .conflicts(Span::new(physical, bytes)?, true)
        {
            return Err(EBUSY);
        }
        Ok(())
    }
}
fn admit_zeroing(
    pending: &Mutex<Vec<zero_pages::Request>>,
    packet: &[u8; CONTROL_PACKET_BYTES],
    cpus: usize,
) -> Result {
    let request = zero_pages::Request::decode(packet, cpus).map_err(errno)?;
    let mut pending = pending.lock();
    if pending.len() == METADATA_CAPACITY {
        return Err(EAGAIN);
    }
    pending.push(request, GFP_KERNEL)?;
    Ok(())
}
