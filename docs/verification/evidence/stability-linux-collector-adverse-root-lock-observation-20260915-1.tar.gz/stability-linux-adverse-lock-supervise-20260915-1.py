#!/usr/bin/python3
import importlib.util
import json
from pathlib import Path
import sys

REPO = Path("/home/holden/mckernel")
SUPERVISOR = REPO / "scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/supervisor_host38.py"
PAYLOAD = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-lock-observe-20260915-1.py")
ATTEMPT = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-lock-observe-20260915-1-outer")
spec = importlib.util.spec_from_file_location("accepted_supervisor_host38", str(SUPERVISOR))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = module.run_supervised(
    ["/usr/bin/python3", "-I", "-B", str(PAYLOAD)],
    cwd=str(REPO), env={"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "TZ": "UTC"},
    attempt_dir=str(ATTEMPT), timeout_seconds=30, cleanup_timeout_seconds=10,
    stdout_limit_bytes=65536, stderr_limit_bytes=65536)
print(json.dumps(report, sort_keys=True))
if report.get("status") != "COMPLETED" or report.get("raw_wait_status") != 0:
    sys.exit(1)
