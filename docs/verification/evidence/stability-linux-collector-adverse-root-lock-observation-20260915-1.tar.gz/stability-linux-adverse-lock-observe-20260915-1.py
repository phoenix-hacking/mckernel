#!/usr/bin/python3
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
from datetime import datetime, timezone

LOCK = Path("/run/lock/mckernel-development.lock")
OUT = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-lock-observation-20260915-1.json")
fd = os.open(str(LOCK), os.O_RDWR | os.O_CLOEXEC | os.O_NOFOLLOW)
try:
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1:
        raise RuntimeError("development lock identity rejected")
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    result = {
        "schema_version": 1,
        "status": "PASS_POST_RUN_DEVELOPMENT_LOCK_ACQUIRABLE",
        "observed_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "lock": str(LOCK),
        "identity": {"device": info.st_dev, "inode": info.st_ino, "mode": info.st_mode,
                     "uid": info.st_uid, "gid": info.st_gid, "nlink": info.st_nlink},
        "nonblocking_exclusive_acquisition": True,
        "application_acceptance": False,
    }
    descriptor = os.open(str(OUT), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    print("PASS_POST_RUN_DEVELOPMENT_LOCK_ACQUIRABLE")
finally:
    os.close(fd)
