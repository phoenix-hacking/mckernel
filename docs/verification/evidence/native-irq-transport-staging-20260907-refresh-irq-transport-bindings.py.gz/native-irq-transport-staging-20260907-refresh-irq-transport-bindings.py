"""Refresh reviewed current metadata using stdlib only; no repository execution."""
import ast
import hashlib
import json
import pprint
import re
import subprocess
from pathlib import Path

root = Path('/home/holden/mckernel')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    data = (root / path).read_bytes()
    return dict(path=path, sha256=sha(data), size=len(data))

def blob_identity(path):
    data = (root / path).read_bytes()
    return dict(sha256=sha(data), size=len(data), git_blob_sha1=hashlib.sha1(
        ('blob ' + str(len(data)) + '\0').encode() + data).hexdigest())

def nodes(source):
    return {n.targets[0].id: n.value for n in ast.parse(source).body
            if isinstance(n, ast.Assign) and len(n.targets) == 1
            and isinstance(n.targets[0], ast.Name)}

def replace_values(path, replacements):
    p = root / path
    source = p.read_text()
    lines = source.splitlines(keepends=True)
    found = nodes(source)
    edits = []
    for name, value in replacements.items():
        n = found[name]
        edits.append((sum(map(len, lines[:n.lineno - 1])) + n.col_offset,
                      sum(map(len, lines[:n.end_lineno - 1])) + n.end_col_offset,
                      pprint.pformat(value, width=100, sort_dicts=False)))
    for a, b, value in sorted(edits, reverse=True):
        source = source[:a] + value + source[b:]
    p.write_text(source)

def normalize(path, marker):
    p = root / path
    raw = p.read_bytes()
    pattern = marker.encode() + br':[0-9a-f]{64}'
    normalized, count = re.subn(pattern, marker.encode() + b':' + b'0' * 64, raw)
    assert count == 1
    raw, count = re.subn(pattern, marker.encode() + b':' + sha(normalized).encode(), raw)
    assert count == 1
    p.write_bytes(raw)

def update_current_json(path, allowed):
    p = root / path
    value = json.loads(p.read_text())
    changed = []
    def walk(item):
        if isinstance(item, dict):
            if item.get('path') in allowed and 'sha256' in item:
                current = identity(item['path'])
                item['sha256'] = current['sha256']
                if 'size' in item:
                    item['size'] = current['size']
                changed.append(item['path'])
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
    walk(value)
    assert set(changed) == allowed, (path, changed, allowed)
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

runtime = 'scripts/native_rust_runtime_evidence.py'
runtime_contract = 'host-kernel/contracts/native-rust-runtime-evidence-v1.json'
workflow = '.github/workflows/native-rust-host-modules-exact-build.yml'
ns = nodes((root / runtime).read_text())
old_workflow = subprocess.check_output(['git', '-C', str(root), 'show', 'HEAD:' + workflow], text=True)
old_steps = ast.literal_eval(ns['EXPECTED_EXACT_BUILD_STEP_SHA256'])

def workflow_pins(source):
    exact = source.split('\n  fp0006-native-rust-capture:\n', 1)[0]
    names = list(old_steps)
    headers = ['      - name: ' + name + '\n' for name in names]
    positions = [exact.index(h) for h in headers]
    steps = {name: sha(exact[start + len(headers[i]):
                          positions[i + 1] if i + 1 < len(positions) else len(exact)].encode())
             for i, (name, start) in enumerate(zip(names, positions))}
    prefix = sha(exact[:exact.index('\njobs:\n') + 1].encode())
    return dict(EXPECTED_EXACT_BUILD_STEP_SHA256=steps, EXPECTED_EXACT_BUILD_PREFIX_SHA256=prefix)

for key, value in workflow_pins(old_workflow).items():
    assert ast.literal_eval(ns[key]) == value, 'Workflow preimage extraction differs: ' + key
replacements = workflow_pins((root / workflow).read_text())
workflow_ids = ast.literal_eval(ns['EXPECTED_REPOSITORY_WORKFLOW_IDENTITIES'])
workflow_ids['build_workflow'] = blob_identity(workflow)
replacements['EXPECTED_REPOSITORY_WORKFLOW_IDENTITIES'] = workflow_ids
replace_values(runtime, replacements)
normalize(runtime, 'ISOLATED_SELF_DIGEST')
p = root / runtime_contract
value = json.loads(p.read_text())
value['repository_workflow_identities']['build_workflow'] = workflow_ids['build_workflow']
p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

# Active FP-0006 integration only. Frozen witness/source descriptors stay fixed.
capture = 'host-kernel/contracts/fp0006-runtime-capture-integration-v1.json'
update_current_json(capture, {runtime, workflow})
cap = identity(capture)
replace_values('scripts/fp0006_runtime_capture_integration.py', dict(
    EXPECTED_CONTRACT_SHA256=cap['sha256'], EXPECTED_CONTRACT_SIZE=cap['size'],
    EXPECTED_NATIVE_WORKFLOW_SHA256=identity(workflow)['sha256']))
executable = 'host-kernel/contracts/fp0006-executable-acceptance-closure-v1.json'
old = identity(executable)['sha256']
update_current_json(executable, {capture})
new = identity(executable)
replace_values('scripts/fp0006_executable_acceptance_closure.py', dict(
    EXPECTED_CONTRACT_SHA256=new['sha256'], EXPECTED_CONTRACT_SIZE=new['size']))
normalize('scripts/fp0006_executable_acceptance_closure.py', 'SELF_DIGEST')
p = root / 'scripts/tests/test_fp0006_executable_acceptance_closure.py'
source = p.read_text()
assert source.count(old) == 1
p.write_text(source.replace(old, new['sha256']))

def refresh_override(path, allowed):
    p = root / path
    source = p.read_text()
    ns = nodes(source)
    node = ns['CURRENT_IMPLEMENTATION_OVERRIDES']
    edits = []
    lines = source.splitlines(keepends=True)
    def resolve(n):
        if isinstance(n, ast.Constant):
            return n.value
        if isinstance(n, ast.Name):
            return ast.literal_eval(ns[n.id])
        if isinstance(n, ast.Subscript):
            return resolve(n.value)[resolve(n.slice)]
        raise ValueError(ast.dump(n))
    for row in node.values:
        fields = {ast.literal_eval(k): v for k, v in zip(row.keys, row.values)}
        relative = resolve(fields['path'])
        if relative not in allowed:
            continue
        current = identity(relative)
        for key in ('sha256', 'size'):
            n = fields[key]
            edits.append((sum(map(len, lines[:n.lineno - 1])) + n.col_offset,
                          sum(map(len, lines[:n.end_lineno - 1])) + n.end_col_offset,
                          repr(current[key])))
    assert len(edits) == 2 * len(allowed), (path, allowed, edits)
    for a, b, value in sorted(edits, reverse=True):
        source = source[:a] + value + source[b:]
    p.write_text(source)

for path, allowed in [
    ('scripts/rocky_kernel_license_child_inventory_v2.py', {'scripts/rocky_kernel_license_inventory.py'}),
    ('scripts/rocky_kernel_license_review_response.py', {'scripts/rocky_kernel_license_inventory.py'}),
    ('scripts/rocky_kernel_license_review_response_builder.py', {'scripts/rocky_kernel_license_review_response.py'}),
    ('scripts/rocky_kernel_license_review_response_index.py', {'scripts/rocky_kernel_license_review_response.py'}),
]:
    refresh_override(path, allowed)

# This inventory explicitly describes currently integrated consumers.
rs006 = 'host-kernel/contracts/rs006-miscdevice-module-owner-followup-v1.json'
p = root / rs006
value = json.loads(p.read_text())
allowed = {workflow, runtime_contract, runtime, 'scripts/rocky_kernel_license_inventory.py',
           'scripts/tests/test_rocky_kernel_license_inventory.py'}
changed = set()
for row in value['integrated_consumer_inventory']:
    if row['path'] in allowed:
        row.update(identity(row['path']))
        changed.add(row['path'])
assert changed == allowed
p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
replace_values('scripts/rs006_miscdevice_module_owner_followup.py', {
    'EXPECTED_CONTRACT_SHA256': identity(rs006)['sha256']})
print('Updated current transport workflow, runtime and dependent bindings; historical records and credit unchanged.')
