from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-vdso-exports-retained-20260907-1'; out.mkdir()

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): result.update(data)
    return result.hexdigest()

record = dict(created_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], production_gate_credit=False, declared_stage=False,
    native_vdso_exports_and_live_data_proven=True, vdso_service_completed=False,
    mckernel_arch_entry_proven=True, control_listener_connections_proven=True,
    mckernel_boot_proven=False,
    passed=[
        'Patch 0008 exports only the existing Linux vDSO image/time/RNG data; actual allocation, update and text ownership remain in Linux',
        'Normal C preprocessing before and after the final bindgen-only inclusion guard is identical apart from source-position markers',
        'Independent C and generated Rust layout witnesses match byte-for-byte across all 44 values, including the 232-byte clock and 512-byte time object',
        'The exact pinned Linux kernel, three native prototype modules and read-only Rust fixture build; prototype and fixture ELF/no-SIMD checks pass',
        'Each of three guests runs two read-only fixture lifetimes, with 32 coherent time samples compared against Linux time, actual sequence updates and unchanged vDSO text',
        'Independent QMP captures read both Linux vDSO text pages and the live time/RNG pages, matching the actual module text hash and proving disjointness from assigned McKernel memory',
        'Preparation repeats both ABIs over two native module cycles, with 32 forced allocations, four physical captures and full unstarted restoration',
        'Both actual-start ABIs still execute McKernel, complete ports 501/503 and deliver the first real SCD_MSG_GET_VDSO_INFO request using the rebuilt Linux kernel',
        'The unchanged revision-2 image descriptor remains busy=1 across all 88 bytes; no vDSO response or readiness success is synthesized'],
    limitations=[
        'The first two binding builds fail E0588 in unrelated packed Hyper-V MSI types; both patches, logs, compiler outputs and the final scoped correction are retained',
        'The TCG guests select VDSO_CLOCKMODE_NONE; coherent coarse time/data access is proven, but accelerated TSC/pvclock/Hyper-V clock operation is not',
        'The new versioned descriptor, Rust guest clock/mapping adaptation and native vDSO service response remain to be implemented',
        'Full status 3, sysfs/mcctrl, asynchronous runtime dispatch, applications and native shutdown/restoration remain open',
        'Declared staging, lifecycle/unsafe-FFI/license bindings, current full-suite integration and independent production acceptance remain open',
        'The earlier intermittent Linux idle/RCU stall and full McKernel/linked-support Rust or assembly completion remain open'])

def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''): stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name,
        source=str(path), size=target.stat().st_size, sha256=digest(target),
        unpacked_size=path.stat().st_size, unpacked_sha256=digest(path)))

def check_row(row, capture):
    path = Path(row['path'])
    if path.is_relative_to(repo):
        if path.suffix == '.patch':
            path = capture / path.name
        elif path.name == 'native_vdso_layout.c':
            path = capture / 'witness' / path.name
        else:
            raise AssertionError(('Unreviewed mutable input', row['path']))
    assert path.stat().st_size == row['size'] and digest(path) == row['sha256'], path

captures = [
    ('native-vdso-kernel-20260907-1', 'FAIL'),
    ('native-vdso-kernel-20260907-2', 'FAIL'),
    ('native-vdso-kernel-20260907-3', 'PASS'),
    ('native-vdso-module-20260907-1', 'PASS'),
    ('native-ikc-prototype-20260907-5', 'PASS'),
    ('native-vdso-control-guest-20260907-prepare-1', 'PASS'),
    ('native-vdso-control-guest-20260907-start-x86_64-1', 'PASS'),
    ('native-vdso-control-guest-20260907-start-i386-1', 'PASS'),
]
for name, status in captures:
    path = work / name; metadata = json.loads((path / 'record.json').read_text())
    assert metadata['status'] == status, name
    rows = metadata.get('inputs', []) + metadata.get('outputs', [])
    for capture in metadata.get('captures', []): rows += capture.get('artifacts', [])
    for row in rows: check_row(row, path)
    if name.startswith('native-vdso-control-guest-'):
        assert metadata['live_vdso_exports'] == dict(module_cycles=2, samples=32, read_only=True, service_completed=False)
        assert all(capture['linux_vdso']['clock_mode'] == 0 for capture in metadata['captures'])
    record['captures'].append(dict(directory=name, status=status, source_parent=metadata.get('source_parent'),
        started_utc=metadata.get('started_utc'), finished_utc=metadata.get('finished_utc')))
    target = out / (name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive: archive.add(path, arcname=name)
    assert target.stat().st_size < 95 << 20, target
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
        source=str(path), size=target.stat().st_size, sha256=digest(target)))
    for short in ('record.json', 'serial.log', 'debugcon.log'):
        if (path / short).exists(): add(path / short, name + '-' + short + '.gz')

# Each retry copied the prior failed bindings before replacing them. Bindgen's
# unsupported layouts remain independently readable in those retained archives.
for attempt in (2, 3):
    add(work / ('native-vdso-kernel-20260907-' + str(attempt)) / 'before-bindings_generated.rs',
        'native-vdso-exports-20260907-failed-bindings-' + str(attempt - 1) + '.rs.gz')
for name in ('build-native-vdso-kernel.py', 'build-native-vdso-module.py',
             'build-native-vdso-prototype.py', 'run-native-vdso-control-guest.py',
             'retain-native-vdso-exports.py', 'native-vdso-module-original-input.rs'):
    add(work / name, 'native-vdso-exports-20260907-' + name + '.gz')
module = work / 'native-vdso-module-20260907-1'
original = json.loads((module / 'record.json').read_text())['repository_input']
saved = work / 'native-vdso-module-original-input.rs'
assert saved.stat().st_size == original['size'] and digest(saved) == original['sha256']
fixture = repo / 'scripts/tests/fixtures/mckernel_vdso_verify.rs'
assert fixture.read_bytes() == (module / 'source/scripts/tests/fixtures' / fixture.name).read_bytes()

stage = work / 'native-ikc-prototype-20260907-5/staged-source'
record['current_compiler_inputs'] = []
for path in sorted(stage.rglob('*')):
    if not path.is_file() or path.suffix not in ('.rs', '.S'): continue
    relative = 'host-kernel/native-rust/' + str(path.relative_to(stage)); current = repo / relative
    row = dict(path=relative, size=current.stat().st_size, sha256=digest(current),
        compiler_size=path.stat().st_size, compiler_sha256=digest(path), transform='none')
    if current.read_bytes() != path.read_bytes():
        assert path.suffix == '.rs', relative
        formatted = out / ('formatted-' + path.name); formatted.write_bytes(current.read_bytes())
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(formatted)]
        subprocess.run(command, check=True); assert formatted.read_bytes() == path.read_bytes(), relative
        row['transform'] = command[:-1]
        add(current, 'native-vdso-exports-20260907-unformatted-' + path.name + '.gz')
    record['current_compiler_inputs'].append(row)
record['current_compiler_input_count'] = len(record['current_compiler_inputs'])
for relative in ('host-kernel/kbuild/patches/0008-rust-expose-existing-x86-vdso-data.patch',
                 'scripts/tests/fixtures/native_vdso_layout.c',
                 'scripts/tests/fixtures/mckernel_vdso_verify.rs', 'scripts/native-boot-init.sh'):
    path = repo / relative
    record.setdefault('source_inputs', []).append(dict(path=relative, size=path.stat().st_size, sha256=digest(path)))
reference = repo / 'docs/verification/native-control-channels-checkpoint-20260907.json'
record['previous_control_reference'] = dict(path=str(reference.relative_to(repo)),
    size=reference.stat().st_size, sha256=digest(reference))
for row in record['artifacts']:
    size = 0; result = hashlib.sha256()
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): size += len(data); result.update(data)
    if 'unpacked_sha256' in row:
        assert size == row['unpacked_size'] and result.hexdigest() == row['unpacked_sha256']
record.update(status='PASS', finished_utc=datetime.now(timezone.utc).isoformat())
(out / 'native-vdso-exports-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained and verified', len(record['artifacts']), 'native vDSO export artifacts; service/full boot remain open', flush=True)
