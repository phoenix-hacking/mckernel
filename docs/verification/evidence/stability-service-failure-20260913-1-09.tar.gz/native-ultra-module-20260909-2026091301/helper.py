"""Build production continuing-service failure repair; guest evidence remains pending."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
assert len(sys.argv) == 2 and re.fullmatch(r'[1-9][0-9]*', sys.argv[1])
assert shutil.disk_usage('/work').free > 3 * 1024**3
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
kernel = Path('/work/native-topology-kernel-20260907-1')
out = Path('/work/native-ultra-module-20260909-' + sys.argv[1])
assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
out.mkdir()
stage = source / 'drivers/misc/mckernel'
modules = build / 'drivers/misc/mckernel'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True, timeout=120).strip(), commands=[], overlay=[], production_gate_credit=False, mckernel_boot_proven=False,
              scope='Native boot implementation prototype; live declared graph, FFI review and downstream bindings pending')

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-14000:])

try:
    shutil.copytree(stage, out / 'prior-stage')
    shutil.copytree(modules, out / 'prior-module-build')
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile('/work/build-native-ultra.py', out / 'prior-build-helper.py')
    record['prior_build_helper'] = identity(out / 'prior-build-helper.py')
    record['integration_patch'] = identity(repo / 'scripts/tests/fixtures/stability-service-failure-candidate.patch')
    record['controlled_test_record'] = identity(Path('/work/stability-service-failure-tests-20260913-3/record.json'))
    assert json.loads(Path(record['controlled_test_record']['path']).read_text())['status'] == 'PASS'
    record['controlled_production_bindings'] = []
    for name in ('smp_application.rs', 'smp_service.rs'):
        current = repo / 'host-kernel/native-rust' / name
        tested = Path('/work/stability-service-failure-tests-20260913-3/source/host-kernel/native-rust') / name
        assert current.read_bytes() == tested.read_bytes(), ('tested candidate drift', name)
        record['controlled_production_bindings'].append(dict(current=identity(current), tested=identity(tested)))
    stage.rename(source / ('drivers/misc/mckernel-before-ultra-20260909-' + sys.argv[1]))
    shutil.copytree(out / 'prior-stage', stage)
    if (stage / 'stage-lock.json').exists():
        (stage / 'stage-lock.json').rename(stage / 'prior-stage-lock.json')
    inputs = ['zero_pages.rs', 'sysfs_zeroing.rs', 'application_pager.rs', 'smp_file_pager.rs', 'smp_resource.rs', 'os_runtime.rs', 'os_registry.rs', 'ihk_ioctl.rs', 'smp_cpu.rs', 'smp_topology.rs', 'sysfs_setup.rs', 'abi/sysfs.rs', 'abi/sysfs_request.rs', 'sysfs_rpc.rs', 'sysfs_remote.rs', 'smp_service.rs', 'smp_procfs.rs', 'procfs_objects.rs', 'sysfs_memory.rs', 'sysfs_snoop.rs', 'smp_memory.rs', 'ihk_smp_x86_64.rs', 'ihk_mapping.rs', 'smp_image.rs', 'smp_loader.rs', 'smp_startup.rs', 'smp_trampoline.rs', 'smp_boot_code.rs', 'smp_ikc.rs', 'smp_vdso.rs', 'sysfs_objects.rs', 'sysfs_os.rs', 'sysfs_tree.rs', 'abi/vdso.rs', 'ikc_queue.rs', 'ikc_master.rs', 'smp_trampoline.S', 'smp_startup_entry.S', 'ihk.rs', 'mcctrl.rs', 'os_service.rs', 'abi/os_service.rs', 'abi/x86_64.rs', 'mcctrl_exec.rs', 'mcctrl_process.rs', 'user_string.rs', 'abi/application.rs', 'application_rpc.rs', 'application_syscall.rs', 'smp_application_syscall.rs', 'smp_application.rs', 'application_image.rs', 'smp_application_image.rs', 'mcctrl_vm.rs']
    original = out / 'original-inputs'; original.mkdir()
    for name in inputs:
        saved = original / name; saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, saved)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, stage / name)
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format-source', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + [str(stage / name) for name in inputs if name.endswith('.rs')])
    record['overlay'] = [identity(stage / name) for name in inputs]
    shutil.copytree(stage, out / 'staged-source')
    record.update(scope='Production continuing-service failure admission/quarantine ordering repair; exact50 controlled tests passed separately, native runtime evidence pending',sysfs_service_completed=False)
    run('module-build', shlex.split((prior / 'module-build.command').read_text()))
    shutil.copytree(modules, out / 'module-build')
    for name in ['ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko']:
        shutil.copyfile(modules / name, out / name)
        disassembly = subprocess.check_output(['objdump', '-d', str(out / name)], text=True, timeout=120)
        (out / (name + '-disassembly.txt')).write_text(disassembly)
        assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', disassembly), name
    for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
        undefined=subprocess.check_output(['nm','-u',str(out/name)],text=True, timeout=120)
        (out/(name+'-undefined.txt')).write_text(undefined)
        info=subprocess.check_output(['modinfo',str(out/name)],text=True, timeout=120)
        (out/(name+'-modinfo.txt')).write_text(info)
        if name == 'mcctrl.ko':
            for symbol in ['ihk_provider_lifecycle_v1','ihk_os_service_register_v1','ihk_os_service_unregister_v1','ihk_os_topology_query_v1','ihk_os_application_open_v1','ihk_os_application_invoke_v1','ihk_os_application_close_v1']:
                assert ' U '+symbol+'\n' in undefined, symbol
            for symbol in ['open_exec','fput','d_path','get_task_pid','get_pid_task','put_pid','pid_nr_ns','init_pid_ns','anon_inode_getfile','get_task_mm','mmput','__mmdrop','vm_mmap','vm_munmap','vmf_insert_pfn_prot','zap_vma_ptes','prepare_creds','override_creds','revert_creds','abort_creds']:
                assert ' U '+symbol+'\n' in undefined, symbol
            assert re.search(r'^depends:\s+ihk$',info,re.M), info
            assert re.search(r'^import_ns:\s+MCKERNEL_IHK_V1$',info,re.M), info
        if name == 'ihk-smp-x86_64.ko':
            assert ' U ihk_os_create_unbooted_v4\n' in undefined
            for symbol in ['fget','fput','kernel_read','kernel_write','vfs_getattr','d_path']:
                assert ' U '+symbol+'\n' in undefined, symbol
        if name == 'ihk.ko':
            symbols=subprocess.check_output(['nm',str(out/name)],text=True, timeout=120)
            for symbol in ['ihk_os_service_register_v1','ihk_os_service_unregister_v1','ihk_os_topology_query_v1','ihk_os_application_open_v1','ihk_os_application_invoke_v1','ihk_os_application_close_v1','ihk_os_create_unbooted_v1','ihk_os_create_unbooted_v2','ihk_os_create_unbooted_v3','ihk_os_create_unbooted_v4']:
                assert re.search(r' T '+symbol+'$',symbols,re.M),symbol
    shutil.copyfile(kernel/'bzImage',out/'bzImage')
    shutil.copyfile(kernel/'resolved.config',out/'resolved.config')
    record['inputs']=[identity(p) for p in sorted(original.rglob('*')) if p.is_file()]
    record['inputs'] += [identity(kernel/'record.json'),identity(prior/'module-build.command')]
    record['compiler_inputs']=[identity(out/'staged-source'/name) for name in inputs]
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row,row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
