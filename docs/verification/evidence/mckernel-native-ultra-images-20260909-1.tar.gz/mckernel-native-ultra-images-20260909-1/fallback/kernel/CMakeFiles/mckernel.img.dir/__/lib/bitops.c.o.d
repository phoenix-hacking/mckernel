kernel/CMakeFiles/mckernel.img.dir/__/lib/bitops.c.o: \
 /work/mckernel-native-ultra-images-20260909-1/source/lib/bitops.c \
 /work/mckernel-native-ultra-images-20260909-1/source/lib/include/bitops.h \
 /work/mckernel-native-ultra-images-20260909-1/source/lib/include/types.h \
 /work/mckernel-native-ultra-images-20260909-1/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-ultra-images-20260909-1/source/lib/include/bitops-test_bit.h \
 /work/mckernel-native-ultra-images-20260909-1/source/arch/x86_64/kernel/include/arch-bitops.h
