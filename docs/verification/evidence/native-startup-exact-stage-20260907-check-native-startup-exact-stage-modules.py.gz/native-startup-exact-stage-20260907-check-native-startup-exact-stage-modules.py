import hashlib,json,os,re,subprocess
from pathlib import Path
repo=Path('/workspace');compiled=Path('/work/native-startup-exact-stage-20260907-1')
if os.getuid()!=1000 or os.sched_getaffinity(0)!={2,3,4,5}: raise SystemExit('Requires fixed four-CPU runner')
manifest=json.loads((repo/'host-kernel/kbuild/stage-manifest.json').read_text())
for row in manifest['inputs']+[module['source'] for module in manifest['modules']]:
 for path in (repo/row['repository_path'],compiled/'staged-source'/row['destination']):
  if hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
   raise SystemExit('Declared source differs: '+str(path))
lock=json.loads((compiled/'stage-lock.json').read_text())
if hashlib.sha256((repo/'host-kernel/kbuild/stage-manifest.json').read_bytes()).hexdigest()!=lock['manifest_sha256']:
 raise SystemExit('Stage manifest identity changed')
for row in lock['files']:
 if hashlib.sha256((compiled/'staged-source'/row['path']).read_bytes()).hexdigest()!=row['sha256']:
  raise SystemExit('Staged file differs: '+row['path'])
print('Declared source, copied stage and stage-lock identities match.',flush=True)
subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
for name in ['ihk_smp_x86_64.rs','smp_cpu.rs','smp_memory.rs','os_runtime.rs','smp_loader.rs','smp_image.rs','smp_startup.rs']:
 subprocess.run(['rustfmt','--check','--edition','2021','--config','skip_children=true,reorder_modules=false',str(repo/'host-kernel/native-rust'/name)],check=True)
record=json.loads((compiled/'record.json').read_text());assert record['status']=='PASS'
modules=[]
for row in record['outputs']:
 path=Path(row['path']);b=path.read_bytes()
 if len(b)!=row['size'] or hashlib.sha256(b).hexdigest()!=row['sha256']: raise SystemExit('Compiled artifact changed: '+str(path))
 if path.suffix!='.ko': continue
 header=subprocess.check_output(['llvm-readelf','-h',str(path)],text=True)
 if 'ELF64' not in header or 'Advanced Micro Devices X86-64' not in header: raise SystemExit('Wrong ELF architecture')
 assembly=subprocess.check_output(['llvm-objdump','-d','--no-show-raw-insn',str(path)],text=True)
 instructions=[];unexpected=[]
 for line in assembly.splitlines():
  match=re.match(r'^\s*[0-9a-f]+:\s+(.+)$',line)
  if not match: continue
  instruction=match.group(1);instructions.append(instruction);mnemonic=instruction.split()[0]
  if re.search(r'%(?:[xyz]mm[0-9]+|mm[0-7])\b',instruction) or mnemonic.startswith(('f','xsave','xrstor')) or mnemonic in ('vzeroupper','vzeroall','emms','ldmxcsr','stmxcsr'): unexpected.append(instruction)
 if unexpected: raise SystemExit('Unexpected SIMD/x87 '+repr(unexpected[:10]))
 modules.append(dict(path=str(path),sha256=row['sha256'],architecture='ELF64 x86-64',instruction_count=len(instructions),simd_x87_instructions=unexpected))
result=dict(status='PASS',modules=modules,scope='declared-stage owned startup tables with isolated debug configuration',full_repository_suite_run=False,production_gate_credit=False)
Path('/work/native-startup-exact-stage-20260907-1/module-artifact-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
