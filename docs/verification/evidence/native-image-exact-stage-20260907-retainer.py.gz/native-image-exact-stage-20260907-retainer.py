"""Retain local declared-stage image validation without production gate credit."""
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile
from pathlib import Path

repo = Path('/home/holden/mckernel')
scratch = Path('/home/holden/mckernel-work/scratch')
compiled = scratch/'native-image-exact-stage-20260907-1'
guest = scratch/'native-image-exact-stage-guest-20260907-2'
first = scratch/'native-image-exact-stage-guest-20260907-1'
build = json.loads((compiled/'record.json').read_text())
run = json.loads((guest/'local-run.json').read_text())
assert build['status'] == 'PASS'
assert run['status'] == 'technical-capture-passed' and run['qemu_exit_code'] == 0
assert not run['missing_markers'] and not run['error_markers']
assert len(run['physical_image_readbacks']) == 24
assert run['mckernel_boot_proven'] is False
for row in build['outputs'] + run['inputs']:
    relative = row['path']
    if relative.startswith('/work/'):
        path = scratch/relative[6:]
    elif relative.startswith('/workspace/'):
        path = repo/relative[11:]
    else:
        # Container-owned compiler bytes were checked inside the guest runner.
        continue
    raw = path.read_bytes()
    assert len(raw) == row['size'] and hashlib.sha256(raw).hexdigest() == row['sha256'], relative

artifacts = []
def retain(name, raw):
    data = gzip.compress(raw, mtime=0)
    path = repo/'docs/verification/evidence'/('native-image-exact-stage-20260907-'+name+'.gz')
    with path.open('xb') as stream:
        stream.write(data)
    artifacts.append(dict(path=str(path.relative_to(repo)), size=len(data),
                          sha256=hashlib.sha256(data).hexdigest(),
                          uncompressed_size=len(raw), uncompressed_sha256=hashlib.sha256(raw).hexdigest()))

def archive(root, paths):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for path in sorted(paths):
            raw = path.read_bytes()
            item = tarfile.TarInfo(str(path.relative_to(root)))
            item.size, item.mode, item.mtime = len(raw), 0o644, 0
            tar.addfile(item, io.BytesIO(raw))
    return buffer.getvalue()

build_paths = [path for path in compiled.rglob('*') if path.is_file()
               and path.relative_to(compiled).parts[0] not in ('prototype-stage', 'prototype-module-build')]
retain('build-capture.tar', archive(compiled, build_paths))
retain('guest-capture.tar', archive(guest, [path for path in guest.rglob('*')
                                          if path.is_file() and path.relative_to(guest).parts[0] != 'root']))
for label, root, names in (
    ('build', compiled, ('record.json', 'module-artifact-checks.json', 'stage-lock.json', 'kbuild-link-closure.json', 'kernel-build.log', 'module-build.log')),
    ('guest', guest, ('local-run.json', 'serial.log', 'image-model.json')),
    ('first-guest', first, ('local-run.json', 'serial.log', 'qemu.log', 'run-helper.py', 'image-model.json')),
):
    for name in names:
        retain(label+'-'+name, (root/name).read_bytes())
for name in ('build-native-image-exact-stage.py', 'check-native-image-exact-stage-modules.py',
             'run-native-image-exact-stage-guest.py', 'run-native-image-declared-stage-guest.py',
             'inventory-rust-consumers-image-20260907.py', 'run-native-image-full-tests.py'):
    retain(name, (scratch/name).read_bytes())
retain('retainer.py', Path(__file__).read_bytes())
inventory = scratch/'rust-consumers-image-20260907.json'
inventory_destination = repo/'docs/verification'/inventory.name
with inventory_destination.open('xb') as stream:
    stream.write(inventory.read_bytes())
inventory_record = json.loads(inventory.read_text())
references = []
for name in ('native-image-loader-checkpoint-20260907.json',
             'native-image-staging-integration-20260907.json', inventory.name):
    path = repo/'docs/verification'/name
    raw = path.read_bytes()
    references.append(dict(path=str(path.relative_to(repo)), size=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
record = dict(schema_version=1, kind='native-image-declared-stage-local-validation',
              recorded_utc=datetime.now(timezone.utc).isoformat(), source_parent=build['source_parent'],
              configuration_scope='isolated-image-fault-injection-debug-variant',
              build=dict(status='PASS', started_utc=build['started_utc'], finished_utc=build['finished_utc'],
                         declared_stage_verified=True, link_closure_verified=True,
                         module_architecture_and_no_simd_verified=True, outputs=build['outputs']),
              guest=dict(status='PASS', started_utc=run['started_utc'], finished_utc=run['finished_utc'],
                         cpus=4, numa_nodes=2, module_cycles=2, abis=['x86_64','i386'],
                         physical_image_readbacks=24, image_model=run['image_model'],
                         missing_markers=[], error_markers=[], immutable_inputs_verified_at_completion=True),
              first_guest=dict(runtime_status='PASS', capture_input_integrity='FAILED_INCIDENTAL_MUTABLE_LOG',
                               explanation='The generic recipe collected a changing orchestration log as an input. The repeated declared-stage recipe selects immutable build inputs and checks them again at completion.'),
              rust_preservation=dict(total_files=len(inventory_record['files']),
                                     counts=inventory_record['preservation_counts'],
                                     kernel_crate_files=inventory_record['kernel_crate_files'],
                                     native_staged_files=18, removed_files=inventory_record['removed_baseline_files']),
              full_repository_suite='pending', production_gate_credit=False, native_mckernel_boot_proven=False,
              complete_rust_unification_claimed=False,
              remaining=['Full repository suite', 'Native AP startup and McKernel boot', 'IKC and native mcctrl workloads',
                         'McKernel Rust/assembly-only completion', 'Production capture and independent acceptance review'],
              references=references, artifacts=artifacts)
path = repo/'docs/verification/native-image-exact-stage-checkpoint-20260907.json'
with path.open('x') as stream:
    stream.write(json.dumps(record, indent=2, sort_keys=True)+'\n')
print('Retained declared-stage build and guest:', len(artifacts), 'artifacts;', len(inventory_record['files']), 'Rust files preserved')
