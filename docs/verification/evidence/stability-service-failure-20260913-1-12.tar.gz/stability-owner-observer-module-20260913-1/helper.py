"""Compile verification-only observer and restore both shared native build trees."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,re,shlex,shutil,stat
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work')
assert shutil.disk_usage(work).free>3*1024**3
out=work/'stability-owner-observer-module-20260913-1';out.mkdir()
parent=work/'native-ultra-module-20260909-2026091301'
stage=work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel'
modules=work/'native-build-base-24a151fe/drivers/misc/mckernel'
record=dict(status='RUNNING',commands=[],inputs=[],started_utc=datetime.now(timezone.utc).isoformat(),verification_only=True,phase_wiring='NONE',actual_guest_transport_fault_verified=False,production_gate_credit=False)
moved_stage=moved_modules=False

def identity(p):
 digest=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):digest.update(b)
 return dict(path=str(p),size=p.stat().st_size,sha256=digest.hexdigest())
def tree(p):
 rows=[]
 for q in sorted(p.rglob('*')):
  s=q.lstat();row=dict(path=str(q.relative_to(p)),mode=stat.S_IMODE(s.st_mode))
  if q.is_symlink():row.update(kind='symlink',target=os.readlink(q))
  elif q.is_file():row.update(kind='file',size=s.st_size,sha256=identity(q)['sha256'])
  elif q.is_dir():row.update(kind='directory')
  else:raise ValueError('unexpected build tree special file: '+str(q))
  rows.append(row)
 return rows

def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(os.environ)
 def run(label,argv,timeout=120):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=20,stdout_limit_bytes=16*1024**2,stderr_limit_bytes=16*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['wait_status']==dict(kind='exited',code=0) and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  return (out/(label+'-collection')/'stdout.bin').read_text()
 pstate=json.loads((parent/'record.json').read_text());assert pstate['status']=='PASS'
 record['parent_record']=identity(parent/'record.json')
 for row in pstate['outputs']+pstate['compiler_inputs']:assert identity(Path(row['path']))==row,row
 record['parent_inputs']=pstate['compiler_inputs']
 record['shared_stage_before']=tree(stage);record['shared_modules_before']=tree(modules)
 package=out/'fixture';package.mkdir()
 shutil.copytree(repo/'scripts/tests/fixtures/stability-owner-observer',package/'stability-owner-observer')
 shutil.copyfile(repo/'scripts/tests/fixtures/stability-owner-observer-state.rs',package/'stability-owner-observer-state.rs')
 record['fixture_inputs']=[identity(p) for p in sorted(package.rglob('*')) if p.is_file()]
 run('observer-state-build',['rustc','--edition','2021','-D','warnings','--test',str(package/'stability-owner-observer-state.rs'),'-o',str(out/'observer-tests')])
 run('observer-state-tests',[str(out/'observer-tests'),'--nocapture'])
 run('ledger-tests',['python3','-B',str(repo/'scripts/tests/test_verification_state.py'),'-v'])
 run('prepare-observer',['python3','-B',str(repo/'scripts/tests/prepare_stability_owner_observer.py'),'--source',str(parent/'staged-source'),'--output',str(out/'overlay')])
 overlay=json.loads((out/'overlay/record.json').read_text());assert overlay['status']=='PREPARED_NOT_COMPILED_NOT_EXECUTED'
 record['overlay_record']=identity(out/'overlay/record.json')
 for row in overlay['files']:
  actual=identity(parent/'staged-source'/row['name']);assert(actual['size'],actual['sha256'])==(row['original']['size'],row['original']['sha256']),row
 stage.rename(out/'restoration-stage');moved_stage=True
 shutil.copytree(parent/'staged-source',stage,symlinks=True)
 modules.rename(out/'restoration-module-build');moved_modules=True
 shutil.copytree(out/'restoration-module-build',modules,symlinks=True)
 for row in overlay['files']:
  shutil.copyfile(out/'overlay'/row['name'],stage/row['name'])
 shutil.copyfile(out/'overlay/stability_observer.rs',stage/'stability_observer.rs')
 run('format-overlay',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false']+[str(stage/row['name']) for row in overlay['files']]+[str(stage/'stability_observer.rs')])
 record['compiler_inputs']=[identity(p) for p in sorted(stage.rglob('*')) if p.is_file()]
 command=work/'native-irq-transport-exact-stage-20260907-1/module-build.command';record['build_command_input']=identity(command)
 run('native-module-build',shlex.split(command.read_text()),1800)
 for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko'):
  shutil.copyfile(modules/name,out/name)
  asm=run(name+'-disassembly',['objdump','-d',str(out/name)])
  assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b',asm),name
  run(name+'-symbols',['nm','-S',str(out/name)])
  run(name+'-undefined',['nm','-u',str(out/name)])
  run(name+'-modinfo',['modinfo',str(out/name)])
 record['compiled_modules']=[identity(out/name) for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko')]
 record.update(status='PASS_BUILD_ONLY',actual_stack_frames_verified=False,observer_guest_verified=False)
except BaseException as error:
 record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:
 try:
  if moved_modules:
   if modules.exists():modules.rename(out/'module-build')
   (out/'restoration-module-build').rename(modules)
  if moved_stage:
   if stage.exists():stage.rename(out/'staged-source')
   (out/'restoration-stage').rename(stage)
  if 'shared_stage_before' in record:
   record['shared_stage_after']=tree(stage);record['shared_modules_after']=tree(modules)
   assert record['shared_stage_after']==record['shared_stage_before'],'stage restoration mismatch'
   assert record['shared_modules_after']==record['shared_modules_before'],'module restoration mismatch'
   record['shared_production_trees_restored']=True
 except BaseException as error:
  record.update(status='RESTORATION_FAILED',restoration_error=str(error));raise
 finally:
  record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
