#!/bin/bash
set -eu
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
fail() { echo MCKERNEL_SYSFS_REMOTE_GUEST_FAIL; while :; do sleep 1; done; }
trap fail EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
for cycle in 1 2; do
    insmod /modules/mckernel_sysfs_remote_verify.ko
    /bin/native-sysfs-remote
    rmmod mckernel_sysfs_remote_verify
    test ! -e /sys/mckernel_sysfs_remote_verify
    printf 'MCKERNEL_SYSFS_REMOTE_CYCLE_PASS=%s\n' "$cycle"
done
echo MCKERNEL_SYSFS_REMOTE_GUEST_PASS
while :; do sleep 1; done
