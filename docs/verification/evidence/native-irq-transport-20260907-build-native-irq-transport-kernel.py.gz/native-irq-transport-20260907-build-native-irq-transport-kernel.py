from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, subprocess, sys
repo, work = Path('/workspace'), Path('/work')
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
source=work/'native-source/linux-6.12.0-211.44.1.el10_2'
build=work/'native-build-base-24a151fe'
prior=work/'native-startup-exact-stage-20260907-1'
out=work/('native-irq-transport-kernel-20260907-'+sys.argv[1])
out.mkdir()
patch=repo/'host-kernel/kbuild/patches/0005-irq-work-export-remote-queue-primitives.patch'
def identity(path):
    data=path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),inputs=[],results=[],production_gate_credit=False,mckernel_boot_proven=False,scope='source-bound generic Linux exports prototype; declared stage integration pending')
original={}
for relative in ['kernel/irq_work.c','mm/percpu.c']:
    path=source/relative
    original[relative]=path.read_bytes()
    record['inputs'].append(identity(path))
    copy=out/'original-source'/relative
    copy.parent.mkdir(parents=True,exist_ok=True)
    copy.write_bytes(original[relative])
for path in [build/'.config',build/'Module.symvers',prior/'kernel-build.command',prior/'module-build.command',patch,Path(__file__)]:
    record['inputs'].append(identity(path))
    shutil.copyfile(path,out/('before-'+path.name.lstrip('.')))
assert original['kernel/irq_work.c'].count(b'static DEFINE_PER_CPU(struct llist_head, raised_list);')==1
assert b'EXPORT_SYMBOL_GPL(per_cpu_ptr_to_phys)' not in original['mm/percpu.c']
assert (build/'.config').read_bytes()==(prior/'resolved.config').read_bytes()
commands=[(['git','-C',str(repo),'diff','--check'],repo),
          (['rustfmt','--check','--edition','2021','--config','skip_children=true',str(repo/'scripts/tests/fixtures/mckernel_irq_work_verify.rs')],repo),
          (['patch','--dry-run','--fuzz=0','-p1','-i',str(patch)],source),
          (['patch','--fuzz=0','-p1','-i',str(patch)],source),
          (shlex.split((prior/'kernel-build.command').read_text()),repo),
          (shlex.split((prior/'module-build.command').read_text()),repo)]
try:
    for index,(command,cwd) in enumerate(commands):
        print('Starting kernel validation step',index,flush=True)
        with (out/('step-'+str(index)+'.log')).open('wb') as log:
            result=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
        record['results'].append(dict(command=command,cwd=str(cwd),exit_code=result.returncode))
        if result.returncode: raise RuntimeError('Step '+str(index)+' failed with '+str(result.returncode))
        print('Completed kernel validation step',index,flush=True)
    expected=original['kernel/irq_work.c'].replace(b'static DEFINE_PER_CPU(struct llist_head, raised_list);',b'DEFINE_PER_CPU(struct llist_head, raised_list);\nEXPORT_PER_CPU_SYMBOL_GPL(raised_list);')
    assert (source/'kernel/irq_work.c').read_bytes()==expected
    assert (source/'mm/percpu.c').read_bytes().replace(b'\nEXPORT_SYMBOL_GPL(per_cpu_ptr_to_phys);',b'')==original['mm/percpu.c']
    record['patched_source']=[]
    for relative in original:
        target=out/'patched-source'/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/relative,target)
        record['patched_source'].append(identity(target))
    exports=(build/'Module.symvers').read_text()
    for symbol in ['raised_list','per_cpu_ptr_to_phys','irq_work_sync','__SCT__apic_call_send_IPI_mask']:
        matches=[line for line in exports.splitlines() if line.split()[1]==symbol]
        assert len(matches)==1 and matches[0].split()[3]=='EXPORT_SYMBOL_GPL', (symbol,matches)
    for source_path,name in [(build/'arch/x86/boot/bzImage','bzImage'),(build/'.config','resolved.config'),
                             (build/'Module.symvers','Module.symvers'),(build/'vmlinux.symvers','vmlinux.symvers'),
                             (build/'rust/bindings/bindings_generated.rs','bindings_generated.rs')]:
        shutil.copyfile(source_path,out/name)
    for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
        shutil.copyfile(build/'drivers/misc/mckernel'/name,out/name)
    record['outputs']=[identity(out/name) for name in ['bzImage','resolved.config','Module.symvers','vmlinux.symvers','bindings_generated.rs','ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']]
    record.update(status='PASS',only_existing_symbols_exported=True)
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record.get('status','FAIL'),out,flush=True)
