"""Retain native executable/credential adapters, all failures, and both guest ABIs."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-mcctrl-exec-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-mcctrl-exec-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),artifacts=[],captures=[],references=[],native_compiler_bindings=[],linux_compiler_bindings=[],applications_tested=False,production_gate_credit=False,declared_stage_integrated=False)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-mcctrl-service-checkpoint-20260908.json','native-guest-sysfs-checkpoint-20260908.json','storage-maintenance-20260908-5.json']:
        path=repo/'docs/verification'/name;state=json.loads(path.read_text());assert state['status']=='PASS'
        item=identity(path);item['path']=str(path.relative_to(repo));record['references'].append(item)
        for row in state['artifacts']:
            actual=identity(repo/row['path']);assert (actual['size'],actual['sha256'])==(row['size'],row['sha256']),row
            with gzip.open(repo/row['path'],'rb') as stream:
                while stream.read(1<<20):pass
    captures=[
        ('native-mcctrl-exec-module-20260908-1','FAIL'),
        ('native-mcctrl-exec-module-20260908-2','PASS'),
        ('native-mcctrl-exec-guest-20260908-x86_64-1','FAIL'),
        ('native-mcctrl-exec-guest-20260908-x86_64-2','FAIL'),
        ('native-mcctrl-exec-guest-20260908-x86_64-3','FAIL'),
        ('native-mcctrl-exec-guest-20260908-x86_64-4','PASS'),
        ('native-mcctrl-exec-guest-20260908-i386-1','PASS'),
    ]
    for name,expected in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        for item in state.get('captures',[]):
            for row in item['artifacts']:verify(row)
        artifact(capture,name+'.tar.gz',True)
        artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status=state['status'],error=state.get('error'),
            recorded_inputs=len(state.get('inputs',[])),recorded_compiler_inputs=len(state.get('compiler_inputs',[])),
            physical_captures=len(state.get('captures',[])),complete_capture_retained=True))
    compiled=work/'native-mcctrl-exec-module-20260908-2'
    replays=[]
    for saved in sorted((compiled/'staged-source').rglob('*.rs')):
        relative=saved.relative_to(compiled/'staged-source')
        current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if current.read_bytes()==saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs')
            shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            item=identity(current);item['path']=str(current.relative_to(repo))
            item.update(binding='Exact pinned rustfmt replay; original and formatted files retained',compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(item)
            replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'},replays
    for name in ['smp_trampoline.S','smp_startup_entry.S']:
        record['native_compiler_bindings'].append(binding(repo/'host-kernel/native-rust'/name,compiled/'staged-source'/name))
    assert len(record['native_compiler_bindings'])==43
    service_expected=dict(topology_queries=1056,contexts=4,workers=8,cycles=2,unload_vetoes=8,absent_rejections=6,unsupported_rejections=2,pre_ready_rejections=2,module_loads=5,module_unloads=5,application_execution=False)
    exec_expected=dict(credential_checks=259,credential_faults=3,file_checks=558,concurrent_callers=8,contexts=3,inherited_owner_isolation=True,final_release=True,procfs_exe_published=False,application_execution=False)
    for name in ['native-mcctrl-exec-guest-20260908-x86_64-4','native-mcctrl-exec-guest-20260908-i386-1']:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        assert state['full_ready_observed'] and state['observed_callback_exchanges']==130
        assert len(state['captures'])==2 and all(row['status']==3 for row in state['captures'])
        assert state['mcctrl_service']==service_expected
        assert state['mcctrl_executable']==exec_expected
        serial=(capture/'serial.log').read_text()
        before_summary=serial[:serial.index('NATIVE_SERVICE_GUEST PASS ready=1')]
        assert before_summary.count('mcctrl: application_service=registered abi=1')==6
        assert before_summary.count('mcctrl: application_service=unregistered abi=1')==6
        for saved in sorted((capture/'probe-source').iterdir()):
            record['linux_compiler_bindings'].append(binding(repo/'scripts/tests/fixtures'/saved.name,saved))
    assert len(record['linux_compiler_bindings'])==12
    artifact(out/'format-replay','native-mcctrl-exec-format-replay-20260908.tar.gz',True)
    reference_root=work/'native-source/linux-6.12.0-211.44.1.el10_2'
    record['linux_reference_sources']=[]
    for relative in ['fs/namei.c','fs/exec.c','fs/file_table.c','include/linux/fs.h','include/linux/cred.h','kernel/pid.c']:
        source=reference_root/relative
        saved=out/'linux-reference-sources'/relative;saved.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,saved)
        assert source.read_bytes()==saved.read_bytes()
        record['linux_reference_sources'].append(dict(source=identity(source),retained=identity(saved),
            scope='Exact pinned Linux review source for executable/path/error, file cleanup, write counter, current credentials or referenced process ID; not an additional runtime test'))
    artifact(out/'linux-reference-sources','native-mcctrl-exec-linux-reference-sources-20260908.tar.gz',True)
    for name in ['build-native-mcctrl-exec.py','run-native-mcctrl-exec.py']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-mcctrl-exec.py.gz')
    record['summary']=dict(native_modules=3,actual_starts=2,physical_ready_captures=4,
        credential_checks=518,credential_faults=6,executable_file_checks=1116,
        executable_contexts_opened_and_closed=6,executable_forked_workers_joined=16,
        inherited_owner_isolation_runs=2,final_file_retirement_runs=2,
        topology_queries=2112,service_contexts_opened_and_closed=8,service_workers_joined=16,
        module_loads_and_unloads=12,unload_vetoes=16,absent_rejections=12,
        pre_ready_rejections=4,unsupported_rejections=4,continuing_sysfs_callback_exchanges=260,
        read_checks=132,store_checks=128,guest_store_payload_checks=128,
        failed_captures_retained=4,exact_formatter_replays=3)
    record['empty_path_correction']=dict(failed_capture='/work/native-mcctrl-exec-guest-20260908-x86_64-3',
        file_check_index=9,incorrect_expected_errno=-2,correct_expected_errno=-13,
        explanation='getname_kernel accepts the empty name; path_init selects cwd, link_path_walk preserves LAST_ROOT, and may_open rejects MAY_EXEC on the directory with EACCES. Existing mcctrl calls the same Linux open_exec API. Only the fixture expectation changed; missing-file ENOENT and all other assertions remain.')
    record['limitations']=[
        'The real guest checks cover executable VFS ownership, caller credentials, file service/topology and a one-CPU normal-image boot. Native mcexec application execution has not run; procfs/exe publication, PPD/VM/pinning, launch packets and syscall forwarding remain open.',
        'Credential and replacement concurrency use separate four-worker fork phases on each ABI. This is not same-TGID pthread stress. The inherited-descriptor owner-isolation child explicitly closes its executable before exit.',
        'Native process retirement currently follows the final IHK file binding. Complete process-exit cleanup, including abrupt exit while another process keeps an inherited file open, remains part of the pending PPD/process lifecycle integration.',
        'All four first failures are preserved in full: missing error constant during build, rejected fixture symlink before boot, and two runtime captures of the incorrect empty-path errno expectation. Failed records with incomplete input lists are retained as captured; they do not receive current compiler-binding credit.',
        'Declared staging/source graph, lifecycle and unsafe-FFI inventory integration and a fresh full suite remain open. This prototype is bound to the exact retained Kbuild sources and guest probes; it does not promote a production gate.',
        'No new project C production bridge was added. Existing compatibility Rust/C consumers, guest image sources and launcher remain unchanged.',
        'Multi-CPU/multi-OS operation, remaining sysfs faults/races, shutdown, full Rust/assembly completion and independent production acceptance remain required by the original goal.',
    ]
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
