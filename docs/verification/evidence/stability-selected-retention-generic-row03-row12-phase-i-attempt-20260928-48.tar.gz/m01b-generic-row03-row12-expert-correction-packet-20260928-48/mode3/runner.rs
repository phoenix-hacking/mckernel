#![cfg(test)]
//! Mode-3-only, source-only host fixture crate.  It is never included by a
//! production module and Phase I never compiles or executes this file.
extern crate self as kernel;

pub mod bindings { pub unsafe fn ktime_get() -> i64 { 2_000_000_000 } }
#[macro_export]
macro_rules! pr_info { ($($arg:tt)*) => {{ let _ = format_args!($($arg)*); }} }

pub mod prelude {
    use core::ops::{Deref, DerefMut};

    #[derive(Clone, Debug, Default)]
    pub struct Vec<T>(std::vec::Vec<T>);
    impl<T> Vec<T> {
        pub fn with_capacity(capacity: usize, _flags: ()) -> Result<Self, ()> {
            let mut values = std::vec::Vec::new();
            values.try_reserve_exact(capacity).map_err(|_| ())?;
            Ok(Self(values))
        }
        pub fn push(&mut self, value: T, _flags: ()) -> Result<(), ()> {
            self.0.try_reserve(1).map_err(|_| ())?;
            self.0.push(value);
            Ok(())
        }
    }
    impl<T> Deref for Vec<T> {
        type Target = std::vec::Vec<T>;
        fn deref(&self) -> &Self::Target { &self.0 }
    }
    impl<T> DerefMut for Vec<T> {
        fn deref_mut(&mut self) -> &mut Self::Target { &mut self.0 }
    }
    impl<T> IntoIterator for Vec<T> {
        type Item = T;
        type IntoIter = std::vec::IntoIter<T>;
        fn into_iter(self) -> Self::IntoIter { self.0.into_iter() }
    }
    impl<'a, T> IntoIterator for &'a Vec<T> {
        type Item = &'a T;
        type IntoIter = core::slice::Iter<'a, T>;
        fn into_iter(self) -> Self::IntoIter { self.0.iter() }
    }
    impl<'a, T> IntoIterator for &'a mut Vec<T> {
        type Item = &'a mut T;
        type IntoIter = core::slice::IterMut<'a, T>;
        fn into_iter(self) -> Self::IntoIter { self.0.iter_mut() }
    }
    pub trait VecExt {}
    impl<T> VecExt for Vec<T> {}
    pub const GFP_KERNEL: () = ();
}

#[path = "source/application_rpc.rs"] mod application_rpc;
#[path = "source/application_syscall.rs"] mod application_syscall;
#[path = "source/smp_application_syscall.rs"] mod smp_application_syscall;
#[path = "source/stability_observer.rs"] mod stability_observer;
#[path = "source/stability_phase.rs"] mod stability_phase;
#[path = "adapter.rs"] pub mod selected_retention_test_adapter;
