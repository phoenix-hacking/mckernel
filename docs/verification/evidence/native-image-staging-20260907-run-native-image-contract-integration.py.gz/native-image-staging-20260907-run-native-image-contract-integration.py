from datetime import datetime, timezone
import hashlib, json, os
from pathlib import Path
import subprocess, sys, tarfile
repo = Path('/workspace')
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-image-contract-integration-20260907-' + str(int(sys.argv[1])))
out.mkdir()
groups = ['test_ihk_native_lifecycle_check', 'test_ihk_smp_native_lifecycle_check',
          'test_ihk_mapping_check', 'test_native_rust_unsafe_ffi_ledger',
          'test_ihk_os_runtime', 'test_ihk_smp_image', 'test_ihk_smp_resource']
if len(sys.argv) > 2:
    groups = sys.argv[2:]
paths = subprocess.check_output(['git', 'ls-files', 'host-kernel/native-rust',
    'host-kernel/kbuild', 'host-kernel/contracts', 'scripts/*.py', 'scripts/tests/*.py',
    'scripts/tests/fixtures/*.rs'], cwd=repo, text=True).splitlines()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(),
    source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    production_gate_credit=False, source_inputs=[dict(path=p, sha256=hashlib.sha256((repo/p).read_bytes()).hexdigest()) for p in paths], steps=[])
with tarfile.open(out/'source.tar.gz', 'w:gz') as archive:
    for p in paths:
        archive.add(repo/p, arcname=p, recursive=False)
commands = [
    ['python3', '-B', '-m', 'unittest', '-v', '-f'] + ['scripts.tests.' + name for name in groups],
    ['python3', '-B', 'scripts/ihk_mapping_check.py', '--repo', '/workspace', '--rustc', '/usr/bin/rustc', '--require-rustc'],
    ['python3', '-B', 'scripts/ihk_os_runtime_check.py', '--repo', '/workspace'],
    ['python3', '-B', 'scripts/native_rust_unsafe_ffi_ledger.py', '--repo', '/workspace', 'check'],
]
environment = dict(os.environ, MCKERNEL_RUSTC_1_92='/usr/bin/rustc')
code = 0
for index, command in enumerate(commands, 1):
    log = out/('step-%d.log' % index)
    with log.open('wb') as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    record['steps'].append(dict(command=command, exit_code=result.returncode, log=log.name))
    print('\n'.join(log.read_text().splitlines()[-35:]), flush=True)
    if result.returncode:
        code = result.returncode
        break
record.update(exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
(out/'record.json').write_text(json.dumps(record, indent=2)+'\n')
raise SystemExit(code)
