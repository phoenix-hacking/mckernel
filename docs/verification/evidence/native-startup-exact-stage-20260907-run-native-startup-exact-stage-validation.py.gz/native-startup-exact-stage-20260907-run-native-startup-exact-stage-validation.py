import subprocess
subprocess.run(['python3','-B','/work/check-native-startup-exact-stage-modules.py'],check=True)
subprocess.run(['python3','-B','/work/run-native-startup-declared-stage-guest.py','/work/native-startup-exact-stage-20260907-1','/work/native-startup-exact-stage-guest-20260907-1'],check=True)
subprocess.run(['python3','-B','/work/inventory-rust-consumers-startup-20260907.py'],check=True)
