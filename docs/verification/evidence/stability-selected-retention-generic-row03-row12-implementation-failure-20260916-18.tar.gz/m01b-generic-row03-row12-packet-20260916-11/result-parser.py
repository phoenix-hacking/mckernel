import json
EXPECTED={'row03':'Err(-11)','row12':'Ok(true)'}
def parse(path):
 with open(path,encoding='utf-8') as f: value=json.load(f)
 return all(value.get(k,{}).get('publish')==v for k,v in EXPECTED.items())
