"""Source/mock tests only. Synthetic retained bytes never count as runtime evidence."""
import copy, hashlib, importlib.util, json, os, stat, struct, tempfile, unittest
from pathlib import Path
from unittest import mock
HERE=Path(__file__).resolve().parent/'fixtures/application-collector-v1/linux-sealed-v1/adverse-v1'
def load(name):
    spec=importlib.util.spec_from_file_location('test_adverse_'+name,HERE/(name+'.py')); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
p=load('prepare'); oracle=load('oracle'); build=load('build_owner'); profile=load('root_profile')
def save(path,value): path.write_text(json.dumps(value,sort_keys=True)+'\n')
def fixture(root,case):
    """Explicit synthetic production-shaped records with real retained unit files."""
    for name in ('collection','outer','inputs','cwd'): (root/name).mkdir()
    n,status,failure,error,sig=oracle.EXPECTED[case]; ready=n==384
    exe=b'SYNTHETIC-UNIT-ELF-BYTES'; manifest=b'SYNTHETIC-UNIT-MANIFEST\n'
    wire=p.reviewed('run_collector_tests.py').request_wire(root/'inputs/fixture',root/'cwd',None,
             [b'literal-app',b'stdin-devnull'],[],manifest,exe,b'',b'x'*16)
    for name,raw in [('fixture',exe),('selected-inputs.json',manifest),('request.bin',wire)]: (root/'inputs'/name).write_bytes(raw)
    cwd=(root/'cwd').stat(); words=[0]*48; words[:18]=[0x314c4341,1,1,1,0,102,101,102,102,0,0,0,0,1,0,18,cwd.st_dev,cwd.st_ino]
    words[18:31]=[stat.S_IFCHR|0o666,1,3,stat.S_IFIFO|0o600,2,4,stat.S_IFIFO|0o600,2,5,3,6,15,0]
    words[31:38]=[0,1,1,0,0,0,1]
    events=[{'event':'collector-start','pid':101,'monotonic_ns':100},
            {'event':'child-created','pid':102,'startticks':20,'monotonic_ns':210},
            {'event':'leader-waitable','pid':102,'monotonic_ns':300},
            {'event':'actual-reap','pid':102,'raw_wait_status':0,'monotonic_ns':410},
            {'event':'collector-finish','first_failure':failure,'monotonic_ns':550}]
    data={'request.bin':wire,'selected-inputs.bin':manifest,'argv.nul':b'literal-app\0stdin-devnull\0','env.nul':b'',
          'events.jsonl':b''.join((json.dumps(x)+'\n').encode() for x in events),'executable.verified.bin':exe,
          'stdout.bin':b'DEVNULL\n' if ready else b'','stderr.bin':oracle.WITNESS[case] if not ready else b'',
          'setup.bin':struct.pack('<48Q',*words)[:n]}
    artifacts=[]
    for name in oracle.NAMES:
        if name is None: artifacts.append(None); continue
        raw=data[name]; (root/'collection'/name).write_bytes(raw)
        artifacts.append({'path':name,'attempted_name':name,'created':True,'fd_available':True,'creation_errno':0,'fd_errno':0,
                          'seen_bytes':len(raw),'stored_bytes':len(raw),'limit_bytes':65536,'truncated':False,'io_error':False,'sha256':oracle.digest(raw)})
    desired={'role':1,'request_profile':1,'uid':0,'gid':0,'group':0,'umask':18,'argc':2,'envc':0,'stdin_mode':0,
             'case_id_hex':b'infrastructure.collector'.hex(),'source_selector_hex':os.fsencode(root/'inputs/fixture').hex(),
             'cwd_hex':os.fsencode(root/'cwd').hex(),'stdin_selector_hex':b'/dev/null'.hex(),'attempt_id_hex':(b'x'*16).hex(),'selected_inputs_sha256':oracle.digest(manifest)}
    r={'schema_version':1,'kind':'linux-sealed-infrastructure-collection','status':status,'first_failure':failure,
       'first_failure_errno':error,'collector_interruption_signal':sig,'application_acceptance':False,'transport_acceptance':False,
       'backend_enabled':False,'request_valid':True,'child_created':True,'cleanup_complete':True,'group_identity_pinned':True,
       'owned_records_omitted':0,'owned_children':[],'setup_ready_record':ready,'setup_validated':ready,'setup_error_record':False,
       'post_exec_backing_observed':ready,'streams':{'stdout_eof':True,'stderr_eof':True,'setup_eof':True},'artifacts':artifacts,
       'stdin':{'artifact':None,'verified':False},'collector_pid':101,'linux_child':{'pid':102,'ppid':101,'startticks':20,
       'identity_observed':True,'reaped':True,'raw_wait_status':0,'wait':{'exited':True,'signaled':False,'exit_code':0,'signal':None,'core_dumped':False}},
       'desired':desired,'setup_words':words if ready else [0]*48,'executable':{'sealed_backing':{'device':3,'inode':6},'seals':15},
       'devnull_identity':{'mode':stat.S_IFCHR|0o666,'device':1,'inode':3},'preparation_start_ns':100,'preparation_deadline_ns':120000000100,
       'process_start_ns':200,'process_deadline_ns':10000000200,'completion_observed_ns':290,'cleanup_start_ns':400,
       'cleanup_deadline_ns':15000000400,'cleanup_finished_ns':500,'first_failure_monotonic_ns':350 if sig else 520}
    outer={'status':'COMPLETED','cleanup_complete':True,'raw_wait_status':0 if case=='control' else 256,
           'process':{'pid':101,'starttime_ticks':10},'streams':{}}
    for name in ('stdout','stderr'):
        raw=oracle.WITNESS[case] if sig and name=='stderr' else b''; (root/'outer'/(name+'.bin')).write_bytes(raw)
        outer['streams'][name]={'eof':True,'discarded_observed_bytes':0,'truncated':False,'bytes_retained':len(raw),'bytes_observed':len(raw),'artifact':{'sha256':oracle.digest(raw)}}
    save(root/'collection/report.json',r); save(root/'outer/report.json',outer); return r,outer
def change_artifact(root,r,name,raw):
    (root/'collection'/name).write_bytes(raw)
    row=next(x for x in r['artifacts'] if x is not None and x['path']==name)
    row.update(sha256=oracle.digest(raw),seen_bytes=len(raw),stored_bytes=len(raw)); save(root/'collection/report.json',r)

class AdversePacketTests(unittest.TestCase):
    def test_fixed_packet_source_header_patch(self):
        packet=p.packet(HERE/'packet.json'); self.assertFalse(packet['application_acceptance']); self.assertEqual(list(p.CASES.values()),[0,1,2,3])
        source=p.read(p.SOURCE); generated=p.generate(source)
        self.assertTrue(p.patch_is_applicable(source,generated,p.read(HERE/'collector.patch')))
        self.assertEqual(generated.count(b'm02_adverse_child_boundary(setup_fd, words);'),1)
        self.assertEqual(generated.count(b'm02_adverse_completed_wait_hook'),1)
        with self.assertRaises(ValueError): p.generate(source+b'\n')
        self.assertFalse(p.patch_is_applicable(source,generated,b'bad patch\n'))
        with mock.patch.object(p,'EXPECTED_PACKET','0'*64):
            with self.assertRaises(ValueError): p.packet(HERE/'packet.json')
        original=p.read
        for name in ('collector.patch','inject.h'):
            def tampered(path,maximum=16*1024**2): return original(path,maximum)+b'\n' if Path(path).name==name else original(path,maximum)
            with mock.patch.object(p,'read',side_effect=tampered):
                with self.assertRaises(ValueError): p.packet(HERE/'packet.json')
    def test_guarded_selector_zero_and_unknown(self):
        header=p.read(HERE/'inject.h').decode()
        for text in ('#ifndef M02_ADVERSE_TEST_ONLY','#ifndef M02_ADVERSE_CASE','#if M02_ADVERSE_CASE < 0 || M02_ADVERSE_CASE > 3','M02_ADVERSE_CASE == 0 || M02_ADVERSE_CASE == 3','M02_ADVERSE_CASE != 3','raise(SIGTERM)'):
            self.assertIn(text,header)
        for selector in range(4): self.assertEqual(build.flags(selector)[-2:],['-DM02_ADVERSE_TEST_ONLY=1','-DM02_ADVERSE_CASE='+str(selector)])
        for selector in (-1,4,True,None,'0'):
            with self.assertRaises(ValueError): build.flags(selector)
    def test_prepare_fresh_output_and_reuse_rejected(self):
        import sys
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'prepared'; argv=['prepare.py','--packet',str(HERE/'packet.json'),'--attempt-root',str(out)]
            with mock.patch.object(sys,'argv',argv): p.main()
            record=json.loads((out/'prepare.json').read_bytes()); self.assertEqual(record['status'],'PREPARED_NOT_EXECUTED')
            self.assertEqual(record['generated']['sha256'],p.digest((out/'adverse-collector.c').read_bytes()))
            with mock.patch.object(sys,'argv',argv):
                with self.assertRaises(ValueError): p.main()
    def test_four_real_layout_synthetic_positive_records(self):
        for case in p.CASES:
            with self.subTest(case=case), tempfile.TemporaryDirectory() as d:
                root=Path(d); r,_=fixture(root,case); self.assertIsNone(r['artifacts'][6]); self.assertTrue(oracle.validate_retained(root,case))
    def test_required_metadata_negative_matrix(self):
        mutations=[lambda r,o:r.update(status='COMPLETED'),lambda r,o:r.update(first_failure_errno=0),
                   lambda r,o:r.update(cleanup_complete=False),lambda r,o:r.update(group_identity_pinned=False),
                   lambda r,o:r['linux_child'].update(raw_wait_status=256),lambda r,o:o.update(raw_wait_status=0),
                   lambda r,o:r['linux_child'].update(startticks=0),lambda r,o:o['process'].update(pid=999),
                   lambda r,o:r['streams'].update(setup_eof=False),lambda r,o:o['streams']['stderr'].update(eof=False),
                   lambda r,o:r.update(completion_observed_ns=r['process_deadline_ns']),
                   lambda r,o:r.update(cleanup_finished_ns=r['cleanup_deadline_ns']),
                   lambda r,o:r.update(first_failure_monotonic_ns=1),lambda r,o:r['desired'].update(attempt_id_hex='00'*16),
                   lambda r,o:r['artifacts'].__setitem__(6,{}),lambda r,o:r.update(owned_records_omitted=1)]
        for index,mutate in enumerate(mutations):
            with self.subTest(index=index), tempfile.TemporaryDirectory() as d:
                root=Path(d); r,o=fixture(root,'interrupt-completed-wait'); mutate(r,o)
                save(root/'collection/report.json',r); save(root/'outer/report.json',o)
                self.assertFalse(oracle.validate(root,'interrupt-completed-wait'))
    def test_required_retained_byte_negative_matrix(self):
        cases=[('partial-setup','setup.bin',b'x'*382),('partial-setup','setup.bin',b'x'*383),
               ('partial-setup','stderr.bin',b''),('missing-setup','stderr.bin',b''),
               ('interrupt-completed-wait','stdout.bin',b'DEVNULL\\n'),('control','stdout.bin',b''),
               ('control','request.bin',b'bad'),('control','events.jsonl',b'{}\n')]
        for case,name,raw in cases:
            with self.subTest(case=case,name=name), tempfile.TemporaryDirectory() as d:
                root=Path(d); r,_=fixture(root,case); change_artifact(root,r,name,raw); self.assertFalse(oracle.validate(root,case))
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); fixture(root,'interrupt-completed-wait'); (root/'outer/stderr.bin').write_bytes(b'')
            self.assertFalse(oracle.validate(root,'interrupt-completed-wait'))
    def test_selector_zero_cannot_pass_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); r,o=fixture(root,'control'); r.update(status='SETUP_ERROR'); o.update(raw_wait_status=256)
            save(root/'collection/report.json',r); save(root/'outer/report.json',o); self.assertFalse(oracle.validate(root,'control'))
    def test_artifact_hash_and_symlink_rejection(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); fixture(root,'control'); (root/'collection/stdout.bin').write_bytes(b'DEVNULL!\n'); self.assertFalse(oracle.validate(root,'control'))
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); fixture(root,'control'); path=root/'collection/stdout.bin'; path.unlink(); path.symlink_to(root/'inputs/fixture'); self.assertFalse(oracle.validate(root,'control'))
    def test_owner_negative_boundaries_without_execution(self):
        owner=p.reviewed('root_orchestrator.py')
        self.assertFalse(owner.release_lock_allowed({'absence_verified':False},0))
        self.assertFalse(owner.release_lock_allowed({'absence_verified':True},256))
        self.assertTrue(owner.release_lock_allowed({'absence_verified':True},0))
        config={'container_id':'a'*64,'name':'mckernel-collector-'+'b'*32,'nonce':'b'*32}
        with self.assertRaises(ValueError): owner.owned({'Id':'c'*64},config)
        for field in ('Config','HostConfig'):
            with self.assertRaises((ValueError,KeyError,TypeError)): owner.full_inspect({field:{}},config,{})
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'record.json'; save(path,{'status':'PREPARED_NOT_EXECUTED'})
            with self.assertRaises((ValueError,KeyError)): profile.verify_build(path)
    def test_all_executable_modules_import_without_side_effects(self):
        for name in ('run','build_owner','root_profile','root_inside','root_orchestrator'): self.assertIsNotNone(load(name).main if name not in ('root_profile',) else load(name).create)

if __name__=='__main__': unittest.main(failfast=True)
