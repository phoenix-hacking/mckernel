#!/usr/bin/env python3
"""Exclusive attempt-4 source snapshot and single bounded unit invocation."""
import hashlib, json, os, shutil, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/holden/mckernel')
PREFIX=Path('scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/adverse-v1')
FILES=[PREFIX/name for name in ('packet.json','tests.md','prepare.py','collector.patch','inject.h','oracle.py','run.py','build_owner.py','root_profile.py','root_inside.py','root_orchestrator.py')]
FILES.append(Path('scripts/tests/test_collector_adverse_packet.py'))
def save(name,value):
    with (ROOT/name).open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
rows=[]
for relative in FILES:
    source=REPO/relative; target=ROOT/'candidate'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream:
        raw=source.read_bytes(); stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    rows.append({'path':str(relative),'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)})
save('pre-run-source-manifest.json',rows)
command=['python3','-I','-B','scripts/tests/test_collector_adverse_packet.py']
environment={'PATH':os.environ['PATH'],'LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1'}
save('command.json',{'argv':command,'cwd':str(REPO),'environment':environment,'environment_scope':'exact subprocess environment; no credentials inherited',
                     'resolved_python':shutil.which('python3',path=environment['PATH']),'timeout_seconds':120,'started_monotonic':time.monotonic()})
result={'status':'FAIL','started_monotonic':time.monotonic()}
with (ROOT/'stdout.bin').open('xb') as stdout, (ROOT/'stderr.bin').open('xb') as stderr:
    try:
        process=subprocess.run(command,cwd=REPO,env=environment,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120,check=False)
        result['returncode']=process.returncode
        if process.returncode==0: result['status']='PASS_UNIT_SOURCE_ONLY'
    except BaseException as error: result['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
result['finished_monotonic']=time.monotonic()
save('result.json',result)
if result['status']=='PASS_UNIT_SOURCE_ONLY':
    with (ROOT/'diff-check.stdout.bin').open('xb') as stdout, (ROOT/'diff-check.stderr.bin').open('xb') as stderr:
        diff=subprocess.run(['git','diff','--check'],cwd=REPO,env=environment,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=30,check=False)
    save('diff-check-result.json',{'argv':['git','diff','--check'],'returncode':diff.returncode})
print(json.dumps(result,sort_keys=True))
