from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, socket, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
compiled = Path('/work/native-sysfs-setup-module-20260907-' + sys.argv[1])
out = Path('/work/native-sysfs-setup-guest-20260907-' + sys.argv[2]); out.mkdir()
kernel = Path('/work/native-topology-kernel-20260907-1')
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', '/workspace', 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], commands=[], production_gate_credit=False, sysfs_service_completed=False,
    mckernel_boot_proven=False, declared_stage=False, cpus=4, memory_mib=8192,
    container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)))
process = None
stream = None

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command, env=None):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-6000:])

sequence = 0
def qmp(command):
    global sequence
    sequence += 1
    stream.write((json.dumps(dict(execute=command, id=sequence)) + '\n').encode()); stream.flush()
    while True:
        line = stream.readline()
        assert line, 'QMP disconnected'
        response = json.loads(line)
        if response.get('id') != sequence: continue
        assert 'error' not in response, response
        return response['return']

try:
    shutil.copyfile(__file__, out / 'helper.py')
    built = json.loads((compiled / 'record.json').read_text())
    assert built['status'] == 'PASS'
    for row in built['inputs'] + built['compiler_inputs'] + built['outputs']:
        assert identity(Path(row['path'])) == row, row
    record['inputs'] += [identity(compiled / 'record.json'), identity(kernel / 'bzImage')]
    root = out / 'root'
    base_root = Path('/work/native-runtime-local-base-24a151fe/root')
    record['inputs'] += [identity(path) for path in sorted(base_root.rglob('*')) if path.is_file()]
    shutil.copytree(base_root, root)
    copies = [(compiled / 'mckernel_sysfs_setup_verify.ko', root / 'modules/mckernel_sysfs_setup_verify.ko'),
              (Path('/usr/bin/sleep'), root / 'bin/sleep')]
    for source, destination in copies:
        record['inputs'].append(identity(source)); shutil.copy2(source, destination)
    (root / 'init').write_text(Path('/work/native-sysfs-setup-guest-init.sh').read_text())
    record['inputs'] += [identity(Path('/work/native-sysfs-setup-guest-init.sh')), identity(Path('/work/native-sysfs-setup-guest-validation.inc'))]
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    generator = Path('/work/write-native-cpio-spec.py')
    record['inputs'].append(identity(generator))
    run('initramfs-spec', ['python3', '-B', str(generator)], dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root)))
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            creator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(creator.stdout, output); creator.stdout.close(); assert creator.wait() == 0
    record['inputs'] += [identity(out / 'initramfs.cpio.gz'), identity(root / 'init')]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
            '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(kernel / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args; save()
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20); connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            for bad in ['Call Trace:', 'MCKERNEL_SYSFS_SETUP_GUEST_FAIL', 'Assertion ', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
                assert bad not in serial, bad
            if 'MCKERNEL_SYSFS_SETUP_GUEST_PASS' in serial:
                qmp('quit'); process.wait(timeout=15); break
            state = qmp('query-status')
            assert state['status'] not in ('shutdown', 'guest-panicked'), state
            time.sleep(0.1)
        assert process.returncode == 0
    serial = (out / 'serial.log').read_text(errors='replace')
    ready = re.findall(r'MCKERNEL_SYSFS_SETUP_VERIFY READY nodes=(\d+) comparison_checks=22 rollback=1 duplicate_preserved=1 ranks=3,1', serial)
    assert len(ready) == 2 and ready[0] == ready[1], ready
    assert serial.count('MCKERNEL_SYSFS_SETUP_CYCLE_PASS=') == 2
    host = {(int(cpu),field):value for cpu,field,value in re.findall(r'^SETUP_HOST cpu=(\d+) field=(\w+) value=([^\n]+)$',serial,re.M)}
    caches = {(int(cpu),int(index),field):value for cpu,index,field,value in re.findall(r'^SETUP_CACHE cpu=(\d+) index=(\d+) field=(\w+) value=([^\n]+)$',serial,re.M)}
    distances = {int(node):value for node,value in re.findall(r'^SETUP_NODE node=(\d+) distance=([^\n]+)$',serial,re.M)}
    assert len(host) == 16 and set(distances) == {0,1}
    ranks = [3,1]
    def bitmap(value): return int(value.replace(',',''),16)
    def translate(value): return sum(1<<rank for rank,cpu in enumerate(ranks) if bitmap(value) & (1<<cpu))
    def listing(mask):
        # The two fixture ranks yield all four independent list cases.
        return {0:'\n',1:'0\n',2:'1\n',3:'0-1\n'}[mask]
    expected = {'/sys/test/a.dir/a_value':'35\n'}
    for name in ('online','possible','present'): expected['/sys/devices/system/cpu/'+name]='0-1\n'
    expected['/sys/devices/system/cpu/offline']='\n'
    for rank,cpu in enumerate(ranks):
        prefix='/sys/devices/system/cpu/cpu'+str(rank)
        for name in ('physical_package_id','core_id'): expected[prefix+'/topology/'+name]=host[(cpu,name)]+'\n'
        for name in ('core_siblings','thread_siblings'):
            mask=translate(host[(cpu,name)])
            expected[prefix+'/topology/'+name]=format(mask,'x')+'\n'
            expected[prefix+'/topology/'+name+'_list']=listing(mask)
        indices={index for c,index,field in caches if c==cpu}
        assert indices == {0,1,2,3}, indices
        for index in indices:
            path=prefix+'/cache/index'+str(index)
            for name in ('level','type','size','coherency_line_size','number_of_sets','physical_line_partition','ways_of_associativity'):
                expected[path+'/'+name]=caches[(cpu,index,name)]+'\n'
            mask=translate(caches[(cpu,index,'shared_cpu_map')])
            expected[path+'/shared_cpu_map']=format(mask,'x')+'\n'
            expected[path+'/shared_cpu_list']=listing(mask)
    for name in ('online','possible'): expected['/sys/devices/system/node/'+name]='0-1\n'
    expected_links={'/sys/test/L.dir'}
    for node in (0,1):
        prefix='/sys/devices/system/node/node'+str(node)
        expected[prefix+'/distance']=distances[node]+'\n'
        mask=1<<(1-node)
        expected[prefix+'/cpumap']=format(mask,'x')+'\n'
        expected[prefix+'/cpulist']=listing(mask)
        expected_links.update(['/sys/bus/node/devices/node'+str(node),prefix+'/cpu'+str(1-node),'/sys/devices/system/cpu/cpu'+str(1-node)+'/node'+str(node)])
    expected_dirs={'/sys','/sys/setup_complete'}
    for path in set(expected)|expected_links:
        parent=str(Path(path).parent)
        while parent != '/': expected_dirs.add(parent); parent=str(Path(parent).parent)
    files={}
    for cycle,phase,path,value in re.findall(r'^SETUP_FILE cycle=(\d+) phase=(\w+) path=(\S+) BEGIN\n(.*?)SETUP_FILE_END$',serial,re.M|re.S):
        key=(int(cycle),phase,path); assert key not in files,key; files[key]=value
    directory_rows=re.findall(r'^SETUP_DIR cycle=(\d+) phase=(\w+) path=(\S+)$',serial,re.M)
    link_rows=re.findall(r'^SETUP_LINK cycle=(\d+) phase=(\w+) path=(\S+)$',serial,re.M)
    for cycle in (1,2):
        for phase in ('before','offline','restored'):
            actual={path:value for (c,p,path),value in files.items() if (c,p)==(cycle,phase)}
            assert actual==expected, (cycle,phase,{path:(actual.get(path),value) for path,value in expected.items() if actual.get(path)!=value},set(actual)-set(expected))
            dirs=[path for c,p,path in directory_rows if (int(c),p)==(cycle,phase)]
            links=[path for c,p,path in link_rows if (int(c),p)==(cycle,phase)]
            assert len(dirs)==len(set(dirs)) and set(dirs)==expected_dirs, (dirs,expected_dirs)
            assert len(links)==len(set(links)) and set(links)==expected_links, (links,expected_links)
    assert int(ready[0])==1+len(expected_dirs)+len(expected_links)+len(expected)
    for row in record['inputs']: assert identity(Path(row['path']))==row,row
    record.update(status='PASS',module_cycles=2,topology_comparison_checks=44,rollback_cycles=2,
        setup_files=len(expected),setup_directories=len(expected_dirs),setup_links=len(expected_links),file_read_checks=len(files),
        linux_cpu_offline_online_cycles=4,namespace_removed=True,
        scope='Actual Linux setup files, rank translation, error rollback and byte-identical reads across CPU transitions; production guest setup request still needs real boot verification')
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
    if stream is not None: stream.close()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name != 'record.json']
    save(); print(record['status'], out, flush=True)
