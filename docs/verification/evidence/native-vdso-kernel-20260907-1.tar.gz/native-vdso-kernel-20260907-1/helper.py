"""Expose Linux's existing vDSO objects; retain exact layout and build evidence."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
kernel = Path('/work/native-apic-bindings-kernel-20260907-1')
out = Path('/work/native-vdso-kernel-20260907-' + sys.argv[1])
out.mkdir()
patch = repo / 'host-kernel/kbuild/patches/0008-rust-expose-existing-x86-vdso-data.patch'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    commands=[], inputs=[], production_gate_credit=False, vdso_service_completed=False,
    scope='Existing Linux vDSO data exports/bindings and exact configured layout; no guest service response yet')

def identity(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): value.update(data)
    return dict(path=str(path), size=path.stat().st_size, sha256=value.hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-14000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(patch, out / patch.name)
    record['inputs'].append(identity(patch))
    targets = ['arch/x86/entry/vdso/vma.c', 'lib/vdso/datastore.c', 'rust/bindings/bindings_helper.h']
    headers = ['include/vdso/datapage.h', 'arch/x86/include/asm/vdso.h',
               'arch/x86/include/asm/vdso/vsyscall.h', 'arch/x86/include/asm/vdso/gettimeofday.h',
               'include/vdso/clocksource.h', 'arch/x86/include/asm/vdso/clocksource.h']
    for relative in targets + headers:
        target = out / 'before' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    shutil.copyfile(build / 'rust/bindings/bindings_generated.rs', out / 'before-bindings_generated.rs')
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check', 'HEAD'])
    run('patch-check', ['patch', '-d', str(source), '-p1', '--batch', '--dry-run', '--fuzz=0', '-i', str(patch)])
    run('patch-apply', ['patch', '-d', str(source), '-p1', '--batch', '--fuzz=0', '-i', str(patch)])
    for relative in targets:
        target = out / 'after' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    witness = out / 'witness'
    witness.mkdir()
    fixture = repo / 'scripts/tests/fixtures/native_vdso_layout.c'
    shutil.copyfile(fixture, witness / fixture.name)
    record['inputs'].append(identity(fixture))
    (witness / 'Kbuild').write_text('obj-m += native_vdso_layout.o\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('layout-witness', base + ['M=' + str(witness), 'native_vdso_layout.o'])
    binary = out / 'native-vdso-layout.bin'
    run('extract-layout', ['objcopy', '--dump-section', '.mckernel_native_vdso_layout=' + str(binary),
                          str(witness / 'native_vdso_layout.o'), str(out / 'layout-copy.o')])
    actual = list(struct.unpack('<' + str(binary.stat().st_size // 8) + 'Q', binary.read_bytes()))
    expected = [4096, 6, 4, 2, 0, 1, 2, 3, 0, 1, 0, 8,
                16, 8, 0, 8, 232, 8, 0, 4, 8, 16, 24, 32, 36, 40,
                12, 2, 0, 1, 512, 64, 0, 464, 468, 472, 16, 8, 0, 8, 0, 1, 2, 3]
    record['layout'] = dict(actual=actual, expected=expected)
    save()
    assert actual == expected, ('exact vDSO layout', actual)
    run('kernel-build', shlex.split((prior / 'kernel-build.command').read_text()))
    run('existing-prototype-module-build', shlex.split((prior / 'module-build.command').read_text()))
    for relative, name in [('.config', 'resolved.config'), ('Module.symvers', 'Module.symvers'),
                           ('arch/x86/boot/bzImage', 'bzImage'),
                           ('rust/bindings/bindings_generated.rs', 'bindings_generated.rs')]:
        shutil.copyfile(build / relative, out / name)
    shutil.copyfile(build / 'arch/x86/entry/vdso/vdso-image-64.c', out / 'vdso-image-64.c')
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(build / 'drivers/misc/mckernel' / name, out / name)
    binding = (out / 'bindings_generated.rs').read_text()
    for name in ('vdso_image', 'vdso_clock', 'vdso_time_data', 'vdso_rng_data'):
        assert 'pub struct ' + name + ' {' in binding, name
    for name in ('vdso_image_64', 'vdso_k_time_data', 'vdso_k_rng_data'):
        assert name + ':' in binding, name
        assert any(line.split()[1:4] == [name, 'vmlinux', 'EXPORT_SYMBOL_GPL']
                   for line in (out / 'Module.symvers').read_text().splitlines()), name
    assert '.size = 8192,' in (out / 'vdso-image-64.c').read_text()
    assert (out / 'resolved.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    shutil.copytree(source / 'drivers/misc/mckernel', out / 'staged-source')
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name not in ('record.json', 'phase')]
    save()
    print(record['status'], out, flush=True)
