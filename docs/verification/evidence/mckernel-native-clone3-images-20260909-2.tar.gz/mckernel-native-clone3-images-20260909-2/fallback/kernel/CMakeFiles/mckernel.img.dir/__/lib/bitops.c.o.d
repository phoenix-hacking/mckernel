kernel/CMakeFiles/mckernel.img.dir/__/lib/bitops.c.o: \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/bitops.c \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/include/bitops.h \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/include/types.h \
 /work/mckernel-native-clone3-images-20260909-2/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/include/bitops-test_bit.h \
 /work/mckernel-native-clone3-images-20260909-2/source/arch/x86_64/kernel/include/arch-bitops.h
