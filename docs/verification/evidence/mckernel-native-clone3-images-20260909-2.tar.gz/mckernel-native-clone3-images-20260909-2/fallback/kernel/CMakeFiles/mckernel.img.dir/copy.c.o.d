kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-clone3-images-20260909-2/source/kernel/copy.c
