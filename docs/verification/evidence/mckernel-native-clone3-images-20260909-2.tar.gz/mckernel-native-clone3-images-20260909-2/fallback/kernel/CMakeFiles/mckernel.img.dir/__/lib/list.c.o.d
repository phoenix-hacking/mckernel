kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o: \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/list.c \
 /work/mckernel-native-clone3-images-20260909-2/source/lib/include/list.h
