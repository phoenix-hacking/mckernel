/work/mckernel-native-clone3-images-20260909-2/invalid-sysfs-legacy/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-clone3-images-20260909-2/invalid-sysfs-legacy/tmp.resolve_MODULES_END/driver.o

