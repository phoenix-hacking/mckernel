#![no_std]
#[path="/home/holden/mckernel-work/host-preparation/evening-next-rust-teardown-20261019-1/original/kernel/rust/abi.rs"] mod abi;
use core::ffi::c_void;
use core::mem::{offset_of,size_of};
use abi::{CInt,CULong,Process,Thread};
mod debug { #[repr(C)]
pub struct Ddebug {
    pub file: *const i8,
    pub func: *const i8,
    pub fmt: *const i8,
    pub line_flags: u32,
}
 }
type ProcessTidLogFn=unsafe extern "C" fn(CInt,*mut c_void,CInt);
extern "C" {fn kprintf(format:*const i8,...)->CInt;}
#[no_mangle]
pub unsafe extern "C" fn process_tid_index_for_thread_result(
    tids: *const c_void,
    nr_tids: CInt,
    entry_stride: CULong,
    thread_offset: CULong,
    thread_addr: CULong,
) -> CInt {
    if tids.is_null() || nr_tids <= 0 || entry_stride == 0 || thread_addr == 0 {
        return -1;
    }

    let base = tids.cast::<u8>();
    let stride = entry_stride as usize;
    let offset = thread_offset as usize;

    for index in 0..(nr_tids as usize) {
        let entry = base.add(index.saturating_mul(stride).saturating_add(offset));
        let stored = *(entry.cast::<CULong>());
        if stored == thread_addr {
            return index as CInt;
        }
    }

    -1
}
#[no_mangle]
pub extern "C" fn process_tid_index_found_result(index: CInt) -> CInt {
    (index >= 0) as CInt
}
fn checked_entry_addr(
    base: *mut c_void,
    index: CInt,
    entry_stride: CULong,
    member_offset: CULong,
) -> Option<*mut u8> {
    if base.is_null() || index < 0 || entry_stride == 0 {
        return None;
    }

    let offset = (index as usize)
        .checked_mul(entry_stride as usize)?
        .checked_add(member_offset as usize)?;
    Some(base.cast::<u8>().wrapping_add(offset))
}
#[no_mangle]
pub unsafe extern "C" fn process_tid_replace_slot_result(
    tids: *mut c_void,
    index: CInt,
    entry_stride: CULong,
    tid_offset: CULong,
    thread_offset: CULong,
    new_tid: CInt,
) -> CInt {
    let Some(tid_slot) = checked_entry_addr(tids, index, entry_stride, tid_offset) else {
        return 0;
    };
    let Some(thread_slot) = checked_entry_addr(tids, index, entry_stride, thread_offset) else {
        return 0;
    };

    *(thread_slot.cast::<CULong>()) = 0;
    *(tid_slot.cast::<CInt>()) = new_tid;
    1
}
#[no_mangle]
pub unsafe extern "C" fn process_tid_log_result(
    old_tid: CInt,
    thread: *mut c_void,
    new_tid: CInt,
    log_fn: Option<ProcessTidLogFn>,
) -> CInt {
    let Some(log) = log_fn else {
        return 0;
    };

    log(old_tid, thread, new_tid);
    1
}
#[no_mangle]
pub unsafe extern "C" fn process_replace_tid_body_result(
    tids: *mut c_void,
    nr_tids: CInt,
    tid_stride: CULong,
    tid_offset: CULong,
    tid_thread_offset: CULong,
    thread: *mut c_void,
    old_tid: CInt,
    new_tid: CInt,
    log_fn: Option<ProcessTidLogFn>,
) -> CInt {
    if tids.is_null() || thread.is_null() {
        return 0;
    }

    let index = process_tid_index_for_thread_result(
        tids,
        nr_tids,
        tid_stride,
        tid_thread_offset,
        thread as CULong,
    );
    if process_tid_index_found_result(index) == 0 {
        return 0;
    }
    if process_tid_replace_slot_result(
        tids,
        index,
        tid_stride,
        tid_offset,
        tid_thread_offset,
        new_tid,
    ) == 0
    {
        return 0;
    }

    let _ = process_tid_log_result(old_tid, thread, new_tid, log_fn);
    1
}

// Preserve the existing optional dynamic-debug event, including its format bytes.
#[used]
#[link_section = "__verbose"]
static mut REPLACE_TID_DEBUG: crate::debug::Ddebug = crate::debug::Ddebug {
    file: concat!(file!(), "\0").as_ptr().cast(),
    func: b"process_replace_tid_log_bridge\0".as_ptr().cast(),
    fmt: core::ptr::null(),
    line_flags: line!() & 0x00ff_ffff,
};

unsafe extern "C" fn process_replace_tid_log_bridge(
    tid: CInt, thread: *mut c_void, new_tid: CInt,
) {
    let flags = unsafe {
        core::ptr::read_volatile(core::ptr::addr_of!(REPLACE_TID_DEBUG.line_flags)) >> 24
    };
    if flags != 0 {
        unsafe {
            kprintf(
                b"%s: tid %d (thread %p) has been relaced with tid %d\n\0".as_ptr().cast(),
                b"__find_and_replace_tid\0".as_ptr().cast::<i8>(), tid, thread, new_tid,
            );
        }
    }
}

const _: () = {
    assert!(offset_of!(Process, tids) == 256);
    assert!(offset_of!(Process, nr_tids) == 264);
    assert!(offset_of!(Thread, tid) == 20);
    assert!(size_of::<crate::abi::McexecTid>() == 16);
    assert!(offset_of!(crate::abi::McexecTid, tid) == 0);
    assert!(offset_of!(crate::abi::McexecTid, thread) == 8);
};

/// Replace the first slot owned by this live thread while threads_lock is held.
/// The caller keeps process, thread and its positive-count TID array live and
/// excludes concurrent or reentrant slot changes. Null tables are permitted.
/// The existing helper clears the matched pointer before writing the new numeric
/// TID, then logs; it never changes thread.tid or frees/references thread storage.
/// Unmatched entries, slot padding and later duplicate pointers are preserved.
#[no_mangle]
pub unsafe extern "C" fn __find_and_replace_tid(
    proc: *mut Process, thread: *mut Thread, new_tid: CInt,
) {
    let _ = unsafe {
        process_replace_tid_body_result(
            (*proc).tids, (*proc).nr_tids,
            size_of::<crate::abi::McexecTid>() as CULong,
            offset_of!(crate::abi::McexecTid, tid) as CULong,
            offset_of!(crate::abi::McexecTid, thread) as CULong,
            thread.cast(), (*thread).tid, new_tid, Some(process_replace_tid_log_bridge),
        )
    };
}
