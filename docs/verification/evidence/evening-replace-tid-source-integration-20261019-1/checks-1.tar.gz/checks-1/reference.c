#ifndef IHK_DEBUG_H
#define IHK_DEBUG_H

#define __aligned(n) __attribute__((aligned(n)))

void panic(const char *);

/* when someone has a lot of time, add attribute __printf(1, 2) to kprintf */
int kprintf(const char *format, ...);
unsigned long kprintf_lock(void);
void kprintf_unlock(unsigned long irqflags);
int __kprintf(const char *format, ...);

struct ddebug {
	const char *file;
	const char *func;
	const char *fmt;
	unsigned int line:24;
	unsigned int flags:8;
} __aligned(8);

#define DDEBUG_NONE  0x0
#define DDEBUG_PRINT 0x1

#define DDEBUG_DEFAULT DDEBUG_NONE

#define dkprintf(fmt, args...)        \
do {                                  \
	static struct ddebug __aligned(8) \
	__attribute__((section("__verbose"))) ddebug = { \
		.file = __FILE__,        \
		.func = __func__,        \
		.line = __LINE__,        \
		.flags = DDEBUG_DEFAULT, \
	};                            \
	if (ddebug.flags)             \
		kprintf(fmt, ##args); \
} while (0)
#define ekprintf(fmt, args...) kprintf(fmt, ##args)

#define BUG_ON(condition) do {                         \
	if (condition) {                               \
		kprintf("PANIC: %s: %s(line:%d)\n",    \
			__FILE__, __func__, __LINE__); \
		panic("");                             \
	}                                              \
} while (0)

#endif

#include <stddef.h>
 struct thread {unsigned char pad[20];int tid;};
 struct mcexec_tid {int tid;int padding;struct thread *thread;};
 struct process {unsigned char pad[256];struct mcexec_tid *tids;int nr_tids;};
 typedef void (*process_tid_log_fn_t)(int,void*,int);
 extern int process_replace_tid_body_result(void *,int,unsigned long,unsigned long,unsigned long,void *,int,int,process_tid_log_fn_t);
 static void process_replace_tid_log_bridge(int tid, void *thread, int new_tid)
{
	dkprintf("%s: tid %d (thread %p) has been relaced with tid %d\n",
		"__find_and_replace_tid", tid, thread, new_tid);
}

#define __find_and_replace_tid c_reference
void __find_and_replace_tid(struct process *proc, struct thread *thread, int new_tid) {
	process_replace_tid_body_result(proc->tids, proc->nr_tids,
		sizeof(proc->tids[0]),
		__builtin_offsetof(struct mcexec_tid, tid),
		__builtin_offsetof(struct mcexec_tid, thread),
		thread, thread->tid, new_tid, process_replace_tid_log_bridge);
}

#undef __find_and_replace_tid
 #include <stdarg.h>
 extern void record_log(const char*,const char*,int,void*,int);
 int kprintf(const char *fmt,...) {va_list a;va_start(a,fmt);const char *func=va_arg(a,const char*);int tid=va_arg(a,int);void *thread=va_arg(a,void*);int new_tid=va_arg(a,int);va_end(a);record_log(fmt,func,tid,thread,new_tid);return 0;}
 