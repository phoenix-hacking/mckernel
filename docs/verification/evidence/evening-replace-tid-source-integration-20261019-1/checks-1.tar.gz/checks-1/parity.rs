#[path="/home/holden/mckernel-work/host-preparation/evening-next-rust-teardown-20261019-1/original/kernel/rust/abi.rs"] mod abi;
use core::ffi::c_void;
use core::mem::{offset_of,size_of};
use abi::{CInt,CULong,Process,Thread};
mod debug { #[repr(C)]
pub struct Ddebug {
    pub file: *const i8,
    pub func: *const i8,
    pub fmt: *const i8,
    pub line_flags: u32,
}
 }
type ProcessTidLogFn=unsafe extern "C" fn(CInt,*mut c_void,CInt);
extern "C" {fn kprintf(format:*const i8,...)->CInt;}
#[no_mangle]
pub unsafe extern "C" fn process_tid_index_for_thread_result(
    tids: *const c_void,
    nr_tids: CInt,
    entry_stride: CULong,
    thread_offset: CULong,
    thread_addr: CULong,
) -> CInt {
    if tids.is_null() || nr_tids <= 0 || entry_stride == 0 || thread_addr == 0 {
        return -1;
    }

    let base = tids.cast::<u8>();
    let stride = entry_stride as usize;
    let offset = thread_offset as usize;

    for index in 0..(nr_tids as usize) {
        let entry = base.add(index.saturating_mul(stride).saturating_add(offset));
        let stored = *(entry.cast::<CULong>());
        if stored == thread_addr {
            return index as CInt;
        }
    }

    -1
}
#[no_mangle]
pub extern "C" fn process_tid_index_found_result(index: CInt) -> CInt {
    (index >= 0) as CInt
}
fn checked_entry_addr(
    base: *mut c_void,
    index: CInt,
    entry_stride: CULong,
    member_offset: CULong,
) -> Option<*mut u8> {
    if base.is_null() || index < 0 || entry_stride == 0 {
        return None;
    }

    let offset = (index as usize)
        .checked_mul(entry_stride as usize)?
        .checked_add(member_offset as usize)?;
    Some(base.cast::<u8>().wrapping_add(offset))
}
#[no_mangle]
pub unsafe extern "C" fn process_tid_replace_slot_result(
    tids: *mut c_void,
    index: CInt,
    entry_stride: CULong,
    tid_offset: CULong,
    thread_offset: CULong,
    new_tid: CInt,
) -> CInt {
    let Some(tid_slot) = checked_entry_addr(tids, index, entry_stride, tid_offset) else {
        return 0;
    };
    let Some(thread_slot) = checked_entry_addr(tids, index, entry_stride, thread_offset) else {
        return 0;
    };

    *(thread_slot.cast::<CULong>()) = 0;
    *(tid_slot.cast::<CInt>()) = new_tid;
    1
}
#[no_mangle]
pub unsafe extern "C" fn process_tid_log_result(
    old_tid: CInt,
    thread: *mut c_void,
    new_tid: CInt,
    log_fn: Option<ProcessTidLogFn>,
) -> CInt {
    let Some(log) = log_fn else {
        return 0;
    };

    log(old_tid, thread, new_tid);
    1
}
#[no_mangle]
pub unsafe extern "C" fn process_replace_tid_body_result(
    tids: *mut c_void,
    nr_tids: CInt,
    tid_stride: CULong,
    tid_offset: CULong,
    tid_thread_offset: CULong,
    thread: *mut c_void,
    old_tid: CInt,
    new_tid: CInt,
    log_fn: Option<ProcessTidLogFn>,
) -> CInt {
    if tids.is_null() || thread.is_null() {
        return 0;
    }

    let index = process_tid_index_for_thread_result(
        tids,
        nr_tids,
        tid_stride,
        tid_thread_offset,
        thread as CULong,
    );
    if process_tid_index_found_result(index) == 0 {
        return 0;
    }
    if process_tid_replace_slot_result(
        tids,
        index,
        tid_stride,
        tid_offset,
        tid_thread_offset,
        new_tid,
    ) == 0
    {
        return 0;
    }

    let _ = process_tid_log_result(old_tid, thread, new_tid, log_fn);
    1
}

// Preserve the existing optional dynamic-debug event, including its format bytes.
#[used]
#[link_section = "__verbose"]
static mut REPLACE_TID_DEBUG: crate::debug::Ddebug = crate::debug::Ddebug {
    file: concat!(file!(), "\0").as_ptr().cast(),
    func: b"process_replace_tid_log_bridge\0".as_ptr().cast(),
    fmt: core::ptr::null(),
    line_flags: line!() & 0x00ff_ffff,
};

unsafe extern "C" fn process_replace_tid_log_bridge(
    tid: CInt, thread: *mut c_void, new_tid: CInt,
) {
    let flags = unsafe {
        core::ptr::read_volatile(core::ptr::addr_of!(REPLACE_TID_DEBUG.line_flags)) >> 24
    };
    if flags != 0 {
        unsafe {
            kprintf(
                b"%s: tid %d (thread %p) has been relaced with tid %d\n\0".as_ptr().cast(),
                b"__find_and_replace_tid\0".as_ptr().cast::<i8>(), tid, thread, new_tid,
            );
        }
    }
}

const _: () = {
    assert!(offset_of!(Process, tids) == 256);
    assert!(offset_of!(Process, nr_tids) == 264);
    assert!(offset_of!(Thread, tid) == 20);
    assert!(size_of::<crate::abi::McexecTid>() == 16);
    assert!(offset_of!(crate::abi::McexecTid, tid) == 0);
    assert!(offset_of!(crate::abi::McexecTid, thread) == 8);
};

/// Replace the first slot owned by this live thread while threads_lock is held.
/// The caller keeps process, thread and its positive-count TID array live and
/// excludes concurrent or reentrant slot changes. Null tables are permitted.
/// The existing helper clears the matched pointer before writing the new numeric
/// TID, then logs; it never changes thread.tid or frees/references thread storage.
/// Unmatched entries, slot padding and later duplicate pointers are preserved.
#[no_mangle]
pub unsafe extern "C" fn __find_and_replace_tid(
    proc: *mut Process, thread: *mut Thread, new_tid: CInt,
) {
    let _ = unsafe {
        process_replace_tid_body_result(
            (*proc).tids, (*proc).nr_tids,
            size_of::<crate::abi::McexecTid>() as CULong,
            offset_of!(crate::abi::McexecTid, tid) as CULong,
            offset_of!(crate::abi::McexecTid, thread) as CULong,
            thread.cast(), (*thread).tid, new_tid, Some(process_replace_tid_log_bridge),
        )
    };
}

use std::ffi::CStr;
use abi::McexecTid;
static mut EVENTS:Vec<(i32,usize,i32,Vec<(i32,usize)>)>=Vec::new();
static mut SLOTS:*mut McexecTid=std::ptr::null_mut();
static mut LEN:usize=0;
extern "C" {fn c_reference(p:*mut Process,t:*mut Thread,n:i32);static mut __start___verbose:debug::Ddebug;static mut __stop___verbose:debug::Ddebug;}
#[no_mangle] unsafe extern "C" fn record_log(fmt:*const i8,func:*const i8,tid:i32,t:*mut c_void,new_tid:i32) {
 assert_eq!(CStr::from_ptr(fmt).to_bytes(),b"%s: tid %d (thread %p) has been relaced with tid %d\n");assert_eq!(CStr::from_ptr(func).to_bytes(),b"__find_and_replace_tid");
 let slots=std::slice::from_raw_parts(SLOTS,LEN).iter().map(|s|(s.tid,s.thread as usize)).collect();EVENTS.push((tid,t as usize,new_tid,slots));
}
unsafe fn set_debug(on:bool) {let mut p=&raw mut __start___verbose;let e=&raw mut __stop___verbose;let mut count=0;while p<e {assert!((*p).fmt.is_null());assert_eq!(CStr::from_ptr((*p).func).to_bytes(),b"process_replace_tid_log_bridge");(*p).line_flags=((*p).line_flags&0x00ff_ffff)|((on as u32)<<24);count+=1;p=p.add(1);}assert_eq!(count,2);}
fn main(){unsafe{
 let mut count=0;
 for on in [false,true] {set_debug(on);for old_tid in [0,37,i32::MAX,i32::MIN] {for new_tid in [0,37,i32::MAX,i32::MIN] {for case in 0..8 {
  let mut traces=Vec::new();
  let mut thread=Box::<Thread>::new_uninit();let tp=thread.as_mut_ptr();std::ptr::addr_of_mut!((*tp).tid).write(old_tid);
  let mut proc=Box::<Process>::new_uninit();let pp=proc.as_mut_ptr();
  let pattern:Vec<bool>=match case {0=>vec![],1=>vec![true],2=>vec![false,true,false],3=>vec![false,false],4=>vec![true,false,true],5=>vec![true],6=>vec![true],_=>vec![false,true]};
  for rust in [false,true] {
   // All numeric TIDs match old_tid: lookup must still match ownership pointer.
   let mut slots:Vec<McexecTid>=pattern.iter().map(|b|McexecTid{tid:old_tid,padding:0x1234abcd,thread:if *b {tp}else{0xfedcba9876543200usize as *mut Thread}}).collect();
   SLOTS=slots.as_mut_ptr();LEN=slots.len();let null_tids=case==5;let nr=if case==6 {-1}else if case==7 {1}else{slots.len() as i32};std::ptr::addr_of_mut!((*pp).tids).write(if null_tids {std::ptr::null_mut()}else{SLOTS.cast()});std::ptr::addr_of_mut!((*pp).nr_tids).write(nr);
   let mut expected:Vec<(i32,usize)>=slots.iter().map(|s|(s.tid,s.thread as usize)).collect();let mut expectedlogs=Vec::new();EVENTS.clear();
   for _ in 0..3 {
    if !null_tids&&nr>0 {if let Some(i)=expected[..nr as usize].iter().position(|p|p.1==tp as usize) {expected[i]=(new_tid,0);if on {expectedlogs.push((old_tid,tp as usize,new_tid,expected.clone()));}}}
    if rust {__find_and_replace_tid(pp,tp,new_tid)}else{c_reference(pp,tp,new_tid)}
    assert_eq!(slots.iter().map(|s|(s.tid,s.thread as usize)).collect::<Vec<_>>(),expected);assert_eq!(EVENTS,expectedlogs);
    assert_eq!((*tp).tid,old_tid);assert_eq!((*pp).nr_tids,nr);assert_eq!((*pp).tids,if null_tids {std::ptr::null_mut()}else{SLOTS.cast()});
    for s in &slots {assert_eq!(s.padding,0x1234abcd);}
   }
   traces.push(format!("{:?}:{:?}",expected,EVENTS));
  }
  assert_eq!(traces[0],traces[1]);count+=1;
 }}}}
 println!("PASS {} actual C/Rust leaf cases, three replacements each, first-match ownership, callback-after-pointer-clear-and-TID-write, unchanged thread/padding, nulltable/nonpositive/boundedcount",count);
}}
