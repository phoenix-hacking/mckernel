from pathlib import Path
import importlib.util, json, os, time
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("supervisor","/home/holden/mckernel/scripts/application-tests/supervisor.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
(R/'results').mkdir(mode=0o700)
(R/'home').mkdir(mode=0o700);(R/'tmp').mkdir(mode=0o700)
env={'PATH':'/usr/bin:/bin','HOME':str(R/'home'),'TMPDIR':str(R/'tmp'),'LC_ALL':'C'}
rows=[]
def run(name,argv,expected_code):
 report=s.run_supervised(argv,cwd=str(R),env=env,attempt_dir=str(R/'results'/name),timeout_seconds=25,cleanup_timeout_seconds=3,stdout_limit_bytes=1048576,stderr_limit_bytes=1048576)
 rows.append({'name':name,'report':report})
 (R/'results/partial.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert report['status']=='COMPLETED' and report['cleanup_complete'], report
 assert report['wait_status']=={'kind':'exited','code':expected_code}, report
 return report
start=time.monotonic()
run('compile',['/home/holden/mckernel-work/toolchains/rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc','--edition=2021','-C','opt-level=1',str(R/'actual-body-harness.rs'),'-o',str(R/'actual-body')],0)
for case in ['alloc','descriptor','cloexec']:
 run(case,[str(R/'actual-body'),case],1)
 assert (R/'results'/case/'stdout.bin').read_bytes()==(R/(case+'.expected.stdout')).read_bytes(),case
 assert (R/'results'/case/'stderr.bin').read_bytes()==b'',case
result={'status':'PASS_THREE_NEW_ACTUAL_LAUNCHER_BODY_FAILURES','elapsed_seconds':time.monotonic()-start,'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','rows':rows,'native_acceptance':False,'shared_source_modified':False}
(R/'results/result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],result['elapsed_seconds'])
