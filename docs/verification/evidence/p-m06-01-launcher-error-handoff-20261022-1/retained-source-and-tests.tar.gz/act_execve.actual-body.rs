#[no_mangle]
pub unsafe extern "C" fn act_execve(
    w: *const McexecSyscallWaitDesc,
    fd: c_int,
    cpu: c_int,
    pathbuf: *mut u8,
    main_loop_ret: *mut c_long,
) -> c_int {
    let phase = unsafe { (*w).sr.args[0] };

    match phase {
        1 => unsafe {
            act_execve_phase1(w, fd, cpu, pathbuf);
            0
        },
        2 => {
            let ret = unsafe { act_execve_phase2(w, fd, cpu) };
            if ret != 0 {
                if !main_loop_ret.is_null() {
                    unsafe {
                        *main_loop_ret = ret;
                    }
                }
                // Phase two follows destruction of the old guest userspace.
                // Worker return values are discarded by join_all_threads, so
                // propagate fatal image failure through the existing process
                // exit path. Uncertain guest responses retain their claims.
                unsafe {
                    mcexec_exit_cmd_servers_bridge();
                    mcexec_exit_process_bridge(1);
                }
                1 // The existing void bridge exits the real process.
            } else {
                0
            }
        }
        _ => unsafe {
            mcexec_execve_invalid_phase_bridge();
            0
        },
    }
}
