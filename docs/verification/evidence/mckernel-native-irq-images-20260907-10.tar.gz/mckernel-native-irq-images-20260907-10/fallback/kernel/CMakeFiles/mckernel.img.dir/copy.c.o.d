kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-irq-images-20260907-10/source/kernel/copy.c
