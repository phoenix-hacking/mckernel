/work/mckernel-native-irq-images-20260907-10/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-irq-images-20260907-10/invalid-abi/tmp.resolve_MODULES_END/driver.o

