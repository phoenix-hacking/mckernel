"""Preserve the entire threads baseline, then compare a new futex application.

The same payload executes directly in pinned guest Linux and then McKernel.
No container-host execution is used as the application's Linux oracle.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast, difflib, gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
architecture, profile = 'x86_64', 'normal'
module_attempt, image_attempt, payload_attempt, attempt = sys.argv[1:]
assert all(re.fullmatch(r'[1-9][0-9]*', value) for value in sys.argv[1:])
case = 'threads'
payload_build = Path('/work/native-ultra-futex-build-20260909-' + payload_attempt)
baseline_runner = Path('/work/run-native-ultra-baseline.py')
compiled = Path('/work/native-ultra-module-20260909-' + module_attempt)
images = Path('/work/mckernel-native-ultra-images-20260909-' + image_attempt)
launcher = Path('/work/native-application-launcher-20260908-2')
baseline = Path('/work/native-mcctrl-image-guest-20260908-x86_64-4')
assert case in ('memory','files','threads','signals')
mode='application'
out = Path('/work/native-ultra-futex-guest-20260909-' + attempt)
out.mkdir()
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              architecture=architecture, profile=profile, mode=mode, inputs=[], commands=[], captures=[],
              cpuset=sorted(os.sched_getaffinity(0)), cpus=4, guest_cpus=1, numa_nodes=2,
              memory_mib=8192, container_memory_mib=12288, application_attempted=False,
              mckernel_application_executed=False, production_gate_credit=False)
sequence, stream, process = 0, None, None
expected_futex_stdout = 'NATIVE_ULTRA_FUTEX PASS cases=16 threads=2 raw_clone=1\n'
launcher_stderr_prefix = b'objdump /proc/self/exe: 2\nwarning: did not set LD_PRELOAD\n'
assert len(launcher_stderr_prefix) == 58
# This independent oracle does not trust expected values supplied by the app.
futex_cases = [('wait_mismatch', -1, 11, 0), ('wait_relative_zero', -1, 110, 0),
    ('wait_relative_10ms', -1, 110, 9000000), ('wait_bitset_expired', -1, 110, 0),
    ('wait_bitset_future', -1, 110, 0), ('wait_null_word', -1, 14, 0),
    ('wait_unaligned_word', -1, 22, 0), ('timeout_protected', -1, 14, 0),
    ('timeout_cross_page', -1, 14, 0), ('timeout_negative_seconds', -1, 22, 0),
    ('timeout_negative_nanoseconds', -1, 22, 0), ('timeout_large_nanoseconds', -1, 22, 0),
    ('wait_bitset_zero', -1, 22, 0), ('wake_empty', 0, 0, 0),
    ('wake_unmapped_private', 0, 0, 0), ('wait_relative_runnable', -1, 110, 9000000)]

def check_futex_side(serial, side):
    stdout_marks = re.findall(r'NATIVE_ULTRA_FUTEX_STDOUT side=' + side + r' bytes=(\d+) line=([^\r\n]+)', serial)
    assert stdout_marks == [(str(len(expected_futex_stdout.encode())), expected_futex_stdout.rstrip('\n'))], stdout_marks
    # Capture every reported line, including blanks or unexpected diagnostics.
    # Only the two frozen launcher lines may precede the original 18 payload
    # lines; the independent full-byte-count check rejects missing newlines.
    combined_lines = re.findall(r'NATIVE_ULTRA_FUTEX_REPORT side=' + side + r' ([^\r\n]*)', serial)
    prefix = launcher_stderr_prefix if side == 'mckernel' else b''
    prefix_lines = prefix.decode().splitlines()
    assert combined_lines[:len(prefix_lines)] == prefix_lines, (side, combined_lines)
    lines = combined_lines[len(prefix_lines):]
    assert len(lines) == 18, (side, lines)
    payload_stderr = ''.join(line + '\n' for line in lines).encode()
    stderr = ''.join(line + '\n' for line in combined_lines).encode()
    assert stderr == prefix + payload_stderr
    byte_marks = re.findall(r'NATIVE_ULTRA_FUTEX_STDERR side=' + side + r' bytes=(\d+)\b', serial)
    assert byte_marks == [str(len(stderr))], (side, byte_marks, len(stderr))
    (out / (side + '-futex-stdout.bin')).write_bytes(expected_futex_stdout.encode())
    (out / (side + '-futex-stderr.bin')).write_bytes(stderr)
    (out / (side + '-futex-launcher-stderr.bin')).write_bytes(prefix)
    (out / (side + '-futex-payload-stderr.bin')).write_bytes(payload_stderr)
    parsed = []
    pattern = (r'NATIVE_ULTRA_FUTEX_CASE id=([a-z0-9_]+) result=(-?\d+) errno=(\d+) '
               r'elapsed_ns=(\d+) before_ns=(\d+) after_ns=(\d+) deadline_ns=(\d+)')
    case_lines = lines[:15] + [lines[16]]
    for line, (case_id, expected_result, expected_errno, minimum) in zip(case_lines, futex_cases):
        match = re.fullmatch(pattern, line)
        assert match, (side, line)
        actual_id = match.group(1)
        result, error, elapsed, before, after, deadline = map(int, match.groups()[1:])
        assert actual_id == case_id and (result, error) == (expected_result, expected_errno), (side, line)
        assert after >= before and elapsed == after - before and minimum <= elapsed <= 2000000000, (side, line)
        if case_id == 'wait_bitset_future':
            assert deadline > 0 and after >= deadline - 1000000, (side, line)
            # Deadline constructed immediately before the measured syscall;
            # setup scheduling can reduce, but cannot extend, the requested 10ms.
            assert deadline - before <= 10000000, (side, line)
        else:
            assert deadline == 0, (side, line)
        parsed.append(dict(id=case_id, result=result, errno=error, elapsed_ns=elapsed,
                           before_ns=before, after_ns=after, deadline_ns=deadline))
    match = re.fullmatch(r'NATIVE_ULTRA_FUTEX_THREADS joined=2 parent_tid=(\d+) tid0=(\d+) tid1=(\d+) '
        r'count0=(\d+) count1=(\d+) token0=1 token1=2 stack_bytes=262144 elapsed_ns=(\d+)', lines[17])
    assert match, (side, lines[17])
    parent, tid0, tid1, count0, count1, elapsed = map(int, match.groups())
    assert len({parent, tid0, tid1}) == 3 and min(parent, tid0, tid1, count0, count1) > 0
    assert max(count0, count1) < 20000000 and elapsed <= 6000000000
    clone = re.fullmatch(r'NATIVE_ULTRA_FUTEX_CLONE parent_tid=(\d+) child_tid=(\d+) entry_tid=(\d+) stored_tid=(\d+) '
        r'cleared_tid=0 entered=1 wait_calls=(\d+) elapsed_ns=(\d+) flags=([0-9a-f]+) stack_bytes=262144', lines[15])
    assert clone, (side, lines[15])
    clone_parent, clone_tid, entry_tid, stored_tid, wait_calls, clone_elapsed = map(int, clone.groups()[:6])
    flags = int(clone.group(7), 16)
    assert clone_parent == parent and clone_tid == entry_tid == stored_tid
    assert clone_tid > 0 and clone_tid != parent and wait_calls <= 256 and clone_elapsed <= 2000000000
    assert flags == (0x100 | 0x200 | 0x400 | 0x800 | 0x10000 | 0x40000 | 0x1000000 | 0x200000)
    return dict(side=side, cases=parsed, parent_tid=parent, child_tids=[tid0, tid1],
        work_counts=[count0, count1], pthread_stack_bytes=262144, join_elapsed_ns=elapsed,
        raw_clone=dict(parent_tid=clone_parent, child_tid=clone_tid, entry_tid=entry_tid,
            stored_tid=stored_tid, cleared_tid=0, entered=True, wait_calls=wait_calls,
            elapsed_ns=clone_elapsed, flags=flags, shared_vm=True, fork_cow=False),
        stdout=identity(out / (side + '-futex-stdout.bin')), stderr=identity(out / (side + '-futex-stderr.bin')),
        launcher_stderr=identity(out / (side + '-futex-launcher-stderr.bin')),
        payload_stderr=identity(out / (side + '-futex-payload-stderr.bin')),
        exact_launcher_prefix_hex=prefix.hex(), payload_stderr_lines=18,
        combined_stderr_exact=True, exact_exit_code=37, total_virtual_size_or_rss_asserted=False)

# Reuse the exact accepted image-runner's physical capture and boot assertions.
# Extract only these complete function definitions, not its top-level run.
original_reference = (baseline / 'helper.py').read_text()
assert original_reference.count('continuing_workers=2') == 1
original = original_reference.replace('continuing_workers=2', 'continuing_workers=3')
names = {'identity', 'save', 'qmp', 'dump', 'capture'}
functions = [node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in functions} == names
exec(compile(ast.Module(body=functions, type_ignores=[]), str(out / 'capture-reference.py'), 'exec'))

def run(label, command, environment=None):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, result.returncode, (out / (label + '.log')).read_text()[-6000:])
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'helper.py')
    stderr_original = Path('/work/run-native-ultra-futex-before-launcher-stderr.py')
    assert identity(stderr_original)['sha256'] == 'd99d1696985da3f8fb487ed73ff6c870aea72c126468d59b2e0efa28491ec03a'
    shutil.copyfile(stderr_original, out / 'helper-before-launcher-stderr.py')
    (out / 'launcher-stderr-adaptation.diff').write_text(''.join(difflib.unified_diff(
        stderr_original.read_text().splitlines(True), Path(__file__).read_text().splitlines(True),
        fromfile=str(stderr_original), tofile=str(Path(__file__)))))
    diagnostic_reference = Path('/work/native-ultra-baseline-threads-guest-20260909-1')
    assert json.loads((diagnostic_reference / 'record.json').read_text())['status'] == 'PASS'
    expected_console_prefix = launcher_stderr_prefix.replace(b'\n', b'\r\n')
    assert (diagnostic_reference / 'serial.log').read_bytes().count(expected_console_prefix) == 9
    record['inputs'] += [identity(out / 'helper-before-launcher-stderr.py'),
        identity(diagnostic_reference / 'record.json'), identity(diagnostic_reference / 'serial.log')]
    record['launcher_stderr_contract'] = dict(original_helper=identity(out / 'helper-before-launcher-stderr.py'),
        reference_record=identity(diagnostic_reference / 'record.json'),
        reference_serial=identity(diagnostic_reference / 'serial.log'), reference_occurrences=9,
        exact_prefix_hex=launcher_stderr_prefix.hex(), original_payload_lines=18,
        scope='Exact existing launcher startup prefix plus all original payload lines; complete combined stderr byte count and separately retained components. No wildcard filtering or payload changes.')
    shutil.copyfile(baseline_runner, out / 'baseline-runner-original.py')
    (out / 'baseline-runner-adaptation.diff').write_text(''.join(difflib.unified_diff(
        baseline_runner.read_text().splitlines(True), Path(__file__).read_text().splitlines(True),
        fromfile=str(baseline_runner), tofile=str(Path(__file__)))))
    record['baseline_runner_preservation'] = dict(original=identity(baseline_runner),
        captured=identity(out / 'baseline-runner-original.py'), case='threads',
        all_eight_hello_and_original_thread_assertions_retained=True,
        appended_window_after_original_guest_pass=True)
    shutil.copyfile(baseline / 'helper.py', out / 'capture-reference-original.py')
    (out / 'capture-reference.py').write_text(original)
    record['inputs'] += [identity(out / 'capture-reference-original.py'), identity(out / 'capture-reference.py')]
    record['capture_reference_adaptation'] = 'Only the exact continuing worker-count assertion changes from 2 to 3; both complete original and executed references retained.'
    assert shutil.disk_usage('/work').free > 2 * 1024**3
    for directory in (compiled, images, launcher, baseline):
        assert json.loads((directory / 'record.json').read_text())['status'] == 'PASS'
        record['inputs'].append(identity(directory / 'record.json'))
    built = json.loads((compiled / 'record.json').read_text())
    for row in built['outputs']:
        assert identity(Path(row['path'])) == row
    launches = json.loads((launcher / 'record.json').read_text())
    for selection in launches['launchers']:
        for row in selection['outputs']:
            assert identity(Path(row['path'])) == row
    for row in launches['outputs']:
        assert identity(Path(row['path'])) == row
    accepted = json.loads((baseline / 'record.json').read_text())
    if mode == 'application':
        metadata_test = Path('/work/native-application-services-buildid-guest-20260908-1/record.json')
        assert json.loads(metadata_test.read_text())['status'] == 'PASS'
        record['inputs'].append(identity(metadata_test))
    boot = baseline / 'root/bin/native-boot'
    # The complete prior capture and compiler command retain this exact binary.
    record['inputs'] += [identity(boot), identity(baseline / 'helper.py')]
    root = out / 'root'
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), root)
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(compiled / name, root / 'modules' / name)
        record['inputs'].append(identity(compiled / name))
    shutil.copy2(boot, root / 'bin/native-boot')
    assert (root / 'bin/native-boot').stat().st_mode & 0o111 == 0o111
    # Existing single-CPU oversubscription option is required for the original
    # two-pthread smoke. Preserve every original bootstrap assertion/command.
    original_boot_source=out/'boot-probe-original'
    boot_source=out/'boot-probe-source'
    shutil.copytree(baseline/'probe-source',original_boot_source)
    shutil.copytree(original_boot_source,boot_source)
    boot_text=(boot_source/'native-boot.c').read_text()
    old='(long)"hidos"'
    assert boot_text.count(old)==1
    (boot_source/'native-boot.c').write_text(boot_text.replace(old,'(long)"hidos allow_oversubscribe"'))
    original_boot_command=next(row['command'] for row in accepted['commands'] if row['label']=='probe-build')
    boot_command=[str(boot_source/'native-boot.c') if word==str(baseline/'probe-source/native-boot.c') else str(root/'bin/native-boot') if word==str(baseline/'root/bin/native-boot') else word for word in original_boot_command]
    record['boot_probe_adaptation']=dict(original_command=original_boot_command,executed_command=boot_command,kernel_command_line='hidos allow_oversubscribe',reason='Enable the existing supported configuration for two pthreads on one McKernel CPU; all original boot/application assertions retained.')
    run('boot-probe-oversubscribe',boot_command)
    record['inputs'] += [identity(p) for directory in [original_boot_source,boot_source] for p in sorted(directory.rglob('*')) if p.is_file()]
    record['inputs'].append(identity(root/'bin/native-boot'))
    application = launcher / 'native-application-hello'

    binary = launcher / 'rust/executer/user/mcexec'
    shutil.copyfile(binary, root / 'bin/mcexec')
    shutil.copyfile(application, root / 'bin/native-application-hello')
    (root / 'bin/mcexec').chmod(0o755)
    (root / 'bin/native-application-hello').chmod(0o755)
    record['inputs'] += [identity(binary), identity(application)]
    core=Path('/work/native-application-core-build-20260908-1')
    core_record=json.loads((core/'record.json').read_text());assert core_record['status']=='PASS'
    for row in core_record['outputs']:assert identity(Path(row['path']))==row
    shutil.copyfile(core/'native-application-core',root/'bin/native-application-core');(root/'bin/native-application-core').chmod(0o755)
    record['inputs'] += [identity(core/'record.json'),identity(core/'native-application-core'),identity(core/'native-application-core.c')]
    record['core_case']=case
    expected_core='NATIVE_CORE PASS '+case+'\n'
    assert next(row for row in core_record['linux_reference'] if row['case']==case)['stdout']==expected_core
    futex_build_record = json.loads((payload_build / 'record.json').read_text())
    assert futex_build_record['status'] == 'PASS' and not futex_build_record['linux_reference_executed']
    assert futex_build_record['application_contract']['stdout'] == expected_futex_stdout
    for row in futex_build_record['outputs']:
        assert identity(Path(row['path'])) == row, row
    futex_binary = payload_build / 'native-ultra-futex'
    assert identity(futex_binary) == futex_build_record['binary']
    shutil.copyfile(futex_binary, root / 'bin/native-ultra-futex')
    (root / 'bin/native-ultra-futex').chmod(0o755)
    record['inputs'] += [identity(payload_build / 'record.json'), identity(futex_binary),
                          identity(payload_build / 'native-ultra-futex.c')]
    record['futex_build_contract'] = futex_build_record['application_contract']
    probe = out / 'probe-source'
    probe.mkdir()
    for name in ('native-os-buildid.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c', 'native-mcctrl-exec.c', 'native-mcctrl-string.c'):
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, probe / name)
    original_header = repo / 'ihk/linux/include/ihk/ihk_host_user.h'
    build_config = launcher / 'rust/config.h'
    shutil.copyfile(original_header, probe / 'ihk_host_user.h.reference')
    shutil.copyfile(build_config, probe / 'launcher-config.h.reference')
    macro = re.findall(r'^#define IHK_OS_GET_BUILDID\s+0x[0-9a-fA-F]+\s*$', original_header.read_text(), re.M)
    buildid = re.findall(r'^#define BUILDID ("[^"\n]+")$', build_config.read_text(), re.M)
    assert len(macro) == len(buildid) == 1
    payload = compiled / 'staged-source/ihk-compat-build-id.bin'
    assert payload.read_bytes() == json.loads(buildid[0]).encode() + b'\0'
    (probe / 'native-buildid-abi.h').write_text(macro[0].strip() + '\n#define BUILDID ' + buildid[0] + '\n')
    binding = Path('/work/native-sysfs-setup-module-20260907-1/bindings_generated.rs')
    states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', binding.read_text())
    assert len(states) == 1
    for bits, label in ((64, 'x86_64'), (32, 'i386')):
        run('buildid-probe-' + label, ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror',
                                     '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie',
                                     '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack',
                                     '-DCPUHP_FAILURE_STATE=' + states[0], str(probe / 'native-os-buildid.c'),
                                     '-o', str(root / ('bin/native-os-buildid-' + label))])
    protocol=repo/'executer/include/uprotocol.h'
    shutil.copyfile(protocol,probe/'uprotocol.h.reference')
    definition=re.search(r'^struct strncpy_from_user_desc \{[^}]+\};',protocol.read_text(),re.M);assert definition
    constant=re.search(r'^#define MCEXEC_UP_STRNCPY_FROM_USER[^\n]+',protocol.read_text(),re.M);assert constant
    (probe/'native-string-abi.h').write_text(constant[0]+'\n'+definition[0]+'\n')
    for bits,label in ((64,'x86_64'),(32,'i386')):
        run('string-probe-'+label,['cc','-m'+str(bits),'-O2','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-pie','-nostdlib','-static','-no-pie','-Wl,-e,_start','-Wl,-z,noexecstack','-DCPUHP_FAILURE_STATE='+states[0],str(probe/'native-mcctrl-string.c'),'-o',str(root/('bin/native-string-'+label))])
    record['inputs'] += [identity(p) for p in sorted(probe.iterdir())]
    record['inputs'] += [identity(binding), identity(payload)]
    # Use this native Linux userspace's libraries for both the base root and
    # the unchanged older-glibc-compatible launcher. Never mix libc releases.
    dependencies = run('launcher-native-dependencies', ['ldd', str(binary)])
    assert 'not found' not in dependencies
    record['runtime_libraries'] = []
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert identity(target)['sha256'] == identity(original_path)['sha256'], ('library mismatch', name)
        else:
            shutil.copyfile(original_path, target)
        record['runtime_libraries'].append(dict(original=identity(original_path), captured=identity(target)))
    assert len(record['runtime_libraries']) >= 3
    for row in core_record['runtime_libraries']:
        original=Path(row['original']['path']);assert identity(original)==row['original']
        target=root/str(original).lstrip('/')
        if target.exists():assert identity(target)['sha256']==row['original']['sha256']
        else:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        record['runtime_libraries'].append(dict(original=identity(original),captured=identity(target)))
    for row in futex_build_record['runtime_libraries']:
        original = Path(row['original']['path'])
        assert identity(original) == row['original']
        target = root / str(original).lstrip('/')
        if target.exists():
            assert identity(target)['sha256'] == row['original']['sha256']
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
        record['runtime_libraries'].append(dict(original=identity(original), captured=identity(target)))

    image_record = json.loads((images / 'record.json').read_text())
    for flag in ['native_fault_hooks_selected', 'native_futex_checked_load_selected',
                 'native_xstate_checked_restore_selected', 'native_clone_tid_selection_compiled']:
        assert image_record[flag], flag
    record['ultra_image_selection'] = next(row for row in image_record['ultra_selection_checks']
                                          if row['profile'] == 'native-rust')
    assert image_record['native_clone3_guest_handler_compiled']
    clone_selection=next(row for row in image_record['clone3_table_checks'] if row['profile']=='native-rust')
    assert clone_selection['native'] and clone_selection['slot435']==clone_selection['rust_handler']!=0 and clone_selection['native_marker_bypass']
    record['clone3_image_selection']=clone_selection
    signal_selection=next(row for row in image_record['signal_stack_checks'] if row['profile']=='native-rust')
    assert signal_selection['native'] and signal_selection['prepare'] and signal_selection['publish']
    record['native_signal_stack_image_selection']=signal_selection

    selected = next(row for row in image_record['images'] if row['kind'] == 'native-rust')
    image = images / 'native-rust/kernel/mckernel.img'
    assert identity(image) in selected['outputs'] and not selected['native_sysfs_verify']
    (root / 'images').mkdir()
    shutil.copyfile(image, root / 'images/mckernel.img')
    init = '''#!/bin/bash
set -euo pipefail
[ "$$" -eq 1 ] && [ "$EUID" -eq 0 ] || exit 125
export PATH=/bin:/sbin:/usr/bin:/usr/sbin LANG=C LC_ALL=C
exec </dev/console >/dev/console 2>&1
finish() { local status=$?; trap - EXIT; if [ "$status" -ne 0 ]; then printf 'NATIVE_APPLICATION_GUEST FAIL status=%s\\n' "$status"; fi; /bin/dmesg || true; /poweroff; }
trap finish EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t debugfs debugfs /sys/kernel/debug
printf '7\\n' >/proc/sys/kernel/printk
read -r online </sys/devices/system/cpu/online
read -r nodes </sys/devices/system/node/online
[ "$online" = 0-3 ] && [ "$nodes" = 0-1 ]
insmod /modules/ihk.ko
insmod /modules/ihk-smp-x86_64.ko ihk_trampoline=524288
insmod /modules/mcctrl.ko
/bin/native-boot
rmmod mcctrl
/bin/native-os-buildid-x86_64
/bin/native-os-buildid-i386
insmod /modules/mcctrl.ko
/bin/native-string-x86_64
/bin/native-string-i386
'''
    if mode == 'application':
        init += '''
printf 'NATIVE_APPLICATION_LINUX_REFERENCE begin\\n'
status=0
/bin/native-application-hello || status=$?
printf 'NATIVE_APPLICATION_LINUX_REFERENCE exit=%s\\n' "$status"
[ "$status" -eq 37 ]
shopt -s nullglob
for iteration in {1..8}; do
printf '<6>NATIVE_APPLICATION_MCEXEC begin iteration=%s\\n' "$iteration" >/dev/kmsg
status=0
application_output=/application-stdout-$iteration
/bin/mcexec -t 1 0 /bin/native-application-hello >"$application_output" || status=$?
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s "$application_output")" -eq 25 ]
IFS= read -r application_line <"$application_output"
[ "$application_line" = NATIVE_APPLICATION_HELLO ]
printf '<6>NATIVE_APPLICATION_STDOUT iteration=%s bytes=25 line=%s\\n' "$iteration" "$application_line" >/dev/kmsg
printf '<6>NATIVE_APPLICATION_MCEXEC exit=%s iteration=%s\\n' "$status" "$iteration" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=%s\\n' "$iteration" >/dev/kmsg
done
printf '<6>NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37\\n' >/dev/kmsg
printf '<6>NATIVE_CORE_MCEXEC begin case=@CORE_CASE@\\n' >/dev/kmsg
status=0
/bin/mcexec -t 1 0 /bin/native-application-core @CORE_CASE@ >/core-stdout || status=$?
printf '<6>NATIVE_CORE_MCEXEC exit=%s case=@CORE_CASE@\\n' "$status" >/dev/kmsg
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s /core-stdout)" -eq @CORE_BYTES@ ]
IFS= read -r application_line </core-stdout
[ "$application_line" = 'NATIVE_CORE PASS @CORE_CASE@' ]
printf '<6>NATIVE_CORE_STDOUT bytes=@CORE_BYTES@ line=%s\\n' "$application_line" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_CORE_REGISTRATIONS_CLEAR case=@CORE_CASE@\\n' >/dev/kmsg
printf '<6>NATIVE_APPLICATION_GUEST PASS application_exit=37\\n' >/dev/kmsg
'''
    else:
        init += "printf 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0\\n'\n"
    init=init.replace('@CORE_CASE@',case).replace('@CORE_BYTES@',str(len(expected_core.encode())))
    # The complete original init, including its PASS delimiter, remains
    # before this window. Its host assertions still inspect only that prefix.
    init += '''
for side in linux mckernel; do
printf '<6>NATIVE_ULTRA_FUTEX_RUN begin side=%s\\n' "$side" >/dev/kmsg
status=0
if [ "$side" = linux ]; then
    /bin/native-ultra-futex >/futex-$side-stdout 2>/futex-$side-stderr || status=$?
else
    /bin/mcexec -t 1 0 /bin/native-ultra-futex >/futex-$side-stdout 2>/futex-$side-stderr || status=$?
fi
printf '<6>NATIVE_ULTRA_FUTEX_RUN exit=%s side=%s\\n' "$status" "$side" >/dev/kmsg
stderr_bytes=$(/bin/stat -c %s /futex-$side-stderr)
printf '<6>NATIVE_ULTRA_FUTEX_STDERR side=%s bytes=%s\\n' "$side" "$stderr_bytes" >/dev/kmsg
while IFS= read -r line; do
    printf '<6>NATIVE_ULTRA_FUTEX_REPORT side=%s %s\\n' "$side" "$line" >/dev/kmsg
done </futex-$side-stderr
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s /futex-$side-stdout)" -eq @FUTEX_BYTES@ ]
IFS= read -r line </futex-$side-stdout
[ "$line" = 'NATIVE_ULTRA_FUTEX PASS cases=16 threads=2 raw_clone=1' ]
printf '<6>NATIVE_ULTRA_FUTEX_STDOUT side=%s bytes=@FUTEX_BYTES@ line=%s\\n' "$side" "$line" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_ULTRA_FUTEX_REGISTRATIONS_CLEAR side=%s\\n' "$side" >/dev/kmsg
done
printf '<6>NATIVE_ULTRA_FUTEX_GUEST PASS sides=2 cases=16 pthread_workers=2 raw_clone=1 application_exit=37\\n' >/dev/kmsg
'''.replace('@FUTEX_BYTES@', str(len(expected_futex_stdout.encode())))
    (root / 'init').write_text(init)
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    env = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root))
    run('initramfs-spec', ['python3', '-B', '/work/write-native-cpio-spec.py'], env)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as target:
            generator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(generator.stdout, target)
            generator.stdout.close()
            assert generator.wait() == 0
    record['inputs'] += [identity(p) for p in (image, compiled / 'bzImage', root / 'init', out / 'initramfs.cpio.gz', Path('/work/write-native-cpio-spec.py'))]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off', '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args
    record['phase'] = 'guest'
    save()
    print('RUN guest', flush=True)
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20)
        connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            record['application_attempted'] = 'NATIVE_APPLICATION_MCEXEC begin' in serial
            for bad in ('NATIVE_ULTRA_FUTEX FAIL', 'NATIVE_CORE FAIL', 'strncpy_from_user:ioctl:', 'ret: ', 'NATIVE_APPLICATION_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP', 'continuing service error', 'clear_host_pte failed'):
                assert bad not in serial, bad
            ready = serial.count('NATIVE_BOOT_CAPTURE x86_64 ready')
            if ready > seen:
                assert ready == seen + 1 and ready <= 2
                capture(serial, seen)
                seen += 1
            state = qmp('query-status')
            if state['status'] in ('shutdown', 'guest-panicked'):
                record['terminal_vm_state'] = state
                for interface in ('x86_64', 'i386'):
                    assert 'NATIVE_OS_BUILDID ' + interface + ' PASS states=2 guarded=4 faults=10 mcctrl_absent=1' in serial
                for interface in ('x86_64','i386'):
                    assert 'NATIVE_STRING_COPY '+interface+' PASS cases=14 descriptor_faults=4 guarded=1 applications=0' in serial
                record['native_string_copy']=dict(interfaces=2,data_cases=28,descriptor_faults=8,guarded=True,source_and_destination_fields_preserved=True)
                if mode == 'application':
                    assert 'NATIVE_APPLICATION_GUEST PASS application_exit=37' in serial, state
                    console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]
                    windows=re.findall(r'NATIVE_APPLICATION_MCEXEC begin iteration=(\d+)(.*?)NATIVE_APPLICATION_MCEXEC exit=37 iteration=\1\b',console,re.S)
                    assert [int(i) for i,body in windows]==list(range(1,9)),windows
                    launches=[]
                    for iteration,body in windows:
                        assert body.count('NATIVE_APPLICATION_HELLO')==1,body
                        assert 'NATIVE_APPLICATION_STDOUT iteration='+iteration+' bytes=25 line=NATIVE_APPLICATION_HELLO' in body,body
                        schedules=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',body)
                        assert len(schedules)==1,schedules
                        pid=schedules[0]
                        delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',body)
                        returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',body)
                        writes=[row for row in delivered if row[3]=='1'];assert len(writes)==1,delivered
                        assert writes[0][:3]+('25',) in returned,(delivered,returned)
                        assert any(row[3]=='231' for row in delivered),delivered
                        for operation in ('published','deleted'):
                            assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',body),operation
                        assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',body),body
                        assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',body),body
                        launches.append(dict(iteration=int(iteration),pid=int(pid),delivered=delivered,returned=returned,write_bytes=25,stdout_hex=b'NATIVE_APPLICATION_HELLO\n'.hex(),stdout_verification='guest regular file, exact 25 bytes, successful newline read and exact line comparison; copied into ordered printk record',exit_code=37,marked_retirement=True,registration_released=True))
                    # The original write-25 regression applies to the eight HELLO
                    # launches. Libc routes are checked below against their own
                    # delivery/result identities, including legitimate errors.
                    hello_console=console.split('NATIVE_CORE_MCEXEC begin case='+case,1)[0]
                    route_pattern=r'application_syscall=return_route os=0 generation=1 pid=(\d+) worker=(\d+) delivery=(\d+) launcher_cpu=(-?\d+) guest_cpu=(\d+)'
                    routes=re.findall(route_pattern,hello_console)
                    assert any(row[3]=='1' and row[4]=='0' for row in routes),('distinct launcher/guest CPU case not observed',routes)
                    for pid,worker,delivery,launcher_cpu,guest_cpu in routes:
                        launch=next(row for row in launches if row['pid']==int(pid))
                        assert (worker,delivery,guest_cpu,'25') in launch['returned']
                    record['return_routes']=routes
                    assert len(set(row['pid'] for row in launches))==8
                    assert re.findall(r'NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=(\d+)',console)==list(map(str,range(1,9)))
                    assert 'NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37' in console
                    assert 'cleanup retained' not in console and 'reap_retained' not in console
                    record['native_application']=dict(applications=8,launches=launches,same_os_instance=True,no_process_nodes_after_each=True)
                    record['mckernel_application_executed']=True
                    core_body=console.split('NATIVE_CORE_MCEXEC begin case='+case,1)[1].split('NATIVE_CORE_MCEXEC exit=37 case='+case,1)[0]
                    core_pids=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',core_body);assert len(core_pids)==1,core_pids
                    pid=core_pids[0]
                    assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',core_body),core_body
                    assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',core_body),core_body
                    for operation in ('published','deleted'):
                        assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',core_body),core_body
                    assert 'NATIVE_CORE_STDOUT bytes='+str(len(expected_core.encode()))+' line='+expected_core.rstrip('\n') in console
                    assert 'NATIVE_CORE_REGISTRATIONS_CLEAR case='+case in console
                    delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',core_body)
                    returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',core_body)
                    assert not any(row[3]=='435' for row in delivered),('clone3 incorrectly delegated to Linux',delivered)
                    core_routes=re.findall(route_pattern,core_body)
                    assert len(re.findall(route_pattern,console))==len(routes)+len(core_routes)
                    for route_pid,worker,delivery,launcher_cpu,guest_cpu in core_routes:
                        assert route_pid==pid and guest_cpu=='0' and launcher_cpu!=guest_cpu
                        assert len([row for row in delivered if row[:3]==(worker,delivery,guest_cpu)])==1
                        assert len([row for row in returned if row[:3]==(worker,delivery,guest_cpu)])==1
                    assert all(row[2]=='0' for row in delivered+returned)
                    record['core_application']=dict(case=case,pid=int(pid),exit_code=37,stdout=expected_core,normal_dynamic_libc=True,marked_retirement=True,registration_released=True,no_process_nodes=True,delivered=delivered,returned=returned,return_routes=core_routes)
                    assert re.search(r'full guest ready os=0 generation=1 status=3 sysfs_requests=\d+ continuing_workers=3',console)
                    zeroed=re.findall(r'allocator zeroed os=0 generation=1 sequence=(\d+) pid=(\d+) cpu=(\d+) chunks=(\d+) pages=(\d+) pending=(-?\d+) workers=(-?\d+)',console)
                    assert zeroed and any(int(row[3])>0 and int(row[4])>0 for row in zeroed),zeroed
                    assert all(row[2]=='0' and int(row[5])>=0 and int(row[6])>=0 for row in zeroed),zeroed
                    record['allocator_zeroing']=zeroed
                    invalidated=re.findall(r'host_mapping=invalidated os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) value=(-?\d+) completed=(-?\d+)',core_body)
                    if case=='memory':assert len(invalidated)>=3,invalidated
                    assert all(row[2:]==('0','0') for row in invalidated),invalidated
                    record['host_invalidations']=invalidated
                    counts={};events=[]
                    for match in re.finditer(r'file_pager=(create|release) handle=(\d+) references=(\d+) (shared|remaining)=(\d+)',core_body):
                        operation,handle,refs,label,value=match.groups();refs=int(refs);value=int(value)
                        if operation=='create':
                            assert label=='shared' and value==int(counts.get(handle,0)>0)
                            assert refs==counts.get(handle,0)+1
                            counts[handle]=refs
                        else:
                            assert label=='remaining' and 0<refs<=counts[handle]
                            counts[handle]-=refs;assert counts[handle]==value
                        events.append(match.groups())
                    assert counts and all(value==0 for value in counts.values()),(counts,events)
                    record['file_pager_lifetime']=dict(events=events,remaining_references=counts,all_created_handles_released=True)

                    capture(serial.split('NATIVE_APPLICATION_GUEST PASS', 1)[0], 'application', validate=False, resume=False)
                    if case=='signals':
                        guest_log=(out/'capture-application/kmsg.txt').read_text()
                        frames=re.findall(r'signal_handler pid='+pid+r' tid='+pid+r' sig=10 handler=(0x[0-9a-f]+) restorer=(0x[0-9a-f]+) old_rip=(0x[0-9a-f]+) old_sp=(0x[0-9a-f]+) new_sp=(0x[0-9a-f]+)',guest_log)
                        assert len(frames)==2 and frames[0][4]==frames[1][4],frames
                        assert all(int(row[4],16)<int(row[3],16) for row in frames),frames
                        returns=re.findall(r'mcexec_v10: syscall return cpu=0 pid='+pid+r' tid='+pid+r' nr=15 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        assert returns==['0','0'],returns
                        assert 'ret: ' not in console
                        record['native_signal_application']=dict(frames=frames,actual_sigreturn_results=list(map(int,returns)),blocked_pending_unblocked_and_repeated_altstack_assertions_passed=True,interrupted_host_return_errors=0)
                    if case=='threads':
                        transfers=re.findall(r'application_tids=transferred os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) physical=([0-9a-f]+) bytes=(\d+)',core_body)
                        assert len(transfers)==1 and int(transfers[0][3])==128*4,transfers
                        worker,delivery,physical,length=transfers[0]
                        assert (worker,delivery,'0','186') in delivered
                        assert (worker,delivery,'0','0') in returned
                        record['native_tid_transfer']=dict(worker=int(worker),delivery=int(delivery),physical=int(physical,16),bytes=int(length),actual_gettid_result=0)
                        guest_log=(out/'capture-application/kmsg.txt').read_text()
                        clones=re.findall(r'mcexec_v10: syscall return cpu=0 pid='+pid+r' tid='+pid+r' nr=435 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        assert len(clones)==2 and len(set(clones))==2 and all(int(tid)>0 and tid!=pid for tid in clones),clones
                        tids={pid,*clones}
                        observed=set(re.findall(r'mcexec_v10: syscall entry cpu=0 pid='+pid+r' tid=(\d+) nr=\d+\b',guest_log))
                        assert observed==tids,(tids,observed)
                        for operation in ('published','deleted'):
                            lifecycle=set(re.findall(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid=(\d+)\b',core_body))
                            assert lifecycle==tids,(operation,tids,lifecycle)
                        record['native_clone3_application']=dict(parent_tid=int(pid),child_tids=list(map(int,clones)),executing_guest_tids=sorted(map(int,observed)),host_clone3_delegations=0,all_thread_procfs_published_and_deleted=True,pthread_barrier_mutex_tls_and_join_passed=True)

                    marker = 'NATIVE_ULTRA_FUTEX_GUEST PASS sides=2 cases=16 pthread_workers=2 raw_clone=1 application_exit=37'
                    assert marker in serial, state
                    futex_console = serial.split(marker, 1)[0]
                    windows = re.findall(r'NATIVE_ULTRA_FUTEX_RUN begin side=(linux|mckernel)(.*?)'
                                         r'NATIVE_ULTRA_FUTEX_RUN exit=37 side=\1\b', futex_console, re.S)
                    assert [side for side, body in windows] == ['linux', 'mckernel'], windows
                    assert futex_console.index('NATIVE_APPLICATION_GUEST PASS') < futex_console.index('NATIVE_ULTRA_FUTEX_RUN begin side=linux')
                    assert 'application SCHEDULE' not in windows[0][1], windows[0]
                    sides = [check_futex_side(futex_console, side) for side in ['linux', 'mckernel']]
                    assert [(row['id'], row['result'], row['errno']) for row in sides[0]['cases']] == [
                        (row['id'], row['result'], row['errno']) for row in sides[1]['cases']]
                    futex_body = windows[1][1]
                    scheduled = re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0', futex_body)
                    assert scheduled == [str(sides[1]['parent_tid'])], scheduled
                    futex_pid = scheduled[0]
                    assert re.search(r'application retirement os=0 generation=1 pid=' + futex_pid + r' token=\d+ errno=0\b', futex_body)
                    assert re.search(r'application_process=release os=0 generation=1 pid=' + futex_pid + r' cleanup_errno=0\b', futex_body)
                    assert 'cleanup retained' not in futex_body and 'reap_retained' not in futex_body
                    assert re.findall(r'NATIVE_ULTRA_FUTEX_REGISTRATIONS_CLEAR side=(linux|mckernel)', futex_console) == ['linux', 'mckernel']
                    pthread_tids = set(map(str, sides[1]['child_tids']))
                    raw_clone_tid = str(sides[1]['raw_clone']['child_tid'])
                    assert raw_clone_tid != futex_pid
                    expected_tids = {futex_pid, *pthread_tids, raw_clone_tid}
                    for operation in ['published', 'deleted']:
                        lifecycle = re.findall(r'application procfs ' + operation + r' os=0 generation=1 pid=' + futex_pid + r' tid=(\d+)\b', futex_body)
                        # McKernel's fixed TID pool can reuse the earlier raw
                        # child's ID. Require both complete lifetimes.
                        expected_lifetimes = [futex_pid, *pthread_tids, raw_clone_tid]
                        assert Counter(lifecycle) == Counter(expected_lifetimes), (operation, lifecycle, expected_lifetimes)
                    futex_guest_log = (out / 'capture-application/kmsg.txt').read_text()
                    actual_clones = re.findall(r'mcexec_v10: syscall return cpu=0 pid=' + futex_pid +
                        r' tid=' + futex_pid + r' nr=435 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b', futex_guest_log)
                    assert len(actual_clones) == 2 and set(actual_clones) == pthread_tids, actual_clones
                    raw_clones = re.findall(r'mcexec_v10: syscall return cpu=0 pid=' + futex_pid +
                        r' tid=' + futex_pid + r' nr=56 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b', futex_guest_log)
                    assert raw_clones == [raw_clone_tid], raw_clones
                    executed_tids = set(re.findall(r'mcexec_v10: syscall entry cpu=0 pid=' + futex_pid + r' tid=(\d+) nr=\d+\b', futex_guest_log))
                    assert executed_tids == expected_tids, (executed_tids, expected_tids)
                    futex_returns = list(map(int, re.findall(r'mcexec_v10: syscall return cpu=0 pid=' + futex_pid +
                        r' tid=' + futex_pid + r' nr=202 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b', futex_guest_log)))
                    for value, minimum in {0: 2, -11: 1, -14: 3, -22: 5, -110: 5}.items():
                        assert futex_returns.count(value) >= minimum, (value, minimum, futex_returns)
                    delivered = re.findall(r'application_syscall=delivered os=0 generation=1 pid=' + futex_pid +
                        r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)', futex_body)
                    returned = re.findall(r'application_syscall=returned os=0 generation=1 pid=' + futex_pid +
                        r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)', futex_body)
                    assert not any(row[3] in ('56', '435') for row in delivered), delivered
                    futex_routes = re.findall(route_pattern, futex_body)
                    for route_pid, worker_id, delivery_id, launcher_cpu, guest_cpu in futex_routes:
                        assert route_pid == futex_pid and guest_cpu == '0' and launcher_cpu != guest_cpu
                        key = (worker_id, delivery_id, guest_cpu)
                        assert len([row for row in delivered if row[:3] == key]) == 1
                        assert len([row for row in returned if row[:3] == key]) == 1
                    counts, events = {}, []
                    for match in re.finditer(r'file_pager=(create|release) handle=(\d+) references=(\d+) (shared|remaining)=(\d+)', futex_body):
                        operation, handle, refs, count_label, value = match.groups()
                        refs, value = int(refs), int(value)
                        if operation == 'create':
                            assert count_label == 'shared' and value == int(counts.get(handle, 0) > 0)
                            assert refs == counts.get(handle, 0) + 1
                            counts[handle] = refs
                        else:
                            assert count_label == 'remaining' and 0 < refs <= counts[handle]
                            counts[handle] -= refs
                            assert counts[handle] == value
                        events.append(match.groups())
                    assert counts and all(value == 0 for value in counts.values()), (counts, events)
                    record['native_ultra_futex'] = dict(sides=sides, same_guest_linux_reference=True,
                        same_binary=identity(futex_binary), sides_expected_stdout=expected_futex_stdout,
                        actual_mckernel_pid=int(futex_pid), actual_guest_tids=sorted(map(int, expected_tids)),
                        guest_futex_returns=futex_returns, normal_retirement=True, no_process_nodes=True,
                        pager_events=events, pager_references_remaining=counts,
                        sampled_deliveries=delivered, sampled_returns=returned, sampled_routes=futex_routes,
                        host_trace_delivery_cap=64, all_host_returns_audited=False,
                        host_trace_scope='Only sampled per-delivery records are paired; functional oracles and actual guest/syscall provenance are checked independently',
                        explicit_fixture_allocation_limit_bytes=1048576, mckernel_memory_mib=128,
                        mckernel_cpus=1, fork_cow_verified=False, direct_child_settid_verified=True,
                        direct_child_settid_scope='One valid aligned writable cell in CLONE_VM shared memory; exact child entry TID observed, kernel-cleared cell joined with shared futex',
                        raw_clone_tid_reused_by_later_pthread=raw_clone_tid in pthread_tids,
                        capability_blockers=futex_build_record['application_contract']['unsupported_or_unverified'])

                else:
                    marker = 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0'
                    assert marker in serial, state
                    capture(serial.split(marker, 1)[0], 'metadata', validate=True, resume=False)
                qmp('quit')
                process.wait(timeout=15)
                break
            time.sleep(0.1)
        assert process.returncode == 0 and seen == 2
    record.update(status='PASS', phase='complete',
                  buildid=dict(interfaces=2, states=4, guarded=8, faults=20, mcctrl_absent=True))
    assert identity(baseline_runner) == record['baseline_runner_preservation']['original']
    record['native_ultra_futex_application_executed'] = True
    if mode == 'application':
        record.update(launcher_reported_exit=37,
                      scope='Real dynamically linked libc application case '+case+' with exact output/exit/retirement, plus both native/compat pathname-copy descriptor ABIs, 28 data cases and eight descriptor faults; eight unchanged launcher ELF hello/exit-37 runs in one OS instance, each with native schedule, delegated write/return, exit, PID/TID publication/deletion, marked retirement and no remaining procfs process nodes; abnormal-owner and core readiness smokes remain pending')
    else:
        record['scope'] = 'Actual OS metadata query over both pointer widths, four live states, twenty copyout faults and eight bounded successful writes; no application execution'
    record['retained_baseline_scope'] = record['scope']
    record['scope'] = ('Complete original eight-HELLO/threads baseline plus the identical new futex binary '
        'directly in pinned guest Linux and McKernel: 16 errno/deadline cases, two runnable pthread '
        'workers and one valid shared-VM CHILD_SETTID/CHILD_CLEARTID thread. Exact output/exit, '
        'actual guest TIDs/syscalls, all process-node lifetimes and retirement/pager cleanup verified. '
        'No full transport-trace, fork/COW, invalid TID-store, realtime-step, robust/PI/WAKE_OP or UTI acceptance.')
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    if stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
