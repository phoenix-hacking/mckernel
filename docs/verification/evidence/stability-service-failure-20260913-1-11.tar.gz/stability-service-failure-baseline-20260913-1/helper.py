from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shutil,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
work=Path('/work');repo=Path('/workspace');out=work/'stability-service-failure-baseline-20260913-1';out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],children=[],module_attempt='2026091301',image_attempt='3',new_catalog_acceptance=False,production_gate_credit=False)
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 binding_path=work/'stability-service-failure-inputs-20260913-1/record.json';binding=json.loads(binding_path.read_text());assert binding['status']=='INPUTS_MATCH'
 record['bindings']=identity(binding_path);record['selected_pair']=binding['selected_pair'];record['supervisor']=identity(out/'supervisor.py')
 def recheck():
  for group in ('native_compiler_bindings','guest_production_bindings'):
   for row in binding[group]:
    actual=identity(repo/row['path']);assert(actual['sha256'],actual['size'])==(row['sha256'],row['size']),row
  for row in binding['selected_pair']['modules']:
   assert identity(Path(row['path']))==row,row
  for name in ('mckernel_image','linux_kernel','launcher','core'):
   row=binding['selected_pair'][name];assert identity(Path(row['path']))==row,row
 recheck()
 attempt='stability-service-failure-20260913-1';module='2026091301';image='3'
 rows=[]
 for mode in ('memory','files','threads','signals'):
  rows.append((mode,['/usr/bin/python3','-B','/work/run-native-ultra-baseline.py',mode,module,image,attempt],work/('native-ultra-baseline-'+mode+'-guest-20260909-'+attempt)))
 for kind,arch in [('regression','x86_64'),('compat','i386')]:
  rows.append(('control-'+arch,['/usr/bin/python3','-B','/work/run-native-ultra-control-'+kind+'.py',arch,module,image,attempt],work/('native-ultra-control-'+kind+'-20260909-'+arch+'-'+attempt)))
 for kind in ('signal-abi','futex'):
  rows.append((kind,['/usr/bin/python3','-B','/work/run-native-ultra-'+kind+'.py',module,image,'3','2026091302'],work/('native-ultra-'+kind+'-guest-20260909-2026091302')))
 env=dict(os.environ)
 for label,argv,directory in rows:
  assert shutil.disk_usage(work).free > 3*1024**3
  assert not directory.exists();recheck()
  source=Path(argv[2]);shutil.copyfile(source,out/(label+'-helper.py'))
  record['phase']=label;save();print('BATCH RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(work),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=700,cleanup_timeout_seconds=20,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,helper=identity(source),collection=result));save()
  assert result['status']=='COMPLETED' and result['wait_status']==dict(kind='exited',code=0) and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  child=json.loads((directory/'record.json').read_text());assert child['status']=='PASS' and child['qemu_exit_code']==0,(label,child['status'])
  record['children'].append(dict(label=label,record=identity(directory/'record.json'),status='PASS',qemu_exit_code=0));save()
 recheck();record.update(status='PASS',original_suites_passed=8)
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
