"""Run the unchanged real launcher and ordinary ELF in an isolated native guest."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast, gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
architecture, profile = 'x86_64', 'normal'
module_attempt, image_attempt, protocol_attempt, attempt = sys.argv[1:]
case = 'signals'
signal_protocol = Path('/work/native-signal-abi-protocol-20260909-' + protocol_attempt)
compiled = Path('/work/native-ultra-module-20260909-' + module_attempt)
images = Path('/work/mckernel-native-ultra-images-20260909-' + image_attempt)
launcher = Path('/work/native-application-launcher-20260908-2')
baseline = Path('/work/native-mcctrl-image-guest-20260908-x86_64-4')
assert case in ('memory','files','threads','signals')
mode='application'
out = Path('/work/native-ultra-signal-abi-guest-20260909-' + attempt)
out.mkdir()
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              architecture=architecture, profile=profile, mode=mode, inputs=[], commands=[], captures=[],
              cpuset=sorted(os.sched_getaffinity(0)), cpus=4, guest_cpus=1, numa_nodes=2,
              memory_mib=8192, container_memory_mib=12288, application_attempted=False,
              mckernel_application_executed=False, production_gate_credit=False)
sequence, stream, process = 0, None, None

# Reuse the exact accepted image-runner's physical capture and boot assertions.
# Extract only these complete function definitions, not its top-level run.
original_reference = (baseline / 'helper.py').read_text()
assert original_reference.count('continuing_workers=2') == 1
original = original_reference.replace('continuing_workers=2', 'continuing_workers=3')
names = {'identity', 'save', 'qmp', 'dump', 'capture'}
functions = [node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in functions} == names
exec(compile(ast.Module(body=functions, type_ignores=[]), str(out / 'capture-reference.py'), 'exec'))

def run(label, command, environment=None):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, result.returncode, (out / (label + '.log')).read_text()[-6000:])
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'helper.py')
    baseline_original = Path('/work/run-native-ultra-signal-abi-baseline-original.py')
    assert hashlib.sha256(baseline_original.read_bytes()).hexdigest() == '6113a42403cd8171e6d70c83208866cdc8b406941ca003b3803ad189921c8d1c'
    shutil.copyfile(baseline_original, out / 'baseline-runner-original.py')
    record['inputs'].append(identity(out / 'baseline-runner-original.py'))
    record['runner_adaptation'] = 'Complete original baseline retained; every original boot, metadata/string, HELLO and signals-core assertion applies to the exact preceding console. New signal cases have separate strict assertions. Guest fp-restart is explicitly BLOCKED, not a passing or skipped case.'
    shutil.copyfile(baseline / 'helper.py', out / 'capture-reference-original.py')
    (out / 'capture-reference.py').write_text(original)
    record['inputs'] += [identity(out / 'capture-reference-original.py'), identity(out / 'capture-reference.py')]
    record['capture_reference_adaptation'] = 'Only the exact continuing worker-count assertion changes from 2 to 3; both complete original and executed references retained.'
    assert shutil.disk_usage('/work').free > 2 * 1024**3
    for directory in (compiled, images, launcher, baseline):
        assert json.loads((directory / 'record.json').read_text())['status'] == 'PASS'
        record['inputs'].append(identity(directory / 'record.json'))
    built = json.loads((compiled / 'record.json').read_text())
    for row in built['outputs']:
        assert identity(Path(row['path'])) == row
    launches = json.loads((launcher / 'record.json').read_text())
    for selection in launches['launchers']:
        for row in selection['outputs']:
            assert identity(Path(row['path'])) == row
    for row in launches['outputs']:
        assert identity(Path(row['path'])) == row
    accepted = json.loads((baseline / 'record.json').read_text())
    if mode == 'application':
        metadata_test = Path('/work/native-application-services-buildid-guest-20260908-1/record.json')
        assert json.loads(metadata_test.read_text())['status'] == 'PASS'
        record['inputs'].append(identity(metadata_test))
    boot = baseline / 'root/bin/native-boot'
    # The complete prior capture and compiler command retain this exact binary.
    record['inputs'] += [identity(boot), identity(baseline / 'helper.py')]
    root = out / 'root'
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), root)
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(compiled / name, root / 'modules' / name)
        record['inputs'].append(identity(compiled / name))
    shutil.copy2(boot, root / 'bin/native-boot')
    assert (root / 'bin/native-boot').stat().st_mode & 0o111 == 0o111
    # Existing single-CPU oversubscription option is required for the original
    # two-pthread smoke. Preserve every original bootstrap assertion/command.
    original_boot_source=out/'boot-probe-original'
    boot_source=out/'boot-probe-source'
    shutil.copytree(baseline/'probe-source',original_boot_source)
    shutil.copytree(original_boot_source,boot_source)
    boot_text=(boot_source/'native-boot.c').read_text()
    old='(long)"hidos"'
    assert boot_text.count(old)==1
    (boot_source/'native-boot.c').write_text(boot_text.replace(old,'(long)"hidos allow_oversubscribe"'))
    original_boot_command=next(row['command'] for row in accepted['commands'] if row['label']=='probe-build')
    boot_command=[str(boot_source/'native-boot.c') if word==str(baseline/'probe-source/native-boot.c') else str(root/'bin/native-boot') if word==str(baseline/'root/bin/native-boot') else word for word in original_boot_command]
    record['boot_probe_adaptation']=dict(original_command=original_boot_command,executed_command=boot_command,kernel_command_line='hidos allow_oversubscribe',reason='Enable the existing supported configuration for two pthreads on one McKernel CPU; all original boot/application assertions retained.')
    run('boot-probe-oversubscribe',boot_command)
    record['inputs'] += [identity(p) for directory in [original_boot_source,boot_source] for p in sorted(directory.rglob('*')) if p.is_file()]
    record['inputs'].append(identity(root/'bin/native-boot'))
    application = launcher / 'native-application-hello'

    binary = launcher / 'rust/executer/user/mcexec'
    shutil.copyfile(binary, root / 'bin/mcexec')
    shutil.copyfile(application, root / 'bin/native-application-hello')
    (root / 'bin/mcexec').chmod(0o755)
    (root / 'bin/native-application-hello').chmod(0o755)
    record['inputs'] += [identity(binary), identity(application)]
    core=Path('/work/native-application-core-build-20260908-1')
    core_record=json.loads((core/'record.json').read_text());assert core_record['status']=='PASS'
    for row in core_record['outputs']:assert identity(Path(row['path']))==row
    shutil.copyfile(core/'native-application-core',root/'bin/native-application-core');(root/'bin/native-application-core').chmod(0o755)
    record['inputs'] += [identity(core/'record.json'),identity(core/'native-application-core'),identity(core/'native-application-core.c')]
    record['core_case']=case
    expected_core='NATIVE_CORE PASS '+case+'\n'
    assert next(row for row in core_record['linux_reference'] if row['case']==case)['stdout']==expected_core
    signal_record = json.loads((signal_protocol / 'record.json').read_text())
    assert signal_record['status'] == 'PASS'
    for row in signal_record['outputs']:
        assert identity(Path(row['path'])) == row
    signal_binary = signal_protocol / 'native-signal-abi'
    assert identity(signal_binary) == signal_record['binary']
    shutil.copyfile(signal_binary, root / 'bin/native-signal-abi')
    (root / 'bin/native-signal-abi').chmod(0o755)
    record['inputs'] += [identity(signal_protocol / 'record.json'), identity(signal_binary),
                         identity(signal_protocol / 'native-signal-abi.c')]
    launcher_diagnostic_reference = Path('/work/native-ultra-baseline-signals-guest-20260909-1/serial.log')
    assert launcher_diagnostic_reference.read_bytes().count(b'objdump /proc/self/exe: 2\r\nwarning: did not set LD_PRELOAD\r\n') == 9
    record['inputs'].append(identity(launcher_diagnostic_reference))
    record['launcher_diagnostic_contract'] = dict(reference=identity(launcher_diagnostic_reference), occurrences=9, exact_hex=b'objdump /proc/self/exe: 2\nwarning: did not set LD_PRELOAD\n'.hex(), scope='Frozen unchanged-launcher startup prefix; application stderr remains separately exact')
    controller_source = out / 'native-signal-controller.c'
    shutil.copyfile(repo / 'scripts/tests/fixtures/native-signal-controller.c', controller_source)
    run('signal-controller-build', ['cc', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
                                   '-Wl,-z,noexecstack', '-MD', '-MF', str(out / 'signal-controller.d'),
                                   str(controller_source), '-o', str(root / 'bin/native-signal-controller')])
    run('signal-controller-elf', ['readelf', '-h', '-l', str(root / 'bin/native-signal-controller')])
    run('signal-controller-disassembly', ['objdump', '-d', str(root / 'bin/native-signal-controller')])
    record['inputs'] += [identity(controller_source), identity(root / 'bin/native-signal-controller')]
    record['controller_compiler_dependencies'] = []
    for name in (out / 'signal-controller.d').read_text().replace('\\\n', ' ').split()[1:]:
        dependency = Path(name)
        if dependency.is_absolute() and dependency.is_file():
            record['controller_compiler_dependencies'].append(identity(dependency))
    assert record['controller_compiler_dependencies']
    for row in signal_record['runtime_libraries']:
        source = Path(row['captured']['path'])
        assert identity(source) == row['captured']
        target = root / row['original']['path'].lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == source.read_bytes(), str(target)
        else:
            shutil.copyfile(source, target)
        record['inputs'].append(identity(source))
    controller_dependencies = run('signal-controller-libraries', ['ldd', str(root / 'bin/native-signal-controller')])
    assert 'not found' not in controller_dependencies
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', controller_dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == original_path.read_bytes(), name
        else:
            shutil.copyfile(original_path, target)
        record['inputs'] += [identity(original_path), identity(target)]
    probe = out / 'probe-source'
    probe.mkdir()
    for name in ('native-os-buildid.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c', 'native-mcctrl-exec.c', 'native-mcctrl-string.c'):
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, probe / name)
    original_header = repo / 'ihk/linux/include/ihk/ihk_host_user.h'
    build_config = launcher / 'rust/config.h'
    shutil.copyfile(original_header, probe / 'ihk_host_user.h.reference')
    shutil.copyfile(build_config, probe / 'launcher-config.h.reference')
    macro = re.findall(r'^#define IHK_OS_GET_BUILDID\s+0x[0-9a-fA-F]+\s*$', original_header.read_text(), re.M)
    buildid = re.findall(r'^#define BUILDID ("[^"\n]+")$', build_config.read_text(), re.M)
    assert len(macro) == len(buildid) == 1
    payload = compiled / 'staged-source/ihk-compat-build-id.bin'
    assert payload.read_bytes() == json.loads(buildid[0]).encode() + b'\0'
    (probe / 'native-buildid-abi.h').write_text(macro[0].strip() + '\n#define BUILDID ' + buildid[0] + '\n')
    binding = Path('/work/native-sysfs-setup-module-20260907-1/bindings_generated.rs')
    states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', binding.read_text())
    assert len(states) == 1
    for bits, label in ((64, 'x86_64'), (32, 'i386')):
        run('buildid-probe-' + label, ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror',
                                     '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie',
                                     '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack',
                                     '-DCPUHP_FAILURE_STATE=' + states[0], str(probe / 'native-os-buildid.c'),
                                     '-o', str(root / ('bin/native-os-buildid-' + label))])
    protocol=repo/'executer/include/uprotocol.h'
    shutil.copyfile(protocol,probe/'uprotocol.h.reference')
    definition=re.search(r'^struct strncpy_from_user_desc \{[^}]+\};',protocol.read_text(),re.M);assert definition
    constant=re.search(r'^#define MCEXEC_UP_STRNCPY_FROM_USER[^\n]+',protocol.read_text(),re.M);assert constant
    (probe/'native-string-abi.h').write_text(constant[0]+'\n'+definition[0]+'\n')
    for bits,label in ((64,'x86_64'),(32,'i386')):
        run('string-probe-'+label,['cc','-m'+str(bits),'-O2','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-pie','-nostdlib','-static','-no-pie','-Wl,-e,_start','-Wl,-z,noexecstack','-DCPUHP_FAILURE_STATE='+states[0],str(probe/'native-mcctrl-string.c'),'-o',str(root/('bin/native-string-'+label))])
    record['inputs'] += [identity(p) for p in sorted(probe.iterdir())]
    record['inputs'] += [identity(binding), identity(payload)]
    # Use this native Linux userspace's libraries for both the base root and
    # the unchanged older-glibc-compatible launcher. Never mix libc releases.
    dependencies = run('launcher-native-dependencies', ['ldd', str(binary)])
    assert 'not found' not in dependencies
    record['runtime_libraries'] = []
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert identity(target)['sha256'] == identity(original_path)['sha256'], ('library mismatch', name)
        else:
            shutil.copyfile(original_path, target)
        record['runtime_libraries'].append(dict(original=identity(original_path), captured=identity(target)))
    assert len(record['runtime_libraries']) >= 3
    for row in core_record['runtime_libraries']:
        original=Path(row['original']['path']);assert identity(original)==row['original']
        target=root/str(original).lstrip('/')
        if target.exists():assert identity(target)['sha256']==row['original']['sha256']
        else:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        record['runtime_libraries'].append(dict(original=identity(original),captured=identity(target)))

    image_record = json.loads((images / 'record.json').read_text())
    assert image_record['native_clone3_guest_handler_compiled']
    clone_selection=next(row for row in image_record['clone3_table_checks'] if row['profile']=='native-rust')
    assert clone_selection['native'] and clone_selection['slot435']==clone_selection['rust_handler']!=0 and clone_selection['native_marker_bypass']
    record['clone3_image_selection']=clone_selection
    signal_selection=next(row for row in image_record['signal_stack_checks'] if row['profile']=='native-rust')
    assert signal_selection['native'] and signal_selection['prepare'] and signal_selection['publish']
    record['native_signal_stack_image_selection']=signal_selection

    selected = next(row for row in image_record['images'] if row['kind'] == 'native-rust')
    image = images / 'native-rust/kernel/mckernel.img'
    assert identity(image) in selected['outputs'] and not selected['native_sysfs_verify']
    (root / 'images').mkdir()
    shutil.copyfile(image, root / 'images/mckernel.img')
    init = '''#!/bin/bash
set -euo pipefail
[ "$$" -eq 1 ] && [ "$EUID" -eq 0 ] || exit 125
export PATH=/bin:/sbin:/usr/bin:/usr/sbin LANG=C LC_ALL=C
exec </dev/console >/dev/console 2>&1
finish() { local status=$?; trap - EXIT; if [ "$status" -ne 0 ]; then printf 'NATIVE_APPLICATION_GUEST FAIL status=%s\\n' "$status"; fi; /bin/dmesg || true; /poweroff; }
trap finish EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t debugfs debugfs /sys/kernel/debug
printf '7\\n' >/proc/sys/kernel/printk
read -r online </sys/devices/system/cpu/online
read -r nodes </sys/devices/system/node/online
[ "$online" = 0-3 ] && [ "$nodes" = 0-1 ]
insmod /modules/ihk.ko
insmod /modules/ihk-smp-x86_64.ko ihk_trampoline=524288
insmod /modules/mcctrl.ko
/bin/native-boot
rmmod mcctrl
/bin/native-os-buildid-x86_64
/bin/native-os-buildid-i386
insmod /modules/mcctrl.ko
/bin/native-string-x86_64
/bin/native-string-i386
'''
    if mode == 'application':
        init += '''
printf 'NATIVE_APPLICATION_LINUX_REFERENCE begin\\n'
status=0
/bin/native-application-hello || status=$?
printf 'NATIVE_APPLICATION_LINUX_REFERENCE exit=%s\\n' "$status"
[ "$status" -eq 37 ]
shopt -s nullglob
for iteration in {1..8}; do
printf '<6>NATIVE_APPLICATION_MCEXEC begin iteration=%s\\n' "$iteration" >/dev/kmsg
status=0
application_output=/application-stdout-$iteration
/bin/mcexec -t 1 0 /bin/native-application-hello >"$application_output" || status=$?
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s "$application_output")" -eq 25 ]
IFS= read -r application_line <"$application_output"
[ "$application_line" = NATIVE_APPLICATION_HELLO ]
printf '<6>NATIVE_APPLICATION_STDOUT iteration=%s bytes=25 line=%s\\n' "$iteration" "$application_line" >/dev/kmsg
printf '<6>NATIVE_APPLICATION_MCEXEC exit=%s iteration=%s\\n' "$status" "$iteration" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=%s\\n' "$iteration" >/dev/kmsg
done
printf '<6>NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37\\n' >/dev/kmsg
printf '<6>NATIVE_CORE_MCEXEC begin case=@CORE_CASE@\\n' >/dev/kmsg
status=0
/bin/mcexec -t 1 0 /bin/native-application-core @CORE_CASE@ >/core-stdout || status=$?
printf '<6>NATIVE_CORE_MCEXEC exit=%s case=@CORE_CASE@\\n' "$status" >/dev/kmsg
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s /core-stdout)" -eq @CORE_BYTES@ ]
IFS= read -r application_line </core-stdout
[ "$application_line" = 'NATIVE_CORE PASS @CORE_CASE@' ]
printf '<6>NATIVE_CORE_STDOUT bytes=@CORE_BYTES@ line=%s\\n' "$application_line" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_CORE_REGISTRATIONS_CLEAR case=@CORE_CASE@\\n' >/dev/kmsg
printf '<6>NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3\\n' >/dev/kmsg
for signal_case in mask-context fp-return; do
/bin/native-signal-controller --linux-reference /bin/native-signal-abi "$signal_case"
/bin/native-signal-controller --guest /bin/mcexec /bin/native-signal-abi "$signal_case"
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_SIGNAL_REGISTRATIONS_CLEAR case=%s\\n' "$signal_case" >/dev/kmsg
done
/bin/native-signal-controller --linux-reference /bin/native-signal-abi fp-restart
printf '<6>NATIVE_SIGNAL_RESTART BLOCKED guest=1 reason=native_mcctrl_missing_SIG_THREAD_and_SEND_SIGNAL\\n' >/dev/kmsg
printf '<6>NATIVE_SIGNAL_ABI_COMPLETE guest_cases=2 linux_cases=3 restart_guest=BLOCKED\\n' >/dev/kmsg
printf '<6>NATIVE_APPLICATION_GUEST PASS application_exit=37\\n' >/dev/kmsg
'''
    else:
        init += "printf 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0\\n'\n"
    init=init.replace('@CORE_CASE@',case).replace('@CORE_BYTES@',str(len(expected_core.encode())))
    (root / 'init').write_text(init)
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    env = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root))
    run('initramfs-spec', ['python3', '-B', '/work/write-native-cpio-spec.py'], env)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as target:
            generator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(generator.stdout, target)
            generator.stdout.close()
            assert generator.wait() == 0
    record['inputs'] += [identity(p) for p in (image, compiled / 'bzImage', root / 'init', out / 'initramfs.cpio.gz', Path('/work/write-native-cpio-spec.py'))]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off', '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args
    record['phase'] = 'guest'
    save()
    print('RUN guest', flush=True)
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20)
        connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            record['application_attempted'] = 'NATIVE_APPLICATION_MCEXEC begin' in serial
            for bad in ('NATIVE_SIGNAL_CONTROL FAIL', 'NATIVE_CORE FAIL', 'strncpy_from_user:ioctl:', 'ret: ', 'NATIVE_APPLICATION_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP', 'continuing service error', 'clear_host_pte failed'):
                assert bad not in serial, bad
            ready = serial.count('NATIVE_BOOT_CAPTURE x86_64 ready')
            if ready > seen:
                assert ready == seen + 1 and ready <= 2
                capture(serial, seen)
                seen += 1
            state = qmp('query-status')
            if state['status'] in ('shutdown', 'guest-panicked'):
                record['terminal_vm_state'] = state
                for interface in ('x86_64', 'i386'):
                    assert 'NATIVE_OS_BUILDID ' + interface + ' PASS states=2 guarded=4 faults=10 mcctrl_absent=1' in serial
                for interface in ('x86_64','i386'):
                    assert 'NATIVE_STRING_COPY '+interface+' PASS cases=14 descriptor_faults=4 guarded=1 applications=0' in serial
                record['native_string_copy']=dict(interfaces=2,data_cases=28,descriptor_faults=8,guarded=True,source_and_destination_fields_preserved=True)
                if mode == 'application':
                    assert 'NATIVE_APPLICATION_GUEST PASS application_exit=37' in serial, state
                    full_console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]
                    console=full_console.split('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3',1)[0]
                    windows=re.findall(r'NATIVE_APPLICATION_MCEXEC begin iteration=(\d+)(.*?)NATIVE_APPLICATION_MCEXEC exit=37 iteration=\1\b',console,re.S)
                    assert [int(i) for i,body in windows]==list(range(1,9)),windows
                    launches=[]
                    for iteration,body in windows:
                        assert body.count('NATIVE_APPLICATION_HELLO')==1,body
                        assert 'NATIVE_APPLICATION_STDOUT iteration='+iteration+' bytes=25 line=NATIVE_APPLICATION_HELLO' in body,body
                        schedules=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',body)
                        assert len(schedules)==1,schedules
                        pid=schedules[0]
                        delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',body)
                        returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',body)
                        writes=[row for row in delivered if row[3]=='1'];assert len(writes)==1,delivered
                        assert writes[0][:3]+('25',) in returned,(delivered,returned)
                        assert any(row[3]=='231' for row in delivered),delivered
                        for operation in ('published','deleted'):
                            assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',body),operation
                        assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',body),body
                        assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',body),body
                        launches.append(dict(iteration=int(iteration),pid=int(pid),delivered=delivered,returned=returned,write_bytes=25,stdout_hex=b'NATIVE_APPLICATION_HELLO\n'.hex(),stdout_verification='guest regular file, exact 25 bytes, successful newline read and exact line comparison; copied into ordered printk record',exit_code=37,marked_retirement=True,registration_released=True))
                    # The original write-25 regression applies to the eight HELLO
                    # launches. Libc routes are checked below against their own
                    # delivery/result identities, including legitimate errors.
                    hello_console=console.split('NATIVE_CORE_MCEXEC begin case='+case,1)[0]
                    route_pattern=r'application_syscall=return_route os=0 generation=1 pid=(\d+) worker=(\d+) delivery=(\d+) launcher_cpu=(-?\d+) guest_cpu=(\d+)'
                    routes=re.findall(route_pattern,hello_console)
                    assert any(row[3]=='1' and row[4]=='0' for row in routes),('distinct launcher/guest CPU case not observed',routes)
                    for pid,worker,delivery,launcher_cpu,guest_cpu in routes:
                        launch=next(row for row in launches if row['pid']==int(pid))
                        assert (worker,delivery,guest_cpu,'25') in launch['returned']
                    record['return_routes']=routes
                    assert len(set(row['pid'] for row in launches))==8
                    assert re.findall(r'NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=(\d+)',console)==list(map(str,range(1,9)))
                    assert 'NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37' in console
                    assert 'cleanup retained' not in console and 'reap_retained' not in console
                    record['native_application']=dict(applications=8,launches=launches,same_os_instance=True,no_process_nodes_after_each=True)
                    record['mckernel_application_executed']=True
                    core_body=console.split('NATIVE_CORE_MCEXEC begin case='+case,1)[1].split('NATIVE_CORE_MCEXEC exit=37 case='+case,1)[0]
                    core_pids=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',core_body);assert len(core_pids)==1,core_pids
                    pid=core_pids[0]
                    assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',core_body),core_body
                    assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',core_body),core_body
                    for operation in ('published','deleted'):
                        assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',core_body),core_body
                    assert 'NATIVE_CORE_STDOUT bytes='+str(len(expected_core.encode()))+' line='+expected_core.rstrip('\n') in console
                    assert 'NATIVE_CORE_REGISTRATIONS_CLEAR case='+case in console
                    delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',core_body)
                    returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',core_body)
                    assert not any(row[3]=='435' for row in delivered),('clone3 incorrectly delegated to Linux',delivered)
                    core_routes=re.findall(route_pattern,core_body)
                    assert len(re.findall(route_pattern,console))==len(routes)+len(core_routes)
                    for route_pid,worker,delivery,launcher_cpu,guest_cpu in core_routes:
                        assert route_pid==pid and guest_cpu=='0' and launcher_cpu!=guest_cpu
                        assert len([row for row in delivered if row[:3]==(worker,delivery,guest_cpu)])==1
                        assert len([row for row in returned if row[:3]==(worker,delivery,guest_cpu)])==1
                    assert all(row[2]=='0' for row in delivered+returned)
                    record['core_application']=dict(case=case,pid=int(pid),exit_code=37,stdout=expected_core,normal_dynamic_libc=True,marked_retirement=True,registration_released=True,no_process_nodes=True,delivered=delivered,returned=returned,return_routes=core_routes)
                    assert re.search(r'full guest ready os=0 generation=1 status=3 sysfs_requests=\d+ continuing_workers=3',console)
                    zeroed=re.findall(r'allocator zeroed os=0 generation=1 sequence=(\d+) pid=(\d+) cpu=(\d+) chunks=(\d+) pages=(\d+) pending=(-?\d+) workers=(-?\d+)',console)
                    assert zeroed and any(int(row[3])>0 and int(row[4])>0 for row in zeroed),zeroed
                    assert all(row[2]=='0' and int(row[5])>=0 and int(row[6])>=0 for row in zeroed),zeroed
                    record['allocator_zeroing']=zeroed
                    invalidated=re.findall(r'host_mapping=invalidated os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) value=(-?\d+) completed=(-?\d+)',core_body)
                    if case=='memory':assert len(invalidated)>=3,invalidated
                    assert all(row[2:]==('0','0') for row in invalidated),invalidated
                    record['host_invalidations']=invalidated
                    counts={};events=[]
                    for match in re.finditer(r'file_pager=(create|release) handle=(\d+) references=(\d+) (shared|remaining)=(\d+)',core_body):
                        operation,handle,refs,label,value=match.groups();refs=int(refs);value=int(value)
                        if operation=='create':
                            assert label=='shared' and value==int(counts.get(handle,0)>0)
                            assert refs==counts.get(handle,0)+1
                            counts[handle]=refs
                        else:
                            assert label=='remaining' and 0<refs<=counts[handle]
                            counts[handle]-=refs;assert counts[handle]==value
                        events.append(match.groups())
                    assert counts and all(value==0 for value in counts.values()),(counts,events)
                    record['file_pager_lifetime']=dict(events=events,remaining_references=counts,all_created_handles_released=True)

                    capture(serial.split('NATIVE_APPLICATION_GUEST PASS', 1)[0], 'application', validate=False, resume=False)
                    if case=='signals':
                        guest_log=(out/'capture-application/kmsg.txt').read_text()
                        frames=re.findall(r'signal_handler pid='+pid+r' tid='+pid+r' sig=10 handler=(0x[0-9a-f]+) restorer=(0x[0-9a-f]+) old_rip=(0x[0-9a-f]+) old_sp=(0x[0-9a-f]+) new_sp=(0x[0-9a-f]+)',guest_log)
                        assert len(frames)==2 and frames[0][4]==frames[1][4],frames
                        assert all(int(row[4],16)<int(row[3],16) for row in frames),frames
                        returns=re.findall(r'mcexec_v10: syscall return cpu=0 pid='+pid+r' tid='+pid+r' nr=15 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        assert returns==['0','0'],returns
                        assert 'ret: ' not in console
                        record['native_signal_application']=dict(frames=frames,actual_sigreturn_results=list(map(int,returns)),blocked_pending_unblocked_and_repeated_altstack_assertions_passed=True,interrupted_host_return_errors=0)
                    if case=='threads':
                        transfers=re.findall(r'application_tids=transferred os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) physical=([0-9a-f]+) bytes=(\d+)',core_body)
                        assert len(transfers)==1 and int(transfers[0][3])==128*4,transfers
                        worker,delivery,physical,length=transfers[0]
                        assert (worker,delivery,'0','186') in delivered
                        assert (worker,delivery,'0','0') in returned
                        record['native_tid_transfer']=dict(worker=int(worker),delivery=int(delivery),physical=int(physical,16),bytes=int(length),actual_gettid_result=0)
                        guest_log=(out/'capture-application/kmsg.txt').read_text()
                        clones=re.findall(r'mcexec_v10: syscall return cpu=0 pid='+pid+r' tid='+pid+r' nr=435 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        assert len(clones)==2 and len(set(clones))==2 and all(int(tid)>0 and tid!=pid for tid in clones),clones
                        tids={pid,*clones}
                        observed=set(re.findall(r'mcexec_v10: syscall entry cpu=0 pid='+pid+r' tid=(\d+) nr=\d+\b',guest_log))
                        assert observed==tids,(tids,observed)
                        for operation in ('published','deleted'):
                            lifecycle=set(re.findall(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid=(\d+)\b',core_body))
                            assert lifecycle==tids,(operation,tids,lifecycle)
                        record['native_clone3_application']=dict(parent_tid=int(pid),child_tids=list(map(int,clones)),executing_guest_tids=sorted(map(int,observed)),host_clone3_delegations=0,all_thread_procfs_published_and_deleted=True,pthread_barrier_mutex_tls_and_join_passed=True)


                    assert full_console.count('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3') == 1
                    extra_console = full_console.split('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3', 1)[1]
                    assert 'cleanup retained' not in extra_console and 'reap_retained' not in extra_console
                    case_order = re.findall(r'NATIVE_SIGNAL_BEGIN guest=(\d) case=([a-z-]+)', extra_console)
                    assert case_order == [('0','mask-context'),('1','mask-context'),('0','fp-return'),('1','fp-return'),('0','fp-restart')], case_order
                    cases = []
                    for guest, signal_case in case_order:
                        begin = 'NATIVE_SIGNAL_BEGIN guest=' + guest + ' case=' + signal_case
                        window = extra_console.split(begin,1)[1].split('NATIVE_SIGNAL_BEGIN',1)[0]
                        terminal = re.findall(r'NATIVE_SIGNAL_CONTROL PASS guest='+guest+r' case='+signal_case+r' pid=(\d+) tid=(-?\d+) raw_status=(\d+) exit=(\d+)',window)
                        assert len(terminal) == 1, (signal_case, terminal)
                        signal_pid, signal_tid, raw_status, exit_code = terminal[0]
                        assert raw_status == str(37 << 8) and exit_code == '37'
                        expected_stdout = (b'NATIVE_SIGNAL_RESTART_READY\n' if signal_case == 'fp-restart' else b'') + ('NATIVE_SIGNAL_ABI PASS '+signal_case+'\n').encode()
                        payload_stderr = b'NATIVE_SIGNAL_RESTART_HANDLED\n' if signal_case == 'fp-restart' else b''
                        launcher_stderr = b'objdump /proc/self/exe: 2\nwarning: did not set LD_PRELOAD\n' if guest == '1' else b''
                        expected_stderr = launcher_stderr + payload_stderr
                        for stream_name, expected in [('stdout',expected_stdout),('stderr',expected_stderr)]:
                            streams = re.findall(r'NATIVE_SIGNAL_STREAM guest='+guest+r' case='+signal_case+r' stream='+stream_name+r' bytes=(\d+) hex=([0-9a-f]*)',window)
                            assert len(streams) == 1 and int(streams[0][0]) == len(expected) and streams[0][1] == expected.hex(), (signal_case,stream_name,streams)
                        row = dict(case=signal_case, guest=guest=='1', pid=int(signal_pid), worker_tid=int(signal_tid),
                                   raw_wait_status=int(raw_status), exit_code=37, stdout_hex=expected_stdout.hex(),
                                   stderr_hex=expected_stderr.hex(), exact_streams=True,
                                   launcher_stderr_hex=launcher_stderr.hex(), payload_stderr_hex=payload_stderr.hex(),
                                   stream_accounting="Exact complete bytes; frozen launcher prefix and unchanged payload suffix; no arbitrary filtering")
                        if guest == '0':
                            assert not re.search(r'application SCHEDULE os=',window)
                            if signal_case == 'fp-restart':
                                blocked = re.findall(r'NATIVE_SIGNAL_BLOCKED guest=0 case=fp-restart pid='+signal_pid+r' tid='+signal_tid+r' syscall=0 0x0 (0x[0-9a-f]+) 0x1\b',window)
                                assert len(blocked) == 1 and signal_pid == signal_tid, (blocked,terminal)
                                assert 'NATIVE_SIGNAL_HANDLED_BEFORE_INPUT guest=0 case=fp-restart pid='+signal_pid+' tid='+signal_tid+' input=a5' in window
                                row.update(blocked_read_observed=True,read_buffer=blocked[0],handler_ack_before_input=True,input_hex='a5')
                            else:
                                assert signal_tid == '-1'
                            cases.append(row)
                            continue
                        assert signal_tid == '-1'
                        assert re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',window) == [signal_pid]
                        for operation in ('published','deleted'):
                            assert re.findall(r'application procfs '+operation+r' os=0 generation=1 pid='+signal_pid+r' tid=(\d+)\b',window) == [signal_pid], (signal_case,operation)
                        assert len(re.findall(r'application retirement os=0 generation=1 pid='+signal_pid+r' token=\d+ errno=0\b',window)) == 1
                        assert len(re.findall(r'application_process=release os=0 generation=1 pid='+signal_pid+r' cleanup_errno=0\b',window)) == 1
                        assert 'NATIVE_SIGNAL_REGISTRATIONS_CLEAR case='+signal_case in window
                        signal_delivered = re.findall(r'application_syscall=delivered os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',window)
                        signal_returned = re.findall(r'application_syscall=returned os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',window)
                        assert signal_delivered and all(item[2] == '0' for item in signal_delivered+signal_returned)
                        # Existing do_sigaction/rt_sigprocmask update guest state
                        # and mirror setup to the host. Handler execution and
                        # rt_sigreturn/tgkill/altstack remain guest-owned.
                        assert not any(item[3] in ('15','56','131','234','435') for item in signal_delivered), signal_delivered
                        mirrored_setup = [item for item in signal_delivered if item[3] in ('13','14')]
                        assert {item[3] for item in mirrored_setup} == {'13','14'}
                        for item in mirrored_setup:
                            assert len([returned for returned in signal_returned if returned == item[:3]+('0',)]) == 1, item
                        writes = [item for item in signal_delivered if item[3] == '1']
                        assert len(writes) == 1 and writes[0][:3]+(str(len(expected_stdout)),) in signal_returned, (writes,signal_returned)
                        assert any(item[3] == '231' for item in signal_delivered)
                        signal_routes = re.findall(route_pattern,window)
                        for route_pid, worker, delivery, launcher_cpu, guest_cpu in signal_routes:
                            assert route_pid == signal_pid and guest_cpu == '0' and launcher_cpu != guest_cpu
                            assert len([item for item in signal_delivered if item[:3] == (worker,delivery,guest_cpu)]) == 1
                            assert len([item for item in signal_returned if item[:3] == (worker,delivery,guest_cpu)]) == 1
                        signal_invalidations = re.findall(r'host_mapping=invalidated os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) value=(-?\d+) completed=(-?\d+)',window)
                        assert all(item[2:] == ('0','0') for item in signal_invalidations)
                        counts = {}; events = []
                        for match in re.finditer(r'file_pager=(create|release) handle=(\d+) references=(\d+) (shared|remaining)=(\d+)',window):
                            operation, handle, refs, label, value = match.groups(); refs=int(refs); value=int(value)
                            if operation == 'create':
                                assert label == 'shared' and value == int(counts.get(handle,0)>0)
                                assert refs == counts.get(handle,0)+1
                                counts[handle] = refs
                            else:
                                assert label == 'remaining' and 0 < refs <= counts[handle]
                                counts[handle] -= refs
                                assert counts[handle] == value
                            events.append(match.groups())
                        assert counts and all(value == 0 for value in counts.values()), (counts,events)
                        guest_log = (out/'capture-application/kmsg.txt').read_text()
                        signal_frames = re.findall(r'signal_handler pid='+signal_pid+r' tid='+signal_pid+r' sig=(\d+) handler=(0x[0-9a-f]+) restorer=(0x[0-9a-f]+) old_rip=(0x[0-9a-f]+) old_sp=(0x[0-9a-f]+) new_sp=(0x[0-9a-f]+)',guest_log)
                        signal_returns = re.findall(r'mcexec_v10: syscall return cpu=0 pid='+signal_pid+r' tid='+signal_pid+r' nr=15 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        expected_signals = ['10','12'] if signal_case == 'mask-context' else ['10']
                        expected_returns = ['12345','12345'] if signal_case == 'mask-context' else ['0']
                        assert [item[0] for item in signal_frames] == expected_signals, signal_frames
                        assert signal_returns == expected_returns, signal_returns
                        assert 'native bad signal frame' not in guest_log
                        row.update(delivered=signal_delivered,returned=signal_returned,return_routes=signal_routes,
                                   pager_events=events,pager_remaining=counts,invalidations=signal_invalidations,
                                   frames=signal_frames,sigreturn_results=list(map(int,signal_returns)),
                                   normal_retirement=True,procfs_cleared=True,guest_fork_executed=False,
                                   mirrored_signal_setup=mirrored_setup, setup_mirror_returns_exact_zero=True)
                        cases.append(row)
                    assert len({item['pid'] for item in cases}) == 5
                    assert not {item['pid'] for item in cases if item['guest']} & {item['pid'] for item in launches}
                    assert record['core_application']['pid'] not in {item['pid'] for item in cases}
                    assert 'NATIVE_SIGNAL_RESTART BLOCKED guest=1 reason=native_mcctrl_missing_SIG_THREAD_and_SEND_SIGNAL' in extra_console
                    assert 'NATIVE_SIGNAL_ABI_COMPLETE guest_cases=2 linux_cases=3 restart_guest=BLOCKED' in extra_console
                    record['signal_abi_cases'] = cases
                    record['signal_guest_restart'] = dict(status='BLOCKED',guest_executed=False,
                        reason='Selected native mcctrl lacks SIG_THREAD and SEND_SIGNAL. Unchanged launcher external-signal handler receives EINVAL and exits1.',
                        prerequisite='Max must design, implement and validate native signal forwarding with existing descriptor/packet ownership before activating the prepared controller guest fp-restart invocation.',
                        controller_prepared=True,timeout_seconds=45,expected_raw_wait_status=37<<8,
                        expected_stdout_hex=(b'NATIVE_SIGNAL_RESTART_READY\nNATIVE_SIGNAL_ABI PASS fp-restart\n').hex(),
                        expected_stderr_hex=b'NATIVE_SIGNAL_RESTART_HANDLED\n'.hex(),required_read_bytes=1,
                        required_input_hex='a5',handler_ack_before_input=True)
                    record['signal_guest_cases_passed'] = ['mask-context','fp-return']
                    record['signal_linux_cases_passed'] = ['mask-context','fp-return','fp-restart']
                    record['signal_reference_kernel'] = identity(compiled/'bzImage')

                else:
                    marker = 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0'
                    assert marker in serial, state
                    capture(serial.split(marker, 1)[0], 'metadata', validate=True, resume=False)
                qmp('quit')
                process.wait(timeout=15)
                break
            time.sleep(0.1)
        assert process.returncode == 0 and seen == 2
    record.update(status='PASS', phase='complete',
                  buildid=dict(interfaces=2, states=4, guarded=8, faults=20, mcctrl_absent=True))
    if mode == 'application':
        record.update(launcher_reported_exit=37,
                      scope='Real dynamically linked libc application case '+case+' with exact output/exit/retirement, plus both native/compat pathname-copy descriptor ABIs, 28 data cases and eight descriptor faults; eight unchanged launcher ELF hello/exit-37 runs in one OS instance, each with native schedule, delegated write/return, exit, PID/TID publication/deletion, marked retirement and no remaining procfs process nodes; abnormal-owner and core readiness smokes remain pending')
    if mode == 'application':
        record['scope'] = 'Two benign signal ABI guest cases (mask-context, fp-return), three same-payload references on the exact pinned Linux kernel, plus every unchanged eight-HELLO/signals-core/boot/control regression. Guest external-signal fp-restart is BLOCKED by missing native forwarding and receives no acceptance credit.'
    else:
        record['scope'] = 'Actual OS metadata query over both pointer widths, four live states, twenty copyout faults and eight bounded successful writes; no application execution'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    if stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
