from pathlib import Path
import hashlib, importlib.util
from types import SimpleNamespace
p=Path('/workspace/scripts/tests/prepare_stability_published_guest.py')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='addbadabce8cba4db7ef863fc8728e68150e8301ccc55972a5ef623f52160056'
spec=importlib.util.spec_from_file_location('published_guest_preparer',p)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.prepare(SimpleNamespace(output=Path('/work/stability-published-guest-root-20260913-postpublish-notify-1'),module=Path('/work/stability-published-hold-module-20260913-postpublish-notify-1'),mode='postpublish-notify',nonce='f488fef2b3df4028a18651ca1ac3dde0',controller_profile='owner-published-hold-v1',payload_profile='runnable-thread-v1'))
