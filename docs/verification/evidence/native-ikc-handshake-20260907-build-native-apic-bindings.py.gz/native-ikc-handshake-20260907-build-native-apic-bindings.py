from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo=Path('/workspace'); source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2'); build=Path('/work/native-build-base-24a151fe')
prior=Path('/work/native-irq-transport-exact-stage-20260907-1')
out=Path('/work/native-apic-bindings-kernel-20260907-' + sys.argv[1]); out.mkdir()
patch=repo/'host-kernel/kbuild/patches/0007-rust-bindings-expose-x86-apic-driver.patch'
record=dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(), commands=[], production_gate_credit=False)
def identity(path):
    data=path.read_bytes(); return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(): (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
def run(label, command):
    print('RUN',label,flush=True); (out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=command,exit_code=result.returncode)); save()
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])
try:
    shutil.copyfile(__file__,out/'helper.py'); shutil.copyfile(patch,out/patch.name)
    shutil.copyfile(source/'rust/bindings/bindings_helper.h',out/'before-bindings_helper.h')
    shutil.copyfile(build/'rust/bindings/bindings_generated.rs',out/'before-bindings_generated.rs')
    run('patch-check',['patch','-d',str(source),'-p1','--batch','--dry-run','--fuzz=0','-i',str(patch)])
    run('patch-apply',['patch','-d',str(source),'-p1','--batch','--fuzz=0','-i',str(patch)])
    shutil.copyfile(source/'rust/bindings/bindings_helper.h',out/'after-bindings_helper.h')
    run('kernel-build',shlex.split((prior/'kernel-build.command').read_text()))
    run('baseline-module-build',shlex.split((prior/'module-build.command').read_text()))
    for relative,name in [('.config','resolved.config'),('Module.symvers','Module.symvers'),('arch/x86/boot/bzImage','bzImage'),('rust/bindings/bindings_generated.rs','bindings_generated.rs')]: shutil.copyfile(build/relative,out/name)
    text=(out/'bindings_generated.rs').read_text()
    assert 'pub struct apic {' in text and 'pub fn dest_mode_logical(' in text and 'pub static mut apic: *mut apic;' in text
    assert (out/'resolved.config').read_bytes()==(Path('/work/native-boot-api-kernel-20260907-1')/'resolved.config').read_bytes()
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')]
    save(); print(record['status'],out,flush=True)
