from pathlib import Path
import subprocess
root = Path('/work/recovery-cJDpVLRT')
with (root / 'native-module-checks.log').open('xb') as log:
    subprocess.run(['python3', '-B', str(root / 'check-native-image-loader-modules.py')],
                   stdout=log, stderr=subprocess.STDOUT, check=True)
print('Recovered native modules: source identity, artifact hashes, formatting and ELF/no-SIMD checks passed.', flush=True)
subprocess.run(['python3', '-B', '/work/run-native-image-loader-guest.py',
                '/work/native-image-loader-prototype-20260907-2',
                '/work/native-image-loader-guest-recovery-20260907-1'], check=True)
