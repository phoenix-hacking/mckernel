/work/native-procfs-objects-module-20260908-1/source/scripts/tests/fixtures/mckernel_procfs_objects_verify.o
