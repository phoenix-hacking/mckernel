from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
build = Path('/work/native-build-base-24a151fe')
linux = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
kernel = Path('/work/native-topology-kernel-20260907-1')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
out = Path('/work/native-procfs-objects-module-20260908-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], compiler_inputs=[], commands=[], production_gate_credit=False,
    procfs_service_completed=False, declared_stage=False)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-9000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    for name in ['.config', 'Module.symvers', 'rust/bindings/bindings_generated.rs']:
        source = build / name
        target = out / Path(name).name
        shutil.copyfile(source, target)
        record['inputs'].append(identity(target))
    for name in ['fs/proc/inode.c', 'fs/proc/generic.c', 'fs/proc/internal.h', 'include/linux/proc_fs.h', 'fs/read_write.c', 'rust/kernel/uaccess.rs', 'rust/kernel/sync/lock/mutex.rs']:
        target = out / 'linux-reference' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(linux / name, target)
        record['inputs'].append(identity(target))
    shutil.copyfile(__file__, out / 'helper.py')
    inputs = ['host-kernel/native-rust/procfs_objects.rs',
              'scripts/tests/fixtures/mckernel_procfs_objects_verify.rs',
              'scripts/tests/fixtures/native-procfs-objects.c',
              'scripts/tests/fixtures/native_procfs_objects_layout.c']
    for name in inputs:
        for base in ['original-inputs', 'source']:
            target = out / base / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(repo / name, target)
        record['inputs'].append(identity(out / 'original-inputs' / name))
    rust = [str(out / 'source' / name) for name in inputs if name.endswith('.rs')]
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + rust)
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false'] + rust)
    record['compiler_inputs'] = [identity(out / 'source' / name) for name in inputs]
    module = out / 'source/scripts/tests/fixtures'
    (module / 'Kbuild').write_text('obj-m += mckernel_procfs_objects_verify.o\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('layout-witness', base + ['M=' + str(module), 'native_procfs_objects_layout.o'])
    run('c-layout-extract', ['objcopy', '--dump-section', '.mckernel_procfs_layout=' + str(out / 'c-layout.bin'),
                           str(module / 'native_procfs_objects_layout.o'), str(out / 'c-layout-copy.o')])
    run('module-build', base + ['M=' + str(module), 'modules'])
    compiled = out / 'mckernel_procfs_objects_verify.ko'
    shutil.copyfile(module / compiled.name, compiled)
    run('rust-layout-extract', ['objcopy', '--dump-section', '.mckernel_procfs_layout=' + str(out / 'rust-layout.bin'),
                          str(compiled), str(out / 'rust-layout-copy.ko')])
    assert (out / 'rust-layout.bin').read_bytes() == (out / 'c-layout.bin').read_bytes()
    record['layout'] = list(struct.unpack('<27Q', (out / 'c-layout.bin').read_bytes()))
    for tool, name in [(['nm', '-u'], 'undefined.txt'), (['objdump', '-d'], 'disassembly.txt'),
                       (['readelf', '-h'], 'elf-header.txt')]:
        (out / name).write_bytes(subprocess.check_output(tool + [str(compiled)]))
    symbols = (out / 'undefined.txt').read_text()
    for name in ('proc_mkdir_mode', 'proc_create_data', 'proc_remove', 'proc_set_user'):
        assert ' U ' + name + '\n' in symbols, name
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', (out / 'disassembly.txt').read_text())
    assert 'ELF64' in (out / 'elf-header.txt').read_text()
    run('user-probe-build', ['gcc', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror',
        str(module / 'native-procfs-objects.c'), '-o', str(out / 'native-procfs-objects')])
    run('user-probe-dependencies', ['ldd', str(out / 'native-procfs-objects')])
    libraries = out / 'lib64'; libraries.mkdir()
    for name in ['libc.so.6', 'ld-linux-x86-64.so.2']:
        source = Path('/lib64') / name
        shutil.copy2(source, libraries / name)
        record['inputs'].append(identity(libraries / name))
    for row in record['inputs'] + record['compiler_inputs']: assert identity(Path(row['path'])) == row, row
    record.update(status='PASS', scope='Native procfs VFS owners and layout fixture compile; no guest request or application service integrated', mckernel_application_executed=False)
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name not in ('record.json', 'phase')]
    save(); print(record['status'], out, flush=True)
