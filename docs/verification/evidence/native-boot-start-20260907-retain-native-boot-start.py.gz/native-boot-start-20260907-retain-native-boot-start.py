from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-boot-start-retained-20260907-2'
out.mkdir()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): value.update(data)
    return value.hexdigest()

record = dict(created_utc=datetime.now(timezone.utc).isoformat(), artifacts=[], captures=[],
    production_gate_credit=False, mckernel_boot_proven=False, mckernel_arch_entry_proven=True,
    declared_stage=False,
    passed=[
        'Pinned Linux export patch 0006 rebuilds without changing the existing INIT/SIPI C function body',
        'All three prototype native modules build and pass ELF/no-SIMD checks; exact C witnesses match both boot layouts',
        'Both user ABIs over two preparation module lifetimes pass 32 forced allocation failures, exclusion, reprepare, CPU invalidation and complete unstarted restoration',
        'Four independently checked QMP preparation snapshots include whole original assembly, boot tails, dump bitmaps and zero guest status',
        'Real native and compat BOOT operations start the assigned AP, reach architectural status 2 and publish both real IKC master queues',
        'Independent CPU registers resolve to the retained guest post_init host-ack wait, with owned guest CR3 and valid queue headers',
        'Failed/incomplete boot stays Failed and retains OS/module/CPU/memory owners after file close; mutation, destruction and module removal are rejected'],
    limitations=[
        'No host INIT_ACK, cross-kernel queue exchange, guest status 3, full boot or applications yet',
        'The first actual-start capture failed by expecting a temporary startup page to remain unchanged after the guest allocator cleared it; original failure and diagnosis are retained',
        'VM teardown contains started resources but is not a proven native shutdown or restoration',
        'Current native declared stage, licensing, FFI/lifecycle contracts and downstream byte bindings still require boot integration',
        'Earlier full suite covers the preceding IRQ transport stage, not these new boot sources',
        'Performance event tables remain unsupported/zero, huge-page profile is fixed at 2 MiB and KARGS is not yet connected',
        'Earlier intermittent Linux idle/RCU stall, full Rust/assembly completion and independent production acceptance remain open'])
record['retention_retry'] = 'Attempt 1 rejected a raw byte identity claim for an unchanged source that the prototype formatted. Attempt 2 proves the exact recorded formatting transformation without rewriting unrelated repository inputs.'

def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''): stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name, source=str(path),
        size=target.stat().st_size, sha256=digest(target), unpacked_size=path.stat().st_size, unpacked_sha256=digest(path)))

names = ['native-boot-api-kernel-20260907-1', 'native-boot-prototype-20260907-1',
         'native-boot-guest-20260907-prepare-1', 'native-boot-guest-20260907-start-x86_64-1',
         'native-boot-start-diagnosis-20260907-1', 'native-boot-guest-20260907-start-x86_64-2',
         'native-boot-guest-20260907-start-i386-1']
for name in names:
    path = work / name
    metadata = json.loads((path / 'record.json').read_text())
    expected = 'FAIL' if name == 'native-boot-guest-20260907-start-x86_64-1' else (2 if name.startswith('native-boot-start-diagnosis') else 'PASS')
    assert metadata['status'] == expected, (name, metadata['status'])
    for row in metadata.get('inputs', []) + metadata.get('outputs', []):
        item = Path(row['path'])
        assert item.stat().st_size == row['size'] and digest(item) == row['sha256'], item
    for capture in metadata.get('captures', []):
        for row in capture.get('artifacts', []):
            item = Path(row['path'])
            assert item.stat().st_size == row['size'] and digest(item) == row['sha256'], item
    record['captures'].append(dict(directory=name, status=metadata['status'], source_parent=metadata.get('source_parent'),
        started_utc=metadata.get('started_utc'), finished_utc=metadata.get('finished_utc')))
    target = out / (name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive: archive.add(path, arcname=name)
    assert target.stat().st_size < 95 << 20, target
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
        source=str(path), size=target.stat().st_size, sha256=digest(target)))
    add(path / 'record.json', name + '-record.json.gz')
    for short in ('serial.log', 'debugcon.log', 'kmsg.txt'):
        if (path / short).exists(): add(path / short, name + '-' + short + '.gz')

for name in ('build-native-boot-api-kernel.py', 'build-native-boot-prototype.py', 'run-native-boot-guest.py',
             'diagnose-native-boot-start.py', 'retain-native-boot-start.py'):
    add(work / name, 'native-boot-start-20260907-' + name + '.gz')
add(work / 'native-boot-start-retained-20260907-1/failed-helper.py', 'native-boot-start-20260907-retention-attempt-1.py.gz')
add(work / 'native-boot-start-retained-20260907-1/failure.json', 'native-boot-start-20260907-retention-attempt-1.json.gz')

stage = work / 'native-boot-prototype-20260907-1/staged-source'
record['current_compiler_inputs'] = []
for path in sorted(stage.rglob('*')):
    if not path.is_file() or path.suffix not in ('.rs', '.S'): continue
    relative = 'host-kernel/native-rust/' + str(path.relative_to(stage))
    current = repo / relative
    row = dict(path=relative, size=current.stat().st_size, sha256=digest(current),
               compiler_size=path.stat().st_size, compiler_sha256=digest(path), transform='none')
    if current.read_bytes() != path.read_bytes():
        assert path.suffix == '.rs', relative
        formatted = out / ('formatted-' + path.name)
        formatted.write_bytes(current.read_bytes())
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(formatted)]
        subprocess.run(command, check=True)
        assert formatted.read_bytes() == path.read_bytes(), relative
        row['transform'] = command[:-1]
        add(current, 'native-boot-start-20260907-unformatted-' + path.name + '.gz')
    record['current_compiler_inputs'].append(row)
record['current_compiler_input_count'] = len(record['current_compiler_inputs'])
for relative in ('scripts/native-boot-init.sh', 'scripts/tests/fixtures/native-boot.c',
                 'scripts/tests/fixtures/native_smp_boot_layout.c',
                 'host-kernel/kbuild/patches/0006-x86-export-owned-secondary-start-primitives.patch'):
    path = repo / relative
    record.setdefault('source_inputs', []).append(dict(path=relative, size=path.stat().st_size, sha256=digest(path)))
for name in ('native-boot-code-checkpoint-20260907.json', 'native-boot-backend-images-checkpoint-20260907.json'):
    path = repo / 'docs/verification' / name
    record.setdefault('references', []).append(dict(path=str(path.relative_to(repo)), size=path.stat().st_size, sha256=digest(path)))
for row in record['artifacts']:
    unpacked, size = hashlib.sha256(), 0
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            unpacked.update(data); size += len(data)
    if 'unpacked_sha256' in row:
        assert size == row['unpacked_size'] and unpacked.hexdigest() == row['unpacked_sha256']
(out / 'native-boot-start-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained and verified', len(record['artifacts']), 'native boot artifacts; full boot remains open', flush=True)
