import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path

HERE = Path(__file__).resolve().parent / "fixtures/native-lifecycle-model-v1"
FILES = {"README.md", "model.rs", "reference.c", "vectors.json", "expected.json", "harness.py"}
REQUIRED = {
    "preparation-abort", "assigned-tid-abort", "late-clone-abort", "immediate-exit",
    "tid-reuse", "thread-only-exit", "last-thread-exit", "competing-group-orders",
    "inherited-status", "duplicate-terminal", "retained-thread-ref",
    "retained-process-ref", "authority-revoked",
    "ref-resurrection", "zombie-before-after-reap",
    "main-storage-held", "live-sibling-retirement", "vm-held", "launcher-loss",
    "teardown-failure", "buffer-full", "counter-overflow", "attempt-counter-overflow",
    "unfinished-reservation",
    "missing-birth", "missing-end", "active-tid-alias",
    "birth-after-runnable",
    "wrong-raw-terminal", "wrong-capture", "wrong-os-generation",
    "wrong-application", "wrong-process", "wrong-exec", "wrong-domain",
    "application-limit", "process-limit", "thread-limit",
}
RAW_REQUIRED = {
    "raw-duplicate-key", "raw-nonfinite", "raw-trailing-object",
    "raw-embedded-nul", "raw-129-operations", "raw-oversized-document",
    "raw-unknown-pool", "raw-cyclic-pool", "raw-excess-pool-args",
}

class NativeLifecycleModelSourceTests(unittest.TestCase):
    def test_exact_packet_and_labels(self):
        self.assertEqual({path.name for path in HERE.iterdir() if path.is_file()}, FILES)
        for name in ("README.md", "model.rs", "reference.c", "harness.py"):
            self.assertIn("MODEL_ONLY", (HERE / name).read_text())

    def test_python_syntax_and_named_coverage(self):
        ast.parse((HERE / "harness.py").read_text())
        vectors = json.loads((HERE / "vectors.json").read_text())
        expected = json.loads((HERE / "expected.json").read_text())
        self.assertEqual(vectors["schema_version"], 2)
        self.assertTrue(vectors["model_only"] and expected["model_only"])
        names = {vector["name"] for vector in vectors["vectors"]}
        self.assertTrue(names <= REQUIRED)
        if vectors["corpus_complete"]:
            self.assertEqual(names, REQUIRED)
        else:
            self.assertIn("immediate-exit", names)
        self.assertEqual(names, set(expected["vectors"]))
        raw_names = {record["name"] for record in vectors["raw_invalid"]}
        self.assertEqual(raw_names, RAW_REQUIRED)
        self.assertTrue(raw_names.isdisjoint(names))
        self.assertEqual(vectors["mutants"], {
            "birth-after-runnable": "birth-after-runnable",
            "early-retirement": "retained-thread-ref",
            "silent-loss": "buffer-full",
            "tid-aliasing": "active-tid-alias",
        })

    def test_separate_registries_and_no_production_wiring(self):
        rust = (HERE / "model.rs").read_text()
        cref = (HERE / "reference.c").read_text()
        for token in ("ProcessRow", "ThreadRow", "ExclusiveUnpublished", "full_key"):
            self.assertIn(token, rust)
        for token in ("process_row", "thread_row", "EXCLUSIVE_UNPUBLISHED", "full_key"):
            self.assertIn(token, cref)
        combined = rust + cref
        for forbidden in ("host_schedule_process", "do_fork", "do_exit", "runq_add_thread", "mcctrl"):
            self.assertNotIn(forbidden, combined)

class NativeLifecycleRawDecoderTests(unittest.TestCase):
    @staticmethod
    def harness_module():
        spec = importlib.util.spec_from_file_location("native_lifecycle_harness", HERE / "harness.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def decoder(raw):
        return subprocess.run(
            [sys.executable, str(HERE / "harness.py"), "--decode-raw-document"],
            input=raw, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=5, check=False,
        )

    @staticmethod
    def document(operations, pools=None):
        return {
            "schema_version": 2,
            "model_only": True,
            "corpus_complete": False,
            "pools": pools or {},
            "vectors": [{
                "name": "valid", "coverage": ["valid"],
                "event_capacity": 256, "seed": "NONE",
                "operations": operations,
            }],
            "raw_invalid": [],
            "mutants": {},
        }

    def assert_decode(self, document, code):
        raw = json.dumps(document, separators=(",", ":")).encode()
        result = self.decoder(raw)
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (code, b"", b""))

    def test_positive_decoder_boundaries(self):
        end = [1, "CAPTURE_END", None, None, 0, 0, 0, 0]
        self.assert_decode(self.document({"pool": "O"}, {"O": [end]}), 0)
        self.assert_decode(self.document({"pool": "O", "args": []}, {"O": [end]}), 0)
        self.assert_decode(self.document({"pool": "A", "args": [end]},
                                           {"A": [{"arg": 0}]}), 0)
        operations = [[index, "CAPTURE_END", None, None, 0, 0, 0, 0]
                      for index in range(1, 129)]
        self.assert_decode(self.document(operations), 0)

    def test_nine_raw_rejections_without_build_inputs(self):
        result = subprocess.run(
            [sys.executable, str(HERE / "harness.py"), "--check-raw-invalid"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False,
        )
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (0, b"", b""))

    def test_oversized_artifact_binding(self):
        vectors = json.loads((HERE / "vectors.json").read_text())
        record = next(item for item in vectors["raw_invalid"]
                      if item["name"] == "raw-oversized-document")
        description = record["source"]["artifact"]
        path = HERE.parents[3] / description["path"]
        raw = path.read_bytes()
        self.assertEqual(len(raw), description["size"])
        self.assertEqual(hashlib.sha256(raw).hexdigest(), description["sha256"])
        self.assertEqual(self.decoder(raw).returncode, 2)

    def test_artifact_metadata_path_and_symlink_rejections(self):
        module = self.harness_module()
        vectors = json.loads((HERE / "vectors.json").read_text())
        record = next(item for item in vectors["raw_invalid"]
                      if item["name"] == "raw-oversized-document")
        description = record["source"]["artifact"]
        with mock.patch.object(module.os, "open", wraps=os.open) as opener:
            retained = module.artifact_bytes(description)
        final_opens = [call for call in opener.call_args_list
                       if call.args and call.args[0] == "oversized-document.json"]
        self.assertEqual(len(final_opens), 1)
        self.assertEqual(hashlib.sha256(retained).hexdigest(), description["sha256"])
        for mutation in (
            {**description, "size": description["size"] - 1},
            {**description, "sha256": "0" * 64},
            {**description, "path": "scripts/tests/fixtures/native-lifecycle-model-v1/../outside"},
        ):
            with self.assertRaises((AssertionError, OSError)):
                module.artifact_bytes(mutation)
        raw_dir = HERE / "raw-invalid"
        with tempfile.TemporaryDirectory(dir=raw_dir) as temporary:
            link = Path(temporary) / "link"
            link.symlink_to(raw_dir / "oversized-document.json")
            relative = link.relative_to(HERE.parents[3]).as_posix()
            with self.assertRaises(OSError):
                module.artifact_bytes({**description, "path": relative})

    def test_child_timeout_and_output_are_not_rejections(self):
        module = self.harness_module()
        real_popen = subprocess.Popen
        children = []
        def capture(*args, **kwargs):
            child = real_popen(*args, **kwargs)
            children.append(child)
            return child
        with mock.patch.object(module.subprocess, "Popen", side_effect=capture):
            with self.assertRaises(AssertionError):
                module.bounded_child(
                    [sys.executable, "-c", "import time; time.sleep(10)"], b"")
            self.assertIsNotNone(children[-1].poll())
            with self.assertRaises(AssertionError):
                module.bounded_child(
                    [sys.executable, "-c", "import os; os.write(1, b'x' * 65537)"], b"")
            self.assertIsNotNone(children[-1].poll())

    def test_recursive_raw_and_build_tripwires(self):
        nested = self.document([[1, "CAPTURE_END", None, None, 0, 0, 0, 0]])
        nested["raw_invalid"] = [{
            "name": "nested", "coverage": ["nested"],
            "source": {"inline_utf8": "{}"},
            "expected": {"stage": "harness", "exit_code": 2,
                         "stdout_hex": "", "stderr_hex": "",
                         "model_invocations": 0},
        }]
        self.assert_decode(nested, 2)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "must-not-exist"
            module = self.harness_module()
            with mock.patch.object(module, "build", side_effect=RuntimeError("build called")) as build_call, \
                 mock.patch.object(module, "compiler", side_effect=RuntimeError("compiler called")) as compiler_call, \
                 mock.patch.object(module, "run", side_effect=RuntimeError("model called")) as model_call, \
                 mock.patch.object(module, "raw_child", wraps=module.raw_child) as raw_call, \
                 mock.patch.object(sys, "argv", [str(HERE / "harness.py"),
                                                  "--rustc", "/must/not/resolve/rustc",
                                                  "--cc", "/must/not/resolve/cc",
                                                  "--output", str(output)]):
                with self.assertRaises(AssertionError):
                    module.main()
                self.assertEqual(raw_call.call_count, len(RAW_REQUIRED))
                build_call.assert_not_called()
                compiler_call.assert_not_called()
                model_call.assert_not_called()
            self.assertFalse(output.exists())

if __name__ == "__main__":
    unittest.main()
