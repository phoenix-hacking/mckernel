/work/stability-linux-collector-build-20260915-2/sha256.o: \
 /work/stability-linux-collector-build-20260915-2/source/linux-sealed-v1/sha256.c \
 /usr/include/stdc-predef.h \
 /work/stability-linux-collector-build-20260915-2/source/linux-sealed-v1/sha256.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stdbool.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stddef.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-intn.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h /usr/include/string.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/strings.h
