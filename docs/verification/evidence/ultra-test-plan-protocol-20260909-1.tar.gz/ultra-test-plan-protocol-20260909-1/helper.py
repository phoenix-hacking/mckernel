from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,importlib.util,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/ultra-test-plan-protocol-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',commands=[],started_utc=datetime.now(timezone.utc).isoformat(),application_tests_passed=0,runtime_authorized=False)
def ident(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,args):
 print('RUN',label,flush=True)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 record['commands'].append(dict(label=label,command=args,exit_code=r.returncode));assert r.returncode==0,(label,(out/(label+'.log')).read_text())
try:
 shutil.copyfile(__file__,out/'helper.py');src=out/'application-tests';shutil.copytree(repo/'scripts/application-tests',src)
 record['inputs']=[ident(p) for p in sorted(src.rglob('*')) if p.is_file()]
 run('catalog',['python3','-B',str(src/'validate.py')])
 run('context',['python3','-B',str(src/'validate.py'),'--packet',str(src/'packets/packet-001.json'),'--emit-context',str(out/'packet-001-context.json')])
 spec=importlib.util.spec_from_file_location('validator',src/'validate.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 catalog=json.loads((src/'cases.json').read_text());packet=json.loads((src/'packets/packet-001.json').read_text());cases=module.validate_catalog(catalog)
 tests=[]
 def reject(name,fn):
  try:fn()
  except ValueError as e:tests.append(dict(name=name,status='PASS',error=str(e)));return
  raise AssertionError(name+' incorrectly accepted')
 c=copy.deepcopy(catalog);c['cases'][0]['depends_on']=[c['cases'][0]['id']];reject('dependency-cycle',lambda:module.validate_catalog(c))
 c=copy.deepcopy(catalog);c['cases'][0]['requires'].append('invented-feature');reject('unknown-capability',lambda:module.validate_catalog(c))
 c=copy.deepcopy(catalog);c['cases'][0]['acceptance_status']='PASS';reject('false-case-pass',lambda:module.validate_catalog(c))
 c=copy.deepcopy(catalog);c['cases'][0]['limits']['container_memory_bytes']=64*1024**3;reject('resource-expansion',lambda:module.validate_catalog(c))
 p=copy.deepcopy(packet);p['write_allowlist'][0]='../../kernel/rust/lib.rs';reject('write-path-escape',lambda:module.validate_packet(p,catalog,cases))
 p=copy.deepcopy(packet);p['execution_enabled']=True;reject('unreviewed-execution',lambda:module.validate_packet(p,catalog,cases))
 p=copy.deepcopy(packet);p['permitted_commands']=[['bash','-c','true']];reject('shell-command',lambda:module.validate_packet(p,catalog,cases))
 context=json.loads((out/'packet-001-context.json').read_text());assert len(context['cases'])==3 and {c['id'] for c in context['cases']}==set(packet['case_ids']);assert context['execution_enabled'] is False
 record.update(status='PASS',negative_checks=tests,logical_cases=len(cases),packet_context_cases=len(context['cases']))
except BaseException as e:record.update(status='FAIL',error=str(e));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[ident(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
