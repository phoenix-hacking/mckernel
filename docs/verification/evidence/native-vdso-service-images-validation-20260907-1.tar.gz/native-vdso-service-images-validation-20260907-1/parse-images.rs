#![allow(dead_code)]
#[path = "/work/mckernel-native-irq-images-20260907-13/source/host-kernel/native-rust/ihk_mapping.rs"] mod ihk_mapping;
#[path = "/work/mckernel-native-irq-images-20260907-13/source/host-kernel/native-rust/smp_resource.rs"] mod smp_resource;
#[path = "/work/mckernel-native-irq-images-20260907-13/source/host-kernel/native-rust/smp_image.rs"] mod smp_image;
fn main() {
    use smp_resource::*;
    use smp_image::*;
    let owner = OsToken::test_only(0, 1).unwrap();
    let mut map = MemoryMap::<16>::new();
    let mut slots = [None; 16];
    let mut workspace = MemoryWorkspace::new(&mut slots).unwrap();
    map.insert_free(0x4000_0000, 64 << 20, 0, &mut workspace).unwrap();
    let extent = MemoryExtent::new(0x4000_0000, 64 << 20, 0, None).unwrap();
    let mut assignment = map.prepare_assign_batch(owner, &[extent], &mut workspace).unwrap();
    assignment.begin_external_effects().unwrap(); assignment.commit().unwrap();
    let layout = BootLayout::select(&map, owner).unwrap();
    for (index, path) in std::env::args().skip(1).enumerate() {
        let image = std::fs::read(&path).unwrap();
        let plan = ImagePlan::parse(&image, layout).unwrap();
        assert_eq!(plan.native_boot_abi(), if index >= 2 {
            Some(NativeBootAbi { header_bytes: 7616, performance: true, completed_queue_reads: index != 3, generic_vdso: index == 2 })
        } else { None });
        let mut memory = vec![0u8; KERNEL_WINDOW_BYTES as usize];
        for segment in plan.segments() {
            let offset = (segment.destination - layout.kernel().start()) as usize;
            memory[offset..offset + segment.file.len()].copy_from_slice(segment.file);
        }
        let checksum = memory.iter().fold(0xcbf29ce484222325u64,
            |old, byte| (old ^ *byte as u64).wrapping_mul(0x100000001b3));
        println!("IMAGE index={index} segments={} entry={:x} loaded_checksum={checksum:016x} native_abi={:?}",
                 plan.load_segments(), plan.entry(), plan.native_boot_abi());
    }
}
