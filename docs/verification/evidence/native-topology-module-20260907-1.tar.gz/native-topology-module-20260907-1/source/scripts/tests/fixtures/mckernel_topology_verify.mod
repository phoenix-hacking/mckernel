/work/native-topology-module-20260907-1/source/scripts/tests/fixtures/mckernel_topology_verify.o
