from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace'); build = Path('/work/native-build-base-24a151fe')
kernel = Path('/work/native-topology-kernel-20260907-1')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
out = Path('/work/native-topology-module-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], compiler_inputs=[], commands=[], production_gate_credit=False,
    sysfs_service_completed=False, declared_stage=False,
    scope='Owned Linux topology producer and 45-value independent layout; native CPU-context integration and runtime validation remain pending')

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-9000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    assert (build / 'Module.symvers').read_bytes() == (kernel / 'Module.symvers').read_bytes()
    shutil.copyfile(__file__, out / 'helper.py')
    for name in ['.config', 'Module.symvers', 'rust/bindings/bindings_generated.rs']:
        saved = out / Path(name).name; shutil.copyfile(build / name, saved)
        record['inputs'].append(identity(saved))
    inputs = ['host-kernel/native-rust/smp_topology.rs',
              'host-kernel/native-rust/sysfs_objects.rs',
              'scripts/tests/fixtures/mckernel_topology_verify.rs',
              'scripts/tests/fixtures/native_topology_layout.c']
    for name in inputs:
        for area in ['original-inputs', 'source']:
            saved = out / area / name; saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(repo / name, saved)
        record['inputs'].append(identity(out / 'original-inputs' / name))
    rust = [str(out / 'source' / name) for name in inputs if name.endswith('.rs')]
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + rust)
    record['compiler_inputs'] = [identity(out / 'source' / name) for name in inputs]
    module = out / 'source/scripts/tests/fixtures'
    (module / 'Kbuild').write_text('obj-m += mckernel_topology_verify.o\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('layout-witness', base + ['M=' + str(module), 'native_topology_layout.o'])
    run('c-layout-extract', ['objcopy', '--dump-section', '.mckernel_native_topology_layout=' + str(out / 'c-layout.bin'),
        str(module / 'native_topology_layout.o'), str(out / 'c-layout-copy.o')])
    run('module-build', base + ['M=' + str(module), 'modules'])
    compiled = out / 'mckernel_topology_verify.ko'; shutil.copyfile(module / compiled.name, compiled)
    run('rust-layout-extract', ['objcopy', '--dump-section', '.mckernel_native_topology_layout=' + str(out / 'rust-layout.bin'),
        str(compiled), str(out / 'rust-layout-copy.ko')])
    assert (out / 'rust-layout.bin').read_bytes() == (out / 'c-layout.bin').read_bytes()
    record['layout'] = list(struct.unpack('<45Q', (out / 'c-layout.bin').read_bytes()))
    assert record['layout'] == json.loads((kernel / 'record.json').read_text())['c_layout']
    for tool, name in [(['nm', '-u'], 'undefined.txt'), (['objdump', '-d'], 'disassembly.txt'),
                       (['readelf', '-h'], 'elf-header.txt')]:
        (out / name).write_bytes(subprocess.check_output(tool + [str(compiled)]))
    symbols = (out / 'undefined.txt').read_text()
    for name in ['get_cpu_cacheinfo', 'cpu_info', 'cpu_core_map', 'cpu_sibling_map', '__per_cpu_offset',
                 'cpus_read_lock', 'cpus_read_unlock', 'kobject_init_and_add', 'kobject_put',
                 'kobject_del', 'kobj_sysfs_ops', 'sysfs_create_file_ns', 'sysfs_remove_file_ns']:
        assert ' U ' + name + '\n' in symbols, name
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', (out / 'disassembly.txt').read_text())
    assert 'ELF64' in (out / 'elf-header.txt').read_text()
    for row in record['inputs'] + record['compiler_inputs']: assert identity(Path(row['path'])) == row, row
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
        if path.is_file() and path.name not in ('record.json', 'phase')]
    save(); print(record['status'], out, flush=True)
