from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-published-phase-tests-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(), inputs=[],
              application_acceptance=False, transport_acceptance=False, guest_execution=False)
def identity(p):
    data = p.read_bytes()
    return dict(path=str(p), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    hashes = {'scripts/application-tests/published_phase_observations.py':'2023ff165284ac94b48df19dd98cafbd706857cf3a2e3f8c1c17767eb2631bce','scripts/tests/test_published_phase_observations.py':'3a495919bab057ceaa0570e50046b0d23bdf361c7a513821d7b4be99aca9e836','scripts/application-tests/phase_observations.py':'589694ee603b096743682225ff964b39612439a3082ae7f6a80707c4755f7102','scripts/tests/test_phase_observations.py':'b56b12168b8ad10c1f71172c4aede7c1e38058865b828636c93d39e584e6f352','scripts/application-tests/owner_observations.py':'97466f94dff53fc250509859d164a9858a4f361405ad62b82bb59ab621f77bcf','scripts/tests/test_owner_observations.py':'fa30ea4f670b239c619f08b708ec099943b9832318a4ffc44bcc8150dc61c096','scripts/application-tests/supervisor.py':'8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'}
    for name, digest in hashes.items():
        src = repo / name
        assert identity(src)['sha256'] == digest
        dst = out / name; dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    shutil.copyfile(out / 'scripts/application-tests/supervisor.py', out / 'supervisor.py')
    spec = importlib.util.spec_from_file_location('supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    argv = ['/usr/bin/python3', '-B', str(out / 'scripts/tests/test_published_phase_observations.py'), '-f']
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    record.update(command=argv, environment=env); save()
    result = supervisor.run_supervised(argv, cwd=str(out), env=env, attempt_dir=str(out / 'collection'),
        timeout_seconds=120, cleanup_timeout_seconds=15, stdout_limit_bytes=8*1024**2, stderr_limit_bytes=8*1024**2)
    record['collection'] = result; save()
    assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete']
    stderr = (out / 'collection/stderr.bin').read_text()
    assert 'Ran 13 tests' in stderr and stderr.rstrip().endswith('OK')
    for row in record['inputs']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    record.update(status='PASS_SYNTHETIC_PUBLISHED_HOLD_PARSER_ONLY', cases=13)
except BaseException as exc:
    record.update(status='FAIL', error_type=type(exc).__name__, error=str(exc)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save()
    print(record['status'], out, flush=True)
