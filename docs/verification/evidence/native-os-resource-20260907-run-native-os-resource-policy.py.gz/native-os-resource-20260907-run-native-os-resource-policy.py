import os,sys,json,hashlib,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
repo=Path('/workspace');out=Path('/work/native-os-resource-policy-20260907');out.mkdir(exist_ok=True)
paths=['host-kernel/native-rust/smp_resource.rs','scripts/tests/fixtures/ihk_smp_resource_compile.rs','scripts/tests/fixtures/ihk_smp_resource_workspace_alias_compile_fail.rs','scripts/tests/test_ihk_smp_resource.py']
for rel in paths:
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/rel,target)
resource=out/paths[0];source=resource.read_text()
for begin_marker,end_marker,wrapper in [
 ('    /// Prepare one OS assignment from sorted physical ranges','    pub(crate) fn prepare_release_all', 'impl<const N: usize> MemoryMap<N>'),
 ('    #[test]\n    fn memory_os_batch_transfers_keep_nodes','    #[test]\n    fn memory_queries_preflight_output_without_partial_copy','mod tests')]:
 begin=source.index(begin_marker);end=source.index(end_marker,begin)
 fragment=out/'format-fragment.rs';fragment.write_text(wrapper+' {\n'+source[begin:end]+'}\n')
 subprocess.run(['rustfmt','--edition','2021',str(fragment)],check=True)
 formatted=fragment.read_text().split('\n',1)[1].rsplit('}',1)[0]
 source=source[:begin]+formatted+'\n'+source[end:]
resource.write_text(source)
record={'started_utc':datetime.now(timezone.utc).isoformat(),'paths':[],'repository_source_before_format_sha256':hashlib.sha256((repo/paths[0]).read_bytes()).hexdigest()}
for rel in paths:
 b=(out/rel).read_bytes();record['paths'].append({'path':rel,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',MCKERNEL_RUSTC_1_92='/usr/bin/rustc')
command=['python3','-m','unittest','discover','-s','scripts/tests','-p','test_ihk_smp_resource.py','-f']
with (out/'tests.log').open('wb') as log:
 result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(command=command,exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat())
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print('OS_RESOURCE_POLICY_EXIT',result.returncode,flush=True)
print((out/'tests.log').read_text()[-6000:],flush=True)
sys.exit(result.returncode)
