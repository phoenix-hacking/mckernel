#include <stdio.h>
#include <assert.h>
#include <errno.h>
struct ikc_scd_packet { int unused; };
static int status, retry, freed;
static int _process_procfs_request(struct ikc_scd_packet *p, int *result) { (void)p; *result=retry; return status; }
static void kfree_tracked(void *p, const char *file, int line) { (void)p; (void)file; (void)line; ++freed; }
static int do_procfs_backlog(void *arg)
{
	struct ikc_scd_packet *rpacket = arg;
	int result = 0;

	_process_procfs_request(rpacket, &result);
	if (!result) {
		kfree_tracked(arg, __FILE__, __LINE__);
	}
	return result;
}
int procfs_lock_retry_result(void)
{
	return -EAGAIN;
}
int main(void) { struct ikc_scd_packet p; const int retries[]={0,1,procfs_lock_retry_result()}; assert(retries[2]==-11); for (unsigned i=0;i<sizeof(retries)/sizeof(retries[0]);++i) { retry=retries[i]; for (status=-12;status<=0;status+=6) { freed=0; int result=do_procfs_backlog(&p); assert(result==retry && freed==!retry); printf("BACKLOG status=%d retry=%d returned=%d freed=%d\n",status,retry,result,freed); } } return 0; }
