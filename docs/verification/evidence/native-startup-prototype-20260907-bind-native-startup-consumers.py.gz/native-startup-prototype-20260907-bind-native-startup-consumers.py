from pathlib import Path
import ast,hashlib,json,pprint,re
root=Path('/home/holden/mckernel')
def identity(path):
 data=(root/path).read_bytes();return dict(path=path,sha256=hashlib.sha256(data).hexdigest(),size=len(data))
def set_assignment(path,name,value):
 target=root/path;text=target.read_text();node=next(n.value for n in ast.parse(text).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
 lines=text.splitlines(keepends=True);a=sum(map(len,lines[:node.lineno-1]))+node.col_offset;b=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
 target.write_text(text[:a]+pprint.pformat(value,width=100,sort_dicts=False)+text[b:])
contract_path='host-kernel/contracts/native-rust-runtime-evidence-v1.json';contract=json.loads((root/contract_path).read_text())
raw=(root/'scripts/native_rust_kbuild_link_closure.py').read_bytes()
contract['repository_semantic_authority_identities']['kbuild_link_closure']={
 'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
 'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)}
(root/contract_path).write_text(json.dumps(contract,indent=2,sort_keys=True)+'\n')
checker_path='scripts/native_rust_runtime_evidence.py'
set_assignment(checker_path,'EXPECTED_REPOSITORY_SEMANTIC_AUTHORITY_IDENTITIES',contract['repository_semantic_authority_identities'])
path=root/checker_path;raw=path.read_bytes()
normalized,count=re.subn(br'ISOLATED_SELF_DIGEST:[0-9a-f]{64}',b'ISOLATED_SELF_DIGEST:'+b'0'*64,raw)
assert count==1
path.write_bytes(re.sub(br'ISOLATED_SELF_DIGEST:[0-9a-f]{64}',b'ISOLATED_SELF_DIGEST:'+hashlib.sha256(normalized).hexdigest().encode(),raw))
# Bind the current integration producer only; its old runtime witnesses remain frozen.
contract_path='host-kernel/contracts/fp0006-runtime-capture-integration-v1.json';contract=json.loads((root/contract_path).read_text())
contract['bound_files']['native_runtime_validator']=identity(checker_path)
(root/contract_path).write_text(json.dumps(contract,indent=2,sort_keys=True)+'\n')
row=identity(contract_path)
set_assignment('scripts/fp0006_runtime_capture_integration.py','EXPECTED_CONTRACT_SHA256',row['sha256'])
set_assignment('scripts/fp0006_runtime_capture_integration.py','EXPECTED_CONTRACT_SIZE',row['size'])
consumer_path='host-kernel/contracts/fp0006-executable-acceptance-closure-v1.json';consumer=json.loads((root/consumer_path).read_text())
updated=[]
def refresh(value):
 if isinstance(value,dict):
  if value.get('path')==contract_path and 'sha256' in value:
   value.update(row);updated.append(contract_path)
  for child in value.values(): refresh(child)
 elif isinstance(value,list):
  for child in value: refresh(child)
refresh(consumer);assert updated==[contract_path]
(root/consumer_path).write_text(json.dumps(consumer,indent=2,sort_keys=True)+'\n')
row=identity(consumer_path)
set_assignment('scripts/fp0006_executable_acceptance_closure.py','EXPECTED_CONTRACT_SHA256',row['sha256'])
set_assignment('scripts/fp0006_executable_acceptance_closure.py','EXPECTED_CONTRACT_SIZE',row['size'])
print('Bound current startup graph in runtime and FP integration consumers; historical witnesses unchanged')
