#![feature(raw_ref_op, let_else)]
#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData, PhantomPinned}; use core::pin::Pin;
use core::ptr::null_mut; use core::mem::{size_of, MaybeUninit}; use std::cell::RefCell;
macro_rules! offset_of { ($ty:ty, $field:ident) => {{ let p=MaybeUninit::<$ty>::uninit(); core::ptr::addr_of!((*p.as_ptr()).$field) as usize-p.as_ptr() as usize }} }
type CInt=i32; type CULong=u64; type OffT=i64;
const EINVAL:CInt=22; const PM_NONE:u8=0; const PM_PENDING_FREE:u8=1; const IHK_MC_PG_USER:CInt=1;
#[repr(C)] #[derive(Clone,Copy)] struct AbiListHead { next:*mut AbiListHead, prev:*mut AbiListHead }
#[repr(C)] #[derive(Clone,Copy)] struct IhkAtomic { counter:CInt }
#[repr(C)] #[derive(Clone,Copy)] struct IhkAtomic64 { counter64:i64 }
#[repr(C)] struct MemPage { list:AbiListHead, hash:AbiListHead, mode:u8, phys:CULong, count:IhkAtomic, mapped:IhkAtomic64, offset:OffT, pgshift:CInt }
type MemPendingFreeFn=unsafe extern "C" fn(CULong,CInt,CInt);
unsafe fn page_from_list(n:*mut AbiListHead)->*mut MemPage { n.cast() }
unsafe fn init_list_head(h:*mut AbiListHead) { (*h).next=h; (*h).prev=h; }
unsafe fn append(h:*mut AbiListHead,e:*mut AbiListHead) { (*e).prev=(*h).prev; (*e).next=h; (*(*h).prev).next=e; (*h).prev=e; }
const LIST_POISON1:usize=0x0010_0129; const LIST_POISON2:usize=0x0020_0229;
unsafe fn list_del_poison(e:*mut AbiListHead) { let n=(*e).next; let p=(*e).prev; (*n).prev=p; (*p).next=n; (*e).next=LIST_POISON1 as *mut _; (*e).prev=LIST_POISON2 as *mut _; }
#[derive(Clone, Copy, PartialEq, Eq)]
enum PendingFreeBatchState {
    Vacant,
    Retained,
    Drained,
}

/// Pinned transaction destination for pending-page ownership transfer.
/// It is deliberately !Unpin, !Send and !Sync and never frees implicitly.
struct PendingFreeBatch {
    head: AbiListHead,
    state: PendingFreeBatchState,
    source: *mut AbiListHead,
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

impl PendingFreeBatch {
    const fn new() -> Self {
        Self {
            head: AbiListHead { next: null_mut(), prev: null_mut() },
            state: PendingFreeBatchState::Vacant,
            source: null_mut(),
            _pin: PhantomPinned,
            _owner: PhantomData,
        }
    }
}

unsafe fn validate_pending_head(head: *mut AbiListHead) -> Result<bool, CInt> {
    if head.is_null() || (*head).next.is_null() || (*head).prev.is_null() {
        return Err(-EINVAL);
    }
    if (*head).next == head || (*head).prev == head {
        if (*head).next != head || (*head).prev != head {
            return Err(-EINVAL);
        }
        return Ok(false);
    }
    if (*(*head).next).prev != head || (*(*head).prev).next != head {
        return Err(-EINVAL);
    }

    // Validate the complete ring before changing either list.  Floyd's
    // traversal detects a foreign cycle without imposing a node-count cap.
    let mut slow = (*head).next;
    let mut fast = (*head).next;
    loop {
        if slow == head {
            break;
        }
        if slow.is_null()
            || (*slow).next.is_null()
            || (*slow).prev.is_null()
            || (*(*slow).next).prev != slow
            || (*(*slow).prev).next != slow
        {
            return Err(-EINVAL);
        }
        let page = page_from_list(slow);
        if page.is_null() || (*page).mode != PM_PENDING_FREE {
            return Err(-EINVAL);
        }
        slow = (*slow).next;

        if fast == head {
            continue;
        }
        if fast.is_null() || (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == head {
            continue;
        }
        if (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == slow && slow != head {
            return Err(-EINVAL);
        }
    }
    Ok(true)
}

unsafe fn detach_pending_free_batch(
    source: *mut AbiListHead,
    mut destination: Pin<&mut PendingFreeBatch>,
) -> CInt {
    // Safety obligations: the caller owns an exclusive, CPU-local source
    // ring and keeps every live descriptor stable; no producer may enqueue or
    // callback may re-enter while this transaction is detached. `destination`
    // must remain at this pinned address until drain (or explicit recovery).
    let dest = destination.as_mut().get_unchecked_mut();
    let dest_head = &raw mut dest.head;
    if source.is_null()
        || source == dest_head
        || dest.state != PendingFreeBatchState::Vacant
        || !(dest.head.next.is_null() && dest.head.prev.is_null())
    {
        return -EINVAL;
    }
    let nonempty = match validate_pending_head(source) {
        Ok(nonempty) => nonempty,
        Err(_) => return -EINVAL,
    };
    if nonempty {
        let first = (*source).next;
        let last = (*source).prev;
        init_list_head(dest_head);
        (*dest_head).next = first;
        (*dest_head).prev = last;
        (*first).prev = dest_head;
        (*last).next = dest_head;
        (*source).next = null_mut();
        (*source).prev = null_mut();
    } else {
        init_list_head(dest_head);
        (*source).next = null_mut();
        (*source).prev = null_mut();
    }
    dest.source = source;
    dest.state = PendingFreeBatchState::Retained;
    0
}

unsafe fn drain_pending_free_batch(
    source: *mut AbiListHead,
    mut batch: Pin<&mut PendingFreeBatch>,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    // Safety obligations: `source` must be the exact source captured by
    // detach, the pinned transaction must outlive this call, and `free_fn`
    // must not mutate either list or re-enter detach/drain. The caller owns
    // the exclusive CPU/descriptor lease for the whole operation.
    let Some(free_fn) = free_fn else { return -EINVAL; };
    let b = batch.as_mut().get_unchecked_mut();
    if b.state != PendingFreeBatchState::Retained
        || b.source != source
        || validate_pending_head(&raw mut b.head).is_err()
    {
        return -EINVAL;
    }
    let mut node = b.head.next;
    let mut count = 0;
    while node != &raw mut b.head {
        let next = (*node).next;
        let page = page_from_list(node);
        (*page).mode = PM_NONE;
        list_del_poison(node);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        node = next;
    }
    b.head.next = null_mut();
    b.head.prev = null_mut();
    b.source = null_mut();
    b.state = PendingFreeBatchState::Drained;
    count
}

#[derive(Clone,Copy)] struct Rec(CULong,CInt,CInt);
thread_local! { static LEDGER: RefCell<Vec<Rec>>=RefCell::new(Vec::new()); }
static mut CALLBACKS:usize=0;
unsafe extern "C" fn free_page(p:CULong,n:CInt,k:CInt) { LEDGER.with(|c| { let v=&mut *c.as_ptr(); let len=v.len(); v.as_mut_ptr().add(len).write(Rec(p,n,k)); v.set_len(len+1); }); CALLBACKS+=1; }
unsafe fn setup() { LEDGER.with(|c| { let v=&mut *c.as_ptr(); v.try_reserve_exact(16).unwrap(); v.clear(); }); CALLBACKS=0; }
unsafe fn make(p:CULong,n:CInt)->MemPage { MemPage{list:AbiListHead{next:null_mut(),prev:null_mut()},hash:AbiListHead{next:null_mut(),prev:null_mut()},mode:PM_PENDING_FREE,phys:p,count:IhkAtomic{counter:0},mapped:IhkAtomic64{counter64:0},offset:n as OffT,pgshift:12} }
fn row(n:&str,s:CInt,c:CInt,k:usize,shape:usize) { println!("ROW|{}|{}|{}|{}|{}",n,s,c,k,shape); }
unsafe fn one() { setup(); let mut s=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut s); let mut b=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut b); let r=detach_pending_free_batch(&mut s,pin.as_mut()); let d=drain_pending_free_batch(&mut s,pin,Some(free_page)); row("empty",r,d,CALLBACKS,1); }
fn main(){unsafe{
 assert_eq!(size_of::<AbiListHead>(),16); assert_eq!(offset_of!(AbiListHead,next),0); assert_eq!(offset_of!(AbiListHead,prev),8); assert_eq!(size_of::<MemPage>(),80);
 one(); setup(); let mut s=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut s); let mut p=make(11,1); append(&mut s,&mut p.list); let mut b=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut b); let r=detach_pending_free_batch(&mut s,pin.as_mut()); let d=drain_pending_free_batch(&mut s,pin,Some(free_page)); row("one",r,d,CALLBACKS,usize::from(p.mode==PM_NONE));
 setup(); init_list_head(&mut s); let mut a=make(12,2); let mut c=make(13,3); let mut e=make(14,4); append(&mut s,&mut a.list);append(&mut s,&mut c.list);append(&mut s,&mut e.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let r=detach_pending_free_batch(&mut s,pin.as_mut());let d=drain_pending_free_batch(&mut s,pin,Some(free_page));let q=LEDGER.with(|x|{let v=x.borrow();usize::from(v.len()==3&&v[0].0==12&&v[1].0==13&&v[2].0==14)});row("three-order",r,d,CALLBACKS,q);
 setup();init_list_head(&mut s);let mut a=make(20,2);let mut c=make(21,3);append(&mut s,&mut a.list);append(&mut s,&mut c.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);assert_eq!(detach_pending_free_batch(&mut s,pin.as_mut()),0);c.mode=PM_NONE;let z=drain_pending_free_batch(&mut s,pin.as_mut(),Some(free_page));row("later-invalid",z,0,CALLBACKS,usize::from(a.mode==PM_PENDING_FREE));c.mode=PM_PENDING_FREE;let z=drain_pending_free_batch(&mut s,pin,Some(free_page));row("later-invalid-repair",z,z,CALLBACKS,usize::from(a.mode==PM_NONE&&c.mode==PM_NONE));
 setup();let mut b=PendingFreeBatch::new();let z=drain_pending_free_batch(&mut s,Pin::new_unchecked(&mut b),None);row("missing-callback",z,0,CALLBACKS,1);
 setup();init_list_head(&mut s);let mut p=make(30,1);append(&mut s,&mut p.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let _=detach_pending_free_batch(&mut s,pin.as_mut());let mut o=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut o);let z=drain_pending_free_batch(&mut o,pin,Some(free_page));row("wrong-source",z,0,CALLBACKS,usize::from(p.mode==PM_PENDING_FREE));
 setup();init_list_head(&mut s);let mut p=make(31,1);append(&mut s,&mut p.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let r=detach_pending_free_batch(&mut s,pin.as_mut());let x=detach_pending_free_batch(&mut s,pin.as_mut());let d=drain_pending_free_batch(&mut s,pin.as_mut(),Some(free_page));let _y=drain_pending_free_batch(&mut s,pin,Some(free_page));row("repeated-detach-drain",x,r+d,CALLBACKS,usize::from(p.mode==PM_NONE));
 setup();let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(null_mut(),Pin::new_unchecked(&mut b));row("null-source",z,0,CALLBACKS,1);
 setup();let mut i=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut i);let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(&mut i,Pin::new_unchecked(&mut b));row("inactive-empty",z,0,CALLBACKS,1);
 setup();let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(&mut b.head,Pin::new_unchecked(&mut b));row("alias-destination",z,0,CALLBACKS,1);
 setup();let mut n=PendingFreeBatch::new();let mut ns=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut ns);let _=detach_pending_free_batch(&mut ns,Pin::new_unchecked(&mut n));let z=detach_pending_free_batch(&mut ns,Pin::new_unchecked(&mut n));row("nested-begin",z,0,CALLBACKS,1);
 println!("PASS_PENDING_FREE_BATCH_RUST_ROWS");}}
