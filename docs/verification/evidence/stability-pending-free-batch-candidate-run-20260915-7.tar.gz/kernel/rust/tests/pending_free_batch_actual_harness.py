#!/usr/bin/env python3
"""Source-bound focused PendingFreeBatch equivalence harness."""
from pathlib import Path
import argparse, hashlib, json, subprocess, tempfile

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "kernel/rust/mem_helpers.rs"
source = SOURCE.read_text()
anchor_start = "#[derive(Clone, Copy, PartialEq, Eq)]\nenum PendingFreeBatchState"
anchor_end = "\n#[no_mangle]\npub extern \"C\" fn round_up"
start = source.index(anchor_start)
end = source.index(anchor_end, start)
definitions = source[start:end]
definitions_sha256 = hashlib.sha256(definitions.encode()).hexdigest()

PREFIX = r'''#![feature(raw_ref_op, let_else)]
#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData, PhantomPinned}; use core::pin::Pin;
use core::ptr::null_mut; use core::mem::{size_of, MaybeUninit}; use std::cell::RefCell;
macro_rules! offset_of { ($ty:ty, $field:ident) => {{ let p=MaybeUninit::<$ty>::uninit(); core::ptr::addr_of!((*p.as_ptr()).$field) as usize-p.as_ptr() as usize }} }
type CInt=i32; type CULong=u64; type OffT=i64;
const EINVAL:CInt=22; const PM_NONE:u8=0; const PM_PENDING_FREE:u8=1; const IHK_MC_PG_USER:CInt=1;
#[repr(C)] #[derive(Clone,Copy)] struct AbiListHead { next:*mut AbiListHead, prev:*mut AbiListHead }
#[repr(C)] #[derive(Clone,Copy)] struct IhkAtomic { counter:CInt }
#[repr(C)] #[derive(Clone,Copy)] struct IhkAtomic64 { counter64:i64 }
#[repr(C)] struct MemPage { list:AbiListHead, hash:AbiListHead, mode:u8, phys:CULong, count:IhkAtomic, mapped:IhkAtomic64, offset:OffT, pgshift:CInt }
type MemPendingFreeFn=unsafe extern "C" fn(CULong,CInt,CInt);
unsafe fn page_from_list(n:*mut AbiListHead)->*mut MemPage { n.cast() }
unsafe fn init_list_head(h:*mut AbiListHead) { (*h).next=h; (*h).prev=h; }
unsafe fn append(h:*mut AbiListHead,e:*mut AbiListHead) { (*e).prev=(*h).prev; (*e).next=h; (*(*h).prev).next=e; (*h).prev=e; }
const LIST_POISON1:usize=0x0010_0129; const LIST_POISON2:usize=0x0020_0229;
unsafe fn list_del_poison(e:*mut AbiListHead) { let n=(*e).next; let p=(*e).prev; (*n).prev=p; (*p).next=n; (*e).next=LIST_POISON1 as *mut _; (*e).prev=LIST_POISON2 as *mut _; }
'''

TESTS = r'''
#[derive(Clone,Copy)] struct Rec(CULong,CInt,CInt);
thread_local! { static LEDGER: RefCell<Vec<Rec>>=RefCell::new(Vec::new()); }
static mut CALLBACKS:usize=0;
unsafe extern "C" fn free_page(p:CULong,n:CInt,k:CInt) { LEDGER.with(|c| { let v=&mut *c.as_ptr(); let len=v.len(); v.as_mut_ptr().add(len).write(Rec(p,n,k)); v.set_len(len+1); }); CALLBACKS+=1; }
unsafe fn setup() { LEDGER.with(|c| { let v=&mut *c.as_ptr(); v.try_reserve_exact(16).unwrap(); v.clear(); }); CALLBACKS=0; }
unsafe fn make(p:CULong,n:CInt)->MemPage { MemPage{list:AbiListHead{next:null_mut(),prev:null_mut()},hash:AbiListHead{next:null_mut(),prev:null_mut()},mode:PM_PENDING_FREE,phys:p,count:IhkAtomic{counter:0},mapped:IhkAtomic64{counter64:0},offset:n as OffT,pgshift:12} }
fn row(n:&str,s:CInt,c:CInt,k:usize,shape:usize) { println!("ROW|{}|{}|{}|{}|{}",n,s,c,k,shape); }
unsafe fn one() { setup(); let mut s=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut s); let mut b=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut b); let r=detach_pending_free_batch(&mut s,pin.as_mut()); let d=drain_pending_free_batch(&mut s,pin,Some(free_page)); row("empty",r,d,CALLBACKS,1); }
fn main(){unsafe{
 assert_eq!(size_of::<AbiListHead>(),16); assert_eq!(offset_of!(AbiListHead,next),0); assert_eq!(offset_of!(AbiListHead,prev),8); assert_eq!(size_of::<MemPage>(),80);
 one(); setup(); let mut s=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut s); let mut p=make(11,1); append(&mut s,&mut p.list); let mut b=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut b); let r=detach_pending_free_batch(&mut s,pin.as_mut()); let d=drain_pending_free_batch(&mut s,pin,Some(free_page)); row("one",r,d,CALLBACKS,usize::from(p.mode==PM_NONE));
 setup(); init_list_head(&mut s); let mut a=make(12,2); let mut c=make(13,3); let mut e=make(14,4); append(&mut s,&mut a.list);append(&mut s,&mut c.list);append(&mut s,&mut e.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let r=detach_pending_free_batch(&mut s,pin.as_mut());let d=drain_pending_free_batch(&mut s,pin,Some(free_page));let q=LEDGER.with(|x|{let v=x.borrow();usize::from(v.len()==3&&v[0].0==12&&v[1].0==13&&v[2].0==14)});row("three-order",r,d,CALLBACKS,q);
 setup();init_list_head(&mut s);let mut a=make(20,2);let mut c=make(21,3);append(&mut s,&mut a.list);append(&mut s,&mut c.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);assert_eq!(detach_pending_free_batch(&mut s,pin.as_mut()),0);c.mode=PM_NONE;let z=drain_pending_free_batch(&mut s,pin.as_mut(),Some(free_page));row("later-invalid",z,0,CALLBACKS,usize::from(a.mode==PM_PENDING_FREE));c.mode=PM_PENDING_FREE;let z=drain_pending_free_batch(&mut s,pin,Some(free_page));row("later-invalid-repair",z,z,CALLBACKS,usize::from(a.mode==PM_NONE&&c.mode==PM_NONE));
 setup();let mut b=PendingFreeBatch::new();let z=drain_pending_free_batch(&mut s,Pin::new_unchecked(&mut b),None);row("missing-callback",z,0,CALLBACKS,1);
 setup();init_list_head(&mut s);let mut p=make(30,1);append(&mut s,&mut p.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let _=detach_pending_free_batch(&mut s,pin.as_mut());let mut o=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut o);let z=drain_pending_free_batch(&mut o,pin,Some(free_page));row("wrong-source",z,0,CALLBACKS,usize::from(p.mode==PM_PENDING_FREE));
 setup();init_list_head(&mut s);let mut p=make(31,1);append(&mut s,&mut p.list);let mut b=PendingFreeBatch::new();let mut pin=Pin::new_unchecked(&mut b);let r=detach_pending_free_batch(&mut s,pin.as_mut());let x=detach_pending_free_batch(&mut s,pin.as_mut());let d=drain_pending_free_batch(&mut s,pin.as_mut(),Some(free_page));let _y=drain_pending_free_batch(&mut s,pin,Some(free_page));row("repeated-detach-drain",x,r+d,CALLBACKS,usize::from(p.mode==PM_NONE));
 setup();let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(null_mut(),Pin::new_unchecked(&mut b));row("null-source",z,0,CALLBACKS,1);
 setup();let mut i=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut i);let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(&mut i,Pin::new_unchecked(&mut b));row("inactive-empty",z,0,CALLBACKS,1);
 setup();let mut b=PendingFreeBatch::new();let z=detach_pending_free_batch(&mut b.head,Pin::new_unchecked(&mut b));row("alias-destination",z,0,CALLBACKS,1);
 setup();let mut n=PendingFreeBatch::new();let mut ns=AbiListHead{next:null_mut(),prev:null_mut()};init_list_head(&mut ns);let _=detach_pending_free_batch(&mut ns,Pin::new_unchecked(&mut n));let z=detach_pending_free_batch(&mut ns,Pin::new_unchecked(&mut n));row("nested-begin",z,0,CALLBACKS,1);
 println!("PASS_PENDING_FREE_BATCH_RUST_ROWS");}}
'''

def run(cmd, out, label):
    p=subprocess.run(cmd,text=True,capture_output=True); (out/(label+".stdout")).write_text(p.stdout); (out/(label+".stderr")).write_text(p.stderr); return p

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--output-dir"); args=ap.parse_args()
    out=Path(args.output_dir) if args.output_dir else Path(tempfile.mkdtemp(prefix="mckernel-pending-")); out.mkdir(parents=False,exist_ok=False)
    actual=out/"actual_extracted.rs"; actual.write_text(PREFIX+definitions+TESTS)
    (out/"source-anchors.json").write_text(json.dumps({"start":anchor_start,"end":anchor_end,"start_offset":start,"end_offset":end,"definitions_sha256":definitions_sha256},sort_keys=True,indent=2)+"\n")
    if run(["rustc","+nightly","--edition=2021","-D","warnings",str(actual),"-o",str(out/"actual")],out,"rust-compile").returncode: raise SystemExit("rust compile failed")
    rr=run([str(out/"actual")],out,"rust-run")
    if rr.returncode: raise SystemExit("rust run failed")
    rows=[x for x in rr.stdout.splitlines() if x.startswith("ROW|")]
    if len(rows)!=12: raise SystemExit("unexpected Rust row count")
    cr=run(["cc","-std=c11","-Wall","-Wextra","-Werror","kernel/rust/tests/pending_free_batch_vectors.c","-o",str(out/"reference-c")],out,"c-compile")
    if cr.returncode: raise SystemExit("C compile failed")
    cresult=run([str(out/"reference-c")],out,"c-run")
    if cresult.returncode: raise SystemExit("C run failed")
    crows=[x for x in cresult.stdout.splitlines() if x.startswith("ROW|")]
    if rows!=crows: raise SystemExit("Rust/C rows differ")
    mutant=out/"partial-release-mutant.rs"
    mutant.write_text((PREFIX+definitions+TESTS).replace("let nonempty = match validate_pending_head(source)", "let nonempty = match Ok::<bool, CInt>(true)", 1))
    mr=run(["rustc","+nightly","--edition=2021","-D","warnings",str(mutant),"-o",str(out/"mutant")],out,"mutant-compile")
    if mr.returncode: raise SystemExit("partial-release mutant did not compile")
    mm=run([str(out/"mutant")],out,"mutant-run")
    if mm.returncode==0 and [x for x in mm.stdout.splitlines() if x.startswith("ROW|")] == rows:
        raise SystemExit("partial-release mutant unexpectedly accepted")
    manifest={"status":"PASS_PENDING_FREE_BATCH_FOCUSED_EQUIVALENCE_ONLY","source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),"definitions_sha256":definitions_sha256,"rows":rows,"mutant_rejected":True}
    (out/"manifest.json").write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
    print("PASS_PENDING_FREE_BATCH_FOCUSED_EQUIVALENCE_ONLY output="+str(out))
if __name__=="__main__": main()
