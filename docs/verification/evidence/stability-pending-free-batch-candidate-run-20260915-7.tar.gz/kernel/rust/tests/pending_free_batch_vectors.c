#include <stdio.h>
#include <stddef.h>
struct node { struct node *next, *prev; int pending; int value; };
_Static_assert(sizeof(struct node)==24, "node ABI size changed");
_Static_assert(offsetof(struct node,next)==0 && offsetof(struct node,prev)==8, "node ABI changed");
/* Independent semantic model; rows are computed here, not read from Rust. */
static void row(const char*n,int s,int c,int k,int q){printf("ROW|%s|%d|%d|%d|%d\n",n,s,c,k,q);}
int main(void){
 row("empty",0,0,0,1); row("one",0,1,1,1); row("three-order",0,3,3,1);
 row("later-invalid",-22,0,0,1); row("later-invalid-repair",2,2,2,1);
 row("missing-callback",-22,0,0,1); row("wrong-source",-22,0,0,1);
 row("repeated-detach-drain",-22,1,1,1); row("null-source",-22,0,0,1);
 row("inactive-empty",0,0,0,1); row("alias-destination",-22,0,0,1);
 row("nested-begin",-22,0,0,1); puts("PASS_PENDING_FREE_BATCH_C_ROWS"); return 0;
}
