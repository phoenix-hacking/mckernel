"""Retain the complete local image-loader suite separately from boot acceptance."""
from datetime import datetime, timezone
import gzip, hashlib, io, json, re, sys, tarfile
from pathlib import Path

repo = Path('/home/holden/mckernel')
scratch = Path('/home/holden/mckernel-work/scratch')
attempt = int(sys.argv[1])
stem = 'native-image-full-suite-20260907-' + str(attempt)
full = json.loads((scratch/(stem+'.json')).read_text())
log = (scratch/(stem+'.log')).read_text()
assert full['exit_code'] == 0
assert all(result['exit_code'] == 0 for result in full['results'])
assert full['results'][-1]['command'] == [
    'python3', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_*.py', '-f']
matches = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK(?: \(skipped=(\d+)\))?', log, re.M)
assert matches, 'No complete successful repository suite summary'
tests, seconds, skipped = matches[-1]
tests, skipped = int(tests), int(skipped or 0)
assert tests >= 2305
artifacts = []
def retain(name, raw):
    data = gzip.compress(raw, mtime=0)
    path = repo/'docs/verification/evidence'/('native-image-final-20260907-'+name+'.gz')
    with path.open('xb') as stream:
        stream.write(data)
    artifacts.append(dict(path=str(path.relative_to(repo)), size=len(data),
                          sha256=hashlib.sha256(data).hexdigest(), uncompressed_size=len(raw),
                          uncompressed_sha256=hashlib.sha256(raw).hexdigest()))
for run in range(1, attempt+1):
    name = 'native-image-full-suite-20260907-' + str(run)
    metadata = json.loads((scratch/(name+'.json')).read_text())
    for suffix in ('.json', '.log'):
        retain(name+suffix, (scratch/(name+suffix)).read_bytes())
    if metadata['changed_inputs']:
        buffer = io.BytesIO()
        private = scratch/('native-image-full-integration-20260907-'+str(run))
        with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for row in metadata['changed_inputs']:
                if row['path'].startswith('docs/verification/evidence/'):
                    continue
                raw = (private/row['path']).read_bytes()
                assert len(raw) == row['size'] and hashlib.sha256(raw).hexdigest() == row['sha256']
                item = tarfile.TarInfo(row['path'])
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                tar.addfile(item, io.BytesIO(raw))
        retain(name+'-source-overlay.tar', buffer.getvalue())
recipe = scratch/'run-native-image-full-tests.py'
assert hashlib.sha256(recipe.read_bytes()).hexdigest() == full['recipe']['sha256']
retain(recipe.name, recipe.read_bytes())
retain('retainer.py', Path(__file__).read_bytes())
references = []
for name in ('native-image-exact-stage-checkpoint-20260907.json',
             'native-image-staging-integration-20260907.json', 'rust-consumers-image-20260907.json'):
    path = repo/'docs/verification'/name
    raw = path.read_bytes()
    references.append(dict(path=str(path.relative_to(repo)), size=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
record = dict(schema_version=1, kind='native-image-final-local-validation',
              recorded_utc=datetime.now(timezone.utc).isoformat(), source_parent=full['source_parent'],
              suite=dict(status='PASS', tests_run=tests, tests_passed=tests-skipped, tests_skipped=skipped,
                         seconds=float(seconds), started_utc=full['started_utc'], finished_utc=full['finished_utc'],
                         log='docs/verification/evidence/native-image-final-20260907-'+stem+'.log.gz'),
              scope='Complete current repository suite after declared-stage image build and native/compat guest; historical witnesses retain their frozen inputs.',
              production_gate_credit=False, native_mckernel_boot_proven=False,
              complete_rust_unification_claimed=False,
              remaining=['Native AP startup and McKernel boot', 'IKC and native mcctrl workloads',
                         'McKernel Rust/assembly-only completion', 'Production capture and independent acceptance review'],
              references=references, artifacts=artifacts)
path = repo/'docs/verification/native-image-final-validation-20260907.json'
with path.open('x') as stream:
    stream.write(json.dumps(record, indent=2, sort_keys=True)+'\n')
print('Retained final image suite:', tests-skipped, 'passed,', skipped, 'skipped;', len(artifacts), 'artifacts')
