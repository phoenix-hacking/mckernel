"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-start-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-start-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

plan=json.loads((work/sys.argv[2]).read_text())
record.update(scope=plan['scope'],native_procfs_service_integrated=True,live_procfs_retirement_observed=True,start_integrated=True,scheduled_cleanup_integrated=True,original_module_failures=sum(status=='FAIL' and '-module-' in name for name,status in plan['captures']),original_guest_failures=0)
try:
    shutil.copyfile(__file__,out/'helper.py')
    shutil.copyfile(work/sys.argv[2],out/'retention-plan.json')
    for name,expected in plan['captures']:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,(name,state['status'])
        record['original_guest_failures'] += expected=='FAIL' and 'qemu_args' in state
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[])+state.get('production_inputs',[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        for row in state.get('images',[]):
            for item in row['outputs']:verify(item)
        for capture in state.get('captures',[]):
            for row in capture['artifacts']:verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-complete-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,complete_capture_retained=True,archive_exclusions={}))
    compiled=work/plan['module']
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout);assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='exact pinned rustfmt replay',compiler_capture=str(saved),formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    if (out/'format-replay').exists():artifact(out/'format-replay','native-application-start-20260908-format-replay.tar.gz',True)
    images=work/plan['images'];state=json.loads((images/'record.json').read_text());assert state['status']=='PASS'
    assert [r['kind'] for r in state['images']]==['fallback','legacy-rust','native-rust','native-sysfs-verify']
    record['images']=state['images'];record['guest_compiler']=state['compiler'];record['historical_equivalence']=state['historical_equivalence']
    for row in state['production_inputs']:
        relative=Path(row['path']).relative_to(images/'source');record['guest_compiler_bindings'].append(binding(repo/relative,images/'source'/relative))
    restored=[]
    listing=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rlz','--full-tree',state['source_parent'],'docs/verification/evidence'])
    for raw in listing.split(b'\0'):
        if not raw:continue
        meta,path=raw.split(b'\t',1);mode,kind,blob,size=meta.decode().split();assert kind=='blob'
        restored.append(dict(path=os.fsdecode(path),mode=mode,git_blob=blob,size=int(size),source_commit=state['source_parent']))
    assert restored==json.loads((images/'historical-evidence-restoration.json').read_text())
    assert not (images/'source/docs/verification/evidence').exists()
    record['compile_only_evidence_omission']=dict(**state['historical_evidence_omitted'],source_commit=state['source_parent'],verified_against_exact_git_tree=True,retained_map=identity(images/'historical-evidence-restoration.json'))
    for row in state['images']:
        directory=images/row['kind'];commands=json.loads((directory/'compile_commands.json').read_text())
        for name in ('host.c','procfs.c'):
            assert any(c['file'].endswith('/kernel/'+name) for c in commands)==(row['kind']=='fallback')
        if row['kind']!='fallback':
            selected=(directory/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            for name in ('host_helpers.rs','procfs.rs'):assert 'kernel/rust/'+name in selected
            assert ('native_linux_irq_work_v6_12' in selected)==row['kind'].startswith('native-')
    record['protocol_bindings']=[]
    protocol=work/plan['protocol'];state=json.loads((protocol/'record.json').read_text());assert state['status']=='PASS'
    for row in state['inputs']:
        relative=Path(row['path']).relative_to(protocol/'original-inputs');record['protocol_bindings'].append(binding(repo/relative,protocol/'source'/relative))
    assert 'test result: ok. 7 passed; 0 failed;' in (protocol/'retirement-tests.log').read_text()
    record['protocol_tests']=dict(new=7,existing=19,actual_native_dispatch_lookup_reply=True,controlled_process_lookup_effects=True)
    adapter=work/plan['return_adapter'];state=json.loads((adapter/'record.json').read_text());assert state['status']=='PASS'
    assert 'test result: ok. 5 passed; 0 failed;' in (adapter/'tests.log').read_text()
    record['return_adapter_bindings']=[binding(repo/'host-kernel/native-rust/mcctrl_process.rs',adapter/'original-inputs/host-kernel/native-rust/mcctrl_process.rs'),binding(repo/'scripts/tests/fixtures/native-application-return-adapter.rs',adapter/'native-application-return-adapter.rs')]
    record['return_adapter_tests']=dict(passed=5,actual_extracted_ioctl_bodies=True,controlled_user_copy_and_backend=True)
    record['probe_bindings']=[];record['module_guest_bindings']=[];record['image_guest_bindings']=[];record['guest_results']=[]
    for name in plan['current_guests']:
        guest=work/name;state=json.loads((guest/'record.json').read_text());assert state['status']=='PASS' and state['qemu_exit_code']==0
        if (guest/'probe-source').exists():
            for saved in sorted((guest/'probe-source').iterdir()):
                if saved.name=='ihk_host_user.h.reference':
                    record['probe_bindings'].append(binding(repo/'ihk/linux/include/ihk/ihk_host_user.h',saved))
                elif saved.name=='launcher-config.h.reference':
                    original=work/'native-application-launcher-20260908-2/rust/config.h'
                    assert identity(original)['sha256']==identity(saved)['sha256']
                    record['probe_bindings'].append(dict(path=str(original),compiler_capture=str(saved),sha256=identity(saved)['sha256'],binding='exact retained original launcher configuration'))
                elif saved.name=='native-buildid-abi.h':
                    # Reproduce the captured helper's generation from exact references.
                    macro=re.findall(r'^#define IHK_OS_GET_BUILDID\s+0x[0-9a-fA-F]+\s*$',(guest/'probe-source/ihk_host_user.h.reference').read_text(),re.M)
                    buildid=re.findall(r'^#define BUILDID ("[^"\n]+")$',(guest/'probe-source/launcher-config.h.reference').read_text(),re.M)
                    assert len(macro)==len(buildid)==1
                    assert saved.read_text()==macro[0].strip()+'\n#define BUILDID '+buildid[0]+'\n'
                    assert (compiled/'staged-source/ihk-compat-build-id.bin').read_bytes()==json.loads(buildid[0]).encode()+b'\0'
                    record['probe_bindings'].append(dict(path=str(saved),sha256=identity(saved)['sha256'],binding='generated ABI reproduced exactly from retained references and native payload'))
                else:
                    current=repo/('executer/include/uprotocol.h' if saved.name=='native-image-c-abi.h' else 'scripts/tests/fixtures/'+saved.name)
                    record['probe_bindings'].append(binding(current,saved))
        for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko'):
            left,right=identity(compiled/name),identity(guest/'root/modules'/name)
            assert (left['size'],left['sha256'])==(right['size'],right['sha256'])
            record['module_guest_bindings'].append(dict(compiled=left,guest=right))
        left,right=identity(images/'native-rust/kernel/mckernel.img'),identity(guest/'root/images/mckernel.img')
        assert (left['size'],left['sha256'])==(right['size'],right['sha256']);record['image_guest_bindings'].append(dict(compiled=left,guest=right))
        result=dict(capture=str(guest),qemu_exit_code=state['qemu_exit_code'])
        for key in ('native_procfs','native_waiter','worker_reaper','native_application','mcctrl_image','mcctrl_process','buildid','return_routes'):
            if key in state:result[key]=state[key]
        record['guest_results'].append(result)
        record['mckernel_application_executed']|=state.get('mckernel_application_executed',False)
    for name in plan['helpers']:
        artifact(work/name,'native-application-start-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-application-start-20260908-retain-helper.py.gz')
    for name in ('native-application-reaper-checkpoint-20260908.json','native-procfs-service-checkpoint-20260908.json','native-application-launcher-checkpoint-20260908.json'):
        path=repo/'docs/verification'/name;assert json.loads(path.read_text())['status']=='PASS'
        row=identity(path);row['path']=str(path.relative_to(repo));record['references'].append(row)
    record.update(status='PASS',complete_captures=len(plan['captures']),artifact_bytes=sum(r['size'] for r in record['artifacts']),application_readiness_complete=False,baseline_remaining=plan['baseline_remaining'])
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');(out/'record.json').write_bytes(manifest.read_bytes())
    print(record['status'],out,flush=True)
