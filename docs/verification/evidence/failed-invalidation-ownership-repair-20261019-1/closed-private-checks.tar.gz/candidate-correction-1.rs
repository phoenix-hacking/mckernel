#![allow(dead_code)]
#[path = "original/application_rpc.rs"] mod application_rpc;
#[path = "original/application_syscall.rs"] mod syscall;
use syscall as application_syscall;
#[path = "candidate/smp_application_syscall.rs"] mod mailbox;
#[path = "original/application_pager.rs"] mod pager;
use core::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use syscall::Request;
extern crate self as kernel;
pub mod prelude {
    pub const GFP_KERNEL: u32 = 0;
    pub struct AllocError;
    pub struct Vec<T>(std::vec::Vec<T>);
    pub trait VecExt<T>: Sized {
        fn with_capacity(n: usize, flags: u32) -> Result<Self, AllocError>;
        fn push(&mut self, value: T, flags: u32) -> Result<(), AllocError>;
    }
    impl<T> VecExt<T> for Vec<T> {
        fn with_capacity(n: usize, _flags: u32) -> Result<Self, AllocError> {
            let mut value = std::vec::Vec::new();
            value.try_reserve(n).map_err(|_| AllocError)?;
            Ok(Self(value))
        }
        fn push(&mut self, value: T, _flags: u32) -> Result<(), AllocError> {
            self.0.try_reserve(1).map_err(|_| AllocError)?;
            self.0.push(value);
            Ok(())
        }
    }
    impl<T> core::ops::Deref for Vec<T> {
        type Target = [T];
        fn deref(&self) -> &[T] {
            &self.0
        }
    }
    impl<T> core::ops::DerefMut for Vec<T> {
        fn deref_mut(&mut self) -> &mut [T] {
            &mut self.0
        }
    }
}

#[repr(C, align(8))]
struct Buffer([u8; 64]);

impl Buffer {
    fn new(state: u64) -> Self {
        let mut buffer = Self([0xa5; 64]);
        buffer.0[8..16].fill(0);
        buffer.0[16..24].copy_from_slice(&state.to_le_bytes());
        buffer
    }
}


struct TestRam {
    bytes: core::cell::UnsafeCell<Buffer>,
    physical: u64,
    claimed: core::sync::atomic::AtomicBool,
    releases: core::sync::atomic::AtomicUsize,
}
// SAFETY: The exclusive TestMemory claim serializes host writes. Concurrent
// peer operations use only aligned atomics; full snapshots follow joined work.
unsafe impl Sync for TestRam {}
impl TestRam {
    fn new(physical: u64, state: u64) -> Arc<Self> {
        Arc::new(Self {
            bytes: core::cell::UnsafeCell::new(Buffer::new(state)),
            physical,
            claimed: core::sync::atomic::AtomicBool::new(false),
            releases: core::sync::atomic::AtomicUsize::new(0),
        })
    }
    fn claim(self: &Arc<Self>) -> Result<TestMemory, i32> {
        self.claimed
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .map_err(|_| -16)?;
        Ok(TestMemory {
            ram: self.clone(),
            released: false,
        })
    }
    fn snapshot(&self) -> [u8; 64] {
        unsafe { (*self.bytes.get()).0 }
    }
    fn status(&self) -> u64 {
        unsafe { AtomicU64::from_ptr(self.bytes.get().cast::<u8>().add(8).cast()) }
            .load(Ordering::Acquire)
    }
}
struct TestMemory {
    ram: Arc<TestRam>,
    released: bool,
}
// SAFETY: Construction checks the exclusive claim. Arc owns the aligned RAM;
// unfinished destruction deliberately retains it as a quarantined test owner.
unsafe impl syscall::ResponseMemory for TestMemory {
    fn physical(&self) -> u64 {
        self.ram.physical
    }
    fn address(&mut self) -> *mut u8 {
        self.ram.bytes.get().cast()
    }
    unsafe fn release(mut self) {
        assert!(self.ram.claimed.swap(false, Ordering::AcqRel));
        self.ram.releases.fetch_add(1, Ordering::AcqRel);
        self.released = true;
    }
}
impl Drop for TestMemory {
    fn drop(&mut self) {
        if !self.released {
            // The synthetic peer supplied no retirement proof. Keep its RAM,
            // matching the native started owner's quarantine contract.
            std::mem::forget(self.ram.clone());
        }
    }
}

fn admit(queue: &mut mailbox::Mailbox<TestMemory>, request: Request, state: u64) -> Arc<TestRam> {
    let memory = TestRam::new(request.response(), state);
    assert_eq!(queue.admit(request, |_| memory.claim()), Ok(true));
    memory
}


fn invalidation_request(start: u64, length: u64) -> Request {
 let mut packet=[0u8;128];
 packet[8..12].copy_from_slice(&4i32.to_le_bytes());
 packet[24..28].copy_from_slice(&1i32.to_le_bytes());
 packet[32..36].copy_from_slice(&321i32.to_le_bytes());
 packet[48..52].copy_from_slice(&700i32.to_le_bytes());
 packet[56..64].copy_from_slice(&1u64.to_le_bytes());
 packet[64..72].copy_from_slice(&11u64.to_le_bytes());
 packet[72..80].copy_from_slice(&start.to_le_bytes());
 packet[80..88].copy_from_slice(&length.to_le_bytes());
 packet[120..128].copy_from_slice(&0x800000u64.to_le_bytes());
 let request=Request::decode(&packet,4).unwrap();
 assert_eq!(request.invalidation_range(),Ok((start,start+length)));
 request
}
fn reserved() -> (mailbox::Mailbox<TestMemory>,u64,u64,i32,Arc<TestRam>) {
 let mut queue=mailbox::Mailbox::new().unwrap();let worker=queue.open_worker(900).unwrap();
 let request=invalidation_request(0x400000,4096);let cpu=request.cpu();let ram=admit(&mut queue,request,2);
 let (serial,_)=queue.reserve(worker).unwrap().unwrap();queue.begin_invalidation(worker,serial).unwrap();
 (queue,worker,serial,cpu,ram)
}
fn held(queue:&mailbox::Mailbox<TestMemory>,ram:&TestRam) {
 assert_eq!(ram.status(),0);assert!(ram.claimed.load(Ordering::Acquire));assert_eq!(ram.releases.load(Ordering::Acquire),0);assert!(!queue.drained());
}

include!("focused_cases_reserve_corrected.rs");
