
#[test]
fn failed_mm_error_retains_response_and_allows_exact_success_retry() {
 let (mut queue,worker,serial,cpu,ram)=reserved();
 let outcome=queue.finish_invalidation(worker,serial,-14);
 let published=queue.publish(cpu,|_|Ok(()));
 assert_eq!((outcome,published,ram.status(),ram.releases.load(Ordering::Acquire),ram.claimed.load(Ordering::Acquire)),(Err(-14),Ok(false),0,0,true),"failed MM invalidation must retain exact response owner");
 assert_eq!(queue.close_worker(worker),Err(-16));held(&queue,&ram);
 assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(-512));
 queue.publish(cpu,|_|Ok(())).unwrap();assert_eq!(ram.releases.load(Ordering::Acquire),1);
}
#[test]
fn every_valid_negative_mm_errno_retains_until_proven_success() {
 for value in [-1,-14,-22,-18,-4095] {
  let (mut queue,worker,serial,cpu,ram)=reserved();
  assert_eq!(queue.finish_invalidation(worker,serial,value),Err(value as i32));
  assert_eq!(queue.publish(cpu,|_|panic!("failed clear response publication")),Ok(false));held(&queue,&ram);
  assert!(queue.open_worker(900).is_err());assert_eq!(queue.reserve(worker),Ok(None));
  assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(0));queue.publish(cpu,|_|Ok(())).unwrap();
  assert_eq!(ram.status(),1);assert_eq!(ram.releases.load(Ordering::Acquire),1);assert!(!ram.claimed.load(Ordering::Acquire));
 }
}
#[test]
fn close_and_worker_cancellation_cannot_release_failed_clear() {
 for process_close in [false,true] {
  let (mut queue,worker,serial,cpu,ram)=reserved();
  if process_close {queue.close().unwrap();}else{assert_eq!(queue.close_worker(worker),Err(-16));}
  assert_eq!(queue.finish_invalidation(worker,serial,-22),Err(-22));
  assert_eq!(queue.publish(cpu,|_|panic!("cancellation before clear")),Ok(false));held(&queue,&ram);
  assert_eq!(queue.close_worker(worker),Err(-16));
  assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(-512));queue.publish(cpu,|_|Ok(())).unwrap();
  assert_eq!(i64::from_le_bytes(ram.snapshot()[24..32].try_into().unwrap()),-512);
  queue.close_worker(worker).unwrap();assert!(queue.drained());assert_eq!(ram.releases.load(Ordering::Acquire),1);
 }
}
#[test]
fn wrong_worker_serial_and_invalid_result_preserve_valid_retry() {
 let (mut queue,worker,serial,cpu,ram)=reserved();let wrong=queue.open_worker(901).unwrap();
 for value in [0,-14] {assert_eq!(queue.finish_invalidation(wrong,serial,value),Err(-16));assert_eq!(queue.finish_invalidation(worker,serial+1,value),Err(-2));held(&queue,&ram);}
 for value in [1,i64::MAX,-4096,i64::MIN] {assert_eq!(queue.finish_invalidation(worker,serial,value),Err(-22));held(&queue,&ram);}
 assert!(!queue.quarantined());assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(0));queue.publish(cpu,|_|Ok(())).unwrap();assert_eq!(ram.releases.load(Ordering::Acquire),1);
}
#[test]
fn repeated_error_and_finish_never_duplicate_completion_or_release() {
 let (mut queue,worker,serial,cpu,ram)=reserved();
 for _ in 0..3 {assert_eq!(queue.finish_invalidation(worker,serial,-18),Err(-18));assert_eq!(queue.publish(cpu,|_|panic!("unexpected error completion")),Ok(false));held(&queue,&ram);}
 assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(0));assert_eq!(queue.finish_invalidation(worker,serial,0),Err(-16));
 queue.publish(cpu,|_|Ok(())).unwrap();assert_eq!(queue.finish_invalidation(worker,serial,0),Err(-2));assert_eq!(queue.publish(cpu,|_|panic!("duplicate completion")),Ok(false));assert_eq!(ram.releases.load(Ordering::Acquire),1);
}
#[test]
fn normal_success_keeps_publication_retry_and_exact_one_release() {
 let (mut queue,worker,serial,cpu,ram)=reserved();assert_eq!(queue.finish_invalidation(worker,serial,0),Ok(0));
 for _ in 0..3 {assert_eq!(queue.publish(cpu,|_|Err(-11)),Err(-11));held(&queue,&ram);}
 queue.publish(cpu,|_|Ok(())).unwrap();assert_eq!(ram.status(),1);assert_eq!(ram.releases.load(Ordering::Acquire),1);assert_eq!(queue.returned(worker,serial),Ok(true));assert!(queue.drained());
}
