	.file	"layer_b_native_owner_v1.c"
	.text
	.p2align 4
	.type	monotonic_ns, @function
monotonic_ns:
.LFB95:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movl	$1, %edi
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rsi
	call	clock_gettime
	movl	%eax, %r8d
	xorl	%eax, %eax
	testl	%r8d, %r8d
	jne	.L1
	imulq	$1000000000, (%rsp), %rax
	addq	8(%rsp), %rax
.L1:
	movq	24(%rsp), %rdx
	xorq	%fs:40, %rdx
	jne	.L8
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
.L8:
	.cfi_restore_state
	call	__stack_chk_fail
	.cfi_endproc
.LFE95:
	.size	monotonic_ns, .-monotonic_ns
	.p2align 4
	.type	signal_owned_children, @function
signal_owned_children:
.LFB119:
	.cfi_startproc
	cmpq	$0, 10248(%rdi)
	je	.L20
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movl	%esi, %r13d
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	xorl	%ebp, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	leaq	8(%rdi), %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	jmp	.L17
	.p2align 4,,10
	.p2align 3
.L13:
	cmpb	$0, 10(%rbx)
	jne	.L12
	movl	(%rbx), %esi
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	movl	%r13d, %edx
	movl	$424, %edi
	call	syscall
	testl	%eax, %eax
	jne	.L16
.L15:
	cmpl	$9, %r13d
	jne	.L12
	movb	$1, 10(%rbx)
	.p2align 4,,10
	.p2align 3
.L12:
	addq	$1, %rbp
	addq	$160, %rbx
	cmpq	%rbp, 10248(%r12)
	jbe	.L23
.L17:
	movl	24(%rbx), %eax
	testl	%eax, %eax
	je	.L12
	cmpl	$15, %r13d
	jne	.L13
	cmpb	$0, 9(%rbx)
	jne	.L12
	movb	$1, 9(%rbx)
	movl	(%rbx), %esi
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	movl	$15, %edx
	movl	$424, %edi
	call	syscall
	testl	%eax, %eax
	je	.L12
.L16:
	call	__errno_location
	cmpl	$3, (%rax)
	jne	.L12
	jmp	.L15
	.p2align 4,,10
	.p2align 3
.L23:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L20:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	ret
	.cfi_endproc
.LFE119:
	.size	signal_owned_children, .-signal_owned_children
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"%s-%06llu-%s.json"
	.text
	.p2align 4
	.type	record_open, @function
record_open:
.LFB99:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	leaq	10292(%rdi), %r9
	movl	$96, %ecx
	movl	$1, %edx
	movq	%rdi, %rbx
	movl	$.LC0, %r8d
	subq	$112, %rsp
	.cfi_def_cfa_offset 128
	movq	%fs:40, %rax
	movq	%rax, 104(%rsp)
	xorl	%eax, %eax
	movq	10256(%rdi), %rax
	addq	$1, %rax
	movq	%rax, 10256(%rdi)
	pushq	%rsi
	.cfi_def_cfa_offset 136
	movl	$96, %esi
	pushq	%rax
	.cfi_def_cfa_offset 144
	xorl	%eax, %eax
	leaq	16(%rsp), %rdi
	call	__snprintf_chk
	popq	%rdx
	.cfi_def_cfa_offset 136
	popq	%rcx
	.cfi_def_cfa_offset 128
	cmpl	$95, %eax
	ja	.L29
	movl	(%rbx), %edi
	movl	$384, %ecx
	movl	$655553, %edx
	movq	%rsp, %rsi
	xorl	%eax, %eax
	call	openat
.L24:
	movq	104(%rsp), %rdx
	xorq	%fs:40, %rdx
	jne	.L30
	addq	$112, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L29:
	.cfi_restore_state
	call	__errno_location
	movl	$36, (%rax)
	movl	$-1, %eax
	jmp	.L24
.L30:
	call	__stack_chk_fail
	.cfi_endproc
.LFE99:
	.size	record_open, .-record_open
	.p2align 4
	.type	consume_owner_signal.isra.0, @function
consume_owner_signal.isra.0:
.LFB134:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movl	$64, %ebx
	subq	$152, %rsp
	.cfi_def_cfa_offset 176
	movq	%fs:40, %rax
	movq	%rax, 136(%rsp)
	xorl	%eax, %eax
	jmp	.L35
	.p2align 4,,10
	.p2align 3
.L32:
	cmpq	$128, %rax
	jne	.L40
	movl	(%rsp), %eax
	cmpl	$15, %eax
	je	.L37
	cmpl	$2, %eax
	je	.L37
	subl	$1, %ebx
	je	.L41
.L35:
	movl	0(%rbp), %edi
	movl	$128, %edx
	movq	%rsp, %rsi
	call	read
	testq	%rax, %rax
	jns	.L32
	call	__errno_location
	movl	(%rax), %edx
	cmpl	$11, %edx
	sete	%al
	cmpl	$4, %edx
	sete	%dl
	orl	%edx, %eax
	xorl	$1, %eax
	movzbl	%al, %eax
	negl	%eax
.L31:
	movq	136(%rsp), %rcx
	xorq	%fs:40, %rcx
	jne	.L42
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L40:
	.cfi_restore_state
	call	__errno_location
	movl	$5, (%rax)
	movl	$-1, %eax
	jmp	.L31
	.p2align 4,,10
	.p2align 3
.L37:
	movl	$1, %eax
	jmp	.L31
	.p2align 4,,10
	.p2align 3
.L41:
	xorl	%eax, %eax
	jmp	.L31
.L42:
	call	__stack_chk_fail
	.cfi_endproc
.LFE134:
	.size	consume_owner_signal.isra.0, .-consume_owner_signal.isra.0
	.p2align 4
	.type	write_all, @function
write_all:
.LFB98:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movl	%edi, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdx, %rbx
	testq	%rdx, %rdx
	je	.L44
	.p2align 4,,10
	.p2align 3
.L49:
	movq	%rbx, %rdx
	movq	%rbp, %rsi
	movl	%r12d, %edi
	call	write
	testq	%rax, %rax
	js	.L58
	je	.L59
	addq	%rax, %rbp
	subq	%rax, %rbx
	jne	.L49
.L44:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L58:
	.cfi_restore_state
	call	__errno_location
	cmpl	$4, (%rax)
	je	.L49
	movl	$-1, %eax
.L60:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L59:
	.cfi_restore_state
	call	__errno_location
	movl	$5, (%rax)
	movl	$-1, %eax
	jmp	.L60
	.cfi_endproc
.LFE98:
	.size	write_all, .-write_all
	.p2align 4
	.type	record_finish.isra.0, @function
record_finish.isra.0:
.LFB139:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rdi, %r13
	movl	%esi, %edi
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movl	%esi, %ebp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$8, %rsp
	.cfi_def_cfa_offset 48
	call	fsync
	testl	%eax, %eax
	jne	.L62
	movl	%ebp, %edi
	call	close
	testl	%eax, %eax
	jne	.L84
.L63:
	movl	0(%r13), %edi
	call	fsync
	movl	%eax, %r12d
	testl	%eax, %eax
	je	.L61
	call	__errno_location
	movl	(%rax), %r12d
	movq	%rax, %rbx
	testl	%r12d, %r12d
	jne	.L66
.L61:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	movl	%r12d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L62:
	.cfi_restore_state
	call	__errno_location
	movl	%ebp, %edi
	movl	(%rax), %r12d
	movq	%rax, %rbx
	call	close
	testl	%eax, %eax
	je	.L65
	testl	%r12d, %r12d
	jne	.L66
	jmp	.L64
	.p2align 4,,10
	.p2align 3
.L84:
	call	__errno_location
	movq	%rax, %rbx
.L64:
	movl	(%rbx), %r12d
.L65:
	testl	%r12d, %r12d
	je	.L63
	call	__errno_location
	movq	%rax, %rbx
.L66:
	movl	%r12d, (%rbx)
	movl	$-1, %r12d
	jmp	.L61
	.cfi_endproc
.LFE139:
	.size	record_finish.isra.0, .-record_finish.isra.0
	.p2align 4
	.type	record_write, @function
record_write:
.LFB101:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rdi, %r13
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdx, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	call	record_open
	testl	%eax, %eax
	js	.L85
	movl	%eax, %ebp
	movq	%r12, %rdx
.L87:
	movl	(%rdx), %ecx
	addq	$4, %rdx
	leal	-16843009(%rcx), %eax
	notl	%ecx
	andl	%ecx, %eax
	andl	$-2139062144, %eax
	je	.L87
	movl	%eax, %ecx
	movq	%r12, %rsi
	shrl	$16, %ecx
	testl	$32896, %eax
	cmove	%ecx, %eax
	leaq	2(%rdx), %rcx
	cmove	%rcx, %rdx
	movl	%eax, %edi
	addb	%al, %dil
	movl	%ebp, %edi
	sbbq	$3, %rdx
	subq	%r12, %rdx
	call	write_all
	testl	%eax, %eax
	jne	.L94
	movl	%ebp, %esi
	movq	%r13, %rdi
	popq	%rbp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	jmp	record_finish.isra.0
	.p2align 4,,10
	.p2align 3
.L94:
	.cfi_restore_state
	call	__errno_location
	movl	%ebp, %edi
	movl	(%rax), %r13d
	movq	%rax, %r12
	call	close
	movl	%r13d, (%r12)
.L85:
	popq	%rbp
	.cfi_def_cfa_offset 24
	movl	$-1, %eax
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE101:
	.size	record_write, .-record_write
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC1:
	.string	"{\"state\":\"UNRESOLVED\",\"nonce\":\"%s\",\"owner_pid\":%ld,\"owner_started_ns\":%lu,\"owned_count\":%zu,\"pidfd_inventory\":\"%016lx\",\"supervision_retained\":true,\"reason\":\"%s\",\"deadline_ns\":%lu}\n"
	.section	.rodata.str1.1
.LC2:
	.string	"unresolved"
	.text
	.p2align 4
	.type	record_unresolved, @function
record_unresolved:
.LFB105:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rdi, %rbp
	subq	$656, %rsp
	.cfi_def_cfa_offset 672
	movq	10248(%rdi), %r9
	movq	10280(%rdi), %r10
	movq	%fs:40, %rax
	movq	%rax, 648(%rsp)
	xorl	%eax, %eax
	movabsq	$1469598103934665603, %rax
	testq	%r9, %r9
	je	.L96
	leaq	(%r9,%r9,4), %r8
	leaq	8(%rdi), %rdx
	movabsq	$1099511628211, %rdi
	salq	$5, %r8
	addq	%rdx, %r8
	.p2align 4,,10
	.p2align 3
.L97:
	xorq	16(%rdx), %rax
	movslq	4(%rdx), %rcx
	addq	$160, %rdx
	imulq	%rdi, %rax
	xorq	%rcx, %rax
	imulq	%rdi, %rax
	movq	%rax, %rcx
	movl	-160(%rdx), %eax
	xorq	%rcx, %rax
	imulq	%rdi, %rax
	cmpq	%rdx, %r8
	jne	.L97
.L96:
	pushq	%r10
	.cfi_def_cfa_offset 680
	movl	$.LC1, %r8d
	movl	$640, %ecx
	movl	$1, %edx
	pushq	%rsi
	.cfi_def_cfa_offset 688
	movl	$640, %esi
	pushq	%rax
	.cfi_def_cfa_offset 696
	movslq	10288(%rbp), %rax
	pushq	%r9
	.cfi_def_cfa_offset 704
	leaq	10292(%rbp), %r9
	pushq	10272(%rbp)
	.cfi_def_cfa_offset 712
	pushq	%rax
	.cfi_def_cfa_offset 720
	xorl	%eax, %eax
	leaq	48(%rsp), %rdi
	call	__snprintf_chk
	addq	$48, %rsp
	.cfi_def_cfa_offset 672
	cmpl	$639, %eax
	ja	.L105
	movq	%rsp, %rdx
	movl	$.LC2, %esi
	movq	%rbp, %rdi
	call	record_write
.L95:
	movq	648(%rsp), %rsi
	xorq	%fs:40, %rsi
	jne	.L106
	addq	$656, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L105:
	.cfi_restore_state
	call	__errno_location
	movl	$75, (%rax)
	orl	$-1, %eax
	jmp	.L95
.L106:
	call	__stack_chk_fail
	.cfi_endproc
.LFE105:
	.size	record_unresolved, .-record_unresolved
	.section	.rodata.str1.1
.LC3:
	.string	""
.LC4:
	.string	"true"
.LC5:
	.string	"false"
	.section	.rodata.str1.8
	.align 8
.LC6:
	.string	"{\"state\":\"%s\",\"nonce\":\"%s\",\"owner_pid\":%ld,\"sequence\":%llu,\"pid_observation\":%ld,\"pidfd_fd\":%d,\"pidfd_inventory\":\"%016lx\",\"waitid_wnowait\":%s,\"si_code\":%d,\"si_status\":%d,\"reason\":\"%s\"}\n"
	.text
	.p2align 4
	.type	record_child, @function
record_child:
.LFB104:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$664, %rsp
	.cfi_def_cfa_offset 704
	movq	%fs:40, %rax
	movq	%rax, 648(%rsp)
	xorl	%eax, %eax
	testq	%r9, %r9
	movl	$.LC3, %eax
	cmove	%rax, %r9
	testq	%r8, %r8
	je	.L116
	movl	24(%r8), %ebx
	movl	8(%r8), %r11d
	movl	$.LC4, %r10d
.L109:
	movq	10248(%rbp), %rdi
	movabsq	$1469598103934665603, %rax
	testq	%rdi, %rdi
	je	.L110
	leaq	(%rdi,%rdi,4), %r8
	leaq	8(%rbp), %rsi
	movabsq	$1099511628211, %rdi
	salq	$5, %r8
	addq	%rsi, %r8
	.p2align 4,,10
	.p2align 3
.L111:
	xorq	16(%rsi), %rax
	addq	$160, %rsi
	imulq	%rdi, %rax
	movq	%rax, %r13
	movslq	-156(%rsi), %rax
	xorq	%r13, %rax
	movl	-160(%rsi), %r13d
	imulq	%rdi, %rax
	xorq	%r13, %rax
	imulq	%rdi, %rax
	cmpq	%rsi, %r8
	jne	.L111
.L110:
	testq	%rcx, %rcx
	je	.L118
	movl	(%rcx), %edi
	movslq	4(%rcx), %rsi
	movq	16(%rcx), %rcx
.L112:
	pushq	%r9
	.cfi_def_cfa_offset 712
	movl	$.LC6, %r8d
	movq	%rdx, %r9
	movl	$1, %edx
	pushq	%rbx
	.cfi_def_cfa_offset 720
	pushq	%r11
	.cfi_def_cfa_offset 728
	pushq	%r10
	.cfi_def_cfa_offset 736
	pushq	%rax
	.cfi_def_cfa_offset 744
	movslq	10288(%rbp), %rax
	pushq	%rdi
	.cfi_def_cfa_offset 752
	pushq	%rsi
	.cfi_def_cfa_offset 760
	movl	$640, %esi
	pushq	%rcx
	.cfi_def_cfa_offset 768
	movl	$640, %ecx
	pushq	%rax
	.cfi_def_cfa_offset 776
	leaq	10292(%rbp), %rax
	pushq	%rax
	.cfi_def_cfa_offset 784
	xorl	%eax, %eax
	leaq	80(%rsp), %rdi
	call	__snprintf_chk
	addq	$80, %rsp
	.cfi_def_cfa_offset 704
	cmpl	$639, %eax
	ja	.L122
	movq	%rsp, %rdx
	movq	%r12, %rsi
	movq	%rbp, %rdi
	call	record_write
.L107:
	movq	648(%rsp), %rbx
	xorq	%fs:40, %rbx
	jne	.L123
	addq	$664, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L116:
	.cfi_restore_state
	xorl	%r11d, %r11d
	xorl	%ebx, %ebx
	movl	$.LC5, %r10d
	jmp	.L109
	.p2align 4,,10
	.p2align 3
.L118:
	xorl	%esi, %esi
	movl	$-1, %edi
	xorl	%ecx, %ecx
	jmp	.L112
.L122:
	call	__errno_location
	movl	$75, (%rax)
	movl	$-1, %eax
	jmp	.L107
.L123:
	call	__stack_chk_fail
	.cfi_endproc
.LFE104:
	.size	record_child, .-record_child
	.section	.rodata.str1.1
.LC7:
	.string	"SPAWN"
.LC8:
	.string	"spawn"
.LC9:
	.string	"ADOPTED"
.LC10:
	.string	"adopted"
	.text
	.p2align 4
	.type	persist_acquisition.part.0, @function
persist_acquisition.part.0:
.LFB140:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	$.LC9, %eax
	cmpb	$0, 8(%rsi)
	movl	$.LC7, %edx
	cmove	%rax, %rdx
	movq	%rsi, %rbx
	movl	$.LC10, %eax
	movl	$.LC8, %esi
	cmove	%rax, %rsi
	movq	%rbx, %rcx
	xorl	%r9d, %r9d
	xorl	%r8d, %r8d
	call	record_child
	testl	%eax, %eax
	jne	.L130
	movl	24(%rbx), %edx
	leaq	(%rdx,%rdx,2), %rdx
	movl	child_steps(,%rdx,8), %edx
.L127:
	movl	%edx, 24(%rbx)
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L130:
	.cfi_restore_state
	movl	24(%rbx), %eax
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+20(,%rax,8), %edx
	movl	$-1, %eax
	jmp	.L127
	.cfi_endproc
.LFE140:
	.size	persist_acquisition.part.0, .-persist_acquisition.part.0
	.p2align 4
	.type	poll_owner.constprop.0, @function
poll_owner.constprop.0:
.LFB142:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	$1, %edx
	movq	%rdi, %rbx
	movl	$1, %esi
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	movq	%fs:40, %rax
	movq	%rax, 8(%rsp)
	xorl	%eax, %eax
	xorl	%eax, %eax
	movw	%dx, 4(%rsp)
	movl	$50, %edx
	movw	%ax, 6(%rsp)
	movl	4(%rdi), %eax
	movq	%rsp, %rdi
	movl	%eax, (%rsp)
	call	poll
	testl	%eax, %eax
	js	.L142
	movzwl	6(%rsp), %edx
	testb	$56, %dl
	jne	.L143
	testl	%eax, %eax
	jne	.L144
.L131:
	movq	8(%rsp), %rcx
	xorq	%fs:40, %rcx
	jne	.L145
	addq	$16, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L144:
	.cfi_restore_state
	xorl	%eax, %eax
	andl	$1, %edx
	je	.L131
	leaq	4(%rbx), %rdi
	call	consume_owner_signal.isra.0
	jmp	.L131
	.p2align 4,,10
	.p2align 3
.L142:
	call	__errno_location
	cmpl	$4, (%rax)
	setne	%al
	movzbl	%al, %eax
	negl	%eax
	jmp	.L131
.L143:
	call	__errno_location
	movl	$5, (%rax)
	movl	$-1, %eax
	jmp	.L131
.L145:
	call	__stack_chk_fail
	.cfi_endproc
.LFE142:
	.size	poll_owner.constprop.0, .-poll_owner.constprop.0
	.section	.rodata.str1.1
.LC11:
	.string	"TERMINAL"
.LC12:
	.string	"terminal"
.LC13:
	.string	"lost-child-status"
.LC14:
	.string	"FAILURE"
.LC15:
	.string	"failure"
	.text
	.p2align 4
	.type	collect_once, @function
collect_once:
.LFB121:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	xorl	%r14d, %r14d
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	xorl	%r13d, %r13d
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	movq	%fs:40, %rax
	movq	%rax, 152(%rsp)
	xorl	%eax, %eax
	cmpq	$0, 10248(%rdi)
	leaq	16(%rsp), %r12
	jne	.L147
	jmp	.L168
	.p2align 4,,10
	.p2align 3
.L151:
	movl	$16, %ecx
	movq	%r12, %rdi
	movq	%r13, %rax
	movq	%r12, %rdx
	rep stosq
	movl	$5, %ecx
	movl	$3, %edi
	call	waitid
	testl	%eax, %eax
	jne	.L228
	movl	32(%rsp), %edx
	testl	%edx, %edx
	je	.L229
	leaq	(%r14,%r14,4), %rax
	movl	$1, %ecx
	salq	$5, %rax
	addq	%rbp, %rax
	cmpl	56(%rax), %edx
	je	.L231
.L159:
	cmpb	$0, 8(%r15)
	je	.L161
	cmpl	$1, 24(%rsp)
	movl	40(%rsp), %eax
	je	.L162
	subl	$-128, %eax
.L162:
	movl	10336(%rbp), %edx
	movl	%eax, 10340(%rbp)
	testl	%edx, %edx
	jne	.L161
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	addl	$1, %eax
	movl	%eax, 10336(%rbp)
.L161:
	movl	24(%r15), %eax
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+8(,%rax,8), %eax
	movl	%eax, 24(%r15)
	leaq	(%r14,%r14,4), %rax
	salq	$5, %rax
	cmpl	$3, 32(%rbp,%rax)
	je	.L232
.L165:
	testl	%ecx, %ecx
	jne	.L233
	cmpq	%r14, 10248(%rbp)
	jbe	.L168
.L147:
	leaq	(%r14,%r14,4), %rbx
	salq	$5, %rbx
	leaq	8(%rbp,%rbx), %r15
	addq	%rbp, %rbx
	movl	32(%rbx), %eax
	testl	%eax, %eax
	jne	.L149
	movq	%r15, %rsi
	movq	%rbp, %rdi
	call	persist_acquisition.part.0
	testl	%eax, %eax
	jne	.L150
	movl	32(%rbx), %eax
.L149:
	movl	8(%rbx), %esi
	cmpl	$1, %eax
	jne	.L151
	movl	$16, %ecx
	movq	%r12, %rdi
	movq	%r13, %rax
	movq	%r12, %rdx
	rep stosq
	movl	$16777221, %ecx
	movl	$3, %edi
	call	waitid
	testl	%eax, %eax
	jne	.L228
	movl	32(%rsp), %eax
	testl	%eax, %eax
	je	.L229
	cmpl	12(%rbx), %eax
	je	.L155
.L227:
	call	__errno_location
	movl	$71, (%rax)
.L150:
	movl	$1, %r13d
.L148:
	xorl	%eax, %eax
	movl	$16, %ecx
	movq	%r12, %rdi
	xorl	%esi, %esi
	rep stosq
	movq	%r12, %rdx
	xorl	%edi, %edi
	movl	$16777221, %ecx
	call	waitid
	testl	%eax, %eax
	je	.L169
	call	__errno_location
	cmpl	$10, (%rax)
	sete	%al
	movzbl	%al, %eax
	movl	scan_actions(,%rax,4), %eax
	cmpl	$1, %eax
	je	.L234
	cmpl	$2, %eax
	je	.L226
	testl	%eax, %eax
	jne	.L235
.L225:
	testl	%r13d, %r13d
	je	.L189
.L184:
	movl	$5, 10336(%rbp)
	movl	$-1, %eax
.L146:
	movq	152(%rsp), %rdx
	xorq	%fs:40, %rdx
	jne	.L236
	addq	$168, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L228:
	.cfi_restore_state
	movl	24(%r15), %eax
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+16(,%rax,8), %eax
	movl	%eax, 24(%r15)
	jmp	.L150
	.p2align 4,,10
	.p2align 3
.L229:
	movl	24(%r15), %eax
	addq	$1, %r14
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+12(,%rax,8), %eax
	movl	%eax, 24(%r15)
	cmpq	%r14, 10248(%rbp)
	ja	.L147
	.p2align 4,,10
	.p2align 3
.L168:
	xorl	%r13d, %r13d
	jmp	.L148
	.p2align 4,,10
	.p2align 3
.L233:
	movl	$5, 10336(%rbp)
	jmp	.L227
	.p2align 4,,10
	.p2align 3
.L231:
	movl	48(%rax), %edx
	cmpl	%edx, 24(%rsp)
	jne	.L159
	xorl	%ecx, %ecx
	movl	64(%rax), %eax
	cmpl	%eax, 40(%rsp)
	setne	%cl
	jmp	.L159
	.p2align 4,,10
	.p2align 3
.L169:
	movl	32(%rsp), %esi
	movq	10248(%rbp), %rdi
	testl	%esi, %esi
	je	.L172
	testq	%rdi, %rdi
	je	.L173
	leaq	12(%rbp), %rdx
	xorl	%ecx, %ecx
	jmp	.L175
	.p2align 4,,10
	.p2align 3
.L238:
	addq	$1, %rcx
	addq	$160, %rdx
	cmpq	%rdi, %rcx
	je	.L237
.L175:
	cmpl	(%rdx), %esi
	jne	.L238
	jmp	.L174
	.p2align 4,,10
	.p2align 3
.L235:
	movl	32(%rsp), %esi
.L173:
	xorl	%edx, %edx
	movl	$434, %edi
	xorl	%eax, %eax
	call	syscall
	movq	%rax, %rbx
	testl	%eax, %eax
	js	.L225
	movq	10248(%rbp), %rax
	movl	32(%rsp), %r9d
	cmpl	%r9d, 10328(%rbp)
	sete	%r10b
	cmpq	$64, %rax
	je	.L239
	leaq	1(%rax), %rdx
	leaq	(%rax,%rax,4), %rsi
	movl	$20, %ecx
	xorl	%eax, %eax
	movq	%rdx, 10248(%rbp)
	movq	10264(%rbp), %rdx
	salq	$5, %rsi
	leaq	1(%rdx), %r8
	leaq	0(%rbp,%rsi), %rdx
	leaq	8(%rdx), %rdi
	movq	%r8, 10264(%rbp)
	leaq	8(%rbp,%rsi), %rsi
	rep stosq
	movl	%ebx, 8(%rdx)
	movq	%rbp, %rdi
	movl	%r9d, 12(%rdx)
	movb	%r10b, 16(%rdx)
	movq	%r8, 24(%rdx)
	call	persist_acquisition.part.0
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	negl	%eax
.L174:
	testl	%r13d, %r13d
	je	.L146
	movl	$5, 10336(%rbp)
.L189:
	movl	$-1, %eax
	jmp	.L146
	.p2align 4,,10
	.p2align 3
.L234:
	cmpq	$0, 10248(%rbp)
	movb	$0, 10333(%rbp)
	jne	.L177
.L222:
	testl	%r13d, %r13d
	je	.L230
	movl	$5, 10336(%rbp)
.L230:
	movl	$1, %eax
	jmp	.L146
	.p2align 4,,10
	.p2align 3
.L232:
	cmpb	$0, 16(%rbx)
	je	.L166
	movl	$0, 10328(%rbp)
.L166:
	movl	8(%rbx), %edi
	movl	%ecx, 12(%rsp)
	call	close
	movq	10248(%rbp), %rax
	movl	12(%rsp), %ecx
	leaq	-1(%rax), %rdx
	leaq	(%rdx,%rdx,4), %rax
	salq	$5, %rax
	addq	%rbp, %rax
	movdqu	8(%rax), %xmm2
	movups	%xmm2, 8(%rbx)
	movdqu	24(%rax), %xmm3
	movups	%xmm3, 24(%rbx)
	movdqu	40(%rax), %xmm4
	movups	%xmm4, 40(%rbx)
	movdqu	56(%rax), %xmm5
	movups	%xmm5, 56(%rbx)
	movdqu	72(%rax), %xmm6
	movups	%xmm6, 72(%rbx)
	movdqu	88(%rax), %xmm7
	movups	%xmm7, 88(%rbx)
	movdqu	104(%rax), %xmm2
	movups	%xmm2, 104(%rbx)
	movdqu	120(%rax), %xmm3
	movups	%xmm3, 120(%rbx)
	movdqu	136(%rax), %xmm4
	movups	%xmm4, 136(%rbx)
	movdqu	152(%rax), %xmm5
	movups	%xmm5, 152(%rbx)
	movq	%rdx, 10248(%rbp)
	jmp	.L165
	.p2align 4,,10
	.p2align 3
.L155:
	xorl	%r9d, %r9d
	movq	%r12, %r8
	movq	%r15, %rcx
	movl	$.LC11, %edx
	movl	$.LC12, %esi
	movq	%rbp, %rdi
	call	record_child
	testl	%eax, %eax
	jne	.L240
	leaq	(%r14,%r14,4), %rax
	movdqa	16(%rsp), %xmm6
	movdqa	32(%rsp), %xmm7
	movdqa	48(%rsp), %xmm0
	movdqa	64(%rsp), %xmm1
	salq	$5, %rax
	leaq	32(%rbp,%rax), %rax
	movups	%xmm6, 8(%rax)
	movdqa	80(%rsp), %xmm6
	movups	%xmm7, 24(%rax)
	movdqa	96(%rsp), %xmm7
	movups	%xmm0, 40(%rax)
	movdqa	112(%rsp), %xmm0
	movups	%xmm1, 56(%rax)
	movdqa	128(%rsp), %xmm1
	movups	%xmm6, 72(%rax)
	movups	%xmm7, 88(%rax)
	movups	%xmm0, 104(%rax)
	movups	%xmm1, 120(%rax)
	movl	24(%r15), %eax
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+4(,%rax,8), %eax
	movl	%eax, 24(%r15)
	movl	8(%rbx), %esi
	jmp	.L151
	.p2align 4,,10
	.p2align 3
.L172:
	testq	%rdi, %rdi
	je	.L186
.L226:
	testl	%r13d, %r13d
	jne	.L184
	xorl	%eax, %eax
	jmp	.L146
.L177:
	movl	$.LC14, %edx
	movl	$.LC13, %r9d
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movl	$5, 10336(%rbp)
	movl	$.LC15, %esi
	movq	%rbp, %rdi
	call	record_child
	movq	10248(%rbp), %rdx
	testq	%rdx, %rdx
	je	.L222
	.p2align 4,,10
	.p2align 3
.L179:
	leaq	(%rdx,%rdx,4), %rbx
	salq	$5, %rbx
	addq	%rbp, %rbx
	cmpb	$0, -144(%rbx)
	je	.L181
	movl	$0, 10328(%rbp)
.L181:
	movl	-152(%rbx), %edi
	call	close
	movq	10248(%rbp), %rax
	leaq	-1(%rax), %rdx
	leaq	(%rdx,%rdx,4), %rax
	salq	$5, %rax
	addq	%rbp, %rax
	movdqu	8(%rax), %xmm0
	movups	%xmm0, -152(%rbx)
	movdqu	24(%rax), %xmm1
	movups	%xmm1, -136(%rbx)
	movdqu	40(%rax), %xmm2
	movups	%xmm2, -120(%rbx)
	movdqu	56(%rax), %xmm3
	movups	%xmm3, -104(%rbx)
	movdqu	72(%rax), %xmm4
	movups	%xmm4, -88(%rbx)
	movdqu	88(%rax), %xmm5
	movups	%xmm5, -72(%rbx)
	movdqu	104(%rax), %xmm6
	movups	%xmm6, -56(%rbx)
	movdqu	120(%rax), %xmm7
	movups	%xmm7, -40(%rbx)
	movdqu	136(%rax), %xmm0
	movups	%xmm0, -24(%rbx)
	movdqu	152(%rax), %xmm1
	movups	%xmm1, -8(%rbx)
	movq	%rdx, 10248(%rbp)
	testq	%rdx, %rdx
	jne	.L179
	jmp	.L222
	.p2align 4,,10
	.p2align 3
.L240:
	movl	24(%r15), %eax
	leaq	(%rax,%rax,2), %rax
	movl	child_steps+20(,%rax,8), %eax
	movl	%eax, 24(%r15)
	jmp	.L150
	.p2align 4,,10
	.p2align 3
.L237:
	cmpq	$64, %rcx
	jne	.L173
	movb	$1, 10332(%rbp)
	call	__errno_location
	movl	$28, (%rax)
	testl	%r13d, %r13d
	jne	.L184
	jmp	.L189
.L186:
	movb	$1, 10333(%rbp)
	jmp	.L226
.L239:
	movb	$1, 10332(%rbp)
	call	__errno_location
	movl	%ebx, %edi
	movl	$28, (%rax)
	movq	%rax, %r12
	call	close
	movl	$28, (%r12)
	jmp	.L225
.L236:
	call	__stack_chk_fail
	.cfi_endproc
.LFE121:
	.size	collect_once, .-collect_once
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"UNRESOLVED: %s; record failed: %s\n"
	.text
	.p2align 4
	.type	retain_unresolved, @function
retain_unresolved:
.LFB123:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rsi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movq	%rdi, %rbx
	subq	$32, %rsp
	.cfi_def_cfa_offset 64
	movq	%fs:40, %rax
	movq	%rax, 24(%rsp)
	xorl	%eax, %eax
	movl	$5, 10336(%rdi)
	call	record_unresolved
	testl	%eax, %eax
	jne	.L251
.L242:
	leaq	4(%rbx), %rbp
	jmp	.L244
	.p2align 4,,10
	.p2align 3
.L243:
	movl	$9, %esi
	movq	%rbx, %rdi
	call	signal_owned_children
	movq	%rbp, %rdi
	call	consume_owner_signal.isra.0
	xorl	%esi, %esi
	movq	%rsp, %rdi
	movq	$1, (%rsp)
	movq	$0, 8(%rsp)
	call	nanosleep
.L244:
	movq	%rbx, %rdi
	call	collect_once
	cmpl	$1, %eax
	jne	.L243
	movq	24(%rsp), %rax
	xorq	%fs:40, %rax
	jne	.L252
	addq	$32, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 32
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L251:
	.cfi_restore_state
	call	__errno_location
	movl	(%rax), %edi
	call	strerror
	movq	stderr(%rip), %rdi
	movq	%r12, %rcx
	movl	$.LC16, %edx
	movq	%rax, %r8
	movl	$1, %esi
	xorl	%eax, %eax
	call	__fprintf_chk
	jmp	.L242
.L252:
	call	__stack_chk_fail
	.cfi_endproc
.LFE123:
	.size	retain_unresolved, .-retain_unresolved
	.section	.rodata.str1.1
.LC17:
	.string	"capacity-overflow"
.LC18:
	.string	"live-adopted-unacquired"
.LC19:
	.string	"clock-failure"
.LC20:
	.string	"cleanup-deadline"
.LC21:
	.string	"acquisition-or-reap-error"
.LC22:
	.string	"signal-channel-error"
	.text
	.p2align 4
	.type	cleanup_with_deadline, @function
cleanup_with_deadline:
.LFB124:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	call	monotonic_ns
	movq	%rbp, %rdi
	movq	%rax, %rbx
	call	collect_once
	cmpl	$1, %eax
	je	.L255
	movl	$.LC19, %esi
	testq	%rbx, %rbx
	je	.L263
	movl	$5859375, %eax
	movl	$3000000000, %r12d
	salq	$11, %rax
	addq	%rbx, %r12
	addq	%rax, %rbx
	movq	%rbx, 10280(%rbp)
	jmp	.L257
	.p2align 4,,10
	.p2align 3
.L278:
	cmpq	%rax, 10280(%rbp)
	jbe	.L261
	movq	%rbp, %rdi
	call	collect_once
	cmpl	$1, %eax
	je	.L255
	cmpl	$-1, %eax
	je	.L276
	cmpq	%r12, %rbx
	movq	%rbp, %rdi
	sbbl	%esi, %esi
	andl	$6, %esi
	addl	$9, %esi
	call	signal_owned_children
	movq	%rbp, %rdi
	call	poll_owner.constprop.0
	testl	%eax, %eax
	js	.L277
.L257:
	call	monotonic_ns
	movq	%rax, %rbx
	testq	%rax, %rax
	jne	.L278
.L261:
	cmpb	$0, 10332(%rbp)
	movl	$.LC17, %esi
	jne	.L263
	cmpb	$0, 10333(%rbp)
	movl	$.LC18, %esi
	jne	.L263
	testq	%rbx, %rbx
	movl	$.LC19, %esi
	movl	$.LC20, %eax
	cmovne	%rax, %rsi
.L263:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	movq	%rbp, %rdi
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	jmp	retain_unresolved
.L255:
	.cfi_restore_state
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	xorl	%eax, %eax
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
.L276:
	.cfi_restore_state
	movl	$.LC21, %esi
	jmp	.L263
.L277:
	movl	$.LC22, %esi
	jmp	.L263
	.cfi_endproc
.LFE124:
	.size	cleanup_with_deadline, .-cleanup_with_deadline
	.section	.rodata.str1.1
.LC23:
	.string	"COMPLETE"
	.section	.rodata.str1.8
	.align 8
.LC24:
	.string	"usage: %s OUTPUT_ROOT -- /ABSOLUTE/PROGRAM [ARG ...]\n"
	.section	.rodata.str1.1
.LC25:
	.string	"start"
	.section	.rodata.str1.8
	.align 8
.LC26:
	.string	"{\"state\":\"START\",\"nonce\":\"%s\",\"owner_pid\":%ld,\"owner_started_ns\":%lu,\"argv_hex\":["
	.section	.rodata.str1.1
.LC27:
	.string	"\""
.LC28:
	.string	","
.LC29:
	.string	"]}\n"
.LC30:
	.string	"pre-fork-setup-failure"
.LC31:
	.string	"owner setup failed: %s\n"
.LC32:
	.string	"/proc/self/fd"
.LC33:
	.string	"R"
.LC34:
	.string	"spawn-setup-failure"
.LC35:
	.string	"parent-echild"
.LC36:
	.string	"complete"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB129:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$4096, %rsp
	.cfi_def_cfa_offset 4152
	orq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_def_cfa_offset 8248
	orq	$0, (%rsp)
	subq	$2840, %rsp
	.cfi_def_cfa_offset 11088
	movq	%fs:40, %rax
	movq	%rax, 11016(%rsp)
	xorl	%eax, %eax
	movq	%rsi, %rbx
	cmpl	$3, %edi
	jle	.L280
	movq	16(%rsi), %rax
	cmpb	$45, (%rax)
	jne	.L280
	cmpb	$45, 1(%rax)
	jne	.L280
	cmpb	$0, 2(%rax)
	jne	.L280
	movq	24(%rsi), %rax
	cmpb	$47, (%rax)
	jne	.L280
	movl	$10344, %edx
	xorl	%esi, %esi
	leaq	400(%rsp), %rdi
	call	memset
	movq	8(%rbx), %rdi
	movl	$720896, %esi
	xorl	%eax, %eax
	call	open
	movl	%eax, 400(%rsp)
	testl	%eax, %eax
	js	.L285
	xorl	%edx, %edx
	movl	$16, %esi
	leaq	10752(%rsp), %rdi
	call	getrandom
	movq	%rax, %r8
	xorl	%eax, %eax
	cmpq	$16, %r8
	jne	.L285
	.p2align 4,,10
	.p2align 3
.L286:
	movzbl	10752(%rsp,%rax), %edx
	movl	%edx, %ecx
	andl	$15, %edx
	shrb	$4, %cl
	movzbl	hex.6682(%rdx), %edx
	andl	$15, %ecx
	movzbl	hex.6682(%rcx), %ecx
	movb	%dl, 10693(%rsp,%rax,2)
	movb	%cl, 10692(%rsp,%rax,2)
	addq	$1, %rax
	cmpq	$16, %rax
	jne	.L286
	movb	$0, 10724(%rsp)
	call	getpid
	movl	%eax, 10688(%rsp)
	call	monotonic_ns
	movq	%rax, 10672(%rsp)
	testq	%rax, %rax
	je	.L285
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%eax, %eax
	movl	$1, %esi
	movl	$36, %edi
	call	prctl
	testl	%eax, %eax
	je	.L376
.L285:
	call	__errno_location
	movl	$.LC30, %r9d
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movl	(%rax), %ebp
	movl	$.LC14, %edx
	movl	$.LC15, %esi
	leaq	400(%rsp), %rdi
	call	record_child
	movl	$1, %r12d
	movl	%ebp, %edi
	call	strerror
	movl	$.LC31, %edx
	movl	$1, %esi
	movq	stderr(%rip), %rdi
	movq	%rax, %rcx
	xorl	%eax, %eax
	call	__fprintf_chk
	jmp	.L279
	.p2align 4,,10
	.p2align 3
.L280:
	movq	(%rbx), %rcx
	movl	$.LC24, %edx
	movl	$1, %esi
	xorl	%eax, %eax
	movq	stderr(%rip), %rdi
	movl	$64, %r12d
	call	__fprintf_chk
.L279:
	movq	11016(%rsp), %rax
	xorq	%fs:40, %rax
	jne	.L377
	addq	$11032, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	%r12d, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L376:
	.cfi_restore_state
	leaq	112(%rsp), %rdi
	call	sigemptyset
	movl	$15, %esi
	leaq	112(%rsp), %rdi
	call	sigaddset
	movl	$2, %esi
	leaq	112(%rsp), %rdi
	call	sigaddset
	movl	$17, %esi
	leaq	112(%rsp), %rdi
	call	sigaddset
	movl	$13, %esi
	leaq	112(%rsp), %rdi
	call	sigaddset
	xorl	%edx, %edx
	xorl	%edi, %edi
	leaq	112(%rsp), %rsi
	call	sigprocmask
	testl	%eax, %eax
	jne	.L285
	leaq	248(%rsp), %r13
	movl	$36, %ecx
	xorl	%ebp, %ebp
	movq	%r13, %rdi
	rep stosl
	movq	%r13, %rdi
	movq	$0, 240(%rsp)
	call	sigemptyset
	movabsq	$8589934607, %rax
	movq	%rax, 96(%rsp)
	movabsq	$55834574865, %rax
	movq	%rax, 104(%rsp)
.L291:
	movl	96(%rsp,%rbp,4), %edi
	xorl	%edx, %edx
	leaq	240(%rsp), %rsi
	call	sigaction
	testl	%eax, %eax
	jne	.L285
	addq	$1, %rbp
	cmpq	$4, %rbp
	jne	.L291
	movl	$526336, %edx
	leaq	112(%rsp), %rsi
	orl	$-1, %edi
	call	signalfd
	movl	%eax, 404(%rsp)
	testl	%eax, %eax
	js	.L285
	leaq	400(%rsp), %rdi
	movl	$.LC25, %esi
	leaq	24(%rbx), %r14
	call	record_open
	movl	$256, %ecx
	movl	$1, %edx
	pushq	10672(%rsp)
	.cfi_def_cfa_offset 11096
	movl	%eax, %ebp
	movslq	10696(%rsp), %rax
	movl	$.LC26, %r8d
	movl	$256, %esi
	pushq	%rax
	.cfi_def_cfa_offset 11104
	xorl	%eax, %eax
	leaq	10708(%rsp), %r9
	leaq	10768(%rsp), %rdi
	call	__snprintf_chk
	popq	%rdx
	.cfi_def_cfa_offset 11096
	popq	%rcx
	.cfi_def_cfa_offset 11088
	testl	%ebp, %ebp
	js	.L292
	movslq	%eax, %rdx
	leaq	10752(%rsp), %rsi
	movl	%ebp, %edi
	call	write_all
	testl	%eax, %eax
	jne	.L300
	xorl	%r12d, %r12d
.L294:
	cmpq	$0, 24(%rbx,%r12,8)
	je	.L378
	testq	%r12, %r12
	je	.L297
	movl	$1, %edx
	movl	$.LC28, %esi
	movl	%ebp, %edi
	call	write_all
	testl	%eax, %eax
	jne	.L300
.L297:
	movl	$1, %edx
	movl	$.LC27, %esi
	movl	%ebp, %edi
	call	write_all
	testl	%eax, %eax
	jne	.L300
	movq	24(%rbx,%r12,8), %r15
	jmp	.L298
.L301:
	shrb	$4, %al
	movl	$2, %edx
	leaq	10750(%rsp), %rsi
	movl	%ebp, %edi
	andl	$15, %eax
	movzbl	hex.6460(%rax), %eax
	movb	%al, 10750(%rsp)
	movzbl	(%r15), %eax
	andl	$15, %eax
	movzbl	hex.6460(%rax), %eax
	movb	%al, 10751(%rsp)
	call	write_all
	testl	%eax, %eax
	jne	.L300
	addq	$1, %r15
.L298:
	movzbl	(%r15), %eax
	testb	%al, %al
	jne	.L301
	movl	$1, %edx
	movl	$.LC27, %esi
	movl	%ebp, %edi
	call	write_all
	testl	%eax, %eax
	jne	.L300
	addq	$1, %r12
	jmp	.L294
.L292:
	call	__errno_location
	movl	(%rax), %r12d
	movq	%rax, %rbx
.L337:
	movl	%r12d, (%rbx)
	jmp	.L285
.L300:
	call	__errno_location
	movl	%ebp, %edi
	movl	(%rax), %r12d
	movq	%rax, %rbx
	call	close
	jmp	.L337
.L378:
	movl	$3, %edx
	movl	$.LC29, %esi
	movl	%ebp, %edi
	call	write_all
	testl	%eax, %eax
	jne	.L300
	movl	%ebp, %esi
	leaq	400(%rsp), %rdi
	call	record_finish.isra.0
	movl	%eax, %r12d
	testl	%eax, %eax
	jne	.L285
	movl	$524288, %esi
	leaq	88(%rsp), %rdi
	call	pipe2
	testl	%eax, %eax
	jne	.L306
	call	fork
	movl	%eax, %ebp
	testl	%eax, %eax
	js	.L379
	jne	.L307
	movl	92(%rsp), %edi
	movb	$0, 15(%rsp)
	call	close
	movl	88(%rsp), %edi
	movl	$1, %edx
	leaq	15(%rsp), %rsi
	call	read
	subq	$1, %rax
	jne	.L375
	cmpb	$82, 15(%rsp)
	jne	.L375
	movq	$60, 16(%rsp)
	xorl	%edi, %edi
	leaq	16(%rsp), %rsi
	movq	$60, 24(%rsp)
	movq	$536870912, 32(%rsp)
	movq	$536870912, 40(%rsp)
	movq	$256, 48(%rsp)
	movq	$256, 56(%rsp)
	movq	$67108864, 64(%rsp)
	movq	$67108864, 72(%rsp)
	call	setrlimit
	testl	%eax, %eax
	je	.L380
.L375:
	movl	$127, %edi
	call	_exit
.L307:
	movl	88(%rsp), %edi
	call	close
	xorl	%edx, %edx
	movl	%ebp, %esi
	movl	$434, %edi
	xorl	%eax, %eax
	movl	%ebp, 10728(%rsp)
	call	syscall
	movq	%rax, %rbx
	testl	%eax, %eax
	js	.L374
	movq	10648(%rsp), %rdx
	cmpq	$64, %rdx
	je	.L381
	leaq	1(%rdx), %rax
	movl	$40, %ecx
	imulq	$160, %rdx, %rdx
	movq	%rax, 10648(%rsp)
	movq	10664(%rsp), %rax
	leaq	1(%rax), %rsi
	movl	%r12d, %eax
	leaq	408(%rsp,%rdx), %rdi
	movq	%rsi, 10664(%rsp)
	rep stosl
	movq	%rsi, 424(%rsp,%rdx)
	leaq	400(%rsp), %rdi
	leaq	408(%rsp,%rdx), %rsi
	movl	%ebx, 408(%rsp,%rdx)
	movl	%ebp, 412(%rsp,%rdx)
	movb	$1, 416(%rsp,%rdx)
	call	persist_acquisition.part.0
	testl	%eax, %eax
	jne	.L374
	movl	92(%rsp), %edi
	movl	$1, %edx
	movl	$.LC33, %esi
	call	write_all
	movl	92(%rsp), %edi
	testl	%eax, %eax
	jne	.L382
	call	close
	call	monotonic_ns
	testq	%rax, %rax
	je	.L327
	movl	$29296875, %ebx
	salq	$11, %rbx
	addq	%rax, %rbx
	jmp	.L331
.L385:
	cmpq	%rax, %rbx
	jbe	.L383
	leaq	400(%rsp), %rdi
	call	collect_once
	testl	%eax, %eax
	js	.L327
	subl	$1, %eax
	je	.L330
	leaq	400(%rsp), %rdi
	call	poll_owner.constprop.0
	testl	%eax, %eax
	js	.L327
	jne	.L384
.L331:
	call	monotonic_ns
	testq	%rax, %rax
	jne	.L385
	movl	$5, %eax
.L332:
	movl	%eax, 10736(%rsp)
.L330:
	leaq	400(%rsp), %rdi
	call	cleanup_with_deadline
.L329:
	movl	10736(%rsp), %eax
	cmpl	$1, %eax
	je	.L341
	cmpl	$2, %eax
	je	.L386
	cmpl	$4, %eax
	je	.L343
	cmpl	$3, %eax
	movl	$130, %r12d
	movl	$1, %eax
	movl	$.LC14, %edx
	cmovne	%eax, %r12d
.L334:
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movl	$.LC35, %r9d
	movl	$.LC36, %esi
	leaq	400(%rsp), %rdi
	call	record_child
	movl	404(%rsp), %edi
	testl	%eax, %eax
	movl	$1, %eax
	cmovne	%eax, %r12d
	call	close
	movl	400(%rsp), %edi
	call	close
	jmp	.L279
.L374:
	movl	92(%rsp), %edi
	call	close
.L306:
	movl	$.LC34, %r9d
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movl	$.LC14, %edx
	leaq	400(%rsp), %rdi
	movl	$.LC15, %esi
	movl	$5, 10736(%rsp)
	call	record_child
	leaq	400(%rsp), %rdi
	call	cleanup_with_deadline
	jmp	.L329
.L341:
	movl	$.LC23, %edx
	jmp	.L334
.L380:
	leaq	32(%rsp), %rsi
	movl	$9, %edi
	call	setrlimit
	testl	%eax, %eax
	jne	.L375
	leaq	48(%rsp), %rsi
	movl	$7, %edi
	call	setrlimit
	testl	%eax, %eax
	jne	.L375
	leaq	64(%rsp), %rsi
	movl	$1, %edi
	call	setrlimit
	testl	%eax, %eax
	jne	.L375
	movl	$536870913, %eax
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	movl	$38, %edi
	salq	$5, %rax
	movabsq	$4611686018444165189, %rsi
	movabsq	$9223090561878065158, %rdx
	movq	$32, 264(%rsp)
	movq	%rax, 240(%rsp)
	movabsq	$-4611685752139349995, %rax
	movq	%rsi, 272(%rsp)
	movabsq	$176093724693, %rsi
	movq	%rax, 248(%rsp)
	movabsq	$-9223372036854775802, %rax
	movq	%rsi, 304(%rsp)
	movl	$2147483649, %esi
	salq	$5, %rsi
	movq	%rax, 256(%rsp)
	movq	%rax, 280(%rsp)
	movabsq	$180405403669, %rax
	movq	%rax, 288(%rsp)
	movabsq	$1407379178520582, %rax
	movq	%rsi, 320(%rsp)
	movabsq	$8606711829, %rsi
	movq	%rax, 296(%rsp)
	movq	%rsi, 328(%rsp)
	movabsq	$42966450197, %rsi
	movq	%rax, 336(%rsp)
	movq	%rax, 352(%rsp)
	leaq	240(%rsp), %rax
	movq	%rdx, 312(%rsp)
	movq	%rsi, 344(%rsp)
	movl	$1, %esi
	movq	%rdx, 360(%rsp)
	xorl	%edx, %edx
	movq	%rax, 72(%rsp)
	xorl	%eax, %eax
	movw	$16, 64(%rsp)
	call	prctl
	testl	%eax, %eax
	jne	.L375
	leaq	64(%rsp), %rdx
	movl	$2, %esi
	movl	$22, %edi
	call	prctl
	testl	%eax, %eax
	jne	.L375
	movl	$36, %ecx
	movq	%r13, %rdi
	xorl	%ebp, %ebp
	movabsq	$8589934607, %rsi
	rep stosl
	movq	%rsi, 96(%rsp)
	leaq	112(%rsp), %rdi
	movabsq	$55834574865, %rsi
	movq	%rsi, 104(%rsp)
	movq	$0, 240(%rsp)
	call	sigemptyset
.L315:
	movl	96(%rsp,%rbp,4), %edi
	xorl	%edx, %edx
	leaq	240(%rsp), %rsi
	call	sigaction
	testl	%eax, %eax
	jne	.L375
	addq	$1, %rbp
	cmpq	$4, %rbp
	jne	.L315
	xorl	%edx, %edx
	leaq	112(%rsp), %rsi
	movl	$2, %edi
	call	sigprocmask
	testl	%eax, %eax
	jne	.L375
	movl	88(%rsp), %edi
	call	close
	movl	400(%rsp), %edi
	call	close
	movl	404(%rsp), %edi
	call	close
	movl	$.LC32, %edi
	call	opendir
	movq	%rax, %r12
	testq	%rax, %rax
	je	.L375
	movq	%rax, %rdi
	call	dirfd
	movslq	%eax, %r15
	call	__errno_location
	movq	%rax, %r13
.L317:
	movl	$0, 0(%r13)
	movq	%r12, %rdi
	call	readdir
	movq	%rax, %rbp
	testq	%rax, %rax
	je	.L318
	leaq	19(%rax), %rdi
	movl	$10, %edx
	leaq	64(%rsp), %rsi
	movq	$0, 64(%rsp)
	call	strtol
	cmpb	$0, 19(%rbp)
	je	.L317
	movq	64(%rsp), %rdx
	cmpb	$0, (%rdx)
	jne	.L317
	cmpq	$2, %rax
	jle	.L317
	cmpq	%r15, %rax
	je	.L317
	movl	%eax, %edi
	call	close
	jmp	.L317
.L318:
	movl	0(%r13), %ebp
	movq	%r12, %rdi
	call	closedir
	testl	%ebp, %ebp
	jne	.L387
	movq	24(%rbx), %rdi
	movl	$child_environment, %edx
	movq	%r14, %rsi
	call	execve
	jmp	.L375
.L327:
	movl	$5, 10736(%rsp)
	jmp	.L330
.L386:
	movl	10740(%rsp), %r12d
	movl	$.LC23, %edx
	movl	$.LC14, %eax
	testl	%r12d, %r12d
	cmovne	%rax, %rdx
	jmp	.L334
.L343:
	movl	$124, %r12d
	movl	$.LC14, %edx
	jmp	.L334
.L383:
	movl	$4, %eax
	jmp	.L332
.L384:
	movl	$3, 10736(%rsp)
	jmp	.L330
.L377:
	call	__stack_chk_fail
.L379:
	call	__errno_location
	movl	88(%rsp), %edi
	movl	(%rax), %ebp
	movq	%rax, %rbx
	call	close
	movl	92(%rsp), %edi
	call	close
	movl	%ebp, (%rbx)
	jmp	.L306
.L387:
	movl	%ebp, 0(%r13)
	jmp	.L375
.L382:
	call	close
	jmp	.L306
.L381:
	movb	$1, 10732(%rsp)
	call	__errno_location
	movl	%ebx, %edi
	movl	$28, (%rax)
	call	close
	movl	92(%rsp), %edi
	call	close
	jmp	.L306
	.cfi_endproc
.LFE129:
	.size	main, .-main
	.section	.rodata
	.align 16
	.type	hex.6460, @object
	.size	hex.6460, 17
hex.6460:
	.string	"0123456789abcdef"
	.set	hex.6682,hex.6460
	.section	.rodata.str1.1
.LC37:
	.string	"PATH=/usr/bin:/bin"
.LC38:
	.string	"LANG=C"
.LC39:
	.string	"LC_ALL=C"
.LC40:
	.string	"HOME=/nonexistent"
.LC41:
	.string	"TMPDIR=/nonexistent"
.LC42:
	.string	"PYTHONDONTWRITEBYTECODE=1"
	.section	.rodata
	.align 32
	.type	child_environment, @object
	.size	child_environment, 56
child_environment:
	.quad	.LC37
	.quad	.LC38
	.quad	.LC39
	.quad	.LC40
	.quad	.LC41
	.quad	.LC42
	.quad	0
	.align 16
	.type	scan_actions, @object
	.size	scan_actions, 24
scan_actions:
	.long	0
	.long	1
	.long	2
	.long	2
	.long	3
	.long	0
	.align 32
	.type	child_steps, @object
	.size	child_steps, 96
child_steps:
	.long	1
	.long	0
	.long	0
	.long	0
	.long	0
	.long	0
	.long	1
	.long	2
	.long	1
	.long	1
	.long	1
	.long	1
	.long	2
	.long	2
	.long	3
	.long	2
	.long	2
	.long	2
	.long	3
	.long	3
	.long	3
	.long	3
	.long	3
	.long	3
	.ident	"GCC: (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	 1f - 0f
	.long	 4f - 1f
	.long	 5
0:
	.string	 "GNU"
1:
	.align 8
	.long	 0xc0000002
	.long	 3f - 2f
2:
	.long	 0x3
3:
	.align 8
4:
