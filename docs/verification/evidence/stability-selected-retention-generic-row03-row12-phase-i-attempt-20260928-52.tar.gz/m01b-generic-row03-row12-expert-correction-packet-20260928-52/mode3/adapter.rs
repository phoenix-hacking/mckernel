#![cfg(test)]
//! Mode-3 retained-memory fixture.  This source-only adapter owns its backing
//! independently; no production source includes or depends on it.
use core::mem::{align_of, size_of};
use core::ptr::NonNull;
use core::sync::atomic::{AtomicBool, Ordering};
use kernel::prelude::{Vec, GFP_KERNEL};
use std::sync::{Arc, Mutex};

use crate::application_syscall::{Request, ResponseMemory};
use crate::stability_observer::{self, Claim, Tag};

static FIXTURE_OWNER_LIVE: AtomicBool = AtomicBool::new(false);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Event {
    Construction, Address, PreparationBaseline, StatusStore, Send, Release,
    DeferredInsertion, FinishedDrop, UnfinishedDrop, QuarantineInsertion,
    Deallocation,
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct FixtureMeta {
    pub(crate) allocation_bytes: usize,
    pub(crate) allocation_alignment: usize,
    pub(crate) span_offset: usize,
    pub(crate) span_bytes: usize,
    pub(crate) span_start: usize,
    pub(crate) span_end: usize,
    pub(crate) physical: u64,
    pub(crate) physical_end: u64,
    pub(crate) owner: Claim,
}
#[derive(Clone, Debug)]
pub(crate) struct Snapshot {
    pub(crate) events: std::vec::Vec<Event>, pub(crate) fixture_address_calls: u64,
    pub(crate) observer_address_calls: u64, pub(crate) status_stores: u64,
    pub(crate) sends: u64, pub(crate) releases: u64, pub(crate) deferred: u64,
    pub(crate) finished_drops: u64, pub(crate) unfinished_drops: u64,
    pub(crate) quarantine: u64, pub(crate) deallocations: u64,
    pub(crate) post_release_address: u64, pub(crate) duplicate_release: u64,
    pub(crate) live_owner: bool, pub(crate) released: bool, pub(crate) metadata: FixtureMeta,
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct ObserverCounters { pub(crate) address_calls: u64, pub(crate) payload_calls: u64, pub(crate) payload_bytes: u64, pub(crate) release_calls: u64, pub(crate) released: bool, pub(crate) after_release_calls: u64, pub(crate) duplicate_release: u64 }
pub(crate) fn captured_observer_counters(selection: Claim) -> ObserverCounters {
    let lines = crate::captured_logs();
    let line = lines.iter().rev().find(|line| line.starts_with("STABILITY_OWNER_COUNTERS ")).expect("missing live observer counters");
    let mut values = std::collections::BTreeMap::new();
    for field in line.split_whitespace().skip(1) { let (key, value) = field.split_once('=').expect("malformed observer field"); assert!(values.insert(key, value).is_none(), "duplicate observer field"); }
    assert_eq!(values.get("version"), Some(&"1")); assert_eq!(values.get("selected_ledger_serial"), Some(&"Some(1)"));
    let parse = |key: &str| values.get(key).expect("missing observer field").parse::<u64>().expect("observer type");
    let released = match values.get("released").copied() { Some("true") => true, Some("false") => false, _ => panic!("observer bool") };
    assert_eq!(selection.response.serial, Some(1));
    ObserverCounters { address_calls: parse("address_calls"), payload_calls: parse("payload_calls"), payload_bytes: parse("payload_bytes"), release_calls: parse("release_calls"), released, after_release_calls: parse("after_release_calls"), duplicate_release: parse("duplicate_release") }
}
struct State {
    deferred: Vec<Box<AlignedBacking>>, quarantine: Vec<Box<AlignedBacking>>, events: Vec<Event>,
    fixture_address_calls: u64, observer_address_calls: u64, status_stores: u64, sends: u64,
    releases: u64, finished_drops: u64, unfinished_drops: u64, quarantine_insertions: u64,
    deallocations: u64, post_release_address: u64, duplicate_release: u64, live_owner: bool,
    released: bool, metadata: FixtureMeta,
}
pub(crate) struct Ledger { state: Mutex<State> }
impl Ledger {
    pub(crate) fn new(metadata: FixtureMeta) -> Result<Arc<Self>, i32> {
        let deferred = Vec::with_capacity(1, GFP_KERNEL).map_err(|_| -12)?;
        let quarantine = Vec::with_capacity(1, GFP_KERNEL).map_err(|_| -12)?;
        let events = Vec::with_capacity(12, GFP_KERNEL).map_err(|_| -12)?;
        Ok(Arc::new(Self { state: Mutex::new(State { deferred, quarantine, events,
            fixture_address_calls: 0, observer_address_calls: 0, status_stores: 0, sends: 0,
            releases: 0, finished_drops: 0, unfinished_drops: 0, quarantine_insertions: 0,
            deallocations: 0, post_release_address: 0, duplicate_release: 0, live_owner: true,
            released: false, metadata }) }))
    }
    fn event(state: &mut State, event: Event) { state.events.push(event, GFP_KERNEL).expect("bounded fixture event ledger"); }
    pub(crate) fn construction(&self) { let mut s = self.state.lock().unwrap(); Self::event(&mut s, Event::Construction); }
    pub(crate) fn verify_metadata(&self) { let s = self.state.lock().unwrap(); let meta = s.metadata; assert_eq!(meta.allocation_bytes, 56); assert_eq!(meta.allocation_alignment, 8); assert_eq!(meta.span_offset, 8); assert_eq!(meta.span_bytes, 40); assert_eq!(meta.span_start.checked_add(40), Some(meta.span_end)); assert_eq!(meta.physical, 0x1000); assert_eq!(meta.physical_end, 0x1028); assert_eq!(meta.owner, TestResponseMemory::owner()); assert!(s.live_owner); }
    pub(crate) fn baseline(&self) { let mut s = self.state.lock().unwrap(); Self::event(&mut s, Event::PreparationBaseline); }
    pub(crate) fn send(&self) { let mut s = self.state.lock().unwrap(); s.sends += 1; Self::event(&mut s, Event::Send); }
    pub(crate) fn status_store(&self) { let mut s = self.state.lock().unwrap(); s.status_stores += 1; Self::event(&mut s, Event::StatusStore); }
    fn address(&self, claim: Claim) {
        { let mut s = self.state.lock().unwrap(); assert!(s.live_owner && !s.released, "address after release");
          assert_eq!(s.metadata.owner, claim, "address claim identity"); s.fixture_address_calls += 1; Self::event(&mut s, Event::Address); }
        stability_observer::address(claim);
    }
    fn release(&self, backing: Box<AlignedBacking>, claim: Claim) {
        { let mut s = self.state.lock().unwrap(); assert!(s.live_owner, "duplicate fixture release");
          if s.released { s.duplicate_release += 1; panic!("duplicate fixture release"); }
          assert_eq!(s.metadata.owner, claim, "release claim identity"); s.released = true; s.live_owner = false; s.releases += 1;
          Self::event(&mut s, Event::Release); s.deferred.push(backing, GFP_KERNEL).expect("bounded deferred queue"); Self::event(&mut s, Event::DeferredInsertion); }
        FIXTURE_OWNER_LIVE.store(false, Ordering::Release); stability_observer::release(claim);
    }
    fn unfinished(&self, backing: Box<AlignedBacking>) { let mut s = self.state.lock().unwrap(); assert!(s.live_owner, "duplicate unfinished owner"); s.live_owner = false; s.unfinished_drops += 1; Self::event(&mut s, Event::UnfinishedDrop); s.quarantine.push(backing, GFP_KERNEL).expect("bounded quarantine queue"); s.quarantine_insertions += 1; Self::event(&mut s, Event::QuarantineInsertion); FIXTURE_OWNER_LIVE.store(false, Ordering::Release); }
    fn finished(&self) { let mut s = self.state.lock().unwrap(); s.finished_drops += 1; Self::event(&mut s, Event::FinishedDrop); }
    pub(crate) fn drain_deferred(&self) { self.drain(false); }
    pub(crate) fn drain_quarantine(&self) { self.drain(true); }
    fn drain(&self, quarantine: bool) { let batch = { let mut s = self.state.lock().unwrap(); if quarantine { core::mem::take(&mut s.quarantine) } else { core::mem::take(&mut s.deferred) } }; for backing in batch { drop(backing); let mut s = self.state.lock().unwrap(); s.deallocations += 1; Self::event(&mut s, Event::Deallocation); } }
    pub(crate) fn snapshot(&self) -> Snapshot { let s = self.state.lock().unwrap(); let observer_address_calls = crate::captured_logs().iter().rev().find(|line| line.starts_with("STABILITY_OWNER_COUNTERS ")).and_then(|line| line.split_whitespace().find(|field| field.starts_with("address_calls="))).and_then(|field| field.split_once('=')).and_then(|(_, value)| value.parse::<u64>().ok()).unwrap_or(0); Snapshot { events: s.events.iter().copied().collect(), fixture_address_calls: s.fixture_address_calls, observer_address_calls, status_stores: s.status_stores, sends: s.sends, releases: s.releases, deferred: s.deferred.len() as u64, finished_drops: s.finished_drops, unfinished_drops: s.unfinished_drops, quarantine: s.quarantine_insertions, deallocations: s.deallocations, post_release_address: s.post_release_address, duplicate_release: s.duplicate_release, live_owner: s.live_owner, released: s.released, metadata: s.metadata } }
}
#[repr(align(8))] pub(crate) struct AlignedBacking { bytes: [u8; 56] }
pub(crate) struct TestResponseMemory { backing: Option<Box<AlignedBacking>>, span: Option<NonNull<u8>>, ledger: Arc<Ledger>, finished: bool }
impl TestResponseMemory {
    pub(crate) fn owner() -> Claim { Claim { os: 1, generation: 1, response: Tag { index: 0, serial: Some(1), physical: 0x1000, end: 0x1028 }, payload: None } }
    pub(crate) fn new() -> Result<(Self, Arc<Ledger>), i32> { FIXTURE_OWNER_LIVE.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire).map_err(|_| -16)?; let mut backing = Box::new(AlignedBacking { bytes: [0; 56] }); let start = backing.bytes.as_mut_ptr() as usize; let span_start = start.checked_add(8).ok_or(-75)?; let span_end = span_start.checked_add(40).ok_or(-75)?; let meta = FixtureMeta { allocation_bytes: size_of::<AlignedBacking>(), allocation_alignment: align_of::<AlignedBacking>(), span_offset: 8, span_bytes: 40, span_start, span_end, physical: 0x1000, physical_end: 0x1028, owner: Self::owner() }; assert_eq!(meta.allocation_bytes, 56); assert_eq!(meta.allocation_alignment, 8); assert_eq!(meta.span_end, meta.span_start + 40); assert_eq!(meta.physical_end, meta.physical + 40); let ledger = Ledger::new(meta)?; ledger.construction(); let span = NonNull::new(span_start as *mut u8).ok_or(-22)?; Ok((Self { backing: Some(backing), span: Some(span), ledger: ledger.clone(), finished: false }, ledger)) }
    pub(crate) fn verify_geometry(&self) { self.ledger.verify_metadata(); }
    pub(crate) fn baseline(&self) { self.verify_geometry(); self.ledger.baseline(); }
}
unsafe impl ResponseMemory for TestResponseMemory { fn verification_owner(&self) -> Option<Claim> { Some(Self::owner()) } fn verification_status_store(&self) { self.ledger.status_store(); } fn physical(&self) -> u64 { 0x1000 } fn address(&mut self) -> *mut u8 { self.ledger.address(Self::owner()); self.span.expect("live retained span").as_ptr() } unsafe fn release(mut self) { let backing = self.backing.take().expect("one retained backing"); self.span = None; self.ledger.release(backing, Self::owner()); self.finished = true; } }
impl Drop for TestResponseMemory { fn drop(&mut self) { if self.finished { self.ledger.finished(); } else if let Some(backing) = self.backing.take() { self.span = None; self.ledger.unfinished(backing); } } }
pub(crate) fn request() -> Request { let mut bytes = [0u8; 128]; bytes[8..12].copy_from_slice(&4i32.to_le_bytes()); bytes[24..28].copy_from_slice(&0i32.to_le_bytes()); bytes[32..36].copy_from_slice(&70i32.to_le_bytes()); bytes[48..52].copy_from_slice(&70i32.to_le_bytes()); bytes[52..56].copy_from_slice(&0i32.to_le_bytes()); bytes[56..64].copy_from_slice(&1u64.to_le_bytes()); bytes[64..72].copy_from_slice(&0u64.to_le_bytes()); bytes[72..80].copy_from_slice(&0u64.to_le_bytes()); bytes[80..88].copy_from_slice(&0x2000u64.to_le_bytes()); bytes[88..96].copy_from_slice(&16u64.to_le_bytes()); bytes[120..128].copy_from_slice(&0x1000u64.to_le_bytes()); Request::decode(&bytes, 1).expect("exact request") }
