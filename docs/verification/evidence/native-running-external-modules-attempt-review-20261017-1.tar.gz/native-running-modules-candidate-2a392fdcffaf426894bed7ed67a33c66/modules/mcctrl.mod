/candidate/modules/mcctrl.o
