"""Preserve final isolated test inputs and results without granting gate credit."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re,sys
repo=Path('/home/holden/mckernel');scratch=Path('/home/holden/mckernel-work/scratch');out=repo/'docs/verification/evidence'
run=sys.argv[1];full_name='native-memory-full-suite-20260907-'+run
full=json.loads((scratch/(full_name+'.json')).read_text());log=(scratch/(full_name+'.log')).read_text()
if full['exit_code']!=0:raise SystemExit('Full suite has not passed')
match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK(?: \(skipped=(\d+)\))?',log)
if not match:raise SystemExit('No complete unittest success summary')
tests=int(match[1]);skipped=int(match[3] or 0);artifacts=[]
def retain(name,data):
 target=out/('native-memory-final-20260907-'+name+'.gz')
 if target.exists():raise SystemExit('Refusing existing retained file '+str(target))
 raw=gzip.compress(data,mtime=0);target.write_bytes(raw)
 artifacts.append(dict(path=str(target.relative_to(repo)),sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),uncompressed_sha256=hashlib.sha256(data).hexdigest(),uncompressed_size=len(data)))
for stem in ['native-memory-binding-tests-20260907-'+str(i) for i in range(1,5)]+['native-memory-full-suite-20260907-'+str(i) for i in range(1,int(run)+1)]:
 for suffix in ('.json','.log'):retain(stem+suffix,(scratch/(stem+suffix)).read_bytes())
for name in ['run-native-memory-binding-tests.py','run-native-memory-full-tests.py','refresh-memory-active-bindings.py','refresh-memory-current-dependent-identities.py','refresh-memory-license-bindings.py']:
 retain(name,(scratch/name).read_bytes())
retain('retainer.py',Path(__file__).read_bytes())
recipe=(scratch/'run-native-memory-full-tests.py').read_bytes()
if hashlib.sha256(recipe).hexdigest()!=full['recipe']['sha256']:raise SystemExit('Final executed test helper identity differs')
references=[]
for name in ['native-memory-checkpoint-20260907.json','native-memory-staging-integration-20260907.json','native-memory-exact-stage-checkpoint-20260907.json','rust-consumers-memory-20260907.json']:
 p=repo/'docs/verification'/name;data=p.read_bytes();references.append(dict(path=str(p.relative_to(repo)),sha256=hashlib.sha256(data).hexdigest(),size=len(data)))
record=dict(schema_version=1,kind='native-memory-final-local-validation',recorded_utc=datetime.now(timezone.utc).isoformat(),source_parent=full['source_parent'],suite=dict(status='PASS',tests_run=tests,tests_passed=tests-skipped,tests_skipped=skipped,seconds=float(match[2]),started_utc=full['started_utc'],finished_utc=full['finished_utc'],log=str(out/('native-memory-final-20260907-'+full_name+'.log.gz'))),scope='source-bound local suite and isolated exact-stage memory/CPU guest; final notes may postdate the test snapshot',production_gate_credit=False,native_mckernel_boot_proven=False,complete_rust_unification_claimed=False,remaining=['generation-checked OS CPU/memory assignment and cleanup','McKernel image loading, AP startup, IKC and workloads','McKernel Rust/assembly-only completion','remaining production acceptance and independent review'],references=references,artifacts=artifacts)
p=repo/'docs/verification/native-memory-final-validation-20260907.json'
if p.exists():raise SystemExit('Final record already exists')
p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained final suite:',tests-skipped,'passed,',skipped,'skipped,',match[2],'seconds;',len(artifacts),'artifacts')
