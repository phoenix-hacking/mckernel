import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_tests', ROOT / 'scripts/tests/test_collector_storage_fault_packet.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.ROOT_ARCHIVE = Path('/home/holden/mckernel/docs/verification/evidence/stability-linux-collector-root-success-20260915-2.tar.gz')
assert hashlib.sha256(m.ROOT_ARCHIVE.read_bytes()).hexdigest() == 'ad7c670311f6756cf64610e1d3e0dbdcdb026f86857c8461c3295cc34c17a721'
for name, expected in [('request.bin',m.oracle.REQUEST_SHA), ('selected-inputs.json',m.oracle.SELECTED_SHA), ('fixture',m.oracle.FIXTURE_SHA)]:
    assert hashlib.sha256(m.retained(name)).hexdigest() == expected
case = m.StorageFaultV2SourceTests()
out = ROOT / 'repro-evidence'
out.mkdir()
results = []
def mutate_path(value, path, new):
    for key in path[:-1]:
        value = value[key]
    value[path[-1]] = new
def check(selector, kind, path, replacement):
    root = out / ('case-%03d' % len(results))
    case.write_fixture(root, selector)
    assert m.oracle.validate(root, selector, 0) is True
    if kind == 'report':
        case.mutate_report(root, lambda value: mutate_path(value, path, replacement))
        changed = root / 'collection/report.json'
    else:
        case.republish_owner(root, lambda value: mutate_path(value, path, replacement))
        changed = root / 'owner-result.json'
    case.refresh_supervisor(root)
    try:
        accepted = m.oracle.validate(root, selector, 0)
        error = None
    except Exception as exception:
        accepted = False
        error = type(exception).__name__ + ': ' + str(exception)
    result = dict(selector=selector, kind=kind, path=path, replacement=replacement,
                  accepted=accepted, error=error, fixture=str(root),
                  canonical_sha256=hashlib.sha256(json.dumps(json.loads(changed.read_bytes()),sort_keys=True,separators=(',',':')).encode()).hexdigest())
    results.append(result)
    print(json.dumps(result,sort_keys=True))
    (out / 'results.json').write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')

for selector in (0, 2):
    baseline = out / ('baseline-%d' % selector)
    case.write_fixture(baseline, selector)
    assert m.oracle.validate(baseline, selector, 0)
    report = json.loads((baseline/'collection/report.json').read_bytes())
    for key, value in report.items():
        if type(value) is int:
            check(selector, 'report', [key], float(value))
        elif type(value) is bool:
            check(selector, 'report', [key], int(value))
    for key, value in report['streams'].items():
        check(selector, 'report', ['streams',key], int(value))
for key, value in [('schema_version', True), ('first_failure_errno',False),
                   ('collector_interruption_signal',False), ('owned_children',[{}]),
                   ('subsequent_proc_exe_link_sample',42)]:
    check(0,'report',[key],value)
for key in ('ppid','pgid_at_observation','sid_at_observation'):
    check(0,'report',['linux_child',key],-1)
check(0,'report',['linux_child','identity_observed'],False)
for key in ('trigger_ns','cleanup_start_ns','cleanup_deadline_ns','cleanup_finished_ns'):
    check(0,'owner',['cleanup',key],float({'trigger_ns':6000,'cleanup_start_ns':6100,'cleanup_deadline_ns':22000006000,'cleanup_finished_ns':6600}[key]))
check(0,'owner',['runtime_inputs','request','size'],406.0)
for field,replacement in [('exit_code',False), ('exit_code',0.0), ('exit_code',None),
                          ('exit_code',7), ('exited',1), ('signaled',0),
                          ('signal',False), ('core_dumped',0), ('core_dumped',True)]:
    check(0,'report',['linux_child','wait',field],replacement)
