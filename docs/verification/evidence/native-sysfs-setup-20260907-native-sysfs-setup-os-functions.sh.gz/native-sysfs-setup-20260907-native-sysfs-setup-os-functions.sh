host_values() {
    local cpu field cache index value node
    for cpu in 0 1 2 3; do
        for field in physical_package_id core_id core_siblings thread_siblings; do
            value=$(</sys/devices/system/cpu/cpu${cpu}/topology/${field})
            printf 'SETUP_HOST cpu=%s field=%s value=%s\n' "$cpu" "$field" "$value"
        done
        for cache in /sys/devices/system/cpu/cpu${cpu}/cache/index*; do
            index=${cache##*/index}
            for field in type level coherency_line_size number_of_sets ways_of_associativity physical_line_partition size shared_cpu_map; do
                value=$(<"$cache/$field")
                printf 'SETUP_CACHE cpu=%s index=%s field=%s value=%s\n' "$cpu" "$index" "$field" "$value"
            done
        done
    done
    for node in 0 1; do
        value=$(</sys/devices/system/node/node${node}/distance)
        printf 'SETUP_NODE node=%s distance=%s\n' "$node" "$value"
    done
    test -d /sys/devices/system/cpu/cpu3/node1
    test -d /sys/devices/system/cpu/cpu1/node0
}
scan() {
    local base=$1 cycle=$2 phase=$3 path value line
    for path in "$base"/*; do
        test -e "$path" || continue
        if test -L "$path"; then
            printf 'SETUP_LINK cycle=%s phase=%s path=%s\n' "$cycle" "$phase" "${path#/sys/class/mcos/mcos0}"
        elif test -d "$path"; then
            printf 'SETUP_DIR cycle=%s phase=%s path=%s\n' "$cycle" "$phase" "${path#/sys/class/mcos/mcos0}"
            scan "$path" "$cycle" "$phase"
        else
            value=$(while IFS= read -r line; do printf '%s\n' "$line"; done < "$path"; printf .)
            value=${value%.}
            printf 'SETUP_FILE cycle=%s phase=%s path=%s BEGIN\n%sSETUP_FILE_END\n' "$cycle" "$phase" "${path#/sys/class/mcos/mcos0}" "$value"
        fi
    done
}
