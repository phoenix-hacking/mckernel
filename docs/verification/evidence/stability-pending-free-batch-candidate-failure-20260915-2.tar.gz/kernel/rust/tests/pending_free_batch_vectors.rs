use std::marker::{PhantomData, PhantomPinned};
use std::pin::Pin;

#[repr(C)]
struct PendingFreeBatch {
    head: (usize, usize),
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

fn main() {
    let mut batch = PendingFreeBatch {
        head: (0, 0),
        _pin: PhantomPinned,
        _owner: PhantomData,
    };
    let pinned: Pin<&mut PendingFreeBatch> = unsafe { Pin::new_unchecked(&mut batch) };
    assert_eq!(pinned.head, (0, 0));
    // The destination is pinned through its final address, not by pinning a
    // temporary value which could subsequently be moved.
    println!("PASS pending-free pin-by-reference vector");
}
