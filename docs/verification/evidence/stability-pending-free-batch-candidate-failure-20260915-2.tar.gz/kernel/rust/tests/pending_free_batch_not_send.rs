use std::marker::{PhantomData, PhantomPinned};
use std::thread;

struct PendingFreeBatch {
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

fn main() {
    let batch = PendingFreeBatch { _pin: PhantomPinned, _owner: PhantomData };
    // Expected compile failure: a pending batch must not cross an owner CPU.
    thread::spawn(move || drop(batch));
}
