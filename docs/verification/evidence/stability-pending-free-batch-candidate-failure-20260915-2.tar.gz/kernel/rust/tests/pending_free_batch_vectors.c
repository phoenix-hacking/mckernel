#include <stdio.h>
#include <stdlib.h>

struct node { struct node *next, *prev; int pending; int value; };

static void require(int condition, const char *message)
{
	if (!condition) { fprintf(stderr, "FAIL %s\n", message); exit(1); }
}

static void init(struct node *head)
{
	head->next = head;
	head->prev = head;
}

static void append(struct node *head, struct node *entry)
{
	entry->next = head;
	entry->prev = head->prev;
	head->prev->next = entry;
	head->prev = entry;
}

static int reference_detach(struct node *source, struct node *destination)
{
	if (source->next == source && source->prev == source) {
		init(destination);
		return 0;
	}
	if (source->next->prev != source || source->prev->next != source)
		return -1;
	struct node *entry = source->next;
	while (entry != source) {
		if (!entry || !entry->next || !entry->prev || !entry->pending ||
		    entry->next->prev != entry || entry->prev->next != entry)
			return -1;
		entry = entry->next;
	}
	init(destination);
	destination->next = source->next;
	destination->prev = source->prev;
	destination->next->prev = destination;
	destination->prev->next = destination;
	source->next = source->prev = NULL;
	return 0;
}

int main(void)
{
	struct node source, destination, first = {0}, second = {0};
	init(&source);
	init(&destination);
	require(reference_detach(&source, &destination) == 0,
	        "empty ring accepted");
	init(&source);
	first.pending = second.pending = 1;
	first.value = 11; second.value = 22;
	append(&source, &first); append(&source, &second);
	require(reference_detach(&source, &destination) == 0,
	        "nonempty ring accepted");
	require(destination.next == &first && destination.prev == &second,
	        "order preserved");
	require(first.prev == &destination && second.next == &destination,
	        "boundaries repaired");
	struct node invalid, bad = {0};
	init(&invalid); bad.pending = 0; append(&invalid, &bad);
	require(reference_detach(&invalid, &destination) != 0,
	        "later-invalid input rejected");
	puts("PASS pending-free C reference vectors");
	return 0;
}
