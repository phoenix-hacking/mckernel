"""Capture owned native startup tables in the declared stage and preserved resource regressions; no production gate credit."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

repo = Path('/workspace')
build = Path('/work/native-build-base-24a151fe')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
if len(sys.argv) != 3:
    raise SystemExit('Usage: run-native-startup-declared-stage-guest.py BUILD_EVIDENCE NEW_CAPTURE_DIRECTORY')
compiled, base = (Path(arg).resolve() for arg in sys.argv[1:])
if os.getuid() != 1000 or os.sched_getaffinity(0) != {2, 3, 4, 5}:
    raise SystemExit('Use the fixed unprivileged four-CPU runner')
if not str(compiled).startswith('/work/') or not str(base).startswith('/work/'):
    raise SystemExit('Use the dedicated scratch filesystem')
compiled_record = json.loads((compiled / 'record.json').read_text())
if compiled_record.get('status') != 'PASS':
    raise SystemExit('Declared startup-table build did not pass')
for item in compiled_record['outputs']:
    data = Path(item['path']).read_bytes()
    if len(data) != item['size'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        raise SystemExit('Built input changed: ' + item['path'])
stage_lock = json.loads((compiled / 'stage-lock.json').read_text())
if stage_lock.get('purpose') != 'compiler-evidence-only' or stage_lock.get('credit_eligible') is not False:
    raise SystemExit('Declared stage scope differs')
manifest_data = (repo / 'host-kernel/kbuild/stage-manifest.json').read_bytes()
if hashlib.sha256(manifest_data).hexdigest() != stage_lock['manifest_sha256']:
    raise SystemExit('Declared stage does not match current manifest')
artifact_checks = json.loads((compiled / 'module-artifact-checks.json').read_text())
if artifact_checks.get('status') != 'PASS' or len(artifact_checks.get('modules', [])) != 3:
    raise SystemExit('Current module architecture/format checks are required')
config = (compiled / 'resolved.config').read_text()
for name in ('FAULT_INJECTION', 'FAIL_PAGE_ALLOC', 'FAULT_INJECTION_DEBUG_FS'):
    if 'CONFIG_' + name + '=y\n' not in config:
        raise SystemExit('Missing actual fault-injection configuration: ' + name)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(data).hexdigest(), size=len(data))

base.mkdir()
shutil.copyfile(Path(__file__), base / 'run-helper.py')
shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), base / 'root')
shutil.copyfile(repo / 'scripts/native-memory-reservation-init.sh', base / 'root/init')
(base / 'root/init').chmod(0o755)
subprocess.run(['bash', '-n', str(base / 'root/init')], check=True)
for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
    shutil.copyfile(compiled / name, base / 'root/modules' / name)
(base / 'probe-source').mkdir()
for name in ('native-image-load.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c'):
    shutil.copyfile(repo / 'scripts/tests/fixtures' / name, base / 'probe-source' / name)
for architecture in ('x86_64', 'i386'):
    name = 'native-rust-runtime-mcd0-ioctl-' + architecture + '.S'
    shutil.copyfile(repo / 'scripts' / name, base / 'probe-source' / name)
bindings_path = compiled / 'bindings_generated.rs'
bindings = bindings_path.read_text()
states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', bindings)
if len(states) != 1:
    raise SystemExit('No unique actual CPUHP_AP_ACTIVE binding')
probe_commands = []
for bits, name in ((64, 'x86_64'), (32, 'i386')):
    reference_command = ['cc', '-m' + str(bits), '-nostdlib', '-static', '-no-pie',
                         '-Wl,-e,_start', '-Wl,-z,noexecstack',
                         str(base / 'probe-source' / ('native-rust-runtime-mcd0-ioctl-' + name + '.S')),
                         '-o', str(base / 'root/bin' / ('mcd0-ioctl-' + name))]
    probe_commands.append(reference_command)
    with (base / 'probe-build.log').open('ab') as log:
        subprocess.run(reference_command, check=True, stdout=log, stderr=subprocess.STDOUT)
    command = ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror',
               '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie',
               '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack',
               '-DCPUHP_FAILURE_STATE=' + states[0],
               str(base / 'probe-source/native-image-load.c'),
               '-o', str(base / 'root/bin' / ('native-memory-' + name))]
    probe_commands.append(command)
    with (base / 'probe-build.log').open('ab') as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)

# Retain the preserved image and make malformed variants inside this container.
# The independent model uses ELF program headers, without importing project code.
import struct
image_source = Path('/work/mckernel-native-irq-images-20260907-9/native-rust/kernel/mckernel.img')
image_data = image_source.read_bytes()
image_directory = base / 'root/images'
image_directory.mkdir()
(image_directory / 'mckernel.img').write_bytes(image_data)
headers_offset = struct.unpack_from('<Q', image_data, 32)[0]
headers_count = struct.unpack_from('<H', image_data, 56)[0]
headers_size = struct.unpack_from('<H', image_data, 54)[0]
assert headers_size == 56 and headers_count == 2
headers = [struct.unpack_from('<IIQQQQQQ', image_data, headers_offset + index * 56) for index in range(headers_count)]
assert all(header[0] == 1 for header in headers)
window = bytearray(8 << 20)
for kind, flags, offset, virtual, physical, filesz, memsz, alignment in headers:
    start = virtual - 0xfffffffffe800000
    assert 0 <= start <= start + memsz <= len(window) and filesz <= memsz
    window[start:start + filesz] = image_data[offset:offset + filesz]
checksum = 0xcbf29ce484222325
for byte in window:
    checksum = ((checksum ^ byte) * 0x100000001b3) & ((1 << 64) - 1)
expected_checksum = format(checksum, '016x')
model = dict(image=identity(image_source),program_headers=headers,window_bytes=len(window),
             window_sha256=hashlib.sha256(window).hexdigest(),fnv1a64=expected_checksum)
(base / 'image-model.json').write_text(json.dumps(model,indent=2)+'\n')
(image_directory / 'short.elf').write_bytes(image_data[:63])
for label, position, value in [
    ('late-filesz', headers_offset + 56 + 32, headers[1][6] + 1),
    ('bad-entry', 24, 0),
    ('late-overlap', headers_offset + 56 + 16, headers[0][3]),
    ('late-overflow', headers_offset + 56 + 8, (1 << 64) - 1)]:
    malformed = bytearray(image_data)
    struct.pack_into('<Q', malformed, position, value)
    # Keep alignment independent of the deliberately overlapping destination.
    if label == 'late-overlap': struct.pack_into('<Q', malformed, headers_offset + 56 + 48, 1)
    if label == 'late-overflow': struct.pack_into('<Q', malformed, headers_offset + 56 + 48, 1)
    (image_directory / (label + '.elf')).write_bytes(malformed)
with (image_directory / 'oversized').open('wb') as oversized:
    oversized.seek(64 << 20); oversized.write(b'\0')
print('Prepared immutable image model checksum=' + expected_checksum, flush=True)

environment = dict(os.environ, RUNTIME_EVIDENCE=str(base), INITRAMFS_ROOT=str(base / 'root'))
subprocess.run(['python3', '/work/write-native-cpio-spec.py'], env=environment, check=True)
with (base / 'initramfs.cpio.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
        process = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio',
                                    '-t', '0', str(base / 'initramfs.list')], stdout=subprocess.PIPE)
        shutil.copyfileobj(process.stdout, output)
        process.stdout.close()
        if process.wait() != 0:
            raise SystemExit('Initramfs generation failed')

args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi',
        '-cpu', 'max,la57=off', '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
        '-object', 'memory-backend-ram,size=4G,id=ram-node0',
        '-object', 'memory-backend-ram,size=4G,id=ram-node1',
        '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0',
        '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
        '-kernel', str(compiled / 'bzImage'), '-initrd', str(base / 'initramfs.cpio.gz'),
        '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1',
        '-display', 'none', '-monitor', 'none', '-serial', 'file:' + str(base / 'serial.log'),
        '-no-reboot', '-nic', 'none']
inputs = [Path(__file__), base / 'initramfs.cpio.gz',
          Path('/work/write-native-cpio-spec.py'), Path('/work/native-runtime-24a151fe/gen_init_cpio'),
          Path('/usr/bin/cc').resolve()]
# Select immutable build inputs explicitly. Orchestration logs and later
# result records in the build directory are not inputs to this guest.
inputs += [Path(item['path']) for item in compiled_record['outputs']]
inputs += [compiled / name for name in ('record.json', 'bindings_generated.rs',
                                       'module-artifact-checks.json')]
if len({str(path) for path in inputs}) != len(inputs):
    raise SystemExit('Duplicate immutable guest input')
inputs += [path for path in sorted((base / 'probe-source').rglob('*')) if path.is_file()]
inputs += [image_source]
record = dict(kind='native-irq-abi-image-startup-tables-declared-stage-debug-two-numa-nodes', qemu_args=args,
              started_utc=datetime.now(timezone.utc).isoformat(), status='running',
              cpus=4, cpuset=sorted(os.sched_getaffinity(0)), memory_mib=8192,
              container_memory_mib=12288, network='none', acceleration='TCG',
              configuration_scope='isolated-image-fault-injection-debug-variant',
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              inputs=[identity(path) for path in inputs], probe_compile_commands=probe_commands,
              compiler_version=subprocess.check_output(['cc', '--version'], text=True),
              initramfs_files=[identity(path) for path in sorted((base / 'root').rglob('*')) if path.is_file()],
              declared_stage_inputs_required=True, numa_nodes=2, production_gate_credit=False,
              memory_reservation_proven=False, memory_assignment_proven=False, mckernel_boot_proven=False)

def save():
    (base / 'local-run.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

save()
with (base / 'qemu.log').open('wb') as output:
    result = subprocess.run(['/usr/bin/timeout', '--signal=TERM', '--kill-after=30s', '1200'] + args,
                            stdout=output, stderr=subprocess.STDOUT)
record.update(qemu_exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
serial = (base / 'serial.log').read_text(errors='replace')
expected = ['NATIVE_MEMORY_GUEST CYCLE=' + str(cycle) + ' restored=0-3 unloaded=all PASS'
            for cycle in (1, 2)] + ['NATIVE_MEMORY_GUEST COMPLETE PASS',
                                   'NATIVE_MEMORY_GUEST NUMA nodes=0-1 cpu-map=0-1/2-3 PASS']
missing = [marker for marker in expected if serial.count(marker) != 1]
for architecture in ('x86_64', 'i386'):
    for category, checks in (
        ('CPU', ('reserve-rollback=3', 'online-veto-and-closed-file-pin',
                 'release-rollback=3', 'concurrent=3x8', 'COMPLETE')),
        ('MEMORY', ('malformed-copyfaults', 'numa-query-closed-file-pin',
                    'unbooted-os-preserves-pool',
                    'release-preflight-partial-rounding', 'allocation-rollback=8x3-no-leak',
                    'allocation-order-fallback', 'bounded-all-request', 'concurrent=3x8', 'COMPLETE'))):
        for check in checks:
            marker = 'NATIVE_' + category + '_RESERVATION ' + architecture + ' ' + check + ' PASS'
            if serial.count(marker) != 2:
                missing.append('Expected exactly twice: ' + marker)
for architecture in ('x86_64', 'i386'):
    for check in ('ordered-cpu-cross-owner-rollback', 'numa-subpage-batch-rollback',
                  'concurrent-instances=2x8', 'all-and-empty-memory-requests',
                  'closed-files-generation-cleanup', 'COMPLETE'):
        marker = 'NATIVE_OS_RESOURCE ' + architecture + ' ' + check + ' PASS'
        if serial.count(marker) != 2:
            missing.append('Expected exactly twice: ' + marker)

for architecture in ('x86_64', 'i386'):
    for check in ('prerequisites-and-other-os-lower-node', 'file-errors-atomic-preflight',
                  'repeat-load-and-bss-readback', 'simultaneous-os-loads',
                  'release-destroy-generation-cleanup', 'startup-owner-cleanup=8',
                  'startup-allocation-failures=16', 'COMPLETE'):
        marker = 'NATIVE_IMAGE_LOAD ' + architecture + ' ' + check + ' PASS'
        if serial.count(marker) != 2: missing.append('Expected exactly twice: ' + marker)
readbacks = re.findall(r'IHK-SMP: image loaded os=([0-9]+) generation=([0-9]+) segments=([0-9]+) window=([0-9]+) checksum=([0-9a-f]+); CPUs not started', serial)
if len(readbacks) != 56: missing.append('Expected exactly 56 physical image readbacks, got ' + str(len(readbacks)))
for owner, generation, segments, length, digest in readbacks:
    if owner not in ('0','1') or int(generation) < 1 or segments != '2' or length != str(8 << 20) or digest != expected_checksum:
        missing.append('Physical image readback differs from independent ELF model')
record['image_model'] = model
record['physical_image_readbacks'] = readbacks

# Independent hierarchical x86 encoder: allocate child tables while visiting
# virtual addresses, then share the identity subtree with the straight map.
# No project planner or native source is imported into this expected-byte model.
def startup_model(root, kernel):
    if root == 0 or root % (2 << 20) or root + 260 * 4096 > 1 << 32:
        raise ValueError('startup root is outside its owned DMA32 geometry')
    if kernel % (2 << 20) or kernel + (8 << 20) > 256 << 30:
        raise ValueError('kernel placement is outside preserved startup mappings')
    tables = [[0] * 512]
    def map_large(virtual, physical):
        parent = 0
        for shift in (39, 30):
            index = (virtual >> shift) & 511
            if not tables[parent][index]:
                tables[parent][index] = root + len(tables) * 4096 | 0x63
                tables.append([0] * 512)
            parent = ((tables[parent][index] & ~0xfff) - root) // 4096
        index = (virtual >> 21) & 511
        if tables[parent][index]:
            raise ValueError('overlapping model mapping')
        tables[parent][index] = physical | 0xe3
    for physical in range(0, 256 << 30, 2 << 20):
        map_large(physical, physical)
    tables[0][256] = tables[0][0]
    for offset in range(0, 8 << 20, 2 << 20):
        map_large(0xfffffffffe800000 + offset, kernel + offset)
    if len(tables) != 260:
        raise ValueError('unexpected complete page-table size')
    raw = b''.join(struct.pack('<512Q', *page) for page in tables)
    checksum = 0xcbf29ce484222325
    for byte in raw:
        checksum = ((checksum ^ byte) * 0x100000001b3) & ((1 << 64) - 1)
    return dict(root_physical=root, image_physical=kernel, pages=len(tables),
                byte_count=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                fnv1a64=format(checksum, '016x'))

table_readbacks = re.findall(r'IHK-SMP: startup tables os=([0-9]+) generation=([0-9]+) root=([0-9a-f]+) image=([0-9a-f]+) pages=([0-9]+) checksum=([0-9a-f]+); CPUs not started', serial)
if len(table_readbacks) != 56:
    missing.append('Expected exactly 56 physical startup-table readbacks, got ' + str(len(table_readbacks)))
models = {}
for owner, generation, root, kernel, pages, checksum in table_readbacks:
    key = root + ':' + kernel
    try:
        if key not in models:
            models[key] = startup_model(int(root, 16), int(kernel, 16))
        expected_table = models[key]
        if owner not in ('0', '1') or int(generation) < 1 or pages != '260' or checksum != expected_table['fnv1a64']:
            missing.append('Actual startup tables differ from independent x86 model')
    except ValueError as error:
        missing.append(str(error))
if [row[:2] for row in readbacks] != [row[:2] for row in table_readbacks]:
    missing.append('Image and startup-table generation publication differs')
if not any(model['image_physical'] >= 1 << 32 for model in models.values()):
    missing.append('Missing above-4-GiB image placement')
failure_marker = 'IHK-SMP: startup table allocation failed order=9; CPUs not started'
if serial.count(failure_marker) != 64:
    missing.append('Expected exactly 64 forced startup allocation failures, got ' + str(serial.count(failure_marker)))
record['startup_table_models'] = list(models.values())
record['physical_startup_table_readbacks'] = table_readbacks
record['startup_allocation_failures'] = serial.count(failure_marker)
record['startup_tables_proven'] = False

errors = [pattern for pattern in ('NATIVE_IMAGE_LOAD x86_64 FAIL', 'NATIVE_IMAGE_LOAD i386 FAIL', 'NATIVE_MEMORY_GUEST FAIL', 'NATIVE_MEMORY_RESERVATION ' + 'x86_64 FAIL',
          'NATIVE_MEMORY_RESERVATION i386 FAIL', 'NATIVE_OS_RESOURCE x86_64 FAIL', 'NATIVE_OS_RESOURCE i386 FAIL', ' FAIL line=', 'BUG:', 'WARNING:',
          'Kernel panic', 'Oops:', 'scheduling while atomic', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP') if pattern in serial]
for row in record['inputs']:
    data = Path(row['path']).read_bytes()
    if len(data) != row['size'] or hashlib.sha256(data).hexdigest() != row['sha256']:
        errors.append('changed immutable input: ' + row['path'])
record['missing_markers'] = missing
record['error_markers'] = errors
passed = result.returncode == 0 and not errors and not missing
record['status'] = 'technical-capture-passed' if passed else 'failed'
record['startup_tables_proven'] = passed
record['memory_reservation_proven'] = passed
record['memory_assignment_proven'] = passed
record['cpu_assignment_proven'] = passed
record['image_loading_proven'] = passed
record['outputs'] = [identity(base / name) for name in ('serial.log', 'qemu.log')]
save()
print(json.dumps({key: record[key] for key in ('status', 'qemu_exit_code', 'missing_markers', 'error_markers')}))
raise SystemExit(0 if passed else 1)
