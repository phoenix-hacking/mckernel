"""Inspect retained files only; never import or execute a subject helper."""
from pathlib import Path
import base64
import gzip
import hashlib
import json
import os
import re
import shutil
import stat
import struct
import tarfile

HERE = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SCRATCH = Path('/home/holden/mckernel-work/scratch')
PHYS = SCRATCH / 'stability-published-physical-tests-20260913-1'
PREP = SCRATCH / 'stability-published-guest-root-20260913-postpublish-notify-1'
verified, unmapped = [], []

def digest(data):
    return hashlib.sha256(data).hexdigest()

def mapped(path):
    if path.startswith('/work/'):
        return SCRATCH / path[6:]
    if path.startswith('/workspace/'):
        return REPO / path[11:]
    if path.startswith('docs/') or path.startswith('scripts/'):
        return REPO / path
    if path.startswith(str(REPO) + '/') or path.startswith(str(SCRATCH) + '/'):
        return Path(path)
    return None

def identity(row):
    p = mapped(row['path'])
    if p is None:
        unmapped.append(row)
        return None
    raw = p.read_bytes()
    assert len(raw) == row.get('size', row.get('size_bytes')) and digest(raw) == row['sha256'], p
    verified.append(dict(declared=row, actual_host_path=str(p)))
    return raw

def identities(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value and ('size' in value or 'size_bytes' in value):
            identity(value)
        else:
            for part in value.values():
                identities(part)
    elif isinstance(value, list):
        for part in value:
            identities(part)

def inventory(root):
    rows = []
    for p in sorted(root.rglob('*')):
        info = p.lstat()
        row = dict(path=str(p.relative_to(root)), mode=stat.S_IMODE(info.st_mode))
        if stat.S_ISDIR(info.st_mode):
            row['kind'] = 'directory'
        elif stat.S_ISREG(info.st_mode):
            raw = p.read_bytes()
            row.update(kind='file', size=len(raw), sha256=digest(raw))
        elif stat.S_ISLNK(info.st_mode):
            row.update(kind='symlink', target=os.readlink(p))
        else:
            raise AssertionError('unexpected file type: ' + str(p))
        rows.append(row)
    return rows

def retain_tree(source, target):
    assert not target.exists()
    shutil.copytree(source, target, symlinks=True)
    assert inventory(source) == inventory(target)

raw_phys, raw_prep = (PHYS / 'record.json').read_bytes(), (PREP / 'record.json').read_bytes()
assert digest(raw_phys) == '535af587641c1a55d0727f477d823b2a493faba1b819d7bac808a377e867e6f6'
assert digest(raw_prep) == '2ab2c4ae463359c71231770d88ae056213c01c142d3d08eeeb43d934a897ccee'
physical, prepared = json.loads(raw_phys), json.loads(raw_prep)
identities(physical)
identities(prepared)
assert physical['status'] == 'PASS_SYNTHETIC_PUBLISHED_PHYSICAL_COMPARATOR_ONLY' and physical['cases'] == 18
assert len(physical['inputs']) == 4
for pair in physical['inputs']:
    assert identity(pair['original']) == identity(pair['retained'])
assert physical['application_acceptance'] is physical['transport_acceptance'] is physical['guest_execution'] is False
result = physical['collection']
assert result == json.loads((PHYS / 'collection/report.json').read_bytes())
assert result['argv'] == physical['command'] and result['env'] == physical['environment']
assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete']
assert result['descendants'] == [] and result['descendant_records_omitted'] == 0
assert result['payload_completion_observed_monotonic'] < result['payload_monotonic_deadline']
for stream in result['streams'].values():
    assert stream['eof'] and not stream['truncated'] and stream['discarded_observed_bytes'] == 0
    assert stream['bytes_observed'] == stream['bytes_retained'] == stream['artifact']['size']
evidences = list((PHYS / 'tmp').iterdir())
assert len(evidences) == 1
evidence = evidences[0]
assert (PHYS / 'collection/stdout.bin').read_bytes() == ('PUBLISHED_PHYSICAL_TEST_EVIDENCE /work/' + str(evidence.relative_to(SCRATCH)) + '\n').encode()
assert re.fullmatch(rb'\.{18}\n-{70}\nRan 18 tests in [0-9]+\.[0-9]+s\n\nOK\n', (PHYS / 'collection/stderr.bin').read_bytes())
declared_sources = json.loads((evidence / 'inputs.json').read_bytes())
for row in declared_sources['source_inputs']:
    raw = identity(row)
    assert raw == mapped(row['retained']).read_bytes()
test_source = (evidence / 'source/test_published_physical_observations.py').read_text()
methods = set(re.findall(r'^    def (test_\w+)\(', test_source, re.M))
assert len(methods) == 18 and {p.name for p in evidence.iterdir() if p.name.startswith('test_')} == methods

def decode(value, directory):
    kind = value['type']
    if kind in ('bytes', 'bytearray'):
        raw = (directory / value['path']).read_bytes()
        assert len(raw) == value['size'] and digest(raw) == value['sha256']
        return raw if kind == 'bytes' else bytearray(raw)
    if kind in ('tuple', 'list'):
        values = [decode(item, directory) for item in value['items']]
        return tuple(values) if kind == 'tuple' else values
    if kind == 'dict':
        return {decode(k, directory): decode(v, directory) for k, v in value['items']}
    return value['value']

def raw_values(value):
    if isinstance(value, dict):
        if set(value) == {'size', 'sha256', 'base64'}:
            raw = base64.b64decode(value['base64'], validate=True)
            assert len(raw) == value['size'] and digest(raw) == value['sha256']
        else:
            for item in value.values():
                raw_values(item)
    elif isinstance(value, list):
        for item in value:
            raw_values(item)

calls = []
for path in sorted(evidence.rglob('invocation.json')):
    invocation = json.loads(path.read_bytes())
    outcome = json.loads(path.with_name('outcome.json').read_bytes())
    args, kwargs = decode(invocation['args'], path.parent), decode(invocation['kwargs'], path.parent)
    assert invocation['application_acceptance'] is outcome['application_acceptance'] is False
    if invocation['expected_outcome'] == 'PhysicalObservationError':
        assert outcome['outcome'] == 'raised' and outcome['type'] == 'PhysicalObservationError'
    else:
        assert invocation['expected_outcome'] == 'return' and outcome['outcome'] == 'returned'
        raw_values(outcome['result'])
        if invocation['function'] == 'compare_prepared_response':
            actual = outcome['result']
            expected = bytearray(args[0])
            expected[4:8] = kwargs['worker_tid'].to_bytes(4, 'little', signed=True)
            expected[16:24] = (1).to_bytes(8, 'little')
            expected[24:32] = (16).to_bytes(8, 'little', signed=True)
            assert bytes(expected) == args[1] == base64.b64decode(actual['expected_prepublication_prefix']['base64'])
            assert base64.b64decode(actual['raw']['BlockedRead']['base64']) == args[0]
            assert base64.b64decode(actual['raw']['AcceptedReturn']['base64']) == args[1]
        else:
            actual = outcome['result']
            assert base64.b64decode(actual['before']['raw']['base64']) == args[0]
            assert base64.b64decode(actual['after']['raw']['base64']) == args[1]
            expected_count = 1 if invocation['function'] == 'one_new_requester_wake' else 0
            assert actual['new_matching_wakes'] == expected_count
            if expected_count:
                item = actual['match']
                assert item['slot'] == item['sequence'] % 127 and item['offset'] == 64 + item['slot'] * 128
                packet = args[1][item['offset']:item['offset'] + 128]
                assert packet == base64.b64decode(item['packet']['base64'])
                assert struct.unpack_from('<i', packet, 8)[0] == 20 and struct.unpack_from('<i', packet, 24)[0] == args[2]
    calls.append(dict(path=str(path.relative_to(evidence)), expected=invocation['expected_outcome'], observed=outcome['outcome']))
assert len(calls) == 131
retain_tree(PHYS, HERE / 'physical18')

assert prepared['status'] == 'PREPARED_REQUIRES_COMPILED_STACK_REVIEW'
for key in ('application_acceptance', 'transport_acceptance', 'production_gate_credit', 'payload_execution', 'guest_execution', 'guest_release_ready'):
    assert prepared[key] is False
assert prepared['compiled_stack_readiness']['status'] == 'PENDING_ACTUAL_REVIEW'
assert prepared['compiled_stack_readiness']['actual_stack_frames_verified'] is False
assert (prepared['mode'], prepared['controller_profile'], prepared['payload_profile'], prepared['controller_protocol'], prepared['phase_ioctl_version'], prepared['phase_ioctl_command']) == ('postpublish-notify', 'owner-published-hold-v1', 'runnable-thread-v1', 'STF2', 2, '0xc100f502')
assert digest((PREP / 'helper.py').read_bytes()) == 'addbadabce8cba4db7ef863fc8728e68150e8301ccc55972a5ef623f52160056'
assert (PREP / 'helper.py').read_bytes() == (REPO / 'scripts/tests/prepare_stability_published_guest.py').read_bytes()
actual_root = inventory(PREP / 'root')
assert actual_root == prepared['root_inventory'] and len(actual_root) == 63
baseline = SCRATCH / 'native-ultra-baseline-memory-guest-20260909-stability-service-failure-20260913-1'
actual_baseline = inventory(baseline / 'root')
assert actual_baseline == prepared['baseline_root_inventory'] and len(actual_baseline) == 55
data = gzip.decompress(identity(prepared['accepted_baseline_initramfs']))
position, cpio, names = 0, [], set()
while True:
    header = data[position:position + 110]
    assert header[:6] == b'070701' and len(header) == 110
    values = [int(header[6 + i * 8:14 + i * 8], 16) for i in range(13)]
    position += 110
    name_bytes = data[position:position + values[11]]
    assert name_bytes.endswith(b'\0') and b'\0' not in name_bytes[:-1]
    name = name_bytes[:-1].decode()
    position = (position + values[11] + 3) & ~3
    payload = data[position:position + values[6]]
    assert len(payload) == values[6]
    position = (position + values[6] + 3) & ~3
    if name == 'TRAILER!!!':
        assert not payload and not data[position:].strip(b'\0')
        break
    assert name not in names and not name.startswith('/') and '..' not in name.split('/')
    names.add(name)
    row = dict(path=name, mode=stat.S_IMODE(values[1]))
    assert values[2] == values[3] == values[12] == 0
    if stat.S_ISREG(values[1]):
        assert values[4] == 1
        row.update(kind='file', size=len(payload), sha256=digest(payload))
    elif stat.S_ISDIR(values[1]):
        assert not payload
        row['kind'] = 'directory'
    elif stat.S_ISLNK(values[1]):
        row.update(kind='symlink', target=payload.decode())
    else:
        assert stat.S_ISCHR(values[1]) and not payload
        assert (name, row['mode'], values[9], values[10]) in [('dev/console', 384, 5, 1), ('dev/null', 438, 1, 3)]
        continue
    cpio.append(row)
assert sorted(cpio, key=lambda item: item['path']) == actual_baseline and len(names) == 57
root_map = {row['path']: row for row in actual_root}
changed = [row['path'] for row in actual_baseline if root_map[row['path']] != row]
assert changed == ['init', 'modules/ihk-smp-x86_64.ko', 'modules/ihk.ko', 'modules/mcctrl.ko']
module = json.loads(identity(prepared['compiled_stack_readiness']['module_record']))
assert prepared['compiled_stack_readiness']['compiled_modules'] == module['compiled_modules']
assert prepared['module_compiler_bindings'] == module['retained_compiler_bindings'] and len(prepared['module_compiler_bindings']) == 63
compiler = {row['path']: row for row in module['compiler_inputs']}
for binding in prepared['module_compiler_bindings']:
    before, retained = compiler[binding['historical_compile_path']], binding['retained']
    assert (before['sha256'], before['size']) == (retained['sha256'], retained['size'])
    identity(retained)
client = json.loads((SCRATCH / 'stability-published-client-tests-20260913-1/record.json').read_bytes())
assert prepared['controller_compiler_bindings'] == client['compiler_dependencies']
assert len(prepared['controller_source_bindings']) == 2
for pair in prepared['controller_source_bindings'] + prepared['controller_compiler_bindings']:
    assert (pair['original']['sha256'], pair['original']['size']) == (pair['retained']['sha256'], pair['retained']['size'])
    identity(pair['retained'])
for binding in prepared['bindings']:
    target = identity(binding['prepared'])
    if 'original' in binding:
        source = identity(binding['original'])
        if source is not None:
            assert target == source
        else:
            assert digest(target) == binding['original']['sha256']
    else:
        assert all(digest(target) == row['sha256'] for row in binding['compiler_outputs'])
retained_records = []
for row in prepared['inputs']:
    if row['path'].endswith('/record.json'):
        target = PREP / 'input-records' / row['path'].lstrip('/')
        assert target.read_bytes() == identity(row)
        retained_records.append(str(target.relative_to(PREP)))
assert prepared['reused_owner_parser_validation']['passed_cases'] == 19 and prepared['reused_owner_parser_validation']['rerun'] is False
preparation = json.loads(identity(prepared['reused_owner_parser_validation']['preparation_record']))
prior = json.loads(identity(prepared['reused_owner_parser_validation']['reference']))
for suffix in ('scripts/tests/test_owner_observations.py', 'scripts/application-tests/owner_observations.py'):
    entries = [[row for row in doc['fixture_inputs'] if row['path'].endswith('/source/' + suffix)] for doc in (prior, preparation)]
    assert len(entries[0]) == len(entries[1]) == 1 and identity(entries[0][0]) == identity(entries[1][0])
proof = [item for item in prior['commands'] if item['label'] == 'owner-parser-tests']
assert len(proof) == 1 and proof[0]['collection']['raw_wait_status'] == 0 and proof[0]['collection']['cleanup_complete']
meta = HERE / 'preparation-records'
meta.mkdir()
for p in PREP.iterdir():
    if p.name == 'root':
        continue
    if p.is_dir():
        retain_tree(p, meta / p.name)
    else:
        (meta / p.name).write_bytes(p.read_bytes())
(meta / 'actual-init').write_bytes((PREP / 'root/init').read_bytes())
for source, name in [(Path('/tmp/stability-published-preparer-root-review-20260913-xvw4lydr'), 'preparer-root-source-review'), (Path('/tmp/stability-published-physical-independent-review-20260913-b86g2o2g'), 'physical-source-review'), (Path('/tmp/stability-selected-response-lifetime-review-20260913-6eqka4um'), 'current-lifetime-blocker')]:
    retain_tree(source, HERE / name)
publication = json.loads((REPO / 'docs/verification/stability-published-build-collection-20260913-1.json').read_bytes())
(HERE / 'original-publication.json').write_bytes((REPO / 'docs/verification/stability-published-build-collection-20260913-1.json').read_bytes())
published_archives = []
for source in (PHYS, PREP):
    captures = [item for item in publication['captures'] if item['source'] == '/work/' + str(source.relative_to(SCRATCH))]
    assert len(captures) == 1
    capture = captures[0]
    identity(capture['archive'])
    expected = {source.name: dict(kind='directory', mode=stat.S_IMODE(source.stat().st_mode))}
    for item in inventory(source):
        expected[source.name + '/' + item['path']] = item
    with tarfile.open(REPO / capture['archive']['path'], 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == capture['exact_tree_members'] == len(expected)
        assert {item.name for item in members} == set(expected)
        for member in members:
            item = expected[member.name]
            assert member.mode == item['mode']
            if item['kind'] == 'directory':
                assert member.isdir()
            elif item['kind'] == 'symlink':
                assert member.issym() and member.linkname == item['target']
            else:
                assert member.isfile()
                raw = tar.extractfile(member).read()
                assert len(raw) == item['size'] and digest(raw) == item['sha256']
    published_archives.append(capture)
assert (PHYS / 'record.json').read_bytes() == raw_phys and (PREP / 'record.json').read_bytes() == raw_prep
review = dict(status='RETAINED_PHYSICAL18_AND_PREPARATION_BINDINGS_MATCH_GUEST_BLOCKED',
    physical_record_sha256=digest(raw_phys), preparation_record_sha256=digest(raw_prep),
    physical=dict(test_methods=18, retained_calls=len(calls), returned=sum(item['observed'] == 'returned' for item in calls), raised_expected=sum(item['observed'] == 'raised' for item in calls), raw_wait_status=0, cleanup_complete=True, source_bindings=4, calls=calls),
    preparation=dict(root_entries=63, baseline_entries=55, baseline_newc_entries=57, inherited_changed=changed, module_compiler_bindings=63, controller_compiler_bindings=185, actual_root_inventory=actual_root, retained_input_records=retained_records, copy_bindings=24, original_owner_parser_tests=19, status=prepared['status'], guest_release_ready=False),
    verified_identity_occurrences=verified, unmapped_container_identity_occurrences=unmapped,
    existing_full_archives_independently_verified=published_archives,
    current_blocker='Selected response cancellation can bypass the eligible send wrapper; no-wake completion bypasses send entirely. The new SELECT-to-release retention profile is not implemented/validated in these exact binaries. PRE_INPUT physical ownership and published guest release remain blocked.',
    compiled_stack_scope='A later independently reviewed known-frame/chain record is available; the prepared record remains historically PENDING_ACTUAL_REVIEW. It is not a complete stack certificate and does not discharge the separate cancellation lifetime blocker.',
    limitations=['No QEMU initramfs or guest execution is claimed for this preparation; gzip/newc check covers only the inherited accepted baseline.', 'Container-only original library/header/tool references were not reopened on the host; retained compiler copies and prepared library bytes were checked against recorded identities.', 'Synthetic physical comparisons are byte-only, not actual ownership/capture/release or transport acceptance.'],
    subject_imports=False, subject_execution_by_reviewer=False, guest_execution=False, guest_release_ready=False, application_acceptance=False, transport_acceptance=False, production_gate_credit=False)
(HERE / 'review.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
print('PASS retained binding audit', len(verified), 'mapped;', len(unmapped), 'container-only identity occurrences')
print('physical calls', len(calls), 'returned', review['physical']['returned'], 'expected errors', review['physical']['raised_expected'])
print('review_sha256', digest((HERE / 'review.json').read_bytes()))
