from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, socket, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
compiled = Path('/work/native-sysfs-remote-module-20260907-' + sys.argv[1])
out = Path('/work/native-sysfs-remote-guest-20260907-' + sys.argv[2]); out.mkdir()
kernel = Path('/work/native-topology-kernel-20260907-1')
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', '/workspace', 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], commands=[], production_gate_credit=False, sysfs_service_completed=False,
    mckernel_boot_proven=False, declared_stage=False, cpus=4, memory_mib=8192,
    container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)))
process = None
stream = None

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command, env=None):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-6000:])

sequence = 0
def qmp(command):
    global sequence
    sequence += 1
    stream.write((json.dumps(dict(execute=command, id=sequence)) + '\n').encode()); stream.flush()
    while True:
        line = stream.readline()
        assert line, 'QMP disconnected'
        response = json.loads(line)
        if response.get('id') != sequence: continue
        assert 'error' not in response, response
        return response['return']

try:
    shutil.copyfile(__file__, out / 'helper.py')
    built = json.loads((compiled / 'record.json').read_text())
    assert built['status'] == 'PASS'
    for row in built['inputs'] + built['compiler_inputs'] + built['outputs']:
        assert identity(Path(row['path'])) == row, row
    record['inputs'] += [identity(compiled / 'record.json'), identity(kernel / 'bzImage')]
    root = out / 'root'
    base_root = Path('/work/native-runtime-local-base-24a151fe/root')
    record['inputs'] += [identity(path) for path in sorted(base_root.rglob('*')) if path.is_file()]
    shutil.copytree(base_root, root)
    copies = [(compiled / 'mckernel_sysfs_remote_verify.ko', root / 'modules/mckernel_sysfs_remote_verify.ko'),
              (Path('/usr/bin/sleep'), root / 'bin/sleep'),
              (compiled / 'native-sysfs-remote', root / 'bin/native-sysfs-remote'),
              (compiled / 'lib64/libc.so.6', root / 'lib64/libc.so.6'),
              (compiled / 'lib64/ld-linux-x86-64.so.2', root / 'lib64/ld-linux-x86-64.so.2')]
    for source, destination in copies:
        record['inputs'].append(identity(source)); shutil.copy2(source, destination)
    (root / 'init').write_text(Path('/work/native-sysfs-remote-guest-init.sh').read_text())
    record['inputs'] += [identity(Path('/work/native-sysfs-remote-guest-init.sh')), identity(compiled / 'native-sysfs-remote')]
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    generator = Path('/work/write-native-cpio-spec.py')
    record['inputs'].append(identity(generator))
    run('initramfs-spec', ['python3', '-B', str(generator)], dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root)))
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            creator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(creator.stdout, output); creator.stdout.close(); assert creator.wait() == 0
    record['inputs'] += [identity(out / 'initramfs.cpio.gz'), identity(root / 'init')]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
            '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(kernel / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args; save()
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20); connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            for bad in ['Call Trace:', 'MCKERNEL_SYSFS_REMOTE_GUEST_FAIL', 'REMOTE_USER_FAIL', 'Assertion ', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
                assert bad not in serial, bad
            if 'MCKERNEL_SYSFS_REMOTE_GUEST_PASS' in serial:
                qmp('quit'); process.wait(timeout=15); break
            state = qmp('query-status')
            assert state['status'] not in ('shutdown', 'guest-panicked'), state
            time.sleep(0.1)
        assert process.returncode == 0
    serial = (out / 'serial.log').read_text(errors='replace')
    assert serial.count('MCKERNEL_SYSFS_REMOTE_VERIFY READY files=9 duplicate_preserved=1')==2
    users=re.findall(r'MCKERNEL_SYSFS_REMOTE_USER_PASS parallel_roundtrips=256 requests=(\d+) retries=(\d+) interrupted=1 late_response=1 callback_drain=1 release_drain=1 boundaries=2 errors=4',serial)
    assert users==[('526','526'),('526','526')],users
    drains=re.findall(r'MCKERNEL_SYSFS_REMOTE_VERIFY DRAINED releases=9 requests=(\d+) retries=(\d+)',serial)
    assert drains==[('534','534'),('534','534')],drains
    assert serial.count('MCKERNEL_SYSFS_REMOTE_CYCLE_PASS=')==2
    for row in record['inputs']:assert identity(Path(row['path']))==row,row
    record.update(status='PASS',module_cycles=2,parallel_roundtrips=512,completed_exchanges=1068,
        forced_queue_full_retries=1068,interrupted_readers=2,late_response_ownership_checks=2,
        concurrent_callback_drains=2,remote_release_drains=18,boundary_checks=4,error_checks=8,
        namespace_removed=True,scope='Real Linux native sysfs callbacks and tree drain with an independent module-owned peer; no actual McKernel dispatch or OS memory-map claim')
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
    if stream is not None: stream.close()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name != 'record.json']
    save(); print(record['status'], out, flush=True)
