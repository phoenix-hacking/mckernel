"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Read-only actual SDK capacity/identity/image admission; no target, lease, container or cleanup entry.
"""
from pathlib import Path
import sys,json,hashlib,os,time
D=Path(__file__).parent
import importlib.util
assert len(sys.argv)==2
inputs_path=D/'QUERY-INPUTS.ROOT.json'
raw=inputs_path.read_bytes()
assert hashlib.sha256(raw).hexdigest()==sys.argv[1]
inputs=json.loads(raw)
assert set(inputs)=={'request','request_sha256'} and isinstance(inputs['request'],str)
request_path=Path(inputs['request'])
assert request_path.is_absolute() and request_path.parent==D.parent.parent
request_raw=request_path.read_bytes()
assert hashlib.sha256(request_raw).hexdigest()==inputs['request_sha256']
request=json.loads(request_raw)
assert request['request_path']==str(request_path)
OWNER=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/library_sdk_owner.py')
assert hashlib.sha256(OWNER.read_bytes()).hexdigest()=='6c75124bfdf870a703614f0560ba61b3658d27a0c85e7b94d0ce94e2a64a00b8'
spec=importlib.util.spec_from_file_location('library_sdk_admission_owner',OWNER)
owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
source_sha256={'scripts/native_exact_historical_lease_observer.py': '463ae558e141c2a6fe5a016fb19baddb26ed883c3bf6d39c114b27711ee78a51', 'scripts/native_running_external_modules_offline.py': 'ff90d5c36b6d1068f10377ba905b0646a4896dffee26193d5b3a00d5acff7e2f', 'scripts/native_running_external_modules_owner.py': '6c75124bfdf870a703614f0560ba61b3658d27a0c85e7b94d0ce94e2a64a00b8', 'scripts/native_rust_exact_build_container_owner.py': '96d17547bfc71454d54e95a705138cc9b26faa1e2cafc34105c9ed8d5a68f4d1', 'scripts/native_rust_exact_build_image_prepare.py': '45cb12e0fd58d164468badfb99a3ed922e65e06046bf38b4a50e27e18595a27b', 'scripts/native_rust_exact_build_image_rebind.py': 'f10ab116e55a24e8db7a8157d71efdd01198ba3453a8141bc8bbf596eda6b61e', 'scripts/native_rust_exact_build_image_rebind_probe.py': '412d46de7e078746a7ec979a13ccb25753d6fa34708610932e35be8f02a89635', 'scripts/native_rust_exact_build_offline.py': 'cc243126ab8cc0754c62175c77e46d6ba0d98294f8168cc77893a2c12249cd1a', 'scripts/native_rust_exact_disk_build_wrapper.py': 'c252ee341eb61752704f8b818503c0a5dc97400845494707ca3110f5f23df6d1', 'scripts/native_rust_exact_mckernel_image_container_owner.py': 'e9861cf73b0328c9fe2eacb987ea179933146cbeddbc3951405d4e60e89560f4', 'scripts/tests/test_native_running_external_modules_owner.py': 'c816f7dfd6fa167670876d8e64e8474bec119e1f19280fcc1cb902dff1a2c340'}
owner.validate_runtime_source_bindings(source_sha256)
# Distinct historical SDK normal retirement and current PREVALIDATION token clearance.
prior_sdk_normal_retirement={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-sdk-library-tool-FD-failure-postjoin-1/ROOT-RECORDED-INDEPENDENT-PHYSICAL-ACCEPTANCE.json', 'sha256': '4dedde1fc45dbcbddbf35f934e82c4f65bbed75417d9e3f13199d98ad7f7e123'}
prior_sdk_normal_postjoin={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-sdk-library-tool-FD-failure-postjoin-1/CURRENT-LIVE-POSTJOIN.json', 'sha256': '65e71cfbc9c36e1f795cfb2d7ee6b2d9a14361d70627629a09ebda163da9e0bd'}
prior=owner.bound(prior_sdk_normal_retirement)
prior_live=owner.bound(prior_sdk_normal_postjoin)
assert prior['status']=='PASS_ACTUAL_M15_SDK_LIBRARY_FAILED_BUILD_PHYSICAL_RETIREMENT'
assert prior['original_build_status']=='FAIL' and prior['artifact_native_acceptance'] is False
assert prior_live['physical_acceptance']==prior_sdk_normal_retirement
assert prior_live['status']=='PASS_CURRENT_LIVE_POSTJOIN_NONNULL'
current_token_clearance={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-copy5-reconciled-token-postjoin-1/ROOT-RECORDED-INDEPENDENT-PHYSICAL-ACCEPTANCE.json', 'sha256': '06779cc315a82b257236a0842262bf73ea5cd688ae11b3bb8a4ed2ef59867621'}
current_token_postjoin={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-copy5-reconciled-token-postjoin-1/CURRENT-LIVE-POSTJOIN.json', 'sha256': '419ebe58613034695f42eefa4cbf6325b4c04d05712c543ebbf664c5eeba6c72'}
clearance=owner.bound(current_token_clearance)
current_live=owner.bound(current_token_postjoin)
assert clearance['status']=='CLOSED_PREVALIDATION_SHARED_TOKEN_NORMAL_RECONCILIATION'
assert clearance['owner']=={'pid':189516,'starttime':'65397349'}
assert clearance['api_child']=={'pid':195301,'starttime':'65488487'}
assert clearance['build_status']=='FAIL_PRESERVED_STOPPED' and clearance['build_acceptance'] is False
assert clearance['current_live_postjoin_accepted_non_null'] is True
assert clearance['implementation_ownership'] is False and clearance['reviewer']=='/root/native235_release_review'
assert current_live['status']=='PASS_CURRENT_LIVE_POSTJOIN_NONNULL'
assert current_live['physical_acceptance']==current_token_clearance and current_live['shared_token_reconciled'] is True
assert current_live['original_build_status']=='FAIL_PRESERVED_STOPPED' and current_live['artifact_native_acceptance'] is False
expected_links={'api_result': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m14-retained-validator-continuation-1/copy4-readelf-stream-correction-1/retained49-copy5-successor-1/actual-bound-copy5-admission-preparation-1/latest-tool-FD-retirement-binding-1/prevalidation-shared-token-reconciliation-preparation-1/ACTUAL-RECONCILIATION-RESULT.json', 'sha256': '93670ec1830787aedc88e94da86bcbea98d2d6e5bd69656aad43cfcddb9600c4'}, 'api_whole_join': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-copy5-prevalidation-token-normal-api-reconciliation-1/WHOLE-JOIN.json', 'sha256': '9bc68106bbd92c32ce211dd3d0903aab41a1f3a835239292d55851954b6b1e79'}, 'proc_whole_join': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-copy5-reconciled-token-postjoin-1/0/WHOLE-JOIN.json', 'sha256': '03f268df0b7ba8a5e3c430e3ceb7b2e1b881f84dbf436b56567e336240e8012d'}, 'mutex_whole_join': {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-copy5-reconciled-token-postjoin-1/1/WHOLE-JOIN.json', 'sha256': '9bfa2c3ad91218f2b448fa44e4d3f08c2228ee1c7428f82bbcd275dcc24e9712'}}
for key,ref in expected_links.items():
    assert clearance[key]==ref
api_result=owner.bound(expected_links['api_result'])
assert api_result['status']=='PASS_NORMAL_API_PREFLIGHT_TOKEN_RECONCILIATION' and api_result['token_absent'] is True
assert api_result['physical_receipt_sha256']=='b787ad27b1c683ce4325cdff7a47042b660fca78cb79e8b965a86c1901f07004'
assert api_result['contract_sha256']=='c252ee341eb61752704f8b818503c0a5dc97400845494707ca3110f5f23df6d1'
assert api_result['permanent_mutex']==[27,4]
assert api_result['build_status']=='FAIL_PRESERVED_STOPPED' and api_result['build_acceptance'] is False
joined={};observed={}
for key in ('api_whole_join','proc_whole_join','mutex_whole_join'):
    join=owner.bound(expected_links[key])
    assert join['returncode']==0 and join['direct_child_joined'] and join['group_absent'] and join['closed_streams']
    assert join['error'] is None and join['retirement_error'] is None and join['timed_out'] is False
    assert join['remaining_group_members']==[] and join['unexpected_group_members']==[]
    err=join['captures']['stderr'];err_path=owner.safe_path(err['path'],False)
    assert err['size']==err_path.stat().st_size==0 and owner.host.digest(err_path)==err['sha256']
    out=join['captures']['stdout']
    observed[key]=owner.bound({'path':out['path'],'sha256':out['sha256']})
    joined[key]=join
assert joined['api_whole_join']['pid']==195301 and str(joined['api_whole_join']['start'])=='65488487'
assert observed['api_whole_join']==api_result
proc=observed['proc_whole_join']
assert proc['status']=='CURRENT_FAILED235_COMPLETE_PROC_OBSERVATION'
assert proc['proc']['schema']=='fp-save-image.proc.v2' and proc['proc']['status']=='COMPLETE'
assert proc['proc']['uid']==0 and proc['proc']['boot_id']==owner.BOOT
assert proc['proc']['failure'] is None and proc['proc']['publishers']==[] and len(proc['proc']['snapshots'])==2
assert all(not any(row[0] in (189516,195301) for row in sweep) for sweep in proc['proc']['snapshots'])
mutex=observed['mutex_whole_join']
assert mutex['status']=='PASS_CURRENT_FAILED235_27_4_AND_8_PATH_ABSENCE' and mutex['lock']==[27,4]
assert mutex['paths']==['/home/holden/mckernel-work/scratch/native-running-external-modules.lease.json', '/home/holden/mckernel-work/scratch/native-running-external-modules-operational-exclusion.json', '/home/holden/mckernel-work/scratch/native-exact-candidate-operational-exclusion-scratch18-image-1.json', '/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/p-m06-matched-guest-build-binding-20261022-1/full-image-attempt-1/lease.json', '/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/common-exclusion.json', '/home/holden/mckernel-work/host-preparation/current68-native235-production-binding-20261022-1/launcher-successor-1/driver-hash-correction-1/pinned-launcher-attempt-1/image-lease.json']
assert str(owner.shared.SHARED_HEAVY_LOCK_PATH)=='/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock'
assert not os.path.lexists(owner.shared.SHARED_HEAVY_LOCK_PATH)


# Latest SDK normal retirement follows the historical prevalidation token clearance above.
latest_sdk_retirement={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-sdk-library-missing-BFD-header-postjoin-1/ROOT-RECORDED-INDEPENDENT-PHYSICAL-ACCEPTANCE.json', 'sha256': '45f9a9cf1ebf8426efda5e02358e16b34a6aa52599074a5f83b08cf4ab4936aa'}
latest_sdk_postjoin={'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/root-sdk-library-missing-BFD-header-postjoin-1/CURRENT-LIVE-POSTJOIN.json', 'sha256': 'b69550a33eca07368bad03fdedb1909c2c461996fb49b61eb66a5584ac1576d0'}
latest=owner.bound(latest_sdk_retirement)
latest_live=owner.bound(latest_sdk_postjoin)
assert latest['status']=='PASS_ACTUAL_M15_SDK_LIBRARY_FAILED_BUILD_PHYSICAL_RETIREMENT'
assert latest['owner']=={'pid':198637,'starttime':'65544028'}
assert latest['original_build_status']=='FAIL' and latest['artifact_native_acceptance'] is False
assert latest['implementation_ownership'] is False and latest['reviewer']=='/root/native235_release_review'
assert latest_live['status']=='PASS_CURRENT_LIVE_POSTJOIN_NONNULL' and latest_live['physical_acceptance']==latest_sdk_retirement
assert latest_live['original_build_status']=='FAIL' and latest_live['artifact_native_acceptance'] is False
latest_owner=owner.bound(latest['owner_stdout'])
assert latest_owner['status']=='FAIL' and latest_owner['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE'
assert latest_owner['retired'] is True and latest_owner['cleanup_separately_required'] is False
for key in ('proc_whole_join','mutex_whole_join'):
    join=owner.bound(latest[key])
    assert join['returncode']==0 and join['direct_child_joined'] and join['group_absent'] and join['closed_streams']
    assert join['error'] is None and join['retirement_error'] is None and join['timed_out'] is False
    assert join['remaining_group_members']==[] and join['unexpected_group_members']==[]
    err=join['captures']['stderr'];err_path=owner.safe_path(err['path'],False)
    assert err['size']==err_path.stat().st_size==0 and owner.host.digest(err_path)==err['sha256']
    out=join['captures']['stdout'];value=owner.bound({'path':out['path'],'sha256':out['sha256']})
    if key=='proc_whole_join':
        assert latest['proc_stdout']=={'path':out['path'],'sha256':out['sha256']}
        assert value['proc']['schema']=='fp-save-image.proc.v2' and value['proc']['status']=='COMPLETE'
        assert value['proc']['uid']==0 and value['proc']['boot_id']==owner.BOOT
        assert value['proc']['failure'] is None and value['proc']['publishers']==[] and len(value['proc']['snapshots'])==2
        assert all(not any(row[0]==198637 for row in sweep) for sweep in value['proc']['snapshots'])
    else:
        assert value['status']=='PASS_CURRENT_FAILED235_27_4_AND_8_PATH_ABSENCE' and value['lock']==[27,4]
        assert value['paths']==mutex['paths']
selected_image_receipt={'path': '/home/holden/mckernel-exact-image-evidence-942c927b-scratch22-authority3-image1-20261017/image-receipt.json', 'sha256': '352102798e60bfcf8a72facded532430a93ba30f949a55e1d8eaf54a2f351550'}
image_authority=owner.bound(selected_image_receipt)
assert image_authority['status']=='PASS' and image_authority['retired'] is True
assert image_authority['image_id']==owner.IMAGE==request['image_id']=='sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5'
assert image_authority['source_free'] is True and image_authority['runtime_network']=='none'
assert image_authority['candidate_sha']==owner.CANDIDATE
assert image_authority['packages']['binutils-devel']=='binutils-devel-0:2.41-63.el10.x86_64'
assert image_authority['tools']['cc']['sha256']==owner.LIBRARY_PREPARATION['target_tools']['/usr/bin/cc']
bfd=image_authority['libraries']['libbfd']
assert bfd['headers']['/usr/include/bfd.h']['sha256']==owner.LIBRARY_PREPARATION['target_tools']['/usr/include/bfd.h']
assert bfd['linker']['sha256']==owner.LIBRARY_PREPARATION['target_tools']['/usr/lib64/libbfd.so']

owner.output_namespace(request)
mount=owner.live_admission(request);capacity=owner.measure(request)
conflicts={owner.LEASE,owner.COMMON,Path(owner.shared.SHARED_HEAVY_LOCK_PATH),Path(owner.image.COMMON_EXCLUSION),Path(owner.host.OPERATIONAL_EXCLUSION_PATH)}
conflicts.update(owner.ROOT.glob('native-exact-mckernel-image-lease-*.json'))
assert not any(os.path.lexists(p) for p in conflicts)
E=D/'root-readonly-admission-preview-1';E.mkdir(mode=0o700)
with owner.DeferredSignals() as latch:
 client=owner.ExternalDocker(E/'image-inspect.log',latch,sudo=True)
 result=client.call(['image','inspect',request['image_id']],timeout=15)
 assert result.returncode==0 and not client.client_retirement_unproven
 info=json.loads(result.stdout);assert len(info)==1 and info[0]['Id']==request['image_id'] and info[0]['Architecture']=='amd64'
 client.check_all_client_groups();assert not client.client_retirement_unproven
summary=dict(scope=__doc__,status='PASS_READONLY_SDK_CAPACITY_IDENTITY_IMAGE_ONLY',at=time.time(),request_sha256=inputs['request_sha256'],resources=capacity,mount=mount,image_id=info[0]['Id'],image_Architecture=info[0]['Architecture'],group_checks=client.group_checks,conflict_paths_absent=[str(p) for p in sorted(conflicts)],current_physical_acceptance=latest_sdk_retirement['sha256'],current_postjoin=latest_sdk_postjoin['sha256'],current_clearance_scope='PASS_ACTUAL_M15_SDK_LIBRARY_FAILED_BUILD_PHYSICAL_RETIREMENT',historical_token_clearance=current_token_clearance,historical_token_postjoin=current_token_postjoin,selected_image_receipt=selected_image_receipt,prior_sdk_normal_retirement=prior_sdk_normal_retirement,prior_sdk_normal_postjoin=prior_sdk_normal_postjoin,reconciliation_links=expected_links,target_calls=0,container_create_calls=0,execution_release=False)
(E/'ADMISSION.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(status=summary['status'],at=summary['at'],resources=capacity,image=info[0]['Id'],target_calls=0)))
