"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure fake FD vectors execute exact retained helper and pre/post loop AST; no tool process.
"""
from pathlib import Path
import ast
import hashlib
import os
import stat
import types
import unittest

SOURCE = Path(__file__).with_name('library_sdk_driver.py')
TREE = ast.parse(SOURCE.read_bytes())
FUNCTIONS = {'need', 'digest', 'tool_digest'}
NODES = [n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name in FUNCTIONS or
         isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'TOOL_RULES' for t in n.targets)]
PRE_START = next(i for i, n in enumerate(TREE.body) if isinstance(n, ast.Assign) and
                 any(isinstance(t, ast.Name) and t.id == 'tool_aliases' for t in n.targets))
PRE_END = next(i for i, n in enumerate(TREE.body[PRE_START:], PRE_START) if isinstance(n, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == 'h' for t in n.targets))
POST = next(n for n in ast.walk(TREE) if isinstance(n, ast.For) and
            isinstance(n.iter, ast.Call) and isinstance(n.iter.func, ast.Attribute) and
            isinstance(n.iter.func.value, ast.Name) and n.iter.func.value.id == 'tool_input_preflight')
FIELDS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')

class FakePath:
    def __init__(self, backend, value):
        self.backend = backend
        self.value = str(value)
    def __str__(self):
        return self.value
    def __eq__(self, other):
        return isinstance(other, FakePath) and self.value == other.value
    def resolve(self, strict):
        assert strict
        self.backend.resolve_count += 1
        if self.backend.missing:
            raise FileNotFoundError(self.value)
        return FakePath(self.backend, '/resolved/tool' + ('-moved' if self.backend.retarget and self.backend.resolve_count % 2 == 0 else ''))
    def lstat(self):
        return types.SimpleNamespace(**self.backend.named)

class FakeFD:
    def __init__(self):
        self.body = b'abc'
        self.first = dict(zip(FIELDS, (9, 17, 0, 0, stat.S_IFREG | 0o755, 2, 3, 100, 101)))
        self.last = dict(self.first)
        self.named = dict(self.first)
        self.closed = []
        self.opened = []
        self.position = 0
        self.fstats = 0
        self.resolve_count = 0
        self.retarget = self.missing = self.read_error = False
    def open(self, path, flags):
        self.opened.append((str(path), flags))
        return 7
    def fstat(self, fd):
        assert fd == 7
        self.fstats += 1
        return types.SimpleNamespace(**(self.first if self.fstats % 2 else self.last))
    def read(self, fd, size):
        assert fd == 7 and size == 65536
        if self.read_error:
            raise OSError('injected read error')
        data = self.body[self.position:self.position + size]
        self.position += len(data)
        return data
    def close(self, fd):
        self.closed.append(fd)
    def reset(self):
        self.position = self.fstats = self.resolve_count = 0

class ToolFDTests(unittest.TestCase):
    def setUp(self):
        self.fd = FakeFD()
        fake_os = types.SimpleNamespace(**{k: getattr(os, k) for k in ('O_RDONLY', 'O_NOFOLLOW', 'O_NONBLOCK', 'O_CLOEXEC')})
        for name in ('open', 'fstat', 'read', 'close'):
            setattr(fake_os, name, getattr(self.fd, name))
        self.ns = dict(Path=lambda v: FakePath(self.fd, v), os=fake_os, stat=stat, hashlib=hashlib)
        exec(compile(ast.Module(body=NODES, type_ignores=[]), str(SOURCE), 'exec'), self.ns)
        self.real_rules = dict(self.ns['TOOL_RULES'])
        expected = hashlib.sha256(self.fd.body).hexdigest()
        self.ns['TOOL_RULES'] = {q: (r[0], expected) for q, r in self.real_rules.items()}
    def call(self, alias='/usr/bin/cc'):
        self.fd.reset()
        return self.ns['tool_digest'](alias)
    def test_fixed_real_alias_classes_and_hashes(self):
        self.assertEqual(self.real_rules, {
            '/usr/bin/cc': ('readonly-image', '2092e32fa9abee9ccbf777a5f893b9cc608582b660c93e742a17c3eb7da109c2'),
            '/usr/include/bfd.h': ('readonly-image', 'de900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432'),
            '/usr/lib64/libbfd.so': ('readonly-image', '6cfd31804974c248c9512879e7b77a94862f92150c2171d901140464ea936ab3'),
            '/nightly/bin/rustc': ('readonly-mounted-nightly', '70ebcbbaa352a2d0ef5401eea226b0e61320840430b5c15ad016fb3dc8b54e09')})
    def test_image_multiple_links_and_open_flags(self):
        for alias in list(self.real_rules)[:3]:
            with self.subTest(alias=alias):
                result = self.call(alias)
                self.assertEqual(result['first_metadata']['st_nlink'], 2)
                self.assertEqual(result['first_metadata'], result['final_metadata'])
                self.assertEqual(result['final_metadata'], result['path_metadata'])
                self.assertEqual(self.fd.opened[-1][1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
                self.assertEqual(self.fd.closed[-1], 7)
    def test_nightly_singlelink_only(self):
        with self.assertRaisesRegex(RuntimeError, '/nightly/bin/rustc.*st_nlink.*regular/link'):
            self.call('/nightly/bin/rustc')
        for record in (self.fd.first, self.fd.last, self.fd.named):
            record['st_nlink'] = 1
        self.assertEqual(self.call('/nightly/bin/rustc')['tool_class'], 'readonly-mounted-nightly')
    def test_regular_and_positive_image_links(self):
        for key, value in [('st_mode', stat.S_IFDIR | 0o755), ('st_nlink', 0)]:
            with self.subTest(key=key):
                saved = self.fd.first[key]
                self.fd.first[key] = value
                with self.assertRaisesRegex(RuntimeError, 'regular/link'):
                    self.call()
                self.fd.first[key] = saved
    def test_each_fd_metadata_change_refused(self):
        for key in FIELDS:
            with self.subTest(field=key):
                self.fd.last = dict(self.fd.first)
                self.fd.last[key] += 1
                with self.assertRaisesRegex(RuntimeError, 'stable fixed tool'):
                    self.call()
    def test_named_path_replacement_refused(self):
        self.fd.named['st_ino'] += 1
        with self.assertRaisesRegex(RuntimeError, 'stable fixed tool'):
            self.call()
    def test_alias_retarget_and_hash_mismatch_refused(self):
        self.fd.retarget = True
        with self.assertRaisesRegex(RuntimeError, 'retargeted'):
            self.call()
        self.fd.retarget = False
        self.ns['TOOL_RULES']['/usr/bin/cc'] = ('readonly-image', '0' * 64)
        with self.assertRaisesRegex(RuntimeError, 'pinned tool hash'):
            self.call()
    def test_read_error_closes_and_names_alias_target_metadata(self):
        self.fd.read_error = True
        with self.assertRaisesRegex(RuntimeError, r'alias=/usr/bin/cc target=/resolved/tool.*st_nlink.*injected read'):
            self.call()
        self.assertEqual(self.fd.closed, [7])
    def test_unknown_and_missing_alias_do_not_open(self):
        with self.assertRaisesRegex(RuntimeError, 'fixed tool alias required'):
            self.call('/usr/bin/other')
        self.fd.missing = True
        with self.assertRaisesRegex(RuntimeError, 'alias=/usr/bin/cc target=None'):
            self.call()
        self.assertEqual(self.fd.opened, [])
    def test_tool_size_cap_and_short_read_refused(self):
        self.fd.body = b'x' * ((32 << 20) + 1)
        with self.assertRaisesRegex(RuntimeError, 'bounded tool hash'):
            self.call()
        self.fd.body = b'a'
        with self.assertRaisesRegex(RuntimeError, 'stable fixed tool'):
            self.call()
    def test_generic_digest_still_refuses_multiple_links(self):
        with self.assertRaisesRegex(RuntimeError, 'regular singlelink source'):
            self.ns['digest']('/source')
        self.assertEqual(self.fd.closed, [7])
    def test_actual_pre_post_loops_match_identity_and_refuse_drift(self):
        for record in (self.fd.first, self.fd.last, self.fd.named):
            record['st_nlink'] = 1
        def resetting(alias):
            return self.call(alias)
        self.ns['tool_digest'] = resetting
        # Execute the exact helper under a separate reference to avoid recursion.
        helper_ns = dict(self.ns)
        exec(compile(ast.Module(body=[n for n in NODES if isinstance(n, ast.FunctionDef) and n.name == 'tool_digest'], type_ignores=[]), str(SOURCE), 'exec'), helper_ns)
        def real_resetting(alias):
            self.fd.reset()
            return helper_ns['tool_digest'](alias)
        self.ns['tool_digest'] = real_resetting
        self.ns['prep'] = {'target_tools': {q: v[1] for q, v in self.ns['TOOL_RULES'].items()}}
        exec(compile(ast.Module(body=TREE.body[PRE_START:PRE_END], type_ignores=[]), str(SOURCE), 'exec'), self.ns)
        exec(compile(ast.Module(body=[POST], type_ignores=[]), str(SOURCE), 'exec'), self.ns)
        self.assertEqual(self.ns['tool_input_preflight'], self.ns['tool_input_postflight'])
        for record in (self.fd.first, self.fd.last, self.fd.named):
            record['st_ino'] += 1
        with self.assertRaisesRegex(RuntimeError, 'same pinned tool alias/identity postflight'):
            exec(compile(ast.Module(body=[POST], type_ignores=[]), str(SOURCE), 'exec'), self.ns)

if __name__ == '__main__':
    unittest.main(verbosity=2)
