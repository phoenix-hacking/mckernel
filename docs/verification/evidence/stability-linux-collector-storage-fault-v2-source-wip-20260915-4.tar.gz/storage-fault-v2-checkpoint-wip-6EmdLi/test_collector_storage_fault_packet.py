import copy
import hashlib
import importlib.util
import json
import os
import struct
import subprocess
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = (Path(__file__).resolve().parent /
        "fixtures/application-collector-v1/linux-sealed-v1/storage-fault-v1")
ROOT_ARCHIVE = (Path(__file__).resolve().parents[2] / "docs/verification/evidence/"
    "stability-linux-collector-root-success-20260915-2.tar.gz")
ROOT_PREFIX = ("stability-linux-sealed-root-tests-20260913-2/work/cases/"
               "stdin-devnull/inputs/")

def retained(name):
    with tarfile.open(ROOT_ARCHIVE, "r:gz") as archive:
        return archive.extractfile(ROOT_PREFIX + name).read()

def module(name):
    spec = importlib.util.spec_from_file_location("storage_fault_v2_" + name,
                                                  HERE / (name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

prepare = module("prepare")
oracle = module("oracle")
owner = module("witness_owner")

class StorageFaultV2SourceTests(unittest.TestCase):
    SOURCE_SHA = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
    COUNTS = [21, 10, 17, 21, 16, 21, 17]
    WAITS = [0, 256, 256, 256, 32000, 32000, 32000]
    PHASES = ["post-fork", "pre-fork", "pre-fork", "post-fork",
              "post-fork", "post-fork", "pre-fork"]
    HASHES = {"generated_sha256": "a" * 64,
              "header_sha256": "b" * 64, "elf_sha256": "c" * 64}
    NONCE = "d" * 32

    def setUp(self):
        self.paths = [HERE / name for name in (
            "packet.json", "prepare.py", "inject.h", "collector.patch",
            "oracle.py", "witness_owner.py", "tests.md")]
        self.paths += [HERE.parent / "collector.c"]
        self.hashes = {path: hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in self.paths}

    def tearDown(self):
        self.assertEqual({path: hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in self.paths}, self.hashes)

    def test_packet_source_and_exact_generated_diff(self):
        record = prepare.packet((HERE / "packet.json").resolve())
        self.assertEqual([case["selector"] for case in record["cases"]],
                         list(range(7)))
        self.assertEqual([case["witness_packets"] for case in record["cases"]],
                         self.COUNTS)
        self.assertTrue(all(count < 32 for count in self.COUNTS))
        raw = prepare.read(prepare.SOURCE)
        self.assertEqual(hashlib.sha256(raw).hexdigest(), self.SOURCE_SHA)
        generated = prepare.generate(raw)
        patch = prepare.diff(raw, generated)
        self.assertEqual(patch, (HERE / "collector.patch").read_bytes())
        self.assertEqual(generated.count(b'#include "storage-fault-v1/inject.h"'), 1)
        for token, count in {
            b"sf_open(SF_EVENTS_CREATE": 1,
            b"sf_write(SF_REQUEST": 1,
            b"sf_sync(SF_REQUEST_SYNC": 1,
            b"sf_open(SF_REPORT_CREATE": 1,
            b"sf_flush(fd, f)": 1,
            b"sf_sync(SF_REPORT_SYNC": 1,
            b"sf_observe_reap": 1,
            b"sf_observe_eof": 1,
            b"sf_observe_cleanup_ready": 1,
            b"sf_observe_cleanup_final": 1,
            b"sf_startup()": 1,
            b"sf_child_close()": 1,
        }.items():
            self.assertEqual(generated.count(token), count, token)
        self.assertNotIn(b"#define open", generated)
        self.assertNotIn(b"#define write", generated)
        self.assertNotIn(b"#define fsync", generated)
        with self.assertRaisesRegex(ValueError, "collector hash"):
            prepare.generate(raw + b"\n")

    def test_header_protocol_and_target_only_contract(self):
        header = (HERE / "inject.h").read_text()
        for token in (
            "M02_STORAGE_FAULT_TEST_ONLY != 1", "M02_STORAGE_FAULT_CASE > 6",
            "SF_WITNESS_FD 198", "SF_PACKET_MAX 4096", "SF_PACKET_LIMIT 32",
            '"RELEASE %s\\n"', '"ACK %s %u\\n"', "packet_sequence",
            "deadline - now", "sf_sequence = 1",
            "sf_acquisition_next", "sf_open_stat_valid", "SOCK_SEQPACKET",
            "sf_observe_reap", "sf_observe_eof", "sf_observe_cleanup_ready",
            "sf_observe_cleanup_final", "sf_transport_failed"):
            self.assertIn(token, header)
        self.assertEqual(header.count("static int sf_open("), 1)
        self.assertEqual(header.count("static ssize_t sf_write("), 1)
        self.assertEqual(header.count("static int sf_sync("), 1)
        self.assertEqual(header.count("static int sf_flush("), 1)
        self.assertNotIn("#define open", header)
        self.assertNotIn("#define write", header)
        self.assertNotIn("#define fsync", header)

    def test_prepare_fresh_root_durability_and_stable_rejection(self):
        unexpected = RuntimeError("execution forbidden")
        with tempfile.TemporaryDirectory() as temporary, \
             mock.patch.object(subprocess, "run", side_effect=unexpected) as run_call, \
             mock.patch.object(subprocess, "Popen", side_effect=unexpected) as popen_call, \
             mock.patch.object(owner, "launch", side_effect=unexpected) as launch_call:
            root = (Path(temporary) / "attempt").resolve()
            result = prepare.prepare((HERE / "packet.json").resolve(), root)
            self.assertEqual(result["status"], "PREPARED_NOT_BUILT")
            self.assertFalse(result["backend_enabled"] or result["application_acceptance"])
            expected = {"source.collector.c", "storage-fault-v2-collector.c",
                        "inject.h", "generated.diff", "prepare.json"}
            self.assertEqual({path.name for path in root.iterdir()}, expected)
            before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in root.iterdir()}
            with self.assertRaisesRegex(FileExistsError, "attempt root exists"):
                prepare.prepare((HERE / "packet.json").resolve(), root)
            self.assertEqual({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in root.iterdir()}, before)
            run_call.assert_not_called()
            popen_call.assert_not_called()
            launch_call.assert_not_called()

    def packet(self, selector, sequence, kind, phase=None, **extra):
        hashes = getattr(self, "active_hashes", self.HASHES)
        value = {"schema_version": 2, "nonce": self.NONCE,
                 "selector": selector, "sequence": sequence, "kind": kind,
                 "phase": phase or self.PHASES[selector],
                 "monotonic_ns": 1000 + sequence,
                 "site": "startup" if kind == "READY" else "observation",
                 "object": "collector", "occurrence": 0,
                 "collector_pid": 50,
                 "collector_startticks": 60, "source_sha256": self.SOURCE_SHA,
                 "generated_sha256": hashes["generated_sha256"],
                 "header_sha256": hashes["header_sha256"],
                 "elf_sha256": hashes["elf_sha256"]}
        value.update(extra)
        return value

    def packets(self, selector, report_size=128):
        def pair(site, object_name, occurrence=1):
            return [("BEFORE", site, object_name, occurrence),
                    ("AFTER", site, object_name, occurrence)]
        e, w1, w2 = pair("events-create", "events.jsonl"), \
            pair("request-write", "request.bin"), pair("request-write", "request.bin", 2)
        eb = [("BIND", "events-create", "events.jsonl", 1)]
        a, r = pair("request-sync", "request.bin"), pair("report-create", "report.json")
        rb = [("BIND", "report-create", "report.json", 1)]
        f, s = pair("report-flush", "report.json"), pair("report-sync", "report.json")
        observations = [("REAP", "reap", "leader", 1),
            ("EOF", "pump", "stdout", 1), ("EOF", "pump", "stderr", 2),
            ("EOF", "pump", "setup", 3),
            ("CLEANUP_READY", "cleanup", "owned-tree", 1),
            ("CLEANUP_FINAL", "cleanup", "owned-tree", 1)]
        body = {0:e+eb+w1+observations+a+r+rb+f+s, 1:e+r+rb+f+s,
            2:e+eb+w1+w2+a+r+rb+f+s, 3:e+eb+w1+observations+a+r+rb+f+s,
            4:e+eb+w1+observations+a+r, 5:e+eb+w1+observations+a+r+rb+f+s,
            6:e+eb+w1+w2+a+r+rb+f+s}[selector]
        signatures = [("READY", "startup", "collector", 0)] + body
        values, request_size = [], 0
        stat_ids = {"events.jsonl": (10, 100), "request.bin": (11, 101),
                    "report.json": (12, 102)}
        def stat_value(object_name, size):
            return {"dev": 1, "ino": stat_ids[object_name][1],
                    "mode": 0o100600, "size": size}
        for kind, site, object_name, occurrence in signatures:
            phase = "pre-fork" if kind == "READY" or site in (
                "events-create", "request-write") or selector in (1, 2, 6) \
                else "post-fork"
            extra = {"site": site, "object": object_name, "occurrence": occurrence}
            if kind in ("BEFORE", "AFTER") and site in ("events-create", "report-create"):
                failed = (site == "events-create" and selector == 1) or \
                         (site == "report-create" and selector == 4)
                acquisition = 1 if site == "events-create" or selector == 1 else 2
                extra.update({"dirfd": 5, "dir_stat": {"dev": 1, "ino": 90,
                    "mode": 0o40700, "size": 0}})
                if kind == "BEFORE":
                    extra.update({"fd": None, "target_stat": None,
                        "acquisition_id": None, "return": None,
                        "errno_authoritative": False, "errno": None})
                elif failed:
                    extra.update({"fd": None, "target_stat": None,
                        "acquisition_id": None, "return": -1,
                        "errno_authoritative": True, "errno": 28})
                else:
                    fd = stat_ids[object_name][0]
                    extra.update({"fd": fd, "target_stat": stat_value(object_name, 0),
                        "acquisition_id": acquisition, "return": fd,
                        "errno_authoritative": False, "errno": None})
            elif kind == "BIND":
                acquisition = 1 if site == "events-create" or selector == 1 else 2
                fd = stat_ids[object_name][0]
                extra.update({"acquisition_id": acquisition, "old_fd": fd,
                    "old_stat": stat_value(object_name, 0), "new_fd": fd,
                    "new_stat": stat_value(object_name, 0)})
            elif site == "request-write":
                requested = 406 if occurrence == 1 else 399
                before_size = 0 if occurrence == 1 else 7
                injected = selector in (2, 6)
                result = 7 if injected and occurrence == 1 else -1 if occurrence == 2 else 406
                after_size = 7 if injected else 406
                extra.update({"fd": 11, "target_stat": stat_value("request.bin",
                    before_size if kind == "BEFORE" else after_size),
                    "acquisition_id": 0, "requested_bytes": requested,
                    "return": None if kind == "BEFORE" else result,
                    "errno_authoritative": kind == "AFTER" and result < 0,
                    "errno": 28 if kind == "AFTER" and result < 0 else None})
                if kind == "AFTER":
                    extra["actual_bytes"] = max(result, 0); request_size = after_size
            elif site in ("request-sync", "report-flush", "report-sync"):
                is_request = site == "request-sync"
                size = request_size if is_request else (0 if kind == "BEFORE" and
                    site == "report-flush" else report_size)
                failed = kind == "AFTER" and ((site == "request-sync" and selector in (3, 6)) or
                    (site == "report-sync" and selector in (5, 6)))
                extra.update({"fd": 11 if is_request else 12,
                    "target_stat": stat_value("request.bin" if is_request else "report.json", size),
                    "acquisition_id": 0 if is_request else (1 if selector == 1 else 2),
                    "return": None if kind == "BEFORE" else (-1 if failed else 0),
                    "errno_authoritative": failed, "errno": 5 if failed else None})
            elif kind == "REAP":
                extra.update({"pid": 70, "startticks": 80, "raw_wait_status": 0})
            elif kind == "EOF":
                extra["closed_fd"] = 20 + occurrence
            elif kind == "CLEANUP_READY":
                extra.update({"waitid_return": -1, "waitid_errno": 10,
                    "leader_reaped": True, "stdout_eof": True,
                    "stderr_eof": True, "setup_eof": True})
            elif kind == "CLEANUP_FINAL":
                extra.update({"cleanup_start_ns": 100,
                    "cleanup_deadline_ns": 15000000100,
                    "cleanup_finished_ns": 200, "cleanup_complete": True,
                    "group_pinned": True, "owned_count": 0,
                    "owned_records_omitted": 0, "first_failure": "none",
                    "first_failure_errno": 0})
            values.append(self.packet(selector, len(values), kind, phase=phase, **extra))
        self.assertEqual(len(values), self.COUNTS[selector])
        return values

    def write_fixture(self, root, selector):
        root.mkdir()
        collection = root / "collection"
        collection.mkdir()
        report_status = oracle.EXPECTED[selector]
        retained_root = root / "retained-inputs"; retained_root.mkdir()
        original_request = retained("request.bin")
        selected = retained("selected-inputs.json")
        stimulus = retained("fixture")
        (retained_root / "request.bin").write_bytes(original_request)
        (retained_root / "selected-inputs.json").write_bytes(selected)
        (retained_root / "fixture").write_bytes(stimulus)
        source = root / "collector.c"; source.write_bytes(prepare.SOURCE.read_bytes())
        generated = root / "generated.c"; generated.write_bytes(b"synthetic generated source\n")
        header = root / "inject.h"; header.write_bytes((HERE / "inject.h").read_bytes())
        elf = root / "collector.elf"; elf.write_bytes(b"synthetic collector ELF\n")
        self.active_hashes = {"generated_sha256": hashlib.sha256(generated.read_bytes()).hexdigest(),
            "header_sha256": hashlib.sha256(header.read_bytes()).hexdigest(),
            "elf_sha256": hashlib.sha256(elf.read_bytes()).hexdigest()}
        post = selector in (0, 3, 4, 5)
        setup_values = ([827081537, 1, 1, 1, 0, 70, 50, 70, 70,
            0, 0, 0, 0, 1, 0, 0o22, 1, 300, 0o20666, 1, 203,
            0o10600, 1, 301, 0o10600, 1, 302, 1, 202, 15, 0,
            0, 1, 1, 0, 0, 0, 1] + [0] * 10) if post else [0] * 48
        if report_status[2] != "absent":
            def report_stat(mode=0o100600, size=0, inode=201):
                return {"device": 1, "inode": inode, "mode": mode, "uid": 0,
                    "gid": 0, "size": size, "nlink": 1, "mtime_seconds": 1,
                    "mtime_nanoseconds": 2, "ctime_seconds": 1,
                    "ctime_nanoseconds": 2}
            def sink(name=None, seen=0, stored=0, io_error=False, raw=b""):
                if name is None:
                    return None
                limits = {"request.bin": 65537, "selected-inputs.bin": 4194304,
                    "argv.nul": 65536, "env.nul": 65536, "events.jsonl": 65536,
                    "executable.verified.bin": 1048576, "stdout.bin": 65536,
                    "stderr.bin": 65536, "setup.bin": 768}
                return {"attempted_name": name, "created": True,
                    "fd_available": True, "creation_errno": 0, "fd_errno": 0,
                    "path": name, "limit_bytes": limits[name],
                    "seen_bytes": seen, "stored_bytes": stored,
                    "truncated": False, "io_error": io_error,
                    "sha256": hashlib.sha256(raw).hexdigest()}
            def failed_sink(name, error):
                return {"attempted_name": name, "created": False,
                    "fd_available": False, "creation_errno": error,
                    "fd_errno": 0, "path": None, "limit_bytes": 65536,
                    "seen_bytes": 0, "stored_bytes": 0, "truncated": False,
                    "io_error": False, "sha256": None}
            def source_record(opened):
                return {"opened": opened, "stable": opened, "verified": opened,
                    "source_before": report_stat(mode=0o100755,
                        size=len(stimulus), inode=201) if opened else None,
                    "source_after": report_stat(mode=0o100755,
                        size=len(stimulus), inode=201) if opened else None,
                    "sealed_backing": report_stat(mode=0o100500,
                        size=len(stimulus), inode=202) if opened else None,
                    "requested_memfd_flags": 3, "seals": 15 if opened else 0,
                    "artifact": sink("executable.verified.bin", len(stimulus),
                        len(stimulus), False, stimulus) if opened else None}
            request_valid = selector not in (1, 2, 6)
            request_bytes = oracle.PREFIX if selector in (2, 6) else original_request
            request_sink = None if selector == 1 else sink("request.bin", 406,
                len(request_bytes), selector in (2, 6), request_bytes)
            artifacts = [request_sink, sink("selected-inputs.bin") if request_valid else None,
                sink("argv.nul") if request_valid else None,
                sink("env.nul") if request_valid else None,
                failed_sink("events.jsonl", 28) if selector == 1
                    else sink("events.jsonl"),
                sink("executable.verified.bin", len(stimulus), len(stimulus),
                    False, stimulus) if post else None, None,
                sink("stdout.bin") if post else None,
                sink("stderr.bin") if post else None,
                sink("setup.bin") if post else None]
            desired = None if not request_valid else {"role": 1,
                "request_profile": 1, "uid": 0, "gid": 0, "group": 0,
                "umask": 18, "argc": 2, "envc": 0, "stdin_mode": 0,
                "case_id_hex": "696e6672617374727563747572652e636f6c6c6563746f72",
                "source_selector_hex": "2f776f726b2f63617365732f737464696e2d6465766e756c6c2f696e707574732f66697874757265",
                "cwd_hex": "2f776f726b2f63617365732f737464696e2d6465766e756c6c2f637764",
                "stdin_selector_hex": "2f6465762f6e756c6c",
                "attempt_id_hex": "b9e7824e46f727250a6a80c8fcfc9359",
                "selected_inputs_sha256": oracle.SELECTED_SHA}
            report = {"schema_version": 1,
                "kind": "linux-sealed-infrastructure-collection",
                "collector_mode": "linux-sealed-infrastructure-v1",
                "status": report_status[3], "first_failure": report_status[4],
                "first_failure_errno": report_status[5],
                "application_acceptance": False, "transport_acceptance": False,
                "backend_enabled": False, "collector_pid": 50,
                "request_valid": request_valid, "child_created": post,
                "linux_child": {"pid": 70, "identity_observed": True,
                    "ppid": 50, "pgid_at_observation": 70,
                    "sid_at_observation": 70, "startticks": 80,
                    "kill_sent": False, "reaped": True, "raw_wait_status": 0,
                    "wait": {"exited": True, "signaled": False,
                        "exit_code": 0, "signal": None, "core_dumped": False}}
                    if post else None,
                "cleanup_start_ns": 100 if post else 0,
                "cleanup_deadline_ns": 15000000100 if post else 0,
                "cleanup_finished_ns": 200 if post else 0,
                "cleanup_complete": post, "group_identity_pinned": post,
                "owned_records_omitted": 0, "owned_children": [],
                "streams": {"stdout_eof": selector in (0, 3, 4, 5),
                    "stderr_eof": selector in (0, 3, 4, 5),
                    "setup_eof": selector in (0, 3, 4, 5)}}
            report.update({"first_failure_monotonic_ns": 0 if report_status[4] == "none"
                else 350 if selector == 3 else 50,
                "pathname_execution": False, "loader_closure_verified": False,
                "native_payload": None, "collector_uid": 0,
                "collector_euid": 0, "collector_interruption_signal": 0,
                "desired": desired,
                "configured_execution_mechanism": "execveat-AT_EMPTY_PATH-sealed-memfd",
                "setup_ready_record": selector in (0, 3, 4, 5),
                "setup_error_record": False,
                "setup_validated": selector in (0, 3, 4, 5),
                "setup_words": setup_values,
                "post_exec_backing_observed": post,
                "post_exec_observed_monotonic_ns": 90 if post else 0,
                "post_exec_backing": report_stat(mode=0o100500,
                    size=len(stimulus), inode=202) if post else None,
                "subsequent_proc_exe_link_sample": None,
                "preparation_start_ns": 1, "preparation_deadline_ns": 120000000001,
                "process_start_ns": 50 if post else 0,
                "process_deadline_ns": 10000000050 if post else 0,
                "completion_observed_ns": 90 if post else 0,
                "executable": source_record(post), "stdin": source_record(False),
                "devnull_identity": report_stat(mode=0o20666, inode=203)
                    if post else None, "artifacts": artifacts})
            (collection / "report.json").write_text(
                json.dumps(report, sort_keys=True, separators=(",", ":")))
        request = oracle.PREFIX if selector in (2, 6) else original_request
        if selector != 1: (collection / "request.bin").write_bytes(request)
        if selector != 1:
            event_values = [{"monotonic_ns": 10, "event": "collector-start", "pid": 50}]
            if post:
                event_values += [
                    {"monotonic_ns": 20, "event": "child-created", "pid": 70,
                     "startticks": 80},
                    {"monotonic_ns": 30, "event": "observed-sealed-exe", "pid": 70},
                    {"monotonic_ns": 40, "event": "leader-waitable", "pid": 70},
                    {"monotonic_ns": 50, "event": "owned-group-kill-attempt",
                     "pgid": 70, "leader_startticks": 80},
                    {"monotonic_ns": 60, "event": "actual-reap", "pid": 70,
                     "raw_wait_status": 0}]
            event_values.append({"monotonic_ns": 300 if post else 100,
                "event": "collector-finish",
                "first_failure": "artifact-write" if selector in (2, 6) else "none"})
            (collection / "events.jsonl").write_bytes(b"".join(
                json.dumps(value, sort_keys=True, separators=(",", ":")).encode() + b"\n"
                for value in event_values))
            if post:
                (collection / "selected-inputs.bin").write_bytes(selected)
                (collection / "argv.nul").write_bytes(b"fixture\x00--mode\x00")
                (collection / "env.nul").write_bytes(b"")
                (collection / "executable.verified.bin").write_bytes(stimulus)
                (collection / "stdout.bin").write_bytes(b"")
                (collection / "stderr.bin").write_bytes(b"")
                (collection / "setup.bin").write_bytes(struct.pack(
                    "<" + "Q" * len(setup_values), *setup_values))
            if (collection / "report.json").exists():
                report_value = json.loads((collection / "report.json").read_text())
                for artifact in report_value["artifacts"]:
                    if artifact is None or not artifact["created"]:
                        continue
                    artifact_path = collection / artifact["path"]
                    if artifact_path.exists():
                        artifact_raw = artifact_path.read_bytes()
                        if not artifact["io_error"]:
                            artifact["seen_bytes"] = len(artifact_raw)
                        artifact["stored_bytes"] = len(artifact_raw)
                        artifact["sha256"] = hashlib.sha256(artifact_raw).hexdigest()
                (collection / "report.json").write_text(json.dumps(
                    report_value, sort_keys=True, separators=(",", ":")))
        (root / "stdout.bin").write_bytes(b"")
        (root / "stderr.bin").write_bytes(b"")
        (root / "owner-errors.jsonl").write_bytes(b"")
        def record(path, shown=None):
            if not path.exists():
                return {"path": str(shown or path), "present": False,
                        "size": None, "sha256": None}
            raw = path.read_bytes()
            return {"path": str(shown or path), "present": True,
                    "size": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        hashes = {"source_sha256": self.SOURCE_SHA, **self.active_hashes}
        environment = owner.effective_environment(self.NONCE, hashes)
        argv = [str(elf), "--linux-sealed-infrastructure-v1",
                str(retained_root / "request.bin"),
                str(retained_root / "selected-inputs.json"), str(collection)]
        cleanup = {"complete": True, "trigger_kind": "normal-eof",
            "trigger_ns": 1000, "cleanup_start_ns": 1100,
            "cleanup_deadline_ns": 22000001000, "cleanup_finished_ns": 1300,
            "events": [{"kind": "wait", "pid": 50, "startticks": 60,
                "raw_wait_status": self.WAITS[selector], "direct": True,
                "monotonic_ns": 1150},
                {"kind": "owned-scan", "monotonic_ns": 1200, "pids": []},
                {"kind": "echild", "monotonic_ns": 1250,
                 "return": -1, "errno": 10}],
            "adopted_reaps": [], "unresolved": []}
        owner_result = {"schema_version": 2, "kind": "OWNER_RESULT",
            "nonce": self.NONCE, "selector": selector, "argv": argv,
            "owner": {"pid": 40, "startticks": 30}, "environment": environment,
            "collector": {"pid": 50, "identity_observed": True, "ppid": 40,
                "startticks": 60, "reaped": True,
                "raw_wait_status": self.WAITS[selector]},
            "packet_count": self.COUNTS[selector], "hashes": hashes,
            "inputs": {"source": record(source), "generated_source": record(generated),
                "header": record(header), "elf": record(elf)},
            "runtime_inputs": {
                "request": {"source_path": "/original/request.bin",
                    "destination_path": str(retained_root / "request.bin"),
                    "size": 406, "sha256": oracle.REQUEST_SHA},
                "selected_inputs": {"source_path": "/original/selected-inputs.json",
                    "destination_path": str(retained_root / "selected-inputs.json"),
                    "size": 76, "sha256": oracle.SELECTED_SHA},
                "fixture": {"source_path": "/work/cases/stdin-devnull/inputs/fixture",
                    "destination_path": str(retained_root / "fixture"),
                    "size": 27448, "sha256": oracle.FIXTURE_SHA}},
            "captures": {"stdout": record(root / "stdout.bin", "stdout.bin"),
                "stderr": record(root / "stderr.bin", "stderr.bin")},
            "artifacts": {"events": record(collection / "events.jsonl"),
                "request": record(collection / "request.bin"),
                "report": record(collection / "report.json")},
            "owner_failure": None, "secondary_failures": [],
            "result_serialized_ns": 1400, "cleanup": cleanup,
            "deadlines": {"owner_start_ns": 500,
                "ready_deadline_ns": 10000000500,
                "release_send_start_ns": 600,
                "collection_deadline_ns": 180000000600,
                "first_postfork_receipt_ns": 700 if post else None,
                "postfork_deadline_ns": 60000000700 if post else None,
                "cleanup_trigger_ns": 1000,
                "cleanup_deadline_ns": 22000001000},
            "backend_enabled": False, "application_acceptance": False}
        (root / "owner-result.json").write_text(json.dumps(
            owner_result, sort_keys=True, separators=(",", ":")) + "\n")
        rows = [{"packet": packet, "receipt_monotonic_ns": 2000 + index}
                for index, packet in enumerate(self.packets(selector,
                    (collection / "report.json").stat().st_size if
                    (collection / "report.json").exists() else 0))]
        rows.append({"packet": owner_result,
                     "receipt_monotonic_ns": 2000 + len(rows)})
        (root / "witness.jsonl").write_bytes(b"".join(
            json.dumps(row, sort_keys=True, separators=(",", ":")).encode() + b"\n"
            for row in rows))

    def mutate(self, selector, mutation, message, exception=ValueError):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "case"
            self.write_fixture(root, selector)
            mutation(root)
            with self.assertRaises(exception) as raised:
                oracle.validate(root, selector)
            self.assertEqual(str(raised.exception), message)

    def test_oracle_seven_positive_fixtures(self):
        unexpected = RuntimeError("execution forbidden")
        with mock.patch.object(subprocess, "run", side_effect=unexpected) as run_call, \
             mock.patch.object(subprocess, "Popen", side_effect=unexpected) as popen_call, \
             mock.patch.object(owner.os, "fork", side_effect=unexpected) as fork_call:
            for selector in range(7):
                with self.subTest(selector=selector), tempfile.TemporaryDirectory() as temporary:
                    root = Path(temporary) / "case"
                    self.write_fixture(root, selector)
                    self.assertTrue(oracle.validate(root, selector))
            run_call.assert_not_called()
            popen_call.assert_not_called()
            fork_call.assert_not_called()

    def test_exact_schedule_and_pre_ack_schema_for_all_selectors(self):
        for selector in range(7):
            packets = self.packets(selector)
            self.assertEqual(len(packets), self.COUNTS[selector])
            for index, packet in enumerate(packets):
                owner.validate_packet_schema(packet, selector)
                owner.validate_schedule_prefix(packets[:index + 1], selector)
            signatures = [(packet["kind"], packet["site"], packet["object"],
                           packet["occurrence"]) for packet in packets]
            self.assertIn(signatures, oracle.schedule_variants(selector))

    def test_pre_ack_rejects_wrong_phase_null_stat_and_boolean_fd(self):
        packet = next(value for value in self.packets(0) if
                      value["kind"] == "BEFORE" and
                      value["site"] == "request-write")
        for field, replacement, message in (
                ("phase", "post-fork", "witness phase"),
                ("target_stat", None, "witness write types"),
                ("fd", True, "witness write types")):
            changed = copy.deepcopy(packet)
            changed[field] = replacement
            with self.assertRaises(ValueError) as raised:
                owner.validate_packet_schema(changed, 0)
            self.assertEqual(str(raised.exception), message)

    def test_report_preflush_prefix_size_is_permitted(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "case"
            self.write_fixture(root, 0)
            report_size = (root / "collection/report.json").stat().st_size
            self.rewrite_journal(root / "witness.jsonl", lambda rows:
                next(row for row in rows if row["packet"].get("site") ==
                     "report-flush" and row["packet"].get("kind") == "BEFORE")
                    ["packet"]["target_stat"].__setitem__("size", report_size // 2))
            self.assertTrue(oracle.validate(root, 0))

    def rewrite_json(self, path, edit):
        value = json.loads(path.read_text())
        edit(value)
        path.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")))

    def rewrite_journal(self, path, edit):
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        edit(rows)
        path.write_bytes(b"".join(json.dumps(row, sort_keys=True,
            separators=(",", ":")).encode() + b"\n" for row in rows))

    def republish_owner(self, root, edit=lambda value: None):
        owner_path = root / "owner-result.json"
        value = json.loads(owner_path.read_text())
        edit(value)
        owner_path.write_text(json.dumps(value, sort_keys=True,
            separators=(",", ":")) + "\n")
        self.rewrite_journal(root / "witness.jsonl",
            lambda rows: rows[-1].__setitem__("packet", value))

    def rebind_artifact(self, root, name):
        filename = {"events": "events.jsonl", "request": "request.bin",
                    "report": "report.json"}[name]
        path = root / "collection" / filename
        raw = path.read_bytes()
        def edit(value):
            value["artifacts"][name].update({"present": True, "size": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest()})
        self.republish_owner(root, edit)
        if name == "report":
            self.rewrite_journal(root / "witness.jsonl", lambda rows: [
                packet["target_stat"].__setitem__("size", len(raw))
                for row in rows[:-1] for packet in [row["packet"]]
                if packet.get("site") in ("report-flush", "report-sync") and
                   not (packet["site"] == "report-flush" and
                        packet["kind"] == "BEFORE")])

    def mutate_report(self, root, edit):
        self.rewrite_json(root / "collection/report.json", edit)
        self.rebind_artifact(root, "report")

    def mutate_events(self, root, edit):
        path = root / "collection/events.jsonl"
        values = [json.loads(line) for line in path.read_text().splitlines()]
        edit(values)
        path.write_bytes(b"".join(json.dumps(value, sort_keys=True,
            separators=(",", ":")).encode() + b"\n" for value in values))
        self.rebind_artifact(root, "events")

    def replace_retained_with_symlink(self, root):
        path = root / "retained-inputs/request.bin"
        path.unlink()
        path.symlink_to(root / "retained-inputs/fixture")

    def test_oracle_independent_negative_matrix(self):
        self.mutate(0, lambda root: self.rewrite_json(root / "owner-result.json",
                    lambda value: value.__setitem__("raw_wait_status", 1)), "owner result")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[1]["packet"].__setitem__("sequence", 7)), "witness identity")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[0]["packet"].__setitem__("nonce", "e" * 32)), "witness identity")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[0]["packet"].__setitem__("elf_sha256", "0" * 64)), "generated hash")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows.pop(-2)), "witness packet count")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows.insert(2, copy.deepcopy(rows[1]))), "witness packet count")
        self.mutate(0, lambda root: self.rewrite_json(root / "collection/report.json",
                    lambda value: value.__setitem__("status", "COLLECTOR_ERROR")), "evidence hash")
        self.mutate(4, lambda root: (root / "collection/report.json").write_text("{}"),
                    "evidence absence")
        self.mutate(2, lambda root: (root / "collection/request.bin").write_bytes(b"BROKEN!"),
                    "evidence hash")
        self.mutate(5, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows
                        if row["packet"].get("site") == "report-sync" and
                        row["packet"].get("kind") == "AFTER" and
                        row["packet"].get("return") == -1)["packet"].__setitem__("errno", 0)),
                    "after result")
        self.mutate(0, lambda root: (root / "witness.jsonl").write_bytes(
                    (root / "witness.jsonl").read_bytes()[:-1]), "journal terminal newline")
        self.mutate(0, lambda root: self.republish_owner(root,
                    lambda value: value.__setitem__("unexpected", 1)), "owner result")
        self.mutate(0, lambda root: self.republish_owner(root,
                    lambda value: value["environment"].__setitem__("EXTRA", "1")),
                    "owner environment")
        self.mutate(0, lambda root: self.republish_owner(root,
                    lambda value: value["argv"].__setitem__(0,
                        value["inputs"]["source"]["path"])), "executed ELF path")
        self.mutate(0, lambda root: self.rewrite_json(root / "owner-result.json",
                    lambda value: value["owner"].__setitem__("startticks", 31)),
                    "owner publication")
        self.mutate(0, lambda root: self.mutate_report(root,
                    lambda value: value.__setitem__("unexpected", 1)), "report fields")
        self.mutate(0, lambda root: self.mutate_report(root,
                    lambda value: value["desired"].pop("argc")), "report desired")
        self.mutate(0, lambda root: self.mutate_report(root,
                    lambda value: value["linux_child"].__setitem__("startticks", 81)),
                    "report child cleanup")
        self.mutate(2, lambda root: self.mutate_report(root,
                    lambda value: value["artifacts"][0].__setitem__("seen_bytes", 405)),
                    "report request sink")
        self.mutate(0, lambda root: self.mutate_events(root,
                    lambda values: values[-1].__setitem__("first_failure", "artifact-write")),
                    "events failure snapshot")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: [packet["target_stat"].__setitem__("size", 1)
                        for row in rows[:-1] for packet in [row["packet"]]
                        if packet.get("site") in ("report-flush", "report-sync") and
                           not (packet["site"] == "report-flush" and
                                packet["kind"] == "BEFORE")]), "report witness size")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[0]["packet"].__setitem__("extra", 1)),
                    "witness exact fields")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[1]["packet"].__setitem__("phase", "post-fork")),
                    "witness phase")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows if
                        row["packet"].get("site") == "request-write")["packet"].
                        __setitem__("acquisition_id", 1)), "request acquisition")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows if
                        row["packet"].get("site") == "request-write")["packet"].
                        __setitem__("requested_bytes", 405)), "request bytes")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows if
                        row["packet"].get("site") == "request-write")["packet"]
                        ["target_stat"].__setitem__("mode", 0o40700)),
                    "witness target type")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows if
                        row["packet"].get("kind") == "CLEANUP_FINAL")["packet"].
                        __setitem__("first_failure", "artifact-write")),
                    "collector cleanup result")
        self.mutate(0, lambda root: self.republish_owner(root,
                    lambda value: value["cleanup"]["events"][-2].
                        __setitem__("pids", [{"pid": 99, "ppid": 40,
                                             "startticks": 88}])),
                    "owner cleanup terminal")
        self.mutate(0, lambda root: self.republish_owner(root,
                    lambda value: value["cleanup"]["events"][1].
                        __setitem__("monotonic_ns", 1140)),
                    "owner cleanup event order")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows if
                        row["packet"].get("site") == "request-sync")["packet"]
                        ["target_stat"].__setitem__("ino", 999)),
                    "request sync identity")
        self.mutate(1, lambda root: self.mutate_report(root,
                    lambda value: value["artifacts"][4].
                        __setitem__("creation_errno", 5)),
                    "report events create failure")
        self.mutate(0, lambda root: self.mutate_report(root,
                    lambda value: value["setup_words"].__setitem__(5, 71)),
                    "report setup semantics")
        self.mutate(0, self.replace_retained_with_symlink,
                    "canonical evidence path")

    def test_durable_journal_and_protocol_helpers(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "journal"
            journal = owner.DurableJournal(root)
            journal.append({"kind": "READY"}, 1)
            journal.close()
            raw = (root / "witness.jsonl").read_bytes()
            self.assertTrue(raw.endswith(b"\n"))
            self.assertEqual(json.loads(raw)["packet"], {"kind": "READY"})
        packet = self.packet(0, 0, "READY", phase="pre-fork")
        owner.validate_common(packet, self.NONCE, 0, 0,
                              {"source_sha256": self.SOURCE_SHA, **self.HASHES})
        wrong = copy.deepcopy(packet)
        wrong["sequence"] = 1
        with self.assertRaisesRegex(ValueError, "witness identity"):
            owner.validate_common(wrong, self.NONCE, 0, 0,
                                  {"source_sha256": self.SOURCE_SHA, **self.HASHES})

    def test_exact_retained_input_and_executable_bindings(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            raw = {"source": prepare.SOURCE.read_bytes(),
                   "generated_source": b"generated-source\n",
                   "header": b"header\n", "elf": b"elf\n"}
            paths = {}
            for name, value in raw.items():
                path = root / name
                path.write_bytes(value)
                paths[name] = path
            hashes = {"source_sha256": hashlib.sha256(raw["source"]).hexdigest(),
                      "generated_sha256": hashlib.sha256(raw["generated_source"]).hexdigest(),
                      "header_sha256": hashlib.sha256(raw["header"]).hexdigest(),
                      "elf_sha256": hashlib.sha256(raw["elf"]).hexdigest()}
            records = owner.bind_inputs(paths, hashes)
            self.assertEqual(set(records), {"source", "generated_source",
                                             "header", "elf"})
            self.assertEqual(records["source"]["sha256"], self.SOURCE_SHA)
            owner.validate_executable([str(paths["elf"])], records)
            with self.assertRaisesRegex(ValueError, "executed ELF path"):
                owner.validate_executable([str(paths["source"])], records)
            bad = dict(hashes); bad["header_sha256"] = "0" * 64
            with self.assertRaisesRegex(ValueError, "input hash header"):
                owner.bind_inputs(paths, bad)
            link = root / "elf-link"
            link.symlink_to(paths["elf"])
            linked = dict(paths); linked["elf"] = link
            with self.assertRaisesRegex(ValueError, "canonical input path"):
                owner.bind_inputs(linked, hashes)

if __name__ == "__main__":
    unittest.main()
