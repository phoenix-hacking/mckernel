/work/native-sysfs-objects-module-20260907-2/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o
