from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-irq-work-retained-20260907-1')
out.mkdir()
record = dict(created_utc=datetime.now(timezone.utc).isoformat(), production_gate_credit=False,
              mckernel_boot_proven=False, stage='guest-irq-work-abi-adaptation', artifacts=[],
              passed=['legacy and native complete-producer checks; 1027 callbacks each',
                      'concurrent native senders; 8192 callbacks; one allocation',
                      'exact Linux 6.12 header witness and native verification module',
                      'four-vCPU/two-NUMA Linux guest; two module cycles; 1024 actual callbacks'],
              limitations=['boot context, guest CPU/IRQ state, allocator and delivery transport are test doubles',
                           'Linux irq_work_queue and hardirq callback/flag completion are real',
                           'McKernel image with native ABI, real AP startup and cross-kernel IRQ/IKC still pending'])
def retain(path, name=None):
    target = out / (name or ('native-irq-work-20260907-' + path.name + '.gz'))
    data = path.read_bytes()
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            stream.write(data)
    assert gzip.decompress(target.read_bytes()) == data
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name, source=str(path),
                                    sha256=hashlib.sha256(target.read_bytes()).hexdigest(), size=target.stat().st_size,
                                    unpacked_sha256=hashlib.sha256(data).hexdigest(), unpacked_size=len(data)))
for name in ['native-irq-work-policy-20260907-1', 'native-irq-work-module-20260907-1', 'native-irq-work-module-20260907-2', 'native-irq-work-module-20260907-3', 'native-irq-work-guest-20260907-1']:
    path = Path('/work') / name
    archive = out / (name + '.tar.gz')
    with tarfile.open(archive, 'w:gz') as stream:
        stream.add(path, arcname=name)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + archive.name, source=str(path), size=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
    retain(path / 'record.json', name + '-record.json.gz')
    log = path / ('serial.log' if 'guest' in name else 'validation.log' if 'policy' in name else 'module-build.log')
    retain(log, name + '-' + log.name + '.gz')
for name in ['format-native-irq-work.py', 'run-native-irq-work-policy.py', 'build-native-irq-work-module.py', 'run-native-irq-work-guest.py', 'retain-native-irq-work.py']:
    retain(Path('/work') / name)
for path in [Path('/workspace/kernel/rust/smp_ikc.rs'), Path('/workspace/kernel/CMakeLists.txt')]:
    record.setdefault('production_inputs', []).append(dict(path=str(path.relative_to('/workspace')), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), size=path.stat().st_size))
(out / 'native-irq-work-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained', len(record['artifacts']), 'artifacts in', out)
