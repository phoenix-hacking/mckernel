#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData,PhantomPinned};
use core::pin::Pin;
use core::ptr::{null_mut,write_volatile};
use core::mem::{size_of,align_of,offset_of};
pub type CInt = i32;
pub type CLong = i64;
pub type CULong = u64;
// x86_64's C enum includes PTATTR_NO_EXECUTE at bit 63, so its ABI is u64.
pub type IhkMcPtAttribute = CULong;
pub type SizeT = usize;
pub type SSizeT = isize;
pub type OffT = i64;

#[repr(C)]
#[derive(Clone, Copy)]
pub struct AbiListHead {
    pub next: *mut AbiListHead,
    pub prev: *mut AbiListHead,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct IhkAtomic {
    pub counter: CInt,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct IhkAtomic64 {
    pub counter64: CLong,
}

#[repr(C)]
pub struct MemPage {
    list: AbiListHead,
    hash: AbiListHead,
    mode: u8,
    phys: CULong,
    count: IhkAtomic,
    mapped: IhkAtomic64,
    offset: OffT,
    pgshift: CInt,
}

#[inline(always)]
unsafe fn list_add(new: *mut AbiListHead, prev: *mut AbiListHead, next: *mut AbiListHead) {
    (*next).prev = new;
    (*new).next = next;
    (*new).prev = prev;
    (*prev).next = new;
}

#[inline(always)]
unsafe fn list_add_tail(new: *mut AbiListHead, head: *mut AbiListHead) {
    list_add(new, (*head).prev, head);
}

#[inline(always)]
unsafe fn list_add_after(new: *mut AbiListHead, head: *mut AbiListHead) {
    list_add(new, head, (*head).next);
}

#[inline(always)]
unsafe fn list_del(entry: *mut AbiListHead) {
    let next = (*entry).next;
    let prev = (*entry).prev;
    (*next).prev = prev;
    (*prev).next = next;
}

#[inline(always)]
unsafe fn init_list_head(head: *mut AbiListHead) {
    (*head).next = head;
    (*head).prev = head;
}

#[inline(always)]
unsafe fn list_del_poison(entry: *mut AbiListHead) {
    list_del(entry);
    (*entry).next = LIST_POISON1 as *mut AbiListHead;
    (*entry).prev = LIST_POISON2 as *mut AbiListHead;
}

#[inline(always)]
unsafe fn page_from_list(node: *mut AbiListHead) -> *mut MemPage {
    node.cast::<MemPage>()
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum PendingFreeBatchState {
    Vacant,
    Retained,
    Drained,
}

/// Pinned transaction destination for pending-page ownership transfer.
/// It is deliberately !Unpin, !Send and !Sync and never frees implicitly.
struct PendingFreeBatch {
    head: AbiListHead,
    state: PendingFreeBatchState,
    source: *mut AbiListHead,
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

impl PendingFreeBatch {
    const fn new() -> Self {
        Self {
            head: AbiListHead { next: null_mut(), prev: null_mut() },
            state: PendingFreeBatchState::Vacant,
            source: null_mut(),
            _pin: PhantomPinned,
            _owner: PhantomData,
        }
    }
}

unsafe fn validate_pending_head(head: *mut AbiListHead) -> Result<bool, CInt> {
    if head.is_null() || (*head).next.is_null() || (*head).prev.is_null() {
        return Err(-EINVAL);
    }
    if (*head).next == head || (*head).prev == head {
        if (*head).next != head || (*head).prev != head {
            return Err(-EINVAL);
        }
        return Ok(false);
    }
    if (*(*head).next).prev != head || (*(*head).prev).next != head {
        return Err(-EINVAL);
    }

    // Validate the complete ring before changing either list.  Floyd's
    // traversal detects a foreign cycle without imposing a node-count cap.
    let mut slow = (*head).next;
    let mut fast = (*head).next;
    loop {
        if slow == head {
            break;
        }
        if slow.is_null()
            || (*slow).next.is_null()
            || (*slow).prev.is_null()
            || (*(*slow).next).prev != slow
            || (*(*slow).prev).next != slow
        {
            return Err(-EINVAL);
        }
        let page = page_from_list(slow);
        if page.is_null() || (*page).mode != PM_PENDING_FREE {
            return Err(-EINVAL);
        }
        slow = (*slow).next;

        if fast == head {
            continue;
        }
        if fast.is_null() || (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == head {
            continue;
        }
        if (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == slow && slow != head {
            return Err(-EINVAL);
        }
    }
    Ok(true)
}

unsafe fn detach_pending_free_batch(
    source: *mut AbiListHead,
    mut destination: Pin<&mut PendingFreeBatch>,
) -> CInt {
    // Safety obligations: the caller owns an exclusive, CPU-local source
    // ring and keeps every live descriptor stable; no producer may enqueue or
    // callback may re-enter while this transaction is detached. `destination`
    // must remain at this pinned address until drain (or explicit recovery).
    let dest = destination.as_mut().get_unchecked_mut();
    let dest_head = &raw mut dest.head;
    if source.is_null()
        || source == dest_head
        || dest.state != PendingFreeBatchState::Vacant
        || !(dest.head.next.is_null() && dest.head.prev.is_null())
    {
        return -EINVAL;
    }
    let nonempty = match validate_pending_head(source) {
        Ok(nonempty) => nonempty,
        Err(_) => return -EINVAL,
    };
    if nonempty {
        let first = (*source).next;
        let last = (*source).prev;
        init_list_head(dest_head);
        (*dest_head).next = first;
        (*dest_head).prev = last;
        (*first).prev = dest_head;
        (*last).next = dest_head;
        (*source).next = null_mut();
        (*source).prev = null_mut();
    } else {
        init_list_head(dest_head);
        (*source).next = null_mut();
        (*source).prev = null_mut();
    }
    dest.source = source;
    dest.state = PendingFreeBatchState::Retained;
    0
}

unsafe fn drain_pending_free_batch(
    source: *mut AbiListHead,
    mut batch: Pin<&mut PendingFreeBatch>,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    // Safety obligations: `source` must be the exact source captured by
    // detach, the pinned transaction must outlive this call, and `free_fn`
    // must not mutate either list or re-enter detach/drain. The caller owns
    // the exclusive CPU/descriptor lease for the whole operation.
    let Some(free_fn) = free_fn else { return -EINVAL; };
    let b = batch.as_mut().get_unchecked_mut();
    if b.state != PendingFreeBatchState::Retained
        || b.source != source
        || validate_pending_head(&raw mut b.head).is_err()
    {
        return -EINVAL;
    }
    let mut node = b.head.next;
    let mut count = 0;
    while node != &raw mut b.head {
        let next = (*node).next;
        let page = page_from_list(node);
        (*page).mode = PM_NONE;
        list_del_poison(node);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        node = next;
    }
    b.head.next = null_mut();
    b.head.prev = null_mut();
    b.source = null_mut();
    b.state = PendingFreeBatchState::Drained;
    count
}

#[no_mangle]
pub unsafe extern "C" fn mem_begin_free_pages_pending_result(pendings: *mut AbiListHead) -> CInt {
    if pendings.is_null() || !(*pendings).next.is_null() {
        return -EINVAL;
    }
    init_list_head(pendings);
    0
}

#[no_mangle]
pub unsafe extern "C" fn mem_begin_free_pages_pending_body_result(
    pendings: *mut AbiListHead,
    begin_fn: Option<MemBeginFreePagesPendingFn>,
    panic_fn: Option<MemVoidFn>,
) -> CInt {
    let ret = if let Some(begin) = begin_fn {
        begin(pendings)
    } else {
        -EINVAL
    };
    if ret != 0 {
        if let Some(panic) = panic_fn {
            panic();
        }
    }
    ret
}

#[no_mangle]
pub unsafe extern "C" fn mem_free_pages_pending_enqueue_result(
    page: *mut MemPage,
    pendings: *mut AbiListHead,
    npages: CInt,
    warn_fn: Option<MemPendingWarnFn>,
) -> CInt {
    if page.is_null() || pendings.is_null() {
        return 0;
    }

    if (*page).mode != PM_NONE {
        if let Some(warn) = warn_fn {
            warn((*page).phys);
        }
    }

    if (*pendings).next.is_null() {
        return 0;
    }

    (*page).mode = PM_PENDING_FREE;
    (*page).offset = npages as OffT;
    list_add_tail(&raw mut (*page).list, pendings);
    1
}

#[no_mangle]
pub unsafe extern "C" fn mem_finish_free_pages_pending_result(
    pendings: *mut AbiListHead,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    let Some(free_fn) = free_fn else {
        return -EINVAL;
    };
    if pendings.is_null() || (*pendings).next.is_null() {
        return 0;
    }

    let mut count: CInt = 0;
    let mut entry = (*pendings).next;
    while entry != pendings {
        let next = (*entry).next;
        let page = page_from_list(entry);

        if (*page).mode != PM_PENDING_FREE {
            return -EINVAL;
        }

        (*page).mode = PM_NONE;
        list_del_poison(entry);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        entry = next;
    }

    write_volatile(&raw mut (*pendings).next, null_mut());
    write_volatile(&raw mut (*pendings).prev, null_mut());
    count
}

const EINVAL: CInt = 22;
const IHK_MC_PG_USER: CInt = 1;
const PM_NONE: u8 = 0x00;
const PM_PENDING_FREE: u8 = 0x01;
const LIST_POISON1: usize = 0x0010_0129;
const LIST_POISON2: usize = 0x0020_0229;
type MemPendingFreeFn = unsafe extern "C" fn(CULong, CInt, CInt);
type MemPendingWarnFn = unsafe extern "C" fn(CULong);
type MemBeginFreePagesPendingFn = unsafe extern "C" fn(*mut AbiListHead) -> CInt;
type MemVoidFn = unsafe extern "C" fn();
const _: () = {
    assert!(size_of::<MemPage>() == 80);
    assert!(align_of::<MemPage>() == 8);
    assert!(offset_of!(MemPage, list) == 0);
    assert!(offset_of!(MemPage, hash) == 16);
    assert!(offset_of!(MemPage, mode) == 32);
    assert!(offset_of!(MemPage, phys) == 40);
    assert!(offset_of!(MemPage, count) == 48);
    assert!(offset_of!(MemPage, mapped) == 56);
    assert!(offset_of!(MemPage, offset) == 64);
    assert!(offset_of!(MemPage, pgshift) == 72);
};

// Appended verbatim to extracted production source. Pointer IDs are fixture-local.
use std::cell::{Cell, RefCell};
use std::sync::atomic::{AtomicUsize, Ordering};
#[derive(Clone, Copy, Debug)]
struct Callback(CULong, CInt, CInt);
struct Ledger { entries: [Callback; 32], used: usize, limit: usize }
thread_local! {
    static LEDGER: RefCell<Ledger> = const { RefCell::new(Ledger { entries: [Callback(0,0,0);32], used: 0, limit: 32 }) };
    static CALLBACK_ERROR: Cell<usize> = const { Cell::new(0) };
}
static TLS_ERROR: AtomicUsize = AtomicUsize::new(0);
static PANIC_BRIDGE: AtomicUsize = AtomicUsize::new(0);
unsafe extern "C" fn panic_bridge() { PANIC_BRIDGE.fetch_add(1, Ordering::SeqCst); }
unsafe extern "C" fn free_page(p: CULong, n: CInt, u: CInt) {
    let access = LEDGER.try_with(|c| {
        let error = match c.try_borrow_mut() {
            Ok(mut l) => { if l.used >= l.limit { 2 } else { let i=l.used; l.entries[i]=Callback(p,n,u); l.used+=1; 0 } },
            Err(_) => 1,
        };
        if error != 0 && CALLBACK_ERROR.try_with(|e|e.set(error)).is_err() { TLS_ERROR.fetch_add(1,Ordering::SeqCst); }
    });
    if access.is_err() { TLS_ERROR.fetch_add(1,Ordering::SeqCst); }
}
fn reset() { LEDGER.with(|c| { let mut l=c.borrow_mut(); l.used=0; l.limit=32; }); CALLBACK_ERROR.with(|c|c.set(0)); PANIC_BRIDGE.store(0, Ordering::SeqCst); assert_eq!(TLS_ERROR.load(Ordering::SeqCst),0); }
fn callbacks() -> String { LEDGER.with(|c| { let l=c.borrow(); let v:Vec<String>=l.entries[..l.used].iter().map(|x|format!("[{},{},{}]",x.0,x.1,x.2)).collect(); format!("[{}]",v.join(",")) }) }
fn callback_controls() { reset(); LEDGER.with(|c| { let _held=c.borrow_mut(); unsafe { free_page(1,1,1); } }); assert_eq!(CALLBACK_ERROR.with(Cell::get),1); reset(); LEDGER.with(|c|c.borrow_mut().limit=0); unsafe { free_page(1,1,1); } assert_eq!(CALLBACK_ERROR.with(Cell::get),2); reset(); println!("CONTROL|callback-borrow-and-capacity-observed"); }
fn head() -> AbiListHead { AbiListHead {next:null_mut(),prev:null_mut()} }
fn page(i:usize) -> MemPage { MemPage {list:head(),hash:head(),mode:PM_NONE,phys:100+i as u64,count:IhkAtomic{counter:70+i as i32},mapped:IhkAtomic64{counter64:80+i as i64},offset:0,pgshift:12+i as i32} }
struct World { s:AbiListHead,t:AbiListHead,p:[MemPage;4],b:Pin<Box<PendingFreeBatch>> }
impl World {
    fn new()->Box<Self>{Box::new(Self{s:head(),t:head(),p:std::array::from_fn(page),b:Box::pin(PendingFreeBatch::new())})}
    unsafe fn id(&self,x:*mut AbiListHead)->usize {
        if x.is_null(){return 0} if x==(&raw const self.s).cast_mut(){return 1} if x==(&raw const self.t).cast_mut(){return 2}
        if x==(&raw const self.b.as_ref().get_ref().head).cast_mut(){return 3}
        for (i,p) in self.p.iter().enumerate(){if x==(&raw const p.list).cast_mut(){return 10+i} if x==(&raw const p.hash).cast_mut(){return 20+i}}
        if x as usize==LIST_POISON1{return 90} if x as usize==LIST_POISON2{return 91} panic!("unknown pointer")
    }
    unsafe fn links(&self,h:&AbiListHead)->String{format!("{{\"next\":{},\"prev\":{}}}",self.id(h.next),self.id(h.prev))}
    unsafe fn snapshot(&self)->String {
        let pages:Vec<String>=self.p.iter().map(|p|format!("{{\"list\":{},\"hash\":{},\"mode\":{},\"phys\":{},\"count\":{},\"mapped\":{},\"offset\":{},\"pgshift\":{}}}",self.links(&p.list),self.links(&p.hash),p.mode,p.phys,p.count.counter,p.mapped.counter64,p.offset,p.pgshift)).collect();
        let b=self.b.as_ref().get_ref();let state=match b.state{PendingFreeBatchState::Vacant=>0,PendingFreeBatchState::Retained=>1,PendingFreeBatchState::Drained=>2};
        format!("{{\"source\":{},\"other\":{},\"batch\":{{\"head\":{},\"state\":{},\"source\":{}}},\"pages\":[{}]}}",self.links(&self.s),self.links(&self.t),self.links(&b.head),state,self.id(b.source),pages.join(","))
    }
    unsafe fn retained_destination(&self)->String {
        let b=self.b.as_ref().get_ref();assert!(b.state==PendingFreeBatchState::Retained);
        let pages:Vec<String>=self.p[..2].iter().map(|p|format!("{}:{}:{}:{}:{}:{}:{}:{}",self.links(&p.list),self.links(&p.hash),p.mode,p.phys,p.count.counter,p.mapped.counter64,p.offset,p.pgshift)).collect();
        format!("{}:{}:{}",self.links(&b.head),self.id(b.source),pages.join(","))
    }
    unsafe fn setup(&mut self,n:usize,other:bool){assert_eq!(mem_begin_free_pages_pending_result(&raw mut self.s),0);for i in 0..n {assert_eq!(mem_free_pages_pending_enqueue_result(&raw mut self.p[i],&raw mut self.s,i as i32+1,None),1)} if other {assert_eq!(mem_begin_free_pages_pending_result(&raw mut self.t),0);assert_eq!(mem_free_pages_pending_enqueue_result(&raw mut self.p[3],&raw mut self.t,4,None),1)} for p in &mut self.p {init_list_head(&raw mut p.hash)} }
    unsafe fn emit(&self,name:&str,op:&str,rc:i32,before:String){let after=self.snapshot();let cb=callbacks();let panic=PANIC_BRIDGE.load(Ordering::SeqCst);println!("JSON|{{\"case\":\"{}\",\"op\":\"{}\",\"rc\":{},\"panic\":{},\"before\":{},\"after\":{},\"callbacks\":{}}}",name,op,rc,panic,before,after,cb);assert_eq!(CALLBACK_ERROR.with(Cell::get),0);assert_eq!(TLS_ERROR.load(Ordering::SeqCst),0);if rc<0 {assert!(before==after && cb=="[]","PARTIAL_RELEASE_DETECTED case={}",name)} }
    unsafe fn detach(&mut self,name:&str,src:usize){reset();let before=self.snapshot();let s=match src{0=>null_mut(),3=>&raw mut self.b.as_mut().get_unchecked_mut().head,_=>&raw mut self.s};let rc=detach_pending_free_batch(s,self.b.as_mut());self.emit(name,"detach",rc,before)}
    unsafe fn drain(&mut self,name:&str,wrong:bool,callback:bool){reset();let before=self.snapshot();let s=if wrong{&raw mut self.t}else{&raw mut self.s};let rc=if name=="later-invalid" {mem_finish_free_pages_pending_result(&raw mut self.b.as_mut().get_unchecked_mut().head,Some(free_page))}else{drain_pending_free_batch(s,self.b.as_mut(),if callback{Some(free_page)}else{None})};self.emit(name,"drain",rc,before)}
    unsafe fn begin(&mut self,name:&str){reset();let before=self.snapshot();let rc=mem_begin_free_pages_pending_result(&raw mut self.s);self.emit(name,"begin",rc,before)}
    unsafe fn begin_body(&mut self,name:&str){reset();let before=self.snapshot();let rc=mem_begin_free_pages_pending_body_result(&raw mut self.s,Some(mem_begin_free_pages_pending_result),Some(panic_bridge));self.emit(name,"begin-body",rc,before)}
    unsafe fn malformed(&mut self,name:&str,boundary:usize){reset();if boundary==0 {self.setup(0,false);self.s.prev=null_mut()} else {self.setup(2,false);if boundary==1 {self.p[0].list.prev=&raw mut self.t} else {self.p[1].list.next=&raw mut self.t}}let before=self.snapshot();let rc=detach_pending_free_batch(&raw mut self.s,self.b.as_mut());self.emit(name,"detach",rc,before)}
}
fn main(){unsafe{
    assert_eq!(core::mem::offset_of!(MemPage,list),0);assert_eq!(core::mem::size_of::<MemPage>(),80);
    callback_controls();
    for (name,n) in [("empty",0),("one",1),("three-order",3)] {let mut w=World::new();w.setup(n,false);w.detach(name,1);w.drain(name,false,true);}
    let mut w=World::new();w.setup(2,false);w.detach("later-invalid-setup",1);w.p[1].mode=PM_NONE;w.drain("later-invalid",false,true);w.p[1].mode=PM_PENDING_FREE;w.drain("later-invalid-repair",false,true);
    let mut w=World::new();w.setup(1,false);w.detach("missing-callback-setup",1);w.drain("missing-callback",false,false);w.drain("missing-callback-recovery",false,true);
    let mut w=World::new();w.setup(1,true);w.detach("wrong-source-setup",1);w.drain("wrong-source",true,true);w.drain("wrong-source-recovery",false,true);
    let mut w=World::new();w.setup(1,false);w.detach("repeated-setup",1);w.detach("repeated-detach",1);w.drain("repeated-recovery",false,true);w.drain("repeated-drain",false,true);
    let mut w=World::new();w.setup(0,false);w.detach("null-source",0);
    let mut w=World::new();w.detach("inactive-empty",1);
    let mut w=World::new();w.setup(1,false);w.detach("alias-destination",3);
    let mut w=World::new();w.setup(1,false);w.b.as_mut().get_unchecked_mut().head.next=&raw mut w.s;w.detach("mixed-destination-links",1);
    let mut w=World::new();w.setup(1,false);w.b.as_mut().get_unchecked_mut().state=PendingFreeBatchState::Retained;w.detach("mixed-destination-state",1);
    let mut w=World::new();w.setup(1,false);w.begin("conflicting-begin");
    let mut w=World::new();w.begin("nested-begin-first");w.begin("nested-begin-second");
    let mut w=World::new();w.setup(1,false);w.begin_body("begin-panic-bridge");
    let mut w=World::new();w.malformed("malformed-active-empty",0);
    let mut w=World::new();w.malformed("malformed-boundary-prev",1);
    let mut w=World::new();w.malformed("malformed-boundary-next",2);
    let mut w=World::new();w.setup(2,true);w.detach("two-head-isolation",1);let retained=w.retained_destination();
    reset();let before=w.snapshot();let rc=mem_begin_free_pages_pending_result(&raw mut w.s);w.emit("source-reuse","begin",rc,before);
    assert_eq!(w.retained_destination(),retained);assert_eq!(callbacks(),"[]");
    reset();let before=w.snapshot();let rc=mem_free_pages_pending_enqueue_result(&raw mut w.p[2],&raw mut w.s,7,None);w.emit("source-reuse","enqueue",rc,before);
    assert_eq!(w.retained_destination(),retained);assert_eq!(callbacks(),"[]");
    reset();let before=w.snapshot();let rc=mem_finish_free_pages_pending_result(&raw mut w.s,Some(free_page));w.emit("source-reuse","finish",rc,before);
    assert_eq!(w.retained_destination(),retained);assert_eq!(callbacks(),"[[102,7,1]]");
    w.drain("two-head-isolation",false,true);assert_eq!(callbacks(),"[[100,1,1],[101,2,1]]");
    reset();let before=w.snapshot();let rc=mem_finish_free_pages_pending_result(&raw mut w.t,Some(free_page));w.emit("other-head-finish","finish",rc,before);
}}
