from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path('/home/holden/mckernel')
first = Path('/tmp/stability-terminal-boundary-source-20260913-1')
final = Path('/tmp/stability-terminal-boundary-source-20260913-2')
peer = Path('/tmp/stability-terminal-boundary-independent-review-20260913-lu6jjxm9')
(final / 'retention.py').write_bytes(Path(__file__).read_bytes())

def identity(path, raw=None):
    if raw is None:
        raw = Path(path).read_bytes()
    return {'path': str(path), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

inputs = json.loads((final / 'inputs.json').read_text())
for item in inputs:
    if identity(item['path'], (root / item['path']).read_bytes()) != item:
        raise ValueError('source changed after independent review: ' + item['path'])
expectations = next(item for item in inputs if item['path'].endswith('terminal-waitable-expectations.json'))
cases = json.loads((root / expectations['path']).read_text())['cases']
record = {
    'schema_version': 1, 'record_kind': 'stability_terminal_boundary_harness_source_review',
    'status': 'PASS_SOURCE_REVIEW_ONLY', 'source_inputs': inputs,
    'cases_authored': cases, 'case_count': len(cases),
    'independent_review': identity(peer / 'review.json'),
    'scope': 'Exact included v2 controller terminal-launcher method with actual Linux fork/pipe/procfs/clock/WAIT_NOWAIT and separately retained owned cleanup; no ioctl or guest paths invoked.',
    'validation_status': 'NOT_COMPILED_OR_EXECUTED_BY_AUTHOR_OR_SOURCE_REVIEWER',
    'pinned_compilation_and_runtime_owner': 'root coordinator',
    'application_acceptance': False, 'transport_acceptance': False,
    'production_gate_credit': False, 'guest_execution': False,
    'author_compilation': False, 'author_test_execution': False,
    'frozen_controller_or_header_modified': False,
    'source_review_findings_resolved': [
        'Require adjacent actual entry time with20ms remaining before nonexpired method calls; late seed retention is a failed fixture, not an expected timeout pass.',
        'Cleanup requires ECHILD plus both actual EOFs observed before its original2-second deadline.'
    ],
    'required_runtime_evidence': [
        'Pinned compiler/wrapper command, exact dependencies/source hashes, diagnostics, object and ELF.',
        'Eight separately supervised case invocations, actual harness raw exits and retained fresh attempt directories.',
        'Actual argv, fixture PIDs and readiness bytes, origin arithmetic, pre-cleanup method/waitid snapshots, stream/event bytes and each cleanup raw wait.',
        'Preserve and immediately report any original unexpected compile/test failure before corrections or retries.'
    ]
}
archive = root / 'docs/verification/evidence/stability-terminal-boundary-harness-source-review-20260913.tar.gz'
report = root / 'docs/verification/stability-terminal-boundary-harness-source-review-20260913.json'
if archive.exists() or report.exists():
    raise ValueError('immutable output already exists')
members = []
with archive.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz') as tar:
        for label, directory in [('source-attempt1', first), ('source-attempt2', final), ('independent-review', peer)]:
            for path in sorted(directory.rglob('*')):
                if path.is_symlink():
                    raise ValueError('unexpected symlink: ' + str(path))
                if not path.is_file():
                    continue
                raw = path.read_bytes()
                member = label + '/' + path.relative_to(directory).as_posix()
                entry = tarfile.TarInfo(member)
                entry.size = len(raw)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(raw))
                members.append(dict(identity(path, raw), member=member))
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    if len(actual) != len(members):
        raise ValueError('archive count mismatch')
    for actual, expected in zip(actual, members):
        raw = tar.extractfile(actual).read()
        if actual.name != expected['member'] or len(raw) != expected['size'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
            raise ValueError('archive member mismatch: ' + actual.name)
record.update(archive=identity(archive), archive_members=members,
              archive_member_hashes_verified=True,
              retention_scope='source bytes and metadata only; no C compilation or invocation')
report.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
result = {'report': identity(report), 'archive': identity(archive), 'members': len(members)}
(final / 'retention-verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result))
