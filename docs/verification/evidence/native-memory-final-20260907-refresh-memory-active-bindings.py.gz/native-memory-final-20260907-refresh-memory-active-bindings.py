"""Edit reviewed current data bindings; never execute repository code on the host."""
import ast,hashlib,json,pprint,re,subprocess
from pathlib import Path
root=Path('/home/holden/mckernel')
def sha(data):return hashlib.sha256(data).hexdigest()
def identity(path):
 data=(root/path).read_bytes();return dict(path=path,sha256=sha(data),size=len(data))
def nodes(s):return {n.targets[0].id:n.value for n in ast.parse(s).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def edit_values(path,replacements):
 p=root/path;s=p.read_text();lines=s.splitlines(keepends=True); found=nodes(s);edits=[]
 for name,value in replacements.items():
  n=found[name];edits.append((sum(map(len,lines[:n.lineno-1]))+n.col_offset,sum(map(len,lines[:n.end_lineno-1]))+n.end_col_offset,pprint.pformat(value,width=100,sort_dicts=False)))
 for a,b,v in sorted(edits,reverse=True):s=s[:a]+v+s[b:]
 p.write_text(s)
def normalize(path,marker):
 p=root/path;raw=p.read_bytes();pattern=marker.encode()+br':[0-9a-f]{64}'
 normalized,count=re.subn(pattern,marker.encode()+b':'+b'0'*64,raw);assert count==1
 raw,count=re.subn(pattern,marker.encode()+b':'+sha(normalized).encode(),raw);assert count==1;p.write_bytes(raw)
def update_json(path,allowed):
 p=root/path;v=json.loads(p.read_text());changed=[]
 def walk(d):
  if isinstance(d,dict):
   if d.get('path') in allowed and 'sha256' in d:
    current=identity(d['path']); d['sha256']=current['sha256']
    if 'size' in d:d['size']=current['size']
    changed.append(d['path'])
   for x in d.values():walk(x)
  elif isinstance(d,list):
   for x in d:walk(x)
 walk(v);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');return changed
runtime='scripts/native_rust_runtime_evidence.py'
workflow='.github/workflows/native-rust-host-modules-exact-build.yml'
s=(root/runtime).read_text();ns=nodes(s)
old_workflow=subprocess.check_output(['git','-C',str(root),'show','HEAD:'+workflow],text=True)
current_workflow=(root/workflow).read_text()
old_exact=old_workflow.split('\n  fp0006-native-rust-capture:\n',1)[0]
new_exact=current_workflow.split('\n  fp0006-native-rust-capture:\n',1)[0]
old_steps=ast.literal_eval(ns['EXPECTED_EXACT_BUILD_STEP_SHA256'])
def workflow_pins(text):
 names=list(old_steps);headers=['      - name: '+name+'\n' for name in names];positions=[text.index(h) for h in headers]
 steps={name:sha(text[start+len(headers[i]):positions[i+1] if i+1<len(positions) else len(text)].encode()) for i,(name,start) in enumerate(zip(names,positions))}
 prefix=sha(text[:text.index('\njobs:\n')+1].encode())
 return dict(EXPECTED_EXACT_BUILD_STEP_SHA256=steps,EXPECTED_EXACT_BUILD_PREFIX_SHA256=prefix)
# The active dispatcher returns v2 directly. Preserve its unreachable legacy
# preparation constant; v2 binds the prefix and each complete named step.
for key,value in workflow_pins(old_exact).items():
 assert ast.literal_eval(ns[key])==value, 'Workflow preimage extraction differs: '+key
replacements=workflow_pins(new_exact)
semantic=ast.literal_eval(ns['EXPECTED_REPOSITORY_SEMANTIC_AUTHORITY_IDENTITIES'])
data=(root/'scripts/native_rust_kbuild_link_closure.py').read_bytes()
semantic['kbuild_link_closure']=dict(git_blob_sha1=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest(),sha256=sha(data),size=len(data))
replacements['EXPECTED_REPOSITORY_SEMANTIC_AUTHORITY_IDENTITIES']=semantic
edit_values(runtime,replacements);normalize(runtime,'ISOLATED_SELF_DIGEST')
capture='host-kernel/contracts/fp0006-runtime-capture-integration-v1.json'
update_json(capture,{runtime,workflow})
cap=identity(capture)
edit_values('scripts/fp0006_runtime_capture_integration.py',dict(EXPECTED_CONTRACT_SHA256=cap['sha256'],EXPECTED_CONTRACT_SIZE=cap['size'],EXPECTED_NATIVE_WORKFLOW_SHA256=identity(workflow)['sha256']))
executable='host-kernel/contracts/fp0006-executable-acceptance-closure-v1.json'
old=identity(executable)['sha256'];update_json(executable,{capture});new=identity(executable)
edit_values('scripts/fp0006_executable_acceptance_closure.py',dict(EXPECTED_CONTRACT_SHA256=new['sha256'],EXPECTED_CONTRACT_SIZE=new['size']))
normalize('scripts/fp0006_executable_acceptance_closure.py','SELF_DIGEST')
p=root/'scripts/tests/test_fp0006_executable_acceptance_closure.py';s=p.read_text();assert s.count(old)==1;p.write_text(s.replace(old,new['sha256']))
print('Updated current runtime/workflow and FP-0006 dependency bindings; historical authorities unchanged')
