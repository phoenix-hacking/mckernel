import json, os, tempfile, unittest
from pathlib import Path
from unittest import mock
HERE=Path(__file__).resolve().parent.parent/'scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/storage-fault-v1'
import importlib.util
def mod(n):
 s=importlib.util.spec_from_file_location(n,HERE/(n+'.py')); x=importlib.util.module_from_spec(s); s.loader.exec_module(x); return x
p=mod('prepare'); o=mod('oracle')
class StorageFaultPacketTests(unittest.TestCase):
 def test_source_and_guards(self):
  q=p.packet(HERE/'packet.json'); self.assertEqual([x['selector'] for x in q['cases']],list(range(6)))
  g=p.generate(p.read(p.SOURCE)); self.assertEqual(g.count(b'#include "inject.h"'),1); self.assertIn(b'M02_STORAGE_FAULT_CASE',g)
  with self.assertRaises(AssertionError): p.generate(p.read(p.SOURCE)+b'\n')
 def test_prepare_is_fresh_and_fsynced(self):
  with tempfile.TemporaryDirectory() as d:
   out=Path(d)/'x'; p.main # ensure public entrypoint exists
   import sys
   with mock.patch.object(sys,'argv',['prepare.py','--packet',str(HERE/'packet.json'),'--attempt-root',str(out)]): p.main()
   self.assertEqual(json.loads((out/'prepare.json').read_text())['status'],'PREPARED_NOT_EXECUTED')
   with mock.patch.object(sys,'argv',['prepare.py','--packet',str(HERE/'packet.json'),'--attempt-root',str(out)]):
    with self.assertRaises(FileExistsError): p.main()
 def test_oracle_negative_matrix(self):
  for sel,(wait,status,err,rf) in o.EXPECTED.items():
   with tempfile.TemporaryDirectory() as d:
    root=Path(d); (root/'original-report.json').write_bytes(b'original')
    w={'schema_version':1,'selector':sel,'raw_wait_status':wait,'status':status,'errno':err,'source_sha256':p.SOURCE_SHA,'nonce':'a'*32,'elf_sha256':'b'*64,'argv':['collector'],'environment':{},'collector_pid':1,'collector_startticks':2,'seam':'x','occurrence':1,'operation_boundary':'before-report','monotonic_ns':3,'file_fsync':True,'parent_fsync':True,'report_failure':rf,'original_report_sha256':o.sha(b'original')}
    if sel==2:w['prefix_bytes']=7
    (root/'witness.json').write_text(json.dumps(w)); self.assertTrue(o.validate(root,sel))
    for key,bad in [('raw_wait_status',0),('file_fsync',False),('original_report_sha256','0'*64),('nonce','x')]:
     w[key]=bad; (root/'witness.json').write_text(json.dumps(w))
     with self.assertRaises((AssertionError,ValueError)): o.validate(root,sel)
if __name__=='__main__': unittest.main()
