/work/mckernel-native-memory-images-20260909-2/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-memory-images-20260909-2/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.o

