#!/usr/bin/env python3
"""Direct, durable owner for the storage-fault-v2 collector (not a release)."""
import argparse
import ctypes
import errno
import hashlib
import json
import os
import select
import signal
import socket
import stat
import time
from pathlib import Path

WITNESS_FD = 198
PACKET_MAX = 4096
PACKET_LIMIT = 32
ACK_SECONDS = 2
OUTER_CLEANUP_SECONDS = 22
PR_SET_CHILD_SUBREAPER = 36

def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("nonfinite")))

def process_identity(pid):
    raw = Path("/proc/%d/stat" % pid).read_bytes()
    close = raw.rfind(b")")
    if close < 0:
        raise ValueError("proc stat")
    prefix = raw[:close + 1]
    open_paren = prefix.find(b"(")
    fields = raw[close + 2:].split()
    if open_paren < 1 or len(fields) < 20:
        raise ValueError("proc stat")
    return {"pid": int(prefix[:open_paren - 1]), "ppid": int(fields[1]),
            "startticks": int(fields[19])}

def complete_write(fd, raw):
    view = memoryview(raw)
    while view:
        try:
            count = os.write(fd, view)
        except InterruptedError:
            continue
        if count <= 0:
            raise OSError("short durable write")
        view = view[count:]

def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def stable_bytes(path, limit=1 << 26):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular evidence required")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                raise OSError("short evidence read")
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("evidence changed during read")
        return b"".join(chunks)
    finally:
        os.close(fd)

def file_record(path, shown_path):
    path = Path(path)
    try:
        raw = stable_bytes(path)
    except FileNotFoundError:
        return {"path": str(shown_path), "present": False,
                "size": None, "sha256": None}
    return {"path": str(shown_path), "present": True, "size": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}

def durable_file(path, raw, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, mode)
    try:
        complete_write(fd, raw)
        os.fsync(fd)
    finally:
        os.close(fd)

def effective_environment(nonce, hashes):
    return {"LANG": "C", "LC_ALL": "C", "PATH": "/usr/bin:/bin",
            "M02_SF_NONCE": nonce,
            "M02_SF_SOURCE_SHA256": hashes["source_sha256"],
            "M02_SF_GENERATED_SHA256": hashes["generated_sha256"],
            "M02_SF_HEADER_SHA256": hashes["header_sha256"],
            "M02_SF_ELF_SHA256": hashes["elf_sha256"]}

def bind_inputs(paths, hashes):
    limits = {"source": 1 << 20, "generated_source": 1 << 20,
              "header": 1 << 20, "elf": 16 << 20}
    hash_keys = {"source": "source_sha256",
                 "generated_source": "generated_sha256",
                 "header": "header_sha256", "elf": "elf_sha256"}
    records = {}
    for name in ("source", "generated_source", "header", "elf"):
        path = Path(paths[name])
        if not path.is_absolute() or path.resolve() != path:
            raise ValueError("canonical input path")
        raw = stable_bytes(path, limits[name])
        digest = hashlib.sha256(raw).hexdigest()
        if digest != hashes[hash_keys[name]]:
            raise ValueError("input hash " + name)
        records[name] = {"path": str(path), "present": True,
                         "size": len(raw), "sha256": digest}
    return records

def validate_executable(argv, inputs):
    if not argv or Path(argv[0]).resolve() != Path(argv[0]) or \
       argv[0] != inputs["elf"]["path"]:
        raise ValueError("executed ELF path")

class DurableJournal:
    def __init__(self, root):
        self.root = Path(root)
        if self.root.exists():
            raise FileExistsError("witness root exists")
        self.root.mkdir(mode=0o700)
        self.fd = os.open(self.root / "witness.jsonl",
                          os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC,
                          0o600)
        fsync_directory(self.root.parent)

    def append(self, packet, receipt_ns):
        record = json.dumps({"packet": packet, "receipt_monotonic_ns": receipt_ns},
                            sort_keys=True, separators=(",", ":")).encode() + b"\n"
        complete_write(self.fd, record)
        os.fsync(self.fd)
        fsync_directory(self.root)

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1

def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))

def observe_identity(pid, phase, expected=None, parent_pid=None):
    now = time.monotonic_ns()
    try:
        current = process_identity(pid)
    except FileNotFoundError:
        return {"kind": "identity", "phase": phase, "observation": "missing",
                "pid": pid, "ppid": None, "startticks": None,
                "matched": False, "monotonic_ns": now}
    except (OSError, ValueError):
        return {"kind": "identity", "phase": phase, "observation": "error",
                "pid": pid, "ppid": None, "startticks": None,
                "matched": False, "monotonic_ns": now}
    matched = (expected is None or current["startticks"] == expected["startticks"]) and \
        (parent_pid is None or current["ppid"] == parent_pid)
    return {"kind": "identity", "phase": phase, "observation": "observed",
            "pid": pid, "ppid": current["ppid"],
            "startticks": current["startticks"], "matched": matched,
            "monotonic_ns": now}

def matching_identity(pid, expected, parent_pid):
    return observe_identity(pid, "match", expected, parent_pid)["matched"]

def wait_direct(pid, deadline_ns, startticks=None, direct=True):
    while time.monotonic_ns() < deadline_ns:
        try:
            actual, raw = os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            return None
        if actual == pid:
            return {"kind": "wait", "pid": pid, "startticks": startticks,
                    "raw_wait_status": raw, "direct": direct,
                    "monotonic_ns": time.monotonic_ns()}
        time.sleep(0.01)
    return None

def adopted_identities(owner_pid, exclude):
    result = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) in exclude:
            continue
        record = observe_identity(int(entry.name), "adopted-scan",
                                  parent_pid=owner_pid)
        if record["matched"]:
            result.append(record)
    return result

def bounded_cleanup(pid, identity, owner_pid, trigger_kind, trigger_ns):
    start_ns = time.monotonic_ns()
    deadline_ns = trigger_ns + OUTER_CLEANUP_SECONDS * 1000000000
    events, adopted_reaps, unresolved = [], [], []
    ticks = identity.get("startticks") if identity else None
    waited = wait_direct(pid, min(deadline_ns, start_ns + 16000000000), ticks)
    if waited:
        events.append(waited)
    else:
        for phase, sig, wait_ns in (("term", signal.SIGTERM, 1000000000),
                                    ("kill", signal.SIGKILL, 5000000000)):
            first = observe_identity(pid, phase + "-identity-1", identity, owner_pid)
            second = observe_identity(pid, phase + "-identity-2", identity, owner_pid)
            events.extend((first, second))
            same_birth = first["startticks"] is not None and \
                first["startticks"] == second["startticks"]
            if not first["matched"] or not second["matched"] or not same_birth:
                unresolved.append(second)
                break
            signal_ticks = second["startticks"]
            os.kill(pid, sig)
            events.append({"kind": "signal", "pid": pid,
                           "startticks": signal_ticks, "signal": int(sig),
                           "monotonic_ns": time.monotonic_ns()})
            waited = wait_direct(pid, min(deadline_ns,
                                 time.monotonic_ns() + wait_ns), signal_ticks)
            if waited:
                events.append(waited)
                break
    for adopted in adopted_identities(owner_pid, {owner_pid, pid}):
        first = observe_identity(adopted["pid"], "adopted-identity-1",
                                 adopted, owner_pid)
        second = observe_identity(adopted["pid"], "adopted-identity-2",
                                  adopted, owner_pid)
        events.extend((first, second))
        if not first["matched"] or not second["matched"]:
            unresolved.append(second)
            continue
        os.kill(adopted["pid"], signal.SIGKILL)
        events.append({"kind": "signal", "pid": adopted["pid"],
                       "startticks": adopted["startticks"],
                       "signal": int(signal.SIGKILL),
                       "monotonic_ns": time.monotonic_ns()})
        adopted_wait = wait_direct(adopted["pid"], deadline_ns,
                                   adopted["startticks"], False)
        if adopted_wait:
            events.append(adopted_wait)
            adopted_reaps.append(adopted_wait)
        else:
            unresolved.append(observe_identity(adopted["pid"],
                              "adopted-unresolved", adopted, owner_pid))
    complete = waited is not None and not unresolved and \
        time.monotonic_ns() <= deadline_ns
    return {"complete": complete, "trigger_kind": trigger_kind,
            "trigger_ns": trigger_ns, "cleanup_start_ns": start_ns,
            "cleanup_deadline_ns": deadline_ns,
            "cleanup_finished_ns": time.monotonic_ns(), "events": events,
            "adopted_reaps": adopted_reaps, "unresolved": unresolved}, waited

def receive(endpoint, deadline):
    poller = select.poll()
    poller.register(endpoint.fileno(), select.POLLIN | select.POLLHUP | select.POLLERR)
    remaining = deadline - time.monotonic()
    if remaining <= 0 or not poller.poll(max(1, int(remaining * 1000))):
        raise TimeoutError("witness packet timeout")
    raw = endpoint.recv(PACKET_MAX + 1)
    if not raw:
        return None
    if len(raw) > PACKET_MAX:
        raise ValueError("oversized witness packet")
    return strict_json(raw)

def validate_common(packet, nonce, selector, sequence, hashes):
    required = {"schema_version", "nonce", "selector", "sequence", "kind",
                "phase", "monotonic_ns", "site", "object", "occurrence",
                "collector_pid", "collector_startticks",
                "source_sha256", "generated_sha256", "header_sha256", "elf_sha256"}
    if not required <= set(packet):
        raise ValueError("witness fields")
    if packet["schema_version"] != 2 or packet["nonce"] != nonce or \
       packet["selector"] != selector or packet["sequence"] != sequence:
        raise ValueError("witness identity")
    if type(packet["monotonic_ns"]) is not int or packet["monotonic_ns"] <= 0:
        raise ValueError("witness time")
    if packet["phase"] not in ("pre-fork", "post-fork") or \
       type(packet["site"]) is not str or type(packet["object"]) is not str or \
       type(packet["occurrence"]) is not int or packet["occurrence"] < 0 or \
       type(packet["collector_pid"]) is not int or \
       type(packet["collector_startticks"]) is not int:
        raise ValueError("witness common types")
    for key, value in hashes.items():
        if packet[key] != value:
            raise ValueError("witness hash")

def launch(argv, witness_root, nonce, selector, hashes, input_paths):
    if len(nonce) != 32 or any(char not in "0123456789abcdef" for char in nonce):
        raise ValueError("nonce")
    if selector not in range(7) or not argv or Path(argv[-1]) != Path(argv[-1]).resolve():
        raise ValueError("launch inputs")
    inputs = bind_inputs(input_paths, hashes)
    validate_executable(argv, inputs)
    subreaper()
    journal = DurableJournal(witness_root)
    witness_root = Path(witness_root).resolve()
    stdout_fd = os.open(witness_root / "stdout.bin",
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    stderr_fd = os.open(witness_root / "stderr.bin",
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    fsync_directory(witness_root)
    parent_endpoint = child_endpoint = None
    owner_pid = os.getpid()
    pid, identity, initial_identity = None, None, None
    packets, owner_failure = [], None
    environment = effective_environment(nonce, hashes)
    try:
        parent_endpoint, child_endpoint = socket.socketpair(
            socket.AF_UNIX, socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC)
        pid = os.fork()
    except Exception:
        os.close(stdout_fd); os.close(stderr_fd); journal.close()
        raise
    if pid == 0:
        try:
            parent_endpoint.close()
            os.dup2(child_endpoint.fileno(), WITNESS_FD, inheritable=True)
            os.dup2(stdout_fd, 1, inheritable=True)
            os.dup2(stderr_fd, 2, inheritable=True)
            child_endpoint.close()
            os.close(stdout_fd); os.close(stderr_fd)
            os.execve(argv[0], argv, environment)
        finally:
            os._exit(127)
    child_endpoint.close()
    child_endpoint = None
    os.close(stdout_fd); os.close(stderr_fd)
    initial_identity = observe_identity(pid, "initial", parent_pid=owner_pid)
    if initial_identity["matched"]:
        identity = {"pid": pid, "ppid": initial_identity["ppid"],
                    "startticks": initial_identity["startticks"]}
    trigger_ns = time.monotonic_ns()
    trigger_kind = "normal-eof"
    try:
        sequence = 0
        while len(packets) <= PACKET_LIMIT:
            receive_seconds = 10 if sequence == 0 else OUTER_CLEANUP_SECONDS
            packet = receive(parent_endpoint, time.monotonic() + receive_seconds)
            if packet is None:
                trigger_ns = time.monotonic_ns()
                break
            if len(packets) == PACKET_LIMIT:
                raise ValueError("witness packet limit")
            validate_common(packet, nonce, selector, sequence, hashes)
            if identity is None or packet["collector_pid"] != pid or \
               packet["collector_startticks"] != identity["startticks"]:
                raise ValueError("collector witness identity")
            journal.append(packet, time.monotonic_ns())
            packets.append(packet)
            if sequence == 0:
                if packet["kind"] != "READY" or not matching_identity(
                        pid, identity, owner_pid):
                    raise ValueError("ready identity")
                parent_endpoint.sendall(("RELEASE %s\n" % nonce).encode())
            else:
                parent_endpoint.sendall(("ACK %s %d\n" % (nonce, sequence)).encode())
            sequence += 1
    except Exception as error:
        owner_failure = {"type": type(error).__name__, "message": str(error)}
        trigger_kind = "owner-failure"
        trigger_ns = time.monotonic_ns()
    finally:
        if parent_endpoint is not None:
            parent_endpoint.close()
        cleanup, waited = bounded_cleanup(pid, identity, owner_pid,
                                           trigger_kind, trigger_ns)
        for capture in (witness_root / "stdout.bin", witness_root / "stderr.bin"):
            fd = os.open(capture, os.O_RDONLY | os.O_CLOEXEC)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        fsync_directory(witness_root)
        collection = Path(argv[-1]).resolve()
        result = {"schema_version": 2, "kind": "OWNER_RESULT",
                  "nonce": nonce, "selector": selector, "argv": list(argv),
                  "environment": environment,
                  "collector": {"pid": pid,
                      "identity_observed": identity is not None,
                      "ppid": identity["ppid"] if identity else None,
                      "startticks": identity["startticks"] if identity else None,
                      "reaped": waited is not None,
                      "raw_wait_status": waited["raw_wait_status"] if waited else None},
                  "packet_count": len(packets),
                  "hashes": {key: hashes[key] for key in
                      ("source_sha256", "generated_sha256", "header_sha256", "elf_sha256")},
                  "inputs": inputs,
                  "captures": {
                      "stdout": file_record(witness_root / "stdout.bin", "stdout.bin"),
                      "stderr": file_record(witness_root / "stderr.bin", "stderr.bin")},
                  "artifacts": {name: file_record(collection / filename,
                      collection / filename) for name, filename in
                      (("events", "events.jsonl"), ("request", "request.bin"),
                       ("report", "report.json"))},
                  "owner_failure": owner_failure, "cleanup": cleanup,
                  "backend_enabled": False, "application_acceptance": False}
        result_raw = (json.dumps(result, sort_keys=True,
                      separators=(",", ":")) + "\n").encode()
        durable_file(witness_root / "owner-result.json", result_raw)
        fsync_directory(witness_root)
        journal.append(result, time.monotonic_ns())
        journal.close()
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--witness-root", type=Path, required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--selector", type=int, choices=range(7), required=True)
    parser.add_argument("--hashes", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--generated-source", type=Path, required=True)
    parser.add_argument("--header", type=Path, required=True)
    parser.add_argument("--elf", type=Path, required=True)
    parser.add_argument("argv", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.argv:
        raise SystemExit("collector argv required")
    hashes = strict_json(args.hashes.read_bytes())
    input_paths = {"source": args.source.resolve(),
                   "generated_source": args.generated_source.resolve(),
                   "header": args.header.resolve(), "elf": args.elf.resolve()}
    result = launch(args.argv, args.witness_root, args.nonce, args.selector,
                    hashes, input_paths)
    print(json.dumps(result, sort_keys=True))

if __name__ == "__main__":
    main()
