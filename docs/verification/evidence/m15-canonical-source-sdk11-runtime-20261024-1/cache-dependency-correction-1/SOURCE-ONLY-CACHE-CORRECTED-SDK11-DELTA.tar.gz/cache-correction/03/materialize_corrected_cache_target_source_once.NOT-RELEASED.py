"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One exact finite target-source copy from accepted source snapshot and seven tool
postimages. Reuses the accepted source materializer stable-FD/no-hardlink loop.
No compiler/root/Docker/guest/canonical mutation; root supplies ordinary grant.
"""
from pathlib import Path
import hashlib,json,os,stat,time
PLAN=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/EXACT-CANONICAL42-PLUS-RETAINED-BASELINE-SOURCE.PLAN.json')
PLAN_SHA='01d2a0e948c8236fd5fff01d90ffb27f9c6b3f2a8e3853da401cc588a8c7d124'
OUT=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1')
def need(ok,why):
 if not ok:raise RuntimeError(why)
def write(path,value):
 with path.open('x') as f:json.dump(value,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 begin=time.monotonic();need(os.getuid()==os.geteuid()==1000 and os.sched_getaffinity(0)=={0},'ordinary CPU0 grant')
 raw=PLAN.read_bytes();need(hashlib.sha256(raw).hexdigest()==PLAN_SHA,'exact finite source plan');p=json.loads(raw);dest=Path(p['destination'])
 need(not os.path.lexists(OUT) and not os.path.lexists(dest),'fresh source namespace')
 need(len(p['entries'])==p['files'] and sum(r['size'] for r in p['entries'])==p['bytes']<256<<20,'source bound')
 need(int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=25501368320,'fresh aggregate floor')
 host=os.statvfs(OUT.parent);scratch=os.statvfs('/home/holden/mckernel-work/scratch');back=Path('/home/holden/mckernel-work/scratch.ext4').stat();gap=max(0,back.st_size-back.st_blocks*512)
 need(host.f_bavail*host.f_frsize>=16*2**30+gap+p['bytes']+(16<<20) and scratch.f_bavail*scratch.f_frsize>=12*2**30,'floors/fullgap/complete growth')
 OUT.mkdir(mode=0o700);dest.mkdir(mode=0o700);copied=0
 with (OUT/'materialization-journal.jsonl').open('x') as journal:
  for row in p['entries']:
   rel=Path(row['relative']);need(not rel.is_absolute() and '..' not in rel.parts,'safe finite relative')
   source=Path(row['source']);target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);before=source.lstat()
   if row['kind']=='symlink':
    raw=os.fsencode(os.readlink(source));need(stat.S_ISLNK(before.st_mode) and raw==os.fsencode(row['target']) and hashlib.sha256(raw).hexdigest()==row['sha256'],'exact tracked symlink');target.symlink_to(row['target'])
   else:
    need(stat.S_ISREG(before.st_mode) and source.resolve()==source and before.st_size==row['size'],'known source regular/size')
    fd=os.open(source,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC);h=hashlib.sha256();count=0
    with os.fdopen(fd,'rb') as inp,target.open('xb') as out:
     opened=os.fstat(inp.fileno())
     for block in iter(lambda:inp.read(1<<20),b''):h.update(block);out.write(block);count+=len(block)
     out.flush();os.fsync(out.fileno());closed=os.fstat(inp.fileno())
    after=source.lstat();fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(all(getattr(before,k)==getattr(opened,k)==getattr(closed,k)==getattr(after,k) for k in fields) and count==row['size'] and h.hexdigest()==row['sha256'],'stable exact source copy')
    target.chmod(row['mode']);need(target.stat().st_nlink==1,'never hardlink')
   journal.write(json.dumps(row,sort_keys=True)+'\n');journal.flush();copied+=row['size']
 seen=set()
 for directory,dirs,names in os.walk(dest,followlinks=False):
  need(all(not (Path(directory)/n).is_symlink() for n in dirs),'no directory symlink')
  seen.update(str((Path(directory)/name).relative_to(dest)) for name in names)
 need(seen=={r['relative'] for r in p['entries']},'exact finite source closure')
 result=dict(status='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY',plan=dict(path=str(PLAN),sha256=PLAN_SHA),source_root=str(dest),source_identity=dict(path=str(dest),device=dest.stat().st_dev,inode=dest.stat().st_ino,mode=stat.S_IMODE(dest.stat().st_mode),uid=dest.stat().st_uid,gid=dest.stat().st_gid),files=len(seen),copied_bytes=copied,source_overrides=p['source_overrides'],compiler_or_native=False,seconds=time.monotonic()-begin)
 write(OUT/'MATERIALIZATION-RESULT.json',result);print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
