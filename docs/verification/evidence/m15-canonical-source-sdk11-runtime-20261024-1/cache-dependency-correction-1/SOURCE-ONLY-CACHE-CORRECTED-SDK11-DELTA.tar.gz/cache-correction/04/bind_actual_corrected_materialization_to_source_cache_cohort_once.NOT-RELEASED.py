"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Bind genuine source materialization into the existing owner/driver/metadata protocol.
No owner/driver/API/query/container/compile runs. Every generated file is exclusive.
"""
from pathlib import Path
import ast,hashlib,json,os,stat
BASE = '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1'
FINAL = Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/selected-source-1')
MATERIAL = Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1/MATERIALIZATION-RESULT.json')
PLAN = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/EXACT-CANONICAL42-PLUS-RETAINED-BASELINE-SOURCE.PLAN.json', 'sha256': '01d2a0e948c8236fd5fff01d90ffb27f9c6b3f2a8e3853da401cc588a8c7d124', 'bytes': 3257299}
CONFIG_TEMPLATE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/TARGET-DRIVER.CANONICAL-INPUTS.CACHE-BOUND.ACTUAL-COPY-PENDING.json', 'sha256': '630b1f0b1b68de2d227e4c3b63b68c45632a9a6b8f94fb57201f7f71c4415132', 'bytes': 142918}
PREP_TEMPLATE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/PREPARATION.CANONICAL-INPUTS.CACHE-BOUND.ACTUAL-COPY-PENDING.json', 'sha256': '680a144b21947a0dae2ddf5572b51f821521f0543a3d9a8fe9ed2413b998a151', 'bytes': 138541}
DRIVER_TEMPLATE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/target_tools_sdk_driver.CANONICAL-PRODUCER.SOURCE-PREPARED.py', 'sha256': 'f63acb9ac2e51715b99e24a55a0848babe68c2f5e984e1a561aec1a6f1279a38', 'bytes': 19551}
OWNER_TEMPLATE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/target_tools_sdk_owner.CANONICAL-PRODUCER.CACHE-BOUND.SOURCE-PREPARED.py', 'sha256': 'b6d9a60520b0cf6ef9a672053d1522b13a60a3276395286c75e2e0f67528d9c3', 'bytes': 175378}
METADATA_TEMPLATE={'bytes': 10445, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/publish_mountpoint_and_target_metadata_and_final11_once.SCHEMA-FINAL.NOT-RELEASED.py', 'sha256': '342edad9193799251335762e3c02c122738aa43156e57877f91a16372d60cac9'}
REQUEST_TEMPLATE={'bytes': 3018, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/REQUEST.MOUNTPOINT-BOUND.FINAL.NAMESPACE-PENDING.json', 'sha256': '1688f430342328ea8763dff97fb24d5dab66d752603d587d55d7d4487bbded2d'}
RELEASE_TEMPLATE={'bytes': 4598, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/default-selector-coherent-successor-1/target-toolchain-cache-qualified-source-1/actual-SDK-DSO-bound-target-plan-1/owner-materialization-preparation-1/three-input-RO-completion-1/libdwarf-configure-closure-correction-1/mountpoint-protocol-completion-1/RELEASE.MOUNTPOINT-SCHEMA-FINAL.NO-CLOCK-NO-APPROVAL.json', 'sha256': 'b7196f795a6abed967e1d7529aaf98d714418daa67fffc4b3d675d8fbadc834d'}
PROOF = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/STATIC-CACHE-CORRECTION-SOURCE-JOIN.json', 'sha256': '91c7851913dbedecffea66f968e2fb526893d20fbaa9f9bd3b3830d99a20cce9', 'bytes': 13150}

def need(ok,why):
 if not ok:raise ValueError(why)
def read(ref):
 p=Path(ref['path']);raw=p.read_bytes();need(len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'exact template input');return raw
def put(name,value):
 p=FINAL/name;raw=value.encode() if isinstance(value,str) else (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def assign(source,values):
 lines=source.splitlines(True)
 for n in reversed(ast.parse(source).body):
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in values:
   value=values[n.targets[0].id];lines[n.lineno-1:n.end_lineno]=[n.targets[0].id+' = '+repr(value)+'\n']
 return ''.join(lines)
def main():
 need(os.getuid()==os.geteuid()==os.getgid()==1000 and not FINAL.exists(),'ordinary fresh metadata binding')
 plan=json.loads(read(PLAN));raw=MATERIAL.read_bytes();material=json.loads(raw)
 need(material['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and material['plan']==dict(path=PLAN['path'],sha256=PLAN['sha256']) and material['source_root']==plan['destination'] and material['source_overrides']==plan['source_overrides'],'actual matching source copy')
 mat=dict(path=str(MATERIAL),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 parent=Path(plan['destination'])/'executer/user/lib/libdwarf';need(parent.resolve()==parent and parent.is_dir() and not os.path.lexists(parent/'libdwarf'),'fresh exact nested vendor mountpoint')
 s=parent.stat();pid=dict(path=str(parent),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode));need(s.st_uid==s.st_gid==1000,'actual source parent owner')
 FINAL.mkdir(mode=0o700)
 c=json.loads(read(CONFIG_TEMPLATE));c['actual_fresh_materialized_source']=mat;c['accepted_input_records'].append(mat);config=put('TARGET-DRIVER.CANONICAL-INPUTS.json',c)
 driver=read(DRIVER_TEMPLATE).decode().replace('ACTUAL_CONFIG_SHA_TO_BIND_AFTER_MATERIALIZATION',config['sha256']);dr=put('target_tools_sdk_driver.py',driver)
 prep=json.loads(read(PREP_TEMPLATE));prep['materialized_source']['result']=mat;prep['closure'].append(config);prep['references']['actual_materialization']=mat;pr=put('preparation.json',prep)
 owner=read(OWNER_TEMPLATE).decode();owner=assign(owner,dict(PREPARATION_SHA=pr['sha256'],LIBRARY_PREPARATION=prep));ow=put('target_tools_sdk_owner.py',owner)
 request=json.loads(read(REQUEST_TEMPLATE));request.update(request_path=str(FINAL/'REQUEST.ROOT.FINAL.json'),input_root=str(FINAL),preparation=dict(path=pr['path'],sha256=pr['sha256']),driver=dr,nonce=None,candidate_root=None,candidate_identity=None,owner_evidence_root=None,input_identity=None,output_parent_identity=None,libdwarf_mountpoint_identity=None);rq=put('REQUEST.CANONICAL.NAMESPACE-PENDING.json',request)
 release=json.loads(read(RELEASE_TEMPLATE));release.update(nonce=None,request=dict(path=str(FINAL/'REQUEST.ROOT.FINAL.json'),sha256=None));release['source_sha256']['scripts/native_running_external_modules_owner.py']=ow['sha256'];release['source_sha256']['scripts/native_running_external_modules_offline.py']=dr['sha256'];rl=put('RELEASE.CANONICAL.NO-CLOCK-NO-APPROVAL.json',release)
 helper=read(METADATA_TEMPLATE).decode();helper=assign(helper,dict(REQUEST=rq,RELEASE=rl,OWNER=ow,DRIVER=dr,PREPARATION=pr,CONFIGURATION=config,MATERIAL=mat,PROOF=PROOF,MOUNTPOINT=str(parent/'libdwarf'),MOUNTPOINT_PARENT=pid));hr=put('publish_mountpoint_and_target_metadata_and_final11_once.NOT-RELEASED.py',helper)
 proof=json.loads(read(PROOF));need(proof['missing']==[],'source route join')
 need(set(request)==set(ast.literal_eval(next(n.value for n in ast.walk(next(n for n in ast.parse(owner).body if isinstance(n,ast.FunctionDef) and n.name=='validate_request')) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='required' for t in n.targets)))),'exact request schema')
 ready=dict(scope=c['scope'],owner=ow,driver=dr,preparation=pr,config=config,request=rq,release=rl,metadata_helper=hr,metadata_argv=['/home/holden/anaconda3/bin/python3','-I','-B',hr['path'],'--publish-metadata-once'],actual_source_materialization=mat,canonical_source_producer=True,actual_metadata=None,actual_query=None,actual_release=None,actual_compile=None)
 print(json.dumps(put('READY.ACTUAL-CANONICAL-SOURCE-COHORT.NOT-RELEASED.json',ready),sort_keys=True))
if __name__=='__main__':main()
