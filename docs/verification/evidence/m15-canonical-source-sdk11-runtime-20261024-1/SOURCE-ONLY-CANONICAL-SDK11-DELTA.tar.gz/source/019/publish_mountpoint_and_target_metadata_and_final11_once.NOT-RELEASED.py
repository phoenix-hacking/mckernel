"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One ordinary UID1000 metadata publication: exclusive empty HOST candidate and
exact completed request/11-source map. No owner import/API/query/release execution.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,uuid
D=Path(__file__).resolve().parent
REQUEST = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/REQUEST.CANONICAL.NAMESPACE-PENDING.json', 'sha256': 'ea9ba0435c5ecdf1a307242cfd31d357665209f8f9d2009cec5f47e53821b5b2', 'bytes': 2271}
RELEASE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/RELEASE.CANONICAL.NO-CLOCK-NO-APPROVAL.json', 'sha256': 'db715a89dc6e039241883165b622c31c6c3b189d8aaefaf777d1d88a2e4cdbae', 'bytes': 4413}
OWNER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/target_tools_sdk_owner.py', 'sha256': 'e76da088f803190e0836963f9a8179298feb9348c6b820cf31d5f041829bf5d7', 'bytes': 183347}
DRIVER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/target_tools_sdk_driver.py', 'sha256': '0ee658c1d10edba2df0b7a907e8aa84ee4747ed0fe84bb41e6118b5f0dfa7a33', 'bytes': 19472}
MATERIAL = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/source-materialization-1/MATERIALIZATION-RESULT.json', 'sha256': 'a804dc6a6acb6aa0ff382c0412dc3b4fdcb6d06265c3948089a045178e5aa7f8', 'bytes': 10895}
PROOF = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/STATIC-CANONICAL42-SOURCE-AND-EXTERNAL-OFF-JOIN.json', 'sha256': '48e40ce4e39a09e877e06107c4b2f2b29f6d5bf5a8b7aeed2b45b35dd0a4b2f5', 'bytes': 12303}

PREPARATION = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/preparation.json', 'sha256': '9cea8a4e0503b93b8ec22c3d5bfba0948fae66a3d3cf699ca1c437d12069d52e', 'bytes': 138466}
CONFIGURATION = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/selected-source-1/TARGET-DRIVER.CANONICAL-INPUTS.json', 'sha256': '7612b9d34f2b0afe4af6a483341135a6fda585853538dc1704a6ec41d7b8fa56', 'bytes': 142908}

def need(ok,message):
 if not ok:raise ValueError(message)
def read(ref):
 p=Path(ref['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=32<<20,'bounded regular input');blocks=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   blocks.append(b)
  raw=b''.join(blocks);z=os.fstat(fd);n=p.lstat();keys=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(a,k)==getattr(z,k)==getattr(n,k) for k in keys) and len(raw)==z.st_size and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'stable9 pinned input');return raw
 finally:os.close(fd)
def node(path):
 p=Path(path);need(p.is_dir() and not p.is_symlink(),'owned directory');s=p.stat();need(s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700,'private directory identity');return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
def publish(path,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 parent=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(parent)
 finally:os.close(parent)
 return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
MOUNTPOINT = '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf/libdwarf'
MOUNTPOINT_PARENT = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf', 'device': 66306, 'inode': 56775037, 'uid': 1000, 'gid': 1000, 'mode': 448}

def create_vendor_mountpoint():
 path=Path(MOUNTPOINT);parent=path.parent
 need(parent.resolve()==parent,'literal non-symlink mountpoint parent')
 fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);expected=MOUNTPOINT_PARENT
  actual=dict(path=str(parent),device=a.st_dev,inode=a.st_ino,uid=a.st_uid,gid=a.st_gid,mode=stat.S_IMODE(a.st_mode))
  need(actual==expected and a.st_uid==a.st_gid==1000,'exact retained mountpoint parent')
  need(not os.path.lexists(path),'mountpoint absent before exclusive creation')
  os.mkdir(path.name,mode=0o700,dir_fd=fd)
  child=os.open(path.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
  try:
   s=os.fstat(child);n=path.lstat()
   need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700 and s.st_dev==a.st_dev,'owned mountpoint mode/device')
   need(s.st_dev==n.st_dev and s.st_ino==n.st_ino and os.listdir(child)==[],'empty exact created mountpoint inode')
   identity=dict(path=str(path),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
   os.fsync(child)
  finally:os.close(child)
  z=os.fstat(fd);need(z.st_dev==a.st_dev and z.st_ino==a.st_ino and os.stat(parent).st_ino==a.st_ino,'parent identity retained');os.fsync(fd)
  return identity
 finally:os.close(fd)

def main():
 need(sys.argv[1:]==['--publish-metadata-once'] and os.getuid()==os.geteuid()==os.getgid()==1000,'exact ordinary UID1000 metadata invocation')
 request=json.loads(read(REQUEST));release=json.loads(read(RELEASE));read(OWNER);read(DRIVER);read(PREPARATION);read(CONFIGURATION);material=json.loads(read(MATERIAL));proof=json.loads(read(PROOF));need(proof['missing']==[],'complete static read-path join')
 need(material['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and node(material['source_root'])==material['source_identity'],'actual materialized source identity')
 need(not (D/'workspace').exists() and not (D/'REQUEST.ROOT.FINAL.json').exists(),'fresh finite namespace/publication')
 mountpoint_identity=create_vendor_mountpoint()
 nonce=uuid.uuid4().hex;parent=D/'workspace';parent.mkdir(mode=0o700);candidate=parent/('native-running-modules-candidate-'+nonce);candidate.mkdir(mode=0o700);evidence=parent/('native-running-modules-owner-'+nonce)
 request.update(libdwarf_mountpoint_identity=mountpoint_identity,nonce=nonce,candidate_root=str(candidate),candidate_identity=node(candidate),owner_evidence_root=str(evidence),input_root=str(D),input_identity=node(D),output_parent_identity=node(parent))
 need(request['request_path']==str(D/'REQUEST.ROOT.FINAL.json') and not evidence.exists() and list(candidate.iterdir())==[],'exact nonce-bound request/freshness')
 rq=publish(D/'REQUEST.ROOT.FINAL.json',request);release.update(nonce=nonce,request=dict(path=rq['path'],sha256=rq['sha256']),status='PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW')
 rl=publish(D/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json',release)
 finalmap=publish(D/'ACTUAL-FINAL-ELEVEN-SOURCE-MAP.json',dict(source_sha256=release['source_sha256'],owner=OWNER,driver=DRIVER,preparation=PREPARATION,configuration=CONFIGURATION,request=rq,nonce=nonce,source_materialization=MATERIAL,execution_release=False))
 result=dict(libdwarf_mountpoint_identity=mountpoint_identity,mountpoint_parent_identity=MOUNTPOINT_PARENT,original_copy_result_preserved=MATERIAL,status='PASS_EXCLUSIVE_TARGET_METADATA_NAMESPACE_AND_REQUEST_ONLY',request=rq,release_pending=rl,final_eleven_source_map=finalmap,nonce=nonce,owner=OWNER,driver=DRIVER,source_sha256=release['source_sha256'],candidate_identity=node(candidate),output_parent_identity=node(parent),input_identity=node(D),actual_source_materialization=MATERIAL,read_path_proof=PROOF,execution_release=False)
 rr=publish(D/'ACTUAL-METADATA-PUBLICATION-RECEIPT.json',result);print(json.dumps(dict(receipt=rr,**result),sort_keys=True))
if __name__=='__main__':main()
