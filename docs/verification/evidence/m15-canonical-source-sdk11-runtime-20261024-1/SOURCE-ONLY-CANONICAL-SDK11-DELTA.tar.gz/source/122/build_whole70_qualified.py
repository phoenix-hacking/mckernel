"""Build orchestration only; functional McKernel OS/Rust work, no security testing.
Generate real selected-header metadata, then compile one existing Rust staticlib.
No device/library API is executed. Lifecycle/resource ownership belongs to the
existing CMake build owner. This helper adds no independent runtime controller.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shlex
import subprocess
from rust_diagnostics import qualify_rust_diagnostics


def require(ok, message):
    if not ok:
        raise ValueError(message)


def replace_bytes(path, data):
    temporary = path.with_name(path.name + ".new")
    with temporary.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cc", required=True)
    parser.add_argument("--rustc", required=True)
    parser.add_argument("--source-dir", required=True)
    parser.add_argument("--include-dir", action="append", required=True)
    parser.add_argument("--out-dir", required=True)
    args = parser.parse_args()
    source = Path(args.source_dir).resolve()
    output = Path(args.out_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    rows = []

    def run(argv, label, environment=None):
        stdout = output / (label + ".stdout")
        stderr = output / (label + ".stderr")
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(argv, cwd=output, env=environment, stdout=out, stderr=err)
        rows.append(dict(argv=argv, returncode=result.returncode, stdout=str(stdout),
                         stderr=str(stderr)))
        require(result.returncode == 0, "failed build phase " + label)
        require(stdout.stat().st_size <= 1 << 20 and stderr.stat().st_size <= 1 << 20,
                "bounded metadata/compiler diagnostics " + label)
        return stdout.read_bytes(), stderr.read_bytes()

    include = ["-I" + path for path in args.include_dir]
    common = [args.cc, "-std=gnu11", "-O0", "-Wall", "-Wextra", "-Werror"] + include
    witnesses = [
        ("perf_pages_abi_witness.c", "perf", []),
        ("dump_abi_witness.c", "dump", ["-DPAGE_SIZE=4096"]),
        ("diagnostic_origins.selected_target_C_witness.c", "origins", []),
        ("combined_selected_SDK_actual_header_ABI.c", "platform", ["-DPAGE_SIZE=4096"]),
    ]
    for filename, label, defines in witnesses:
        out, err = run(common + defines + [str(source / "abi" / filename), "-o",
                       str(output / (label + "-witness"))], label + "-compile")
        require(out == err == b"", "unexpected header compiler diagnostics")
    generators = [
        ("perf", [], "perf_pages_abi.rs"),
        ("dump", [], "dump_abi.rs"),
        ("origins", ["raw"], "diagnostic_origins.rs"),
        ("origins", ["create"], "create_diagnostic_origins.rs"),
    ]
    for label, arguments, filename in generators:
        out, err = run([str(output / (label + "-witness"))] + arguments, filename)
        require(out and b"pub const " in out and not err, "real header metadata")
        replace_bytes(output / filename, out)
    out, err = run([str(output / "platform-witness")], "platform-select")
    require(out == b"ihklib_stat_abi_stat\n" and not err, "actual supported stat ABI")
    stat_cfg = out.decode().strip()
    replace_bytes(output / "actual-stat-cfg.txt", out)
    environment = dict(os.environ)
    for key, name in [
        ("MCKERNEL_DUMP_ABI_RS", "dump_abi.rs"),
        ("MCKERNEL_PERF_PAGES_ABI_RS", "perf_pages_abi.rs"),
        ("MCKERNEL_IHKLIB_DIAGNOSTIC_ORIGINS_RS", "diagnostic_origins.rs"),
        ("MCKERNEL_IHKLIB_CREATE_DIAGNOSTIC_ORIGINS_RS", "create_diagnostic_origins.rs"),
    ]:
        environment[key] = str(output / name)
    archive = output / "libihklib_whole70.a"
    temporary_archive = output / "libihklib_whole70.a.new"
    argv = [args.rustc, "--edition=2021", "--crate-name", "ihklib_supported_whole70_host",
            "--crate-type", "staticlib", "--cfg", "ihklib_host_std_runtime", "--cfg",
            stat_cfg, "-C", "panic=abort", "-C", "codegen-units=1", "-C",
            "relocation-model=pic", "-C", "opt-level=2", "--print", "native-static-libs",
            "-o", str(temporary_archive), str(source / "libihklib_whole70.rs")]
    out, err = run(argv, "whole70-rust", environment)
    require(not out, "no compiler stdout")
    native = qualify_rust_diagnostics(err, source)
    require(temporary_archive.is_file() and temporary_archive.stat().st_size > 0,
            "actual Rust staticlib output")
    replace_bytes(output / "native-static-libs.rsp", ("\n".join(native) + "\n").encode())
    os.replace(temporary_archive, archive)
    replace_bytes(output / "producer-receipt.json", (json.dumps(dict(
        status="PASS_REAL_HEADERS_AND_ONE_RUST_STATICLIB_BUILD_ONLY", commands=rows,
        stat_cfg=stat_cfg, native_static_libs=native, archive=str(archive),
        C_runtime_TU=False, native=False), sort_keys=True, indent=2) + "\n").encode())


if __name__ == "__main__":
    main()
