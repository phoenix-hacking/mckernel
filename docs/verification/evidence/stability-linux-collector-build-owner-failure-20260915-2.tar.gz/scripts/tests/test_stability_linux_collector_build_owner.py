"""Executable contract tests for the durable collector-build owner.

These tests stub Docker and never acquire the production lock or start a
container.
"""
import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest import mock

OWNER = Path(__file__).parents[2] / 'docs/verification/evidence/stability-linux-collector-build-owner-20260915.py'
spec = importlib.util.spec_from_file_location('collector_build_owner', OWNER)
owner = importlib.util.module_from_spec(spec); spec.loader.exec_module(owner)


class OwnerContractTests(unittest.TestCase):
    def test_create_is_pinned_and_restricted(self):
        argv = owner.profile('mckernel-collector-' + 'a' * 32, 'a' * 32, Path('/tmp/out'))
        self.assertEqual(argv[argv.index('--cpus=4')], '--cpus=4')
        self.assertIn('--cpuset-cpus=2-5', argv)
        self.assertIn('--memory=12g', argv); self.assertIn('--memory-swap=12g', argv)
        self.assertIn('--pids-limit=512', argv); self.assertIn('--cap-drop=ALL', argv)
        self.assertIn('--security-opt=no-new-privileges', argv)
        self.assertIn('--read-only', argv); self.assertIn('--network=none', argv)
        self.assertIn('--user=1000:1000', argv); self.assertIn('--ulimit', argv)
        self.assertEqual(argv[argv.index('--entrypoint=/usr/bin/python3') + 1], owner.IMAGE)
        self.assertEqual(argv[-1], '/workspace/docs/verification/evidence/stability-linux-collector-rebuild-20260915.py')

    def test_cleanup_retries_and_requires_exact_absence(self):
        row = {'State': {'Running': False, 'Paused': False}}
        with tempfile.TemporaryDirectory() as td, mock.patch.object(owner, 'owned', side_effect=[row, row, None, None]):
            with mock.patch.object(owner, 'docker', return_value=mock.Mock(returncode=0)) as run:
                result = owner.cleanup('a' * 32, 'mckernel-collector-build-' + 'a' * 32, 'b' * 64, Path(td))
        self.assertTrue(result['absence_verified'])
        self.assertTrue(result['evidence_complete'])
        self.assertEqual([call.args[0][1] for call in run.call_args_list], ['rm'])

    def test_cleanup_preserves_failure_and_never_claims_acceptance(self):
        with tempfile.TemporaryDirectory() as td, mock.patch.object(owner, 'owned', side_effect=RuntimeError('identity drift')):
            with mock.patch.object(owner.time, 'sleep'):
                result = owner.cleanup('a' * 32, 'mckernel-collector-build-' + 'a' * 32, 'b' * 64, Path(td))
        self.assertFalse(result['absence_verified']); self.assertFalse(result['evidence_complete'])
        self.assertFalse(result['application_acceptance']); self.assertEqual(len(result['attempts']), 8)

    def test_owner_source_has_failure_gates_and_full_id_disarm(self):
        source = OWNER.read_text()
        self.assertIn("result.get('start_returncode') == 0", source)
        self.assertIn("cleanup_result.get('evidence_complete') is True", source)
        self.assertIn("result.get('watchdog_raw_wait_status') == 0", source)
        self.assertIn("'DISARM ' + nonce + ' ' + cid", source)
        self.assertIn("signal.SIGINT, signal.SIGTERM, signal.SIGHUP", source)
        self.assertNotIn("'--group-add=1000'", source)


if __name__ == '__main__': unittest.main()
