from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,importlib.util,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/ultra-test-plan-protocol-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',commands=[],started_utc=datetime.now(timezone.utc).isoformat(),application_tests_passed=0,runtime_authorized=False,scope='Draft planning metadata and negative rejection checks only; no payload execution, sandbox enforcement or application acceptance')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,args):
 print('RUN',label,flush=True)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 record['commands'].append(dict(label=label,command=args,exit_code=r.returncode));assert r.returncode==0,(label,(out/(label+'.log')).read_text())
try:
 shutil.copyfile(__file__,out/'helper.py');src=out/'application-tests';shutil.copytree(repo/'scripts/application-tests',src)
 assert (src/'README.md').is_file() and (src/'handoff-start.md').is_file()
 record['inputs']=[ident(p) for p in sorted(src.rglob('*')) if p.is_file()]
 run('catalog',['python3','-B',str(src/'validate.py')])
 run('context',['python3','-B',str(src/'validate.py'),'--packet',str(src/'packets/packet-001.json'),'--emit-context',str(out/'packet-001-context.json')])
 run('vector-context',['python3','-B',str(src/'validate.py'),'--packet',str(src/'packets/packet-007.json'),'--emit-context',str(out/'packet-007-context.json')])
 spec=importlib.util.spec_from_file_location('validator',src/'validate.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 catalog=json.loads((src/'cases.json').read_text());packet=json.loads((src/'packets/packet-001.json').read_text());cases=module.validate_catalog(catalog)
 queue=json.loads((src/'draft-queue.json').read_text());rows,canonical=module.validate_queue(queue,catalog,cases,src)
 tests=[];record['negative_checks']=tests;negative=out/'negative-inputs';negative.mkdir()
 def reject(name,fn,mutation,reason):
  captured=negative/(name+'.json');captured.write_text(json.dumps(mutation,indent=2,sort_keys=True)+'\n')
  try:fn()
  except ValueError as e:
   assert reason in str(e),(name,'unexpected rejection reason',str(e))
   tests.append(dict(name=name,status='PASS',error=str(e),input=ident(captured)));return
  raise AssertionError(name+' incorrectly accepted')
 def reject_catalog(name,change,reason):
  value=copy.deepcopy(catalog);change(value);reject(name,lambda:module.validate_catalog(value),value,reason)
 def reject_packet(name,change,reason):
  value=copy.deepcopy(packet);change(value);reject(name,lambda:module.validate_packet(value,catalog,cases),value,reason)
 def reject_queue(name,change,reason):
  value=copy.deepcopy(queue);change(value);reject(name,lambda:module.validate_queue(value,catalog,cases,src),value,reason)
 reject_catalog('dependency-cycle',lambda c:c['cases'][0].update(depends_on=[c['cases'][0]['id']]),'dependency cycle')
 reject_catalog('unknown-capability',lambda c:c['cases'][0]['requires'].append('invented-feature'),'unknown capability')
 reject_catalog('false-case-pass',lambda c:c['cases'][0].update(acceptance_status='PASS'),'false acceptance')
 reject_catalog('resource-expansion',lambda c:c['cases'][0]['limits'].update(container_memory_bytes=64*1024**3),'invalid bound')
 for field,value in [('application_threads',9),('application_children',2),('thread_stack_bytes',262145),('case_file_bytes',4194305)]:
  reject_catalog('bound-'+field,lambda c,k=field,v=value:c['cases'][0]['limits'].update({k:v}),'child bound' if field=='application_children' else 'invalid bound')
 reject_catalog('repeat-expansion',lambda c:c['cases'][0]['repeatability'].update(same_os_repeats=100000),'repeat bounds')
 reject_catalog('metadata-overwrite-payload',lambda c:c['cases'][0]['payload_contract'].update(path='validate.py'),'payload write scope')
 reject_catalog('global-gate-removed',lambda c:c.update(global_execution_gates=['current-inputs']),'global execution gates')
 reject_catalog('unreviewed-case-command',lambda c:c['cases'][0].update(command_argv=['python3','-c','print(1)']),'unreviewed command template')
 reject_packet('write-path-escape',lambda p:p['write_allowlist'].__setitem__(0,'../../kernel/rust/lib.rs'),'draft writes exceed')
 reject_packet('unreviewed-execution',lambda p:p.update(execution_enabled=True),'runtime packet')
 reject_packet('shell-command',lambda p:p.update(permitted_commands=[['bash','-c','true']]),'shell execution')
 reject_packet('other-packet-command',lambda p:p['permitted_commands'][0].__setitem__(-1,'/workspace/scripts/application-tests/packets/packet-002.json'),'draft command exceeds')
 reject_packet('absolute-catalog-read',lambda p:p['read_allowlist'].append('/workspace/scripts/application-tests/cases.json'),'read context exceeds')
 reject_packet('alias-history-read',lambda p:p['read_allowlist'].append('docs/../kernel.log'),'read context exceeds')
 reject_packet('packet-global-gate-removed',lambda p:p.update(blocked_by=[]),'missing list')
 reject_packet('report-path-escape',lambda p:p['reporting'].update(report_path='/tmp/escape'),'report write scope')
 reject_packet('false-draft-pass',lambda p:p['reporting']['draft_statuses'].append('PASS'),'draft result statuses')
 reject_packet('packet-active-case-expansion',lambda p:p['limits'].update(active_cases_max=2),'declared active case bound')
 reject_packet('missing-original-failure-evidence',lambda p:p['reporting']['required_failure_event_fields'].remove('original_artifact_paths_and_sha256'),'missing original failure evidence')
 def vector_case(c,cid='vector.ymm-raw-syscall'):
  return next(row for row in c['cases'] if row['id']==cid)
 def common_feature_change(c,feature,change):
  change(c['vector_feature_contracts'][feature])
  for row in c['cases']:
   contracts=row['payload_contract'].get('vector_contract',{}).get('feature_contracts',{})
   if feature in contracts:change(contracts[feature])
 reject_catalog('common-mode-osxsave-removal',lambda c:common_feature_change(c,'avx',lambda f:f.update(cpuid_all_bits=[])),'reviewed vector feature predicates changed')
 reject_catalog('feature-self-cycle',lambda c:common_feature_change(c,'avx',lambda f:f['all_of'].append('avx')),'feature dependency cycle')
 reject_catalog('feature-state-mask-zero',lambda c:common_feature_change(c,'avx',lambda f:f.update(cpuid_d_0_xcr0_supported_all_bits='0x0')),'required state unsupported')
 reject_catalog('feature-state-mask-too-wide',lambda c:common_feature_change(c,'avx',lambda f:f.update(cpuid_d_0_xcr0_supported_all_bits='0x10000000000000000')),'invalid mask')
 reject_catalog('transitive-gate-missing',lambda c:vector_case(c)['payload_contract']['vector_contract']['feature_contracts'].pop('sse2'),'missing transitive feature gate')
 reject_catalog('optional-baseline-isa',lambda c:vector_case(c)['payload_contract']['vector_contract']['baseline_dispatch_flags'].append('-mavx'),'unreviewed baseline ISA flags')
 reject_catalog('vectorized-scalar-reference',lambda c:vector_case(c)['payload_contract']['vector_contract'].update(scalar_reference_flags=[]),'unreviewed scalar reference flags')
 reject_catalog('unknown-parameter-feature',lambda c:vector_case(c,'vector.avx512-bit-popcounts')['parameters']['forms'][1].update(features=['invented']),'unknown parameter feature')
 def change_binding(c):
  v=vector_case(c)['payload_contract']['vector_contract'];v['features']=['baseline'];v['feature_contracts']['baseline']=copy.deepcopy(c['vector_feature_contracts']['baseline'])
 reject_catalog('weakened-case-feature-binding',change_binding,'reviewed case-to-feature bindings changed')
 reject_queue('queue-summary-path-escape',lambda q:q['reporting'].update(summary_path='/tmp/escape'),'queue report write scope')
 reject_queue('queue-context-expansion',lambda q:q['context_policy'].update(active_cases_max=273),'queue context expansion')
 reject_queue('queue-production-patch-authorization',lambda q:q['failure_policy'].update(production_changes_allowed=True),'queue failure policy weakened')
 reject_queue('queue-runtime-authorization',lambda q:q.update(execution_enabled=True),'queue enables runtime')
 reject_queue('queue-missing-case-row',lambda q:q['packets'][0].update(case_ids=[]),'queue/packet case mismatch')
 reject('queue-empty',lambda:module.validate_queue({},catalog,cases,src),{},'missing mandatory draft queue')
 reject('duplicate-json-key',lambda:module.load_json('{"mode":"draft-only","mode":"run"}'),{'raw':'{"mode":"draft-only","mode":"run"}'},'duplicate JSON key')
 # An arbitrary same-ID file cannot borrow the validated canonical queue cursor.
 external=out/'external-identical';external.mkdir();external_packet=external/'packet-001.json'
 external_packet.write_bytes((src/'packets/packet-001.json').read_bytes())
 reject('external-identical-packet',lambda:module.selected_packet(external_packet,canonical,src),{'path':str(external_packet),'sha256':ident(external_packet)['sha256']},'not canonical queued path')
 external=out/'external-report';external.mkdir();external_packet=external/'packet-001.json'
 changed=copy.deepcopy(packet);changed['reporting']['report_path']='/tmp/escape';external_packet.write_text(json.dumps(changed))
 reject('external-changed-report-packet',lambda:module.selected_packet(external_packet,canonical,src),changed,'not canonical queued path')
 external=out/'external-cases';external.mkdir();external_packet=external/'packet-001.json'
 changed=copy.deepcopy(canonical['packet-002'][0]);changed['packet_id']='packet-001';external_packet.write_text(json.dumps(changed))
 reject('external-changed-cases-packet',lambda:module.selected_packet(external_packet,canonical,src),changed,'not canonical queued path')
 race=out/'changed-after-validation';(race/'packets').mkdir(parents=True);race_packet=race/'packets/packet-001.json'
 race_packet.write_bytes(canonical['packet-001'][1]+b'\n')
 reject('canonical-packet-changed-after-validation',lambda:module.selected_packet(race_packet,canonical,race),{'path':str(race_packet),'sha256':ident(race_packet)['sha256']},'changed after queue validation')
 # Copy only planning packet files for deterministic queue identity/order failures.
 def queue_tree(name,change_packet,change_queue,reason):
  tree=out/name;tree.mkdir();shutil.copytree(src/'packets',tree/'packets')
  values={pid:copy.deepcopy(row[0]) for pid,row in canonical.items()};q=copy.deepcopy(queue)
  change_packet(values);change_queue(q)
  for pid,value in values.items():(tree/'packets'/(pid+'.json')).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
  reject(name,lambda:module.validate_queue(q,catalog,cases,tree),{'queue':q,'packet_inputs':[ident(p) for p in sorted((tree/'packets').glob('*.json'))]},reason)
 queue_tree('packet-identity-mismatch',lambda ps:ps.__setitem__('packet-001',copy.deepcopy(ps['packet-002'])),lambda q:None,'packet ID differs from canonical')
 queue_tree('packet-next-cursor-mismatch',lambda ps:ps['packet-001']['queue'].update(next_packet_id='packet-097'),lambda q:None,'packet queue cursor/scope mismatch')
 # Keep each duplicated packet internally coherent; duplicate coverage is rejected before later missing cases.
 def duplicate_assignment(ps):
  original=copy.deepcopy(ps['packet-001']);target=ps['packet-002']
  target['case_ids']=original['case_ids'];target['write_allowlist']=original['write_allowlist']
  target['read_allowlist']=[x.replace('packet-001.json','packet-002.json') for x in original['read_allowlist']]
 queue_tree('duplicate-case-assignment',duplicate_assignment,lambda q:q['packets'][1].update(case_ids=packet['case_ids']),'case assigned more than once')
 def reverse_dependency(ps):ps['packet-005']['case_ids'].reverse()
 queue_tree('within-packet-dependency-order',reverse_dependency,lambda q:q['packets'][4]['case_ids'].reverse(),'draft dependency order')
 # Actual CLI must fail closed when the mandatory queue is missing, before any context is emitted.
 missing=out/'missing-queue';shutil.copytree(src,missing);(missing/'draft-queue.json').unlink()
 log=out/'missing-queue.log';args=['python3','-B',str(missing/'validate.py')]
 with log.open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 record['commands'].append(dict(label='missing-queue-negative',command=args,exit_code=r.returncode,expected_nonzero=True))
 assert r.returncode!=0 and 'missing mandatory canonical draft queue' in log.read_text()
 tests.append(dict(name='missing-queue-cli',status='PASS',log=ident(log)))
 contexts=[]
 for pid in ('packet-001','packet-007'):
  context=json.loads((out/(pid+'-context.json')).read_text());source_packet=canonical[pid][0]
  assert len(context['cases'])==3 and [c['id'] for c in context['cases']]==source_packet['case_ids']
  assert context['execution_enabled'] is False and context['mode']=='draft-only'
  assert context['catalog_sha256']==ident(src/'cases.json')['sha256'] and context['packet_sha256']==ident(src/'packets'/(pid+'.json'))['sha256']
  assert set(catalog['global_execution_gates'])<=context['capability_contracts'].keys()
  assert context['queue_cursor']['queue_sha256']==ident(src/'draft-queue.json')['sha256'] and context['queue_cursor']['total']==97
  assert context['queue_cursor']['review_state']==queue['review_state'] and 'not an operating-system sandbox' in context['notice']
  assert 'packets' not in context and 'cases' not in context['queue_cursor']
  contexts.append(dict(packet_id=pid,cases=len(context['cases']),artifact=ident(out/(pid+'-context.json'))))
 assert len(cases)==273 and len(rows)==97 and len({cid for row in rows for cid in row['case_ids']})==273
 record.update(status='PASS',negative_checks=tests,logical_cases=len(cases),queue_packets=len(rows),packet_context_cases=3,contexts=contexts)
except BaseException as e:record.update(status='FAIL',error=str(e));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[ident(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
