"""Compile source-bound OS lease callback prototype; not an exact-stage acceptance build."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shlex,shutil,subprocess
repo=Path('/workspace');source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2');build=Path('/work/native-build-base-24a151fe');prior=Path('/work/native-memory-exact-stage-20260907');out=Path('/work/native-os-resource-prototype-20260907')
if os.getuid()!=1000 or os.sched_getaffinity(0)!={2,3,4,5}: raise SystemExit('Requires fixed four-CPU unprivileged runner')
if (build/'.config').read_bytes()!=(prior/'resolved.config').read_bytes(): raise SystemExit('Debug config changed')
out.mkdir();stage=source/'drivers/misc/mckernel';modules=build/'drivers/misc/mckernel'
def identity(path):
 b=path.read_bytes();return {'path':str(path),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
record={'started_utc':datetime.now(timezone.utc).isoformat(),'source_parent':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'scope':'source-bound OS backend prototype; current authority bindings pending','production_gate_credit':False,'mckernel_boot_proven':False,'helper':identity(Path(__file__))}
try:
 shutil.copytree(stage,out/'prior-stage');shutil.copytree(modules,out/'prior-module-build')
 shutil.copyfile(Path(__file__),out/'build-helper.py')
 stage.rename(source/'drivers/misc/mckernel-os-backend-before-resource-20260907')
 shutil.copytree(out/'prior-stage',stage)
 if (stage/'stage-lock.json').exists(): (stage/'stage-lock.json').rename(stage/'prior-stage-lock.json')
 overlay=[]
 for name in ['smp_resource.rs','os_runtime.rs','os_registry.rs','ihk_ioctl.rs','smp_cpu.rs','smp_memory.rs','ihk_smp_x86_64.rs']:
  path=repo/'host-kernel/native-rust'/name;shutil.copyfile(path,stage/name);overlay.append(identity(path))
 record['overlay']=overlay
 (stage/'prototype-source-record.json').write_text(json.dumps(record,indent=2)+'\n')
 shutil.copytree(stage,out/'staged-source')
 command=shlex.split((prior/'module-build.command').read_text());record['command']=command
 (out/'module-build.command').write_text(shlex.join(command)+'\n')
 with (out/'module-build.log').open('wb') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copytree(modules,out/'module-build')
 for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']: shutil.copyfile(modules/name,out/name)
 for name in ['Module.symvers','rust/bindings/bindings_generated.rs','.config']:
  shutil.copyfile(build/name,out/Path(name).name)
 result=subprocess.check_output(['llvm-nm','--defined-only',str(out/'ihk.ko')],text=True)
 (out/'ihk-defined-symbols.txt').write_text(result)
 for name in ['ihk_os_create_unbooted_v1','ihk_os_create_unbooted_v2','ihk_os_destroy_unbooted_v1']:
  if not any(line.split()[-1:]==[name] for line in result.splitlines()): raise SystemExit('Missing export '+name)
 if (build/'.config').read_bytes()!=(prior/'resolved.config').read_bytes(): raise SystemExit('Build changed config')
 shutil.copyfile(prior/'bzImage',out/'bzImage')
 shutil.copyfile(build/'.config',out/'resolved.config')
 record.update(status='PASS',outputs=[identity(out/name) for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko','bzImage','resolved.config']])
except BaseException as error:
 record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print('NATIVE_OS_RESOURCE_PROTOTYPE_BUILD_PASS',flush=True)
