/work/native-sysfs-os-module-20260907-2/fixture/mckernel_os_device_verify.o
