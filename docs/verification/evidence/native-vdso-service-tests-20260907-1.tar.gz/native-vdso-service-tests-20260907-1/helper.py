from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
linux = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
out = Path('/work/native-vdso-service-tests-20260907-' + sys.argv[1])
out.mkdir()
source = out / 'source'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), commands=[], status='running', production_gate_credit=False)
inputs = ['host-kernel/native-rust/abi/vdso.rs', 'host-kernel/native-rust/smp_vdso.rs', 'host-kernel/native-rust/smp_memory.rs', 'host-kernel/native-rust/smp_image.rs', 'host-kernel/native-rust/ihk_mapping.rs', 'host-kernel/native-rust/ihk_smp_x86_64.rs', 'kernel/rust/native_vdso.rs', 'kernel/rust/syscall_policy.rs', 'kernel/rust/init.rs', 'kernel/rust/lib.rs', 'kernel/rust/x86_setup.rs', 'scripts/tests/fixtures/mckernel_native_vdso_compile.rs', 'scripts/tests/fixtures/ihk_smp_image_compile.rs']

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=source, env=dict(os.environ, MCKERNEL_NATIVE_LINUX_SOURCE=str(linux)), stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-10000:])

try:
    shutil.copyfile(__file__, out / 'helper.py')
    for relative in ['kernel/rust', 'host-kernel/native-rust', 'scripts/tests']:
        shutil.copytree(repo / relative, source / relative)
    record['inputs'] = [identity(repo / relative) for relative in inputs]
    for relative in ['arch/x86/include/asm/vdso/gettimeofday.h', 'include/vdso/math64.h']:
        path = out / 'linux-inputs' / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(linux / relative, path)
        record['inputs'].append(identity(path))
    config = Path('/work/native-build-base-24a151fe/.config').read_text()
    assert 'CONFIG_ARCH_SUPPORTS_INT128=y\n' in config
    (out / 'linux.config').write_text(config)
    run('format-source', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + inputs)
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false'] + inputs)
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('native-vdso', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_mckernel_native_vdso.py', '-v', '-f'])
    run('image-mapping-resource', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_ihk_smp_image.py', '-v', '-f'])
    record['formatted_outputs'] = [identity(source / relative) for relative in inputs]
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
