from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-guest-sysfs-format-20260908-' + sys.argv[1])
out.mkdir()
source = Path('/workspace/scripts/tests/fixtures/mckernel_guest_sysfs.rs')
record = dict(status='running', commands=[], started_utc=datetime.now(timezone.utc).isoformat())
def identity(p):
    data = p.read_bytes()
    return dict(path=str(p), size=len(data), sha256=hashlib.sha256(data).hexdigest())
try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(source, out / 'original.rs')
    shutil.copyfile(source, out / 'formatted.rs')
    record['input'] = identity(source)
    record['compiler'] = subprocess.check_output(['/opt/mckernel/cargo/bin/rustfmt', '--version'], text=True)
    for check in (False, True):
        command = ['/opt/mckernel/cargo/bin/rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false']
        if check: command.append('--check')
        command.append(str(out / 'formatted.rs'))
        result = subprocess.run(command, capture_output=True, text=True)
        (out / ('check.log' if check else 'format.log')).write_text(result.stdout + result.stderr)
        record['commands'].append(dict(command=command, exit_code=result.returncode))
        assert result.returncode == 0, result.stderr
    record['outputs'] = [identity(out / n) for n in ('original.rs', 'formatted.rs')]
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    print(record['status'], out, flush=True)
