import ast
import json
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent / "fixtures/native-lifecycle-model-v1"
FILES = {"README.md", "model.rs", "reference.c", "vectors.json", "expected.json", "harness.py"}
REQUIRED = {
    "preparation-abort", "assigned-tid-abort", "late-clone-abort", "immediate-exit",
    "tid-reuse", "thread-only-exit", "last-thread-exit", "competing-group-orders",
    "inherited-status", "duplicate-terminal", "retained-thread-ref",
    "retained-process-ref", "authority-revoked", "forged-authority",
    "ref-resurrection", "zombie-before-after-reap", "unscheduled-destroy",
    "main-storage-held", "live-sibling-retirement", "vm-held", "launcher-loss",
    "teardown-failure", "buffer-full", "counter-overflow", "unfinished-reservation",
    "missing-birth", "missing-end", "generation-domain-mismatch", "pid-tid-width",
    "capacity-limits", "malformed-schema", "active-tid-alias",
}

class NativeLifecycleModelSourceTests(unittest.TestCase):
    def test_exact_packet_and_labels(self):
        self.assertEqual({path.name for path in HERE.iterdir() if path.is_file()}, FILES)
        for name in ("README.md", "model.rs", "reference.c", "harness.py"):
            self.assertIn("MODEL_ONLY", (HERE / name).read_text())

    def test_python_syntax_and_named_coverage(self):
        ast.parse((HERE / "harness.py").read_text())
        vectors = json.loads((HERE / "vectors.json").read_text())
        expected = json.loads((HERE / "expected.json").read_text())
        self.assertEqual(vectors["schema_version"], 2)
        self.assertTrue(vectors["model_only"] and expected["model_only"])
        names = {vector["name"] for vector in vectors["vectors"]}
        self.assertTrue(names <= REQUIRED)
        if vectors["corpus_complete"]:
            self.assertEqual(names, REQUIRED)
        else:
            self.assertIn("immediate-exit", names)
        self.assertEqual(names, set(expected["vectors"]))
        self.assertEqual(vectors["mutants"], {
            "birth-after-runnable": "birth-after-runnable",
            "early-retirement": "retained-thread-ref",
            "silent-loss": "buffer-full",
            "tid-aliasing": "active-tid-alias",
        })

    def test_separate_registries_and_no_production_wiring(self):
        rust = (HERE / "model.rs").read_text()
        cref = (HERE / "reference.c").read_text()
        for token in ("ProcessRow", "ThreadRow", "ExclusiveUnpublished", "full_key"):
            self.assertIn(token, rust)
        for token in ("process_row", "thread_row", "EXCLUSIVE_UNPUBLISHED", "full_key"):
            self.assertIn(token, cref)
        combined = rust + cref
        for forbidden in ("host_schedule_process", "do_fork", "do_exit", "runq_add_thread", "mcctrl"):
            self.assertNotIn(forbidden, combined)

if __name__ == "__main__":
    unittest.main()
