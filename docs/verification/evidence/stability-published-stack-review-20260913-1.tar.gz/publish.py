from pathlib import Path
import hashlib,json,shutil,stat,sys,tarfile

REPO=Path('/home/holden/mckernel')
LOCAL=Path(__file__).parent
def identity(p,label=None):
    digest=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):digest.update(b)
    return {'path':str(p) if label is None else label,'size':p.stat().st_size,'sha256':digest.hexdigest()}
record=json.loads((LOCAL/'review.json').read_text())
if len(sys.argv)==2:
    peer=Path(sys.argv[1]);shutil.copytree(peer,LOCAL/'independent-arithmetic-review',symlinks=True)
    record['independent_arithmetic_review_directory']=str(peer)
else:
    record['independent_arithmetic_review_directory']=None
record['review_source_retention']=str(LOCAL)
archive=REPO/'docs/verification/evidence/stability-published-stack-review-20260913-1.tar.gz'
members=[]
with tarfile.open(str(archive),'x:gz') as tar:
    for p in sorted(LOCAL.rglob('*')):
        mode=p.lstat().st_mode;rel=str(p.relative_to(LOCAL))
        if stat.S_ISDIR(mode):members.append({'path':rel,'type':'directory','mode':stat.S_IMODE(mode)})
        elif stat.S_ISREG(mode):members.append(identity(p,rel))
        else:raise ValueError('unexpected review tree type '+str(p))
        tar.add(str(p),arcname=rel,recursive=False)
with tarfile.open(str(archive),'r:gz') as tar:
    found=tar.getmembers();assert len(found)==len(members)
    for member,row in zip(found,members):
        assert member.name==row['path']
        if row.get('type')=='directory':assert member.isdir() and member.mode==row['mode']
        else:
            assert member.isfile() and member.size==row['size']
            assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
record['retention']={'archive':identity(archive,str(archive.relative_to(REPO))),'members':members,'all_members_read_back_and_verified':True}
output=REPO/'docs/verification/stability-published-stack-review-20260913-1.json'
with output.open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'publication':identity(output),'archive':record['retention']['archive'],'members':len(members)},indent=2))
