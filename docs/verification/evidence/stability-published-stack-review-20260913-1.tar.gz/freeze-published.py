from pathlib import Path
import hashlib,json,shutil,sys,tarfile

ROOT=Path('/home/holden/mckernel')
CAP=Path('/home/holden/mckernel-work/scratch/stability-published-hold-module-20260913-postpublish-notify-1')
OUT=Path('/tmp/stability-published-stack-review-20260913-jx2y2d33')
def ident(p,label=None):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return {'path':str(p) if label is None else label,'size':p.stat().st_size,'sha256':h.hexdigest()}
def save(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
analysis=json.loads((OUT/'analysis.json').read_text())
build=json.loads((CAP/'record.json').read_text())
assert ident(CAP/'record.json')['sha256']=='3bded4f7bfc206b4e64b03a58243d0e3a7783a5a493dd4095be5916a07e7ed48'
assert build['status']=='PASS_BUILD_ONLY' and build['shared_production_trees_restored'] is True
assert build['shared_stage_before']==build['shared_stage_after'] and build['shared_modules_before']==build['shared_modules_after']
fs={name:{f['address']:f for f in data['functions']} for name,data in analysis['modules'].items()}
def chain(module,addresses,expected):
    rows=[]
    for i,address in enumerate(addresses):
        f=fs[module][address];assert not f['unknown_stack_assignments']
        row={'function':f['name'],'address':hex(address),'entry_line':f['line'],'maximum_local_bytes':f['maximum_local_stack_bytes'],'entry_return_bytes':8}
        if i+1<len(addresses):
            edges=[c for c in f['calls'] if c['target']==['.text',addresses[i+1]]]
            assert edges and all(c['kind']=='call' for c in edges)
            row['callsites']=edges;row['counted_local_bytes']=max(c['depth_before'] for c in edges)
        else:row['counted_local_bytes']=f['maximum_local_stack_bytes']
        row['counted_bytes']=row['counted_local_bytes']+8;rows.append(row)
    total=sum(r['counted_bytes'] for r in rows);assert total==expected,(total,expected)
    return {'bytes':total,'module':module,'rows':rows,'scope':'Known nested module frames only. External kernel/callback residuals remain separate.'}
worker=[0x4a0d0,0x37040,0x31950,0x11450,0x31b50,0x2f960,0x235f0]
ioctl=[0x2430,0x4e640,0x312d0,0x31b50,0x2f960,0x235f0]
chains={
 'packet_worker_to_mailbox_copy':chain('ihk-smp-x86_64',worker+[0x24b60,0x33700],5688),
 'phase_ioctl_to_mailbox_copy':chain('ihk-smp-x86_64',ioctl+[0x24b60,0x33700],6088),
 'packet_worker_to_apps':chain('ihk-smp-x86_64',worker+[0x23740],3168),
 'phase_ioctl_to_apps':chain('ihk-smp-x86_64',ioctl+[0x23740],3568),
 'packet_worker_ready_log':chain('ihk-smp-x86_64',[0x4a0d0,0x37040,0x31950,0x11450,0x48560],768),
 'phase_ioctl_release_log':chain('ihk-smp-x86_64',[0x2430,0x4e640,0x312d0,0x486f0],1344),
 'ret_enter_hook':chain('mcctrl',[0xcf0,0x3d60,0x5b00],704),
 'ret_leave_hook':chain('mcctrl',[0xcf0,0x3d60,0x5c90],704),
 'ret_select_hook':chain('mcctrl',[0xcf0,0x2ac0,0x5e20],560)}
save(OUT/'known-module-chains.json',chains)
selected={name:set(int(row['address'],16) for c in chains.values() if c['module']==name for row in c['rows']) for name in fs}
for name,addresses in selected.items():
    lines=(CAP/(name+'.ko-demangled-disassembly-collection/stdout.bin')).read_text().splitlines(True)
    excerpts=[]
    for address in sorted(addresses):
        f=fs[name][address];start=f['line']-1;end=min(start+35,len(lines))
        excerpts.append({'address':hex(address),'function':f['name'],'prologue_first_line':start+1,'prologue':''.join(lines[start:end]),
          'stack_instructions':f['stack_instructions'],'calls':f['calls'],'unknown_stack_assignments':f['unknown_stack_assignments']})
    save(OUT/(name+'-selected-assembly.json'),excerpts)
    for suffix in ['demangled-disassembly','disassembly','modinfo']:
        directory=CAP/(name+'.ko-'+suffix+'-collection')
        for leaf in ['report.json','request.json','stdout.bin','stderr.bin']:
            p=directory/leaf;q=OUT/'compiled-inputs'/directory.name/leaf;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
            assert ident(p)['sha256']==ident(q)['sha256']
for leaf in ['record.json','helper.py','held-stage-record.json','preparation-record.json']:
    shutil.copy2(CAP/leaf,OUT/'compiled-inputs'/leaf)
shutil.copytree(CAP/'staged-source',OUT/'compiled-staged-source',symlinks=True)
previous_path=ROOT/'docs/verification/stability-observer-stack-review-20260913-3.json'
previous=json.loads(previous_path.read_text())
linux_path=ROOT/'docs/verification/stability-observer-stack-review-20260913-2.json'
linux=json.loads(linux_path.read_text())['linux_context']
assert analysis['modules']['mcctrl']['module']['sha256']==previous['modules']['mcctrl']['module']['sha256']
kernel=ident(Path(linux['vmlinux']['path']));assert kernel==linux['vmlinux']
assert linux['thread_size_bytes']==16384 and linux['direct_initial_formatting_path_upper_bytes']==797
save(OUT/'old-address-display-diagnostic.json',{'kind':'READ_ONLY_SYMBOL_LOOKUP_DIAGNOSTIC','subject_execution':False,
 'query':'Display selected function call edges, including historical fops address0x22d0.','result':'KeyError8912 after preceding worker/snapshot rows printed; the old address does not exist in this new module.',
 'stderr':'Traceback (most recent call last):\n  File "<stdin>", line 8, in <module>\nKeyError: 8912\n',
 'correction':'Enumerated actual callers of the new ioctl and phase snapshot, resolving current fops0x2430 and command0x312d0 from ELF relocations. No old address or old frame sum was accepted.',
 'core_analyzer_status':'Successful; analysis.stdout/analysis.stderr retained separately.'})
save(OUT/'review.json',{'schema_version':1,'record_kind':'published-held-observer-compiled-stack-review',
 'status':'MEASURED_PUBLISHED_HOLD_MODULE_FRAMES_WITH_KERNEL_RESIDUALS','build_record':ident(CAP/'record.json'),
 'analysis_record':ident(OUT/'analysis.json'),'analyzer':ident(OUT/'analyzer-published.py'),'analysis_environment':{'python':sys.executable,'version':sys.version},
 'verified_compiler_and_fixture_input_count':len(analysis['verified_retained_inputs']),'verified_inputs':analysis['verified_retained_inputs'],
 'modules':{k:{name:v[name] for name in ['module','disassembly']} for k,v in analysis['modules'].items()},
 'known_module_chains':chains,'comparison':{'previous_review':ident(previous_path),'worker_previous':5512,'worker_current':5688,'worker_increase':176,'ioctl_previous':5832,'ioctl_current':6088,'ioctl_increase':256,'app_outer_bytes':224,'app_helper_bytes':1536,'mailbox_emitter_bytes':3760,'mailbox_copier_bytes':296,'app_helper_sibling_to_mailbox':True,'mcctrl_exactly_unchanged':True},
 'selected_linux_context':{'reference':ident(linux_path),'current_vmlinux_rehashed':kernel,'thread_size_bytes':16384,'selected_direct_formatting_prefix_bytes':797,'worker_mailbox_print_prefix_bytes':5392,'ioctl_mailbox_print_prefix_bytes':5792,'worker_plus_selected_linux_prefix_bytes':6189,'ioctl_plus_selected_linux_prefix_bytes':6589,'scope':'Same exact pinned vmlinux. Only direct initial formatting through core::fmt::write; stops before dynamic callbacks and is not a full stack upper bound.'},
 'residuals':['Dynamic core::fmt/Debug callbacks and nested formatting frames.','Alternate printk_sprint formatting path, console flush and console-driver descendants.','Linux syscall/kthread entry, lock slowpaths, scheduler, interrupts/NMI, mitigations and deeper RETURN backend handling outside selected module chains.','No runtime stack watermark or actual guest publication/timer/QMP/physical proof is supplied by this review.'],
 'further_source_stack_reduction_recommended':False,'recommendation':'Current measured changes add176/256 known bytes to the already reduced worker/ioctl prefixes. No additional observer buffer change is indicated by this bounded comparison; retain explicit residuals for controlled guest validation.',
 'subject_execution_by_reviewer':False,'runtime_authorized':False,'full_linux_stack_bound_verified':False,'production_gate_credit':False,'transport_acceptance':False,'application_acceptance':False})
for row in analysis['verified_retained_inputs']:
    assert ident(Path(row['path']))==row
print(json.dumps({'directory':str(OUT),'review':ident(OUT/'review.json'),'worker_bytes':5688,'ioctl_bytes':6088},indent=2))
