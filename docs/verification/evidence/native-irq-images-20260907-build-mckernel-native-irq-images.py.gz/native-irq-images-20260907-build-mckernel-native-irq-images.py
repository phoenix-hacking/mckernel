"""Pinned compatibility compiler; actual McKernel image selects native Linux ABI."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/mckernel-native-irq-images-20260907-' + sys.argv[1])
out.mkdir()
source = out / 'source'
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
ihk_head = subprocess.check_output(['git', '-C', str(repo / 'ihk'), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
assert shutil.disk_usage('/work').free > 3 * 1024**3
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=head, ihk_source=ihk_head,
              status='running', production_gate_credit=False, mckernel_boot_proven=False, results=[])
environment = dict(os.environ, PATH='/opt/mckernel/cargo/bin:' + os.environ['PATH'], RUSTC='/opt/mckernel/cargo/bin/rustc',
                   PYTHONDONTWRITEBYTECODE='1', MCKERNEL_RUST_EQUIV_KEEP_TMP='1')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
def run(label, command, expected=None):
    record['phase'] = label
    (out / 'phase').write_text(label + '\n')
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=str(source) if source.exists() else str(repo), env=environment, stdout=log, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode)
    record['results'].append(row)
    save()
    if expected is None:
        assert result.returncode == 0, (label, result.returncode)
    else:
        assert result.returncode != 0 and expected in (out / (label + '.log')).read_text(), label
try:
    shutil.copyfile(__file__, out / 'build-helper.py')
    run('clone-source', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo), str(source)])
    run('checkout-source', ['git', '-C', str(source), 'checkout', '--detach', head])
    run('clone-ihk', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / 'ihk'), str(source / 'ihk')])
    run('checkout-ihk', ['git', '-C', str(source / 'ihk'), 'checkout', '--detach', ihk_head])
    submodules = subprocess.check_output(['git', '-C', str(repo), 'submodule', 'status', '--recursive'], universal_newlines=True)
    record['recursive_submodules'] = submodules.splitlines()
    for index, line in enumerate(submodules.splitlines()):
        assert line.startswith(' '), line
        revision, relative = line[1:].split()[:2]
        if relative == 'ihk': continue
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        run('clone-submodule-' + str(index), ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / relative), str(target)])
        run('checkout-submodule-' + str(index), ['git', '-C', str(target), 'checkout', '--detach', revision])
    record['compiler'] = subprocess.check_output(['/opt/mckernel/cargo/bin/rustc', '--version', '--verbose'], universal_newlines=True)
    record['source_status'] = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], universal_newlines=True)
    assert record['source_status'] == ''
    changed = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', 'HEAD', '-z']).split(b'\0')
    changed += subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    record['source_overlays'] = []
    for raw in sorted(set(changed)):
        if not raw: continue
        relative = os.fsdecode(raw)
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / relative, path)
        record['source_overlays'].append(identity(path))
    record['production_inputs'] = [identity(source / p) for p in ['kernel/CMakeLists.txt', 'kernel/rust/smp_ikc.rs', 'kernel/rust/llist.rs', 'kernel/rust/lib.rs', 'lib/include/list.h', 'arch/x86_64/kernel/include/registers.h', 'arch/x86_64/kernel/include/ihk/atomic.h']]
    run('diff-check', ['git', 'diff', '--check'])
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false', 'kernel/rust/smp_ikc.rs', 'scripts/tests/fixtures/mckernel_irq_work_compile.rs', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs'])
    for enabled in [False, True]:
        command = ['cc', '-E', '-dM', '-x', 'c', '-I', str(source / 'lib/include'), '-include', 'list.h']
        if enabled: command.append('-DMCKERNEL_RUST_LIST_HELPERS')
        output = subprocess.check_output(command + ['/dev/null'])
        (out / ('list-macros-rust.txt' if enabled else 'list-macros-fallback.txt')).write_bytes(output)
        for macro in [b'#define list_for_each_entry(', b'#define list_for_each_entry_safe(']:
            assert (macro in output) == (not enabled)
    run('producer-check', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_mckernel_irq_work.py', '-v', '-f'])
    # The old broad harness requires three Rust sources absent from the exact
    # pinned IHK. Preserve its failed attempt 2; do not invent that old source.
    # The preceding focused test now runs the complete, unchanged pinned C
    # producer and the retained Rust producer with the same fixture and checks
    # identical observable results, plus the native extension independently.
    missing = [p for p in ['ihk/linux/core/rust/core_helpers.rs',
                          'ihk/linux/driver/smp/rust/smp_driver_helpers.rs',
                          'ihk/linux/user/rust/ihklib_helpers.rs'] if not (source / p).is_file()]
    record['historical_equivalence'] = dict(status='prerequisites-unavailable', missing=missing,
        retained_failure='/work/mckernel-native-irq-images-20260907-2', pass_claimed=False,
        current_surface_equivalence='producer-check includes exact pinned C body and current Rust body')
    assert len(missing) == 3
    common = ['cmake', '-S', str(source), '-DCMAKE_BUILD_TYPE=Debug', '-DBUILD_TARGET=smp-x86',
              '-DKERNEL_DIR=/usr/src/kernels/4.18.0-553.159.1.el8_10.x86_64',
              '-DENABLE_PERF=ON', '-DENABLE_RUSAGE=ON', '-DENABLE_LINUX_WORK_IRQ_FOR_IKC=ON',
              '-DRUSTC=/opt/mckernel/cargo/bin/rustc', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    run('reject-invalid-abi', common + ['-B', str(out / 'invalid-abi'), '-DMCKERNEL_HOST_IRQ_ABI=invalid'], 'MCKERNEL_HOST_IRQ_ABI must be legacy or linux-6.12')
    run('reject-native-c-fallback', common + ['-B', str(out / 'invalid-native-fallback'), '-DMCKERNEL_HOST_IRQ_ABI=linux-6.12', '-DENABLE_RUST_KERNEL=OFF'], 'linux-6.12 IRQ ABI requires the x86_64 Rust kernel')
    record['images'] = []
    for label, enabled, abi in [('fallback', 'OFF', 'legacy'), ('legacy-rust', 'ON', 'legacy'), ('native-rust', 'ON', 'linux-6.12')]:
        build = out / label
        run(label + '-configure', common + ['-B', str(build), '-DCMAKE_INSTALL_PREFIX=' + str(out / (label + '-prefix')),
                '-DENABLE_RUST_KERNEL=' + enabled, '-DENABLE_RUST_IHK_MODULE_HELPERS=' + enabled,
                '-DENABLE_RUST_USER_TOOLS=' + enabled, '-DMCKERNEL_HOST_IRQ_ABI=' + abi])
        run(label + '-build', ['cmake', '--build', str(build), '--target', 'mckernel.img', '-j4'])
        image = build / 'kernel/mckernel.img'
        artifacts = [image, build / 'kernel/mckernel.img.map', build / 'CMakeCache.txt', build / 'compile_commands.json']
        (out / (label + '-elf-header.txt')).write_bytes(subprocess.check_output(['readelf', '-h', str(image)]))
        (out / (label + '-symbols.txt')).write_bytes(subprocess.check_output(['nm', '-n', str(image)]))
        header = (out / (label + '-elf-header.txt')).read_text()
        assert 'ELF64' in header and 'Advanced Micro Devices X86-64' in header and 'EXEC' in header
        symbols = (out / (label + '-symbols.txt')).read_text()
        assert ' T ihk_mc_interrupt_host\n' in symbols
        if enabled == 'ON':
            artifacts += [build / 'kernel/rust/mckernel_rust.o', build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make']
            selected = 'native_linux_irq_work_v6_12' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            assert selected == (abi == 'linux-6.12')
            run(label + '-linked-ownership', ['python3', str(source / 'scripts/mckernel_linked_text_ownership.py'), '--image', str(image), '--link-map', str(build / 'kernel/mckernel.img.map'), '--rust-object', str(build / 'kernel/rust/mckernel_rust.o'), '--source-commit', head, '--output', str(out / (label + '-linked-ownership.json'))])
        record['images'].append(dict(kind=label, host_irq_abi=abi, outputs=[identity(path) for path in artifacts]))
        save()
    assert record['images'][1]['outputs'][0]['sha256'] != record['images'][2]['outputs'][0]['sha256']
    for item in record['production_inputs']:
        assert identity(Path(item['path'])) == item
    record.update(status='PASS', phase='complete')
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
