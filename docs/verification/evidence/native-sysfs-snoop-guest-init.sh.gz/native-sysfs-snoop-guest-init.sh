#!/bin/bash
set -eu
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
fail() { echo MCKERNEL_SYSFS_SNOOP_GUEST_FAIL; while :; do sleep 1; done; }
trap fail EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
insmod /modules/mckernel_sysfs_snoop_oracle.ko
for cycle in 1 2; do
    insmod /modules/mckernel_sysfs_snoop_verify.ko
    /bin/native-sysfs-snoop
    rmmod mckernel_sysfs_snoop_verify
    test ! -e /sys/mckernel_sysfs_snoop_verify
    printf 'MCKERNEL_SYSFS_SNOOP_CYCLE_PASS=%s\n' "$cycle"
done
rmmod mckernel_sysfs_snoop_oracle
echo MCKERNEL_SYSFS_SNOOP_GUEST_PASS
while :; do sleep 1; done
