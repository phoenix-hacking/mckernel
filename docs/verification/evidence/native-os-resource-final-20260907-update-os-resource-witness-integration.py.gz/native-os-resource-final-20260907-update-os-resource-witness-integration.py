"""Bind the current historical-test harness; preserve both witness authorities."""
import ast
import hashlib
import json
from pathlib import Path
import pprint
import re

repo = Path('/home/holden/mckernel')

def identity(relative):
    data = (repo / relative).read_bytes()
    return dict(path=relative, sha256=hashlib.sha256(data).hexdigest(), size=len(data))

def set_assignment(relative, name, value):
    path = repo / relative
    source = path.read_text()
    nodes = [n.value for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Assign)
             and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name]
    assert len(nodes) == 1, (relative, name)
    old = ast.get_source_segment(source, nodes[0])
    assert source.count(name + ' = ' + old) == 1
    path.write_text(source.replace(name + ' = ' + old,
                                   name + ' = ' + pprint.pformat(value, width=100), 1))

capture_path = 'host-kernel/contracts/fp0006-runtime-capture-integration-v1.json'
capture = json.loads((repo / capture_path).read_text())
files = capture['base_witness']['files']
files['tests'] = identity('scripts/tests/test_fp0006_ihk_device_negative_dispatch.py')
files['tests_fixture_materializer'] = identity('scripts/tests/frozen_fp0006_authority.py')
files['tests_source_archive'] = identity('scripts/tests/fixtures/fp0006-unbooted-source-inputs-3d68165c.tar.gz')
(repo / capture_path).write_text(json.dumps(capture, indent=2, sort_keys=True) + '\n')
checker = 'scripts/fp0006_runtime_capture_integration.py'
set_assignment(checker, 'expected_frozen', files)
cap = identity(capture_path)
set_assignment(checker, 'EXPECTED_CONTRACT_SHA256', cap['sha256'])
set_assignment(checker, 'EXPECTED_CONTRACT_SIZE', cap['size'])

closure_path = 'host-kernel/contracts/fp0006-executable-acceptance-closure-v1.json'
before = identity(closure_path)['sha256']
value = json.loads((repo / closure_path).read_text())
updated = []
def walk(row):
    if isinstance(row, dict):
        if row.get('path') == capture_path and 'sha256' in row:
            row.update(cap)
            updated.append(capture_path)
        for child in row.values():
            walk(child)
    elif isinstance(row, list):
        for child in row:
            walk(child)
walk(value)
assert len(updated) == 1
(repo / closure_path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
closure = identity(closure_path)
checker = 'scripts/fp0006_executable_acceptance_closure.py'
set_assignment(checker, 'EXPECTED_CONTRACT_SHA256', closure['sha256'])
set_assignment(checker, 'EXPECTED_CONTRACT_SIZE', closure['size'])
path = repo / checker
data = path.read_bytes()
normalized, count = re.subn(br'SELF_DIGEST:[0-9a-f]{64}', b'SELF_DIGEST:' + b'0' * 64, data)
assert count == 1
data, count = re.subn(br'SELF_DIGEST:[0-9a-f]{64}', b'SELF_DIGEST:' + hashlib.sha256(normalized).hexdigest().encode(), data)
assert count == 1
path.write_bytes(data)
path = repo / 'scripts/tests/test_fp0006_executable_acceptance_closure.py'
source = path.read_text()
assert source.count(before) == 1
path.write_text(source.replace(before, closure['sha256'], 1))
print('Bound current historical-test harness and its pinned source archive; original witness contracts and checker bytes unchanged')
