from datetime import datetime, timezone
import hashlib, json, os
from pathlib import Path
import subprocess, sys
repo=Path('/workspace')
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
attempt=int(sys.argv[1])
out=Path('/work/native-image-staging-integration-20260907-'+str(attempt))
out.mkdir()
files=['host-kernel/kbuild/stage-manifest.json', 'scripts/rocky_rust_staging.py',
       'scripts/native_rust_host_audit.py', 'scripts/native_rust_kbuild_link_closure.py',
       'scripts/tests/test_rocky_rust_staging.py', 'scripts/tests/test_native_rust_kbuild_link_closure.py',
       'scripts/tests/test_native_rust_host_audit.py']
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),
            source_commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
            sources=[dict(path=f,sha256=hashlib.sha256((repo/f).read_bytes()).hexdigest()) for f in files],
            production_gate_credit=False)
for f in files:
    target=out/'source'/f
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((repo/f).read_bytes())
command=['python3','-B','-m','unittest','-v','-f',
         'scripts.tests.test_rocky_rust_staging',
         'scripts.tests.test_native_rust_kbuild_link_closure',
         'scripts.tests.test_native_rust_host_audit']
record['command']=command
with (out/'tests.log').open('wb') as log:
    result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat())
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print('\n'.join((out/'tests.log').read_text().splitlines()[-25:]),flush=True)
raise SystemExit(result.returncode)
