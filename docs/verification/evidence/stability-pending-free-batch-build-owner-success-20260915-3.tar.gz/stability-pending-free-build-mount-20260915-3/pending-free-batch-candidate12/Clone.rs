#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData,PhantomPinned};
use core::pin::Pin;
use core::ptr::{null_mut,write_volatile};
use core::mem::{size_of,align_of,offset_of};
pub type CInt = i32;
pub type CLong = i64;
pub type CULong = u64;
// x86_64's C enum includes PTATTR_NO_EXECUTE at bit 63, so its ABI is u64.
pub type IhkMcPtAttribute = CULong;
pub type SizeT = usize;
pub type SSizeT = isize;
pub type OffT = i64;

#[repr(C)]
#[derive(Clone, Copy)]
pub struct AbiListHead {
    pub next: *mut AbiListHead,
    pub prev: *mut AbiListHead,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct IhkAtomic {
    pub counter: CInt,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct IhkAtomic64 {
    pub counter64: CLong,
}

#[repr(C)]
pub struct MemPage {
    list: AbiListHead,
    hash: AbiListHead,
    mode: u8,
    phys: CULong,
    count: IhkAtomic,
    mapped: IhkAtomic64,
    offset: OffT,
    pgshift: CInt,
}

#[inline(always)]
unsafe fn list_add(new: *mut AbiListHead, prev: *mut AbiListHead, next: *mut AbiListHead) {
    (*next).prev = new;
    (*new).next = next;
    (*new).prev = prev;
    (*prev).next = new;
}

#[inline(always)]
unsafe fn list_add_tail(new: *mut AbiListHead, head: *mut AbiListHead) {
    list_add(new, (*head).prev, head);
}

#[inline(always)]
unsafe fn list_add_after(new: *mut AbiListHead, head: *mut AbiListHead) {
    list_add(new, head, (*head).next);
}

#[inline(always)]
unsafe fn list_del(entry: *mut AbiListHead) {
    let next = (*entry).next;
    let prev = (*entry).prev;
    (*next).prev = prev;
    (*prev).next = next;
}

#[inline(always)]
unsafe fn init_list_head(head: *mut AbiListHead) {
    (*head).next = head;
    (*head).prev = head;
}

#[inline(always)]
unsafe fn list_del_poison(entry: *mut AbiListHead) {
    list_del(entry);
    (*entry).next = LIST_POISON1 as *mut AbiListHead;
    (*entry).prev = LIST_POISON2 as *mut AbiListHead;
}

#[inline(always)]
unsafe fn page_from_list(node: *mut AbiListHead) -> *mut MemPage {
    node.cast::<MemPage>()
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum PendingFreeBatchState {
    Vacant,
    Retained,
    Drained,
}

/// Pinned transaction destination for pending-page ownership transfer.
/// It is deliberately !Unpin, !Send and !Sync and never frees implicitly.
struct PendingFreeBatch {
    head: AbiListHead,
    state: PendingFreeBatchState,
    source: *mut AbiListHead,
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

impl PendingFreeBatch {
    const fn new() -> Self {
        Self {
            head: AbiListHead { next: null_mut(), prev: null_mut() },
            state: PendingFreeBatchState::Vacant,
            source: null_mut(),
            _pin: PhantomPinned,
            _owner: PhantomData,
        }
    }
}

unsafe fn validate_pending_head(head: *mut AbiListHead) -> Result<bool, CInt> {
    if head.is_null() || (*head).next.is_null() || (*head).prev.is_null() {
        return Err(-EINVAL);
    }
    if (*head).next == head || (*head).prev == head {
        if (*head).next != head || (*head).prev != head {
            return Err(-EINVAL);
        }
        return Ok(false);
    }
    if (*(*head).next).prev != head || (*(*head).prev).next != head {
        return Err(-EINVAL);
    }

    // Validate the complete ring before changing either list.  Floyd's
    // traversal detects a foreign cycle without imposing a node-count cap.
    let mut slow = (*head).next;
    let mut fast = (*head).next;
    loop {
        if slow == head {
            break;
        }
        if slow.is_null()
            || (*slow).next.is_null()
            || (*slow).prev.is_null()
            || (*(*slow).next).prev != slow
            || (*(*slow).prev).next != slow
        {
            return Err(-EINVAL);
        }
        let page = page_from_list(slow);
        if page.is_null() || (*page).mode != PM_PENDING_FREE {
            return Err(-EINVAL);
        }
        slow = (*slow).next;

        if fast == head {
            continue;
        }
        if fast.is_null() || (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == head {
            continue;
        }
        if (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == slow && slow != head {
            return Err(-EINVAL);
        }
    }
    Ok(true)
}

unsafe fn detach_pending_free_batch(
    source: *mut AbiListHead,
    mut destination: Pin<&mut PendingFreeBatch>,
) -> CInt {
    // Safety obligations: the caller owns an exclusive, CPU-local source
    // ring and keeps every live descriptor stable; no producer may edit the
    // transfer or retained descriptors, and no callback may re-enter while
    // this transaction is detached. `destination` must remain at this pinned
    // address until drain (or explicit recovery). Once the source head has
    // been reset, a later independently owned capture of that source is
    // permitted while this older pinned batch remains retained.
    let dest = destination.as_mut().get_unchecked_mut();
    let dest_head = &raw mut dest.head;
    if source.is_null()
        || source == dest_head
        || dest.state != PendingFreeBatchState::Vacant
        || !(dest.head.next.is_null() && dest.head.prev.is_null())
    {
        return -EINVAL;
    }
    let nonempty = match validate_pending_head(source) {
        Ok(nonempty) => nonempty,
        Err(_) => return -EINVAL,
    };
    if nonempty {
        let first = (*source).next;
        let last = (*source).prev;
        init_list_head(dest_head);
        (*dest_head).next = first;
        (*dest_head).prev = last;
        (*first).prev = dest_head;
        (*last).next = dest_head;
        (*source).next = null_mut();
        (*source).prev = null_mut();
    } else {
        init_list_head(dest_head);
        (*source).next = null_mut();
        (*source).prev = null_mut();
    }
    dest.source = source;
    dest.state = PendingFreeBatchState::Retained;
    0
}

unsafe fn drain_pending_free_batch(
    source: *mut AbiListHead,
    mut batch: Pin<&mut PendingFreeBatch>,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    // Safety obligations: `source` must be the exact source captured by
    // detach, the pinned transaction must outlive this call, and `free_fn`
    // must not mutate either list or re-enter detach/drain. The caller owns
    // the exclusive CPU/descriptor lease for the whole operation.
    let Some(free_fn) = free_fn else { return -EINVAL; };
    let b = batch.as_mut().get_unchecked_mut();
    if b.state != PendingFreeBatchState::Retained
        || b.source != source
        || validate_pending_head(&raw mut b.head).is_err()
    {
        return -EINVAL;
    }
    let mut node = b.head.next;
    let mut count = 0;
    while node != &raw mut b.head {
        let next = (*node).next;
        let page = page_from_list(node);
        (*page).mode = PM_NONE;
        list_del_poison(node);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        node = next;
    }
    b.head.next = null_mut();
    b.head.prev = null_mut();
    b.source = null_mut();
    b.state = PendingFreeBatchState::Drained;
    count
}

#[no_mangle]
pub unsafe extern "C" fn mem_begin_free_pages_pending_result(pendings: *mut AbiListHead) -> CInt {
    if pendings.is_null() || !(*pendings).next.is_null() {
        return -EINVAL;
    }
    init_list_head(pendings);
    0
}

#[no_mangle]
pub unsafe extern "C" fn mem_begin_free_pages_pending_body_result(
    pendings: *mut AbiListHead,
    begin_fn: Option<MemBeginFreePagesPendingFn>,
    panic_fn: Option<MemVoidFn>,
) -> CInt {
    let ret = if let Some(begin) = begin_fn {
        begin(pendings)
    } else {
        -EINVAL
    };
    if ret != 0 {
        if let Some(panic) = panic_fn {
            panic();
        }
    }
    ret
}

#[no_mangle]
pub unsafe extern "C" fn mem_free_pages_pending_enqueue_result(
    page: *mut MemPage,
    pendings: *mut AbiListHead,
    npages: CInt,
    warn_fn: Option<MemPendingWarnFn>,
) -> CInt {
    if page.is_null() || pendings.is_null() {
        return 0;
    }

    if (*page).mode != PM_NONE {
        if let Some(warn) = warn_fn {
            warn((*page).phys);
        }
    }

    if (*pendings).next.is_null() {
        return 0;
    }

    (*page).mode = PM_PENDING_FREE;
    (*page).offset = npages as OffT;
    list_add_tail(&raw mut (*page).list, pendings);
    1
}

#[no_mangle]
pub unsafe extern "C" fn mem_finish_free_pages_pending_result(
    pendings: *mut AbiListHead,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    let Some(free_fn) = free_fn else {
        return -EINVAL;
    };
    if pendings.is_null() || (*pendings).next.is_null() {
        return 0;
    }

    let mut count: CInt = 0;
    let mut entry = (*pendings).next;
    while entry != pendings {
        let next = (*entry).next;
        let page = page_from_list(entry);

        if (*page).mode != PM_PENDING_FREE {
            return -EINVAL;
        }

        (*page).mode = PM_NONE;
        list_del_poison(entry);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        entry = next;
    }

    write_volatile(&raw mut (*pendings).next, null_mut());
    write_volatile(&raw mut (*pendings).prev, null_mut());
    count
}

const EINVAL: CInt = 22;
const IHK_MC_PG_USER: CInt = 1;
const PM_NONE: u8 = 0x00;
const PM_PENDING_FREE: u8 = 0x01;
const LIST_POISON1: usize = 0x0010_0129;
const LIST_POISON2: usize = 0x0020_0229;
type MemPendingFreeFn = unsafe extern "C" fn(CULong, CInt, CInt);
type MemPendingWarnFn = unsafe extern "C" fn(CULong);
type MemBeginFreePagesPendingFn = unsafe extern "C" fn(*mut AbiListHead) -> CInt;
type MemVoidFn = unsafe extern "C" fn();
const _: () = {
    assert!(size_of::<MemPage>() == 80);
    assert!(align_of::<MemPage>() == 8);
    assert!(offset_of!(MemPage, list) == 0);
    assert!(offset_of!(MemPage, hash) == 16);
    assert!(offset_of!(MemPage, mode) == 32);
    assert!(offset_of!(MemPage, phys) == 40);
    assert!(offset_of!(MemPage, count) == 48);
    assert!(offset_of!(MemPage, mapped) == 56);
    assert!(offset_of!(MemPage, offset) == 64);
    assert!(offset_of!(MemPage, pgshift) == 72);
};

fn need<T:Clone>(){} fn main(){need::<PendingFreeBatch>();}
