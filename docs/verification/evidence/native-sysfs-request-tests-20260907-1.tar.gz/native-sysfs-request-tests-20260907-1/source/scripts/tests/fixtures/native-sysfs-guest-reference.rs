use crate::abi::*;
use core::{ffi::c_void,ptr::write};
const EIO: CInt = 5;
const EINVAL: CInt = 22;
const SCD_MSG_SYSFS_RESP_SHOW: CInt = 0x3b;
const SCD_MSG_SYSFS_RESP_STORE: CInt = 0x3d;
const SCD_MSG_SYSFS_RESP_RELEASE: CInt = 0x3f;
pub type SysfssShowFn = Option<
    unsafe extern "C" fn(
        ops: *mut c_void,
        instance: *mut c_void,
        buf: *mut c_void,
        bufsize: SizeT,
    ) -> CLong,
>;
pub type SysfssStoreFn = Option<
    unsafe extern "C" fn(
        ops: *mut c_void,
        instance: *mut c_void,
        buf: *mut c_void,
        size: SizeT,
    ) -> CLong,
>;
pub type SysfssReleaseFn = Option<unsafe extern "C" fn(ops: *mut c_void, instance: *mut c_void)>;
pub type SysfssSendFn =
    Option<unsafe extern "C" fn(msg: CInt, err: CInt, arg1: CLong, arg2: CLong) -> CInt>;
pub type SysfssPacketShowFn =
    Option<unsafe extern "C" fn(nodeh: CLong, ops: *mut c_void, instance: *mut c_void)>;
pub type SysfssPacketStoreFn = Option<
    unsafe extern "C" fn(nodeh: CLong, ops: *mut c_void, instance: *mut c_void, size: SizeT),
>;
pub type SysfssPacketReleaseFn =
    Option<unsafe extern "C" fn(nodeh: CLong, ops: *mut c_void, instance: *mut c_void)>;
pub type SysfssPacketUnknownFn =
    Option<unsafe extern "C" fn(msg: CInt, error: CInt, arg1: CLong, arg2: CLong, arg3: CLong)>;
pub type SysfssReqLogFn = Option<
    unsafe extern "C" fn(
        event: CInt,
        nodeh: CLong,
        ops: *mut c_void,
        instance: *mut c_void,
        size: SizeT,
        error: CInt,
        packet_err: CInt,
        ssize: CLong,
    ),
>;

pub extern "C" fn sysfs_response_error_result(ssize: CLong) -> CInt {
    if ssize < 0 {
        ssize as CInt
    } else {
        0
    }
}
pub extern "C" fn sysfs_default_response_ssize_result() -> CLong {
    -(EIO as CLong)
}
pub extern "C" fn sysfs_release_response_error_result() -> CInt {
    0
}
pub unsafe extern "C" fn sysfss_packet_prepare_result(
    packet: *mut IkcScdPacket,
    msg: CInt,
    err: CInt,
    arg1: CLong,
    arg2: CLong,
) -> CInt {
    if packet.is_null() {
        return -EINVAL;
    }

    let sysfs = core::ptr::addr_of_mut!((*packet).body).cast::<IkcScdPacketSysfs>();
    write(core::ptr::addr_of_mut!((*packet).msg), msg);
    write(core::ptr::addr_of_mut!((*packet).err), err);
    write(core::ptr::addr_of_mut!((*sysfs).sysfs_arg1), arg1);
    write(core::ptr::addr_of_mut!((*sysfs).sysfs_arg2), arg2);

    0
}
unsafe fn store_sysfs_response(
    ssizep: *mut CLong,
    packet_errp: *mut CInt,
    ssize: CLong,
    err: CInt,
) {
    if !ssizep.is_null() {
        write(ssizep, ssize);
    }
    if !packet_errp.is_null() {
        write(packet_errp, err);
    }
}
unsafe fn sysfss_send(
    send_fn: SysfssSendFn,
    msg: CInt,
    err: CInt,
    arg1: CLong,
    arg2: CLong,
) -> CInt {
    match send_fn {
        Some(send) => send(msg, err, arg1, arg2),
        None => -EIO,
    }
}
pub unsafe extern "C" fn sysfss_req_show_body_result(
    nodeh: CLong,
    ops: *mut c_void,
    instance: *mut c_void,
    data_buf: *mut c_void,
    data_bufsize: SizeT,
    show_fn: SysfssShowFn,
    send_fn: SysfssSendFn,
    ssizep: *mut CLong,
    packet_errp: *mut CInt,
) -> CInt {
    let ssize = match show_fn {
        Some(show) => show(ops, instance, data_buf, data_bufsize),
        None => sysfs_default_response_ssize_result(),
    };
    let packet_err = sysfs_response_error_result(ssize);
    let send_error = sysfss_send(send_fn, SCD_MSG_SYSFS_RESP_SHOW, packet_err, nodeh, ssize);
    store_sysfs_response(ssizep, packet_errp, ssize, packet_err);
    send_error
}
pub unsafe extern "C" fn sysfss_req_store_body_result(
    nodeh: CLong,
    ops: *mut c_void,
    instance: *mut c_void,
    data_buf: *mut c_void,
    size: SizeT,
    store_fn: SysfssStoreFn,
    send_fn: SysfssSendFn,
    ssizep: *mut CLong,
    packet_errp: *mut CInt,
) -> CInt {
    let ssize = match store_fn {
        Some(store) => store(ops, instance, data_buf, size),
        None => sysfs_default_response_ssize_result(),
    };
    let packet_err = sysfs_response_error_result(ssize);
    let send_error = sysfss_send(send_fn, SCD_MSG_SYSFS_RESP_STORE, packet_err, nodeh, ssize);
    store_sysfs_response(ssizep, packet_errp, ssize, packet_err);
    send_error
}
pub unsafe extern "C" fn sysfss_req_release_body_result(
    nodeh: CLong,
    ops: *mut c_void,
    instance: *mut c_void,
    release_fn: SysfssReleaseFn,
    send_fn: SysfssSendFn,
    packet_errp: *mut CInt,
) -> CInt {
    if let Some(release) = release_fn {
        release(ops, instance);
    }
    let packet_err = sysfs_release_response_error_result();
    let send_error = sysfss_send(send_fn, SCD_MSG_SYSFS_RESP_RELEASE, packet_err, nodeh, 0);
    if !packet_errp.is_null() {
        write(packet_errp, packet_err);
    }
    send_error
}
