/work/native-sysfs-tree-module-20260907-2/tree/source/scripts/tests/fixtures/mckernel_sysfs_tree_verify.o
