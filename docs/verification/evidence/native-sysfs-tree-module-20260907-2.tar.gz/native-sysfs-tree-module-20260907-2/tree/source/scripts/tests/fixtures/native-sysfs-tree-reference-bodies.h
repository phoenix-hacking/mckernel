/* SPDX-License-Identifier: GPL-2.0-only */
static int
release_i(struct sysfsm_node *np)
{
	int error;
	struct sysfsm_data *sdp;

	BUG_ON(!np);
	dprintk("mcctrl:release_i(%p %s)\n", np, np->name);

	sdp = np->sdp;

	if (np->type != SNT_DIR) {
		if (np->server_ops && np->server_ops->release) {
			(*np->server_ops->release)(np->server_ops, np);
		}
	}
	kfree(np->name);
	kfree(np);

	error = 0;
#if 0
out:
#endif
	if (error) {
		eprintk("mcctrl:release_i(%p %s): %d\n", np, np->name, error);
	}
	dprintk("mcctrl:release_i(%p): %d\n", np, error);
	return error;
} /* release_i() */

static struct sysfsm_node *
lookup_i(struct sysfsm_node *dirp, const char *name)
{
#ifdef MCCTRL_RUST_HELPERS
	BUG_ON(!dirp);
	BUG_ON(!name);
	dprintk("mcctrl:lookup_i(%s,%s)\n", dirp->name, name);

	return mcctrl_sysfs_lookup_i_body_result(
		dirp, name, SNT_DIR, mcctrl_sysfs_node_type_bridge,
		mcctrl_sysfs_node_name_bridge,
		mcctrl_sysfs_first_child_bridge,
		mcctrl_sysfs_next_child_bridge,
		mcctrl_sysfs_err_ptr_bridge);
#else
	int error;
	struct sysfsm_node *np;

	BUG_ON(!dirp);
	BUG_ON(!name);
	dprintk("mcctrl:lookup_i(%s,%s)\n", dirp->name, name);

	if (dirp->type != SNT_DIR) {
		error = -ENOTDIR;
		eprintk("mcctrl:lookup_i:not a directory. %d\n", error);
		goto out;
	}

	if (name[0] == '\0') {
		error = -ENOENT;
		eprintk("mcctrl:lookup_i:null component. %d\n", error);
		goto out;
	}

	list_for_each_entry(np, &dirp->children, chain) {
		if (!strcmp(np->name, name)) {
			/* found */
			error = 0;
			goto out;
		}
	}

	/* this is usual when called from create_i(), mkdir_i() and symlink_i(). */
	error = ENOENT; /* positive value means suppressing error message */
out:
	if (error) {
		if (error < 0) {
			eprintk("mcctrl:lookup_i(%s,%s): %d\n",
					dirp->name, name, error);
		}
		else {
			error = -error;
		}
		np = ERR_PTR(error);
	}
	dprintk("mcctrl:lookup_i(%s,%s): %p %d\n",
			dirp->name, name, np, error);
	return np;
#endif
} /* lookup_i() */

static struct sysfsm_node *
create_i(struct sysfsm_node *parent, const char *name, mode_t mode,
		struct sysfsm_ops *server_ops, long client_ops,
		long client_instance)
{
	int error;
	struct sysfsm_node *np = NULL;
	struct sysfsm_data *sdp;

	BUG_ON(!parent);
	BUG_ON(!name);
	dprintk("mcctrl:create_i(%s,%s,%#o,%#lx,%#lx)\n",
			parent->name, name, mode, client_ops, client_instance);

	sdp = parent->sdp;

	if (parent == sdp->sysfs_root) {
		error = -EPERM;
		eprintk("mcctrl:create_i:root dir. %d\n", error);
		goto out;
	}

	if (parent->type != SNT_DIR) {
		error = -ENOTDIR;
		eprintk("mcctrl:create_i:not a directory. %d\n", error);
		goto out;
	}

	if (name[0] == '\0') {
		error = -EINVAL;
		eprintk("mcctrl:create_i:null filename. %d\n", error);
		goto out;
	}

	np = lookup_i(parent, name);
	if (!IS_ERR(np)) {
		error = -EEXIST;
		eprintk("mcctrl:create_i:already exist. %d\n", error);
		np = NULL;
		goto out;
	}

	np = kzalloc(sizeof(*np), GFP_KERNEL);
	if (!np) {
		error = -ENOMEM;
		eprintk("mcctrl:create_i:kzalloc failed. %d\n", error);
		goto out;
	}

	np->type = SNT_FILE;
	np->name = kstrdup(name, GFP_KERNEL);
	np->parent = parent;
	np->sdp = sdp;
	INIT_LIST_HEAD(&np->chain);
	np->attr.name = np->name;
	np->attr.mode = mode;
	np->server_ops = server_ops;
	np->client_ops = client_ops;
	np->client_instance = client_instance;

	if (!np->name) {
		error = -ENOMEM;
		eprintk("mcctrl:create_i:kstrdup failed. %d\n", error);
		goto out;
	}

	error = sysfs_create_file(&parent->kobj, &np->attr);
	if (error) {
		eprintk("mcctrl:create_i:sysfs_create_file failed. %d\n",
				error);
		goto out;
	}

	list_add(&np->chain, &parent->children);

	error = 0;
out:
	if (error) {
		if (np) {
			kfree(np->name);
			kfree(np);
		}
		np = ERR_PTR(error);
		eprintk("mcctrl:create_i(%s,%s,%#o,%#lx,%#lx) : %d\n",
				parent->name, name, mode, client_ops,
				client_instance, error);
	}
	dprintk("mcctrl:create_i(%s,%s,%#o,%#lx,%#lx) : %p %d\n",
			parent->name, name, mode, client_ops, client_instance,
			np, error);
	return np;
} /* create_i() */

static struct sysfsm_node *
mkdir_i(struct sysfsm_node *parent, const char *name)
{
	int error;
	struct sysfsm_node *np = NULL;
	struct kobject *parent_kobj;
	struct sysfsm_data *sdp;

	BUG_ON(!parent);
	BUG_ON(!name);
	dprintk("mcctrl:mkdir_i(%s,%s)\n", parent->name, name);

	sdp = parent->sdp;

	if ((parent == sdp->sysfs_root) && strcmp(name, "sys")) {
		error = -EPERM;
		eprintk("mcctrl:mkdir_i:root dir. %d\n", error);
		goto out;
	}

	if (parent->type != SNT_DIR) {
		error = -ENOTDIR;
		eprintk("mcctrl:mkdir_i:not a directory. %d\n", error);
		goto out;
	}

	if (name[0] == '\0') {
		error = -EINVAL;
		eprintk("mcctrl:mkdir_i:null dirname. %d\n", error);
		goto out;
	}

	np = lookup_i(parent, name);
	if (!IS_ERR(np)) {
		error = -EEXIST;
		eprintk("mcctrl:mkdir_i:already exist. %d\n", error);
		np = NULL;
		goto out;
	}

	np = kzalloc(sizeof(*np), GFP_KERNEL);
	if (!np) {
		error = -ENOMEM;
		eprintk("mcctrl:mkdir_i:kzalloc failed. %d\n", error);
		goto out;
	}

	np->type = SNT_DIR;
	np->name = kstrdup(name, GFP_KERNEL);
	np->parent = parent;
	np->sdp = sdp;
	INIT_LIST_HEAD(&np->chain);
	INIT_LIST_HEAD(&np->children);

	if (!np->name) {
		error = -ENOMEM;
		eprintk("mcctrl:mkdir_i:kstrdup failed. %d\n", error);
		goto out;
	}

	parent_kobj = &parent->kobj;
	if (parent == sdp->sysfs_root) {
		parent_kobj = sdp->sysfs_kobj;
	}

	error = kobject_init_and_add(&np->kobj, &the_ktype, parent_kobj,
			np->name);
	if (error) {
		eprintk("mcctrl:mkdir_i:kobject_init_and_add failed. %d\n",
				error);
		goto out;
	}

	list_add(&np->chain, &parent->children);

	error = 0;
out:
	if (error) {
		if (np) {
			kfree(np->name);
			kfree(np);
		}
		np = ERR_PTR(error);
		eprintk("mcctrl:mkdir_i(%s,%s): %d\n",
				parent->name, name, error);
	}
	dprintk("mcctrl:mkdir_i(%s,%s): %p %d\n",
			parent->name, name, np, error);
	return np;
} /* mkdir_i() */

static struct sysfsm_node *
symlink_i(struct sysfsm_node *target, struct sysfsm_node *parent,
		const char *name)
{
	int error;
	struct sysfsm_node *np = NULL;
	struct sysfsm_data *sdp;

	BUG_ON(!target);
	BUG_ON(!parent);
	BUG_ON(!name);
	dprintk("mcctrl:symlink_i(%s,%s,%s)\n",
			target->name, parent->name, name);

	sdp = parent->sdp;

	if (target->type != SNT_DIR) {
		error = -EINVAL;
		eprintk("mcctrl:symlink_i:target isn't a directory. %d\n",
				error);
		goto out;
	}

	if (parent == sdp->sysfs_root) {
		error = -EPERM;
		eprintk("mcctrl:symlink_i:root directory. %d\n", error);
		goto out;
	}

	if (parent->type != SNT_DIR) {
		error = -ENOTDIR;
		eprintk("mcctrl:symlink_i:parent isn't a directory. %d\n",
				error);
		goto out;
	}

	if (name[0] == '\0') {
		error = -EINVAL;
		eprintk("mcctrl:symlink_i:null linkname. %d\n", error);
		goto out;
	}

	np = lookup_i(parent, name);
	if (!IS_ERR(np)) {
		error = -EEXIST;
		eprintk("mcctrl:symlink_i:already exist. %d\n", error);
		np = NULL;
		goto out;
	}

	np = kzalloc(sizeof(*np), GFP_KERNEL);
	if (!np) {
		error = -ENOMEM;
		eprintk("mcctrl:symlink_i:kzalloc failed. %d\n", error);
		goto out;
	}

	np->type = SNT_LINK;
	np->name = kstrdup(name, GFP_KERNEL);
	np->parent = parent;
	np->sdp = sdp;
	INIT_LIST_HEAD(&np->chain);

	if (!np->name) {
		error = -ENOMEM;
		eprintk("mcctrl:symlink_i:kstrdup failed. %d\n", error);
		goto out;
	}

	error = sysfs_create_link(&parent->kobj, &target->kobj, name);
	if (error) {
		eprintk("mcctrl:symlink_i:sysfs_create_link failed. %d\n",
				error);
		goto out;
	}

	list_add(&np->chain, &parent->children);

	error = 0;
out:
	if (error) {
		if (np) {
			kfree(np->name);
			kfree(np);
		}
		np = ERR_PTR(error);
		eprintk("mcctrl:symlink_i(%s,%s,%s): %d\n",
				target->name, parent->name, name, error);
	}
	dprintk("mcctrl:symlink_i(%s,%s,%s): %p %d\n",
			target->name, parent->name, name, np, error);
	return np;
} /* symlink_i() */

static int
unlink_i(struct sysfsm_node *np)
{
	int error;
	struct sysfsm_data *sdp;

	BUG_ON(!np);
	dprintk("mcctrl:unlink_i(%s)\n", np->name);

	sdp = np->sdp;

	if ((np == sdp->sysfs_root) || (np->parent == sdp->sysfs_root)) {
		error = -EPERM;
		eprintk("mcctrl:unlink_i:protected directory. %d\n", error);
		goto out;
	}

	if ((np->type == SNT_DIR) && !list_empty(&np->children)) {
		error = -ENOTEMPTY;
		eprintk("mcctrl:unlink_i:not empty dir. %d\n", error);
		goto out;
	}

	list_del(&np->chain);
	if (np->type == SNT_FILE) {
		sysfs_remove_file(&np->parent->kobj, &np->attr);
	}
	else if (np->type == SNT_DIR) {
		if (np->parent != np) {
			kobject_del(&np->kobj);
		}
	}
	else if (np->type == SNT_LINK) {
		sysfs_remove_link(&np->parent->kobj, np->name);
	}
	else {
		BUG();
	}

	error = release_i(np);
	if (error) {
		eprintk("mcctrl:unlink_i:release_i failed. %d\n", error);
		goto out;
	}

	error = 0;
out:
	if (error) {
		eprintk("mcctrl:unlink_i(%s): %d\n", np->name, error);
	}
	dprintk("mcctrl:unlink_i(%s): %d\n", (!error)?NULL:np->name, error);
	return error;
} /* unlink_i() */

static int
remove(struct sysfsm_node *target)
{
	int error;
	struct sysfsm_node *np;
	struct sysfsm_node *next_np;

	BUG_ON(!target);
	dprintk("mcctrl:remove(%s)\n", target->name);

	for (np = target; np; np = next_np) {
		while ((np->type == SNT_DIR) && !list_empty(&np->children)) {
			np = list_first_entry(&np->children,
					struct sysfsm_node, chain);
		}

		next_np = np->parent;
		if (np == target) {
			next_np = NULL;
		}

		error = unlink_i(np);
		if (error) {
			eprintk("mcctrl:remove:unlink_i(%s) failed. %d\n",
					np->name, error);
			goto out;
		}
	}

	error = 0;
out:
	if (error) {
		eprintk("mcctrl:remove(%s): %d\n", target->name, error);
	}
	dprintk("mcctrl:remove(%s): %d\n", (!error)?NULL:target->name, error);
	return error;
} /* remove() */

static struct sysfsm_node *
lookup(struct sysfsm_node *from, char *path)
{
	int error;
	struct sysfsm_node *dirp;
	struct sysfsm_node *np;
	char *p;
	char *name;

	BUG_ON(!from);
	BUG_ON(!path);
	dprintk("mcctrl:lookup(%s,%s)\n", from->name, path);

	dirp = from;
	np = from;
	p = path;
	while (!!(name = strsep(&p, "/"))) {
		if (!*name) {
			continue;
		}

		np = lookup_i(dirp, name);
		if (IS_ERR(np)) {
			error = PTR_ERR(np);
			eprintk("mcctrl:lookup:lookup_i(%s,%s) failed. %d\n",
					dirp->name, name, error);
			goto out;
		}
		dirp = np;
	}

	error = 0;
out:
	if (error) {
		np = ERR_PTR(error);
		eprintk("mcctrl:lookup(%s,%s): %d\n", from->name, path, error);
	}
	dprintk("mcctrl:lookup(%s,%s): %p %d\n", from->name, path, np, error);
	return np;
} /* lookup() */

static struct sysfsm_node *
dig(struct sysfsm_node *from, char *path)
{
	int error;
	struct sysfsm_node *dirp;
	char *p;
	char *name;
	struct sysfsm_node *np;

	BUG_ON(!from);
	BUG_ON(!path);
	dprintk("mcctrl:dig(%s,%s)\n", from->name, path);

	dirp = from;
	p = path;
	while (!!(name = strsep(&p, "/"))) {
		if (!*name) {
			continue;
		}

		np = lookup_i(dirp, name);
		if (IS_ERR(np)) {
			error = PTR_ERR(np);
			if (error != -ENOENT) {
				eprintk("mcctrl:dig:lookup_i(%s,%s) failed. %d\n",
						dirp->name, name, error);
				goto out;
			}

			np = mkdir_i(dirp, name);
			if (IS_ERR(np)) {
				error = PTR_ERR(np);
				eprintk("mcctrl:dig:mkdir_i(%s,%s) failed. %d\n",
						dirp->name, name, error);
				goto out;
			}
		}
		dirp = np;
	}

	if (dirp->type != SNT_DIR) {
		error = -ENOTDIR;
		eprintk("mcctrl:dig:%s:not a directory. %d\n",
				dirp->name, error);
		goto out;
	}

	error = 0;
out:
	if (error) {
		dirp = ERR_PTR(error);
		eprintk("mcctrl:dig(%s): %d\n", from->name, error);
	}
	dprintk("mcctrl:dig(%s): %p %d\n", from->name, dirp, error);
	return dirp;
} /* dig() */

static void
cleanup_ancestor(struct sysfsm_node *target)
{
	int error;
	struct sysfsm_node *np;
	struct sysfsm_node *next_np;

	BUG_ON(!target);
	dprintk("mcctrl:cleanup_ancestor(%p {%s})\n", target, target->name);

	error = 0;
	for (np = target; !error; np = next_np) {
		next_np = np->parent;

		if ((np == np->sdp->sysfs_root)
				|| (np->parent == np->sdp->sysfs_root)
				|| !list_empty(&np->children)) {
			break;
		}

		error = unlink_i(np);
	}

	dprintk("mcctrl:cleanup_ancestor(%p):\n", target);
	return;
} /* cleanup_ancestor() */

static struct sysfsm_node *
sysfsm_create(struct sysfsm_data *sdp, const char *path0, mode_t mode,
		struct sysfsm_ops *server_ops, long client_ops,
		long client_instance)
{
	int error;
	char *path = NULL;
	struct semaphore *held_sem = NULL;
	struct sysfsm_node *dirp;
	char *name;
	struct sysfsm_node *np = ERR_PTR(-EIO);

	BUG_ON(!sdp);
	dprintk("mcctrl:sysfsm_create(%p,%s,%#o,%#lx,%#lx)\n",
			sdp, path0, mode, client_ops, client_instance);

	path = kstrdup(path0, GFP_KERNEL);
	if (!path) {
		error = -ENOMEM;
		eprintk("mcctrl:sysfsm_create:kstrdup failed. %d\n", error);
		goto out;
	}

	error = down_interruptible(&sdp->sysfs_tree_sem);
	if (error) {
		eprintk("mcctrl:sysfsm_create:down failed. %d\n", error);
		goto out;
	}
	held_sem = &sdp->sysfs_tree_sem;

	dirp = sdp->sysfs_root;
	name = strrchr(path, '/');
	if (!name) {
		name = path;
	}
	else {
		*name = '\0';
		++name;

		dirp = dig(dirp, path);
		if (IS_ERR(dirp)) {
			error = PTR_ERR(dirp);
			eprintk("mcctrl:sysfsm_create:dig failed. %d\n",
					error);
			goto out;
		}
	}

	np = create_i(dirp, name, mode, server_ops, client_ops,
			client_instance);
	if (IS_ERR(np)) {
		error = PTR_ERR(np);
		eprintk("mcctrl:sysfsm_create:create_i(%s,%s) failed. %d\n",
				dirp->name, name, error);
		goto out;
	}

	error = 0;
out:
	if (held_sem) {
		up(held_sem);
	}
	kfree(path);
	if (error) {
		np = ERR_PTR(error);
		eprintk("mcctrl:sysfsm_create(%p,%s,%#o,%#lx,%#lx): %d\n",
				sdp, path0, mode, client_ops, client_instance,
				error);
	}
	dprintk("mcctrl:sysfsm_create(%p,%s,%#o,%#lx,%#lx): %p %d\n",
			sdp, path0, mode, client_ops, client_instance, np,
			error);
	return np;
} /* sysfsm_create() */

struct sysfsm_node *
sysfsm_mkdir(struct sysfsm_data *sdp, const char *path0)
{
	int error;
	char *path = NULL;
	struct semaphore *held_sem = NULL;
	struct sysfsm_node *dirp;
	char *name;
	struct sysfsm_node *np = ERR_PTR(-EIO);

	BUG_ON(!sdp);
	dprintk("mcctrl:sysfsm_mkdir(%p,%s)\n", sdp, path0);

	path = kstrdup(path0, GFP_KERNEL);
	if (!path) {
		error = -ENOMEM;
		eprintk("mcctrl:sysfsm_mkdir:kstrdup failed. %d\n", error);
		goto out;
	}

	error = down_interruptible(&sdp->sysfs_tree_sem);
	if (error) {
		eprintk("mcctrl:sysfsm_mkdir:down failed. %d\n", error);
		goto out;
	}
	held_sem = &sdp->sysfs_tree_sem;

	dirp = sdp->sysfs_root;
	name = strrchr(path, '/');
	if (!name) {
		name = path;
	}
	else {
		*name = '\0';
		++name;

		dirp = dig(dirp, path);
		if (IS_ERR(dirp)) {
			error = PTR_ERR(dirp);
			eprintk("mcctrl:sysfsm_mkdir:dig failed. %d\n", error);
			goto out;
		}
	}

	np = mkdir_i(dirp, name);
	if (IS_ERR(np)) {
		error = PTR_ERR(np);
		eprintk("mcctrl:sysfsm_mkdir:mkdir_i failed. %d\n", error);
		goto out;
	}

	error = 0;
out:
	if (held_sem) {
		up(held_sem);
	}
	kfree(path);
	if (error) {
		np = ERR_PTR(error);
		eprintk("mcctrl:sysfsm_mkdir(%p,%s): %d\n", sdp, path0, error);
	}
	dprintk("mcctrl:sysfsm_mkdir(%p,%s): %p %d\n", sdp, path0, np, error);
	return np;
} /* sysfsm_mkdir() */

struct sysfsm_node *
sysfsm_symlink(struct sysfsm_data *sdp, struct sysfsm_node *target,
		const char *path0)
{
	int error;
	char *path = NULL;
	struct semaphore *held_sem = NULL;
	char *name;
	struct sysfsm_node *dirp;
	struct sysfsm_node *np = ERR_PTR(-EIO);

	BUG_ON(!sdp);
	BUG_ON(!target);
	dprintk("mcctrl:sysfsm_symlink(%p,%s,%s)\n", sdp, target->name, path0);

	path = kstrdup(path0, GFP_KERNEL);
	if (!path) {
		error = -ENOMEM;
		eprintk("mcctrl:sysfsm_symlink:kstrdup failed. %d\n", error);
		goto out;
	}

	error = down_interruptible(&sdp->sysfs_tree_sem);
	if (error) {
		eprintk("mcctrl:sysfsm_symlink:down failed. %d\n", error);
		goto out;
	}
	held_sem = &sdp->sysfs_tree_sem;

	dirp = sdp->sysfs_root;
	name = strrchr(path, '/');
	if (!name) {
		name = path;
	}
	else {
		*name = '\0';
		++name;

		dirp = dig(dirp, path);
		if (IS_ERR(dirp)) {
			error = PTR_ERR(dirp);
			eprintk("mcctrl:sysfsm_symlink:dig failed. %d\n",
					error);
			goto out;
		}
	}

	np = symlink_i(target, dirp, name);
	if (IS_ERR(np)) {
		error = PTR_ERR(np);
		eprintk("mcctrl:sysfsm_symlink:symlink_i(%s,%s,%s) failed. %d\n",
				target->name, dirp->name, name, error);
		goto out;
	}

	error = 0;
out:
	if (held_sem) {
		up(held_sem);
	}
	kfree(path);
	if (error) {
		np = ERR_PTR(error);
		eprintk("mcctrl:sysfsm_symlink(%p,%s,%s): %d\n",
				sdp, target->name, path0, error);
	}
	dprintk("mcctrl:sysfsm_symlink(%p,%s,%s): %p %d\n",
			sdp, target->name, path0, np, error);
	return np;
} /* sysfsm_symlink() */

static struct sysfsm_node *
sysfsm_lookup(struct sysfsm_data *sdp, const char *path0)
{
	int error;
	char *path = NULL;
	struct semaphore *held_sem = NULL;
	struct sysfsm_node *np;

	BUG_ON(!sdp);
	dprintk("mcctrl:sysfsm_lookup(%p,%s)\n", sdp, path0);

	path = kstrdup(path0, GFP_KERNEL);
	if (!path) {
		error = -ENOMEM;
		eprintk("mcctrl:sysfsm_lookup:kstrdup failed. %d\n", error);
		goto out;
	}

	error = down_interruptible(&sdp->sysfs_tree_sem);
	if (error) {
		eprintk("mcctrl:sysfsm_lookup:down failed. %d\n", error);
		goto out;
	}
	held_sem = &sdp->sysfs_tree_sem;

	np = lookup(sdp->sysfs_root, path);
	if (IS_ERR(np)) {
		error = PTR_ERR(np);
		eprintk("mcctrl:sysfsm_lookup:lookup failed. %d\n", error);
		goto out;
	}

	error = 0;
out:
	if (held_sem) {
		up(held_sem);
	}
	kfree(path);
	if (error) {
		np = ERR_PTR(error);
		eprintk("mcctrl:sysfsm_lookup(%p,%s): %d\n",
				sdp, path0, error);
	}
	dprintk("mcctrl:sysfsm_lookup(%p,%s): %p %d\n", sdp, path0, np, error);
	return np;
} /* sysfsm_lookup() */

static int
sysfsm_unlink(struct sysfsm_data *sdp, const char *path0, int flags)
{
	int error;
	char *path = NULL;
	struct semaphore *held_sem = NULL;
	struct sysfsm_node *dirp;
	struct sysfsm_node *np;

	BUG_ON(!sdp);
	dprintk("mcctrl:sysfsm_unlink(%p,%s,%#x)\n", sdp, path0, flags);

	path = kstrdup(path0, GFP_KERNEL);
	if (!path) {
		error = -ENOMEM;
		eprintk("mcctrl:sysfsm_unlink:kstrdup failed. %d\n", error);
		goto out;
	}

	error = down_interruptible(&sdp->sysfs_tree_sem);
	if (error) {
		eprintk("mcctrl:sysfsm_unlink:down failed. %d\n", error);
		goto out;
	}
	held_sem = &sdp->sysfs_tree_sem;

	np = lookup(sdp->sysfs_root, path);
	if (IS_ERR(np)) {
		error = PTR_ERR(np);
		eprintk("mcctrl:sysfsm_unlink:lookup failed. %d\n", error);
		goto out;
	}

	dirp = np->parent;

	error = remove(np);
	if (error) {
		eprintk("mcctrl:sysfsm_unlink:remove failed. %d\n", error);
		goto out;
	}

	if (!(flags & SYSFS_UNLINK_KEEP_ANCESTOR)) {
		cleanup_ancestor(dirp);
	}

	error = 0;
out:
	if (held_sem) {
		up(held_sem);
	}
	kfree(path);
	if (error) {
		eprintk("mcctrl:sysfsm_unlink(%p,%s,%#x): %d\n",
				sdp, path0, flags, error);
	}
	dprintk("mcctrl:sysfsm_unlink(%p,%s,%#x): %d\n",
			sdp, path0, flags, error);
	return error;
} /* sysfsm_unlink() */
