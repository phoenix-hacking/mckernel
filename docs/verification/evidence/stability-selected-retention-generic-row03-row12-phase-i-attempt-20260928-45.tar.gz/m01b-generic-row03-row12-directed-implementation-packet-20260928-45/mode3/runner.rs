#![cfg(test)]
//! Source-only standalone host-test crate for the mode-3 staged bytes.
//! No production source includes this runner, and this Phase-I packet does not compile it.
extern crate self as kernel;
pub mod bindings { pub unsafe fn ktime_get() -> i64 { 2_000_000_000 } }
#[macro_export] macro_rules! pr_info { ($($arg:tt)*) => {{ let _ = format_args!($($arg)*); }} }
pub mod prelude { pub use std::vec::Vec; pub trait VecExt {} pub const GFP_KERNEL: () = (); }
#[path = "source/application_rpc.rs"] mod application_rpc;
#[path = "source/application_syscall.rs"] mod application_syscall;
#[path = "source/smp_application_syscall.rs"] mod smp_application_syscall;
#[path = "source/stability_observer.rs"] mod stability_observer;
#[path = "source/stability_phase.rs"] mod stability_phase;
#[path = "adapter.rs"] pub mod selected_retention_test_adapter;
