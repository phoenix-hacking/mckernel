#![cfg(test)]
//! Mode-3-only retained-response fixture.  This file is loaded solely by this
//! mode's standalone runner; production source never includes it.
use std::ptr::NonNull;
use std::sync::{Arc, Mutex};

use crate::application_syscall::{Request, ResponseMemory};
use crate::stability_observer::{Claim, Tag};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum Event {
    Construction, PreparationBaseline, StatusStore, Release, DeferredInsertion,
    FinishedDrop, UnfinishedDrop, QuarantineInsertion, Deallocation,
}
pub(crate) struct State {
    deferred: Vec<Box<AlignedBacking>>,
    quarantine: Vec<Box<AlignedBacking>>,
    events: Vec<Event>,
}
pub(crate) struct Ledger { state: Mutex<State> }
impl Ledger {
    pub(crate) fn new() -> Arc<Self> {
        Arc::new(Self { state: Mutex::new(State {
            deferred: Vec::with_capacity(1), quarantine: Vec::with_capacity(1),
            events: Vec::with_capacity(9),
        })})
    }
    pub(crate) fn record(&self, event: Event) { self.state.lock().unwrap().events.push(event); }
    pub(crate) fn snapshot(&self) -> Vec<Event> { self.state.lock().unwrap().events.clone() }
    pub(crate) fn drain_deferred(&self) { self.drain(false); }
    pub(crate) fn drain_quarantine(&self) { self.drain(true); }
    fn drain(&self, quarantine: bool) {
        let batch = { let mut state = self.state.lock().unwrap();
            if quarantine { std::mem::take(&mut state.quarantine) } else { std::mem::take(&mut state.deferred) }
        };
        let count = batch.len(); drop(batch);
        for _ in 0..count { self.record(Event::Deallocation); }
    }
}
#[repr(align(8))]
pub(crate) struct AlignedBacking { bytes: [u8; 56] }
pub(crate) struct TestResponseMemory {
    backing: Option<Box<AlignedBacking>>, span: NonNull<u8>, ledger: Arc<Ledger>, released: bool,
}
impl TestResponseMemory {
    pub(crate) fn new(ledger: Arc<Ledger>) -> Self {
        let mut backing = Box::new(AlignedBacking { bytes: [0; 56] });
        let span = NonNull::new(unsafe { backing.bytes.as_mut_ptr().add(8) }).unwrap();
        ledger.record(Event::Construction);
        Self { backing: Some(backing), span, ledger, released: false }
    }
    pub(crate) fn baseline(&self) { self.ledger.record(Event::PreparationBaseline); }
    pub(crate) fn owner() -> Claim { Claim { os: 1, generation: 1,
        response: Tag { index: 0, serial: Some(1), physical: 0x1000, end: 0x1028 }, payload: None } }
}
unsafe impl ResponseMemory for TestResponseMemory {
    fn verification_owner(&self) -> Option<Claim> { Some(Self::owner()) }
    fn verification_status_store(&self) { self.ledger.record(Event::StatusStore); }
    fn physical(&self) -> u64 { 0x1000 }
    fn address(&mut self) -> *mut u8 { self.span.as_ptr() }
    unsafe fn release(mut self) {
        self.released = true;
        let backing = self.backing.take().expect("one retained backing");
        { let mut state = self.ledger.state.lock().unwrap(); state.events.push(Event::Release); state.deferred.push(backing); state.events.push(Event::DeferredInsertion); }
    }
}
impl Drop for TestResponseMemory {
    fn drop(&mut self) {
        if self.released { self.ledger.record(Event::FinishedDrop); }
        else if let Some(backing) = self.backing.take() {
            let mut state = self.ledger.state.lock().unwrap(); state.events.push(Event::UnfinishedDrop);
            state.quarantine.push(backing); state.events.push(Event::QuarantineInsertion);
        }
    }
}
pub(crate) fn request() -> Request {
    let mut bytes = [0u8; 128];
    bytes[8..12].copy_from_slice(&4i32.to_le_bytes()); bytes[24..28].copy_from_slice(&0i32.to_le_bytes());
    bytes[32..36].copy_from_slice(&70i32.to_le_bytes()); bytes[48..52].copy_from_slice(&70i32.to_le_bytes());
    bytes[52..56].copy_from_slice(&0i32.to_le_bytes()); bytes[56..64].copy_from_slice(&1u64.to_le_bytes());
    bytes[64..72].copy_from_slice(&0u64.to_le_bytes()); bytes[72..80].copy_from_slice(&0u64.to_le_bytes());
    bytes[80..88].copy_from_slice(&0x2000u64.to_le_bytes()); bytes[88..96].copy_from_slice(&16u64.to_le_bytes());
    bytes[120..128].copy_from_slice(&0x1000u64.to_le_bytes()); Request::decode(&bytes, 1).expect("exact request")
}
