/work/mckernel-native-ultra-images-20260909-3/invalid-native-fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-ultra-images-20260909-3/invalid-native-fallback/tmp.resolve_MODULES_END/driver.o

