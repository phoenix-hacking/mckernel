/work/mckernel-native-ultra-images-20260909-3/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-ultra-images-20260909-3/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.o

