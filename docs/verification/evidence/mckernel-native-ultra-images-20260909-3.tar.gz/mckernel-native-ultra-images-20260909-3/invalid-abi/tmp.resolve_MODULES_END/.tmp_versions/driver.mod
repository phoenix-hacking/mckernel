/work/mckernel-native-ultra-images-20260909-3/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-ultra-images-20260909-3/invalid-abi/tmp.resolve_MODULES_END/driver.o

