/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o
