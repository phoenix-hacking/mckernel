savedcmd_/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o := RUST_MODFILE=/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify rustc --edition=2021 -Zbinary_dep_depinfo=y -Astable_features -Dunsafe_op_in_unsafe_fn -Dnon_ascii_idents -Wrust_2018_idioms -Wunreachable_pub -Wmissing_docs -Wrustdoc::missing_crate_level_docs -Wclippy::all -Wclippy::mut_mut -Wclippy::needless_bitwise_bool -Wclippy::needless_continue -Wclippy::no_mangle_with_rust_abi -Wclippy::dbg_macro -Cpanic=abort -Cembed-bitcode=n -Clto=n -Cforce-unwind-tables=n -Ccodegen-units=1 -Csymbol-mangling-version=v0 -Crelocation-model=static -Zfunction-sections=n -Wclippy::float_arithmetic --target=./scripts/target.json -Ctarget-feature=-sse,-sse2,-sse3,-ssse3,-sse4.1,-sse4.2,-avx,-avx2 -Zcf-protection=branch -Zno-jump-tables -Ztune-cpu=generic -Cno-redzone=y -Ccode-model=kernel -Zfunction-return=thunk-extern -Zpatchable-function-entry=16,16 -Copt-level=2 -Cdebug-assertions=n -Coverflow-checks=n -Dwarnings -Cdebuginfo=2  --cfg MODULE  @./include/generated/rustc_cfg -Zallow-features=arbitrary_self_types,new_uninit,used_with_arg -Zcrate-attr=no_std -Zcrate-attr='feature(arbitrary_self_types,new_uninit,used_with_arg)' -Zunstable-options --extern force:alloc --extern kernel --crate-type rlib -L ./rust/ --crate-name mckernel_sysfs_objects_verify --sysroot=/dev/null --out-dir /work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/ --emit=dep-info=/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/.mckernel_sysfs_objects_verify.o.d --emit=obj=/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o /work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.rs  ; ./tools/objtool/objtool --hacks=jump_label --hacks=noinstr --hacks=skylake --ibt --mcount --mnop --orc --retpoline --rethunk --sls --static-call --uaccess --prefix=16  --link  --module /work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o

source_/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o := /work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.rs

deps_/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o := \
  /work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs \
  ./rust/libcore.rmeta \
  ./rust/libkernel.rmeta \
  ./rust/liballoc.rmeta \
  ./rust/libcompiler_builtins.rmeta \
  ./rust/libmacros.so \
  ./rust/libbindings.rmeta \
  ./rust/libuapi.rmeta \
  ./rust/libbuild_error.rmeta \

/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o: $(deps_/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o)

$(deps_/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o):

/work/native-sysfs-objects-module-20260907-4/source/scripts/tests/fixtures/mckernel_sysfs_objects_verify.o: $(wildcard ./tools/objtool/objtool)
