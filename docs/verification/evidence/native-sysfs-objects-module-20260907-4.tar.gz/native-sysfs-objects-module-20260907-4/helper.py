from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
build = Path('/work/native-build-base-24a151fe')
linux = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
kernel = Path('/work/native-vdso-kernel-20260907-3')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
out = Path('/work/native-sysfs-objects-module-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], compiler_inputs=[], commands=[], production_gate_credit=False,
    sysfs_service_completed=False, declared_stage=False)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-9000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    for name in ['.config', 'Module.symvers', 'rust/bindings/bindings_generated.rs']:
        source = build / name
        target = out / Path(name).name
        shutil.copyfile(source, target)
        record['inputs'].append(identity(target))
    for name in ['lib/kobject.c', 'fs/sysfs/file.c', 'fs/sysfs/symlink.c', 'fs/sysfs/dir.c',
                 'fs/kernfs/dir.c', 'fs/kernfs/file.c', 'include/linux/kobject.h', 'include/linux/sysfs.h']:
        target = out / 'linux-reference' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(linux / name, target)
        record['inputs'].append(identity(target))
    shutil.copyfile(__file__, out / 'helper.py')
    inputs = ['host-kernel/native-rust/sysfs_objects.rs',
              'scripts/tests/fixtures/mckernel_sysfs_objects_verify.rs',
              'scripts/tests/fixtures/native-sysfs-objects.c',
              'scripts/tests/fixtures/native_sysfs_objects_layout.c']
    for name in inputs:
        for base in ['original-inputs', 'source']:
            target = out / base / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(repo / name, target)
        record['inputs'].append(identity(out / 'original-inputs' / name))
    rust = [str(out / 'source' / name) for name in inputs if name.endswith('.rs')]
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + rust)
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false'] + rust)
    record['compiler_inputs'] = [identity(out / 'source' / name) for name in inputs]
    module = out / 'source/scripts/tests/fixtures'
    (module / 'Kbuild').write_text('obj-m += mckernel_sysfs_objects_verify.o\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('layout-witness', base + ['M=' + str(module), 'native_sysfs_objects_layout.o'])
    run('c-layout-extract', ['objcopy', '--dump-section', '.mckernel_sysfs_layout=' + str(out / 'c-layout.bin'),
                           str(module / 'native_sysfs_objects_layout.o'), str(out / 'c-layout-copy.o')])
    run('module-build', base + ['M=' + str(module), 'modules'])
    compiled = out / 'mckernel_sysfs_objects_verify.ko'
    shutil.copyfile(module / compiled.name, compiled)
    run('rust-layout-extract', ['objcopy', '--dump-section', '.mckernel_sysfs_layout=' + str(out / 'rust-layout.bin'),
                          str(compiled), str(out / 'rust-layout-copy.ko')])
    assert (out / 'rust-layout.bin').read_bytes() == (out / 'c-layout.bin').read_bytes()
    record['layout'] = list(struct.unpack('<21Q', (out / 'c-layout.bin').read_bytes()))
    for tool, name in [(['nm', '-u'], 'undefined.txt'), (['objdump', '-d'], 'disassembly.txt'),
                       (['readelf', '-h'], 'elf-header.txt')]:
        (out / name).write_bytes(subprocess.check_output(tool + [str(compiled)]))
    symbols = (out / 'undefined.txt').read_text()
    for name in ('kobject_init_and_add', 'kobject_put', 'kobject_del',
                 'kobj_sysfs_ops', 'sysfs_create_file_ns', 'sysfs_remove_file_ns',
                 'sysfs_create_link', 'sysfs_remove_link'):
        assert ' U ' + name + '\n' in symbols, name
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', (out / 'disassembly.txt').read_text())
    assert 'ELF64' in (out / 'elf-header.txt').read_text()
    run('user-probe-build', ['gcc', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror',
        str(module / 'native-sysfs-objects.c'), '-o', str(out / 'native-sysfs-objects')])
    run('user-probe-dependencies', ['ldd', str(out / 'native-sysfs-objects')])
    libraries = out / 'lib64'; libraries.mkdir()
    for name in ['libc.so.6', 'ld-linux-x86-64.so.2']:
        source = Path('/lib64') / name
        shutil.copy2(source, libraries / name)
        record['inputs'].append(identity(libraries / name))
    for row in record['inputs'] + record['compiler_inputs']: assert identity(Path(row['path'])) == row, row
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name not in ('record.json', 'phase')]
    save(); print(record['status'], out, flush=True)
