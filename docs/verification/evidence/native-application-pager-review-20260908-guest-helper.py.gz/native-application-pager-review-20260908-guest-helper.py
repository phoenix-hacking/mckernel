"""Run the unchanged real launcher and ordinary ELF in an isolated native guest."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast, gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
architecture, profile = 'x86_64', 'normal'
compiled = Path('/work/native-application-string-module-20260908-2')
images = Path('/work/mckernel-native-start-images-20260908-1')
launcher = Path('/work/native-application-launcher-20260908-2')
baseline = Path('/work/native-mcctrl-image-guest-20260908-x86_64-4')
case, attempt = sys.argv[1:]
assert case in ('memory','files','threads','signals')
mode='application'
out = Path('/work/native-application-core-' + case + '-guest-20260908-' + attempt)
out.mkdir()
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              architecture=architecture, profile=profile, mode=mode, inputs=[], commands=[], captures=[],
              cpuset=sorted(os.sched_getaffinity(0)), cpus=4, guest_cpus=1, numa_nodes=2,
              memory_mib=8192, container_memory_mib=12288, application_attempted=False,
              mckernel_application_executed=False, production_gate_credit=False)
sequence, stream, process = 0, None, None

# Reuse the exact accepted image-runner's physical capture and boot assertions.
# Extract only these complete function definitions, not its top-level run.
original = (baseline / 'helper.py').read_text()
names = {'identity', 'save', 'qmp', 'dump', 'capture'}
functions = [node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in functions} == names
exec(compile(ast.Module(body=functions, type_ignores=[]), str(baseline / 'helper.py'), 'exec'))

def run(label, command, environment=None):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, result.returncode, (out / (label + '.log')).read_text()[-6000:])
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(baseline / 'helper.py', out / 'capture-reference.py')
    assert shutil.disk_usage('/work').free > 2 * 1024**3
    for directory in (compiled, images, launcher, baseline):
        assert json.loads((directory / 'record.json').read_text())['status'] == 'PASS'
        record['inputs'].append(identity(directory / 'record.json'))
    built = json.loads((compiled / 'record.json').read_text())
    for row in built['outputs']:
        assert identity(Path(row['path'])) == row
    launches = json.loads((launcher / 'record.json').read_text())
    for selection in launches['launchers']:
        for row in selection['outputs']:
            assert identity(Path(row['path'])) == row
    for row in launches['outputs']:
        assert identity(Path(row['path'])) == row
    accepted = json.loads((baseline / 'record.json').read_text())
    if mode == 'application':
        metadata_test = Path('/work/native-application-services-buildid-guest-20260908-1/record.json')
        assert json.loads(metadata_test.read_text())['status'] == 'PASS'
        record['inputs'].append(identity(metadata_test))
    boot = baseline / 'root/bin/native-boot'
    # The complete prior capture and compiler command retain this exact binary.
    record['inputs'] += [identity(boot), identity(baseline / 'helper.py')]
    root = out / 'root'
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), root)
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(compiled / name, root / 'modules' / name)
        record['inputs'].append(identity(compiled / name))
    shutil.copy2(boot, root / 'bin/native-boot')
    assert (root / 'bin/native-boot').stat().st_mode & 0o111 == 0o111
    application = launcher / 'native-application-hello'
    binary = launcher / 'rust/executer/user/mcexec'
    shutil.copyfile(binary, root / 'bin/mcexec')
    shutil.copyfile(application, root / 'bin/native-application-hello')
    (root / 'bin/mcexec').chmod(0o755)
    (root / 'bin/native-application-hello').chmod(0o755)
    record['inputs'] += [identity(binary), identity(application)]
    core=Path('/work/native-application-core-build-20260908-1')
    core_record=json.loads((core/'record.json').read_text());assert core_record['status']=='PASS'
    for row in core_record['outputs']:assert identity(Path(row['path']))==row
    shutil.copyfile(core/'native-application-core',root/'bin/native-application-core');(root/'bin/native-application-core').chmod(0o755)
    record['inputs'] += [identity(core/'record.json'),identity(core/'native-application-core'),identity(core/'native-application-core.c')]
    record['core_case']=case
    expected_core='NATIVE_CORE PASS '+case+'\n'
    assert next(row for row in core_record['linux_reference'] if row['case']==case)['stdout']==expected_core
    probe = out / 'probe-source'
    probe.mkdir()
    for name in ('native-os-buildid.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c', 'native-mcctrl-exec.c', 'native-mcctrl-string.c'):
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, probe / name)
    original_header = repo / 'ihk/linux/include/ihk/ihk_host_user.h'
    build_config = launcher / 'rust/config.h'
    shutil.copyfile(original_header, probe / 'ihk_host_user.h.reference')
    shutil.copyfile(build_config, probe / 'launcher-config.h.reference')
    macro = re.findall(r'^#define IHK_OS_GET_BUILDID\s+0x[0-9a-fA-F]+\s*$', original_header.read_text(), re.M)
    buildid = re.findall(r'^#define BUILDID ("[^"\n]+")$', build_config.read_text(), re.M)
    assert len(macro) == len(buildid) == 1
    payload = compiled / 'staged-source/ihk-compat-build-id.bin'
    assert payload.read_bytes() == json.loads(buildid[0]).encode() + b'\0'
    (probe / 'native-buildid-abi.h').write_text(macro[0].strip() + '\n#define BUILDID ' + buildid[0] + '\n')
    binding = Path('/work/native-sysfs-setup-module-20260907-1/bindings_generated.rs')
    states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', binding.read_text())
    assert len(states) == 1
    for bits, label in ((64, 'x86_64'), (32, 'i386')):
        run('buildid-probe-' + label, ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror',
                                     '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie',
                                     '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack',
                                     '-DCPUHP_FAILURE_STATE=' + states[0], str(probe / 'native-os-buildid.c'),
                                     '-o', str(root / ('bin/native-os-buildid-' + label))])
    protocol=repo/'executer/include/uprotocol.h'
    shutil.copyfile(protocol,probe/'uprotocol.h.reference')
    definition=re.search(r'^struct strncpy_from_user_desc \{[^}]+\};',protocol.read_text(),re.M);assert definition
    constant=re.search(r'^#define MCEXEC_UP_STRNCPY_FROM_USER[^\n]+',protocol.read_text(),re.M);assert constant
    (probe/'native-string-abi.h').write_text(constant[0]+'\n'+definition[0]+'\n')
    for bits,label in ((64,'x86_64'),(32,'i386')):
        run('string-probe-'+label,['cc','-m'+str(bits),'-O2','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-pie','-nostdlib','-static','-no-pie','-Wl,-e,_start','-Wl,-z,noexecstack','-DCPUHP_FAILURE_STATE='+states[0],str(probe/'native-mcctrl-string.c'),'-o',str(root/('bin/native-string-'+label))])
    record['inputs'] += [identity(p) for p in sorted(probe.iterdir())]
    record['inputs'] += [identity(binding), identity(payload)]
    # Use this native Linux userspace's libraries for both the base root and
    # the unchanged older-glibc-compatible launcher. Never mix libc releases.
    dependencies = run('launcher-native-dependencies', ['ldd', str(binary)])
    assert 'not found' not in dependencies
    record['runtime_libraries'] = []
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert identity(target)['sha256'] == identity(original_path)['sha256'], ('library mismatch', name)
        else:
            shutil.copyfile(original_path, target)
        record['runtime_libraries'].append(dict(original=identity(original_path), captured=identity(target)))
    assert len(record['runtime_libraries']) >= 3
    for row in core_record['runtime_libraries']:
        original=Path(row['original']['path']);assert identity(original)==row['original']
        target=root/str(original).lstrip('/')
        if target.exists():assert identity(target)['sha256']==row['original']['sha256']
        else:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
        record['runtime_libraries'].append(dict(original=identity(original),captured=identity(target)))

    image_record = json.loads((images / 'record.json').read_text())
    selected = next(row for row in image_record['images'] if row['kind'] == 'native-rust')
    image = images / 'native-rust/kernel/mckernel.img'
    assert identity(image) in selected['outputs'] and not selected['native_sysfs_verify']
    (root / 'images').mkdir()
    shutil.copyfile(image, root / 'images/mckernel.img')
    init = '''#!/bin/bash
set -euo pipefail
[ "$$" -eq 1 ] && [ "$EUID" -eq 0 ] || exit 125
export PATH=/bin:/sbin:/usr/bin:/usr/sbin LANG=C LC_ALL=C
exec </dev/console >/dev/console 2>&1
finish() { local status=$?; trap - EXIT; if [ "$status" -ne 0 ]; then printf 'NATIVE_APPLICATION_GUEST FAIL status=%s\\n' "$status"; fi; /bin/dmesg || true; /poweroff; }
trap finish EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t debugfs debugfs /sys/kernel/debug
printf '7\\n' >/proc/sys/kernel/printk
read -r online </sys/devices/system/cpu/online
read -r nodes </sys/devices/system/node/online
[ "$online" = 0-3 ] && [ "$nodes" = 0-1 ]
insmod /modules/ihk.ko
insmod /modules/ihk-smp-x86_64.ko ihk_trampoline=524288
insmod /modules/mcctrl.ko
/bin/native-boot
rmmod mcctrl
/bin/native-os-buildid-x86_64
/bin/native-os-buildid-i386
insmod /modules/mcctrl.ko
/bin/native-string-x86_64
/bin/native-string-i386
'''
    if mode == 'application':
        init += '''
printf 'NATIVE_APPLICATION_LINUX_REFERENCE begin\\n'
status=0
/bin/native-application-hello || status=$?
printf 'NATIVE_APPLICATION_LINUX_REFERENCE exit=%s\\n' "$status"
[ "$status" -eq 37 ]
shopt -s nullglob
for iteration in {1..8}; do
printf '<6>NATIVE_APPLICATION_MCEXEC begin iteration=%s\\n' "$iteration" >/dev/kmsg
status=0
application_output=/application-stdout-$iteration
/bin/mcexec -t 1 0 /bin/native-application-hello >"$application_output" || status=$?
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s "$application_output")" -eq 25 ]
IFS= read -r application_line <"$application_output"
[ "$application_line" = NATIVE_APPLICATION_HELLO ]
printf '<6>NATIVE_APPLICATION_STDOUT iteration=%s bytes=25 line=%s\\n' "$iteration" "$application_line" >/dev/kmsg
printf '<6>NATIVE_APPLICATION_MCEXEC exit=%s iteration=%s\\n' "$status" "$iteration" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=%s\\n' "$iteration" >/dev/kmsg
done
printf '<6>NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37\\n' >/dev/kmsg
printf '<6>NATIVE_CORE_MCEXEC begin case=@CORE_CASE@\\n' >/dev/kmsg
status=0
/bin/mcexec -t 1 0 /bin/native-application-core @CORE_CASE@ >/core-stdout || status=$?
printf '<6>NATIVE_CORE_MCEXEC exit=%s case=@CORE_CASE@\\n' "$status" >/dev/kmsg
[ "$status" -eq 37 ]
[ "$(/bin/stat -c %s /core-stdout)" -eq @CORE_BYTES@ ]
IFS= read -r application_line </core-stdout
[ "$application_line" = 'NATIVE_CORE PASS @CORE_CASE@' ]
printf '<6>NATIVE_CORE_STDOUT bytes=@CORE_BYTES@ line=%s\\n' "$application_line" >/dev/kmsg
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_CORE_REGISTRATIONS_CLEAR case=@CORE_CASE@\\n' >/dev/kmsg
printf '<6>NATIVE_APPLICATION_GUEST PASS application_exit=37\\n' >/dev/kmsg
'''
    else:
        init += "printf 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0\\n'\n"
    init=init.replace('@CORE_CASE@',case).replace('@CORE_BYTES@',str(len(expected_core.encode())))
    (root / 'init').write_text(init)
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    env = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root))
    run('initramfs-spec', ['python3', '-B', '/work/write-native-cpio-spec.py'], env)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as target:
            generator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(generator.stdout, target)
            generator.stdout.close()
            assert generator.wait() == 0
    record['inputs'] += [identity(p) for p in (image, compiled / 'bzImage', root / 'init', out / 'initramfs.cpio.gz', Path('/work/write-native-cpio-spec.py'))]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off', '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args
    record['phase'] = 'guest'
    save()
    print('RUN guest', flush=True)
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20)
        connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            record['application_attempted'] = 'NATIVE_APPLICATION_MCEXEC begin' in serial
            for bad in ('NATIVE_CORE FAIL', 'strncpy_from_user:ioctl:', 'ret: ', 'NATIVE_APPLICATION_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP', 'continuing service error'):
                assert bad not in serial, bad
            ready = serial.count('NATIVE_BOOT_CAPTURE x86_64 ready')
            if ready > seen:
                assert ready == seen + 1 and ready <= 2
                capture(serial, seen)
                seen += 1
            state = qmp('query-status')
            if state['status'] in ('shutdown', 'guest-panicked'):
                record['terminal_vm_state'] = state
                for interface in ('x86_64', 'i386'):
                    assert 'NATIVE_OS_BUILDID ' + interface + ' PASS states=2 guarded=4 faults=10 mcctrl_absent=1' in serial
                for interface in ('x86_64','i386'):
                    assert 'NATIVE_STRING_COPY '+interface+' PASS cases=14 descriptor_faults=4 guarded=1 applications=0' in serial
                record['native_string_copy']=dict(interfaces=2,data_cases=28,descriptor_faults=8,guarded=True,source_and_destination_fields_preserved=True)
                if mode == 'application':
                    assert 'NATIVE_APPLICATION_GUEST PASS application_exit=37' in serial, state
                    console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]
                    windows=re.findall(r'NATIVE_APPLICATION_MCEXEC begin iteration=(\d+)(.*?)NATIVE_APPLICATION_MCEXEC exit=37 iteration=\1\b',console,re.S)
                    assert [int(i) for i,body in windows]==list(range(1,9)),windows
                    launches=[]
                    for iteration,body in windows:
                        assert body.count('NATIVE_APPLICATION_HELLO')==1,body
                        assert 'NATIVE_APPLICATION_STDOUT iteration='+iteration+' bytes=25 line=NATIVE_APPLICATION_HELLO' in body,body
                        schedules=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',body)
                        assert len(schedules)==1,schedules
                        pid=schedules[0]
                        delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',body)
                        returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',body)
                        writes=[row for row in delivered if row[3]=='1'];assert len(writes)==1,delivered
                        assert writes[0][:3]+('25',) in returned,(delivered,returned)
                        assert any(row[3]=='231' for row in delivered),delivered
                        for operation in ('published','deleted'):
                            assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',body),operation
                        assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',body),body
                        assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',body),body
                        launches.append(dict(iteration=int(iteration),pid=int(pid),delivered=delivered,returned=returned,write_bytes=25,stdout_hex=b'NATIVE_APPLICATION_HELLO\n'.hex(),stdout_verification='guest regular file, exact 25 bytes, successful newline read and exact line comparison; copied into ordered printk record',exit_code=37,marked_retirement=True,registration_released=True))
                    routes=re.findall(r'application_syscall=return_route os=0 generation=1 pid=(\d+) worker=(\d+) delivery=(\d+) launcher_cpu=(-?\d+) guest_cpu=(\d+)',console)
                    assert any(row[3]=='1' and row[4]=='0' for row in routes),('distinct launcher/guest CPU case not observed',routes)
                    for pid,worker,delivery,launcher_cpu,guest_cpu in routes:
                        launch=next(row for row in launches if row['pid']==int(pid))
                        assert (worker,delivery,guest_cpu,'25') in launch['returned']
                    record['return_routes']=routes
                    assert len(set(row['pid'] for row in launches))==8
                    assert re.findall(r'NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=(\d+)',console)==list(map(str,range(1,9)))
                    assert 'NATIVE_APPLICATION_REPEAT PASS applications=8 application_exit=37' in console
                    assert 'cleanup retained' not in console and 'reap_retained' not in console
                    record['native_application']=dict(applications=8,launches=launches,same_os_instance=True,no_process_nodes_after_each=True)
                    record['mckernel_application_executed']=True
                    core_body=console.split('NATIVE_CORE_MCEXEC begin case='+case,1)[1].split('NATIVE_CORE_MCEXEC exit=37 case='+case,1)[0]
                    core_pids=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',core_body);assert len(core_pids)==1,core_pids
                    pid=core_pids[0]
                    assert re.search(r'application retirement os=0 generation=1 pid='+pid+r' token=\d+ errno=0\b',core_body),core_body
                    assert re.search(r'application_process=release os=0 generation=1 pid='+pid+r' cleanup_errno=0\b',core_body),core_body
                    for operation in ('published','deleted'):
                        assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+pid+r' tid='+pid+r'\b',core_body),core_body
                    assert 'NATIVE_CORE_STDOUT bytes='+str(len(expected_core.encode()))+' line='+expected_core.rstrip('\n') in console
                    assert 'NATIVE_CORE_REGISTRATIONS_CLEAR case='+case in console
                    record['core_application']=dict(case=case,pid=int(pid),exit_code=37,stdout=expected_core,normal_dynamic_libc=True,marked_retirement=True,registration_released=True,no_process_nodes=True)

                    capture(serial.split('NATIVE_APPLICATION_GUEST PASS', 1)[0], 'application', validate=False, resume=False)
                else:
                    marker = 'NATIVE_BUILDID_GUEST PASS interfaces=2 states=4 faults=20 applications=0'
                    assert marker in serial, state
                    capture(serial.split(marker, 1)[0], 'metadata', validate=True, resume=False)
                qmp('quit')
                process.wait(timeout=15)
                break
            time.sleep(0.1)
        assert process.returncode == 0 and seen == 2
    record.update(status='PASS', phase='complete',
                  buildid=dict(interfaces=2, states=4, guarded=8, faults=20, mcctrl_absent=True))
    if mode == 'application':
        record.update(launcher_reported_exit=37,
                      scope='Real dynamically linked libc application case '+case+' with exact output/exit/retirement, plus both native/compat pathname-copy descriptor ABIs, 28 data cases and eight descriptor faults; eight unchanged launcher ELF hello/exit-37 runs in one OS instance, each with native schedule, delegated write/return, exit, PID/TID publication/deletion, marked retirement and no remaining procfs process nodes; abnormal-owner and core readiness smokes remain pending')
    else:
        record['scope'] = 'Actual OS metadata query over both pointer widths, four live states, twenty copyout faults and eight bounded successful writes; no application execution'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    if stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
