"""Run the unchanged real launcher and ordinary ELF in an isolated native guest."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast, gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
architecture, profile = 'x86_64', 'normal'
compiled = Path('/work/native-mcctrl-image-module-20260908-8')
images = Path('/work/mckernel-native-sysfs-images-20260908-2')
launcher = Path('/work/native-application-launcher-20260908-2')
baseline = Path('/work/native-mcctrl-image-guest-20260908-x86_64-4')
out = Path('/work/native-application-launcher-guest-20260908-' + sys.argv[1])
out.mkdir()
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              architecture=architecture, profile=profile, inputs=[], commands=[], captures=[],
              cpuset=sorted(os.sched_getaffinity(0)), cpus=4, guest_cpus=1, numa_nodes=2,
              memory_mib=8192, container_memory_mib=12288, application_attempted=False,
              mckernel_application_executed=False, production_gate_credit=False)
sequence, stream, process = 0, None, None

# Reuse the exact accepted image-runner's physical capture and boot assertions.
# Extract only these complete function definitions, not its top-level run.
original = (baseline / 'helper.py').read_text()
names = {'identity', 'save', 'qmp', 'dump', 'capture'}
functions = [node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in functions} == names
exec(compile(ast.Module(body=functions, type_ignores=[]), str(baseline / 'helper.py'), 'exec'))

def run(label, command, environment=None):
    record['phase'] = label
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    save()
    assert result.returncode == 0, (label, result.returncode, (out / (label + '.log')).read_text()[-6000:])
    return (out / (label + '.log')).read_text()

try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(baseline / 'helper.py', out / 'capture-reference.py')
    assert shutil.disk_usage('/work').free > 2 * 1024**3
    for directory in (compiled, images, launcher, baseline):
        assert json.loads((directory / 'record.json').read_text())['status'] == 'PASS'
        record['inputs'].append(identity(directory / 'record.json'))
    built = json.loads((compiled / 'record.json').read_text())
    for row in built['outputs']:
        assert identity(Path(row['path'])) == row
    launches = json.loads((launcher / 'record.json').read_text())
    for selection in launches['launchers']:
        for row in selection['outputs']:
            assert identity(Path(row['path'])) == row
    for row in launches['outputs']:
        assert identity(Path(row['path'])) == row
    accepted = json.loads((baseline / 'record.json').read_text())
    boot = baseline / 'root/bin/native-boot'
    # The complete prior capture and compiler command retain this exact binary.
    record['inputs'] += [identity(boot), identity(baseline / 'helper.py')]
    root = out / 'root'
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), root)
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(compiled / name, root / 'modules' / name)
        record['inputs'].append(identity(compiled / name))
    shutil.copy2(boot, root / 'bin/native-boot')
    assert (root / 'bin/native-boot').stat().st_mode & 0o111 == 0o111
    application = launcher / 'native-application-hello'
    binary = launcher / 'rust/executer/user/mcexec'
    shutil.copyfile(binary, root / 'bin/mcexec')
    shutil.copyfile(application, root / 'bin/native-application-hello')
    (root / 'bin/mcexec').chmod(0o755)
    (root / 'bin/native-application-hello').chmod(0o755)
    record['inputs'] += [identity(binary), identity(application)]
    # Use this native Linux userspace's libraries for both the base root and
    # the unchanged older-glibc-compatible launcher. Never mix libc releases.
    dependencies = run('launcher-native-dependencies', ['ldd', str(binary)])
    assert 'not found' not in dependencies
    record['runtime_libraries'] = []
    for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)', dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert identity(target)['sha256'] == identity(original_path)['sha256'], ('library mismatch', name)
        else:
            shutil.copyfile(original_path, target)
        record['runtime_libraries'].append(dict(original=identity(original_path), captured=identity(target)))
    assert len(record['runtime_libraries']) >= 3
    image_record = json.loads((images / 'record.json').read_text())
    selected = next(row for row in image_record['images'] if row['kind'] == 'native-rust')
    image = images / 'native-rust/kernel/mckernel.img'
    assert identity(image) in selected['outputs'] and not selected['native_sysfs_verify']
    (root / 'images').mkdir()
    shutil.copyfile(image, root / 'images/mckernel.img')
    init = '''#!/bin/bash
set -euo pipefail
[ "$$" -eq 1 ] && [ "$EUID" -eq 0 ] || exit 125
export PATH=/bin:/sbin:/usr/bin:/usr/sbin LANG=C LC_ALL=C
exec </dev/console >/dev/console 2>&1
finish() { local status=$?; trap - EXIT; if [ "$status" -ne 0 ]; then printf 'NATIVE_APPLICATION_GUEST FAIL status=%s\\n' "$status"; fi; /bin/dmesg || true; /poweroff; }
trap finish EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t debugfs debugfs /sys/kernel/debug
printf '7\\n' >/proc/sys/kernel/printk
read -r online </sys/devices/system/cpu/online
read -r nodes </sys/devices/system/node/online
[ "$online" = 0-3 ] && [ "$nodes" = 0-1 ]
insmod /modules/ihk.ko
insmod /modules/ihk-smp-x86_64.ko ihk_trampoline=524288
insmod /modules/mcctrl.ko
/bin/native-boot
printf 'NATIVE_APPLICATION_LINUX_REFERENCE begin\\n'
status=0
/bin/native-application-hello || status=$?
printf 'NATIVE_APPLICATION_LINUX_REFERENCE exit=%s\\n' "$status"
[ "$status" -eq 37 ]
printf 'NATIVE_APPLICATION_MCEXEC begin\\n'
status=0
/bin/mcexec -t 1 0 /bin/native-application-hello || status=$?
printf 'NATIVE_APPLICATION_MCEXEC exit=%s\\n' "$status"
[ "$status" -eq 37 ]
printf 'NATIVE_APPLICATION_GUEST PASS application_exit=37\\n'
'''
    (root / 'init').write_text(init)
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    env = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root))
    run('initramfs-spec', ['python3', '-B', '/work/write-native-cpio-spec.py'], env)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as target:
            generator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(generator.stdout, target)
            generator.stdout.close()
            assert generator.wait() == 0
    record['inputs'] += [identity(p) for p in (image, compiled / 'bzImage', root / 'init', out / 'initramfs.cpio.gz', Path('/work/write-native-cpio-spec.py'))]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off', '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args
    record['phase'] = 'guest'
    save()
    print('RUN guest', flush=True)
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 180
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20)
        connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            record['application_attempted'] = 'NATIVE_APPLICATION_MCEXEC begin' in serial
            for bad in ('NATIVE_APPLICATION_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP', 'continuing service error'):
                assert bad not in serial, bad
            ready = serial.count('NATIVE_BOOT_CAPTURE x86_64 ready')
            if ready > seen:
                assert ready == seen + 1 and ready <= 2
                capture(serial, seen)
                seen += 1
            state = qmp('query-status')
            if state['status'] in ('shutdown', 'guest-panicked'):
                record['terminal_vm_state'] = state
                assert 'NATIVE_APPLICATION_GUEST PASS application_exit=37' in serial, state
                segment = serial.split('NATIVE_APPLICATION_MCEXEC begin', 1)[1].split('NATIVE_APPLICATION_MCEXEC exit=', 1)[0]
                assert segment.count('NATIVE_APPLICATION_HELLO') == 1, segment
                # Successful output must have come through the actual guest
                # process, with its schedule and syscall evidence verified next.
                capture(serial.split('NATIVE_APPLICATION_GUEST PASS', 1)[0], 'application', validate=False, resume=False)
                qmp('quit')
                process.wait(timeout=15)
                break
            time.sleep(0.1)
        assert process.returncode == 0 and seen == 2
    record.update(status='PASS', phase='complete', launcher_reported_exit=37,
                  scope='Real ELF launcher run; scheduling/syscall physical attribution remains separately required')
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    if stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
