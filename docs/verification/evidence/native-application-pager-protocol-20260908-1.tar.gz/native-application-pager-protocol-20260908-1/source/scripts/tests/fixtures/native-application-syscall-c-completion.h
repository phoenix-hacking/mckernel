static int __notify_syscall_requester(ihk_os_t os, struct ikc_scd_packet *packet,
		struct syscall_response *res)
{
	struct mcctrl_usrdata *usrdata = ihk_host_os_get_usrdata(os);
	struct ihk_ikc_channel_desc *c;
	struct ikc_scd_packet r_packet;
	int ret = 0;

	if (!usrdata) {
		pr_err("%s: error: mcctrl_usrdata not found\n",
			 __func__);
		return -EINVAL;
	}

	c = (usrdata->channels + packet->ref)->c;

	/* If spinning, no need for IKC message */
	if (cmpxchg(&res->req_thread_status,
				IHK_SCD_REQ_THREAD_SPINNING,
				IHK_SCD_REQ_THREAD_TO_BE_WOKEN) ==
			IHK_SCD_REQ_THREAD_SPINNING) {
		dprintk("%s: no need to send IKC message for PID %d\n",
				__FUNCTION__, packet->pid);
		return ret;
	}

	/* Wait until the status goes back to IHK_SCD_REQ_THREAD_SPINNING or
	   IHK_SCD_REQ_THREAD_DESCHEDULED because two wake-up attempts are competing.
	   Note that mcexec_terminate_thread() and returning EINTR would compete. */
	if (smp_load_acquire(&res->req_thread_status) == IHK_SCD_REQ_THREAD_TO_BE_WOKEN) {
		printk("%s: INFO: someone else is waking up the McKernel thread, "
				"pid: %d, req status: %lu, syscall nr: %lu\n",
				__FUNCTION__, packet->pid,
				res->req_thread_status, packet->req.number);
	}

	/* The thread is not spinning any more, make sure it's descheduled */
	if (cmpxchg(&res->req_thread_status,
				IHK_SCD_REQ_THREAD_DESCHEDULED,
				IHK_SCD_REQ_THREAD_TO_BE_WOKEN) !=
			IHK_SCD_REQ_THREAD_DESCHEDULED) {
		printk("%s: WARNING: inconsistent requester status, "
				"pid: %d, req status: %lu, syscall nr: %lu\n",
				__FUNCTION__, packet->pid,
				res->req_thread_status, packet->req.number);
		dump_stack();

		return -EINVAL;
	}

	r_packet.msg = SCD_MSG_WAKE_UP_SYSCALL_THREAD;
	r_packet.ttid = packet->req.rtid;
	ret = ihk_ikc_send(c, &r_packet, 0);

	return ret;
}
void __return_syscall(ihk_os_t os, struct mcctrl_per_proc_data *ppd,
		struct ikc_scd_packet *packet,
		long ret, int stid)
{
	unsigned long phys;
	struct syscall_response *res;

	if (!os || ihk_host_validate_os(os) || !packet) {
		return;
	}

	phys = ihk_device_map_memory(ihk_os_to_dev(os),
			packet->resp_pa, sizeof(*res));
	if (!phys) {
		return;
	}

	res = ihk_device_map_virtual(ihk_os_to_dev(os),
			phys, sizeof(*res), NULL, 0);

	if (!res) {
		printk("%s: ERROR: invalid response structure address\n",
			__FUNCTION__);
		ihk_device_unmap_memory(ihk_os_to_dev(os), phys, sizeof(*res));
		return;
	}

	/* Map response structure and notify offloading thread */
	res->ret = ret;
	res->stid = stid;

#ifdef ENABLE_TOFU
	/* Tofu enabled process? */
	if (ppd && ppd->enable_tofu) {
		char *pathbuf, *fullpath;

		/* Record PDE_DATA after open() calls for Tofu driver */
		if (packet->req.number == __NR_openat && ret > 1) {
			struct fd f;
			int fd;

			fd = ret;
			f = fdget(fd);

			if (!f.file) {
				goto out_notify;
			}

			pathbuf = (char *)__get_free_page(GFP_ATOMIC);
			if (!pathbuf) {
				goto out_fdput_open;
			}

			fullpath = d_path(&f.file->f_path, pathbuf, PAGE_SIZE);
			if (IS_ERR(fullpath)) {
				goto out_free_open;
			}

			if (mcctrl_tofu_dev_path(fullpath)) {
				res->pde_data = PDE_DATA(file_inode(f.file));
				dprintk("%s: fd: %d, path: %s, PDE_DATA: 0x%lx\n",
						__func__,
						fd,
						fullpath,
						(unsigned long)res->pde_data);
				dprintk("%s: pgd_index: %ld, pmd_index: %ld, pte_index: %ld\n",
						__func__,
						pgd_index((unsigned long)res->pde_data),
						pmd_index((unsigned long)res->pde_data),
						pte_index((unsigned long)res->pde_data));
				dprintk("MAX_USER_VA_BITS: %d, PGDIR_SHIFT: %d\n",
						MAX_USER_VA_BITS, PGDIR_SHIFT);
				mcctrl_file_to_pidfd_hash_insert(f.file, os,
						task_tgid_vnr(current),
						current->group_leader, fd,
						fullpath, res->pde_data);
			}

out_free_open:
			free_page((unsigned long)pathbuf);
out_fdput_open:
			fdput(f);
		}

		/* Ioctl on Tofu CQ? */
		else if (packet->req.number == __NR_ioctl &&
				packet->req.args[0] > 0 && ret == 0) {
			struct fd f;
			int fd;
			int tni, cq;
			long __ret;

			fd = packet->req.args[0];
			f = fdget(fd);

			if (!f.file) {
				goto out_notify;
			}

			pathbuf = (char *)__get_free_page(GFP_ATOMIC);
			if (!pathbuf) {
				goto out_fdput_ioctl;
			}

			fullpath = d_path(&f.file->f_path, pathbuf, PAGE_SIZE);
			if (IS_ERR(fullpath)) {
				goto out_free_ioctl;
			}

			/* Looking for /proc/tofu/dev/tniXcqY pattern */
			__ret = mcctrl_tofu_cq_path_parse(fullpath, &tni, &cq);
			if (__ret) {
				extern long __mcctrl_tof_utofu_unlocked_ioctl_cq(void *pde_data,
						unsigned int cmd, unsigned long arg);

				dprintk("%s: ioctl(): fd: %d, path: %s\n",
						__func__,
						fd,
						fullpath);

				__ret = __mcctrl_tof_utofu_unlocked_ioctl_cq(
						PDE_DATA(file_inode(f.file)),
						packet->req.args[1], packet->req.args[2]);
			}

out_free_ioctl:
			free_page((unsigned long)pathbuf);
out_fdput_ioctl:
			fdput(f);
		}
	}

out_notify:
#endif
	if (__notify_syscall_requester(os, packet, res) < 0) {
		printk("%s: WARNING: failed to notify PID %d\n",
			__FUNCTION__, packet->pid);
	}

	mb();
	res->status = 1;

	ihk_device_unmap_virtual(ihk_os_to_dev(os), res, sizeof(*res));
	ihk_device_unmap_memory(ihk_os_to_dev(os), phys, sizeof(*res));
}
