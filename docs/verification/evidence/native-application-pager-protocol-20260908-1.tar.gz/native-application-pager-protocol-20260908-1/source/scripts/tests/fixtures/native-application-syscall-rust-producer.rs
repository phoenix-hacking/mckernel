use crate::abi::*;
use core::{mem::size_of,ptr::{write,copy_nonoverlapping,addr_of_mut},sync::atomic::{AtomicU64,Ordering}};
const EINVAL: CInt = 22;
pub extern "C" fn syscall_use_requester_tid_result(
    syscall_nr: CInt,
    arg0: CULong,
    sched_setaffinity_nr: CInt,
) -> CInt {
    (syscall_nr == sched_setaffinity_nr && arg0 == 0) as CInt
}
pub extern "C" fn syscall_target_tid_result(use_requester_tid: CInt, current_tid: CInt) -> CInt {
    if use_requester_tid != 0 {
        current_tid
    } else {
        0
    }
}
pub unsafe extern "C" fn syscall_offload_prepare_result(
    request: *mut SyscallRequest,
    response: *mut SyscallResponse,
    current_tid: CInt,
    syscall_nr: CInt,
    arg0: CULong,
    sched_setaffinity_nr: CInt,
    spinning_status: CULong,
) -> CInt {
    if request.is_null() || response.is_null() {
        return -EINVAL;
    }

    let use_requester_tid =
        syscall_use_requester_tid_result(syscall_nr, arg0, sched_setaffinity_nr);
    let target_tid = syscall_target_tid_result(use_requester_tid, current_tid);

    write(core::ptr::addr_of_mut!((*request).rtid), current_tid);
    write(core::ptr::addr_of_mut!((*request).ttid), target_tid);
    write(
        core::ptr::addr_of_mut!((*response).req_thread_status),
        spinning_status,
    );
    write(
        core::ptr::addr_of_mut!((*response).pde_data),
        core::ptr::null_mut(),
    );

    use_requester_tid
}
pub unsafe extern "C" fn syscall_send_prepare_result(
    request: *mut SyscallRequest,
    response: *mut SyscallResponse,
) -> CInt {
    if request.is_null() || response.is_null() {
        return -EINVAL;
    }

    write(core::ptr::addr_of_mut!((*response).status), 0);
    write(core::ptr::addr_of_mut!((*request).valid), 0);

    0
}
pub unsafe extern "C" fn syscall_request_copy_result(
    dst: *mut SyscallRequest,
    src: *const SyscallRequest,
) -> CInt {
    if dst.is_null() || src.is_null() {
        return -EINVAL;
    }

    // The Linux proxy protocol historically copies this wire object with
    // memcpy.  In particular, a nested request can begin at an address that
    // is not aligned for `SyscallRequest`; keeping the operation byte-typed
    // preserves those semantics without creating an unaligned Rust reference.
    copy_nonoverlapping(
        src.cast::<u8>(),
        dst.cast::<u8>(),
        size_of::<SyscallRequest>(),
    );

    0
}
pub unsafe extern "C" fn syscall_request_publish_result(request: *mut SyscallRequest) -> CInt {
    if request.is_null() {
        return -EINVAL;
    }

    AtomicU64::from_ptr(addr_of_mut!((*request).valid)).store(1, Ordering::Release);
    0
}
pub unsafe extern "C" fn syscall_packet_traditional_prepare_result(
    packet: *mut IkcScdPacket,
    msg: CInt,
    cpu_ref: CInt,
    pid: CInt,
    resp_pa: CULong,
) -> CInt {
    if packet.is_null() {
        return -EINVAL;
    }

    write(core::ptr::addr_of_mut!((*packet).msg), msg);
    let traditional = core::ptr::addr_of_mut!((*packet).body).cast::<IkcScdPacketTraditional>();
    write(core::ptr::addr_of_mut!((*traditional).ref_), cpu_ref);
    write(core::ptr::addr_of_mut!((*traditional).pid), pid);
    write(core::ptr::addr_of_mut!((*traditional).resp_pa), resp_pa);

    0
}
