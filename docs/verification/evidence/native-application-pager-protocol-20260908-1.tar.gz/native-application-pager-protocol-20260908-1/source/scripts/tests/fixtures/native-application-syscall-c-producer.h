SYSCALL_POLICY_HELPER_SCOPE int
syscall_use_requester_tid_result(int syscall_nr, unsigned long arg0,
		int sched_setaffinity_nr)
{
	return syscall_nr == sched_setaffinity_nr && arg0 == 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_target_tid_result(int use_requester_tid, int current_tid)
{
	return use_requester_tid ? current_tid : 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_offload_prepare_result(struct syscall_request *req,
		struct syscall_response *res, int current_tid, int syscall_nr,
		unsigned long arg0, int sched_setaffinity_nr,
		unsigned long spinning_status)
{
	int use_requester_tid;

	if (!req || !res)
		return -EINVAL;

	use_requester_tid = syscall_use_requester_tid_result(syscall_nr, arg0,
			sched_setaffinity_nr);
	req->rtid = current_tid;
	req->ttid = syscall_target_tid_result(use_requester_tid, current_tid);
	res->req_thread_status = spinning_status;
	res->pde_data = NULL;

	return use_requester_tid;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_send_prepare_result(struct syscall_request *req,
		struct syscall_response *res)
{
	if (!req || !res)
		return -EINVAL;

	res->status = 0;
	req->valid = 0;

	return 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_request_copy_result(struct syscall_request *dst,
		const struct syscall_request *src)
{
	if (!dst || !src)
		return -EINVAL;

	memcpy(dst, src, sizeof(*dst));

	return 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_request_publish_result(struct syscall_request *req)
{
	if (!req)
		return -EINVAL;

	__atomic_store_n(&req->valid, 1, __ATOMIC_RELEASE);

	return 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
syscall_packet_traditional_prepare_result(struct ikc_scd_packet *packet,
		int msg, int cpu_ref, int pid, unsigned long resp_pa)
{
	if (!packet)
		return -EINVAL;

	packet->msg = msg;
	packet->ref = cpu_ref;
	packet->pid = pid;
	packet->resp_pa = resp_pa;

	return 0;
}
