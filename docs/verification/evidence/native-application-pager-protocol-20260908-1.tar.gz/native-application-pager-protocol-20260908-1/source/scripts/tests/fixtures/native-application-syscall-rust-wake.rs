use crate::abi::*;
use core::ffi::c_void;
const EINVAL: CInt = 22;
pub type HostFindThreadFn = Option<unsafe extern "C" fn(pid: CInt, tid: CInt) -> *mut c_void>;
pub type HostWakeupThreadFn = Option<unsafe extern "C" fn(thread: *mut c_void)>;
pub type HostThreadUnlockFn = Option<unsafe extern "C" fn(thread: *mut c_void)>;
pub type HostWakeSyscallLogFn = Option<unsafe extern "C" fn(tid: CInt, found: CInt)>;
pub unsafe extern "C" fn host_find_thread_result(
    pid: CInt,
    tid: CInt,
    find_thread_fn: HostFindThreadFn,
) -> *mut c_void {
    let find_thread = match find_thread_fn {
        Some(find_thread) => find_thread,
        None => return core::ptr::null_mut(),
    };

    find_thread(pid, tid)
}
pub unsafe extern "C" fn host_wakeup_thread_result(
    thread: *mut c_void,
    wakeup_fn: HostWakeupThreadFn,
) -> CInt {
    let wakeup = match wakeup_fn {
        Some(wakeup) => wakeup,
        None => return -EINVAL,
    };

    wakeup(thread);
    0
}
pub unsafe extern "C" fn host_thread_unlock_result(
    thread: *mut c_void,
    unlock_fn: HostThreadUnlockFn,
) -> CInt {
    let unlock = match unlock_fn {
        Some(unlock) => unlock,
        None => return -EINVAL,
    };

    unlock(thread);
    0
}
pub unsafe extern "C" fn host_wake_syscall_log_result(
    tid: CInt,
    found: CInt,
    log_fn: HostWakeSyscallLogFn,
) -> CInt {
    let log = match log_fn {
        Some(log) => log,
        None => return -EINVAL,
    };

    log(tid, found);
    0
}
pub unsafe extern "C" fn host_wake_syscall_thread_request_result(
    request: *mut IkcScdPacket,
    find_thread_fn: HostFindThreadFn,
    wakeup_fn: HostWakeupThreadFn,
    unlock_fn: HostThreadUnlockFn,
    log_fn: HostWakeSyscallLogFn,
) -> CInt {
    if request.is_null() || find_thread_fn.is_none() || wakeup_fn.is_none() || unlock_fn.is_none() {
        return -EINVAL;
    }

    let tid = (*request).body.ttid;
    let thread = host_find_thread_result(0, tid, find_thread_fn);
    if thread.is_null() {
        if log_fn.is_some() {
            let _ = host_wake_syscall_log_result(tid, 0, log_fn);
        }
        return -EINVAL;
    }

    if log_fn.is_some() {
        let _ = host_wake_syscall_log_result(tid, 1, log_fn);
    }
    let _ = host_wakeup_thread_result(thread, wakeup_fn);
    let _ = host_thread_unlock_result(thread, unlock_fn);
    0
}
