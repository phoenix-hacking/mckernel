"""Retain exact callback build/guest evidence, failures and formatting replays."""
from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-sysfs-remote-retained-20260907-'+sys.argv[1]);out.mkdir()
manifest=out/'native-sysfs-remote-checkpoint-20260907.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),artifacts=[],compiler_inputs=[],references=[],commands=[],
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    production_gate_credit=False,mckernel_boot_proven=False,sysfs_service_completed=False,applications_tested=False)

def identity(path):
    data=path.read_bytes();return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())

def verify(row):
    assert identity(Path(row['path']))==row,row

def artifact(source,name,tree=False):
    path=out/name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            if tree:
                with tarfile.open(fileobj=compressed,mode='w') as archive:archive.add(source,arcname=source.name)
            else:
                with source.open('rb') as stream:shutil.copyfileobj(stream,compressed)
    with gzip.open(path,'rb') as stream:
        while stream.read(1<<20):pass
    row=identity(path);row['path']='docs/verification/evidence/'+path.name;row['source']=str(source)
    record['artifacts'].append(row)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-sysfs-request-protocol-20260907.json','native-sysfs-setup-checkpoint-20260907.json','native-topology-checkpoint-20260907.json']:
        path=repo/'docs/verification'/name;ref=identity(path);ref['path']=str(path.relative_to(repo));record['references'].append(ref)
        saved=json.loads(path.read_text());assert saved['status']=='PASS'
        for row in saved['artifacts']:
            path=repo/row['path'];actual=identity(path)
            assert actual['sha256']==row['sha256'] and actual['size']==row['size'],row
            with gzip.open(path,'rb') as stream:
                while stream.read(1<<20):pass
    captures=['native-sysfs-remote-module-20260907-'+str(n) for n in range(1,5)]+['native-sysfs-remote-guest-20260907-1']
    record['captures']=[]
    for name in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        expected='FAIL' if name in captures[:3] else 'PASS';assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('compiler_inputs',[])+state.get('outputs',[]):verify(row)
        artifact(capture,name+'.tar.gz',True);artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status=expected))
    compiled=work/'native-sysfs-remote-module-20260907-4'
    state=json.loads((compiled/'record.json').read_text())
    originals=compiled/'original-inputs';staged=compiled/'staged-source'
    replay=out/'format-replay';replay.mkdir()
    for original in sorted(originals.rglob('*')):
        if not original.is_file():continue
        relative=original.relative_to(originals)
        if relative.name in ['mckernel_sysfs_remote_verify.rs','native-sysfs-remote.c']:
            compiler=compiled/'fixture/source/scripts/tests/fixtures'/relative
            current=repo/'scripts/tests/fixtures'/relative
        else:
            compiler=staged/relative;current=repo/'host-kernel/native-rust'/relative
        source_bytes=current.read_bytes();compiler_bytes=compiler.read_bytes()
        row=dict(path=str(current.relative_to(repo)),source_size=len(source_bytes),source_sha256=hashlib.sha256(source_bytes).hexdigest(),
            compiler_capture=str(compiler),original_capture=str(original),size=len(compiler_bytes),sha256=hashlib.sha256(compiler_bytes).hexdigest())
        if source_bytes==compiler_bytes:row['binding']='identical'
        else:
            assert source_bytes==original.read_bytes() and current.suffix=='.rs',str(current)
            candidate=replay/relative;candidate.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(current,candidate)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(candidate)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            record['commands'].append(dict(command=command,exit_code=result.returncode,output=result.stdout.decode()))
            assert result.returncode==0 and candidate.read_bytes()==compiler_bytes,str(current)
            row['binding']='exact pinned rustfmt replay';row['replay']=str(candidate)
        record['compiler_inputs'].append(row)
    artifact(replay,'native-sysfs-remote-format-replay-20260907.tar.gz',True)
    for name in ['build-native-sysfs-remote.py','build-native-sysfs-remote-v2.py','run-native-sysfs-remote-guest.py','native-sysfs-remote-guest-init.sh']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-sysfs-remote.py.gz')
    guest=json.loads((work/captures[-1]/'record.json').read_text())
    for key in ['module_cycles','parallel_roundtrips','completed_exchanges','forced_queue_full_retries','interrupted_readers',
        'late_response_ownership_checks','concurrent_callback_drains','remote_release_drains','boundary_checks','error_checks','namespace_removed']:
        record[key]=guest[key]
    record.update(status='PASS',native_modules_built=3,fixture_built=True,no_simd=True,
        scope='Real Linux native remote sysfs callbacks, shared-buffer exchange and tree drain with an independent module-owned peer',
        limitations=[
            'The Linux fixture uses its own page and a fixture-only diagnostic identity in place of the setup mapping carrier. It proves no IHK generation or actual guest extent ownership.',
            'Continuing packet dispatch, exclusive/overlap metadata claims and special snooping are not integrated. Actual McKernel startup still stops at CREATE with architectural status 2.',
            'Actual full-ready status, application execution, native shutdown, current full-suite/declared integration and full Rust/assembly/production acceptance remain open.',
            'The initial allocator conversion, fixture visibility and CondVar symbol assertions remain failed evidence. Only module attempt 4 and guest attempt 1 are accepted here.'
        ])
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
