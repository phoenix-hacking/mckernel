#!/usr/bin/env python3
"""Durable owner for the single native Linux collector rebuild.

This is infrastructure-only.  It deliberately has no catalog, guest, or
application-success path.  The inherited lock descriptor belongs to the
watchdog until cleanup and disarm have both been verified.
"""
import argparse, fcntl, hashlib, importlib.util, json, os, re, select, signal, subprocess, sys, time
from pathlib import Path

REPO = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work')
LOCK = Path('/run/lock/mckernel-development.lock')
DOCKER = '/usr/bin/docker'
PYTHON = '/usr/bin/python3'
IMAGE = 'sha256:46d47ba9223a03f4c99db99758b741b2b58694a44cc083e13d4a7e7c78edfd94'
HELPER = REPO / 'docs/verification/evidence/stability-linux-collector-rebuild-20260915.py'
HELPER_SHA = '6ae0e29dbebf2593f91b4cfa19a5252a157241b83715b2243826cf528efca0e2'
REVIEWED_ORCHESTRATOR = REPO / 'scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/root_orchestrator.py'
REVIEWED_ORCHESTRATOR_SHA = '6e6311ac7059eb97f1cba2eb9606bdc7e82016e381cb47a732ca5b274c216ab3'
REVIEWED_SUPERVISOR_SHA = 'cba4b4d50d68f9afd5aa8a4c2d830ec0b800f7fd7dfd07774911d5fd1b99c7e7'
CID = re.compile(r'^[0-9a-f]{64}$')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(65536), b''): h.update(b)
    return h.hexdigest()

def reviewed_owner():
    assert digest(REVIEWED_ORCHESTRATOR) == REVIEWED_ORCHESTRATOR_SHA
    spec = importlib.util.spec_from_file_location('reviewed_root_orchestrator', REVIEWED_ORCHESTRATOR)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    assert digest(mod.FIXTURES / 'supervisor_host38.py') == REVIEWED_SUPERVISOR_SHA
    return mod

def save(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try: os.write(fd, data); os.fsync(fd)
    finally: os.close(fd)

def save_bytes(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        view = memoryview(data)
        while view:
            n = os.write(fd, view); assert n > 0; view = view[n:]
        os.fsync(fd)
    finally: os.close(fd)

def profile(name, nonce, output):
    return [DOCKER, 'create', '--pull=never', '--init', '--name', name,
            '--label', 'mckernel.collector.build-owner=' + nonce,
            '--cpus=4', '--cpuset-cpus=2-5', '--cgroup-parent=/mckernel-dev',
            '--memory=12g', '--memory-swap=12g', '--pids-limit=512',
            '--cap-drop=ALL', '--security-opt=no-new-privileges', '--read-only',
            '--network=none', '--user=1000:1000',
            '--ulimit', 'core=0', '--ulimit', 'nofile=4096:4096',
            '--tmpfs', '/tmp:rw,nodev,nosuid,size=256m',
            '--mount', 'type=bind,src=' + str(REPO) + ',dst=/workspace,readonly',
            '--mount', 'type=bind,src=' + str(output) + ',dst=/work',
            '--env', 'TMPDIR=/work/tmp', '--env', 'HOME=/tmp',
            '--env', 'PYTHONDONTWRITEBYTECODE=1', '--workdir=/work',
            '--entrypoint=/usr/bin/python3', IMAGE, '-B',
            '/workspace/docs/verification/evidence/stability-linux-collector-rebuild-20260915.py']

def docker(argv, timeout=30):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=timeout, check=False)

def owned(nonce, name, cid=None):
    rows = []
    for flt in ('label=mckernel.collector.build-owner=' + nonce, 'name=^/' + name + '$'):
        p = docker([DOCKER, 'container', 'ls', '--all', '--no-trunc', '--filter', flt, '--format', '{{.ID}}'])
        if p.returncode: raise RuntimeError('lookup failed: ' + p.stderr.decode(errors='replace'))
        rows.append(p.stdout.decode().splitlines())
    if rows[0] != rows[1] or len(rows[0]) > 1: raise RuntimeError('ambiguous owner lookup')
    if not rows[0]: return None
    found = rows[0][0]
    if not CID.fullmatch(found) or (cid is not None and found != cid): raise RuntimeError('container identity drift')
    row = json.loads(docker([DOCKER, 'inspect', found]).stdout)[0]
    labels = row.get('Config', {}).get('Labels', {})
    if row.get('Id') != found or row.get('Name') != '/' + name or row.get('Image') != IMAGE or labels.get('mckernel.collector.build-owner') != nonce:
        raise RuntimeError('container ownership mismatch')
    return row

def cleanup(nonce, name, cid, host, *, max_passes=8):
    errors = []; attempts = []
    n = 0
    while max_passes is None or n < max_passes:
        n += 1
        try:
            row = owned(nonce, name, cid)
            if row is not None:
                # A failed create may still have committed a container.  Bind
                # the discovered full ID before any stop/remove operation.
                if cid is None: cid = row['Id']
                if row.get('State', {}).get('Running') or row.get('State', {}).get('Paused'):
                    p = docker([DOCKER, 'stop', '--time=20', cid], 30)
                    if p.returncode: raise RuntimeError('stop exit ' + str(p.returncode))
                row = owned(nonce, name, cid)
                if row is not None:
                    p = docker([DOCKER, 'rm', '--force', cid], 30)
                    if p.returncode: raise RuntimeError('remove exit ' + str(p.returncode))
            absent = owned(nonce, name, cid) is None
            attempts.append({'number': n, 'absence_verified': absent})
            if absent:
                result = {'absence_verified': True, 'attempts': attempts, 'errors': errors,
                          'evidence_complete': not errors, 'application_acceptance': False}
                save(host / ('cleanup-%d-%d.json' % (os.getpid(), os.getppid())), result); return result
        except BaseException as e:
            errors.append(str(e)); attempts.append({'number': n, 'absence_verified': False, 'error': str(e)})
        time.sleep(1)
    result = {'absence_verified': False, 'attempts': attempts, 'errors': errors,
              'evidence_complete': False, 'application_acceptance': False}
    save(host / ('cleanup-%d-%d.json' % (os.getpid(), os.getppid())), result); return result

def watchdog(config_path, pipe_fd, lock_fd):
    cfg = json.loads(Path(config_path).read_text()); host = Path(cfg['host'])
    try:
        data = b''; expected = None
        deadline = time.monotonic() + 900
        while time.monotonic() < deadline:
            if expected is None:
                latest = json.loads(Path(config_path).read_text())
                if CID.fullmatch(str(latest.get('container_id', ''))):
                    cfg = latest; expected = cfg['disarm'].encode()
            ready, _, _ = select.select([pipe_fd], [], [], 0.25)
            if not ready: continue
            b = os.read(pipe_fd, 256)
            if not b: break
            data += b
            if expected is None or len(data) > len(expected) or not expected.startswith(data): raise RuntimeError('malformed disarm')
            if data == expected:
                if owned(cfg['nonce'], cfg['name'], cfg['container_id']) is not None: raise RuntimeError('disarm before absence')
                save(host / 'watchdog-result.json', {'status':'DISARMED_AFTER_VERIFIED_ABSENCE','raw_wait_status':0})
                os.close(lock_fd); return 0
        result = cleanup(cfg['nonce'], cfg['name'], cfg['container_id'], host, max_passes=None)
        save(host / 'watchdog-result.json', {'status':'WATCHDOG_TRIGGERED','cleanup':result})
        if result['absence_verified']: os.close(lock_fd)
        return 1
    except BaseException as e:
        try: save(host / 'watchdog-error.json', {'error':str(e)})
        except BaseException: pass
        return 1

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--attempt-number', type=int, required=True); ap.add_argument('--owner-sha256', required=True)
    a = ap.parse_args(); assert os.getuid() == 0 and 1 <= a.attempt_number <= 999999
    assert digest(Path(__file__).resolve()) == a.owner_sha256 and HELPER.is_file() and digest(HELPER) == HELPER_SHA
    reviewed = reviewed_owner()
    host = WORK / ('scratch/stability-linux-collector-build-owner-20260915-%d' % a.attempt_number)
    mount = WORK / ('scratch/stability-linux-collector-build-mount-20260915-%d' % a.attempt_number)
    assert not host.exists() and not mount.exists(); host.mkdir(mode=0o700); mount.mkdir(mode=0o777); (mount / 'tmp').mkdir(mode=0o777)
    nonce = '%032x' % int.from_bytes(os.urandom(16), 'big'); name = 'mckernel-collector-build-' + nonce
    lock_fd = os.open(LOCK, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    st = os.fstat(lock_fd); assert st.st_uid == 0 and st.st_nlink == 1 and os.stat(LOCK).st_ino == st.st_ino
    fcntl.flock(lock_fd, fcntl.LOCK_EX)
    cfg = {'host':str(host), 'nonce':nonce, 'name':name, 'image':IMAGE, 'container_id':None,
           'disarm':'DISARM ' + nonce + '\n'}; save(host / 'owner-config.json', cfg)
    result = {'status':'FAIL', 'application_acceptance':False, 'transport_acceptance':False, 'watchdog_raw_wait_status':None, 'first_failure':None}
    def failed(sig, _frame):
        if result['first_failure'] is None: result['first_failure'] = {'signal': sig, 'monotonic': time.monotonic()}
        raise KeyboardInterrupt('signal ' + str(sig))
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP): signal.signal(sig, failed)
    rpipe, wpipe = os.pipe(); watch = subprocess.Popen([PYTHON, '-B', str(Path(__file__).resolve()), '--watchdog', str(host/'owner-config.json'), str(rpipe), str(lock_fd)], pass_fds=(rpipe,lock_fd), start_new_session=True)
    os.close(rpipe)
    try:
        image_probe = docker([DOCKER, 'image', 'inspect', IMAGE], 30)
        assert image_probe.returncode == 0 and IMAGE in image_probe.stdout.decode()
        scratch_probe = subprocess.run(['/usr/bin/findmnt', '-n', '-o', 'LABEL', '--target', str(WORK / 'scratch')], capture_output=True, text=True, check=False)
        assert scratch_probe.returncode == 0 and scratch_probe.stdout.strip() == 'mckernel-scratch'
        created = docker(profile(name, nonce, mount), 30); cid = created.stdout.decode().strip(); assert CID.fullmatch(cid); cfg['container_id'] = cid
        cfg['disarm'] = 'DISARM ' + nonce + ' ' + cid + '\n'
        tmp = host / 'owner-config.json.tmp'; tmp.write_text(json.dumps(cfg, sort_keys=True)+'\n')
        with tmp.open('rb') as f: os.fsync(f.fileno())
        os.replace(tmp, host / 'owner-config.json')
        run = docker([DOCKER, 'start', '--attach', cid], 900)
        save_bytes(host / 'rebuild-stdout.bin', run.stdout); save_bytes(host / 'rebuild-stderr.bin', run.stderr)
        result.update({'start_returncode':run.returncode, 'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(), 'stderr_sha256':hashlib.sha256(run.stderr).hexdigest()})
        record = mount / 'stability-linux-collector-build-20260915-2' / 'record.json'
        result['build_record'] = str(record)
        result['build_record_sha256'] = digest(record)
        record_data = json.loads(record.read_text())
        assert record_data.get('status') == 'PASS_LINUX_COLLECTOR_REBUILD_SHA9_BUILDER_NEGATIVE_ONLY' and record_data.get('application_acceptance') is False
        assert run.returncode == 0
    except BaseException as error:
        if result['first_failure'] is None: result['first_failure'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        cleanup_result = cleanup(nonce, name, cfg.get('container_id'), host) if cfg.get('container_id') else {'absence_verified':True}
        result['cleanup'] = cleanup_result
        if cleanup_result.get('absence_verified') and cleanup_result.get('evidence_complete') and cfg.get('container_id'):
            os.write(wpipe, cfg['disarm'].encode())
        os.close(wpipe)
        result['watchdog_raw_wait_status'] = watch.wait()
        passed = (result.get('start_returncode') == 0 and result.get('build_record_sha256') and
                  cleanup_result.get('absence_verified') is True and cleanup_result.get('evidence_complete') is True and
                  result.get('watchdog_raw_wait_status') == 0 and result.get('first_failure') is None)
        result['status'] = 'PASS_LINUX_COLLECTOR_BUILD_OWNER_INFRASTRUCTURE_ONLY' if passed else 'FAIL'
        save(host / 'result.json', result)
        if cleanup_result.get('absence_verified') and result['watchdog_raw_wait_status'] == 0: os.close(lock_fd)
    return 0 if passed else 1

if __name__ == '__main__':
    if len(sys.argv) == 5 and sys.argv[1] == '--watchdog':
        # The reviewed root watchdog owns the inherited lock and performs
        # bounded Commands/recover_cleanup recovery after parent death.
        raise SystemExit(reviewed_owner().watchdog(Path(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])))
    raise SystemExit(main())
