const EINVAL: CInt = 22;
const ENOMEM: CInt = 12;
const EACCES: CInt = 13;
const PAGE_SIZE: CULong = 1 << 12;
const PAGE_MASK: CULong = !(PAGE_SIZE - 1);
const VR_PROT_WRITE: CULong = 0x00020000;
const VR_PROT_MASK: CULong = 0x00070000;
const VR_MAXPROT_MASK: CULong = 0x00700000;
const VR_REMOTE: CULong = 0x200;
const VR_RESERVED: CULong = 0x2;
const VR_IO_NOCACHE: CULong = 0x100;
const PROT_READ: CInt = 0x01;
const PROT_WRITE: CInt = 0x02;
const PROT_EXEC: CInt = 0x04;
const MPROTECT_LOG_ENTER: CInt = 1;
const MPROTECT_LOG_INVALID_RANGE: CInt = 2;
const MPROTECT_LOG_STRAIGHT_IGNORED: CInt = 3;
const MPROTECT_LOG_NOT_CONTIG: CInt = 4;
const MPROTECT_LOG_DENIED: CInt = 5;
const MPROTECT_LOG_CANNOT_CHANGE: CInt = 6;
const MPROTECT_LOG_SPLIT_FAILED: CInt = 7;
const MPROTECT_LOG_CHANGE_FAILED: CInt = 8;
const MPROTECT_LOG_JOIN_FAILED: CInt = 9;
const MPROTECT_LOG_SET_HOST_FAILED: CInt = 10;
const MPROTECT_LOG_EXIT: CInt = 11;
type SyscallDoSyscall3Fn = unsafe extern "C" fn(CInt, CULong, CULong, CULong) -> CLong;
type ClearHostPteLogFn = unsafe extern "C" fn(CLong);
type SyscallRwlockFn = unsafe extern "C" fn(*mut c_void);
type MsyncLookupRangeFn = unsafe extern "C" fn(*mut c_void, CULong, CULong) -> *mut c_void;
type MsyncNextRangeFn = unsafe extern "C" fn(*mut c_void, *mut c_void) -> *mut c_void;
type MemlockSplitFn =
    unsafe extern "C" fn(*mut c_void, *mut c_void, CULong, *mut *mut c_void) -> CInt;
type MemlockJoinFn = unsafe extern "C" fn(*mut c_void, *mut c_void, *mut c_void) -> CInt;
type MprotectFlushFn = unsafe extern "C" fn();
type MprotectChangeFn = unsafe extern "C" fn(*mut c_void, *mut c_void, CULong) -> CInt;
type MprotectSetHostVmaFn = unsafe extern "C" fn(CULong, SizeT, CInt, CInt) -> CInt;
type MprotectLogFn = unsafe extern "C" fn(*const MprotectLogRecord);
#[repr(C)]
pub struct MprotectLogRecord {
    event: CInt,
    cpu: CInt,
    start: CULong,
    len: SizeT,
    prot: CInt,
    addr: CULong,
    range_start: CULong,
    range_end: CULong,
    range_flags: CULong,
    protflags: CULong,
    denied: CULong,
    error: CInt,
}
unsafe fn field_ptr<T>(base: *mut u8, offset: SizeT) -> *mut T {
    base.add(offset).cast::<T>()
}
unsafe fn memlock_range_ulong(range: *mut c_void, offset: SizeT) -> CULong {
    *field_ptr::<CULong>(range.cast::<u8>(), offset)
}
pub extern "C" fn range_has_disallowed_change_flags(flag: CULong) -> CInt {
    if (flag & (VR_REMOTE | VR_RESERVED | VR_IO_NOCACHE)) != 0 {
        1
    } else {
        0
    }
}
pub unsafe extern "C" fn clear_host_pte_body_result(
    vm: *mut c_void,
    addr: CULong,
    len: SizeT,
    holding_memory_range_lock: CInt,
    vm_lock_taken_offset: SizeT,
    cpu: CInt,
    syscall_nr: CInt,
    forward_fn: Option<SyscallDoSyscall3Fn>,
    log_fn: Option<ClearHostPteLogFn>,
) -> CLong {
    if holding_memory_range_lock != 0 {
        *field_ptr::<CInt>(vm.cast::<u8>(), vm_lock_taken_offset) = cpu;
    }

    let lerror = if let Some(forward) = forward_fn {
        forward(syscall_nr, addr, len as CULong, 0)
    } else {
        (-EINVAL) as CLong
    };

    if holding_memory_range_lock != 0 {
        *field_ptr::<CInt>(vm.cast::<u8>(), vm_lock_taken_offset) = -1;
    }
    if lerror != 0 {
        if let Some(log) = log_fn {
            log(lerror);
        }
    }
    lerror
}
pub extern "C" fn set_host_vma_body_result(
    _addr: CULong,
    _len: SizeT,
    _prot: CInt,
    _holding_memory_range_lock: CInt,
) -> CInt {
    #[cfg(native_linux_irq_work_v6_12)]
    unsafe {
        let thread = current_thread_ptr();
        if thread.is_null() || (*thread).vm.is_null() {
            return -EINVAL;
        }
        // Keep the mirror VMA's original protection and invalidate cached PFNs.
        // Subsequent host faults must consult the new guest PTE permissions.
        // The existing bridge publishes the held-range-lock flag while the
        // offload runs, then restores it before the caller unlocks that range.
        return clear_host_pte_body_result(
            (*thread).vm.cast::<c_void>(),
            _addr,
            _len,
            _holding_memory_range_lock,
            offset_of!(ProcessVm, is_memory_range_lock_taken),
            ihk_mc_get_processor_id(),
            11,
            Some(syscall_policy_do_syscall3_bridge),
            None,
        ) as CInt;
    }
    #[cfg(not(native_linux_irq_work_v6_12))]
    {
        0
    }
}
pub unsafe extern "C" fn mprotect_prepare_range(
    start: CULong,
    len0: SizeT,
    user_start: CULong,
    user_end: CULong,
    lenp: *mut SizeT,
    endp: *mut CULong,
) -> CInt {
    let len = len0.wrapping_add((PAGE_SIZE - 1) as SizeT) & PAGE_MASK as SizeT;
    let end = start.wrapping_add(len as CULong);

    write(lenp, len);
    write(endp, end);

    if (start & (PAGE_SIZE - 1)) != 0 {
        return -EINVAL;
    }

    if start < user_start || user_end <= start || user_end.wrapping_sub(start) < len as CULong {
        return -ENOMEM;
    }

    0
}
pub unsafe extern "C" fn mprotect_split_needed_result(
    range_start: CULong,
    range_end: CULong,
    addr: CULong,
    end: CULong,
    split_startp: *mut CInt,
    split_endp: *mut CInt,
) {
    if !split_startp.is_null() {
        unsafe {
            *split_startp = (range_start < addr) as CInt;
        }
    }
    if !split_endp.is_null() {
        unsafe {
            *split_endp = (end < range_end) as CInt;
        }
    }
}
pub extern "C" fn mprotect_write_changed_result(range_flags: CULong, protflags: CULong) -> CInt {
    let mask = if cfg!(native_linux_irq_work_v6_12) {
        VR_PROT_MASK
    } else {
        VR_PROT_WRITE
    };
    (((range_flags ^ protflags) & mask) != 0) as CInt
}
unsafe fn mprotect_log(
    log: Option<MprotectLogFn>,
    event: CInt,
    cpu: CInt,
    start: CULong,
    len: SizeT,
    prot: CInt,
    addr: CULong,
    range_start: CULong,
    range_end: CULong,
    range_flags: CULong,
    protflags: CULong,
    denied: CULong,
    error: CInt,
) {
    let Some(log) = log else {
        return;
    };

    let mut record = MaybeUninit::<MprotectLogRecord>::uninit();
    let ptr = record.as_mut_ptr();
    write_volatile(&raw mut (*ptr).event, event);
    write_volatile(&raw mut (*ptr).cpu, cpu);
    write_volatile(&raw mut (*ptr).start, start);
    write_volatile(&raw mut (*ptr).len, len);
    write_volatile(&raw mut (*ptr).prot, prot);
    write_volatile(&raw mut (*ptr).addr, addr);
    write_volatile(&raw mut (*ptr).range_start, range_start);
    write_volatile(&raw mut (*ptr).range_end, range_end);
    write_volatile(&raw mut (*ptr).range_flags, range_flags);
    write_volatile(&raw mut (*ptr).protflags, protflags);
    write_volatile(&raw mut (*ptr).denied, denied);
    write_volatile(&raw mut (*ptr).error, error);
    log(ptr as *const MprotectLogRecord);
}
pub unsafe extern "C" fn mprotect_body_result(
    vm: *mut c_void,
    range_lock: *mut c_void,
    start: CULong,
    len0: SizeT,
    prot: CInt,
    user_start: CULong,
    user_end: CULong,
    straight_va: CULong,
    straight_len: SizeT,
    cpu: CInt,
    range_start_offset: SizeT,
    range_end_offset: SizeT,
    range_flag_offset: SizeT,
    lock_fn: Option<SyscallRwlockFn>,
    unlock_fn: Option<SyscallRwlockFn>,
    lookup_fn: Option<MsyncLookupRangeFn>,
    next_fn: Option<MsyncNextRangeFn>,
    split_fn: Option<MemlockSplitFn>,
    join_fn: Option<MemlockJoinFn>,
    change_fn: Option<MprotectChangeFn>,
    set_host_vma_fn: Option<MprotectSetHostVmaFn>,
    flush_nfo_fn: Option<MprotectFlushFn>,
    flush_tlb_fn: Option<MprotectFlushFn>,
    log_fn: Option<MprotectLogFn>,
) -> CInt {
    let protflags = ((prot as CULong) << 16) & VR_PROT_MASK;
    mprotect_log(
        log_fn,
        MPROTECT_LOG_ENTER,
        cpu,
        start,
        len0,
        prot,
        0,
        0,
        0,
        0,
        protflags,
        0,
        0,
    );

    let mut len: SizeT = 0;
    let mut end: CULong = 0;
    let mut error = mprotect_prepare_range(start, len0, user_start, user_end, &mut len, &mut end);
    if error != 0 {
        mprotect_log(
            log_fn,
            MPROTECT_LOG_INVALID_RANGE,
            cpu,
            start,
            len0,
            prot,
            0,
            0,
            0,
            0,
            protflags,
            0,
            error,
        );
        return error;
    }

    if len == 0 {
        return 0;
    }

    if straight_va != 0
        && start >= straight_va
        && end <= straight_va.wrapping_add(straight_len as CULong)
    {
        mprotect_log(
            log_fn,
            MPROTECT_LOG_STRAIGHT_IGNORED,
            cpu,
            start,
            len0,
            prot,
            0,
            straight_va,
            straight_va.wrapping_add(straight_len as CULong),
            0,
            protflags,
            0,
            0,
        );
        mprotect_log(
            log_fn,
            MPROTECT_LOG_EXIT,
            cpu,
            start,
            len0,
            prot,
            0,
            0,
            0,
            0,
            protflags,
            0,
            0,
        );
        return 0;
    }

    if let Some(flush_nfo) = flush_nfo_fn {
        flush_nfo();
    }

    if let Some(lock) = lock_fn {
        lock(range_lock);
    }

    let first = if let Some(lookup) = lookup_fn {
        lookup(vm, start, start.wrapping_add(PAGE_SIZE))
    } else {
        core::ptr::null_mut()
    };
    let mut changed = core::ptr::null_mut::<c_void>();
    let mut ro_changed = 0;
    let mut addr = start;

    while addr < end {
        let mut range = if changed.is_null() {
            first
        } else if let Some(next) = next_fn {
            next(vm, changed)
        } else {
            core::ptr::null_mut()
        };

        if range.is_null() || addr < memlock_range_ulong(range, range_start_offset) {
            error = -ENOMEM;
            let (range_start, range_end, range_flags) = if range.is_null() {
                (0, 0, 0)
            } else {
                (
                    memlock_range_ulong(range, range_start_offset),
                    memlock_range_ulong(range, range_end_offset),
                    memlock_range_ulong(range, range_flag_offset),
                )
            };
            mprotect_log(
                log_fn,
                MPROTECT_LOG_NOT_CONTIG,
                cpu,
                start,
                len0,
                prot,
                addr,
                range_start,
                range_end,
                range_flags,
                protflags,
                0,
                error,
            );
            break;
        }

        let mut range_flags = memlock_range_ulong(range, range_flag_offset);
        let denied = protflags & !((range_flags & VR_MAXPROT_MASK) >> 4);
        if denied != 0 {
            error = -EACCES;
            mprotect_log(
                log_fn,
                MPROTECT_LOG_DENIED,
                cpu,
                start,
                len0,
                prot,
                addr,
                memlock_range_ulong(range, range_start_offset),
                memlock_range_ulong(range, range_end_offset),
                range_flags,
                protflags,
                denied,
                error,
            );
            break;
        }

        if range_has_disallowed_change_flags(range_flags) != 0 {
            error = -ENOMEM;
            mprotect_log(
                log_fn,
                MPROTECT_LOG_CANNOT_CHANGE,
                cpu,
                start,
                len0,
                prot,
                addr,
                memlock_range_ulong(range, range_start_offset),
                memlock_range_ulong(range, range_end_offset),
                range_flags,
                protflags,
                0,
                error,
            );
            break;
        }

        let mut split_start = 0;
        let mut split_end = 0;
        mprotect_split_needed_result(
            memlock_range_ulong(range, range_start_offset),
            memlock_range_ulong(range, range_end_offset),
            addr,
            end,
            &mut split_start,
            &mut split_end,
        );
        if split_start != 0 {
            error = if let Some(split) = split_fn {
                split(vm, range, addr, &mut range)
            } else {
                -EINVAL
            };
            if error != 0 {
                mprotect_log(
                    log_fn,
                    MPROTECT_LOG_SPLIT_FAILED,
                    cpu,
                    start,
                    len0,
                    prot,
                    addr,
                    memlock_range_ulong(range, range_start_offset),
                    memlock_range_ulong(range, range_end_offset),
                    memlock_range_ulong(range, range_flag_offset),
                    protflags,
                    0,
                    error,
                );
                break;
            }
        }
        if split_end != 0 {
            error = if let Some(split) = split_fn {
                split(vm, range, end, core::ptr::null_mut())
            } else {
                -EINVAL
            };
            if error != 0 {
                mprotect_log(
                    log_fn,
                    MPROTECT_LOG_SPLIT_FAILED,
                    cpu,
                    start,
                    len0,
                    prot,
                    end,
                    memlock_range_ulong(range, range_start_offset),
                    memlock_range_ulong(range, range_end_offset),
                    memlock_range_ulong(range, range_flag_offset),
                    protflags,
                    0,
                    error,
                );
                break;
            }
        }

        range_flags = memlock_range_ulong(range, range_flag_offset);
        if mprotect_write_changed_result(range_flags, protflags) != 0 {
            ro_changed = 1;
        }

        error = if let Some(change) = change_fn {
            change(vm, range, protflags)
        } else {
            -EINVAL
        };
        if error != 0 {
            mprotect_log(
                log_fn,
                MPROTECT_LOG_CHANGE_FAILED,
                cpu,
                start,
                len0,
                prot,
                addr,
                memlock_range_ulong(range, range_start_offset),
                memlock_range_ulong(range, range_end_offset),
                memlock_range_ulong(range, range_flag_offset),
                protflags,
                0,
                error,
            );
            break;
        }

        if changed.is_null() {
            changed = range;
        } else {
            let join_error = if let Some(join) = join_fn {
                join(vm, changed, range)
            } else {
                -EINVAL
            };
            if join_error != 0 {
                mprotect_log(
                    log_fn,
                    MPROTECT_LOG_JOIN_FAILED,
                    cpu,
                    start,
                    len0,
                    prot,
                    addr,
                    memlock_range_ulong(changed, range_start_offset),
                    memlock_range_ulong(range, range_end_offset),
                    memlock_range_ulong(range, range_flag_offset),
                    protflags,
                    0,
                    join_error,
                );
                changed = range;
            }
        }

        addr = memlock_range_ulong(changed, range_end_offset);
    }

    if let Some(flush_tlb) = flush_tlb_fn {
        flush_tlb();
    }
    if ro_changed != 0 && (error == 0 || cfg!(native_linux_irq_work_v6_12)) {
        let host_error = if let Some(set_host_vma) = set_host_vma_fn {
            set_host_vma(start, len, prot & (PROT_READ | PROT_WRITE | PROT_EXEC), 1)
        } else {
            -EINVAL
        };
        if host_error != 0 {
            mprotect_log(
                log_fn,
                MPROTECT_LOG_SET_HOST_FAILED,
                cpu,
                start,
                len0,
                prot,
                0,
                0,
                0,
                0,
                protflags,
                0,
                host_error,
            );
        }
        if error == 0 {
            error = host_error;
        }
    }
    if let Some(unlock) = unlock_fn {
        unlock(range_lock);
    }

    mprotect_log(
        log_fn,
        MPROTECT_LOG_EXIT,
        cpu,
        start,
        len0,
        prot,
        0,
        0,
        0,
        0,
        protflags,
        0,
        error,
    );
    error
}
