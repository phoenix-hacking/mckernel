"""Exact guest Rust protection bodies, preserved C reference and native offload."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-application-protection-protocol-20260909-' + sys.argv[1]); out.mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'], text=True).strip(),
    commands=[], extracted_bodies=[], scope='Exact legacy C comparison and selected Rust mprotect/host-invalidation bodies with controlled thread, VM, forwarding and range providers; no actual guest claim', production_gate_credit=False)

def identity(path):
    data=path.read_bytes(); return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def extract(path, pattern, name):
    data=path.read_text(); match=re.search(pattern,data,re.M); assert match,name
    start=match.start(); end=data.index('{',start)+1; depth=1
    while depth:
        depth+=(data[end]=='{')-(data[end]=='}'); end+=1
    body=data[start:end]
    record['extracted_bodies'].append(dict(source=str(path),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
    return body+'\n'
def run(label, args):
    print('RUN',label,flush=True); (out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])

try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['kernel/rust/syscall_policy.rs','kernel/rust/abi.rs','kernel/syscall.c','kernel/include/process.h','scripts/tests/fixtures/native-application-protection.rs']
    for name in names:
        path=out/'original-inputs'/name; path.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(repo/name,path)
    record['inputs']=[identity(out/'original-inputs'/name) for name in names]
    rust=out/'original-inputs/kernel/rust/syscall_policy.rs'; data=rust.read_text()
    generated=''
    constants=['EINVAL','ENOMEM','EACCES','PAGE_SIZE','PAGE_MASK','VR_PROT_WRITE','VR_PROT_MASK','VR_MAXPROT_MASK','VR_REMOTE','VR_RESERVED','VR_IO_NOCACHE','PROT_READ','PROT_WRITE','PROT_EXEC']
    constants+=re.findall(r'^const (MPROTECT_LOG_\w+):',data,re.M)
    for name in constants:
        match=re.search(r'^const '+name+r':[^;]+;',data,re.M); assert match,name; generated+=match[0]+'\n'
    for name in ['SyscallDoSyscall3Fn','ClearHostPteLogFn','SyscallRwlockFn','MsyncLookupRangeFn','MsyncNextRangeFn','MemlockSplitFn','MemlockJoinFn','MprotectFlushFn','MprotectChangeFn','MprotectSetHostVmaFn','MprotectLogFn']:
        match=re.search(r'^type '+name+r'\b[^;]+;',data,re.M); assert match,name; generated+=match[0]+'\n'
    generated+='#[repr(C)]\n'+extract(rust,r'^pub struct MprotectLogRecord \{','MprotectLogRecord')
    for name in ['field_ptr','memlock_range_ulong','range_has_disallowed_change_flags','clear_host_pte_body_result','set_host_vma_body_result','mprotect_prepare_range','mprotect_split_needed_result','mprotect_write_changed_result','mprotect_log','mprotect_body_result']:
        generated+=extract(rust,r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'(?:<[^>]+>)?\(',name)
    (out/'native-application-protection-bodies.rs').write_text(generated)
    shutil.copyfile(out/'original-inputs/kernel/rust/abi.rs',out/'abi.rs')
    shutil.copyfile(out/'original-inputs/scripts/tests/fixtures/native-application-protection.rs',out/'native-application-protection.rs')
    csource=out/'original-inputs/kernel/syscall.c'
    match=re.search(r'^#define\s+VR_PROT_WRITE\s+[^\n]+',(out/'original-inputs/kernel/include/process.h').read_text(),re.M); assert match
    generated='#include <stdio.h>\n#include <stddef.h>\n#define SYSCALL_POLICY_HELPER_SCOPE\n'+match[0]+'\n'
    for name in ['set_host_vma_body_result','mprotect_write_changed_result']:
        generated+=extract(csource,r'^SYSCALL_POLICY_HELPER_SCOPE int\n'+name+r'\(',name)
    generated+='int main(void) { for (int old=0; old<8; ++old) for (int next=0; next<8; ++next) printf("%d %d %d %d\\n",old,next,mprotect_write_changed_result((unsigned long)old<<16,(unsigned long)next<<16),set_host_vma_body_result(0x400000,8192,next,1)); return 0; }\n'
    (out/'c-reference.c').write_text(generated)
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(out/'native-application-protection.rs')])
    run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(out/'c-reference.c'),'-o',str(out/'c-reference')])
    run('c-reference',[str(out/'c-reference')])
    record['test_summaries']={}
    for kind,extra in [('legacy',[]),('native',['--cfg','native_linux_irq_work_v6_12'])]:
        run(kind+'-build',['rustc','--edition','2021','-D','warnings','--test',str(out/'native-application-protection.rs'),'-o',str(out/(kind+'-tests'))]+extra)
        run(kind+'-tests',[str(out/(kind+'-tests')),'--nocapture'])
        record['test_summaries'][kind]=[line for line in (out/(kind+'-tests.log')).read_text().splitlines() if line.startswith('test result:')]
    record['compiler_inputs']=[identity(out/name) for name in ['native-application-protection.rs','native-application-protection-bodies.rs','abi.rs','c-reference.c','c-reference.log']]
    for row in record['inputs']+record['compiler_inputs']: assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
