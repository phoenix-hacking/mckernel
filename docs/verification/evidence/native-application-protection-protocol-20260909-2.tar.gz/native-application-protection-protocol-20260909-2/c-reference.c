#include <stdio.h>
#include <stddef.h>
#define SYSCALL_POLICY_HELPER_SCOPE
#define	VR_PROT_WRITE      0x00020000
SYSCALL_POLICY_HELPER_SCOPE int
set_host_vma_body_result(unsigned long addr, size_t len, int prot,
		int holding_memory_range_lock)
{
	(void)addr;
	(void)len;
	(void)prot;
	(void)holding_memory_range_lock;
	return 0;
}
SYSCALL_POLICY_HELPER_SCOPE int
mprotect_write_changed_result(unsigned long range_flags,
		unsigned long protflags)
{
	return ((range_flags ^ protflags) & VR_PROT_WRITE) != 0;
}
int main(void) { for (int old=0; old<8; ++old) for (int next=0; next<8; ++next) printf("%d %d %d %d\n",old,next,mprotect_write_changed_result((unsigned long)old<<16,(unsigned long)next<<16),set_host_vma_body_result(0x400000,8192,next,1)); return 0; }
