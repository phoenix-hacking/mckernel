# mckernel spec file usage:
# cmake /path/to/mckernel && make dist
# cp -i ./mckernel-1.8.0.tar.gz <rpmbuild>/SOURCES
# rpmbuild -ba scripts/mckernel.spec
#
# for cross compilation also pass at least the following to rpmbuild:
# --target aarch64 -D 'kernel_version <target kernel>'
# you will need to setup your your environment as per
# cmake/README.cross_compilation

# Prevent rpmbuild from including build-id directories into package
%define _build_id_links none

%{!?kernel_version: %global kernel_version 5.15.0-139-generic}
%{!?kernel_dir: %global kernel_dir /usr/src/kernels/%{kernel_version}}
%define krequires %(echo %{kernel_version} | sed "s/.%{_target_cpu}$//")
%define ktag %(echo %{krequires} | tr '-' '_' | sed -e 's/\.el[0-9_]*$//' | sed -e 's/\.\([a-zA-Z]\)/_\1/')
%if "OFF" == "ON"
%define enable_uti 1
%else
%define enable_uti 0
%endif

Name: mckernel
Version: 1.8.0
Release: _%{ktag}%{?dist}
Summary: IHK/McKernel
License: GPLv2
Source0: mckernel-%{version}.tar.gz

Requires: systemd-libs numactl-libs libdwarf capstone

# don't use kernel_module_package so that one rpm including .ko and binaries are created
%if "%{?_host_cpu}" == "x86_64" && "%{?_target_cpu}" == "aarch64"
%define cross_compile 1
%else
BuildRequires: systemd-devel numactl-devel binutils-devel kernel-devel libdwarf-devel capstone-devel
# Friendly reminder of the fact that kernel-rpm-macros is no longer included in kernel-devel
%if 0%{?rhel} >= 8
BuildRequires: redhat-rpm-config kernel-rpm-macros elfutils-libelf-devel
%endif
%endif

%if 0%{?rhel} >= 8
Requires: kernel >= %{krequires}
%else
Requires: kernel = %{krequires}
%endif
Requires(post):   /usr/sbin/depmod
Requires(postun): /usr/sbin/depmod

%description
Interface for Heterogeneous Kernels and McKernel.

%package	devel
Summary:	Headers and libraries required for build apps using IHK/McKernel
Requires:	%{name} = %{version}-%{release}

%description	devel
This package contains headers and libraries required for build apps using IHK/McKernel.

%prep
%setup -q

%build
%if 0%{?cross_compile}
%{!?toolchain_file: %global toolchain_file cmake/cross-aarch64.cmake}
%{!?build_target: %global build_target smp-arm64}
%{!?cmake_libdir: %global cmake_libdir /usr/lib64}
%endif

# We need to remove ld flags like relro for the final mckernel.img link, as well as remove cflags for mckernel
# ideally mckernel should use different environment variables for the user tools and the kernel tools altogether...
%undefine _hardened_build
%define build_ldflags ""
%define __global_ldflags ""
%define optflags -O2 -g -pipe -Wall -Wp,-D_FORTIFY_SOURCE=2 -fexceptions --param=ssp-buffer-size=4 -grecord-gcc-switches -mtune=generic

mkdir build
pushd build
%cmake -DCMAKE_BUILD_TYPE=Release \
	-DUNAME_R=%{kernel_version} \
	-DKERNEL_DIR=%{kernel_dir} \
	%{?cmake_libdir:-DCMAKE_INSTALL_LIBDIR=%{cmake_libdir}} \
	%{?build_target:-DBUILD_TARGET=%{build_target}} \
	%{?toolchain_file:-DCMAKE_TOOLCHAIN_FILE=%{toolchain_file}} \
	-DENABLE_TOFU=OFF -DENABLE_FUGAKU_HACKS=OFF \
	-DENABLE_KRM_WORKAROUND=OFF -DWITH_KRM=OFF \
	-DENABLE_FUGAKU_DEBUG=OFF -DENABLE_UTI=OFF \
	-DENABLE_FJMPI_WORKAROUND=OFF \
	..
%make_build
popd

%install
pushd build
%make_install
popd

%files
%ifarch x86_64
%{_datadir}/mckernel/smp-x86/mckernel.img
%endif
%ifarch aarch64
%{_datadir}/mckernel/smp-arm64/mckernel.img
%endif
%{_sbindir}/mcreboot.sh
%{_sbindir}/mcstop+release.sh
%{_sbindir}/ihkconfig
%{_sbindir}/ihkosctl
%{_sbindir}/ihkmond
%{_bindir}/mcexec
%{_bindir}/eclair
%{_bindir}/eclair-dump-backtrace.exp
%{_bindir}/mcinspect
%{_bindir}/mcps
%{_bindir}/vmcore2mckdump
%{_bindir}/mcstat
%{_libdir}/libihk.so
%{_libdir}/libsched_yield.so.1.0.0
%{_libdir}/libsched_yield.so
%{_libdir}/libldump2mcdump.so
%if 0%{?enable_uti}
%{_libdir}/libmck_syscall_intercept.so
%{_libdir}/libsyscall_intercept.so.0.1.0
%{_libdir}/libsyscall_intercept.so.0
%{_libdir}/libsyscall_intercept.so
%{_libdir}/mck/libuti.so.1.0.0
%{_libdir}/mck/libuti.so.1
%{_libdir}/mck/libuti.so
%endif
%{_sysconfdir}/irqbalance_mck.in
%{_mandir}/man1/mcreboot.1.gz
%{_mandir}/man1/ihkconfig.1.gz
%{_mandir}/man1/ihkosctl.1.gz
%{_mandir}/man1/mcexec.1.gz

/lib/modules/%{kernel_version}/extra/mckernel/ihk.ko
/lib/modules/%{kernel_version}/extra/mckernel/mcctrl.ko
%ifarch x86_64
/lib/modules/%{kernel_version}/extra/mckernel/ihk-smp-x86_64.ko
%endif
%ifarch aarch64
/lib/modules/%{kernel_version}/extra/mckernel/ihk-smp-arm64.ko
%endif

%files	devel
%{_includedir}/ihklib.h
%{_includedir}/ihk/affinity.h
%{_includedir}/ihk/ihk_rusage.h
%{_includedir}/ihk/archdefs.h
%{_includedir}/ihk/status.h
%{_includedir}/ihk/ihk_monitor.h
%{_includedir}/ihk/ihk_debug.h
%{_includedir}/ihk/ihk_host_driver.h
/lib/modules/%{kernel_version}/extra/mckernel/ihk/linux/core/Module.symvers

# taken from /usr/lib/rpm/redhat/kmodtool (kernel_module_package)
%post
if [ -e "/boot/System.map-%{kernel_version}" ]; then
    /usr/sbin/depmod -aeF "/boot/System.map-%{kernel_version}" "%{kernel_version}" > /dev/null || :
fi

modules=( $(find /lib/modules/%{kernel_version}/extra/%{name} | grep '\.ko$') )
if [ -x "/sbin/weak-modules" ]; then
    printf '%s\n' "${modules[@]}" \
    | /sbin/weak-modules --add-modules
fi

%preun
rpm -ql %{name}-%{version} | grep '\.ko$' > /var/run/rpm-kmod-%{name}-modules

%postun
if [ -e "/boot/System.map-%{kernel_version}" ]; then
    /usr/sbin/depmod -aeF "/boot/System.map-%{kernel_version}" "%{kernel_version}" > /dev/null || :
fi

modules=( $(cat /var/run/rpm-kmod-%{name}-modules) )
rm /var/run/rpm-kmod-%{name}-modules
if [ -x "/sbin/weak-modules" ]; then
    printf '%s\n' "${modules[@]}" \
    | /sbin/weak-modules --remove-modules
fi

%changelog
* Tue Feb 12 2019 Dominique Martinet <dominique.martinet@cea.fr> - 1.6.0-0
- Initial package
