/work/mckernel-native-irq-images-20260907-4/fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-irq-images-20260907-4/fallback/tmp.resolve_MODULES_END/driver.o

