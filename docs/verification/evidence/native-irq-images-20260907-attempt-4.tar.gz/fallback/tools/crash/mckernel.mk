#
# Copyright (C) 2009, 2011, 2013 David Anderson
# Copyright (C) 2009, 2011, 2013 Red Hat, Inc. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

ifeq ($(shell arch), i686)
  TARGET=X86
  TARGET_CFLAGS=-D_FILE_OFFSET_BITS=64
endif
ifeq ($(shell arch), ppc64)
  TARGET=PPC64
  TARGET_CFLAGS=-m64
endif
ifeq ($(shell arch), ppc64le)
  TARGET=PPC64
  TARGET_CFLAGS=-m64
endif
ifeq ($(shell arch), ia64)
  TARGET=IA64
  TARGET_CFLAGS=
endif
ifeq ($(shell arch), x86_64)
  TARGET=X86_64
  TARGET_CFLAGS=
endif
ifeq ($(shell arch), aarch64)
  TARGET=ARM64
  TARGET_CFLAGS=
endif

ifeq ($(shell /bin/ls ../defs.h 2> /dev/null), ../defs.h)
  INCDIR=..
endif
ifeq ($(shell /bin/ls ./defs.h 2> /dev/null), ./defs.h)
  INCDIR=.
endif
ifeq ($(shell /bin/ls /usr/include/crash/defs.h 2>/dev/null), /usr/include/crash/defs.h)
  INCDIR=/usr/include/crash
endif

RUSTC=$(shell command -v rustc 2>/dev/null)
ifneq ($(RUSTC),)
  RUST_OBJ=mckernel_crash_helpers.o
  RUST_CFLAGS=-DMCKERNEL_CRASH_RUST_HELPERS
  ifeq ($(TARGET),X86_64)
    RUST_CFG=--cfg mckernel_crash_x86_64
  endif
endif

all: mckernel.so

mckernel_crash_helpers.o: rust/mckernel_crash_helpers.rs
	$(RUSTC) $(RUST_CFG) --crate-name mckernel_crash_helpers --crate-type lib --edition=2021 -C panic=abort -C opt-level=2 -C debuginfo=1 -C relocation-model=pic -C force-unwind-tables=no --emit=obj=$@ $<

mckernel.so: $(INCDIR)/defs.h mckernel.c $(RUST_OBJ)
	gcc -Wall -g -I$(INCDIR) -shared -rdynamic -o mckernel.so mckernel.c $(RUST_OBJ) -fPIC -D$(TARGET) -DMAP_KERNEL_START=0xfffffffffe800000UL $(TARGET_CFLAGS) $(GDB_FLAGS) $(RUST_CFLAGS)
