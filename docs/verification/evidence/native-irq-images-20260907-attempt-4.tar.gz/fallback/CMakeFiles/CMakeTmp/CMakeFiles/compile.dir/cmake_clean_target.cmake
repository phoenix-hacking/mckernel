file(REMOVE_RECURSE
  "libcompile.a"
)
