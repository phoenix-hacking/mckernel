file(REMOVE_RECURSE
  "CMakeFiles/compile.dir/src.c.o"
  "CMakeFiles/compile.dir/src.c.o.d"
  "libcompile.a"
  "libcompile.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/compile.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
