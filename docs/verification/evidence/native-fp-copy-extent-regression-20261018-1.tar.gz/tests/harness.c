#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include "registers.h"
#define PAGE_SIZE 4096
#define PAGE_SHIFT 12
#define PAGE_P2ALIGN 0
#define IHK_MC_AP_NOWAIT 0
#define IHK_MC_PG_KERNEL 0
#define dkprintf(...) ((void)0)
#define kprintf(...) ((void)0)
struct thread { fp_regs_struct *fp_regs; };
static int xsave_available = 1;
static int xsave_size;
static int allocations, copies, fail_alloc;
static size_t copied;
static unsigned char pool[PAGE_SIZE + 64] __attribute__((aligned(64)));
static void *allocate(int pages, int align, int flags, int node, int kind,
                      int user, const char *file, int line)
{
    (void)align; (void)flags; (void)node; (void)kind;
    (void)user; (void)file; (void)line;
    allocations++;
    if (pages != 1) abort();
    if (fail_alloc) return NULL;
    return pool;
}
#define _ihk_mc_alloc_aligned_pages_node allocate
static void *copy_bytes(void *dst, const void *src, size_t size)
{
    copies++;
    copied = size;
    return memcpy(dst, src, size);
}
#define memcpy copy_bytes
#include "body.inc"
#undef memcpy
static int errors;
#define CHECK(expr) do { if (!(expr)) { \
    fprintf(stderr, "FAIL extent=%d line=%d: %s\n", xsave_size, __LINE__, #expr); \
    errors++; } } while (0)
static void reset(int size)
{
    xsave_size = size;
    allocations = copies = fail_alloc = 0;
    copied = 0;
    memset(pool, 0xa5, sizeof(pool));
}
static void extent_case(int size)
{
    unsigned char source[PAGE_SIZE + 64] __attribute__((aligned(64)));
    unsigned char snapshot[sizeof(source)];
    unsigned char dest[PAGE_SIZE + 64] __attribute__((aligned(64)));
    struct thread from = { (fp_regs_struct *)source }, to = { NULL };
    size_t i;
    for (i = 0; i < sizeof(source); i++) source[i] = (unsigned char)(1 + i % 251);
    memcpy(snapshot, source, sizeof(source));
    reset(size);
    CHECK(copy_fp_regs(&from, &to) == 0);
    CHECK(allocations == 1 && copies == 1 && copied == (size_t)size);
    CHECK(to.fp_regs == (fp_regs_struct *)pool && to.fp_regs != from.fp_regs);
    CHECK(memcmp(pool, source, (size_t)size) == 0);
    for (i = (size_t)size; i < PAGE_SIZE; i++) CHECK(pool[i] == 0);
    for (i = PAGE_SIZE; i < sizeof(pool); i++) CHECK(pool[i] == 0xa5);
    CHECK(memcmp(snapshot, source, sizeof(source)) == 0);
    pool[0] ^= 0xff;
    CHECK(memcmp(snapshot, source, sizeof(source)) == 0);

    reset(size); fail_alloc = 1; to.fp_regs = NULL;
    CHECK(copy_fp_regs(&from, &to) == -ENOMEM);
    CHECK(allocations == 1 && copies == 0 && to.fp_regs == NULL);
    CHECK(memcmp(snapshot, source, sizeof(source)) == 0);
    for (i = 0; i < sizeof(pool); i++) CHECK(pool[i] == 0xa5);

    reset(size); memset(dest, 0xa5, sizeof(dest));
    to.fp_regs = (fp_regs_struct *)dest;
    CHECK(copy_fp_regs(&from, &to) == 0);
    CHECK(allocations == 0 && copies == 1 && copied == (size_t)size);
    CHECK(to.fp_regs == (fp_regs_struct *)dest);
    CHECK(memcmp(dest, source, (size_t)size) == 0);
    for (i = (size_t)size; i < sizeof(dest); i++) CHECK(dest[i] == 0xa5);
    CHECK(memcmp(snapshot, source, sizeof(source)) == 0);

    reset(size); from.fp_regs = NULL; to.fp_regs = NULL;
    CHECK(copy_fp_regs(&from, &to) == 0);
    CHECK(allocations == 0 && copies == 0 && to.fp_regs == NULL);
    puts("case completed");
}
int main(void)
{
    printf("real fp_regs_struct=%zu legacy i387=%zu\n", sizeof(fp_regs_struct),
           sizeof(struct i387_fxsave_struct));
    CHECK(sizeof(struct i387_fxsave_struct) == 512);
    CHECK(sizeof(fp_regs_struct) < 2696);
    extent_case(2696);
    extent_case((int)sizeof(struct i387_fxsave_struct));
    extent_case((int)sizeof(fp_regs_struct));
    printf("errors=%d\n", errors);
    return errors ? 1 : 0;
}
