from pathlib import Path
import difflib, hashlib, json, os, subprocess, sys
base = Path(__file__).resolve().parent.parent
assert sys.version_info[:2] == (3, 9)
env = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}
results = []
def run(cmd, name):
    p = subprocess.run(cmd, cwd=str(base), env=env, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=30)
    (base / "evidence" / (name + ".log")).write_bytes(p.stdout)
    results.append({"name":name, "command":cmd, "environment":env,
                    "returncode":p.returncode})
    return p.returncode
def body(path):
    text = path.read_text()
    a = text.index("static int\ncheck_and_allocate_fp_regs(")
    z = text.index("\n/*@", a)
    c = text.index("int copy_fp_regs(")
    d = text.index("\nstatic void restore_default_fp_regs", c)
    return text[a:z] + "\n" + text[c:d]
orig = base / "fixtures/cpu.original.c"
fixed = base / "source/arch/x86_64/kernel/cpu.c"
(base / "report/repair.diff").write_text("".join(difflib.unified_diff(
    orig.read_text().splitlines(True), fixed.read_text().splitlines(True),
    fromfile="a/arch/x86_64/kernel/cpu.c", tofile="b/arch/x86_64/kernel/cpu.c")))
assert run(["/usr/bin/gcc", "--version"], "compiler-version") == 0
for label, path in (("original", orig), ("repaired", fixed)):
    out = base / "tests" / label
    out.mkdir(exist_ok=False)
    extracted = body(path)
    (out / "body.inc").write_text(extracted)
    cmd = ["/usr/bin/gcc", "-std=gnu99", "-Wall", "-Wextra", "-Werror",
           "-I" + str(base / "fixtures"), "-I" + str(out),
           str(base / "tests/harness.c"), "-o", str(out / "regression")]
    rc = run(cmd, label + "-compile")
    if rc != 0: break
    rc = run([str(out / "regression")], label + "-run")
    if (label == "original" and rc != 1) or (label == "repaired" and rc != 0): break
else:
    (base / "report/ready.txt").write_text("READY FOR REVIEW: original rejected; repaired passes unchanged oracle.\n")
(base / "evidence/commands.json").write_text(json.dumps(results, indent=2) + "\n")
files = sorted(p for group in ("source", "fixtures", "tests", "evidence", "report")
               for p in (base / group).rglob("*") if p.is_file())
(base / "report/hashes.json").write_text(json.dumps({str(p.relative_to(base)):
    hashlib.sha256(p.read_bytes()).hexdigest() for p in files}, indent=2) + "\n")
if not (base / "report/ready.txt").exists(): sys.exit(2)
