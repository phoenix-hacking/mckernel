"""Bind actual fresh8b artifacts to the accepted finite15 producer; no tools/copy/root."""
from pathlib import Path
import ast,copy,hashlib,json,os,stat
P=Path(__file__).resolve().parent;R=P.parent;A=R.parents[1];V=A/'terminal-preparation-1/fresh-full-8b-amendment-1';O=V/'postbuild-readonly-1'
L=A.parent/'future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/remaining-only-late-binding-1';OLD=L/'postbuild-readonly-1'
REVIEW=A.parent/'four-callback-affinity-image-heavy-review-20261019-1/NEW205-FRESH8B-ACTUAL-BUILD-AND-CLIENT-RETIREMENT-REVIEW.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ref(p):
 raw=Path(p).read_bytes();return dict(path=str(p),sha256=sha(raw),bytes=len(raw))
def bound(r):
 raw=Path(r['path']).read_bytes();assert sha(raw)==r['sha256'] and ('bytes' not in r or len(raw)==r['bytes']);return json.loads(raw)
def write(name,value):
 with (P/name).open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
def observe(p):
 p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode);h=hashlib.sha256();count=0
  while True:
   data=os.read(fd,65536)
   if not data:break
   count+=len(data);assert count<=a.st_size;h.update(data)
  b=os.fstat(fd);stable=lambda x:(x.st_dev,x.st_ino,x.st_mode,x.st_uid,x.st_gid,x.st_nlink,x.st_size,x.st_mtime_ns,x.st_ctime_ns);assert stable(a)==stable(b)==stable(os.lstat(p)) and count==a.st_size
  return dict(path=str(p),dev=b.st_dev,inode=b.st_ino,uid=b.st_uid,gid=b.st_gid,mode=stat.S_IMODE(b.st_mode),bytes=b.st_size,mtime_ns=b.st_mtime_ns,ctime_ns=b.st_ctime_ns,sha256=h.hexdigest())
 finally:os.close(fd)
def rebind(value,oldwork):
 if isinstance(value,str):return value.replace(str(oldwork),str(R/'owner-work')).replace(str(OLD),str(O))
 if isinstance(value,list):return [rebind(x,oldwork) for x in value]
 if isinstance(value,dict):return {k:rebind(v,oldwork) for k,v in value.items()}
 return value
def main():
 assert ref(REVIEW)['sha256']=='f7352de9e6aaf2ed6de5928cbb94c55c7b2a2ca6a7598c9d79d2bc933e6dbf98';review=json.loads(REVIEW.read_bytes());request=ref(R/'image-request.json');assert request['sha256']=='8b7b34ede927594675ad8cd303c24c233f4dcdaaa414c5a4c1171adc1139cbe1' and review['request']==request
 assert review['current_build_success'] is True and review['positive_client_retirement'] is True and review['terminal_container_retained'] is True
 assert not O.exists();build=R/'owner-work/output/build';database=json.loads((build/'compile_commands.json').read_bytes());cpurows=[r for r in database if r['file']=='/src/arch/x86_64/kernel/cpu.c'];assert len(cpurows)==1;cpuobject=build/cpurows[0]['output'];paths=dict(cpu=str(cpuobject),process=str(build/'kernel/CMakeFiles/mckernel.img.dir/process.c.o'),rust=str(build/'kernel/rust/mckernel_rust.o'),image=str(build/'kernel/mckernel.img'))
 artifacts={k:observe(v) for k,v in paths.items()};extra={'fallback':observe(build/'release-tid-production/fallback-process.o')};assert artifacts['image']['sha256']==review['image']['sha256'] and artifacts['image']['bytes']==review['image']['size'];assert sum(r['bytes'] for r in artifacts.values())<=32*2**20
 write('actual-artifacts.json',artifacts);write('inspection-extra-artifacts.json',extra)
 oldplan=json.loads((OLD/'initial-15-command-plan.json').read_bytes());oldwork=Path(oldplan['paths']['image']).parents[3];assert str(oldwork).endswith('/owner-work');plan=rebind(oldplan,oldwork)
 plan['paths']=paths
 for op in plan['operations'][12:]:
  op['actual_artifact_argv']=None;op['mechanical_late_binding']='actualclosedreadelf9/12 via pinned380 only';op['argv']=op['argv'][:op['argv'].index('--')+1]+['PENDING_ACTUAL_DESCRIPTOR_RESOLUTION']
 plan['commands']=[op['argv'] for op in plan['operations']];write('initial15-command-plan.json',plan)
 copyplan=json.loads((OLD/'exact-four-copy-command.json').read_bytes());copyplan=rebind(copyplan,oldwork);code=copyplan['argv'][copyplan['argv'].index('-c')+1];code=code.replace(str(O/'actual-artifacts.json'),str(P/'actual-artifacts.json'));code=code.replace('assert hashlib.sha256(pin.read_bytes()).hexdigest()==sys.argv[1]\n rows=json.loads(pin.read_text())','raw=pin.read_bytes();assert hashlib.sha256(raw).hexdigest()==sys.argv[1]\n rows=json.loads(raw)');copyplan['argv'][copyplan['argv'].index('-c')+1]=code;copyplan['argv'][-1]='ACTUAL_ARTIFACTS_SHA256_FROM_GENERATED_METADATA';copyplan['immutable_inputs']=ref(P/'actual-artifacts.json');copyplan['total_artifact_bytes']=sum(r['bytes'] for r in artifacts.values());copyplan['manual_inline_copy_source']={'bytes':len(code.encode()),'sha256':sha(code.encode())};write('exact-four-copy-command.json',copyplan)
 profile=rebind(json.loads((OLD/'profile.json').read_bytes()),oldwork);profile['required_absent_paths']=[str(O)];profile['original_DWARF13']='OPEN_NO_REPLAY_NO_WAIVER; actualfreshC110/syscall10+8/layout27/fullcrates separatelyprove literalcontracts';write('profile.json',profile)
 oldrelease=json.loads((OLD/'readonly15-execution-release-correction-1.json').read_bytes());tools=bound(oldrelease['tools'])
 for t in tools.values():
  p=Path(t['path']);resolved=p.resolve();observed=observe(resolved);assert observed['sha256']==t['sha256'];t['resolved_path']=str(resolved);t['identity']={k:observed[k] for k in ['dev','inode','uid','gid','mode','bytes','mtime_ns','ctime_ns']}
 write('tool-pins.json',tools)
 bindings=json.loads((V/'FIFTEEN-FACTS-BINDINGS-NULL-TEMPLATE.json').read_bytes());compiler=bindings['compiler_boundary']
 for key in ['process_checks','affinity_checks']:compiler[key]=ref(compiler[key]['path'])
 for group in ['full_crates','layout_vectors']:
  for k,v in compiler[group].items():compiler[group][k]=ref(v['path'])
 write('facts-bindings-template.json',bindings)
 release=dict(status='PASS_EXACT_ORDINARY_POSTBUILD_READONLY_RELEASE',author='/root/rust_next_teardown_leaf',dispatcher=ref(P/'observe_fresh_full_postbuild.py'),descriptor_facts_producer=ref(V/'derive_new205_facts.py'),descriptor_api=ref(L/'facts-correction-1/postbuild_future_facts_corrected.py'),actual_role_adapter=ref(P/'prepare_actual_plan.py'),commands=ref(P/'initial15-command-plan.json'),copies=ref(P/'exact-four-copy-command.json'),profile=ref(P/'profile.json'),tools=ref(P/'tool-pins.json'),actual_artifacts=ref(P/'actual-artifacts.json'),inspection_extra_artifacts=ref(P/'inspection-extra-artifacts.json'),facts_bindings_template=ref(P/'facts-bindings-template.json'),request=request,request_sha256=request['sha256'],actual_build_acceptance=ref(REVIEW),driver_receipt=review['driver_receipt'],container_id=review['container_id'],owner_completion={'owner_receipt':review['owner_receipt'],'guard_result':review['guard_result'],'postjoin_readback':review['ordinary_postjoin']},operation_completion_contracts={str(i):dict(classification='MECHANICAL_INPUT',receipt_stage='command-'+str(i),returncode=0,stderr_policy='empty') for i in range(1,16)},late_binding_policy={'path':str(P/'exact-late-binding-policy.json'),'sha256':'PENDING_INDEPENDENT_POLICY_SHA256'},execution_review={'path':str(P/'execution-review.json'),'sha256':'PENDING_INDEPENDENT_EXECUTION_REVIEW_SHA256'},cleanup_authority=False,retention_authority=False,production_or_native_acceptance=False,original_full_DWARF_gap_open=True)
 write('release-payload-DRAFT.json',{k:v for k,v in release.items() if k!='execution_review'});write('execution-request.json',release)
 write('PLANNER-RESULT.json',{'status':'BOUND_ACTUAL_FULLFRESH_ARTIFACTS15_SOURCE_ONLY','build_acceptance':ref(REVIEW),'request':request,'artifact_bytes':sum(r['bytes'] for r in artifacts.values()),'plan':ref(P/'initial15-command-plan.json'),'release_draft':ref(P/'release-payload-DRAFT.json'),'tools_copy_root_executions':0})
 print(json.dumps({'status':'BOUND_ACTUAL_FULLFRESH_METADATA_ONLY','artifacts':4,'operations':15,'copies_executed':0,'toolruns':0}))
if __name__=='__main__':main()
