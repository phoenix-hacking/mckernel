"""Actual producer entrypoint with effects stubbed; synthetic tool bytes only."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,tempfile,types
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('actual15producer',P/'observe_fresh_full_postbuild.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def put(p,value):
 p.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
with tempfile.TemporaryDirectory(prefix='new205-readonly15-interface-') as tmp:
 t=Path(tmp);g.O=t/'output';release=json.loads((P/'execution-request.json').read_bytes());plan=g.bound(release['commands']);profile=g.bound(release['profile']);copyplan=g.bound(release['copies']);old=Path(profile['required_absent_paths'][0])
 def swap(value):
  if isinstance(value,str):return value.replace(str(old),str(g.O))
  if isinstance(value,list):return [swap(v) for v in value]
  if isinstance(value,dict):return {k:swap(v) for k,v in value.items()}
  return value
 plan=swap(plan);profile=swap(profile);copyplan=swap(copyplan)
 release['commands']=put(t/'plan.json',plan);release['profile']=put(t/'profile.json',profile);release['copies']=put(t/'copy.json',copyplan)
 policy={'decision':'PASS_EXACT_ACTUAL_READ_ELF_NDX_AND_RANGE_LATE_BINDING_ONLY','implementation_ownership':False,'reviewer':'SYNTHETIC_PEER','final_execution_review_literal_except_payload_hash':dict(decision='PASS_EXACT_ORDINARY_POSTBUILD_READONLY',implementation_ownership=False,reviewer='SYNTHETIC_PEER')};release['late_binding_policy']=put(t/'policy.json',policy)
 calls=[]
 class Fake:
  def __init__(self,argv,stdin,stdout,stderr):
   self.pid=os.getpid();n=len(calls);calls.append(argv)
   text='SYNTHETIC empty observation\n'
   if n==9:text=' 1: 0000000000000000 32 OBJECT GLOBAL DEFAULT 100 RELEASE_TID_DEBUG\n 2: 0000000000000000 32 OBJECT GLOBAL DEFAULT 101 REPLACE_TID_DEBUG\n'
   if n==12:text=' 1: ffffffff00001000 32 OBJECT GLOBAL DEFAULT 3 RELEASE_TID_DEBUG\n 2: ffffffff00001020 32 OBJECT GLOBAL DEFAULT 3 REPLACE_TID_DEBUG\n'
   stdout.write(text.encode());stdout.flush()
  def wait(self):return 0
 g.subprocess=types.SimpleNamespace(Popen=Fake,DEVNULL=-3)
 def final(value,name):
  payload={k:v for k,v in value.items() if k!='execution_review'};review=dict(decision='PASS_EXACT_ORDINARY_POSTBUILD_READONLY',implementation_ownership=False,reviewer='SYNTHETIC_PEER',reviewed_release_payload_sha256=hashlib.sha256((json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest());value=copy.deepcopy(value);value['execution_review']=put(t/(name+'review.json'),review);r=put(t/(name+'.json'),value);return [r['path'],r['sha256']]
 g.main(final(release,'positive'));assert len(calls)==16
 resolved=json.loads((g.O/'resolved15-command-plan.json').read_bytes());assert resolved['operations'][12]['actual_artifact_argv'][2]=='100' and resolved['operations'][13]['actual_artifact_argv'][2]=='101';assert '--start-address=0xffffffff00001000' in resolved['operations'][14]['actual_artifact_argv'] and '--stop-address=0xffffffff00001040' in resolved['operations'][14]['actual_artifact_argv']
 assert len(json.loads((g.O/'completed-command-receipt.json').read_bytes())['results'])==16
 command=json.loads((g.O/'next-facts-command-PENDING-SOURCE-ASSOCIATION.json').read_bytes())['argv'];assert len(command[command.index('-B')+1:])==4
 negative=0
 for field in ('container_id','request','actual_build_acceptance'):
  wrong=copy.deepcopy(release)
  if field=='container_id':wrong[field]='0'*64
  elif field=='request':wrong[field]['sha256']='0'*64
  else:wrong[field]['sha256']='0'*64
  before=len(calls)
  try:g.main(final(wrong,field))
  except AssertionError:negative+=1
  else:raise AssertionError('foreign input accepted')
  assert len(calls)==before
 print(json.dumps(dict(status='PASS_SYNTHETIC_ACTUAL_ENTRYPOINT_INTERFACE_ONLY',positive=1,negative=negative,stubbed_effects=16,late_ndx_range=True,facts_positional_args=3,actual_tools_copies_root=0)))
