import argparse,hashlib,json,os,resource,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--approved-release',required=True);p.add_argument('--sha256',required=True);a=p.parse_args();P=Path(__file__).resolve().parent
raw=Path(a.approved_release).read_bytes();assert hashlib.sha256(raw).hexdigest()==a.sha256
packet=P/'SOURCE-AND-EXECUTION-REVIEW.json';assert hashlib.sha256(packet.read_bytes()).hexdigest()=='8145f5af77bc70e036ffd1d4a9ac0d6a5473dd50ebf09e909e28763eacdbafe1';spec=json.loads(packet.read_bytes());argv=spec['actual_observation_command'];assert argv[-1]=='ACTUAL_FINAL_RELEASE_SHA256_FROM_FILE';dest=Path(argv[-2]);assert dest==P/'readonly15-execution-release.json'
with dest.open('xb') as f:f.write(raw)
argv[-1]=a.sha256;cap=P/'actual-readonly15-run-1';cap.mkdir(mode=0o700);os.umask(0o077);os.sched_setaffinity(0,{6});resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432))
def put(name,obj):
 with (cap/name).open('x') as f:json.dump(obj,f,sort_keys=True,indent=2);f.write('\n')
def desc(path):
 st=path.stat();v={'path':str(path),'device':st.st_dev,'inode':st.st_ino,'uid':st.st_uid,'gid':st.st_gid,'mode':oct(st.st_mode),'nlink':st.st_nlink,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns};v['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();s=path.stat();assert (st.st_dev,st.st_ino,st.st_uid,st.st_gid,st.st_mode,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns)==(s.st_dev,s.st_ino,s.st_uid,s.st_gid,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns);return v
state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_bytes());assert state.get('stop_reason') is None and state['last_rate_limits']['primary']['usedPercent']<97
for root,floor in [('/home/holden',17179869184),('/home/holden/mckernel-work/scratch',12884901888)]:
 fs=os.statvfs(root);assert fs.f_bavail*fs.f_frsize>=floor+671088640
put('command.json',{'argv':argv,'approved_release_sha256':a.sha256,'source_packet_sha256':'8145f5af77bc70e036ffd1d4a9ac0d6a5473dd50ebf09e909e28763eacdbafe1','each_stream_cap_bytes':33554432});t=time.monotonic();error=None
with (cap/'stdout').open('xb') as out,(cap/'stderr').open('xb') as err:
 c=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True);start=int(Path('/proc/%d/stat'%c.pid).read_text().rsplit(')',1)[1].split()[19]);put('child.json',{'pid':c.pid,'starttime':start,'pgid':c.pid,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
 try:rc=c.wait(timeout=700)
 except subprocess.TimeoutExpired:
  error='outer_wall_timeout';assert int(Path('/proc/%d/stat'%c.pid).read_text().rsplit(')',1)[1].split()[19])==start
  os.killpg(c.pid,signal.SIGTERM)
  try:rc=c.wait(timeout=2)
  except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);rc=c.wait(timeout=2)
 put('direct-join.json',{'returncode':rc,'direct_child_joined':True,'pid':c.pid,'starttime':start,'observer_error':error,'duration_seconds':time.monotonic()-t})
try:os.killpg(c.pid,0);absent=False
except ProcessLookupError:absent=True
status={'returncode':rc,'direct_child_joined':True,'pid':c.pid,'starttime':start,'process_group_absent':absent,'observer_error':error,'duration_seconds':time.monotonic()-t,'stdout':desc(cap/'stdout'),'stderr':desc(cap/'stderr')};put('status.json',status);print(json.dumps({'returncode':rc,'direct_child_joined':True,'duration_seconds':status['duration_seconds'],'process_group_absent':absent,'status':str(cap/'status.json'),'status_sha256':hashlib.sha256((cap/'status.json').read_bytes()).hexdigest()}));assert rc==0 and absent and error is None
