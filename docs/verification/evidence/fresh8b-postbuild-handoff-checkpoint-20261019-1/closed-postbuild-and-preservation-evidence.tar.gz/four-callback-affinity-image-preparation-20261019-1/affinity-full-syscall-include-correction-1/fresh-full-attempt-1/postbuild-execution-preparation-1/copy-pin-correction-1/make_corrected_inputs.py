"""Exact zero-copy-prefix correction; preserve consumed b10 and original37destinations."""
from pathlib import Path
import ast,hashlib,json
Q=Path(__file__).resolve().parent;P=Q.parent;O=Q/'observation-1'
def ref(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def write(n,v):
 with (Q/n).open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
def python_code_index(argv):
 python=argv.index('/home/holden/anaconda3/bin/python3');index=argv.index('-c',python+1)+1;assert argv[index-1]=='-c' and index>argv.index('-c')+1;return index

def main():
 old=json.loads((P/'exact-four-copy-command.json').read_bytes());argv=old['argv'];index=python_code_index(argv);code=argv[index]
 tree=ast.parse(code);pin=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pin' for t in n.targets));oldpin=ast.literal_eval(pin.value.args[0]);assert oldpin!=str(P/'actual-artifacts.json') and not Path(oldpin).exists()
 code=code.replace(oldpin,str(P/'actual-artifacts.json'));oldread='assert hashlib.sha256(pin.read_bytes()).hexdigest()==sys.argv[1]\n rows=json.loads(pin.read_text())';newread='raw=pin.read_bytes();assert hashlib.sha256(raw).hexdigest()==sys.argv[1]\n rows=json.loads(raw)';assert code.count(oldread)==1;code=code.replace(oldread,newread);ast.parse(code);argv[index]=code
 original_output=Path(old['captures']['stdout']).parent;assert not Path(old['destination']).exists() and not O.exists()
 old['captures']={k:str(O/Path(v).name) for k,v in old['captures'].items()};old['immutable_inputs']=ref(P/'actual-artifacts.json');old['manual_inline_copy_source']={'bytes':len(code.encode()),'sha256':hashlib.sha256(code.encode()).hexdigest()};write('exact-four-copy-command.json',old)
 def swap(x):
  if isinstance(x,str):return x.replace(str(original_output),str(O))
  if isinstance(x,list):return [swap(v) for v in x]
  if isinstance(x,dict):return {k:swap(v) for k,v in x.items()}
  return x
 plan=swap(json.loads((P/'initial15-command-plan.json').read_bytes()));write('initial15-command-plan.json',plan)
 profile=json.loads((P/'profile.json').read_bytes());profile['required_absent_paths']=[str(O),old['destination']];write('profile.json',profile)
 source=(P/'observe_fresh_full_postbuild.py').read_text();oldassign='O=Path('+repr(str(original_output))+')';assert source.count(oldassign)==1;source=source.replace(oldassign,'O=Path('+repr(str(O))+')');ast.parse(source);(Q/'observe_corrected_copy15.py').write_text(source)
 release=json.loads((P/'readonly15-execution-release.json').read_bytes());assert ref(P/'readonly15-execution-release.json')['sha256']=='b10db12c394b88d95139c77d3fcaee8f6bbfb8ed94f4c7eced2164ba2225e4cb'
 release.update(dispatcher=ref(Q/'observe_corrected_copy15.py'),actual_role_adapter=ref(Q/'make_corrected_inputs.py'),commands=ref(Q/'initial15-command-plan.json'),copies=ref(Q/'exact-four-copy-command.json'),profile=ref(Q/'profile.json'),late_binding_policy={'path':str(Q/'exact-late-binding-policy.json'),'sha256':'PENDING_PEER_POLICY_SHA256'},execution_review={'path':str(Q/'execution-review.json'),'sha256':'PENDING_PEER_EXECUTION_REVIEW_SHA256'})
 write('release-payload-DRAFT.json',{k:v for k,v in release.items() if k!='execution_review'});write('execution-request.json',release)
 print(json.dumps({'status':'BOUND_ONE_ZERO_COPY_PREFIX_CORRECTION','python_code_index':index,'taskset_cpu':argv[argv.index('/usr/bin/taskset')+2],'pin':str(P/'actual-artifacts.json'),'new_capture_namespace':str(O),'primary_retention_destination_unchanged':old['destination'],'copies_tools_run':0}))
if __name__=='__main__':main()
