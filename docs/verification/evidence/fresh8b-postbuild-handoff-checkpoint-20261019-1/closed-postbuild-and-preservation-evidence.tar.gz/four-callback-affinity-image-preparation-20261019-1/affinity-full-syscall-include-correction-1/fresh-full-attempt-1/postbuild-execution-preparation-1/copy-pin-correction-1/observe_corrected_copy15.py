"""Case-specific14 adapter of accepted FP finite capture producer; no root/Docker/decoder."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
R=Path('/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/affinity-full-syscall-include-correction-1/fresh-full-attempt-1');O=Path('/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/affinity-full-syscall-include-correction-1/fresh-full-attempt-1/postbuild-execution-preparation-1/copy-pin-correction-1/observation-1')
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
def bound(row):
 p=Path(row['path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];assert 'bytes' not in row or len(raw)==row['bytes'];return json.loads(raw)
def write(p,d):
 with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
def identity(p):
 s=os.lstat(p);assert stat.S_ISREG(s.st_mode)
 return dict(dev=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def main(argv=None):
 args=sys.argv[1:] if argv is None else argv;assert len(args)==2,'exact observation release path/hash required'
 release=bound(dict(path=args[0],sha256=args[1]));assert release['status']=='PASS_EXACT_ORDINARY_POSTBUILD_READONLY_RELEASE'
 review=bound(release['execution_review']);payload={k:v for k,v in release.items() if k!='execution_review'}
 assert review['decision']=='PASS_EXACT_ORDINARY_POSTBUILD_READONLY' and review['implementation_ownership'] is False and review['reviewer']!=release['author']
 assert review['reviewed_release_payload_sha256']==hashlib.sha256((json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
 for key in ['dispatcher','descriptor_facts_producer','actual_role_adapter']:assert digest(release[key]['path'])==release[key]['sha256']
 assert release['dispatcher']['path']==str(Path(__file__).resolve())
 plan=bound(release['commands']);copyplan=bound(release['copies']);profile=bound(release['profile']);tools=bound(release['tools']);artifacts=bound(release['actual_artifacts']);extra=bound(release['inspection_extra_artifacts'])
 assert set(artifacts)=={'cpu','process','rust','image'} and set(extra)=={'fallback'} and len(plan['operations'])==15
 assert release['operation_completion_contracts'].keys()=={str(i) for i in range(1,16)}
 assert not any(any(arg.startswith('--debug-dump') or arg=='-w' for arg in op['argv']) for op in plan['operations']),'historical fullDWARF13 replay excluded'
 completion={k:bound(v) for k,v in release['owner_completion'].items()}
 owner=completion['owner_receipt'];guard=completion['guard_result'];post=completion['postjoin_readback']
 assert owner['status']=='PASS' and owner['exit_code']==0 and owner['retired'] is True and owner['terminal_container_retained'] is True
 assert guard['retired'] is True and guard['retained_for_separate_cleanup'] is True and post['guard_direct_joined'] is True and post['root27_4_reacquired_after_join'] is True
 assert guard['owner_receipt_sha256']==post['owner_receipt_sha256']==release['owner_completion']['owner_receipt']['sha256']
 assert post['guard_result_sha256']==release['owner_completion']['guard_result']['sha256']
 assert owner['container_id']==guard['container_id']==post['container_id']==release['container_id']
 build_review=bound(release['actual_build_acceptance'])
 assert release['actual_build_acceptance']['sha256']=='f7352de9e6aaf2ed6de5928cbb94c55c7b2a2ca6a7598c9d79d2bc933e6dbf98'
 assert build_review['schema']=='mckernel.independent-new205-fresh-full-actual-build-and-client-retirement.v1' and build_review['decision']=='PASS_ACTUAL_FRESH_FULL_COMPILER_IMAGE_BUILD_AND_POSITIVE_CLIENT_RETIREMENT_ONLY' and build_review['implementation_ownership'] is False and build_review['reviewer']!=release['author']
 assert build_review['container_id']==release['container_id'] and build_review['request']==release['request'] and build_review['image']['sha256']==artifacts['image']['sha256'] and build_review['image']['size']==artifacts['image']['bytes']
 assert build_review['driver_receipt']==release['driver_receipt'] and build_review['owner_receipt']==release['owner_completion']['owner_receipt'] and build_review['guard_result']==release['owner_completion']['guard_result']
 assert bound(release['driver_receipt'])['status']=='PASS' and bound(release['driver_receipt'])['phase']=='complete'
 for row in tools.values():assert str(Path(row['path']).resolve())==row['resolved_path'] and digest(Path(row['path']))==row['sha256'] and identity(Path(row['path']).resolve())==row['identity']
 observed=dict(artifacts,**extra)
 def sourcecheck():
  for row in observed.values():assert identity(row['path'])=={k:row[k] for k in ['dev','inode','uid','gid','mode','bytes','mtime_ns','ctime_ns']}
 def capacitycheck(remaining):
  for label,path in [('host',Path('/home/holden')),('scratch',Path('/home/holden/mckernel-work/scratch'))]:
   cap=profile['fresh_admission'][label];fs=os.statvfs(path);minimum=cap['floor_bytes']+cap['emergency_bytes']+(remaining if label=='host' else 0);assert fs.f_bavail*fs.f_frsize>=minimum
 for p in profile['required_absent_paths']:assert not os.path.lexists(p),p
 sourcecheck();remaining=profile['absolute_total_output_cap_bytes'];capacitycheck(remaining);O.mkdir(mode=0o700);(O/'captures').mkdir(mode=0o700);results=[]
 # Exact accepted receipt schema and direct wait are preserved from FP producer.
 def run(argv,stdout,stderr,status_path,label,reservation,contract):
  nonlocal remaining
  assert reservation<=remaining;capacitycheck(remaining);sourcecheck()
  write(Path(str(status_path)+'.command.json'),dict(argv=argv,stage=label,reservation_bytes=reservation,release_sha256=args[1]))
  start=time.monotonic();observer_error=None
  with Path(stdout).open('xb') as out,Path(stderr).open('xb') as err:
   child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
   try:write(Path(str(status_path)+'.child.json'),dict(pid=child.pid,monotonic_start=start,proc_queries=False))
   except BaseException as ex:observer_error=dict(type=type(ex).__name__,error=str(ex))
   finally:code=child.wait()
  row=dict(stage=label,observer_error=observer_error,argv=argv,returncode=code,direct_child_joined=True,elapsed_seconds=time.monotonic()-start,stdout_bytes=Path(stdout).stat().st_size,stderr_bytes=Path(stderr).stat().st_size,stdout_sha256=digest(stdout),stderr_sha256=digest(stderr))
  write(Path(status_path),row);results.append(row)
  assert code==contract['returncode'] and observer_error is None,label
  if contract['stderr_policy']=='empty':assert row['stderr_bytes']==0,label
  if label.startswith('command-'):assert row['stdout_bytes']<reservation//2 and row['stderr_bytes']<reservation//2,label
  sourcecheck();remaining-=reservation
 copyargv=[release['actual_artifacts']['sha256'] if x=='ACTUAL_ARTIFACTS_SHA256_FROM_GENERATED_METADATA' else x for x in copyplan['argv']]
 run(copyargv,copyplan['captures']['stdout'],copyplan['captures']['stderr'],copyplan['captures']['status'],'fourcopy',32*2**20+2048,dict(returncode=0,stderr_policy='empty'))
 # First twelve are fixed; three followups are derived only from their completed captures.
 for op in plan['operations'][:12]:
  i=op['index'];run(op['argv'],op['stdout_path'],op['stderr_path'],op['status_path'],'command-'+str(i),op['both_stream_reservation_bytes'],release['operation_completion_contracts'][str(i)])
 import types
 api=release['descriptor_api'];assert api['sha256']=='380e4d8c7ac1360a2694a34cb037c748bdaa31948da7948686add983f5b825fe'
 raw=Path(api['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==api['sha256'];m=types.ModuleType('_actual_descriptor_api');m.__file__=api['path'];sys.path.insert(0,str(Path(api['path']).parents[1]));exec(compile(raw,api['path'],'exec'),m.__dict__)
 latepolicy=bound(release['late_binding_policy']);assert latepolicy['decision']=='PASS_EXACT_ACTUAL_READ_ELF_NDX_AND_RANGE_LATE_BINDING_ONLY' and latepolicy['implementation_ownership'] is False and latepolicy['reviewer']!=release['author']
 rust=[m.symbol_sections(Path(plan['operations'][8]['stdout_path']).read_text(),tag) for tag in m.DESCRIPTORS];image=[m.symbol_sections(Path(plan['operations'][11]['stdout_path']).read_text(),tag) for tag in m.DESCRIPTORS]
 assert rust[0]['ndx']!=rust[1]['ndx'] and image[0]['ndx']==image[1]['ndx'];start=min(r['address'] for r in image);assert sorted(r['address'] for r in image)==[start,start+32]
 for i in (13,14,15):
  op=plan['operations'][i-1];actual=(['/usr/bin/readelf','-x',str(rust[i-13]['ndx']),plan['paths']['rust']] if i<15 else ['/usr/bin/objdump','-s','--start-address='+hex(start),'--stop-address='+hex(start+64),plan['paths']['image']]);cut=op['argv'].index('--')+1;op['argv']=op['argv'][:cut]+actual;op['actual_artifact_argv']=actual;op.pop('mechanical_late_binding',None)
 plan['commands']=[op['argv'] for op in plan['operations']];write(O/'resolved15-command-plan.json',plan)
 # Root's independent policy pre-authorizes only these actual argv/data hash instantiations.
 final={k:v for k,v in release.items() if k!='execution_review'};final['commands']=dict(path=str(O/'resolved15-command-plan.json'),sha256=digest(O/'resolved15-command-plan.json'))
 for contract in final['operation_completion_contracts'].values():contract['receipt_execution_release_sha256']=args[1]
 record=dict(latepolicy['final_execution_review_literal_except_payload_hash']);record['reviewed_release_payload_sha256']=hashlib.sha256((json.dumps(final,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest();write(O/'resolved15-execution-review.json',record);final['execution_review']=dict(path=str(O/'resolved15-execution-review.json'),sha256=digest(O/'resolved15-execution-review.json'));write(O/'resolved15-release.json',final)
 for op in plan['operations'][12:]:
  i=op['index'];run(op['argv'],op['stdout_path'],op['stderr_path'],op['status_path'],'command-'+str(i),op['both_stream_reservation_bytes'],release['operation_completion_contracts'][str(i)])
 finalrelease=O/'resolved15-release.json';completionpath=O/'completed-command-receipt.json';write(completionpath,dict(status='PASS_EXACT_FOUR_COPY_AND15_DECLARED_COMPLETION_CONTRACTS_ONLY',results=results,release_sha256=digest(finalrelease),container_id=release['container_id'],original_full_DWARF_gap_open=True,production_or_native_acceptance=False))
 bindings=bound(release['facts_bindings_template']);bindings['plan']=dict(path=str(O/'resolved15-command-plan.json'),sha256=digest(O/'resolved15-command-plan.json'),bytes=(O/'resolved15-command-plan.json').stat().st_size);bindings['resolved_release']=dict(path=str(finalrelease),sha256=digest(finalrelease),bytes=finalrelease.stat().st_size);bindings['completion']=dict(path=str(completionpath),sha256=digest(completionpath),bytes=completionpath.stat().st_size)
 op11=plan['operations'][10];bindings['image_disassembly']=dict(path=op11['stdout_path'],sha256=digest(op11['stdout_path']),bytes=Path(op11['stdout_path']).stat().st_size)
 write(O/'actual-facts-bindings-PENDING-SOURCE-ASSOCIATION.json',bindings)
 factsargv=['/usr/bin/timeout','--signal=TERM','--kill-after=2s','35s','/usr/bin/taskset','-c','6','/usr/bin/prlimit','--as=1073741824','--cpu=30','--fsize=33554432','--','/home/holden/anaconda3/bin/python3','-I','-B',release['descriptor_facts_producer']['path'],'ACTUAL_COMPLETED_BINDINGS_PATH','ACTUAL_COMPLETED_BINDINGS_SHA256',str(O/'new205-mechanical-facts.json')]
 write(O/'next-facts-command-PENDING-SOURCE-ASSOCIATION.json',dict(argv=factsargv,required_remaining_field='independent_source_associations actual pinned new205 report; null refused',execution_authority=False))
 write(O/'postbuild-result.json',dict(status='PASS_EXACT_FOUR_COPY15_COMPLETION_ONLY_PENDING_SOURCE_ASSOCIATION',initial_release_sha256=args[1],resolved_release_sha256=digest(finalrelease),stages=len(results),artifact_copies=4,declared_commands=15,completed_receipt_sha256=digest(completionpath),original_full_DWARF_gap_open=True,cleanup_authorized=False,production_or_native_acceptance=False))
 print('PASS actualfourcopy+15 declareddirectcompletion receipts; sourceassociation/facts/retention/native pending')
if __name__=='__main__':main()
