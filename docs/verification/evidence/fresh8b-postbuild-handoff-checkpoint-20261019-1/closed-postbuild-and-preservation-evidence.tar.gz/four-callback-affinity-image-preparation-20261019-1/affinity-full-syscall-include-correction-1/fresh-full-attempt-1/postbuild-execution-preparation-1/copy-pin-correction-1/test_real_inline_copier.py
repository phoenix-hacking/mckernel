"""Disposable realinline copier regression; never copiesactualkernel artifacts."""
from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,tempfile
Q=Path(__file__).resolve().parent;P=Q.parent
plan=json.loads((Q/'exact-four-copy-command.json').read_bytes());argv=plan['argv'];pi=argv.index('/home/holden/anaconda3/bin/python3');ci=argv.index('-c',pi+1)+1;assert argv[argv.index('/usr/bin/taskset')+2]=='6' and ci==20
code=argv[ci];tree=ast.parse(code);pin=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pin' for t in n.targets));actualpin=ast.literal_eval(pin.value.args[0]);assert actualpin==str(P/'actual-artifacts.json')==plan['immutable_inputs']['path'];raw=Path(actualpin).read_bytes();assert hashlib.sha256(raw).hexdigest()==plan['immutable_inputs']['sha256'];assert set(json.loads(raw))=={'cpu','process','rust','image'}
# Exercise the exact consumed inline body with onlyits two pathliterals rebased
# to disposable synthetic files. FullFD/checks/copy/hash/mode logic is unchanged.
with tempfile.TemporaryDirectory(prefix='actual-inline-copy-path-regression-') as tmp:
 t=Path(tmp);rows={}
 for i,name in enumerate(['cpu','process','rust','image']):
  p=t/(name+'.source');p.write_bytes(('SYNTHETIC-'+name+'\n').encode());p.chmod(0o600 if i%2 else 0o644);s=p.stat();rows[name]=dict(path=str(p),dev=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=s.st_mode&4095,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 data=t/'artifacts.json';data.write_text(json.dumps(rows));sha=hashlib.sha256(data.read_bytes()).hexdigest();oldD=plan['destination']
 fixture=code.replace(actualpin,str(data)).replace(oldD,str(t/'positive'))
 good=subprocess.run([sys.executable,'-I','-B','-c',fixture,sha],capture_output=True,check=False);assert good.returncode==0 and good.stderr==b''
 result=json.loads((t/'positive/retention-result.json').read_bytes());assert result['status']=='PASS_EXACT_FOUR_ARTIFACT_RETENTION_ONLY' and len(result['artifacts'])==4
 for name,row in rows.items():assert (t/'positive'/(name+'.artifact')).read_bytes()==Path(row['path']).read_bytes() and ((t/'positive'/(name+'.artifact')).stat().st_mode&4095)==row['mode']
 badcode=code.replace(actualpin,str(data)).replace(oldD,str(t/'negative'));bad=subprocess.run([sys.executable,'-I','-B','-c',badcode,'0'*64],capture_output=True,check=False);assert bad.returncode==1 and not (t/'negative').exists() and b'AssertionError' in bad.stderr
 print(json.dumps({'status':'PASS_ACTUAL_INLINE_PYTHON_ARGV_PIN_AND_DISPOSABLE_COPIER_ONLY','positive':1,'negative':1,'synthetic_copies':4,'actual_artifact_copies':0,'python_code_index':ci,'taskset_cpu_unchanged':True,'wrong_pin_refused_before_mkdir':True,'actual15tools':0}))
