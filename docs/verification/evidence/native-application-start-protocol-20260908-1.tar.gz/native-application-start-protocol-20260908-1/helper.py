"""Pinned-container protocol checks with exact guest Rust bodies and C declarations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo = Path('/workspace')
out = Path('/work/native-application-start-protocol-20260908-' + sys.argv[1])
out.mkdir()
source = out / 'source'
fixture = source / 'scripts/tests/fixtures'
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    commands=[], extracted_bodies=[], production_gate_credit=False,
    scope='Native image decoder, page walk and traditional prepare/cleanup protocol; independent existing C and guest Rust image layouts and exact guest request/reply bodies, without a live transport')

def identity(path):
    raw=path.read_bytes()
    return dict(path=str(path),size=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def run(label, args):
    print('RUN',label,flush=True)
    with (out/(label+'.log')).open('wb') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode == 0, (label,(out/(label+'.log')).read_text()[-14000:])

def extract(path, pattern, name, semicolon=False):
    data=path.read_text()
    match=re.search(pattern,data,re.M); assert match,name
    start=match.start(); opening=data.index('{',start); end=opening+1; depth=1
    while depth:
        depth+=(data[end]=='{')-(data[end]=='}'); end+=1
    if semicolon:
        assert data[end]==';'; end+=1
    body=data[start:end]
    record['extracted_bodies'].append(dict(source=str(path.relative_to(source)),name=name,
        start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
    return body+'\n'

try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['scripts/tests/fixtures/native-application-retirement.rs','kernel/rust/lock_helpers.rs','host-kernel/native-rust/application_rpc.rs','kernel/rust/abi.rs',
        'kernel/rust/host_helpers.rs','kernel/include/syscall.h','ihk/ikc/include/ikc/queue.h',
        'scripts/tests/fixtures/native-application-protocol.rs',
        'scripts/tests/fixtures/native-application-layout.c',
        'host-kernel/native-rust/application_image.rs','executer/include/uprotocol.h','kernel/rust/object_helpers.rs',
        'scripts/tests/fixtures/native-application-image.rs','scripts/tests/fixtures/native-application-image-layout.c',
        'executer/user/mcexec.c','executer/user/rust/mcexec_helpers.rs','scripts/tests/fixtures/native-application-flat.c']
    for name in names:
        original=out/'original-inputs'/name; original.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(repo/name,original)
        target=source/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(original,target)
    record['inputs']=[identity(out/'original-inputs'/name) for name in names]
    host=source/'kernel/rust/host_helpers.rs'; data=host.read_text()
    generated='use crate::abi::*;\nuse core::{ffi::c_void,mem::size_of,ptr::write_volatile};\n'
    for name in ['EINVAL','SCD_MSG_CLEANUP_PROCESS_RESP','SCD_MSG_PREPARE_PROCESS_ACKED']:
        match=re.search(r'^const '+name+r':[^\n]+;',data,re.M); assert match,name
        generated+=match[0]+'\n'
    for name in ['HostPrepareProcessFn','HostIkcPacketSendFn','HostCleanupProcessFn','HostTerminateHostFn','HostCleanupProcessLogFn']:
        match=re.search(r'^pub type '+name+r'\b[^;]+;',data,re.M); assert match,name
        generated+=match[0]+'\n'
    for name in ['zero_ikc_scd_packet','host_ikc_packet_send_result','host_cleanup_process_result',
                 'host_cleanup_process_log_result','host_terminate_host_result',
                 'host_traditional_reply_result','host_cleanup_process_request_result',
                 'host_prepare_process_result','host_prepare_process_request_result']:
        generated+=extract(host,r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',name)
    (fixture/'native-application-guest-reference.rs').write_text(generated)
    extra='const EAGAIN: CInt = 11;\nconst SCD_MSG_CLEANUP_PROCESS: CInt = 9;\nunsafe extern "C" { fn get_this_cpu_local_var() -> *mut CpuLocalVar; }\n'
    for name in ['host_process_retirement_query_result','host_process_retirement_lookup_bridge','host_cleanup_process_request_bridge']:
        extra+=extract(host,r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',name)
    (fixture/'native-retirement-guest-reference.rs').write_text(extra)
    lock=extract(source/'kernel/rust/lock_helpers.rs',r'^pub struct McsRwlockNodeIrqsave \{','McsRwlockNodeIrqsave')
    (fixture/'native-retirement-lock-type.rs').write_text('use crate::abi::CULong;\n#[repr(C,align(64))]\n'+lock)

    objects=source/'kernel/rust/object_helpers.rs'; data=objects.read_text()
    generated='use crate::abi::*;\nuse core::{ffi::c_void,mem::size_of,ptr::{read_volatile,write_volatile}};\n'
    for name in ['EINVAL','SCD_MSG_PROCFS_TID_CREATE']:
        match=re.search(r'^const '+name+r':[^\n]+;',data,re.M); assert match,name
        generated+=match[0]+'\n'
    for name in ['ProcfsThreadPhysFn','ProcfsThreadSendFn','ProcfsThreadPauseFn']:
        match=re.search(r'^pub type '+name+r'\b[^;]+;',data,re.M); assert match,name
        generated+=match[0]+'\n'
    for name in ['zero_ikc_scd_packet','procfs_thread_ctl_result']:
        generated+=extract(objects,r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',name)
    (fixture/'native-application-procfs-reference.rs').write_text(generated)
    csource=source/'kernel/include/syscall.h'
    generated=extract(source/'ihk/ikc/include/ikc/queue.h',r'^struct ihk_ikc_packet_header \{','ihk_ikc_packet_header',True)
    for kind,name in [('struct','syscall_request'),('enum','mcctrl_os_cpu_operation'),('struct','ikc_scd_packet')]:
        generated+=extract(csource,r'^'+kind+' '+name+r' \{',name,True)
    messages=[]
    for name in ['SCD_MSG_CLEANUP_PROCESS','SCD_MSG_CLEANUP_PROCESS_RESP','SCD_MSG_PROCFS_TID_DELETE','SCD_MSG_SCHEDULE_PROCESS']:
        match=re.search(r'^#define '+name+r'\s+[^\n]+',csource.read_text(),re.M); assert match,name
        generated+=match[0]+'\n'; messages.append(match[0])
    (fixture/'native-application-c-reference.h').write_text(generated)
    (fixture/'native-application-c-messages.h').write_text('\n'.join(messages)+'\n')
    launcher=source/'executer/user/rust/mcexec_helpers.rs'
    generated='extern "C" { fn malloc(size: usize) -> *mut u8; pub fn free(pointer: *mut u8); }\n'
    for name in ['cstr_len','zero_bytes','copy_ptr_bytes','count_cstr_array','mcexec_flatten_strings_result']:
        generated+=extract(launcher,r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',name)
    (fixture/'native-application-flat-rust-reference.rs').write_text(generated)
    generated=extract(source/'executer/user/mcexec.c',r'^int flatten_strings\([^\n]+\)\n\{','flatten_strings')
    (fixture/'native-application-flat-c-reference.h').write_text(generated)
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',
        str(source/'host-kernel/native-rust/application_rpc.rs'),str(fixture/'native-application-protocol.rs'),
        str(source/'host-kernel/native-rust/application_image.rs'),str(fixture/'native-application-image.rs')])
    run('layout-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(fixture/'native-application-layout.c'),'-o',str(out/'layout')])
    run('layout',[str(out/'layout')])
    shutil.copyfile(out/'layout.log',fixture/'native-application-layout.txt')
    record['c_layout']=list(map(int,(out/'layout.log').read_text().split()))
    run('protocol-build',['rustc','--edition','2021','--test',str(fixture/'native-application-protocol.rs'),'-o',str(out/'protocol-tests')])
    run('protocol-tests',[str(out/'protocol-tests'),'--nocapture'])
    run('image-layout-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(fixture/'native-application-image-layout.c'),'-o',str(out/'image-layout')])
    run('image-layout',[str(out/'image-layout')])
    shutil.copyfile(out/'image-layout.log',fixture/'native-application-image-layout.txt')
    record['image_c_layout']=list(map(int,(out/'image-layout.log').read_text().split()))
    # Match the real launcher's Debug C selection; preserve the exact legacy
    # body and enforce every warning. The unrelated -O2 attempt is retained.
    run('launcher-flat-build',['gcc','-std=gnu11','-O0','-g','-Wall','-Wextra','-Werror',str(fixture/'native-application-flat.c'),'-o',str(out/'launcher-flat')])
    run('launcher-flat',[str(out/'launcher-flat')])
    shutil.copyfile(out/'launcher-flat.log',fixture/'native-application-flat-c.txt')
    record['actual_launcher_vectors']=6
    run('image-build',['rustc','--edition','2021','--test',str(fixture/'native-application-image.rs'),'-o',str(out/'image-tests')])
    run('image-tests',[str(out/'image-tests'),'--nocapture'])
    ctest = '#include <stdio.h>\n#include <string.h>\n#include "native-application-c-reference.h"\n' + r'''
static void emit(const char *tag, struct ikc_scd_packet *p) {
    printf("%s ",tag); for(unsigned i=0;i<sizeof(*p);++i)printf("%02x",((unsigned char *)p)[i]); puts("");
}
int main(void) {
    struct ikc_scd_packet p={0};p.msg=SCD_MSG_SCHEDULE_PROCESS;p.reply=7;p.ref=2;p.osnum=3;p.pid=723;p.arg=0xffff880012345000UL;emit("SCHEDULE",&p);
    p.msg=SCD_MSG_CLEANUP_PROCESS;p.arg=0;memcpy(&p.resp_pa,"MCRQ0001",8);emit("QUERY",&p);
    p.msg=SCD_MSG_CLEANUP_PROCESS_RESP;memcpy(&p.resp_pa,"MCRE0001",8);emit("ABSENT",&p);
    p.err=-11;emit("PRESENT",&p);p.err=0;p.resp_pa=0;p.pid=0;p.osnum=0;emit("LEGACY",&p);return 0;
}
'''
    (fixture/'native-retirement-c.c').write_text(ctest)
    run('retirement-c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(fixture/'native-retirement-c.c'),'-o',str(out/'retirement-c')])
    run('retirement-c',[str(out/'retirement-c')])
    shutil.copyfile(out/'retirement-c.log',fixture/'native-retirement-c.txt')
    run('retirement-format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(fixture/'native-application-retirement.rs')])
    run('retirement-build',['rustc','--edition','2021','-D','warnings','--cfg','native_linux_irq_work_v6_12','--test',str(fixture/'native-application-retirement.rs'),'-o',str(out/'retirement-tests')])
    run('retirement-tests',[str(out/'retirement-tests'),'--test-threads=1','--nocapture'])
    record.update(start_wire_and_retirement_tests=7,old_protocol_and_image_tests_preserved=True,native_dispatch_and_lookup_bodies_tested=True)
    record['compiler_inputs']=[identity(p) for p in sorted(source.rglob('*')) if p.is_file()]
    for row in record['inputs']+record['compiler_inputs']: assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json']
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
