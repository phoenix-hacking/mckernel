from pathlib import Path
import gzip,hashlib,json,os,subprocess
repo=Path('/workspace');work=Path('/work')
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
records=['native-startup-tables-checkpoint-20260907.json','native-startup-staging-integration-20260907.json','native-startup-exact-stage-checkpoint-20260907.json']
checked=[];references=[]
def identity(row,compressed=False):
 path=repo/row['path'];data=path.read_bytes()
 if len(data)!=row['size'] or hashlib.sha256(data).hexdigest()!=row['sha256']: raise SystemExit('Retained bytes differ: '+row['path'])
 if compressed:
  raw=gzip.decompress(data)
  if len(raw)!=row['uncompressed_size'] or hashlib.sha256(raw).hexdigest()!=row['uncompressed_sha256']: raise SystemExit('Retained gzip round-trip differs: '+row['path'])
for name in records:
 record=json.loads((repo/'docs/verification'/name).read_text())
 if record.get('production_gate_credit') is not False or record.get('native_mckernel_boot_proven') is not False: raise SystemExit('Invalid checkpoint scope')
 for row in record['artifacts']:
  identity(row,True);checked.append(row['path'])
 for row in record.get('references',[]):
  identity(row);references.append(row['path'])
 if 'prototype' in record:
  identity(record['prototype']);references.append(record['prototype']['path'])
subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
result=dict(status='PASS',artifacts=len(checked),unique_artifacts=len(set(checked)),references=len(references),gzip_roundtrips_verified=True,production_gate_credit=False)
out=work/'native-startup-retained-evidence-checks-20260907.json'
with out.open('x') as stream: stream.write(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result),flush=True)
