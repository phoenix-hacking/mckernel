from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shutil
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
work=Path('/work');repo=Path('/workspace');out=work/'stability-permanent-physical-comparison-20260913-1';out.mkdir()
guest=work/'stability-transport-fault-guest-20260913-permanent-backpressure-2'
r=dict(status='RUNNING',scope='Actual permanent guest2 retained physical comparisons after complete native deadline/owner/phase collection; independent acceptance review still required',inputs=[],application_acceptance=False,transport_acceptance=False,production_gate_credit=False,started_utc=datetime.now(timezone.utc).isoformat())
def identity(p):
 d=p.read_bytes();return dict(path=str(p),size=len(d),sha256=hashlib.sha256(d).hexdigest())
def save():(out/'record.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
def bound(row):
 p=Path(row['path']);assert p.is_relative_to(guest),p
 assert identity(p)==row,p
 r['inputs'].append(row);return p.read_bytes()
try:
 shutil.copyfile(__file__,out/'helper.py')
 modules={}
 for name,sha in [('physical_observations.py','bf343ff9b3e59e2b92cf6481b6b181e45e9204afed5dfaf8ded4e7b063a0460a'),('owner_observations.py','97466f94dff53fc250509859d164a9858a4f361405ad62b82bb59ab621f77bcf')]:
  src=repo/'scripts/application-tests'/name;assert identity(src)['sha256']==sha
  target=out/name;shutil.copyfile(src,target);r['inputs'].append(identity(target))
  spec=importlib.util.spec_from_file_location(name,target);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[name]=module
 phy=modules['physical_observations.py'];owner=modules['owner_observations.py']
 record=owner.load_json((guest/'record.json').read_bytes());assert record['status']=='COLLECTED_REQUIRES_CONTRACT_REVIEW' and record['mode']=='permanent-backpressure'
 assert record['qemu_exit_code']==0 and not record['cleanup_errors'] and record['export_thread_finished']
 r['original_guest_record']=identity(guest/'record.json');r['native_phase_contract']=identity(guest/'native-phase-contract.json');r['collection_status']=record['status']
 raw=(guest/'native-dmesg.canonical.bin').read_bytes();observed=owner.parse_observations(raw)
 assert owner.load_json((guest/'owner-observations.json').read_bytes())==observed
 r['inputs'] += [identity(guest/'native-dmesg.canonical.bin'),identity(guest/'owner-observations.json')]
 snaps=observed['snapshots'];assert [s['phase'] for s in snaps]==['BlockedRead','AcceptedReturn','Terminal','TerminalPlusFive']
 selected=snaps[0]['selection'];tid=owner.original_worker(snaps[0])
 delivery=next(row['row'] for row in snaps[0]['records'] if row['kind']=='DELIVERY' and row['application']==selected['application'] and row['row']['serial']==selected['delivery'])
 request={k:delivery[k] for k in ('cpu','pid','requester','target','number','response','arguments')}
 recovered=owner.load_json((guest/'qmp-recovery.json').read_bytes());responses=[];sends=[]
 for seq,(entry,phase) in enumerate(zip(record['phase_captures'],['PRE_INPUT','POST_RET','QUIET']),1):
  req=entry['request'];assert req['kind']=='REQ' and req['phase']==phase and req['sequence']==seq
  assert req['nonce']==record['nonce'] and (req['tgid'],req['tid'])==(selected['pid'],tid)
  manifest=owner.load_json(bound(entry['manifest']));assert manifest['request']==req and manifest['continued'] is True
  recovery=manifest['recovery'];assert recovery in recovered and recovery['resume_verified'] is True
  assert set(recovery)=={'started_monotonic','pause_confirmed_monotonic','finished_monotonic','resume_verified'}
  directory=Path(entry['manifest']['path']).parent
  captures=[c for c in record['captures'] if c['directory']==str(directory)];assert len(captures)==1
  cap=captures[0];assert cap['owner']==dict(slot=selected['os'],generation=selected['generation'])
  for row in manifest['artifacts']:bound(row)
  descriptor=owner.load_json((directory/'selected-response.json').read_bytes());assert descriptor['selection']==selected and descriptor['host_post_release_read'] is False
  response=bound(descriptor['artifact']);responses.append(response)
  queue=next(q for q in cap['queues'] if q['port']==501 and q['direction']=='send')
  sends.append((directory/'control-501-send.bin').read_bytes())
  assert len(sends[-1])==queue['bytes']==16384
  if seq==1:
   original_queue=next(q for q in cap['queues'] if q['port']==503 and q['direction']=='receive')
   r['request_ring_binding']=phy.locate_consumed_request((directory/'control-503-receive.bin').read_bytes(),request)
   r['queue_physical_addresses']=dict(send501=queue['physical'],receive503=original_queue['physical'])
  else:assert queue['physical']==r['queue_physical_addresses']['send501']
 assert len(record['phase_captures'])==len(responses)==3
 r['response_comparison']=phy.compare_hard_response(*responses,worker_tid=tid)
 r['wake_publication_comparisons']=[phy.no_new_requester_wake(a,b,selected['requester']) for a,b in zip(sends,sends[1:])]
 a,b=map(owner.inventory_projection,snaps[-2:]);r['terminal_inventory_sizes']=[len(a),len(b)]
 r['terminal_inventory_differences']=[dict(index=i,terminal=x,plus_five=y) for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 r['ret']=observed['ret'];r['selected_counters']=[s['counters'] for s in snaps]
 assert len(a)==len(b) and a==b
 r['status']='PHYSICAL_COMPARISONS_MATCH_REQUIRES_INDEPENDENT_REVIEW'
except BaseException as e:r.update(status='FAIL',error_type=type(e).__name__,error=str(e));raise
finally:r['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(r['status'],out,flush=True)
