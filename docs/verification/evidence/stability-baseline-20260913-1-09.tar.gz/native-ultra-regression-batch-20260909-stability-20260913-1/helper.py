from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
work=Path('/work');attempt=sys.argv[1];out=work/('native-ultra-regression-batch-20260909-'+attempt);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],children=[],module_attempt='1',image_attempt='3')
try:
 (out/'helper.py').write_bytes(Path(__file__).read_bytes())
 rows=[(['python3','-B','/work/run-native-ultra-baseline.py',case,'1','3',attempt],work/('native-ultra-baseline-'+case+'-guest-20260909-'+attempt)) for case in ['files','threads','signals']]
 rows += [(['python3','-B','/work/run-native-ultra-control-'+kind+'.py',arch,'1','3',attempt],work/('native-ultra-control-'+kind+'-20260909-'+arch+'-'+attempt)) for kind,arch in [('regression','x86_64'),('compat','i386')]]
 for command,directory in rows:
  print('BATCH RUN',directory,flush=True);assert not directory.exists()
  p=work/Path(command[2]).name;raw=p.read_bytes();(out/p.name).write_bytes(raw)
  record['commands'].append(dict(command=command,helper_sha256=hashlib.sha256(raw).hexdigest()))
  result=subprocess.run(command,timeout=700);record['commands'][-1]['exit_code']=result.returncode
  assert result.returncode==0,(command,result.returncode,str(directory))
  state=json.loads((directory/'record.json').read_text());assert state['status']=='PASS' and state.get('qemu_exit_code')==0
  record['children'].append(dict(path=str(directory),status=state['status'],record_sha256=hashlib.sha256((directory/'record.json').read_bytes()).hexdigest()))
  (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 record['status']='PASS'
except BaseException as e:record.update(status='FAIL',error=str(e));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
