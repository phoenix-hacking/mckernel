"""Retain exact native procfs VFS owner and actual Linux guest rundown evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-procfs-objects-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-procfs-objects-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],compiler_bindings=[],
    scope='Actual native Linux procfs publication, per-open I/O and callback rundown. Separate verification module; no native guest procfs service, START or application execution.',
    native_vfs_adapter_verified=True,production_smp_selected=False,procfs_guest_service_integrated=False,
    mckernel_application_executed=False,declared_stage_integrated=False,production_gate_credit=False,
    independent_acceptance=False,original_failures_in_this_batch=0)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    prior=repo/'docs/verification/native-application-mailbox-checkpoint-20260908.json'
    assert json.loads(prior.read_text())['status']=='PASS'
    row=identity(prior);row['path']=str(prior.relative_to(repo));record['references'].append(row)
    captures=['native-procfs-objects-module-20260908-1','native-procfs-objects-guest-20260908-1']
    for name in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']=='PASS'
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status='PASS',complete_capture_retained=True,archive_exclusions={}))
    compiled=work/captures[0];guest=work/captures[1]
    state=json.loads((compiled/'record.json').read_text())
    for row in state['compiler_inputs']:
        relative=Path(row['path']).relative_to(compiled/'source')
        record['compiler_bindings'].append(binding(repo/relative,compiled/'source'/relative))
    assert len(record['compiler_bindings'])==4
    assert (compiled/'c-layout.bin').read_bytes()==(compiled/'rust-layout.bin').read_bytes()
    assert len(state['layout'])==27 and state['layout'][:14]==[96,8,0,8,16,24,32,40,48,56,64,72,80,88]
    record['linux_c_rust_layout']=state['layout']
    record['guest_binary_bindings']=[]
    for source,destination in [(compiled/'mckernel_procfs_objects_verify.ko',guest/'root/modules/mckernel_procfs_objects_verify.ko'),(compiled/'native-procfs-objects',guest/'root/bin/native-procfs-objects')]:
        left,right=identity(source),identity(destination)
        assert (left['sha256'],left['size'])==(right['sha256'],right['size'])
        record['guest_binary_bindings'].append(dict(compiled=left,guest=right))
    state=json.loads((guest/'record.json').read_text())
    assert state['status']=='PASS' and state['qemu_exit_code']==0
    assert state['session_counts']==[[1039,1039,1039],[1039,1039,1039]]
    assert state['module_cycles']==2 and state['namespace_races']==32
    assert state['concurrent_reads']==state['concurrent_writes']==1024
    assert state['copy_faults']==4 and state['failed_opens']==2 and state['partial_read_bytes']==16384
    record['guest_results']={key:state[key] for key in ['cpus','memory_mib','container_memory_mib','cpuset','session_counts','drain_milliseconds','module_cycles','namespace_races','concurrent_reads','concurrent_writes','copy_faults','failed_opens','partial_read_bytes','removed_read_errno','removed_seek_errno','qemu_exit_code']}
    record['guest_results'].update(joined_namespace_workers=64,terminated='QMP quit after two completed module unloads and guest PASS',actual_guest_syscall_service=False)
    references=out/'project-reference';references.mkdir()
    record['retained_existing_procfs_sources']=[]
    for name in ['executer/kernel/mcctrl/rust/mcctrl_helpers.rs','executer/kernel/mcctrl/procfs.c',
                 'kernel/rust/object_helpers.rs','kernel/rust/abi.rs','kernel/procfs.c','kernel/include/syscall.h']:
        saved=references/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,saved)
        record['retained_existing_procfs_sources'].append(binding(repo/name,saved))
    record['unchanged_actual_guest_peer_bindings']=[]
    for name in ['kernel/rust/object_helpers.rs','kernel/rust/abi.rs','kernel/procfs.c','kernel/include/syscall.h']:
        record['unchanged_actual_guest_peer_bindings'].append(binding(repo/name,work/'mckernel-native-sysfs-images-20260908-2/source'/name))
    record['pinned_linux_sources']=[]
    for saved in sorted((compiled/'linux-reference').rglob('*')):
        if not saved.is_file():continue
        name=saved.relative_to(compiled/'linux-reference')
        original=work/'native-source/linux-6.12.0-211.44.1.el10_2'/name
        assert original.read_bytes()==saved.read_bytes()
        record['pinned_linux_sources'].append(dict(original=identity(original),retained=identity(saved)))
    assert len(record['pinned_linux_sources'])==7
    artifact(references,'native-procfs-objects-20260908-project-reference.tar.gz',True)
    for name in ['build-native-procfs-objects.py','run-native-procfs-objects-guest.py']:
        artifact(work/name,'native-procfs-objects-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-procfs-objects-20260908-retain-helper.py.gz')
    record.update(status='PASS',complete_captures=2,artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
