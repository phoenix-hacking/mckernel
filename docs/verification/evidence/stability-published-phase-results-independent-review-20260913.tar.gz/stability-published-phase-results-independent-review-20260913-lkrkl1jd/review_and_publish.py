from pathlib import Path
import base64
import hashlib
import json
import re
import shutil
import stat
import tarfile

OUT=Path(__file__).resolve().parent
REPO=Path('/home/holden/mckernel')
ATTEMPT=Path('/home/holden/mckernel-work/scratch/stability-published-phase-tests-20260913-1')
SCRATCH=Path('/home/holden/mckernel-work/scratch')
SOURCE_REVIEW=Path('/tmp/stability-published-phase-independent-review-20260913-xz1o70sr')

def identity(data):return {'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def inventory(root):
    rows=[]
    for path in [root]+sorted(root.rglob('*')):
        mode=path.lstat().st_mode
        row={'name':root.name if path==root else root.name+'/'+path.relative_to(root).as_posix(),'mode':stat.S_IMODE(mode)}
        if stat.S_ISDIR(mode):row.update(type='directory',size=0)
        elif stat.S_ISREG(mode):row.update(type='regular',**identity(path.read_bytes()))
        else:raise ValueError('unexpected special input '+str(path))
        rows.append(row)
    return rows

copied=[]
for original in [ATTEMPT,SOURCE_REVIEW]:
    before=inventory(original);destination=OUT/'captures'/original.name
    shutil.copytree(original,destination)
    assert inventory(original)==before==inventory(destination)
    copied.append({'original':str(original),'retained':str(destination.relative_to(OUT)),
                   'members':before,'verified_bytes_types_modes_membership':True})
for name in ['check-published-phases.py','check-published-phases.log']:
    src=SCRATCH/'stability-20260913-1'/name;target=OUT/name;shutil.copy2(src,target)
    assert src.read_bytes()==target.read_bytes()
assert (OUT/'check-published-phases.py').read_bytes()==(ATTEMPT/'helper.py').read_bytes()
assert (OUT/'check-published-phases.log').read_bytes()==b'PASS_SYNTHETIC_PUBLISHED_HOLD_PARSER_ONLY /work/stability-published-phase-tests-20260913-1\n'
r=json.loads((ATTEMPT/'record.json').read_text())
assert r['status']=='PASS_SYNTHETIC_PUBLISHED_HOLD_PARSER_ONLY' and r['cases']==13
assert all(r[k] is False for k in ('application_acceptance','transport_acceptance','guest_execution'))
verified=[]
for row in r['inputs']:
    original=row['original'];retained=row['retained'];path=SCRATCH/retained['path'][len('/work/'):]
    assert identity(path.read_bytes())=={k:retained[k] for k in ('size','sha256')}=={k:original[k] for k in ('size','sha256')}
    rel=original['path'][len('/workspace/'):]
    if 'supervisor.py' not in rel:
        expected=SOURCE_REVIEW/('final-reviewed' if 'published_phase' in rel else 'first-reviewed')/rel
        assert path.read_bytes()==expected.read_bytes()
    else:assert path.read_bytes()==(ATTEMPT/'supervisor.py').read_bytes()
    verified.append(row)
c=r['collection'];request=json.loads((ATTEMPT/'collection/request.json').read_text())
assert c==json.loads((ATTEMPT/'collection/report.json').read_text())
assert c['argv']==request['argv']==r['command'] and c['env']==request['env']==r['environment']
assert c['status']=='COMPLETED' and type(c['raw_wait_status']) is int and c['raw_wait_status']==0
assert c['wait_status']=={'kind':'exited','code':0} and c['cleanup_complete'] is True
assert c['descendants']==[] and c['descendant_records_omitted']==0 and (ATTEMPT/'collection/worker.stderr').read_bytes()==b''
assert c['payload_monotonic_started']<=c['payload_completion_observed_monotonic']<c['payload_monotonic_deadline']
assert c['monotonic_finished']<c['payload_monotonic_deadline']+c['cleanup_timeout_seconds']
for name in ('stdout','stderr'):
    stream=c['streams'][name];data=(ATTEMPT/f'collection/{name}.bin').read_bytes()
    assert stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes']==0
    assert stream['bytes_observed']==stream['bytes_retained']==len(data)<=stream['limit_bytes']
    assert identity(data)=={k:stream['artifact'][k] for k in ('size','sha256')}
source=(ATTEMPT/'scripts/tests/test_published_phase_observations.py').read_text()
tests=sorted(re.findall(r'^    def (test_\w+)\(',source,re.M));assert len(tests)==13
stderr=(ATTEMPT/'collection/stderr.bin').read_text()
expected=''.join(f'{name} (__main__.PublishedPhaseTests.{name}) ... ok\n' for name in tests)
assert stderr.startswith(expected)
assert re.fullmatch(r'\n-+\nRan 13 tests in [0-9]+\.[0-9]+s\n\nOK\n',stderr[len(expected):])
stdout=(ATTEMPT/'collection/stdout.bin').read_text().splitlines()
assert len(stdout)==2
for line,prefix in zip(stdout,['PHASE_TEST_EVIDENCE ','PUBLISHED_PHASE_TEST_EVIDENCE ']):
    assert line.startswith(prefix)
    path=SCRATCH/line[len(prefix):][len('/work/'):]
    assert path.parent==ATTEMPT/'tmp' and path.is_dir()
results=[]
for path in sorted((ATTEMPT/'tmp').rglob('*checked.json')):
    value=json.loads(path.read_text());raw=path.with_suffix('.bin').read_bytes();lines=raw.splitlines(keepends=True)
    assert value['status']=='NATIVE_PUBLISHED_HOLD_METADATA_ONLY'
    assert all(value[k] is False for k in ('application_acceptance','transport_acceptance','physical_accepted_return_capture_verified','production_gate_credit','physical_full_ring_verified'))
    phases=value['phase_observations'];original=value['original_phase_comparison']
    for parsed in (phases,original['phase_observations']):
        assert base64.b64decode(parsed['raw']['base64'],validate=True)==raw
        assert {k:parsed['raw'][k] for k in ('size','sha256')}==identity(raw)
        assert len(parsed['snapshots'])==4
    hold=phases['published_hold'];assert hold['release']['capture_sha256']=='efcdab8967452301'*4
    for row in hold['counts']+[hold['ready'],hold['release']]:
        assert row['raw_sha256']==identity(lines[row['line']-1])['sha256']
    assert [row['stage'] for row in hold['counts']]==[1,4,3,3]
    assert [row['host_hold_calls'] for row in hold['counts']]==[0,0,5,5] and hold['ready']['host_hold_calls']==0
    assert hold['publication_timer_seconds']==3
    assert hold['release']['begin_ns']==3450000000 and hold['release']['end_ns'] in (3460000000,3700000000,6100000000)
    results.append({'path':str(path),**identity(path.read_bytes()),'raw':identity(raw),
                    'mode':phases['mode'],'release_end_ns':hold['release']['end_ns']})
assert len(results)==4
assert sorted(r['release_end_ns'] for r in results)==[3460000000,3460000000,3700000000,6100000000]
review={'schema_version':1,'status':'PASS_INDEPENDENT_RETAINED_SYNTHETIC_PHASE_RESULTS_REVIEW',
        'scope':'Existing pinned13-test native-log parser run only, with complete raw/source/negative fixture retention. No rerun or subject import by reviewer.',
        'actual_record':{'path':str(ATTEMPT/'record.json'),**identity((ATTEMPT/'record.json').read_bytes())},
        'source_review':identity((SOURCE_REVIEW/'review-final.json').read_bytes()),
        'verified_source_bindings':verified,'actual_test_names':tests,'actual_completed_positive_reports':results,
        'capture_inputs':copied,'raw_wait_status':0,'streams_complete':True,'owned_cleanup_complete':True,
        'positive_raw_and_hold_line_hashes_independently_joined':True,
        'limitations':['Negative raw variants and original fixtures are retained; expected exception assertions are evidenced by exact reviewed test source and actual unittest results, not rerun by this lane.',
                       'Original pinned Python executable hash is retained but container-only bytes were not reopened; no full toolchain identity freshness claim.',
                       'No actual native owner/response/ring, ioctl, UART/QMP or guest behavior is supplied by these synthetic logs.',
                       'Both published transport fault gates, mode3 eight HELLO provenance, catalog execution and whole-OS acceptance remain separate required work.'],
        'reviewer_subject_execution':False,'application_acceptance':False,'transport_acceptance':False,'guest_execution':False}
(OUT/'review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
archive=REPO/'docs/verification/evidence/stability-published-phase-results-independent-review-20260913.tar.gz'
sidecar=REPO/'docs/verification/stability-published-phase-results-independent-review-20260913.json'
assert not archive.exists() and not sidecar.exists()
members=inventory(OUT)
with tarfile.open(archive,'w:gz') as stream:
    for row in members:
        local=OUT if row['name']==OUT.name else OUT/Path(row['name']).relative_to(OUT.name)
        stream.add(local,arcname=row['name'],recursive=False)
with tarfile.open(archive,'r:gz') as stream:
    actual=[]
    for member in stream.getmembers():
        row={'name':member.name,'mode':member.mode}
        if member.isdir():row.update(type='directory',size=0)
        elif member.isfile():row.update(type='regular',**identity(stream.extractfile(member).read()))
        else:raise ValueError('unexpected archive member type')
        actual.append(row)
    assert actual==members
assert inventory(OUT)==members
manifest={'schema_version':1,'status':review['status'],'scope':review['scope'],
          'review':{'member':OUT.name+'/review.json',**identity((OUT/'review.json').read_bytes())},
          'archive':{'path':str(archive.relative_to(REPO)),**identity(archive.read_bytes()),'members':members,'verified_exact_bytes_types_modes_membership':True},
          'actual_test_count':13,'reviewer_subject_execution':False,'application_acceptance':False,'transport_acceptance':False,'guest_execution':False}
sidecar.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'sidecar':str(sidecar),**identity(sidecar.read_bytes()),'archive_sha256':manifest['archive']['sha256'],
                  'archive_bytes':manifest['archive']['size'],'members':len(members),'review_sha256':manifest['review']['sha256']},indent=2))
