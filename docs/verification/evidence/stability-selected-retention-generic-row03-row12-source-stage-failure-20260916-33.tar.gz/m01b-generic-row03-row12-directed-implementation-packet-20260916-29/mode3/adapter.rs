#![allow(dead_code)]

#[cfg(test)]
pub(crate) mod fixture {
    use std::ptr::NonNull;
    use std::sync::{Arc, Mutex};
    #[derive(Clone, Copy, Debug, Eq, PartialEq)]
    pub enum Event { Construct, Baseline, StatusStore, Release, Deferred,
        FinishedDrop, UnfinishedDrop, Quarantine, Deallocate }
    pub struct State { pub deferred: Vec<Box<AlignedBacking>>, pub quarantine: Vec<Box<AlignedBacking>>, pub events: Vec<Event> }
    pub struct Ledger { pub state: Mutex<State> }
    impl Ledger { pub fn new() -> Arc<Self> { Arc::new(Self { state: Mutex::new(State {
        deferred: Vec::with_capacity(1), quarantine: Vec::with_capacity(1), events: Vec::with_capacity(9) }) }) }
        pub fn record(&self, e: Event) { self.state.lock().unwrap().events.push(e); }
        pub fn snapshot(&self) -> Vec<Event> { self.state.lock().unwrap().events.clone() }
        pub fn drain(&self, quarantine: bool) { let batch = { let mut s = self.state.lock().unwrap();
            if quarantine { std::mem::take(&mut s.quarantine) } else { std::mem::take(&mut s.deferred) } };
            let n = batch.len(); drop(batch); for _ in 0..n { self.record(Event::Deallocate); } }
    }
    #[repr(align(8))] pub struct AlignedBacking { pub bytes: [u8; 56] }
    pub struct TestResponseMemory { pub backing: Option<Box<AlignedBacking>>, span: NonNull<u8>, pub ledger: Arc<Ledger>, released: bool }
    impl TestResponseMemory { pub fn new(ledger: Arc<Ledger>) -> Self { let mut backing = Box::new(AlignedBacking { bytes: [0; 56] });
        let span = NonNull::new(unsafe { backing.bytes.as_mut_ptr().add(8) }).unwrap(); ledger.record(Event::Construct);
        Self { backing: Some(backing), span, ledger, released: false } }
        pub fn preparation_baseline(&self) { self.ledger.record(Event::Baseline); }
        pub fn verification_owner(&self) -> crate::stability_observer::Claim { crate::stability_observer::Claim { os: 1, generation: 1,
            response: crate::stability_observer::Tag { index: 0, serial: Some(1), physical: 0x1000, end: 0x1028 }, payload: None } }
    }
    unsafe impl super::ResponseMemory for TestResponseMemory { fn physical(&self) -> u64 { 0x1000 }
        fn address(&mut self) -> *mut u8 { self.span.as_ptr() }
        unsafe fn release(mut self) { if self.released { return; } self.released = true; self.ledger.record(Event::StatusStore);
            self.ledger.record(Event::Release); let b = self.backing.take().unwrap(); self.ledger.state.lock().unwrap().deferred.push(b); self.ledger.record(Event::Deferred); } }
    impl Drop for TestResponseMemory { fn drop(&mut self) { if self.released { self.ledger.record(Event::FinishedDrop); } else {
        let b = self.backing.take().unwrap(); self.ledger.state.lock().unwrap().quarantine.push(b); self.ledger.record(Event::UnfinishedDrop); self.ledger.record(Event::Quarantine); } } }
    pub fn request() -> crate::application_rpc::Request { let mut b = [0u8; 128];
        for (at, value) in [(8,4i32.to_le_bytes().to_vec()), (24,0i32.to_le_bytes().to_vec()), (32,70i32.to_le_bytes().to_vec()),
            (48,70i32.to_le_bytes().to_vec()), (52,0i32.to_le_bytes().to_vec()), (56,1u64.to_le_bytes().to_vec()),
            (80,0x2000u64.to_le_bytes().to_vec()), (88,16u64.to_le_bytes().to_vec()), (120,0x1000u64.to_le_bytes().to_vec())] { b[at..at+value.len()].copy_from_slice(&value); }
        crate::application_rpc::Request::decode(&b).expect("packet29 request") }
}
