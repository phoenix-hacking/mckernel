#![allow(dead_code)]
#[path = "source/application_rpc.rs"] mod application_rpc;
#[path = "source/application_syscall.rs"] mod application_syscall;
#[path = "source/smp_application_syscall.rs"] mod smp_application_syscall;
#[path = "source/stability_observer.rs"] mod stability_observer;
#[path = "source/stability_phase.rs"] mod stability_phase;
#[path = "adapter.rs"] mod adapter;

#[cfg(test)]
mod scenarios {
    use super::adapter::fixture::{request, Ledger, TestResponseMemory};
    pub fn row03() {
        let ledger = Ledger::new();
        let memory = TestResponseMemory::new(ledger.clone());
        let request = request();
        let mailbox = super::smp_application_syscall::Mailbox::<TestResponseMemory>::new();
        let worker = mailbox.open_worker(71).expect("worker");
        let handle = worker.admit(request, move |_| Ok(memory)).expect("admit");
        let handle = handle.reserve().expect("reserve");
        let handle = handle.copied(1, true).expect("copied");
        let _ = mailbox.verification_read16(Some(70), 42);
        let _ = mailbox.return_value(handle, 1, 0, 16, |_| Ok(()));
        let _ = mailbox.verification_phase_completion(1);
        assert_eq!(mailbox.publish(0, |_| Ok(())), Err(-11));
        assert_eq!(ledger.snapshot().len(), 2);
    }
    pub fn row12() {
        let ledger = Ledger::new();
        let memory = TestResponseMemory::new(ledger.clone());
        let request = request();
        let mailbox = super::smp_application_syscall::Mailbox::<TestResponseMemory>::new();
        let worker = mailbox.open_worker(71).expect("worker");
        let handle = worker.admit(request, move |_| Ok(memory)).expect("admit");
        let handle = handle.reserve().expect("reserve");
        let handle = handle.copied(1, true).expect("copied");
        let _ = mailbox.verification_read16(Some(70), 42);
        let _ = mailbox.return_value(handle, 1, 0, 16, |_| Ok(()));
        let _ = mailbox.verification_phase_completion(1);
        assert_eq!(mailbox.publish(0, |_| Ok(())), Ok(true));
        ledger.drain(false);
    }
    pub fn ktime_get() -> i64 { 2_000_000_000 }
}
