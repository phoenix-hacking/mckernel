#![allow(dead_code)]

#[cfg(test)]
pub(crate) mod fixture {
    use std::ptr::NonNull;
    use std::sync::{Arc, Mutex};

    #[derive(Clone, Copy, Debug, Eq, PartialEq)]
    pub enum Event { Construct, Baseline, StatusStore, Release, Deferred,
        FinishedDrop, UnfinishedDrop, Quarantine, Deallocate }
    #[derive(Default)]
    pub struct State {
        pub deferred: Vec<Box<AlignedBacking>>,
        pub quarantine: Vec<Box<AlignedBacking>>,
        pub events: Vec<Event>,
    }
    pub struct Ledger { pub state: Mutex<State> }
    impl Ledger {
        pub fn new() -> Arc<Self> { Arc::new(Self { state: Mutex::new(State {
            deferred: Vec::with_capacity(1), quarantine: Vec::with_capacity(1),
            events: Vec::with_capacity(9),
        }) }) }
        pub fn record(&self, event: Event) { self.state.lock().unwrap().events.push(event); }
        pub fn snapshot(&self) -> Vec<Event> { self.state.lock().unwrap().events.clone() }
        pub fn drain_deferred(&self) { let batch = {
            let mut state = self.state.lock().unwrap(); std::mem::take(&mut state.deferred)
        }; let count = batch.len(); drop(batch);
            for _ in 0..count { self.record(Event::Deallocate); } }
        pub fn drain_quarantine(&self) { let batch = {
            let mut state = self.state.lock().unwrap(); std::mem::take(&mut state.quarantine)
        }; let count = batch.len(); drop(batch);
            for _ in 0..count { self.record(Event::Deallocate); } }
    }
    #[repr(align(8))]
    pub struct AlignedBacking { pub bytes: [u8; 56] }
    pub struct TestResponseMemory {
        pub backing: Option<Box<AlignedBacking>>, span: NonNull<u8>,
        physical: u64, pub ledger: Arc<Ledger>, released: bool,
    }
    impl TestResponseMemory {
        pub fn new(ledger: Arc<Ledger>) -> Self {
            let mut backing = Box::new(AlignedBacking { bytes: [0; 56] });
            let span = NonNull::new(unsafe { backing.bytes.as_mut_ptr().add(8) }).unwrap();
            ledger.record(Event::Construct);
            Self { backing: Some(backing), span, physical: 0x1000,
                ledger, released: false }
        }
        pub fn preparation_baseline(&self) { self.ledger.record(Event::Baseline); }
        pub fn verification_owner(&self) -> crate::stability_observer::Claim {
            crate::stability_observer::Claim { os: 1, generation: 1,
                response: crate::stability_observer::Tag { index: 0, serial: Some(1),
                    physical: self.physical, end: 0x1028 }, payload: None }
        }
    }
    unsafe impl super::ResponseMemory for TestResponseMemory {
        fn physical(&self) -> u64 { self.physical }
        fn address(&mut self) -> *mut u8 { self.span.as_ptr() }
        unsafe fn release(mut self) {
            if self.released { return; }
            self.released = true;
            self.ledger.record(Event::StatusStore);
            self.ledger.record(Event::Release);
            let backing = self.backing.take().unwrap();
            self.ledger.state.lock().unwrap().deferred.push(backing);
            self.ledger.record(Event::Deferred);
        }
    }
    impl Drop for TestResponseMemory {
        fn drop(&mut self) {
            if self.released { self.ledger.record(Event::FinishedDrop); return; }
            let backing = self.backing.take().unwrap();
            self.ledger.state.lock().unwrap().quarantine.push(backing);
            self.ledger.record(Event::UnfinishedDrop);
            self.ledger.record(Event::Quarantine);
        }
    }

    pub fn request() -> crate::application_rpc::Request {
        let mut bytes = [0u8; 128];
        bytes[8..12].copy_from_slice(&4i32.to_le_bytes());
        bytes[24..28].copy_from_slice(&0i32.to_le_bytes());
        bytes[32..36].copy_from_slice(&70i32.to_le_bytes());
        bytes[48..52].copy_from_slice(&70i32.to_le_bytes());
        bytes[52..56].copy_from_slice(&0i32.to_le_bytes());
        bytes[56..64].copy_from_slice(&1u64.to_le_bytes());
        bytes[80..88].copy_from_slice(&0x2000u64.to_le_bytes());
        bytes[88..96].copy_from_slice(&16u64.to_le_bytes());
        bytes[120..128].copy_from_slice(&0x1000u64.to_le_bytes());
        crate::application_rpc::Request::decode(&bytes).expect("packet29 request")
    }
}
