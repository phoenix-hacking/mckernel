const EFAULT: CInt = 14;
type ArchCloneLockFn = unsafe extern "C" fn(*mut c_void, *mut c_void);
type ArchDoForkFn =
    unsafe extern "C" fn(CInt, CULong, CULong, CULong, CULong, CULong, CULong) -> CULong;
pub unsafe extern "C" fn sys_clone(_n: CInt, ctx: *mut X86UserContext) -> CLong {
    if ctx.is_null() {
        return -(EFAULT as CLong);
    }
    let thread = current_thread_ptr();
    if thread.is_null() || (*thread).proc.is_null() {
        return -(EFAULT as CLong);
    }

    let mut lock_dump = MaybeUninit::<McsRwlockNodeIrqsave>::uninit();
    arch_clone_body_result(
        (*thread).proc.cast::<c_void>(),
        offset_of!(Process, coredump_lock),
        lock_dump.as_mut_ptr().cast::<c_void>(),
        (*ctx).gpr.rdi as CInt,
        (*ctx).gpr.rsi,
        (*ctx).gpr.rdx,
        (*ctx).gpr.r10,
        (*ctx).gpr.r8,
        (*ctx).gpr.rip,
        (*ctx).gpr.rsp,
        Some(arch_clone_reader_lock_bridge),
        Some(arch_clone_reader_unlock_bridge),
        Some(do_fork),
    ) as CLong
}
pub unsafe extern "C" fn sys_clone3(n: CInt, ctx: *mut X86UserContext) -> CLong {
    if ctx.is_null() || n as u64 != crate::clone3::NUMBER {
        return -(EFAULT as CLong);
    }
    let thread = current_thread_ptr();
    if thread.is_null() || (*thread).proc.is_null() || (*thread).vm.is_null() {
        return -(EFAULT as CLong);
    }
    let region = addr_of!((*(*thread).vm).region);
    let args = match crate::clone3::read(
        (*ctx).gpr.rdi,
        (*ctx).gpr.rsi as usize,
        (*region).user_start,
        (*region).user_end,
        |address, bytes| {
            let result = syscall_copy_from_user_bridge(bytes.as_mut_ptr(), address, bytes.len());
            if result == 0 {
                Ok(())
            } else {
                Err(result)
            }
        },
    ) {
        Ok(args) => args,
        Err(error) => return error,
    };
    let mut legacy = core::ptr::read(ctx);
    legacy.gpr.rdi = args.flags;
    legacy.gpr.rsi = args.stack;
    legacy.gpr.rdx = args.parent_tid;
    legacy.gpr.r10 = args.child_tid;
    legacy.gpr.r8 = args.tls;
    sys_clone(56, addr_of_mut!(legacy))
}
pub unsafe extern "C" fn arch_clone_body_result(
    proc: *mut c_void,
    coredump_lock_offset: SizeT,
    lock_node: *mut c_void,
    clone_flags: CInt,
    newsp: CULong,
    parent_tidptr: CULong,
    child_tidptr: CULong,
    tls: CULong,
    pc: CULong,
    sp: CULong,
    lock_fn: Option<ArchCloneLockFn>,
    unlock_fn: Option<ArchCloneLockFn>,
    fork_fn: Option<ArchDoForkFn>,
) -> CULong {
    if proc.is_null() {
        return (-(EFAULT as CLong)) as CULong;
    }
    let Some(lock) = lock_fn else {
        return (-(EFAULT as CLong)) as CULong;
    };
    let Some(unlock) = unlock_fn else {
        return (-(EFAULT as CLong)) as CULong;
    };
    let Some(fork) = fork_fn else {
        return (-(EFAULT as CLong)) as CULong;
    };

    let coredump_lock = proc.cast::<u8>().add(coredump_lock_offset).cast::<c_void>();
    lock(coredump_lock, lock_node);
    let ret = fork(clone_flags, newsp, parent_tidptr, child_tidptr, tls, pc, sp);
    unlock(coredump_lock, lock_node);
    ret
}
