kernel/CMakeFiles/mckernel.img.dir/lock_helpers.c.o: \
 /work/mckernel-native-irq-images-20260907-12/source/kernel/lock_helpers.c \
 /work/mckernel-native-irq-images-20260907-12/source/lib/include/types.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-irq-images-20260907-12/source/kernel/include/lwk/stddef.h \
 /work/mckernel-native-irq-images-20260907-12/source/kernel/include/lwk/compiler.h \
 /work/mckernel-native-irq-images-20260907-12/source/kernel/include/lwk/compiler-gcc.h \
 /work/mckernel-native-irq-images-20260907-12/source/lib/include/ihk/lock.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/arch-lock.h \
 /work/mckernel-native-irq-images-20260907-12/source/lib/include/ihk/cpu.h \
 /work/mckernel-native-irq-images-20260907-12/source/lib/include/list.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/ihk/context.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/registers.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/arch/cpu.h \
 /work/mckernel-native-irq-images-20260907-12/source/lib/include/mc_perf_event.h \
 /work/mckernel-native-irq-images-20260907-12/source/ihk/cokernel/smp/x86_64/include/march.h \
 /work/mckernel-native-irq-images-20260907-12/source/arch/x86_64/kernel/include/ihk/atomic.h \
 /work/mckernel-native-irq-images-20260907-12/fallback/config.h
