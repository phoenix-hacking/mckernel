"""Retain native prepared-image VM/cleanup, source-bound protocols, all failures and both ABI regressions."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-mcctrl-image-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-mcctrl-image-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),artifacts=[],captures=[],references=[],native_compiler_bindings=[],linux_compiler_bindings=[],applications_tested=False,production_gate_credit=False,declared_stage_integrated=False)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-mcctrl-process-checkpoint-20260908.json',
                 'native-guest-sysfs-checkpoint-20260908.json',
                 'storage-maintenance-20260908-8.json']:
        path=repo/'docs/verification'/name
        state=json.loads(path.read_text()); assert state['status']=='PASS'
        item=identity(path);item['path']=str(path.relative_to(repo));record['references'].append(item)
        for row in state['artifacts']:
            actual=identity(repo/row['path'])
            assert (actual['size'],actual['sha256'])==(row['size'],row['sha256']),row
            with gzip.open(repo/row['path'],'rb') as stream:
                while stream.read(1<<20): pass
    captures=[('native-mcctrl-image-module-20260908-'+str(n),'FAIL' if n in (1,3,4) else 'PASS') for n in range(1,9)]
    captures += [('native-application-image-20260908-'+str(n),'FAIL' if n==2 else 'PASS') for n in range(1,4)]
    captures += [('native-mcctrl-image-guest-20260908-x86_64-'+str(n),'PASS' if n==4 else 'FAIL') for n in range(1,5)]
    captures += [('native-mcctrl-image-regression-guest-20260908-i386-1','PASS')]
    assert len(captures)==16
    for name,expected in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]): verify(row)
        for row in state.get('overlay',[]):
            verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',capture/'staged-source')
        for item in state.get('captures',[]):
            for row in item['artifacts']: verify(row)
        artifact(capture,name+'.tar.gz',True)
        artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status=state['status'],error=state.get('error'),
            recorded_inputs=len(state.get('inputs',[])),recorded_compiler_inputs=len(state.get('compiler_inputs',[])),
            recorded_overlay_sources=len(state.get('overlay',[])),physical_captures=len(state.get('captures',[])),complete_capture_retained=True))
    compiled=work/'native-mcctrl-image-module-20260908-8'
    replays=[]
    for saved in sorted((compiled/'staged-source').rglob('*.rs')):
        relative=saved.relative_to(compiled/'staged-source')
        current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if current.read_bytes()==saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative; replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs')
            shutil.copyfile(current,original); shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            item=identity(current); item['path']=str(current.relative_to(repo))
            item.update(binding='Exact pinned rustfmt replay; original and formatted files retained',
                compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,
                format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(item); replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'},replays
    for name in ['smp_trampoline.S','smp_startup_entry.S']:
        record['native_compiler_bindings'].append(binding(repo/'host-kernel/native-rust'/name,compiled/'staged-source'/name))
    assert len(record['native_compiler_bindings'])==49

    protocol=work/'native-application-image-20260908-3'
    protocol_state=json.loads((protocol/'record.json').read_text())
    assert protocol_state['status']=='PASS'
    assert protocol_state['c_layout']==[128,8,0,8,12,16,24,28,32,40,48,120,9,10]
    assert protocol_state['image_c_layout']==[776,8,56,8,776,14627351833160655377,8,12,16,28,72,80,88,96,104,152,160,168,176,504,640,768]
    assert '8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (protocol/'protocol-tests.log').read_text()
    assert '9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (protocol/'image-tests.log').read_text()
    record['protocol_compiler_bindings']=[]
    for row in protocol_state['inputs']:
        relative=Path(row['path']).relative_to(protocol/'original-inputs')
        record['protocol_compiler_bindings'].append(binding(repo/relative,protocol/'source'/relative))
    assert len(record['protocol_compiler_bindings'])==12
    for body in protocol_state['extracted_bodies']:
        raw=(protocol/'source'/body['source']).read_bytes()[body['start_byte']:body['end_byte']]
        assert hashlib.sha256(raw).hexdigest()==body['sha256'],body
    assert len(protocol_state['extracted_bodies'])==15
    record['protocol']=dict(tests_passed=17,traditional_tests=8,image_and_deletion_tests=9,
        c_packet_layout_values=14,c_and_guest_rust_image_layout_values=22,c_tid_delete_message_assertion=69,
        exact_guest_rust_bodies=11,exact_c_declarations=4,unique_concurrent_tokens=4096,
        scope='Native state/image/page-walk checks and exact unchanged guest request/reply/deletion construction. Fault/late/wrong/full-queue cases are state tests, not live fault injection.')
    record['guest_peer_source_bindings']=[]
    for relative in ['kernel/rust/host_helpers.rs','kernel/rust/abi.rs','kernel/rust/syscall_policy.rs','kernel/syscall.c',
                     'kernel/rust/object_helpers.rs','kernel/rust/procfs.rs','kernel/procfs.c',
                     'kernel/rust/process_helpers.rs','kernel/process.c','kernel/host.c','kernel/rust/sched_helpers.rs']:
        record['guest_peer_source_bindings'].append(binding(repo/relative,
            work/'mckernel-native-sysfs-images-20260908-2/source'/relative))
    service_expected=dict(topology_queries=1056,contexts=4,workers=8,cycles=2,unload_vetoes=8,
        absent_rejections=6,unsupported_rejections=2,pre_ready_rejections=2,module_loads=5,module_unloads=5,application_execution=False)
    exec_expected=dict(credential_checks=259,credential_faults=3,file_checks=558,concurrent_callers=8,
        contexts=3,inherited_owner_isolation=True,final_release=True,procfs_exe_published=False,application_execution=False)
    process_expected=dict(checks=153,registrations=73,duplicate_rejections=74,user_copy_faults=3,
        unsupported_vm_requests=2,capacity=64,capacity_rejections=1,forked_workers=69,unload_vetoes=2,
        contexts=71,cleanup_acks=73,unique_reply_tokens=73,queued_timeouts=0,
        procfs_published=False,prepared_guest_processes=0,application_execution=False,physical_queue_cleanup_exchanges=73)

    accepted=[('native-mcctrl-image-guest-20260908-x86_64-4',4),('native-mcctrl-image-regression-guest-20260908-i386-1',3)]
    for name,count in accepted:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        assert state['status']=='PASS' and state['full_ready_observed'] and state['observed_callback_exchanges']==130
        assert not state['applications_tested'] and not state['production_gate_credit']
        assert len(state['captures'])==count and all(row['status']==3 and row['validated'] for row in state['captures'])
        assert state['mcctrl_service']==service_expected
        assert state['mcctrl_executable']==exec_expected
        assert state['mcctrl_process']==process_expected
        serial=(capture/'serial.log').read_text()
        before_summary=serial[:serial.index('NATIVE_SERVICE_GUEST PASS ready=1')]
        assert before_summary.count('mcctrl: application_service=registered abi=1')==6
        assert before_summary.count('mcctrl: application_service=unregistered abi=1')==6
        for saved in sorted((capture/'probe-source').iterdir()):
            relative='executer/include/uprotocol.h' if saved.name=='native-image-c-abi.h' else 'scripts/tests/fixtures/'+saved.name
            record['linux_compiler_bindings'].append(binding(repo/relative,saved))
    assert len(record['linux_compiler_bindings'])==16
    image_expected=dict(application_execution=False,capability_restored=True,checks=47,cleanup_acks=2,
        cleanup_handler_barrier=True,final_release=True,foreign_process_rejected=True,independent_page_walks=3,
        independent_physical_content_bytes=12288,mapping_unload_veto=True,mirror_bytes=24576,
        physical_incoming_packets=4,physical_queue_exchanges=3,prepare_acks=1,prepared=1,pte_clear=True,
        readback_bytes=16384,readonly_text_bytes_rechecked=4096,readonly_write_sigbus=True,registrations=2,
        same_mm_data_write=True,task_scheduled=False,transfer_bytes=12288,unscheduled_thread_deletions=1)
    image_capture=work/accepted[0][0];image_state=json.loads((image_capture/'record.json').read_text())
    assert image_state['mcctrl_image']==image_expected,(image_state['mcctrl_image'],image_expected)
    record['prepared_image']=image_expected
    physical=image_state['captures'][2]['prepared_image']
    assert physical['physical_content_bytes']==12288 and len(physical['page_walks'])==3 and not physical['task_scheduled']
    deletes=image_state['captures'][3]['unscheduled_thread_deletions']
    assert len(deletes)==1 and deletes[0]['pid']==physical['descriptor']['pid'] and deletes[0]['tid']==0 and not deletes[0]['reply_expected']
    record['independent_image_capture']=physical
    record['independent_deletion_capture']=deletes
    artifact(out/'format-replay','native-mcctrl-image-format-replay-20260908.tar.gz',True)
    reference_root=work/'native-source/linux-6.12.0-211.44.1.el10_2'
    record['linux_reference_sources']=[]
    for relative in ['fs/anon_inodes.c','fs/file_table.c','mm/mmap.c','mm/vma.c','mm/memory.c','mm/mprotect.c','mm/util.c',
                     'include/linux/sched/mm.h','include/linux/mm_types.h','include/linux/cred.h',
                     'kernel/fork.c','kernel/cred.c','kernel/pid.c','include/linux/pid.h',
                     'arch/x86/include/asm/pgtable_types.h','arch/x86/entry/syscalls/syscall_64.tbl']:
        source=reference_root/relative
        saved=out/'linux-reference-sources'/relative;saved.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,saved);assert source.read_bytes()==saved.read_bytes()
        record['linux_reference_sources'].append(dict(source=identity(source),retained=identity(saved),
            scope='Exact pinned source context for consumed Linux file/MM/PFN/PTE/credential/PID interfaces and probe syscalls; not additional runtime validation.'))
    artifact(out/'linux-reference-sources','native-mcctrl-image-linux-reference-sources-20260908.tar.gz',True)
    artifact(work/'native-build-base-24a151fe/System.map','native-mcctrl-image-linux-System.map.gz')
    for name in ['build-native-mcctrl-image.py','build-native-mcctrl-image-vm.py','run-native-mcctrl-image.py',
                 'run-native-mcctrl-image-regression.py','test-native-application-image.py']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-mcctrl-image.py.gz')
    record['summary']=dict(native_modules=3,accepted_guest_runs=2,physical_ready_captures=7,
        protocol_tests=17,prepared_images=1,image_checks=47,transfer_bytes=12288,readback_bytes=16384,mirror_bytes=24576,
        independent_image_bytes=12288,independent_image_page_walks=3,readonly_write_sigbus_checks=1,
        same_mm_vfork_workers_joined=1,unscheduled_thread_deletions=1,prepared_cleanup_handler_barriers=1,
        process_ioctl_checks=306,baseline_process_registrations=146,image_process_registrations=2,
        duplicate_process_rejections=148,process_copy_faults=6,unsupported_nonnull_ppd_requests=4,
        process_capacity_per_os=64,capacity_exhaustions=2,process_workers_joined=138,process_contexts_opened_and_closed=142,
        process_unload_vetoes=4,cleanup_acknowledgements=148,prepare_acknowledgements=1,
        application_request_reply_exchanges=149,additional_advisory_incoming_packets=1,
        credential_checks=518,credential_faults=6,executable_file_checks=1116,executable_contexts_opened_and_closed=6,
        executable_forked_workers_joined=16,topology_queries=2112,service_contexts_opened_and_closed=8,
        service_workers_joined=16,module_loads_and_unloads=12,service_unload_vetoes=16,
        continuing_sysfs_callback_exchanges=260,guest_store_payload_checks=128,
        failed_captures_retained=7,exact_formatter_replays=3)
    assert sum(expected=='FAIL' for name,expected in captures)==record['summary']['failed_captures_retained']
    record['limitations']=[
        'The x86_64 launcher ABI prepares and transfers a real guest image, but no guest task was scheduled and no native mcexec application has executed. Actual ELF START, syscall/signal forwarding, procfs publication/read paths and full application verification remain required.',
        'The Linux mirror retains exact referenced MM/process/OS/backend/module owners, checks guest permissions, restores temporary credentials and validates PTE clear identity. Full running-VM invalidation/pinning, remote page faults, mprotect/mremap synchronization and fork/exec/exit races remain open.',
        'Only x86_64 image preparation is implemented. i386 repeats unchanged executable/credential/process/topology/sysfs regressions; it does not claim compatibility image preparation. Non-null CREATE_PPD remains explicitly unsupported with preserved copy faults.',
        'Prepared unscheduled cleanup retains its bounded registration through the cleanup ACK and exact OS/CPU/PID/TID-zero deletion. DELETE is advisory and its peer-stack resp_pa is never dereferenced. No procfs thread entry has been created in this phase; scheduled TIDs and full procfs/lifecycle ownership remain required.',
        'Neither ACK nor DELETE alone proves final thread destruction. A subsequent acknowledged request on the same guest CPU provides a handler-completion barrier; allocator reuse, full exit semantics, multi-thread lifetime and running-task termination still need direct coverage.',
        'The traditional deletion notification carries no operation token. Ordered exactly-once transport plus the retained unscheduled owner define the present identity boundary. Real late/queue-full/duplicate/reuse/removal fault injection remains open beyond source-bound state tests.',
        'All seven original failed captures remain FAIL and are fully retained: three module compiler failures, one C test-header conflict and three actual guest failures (anon-inode noexec EPERM, repeated PFN write fault timeout, and unserviced thread-deletion teardown). No failing assertion was removed to obtain acceptance.',
        'All current native/probe/protocol/guest-peer bindings and three exact formatter replays are retained. Accumulated declared staging/source-graph/lifecycle/unsafe-FFI integration and a fresh full repository suite remain required; this checkpoint grants no production gate credit.',
        'Current guest Rust/C consumers and images remain unchanged, and no McKernel C production bridge was added. Full Rust/assembly retirement, shutdown, multi-CPU/multi-OS, remaining sysfs faults/races and independent acceptance remain required by the original goal.',
    ]
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
