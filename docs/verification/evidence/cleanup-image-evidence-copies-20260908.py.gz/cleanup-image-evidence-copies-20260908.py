"""Remove only committed evidence copies named by the actual-guest manifest."""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util, json, os, sys

WORK = Path('/home/holden/mckernel-work/scratch')
REPO = Path('/home/holden/mckernel')
MANIFEST = 'docs/verification/native-guest-sysfs-checkpoint-20260908.json'
PLAN = WORK / 'storage-image-evidence-copies-20260908-plan.json'
REPORT = WORK / 'storage-image-evidence-copies-20260908-report.json'
CAPTURES = {'mckernel-native-sysfs-images-20260908-1', 'mckernel-native-sysfs-images-20260908-2'}
RETAINED = WORK / 'native-guest-sysfs-retained-20260908-1'
spec = importlib.util.spec_from_file_location('storage_base', WORK / 'cleanup-archived-captures-20260908-3.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def local(path):
    path = Path(path)
    if path.is_relative_to('/work'):
        return WORK / path.relative_to('/work')
    if path.is_relative_to('/workspace'):
        return REPO / path.relative_to('/workspace')
    raise ValueError(str(path))


def allowed(path, group):
    if any(p.is_symlink() for p in (path, *path.parents)):
        return False
    if group == 'image_evidence_copies':
        relative = path.relative_to(WORK)
        return (relative.parts[0] in CAPTURES
                and relative.parts[1:5] == ('source', 'docs', 'verification', 'evidence'))
    return group == 'retention_archive_copies' and path.parent == RETAINED and path.suffix == '.gz'


def unused(path, open_paths):
    alias = Path('/work') / path.relative_to(WORK)
    return not base.in_use(path, open_paths) and not base.in_use(alias, open_paths)


def audit():
    assert not PLAN.exists() and not REPORT.exists()
    head = base.git('rev-parse', 'HEAD').decode().strip()
    remote = base.git('ls-remote', 'origin', base.BRANCH).decode().split()[0]
    assert head == remote and not base.git('status', '--porcelain')
    tracked = {}
    for raw in base.git('ls-tree', '-r', '-z', head, '--', 'docs/verification').split(b'\0'):
        if raw:
            info, path = raw.split(b'\t', 1)
            tracked[path.decode()] = info.split()[2].decode()
    checked = {}
    def committed(relative, expected=None):
        if relative not in checked:
            value = base.hashes(REPO / relative)
            assert value['git_blob'] == tracked[relative], relative
            checked[relative] = value
        value = checked[relative]
        if expected:
            assert value['size'] == expected['size'] and value['sha256'] == expected['sha256'], relative
        return value
    committed(MANIFEST)
    manifest = json.loads((REPO / MANIFEST).read_text())
    assert manifest['status'] == 'PASS' and len(manifest['archive_exclusions']) == 2
    targets = []
    for capture in manifest['archive_exclusions']:
        root = local(capture['capture'])
        assert root.parent == WORK and root.name in CAPTURES
        for row in capture['files']:
            path = root / row['relative_capture']
            assert allowed(path, 'image_evidence_copies')
            retained = committed(row['git_path'], row)
            current = base.hashes(path)
            assert current == retained and current['git_blob'] == row['git_blob'], str(path)
            assert path.stat().st_nlink == 1 and path.stat().st_uid == 1000
            targets.append(dict(path=str(path), group='image_evidence_copies',
                archive=row['git_path'], snapshot=base.snapshot(path), allocated_bytes=path.stat().st_blocks * 512))
    for row in manifest['artifacts']:
        path = RETAINED / Path(row['path']).name
        assert allowed(path, 'retention_archive_copies')
        retained = committed(row['path'], row)
        assert base.hashes(path) == retained
        targets.append(dict(path=str(path), group='retention_archive_copies',
            archive=row['path'], snapshot=base.snapshot(path), allocated_bytes=path.stat().st_blocks * 512))
    paths = {Path(row['path']) for row in json.loads((WORK / 'storage-preserved-inputs-20260908-3.json').read_text())['files']}
    for group in ('native_compiler_bindings', 'guest_compiler_bindings', 'linux_compiler_bindings'):
        for row in manifest[group]:
            paths.add(local(row['compiler_capture']))
            paths.add(REPO / row['path'])
    for name in CAPTURES:
        state = json.loads((WORK / name / 'record.json').read_text())
        paths.add(WORK / name / 'record.json')
        for row in state.get('production_inputs', []):
            paths.add(local(row['path']))
        for image in state.get('images', []):
            for row in image['outputs']:
                paths.add(local(row['path']))
    paths.update(p for p in WORK.iterdir() if p.is_file() and not p.is_symlink()
                 and p.suffix in ('.py', '.sh', '.inc'))
    assert not paths.intersection(Path(row['path']) for row in targets)
    protected = sorted(base.KEEP | CAPTURES)
    for name in protected:
        assert (WORK / name).is_dir(), name
    open_paths, inaccessible = base.visible_open_paths()
    for row in targets:
        assert unused(Path(row['path']), open_paths), row['path']
    plan = dict(head=head, remote_head=remote, manifest=MANIFEST, targets=targets,
        preserved_files={str(p): base.hashes(p) for p in sorted(paths)}, protected=protected,
        verified_committed_files=checked, inaccessible_process_fd_directories=inaccessible,
        finished_utc=base.now(), disk_before=base.disk_state())
    base.save(PLAN, plan)
    print('AUDIT PASS', len(targets), 'copies;', sum(row['allocated_bytes'] for row in targets),
          'allocated bytes;', len(paths), 'preserved inputs', flush=True)


def apply():
    assert not REPORT.exists()
    plan = json.loads(PLAN.read_text())
    assert base.git('rev-parse', 'HEAD').decode().strip() == plan['head']
    for relative, expected in plan['verified_committed_files'].items():
        assert base.hashes(REPO / relative) == expected, relative
    open_paths, inaccessible = base.visible_open_paths()
    for row in plan['targets']:
        path = Path(row['path'])
        assert allowed(path, row['group']) and unused(path, open_paths), str(path)
        assert base.snapshot(path) == row['snapshot'], str(path)
    report = dict(status='running', started_utc=base.now(), head=plan['head'],
                  manifest=MANIFEST, removed=[], disk_before=base.disk_state(),
                  inaccessible_process_fd_directories=inaccessible)
    base.save(REPORT, report)
    try:
        for row in plan['targets']:
            path = Path(row['path'])
            assert base.snapshot(path) == row['snapshot'], str(path)
            path.unlink()
            report['removed'].append(dict(path=str(path), group=row['group'], archive=row['archive'],
                                          allocated_bytes=row['allocated_bytes']))
            if len(report['removed']) % 64 == 0:
                base.save(REPORT, report)
        for path, expected in plan['preserved_files'].items():
            assert base.hashes(Path(path)) == expected, path
        for name in plan['protected']:
            assert (WORK / name).is_dir(), name
        assert all(not Path(row['path']).exists() for row in plan['targets'])
        report.update(status='PASS', preserved_files=len(plan['preserved_files']),
            protected_directories=plan['protected'], all_preserved_files_byte_identical=True,
            removed_allocated_bytes=sum(row['allocated_bytes'] for row in plan['targets']))
    except BaseException as error:
        report.update(status='FAIL', error=str(error))
        raise
    finally:
        report.update(finished_utc=base.now(), disk_after=base.disk_state())
        base.save(REPORT, report)
    print('CLEANUP PASS', len(report['removed']), 'copies;', report['removed_allocated_bytes'],
          'allocated bytes;', report['preserved_files'], 'inputs unchanged; trim still required', flush=True)


assert os.getuid() == 1000 and len(sys.argv) == 2 and sys.argv[1] in ('audit', 'apply')
(audit if sys.argv[1] == 'audit' else apply)()
