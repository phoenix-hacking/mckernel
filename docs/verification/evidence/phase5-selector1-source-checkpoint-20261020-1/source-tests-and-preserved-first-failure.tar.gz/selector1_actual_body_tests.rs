#![allow(dead_code,non_camel_case_types,static_mut_refs)]
use core::ffi::{c_int,c_long,c_ulong,c_void};
const EINVAL:i32=22;const ECHILD:i32=10;
#[repr(C)]
pub struct McexecSyscallRequest {
    rtid: c_int,
    ttid: c_int,
    valid: c_ulong,
    number: c_ulong,
    args: [c_ulong; 6],
}

#[repr(C)]
pub struct McexecSyscallWaitDesc {
    cpu: c_ulong,
    sr: McexecSyscallRequest,
    pid: c_int,
}

#[repr(C)]
pub struct ForkSync {
    status: i32,
    success: i32,
}

#[repr(C)]
pub struct ForkSyncContainer {
    pid: i32,
    next: *mut ForkSyncContainer,
    fs: *mut ForkSync,
}

pub unsafe extern "C" fn act_clone_complete(
    w: *const McexecSyscallWaitDesc,
    fd: c_int,
    cpu: c_int,
) {
    // Selector1 commits the host child's existing fork-sync owner. A missing
    // owner cannot be reported as successful child start to the guest.
    let pid = match i32::try_from(unsafe { (*w).sr.args[1] }) {
        Ok(pid) if pid > 0 => pid,
        _ => { unsafe { do_syscall_return(fd, cpu, -EINVAL as c_long, 0, 0, 0, 0) }; return; }
    };
    let mut fs: *mut ForkSync = core::ptr::null_mut();
    let mut node: *mut ForkSyncContainer = core::ptr::null_mut();
    unsafe {
        mcexec_fork_sync_lock_bridge();
        let completed = mcexec_fork_sync_complete_result(
            core::ptr::addr_of_mut!(MCEXEC_FORK_SYNC_TOP), pid, &mut fs, &mut node,
        );
        if completed == 1 {
            // The producer checked both pointers before changing success or
            // unlinking. These are the exact detached owner, consumed once.
            mcexec_fork_sync_munmap_bridge(fs.cast());
            mcexec_fork_sync_free_bridge(node.cast());
        }
        mcexec_fork_sync_unlock_bridge();
        let result = if completed == 1 { 0 } else if completed < 0 { completed } else { -ECHILD };
        do_syscall_return(fd, cpu, result as c_long, 0, 0, 0, 0);
    }
}

pub unsafe extern "C" fn mcexec_fork_sync_complete_result(
    top: *mut *mut ForkSyncContainer,
    pid: i32,
    fs_out: *mut *mut ForkSync,
    node_out: *mut *mut ForkSyncContainer,
) -> i32 {
    if top.is_null() || fs_out.is_null() || node_out.is_null() || pid <= 0 {
        return -EINVAL;
    }

    unsafe {
        *fs_out = core::ptr::null_mut();
        *node_out = core::ptr::null_mut();
    }

    let mut prev: *mut ForkSyncContainer = core::ptr::null_mut();
    let mut current = unsafe { *top };
    while !current.is_null() {
        let next = unsafe { (*current).next };
        if unsafe { (*current).pid } == pid {
            // Refuse before effects: no live sync object means no child-start
            // producer, and the list owner must remain available for repair.
            let fs = unsafe { (*current).fs };
            if fs.is_null() { return -EINVAL; }
            if prev.is_null() {
                unsafe {
                    *top = next;
                }
            } else {
                unsafe {
                    (*prev).next = next;
                }
            }

            unsafe { (*fs).success = 1; }
            unsafe {
                *fs_out = fs;
                *node_out = current;
            }
            return 1;
        }
        prev = current;
        current = next;
    }

    0
}

// Explicit test adapters: real production bodies/types above, counters stand
// in for existing userspace mutex, unmap, free and transport. No kernelABI/MM proof.
static mut MCEXEC_FORK_SYNC_TOP:*mut ForkSyncContainer=core::ptr::null_mut();
static mut LOCKS:i32=0;static mut UNLOCKS:i32=0;static mut UNMAPS:usize=0;static mut FREES:usize=0;
static mut UNMAPPED:usize=0;static mut FREED:usize=0;static mut RETURNED:i64=999;
unsafe fn mcexec_fork_sync_lock_bridge(){LOCKS+=1;}
unsafe fn mcexec_fork_sync_unlock_bridge(){UNLOCKS+=1;}
unsafe fn mcexec_fork_sync_munmap_bridge(p:*mut c_void){UNMAPS+=1;UNMAPPED=p as usize;}
unsafe fn mcexec_fork_sync_free_bridge(p:*mut c_void){FREES+=1;FREED=p as usize;}
unsafe fn do_syscall_return(_:i32,_:i32,result:i64,_:usize,_:usize,_:usize,_:usize){RETURNED=result;}
unsafe fn reset(){MCEXEC_FORK_SYNC_TOP=core::ptr::null_mut();LOCKS=0;UNLOCKS=0;UNMAPS=0;FREES=0;UNMAPPED=0;FREED=0;RETURNED=999;}
fn request(pid:u64)->McexecSyscallWaitDesc{McexecSyscallWaitDesc{cpu:2,sr:McexecSyscallRequest{rtid:7,ttid:0,valid:0,number:56,args:[1,pid,0,0,0,0]},pid:7}}
#[test]fn selector1_success_consumes_exact_owner_once(){unsafe{
 reset();let mut fs=ForkSync{status:0,success:0};let mut other=ForkSync{status:0,success:0};
 let mut tail=ForkSyncContainer{pid:99,next:core::ptr::null_mut(),fs:&mut other};
 let mut head=ForkSyncContainer{pid:41,next:&mut tail,fs:&mut fs};MCEXEC_FORK_SYNC_TOP=&mut head;
 act_clone_complete(&request(41),3,2);assert_eq!(RETURNED,0);assert_eq!(fs.success,1);assert_eq!(other.success,0);
 assert_eq!(MCEXEC_FORK_SYNC_TOP,&mut tail as *mut _);assert_eq!(UNMAPPED,&mut fs as *mut _ as usize);assert_eq!(FREED,&mut head as *mut _ as usize);
 assert_eq!((UNMAPS,FREES,LOCKS,UNLOCKS),(1,1,1,1));
 act_clone_complete(&request(41),3,2);assert_eq!(RETURNED,-10);assert_eq!((UNMAPS,FREES),(1,1));assert_eq!(other.success,0);
}}
#[test]fn selector1_missing_pid_keeps_other_owner(){unsafe{
 reset();let mut fs=ForkSync{status:0,success:0};let mut owner=ForkSyncContainer{pid:99,next:core::ptr::null_mut(),fs:&mut fs};MCEXEC_FORK_SYNC_TOP=&mut owner;
 act_clone_complete(&request(41),3,2);assert_eq!(RETURNED,-10);assert_eq!(MCEXEC_FORK_SYNC_TOP,&mut owner as *mut _);assert_eq!(fs.success,0);assert_eq!((UNMAPS,FREES,LOCKS,UNLOCKS),(0,0,1,1));
}}
#[test]fn selector1_malformed_sync_refuses_before_unlink(){unsafe{
 reset();let mut invalid=ForkSyncContainer{pid:41,next:core::ptr::null_mut(),fs:core::ptr::null_mut()};let mut fs=ForkSync{status:0,success:0};
 let mut head=ForkSyncContainer{pid:99,next:&mut invalid,fs:&mut fs};MCEXEC_FORK_SYNC_TOP=&mut head;
 act_clone_complete(&request(41),3,2);assert_eq!(RETURNED,-22);assert_eq!(MCEXEC_FORK_SYNC_TOP,&mut head as *mut _);assert_eq!(head.next,&mut invalid as *mut _);assert_eq!((UNMAPS,FREES),(0,0));assert_eq!(fs.success,0);
}}
#[test]fn selector1_invalid_or_truncated_pid_never_commits(){unsafe{
 reset();let mut fs=ForkSync{status:0,success:0};let mut head=ForkSyncContainer{pid:41,next:core::ptr::null_mut(),fs:&mut fs};MCEXEC_FORK_SYNC_TOP=&mut head;
 for pid in [0,u64::MAX,(1u64<<32)+41]{act_clone_complete(&request(pid),3,2);assert_eq!(RETURNED,-22);}
 assert_eq!((LOCKS,UNLOCKS,UNMAPS,FREES),(0,0,0,0));assert_eq!(MCEXEC_FORK_SYNC_TOP,&mut head as *mut _);assert_eq!(fs.success,0);
}}
#[test]fn selector1_helper_invalid_output_keeps_owner(){unsafe{
 reset();let mut fs=ForkSync{status:0,success:0};let mut head=ForkSyncContainer{pid:41,next:core::ptr::null_mut(),fs:&mut fs};let mut top=&mut head as *mut _;let mut out=core::ptr::null_mut();
 assert_eq!(mcexec_fork_sync_complete_result(&mut top,41,core::ptr::null_mut(),&mut out),-22);assert_eq!(top,&mut head as *mut _);assert_eq!(fs.success,0);
}}
