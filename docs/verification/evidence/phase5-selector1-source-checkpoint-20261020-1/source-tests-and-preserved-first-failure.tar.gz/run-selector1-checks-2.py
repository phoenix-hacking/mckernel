import os,resource,subprocess,pathlib,json,hashlib,signal,time
r=pathlib.Path(__file__).resolve().parent
compiler=pathlib.Path('/home/holden/.rustup/toolchains/1.85.1-x86_64-unknown-linux-gnu/bin/rustc')
linker=pathlib.Path('/usr/bin/cc').resolve()
records=[]
state=json.loads(pathlib.Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_text())
usage=state.get('last_rate_limits',{}).get('primary',{}).get('usedPercent')
assert state.get('phase')=='running' and not state.get('pause_reason') and isinstance(usage,(int,float)) and usage<100
for path,floor in [('/home/holden',16*2**30),('/home/holden/mckernel-work/scratch',12*2**30)]:
 v=os.statvfs(path);assert v.f_bavail*v.f_frsize>=floor+64*2**20

def limits():
 os.sched_setaffinity(0,{6})
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 resource.setrlimit(resource.RLIMIT_NOFILE,(256,256))
 resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
 resource.setrlimit(resource.RLIMIT_CPU,(30,30))
 resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432))
def run(name,args):
 out=r/(name+'.stdout');err=r/(name+'.stderr');start=time.monotonic()
 with out.open('wb') as o,err.open('wb') as e:
  p=subprocess.Popen(args,cwd=r,stdout=o,stderr=e,preexec_fn=limits,start_new_session=True)
  try: code=p.wait(timeout=35)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try: code=p.wait(timeout=2)
   except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 (r/(name+'.wait-status.json')).write_text(json.dumps({'pid':p.pid,'exit_code':code,'positive_wait':True,'elapsed':time.monotonic()-start},sort_keys=True)+'\n')
 rec={'environment':{'RUSTC_BOOTSTRAP':os.environ.get('RUSTC_BOOTSTRAP')},'name':name,'command':list(map(str,args)),'pid':p.pid,'exit_code':code,'elapsed':time.monotonic()-start,'positive_wait':True,'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest()};records.append(rec)
 (r/'selector1-test-result-2.json').write_text(json.dumps({'profile':'CPU6 / 1job /1GiBAS /30CPU /35+2wall /32MiBperstream','compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'linker_sha256':hashlib.sha256(linker.read_bytes()).hexdigest(),'results':records},indent=2)+'\n')
 # Full logs remain file backed; one final bounded count/status only.
 return code
os.environ['RUSTC_BOOTSTRAP']='1'
if run('selector1-source-normal-2',[str(compiler),'--edition=2021','-Zunpretty=normal','--crate-type=lib','source/executer/user/rust/mcexec_helpers.rs'])==0:
 os.environ.pop('RUSTC_BOOTSTRAP',None)
 if run('selector1-body-compile-1',[str(compiler),'--edition=2021','--test','-C','codegen-units=1','-C','debuginfo=0','-C','linker='+str(linker),'selector1_actual_body_tests.rs','-o','selector1-tests-1'])==0:
  run('selector1-body-test-1',[str(r/'selector1-tests-1'),'selector1_','--test-threads=1'])
print(json.dumps({'joined_commands':len(records),'exit_codes':[x['exit_code']for x in records]}))
