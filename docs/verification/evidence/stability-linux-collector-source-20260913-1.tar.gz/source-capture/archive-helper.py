from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import tarfile

REPO = Path('/home/holden/mckernel')
CAPTURE = Path('/tmp/stability-linux-sealed-collector-source-20260913-uuvfj0uc')
PACK = Path(__file__).parent
EVIDENCE = REPO / 'docs/verification/evidence'
ARCHIVE = EVIDENCE / 'stability-linux-collector-source-20260913-1.tar.gz'
MEMBERS = EVIDENCE / 'stability-linux-collector-source-20260913-1.members.json'
PUBLICATION = REPO / 'docs/verification/stability-linux-collector-source-review-20260913-1.json'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def identity(path):
    return {'path': str(path), 'size_bytes': path.stat().st_size, 'sha256': digest(path)}


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def inventory(root):
    rows = []
    for path in [root, *sorted(root.rglob('*'))]:
        info = path.lstat()
        kind = 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else None
        if kind is None:
            raise ValueError('unsupported source-capture member: ' + str(path))
        row = {'relative': str(path.relative_to(root)) if path != root else '', 'type': kind,
               'mode': stat.S_IMODE(info.st_mode), 'size_bytes': info.st_size if kind == 'file' else 0}
        if kind == 'file': row['sha256'] = digest(path)
        rows.append(row)
    return rows


for path in (ARCHIVE, MEMBERS, PUBLICATION, CAPTURE / 'archive-helper.py'):
    if path.exists():
        raise FileExistsError(path)
author = json.loads((CAPTURE / 'author-review.json').read_text())
for item in author['inputs']:
    actual = identity(Path(item['path']))
    assert all(actual[key] == item[key] for key in ('path', 'size_bytes', 'sha256')), item['path']
for peer in author['peer_reviews']:
    original = Path('/tmp') / peer['directory']
    copied = CAPTURE / peer['directory']
    assert inventory(original) == inventory(copied), peer['directory']
shutil.copy2(Path(__file__), CAPTURE / 'archive-helper.py')
rows = inventory(CAPTURE)
assert len(rows) <= 4096
assert sum(row['size_bytes'] for row in rows) <= 95 * 1024 * 1024
with ARCHIVE.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz', format=tarfile.PAX_FORMAT) as archive:
        for row in rows:
            source = CAPTURE / row['relative']
            name = 'source-capture' + ('/' + row['relative'] if row['relative'] else '')
            archive.add(source, arcname=name, recursive=False)
            row['archive_member'] = name
    output.flush(); os.fsync(output.fileno())
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(rows)
    for member, expected in zip(actual, rows):
        assert member.name == expected['archive_member']
        assert stat.S_IMODE(member.mode) == expected['mode']
        assert member.isdir() if expected['type'] == 'directory' else member.isfile()
        assert member.size == expected['size_bytes']
        if member.isfile():
            h = hashlib.sha256()
            with archive.extractfile(member) as stream:
                for chunk in iter(lambda: stream.read(1048576), b''): h.update(chunk)
            assert h.hexdigest() == expected['sha256'], member.name
expected_after = [{key: value for key, value in row.items() if key != 'archive_member'} for row in rows]
assert inventory(CAPTURE) == expected_after
for item in author['inputs']:
    actual = identity(Path(item['path']))
    assert all(actual[key] == item[key] for key in ('path', 'size_bytes', 'sha256')), item['path']
save(MEMBERS, {'schema_version': 1, 'kind': 'complete-source-archive-members', 'archive': identity(ARCHIVE),
               'original_root': str(CAPTURE), 'member_count': len(rows), 'all_members_verified': True, 'members': rows})
document = Path(author['documentation']['path'])
assert identity(document) == author['documentation']
publication = {
    'schema_version': 1, 'kind': 'linux-sealed-collector-source-review',
    'status': 'PASS_SOURCE_REVIEW_ONLY_NOT_RUN', 'application_acceptance': False, 'transport_acceptance': False,
    'backend_enabled': False, 'catalog_cases_executed': 0, 'compiler_executions': 0,
    'actual_test_executions': 0, 'guest_executions': 0, 'python_subject_imports': 0,
    'source_root': str(REPO / 'scripts/tests/fixtures/application-collector-v1/linux-sealed-v1'),
    'collector_profile': 'linux-sealed-infrastructure-v1', 'supported_role': 'declared-Linux-reference-only',
    'native_role': 'BLOCKED', 'pathname_execution': 'UNSUPPORTED', 'loader_closure': 'NOT_VERIFIED',
    'source_inputs': [{key: value for key, value in item.items() if key != 'retained'} for item in author['inputs']],
    'documentation': identity(document), 'author_review': identity(CAPTURE / 'author-review.json'),
    'peer_reviews': author['peer_reviews'], 'archive': identity(ARCHIVE), 'members_manifest': identity(MEMBERS),
    'original_capture_root': str(CAPTURE), 'member_count': len(rows), 'all_member_types_modes_bytes_verified': True,
    'all_original_versions_and_peer_failures_retained': True,
    'immutable_preserved_inputs': [str(REPO / 'scripts/tests/fixtures/application-collector-v1/request.c'),
                                  str(REPO / 'scripts/tests/fixtures/application-collector-v1/request.h'),
                                  str(REPO / 'scripts/tests/fixtures/application-collector-v1/request-v1.md'),
                                  '/home/holden/mckernel-work/setup/container-run.py'],
    'planned_actual_checks': {'sha_harness_literal_lines': 9, 'actual_root_driver_cases': 25, 'actual_builder_block_cases': 1},
    'remaining_gates': ['pinned compiler/dependency/ELF validation', 'actual SHA and builder-negative checks',
                        'parent-owned exact isolated root profile inspect/lock/watchdog/cleanup',
                        'actual25-case collector fixture run with complete raw evidence',
                        'remaining adverse storage/late-signal/ownership/stop/setup checks from tests.md',
                        'immutable pathname execution before pathname predicates/case release',
                        'source/image-bound loader closure and reviewed native payload observation',
                        'existing global and case capabilities plus separate reviewed execution packet'],
    'acceptance_scope': 'source review and retained implementation only; no collector runtime, application or OS acceptance',
}
save(PUBLICATION, publication)
save(PACK / 'result.json', {'publication': identity(PUBLICATION), 'archive': identity(ARCHIVE),
                           'members': identity(MEMBERS), 'member_count': len(rows), 'source_input_count': len(author['inputs'])})
print(json.dumps(json.loads((PACK / 'result.json').read_text()), indent=2))
