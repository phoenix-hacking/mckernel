# Linux sealed-image infrastructure collector, version 1

This is a separate **infrastructure** execution profile, not new semantics for
ACRQ profile 1 or an application runner backend. The decoder and its original
wire contract remain immutable. `run.py`, native launcher execution, catalog
predicates and application acceptance remain disabled. In particular, immutable
pathname execution is still a concrete gate before any existing case release.

The only proposed command is:

```
linux-collector --linux-sealed-infrastructure-v1 REQUEST INPUT_MANIFEST ATTEMPT
```

All three paths are absolute. ATTEMPT must be new; its parent and every input
path component must be existing nonsymlink directories. REQUEST is the exact
ACRQ0001 byte record. INPUT_MANIFEST is retained and hashed against the request's
selected-input digest. Its content is opaque to C; this check does not evaluate
capabilities, compilation, loader closure or a runtime packet. A separate caller
must perform those checks before any future application backend exists.

The collector accepts only the declared Linux reference role (1), request
identity/limit profile 1 and this explicit collector-side mode. McKernel role 2,
unknown/default/pathname modes and any attempt to submit catalog predicates are
unsupported. Ordinary builder-UID invocation is BLOCKED: positive infrastructure
fixtures require root in the separately pinned, isolated container. Desired
child uid/gid/groups/umask are established and observed, never copied into an
"actual" record without checking the child setup.

This first collector further bounds executable source to 1 MiB and regular
stdin to 65536 bytes; otherwise valid ACRQ requests beyond this subset are
BLOCKED. The selected manifest is at most 4 MiB. Request capture is bounded to
65537 bytes, retaining the one-byte-over negative fixture. Preparation has a
120-second monotonic deadline; child time is exactly ten seconds beginning no
later than fork, followed by at most fifteen seconds of owned cleanup. Separate
stdout/stderr retention bounds remain 65536 bytes. An independent external
supervisor must also bound the utility itself, filesystem stalls, interruptions
or a stopped collector and reap all adopted descendants. Local late observations
cannot become on-time completion.

The literal executable pathname is a **source selector**. The collector opens
it without following symlinks, copies and hashes its exact stable bytes, and
checks the requested size/digest. It then seals a private memfd against content
writes, growth and shrinkage before `execveat(fd, "", argv, env, AT_EMPTY_PATH)`.
This prevents a subsequent source-path replacement or write from selecting
different main executable bytes. Literal argv0 remains independent of that
source path, including empty later arguments and complete environment bytes.
Privileged/script/non-x86-64-ELF sources are outside this initial subset.

The actual backing is a sealed anonymous file, not the requested pathname.
`AT_EXECFN` and `/proc/self/exe` consequently have descriptor/memfd semantics;
path-sensitive predicates are BLOCKED. The report separately names requested
source, verified source stat/hash, sealed descriptor stat/seals, pre-exec child
descriptor observations and any actually observed post-exec `/proc/PID/exe`
identity. Missing post-exec observation stays missing. Error-pipe EOF alone
must not be labeled a directly observed successful exec. Interpreter/DSO closure
is not verified by this utility; no loader or application capability is granted.

Regular stdin receives the same stable-copy/hash/seal treatment with its own
descriptor and offset zero. `/dev/null` requires a real character device 1:3.
The child gets only stdin, separate blocking stdout/stderr pipe writers and
the CLOEXEC setup/error channel and executable descriptor needed before exec.
Cwd is opened component by component and selected by descriptor. Actual child
credentials, supplementary group, umask, cwd identity and fd modes are checked
before attempting exec. All inherited signal dispositions/masks are reset in
the child. The parent uses a private session/process group and Linux subreaping.

Collection is distinct from an oracle. A completed child can have a nonzero
exit or a real signal. Preserve the actual `waitpid` integer and consistent
`WIFEXITED`/`WIFSIGNALED` decoding; do not synthesize it from a printed result or
128+signal. Keep the original leader unreaped until its owned group has been
handled; never target the collector's group. Recheck direct/adopted ownership
and startticks, preserve every raw reap, drain both streams concurrently, and
require final ECHILD plus EOF for complete cleanup. Surviving descendants,
unattributed pipe holders, observation loss, overflow or cleanup deadline are
explicit failures. No unowned process may be signaled to obtain EOF.

Artifacts include original request/manifest, verified executable and stdin
copies where applicable, literal `argv.nul`/`env.nul`, stdout/stderr, the raw
child setup channel, bounded events and a final JSON report. Hash/count updates
follow every successful stored prefix; short writes must not claim unstored
bytes. Unknown/truncated evidence stays explicit. Root must inspect the actual
outer collector status/raw wait and complete artifacts even when an inner
report claims collection completed.

The intended report kind is `linux-sealed-infrastructure-collection`, version
1. It records actual Linux collector/child identities, desired request fields,
verified source and backing artifacts, monotonic phase/deadline observations,
setup/exec observations, raw child wait, pipe loss/EOF, owned cleanup and first
failure. Application/transport acceptance and backend enablement are always
false; native payload identity and payload completion are never manufactured.

Required actual-C infrastructure fixtures cover SHA256 known answers/chunk
boundaries, missing/malformed/stale/symlink/FIFO files, builder-UID and role/mode
blocks, copied image/stdin identities, literal argv0/empty/env/cwd, simultaneous
pipe pressure, exact limits and overflow, genuine signal versus exit143,
timeout, inherited pipes, escaped adopted children and interruption. Root owns
the pinned compilation and execution. No test or guest run is claimed by this
source document.
