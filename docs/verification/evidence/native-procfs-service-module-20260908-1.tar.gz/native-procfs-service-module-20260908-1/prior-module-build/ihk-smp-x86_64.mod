drivers/misc/mckernel/ihk_smp_x86_64.o
