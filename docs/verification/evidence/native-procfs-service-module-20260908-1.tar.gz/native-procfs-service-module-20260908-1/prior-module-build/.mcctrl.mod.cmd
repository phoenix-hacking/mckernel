savedcmd_drivers/misc/mckernel/mcctrl.mod := printf '%s\n'   mcctrl.o | awk '!x[$$0]++ { print("drivers/misc/mckernel/"$$0) }' > drivers/misc/mckernel/mcctrl.mod
