drivers/misc/mckernel/mcctrl.o
