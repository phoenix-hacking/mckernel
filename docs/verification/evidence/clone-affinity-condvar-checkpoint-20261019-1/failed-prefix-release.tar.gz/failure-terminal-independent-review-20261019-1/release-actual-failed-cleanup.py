import json,pathlib,hashlib,copy,time
R=pathlib.Path(__file__).parent;F=pathlib.Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/failure-preparation-1');A=F/'actual-root-readonly-1'
H=lambda b:hashlib.sha256(b).hexdigest();C=lambda d:json.dumps(d,sort_keys=True,separators=(',',':')).encode();J=lambda p:json.loads(pathlib.Path(p).read_bytes())
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':H(b),'bytes':len(b)}
def emit(name,d,newline=True):
 p=R/name;b=C(d)+(b'\n' if newline else b'');p.open('xb').write(b);return ref(p)
actual=ref(R/'FAILED-TERMINAL-ACTUAL-READONLY-REVIEW.json');assert actual['sha256']=='f9b8c0af22a2e6224e4015da785b3836cedb41dccc87cf0597b3906feafb7325'
factref=ref(A/'actual-readonly-postjoin-process-mutex-facts.json');assert factref['sha256']=='4d96976c0122f76275468d35651122e447290c6abdb26373b095c0eeccf2cf06';facts=J(factref['path'])
assert facts['status']=='PASS_FIVE_READONLY_CHILDREN_JOINED_GROUPS_EMPTY_MUTEX_REACQUIRED' and not facts['group_matches'] and not facts['permission_denials'] and len(facts['owned_start_new_session_groups'])==5
assert facts['root_mutex']=={'device':27,'inode':4,'reacquired':True}
assert {row['pid'] for row in facts['rows']}=={1464036,1464067,1464071,1465699,1465744}
source=ref(R/'FAILED-TERMINAL-CONSOLIDATED-SOURCE-REVIEW.json');assert source['sha256']=='989eb4f1c2ac933da3e844d252ff449c8c877cd2c90497c479faa97dc22ff85f'
proof=ref(F/'failure-terminal-fetched-proof.json');assert proof['sha256']=='2a7b315b6ca56a145458aaa3f5cae7f4ebc31976fb25aa93ad5442905dbb875d'
p=J(F/'actual-cleanup-release-payload-DRAFT.json');assert ref(F/'actual-cleanup-release-payload-DRAFT.json')['sha256']=='4fd7ed6ab1c5b7c7915a2e803708bdd4a30f4a5fcd0fae37a94401a14bec68c9'
assert p['status']=='NOT_RELEASED' and p['source_review'] is p['execution_review'] is None
assert p['schema']=='fp-save-image.cleanup-release.v1' and p['script_sha256']=='db58d8d86847903e9288a87552808c4cab4a3b588a62dadd7a59236551d7d346'
assert p['observation']['target']['exit_code']==1 and p['observation']['target']['container_id']=='dadedd81537c2121aad6ac8fc1141c4612857c22b0314f5cc67205b05dd1c08f'
assert p['fetched_source_verified'] is True
for k in ['actual_readonly_join','fetched_source_proof']:
 v=p[k];assert ref(v['path'])['sha256']==v['sha256']
p['status']='PASS_EXECUTION_RELEASE';p['source_review']={'status':'PASS','reviewer':'resume_git_owner_review','evidence_sha256':source['sha256'],'implementation_ownership':False,'fetched_source_proof':proof}
p['execution_review']={'status':'PASS','reviewer':'resume_git_owner_review','evidence_sha256':actual['sha256'],'implementation_ownership':False,'positive_readonly_postjoin':factref,'scope':'one exact failed-build stopped-container cleanup with complete original build/evidence retained in place'}
release=emit('FAILED-TERMINAL-EXACT-CLEANUP-RELEASE.json',p,False)
cap=J(F/'actual-cleanup-capture-bindings-DRAFT.json');assert ref(F/'actual-cleanup-capture-bindings-DRAFT.json')['sha256']=='8fdf5a5c08d6484e55a34cbaea2ccb905761014fda6d545caf969c43cb9b04de'
for op in cap['operations']:
 assert op['affinity']==[6] and op['inherited_cpu']==[-1,-1] and op['no_outer_wallkill'] is True and op['each_stream_cap']==134217728 and op['core_bytes']==0
 op['argv']=[release['sha256'] if x=='PENDING_EXACT_ROOT_CLEANUP_RELEASE_SHA256' else x for x in op['argv']]
 assert op['argv'][0:2]==['/usr/bin/sudo','-A']
 assert op['as_hard_bytes']==2147483648 and op['as_soft_bytes']==(2147483648 if op['role']=='cleanup' else 1073741824)
cap['status']='PASS_EXACT_CLEANUP_AND_CONDITIONAL_POSTJOIN_CAPTURE_BINDINGS';cap['implementation_author']='resume_git_owner_review';cap['source_data_author']='/root/next_live_process_rust_batch';cap['cleanup_authorized']=True;cap['physical_release']=False;cap['exact_release']=release;cap['install_exact_release_at']=str(F/'physical-cleanup-release.json')
cap['operations'][1]['admission_condition']={'cleanup_direct_child_joined':True,'cleanup_returncode':0,'cleanup_stderr_bytes':0,'complete_held_FD_cleanup_stdout':str(F/'actual-cleanup-result.json'),'cleanup_stdout_status':'PASS_EXECUTED','terminal':True,'container_present':False,'release_sha256':release['sha256'],'on_failure':'STOP; preserve all outputs; no postreader or cleanup retry without exact new review'}
capref=emit('FAILED-TERMINAL-EXACT-CLEANUP-CAPTURE-BINDINGS.json',cap)
d={'schema':'mckernel.independent-failed-build-terminal-exact-cleanup-decision.v1','status':'PASS_EXACT_FAILED_BUILD_CLEANUP_AND_CONDITIONAL_POSTJOIN_RELEASE','reviewer':'resume_git_owner_review','implementation_ownership':False,'actual_readonly_review':actual,'positive_readonly_retirement':factref,'source_review':source,'source_publication':proof,'exact_release':release,'install_exact_release_at':str(F/'physical-cleanup-release.json'),'canonical_release':'sorted compact JSON WITHOUT newline; SHA256 binds whole exact release bytes','capture_bindings':capref,'allowed_argv':[x['argv'] for x in cap['operations']],'preserve_in_place':J(R/'FAILED-BUILD-PRESERVATION-AUTHORITY.json')['required_preserved_directories'],'permitted_mutation':'only exact stopped failed CID removal and journaled archival/release of exact original common/shared ownership records; persistent mutex and complete original build/evidence/source/toolchain/failed bytes remain','fresh_coordinator_admission_required':['current boot/mount/source/author/selected source identity','exact stopped CID and exit1; no replacement or active container','live namespace/process census and root mutex ownership','exclusive CPU6 slot, existing usage guard and host/scratch floor plus full 2x128MiB capture/growth reserve','original common/shared identities and lease absent; unchanged protected inventories'],'critical_profile':{'affinity':[6],'jobs':1,'cleanup_as_soft_hard':[2147483648,2147483648],'postjoin_as_soft_hard':[1073741824,2147483648],'cpu_limits':[-1,-1],'each_stream_fsize':134217728,'wall_kill':None,'outer_grace_kill':None,'source_command_timeout_seconds':30},'postjoin_transport':'intentional JSON stderr PASS_CLEANUP_POSTJOIN_READBACK_ONLY plus exact5-member tar and22 retained FD rows; no empty-stderr requirement for successful postjoin','stop_first_failure':True,'retry_authorized':False,'physical_release':False,'production_image_acceptance':False,'native_acceptance':False,'time_unix':time.time()}
rr=emit('FAILED-TERMINAL-EXACT-CLEANUP-DECISION.json',d)
print(json.dumps({'status':d['status'],'decision':rr,'release':release,'capture_bindings':capref}))
