import pathlib,json,hashlib,os,stat,copy
R=pathlib.Path('/home/holden/mckernel-work/host-preparation/failure-terminal-independent-review-20261019-1');F=pathlib.Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/failure-preparation-1');A=F/'actual-root-readonly-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,expected=None):
 p=pathlib.Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode)and a.st_nlink==1 and a.st_size<=33554432;data=b''
  while True:
   b=os.read(fd,65536)
   if not b:break
   data+=b
  z=os.fstat(fd);n=p.stat();m=lambda s:dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
  assert m(a)==m(z)==m(n)
  if expected:assert sha(data)==expected
  return data,m(a)
 finally:os.close(fd)
def load(p):return json.loads(read(p)[0])
def ref(p):b,m=read(p);return dict(path=str(p),sha256=sha(b),bytes=len(b))
def save(n,d):p=R/n;b=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode();p.open('xb').write(b);return dict(path=str(p),sha256=sha(b))
base=load(R/'FAILED-TERMINAL-EXACT-READONLY-SET-DECISION.json');completed=[]
for role in ['observer','summary','original-five-FD-metadata']:
 s=load(A/(role+'.status.json'));assert s['role']==role and s['direct_child_joined']is True and s['observer_error']is None and s['returncode']==(1 if role=='original-five-FD-metadata'else 0)
 for kind,row in s['streams'].items():
  b,m=read(row['path'],row['sha256']);assert m==row['metadata']
  if role!='original-five-FD-metadata'and kind=='stderr':assert b==b''
 completed.append(dict(role=role,status=ref(A/(role+'.status.json')),pid=s['pid'],start=s['start'],returncode=s['returncode']))
err=read(A/'original-five-FD-metadata.stderr')[0];assert err.endswith(b'RuntimeError: exact inherited summary1GiB profile required\n')and read(A/'original-five-FD-metadata.stdout')[0]==b''
summary=load(A/'summary.stdout');assert summary['status']=='PASS_EXACT_FINITE_OBSERVER_READBACK_ONLY'and summary['result']['status']=='PASS_READ_ONLY_OBSERVATION_ONLY'and summary['cleanup_draft']['status']=='NOT_RELEASED'
assert summary['new_object_metadata']['objects']==[p[k]for p in load(F/'retained-production-objects/retained-objects.json')for k in ['original','retained']]
assert len(summary['new_object_metadata']['objects'])==22 and len(summary['file_sha256'])==5
hashpath=F/'actual-original-five-hashes.json';hdata,hm=read(hashpath);assert json.loads(hdata)==summary['file_sha256']and(hm['uid'],hm['gid'],hm['mode'],hm['nlink'])==(1000,1000,0o600,1)
assert not (A/'raw-five-export.tar').exists()
metadata=copy.deepcopy(base['operations'][2]);metadata['role']='original-five-FD-metadata-correction-1'
for key,suffix in [('status_path','.status.json'),('stdout_path','.stdout'),('stderr_path','.stderr')]:metadata[key]=str(A/('original-five-FD-metadata-correction-1'+suffix));assert not pathlib.Path(metadata[key]).exists()
metadata['argv']=[sha(hdata)if x=='PENDING_FIVE_ACTUAL_FILE_HASH_AUTHORITY_SHA256'else x for x in metadata['argv']]
raw=copy.deepcopy(base['operations'][3]);operations=[metadata,raw]
policy=load(R/'FAILED-ROOT-RAW5-MECHANICAL-LATE-BINDING-POLICY.json');policy['operations']=[base['operations'][0],base['operations'][1],metadata,raw]
policy['remaining_only_correction']=dict(complete_observer_status=ref(A/'observer.status.json'),complete_summary_status=ref(A/'summary.status.json'),complete_summary_stdout=ref(A/'summary.stdout'),failed_metadata_status=ref(A/'original-five-FD-metadata.status.json'),failed_metadata_stderr=ref(A/'original-five-FD-metadata.stderr'),corrected_metadata_status_path=metadata['status_path'],corrected_metadata_stdout_path=metadata['stdout_path'],hashfile=ref(hashpath),only_operations_invoked=[metadata['role'],raw['role']],no_observer_or_summary_replay=True,profile_enforcement='Per-child actual RLIMIT_AS=(1GiB,1GiB),CPU=(30,30),FSIZE=(32MiB,32MiB),CORE0 and affinity6 under existing35s+5s parentgroup control. Metadata source independently requires exact1GiB before reading original files.',unchanged_genuine_source_and_release=True)
policyref=save('FAILED-ROOT-RAW5-REMAINING-PROFILE-CORRECTION-POLICY.json',policy)
dec=dict(schema='mckernel.independent-failed-build-remaining-readonly-correction-review.v1',decision='PASS_EXACT_REMAINING_METADATA_AND_RAW5_PROFILE_CORRECTION_ONLY',reviewer='resume_git_owner_review',implementation_ownership=False,original_readonly_decision=ref(R/'FAILED-TERMINAL-EXACT-READONLY-SET-DECISION.json'),completed_stages=completed,failure_classification='Metadata helper refused inheritedAS2GiB at source pre-read exact1GiB check; helper/release/original5 not changed. Observer and distinct summary already passed and must be reused.',remaining_operations=operations,raw5_late_binding_policy=policyref,original_five_hashfile=ref(hashpath),completed_original_observer_and_summary_required=True,first_observer_release=base['exact_observer_release'],resource_controls=base['resource_controls'],mandatory_actual_per_child_limits=dict(AS=[1073741824,1073741824],CPU=[30,30],FSIZE=[33554432,33554432],CORE=[0,0],affinity=[6],parent_wall_seconds=35,TERM_KILL_grace_seconds=5),fresh_prerequisites=['Fresh soleCPU6/root sharedbudget/capacity/usage/service admission; all three prior ownedgroups physically retired and rootmutex27:4 available under normal admission.','Rootoriginal5, successful observer/summary capture/status bytes, genuine summary-derived hashfile and all frozen sources remain exact; helper itself reopens/checks actual original5 under corrected limits.','Preserve failed original metadata captures/status/failure.json, source/release/rootnonce and every original build/log. Use fresh metadata-correction paths; rawexport remains its original unconsumed path.'],mechanical_late_binding='All prior policy whitelists/typed FD/originalbytes/hash/canonical predicates unchanged. Only FD metadata stdout/status refs now MUST refer to exact correction1 paths after directjoin0; observer and summary refs remain original distinct positive statuses. Root may instantiate same exact reviewer literals with actual newFD rows/hash and wholepayloadhash; no author-generatedPASS.',failure_rule='One remaining-only bounded transport correction. Any failure stops/preserves for expert review; no reobserve, summary rerun, source/pub/test replay, profile widening or further retry.',cleanup_authority=False,physical_release=False,production_image_acceptance=False,native_acceptance=False)
out=save('FAILED-ROOT-REMAINING-TWO-EXACT-DECISION.json',dec);print(json.dumps(dict(decision=out,policy=policyref,hashfile_sha256=sha(hdata),completed=2,remaining=2),sort_keys=True))
