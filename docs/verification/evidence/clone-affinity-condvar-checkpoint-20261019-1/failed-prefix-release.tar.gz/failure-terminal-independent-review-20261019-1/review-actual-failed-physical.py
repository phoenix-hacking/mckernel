import json,pathlib,hashlib,os,stat,tarfile,time
R=pathlib.Path(__file__).parent;F=pathlib.Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/failure-preparation-1');A=F/'actual-root-cleanup-1'
H=lambda b:hashlib.sha256(b).hexdigest();C=lambda d:json.dumps(d,sort_keys=True,separators=(',',':')).encode();J=lambda p:json.loads(pathlib.Path(p).read_bytes())
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':H(b),'bytes':len(b)}
def meta(s):return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def held(row):
 p=pathlib.Path(row['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd);assert stat.S_ISREG(before.st_mode);h=hashlib.sha256()
  while True:
   b=os.read(fd,1024*1024)
   if not b:break
   h.update(b)
  assert meta(before)==meta(os.fstat(fd))==meta(p.lstat())
  for k,v in row.items():
   if k in meta(before):assert meta(before)[k]==(int(v,8) if k=='mode' and isinstance(v,str) else v),(str(p),k)
  assert h.hexdigest()==row['sha256']
 finally:os.close(fd)
statuses=[]
for role in ['cleanup','postjoin-readback']:
 s=J(A/(role+'.status.json'));assert s['returncode']==0 and s['direct_child_joined'] is True and s['observer_error'] is None
 for name,row in s['streams'].items():
  held(dict(row['metadata'],path=row['path'],sha256=row['sha256']));assert row['metadata']['size']<=134217728
  if role=='cleanup' and name=='stderr':assert row['metadata']['size']==0
 statuses.append(ref(A/(role+'.status.json')))
release=J(R/'FAILED-TERMINAL-EXACT-CLEANUP-RELEASE.json');r=J(F/'actual-cleanup-result.json')
assert r['status']=='PASS_EXECUTED' and r['terminal'] is True and r['container_absent'] is True
assert r['release_sha256']=='e501936c72c7c7e82e564f548e85e860a42ef2e3c928c97347f2752b59b77093'
assert r['container_id']==release['observation']['target']['container_id']=='dadedd81537c2121aad6ac8fc1141c4612857c22b0314f5cc67205b05dd1c08f'
assert r['boot_id']==release['observation']['boot_id']=='7bfc5687-6c04-4d15-84eb-b92ab9a55dcb'
assert r['filesystem_uuid']=='2a5768c8-718d-4914-bdc0-6b32c5a92a52'
rows=[r['plan'],r['journal'],r['capture']]+r['archives'];assert len(rows)==5
payloads={}
with tarfile.open(A/'postjoin-readback.tar') as t:
 ms=t.getmembers();assert len(ms)==5 and len({m.name for m in ms})==5 and {m.name for m in ms}=={pathlib.Path(x['path']).name for x in rows}
 for m in ms:
  row=next(x for x in rows if pathlib.Path(x['path']).name==m.name);b=t.extractfile(m).read();assert m.isfile() and m.size==row['size'] and H(b)==row['sha256'];payloads[m.name]=b
plan=json.loads(payloads[pathlib.Path(r['plan']['path']).name]);journalbytes=payloads[pathlib.Path(r['journal']['path']).name];journal=[json.loads(x) for x in journalbytes.splitlines()]
assert H(C(plan))==r['plan_sha256']
assert plan['release_sha256']==r['release_sha256'];assert len(journal)==9 and len(plan['records'])==2 and len(plan['waiters'])==8
legal=[(event,i) for i in range(2) for event in ['before_exchange','after_exchange','release','after_release']]+[('complete',2)]
prev=r['plan_sha256']
for i,(row,expected,line) in enumerate(zip(journal,legal,journalbytes.splitlines(keepends=True))):
 assert (row['event'],row['index'])==expected and row['sequence']==i and row['previous']==prev and row['plan_sha256']==r['plan_sha256']
 assert row['plan_identity']==[r['plan']['device'],r['plan']['inode']]
 assert H(C({k:v for k,v in row.items() if k!='hash'}))==row['hash'] and C(row)+b'\n'==line;prev=row['hash']
authority=J(R/'FAILED-BUILD-PRESERVATION-AUTHORITY.json')
for row,kind,record in zip(r['archives'],['common','shared'],plan['records']):
 original=authority['ownership'][kind];assert row['inode']==original['inode'] and row['device']==original['device'] and row['sha256']==original['sha256'] and row['size']==original['size']
 assert record[0]==original['path'] and record[3]==original['sha256'] and record[4]==original['inode'] and record[5]==original['size']
 held(row);assert not pathlib.Path(original['path']).exists()
post=J(A/'postjoin-readback.stderr');assert post['status']=='PASS_CLEANUP_POSTJOIN_READBACK_ONLY' and post['members']==5 and post['application_acceptance'] is False
pairs=J(F/'retained-production-objects/retained-objects.json');expected=[p[k] for p in pairs for k in ['original','retained']]
assert post['actual_object_rows']==expected and len(expected)==22
for row in expected:held(row)
# Preserve every represented original inventory entry in place. No rebuilt bytes or source corpus is reread.
entries=0
for base,inv in release['observation']['inventories'].items():
 for row in inv:
  s=pathlib.Path(row['path']).lstat();actual=dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=s.st_mode,nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
  for k,v in row.items():
   if k in actual:assert actual[k]==v,(row['path'],k)
  entries+=1
for p in authority['required_preserved_directories']:assert pathlib.Path(p).is_dir()
result={'schema':'mckernel.independent-failed-build-terminal-actual-cleanup-evidence-review.v1','status':'PASS_ACTUAL_FAILED_BUILD_TERMINAL_JOURNAL_ARCHIVES_AND_PRESERVATION','reviewer':'resume_git_owner_review','implementation_ownership':False,'positive_statuses':statuses,'engine_result':ref(F/'actual-cleanup-result.json'),'postjoin_archive':ref(A/'postjoin-readback.tar'),'postjoin_summary':ref(A/'postjoin-readback.stderr'),'exact_release_sha256':r['release_sha256'],'target_container_id':r['container_id'],'container_absent':True,'terminal_journal_events':9,'plan_sha256':r['plan_sha256'],'archived_original_ownership_records':r['archives'],'all_original_inventory_entries_preserved':entries,'original_work_inventory_entries':len(release['observation']['inventories'][str(F.parents[1]/'owner-work')]),'original_log_pairs':11,'full_FD_byte_rows_preserved':22,'full_original_build_evidence_preserved_in_place':authority['required_preserved_directories'],'physical_release':False,'normal_owned_group_mutex_supplement_pending':True,'production_image_acceptance':False,'native_acceptance':False,'time_unix':time.time()}
p=R/'FAILED-TERMINAL-ACTUAL-CLEANUP-EVIDENCE-REVIEW.json';p.open('xb').write(C(result)+b'\n');print(json.dumps({'status':result['status'],'path':str(p),'sha256':ref(p)['sha256'],'inventory_entries':entries,'journal_events':9,'FD_rows':22}))
