import json,pathlib,os,stat,hashlib,tarfile
R=pathlib.Path(__file__).parent
F=pathlib.Path('/home/holden/mckernel-work/host-preparation/future-four-callback-compiler-preparation-20261019-1/terminal-preparation-1/failure-preparation-1');A=F/'actual-root-readonly-1'
H=lambda b:hashlib.sha256(b).hexdigest()
C=lambda d:json.dumps(d,sort_keys=True,separators=(',',':')).encode()
J=lambda p:json.loads(pathlib.Path(p).read_bytes())
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':H(b),'bytes':len(b)}
def meta(s):return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def held(p,want=None,sha=None):
 p=pathlib.Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  s=os.fstat(fd);assert stat.S_ISREG(s.st_mode);b=b''
  while True:
   c=os.read(fd,1024*1024)
   if not c:break
   b+=c
  assert meta(s)==meta(os.fstat(fd))==meta(p.lstat())
  if want:
   for k,v in want.items():
    if k in meta(s):assert meta(s)[k]==(int(v,8) if k=='mode' and isinstance(v,str) else v),(str(p),k)
  if sha:assert H(b)==sha,str(p)
  return b
 finally:os.close(fd)
roles=['observer','summary','original-five-FD-metadata-correction-1','raw-five-export']
statuses=[]
for role in roles:
 p=A/(role+'.status.json');s=J(p);assert s['direct_child_joined'] is True and s['returncode']==0 and s['observer_error'] is None
 assert s['pid']>0 and int(s['start'])>0
 for kind,row in s['streams'].items():
  b=held(row['path'],row['metadata'],row['sha256']);assert len(b)<=33554432
  if kind=='stderr':assert not b
 statuses.append(ref(p))
failed=J(A/'original-five-FD-metadata.status.json');assert failed['direct_child_joined'] and failed['returncode']==1
summary=J(A/'summary.stdout');metadata=J(A/'original-five-FD-metadata-correction-1.stdout');late=J(A/'remaining-two-mechanical-latebindings.json');release=J(F/'raw-five-export-release.json')
for v in late.values():
 if isinstance(v,dict) and 'path' in v:assert ref(v['path'])['sha256']==v['sha256']
assert metadata['members']==5 and summary['file_sha256']==metadata['file_sha256']==J(F/'actual-original-five-hashes.json')==release['file_sha256']
for k,p in [('observer_status',A/'observer.status.json'),('summary_status',A/'summary.status.json'),('original_five_fd_metadata_status',A/'original-five-FD-metadata-correction-1.status.json'),('original_five_fd_metadata',A/'original-five-FD-metadata-correction-1.stdout')]:
 assert release[k]['path']==str(p) and release[k]['sha256']==ref(p)['sha256']
assert release['original_five_fd_objects']==metadata['objects']
assert release['execution_review']['reviewed_payload_sha256']==H(C({k:v for k,v in release.items() if k!='execution_review'})+b'\n')
assert late['policy']['sha256']=='364c6db65171e8b7f4aad4e2bde7f7fd101623f816d0ce72c38625ffbddefcac'
names=['observer-result.json','observation.json','cleanup-release-draft.json','new-object-metadata.json','ownership.json'];data={}
with tarfile.open(A/'raw-five-export.tar') as t:
 ms=t.getmembers();assert [m.name for m in ms]==names
 for m in ms:
  assert m.isfile() and m.uid==m.gid==0 and m.mode==0o600
  b=t.extractfile(m).read();assert H(b)==summary['file_sha256'][m.name]
  row=next(r for r in metadata['objects'] if pathlib.Path(r['path']).name==m.name)
  assert row['uid']==row['gid']==0 and row['mode']=='0o600' and row['nlink']==1 and row['size']==len(b) and row['sha256']==H(b)
  data[m.name]=json.loads(b)
 assert len(ms)==5
assert (A/'raw-five-export.tar').stat().st_size==late['expected_tar_bytes']==440320
obs=data['observation.json'];draft=data['cleanup-release-draft.json'];result=data['observer-result.json'];objects=data['new-object-metadata.json'];ownership=data['ownership.json']
assert result['status']=='PASS_READ_ONLY_OBSERVATION_ONLY' and result['cleanup_executed'] is False and result['application_acceptance'] is False
assert draft['status']=='NOT_RELEASED' and draft['observation']==obs
assert summary['cleanup_draft']['observation_canonical_sha256']==H(C(obs))
assert result['observation_sha256']==summary['file_sha256']['observation.json']
assert result['cleanup_release_draft_sha256']==summary['file_sha256']['cleanup-release-draft.json']
assert obs['target']['container_id']=='dadedd81537c2121aad6ac8fc1141c4612857c22b0314f5cc67205b05dd1c08f' and obs['target']['exit_code']==1
state=obs['container_inspect']['State'];assert state['Status']=='exited' and state['ExitCode']==1 and not state['Running'] and not state['OOMKilled'] and state['Pid']==0
assert obs['request_lease_absent'] is True and obs['guard_proof']['sha256']=='149e49aab1d9d17605a302600b49f60013c43ca94cfcb860fefc3fd1982dd430'
assert len(obs['client_ledger'])==8
for c in result['commands']:assert c['returncode']==0 and c['launch_error'] is None and not c['timed_out'] and not c['stdout_truncated'] and not c['stderr_truncated']
assert len(result['commands'])==6
pairs=J(F/'retained-production-objects/retained-objects.json');expected=[p[k] for p in pairs for k in ['original','retained']]
assert len(pairs)==11 and len(expected)==22 and objects['objects']==expected
for row in expected:held(row['path'],row,row['sha256'])
assert objects['authority_sha256']=='b10f2e061b17e6135f518c47d979ca1b7d1c75d2e06d6d5c3ea37b96aecafbd2'
assert ownership['nonce']==metadata['nonce']=='future-four-callback-failed-observation-1'
assert ownership['root_lock']['device']==27 and ownership['root_lock']['inode']==4
assert ownership['output']['uid']==0 and ownership['output']['mode']=='0o700'
selected={r['path']:r for r in obs['selected_files']}
authority=J(R/'FAILED-BUILD-PRESERVATION-AUTHORITY.json');assert len(selected)==76
assert selected[str(F/'FAILED-BUILD-PRESERVATION-AUTHORITY.json')]['sha256']=='20bd2b91d5433267da14a9d59aa0af38354cfef7d9589d8f22dfd04e3e177e76'
proposed=J(F/'actual-cleanup-release-payload-DRAFT.json'); additions={'actual_readonly_join','fetched_source_proof'}
assert {k:v for k,v in proposed.items() if k not in additions|{'fetched_source_verified'}}=={k:v for k,v in draft.items() if k!='fetched_source_verified'}
assert proposed['fetched_source_verified'] is True
out={'schema':'mckernel.independent-failed-build-terminal-actual-readonly-review.v1','status':'PASS_ACTUAL_FAILED_BUILD_READONLY_ROOT5_AND_22_FD_BINDINGS','reviewer':'resume_git_owner_review','implementation_ownership':False,'positive_statuses':statuses,'metadata_profile_failure_preserved':ref(A/'original-five-FD-metadata.status.json'),'bounded_remaining_correction':ref(A/'whole-readonly-remaining-completion.json'),'raw_tar':ref(A/'raw-five-export.tar'),'actual_five_sha256':summary['file_sha256'],'root_FD_rows':metadata['objects'],'retained_log_pairs':11,'verified_full_FD_byte_rows':22,'selected_source_rows':76,'original_guard_clients':8,'readonly_synchronous_commands':6,'inventories':{k:len(v) for k,v in obs['inventories'].items()},'observation_canonical_sha256':H(C(obs)),'cleanup_payload_draft':ref(F/'actual-cleanup-release-payload-DRAFT.json'),'cleanup_authorized':False,'physical_release':False,'production_image_acceptance':False,'native_acceptance':False,'full_original_build_evidence_preservation_required':authority['required_preserved_directories']}
p=R/'FAILED-TERMINAL-ACTUAL-READONLY-REVIEW.json';p.open('xb').write(C(out)+b'\n');print(json.dumps({'status':out['status'],'path':str(p),'sha256':ref(p)['sha256'],'pairs':11,'FD_rows':22,'root_files':5}))
