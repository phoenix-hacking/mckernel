"""Completed N3 serial replay plus focused retirement-contract mutations.

No host-observer reconstruction, process/backend effects or guest acceptance.
The original result and original evaluator remain untouched and FAIL.
"""
from pathlib import Path
import hashlib,importlib.util,json,os,socket,subprocess
C=Path(__file__).resolve().parent;R=C.parent
N=R/'two-cpu-running-query-correction-1/native-owner-3'
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def forbidden(*args,**kwargs):raise AssertionError('execution factory forbidden')
def main():
    assert os.sched_getaffinity(0)=={7}
    for row in json.loads((C/'source-pins.json').read_text()):
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
    subprocess.Popen=forbidden;os.execve=forbidden;socket.socket=forbidden
    original=load('original_frozen_N3_diagnostic',N/'native_diagnostic.py')
    candidate=load('corrected_pair_retirement_consumer',C/'native_diagnostic.py')
    proposal=json.loads((N/'parent-bound-proposal.json').read_text())
    manifest=candidate.load_manifest(proposal['normalized_manifest']['path'])
    attempt=Path(proposal['parent']['path'])/('attempt-'+proposal['nonce'])
    raw=(attempt/'serial.log').read_bytes();serial=raw.decode('utf-8');lines=serial.splitlines()
    old_result=json.loads((attempt/'result.json').read_text())
    assert old_result['status']=='FAIL' and old_result['failure']['error']=='pair premature retirement'
    try:original._pair_body(manifest,{'serial':serial})
    except original.DiagnosticError as error:assert str(error)=='pair premature retirement'
    else:raise AssertionError('original failure changed')
    result=candidate._pair_body(manifest,{'serial':serial})
    assert result['status']=='PROTOCOL_PASS' and result['application_acceptance'] is False
    actual=result['guest_report'];assert [a['pid'] for a in actual['apps']]==[259,258]
    assert [len(bytes.fromhex(a['streams']['stdout']['hex'])) for a in actual['apps']]==[387,254]
    pid=258;prefix='os=0 generation=1 pid='+str(pid)+' '
    def index(rows,text):
        matches=[i for i,line in enumerate(rows) if text in line]
        assert len(matches)==1,(text,len(matches));return matches[0]
    retry_text='application retirement '+prefix+'token=95 errno=-11'
    success_text='application retirement '+prefix+'token=178 errno=0'
    release_text='application_process=release '+prefix+'cleanup_errno=0'
    exit_text='application_syscall=delivered '+prefix
    exit_index=next(i for i,line in enumerate(lines) if exit_text in line and ' number=231' in line)
    observations=[{'label':'actual_completed_N3_pair_report','status':'PAIR_BODY_PASS','original_result':'FAIL_PRESERVED'}]
    positives=1;negatives=0
    def rejects(label,rows,expected):
        nonlocal negatives
        try:candidate._pair_body(manifest,{'serial':'\n'.join(rows)})
        except candidate.DiagnosticError as error:
            assert str(error)==expected,(label,str(error),expected)
        else:raise AssertionError('accepted negative '+label)
        negatives+=1;observations.append({'label':label,'status':'REFUSED','error':expected})
    # Already-supported zero-retry terminal path still passes unchanged.
    no_retry=[line for line in lines if not ('application retirement ' in line and ' errno=-11' in line)]
    assert candidate._pair_body(manifest,{'serial':'\n'.join(no_retry)})['status']=='PROTOCOL_PASS';positives+=1
    observations.append({'label':'zero_retry_path','status':'PAIR_BODY_PASS'})
    for label,text,target,expected in (
        ('retry_before_exit',retry_text,exit_index,'pair premature retirement'),
        ('success_before_exit',success_text,exit_index,'pair premature retirement'),
        ('release_before_success',release_text,index(lines,success_text),'pair premature release')):
        rows=list(lines);item=rows.pop(index(rows,text));rows.insert(target,item);rejects(label,rows,expected)
    rows=list(lines);rows.insert(index(rows,success_text),rows[index(rows,retry_text)]);rejects('duplicate_retry_token',rows,'pair retirement attempts')
    rows=list(lines);rows.insert(index(rows,success_text),rows[index(rows,success_text)]);rejects('duplicate_success',rows,'pair retirement/procfs')
    rows=list(lines);rows[index(rows,retry_text)]=rows[index(rows,retry_text)].replace('errno=-11','errno=-5');rejects('other_nonzero_quarantine',rows,'pair retirement retry result')
    rows=list(lines);item=rows.pop(index(rows,retry_text));rows.insert(index(rows,success_text)+1,item);rejects('retry_after_success',rows,'pair retirement retry result')
    for label,text in (('missing_success',success_text),('missing_release',release_text),('missing_main_procfs_delete','application procfs deleted '+prefix+'tid=258')):
        rows=list(lines);rows.pop(index(rows,text));rejects(label,rows,'pair retirement/procfs')
    rows=list(lines);rows[index(rows,retry_text)]=rows[index(rows,retry_text)].replace('token=95','token=177');rejects('cross_PID_retry_token_reuse',rows,'pair reused retirement attempt token')
    rows=list(lines);rows[index(rows,retry_text)]=rows[index(rows,retry_text)].replace('token=95','token=0');rejects('zero_retry_token',rows,'pair premature retirement')
    rows=list(lines);at=index(rows,success_text)
    for token in range(500,511):rows.insert(at,'application retirement '+prefix+'token='+str(token)+' errno=-11')
    rejects('unbounded_retry_responses',rows,'pair retirement attempts')
    rows=list(lines);rows[index(rows,retry_text)]+=' unexpected=1';rejects('malformed_retry_response',rows,'malformed pair retirement')
    for label,change,expected in (
        ('procfs_still_nonempty',lambda r:r.update(procfs_empty=False),'pair CPU/retirement report'),
        ('changed_payload_oracle',lambda r:r['apps'][0]['streams']['stdout'].update(hex='00'+r['apps'][0]['streams']['stdout']['hex'][2:]),'pair stream oracle')):
        rows=list(lines);at=index(rows,'ND_PAIR ');report=json.loads(rows[at][len('ND_PAIR '):]);change(report);rows[at]='ND_PAIR '+json.dumps(report);rejects(label,rows,expected)
    assert (attempt/'serial.log').read_bytes()==raw
    assert json.loads((attempt/'result.json').read_text())==old_result
    with (C/'case-results.json').open('x') as f:json.dump(observations,f,indent=2);f.write('\n')
    summary={'status':'PASS_COMPLETED_N3_PAIR_REPORT_REPLAY_AND_RETIREMENT_NEGATIVES','positives':positives,'negatives':negatives,'original_strict_failure_preserved':True,
      'actual_guest_app_reports':2,'new_guest_runs':0,'scope':'actual pair evaluator body only; no invented host observation or runtime promotion','factories_forbidden':True}
    with (C/'result.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
