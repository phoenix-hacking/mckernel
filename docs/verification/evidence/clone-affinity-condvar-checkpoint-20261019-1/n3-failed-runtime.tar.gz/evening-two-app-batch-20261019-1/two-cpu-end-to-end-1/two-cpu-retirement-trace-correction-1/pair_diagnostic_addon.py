"""Appended to the retained diagnostic module; original one-app path stays intact."""
_one_validate_manifest = _validate_manifest
_one_evaluate = evaluate
_one_build_command = build_command
PAIR_IMAGE_SHA = "1e7a1f689f565e3ba35def32d4f8c9ae729f0e5945c4fbeadee4eb523738a4a2"
PAIR_MODULE_SHAS = ("51b48a9e42eaa2411cab2a28edf9bb5db8b2d648675d083473e926f91dd0e038",
                    "82c9021f7491fa8bc6d178fe99e7d4b7b6f90838474a9c91b62ddb8edb3d13f8",
                    "6571ac7eca13559d8bab65125d54facbbc65e84f815d4ff3fc77ec6aa1104972")

def pair_argv(i):
    return ["/bin/mcexec", "-t", "1", "-c", str(i), "0", "/apps/app"+str(i)]

def pair_env(i):
    return {"PATH":"/usr/bin:/bin", "COKERNEL_PATH":"/apps", "PAIR_CPU":str(i)}

def _validate_manifest(obj):
    if "pair" not in obj:
        return _one_validate_manifest(obj)
    _need(set(obj)=={"schema_version","kind","case_id","artifacts","modules","profile","payload","staging","pair"},"pair manifest keys")
    base=_one_validate_manifest({k:v for k,v in obj.items() if k!="pair"})
    _need(base["profile"]["name"]==PROFILE_RETAINED,"pair retains4vCPU8192MiB envelope")
    _need(base["artifacts"]["mckernel_image"]["sha256"]==PAIR_IMAGE_SHA,"fixed FP image")
    _need(tuple(r["sha256"] for r in base["modules"])==PAIR_MODULE_SHAS,"matching fixed FP modules")
    p=obj["pair"]
    _keys(p,("version","os","generation","host_cpus","cpus","default_ikc_linux","apps","source_authority","inherited_overlay_manifest"))
    _need(type(p["version"]) is int and p["version"]==1 and type(p["os"]) is int and p["os"]==0 and type(p["generation"]) is int and p["generation"]==1,"pair OS identity")
    _need(p["host_cpus"]==[1,2] and p["cpus"]==[0,1] and type(p["default_ikc_linux"]) is int and p["default_ikc_linux"]==0,"pair CPU contract")
    authority=_ref(p["source_authority"],"retained FP complete authority")
    binding=json.loads(Path(authority["path"]).read_text(),object_pairs_hook=_pairs)
    review_ref=_ref(binding["image_artifact_review"],"accepted FP artifact review")
    review=json.loads(Path(review_ref["path"]).read_text(),object_pairs_hook=_pairs)
    _need(review["schema"]=="mckernel.independent-rust-fp-release-image-actual-review.v1" and review["decision"]=="PASS_ACTUAL_PRODUCTION_IMAGE_ARTIFACT_AND_GUARD_RETIREMENT" and review["production_artifact_acceptance"] is True and review["runtime_acceptance"] is False and review["implementation_ownership"] is False,"accepted FP artifact decision")
    production=_ref(binding["retained_production_manifest"],"all29 production roles")
    pairs=json.loads(Path(production["path"]).read_text(),object_pairs_hook=_pairs)
    _need(len(pairs)==29 and len({x["original"]["path"] for x in pairs})==29 and len({x["retained"]["path"] for x in pairs})==29,"complete production roles")
    selected=[x for x in pairs if x["original"]["path"]==review["actual_artifacts"]["image"]["path"]]
    _need(selected==[binding["selected_image_retained_pair"]] and selected[0]["original"]==binding["actual_image_source"] and selected[0]["retained"]["sha256"]==PAIR_IMAGE_SHA and selected[0]["retained"]["path"]==binding["retained_image"]["path"] and selected[0]["original"]["sha256"]==review["actual_artifacts"]["image"]["sha256"]==PAIR_IMAGE_SHA,"selected production image join")
    full=binding["full_fp_source_authority"]
    for key,review_key in (("image_request","request"),("entire_source_manifest","manifest"),("materialization_receipt","materialization_receipt")):
        record=_ref(full[key],"whole FP authority "+key)
        _need(record["path"]==review["source_request_bindings"][review_key]["path"] and record["sha256"]==review["source_request_bindings"][review_key]["sha256"],"complete reviewed FP source authority "+key)
    request=json.loads(Path(full["image_request"]["path"]).read_text(),object_pairs_hook=_pairs)
    _need(request["source_root"]==full["source_root"] and request["source_identity"]==full["source_identity"] and request["source_derivative_sha256"]==full["source_derivative_sha256"],"whole retained source authority join")
    _need(binding["retained_image"]["sha256"]==PAIR_IMAGE_SHA,"authority image join")
    inherited=_ref(p["inherited_overlay_manifest"],"inherited overlay")
    old=json.loads(Path(inherited["path"]).read_text(),object_pairs_hook=_pairs)["final_map"]
    final=json.loads(Path(base["staging"]["overlay_manifest"]["path"]).read_text(),object_pairs_hook=_pairs)["final_map"]
    _need(set(final)==set(old)|{"apps/app0","apps/app1"},"exact pair overlay membership")
    changed={n for n in old if old[n]!=final[n]}
    _need(changed <= {"init","apps/app","bin/native-boot"},"only pair collector/apps/bootstrap change")
    for n in old:
        _need({k:v for k,v in old[n].items() if k not in {"sha256","size"}}=={k:v for k,v in final[n].items() if k not in {"sha256","size"}},"retained metadata "+n)
    _need(type(p["apps"]) is list and len(p["apps"])==2,"exactly two apps")
    for i,a in enumerate(p["apps"]):
        _keys(a,("id","cpu","argv","cwd","env","payload","oracle","stdout_limit_bytes","stderr_limit_bytes","timeout_ms"))
        _need(type(a["id"]) is int and a["id"]==i and type(a["cpu"]) is int and a["cpu"]==i,"pair ordinal")
        _need(a["argv"]==pair_argv(i) and a["cwd"]=="/case/two-app/work"+str(i) and a["env"]==pair_env(i),"pair launch contract")
        payload=_ref(a["payload"],"pair payload")
        row=final["apps/app"+str(i)]
        _need(row["sha256"]==payload["sha256"] and row["size"]==payload["size"] and row["mode"]==stat.S_IFREG|0o755,"pair payload final member")
        _need(a["oracle"]=={"stdout_hex":base["payload"]["oracle"]["stdout_hex"],"stderr_hex":"","exit_code":0} if i==0 else
              a["oracle"]=={"stdout_hex":bytes.fromhex(a["oracle"]["stdout_hex"]).hex(),"stderr_hex":"","exit_code":0},"pair oracle shape")
        expected_shas=("e5aab46f5a720bacdbb2fb3cb83d682b02df7261336e79663c79fa78022b9bc4","52095dafd5235a8c1073248bbda3964f8a7b749722306ceaabf321d2fdcd4816")
        _need(hashlib.sha256(bytes.fromhex(a["oracle"]["stdout_hex"])).hexdigest()==expected_shas[i],"frozen pair output oracle")
        _need(type(a["timeout_ms"]) is int and a["timeout_ms"]==10000 and type(a["stdout_limit_bytes"]) is int and a["stdout_limit_bytes"]==1024 and type(a["stderr_limit_bytes"]) is int and a["stderr_limit_bytes"]==1024,"pair finite bounds")
    _need(p["apps"][0]["payload"]==base["artifacts"]["payload"],"primary app alias")
    return {**base,"pair":p}

def build_command(manifest,attempt):
    plan=_one_build_command(manifest,attempt)
    if "pair" not in manifest:return plan
    plan=_thaw(plan)
    plan["payload"]={"pair":manifest["pair"]["apps"]}
    plan["overlay"]["payloads"]=[a["payload"]["path"] for a in manifest["pair"]["apps"]]
    plan["overlay"]["boot_contract"]="native-boot-two-cpu-readback-v1"
    plan["overlay"]["guest_destinations"].update({"/apps/app"+str(i):a["payload"]["path"] for i,a in enumerate(manifest["pair"]["apps"])})
    plan["overlay"]["init_sequence"][-1]="two isolated app supervisors; join both before shared retirement"
    return _freeze(plan)

def _pair_trace(serial,pid,cpu):
    prefix=r"os=0 generation=1 pid="+str(pid)
    suffixes={"delivered":r"worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)",
              "returned":r"worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)",
              "return_route":r"worker=(\d+) delivery=(\d+) launcher_cpu=(-?\d+) guest_cpu=(\d+)"}
    records={k:{} for k in suffixes}
    for position,line in enumerate(serial.splitlines()):
        for name,suffix in suffixes.items():
            marker="application_syscall="+name+" "+"os=0 generation=1 pid="+str(pid)+" "
            if marker not in line:continue
            m=re.search(re.escape(marker)+suffix+r"\s*$",line)
            _need(m is not None,"malformed pair trace")
            row=tuple(map(int,m.groups()));key=row[:2]
            _need(all(0<v<2**64 for v in key) and key not in records[name],"duplicate/invalid pair delivery")
            records[name][key]=(row[2:],position)
    delivered,returned,routes=(records[k] for k in suffixes)
    exits={k for k,(row,_) in delivered.items() if row[1]==231}
    _need(delivered and returned and routes and len(exits)==1,"missing pair route/exit evidence")
    ordinary=set(delivered)-exits
    _need(set(returned)==ordinary and set(routes)<=ordinary and all(row[1]!=60 for row,_ in delivered.values()),"pair syscall correspondence")
    terminal=delivered[next(iter(exits))][1]
    _need(all(row[0]==cpu for row,_ in delivered.values()) and all(row[0]==cpu for row,_ in returned.values()),"pair actual CPU mismatch")
    workers={}
    for key in ordinary:
        begin,end=delivered[key][1],returned[key][1]
        _need(begin<end<terminal,"pair syscall order")
        slot=cpu
        if key in routes:
            (launcher,guest),where=routes[key]
            _need(launcher in (0,1) and launcher!=cpu and guest==cpu and begin<where<end,"pair route mismatch")
            slot=launcher
        _need(workers.setdefault(key[0],slot)==slot,"pair inconsistent worker route")
    # The retained broker retries EAGAIN with a fresh retirement Exchange
    # after the next monotonic-second boundary. The fixed successful launcher
    # has a10s supervisor budget: initial+ten boundary retries+success is a
    # conservative12-response cap. Every response still follows terminal exit.
    attempts=[];releases=[]
    for position,line in enumerate(serial.splitlines()):
        if "application retirement " in line and re.search(prefix+r"\b",line):
            match=re.search(r"application retirement "+prefix+r" token=(\d+) errno=(-?\d+)\s*$",line)
            _need(match is not None,"malformed pair retirement")
            token,error=map(int,match.groups())
            _need(0<token<2**64 and position>terminal,"pair premature retirement")
            attempts.append((position,token,error))
        if "application_process=release " in line and re.search(prefix+r"\b",line):
            match=re.search(r"application_process=release "+prefix+r" cleanup_errno=(-?\d+)\s*$",line)
            _need(match is not None and int(match.group(1))==0,"pair release failure")
            releases.append(position)
    _need(1<=len(attempts)<=12 and len({row[1] for row in attempts})==len(attempts),"pair retirement attempts")
    _need(all(row[2]==-11 for row in attempts[:-1]) and attempts[-1][2]==0,"pair retirement retry result")
    _need(len(releases)==1 and releases[0]>attempts[-1][0],"pair premature release")

def _pair_body(manifest,observation):
    serial=observation["serial"]
    _need(not any(line.startswith("ND_PAYLOAD ") for line in serial.splitlines()),"foreign one-app report")
    lines=[line[len("ND_PAIR "):] for line in serial.splitlines() if line.startswith("ND_PAIR ")]
    _need(len(lines)==1 and len(lines[0])<=MAX_JSON,"missing/duplicate pair report")
    r=json.loads(lines[0],object_pairs_hook=_pairs)
    _keys(r,("os","generation","host_cpus","cpus","procfs_empty","apps"))
    _need(type(r["os"]) is int and r["os"]==0 and type(r["generation"]) is int and r["generation"]==1 and r["host_cpus"]==[1,2] and r["cpus"]==[0,1] and r["procfs_empty"] is True,"pair CPU/retirement report")
    _need(type(r["apps"]) is list and len(r["apps"])==2,"pair reports")
    pids=[]
    for i,(a,expected) in enumerate(zip(r["apps"],manifest["pair"]["apps"])):
        _keys(a,("id","pid","cpu","cwd","argv","env","raw_wait_status","clean","fault","timeout","started_ns","reaped_ns","finished_ns","streams"))
        _need(type(a["id"]) is int and a["id"]==i and type(a["cpu"]) is int and a["cpu"]==i and type(a["pid"]) is int and a["pid"]>0 and a["pid"] not in pids,"pair PID/CPU identity")
        pids.append(a["pid"])
        for k in ("argv","cwd","env"):_need(a[k]==expected[k],"pair launch "+k)
        _need(all(type(a[k]) is int for k in ("raw_wait_status","clean","fault","timeout")) and (a["raw_wait_status"],a["clean"],a["fault"],a["timeout"])==(0,1,0,0),"pair app status")
        _need(all(type(a[k]) is int and a[k]>0 for k in ("started_ns","reaped_ns","finished_ns")) and a["started_ns"]<=a["reaped_ns"]<=a["finished_ns"],"pair times")
        _keys(a["streams"],("stdout","stderr"))
        for stream in ("stdout","stderr"):
            s=a["streams"][stream]
            _keys(s,("hex","eof","truncated","observed","retained","discarded","limit","eof_ns"))
            _need(type(s["hex"]) is str and re.fullmatch(r"(?:[0-9a-f]{2})*",s["hex"]),"pair stream hex")
            data=bytes.fromhex(s["hex"])
            _need(all(type(s[k]) is int and s[k]>=0 for k in ("observed","retained","discarded","limit","eof_ns")),"pair stream type")
            _need(s["eof"] is True and s["truncated"] is False and s["observed"]==s["retained"]==len(data)<=1024 and s["discarded"]==0 and s["limit"]==1024,"pair stream accounting")
            _need(a["started_ns"]<=s["eof_ns"]<=a["finished_ns"] and data==bytes.fromhex(expected["oracle"][stream+"_hex"]),"pair stream oracle")
        prefix=r"os=0 generation=1 pid="+str(a["pid"])
        _need(len(re.findall(r"application SCHEDULE "+prefix+r" cpu="+str(i)+r"\b",serial))==1,"pair schedule")
        for pattern in (r"application retirement "+prefix+r" token=(\d+) errno=0\b",r"application_process=release "+prefix+r" cleanup_errno=0\b",*[r"application procfs "+op+" "+prefix+r" tid="+str(a["pid"])+r"\b" for op in ("published","deleted")]):
            _need(len(re.findall(pattern,serial))==1,"pair retirement/procfs")
        _pair_trace(serial,a["pid"],i)
    schedules=re.findall(r"application SCHEDULE os=(\d+) generation=(\d+) pid=(\d+) cpu=(\d+)\b",serial)
    _need(set(schedules)=={("0","1",str(pids[i]),str(i)) for i in range(2)} and len(schedules)==2,"foreign pair schedule")
    for line in serial.splitlines():
        for name in ("delivered","returned","return_route"):
            marker="application_syscall="+name+" "
            if marker not in line:continue
            found=re.search(re.escape(marker)+r"os=(\d+) generation=(\d+) pid=(\d+) ",line)
            _need(found is not None and found.groups()[:2]==("0","1") and int(found.group(3)) in pids,"malformed/foreign pair syscall")
    _need(max(a["started_ns"] for a in r["apps"])<min(a["reaped_ns"] for a in r["apps"]),"no pair overlap")
    _need("NATIVE_PAIR_CPU os=0 generation=1 assigned_host=1,2 logical=0,1 default_ikc_linux=0" in serial,"missing actual boot CPU readback")
    tokens=re.findall(r"application retirement os=0 generation=1 pid=(?:"+"|".join(map(str,pids))+r") token=(\d+) errno=0\b",serial)
    _need(len(tokens)==2 and len(set(tokens))==2 and all(int(t)>0 for t in tokens),"pair distinct retirement tokens")
    attempt_tokens=re.findall(r"application retirement os=0 generation=1 pid=(?:"+"|".join(map(str,pids))+r") token=(\d+) errno=-?\d+\s*$",serial,re.MULTILINE)
    _need(len(attempt_tokens)==len(set(map(int,attempt_tokens))) and all(0<int(t)<2**64 for t in attempt_tokens),"pair reused retirement attempt token")
    channels=[]
    for logical,physical in enumerate((1,2)):
        pattern=r"control accepted os=0 generation=1 port=501 guest_cpu="+str(logical)+r" linux_cpu="+str(physical)+r" cookie=(\d+) receive=([0-9a-f]+) send=([0-9a-f]+) bytes="+str(PAIR_CONTROL_QUEUE_BYTES)+r" reference=(\d+) remote_cookie=([0-9a-f]+)"
        matches=re.findall(pattern,serial)
        _need(len(matches)==1 and int(matches[0][0])>0 and all(int(x,16)>0 for x in (matches[0][1],matches[0][2],matches[0][4])),"missing twoCPU IKC channel readback")
        channels.append(matches[0])
    _need(channels[0][0]!=channels[1][0],"duplicate pair IKC cookie")
    queues=[int(row[k],16) for row in channels for k in (1,2)]
    _need(all(a+PAIR_CONTROL_QUEUE_BYTES<=b or b+PAIR_CONTROL_QUEUE_BYTES<=a for i,a in enumerate(queues) for b in queues[i+1:]),"overlapping pair IKC queues")
    _need(len(re.findall(r"control accepted os=0 generation=1 port=501 ",serial))==2,"foreign/duplicate pair IKC channel")
    elapsed=max(a["finished_ns"] for a in r["apps"])-min(a["started_ns"] for a in r["apps"])
    return {"schema_version":1,"kind":"native-diagnostic-result","case_id":manifest["case_id"],"status":"PROTOCOL_PASS","application_acceptance":False,"mckernel_application_executed":False,"guest_report":r,"observation":observation,"runtime_blocker":DIAGNOSTIC_LIMITATION,"pair_metrics":{"completed_apps":2,"wall_ns":elapsed,"apps_per_wall_minute":120_000_000_000/elapsed}}

def evaluate(manifest,observation):
    if "pair" not in manifest:return _one_evaluate(manifest,observation)
    # _pair_host_evaluate is generated from the literal retained host-observer
    # prefix, ending before single-payload parsing. No QMP/teardown gate changes.
    return _pair_host_evaluate(manifest,observation)
