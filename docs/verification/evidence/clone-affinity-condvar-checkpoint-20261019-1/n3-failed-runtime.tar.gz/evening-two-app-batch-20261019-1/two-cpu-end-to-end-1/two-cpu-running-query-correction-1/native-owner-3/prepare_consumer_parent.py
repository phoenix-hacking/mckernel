"""Affected actual owner/runner consumers and one full short-parent binding.

Unprivileged preparation only. All execution factories are forbidden or fake.
No original mount controls, negative lifecycle cases or compiler checks replay.
"""
from pathlib import Path
import contextlib,hashlib,importlib.util,io,json,os,socket,stat,subprocess,time
N=Path(__file__).resolve().parent;C=N.parent;R=C.parent;P=R.parent
OLD=R/'native-owner-short-2';ORIGINAL=R/'native-owner-1'
WORK=P/'rqf3'
def ref(p):
    p=Path(p);s=p.stat()
    return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=s.st_size,mode=s.st_mode)
def js(name,value):
    with (N/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def forbidden(*args,**kwargs):raise AssertionError('real execution boundary forbidden')
def main():
    assert os.getuid()==os.geteuid()==1000 and os.sched_getaffinity(0)=={7}
    settings=json.loads((N/'preparation-settings.json').read_text())
    parent=Path(settings['parent']);manifest_root=Path(settings['normalized_manifest_root'])
    for p in (parent.parent,manifest_root,WORK):assert not os.path.lexists(p),str(p)
    stage=json.loads((C/'stage-1/stage-result.json').read_text())
    stage_manifest=stage['manifest'];assert ref(stage_manifest['path'])==stage_manifest
    original_bytes=Path(stage_manifest['path']).read_bytes()
    manifest_root.mkdir(mode=0o700);manifest_path=manifest_root/'manifest.json'
    with manifest_path.open('xb') as f:f.write(original_bytes);f.flush();os.fsync(f.fileno())
    assert manifest_path.read_bytes()==original_bytes
    normalized=ref(manifest_path)
    parent.parent.mkdir(mode=0o700);parent.mkdir(mode=0o700)
    s=parent.lstat();identity=dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)))
    assert identity['uid']==identity['gid']==1000 and identity['mode']=='0o700'
    owner=load('running_query_actual_owner',N/'native_diagnostic_container_owner.py')
    runner=load('running_query_actual_runner',N/'native_diagnostic_runner.py')
    nd,m=owner.bound_manifest(str(manifest_path),normalized['sha256'])
    assert Path(nd.__file__).resolve()==N/'native_diagnostic.py'
    subprocess.Popen=forbidden;os.execve=forbidden;socket.socket=forbidden
    actual=owner.DiagnosticOwner(str(parent),manifest=str(manifest_path),manifest_sha256=normalized['sha256'],nonce=settings['nonce'])
    inside=actual._inside_args();attempt=actual.attempt;argv=nd.expected_qemu_argv(m,attempt)
    assert actual.owner_sha==ref(N/'native_diagnostic_container_owner.py')['sha256']
    assert attempt==parent/('attempt-'+settings['nonce'])
    assert inside[inside.index('--attempt-parent')+1]==str(parent)
    assert inside[inside.index('--nonce')+1]==settings['nonce']
    assert inside[inside.index('--manifest')+1]==str(manifest_path)
    endpoints=[]
    for index,arg in enumerate(argv):
        if arg.startswith('unix:'):
            path=arg[5:].split(',',1)[0];n=len(os.fsencode(path));assert n<=107
            endpoints.append(dict(option=argv[index-1],path=path,encoded_bytes=n))
    qmp=nd._qmp_socket_path(attempt)
    assert endpoints==[dict(option='-qmp',path=qmp,encoded_bytes=len(os.fsencode(qmp)))]
    assert qmp==str(attempt/'qmp.sock') and argv[argv.index('-monitor')+1]=='none'
    assert argv[argv.index('-m')+1]=='8192' and argv[argv.index('-smp')+1]=='4,sockets=2,cores=2,threads=1'
    # Full actual source projection: mounts expose every consumed runtime ref
    # at its original path, including the standalone FP authority inputs.
    ro=[Path(owner.REPO),Path(owner.SCRATCH)]+[Path(p) for p in owner.EXTRA_READONLY]
    def visible(path):
        p=Path(path)
        return any(p==mount or (mount.is_dir() and p.is_relative_to(mount)) for mount in ro)
    roles={}
    for name in ('native_diagnostic_container_owner.py','native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py'):
        roles['runtime:'+name]=ref(N/name)
    for name in ('pair_collector.c','pair_collector.inc','pair_runtime.inc','pair_assignment.h','native-boot-two.c','native-os-resource-assignment.c','native-memory-reservation.c','native-cpu-reservation.c'):
        roles['producer:'+name]=ref(C/name)
    for path,sha in owner.SOURCE_HASHES.items():
        row=ref(path);assert row['sha256']==sha
        roles['owner-consumed:'+path]=row
    for key,row in m['artifacts'].items():roles['artifact:'+key]=row
    for index,row in enumerate(m['modules']):roles['module:'+str(index)]=row
    for key,row in m['staging'].items():
        if isinstance(row,dict) and 'path' in row and 'sha256' in row:
            roles['staging:'+key]=row
    for app in m['pair']['apps']:roles['application:'+str(app['id'])]=app['payload']
    roles['stage:manifest']=stage_manifest;roles['normalized:manifest']=normalized
    roles['stage:source']=ref(R/'stage_pair.py')
    for role,row in roles.items():
        assert visible(row['path']),(role,'not visible via actual RO mounts')
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
    js('runtime-input-projection.json',{'status':'PASS_ACTUAL_ROLE_PROJECTED_INPUT_VISIBILITY','roles':roles,'readonly_mounts':[str(p) for p in ro],
          'REPO':owner.REPO,'SCRATCH':owner.SCRATCH,'parent_rw':str(parent),'historical_owner_required':False})
    # Reuse accepted fake-effect classes; do not invoke their old main or controls.
    fake=load('accepted_pair_fake_classes',ORIGINAL/'entrypoint_fixture.actual-reflection-failure.py')
    fake.owner_module=owner
    row,image=fake.profile_row(actual);owner.DiagnosticOwner._profile(actual,row,image)
    class RootIdentity:
        def getuid(self):return 0
        def geteuid(self):return 0
        def __getattr__(self,name):return getattr(os,name)
    owner.os=RootIdentity();owner.DockerBackend=lambda:type('NoDocker',(),{'call':staticmethod(forbidden)})()
    def injected_run(obj):
        create=obj._create_argv()
        for path in [owner.REPO,owner.SCRATCH,*owner.EXTRA_READONLY]:
            assert create.count('type=bind,src='+path+',dst='+path+',readonly')==1
        positive,image=fake.profile_row(obj);obj._profile(positive,image);obj.absent=True
    owner.DiagnosticOwner.run=injected_run
    owner_args=['--attempt-parent',str(parent),'--nonce',settings['nonce'],'--owner-sha256',actual.owner_sha,'--manifest',str(manifest_path),'--manifest-sha256',normalized['sha256']]
    out=io.StringIO();err=io.StringIO()
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):owner_rc=owner.main(owner_args)
    with (N/'owner-fixture.stdout').open('x') as f:f.write(out.getvalue())
    with (N/'owner-fixture.stderr').open('x') as f:f.write(err.getvalue())
    assert owner_rc==0 and err.getvalue()==''
    WORK.mkdir(mode=0o700);original_loader=runner._module;state={};loaded=[]
    def injected_loader(name,path):
        module=original_loader(name,path);loaded.append(str(Path(module.__file__).resolve()))
        if Path(path).name=='native_diagnostic.py':state['nd']=module
        if Path(path).name=='native_diagnostic_backend.py':
            assert Path(module.QmpSession.__init__.__code__.co_filename).resolve()==N/'qmp_capture.py'
            module.process_factory=lambda argv,attempt:lambda timeout:fake.FakeProcess(argv,attempt,'good',state['nd'])
            module.qmp_factory=lambda path:lambda timeout:fake.FakeQMP()
        return module
    runner._module=injected_loader;out=io.StringIO();err=io.StringIO()
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        runner_rc=runner.main(['--manifest',str(manifest_path),'--attempt-parent',str(WORK),'--attempt-name','a','--timeout','10'])
    with (N/'runner-fixture.stdout').open('x') as f:f.write(out.getvalue())
    with (N/'runner-fixture.stderr').open('x') as f:f.write(err.getvalue())
    report=json.loads((WORK/'a/result.json').read_text())
    expected=json.loads((R/'c-consumer-finalization1.stdout').read_text()[len('ND_PAIR '):])
    assert runner_rc==0 and err.getvalue()=='' and report['status']=='PROTOCOL_PASS'
    assert report['cleanup']=={'reaped':True,'errors':[]} and report['guest_report']==expected and not report['capture_errors']
    assert all(str(N/name) in loaded for name in ('native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py'))
    assert not list(parent.iterdir()) and not os.path.lexists(actual.evidence)
    owner_argv=['/usr/bin/sudo','-A','/home/holden/anaconda3/bin/python3','-B',str(N/'native_diagnostic_container_owner.py'),*owner_args]
    proposal=json.loads((OLD/'execution-proposal.json').read_text())
    previous_parent=proposal['parent']['path'];previous_nonce=proposal['nonce']
    encoded=json.dumps(proposal).replace(previous_parent,str(parent)).replace(previous_nonce,settings['nonce']).replace(str(ORIGINAL),str(N))
    proposal=json.loads(encoded)
    proposal.update(status='ACTUAL_CORRECTED_STAGE_OWNER_RUNNER_SHORT_PARENT_PENDING_INDEPENDENT_REVIEW',owner=ref(N/'native_diagnostic_container_owner.py'),runner=ref(N/'native_diagnostic_runner.py'),diagnostic=ref(N/'native_diagnostic.py'),
      source_closure=[ref(N/name) for name in ('native_diagnostic_container_owner.py','native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py')],
      accepted_stage_manifest=stage_manifest,normalized_manifest=normalized,argv=owner_argv,nonce=settings['nonce'],runtime_release=False,guest_runs=0,
      runtime_input_projection=ref(N/'runtime-input-projection.json'),producer_ordinary_result=ref(C/'result.json'),producer_source_review=ref(Path('/home/holden/mckernel-work/host-preparation/evening-two-cpu-end-to-end-review-20261019-1/decision-running-query-correction1-consolidated.json')))
    proposal['parent']=dict(path=str(parent),identity=identity,creation='ACTUAL_EXCLUSIVE_CORRECTED_SHORT_PARENT')
    proposal['source_closure_reuse']='runtime owner source-local paths rebound; unchanged runner/ND/backend/QMP; original23mount/negative controls reused'
    proposal['byte_identical_local_clones']=json.loads((N/'source-derivation.json').read_text())
    proposal['reused_prior_ordinary_stage_review']=proposal['accepted_ordinary_actual_review']
    proposal['accepted_ordinary_actual_review']=proposal['producer_source_review']
    proposal['cpu_assignment']['authentication']='actual preboot OS_CREATE/COUNT/QUERY + fresh exclusive PID1 challenge + trusted 0600 proof + exact live kernel501 OS/generation/rank records + supported RunningGETCPU/sysfs; strict consumer'
    proposal['pending']=['independent affected actual stage/owner/runner/parent acceptance','genuine current heavy physical retirement accepted by parent','fresh <=60s snapshot and final hash-bound one-shot release']
    js('parent-bound-proposal.json',proposal)
    result=dict(status='PASS_ACTUAL_CORRECTED_STAGE_OWNER_RUNNER_FULL_SHORT_PARENT',parent_identity=identity,parent=str(parent),nonce=settings['nonce'],
      actual_attempt=str(attempt),qmp_encoded_bytes=len(os.fsencode(qmp)),AF_UNIX_endpoints=endpoints,monitor='none',owner_argv=owner_argv,inside_argv=inside,qemu_argv=argv,
      actual_owner_cli_rc=owner_rc,actual_runner_cli_rc=runner_rc,protocol='PROTOCOL_PASS',reaped=True,exact_pair_report=True,parent_empty=True,attempt_absent=True,
      owner_evidence_absent=True,normalized_manifest=normalized,stage_manifest=stage_manifest,role_projection=ref(N/'runtime-input-projection.json'),real_child_commands=0,guest_runs=0,runtime_release=False)
    js('actual-consumer-parent-result.json',result)
    meta=json.loads((ORIGINAL/'conditional-metadata.json').read_text())
    meta.update(status='ACTUAL_CORRECTED_STAGE_PARENT_PENDING_AFFECTED_REVIEW_AND_NATIVE_RELEASE',proposal=ref(N/'parent-bound-proposal.json'),runtime_wrapper=ref(N/'dispatch-runtime.py'),
      postjoin_readback=proposal['postjoin_readback'],parent_identity=identity,affected_path_check=ref(N/'actual-consumer-parent-result.json'),
      accepted_stage_manifest=stage_manifest,normalized_manifest=normalized)
    meta['reused_original_metadata_review']=meta['actual_metadata_review']
    meta['reused_owner_and_runner_controls_review']=meta['accepted_stage_fixture_parent_review']
    meta['actual_metadata_review']=None
    meta['accepted_stage_fixture_parent_review']=None
    js('conditional-metadata.json',meta)
    pending=json.loads((OLD/'machine-release-PENDING.json').read_text())
    pending.update(status='PENDING_CURRENT_PHYSICAL_RELEASE_LAST_SNAPSHOT_FINAL_DECISION',conditional_metadata_release=ref(N/'conditional-metadata.json'),parent_identity=identity,
      terminal_cleanup_and_common_shared_release={'status':'PENDING_CURRENT_PHYSICAL_PREDECESSOR','ref':None},fresh_live_preflight=None,
      exclusive_queue_predecessor=None,accepted_actual_stage_fixture_parent_review=None,runtime_release=False)
    js('machine-release-PENDING.json',pending)
    bindings=json.loads((OLD/'fresh-snapshot-bindings.json').read_text())
    bindings.update(source_pins=[ref(N/name) for name in ('root_manual_snapshot.py','native_diagnostic_container_owner.py','native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py','conditional-metadata.json','parent-bound-proposal.json','machine-release-PENDING.json','dispatch-runtime.py','actual-consumer-parent-result.json')],
      conditional_metadata=ref(N/'conditional-metadata.json'),machine_pending=ref(N/'machine-release-PENDING.json'),parent_identity=identity,manifest=normalized,non_temporal_freeze=ref(N/'actual-consumer-parent-result.json'))
    # No claim that the old fourleaf predecessor is the latest retired owner.
    # Parent supplies the genuine current predecessor before any root snapshot.
    bindings['physical_predecessor']={key:None for key in bindings['physical_predecessor']}
    bindings['physical_predecessor_status']='PENDING_PARENT_GENUINE_CURRENT_PHYSICAL_RELEASE'
    js('fresh-snapshot-bindings-PENDING-PHYSICAL.json',bindings)
    print(json.dumps({key:result[key] for key in ('status','qmp_encoded_bytes','actual_owner_cli_rc','actual_runner_cli_rc','guest_runs')}))
if __name__=='__main__':main()
