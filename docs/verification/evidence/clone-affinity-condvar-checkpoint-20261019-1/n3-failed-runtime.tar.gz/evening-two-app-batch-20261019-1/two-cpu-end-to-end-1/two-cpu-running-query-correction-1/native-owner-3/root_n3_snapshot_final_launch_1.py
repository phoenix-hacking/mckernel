from pathlib import Path
import os,json,hashlib,subprocess,time,stat
N=Path(__file__).resolve().parent
R=Path('/home/holden/mckernel-work/host-preparation/evening-two-cpu-end-to-end-review-20261019-1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,d):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w')as f:json.dump(d,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def start(pid):return Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()[19]
def run(role,argv):
 outp=N/(role+'.stdout');errp=N/(role+'.stderr');sp=N/(role+'.status.json');put(N/(role+'.command.json'),dict(role=role,argv=argv));t=time.monotonic();error=None;cs=None
 with outp.open('xb')as out,errp.open('xb')as err:
  child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:cs=start(child.pid);put(N/(role+'.child.json'),dict(pid=child.pid,start=cs,argv=argv))
  except BaseException as e:error=repr(e)
  finally:rc=child.wait()
  out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno());held={k:ident(os.fstat(f.fileno()))for k,f in [('stdout',out),('stderr',err)]}
 streams={}
 for k,p in [('stdout',outp),('stderr',errp)]:
  fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
  try:
   ss=os.fstat(fd);assert ident(ss)==held[k]==ident(p.stat());assert stat.S_ISREG(ss.st_mode)and ss.st_uid==1000 and ss.st_nlink==1 and stat.S_IMODE(ss.st_mode)==0o600
   with os.fdopen(os.dup(fd),'rb')as f:h=hashlib.sha256(f.read()).hexdigest()
   streams[k]=dict(path=str(p),sha256=h,metadata=ident(ss))
  finally:os.close(fd)
 row=dict(role=role,argv=argv,pid=child.pid,start=cs,returncode=rc,direct_child_joined=True,observer_error=error,elapsed_seconds=time.monotonic()-t,streams=streams);put(sp,row)
 assert rc==0 and error is None,(role,rc,error)
 return row
os.umask(0o077);assert os.getuid()==1000
ready=N/'PHYSICAL-ACCEPTED-SNAPSHOT-LAST-READY.json';assert sha(ready)=='33749b40138fa55b413bb601d5a627e2c2c5ff27398cb18ef5af2bb3a160eb13';d=json.loads(ready.read_text());assert sha(d['canonical_snapshot_bindings']['path'])==d['canonical_snapshot_bindings']['sha256'];assert sha(R/'review_final_n3_release.py')=='6cb11aab1bff7af6505f09b2ded9a52b739bc19d0b92892d4ff77a93c62d1483'
assert not (N/'execution-release.json').exists() and not (N/'root-live-preflight-1.json').exists()
run('snapshot-command',d['snapshot_argv']);run('assembly-command',d['assemble_argv']);rh=sha(N/'execution-release.json')
run('final-check',['/home/holden/anaconda3/bin/python3','-I','-B',str(R/'review_final_n3_release.py'),rh,str(N/'snapshot-command.status.json')])
final=json.loads((N/'final-check.stdout').read_text());assert final['status']=='PASS_EXACT_N3_ONE_SHOT_NATIVE_EXECUTION_RELEASE' and final['execution_release_sha256']==rh
argv=[rh if x=='@@FINAL_ONE_SHOT_RELEASE_SHA256@@'else x for x in d['launch_argv']];assert argv==final['launch_argv']
run('runtime-command',argv)
print('N3 owner wrapper wholejoined0; completed runtime captures ready',flush=True)
