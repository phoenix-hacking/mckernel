from pathlib import Path
import hashlib,json,os,signal,subprocess,time
R=Path(__file__).resolve().parent
COMMANDS=[('actual-consumer-parent',['/home/holden/anaconda3/bin/python3','-I','-B',str(R/'prepare_consumer_parent.py')])]
def main():
    assert os.sched_getaffinity(0)=={7}
    pins=json.loads((R/'consumer-source-pins.json').read_text())
    for row in pins:
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    bindings=json.loads(Path('/home/holden/mckernel-work/host-preparation/practical-rust-file-roundtrip-20261018-1/toolchain-and-profile-bindings.json').read_text())
    for row in [*(bindings['tools'][k] for k in ('cc','ld','capture_python')),*bindings['installed_static_link_inputs'].values()]:
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    for p,floor in [('/home/holden/mckernel',16*1024**3),('/home/holden/mckernel-work/scratch',12*1024**3)]:
        st=os.statvfs(p);assert st.f_bavail*st.f_frsize>=floor+640*1024**2
    profile=json.loads((R/'consumer-execution-profile.json').read_text())
    for row in profile['storage']['per_filesystem'].values():
        st=os.statvfs(row['path']);assert st.f_bavail*st.f_frsize>=row['floor_bytes']+row['reserve_bytes']+row['new_growth_ceiling_bytes']
    for path in profile['fresh_outputs']:
        if Path(path).name.startswith('consumer-whole.'):continue
        assert not os.path.lexists(path),path
    for label,cmd in COMMANDS:
        for suffix in ('.stdout','.stderr','.status.json'):assert not (R/(label+suffix)).exists()
    for name in ('consumer-sequence-result.json',):assert not (R/name).exists()
    deadline=time.monotonic()+28
    rows=[]
    for label,cmd in COMMANDS:
        remaining=deadline-time.monotonic();assert remaining>3
        start=time.time_ns();mono=time.monotonic_ns();p=None;timedout=False
        with (R/(label+'.stdout')).open('xb') as out,(R/(label+'.stderr')).open('xb') as err:
            p=subprocess.Popen(cmd,cwd=R,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC'},stdout=out,stderr=err,start_new_session=True)
            try:
                try:p.wait(timeout=min(20,remaining-3))
                except subprocess.TimeoutExpired:
                    timedout=True;os.killpg(p.pid,signal.SIGTERM)
                    try:p.wait(timeout=1)
                    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=1)
            finally:
                if p.poll() is None:
                    os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=1)
                row={'argv':cmd,'pid':p.pid,'started_unix_ns':start,'finished_unix_ns':time.time_ns(),'elapsed_ns':time.monotonic_ns()-mono,'returncode':p.returncode,'direct_join':True,'timedout':timedout}
                with (R/(label+'.status.json')).open('x') as f:json.dump(row,f,indent=2);f.write('\n')
                rows.append(row)
        if p.returncode or timedout:raise RuntimeError((label,p.returncode,'stop and preserve'))
        assert (R/(label+'.stderr')).stat().st_size==0,label
        if label.startswith('readelf-'):
            b=(R/(label+'.stdout')).read_bytes();assert b'EXEC (Executable file)' in b and b'INTERP' not in b and b'NEEDED' not in b
    result={'status':'PASS_AFFECTED_STAGE_OWNER_RUNNER_SHORT_PARENT_SEQUENCE','commands':len(rows),'all_direct_joined':True,'guest_runs':0,'source_pins_sha256':hashlib.sha256((R/'consumer-source-pins.json').read_bytes()).hexdigest(),'fixture_summary':json.loads((R/'actual-consumer-parent-result.json').read_text())['status']}
    with (R/'consumer-sequence-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
