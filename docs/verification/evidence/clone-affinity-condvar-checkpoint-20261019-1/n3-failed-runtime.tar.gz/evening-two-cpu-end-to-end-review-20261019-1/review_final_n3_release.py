"""Independent completed final-artifact review; never executes owner or guest."""
from pathlib import Path
import hashlib,json,sys,time
R=Path(__file__).resolve().parent
N=Path('/home/holden/mckernel-work/host-preparation/evening-two-app-batch-20261019-1/two-cpu-end-to-end-1/two-cpu-running-query-correction-1/native-owner-3')
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def checked(row):
 p=Path(row['path']);assert ref(p)['sha256']==row['sha256'];return json.loads(p.read_text())
assert len(sys.argv)==3
cfg=json.loads((R/'n3-final-review-config.json').read_text())
base=checked(cfg['accepted_physical_machine_base'])
p=N/'execution-release.json';rr=ref(p);assert rr['sha256']==sys.argv[1]
x=json.loads(p.read_text());late={'status','runtime_release','fresh_live_preflight'}
assert set(x)==set(base) and all(x[k]==base[k] for k in base if k not in late)
assert x['status']=='PASS_EXECUTION_RELEASE' and x['runtime_release']is True
assert type(x['execution_count'])is int and x['execution_count']==1
f=x['fresh_live_preflight'];assert set(f)=={'path','sha256'} and f['path']==str(N/'root-live-preflight-1.json')
s=checked(f);age=time.time()-s['time_epoch'];assert 0<=age<=60
assert s['status']=='PASS_LIVE_PREEXECUTION_SNAPSHOT' and s['exclusive_heavy_accepted']is True and s['root_mutex_snapshot_free']is True
assert s['parent_identity']==x['parent_identity']=={'device':1828,'inode':629647,'uid':1000,'gid':1000,'mode':'0o700'}
assert s['terminal_acceptance']['path']==cfg['raw_terminal']['path'] and s['terminal_acceptance']['sha256']==cfg['raw_terminal']['sha256']
assert s['independent_static_execution_decision']['sha256']=='233c7c6cff5e0c8be5e8941b031b87e7515d5d1de3f699dbe1a18acec111b0e1'
assert s['non_temporal_join_result']['path']==str(N/'actual-consumer-parent-result.json') and s['non_temporal_join_result']['sha256']=='e5b384e8e60e48bbfa157d0db8861c2f34ce11d8bc246e54733902395c2dfe15'
assert s['guest_profile']=={'memory_mib':8192,'vcpus':4,'numa_nodes':2}
assert s['heavy_profile']=={'cpuset':'2-5','cpus':4,'memory':12884901888,'memory_swap':12884901888,'pids':512,'network':'none'}
status_path=Path(sys.argv[2]);assert status_path.parent==N
status=json.loads(status_path.read_text());assert status.get('returncode',status.get('exit_code'))==0
assert status.get('direct_join',status.get('direct_child_joined',status.get('joined')))is True
argv=['/home/holden/anaconda3/bin/python3','-I','-B',str(N/'dispatch-runtime.py'),'--release',str(p),'--release-sha256',rr['sha256']]
d={'schema':'mckernel.independent-two-cpu-n3-final-execution-release.v1','status':'PASS_EXACT_N3_ONE_SHOT_NATIVE_EXECUTION_RELEASE','reviewer':'two_cpu_end_to_end_review','execution_release':rr,'snapshot':f,'snapshot_actual_status':ref(status_path),'snapshot_age_seconds_at_review':age,'accepted_nontemporal_review':cfg['nontemporal_review'],'independent_current_physical_acceptance':cfg['physical_review'],'accepted_physical_machine_base':cfg['accepted_physical_machine_base'],'only_three_approved_late_fields_changed':True,'execution_count':1,'runtime_release':True,'native_application_acceptance':False,'launch_argv':argv,'conditions':'Immediate root sole-heavy dispatch; wrapper still enforces snapshot<=60s and exactunusedparent/freshpaths. Accepted ownerretirement and three boundedpostjoinreadbacks unchanged. Stop/preserve anyfailure; no retry/cleanup inferred.'}
out=R/'decision-final-native-n3-execution-release.json'
with out.open('x')as stream:json.dump(d,stream,sort_keys=True,separators=(',',':'));stream.write('\n')
print(json.dumps({'status':d['status'],'decision':ref(out),'execution_release_sha256':rr['sha256'],'snapshot_age_seconds':age,'launch_argv':argv}))
