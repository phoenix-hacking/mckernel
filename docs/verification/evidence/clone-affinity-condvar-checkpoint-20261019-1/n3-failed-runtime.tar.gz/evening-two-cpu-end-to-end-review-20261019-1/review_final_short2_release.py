"""Independent completed-artifact review only; no runtime/test/privileged effects."""
from pathlib import Path
import hashlib,json,sys,time
N=Path('/home/holden/mckernel-work/host-preparation/evening-two-app-batch-20261019-1/two-cpu-end-to-end-1/native-owner-short-2')
R=Path(__file__).resolve().parent
EXPECTED_BASE='f40fdda958ec6cb84685ab84b2cc624df7fd4cbd3e9305f1df7eb2ae229f6005'
EXPECTED_REVIEW='87331323580d10f5453962b88b7e1c25253e8d9899640ee18946e6d086718de9'
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def checked(row):
    p=Path(row['path']);assert ref(p)['sha256']==row['sha256'];return json.loads(p.read_text())
assert len(sys.argv)==2
p=N/'execution-release.json';rr=ref(p);assert rr['sha256']==sys.argv[1]
base=checked({'path':str(N/'machine-release-PENDING.json'),'sha256':EXPECTED_BASE})
x=json.loads(p.read_text());late={'status','runtime_release','fresh_live_preflight'}
assert set(x)==set(base) and all(x[k]==base[k] for k in base if k not in late)
assert x['status']=='PASS_EXECUTION_RELEASE' and x['runtime_release'] is True
assert type(x['execution_count'])is int and x['execution_count']==1
f=x['fresh_live_preflight'];assert set(f)=={'path','sha256'} and f['path']==str(N/'root-live-preflight-1.json')
s=checked(f);age=time.time()-s['time_epoch'];assert 0<=age<=60
assert s['status']=='PASS_LIVE_PREEXECUTION_SNAPSHOT' and s['exclusive_heavy_accepted']is True and s['root_mutex_snapshot_free']is True
assert s['parent_identity']==x['parent_identity']=={'device':1828,'inode':757494,'uid':1000,'gid':1000,'mode':'0o700'}
assert s['terminal_acceptance']['sha256']=='6822249f8d43e788a10e45753dfd5e4a702be2e407d06bcc84ed094ea76bc850'
assert s['independent_static_execution_decision']['sha256']=='a0c86d0cb074260618563417e5456c9c63397c63bd6cc2e2ae7902de6a2fb73c'
assert s['non_temporal_join_result']['path']==str(N/'actual-path-check-result.json') and s['non_temporal_join_result']['sha256']=='f04419a5f3b6acfed59c5a591ec00f47dc85f2db00eaf30047ce1341b733b1d4'
assert s['guest_profile']=={'memory_mib':8192,'vcpus':4,'numa_nodes':2}
assert s['heavy_profile']=={'cpuset':'2-5','cpus':4,'memory':12884901888,'memory_swap':12884901888,'pids':512,'network':'none'}
checked({'path':str(R/'decision-short-parent2-source-actual.json'),'sha256':EXPECTED_REVIEW})
argv=['/home/holden/anaconda3/bin/python3','-I','-B',str(N/'dispatch-runtime.py'),'--release',str(p),'--release-sha256',rr['sha256']]
d={'status':'PASS_EXACT_SHORT_PARENT_ONE_SHOT_NATIVE_EXECUTION_RELEASE','reviewer':'two_cpu_end_to_end_review','execution_release':rr,'snapshot':f,'snapshot_age_seconds_at_review':age,'affected_source_actual_decision':{'path':str(R/'decision-short-parent2-source-actual.json'),'sha256':EXPECTED_REVIEW},'only_three_approved_late_fields_changed':True,'execution_count':1,'runtime_release':True,'native_application_acceptance':False,'launch_argv':argv,'conditions':'Immediate sole-heavy launch; dispatcher still enforces snapshot<=60s and exact actualparent/freshpaths. Existing owner retirement and three bounded postjoin readbacks unchanged. Failure preserves evidence and stops; no replay/cleanup authority.'}
out=R/'decision-final-native-short2-execution-release.json'
with out.open('x')as stream:json.dump(d,stream,sort_keys=True,separators=(',',':'));stream.write('\n')
print(json.dumps({'status':d['status'],'decision':ref(out),'execution_release_sha256':rr['sha256'],'snapshot_age_seconds':age}))
