"""One independent completed-machine check; never invokes root, owner or guest."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import stat
import time

R = Path(__file__).resolve().parent
N = Path('/home/holden/mckernel-work/host-preparation/evening-fourleaf-native-continuation-20261019-1/next-condvar-timeout-preparation-1/native-final-preparation-1')
HANDOFF_SHA = '969b88b7ad712db966350b9781e82cad1ae6cdef90c9fb9d2a69e68c044198c6'
OUT = R / 'native-final-machine-release-review.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_fd(path, root=False):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        if root:
            assert before.st_uid == before.st_gid == 0
            assert stat.S_IMODE(before.st_mode) == 0o644
        data = bytearray()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            data.extend(chunk)
            assert len(data) <= 1024 * 1024
        after = os.fstat(fd)
        keys = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mode',
                'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        assert all(getattr(before, k) == getattr(after, k) for k in keys)
        assert len(data) == after.st_size
        return bytes(data), after
    finally:
        os.close(fd)


def checked(row, root=False):
    data, info = read_fd(row['path'], root)
    assert sha(data) == row['sha256']
    for key in ('bytes', 'size'):
        if key in row:
            assert len(data) == row[key]
    return json.loads(data), data, info


def ref(path, data):
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def command_status(path, argv):
    obj, raw, _ = checked(dict(path=str(path), sha256=sha(Path(path).read_bytes())))
    assert obj['argv'] == argv and obj['cwd'] == str(N)
    assert type(obj['returncode']) is int and obj['returncode'] == 0
    assert obj['direct_child_joined'] is True
    if 'owned_process_group_empty' in obj:
        assert obj['owned_process_group_empty'] is True
    assert type(obj['pid']) is int and obj['pid'] > 0
    assert obj['start_ns'] <= obj['finish_ns'] <= time.time_ns()
    streams = {}
    for name in ('stdout', 'stderr'):
        row = obj[name]
        data, _ = read_fd(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        streams[name] = data
    assert streams['stderr'] == b''
    return obj, json.loads(streams['stdout']), ref(path, raw)


def main():
    ap = argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--machine-sha256', required=True)
    ap.add_argument('--snapshot-status', required=True)
    ap.add_argument('--assembly-status', required=True)
    args = ap.parse_args()
    assert os.getuid() == os.geteuid() == 1000 and not os.path.lexists(OUT)
    handoff, _, _ = checked(dict(path=str(N / 'final-nontemporal-late-N3-ready-1.json'), sha256=HANDOFF_SHA))
    request, _, _ = checked(handoff['source_request'])
    for key in ('conditional_source_review', 'static_envelope_review',
                'actual_stage_fixture_parent_review', 'authoritative_late_data_peerdecision'):
        checked(handoff[key])
    for row in request['sources'].values():
        data, _ = read_fd(row['path'])
        assert sha(data) == row['sha256'] and len(data) == row['size']
    binding, _, _ = checked(request['binding'])
    proposal, _, _ = checked(request['proposal'])
    template, _, _ = checked(request['machine_template'])
    manifest, _, _ = checked(binding['manifest'])
    assert binding['manifest'] == proposal['manifest']
    assert manifest['payload'] == proposal['payload_contract']
    assert manifest['artifacts']['payload'] == proposal['payload']
    assert manifest['artifacts']['mckernel_image'] == proposal['mckernel_image']
    assert manifest['staging']['overlay_manifest'] == proposal['consumer_overlay_metadata']
    physical, _, _ = checked(handoff['latest_physical_predecessor'])
    late, _, _ = checked(handoff['late_physical_binding'])
    checked(handoff['separate_historical_image_cleanup'])
    assert late['independent_physical_review'] == handoff['latest_physical_predecessor']
    assert physical['physical_release'] is True and physical['container_absent'] is True
    assert physical['lease_retained'] is False and physical['owned_groups_empty'] is True
    assert physical['container_id'] == late['retired_container_id']
    terminal, _, _ = checked(late['raw_terminal'])
    assert terminal['container'] == physical['container_id']
    assert terminal['absence_verified'] is True and terminal['lease_retained'] is False
    assert terminal['status'] == 'FAIL' and terminal['application_acceptance'] is False
    sp = N / 'root-live-preflight-1.json'
    pp = N / 'root-snapshot-publication-1.json'
    mp = N / 'machine-execution-release-1.json'
    snapshot_raw, snapshot_stat = read_fd(sp, root=True)
    publication_raw, publication_stat = read_fd(pp, root=True)
    snap = json.loads(snapshot_raw)
    publication = json.loads(publication_raw)
    snapref = dict(path=str(sp), sha256=sha(snapshot_raw))
    pubref = dict(path=str(pp), sha256=sha(publication_raw))
    desc = publication['snapshot']
    assert desc == dict(path=str(sp), sha256=sha(snapshot_raw), bytes=len(snapshot_raw),
                        device=snapshot_stat.st_dev, inode=snapshot_stat.st_ino,
                        uid=0, gid=0, mode=0o644, nlink=1)
    assert publication['status'] == 'PASS_ROOT_FD_PUBLISHED_READABLE_SNAPSHOT'
    assert publication['root_readback_bytes_equal'] is True
    assert publication['dispatcher_other_read_bit'] is True
    assert publication['owner_or_guest_invoked'] is False
    assert snap['status'] == 'PASS_LIVE_PREEXECUTION_SNAPSHOT'
    assert snap['exclusive_heavy_accepted'] is True and snap['root_mutex_snapshot_free'] is True
    assert snap['boot_id'] == binding['boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    assert snap['snapshot_static_bindings'] == dict(path=request['binding']['path'], sha256=request['binding']['sha256'])
    assert snap['terminal_acceptance'] == snap['exclusive_queue_predecessor'] == handoff['latest_physical_predecessor']
    assert snap['late_physical_binding'] == handoff['late_physical_binding']
    assert snap['released_paths_absent'] == late['released_paths']
    assert all(not os.path.lexists(p) for p in late['released_paths'])
    assert snap['independent_static_execution_decision'] == handoff['static_envelope_review']
    assert snap['accepted_actual_stage_fixture_parent_review'] == binding['ordinary_acceptance']
    assert snap['heavy_profile'] == proposal['profile']
    assert snap['mem_available_bytes'] >= 16 * 2**30 and snap['included_usage_percent'] < 97
    for path, floor in (('/home/holden/mckernel', 16 * 2**30),
                        ('/home/holden/mckernel-work/scratch', 12 * 2**30)):
        capacity = snap['capacity'][path]
        assert capacity['floor_bytes'] == floor and capacity['reserve_bytes'] == 640 * 2**20
        assert capacity['available_bytes'] >= floor + 640 * 2**20
    age = time.time() - snap['time_epoch']
    assert 0 <= age <= 60
    snapshot_status, snapshot_stdout, snapshot_status_ref = command_status(args.snapshot_status, handoff['root_snapshot_argv'])
    assert snapshot_status['start_ns'] / 1e9 <= snap['time_epoch'] <= snapshot_status['finish_ns'] / 1e9
    assert snapshot_stdout['status'] == snap['status'] and snapshot_stdout['snapshot'] == desc
    published = snapshot_stdout['publication']
    assert published == dict(path=str(pp), sha256=sha(publication_raw), bytes=len(publication_raw),
                             device=publication_stat.st_dev, inode=publication_stat.st_ino,
                             uid=0, gid=0, mode=0o644, nlink=1)
    assembly_argv = handoff['UID1000_assembly_argv'].copy()
    assembly_argv[assembly_argv.index('--snapshot-sha256') + 1] = snapref['sha256']
    assembly_argv[assembly_argv.index('--publication-sha256') + 1] = pubref['sha256']
    assembly_status, assembly_stdout, assembly_status_ref = command_status(args.assembly_status, assembly_argv)
    assert snapshot_status['finish_ns'] <= assembly_status['start_ns']
    machine, machine_raw, machine_stat = checked(dict(path=str(mp), sha256=args.machine_sha256))
    assert machine_stat.st_uid == machine_stat.st_gid == 1000
    expected = dict(template)
    expected.update(status='PASS_EXECUTION_RELEASE', runtime_release=True,
                    fresh_live_preflight=snapref, snapshot_publication=pubref,
                    independent_static_execution_decision=snap['independent_static_execution_decision'],
                    accepted_actual_stage_fixture_parent_review=snap['accepted_actual_stage_fixture_parent_review'],
                    terminal_cleanup_and_common_shared_release=dict(status='PASS', ref=snap['terminal_acceptance']),
                    exclusive_queue_predecessor=dict(status='PASS_POSITIVE_PHYSICAL_RELEASE_INDEPENDENTLY_ACCEPTED',
                                                     ref=snap['exclusive_queue_predecessor'], image_matching_required=False),
                    unprivileged_snapshot_readback=dict(uid=1000, snapshot_device=snapshot_stat.st_dev,
                                                       snapshot_inode=snapshot_stat.st_ino, root_owned_readable0644=True))
    assert machine == expected and type(machine['execution_count']) is int and machine['execution_count'] == 1
    assert assembly_stdout['status'] == 'READY_EXACT_MACHINE_PENDING_EXTERNAL_EXECUTION_DECISION'
    assert assembly_stdout['path'] == str(mp) and assembly_stdout['sha256'] == args.machine_sha256
    assert 0 <= assembly_stdout['snapshot_age_seconds'] <= 60
    identity = binding['parent_identity']
    assert identity == machine['parent_identity'] == snap['parent_identity'] == proposal['parent']['identity']
    parent = Path(proposal['parent']['path'])
    fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        assert identity == dict(device=info.st_dev, inode=info.st_ino, uid=info.st_uid,
                                gid=info.st_gid, mode=oct(stat.S_IMODE(info.st_mode)))
        assert parent.resolve(strict=True) == parent and os.listdir(fd) == []
    finally:
        os.close(fd)
    assert proposal['nonce'] == binding['nonce'] == '504dc644f5e6f8c28620cd6b087181c0'
    assert all(len(os.fsencode(e['path'])) == e['encoded_bytes'] <= 107 for e in proposal['unix_monitor_endpoints'])
    assert not os.path.lexists(str(parent) + '.owner-' + proposal['nonce'])
    for name in ('owner.stdout', 'owner.stderr', 'owner-join.json'):
        assert not os.path.lexists(N / name)
    allowed = ['/home/holden/anaconda3/bin/python3', '-I', '-B', str(N / 'dispatch-runtime.py'),
               '--release', str(mp), '--release-sha256', args.machine_sha256]
    age = time.time() - snap['time_epoch']
    assert 0 <= age <= 60
    decision = dict(schema='mckernel.independent-condvar-timeout-native-exact-machine-release-review.v1',
                    decision='PASS_EXACT_CONDVAR_TIMEOUT_MACHINE_RELEASE_AND_OWNER_INVOCATION',
                    reviewer='condvar_timeout_source_review', machine_release=ref(mp, machine_raw),
                    machine_projection_sha256=sha((json.dumps(machine, sort_keys=True, separators=(',', ':')) + '\n').encode()),
                    allowed_argv=allowed, snapshot_time_epoch=snap['time_epoch'], snapshot_age_seconds_at_review=age,
                    snapshot_actual_status=snapshot_status_ref, assembly_actual_status=assembly_status_ref,
                    latest_physical_review=handoff['latest_physical_predecessor'],
                    accepted_late_data_review=handoff['authoritative_late_data_peerdecision'],
                    independent_checker_source=ref(Path(__file__), Path(__file__).read_bytes()),
                    approved_template_with_only_exact_late_fields=True, execution_count=1,
                    runtime_release=True, native_application_acceptance=False,
                    conditions='Immediate sole-heavy finalguard invocation within original60s; no retry or cleanup authority.')
    with OUT.open('x') as stream:
        json.dump(decision, stream, sort_keys=True, separators=(',', ':'))
        stream.write('\n')
    print(json.dumps(dict(decision=ref(OUT, OUT.read_bytes()), snapshot_age_seconds=age, allowed_argv=allowed)))


if __name__ == '__main__':
    main()
