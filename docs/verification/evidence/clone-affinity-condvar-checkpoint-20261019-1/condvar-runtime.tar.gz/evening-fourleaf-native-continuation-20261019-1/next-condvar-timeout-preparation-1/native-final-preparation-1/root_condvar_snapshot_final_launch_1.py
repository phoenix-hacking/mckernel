from pathlib import Path
import os,json,hashlib,subprocess,time,stat
N=Path(__file__).resolve().parent
R=Path('/home/holden/mckernel-work/host-preparation/condvar-timeout-source-review-20261019-1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,d):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w')as f:json.dump(d,f,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def run(role,argv):
 base=N/role;base.mkdir(mode=0o700);outp=base/'stdout';errp=base/'stderr';sp=base/'status.json';put(base/'command.json',dict(argv=argv,cwd=str(N)));t=time.monotonic();start_ns=time.time_ns();error=None;tick=None
 with outp.open('xb')as out,errp.open('xb')as err:
  child=subprocess.Popen(argv,cwd=N,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:tick=Path('/proc/'+str(child.pid)+'/stat').read_text().rsplit(')',1)[1].split()[19];put(base/'child.json',dict(pid=child.pid,start=tick,argv=argv))
  except BaseException as e:error=repr(e)
  finally:rc=child.wait()
  finish_ns=time.time_ns();out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno());held={k:ident(os.fstat(f.fileno()))for k,f in [('stdout',out),('stderr',err)]}
 streams={}
 for k,p in [('stdout',outp),('stderr',errp)]:
  fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
  try:
   ss=os.fstat(fd);assert ident(ss)==held[k]==ident(p.stat());assert stat.S_ISREG(ss.st_mode)and ss.st_uid==1000 and ss.st_nlink==1 and stat.S_IMODE(ss.st_mode)==0o600
   with os.fdopen(os.dup(fd),'rb')as f:h=hashlib.sha256(f.read()).hexdigest()
   streams[k]=dict(path=str(p),sha256=h,bytes=ss.st_size,metadata=ident(ss))
  finally:os.close(fd)
 row=dict(argv=argv,cwd=str(N),pid=child.pid,start=tick,start_ns=start_ns,finish_ns=finish_ns,returncode=rc,direct_child_joined=True,observer_error=error,elapsed_seconds=time.monotonic()-t,stdout=streams['stdout'],stderr=streams['stderr']);put(sp,row)
 assert rc==0 and error is None,(role,rc,error)
 return row
os.umask(0o077);assert os.getuid()==1000
ready=N/'final-nontemporal-late-N3-ready-1.json';assert sha(ready)=='969b88b7ad712db966350b9781e82cad1ae6cdef90c9fb9d2a69e68c044198c6';d=json.loads(ready.read_text());assert sha(R/'review_final_condvar_machine.py')=='89bdad699fbe5f623d994cb3d832f0063c29c22499bd8e9a5feef212340b5128'
assert not(N/'root-live-preflight-1.json').exists()and not(N/'machine-execution-release-1.json').exists()
run('root-snapshot-execution-1',d['root_snapshot_argv'])
argv=d['UID1000_assembly_argv'];argv[argv.index('--snapshot-sha256')+1]=sha(N/'root-live-preflight-1.json');argv[argv.index('--publication-sha256')+1]=sha(N/'root-snapshot-publication-1.json');run('assembly-execution-1',argv)
checker=json.loads((R/'native-final-checker-ready.json').read_text())['argv'];checker=[sha(N/'machine-execution-release-1.json')if x=='ACTUAL_MACHINE_EXECUTION_RELEASE_FILE_SHA256'else x for x in checker];run('independent-final-check-execution-1',checker)
result=json.loads((N/'independent-final-check-execution-1/stdout').read_text());review=result['decision'];argv=d['launch_guard_argv'];argv[-2]=review['path'];argv[-1]=review['sha256']
run('runtime-execution-1',argv)
print('Condvar ownerwrapper wholejoined0; completed captures ready',flush=True)
