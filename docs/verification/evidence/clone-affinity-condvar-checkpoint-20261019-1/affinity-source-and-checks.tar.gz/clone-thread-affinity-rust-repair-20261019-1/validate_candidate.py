from pathlib import Path
import hashlib,json,re
b=Path(__file__).parent;r=Path('/home/holden/mckernel')
base=json.loads((b/'input-bindings-current.json').read_text())['files']
patch=(b/'candidate.patch').read_text().splitlines(True)
actual={};i=0
while i<len(patch):
 assert patch[i].startswith('--- a/');name=patch[i][6:].strip();i+=1
 assert patch[i]=='+++ b/'+name+'\n';i+=1
 assert name in base
 source=(r/name).read_bytes();assert hashlib.sha256(source).hexdigest()==base[name]['sha256'],name
 lines=source.decode().splitlines(True);out=[];cursor=0;hunks=0
 while i<len(patch) and not patch[i].startswith('--- a/'):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',patch[i]);assert m,patch[i]
  start=int(m[1])-1;out.extend(lines[cursor:start]);cursor=start;i+=1;hunks+=1
  while i<len(patch) and patch[i][:1] in [' ','+','-'] and not patch[i].startswith('--- a/'):
   op,text=patch[i][0],patch[i][1:]
   if op in [' ','-']:assert lines[cursor]==text,(name,cursor);cursor+=1
   if op in [' ','+']:out.append(text)
   i+=1
 out.extend(lines[cursor:]);candidate=''.join(out).encode();assert candidate==(b/'source'/name).read_bytes(),name
 actual[name]={'sha256':hashlib.sha256(candidate).hexdigest(),'base_sha256':base[name]['sha256'],'hunks':hunks,'bytes':len(candidate)}
assert len(actual)==3
s=(b/'source/kernel/rust/process_helpers.rs').read_text();assert s.count('crate::sched_helpers::sched_clone_affinity_inherit_result(')==1
s=(b/'source/kernel/rust/sched_helpers.rs').read_text();lo=s.index('pub unsafe extern "C" fn sched_clone_affinity_inherit_result');hi=s.index('#[no_mangle]',lo);body=s[lo:hi];assert body.count('sched_affinity_lock()')==1 and body.count('sched_affinity_unlock(irqstate)')==1
c=(b/'source/kernel/syscall.c').read_text();lo=c.index('unsigned long do_fork(');assert c.index('newproc = new->proc;',lo)<c.index('if (inherit_clone_affinity',lo)
f=(b/'checks/actual.rs').read_text();assert f.count('crate::sched_helpers::sched_clone_affinity_inherit_result(')==1
assert f.count('let irqstate = unsafe { sched_affinity_lock() };')==3
(b/'final-source-coherence.json').write_text(json.dumps({'status':'PASS_EXACT_PATCH_RECONSTRUCTION_CURRENT_BASIS','files':actual,'fixture_has_actual_locked_basecopy':True,'guest_runs':0},indent=2)+'\n')
