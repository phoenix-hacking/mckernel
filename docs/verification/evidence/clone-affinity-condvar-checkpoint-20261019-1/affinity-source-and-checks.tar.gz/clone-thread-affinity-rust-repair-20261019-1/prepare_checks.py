from pathlib import Path
import re,json,hashlib
b=Path(__file__).parent;r=Path('/home/holden/mckernel');o=b/'checks';o.mkdir(exist_ok=True)
rs=(b/'source/kernel/rust/sched_helpers.rs').read_text();c=(b/'source/kernel/syscall.c').read_text();arch=(r/'arch/x86_64/kernel/syscall.c').read_text()
def fn(s,name,lang='rust'):
 if lang=='rust':m=re.search(r'^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\b',s,re.M)
 else:m=re.search(r'^int '+name+r'\b',s,re.M)
 assert m,name
 start=m.start();pos=s.index('{',m.end());depth=1;end=pos+1
 while depth:
  depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[start:end]
def struct(s,name):
 m=re.search(r'pub struct '+name+r'\s*\{[^}]*\}',s,re.S);assert m;return '#[repr(C)]\n'+m.group()
rsout='''#![allow(dead_code)]
use core::ptr::{read_volatile,write_volatile};
use core::ffi::c_void;
type CInt=i32; type CLong=i64; type CULong=u64; type SizeT=usize; type IhkSpinlock=u32;
const EINVAL:CInt=22;const EFAULT:CInt=14;const ESRCH:CInt=3;const EPERM:CInt=1;
extern "C" {static mut runq_reservation_lock:IhkSpinlock;
#[link_name="process_spin_lock_bridge"] fn process_spin_lock_bridge_c(addr:CULong)->CULong;
#[link_name="process_spin_unlock_bridge"] fn process_spin_unlock_bridge_c(addr:CULong,state:CULong);}
'''
for name in ['SchedFindThreadFn','SchedThreadUnlockFn','SchedHoldThreadFn','SchedReleaseThreadFn','SchedCopyFromUserFn','SchedRequestMigrateFn']:
 m=re.search(r'^type '+name+r'\s*=[\s\S]*?;',rs,re.M);assert m,name;rsout+=m.group()+'\n'
rsout+=struct(rs,'SchedSyscallOffsets')+'\n'
names=['sched_affinity_permission_result','sched_affinity_copy_len','sched_errno','sched_read_usize','sched_read_int','sched_thread_proc','sched_thread_cpu_id','sched_proc_ruid','sched_proc_euid','sched_cpuset_zero','sched_cpuset_copy','sched_cpuset_is_set','sched_cpuset_set','sched_affinity_select_thread','sched_affinity_lock','sched_affinity_unlock','sched_clone_affinity_snapshot_result','sched_clone_affinity_inherit_result','sched_setaffinity_body_result']
for n in names:
 body=fn(rs,n);rsout+=('#[no_mangle]\n' if n in ['sched_clone_affinity_snapshot_result','sched_clone_affinity_inherit_result','sched_setaffinity_body_result'] else '')+body+'\n'
rsout+='mod sched_helpers { pub use super::sched_clone_affinity_inherit_result; }\n'
rsout+='#[no_mangle]\n'+fn((b/'source/kernel/rust/process_helpers.rs').read_text(),'process_clone_thread_base_state_body_result')+'\n'
(o/'actual.rs').write_text(rsout)
# Do not inject prototypes for candidate exports: use the exact production declarations.
start=c.index('#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS\nextern int sched_clone_affinity_snapshot_result');end=c.index('\nunsigned long do_fork(',start);decls=c[start:end]
start=c.index('\tif (helper_thread) {',end);end=c.index('\n\tnew = clone_thread(',start);placement=c[start:end]
start=c.index('#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS\n    if (inherit_clone_affinity');end=c.index('\n#endif',start)+len('\n#endif');inherit=c[start:end]
common='''#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define CLONE_THREAD 0x10000
#define CPU_STATUS_RESERVED 1
#define dkprintf(...) ((void)0)
#define CPU_ISSET(cpu,set) (((set)->bits[(cpu)/64] >> ((cpu)%64)) & 1UL)
typedef struct { unsigned long bits[2]; } cpu_set_t;
struct process {cpu_set_t cpu_set;int uti_thread_rank;int uti_use_last_cpu;};
struct thread {cpu_set_t cpu_set;struct process*proc;int cpu_id;int mod_clone;int in_kernel;};
struct cpu_local_var {int runq_len,runq_reserved,runq_lock,status;};
int num_processors=2;unsigned int runq_reservation_lock;static int held,locks,unlocks,holds,releases,migrations;
static struct cpu_local_var cpus[128];
static unsigned long ihk_mc_spinlock_lock(unsigned int *p){if(p==&runq_reservation_lock){assert(!held);held=1;locks++;}return 123;}
static void ihk_mc_spinlock_unlock(unsigned int*p,unsigned long flags){assert(flags==123);if(p==&runq_reservation_lock){assert(held);held=0;unlocks++;}}
static void ihk_mc_spinlock_lock_noirq(int*p){(void)p;assert(held);}
static void ihk_mc_spinlock_unlock_noirq(int*p){(void)p;assert(held);}
static struct cpu_local_var*get_cpu_local_var(int c){assert(c>=0&&c<num_processors);return &cpus[c];}
static int ihk_mc_get_processor_id(void){return 0;}
static int clone_use_last_cpu_result(int mod,int use){return mod&&use;}
static void kprintf(const char*f,...){(void)f;}
unsigned long process_spin_lock_bridge(unsigned long p){return ihk_mc_spinlock_lock((unsigned int*)p);}
void process_spin_unlock_bridge(unsigned long p,unsigned long s){ihk_mc_spinlock_unlock((unsigned int*)p,s);}
'''
consumer=common+decls+'\n'+fn(arch,'obtain_clone_cpuid','c')+'''
static long actual_consumer(struct thread*old,int clone_flags,int helper_thread,int mutate){
 struct process*oldproc=old->proc;struct thread child=*old;struct thread*new=&child;
 int cpuid=-1,err=0;cpus[0].runq_reserved=cpus[1].runq_reserved=0;
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 cpu_set_t clone_cpu_set;int inherit_clone_affinity=0;
#endif
'''+placement+'''
 if(mutate) old->cpu_set.bits[0]=1;
'''+inherit+'''
 assert(!held);
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 if(inherit_clone_affinity) assert(new->cpu_set.bits[0]==2);
#endif
 return cpuid;
destroy_thread: return err;
}
int main(void){struct process p={.cpu_set={{3,0}}};struct thread t={.cpu_set={{2,0}},.proc=&p,.cpu_id=1};
 cpus[1].runq_len=1;long result=actual_consumer(&t,CLONE_THREAD,0,1);
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 assert(result==1); assert(locks==3&&unlocks==3); /* snapshot, reservation, private final copy */
#else
 assert(result==0); assert(locks==1&&unlocks==1); /* retained failing route control */
#endif
 t.cpu_set.bits[0]=2;p.uti_thread_rank=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 p.uti_thread_rank=0;t.mod_clone=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 t.mod_clone=0;p.uti_use_last_cpu=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 p.uti_use_last_cpu=0;assert(actual_consumer(&t,0,0,0)==0);
 assert(actual_consumer(&t,CLONE_THREAD,1,0)==0);assert(!held&&locks==unlocks);
 puts("actual selected/fallback consumer PASS");return 0;}
'''
consumer=consumer.replace('static ', '')
(o/'consumer.c').write_text(consumer)
# Exact exported declaration from source, not a hand-written prototype.
setstart=c.index('extern long sched_setaffinity_body_result(');setend=c.index(';',setstart)+1
# Existing production declaration depends on these original ABI callback names.
types='''typedef unsigned long (*sched_find_thread_fn_t)(int);typedef void(*sched_thread_unlock_fn_t)(unsigned long);typedef void(*sched_hold_thread_fn_t)(unsigned long);typedef void(*sched_release_thread_fn_t)(unsigned long);typedef int(*syscall_copy_from_user_fn_t)(void*,unsigned long,size_t);typedef void(*sched_request_migrate_fn_t)(int,unsigned long);
struct sched_syscall_offsets{size_t thread_proc_offset,thread_sched_param_offset,thread_sched_policy_offset,thread_cpu_id_offset,thread_cpu_set_offset,proc_pid_offset,proc_ruid_offset,proc_euid_offset,proc_cpu_set_offset;};
'''
h=(r/'kernel/include/process_helpers.h').read_text();q=re.search(r'int process_clone_thread_base_state_body_result\([^;]*;',h,re.S);assert q
base_decl=q.group()+'\n'
types=''
for alias in ['sched_find_thread_fn_t','sched_thread_unlock_fn_t','sched_hold_thread_fn_t','sched_release_thread_fn_t','syscall_copy_from_user_fn_t','sched_request_migrate_fn_t']:
 hit=re.search(r'typedef[^;]*\b'+alias+r'\b[^;]*;',c,re.S);assert hit,alias;types+=hit.group()+'\n'
hit=re.search(r'struct sched_syscall_offsets\s*\{[^}]*\};',c,re.S);assert hit;types+=hit.group()+'\n'
mask=common+'#define MCKERNEL_RUST_SCHED_POLICY_HELPERS\n'+decls+types+base_decl+c[setstart:setend]+'''
static int hold(unsigned long t){assert(t);holds++;return 0;}static void release(unsigned long t){assert(t&&!held);releases++;}
static long copyfrom(void*d,unsigned long s,size_t n){memcpy(d,(void*)s,n);return 0;}
static void migrate(int cpu,unsigned long t){assert(cpu==0&&t&&!held);migrations++;}
int main(void){cpu_set_t a,b,out,child;unsigned cases=0;
 for(unsigned x=0;x<16;x++)for(unsigned y=0;y<16;y++){a=(cpu_set_t){{x,0}};b=(cpu_set_t){{y,0}};out=(cpu_set_t){{~0UL,~0UL}};
 int r=sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,4);
 assert(r==((x&y)?0:-EINVAL));assert(out.bits[0]==(x&y)&&out.bits[1]==0);assert(a.bits[0]==x&&b.bits[0]==y);assert(!held);cases++;}
 a=(cpu_set_t){{0,1UL<<55}};b=a;assert(!sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,120));assert(out.bits[1]==(1UL<<55));
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,119)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,1,1)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result(0,(unsigned long)&b,(unsigned long)&out,sizeof out,2)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,0,2)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,8,65)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,16,0)==-EINVAL);
 out=(cpu_set_t){{2,0}};child=(cpu_set_t){{1,0}};assert(!sched_clone_affinity_inherit_result((unsigned long)&child,(unsigned long)&out,sizeof out));assert(child.bits[0]==2);
 assert(sched_clone_affinity_inherit_result(0,(unsigned long)&out,sizeof out)==-EINVAL);
 struct thread origin={.cpu_set={{2,0}},.in_kernel=7},created={0};
 assert(!process_clone_thread_base_state_body_result(&created,&origin,offsetof(struct thread,cpu_set),sizeof origin.cpu_set,offsetof(struct thread,in_kernel)));
 assert(created.cpu_set.bits[0]==2&&created.in_kernel==7&&!held);
 created.cpu_set.bits[0]=1;origin.in_kernel=9;
 assert(!process_clone_thread_base_state_body_result(&created,&origin,offsetof(struct thread,cpu_set),0,offsetof(struct thread,in_kernel)));
 assert(created.cpu_set.bits[0]==1&&created.in_kernel==9&&!held);
 assert(process_clone_thread_base_state_body_result(0,&origin,offsetof(struct thread,cpu_set),sizeof origin.cpu_set,offsetof(struct thread,in_kernel))==-EINVAL);
 struct process p={.cpu_set={{3,0}}};struct thread t={.cpu_set={{1,0}},.proc=&p,.cpu_id=0};
 struct sched_syscall_offsets offsets={.thread_proc_offset=offsetof(struct thread,proc),.thread_cpu_id_offset=offsetof(struct thread,cpu_id),.thread_cpu_set_offset=offsetof(struct thread,cpu_set),.proc_cpu_set_offset=offsetof(struct process,cpu_set)};
 cpu_set_t request={{2,0}},scratch,eligible;long ret=sched_setaffinity_body_result(0,sizeof request,(unsigned long)&request,(unsigned long)&t,(unsigned long)&scratch,(unsigned long)&eligible,sizeof request,2,&offsets,0,0,hold,release,copyfrom,migrate);
 assert(ret==0&&t.cpu_set.bits[0]==2&&migrations==1&&holds==1&&releases==1);assert(!held&&locks==unlocks);
 request.bits[0]=4;ret=sched_setaffinity_body_result(0,sizeof request,(unsigned long)&request,(unsigned long)&t,(unsigned long)&scratch,(unsigned long)&eligible,sizeof request,2,&offsets,0,0,hold,release,copyfrom,migrate);
 assert(ret==-EINVAL&&holds==2&&releases==2&&!held&&locks==unlocks);
 printf("mask cases=%u high-tail/errors/publication/migration PASS\\n",cases);return 0;}
'''
mask=mask.replace('static ', '')
(o/'masks.c').write_text(mask)
(o/'linux.c').write_text('''#define _GNU_SOURCE
#include <assert.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
static cpu_set_t expected;
static void *child(void*x){(void)x;cpu_set_t seen;assert(!sched_getaffinity(0,sizeof seen,&seen));assert(CPU_EQUAL(&seen,&expected));assert(CPU_ISSET(sched_getcpu(),&expected));return 0;}
int main(void){cpu_set_t before;assert(!sched_getaffinity(0,sizeof before,&before));int cpu=-1;for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&before)){cpu=i;break;}assert(cpu>=0);CPU_ZERO(&expected);CPU_SET(cpu,&expected);assert(!sched_setaffinity(0,sizeof expected,&expected));pthread_t t;assert(!pthread_create(&t,0,child,0));assert(!pthread_join(t,0));assert(!sched_setaffinity(0,sizeof before,&before));puts("Linux creator-mask inheritance before child bind PASS");return 0;}
''')
(o/'source-slices.json').write_text(json.dumps({'rust_functions':names,'exact_C_prototypes':decls+c[setstart:setend],'placement':placement,'inherit':inherit,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in o.iterdir() if p.is_file()}},indent=2)+'\n')
