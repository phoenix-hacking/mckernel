from pathlib import Path
import difflib
b=Path(__file__).parent;r=Path('/home/holden/mckernel-work/host-preparation/rust-fp-release-image-preparation-20261018-1/materialized-source')
p=b/'source/kernel/rust/sched_helpers.rs';s=p.read_text()
needle='#[no_mangle]\npub unsafe extern "C" fn sched_setaffinity_body_result('
new='''// Serialize supported thread-clone snapshots with selected affinity writers.
// The reservation provider takes this lock itself, so the caller must release
// it before obtain_clone_cpuid or sched_request_migrate is invoked.
unsafe fn sched_affinity_lock() -> CULong {
    unsafe {
        process_spin_lock_bridge_c(core::ptr::addr_of_mut!(runq_reservation_lock) as CULong)
    }
}

unsafe fn sched_affinity_unlock(irqstate: CULong) {
    unsafe {
        process_spin_unlock_bridge_c(
            core::ptr::addr_of_mut!(runq_reservation_lock) as CULong,
            irqstate,
        );
    }
}

#[no_mangle]
pub unsafe extern "C" fn sched_clone_affinity_snapshot_result(
    thread_mask: usize,
    process_mask: usize,
    snapshot: usize,
    bytes: SizeT,
    nr_cpus: CInt,
) -> CInt {
    if thread_mask == 0 || process_mask == 0 || snapshot == 0 || bytes == 0
        || nr_cpus <= 0 || (nr_cpus as usize) > bytes.saturating_mul(8)
    {
        return -EINVAL;
    }
    // All inputs are live syscall-owned native cpu_set_t objects; snapshot is
    // disjoint stack storage. Process eligibility is stable for this syscall.
    let irqstate = unsafe { sched_affinity_lock() };
    unsafe { sched_cpuset_zero(snapshot, bytes) };
    let mut nonempty = false;
    for cpu in 0..nr_cpus {
        if unsafe { sched_cpuset_is_set(thread_mask, bytes, cpu) }
            && unsafe { sched_cpuset_is_set(process_mask, bytes, cpu) }
        {
            unsafe { sched_cpuset_set(snapshot, bytes, cpu) };
            nonempty = true;
        }
    }
    unsafe { sched_affinity_unlock(irqstate) };
    if nonempty { 0 } else { -EINVAL }
}

#[no_mangle]
pub unsafe extern "C" fn sched_clone_affinity_inherit_result(
    child_mask: usize,
    snapshot: usize,
    bytes: SizeT,
) -> CInt {
    if child_mask == 0 || snapshot == 0 || bytes == 0 {
        return -EINVAL;
    }
    // Child remains private: no lookup/runqueue can observe this write.
    unsafe { sched_cpuset_copy(child_mask, snapshot, bytes) };
    0
}

'''+needle
assert s.count(needle)==1;s=s.replace(needle,new)
old='''    let thread_cpu_set_addr = thread.wrapping_add(offsets.thread_cpu_set_offset);
    unsafe {
        sched_cpuset_copy(thread_cpu_set_addr, cpu_set_addr, cpuset_size);
    }
    let cpu_id = unsafe { sched_thread_cpu_id(thread, offsets) };
'''
new='''    let thread_cpu_set_addr = thread.wrapping_add(offsets.thread_cpu_set_offset);
    let irqstate = unsafe { sched_affinity_lock() };
    unsafe {
        sched_cpuset_copy(thread_cpu_set_addr, cpu_set_addr, cpuset_size);
    }
    let cpu_id = unsafe { sched_thread_cpu_id(thread, offsets) };
    let needs_migrate = !unsafe { sched_cpuset_is_set(thread_cpu_set_addr, cpuset_size, cpu_id) };
    unsafe { sched_affinity_unlock(irqstate) };
'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''    if !unsafe { sched_cpuset_is_set(thread_cpu_set_addr, cpuset_size, cpu_id) } {
        unsafe {
            migrate(cpu_id, thread);
''','''    if needs_migrate {
        unsafe {
            migrate(cpu_id, thread);
''',1)
p.write_text(s)
p=b/'source/kernel/syscall.c';s=p.read_text()
needle='unsigned long do_fork('
# Definitions go before the actual do_fork definition, not inside fixture declarations.
idx=s.index(needle)
s=s[:idx]+'''#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
extern int sched_clone_affinity_snapshot_result(unsigned long thread_mask,
        unsigned long process_mask, unsigned long snapshot,
        size_t bytes, int nr_cpus);
extern int sched_clone_affinity_inherit_result(unsigned long child_mask,
        unsigned long snapshot, size_t bytes);
#endif

'''+s[idx:]
needle='\tint helper_thread = 0;'
assert s.count(needle)==1;s=s.replace(needle,needle+'''
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
    cpu_set_t clone_cpu_set;
    int inherit_clone_affinity = 0;
#endif''')
needle='''	else {
		cpuid = obtain_clone_cpuid(&oldproc->cpu_set,
				clone_use_last_cpu_result(old->mod_clone,
					oldproc->uti_use_last_cpu));'''
assert s.count(needle)==1
s=s.replace(needle,'''	else {
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
        /* Keep UTI and non-thread clone policy on their existing route. */
        if ((clone_flags & CLONE_THREAD) && !oldproc->uti_thread_rank &&
                !old->mod_clone && !oldproc->uti_use_last_cpu) {
            if (sched_clone_affinity_snapshot_result(
                    (unsigned long)&old->cpu_set,
                    (unsigned long)&oldproc->cpu_set,
                    (unsigned long)&clone_cpu_set,
                    sizeof(clone_cpu_set), num_processors))
                return -EAGAIN;
            inherit_clone_affinity = 1;
            cpuid = obtain_clone_cpuid(&clone_cpu_set, 0);
        } else
#endif
        cpuid = obtain_clone_cpuid(&oldproc->cpu_set,
                clone_use_last_cpu_result(old->mod_clone,
                    oldproc->uti_use_last_cpu));''')
needle='''	if (clone_pthread_start_routine &&
		range && range->memobj && range->memobj->path) {'''
assert s.count(needle)==1;s=s.replace(needle,'''#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
    if (inherit_clone_affinity && sched_clone_affinity_inherit_result(
            (unsigned long)&new->cpu_set, (unsigned long)&clone_cpu_set,
            sizeof(clone_cpu_set))) {
        err = -EINVAL;
        goto destroy_thread;
    }
#endif

'''+needle)
p.write_text(s)
patch=''
for f in ['kernel/syscall.c','kernel/rust/sched_helpers.rs']:
 patch+=''.join(difflib.unified_diff((r/f).read_text().splitlines(True),(b/'source'/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(b/'candidate.patch').write_text(patch)
