# Selected mask writers and stability premise

Bounded paths only: selected scheduling/process/host helpers for ordinary current thread clone; no broad audit.

| Destination | Existing selected body | Lifetime/serialization |
|---|---|---|
| Initial thread.cpu_set and process.cpu_set | process_create_cpu_sets_body_result (process_helpers.rs6267), create_thread caller process.c873 / Rust create orchestrator8071 | Both newly allocated private objects before host scheduling/publication; initialization only. |
| Cloned thread.cpu_set | process_clone_thread_base_state_body_result (process_helpers.rs7116), process.c984 | Child private, but origin published: existing copy reads caller mask. Candidate invokes the same locked inherit helper, serializing this initial caller-mask read with selected affinity writes. |
| Published thread.cpu_set | sched_setaffinity_body_result (sched_helpers.rs1290original; candidate after exports) | Existing hold/release lifetime retained; candidate global reservation lock around mask write and currentCPU/needs-migration observation; unlock before migrate/release. |
| Private clone snapshot | new sched_clone_affinity_snapshot_result | Same reservation lock around intersection read and output construction; no provider call while lock held. |
| Private child final mask | new sched_clone_affinity_inherit_result | Same locked helper copies owned immutable stack snapshot before address-space CPU update, TID registration, procfs, runq publication. This extra private-copy lock adds no callback or publication. |

Host_helpers.rs5464/5478 reads thread mask for scheduling and passes it to existing obtain_clone_cpuid; no mask write. Address-space cpu_set has a separate meaning/lock and is not thread eligibility.

Process eligibility premise: process.cpu_set is launch eligibility, initialized during private create and copied into a new private process on nonshared clone; sched_setaffinity intersects requested mask with it and mutates only thread.cpu_set. No runtime eligibility-changing API is introduced. New normal-thread route excludes UTI rank/mod_clone/use-last; helper and nonthread routes retain exact old selection. Future process eligibility mutation would require adding its writer to the same serialization contract before claiming support.

Current mask readers outside this bounded repair preserve existing contracts; no global affinity correctness audit or certification is claimed.
