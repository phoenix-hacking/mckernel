from pathlib import Path
import hashlib,json,os,signal,subprocess,time
R=Path(__file__).resolve().parent
E=R/'check-results-remaining-1'
COMMANDS=json.loads((R/'commands-remaining.json').read_text())
def main():
    assert os.sched_getaffinity(0)=={7}
    pins=json.loads((R/'source-pins.json').read_text())+json.loads((R/'tool-pins.json').read_text())
    for row in pins:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
    for path,floor in [('/home/holden/mckernel',16*1024**3),('/home/holden/mckernel-work/scratch',12*1024**3)]:
        st=os.statvfs(path);assert st.f_bavail*st.f_frsize>=floor+640*1024**2
    assert not E.exists();E.mkdir()
    deadline=time.monotonic()+28
    rows=[]
    for label,cmd in COMMANDS:
        remaining=deadline-time.monotonic();assert remaining>3
        start=time.time_ns();mono=time.monotonic_ns();p=None;timedout=False
        with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:
            p=subprocess.Popen(cmd,cwd=R,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC'},stdout=out,stderr=err,start_new_session=True)
            try:
                try:p.wait(timeout=min(20,remaining-3))
                except subprocess.TimeoutExpired:
                    timedout=True;os.killpg(p.pid,signal.SIGTERM)
                    try:p.wait(timeout=1)
                    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=1)
            finally:
                if p.poll() is None:
                    os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=1)
                row={'argv':cmd,'pid':p.pid,'started_unix_ns':start,'finished_unix_ns':time.time_ns(),'elapsed_ns':time.monotonic_ns()-mono,'returncode':p.returncode,'direct_join':True,'timedout':timedout}
                with (E/(label+'.status.json')).open('x') as f:json.dump(row,f,indent=2);f.write('\n')
                rows.append(row)
        if p.returncode or timedout:raise RuntimeError((label,p.returncode,'stop and preserve'))
        assert (E/(label+'.stderr')).stat().st_size==0,label

    symbols=(E/'symbols.stdout').read_text()
    for name in ['sched_clone_affinity_snapshot_result','sched_clone_affinity_inherit_result','sched_setaffinity_body_result','process_clone_thread_base_state_body_result']:
        assert sum(line.endswith(' T '+name) for line in symbols.splitlines())==1,name
    result={'status':'PASS_SOURCE_BODY_CONSUMER_AFFINITY','commands':len(rows),'prior_passed_commands_reused':4,'all_direct_joined':True,'guest_runs':0,'current_candidate_builds':0,'mask_pairs':256,'native_runtime':'PENDING','compiler_fullcrate_default_artifact':'PENDING'}
    (E/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
if __name__=='__main__':main()
