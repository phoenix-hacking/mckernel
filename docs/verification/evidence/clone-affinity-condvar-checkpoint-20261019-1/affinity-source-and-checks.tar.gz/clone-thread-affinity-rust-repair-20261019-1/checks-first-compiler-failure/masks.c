#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define CLONE_THREAD 0x10000
#define CPU_STATUS_RESERVED 1
#define dkprintf(...) ((void)0)
#define CPU_ISSET(cpu,set) (((set)->bits[(cpu)/64] >> ((cpu)%64)) & 1UL)
typedef struct { unsigned long bits[2]; } cpu_set_t;
struct process {cpu_set_t cpu_set;int uti_thread_rank;int uti_use_last_cpu;};
struct thread {cpu_set_t cpu_set;struct process*proc;int cpu_id;int mod_clone;int in_kernel;};
struct cpu_local_var {int runq_len,runq_reserved,runq_lock,status;};
int num_processors=2;unsigned int runq_reservation_lock;int held,locks,unlocks,holds,releases,migrations;
struct cpu_local_var cpus[128];
unsigned long ihk_mc_spinlock_lock(unsigned int *p){if(p==&runq_reservation_lock){assert(!held);held=1;locks++;}return 123;}
void ihk_mc_spinlock_unlock(unsigned int*p,unsigned long flags){assert(flags==123);if(p==&runq_reservation_lock){assert(held);held=0;unlocks++;}}
void ihk_mc_spinlock_lock_noirq(int*p){(void)p;assert(held);}
void ihk_mc_spinlock_unlock_noirq(int*p){(void)p;assert(held);}
struct cpu_local_var*get_cpu_local_var(int c){assert(c>=0&&c<num_processors);return &cpus[c];}
int ihk_mc_get_processor_id(void){return 0;}
int clone_use_last_cpu_result(int mod,int use){return mod&&use;}
void kprintf(const char*f,...){(void)f;}
unsigned long process_spin_lock_bridge(unsigned long p){return ihk_mc_spinlock_lock((unsigned int*)p);}
void process_spin_unlock_bridge(unsigned long p,unsigned long s){ihk_mc_spinlock_unlock((unsigned int*)p,s);}
#define MCKERNEL_RUST_SCHED_POLICY_HELPERS
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
extern int sched_clone_affinity_snapshot_result(unsigned long thread_mask,
        unsigned long process_mask, unsigned long snapshot,
        size_t bytes, int nr_cpus);
extern int sched_clone_affinity_inherit_result(unsigned long child_mask,
        unsigned long snapshot, size_t bytes);
#endif
typedef unsigned long (*sched_find_thread_fn_t)(int pid);
typedef void (*sched_thread_unlock_fn_t)(unsigned long thread_addr);
typedef int (*sched_hold_thread_fn_t)(unsigned long thread_addr);
typedef void (*sched_release_thread_fn_t)(unsigned long thread_addr);
typedef long (*syscall_copy_from_user_fn_t)(void *dst,
		unsigned long src_addr, size_t bytes);
typedef void (*sched_request_migrate_fn_t)(int cpu_id,
		unsigned long thread_addr);
struct sched_syscall_offsets {
	size_t thread_proc_offset;
	size_t thread_sched_param_offset;
	size_t thread_sched_policy_offset;
	size_t thread_cpu_id_offset;
	size_t thread_cpu_set_offset;
	size_t proc_pid_offset;
	size_t proc_ruid_offset;
	size_t proc_euid_offset;
	size_t proc_cpu_set_offset;
};
int process_clone_thread_base_state_body_result(
	void *thread, const void *origin, unsigned long cpu_set_offset,
	unsigned long cpu_set_size, unsigned long in_kernel_offset);
extern long sched_setaffinity_body_result(int tid, size_t len,
		unsigned long u_cpu_set_addr, unsigned long current_thread,
		unsigned long k_cpu_set_addr, unsigned long cpu_set_addr,
		size_t cpuset_size, int nr_cpus,
		const struct sched_syscall_offsets *offsets,
		sched_find_thread_fn_t find_fn,
		sched_thread_unlock_fn_t unlock_fn,
		sched_hold_thread_fn_t hold_fn,
		sched_release_thread_fn_t release_fn,
		syscall_copy_from_user_fn_t copy_from_fn,
		sched_request_migrate_fn_t migrate_fn);
int hold(unsigned long t){assert(t);holds++;return 0;}void release(unsigned long t){assert(t&&!held);releases++;}
long copyfrom(void*d,unsigned long s,size_t n){memcpy(d,(void*)s,n);return 0;}
void migrate(int cpu,unsigned long t){assert(cpu==0&&t&&!held);migrations++;}
int main(void){cpu_set_t a,b,out,child;unsigned cases=0;
 for(unsigned x=0;x<16;x++)for(unsigned y=0;y<16;y++){a=(cpu_set_t){{x,0}};b=(cpu_set_t){{y,0}};out=(cpu_set_t){{~0UL,~0UL}};
 int r=sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,4);
 assert(r==((x&y)?0:-EINVAL));assert(out.bits[0]==(x&y)&&out.bits[1]==0);assert(a.bits[0]==x&&b.bits[0]==y);assert(!held);cases++;}
 a=(cpu_set_t){{0,1UL<<55}};b=a;assert(!sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,120));assert(out.bits[1]==(1UL<<55));
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,sizeof out,119)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,1,1)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result(0,(unsigned long)&b,(unsigned long)&out,sizeof out,2)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,0,2)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,8,65)==-EINVAL);
 assert(sched_clone_affinity_snapshot_result((unsigned long)&a,(unsigned long)&b,(unsigned long)&out,16,0)==-EINVAL);
 out=(cpu_set_t){{2,0}};child=(cpu_set_t){{1,0}};assert(!sched_clone_affinity_inherit_result((unsigned long)&child,(unsigned long)&out,sizeof out));assert(child.bits[0]==2);
 assert(sched_clone_affinity_inherit_result(0,(unsigned long)&out,sizeof out)==-EINVAL);
 struct thread origin={.cpu_set={{2,0}},.in_kernel=7},created={0};
 assert(!process_clone_thread_base_state_body_result(&created,&origin,offsetof(struct thread,cpu_set),sizeof origin.cpu_set,offsetof(struct thread,in_kernel)));
 assert(created.cpu_set.bits[0]==2&&created.in_kernel==7&&!held);
 created.cpu_set.bits[0]=1;origin.in_kernel=9;
 assert(!process_clone_thread_base_state_body_result(&created,&origin,offsetof(struct thread,cpu_set),0,offsetof(struct thread,in_kernel)));
 assert(created.cpu_set.bits[0]==1&&created.in_kernel==9&&!held);
 assert(process_clone_thread_base_state_body_result(0,&origin,offsetof(struct thread,cpu_set),sizeof origin.cpu_set,offsetof(struct thread,in_kernel))==-EINVAL);
 struct process p={.cpu_set={{3,0}}};struct thread t={.cpu_set={{1,0}},.proc=&p,.cpu_id=0};
 struct sched_syscall_offsets offsets={.thread_proc_offset=offsetof(struct thread,proc),.thread_cpu_id_offset=offsetof(struct thread,cpu_id),.thread_cpu_set_offset=offsetof(struct thread,cpu_set),.proc_cpu_set_offset=offsetof(struct process,cpu_set)};
 cpu_set_t request={{2,0}},scratch,eligible;long ret=sched_setaffinity_body_result(0,sizeof request,(unsigned long)&request,(unsigned long)&t,(unsigned long)&scratch,(unsigned long)&eligible,sizeof request,2,&offsets,0,0,hold,release,copyfrom,migrate);
 assert(ret==0&&t.cpu_set.bits[0]==2&&migrations==1&&holds==1&&releases==1);assert(!held&&locks==unlocks);
 request.bits[0]=4;ret=sched_setaffinity_body_result(0,sizeof request,(unsigned long)&request,(unsigned long)&t,(unsigned long)&scratch,(unsigned long)&eligible,sizeof request,2,&offsets,0,0,hold,release,copyfrom,migrate);
 assert(ret==-EINVAL&&holds==2&&releases==2&&!held&&locks==unlocks);
 printf("mask cases=%u high-tail/errors/publication/migration PASS\n",cases);return 0;}
