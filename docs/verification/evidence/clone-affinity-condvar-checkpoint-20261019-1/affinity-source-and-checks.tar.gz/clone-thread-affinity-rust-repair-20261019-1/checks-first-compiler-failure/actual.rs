#![allow(dead_code)]
use core::ptr::{read_volatile,write_volatile};
use core::ffi::c_void;
type CInt=i32; type CLong=i64; type CULong=u64; type SizeT=usize; type IhkSpinlock=u32;
const EINVAL:CInt=22;const EFAULT:CInt=14;const ESRCH:CInt=3;const EPERM:CInt=1;
extern "C" {static mut runq_reservation_lock:IhkSpinlock;
#[link_name="process_spin_lock_bridge"] fn process_spin_lock_bridge_c(addr:CULong)->CULong;
#[link_name="process_spin_unlock_bridge"] fn process_spin_unlock_bridge_c(addr:CULong,state:CULong);}
type SchedFindThreadFn = unsafe extern "C" fn(CInt) -> usize;
type SchedThreadUnlockFn = unsafe extern "C" fn(usize);
type SchedHoldThreadFn = unsafe extern "C" fn(usize) -> CInt;
type SchedReleaseThreadFn = unsafe extern "C" fn(usize);
type SchedCopyFromUserFn = unsafe extern "C" fn(*mut u8, CULong, SizeT) -> CLong;
type SchedRequestMigrateFn = unsafe extern "C" fn(CInt, usize);
#[repr(C)]
pub struct SchedSyscallOffsets {
    pub thread_proc_offset: SizeT,
    pub thread_sched_param_offset: SizeT,
    pub thread_sched_policy_offset: SizeT,
    pub thread_cpu_id_offset: SizeT,
    pub thread_cpu_set_offset: SizeT,
    pub proc_pid_offset: SizeT,
    pub proc_ruid_offset: SizeT,
    pub proc_euid_offset: SizeT,
    pub proc_cpu_set_offset: SizeT,
}
pub extern "C" fn sched_affinity_permission_result(
    caller_euid: u32,
    target_ruid: u32,
    target_euid: u32,
) -> CInt {
    if caller_euid == 0 || caller_euid == target_ruid || caller_euid == target_euid {
        0
    } else {
        -EPERM
    }
}
pub extern "C" fn sched_affinity_copy_len(len: usize, cpuset_size: usize) -> usize {
    if len < cpuset_size {
        len
    } else {
        cpuset_size
    }
}
fn sched_errno(errno: CInt) -> CLong {
    -(errno as CLong)
}
unsafe fn sched_read_usize(base: usize, offset: SizeT) -> usize {
    unsafe { read_volatile(base.wrapping_add(offset) as *const usize) }
}
unsafe fn sched_read_int(base: usize, offset: SizeT) -> CInt {
    unsafe { read_volatile(base.wrapping_add(offset) as *const CInt) }
}
unsafe fn sched_thread_proc(thread_addr: usize, offsets: &SchedSyscallOffsets) -> usize {
    unsafe { sched_read_usize(thread_addr, offsets.thread_proc_offset) }
}
unsafe fn sched_thread_cpu_id(thread_addr: usize, offsets: &SchedSyscallOffsets) -> CInt {
    unsafe { sched_read_int(thread_addr, offsets.thread_cpu_id_offset) }
}
unsafe fn sched_proc_ruid(proc_addr: usize, offsets: &SchedSyscallOffsets) -> u32 {
    unsafe { read_volatile(proc_addr.wrapping_add(offsets.proc_ruid_offset) as *const u32) }
}
unsafe fn sched_proc_euid(proc_addr: usize, offsets: &SchedSyscallOffsets) -> u32 {
    unsafe { read_volatile(proc_addr.wrapping_add(offsets.proc_euid_offset) as *const u32) }
}
unsafe fn sched_cpuset_zero(cpuset_addr: usize, cpuset_size: SizeT) {
    let word_size = core::mem::size_of::<CULong>();
    let words = cpuset_size / word_size;
    let tail = cpuset_size % word_size;

    for index in 0..words {
        unsafe {
            write_volatile(
                cpuset_addr.wrapping_add(index * word_size) as *mut CULong,
                0,
            );
        }
    }
    let tail_base = cpuset_addr.wrapping_add(words * word_size);
    for index in 0..tail {
        unsafe {
            write_volatile(tail_base.wrapping_add(index) as *mut u8, 0);
        }
    }
}
unsafe fn sched_cpuset_copy(dst_addr: usize, src_addr: usize, bytes: SizeT) {
    let word_size = core::mem::size_of::<CULong>();
    let words = bytes / word_size;
    let tail = bytes % word_size;

    for index in 0..words {
        let offset = index * word_size;
        let value = unsafe { read_volatile(src_addr.wrapping_add(offset) as *const CULong) };
        unsafe {
            write_volatile(dst_addr.wrapping_add(offset) as *mut CULong, value);
        }
    }
    let tail_base = words * word_size;
    for index in 0..tail {
        let offset = tail_base + index;
        let value = unsafe { read_volatile(src_addr.wrapping_add(offset) as *const u8) };
        unsafe {
            write_volatile(dst_addr.wrapping_add(offset) as *mut u8, value);
        }
    }
}
unsafe fn sched_cpuset_is_set(cpuset_addr: usize, cpuset_size: SizeT, cpu: CInt) -> bool {
    if cpu < 0 {
        return false;
    }
    let cpu = cpu as usize;
    if cpu >= cpuset_size.saturating_mul(8) {
        return false;
    }
    let word_bits = core::mem::size_of::<CULong>() * 8;
    let word_index = cpu / word_bits;
    let bit = cpu % word_bits;
    let value = unsafe {
        read_volatile(
            cpuset_addr.wrapping_add(word_index * core::mem::size_of::<CULong>()) as *const CULong,
        )
    };
    (value & (1u64 << bit)) != 0
}
unsafe fn sched_cpuset_set(cpuset_addr: usize, cpuset_size: SizeT, cpu: CInt) {
    if cpu < 0 {
        return;
    }
    let cpu = cpu as usize;
    if cpu >= cpuset_size.saturating_mul(8) {
        return;
    }
    let word_bits = core::mem::size_of::<CULong>() * 8;
    let word_index = cpu / word_bits;
    let bit = cpu % word_bits;
    let word_addr =
        cpuset_addr.wrapping_add(word_index * core::mem::size_of::<CULong>()) as *mut CULong;
    let value = unsafe { read_volatile(word_addr) };
    unsafe {
        write_volatile(word_addr, value | (1u64 << bit));
    }
}
unsafe fn sched_affinity_select_thread(
    tid: CInt,
    current_thread: usize,
    offsets: &SchedSyscallOffsets,
    find_fn: Option<SchedFindThreadFn>,
    unlock_fn: Option<SchedThreadUnlockFn>,
    hold_fn: Option<SchedHoldThreadFn>,
) -> Result<usize, CLong> {
    let Some(hold) = hold_fn else {
        return Err(sched_errno(EINVAL));
    };
    if tid == 0 {
        unsafe {
            hold(current_thread);
        }
        return Ok(current_thread);
    }

    let (Some(find_thread), Some(thread_unlock)) = (find_fn, unlock_fn) else {
        return Err(sched_errno(EINVAL));
    };
    let thread = unsafe { find_thread(tid) };
    if thread == 0 {
        return Err(sched_errno(ESRCH));
    }

    let current_proc = unsafe { sched_thread_proc(current_thread, offsets) };
    let target_proc = unsafe { sched_thread_proc(thread, offsets) };
    if current_proc == 0 || target_proc == 0 {
        unsafe {
            thread_unlock(thread);
        }
        return Err(sched_errno(EINVAL));
    }
    let permission = sched_affinity_permission_result(
        unsafe { sched_proc_euid(current_proc, offsets) },
        unsafe { sched_proc_ruid(target_proc, offsets) },
        unsafe { sched_proc_euid(target_proc, offsets) },
    );
    if permission != 0 {
        unsafe {
            thread_unlock(thread);
        }
        return Err(permission as CLong);
    }

    unsafe {
        hold(thread);
        thread_unlock(thread);
    }
    Ok(thread)
}
unsafe fn sched_affinity_lock() -> CULong {
    unsafe {
        process_spin_lock_bridge_c(core::ptr::addr_of_mut!(runq_reservation_lock) as CULong)
    }
}
unsafe fn sched_affinity_unlock(irqstate: CULong) {
    unsafe {
        process_spin_unlock_bridge_c(
            core::ptr::addr_of_mut!(runq_reservation_lock) as CULong,
            irqstate,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn sched_clone_affinity_snapshot_result(
    thread_mask: usize,
    process_mask: usize,
    snapshot: usize,
    bytes: SizeT,
    nr_cpus: CInt,
) -> CInt {
    if thread_mask == 0 || process_mask == 0 || snapshot == 0 || bytes == 0
        || bytes % core::mem::size_of::<CULong>() != 0
        || nr_cpus <= 0 || (nr_cpus as usize) > bytes.saturating_mul(8)
    {
        return -EINVAL;
    }
    // All inputs are live syscall-owned native cpu_set_t objects; snapshot is
    // disjoint stack storage. Process eligibility is stable for this syscall.
    let irqstate = unsafe { sched_affinity_lock() };
    unsafe { sched_cpuset_zero(snapshot, bytes) };
    let mut nonempty = false;
    for cpu in 0..nr_cpus {
        if unsafe { sched_cpuset_is_set(thread_mask, bytes, cpu) }
            && unsafe { sched_cpuset_is_set(process_mask, bytes, cpu) }
        {
            unsafe { sched_cpuset_set(snapshot, bytes, cpu) };
            nonempty = true;
        }
    }
    unsafe { sched_affinity_unlock(irqstate) };
    if nonempty { 0 } else { -EINVAL }
}
#[no_mangle]
pub unsafe extern "C" fn sched_clone_affinity_inherit_result(
    child_mask: usize,
    snapshot: usize,
    bytes: SizeT,
) -> CInt {
    if child_mask == 0 || snapshot == 0 || bytes == 0 {
        return -EINVAL;
    }
    // Child remains private: no lookup/runqueue can observe this write.
    unsafe { sched_cpuset_copy(child_mask, snapshot, bytes) };
    0
}
#[no_mangle]
pub unsafe extern "C" fn sched_setaffinity_body_result(
    tid: CInt,
    len: SizeT,
    u_cpu_set_addr: CULong,
    current_thread: usize,
    k_cpu_set_addr: usize,
    cpu_set_addr: usize,
    cpuset_size: SizeT,
    num_processors: CInt,
    offsets: *const SchedSyscallOffsets,
    find_fn: Option<SchedFindThreadFn>,
    unlock_fn: Option<SchedThreadUnlockFn>,
    hold_fn: Option<SchedHoldThreadFn>,
    release_fn: Option<SchedReleaseThreadFn>,
    copy_from_fn: Option<SchedCopyFromUserFn>,
    migrate_fn: Option<SchedRequestMigrateFn>,
) -> CLong {
    if u_cpu_set_addr == 0 {
        return sched_errno(EFAULT);
    }
    if current_thread == 0
        || k_cpu_set_addr == 0
        || cpu_set_addr == 0
        || cpuset_size == 0
        || offsets.is_null()
        || num_processors < 0
    {
        return sched_errno(EINVAL);
    }
    let Some(copy_from) = copy_from_fn else {
        return sched_errno(EINVAL);
    };
    let Some(release) = release_fn else {
        return sched_errno(EINVAL);
    };
    let Some(migrate) = migrate_fn else {
        return sched_errno(EINVAL);
    };

    if cpuset_size > len {
        unsafe {
            sched_cpuset_zero(k_cpu_set_addr, cpuset_size);
        }
    }
    let copy_len = sched_affinity_copy_len(len, cpuset_size);
    if unsafe { copy_from(k_cpu_set_addr as *mut u8, u_cpu_set_addr, copy_len) } != 0 {
        return sched_errno(EFAULT);
    }

    let offsets = unsafe { &*offsets };
    let thread = match unsafe {
        sched_affinity_select_thread(tid, current_thread, offsets, find_fn, unlock_fn, hold_fn)
    } {
        Ok(thread) => thread,
        Err(ret) => return ret,
    };
    let target_proc = unsafe { sched_thread_proc(thread, offsets) };
    if target_proc == 0 {
        unsafe {
            release(thread);
        }
        return sched_errno(EINVAL);
    }

    unsafe {
        sched_cpuset_zero(cpu_set_addr, cpuset_size);
    }
    let proc_cpu_set_addr = target_proc.wrapping_add(offsets.proc_cpu_set_offset);
    let mut empty = true;
    for cpu in 0..num_processors {
        if unsafe { sched_cpuset_is_set(k_cpu_set_addr, cpuset_size, cpu) }
            && unsafe { sched_cpuset_is_set(proc_cpu_set_addr, cpuset_size, cpu) }
        {
            unsafe {
                sched_cpuset_set(cpu_set_addr, cpuset_size, cpu);
            }
            empty = false;
        }
    }
    if empty {
        unsafe {
            release(thread);
        }
        return sched_errno(EINVAL);
    }

    let thread_cpu_set_addr = thread.wrapping_add(offsets.thread_cpu_set_offset);
    let irqstate = unsafe { sched_affinity_lock() };
    unsafe {
        sched_cpuset_copy(thread_cpu_set_addr, cpu_set_addr, cpuset_size);
    }
    let cpu_id = unsafe { sched_thread_cpu_id(thread, offsets) };
    let needs_migrate = !unsafe { sched_cpuset_is_set(thread_cpu_set_addr, cpuset_size, cpu_id) };
    unsafe { sched_affinity_unlock(irqstate) };
    if needs_migrate {
        unsafe {
            migrate(cpu_id, thread);
        }
    }
    unsafe {
        release(thread);
    }
    0
}
mod sched_helpers { pub use super::sched_clone_affinity_inherit_result; }
#[no_mangle]
pub unsafe extern "C" fn process_clone_thread_base_state_body_result(
    thread: *mut c_void,
    origin: *const c_void,
    cpu_set_offset: CULong,
    cpu_set_size: CULong,
    in_kernel_offset: CULong,
) -> CInt {
    if thread.is_null() || origin.is_null() {
        return -EINVAL;
    }

    let dst = thread.cast::<u8>();
    let src = origin.cast::<u8>();
    copy_nonoverlapping(
        src.add(cpu_set_offset as usize),
        dst.add(cpu_set_offset as usize),
        cpu_set_size as usize,
    );
    *dst.add(in_kernel_offset as usize).cast::<CInt>() =
        *src.add(in_kernel_offset as usize).cast::<CInt>();
    0
}
