#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define CLONE_THREAD 0x10000
#define CPU_STATUS_RESERVED 1
#define dkprintf(...) ((void)0)
#define CPU_ISSET(cpu,set) (((set)->bits[(cpu)/64] >> ((cpu)%64)) & 1UL)
typedef struct { unsigned long bits[2]; } cpu_set_t;
struct process {cpu_set_t cpu_set;int uti_thread_rank;int uti_use_last_cpu;};
struct thread {cpu_set_t cpu_set;struct process*proc;int cpu_id;int mod_clone;int in_kernel;};
struct cpu_local_var {int runq_len,runq_reserved,runq_lock,status;};
int num_processors=2;unsigned int runq_reservation_lock;int held,locks,unlocks,holds,releases,migrations;
struct cpu_local_var cpus[128];
unsigned long ihk_mc_spinlock_lock(unsigned int *p){if(p==&runq_reservation_lock){assert(!held);held=1;locks++;}return 123;}
void ihk_mc_spinlock_unlock(unsigned int*p,unsigned long flags){assert(flags==123);if(p==&runq_reservation_lock){assert(held);held=0;unlocks++;}}
void ihk_mc_spinlock_lock_noirq(int*p){(void)p;assert(held);}
void ihk_mc_spinlock_unlock_noirq(int*p){(void)p;assert(held);}
struct cpu_local_var*get_cpu_local_var(int c){assert(c>=0&&c<num_processors);return &cpus[c];}
int ihk_mc_get_processor_id(void){return 0;}
int clone_use_last_cpu_result(int mod,int use){return mod&&use;}
void kprintf(const char*f,...){(void)f;}
unsigned long process_spin_lock_bridge(unsigned long p){return ihk_mc_spinlock_lock((unsigned int*)p);}
void process_spin_unlock_bridge(unsigned long p,unsigned long s){ihk_mc_spinlock_unlock((unsigned int*)p,s);}
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
extern int sched_clone_affinity_snapshot_result(unsigned long thread_mask,
        unsigned long process_mask, unsigned long snapshot,
        size_t bytes, int nr_cpus);
extern int sched_clone_affinity_inherit_result(unsigned long child_mask,
        unsigned long snapshot, size_t bytes);
#endif

int obtain_clone_cpuid(cpu_set_t *cpu_set, int use_last) {
	int min_queue_len = -1;
	int cpu, min_cpu = -1, uti_cpu = -1;
	unsigned long irqstate;
	
	irqstate = ihk_mc_spinlock_lock(&runq_reservation_lock);
	/* Find the first allowed core with the shortest run queue */
	for (cpu = 0; cpu < num_processors; ++cpu) {
		struct cpu_local_var *v;

		if (!CPU_ISSET(cpu, cpu_set)) continue;

		v = get_cpu_local_var(cpu);
		ihk_mc_spinlock_lock_noirq(&v->runq_lock);
		dkprintf("%s: cpu=%d,runq_len=%d,runq_reserved=%d\n", __FUNCTION__, cpu, v->runq_len, v->runq_reserved);
		if (min_queue_len == -1 || v->runq_len + v->runq_reserved < min_queue_len) {
			min_queue_len = v->runq_len + v->runq_reserved;
			min_cpu = cpu;
		}

		/* Record the last tie CPU */
		if (min_cpu != cpu && v->runq_len + v->runq_reserved == min_queue_len) {
			uti_cpu = cpu;
		}
		dkprintf("%s: cpu=%d,runq_len=%d,runq_reserved=%d,min_cpu=%d,uti_cpu=%d\n", __FUNCTION__, cpu, v->runq_len, v->runq_reserved, min_cpu, uti_cpu);
		ihk_mc_spinlock_unlock_noirq(&v->runq_lock);
#if 0
		if (min_queue_len == 0)
			break;
#endif
	}

	min_cpu = use_last ? uti_cpu : min_cpu;
	if (min_cpu != -1) {
		if (get_cpu_local_var(min_cpu)->status != CPU_STATUS_RESERVED)
			get_cpu_local_var(min_cpu)->status = CPU_STATUS_RESERVED;
		__sync_fetch_and_add(&get_cpu_local_var(min_cpu)->runq_reserved, 1);
	}
	ihk_mc_spinlock_unlock(&runq_reservation_lock, irqstate);

    return min_cpu;
}
long actual_consumer(struct thread*old,int clone_flags,int helper_thread,int mutate){
 struct process*oldproc=old->proc;struct thread child=*old;struct thread*new=&child;
 int cpuid=-1,err=0;cpus[0].runq_reserved=cpus[1].runq_reserved=0;
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 cpu_set_t clone_cpu_set;int inherit_clone_affinity=0;
#endif
	if (helper_thread) {
		cpuid = ihk_mc_get_processor_id();
		//cpuid = obtain_clone_cpuid(&oldproc->cpu_set, 1);
	}
	else {
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
        /* Keep UTI and non-thread clone policy on their existing route. */
        if ((clone_flags & CLONE_THREAD) && !oldproc->uti_thread_rank &&
                !old->mod_clone && !oldproc->uti_use_last_cpu) {
            if (sched_clone_affinity_snapshot_result(
                    (unsigned long)&old->cpu_set,
                    (unsigned long)&oldproc->cpu_set,
                    (unsigned long)&clone_cpu_set,
                    sizeof(clone_cpu_set), num_processors))
                return -EAGAIN;
            inherit_clone_affinity = 1;
            cpuid = obtain_clone_cpuid(&clone_cpu_set, 0);
        } else
#endif
        cpuid = obtain_clone_cpuid(&oldproc->cpu_set,
                clone_use_last_cpu_result(old->mod_clone,
                    oldproc->uti_use_last_cpu));
		if (cpuid == -1) {
			kprintf("do_fork,core not available\n");
			return -EAGAIN;
		}
	}

 if(mutate) old->cpu_set.bits[0]=1;
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
    if (inherit_clone_affinity && sched_clone_affinity_inherit_result(
            (unsigned long)&new->cpu_set, (unsigned long)&clone_cpu_set,
            sizeof(clone_cpu_set))) {
        err = -EINVAL;
        goto destroy_thread;
    }
#endif
 assert(!held);
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 if(inherit_clone_affinity) assert(new->cpu_set.bits[0]==2);
#endif
 return cpuid;
destroy_thread: return err;
}
int main(void){struct process p={.cpu_set={{3,0}}};struct thread t={.cpu_set={{2,0}},.proc=&p,.cpu_id=1};
 cpus[1].runq_len=1;long result=actual_consumer(&t,CLONE_THREAD,0,1);
#ifdef MCKERNEL_RUST_SCHED_POLICY_HELPERS
 assert(result==1); assert(locks==3&&unlocks==3); /* snapshot, reservation, private final copy */
#else
 assert(result==0); assert(locks==1&&unlocks==1); /* retained failing route control */
#endif
 t.cpu_set.bits[0]=2;p.uti_thread_rank=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 p.uti_thread_rank=0;t.mod_clone=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 t.mod_clone=0;p.uti_use_last_cpu=1;assert(actual_consumer(&t,CLONE_THREAD,0,0)==0);
 p.uti_use_last_cpu=0;assert(actual_consumer(&t,0,0,0)==0);
 assert(actual_consumer(&t,CLONE_THREAD,1,0)==0);assert(!held&&locks==unlocks);
 puts("actual selected/fallback consumer PASS");return 0;}
