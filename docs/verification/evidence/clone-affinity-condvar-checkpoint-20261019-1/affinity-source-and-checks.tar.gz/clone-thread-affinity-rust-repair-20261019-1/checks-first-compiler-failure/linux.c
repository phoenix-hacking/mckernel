#define _GNU_SOURCE
#include <assert.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
static cpu_set_t expected;
static void *child(void*x){(void)x;cpu_set_t seen;assert(!sched_getaffinity(0,sizeof seen,&seen));assert(CPU_EQUAL(&seen,&expected));assert(CPU_ISSET(sched_getcpu(),&expected));return 0;}
int main(void){cpu_set_t before;assert(!sched_getaffinity(0,sizeof before,&before));int cpu=-1;for(int i=0;i<CPU_SETSIZE;i++)if(CPU_ISSET(i,&before)){cpu=i;break;}assert(cpu>=0);CPU_ZERO(&expected);CPU_SET(cpu,&expected);assert(!sched_setaffinity(0,sizeof expected,&expected));pthread_t t;assert(!pthread_create(&t,0,child,0));assert(!pthread_join(t,0));assert(!sched_setaffinity(0,sizeof before,&before));puts("Linux creator-mask inheritance before child bind PASS");return 0;}
