# Preserved first attempt

First failed current-basis preparation: current-basis-preparation.stderr ValueError; subsequent original implement.py returned0 and masked it. Old script and source were never an integrated kernel change. The full original script is preserved as implement-fp-basis.py and implement.py; do not rerun either. Final source is reconstructed and validated by validate_candidate.py, which checks original current-source digests and every exact unified-patch context before comparing final bytes.

First compiler chain: checks-run1.*, check-results-1/*, candidate-first-compiler-failure.patch, source-first-compiler-failure/*, checks-first-compiler-failure/*, source-pins-first-compiler-failure.json. This maps its original mutable source/check paths to byte-exact archived copies. The E0425 copy_nonoverlapping error belongs to an extraction of the stale unlocked base-copy body. No native image/default artifact was built.

Final authoritative candidate: source/*, candidate.patch, final-source-coherence.json, source-pins.json, LOCK-ORDER.md. Final current three-file source basis is input-bindings-current.json; original FP preparation input bindings and first FP design remain separate historical records. Compiler correction uses check-results-2 only after reviewer coherence confirmation.
