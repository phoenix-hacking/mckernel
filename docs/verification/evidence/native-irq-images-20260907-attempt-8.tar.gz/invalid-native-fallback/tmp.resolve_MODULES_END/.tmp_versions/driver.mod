/work/mckernel-native-irq-images-20260907-8/invalid-native-fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-irq-images-20260907-8/invalid-native-fallback/tmp.resolve_MODULES_END/driver.o

