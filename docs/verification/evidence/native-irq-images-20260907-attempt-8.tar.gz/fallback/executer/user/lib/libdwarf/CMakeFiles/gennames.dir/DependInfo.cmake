
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/mckernel-native-irq-images-20260907-8/source/executer/user/lib/libdwarf/libdwarf/libdwarf/dwgetopt.c" "executer/user/lib/libdwarf/CMakeFiles/gennames.dir/libdwarf/libdwarf/dwgetopt.c.o" "gcc" "executer/user/lib/libdwarf/CMakeFiles/gennames.dir/libdwarf/libdwarf/dwgetopt.c.o.d"
  "/work/mckernel-native-irq-images-20260907-8/source/executer/user/lib/libdwarf/libdwarf/libdwarf/gennames.c" "executer/user/lib/libdwarf/CMakeFiles/gennames.dir/libdwarf/libdwarf/gennames.c.o" "gcc" "executer/user/lib/libdwarf/CMakeFiles/gennames.dir/libdwarf/libdwarf/gennames.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
