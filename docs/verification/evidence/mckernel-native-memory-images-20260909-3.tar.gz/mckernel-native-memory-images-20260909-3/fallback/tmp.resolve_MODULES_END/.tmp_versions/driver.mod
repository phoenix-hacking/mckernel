/work/mckernel-native-memory-images-20260909-3/fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-memory-images-20260909-3/fallback/tmp.resolve_MODULES_END/driver.o

