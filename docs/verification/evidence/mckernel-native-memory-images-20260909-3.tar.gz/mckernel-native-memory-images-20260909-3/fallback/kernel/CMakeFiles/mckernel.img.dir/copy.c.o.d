kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-memory-images-20260909-3/source/kernel/copy.c
