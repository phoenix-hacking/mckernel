kernel/CMakeFiles/mckernel.img.dir/__/lib/vsprintf.c.o: \
 /work/mckernel-native-memory-images-20260909-3/source/lib/vsprintf.c \
 /usr/lib/gcc/x86_64-redhat-linux/8/include/stdarg.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/string.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/types.h \
 /work/mckernel-native-memory-images-20260909-3/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-memory-images-20260909-3/source/arch/x86_64/kernel/include/arch-string.h \
 /work/mckernel-native-memory-images-20260909-3/source/arch/x86_64/kernel/include/errno.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/generic-errno.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/ctype.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/limits.h \
 /work/mckernel-native-memory-images-20260909-3/source/lib/include/memory.h \
 /work/mckernel-native-memory-images-20260909-3/source/arch/x86_64/kernel/include/arch-memory.h
