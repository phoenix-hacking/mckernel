from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, base = Path('/workspace'), Path('/work')
out = base / ('native-sysfs-setup-build-retained-20260907-' + sys.argv[1]); out.mkdir()
final = base / 'native-sysfs-setup-module-20260907-1'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[], production_gate_credit=False,
    declared_stage=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    applications_tested=False)

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): checksum.update(chunk)
    return checksum.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def checked(row):
    assert identity(Path(row['path'])) == row, row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target)
    row.update(path='docs/verification/evidence/' + name, source=str(source),
        unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

def bind(current, compiled):
    relative = current.relative_to(repo)
    row = identity(compiled); row['path'] = str(relative)
    row.update(source_sha256=digest(current), source_size=current.stat().st_size,
               binding='identical', compiler_capture=str(compiled))
    if current.read_bytes() != compiled.read_bytes():
        assert current.suffix == '.rs', (str(current), str(compiled))
        original = final / 'original-inputs' / current.relative_to(repo / 'host-kernel/native-rust')
        assert current.read_bytes() == original.read_bytes(), ('original-source-binding', str(current))
        saved = out / 'source-bindings' / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(current, saved.with_suffix('.original.rs'))
        shutil.copyfile(current, saved)
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(saved)]
        with saved.with_suffix('.rustfmt.log').open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (command, result.returncode)
        assert saved.read_bytes() == compiled.read_bytes(), ('formatted-source-binding', str(current))
        row.update(binding='exact-rustfmt-replay', command=command, original_capture=str(original))
    if row not in record['compiler_inputs']: record['compiler_inputs'].append(row)

try:
    shutil.copyfile(__file__, out / 'helper.py')
    captures = ['native-sysfs-setup-module-20260907-1', 'native-sysfs-ownership-tests-20260907-1', 'native-sysfs-setup-guest-20260907-1']
    for name in captures:
        source = base / name
        captured = json.loads((source / 'record.json').read_text())
        assert captured['status'] == 'PASS', name
        for field in ('inputs','outputs','fixture_inputs','compiler_inputs'):
            for row in captured.get(field,[]): checked(row)
        archive = out / (name + '.tar.gz')
        with tarfile.open(archive,'w:gz') as tar: tar.add(source,arcname=name)
        assert archive.stat().st_size < 95 << 20, name
        row = identity(archive); row.update(path='docs/verification/evidence/' + archive.name, source=str(source))
        record['artifacts'].append(row)
        retain_gzip(source / 'record.json', name + '-record.json.gz')
        if (source/'serial.log').exists(): retain_gzip(source/'serial.log',name+'-serial.log.gz')
        record['captures'].append(dict(directory=name,status='PASS',source_parent=captured['source_parent'],
            started_utc=captured['started_utc'],finished_utc=captured['finished_utc'],qemu_exit_code=captured.get('qemu_exit_code')))
        print('Retained',name,flush=True)
    compiled = json.loads((final/'record.json').read_text())
    for saved in sorted((final/'staged-source').rglob('*')):
        if saved.is_file() and saved.suffix in ('.rs','.S'):
            bind(repo/'host-kernel/native-rust'/saved.relative_to(final/'staged-source'),saved)
    for row in compiled['compiler_inputs']:
        saved=Path(row['path'])
        for tree in ('tree','setup'):
            prefix=final/tree/'source'
            if saved.is_relative_to(prefix):
                current=repo/saved.relative_to(prefix)
                if current.exists(): bind(current,saved)
    ownership=base/captures[1]
    for row in json.loads((ownership/'record.json').read_text())['inputs']:
        saved=Path(row['path']); bind(repo/saved.relative_to(ownership/'source'),saved)
    guest=json.loads((base/captures[2]/'record.json').read_text())
    assert guest['file_read_checks']==582 and guest['setup_files']==97
    assert guest['topology_comparison_checks']==44 and guest['rollback_cycles']==2
    assert guest['linux_cpu_offline_online_cycles']==4 and guest['namespace_removed']
    assert compiled['setup_layout']==[1056,8,0,8,16,1052]
    binding_archive=out/'native-sysfs-setup-build-source-bindings-20260907.tar.gz'
    with tarfile.open(binding_archive,'w:gz') as tar: tar.add(out/'source-bindings',arcname='source-bindings')
    row=identity(binding_archive);row['path']='docs/verification/evidence/'+binding_archive.name;record['artifacts'].append(row)
    for name in ['build-native-sysfs-setup.py','check-native-sysfs-ownership.py','run-native-sysfs-setup-guest.py',
        'native-sysfs-setup-guest-init.sh','native-sysfs-setup-guest-validation.inc','retain-native-sysfs-setup-build.py']:
        retain_gzip(base/name,'native-sysfs-setup-build-20260907-'+name+'.gz')
    for row in record['artifacts']:
        checksum=hashlib.sha256();size=0
        with gzip.open(out/Path(row['path']).name,'rb') as stream:
            for chunk in iter(lambda:stream.read(1<<20),b''):checksum.update(chunk);size+=len(chunk)
        if 'unpacked_size' in row: assert size==row['unpacked_size'] and checksum.hexdigest()==row['unpacked_sha256'],row
    record.update(status='PASS',native_cpu_context_integrated=True,setup_layout=compiled['setup_layout'],
        protocol_tests=3,concurrent_setup_exchanges=4096,actual_ownership_body_tests=2,
        linux_fixture_module_cycles=2,topology_comparison_checks=44,setup_files=97,file_read_checks=582,
        setup_directories=guest['setup_directories'],setup_links=guest['setup_links'],rollback_cycles=2,
        linux_cpu_offline_online_cycles=4,namespace_removed=True,
        scope='Production topology ownership/setup implementation builds; protocol/extent bodies and real Linux setup tree pass. Actual OS setup exchange remains unverified.',
        limitations=['The new kernel and integrated native CPU owner still require OS preparation and both actual McKernel startup interfaces.',
            'Not every new allocation failure has been injected; the real Linux fixture forces a mid-publication invalid-cache error and verifies rollback.',
            'The ownership-body fixture records setup callbacks; actual Linux namespace effects are independently checked by the separate module guest.',
            'Full ready status, continuing remote services, application launch/tests, native shutdown, declared staging/contracts/current full suite, complete McKernel and linked support Rust/assembly ownership and independent production acceptance remain open.'])
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'native-sysfs-setup-build-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],'retained',len(record['artifacts']),'setup build artifacts',flush=True)
