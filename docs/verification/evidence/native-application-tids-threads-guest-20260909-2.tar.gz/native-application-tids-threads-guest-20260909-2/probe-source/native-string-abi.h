#define MCEXEC_UP_STRNCPY_FROM_USER 0x30a02908
struct strncpy_from_user_desc {
	void *dest;
	void *src;
	unsigned long n;
	long result;
};
