"""Retain syscall protocol prerequisites without claiming application execution."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-syscall-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-syscall-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],
    scope='Verified syscall protocol prerequisite and native compile selection; unchanged image/protocol regressions. Native mailbox, response claim adapter, wait/return ioctls, procfs and START remain unconnected.',
    native_mailbox_integrated=False,user_syscall_ioctls_integrated=False,procfs_integrated=False,
    application_attempted_in_this_checkpoint=False,mckernel_application_executed=False,
    declared_stage_integrated=False,production_gate_credit=False,independent_acceptance=False,
    application_acceptance='FAIL: last actual launcher reached unimplemented START_IMAGE')
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    prior_path=repo/'docs/verification/native-application-launcher-checkpoint-20260908.json'
    prior=json.loads(prior_path.read_text());assert prior['status']=='PASS' and not prior['mckernel_application_executed']
    reference=identity(prior_path);reference['path']=str(prior_path.relative_to(repo));record['references'].append(reference)
    record['last_actual_launcher']=prior['actual_launcher']
    assert record['last_actual_launcher']['reached']=='START_IMAGE'
    assert record['last_actual_launcher']['overall_result']=='FAIL'
    captures=['native-application-syscall-20260908-1','native-application-syscall-20260908-2',
              'native-application-image-20260908-7','native-application-syscall-module-20260908-1']
    for name in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']=='PASS',name
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        for row in state.get('overlay',[]):
            verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status='PASS',complete_capture_retained=True,archive_exclusions={}))

    compiled=work/'native-application-syscall-module-20260908-1';replays=[]
    old=work/'native-application-service-module-20260908-2/staged-source';changed=[];added=[]
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if not (old/relative).exists():added.append(str(relative))
        elif (old/relative).read_bytes()!=saved.read_bytes():changed.append(str(relative))
        if current.read_bytes()==saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout);assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='Exact pinned rustfmt replay; original and formatted files retained',
                compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,
                format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(row);replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'}
    assert len(record['native_compiler_bindings'])==50
    assert set(changed)=={'application_rpc.rs','ihk_smp_x86_64.rs'} and added==['application_syscall.rs']
    record['native_change_scope']=dict(previous_runtime_module=str(old.parent),unchanged_sources=47,
        changed_sources=changed,added_sources=added,new_module_guest_tested=False,
        selected_for_compilation_only='application_syscall.rs; native service adapter remains required')
    record['current_native_module']=str(compiled)

    for key,directory,expected_count in [('syscall_protocol',work/'native-application-syscall-20260908-2',12),
                                       ('image_protocol',work/'native-application-image-20260908-7',15)]:
        state=json.loads((directory/'record.json').read_text());assert state['status']=='PASS'
        rows=[]
        for row in state['inputs']:
            relative=Path(row['path']).relative_to(directory/'original-inputs')
            rows.append(binding(repo/relative,directory/'source'/relative))
        assert len(rows)==expected_count
        record[key+'_compiler_bindings']=rows
        for body in state['extracted_bodies']:
            raw=(directory/'source'/body['source']).read_bytes()[body['start_byte']:body['end_byte']]
            assert hashlib.sha256(raw).hexdigest()==body['sha256'],body
        record[key+'_extracted_bodies']=state['extracted_bodies']
    protocol=work/'native-application-syscall-20260908-2';state=json.loads((protocol/'record.json').read_text())
    assert '11 passed; 0 failed;' in (protocol/'rust-tests.log').read_text()
    assert not (protocol/'rust-build.log').read_bytes()
    assert len(state['extracted_bodies'])==25
    for key,value in [('exact_request_vectors',6),('exact_completion_vectors',12),('queue_full_retries',1024),('atomic_race_rounds',256),('concurrent_tokens',4096)]:
        assert state[key]==value,key
    record['syscall_protocol']=dict(capture=str(protocol),tests_passed=11,c_layout=state['c_layout'],
        exact_request_vectors=6,exact_completion_vectors=12,queue_full_retries=1024,atomic_race_rounds=256,
        concurrent_tokens=4096,exact_extracted_bodies=25,rust_warnings_enforced=True,
        initial_unused_import_warning_retained='native-application-syscall-20260908-1',
        intentional_queue_failure_change='Keep status zero and retain the wake for retry; the original C path publishes status even if send fails',
        limitations='Delivery/requeue/TID checks are protocol state tests; atomics use the actual core body. No real mailbox, copyout, response ledger or application was exercised.')
    image=work/'native-application-image-20260908-7'
    assert '8 passed; 0 failed;' in (image/'protocol-tests.log').read_text()
    assert '11 passed; 0 failed;' in (image/'image-tests.log').read_text()
    record['image_protocol']=dict(capture=str(image),tests_passed=19,previous_assertions_preserved=True)

    record['unchanged_guest_peer_bindings']=[]
    for name in ['kernel/rust/abi.rs','kernel/rust/syscall_policy.rs','kernel/rust/host_helpers.rs','kernel/syscall.c']:
        record['unchanged_guest_peer_bindings'].append(binding(repo/name,work/'mckernel-native-sysfs-images-20260908-2/source'/name))
    linux=work/'native-source/linux-6.12.0-211.44.1.el10_2';references=out/'linux-reference';references.mkdir()
    record['pinned_linux_review_sources']=[]
    for name in ['rust/kernel/sync/condvar.rs','rust/kernel/sync/lock/mutex.rs','rust/kernel/sync/arc.rs',
                 'rust/kernel/task.rs','rust/kernel/uaccess.rs','include/linux/proc_fs.h','fs/proc/inode.c']:
        target=references/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(linux/name,target)
        assert target.read_bytes()==(linux/name).read_bytes()
        record['pinned_linux_review_sources'].append(dict(original=identity(linux/name),retained=identity(target)))
    artifact(references,'native-syscall-20260908-linux-reference.tar.gz',True)
    artifact(out/'format-replay','native-syscall-20260908-format-replay.tar.gz',True)
    for name in ['test-native-application-syscall.py','test-native-application-image.py','build-native-application-syscall.py']:
        artifact(work/name,'native-syscall-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-syscall-20260908-retain-helper.py.gz')
    record.update(status='PASS',complete_captures=4,original_failures_in_this_batch=0,
        original_warning_capture_preserved=True,artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
