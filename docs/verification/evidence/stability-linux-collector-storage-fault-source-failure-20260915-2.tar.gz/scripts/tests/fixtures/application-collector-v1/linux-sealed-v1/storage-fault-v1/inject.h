#ifndef M02_STORAGE_FAULT_TEST_ONLY
#error "storage-fault seams are test-only"
#endif
#ifndef M02_STORAGE_FAULT_CASE
#error "storage-fault selector required"
#endif
#if M02_STORAGE_FAULT_CASE < 0 || M02_STORAGE_FAULT_CASE > 5
#error "unknown storage-fault selector"
#endif
/* Generated seam declarations. Production collector is never linked here. */
enum m02_storage_fault { M02_SF_CONTROL=0, M02_SF_ARTIFACT_CREATE=1,
    M02_SF_WRITE_ENOSPC=2, M02_SF_ARTIFACT_FSYNC=3,
    M02_SF_REPORT_OPEN=4, M02_SF_REPORT_FSYNC=5 };
static inline int m02_storage_fault_errno(int operation)
{
    if (M02_STORAGE_FAULT_CASE == operation) {
        return operation == M02_SF_ARTIFACT_FSYNC || operation == M02_SF_REPORT_FSYNC ? 5 : 28;
    }
    return 0;
}
static inline int m02_storage_fault_guard(void) { return M02_STORAGE_FAULT_CASE >= 0; }
