#!/usr/bin/env python3
"""Strict offline oracle for retained storage-fault observations."""
import hashlib,json,os,stat
from pathlib import Path
EXPECTED={0:(0,'COMPLETED',0,False),1:(256,'PREPARATION_ERROR',28,False),2:(256,'COLLECTOR_ERROR',28,False),3:(256,'COLLECTOR_ERROR',5,False),4:(32000,'COMPLETED',28,True),5:(32000,'COMPLETED',5,True)}
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p); assert p.is_absolute() and p.resolve()==p and p.is_file(), 'canonical witness'; fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC); 
 try:
  s=os.fstat(fd); assert stat.S_ISREG(s.st_mode) and s.st_size<=65536; b=os.read(fd,s.st_size+1); assert len(b)==s.st_size; return b
 finally: os.close(fd)
def strict(b):
 def pairs(xs):
  d={}
  for k,v in xs: assert k not in d,'duplicate key'; d[k]=v
  return d
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite')))
def validate(root,selector):
 root=Path(root); assert selector in EXPECTED; raw=read(root/'witness.json'); w=strict(raw); exp,status,err,report=EXPECTED[selector]
 assert w['schema_version']==1 and w['selector']==selector and w['raw_wait_status']==exp and w['status']==status and w['errno']==err
 assert w['source_sha256']=='09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f'
 for k in ('nonce','elf_sha256','argv','environment','collector_pid','collector_startticks','seam','occurrence','operation_boundary','monotonic_ns','file_fsync','parent_fsync'): assert k in w
 assert len(w['nonce'])==32 and len(w['elf_sha256'])==64 and w['collector_pid']>0 and w['collector_startticks']>0 and w['monotonic_ns']>0
 assert w['file_fsync'] is True and w['parent_fsync'] is True and w['report_failure'] is report
 if selector==2: assert w['prefix_bytes']==7
 assert w['original_report_sha256']==sha(read(root/'original-report.json'))
 return True
