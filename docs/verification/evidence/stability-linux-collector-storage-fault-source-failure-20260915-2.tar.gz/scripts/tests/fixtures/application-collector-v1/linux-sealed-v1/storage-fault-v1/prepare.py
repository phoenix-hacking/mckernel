#!/usr/bin/env python3
"""Prepare a guarded storage-fault source; this module never builds or runs it."""
import argparse, hashlib, json, os, difflib
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'collector.c'
SOURCE_SHA='09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f'
CASES={'control':0,'artifact-create-enospc':1,'write-seven-enospc':2,'artifact-fsync-eio':3,'report-open-enospc':4,'report-fsync-eio':5}
def sha(x): return hashlib.sha256(x).hexdigest()
def read(p):
 p=Path(p); assert p.is_absolute() and p.resolve()==p and p.is_file(), 'canonical regular input'
 return p.read_bytes()
def packet(p):
 r=json.loads(read(p)); assert r['schema_version']==1 and r['kind']=='linux-sealed-collector-storage-fault-v1'
 assert r['application_acceptance'] is False and r['backend_enabled'] is False
 assert sha(read(SOURCE))==SOURCE_SHA==r['source']['sha256']; assert [x['selector'] for x in r['cases']]==list(range(6)); return r
def generate(raw):
 assert sha(raw)==SOURCE_SHA
 assert raw.count(b'#include <unistd.h>\n')==1
 assert raw.count(b'#define SETUP_PACKET (SETUP_WORDS * 8U)\n')==1
 assert b'M02_STORAGE_FAULT_CASE' not in raw
 text=raw.decode()
 text=text.replace('#define SETUP_PACKET (SETUP_WORDS * 8U)\n','#define SETUP_PACKET (SETUP_WORDS * 8U)\n#include "inject.h"\n',1)
 anchor='static bool new_sink(struct sink *s, const char *name, uint64_t limit)\n'
 assert text.count(anchor)==1
 text=text.replace(anchor,'static bool m02_storage_fault_new_sink_guard(struct sink *s, const char *name, uint64_t limit) { return m02_storage_fault_guard() && m02_storage_fault_errno(M02_SF_ARTIFACT_CREATE) == 0; }\n'+anchor,1)
 assert text.count('static bool m02_storage_fault_new_sink_guard')==1
 return text.encode()
def main():
 a=argparse.ArgumentParser(); a.add_argument('--packet',type=Path,required=True); a.add_argument('--attempt-root',type=Path,required=True); x=a.parse_args(); packet(x.packet); raw=read(SOURCE); gen=generate(raw)
 assert not x.attempt_root.exists(); x.attempt_root.mkdir(mode=0o700,parents=False)
 for n,b,m in [('source.collector.c',raw,0o600),('storage-fault-collector.c',gen,0o644),('inject.h',read(HERE/'inject.h'),0o600)]:
  fd=os.open(x.attempt_root/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL, m); os.write(fd,b); os.fsync(fd); os.close(fd)
 diff=''.join(difflib.unified_diff(raw.decode().splitlines(True),gen.decode().splitlines(True),fromfile='collector.c',tofile='storage-fault-collector.c')).encode()
 fd=os.open(x.attempt_root/'generated.diff',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600); os.write(fd,diff); os.fsync(fd); os.close(fd)
 rec={'schema_version':1,'status':'PREPARED_NOT_EXECUTED','source_sha256':sha(raw),'generated_sha256':sha(gen),'diff_sha256':sha(diff),'cases':CASES,'application_acceptance':False,'witness_schema':'independent-fsynced-v1'}
 (x.attempt_root/'prepare.json').write_text(json.dumps(rec,sort_keys=True,indent=2)+'\n'); os.chmod(x.attempt_root/'prepare.json',0o600); print(json.dumps(rec,sort_keys=True))
if __name__=='__main__': main()
