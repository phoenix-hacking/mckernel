# storage-fault-v1 source packet

This additive Linux-instrumented packet covers only selectors 0–5: control,
artifact creation ENOSPC, seven-byte write then ENOSPC, artifact fsync EIO,
report open ENOSPC, and report fsync EIO. Cases preserve raw wait 256 for
collector failures and 32000 when report serialization fails. Every execution
must precreate and fsync an independent witness file and its parent directory;
the original report is immutable. This packet is not application or production
acceptance and does not claim media/power-loss durability.
