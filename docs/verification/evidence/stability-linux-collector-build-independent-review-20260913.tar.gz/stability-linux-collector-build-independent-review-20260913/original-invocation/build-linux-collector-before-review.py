from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shlex, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-linux-collector-build-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
              commands=[], inputs=[], compiler_dependencies=[], compiled_outputs=[], loader_dependencies=[],
              application_acceptance=False, backend_enabled=False, guest_execution=False,
              root_positive_execution=False, scope='Pinned actual Linux collector build, actual SHA9 and builder identity rejection only')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    source = repo / 'scripts/tests/fixtures/application-collector-v1'
    review_path = repo / 'docs/verification/stability-linux-collector-source-review-20260913-1.json'
    assert identity(review_path)['sha256'] == '7b5527f0c302f1e1f4cf0c1f221c842687ab6aab6b1dc67ed33d50341e68595d'
    review = json.loads(review_path.read_text())
    shutil.copyfile(review_path, out / 'source-review.json')
    record['source_review'] = identity(review_path)
    for row in review['source_inputs']:
        src = repo / Path(row['path']).relative_to('/home/holden/mckernel')
        observed = identity(src)
        assert (observed['size'], observed['sha256']) == (row['size_bytes'], row['sha256'])
        dst = out / 'source' / src.relative_to(source); dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=observed, retained=identity(dst)))
    for name, expected in {'request.c':'c072005948e479e6f50d3f647bf649301741365d7c034c72d3047df3f85cc3ab',
                           'request.h':'e767e217104d3b89b0b6d0f74e37f8150600c0b078d40799e75d14f3ede8d00e'}.items():
        src = source / name
        assert identity(src)['sha256'] == expected
        dst = out / 'source' / name; shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    src = repo / 'scripts/application-tests/supervisor.py'
    assert identity(src)['sha256'] == '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
    shutil.copyfile(src, out / 'supervisor.py')
    record['inputs'].append(dict(original=identity(src), retained=identity(out / 'supervisor.py')))
    spec = importlib.util.spec_from_file_location('collector_build_supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    def run(label, argv, timeout=120, cap=8*1024**2):
        if not Path(argv[0]).is_absolute(): argv[0] = shutil.which(argv[0], path=env['PATH'])
        record['phase'] = label; save(); print('RUN', label, flush=True)
        result = supervisor.run_supervised(argv, cwd=str(out), env=env,
            attempt_dir=str(out / (label + '-collection')), timeout_seconds=timeout,
            cleanup_timeout_seconds=15, stdout_limit_bytes=cap, stderr_limit_bytes=cap)
        record['commands'].append(dict(label=label, argv=argv, environment=env, collection=result)); save()
        assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete'], (label, result)
        return (out / (label + '-collection') / 'stdout.bin').read_text()
    run('compiler-version', ['gcc', '--version'])
    units = {'request': out / 'source/request.c'}
    for name in ('sha256', 'collector', 'fixture', 'sha256_harness'):
        units[name] = out / 'source/linux-sealed-v1' / (name + '.c')
    for name, src in units.items():
        run('compile-' + name, ['gcc', '-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
            '-fno-pie', '-MD', '-MF', str(out / (name + '.d')), '-c', str(src), '-o', str(out / (name + '.o'))])
    executables = {'linux-collector':['request','sha256','collector'], 'fixture':['fixture'], 'sha256-harness':['sha256','sha256_harness']}
    for name, objects in executables.items():
        run('link-' + name, ['gcc', '-no-pie'] + [str(out / (obj + '.o')) for obj in objects] +
            ['-Wl,-Map=' + str(out / (name + '.map')), '-o', str(out / name)])
        run('elf-' + name, ['readelf', '-h', '-l', '-d', str(out / name)])
        run('disassembly-' + name, ['objdump', '-d', str(out / name)])
        for line in run('loader-' + name, ['ldd', str(out / name)]).splitlines():
            for part in line.split():
                if part.startswith('/') and Path(part).is_file():
                    observed = identity(Path(part))
                    if observed not in record['loader_dependencies']: record['loader_dependencies'].append(observed)
    for name in units:
        text = (out / (name + '.d')).read_text().split(':', 1)[1].replace('\\\n', ' ')
        for item in shlex.split(text):
            src = Path(item)
            if not src.is_absolute(): src = out / src
            src = src.resolve()
            row = identity(src)
            if any(old['original'] == row for old in record['compiler_dependencies']): continue
            dst = out / 'compiler-inputs' / str(src).lstrip('/')
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)
            record['compiler_dependencies'].append(dict(original=row, retained=identity(dst)))
    record['compiled_outputs'] = [identity(out / (name + suffix)) for name in units for suffix in ('.o', '.d')]
    record['compiled_outputs'] += [identity(out / (name + suffix)) for name in executables for suffix in ('', '.map')]
    run('sha9', [str(out / 'sha256-harness')], timeout=10, cap=65536)
    expected = b'PASS empty\nPASS abc\nPASS multi-56\nPASS boundary-55\nPASS boundary-56\nPASS boundary-63\nPASS boundary-64\nPASS boundary-65\nPASS rejected-update-preserves-state\n'
    assert (out / 'sha9-collection/stdout.bin').read_bytes() == expected
    assert (out / 'sha9-collection/stderr.bin').read_bytes() == b''
    run('builder-negative', ['/usr/bin/python3', '-B', str(out / 'source/linux-sealed-v1/run_collector_tests.py'),
        '--collector', str(out / 'linux-collector'), '--fixture', str(out / 'fixture'),
        '--supervisor', str(out / 'supervisor.py'), '--attempt-root', str(out / 'builder-negative'), '--builder-only'], timeout=60)
    assert (out / 'builder-negative-collection/stdout.bin').read_bytes() == b'PASS builder-identity\n'
    assert (out / 'builder-negative-collection/stderr.bin').read_bytes() == b''
    driver = json.loads((out / 'builder-negative/record.json').read_text())
    assert driver['status'] == 'PASS_INFRASTRUCTURE_ONLY' and len(driver['cases']) == 1
    assert driver['uid'] == driver['euid'] == 1000
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    for row in record['compiled_outputs'] + record['loader_dependencies']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS_LINUX_COLLECTOR_BUILD_SHA9_BUILDER_NEGATIVE_ONLY', sha_cases=9, builder_cases=1)
except BaseException as error:
    record.update(status='FAIL', error_type=type(error).__name__, error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save(); print(record['status'], out, flush=True)
