"""Read-only retained-data audit; never imports/executes a subject component."""
from pathlib import Path
import hashlib
import json
import os
import posixpath
import shlex
import shutil
import stat
import struct

HERE = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SCRATCH = Path('/home/holden/mckernel-work/scratch')
ATTEMPT = SCRATCH / 'stability-linux-collector-build-20260913-1'
PREFIX = '/work/stability-linux-collector-build-20260913-1'
verified, unmapped = [], []

def digest(data):
    return hashlib.sha256(data).hexdigest()

def mapped(path):
    if path.startswith('/workspace/'):
        return REPO / path[len('/workspace/'):]
    if path.startswith('/work/'):
        return SCRATCH / path[len('/work/'):]
    if path.startswith(str(REPO) + '/') or path.startswith(str(SCRATCH) + '/'):
        return Path(path)
    return None

def identity(row):
    p = mapped(row['path'])
    if p is None:
        unmapped.append(row)
        return None
    data = p.read_bytes()
    assert len(data) == row.get('size', row.get('size_bytes')) and digest(data) == row['sha256'], p
    verified.append(dict(declared=row, actual_host_path=str(p)))
    return data

def walk_identities(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value and ('size' in value or 'size_bytes' in value):
            identity(value)
        else:
            for item in value.values():
                walk_identities(item)
    elif isinstance(value, list):
        for item in value:
            walk_identities(item)

def collection(result, raw):
    assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == raw
    assert result['cleanup_complete'] and result['descendant_records_omitted'] == 0
    assert result['payload_completion_observed_monotonic'] < result['payload_monotonic_deadline']
    for stream in result['streams'].values():
        assert stream['eof'] and not stream['truncated'] and stream['discarded_observed_bytes'] == 0
        assert stream['bytes_observed'] == stream['bytes_retained'] == stream['artifact']['size']
        identity(stream['artifact'])

def copy_tree(source, target):
    target.mkdir()
    for path in sorted(source.rglob('*')):
        kind = path.lstat()
        rel = path.relative_to(source)
        dest = target / rel
        assert not path.is_symlink(), path
        if stat.S_ISDIR(kind.st_mode):
            dest.mkdir()
        else:
            assert stat.S_ISREG(kind.st_mode), path
            data = path.read_bytes()
            dest.write_bytes(data)
            assert dest.read_bytes() == data == path.read_bytes(), path
        dest.chmod(stat.S_IMODE(kind.st_mode))

raw = (ATTEMPT / 'record.json').read_bytes()
assert digest(raw) == '72ad1e2e01b00c9ccb664096d8c81852f8892b7eb87dab894dc0f59e5d23f783'
record = json.loads(raw)
assert record['status'] == 'PASS_LINUX_COLLECTOR_BUILD_SHA9_BUILDER_NEGATIVE_ONLY'
assert record['sha_cases'] == 9 and record['builder_cases'] == 1
for flag in ('application_acceptance', 'backend_enabled', 'guest_execution', 'root_positive_execution'):
    assert record[flag] is False
copy_tree(ATTEMPT, HERE / 'actual-build')
walk_identities(record)
source_review = identity(record['source_review'])
assert source_review == (ATTEMPT / 'source-review.json').read_bytes()
source_rows = json.loads(source_review)['source_inputs']
for row in source_rows:
    actual = identity(row)
    rel = Path(row['path']).relative_to(REPO / 'scripts/tests/fixtures/application-collector-v1')
    assert actual == (ATTEMPT / 'source' / rel).read_bytes()
for pair in record['inputs'] + record['compiler_dependencies']:
    assert (pair['original']['size'], pair['original']['sha256']) == (pair['retained']['size'], pair['retained']['sha256'])
assert len(record['inputs']) == 14 and len(record['compiler_dependencies']) == 176
dep_rows = {row['original']['path']: row for row in record['compiler_dependencies']}
assert len(dep_rows) == 176
dep_tokens = set()
for unit in ('request', 'sha256', 'collector', 'fixture', 'sha256_harness'):
    text = (ATTEMPT / (unit + '.d')).read_text().split(':', 1)[1].replace('\\\n', ' ')
    for token in shlex.split(text):
        if not token.startswith('/'):
            token = PREFIX + '/' + token
        dep_tokens.add(posixpath.normpath(token))
assert dep_tokens == set(dep_rows), (dep_tokens - set(dep_rows), set(dep_rows) - dep_tokens)

commands = {row['label']: row for row in record['commands']}
assert len(commands) == len(record['commands']) == 20
for name, command in commands.items():
    result = command['collection']
    collection(result, 0)
    assert result == json.loads((ATTEMPT / (name + '-collection/report.json')).read_bytes())
    assert result['uid'] == result['gid'] == 1000 and result['groups'] == [1000]
    assert result['argv'] == command['argv'] and result['cwd'] == PREFIX
    if name.startswith('compile-'):
        assert command['argv'][1:9] == ['-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror', '-fno-pie']
        assert (ATTEMPT / (name + '-collection/stdout.bin')).read_bytes() == b''
        assert (ATTEMPT / (name + '-collection/stderr.bin')).read_bytes() == b''
expected_links = {'linux-collector': ['request', 'sha256', 'collector'], 'fixture': ['fixture'], 'sha256-harness': ['sha256', 'sha256_harness']}
elfs = []
for name, units in expected_links.items():
    argv = commands['link-' + name]['argv']
    assert argv == ['/usr/bin/gcc', '-no-pie'] + [PREFIX + '/' + unit + '.o' for unit in units] + ['-Wl,-Map=' + PREFIX + '/' + name + '.map', '-o', PREFIX + '/' + name]
    data = (ATTEMPT / name).read_bytes()
    assert data[:6] == b'\x7fELF\x02\x01'
    assert struct.unpack_from('<HH', data, 16) == (2, 62)
    elf = dict(path=PREFIX + '/' + name, size=len(data), sha256=digest(data), type='ELF64_LE_ET_EXEC_EM_X86_64')
    assert any(row['path'] == elf['path'] and row['sha256'] == elf['sha256'] for row in record['compiled_outputs'])
    elfs.append(elf)
    for unit in units:
        assert ('LOAD ' + PREFIX + '/' + unit + '.o') in (ATTEMPT / (name + '.map')).read_text()
assert commands['sha9']['collection']['executable']['sha256'] == elfs[2]['sha256']
expected_sha = b'PASS empty\nPASS abc\nPASS multi-56\nPASS boundary-55\nPASS boundary-56\nPASS boundary-63\nPASS boundary-64\nPASS boundary-65\nPASS rejected-update-preserves-state\n'
assert (ATTEMPT / 'sha9-collection/stdout.bin').read_bytes() == expected_sha
assert (ATTEMPT / 'sha9-collection/stderr.bin').read_bytes() == b''
assert (ATTEMPT / 'builder-negative-collection/stdout.bin').read_bytes() == ('PASS builder-identity\nRETAINED ' + PREFIX + '/builder-negative\n').encode()
assert (ATTEMPT / 'builder-negative-collection/stderr.bin').read_bytes() == b''

case = ATTEMPT / 'builder-negative/builder-identity'
driver = json.loads((ATTEMPT / 'builder-negative/result.json').read_bytes())
outer = json.loads((case / 'outer-returned.json').read_bytes())
report = json.loads((case / 'collection/report.json').read_bytes())
invocation = json.loads((case / 'invocation.json').read_bytes())
walk_identities(driver)
walk_identities(outer)
walk_identities(invocation)
collection(outer, 512)
assert outer == json.loads((case / 'outer/report.json').read_bytes())
assert outer['argv'] == invocation['argv'] and outer['cwd'] == invocation['cwd'] and outer['env'] == invocation['env']
assert outer['uid'] == outer['gid'] == driver['uid'] == driver['euid'] == 1000
assert outer['executable']['sha256'] == elfs[0]['sha256']
assert report['collector_pid'] == outer['process']['pid'] == 77
assert report['collector_uid'] == report['collector_euid'] == 1000
assert report['status'] == 'BLOCKED' and report['first_failure'] == 'root-infrastructure-identity-required' and report['first_failure_errno'] == 1
assert report['request_valid'] is True and report['child_created'] is False and report['linux_child'] is None
assert report['owned_children'] == [] and report['owned_records_omitted'] == 0
assert outer['descendants'] == [] and outer['wait_status'] == dict(kind='exited', code=2)
assert driver['cases'] == [dict(case='builder-identity', observed_status='BLOCKED', status='PASS_INFRASTRUCTURE_ONLY')]
for key in ('application_acceptance', 'transport_acceptance', 'backend_enabled', 'pathname_execution', 'loader_closure_verified'):
    assert report[key] is False
wire = (case / 'inputs/request.bin').read_bytes()
assert wire == (case / 'expected-request.bin').read_bytes() == (case / 'collection/request.bin').read_bytes()
assert wire[:8] == b'ACRQ0001' and struct.unpack_from('<III', wire, 8) == (1, 256, len(wire))
assert struct.unpack_from('<6I', wire, 24) == (1, 1, 0, 0, 1, 0)
assert struct.unpack_from('<4I', wire, 48) == (18, 2, 0, 0)
assert struct.unpack_from('<6I', wire, 64) == (1, 1, 10000, 15000, 65536, 65536)
assert wire[200:216] == hashlib.sha256(b'builder-identity').digest()[:16] and wire[216:256] == bytes(40)
strings, position = [], 256
for _ in range(6):
    length = struct.unpack_from('<I', wire, position)[0]
    position += 4
    strings.append(wire[position:position + length])
    position += length
assert position == len(wire)
assert strings == [b'infrastructure.collector', (PREFIX + '/builder-negative/builder-identity/inputs/fixture').encode(), (PREFIX + '/builder-negative/builder-identity/cwd').encode(), b'/dev/null', b'literal-app', b'stdin-devnull']
manifest = b'{"kind":"opaque-infrastructure-input-bytes","application_acceptance":false}\n'
assert (case / 'inputs/selected-inputs.json').read_bytes() == manifest == (case / 'collection/selected-inputs.bin').read_bytes()
assert wire[104:136] == hashlib.sha256(manifest).digest()
assert wire[136:168] == hashlib.sha256((ATTEMPT / 'fixture').read_bytes()).digest() and wire[168:200] == bytes(32)
assert struct.unpack_from('<QQ', wire, 88) == (elfs[1]['size'], 0)
artifacts = [row for row in report['artifacts'] if row is not None]
assert [row['path'] for row in artifacts] == ['request.bin', 'selected-inputs.bin', 'events.jsonl']
for row in artifacts:
    data = (case / 'collection' / row['path']).read_bytes()
    assert row['created'] and row['fd_available'] and row['creation_errno'] == row['fd_errno'] == 0
    assert row['stored_bytes'] == row['seen_bytes'] == len(data) and row['sha256'] == digest(data)
    assert not row['truncated'] and not row['io_error']
events = [json.loads(line) for line in (case / 'collection/events.jsonl').read_bytes().splitlines()]
assert [row['event'] for row in events] == ['collector-start', 'collector-finish']
assert events[0]['pid'] == 77 and events[1]['first_failure'] == report['first_failure']
assert report['preparation_start_ns'] <= events[0]['monotonic_ns'] <= report['first_failure_monotonic_ns'] <= events[1]['monotonic_ns'] < report['preparation_deadline_ns']
assert (case / 'outer/stdout.bin').read_bytes() == (case / 'outer/stderr.bin').read_bytes() == b''
invocation_dir = HERE / 'original-invocation'
invocation_dir.mkdir()
for name in ('build-linux-collector.py', 'build-linux-collector-before-review.py', 'build-linux-collector-1.log'):
    path = SCRATCH / 'stability-20260913-1' / name
    (invocation_dir / name).write_bytes(path.read_bytes())
assert (invocation_dir / 'build-linux-collector.py').read_bytes() == (ATTEMPT / 'helper.py').read_bytes()
assert (ATTEMPT / 'record.json').read_bytes() == raw
review = dict(status='INDEPENDENT_REVIEW_PASS_BUILD_SHA9_AND_BUILDER_REJECTION_ONLY', original_record_sha256=digest(raw),
    source_inputs=record['inputs'], compiled_executables=elfs, commands_checked=20,
    compile_units=5, compiler_dependency_pairs=176, exact_dependency_file_union=True,
    actual_sha_cases=9, actual_builder_negative_cases=1,
    builder_observation=dict(uid=1000, euid=1000, collector_pid=77, raw_wait_status=512, exited=2,
        request_bytes=len(wire), status='BLOCKED', reason='root-infrastructure-identity-required', errno=1,
        child_created=False, outer_cleanup_complete=True, internal_child_cleanup_not_applicable=True),
    verified_identity_occurrences=verified, unmapped_container_identity_occurrences=unmapped,
    evidence_scope='Retained actual outputs independently inspected; no subject import, test, compiler, container or guest rerun.',
    limitations=['Container-only original compiler/header/library/tool references were not reopened on the host; retained compiler input copies were independently hashed and joined to recorded originals.',
        'No root-positive collector profile execution or child setup/exec/cleanup acceptance; actual builder failure precedes fork.',
        'No native payload, pathname execution, loader closure, application backend or transport/catalog acceptance.'],
    source_semantics=['Actual collector source line909 rejects nonroot UID/EUID before fork at946.',
        'Internal report cleanup_complete=false and EOF=false describe a child that was never created; outer Linux collector process has actual completed raw512, empty streams and owned cleanup.'],
    application_acceptance=False, transport_acceptance=False, backend_enabled=False, guest_execution=False, subject_execution_by_reviewer=False)
(HERE / 'review.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
print('PASS retained audit', len(verified), 'mapped identity occurrences;', len(unmapped), 'container-only identity occurrences')
print('review_sha256', digest((HERE / 'review.json').read_bytes()))
