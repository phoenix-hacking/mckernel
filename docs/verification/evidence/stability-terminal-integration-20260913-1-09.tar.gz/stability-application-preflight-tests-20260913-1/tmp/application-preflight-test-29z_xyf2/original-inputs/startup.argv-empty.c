reviewed metadata test source; never compiled
