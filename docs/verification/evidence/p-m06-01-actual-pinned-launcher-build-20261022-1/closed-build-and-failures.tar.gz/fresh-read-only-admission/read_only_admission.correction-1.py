import ast,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ENGINE=Path('/home/holden/mckernel-work/host-preparation/m07-proc-acquisition-repair-20261022-1/retention-correction-1/coupled/bound-terminal-proc-v2-source-4/cleanup_pass_image.py')
EXPECTED='414ac6ff817e820d8dfd5524396d455f0d6ec87f3fbf31fd7558e1683eed4ce4'
def need(v,m):
 if not v:raise RuntimeError(m)
def run(a):
 p=subprocess.run(a,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12)
 if p.returncode or p.stderr or len(p.stdout)>4*1024**2:
  sys.stderr.write(json.dumps(dict(argv=a,returncode=p.returncode,stdout_bytes=len(p.stdout),stderr=p.stderr[:65536].decode('utf-8','replace'),stderr_total_bytes=len(p.stderr)))+'\n')
  raise RuntimeError('bounded read-only command')
 return p.stdout.decode()
need(os.geteuid()==0,'authenticated root read-only admission')
b=ENGINE.read_bytes();need(hashlib.sha256(b).hexdigest()==EXPECTED,'accepted census source')
code=next(ast.literal_eval(n.value) for n in ast.parse(b).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROC_CODE' for t in n.targets))
pid=os.getpid();start=Path('/proc/self/stat').read_text().rpartition(') ')[2].split()[19]
proc=json.loads(run(['/usr/bin/python3','-I','-B','-c',code,'m06-pinned-launcher-admission-20261022-1',str(pid),start]))
need(proc['status']=='COMPLETE' and proc['failure'] is None and proc['publishers']==[] and len(proc['snapshots'])==2,'complete publisher-free census')
root=Path('/home/holden/mckernel-work/scratch');backing=Path('/home/holden/mckernel-work/scratch.ext4');bs=backing.stat();host=os.statvfs('/home/holden/mckernel');scratch=os.statvfs(root)
need(bs.st_ino==47468427 and bs.st_size==118111600640,'110GiB backing identity')
mount=json.loads(run(['/usr/bin/findmnt','-J','-o','TARGET,UUID','-T',str(root)]))['filesystems']
need(mount==[dict(target=str(root),uuid='2a5768c8-718d-4914-bdc0-6b32c5a92a52')],'scratch UUID')
lock=Path('/run/lock/mckernel-development.lock').stat();need((lock.st_dev,lock.st_ino,lock.st_uid,lock.st_gid,lock.st_nlink)==(27,4,0,0,1),'permanent mutex')
key=f'{os.major(lock.st_dev):02x}:{os.minor(lock.st_dev):02x}:{lock.st_ino}'
locks=[l for l in Path('/proc/locks').read_text().splitlines() if key in l.split()];need(not locks,'permanent mutex currently held')
old=Path('/home/holden/mckernel-work/host-preparation/m07-sigill-current-image-successor-preparation-20261022-1/full-image-attempt-1')
paths=[str(old/'lease.json'),str(old/'common-exclusion.json'),'/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock'];need(all(not os.path.lexists(p) for p in paths),'latest retired ownership names absent')
cid='c8fd6e8525d8d63c43d380f2b045e141568d0847457eed97553a00be821dcbbf'
need(run(['/usr/bin/docker','ps','-aq','--no-trunc','--filter','id='+cid])=='','latest retired container absent')
running=run(['/usr/bin/docker','ps','-q','--no-trunc']);need(not running,'competing running container')
freehost=host.f_bavail*host.f_frsize;freescratch=scratch.f_bavail*scratch.f_frsize;growth=bs.st_size-bs.st_blocks*512;minimum=16*2**30+growth+328935465+679477248
need(freehost>=minimum and freescratch>=12*2**30+679477248,'full capacity growth/reserves')
mem=int(next(l for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')).split()[1])*1024
need(mem>=int(16.2158*2**30),'aggregate available memory')
state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_text());need(state['phase']=='running' and state['stop_reason'] is None,'launcher active')
cgroup={p:Path(p).read_text().strip() for p in ['/sys/fs/cgroup/cgroup.controllers','/sys/fs/cgroup/cpuset.cpus.effective','/sys/fs/cgroup/memory.max']}
print(json.dumps(dict(status='PASS_FRESH_READ_ONLY_M06_BUILD_ADMISSION',proc=proc,mount=mount,backing=dict(dev=bs.st_dev,inode=bs.st_ino,size=bs.st_size,allocated=bs.st_blocks*512),host_available=freehost,scratch_available=freescratch,minimum_host=minimum,memory_available=mem,affinity=sorted(os.sched_getaffinity(0)),root_lock=[lock.st_dev,lock.st_ino],ownership_paths_absent=paths,running_containers=[],cgroup=cgroup,mutation=False,at_unix=time.time()),sort_keys=True))
