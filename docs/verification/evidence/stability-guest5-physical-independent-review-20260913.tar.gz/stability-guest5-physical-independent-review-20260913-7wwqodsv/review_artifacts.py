from pathlib import Path
import base64, hashlib, json, re, stat, struct
ROOT = Path(__file__).resolve().parent
WORK = Path('/home/holden/mckernel-work/scratch')
REPO = Path('/home/holden/mckernel')
GUEST = WORK / 'stability-transport-fault-guest-20260913-prepublish-hard-5'
DIAG = WORK / 'stability-hard-physical-diagnostic-20260913-1'
rows, blobs = [], {}
sha = lambda b: hashlib.sha256(b).hexdigest()
def take(path, expected=None):
    path = Path(path)
    if path not in blobs:
        before = path.lstat()
        assert stat.S_ISREG(before.st_mode), path
        data = path.read_bytes()
        after = path.lstat()
        assert (before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), path
        rel = ('work/' + path.relative_to(WORK).as_posix()) if path.is_relative_to(WORK) else 'repository/' + path.relative_to(REPO).as_posix()
        destination = ROOT/'inputs'/rel
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(data)
        destination.chmod(stat.S_IMODE(before.st_mode))
        rows.append(dict(path=str(path),retained=destination.relative_to(ROOT).as_posix(),size=len(data),sha256=sha(data),mode=stat.S_IMODE(before.st_mode)))
        blobs[path] = data
    data = blobs[path]
    if expected is not None:
        assert len(data)==expected['size'] and sha(data)==expected['sha256'], path
    return data
def mapped(wire):
    if wire.startswith('/work/'): return WORK/wire.removeprefix('/work/')
    if wire.startswith('/workspace/'): return REPO/wire.removeprefix('/workspace/')
    raise AssertionError(wire)
def bound(row): return take(mapped(row['path']),row)
def read_json(path): return json.loads(take(path))
result = dict(schema_version=1,status='RUNNING_READ_ONLY_ARTIFACT_REVIEW',application_acceptance=False,transport_acceptance=False,production_gate_credit=False,tests_executed=False,build_execution=False,guest_execution=False,subject_helpers_imported_or_executed=False)
try:
    diagnostic=read_json(DIAG/'record.json')
    for p in DIAG.iterdir(): take(p)
    assert diagnostic['status']=='PHYSICAL_COMPARISONS_MATCH_ORIGINAL_RUN_FAIL'
    for key in ('application_acceptance','transport_acceptance','production_gate_credit'): assert diagnostic[key] is False
    for reference in diagnostic['inputs']: bound(reference)
    original=json.loads(bound(diagnostic['original_guest_record']))
    assert original['status']=='FAIL' and original['error']==diagnostic['original_failure_preserved']=='terminal inventories changed'
    assert original['qemu_exit_code']==0 and original['cleanup_errors']==[] and original['export_thread_finished'] is True
    for key in ('application_acceptance','transport_acceptance','production_gate_credit','physical_full_ring_verified'): assert original[key] is False
    for name,expected in [('physical_observations.py','bf343ff9b3e59e2b92cf6481b6b181e45e9204afed5dfaf8ded4e7b063a0460a'),('owner_observations.py','97466f94dff53fc250509859d164a9858a4f361405ad62b82bb59ab621f77bcf')]:
        assert sha(take(DIAG/name))==expected
        assert take(REPO/'scripts/application-tests'/name)==take(DIAG/name)
    assert take(DIAG/'owner_observations.py')==take(GUEST/'source/owner_observations.py')
    for p in (GUEST/'source').iterdir(): take(p)
    for reference in original['inputs']:
        if reference['path'].endswith('/record.json') and reference['path'].startswith('/work/stability-fault-guest-root-'): bound(reference)
    for rel in ['helper.py','capture-reference.py','capture-reference.original.py','qmp-recovery.json','qmp-transcript.json','native-prefix-mapping.json','serial.log','uart/rx.bin','uart/tx.bin','uart/report.json','uart/events.jsonl','guest-artifacts/files/mckernel/report.json','guest-artifacts/files/mckernel/events.jsonl']:
        take(GUEST/rel)
    raw=take(GUEST/'native-dmesg.canonical.bin')
    owners=read_json(GUEST/'owner-observations.json')
    assert base64.b64decode(owners['raw']['base64'],validate=True)==raw
    assert owners['raw']['size']==len(raw) and owners['raw']['sha256']==sha(raw)
    lines=raw.splitlines(keepends=True)
    for record in [r for s in owners['snapshots'] for r in s['records']]+owners['ret']['records']:
        assert sha(lines[record['line']-1])==record['raw_sha256']
    snapshots=owners['snapshots']
    assert [s['phase'] for s in snapshots]==['BlockedRead','AcceptedReturn','Terminal','TerminalPlusFive']
    key=snapshots[0]['selection']; assert all(s['selection']==key for s in snapshots)
    tid=owners['ret']['key']['tid']
    deliveries=[r['row'] for r in snapshots[0]['records'] if r['kind']=='DELIVERY' and r['application']==key['application'] and r['row']['serial']==key['delivery']]
    assert len(deliveries)==1
    request={k:deliveries[0][k] for k in ('cpu','pid','requester','target','number','arguments','response')}
    for snapshot in snapshots:
        selected=[r['row'] for r in snapshot['records'] if r['kind']=='DELIVERY' and r['application']==key['application'] and r['row']['serial']==key['delivery']]
        assert len(selected)==1 and all(selected[0][k]==v for k,v in request.items())
        assert snapshot['counters']['release_calls']==0 and snapshot['counters']['released'] is False
        assert all(snapshot['counters'][k]==0 for k in ('after_release_calls','duplicate_release','payload_calls','payload_bytes'))
    assert [s['counters']['address_calls'] for s in snapshots]==[0,1,1,1]
    assert diagnostic['selected_counters']==[s['counters'] for s in snapshots]
    ret=owners['ret']; assert diagnostic['ret']==ret and ret['errno']==-71 and ret['accepted']==1 and ret['value']==16
    assert ret['elapsed_ns']==ret['leave_ns']-ret['enter_ns']==45361352
    begins={m.group(1).decode():int(m.group(2)) for m in re.finditer(rb'STABILITY_PHASE_SNAPSHOT_BEGIN version=1 phase_sequence=\d+ phase=(\w+) [^\n]*?mono_ns=(\d+)',raw)}
    ends={int(m.group(1)):int(m.group(2)) for m in re.finditer(rb'STABILITY_PHASE_SNAPSHOT_END version=1 phase_sequence=(\d+) errno=0 mono_ns=(\d+)',raw)}
    assert begins['TerminalPlusFive']-ends[3]>=5_000_000_000
    assert ret['enter_ns']<=begins['AcceptedReturn']<=ends[2]<=ret['leave_ns']<=begins['Terminal']
    recovery=read_json(GUEST/'qmp-recovery.json')
    transcript=read_json(GUEST/'qmp-transcript.json')
    decoded=[]
    pending={'sent': b'', 'received': b''}
    for row in transcript:
        direction=row['direction']; assert direction in pending
        pending[direction]+=bytes.fromhex(row['raw_hex'])
        while b'\n' in pending[direction]:
            line,pending[direction]=pending[direction].split(b'\n',1)
            if line.strip(): decoded.append(dict(direction=direction,monotonic=row['monotonic'],wire=json.loads(line)))
    assert all(not value for value in pending.values()), 'truncated final QMP frame'
    responses=[]; sends=[]; captures=[]
    assert len(original['phase_captures'])==3
    for ordinal,(capture,phase) in enumerate(zip(original['phase_captures'],['PRE_INPUT','POST_RET','QUIET']),1):
        request_frame=capture['request']; manifest=json.loads(bound(capture['manifest']))
        assert manifest['request']==request_frame and manifest['continued'] is True
        assert (request_frame['phase'],request_frame['ack_phase'],request_frame['sequence'],request_frame['nonce'],request_frame['tgid'],request_frame['tid'])==(phase,phase,ordinal,original['nonce'],key['pid'],tid)
        rec=manifest['recovery']; assert rec in recovery and rec['resume_verified'] is True
        assert rec['started_monotonic']<=rec['pause_confirmed_monotonic']<rec['finished_monotonic']
        for artifact in manifest['artifacts']: bound(artifact)
        directory=mapped(capture['manifest']['path']).parent
        descriptor=read_json(directory/'selected-response.json')
        assert descriptor['selection']==key and descriptor['host_post_release_read'] is False
        responses.append(bound(descriptor['artifact']))
        sends.append(take(directory/'control-501-send.bin'))
        metadata=[c for c in original['captures'] if mapped(c['directory'])==directory]
        assert len(metadata)==1 and metadata[0]['owner']==dict(slot=key['os'],generation=key['generation'])
        queue=next(q for q in metadata[0]['queues'] if q['port']==501 and q['direction']=='send')
        assert queue['physical']==diagnostic['queue_physical_addresses']['send501'] and queue['bytes']==16384
        interval=[e for e in decoded if rec['started_monotonic']<=e['monotonic']<=rec['finished_monotonic']]
        commands=[e for e in interval if e['direction']=='sent']
        returns={e['wire']['id']:e for e in interval if e['direction']=='received' and 'return' in e['wire'] and 'id' in e['wire']}
        assert commands[0]['wire']['execute']=='stop'
        paused=[e for e in interval if e['direction']=='received' and e['wire'].get('return')==dict(status='paused',running=False)]
        resumed=[e for e in interval if e['direction']=='received' and e['wire'].get('return')==dict(status='running',running=True)]
        assert len(paused)==len(resumed)==1 and paused[0]['monotonic']<=rec['pause_confirmed_monotonic']<resumed[0]['monotonic']
        cont=[e for e in commands if e['wire']['execute']=='cont']; assert len(cont)==1 and cont[0]['wire']['id'] in returns
        physical=[]
        for name,address,size in [('selected-response.bin',key['response'],40),('control-501-send.bin',queue['physical'],16384),('control-503-receive.bin',diagnostic['queue_physical_addresses']['receive503'],16384)]:
            expected='pmemsave '+hex(address)+' '+str(size)+' "'+capture['manifest']['path'].rsplit('/',1)[0]+'/'+name+'"'
            matches=[e for e in commands if e['wire'].get('arguments',{}).get('command-line')==expected]
            assert len(matches)==1; item=matches[0]; reply=returns[item['wire']['id']]
            assert rec['pause_confirmed_monotonic']<=item['monotonic']<=reply['monotonic']<cont[0]['monotonic']
            physical.append(dict(artifact=name,address=address,size=size,command_id=item['wire']['id'],sent_monotonic=item['monotonic'],replied_monotonic=reply['monotonic']))
        captures.append(dict(phase=phase,sequence=ordinal,recovery=rec,physical_command_bindings=physical))
    u32=lambda b,o:int.from_bytes(b[o:o+4],'little',signed=True)
    u64=lambda b,o:int.from_bytes(b[o:o+8],'little')
    blocked,terminal,quiet=responses
    assert [len(x) for x in responses]==[40]*3 and (u64(blocked,8),u64(blocked,16))==(0,2)
    expected=bytearray(blocked);expected[4:8]=tid.to_bytes(4,'little',signed=True);expected[16:24]=(1).to_bytes(8,'little');expected[24:32]=(16).to_bytes(8,'little')
    assert terminal==quiet==bytes(expected)
    for phase,data in zip(['BlockedRead','Terminal','TerminalPlusFive'],responses):
        saved=diagnostic['response_comparison']['raw'][phase]
        assert base64.b64decode(saved['base64'],validate=True)==data and saved['sha256']==sha(data) and saved['size']==40
    assert diagnostic['response_comparison']['accepted_return_physically_observed'] is False
    receive=take(GUEST/'capture-uart-1-PRE_INPUT/control-503-receive.bin')
    assert len(receive)==16384
    read,pub,res=(u64(receive,o) for o in (16,24,32))
    assert read<=pub<=res<(1<<64)-1 and res-read<=126
    matches=[]
    for sequence in range(max(0,res-127),read):
        offset=64+(sequence%127)*128;packet=receive[offset:offset+128]
        fields=dict(cpu=u32(packet,24),pid=u32(packet,32),requester=u32(packet,48),target=u32(packet,52),number=u64(packet,64),arguments=[u64(packet,o) for o in range(72,120,8)],response=u64(packet,120))
        if u32(packet,8)==4 and u64(packet,56)==1 and fields==request: matches.append((sequence,offset,packet))
    assert len(matches)==1
    sequence,offset,packet=matches[0];reported=diagnostic['request_ring_binding']['match']
    assert (sequence,sequence%127,offset)==(reported['sequence'],reported['slot'],reported['offset'])
    assert base64.b64decode(reported['packet']['base64'],validate=True)==packet
    intervals=[]
    for index,(first,last) in enumerate(zip(sends,sends[1:])):
        assert len(first)==len(last)==16384
        for ring in (first,last):
            assert (u32(ring,0),int.from_bytes(ring[4:6],'little'),int.from_bytes(ring[6:8],'little'),u32(ring,8),u64(ring,40))==(1,501,128,127,16256)
            assert u64(ring,16)<=u64(ring,24)<=u64(ring,32)<(1<<64)-1 and u64(ring,32)-u64(ring,16)<=126
        assert first[:16]+first[40:64]==last[:16]+last[40:64]
        assert all(u64(last,o)>=u64(first,o) for o in (16,24,32))
        start,end=u64(first,24),u64(last,24);assert max(0,u64(last,32)-127)<=start
        for sequence in range(start,end):
            offset=64+(sequence%127)*128
            assert (u32(last,offset+8),u32(last,offset+24))!=(0x14,key['requester'])
        reported=diagnostic['wake_publication_comparisons'][index]
        assert (reported['checked_publication_begin'],reported['checked_publication_end'],reported['new_matching_wakes'])==(start,end,0)
        intervals.append(dict(begin=start,end=end,matching_wakes=0))
    omit={'line','raw_sha256','sequence','version','family'}
    projected=[[{k:v for k,v in row.items() if k not in omit} for row in snapshot['records'] if row['kind'] not in ('BEGIN','END','COUNTERS')] for snapshot in snapshots[2:]]
    assert [len(x) for x in projected]==diagnostic['terminal_inventory_sizes']==[31,31]
    differences=[dict(index=i,terminal=a,plus_five=b) for i,(a,b) in enumerate(zip(*projected)) if a!=b]
    assert differences==diagnostic['terminal_inventory_differences'] and len(differences)==1
    difference=differences[0];assert difference['terminal']['kind']==difference['plus_five']['kind']=='APP'
    a=difference['terminal']['row'].copy();b=difference['plus_five']['row'].copy();assert a.pop('closed') is False and b.pop('closed') is True and a==b
    controller=read_json(GUEST/'guest-artifacts/files/mckernel/report.json')
    assert controller['raw_wait_status']==0 and controller['launcher_reaped'] and not controller['launcher_kill_sent'] and controller['host_ack_count']==3
    for side,keyname in [('rx','rx_sha256'),('tx','tx_sha256')]: assert sha(take(GUEST/'uart'/f'{side}.bin'))==original['control'][keyname]
    ack_lines=take(GUEST/'uart/tx.bin').decode().splitlines()
    assert len(ack_lines)==3
    for item,line in zip(original['phase_captures'],ack_lines):
        req=item['request'];expected=f"STF1 ACK {req['nonce']} {req['sequence']} {req['phase']} {req['mode']} {req['tgid']} {req['tid']} {req['start_ticks']} {item['manifest']['sha256']} CONTINUED"
        assert line==expected
    result.update(status='MATCH_RETAINED_PHYSICAL_DIAGNOSTIC_ORIGINAL_GUEST_FAIL',original_guest_status='FAIL',original_failure='terminal inventories changed',selected=key,linux_worker_tid=tid,ret_elapsed_ns=ret['elapsed_ns'],ret_errno=-71,response_bytes_match=True,response_changes_only=[[4,8],[16,24],[24,32]],accepted_return_physical_capture_verified=False,physical_full_ring_verified=False,consumed_request_match=dict(sequence=matches[0][0],slot=matches[0][0]%127,offset=matches[0][1],sha256=sha(matches[0][2])),outbound_publication_intervals=intervals,phase_captures=captures,terminal_inventory_rows=31,unchanged_terminal_inventory_rows=30,terminal_inventory_differences=differences,terminal_plus_five_interval_ns=begins['TerminalPlusFive']-ends[3],controller_launcher_raw_wait=0,scope_limits=['Frozen subject parser/helper source inspected and bound; not imported or rerun. Independent stdlib arithmetic checked retained bytes and QMP/UART records only.','No new guest, physical memory read, compiler execution or broad native source/ELF requalification.','Original full-contract failure and all false acceptance flags remain unchanged.'],reviewed_inputs=rows)
except BaseException as error:
    result.update(status='REVIEW_FAILED',error_type=type(error).__name__,error=str(error),reviewed_inputs=rows)
    raise
finally:
    (ROOT/'review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status=result['status'],root=str(ROOT),inputs=len(rows))))
