from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-irq-images-retained-20260907-1')
out.mkdir()
record = dict(created_utc=datetime.now(timezone.utc).isoformat(), production_gate_credit=False,
              mckernel_boot_proven=False, artifacts=[],
              passed=['exact pinned C/Rust IRQ producer equivalence and native concurrency',
                      'invalid ABI and native-C-fallback CMake rejection',
                      'complete C fallback, legacy Rust and native-ABI Rust McKernel image builds',
                      'ELF64 x86 image and linked Rust text attribution checks'],
              open=['full historical equivalence prerequisites unavailable; failed replay retained',
                    'new native image loader/startup-table guest replay and full suite pending',
                    'real McKernel CPU startup, cross-kernel IRQ/IKC, applications and full Rust/assembly completion'])
def add(path, name):
    data = path.read_bytes()
    target = out / name
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream: stream.write(data)
    assert gzip.decompress(target.read_bytes()) == data
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name, source=str(path),
        size=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
        unpacked_size=len(data), unpacked_sha256=hashlib.sha256(data).hexdigest()))
for attempt in range(1, 10):
    path = Path('/work/mckernel-native-irq-images-20260907-' + str(attempt))
    capture = json.loads((path / 'record.json').read_text())
    target = out / ('native-irq-images-20260907-attempt-' + str(attempt) + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        for child in sorted(path.iterdir()):
            if child.name != 'source': archive.add(child, arcname=child.name)
        for item in capture.get('source_overlays', []):
            source = Path(item['path'])
            archive.add(source, arcname='source-overlays/' + str(source.relative_to(path / 'source')))
        if 'equivalence_scratch_adaptation' in capture:
            archive.add(path / 'source/kernel/rust/tests/run_equivalence.sh', arcname='equivalence-adapted.sh')
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
        size=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest(), source=str(path)))
    add(path / 'record.json', 'native-irq-images-20260907-attempt-' + str(attempt) + '-record.json.gz')
passed = Path('/work/mckernel-native-irq-images-20260907-9')
built = json.loads((passed / 'record.json').read_text())
assert built['status'] == 'PASS'
record['source_parent'] = built['source_parent']
record['production_inputs'] = built['production_inputs']
record['source_overlays'] = built['source_overlays']
record['images'] = built['images']
for item in built['production_inputs']:
    path = Path(item['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
for variant in built['images']:
    for item in variant['outputs']:
        path = Path(item['path'])
        assert path.stat().st_size == item['size'] and hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
    if variant['kind'] != 'fallback':
        add(passed / (variant['kind'] + '-linked-ownership.json'), 'native-irq-images-20260907-' + variant['kind'] + '-linked-ownership.json.gz')
for name in ['build-mckernel-native-irq-images.py', 'retain-native-irq-images.py']:
    add(Path('/work') / name, 'native-irq-images-20260907-' + name + '.gz')
(out / 'native-irq-images-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained', len(record['artifacts']), 'artifacts in', out, flush=True)
