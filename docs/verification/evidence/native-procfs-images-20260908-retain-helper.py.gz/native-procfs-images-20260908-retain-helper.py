"""Retain rebuilt procfs guest images, current native modules and real boot regressions."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-procfs-images-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-procfs-images-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Four actual guest image profiles with procfs lifetime fixes; current three native modules and both real Linux/McKernel ABI regressions. Actual procfs request/release service, scheduled cleanup, START and application execution remain pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-procfs-lifetime-checkpoint-20260908.json','native-application-mailbox-checkpoint-20260908.json','native-procfs-objects-checkpoint-20260908.json']:
        path=repo/'docs/verification'/name;assert json.loads(path.read_text())['status']=='PASS'
        row=identity(path);row['path']=str(path.relative_to(repo));record['references'].append(row)
    captures=[('mckernel-native-procfs-images-20260908-1','PASS'),('native-application-mailbox-module-20260908-4','FAIL'),('native-application-mailbox-module-20260908-5','PASS'),('native-procfs-lifetime-20260908-6','PASS'),('native-procfs-image-guest-20260908-x86_64-1','PASS'),('native-procfs-image-regression-20260908-i386-1','PASS')]
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,name
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[])+state.get('production_inputs',[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        for item in state.get('images',[]):
            for row in item['outputs']:verify(row)
        for capture in state.get('captures',[]):
            for row in capture['artifacts']:verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,complete_capture_retained=True,archive_exclusions={}))
    images=work/'mckernel-native-procfs-images-20260908-1';state=json.loads((images/'record.json').read_text())
    assert [row['kind'] for row in state['images']]==['fallback','legacy-rust','native-rust','native-sysfs-verify']
    record['images']=state['images'];record['guest_compiler']=state['compiler'];record['historical_equivalence']=state['historical_equivalence']
    for row in state['production_inputs']:
        relative=Path(row['path']).relative_to(images/'source')
        record['guest_compiler_bindings'].append(binding(repo/relative,images/'source'/relative))
    restored=[]
    listing=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rlz','--full-tree',state['source_parent'],'docs/verification/evidence'])
    for raw in listing.split(b'\0'):
        if not raw:continue
        metadata,path=raw.split(b'\t',1);mode,kind,blob,size=metadata.decode().split();assert kind=='blob'
        restored.append(dict(path=os.fsdecode(path),mode=mode,git_blob=blob,size=int(size),source_commit=state['source_parent']))
    assert restored==json.loads((images/'historical-evidence-restoration.json').read_text())
    assert not (images/'source/docs/verification/evidence').exists()
    record['compile_only_evidence_omission']=dict(**state['historical_evidence_omitted'],source_commit=state['source_parent'],verified_against_exact_git_tree=True,retained_map=identity(images/'historical-evidence-restoration.json'))
    for row in state['images']:
        directory=images/row['kind'];commands=json.loads((directory/'compile_commands.json').read_text())
        c_selected=any(item['file'].endswith('/kernel/procfs.c') for item in commands)
        assert c_selected==(row['kind']=='fallback')
        if not c_selected:assert 'kernel/rust/procfs.rs' in (directory/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
    compiled=work/'native-application-mailbox-module-20260908-5';replays=[];changed=[]
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        previous=work/'native-application-mailbox-module-20260908-3/staged-source'/relative
        assert previous.is_file()
        if previous.read_bytes()!=saved.read_bytes():changed.append(str(relative))
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout);assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='Exact pinned rustfmt replay; original and formatted files retained',compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(row);replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'} and len(record['native_compiler_bindings'])==51
    assert changed==['application_rpc.rs'],changed
    record['native_changed_sources_since_prior_guest']=changed
    record['current_native_module']=str(compiled)
    artifact(out/'format-replay','native-procfs-images-20260908-format-replay.tar.gz',True)
    protocol=work/'native-procfs-lifetime-20260908-6';state=json.loads((protocol/'record.json').read_text())
    record['procfs_fixture_bindings']=[]
    for row in state['inputs']:
        relative=Path(row['path']).relative_to(protocol/'original-inputs')
        record['procfs_fixture_bindings'].append(binding(repo/relative,protocol/'source'/relative))
    assert len(record['procfs_fixture_bindings'])==18
    for profile in ['legacy','native']:assert 'test result: ok. 9 passed; 0 failed;' in (protocol/(profile+'-rust-tests.log')).read_text()
    assert (compiled/'staged-source/application_rpc.rs').read_bytes()==(protocol/'source/host-kernel/native-rust/application_rpc.rs').read_bytes()
    record['guest_probe_bindings']=[];record['guest_module_bindings']=[];record['guest_image_bindings']=[];record['guest_results']=[]
    for directory in [work/'native-procfs-image-guest-20260908-x86_64-1',work/'native-procfs-image-regression-20260908-i386-1']:
        state=json.loads((directory/'record.json').read_text())
        assert state['status']=='PASS' and state['qemu_exit_code']==0 and state['terminal_vm_state']==dict(running=False,status='shutdown')
        assert not state['applications_tested'] and state['physical_status']==3 and state['full_ready_observed']
        for saved in sorted((directory/'probe-source').iterdir()):
            current=repo/('executer/include/uprotocol.h' if saved.name=='native-image-c-abi.h' else 'scripts/tests/fixtures/'+saved.name)
            record['guest_probe_bindings'].append(binding(current,saved))
        for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
            left,right=identity(compiled/name),identity(directory/'root/modules'/name)
            assert (left['size'],left['sha256'])==(right['size'],right['sha256'])
            record['guest_module_bindings'].append(dict(compiled=left,guest=right))
        left,right=identity(images/'native-rust/kernel/mckernel.img'),identity(directory/'root/images/mckernel.img')
        assert (left['size'],left['sha256'])==(right['size'],right['sha256'])
        record['guest_image_bindings'].append(dict(compiled=left,guest=right))
        result={key:state[key] for key in ['architecture','profile','cpuset','container_memory_mib','guest_cpus','numa_nodes','mcctrl_service','mcctrl_process','mcctrl_executable','observed_callback_exchanges','terminal_vm_state']}
        result.update(capture=str(directory),physical_status_3_captures=len(state['captures']))
        for capture in state['captures']:assert capture['validated'] and capture['status']==3
        for key in ['mcctrl_image','native_waiter']:
            if key in state:result[key]=state[key]
        record['guest_results'].append(result)
    assert len(record['guest_probe_bindings'])==17 and len(record['guest_module_bindings'])==6
    assert record['guest_results'][0]['native_waiter']['checks']==396 and record['guest_results'][0]['mcctrl_image']['checks']==47
    record['current_guest_totals']=dict(physical_status_3_captures=sum(row['physical_status_3_captures'] for row in record['guest_results']),process_checks=sum(row['mcctrl_process']['checks'] for row in record['guest_results']),credential_checks=sum(row['mcctrl_executable']['credential_checks'] for row in record['guest_results']),executable_checks=sum(row['mcctrl_executable']['file_checks'] for row in record['guest_results']),topology_queries=sum(row['mcctrl_service']['topology_queries'] for row in record['guest_results']),continuing_sysfs_callbacks=sum(row['observed_callback_exchanges'] for row in record['guest_results']))
    assert record['current_guest_totals']==dict(physical_status_3_captures=7,process_checks=306,credential_checks=518,executable_checks=1116,topology_queries=2112,continuing_sysfs_callbacks=260)
    for name in ['build-mckernel-native-procfs-images.py','build-native-application-mailbox.py','test-native-procfs-lifetime.py','run-native-procfs-image-guest.py','run-native-procfs-image-compat.py']:
        artifact(work/name,'native-procfs-images-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-procfs-images-20260908-retain-helper.py.gz')
    record.update(status='PASS',complete_captures=len(captures),artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
