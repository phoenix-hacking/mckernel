from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, base = Path('/workspace'), Path('/work')
out = base / ('native-sysfs-tree-retained-20260907-' + sys.argv[1]); out.mkdir()
final = base / 'native-sysfs-tree-module-20260907-2'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[], production_gate_credit=False,
    declared_stage=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    applications_tested=False)

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): checksum.update(chunk)
    return checksum.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def checked(row):
    assert identity(Path(row['path'])) == row, row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target)
    row.update(path='docs/verification/evidence/' + name, source=str(source),
        unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

def bind(current, compiled):
    relative = current.relative_to(repo)
    row = identity(compiled); row['path'] = str(relative)
    row.update(source_sha256=digest(current), source_size=current.stat().st_size,
               binding='identical', compiler_capture=str(compiled))
    if current.read_bytes() != compiled.read_bytes():
        assert current.suffix == '.rs', (str(current), str(compiled))
        original = final / 'original-inputs' / current.relative_to(repo / 'host-kernel/native-rust')
        assert current.read_bytes() == original.read_bytes(), ('original-source-binding', str(current))
        saved = out / 'source-bindings' / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(current, saved.with_suffix('.original.rs'))
        shutil.copyfile(current, saved)
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(saved)]
        with saved.with_suffix('.rustfmt.log').open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (command, result.returncode)
        assert saved.read_bytes() == compiled.read_bytes(), ('formatted-source-binding', str(current))
        row.update(binding='exact-rustfmt-replay', command=command, original_capture=str(original))
    if row not in record['compiler_inputs']: record['compiler_inputs'].append(row)

try:
    shutil.copyfile(__file__, out / 'helper.py')
    captures = [('module-1', 'native-sysfs-tree-module-20260907-1', 'FAIL'),
                ('module-2', 'native-sysfs-tree-module-20260907-2', 'PASS'),
                ('tree', 'native-sysfs-tree-guest-20260907-1', 'PASS'),
                ('prepare', 'native-sysfs-tree-os-guest-20260907-prepare-1', 'PASS'),
                ('start-x86_64', 'native-sysfs-tree-os-guest-20260907-start-x86_64-1', 'PASS'),
                ('start-i386', 'native-sysfs-tree-os-guest-20260907-start-i386-1', 'PASS')]
    guests = {}
    for category, name, expected in captures:
        source = base / name
        captured = json.loads((source / 'record.json').read_text())
        assert captured['status'] == expected, (name, captured['status'])
        for field in ('inputs', 'outputs', 'fixture_inputs', 'compiler_inputs'):
            for row in captured.get(field, []): checked(row)
        for capture in captured.get('captures', []):
            for row in capture['artifacts']: checked(row)
        archive = out / (name + '.tar.gz')
        with tarfile.open(archive, 'w:gz') as tar:
            tar.add(source, arcname=name)
        assert archive.stat().st_size < 95 << 20, name
        row = identity(archive); row.update(path='docs/verification/evidence/' + archive.name, source=str(source))
        record['artifacts'].append(row)
        retain_gzip(source / 'record.json', name + '-record.json.gz')
        if (source / 'serial.log').exists():
            retain_gzip(source / 'serial.log', name + '-serial.log.gz')
            guests[category] = captured
            serial = (source / 'serial.log').read_text()
            for bad in ['Call Trace:', 'BUG:', 'Oops:', 'WARNING:', 'Kernel panic', ' FAIL line=', 'rcu_preempt detected stalls']:
                assert bad not in serial, (name, bad)
        record['captures'].append(dict(directory=name, status=expected,
            source_parent=captured['source_parent'], started_utc=captured['started_utc'],
            finished_utc=captured['finished_utc'], qemu_exit_code=captured.get('qemu_exit_code')))
        print('Retained', name, expected, flush=True)
    compiled_record = json.loads((final / 'record.json').read_text())
    for row in compiled_record['overlay']:
        relative = row['path'].split('/drivers/misc/mckernel/', 1)[1]
        saved = final / 'staged-source' / relative
        assert digest(saved) == row['sha256'] and saved.stat().st_size == row['size'], relative
    for saved in sorted((final / 'staged-source').rglob('*')):
        if saved.is_file() and saved.suffix in ('.rs', '.S'):
            bind(repo / 'host-kernel/native-rust' / saved.relative_to(final / 'staged-source'), saved)
    for row in compiled_record['fixture_inputs']:
        bind(repo / 'scripts/tests/fixtures' / Path(row['path']).name, Path(row['path']))
    for name in ['mckernel_sysfs_tree_verify.rs', 'native-sysfs-tree.c',
                 'native-sysfs-tree-reference.c', 'native-sysfs-tree-cases.txt']:
        bind(repo / 'scripts/tests/fixtures' / name, final / 'tree/source/scripts/tests/fixtures' / name)
    for category, name, _ in captures[3:]:
        for saved in sorted((base / name / 'probe-source').iterdir()):
            bind(repo / 'scripts/tests/fixtures' / saved.name, saved)
    bind(repo / 'executer/kernel/mcctrl/sysfs.c', final / 'legacy-sysfs.c')
    legacy = (final / 'legacy-sysfs.c').read_bytes()
    extraction = json.loads((final / 'legacy-extraction.json').read_text())
    assert len(extraction) == 15 and [row['name'] for row in extraction] == compiled_record['tree_legacy_bodies']
    bodies = []
    for row in extraction:
        body = legacy[row['start_byte']:row['end_byte']]
        assert hashlib.sha256(body).hexdigest() == row['sha256'], row
        bodies.append(body)
    assert (final / 'tree/source/scripts/tests/fixtures/native-sysfs-tree-reference-bodies.h').read_bytes() == b'/* SPDX-License-Identifier: GPL-2.0-only */\n' + b'\n\n'.join(bodies) + b'\n'
    assert compiled_record['tree_reference_cases'] == 60
    tree = guests['tree']
    assert tree['module_cycles'] == 2 and tree['reference_cases_per_cycle'] == 60
    assert tree['deep_directories_per_cycle'] == 509 and tree['active_callback_drains'] == 2
    assert guests['prepare']['sysfs_namespace_checks'] == 404 and len(guests['prepare']['captures']) == 4
    for mode in ('start-x86_64', 'start-i386'):
        guest = guests[mode]
        assert guest['sysfs_namespace_checks'] == 2
        assert guest['device_borrow_checks'] == 30 and guest['device_borrow_callbacks'] == 10
        capture = guest['captures'][0]
        assert capture['status'] == 2 and capture['linux_vdso']['service_completed']
        assert capture['linux_vdso']['next_request']['message'] == 0x40
        assert capture['linux_vdso']['next_request']['busy'] == 1
    binding_archive = out / 'native-sysfs-tree-source-bindings-20260907.tar.gz'
    with tarfile.open(binding_archive, 'w:gz') as tar:
        tar.add(out / 'source-bindings', arcname='source-bindings')
    row = identity(binding_archive); row['path'] = 'docs/verification/evidence/' + binding_archive.name
    record['artifacts'].append(row)
    for name in ['build-native-sysfs-tree.py', 'run-native-sysfs-tree-guest.py',
                 'run-native-sysfs-tree-os-guest.py', 'retain-native-sysfs-tree.py']:
        retain_gzip(base / name, 'native-sysfs-tree-20260907-' + name + '.gz')
    for name in ['native-sysfs-os-checkpoint-20260907.json', 'native-sysfs-objects-checkpoint-20260907.json',
                 'native-vdso-service-checkpoint-20260907.json']:
        row = identity(repo / 'docs/verification' / name)
        row['path'] = str(Path(row['path']).relative_to(repo)); record['references'].append(row)
    for row in record['artifacts']:
        checksum = hashlib.sha256(); size = 0
        with gzip.open(out / Path(row['path']).name, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                checksum.update(chunk); size += len(chunk)
        if 'unpacked_size' in row:
            assert size == row['unpacked_size'] and checksum.hexdigest() == row['unpacked_sha256'], row
    subprocess.run(['git', '-C', str(repo), 'diff', '--check'], check=True)
    record.update(status='PASS', tree_module_cycles=2, tree_reference_cases_per_cycle=60,
        deep_directories_per_cycle=509, active_callback_drains=2,
        drain_milliseconds=tree['drain_milliseconds'], legacy_bodies=15,
        sysfs_namespace_checks=408, device_borrow_checks=60, device_borrow_callbacks=20,
        independent_preparation_captures=4,
        passed=[
            'The three native modules, exact boot/device layout witnesses, device borrowing fixture and actual tree fixture build with no SIMD/FPU register use in module disassembly',
            'The real Linux tree matches all 60 operations from 15 unchanged legacy C bodies across two complete module lifetimes; paths, errno results and node counts match',
            'Actual Linux properties cover protected roots, whole-path validation without prefix mutation, directory-only links, stale/foreign/nonmember handles, filename reuse and 509-level iterative teardown',
            'Real sysfs file modes, reads/writes and symlink resolution pass; two module removals observe an active callback, wait for it, and leave no namespace behind',
            'Both OS preparation ABIs across two native module lifetimes retain 404 namespace checks, original allocation failures, four physical captures and full unstarted restoration',
            'Both actual McKernel startup ABIs retain the tree root and vDSO completion at architectural status 2, with 60 borrowing checks and SYSFS_REQ_SETUP still busy',
            'Full capture hashes and gzip streams verify; current sources bind to exact compiler inputs or explicit pinned rustfmt replay; the first fixture compiler failure is retained'],
        limitations=[
            'The native OS tree still contains only its protected roots: topology/setup attributes, shared-buffer ownership and the actual SYSFS_REQ_SETUP exchange remain required',
            'Tree metadata mutation requires exclusive mutable access and callbacks must not acquire its removal lock; the fixture does not prove a continuing remote request dispatcher',
            'Module-wide handles do not wrap or encode pointers; validity still depends on live membership in the current tree and the OS generation boundary',
            'Not every new tree allocation-failure point has been injected. Protected-root and malformed-path prevalidation deliberately reject before mutation, beyond legacy partial-failure behavior',
            'Full ready status, application launch/tests, native shutdown, complete McKernel and support Rust/assembly ownership, declared integration, a current full suite and independent production acceptance remain open'])
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'native-sysfs-tree-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], 'retained', len(record['artifacts']), 'native tree artifacts', flush=True)
