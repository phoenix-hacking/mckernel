mod tests {
    fn batch_range(start: u64, length: u64, node: u32) -> MemoryExtent {
        MemoryExtent::new(start, length, node, None).unwrap()
    }

    #[test]
    fn memory_batch_insert_merges_old_and_new_ranges_at_one_commit() {
        let mut memory = MemoryMap::<4>::new();
        let mut staging = [None; 4];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x3000, 0x1000, 0, &mut workspace)
            .unwrap();
        let ranges = [
            batch_range(0x1000, 0x2000, 0),
            batch_range(0x4000, 0x1000, 0),
            batch_range(0x5000, 0x1000, 1),
        ];
        let before = memory.extents;
        {
            let transaction = memory
                .prepare_insert_free_batch(&ranges, &mut workspace)
                .unwrap();
            assert_eq!(transaction.live_len(), 1);
            assert_eq!(transaction.candidate_len(), 2);
            assert_eq!(
                transaction.candidate_extent(0),
                Some(batch_range(0x1000, 0x4000, 0))
            );
        }
        assert_eq!(memory.extents, before);
        let mut transaction = memory
            .prepare_insert_free_batch(&ranges, &mut workspace)
            .unwrap();
        transaction.begin_external_effects().unwrap();
        transaction.commit().unwrap();
        assert_eq!(memory.len(), 2);
        assert_eq!(memory.free_bytes().unwrap(), 0x5000);
        assert_eq!(memory.extent(1), Some(batch_range(0x5000, 0x1000, 1)));
        assert_eq!(workspace.len(), 0);
    }

    #[test]
    fn memory_batch_insert_rejects_overlap_order_and_owned_input_without_change() {
        let mut memory = MemoryMap::<4>::new();
        let mut staging = [None; 4];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x5000, 0x2000, 0, &mut workspace)
            .unwrap();
        let before = memory.extents;
        let cases = [
            [
                batch_range(0x1000, 0x2000, 0),
                batch_range(0x2000, 0x1000, 1),
            ],
            [
                batch_range(0x3000, 0x1000, 0),
                batch_range(0x1000, 0x1000, 0),
            ],
            [
                batch_range(0x1000, 0x1000, 0),
                batch_range(0x6000, 0x2000, 0),
            ],
        ];
        for ranges in cases {
            assert_eq!(
                memory
                    .prepare_insert_free_batch(&ranges, &mut workspace)
                    .err(),
                Some(ResourceError::Overlap)
            );
            assert_eq!(memory.extents, before);
            memory.validate().unwrap();
        }
        let owned = MemoryExtent::new(0x1000, 0x1000, 0, Some(token(1, 1))).unwrap();
        assert_eq!(
            memory
                .prepare_insert_free_batch(&[owned], &mut workspace)
                .err(),
            Some(ResourceError::Ownership)
        );
        assert_eq!(memory.extents, before);
    }

    #[test]
    fn memory_batch_capacity_failure_leaves_live_state_and_reusable_workspace() {
        let mut memory = MemoryMap::<2>::new();
        let mut staging = [None; 2];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x3000, 0x1000, 0, &mut workspace)
            .unwrap();
        let before = memory.extents;
        let fragmented = [
            batch_range(0x1000, 0x1000, 0),
            batch_range(0x5000, 0x1000, 0),
        ];
        assert_eq!(
            memory
                .prepare_insert_free_batch(&fragmented, &mut workspace)
                .err(),
            Some(ResourceError::Capacity)
        );
        assert_eq!(memory.extents, before);
        let joined = [
            batch_range(0x1000, 0x1000, 0),
            batch_range(0x2000, 0x1000, 0),
            batch_range(0x4000, 0x1000, 0),
        ];
        let mut transaction = memory
            .prepare_insert_free_batch(&joined, &mut workspace)
            .unwrap();
        transaction.begin_external_effects().unwrap();
        transaction.commit().unwrap();
        assert_eq!(memory.len(), 1);
        assert_eq!(memory.free_bytes().unwrap(), 0x4000);
    }

    #[test]
    fn memory_batch_remove_splits_free_ranges_and_preserves_os_owned_memory() {
        let mut memory = MemoryMap::<8>::new();
        let mut staging = [None; 8];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x1000, 0x9000, 0, &mut workspace)
            .unwrap();
        memory
            .insert_free(0xa000, 0x4000, 1, &mut workspace)
            .unwrap();
        let owner = token(3, 9);
        memory
            .assign(owner, 0x5000, 0x1000, &mut workspace)
            .unwrap();
        let before = memory.extents;
        let ranges = [
            batch_range(0x2000, 0x2000, 0),
            batch_range(0x6000, 0x4000, 0),
            batch_range(0xb000, 0x1000, 1),
        ];
        {
            let transaction = memory
                .prepare_remove_free_batch(&ranges, &mut workspace)
                .unwrap();
            assert_eq!(transaction.live_len(), 4);
            assert_eq!(transaction.candidate_len(), 5);
        }
        assert_eq!(memory.extents, before);
        let mut transaction = memory
            .prepare_remove_free_batch(&ranges, &mut workspace)
            .unwrap();
        transaction.begin_external_effects().unwrap();
        transaction.commit().unwrap();
        assert_eq!(memory.bytes_owned_by(owner).unwrap(), 0x1000);
        assert_eq!(memory.free_bytes().unwrap(), 0x5000);
        assert_eq!(memory.len(), 5);
        memory.validate().unwrap();
    }

    #[test]
    fn memory_batch_remove_rejects_late_invalid_ranges_without_partial_release() {
        let mut memory = MemoryMap::<8>::new();
        let mut staging = [None; 8];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x1000, 0x4000, 0, &mut workspace)
            .unwrap();
        memory
            .insert_free(0x6000, 0x4000, 1, &mut workspace)
            .unwrap();
        memory
            .assign(token(1, 2), 0x8000, 0x1000, &mut workspace)
            .unwrap();
        let before = memory.extents;
        let first = batch_range(0x1000, 0x1000, 0);
        for (last, expected) in [
            (
                batch_range(0x4000, 0x3000, 0),
                ResourceError::RangeUnavailable,
            ),
            (
                batch_range(0x5000, 0x1000, 0),
                ResourceError::RangeUnavailable,
            ),
            (
                batch_range(0x6000, 0x1000, 0),
                ResourceError::RangeUnavailable,
            ),
            (batch_range(0x8000, 0x1000, 1), ResourceError::Ownership),
            (first, ResourceError::Overlap),
        ] {
            assert_eq!(
                memory
                    .prepare_remove_free_batch(&[first, last], &mut workspace)
                    .err(),
                Some(expected)
            );
            assert_eq!(memory.extents, before);
            memory.validate().unwrap();
        }
    }

    #[test]
    fn memory_batch_remove_capacity_and_adjacent_ranges_are_atomic() {
        let mut memory = MemoryMap::<2>::new();
        let mut staging = [None; 2];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        memory
            .insert_free(0x1000, 0x7000, 0, &mut workspace)
            .unwrap();
        let before = memory.extents;
        let splits = [
            batch_range(0x2000, 0x1000, 0),
            batch_range(0x5000, 0x1000, 0),
        ];
        assert_eq!(
            memory
                .prepare_remove_free_batch(&splits, &mut workspace)
                .err(),
            Some(ResourceError::Capacity)
        );
        assert_eq!(memory.extents, before);
        let adjacent = [
            batch_range(0x2000, 0x1000, 0),
            batch_range(0x3000, 0x1000, 0),
        ];
        let mut transaction = memory
            .prepare_remove_free_batch(&adjacent, &mut workspace)
            .unwrap();
        transaction.begin_external_effects().unwrap();
        transaction.commit().unwrap();
        assert_eq!(memory.len(), 2);
        assert_eq!(memory.free_bytes().unwrap(), 0x5000);
    }

    #[test]
    fn memory_batches_retain_compensation_poison_and_empty_request_rules() {
        for remove in [false, true] {
            for compensate in [false, true] {
                let mut memory = MemoryMap::<4>::new();
                let mut staging = [None; 4];
                let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
                memory
                    .insert_free(0x1000, 0x4000, 0, &mut workspace)
                    .unwrap();
                let before = memory.extents;
                let ranges = [batch_range(if remove { 0x2000 } else { 0x6000 }, 0x1000, 0)];
                let mut transaction = if remove {
                    memory
                        .prepare_remove_free_batch(&ranges, &mut workspace)
                        .unwrap()
                } else {
                    memory
                        .prepare_insert_free_batch(&ranges, &mut workspace)
                        .unwrap()
                };
                transaction.begin_external_effects().unwrap();
                if compensate {
                    transaction.compensated_rollback().unwrap();
                } else {
                    drop(transaction);
                }
                assert_eq!(memory.extents, before);
                assert_eq!(memory.is_poisoned(), !compensate);
            }
        }
        let mut memory = MemoryMap::<1>::new();
        let mut staging = [None; 1];
        let mut workspace = MemoryWorkspace::new(&mut staging).unwrap();
        let transaction = memory
            .prepare_insert_free_batch(&[], &mut workspace)
            .unwrap();
        assert_eq!(
            transaction.commit(),
            Err(ResourceError::ExternalEffectsNotStarted)
        );
        assert!(!memory.is_poisoned());
        let mut transaction = memory
            .prepare_remove_free_batch(&[], &mut workspace)
            .unwrap();
        transaction.begin_external_effects().unwrap();
        transaction.commit().unwrap();
        assert!(memory.is_empty());
    }
}
