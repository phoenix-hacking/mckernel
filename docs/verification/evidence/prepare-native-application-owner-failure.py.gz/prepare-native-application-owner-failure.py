from pathlib import Path
p=Path('/home/holden/mckernel-work/scratch')
s=(p/'run-native-application-signals.py').read_text()
s=s.replace("out = Path('/work/native-application-signals-' + case + '-guest-20260909-' + attempt)","out = Path('/work/native-application-owner-failure-guest-20260909-' + attempt)")
needle="    shutil.copyfile(__file__, out / 'helper.py')"
s=s.replace(needle,needle+"\n    shutil.copyfile('/work/run-native-application-signals.py', out/'normal-runner-original.py')\n    record['runner_adaptation']='Original normal core/HELLO assertions apply to the exact pre-failure console; the new failure and post-failure windows have separate full assertions. Original runner retained.'")
needle="    probe = out / 'probe-source'"
extra="""    failure=Path('/work/native-application-failure-build-20260909-1')
    failure_record=json.loads((failure/'record.json').read_text());assert failure_record['status']=='PASS'
    for row in failure_record['outputs']:assert identity(Path(row['path']))==row
    record['inputs'].append(identity(failure/'record.json'))
    for name in ['native-application-failure','native-application-failure-control']:
        shutil.copyfile(failure/name,root/'bin'/name);(root/'bin'/name).chmod(0o755)
        record['inputs']+=[identity(failure/name),identity(failure/(name+'.c'))]
    for row in failure_record['runtime_libraries']:
        source=Path(row['captured']['path']);assert identity(source)==row['captured']
        target=root/row['original']['path'].lstrip('/')
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==source.read_bytes(),str(target)
        else:shutil.copyfile(source,target)
        record['inputs'].append(identity(source))
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
a=s.index('for iteration in {1..8}; do');b=s.index("printf '<6>NATIVE_APPLICATION_REPEAT PASS",a)
loop=s[a:b].replace('for iteration in {1..8}; do','for iteration in {9..16}; do')
needle="printf '<6>NATIVE_APPLICATION_GUEST PASS application_exit=37"
idx=s.index(needle)
extra="/bin/native-application-failure-control --guest /bin/mcexec /bin/native-application-failure\nprocess_nodes=(/proc/mcos0/[0-9]*)\n[ \"${#process_nodes[@]}\" -eq 0 ]\n"+loop+"printf '<6>NATIVE_POSTFAILURE_REPEAT PASS applications=8 application_exit=37\\\\n' >/dev/kmsg\n"
s=s[:idx]+extra+s[idx:]
needle="            state = qmp('query-status')"
extra="""            if 'NATIVE_FAILURE_BLOCKED' in serial and not record.get('blocked_capture'):
                assert 'NATIVE_FAILURE_KILLED' not in serial, 'Missed live blocked-read capture'
                capture(serial,'blocked-read',validate=False)
                record['blocked_capture']=True
                save()
"""
assert s.count(needle)==1;s=s.replace(needle,extra+needle)
needle="                    console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]"
s=s.replace(needle,"                    full_console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]\n                    console=full_console.split('NATIVE_FAILURE_BEGIN guest=1',1)[0]")
needle="\n                else:\n                    marker = 'NATIVE_BUILDID_GUEST PASS"
extra=r'''
                    assert record['blocked_capture']
                    fault=full_console.split('NATIVE_FAILURE_BEGIN guest=1',1)[1]
                    blocked=re.findall(r'NATIVE_FAILURE_BLOCKED pid=(\d+) tid=(\d+) syscall=0 0x0 (0x[0-9a-f]+) 0x10\b',fault)
                    assert len(blocked)==1,blocked
                    dead_pid,dead_tid,read_buffer=blocked[0]
                    before_kill=fault.split('NATIVE_FAILURE_KILLED',1)[0]
                    assert re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',before_kill)==[dead_pid]
                    requests=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+dead_pid+r' worker=(\d+) delivery=(\d+) cpu=0 number=(\d+)',before_kill)
                    assert requests and requests[-1][2]=='0',requests
                    read_worker,read_serial,_=requests[-1]
                    assert 'NATIVE_FAILURE_KILLED pid='+dead_pid+' tid='+dead_tid+' signal=9' in fault
                    assert 'NATIVE_FAILURE_PROCESS_NODE_CLEAR pid='+dead_pid in fault
                    reuse=re.findall(r'NATIVE_FAILURE_REUSE pid='+dead_pid+r' tid='+dead_tid+r' forks=700 pid_reused=(\d+) tid_reused=(\d+)',fault)
                    assert len(reuse)==1 and all(int(n)>0 for n in reuse[0]),reuse
                    assert 'NATIVE_FAILURE_CONTROL PASS guest=1 pid='+dead_pid+' tid='+dead_tid in fault
                    cleanup=fault.split('NATIVE_FAILURE_REUSE',1)[0]
                    assert re.search(r'application retirement os=0 generation=1 pid='+dead_pid+r' token=\d+ errno=0\b',cleanup),cleanup[-12000:]
                    assert re.search(r'application_process=release os=0 generation=1 pid='+dead_pid+r' cleanup_errno=0\b',cleanup),cleanup[-12000:]
                    for operation in ['published','deleted']:
                        assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+dead_pid+r' tid='+dead_pid+r'\b',cleanup)
                    assert 'cleanup retained' not in full_console and 'reap_retained' not in full_console
                    quiet=cleanup.split('NATIVE_FAILURE_PROCESS_NODE_CLEAR',1)[1]
                    assert not re.search(r'application_syscall=returned os=0 generation=1 pid='+dead_pid+r'\b',quiet)
                    after=fault.split('NATIVE_FAILURE_CONTROL PASS',1)[1]
                    windows=re.findall(r'NATIVE_APPLICATION_MCEXEC begin iteration=(\d+)(.*?)NATIVE_APPLICATION_MCEXEC exit=37 iteration=\1\b',after,re.S)
                    assert [int(i) for i,_ in windows]==list(range(9,17)),windows
                    post=[]
                    for iteration,body in windows:
                        assert body.count('NATIVE_APPLICATION_HELLO')==1
                        assert 'NATIVE_APPLICATION_STDOUT iteration='+iteration+' bytes=25 line=NATIVE_APPLICATION_HELLO' in body
                        pids=re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',body);assert len(pids)==1
                        this_pid=pids[0]
                        delivered=re.findall(r'application_syscall=delivered os=0 generation=1 pid='+this_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',body)
                        returned=re.findall(r'application_syscall=returned os=0 generation=1 pid='+this_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',body)
                        writes=[row for row in delivered if row[3]=='1'];assert len(writes)==1
                        assert writes[0][:3]+('25',) in returned
                        assert any(row[3]=='231' for row in delivered)
                        for operation in ['published','deleted']:
                            assert re.search(r'application procfs '+operation+r' os=0 generation=1 pid='+this_pid+r' tid='+this_pid+r'\b',body)
                        assert re.search(r'application retirement os=0 generation=1 pid='+this_pid+r' token=\d+ errno=0\b',body)
                        assert re.search(r'application_process=release os=0 generation=1 pid='+this_pid+r' cleanup_errno=0\b',body)
                        for route in re.findall(route_pattern,body):
                            assert route[0]==this_pid and (route[1],route[2],route[4],'25') in returned
                        post.append(dict(iteration=int(iteration),pid=int(this_pid),delivered=delivered,returned=returned,exit_code=37,write_bytes=25,normal_retirement=True))
                    assert len({row['pid'] for row in post})==8
                    assert re.findall(r'NATIVE_APPLICATION_REGISTRATIONS_CLEAR iteration=(\d+)',after)==list(map(str,range(9,17)))
                    assert 'NATIVE_POSTFAILURE_REPEAT PASS applications=8 application_exit=37' in after
                    record['abnormal_owner']=dict(pid=int(dead_pid),blocked_tid=int(dead_tid),read_worker=int(read_worker),read_delivery=int(read_serial),read_buffer=read_buffer,read_bytes=16,actual_sigkill=9,pid_reused=int(reuse[0][0]),tid_reused=int(reuse[0][1]),reuse_forks=700,cleanup_errno=0,retirement_errno=0,post_failure_applications=post,no_stale_return_in_quiet_window=True)
'''
assert s.count(needle)==1;s=s.replace(needle,'\n'+extra+needle)
s=s.replace("record.update(launcher_reported_exit=37,", "record.update(launcher_reported_exit=37,abnormal_owner_verified=True,")
(p/'run-native-application-owner-failure.py').write_text(s)
print('Prepared complete original baseline, live blocked-read capture, owned-child kill, PID reuse and eight post-failure launches')
