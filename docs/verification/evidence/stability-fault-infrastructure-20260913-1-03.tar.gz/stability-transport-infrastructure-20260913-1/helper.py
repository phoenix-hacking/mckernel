from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,re,shlex,shutil,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work')
assert shutil.disk_usage(work).free>3*1024**3
out=work/'stability-transport-infrastructure-20260913-1';out.mkdir();(out/'tmp').mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],compiler_dependencies=[],compiled_outputs=[],application_acceptance=False,transport_acceptance=False,production_gate_credit=False,scope='Pinned ledger/parser tests and controller protocol fake-process infrastructure only; payload compiled but not executed')
def identity(p):
 d=p.read_bytes();return dict(path=str(p),size=len(d),sha256=hashlib.sha256(d).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 shutil.copyfile(__file__,out/'helper.py')
 names=['scripts/application-tests/'+n for n in ('supervisor.py','verification_state.py','owner_observations.py','owner-observations.md')]+['scripts/tests/'+n for n in ('test_verification_state.py','test_owner_observations.py')]
 names+=['scripts/tests/fixtures/stability-transport-fault/'+n for n in ('controller.c','payload.c','protocol_harness.c','protocol-expectations.json','run_protocol_tests.py')]
 for name in names:
  p=repo/name;q=out/'source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
  record['inputs'].append(dict(original=identity(p),captured=identity(q)))
 spec=importlib.util.spec_from_file_location('supervisor',out/'source/scripts/application-tests/supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(out/'tmp'))
 def run(label,argv,timeout=120):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0],path=env['PATH'])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=20,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['raw_wait_status']==0 and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  return (out/(label+'-collection')/'stdout.bin').read_text()
 for name in ('test_verification_state.py','test_owner_observations.py'):
  run(name,[sys.executable,'-B',str(repo/'scripts/tests'/name),'-v'])
 run('compiler-version',['gcc','--version'])
 package=out/'source/scripts/tests/fixtures/stability-transport-fault'
 for name in ('controller','payload','protocol_harness'):
  obj=out/(name+'.o');elf=out/(name+'.elf');deps=out/(name+'.d')
  run(name+'-compile',['gcc','-std=c11','-D_GNU_SOURCE','-O2','-g','-Wall','-Wextra','-Werror','-fno-pie','-pthread','-MD','-MF',str(deps),'-I',str(repo/'executer/include'),'-c',str(package/(name+'.c')),'-o',str(obj)])
  run(name+'-link',['gcc','-no-pie','-pthread',str(obj),'-Wl,-Map='+str(out/(name+'.map')),'-o',str(elf)])
  run(name+'-elf',['readelf','-h','-l','-d',str(elf)])
  loader=run(name+'-loader-trace',['ldd',str(elf)]);record.setdefault('loader_tracing_scope','ldd examines interpreter/DSO dependencies only; no payload main execution')
  for line in loader.splitlines():
   for item in line.split():
    if item.startswith('/') and Path(item).is_file():record.setdefault('loader_dependencies',[]).append(identity(Path(item)))
  data=deps.read_text().replace('\\\n',' '); _,items=data.split(':',1)
  for item in shlex.split(items):
   path=Path(item)
   if not path.is_absolute():path=out/path
   assert path.is_file(),path
   row=identity(path)
   if row not in record['compiler_dependencies']:record['compiler_dependencies'].append(row)
  record['compiled_outputs'] += [identity(p) for p in (obj,elf,deps,out/(name+'.map'))]
 run('protocol-suite',[sys.executable,'-B',str(package/'run_protocol_tests.py'),'--harness',str(out/'protocol_harness.elf'),'--attempt-root',str(out/'protocol-cases')],240)
 protocol=json.loads((out/'protocol-cases/result.json').read_text());assert protocol['status']=='PASS' and len(protocol['results'])==23
 record['protocol_suite']=identity(out/'protocol-cases/result.json')
 for row in record['inputs']:
  assert identity(Path(row['original']['path']))==row['original']
  assert identity(Path(row['captured']['path']))==row['captured']
 record.update(status='PASS',ledger_tests=23,owner_parser_tests=18,controller_protocol_cases=23,guest_execution=False,payload_main_executed=False)
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
