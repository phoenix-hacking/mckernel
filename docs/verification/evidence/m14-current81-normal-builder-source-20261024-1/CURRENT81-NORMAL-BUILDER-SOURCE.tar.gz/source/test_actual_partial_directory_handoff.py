"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Execute the actual outer handoff AST and actual embedded partial-phase directory
creator on owned temporary directories. Full ELF leaf predicates, compiler calls
and existing16 tests are deliberately outside this one orchestration regression.
"""
from pathlib import Path
import ast, hashlib, os, stat, tempfile, unittest

D = Path(__file__).resolve().parent
NAME = 'native_rust_exact_mckernel_image_offline.CURRENT81.NORMAL.NOT-RELEASED.py'
OLD = D.parent / NAME
NEW = D / NAME
EXPECTED = {OLD: '889c626784825f0c718bce61abbc5d4485806d302eda97d3118d891ba437d0fc',
            NEW: 'caace62e2332a365bb6ff303d1464628a454815cdf48de22a93facbffb5e7e1e'}


def actual_handoff(path):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED[path]
    tree = ast.parse(raw, str(path))
    graph = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and
                 n.name == '_m14_current81_actual_graph')
    start = next(i for i, n in enumerate(graph.body) if isinstance(n, ast.Assign) and
                 ast.unparse(n.targets[0]) == "context['phase']" and
                 isinstance(n.value, ast.Constant) and n.value.value == 'partial')
    end = next(i for i in range(start, len(graph.body)) if
               isinstance(graph.body[i], ast.Expr) and
               isinstance(graph.body[i].value, ast.Call) and
               isinstance(graph.body[i].value.func, ast.Name) and
               graph.body[i].value.func.id == 'exec')
    outer_nodes = graph.body[start:end + 1]
    assert len(outer_nodes) == (4 if path == OLD else 3)
    value = next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id == 'M14_CURRENT81_PHASE_SOURCE' for t in n.targets))
    phase = ast.literal_eval(value)
    phase_tree = ast.parse(phase)
    branch = next(n for n in phase_tree.body if isinstance(n, ast.If) and
                  ast.unparse(n.test) == "phase == 'selected'")
    creator = branch.orelse[0]
    assert isinstance(creator, ast.Expr) and isinstance(creator.value, ast.Call)
    assert ast.unparse(creator.value.func) == 'A.mkdir'
    assert not creator.value.args and len(creator.value.keywords) == 1
    assert creator.value.keywords[0].arg == 'mode'
    assert ast.literal_eval(creator.value.keywords[0].value) == 0o700
    inner = ast.Module(body=[creator], type_ignores=[])
    # No fabricated mkdir body: the project's embedded exclusive creator runs.
    inner_source = ast.unparse(inner)
    return compile(ast.Module(body=outer_nodes, type_ignores=[]), str(path), 'exec'), inner_source


OLD_HANDOFF, OLD_CREATOR = actual_handoff(OLD)
NEW_HANDOFF, NEW_CREATOR = actual_handoff(NEW)
assert OLD_CREATOR == NEW_CREATOR


def execute(handoff, creator, owned_parent):
    context = {}
    namespace = dict(O=owned_parent, context=context, M14_CURRENT81_PHASE_SOURCE=creator)
    exec(handoff, namespace)
    return context


class ActualPartialDirectoryHandoff(unittest.TestCase):
    def owned(self):
        return tempfile.TemporaryDirectory(prefix='.partial-handoff-', dir=str(D))

    def test_original_actual_handoff_reproduces_duplicate_creator(self):
        with self.owned() as root:
            parent = Path(root)
            with self.assertRaises(FileExistsError):
                execute(OLD_HANDOFF, OLD_CREATOR, parent)
            self.assertEqual(sorted(p.name for p in parent.iterdir()), ['partial'])
            self.assertEqual(stat.S_IMODE((parent/'partial').stat().st_mode), 0o700)

    def test_corrected_actual_handoff_has_one_exclusive_creator(self):
        with self.owned() as root:
            parent = Path(root)
            context = execute(NEW_HANDOFF, NEW_CREATOR, parent)
            target = parent/'partial'
            self.assertEqual(context['phase'], 'partial')
            self.assertEqual(context['A'], target)
            self.assertEqual(sorted(p.name for p in parent.iterdir()), ['partial'])
            self.assertFalse(target.is_symlink())
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o700)
            self.assertEqual(target.stat().st_uid, os.getuid())
            self.assertEqual(list(target.iterdir()), [])

    def test_corrected_actual_handoff_refuses_occupied_namespace(self):
        with self.owned() as root:
            parent = Path(root);target = parent/'partial';target.mkdir(mode=0o700)
            marker = target/'retained';marker.write_bytes(b'preserve')
            before = target.stat()
            with self.assertRaises(FileExistsError):
                execute(NEW_HANDOFF, NEW_CREATOR, parent)
            after = target.stat()
            self.assertEqual((before.st_dev, before.st_ino, before.st_mode),
                             (after.st_dev, after.st_ino, after.st_mode))
            self.assertEqual(marker.read_bytes(), b'preserve')
            self.assertEqual(sorted(p.name for p in target.iterdir()), ['retained'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
