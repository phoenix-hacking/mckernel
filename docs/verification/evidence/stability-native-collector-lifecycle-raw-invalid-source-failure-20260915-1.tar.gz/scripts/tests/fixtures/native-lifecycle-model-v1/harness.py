#!/usr/bin/env python3
"""Dispatcher-owned bounded runner for the MODEL_ONLY lifecycle packet."""
import argparse
import hashlib
import json
import os
import pathlib
import resource
import stat
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
MAX_JSON = 1 << 20
MAX_EXPANDED = 2 << 20
MAX_OUTPUT = 1 << 20
MAX_RAW_ARTIFACT = MAX_JSON + 1
MAX_RAW_STREAM = 1 << 16
RAW_EXPECTED = {
    "stage": "harness", "exit_code": 2, "stdout_hex": "", "stderr_hex": "",
    "model_invocations": 0,
}
OPS = {
    "P_ALLOC", "T_ALLOC", "TID_ASSIGN", "BIRTH", "RUNNABLE", "REF_ADD",
    "REF_DROP", "RETIRE_BEGIN", "RETIRE_DONE", "ABORT", "TERMINAL",
    "ZOMBIE_SET", "PARENT_REAP", "VM_RELEASE", "MAIN_STORAGE_RELEASE",
    "LAUNCHER_LOSS", "CAPTURE_END", "TEARDOWN_FAIL",
}

def strict_bytes(raw):
    assert len(raw) <= MAX_JSON
    def pairs(items):
        result = {}
        for name, value in items:
            assert name not in result, "duplicate key"
            result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def strict_file(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    raw = path.read_bytes()
    assert raw.rstrip().endswith(b"}") and b"\x00" not in raw
    return strict_bytes(raw)

class ExpansionBudget:
    def __init__(self):
        self.nodes = 262144
        self.bytes = MAX_EXPANDED

    def take(self, value):
        self.nodes -= 1
        if value is None:
            cost = 4
        elif type(value) is bool:
            cost = 5
        elif type(value) is int:
            cost = len(str(value))
        elif isinstance(value, str):
            cost = 12 * len(value) + 2
        elif isinstance(value, list):
            cost = max(2, len(value) + 1)
        else:
            cost = 2
        self.bytes -= cost
        assert self.nodes >= 0 and self.bytes >= 0, "expanded literal budget"

def literal_expand(value, pools, args=(), stack=(), budget=None, depth=0):
    """Acyclic literal substitution only; no transition or arithmetic evaluation."""
    if budget is None:
        budget = ExpansionBudget()
    assert depth <= 32 and len(stack) <= 32
    budget.take(value)
    if isinstance(value, dict):
        if set(value) == {"arg"}:
            index = value["arg"]
            assert type(index) is int and 0 <= index < len(args)
            return literal_expand(args[index], {}, (), (), budget, depth + 1)
        assert set(value) in ({"pool"}, {"pool", "args"})
        name = value["pool"]
        assert isinstance(name, str) and name in pools and name not in stack
        supplied = value.get("args", [])
        assert isinstance(supplied, list)
        arity = pool_arity(pools[name])
        assert len(supplied) == arity
        expanded_args = [literal_expand(item, pools, args, stack, budget, depth + 1) for item in supplied]
        return literal_expand(pools[name], pools, expanded_args, stack + (name,), budget, depth + 1)
    if isinstance(value, list):
        result = []
        for item in value:
            result.append(literal_expand(item, pools, args, stack, budget, depth + 1))
        return result
    assert value is None or type(value) in (str, int, bool)
    return value

def pool_arity(value):
    greatest = -1
    if isinstance(value, dict):
        if set(value) == {"arg"}:
            index = value["arg"]
            assert type(index) is int and index >= 0
            return index + 1
        for item in value.values():
            greatest = max(greatest, pool_arity(item) - 1)
    elif isinstance(value, list):
        for item in value:
            greatest = max(greatest, pool_arity(item) - 1)
    return greatest + 1

def checked_expansion(value, pools):
    result = literal_expand(value, pools, budget=ExpansionBudget())
    assert len(json.dumps(result, separators=(",", ":")).encode()) <= MAX_EXPANDED
    return result

def integer(value, low=0, high=(1 << 64) - 1):
    assert type(value) is int and low <= value <= high
    return value

def key(value, process=False):
    assert isinstance(value, list) and len(value) == 7
    result = [integer(item) for item in value]
    assert result[0] and result[2] and result[3] and result[4] and result[6]
    assert (result[5] == 0) if process else (result[5] != 0)
    return result

def operation(raw, expected_id):
    assert isinstance(raw, list) and len(raw) == 8
    op_id, name, subject, parent, a, b, c, d = raw
    assert integer(op_id, 1, 128) == expected_id and name in OPS
    if name in ("LAUNCHER_LOSS", "CAPTURE_END"):
        assert subject is None and parent is None
        subject_wire = parent_wire = [0] * 7
    else:
        assert isinstance(subject, list) and len(subject) == 7
        process_subject = subject[5] == 0
        subject_wire = key(subject, process=process_subject)
        if name == "P_ALLOC":
            assert process_subject
            assert parent is None
            parent_wire = [0] * 7
        elif name == "T_ALLOC":
            assert not process_subject
            parent_wire = key(parent, process=True)
            assert subject_wire[:5] + [0] + subject_wire[6:] == parent_wire
        else:
            assert parent is None
            parent_wire = [0] * 7
    args = [integer(item) for item in (a, b, c, d)]
    if name == "P_ALLOC":
        integer(a, 1, (1 << 31) - 1); assert b == c == d == 0
    elif name == "T_ALLOC":
        integer(a, 0, (1 << 31) - 1); assert b in (0, 1) and c == d == 0
    elif name == "TID_ASSIGN":
        integer(a, 1, (1 << 31) - 1); assert b == c == d == 0
    elif name == "ABORT":
        integer(a, 1, 255); assert b == c == d == 0
    elif name == "TERMINAL":
        integer(a, 0, (1 << 32) - 1); integer(b, 0, 255)
        integer(c, 0, 255); integer(d, 1, 4)
    else:
        assert a == b == c == d == 0
    return [op_id, name, *subject_wire, *parent_wire, *args]

def wire(vector, input_pools):
    capacity = integer(vector["event_capacity"], 0, 256)
    seed = vector["seed"]
    assert seed in ("NONE", "ATTEMPTS_MAX", "LOST_MAX", "RESERVATION_ONE")
    operations = checked_expansion(vector["operations"], input_pools)
    assert isinstance(operations, list) and 0 < len(operations) <= 128
    rows = [f"MODEL2 {capacity} {seed}"]
    for index, raw in enumerate(operations, 1):
        rows.append(" ".join(map(str, operation(raw, index))))
    return ("\n".join(rows) + "\n").encode("ascii")

def expected_rows(document, name):
    rows = checked_expansion(document["vectors"][name], document["pools"])
    assert isinstance(rows, list) and rows
    for index, row in enumerate(rows, 1):
        validate_output_row(row, index)
    return rows

def nullable_key(value, process=None):
    if value is None:
        return
    assert isinstance(value, list) and len(value) == 7
    for item in value:
        integer(item)
    if process is True:
        assert value[5] == 0
    elif process is False:
        assert value[5] != 0

def terminal(value):
    if value is None:
        return
    assert isinstance(value, list) and len(value) == 4
    integer(value[0], 0, (1 << 32) - 1)
    integer(value[1], 0, 255); integer(value[2], 0, 255); integer(value[3], 1, 4)

def process_row(row):
    assert isinstance(row, list) and len(row) == 13
    nullable_key(row[0], True); nullable_key(row[1], True)
    integer(row[2], 1, (1 << 31) - 1)
    assert row[3] in ("Allocated", "Born", "Aborted", "Terminal", "Retiring", "Retired")
    integer(row[4], 0, (1 << 32) - 1); assert row[5] in ("E", "N")
    terminal(row[6]); integer(row[7], 0, 255); nullable_key(row[8], False)
    assert type(row[9]) is type(row[10]) is type(row[11]) is bool
    if row[12] is not None:
        assert isinstance(row[12], list) and len(row[12]) == 3
        nullable_key(row[12][0], True); terminal(row[12][1]); integer(row[12][2], 0, 255)

def thread_row(row):
    assert isinstance(row, list) and len(row) == 11
    nullable_key(row[0], False); nullable_key(row[1], True)
    integer(row[2], 1, (1 << 31) - 1); integer(row[3], 0, (1 << 31) - 1)
    assert type(row[4]) is bool
    assert row[5] in ("Allocated", "Born", "Runnable", "Aborted", "Terminal", "Retiring", "Retired")
    integer(row[6], 0, (1 << 32) - 1); assert row[7] in ("E", "N")
    terminal(row[8]); integer(row[9], 0, 255)
    if row[10] is not None:
        assert isinstance(row[10], list) and len(row[10]) == 3
        nullable_key(row[10][0], False); terminal(row[10][1]); integer(row[10][2], 0, 255)

def validate_output_row(row, expected_id):
    assert isinstance(row, list) and len(row) == 6
    assert integer(row[0], 1, 128) == expected_id
    assert row[1] in ("OK", "SCHEMA", "KEY", "STATE", "IDENTITY", "REF", "BUSY", "STATUS", "LIMIT", "CLOSED")
    assert isinstance(row[2], list)
    for event in row[2]:
        assert isinstance(event, list) and len(event) == 11
        assert integer(event[0]) == 1; integer(event[1], 1); integer(event[2], 1, 128)
        assert isinstance(event[3], str) and event[3]
        nullable_key(event[4]); nullable_key(event[5], True)
        if event[6] is not None: integer(event[6], 1, (1 << 31) - 1)
        if event[7] is not None: integer(event[7], 0, (1 << 31) - 1)
        assert isinstance(event[8], list) and len(event[8]) == 5
        integer(event[8][0], 0, (1 << 32) - 1)
        for item in event[8][1:]: integer(item, 0, 255)
        assert integer(event[9]) == 1 and integer(event[10]) == event[2]
    assert isinstance(row[3], list) and isinstance(row[4], list)
    for item in row[3]: process_row(item)
    for item in row[4]: thread_row(item)
    control = row[5]
    assert isinstance(control, list) and len(control) == 7
    integer(control[0]); integer(control[1]); integer(control[2])
    assert type(control[3]) is type(control[4]) is type(control[5]) is bool
    integer(control[6])

def run(command, data):
    result = subprocess.run(command, input=data, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=10, check=False)
    assert result.returncode == 0 and not result.stderr
    assert len(result.stdout) <= MAX_OUTPUT
    rows = [strict_bytes(line) for line in result.stdout.splitlines()]
    for index, row in enumerate(rows, 1):
        validate_output_row(row, index)
    return rows

def compiler(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    return str(path)

def build(args, output):
    rust, cref = output / "model-rust", output / "model-c"
    subprocess.run([compiler(args.rustc), "--edition=2021", "-Dwarnings", "-o",
                    str(rust), str(HERE / "model.rs")], check=True, timeout=60)
    subprocess.run([compiler(args.cc), "-std=c11", "-Wall", "-Wextra", "-Werror",
                    "-O2", "-o", str(cref), str(HERE / "reference.c")],
                   check=True, timeout=60)
    return rust, cref

def validate_input_document(document, require_nested_empty=False):
    assert set(document) == {"schema_version", "model_only", "corpus_complete", "pools", "vectors", "raw_invalid", "mutants"}
    assert document["schema_version"] == 2
    assert document["model_only"] is True
    assert type(document["corpus_complete"]) is bool
    assert isinstance(document["pools"], dict)
    assert all(isinstance(name, str) for name in document["pools"])
    assert isinstance(document["vectors"], list)
    assert isinstance(document["raw_invalid"], list)
    if require_nested_empty:
        assert document["raw_invalid"] == []
    assert isinstance(document["mutants"], dict)
    seen = set()
    for vector in document["vectors"]:
        assert set(vector) == {"name", "coverage", "event_capacity", "seed", "operations"}
        name = vector["name"]
        coverage = vector["coverage"]
        assert isinstance(name, str) and name and name not in seen
        assert isinstance(coverage, list) and coverage
        assert all(isinstance(item, str) and item for item in coverage)
        assert len(set(coverage)) == len(coverage)
        seen.add(name)
        wire(vector, document["pools"])
    return seen

def validate_expected_document(document, names):
    assert set(document) == {"schema_version", "model_only", "corpus_complete", "pools", "vectors"}
    assert document["schema_version"] == 2 and document["model_only"] is True
    assert type(document["corpus_complete"]) is bool
    assert isinstance(document["pools"], dict) and isinstance(document["vectors"], dict)
    assert names == set(document["vectors"])
    for name in names:
        expected_rows(document, name)

def validate_raw_records(records):
    seen = set()
    for record in records:
        assert set(record) == {"name", "coverage", "source", "expected"}
        name, coverage = record["name"], record["coverage"]
        assert isinstance(name, str) and name and name not in seen
        assert isinstance(coverage, list) and coverage
        assert all(isinstance(item, str) and item for item in coverage)
        assert len(set(coverage)) == len(coverage)
        assert record["expected"] == RAW_EXPECTED
        source = record["source"]
        assert isinstance(source, dict)
        assert set(source) in ({"inline_utf8"}, {"artifact"})
        if "inline_utf8" in source:
            assert isinstance(source["inline_utf8"], str)
            assert len(source["inline_utf8"].encode("utf-8")) <= MAX_RAW_ARTIFACT
        else:
            artifact = source["artifact"]
            assert set(artifact) == {"path", "sha256", "size"}
            assert isinstance(artifact["path"], str)
            assert isinstance(artifact["sha256"], str) and len(artifact["sha256"]) == 64
            assert artifact["sha256"] == artifact["sha256"].lower()
            assert all(char in "0123456789abcdef" for char in artifact["sha256"])
            integer(artifact["size"], 0, MAX_RAW_ARTIFACT)
        seen.add(name)
    return seen

def artifact_bytes(description):
    relative = pathlib.PurePosixPath(description["path"])
    prefix = pathlib.PurePosixPath("scripts/tests/fixtures/native-lifecycle-model-v1")
    assert not relative.is_absolute() and relative.parts[:len(prefix.parts)] == prefix.parts
    assert all(part not in ("", ".", "..") for part in relative.parts)
    root = HERE.parents[3]
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for component in relative.parts[:-1]:
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=directory)
            os.close(directory)
            directory = child
        descriptor = os.open(relative.parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=directory)
    finally:
        os.close(directory)
    try:
        before = os.fstat(descriptor)
        assert stat.S_ISREG(before.st_mode)
        assert before.st_size == description["size"] <= MAX_RAW_ARTIFACT
        chunks, total = [], 0
        while True:
            chunk = os.read(descriptor, min(65536, MAX_RAW_ARTIFACT + 1 - total))
            if not chunk:
                break
            chunks.append(chunk); total += len(chunk)
            assert total <= MAX_RAW_ARTIFACT
        raw = b"".join(chunks)
        after = os.fstat(descriptor)
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
        assert len(raw) == description["size"]
        assert hashlib.sha256(raw).hexdigest() == description["sha256"]
        return raw
    finally:
        os.close(descriptor)

def raw_source_bytes(record):
    source = record["source"]
    if "inline_utf8" in source:
        return source["inline_utf8"].encode("utf-8")
    return artifact_bytes(source["artifact"])

def decode_raw_document(raw):
    document = strict_bytes(raw)
    validate_input_document(document, require_nested_empty=True)

def decoder_mode():
    raw = sys.stdin.buffer.read(MAX_RAW_ARTIFACT + 1)
    try:
        decode_raw_document(raw)
    except (AssertionError, json.JSONDecodeError, UnicodeDecodeError, ValueError):
        return 2
    return 0

def raw_child(raw):
    def limit_output():
        resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_RAW_STREAM, MAX_RAW_STREAM))
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        process = subprocess.Popen([sys.executable, str(HERE / "harness.py"), "--decode-raw-document"], stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, preexec_fn=limit_output)
        try:
            process.communicate(raw, timeout=5)
        except subprocess.TimeoutExpired:
            process.kill(); process.communicate()
            raise AssertionError("raw decoder timeout")
        stdout.seek(0); stderr.seek(0)
        out = stdout.read(MAX_RAW_STREAM + 1); err = stderr.read(MAX_RAW_STREAM + 1)
        assert len(out) <= MAX_RAW_STREAM and len(err) <= MAX_RAW_STREAM
        return process.returncode, out, err

def check_raw_invalid(vectors, expected):
    names = validate_input_document(vectors)
    validate_expected_document(expected, names)
    validate_raw_records(vectors["raw_invalid"])
    for record in vectors["raw_invalid"]:
        code, out, err = raw_child(raw_source_bytes(record))
        assert code == 2 and out == b"" and err == b""

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--decode-raw-document", action="store_true")
    parser.add_argument("--check-raw-invalid", action="store_true")
    parser.add_argument("--rustc")
    parser.add_argument("--cc")
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args()
    assert not (args.decode_raw_document and args.check_raw_invalid)
    if args.decode_raw_document:
        assert args.rustc is args.cc is args.output is None
        return decoder_mode()
    vectors = strict_file(HERE / "vectors.json")
    expected = strict_file(HERE / "expected.json")
    names = validate_input_document(vectors)
    validate_expected_document(expected, names)
    validate_raw_records(vectors["raw_invalid"])
    if args.check_raw_invalid:
        assert args.rustc is args.cc is args.output is None
        check_raw_invalid(vectors, expected)
        return 0
    assert args.rustc is not None and args.cc is not None and args.output is not None
    assert args.output.is_absolute() and not args.output.exists()
    assert vectors["corpus_complete"] is expected["corpus_complete"] is True
    args.output.mkdir(mode=0o700)
    rust, cref = build(args, args.output)
    seen = set()
    for vector in vectors["vectors"]:
        assert set(vector) == {"name", "coverage", "event_capacity", "seed", "operations"}
        name = vector["name"]
        assert isinstance(name, str) and name not in seen
        assert isinstance(vector["coverage"], list) and vector["coverage"]
        seen.add(name)
        want = expected_rows(expected, name)
        rust_rows = run([str(rust)], wire(vector, vectors["pools"]))
        c_rows = run([str(cref)], wire(vector, vectors["pools"]))
        assert rust_rows == want and c_rows == want and rust_rows == c_rows
    assert seen == set(expected["vectors"])
    assert vectors["mutants"] == {
        "birth-after-runnable": "birth-after-runnable",
        "early-retirement": "retained-thread-ref",
        "silent-loss": "buffer-full",
        "tid-aliasing": "active-tid-alias",
    }
    directory = os.open(args.output, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

if __name__ == "__main__":
    sys.exit(main())
