"""Existing WHOLE owner read-only crossrefs: correctedpositive/originalnegative only.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
No owner main/lock/Docker/source validation/compiler execution.
"""
import hashlib,json,sys,types
from pathlib import Path
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(r):
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];return b
assert len(sys.argv)==3
raw=Path(sys.argv[1]).read_bytes();assert sha(raw)==sys.argv[2];b=json.loads(raw)
original=json.loads(bound(b['original_request']));corrected=json.loads(bound(b['corrected_request']))
bound(b['original_supplement']);bound(b['corrected_supplement'])
assert {k for k in original if original[k]!=corrected[k]}=={'gitlink_manifest','gitlink_manifest_sha256'}
old=json.loads(Path(original['gitlink_manifest']).read_bytes());new=json.loads(Path(corrected['gitlink_manifest']).read_bytes())
assert {k for k in old if old[k]!=new[k]}=={'base_manifest_sha256'}
assert new['base_manifest_sha256']==b['source_manifest_sha256']==corrected['source_manifest_sha256']
m=types.ModuleType('_actual_existing_image_owner_crossrefs');m.__file__=b['owner']['path']
exec(compile(bound(b['owner']),m.__file__,'exec'),m.__dict__)
positive=m.preflight_request_crossrefs(corrected)
assert positive=={'status':'PASS_DETERMINISTIC_REQUEST_CROSSREFS_ONLY','source_manifest_sha256':corrected['source_manifest_sha256'],'gitlink_manifest_sha256':corrected['gitlink_manifest_sha256'],'driver_sha256':corrected['driver_sha256']}
try:m.preflight_request_crossrefs(original)
except m.OwnerError as e:assert str(e)==b['expected_original_error'];negative=str(e)
else:raise AssertionError('original stale gitlink crossref unexpectedlyaccepted')
print(json.dumps({'status':'PASS_ACTUAL_WHOLE_OWNER_CROSSREFS_CORRECTED_POSITIVE_ORIGINAL_NEGATIVE_ONLY','owner':b['owner'],'corrected_request':b['corrected_request'],'positive':positive,'original_refusal':negative,'compiler_started':False,'Docker':False,'lock_acquired':False},sort_keys=True))
