"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure retained-evidence body comparison. Fixed fixture clock grants no live admission.
"""
from pathlib import Path
import ast, copy, hashlib, json
from types import SimpleNamespace

D = Path(__file__).resolve().parent

def checked(record):
    raw = Path(record['path']).read_bytes()
    assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
    return raw

def body(nodes, scope, name):
    exec(compile(ast.Module(body=nodes, type_ignores=[]), name, 'exec'), scope)

def refusal(call, error):
    try:
        call()
    except error:
        return
    raise AssertionError('original descriptor producer unexpectedly accepted')

pins = json.loads((D/'RETAINED-ACTUAL-BODY-INPUT-PINS.json').read_bytes())
raw = {name: checked(record) for name, record in pins.items()}
snapshot = json.loads(raw['actual_snapshot'])
old_base = json.loads(raw['old_machine_base'])
old_cfg = json.loads(raw['old_final_config'])
inputs = json.loads(raw['corrected_constructor_inputs'])
constructor = ast.parse(raw['corrected_constructor'])

def producer(keyword, target):
    matches = [value.value for node in constructor.body
               if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
               and isinstance(node.value.func, ast.Attribute)
               and isinstance(node.value.func.value, ast.Name)
               and node.value.func.value.id == target and node.value.func.attr == 'update'
               for value in node.value.keywords if value.arg == keyword]
    assert len(matches) == 1
    return eval(compile(ast.Expression(matches[0]), pins['corrected_constructor']['path'], 'eval'),
                dict(c=inputs, P=Path(inputs['latest_physical']['path'])))

machine_terminal = producer('exclusive_queue_predecessor', 'base')
guard_terminal = producer('terminal_acceptance', 'equal')
assert set(machine_terminal) == set(guard_terminal) == {'path', 'sha256'}
assert machine_terminal == guard_terminal == snapshot['terminal_acceptance']
assert old_base['exclusive_queue_predecessor'] != machine_terminal
assert old_cfg['snapshot_equal']['terminal_acceptance'] != guard_terminal
base = copy.deepcopy(old_base)
base['exclusive_queue_predecessor'] = machine_terminal
cfg = copy.deepcopy(old_cfg)
cfg['snapshot_equal']['terminal_acceptance'] = guard_terminal

seven = json.loads(raw['actual_seven'])
argv = seven['steps'][1]['argv_template']
assembly = ast.parse(argv[argv.index('-c')+1]).body
assert all(isinstance(node, ast.Assert) for node in assembly[9:12])
assert isinstance(assembly[12], ast.Expr) and isinstance(assembly[13], ast.Assign)
clock = SimpleNamespace(time=lambda: snapshot['time_epoch'])
snapref = dict(pins['actual_snapshot'])
scope = dict(snapshot=copy.deepcopy(snapshot), base=copy.deepcopy(base), time=clock,
             json=json, V=Path(pins['actual_snapshot']['path']).parent,
             sys=SimpleNamespace(argv=['fixture', None, snapref['sha256']]),
             snapshotbytes=raw['actual_snapshot'])
# Exact actual assembly assertions, late-field production and JSON encoding;
# exclude filesystem reads/writes and print only, preserving their source pins.
body(assembly[9:14], scope, 'actual-machine-assembly-retained-body')
machine = json.loads(scope['raw'])

guard_tree = ast.parse(raw['actual_final_guard'])
need = next(node for node in guard_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'need')
main = next(node for node in guard_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
loops = [node for node in main.body if isinstance(node, ast.For)
         and isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Attribute)
         and isinstance(node.iter.func.value, ast.Subscript)
         and isinstance(node.iter.func.value.slice, ast.Constant)
         and node.iter.func.value.slice.value == 'snapshot_equal']
assert len(loops) == 1
expected = next(node for node in main.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == 'expected' for target in node.targets))
machine_needs = [node for node in main.body if isinstance(node, ast.Expr)
                 and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
                 and node.value.func.id == 'need' and len(node.value.args) == 2
                 and isinstance(node.value.args[1], ast.Constant)
                 and node.value.args[1].value == 'only three exact permitted late machine fields']
assert len(machine_needs) == 1
guard_scope = dict(cfg=cfg, snapshot=snapshot, base=base, machine=machine, snapref=snapref)
body([need, loops[0], expected, machine_needs[0]], guard_scope, 'actual-final-guard-descriptor-body')

original_machine_scope = dict(snapshot=copy.deepcopy(snapshot), base=copy.deepcopy(old_base), time=clock)
refusal(lambda: body(assembly[9:12], original_machine_scope, 'original-machine-descriptor-negative'), AssertionError)
original_guard_scope = dict(cfg=old_cfg, snapshot=snapshot)
body([need], original_guard_scope, 'actual-final-guard-need')
refusal(lambda: body(loops, original_guard_scope, 'original-guard-descriptor-negative'), ValueError)

result = dict(status='PASS_RETAINED_ACTUAL_MACHINE_AND_GUARD_DESCRIPTOR_BODIES_ONLY',
              cases=3, corrected_positive=True, original_machine_refused=True,
              original_guard_refused=True, snapshot_equal_fields=len(cfg['snapshot_equal']),
              actual_snapshot=pins['actual_snapshot'], fixture_clock=snapshot['time_epoch'],
              root_operations=0, guest_runs=0, runtime_release=False,
              live_admission=False, freshness_acceptance=False,
              untested_live_predicates='Root ownership/mode/full FD/current parent/fresh live census/expiry remain actual future admissions.')
print(json.dumps(result, sort_keys=True))
