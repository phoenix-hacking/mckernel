"""Finite current four-object request join only; no candidate import/root/compile."""
from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--request',required=True);p.add_argument('--request-sha256',required=True);a=p.parse_args()
def raw(row):
 data=Path(row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes'];return data
r=json.loads(raw(dict(path=a.request,sha256=a.request_sha256,bytes=Path(a.request).stat().st_size)))
s=json.loads(raw(r['source']));m=json.loads(raw(r['source_materialization']));v=json.loads(raw(r['source_materialization_acceptance']))
assert v['schema']=='mckernel.numa-vm-policy-insert.actual-source-materialization-review.v1'
assert v['status']=='PASS_ACTUAL_SOURCE_MATERIALIZATION_AND_FOUR_OBJECT_CONSUMER_MANIFEST_ONLY' and v['implementation_ownership']is False and v['reviewer']
assert s['count']==len(s['rows'])==v['regular_files']==6911 and len({x['relative']for x in s['rows']})==6911
assert m['source_entries']==v['source_entries']==6960 and m['tracked_symlinks']==v['tracked_symlinks']==49
assert s['source_identity']==m['materialization_sha256']==r['materialization_sha256']==v['materialization_id']
assert s['source_state']['source_derivative_sha256']==m['source_derivative_sha256']==r['source_derivative_sha256']==v['source_hash']
assert r['source']['sha256']==v['source_manifest']['sha256'] and r['source_materialization']['sha256']==v['materialization_receipt']['sha256']
rows={x['relative']:x for x in s['rows']};config=rows['.compiler-generated/config.h']
assert config['sha256']==v['new_config']['sha256']=='da78d6a8c94b274adad3159b1cc373b00e5de7fea6cc2ae7955a700078db6b2f' and config['bytes']==v['new_config']['bytes']==1055
for key in ('driver','owner','commands','prototype_assertions','capture_helpers','provider'):raw(r[key])
c=json.loads(raw(r['commands']));assert[x['selection']for x in c]==['native','legacy','caller-selected','caller-fallback']
assert len(c)==len(r['expected_artifacts'])==r['driver_limits']['compiler_stages']==4
assert all(x['cwd']=='/work/output/build/kernel' for x in c)
for x in c[:2]:assert x['argv'][-1]=='/src/kernel/rust/lib.rs' and any(a.startswith('--emit=obj=')for a in x['argv'])
selected=c[2]['argv'];fallback=c[3]['argv'];assert selected.count('-DMCKERNEL_RUST_SYSCALL_POLICY_HELPERS')==1 and '-DMCKERNEL_RUST_SYSCALL_POLICY_HELPERS'not in fallback
assert '-DMCKERNEL_NATIVE_FORK_OWNED_TRANSACTION'in selected and '-DMCKERNEL_NATIVE_FORK_OWNED_TRANSACTION'in fallback
normalized=[a for a in selected if a!='-DMCKERNEL_RUST_SYSCALL_POLICY_HELPERS'];normalized[normalized.index('-o')+1]=fallback[fallback.index('-o')+1];assert normalized==fallback
assert all(x['output']=='/work/'+y for x,y in zip(c,r['expected_artifacts']))
mounts=r['mounts'];assert mounts[0]['source']==m['source'] and mounts[0]['target']=='/src' and mounts[0]['readonly']is True
assert[x['target']for x in mounts if not x['readonly']]==['/work']
for key,target in [('driver','/driver.py'),('source','/inputs.json'),('commands','/commands.json'),('prototype_assertions','/prototype-assertions.h')]:assert next(x for x in mounts if x['target']==target)['source']==r[key]['path']
assert r['latest_exclusive_physical']is None and r['source_publication']is None and r['actual_execution_release']is None and r['heavy_execution_review']is None and r['heavy_resource_grant']is None
assert r['compiler_started']is False
work=Path(r['work_root']);assert {x.name for x in work.iterdir()}=={'output','home','tmp'} and all(x.is_dir()and not any(x.iterdir())for x in work.iterdir())
print(json.dumps(dict(status='PASS_FINITE_ACTUAL_FOUR_OBJECT_REQUEST_JOIN_ONLY',commands=4,regular_rows=6911,symlinks=49,root_operations=0,compiler_jobs=0,heavy_authority=False)))
