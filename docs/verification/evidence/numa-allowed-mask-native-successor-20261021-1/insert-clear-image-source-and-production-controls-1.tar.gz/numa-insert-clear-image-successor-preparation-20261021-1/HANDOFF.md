Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

This is source/DATA preparation only. No candidate import, materialization,
validator, compiler, Docker, root, guest, Git or lease operation was executed.
Root owns every execution grant, integration, publication and acceptance.

The accepted Q production6959 source is the parent. Only kernel/syscall.c
(bca4d642,842598B) and kernel/rust/syscall_policy.rs (92eec5a9,707533B)
change, from the root-verified 8cd600a7 checkpoint. All6957 other source entries,
49 tracked symlinks,21 IHK metadata entries, modes/kinds/gitlinks/restoration,
production CMake af2758e8 and raw lib4e8d34dc remain unchanged. No launcher,
module, app, generated config or private compiler assertion overlay was added.

EXACT-TWO-SOURCE-OVERLAY-RECIPE.json and thin-inputs.json bind the two private
overlay copies. Planned derivative cfef21c9 and materialization b8aaa2f4 are
source DATA fingerprints, not observations or acceptance. PREPARATION-RECEIPT.json
pins all controls. SOURCE-CONTROL-DELTA-INSPECTION.json records complete unchanged
function/class ASTs for both source-contract copies, image driver, materializer
and whole checker. Their differences are finite canonical-manifest/source pins,
the private parent/output/overlay paths and the two genuinely changed old/new
source-pin checks. Full source validation/build algorithms are unchanged.

ORDINARY-MATERIALIZATION-AND-WHOLE-VALIDATOR-PROPOSAL.json has the exact existing
CPU6/onejob/1GiB/30CPU/35wall/32MiB profile and two commands. Root first obtains
the focused source review and fresh aggregate/storage grant, runs the materializer
once, accepts the actual private6959/49 source/inode, then runs the whole checker.
The checker imports entire old/new drivers and requires genuine old-Q pin refusal.
Its affinity endpoint is the real absent compile_commands.json read; that is
source-gate evidence only, never compiler/full-affinity acceptance. All future
source acceptance, image build and native authority remain null.

NAMED-INSERT-CLEAR-DEFAULT-CONSUMER-AND-ELF-JOINS.json lists the actual default
MCKERNEL_RUST_SYSCALL_POLICY_HELPERS consumer, compiled-C relocation, two Rust
provider definitions, same production Rust object and unique final ELF/no-unresolved
joins required for insert and clear. Reuse the existing real18-command/9-artifact/
32-inventory/provider/CMake/defaultOFF/ABI/link gates. Do not repeat the combined
four-object compiler checks. One later genuine production kernel-image build is
needed for changed C/Rust, including actual whole TU/crate/header compilation.

Keep accepted launcher33f/current modules and the strict116B/empty-stderr/exit37
application. Q retains historical launcher source; its genuine transitive689
build artifact is build evidence and never substitutes for runtime33f. The
existing dependency/CMake gates remain intact; no skip flag is introduced.

Preserve all source/compiler/native failures and prior accepted facts, current
ownership, mutex27:4, retained Scratch21, scratch110GiB UUID/noresize,16/12GiB
floors and measured growth, and oneheavy CPUs2-5/4CPU/12GiB/no-added-swap/512tasks/
nonet/jobs<=4. One failed candidate plus one bounded correction per family then
expert escalation; no unchanged replay. Quiesce before any root-announced census.
