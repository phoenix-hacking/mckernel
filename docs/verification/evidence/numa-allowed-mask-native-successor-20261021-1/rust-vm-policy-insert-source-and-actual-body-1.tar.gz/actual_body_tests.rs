#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
#[path="/home/holden/mckernel/kernel/rust/rbtree.rs"] mod rbtree;
use abi::{AbiRbNode,AbiRbRoot,CInt,CULong,ProcessVm,VmRangeNumaPolicy};
use std::cell::RefCell;
use core::mem::{offset_of,size_of};
use core::ptr::{addr_of_mut,null_mut};
const EINVAL:CInt=22;const EFAULT:CInt=14;
include!("actual_rust_insert.rs");
thread_local! {
 static EVENTS:RefCell<Vec<(u8,Vec<u64>)>>=RefCell::new(Vec::new());
 static CURRENT:RefCell<(usize,Vec<usize>)>=RefCell::new((0,Vec::new()));
}
fn index(p:*mut AbiRbNode)->u64 {
 if p.is_null(){return u64::MAX;}
 CURRENT.with(|x|x.borrow().1.iter().position(|a|*a==p as usize).expect("foreign node")as u64)
}
fn event(kind:u8,data:Vec<u64>){EVENTS.with(|e|e.borrow_mut().push((kind,data)));}
#[no_mangle]
unsafe extern "C" fn fixture_rb_link_node(node:*mut AbiRbNode,parent:*mut AbiRbNode,slot:*mut *mut AbiRbNode){
 assert!((*slot).is_null());let side=if parent.is_null(){0}else if slot==addr_of_mut!((*parent).rb_left){1}else{assert_eq!(slot,addr_of_mut!((*parent).rb_right));2};
 event(1,vec![index(node),index(parent),side]);
 rbtree::rb_link_node(node.cast(),parent.cast(),slot.cast());
}
#[no_mangle]
unsafe extern "C" fn fixture_rb_insert_color(node:*mut AbiRbNode,root:*mut AbiRbRoot){
 event(2,vec![index(node)]);rbtree::rb_insert_color(node.cast(),root.cast());
}
#[no_mangle]
unsafe extern "C" fn fixture_log_fields(overlap:i32,label:*const core::ffi::c_char,vm:*mut core::ffi::c_void,start:u64,end:u64,mask:*mut u64,policy:i32,os:u64,oe:u64,om:*mut u64,op:i32){
 assert_eq!(std::ffi::CStr::from_ptr(label).to_bytes(),b"vm_policy_insert");
 CURRENT.with(|x|assert_eq!(vm as usize,x.borrow().0));
 let node=mask.cast::<u8>().sub(offset_of!(VmRangeNumaPolicy,numa_mask)).cast::<VmRangeNumaPolicy>();
 assert_eq!((start,end,policy),((*node).start,(*node).end,(*node).numa_mem_policy));
 let mut data=vec![index(addr_of_mut!((*node).policy_rb_node)),start,end,policy as u64];data.extend_from_slice(&(*node).numa_mask);
 if overlap!=0 {
  let old=om.cast::<u8>().sub(offset_of!(VmRangeNumaPolicy,numa_mask)).cast::<VmRangeNumaPolicy>();
  assert_eq!((os,oe,op),((*old).start,(*old).end,(*old).numa_mem_policy));
  data.extend_from_slice(&[index(addr_of_mut!((*old).policy_rb_node)),os,oe,op as u64]);data.extend_from_slice(&(*old).numa_mask);
 }
 event(if overlap==0{0}else{3},data);
}
unsafe extern "C" {fn fixture_insert_reference(vm:*mut ProcessVm,node:*mut VmRangeNumaPolicy)->i32;fn fixture_insert_selected(vm:*mut ProcessVm,node:*mut VmRangeNumaPolicy)->i32;}
struct Tree{vm:Box<ProcessVm>,nodes:Vec<Box<VmRangeNumaPolicy>>}
impl Tree {
 fn new(ranges:&[(u64,u64)])->Self {Self{vm:Box::new(unsafe{core::mem::zeroed()}),nodes:ranges.iter().enumerate().map(|(i,(s,e))|{
  let mut n:Box<VmRangeNumaPolicy>=Box::new(unsafe{core::mem::zeroed()});n.start=*s;n.end=*e;n.numa_mask=[1u64.rotate_left(i as u32),i as u64,0x12345678,u64::MAX];n.numa_mem_policy=(i%5)as i32;n.il_prev=i as i32+37;n.policy_rb_node.__rb_parent_color=0xfeed; n}).collect()}}
 fn activate(&mut self){CURRENT.with(|x|*x.borrow_mut()=((&mut*self.vm)as*mut ProcessVm as usize,self.nodes.iter_mut().map(|n|(&mut n.policy_rb_node)as*mut AbiRbNode as usize).collect()));EVENTS.with(|x|x.borrow_mut().clear());}
 fn encode(&mut self)->Vec<u64>{self.activate();let mut v=vec![index(self.vm.vm_range_numa_policy_tree.rb_node)];for n in &self.nodes{
  let pc=n.policy_rb_node.__rb_parent_color;let rawparent=(pc&!3)as usize;
  let parent=self.nodes.iter().position(|m|(&m.policy_rb_node)as*const _ as usize==rawparent).map(|i|((i as u64+1)<<2)|(pc&3)).unwrap_or(pc);
  v.extend_from_slice(&[parent,index(n.policy_rb_node.rb_left),index(n.policy_rb_node.rb_right),n.start,n.end,n.numa_mem_policy as u64,n.il_prev as u64]);v.extend_from_slice(&n.numa_mask);
 }v}
 unsafe fn verify_rb(&self){
  unsafe fn walk(node:*mut AbiRbNode,parent:*mut AbiRbNode,seen:&mut Vec<usize>)->usize{
   if node.is_null(){return 1;}assert!(!seen.contains(&(node as usize)));seen.push(node as usize);
   assert_eq!(((*node).__rb_parent_color&!3)as*mut AbiRbNode,parent);
   if (*node).__rb_parent_color&1==0{for c in [(*node).rb_left,(*node).rb_right]{assert!(c.is_null()||(*c).__rb_parent_color&1==1);}}
   let l=walk((*node).rb_left,node,seen);let r=walk((*node).rb_right,node,seen);assert_eq!(l,r);l+((*node).__rb_parent_color&1)as usize
  }
  let root=self.vm.vm_range_numa_policy_tree.rb_node;if !root.is_null(){assert_eq!((*root).__rb_parent_color&1,1);walk(root,null_mut(),&mut Vec::new());}
 }
}
fn exercise(ranges:&[(u64,u64)],order:&[usize])->usize{
 let mut a=Tree::new(ranges);let mut b=Tree::new(ranges);let mut n=0;
 for &i in order{
  let before_a=a.encode();let before_b=b.encode();assert_eq!(before_a,before_b);
  a.activate();let ra=unsafe{fixture_insert_reference(&mut*a.vm,&mut*a.nodes[i])};let ea=EVENTS.with(|x|x.borrow().clone());
  b.activate();let rb=unsafe{fixture_insert_selected(&mut*b.vm,&mut*b.nodes[i])};let eb=EVENTS.with(|x|x.borrow().clone());
  assert_eq!(ra,rb,"return index {i}");assert_eq!(ea,eb,"callback sequence index {i}");
  let after_a=a.encode();let after_b=b.encode();assert_eq!(after_a,after_b,"complete node/tree state");
  if ra<0{assert_eq!(ra,-14);assert_eq!(after_a,before_a,"overlap must not mutate any node/tree field");assert_eq!(ea.len(),1);assert_eq!(ea[0].0,3);}else{assert_eq!(ea.iter().map(|x|x.0).collect::<Vec<_>>(),vec![0,1,2]);}
  unsafe{a.verify_rb();b.verify_rb();}n+=1;
 }n
}
#[test]fn all_orders_and_overlaps_match_exact_c_and_selected_glue(){
 fn permute(order:&mut[usize],at:usize,total:&mut usize){if at==order.len(){
  let mut ranges:Vec<(u64,u64)>=(0..6).map(|i|(i*32,i*32+16)).collect();ranges.extend_from_slice(&[(0,16),(1,15),(0,192),(15,17),(16,32),(192,208),(8,40)]);
  let mut calls=order.to_vec();calls.extend(6..ranges.len());*total+=exercise(&ranges,&calls);return;}
  for i in at..order.len(){order.swap(i,at);permute(order,at+1,total);order.swap(i,at);}}
 let mut total=0;permute(&mut[0,1,2,3,4,5],0,&mut total);assert_eq!(total,9360);println!("exact C/Rust selected-glue insertion comparisons={total}; permutations=720");
}
#[test]fn original_unsigned_degenerate_interval_semantics_preserved(){
 let ranges=[(0,0),(0,1),(1,1),(1,2),(u64::MAX-16,u64::MAX-8),(u64::MAX-8,u64::MAX),(u64::MAX,u64::MAX),(7,3),(2,8),(u64::MAX-12,u64::MAX-4)];
 assert_eq!(exercise(&ranges,&(0..ranges.len()).collect::<Vec<_>>()),10);
}
#[test]fn missing_callbacks_refuse_before_pointer_access(){
 assert_eq!(size_of::<VmRangeNumaPolicy>(),80);assert_eq!(offset_of!(ProcessVm,vm_range_numa_policy_tree),248);
 unsafe extern "C" fn logger(_: *mut ProcessVm,_:*mut VmRangeNumaPolicy,_:*mut VmRangeNumaPolicy){panic!("callback must not run")}
 let cases=[(None,Some(fixture_rb_insert_color as SyscallPolicyRbInsertColorFn),Some(logger as SyscallPolicyInsertLogFn)),(Some(fixture_rb_link_node as SyscallPolicyRbLinkFn),None,Some(logger as SyscallPolicyInsertLogFn)),(Some(fixture_rb_link_node as SyscallPolicyRbLinkFn),Some(fixture_rb_insert_color as SyscallPolicyRbInsertColorFn),None)];
 for (a,b,c)in cases{assert_eq!(unsafe{syscall_vm_policy_insert_body_result(null_mut(),null_mut(),a,b,c)},-22);}
}
