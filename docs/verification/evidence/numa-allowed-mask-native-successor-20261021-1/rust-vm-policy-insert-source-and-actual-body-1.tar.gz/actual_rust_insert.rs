type SyscallPolicyRbLinkFn =
    unsafe extern "C" fn(*mut AbiRbNode, *mut AbiRbNode, *mut *mut AbiRbNode);
type SyscallPolicyRbInsertColorFn = unsafe extern "C" fn(*mut AbiRbNode, *mut AbiRbRoot);
type SyscallPolicyInsertLogFn =
    unsafe extern "C" fn(*mut ProcessVm, *mut VmRangeNumaPolicy, *mut VmRangeNumaPolicy);
#[no_mangle]
pub unsafe extern "C" fn syscall_vm_policy_insert_body_result(
    vm: *mut ProcessVm,
    newrange: *mut VmRangeNumaPolicy,
    link_fn: Option<SyscallPolicyRbLinkFn>,
    insert_color_fn: Option<SyscallPolicyRbInsertColorFn>,
    log_fn: Option<SyscallPolicyInsertLogFn>,
) -> CInt {
    let (Some(link), Some(insert_color), Some(log)) = (link_fn, insert_color_fn, log_fn) else {
        return -EINVAL;
    };
    let root = unsafe { addr_of_mut!((*vm).vm_range_numa_policy_tree) };
    let mut slot = unsafe { addr_of_mut!((*root).rb_node) };
    let mut parent = null_mut();
    while !unsafe { *slot }.is_null() {
        let node = unsafe { *slot };
        let range = unsafe {
            node.cast::<u8>()
                .sub(offset_of!(VmRangeNumaPolicy, policy_rb_node))
                .cast::<VmRangeNumaPolicy>()
        };
        parent = node;
        if unsafe { (*newrange).end <= (*range).start } {
            slot = unsafe { addr_of_mut!((*node).rb_left) };
        } else if unsafe { (*newrange).start >= (*range).end } {
            slot = unsafe { addr_of_mut!((*node).rb_right) };
        } else {
            unsafe { log(vm, newrange, range) };
            return -EFAULT;
        }
    }
    unsafe {
        log(vm, newrange, null_mut());
        let node = addr_of_mut!((*newrange).policy_rb_node);
        link(node, parent, slot);
        insert_color(node, root);
    }
    0
}
