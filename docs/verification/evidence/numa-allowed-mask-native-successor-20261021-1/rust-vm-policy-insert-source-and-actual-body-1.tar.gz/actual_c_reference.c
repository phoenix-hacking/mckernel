#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
#define EFAULT 14
struct rb_node { unsigned long parent_color; struct rb_node *rb_right, *rb_left; };
struct rb_root { struct rb_node *rb_node; };
struct vm_range_numa_policy { struct rb_node policy_rb_node; unsigned long start,end; unsigned long numa_mask[4]; int numa_mem_policy,il_prev; };
/* Existing production ABI assertions: root248, policy80, node24. Only root is accessed. */
struct process_vm { unsigned char prefix[248]; struct rb_root vm_range_numa_policy_tree; unsigned char tail[48]; };
_Static_assert(sizeof(struct rb_node)==24,"node ABI");
_Static_assert(sizeof(struct vm_range_numa_policy)==80,"policy ABI");
_Static_assert(offsetof(struct vm_range_numa_policy,numa_mask)==40,"mask ABI");
_Static_assert(offsetof(struct process_vm,vm_range_numa_policy_tree)==248,"root ABI");
extern void fixture_rb_link_node(struct rb_node *,struct rb_node *,struct rb_node **);
extern void fixture_rb_insert_color(struct rb_node *,struct rb_root *);
extern void fixture_log_fields(int,const char *,void *,unsigned long,unsigned long,unsigned long *,int,unsigned long,unsigned long,unsigned long *,int);
static void fixture_ekprintf(const char *format,...) {
 (void)format;va_list a;va_start(a,format);
 const char *label=va_arg(a,const char *);void *vm=va_arg(a,void *);
 unsigned long start=va_arg(a,unsigned long),end=va_arg(a,unsigned long);unsigned long *mask=va_arg(a,unsigned long *);int policy=va_arg(a,int);
 unsigned long os=va_arg(a,unsigned long),oe=va_arg(a,unsigned long);unsigned long *om=va_arg(a,unsigned long *);int op=va_arg(a,int);va_end(a);
 fixture_log_fields(1,label,vm,start,end,mask,policy,os,oe,om,op);
}
static void fixture_dkprintf(const char *format,...) {
 (void)format;va_list a;va_start(a,format);
 const char *label=va_arg(a,const char *);void *vm=va_arg(a,void *);(void)va_arg(a,void *);
 unsigned long start=va_arg(a,unsigned long),end=va_arg(a,unsigned long);unsigned long *mask=va_arg(a,unsigned long *);int policy=va_arg(a,int);va_end(a);
 fixture_log_fields(0,label,vm,start,end,mask,policy,0,0,NULL,0);
}
#define ekprintf fixture_ekprintf
#define dkprintf fixture_dkprintf
#define rb_link_node fixture_rb_link_node
#define rb_insert_color fixture_rb_insert_color
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
extern int syscall_vm_policy_insert_body_result(struct process_vm *vm,
		struct vm_range_numa_policy *newrange,
		void (*link)(struct rb_node *, struct rb_node *, struct rb_node **),
		void (*insert_color)(struct rb_node *, struct rb_root *),
		void (*log)(struct process_vm *, struct vm_range_numa_policy *,
			struct vm_range_numa_policy *));

static void syscall_vm_policy_link_bridge(struct rb_node *node,
		struct rb_node *parent, struct rb_node **link)
{
	rb_link_node(node, parent, link);
}

static void syscall_vm_policy_color_bridge(struct rb_node *node,
		struct rb_root *root)
{
	rb_insert_color(node, root);
}

static void syscall_vm_policy_insert_log_bridge(struct process_vm *vm,
		struct vm_range_numa_policy *newrange,
		struct vm_range_numa_policy *overlap)
{
	if (overlap) {
		ekprintf("%s(%p,%lx-%lx (nodemask)%lx (policy)%d): overlap %lx-%lx (nodemask)%lx (policy)%d\n",
				"vm_policy_insert", vm, newrange->start,
				newrange->end, newrange->numa_mask,
				newrange->numa_mem_policy, overlap->start,
				overlap->end, overlap->numa_mask,
				overlap->numa_mem_policy);
	} else {
		dkprintf("%s: %p,%p: %lx-%lx (nodemask)%lx (policy)%d\n",
				"vm_policy_insert", vm, newrange, newrange->start,
				newrange->end, newrange->numa_mask,
				newrange->numa_mem_policy);
	}
}
#endif

static int vm_policy_insert(struct process_vm *vm,
		struct vm_range_numa_policy *newrange)
{
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
	return syscall_vm_policy_insert_body_result(vm, newrange,
			syscall_vm_policy_link_bridge, syscall_vm_policy_color_bridge,
			syscall_vm_policy_insert_log_bridge);
#else
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct rb_node **new = &(root->rb_node), *parent = NULL;
	struct vm_range_numa_policy *range;

	while (*new) {
		range = ((struct vm_range_numa_policy *)((char *)(*new) - offsetof(struct vm_range_numa_policy, policy_rb_node)));
		parent = *new;
		if (newrange->end <= range->start) {
			new = &((*new)->rb_left);
		} else if (newrange->start >= range->end) {
			new = &((*new)->rb_right);
		} else {
			ekprintf("%s(%p,%lx-%lx (nodemask)%lx (policy)%d): overlap %lx-%lx (nodemask)%lx (policy)%d\n",
					__func__, vm, newrange->start,
					newrange->end, newrange->numa_mask,
					newrange->numa_mem_policy, range->start,
					range->end, range->numa_mask,
					range->numa_mem_policy);
			return -EFAULT;
		}
	}

	dkprintf("%s: %p,%p: %lx-%lx (nodemask)%lx (policy)%d\n",
			__func__, vm, newrange, newrange->start, newrange->end,
			newrange->numa_mask, newrange->numa_mem_policy);

	rb_link_node(&newrange->policy_rb_node, parent, new);
	rb_insert_color(&newrange->policy_rb_node, root);

	return 0;
#endif
}

int fixture_insert_reference(struct process_vm *vm,struct vm_range_numa_policy *node){return vm_policy_insert(vm,node);}
