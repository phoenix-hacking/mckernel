Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

PureDATA readiness. Original activeprivate25e and release094 remain immutable.
CORRECTED-SAME-RELEASE-DATA-NOT-RELEASED.json changes only authority status/review
fields, script5f67, genuine6981commit/tree6ef71/fetched/source_review8dd, and the one
engine observation.selected_files row64. All other observation fields/rows remain
exactly original. Row64 path/hash/size are fixed; six actualidentity fields remain
null until root actualactivation/copy FDmetadata. Do not copy old25e inode or use
privateproposed metadata as actualactivatedidentity. This is9key observe_identity,
not mtime/ctime preservation. Executionreview stays null; draftNOT_RELEASED.

ADDITIVE-CURRENT-CONSUMER-FIELD-JOIN.json binds actual07b7 publication and private
canonical engine5f67/postjoin245/body602/newretained7d source map,8dd actual15case
bodyreview and separated3a9 conditionalretainedcallerreview. Original SOURCE-PINS
and rawfailed094 source/identity remain historical immutable authority. Newsource
join is additive. Oldfresh725 and correctedfreshb7c are parkedunused.

SAME-RELEASE-THREE-OPERATION-FIELD-MATRIX.json provides exact argv fields/profiles
for retained7d --release/--sha256, engine --release/--release-sha256/--execute and
postjoin245 positionalrelease/hash/result. All bind one future finalrelease2 path
and actualfileSHA, with freshpreflight1/cleanup2/postjoin2 captures and exactbyte
O_EXCL cleanupresult2 only after positivejoinedcleanup. Result/plan uses separate
canonicalJSON NO-LF releaseSHA; no positionalhash duplication. Originalfiles and
operations1 remain unchanged.

Preflight captures reuse qualifieda6ce inline tail with CPU7/2GiB/32MiB/unlimitedCPU/
noouterkill. Do not send preflight role to eff9 which accepts onlycleanup/postjoin.
Critical cleanup/postjoin retain eff9 with 128MiB streams and originalprofiles.
Transport0 is not predicatePASS: require exact retained7d positive result and all
existingmutex116297/zeroevents/no-mutation/realcontainer/log/census/protectedchecks.
No observer/raw5/materializer/fixtures replay or newframework/gate is proposed.

Root still must bind acceptedactualarchive, actualactivation9keyidentity/current
consumerrefs and exactindependent SAMEfinal execution review before anyeffects.
Stablemonitor2590193/start37928121 is acknowledgedcontext, not a new census or
operationalauthority. Worker performed no imports/tests/root/Git/execution/effects.
