#!/usr/bin/env python3
"""Read exactly two known root retirement receipts; no effects or census.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
"""
import base64,hashlib,json,os,stat
from pathlib import Path
BASE=Path('/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/next-reconciliation-preparation-1/quarantine-archive-source-1/actual-root-archive-1')
COMPLETE_SHA = None
EXPECTED_ACTOR = None
PROFILE = {'absent_paths': ['/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.plan.json', '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.journal.jsonl', '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.docker-logs.capture', '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-image-successor-preparation-20261021-1/full-image-attempt-1/numa-allowed-mask-image-terminal-20261021-1.attempt.archive', '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.shared.archive'], 'boot_id': '7bfc5687-6c04-4d15-84eb-b92ab9a55dcb', 'complete_sha256': 'db6926c8b12cc70aa8b35289048043ddb5ad8eb8da973b51447743c10633af08', 'destination': '/home/holden/mckernel-work/scratch/numa-allowed-mask-preplan-quarantine-archive-20261021-1.json', 'effect_count': 1, 'ending_scope': 'Quarantine-only archival; preserve0Bmutex/permanentrootlock/common/shared/oldsource25e/release094. No cleanup/engine/validation/runtime authority.', 'evidence_directory': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/next-reconciliation-preparation-1/quarantine-archive-source-1/actual-root-archive-1', 'mutex': {'full9': {'ctime_ns': 1792579403434141547, 'device': 1828, 'gid': 1000, 'inode': 116297, 'mode': 33152, 'mtime_ns': 1792579403434141547, 'nlink': 1, 'size': 0, 'uid': 1000}, 'path': '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.mutex', 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, 'old_holder': {'pid': 2575750, 'starttime': '37684618'}, 'old_outer': {'pid': 2575747, 'starttime': '37684611'}, 'original_critical_closed_status': {'bytes': 1982, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/bound-terminal-source-1/actual-cleanup-capture-1/status.json', 'sha256': '0868e537412c07f36b764e54dc810ccbc759f48a758b4732724c897efd02306c'}, 'prepared_sha256': '8921069ffcbe63fd0df54a37b0d6b97c8306bf92998a5a8977554e4c4adaf914', 'quarantine': {'full9': {'ctime_ns': 1792579403770152194, 'device': 1828, 'gid': 1000, 'inode': 116298, 'mode': 33152, 'mtime_ns': 1792579403770152194, 'nlink': 1, 'size': 990, 'uid': 1000}, 'path': '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.quarantine.json', 'sha256': 'bc4b8856039eb827a9de0c797e740214133bb9549c6b9009ad6fa8c141db2f2d'}, 'retirement_actual_acceptance': {'bytes': 5049, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/cleanup-quarantine-recovery-preparation-2/independent-review-1/ACTUAL-IDLE-HOLDER-RETIREMENT-ACCEPTANCE-1.json', 'sha256': 'f86c26e558875ab408d04db3926dd31a13d73e970bb8c8783743892a4c5908db'}, 'retirement_export': {'bytes': 10588, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/next-reconciliation-preparation-1/actual-two-receipt-read-capture-1/stdout', 'sha256': '3d9e53a39656bb9b57871d3684f946a551afb3ba30eff4aa770517f41409a8e3'}, 'root_lock': {'device': 27, 'gid': 0, 'inode': 4, 'path': '/run/lock/mckernel-development.lock', 'uid': 0}, 'schema': 'mckernel.exact-retired-quarantine-archive-profile.v1', 'scope': 'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.', 'scratch_uuid': '2a5768c8-718d-4914-bdc0-6b32c5a92a52', 'unchanged_regulars': [{'full9': {'ctime_ns': 1792579403434141547, 'device': 1828, 'gid': 1000, 'inode': 116297, 'mode': 33152, 'mtime_ns': 1792579403434141547, 'nlink': 1, 'size': 0, 'uid': 1000}, 'path': '/home/holden/mckernel-work/scratch/numa-allowed-mask-image-terminal-20261021-1.mutex', 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, {'full9': {'ctime_ns': 1792576213124736447, 'device': 66306, 'gid': 1000, 'inode': 48508883, 'mode': 33152, 'mtime_ns': 1792576213124736447, 'nlink': 1, 'size': 272, 'uid': 1000}, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-image-successor-preparation-20261021-1/full-image-attempt-1/common-exclusion.json', 'sha256': 'be1ffc4b4108c03154eb7c3355f361ec9f669a41e82abc9d50159677defd3a46'}, {'full9': {'ctime_ns': 1792576146482595706, 'device': 1828, 'gid': 1000, 'inode': 116289, 'mode': 33152, 'mtime_ns': 1792576146482595706, 'nlink': 1, 'size': 269, 'uid': 1000}, 'path': '/home/holden/mckernel-work/scratch/mckernel-heavy-operation.lock', 'sha256': '3a8fc0745fffcb2c54625f45b29dd66e81657216138185a3fe603fa499e6935d'}, {'full9': {'ctime_ns': 1792579265597773510, 'device': 66306, 'gid': 1000, 'inode': 48510007, 'mode': 33152, 'mtime_ns': 1792579265597773510, 'nlink': 1, 'size': 256040, 'uid': 1000}, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/bound-terminal-source-1/cleanup-execution-release.json', 'sha256': '094234f95e6cd826adc0a66bd44e3807842a141362c94cf7c882a624c5b866dd'}, {'full9': {'ctime_ns': 1792577299579279746, 'device': 66306, 'gid': 1000, 'inode': 48509551, 'mode': 33152, 'mtime_ns': 1792577299579279746, 'nlink': 1, 'size': 88292, 'uid': 1000}, 'path': '/home/holden/mckernel-work/host-preparation/numa-allowed-mask-native-successor-preparation-20261021-1/bound-terminal-source-1/cleanup_pass_image.py', 'sha256': '25e8657a301c6d486833de7bf8f6cdd7ebc360d9930a997809b3089b16551633'}]}
CAP=1<<20

def full9(s):return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,nlink=s.st_nlink,uid=s.st_uid,gid=s.st_gid,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def need(ok,why):
 if not ok:raise RuntimeError(why)
def directory(path):
 fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  for part in path.parts[1:]:
   child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=child
  return fd
 except BaseException:os.close(fd);raise

def snapshot(parent,name,expected):
 fd=None;row=dict(path=str(BASE/name))
 try:
  before=full9(os.stat(name,dir_fd=parent,follow_symlinks=False));fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=parent);first=full9(os.fstat(fd))
  row.update(named_before=before,fd_before=first)
  need(stat.S_ISREG(first['mode']) and first['uid']==first['gid']==0 and first['nlink']==1 and stat.S_IMODE(first['mode'])==0o600 and before==first,'exact root regular/full9 shape')
  parts=[];count=0
  while True:
   block=os.read(fd,min(65536,CAP+1-count))
   if not block:break
   count+=len(block);need(count<=CAP,'receipt exceeds1MiB');parts.append(block)
  raw=b''.join(parts);h=hashlib.sha256(raw).hexdigest();row.update(bytes=len(raw),sha256=h,raw_base64=base64.b64encode(raw).decode(),raw_complete=True)
  row['fd_after']=full9(os.fstat(fd));row['named_after']=full9(os.stat(name,dir_fd=parent,follow_symlinks=False));row['stable_full9']=row['named_before']==row['fd_before']==row['fd_after']==row['named_after']
  need(row['stable_full9'] and h==expected,'receipt exacthash/full9 drift')
  value=json.loads(raw);row['parsed_json']=value;row['status']='PASS_EXACT_ROOT_RECEIPT_READ_ONLY';return row,value
 except BaseException as exc:
  row['status']='REFUSED_READ_ONLY';row['error']=dict(type=type(exc).__name__,errno=getattr(exc,'errno',None),message=str(exc)[:1024]);return row,None
 finally:
  if fd is not None:os.close(fd)

def main():
 need(os.getuid()==os.geteuid()==0,'released root readonly invocation required')
 need(type(COMPLETE_SHA) is str and len(COMPLETE_SHA)==64 and all(x in '0123456789abcdef' for x in COMPLETE_SHA),'actual future complete SHA remains pending')
 need(type(EXPECTED_ACTOR) is dict and set(EXPECTED_ACTOR)=={'pid','starttime','uid','gid','pgrp','boot_id'},'actual root actor birth remains pending')
 need(type(EXPECTED_ACTOR['pid']) is int and EXPECTED_ACTOR['pid']>0 and type(EXPECTED_ACTOR['pgrp']) is int and EXPECTED_ACTOR['pgrp']>0 and type(EXPECTED_ACTOR['starttime']) is str and EXPECTED_ACTOR['starttime'].isdigit() and EXPECTED_ACTOR['uid']==EXPECTED_ACTOR['gid']==0 and EXPECTED_ACTOR['boot_id']==PROFILE['boot_id'],'actual root actor type/boot scope')
 fd=directory(BASE)
 try:
  parent=full9(os.fstat(fd));need(parent['uid']==parent['gid']==0 and stat.S_IMODE(parent['mode'])==0o700,'root0700 receipt directory')
  complete,c=snapshot(fd,'complete.json',COMPLETE_SHA);prepared=None;p=None
  if c is not None:
   need(c.get('status')=='COMPLETE_QUARANTINE_ONLY_ARCHIVAL' and c.get('actor')==EXPECTED_ACTOR,'current complete archive/root actor scope')
   need(type(c.get('prepared_sha256')) is str and len(c['prepared_sha256'])==64 and all(x in '0123456789abcdef' for x in c['prepared_sha256']),'exact second-file hash required')
   prepared,p=snapshot(fd,'prepared.json',c['prepared_sha256'])
   if p is not None:
    need(p.get('status')=='PREPARED_QUARANTINE_ONLY_ARCHIVAL' and p.get('actor')==c['actor']==EXPECTED_ACTOR,'prepared/current root actor birth pair')
    need(p.get('release_sha256')==c.get('release_sha256') and type(c.get('release_sha256')) is str and len(c['release_sha256'])==64 and all(x in '0123456789abcdef' for x in c['release_sha256']),'same actual archive release')
    need(p.get('source')==PROFILE['quarantine'] and p.get('destination')==PROFILE['destination'] and p.get('effect_budget')==1 and p.get('cleanup_authorized') is False,'exact prepared one archival/source/destination')
    need(p.get('preserved')==PROFILE['unchanged_regulars'],'complete exact protected/mutex original identities')
    archived=c.get('archived');need(type(archived) is dict and set(archived)=={'path','full9','sha256'} and archived['path']==PROFILE['destination'] and archived['sha256']==PROFILE['quarantine']['sha256'],'exact archive destination/hash')
    original=PROFILE['quarantine']['full9'];actual=archived['full9']
    need(set(actual)==set(original) and all(actual[key]==original[key] for key in original if key!='ctime_ns') and type(actual['ctime_ns']) is int,'archive full9 retained inode/bytes; rename ctime only')
    need(actual['inode']==116298 and actual['size']==990 and archived['sha256']=='bc4b8856039eb827a9de0c797e740214133bb9549c6b9009ad6fa8c141db2f2d','exact original quarantine990B inode/hash')
    need(c.get('rename_count')==1 and c.get('rename_flags')==1 and c.get('original_name_absent') is True and c.get('mutex_preserved')==PROFILE['mutex'] and c['mutex_preserved']['full9']['inode']==116297 and c.get('protected_inputs_unchanged') is True and c.get('root_lock_identity')==[27,4],'exact single NOREPLACE archive/preserved mutex/protected/rootlock findings')
    need(c.get('cleanup_authorized') is False and c.get('retained_mutex_preflight_accepted') is False,'no cleanup/retained preflight authority')
  print(json.dumps(dict(schema='mckernel.exact-two-root-quarantine-archive-receipt-export.v1',status='PASS_READ_ONLY_TWO_ARCHIVE_RECEIPTS' if c is not None and p is not None else 'REFUSED_READ_ONLY',directory=parent,complete=complete,prepared=prepared,root_lock_acquired=False,signals_sent=False,mutation=False,census=False,cleanup_authority=False,retained_mutex_preflight_accepted=False),sort_keys=True))
 finally:os.close(fd)
if __name__=='__main__':main()
