"""Only actual strict static_joins; no root/live snapshot or workload."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,socket,subprocess
p=argparse.ArgumentParser(allow_abbrev=False)
for k in ('snapshot-source','snapshot-sha256','bindings','bindings-sha256'):p.add_argument('--'+k,required=True)
a=p.parse_args()
def checked(p,h):
 raw=Path(p).read_bytes();assert hashlib.sha256(raw).hexdigest()==h;return raw
b=json.loads(checked(a.bindings,a.bindings_sha256));checked(a.snapshot_source,a.snapshot_sha256)
def forbidden(*args,**kwargs):raise AssertionError('no process/socket/root effect in static comparison')
subprocess.Popen=forbidden;os.execve=forbidden;socket.socket=forbidden
spec=importlib.util.spec_from_file_location('actual_strict_snapshot_body',a.snapshot_source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.static_joins(b)
print(json.dumps(dict(status='PASS_ACTUAL_STRICT_STATIC_JOINS_BODY_ONLY',root_operations=0,guest_runs=0)))
