struct vm_range_numa_policy *vm_range_policy_search(struct process_vm *vm, uintptr_t addr)
{
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
	return syscall_vm_range_policy_search_body_result(vm, addr);
#else
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct rb_node *node = root->rb_node;
	struct vm_range_numa_policy *numa_policy = NULL;

	while (node) {
		numa_policy = ((struct vm_range_numa_policy *)((char *)(node) - offsetof(struct vm_range_numa_policy, policy_rb_node)));
		if (addr < numa_policy->start) {
			node = node->rb_left;
		} else if (addr >= numa_policy->end) {
			node = node->rb_right;
		} else {
			return numa_policy;
		}
	}

	return NULL;
#endif
}
