pub unsafe extern "C" fn syscall_vm_range_policy_search_body_result(
    vm: *mut ProcessVm,
    addr: CULong,
) -> *mut VmRangeNumaPolicy {
    let mut node = unsafe { (*vm).vm_range_numa_policy_tree.rb_node };
    while !node.is_null() {
        let policy = unsafe {
            node.cast::<u8>()
                .sub(offset_of!(VmRangeNumaPolicy, policy_rb_node))
                .cast::<VmRangeNumaPolicy>()
        };
        if addr < unsafe { (*policy).start } {
            node = unsafe { (*node).rb_left };
        } else if addr >= unsafe { (*policy).end } {
            node = unsafe { (*node).rb_right };
        } else {
            return policy;
        }
    }
    null_mut()
}
