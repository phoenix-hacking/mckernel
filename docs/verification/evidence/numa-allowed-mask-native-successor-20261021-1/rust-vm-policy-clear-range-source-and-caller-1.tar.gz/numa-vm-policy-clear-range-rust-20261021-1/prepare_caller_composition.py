from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
R=Path('/home/holden/mckernel')
old=(D/'clear_range.rs').read_text()
p=old.index('/// Safety:');q=old.index('#[no_mangle]',p)
contract='''/// Safety: start < end; the caller holds the existing exclusive VM policy-tree
/// lock and supplies a valid, disjoint half-open-range tree. vm and linked
/// policies have checked C layouts and remain live until the erase/free callback.
/// Every callback preserves that lock/lifetime contract. policy_size is at least
/// size_of::<VmRangeNumaPolicy>(); successful allocation returns a fresh, aligned,
/// writable allocation of at least that size, nonaliasing vm or any live policy.
/// The existing insertion callback publishes the original allocation only on
/// success (return 0); on error it leaves the allocation unpublished and does not
/// consume or free it. The current valid-range/disjoint-tree caller makes that
/// insertion-error branch unreachable. As in C, allocation failure retains the
/// already-truncated leading range; no rollback is performed. No Rust references
/// are retained across callbacks. Do not call this body with empty, reversed or
/// wrapped ranges: inherited C behavior outside this contract includes an
/// unpublished, unfreed tail after insertion rejection.
'''
(D/'clear_range_contract_v2.rs').write_text(old[:p]+contract+old[q:])
s=(R/'kernel/rust/syscall_policy.rs').read_text()
def function(marker):
 p=s.index(marker); start=s.index('{',p); depth=1;i=start+1
 while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[p:i]+'\n'
markers=['pub unsafe extern "C" fn mbind_prepare_range(', 'pub unsafe extern "C" fn mempolicy_nodemask_bits_result(', 'pub extern "C" fn mempolicy_nodemask_bits_is_clamped(', 'pub unsafe extern "C" fn mbind_mode_flags_result(', 'pub extern "C" fn mempolicy_mode_is_supported(', 'unsafe fn policy_mask_zero(', 'unsafe fn policy_mask_set(', 'unsafe fn policy_mask_test(', 'unsafe fn policy_mask_empty(', 'unsafe fn policy_mask_set_all_nodes(', 'unsafe fn mbind_log(', 'unsafe fn policy_mask_copy_words(', 'pub unsafe extern "C" fn mbind_body_result(']
chunks=[]
for marker in markers:chunks.append(function(marker))
# Exact existing constants used by the unchanged actual mbind body and helpers.
constants='\n'.join(line for line in s.splitlines() if line.startswith('const MPOL_') or line.startswith('const MBIND_LOG_') or line.startswith('const PROCESS_NUMA_MASK_BITS:') or line.startswith('const PAGE_SIZE:') or line.startswith('const PAGE_MASK:'))+'\n'
(D/'actual_mbind_body_and_dependencies.rs').write_text(constants+'\n'.join(chunks))
# Reuse the accepted observer and actual RB/C objects; execute ONLY new exact test.
base=(D/'actual_body_tests.rs').read_text().replace('include!("clear_range.rs");','include!("clear_range_contract_v2.rs");')
base=base.replace('fn event(&mut self,kind:u8,args:Vec<u64>){','fn event(&mut self,kind:u8,args:Vec<u64>){if COMPOSITION_ACTIVE.with(|c|c.get()){assert!(LOCK_HELD.with(|c|c.get()),"policy callback outside writer lock");}')
(D/'caller_composition_tests.rs').write_text(base+'\n'+(D/'caller_composition_addition.rs').read_text())
inputs=[D/n for n in ['clear_range_contract_v2.rs','actual_mbind_body_and_dependencies.rs','caller_composition_tests.rs','caller_composition_addition.rs','prepare_caller_composition.py','run_caller_composition.py','actual_rust_search.rs','actual_rust_insert.rs','c-reference-1.o','c-selected-1.o']]+[R/'kernel/rust/abi.rs',R/'kernel/rust/rbtree.rs']
record={'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','candidate_executed':False,'previous_freeze_sha256':hashlib.sha256((D/'SOURCE-FREEZE.json').read_bytes()).hexdigest(),'accepted_parity_result_sha256':hashlib.sha256((D/'actual-body-result-1.json').read_bytes()).hexdigest(),'contract_only_correction':True,'code_body_unchanged':old[old.index('#[no_mangle]'):]==(D/'clear_range_contract_v2.rs').read_text().split('#[no_mangle]',1)[1].join(['#[no_mangle]','']),'exact_new_test':'current_mbind_caller_range_validation_and_writer_locked_split','old_parity_tests_replayed':False,'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in inputs],'command':['/home/holden/anaconda3/bin/python3.9','-I','-B',str(D/'run_caller_composition.py')],'failure_history':[],'production_link_native_acceptance':False}
assert record['code_body_unchanged']
(D/'CALLER-COMPOSITION-SOURCE-FREEZE-2.json').write_text(json.dumps(record,indent=2)+'\n')
print(hashlib.sha256((D/'CALLER-COMPOSITION-SOURCE-FREEZE-2.json').read_bytes()).hexdigest())
