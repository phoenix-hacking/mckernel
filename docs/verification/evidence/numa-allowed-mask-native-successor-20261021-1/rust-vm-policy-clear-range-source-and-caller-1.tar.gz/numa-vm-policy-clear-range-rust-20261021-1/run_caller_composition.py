"""Fresh grant only: one Rust compile and one exact new caller-composition test."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
D=Path(__file__).resolve().parent
binding=json.loads((D/'CALLER-COMPOSITION-SOURCE-FREEZE-2.json').read_bytes())
for row in binding['inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert os.sched_getaffinity(0)=={6}
cc='/usr/bin/cc';rustc='/home/holden/.rustup/toolchains/1.85.1-x86_64-unknown-linux-gnu/bin/rustc'
commands=[('caller-composition-compile-2',[rustc,'--edition=2021','--test','-C','codegen-units=1','-C','debuginfo=0','-C','linker='+cc,'-C','link-arg=c-reference-1.o','-C','link-arg=c-selected-1.o','caller_composition_tests.rs','-o','caller-composition-tests-2']),('caller-composition-test-2',[str(D/'caller-composition-tests-2'),'--exact','current_mbind_caller_range_validation_and_writer_locked_split','--test-threads=1','--nocapture'])]
records=[]
for name,argv in commands:
 start=time.monotonic()
 with (D/(name+'.stdout')).open('xb')as out,(D/(name+'.stderr')).open('xb')as err:
  p=subprocess.Popen(argv,cwd=D,stdout=out,stderr=err,start_new_session=True)
  timed_out=False
  try:rc=p.wait(timeout=35)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 try:os.killpg(p.pid,0);absent=False
 except ProcessLookupError:absent=True
 row=dict(name=name,argv=argv,pid=p.pid,returncode=rc,direct_child_joined=True,group_absent=absent,timed_out=timed_out,seconds=time.monotonic()-start)
 for suffix in ('stdout','stderr'):
  path=D/(name+'.'+suffix);raw=path.read_bytes();row[suffix]=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 records.append(row);print(json.dumps(row),flush=True)
 if rc!=0 or not absent:break
result=dict(scope=binding['scope'],status='PASS_ACTUAL_MBIND_CALLER_COMPOSITION_ONLY'if len(records)==2 and all(r['returncode']==0 and r['group_absent']for r in records)else'FAIL_PRESERVED_NO_RETRY',records=records,old_parity_tests_replayed=False,root_operations=0,guest_runs=0,default_link_native_acceptance=False)
with (D/'caller-composition-result-2.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
raise SystemExit(0 if result['status'].startswith('PASS_')else 1)
