const PAGE_SIZE: CULong = 1 << 12;
const PAGE_MASK: CULong = !(PAGE_SIZE - 1);
const PROCESS_NUMA_MASK_BITS: CULong = 256;
const MPOL_DEFAULT: CInt = 0;
const MPOL_PREFERRED: CInt = 1;
const MPOL_BIND: CInt = 2;
const MPOL_INTERLEAVE: CInt = 3;
const MPOL_F_STATIC_NODES: CInt = 1 << 15;
const MPOL_F_RELATIVE_NODES: CInt = 1 << 14;
const MPOL_MODE_FLAGS: CInt = MPOL_F_STATIC_NODES | MPOL_F_RELATIVE_NODES;
const MPOL_F_NODE: CInt = 1 << 0;
const MPOL_F_ADDR: CInt = 1 << 1;
const MPOL_F_MEMS_ALLOWED: CInt = 1 << 2;
const MPOL_MF_STRICT: CInt = 1 << 0;
const MPOL_MF_MOVE: CInt = 1 << 1;
const MPOL_MF_MOVE_ALL: CInt = 1 << 2;
const MBIND_LOG_NODEMASK_BITS_TOO_BIG: CInt = 2;
const MBIND_LOG_CLAMPED: CInt = 3;
const MBIND_LOG_INVALID_MODE_FLAGS: CInt = 4;
const MBIND_LOG_COPY_FROM_NUMA_MASK: CInt = 5;
const MBIND_LOG_DEFAULT_MASK_NOT_EMPTY: CInt = 6;
const MBIND_LOG_NODEMASK_NOT_SPECIFIED: CInt = 7;
const MBIND_LOG_NODE_TOO_LARGE: CInt = 8;
const MBIND_LOG_INVALID_RANGE: CInt = 9;
const MBIND_LOG_CLEAR_POLICY_RANGE: CInt = 10;
const MBIND_LOG_ALLOC_POLICY: CInt = 11;
const MBIND_LOG_INSERT_POLICY: CInt = 12;
pub unsafe extern "C" fn mbind_prepare_range(
    addr: CULong,
    len0: CULong,
    lenp: *mut CULong,
) -> CInt {
    let len = len0.wrapping_add(PAGE_SIZE - 1) & PAGE_MASK;
    write(lenp, len);

    if (addr & (PAGE_SIZE - 1)) != 0
        || addr.wrapping_add(len) < addr
        || addr == addr.wrapping_add(len)
    {
        return -EINVAL;
    }

    0
}

pub unsafe extern "C" fn mempolicy_nodemask_bits_result(
    maxnode: CULong,
    nodemask_bitsp: *mut CULong,
) -> CInt {
    let mut nodemask_bits = if maxnode != 0 {
        maxnode.wrapping_add(7) & !7
    } else {
        0
    };

    if maxnode > (PAGE_SIZE << 3) {
        write(nodemask_bitsp, nodemask_bits);
        return -EINVAL;
    }

    if nodemask_bits > PROCESS_NUMA_MASK_BITS {
        nodemask_bits = PROCESS_NUMA_MASK_BITS;
    }

    write(nodemask_bitsp, nodemask_bits);
    0
}

pub extern "C" fn mempolicy_nodemask_bits_is_clamped(maxnode: CULong) -> CInt {
    if maxnode != 0 && ((maxnode.wrapping_add(7) & !7) > PROCESS_NUMA_MASK_BITS) {
        1
    } else {
        0
    }
}

pub unsafe extern "C" fn mbind_mode_flags_result(
    mode: CInt,
    flags: CInt,
    mode_flagsp: *mut CInt,
    normalized_modep: *mut CInt,
) -> CInt {
    if (mode & MPOL_F_STATIC_NODES) != 0 && (mode & MPOL_F_RELATIVE_NODES) != 0 {
        return -EINVAL;
    }

    if (flags & MPOL_MF_STRICT) != 0 && (flags & MPOL_MF_MOVE) != 0 {
        return -EINVAL;
    }

    let mode_flags = mode & MPOL_MODE_FLAGS;
    let normalized_mode = mode & !MPOL_MODE_FLAGS;
    write(mode_flagsp, mode_flags);
    write(normalized_modep, normalized_mode);

    if (mode_flags & MPOL_F_RELATIVE_NODES) != 0 {
        return -EINVAL;
    }

    0
}

pub extern "C" fn mempolicy_mode_is_supported(mode: CInt) -> CInt {
    if mode == MPOL_DEFAULT
        || mode == MPOL_BIND
        || mode == MPOL_INTERLEAVE
        || mode == MPOL_PREFERRED
    {
        1
    } else {
        0
    }
}

unsafe fn policy_mask_zero(mask: *mut CULong) {
    let mut word = 0usize;
    while word < PROCESS_NUMA_MASK_WORDS {
        write_volatile(mask.add(word), 0);
        word += 1;
    }
}

unsafe fn policy_mask_set(mask: *mut CULong, bit: CInt) {
    if bit < 0 || bit as CULong >= PROCESS_NUMA_MASK_BITS {
        return;
    }
    let shift = (bit as usize) % (size_of::<CULong>() * 8);
    let word = (bit as usize) / (size_of::<CULong>() * 8);
    let value = read_volatile(mask.add(word)) | ((1 as CULong) << shift);
    write_volatile(mask.add(word), value);
}

unsafe fn policy_mask_test(mask: *const CULong, bit: CInt) -> bool {
    if bit < 0 || bit as CULong >= PROCESS_NUMA_MASK_BITS {
        return false;
    }
    let shift = (bit as usize) % (size_of::<CULong>() * 8);
    let word = (bit as usize) / (size_of::<CULong>() * 8);
    (read_volatile(mask.add(word)) & ((1 as CULong) << shift)) != 0
}

unsafe fn policy_mask_empty(mask: *const CULong, bits: CULong) -> bool {
    let limit = if bits > PROCESS_NUMA_MASK_BITS {
        PROCESS_NUMA_MASK_BITS
    } else {
        bits
    };
    let mut bit = 0 as CULong;
    while bit < limit {
        if policy_mask_test(mask, bit as CInt) {
            return false;
        }
        bit += 1;
    }
    true
}

unsafe fn policy_mask_set_all_nodes(mask: *mut CULong, nr_numa_nodes: CInt) {
    policy_mask_zero(mask);
    let mut bit = 0;
    while bit < nr_numa_nodes && (bit as CULong) < PROCESS_NUMA_MASK_BITS {
        policy_mask_set(mask, bit);
        bit += 1;
    }
}

unsafe fn mbind_log(
    log_fn: Option<SyscallMbindLogFn>,
    event: CInt,
    arg0: CULong,
    arg1: CULong,
    arg2: CInt,
) {
    if let Some(log) = log_fn {
        log(event, arg0, arg1, arg2);
    }
}

unsafe fn policy_mask_copy_words(dst: *mut CULong, src: *const CULong) {
    let mut word = 0usize;
    while word < PROCESS_NUMA_MASK_WORDS {
        let value = read_volatile(src.add(word));
        write_volatile(dst.add(word), value);
        word += 1;
    }
}

pub unsafe extern "C" fn mbind_body_result(
    addr: CULong,
    len0: CULong,
    mode: CInt,
    nodemask_addr: CULong,
    maxnode: CULong,
    flags: CInt,
    vm: *mut ProcessVm,
    straight_va: CInt,
    fugaku_hacks: CInt,
    nr_numa_nodes: CInt,
    policy_size: SizeT,
    alloc_flags: CULong,
    copy_from_fn: Option<SyscallCopyFromUserFn>,
    write_lock_fn: Option<SyscallRwlockFn>,
    write_unlock_fn: Option<SyscallRwlockFn>,
    lookup_range_fn: Option<SyscallLookupRangeFn>,
    policy_search_fn: Option<SyscallPolicySearchFn>,
    clear_range_fn: Option<SyscallPolicyClearRangeFn>,
    alloc_fn: Option<SyscallPolicyAllocFn>,
    rb_clear_fn: Option<SyscallPolicyRbClearFn>,
    insert_fn: Option<SyscallPolicyInsertFn>,
    log_fn: Option<SyscallMbindLogFn>,
) -> CLong {
    if straight_va != 0 {
        return 0;
    }
    if vm.is_null() {
        return -(EFAULT as CLong);
    }

    let mut len = len0;
    let error = mbind_prepare_range(addr, len0, &mut len);
    if error != 0 {
        return error as CLong;
    }

    if fugaku_hacks != 0 {
        return 0;
    }

    let mut numa_mask = [0 as CULong; PROCESS_NUMA_MASK_WORDS];
    policy_mask_zero(numa_mask.as_mut_ptr());

    let mut nodemask_bits: CULong = 0;
    let error = mempolicy_nodemask_bits_result(maxnode, &mut nodemask_bits);
    if error != 0 {
        mbind_log(
            log_fn,
            MBIND_LOG_NODEMASK_BITS_TOO_BIG,
            addr,
            maxnode,
            error,
        );
        return error as CLong;
    }
    if mempolicy_nodemask_bits_is_clamped(maxnode) != 0 {
        mbind_log(log_fn, MBIND_LOG_CLAMPED, addr, maxnode, 0);
    }

    let mut mode_flags = 0;
    let mut normalized_mode = mode;
    let error = mbind_mode_flags_result(mode, flags, &mut mode_flags, &mut normalized_mode);
    if error != 0 {
        mbind_log(
            log_fn,
            MBIND_LOG_INVALID_MODE_FLAGS,
            addr,
            flags as CULong,
            error,
        );
        return error as CLong;
    }
    if mempolicy_mode_is_supported(normalized_mode) == 0 {
        return -(EINVAL as CLong);
    }

    match normalized_mode {
        MPOL_DEFAULT => {
            if nodemask_addr != 0 && nodemask_bits != 0 {
                let Some(copy_from) = copy_from_fn else {
                    return -(EINVAL as CLong);
                };
                if copy_from(
                    numa_mask.as_mut_ptr().cast::<u8>(),
                    nodemask_addr,
                    (nodemask_bits >> 3) as SizeT,
                ) != 0
                {
                    mbind_log(
                        log_fn,
                        MBIND_LOG_COPY_FROM_NUMA_MASK,
                        addr,
                        nodemask_addr,
                        0,
                    );
                    return -(EFAULT as CLong);
                }
                if !policy_mask_empty(numa_mask.as_ptr(), nodemask_bits) {
                    mbind_log(
                        log_fn,
                        MBIND_LOG_DEFAULT_MASK_NOT_EMPTY,
                        addr,
                        nodemask_addr,
                        0,
                    );
                    return -(EINVAL as CLong);
                }
            }
        }
        MPOL_BIND | MPOL_INTERLEAVE | MPOL_PREFERRED => {
            if normalized_mode == MPOL_PREFERRED && nodemask_addr == 0 {
            } else {
                if (flags & MPOL_MF_STRICT) != 0 {
                    return -(EIO as CLong);
                }

                let Some(copy_from) = copy_from_fn else {
                    return -(EINVAL as CLong);
                };
                if copy_from(
                    numa_mask.as_mut_ptr().cast::<u8>(),
                    nodemask_addr,
                    (nodemask_bits >> 3) as SizeT,
                ) != 0
                {
                    return -(EFAULT as CLong);
                }

                if nodemask_addr == 0 || policy_mask_empty(numa_mask.as_ptr(), nodemask_bits) {
                    mbind_log(
                        log_fn,
                        MBIND_LOG_NODEMASK_NOT_SPECIFIED,
                        addr,
                        nodemask_addr,
                        0,
                    );
                    return -(EINVAL as CLong);
                }

                let scan_bits = if maxnode < PROCESS_NUMA_MASK_BITS {
                    maxnode
                } else {
                    PROCESS_NUMA_MASK_BITS
                };
                let mut bit = 0 as CULong;
                while bit < scan_bits {
                    if policy_mask_test(numa_mask.as_ptr(), bit as CInt)
                        && bit as CInt >= nr_numa_nodes
                    {
                        mbind_log(log_fn, MBIND_LOG_NODE_TOO_LARGE, addr, bit, 0);
                        return -(EINVAL as CLong);
                    }
                    bit += 1;
                }
            }
        }
        _ => return -(EINVAL as CLong),
    }

    let (
        Some(write_lock),
        Some(write_unlock),
        Some(lookup_range),
        Some(policy_search),
        Some(clear_range),
        Some(alloc),
        Some(rb_clear),
        Some(insert),
    ) = (
        write_lock_fn,
        write_unlock_fn,
        lookup_range_fn,
        policy_search_fn,
        clear_range_fn,
        alloc_fn,
        rb_clear_fn,
        insert_fn,
    )
    else {
        return -(EINVAL as CLong);
    };

    let lock = core::ptr::addr_of_mut!((*vm).memory_range_lock) as *mut c_void;
    write_lock(lock);

    let end = addr.wrapping_add(len);
    let range = lookup_range(vm, addr, end);
    if range.is_null() {
        mbind_log(log_fn, MBIND_LOG_INVALID_RANGE, addr, end, 0);
        write_unlock(lock);
        return -(EFAULT as CLong);
    }

    let mut range_policy = policy_search(vm, addr);
    if range_policy.is_null() || (*range_policy).start != addr || (*range_policy).end != end {
        let error = clear_range(vm, addr, end);
        if error != 0 {
            mbind_log(log_fn, MBIND_LOG_CLEAR_POLICY_RANGE, addr, end, error);
            write_unlock(lock);
            return error as CLong;
        }

        range_policy = alloc(policy_size, alloc_flags).cast::<VmRangeNumaPolicy>();
        if range_policy.is_null() {
            mbind_log(log_fn, MBIND_LOG_ALLOC_POLICY, addr, end, 0);
            write_unlock(lock);
            return -(ENOMEM as CLong);
        }

        rb_clear(range_policy);
        (*range_policy).start = addr;
        (*range_policy).end = end;

        let error = insert(vm, range_policy);
        if error != 0 {
            mbind_log(log_fn, MBIND_LOG_INSERT_POLICY, addr, end, error);
            write_unlock(lock);
            return error as CLong;
        }
    }

    if normalized_mode == MPOL_DEFAULT {
        policy_mask_set_all_nodes((*range_policy).numa_mask.as_mut_ptr(), nr_numa_nodes);
    } else {
        policy_mask_copy_words((*range_policy).numa_mask.as_mut_ptr(), numa_mask.as_ptr());
    }
    (*range_policy).numa_mem_policy = normalized_mode;
    if normalized_mode == MPOL_INTERLEAVE {
        (*range_policy).il_prev = (PROCESS_NUMA_MASK_BITS - 1) as CInt;
    }

    write_unlock(lock);
    0
}
