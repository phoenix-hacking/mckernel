Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Additive source-contract correction after actual-body parity PASS and independent
review INTEGRATE_CURRENT_MBIND_CALLER_ONLY. The original source, freezes, three
passing parity tests and all captured compiler/test streams remain untouched.
clear_range_contract_v2.rs changes documentation only: start < end, a valid
nonoverlapping tree, the existing exclusive writer lock, fresh aligned writable
nonalias allocation >= sizeof(VmRangeNumaPolicy), and existing insertion ownership
semantics are explicit. No executable clear body change and no old parity replay.

The inherited insertion-error unfreed-tail branch is unreachable for the current
validated, disjoint-tree mbind caller. Out-of-contract empty/reversed inputs used
by parity stress preserve C behavior but do not expand this integration release.
Only current mbind caller integration is reviewed; no source/native/link credit.

New focused test composes the exact current mbind_body_result and dependencies
with the proposed clear body through its accepted compiled C forwarding glue.
The common accepted actual RB/C observer is reused. The test executes four bad
length vectors (empty, reversed endpoints, endpoint wrap, rounding wrap), requiring
-EINVAL with no lock/lookup/search/clear/allocation/tree mutation. A valid length1
rounds to one page, enters clear under the original VM memory_range_lock, splits
an existing policy, publishes the replacement and then unlocks. Every tree-event
callback asserts the writer lock is held during this composition. Final ranges,
replacement policy/mask and allocation ownership are checked.

Exact proposed command inside the root's fresh CPU6/1GiB/CPU55/nofile256/
fsize64MiB/core0 ordinary one-job grant:
/home/holden/anaconda3/bin/python3.9 -I -B /home/holden/mckernel-work/host-preparation/numa-vm-policy-clear-range-rust-20261021-1/run_caller_composition.py

Two serial commands: accepted Rust1.85.1 compile linking existing hash-bound C
objects, then --exact current_mbind_caller_range_validation_and_writer_locked_split.
Old three tests are compiled for observer reuse but are NOT executed. No C compile,
root/module/guest or production build. No test attempted at this source freeze.
Stop after one failed candidate plus one bounded correction per family; retain
all failures. No shared kernel/Git/docs writes. Production insertion copy untouched.
