// Proposal for kernel/rust/syscall_policy.rs. Reuses its existing policy types.
type SyscallPolicyRbEraseFn = unsafe extern "C" fn(*mut AbiRbNode, *mut AbiRbRoot);
type SyscallPolicyRbFirstFn = unsafe extern "C" fn(*const AbiRbRoot) -> *mut AbiRbNode;
type SyscallPolicyRbNextFn = unsafe extern "C" fn(*const AbiRbNode) -> *mut AbiRbNode;
type SyscallPolicyClearFreeFn = unsafe extern "C" fn(*mut c_void);
type SyscallPolicyClearLogFn = unsafe extern "C" fn(CInt, CInt);

/// Clears policy ranges with the original C ordering and partial mutations.
///
/// Safety: caller holds the existing exclusive VM policy-tree lock; vm and all
/// linked policies have checked C layouts and stay live until erase/free. Each
/// callback obeys that lock/lifetime contract. Allocation returns an aligned,
/// writable policy allocation of policy_size bytes; only insert publishes it.
/// No Rust references are retained across callbacks. The original failure path
/// after insertion error leaves the allocated, unpublished tail unfreed. This
/// inherited ownership ambiguity is deliberately exposed for independent review;
/// the migration does not introduce rollback/free semantics absent from C.
#[no_mangle]
pub unsafe extern "C" fn syscall_vm_policy_clear_range_body_result(
    vm: *mut ProcessVm, start: CULong, end: CULong,
    policy_size: SizeT, alloc_flags: CULong,
    alloc_fn: Option<SyscallPolicyAllocFn>,
    rb_clear_fn: Option<SyscallPolicyRbClearFn>,
    insert_fn: Option<SyscallPolicyInsertFn>,
    erase_fn: Option<SyscallPolicyRbEraseFn>,
    free_fn: Option<SyscallPolicyClearFreeFn>,
    first_fn: Option<SyscallPolicyRbFirstFn>,
    next_fn: Option<SyscallPolicyRbNextFn>,
    log_fn: Option<SyscallPolicyClearLogFn>,
) -> CInt {
    let (Some(alloc), Some(rb_clear), Some(insert), Some(erase), Some(free),
         Some(first), Some(next), Some(log)) =
        (alloc_fn, rb_clear_fn, insert_fn, erase_fn, free_fn, first_fn, next_fn, log_fn)
    else { return -EINVAL; };
    let root = unsafe { addr_of_mut!((*vm).vm_range_numa_policy_tree) };
    let iter = unsafe { syscall_vm_range_policy_search_body_result(vm, start) };
    if !iter.is_null() {
        let mut adjusted = false;
        let mut orig_end = unsafe { (*iter).end };
        if unsafe { (*iter).start == start && (*iter).end == end } {
            unsafe { erase(addr_of_mut!((*iter).policy_rb_node), root); free(iter.cast()); }
            return 0;
        }
        if unsafe { (*iter).start < start } {
            orig_end = unsafe { (*iter).end };
            unsafe { (*iter).end = start; }
            adjusted = true;
        }
        if orig_end > end {
            if adjusted {
                let tail = unsafe { alloc(policy_size, alloc_flags) }.cast::<VmRangeNumaPolicy>();
                if tail.is_null() { unsafe { log(0, 0); } return -ENOMEM; }
                unsafe {
                    rb_clear(tail);
                    (*tail).start = end;
                    (*tail).end = orig_end;
                    (*tail).numa_mem_policy = (*iter).numa_mem_policy;
                    // C copies only mask, leaving il_prev and RB child bytes alone.
                    core::ptr::copy_nonoverlapping(
                        core::ptr::addr_of!((*iter).numa_mask),
                        addr_of_mut!((*tail).numa_mask),
                        1);
                }
                let error = unsafe { insert(vm, tail) };
                if error != 0 { unsafe { log(1, error); } return error; }
            } else { unsafe { (*iter).start = end; } }
        }
    }
    // C unsigned end - 1 intentionally wraps for end == 0.
    let iter = unsafe { syscall_vm_range_policy_search_body_result(vm, end.wrapping_sub(1)) };
    if !iter.is_null() { unsafe { (*iter).start = end; } }
    // Restart rb_first after every removal, matching the C goto again_search.
    loop {
        let mut node = unsafe { first(root) };
        let mut removed = false;
        while !node.is_null() {
            let range = unsafe { node.cast::<u8>()
                .sub(offset_of!(VmRangeNumaPolicy, policy_rb_node)).cast::<VmRangeNumaPolicy>() };
            if unsafe { (*range).start >= start && (*range).end <= end } {
                unsafe { erase(addr_of_mut!((*range).policy_rb_node), root); free(range.cast()); }
                removed = true;
                break;
            }
            node = unsafe { next(node) };
        }
        if !removed { break; }
    }
    0
}
