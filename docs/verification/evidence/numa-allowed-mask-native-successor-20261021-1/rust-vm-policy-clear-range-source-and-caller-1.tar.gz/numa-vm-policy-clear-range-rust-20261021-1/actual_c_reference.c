#include <stddef.h>
#include <stdint.h>
#include <string.h>
#define EFAULT 14
#define ENOMEM 12
#define IHK_MC_AP_NOWAIT 0x204UL
struct rb_node { unsigned long parent_color; struct rb_node *rb_right, *rb_left; };
struct rb_root { struct rb_node *rb_node; };
struct vm_range_numa_policy { struct rb_node policy_rb_node; unsigned long start,end; unsigned long numa_mask[4]; int numa_mem_policy,il_prev; };
struct process_vm { unsigned char prefix[248]; struct rb_root vm_range_numa_policy_tree; unsigned char tail[48]; };
_Static_assert(sizeof(struct vm_range_numa_policy)==80,"policy ABI");
_Static_assert(offsetof(struct process_vm,vm_range_numa_policy_tree)==248,"root ABI");
extern void fixture_erase(struct rb_node *,struct rb_root *);
extern void fixture_free(void *);
extern struct rb_node *fixture_first(const struct rb_root *);
extern struct rb_node *fixture_next(const struct rb_node *);
extern void *fixture_alloc(size_t,unsigned long);
extern void fixture_clear(struct vm_range_numa_policy *);
extern int fixture_insert(struct process_vm *,struct vm_range_numa_policy *);
extern void fixture_log(int,int);
extern void fixture_link(struct rb_node *,struct rb_node *,struct rb_node **);
extern void fixture_color(struct rb_node *,struct rb_root *);
extern void fixture_insert_log(struct process_vm *,struct vm_range_numa_policy *,struct vm_range_numa_policy *);
#define rb_erase fixture_erase
#define kfree_tracked(p,f,l) fixture_free(p)
#define kmalloc_tracked(s,a,f,l) fixture_alloc(s,a)
#define rb_first fixture_first
#define rb_next fixture_next
#define RB_CLEAR_NODE(p) fixture_clear((struct vm_range_numa_policy *)((char *)(p)-offsetof(struct vm_range_numa_policy,policy_rb_node)))
#define dkprintf(...) fixture_log(0,0)
#define kprintf(f,n,e) fixture_log(1,e)
#define ekprintf(...) fixture_insert_log(vm,newrange,range)
#define rb_link_node fixture_link
#define rb_insert_color fixture_color
struct vm_range_numa_policy *vm_range_policy_search(struct process_vm *vm, uintptr_t addr)
{
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
	return syscall_vm_range_policy_search_body_result(vm, addr);
#else
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct rb_node *node = root->rb_node;
	struct vm_range_numa_policy *numa_policy = NULL;

	while (node) {
		numa_policy = ((struct vm_range_numa_policy *)((char *)(node) - offsetof(struct vm_range_numa_policy, policy_rb_node)));
		if (addr < numa_policy->start) {
			node = node->rb_left;
		} else if (addr >= numa_policy->end) {
			node = node->rb_right;
		} else {
			return numa_policy;
		}
	}

	return NULL;
#endif
}

#undef dkprintf
#define dkprintf(...) fixture_insert_log(vm,newrange,NULL)
static int fixture_real_insert(struct process_vm *vm,
		struct vm_range_numa_policy *newrange)
{
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
	return syscall_vm_policy_insert_body_result(vm, newrange,
			syscall_vm_policy_link_bridge, syscall_vm_policy_color_bridge,
			syscall_vm_policy_insert_log_bridge);
#else
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct rb_node **new = &(root->rb_node), *parent = NULL;
	struct vm_range_numa_policy *range;

	while (*new) {
		range = ((struct vm_range_numa_policy *)((char *)(*new) - offsetof(struct vm_range_numa_policy, policy_rb_node)));
		parent = *new;
		if (newrange->end <= range->start) {
			new = &((*new)->rb_left);
		} else if (newrange->start >= range->end) {
			new = &((*new)->rb_right);
		} else {
			ekprintf("%s(%p,%lx-%lx (nodemask)%lx (policy)%d): overlap %lx-%lx (nodemask)%lx (policy)%d\n",
					__func__, vm, newrange->start,
					newrange->end, newrange->numa_mask,
					newrange->numa_mem_policy, range->start,
					range->end, range->numa_mask,
					range->numa_mem_policy);
			return -EFAULT;
		}
	}

	dkprintf("%s: %p,%p: %lx-%lx (nodemask)%lx (policy)%d\n",
			__func__, vm, newrange, newrange->start, newrange->end,
			newrange->numa_mask, newrange->numa_mem_policy);

	rb_link_node(&newrange->policy_rb_node, parent, new);
	rb_insert_color(&newrange->policy_rb_node, root);

	return 0;
#endif
}

int fixture_reference_insert(struct process_vm *vm,struct vm_range_numa_policy *p){return fixture_real_insert(vm,p);}
#undef dkprintf
#define dkprintf(...) fixture_log(0,0)
#define vm_policy_insert fixture_insert
static int vm_policy_clear_range(struct process_vm *vm,
		unsigned long start, unsigned long end)
{
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct vm_range_numa_policy *range, *range_policy_iter;
	struct vm_range_numa_policy *range_policy;
	struct rb_node *node;
	int error = 0;

	/*
	 * Adjust overlapping range settings and add new one
	 *  case: front part of new range overlaps existing one
	 *  case: new range is a part of existing range
	 */
	range_policy_iter = vm_range_policy_search(vm, start);
	if (range_policy_iter) {
		int adjusted = 0;
		unsigned long orig_end = range_policy_iter->end;

		if (range_policy_iter->start == start &&
				range_policy_iter->end == end) {
			rb_erase(&range_policy_iter->policy_rb_node,
				&vm->vm_range_numa_policy_tree);
			kfree_tracked(range_policy_iter, __FILE__, __LINE__);
			error = 0;
			goto out;
		}

		/* Overlapping partially? */
		if (range_policy_iter->start < start) {
			orig_end = range_policy_iter->end;
			range_policy_iter->end = start;
			adjusted = 1;
		}

		/* Do we need to keep the end? */
		if (orig_end > end) {
			if (adjusted) {
				/* Add a new entry after */
				range_policy = kmalloc_tracked(sizeof(struct vm_range_numa_policy), IHK_MC_AP_NOWAIT, __FILE__, __LINE__);
				if (!range_policy) {
					dkprintf("%s: error allocating range_policy\n",
							__func__);
					error = -ENOMEM;
					goto out;
				}

				RB_CLEAR_NODE(&range_policy->policy_rb_node);
				range_policy->start = end;
				range_policy->end = orig_end;
				range_policy->numa_mem_policy =
					range_policy_iter->numa_mem_policy;

				memcpy(range_policy->numa_mask,
					&range_policy_iter->numa_mask,
					sizeof(range_policy->numa_mask));

				error = vm_policy_insert(vm, range_policy);
				if (error) {
					kprintf("%s: ERROR: could not insert range: %d\n",
							__func__, error);
					goto out;
				}
			}
			else {
				range_policy_iter->start = end;
			}
		}
	}

	/*
	 * Adjust overlapping range settings
	 *  case: rear part of new range overlaps existing range
	 */
	range_policy_iter = vm_range_policy_search(vm, end - 1);
	if (range_policy_iter) {
		range_policy_iter->start = end;
	}

	/* Search fulliy contained range */
again_search:
	for (node = rb_first(root); node; node = rb_next(node)) {
		range = ((struct vm_range_numa_policy *)((char *)(node) - offsetof(struct vm_range_numa_policy, policy_rb_node)));

		/* existing range is fully contained */
		if (range->start >= start && range->end <= end) {
			rb_erase(&range->policy_rb_node,
				&vm->vm_range_numa_policy_tree);
			kfree_tracked(range, __FILE__, __LINE__);
			goto again_search;
		}
	}

out:
	return error;
}

int fixture_reference_clear(struct process_vm *vm,unsigned long s,unsigned long e){return vm_policy_clear_range(vm,s,e);}
