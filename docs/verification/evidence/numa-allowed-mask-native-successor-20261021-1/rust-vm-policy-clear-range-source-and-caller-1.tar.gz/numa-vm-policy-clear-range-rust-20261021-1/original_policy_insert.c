static int vm_policy_insert(struct process_vm *vm,
		struct vm_range_numa_policy *newrange)
{
#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
	return syscall_vm_policy_insert_body_result(vm, newrange,
			syscall_vm_policy_link_bridge, syscall_vm_policy_color_bridge,
			syscall_vm_policy_insert_log_bridge);
#else
	struct rb_root *root = &vm->vm_range_numa_policy_tree;
	struct rb_node **new = &(root->rb_node), *parent = NULL;
	struct vm_range_numa_policy *range;

	while (*new) {
		range = ((struct vm_range_numa_policy *)((char *)(*new) - offsetof(struct vm_range_numa_policy, policy_rb_node)));
		parent = *new;
		if (newrange->end <= range->start) {
			new = &((*new)->rb_left);
		} else if (newrange->start >= range->end) {
			new = &((*new)->rb_right);
		} else {
			ekprintf("%s(%p,%lx-%lx (nodemask)%lx (policy)%d): overlap %lx-%lx (nodemask)%lx (policy)%d\n",
					__func__, vm, newrange->start,
					newrange->end, newrange->numa_mask,
					newrange->numa_mem_policy, range->start,
					range->end, range->numa_mask,
					range->numa_mem_policy);
			return -EFAULT;
		}
	}

	dkprintf("%s: %p,%p: %lx-%lx (nodemask)%lx (policy)%d\n",
			__func__, vm, newrange, newrange->start, newrange->end,
			newrange->numa_mask, newrange->numa_mem_policy);

	rb_link_node(&newrange->policy_rb_node, parent, new);
	rb_insert_color(&newrange->policy_rb_node, root);

	return 0;
#endif
}
