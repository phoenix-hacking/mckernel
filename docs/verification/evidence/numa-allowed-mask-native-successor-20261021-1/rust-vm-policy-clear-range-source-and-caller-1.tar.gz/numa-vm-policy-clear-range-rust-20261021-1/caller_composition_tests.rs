#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
#[path="/home/holden/mckernel/kernel/rust/rbtree.rs"] mod rbtree;
use abi::{AbiRbNode,AbiRbRoot,CInt,CULong,SizeT,ProcessVm,VmRangeNumaPolicy};
use core::ffi::c_void;
use core::mem::{offset_of,size_of};
use core::ptr::{addr_of_mut,null_mut};
use std::cell::Cell;
const EINVAL:CInt=22;const EFAULT:CInt=14;const ENOMEM:CInt=12;
type SyscallPolicyAllocFn=unsafe extern "C" fn(SizeT,CULong)->*mut c_void;
type SyscallPolicyRbClearFn=unsafe extern "C" fn(*mut VmRangeNumaPolicy);
type SyscallPolicyInsertFn=unsafe extern "C" fn(*mut ProcessVm,*mut VmRangeNumaPolicy)->CInt;
type SyscallPolicyRbLinkFn=unsafe extern "C" fn(*mut AbiRbNode,*mut AbiRbNode,*mut *mut AbiRbNode);
type SyscallPolicyRbInsertColorFn=unsafe extern "C" fn(*mut AbiRbNode,*mut AbiRbRoot);
type SyscallPolicyInsertLogFn=unsafe extern "C" fn(*mut ProcessVm,*mut VmRangeNumaPolicy,*mut VmRangeNumaPolicy);
include!("actual_rust_search.rs");
include!("actual_rust_insert.rs");
include!("clear_range_contract_v2.rs");
unsafe extern "C" {
 fn fixture_reference_clear(vm:*mut ProcessVm,s:u64,e:u64)->i32;
 fn fixture_selected_clear(vm:*mut ProcessVm,s:u64,e:u64)->i32;
 fn fixture_reference_insert(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy)->i32;
}
thread_local!{static CURRENT:Cell<*mut Tree>=const{Cell::new(null_mut())};}
#[derive(Debug,Clone,PartialEq,Eq)]struct Event{kind:u8,args:Vec<u64>,state:Vec<u64>}
struct Tree{vm:Box<ProcessVm>,nodes:Vec<Box<VmRangeNumaPolicy>>,freed:Vec<bool>,events:Vec<Event>,mode:u8,fail_alloc:bool,insert_error:i32}
impl Tree{
 fn new(ranges:&[(u64,u64)],mode:u8,fail_alloc:bool,insert_error:i32)->Self{
  let mut t=Self{vm:Box::new(unsafe{core::mem::zeroed()}),nodes:Vec::new(),freed:Vec::new(),events:Vec::new(),mode,fail_alloc,insert_error};
  for (i,&(start,end))in ranges.iter().enumerate(){let mut p:Box<VmRangeNumaPolicy>=Box::new(unsafe{core::mem::zeroed()});p.start=start;p.end=end;p.numa_mask=[i as u64+1,u64::MAX,0x123456789abcdef0,1<<63];p.numa_mem_policy=i as i32+1;p.il_prev=i as i32+57;t.nodes.push(p);t.freed.push(false);}
  t
 }
 fn activate(&mut self){CURRENT.with(|c|c.set(self));}
 fn node_index(&self,p:*const AbiRbNode)->u64{if p.is_null(){u64::MAX}else{self.nodes.iter().position(|n|(&n.policy_rb_node as*const AbiRbNode)==p).map(|i|i as u64).unwrap_or(p as u64)}}
 fn state(&self)->Vec<u64>{let mut s=vec![self.node_index(self.vm.vm_range_numa_policy_tree.rb_node)];for(i,n)in self.nodes.iter().enumerate(){let pc=n.policy_rb_node.__rb_parent_color;let parent=(pc&!3)as*const AbiRbNode;let parent=if parent==&n.policy_rb_node{0xeeee0000|(pc&3)}else{let x=self.node_index(parent);if x==u64::MAX{x}else{(x<<2)|(pc&3)}};s.extend_from_slice(&[parent,self.node_index(n.policy_rb_node.rb_left),self.node_index(n.policy_rb_node.rb_right),n.start,n.end,n.numa_mem_policy as u64,n.il_prev as u64,self.freed[i]as u64]);s.extend_from_slice(&n.numa_mask);}s}
 fn event(&mut self,kind:u8,args:Vec<u64>){if COMPOSITION_ACTIVE.with(|c|c.get()){assert!(LOCK_HELD.with(|c|c.get()),"policy callback outside writer lock");}self.events.push(Event{kind,args,state:self.state()});}
 fn live_ranges(&self)->Vec<(u64,u64)>{unsafe{let mut p=rbtree::rb_first((&self.vm.vm_range_numa_policy_tree as*const AbiRbRoot).cast());let mut v=vec![];while !p.is_null(){let n=p.cast::<VmRangeNumaPolicy>();v.push(((*n).start,(*n).end));p=rbtree::rb_next(p);}v}}
 unsafe fn setup(&mut self){self.activate();for i in 0..self.nodes.len(){let p=&mut*self.nodes[i]as*mut _;assert_eq!(fixture_reference_insert(&mut*self.vm,p),0);}self.events.clear();}
}
fn with_tree<T>(f:impl FnOnce(&mut Tree)->T)->T{CURRENT.with(|c|unsafe{f(&mut*c.get())})}
#[no_mangle]unsafe extern "C" fn fixture_alloc(size:SizeT,flags:u64)->*mut c_void{with_tree(|t|{t.event(1,vec![size as u64,flags]);assert_eq!(size,size_of::<VmRangeNumaPolicy>()as SizeT);assert_eq!(flags,0x204);if t.fail_alloc{return null_mut();}let mut p:Box<VmRangeNumaPolicy>=Box::new(core::mem::zeroed());core::ptr::write_bytes((&mut*p as*mut VmRangeNumaPolicy).cast::<u8>(),0xa5,size as usize);let raw=&mut*p as*mut VmRangeNumaPolicy;t.nodes.push(p);t.freed.push(false);raw.cast()})}
#[no_mangle]unsafe extern "C" fn fixture_clear(p:*mut VmRangeNumaPolicy){with_tree(|t|t.event(2,vec![t.node_index(addr_of_mut!((*p).policy_rb_node))]));(*p).policy_rb_node.__rb_parent_color=addr_of_mut!((*p).policy_rb_node)as u64;}
#[no_mangle]unsafe extern "C" fn fixture_insert(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy)->i32{let(mode,error)=with_tree(|t|{assert_eq!(vm,&mut*t.vm as*mut _);t.event(3,vec![t.node_index(addr_of_mut!((*p).policy_rb_node))]);(t.mode,t.insert_error)});if error!=0{return error;}if mode==0{fixture_reference_insert(vm,p)}else{syscall_vm_policy_insert_body_result(vm,p,Some(fixture_link),Some(fixture_color),Some(fixture_insert_log))}}
#[no_mangle]unsafe extern "C" fn fixture_erase(p:*mut AbiRbNode,root:*mut AbiRbRoot){with_tree(|t|t.event(4,vec![t.node_index(p)]));rbtree::rb_erase(p.cast(),root.cast());}
#[no_mangle]unsafe extern "C" fn fixture_free(p:*mut c_void){with_tree(|t|{let i=t.node_index(p.cast())as usize;t.event(5,vec![i as u64]);assert!(!t.freed[i]);t.freed[i]=true;});}
#[no_mangle]unsafe extern "C" fn fixture_first(root:*const AbiRbRoot)->*mut AbiRbNode{with_tree(|t|t.event(6,vec![]));rbtree::rb_first(root.cast()).cast()}
#[no_mangle]unsafe extern "C" fn fixture_next(p:*const AbiRbNode)->*mut AbiRbNode{with_tree(|t|t.event(7,vec![t.node_index(p)]));rbtree::rb_next(p.cast()).cast()}
#[no_mangle]unsafe extern "C" fn fixture_log(event:i32,error:i32){with_tree(|t|t.event(8,vec![event as u64,error as u64]));}
#[no_mangle]unsafe extern "C" fn fixture_link(p:*mut AbiRbNode,parent:*mut AbiRbNode,slot:*mut*mut AbiRbNode){with_tree(|t|t.event(9,vec![t.node_index(p),t.node_index(parent)]));rbtree::rb_link_node(p.cast(),parent.cast(),slot.cast());}
#[no_mangle]unsafe extern "C" fn fixture_color(p:*mut AbiRbNode,root:*mut AbiRbRoot){with_tree(|t|t.event(10,vec![t.node_index(p)]));rbtree::rb_insert_color(p.cast(),root.cast());}
#[no_mangle]unsafe extern "C" fn fixture_insert_log(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy,overlap:*mut VmRangeNumaPolicy){with_tree(|t|{assert_eq!(vm,&mut*t.vm as*mut _);t.event(11,vec![t.node_index(p.cast()),t.node_index(overlap.cast())]);});}
fn compare(ranges:&[(u64,u64)],start:u64,end:u64,fail_alloc:bool,insert_error:i32)->(Tree,i32){let mut a=Tree::new(ranges,0,fail_alloc,insert_error);let mut b=Tree::new(ranges,1,fail_alloc,insert_error);unsafe{a.setup();b.setup();}a.activate();let ra=unsafe{fixture_reference_clear(&mut*a.vm,start,end)};b.activate();let rb=unsafe{fixture_selected_clear(&mut*b.vm,start,end)};assert_eq!(ra,rb,"returns {ranges:?} {start}..{end}");assert_eq!(a.events,b.events,"callback order and pre-callback ownership/state {ranges:?} {start}..{end}");assert_eq!(a.state(),b.state(),"complete final allocated/freed/node/tree state {ranges:?} {start}..{end}");assert_eq!(a.live_ranges(),b.live_ranges());(b,rb)}
#[test]fn independent_expected_ranges_and_failure_order(){
 let cases:&[(&[(u64,u64)],u64,u64,&[(u64,u64)])]=&[
 (&[],10,20,&[]),(&[(10,50)],10,50,&[]),(&[(10,50)],20,30,&[(10,20),(30,50)]),
 (&[(10,50)],10,30,&[(30,50)]),(&[(10,50)],30,50,&[(10,30)]),
 (&[(10,50)],0,60,&[]),(&[(10,20),(30,40),(50,60)],15,55,&[(10,15),(55,60)]),
 (&[(10,20),(30,40)],20,30,&[(10,20),(30,40)]),(&[(10,20)],0,10,&[(10,20)]),
 (&[(10,20)],20,30,&[(10,20)]),(&[(0,1),(u64::MAX-2,u64::MAX)],0,u64::MAX,&[]),
 (&[(u64::MAX-8,u64::MAX)],u64::MAX-6,u64::MAX-4,&[(u64::MAX-8,u64::MAX-6),(u64::MAX-4,u64::MAX)]),
 // Unvalidated empty/reversed inputs retain the original surprising mutations.
 (&[(10,50)],30,30,&[(30,50)]),
 (&[(10,50)],0,0,&[(10,50)]),(&[(u64::MAX-2,u64::MAX)],0,0,&[(u64::MAX-2,u64::MAX)]),
 ];
 for &(ranges,s,e,expected)in cases{let(t,rc)=compare(ranges,s,e,false,0);assert_eq!(rc,0);assert_eq!(t.live_ranges(),expected,"independent ranges {s}..{e}");}
 let(t,rc)=compare(&[(10,50)],20,30,true,0);assert_eq!(rc,-12);assert_eq!(t.live_ranges(),[(10,20)]);assert_eq!(t.events.iter().map(|e|e.kind).collect::<Vec<_>>(),[1,8]);assert_eq!(t.nodes.len(),1);
 let(t,rc)=compare(&[(10,50)],30,20,false,0);assert_eq!(rc,-14);assert_eq!(t.live_ranges(),[(10,30)]);assert_eq!((t.nodes[1].start,t.nodes[1].end),(20,50));assert!(!t.freed[1]);
 for error in [-14,-22,7]{let(t,rc)=compare(&[(10,50)],20,30,false,error);assert_eq!(rc,error);assert_eq!(t.live_ranges(),[(10,20)]);assert_eq!(t.events.iter().map(|e|e.kind).collect::<Vec<_>>(),[1,2,3,8]);assert_eq!(t.nodes.len(),2);assert!(!t.freed[1]);assert_eq!((t.nodes[1].start,t.nodes[1].end),(30,50));assert_eq!(t.nodes[1].il_prev,0xa5a5a5a5u32 as i32);}
 println!("independent expected cases=15; allocation failures=1; insertion errors=3; exact callback and partial-mutation checks passed");
}
#[test]fn bounded_unsigned_and_tree_sweep(){let layouts:&[&[(u64,u64)]]=&[&[],&[(2,7)],&[(0,2),(3,6),(7,10)],&[(8,12),(0,2),(14,20),(3,6)],&[(u64::MAX-8,u64::MAX-4),(u64::MAX-3,u64::MAX)]];let points=[0,1,2,3,5,6,7,9,10,12,20,u64::MAX-7,u64::MAX-4,u64::MAX-1,u64::MAX];let mut n=0;for &layout in layouts{for &s in &points{for &e in &points{for &(fail,error)in &[(false,0),(true,0),(false,-14)]{compare(layout,s,e,fail,error);n+=1;}}}}assert_eq!(n,3375);println!("exact unchanged-C/selected-Rust clear comparisons={n}");}
#[test]fn missing_callback_refuses_before_vm_access(){assert_eq!(unsafe{syscall_vm_policy_clear_range_body_result(null_mut(),0,0,80,0x204,None,Some(fixture_clear),Some(fixture_insert),Some(fixture_erase),Some(fixture_free),Some(fixture_first),Some(fixture_next),Some(fixture_log))},-22);assert_eq!(size_of::<VmRangeNumaPolicy>(),80);assert_eq!(offset_of!(ProcessVm,vm_range_numa_policy_tree),248);}

use abi::{CLong,VmRange,PROCESS_NUMA_MASK_WORDS};
use core::ptr::{write,read_volatile,write_volatile};
use std::cell::RefCell;
const EIO:CInt=5;
type SyscallCopyFromUserFn=unsafe extern "C" fn(*mut u8,CULong,SizeT)->CLong;
type SyscallRwlockFn=unsafe extern "C" fn(*mut c_void);
type SyscallLookupRangeFn=unsafe extern "C" fn(*mut ProcessVm,CULong,CULong)->*mut VmRange;
type SyscallPolicySearchFn=unsafe extern "C" fn(*mut ProcessVm,CULong)->*mut VmRangeNumaPolicy;
type SyscallPolicyClearRangeFn=unsafe extern "C" fn(*mut ProcessVm,CULong,CULong)->CInt;
type SyscallMbindLogFn=unsafe extern "C" fn(CInt,CULong,CULong,CInt);
include!("actual_mbind_body_and_dependencies.rs");
thread_local!{
 static COMPOSITION_ACTIVE:Cell<bool>=const{Cell::new(false)};
 static LOCK_HELD:Cell<bool>=const{Cell::new(false)};
 static CALLER_TRACE:RefCell<Vec<&'static str>>=const{RefCell::new(Vec::new())};
 static VM_RANGE:Cell<*mut VmRange>=const{Cell::new(null_mut())};
}
fn trace(s:&'static str){CALLER_TRACE.with(|t|t.borrow_mut().push(s));}
unsafe extern "C" fn caller_lock(lock:*mut c_void){with_tree(|t|assert_eq!(lock,addr_of_mut!((*t.vm).memory_range_lock).cast()));assert!(!LOCK_HELD.with(|c|c.replace(true)));trace("lock");}
unsafe extern "C" fn caller_unlock(lock:*mut c_void){with_tree(|t|assert_eq!(lock,addr_of_mut!((*t.vm).memory_range_lock).cast()));assert!(LOCK_HELD.with(|c|c.replace(false)));trace("unlock");}
unsafe extern "C" fn caller_lookup(vm:*mut ProcessVm,start:u64,end:u64)->*mut VmRange{assert!(LOCK_HELD.with(|c|c.get()));with_tree(|t|assert_eq!(vm,&mut*t.vm as*mut _));assert_eq!((start,end),(0x2000,0x3000));trace("lookup");VM_RANGE.with(|c|c.get())}
unsafe extern "C" fn caller_search(vm:*mut ProcessVm,addr:u64)->*mut VmRangeNumaPolicy{assert!(LOCK_HELD.with(|c|c.get()));trace("search");syscall_vm_range_policy_search_body_result(vm,addr)}
unsafe extern "C" fn caller_clear(vm:*mut ProcessVm,start:u64,end:u64)->i32{assert!(LOCK_HELD.with(|c|c.get()));assert!(start<end);trace("clear.enter");let rc=fixture_selected_clear(vm,start,end);assert!(LOCK_HELD.with(|c|c.get()));assert_eq!(rc,0);with_tree(|t|assert_eq!(t.live_ranges(),[(0x1000,0x2000),(0x3000,0x5000)]));trace("clear.exit");rc}
unsafe extern "C" fn caller_alloc(size:SizeT,flags:u64)->*mut c_void{assert!(LOCK_HELD.with(|c|c.get()));trace("alloc");fixture_alloc(size,flags)}
unsafe extern "C" fn caller_rb_clear(p:*mut VmRangeNumaPolicy){trace("rbclear");fixture_clear(p);}
unsafe extern "C" fn caller_insert(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy)->i32{trace("insert");fixture_insert(vm,p)}
unsafe fn caller_run(t:&mut Tree,addr:u64,len:u64)->CLong{t.activate();mbind_body_result(addr,len,MPOL_DEFAULT,0,0,0,&mut*t.vm,0,0,2,80,0x204,None,Some(caller_lock),Some(caller_unlock),Some(caller_lookup),Some(caller_search),Some(caller_clear),Some(caller_alloc),Some(caller_rb_clear),Some(caller_insert),None)}
#[test]fn current_mbind_caller_range_validation_and_writer_locked_split(){
 let mut range:Box<VmRange>=Box::new(unsafe{core::mem::zeroed()});VM_RANGE.with(|c|c.set(&mut*range));
 // Exact existing mbind_prepare_range must reject before acquiring a writer lock
 // or calling lookup/search/clear. Reversed endpoints use wrapped unsigned len.
 for (addr,len)in [(0x2000,0),(0x2000,0x1000u64.wrapping_sub(0x2000)),(u64::MAX-0xfff,0x2000),(0x2000,u64::MAX)]{
  let mut t=Tree::new(&[(0x1000,0x5000)],1,false,0);unsafe{t.setup();}let before=t.state();CALLER_TRACE.with(|c|c.borrow_mut().clear());COMPOSITION_ACTIVE.with(|c|c.set(true));let rc=unsafe{caller_run(&mut t,addr,len)};COMPOSITION_ACTIVE.with(|c|c.set(false));assert_eq!(rc,-22,"{addr:x} len {len:x}");assert_eq!(t.state(),before);assert!(t.events.is_empty());assert!(CALLER_TRACE.with(|c|c.borrow().is_empty()));assert!(!LOCK_HELD.with(|c|c.get()));
 }
 let mut t=Tree::new(&[(0x1000,0x5000)],1,false,0);unsafe{t.setup();}CALLER_TRACE.with(|c|c.borrow_mut().clear());COMPOSITION_ACTIVE.with(|c|c.set(true));let rc=unsafe{caller_run(&mut t,0x2000,1)};COMPOSITION_ACTIVE.with(|c|c.set(false));assert_eq!(rc,0);assert!(!LOCK_HELD.with(|c|c.get()));assert_eq!(CALLER_TRACE.with(|c|c.borrow().clone()),["lock","lookup","search","clear.enter","clear.exit","alloc","rbclear","insert","unlock"]);assert_eq!(t.live_ranges(),[(0x1000,0x2000),(0x2000,0x3000),(0x3000,0x5000)]);assert_eq!(t.nodes.len(),3);assert_eq!(t.nodes[2].numa_mem_policy,MPOL_DEFAULT);assert_eq!(t.nodes[2].numa_mask,[3,0,0,0]);assert!(t.freed.iter().all(|f|!*f));
 println!("actual mbind body: 4 empty/reversed/wrapped/rounding-overflow inputs rejected before lock/clear; 1 rounded valid split reaches proposed clear under writer lock and publishes replacement before unlock");
}
