"""Source-bound ordinary actual-body check; requires fresh root grant."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
D=Path(__file__).resolve().parent
binding=json.loads((D/'SOURCE-FREEZE.json').read_bytes())
for row in binding['inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert os.sched_getaffinity(0)=={6}
cc='/usr/bin/cc';rustc='/home/holden/.rustup/toolchains/1.85.1-x86_64-unknown-linux-gnu/bin/rustc'
commands=[('c-reference',[cc,'-std=c11','-Wall','-Wextra','-Werror','-c','actual_c_reference.c','-o','c-reference-1.o']),('c-selected-signature',[cc,'-std=c11','-Wall','-Wextra','-Werror','-c','actual_c_selected.c','-o','c-selected-1.o']),('rust-body-compile',[rustc,'--edition=2021','--test','-C','codegen-units=1','-C','debuginfo=0','-C','linker='+cc,'-C','link-arg=c-reference-1.o','-C','link-arg=c-selected-1.o','actual_body_tests.rs','-o','actual-body-tests-1']),('actual-body-test',[str(D/'actual-body-tests-1'),'--test-threads=1','--nocapture'])]
records=[]
for name,argv in commands:
 start=time.monotonic()
 with (D/(name+'.stdout')).open('xb')as out,(D/(name+'.stderr')).open('xb')as err:
  p=subprocess.Popen(argv,cwd=D,stdout=out,stderr=err,start_new_session=True)
  timed_out=False
  try:rc=p.wait(timeout=35)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 try:os.killpg(p.pid,0);absent=False
 except ProcessLookupError:absent=True
 row=dict(name=name,argv=argv,pid=p.pid,returncode=rc,direct_child_joined=True,group_absent=absent,timed_out=timed_out,seconds=time.monotonic()-start)
 for suffix in ('stdout','stderr'):
  path=D/(name+'.'+suffix);raw=path.read_bytes();row[suffix]=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 records.append(row);print(json.dumps(row),flush=True)
 if rc!=0 or not absent:break
result=dict(scope=binding['scope'],status='PASS_ACTUAL_CLEAR_BODY_AND_SELECTED_SIGNATURE_ONLY'if len(records)==4 and all(r['returncode']==0 and r['group_absent']for r in records)else'FAIL_PRESERVED_NO_RETRY',records=records,root_operations=0,guest_runs=0,default_link_native_acceptance=False)
with (D/'actual-body-result-1.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
raise SystemExit(0 if result['status'].startswith('PASS_')else 1)
