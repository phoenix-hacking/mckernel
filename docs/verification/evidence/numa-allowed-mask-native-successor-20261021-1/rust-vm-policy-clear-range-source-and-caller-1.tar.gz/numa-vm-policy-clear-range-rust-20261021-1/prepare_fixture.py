from pathlib import Path
import hashlib,json,difflib
D=Path(__file__).resolve().parent
R=Path('/home/holden/mckernel')
s=(R/'kernel/syscall.c').read_text()
r=(R/'kernel/rust/syscall_policy.rs').read_text()
def function(text,marker):
 p=text.index(marker); start=text.index('{',p); depth=1;i=start+1
 while depth:
  depth += (text[i]=='{')-(text[i]=='}');i+=1
 return text[p:i]+'\n'
clear=function(s,'static int vm_policy_clear_range(')
search=function(s,'struct vm_range_numa_policy *vm_range_policy_search(')
insert=function(s,'static int vm_policy_insert(')
(D/'original_clear_range.c').write_text(clear)
(D/'original_policy_search.c').write_text(search)
(D/'original_policy_insert.c').write_text(insert)
(D/'actual_rust_search.rs').write_text(function(r,'pub unsafe extern "C" fn syscall_vm_range_policy_search_body_result('))
(D/'actual_rust_insert.rs').write_text(function(r,'pub unsafe extern "C" fn syscall_vm_policy_insert_body_result('))
prefix='''#include <stddef.h>
#include <stdint.h>
#include <string.h>
#define EFAULT 14
#define ENOMEM 12
#define IHK_MC_AP_NOWAIT 0x204UL
struct rb_node { unsigned long parent_color; struct rb_node *rb_right, *rb_left; };
struct rb_root { struct rb_node *rb_node; };
struct vm_range_numa_policy { struct rb_node policy_rb_node; unsigned long start,end; unsigned long numa_mask[4]; int numa_mem_policy,il_prev; };
struct process_vm { unsigned char prefix[248]; struct rb_root vm_range_numa_policy_tree; unsigned char tail[48]; };
_Static_assert(sizeof(struct vm_range_numa_policy)==80,"policy ABI");
_Static_assert(offsetof(struct process_vm,vm_range_numa_policy_tree)==248,"root ABI");
extern void fixture_erase(struct rb_node *,struct rb_root *);
extern void fixture_free(void *);
extern struct rb_node *fixture_first(const struct rb_root *);
extern struct rb_node *fixture_next(const struct rb_node *);
extern void *fixture_alloc(size_t,unsigned long);
extern void fixture_clear(struct vm_range_numa_policy *);
extern int fixture_insert(struct process_vm *,struct vm_range_numa_policy *);
extern void fixture_log(int,int);
extern void fixture_link(struct rb_node *,struct rb_node *,struct rb_node **);
extern void fixture_color(struct rb_node *,struct rb_root *);
extern void fixture_insert_log(struct process_vm *,struct vm_range_numa_policy *,struct vm_range_numa_policy *);
#define rb_erase fixture_erase
#define kfree_tracked(p,f,l) fixture_free(p)
#define kmalloc_tracked(s,a,f,l) fixture_alloc(s,a)
#define rb_first fixture_first
#define rb_next fixture_next
#define RB_CLEAR_NODE(p) fixture_clear((struct vm_range_numa_policy *)((char *)(p)-offsetof(struct vm_range_numa_policy,policy_rb_node)))
#define dkprintf(...) fixture_log(0,0)
#define kprintf(f,n,e) fixture_log(1,e)
#define ekprintf(...) fixture_insert_log(vm,newrange,range)
#define rb_link_node fixture_link
#define rb_insert_color fixture_color
'''
# Original C insertion fallback uses its diagnostic callback only. Clear callback
# injection wrapper is distinct, so error paths can be observed before insertion.
insert=insert.replace('static int vm_policy_insert(', 'static int fixture_real_insert(')
# Replace success diagnostic macro's dkprintf path for insertion only.
reference=prefix+search+'\n#undef dkprintf\n#define dkprintf(...) fixture_insert_log(vm,newrange,NULL)\n'+insert+'\nint fixture_reference_insert(struct process_vm *vm,struct vm_range_numa_policy *p){return fixture_real_insert(vm,p);}\n#undef dkprintf\n#define dkprintf(...) fixture_log(0,0)\n#define vm_policy_insert fixture_insert\n'+clear+'\nint fixture_reference_clear(struct process_vm *vm,unsigned long s,unsigned long e){return vm_policy_clear_range(vm,s,e);}\n'
(D/'actual_c_reference.c').write_text(reference)
glue='''#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
extern int syscall_vm_policy_clear_range_body_result(struct process_vm *,
 unsigned long,unsigned long,size_t,unsigned long,
 void *(*)(size_t,unsigned long),void (*)(struct vm_range_numa_policy *),
 int (*)(struct process_vm *,struct vm_range_numa_policy *),
 void (*)(struct rb_node *,struct rb_root *),void (*)(void *),
 struct rb_node *(*)(const struct rb_root *),
 struct rb_node *(*)(const struct rb_node *),void (*)(int,int));
static void *syscall_vm_policy_clear_alloc_bridge(size_t size,unsigned long flags)
{ return kmalloc_tracked(size,flags,__FILE__,__LINE__); }
static void syscall_vm_policy_clear_rb_bridge(struct vm_range_numa_policy *p)
{ RB_CLEAR_NODE(&p->policy_rb_node); }
static void syscall_vm_policy_clear_free_bridge(void *p)
{ kfree_tracked(p,__FILE__,__LINE__); }
static void syscall_vm_policy_clear_log_bridge(int event,int error)
{
 if (event == 0) { dkprintf("%s: error allocating range_policy\\n","vm_policy_clear_range"); }
 else { kprintf("%s: ERROR: could not insert range: %d\\n","vm_policy_clear_range",error); }
}
#endif
'''
selected_body='''\n#ifdef MCKERNEL_RUST_SYSCALL_POLICY_HELPERS
 return syscall_vm_policy_clear_range_body_result(vm,start,end,
 sizeof(struct vm_range_numa_policy),IHK_MC_AP_NOWAIT,
 syscall_vm_policy_clear_alloc_bridge,syscall_vm_policy_clear_rb_bridge,
 vm_policy_insert,rb_erase,syscall_vm_policy_clear_free_bridge,
 rb_first,rb_next,syscall_vm_policy_clear_log_bridge);
#else
'''+clear[clear.index('{')+1:clear.rindex('}')]+'''#endif
}'''
replacement=glue+clear[:clear.index('{')+1]+selected_body+'\n'
(D/'c_glue.patch').write_text(''.join(difflib.unified_diff(clear.splitlines(True),replacement.splitlines(True),fromfile='a/kernel/syscall.c',tofile='b/kernel/syscall.c')))
# Same proposed C declaration and dispatch call compiled against the real Rust ABI.
(D/'actual_c_selected.c').write_text(prefix+'\n#define MCKERNEL_RUST_SYSCALL_POLICY_HELPERS 1\n#define vm_policy_insert fixture_insert\n'+replacement+'\nint fixture_selected_clear(struct process_vm *vm,unsigned long s,unsigned long e){return vm_policy_clear_range(vm,s,e);}\n')
(D/'SOURCE-BINDING.json').write_text(json.dumps({'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','source_only':True,'shared_writes':False,'original_source_sha256':hashlib.sha256(s.encode()).hexdigest(),'original_clear_sha256':hashlib.sha256(clear.encode()).hexdigest(),'source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file()},'abi':{'path':str(R/'kernel/rust/abi.rs'),'sha256':hashlib.sha256((R/'kernel/rust/abi.rs').read_bytes()).hexdigest()},'rbtree':{'path':str(R/'kernel/rust/rbtree.rs'),'sha256':hashlib.sha256((R/'kernel/rust/rbtree.rs').read_bytes()).hexdigest()}},indent=2)+'\n')
