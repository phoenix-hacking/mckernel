Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Private source proposal only. No shared kernel, Git, root, module or guest changes.
Production insertion copy and its frozen materialized source are untouched.

The proposed clear body uses existing ProcessVm/VmRangeNumaPolicy layouts and
existing Rust search and insertion exports. C additions are ABI declarations,
allocation/free/log/RB macro wrappers, and the macro-selected forwarding call;
the original C body remains exactly under #else. RB traversal, erase and insert
remain existing reviewed implementations; new compute is Rust only.

The existing writer lock/lifetime contract is caller-owned and unchanged.
Allocation is NOWAIT (production C constant forwarded, fixture sentinel 0x204).
The existing C ordering deliberately truncates before allocating. ENOMEM returns
with this truncation retained. Original insertion errors (negative OR positive)
return immediately after logging; allocated tail is neither published nor freed.
This inherited unreachable allocation is NOT resolved by this migration. A real
insertion error is reachable for reversed clear inputs. Independent ownership
review must decide whether retaining the original behavior is sufficient before
integration; source parity is not a memory-ownership acceptance claim.

RB_CLEAR_NODE only resets parent-color; freshly allocated child bytes and il_prev
remain allocator bytes until insertion initializes the RB children. Mask and
policy copy preserve only the original fields. No rollback, free, validation,
locking or normalization absent from the original C algorithm is introduced.
end-1 uses explicit unsigned wrapping. Empty/reversed input behavior is retained,
even when it creates a surprising range mutation or causes insertion rejection.

Reference: original_clear_range.c is byte-exact extracted current C function;
actual_c_reference.c prepends projected checked ABI plus observable callbacks.
The original search and insert bodies are also preserved. Reference clear runs
with original C search and C insertion body; selected clear dispatches Rust with
existing actual Rust search/insertion bodies and common actual RB implementation.
Callbacks record complete node/tree/allocation/free state before each operation.
Fixture retains freed allocation storage solely for post-call byte/state checks;
assertions track erase-before-free, exact callback order and unreachable tail.
C projected ABI checks do not replace production headers/whole-crate/link/native.

Next observation: fresh root-granted ordinary CPU6/1GiB profile runs four serial
commands in run_actual_body_checks.py. No compilation/test has run at freeze.
One failed candidate plus one bounded correction per family before escalation;
all failed streams/results retained, no unchanged deterministic replay.
