use abi::{CLong,VmRange,PROCESS_NUMA_MASK_WORDS};
use core::ptr::{write,read_volatile,write_volatile};
use std::cell::RefCell;
const EIO:CInt=5;
type SyscallCopyFromUserFn=unsafe extern "C" fn(*mut u8,CULong,SizeT)->CLong;
type SyscallRwlockFn=unsafe extern "C" fn(*mut c_void);
type SyscallLookupRangeFn=unsafe extern "C" fn(*mut ProcessVm,CULong,CULong)->*mut VmRange;
type SyscallPolicySearchFn=unsafe extern "C" fn(*mut ProcessVm,CULong)->*mut VmRangeNumaPolicy;
type SyscallPolicyClearRangeFn=unsafe extern "C" fn(*mut ProcessVm,CULong,CULong)->CInt;
type SyscallMbindLogFn=unsafe extern "C" fn(CInt,CULong,CULong,CInt);
include!("actual_mbind_body_and_dependencies.rs");
thread_local!{
 static COMPOSITION_ACTIVE:Cell<bool>=const{Cell::new(false)};
 static LOCK_HELD:Cell<bool>=const{Cell::new(false)};
 static CALLER_TRACE:RefCell<Vec<&'static str>>=const{RefCell::new(Vec::new())};
 static VM_RANGE:Cell<*mut VmRange>=const{Cell::new(null_mut())};
}
fn trace(s:&'static str){CALLER_TRACE.with(|t|t.borrow_mut().push(s));}
unsafe extern "C" fn caller_lock(lock:*mut c_void){with_tree(|t|assert_eq!(lock,addr_of_mut!((*t.vm).memory_range_lock).cast()));assert!(!LOCK_HELD.with(|c|c.replace(true)));trace("lock");}
unsafe extern "C" fn caller_unlock(lock:*mut c_void){with_tree(|t|assert_eq!(lock,addr_of_mut!((*t.vm).memory_range_lock).cast()));assert!(LOCK_HELD.with(|c|c.replace(false)));trace("unlock");}
unsafe extern "C" fn caller_lookup(vm:*mut ProcessVm,start:u64,end:u64)->*mut VmRange{assert!(LOCK_HELD.with(|c|c.get()));with_tree(|t|assert_eq!(vm,&mut*t.vm as*mut _));assert_eq!((start,end),(0x2000,0x3000));trace("lookup");VM_RANGE.with(|c|c.get())}
unsafe extern "C" fn caller_search(vm:*mut ProcessVm,addr:u64)->*mut VmRangeNumaPolicy{assert!(LOCK_HELD.with(|c|c.get()));trace("search");syscall_vm_range_policy_search_body_result(vm,addr)}
unsafe extern "C" fn caller_clear(vm:*mut ProcessVm,start:u64,end:u64)->i32{assert!(LOCK_HELD.with(|c|c.get()));assert!(start<end);trace("clear.enter");let rc=fixture_selected_clear(vm,start,end);assert!(LOCK_HELD.with(|c|c.get()));assert_eq!(rc,0);with_tree(|t|assert_eq!(t.live_ranges(),[(0x1000,0x2000),(0x3000,0x5000)]));trace("clear.exit");rc}
unsafe extern "C" fn caller_alloc(size:SizeT,flags:u64)->*mut c_void{assert!(LOCK_HELD.with(|c|c.get()));trace("alloc");fixture_alloc(size,flags)}
unsafe extern "C" fn caller_rb_clear(p:*mut VmRangeNumaPolicy){trace("rbclear");fixture_clear(p);}
unsafe extern "C" fn caller_insert(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy)->i32{trace("insert");fixture_insert(vm,p)}
unsafe fn caller_run(t:&mut Tree,addr:u64,len:u64)->CLong{t.activate();mbind_body_result(addr,len,MPOL_DEFAULT,0,0,0,&mut*t.vm,0,0,2,80,0x204,None,Some(caller_lock),Some(caller_unlock),Some(caller_lookup),Some(caller_search),Some(caller_clear),Some(caller_alloc),Some(caller_rb_clear),Some(caller_insert),None)}
#[test]fn current_mbind_caller_range_validation_and_writer_locked_split(){
 let mut range:Box<VmRange>=Box::new(unsafe{core::mem::zeroed()});VM_RANGE.with(|c|c.set(&mut*range));
 // Exact existing mbind_prepare_range must reject before acquiring a writer lock
 // or calling lookup/search/clear. Reversed endpoints use wrapped unsigned len.
 for (addr,len)in [(0x2000,0),(0x2000,0x1000u64.wrapping_sub(0x2000)),(u64::MAX-0xfff,0x2000),(0x2000,u64::MAX)]{
  let mut t=Tree::new(&[(0x1000,0x5000)],1,false,0);unsafe{t.setup();}let before=t.state();CALLER_TRACE.with(|c|c.borrow_mut().clear());COMPOSITION_ACTIVE.with(|c|c.set(true));let rc=unsafe{caller_run(&mut t,addr,len)};COMPOSITION_ACTIVE.with(|c|c.set(false));assert_eq!(rc,-22,"{addr:x} len {len:x}");assert_eq!(t.state(),before);assert!(t.events.is_empty());assert!(CALLER_TRACE.with(|c|c.borrow().is_empty()));assert!(!LOCK_HELD.with(|c|c.get()));
 }
 let mut t=Tree::new(&[(0x1000,0x5000)],1,false,0);unsafe{t.setup();}CALLER_TRACE.with(|c|c.borrow_mut().clear());COMPOSITION_ACTIVE.with(|c|c.set(true));let rc=unsafe{caller_run(&mut t,0x2000,1)};COMPOSITION_ACTIVE.with(|c|c.set(false));assert_eq!(rc,0);assert!(!LOCK_HELD.with(|c|c.get()));assert_eq!(CALLER_TRACE.with(|c|c.borrow().clone()),["lock","lookup","search","clear.enter","clear.exit","alloc","rbclear","insert","unlock"]);assert_eq!(t.live_ranges(),[(0x1000,0x2000),(0x2000,0x3000),(0x3000,0x5000)]);assert_eq!(t.nodes.len(),3);assert_eq!(t.nodes[2].numa_mem_policy,MPOL_DEFAULT);assert_eq!(t.nodes[2].numa_mask,[3,0,0,0]);assert!(t.freed.iter().all(|f|!*f));
 println!("actual mbind body: 4 empty/reversed/wrapped/rounding-overflow inputs rejected before lock/clear; 1 rounded valid split reaches proposed clear under writer lock and publishes replacement before unlock");
}
