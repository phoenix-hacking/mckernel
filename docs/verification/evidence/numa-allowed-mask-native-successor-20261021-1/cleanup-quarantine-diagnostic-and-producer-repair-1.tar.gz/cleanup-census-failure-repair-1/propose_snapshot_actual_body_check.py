#!/usr/bin/env python3
"""UNRUN deterministic exact producer-body regression; no real /proc/root/census.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Root must clear source-job hold and grant existing CPU6 ordinary profile first.
"""
from pathlib import Path
import ast,hashlib,io,json,os,types
R=Path(__file__).resolve().parent
BEFORE='25e8657a301c6d486833de7bf8f6cdd7ebc360d9930a997809b3089b16551633'
AFTER='5f6716a8914564cfae06693931033fa2efacae49aaf2e21f18600463b376d21d'
def sha(b):return hashlib.sha256(b).hexdigest()
def stat_bytes(pid,ppid,start,malformed=False):
 if malformed:return (str(pid)+' (fixture) S 0\n').encode()
 fields=['S']+['0']*49;fields[1]=str(ppid);fields[19]=str(start)
 return (str(pid)+' (fixture) '+' '.join(fields)+'\n').encode()
def process(pid,ppid=1,start=None,exe='/usr/bin/true'):
 return dict(pid=pid,ppid=ppid,start=pid*10 if start is None else start,exe=exe,argv=[exe])
BASE={1:process(1,0,1,'/usr/bin/init'),10:process(10,1,100,'/usr/bin/python3'),20:process(20),30:process(30)}
class ProcFixture:
 def __init__(self,mode):self.mode=mode;self.attempt=0;self.read_counts={};self.path=types.SimpleNamespace(basename=os.path.basename)
 def listdir(self,path):
  assert path=='/proc';self.attempt+=1
  if self.mode=='process-count':return ['n']*4097
  if self.mode in ('owned-prefix','publisher-prefix','publisher-confirmation','descendant-prefix') and self.attempt>1:return ['1','10']
  if self.mode in ('benign-first-stat','mid-read-owned') and self.attempt>1:return ['1','10','20']
  return ['1','10','20','30']
 def entry(self,pid):
  value=dict(BASE[pid])
  if self.mode in ('publisher-prefix','publisher-confirmation') and pid==20:value.update(exe='/usr/bin/make',argv=['/usr/bin/make'])
  if self.mode=='descendant-prefix' and pid==20:value['ppid']=999
  if self.mode=='PID-reuse' and self.attempt>1 and pid==20:value['start']+=1
  if self.mode=='caller-reuse' and pid==10:value['start']+=1
  return value
 def read(self,path):
  parts=path.split('/');assert len(parts)==4 and parts[:2]==['','proc'];pid=int(parts[2]);name=parts[3]
  key=(self.attempt,pid,name);self.read_counts[key]=self.read_counts.get(key,0)+1
  if self.mode=='publisher-confirmation' and pid==20 and name=='stat' and self.attempt==1 and self.read_counts[key]==2:raise FileNotFoundError(2,'fixture-gone',path)
  if self.mode=='permission' and pid==20 and name=='stat':raise PermissionError(13,'fixture-permission',path)
  if self.mode=='foreign-ENOENT' and pid==20 and name=='stat':raise FileNotFoundError(2,'fixture-foreign','/tmp/not-a-proc-file')
  if pid==30 and name=='stat' and self.mode in ('benign-first-stat','owned-prefix','publisher-prefix','descendant-prefix','PID-reuse','persistent-ENOENT') and (self.attempt==1 or self.mode=='persistent-ENOENT'):raise FileNotFoundError(2,'fixture-gone',path)
  if self.mode=='mid-read-owned' and pid==30 and name=='cmdline' and self.attempt==1:raise FileNotFoundError(2,'fixture-gone',path)
  entry=self.entry(pid)
  if name=='stat':return stat_bytes(pid,entry['ppid'],entry['start'],self.mode=='malformed' and pid==20)
  if name=='cmdline':return ('\0'.join(entry['argv'])+'\0').encode()
  raise AssertionError(path)
 def open(self,path,mode):assert mode=='rb';return io.BytesIO(self.read(path))
 def readlink(self,path):
  parts=path.split('/');assert parts[3]=='exe';return self.entry(int(parts[2]))['exe']
def load(name,pin,mode):
 raw=(R/name).read_bytes();assert sha(raw)==pin
 module=ast.parse(raw);proc=ast.literal_eval(next(n.value for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROC_CODE' for t in n.targets)))
 tree=ast.parse(proc);nodes=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in ('publisher','snapshot','_snapshot_once')) or (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='heavy' for t in n.targets))]
 fixture=ProcFixture(mode);ns=dict(os=fixture,open=fixture.open,caller=[10,'100'],caller_parent=1)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'<whole actual PROC_CODE functions>','exec'),ns)
 return ns,fixture,module,proc
class Refusal(ValueError):pass
def validator(module):
 node=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='validate_process_report')
 ns=dict(Refusal=Refusal,BOOT_ID='fixture-boot',OWNER_PID=999,WAITER_PIDS=(998,))
 exec(compile(ast.Module(body=[node],type_ignores=[]),'<whole actual report validator>','exec'),ns)
 return ns
def report(ns):
 a,p=ns['snapshot']();b,q=ns['snapshot']()
 return dict(schema='fp-save-image.proc.v1',uid=0,boot_id='fixture-boot',challenge='fixture',caller=[10,'100'],publishers=p+q,snapshots=[a,b])
def main():
 results=[]
 # Original exact failure is reproduced, not relabeled as a pass.
 ns,f,module,proc=load('cleanup_pass_image.before.py',BEFORE,'benign-first-stat')
 try:ns['snapshot']()
 except FileNotFoundError as e:assert e.filename=='/proc/30/stat' and f.attempt==1
 else:raise AssertionError('baseline race did not reproduce')
 results.append('baseline exact FileNotFoundError preserved')
 ns,f,module,proc=load('cleanup_pass_image.proposed.py',AFTER,'benign-first-stat');v=validator(module);r=report(ns);v['validate_process_report'](r,'fixture',[10,'100']);assert f.attempt==3
 results.append('candidate two complete sweeps after one whole-sweep retry')
 for mode,owner,publisher in [('owned-prefix',20,False),('mid-read-owned',30,False),('publisher-prefix',999,True),('publisher-confirmation',999,True),('descendant-prefix',999,False)]:
  ns,f,module,proc=load('cleanup_pass_image.proposed.py',AFTER,mode);v=validator(module);v['OWNER_PID']=owner;r=report(ns)
  if publisher:assert r['publishers']
  else:assert any(row[0]==owner or (mode=='descendant-prefix' and row[1]==owner) for row in r['snapshots'][0])
  try:v['validate_process_report'](r,'fixture',[10,'100'])
  except Refusal as error:assert str(error)==('concurrent-build-or-cleanup-publisher' if publisher else 'owner-waiter-or-descendant-present')
  else:raise AssertionError('lost conservative evidence: '+mode)
  results.append(mode+' still refused')
 for mode,kind,attempts in [('PID-reuse',ValueError,2),('persistent-ENOENT',ValueError,3),('permission',PermissionError,1),('foreign-ENOENT',FileNotFoundError,1),('malformed',ValueError,1),('caller-reuse',ValueError,1),('process-count',ValueError,1)]:
  ns,f,module,proc=load('cleanup_pass_image.proposed.py',AFTER,mode)
  try:ns['snapshot']()
  except kind:assert f.attempt==attempts,(mode,f.attempt)
  else:raise AssertionError('unsafe acceptance: '+mode)
  results.append(mode+' bounded refusal')
 # Normal stable producer/validator behavior and challenge/boot/caller checks remain.
 ns,f,module,proc=load('cleanup_pass_image.proposed.py',AFTER,'stable');v=validator(module);r=report(ns);v['validate_process_report'](r,'fixture',[10,'100']);assert f.attempt==2
 for key,value in [('boot_id','other-boot'),('challenge','other-challenge'),('caller',[10,'999'])]:
  changed=dict(r);changed[key]=value
  try:v['validate_process_report'](changed,'fixture',[10,'100'])
  except Refusal:pass
  else:raise AssertionError('binding relaxed: '+key)
 results.append('stable report and boot/challenge/caller bindings unchanged')
 print(json.dumps(dict(status='PASS_ACTUAL_PRODUCER_BODY_RACE_AND_STRICT_PREDICATES_ONLY',checks=results,real_proc_reads=False,root_actions=False,cleanup_execution=False,quarantine_or_owner_edits=False),sort_keys=True))
if __name__=='__main__':main()
