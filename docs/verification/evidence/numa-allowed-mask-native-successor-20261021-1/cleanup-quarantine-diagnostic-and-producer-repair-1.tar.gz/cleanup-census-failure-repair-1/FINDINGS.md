# Focused process-census producer correction — SOURCE ONLY

Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

The actual root `/usr/bin/python3 -I -B -c PROC_CODE ...` census failed on a numeric PID listed by `/proc` that disappeared before its first stat read. That read is unconditional in the accepted producer. This is a host process-lifetime race, not a failed target-retirement proof or a kernel/app defect. The failed child and quarantined cleanup remain preserved; this packet neither changes nor releases them.

The source confirms `quarantine_wait()` only sleeps/catches exceptions and performs no census. No live process probe, census, cleanup, root action, candidate import or test was executed by this preparation.

Only the embedded `PROC_CODE` assignment changes. `snapshot()` retries a complete sweep at most three times for an exact `/proc/<decimal-pid>/{stat,cmdline,exe}` FileNotFoundError. A failed sweep never produces an accepted report. Each successful report carries the conservative union of all first-stat-validated rows from its attempted sweeps, including partial parent links. A conflicting PID/birth/parent row refuses. The original consumer therefore sees historical owned/descendant presence instead of silently losing it. The publisher classification is retained immediately after complete cmdline/exe evidence, before the still-required confirmation stat; observed publishers survive an interrupted sweep. Stable confirmation and actual caller presence remain required in the successful sweep. Retried churn exhausts into a strict failure after three attempts.

This changes process-census infrastructure only. It grants no cleanup authority, no runtime acceptance and no physical clearance. Every engine function/class AST, including `validate_process_report`, transaction/ownership/resource/cleanup/quarantine operations, remains identical to the active engine. The original report schema remains `fp-save-image.proc.v1`; no alias or new runtime gate is introduced.

## Complete focused invariant matrix

| Predicate | Source/result requirement |
| --- | --- |
| Numeric PID list / count | Original numeric selection and per-sweep 4096 cap; new retained-union cap4096; no unreadable per-row skip. |
| Stat shape / size / state / numeric fields | Original first-stat 64KiB, prefix, 50field, state and numeric checks retained verbatim. |
| PID lifetime | Original second-stat start comparison retained. Retried observation with changed birth or parent refuses. |
| Cmdline / exe | Original length, NUL, UTF8, argv-count, argument-length, live-empty restrictions retained. |
| Missing proc leaf | Whole-sweep retry only for numeric proc stat/cmdline/exe ENOENT; bounded3; other exceptions/malformed records stay fatal. |
| Caller / sudo parent | Original exact caller birth/presence and caller-parent sudo exclusion retained. |
| Publisher | Original classifier/exclusions retained; classification recorded before confirmation read, retained across attempts and remains an unconditional consumer refusal. |
| Owner/waiter / descendants | Original exact PID and transitive parent closure unchanged, including PID reuse refusal; partial rows remain visible to that closure. |
| Two snapshots / boot / challenge | Original two successful snapshots, producer boot reread, root EUID, exact caller and consumer boot/challenge bindings unchanged. |
| Docker / targets / resources / ownership | All engine operational functions/classes AST-identical; no container/target, release, lease, lock, resource-floor or cleanup changes. |
| Failure history | Original25e engine and failed real capture unchanged. First pre-review proposal preserved as `.source-review-v1`; reviewer-found publisher-confirmation gap corrected before execution. |

## One next actual observation

After root clears its source-job hold and grants the existing ordinary CPU6 envelope, root runs exactly the argv in `PROPOSED-CHEAP-CHECK.json` under its existing outer capture/direct-wait route. The fixture extracts whole actual `publisher`/`snapshot`/`_snapshot_once` functions and the unchanged report validator into a deterministic fake-proc environment. It reads no real `/proc`, performs no privilege operations and executes no cleanup. It reproduces the exact baseline FileNotFoundError, then checks two completed candidate sweeps and strict refusal for observed owner, partial descendant, publisher prefix, publisher disappearing at confirmation stat, PID reuse, exhausted churn, permission/unrelated errors, malformed records, caller reuse, process cap and changed report bindings. This is an actual-body check, not a live-census or cleanup acceptance.

Keep stdout/stderr/status and direct-join/group-absence in a fresh `actual-producer-body-check-capture-1/` root-owned capture. A second actual failure in this family requires root strategy/expert decision, with no unchanged replay. Only after a genuine positive body check and independently reviewed new execution binding may root choose a successor cleanup source/release; never patch or rerun the quarantined active instance.
