Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Frozen finite read-only diagnostic source + exact target/resource/capture proposal.
No import/test/execution by worker; no root action, locks, signals or engine import.
Exact final release094 authenticates all seven transaction paths plus original
common/shared ownership paths. Raw control/ownership bytes preserve plan/journal/
quarantine details; CAPTURE exports only streamed hash+size. Typed ENOENT/parse/read
errors and full9 FD/named identities preserve uncertainty. Target directories list
<=32directentries only, no walk. Active capture child-start/stdout/stderr remain
explicitly nonfinal. /proc/locks selects27:4 then reads only that actualholder birth,
cmdline/status/exe and relevant rootlock/MUTEX fdinfo, not a general census.

Root chooses/records actual read-only execution release and capture. Current sleeping
owner10482 remains live; outer2575747 is not assumed actualholder. Diagnostic output
cannot authorize cleanup, lock release or recovery. Original quarantine/state and
all prior bytes remain unchanged.
