Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Reader first: read_two_retirement_receipts.py and its exact bounded CPU7/1GiB/
30CPU/32MiB proposal were frozen and sent for review. Actualcomplete db6926 authenticates
preparedSHA. Root must obtain actualtwofile export and independent acceptance, preserving
original10482 failedclose-9/directjoin/streams/group proof. Worker performed no execution.

Existing strictfresh checker rejects both retained temporary MUTEX and QUARANTINE.
Existing nonfresh engine run(False) can reuse0Bmutex only after quarantine removal;
there is no unchanged checker route that both retainsquarantine and validates. Do not
rename this into freshvalidation or weaken the existing checker.

Proposed smallest strict route is a separate exact27:4 lockheld transition archiving
both retired temporary mutex116297 and quarantine116298 via same-filesystem
RENAME_NOREPLACE, full9+hash pins before and originalinode/bytes after, fsync plus
durableprepared/completion and uncertaintyhold. Permanentlock27:4 and original
common/shared ownership records are never unlinked/renamed. Future archive names and
all mutation authority remain proposals; root/source_review owns exactsource/release.
No cleanup effects are bundled and no new framework is proposed.

Only then bind genuine correctedsource5f67 FDidentity/review+coupled consumers and
new same finalcleanuprelease. Original25e/failure/rawfive remain historical exactbytes.
Run existing strictfresh preflight against that same finalrelease; its real container/
logs/census/protected/UUID predicates remain mandatory, not assumed passed from archive
nameabsence. Root already has selectedfix/15checks; do not replay observer/raw5/fixtures/
source/materialization. All futureeffects/authority in the JSON proposal remain null.
