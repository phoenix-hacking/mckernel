Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Concrete current one-holder retirement source/command ready for independent review.
No effects by worker. Current target root2575750/start37684618, parent/group2575747,
fd3permanent27:4/fd6empty116297 and original quarantine116298bc4b are bound from
accepted14a185 state. Historicalpidfdhelper is an ancestry pattern, never oldtarget
80259 authority. This finite variant has no general census, Docker or engine import.

Protocol retains exactcurrent argv/exe/credentials/threads/source/birth+holderFDs,
two preserved full9/hash snapshots, fresh durable prepared record, one pidfd SIGKILL
budget with no numeric/group fallback, pidfdexit plus bounded originalparent reap,
replacement27:4 acquisition, stable original records/quarantine/mutex/source and
durablecomplete. Errors after attempted signal enter uncertain nonreturning ownership
hold and consume budget. Critical profile requires unlimited inherited CPU/no outer
kill. Source publication and exact independent canonical-payload execution review
remain unbound; root alone may fill actual reviewed release and execute.

Ending scope is idle holder retirement only. Root originalcaller10482 positivejoin
and its actual tool/rootbirth evidence are separate future proof. Source completes
then closes only its newly acquired replacementlock; no prior lock is manually
unlocked, no records/containers/quarantine/mutex are removed/renamed. Root then
requires separate lockheld reconciliation authority. Existing freshpreflight rejects
retained MUTEX/QUARANTINE; this command does not restore fresh3-op eligibility or
replay unchanged cleanup. Preserve all current bytes and failed evidence.
