"""Cheapest actual batch terminal-body comparison; ordinary only, no census/root."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os
R=Path(__file__).resolve().parent
SOURCE=R/'source-correction-1/root_manual_snapshot_three_round_native.py'
SOURCE_SHA='2f7d65137680d31eebdf236a84b6203931f57988046bb825bf063c6db78e6b8f'
DATA=R/'CURRENT-NATIVE-AND-RELEASED-RECORD-PREDECESSOR-DATA.json'
DATA_SHA='7ac74c6edf3f47e1bc89b11b82e45064ee703360474bc2b872594e6a364cbff0'
class Refusal(RuntimeError):pass
def frozen(p,h):
 raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==h;return raw
text=frozen(SOURCE,SOURCE_SHA).decode();b=json.loads(frozen(DATA,DATA_SHA))
ns=dict(Path=Path,hashlib=hashlib,importlib=importlib,json=json,os=os,Refusal=Refusal)
tree=ast.parse(text)
for name in ('need','checked','terminal_joins'):
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name)
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(SOURCE),'exec'),ns)
t=ns['checked'](b['physical_review']);ns['terminal_joins'](t,b)
controls=[]
for label,path,value in [
 ('current-native-CID',('physical_predecessor','container_id'),'0'*64),
 ('permanent-root-lock',('root_lock_identity','inode'),5),
 ('native-tool-pair',('native_controller_pair','sha256'),'0'*64),
 ('released-record-provenance',('released_record_predecessor','owner_nonce'),'wrong-owner')]:
 changed=copy.deepcopy(b);changed[path[0]][path[1]]=value
 try:ns['terminal_joins'](t,changed)
 except Refusal:controls.append(label)
 else:raise AssertionError('accepted changed boundary: '+label)
print(json.dumps(dict(status='PASS_ACTUAL_SIX_BATCH_CURRENT_NATIVE_PREDECESSOR_BODY_ONLY',positive=1,refusals=controls,refusal_count=len(controls),root_actions=False,census=False,guest=False,stage=False,runtime_release=False),sort_keys=True))
