# Read-mode source/ABI finding

Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

The cause-supported repair belongs in the existing Rust launcher: its `PLD_MPOL_MAX` constant is4, while both producer/consumer protocol headers reserve5 for unspecified and4 for explicit LOCAL. Change only that constant to5. Preserve frozen app0863, the getter, public LOCAL4 and host sentinel5. Producer owner has been informed; no source was changed here.

The 39-byte native stderr supplied by root is exactly `FAIL stage=read-mode raw=4 unmap_raw=0\n`. In app `numa_interval_app.rs` lines40–45, rawsyscall0 and all mode/mask guards pass before line45 rejects modes outside0..3. Its diagnostic `raw=4` is the returned i32mode, not syscall return4. The first query is baseline `policy(0,0)` at63, so flags0/address0, before neighbor queries and mbind. Registers are rax239/rdi pointer to interiori32/rsi pointer to fourinterioru64/rdx256/r10zero/r8zero. Rust native getter12856 reads those exact registers; mode copy8288 is sizeofCInt/i32=4. No enum width or register conversion defect is evidenced.

## Exact accepted materialized source chain

All paths below are relative to the accepted allowed-mask image source-materialization-1/materialized-source, with exact refs in RESULT.json.

| Boundary | Exact location | Meaning |
| --- | --- | --- |
| Launcher Rust value | executer/user/rust/mcexec_helpers.rs85 | `PLD_MPOL_MAX=4`, the defect. |
| Production caller | same3790,4011,4026 | `mcexec_main_body` passes its hardcoded PLD_MPOL_MAX into actual `mcexec_apply_desc_runtime_body`. |
| Runtime producer | same6432,6463–6471 | Parameter is forwarded unchanged as last arg of existing C bridge. |
| Existing ABI glue | executer/user/mcexec.c2290–2301 | Bridge assigns `desc->mpol_mode=pld_mpol_max`; no conversion. |
| Canonical load ABI | executer/include/uprotocol.h119–125; kernel/include/syscall.h190–196 | DEFAULT0/PREFERRED1/BIND2/INTERLEAVE3/LOCAL4/MAX5. |
| Initialized VM | kernel/rust/process_helpers.rs6408 | Process policy starts DEFAULT0. |
| Host production constant/caller | kernel/rust/host_helpers.rs111,4967 | Canonical MPOL_MAX5 supplied to host prepare. |
| Host branch | same1886–1907 | No bindmask: supplied mode4!=sentinel5, therefore enters explicit-policy branch. |
| Host publication | same1805 | Copies descriptor mode4 to VM policy; clears/copies policy mask. |
| Getter | kernel/rust/syscall_policy.rs8283–8295 | Flags0 reads VM policy and copies i32mode verbatim. |
| C getter reference | kernel/syscall.c12160–12172 | Same intpolicy copy; no intended4→0 translation. |

Linux installed UAPI `/usr/include/linux/mempolicy.h` and McKernel `kernel/include/process.h` explicitly define public MPOL_LOCAL4. Therefore4 is not an internal enum requiring conversion. The app’s0..3 domain is narrower than all public Linux modes, but broadening the oracle would hide this specific default-route sentinel bug. With the corrected unspecified5, the host skips explicit publication and preserves initializedDEFAULT0; explicitLOCAL4 must continue to remain distinct.

The accepted Linux reference3abbf0e8 proves the exact app’s actual116-byte/empty-stderr/exit37 run, not that all inherited public modes were covered. No accepted reference bytes are changed/replayed. We infer syscall0/guards and failure-beforembind from the frozen app and supplied stderr; no actual register or VM-last-write dump was read. The precise runtime last write remains an inference from the bound production callchain, not a claimed trace.

The producer lane owns its one-constant private candidate and cheapest actual-body default-sentinel comparison. That test should bind the actualmain constant/caller plus runtime descriptor producer so passing a manually supplied5 cannot mask the original hardcoded4. Include canonical unspecified5 preserving DEFAULT0 and explicitLOCAL4 remaining4; no broad oracle edits or new kernel image are demanded by this launcher-only repair. Root owns integration, launcher production rebuild/link/release and any actual guest attempt. This lane performed only focused read-only inspection and these reports.
