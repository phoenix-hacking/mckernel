from pathlib import Path
import hashlib,json,difflib
D=Path(__file__).resolve().parent;P=D.parent;R=Path('/home/holden/mckernel')
s=(P/'clear_range_contract_v2.rs').read_text()
s=s.replace('/// Clears policy ranges with the original C ordering and partial mutations.','/// Clears policy ranges with original ordering and partial mutations, initializing\n/// the new tail interleave cursor before publication.')
s=s.replace('// C copies only mask, leaving il_prev and RB child bytes alone.','// Initialize without reading the source cursor: noninterleave\n                    // source policies need not have an initialized il_prev.\n                    (*tail).il_prev = (PROCESS_NUMA_MASK_BITS - 1) as CInt;\n                    // Copy only the existing policy mask; RB children are set by insert.')
(D/'clear_range_cursor_initialized.rs').write_text(s)
original=(P/'clear_range_contract_v2.rs').read_text();(D/'original_uncorrected_body.rs').write_text(original[original.index('#[no_mangle]'):].replace('fn syscall_vm_policy_clear_range_body_result(', 'fn original_uncorrected_clear_body('))
(D/'rust_cursor_initialization.patch').write_text(''.join(difflib.unified_diff((P/'clear_range_contract_v2.rs').read_text().splitlines(True),s.splitlines(True),fromfile='clear_range_contract_v2.rs',tofile='clear_range_cursor_initialized.rs')))
mem=(R/'kernel/rust/mem_helpers.rs').read_text()
def function(text,marker):
 p=text.index(marker);i=text.index('{',p)+1;depth=1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[p:i]+'\n'
markers=['pub unsafe extern "C" fn mem_policy_fields_result(', 'pub unsafe extern "C" fn mem_interleave_nodes_result(', 'pub extern "C" fn mem_alloc_policy_should_try_policy_result(', 'pub extern "C" fn mem_alloc_node_id_valid_result(', 'pub extern "C" fn mem_alloc_policy_inputs_valid_result(', 'pub extern "C" fn mem_alloc_order_node_result(', 'unsafe fn mem_try_alloc_node(', 'unsafe fn mem_finish_alloc(', 'pub unsafe extern "C" fn mem_mckernel_alloc_policy_result(']
constants='\n'.join(line for line in mem.splitlines() if line.startswith('const MPOL_') or line.startswith('const MEM_ALLOC_LOG_') or line.startswith('const IHK_MC_AP_USER:'))+'\n'
types='\n'.join(line for line in mem.splitlines() if line.startswith(('type MemTryAllocNodeFn =','type MemDistanceIdFn =','type MemMaskTestFn =','type MemInterleaveNextFn =','type MemRusageAddFn =','type MemPhysToVirtFn =','type MemAllocLogFn =')))+'\n'
(D/'actual_allocator_consumer.rs').write_text(constants+types+'\n'.join(function(mem,m)for m in markers))
for n in ['actual_rust_search.rs','actual_rust_insert.rs']:(D/n).write_bytes((P/n).read_bytes())
# The existing C forwarding object is reused, never rewritten.
inputs=[p for p in D.iterdir()if p.is_file() and p.name!='SOURCE-FREEZE.json']+[P/'c-selected-1.o',R/'kernel/rust/abi.rs',R/'kernel/rust/rbtree.rs']
record={'scope':'Functional McKernel OS/apps and Rust/assembly migration only; no security testing.','candidate_executed':False,'reason':'reviewer supported interleave tail cursor read-before-write source finding; not native failure','prior_clear_contract_sha256':hashlib.sha256((P/'clear_range_contract_v2.rs').read_bytes()).hexdigest(),'actual_mem_helpers_source_sha256':hashlib.sha256(mem.encode()).hexdigest(),'new_compute_C':False,'original_C_fallback_changed':False,'prior_parity_replay':False,'command':['/home/holden/anaconda3/bin/python3.9','-I','-B',str(D/'run_focused_check.py')],'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in sorted(inputs)],'failure_history':[],'production_native_link_acceptance':False}
(D/'SOURCE-FREEZE.json').write_text(json.dumps(record,indent=2)+'\n');print(hashlib.sha256((D/'SOURCE-FREEZE.json').read_bytes()).hexdigest())
