#![allow(dead_code)]
#[path="/home/holden/mckernel/kernel/rust/abi.rs"] mod abi;
#[path="/home/holden/mckernel/kernel/rust/rbtree.rs"] mod rbtree;
use abi::{AbiRbNode,AbiRbRoot,CInt,CULong,SizeT,ProcessVm,VmRangeNumaPolicy};
use core::ffi::c_void;
use core::mem::{MaybeUninit,offset_of,size_of};
use core::ptr::{addr_of,addr_of_mut,null_mut};
use std::cell::{Cell,RefCell};
const EINVAL:CInt=22;const EFAULT:CInt=14;const ENOMEM:CInt=12;
const PROCESS_NUMA_MASK_BITS:CULong=256;
type SyscallPolicyAllocFn=unsafe extern "C" fn(SizeT,CULong)->*mut c_void;
type SyscallPolicyRbClearFn=unsafe extern "C" fn(*mut VmRangeNumaPolicy);
type SyscallPolicyInsertFn=unsafe extern "C" fn(*mut ProcessVm,*mut VmRangeNumaPolicy)->CInt;
type SyscallPolicyRbLinkFn=unsafe extern "C" fn(*mut AbiRbNode,*mut AbiRbNode,*mut*mut AbiRbNode);
type SyscallPolicyRbInsertColorFn=unsafe extern "C" fn(*mut AbiRbNode,*mut AbiRbRoot);
type SyscallPolicyInsertLogFn=unsafe extern "C" fn(*mut ProcessVm,*mut VmRangeNumaPolicy,*mut VmRangeNumaPolicy);
include!("actual_rust_search.rs");
include!("actual_rust_insert.rs");
include!("clear_range_cursor_initialized.rs");
include!("original_uncorrected_body.rs");
include!("actual_allocator_consumer.rs");
unsafe extern "C"{fn fixture_selected_clear(vm:*mut ProcessVm,start:u64,end:u64)->i32;}
thread_local!{
 static TAIL:Cell<*mut VmRangeNumaPolicy>=const{Cell::new(null_mut())};
 static SOURCE:Cell<*mut VmRangeNumaPolicy>=const{Cell::new(null_mut())};
 static POLICY:Cell<i32>=const{Cell::new(0)};
 static CORRECTED:Cell<bool>=const{Cell::new(true)};
 static EVENTS:RefCell<Vec<&'static str>>=const{RefCell::new(Vec::new())};
 static NODES:RefCell<Vec<i32>>=const{RefCell::new(Vec::new())};
 static CURSORS:RefCell<Vec<i32>>=const{RefCell::new(Vec::new())};
 static ACCOUNT:RefCell<Vec<i32>>=const{RefCell::new(Vec::new())};
}
fn event(s:&'static str){EVENTS.with(|e|e.borrow_mut().push(s));}
#[no_mangle]unsafe extern "C" fn fixture_alloc(size:SizeT,flags:u64)->*mut c_void{assert_eq!(size,80);assert_eq!(flags,0x204);event("alloc");let original=SOURCE.with(|c|c.get());assert_eq!((*original).end,0x2000);let p=TAIL.with(|c|c.get());assert_ne!(p,original);assert_eq!((*p).il_prev,2,"stale reused cursor before clear initialization");p.cast()}
#[no_mangle]unsafe extern "C" fn fixture_clear(p:*mut VmRangeNumaPolicy){event("rbclear");(*p).policy_rb_node.__rb_parent_color=addr_of_mut!((*p).policy_rb_node)as u64;}
#[no_mangle]unsafe extern "C" fn fixture_insert(vm:*mut ProcessVm,p:*mut VmRangeNumaPolicy)->i32{event("insert");assert_eq!(p,TAIL.with(|c|c.get()));assert_eq!((*p).il_prev,if CORRECTED.with(|c|c.get()){255}else{2},"cursor before RB publication");assert_eq!((*p).numa_mem_policy,POLICY.with(|c|c.get()));assert_eq!((*p).numa_mask,[0x24,0,0,0]);syscall_vm_policy_insert_body_result(vm,p,Some(fixture_link),Some(fixture_color),Some(fixture_insert_log))}
unsafe extern "C" fn fixture_link(p:*mut AbiRbNode,parent:*mut AbiRbNode,slot:*mut*mut AbiRbNode){event("link");rbtree::rb_link_node(p.cast(),parent.cast(),slot.cast());}
unsafe extern "C" fn fixture_color(p:*mut AbiRbNode,root:*mut AbiRbRoot){event("color");rbtree::rb_insert_color(p.cast(),root.cast());}
unsafe extern "C" fn fixture_insert_log(_: *mut ProcessVm,_:*mut VmRangeNumaPolicy,overlap:*mut VmRangeNumaPolicy){assert!(overlap.is_null());event("insertlog");}
#[no_mangle]unsafe extern "C" fn fixture_erase(_: *mut AbiRbNode,_:*mut AbiRbRoot){panic!("split must not erase")}
#[no_mangle]unsafe extern "C" fn fixture_free(_: *mut c_void){panic!("split must not free")}
#[no_mangle]unsafe extern "C" fn fixture_first(root:*const AbiRbRoot)->*mut AbiRbNode{rbtree::rb_first(root.cast()).cast()}
#[no_mangle]unsafe extern "C" fn fixture_next(p:*const AbiRbNode)->*mut AbiRbNode{rbtree::rb_next(p.cast()).cast()}
#[no_mangle]unsafe extern "C" fn fixture_log(_:i32,_:i32){panic!("split must not log error")}
unsafe extern "C" fn consumer_next(off:i32,mask:*mut u64)->i32{CURSORS.with(|v|v.borrow_mut().push(off));mem_interleave_nodes_result(off,mask,256)}
unsafe extern "C" fn consumer_try(node:i32,npages:i32,align:i32,is_user:i32,oom:*mut i32)->u64{assert_eq!((npages,align,is_user),(1,0,1));*oom=0;NODES.with(|v|v.borrow_mut().push(node));0x8000+(node as u64)*0x1000}
unsafe extern "C" fn consumer_account(node:i32,npages:i32,is_user:i32){assert_eq!((npages,is_user),(1,1));ACCOUNT.with(|v|v.borrow_mut().push(node));}
unsafe extern "C" fn consumer_p2v(pa:u64)->*mut c_void{pa as*mut c_void}
unsafe fn allocation_consumer(p:*mut VmRangeNumaPolicy)->*mut c_void{let mut policy=0;let mut mask=null_mut();let mut cursor=null_mut();assert_eq!(mem_policy_fields_result(1,(*p).numa_mem_policy,addr_of_mut!((*p).numa_mask).cast(),addr_of_mut!((*p).il_prev),&mut policy,&mut mask,&mut cursor),1);mem_mckernel_alloc_policy_result(1,0,0,-1,1,0,8,policy,0,mask,cursor,Some(consumer_try),None,None,Some(consumer_next),Some(consumer_account),Some(consumer_p2v),None)}
#[test]fn poisoned_split_tail_initializes_cursor_before_actual_allocation_consumer(){
 for (policy,corrected) in [(MPOL_INTERLEAVE,false),(MPOL_INTERLEAVE,true),(MPOL_DEFAULT,true)]{
  let mut vm:Box<ProcessVm>=Box::new(unsafe{core::mem::zeroed()});
  // For DEFAULT the source cursor remains genuinely uninitialized. Keep storage
  // as MaybeUninit and access only initialized fields via raw pointers; no whole
  // policy reference, byte comparison, cursor copy or snapshot is permitted.
  let mut source=Box::new(MaybeUninit::<VmRangeNumaPolicy>::uninit());let original=source.as_mut_ptr();
  // Model a reused allocation with every byte including the old cursor poisoned.
  let mut storage=Box::new(MaybeUninit::<VmRangeNumaPolicy>::uninit());let tail=storage.as_mut_ptr();
  unsafe{
   core::ptr::write_bytes(tail.cast::<u8>(),0xa5,size_of::<VmRangeNumaPolicy>());
   addr_of_mut!((*tail).il_prev).write(2); // stale prior interleave cursor in reused storage
   addr_of_mut!((*original).policy_rb_node).write(core::mem::zeroed());(*original).policy_rb_node.__rb_parent_color=1;
   addr_of_mut!((*original).start).write(0x1000);addr_of_mut!((*original).end).write(0x5000);addr_of_mut!((*original).numa_mask).write([0x24,0,0,0]);addr_of_mut!((*original).numa_mem_policy).write(policy);
   if policy==MPOL_INTERLEAVE{addr_of_mut!((*original).il_prev).write(5);}
   vm.vm_range_numa_policy_tree.rb_node=addr_of_mut!((*original).policy_rb_node);
   CORRECTED.with(|c|c.set(corrected));TAIL.with(|c|c.set(tail));SOURCE.with(|c|c.set(original));POLICY.with(|c|c.set(policy));EVENTS.with(|v|v.borrow_mut().clear());NODES.with(|v|v.borrow_mut().clear());CURSORS.with(|v|v.borrow_mut().clear());ACCOUNT.with(|v|v.borrow_mut().clear());
   let rc=if corrected{fixture_selected_clear(&mut*vm,0x2000,0x3000)}else{original_uncorrected_clear_body(&mut*vm,0x2000,0x3000,80,0x204,Some(fixture_alloc),Some(fixture_clear),Some(fixture_insert),Some(fixture_erase),Some(fixture_free),Some(fixture_first),Some(fixture_next),Some(fixture_log))};assert_eq!(rc,0);
   assert_eq!(EVENTS.with(|v|v.borrow().clone()),["alloc","rbclear","insert","insertlog","link","color"]);
   assert_eq!(syscall_vm_range_policy_search_body_result(&mut*vm,0x3000),tail);assert_eq!(((*tail).start,(*tail).end),(0x3000,0x5000));assert_eq!((*tail).il_prev,if corrected{255}else{2});
   if !corrected{
    assert_eq!(allocation_consumer(tail)as u64,0xd000);assert_eq!((*tail).il_prev,5);assert_eq!(CURSORS.with(|v|v.borrow().clone()),[2]);assert_eq!(NODES.with(|v|v.borrow().clone()),[5]);
   }else if policy==MPOL_INTERLEAVE{
    assert_eq!((*original).il_prev,5,"source cursor retained");
    for expected_node in [2,5,2]{assert_eq!(allocation_consumer(tail)as u64,0x8000+(expected_node as u64)*0x1000);assert_eq!((*tail).il_prev,expected_node);}
    assert_eq!(CURSORS.with(|v|v.borrow().clone()),[255,2,5]);assert_eq!(NODES.with(|v|v.borrow().clone()),[2,5,2]);assert_eq!(ACCOUNT.with(|v|v.borrow().clone()),[2,5,2]);
   }else{
    // Actual DEFAULT consumer skips interleave and never reads the source cursor.
    assert_eq!(allocation_consumer(tail)as u64,0x8000);assert!(CURSORS.with(|v|v.borrow().is_empty()));assert_eq!(NODES.with(|v|v.borrow().clone()),[0]);assert_eq!((*tail).il_prev,255);
   }
  }
 }
 println!("original stale cursor2 first selects5; corrected poisoned reused tail: cursor255 observed before publication; actual allocator selects nodes2,5,2; DEFAULT source cursor remains uninitialized and unread; original C fallback unchanged");
}
