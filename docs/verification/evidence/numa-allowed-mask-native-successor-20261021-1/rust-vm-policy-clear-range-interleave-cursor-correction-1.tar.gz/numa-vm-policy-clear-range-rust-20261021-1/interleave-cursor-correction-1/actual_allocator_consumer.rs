const IHK_MC_AP_USER: CULong = 0x001000;
const MPOL_DEFAULT: CInt = 0;
const MPOL_PREFERRED: CInt = 1;
const MPOL_BIND: CInt = 2;
const MPOL_INTERLEAVE: CInt = 3;
const MEM_ALLOC_LOG_EXPLICIT_OK: CInt = 1;
const MEM_ALLOC_LOG_EXPLICIT_MISS: CInt = 2;
const MEM_ALLOC_LOG_POLICY_OK: CInt = 3;
const MEM_ALLOC_LOG_POLICY_MISS: CInt = 4;
const MEM_ALLOC_LOG_DISTANCE_OK: CInt = 5;
const MEM_ALLOC_LOG_DISTANCE_FIRST_MISS: CInt = 6;
const MEM_ALLOC_LOG_OOM: CInt = 7;
type MemTryAllocNodeFn = unsafe extern "C" fn(CInt, CInt, CInt, CInt, *mut CInt) -> CULong;
type MemDistanceIdFn = unsafe extern "C" fn(CInt, CInt) -> CInt;
type MemMaskTestFn = unsafe extern "C" fn(CInt, *mut CULong) -> CInt;
type MemInterleaveNextFn = unsafe extern "C" fn(CInt, *mut CULong) -> CInt;
type MemRusageAddFn = unsafe extern "C" fn(CInt, CInt, CInt);
type MemPhysToVirtFn = unsafe extern "C" fn(CULong) -> *mut c_void;
type MemAllocLogFn = unsafe extern "C" fn(CInt, CInt, CInt, CInt);
pub unsafe extern "C" fn mem_policy_fields_result(
    has_policy: CInt,
    policy: CInt,
    mask: *mut CULong,
    il_prev_in: *mut CInt,
    numa_mem_policy: *mut CInt,
    numa_mask: *mut *mut CULong,
    il_prev: *mut *mut CInt,
) -> CInt {
    if has_policy == 0 {
        return 0;
    }

    if !numa_mem_policy.is_null() {
        unsafe {
            *numa_mem_policy = policy;
        }
    }
    if !numa_mask.is_null() {
        unsafe {
            *numa_mask = mask;
        }
    }
    if !il_prev.is_null() {
        unsafe {
            *il_prev = il_prev_in;
        }
    }
    1
}

pub unsafe extern "C" fn mem_interleave_nodes_result(
    off: CInt,
    numa_mask: *mut CULong,
    nr_bits: CInt,
) -> CInt {
    if numa_mask.is_null() || nr_bits <= 0 {
        return nr_bits;
    }

    let word_bits = (core::mem::size_of::<CULong>() * 8) as CInt;
    let bit_is_set = |bit: CInt| -> bool {
        let word = unsafe { *numa_mask.add((bit / word_bits) as usize) };
        ((word >> (bit % word_bits)) & 1) != 0
    };
    let start = if off < 0 {
        0
    } else if off >= nr_bits {
        nr_bits
    } else {
        off + 1
    };

    for bit in start..nr_bits {
        if bit_is_set(bit) {
            return bit;
        }
    }
    for bit in 0..nr_bits {
        if bit_is_set(bit) {
            return bit;
        }
    }

    nr_bits
}

pub extern "C" fn mem_alloc_policy_should_try_policy_result(
    pref_node: CInt,
    flag: CULong,
    numa_mem_policy: CInt,
    chk_shm: CInt,
) -> CInt {
    if pref_node == -1
        && (flag & IHK_MC_AP_USER) == 0
        && numa_mem_policy == MPOL_DEFAULT
        && chk_shm == 0
    {
        0
    } else {
        1
    }
}

pub extern "C" fn mem_alloc_node_id_valid_result(node: CInt, nr_nodes: CInt) -> CInt {
    (node >= 0 && node < nr_nodes) as CInt
}

pub extern "C" fn mem_alloc_policy_inputs_valid_result(
    npages: CInt,
    nr_nodes: CInt,
    has_try_alloc: CInt,
    has_rusage_add: CInt,
    has_phys_to_virt: CInt,
) -> CInt {
    (npages > 0
        && nr_nodes > 0
        && has_try_alloc != 0
        && has_rusage_add != 0
        && has_phys_to_virt != 0) as CInt
}

pub extern "C" fn mem_alloc_order_node_result(
    current_node: CInt,
    offset: CInt,
    nr_nodes: CInt,
) -> CInt {
    if nr_nodes <= 0 {
        return -1;
    }

    (current_node + offset) % nr_nodes
}

unsafe fn mem_try_alloc_node(
    try_alloc: MemTryAllocNodeFn,
    numa_id: CInt,
    npages: CInt,
    p2align: CInt,
    is_user: CInt,
) -> (CULong, bool) {
    let mut oom: CInt = 0;
    let pa = try_alloc(numa_id, npages, p2align, is_user, &mut oom);
    (pa, oom != 0)
}

unsafe fn mem_finish_alloc(
    pa: CULong,
    current_node: CInt,
    numa_id: CInt,
    npages: CInt,
    is_user: CInt,
    event: CInt,
    rusage_add: MemRusageAddFn,
    phys_to_virt: MemPhysToVirtFn,
    log_fn: Option<MemAllocLogFn>,
) -> *mut c_void {
    rusage_add(numa_id, npages, is_user);
    if let Some(log_fn) = log_fn {
        log_fn(event, current_node, numa_id, npages);
    }
    phys_to_virt(pa)
}

pub unsafe extern "C" fn mem_mckernel_alloc_policy_result(
    npages: CInt,
    p2align: CInt,
    flag: CULong,
    pref_node: CInt,
    is_user: CInt,
    current_node: CInt,
    nr_nodes: CInt,
    numa_mem_policy: CInt,
    chk_shm: CInt,
    numa_mask: *mut CULong,
    il_prevp: *mut CInt,
    try_alloc_fn: Option<MemTryAllocNodeFn>,
    distance_id_fn: Option<MemDistanceIdFn>,
    mask_test_fn: Option<MemMaskTestFn>,
    interleave_next_fn: Option<MemInterleaveNextFn>,
    rusage_add_fn: Option<MemRusageAddFn>,
    phys_to_virt_fn: Option<MemPhysToVirtFn>,
    log_fn: Option<MemAllocLogFn>,
) -> *mut c_void {
    if mem_alloc_policy_inputs_valid_result(
        npages,
        nr_nodes,
        try_alloc_fn.is_some() as CInt,
        rusage_add_fn.is_some() as CInt,
        phys_to_virt_fn.is_some() as CInt,
    ) == 0
    {
        return null_mut();
    }
    let (Some(try_alloc), Some(rusage_add), Some(phys_to_virt)) =
        (try_alloc_fn, rusage_add_fn, phys_to_virt_fn)
    else {
        return null_mut();
    };

    if mem_alloc_policy_should_try_policy_result(pref_node, flag, numa_mem_policy, chk_shm) != 0 {
        if mem_alloc_node_id_valid_result(pref_node, nr_nodes) != 0 {
            let (pa, _) = mem_try_alloc_node(try_alloc, pref_node, npages, p2align, is_user);
            if pa != 0 {
                return mem_finish_alloc(
                    pa,
                    current_node,
                    pref_node,
                    npages,
                    is_user,
                    MEM_ALLOC_LOG_EXPLICIT_OK,
                    rusage_add,
                    phys_to_virt,
                    log_fn,
                );
            }
            if let Some(log_fn) = log_fn {
                log_fn(MEM_ALLOC_LOG_EXPLICIT_MISS, current_node, pref_node, npages);
            }
        }

        let mut policy_pa: CULong = 0;
        let mut policy_numa: CInt = -1;

        match numa_mem_policy {
            MPOL_BIND | MPOL_PREFERRED => {
                if let (Some(distance_id), Some(mask_test)) = (distance_id_fn, mask_test_fn) {
                    if !numa_mask.is_null() {
                        let mut i = 0;
                        while i < nr_nodes {
                            let numa_id = distance_id(current_node, i);
                            if mem_alloc_node_id_valid_result(numa_id, nr_nodes) != 0
                                && mask_test(numa_id, numa_mask) != 0
                            {
                                let (pa, _) = mem_try_alloc_node(
                                    try_alloc, numa_id, npages, p2align, is_user,
                                );
                                if pa != 0 {
                                    policy_pa = pa;
                                    policy_numa = numa_id;
                                    break;
                                }
                            }
                            i += 1;
                        }
                    }
                }
            }
            MPOL_INTERLEAVE => {
                if let Some(interleave_next) = interleave_next_fn {
                    if !numa_mask.is_null() && !il_prevp.is_null() {
                        let il_start = *il_prevp;
                        let mut looping = false;
                        let mut attempts = 0;
                        while attempts <= nr_nodes {
                            let numa_id = interleave_next(*il_prevp, numa_mask);
                            let mut oom = false;
                            *il_prevp = numa_id;

                            if il_start == *il_prevp && looping {
                                policy_pa = 0;
                                break;
                            }
                            looping = true;

                            if numa_id >= 0 && numa_id < nr_nodes {
                                let result = mem_try_alloc_node(
                                    try_alloc, numa_id, npages, p2align, is_user,
                                );
                                policy_pa = result.0;
                                oom = result.1;
                                if policy_pa != 0 {
                                    policy_numa = numa_id;
                                    break;
                                }
                            }

                            if !oom {
                                break;
                            }
                            attempts += 1;
                        }
                    }
                }
            }
            _ => {}
        }

        if policy_pa != 0 {
            return mem_finish_alloc(
                policy_pa,
                current_node,
                policy_numa,
                npages,
                is_user,
                MEM_ALLOC_LOG_POLICY_OK,
                rusage_add,
                phys_to_virt,
                log_fn,
            );
        }
        if let Some(log_fn) = log_fn {
            log_fn(MEM_ALLOC_LOG_POLICY_MISS, current_node, -1, npages);
        }
    }

    if let Some(distance_id) = distance_id_fn {
        let mut i = 0;
        while i < nr_nodes {
            let numa_id = distance_id(current_node, i);
            if mem_alloc_node_id_valid_result(numa_id, nr_nodes) != 0 {
                let (pa, _) = mem_try_alloc_node(try_alloc, numa_id, npages, p2align, is_user);
                if pa != 0 {
                    return mem_finish_alloc(
                        pa,
                        current_node,
                        numa_id,
                        npages,
                        is_user,
                        MEM_ALLOC_LOG_DISTANCE_OK,
                        rusage_add,
                        phys_to_virt,
                        log_fn,
                    );
                }
                if i == 0 {
                    if let Some(log_fn) = log_fn {
                        log_fn(
                            MEM_ALLOC_LOG_DISTANCE_FIRST_MISS,
                            current_node,
                            numa_id,
                            npages,
                        );
                    }
                }
            }
            i += 1;
        }
    }

    let mut i = 0;
    while i < nr_nodes {
        let numa_id = mem_alloc_order_node_result(current_node, i, nr_nodes);
        let (pa, _) = mem_try_alloc_node(try_alloc, numa_id, npages, p2align, is_user);
        if pa != 0 {
            return mem_finish_alloc(
                pa,
                current_node,
                numa_id,
                npages,
                is_user,
                0,
                rusage_add,
                phys_to_virt,
                None,
            );
        }
        i += 1;
    }

    if let Some(log_fn) = log_fn {
        log_fn(MEM_ALLOC_LOG_OOM, current_node, -1, npages);
    }
    null_mut()
}
