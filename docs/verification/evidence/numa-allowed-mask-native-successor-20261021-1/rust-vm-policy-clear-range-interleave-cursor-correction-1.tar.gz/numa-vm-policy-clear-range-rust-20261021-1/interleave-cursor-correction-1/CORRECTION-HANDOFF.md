Functional McKernel OS/apps and Rust/assembly migration only; no security testing.

Private proposal correcting a reviewer source finding: supported MPOL_INTERLEAVE
split tails were published with an uninitialized il_prev, then the allocation
consumer read that cursor before writing it. This is not a native failure report.

Minimal Rust change initializes every newly allocated split tail cursor to the
existing (PROCESS_NUMA_MASK_BITS - 1) sentinel before insertion publication. The
source cursor is never read or copied: noninterleave source cursor storage may
be uninitialized. Tail allocation failure, ownership, masks, original-node cursor,
callbacks and unsigned range behavior are otherwise retained. No new compute C,
no C fallback edits, no shared source edits and no old parity replay. Prior
accepted/failing evidence remains untouched in the parent packet.

One new focused actual-body test reuses the accepted C forwarding object and
actual Rust RB/search/insert bodies. A reused tail is filled with 0xa5 bytes and carries a stale prior cursor2. The
original uncorrected actual Rust clear body retains2 and the actual consumer
first selects node5. The corrected body resets255 and first selects node2. The
insertion callback requires cursor255 before publication. The exact production
mem_policy_fields_result, mem_mckernel_alloc_policy_result and
mem_interleave_nodes_result bodies plus dependencies exercise the read consumer.
Mask{2,5} must first select node2, then5, then2, updating cursor and accounting.
The source interleave cursor5 stays unchanged. A separate DEFAULT source uses
MaybeUninit storage with il_prev genuinely unwritten; raw field accesses initialize
only the other fields, and no whole-policy reference/snapshot/byte-copy reads that
cursor. Splitting it initializes the tail sentinel and DEFAULT allocation skips
interleave selection. This is focused source/consumer evidence, not native proof.

Next exact command under fresh root ordinary CPU6/1GiB/CPU55/nofile256/
fsize64MiB/core0, one serial job, no nproc adjustment:
/home/holden/anaconda3/bin/python3.9 -I -B /home/holden/mckernel-work/host-preparation/numa-vm-policy-clear-range-rust-20261021-1/interleave-cursor-correction-1/run_focused_check.py

Two serial commands only: accepted Rust1.85.1 compiler links hash-bound existing
c-selected-1.o, then one exact test. Root grant required; no compilation/test run
at freeze. Expected <1s measured baseline for similar compilation, reserve35s per
command and fresh root wall/cpu binding. Output growth reserve <64MiB. No network,
root/module/guest, fullcrate or production build. Stop on failure; one failed
candidate plus one bounded correction per family, retain every stream/result.
Independent review and dispatcher integration remain prerequisites.
