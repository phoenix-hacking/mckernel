#[no_mangle]
pub unsafe extern "C" fn original_uncorrected_clear_body(
    vm: *mut ProcessVm, start: CULong, end: CULong,
    policy_size: SizeT, alloc_flags: CULong,
    alloc_fn: Option<SyscallPolicyAllocFn>,
    rb_clear_fn: Option<SyscallPolicyRbClearFn>,
    insert_fn: Option<SyscallPolicyInsertFn>,
    erase_fn: Option<SyscallPolicyRbEraseFn>,
    free_fn: Option<SyscallPolicyClearFreeFn>,
    first_fn: Option<SyscallPolicyRbFirstFn>,
    next_fn: Option<SyscallPolicyRbNextFn>,
    log_fn: Option<SyscallPolicyClearLogFn>,
) -> CInt {
    let (Some(alloc), Some(rb_clear), Some(insert), Some(erase), Some(free),
         Some(first), Some(next), Some(log)) =
        (alloc_fn, rb_clear_fn, insert_fn, erase_fn, free_fn, first_fn, next_fn, log_fn)
    else { return -EINVAL; };
    let root = unsafe { addr_of_mut!((*vm).vm_range_numa_policy_tree) };
    let iter = unsafe { syscall_vm_range_policy_search_body_result(vm, start) };
    if !iter.is_null() {
        let mut adjusted = false;
        let mut orig_end = unsafe { (*iter).end };
        if unsafe { (*iter).start == start && (*iter).end == end } {
            unsafe { erase(addr_of_mut!((*iter).policy_rb_node), root); free(iter.cast()); }
            return 0;
        }
        if unsafe { (*iter).start < start } {
            orig_end = unsafe { (*iter).end };
            unsafe { (*iter).end = start; }
            adjusted = true;
        }
        if orig_end > end {
            if adjusted {
                let tail = unsafe { alloc(policy_size, alloc_flags) }.cast::<VmRangeNumaPolicy>();
                if tail.is_null() { unsafe { log(0, 0); } return -ENOMEM; }
                unsafe {
                    rb_clear(tail);
                    (*tail).start = end;
                    (*tail).end = orig_end;
                    (*tail).numa_mem_policy = (*iter).numa_mem_policy;
                    // C copies only mask, leaving il_prev and RB child bytes alone.
                    core::ptr::copy_nonoverlapping(
                        core::ptr::addr_of!((*iter).numa_mask),
                        addr_of_mut!((*tail).numa_mask),
                        1);
                }
                let error = unsafe { insert(vm, tail) };
                if error != 0 { unsafe { log(1, error); } return error; }
            } else { unsafe { (*iter).start = end; } }
        }
    }
    // C unsigned end - 1 intentionally wraps for end == 0.
    let iter = unsafe { syscall_vm_range_policy_search_body_result(vm, end.wrapping_sub(1)) };
    if !iter.is_null() { unsafe { (*iter).start = end; } }
    // Restart rb_first after every removal, matching the C goto again_search.
    loop {
        let mut node = unsafe { first(root) };
        let mut removed = false;
        while !node.is_null() {
            let range = unsafe { node.cast::<u8>()
                .sub(offset_of!(VmRangeNumaPolicy, policy_rb_node)).cast::<VmRangeNumaPolicy>() };
            if unsafe { (*range).start >= start && (*range).end <= end } {
                unsafe { erase(addr_of_mut!((*range).policy_rb_node), root); free(range.cast()); }
                removed = true;
                break;
            }
            node = unsafe { next(node) };
        }
        if !removed { break; }
    }
    0
}
