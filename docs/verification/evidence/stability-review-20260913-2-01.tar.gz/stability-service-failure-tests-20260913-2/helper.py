#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shutil,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
work,repo=Path('/work'),Path('/workspace')
out=work/'stability-service-failure-tests-20260913-2';out.mkdir()
staged=work/'stability-service-failure-stage-20260913-2'
record=dict(status='RUNNING',commands=[],inputs=[],started_utc=datetime.now(timezone.utc).isoformat(),scope='exact production-method protocol tests with bounded Linux mocks; no native module or guest evidence',actual_guest_transport_fault_verified=False,production_gate_credit=False)
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 shutil.copyfile(__file__,out/'helper.py')
 shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 st=json.loads((staged/'record.json').read_text());assert st['status']=='STAGED_NOT_RUN'
 record['stage_record']=identity(staged/'record.json')
 for row in st['compiler_inputs']:
  p=staged/row['path'];got=identity(p)
  assert (got['sha256'],got['size'])==(row['sha256'],row['size']),row
  record['inputs'].append(got)
 for row in st['current_originals']:
  got=identity(repo/row['path']);assert(got['sha256'],got['size'])==(row['sha256'],row['size']),row
  record['inputs'].append(got)
 shutil.copytree(staged/'source',out/'source')
 record['supervisor']=identity(out/'supervisor.py')
 fixture=out/'source/scripts/tests/fixtures'
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC')
 commands=[('compiler-version',['rustc','--version','--verbose'],30),('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter',str(fixture/'native-application-syscall.c'),'-o',str(out/'c-reference')],120),('c-reference',[str(out/'c-reference')],30),('rust-build',['rustc','--edition','2021','-D','warnings','--test',str(fixture/'native-application-syscall.rs'),'-o',str(out/'syscall-tests')],180),('rust-tests',[str(out/'syscall-tests'),'--nocapture','--test-threads=4'],90)]
 for label,argv,timeout in commands:
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0],path=env['PATH'])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=5,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['wait_status']==dict(kind='exited',code=0) and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  if label=='c-reference':assert (out/(label+'-collection')/'stdout.bin').read_bytes()==(fixture/'native-application-syscall-c.txt').read_bytes(),'independent C reference differs'
 for row in record['inputs']:assert identity(Path(row['path']))==row,row
 record.update(status='PASS')
except BaseException as error:
 record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
