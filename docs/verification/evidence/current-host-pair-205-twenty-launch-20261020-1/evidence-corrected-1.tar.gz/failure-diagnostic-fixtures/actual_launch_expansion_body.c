#define _GNU_SOURCE
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#define PAIR_ROOT "case"
#define ND_PAIR_LAUNCH_EXPANSION 1
#define STREAM_LIMIT 1024u
#define FRAME_LIMIT 4096u
#define MS 1000000ull
struct stream {
    unsigned char data[STREAM_LIMIT];
    size_t kept;
    uint64_t observed, eof_ns;
    int eof;
};
struct result {
    struct stream out, err;
    int pid;
    int status, fault, timeout, clean;
    int child_stage, child_errno;
    uint64_t started, reaped, finished;
};
static unsigned pair_active_round;
static const char *pair_fail_phase="setup";
static int pair_rounds_initialized;
static char pair_evidence_dir[128];
static unsigned long pair_generation=1;
static unsigned pair_os;
static int pair_host_cpus[2]={1,2};
static uint64_t fixture_clock=1000000000ull;
static int scenario,run_calls,app_launches;
static char fixture_log[1048577];static size_t log_size;
static uint64_t now_ns(void){fixture_clock+=100000000ull;return fixture_clock;}
static uint64_t bounded_deadline(uint64_t end,uint64_t reserve){(void)reserve;return end;}
static int retired_at(const char *path){(void)path;return (scenario==4 && run_calls==1) || (scenario==17 && run_calls==9)?0:1;}
#include "actual_shared_functions.inc"
#include "actual_result_io.inc"
static int fixture_klogctl(int action,char *buf,int length){(void)action;if(log_size>=(size_t)length)return -1;memcpy(buf,fixture_log,log_size);return (int)log_size;}
#define klogctl fixture_klogctl
#include "../candidate/pair_launch_expansion_support.inc"
static void add(const char *fmt,...){va_list ap;va_start(ap,fmt);int n=vsnprintf(fixture_log+log_size,sizeof fixture_log-log_size,fmt,ap);va_end(ap);assert(n>=0 && (size_t)n<sizeof fixture_log-log_size);log_size+=(size_t)n;}
static int pair_run(int *safe)
{
    run_calls++;*safe=1;
    if(scenario==22 && pair_active_round>0)log_size=0;
    if(scenario==3){*safe=0;return 1;}
    if((scenario==7 && pair_active_round==1) || (scenario==16 && pair_active_round==9))assert(save_file("case/two-app/work0/stale","x",1)==0);
    if(pair_round_workdirs())return 1;
    if(scenario==21 && pair_active_round==0)assert(save_file("case/evidence/round0/current-trace.log","x",1)==0);
    uint64_t launch_base=fixture_clock;
    for(int i=0;i<2;i++) {
        struct result r;memset(&r,0,sizeof r);r.pid=1001+(int)pair_active_round*2+i;
        if((scenario==5 && pair_active_round==1 && i==0) || (scenario==12 && pair_active_round==9 && i==0))r.pid=1001;
        r.clean=1;r.started=launch_base+10+(uint64_t)i*10;r.reaped=launch_base+200+(uint64_t)i*20;r.finished=launch_base+250+(uint64_t)i*10;
        const unsigned char *p=i?pair_round_stdout_1:pair_round_stdout_0;size_t size=i?sizeof pair_round_stdout_1:sizeof pair_round_stdout_0;
        memcpy(r.out.data,p,size);r.out.kept=size;r.out.observed=size;r.out.eof=r.err.eof=1;r.out.eof_ns=r.err.eof_ns=r.reaped-10;
        if((scenario==1 && pair_active_round==0 && i==0) || (scenario==8 && pair_active_round==4 && i==0) || (scenario==15 && pair_active_round==9 && i==0))r.out.data[0]^=1;
        char name[PATH_MAX];int n=snprintf(name,sizeof name,"%s/app%d.result",pair_evidence_dir,i);assert(n>0 && (size_t)n<sizeof name);assert(save_file(name,&r,sizeof r)==0);app_launches++;
        int cpu=((scenario==2 && pair_active_round==0 && i==0) || (scenario==14 && pair_active_round==9 && i==0))?1:i;
        unsigned long long token=(unsigned long long)r.pid*10+1;
        if((scenario==6 && pair_active_round==1 && i==0) || (scenario==13 && pair_active_round==9 && i==0))token=10011;
        if(scenario==9 && pair_active_round==0 && i==1)token=10011;
        add("application SCHEDULE os=0 generation=1 pid=%d cpu=%d\n",r.pid,cpu);
        add("application procfs published os=0 generation=1 pid=%d tid=%d\n",r.pid,r.pid);
        add("application_syscall=delivered os=0 generation=1 pid=%d worker=%d delivery=1 cpu=%d number=157\n",r.pid,r.pid+5000,cpu);
        add("application_syscall=return_route os=0 generation=1 pid=%d worker=%d delivery=1 launcher_cpu=%d guest_cpu=%d\n",r.pid,r.pid+5000,1-i,cpu);
        add("application_syscall=returned os=0 generation=1 pid=%d worker=%d delivery=1 cpu=%d value=0\n",r.pid,r.pid+5000,cpu);
        add("application_syscall=delivered os=0 generation=1 pid=%d worker=%d delivery=2 cpu=%d number=231\n",r.pid,r.pid+5000,cpu);
        add("application retirement os=0 generation=1 pid=%d token=%llu errno=-11\n",r.pid,token);
        add("application retirement os=0 generation=1 pid=%d token=%llu errno=0\n",r.pid,token+1);
        add("application_process=release os=0 generation=1 pid=%d cleanup_errno=0\n",r.pid);
        add("application procfs deleted os=0 generation=1 pid=%d tid=%d\n",r.pid,r.pid);
    }
    if(scenario==18 && pair_active_round==0)log_size=sizeof fixture_log-1;
    if(scenario==26 && pair_active_round==1)add("application_syscall=delivered os=0 generation=1 pid=1001 worker=6001 delivery=999 cpu=0 number=157\n");
    fixture_clock+=1000;return 0;
}
#include "../candidate/pair_launch_expansion_run.inc"
int main(int argc,char **argv)
{
    assert((argc==3 || argc==4) && chdir(argv[2])==0);scenario=atoi(argv[1]);assert(scenario>=0 && scenario<=30);int damage=scenario>=29?scenario:0;if(damage)scenario=8;
    assert(mkdir("case",0700)==0 && mkdir("case/evidence",0700)==0);
    if(scenario==11) {
        int fds[2];assert(pipe2(fds,O_NONBLOCK|O_CLOEXEC)==0);char fill[512]={0};int full=0;
        for(int i=0;i<2048;i++) {ssize_t wrote=write(fds[1],fill,sizeof fill);if(wrote<0 && errno==EAGAIN){full=1;break;}assert(wrote==(ssize_t)sizeof fill);}
        assert(full);int result=write_all(fds[1],"x",1);assert(result==-1);assert(close(fds[0])==0 && close(fds[1])==0);
        printf("WRITE_EAGAIN_DEADLINE_RESULT %d\n",result);return 0;
    }
    if(scenario==10) {
        assert(argc==4);FILE *input=fopen(argv[3],"rb");assert(input);log_size=fread(fixture_log,1,sizeof fixture_log-1,input);assert(!ferror(input) && feof(input));assert(fclose(input)==0);fixture_log[log_size]=0;
#include "saved_gate_results.inc"
        pair_active_round=0;assert(mkdir("case/evidence/round0",0700)==0);
        strcpy(pair_evidence_dir,"case/evidence/round0");
        int result=pair_round_gate();printf("SAVED_GATE_RESULT %d\n",result);return 0;
    }
    add("NATIVE_PAIR_CPU os=0 generation=1 assigned_host=1,2 logical=0,1 default_ikc_linux=0\n");
    add("control accepted os=0 generation=1 port=501 guest_cpu=0 linux_cpu=1 cookie=1 receive=10000000 send=20000000 bytes=16384 reference=1 remote_cookie=30000000\n");
    add("control accepted os=0 generation=1 port=501 guest_cpu=1 linux_cpu=2 cookie=2 receive=40000000 send=50000000 bytes=16384 reference=1 remote_cookie=60000000\n");
    int safe=1,empty=0;int result=pair_run_launch_expansion(1,&safe,&empty);
    if(result && safe){assert(save_file("case/evidence/kernel.log",fixture_log,log_size)==0);if(damage==29){int corrupt=open("case/evidence/round0/current-trace.log",O_WRONLY|O_TRUNC);assert(corrupt>=0 && close(corrupt)==0);}
        if(damage==30)assert(unlink("case/evidence/round0/current-trace.log")==0);
        int exported=pair_failure_export(1,fixture_log,log_size);assert(exported==(damage?-1:0));
        if(damage)printf("DIAGNOSTIC_TAMPER_REFUSED %d\n",damage);}
    if(result==0){
        if(scenario==19)assert(unlink("case/evidence/round0/current-trace.log")==0);
        if(scenario==20){int corrupt=open("case/evidence/round0/current-trace.log",O_WRONLY|O_TRUNC);assert(corrupt>=0 && close(corrupt)==0);}
        if(scenario==23)add("application SCHEDULE os=0 generation=1 pid=9999 cpu=0\n");
        if(scenario==24)add("application_syscall=delivered malformed\n");
        if(scenario==25)add("application_syscall=delivered os=0 generation=1 pid=1019 worker=6019 delivery=999 cpu=0 number=157\n");
        if(scenario==27)add("control accepted os=0 generation=1 port=501 guest_cpu=0 linux_cpu=1 cookie=999 receive=10000000 send=20000000 bytes=16384 reference=1 remote_cookie=30000000\n");
        if(scenario==28)add("control accepted os=0 generation=1 port=501 guest_cpu=0 linux_cpu=1 cookie=1 receive=10000000 send=20000000 bytes=16384 reference=1 remote_cookie=30000000\n");
        if(pair_trace_publish(1,fixture_log,log_size))result=-1;
    }
    if(result==0){const char done[]="ND_PAIR_ROUNDS_COMPLETE {\"rounds\":10,\"os\":0,\"generation\":1,\"procfs_empty\":true}\n";assert(write_all(1,done,sizeof done-1)==0);}
    printf("FIXTURE_RESULT {\"scenario\":%d,\"result\":%d,\"safe\":%d,\"empty\":%d,\"runs\":%d,\"launches\":%d}\n",scenario,result,safe,empty,run_calls,app_launches);
    return 0;
}
