from pathlib import Path
import hashlib,importlib.util,json,os,time
N=Path(__file__).resolve().parent;D=N/'stage-preparation-1';Q=D/'native-packet-1';O=Q/'actual-physical-projection-1.json'
def ref(p):raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
source=D/'root_manual_snapshot_twenty_launches_sdk.py';bindings=D/'fresh-snapshot-bindings.json.PENDING-STATIC';b=json.loads(bindings.read_bytes());t=json.loads(Path(b['physical_review']['path']).read_bytes());start=time.monotonic()
spec=importlib.util.spec_from_file_location('actual_caller78_projection',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result={'status':'PENDING','source':ref(source),'bindings':ref(bindings),'physical':b['physical_review'],'actual_schema':t['schema'],'root_operations':0,'workload_commands':0,'snapshot_created':False}
try:
 m.terminal_joins(t,b);result.update(status='PASS_ACTUAL_CALLER78_PURE_TERMINAL_JOIN',actual_clients=t['physical_facts']['client_count'],actual_group_checks=t['physical_facts']['owned_group_check_count'],actual_record_count=t['physical_facts']['record_count'])
except BaseException as exc:
 result.update(status='FAIL_PRESERVE_EXACT_PROJECTION_REFUSAL',error=type(exc).__name__+': '+str(exc));raise
finally:
 result['elapsed_seconds']=time.monotonic()-start
 with O.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:result[k] for k in ['status','actual_clients','actual_group_checks','actual_record_count','elapsed_seconds']}))
