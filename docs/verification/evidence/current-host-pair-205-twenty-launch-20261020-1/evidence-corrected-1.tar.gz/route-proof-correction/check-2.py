from pathlib import Path
import hashlib,importlib.util,json,os,resource,shutil,time
N=Path(__file__).resolve().parent
W=N/'check-2'; assert not W.exists();W.mkdir(mode=0o700)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert os.sched_getaffinity(0)=={6}
assert resource.getrlimit(resource.RLIMIT_AS)[0]==1073741824
assert resource.getrlimit(resource.RLIMIT_CPU)[0]==30
assert resource.getrlimit(resource.RLIMIT_FSIZE)[0]==33554432
assert ref('/usr/bin/gcc')['sha256']=='6cb2d84ccd9fd3485d4e47ba032e626be65692601c38fad46866a6b565f3100f'
for mount,floor in [('/home/holden',16<<30),('/home/holden/mckernel-work/scratch',12<<30)]:
 assert shutil.disk_usage(mount).free>floor+(640<<20)
assert int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>2<<30
pins=[ref(p) for p in sorted((N/'candidate').glob('*'))]+[ref(p) for p in sorted((N/'fixtures').glob('*'))]
(N/'input-pins-2.json').write_text(json.dumps(pins,indent=2)+'\n')
e=Path('/home/holden/mckernel-work/host-preparation/current-host-pair-205-compatibility-20261019-1/ordinary-envelope-1/run_three_commands_source_bound.py')
assert ref(e)['sha256']=='37e5d4fcf0d5ad196627a1c60831ff4887a14a8fa89c9ebe29c82387faf1d6c4'
spec=importlib.util.spec_from_file_location('capture',e);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.monotonic();rows=[]
def run(name,argv):
 d=W/name;d.mkdir();(d/'command.json').write_text(json.dumps({'argv':argv})+'\n')
 r=m.owned_capture({'argv':argv},d,28-(time.monotonic()-start),lambda:None);m.write(d/'status.json',r);rows.append({'name':name,**r})
 assert r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and not r['error'] and not r['retirement_error'],r
 assert not (d/'stderr').read_bytes()
 return (d/'stdout').read_text()
flags=['/usr/bin/gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-static','-fno-pie','-no-pie','-Wl,-z,noexecstack','-DND_CORE_THREADS','-DND_PAIR_LAUNCH_EXPANSION']
assert (N/'check-1/collector').is_file() # retained passed actual production compile, unchanged inputs
run('compile-original-body',flags+['-Wno-unused-function','-DORIGINAL','-I'+str(N/'candidate'),str(N/'fixtures/actual_discover.c'),'-o',str(W/'original')])
run('compile-corrected-body',flags+['-Wno-unused-function','-I'+str(N/'candidate'),str(N/'fixtures/actual_discover.c'),'-o',str(W/'corrected')])
checks=[]
raw=N.parent/'actual-failure-triage-1/current_raw-round7.log'
first=N.parent/'actual-failure-triage-1/retained-round0.log'
for revision,cases in [('original',[0,1,10]),('corrected',list(range(11)))]:
 for case in cases:
  cwd=W/('workspace-'+revision+'-'+str(case));cwd.mkdir()
  serial=run(revision+'-'+str(case),[str(W/revision),str(case),str(raw),str(first),str(cwd)])
  record=json.loads(next(x.split(' ',1)[1] for x in serial.splitlines() if x.startswith('ROUTE_RESULT ')))
  if revision=='original' and case==0:assert record['modeled_klog_n']==262144 and record['pair_routes_calls_after_startup']==0
  if revision=='original' and case==1:assert record['modeled_klog_n']<262144 and record['pair_routes_calls_after_startup']==1
  checks.append(record)
assert pins==[ref(p['path']) for p in pins]
result={'status':'PASS_OFFLINE_ONLY','checks':checks,'commands':rows,'elapsed_seconds':time.monotonic()-start,'actual_guest_launches':0}
(N/'result-2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'compiles':2,'retained_production_compile_reused':1,'actual_guest_launches':0}))
