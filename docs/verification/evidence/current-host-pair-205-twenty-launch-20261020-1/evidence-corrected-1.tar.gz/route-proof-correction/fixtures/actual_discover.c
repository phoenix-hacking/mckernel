#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/klog.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define ND_PAIR_LAUNCH_EXPANSION 1
#define PAIR_ROOT "case"
static int route_calls;
#define pair_routes actual_pair_routes
#include "../candidate/pair_assignment.h"
#undef pair_routes
static int pair_routes(const char *log,unsigned long bytes,const struct pair_assignment *a,unsigned long *g){route_calls++;return actual_pair_routes(log,bytes,a,g);}
#undef PAIR_ASSIGNMENT
#undef PAIR_CHALLENGE
#define PAIR_ASSIGNMENT "assignment"
#define PAIR_CHALLENGE "challenge"
static unsigned pair_active_round;
static int pair_rounds_initialized=1;
static char pair_evidence_dir[128]="case/evidence/round0";
struct result {int pid;};
static struct result pair_results[2]={{256},{257}};
static int pair_seen_pids[20]={256,257};
static char *mock_log;static size_t mock_bytes;static int exact_cap,last_klog_n;
static int tags[256];
static int save_file(const char *path,const void *p,size_t bytes){int f=open(path,O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0600);if(f<0)return -1;ssize_t n=write(f,p,bytes);int bad=n!=(ssize_t)bytes;if(close(f))bad=1;return bad?-1:0;}
static int write_all(int fd,const void *p,size_t bytes){(void)fd;(void)p;(void)bytes;return 0;}
static int route_open(const char *p,int flags,...)
{
 const char *real=p;int tag=0;
 if(!strcmp(p,PAIR_ASSIGNMENT))tag=1;
 if(!strcmp(p,"/dev/mcos0")){real="device";tag=2;}
 if(!strcmp(p,"/sys/devices/system/cpu/online"))real="online";
 if(!strcmp(p,"/sys/class/mcos/mcos0/sys/devices/system/cpu/num_processors"))real="count";
 if(!strcmp(p,"/sys/class/mcos/mcos0/sys/devices/system/cpu/cpu0/online") || !strcmp(p,"/sys/class/mcos/mcos0/sys/devices/system/cpu/cpu1/online"))real="cpu-online";
 int fd=open(real,flags);if(fd>=0){assert(fd<256);tags[fd]=tag;}return fd;
}
static int route_fstat(int fd,struct stat *s){int r=fstat(fd,s);if(!r && tags[fd]==1){s->st_uid=s->st_gid=0;}if(!r && tags[fd]==2)s->st_mode=(s->st_mode&07777)|S_IFCHR;return r;}
static int route_close(int fd){if(fd>=0 && fd<256)tags[fd]=0;return close(fd);}
static int route_ioctl(int fd,unsigned long request,...){assert(fd>=0 && tags[fd]==2 && request==0x30a02907);return 2;}
static int route_klogctl(int action,char *buf,int cap)
{
 assert(action==3 && cap==PAIR_LOG_LIMIT);size_t off=mock_bytes>(size_t)cap?mock_bytes-(size_t)cap:0;
 if(off && !exact_cap){const char *nl=memchr(mock_log+off,'\n',mock_bytes-off);assert(nl);off=(size_t)(nl-mock_log)+1;}
 size_t n=mock_bytes-off;assert(n<=(size_t)cap);memcpy(buf,mock_log+off,n);last_klog_n=(int)n;return (int)n;
}
#define open route_open
#define close route_close
#define fstat route_fstat
#define ioctl route_ioctl
#define klogctl route_klogctl
#ifdef ORIGINAL
#include "runtime-original.inc"
#else
#include "runtime-corrected.inc"
#endif
#include "../candidate/pair_trace_retention.inc"
#undef open
#undef close
#undef fstat
#undef ioctl
#undef klogctl
static char *read_all(const char *path,size_t *bytes){FILE *f=fopen(path,"rb");assert(f);assert(fseek(f,0,SEEK_END)==0);long n=ftell(f);assert(n>0 && n<1048576);rewind(f);char *p=malloc((size_t)n+1);assert(p);assert(fread(p,1,(size_t)n,f)==(size_t)n && fclose(f)==0);p[n]=0;*bytes=(size_t)n;return p;}
int main(int argc,char **argv)
{
 assert(argc==5);int scenario=atoi(argv[1]);size_t bytes,first_bytes;char *raw=read_all(argv[2],&bytes),*first=read_all(argv[3],&first_bytes);assert(chdir(argv[4])==0);
 assert(mkdir("case",0700)==0 && mkdir("case/evidence",0700)==0 && mkdir("case/evidence/round0",0700)==0);
 struct pair_assignment assignment={.magic=PAIR_MAGIC,.nonce={1,2},.os=0,.count=2,.generation=1,.physical={1,2}};
 assert(save_file(PAIR_ASSIGNMENT,&assignment,sizeof assignment)==0 && save_file("device","",0)==0 && save_file("online","0,3\n",4)==0 && save_file("count","2\n",2)==0 && save_file("cpu-online","1\n",2)==0);
 pair_nonce[0]=1;pair_nonce[1]=2;if(0)pair_prepare_challenge();
 char *schedule=strstr(raw,"application SCHEDULE ");assert(schedule);char *start=schedule;while(start>raw && start[-1]!='\n')start--;
 mock_log=raw;mock_bytes=(size_t)(start-raw);int cpus[2]={-1,-1};assert(pair_discover(cpus)==0 && cpus[0]==0 && cpus[1]==1);
 pair_trace_total=0;for(int i=0;i<10;i++)pair_trace_records[i].fd=-1;
 assert(pair_trace_save(first,first_bytes)==0);pair_active_round=7;mock_log=raw;mock_bytes=bytes;exact_cap=scenario==0;
 if(scenario==2){assignment.generation=2;int f=open(PAIR_ASSIGNMENT,O_WRONLY|O_TRUNC);assert(f>=0 && write(f,&assignment,sizeof assignment)==(ssize_t)sizeof assignment && close(f)==0);}
 if(scenario==3){assert(rename(PAIR_ASSIGNMENT,"assignment.old")==0 && save_file(PAIR_ASSIGNMENT,&assignment,sizeof assignment)==0);}
 if(scenario==4){int f=open("case/evidence/round0/current-trace.log",O_WRONLY|O_TRUNC);assert(f>=0 && close(f)==0);}
 if(scenario==5)assert(unlink("case/evidence/round0/current-trace.log")==0);
 if(scenario==6){assert(close(pair_trace_records[0].fd)==0);pair_trace_records[0].fd=-1;}
 char changed[1024];
 if(scenario==7){strcpy(changed,"<6>[ 99.000000] IHK-SMP: control accepted os=0 generation=2 port=501 guest_cpu=0 linux_cpu=1 cookie=1\n");mock_log=changed;mock_bytes=strlen(changed);}
 if(scenario==8 || scenario==9){
  const char *p0=strstr(first,"IHK-SMP: control accepted os=0 generation=1 port=501 guest_cpu=0");const char *p1=strstr(first,"IHK-SMP: control accepted os=0 generation=1 port=501 guest_cpu=1");assert(p0 && p1);
  while(p0>first && p0[-1]!='\n'){p0--;}
  while(p1>first && p1[-1]!='\n'){p1--;}
  size_t n0=(size_t)(strchr(p0,'\n')-p0)+1,n1=(size_t)(strchr(p1,'\n')-p1)+1;
  if(scenario==8){memcpy(changed,p1,n1);memcpy(changed+n1,p0,n0);mock_bytes=n1+n0;}
  else {memcpy(changed,p0,n0);memcpy(changed+n0,p0,n0);mock_bytes=2*n0;}
  mock_log=changed;
 }
 if(scenario==10){mock_log=first;mock_bytes=first_bytes;}
 int before=route_calls;last_klog_n=-1;int result=pair_discover(cpus);
#ifdef ORIGINAL
 int expected=scenario==10?0:77;
#else
 int expected=(scenario<=1 || scenario==10)?0:77;
#endif
 assert(result==expected);
 printf("ROUTE_RESULT {\"revision\":\"%s\",\"scenario\":%d,\"result\":%d,\"modeled_klog_n\":%d,\"pair_routes_calls_after_startup\":%d,\"observed_native_klog_n\":null}\n",
#ifdef ORIGINAL
 "original",
#else
 "corrected",
#endif
 scenario,result,last_klog_n,route_calls-before);
 free(raw);free(first);return 0;
}
