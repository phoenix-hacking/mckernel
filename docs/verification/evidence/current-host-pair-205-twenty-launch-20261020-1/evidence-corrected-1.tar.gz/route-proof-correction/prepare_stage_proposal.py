from pathlib import Path
import ast,copy,hashlib,json,os,stat,uuid
N=Path(__file__).resolve().parent;B=N.parent;OLD=B/'stage-preparation-1';D=N/'stage-preparation-1';D.mkdir(mode=0o700)
nonce=uuid.uuid4().hex
replacements={str(OLD):str(D),'r205d-261020-1':'r205r-261020-1','r205dm-261020-1':'r205rm-261020-1','r205df-261020-1':'r205rf-261020-1',json.loads((OLD/'variant-settings.json').read_bytes())['nonce']:nonce}
def subst(s):
 for a,b in replacements.items():s=s.replace(a,b)
 return s
def transform(v):
 if isinstance(v,str):return subst(v)
 if isinstance(v,list):return [transform(x) for x in v]
 if isinstance(v,dict):return {k:transform(x) for k,x in v.items()}
 return v
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exact(p):
 p=Path(p);s=p.stat();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=s.st_size,mode=s.st_mode)
def dump(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def assignment(s,name,v):
 nodes=[n for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)];assert len(nodes)==1;n=nodes[0];lines=s.splitlines(True);lines[n.lineno-1:n.end_lineno]=[name+' = '+repr(v)+'\n'];return ''.join(lines)
for name in ['native_diagnostic_runner.py','native_diagnostic_backend.py','qmp_capture.py','prepare_native_parent.py','prepare_current_pair_consumer.py','stage_launch_init.py']:(D/name).write_text(subst((OLD/name).read_text()))
for name in ['native_diagnostic.py','repaired_image_authority.py','fresh8b-fixture-inputs.json']:(D/name).write_bytes((OLD/name).read_bytes())
settings=transform(json.loads((OLD/'variant-settings.json').read_bytes()));settings['case_id']='FIXED_TEN_ROUNDS_CURRENT205_RETAINED_ROUTE_PROOF';dump(D/'variant-settings.json',settings)
prospective=transform(json.loads((OLD/'prospective-full-argv-NOT-PREFLIGHT.json').read_bytes()));dump(D/'prospective-full-argv-NOT-PREFLIGHT.json',prospective)
b=transform(json.loads((OLD/'STAGE-INPUTS.json').read_bytes()));b['sources']['compiled_collector']=exact(N/'check-1/collector');b['sources']['parent_manifest']=exact(OLD/'stage-launches-1/manifest.json');b['sources']['actual_parent_stage']=exact(B.parent/'failure-diagnostic-1-independent-review/ACTUAL-DIAGNOSTIC-INIT-STAGE-AND-CONSUMER-ACCEPTANCE.json');b['sources']['offline_acceptance']=exact(N/'result-2.json');dump(D/'STAGE-INPUTS.json',b)
owner=(OLD/'native_diagnostic_container_owner.py').read_text();tree=ast.parse(owner)
def value(name):return ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)))
source_map=value('SOURCE_HASHES');readonly=value('EXTRA_READONLY')
for p in sorted((N/'candidate').iterdir()):
 if p.is_file():source_map[str(p)]=ref(p)['sha256']
for name in ['native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py','repaired_image_authority.py','stage_launch_init.py','STAGE-INPUTS.json']:source_map[str(D/name)]=ref(D/name)['sha256']
source_map[str(N/'check-1/collector')]=b['sources']['compiled_collector']['sha256'];source_map[str(D/'stage-launches-1/pair-init-0755')]=b['sources']['compiled_collector']['sha256']
readonly=list(dict.fromkeys(readonly+[str(N)]))
owner=assignment(owner,'SOURCE_HASHES',source_map);owner=assignment(owner,'EXTRA_READONLY',readonly);owner=assignment(owner,'SELF',str(D/'native_diagnostic_container_owner.py'));owner=assignment(owner,'RUNNER',str(D/'native_diagnostic_runner.py'));owner=owner.replace('    source = '+repr(str(OLD/'native_diagnostic.py')),'    source = '+repr(str(D/'native_diagnostic.py')));(D/'native_diagnostic_container_owner.py').write_text(owner)
a=ast.parse((OLD/'native_diagnostic_container_owner.py').read_text());z=ast.parse(owner)
aa=[n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))];zz=[n for n in z.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))];assert len(aa)==len(zz);assert all(ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False) for x,y in zip(aa,zz) if x.name!='bound_manifest')
paths=[Path(b['sources'][name]['path']) for name in ['header_producer','overlay_module','actual_parent_stage','offline_acceptance','parent_manifest','compiled_collector']]
paths += [p for p in sorted(D.iterdir()) if p.is_file()]
paths += [B.parent/'ordinary-check-1/actual-body-0/stdout',B.parent/'ordinary-remaining-check-1/result.json',B.parent/'ACTUAL-OFFLINE-HANDOFF.json',B.parent/'FROZEN-LAUNCH-ORACLE.json']
# Pin compiler input closure and the original passed diagnostic result as authority.
paths += list(sorted((N/'candidate').glob('*')))+[N/'input-pins-2.json']
paths=list(dict.fromkeys(paths));pins=[ref(p) for p in paths];dump(D/'source-pins-v2.json',pins)
authorities={}
for p in paths:
 s=p.stat();r=ref(p);authorities[str(p)]=dict(path=str(p),sha256=r['sha256'],device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
dump(D/'pinned-source-authorities-v2.json',authorities)
profile=transform(json.loads((OLD/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json').read_bytes()));profile['source_pins']=ref(D/'source-pins-v2.json');profile['rationale']='Same accepted diagnostic init-only transform and actual owner/runner fresh-parent fixture. Reuse passed static collector with two-source retained-route proof correction; no compile, guest or root. Preserve45+10 CPU/wall commands,55CPU/60wall whole,1GiB,CPU7,32MiB stream and64MiB stage caps. Current invocation guard100percent included only.';dump(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json',profile)
executor=(OLD/'run_two_commands_source_bound_corrected.py').read_text();executor=assignment(executor,'PROFILE_SHA',ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json')['sha256']);executor=assignment(executor,'SOURCE_AUTHORITIES_SHA',ref(D/'pinned-source-authorities-v2.json')['sha256']);executor=executor.replace('len(rows)==23','len(rows)=='+str(len(pins))).replace("need(used<97,'included usage guard')","need(used<100,'included usage guard')");(D/'run_two_commands_source_bound_corrected.py').write_text(executor)
commands=transform(json.loads((OLD/'COMMAND-SET-v2.json').read_bytes()));commands['execution_profile']=ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json');commands['executor']=ref(D/'run_two_commands_source_bound_corrected.py');commands['fixed_commands']=profile['per_command'];commands['required_absent_paths']=profile['required_absent_paths'];dump(D/'COMMAND-SET-v2.json',commands)
packet={'status':'SOURCE_PROPOSAL_UNRUN_PENDING_AFFECTED_REVIEW','functional_scope':'Supported-profile functional OS/apps plus live compute-C retirement into Rust/reviewed assembly; collector Linux userland C only','source_changes':['Only existing init payload changes in a new derived copy of accepted diagnostic archive; accepted205 image/modules/apps/oracles unchanged; two changed collector source files only','Reuse already compiled check-2/collector0700; create byte-identical separate0755 stage reference; no recompile','Owner/runner/profile logic retained; path+freshnonce/source-map rebinding only; generated ordinary executor guards current100 included setting'],'source_refs':[ref(D/x) for x in ['stage_launch_init.py','prepare_current_pair_consumer.py','prepare_native_parent.py','native_diagnostic_container_owner.py','native_diagnostic_runner.py','native_diagnostic.py','native_diagnostic_backend.py','qmp_capture.py','repaired_image_authority.py']],'collector':exact(N/'check-1/collector'),'diagnostic_actual_checks':ref(N/'result-2.json'),'diagnostic_source_patch':ref(N/'route-proof-correction.patch'),'route_source_independent_acceptance':None,'source_acceptance_note':'Designated SDK semantic reviewer is closing route correction review; exact affected ordinary release and root admission required before execution','frozen_strict_oracles':ref(B.parent/'FROZEN-LAUNCH-ORACLE.json'),'parent_manifest':b['sources']['parent_manifest'],'parent_stage_review':b['sources']['actual_parent_stage'],'profile':ref(D/'EXECUTION-PROFILE-SOURCE-BOUND-v2.json'),'commands':ref(D/'COMMAND-SET-v2.json'),'executor':ref(D/'run_two_commands_source_bound_corrected.py'),'source_pins':ref(D/'source-pins-v2.json'),'source_authorities':ref(D/'pinned-source-authorities-v2.json'),'pin_count':len(pins),'native_runtime_authority':False,'throughput_target':{'strict_real_apps':20,'owner_seconds_for4x':110.4008175,'logger_seconds':120,'target_is_not_result_or_timeout':True},'diagnostic_capture_bounds':{'retained_raw_max':2097152,'current_raw_max_exclusive':1048576,'chunk_raw_max':1024,'framing_hex_growth_upper_bound':8388608,'existing_ordinary_stream_file_cap':33554432,'existing_runtime_evaluator_serial_read_cap':4194304,'runtime_evaluator_cap_unchanged':True,'overflow_behavior':'Strict failure if serial exceeds4MiB; original on-disk serial remains bounded by runtime owner capture profile and must be retained/readback independently. No reader/oracle expansion authorized here.'},'next_observation':'One ordinary metadata-preserving init stage plus affected actual owner/runner/fresh-parent fixture under explicit review; no native/root.'}
dump(D/'REVIEW-PACKET.json',packet)
for p in D.glob('*.py'):ast.parse(p.read_text())
assert all(not Path(p).exists() for p in profile['required_absent_paths']);assert len(os.fsencode(Path(settings['parent'])/('attempt-'+nonce)/'qmp.sock'))<=107
print(json.dumps({'packet':ref(D/'REVIEW-PACKET.json'),'pin_count':len(pins),'stage_executed':False,'prospective_qmp_bytes':len(os.fsencode(Path(settings['parent'])/('attempt-'+nonce)/'qmp.sock'))}))
