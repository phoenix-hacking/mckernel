"""Case-specific read-only root admission recipe; no owner or guest invocation."""
from pathlib import Path
import argparse,fcntl,hashlib,importlib.util,json,os,re,stat,subprocess,time
N=Path(__file__).resolve().parent
OUTPUT=N/'root-live-preflight-1.json'
class Refusal(RuntimeError):pass
def need(ok,message):
    if not ok:raise Refusal(message)
def ref(path):return {'path':str(path),'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'bytes':Path(path).stat().st_size}
def checked(record):
    p=Path(record['path']);need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),'canonical input')
    raw=p.read_bytes();need(len(raw)<=4*1024**2 and hashlib.sha256(raw).hexdigest()==record['sha256'],'input hash');need('bytes' not in record or len(raw)==record['bytes'],'whole descriptor bytes')
    return json.loads(raw)
def identity(p):
    s=Path(p).lstat();return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)))
def command(argv):
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=5,check=False)
    need(p.returncode==0 and p.stderr==b'' and len(p.stdout)<=4*1024**2,'bounded read-only command')
    return p.stdout.decode()
def static_joins(b):
    for record in b['source_pins']:
        need(hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()==record['sha256'],'frozen source')
    meta=checked(b['conditional_metadata']);proposal=checked(meta['proposal']);pending=checked(b['machine_pending'])
    need(meta['parent_identity']==proposal['parent']['identity']==b['parent_identity']==pending['parent_identity'],'parent static join')
    need(pending['independent_static_execution_decision']==b['static_review'],'static review join')
    checked(b['static_review'])
    need(proposal['profile']['mckernel_cpus']==2 and proposal['profile']['memory']==proposal['profile']['memory_swap']==12884901888,'fixed profile')
    spec=importlib.util.spec_from_file_location('two_cpu_snapshot_owner',N/'native_diagnostic_container_owner.py')
    owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
    _,manifest=owner.bound_manifest(b['manifest']['path'],b['manifest']['sha256'])
    need(manifest['artifacts']['mckernel_image']['sha256']==b['repaired_image_sha256'] and manifest['pair']['host_cpus']==[1,2] and manifest['pair']['cpus']==[0,1],'fixed NEW205/two CPU authority')
    need(type(manifest.get('pair_rounds')) is int and manifest['pair_rounds']==10,'fixed TEN sequential pair rounds; no duration knob')
    c=checked(b['mandatory_consumer_review']);s=checked(b['stage_review'])
    need(c==s and c['schema']=='mckernel.independent-actual-diagnostic-init-stage-consumer-acceptance.v1' and c['decision']=='PASS_ACTUAL_DIAGNOSTIC_INIT_ONLY_STAGE_AND_OWNER_RUNNER_FRESH_PARENT','exact actual combined stage/consumer contract')
    need(c['ordinary_stage_acceptance'] is True and c['consumer_preparation_acceptance'] is True and c['runtime_release'] is False and c['application_acceptance'] is False,'preparation only actual acceptance')
    pre=checked(c['actual_full_preflight']);consumer=checked(c['actual_consumer_result']);facts=c['facts']
    need(c['stage_manifest']==proposal['stage_manifest'] and consumer['normalized_manifest']==b['manifest'],'actual stage and normalized manifest descriptors')
    need(facts['parent_identity']==b['parent_identity']==pre['parent_identity'] and facts['parent_nine_field_identity']==b['parent_review_identity'],'complete actual parent identity roles')
    need(facts['nonce']==proposal['nonce']==pre['nonce'] and facts['parent']==proposal['parent']['path'],'actual parent and nonce')
    need(owner.SOURCE_HASHES==b['runtime_source_hashes'] and pre['consumed_paths']==b['entire_consumed_paths'],'whole actual runtime source map and consumed path list')
    need(pre['owner_argv']==proposal['argv'] and pre['qemu_argv']==b['qemu_argv'] and pre['inside_argv']==b['inside_argv'],'actual exact owner/runner/QEMU argv')
    need(facts['guest_runs']==0 and facts['real_child_commands']==0 and facts['exact_fixture_pair_report'] is True and facts['all_direct_children_joined'] is True and facts['all_groups_absent'] is True,'closed actual ordinary composition no native substitution')
    return proposal,owner
def same_ref(a, b, label):
    need(a == b, label)

def terminal_joins(t,b):
 need(t==checked(b['physical_review']),'whole exact latest owned-request77 physical report')
 need(t['schema']=='mckernel.actual-owned-caller78-fullcrate-physical-retirement-review.v1' and t['status']=='PASS' and t['decision']=='ACCEPT_EXACT_CALLER78_CRATE_OWNER_POSITIVE_PHYSICAL_RETIREMENT_AND_THREE_RECORD_RELEASE_ONLY','actual crate physical-only contract')
 need(t['native_or_guest_acceptance'] is False and t['source_activation'] is False,'physical retirement is not source/native activation')
 c=b['physical_predecessor'];f=t['physical_facts'];outer=t['outer_facts'];request=checked(t['source_request']);owner=checked(t['owner_receipt']);post=checked(t['postflight']);archive=checked(t['archive']);released=checked(t['release_complete']);authorized=checked(t['release_authorized'])
 need(t['source_request']==b['crate_request'],'exact current crate request descriptor')
 need(outer['direct_child_joined'] is True and outer['process_group_absent'] is True and outer['observer_error'] is None and outer['returncode']==0,'outer positive direct/group retirement')
 need(t['container_id']==owner['container_id']==f['container_id']==c['container_id'] and t['owner_nonce']==owner['owner_nonce']==f['request_owner_nonce']==request['nonce']==c['owner_nonce'],'actual crate CID and owner nonce')
 need(owner['retired'] is True and owner['cleanup_separately_required'] is False and owner['terminal_container_retained'] is False and owner['client_retirement_unproven'] is False and owner['cleanup_status']=='PASS_OWNED_REMOVAL_AND_RECORD_RELEASE','actual crate positive owned cleanup')
 need(owner['postflight']==post and post['all_clients_reaped'] is True and post['container_absent'] is True and post['absence']['absent'] is True and post['absence']['container_id']==c['container_id'] and post['absence']['nonce']==c['owner_nonce'],'whole crate owner/postflight/absence join')
 groups=post['client_group_checks'];need(len(groups)==f['owned_group_check_count'] and all(g['empty'] is True and g['surviving_members']==[] for g in groups),'all exact crate owned group checks')
 need(len({g['pid'] for g in groups})==owner['client_count']==f['client_count']==c['client_count']==len(t['client_evidence'])>0,'whole actual crate client count')
 for row in t['client_evidence']:
  client=checked(row['status']);need(client['state']=='exited' and client['exit_code']==0 and client['pid'] in {g['pid'] for g in groups} and row['status']['path'] in {g['status_path'] for g in groups},'actual closed caller client status and owned group tuple')
 need(archive['nonce']==request['nonce']==released['nonce'] and len(archive['records'])==3 and released['status']=='OWNED_RECORDS_RELEASED' and released['archive_sha256']==t['archive']['sha256'],'actual archive and three-record completion')
 need(authorized['status']=='POSTFLIGHT_RELEASE_AUTHORIZED' and authorized['archive_sha256']==t['archive']['sha256'],'exact record release authorization')
 records={r['path']:r for r in archive['records']}
 need(set(records)==set(f['current_record_paths_absent'])=={c['lease_path'],c['common_exclusion'],c['shared_heavy']},'three exact released coordination paths')
 for key,field in [('lease_path','lease'),('common_exclusion','common_exclusion'),('shared_heavy','shared_heavy_operation')]:
  need(owner[field]['path']==c[key] and owner[field]['record']==records[c[key]]['record'],'whole archived owned record join '+key)
 need(owner['lease']['record']['nonce']==f['lease_nonce']==c['lease_nonce'] and owner['common_exclusion']['record']['boot_id']==owner['shared_heavy_operation']['record']['boot_id']==c['boot_id'],'distinct operation lease and current boot')
 need(t['physical_release'] is True and t['retired'] is True and t['container_absent'] is True and t['three_owned_records_released'] is True and t['all_owned_groups_empty'] is True,'complete caller78 independent physical facts')
 need(f['exact_stopped_CID_removal_and_name_label_id_absence'] is True and f['records_released_under_accepted_owner_development_flock'] is True and f['all_client_states_exited'] is True and f['all_owned_groups_empty'] is True,'caller78 positive owner/record/client boundary')
 terminal=f['terminal_state'];need(terminal['Status']=='exited' and terminal['Running'] is False and terminal['Paused'] is False and terminal['Restarting'] is False and terminal['OOMKilled'] is False and terminal['Dead'] is False and terminal['Pid']==0 and terminal['ExitCode']==f['wait_exit_code']==0,'actual terminal state and owner wait')
 need(f['current_lock_availability_rechecked_by_reviewer'] is False,'report makes no fresh mutex claim; root collect_live must acquire it')
 need(b['root_lock_identity']==dict(device=27,inode=4,uid=0,gid=0,mode='0o644'),'permanent mutex exact identity; live reacquire remains collect_live')
 for path in (c['lease_path'],c['common_exclusion'],c['shared_heavy']):need(not os.path.lexists(path),'current released crate coordination path absent')
def collect_live(b,proposal,owner):
    parent=Path(proposal['parent']['path']);scratch=Path(owner.SCRATCH);lock=Path(owner.LOCK)
    free=False
    with lock.open('r') as stream:
        try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);free=True
        except BlockingIOError:pass
        finally:
            if free:fcntl.flock(stream,fcntl.LOCK_UN)
    names=['owner.stdout','owner.stderr','owner-join.json']+[f'readback-{i}.{suffix}' for i in range(1,4) for suffix in ('stdout','stderr','command.json')]
    paths=[b['physical_predecessor']['common_exclusion'],b['physical_predecessor']['shared_heavy']]
    capacity={}
    for path,floor in [(Path(owner.REPO),16*1024**3),(scratch,12*1024**3)]:
        s=os.statvfs(path);capacity[str(path)]={'available_bytes':s.f_bavail*s.f_frsize,'floor_bytes':floor,'reserve_bytes':679477248}
    state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_text())
    s=scratch.stat()
    return {'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'parent_identity':identity(parent),
      'parent_canonical':parent.resolve(strict=True)==parent,'parent_empty':not list(parent.iterdir()),
      'attempt_absent':not os.path.lexists(parent/('attempt-'+proposal['nonce'])),
      'owner_evidence_absent':not os.path.lexists(str(parent)+'.owner-'+proposal['nonce']),
      'fresh_outputs_absent':all(not os.path.lexists(N/name) for name in names) and not os.path.lexists(OUTPUT),
      'scratch_identity':[s.st_dev,s.st_ino],
      'mount':json.loads(command(['/usr/bin/findmnt','-J','-o','TARGET,UUID','-T',str(scratch)]))['filesystems'],
      'root_lock_identity':identity(lock),'root_mutex_snapshot_free':free,
      'released_paths_absent':{p:not os.path.lexists(p) for p in paths},
      'predecessor_container_absent':command(['/usr/bin/docker','ps','-aq','--no-trunc','--filter','id='+b['physical_predecessor']['container_id']])=='',
      'image_id':command(['/usr/bin/docker','image','inspect','--format','{{.Id}}',owner.IMAGE]).strip(),
      'image_record_sha256':hashlib.sha256(Path(owner.IMAGE_RECORD).read_bytes()).hexdigest(),
      'cgroup':{p:Path(p).read_text().strip() for p in owner.CGROUP},'capacity':capacity,
      'mem_available_bytes':int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024,
      'launcher_phase':state['phase'],'launcher_stop_reason':state['stop_reason'],'included_usage_percent':state['last_rate_limits']['primary']['usedPercent']}
def validate_live(o,b,owner):
    need(o['boot_id']==b['physical_predecessor']['boot_id'],'current boot')
    need(o['parent_identity']==b['parent_identity'] and all(o[k] is True for k in ('parent_canonical','parent_empty','attempt_absent','owner_evidence_absent','fresh_outputs_absent')),'actual parent/fresh outputs')
    need(o['scratch_identity']==b['scratch_identity'] and o['mount']==[{'target':owner.SCRATCH,'uuid':b['physical_predecessor']['filesystem_uuid']}],'current scratch mount')
    need(o['root_lock_identity']==b['root_lock_identity'] and o['root_mutex_snapshot_free'] is True,'root mutex')
    need(o['released_paths_absent']=={b['physical_predecessor'][key]:True for key in ('common_exclusion','shared_heavy')} and o['predecessor_container_absent'] is True,'current physical/common/shared release')
    need(o['image_id']==owner.IMAGE and o['image_record_sha256']==owner.IMAGE_RECORD_SHA256 and o['cgroup']==owner.CGROUP,'actual image/cgroup')
    for path,floor in ((owner.REPO,16*1024**3),(owner.SCRATCH,12*1024**3)):
        row=o['capacity'][path];need(row['floor_bytes']==floor and row['reserve_bytes']==679477248 and row['available_bytes']>=floor+679477248,'capacity floors/reserve')
    need(o['mem_available_bytes']>=16*1024**3,'memory headroom')
    need(o['launcher_phase']=='running' and o['launcher_stop_reason'] is None and type(o['included_usage_percent']) in (int,float) and 0<=o['included_usage_percent']<100,'launcher/included usage')
def publish(result):
    with OUTPUT.open('x') as f:
        os.fchmod(f.fileno(),0o644)
        json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return ref(OUTPUT)
def main(argv=None):
    p=argparse.ArgumentParser(allow_abbrev=False)
    for flag in ('bindings-sha256','terminal','terminal-sha256'):p.add_argument('--'+flag,required=True)
    a=p.parse_args(argv);need(os.getuid()==os.geteuid()==0,'root read-only observer required')
    b=checked({'path':str(N/'fresh-snapshot-bindings.json'),'sha256':a.bindings_sha256})
    proposal,owner=static_joins(b);terminal_ref=b['physical_review'];need(terminal_ref['path']==a.terminal and terminal_ref['sha256']==a.terminal_sha256,'exact selected full terminal descriptor')
    terminal_joins(checked(terminal_ref),b)
    o=collect_live(b,proposal,owner);validate_live(o,b,owner)
    result=dict(status='PASS_LIVE_PREEXECUTION_SNAPSHOT',time_epoch=time.time(),parent_identity=b['parent_identity'],
      exclusive_heavy_accepted=True,root_mutex_snapshot_free=True,terminal_acceptance=terminal_ref,
      independent_static_execution_decision=b['static_review'],accepted_actual_stage_fixture_parent_review=b['static_review'],
      non_temporal_join_result=b['non_temporal_freeze'],boot_id=o['boot_id'],capacity=o['capacity'],
      mem_available_bytes=o['mem_available_bytes'],included_usage_percent=o['included_usage_percent'],
      heavy_profile={k:proposal['profile'][k] for k in ('cpuset','cpus','memory','memory_swap','pids','network')},
      guest_profile={'memory_mib':8192,'vcpus':4,'numa_nodes':2},released_paths_absent=list(o['released_paths_absent']),
      current_predecessor_container_absent=True,image_id=o['image_id'],cgroup=o['cgroup'])
    record=publish(result);print(json.dumps({'status':result['status'],**record}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
