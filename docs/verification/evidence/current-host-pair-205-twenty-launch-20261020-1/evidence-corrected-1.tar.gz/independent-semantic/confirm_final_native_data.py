from pathlib import Path
import json,hashlib,re,time
O=Path(__file__).parent;D=Path('/home/holden/mckernel-work/host-preparation/current-host-pair-205-launch-expansion-20261020-1/failure-diagnostic-1/route-proof-correction-1/stage-preparation-1');Q=D/'native-packet-1';N=D.parent;cache={}
def ref(p):
 p=Path(p)
 if str(p) not in cache:
  b=p.read_bytes();cache[str(p)]=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 return cache[str(p)]
def load(p):return json.loads(Path(p).read_bytes())
r=load(O/'ROUTE-NATIVE-SOURCE-AND-NONTEMPORAL-RELEASE.json');rr=ref(O/'ROUTE-NATIVE-SOURCE-AND-NONTEMPORAL-RELEASE.json');assert rr['sha256']=='30d672c28c33182ade02b235e5daeab9359019f6ae1b64611960e455763d197e'
status=load(Q/'final-bind-1.status.json');assert status['returncode']==0 and status['direct_child_joined'] and status['process_group_absent'] and status['included_usage_percent']<100
expected=list(r['allowed_binder_argv_template']);expected[-1]=rr['sha256'];assert status['argv'][status['argv'].index('/home/holden/anaconda3/bin/python3'):]==expected
out=load(Q/'final-bind-1.stdout');assert out['outputs']==19 and out['rows']==7 and out['fresh_capture_paths']==49 and out['snapshots']==out['guest_runs']==0 and out['pending'] is False and (Q/'final-bind-1.stderr').stat().st_size==0
pairs=[];hashmap={}
for before in r['reviewed_pending_outputs']:
 p=Path(before['path']);assert ref(p)==before;canonical=Path(str(p).removesuffix('.PENDING-STATIC-CORRECTED'));after=ref(canonical);pairs.append((p,canonical,before,after));hashmap[before['sha256']]=after['sha256']
assert len(pairs)==19
bycanonical={str(c):a for p,c,b,a in pairs}
statusmap={'PENDING_INDEPENDENT_STATIC_DATA_REVIEW':'PASS_ACTUAL_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT','PENDING_INDEPENDENT_STATIC_DATA_DECISION':'PASS_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT','PENDING_ONE_INDEPENDENT_SOURCE_DATA_MAPPING_REVIEW':'BOUND_NON_TEMPORAL_PENDING_ROOT_ADMISSION'}
# Status progressions are fixed by the reviewed binder's final flag.
expectedstatuses={'conditional-metadata.json':'PASS_NONTEMPORAL_DATA_ONLY','non-temporal-freeze.json':'PASS_ACTUAL_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT','FINAL-NONTEMPORAL-DATA-INDEX.json':'PASS_STATIC_DATA_ONLY_PENDING_LAST_SNAPSHOT','SNAPSHOT-STATIC-EQUALITY-AND-CAPPED-ARGV.json':'PASS_SOURCE_DERIVED_STATIC_DATA_ONLY_NO_SNAPSHOT','FINAL-IHK-LOGGING-CHECK-CONFIG.json':'PASS_NON_TEMPORAL_CURRENT_IHK_LOGGING_NATIVE_CHECK_CONFIG','NATIVE-COHERENT-REVIEW-PACKET.json':'BOUND_NON_TEMPORAL_PENDING_ROOT_ADMISSION'}
errors=[]
def compare(a,b,path):
 if isinstance(a,dict) and isinstance(b,dict):
  if a.get('path')==rr['path'] and 'sha256' in a and a['sha256'] is None:
   if b!=rr:errors.append(path+':static descriptor')
   return
  if set(a)!=set(b):errors.append(path+':keys');return
  for k in a:
   if k=='status' and path.endswith(':') and Path(path.split(':',1)[0]).name in expectedstatuses:
    if b[k]!=expectedstatuses[Path(path.split(':',1)[0]).name]:errors.append(path+':status')
   elif k in ('bytes','size') and isinstance(a.get('path'),str) and a.get('sha256') in hashmap:
    if b[k]!=bycanonical[a['path']]['bytes']:errors.append(path+':refsize')
   else:compare(a[k],b[k],path+'/'+str(k))
 elif isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):errors.append(path+':listlen');return
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 else:
  expected=hashmap.get(a,a) if isinstance(a,str) else a
  if expected!=b:errors.append(path+':value')
for p,c,before,after in pairs:
 if c.suffix=='.py':
  a=p.read_text();b=c.read_text()
  for old,new in hashmap.items():a=a.replace(old,new)
  assert a==b
 else:compare(load(p),load(c),str(c)+':')
# All changed JSON status strings are on the six explicitly listed top-level outputs.
errors=[e for e in errors if not any(e==str(c)+':/status:value' and load(c)['status']==expectedstatuses[c.name] for c in [x[1] for x in pairs] if c.name in expectedstatuses)]
assert not errors,errors[:5]
packet=load(Q/'NATIVE-COHERENT-REVIEW-PACKET.json');assert ref(Q/'NATIVE-COHERENT-REVIEW-PACKET.json')==out['packet'] and packet['static_decision']==rr and packet['binding_source']==r['binding_source'] and packet['snapshot_source']['sha256']=='41625a807b34ad07fdddc5e59218f4bb97e689277fac9aa1f8762f3696e7e9cf'
occ=[];unique={}
def walk(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) and re.fullmatch('[0-9a-f]{64}',x['sha256']) and x['path'].startswith(str(N)):
   v=ref(Path(x['path']));assert v['sha256']==x['sha256'] and v['bytes']==x.get('bytes',x.get('size',v['bytes']));occ.append(x['path']);unique[x['path']]=v
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for p,c,b,a in pairs:
 if c.suffix=='.json':walk(load(c))
assert len(occ)==78 and len(unique)==30
seven=load(Q/'FINAL-SEVEN-ROOT-CALL-DATA.json');assert all(not Path(p).exists() for p in seven['fresh_capture_and_actual_command_paths']) and not Path(seven['snapshot_output']).exists() and not Path(seven['final_machine_output']).exists() and not Path(seven['final_guard_output']).exists()
report=dict(schema='mckernel.independent-route-native-final19-publication-confirmation.v1',decision='PASS_EXACT_REVIEWED_FINAL19_PUBLICATION',reviewer='/root/sdk66_boundary_review',implementation_ownership=False,reviewed_at_epoch=time.time(),source_static_release=rr,actual_status=ref(Q/'final-bind-1.status.json'),actual_stdout=ref(Q/'final-bind-1.stdout'),packet=ref(Q/'NATIVE-COHERENT-REVIEW-PACKET.json'),seven_rows=ref(Q/'FINAL-SEVEN-ROOT-CALL-DATA.json'),root_executor=ref(Q/'root-execute-seven-1.py'),published_outputs=[a for p,c,b,a in pairs],counts=dict(outputs=19,descriptor_occurrences=78,unique_inputs=30,rows=7,fresh_capture_paths=49),mechanical_result='Only reviewed static descriptor/status progression and consequent hashes/lengths changed from corrected pending DATA. All other values and source bytes match. Snapshot/machine/guard and49capturepaths still absent.',source_and_physical_acceptance_reused=True,root_admission_last=True,runtime_release=False,application_acceptance=False,new_tests_compilers_root_or_workloads=0)
p=O/'ROUTE-NATIVE-FINAL19-PUBLICATION-CONFIRMATION.json';p.open('x').write(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(decision=report['decision'],report=ref(p),packet=report['packet'],seven=report['seven_rows'],executor=report['root_executor'])))
