from pathlib import Path
import hashlib,importlib.util,json,os,resource,shutil,time
N=Path(__file__).resolve().parent
W=N/'check-2'; assert not W.exists();W.mkdir(mode=0o700)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert os.sched_getaffinity(0)=={7}
assert resource.getrlimit(resource.RLIMIT_AS)[0]==1073741824
assert resource.getrlimit(resource.RLIMIT_CPU)[0]==30
assert resource.getrlimit(resource.RLIMIT_FSIZE)[0]==33554432
assert ref('/usr/bin/gcc')['sha256']=='6cb2d84ccd9fd3485d4e47ba032e626be65692601c38fad46866a6b565f3100f'
for mount,floor in [('/home/holden',16<<30),('/home/holden/mckernel-work/scratch',12<<30)]:
 assert shutil.disk_usage(mount).free>floor+(640<<20)
assert int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>2<<30
pins=[ref(p) for p in sorted((N/'candidate').glob('*'))]+[ref(p) for p in sorted((N/'fixtures').glob('*'))]
(N/'input-pins-2.json').write_text(json.dumps(pins,indent=2)+'\n')
e=Path('/home/holden/mckernel-work/host-preparation/current-host-pair-205-compatibility-20261019-1/ordinary-envelope-1/run_three_commands_source_bound.py')
assert ref(e)['sha256']=='37e5d4fcf0d5ad196627a1c60831ff4887a14a8fa89c9ebe29c82387faf1d6c4'
spec=importlib.util.spec_from_file_location('capture',e);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.monotonic();rows=[]
def run(name,argv):
 d=W/name;d.mkdir();(d/'command.json').write_text(json.dumps({'argv':argv})+'\n')
 r=m.owned_capture({'argv':argv},d,28-(time.monotonic()-start),lambda:None);m.write(d/'status.json',r);rows.append({'name':name,**r})
 assert r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and not r['error'] and not r['retirement_error'],r
 assert not (d/'stderr').read_bytes()
 return (d/'stdout').read_text()
flags=['/usr/bin/gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-static','-fno-pie','-no-pie','-Wl,-z,noexecstack','-DND_CORE_THREADS','-DND_PAIR_LAUNCH_EXPANSION']
run('compile-collector',flags+[str(N/'candidate/pair_collector.c'),'-o',str(W/'collector')])
run('compile-body',flags+[str(N/'fixtures/actual_launch_expansion_body.c'),'-o',str(W/'body')])
checks=[]
for case in (29,30):
 cwd=W/('workspace-'+str(case));cwd.mkdir()
 serial=run('case-'+str(case),[str(W/'body'),str(case),str(cwd)])
 assert 'DIAGNOSTIC_TAMPER_REFUSED '+str(case) in serial
 assert '"kind":"current_raw"' in serial and '"kind":"retained"' not in serial
 assert 'ND_PAIR_ROUNDS_COMPLETE ' not in serial
 checks.append({'case':case,'tamper_refused':True})
for case,phase,retained in [(0,None,10),(8,'stream_identity_oracle',4),(3,'unsafe_owner_handoff',0),(14,'app0_trace_oracle',9),(16,'pair_run',9),(17,'post_round_procfs',8)]:
 cwd=W/('workspace-'+str(case));cwd.mkdir()
 serial=run('case-'+str(case),[str(W/'body'),str(case),str(cwd)])
 if phase:
  fail=json.loads(next(x.split(' ',1)[1] for x in serial.splitlines() if x.startswith('ND_PAIR_ROUND_FAIL ')))
  assert fail['phase']==phase,(case,fail)
  assert 'ND_PAIR_ROUNDS_COMPLETE ' not in serial
 if case==3:assert 'ND_PAIR_DIAGNOSTIC_' not in serial
 elif case:
  chunks={};begins={};ends={}
  for line in serial.splitlines():
   if not line.startswith('ND_PAIR_DIAGNOSTIC_'):continue
   tag,value=line.split(' ',1);v=json.loads(value);key=(v['kind'],v['round'])
   if tag.endswith('BEGIN'):assert key not in begins;begins[key]=v['bytes'];chunks[key]=bytearray()
   elif tag.endswith('CHUNK'):assert v['offset']==len(chunks[key]);chunks[key]+=bytes.fromhex(v['hex'])
   elif tag.endswith('END'):ends[key]=v['bytes']
  assert begins==ends and len(begins)==retained+1
  for (kind,rnd),raw in chunks.items():
   source=cwd/'case/evidence'/('kernel.log' if kind=='current_raw' else 'round%d/current-trace.log'%rnd)
   assert bytes(raw)==source.read_bytes() and len(raw)==begins[kind,rnd]
 else:assert serial.count('ND_PAIR_ROUND_END ')==10 and serial.count('ND_PAIR_ROUNDS_COMPLETE ')==1
 checks.append({'case':case,'phase':phase,'retained_rounds':retained})
assert pins==[ref(p['path']) for p in pins]
result={'status':'PASS_OFFLINE_ONLY','checks':checks,'commands':rows,'elapsed_seconds':time.monotonic()-start,'actual_guest_launches':0}
(N/'result-2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'compiles':2,'actual_guest_launches':0}))
