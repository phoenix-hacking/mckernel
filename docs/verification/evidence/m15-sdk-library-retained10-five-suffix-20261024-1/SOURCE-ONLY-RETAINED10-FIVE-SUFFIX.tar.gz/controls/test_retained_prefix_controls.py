"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Pure retained-consumer vectors: small saved JSON/streams only; no archive read or processes.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,unittest,ast
R=Path(__file__).parent
D=R.parent
N4=D.parent
C=N4/'workspace/native-running-modules-candidate-faa9c865ce9c9943c8fcc7774be40f7d'
s=importlib.util.spec_from_file_location('retained_prefix_actual_consumer',D/'retained_prefix_consumer.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def pinned(path,digest):
    raw=path.read_bytes();assert len(raw)<=1048576 and hashlib.sha256(raw).hexdigest()==digest
    return raw
class RetainedPrefixControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.receipt=json.loads(pinned(C/'evidence/receipt.json','214bc592fb6561c6d79caadb3a29626f72d08fc5813a7e14fb11d8b3aab4072c'))
        cls.prep=json.loads(pinned(N4/'preparation.json',cls.receipt['preparation_sha256']))
        cls.commands=json.loads(pinned(N4/'commands.json',cls.prep['commands']['sha256']))
        cls.streams=[]
        for row in cls.receipt['commands']:
            values={}
            for name in ('stdout','stderr'):
                item=row['result']['captures'][name]
                values[name]=pinned(C/Path(item['path']).relative_to('/work'),item['sha256'])
            cls.streams.append(values)
        cls.metadata=json.loads((D/'ACTUAL-RETAINED-PREFIX10.INTERPRETATION.NOT-FULL-SDK-PASS.json').read_bytes())['archive_fd_stat_only']
    def fixture(self):
        return copy.deepcopy([self.receipt,self.prep,self.commands,self.streams,self.metadata])
    def call(self,values):return m.interpret_prefix(*values)
    def changed_stderr(self,values,raw):
        values[3][9]['stderr']=raw
        item=values[0]['commands'][9]['result']['captures']['stderr']
        item.update(sha256=hashlib.sha256(raw).hexdigest(),size=len(raw))
    def test_exact_actual_first10_qualifies_without_relabeling_FAIL(self):
        result=self.call(self.fixture())
        self.assertEqual(result['original_driver_status'],'FAIL')
        self.assertEqual(result['status'],'QUALIFIED_RETAINED_FIRST10_ONLY_SDK_LINK_PENDING')
        self.assertEqual(len(result['diagnostics']['warnings']),7)
        self.assertEqual(result['native_static_libs'],m.NATIVE_FLAGS)
        self.assertFalse(result['compiler_reexecuted'])
        self.assertFalse(result['archive_rehashed'])
        self.assertFalse(result['full_SDK_library_acceptance'])
    def test_unknown_warning_refused_even_with_updated_stream_descriptor(self):
        v=self.fixture();self.changed_stderr(v,v[3][9]['stderr']+b'warning: unexpected diagnostic\n')
        with self.assertRaisesRegex(ValueError,'exact retained compiler diagnostics'):self.call(v)
    def test_wrong_warning_source_refused_even_if_producer_map_matches(self):
        v=self.fixture();path=m.WARNING_SOURCES['abort'][1]
        next(r for r in v[1]['closure'] if r['path']==path)['sha256']='0'*64
        v[0]['source_sha256'][path]='0'*64
        with self.assertRaisesRegex(ValueError,'warning exact source/line/hash'):self.call(v)
    def test_dirty_join_refused(self):
        for field,value in [('group_absent',False),('direct_child_joined',False),('closed_streams',False),('timed_out',True),('retirement_error','unknown')]:
            with self.subTest(field=field):
                v=self.fixture();v[0]['commands'][3]['result'][field]=value
                with self.assertRaisesRegex(ValueError,'positive prefix command'):self.call(v)
    def test_missing_native_flags_refused(self):
        v=self.fixture();raw=v[3][9]['stderr'];line=b'note: native-static-libs: '+b' '.join(a.encode() for a in m.NATIVE_FLAGS)+b'\n'
        self.assertIn(line,raw);self.changed_stderr(v,raw.replace(line,b''))
        with self.assertRaisesRegex(ValueError,'exact retained compiler diagnostics'):self.call(v)
    def test_each_archive_identity_change_refused(self):
        for field in ['device','inode','mode','nlink','uid','gid','size','mtime_ns','ctime_ns']:
            with self.subTest(field=field):
                v=self.fixture();v[4][field]=v[4][field]+1 if isinstance(v[4][field],int) else '0o600'
                with self.assertRaisesRegex(ValueError,'stable metadata'):self.call(v)
    def test_wrong_archive_producer_hash_refused(self):
        v=self.fixture();v[0]['artifacts'][m.ARCHIVE]['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'archive producer identity'):self.call(v)
    def test_failed_compiler_refused(self):
        v=self.fixture();v[0]['commands'][9]['result']['returncode']=1
        with self.assertRaisesRegex(ValueError,'positive prefix command'):self.call(v)
    def test_missing_prefix_command_refused(self):
        v=self.fixture();v[0]['commands'].pop()
        with self.assertRaisesRegex(ValueError,'first10 actual only'):self.call(v)
    def test_wrong_compiler_argv_refused(self):
        v=self.fixture();v[0]['commands'][9]['actual_argv'][0]='/usr/bin/rustc'
        with self.assertRaisesRegex(ValueError,'positive prefix command'):self.call(v)
    def test_changed_saved_stream_refused(self):
        v=self.fixture();v[3][1]['stdout']+=b'corrupt'
        with self.assertRaisesRegex(ValueError,'actual saved stream'):self.call(v)
    def test_production_budget_and_hash_helpers_preserved(self):
        old=ast.parse((N4/'library_sdk_driver.py').read_bytes());new=ast.parse((R/'library_sdk_driver.py').read_bytes())
        for name in ['digest','tool_digest','positive','limits','budget','load']:
            before=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name==name)
            after=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(ast.dump(before,include_attributes=False),ast.dump(after,include_attributes=False),name)
if __name__=='__main__':unittest.main(verbosity=2)
