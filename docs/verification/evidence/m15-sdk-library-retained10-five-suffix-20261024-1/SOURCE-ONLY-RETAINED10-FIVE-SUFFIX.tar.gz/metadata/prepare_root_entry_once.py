"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
ROOT metadata preparation once for retained10 + five fresh suffix, reusing SDK request/entry/base payload schema.
Creates only the exact new workspace/candidate, request/query input/base-payload/entry data.
No imports of runtime owners, root query, Docker, compiler, target or ownership API.
"""
from pathlib import Path
import os,stat,json,hashlib,sys
R=Path(__file__).parent
N=R.parent.parent
O=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1')
A=N/'publication-preparation-1/admission-preparation-1'
PINS={'/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/REQUEST.PENDING.json': '52ad05c22ab73fbaebeb1364f8b4b47ce05dff2f6c1f3deed5bcc0a28071b16b', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/RUNTIME-SOURCE-REVIEW-PINS.json': '10a78b342f1dd532d2720073e715b24ee70cd752563c346a1970a18c45a20982', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/ROOT-RECORDED-INDEPENDENT-SOURCE-APPROVAL.json': '0c677473d148d1c9a5a313ddb7bf268c79701894fa859cca5a67f08e3a003dae', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/library_sdk_owner.py': '6ed7f3a0fb3be4da1d1505c5f33c519344b8c1916fe959c963a9eaddd65a1b47', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/library_sdk_driver.py': '864f966a1102843c5cf184ff001c71e69c25e4c675d4220cf18a872ee99faf2a', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/selected-BFD-image-correction-1/actual-compiler-diagnostics-correction-1/runtime-suffix-successor-1/preparation.json': 'f04996ad7ab48018475cc2948b039d0e1faadec0dda9ea1015da970e6624a04d', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/RELEASE.ROOT.BASE.PAYLOAD.NO-FRESH.json': 'ba62b33348e087f76ab53cc74578e5203e50f67e67aa1c254907e87096b076c5', '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/toolchain-mount-correction-1/tool-FD-expert-correction-1/ROOT-ACTUAL-OWNER-ENTRY.FRESH3.json': 'ab2a4d5debb684f73fef0884df363249ceae7ab40a89f743e323ce7eb410bf95'}
NONCE='c0145b52636dfa7ff697426d228a2518'
IMAGE='sha256:41778f1f22fd68897c1209e225a9807a197ed47bf0edd17835821bb5986e50b5'
PHYSICAL=None
POSTJOIN=None
BASIS=Path('/home/holden/mckernel-work/scratch/mckernel-exact-candidate-scratch-22-authority3-output')
BACKING=Path('/home/holden/mckernel-work/scratch.ext4')
assert os.getuid()==os.geteuid()==0 and len(sys.argv)==1
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def load(path):
    assert str(path) in PINS
    assert not path.is_symlink() and path.is_file()
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert len(raw)<=1048576 and all(getattr(before,k)==getattr(after,k) for k in FIELDS)
    assert hashlib.sha256(raw).hexdigest()==PINS[str(path)]
    return json.loads(raw)
def node(path):
    meta = path.stat()
    return dict(path=str(path), device=meta.st_dev, inode=meta.st_ino,
                mode=stat.S_IMODE(meta.st_mode), uid=meta.st_uid, gid=meta.st_gid)
def safe(path):
    assert path.is_absolute() and all(not p.is_symlink() for p in (path,*path.parents))
    return path

def write(path,obj):
    raw=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        view=memoryview(raw)
        while view:
            count=os.write(fd,view);assert count>0;view=view[count:]
        os.fchown(fd,1000,1000);os.fsync(fd)
    finally:os.close(fd)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
for name,digest in PINS.items():
    p=safe(Path(name));assert p.is_file()
    raw=p.read_bytes();assert len(raw)<=1048576 and hashlib.sha256(raw).hexdigest()==digest
request=load(N/'REQUEST.PENDING.json')
pinmap=load(N/'RUNTIME-SOURCE-REVIEW-PINS.json')
approval_ref=dict(path=str(N/'ROOT-RECORDED-INDEPENDENT-SOURCE-APPROVAL.json'),sha256=PINS[str(N/'ROOT-RECORDED-INDEPENDENT-SOURCE-APPROVAL.json')])
approval=load(N/'ROOT-RECORDED-INDEPENDENT-SOURCE-APPROVAL.json')
matrix_raw=(N/'RUNTIME-SOURCE-REVIEW-PINS.json').read_bytes()
assert approval['matrix_sha256']==hashlib.sha256(matrix_raw).hexdigest()=='10a78b342f1dd532d2720073e715b24ee70cd752563c346a1970a18c45a20982'
assert approval['ready_sha256']=='c49e3dc1c5ccb616f7945548c0a21afdf68ea46b859d531c95dca9d969539feb'
assert approval['reviewer']=='/root/m15_sdk_library_release_review' and approval['execution_authorized'] is False
approval=dict(approval,source_sha256=pinmap['source_sha256'],original_approval=approval_ref,
              record_writer='/root',record_origin='dispatcher_digest_checked_matrix_expansion_of_genuine_review')
approval_path=N/'ROOT-RECORDED-INDEPENDENT-SOURCE-APPROVAL.VALIDATOR-COMPATIBLE.json' 
assert request['nonce']==NONCE and request['image_id']==IMAGE
assert approval['decision']=='PASS_SOURCE' and approval['implementation_ownership'] is False
assert approval['source_sha256']==pinmap['source_sha256']
assert request['input_root']==str(N) and request['driver']['path']==str(N/'library_sdk_driver.py')
assert node(safe(N))['uid']==node(N)['gid']==1000 and node(N)['mode']==0o700
workspace=N/'workspace'
candidate=workspace/('native-running-modules-candidate-'+NONCE)
owner_evidence=workspace/('native-running-modules-owner-'+NONCE)
request_path=N/'REQUEST.ROOT.FINAL.json'
query_inputs=A/'QUERY-INPUTS.ROOT.json'
payload_path=N/'RELEASE.ROOT.BASE.PAYLOAD.NO-FRESH.json'
entry_path=N/'ROOT-OWNER-ENTRY.PENDING-FINAL-RELEASE.json'
result_path=R/'ROOT-DATA-PREPARATION.RESULT.json'
outputs=(workspace,candidate,owner_evidence,request_path,query_inputs,payload_path,entry_path,result_path,approval_path)
assert all(not os.path.lexists(path) for path in outputs)
assert request['lease_path']=='/home/holden/mckernel-work/scratch/native-running-external-modules.lease.json'
assert request['common_exclusion_path']=='/home/holden/mckernel-work/scratch/native-running-external-modules-operational-exclusion.json'
for path in (BASIS,BACKING):safe(path)
assert BASIS.is_dir() and BACKING.is_file()
backing=BACKING.stat();assert backing.st_uid==backing.st_gid==0 and backing.st_nlink==1 and backing.st_size==110*2**30
# Fresh exact namespace only; no ownership/exclusion records are acquired or modified.
workspace.mkdir(mode=0o700);os.chown(workspace,1000,1000)
candidate.mkdir(mode=0o700);os.chown(candidate,1000,1000)
assert node(workspace)['mode']==node(candidate)['mode']==0o700 and not list(candidate.iterdir())
request.update(request_path=str(request_path),candidate_root=str(candidate),owner_evidence_root=str(owner_evidence),
               candidate_identity=node(candidate),output_parent_identity=node(workspace),input_identity=node(N),
               basis_identity=node(BASIS),backing_identity=dict(node(BACKING),size=backing.st_size,nlink=backing.st_nlink))
assert not any(v is None for v in request.values())
approval_bound=write(approval_path,approval)
request_ref=write(request_path,request)
query_ref=write(query_inputs,dict(request=str(request_path),request_sha256=request_ref['sha256']))
base=load(O/'RELEASE.ROOT.BASE.PAYLOAD.NO-FRESH.json')
base['historical_prevalidation_token_clearance']=base.pop('current_token_clearance')
base['historical_prevalidation_token_postjoin']=base.pop('current_token_postjoin')
base.update(nonce=NONCE,request={k:request_ref[k] for k in ('path','sha256')},source_sha256=pinmap['source_sha256'],
            source_review={k:approval_bound[k] for k in ('path','sha256')},
            current_physical=PHYSICAL,current_live_postjoin=POSTJOIN,
            fetched_source_verified=None,fetched_source_proof=None,actual_query=None,actual_query_whole_join=None,
            execution_review=None,status=None,
            readonly_query_source=None,readonly_query_capture_source=None)
for field in ('memory_available','scratch_actual','scratch_required'):base['aggregate_review'][field]=None
base_ref=write(payload_path,base)
entry=load(O/'ROOT-ACTUAL-OWNER-ENTRY.FRESH3.json')
argv=entry['argv'];argv[argv.index(str(O/'library_sdk_owner.py'))]=str(N/'library_sdk_owner.py')
argv[argv.index('--request')+1]=str(request_path);argv[argv.index('--request-sha256')+1]=request_ref['sha256']
argv[argv.index('--release')+1]=str(N/'RELEASE.ROOT.FINAL.json')
argv[argv.index('--release-sha256')+1]='ROOT_FINAL_REVIEWED_RELEASE_SHA256'
entry.update(argv=argv,at=None,memory_available=None,query_age_seconds=None,release_sha256=None,
             status='PENDING_FETCH_FRESH_QUERY_AND_EXACT_EXECUTION_RELEASE',source_only=True)
assert entry['outer_CPU_rlimit'] is None and entry['outer_timeout'] is None
entry_ref=write(entry_path,entry)
assert not os.path.lexists(owner_evidence)
result=write(result_path,dict(scope=__doc__,status='PASS_ROOT_METADATA_ONLY_READY_FOR_QUERY_NOT_RUNTIME',request=request_ref,
                query_inputs=query_ref,base_payload=base_ref,pending_entry=entry_ref,
                source_approval=approval_bound,workspace=node(workspace),candidate=node(candidate),owner_evidence_absent=True,
                fetched_proof=None,fresh_resources=None,execution_review=None,actual_query=None,actual_targets=0))
print(json.dumps(result))
