"""Preserve durable RS-011 identities while adding the bounded image loader."""
import collections, copy, json, sys
from pathlib import Path
sys.path.insert(0, '/workspace/scripts')
import native_rust_unsafe_ffi_ledger as checker
repo = '/workspace'
ledger = json.loads(Path(repo, checker.LEDGER_PATH).read_text())
discovery = checker.discover(repo)
remaining = {site['id']: site for site in ledger['sites']}
original_ids = set(remaining)
allowed_changed = {'RS011-SMP-0055', 'RS011-IHK-0078'}
next_smp = max(int(sid.rsplit('-', 1)[1]) for sid in remaining if sid.startswith('RS011-SMP-')) + 1
def key(site):
    return (site['path'], site['kind'], site['expression_sha256'], json.dumps(site['macro_context'], sort_keys=True))
constraints = [
    'Pinned Linux 6.12 x86_64 ABI; IHK supplies an exact live slot/generation lease and retains the SMP provider module through each synchronous callback.',
    'Process context under the per-OS operation mutex. Load starts only in NotBooted, exposes Loading while the callback runs, and restores NotBooted after every backend result; it starts no CPUs.',
    'Compat top-level pointers are zero-extended exactly once by IHK. The filename is read through UserSlice up to the first NUL within 256 bytes; no userspace pointer survives the call.',
    'Invalidate the prior image before file read. Linux kernel_read_file_from_path enforces the 64 MiB whole-file limit before allocating, with NULL file_size and READING_KEXEC_IMAGE security hooks; one ImageFile owns the returned vmalloc buffer and drops it with kvfree.',
    'Acquire CPU then memory controller locks before placement and copying. A CPU must be assigned to this OS; all physical image bytes and startup space must fit its generation-owned RAM.',
    'Validate every bounded ELF64 program header, source range, destination range, segment overlap, entry and startup geometry before the first physical write. The immutable file borrow survives the entire preflight, copy and readback.',
    'verify() ties the canonical logical map to retained PageOwners. Split zero/copy/readback access at original compound-allocation boundaries; logical adjacency never creates one Rust allocation. Linux direct-map addresses use checked arithmetic.',
    'Zero the complete 8 MiB image window, copy validated file bytes, read back physical bytes, then publish LoadedImage. Invalidation, error or resource changes cannot authorize boot; native McKernel startup, user VMAs and IKC remain unimplemented.',
]
records, changed, added = [], [], []
for found in discovery['sites']:
    candidates = [site for site in remaining.values() if key(site) == key(found)]
    if not candidates:
        candidates = [site for site in remaining.values() if site['id'] in allowed_changed
                      and site['path'] == found['path'] and site['kind'] == found['kind']
                      and site['safety_comment']['text'] == found['safety_comment']['text']]
        if candidates:
            if len(candidates) != 1:
                raise SystemExit('Ambiguous changed boundary identity')
            changed.append(candidates[0]['id'])
    if candidates:
        record = copy.deepcopy(candidates[0])
        del remaining[record['id']]
        record.update(checker.mechanical_site(found))
    else:
        if found['kind'] != 'unsafe_block' or found['path'] not in {
            'host-kernel/native-rust/smp_loader.rs', 'host-kernel/native-rust/smp_memory.rs',
            'host-kernel/native-rust/smp_cpu.rs',
        }:
            raise SystemExit('Unexpected new boundary: ' + repr(found))
        record = checker.mechanical_site(found)
        record.update(id='RS011-SMP-%04d' % next_smp,
                      owner={'component': 'native Rust SMP bounded image loader', 'accountable_role': 'host-module maintainer'},
                      caller_obligations=[found['safety_comment']['text']],
                      context_constraints=list(constraints),
                      compiler_capture={'required': True, 'status': 'not_captured', 'evidence_sha256': None},
                      independent_review={'required': True, 'status': 'pending', 'reviewer': None, 'evidence_sha256': None})
        next_smp += 1
        added.append(record['id'])
    if record['id'] in allowed_changed:
        record['caller_obligations'] = [found['safety_comment']['text']]
        record['context_constraints'] = list(constraints)
    if record['id'] in original_ids and found['path'].endswith('/smp_memory.rs'):
        record['context_constraints'] = [line.replace(
            'Native boot and guest access remain unimplemented.',
            'The image loader writes and reads back exclusively assigned unbooted RAM while retaining the original PageOwners; native CPU startup and user VMA access remain unimplemented.')
            for line in record['context_constraints']]
    records.append(record)
if remaining or set(changed) != allowed_changed or len(added) != 9:
    raise SystemExit('Unexpected retirement or boundary changes: ' + repr((remaining, changed, added)))
ledger['sites'] = records
ledger['repository_locks'], ledger['target'] = checker.expected_locks(repo)
ledger['crate_roots'] = discovery['roots']
ledger['source_inputs'] = discovery['inputs']
ledger['source_closure_sha256'] = discovery['source_closure_sha256']
ledger['coverage'] = dict(source_input_count=len(discovery['inputs']), site_count=len(records),
    site_ids_sha256=checker.sha256_bytes(checker.canonical_bytes([site['id'] for site in records])),
    by_kind=dict(sorted(collections.Counter(site['kind'] for site in records).items())),
    by_crate={crate: sum(crate in site['crate_roots'] for site in records) for crate in checker.EXPECTED_CRATES},
    source_inventory_status='complete_for_locked_source_bytes')
ledger['ledger_sha256'] = checker.ledger_digest(ledger)
checker.validate_ledger(ledger, repo)
out = Path('/work/native-image-updated-ffi-ledger-20260907.json')
with out.open('x') as stream:
    stream.write(checker.pretty(ledger))
with out.with_suffix('.changes.json').open('x') as stream:
    stream.write(checker.pretty(dict(changed_existing_ids=changed, new_ids=added, preserved_ids=sorted(original_ids))))
print(checker.pretty(ledger['coverage']), flush=True)
