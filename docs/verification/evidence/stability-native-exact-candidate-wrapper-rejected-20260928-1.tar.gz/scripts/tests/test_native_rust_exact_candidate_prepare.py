"""Cheap admission tests; no clone, metadata relocation, owner, or Docker."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import native_rust_exact_candidate_prepare as prep


class Host(object):
    def __init__(self, free=32 << 30, memory=32 << 30, processes=None, size=1):
        self.free_value, self.memory, self.rows, self.size = free, memory, processes or [], size
    def free(self, unused): return self.free_value
    def mem(self): return self.memory
    def processes(self): return self.rows
    def du(self, unused): return self.size


class CandidatePrepareTests(unittest.TestCase):
    def request(self, root):
        root = Path(root); source = root/'source'; (source/'ihk').mkdir(parents=True); (root/'assets').mkdir()
        receipt = root/'image-receipt.json'; receipt.write_text('{}')
        result = {'source_root':str(source), 'assets_root':str(root/'assets'),
                  'host_measure_root':str(root), 'scratch_measure_root':str(root),
                  'source_commit':'a'*40, 'candidate_sha':'a'*40, 'ihk_commit':'b'*40,
                  'image':prep.IMAGE, 'image_receipt':str(receipt), 'image_receipt_sha256':prep.IMAGE_RECEIPT}
        for key, name in (('candidate_root','candidate'),('backup_root','backup'),('metadata_evidence_root','metadata'),
                          ('durable_log','log'),('manifest_path','manifest'),('build_request_path','request'),
                          ('owner_output_root','out'),('owner_evidence_root','evidence'),('lease_path','lease')):
            result[key] = str(root/name)
        return result

    def test_existing_dangling_symlink_alias_overlap_and_old_are_prelog_refusals(self):
        with tempfile.TemporaryDirectory() as temporary:
            for kind in ('existing','dangling','ancestor','alias','overlap','old'):
                root = Path(temporary)/kind; root.mkdir(); request = self.request(root)
                if kind == 'existing': Path(request['candidate_root']).mkdir()
                elif kind == 'dangling': Path(request['lease_path']).symlink_to(root/'missing')
                elif kind == 'ancestor':
                    (root/'link').symlink_to(root); request['candidate_root'] = str(root/'link'/'candidate')
                elif kind == 'alias': request['backup_root'] = request['candidate_root']
                elif kind == 'overlap': request['manifest_path'] = str(Path(request['candidate_root'])/'manifest')
                else: request['candidate_root'] = str(root/'80b8c492-new')
                with self.assertRaises(ValueError): prep.prepare(request, host=Host())
                self.assertFalse(Path(request['durable_log']).exists())

    def test_preflight_hash_failure_leaves_terminal_evidence_and_no_candidate(self):
        with tempfile.TemporaryDirectory() as directory:
            request = self.request(directory)
            with mock.patch.object(prep, 'sha256', return_value='not-pinned'):
                with self.assertRaises(RuntimeError): prep.prepare(request, host=Host())
            text = Path(request['durable_log']).read_text()
            self.assertIn('PREPARATION_RC', text)
            self.assertIn('pinned helper hash differs', text)
            self.assertFalse(Path(request['candidate_root']).exists())

    def test_self_is_never_a_process_match_and_real_heavy_is(self):
        self.assertEqual([], prep._processes(Host(processes=[{'pid':7,'comm':'python','cmdline':'native_rust_exact_candidate_prepare.py'}]), 7))
        self.assertEqual(1, len(prep._processes(Host(processes=[{'pid':8,'comm':'qemu-kvm','cmdline':'qemu-kvm'}]), 7)))

    def test_every_resource_floor_refuses(self):
        request = {'host_measure_root':'/', 'scratch_measure_root':'/'}
        for which, limit in (('shm',prep.MIN_SHM),('host',prep.MIN_HOST),('scratch',prep.MIN_SCRATCH),('memory',prep.MIN_MEM)):
            host = Host()
            if which == 'memory': host.memory = limit - 1
            else:
                # This adapter maps all filesystem probes to the same value;
                # each below-floor value is still a distinct admission vector.
                host.free_value = limit - 1
            with self.assertRaises(RuntimeError): prep._resource(request, host)

    def test_command_adapter_uses_argv_and_child_umask(self):
        seen = []
        class Adapter(object):
            def run(self, argv, cwd=None, env=None, umask=None):
                seen.append((argv, env, umask)); return 0, b'ok', b''
        with tempfile.TemporaryDirectory() as directory:
            log = Path(directory)/'log'; log.touch()
            prep._run(Adapter(), log, ['/bin/true','space value'], 'probe', umask=0o22)
        self.assertEqual(['/bin/true','space value'], seen[0][0])
        self.assertEqual(0o22, seen[0][2])
        self.assertEqual('/nonexistent', seen[0][1]['HOME'])
        self.assertEqual('file', seen[0][1]['GIT_ALLOW_PROTOCOL'])

    def test_root_and_bad_image_are_refused_before_log(self):
        with tempfile.TemporaryDirectory() as directory:
            request = self.request(directory); request['image'] = 'sha256:'+'0'*64
            with self.assertRaises(ValueError): prep.prepare(request, host=Host())
            self.assertFalse(Path(request['durable_log']).exists())
            request = self.request(Path(directory)/'two') if False else request

    def test_starttime_is_a_string(self):
        self.assertTrue(prep._starttime(os.getpid()))


if __name__ == '__main__':
    unittest.main()
