#!/usr/bin/env python3
"""Fail-closed, validate-only preparation of an exact-build candidate.

This program intentionally cannot acquire a build lease or invoke Docker.  It
only prepares a detached candidate, proves its provenance, and calls the
candidate owner's ``validate`` method.  Command and host adapters make the
admission boundary cheaply testable.
"""
from __future__ import print_function
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

# Candidate imports are part of provenance, not a permission to leave an
# untracked __pycache__ in the checkout.
sys.dont_write_bytecode = True

PLACEMENT = Path('/home/holden/mckernel-work/scratch/candidate-placement-observer-80b8c492-1.py')
CLOSURE = Path('/home/holden/mckernel-work/scratch/source-git-closure-observer-80b8c492-1.py')
HASHES = {'placement_observer':'4fe5b7717a7ddc8694edaecc63d07f97a56460f8e692d3ebe2d682024dadbe8a',
          'closure_observer':'079482060e5d0b461d15a5d1ffeb7f5d96719d70b877125665df8df7c4bcd7f1',
          'metadata_helper':'b68a8b5d18a6642ef0043b791984e7a4ea2503a61b8d9153a781827a2277a10a',
          'manifest_helper':'28112e13a9932796080d8183e66e493b1bf0655631413b42775af865798c1d3f',
          'offline_helper':'1e522a60a265cbd54f50f8856f2c1a8b2f140bd11e655d875f6db431f08a962b',
          'owner':'0a4386a9965a99e3b47a469f9f97a2d8180ceab91cdb53aeccd98d1fee04b72d'}
IMAGE = 'sha256:0f8ad280e47d76b23554de4aec411752e1f779f9b2fc7fece6b0b3375dc9775d'
IMAGE_RECEIPT = '18225919a44e2c07e87a66711c8d1c9483d10e15da91fa5d7fcb7339ff888172'
MIN_SHM, MIN_HOST, MIN_SCRATCH, MIN_MEM, LIMIT = 4 << 30, 16 << 30, 12 << 30, 16 << 30, 24 << 30
HEX40 = re.compile(r'^[0-9a-f]{40}$')
OLD_NAMES = ('80b8c492', 'candidate-80b', 'attempt-1', 'attempt-2')


def sha256(path):
    h = hashlib.sha256()
    with open(str(path), 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe_env():
    """A complete, non-inherited execution environment (no network prompts)."""
    return {'PATH':'/usr/bin:/bin', 'LANG':'C', 'LC_ALL':'C', 'TZ':'UTC',
            'HOME':'/nonexistent', 'PYTHONDONTWRITEBYTECODE':'1',
            'PYTHONNOUSERSITE':'1', 'PYTHONSAFEPATH':'1',
            'GIT_CONFIG_NOSYSTEM':'1', 'GIT_CONFIG_GLOBAL':'/dev/null',
            'GIT_NO_REPLACE_OBJECTS':'1', 'GIT_TERMINAL_PROMPT':'0',
            'GIT_ALLOW_PROTOCOL':'file'}


def _starttime(pid):
    try:
        return Path('/proc/%d/stat' % pid).read_text().split()[21]
    except (OSError, IndexError):
        return None


class Command(object):
    def run(self, argv, cwd=None, env=None, umask=None):
        if not isinstance(argv, (list, tuple)) or any(not isinstance(item, str) for item in argv):
            raise ValueError('argv must be a string vector')
        def child():
            if umask is not None:
                os.umask(umask)
        result = subprocess.run(list(argv), cwd=cwd, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, check=False,
                                preexec_fn=child if umask is not None else None)
        return result.returncode, result.stdout, result.stderr


class Host(object):
    def free(self, path):
        info = os.statvfs(str(path)); return info.f_bavail * info.f_frsize
    def mem(self):
        for line in Path('/proc/meminfo').read_text().splitlines():
            if line.startswith('MemAvailable:'):
                return int(line.split()[1]) * 1024
        raise RuntimeError('MemAvailable unavailable')
    def du(self, path):
        total = 0
        for root, unused, files in os.walk(str(path), followlinks=False):
            for name in files:
                item = Path(root) / name
                if not item.is_symlink(): total += item.lstat().st_blocks * 512
        return total
    def processes(self):
        rows = []
        for entry in Path('/proc').glob('[0-9]*'):
            try:
                rows.append({'pid':int(entry.name), 'starttime':_starttime(int(entry.name)),
                             'comm':(entry/'comm').read_text().strip(),
                             'cmdline':(entry/'cmdline').read_bytes().replace(b'\0',b' ').decode('utf-8','replace')})
            except (OSError, ValueError): pass
        return rows


def _ancestor_safe(path, label):
    path = Path(path)
    if not path.is_absolute(): raise ValueError('%s is not absolute' % label)
    here = Path(path.anchor)
    for part in path.parts[1:]:
        here /= part
        if os.path.lexists(str(here)) and here.is_symlink():
            raise ValueError('%s has a symlink ancestor: %s' % (label, here))


def _fresh(path, label):
    path = Path(path); _ancestor_safe(path, label)
    if os.path.lexists(str(path)): raise ValueError('%s exists/dangles: %s' % (label, path))
    if any(name in str(path) for name in OLD_NAMES): raise ValueError('%s is an old name' % label)
    return path


def _existing(path, label, directory=False):
    path = Path(path); _ancestor_safe(path, label)
    if path.is_symlink() or not path.exists() or directory and not path.is_dir():
        raise ValueError('unsafe required %s: %s' % (label, path))
    return path.resolve(strict=True)


def _disjoint(rows):
    rows = [(name, Path(path).resolve(strict=False)) for name, path in rows]
    for i, (name, path) in enumerate(rows):
        for other_name, other in rows[i + 1:]:
            if path == other or path in other.parents or other in path.parents:
                raise ValueError('path alias/overlap: %s %s' % (name, other_name))


def _append(log, row):
    with open(str(log), 'a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')
        stream.flush(); os.fsync(stream.fileno())


def _run(adapter, log, argv, label, cwd=None, umask=None):
    _append(log, {'event':'step-start','label':label,'argv':list(argv),'cwd':None if cwd is None else str(cwd),
                  'pid':os.getpid(),'starttime':_starttime(os.getpid())})
    rc, stdout, stderr = adapter.run(list(argv), cwd=None if cwd is None else str(cwd), env=safe_env(), umask=umask)
    _append(log, {'event':'step-end','label':label,'rc':rc,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
                  'stderr_sha256':hashlib.sha256(stderr).hexdigest()})
    if rc: raise RuntimeError('%s rc=%d: %s' % (label, rc, stderr.decode('utf-8','replace').strip()))
    return stdout


def _git(adapter, log, root, *args):
    return _run(adapter, log, ['/usr/bin/git','-c','safe.directory='+str(root),'-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','-C',str(root)] + list(args), 'git:'+args[0]).decode('ascii','strict').strip()


def _resource(req, host):
    values = {'shm_free':host.free('/dev/shm'), 'host_free':host.free(req['host_measure_root']),
              'scratch_free':host.free(req['scratch_measure_root']), 'memory_available':host.mem()}
    if values['shm_free'] < MIN_SHM or values['host_free'] < MIN_HOST or values['scratch_free'] < MIN_SCRATCH or values['memory_available'] < MIN_MEM:
        raise RuntimeError('resource floor admission failed: '+json.dumps(values,sort_keys=True))
    return values


def _processes(host, self_pid):
    hits, heavy = [], set(('docker','dockerd','qemu-system-x86_64','qemu-kvm','mcexec'))
    for row in host.processes():
        if row.get('pid') == self_pid: continue
        argv = [word for word in row.get('cmdline','').split(' ') if word]
        command = os.path.basename(argv[0]) if argv else row.get('comm','')
        if command in heavy or row.get('comm') in heavy: hits.append(row)
    return hits


def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None: raise RuntimeError('cannot import candidate helper: '+str(path))
    # Candidate helpers intentionally import their sibling modules by name.
    # Never fall back to the launch checkout for that import.
    parent = str(Path(path).parent)
    sys.path.insert(0, parent)
    # ``import native_rust_exact_build_offline`` in a helper must resolve to
    # this candidate capsule even if a launch-tree copy was imported earlier.
    sibling = Path(path).stem
    sys.modules.pop(sibling, None)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def _closure(out):
    words = out.decode('ascii','strict').strip().split()
    if len(words) != 4 or words[0] != 'SOURCE_CLOSURE' or not re.fullmatch('[0-9a-f]{64}', words[3]):
        raise RuntimeError('bad closure observer output')
    return words[3]


def _admit(req):
    required = ('candidate_root','backup_root','metadata_evidence_root','durable_log','manifest_path','build_request_path','owner_output_root','owner_evidence_root','lease_path','source_root','assets_root','host_measure_root','scratch_measure_root','source_commit','ihk_commit','candidate_sha','image','image_receipt','image_receipt_sha256')
    for key in required:
        if key not in req: raise ValueError('missing request field: '+key)
    if os.geteuid() == 0: raise ValueError('refusing root')
    if any(not HEX40.fullmatch(req[key]) for key in ('source_commit','ihk_commit','candidate_sha')): raise ValueError('bad commit')
    if req['source_commit'] != req['candidate_sha'] or req['image'] != IMAGE or req['image_receipt_sha256'] != IMAGE_RECEIPT: raise ValueError('candidate/image receipt binding differs')
    fresh_keys = ('candidate_root','backup_root','metadata_evidence_root','durable_log','manifest_path','build_request_path','owner_output_root','owner_evidence_root')
    fresh = {key:_fresh(req[key],key) for key in fresh_keys}; _fresh(req['lease_path'],'lease_path')
    source, assets = _existing(req['source_root'],'source_root',True), _existing(req['assets_root'],'assets_root',True)
    _existing(req['image_receipt'],'image_receipt')
    ihk = _existing(source/'ihk','source_ihk',True)
    # ``source_ihk`` is intentionally a child of the source superproject;
    # it is checked for safety above but is not an independent allocation root.
    _disjoint(list(fresh.items()) + [('source_root',source),('assets_root',assets)])
    return source, assets, fresh


def prepare(request, owner_cls=None, runner=None, host=None):
    """Complete preparation; exceptions retain all partial paths and durable log."""
    req = dict(request); source, assets, fresh = _admit(req); log = fresh['durable_log']
    adapter, host = runner or Command(), host or Host()
    with open(str(log), 'x', encoding='utf-8') as stream: stream.flush(); os.fsync(stream.fileno())
    receipt = {'status':'FAIL','candidate_sha':req['candidate_sha'],'ihk_sha':req['ihk_commit'],
               'scope':'preparation validate-only; no lease/docker/build','pid':os.getpid(),'starttime':_starttime(os.getpid()),'started_at':time.time()}
    _append(log, {'event':'start','env':safe_env(),'request':{key:req[key] for key in sorted(req)}})
    try:
        paths = {'placement_observer':PLACEMENT,'closure_observer':CLOSURE,
                 'metadata_helper':Path('scripts/native_rust_exact_build_candidate_metadata.py').resolve(),
                 'manifest_helper':Path('scripts/native_rust_exact_build_input_manifest.py').resolve(),
                 'offline_helper':Path('scripts/native_rust_exact_build_offline.py').resolve(),
                 'owner':Path('scripts/native_rust_exact_build_container_owner.py').resolve()}
        for name, path in paths.items():
            _existing(path,name)
            if sha256(path) != HASHES[name]: raise RuntimeError('pinned helper hash differs: '+name)
        if sha256(req['image_receipt']) != IMAGE_RECEIPT:
            raise RuntimeError('pinned image receipt hash differs')
        hits = _processes(host, os.getpid())
        _append(log, {'event':'observation-before','processes':hits,
                      'lease_exists':os.path.lexists(req['lease_path']),
                      'lease_path':req['lease_path'],
                      'containers':'not queried: validate-only never invokes Docker'})
        if hits: raise RuntimeError('active heavy process: '+json.dumps(hits,sort_keys=True))
        if os.path.lexists(req['lease_path']): raise RuntimeError('lease appeared during admission')
        receipt['resources_before'] = _resource(req,host)
        _run(adapter,log,[sys.executable,'-E','-s',str(PLACEMENT),'--self-test'],'placement-self-test')
        _run(adapter,log,[sys.executable,'-E','-s',str(CLOSURE),'--self-test'],'closure-self-test')
        if _git(adapter,log,source,'rev-parse','HEAD') != req['source_commit'] or _git(adapter,log,source/'ihk','rev-parse','HEAD') != req['ihk_commit']: raise RuntimeError('source identity differs')
        if _git(adapter,log,source,'status','--porcelain=1','--untracked-files=all') or _git(adapter,log,source/'ihk','status','--porcelain=1','--untracked-files=all'): raise RuntimeError('source checkout dirty')
        main_digest = _closure(_run(adapter,log,[sys.executable,'-E','-s',str(CLOSURE),'--root',str(source/'.git'),'--label','source-main'],'closure-main-before'))
        ihk_digest = _closure(_run(adapter,log,[sys.executable,'-E','-s',str(CLOSURE),'--root',str(source/'ihk'/'.git'),'--label','source-ihk'],'closure-ihk-before'))
        candidate = fresh['candidate_root']
        _run(adapter,log,['/usr/bin/git','-c','protocol.file.allow=always','clone','--no-local','--no-checkout','--no-recurse-submodules',str(source),str(candidate)],'clone-main-detached',umask=0o22)
        _git(adapter,log,candidate,'checkout','--detach',req['candidate_sha'])
        _run(adapter,log,['/usr/bin/git','-c','protocol.file.allow=always','clone','--no-local','--no-checkout',str(source/'ihk'),str(candidate/'ihk')],'clone-ihk-detached',umask=0o22)
        _git(adapter,log,candidate/'ihk','checkout','--detach',req['ihk_commit'])
        if _git(adapter,log,candidate,'rev-parse','HEAD') != req['candidate_sha'] or _git(adapter,log,candidate/'ihk','rev-parse','HEAD') != req['ihk_commit']: raise RuntimeError('detached clone identity differs')
        _run(adapter,log,[sys.executable,'-E','-s',str(PLACEMENT),'--candidate',str(candidate),'--source',str(source),'--main-sha',req['candidate_sha'],'--ihk-sha',req['ihk_commit']],'placement-observer')
        _run(adapter,log,[sys.executable,'-E','-s',str(paths['metadata_helper']),'--main',str(candidate),'--ihk',str(candidate/'ihk'),'--source-main',str(source/'.git'),'--source-ihk',str(source/'ihk'/'.git'),'--backup',str(fresh['backup_root']),'--evidence',str(fresh['metadata_evidence_root']),'--main-sha',req['candidate_sha'],'--ihk-sha',req['ihk_commit']],'metadata-relocation',umask=0o22)
        metadata_receipt = fresh['metadata_evidence_root']/'receipt.json'
        if not metadata_receipt.is_file() or json.loads(metadata_receipt.read_text()).get('status') != 'PASS': raise RuntimeError('metadata receipt not PASS')
        if any(item.name.startswith('exact-metadata-') for item in candidate.parent.iterdir()): raise RuntimeError('metadata staging remains')
        _run(adapter,log,[sys.executable,'-E','-s',str(CLOSURE),'--root',str(source/'.git'),'--label','source-main','--expected',main_digest],'closure-main-after')
        _run(adapter,log,[sys.executable,'-E','-s',str(CLOSURE),'--root',str(source/'ihk'/'.git'),'--label','source-ihk','--expected',ihk_digest],'closure-ihk-after')
        for name, key in (('native_rust_exact_build_candidate_metadata.py','metadata_helper'),('native_rust_exact_build_input_manifest.py','manifest_helper'),('native_rust_exact_build_offline.py','offline_helper'),('native_rust_exact_build_container_owner.py','owner')):
            if sha256(candidate/'scripts'/name) != HASHES[key]: raise RuntimeError('candidate capsule hash differs: '+name)
        _run(adapter,log,[sys.executable,'-E','-s',str(candidate/'scripts/x86_64_shared_abi.py'),'--repo-root',str(candidate),'--check'],'shared-abi',cwd=candidate)
        manifest_mod = _module(candidate/'scripts/native_rust_exact_build_input_manifest.py','candidate_manifest')
        inherited_umask = os.umask(0o22)
        try: manifest_mod.generate(candidate,assets,fresh['manifest_path'],req['candidate_sha'])
        finally: os.umask(inherited_umask)
        manifest = json.loads(fresh['manifest_path'].read_text())
        offline_mod = _module(candidate/'scripts/native_rust_exact_build_offline.py','candidate_offline')
        offline_mod.verify_inputs(candidate,req['candidate_sha'],assets,manifest,offline_mod.Runner())
        fresh['owner_output_root'].mkdir(mode=0o755); fresh['owner_evidence_root'].mkdir(mode=0o755)
        if any(fresh['owner_output_root'].iterdir()) or any(fresh['owner_evidence_root'].iterdir()): raise RuntimeError('owner roots not empty')
        build = {'candidate_root':str(candidate),'source_root':str(candidate),'candidate_sha':req['candidate_sha'],'ihk_sha':req['ihk_commit'],'image_id':IMAGE,'image_receipt':req['image_receipt'],'image_receipt_sha256':IMAGE_RECEIPT,'input_manifest':str(fresh['manifest_path']),'input_manifest_sha256':sha256(fresh['manifest_path']),'driver_path':str(candidate/'scripts/native_rust_exact_build_offline.py'),'driver_path_sha256':HASHES['offline_helper'],'driver_sha256':HASHES['offline_helper'],'manifest_helper_sha256':HASHES['manifest_helper'],'metadata_helper_sha256':HASHES['metadata_helper'],'owner_sha256':HASHES['owner'],'timeout':int(req.get('timeout_seconds',7200)),'host_measure_root':req['host_measure_root'],'scratch_measure_root':req['scratch_measure_root'],'assets_root':str(assets),'host_floor':MIN_HOST,'scratch_floor':MIN_SCRATCH,'memory_allocation_roots':[str(candidate),str(fresh['backup_root'])],'output_root':str(fresh['owner_output_root']),'evidence_root':str(fresh['owner_evidence_root']),'lease_path':req['lease_path']}
        with open(str(fresh['build_request_path']),'x',encoding='utf-8') as stream: json.dump(build,stream,sort_keys=True); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        if host.du(candidate)+host.du(fresh['backup_root'])+(12<<30) > LIMIT: raise RuntimeError('candidate/backup allocation exceeds aggregate')
        after_hits = _processes(host,os.getpid())
        _append(log, {'event':'observation-before-validate','processes':after_hits,
                      'lease_exists':os.path.lexists(req['lease_path']),
                      'containers':'not queried: validate-only never invokes Docker'})
        if after_hits or os.path.lexists(req['lease_path']): raise RuntimeError('process/lease changed before validate')
        owner_mod = _module(candidate/'scripts/native_rust_exact_build_container_owner.py','candidate_owner')
        (owner_cls or owner_mod.BuildOwner)(build).validate()
        final_hits = _processes(host,os.getpid())
        _append(log, {'event':'observation-after-validate','processes':final_hits,
                      'lease_exists':os.path.lexists(req['lease_path']),
                      'containers':'not queried: validate-only never invokes Docker'})
        if final_hits or any(fresh['owner_output_root'].iterdir()) or any(fresh['owner_evidence_root'].iterdir()) or os.path.lexists(req['lease_path']): raise RuntimeError('validate-only boundary crossed')
        receipt.update({'status':'PASS_PREPARATION_VALIDATE_ONLY','resources_after':_resource(req,host),'measurement':'PASS','manifest_sha256':sha256(fresh['manifest_path'])})
    except BaseException as error:
        receipt['error'] = str(error); _append(log,{'event':'error','error':str(error)}); raise
    finally:
        receipt['finished_at'] = time.time(); _append(log,{'event':'terminal','PREPARATION_RC':0 if receipt['status'].startswith('PASS') else 1,'receipt':receipt})
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(); parser.add_argument('request'); args = parser.parse_args(argv)
    try: result = prepare(json.loads(Path(args.request).read_text()))
    except BaseException as error: print(json.dumps({'status':'FAIL','error':str(error)},sort_keys=True)); return 1
    print(json.dumps(result,sort_keys=True)); return 0


if __name__ == '__main__': sys.exit(main())
