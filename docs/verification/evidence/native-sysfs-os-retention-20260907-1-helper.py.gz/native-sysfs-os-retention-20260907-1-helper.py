from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, base = Path('/workspace'), Path('/work')
out = base / ('native-sysfs-os-retained-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[], production_gate_credit=False,
    declared_stage=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    applications_tested=False)

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): checksum.update(chunk)
    return checksum.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def checked(row):
    assert identity(Path(row['path'])) == row, row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target)
    row.update(path='docs/verification/evidence/' + name, source=str(source),
        unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

def bind(current, compiled):
    assert current.read_bytes() == compiled.read_bytes(), (str(current), str(compiled))
    row = identity(current); row['path'] = str(current.relative_to(repo))
    if row not in record['compiler_inputs']: record['compiler_inputs'].append(row)

try:
    captures = [('module-1', 'native-sysfs-os-module-20260907-1', 'FAIL'),
                ('module-2', 'native-sysfs-os-module-20260907-2', 'PASS'),
                ('prepare', 'native-sysfs-os-guest-20260907-prepare-1', 'PASS'),
                ('start-x86_64', 'native-sysfs-os-guest-20260907-start-x86_64-1', 'PASS'),
                ('start-i386', 'native-sysfs-os-guest-20260907-start-i386-1', 'PASS')]
    guests = {}
    for category, name, expected in captures:
        source = base / name
        captured = json.loads((source / 'record.json').read_text())
        assert captured['status'] == expected, (name, captured['status'])
        for row in captured.get('inputs', []) + captured.get('outputs', []) + captured.get('fixture_inputs', []): checked(row)
        for capture in captured.get('captures', []):
            for row in capture['artifacts']: checked(row)
        archive = out / (name + '.tar.gz')
        with tarfile.open(archive, 'w:gz') as tar:
            tar.add(source, arcname=name, filter=lambda item: item if item.isfile() or item.isdir() else None)
        assert archive.stat().st_size < 95 << 20, name
        row = identity(archive); row.update(path='docs/verification/evidence/' + archive.name, source=str(source))
        record['artifacts'].append(row)
        retain_gzip(source / 'record.json', name + '-record.json.gz')
        if (source / 'serial.log').exists():
            retain_gzip(source / 'serial.log', name + '-serial.log.gz')
            guests[category] = captured
            serial = (source / 'serial.log').read_text()
            for bad in ['Call Trace:', 'BUG:', 'Oops:', 'WARNING:', 'Kernel panic', ' FAIL line=', 'rcu_preempt detected stalls']:
                assert bad not in serial, (name, bad)
        record['captures'].append(dict(directory=name, status=expected,
            source_parent=captured['source_parent'], started_utc=captured['started_utc'],
            finished_utc=captured['finished_utc'], qemu_exit_code=captured.get('qemu_exit_code')))
        print('Retained', name, expected, flush=True)
    final = base / 'native-sysfs-os-module-20260907-2'
    compiled_record = json.loads((final / 'record.json').read_text())
    for row in compiled_record['overlay']:
        relative = row['path'].split('/drivers/misc/mckernel/', 1)[1]
        saved = final / 'staged-source' / relative
        assert digest(saved) == row['sha256'] and saved.stat().st_size == row['size'], relative
    for saved in sorted((final / 'staged-source').rglob('*')):
        if saved.is_file() and saved.suffix in ('.rs', '.S'):
            current = repo / 'host-kernel/native-rust' / saved.relative_to(final / 'staged-source')
            bind(current, saved)
    for row in compiled_record['fixture_inputs']:
        bind(repo / 'scripts/tests/fixtures' / Path(row['path']).name, Path(row['path']))
    for category, name, _ in captures[2:]:
        for saved in sorted((base / name / 'probe-source').iterdir()):
            bind(repo / 'scripts/tests/fixtures' / saved.name, saved)
    record['device_layout'] = compiled_record['device_layout']
    assert len(record['device_layout']) == 3
    assert guests['prepare']['sysfs_namespace_checks'] == 404
    assert len(guests['prepare']['captures']) == 4
    for mode in ('start-x86_64', 'start-i386'):
        assert guests[mode]['sysfs_namespace_checks'] == 2
        assert guests[mode]['device_borrow_checks'] == 30 and guests[mode]['device_borrow_callbacks'] == 10
        capture = guests[mode]['captures'][0]
        assert capture['status'] == 2
        assert capture['linux_vdso']['service_completed']
        assert capture['linux_vdso']['next_request']['message'] == 0x40
        assert capture['linux_vdso']['next_request']['busy'] == 1
    for name in ['build-native-sysfs-os.py', 'run-native-sysfs-os-guest.py', 'retain-native-sysfs-os.py']:
        retain_gzip(base / name, 'native-sysfs-os-20260907-' + name + '.gz')
    for name in ['native-sysfs-objects-checkpoint-20260907.json', 'native-vdso-service-checkpoint-20260907.json']:
        row = identity(repo / 'docs/verification' / name)
        row['path'] = str(Path(row['path']).relative_to(repo)); record['references'].append(row)
    for row in record['artifacts']:
        checksum = hashlib.sha256(); size = 0
        with gzip.open(out / Path(row['path']).name, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                checksum.update(chunk); size += len(chunk)
        if 'unpacked_size' in row:
            assert size == row['unpacked_size'] and checksum.hexdigest() == row['unpacked_sha256'], row
    subprocess.run(['git', '-C', str(repo), 'diff', '--check'], check=True)
    record.update(status='PASS', sysfs_namespace_checks=408, device_borrow_checks=60,
        device_borrow_callbacks=20, independent_preparation_captures=4,
        passed=[
            'All three native modules and the OS-device borrowing fixture build with exact boot/device layout witnesses and module no-SIMD checks',
            'The actual native SMP prototype consumes the production sysfs object owner and attaches its sys child to the real generation-owned mcos device',
            'Both user ABIs across two preparation module lifetimes pass 404 namespace checks, repeated replacement/retirement, 32 original allocation failures, minor reuse and full unstarted resource restoration',
            'Both real McKernel startup interfaces retain the OS sysfs root after incomplete BOOT and rejected destruction, with four additional namespace checks',
            'Four fixture lifetimes on actual started devices pass 60 callback ABI checks, including stale generations, invalid slots/versions, absent callbacks/OS instances, exact device name and callback errno shaping',
            'Both actual starts preserve native vDSO completion and independently captured architectural status 2, with SYSFS_REQ_SETUP still pending and busy set',
            'All captured hashes, exact current compiler inputs and complete gzip streams verify; the initial helper modpost failure remains retained'],
        limitations=[
            'The OS-bound root is empty and has no setup_complete marker. Native tree/path/handle behavior, complete topology/setup files, owned shared buffers and actual SYSFS_REQ_SETUP completion remain required',
            'The borrowed parent callback relies on kernel callers to keep code/context live, avoid reentering OS operations and retire children before backend release and module unload; no guest/user pointer is accepted as a Linux object',
            'The callback fixture rejects mismatched generations on a live generation-1 device. Full preparation separately exercises minor reuse; the borrowing callback itself has not been raced against destruction in this fixture',
            'The original 32 boot allocation-failure cases do not inject every new sysfs allocation failure point',
            'Continuing native host dispatch, full ready status, application launcher/tests, native shutdown and complete McKernel/linked-support Rust or assembly ownership remain open',
            'Declared staging/lifecycle/unsafe-FFI/license bindings, a current integrated full suite and independent production acceptance remain required. No production gate or full boot claim'])
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'native-sysfs-os-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], 'retained', len(record['artifacts']), 'native OS sysfs artifacts', flush=True)
