"""Bind native file-access masks to the exact pinned Linux C definitions."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-pager-file-modes-20260908-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],production_gate_credit=False)
def identity(p):
    b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,args):
    print('RUN',label,flush=True)
    with (out/(label+'.log')).open('wb') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=r.returncode))
    assert r.returncode==0,(label,(out/(label+'.log')).read_text())
try:
    shutil.copyfile(__file__,out/'helper.py')
    linux=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/fs.h')
    rust=repo/'host-kernel/native-rust/smp_file_pager.rs'
    shutil.copyfile(linux,out/'linux-fs.h.reference');shutil.copyfile(rust,out/'smp_file_pager.rs.reference')
    record['inputs']=[identity(linux),identity(rust)]
    names=['FMODE_READ','FMODE_WRITE','FMODE_PREAD','FMODE_PWRITE']
    c='#include <stdio.h>\ntypedef unsigned int fmode_t;\n#define __force\n'
    definitions=[]
    for name in names:
        match=re.search(r'^#define\s+'+name+r'\s+[^\n]+',linux.read_text(),re.M);assert match,name
        c+=match[0]+'\n'
        match=re.search(r'^const '+name+r': u32 = [^;]+;',rust.read_text(),re.M);assert match,name
        definitions.append(match[0])
    c+='int main(void) { printf("%u %u %u %u\\n", '+', '.join(names)+'); return 0; }\n'
    (out/'linux-reference.c').write_text(c)
    run('c-build',['cc','-O2','-Wall','-Wextra','-Werror',str(out/'linux-reference.c'),'-o',str(out/'linux-reference')])
    run('c-reference',[str(out/'linux-reference')])
    expected=list(map(int,(out/'c-reference.log').read_text().split()));assert len(expected)==4
    rust='\n'.join(definitions)+'\n#[test]\nfn exact_linux_open_modes() { assert_eq!(['+', '.join(names)+'], '+repr(expected)+'); }\n'
    (out/'file-mode-test.rs').write_text(rust)
    run('rust-build',['rustc','--edition','2021','-D','warnings','--test',str(out/'file-mode-test.rs'),'-o',str(out/'file-mode-test')])
    run('rust-test',[str(out/'file-mode-test')])
    record.update(status='PASS',masks=dict(zip(names,expected)))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json']
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
