#include <stdio.h>
typedef unsigned int fmode_t;
#define __force
#define FMODE_READ		((__force fmode_t)(1 << 0))
#define FMODE_WRITE		((__force fmode_t)(1 << 1))
#define FMODE_PREAD		((__force fmode_t)(1 << 3))
#define FMODE_PWRITE		((__force fmode_t)(1 << 4))
int main(void) { printf("%u %u %u %u\n", FMODE_READ, FMODE_WRITE, FMODE_PREAD, FMODE_PWRITE); return 0; }
