const FMODE_READ: u32 = 1 << 0;
const FMODE_WRITE: u32 = 1 << 1;
const FMODE_PREAD: u32 = 1 << 3;
const FMODE_PWRITE: u32 = 1 << 4;
#[test]
fn exact_linux_open_modes() { assert_eq!([FMODE_READ, FMODE_WRITE, FMODE_PREAD, FMODE_PWRITE], [1, 2, 8, 16]); }
