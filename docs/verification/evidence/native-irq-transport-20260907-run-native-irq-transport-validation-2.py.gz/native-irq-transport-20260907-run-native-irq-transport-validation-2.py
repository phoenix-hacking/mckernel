from datetime import datetime, timezone
from pathlib import Path
import json, os, subprocess
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
out=Path('/work/native-irq-transport-validation-20260907-2')
out.mkdir()
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),results=[])
commands=[['python3','-B','/work/build-native-irq-transport-module.py','remote','2'],
          ['python3','-B','/work/run-native-irq-transport-guest.py','remote','2','1','default'],
          ['python3','-B','/work/build-native-irq-transport-module.py','default','1'],
          ['python3','-B','/work/run-native-irq-transport-guest.py','default','1','1','default']]
for index,command in enumerate(commands):
    print('Starting transport step',index,command,flush=True)
    with (out/('step-'+str(index)+'.log')).open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    record['results'].append(dict(command=command,exit_code=result.returncode))
    record['exit_code']=result.returncode
    record['updated_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print('Finished transport step',index,'exit',result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
