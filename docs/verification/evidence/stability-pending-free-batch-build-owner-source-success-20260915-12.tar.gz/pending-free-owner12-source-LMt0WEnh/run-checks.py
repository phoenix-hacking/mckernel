import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

repo = Path('/home/holden/mckernel')
out = Path(__file__).parent
sources = [
    'docs/verification/evidence/stability-pending-free-batch-build-owner-20260915.py',
    'scripts/tests/test_stability_pending_free_batch_build_owner.py',
    'kernel/rust/tests/pending_free_batch_actual_harness.py',
    'kernel/rust/tests/pending_free_batch_vectors.rs',
    'kernel/rust/tests/pending_free_batch_vectors.c',
    'kernel/rust/tests/run_equivalence.sh',
    'kernel/rust/mem_helpers.rs',
    'kernel/rust/abi.rs',
]
env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'PYTHONDONTWRITEBYTECODE': '1'}
commands = [('python3', ['/home/holden/anaconda3/bin/python3', '-B', 'scripts/tests/test_stability_pending_free_batch_build_owner.py']),
            ('python38', ['/usr/bin/python3.8', '-B', 'scripts/tests/test_stability_pending_free_batch_build_owner.py']),
            ('diff-check', ['git', 'diff', '--check'])]
def save(name, data):
    with (out / name).open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')

frozen = out / 'source'
frozen.mkdir()
identities = {}
for relative in sources:
    dest = frozen / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / relative, dest)
    identities[relative] = hashlib.sha256(dest.read_bytes()).hexdigest()
save('pre-run.json', {'sources': identities, 'commands': commands, 'cwd': str(repo), 'environment': env, 'timeout_seconds': 120, 'timestamp_ns': time.time_ns()})
for label, argv in commands:
    record = {'argv': argv, 'cwd': str(repo), 'environment': env, 'started_ns': time.time_ns(), 'timeout_seconds': 120}
    with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
        try:
            result = subprocess.run(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=120)
            record['returncode'] = result.returncode
        except Exception as error:
            record['error'] = repr(error)
            record['returncode'] = None
    record['finished_ns'] = time.time_ns()
    for stream in ('stdout', 'stderr'):
        record[stream + '_sha256'] = hashlib.sha256((out / (label + '.' + stream)).read_bytes()).hexdigest()
    save(label + '.result.json', record)
    print(label, record['returncode'], flush=True)
    if record['returncode'] != 0:
        save('first-failure.json', record)
        raise SystemExit(1)
save('post-run.json', {'sources': {relative: hashlib.sha256((repo / relative).read_bytes()).hexdigest() for relative in sources}, 'status': 'PASS_SOURCE_UNIT_TESTS_ONLY'})
