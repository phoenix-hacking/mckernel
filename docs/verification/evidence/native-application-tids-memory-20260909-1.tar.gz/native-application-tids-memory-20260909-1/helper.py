"""Compile actual native zeroing, ledger, admission and mapping bodies."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-tids-memory-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],extracted_bodies=[],production_gate_credit=False,actual_guest_pass=False,scope='Actual TID payload claim/copy/release, all seven conflicting claim classes and blocked final publication, plus complete prior native zeroing adapter with actual shared protocol, ledger/mapping/admission bodies and resource/image policies. Linux allocation/mutex/sleep providers substituted with guarded host arenas; constructors/kthread integration require the actual module and guest.')
def identity(path):
    data=path.read_bytes();return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def run(label,args):
    print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])
def body(path,pattern,name):
    data=path.read_text();match=re.search(pattern,data,re.M);assert match,name
    start=match.start();end=data.index('{',start)+1;depth=1
    while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
    value=data[start:end];record['extracted_bodies'].append(dict(source=str(path),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(value.encode()).hexdigest()))
    return value+'\n'
try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['host-kernel/native-rust/'+name for name in ['sysfs_zeroing.rs','sysfs_memory.rs','smp_service.rs','smp_memory.rs','ihk_smp_x86_64.rs','zero_pages.rs','smp_resource.rs','smp_image.rs','ihk_mapping.rs','application_rpc.rs','application_syscall.rs','application_pager.rs']]
    names+=['scripts/tests/fixtures/native-application-tids-memory.rs']
    original=out/'original-inputs';source=out/'source'
    for name in names:
        for prefix in [original,source]:
            target=prefix/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target)
    record['inputs']=[identity(original/name) for name in names]
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    formatted=['host-kernel/native-rust/'+name for name in ['sysfs_zeroing.rs','sysfs_memory.rs','smp_service.rs','smp_memory.rs','ihk_smp_x86_64.rs']]+['scripts/tests/fixtures/native-application-tids-memory.rs']
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false']+[str(source/name) for name in formatted])
    for name in ['smp_resource.rs','smp_image.rs','ihk_mapping.rs','zero_pages.rs','application_rpc.rs','application_syscall.rs','application_pager.rs']:
        shutil.copyfile(source/'host-kernel/native-rust'/name,out/name)
    (out/'memory').mkdir();shutil.copyfile(source/'host-kernel/native-rust/sysfs_zeroing.rs',out/'memory/sysfs_zeroing.rs')
    shutil.copyfile(source/'scripts/tests/fixtures/native-application-tids-memory.rs',out/'native-application-tids-memory.rs')
    memory=source/'host-kernel/native-rust/sysfs_memory.rs';mapping=source/'host-kernel/native-rust/smp_memory.rs'
    generated=''
    for name in ['Span','Tagged','Ledger']:
        generated+=body(memory,r'^(?:#\[[^\n]+\]\n)*(?:pub\(super\) )?struct '+name+r' \{',name)
    for name in ['Span','Ledger']:
        generated+=body(memory,r'^impl '+name+r' \{','impl '+name)
    generated+=body(memory,r'^pub\(super\) struct Memory \{','Memory fields').replace('    #[pin]\n','')
    record['fixture_transforms']=['Remove only the Memory field #[pin] attribute because the test substitutes std::sync::Mutex; retain all field names/types and exact production zeroing/ledger/mapping bodies. Actual constructor, Linux mutex, kthread creation and readiness need real module/guest checks.']
    generated+=body(mapping,r'^trait GuestExtents \{','GuestExtents')
    generated+=body(mapping,r'^impl<const N: usize> GuestExtents for MemoryMap<N> \{','GuestExtents for MemoryMap')
    generated+=body(mapping,r'^impl GuestExtents for \[MemoryExtent\] \{','GuestExtents for slice')
    generated+=body(mapping,r'^fn checked_guest_bytes\(','checked_guest_bytes')
    generated+='impl Memory {\n'
    for name in ['address','application_range','syscall']:
        generated+=body(memory,r'^    (?:pub\(super\) )?fn '+name+r'\(',name)
    generated+='}\n'
    generated+=body(memory,r'^pub\(crate\) struct SyscallResponse \{','SyscallResponse')
    generated+=body(memory,r'^impl SyscallResponse \{','impl SyscallResponse')
    generated+=body(memory,r'^unsafe impl ResponseMemory for SyscallResponse \{','ResponseMemory release')
    generated+=body(source/'host-kernel/native-rust/smp_service.rs',r'^fn admit_zeroing\(','admit_zeroing')
    (out/'native-application-zeroing-memory-bodies.rs').write_text(generated)
    run('rust-build',['rustc','--edition','2021','-D','warnings','--test',str(out/'native-application-tids-memory.rs'),'-o',str(out/'zeroing-tests')])
    run('rust-tests',[str(out/'zeroing-tests'),'--nocapture'])
    record['compiler_inputs']=[identity(path) for path in sorted(out.rglob('*.rs')) if not path.is_relative_to(original)]
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
    record['test_summary']=[line for line in (out/'rust-tests.log').read_text().splitlines() if line.startswith('test result:')]
    record.update(status='PASS',guarded_bytes=16777216,concurrent_chunks=512,allocation_failure_points=5,active_claim_classes=7,queue_full_retries=1024)
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
