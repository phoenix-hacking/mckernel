from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shlex, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-terminal-boundary-tests-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
              commands=[], inputs=[], compiler_dependencies=[], compiled_outputs=[], cases=[],
              application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
              guest_execution=False, scope='Eight actual Linux fork/pipe/wait/clock scenarios calling the unchanged owner-phase-v2 terminal boundary')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    source = repo / 'scripts/tests/fixtures/stability-transport-fault/owner-phase-v2'
    required = {
        'terminal_waitable_harness.c': 'd0e33e0d0d68f250311f15e61bf94e53d71c14d964de7970748f5bc62a99dd55',
        'controller.c': '7b1115f4c744d32bb085f23b515e35bcfab4cf0efa6f2e3cb5827742876511e2',
        'phase_client.h': '03f17078369078898dfafc97b064b29a349efd6f758d9e7895f5cdb91579d9c7',
    }
    for name in (*required, 'terminal-waitable-expectations.json', 'terminal-waitable-harness.md'):
        src, dst = source / name, out / name
        if name in required: assert identity(src)['sha256'] == required[name]
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    src = repo / 'scripts/application-tests/supervisor.py'
    assert identity(src)['sha256'] == '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
    shutil.copyfile(src, out / 'supervisor.py')
    record['inputs'].append(dict(original=identity(src), retained=identity(out / 'supervisor.py')))
    spec = importlib.util.spec_from_file_location('terminal_supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    def run(label, argv, timeout=120):
        if not Path(argv[0]).is_absolute(): argv[0] = shutil.which(argv[0], path=env['PATH'])
        record['phase'] = label; save(); print('RUN', label, flush=True)
        result = supervisor.run_supervised(argv, cwd=str(out), env=env,
            attempt_dir=str(out / (label + '-collection')), timeout_seconds=timeout,
            cleanup_timeout_seconds=15, stdout_limit_bytes=8*1024**2, stderr_limit_bytes=8*1024**2)
        record['commands'].append(dict(label=label, argv=argv, environment=env, collection=result)); save()
        assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete'], (label, result)
        return (out / (label + '-collection') / 'stdout.bin').read_text()
    run('compiler-version', ['gcc', '--version'])
    obj, elf, deps, linkmap = [out / ('terminal-harness' + suffix) for suffix in ('.o', '.elf', '.d', '.map')]
    run('compile', ['gcc', '-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
        '-fno-pie', '-pthread', '-MD', '-MF', str(deps), '-I', str(repo / 'executer/include'),
        '-c', str(out / 'terminal_waitable_harness.c'), '-o', str(obj)])
    run('link', ['gcc', '-no-pie', '-pthread', str(obj), '-Wl,-Map=' + str(linkmap), '-o', str(elf)])
    run('elf', ['readelf', '-h', '-l', '-d', str(elf)])
    data = run('loader-trace', ['ldd', str(elf)])
    for line in data.splitlines():
        for part in line.split():
            if part.startswith('/') and Path(part).is_file(): record.setdefault('loader_dependencies', []).append(identity(Path(part)))
    for item in shlex.split(deps.read_text().replace('\\\n', ' ').split(':', 1)[1]):
        src = Path(item)
        if not src.is_absolute(): src = out / src
        row = identity(src)
        if any(old['original'] == row for old in record['compiler_dependencies']): continue
        dst = out / 'compiler-inputs' / str(src).lstrip('/')
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)
        record['compiler_dependencies'].append(dict(original=row, retained=identity(dst)))
    record['compiled_outputs'] = [identity(p) for p in (obj, elf, deps, linkmap)]
    run('disassembly', ['objdump', '-d', str(elf)])
    expectations = json.loads((out / 'terminal-waitable-expectations.json').read_text())
    assert len(expectations['cases']) == 8
    for expected in expectations['cases']:
        name = expected['name']; attempt = out / ('case-' + name)
        run(name, [str(elf), name, str(attempt)], timeout=15)
        final = json.loads((attempt / 'harness-result.json').read_text())
        observed = json.loads((attempt / 'observation-before-cleanup.json').read_text())
        record['cases'].append(dict(expected=expected, result=final, observation=observed,
                                   final_record=identity(attempt / 'harness-result.json'))); save()
        assert final['case'] == name and final['status'] == 'PASS' and final['assertion_failures'] == 0
        assert final['setup_complete'] and final['cleanup_complete']
        assert not final['application_acceptance'] and not final['transport_acceptance'] and not final['guest_execution']
        assert observed['method_called'] and observed['entry_budget_valid']
        assert observed['method_result'] == expected['method_result']
        assert observed['errno'] == expected['method_failure_errno']
        for key in ('launcher_raw_wait', 'reaped', 'descendant_raw_wait'):
            if key in expected: assert final[key] == expected[key], (name, key)
        assert (attempt / 'stdout.bin').read_bytes() == b'TERMINAL_FIXTURE_STDOUT\n'
        assert (attempt / 'stderr.bin').read_bytes() == b'TERMINAL_FIXTURE_STDERR\n'
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    for row in record['compiled_outputs'] + record['loader_dependencies']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS_ACTUAL_LINUX_TERMINAL_BOUNDARY_ONLY', passed_cases=8)
except BaseException as error:
    record.update(status='FAIL', error_type=type(error).__name__, error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save(); print(record['status'], out, flush=True)
