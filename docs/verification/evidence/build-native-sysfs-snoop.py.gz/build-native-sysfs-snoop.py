"""Build the actual native boot adapter; declared integration remains pending."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
kernel = Path('/work/native-topology-kernel-20260907-1')
out = Path('/work/native-sysfs-snoop-module-20260908-' + sys.argv[1])
assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
out.mkdir()
stage = source / 'drivers/misc/mckernel'
modules = build / 'drivers/misc/mckernel'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), commands=[], overlay=[], production_gate_credit=False, mckernel_boot_proven=False,
              scope='Native boot implementation prototype; live declared graph, FFI review and downstream bindings pending')

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-14000:])

try:
    shutil.copytree(stage, out / 'prior-stage')
    shutil.copytree(modules, out / 'prior-module-build')
    shutil.copyfile(__file__, out / 'helper.py')
    stage.rename(source / ('drivers/misc/mckernel-before-sysfs-snoop-20260908-' + sys.argv[1]))
    shutil.copytree(out / 'prior-stage', stage)
    if (stage / 'stage-lock.json').exists():
        (stage / 'stage-lock.json').rename(stage / 'prior-stage-lock.json')
    inputs = ['smp_resource.rs', 'os_runtime.rs', 'os_registry.rs', 'ihk_ioctl.rs', 'smp_cpu.rs', 'smp_topology.rs', 'sysfs_setup.rs', 'abi/sysfs.rs', 'abi/sysfs_request.rs', 'sysfs_rpc.rs', 'sysfs_remote.rs', 'smp_service.rs', 'sysfs_memory.rs', 'sysfs_snoop.rs', 'smp_memory.rs', 'ihk_smp_x86_64.rs', 'ihk_mapping.rs', 'smp_image.rs', 'smp_loader.rs', 'smp_startup.rs', 'smp_trampoline.rs', 'smp_boot_code.rs', 'smp_ikc.rs', 'smp_vdso.rs', 'sysfs_objects.rs', 'sysfs_os.rs', 'sysfs_tree.rs', 'abi/vdso.rs', 'ikc_queue.rs', 'ikc_master.rs', 'smp_trampoline.S', 'smp_startup_entry.S']
    original = out / 'original-inputs'; original.mkdir()
    for name in inputs:
        saved = original / name; saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, saved)
        shutil.copyfile(repo / 'host-kernel/native-rust' / name, stage / name)
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check'])
    run('format-source', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false'] + [str(stage / name) for name in inputs if name.endswith('.rs')])
    record['overlay'] = [identity(stage / name) for name in inputs]
    shutil.copytree(stage, out / 'staged-source')
    record.update(scope='Native aligned scalar/string corrections plus actual mapping/snooping fixture and separate unchanged-C oracle compilation; runtime checks not yet performed',sysfs_service_completed=False)
    run('module-build', shlex.split((prior / 'module-build.command').read_text()))
    shutil.copytree(modules, out / 'module-build')
    for name in ['ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko']:
        shutil.copyfile(modules / name, out / name)
        disassembly = subprocess.check_output(['objdump', '-d', str(out / name)], text=True)
        (out / (name + '-disassembly.txt')).write_text(disassembly)
        assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', disassembly), name
    fixture_source=out/'fixture/source'; fixture=fixture_source/'scripts/tests/fixtures'; fixture.mkdir(parents=True)
    native=fixture_source/'host-kernel/native-rust'; native.mkdir(parents=True)
    for name in ['sysfs_objects.rs','sysfs_tree.rs','sysfs_memory.rs','sysfs_snoop.rs','abi/sysfs_request.rs']:
        target=native/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/name,target)
    fixture_names=['mckernel_sysfs_snoop_verify.rs','mckernel_native_snoop_checks.rs','mckernel_sysfs_snoop_oracle.c','native-sysfs-snoop.c']
    for name in fixture_names:
        shutil.copyfile(repo/'scripts/tests/fixtures'/name,original/name)
        shutil.copyfile(original/name,fixture/name)
    reference=out/'legacy-reference'; reference.mkdir()
    shutil.copyfile(repo/'executer/kernel/mcctrl/sysfs.c',reference/'sysfs.c')
    def extract(path,signature):
        text=path.read_text();start=text.index(signature);opening=text.index('{',start);depth=1;end=opening+1
        while depth:
            depth+=(text[end]=='{')-(text[end]=='}');end+=1
        body=text[start:end]
        record.setdefault('extracted_bodies',[]).append(dict(source=str(path),signature=signature,start_byte=len(text[:start].encode()),end_byte=len(text[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
        return body
    c=reference/'sysfs.c'
    oracle=extract(c,'struct remote_snooping_param {')+';\n'
    for name in ['bitmap_scnprintf','bitmap_scnlistprintf']:
        oracle+=extract(c,'static inline int\n'+name+'(')+'\n'
    for name in ['d32','d64','u32','u64','s','pbl','pb','u32K']:
        oracle+=extract(c,'static ssize_t snooping_remote_show_'+name+'(')+'\n'
    (fixture/'native-sysfs-snoop-reference.h').write_text(oracle)
    generated='mod memory_fixture {\nuse kernel::prelude::*;\nuse super::smp_resource::{MemoryExtent,MemoryMap};\nconst MAX_EXTENTS: usize=8;\n'
    limit=re.search(r'pub\(crate\) const IDENTITY_WINDOW_END: u64 = [^;]+;', (stage/'smp_image.rs').read_text()).group()
    generated+=limit+'\n'
    for name in ['trait GuestExtents','impl<const N: usize> GuestExtents for MemoryMap<N>','impl GuestExtents for [MemoryExtent]','fn checked_guest_bytes(']:
        generated+=extract(out/'staged-source/smp_memory.rs',name)+'\n'
    generated+='pub(crate) mod service {\nuse kernel::prelude::*;\nuse super::super::smp_resource::OsToken;\nconst METADATA_CAPACITY: usize=64;\nfn errno(code:i32)->Error{kernel::error::to_result(code).err().unwrap_or(EIO)}\n'
    generated+='#[derive(Clone, Copy, Debug, Eq, PartialEq)]\n'+extract(out/'staged-source/ikc_master.rs','pub(crate) struct AcceptSuccess {')+'\n'
    for module,path in [('wire',native/'abi/sysfs_request.rs'),('memory',native/'sysfs_memory.rs'),('snoop',native/'sysfs_snoop.rs')]:
        generated+='#[allow(dead_code)]\n#[path = '+json.dumps(str(path))+'] mod '+module+';\n'
    generated+='#[path = '+json.dumps(str(fixture/'mckernel_native_snoop_checks.rs'))+'] pub(crate) mod checks;\n}}\n'
    (fixture/'native-sysfs-snoop-bindings.rs').write_text(generated)
    run('fixture-format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false']+[str(fixture/name) for name in fixture_names if name.endswith('.rs')])
    (fixture/'Kbuild').write_text('obj-m += mckernel_sysfs_snoop_oracle.o\nobj-m += mckernel_sysfs_snoop_verify.o\n')
    base=shlex.split((prior/'module-build.command').read_text())[:-3]
    run('fixture-build',base+['M='+str(fixture),'modules'])
    for name in ['mckernel_sysfs_snoop_oracle','mckernel_sysfs_snoop_verify']:
        compiled=out/(name+'.ko');shutil.copyfile(fixture/compiled.name,compiled)
        disassembly=subprocess.check_output(['objdump','-d',str(compiled)],text=True);(out/(name+'-disassembly.txt')).write_text(disassembly)
        assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b',disassembly)
        undefined=subprocess.check_output(['nm','-u',str(compiled)],text=True);(out/(name+'-undefined.txt')).write_text(undefined)
        if name.endswith('verify'):
            for symbol in ['sysfs_create_file_ns','sysfs_remove_file_ns','kthread_create_on_node','kthread_stop','mckernel_sysfs_snoop_oracle','bitmap_print_list_to_buf','bitmap_print_bitmask_to_buf']:
                assert ' U '+symbol+'\n' in undefined,symbol
    for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
        assert 'mckernel_sysfs_snoop_oracle' not in subprocess.check_output(['nm',str(out/name)],text=True)
    run('user-probe-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-pthread',str(fixture/'native-sysfs-snoop.c'),'-o',str(out/'native-sysfs-snoop')])
    run('user-probe-dependencies',['ldd',str(out/'native-sysfs-snoop')])
    libraries=out/'lib64';libraries.mkdir()
    for name in ['libc.so.6','ld-linux-x86-64.so.2']:shutil.copy2(Path('/lib64')/name,libraries/name)
    shutil.copyfile(kernel/'bzImage',out/'bzImage')
    shutil.copyfile(kernel/'resolved.config',out/'resolved.config')
    record['inputs']=[identity(p) for p in sorted(original.rglob('*')) if p.is_file()]
    record['inputs'] += [identity(reference/'sysfs.c')]+[identity(p) for p in sorted(libraries.iterdir())]+[identity(kernel/'record.json'),identity(prior/'module-build.command')]
    record['compiler_inputs']=[identity(out/'staged-source'/name) for name in inputs]
    record['compiler_inputs'] += [identity(p) for p in sorted(fixture_source.rglob('*')) if p.is_file() and p.suffix in ('.rs','.c','.h') or p.name=='Kbuild']
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row,row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
