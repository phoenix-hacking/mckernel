from pathlib import Path
import difflib
import hashlib
import json
import os
import shutil
import stat
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
SOURCES = [
    Path('/tmp/stability-published-phase-source-20260913-xnyw2f2j'),
    Path('/tmp/stability-published-host-phase-corrected-20260913-tfi3lxtp'),
    Path('/tmp/stability-selected-send-single-owner-review-20260913-9gpi_2di'),
]
EXPECTED = {
    'scripts/application-tests/published_phase_observations.py': '2023ff165284ac94b48df19dd98cafbd706857cf3a2e3f8c1c17767eb2631bce',
    'scripts/tests/test_published_phase_observations.py': '3a495919bab057ceaa0570e50046b0d23bdf361c7a513821d7b4be99aca9e836',
}

def identity(data):
    return {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def inventory(root):
    rows = []
    for path in [root] + sorted(root.rglob('*')):
        mode = path.lstat().st_mode
        row = {'name': root.name if path == root else root.name + '/' + path.relative_to(root).as_posix(),
               'mode': stat.S_IMODE(mode)}
        if stat.S_ISDIR(mode):
            row.update(type='directory', size=0)
        elif stat.S_ISREG(mode):
            row.update(type='regular', **identity(path.read_bytes()))
        else:
            raise ValueError('unexpected special review member: ' + str(path))
        rows.append(row)
    return rows

copied = []
for source in SOURCES:
    before = inventory(source)
    destination = ROOT / 'author-and-proof' / source.name
    shutil.copytree(source, destination)
    assert inventory(source) == before == inventory(destination)
    copied.append({'original': str(source), 'retained': str(destination.relative_to(ROOT)),
                   'members': before, 'byte_type_mode_membership_equal': True})

reviewed = []
for relative, expected in EXPECTED.items():
    source = REPO / relative
    data = source.read_bytes()
    assert identity(data)['sha256'] == expected
    target = ROOT / 'final-reviewed' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    os.chmod(target, stat.S_IMODE(source.stat().st_mode))
    assert data == (SOURCES[1] / relative).read_bytes()
    previous = (ROOT / 'first-reviewed' / relative).read_bytes()
    delta = ''.join(difflib.unified_diff(previous.decode().splitlines(True), data.decode().splitlines(True),
                                        fromfile='original/' + relative, tofile='corrected/' + relative))
    patch = ROOT / 'diffs' / (source.name + '.diff')
    patch.parent.mkdir(parents=True, exist_ok=True)
    patch.write_text(delta)
    reviewed.append({'original': str(source), 'retained': str(target.relative_to(ROOT)), **identity(data)})

for capture in SOURCES[:2]:
    for row in json.loads((capture / 'inputs.json').read_text()):
        actual = identity((capture / row['path']).read_bytes())
        assert actual == {k: row[k] for k in ('size', 'sha256')}

review = {
    'schema_version': 1,
    'status': 'PASS_SOURCE_REVIEW_ONLY',
    'scope': 'Private published native phase log join and thirteen synthetic test methods; no subject import or execution.',
    'reviewed_final_inputs': reviewed,
    'complete_author_and_proof_captures': copied,
    'original_review': identity((ROOT / 'first-review.json').read_bytes()),
    'closed_findings': [
        {'id': 'local-health', 'resolution': 'Parser lines80-85 require exact selected APP and mailbox local live fields in both first snapshots, including held-only prefix. Five independent accepted local-health mutations are rejected by prepared source tests.'},
        {'id': 'single-sender-host-hold', 'resolution': 'Parser lines97/111 require zero Accepted/READY host-hold calls. Corrected positive literals and two explicit negative mutations bind the sole Packets sender/observer scheduling proof.'},
    ],
    'reasoning': [
        'Exact schema and canonical native producer are required for every HOLD marker; all four counts are inside their own fault-count/phase-end brackets and frozen sequence/state/commit values.',
        'Original selected Claim timer is copied, checked for presence and overflow, and remains unchanged through release/final snapshots. Some(0) is distinguishable from no timer.',
        'Held prefix requires only BlockedRead/AcceptedReturn, exact READY, no release attempt/fault event/RET leave, and health plus retained Returning Request/Worker/Claim from unchanged base parser.',
        'Release binds nonce, original timer, accepted/UART sequence2, nonzero exact LE digest reconstruction, one commit and original deadline. Real send and RET may precede the release log after scalar commit unlock; positive source tests cover release logs both before and after RET_LEAVE.',
        'Mode2 additionally requires original completion/delivery/tag absence and exact worker completed original delivery with no active delivery; closed/quarantined original APP and unchanged owner full-run checks remain required.',
        'Mode3 full unchanged phase validator still requires actual callback success after two-second injected pressure and before original timer deadline; ioctl-specific reserve and digest authenticity remain external joins.',
        'Thirteen test methods retain literal prior fixture provenance, explicit request/reply values and negative raw inputs; no model of a whole-OS atomic snapshot is asserted.',
    ],
    'limitations': [
        'No tests/imports/compilation/container/guest/physical reads were performed by this review lane.',
        'Root corrected freeze contains host coordinator/test snapshots retained as companions only. Their source review belongs to progress_audit and is not asserted here.',
        'Actual compiled native/client identity, ioctl metadata/UART ACK/digest join, QMP stop/resume, physical prepared-response prefix/publication, raw RET/launcher wait/cleanup, and mode3 eight HELLO provenance remain separate required evidence.',
        'A valid native log join supplies metadata evidence only. It does not make a catalog packet executable or close either published transport fault gate.',
    ],
    'test_execution': 'NOT_RUN',
    'application_acceptance': False,
    'transport_acceptance': False,
    'physical_acceptance': False,
    'production_gate_credit': False,
}
(ROOT / 'review-final.json').write_text(json.dumps(review, indent=2, sort_keys=True) + '\n')
archive = REPO / 'docs/verification/evidence/stability-published-phase-independent-review-20260913.tar.gz'
sidecar = REPO / 'docs/verification/stability-published-phase-independent-review-20260913.json'
assert not archive.exists() and not sidecar.exists()
members = inventory(ROOT)
with tarfile.open(archive, 'w:gz') as stream:
    for row in members:
        stream.add(ROOT if row['name'] == ROOT.name else ROOT / Path(row['name']).relative_to(ROOT.name),
                   arcname=row['name'], recursive=False)
with tarfile.open(archive, 'r:gz') as stream:
    actual = []
    for member in stream.getmembers():
        row = {'name': member.name, 'mode': member.mode}
        if member.isdir():
            row.update(type='directory', size=0)
        elif member.isfile():
            row.update(type='regular', **identity(stream.extractfile(member).read()))
        else:
            raise ValueError('unexpected archive member type')
        actual.append(row)
    assert actual == members
assert inventory(ROOT) == members
manifest = {
    'schema_version': 1, 'status': 'PASS_SOURCE_REVIEW_ONLY',
    'review': {'member': ROOT.name + '/review-final.json', **identity((ROOT / 'review-final.json').read_bytes())},
    'archive': {'path': str(archive.relative_to(REPO)), **identity(archive.read_bytes()),
                'members': members, 'verified_exact_bytes_types_modes_and_membership': True},
    'scope': review['scope'], 'test_execution': 'NOT_RUN',
    'application_acceptance': False, 'transport_acceptance': False,
    'physical_acceptance': False, 'production_gate_credit': False,
}
sidecar.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'sidecar': str(sidecar), **identity(sidecar.read_bytes()),
                  'archive': manifest['archive']['sha256'], 'archive_bytes': manifest['archive']['size'],
                  'member_count': len(members), 'review': manifest['review']['sha256']}, indent=2))
