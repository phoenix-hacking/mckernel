from pathlib import Path
import importlib.util,json,time
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('supervisor','/home/holden/mckernel/scripts/application-tests/supervisor.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
(R/'results').mkdir(mode=0o700);(R/'home').mkdir(mode=0o700);(R/'tmp').mkdir(mode=0o700)
env={'PATH':'/usr/bin:/bin','HOME':str(R/'home'),'TMPDIR':str(R/'tmp'),'LC_ALL':'C'}
rows=[]
def run(name,args):
 report=s.run_supervised(args,cwd=str(R),env=env,attempt_dir=str(R/'results'/name),timeout_seconds=24,cleanup_timeout_seconds=3,stdout_limit_bytes=1048576,stderr_limit_bytes=1048576)
 rows.append({'name':name,'report':report});(R/'results/partial.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert report['status']=='COMPLETED' and report['cleanup_complete'] and report['wait_status']=={'kind':'exited','code':0},name
 return report
source=R/'source';user=source/'executer/user'
inc=['-I'+str(p) for p in [user,source,source/'ihk/linux/include',user/'arch/x86_64/include',user/'arch/x86_64',source/'.kernel-sdk']]
flags=['-g','-Wall','-Wextra','-Wno-unused-parameter','-Wno-sign-compare','-Wno-unused-function','-Wno-implicit-fallthrough','-Wno-stringop-truncation']
defs=['-DIHK_IKC_USE_LINUX_WORK_IRQ','-DPROFILE_ENABLE']
start=time.monotonic()
run('c-compile',['/usr/bin/cc',*defs,'-DMCEXEC_RUST_HELPERS',*inc,*flags,'-fPIE','-MD','-MT','mcexec.c.o','-MF',str(R/'mcexec.c.o.d'),'-o',str(R/'mcexec.c.o'),'-c',str(user/'mcexec.c')])
run('asm-compile',['/usr/bin/cc',*defs,*inc,*flags,'-fPIC','-o',str(R/'archdep.S.o'),'-c',str(user/'arch/x86_64/archdep.S')])
run('archive',['/usr/bin/ar','crs',str(R/'libmcexec.a'),str(R/'archdep.S.o')])
run('link',['/usr/bin/cc','-g','-fPIE','-pie','-Wl,--no-undefined','-Wl,-t','-Wl,-Map='+str(R/'mcexec.map'),str(R/'mcexec.c.o'),str(R/'mcexec_helpers.o'),'-o',str(R/'mcexec'),str(R/'libmcexec.a'),'/usr/lib/x86_64-linux-gnu/librt.a','/usr/lib/x86_64-linux-gnu/libnuma.so','-lpthread'])
run('nm-defined',['/usr/bin/nm','--defined-only',str(R/'mcexec')])
run('nm-rust',['/usr/bin/nm','--defined-only',str(R/'mcexec_helpers.o')])
run('nm-c',['/usr/bin/nm',str(R/'mcexec.c.o')])
run('elf',['/usr/bin/readelf','-h','-d','--version-info',str(R/'mcexec')])
required=['transfer_image','act_execve_phase2','act_execve','mcexec_exit_cmd_servers_bridge','mcexec_exit_process_bridge']
final=(R/'results/nm-defined/stdout.bin').read_text().splitlines();rust=(R/'results/nm-rust/stdout.bin').read_text().splitlines();c=(R/'results/nm-c/stdout.bin').read_text().splitlines()
for sym in required:
 assert sum(line.split()[-1]==sym for line in final)==1,sym
 owner=rust if sym in required[:3] else c
 assert sum(line.split()[-1]==sym and line.split()[-2].upper()!='U' for line in owner)==1,sym
result={'status':'PASS_HOST_SELECTED_REAL_C_RUST_LAUNCHER_LINK','elapsed_seconds':time.monotonic()-start,'rows':rows,'unique_final_boundary_definitions':required,'host_only':True,'production_toolchain_acceptance':False,'native_acceptance':False,'launcher_execution':False}
(R/'results/result.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],result['elapsed_seconds'])
