/work/mckernel-native-procfs-images-20260908-1/invalid-native-fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-procfs-images-20260908-1/invalid-native-fallback/tmp.resolve_MODULES_END/driver.o

