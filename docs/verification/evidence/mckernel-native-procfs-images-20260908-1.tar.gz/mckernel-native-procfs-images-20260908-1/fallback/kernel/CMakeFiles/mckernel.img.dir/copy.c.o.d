kernel/CMakeFiles/mckernel.img.dir/copy.c.o: \
 /work/mckernel-native-procfs-images-20260908-1/source/kernel/copy.c
