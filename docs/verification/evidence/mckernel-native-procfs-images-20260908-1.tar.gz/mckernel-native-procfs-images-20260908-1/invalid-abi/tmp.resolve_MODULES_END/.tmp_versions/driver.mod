/work/mckernel-native-procfs-images-20260908-1/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-procfs-images-20260908-1/invalid-abi/tmp.resolve_MODULES_END/driver.o

