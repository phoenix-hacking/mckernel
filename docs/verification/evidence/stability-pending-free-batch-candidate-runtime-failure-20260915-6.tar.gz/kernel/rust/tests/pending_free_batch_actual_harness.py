#!/usr/bin/env python3
"""Compile and run the exact pending-batch definitions from mem_helpers.rs."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "kernel/rust/mem_helpers.rs"
text = SOURCE.read_text()
start = text.index("#[derive(Clone, Copy, PartialEq, Eq)]\nenum PendingFreeBatchState")
end = text.index("\n#[no_mangle]\npub extern \"C\" fn round_up", start)
definitions = text[start:end]
digest = hashlib.sha256(definitions.encode()).hexdigest()

prefix = r'''#![feature(raw_ref_op, let_else)]
#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData, PhantomPinned};
use core::pin::Pin;
use core::ptr::null_mut;
use core::mem::{size_of, MaybeUninit};
macro_rules! offset_of { ($ty:ty, $field:ident) => {{ let p=MaybeUninit::<$ty>::uninit(); core::ptr::addr_of!((*p.as_ptr()).$field) as usize - p.as_ptr() as usize }} }
type CInt = i32; type CULong = u64; type OffT = i64;
const EINVAL: CInt = 22; const PM_NONE: u8 = 0; const PM_PENDING_FREE: u8 = 1;
const IHK_MC_PG_USER: CInt = 1;
#[repr(C)] #[derive(Clone, Copy)] struct AbiListHead { next: *mut AbiListHead, prev: *mut AbiListHead }
#[repr(C)] #[derive(Clone, Copy)] struct IhkAtomic { counter: CInt }
#[repr(C)] #[derive(Clone, Copy)] struct IhkAtomic64 { counter64: i64 }
#[repr(C)] struct MemPage { list: AbiListHead, hash: AbiListHead, mode: u8, phys: CULong, count: IhkAtomic, mapped: IhkAtomic64, offset: OffT, pgshift: CInt }
type MemPendingFreeFn = unsafe extern "C" fn(CULong, CInt, CInt);
unsafe fn page_from_list(node: *mut AbiListHead) -> *mut MemPage { node.cast() }
unsafe fn init_list_head(head: *mut AbiListHead) { (*head).next = head; (*head).prev = head; }
const LIST_POISON1: usize = 0x0010_0129; const LIST_POISON2: usize = 0x0020_0229;
unsafe fn list_del_poison(entry: *mut AbiListHead) { let n=(*entry).next; let p=(*entry).prev; (*n).prev=p; (*p).next=n; (*entry).next=LIST_POISON1 as *mut _; (*entry).prev=LIST_POISON2 as *mut _; }
unsafe fn append(head: *mut AbiListHead, entry: *mut AbiListHead) { (*entry).prev=(*head).prev; (*entry).next=head; (*(*head).prev).next=entry; (*head).prev=entry; }
'''
tests = r'''
static mut FREED: [(CULong, CInt, CInt); 4] = [(0,0,0); 4];
static mut N: usize = 0;
unsafe extern "C" fn free_page(phys: CULong, pages: CInt, kind: CInt) { FREED[N]=(phys,pages,kind); N+=1; }
unsafe fn make(phys: CULong, pages: CInt) -> MemPage { MemPage { list: AbiListHead {next:null_mut(),prev:null_mut()}, hash:AbiListHead {next:null_mut(),prev:null_mut()}, mode:PM_PENDING_FREE, phys, count:IhkAtomic{counter:0}, mapped:IhkAtomic64{counter64:0}, offset:pages as OffT, pgshift:12 } }
fn main() {
 unsafe {
  assert_eq!(size_of::<AbiListHead>(),16); assert_eq!(offset_of!(AbiListHead,next),0); assert_eq!(offset_of!(AbiListHead,prev),8);
  assert_eq!(size_of::<IhkAtomic>(),4); assert_eq!(size_of::<IhkAtomic64>(),8);
  assert_eq!(size_of::<MemPage>(),80); assert_eq!(offset_of!(MemPage,mode),32); assert_eq!(offset_of!(MemPage,phys),40); assert_eq!(offset_of!(MemPage,count),48); assert_eq!(offset_of!(MemPage,mapped),56); assert_eq!(offset_of!(MemPage,offset),64); assert_eq!(offset_of!(MemPage,pgshift),72);
  let mut source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut source);
  let mut a=make(10,2); let mut b=make(20,3); append(&mut source,&mut a.list); append(&mut source,&mut b.list);
  let mut batch=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut batch);
  assert_eq!(detach_pending_free_batch(&mut source,pin.as_mut()),0);
  assert!(source.next.is_null() && source.prev.is_null());
  let view=pin.as_ref().get_ref(); assert!(view.head.next==&mut a.list); assert!(view.head.prev==&mut b.list);
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),None),-EINVAL);
  init_list_head(&mut source); let mut empty=PendingFreeBatch::new();
  assert_eq!(detach_pending_free_batch(&mut source,Pin::new_unchecked(&mut empty)),0); assert!(source.next.is_null()&&source.prev.is_null());
  init_list_head(&mut source); let mut reused=make(30,4); append(&mut source,&mut reused.list);
  let mut second=PendingFreeBatch::new(); let mut second_pin=Pin::new_unchecked(&mut second);
  assert_eq!(detach_pending_free_batch(&mut source,second_pin.as_mut()),0); assert!(source.next.is_null()&&source.prev.is_null());
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),Some(free_page)),2);
  assert_eq!(N,2); assert_eq!(FREED[0],(10,2,IHK_MC_PG_USER)); assert_eq!(FREED[1],(20,3,IHK_MC_PG_USER));
  assert_eq!(a.mode,PM_NONE); assert_eq!(b.mode,PM_NONE);
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),Some(free_page)),-EINVAL);
  let retained_view=second_pin.as_ref().get_ref(); assert!(retained_view.head.next==&mut reused.list);
  let reused_next=reused.list.next; let reused_prev=reused.list.prev; reused.mode=PM_NONE;
  assert_eq!(drain_pending_free_batch(&mut source,second_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(N,2); assert_eq!(reused.list.next,reused_next); assert_eq!(reused.list.prev,reused_prev); reused.mode=PM_PENDING_FREE;
  assert_eq!(drain_pending_free_batch(&mut source,second_pin,Some(free_page)),1); assert_eq!(N,3); assert_eq!(FREED[2],(30,4,IHK_MC_PG_USER));
  // Detach a valid prefix, corrupt a later entry, and prove drain is atomic.
  init_list_head(&mut source); let mut prefix_page=make(60,7); let mut tail_page=make(70,8);
  append(&mut source,&mut prefix_page.list); append(&mut source,&mut tail_page.list);
  let mut late=PendingFreeBatch::new(); let mut late_pin=Pin::new_unchecked(&mut late);
  assert_eq!(detach_pending_free_batch(&mut source,late_pin.as_mut()),0);
  tail_page.mode=PM_NONE; let before_n=N;
  assert_eq!(drain_pending_free_batch(&mut source,late_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(N,before_n); assert_eq!(prefix_page.mode,PM_PENDING_FREE); assert_eq!(tail_page.mode,PM_NONE);
  tail_page.mode=PM_PENDING_FREE;
  assert_eq!(drain_pending_free_batch(&mut source,late_pin,Some(free_page)),2); assert_eq!(N,5);
  // Independent heads and destinations remain isolated, including wrong-source drain.
  let mut other_source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut other_source);
  let mut other_page=make(80,9); append(&mut other_source,&mut other_page.list);
  let mut other_batch=PendingFreeBatch::new(); let mut other_pin=Pin::new_unchecked(&mut other_batch);
  assert_eq!(detach_pending_free_batch(&mut other_source,other_pin.as_mut()),0);
  let mut wrong_head=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut wrong_head);
  assert_eq!(drain_pending_free_batch(&mut wrong_head,other_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(drain_pending_free_batch(&mut other_source,other_pin,Some(free_page)),1); assert_eq!(N,6);
  let mut invalid_source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut invalid_source);
  let mut valid=make(40,5); let mut invalid=make(50,6); append(&mut invalid_source,&mut valid.list); append(&mut invalid_source,&mut invalid.list); invalid.mode=PM_NONE;
  let snapshot=invalid_source; let valid_next=valid.list.next; let valid_prev=valid.list.prev; let invalid_next=invalid.list.next; let invalid_prev=invalid.list.prev; let mut reject=PendingFreeBatch::new();
  assert_eq!(detach_pending_free_batch(&mut invalid_source,Pin::new_unchecked(&mut reject)),-EINVAL);
  assert_eq!(invalid_source.next,snapshot.next); assert_eq!(invalid_source.prev,snapshot.prev); assert_eq!(valid.list.next,valid_next); assert_eq!(valid.list.prev,valid_prev); assert_eq!(invalid.list.next,invalid_next); assert_eq!(invalid.list.prev,invalid_prev); assert_eq!(valid.phys,40); assert_eq!(valid.offset,5);
  println!("PASS actual pending-free helper vectors source-definitions-sha256={digest}");
 }
}
'''
requested_out = os.environ.get("MCKERNEL_PENDING_OUT")
context = tempfile.TemporaryDirectory(prefix="mckernel-pending-actual-") if not requested_out else None
td = requested_out or context.name
Path(td).mkdir(parents=True, exist_ok=True)
if True:
    src = Path(td) / "actual.rs"; binary = Path(td) / "actual"
    src.write_text(prefix + definitions + tests.replace("{digest}", digest))
    subprocess.run(["rustc", "+nightly", "--edition=2021", "-D", "warnings", str(src), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
    negative = {
        "unpin": "fn need<T: Unpin>() {} fn main() { need::<PendingFreeBatch>(); }",
        "send": "fn main() { let batch = PendingFreeBatch::new(); std::thread::spawn(move || drop(batch)); }",
        "sync": "fn need<T: Sync>() {} fn main() { need::<PendingFreeBatch>(); }",
    }
    for name, body in negative.items():
        neg = Path(td) / (name + ".rs")
        neg.write_text(prefix + definitions + body)
        result = subprocess.run(["rustc", "+nightly", "--edition=2021", str(neg), "-o", str(Path(td) / name)], text=True, capture_output=True)
        if result.returncode == 0:
            raise SystemExit("actual PendingFreeBatch negative check unexpectedly compiled: " + name)
        if name.capitalize() not in result.stderr and name != "send":
            raise SystemExit("actual PendingFreeBatch negative diagnostic missing: " + name)
        if name == "send" and "Send" not in result.stderr:
            raise SystemExit("actual PendingFreeBatch negative diagnostic missing: send")
    csrc = ROOT / "kernel/rust/tests/pending_free_batch_vectors.c"
    cbin = Path(td) / "reference-c"
    subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", str(csrc), "-o", str(cbin)], check=True)
    cresult = subprocess.run([str(cbin)], text=True, capture_output=True, check=True)
    expected = "RESULT pending-free-c abi-list-size=16 abi-list-next=0 abi-list-prev=8 node-size=24 node-pending=16 node-value=20 empty-source-null=1 nonempty-order=1 invalid-preserved=1\n"
    if cresult.stdout != expected:
        raise SystemExit("C reference outcome mismatch: " + repr(cresult.stdout))
    manifest = {
        "source": str(SOURCE),
        "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        "extracted_definitions_sha256": digest,
        "rust_fixture_sha256": hashlib.sha256((ROOT / "kernel/rust/tests/pending_free_batch_vectors.rs").read_bytes()).hexdigest(),
        "c_fixture_sha256": hashlib.sha256(csrc.read_bytes()).hexdigest(),
        "c_result": cresult.stdout.strip(),
    }
    (Path(td) / "manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    print("PASS pending-free actual harness output=" + str(Path(td)))
