#![feature(raw_ref_op, let_else)]
#![allow(dead_code, unsafe_op_in_unsafe_fn)]
use core::marker::{PhantomData, PhantomPinned};
use core::pin::Pin;
use core::ptr::null_mut;
use core::mem::{size_of, MaybeUninit};
macro_rules! offset_of { ($ty:ty, $field:ident) => {{ let p=MaybeUninit::<$ty>::uninit(); core::ptr::addr_of!((*p.as_ptr()).$field) as usize - p.as_ptr() as usize }} }
type CInt = i32; type CULong = u64; type OffT = i64;
const EINVAL: CInt = 22; const PM_NONE: u8 = 0; const PM_PENDING_FREE: u8 = 1;
const IHK_MC_PG_USER: CInt = 1;
#[repr(C)] #[derive(Clone, Copy)] struct AbiListHead { next: *mut AbiListHead, prev: *mut AbiListHead }
#[repr(C)] #[derive(Clone, Copy)] struct IhkAtomic { counter: CInt }
#[repr(C)] #[derive(Clone, Copy)] struct IhkAtomic64 { counter64: i64 }
#[repr(C)] struct MemPage { list: AbiListHead, hash: AbiListHead, mode: u8, phys: CULong, count: IhkAtomic, mapped: IhkAtomic64, offset: OffT, pgshift: CInt }
type MemPendingFreeFn = unsafe extern "C" fn(CULong, CInt, CInt);
unsafe fn page_from_list(node: *mut AbiListHead) -> *mut MemPage { node.cast() }
unsafe fn init_list_head(head: *mut AbiListHead) { (*head).next = head; (*head).prev = head; }
const LIST_POISON1: usize = 0x0010_0129; const LIST_POISON2: usize = 0x0020_0229;
unsafe fn list_del_poison(entry: *mut AbiListHead) { let n=(*entry).next; let p=(*entry).prev; (*n).prev=p; (*p).next=n; (*entry).next=LIST_POISON1 as *mut _; (*entry).prev=LIST_POISON2 as *mut _; }
unsafe fn append(head: *mut AbiListHead, entry: *mut AbiListHead) { (*entry).prev=(*head).prev; (*entry).next=head; (*(*head).prev).next=entry; (*head).prev=entry; }
#[derive(Clone, Copy, PartialEq, Eq)]
enum PendingFreeBatchState {
    Vacant,
    Retained,
    Drained,
}

/// Pinned transaction destination for pending-page ownership transfer.
/// It is deliberately !Unpin, !Send and !Sync and never frees implicitly.
struct PendingFreeBatch {
    head: AbiListHead,
    state: PendingFreeBatchState,
    source: *mut AbiListHead,
    _pin: PhantomPinned,
    _owner: PhantomData<*mut ()>,
}

impl PendingFreeBatch {
    const fn new() -> Self {
        Self {
            head: AbiListHead { next: null_mut(), prev: null_mut() },
            state: PendingFreeBatchState::Vacant,
            source: null_mut(),
            _pin: PhantomPinned,
            _owner: PhantomData,
        }
    }
}

unsafe fn validate_pending_head(head: *mut AbiListHead) -> Result<bool, CInt> {
    if head.is_null() || (*head).next.is_null() || (*head).prev.is_null() {
        return Err(-EINVAL);
    }
    if (*head).next == head || (*head).prev == head {
        if (*head).next != head || (*head).prev != head {
            return Err(-EINVAL);
        }
        return Ok(false);
    }
    if (*(*head).next).prev != head || (*(*head).prev).next != head {
        return Err(-EINVAL);
    }

    // Validate the complete ring before changing either list.  Floyd's
    // traversal detects a foreign cycle without imposing a node-count cap.
    let mut slow = (*head).next;
    let mut fast = (*head).next;
    loop {
        if slow == head {
            break;
        }
        if slow.is_null()
            || (*slow).next.is_null()
            || (*slow).prev.is_null()
            || (*(*slow).next).prev != slow
            || (*(*slow).prev).next != slow
        {
            return Err(-EINVAL);
        }
        let page = page_from_list(slow);
        if page.is_null() || (*page).mode != PM_PENDING_FREE {
            return Err(-EINVAL);
        }
        slow = (*slow).next;

        if fast == head {
            continue;
        }
        if fast.is_null() || (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == head {
            continue;
        }
        if (*fast).next.is_null() {
            return Err(-EINVAL);
        }
        fast = (*fast).next;
        if fast == slow && slow != head {
            return Err(-EINVAL);
        }
    }
    Ok(true)
}

unsafe fn detach_pending_free_batch(
    source: *mut AbiListHead,
    mut destination: Pin<&mut PendingFreeBatch>,
) -> CInt {
    // Safety obligations: the caller owns an exclusive, CPU-local source
    // ring and keeps every live descriptor stable; no producer may enqueue or
    // callback may re-enter while this transaction is detached. `destination`
    // must remain at this pinned address until drain (or explicit recovery).
    let dest = destination.as_mut().get_unchecked_mut();
    let dest_head = &raw mut dest.head;
    if source.is_null()
        || source == dest_head
        || dest.state != PendingFreeBatchState::Vacant
        || !(dest.head.next.is_null() && dest.head.prev.is_null())
    {
        return -EINVAL;
    }
    let nonempty = match validate_pending_head(source) {
        Ok(nonempty) => nonempty,
        Err(_) => return -EINVAL,
    };
    if nonempty {
        let first = (*source).next;
        let last = (*source).prev;
        init_list_head(dest_head);
        (*dest_head).next = first;
        (*dest_head).prev = last;
        (*first).prev = dest_head;
        (*last).next = dest_head;
        (*source).next = null_mut();
        (*source).prev = null_mut();
    } else {
        init_list_head(dest_head);
        (*source).next = null_mut();
        (*source).prev = null_mut();
    }
    dest.source = source;
    dest.state = PendingFreeBatchState::Retained;
    0
}

unsafe fn drain_pending_free_batch(
    source: *mut AbiListHead,
    mut batch: Pin<&mut PendingFreeBatch>,
    free_fn: Option<MemPendingFreeFn>,
) -> CInt {
    // Safety obligations: `source` must be the exact source captured by
    // detach, the pinned transaction must outlive this call, and `free_fn`
    // must not mutate either list or re-enter detach/drain. The caller owns
    // the exclusive CPU/descriptor lease for the whole operation.
    let Some(free_fn) = free_fn else { return -EINVAL; };
    let b = batch.as_mut().get_unchecked_mut();
    if b.state != PendingFreeBatchState::Retained
        || b.source != source
        || validate_pending_head(&raw mut b.head).is_err()
    {
        return -EINVAL;
    }
    let mut node = b.head.next;
    let mut count = 0;
    while node != &raw mut b.head {
        let next = (*node).next;
        let page = page_from_list(node);
        (*page).mode = PM_NONE;
        list_del_poison(node);
        free_fn((*page).phys, (*page).offset as CInt, IHK_MC_PG_USER);
        count += 1;
        node = next;
    }
    b.head.next = null_mut();
    b.head.prev = null_mut();
    b.source = null_mut();
    b.state = PendingFreeBatchState::Drained;
    count
}

static mut FREED: [(CULong, CInt, CInt); 4] = [(0,0,0); 4];
static mut N: usize = 0;
unsafe extern "C" fn free_page(phys: CULong, pages: CInt, kind: CInt) { FREED[N]=(phys,pages,kind); N+=1; }
unsafe fn make(phys: CULong, pages: CInt) -> MemPage { MemPage { list: AbiListHead {next:null_mut(),prev:null_mut()}, hash:AbiListHead {next:null_mut(),prev:null_mut()}, mode:PM_PENDING_FREE, phys, count:IhkAtomic{counter:0}, mapped:IhkAtomic64{counter64:0}, offset:pages as OffT, pgshift:12 } }
fn main() {
 unsafe {
  assert_eq!(size_of::<AbiListHead>(),16); assert_eq!(offset_of!(AbiListHead,next),0); assert_eq!(offset_of!(AbiListHead,prev),8);
  assert_eq!(size_of::<IhkAtomic>(),4); assert_eq!(size_of::<IhkAtomic64>(),8);
  assert_eq!(size_of::<MemPage>(),80); assert_eq!(offset_of!(MemPage,mode),32); assert_eq!(offset_of!(MemPage,phys),40); assert_eq!(offset_of!(MemPage,count),48); assert_eq!(offset_of!(MemPage,mapped),56); assert_eq!(offset_of!(MemPage,offset),64); assert_eq!(offset_of!(MemPage,pgshift),72);
  let mut source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut source);
  let mut a=make(10,2); let mut b=make(20,3); append(&mut source,&mut a.list); append(&mut source,&mut b.list);
  let mut batch=PendingFreeBatch::new(); let mut pin=Pin::new_unchecked(&mut batch);
  assert_eq!(detach_pending_free_batch(&mut source,pin.as_mut()),0);
  assert!(source.next.is_null() && source.prev.is_null());
  let view=pin.as_ref().get_ref(); assert!(view.head.next==&mut a.list); assert!(view.head.prev==&mut b.list);
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),None),-EINVAL);
  init_list_head(&mut source); let mut empty=PendingFreeBatch::new();
  assert_eq!(detach_pending_free_batch(&mut source,Pin::new_unchecked(&mut empty)),0); assert!(source.next.is_null()&&source.prev.is_null());
  init_list_head(&mut source); let mut reused=make(30,4); append(&mut source,&mut reused.list);
  let mut second=PendingFreeBatch::new(); let mut second_pin=Pin::new_unchecked(&mut second);
  assert_eq!(detach_pending_free_batch(&mut source,second_pin.as_mut()),0); assert!(source.next.is_null()&&source.prev.is_null());
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),Some(free_page)),2);
  assert_eq!(N,2); assert_eq!(FREED[0],(10,2,IHK_MC_PG_USER)); assert_eq!(FREED[1],(20,3,IHK_MC_PG_USER));
  assert_eq!(a.mode,PM_NONE); assert_eq!(b.mode,PM_NONE);
  assert_eq!(drain_pending_free_batch(&mut source,pin.as_mut(),Some(free_page)),-EINVAL);
  let retained_view=second_pin.as_ref().get_ref(); assert!(retained_view.head.next==&mut reused.list);
  let reused_next=reused.list.next; let reused_prev=reused.list.prev; reused.mode=PM_NONE;
  assert_eq!(drain_pending_free_batch(&mut source,second_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(N,2); assert_eq!(reused.list.next,reused_next); assert_eq!(reused.list.prev,reused_prev); reused.mode=PM_PENDING_FREE;
  assert_eq!(drain_pending_free_batch(&mut source,second_pin,Some(free_page)),1); assert_eq!(N,3); assert_eq!(FREED[2],(30,4,IHK_MC_PG_USER));
  // Detach a valid prefix, corrupt a later entry, and prove drain is atomic.
  init_list_head(&mut source); let mut prefix_page=make(60,7); let mut tail_page=make(70,8);
  append(&mut source,&mut prefix_page.list); append(&mut source,&mut tail_page.list);
  let mut late=PendingFreeBatch::new(); let mut late_pin=Pin::new_unchecked(&mut late);
  assert_eq!(detach_pending_free_batch(&mut source,late_pin.as_mut()),0);
  tail_page.mode=PM_NONE; let before_n=N;
  assert_eq!(drain_pending_free_batch(&mut source,late_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(N,before_n); assert_eq!(prefix_page.mode,PM_PENDING_FREE); assert_eq!(tail_page.mode,PM_NONE);
  tail_page.mode=PM_PENDING_FREE;
  assert_eq!(drain_pending_free_batch(&mut source,late_pin,Some(free_page)),2); assert_eq!(N,5);
  // Independent heads and destinations remain isolated, including wrong-source drain.
  let mut other_source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut other_source);
  let mut other_page=make(80,9); append(&mut other_source,&mut other_page.list);
  let mut other_batch=PendingFreeBatch::new(); let mut other_pin=Pin::new_unchecked(&mut other_batch);
  assert_eq!(detach_pending_free_batch(&mut other_source,other_pin.as_mut()),0);
  let mut wrong_head=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut wrong_head);
  assert_eq!(drain_pending_free_batch(&mut wrong_head,other_pin.as_mut(),Some(free_page)),-EINVAL);
  assert_eq!(drain_pending_free_batch(&mut other_source,other_pin,Some(free_page)),1); assert_eq!(N,6);
  let mut invalid_source=AbiListHead{next:null_mut(),prev:null_mut()}; init_list_head(&mut invalid_source);
  let mut valid=make(40,5); let mut invalid=make(50,6); append(&mut invalid_source,&mut valid.list); append(&mut invalid_source,&mut invalid.list); invalid.mode=PM_NONE;
  let snapshot=invalid_source; let valid_next=valid.list.next; let valid_prev=valid.list.prev; let invalid_next=invalid.list.next; let invalid_prev=invalid.list.prev; let mut reject=PendingFreeBatch::new();
  assert_eq!(detach_pending_free_batch(&mut invalid_source,Pin::new_unchecked(&mut reject)),-EINVAL);
  assert_eq!(invalid_source.next,snapshot.next); assert_eq!(invalid_source.prev,snapshot.prev); assert_eq!(valid.list.next,valid_next); assert_eq!(valid.list.prev,valid_prev); assert_eq!(invalid.list.next,invalid_next); assert_eq!(invalid.list.prev,invalid_prev); assert_eq!(valid.phys,40); assert_eq!(valid.offset,5);
  println!("PASS actual pending-free helper vectors source-definitions-sha256=680dc2aa3faac80d116276a953e9831a53fe2a444f113525e72f53c3d4e0352a");
 }
}
