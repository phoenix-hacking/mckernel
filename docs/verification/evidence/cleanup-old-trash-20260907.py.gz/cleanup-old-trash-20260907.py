"""Remove only long-discarded user Trash entries; retain aggregate metadata only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import stat
import time

WORK = Path('/home/holden/mckernel-work/scratch')
TRASH = Path('/home/holden/.local/share/Trash')
REPORT = WORK / 'storage-old-trash-cleanup-20260907.json'


def snapshot(root):
    stack = [root]
    rows = {}
    while stack:
        path = stack.pop()
        st = path.lstat()
        assert st.st_dev == TRASH.stat().st_dev and st.st_uid == os.getuid()
        assert stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode)
        rows[str(path.relative_to(root))] = (st.st_mode, st.st_size, st.st_ino,
            st.st_mtime_ns, st.st_ctime_ns, st.st_blocks, st.st_nlink)
        if stat.S_ISDIR(st.st_mode):
            stack.extend(path.iterdir())
    return rows


def assert_not_open():
    # Never remove an entry being viewed or used by a process visible to this user.
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            links = list((process / 'fd').iterdir()) + [process / 'cwd', process / 'root']
        except (PermissionError, FileNotFoundError, ProcessLookupError):
            continue
        for link in links:
            try:
                target = os.readlink(link)
            except (PermissionError, FileNotFoundError, ProcessLookupError, OSError):
                continue
            assert target != str(TRASH) and not target.startswith(str(TRASH) + '/'), 'Trash entry currently open'


def save(value):
    REPORT.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    assert os.getuid() == 1000 and not REPORT.exists()
    assert shutil.rmtree.avoids_symlink_attacks
    for path in (TRASH, TRASH / 'files', TRASH / 'info'):
        assert path.is_dir() and not path.is_symlink() and path.stat().st_uid == os.getuid()
    now = time.time()
    cutoff = now - 365 * 86400
    candidates = []
    skipped = 0
    for info in sorted((TRASH / 'info').glob('*.trashinfo')):
        assert info.is_file() and not info.is_symlink()
        data = info.read_bytes()
        values = dict(line.split('=', 1) for line in data.decode().splitlines() if '=' in line)
        deleted = datetime.fromisoformat(values['DeletionDate']).timestamp()
        source = TRASH / 'files' / info.name.removesuffix('.trashinfo')
        assert source.exists() or source.is_symlink()
        state = snapshot(source)
        if deleted > cutoff or any(row[3] / 1e9 > cutoff for row in state.values()):
            skipped += 1
            continue
        assert all(not stat.S_ISREG(row[0]) or row[6] == 1 for row in state.values()), 'Shared hardlink in Trash'
        candidates.append((source, info, data, state, deleted, info.stat().st_blocks * 512))
    assert_not_open()
    # Retain only counts, ages and storage measurements, never personal filenames or content.
    report = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
        criterion='User Trash entries discarded over 365 days ago with no newer payload modifications',
        candidate_items=len(candidates), skipped_recent_items=skipped,
        newest_deletion_date=datetime.fromtimestamp(max(c[4] for c in candidates)).isoformat() if candidates else None,
        oldest_deletion_date=datetime.fromtimestamp(min(c[4] for c in candidates)).isoformat() if candidates else None,
        root_free_before=shutil.disk_usage('/').free, removed_items=0, removed_entries=0,
        removed_allocated_bytes=0, personal_paths_or_contents_recorded=False)
    save(report)
    try:
        for source, info, data, state, deleted, info_bytes in candidates:
            assert snapshot(source) == state and info.read_bytes() == data
            assert_not_open()
            if source.is_dir() and not source.is_symlink():
                shutil.rmtree(source)
            else:
                source.unlink()
            info.unlink()
            assert not source.exists() and not source.is_symlink() and not info.exists()
            report['removed_items'] += 1
            report['removed_entries'] += len(state) + 1
            report['removed_allocated_bytes'] += sum(row[5] * 512 for row in state.values()) + info_bytes
            save(report)
        report.update(status='PASS', root_free_after=shutil.disk_usage('/').free,
            remaining_payload_items=sum(1 for _ in (TRASH / 'files').iterdir()))
    except BaseException as error:
        # Do not retain exception paths from personal Trash entries.
        report.update(status='FAIL', error_type=type(error).__name__)
        raise
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save(report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
