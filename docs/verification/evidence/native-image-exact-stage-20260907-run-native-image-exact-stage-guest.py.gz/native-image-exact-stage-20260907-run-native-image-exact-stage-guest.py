from datetime import datetime, timezone
import hashlib, json, subprocess
from pathlib import Path
root = Path('/work/native-image-exact-stage-20260907-1')
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), production_gate_credit=False,
              recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), steps=[])
commands = [
    ('module-checks', ['python3', '-B', '/work/check-native-image-exact-stage-modules.py']),
    ('guest', ['python3', '-B', '/work/run-native-image-loader-guest.py',
               str(root), '/work/native-image-exact-stage-guest-20260907-1']),
    ('rust-inventory', ['python3', '-B', '/work/inventory-rust-consumers-image-20260907.py']),
]
for name, command in commands:
    print('START ' + name, flush=True)
    with (root/(name+'.log')).open('xb') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    record['steps'].append(dict(name=name, command=command, exit_code=result.returncode))
    print('FINISH ' + name + ' exit=' + str(result.returncode), flush=True)
    if result.returncode:
        break
record.update(exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
with (root/'postbuild-record.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2)+'\n')
raise SystemExit(result.returncode)
