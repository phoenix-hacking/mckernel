from pathlib import Path
from datetime import datetime, timezone
import json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
base = Path('/work/native-irq-suite-retry-20260907-1')
base.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[])
for index, command in enumerate([
    ['python3', '-B', '/work/run-native-irq-full-tests.py', '2'],
    ['python3', '-B', '/work/inventory-rust-consumers-irq-final-20260907.py'],
]):
    print('Starting', command, flush=True)
    with (base / ('step-' + str(index) + '.log')).open('wb') as output:
        result = subprocess.run(command, cwd='/workspace', stdout=output, stderr=subprocess.STDOUT)
    record['results'].append(dict(command=command, exit_code=result.returncode))
    record['exit_code'] = result.returncode
    record['updated_utc'] = datetime.now(timezone.utc).isoformat()
    (base / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Finished', index, 'exit', result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
