from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, re, subprocess, tarfile
repo, work = Path('/workspace'), Path('/work')
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = work / 'native-irq-final-retained-20260907-1'
out.mkdir()

def identity(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        while True:
            data = stream.read(1 << 20)
            if not data: break
            digest.update(data)
            size += len(data)
    return dict(size=size, sha256=digest.hexdigest())

references, checked = [], []
for name in ['native-irq-work-checkpoint-20260907.json', 'native-irq-images-checkpoint-20260907.json', 'native-irq-runtime-checkpoint-20260907.json']:
    path = repo / 'docs/verification' / name
    references.append(dict(path=str(path.relative_to(repo)), **identity(path)))
    checkpoint = json.loads(path.read_text())
    assert checkpoint['production_gate_credit'] is False and checkpoint['mckernel_boot_proven'] is False
    for row in checkpoint['artifacts']:
        artifact = repo / row['path']
        actual = identity(artifact)
        assert actual['size'] == row['size'] and actual['sha256'] == row['sha256'], row['path']
        digest, size = hashlib.sha256(), 0
        with gzip.open(artifact, 'rb') as stream:
            while True:
                data = stream.read(1 << 20)
                if not data: break
                digest.update(data)
                size += len(data)
        if 'unpacked_size' in row:
            assert size == row['unpacked_size'] and digest.hexdigest() == row['unpacked_sha256'], row['path']
        checked.append(row['path'])

run = json.loads((work / 'native-irq-full-suite-20260907-2.json').read_text())
log = (work / 'native-irq-full-suite-20260907-2.log').read_text()
assert run['exit_code'] == 0 and not run['changed_inputs']
match = re.search(r'^Ran ([0-9]+) tests in ([0-9.]+)s$', log, re.M)
okay = re.search(r'^OK \(skipped=([0-9]+)\)$', log, re.M)
assert match and okay
count, seconds, skipped = int(match[1]), float(match[2]), int(okay[1])
assert count >= 2315 and skipped == 71
completion = json.loads((work / 'native-irq-completion-checks-20260907-1/record.json').read_text())
assert completion['exit_code'] == 1 and len(completion['results']) == 4
assert all(row['exit_code'] == 0 for row in completion['results'][:3])
retry = json.loads((work / 'native-irq-suite-retry-20260907-1/record.json').read_text())
assert retry['exit_code'] == 0 and len(retry['results']) == 2
assert all(row['exit_code'] == 0 for row in retry['results'])
guest_root = work / 'native-irq-image-load-guest-20260907-4'
guest = json.loads((guest_root / 'local-run.json').read_text())
assert guest['status'] == 'technical-capture-passed' and guest['qemu_exit_code'] == 0
assert not guest['missing_markers'] and not guest['error_markers']
assert len(guest['physical_image_readbacks']) == len(guest['physical_startup_table_readbacks']) == 56
assert guest['startup_allocation_failures'] == 64
assert guest['image_model']['image']['sha256'] == 'fb7f5140c8a877b2f927c222332bf589ad70120849285e50b46c352bfcd79ad1'
intervening = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', guest['source_parent'], run['source_parent']], text=True).splitlines()
assert set(intervening) == {'kernel.log', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs'}
image_checkpoint = json.loads((repo / 'docs/verification/native-irq-images-checkpoint-20260907.json').read_text())
for row in image_checkpoint['production_inputs']:
    relative = row['path'].split('/source/', 1)[1]
    actual = identity(repo / relative)
    assert actual['size'] == row['size'] and actual['sha256'] == row['sha256'], relative
for name in ['native-image-load.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c']:
    assert identity(guest_root / 'probe-source' / name) == identity(repo / 'scripts/tests/fixtures' / name)
serial = (guest_root / 'serial.log').read_text()
measurements = [dict(abi=abi, buddy_before_kib=int(before), buddy_after_kib=int(after), pcp_before_kib=int(cbefore), pcp_after_kib=int(cafter))
    for abi, before, after, cbefore, cafter in re.findall(r'NATIVE_IMAGE_LOAD (x86_64|i386) startup-memory-kib before=([0-9]+) after=([0-9]+) cached-before=([0-9]+) cached-after=([0-9]+)', serial)]
assert len(measurements) == 4
for row in measurements:
    row['total_free_loss_kib'] = row['buddy_before_kib'] + row['pcp_before_kib'] - row['buddy_after_kib'] - row['pcp_after_kib']
    assert row['total_free_loss_kib'] <= 4096
inventory = json.loads((work / 'rust-consumers-irq-final-20260907.json').read_text())
assert inventory['source_parent'] == run['source_parent']
assert len(inventory['files']) == 139 and inventory['kernel_crate_files'] == 64
assert not inventory['removed_baseline_files'] and not inventory['cmake_missing_dependencies'] and not inventory['cmake_extra_dependencies']
assert len(set().union(*(set(paths) for paths in inventory['native_module_graph'].values()))) == 19
artifacts = []

def retain(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            while True:
                data = source.read(1 << 20)
                if not data: break
                output.write(data)
    artifacts.append(dict(path='docs/verification/evidence/' + name, source=str(path), **identity(target),
                          unpacked_size=path.stat().st_size, unpacked_sha256=identity(path)['sha256']))

def retain_tree(path):
    target = out / (path.name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        archive.add(path, arcname=path.name)
    artifacts.append(dict(path='docs/verification/evidence/' + target.name, source=str(path), **identity(target)))

retain_tree(guest_root)
retain(guest_root / 'local-run.json', guest_root.name + '-local-run.json.gz')
retain(guest_root / 'serial.log', guest_root.name + '-serial.log.gz')
retain_tree(work / 'native-irq-completion-checks-20260907-1')
retain_tree(work / 'native-irq-suite-retry-20260907-1')
for name in ['native-irq-full-suite-20260907-1.json', 'native-irq-full-suite-20260907-1.log',
             'native-irq-full-suite-20260907-2.json', 'native-irq-full-suite-20260907-2.log',
             'rust-consumers-irq-20260907.json', 'rust-consumers-irq-final-20260907.json',
             'run-native-irq-completion-checks.py', 'run-native-irq-full-tests.py', 'run-native-irq-suite-retry.py',
             'inventory-rust-consumers-irq-final-20260907.py', 'retain-native-irq-final.py']:
    retain(work / name, 'native-irq-final-20260907-' + name + '.gz')
for row in artifacts:
    digest, size = hashlib.sha256(), 0
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        while True:
            data = stream.read(1 << 20)
            if not data: break
            digest.update(data)
            size += len(data)
    if 'unpacked_size' in row:
        assert size == row['unpacked_size'] and digest.hexdigest() == row['unpacked_sha256'], row['path']
(out / 'rust-consumers-irq-20260907.json').write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
record = dict(schema_version=1, kind='native-irq-image-full-verification-checkpoint-with-open-irq-runtime-failure',
    recorded_utc=datetime.now(timezone.utc).isoformat(), source_parent=run['source_parent'],
    full_repository_suite=dict(status='PASS', total=count, passed=count-skipped, skipped=skipped, duration_seconds=seconds,
        started_utc=run['started_utc'], finished_utc=run['finished_utc'], uncommitted_source_overlays=0, environment=run['environment']),
    native_image_guest=dict(status='PASS', capture=guest_root.name, source_parent=guest['source_parent'], image_sha256=guest['image_model']['image']['sha256'],
        image_readbacks=56, startup_table_readbacks=56, forced_startup_allocation_failures=64, abis=['x86_64', 'i386'], cycles=2,
        vcpus=4, numa_nodes=2, memory_mib=8192, started_utc=guest['started_utc'], finished_utc=guest['finished_utc'],
        source_probe_matches_current=True, image_production_inputs_match_current=True, cleanup_allowance_kib=4096, cleanup_measurements=measurements),
    rust_inventory=dict(files=139, kernel_crate_files=64, native_staged_files=19, preservation_counts=inventory['preservation_counts'],
        removed_baseline_files=[], path='docs/verification/rust-consumers-irq-20260907.json'),
    retained_prior_evidence=dict(status='PASS', artifacts=len(checked), unique_artifacts=len(set(checked)), gzip_streams_checked=True),
    retained_new_evidence=dict(status='PASS', artifacts=len(artifacts), gzip_streams_checked=True),
    production_gate_credit=False, native_mckernel_boot_proven=False, complete_rust_unification_claimed=False,
    open=['Intermittent Linux default-idle timer/RCU stall in IRQ guest 2 remains unresolved despite later poll/default passes',
          'Historical broad C/Rust equivalence harness lacks three pinned IHK source prerequisites; direct touched-producer comparison passes',
          'Owned low-memory trampoline and exact boot parameters', 'Native CPU wakeup, cross-kernel IRQ/IKC and readiness',
          'Native mcctrl/application verification', 'Complete McKernel and linked support in Rust or reviewed assembly',
          'Independent production acceptance'], references=references, artifacts=artifacts)
(out / 'native-irq-final-validation-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({key:record[key] for key in ['full_repository_suite', 'rust_inventory', 'retained_prior_evidence']}, indent=2), flush=True)
