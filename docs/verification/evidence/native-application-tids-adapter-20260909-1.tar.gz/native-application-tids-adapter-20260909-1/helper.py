from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-tids-adapter-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],extracted_bodies=[],actual_guest_pass=False,scope='Exact native transfer method, actual image byte codecs and kernel ABI; controlled referenced current worker/MM, guarded 32/64-bit descriptor/user buffers, allocation and backend providers. Actual Linux integration requires module/guest.')
def identity(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,command):
 print('RUN',label,flush=True)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append(dict(label=label,command=command,exit_code=r.returncode));assert r.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])
try:
 shutil.copyfile(__file__,out/'helper.py')
 names=['host-kernel/native-rust/mcctrl_process.rs','host-kernel/native-rust/application_image.rs','host-kernel/native-rust/abi/application.rs','scripts/tests/fixtures/native-application-tids-adapter.rs','executer/include/uprotocol.h','executer/user/rust/mcexec_helpers.rs','executer/user/mcexec.c']
 for name in names:
  p=out/'original-inputs'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,p)
 record['inputs']=[identity(out/'original-inputs'/name) for name in names]
 for source,target in [(names[0],'mcctrl_process.rs'),(names[1],'application-image.rs'),(names[2],'application-abi.rs'),(names[3],'fixture.rs')]:
  shutil.copyfile(out/'original-inputs'/source,out/target)
 run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(out/'mcctrl_process.rs'),str(out/'fixture.rs')])
 data=(out/'mcctrl_process.rs').read_text();m=re.search(r'^    fn transfer_image\(',data,re.M);assert m
 start=m.start();end=data.index('{',start)+1;depth=1
 while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
 body=data[start:end];record['extracted_bodies'].append(dict(source=identity(out/'mcctrl_process.rs'),name='Registration::transfer_image',start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
 (out/'transfer-method.rs').write_text('impl Registration {\n'+body+'\n}\n')
 run('rust-build',['rustc','--edition','2021','-D','warnings','--test',str(out/'fixture.rs'),'-o',str(out/'adapter-tests')])
 run('rust-tests',[str(out/'adapter-tests'),'--nocapture'])
 record['compiler_inputs']=[identity(p) for p in sorted(out.glob('*.rs'))]
 for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
 record['test_summary']=[line for line in (out/'rust-tests.log').read_text().splitlines() if line.startswith('test result:')];record['status']='PASS'
except BaseException as error:
 record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
