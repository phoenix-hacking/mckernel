impl Registration {
    fn transfer_image(&self, argument: usize, compat: bool) -> Result<isize> {
        let mirror = self.mapping.lock().clone().ok_or(EINVAL)?;
        mirror.current()?;
        let mut descriptor = [0; 32];
        let length = if compat { 16 } else { 32 };
        UserSlice::new(argument, length)
            .reader()
            .read_slice(&mut descriptor[..length])?;
        let (physical, user, size, direction) = if compat {
            (
                u32::from_le_bytes(descriptor[0..4].try_into().unwrap()) as u64,
                u32::from_le_bytes(descriptor[4..8].try_into().unwrap()) as usize,
                u32::from_le_bytes(descriptor[8..12].try_into().unwrap()) as usize,
                descriptor[12],
            )
        } else {
            (
                image::word(&descriptor, 0).map_err(errno)?,
                image::word(&descriptor, 8).map_err(errno)? as usize,
                image::word(&descriptor, 16).map_err(errno)? as usize,
                descriptor[24],
            )
        };
        if size == 0 || size > image::MAX_FLAT_BYTES || direction > 1 {
            return Err(EINVAL);
        }
        user.checked_add(size).ok_or(errno(-75))?;
        physical.checked_add(size as u64).ok_or(errno(-75))?;
        let identity = ProcessId::thread()?;
        let worker = self
            .workers
            .lock()
            .iter()
            .find(|worker| worker.identity.same(&identity))
            .cloned();
        let delivery = worker
            .as_ref()
            .map_or(0, |worker| worker.delivery.load(Ordering::Acquire));
        let running = delivery != 0;
        let prefix = if running { 32 } else { 16 };
        let mut bytes = zero_bytes(prefix + size)?;
        if running {
            let worker = worker.as_ref().ok_or(EINVAL)?;
            worker.mirror.current()?;
            image::put_word(&mut bytes, 0, worker.handle).map_err(errno)?;
            image::put_word(&mut bytes, 8, delivery).map_err(errno)?;
        }
        image::put_word(&mut bytes, prefix - 16, physical).map_err(errno)?;
        image::put_word(&mut bytes, prefix - 8, direction as u64).map_err(errno)?;
        if direction == 0 {
            UserSlice::new(user, size)
                .reader()
                .read_slice(&mut bytes[prefix..])?;
        }
        let command = if running {
            super::application_abi::TID_TRANSFER
        } else {
            super::application_abi::TRANSFER
        };
        self.invoke(command, &mut bytes)?;
        if direction == 1 {
            UserSlice::new(user, size)
                .writer()
                .write_slice(&bytes[prefix..])?;
        }
        Ok(0)
    }
}
