impl Runtime {
    fn fail(&self, error: Error) {
        if self.application.fail_service(&self.error, error) {
            pr_err!("IHK-SMP: continuing service error os={} generation={} errno={}; workers and all started owners retained\n",
                self.owner.slot(), self.owner.generation(), error.to_errno());
        }
    }
    fn pump(&self) {
        self.procfs.advance();
        // A failure in one service must not prevent callback replies or
        // already-published exchanges from draining in the other service.
        // Handle each result before invoking the next service. An array of
        // Results would eagerly publish later work before recording failure.
        if let Err(error) = self.pump_master() {
            self.fail(error);
        }
        if let Err(error) = self.pump_regular() {
            self.fail(error);
        }
        if let Err(error) = self.publish_remote() {
            self.fail(error);
        }
        if let Err(error) = self.publish_applications() {
            self.fail(error);
        }
        if let Err(error) = self.publish_syscalls() {
            self.fail(error);
        }
        if let Err(error) = self.application.advance() {
            self.fail(error);
        }
        if let Err(error) = self.publish_procfs() {
            self.fail(error);
        }
    }
}
