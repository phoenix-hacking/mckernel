import importlib.util, json, tempfile, unittest
from pathlib import Path

HERE = Path(__file__).parent / "fixtures/application-collector-v1/linux-sealed-v1/adverse-v1"
def load(name):
    spec=importlib.util.spec_from_file_location(name, HERE/(name+".py")); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
prepare=load("prepare"); oracle=load("oracle")

class AdversePacketTests(unittest.TestCase):
    def test_packet_is_non_acceptance_and_cases_are_exact(self):
        packet=json.loads((HERE/"packet.json").read_text())
        self.assertEqual(packet["status"], "SOURCE_PACKET_ONLY")
        self.assertFalse(packet["application_acceptance"]); self.assertFalse(packet["backend_enabled"])
        self.assertEqual([x["id"] for x in packet["cases"]], ["missing-setup", "partial-setup", "interrupt-completed-wait"])
        self.assertEqual([x["setup_length"] for x in packet["cases"]], [0, 383, 384])

    def test_generation_has_unique_guarded_sites(self):
        source=prepare.SOURCE.read_bytes(); generated=prepare.generate(source).decode()
        self.assertEqual(generated.count('#include "inject.h"'), 1)
        self.assertEqual(generated.count("m02_adverse_child_boundary(setup_fd, words);"), 1)
        self.assertEqual(generated.count("m02_adverse_completed_wait_hook"), 2) # declaration + call
        self.assertIn("#define M02_ADVERSE_TEST_ONLY 1", generated)
        self.assertIn("m02_adverse_caught != SIGTERM", (HERE/"inject.h").read_text())

    def test_prepare_writes_fresh_source_bound_record(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/"attempt"
            import sys
            old=sys.argv; sys.argv=["prepare.py","--packet",str(HERE/"packet.json"),"--attempt-root",str(out)]
            try: prepare.main()
            finally: sys.argv=old
            record=json.loads((out/"prepare.json").read_text())
            self.assertEqual(record["status"], "PREPARED_NOT_EXECUTED")
            self.assertEqual(record["source"]["sha256"], prepare.EXPECTED_SOURCE)
            self.assertTrue((out/"generated.diff").read_bytes())

    def test_oracle_rejects_misleading_completed_and_wrong_lengths(self):
        base={"status":"SETUP_ERROR","failure":"setup-pipe-incomplete","failure_errno":"EPROTO","setup_length":0,"cleanup_complete":True,"all_pipes_eof":True,"ready":False,"validated":False,"raw_wait_status":0,"post_exec_observed":False,"boundary_witness":True}
        self.assertTrue(oracle.validate(base,"missing-setup"))
        bad=dict(base); bad["status"]="COMPLETED"; self.assertFalse(oracle.validate(bad,"missing-setup"))
        bad=dict(base); bad["setup_length"]=383; self.assertFalse(oracle.validate(bad,"missing-setup"))

    def test_oracle_requires_signal_and_boundary(self):
        value={"status":"INTERRUPTED","failure":"collector-interrupted","failure_errno":"EINTR","setup_length":384,"cleanup_complete":True,"all_pipes_eof":True,"ready":False,"validated":False,"raw_wait_status":0,"signal":15,"boundary_witness":True}
        self.assertTrue(oracle.validate(value,"interrupt-completed-wait"))
        value["signal"]=9; self.assertFalse(oracle.validate(value,"interrupt-completed-wait"))

if __name__ == "__main__": unittest.main()
