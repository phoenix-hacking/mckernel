#!/usr/bin/env python3
"""Runtime interface placeholder. Execution is intentionally dispatcher-owned."""
import argparse, json
def main():
    p=argparse.ArgumentParser(); p.add_argument("--case", choices=("control","missing-setup","partial-setup","interrupt-completed-wait"), required=True); p.add_argument("--attempt-root", required=True); p.add_argument("--prepared", required=True); a=p.parse_args()
    raise RuntimeError("adverse-v1 runtime requires reviewed root orchestrator; packet is source-only")
if __name__ == "__main__": main()
