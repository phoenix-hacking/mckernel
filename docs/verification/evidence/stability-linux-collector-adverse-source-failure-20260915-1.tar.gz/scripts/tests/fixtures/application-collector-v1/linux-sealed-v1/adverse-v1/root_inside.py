#!/usr/bin/env python3
"""Adverse container entrypoint is not executable until a reviewed root packet."""
raise RuntimeError("adverse-v1 root entrypoint is source-only")
