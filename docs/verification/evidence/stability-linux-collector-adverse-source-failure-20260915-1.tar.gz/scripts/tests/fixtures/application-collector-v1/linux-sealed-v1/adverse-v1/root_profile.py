#!/usr/bin/env python3
"""Describe the separate adverse root profile; never select the released profile."""
import argparse, json
def main():
    p=argparse.ArgumentParser(); p.add_argument("--packet", required=True); p.add_argument("--attempt-root", required=True); a=p.parse_args()
    raise RuntimeError("root profile preparation is dispatcher-owned and not enabled by source packet")
if __name__ == "__main__": main()
