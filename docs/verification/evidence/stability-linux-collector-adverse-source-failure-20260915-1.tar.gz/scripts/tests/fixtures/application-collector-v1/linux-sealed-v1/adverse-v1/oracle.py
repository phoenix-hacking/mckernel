#!/usr/bin/env python3
"""Independent oracle for adverse-v1 records; never imports collector code."""
import json, os

EXPECTED = {"missing-setup": (0, "SETUP_ERROR", "setup-pipe-incomplete", "EPROTO"), "partial-setup": (383, "SETUP_ERROR", "setup-pipe-incomplete", "EPROTO"), "interrupt-completed-wait": (384, "INTERRUPTED", "collector-interrupted", "EINTR")}

def validate(record, case):
    if case not in EXPECTED: raise ValueError("unknown case")
    length, status, failure, error = EXPECTED[case]
    if record.get("status") != status or record.get("failure") != failure or record.get("failure_errno") != error: return False
    if record.get("setup_length") != length or record.get("cleanup_complete") is not True: return False
    if record.get("all_pipes_eof") is not True or record.get("ready") is not False or record.get("validated") is not False: return False
    raw = record.get("raw_wait_status")
    if type(raw) is not int or raw != 0: return False
    if case == "interrupt-completed-wait": return record.get("signal") == 15 and record.get("boundary_witness") is True
    return record.get("post_exec_observed") is False and record.get("boundary_witness") is True

def main():
    import argparse
    p = argparse.ArgumentParser(); p.add_argument("--record", required=True); p.add_argument("--case", required=True)
    a = p.parse_args(); value = json.load(open(a.record, encoding="utf-8")); print("PASS" if validate(value, a.case) else "FAIL")
    raise SystemExit(0 if validate(value, a.case) else 1)
if __name__ == "__main__": main()
