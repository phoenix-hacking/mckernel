#!/usr/bin/env python3
"""Record a bounded build plan; compilation remains dispatcher-owned."""
import argparse, hashlib, json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(); p.add_argument("--packet", type=Path, required=True); p.add_argument("--attempt-root", type=Path, required=True); a=p.parse_args()
    if a.attempt_root.exists(): raise ValueError("fresh build attempt required")
    packet=json.loads(a.packet.read_text()); a.attempt_root.mkdir(mode=0o700, parents=False)
    record={"schema_version":1,"kind":"linux-sealed-collector-adverse-build-plan","status":"PREPARED_NOT_EXECUTED","application_acceptance":False,"backend_enabled":False,"packet_sha256":hashlib.sha256(a.packet.read_bytes()).hexdigest(),"compiler":{"language":"c11","flags":["-D_GNU_SOURCE","-Wall","-Wextra","-Werror"],"objects":["request.c","sha256.c","collector.c","adverse-collector.c"]},"cases":packet["cases"]}
    (a.attempt_root/"build-record.json").write_text(json.dumps(record,indent=2,sort_keys=True)+"\n")
if __name__ == "__main__": main()
