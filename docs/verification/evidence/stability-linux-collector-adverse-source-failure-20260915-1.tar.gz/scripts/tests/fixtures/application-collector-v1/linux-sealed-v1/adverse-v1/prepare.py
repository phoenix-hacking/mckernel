#!/usr/bin/env python3
"""Prepare hash-bound, separately named adverse collector sources; never build/run."""
import argparse, difflib, hashlib, json, os, stat
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[5]
SOURCE = REPO / "scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/collector.c"
EXPECTED_SOURCE = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
CASES = {"control": 0, "missing-setup": 1, "partial-setup": 2, "interrupt-completed-wait": 3}

def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(path):
    return json.loads(path.read_text(encoding="utf-8"))
def atomic_new(path, raw, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, mode)
    try:
        view = memoryview(raw)
        while view:
            n = os.write(fd, view)
            if n <= 0: raise OSError("short write")
            view = view[n:]
        os.fsync(fd)
    finally: os.close(fd)

def generate(source):
    if digest(source) != EXPECTED_SOURCE: raise ValueError("released collector source SHA mismatch")
    text = source.decode("utf-8")
    include = '#include "inject.h"\n'
    if text.count("    setup_packet(setup_fd, words);\n") != 1: raise ValueError("setup anchor is not unique")
    if text.count("        pump(); observe_exec(); check_leader();\n") != 1: raise ValueError("leader anchor is not unique")
    if text.count("#include <unistd.h>\n") != 1: raise ValueError("include anchor is not unique")
    text = text.replace("#include <unistd.h>\n", "#include <unistd.h>\n#define M02_ADVERSE_TEST_ONLY 1\n#include \"inject.h\"\n", 1)
    text = text.replace("    setup_packet(setup_fd, words);\n", "    m02_adverse_child_boundary(setup_fd, words);\n    setup_packet(setup_fd, words);\n", 1)
    text = text.replace("        pump(); observe_exec(); check_leader();\n", "        pump(); observe_exec(); check_leader();\n        if (m02_adverse_completed_wait_hook(leader_waitable, completion_observed, process_deadline, failure) < 0)\n            fail(\"COLLECTOR_ERROR\", \"adverse-hook\", errno ? errno : EIO);\n", 1)
    return text.encode()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--packet", type=Path, required=True)
    ap.add_argument("--attempt-root", type=Path, required=True)
    args = ap.parse_args()
    packet = load(args.packet)
    if packet.get("schema_version") != 1 or packet.get("kind") != "linux-sealed-collector-adverse-v1": raise ValueError("packet kind")
    if packet.get("application_acceptance") or packet.get("backend_enabled"): raise ValueError("acceptance flags")
    if not args.attempt_root.is_absolute() or args.attempt_root.exists(): raise ValueError("fresh absolute attempt root required")
    source = SOURCE.read_bytes(); generated = generate(source)
    out = args.attempt_root; out.mkdir(mode=0o700, parents=False)
    atomic_new(out / "source.collector.c", source)
    atomic_new(out / "inject.h", (HERE / "inject.h").read_bytes())
    atomic_new(out / "collector.patch", (HERE / "collector.patch").read_bytes())
    diff = "".join(difflib.unified_diff(source.decode().splitlines(True), generated.decode().splitlines(True), fromfile="collector.c", tofile="adverse-collector.c"))
    atomic_new(out / "generated.diff", diff.encode())
    record = {"schema_version": 1, "kind": "linux-sealed-collector-adverse-preparation", "status": "PREPARED_NOT_EXECUTED", "application_acceptance": False, "backend_enabled": False, "source": {"path": str(SOURCE), "sha256": digest(source)}, "generated": {"path": str(out / "adverse-collector.c"), "sha256": digest(generated), "diff_sha256": digest(diff.encode()), "include_count": generated.count('#include "inject.h"'), "guard_count": generated.count("M02_ADVERSE_TEST_ONLY")}, "cases": CASES, "runtime_root": str(out)}
    atomic_new(out / "prepare.json", (json.dumps(record, indent=2, sort_keys=True) + "\n").encode())
    atomic_new(out / "adverse-collector.c", generated, 0o644)
    print(json.dumps(record, sort_keys=True))

if __name__ == "__main__": main()
