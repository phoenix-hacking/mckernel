"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-zeroing-retained-20260909-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-zeroing-checkpoint-20260909.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Native guest atomic batch ownership and shared one-way geometry, exact legacy C oracle, original failed attempts. Native host zeroing service, image compilation and actual guest execution pending.',artifacts=[],captures=[],source_bindings=[],application_readiness_complete=False,actual_guest_pass=False,zeroing_service_integrated=False,guest_images_built=False,full_capture_retention_pending=False)
try:
    shutil.copyfile(__file__,out/'helper.py')
    for attempt,expected in [(1,'FAIL'),(2,'FAIL'),(3,'FAIL'),(4,'PASS')]:
        directory=work/('native-application-zeroing-protocol-20260909-'+str(attempt));state=json.loads((directory/'record.json').read_text());assert state['status']==expected
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        artifact(directory,directory.name+'.tar.gz',True)
        artifact(directory/'record.json',directory.name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),original_status=expected,complete_capture_retained=True,record=identity(directory/'record.json')))
    directory=work/'native-application-zeroing-protocol-20260909-4';state=json.loads((directory/'record.json').read_text())
    formatted={'host-kernel/native-rust/zero_pages.rs':'zero_pages.rs','scripts/tests/fixtures/native-application-zeroing.rs':'native-application-zeroing.rs'}
    copied={'kernel/rust/abi.rs':'abi.rs','kernel/rust/llist.rs':'llist.rs','host-kernel/native-rust/application_rpc.rs':'application_rpc.rs','host-kernel/native-rust/application_syscall.rs':'application_syscall.rs'}
    for row in state['inputs']:
        saved=Path(row['path']);relative=saved.relative_to(directory/'original-inputs');key=str(relative)
        current=repo/relative
        if key in formatted or key in copied:
            compiled=directory/(formatted|copied)[key]
            item=binding(current,compiled)
            if key in formatted:item['formatter_original']=identity(saved)
        else:
            item=binding(current,saved)
            item['binding']='identical original source for exact extraction or build-selection review; full guest image compilation pending'
        record['source_bindings'].append(item)
    assert len(record['source_bindings'])==21
    record['test_summaries']=state['test_summaries']
    record['extracted_bodies']=state['extracted_bodies']
    artifact(out/'helper.py','native-application-zeroing-retention-helper-20260909-1.py.gz')
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],manifest,flush=True)
