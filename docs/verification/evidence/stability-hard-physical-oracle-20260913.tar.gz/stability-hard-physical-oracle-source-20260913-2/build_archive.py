from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/holden/mckernel')
ORIGINAL = Path('/tmp/stability-hard-physical-oracle-source-20260913-1')
FINAL = Path('/tmp/stability-hard-physical-oracle-source-20260913-2')
PEER = Path('/tmp/stability-physical-ack-independent-review-20260913-46ogngi1')
OUTPUT = ROOT / 'docs/verification/stability-hard-physical-oracle-20260913.json'
ARCHIVE = ROOT / 'docs/verification/evidence/stability-hard-physical-oracle-20260913.tar.gz'

def identity(path, raw=None):
    raw = path.read_bytes() if raw is None else raw
    return {'path': str(path), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

if OUTPUT.exists() or ARCHIVE.exists():
    raise RuntimeError('immutable destination already exists')
inputs = json.loads((FINAL / 'inputs.json').read_text())
for item in inputs['source_inputs']:
    current = identity(ROOT / item['path'])
    if (current['size'], current['sha256']) != (item['size'], item['sha256']):
        raise RuntimeError('reviewed input changed: ' + item['path'])
peer_record = PEER / 'review.json'
if identity(peer_record)['sha256'] != '24a0ce45cda1faf63490175b8e90c25c8273f860e564f08511cdf0bcc3ff0d09':
    raise RuntimeError('independent source review changed')
files = {}
for directory in (ORIGINAL, FINAL, PEER):
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            files[directory.name + '/' + str(path.relative_to(directory))] = (path, path.read_bytes())
queue_c = ROOT / 'ihk/ikc/include/ikc/queue.h'
files['additional-sources/ihk/ikc/include/ikc/queue.h'] = (queue_c, queue_c.read_bytes())
members = []
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, (path, raw) in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
                members.append({'member': name, 'original_identity': identity(path, raw)})
record = {
    'schema_version': 1,
    'record_kind': 'hard_fault_physical_oracle_source_review',
    'status': 'INDEPENDENT_SOURCE_REVIEW_ONLY_NOT_EXECUTED_OR_TESTED',
    'application_acceptance': False,
    'production_gate_credit': False,
    'physical_capture_gate_credit': False,
    'parser_imported_or_executed': False,
    'tests_run': [],
    'runtime_observations_used_to_derive_expected_constants': [],
    'helper': identity(ROOT / 'scripts/application-tests/physical_observations.py'),
    'derivation': identity(ROOT / 'docs/verification/stability-hard-physical-oracle-20260913.md'),
    'independent_review': identity(peer_record),
    'source_inputs': inputs['source_inputs'],
    'additional_c_queue_header': identity(queue_c),
    'compiled_producer_inputs': inputs['compiled_producer_inputs'],
    'original_and_final_source_captures': [str(ORIGINAL), str(FINAL)],
    'response_prefix_contract': {
        'bytes': 40, 'configured_guest_struct_bytes': 48, 'guest_pde_data_offset40_observed': False,
        'blocked_status': 0, 'blocked_wake_state': 2,
        'writes': [{'begin': 4, 'end': 8, 'value': 'original selected Linux worker TID'},
                   {'begin': 16, 'end': 24, 'value': 1}, {'begin': 24, 'end': 32, 'value': 16}],
        'preserved_spans': [[0, 4], [8, 16], [32, 40]],
        'terminal_plus_five': 'Both must equal the source-derived prepared prefix byte-for-byte.',
        'response_ttid_policy': 'Uninitialized by the actual do_syscall/offload_prepare/send_prepare path; preserve original bytes without asserting guest requester equality.',
        'accepted_return_physical_snapshot_observed': False,
    },
    'ring_contract': {
        'queue_bytes': 16384, 'header_bytes': 64, 'packet_bytes': 128, 'packet_count': 127,
        'payload_bytes': 16256, 'trailing_unused_bytes': 64,
        'request_port': 503, 'request_direction': 'host_receive', 'request_message': 4,
        'wake_port': 501, 'wake_direction': 'host_send', 'wake_message': 20, 'wake_requester_offset': 24,
        'consumed_retained_sequences': 'max(0, reserved - 127) <= sequence < read',
        'packet_offset': '64 + (sequence % 127) * 128',
        'new_publications': 'before.published <= sequence < after.published; every sequence must remain in after retention window',
        'maximum_sequences_scanned_per_comparison': 127,
        'full_distance126_is_legal': True,
        'physical_full_ring_proved': False,
    },
    'source_review_correction': 'Clarified counter saturation versus legal physically full queue; no executable change from final reviewed helper.',
    'required_before_runtime_use': [
        'Focused independent positive and negative tests for exact field offsets and response preservation.',
        'Boundary tests for retained consumed windows, overwritten/reused slot exclusion, duplicate matches, legal full queues, malformed headers and counter wrap/saturation.',
        'New-wake publication tests for retained interval endpoints and overwritten-gap refusal.',
        'Strict caller request types and u64 response-span overflow tests.',
    ],
    'required_separate_runtime_evidence': [
        'Exact kernel/image/module/overlay and native selection/Request bindings.',
        'Correct queue physical addresses, direction, guest CPU and generation.',
        'Stopped QMP captures, raw bytes and verified resume.',
        'Retained original response owner and zero publication/release at every physical read; never reread after release.',
        'Native AcceptedReturn/Terminal/quiet phase sequencing and five-second timing.',
        'Actual callback, notification, RET, launcher/controller/UART and guest provenance.',
        'Physical AcceptedReturn/prepublication capture remains a separate gate; this helper cannot create it.',
    ],
    'archive': identity(ARCHIVE),
    'archive_members': members,
}
OUTPUT.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps({'record': identity(OUTPUT), 'archive': identity(ARCHIVE), 'members': len(members)}, indent=2))
