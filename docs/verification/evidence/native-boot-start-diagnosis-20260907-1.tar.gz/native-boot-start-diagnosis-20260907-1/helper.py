from pathlib import Path
import hashlib, json, os, re, struct, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
source = Path('/work/native-boot-guest-20260907-start-x86_64-1')
out = Path('/work/native-boot-start-diagnosis-20260907-1'); out.mkdir()
(out / 'helper.py').write_bytes(Path(__file__).read_bytes())
data = (source / 'capture-0/kmsg.bin').read_bytes()
lock, tail, length, head = struct.unpack_from('<4I', data)
assert length == len(data) - 4096 and 0 <= head < length and 0 <= tail < length
body = data[4096:]
message = body[head:tail] if tail >= head else body[head:] + body[:tail]
(out / 'kmsg.txt').write_bytes(message)
params = (source / 'capture-0/params.bin').read_bytes()
low = (source / 'capture-0/trampoline.bin').read_bytes()
regs = (source / 'capture-0/registers.txt').read_text()
ap = regs.split('CPU#1\n')[1].split('CPU#2\n')[0]
ip = int(re.search(r'RIP=([0-9a-f]+)', ap)[1], 16)
image = Path('/work/mckernel-native-irq-images-20260907-10/native-rust/kernel/mckernel.img')
commands = [ ['addr2line', '-e', str(image), '-f', '-C', hex(ip)], ['objdump', '-d', '--start-address=' + hex(ip - 40), '--stop-address=' + hex(ip + 80), str(image)]]
for index, command in enumerate(commands):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
    (out / ('symbol-' + str(index) + '.txt')).write_bytes(result.stdout)
record = dict(status=struct.unpack_from('<Q', params, 16)[0], kmsg_head=head, kmsg_tail=tail,
              kmsg_sha256=hashlib.sha256(message).hexdigest(), ap_instruction_pointer=hex(ip),
              low_header=[hex(value) for value in struct.unpack_from('<4Q', low, 8)],
              bootstrap_end=hex(struct.unpack_from('<Q', params, 32)[0]),
              startup_page_all_zero=not any((source / 'capture-0/startup.bin').read_bytes()),
              production_gate_credit=False, original_guest_status='FAIL')
(out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print((out / 'symbol-0.txt').read_text())
print(message.decode(errors='replace')[-6000:])
