import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path('/home/holden/mckernel-work/scratch/stability-application-preflight-tests-20260913-1')
WIRE_ROOT = '/work/stability-application-preflight-tests-20260913-1/'
OUT = Path(__file__).parent
EXPECTED = {
    'test_eligible_metadata_still_blocks_and_retains_exact_original_graph': ['BLOCKED'],
    'test_existing_or_symlinked_attempt_never_overwrites': [],
    'test_fifo_symlink_and_nonregular_inputs_fail_without_open_wait': ['FAIL'] * 3,
    'test_malformed_bundle_bytes_are_retained_before_json_rejection': ['FAIL'] * 4,
    'test_missing_blocked_unsupported_and_disabled_capabilities_never_release': ['BLOCKED'] * 4,
    'test_planned_cli_returns_blocked_and_has_no_execution_switch': ['BLOCKED'],
    'test_repeated_references_count_toward_work_bound': ['FAIL'],
    'test_retention_count_and_aggregate_bounds_fail_explicitly': ['FAIL'] * 2,
    'test_source_stale_capability_and_increased_limit_fail': ['FAIL'] * 2,
    'test_stale_payload_and_changed_after_loader_fail_closed': ['FAIL'] * 2,
    'test_temporary_original_bundle_swap_cannot_replace_captured_metadata': ['BLOCKED'],
    'test_unselected_case_and_unsupported_oracle_stay_blocked': ['BLOCKED'] * 2,
}


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())


def local(path):
    assert path.startswith(WIRE_ROOT), path
    relative = path[len(WIRE_ROOT):]
    assert '..' not in Path(relative).parts
    return ROOT / relative


def verify(reference):
    path = local(reference['path'])
    actual = identity(path)
    assert (actual['size'], actual['sha256']) == (reference['size'], reference['sha256'])
    return path


def retain(path):
    target = OUT / 'retained' / path.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    assert target.read_bytes() == path.read_bytes()
    return identity(path)


record = json.loads((ROOT / 'record.json').read_bytes())
assert record['status'] == 'PASS_METADATA_PREFLIGHT_TESTS_ONLY' and record['cases'] == 12
collector = record['collection']
assert collector['status'] == 'COMPLETED' and type(collector['raw_wait_status']) is int and collector['raw_wait_status'] == 0
assert collector['cleanup_complete'] is True and collector['descendants'] == []
assert collector['payload_monotonic_started'] <= collector['payload_completion_observed_monotonic'] <= collector['payload_monotonic_deadline']
sources = [retain(verify(row['retained'])) for row in record['inputs']]
streams = {}
for name, stream in collector['streams'].items():
    path = verify(stream['artifact'])
    assert stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes'] == 0
    assert stream['bytes_observed'] == stream['bytes_retained'] == path.stat().st_size
    streams[name] = retain(path)
stderr = (ROOT / 'collection/stderr.bin').read_text()
assert 'Ran 12 tests in 1.518s' in stderr and stderr.rstrip().endswith('OK')
rows = re.findall(r'^RETAINED_APPLICATION_PREFLIGHT __main__\.PreflightTests\.(\S+) (\S+)$',
                  (ROOT / 'collection/stdout.bin').read_text(), re.M)
assert len(rows) == 12 and {name for name, _ in rows} == set(EXPECTED)
cases = []
artifact_checks = 0
for name, source in rows:
    directory = local(source)
    reports = sorted(directory.rglob('report.json'))
    observed = []
    captures = []
    for path in reports:
        report = json.loads(path.read_bytes())
        observed.append(report['status'])
        assert report['execution_status'] == 'NOT_RUN' and report['backend_implemented'] is False
        for flag in ('application_acceptance', 'transport_acceptance', 'production_gate_credit'):
            assert report[flag] is False
        index_path = verify(report['retention_index'])
        index = json.loads(index_path.read_bytes())
        for item in index['entries']:
            if 'retained' in item:
                verify(item['retained'])
                artifact_checks += 1
        captures.append(dict(report=retain(path), retention_index=retain(index_path),
                             status=report['status'], metadata=report['metadata'], reasons=report['reasons']))
    assert observed == EXPECTED[name], (name, observed)
    if name == 'test_existing_or_symlinked_attempt_never_overwrites':
        assert (directory / 'existing/marker').read_bytes() == b'original attempt must remain unchanged\n'
        assert [p.name for p in (directory / 'existing').iterdir()] == ['marker']
    if name == 'test_temporary_original_bundle_swap_cannot_replace_captured_metadata':
        assert captures[0]['metadata']['status'] == 'BLOCKED'
        assert 'runtime-transport-fault-injection' in str(captures[0]['metadata']['reasons'])
    cases.append(dict(test=name, directory=source, reports=captures))
result = dict(schema_version=1, status='PASS_RETAINED_METADATA_TEST_EVIDENCE_ONLY',
              parent_record=retain(ROOT / 'record.json'), parent_helper=retain(ROOT / 'helper.py'),
              sources=sources, streams=streams, test_methods=12, retained_reports=23,
              retained_artifact_hash_checks=artifact_checks, cases=cases,
              parent_collector_raw_wait=0, parent_collector_elapsed_seconds=collector['elapsed_seconds'],
              parent_unittest_seconds=1.518, reviewer_test_execution=False, guest_execution=False,
              application_acceptance=False, transport_acceptance=False, production_gate_credit=False)
(OUT / 'inspection.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(identity(OUT / 'inspection.json'), sort_keys=True))
print('actual cases=12 reports=23 retained-artifact-hashes=%d' % artifact_checks)
