"""Sequential post-guest checks; stop and retain the first failure."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

commands = [
    ['python3', '/work/check-native-os-resource-exact-modules.py'],
    ['python3', '/work/inventory-rust-consumers-os-resource-20260907.py'],
    ['python3', '/work/run-native-os-resource-binding-tests.py', '1',
     'scripts.tests.test_rs006_miscdevice_module_owner_followup',
     'scripts.tests.test_fp0006_ihk_os_status_alias',
     'scripts.tests.test_fp0006_ihk_device_negative_dispatch',
     'scripts.tests.test_rocky_kernel_license_inventory'],
]
out = Path('/work/native-os-resource-post-guest-20260907.json')
if out.exists():
    raise SystemExit('Refusing to replace a prior run')
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[])
for command in commands:
    result = subprocess.run(command)
    record['results'].append(dict(command=command, exit_code=result.returncode))
    if result.returncode:
        break
record.update(finished_utc=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode)
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
raise SystemExit(result.returncode)
