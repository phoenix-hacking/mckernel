from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
compiled = Path('/work/native-irq-work-module-20260907-' + sys.argv[1])
out = Path('/work/native-irq-work-guest-20260907-' + sys.argv[2])
mode = sys.argv[3]
assert mode in ('default', 'poll')
kernel = Path('/work/native-startup-exact-stage-20260907-1')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
compiled_record = json.loads((compiled / 'record.json').read_text())
assert compiled_record['status'] == 'PASS'
for item in compiled_record['outputs'] + compiled_record['inputs']:
    assert identity(Path(item['path'])) == item
config = (kernel / 'resolved.config').read_text()
for required in ['CONFIG_IRQ_WORK=y\n', 'CONFIG_X86_LOCAL_APIC=y\n', 'CONFIG_MODULE_UNLOAD=y\n', '# CONFIG_PREEMPT_RT is not set\n']:
    assert required in config, required
assert (compiled / 'config').read_text() == config
out.mkdir()
shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), out / 'root')
shutil.copyfile(repo / 'scripts/native-irq-work-init.sh', out / 'root/init')
(out / 'root/init').chmod(0o755)
shutil.copyfile(compiled / 'mckernel_irq_work_verify.ko', out / 'root/modules/mckernel_irq_work_verify.ko')
shutil.copyfile(__file__, out / 'run-helper.py')
subprocess.run(['bash', '-n', str(out / 'root/init')], check=True)
environment = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(out / 'root'))
subprocess.run(['python3', '-B', '/work/write-native-cpio-spec.py'], env=environment, check=True)
with (out / 'initramfs.cpio.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
        process = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
        shutil.copyfileobj(process.stdout, output)
        process.stdout.close()
        assert process.wait() == 0
args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
        '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
        '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
        '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
        '-kernel', str(kernel / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
        '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1' + (' idle=poll' if mode == 'poll' else ''),
        '-display', 'none', '-monitor', 'none', '-serial', 'file:' + str(out / 'serial.log'), '-no-reboot', '-nic', 'none']
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', qemu_args=args,
              inputs=[identity(path) for path in [Path(__file__), out / 'initramfs.cpio.gz', kernel / 'bzImage', kernel / 'resolved.config', compiled / 'record.json', compiled / 'mckernel_irq_work_verify.ko']],
              cpus=4, numa_nodes=2, memory_mib=8192, container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)),
              production_gate_credit=False, mckernel_boot_proven=False, linux_idle=mode, transport='mock boot and guest context; actual Linux irq_work_queue and hardirq completion')
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
save()
try:
    with (out / 'qemu.log').open('wb') as log:
        result = subprocess.run(['/usr/bin/timeout', '--signal=TERM', '--kill-after=30s', '300'] + args, stdout=log, stderr=subprocess.STDOUT)
    record['qemu_exit_code'] = result.returncode
    assert result.returncode == 0, result.returncode
    serial = (out / 'serial.log').read_text(errors='replace')
    for marker in ['MCKERNEL_IRQ_WORK_GUEST PASS', 'MCKERNEL_IRQ_WORK_GUEST cycle=1 complete', 'MCKERNEL_IRQ_WORK_GUEST cycle=2 complete']:
        assert marker in serial, marker
    # dmesg echoes the console's earlier module messages; count exact half.
    passes = serial.count('MCKERNEL_IRQ_WORK_VERIFY PASS callbacks=512')
    unloads = serial.count('MCKERNEL_IRQ_WORK_VERIFY UNLOAD drained=1')
    assert passes == 4 and unloads == 4, (passes, unloads)
    for forbidden in ['MCKERNEL_IRQ_WORK_GUEST FAIL', 'Kernel panic', 'BUG:', 'WARNING:', 'Oops:', 'error:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
        assert forbidden not in serial, forbidden
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item
    record.update(status='PASS', module_cycles=2, callbacks=1024)
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
