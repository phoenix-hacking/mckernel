"""One-time stdlib-only source/contract bookkeeping; no project imports."""
import ast
import hashlib
import json
from pathlib import Path
import pprint

repo = Path('/home/holden/mckernel')
pending = {}
preimages = {}

def read(relative):
    if relative not in pending:
        pending[relative] = (repo / relative).read_text()
        preimages[relative] = pending[relative]
    return pending[relative]

def replace(relative, old, new):
    text = read(relative)
    assert text.count(old) == 1, (relative, old[:100], text.count(old))
    pending[relative] = text.replace(old, new, 1)

def node(relative, name):
    matches = [n for n in ast.parse(read(relative)).body if isinstance(n, ast.Assign)
               and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
               and n.targets[0].id == name]
    assert len(matches) == 1, (relative, name)
    return matches[0].value

def literal(relative, name):
    return ast.literal_eval(node(relative, name))

def set_literal(relative, name, value):
    old = ast.get_source_segment(read(relative), node(relative, name))
    replace(relative, name + ' = ' + old,
            name + ' = ' + pprint.pformat(value, width=100, sort_dicts=False))

def digest(relative):
    return hashlib.sha256((repo / relative).read_bytes()).hexdigest()

def rust_item(source, prefix, full=True):
    assert source.count(prefix) == 1, prefix
    start = source.index(prefix)
    if prefix.startswith('type '):
        return source[start:source.index(';', start) + 1]
    opening = source.index('{', start)
    if not full:
        return source[start:opening + 1]
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    if end < len(source) and source[end] == ';':
        end += 1
    return source[start:end]

def leading_comments(source, exact):
    start = source.index(exact)
    lines = source[:start].splitlines(keepends=True)
    comments = []
    while lines and lines[-1].lstrip().startswith('//'):
        comments.insert(0, lines.pop())
    return ''.join(comments)

smp = (repo / 'host-kernel/native-rust/ihk_smp_x86_64.rs').read_text()
runtime = (repo / 'host-kernel/native-rust/os_runtime.rs').read_text()
foreign = rust_item(smp, 'extern "C" {')
os_types = [rust_item(smp, 'type IhkSmpOsIoctlV2'), rust_item(smp, 'type IhkSmpOsReleaseV2')]
os_callbacks = [rust_item(smp, 'unsafe extern "C" fn ihk_smp_os_ioctl_v2'),
                rust_item(smp, 'unsafe extern "C" fn ihk_smp_os_release_v2')]
os_headers = [body[:body.index('{') + 1] for body in os_callbacks]
constructor = literal('scripts/tests/test_ihk_smp_resource.py', 'LEASE_CONSTRUCTOR')

# Pin the exact new FFI declarations, prefixes, placement and source order.
audit = 'scripts/native_rust_host_audit.py'
audit_node = node(audit, 'REVIEWED_RUST_ESCAPE_BLOCKS')
audit_dict = ast.literal_eval(audit_node)
smp_key = 'host-kernel/native-rust/ihk_smp_x86_64.rs'
old_tuple = audit_dict[smp_key]
new_tuple = []
prefixes = {}
new_labels = []
for label, exact in old_tuple:
    if label == 'IHK SMP provider and OS import':
        for new_label, new_exact in zip(('IHK SMP OS ioctl callback type', 'IHK SMP OS release callback type'), os_types):
            new_tuple.append((new_label, new_exact))
            prefixes[new_label] = leading_comments(smp, new_exact)
            new_labels.append(new_label)
        exact = foreign
    new_tuple.append((label, exact))
    if label == 'IHK SMP provider and OS import':
        for new_label, new_exact in zip(('IHK SMP OS ioctl callback ABI', 'IHK SMP OS release callback ABI'), os_headers):
            new_tuple.append((new_label, new_exact))
            prefixes[new_label] = leading_comments(smp, new_exact)
            new_labels.append(new_label)
for key_node, value_node in zip(audit_node.keys, audit_node.values):
    if ast.literal_eval(key_node) == smp_key:
        replace(audit, ast.get_source_segment(read(audit), value_node),
                pprint.pformat(tuple(new_tuple), width=100))
        break
runtime_target = "REVIEWED_RUST_ESCAPE_BLOCKS['host-kernel/native-rust/os_runtime.rs']"
runtime_node = next(n.value for n in ast.parse(read(audit)).body if isinstance(n, ast.Assign)
                    and ast.get_source_segment(read(audit), n.targets[0]) == runtime_target)
new_tuple = []
for label, exact in ast.literal_eval(runtime_node):
    if label == 'OS ioctl ABI':
        exact = exact.replace('_argument:', 'argument:')
    new_tuple.append((label, exact))
    additions = []
    if label == 'OS Linux kernel exports':
        additions = [('OS backend ioctl callback type', rust_item(runtime, 'type OsBackendIoctlV2')),
                     ('OS backend release callback type', rust_item(runtime, 'type OsBackendReleaseV2'))]
    elif label == 'OS create ABI':
        additions = [('OS create v2 ABI', rust_item(runtime, '#[export_name = "ihk_os_create_unbooted_v2"]', False))]
    elif label == 'OS ioctl ABI':
        additions = [('OS compat ioctl ABI', rust_item(runtime, '#[cfg(CONFIG_COMPAT)]\nunsafe extern "C" fn os_compat_ioctl', False))]
    elif label == 'OS create export record':
        additions = [('OS create v2 export record', rust_item(runtime, '#[export_name = "__export_symbol_ihk_os_create_unbooted_v2"]'))]
    for new_label, new_exact in additions:
        new_tuple.append((new_label, new_exact))
        prefixes[new_label] = leading_comments(runtime, new_exact)
        new_labels.append(new_label)
replace(audit, runtime_target + ' = ' + ast.get_source_segment(read(audit), runtime_node),
        runtime_target + ' = ' + pprint.pformat(tuple(new_tuple), width=100))
replace(audit, 'REVIEWED_RUST_BRACED_BLOCKS = frozenset(',
        'REVIEWED_RUST_BLOCK_PREFIXES.update(' + pprint.pformat(prefixes, width=100) + ')\n'
        'REVIEWED_RUST_OUTER_BLOCKS = REVIEWED_RUST_OUTER_BLOCKS | frozenset(' + repr(tuple(new_labels)) + ')\n\n'
        'REVIEWED_RUST_BRACED_BLOCKS = frozenset(')

# Keep the declared stage exact; no other unsafe/extern/import is accepted.
stager = 'scripts/rocky_rust_staging.py'
manifest_path = 'host-kernel/kbuild/stage-manifest.json'
manifest = json.loads(read(manifest_path))
for item in manifest['inputs'] + [module['source'] for module in manifest['modules']]:
    item['sha256'] = digest(item['repository_path'])
pending[manifest_path] = json.dumps(manifest, indent=2, sort_keys=True) + '\n'
set_literal(stager, 'EXPECTED_INPUTS', tuple(manifest['inputs']))
set_literal(stager, 'AUDITED_SMP_PROVIDER_EXTERN', foreign)
declarations = dict(zip(('AUDITED_SMP_OS_IOCTL_TYPE', 'AUDITED_SMP_OS_RELEASE_TYPE',
                         'AUDITED_SMP_OS_IOCTL_EXTERN', 'AUDITED_SMP_OS_RELEASE_EXTERN'), os_types + os_headers))
declarations['AUDITED_OS_LEASE_CONSTRUCTOR'] = constructor
replace(stager, 'AUDITED_SMP_INIT_CALLBACK_EXTERN = (',
        ''.join(name + ' = ' + repr(value) + '\n' for name, value in declarations.items())
        + '\nAUDITED_SMP_INIT_CALLBACK_EXTERN = (')
replace(stager, '            AUDITED_SMP_PROVIDER_EXTERN,\n',
        '            AUDITED_SMP_PROVIDER_EXTERN,\n'
        + ''.join('            ' + name + ',\n' for name in list(declarations)[:4]))
start = read(stager).index('    elif item["destination"] == "smp_resource.rs":')
end = read(stager).index('    elif item["destination"] == "smp_cpu.rs":', start)
block = read(stager)[start:end]
new_block = block.replace('        lowered = text.lower()',
    '        if text.count(AUDITED_OS_LEASE_CONSTRUCTOR) != 1:\n'
    '            raise ValidationError("{0} lacks the exact checked IHK lease constructor".format(label))\n'
    '        lowered = text.replace(AUDITED_OS_LEASE_CONSTRUCTOR, "", 1).lower()')
assert new_block != block
replace(stager, block, new_block)

# Publish an explicit unbooted OS resource bridge contract; boot credit stays false.
checker = 'scripts/ihk_smp_native_lifecycle_check.py'
contract_path = 'host-kernel/native-rust/ihk-smp-lifecycle-contract-v1.json'
contract = json.loads(read(contract_path))
for item in contract['crate_modules']:
    item['sha256'] = digest(item['path'])
resource = contract['resource_foundation']
resource['fixture'].update(expected_in_file_tests=37, expected_total_tests=51)
resource['fixture']['negative_sha256'] = digest(resource['fixture']['negative_path'])
resource['status'] = 'native-cpu-memory-adapters-with-versioned-ihk-os-resource-assignment'
resource['os_token_minting'] = 'explicit-unsafe-contract-requires-exact-ihk-v2-os-lease-or-destroy-guard-and-smp-module-owner'
resource['integration_blockers'] = [
    'OS resource assignment needs declared staging, exact-stage replay and production acceptance',
    'CPU physical eject, suspend, topology replacement and uncertain-state reconciliation need production acceptance',
    'IKC optional-versus-complete mapping compatibility is not selected at the ABI boundary',
    'image loading, APIC reset, IRQ and native McKernel boot remain unreachable',
]
control = contract['control_device_shell']
fixture = control['get_buildid']['source_fixture']
fixture.update(sha256=digest(fixture['path']), size=(repo / fixture['path']).stat().st_size)
control['scope'] = ('SMP-owned mcd0 with native/compat BUILDID, unbooted OS create/destroy with a '
                    'versioned resource callback pair, CPU reserve/release/count/query and memory '
                    'reserve/query/full/partial release; OS resource commands use mcosN; boot remains pending')
bridge = {
    'callback_abi': 1,
    'create_symbol': 'ihk_os_create_unbooted_v2',
    'compatibility_create_export': 'ihk_os_create_unbooted_v1',
    'ioctl_callback': 'ihk_smp_os_ioctl_v2',
    'release_callback': 'ihk_smp_os_release_v2',
    'node_family': '/dev/mcosN',
    'allowed_status': 'NotBooted',
    'authority': 'exact live IHK OsLease or exclusive DestroyGuard, never userspace identities',
    'callback_lifetime': 'OS-owned Linux SMP module reference',
    'serialization': 'per-OS sleepable mutex before CPU then memory controller locks',
    'compat_address': 'zero-extended once in IHK; reject out-of-range address or compat flag in SMP',
    'cpu_assignment': 'preserve requested logical rank; whole-batch ownership validation',
    'memory_assignment': 'reuse canonical MemoryMap and retained Linux allocation owners',
    'destroy': 'preflight CPU and memory before either commit; return to reserved pool before minor reuse',
    'commands': ['IHK_OS_ASSIGN_CPU', 'IHK_OS_RELEASE_CPU', 'IHK_OS_QUERY_CPU', 'IHK_OS_GET_NUM_CPUS',
                 'IHK_OS_ASSIGN_MEM', 'IHK_OS_RELEASE_MEM', 'IHK_OS_QUERY_MEM'],
    'source_reachable': True,
    'native_boot_proven': False,
    'credit_eligible': False,
    'tracker_credit': False,
}
contract['os_resource_bridge'] = bridge
pending[contract_path] = json.dumps(contract, indent=2, sort_keys=True) + '\n'
for name, key in (('EXPECTED_CRATE_MODULES', 'crate_modules'),
                  ('EXPECTED_RESOURCE_FOUNDATION', 'resource_foundation'),
                  ('EXPECTED_CONTROL_DEVICE_SHELL', 'control_device_shell')):
    set_literal(checker, name, contract[key])
set_literal(checker, 'EXPECTED_OS_REQUEST', rust_item(smp, 'fn control_device_request'))
replace(checker, 'class ValidationError(Exception):',
        'EXPECTED_OS_RESOURCE_BRIDGE = ' + pprint.pformat(bridge, width=100) + '\n'
        'EXPECTED_OS_CALLBACK_TYPES = ' + repr(tuple(os_types)) + '\n'
        'EXPECTED_OS_CALLBACK_HEADERS = ' + repr(tuple(os_headers)) + '\n'
        'EXPECTED_OS_CALLBACK_BODIES = ' + pprint.pformat(tuple(os_callbacks), width=100) + '\n'
        'EXPECTED_OS_LEASE_CONSTRUCTOR = ' + repr(constructor) + '\n\n'
        'class ValidationError(Exception):')
replace(checker, '            "resource_foundation",\n', '            "resource_foundation",\n            "os_resource_bridge",\n')
replace(checker, '    if contract["provider_lease"] != EXPECTED_PROVIDER_LEASE:',
        '    if contract["os_resource_bridge"] != EXPECTED_OS_RESOURCE_BRIDGE:\n'
        '        raise ValidationError("SMP OS resource bridge differs or overclaims readiness")\n'
        '    if contract["provider_lease"] != EXPECTED_PROVIDER_LEASE:')
replace(checker, 'return _provider_symbols(contract) + ("ihk_os_create_unbooted_v1", "ihk_os_destroy_unbooted_v1")',
        'return _provider_symbols(contract) + ("ihk_os_create_unbooted_v2", "ihk_os_destroy_unbooted_v1")')
old_import = '''        '    #[link_name = "ihk_os_create_unbooted_v1"]\\n'
        "    fn ihk_os_create_unbooted_v1(provider_minor: u32,\\n"
        "        owner: *mut core::ffi::c_void, argument: u64) -> i64;\\n"
'''
create_import = foreign[foreign.index('    #[link_name = "ihk_os_create_unbooted_v2"]'):foreign.index('    #[link_name = "ihk_os_destroy_unbooted_v1"]')]
replace(checker, old_import, ''.join('        ' + repr(line) + '\n' for line in create_import.splitlines(keepends=True)))
replace(checker, '            provider_import,\n            callback_init,',
        '            provider_import,\n            *EXPECTED_OS_CALLBACK_TYPES,\n'
        '            *EXPECTED_OS_CALLBACK_HEADERS,\n            callback_init,')
replace(checker, '    expected_status_adapter = ',
        '    for body in EXPECTED_OS_CALLBACK_BODIES:\n'
        '        _require_active_count(text, code, body, 1, "Rust exact checked OS resource callback")\n'
        '        _validate_top_level_item(code, _active_fragment_positions(text, code, body)[0],\n'
        '                                 "OS resource callback")\n\n'
        '    expected_status_adapter = ')
replace(checker, '    for forbidden in (\n        r"\\bunsafe\\b",',
        '    _require_active_count(production, masked_production, EXPECTED_OS_LEASE_CONSTRUCTOR, 1,\n'
        '                          "SMP exact checked IHK lease constructor")\n'
        '    constructor_start = _active_fragment_positions(\n'
        '        production, masked_production, EXPECTED_OS_LEASE_CONSTRUCTOR)[0]\n'
        '    masked_production = (masked_production[:constructor_start]\n'
        '                         + " " * len(EXPECTED_OS_LEASE_CONSTRUCTOR)\n'
        '                         + masked_production[constructor_start + len(EXPECTED_OS_LEASE_CONSTRUCTOR):])\n'
        '    for forbidden in (\n        r"\\bunsafe\\b",')
replace(checker, '        "fn forge_os_token() -> smp_resource::OsToken",',
        '        "fn forge_os_token() -> smp_resource::OsToken",\n        "fn lease_without_proof()",')
test = 'scripts/tests/test_ihk_smp_native_lifecycle_check.py'
replace(test, 'self.assertEqual(45, summary["resource_foundation_tests"])',
        'self.assertEqual(51, summary["resource_foundation_tests"])')

# IHK claims only the validated callback boundary; the separate SMP contract owns effects.
runtime_checker = 'scripts/ihk_os_runtime_check.py'
replace(runtime_checker, '"scope": "native unbooted create/status/destroy and Linux character-device ownership",',
        '"scope": "native unbooted lifecycle, Linux character-device ownership and checked SMP resource callbacks",')
replace(runtime_checker, '"destroy_order": ["exclude new opens", "remove node", "free kmsg", "release provider owners", "recycle minor"],',
        '"destroy_order": ["exclude new opens", "require exclusive NotBooted status",\n'
        '                              "lock OS operations", "finish backend resource cleanup",\n'
        '                              "remove node", "free kmsg", "release provider owners", "recycle minor"],')
replace(runtime_checker, '            "resource_assignment": False,',
        '            "resource_assignment": "through the checked SMP v2 backend; effects bound by SMP lifecycle contract",\n'
        '            "backend_abi": {"version": 1, "callback_pair_required": True,\n'
        '                            "trusted_module_code_only": True, "provider_module_retained": True,\n'
        '                            "generation_source": "live OsLease or exclusive DestroyGuard",\n'
        '                            "operation_lock": "per-OS sleepable mutex",\n'
        '                            "allowed_status": "NotBooted",\n'
        '                            "native_address_bits": 64, "compat_address_bits": 32,\n'
        '                            "compat_normalization": "zero extend once",\n'
        '                            "cleanup_failure": "keep node, generation and owners live"},')
replace(runtime_checker, '"adapter_cases": 10,', '"adapter_cases": 16,')

for relative, text in pending.items():
    if text != preimages[relative]:
        assert (repo / relative).read_text() == preimages[relative], relative
        (repo / relative).write_text(text)
        print(relative)
