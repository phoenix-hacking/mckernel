file(REMOVE_RECURSE
  ".control.o.cmd"
  ".driver.o.cmd"
  ".futex.o.cmd"
  ".mcctrl.ko.cmd"
  ".mcctrl.mod.o.cmd"
  ".mcctrl.o.cmd"
  ".procfs.o.cmd"
  ".syscall.o.cmd"
  ".sysfs.o.cmd"
  ".tmp_versions"
  ".tmp_versions/mcctrl.mod"
  "CMakeFiles/mcctrl_ko"
  "Module.symvers"
  "control.o"
  "driver.o"
  "futex.o"
  "kmod_always_rebuild"
  "mcctrl.ko"
  "mcctrl.mod.c"
  "mcctrl.mod.o"
  "mcctrl.o"
  "modules.order"
  "old_timestamp"
  "procfs.o"
  "syscall.o"
  "sysfs.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcctrl_ko.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
