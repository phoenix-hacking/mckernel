file(REMOVE_RECURSE
  "CMakeFiles/mcctrl_rust_helpers"
  "rust/.mcctrl_helpers.o.cmd"
  "rust/.mcctrl_helpers.o.cmd.argv.json"
  "rust/mcctrl_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcctrl_rust_helpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
