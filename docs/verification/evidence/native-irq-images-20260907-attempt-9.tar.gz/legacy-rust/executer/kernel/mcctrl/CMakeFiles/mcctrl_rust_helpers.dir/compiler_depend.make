# Empty custom commands generated dependencies file for mcctrl_rust_helpers.
# This may be replaced when dependencies are built.
