file(REMOVE_RECURSE
  "CMakeFiles/mcinspect.dir/mcinspect_bfd_shim.c.o"
  "CMakeFiles/mcinspect.dir/mcinspect_bfd_shim.c.o.d"
  "mcinspect"
  "mcinspect.pdb"
  "rust/mcinspect_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mcinspect.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
