file(REMOVE_RECURSE
  "CMakeFiles/mcexec_rust_helpers"
  "rust/mcexec_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mcexec_rust_helpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
