# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for eclair_arch_rust.
