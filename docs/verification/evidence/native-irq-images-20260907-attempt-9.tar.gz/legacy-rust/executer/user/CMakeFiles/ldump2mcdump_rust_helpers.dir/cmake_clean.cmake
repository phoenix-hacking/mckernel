file(REMOVE_RECURSE
  "CMakeFiles/ldump2mcdump_rust_helpers"
  "rust/ldump2mcdump_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ldump2mcdump_rust_helpers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
