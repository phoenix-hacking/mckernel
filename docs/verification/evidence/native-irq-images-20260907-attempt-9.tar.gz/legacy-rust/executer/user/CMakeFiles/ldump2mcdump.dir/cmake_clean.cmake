file(REMOVE_RECURSE
  "libldump2mcdump.pdb"
  "libldump2mcdump.so"
  "rust/ldump2mcdump_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ldump2mcdump.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
