file(REMOVE_RECURSE
  "CMakeFiles/eclair.dir/eclair_bfd_shim.c.o"
  "CMakeFiles/eclair.dir/eclair_bfd_shim.c.o.d"
  "eclair"
  "eclair.pdb"
  "rust/arch_eclair_x86_64.o"
  "rust/eclair_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/eclair.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
