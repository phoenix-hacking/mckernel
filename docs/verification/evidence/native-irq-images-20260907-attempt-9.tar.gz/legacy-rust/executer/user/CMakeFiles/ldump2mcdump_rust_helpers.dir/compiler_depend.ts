# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for ldump2mcdump_rust_helpers.
