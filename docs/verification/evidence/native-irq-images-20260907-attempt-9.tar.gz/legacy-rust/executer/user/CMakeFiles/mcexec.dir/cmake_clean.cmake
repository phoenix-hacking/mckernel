file(REMOVE_RECURSE
  "CMakeFiles/mcexec.dir/mcexec.c.o"
  "CMakeFiles/mcexec.dir/mcexec.c.o.d"
  "mcexec"
  "mcexec.pdb"
  "rust/mcexec_helpers.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mcexec.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
