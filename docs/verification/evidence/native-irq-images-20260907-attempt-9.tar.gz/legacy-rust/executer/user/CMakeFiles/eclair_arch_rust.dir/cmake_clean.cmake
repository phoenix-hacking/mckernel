file(REMOVE_RECURSE
  "CMakeFiles/eclair_arch_rust"
  "rust/arch_eclair_x86_64.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/eclair_arch_rust.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
