"""Retain exact callback build/guest evidence, failures and formatting replays."""
from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-sysfs-service-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-sysfs-service-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),artifacts=[],compiler_inputs=[],references=[],commands=[],
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    production_gate_credit=False,mckernel_boot_proven=False,sysfs_service_completed=False,applications_tested=False)

def identity(path):
    data=path.read_bytes();return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())

def verify(row):
    assert identity(Path(row['path']))==row,row

def artifact(source,name,tree=False):
    path=out/name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            if tree:
                with tarfile.open(fileobj=compressed,mode='w') as archive:archive.add(source,arcname=source.name)
            else:
                with source.open('rb') as stream:shutil.copyfileobj(stream,compressed)
    with gzip.open(path,'rb') as stream:
        while stream.read(1<<20):pass
    row=identity(path);row['path']='docs/verification/evidence/'+path.name;row['source']=str(source)
    record['artifacts'].append(row)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-sysfs-request-protocol-20260907.json','native-sysfs-setup-checkpoint-20260907.json','native-topology-checkpoint-20260907.json','native-sysfs-remote-checkpoint-20260907.json']:
        path=repo/'docs/verification'/name;ref=identity(path);ref['path']=str(path.relative_to(repo));record['references'].append(ref)
        saved=json.loads(path.read_text());assert saved['status']=='PASS'
        for row in saved['artifacts']:
            path=repo/row['path'];actual=identity(path)
            assert actual['sha256']==row['sha256'] and actual['size']==row['size'],row
            with gzip.open(path,'rb') as stream:
                while stream.read(1<<20):pass
    captures=[
        'native-sysfs-service-module-20260908-1',
        'native-sysfs-service-module-20260908-2',
        'native-sysfs-service-ownership-tests-20260908-1',
        'native-sysfs-service-prepare-20260908-prepare-1',
        'native-sysfs-service-guest-20260908-x86_64-1',
        'native-sysfs-service-guest-20260908-x86_64-2',
        'native-sysfs-service-guest-20260908-x86_64-3',
        'native-sysfs-service-guest-20260908-i386-1',
    ]
    failed={captures[0],captures[4],captures[5]}
    record['captures']=[]
    for name in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        expected='FAIL' if name in failed else 'PASS';assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('compiler_inputs',[])+state.get('outputs',[]):verify(row)
        for capture_row in state.get('captures',[]):
            for row in capture_row.get('artifacts',[]):verify(row)
        for row in state.get('overlay',[]):
            relative=Path(row['path']).relative_to(work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel')
            saved=identity(capture/'staged-source'/relative)
            assert saved['size']==row['size'] and saved['sha256']==row['sha256'],(name,relative)
        artifact(capture,name+'.tar.gz',True);artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status=expected))
    compiled=work/'native-sysfs-service-module-20260908-2'
    state=json.loads((compiled/'record.json').read_text())
    originals=compiled/'original-inputs';staged=compiled/'staged-source'
    replay=out/'format-replay';replay.mkdir()
    for original in sorted(originals.rglob('*')):
        if not original.is_file():continue
        relative=original.relative_to(originals)
        if relative.name in ['mckernel_sysfs_remote_verify.rs','native-sysfs-remote.c']:
            compiler=compiled/'fixture/source/scripts/tests/fixtures'/relative
            current=repo/'scripts/tests/fixtures'/relative
        else:
            compiler=staged/relative;current=repo/'host-kernel/native-rust'/relative
        source_bytes=current.read_bytes();compiler_bytes=compiler.read_bytes()
        row=dict(path=str(current.relative_to(repo)),source_size=len(source_bytes),source_sha256=hashlib.sha256(source_bytes).hexdigest(),
            compiler_capture=str(compiler),original_capture=str(original),size=len(compiler_bytes),sha256=hashlib.sha256(compiler_bytes).hexdigest())
        if source_bytes==compiler_bytes:row['binding']='identical'
        else:
            assert source_bytes==original.read_bytes() and current.suffix=='.rs',str(current)
            candidate=replay/relative;candidate.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(current,candidate)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(candidate)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            record['commands'].append(dict(command=command,exit_code=result.returncode,output=result.stdout.decode()))
            assert result.returncode==0 and candidate.read_bytes()==compiler_bytes,str(current)
            row['binding']='exact pinned rustfmt replay';row['replay']=str(candidate)
        record['compiler_inputs'].append(row)
    artifact(replay,'native-sysfs-service-format-replay-20260908.tar.gz',True)
    for name in ['build-native-sysfs-service.py','check-native-sysfs-service-ownership.py','run-native-sysfs-service-prepare.py','run-native-sysfs-service-guest.py','run-native-sysfs-service-guest-v2.py','run-native-sysfs-service-guest-v3.py']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-sysfs-service.py.gz')
    guests=[json.loads((work/name/'record.json').read_text()) for name in captures[-2:]]
    record['actual_starts']=[]
    for name,guest in zip(captures[-2:],guests):
        assert guest['full_ready_observed'] and guest['boot_ioctl']==0 and guest['registry_status']==4 and guest['physical_status']==3
        assert guest['observed_callback_exchanges']==130 and guest['guest_store_payload_checks']==64
        for path in sorted((work/name/'probe-source').iterdir()):
            current=repo/'scripts/tests/fixtures'/path.name
            assert current.read_bytes()==path.read_bytes(),str(current)
            record['compiler_inputs'].append(dict(path=str(current.relative_to(repo)),
                source_size=current.stat().st_size,source_sha256=identity(current)['sha256'],
                compiler_capture=str(path),original_capture=str(path),size=path.stat().st_size,
                sha256=identity(path)['sha256'],binding='identical actual-start compiler source'))
        record['actual_starts'].append({key:guest[key] for key in ['architecture','boot_ioctl','registry_status','physical_status','observed_callback_exchanges','read_checks','store_checks','rounds','guest_store_payload_checks']})
    preparation=json.loads((work/captures[3]/'record.json').read_text())
    assert preparation['sysfs_namespace_checks']==404 and len(preparation['captures'])==4
    record.update(status='PASS',native_modules_built=3,fixture_built=True,no_simd=True,
        full_ready_observed=True,actual_start_abis=['x86_64','i386'],boot_sysfs_metadata_requests=14,
        remote_read_checks=132,remote_store_checks=128,guest_store_payload_checks=128,
        actual_callback_exchanges=260,physical_ready_captures=4,
        preparation_namespace_checks=404,preparation_captures=4,preparation_allocation_failures=32,
        scope='Continuing native sysfs service reaches actual full-ready boot through both startup ABIs and services real guest callbacks with independent physical and guest-log checks',
        limitations=[
            'Each actual start runs one McKernel CPU in a four-vCPU, two-NUMA Linux guest. Multiple active McKernel CPUs/OS instances and application execution remain unverified.',
            'Real boot covers four creates, one lookup and two symlinks per ABI. Mkdir/unlink/remote release, all special snooping formats, request-claim races, queue pressure, malformed mappings and worker-allocation failures still need direct runtime coverage.',
            'The existing guest CPU online store is NYI: it logs the delivered bytes and acknowledges their count without changing its value or Linux CPU state. No store mutation or CPU hotplug credit is claimed.',
            'Preparation retains its original probe/compiler sources; later edits affect startup-only tests and diagnostic line numbers. Both accepted actual-start probes match the current repository byte for byte.',
            'The first module allocator/initializer failure and the first two x86_64 guest failures remain FAIL. The latter reached full status 3 before the incorrect store-mutation expectation failed.',
            'Native shutdown/drain, the current full suite, declared production integration, complete Rust/assembly and independent acceptance remain open. Production gate accounting is unchanged.'
        ])

except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
