from datetime import datetime, timezone
from pathlib import Path
import json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
base = Path('/work/native-irq-completion-checks-20260907-1')
base.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[])
commands = [
    ['git', '-C', '/workspace', 'diff', '--check'],
    ['python3', '-B', '/work/run-native-irq-image-load-guest.py', '/work/native-startup-exact-stage-20260907-1', '/work/native-irq-image-load-guest-20260907-4'],
    ['python3', '-B', '/work/inventory-rust-consumers-irq-20260907.py'],
    ['python3', '-B', '/work/run-native-irq-full-tests.py', '1'],
]
for index, command in enumerate(commands):
    print('Starting validation step', index, command, flush=True)
    with (base / ('step-' + str(index) + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd='/workspace', stdout=log, stderr=subprocess.STDOUT)
    record['results'].append(dict(command=command, exit_code=result.returncode))
    record['updated_utc'] = datetime.now(timezone.utc).isoformat()
    record['exit_code'] = result.returncode
    (base / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Completed validation step', index, 'exit', result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
