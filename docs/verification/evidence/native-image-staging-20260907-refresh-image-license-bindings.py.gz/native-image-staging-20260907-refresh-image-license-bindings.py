"""Extend only the live additive inventory and current implementation pins."""
import ast,hashlib,json,pprint
from pathlib import Path
root=Path('/home/holden/mckernel')
def ident(path):
 data=(root/path).read_bytes();return dict(path=path,sha256=hashlib.sha256(data).hexdigest(),size=len(data))
def assignments(source):return {n.targets[0].id:n.value for n in ast.parse(source).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def change_node(source,node,value):
 lines=source.splitlines(keepends=True);a=sum(map(len,lines[:node.lineno-1]))+node.col_offset;b=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
 return source[:a]+pprint.pformat(value,width=100,sort_dicts=False)+source[b:]
def expand_inputs(path,counts):
 p=root/path;s=p.read_text()
 for old,new,expected in [
  ('"host-kernel/native-rust/smp_cpu.rs",','"host-kernel/native-rust/smp_memory.rs",',counts[0]),
  ('"host-kernel/kbuild/patches/0003-driver-core-export-device-hotplug-transactions.patch",','"host-kernel/kbuild/patches/0004-mm-export-memory-hotplug-read-exclusion.patch",',counts[1])]:
  lines=s.splitlines(keepends=True);found=0;out=[]
  for line in lines:
   out.append(line)
   if line.strip()==old:
    out.append(line[:len(line)-len(line.lstrip())]+new+'\n');found+=1
  assert found==expected,(path,old,found);s=''.join(out)
 p.write_text(s)
for relative, expected in [('scripts/rocky_kernel_license_inventory.py', 3), ('scripts/tests/test_rocky_kernel_license_inventory.py', 2)]:
 p=root/relative;s=p.read_text();out=[];count=0
 for line in s.splitlines(keepends=True):
  out.append(line)
  if line.strip().replace(chr(39), chr(34)) == '"host-kernel/native-rust/smp_memory.rs",':
   indent=line[:len(line)-len(line.lstrip())]
   for name in ('ihk_mapping', 'smp_image', 'smp_loader'):
    out.append(indent+'"host-kernel/native-rust/'+name+'.rs",'+chr(10))
   count+=1
 assert count==expected,(relative,count)
 p.write_text(''.join(out))

def refresh_override(path,allowed):
 p=root/path;s=p.read_text();ns=assignments(s);node=ns['CURRENT_IMPLEMENTATION_OVERRIDES'];edits=[];lines=s.splitlines(keepends=True)
 def resolve(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return ast.literal_eval(ns[n.id])
  if isinstance(n,ast.Subscript):return resolve(n.value)[resolve(n.slice)]
  raise ValueError(ast.dump(n))
 for row in node.values:
  fields={ast.literal_eval(k):v for k,v in zip(row.keys,row.values)}
  relative=resolve(fields['path'])
  if relative not in allowed:continue
  current=ident(relative)
  for key in ('sha256','size'):
   n=fields[key];edits.append((sum(map(len,lines[:n.lineno-1]))+n.col_offset,sum(map(len,lines[:n.end_lineno-1]))+n.end_col_offset,repr(current[key])))
 assert edits,'No matching current override '+path
 for a,b,v in sorted(edits,reverse=True):s=s[:a]+v+s[b:]
 p.write_text(s)
for path,allowed in [
 ('scripts/rocky_kernel_license_child_inventory_v2.py',{'scripts/rocky_kernel_license_inventory.py'}),
 ('scripts/rocky_kernel_license_review_response.py',{'scripts/rocky_kernel_license_inventory.py'}),
 ('scripts/rocky_kernel_license_review_response_builder.py',{'scripts/rocky_kernel_license_review_response.py'}),
 ('scripts/rocky_kernel_license_review_response_index.py',{'scripts/rocky_kernel_license_review_response.py'})]:refresh_override(path,allowed)
# This inventory describes the currently integrated consumers of the unchanged
# module-owner patch. Its predecessor and kernel-source patch records are frozen.
p=root/'host-kernel/contracts/rs006-miscdevice-module-owner-followup-v1.json';v=json.loads(p.read_text());changed=[]
allowed={'.github/workflows/native-rust-host-modules-exact-build.yml','host-kernel/kbuild/stage-manifest.json','scripts/native_rust_runtime_evidence.py','scripts/rocky_kernel_license_inventory.py','scripts/tests/test_rocky_kernel_license_inventory.py'}
for row in v['integrated_consumer_inventory']:
 if row['path'] in allowed:
  row.update(ident(row['path']));changed.append(row['path'])
assert set(changed)==allowed,changed
p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
p=root/'scripts/rs006_miscdevice_module_owner_followup.py';s=p.read_text();n=assignments(s)['EXPECTED_CONTRACT_SHA256'];p.write_text(change_node(s,n,ident('host-kernel/contracts/rs006-miscdevice-module-owner-followup-v1.json')['sha256']))
print('Extended live inventory by three image-loader sources; preserved frozen descriptors and false credit claims')
