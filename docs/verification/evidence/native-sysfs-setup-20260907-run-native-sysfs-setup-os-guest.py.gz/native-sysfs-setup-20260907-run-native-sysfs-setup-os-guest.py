from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time, textwrap

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
mode, module_attempt, attempt = sys.argv[1:]
assert mode in ('prepare', 'start-x86_64', 'start-i386')
repo = Path('/workspace')
compiled = Path('/work/native-sysfs-setup-module-20260907-' + module_attempt)
out = Path('/work/native-sysfs-setup-os-guest-20260907-' + mode + '-' + attempt)
images = Path('/work/mckernel-native-irq-images-20260907-13')
templates = Path('/work/native-trampoline-region-module-20260907-3')
vdso_fixture = Path('/work/native-vdso-module-20260907-1')
built = json.loads((compiled / 'record.json').read_text())
assert built['status'] == 'PASS'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

for item in built['outputs']:
    assert identity(Path(item['path'])) == item, item
out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', mode=mode,
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              inputs=[identity(compiled / 'record.json')], commands=[], captures=[],
              cpus=4, numa_nodes=2, memory_mib=8192, container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)),
              production_gate_credit=False, mckernel_boot_proven=False, declared_stage=False)
process = None
stream = None

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-12000:])

sequence = 0
def qmp(command, arguments=None):
    global sequence
    sequence += 1
    request = dict(execute=command, id=sequence)
    if arguments is not None: request['arguments'] = arguments
    stream.write((json.dumps(request) + '\n').encode()); stream.flush()
    while True:
        line = stream.readline()
        if not line: raise RuntimeError('QMP disconnected')
        result = json.loads(line)
        if result.get('id') != sequence: continue
        assert 'error' not in result, result
        return result['return']

def dump(physical, length, path):
    assert 0 <= physical < physical + length <= 256 << 30 and 0 < length <= 4 << 20
    response = qmp('human-monitor-command', {'command-line': 'pmemsave 0x%x %d "%s"' % (physical, length, path)})
    assert response == '', response
    assert path.stat().st_size == length
    return path.read_bytes()

def capture_linux_vdso(serial, target):
    pattern = (r'MCKERNEL_VDSO_VERIFY PASS text=([0-9a-f]+) bytes=8192 fnv=([0-9a-f]+) time=([0-9a-f]+) rng=([0-9a-f]+) physical_base=([0-9a-f]+) mode=(\d+) first_seq=(\d+) last_seq=(\d+) updates=(\d+) samples=16 rng_ready=(\d+) read_only=1 service_completed=0')
    matches = re.findall(pattern, serial)
    assert len(matches) == 2, matches
    rows = [list(map(lambda item: int(item[1], 16 if item[0] < 5 else 10), enumerate(row))) for row in matches]
    assert rows[0][:5] == rows[1][:5]
    assert all(0 <= row[5] <= 3 and row[6] != row[7] and 1 <= row[8] <= 16 and row[9] in (0, 1) for row in rows)
    text, expected_fnv, time_data, rng_data, physical_base = rows[0][:5]
    physical = {}
    ranges = []
    for name, virtual, count in [('text', text, 8192), ('time', time_data, 4096), ('rng', rng_data, 4096)]:
        assert 0xffffffff80000000 <= virtual < virtual + count <= 0xffffffffc0000000
        start = virtual - 0xffffffff80000000 + physical_base
        assert start % 4096 == 0 and 0 < start < start + count <= 256 << 30
        assert not any(start < end and begin < start + count for begin, end in ranges)
        ranges.append((start, start + count)); physical[name] = start
        dump(start, count, target / ('linux-vdso-' + name + '.bin'))
    text_bytes = (target / 'linux-vdso-text.bin').read_bytes()
    value = 0xcbf29ce484222325
    for byte in text_bytes: value = ((value ^ byte) * 0x100000001b3) & ((1 << 64) - 1)
    assert text_bytes[:5] == b'\x7fELF\x02' and value == expected_fnv
    time_bytes = (target / 'linux-vdso-time.bin').read_bytes()
    # QMP may pause Linux during a timekeeper update. Retain the sequence's
    # parity; coherent samples were separately checked by the live Rust fixture.
    seq, clock_mode = struct.unpack_from('<Ii', time_bytes)
    sec, nsec = struct.unpack_from('<QQ', time_bytes, 40 + 5 * 16)
    assert 0 <= clock_mode <= 3 and sec > 0 and nsec < 1_000_000_000
    rng_ready = (target / 'linux-vdso-rng.bin').read_bytes()[8]
    assert rng_ready in (0, 1)
    result = dict(module_cycles=2, coherent_samples=32, text_fnv=value, physical=physical,
                  paused_sequence=seq, paused_sequence_even=(seq % 2 == 0), clock_mode=clock_mode,
                  coarse_sec=sec, coarse_nsec=nsec, rng_ready=rng_ready, ranges=ranges,
                  read_only=True, service_completed=False)
    (target / 'linux-vdso.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    return result

def control_rows(serial, generation):
    pattern = (r'IHK-SMP: control accepted os=0 generation=' + generation +
        r' port=(\d+) guest_cpu=(\d+) linux_cpu=(\d+) cookie=(\d+) receive=([0-9a-f]+) send=([0-9a-f]+) bytes=(\d+) reference=(\d+) remote_cookie=([0-9a-f]+)')
    names = ('port', 'guest_cpu', 'linux_cpu', 'cookie', 'receive', 'send', 'bytes', 'reference', 'remote_cookie')
    return [dict(zip(names, [int(value, 16 if index in (4, 5, 8) else 10) for index, value in enumerate(row)]))
            for row in re.findall(pattern, serial)]

def capture(serial, index, validate=True, resume=True):
    matches = re.findall(r'IHK-SMP: boot prepared os=(\d+) generation=(\d+) params=([0-9a-f]+) bytes=(\d+) trampoline=([0-9a-f]+) startup=([0-9a-f]+) cpus=(\d+) numa=(\d+) chunks=(\d+) kmsg=([0-9a-f]+)', serial)
    assert matches, 'No complete native preparation record'
    os_id, generation, params, length, trampoline, startup, cpus, nodes, chunks, kmsg = matches[-1]
    assert int(os_id) == 0
    params, trampoline, startup, kmsg = (int(value, 16) for value in (params, trampoline, startup, kmsg))
    length, cpus, nodes, chunks = (int(value) for value in (length, cpus, nodes, chunks))
    assert 7616 <= length <= 4 << 20 and trampoline == 0x80000
    target = out / ('capture-' + str(index)); target.mkdir()
    qmp('stop')
    try:
        data = dump(params, length, target / 'params.bin')
        low = dump(trampoline, 4096, target / 'trampoline.bin')
        startup_data = dump(startup, 4096, target / 'startup.bin')
        kmsg_data = dump(kmsg, 4 << 20, target / 'kmsg.bin')
        dump_count = struct.unpack_from('<I', data, 6636)[0]
        dump_bytes, dump_physical = struct.unpack_from('<QQ', data, 6640)
        dump_data = dump(dump_physical, dump_bytes, target / 'dump.bin')
        vdso_capture = capture_linux_vdso(serial, target) if validate else None
        (target / 'registers.txt').write_text(qmp('human-monitor-command', {'command-line': 'info registers -a'}))
        (target / 'cpus.json').write_text(json.dumps(qmp('query-cpus-fast'), indent=2) + '\n')
        if mode != 'prepare' and validate:
            for offset, name in ((56, 'receive'), (64, 'send')):
                physical = struct.unpack_from('<Q', data, offset)[0]
                if physical:
                    dump(physical, 4096, target / ('queue-' + name + '.bin'))
            for row in control_rows(serial, generation):
                for direction in ('receive', 'send'):
                    dump(row[direction], row['bytes'], target / ('control-' + str(row['port']) + '-' + direction + '.bin'))
            requests = re.findall(r'IHK-SMP: regular request os=0 generation=' + generation + r' port=(\d+) cookie=(\d+) packets=(\d+) message=([0-9a-f]+) reference=(-?\d+) argument=([0-9a-f]+) irq_events=(\d+)', serial)
            assert len(requests) == 3, requests
            argument = int(requests[0][5], 16)
            dump(argument, 128, target / 'vdso-descriptor.bin')
            # SYSFS_REQ_SETUP uses payload.sysfs_arg1 at byte 24. The
            # preceding vDSO message uses traditional.arg at byte 40.
            control = (target / 'control-503-receive.bin').read_bytes()
            assert int(requests[1][3], 16) == 0x40
            assert int(requests[2][3], 16) == 0x30
            next_argument = struct.unpack_from('<Q', control, 320 + 24)[0]
            dump(next_argument, 4096, target / 'service-argument.bin')
            replies = re.findall(r'IHK-SMP: sysfs setup replied os=0 generation=' + generation +
                r' request=([0-9a-f]+) buffer=([0-9a-f]+) bytes=4096 nodes=(\d+) error=0 setup_completed=1', serial)
            assert len(replies) == 1, replies
            buffer_pa = int(replies[0][1], 16)
            dump(buffer_pa, 4096, target / 'sysfs-shared-data.bin')
            loaded = re.findall(r'IHK-SMP: startup tables os=0 generation=' + generation + r' root=([0-9a-f]+) image=([0-9a-f]+)', serial)
            assert len(loaded) == 1
            image_base = int(loaded[0][1], 16)
            symbols = (images / 'native-rust-symbols.txt').read_text().splitlines()
            guest_symbols = {}
            for label, name, length0 in [('exchange', 'native_vdso8EXCHANGE', 128), ('state', 'native_vdso5STATE', 4),
                    ('prefix', 'vdso', 88), ('container-size', 'container_size', 8), ('text-offset', 'vdso_offset', 8),
                    ('local-time-support', 'gettime_local_support', 4), ('vsyscall-local', 'tod_data', 1)]:
                matches0 = [int(line.split()[0], 16) for line in symbols if len(line.split()) == 3 and
                    (line.split()[2].endswith(name) if name.startswith('native_vdso') else line.split()[2] == name)]
                assert len(matches0) == 1, (name, matches0)
                virtual = matches0[0]
                assert 0xfffffffffe800000 <= virtual < virtual + length0 <= 0xffffffffff000000
                physical0 = image_base + virtual - 0xfffffffffe800000
                dump(physical0, length0, target / ('guest-vdso-' + label + '.bin'))
                guest_symbols[label] = dict(virtual=virtual, physical=physical0, bytes=length0)
            assert guest_symbols['exchange']['physical'] == argument
            (target / 'guest-vdso-symbols.json').write_text(json.dumps(guest_symbols, indent=2) + '\n')

    finally:
        if resume:
            qmp('cont')
    if not validate:
        record['emergency_capture'] = dict(directory=str(target),
            status=struct.unpack_from('<Q', data, 16)[0],
            artifacts=[identity(path) for path in sorted(target.iterdir()) if path.is_file()])
        save()
        print('Retained emergency boot capture', target, flush=True)
        return
    u64 = lambda offset: struct.unpack_from('<Q', data, offset)[0]
    u32 = lambda offset: struct.unpack_from('<I', data, offset)[0]
    assert u32(24) == length and (u64(40), u64(48)) == (kmsg, 4 << 20)
    assert (u32(6604), u32(6608), u32(6612), u32(6616), u32(6620)) == (4, cpus, nodes, chunks, 0)
    assert u32(4296) == 0xf6 and u64(4288) >= 0xffff800000000000
    assert struct.unpack_from('<4I', data, 4300) == (0, 1, 2, 3)
    assert all(struct.unpack_from('<4Q', data, 192))
    assert u64(128) % 4096 == 0 and u64(128) != 0 and u64(152) < 1 << 32
    assert u64(160) > 0 and u64(168) > 0 and 0 <= u64(184) < 1_000_000_000
    cpu_rows = [struct.unpack_from('<4i', data, 7616 + rank * 16) for rank in range(cpus)]
    node_offset = 7616 + cpus * 16
    node_rows = [struct.unpack_from('<2i', data, node_offset + rank * 8) for rank in range(nodes)]
    expected_cpus = [(1, 3, 3, 0), (0, 1, 1, 0)] if mode == 'prepare' else [(0, 1, 1, 0)]
    assert cpu_rows == expected_cpus, cpu_rows
    assert node_rows == ([(1, 0), (1, 1)] if mode == 'prepare' else [(1, 0)])
    chunk_offset = node_offset + nodes * 8
    chunk_rows = [struct.unpack_from('<QQi4x', data, chunk_offset + rank * 24) for rank in range(chunks)]
    assert all(start < end and start % 4096 == end % 4096 == 0 for start, end, node in chunk_rows)
    assert sum(end - start for start, end, node in chunk_rows) == (64 if mode == 'prepare' else 128) << 20
    assert all(node == (1 if mode == 'prepare' else 0) for start, end, node in chunk_rows)
    assert (u64(0), u64(8)) == (min(row[0] for row in chunk_rows), max(row[1] for row in chunk_rows))
    assert dump_count == chunks
    distance_offset = chunk_offset + chunks * 24
    distances = list(struct.unpack_from('<' + str(nodes * nodes) + 'I', data, distance_offset))
    assert all(distances[i * nodes + i] == 10 for i in range(nodes))
    assert all(distance >= 10 for distance in distances)
    if mode == 'prepare':
        root, stack, image_physical, actual_trampoline, entry = struct.unpack_from('<5Q', startup_data, 16)
        assert root == u64(152) and actual_trampoline == trampoline and entry >= 0xfffffffffe800000
        original_startup = bytearray((templates / 'native-startup.bin').read_bytes())
        struct.pack_into('<5Q', original_startup, 16, root, stack, image_physical, trampoline, entry)
        assert startup_data == bytes(original_startup) + bytes(4096 - len(original_startup))
        assert u64(16) == u64(56) == u64(64) == 0
        assert data[6348:6604] == b'y' * 255 + b'\0'
        original_low = bytearray((templates / 'native-trampoline.bin').read_bytes())
        struct.pack_into('<4Q', original_low, 8, root, startup, stack, params)
        assert low == original_low
        cursor = 0
        for start, end, node in chunk_rows:
            pages = (end - start) // 4096
            words = (pages + 63) // 64
            assert struct.unpack_from('<2Q', dump_data, cursor) == (start, words)
            for word in range(words):
                expected = (1 << min(64, pages - word * 64)) - 1
                assert struct.unpack_from('<Q', dump_data, cursor + 16 + word * 8)[0] == expected
            cursor += 16 + words * 8
        assert not any(dump_data[cursor:])
    else:
        assert u64(16) >= 2, ('McKernel did not reach architectural readiness', u64(16))
        # arch_start moves to STACK before allocator initialization. The existing
        # mem_numa_init_body_result / __ihk_numa_add_free_pages then clears and
        # reuses the startup page. Complete immutable-byte comparison belongs
        # to preparation; inspect the executing AP's actual image/CR3 here.
        root, actual_startup, stack, actual_params = struct.unpack_from('<4Q', low, 8)
        assert (root, actual_startup, actual_params) == (u64(152), startup, params)
        assert stack == u64(32) - 4096
        image_rows = re.findall(r'IHK-SMP: startup tables os=0 generation=' + generation + r' root=([0-9a-f]+) image=([0-9a-f]+)', serial)
        assert len(image_rows) == 1 and int(image_rows[0][0], 16) == root
        image_physical = int(image_rows[0][1], 16)
        assert any(start <= image_physical < image_physical + (8 << 20) <= end for start, end, node in chunk_rows)
        registers = (target / 'registers.txt').read_text().split('CPU#1\n')[1].split('CPU#2\n')[0]
        ip = int(re.search(r'RIP=([0-9a-f]+)', registers)[1], 16)
        cr3 = int(re.search(r'CR3=([0-9a-f]+)', registers)[1], 16)
        assert 0xfffffffffe800000 <= ip < 0xfffffffffe900000
        assert any(start <= cr3 < cr3 + 4096 <= end for start, end, node in chunk_rows)
        symbol = subprocess.check_output(['addr2line', '-e', str(images / 'native-rust/kernel/mckernel.img'), '-f', '-C', hex(ip)], text=True)
        (target / 'ap-symbol.txt').write_text(symbol)
        assert symbol.splitlines()[0] != '??', symbol
        assert data[6348:6604] == b'hidos' + bytes(251)
        for queue in (u64(56), u64(64)):
            assert queue % 4096 == 0 and any(start <= queue < queue + 4096 <= end for start, end, node in chunk_rows), queue
        for name, count in (('receive', 2), ('send', 3)):
            queue_data = (target / ('queue-' + name + '.bin')).read_bytes()
            assert struct.unpack_from('<IHHI', queue_data) == (0, 0, 56, 72)
            assert struct.unpack_from('<4Q', queue_data, 16) == (count, count, count, 4032)
        incoming = (target / 'queue-receive.bin').read_bytes()
        outgoing = (target / 'queue-send.bin').read_bytes()
        assert struct.unpack_from('<I', outgoing, 72)[0] == 0x10203010
        rows = control_rows(serial, generation)
        assert [row['port'] for row in rows] == [501, 503], rows
        ranges = [(u64(56), u64(56) + 4096), (u64(64), u64(64) + 4096)]
        for index, row in enumerate(rows):
            assert (row['guest_cpu'], row['linux_cpu'], row['cookie'], row['bytes']) == (0, 1, index + 1, 16384)
            assert row['receive'] % 4096 == 0 and 0 < row['receive'] < row['receive'] + 16384 <= 1 << 32
            assert not any(start < row['receive'] + 16384 and row['receive'] < end for start, end, node in chunk_rows)
            assert row['send'] % 4096 == 0 and any(start <= row['send'] < row['send'] + 16384 <= end for start, end, node in chunk_rows)
            for direction in ('receive', 'send'):
                interval = (row[direction], row[direction] + 16384)
                assert not any(interval[0] < end and start < interval[1] for start, end in ranges)
                ranges.append(interval)
                contents = (target / ('control-' + str(row['port']) + '-' + direction + '.bin')).read_bytes()
                assert struct.unpack_from('<IHHI', contents) == (1, row['port'], 128, 127)
                count = 3 if row['port'] == 503 and direction == 'receive' else 0
                assert struct.unpack_from('<4Q', contents, 16) == (count, count, count, 16256)
                assert struct.unpack_from('<4I', contents, 48) == (row['cookie'] if direction == 'receive' else row['reference'], 0, 0, 0)
            offer = struct.unpack_from('<7Q', incoming, 64 + index * 56)
            assert offer[1] == (row['reference'] << 32) | 0x20000001
            assert offer[2] == (128 << 32) | row['port']
            assert offer[3:6] == (0, row['send'], row['remote_cookie'])
            assert offer[6] == (0xffffffff00001329 if row['port'] == 501 else 0x1129)
            reply = struct.unpack_from('<7Q', outgoing, 64 + (index + 1) * 56)
            assert reply == (0, (row['reference'] << 32) | 0x20000002, 0, row['receive'], row['remote_cookie'], row['cookie'], 0)
        request = re.search(r'IHK-SMP: regular request os=0 generation=' + generation + r' port=(\d+) cookie=(\d+) packets=(\d+) message=([0-9a-f]+) reference=(-?\d+) argument=([0-9a-f]+) irq_events=(\d+)', serial)
        assert request and (int(request[1]), int(request[2]), int(request[3]), int(request[4], 16)) == (503, 2, 1, 0xb), request
        assert int(request[7]) >= 2
        regular = (target / 'control-503-receive.bin').read_bytes()[64:192]
        assert struct.unpack_from('<i', regular, 8)[0] == 0xb
        assert struct.unpack_from('<i', regular, 24)[0] == int(request[5])
        argument = struct.unpack_from('<Q', regular, 40)[0]
        assert argument == int(request[6], 16) and any(start <= argument < argument + 128 <= end for start, end, node in chunk_rows)
        (target / 'control-channels.json').write_text(json.dumps(rows, indent=2) + '\n')
        lock, tail, capacity, head = struct.unpack_from('<4I', kmsg_data)
        assert capacity == (4 << 20) - 4096 and 0 <= head <= tail < capacity
        message = kmsg_data[4096 + head:4096 + tail].decode(errors='replace')
        (target / 'kmsg.txt').write_text(message)
        assert 'IHK/McKernel started.' in message and 'BSP: booted 0 AP CPUs' in message
        assert 'panic' not in message.lower()
        assert 'Master channel init acked.' in message
        for port_name in ('ikc2mckernel', 'ikc2linux'):
            pattern = r'^\[ *0\]: \(' + port_name + r'\) Trying to connect host \.\.\.\[ *0\]: connected\.$'
            assert re.search(pattern, message, re.MULTILINE), (port_name, message)
        assert 'vdso is enabled' in message
        text_pa, time_pa, rng_pa = (vdso_capture['physical'][name] for name in ('text', 'time', 'rng'))
        descriptor = (target / 'vdso-descriptor.bin').read_bytes()
        expected = struct.pack('<Q6I12Q', 0, 1, 128, 0, 2, 6, 1,
            text_pa, text_pa + 4096, time_pa, 0, rng_pa, 0, 0, 0, 0, 0, 0, 0)
        assert descriptor == expected, descriptor.hex()
        assert (target / 'guest-vdso-exchange.bin').read_bytes() == descriptor
        assert (target / 'guest-vdso-state.bin').read_bytes() == struct.pack('<I', 2)
        assert (target / 'guest-vdso-container-size.bin').read_bytes() == struct.pack('<Q', 32768)
        assert (target / 'guest-vdso-text-offset.bin').read_bytes() == struct.pack('<Q', 24576)
        assert (target / 'guest-vdso-local-time-support.bin').read_bytes() == bytes(4)
        assert (target / 'guest-vdso-vsyscall-local.bin').read_bytes() == bytes(1)
        prefix = (target / 'guest-vdso-prefix.bin').read_bytes()
        assert struct.unpack_from('<qi4b', prefix) == (0, 2, 0, 0, 0, 0)
        assert struct.unpack_from('<9Q', prefix, 16) == (text_pa, text_pa + 4096,
            (1 << 64) - 24576, time_pa, 0, 0, 0, 0, u64(136) + time_pa)
        assert 'IHK-SMP: vDSO replied os=0 generation=' + generation + ' ' in serial
        requests = re.findall(r'IHK-SMP: regular request os=0 generation=' + generation + r' port=(\d+) cookie=(\d+) packets=(\d+) message=([0-9a-f]+) reference=(-?\d+) argument=([0-9a-f]+) irq_events=(\d+)', serial)
        assert len(requests) == 3 and [int(row[3],16) for row in requests] == [0xb,0x40,0x30], requests
        control = (target / 'control-503-receive.bin').read_bytes()
        setup_packet, next_packet = control[192:320], control[320:448]
        assert struct.unpack_from('<i',setup_packet,8)[0] == 0x40
        assert struct.unpack_from('<i',next_packet,8)[0] == 0x30
        setup_argument = struct.unpack_from('<Q',setup_packet,24)[0]
        next_argument = struct.unpack_from('<Q',next_packet,24)[0]
        assert setup_argument & 0xffffffff == int(requests[1][4]) & 0xffffffff
        assert next_argument & 0xffffffff == int(requests[2][4]) & 0xffffffff
        assert next_argument % 4096 == setup_argument % 4096 == 0
        assert setup_argument == int(replies[0][0],16)
        assert buffer_pa != next_argument and buffer_pa != setup_argument
        for begin,length0 in [(setup_argument,1056),(next_argument,4096),(buffer_pa,4096)]:
            assert any(start <= begin < begin+length0 <= stop for start,stop,node in chunk_rows)
            assert not any(begin < stop and start < begin+length0 for start,stop in ranges)
            assert not (begin < argument+128 and argument < begin+length0)
        assert not (buffer_pa < setup_argument+1056 and setup_argument < buffer_pa+4096)
        assert not (buffer_pa < next_argument+4096 and next_argument < buffer_pa+4096)
        next_data = (target / 'service-argument.bin').read_bytes()
        file_mode, file_error, client_ops, client_instance = struct.unpack_from('<iiQQ',next_data)
        path_bytes=next_data[24:1048]
        assert b'\0' in path_bytes
        file_path=path_bytes.split(b'\0',1)[0].decode('ascii')
        assert file_mode == 0o444 and file_path == '/sys/devices/system/cpu/num_processors'
        assert client_ops >= 0xfffffffffe800000 and client_instance >= 0xfffffffffe800000
        assert struct.unpack_from('<i',next_data,1052)[0] == 1
        # The setup allocation can already have been freed and reused for this
        # next request. Preserve the observed reuse; do not read it as old setup.
        vdso_capture['service_completed'] = True
        vdso_capture['guest_validated_state'] = 2
        vdso_capture['sysfs_setup'] = dict(completed=True,request=setup_argument,buffer=buffer_pa,
            bytes=4096,nodes=int(replies[0][2]),request_reused=(next_argument==setup_argument))
        vdso_capture['next_request'] = dict(message=0x30,argument=next_argument,path=file_path,
            mode=file_mode,client_ops=client_ops,client_instance=client_instance,busy=1)

    result = dict(directory=str(target), os_generation=int(generation), status=u64(16), cpu_rows=cpu_rows,
                  node_rows=node_rows, chunks=chunk_rows, distances=distances, params_physical=params,
                  startup_physical=startup, image_physical=image_physical, root_physical=root,
                  kmsg_physical=kmsg, queue_receive=u64(56), queue_send=u64(64),
                  artifacts=[identity(path) for path in sorted(target.iterdir()) if path.is_file()])
    result['linux_vdso'] = vdso_capture
    for begin, end in vdso_capture['ranges']:
        assert not any(start < end and begin < limit for start, limit, node in chunk_rows)
    record['captures'].append(result); save()
    print('Captured and checked', target, 'guest status', u64(16), flush=True)

try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), out / 'root')
    shutil.copyfile(repo / 'scripts/native-boot-init.sh', out / 'root/init')
    (out / 'root/init').chmod(0o755)
    vdso_record = json.loads((vdso_fixture / 'record.json').read_text())
    assert vdso_record['status'] == 'PASS'
    for item in vdso_record['inputs'] + vdso_record['outputs']:
        assert identity(Path(item['path'])) == item, item
    shutil.copyfile(vdso_fixture / 'mckernel_vdso_verify.ko', out / 'root/modules/mckernel_vdso_verify.ko')
    record['inputs'] += [identity(vdso_fixture / 'record.json'), identity(vdso_fixture / 'mckernel_vdso_verify.ko')]
    init_text = (out / 'root/init').read_text()
    insertion = '''for vdso_cycle in 1 2; do
    insmod /modules/mckernel_vdso_verify.ko
    rmmod mckernel_vdso_verify
    printf 'NATIVE_VDSO_EXPORTS cycle=%s complete\\n' "$vdso_cycle"
done
'''
    setup_functions = Path('/work/native-sysfs-setup-os-functions.sh')
    record['inputs'].append(identity(setup_functions))
    insertion = setup_functions.read_text() + '\nhost_values\n' + insertion
    assert init_text.count('read -r mode </boot-mode\n') == 1
    (out / 'root/init').write_text(init_text.replace('read -r mode </boot-mode\n', insertion + 'read -r mode </boot-mode\n'))
    fixture_name = 'mckernel_os_device_verify.ko'
    shutil.copyfile(compiled / fixture_name, out / 'root/modules' / fixture_name)
    record['inputs'].append(identity(compiled / fixture_name))
    init_text = (out / 'root/init').read_text()
    anchor = "    printf 'NATIVE_BOOT_GUEST START_CAPTURE incomplete=1 restoration_proven=0"
    assert init_text.count(anchor) == 1
    insertion = '''    [ -d /sys/class/mcos/mcos0/sys ]
    [ -d /sys/class/mcos/mcos0/sys/setup_complete ]
    printf 'SETUP_DIR cycle=1 phase=after path=/sys\\n'
    scan /sys/class/mcos/mcos0/sys 1 after
    base=/sys/class/mcos/mcos0/sys
    [ "$base/test/L.dir" -ef "$base/test/a.dir" ]
    [ "$base/bus/node/devices/node0" -ef "$base/devices/system/node/node0" ]
    [ "$base/devices/system/node/node0/cpu0" -ef "$base/devices/system/cpu/cpu0" ]
    [ "$base/devices/system/cpu/cpu0/node0" -ef "$base/devices/system/node/node0" ]
    for device_cycle in 1 2; do
        insmod /modules/mckernel_os_device_verify.ko
        rmmod mckernel_os_device_verify
    done
'''
    (out / 'root/init').write_text(init_text.replace(anchor, insertion + anchor))
    (out / 'root/boot-mode').write_text(mode + '\n')
    run('shell-syntax', ['bash', '-n', str(out / 'root/init')])
    for name in ['ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko']:
        shutil.copyfile(compiled / name, out / 'root/modules' / name)
    record['inputs'].append(identity(Path('/work/native-sysfs-setup-os-validation.inc')))
    probe = out / 'probe-source'; probe.mkdir()
    for name in ['native-boot.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c']:
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, probe / name)
    states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', (compiled / 'bindings_generated.rs').read_text())
    assert len(states) == 1
    for bits, architecture in [(64, 'x86_64'), (32, 'i386')]:
        command = ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror', '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie', '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack', '-DCPUHP_FAILURE_STATE=' + states[0], '-DNATIVE_VDSO_REV3=1', '-DNATIVE_SYSFS_OS=1', '-DNATIVE_SYSFS_SETUP=1', '-DBOOT_PREPARE_ONLY=' + str(int(mode == 'prepare')), str(probe / 'native-boot.c'), '-o', str(out / 'root/bin' / ('native-boot-' + architecture))]
        run('probe-build-' + architecture, command)
    image_dir = out / 'root/images'; image_dir.mkdir()
    for variant, filename in [('native-rust', 'mckernel.img'), ('legacy-rust', 'legacy.img')]:
        shutil.copyfile(images / variant / 'kernel/mckernel.img', image_dir / filename)
    old_image = Path('/work/mckernel-native-irq-images-20260907-10/native-rust/kernel/mckernel.img')
    record['inputs'].append(identity(old_image))
    shutil.copyfile(old_image, image_dir / 'native-v1.img')
    old_v2 = Path('/work/mckernel-native-irq-images-20260907-11/native-rust/kernel/mckernel.img')
    record['inputs'].append(identity(old_v2))
    shutil.copyfile(old_v2, image_dir / 'native-v2.img')
    environment = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(out / 'root'))
    subprocess.run(['python3', '-B', '/work/write-native-cpio-spec.py'], env=environment, check=True)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            creator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(creator.stdout, output); creator.stdout.close(); assert creator.wait() == 0
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
            '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-nic', 'none']
    if mode != 'prepare':
        args += ['-no-shutdown']
    record['qemu_args'] = args
    record['inputs'] += [identity(path) for path in [compiled / 'bzImage', out / 'initramfs.cpio.gz', templates / 'native-startup.bin', templates / 'native-trampoline.bin']]
    record['inputs'] += [identity(path) for path in sorted(probe.iterdir())]
    record['inputs'].append(identity(images / 'native-rust-symbols.txt'))
    save()
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 600
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20); connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            if mode != 'prepare':
                vm_state = qmp('query-status')
                if vm_state['status'] in ('shutdown', 'guest-panicked'):
                    record['terminal_vm_state'] = vm_state
                    assert 'NATIVE_BOOT_GUEST START_CAPTURE incomplete=1 restoration_proven=0' in serial, vm_state
                    qmp('quit')
                    process.wait(timeout=15)
                    break
            for bad in ['NATIVE_BOOT_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
                assert bad not in serial, bad
            ready = len(re.findall(r'NATIVE_BOOT_CAPTURE (?:x86_64|i386) ready', serial))
            if ready > seen:
                assert ready == seen + 1
                capture(serial, seen); seen += 1
            time.sleep(0.1)
        assert process.returncode == 0, process.returncode
    serial = (out / 'serial.log').read_text(errors='replace')
    if mode == 'prepare':
        assert 'NATIVE_BOOT_GUEST PREPARATION PASS' in serial
        assert len(record['captures']) == 4
        for architecture in ('x86_64', 'i386'):
            assert serial.count('NATIVE_BOOT_PREPARATION ' + architecture + ' PASS cycles=8 failures=8 exclusive=1 restored=1') == 2
        assert 'IHK-SMP: CPU start ' not in serial
    else:
        assert 'NATIVE_BOOT_GUEST START_CAPTURE incomplete=1 restoration_proven=0' in serial
        assert len(record['captures']) == 1
        assert 'IHK-SMP: CPU start os=0' in serial
        assert 'IHK-SMP: guest boot progress os=0' in serial
    states = re.findall(r'NATIVE_OS_SYSFS (x86_64|i386) PASS checks=(\d+) setup_completed=' + ('0' if mode == 'prepare' else '1'), serial)
    assert len(states) == (4 if mode == 'prepare' else 1), states
    expected_checks = 101 if mode == 'prepare' else 2
    assert all(int(count) == expected_checks for _, count in states), states
    record['sysfs_namespace_checks'] = sum(int(count) for _, count in states)
    record['sysfs_service_completed'] = mode != 'prepare'
    if mode != 'prepare':
        # printk is repeated by the final dmesg dump: four records = two loads.
        assert serial.count('MCKERNEL_OS_DEVICE_VERIFY PASS checks=15 callbacks=5 parent=mcos0 generation=1') == 4
        record['device_borrow_checks'] = 30
        record['device_borrow_callbacks'] = 10
    assert serial.count('MCKERNEL_VDSO_VERIFY PASS ') == 4
    assert serial.count('MCKERNEL_VDSO_VERIFY UNLOAD read_only=1 text_unchanged=1') == 4
    record['live_vdso_exports'] = dict(module_cycles=2, samples=32, read_only=True, service_completed=mode != 'prepare')
    if mode != 'prepare':
        exec(textwrap.dedent(Path('/work/native-sysfs-setup-os-validation.inc').read_text()), globals())
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item, item
    record.update(status='PASS', scope=('Unstarted preparation, independent physical snapshots and resource restoration' if mode == 'prepare' else 'Actual vDSO and sysfs setup completion, then pending remote file creation; full runtime/boot/applications remain open'))
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    if mode != 'prepare' and stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
    if stream is not None: stream.close()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
