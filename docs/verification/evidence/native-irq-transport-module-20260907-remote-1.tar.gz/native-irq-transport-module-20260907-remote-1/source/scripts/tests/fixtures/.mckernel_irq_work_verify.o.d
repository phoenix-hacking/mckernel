/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/.mckernel_irq_work_verify.o.d: /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.rs /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/llist.rs /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/smp_ikc.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.o: /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.rs /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/llist.rs /work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/smp_ikc.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.rs:
/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/llist.rs:
/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/../../../kernel/rust/smp_ikc.rs:
./rust/libcore.rmeta:
./rust/libkernel.rmeta:
./rust/liballoc.rmeta:
./rust/libcompiler_builtins.rmeta:
./rust/libmacros.so:
./rust/libbindings.rmeta:
./rust/libuapi.rmeta:
./rust/libbuild_error.rmeta:
