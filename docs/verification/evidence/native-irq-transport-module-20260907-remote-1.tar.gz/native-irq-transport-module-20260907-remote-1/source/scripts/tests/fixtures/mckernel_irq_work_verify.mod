/work/native-irq-transport-module-20260907-remote-1/source/scripts/tests/fixtures/mckernel_irq_work_verify.o
