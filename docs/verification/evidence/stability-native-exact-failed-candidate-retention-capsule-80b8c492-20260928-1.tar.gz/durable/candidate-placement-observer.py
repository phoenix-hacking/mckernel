#!/usr/bin/env python3
"""Read-only placement/identity observer for the exact tmpfs candidate."""
import argparse
import os
from pathlib import Path
import stat
import subprocess
import tempfile


def git(repo, *args):
    result = subprocess.run(
        ["/usr/bin/git", "-C", str(repo), *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={
            "PATH": "/usr/bin:/bin",
            "HOME": "/nonexistent",
            "LANG": "C",
            "LC_ALL": "C",
            "TZ": "UTC",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_NO_REPLACE_OBJECTS": "1",
            "GIT_TERMINAL_PROMPT": "0",
        },
        check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", "replace"))
    return result.stdout


def index_rows(repo):
    rows = []
    for raw in git(repo, "ls-files", "-s", "-z").split(b"\0"):
        if not raw:
            continue
        metadata, separator, path = raw.partition(b"\t")
        fields = metadata.split(b" ")
        if not separator or len(fields) != 3 or fields[2] != b"0" or not path:
            raise RuntimeError("malformed index row")
        rows.append((fields[0], os.fsdecode(path)))
    return rows


def verify_rows(repo, source, expected_device, rows):
    regular = 0
    shared = []
    wrong_device = []
    for mode, name in rows:
        path = repo / name
        info = os.lstat(str(path))
        if mode == b"160000":
            continue
        if mode == b"120000":
            if not stat.S_ISLNK(info.st_mode):
                raise RuntimeError("tracked symlink changed type: " + name)
            continue
        if mode not in (b"100644", b"100755") or not stat.S_ISREG(info.st_mode):
            raise RuntimeError("tracked file changed type/mode: " + name)
        regular += 1
        if info.st_dev != expected_device:
            wrong_device.append(name)
        original = source / name
        try:
            original_info = os.lstat(str(original))
        except FileNotFoundError:
            continue
        if (info.st_dev, info.st_ino) == (original_info.st_dev, original_info.st_ino):
            shared.append(name)
    if wrong_device or shared:
        raise RuntimeError("placement failure wrong_device=%r shared=%r" %
                           (wrong_device[:3], shared[:3]))
    return regular


def self_test():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        candidate = root / "candidate"
        source = root / "source"
        candidate.mkdir()
        source.mkdir()
        (candidate / "file").write_bytes(b"candidate")
        (source / "file").write_bytes(b"source")
        (candidate / "link").symlink_to("file")
        rows = [(b"100644", "file"), (b"120000", "link")]
        assert verify_rows(candidate, source, candidate.stat().st_dev, rows) == 1
        (source / "file").unlink()
        os.link(str(candidate / "file"), str(source / "file"))
        try:
            verify_rows(candidate, source, candidate.stat().st_dev, rows)
        except RuntimeError as error:
            assert "shared=" in str(error)
        else:
            raise AssertionError("hardlink identity was accepted")
    print("SELF_TEST PASS")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--main-sha")
    parser.add_argument("--ihk-sha")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if None in (args.candidate, args.source, args.main_sha, args.ihk_sha):
        parser.error("candidate, source, main-sha and ihk-sha are required")
    candidate = args.candidate.resolve(strict=True)
    source = args.source.resolve(strict=True)
    if git(candidate, "rev-parse", "HEAD").strip().decode("ascii") != args.main_sha:
        raise RuntimeError("main HEAD differs")
    if git(candidate / "ihk", "rev-parse", "HEAD").strip().decode("ascii") != args.ihk_sha:
        raise RuntimeError("IHK HEAD differs")
    if git(candidate, "status", "--porcelain=1", "--untracked-files=all", "-z"):
        raise RuntimeError("main candidate dirty")
    if git(candidate / "ihk", "status", "--porcelain=1", "--untracked-files=all", "-z"):
        raise RuntimeError("IHK candidate dirty")
    expected_device = Path("/dev/shm").stat().st_dev
    if candidate.stat().st_dev != expected_device or source.stat().st_dev == expected_device:
        raise RuntimeError("candidate/source filesystem placement differs")
    count = verify_rows(candidate, source, expected_device, index_rows(candidate))
    count += verify_rows(candidate / "ihk", source / "ihk", expected_device,
                         index_rows(candidate / "ihk"))
    if not count:
        raise RuntimeError("no regular tracked files")
    print("TRACKED_REGULAR_TMPFS_DISTINCT_IDENTITY", count, expected_device)


if __name__ == "__main__":
    main()
