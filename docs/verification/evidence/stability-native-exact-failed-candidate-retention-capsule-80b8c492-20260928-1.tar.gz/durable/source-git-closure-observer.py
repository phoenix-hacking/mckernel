#!/usr/bin/env python3
"""Fingerprint only Git object/ref/config inputs used by metadata relocation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile


def fingerprint(root):
    root = Path(root).resolve(strict=True)
    rows = []
    for relative in ("objects", "refs"):
        start = root / relative
        if not start.is_dir():
            raise RuntimeError("missing Git closure directory: " + str(start))
        for base, directories, files in os.walk(str(start)):
            directories.sort()
            files.sort()
            for name in files:
                path = Path(base) / name
                if path.is_symlink() or not path.is_file():
                    raise RuntimeError("unsafe Git closure entry: " + str(path))
                info = path.stat()
                rows.append((str(path.relative_to(root)), info.st_size,
                             info.st_mtime_ns, info.st_ino, info.st_dev))
    for relative in ("HEAD", "config", "packed-refs"):
        path = root / relative
        if path.exists():
            if path.is_symlink() or not path.is_file():
                raise RuntimeError("unsafe Git closure scalar: " + str(path))
            info = path.stat()
            rows.append((relative, info.st_size, info.st_mtime_ns,
                         info.st_ino, info.st_dev))
    rows.sort()
    encoded = json.dumps(rows, separators=(",", ":")).encode("utf-8")
    return len(rows), hashlib.sha256(encoded).hexdigest()


def self_test():
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        (root / "objects" / "aa").mkdir(parents=True)
        (root / "refs" / "heads").mkdir(parents=True)
        (root / "objects" / "aa" / "object").write_bytes(b"one")
        (root / "refs" / "heads" / "main").write_text("abc\n")
        (root / "HEAD").write_text("ref: refs/heads/main\n")
        before = fingerprint(root)
        (root / "objects" / "aa" / "object").write_bytes(b"changed")
        after = fingerprint(root)
        assert before != after
    print("SELF_TEST PASS")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path)
    parser.add_argument("--label")
    parser.add_argument("--expected")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.root is None or args.label is None:
        parser.error("root and label are required")
    count, digest = fingerprint(args.root)
    print("SOURCE_CLOSURE", args.label, count, digest)
    if args.expected is not None and digest != args.expected:
        raise SystemExit("source closure changed")


if __name__ == "__main__":
    main()
