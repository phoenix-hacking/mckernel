import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/holden/mckernel')
CAPTURES = [
    Path('/tmp/stability-phase-parser-validation-20260913-1'),
    Path('/tmp/stability-phase-parser-tests-sskvb9zv'),
    Path('/tmp/stability-phase-parser-validation-20260913-2'),
    Path('/tmp/stability-phase-parser-tests-z5ovle4j'),
    Path('/tmp/stability-phase-stager-source-review-20260913-epwww829'),
]
OUTPUT = ROOT / 'docs/verification/stability-phase-parser-validation-20260913.json'
ARCHIVE = ROOT / 'docs/verification/evidence/stability-phase-parser-validation-20260913.tar.gz'
REVIEW = CAPTURES[-1] / 'final-review.json'
PRINT = Path('/home/holden/mckernel-work/scratch/native-source/linux-6.12.0-211.44.1.el10_2/rust/kernel/print.rs')
MODULE = Path('/home/holden/mckernel-work/scratch/stability-transport-fault-module-20260913-prepublish-hard-3')

def identity(path, data=None):
    data = path.read_bytes() if data is None else data
    return {'path': str(path), 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

if OUTPUT.exists() or ARCHIVE.exists():
    raise RuntimeError('immutable output already exists')
inputs = json.loads((CAPTURES[2] / 'inputs.json').read_text())
for item in inputs['inputs']:
    observed = identity(ROOT / item['path'])
    if (observed['size'], observed['sha256']) != (item['size'], item['sha256']):
        raise RuntimeError('frozen input changed: ' + item['path'])
if identity(REVIEW)['sha256'] != '411ad6fccb7c91f2e1f17384b7addc3070a8108939e40a9d3993f4a36a3ed09e':
    raise RuntimeError('peer review identity changed')

members = {}
for directory in CAPTURES:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            members[directory.name + '/' + str(path.relative_to(directory))] = (path, path.read_bytes())
members['retention-helper/build.py'] = (Path(__file__), Path(__file__).read_bytes())
members['pinned-kernel/rust/kernel/print.rs'] = (PRINT, PRINT.read_bytes())
compiled_producers = []
for name in ('application_syscall.rs', 'smp_application_syscall.rs', 'smp_application.rs',
             'smp_service.rs', 'sysfs_memory.rs', 'mcctrl_process.rs', 'stability_observer.rs', 'stability_phase.rs'):
    path = MODULE / 'staged-source' / name
    data = path.read_bytes()
    members['compiled-producers/' + name] = (path, data)
    compiled_producers.append(identity(path, data))
manifest = []
with ARCHIVE.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, (path, data) in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
                manifest.append({'member': name, 'original_identity': identity(path, data)})
result = json.loads((CAPTURES[2] / 'result.json').read_text())
record = {
    'schema_version': 1,
    'record_kind': 'native_phase_fault_parser_validation',
    'status': 'INDEPENDENT_SOURCE_REVIEW_AND_LOCAL_METADATA_TESTS_PASS',
    'application_acceptance': False,
    'production_gate_credit': False,
    'guest_execution_performed_by_this_lane': False,
    'pinned_container_validation_in_this_record': False,
    'final_inputs': inputs,
    'independent_review': identity(REVIEW),
    'independent_review_scope': 'Source-only, no reviewer tests/compilation/guest; exact final parser/test/doc hashes; original request target/number/all arguments correction independently rechecked.',
    'final_local_test': {**result, 'test_count': 15, 'unittest_elapsed_seconds': 0.781,
                         'stdout': identity(CAPTURES[2] / 'stdout.bin'), 'stderr': identity(CAPTURES[2] / 'stderr.bin')},
    'original_local_test': {'test_count': 12, 'returncode': 0, 'unittest_elapsed_seconds': 0.905,
                            'inputs': identity(CAPTURES[0] / 'inputs.json'),
                            'stdout': identity(CAPTURES[0] / 'stdout.bin'), 'stderr': identity(CAPTURES[0] / 'stderr.bin'),
                            'scope': 'Original passing tests predate source-review hardening. Original source and all synthetic captures retained unchanged.'},
    'unexpected_test_failures': [],
    'corrected_source_findings': [
        'Full fault timestamp comparison alone did not constrain raw event positions relative to AcceptedReturn/RET; prefix now enforces native position and stage ordering.',
        'Prefix RET evidence was only schema-checked; original key, CPU/value, mode result, duplicate flags and phase/time brackets now checked without requiring future records.',
        'Returning CALL/DELIVERY alone did not bind the selected WORKER inventory or original terminal TID; same-domain worker delivery/completion binding now enforced.',
        'Mode1 retained timer could differ from an already observed AcceptedReturn timer; all retained terminal calls preserve any previously observed timer.',
        'Independent reviewer found immutable Request target/number/full arguments could drift while selection fields remained equal; every retained selected delivery now matches the original request.'
    ],
    'native_prefix_policy': {
        'owner_phase_fault_module': 'ihk_smp_x86_64', 'ret_module': 'mcctrl',
        'pinned_print_source': identity(PRINT),
        'format_evidence': 'rust/kernel/print.rs print_macro passes crate::__LOG_PREFIX to fixed %s: %pA printk format; exact current module declaration inputs included.',
        'raw_identity': 'Original complete bytes retained; only exact known producer label removed in derived canonical capture; original/canonical per-marker-line SHA-256 mapping retained.'
    },
    'compiled_producer_source_identities': compiled_producers,
    'compiled_producer_prior_record': identity(ROOT / 'docs/verification/stability-observer-stack-review-20260913-3.json'),
    'interfaces': ['canonicalize_line(text)', 'canonicalize_capture(raw)',
                   'parse_envelopes(raw, *, mode, nonce_low, nonce_high)',
                   'validate_capture(raw, *, mode, nonce_low, nonce_high, owner_contract)'],
    'supported_modes': ['prepublish-hard', 'postpublish-notify', 'recoverable-backpressure', 'permanent-backpressure'],
    'limits': {'raw_bytes': 16777216, 'lines': 65536, 'line_bytes': 2048, 'marker_records': 4096,
               'fault_events': 40, 'real_send_records': 32, 'completed_phase_envelopes': 4},
    'remaining_evidence_limits': [
        'Always metadata-only; owner contract payload counts must be frozen independently and never inferred from synthetic fixtures or phase labels.',
        'AcceptedReturn barrier count0 and missing publication_since are legitimate source races. Recovery without an observed original production timer remains METADATA_MATCH_WITH_MISSING_TIMER.',
        'Automatic AcceptedReturn snapshot release does not guarantee a host-stopped physical prepublication response capture, especially modes2/3; that separate gate remains open.',
        'Never reread the original response after publication or release. No physical response/ring, physical ring saturation, host task/UART ACK or guest provenance proof is supplied by this parser.',
        'Launcher rawwait, original RET bounds, same-OS eight-HELLO provenance and actual kernel/module/image/hook identities require independent retained runtime evidence.',
        'Owner domains and atomic counters are sampled independently; no simultaneous whole-state snapshot or whole-Linux stack certification is claimed.'
    ],
    'archive': identity(ARCHIVE),
    'archive_members': manifest,
    'retained_capture_paths': [str(path) for path in CAPTURES],
}
OUTPUT.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps({'record': identity(OUTPUT), 'archive': identity(ARCHIVE), 'members': len(manifest)}, indent=2))
