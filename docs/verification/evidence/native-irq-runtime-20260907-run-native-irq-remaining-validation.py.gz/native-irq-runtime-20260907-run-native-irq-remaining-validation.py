from datetime import datetime, timezone
from pathlib import Path
import json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-irq-remaining-validation-20260907-1')
out.mkdir()
commands = [['python3', '-B', '/work/run-native-irq-image-load-guest.py', '/work/native-startup-exact-stage-20260907-1', '/work/native-irq-image-load-guest-20260907-1'],
            ['python3', '-B', '/work/inventory-rust-consumers-irq-20260907.py'],
            ['python3', '-B', '/work/run-native-irq-full-tests.py', '1']]
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[], production_gate_credit=False,
              known_runtime_issue='Default-idle IRQ guest repeat 2 stalled in RCU after first unload; fresh default repeat 4 and polling-idle repeat 3 passed. Cause unresolved; no production acceptance claimed.')
(out / 'run-helper.py').write_bytes(Path(__file__).read_bytes())
try:
    for index, command in enumerate(commands):
        print('RUN', command, flush=True)
        (out / 'phase').write_text(str(index) + ' ' + repr(command) + '\n')
        with (out / (str(index) + '.log')).open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        record['results'].append(dict(command=command, exit_code=result.returncode))
        assert result.returncode == 0, (index, result.returncode)
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print((out / (str(index) + '.log')).read_text()[-10000:], flush=True)
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
