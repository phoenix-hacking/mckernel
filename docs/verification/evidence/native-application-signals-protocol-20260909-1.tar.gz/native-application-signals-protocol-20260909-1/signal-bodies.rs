const EFAULT: CInt = 14;
const RFLAGS_TF: CULong = 1 << 8;
const TRAP_TRACE: CInt = 2;
const SIGTRAP: CInt = 5;
type SyscallCopyFromUserFn = unsafe extern "C" fn(*mut u8, CULong, SizeT) -> CLong;
type SyscallForwardContextFn = unsafe extern "C" fn(CInt, *mut c_void) -> CLong;
type ArchRtSigreturnSetSignalFn = unsafe extern "C" fn(CInt, *mut c_void, *const SigInfo);
type PtraceVoidFn = unsafe extern "C" fn();
type ArchRtSigreturnCheckSignalFn = unsafe extern "C" fn(CInt, *mut c_void, CInt);
type ArchPtraceAllocFn = unsafe extern "C" fn(SizeT, CULong) -> *mut c_void;
type ArchRtSigreturnFreeFn = unsafe extern "C" fn(*mut c_void);
type ArchRtSigreturnXrstorFn = unsafe extern "C" fn(*mut c_void);
#[repr(C)]
struct RtSigreturnFrame {
    flags: CULong,
    link: *mut c_void,
    sigstack: SigStack,
    regs: [CULong; 23],
    fpregs: *mut c_void,
    reserve: [CULong; 8],
    sigrc: CULong,
    sigmask: CULong,
    num: CInt,
    restart: CInt,
    ss: CULong,
    info: SigInfo,
}
const RTSIG_REG_R8: usize = 0;
const RTSIG_REG_R9: usize = 1;
const RTSIG_REG_R10: usize = 2;
const RTSIG_REG_R11: usize = 3;
const RTSIG_REG_R12: usize = 4;
const RTSIG_REG_R13: usize = 5;
const RTSIG_REG_R14: usize = 6;
const RTSIG_REG_R15: usize = 7;
const RTSIG_REG_RDI: usize = 8;
const RTSIG_REG_RSI: usize = 9;
const RTSIG_REG_RBP: usize = 10;
const RTSIG_REG_RBX: usize = 11;
const RTSIG_REG_RDX: usize = 12;
const RTSIG_REG_RAX: usize = 13;
const RTSIG_REG_RCX: usize = 14;
const RTSIG_REG_RSP: usize = 15;
const RTSIG_REG_RIP: usize = 16;
const RTSIG_REG_RFLAGS: usize = 17;
const RTSIG_REG_ERROR: usize = 19;
const RTSIG_REG_OLDMASK: usize = 21;
unsafe fn rt_sigreturn_zero_siginfo(info: *mut SigInfo) {
    let dst = info.cast::<u8>();
    let mut offset = 0usize;

    while offset < size_of::<SigInfo>() {
        write_volatile(dst.add(offset), 0);
        offset += 1;
    }
}
pub unsafe extern "C" fn arch_rt_sigreturn_body_result(
    thread: *mut u8,
    regs: *mut X86UserContext,
    sigmask_offset: SizeT,
    sigstack_offset: SizeT,
    sigstack_size: SizeT,
    frame_size: SizeT,
    xsave_size: CInt,
    nowait_flag: CULong,
    copy_from_fn: Option<SyscallCopyFromUserFn>,
    syscall_fn: Option<SyscallForwardContextFn>,
    set_signal_fn: Option<ArchRtSigreturnSetSignalFn>,
    check_need_resched_fn: Option<PtraceVoidFn>,
    check_signal_fn: Option<ArchRtSigreturnCheckSignalFn>,
    alloc_fn: Option<ArchPtraceAllocFn>,
    free_fn: Option<ArchRtSigreturnFreeFn>,
    xrstor_fn: Option<ArchRtSigreturnXrstorFn>,
) -> CLong {
    if thread.is_null() || regs.is_null() {
        return -(EFAULT as CLong);
    }
    if frame_size != size_of::<RtSigreturnFrame>() || sigstack_size != size_of::<SigStack>() {
        return -(EFAULT as CLong);
    }

    let Some(copy_from) = copy_from_fn else {
        return -(EFAULT as CLong);
    };

    let sigsp = (*regs).gpr.rsp as *const RtSigreturnFrame;
    if sigsp.is_null() {
        return -(EFAULT as CLong);
    }

    let mut frame_storage = MaybeUninit::<RtSigreturnFrame>::uninit();
    if copy_from(
        frame_storage.as_mut_ptr().cast::<u8>(),
        sigsp as CULong,
        frame_size,
    ) != 0
    {
        return -(EFAULT as CLong);
    }
    let frame = &*frame_storage.as_ptr();
    // Native consumers never re-read a userspace frame after the checked copy.
    #[cfg(native_linux_irq_work_v6_12)]
    let sigsp = frame as *const RtSigreturnFrame;

    let gpr = &mut (*regs).gpr;
    gpr.r15 = frame.regs[RTSIG_REG_R15];
    gpr.r14 = frame.regs[RTSIG_REG_R14];
    gpr.r13 = frame.regs[RTSIG_REG_R13];
    gpr.r12 = frame.regs[RTSIG_REG_R12];
    gpr.rbp = frame.regs[RTSIG_REG_RBP];
    gpr.rbx = frame.regs[RTSIG_REG_RBX];
    gpr.r11 = frame.regs[RTSIG_REG_R11];
    gpr.r10 = frame.regs[RTSIG_REG_R10];
    gpr.r9 = frame.regs[RTSIG_REG_R9];
    gpr.r8 = frame.regs[RTSIG_REG_R8];
    gpr.rax = frame.regs[RTSIG_REG_RAX];
    gpr.rcx = frame.regs[RTSIG_REG_RCX];
    gpr.rdx = frame.regs[RTSIG_REG_RDX];
    gpr.rsi = frame.regs[RTSIG_REG_RSI];
    gpr.rdi = frame.regs[RTSIG_REG_RDI];
    gpr.orig_rax = frame.regs[RTSIG_REG_ERROR];
    gpr.rip = frame.regs[RTSIG_REG_RIP];
    gpr.rflags = frame.regs[RTSIG_REG_RFLAGS];
    gpr.rsp = frame.regs[RTSIG_REG_RSP];

    *thread.add(sigmask_offset).cast::<CULong>() = frame.regs[RTSIG_REG_OLDMASK];
    #[cfg(native_linux_irq_work_v6_12)]
    crate::native_signal::restore(
        &mut *thread.add(sigstack_offset).cast::<SigStack>(),
        &frame.sigstack,
        frame.regs[RTSIG_REG_RSP],
    );
    #[cfg(not(native_linux_irq_work_v6_12))]
    {
    let sigstack_src = (&frame.sigstack as *const SigStack).cast::<u8>();
    let sigstack_dst = thread.add(sigstack_offset);
    let mut sigstack_byte = 0usize;
    while sigstack_byte < sigstack_size {
        write_volatile(
            sigstack_dst.add(sigstack_byte),
            read_volatile(sigstack_src.add(sigstack_byte)),
        );
        sigstack_byte += 1;
    }
    }

    if (*sigsp).restart != 0 {
        let Some(call_syscall) = syscall_fn else {
            return -(EFAULT as CLong);
        };
        return call_syscall((*sigsp).num, regs.cast::<c_void>());
    }

    if ((*regs).gpr.rflags & RFLAGS_TF) != 0 {
        let Some(set_signal) = set_signal_fn else {
            return -(EFAULT as CLong);
        };
        let Some(check_need_resched) = check_need_resched_fn else {
            return -(EFAULT as CLong);
        };
        let Some(check_signal) = check_signal_fn else {
            return -(EFAULT as CLong);
        };
        let mut info_storage = MaybeUninit::<SigInfo>::uninit();
        let info = info_storage.as_mut_ptr();

        (*regs).gpr.rax = (*sigsp).sigrc;
        (*regs).gpr.rflags &= !RFLAGS_TF;
        rt_sigreturn_zero_siginfo(info);
        (*info).si_code = TRAP_TRACE;
        set_signal(SIGTRAP, regs.cast::<c_void>(), info as *const SigInfo);
        check_need_resched();
        check_signal(0, regs.cast::<c_void>(), -1);
    }

    if !frame.fpregs.is_null() && xsave_size != 0 {
        let Some(alloc) = alloc_fn else {
            return -(EFAULT as CLong);
        };
        let Some(free) = free_fn else {
            return -(EFAULT as CLong);
        };
        let Some(xrstor) = xrstor_fn else {
            return -(EFAULT as CLong);
        };

        let fpregs = alloc((xsave_size as SizeT).wrapping_add(64), nowait_flag);
        if !fpregs.is_null() {
            let aligned = (((fpregs as usize) + 63) & !63usize) as *mut c_void;

            if copy_from(
                aligned.cast::<u8>(),
                frame.fpregs as CULong,
                xsave_size as SizeT,
            ) != 0
            {
                #[cfg(native_linux_irq_work_v6_12)]
                free(fpregs);
                return -(EFAULT as CLong);
            }
            xrstor(aligned);
            free(fpregs);
        }
    }

    (*sigsp).sigrc as CLong
}
