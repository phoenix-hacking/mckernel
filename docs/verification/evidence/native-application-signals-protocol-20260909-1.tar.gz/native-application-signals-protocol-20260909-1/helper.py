from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work');linux=work/'native-source/linux-6.12.0-211.44.1.el10_2'
out=work/('native-application-signals-protocol-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),inputs=[],commands=[],extracted_bodies=[],scope='Pinned Linux stack predicates/configuration and actual native stack placement/publication/sigreturn bodies; legacy return behavior retained; controlled user-copy and XSAVE. Actual guest pending.')
def identity(path):return dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def extract(path,pattern,name):
    data=path.read_text();match=re.search(pattern,data,re.M);assert match,name
    start=match.start();end=data.index('{',start)+1;depth=1
    while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
    body=data[start:end];record['extracted_bodies'].append(dict(source=str(path),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()));return body+'\n'
def run(label,args):
    print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode));assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-8000:])
try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['kernel/rust/native_signal.rs','kernel/rust/syscall_policy.rs','kernel/rust/lib.rs','kernel/rust/abi.rs','kernel/CMakeLists.txt','arch/x86_64/kernel/syscall.c','arch/x86_64/kernel/include/signal.h','scripts/tests/fixtures/native-application-signals.rs','scripts/tests/fixtures/native-application-signals.c','kernel/rust/tests/run_equivalence.sh']
    for name in names:
        path=out/'original-inputs'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,path);record['inputs'].append(identity(path))
    for name in ['include/linux/sched/signal.h','include/linux/signal.h','arch/x86/kernel/signal.c','arch/x86/kernel/signal_64.c','kernel/signal.c']:
        path=out/'linux-reference'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(linux/name,path);record['inputs'].append(identity(path))
    for name in ['native_signal.rs','abi.rs']:shutil.copyfile(out/'original-inputs/kernel/rust'/name,out/name)
    for name in ['native-application-signals.rs','native-application-signals.c']:shutil.copyfile(out/'original-inputs/scripts/tests/fixtures'/name,out/name)
    rust=out/'original-inputs/kernel/rust/syscall_policy.rs';data=rust.read_text();body=''
    for name in ['EFAULT','RFLAGS_TF','TRAP_TRACE','SIGTRAP']:
        match=re.search(r'^const '+name+r':[^;]+;',data,re.M);assert match;body+=match[0]+'\n'
    for name in ['SyscallCopyFromUserFn','SyscallForwardContextFn','ArchRtSigreturnSetSignalFn','PtraceVoidFn','ArchRtSigreturnCheckSignalFn','ArchPtraceAllocFn','ArchRtSigreturnFreeFn','ArchRtSigreturnXrstorFn']:
        match=re.search(r'^type '+name+r'\b[^;]+;',data,re.M);assert match;body+=match[0]+'\n'
    body+='#[repr(C)]\n'+extract(rust,r'^struct RtSigreturnFrame \{','RtSigreturnFrame')
    body+='\n'.join(re.findall(r'^const RTSIG_REG_\w+[^;]+;',data,re.M))+'\n'
    body+=extract(rust,r'^unsafe fn rt_sigreturn_zero_siginfo\(','rt_sigreturn_zero_siginfo')
    body+=extract(rust,r'^pub unsafe extern "C" fn arch_rt_sigreturn_body_result\(','arch_rt_sigreturn_body_result')
    (out/'signal-bodies.rs').write_text(body)
    hdr=out/'linux-reference/include/linux/sched/signal.h';sig=out/'linux-reference/kernel/signal.c';c=''
    for name in ['__on_sig_stack','on_sig_stack','sas_ss_flags']:c+=extract(hdr,r'^static inline int '+name+r'\(',name)
    c+=extract(sig,r'^static int\ndo_sigaltstack \(','do_sigaltstack')
    (out/'linux-signal-reference.h').write_text(c)
    vectors=[]
    for old in [(0x20000,65536,0),(0x20000,65536,1),(0,0,2)]:
        for sp in [0,0x20000,0x20001,0x21000,0x2ffff,0x30000,0x30001,0x70000,(1<<64)-1]:
            for newflags in [0,1,2,3,6,16,(1<<64)-1]:
                for size in [0,2047,2048,65536,(1<<64)-1]:
                    for present in [0,1]:
                        for output in [0,1]:
                            vectors.append(struct.pack('<10Q',*old,sp,0x40000,size,newflags,present,output,0))
    (out/'vectors.bin').write_bytes(b''.join(vectors));record['vectors']=len(vectors)
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(out/'native_signal.rs'),str(out/'native-application-signals.rs')])
    run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(out/'native-application-signals.c'),'-o',str(out/'c-reference')])
    run('c-reference',[str(out/'c-reference'),str(out/'vectors.bin')])
    for profile in ['legacy','native']:
        args=['rustc','--edition','2021','-D','warnings','--test',str(out/'native-application-signals.rs'),'-o',str(out/(profile+'-tests'))]
        if profile=='native':args+=['--cfg','native_linux_irq_work_v6_12']
        run(profile+'-build',args);run(profile+'-tests',[str(out/(profile+'-tests')),'--nocapture'])
    record['test_summary']={profile:[line for line in (out/(profile+'-tests.log')).read_text().splitlines() if line.startswith('test result:')] for profile in ['legacy','native']}
    record['compiler_inputs']=[identity(out/name) for name in ['native_signal.rs','abi.rs','native-application-signals.rs','signal-bodies.rs','native-application-signals.c','linux-signal-reference.h','vectors.bin','c-reference.log']]
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
