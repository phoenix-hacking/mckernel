import base64
import hashlib
import json
import pathlib
import re
import sys
from collections import deque
from elftools.elf.elffile import ELFFile

CAPTURE = pathlib.Path(sys.argv[1])
OUT = pathlib.Path(sys.argv[2])

def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), size=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def mapped(path):
    return pathlib.Path('/home/holden/mckernel-work/scratch') / pathlib.Path(path).relative_to('/work')

def require_ref(row):
    path = mapped(row['path'])
    now = identity(path)
    if any(now[k] != row[k] for k in ('size', 'sha256')):
        raise ValueError('retained input changed: ' + str(path))
    return now

def parse_functions(path):
    functions = {}
    section, current = None, None
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        match = re.match(r'Disassembly of section (.+):', line)
        if match:
            section, current = match[1], None
            continue
        match = re.match(r'^([0-9a-f]+) <(.+)>:$', line)
        if match:
            current = None
            if not match[2].startswith('__pfx_'):
                current = dict(name=match[2], section=section, address=int(match[1], 16), line=line_number, instructions=[])
                functions[(section, current['address'])] = current
            continue
        if current is None:
            continue
        match = re.match(r'^\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*(\S.*)$', line)
        if match:
            op = match[3].split('#', 1)[0].strip()
            current['instructions'].append(dict(address=int(match[1],16), width=len(match[2].split()), op=op, line=line_number))
    return functions

def relocations(path, functions):
    result = {}
    with path.open('rb') as stream:
        elf = ELFFile(stream)
        for section in elf.iter_sections():
            if section['sh_type'] != 'SHT_RELA':
                continue
            owner = elf.get_section(section['sh_info']).name
            table = elf.get_section(section['sh_link'])
            for relocation in section.iter_relocations():
                symbol = table.get_symbol(relocation['r_info_sym'])
                target = None
                target_section = symbol['st_shndx']
                # x86 rel32 uses S+A-P; decoded instruction displacement ends P+4.
                if isinstance(target_section, int) and relocation['r_info_type'] in (2,4):
                    target = (elf.get_section(target_section).name, symbol['st_value'] + relocation['r_addend'] + 4)
                name = functions[target]['name'] if target in functions else symbol.name
                result[(owner, relocation['r_offset'])] = dict(symbol=symbol.name, name=name, relocation_type=relocation['r_info_type'], target=list(target) if target in functions else None, addend=relocation['r_addend'])
    return result

def analyze(function, relocs):
    insns = function['instructions']
    if not insns:
        return dict(error='empty function')
    by_address = {r['address']:i for i,r in enumerate(insns)}
    todo, seen = deque([(0,0,None)]), set()
    maximum, calls, unknowns, stack_ops = 0, {}, set(), {}
    while todo:
        index, depth, frame_pointer = todo.popleft()
        if index >= len(insns) or (index,depth,frame_pointer) in seen:
            continue
        seen.add((index,depth,frame_pointer))
        if len(seen)>100000 or not -4096 <= depth <= 65536:
            unknowns.add('control-flow stack state exploration limit')
            break
        insn = insns[index]
        op = insn['op']; mnemonic, _, operands = op.partition(' '); operands=operands.strip()
        relocation = next((relocs[(function['section'],insn['address']+off)] for off in range(insn['width']) if (function['section'],insn['address']+off) in relocs),None)
        next_depth, next_frame = depth, frame_pointer
        is_stack=False
        if mnemonic.startswith('push'):
            next_depth += 8;is_stack=True
        elif mnemonic.startswith('pop'):
            next_depth -= 8;is_stack=True
        elif operands.endswith(',%rsp'):
            is_stack=True
            immediate = re.match(r'\$(0x[0-9a-f]+|[0-9]+),%rsp$',operands)
            if mnemonic in ('sub','add') and immediate:
                next_depth += int(immediate[1],0) * (1 if mnemonic=='sub' else -1)
            elif mnemonic=='mov' and operands=='%rbp,%rsp' and frame_pointer is not None:
                next_depth=frame_pointer
            elif mnemonic=='lea':
                displacement=re.match(r'(-?0x[0-9a-f]+|-?[0-9]+)\(%rsp\),%rsp$',operands)
                if displacement:next_depth-=int(displacement[1],0)
                else:unknowns.add('unresolved stack assignment: '+op)
            else:unknowns.add('unresolved stack assignment: '+op)
        elif mnemonic=='mov' and operands=='%rsp,%rbp':
            next_frame=depth
        elif mnemonic=='leave':
            is_stack=True
            if frame_pointer is None:unknowns.add('unresolved leave')
            else:next_depth=frame_pointer-8
        if is_stack:
            stack_ops[insn['address']]=dict(line=insn['line'],address=hex(insn['address']),op=op)
        maximum=max(maximum,depth,next_depth)
        target_match=re.match(r'^([0-9a-f]+)\s+<',operands)
        target_address=int(target_match[1],16) if target_match else None
        is_call=mnemonic.startswith('call')
        is_jump=mnemonic.startswith('j')
        local_jump=is_jump and relocation is None and target_address in by_address
        if is_call or (is_jump and not local_jump):
            key=(insn['address'],depth)
            target=relocation['target'] if relocation else None
            # Final module-local direct calls can already have resolved rel32.
            if not relocation and target_address is not None:
                target=[function['section'],target_address]
            calls[key]=dict(line=insn['line'],address=hex(insn['address']),op=op,kind='call' if is_call else 'tail_or_external_branch',depth_before=depth,return_address_bytes=8 if is_call else 0,target=target,relocation=relocation)
        if mnemonic in ('ret','retq','ud2','hlt'):
            continue
        if is_jump:
            if local_jump:todo.append((by_address[target_address],next_depth,next_frame))
            if mnemonic in ('jmp','jmpq'):continue
        todo.append((index+1,next_depth,next_frame))
    return dict(maximum_local_stack_bytes=maximum,with_entry_return_address_bytes=maximum+8,unknown_stack_assignments=sorted(unknowns),stack_instructions=list(stack_ops.values()),calls=list(calls.values()),states_visited=len(seen))

record=json.loads((CAPTURE/'record.json').read_text())
bound=[require_ref(r['retained']) for r in record['retained_compiler_bindings']]
bound.extend(require_ref(r) for r in record['compiled_modules']+record['fixture_inputs']+record['overlays'])
modules={}
for name in ('ihk-smp-x86_64','mcctrl'):
    dis=CAPTURE/(name+'.ko-demangled-disassembly-collection/stdout.bin')
    report=json.loads((dis.parent/'report.json').read_text())
    require_ref(report['streams']['stdout']['artifact'])
    if report['status']!='COMPLETED' or report['streams']['stdout']['truncated'] or report['wait_status']!={'kind':'exited','code':0}:
        raise ValueError('disassembly collection is not complete')
    funcs=parse_functions(dis)
    rels=relocations(CAPTURE/(name+'.ko'),funcs)
    analyzed=[]
    for function in funcs.values():
        analyzed.append({k:v for k,v in function.items() if k!='instructions'} | analyze(function,rels))
    modules[name]=dict(module=identity(CAPTURE/(name+'.ko')),disassembly=identity(dis),functions=analyzed)
output=dict(schema_version=1,record_kind='compiled-observer-stack-analysis',status='PARTIAL_STATIC_FRAME_ANALYSIS',actual_guest_executed=False,application_acceptance=False,production_gate_credit=False,build_record=identity(CAPTURE/'record.json'),verified_retained_inputs=bound,modules=modules)
OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(output=identity(OUT),verified_retained_inputs=len(bound),module_functions={k:len(v['functions']) for k,v in modules.items()})))
