from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
root=Path('/home/holden/mckernel')
cap=Path('/home/holden/mckernel-work/scratch/stability-transport-fault-module-20260913-prepublish-hard-3')
local=Path('/tmp/stability-observer-stack-review-20260913-3')
def ident(path):
 raw=path.read_bytes()
 return {'path':str(path),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
a=json.loads((local/'analysis.json').read_text())
fs={mod:{f['address']:f for f in v['functions']} for mod,v in a['modules'].items()}
def chain(mod,addresses,expected):
 rows=[]
 for i,address in enumerate(addresses):
  f=fs[mod][address];assert not f['unknown_stack_assignments']
  row={'function':f['name'],'address':hex(address),'entry_disassembly_line':f['line'],'entry_return_bytes':8,'maximum_local_bytes':f['maximum_local_stack_bytes']}
  if i+1<len(addresses):
   edges=[c for c in f['calls'] if c['target']==['.text',addresses[i+1]]]
   assert edges and all(c['kind']=='call' for c in edges)
   row['callsites']=edges;row['counted_local_bytes']=max(c['depth_before'] for c in edges)
  else:row['counted_local_bytes']=f['maximum_local_stack_bytes']
  row['counted_bytes']=row['counted_local_bytes']+8;rows.append(row)
 total=sum(r['counted_bytes'] for r in rows);assert total==expected,(total,expected)
 return {'bytes':total,'module':mod,'rows':rows,'scope':'Known nested module frames only; Linux/callback residuals remain separate.'}
worker=[0x48d20,0x35f70,0x11150,0x30af0,0x2f130,0x23000]
ioctl=[0x22d0,0x4d290,0x3e330,0x30af0,0x2f130,0x23000]
chains={
 'packet_worker_to_mailbox_copy':chain('ihk-smp-x86_64',worker+[0x24570,0x32630],5512),
 'phase_ioctl_to_mailbox_copy':chain('ihk-smp-x86_64',ioctl+[0x24570,0x32630],5832),
 'packet_worker_to_apps':chain('ihk-smp-x86_64',worker+[0x23150],2992),
 'phase_ioctl_to_apps':chain('ihk-smp-x86_64',ioctl+[0x23150],3312),
 'ret_enter_hook':chain('mcctrl',[0xcf0,0x3d60,0x5b00],704),
 'ret_leave_hook':chain('mcctrl',[0xcf0,0x3d60,0x5c90],704),
 'ret_select_hook':chain('mcctrl',[0xcf0,0x2ac0,0x5e20],560)}
build=json.loads((cap/'record.json').read_text());assert build['status']=='PASS_BUILD_ONLY' and build['owner_parser_tests']==19
report_path=cap/'owner-parser-tests-collection/report.json'
tests=json.loads(report_path.read_text())
assert tests['status']=='COMPLETED' and tests['wait_status']=={'kind':'exited','code':0} and tests['raw_wait_status']==0 and tests['cleanup_complete'] is True
for name,row in tests['streams'].items():
 current=ident(cap/'owner-parser-tests-collection'/(name+'.bin'))
 assert all(current[k]==row['artifact'][k] for k in ('size','sha256'))
 assert row['truncated'] is False and row['eof'] is True and row['discarded_observed_bytes']==0
stderr=(cap/'owner-parser-tests-collection/stderr.bin').read_bytes()
assert len(re.findall(rb'^test_.* \.\.\. ok$',stderr,re.M))==19 and b'Ran 19 tests' in stderr and stderr.endswith(b'\nOK\n')
previous_path=root/'docs/verification/stability-observer-stack-review-20260913-2.json'
previous=json.loads(previous_path.read_text())
assert a['modules']['mcctrl']['module']['sha256']==previous['modules']['mcctrl']['module']['sha256']
peer=json.loads((root/'docs/verification/stability-app-row-stack-helper-review-20260913.json').read_text())
for label in ('fixture','parser_test'):
 reference=peer[label]
 matches=[r for r in build['fixture_inputs'] if r['sha256']==reference['sha256'] and r['size']==reference['size']]
 assert len(matches)==1,label
members={}
for path in sorted(local.rglob('*')):
 if path.is_file():members['analysis/'+str(path.relative_to(local))]=path.read_bytes()
members['analysis/retained-analyzer.py']=Path('/tmp/stability-observer-stack-review-inputs/audit.py').read_bytes()
for path in [cap/'record.json',report_path,cap/'owner-parser-tests-collection/stdout.bin',cap/'owner-parser-tests-collection/stderr.bin']:
 members['compiled-capture/'+str(path.relative_to(cap))]=path.read_bytes()
for directory in ('staged-source','source'):
 for path in sorted((cap/directory).rglob('*')):
  if path.is_file():members['compiled-capture/'+str(path.relative_to(cap))]=path.read_bytes()
archive=root/'docs/verification/evidence/stability-observer-stack-review-20260913-3.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:checked={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
assert checked==members
record={'schema_version':1,'record_kind':'stability-compiled-observer-stack-review','review_date':'2026-09-13','status':'MEASURED_APP_HELPER_REDUCTION_WITH_EXPLICIT_KERNEL_RESIDUALS','runtime_authorized':False,'application_acceptance':False,'production_gate_credit':False,'full_linux_stack_bound_verified':False,'further_source_reduction_recommended':False,'build_record':ident(cap/'record.json'),'previous_review':ident(previous_path),'independent_helper_source_review':ident(root/'docs/verification/stability-app-row-stack-helper-review-20260913.json'),'modules':{k:{field:v[field] for field in ('module','disassembly')} for k,v in a['modules'].items()},'retained_input_count':len(a['verified_retained_inputs']),'retained_inputs':a['verified_retained_inputs'],'known_module_chains':chains,'comparison':{'worker_module2_bytes':6760,'worker_module3_bytes':5512,'ioctl_module2_bytes':7080,'ioctl_module3_bytes':5832,'reduction_each_bytes':1248,'worker_module1_bytes':9416,'worker_reduction_from_module1_bytes':3904,'app_outer_module2_bytes':1472,'app_outer_module3_bytes':224,'app_row_helper_module3_bytes':1536,'app_row_helper_is_sibling_to_mailbox':True,'mailbox_emitter_bytes':3760,'mailbox_copier_bytes':296,'mcctrl_byte_unchanged':True},'verified_parent_parser_tests':{'count':19,'test_report':ident(report_path),'stdout':ident(cap/'owner-parser-tests-collection/stdout.bin'),'stderr':ident(cap/'owner-parser-tests-collection/stderr.bin'),'raw_wait_status':0,'wait_status':tests['wait_status'],'complete_untruncated_streams':True,'compiled_fixture_binding':peer['fixture'],'tested_source_binding':peer['parser_test'],'scope':'Parent pinned process/parser infrastructure tests, not guest or application acceptance.'},'selected_linux_formatting_context':{'thread_size_bytes':16384,'reference':ident(previous_path),'direct_initial_formatting_prefix_upper_bytes':797,'worker_mailbox_print_module_prefix_bytes':5216,'ioctl_mailbox_print_module_prefix_bytes':5536,'worker_with_selected_linux_prefix_bytes':6013,'ioctl_with_selected_linux_prefix_bytes':6333,'scope':'Inherited exact pinned Linux analysis of only the direct initial vsnprintf path through core::fmt::write. These values stop before dynamic callbacks and do not form a whole-Linux upper bound.'},'residuals':['Dynamic core::fmt/Debug callbacks and their nested formatting frames.','Alternate printk_sprint formatting path, console flush and console-driver descendants.','Linux syscall/kthread entry beyond selected module boundaries, lock slowpaths/scheduler, interrupts/NMI/mitigation behavior and deeper RETURN backend handling.','No stack runtime watermark or actual guest verification is supplied by this review. Parent controls isolated guest validation and must retain the residual claim.'],'recommendation':'The measured minimal observer reductions are complete for this slice. Continue controlled guest verification under parent gating; no whole-Linux certification or application acceptance is inferred.','retention':{'archive':ident(archive),'members':[{'name':n,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(members.items())],'roundtrip_bytes_verified':True}}
out=root/'docs/verification/stability-observer-stack-review-20260913-3.json'
with out.open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps({'review':ident(out),'archive':ident(archive),'worker_bytes':5512,'ioctl_bytes':5832,'verified_inputs':len(a['verified_retained_inputs']),'parser_tests':19},sort_keys=True))
