from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work')
out=work/'native-irq-transport-retained-20260907-1'
out.mkdir()
record=dict(created_utc=datetime.now(timezone.utc).isoformat(),production_gate_credit=False,mckernel_boot_proven=False,artifacts=[],
    passed=['Exact Linux export patch application and unchanged function bodies', 'Native debug Linux kernel and all three existing native modules',
            'Exact-header queue/work/CPU/APIC call ABI witness and native module ELF/no-SIMD checks',
            'Direct guest producer publication to Linux raised queues; 1024 callbacks across three remote targets and two module cycles',
            'Original local irq_work_queue fixture on the new kernel: 1024 callbacks and two module cycles'],
    limitations=['Guest CPU/boot context and allocator remain mocked; no executing McKernel CPU or IKC handshake',
                 'Earlier intermittent default-idle timer/RCU stall remains unresolved; these passing repeats do not establish its cause',
                 'Patch 0005 still needs authoritative workflow/license and downstream binding integration',
                 'Native boot must retain target CPU, exact OS/module and guest-memory owners through sender stop and callback drain'])
def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        while True:
            data=stream.read(1<<20)
            if not data: break
            value.update(data)
    return value.hexdigest()
def add(path,name):
    target=out/name
    with path.open('rb') as source,target.open('xb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as output:
            while True:
                data=source.read(1<<20)
                if not data: break
                output.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/'+name,source=str(path),size=target.stat().st_size,sha256=digest(target),unpacked_size=path.stat().st_size,unpacked_sha256=digest(path)))
for name in ['native-irq-transport-kernel-20260907-1','native-irq-transport-module-20260907-remote-1',
             'native-irq-transport-module-20260907-remote-2','native-irq-transport-module-20260907-default-1',
             'native-irq-transport-guest-20260907-remote-1','native-irq-transport-guest-20260907-default-1',
             'native-irq-transport-validation-20260907-1','native-irq-transport-validation-20260907-2']:
    path=work/name
    metadata=json.loads((path/'record.json').read_text())
    record.setdefault('captures',[]).append(dict(directory=name,status=metadata.get('status',metadata.get('exit_code')),source_parent=metadata.get('source_parent'),started_utc=metadata['started_utc'],finished_utc=metadata.get('finished_utc',metadata.get('updated_utc'))))
    target=out/(name+'.tar.gz')
    with tarfile.open(target,'w:gz') as archive: archive.add(path,arcname=name)
    record['artifacts'].append(dict(path='docs/verification/evidence/'+target.name,source=str(path),size=target.stat().st_size,sha256=digest(target)))
    add(path/'record.json',name+'-record.json.gz')
    if (path/'serial.log').exists(): add(path/'serial.log',name+'-serial.log.gz')
for name in ['prepare-native-irq-transport-source.py','build-native-irq-transport-kernel.py','build-native-irq-transport-module.py',
             'run-native-irq-transport-guest.py','run-native-irq-transport-validation.py','run-native-irq-transport-validation-2.py','retain-native-irq-transport.py']:
    add(work/name,'native-irq-transport-20260907-'+name+'.gz')
for relative in ['kernel/rust/smp_ikc.rs','kernel/rust/llist.rs','scripts/tests/fixtures/mckernel_irq_work_verify.rs','scripts/tests/fixtures/mckernel_irq_work_layout.c','host-kernel/kbuild/patches/0005-irq-work-export-remote-queue-primitives.patch']:
    path=repo/relative
    record.setdefault('source_inputs',[]).append(dict(path=relative,size=path.stat().st_size,sha256=digest(path)))
for row in record['artifacts']:
    digest_value,size=hashlib.sha256(),0
    with gzip.open(out/Path(row['path']).name,'rb') as stream:
        while True:
            data=stream.read(1<<20)
            if not data: break
            digest_value.update(data);size+=len(data)
    if 'unpacked_size' in row: assert size==row['unpacked_size'] and digest_value.hexdigest()==row['unpacked_sha256']
(out/'native-irq-transport-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained and verified',len(record['artifacts']),'artifacts in',out,flush=True)
