/work/mckernel-native-ultra-images-20260909-2/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-ultra-images-20260909-2/invalid-abi/tmp.resolve_MODULES_END/driver.o

