from pathlib import Path
import hashlib,json
root=Path('/home/holden/mckernel');out=Path(__file__).parent
def identity(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
old_path=root/'docs/verification/stability-observer-stack-review-20260913-3.json'
old=json.loads(old_path.read_text());new=json.loads((out/'analysis.json').read_text())
r=dict(status='RUNNING',scope='Exact compiled known module frame paths; inherited Linux residuals remain unbounded',application_acceptance=False,transport_acceptance=False,full_linux_stack_bound_verified=False,chains={},inputs=[identity(old_path),identity(out/'analysis.json')])
try:
 for label,prior in old['known_module_chains'].items():
  functions=new['modules'][prior['module']]['functions'];rows=[]
  selected=[]
  for item in prior['rows']:
   found=[f for f in functions if f['name']==item['function']];assert len(found)==1
   assert not found[0]['unknown_stack_assignments'];selected.append(found[0])
  for index,f in enumerate(selected):
   if index+1<len(selected):
    calls=[c for c in f['calls'] if c['target']==['.text',selected[index+1]['address']]]
    assert calls and all(c['kind']=='call' for c in calls)
    local=max(c['depth_before'] for c in calls)
   else:calls=[];local=f['maximum_local_stack_bytes']
   rows.append(dict(function=f['name'],address=f['address'],local_bytes=local,entry_return_bytes=8,maximum_local_bytes=f['maximum_local_stack_bytes'],callsites=calls))
  total=sum(x['local_bytes']+8 for x in rows)
  r['chains'][label]=dict(bytes=total,prior_bytes=prior['bytes'],rows=rows)
  assert total<=prior['bytes'],(label,total,prior['bytes'])
 assert new['modules']['mcctrl']['module']['sha256']==old['modules']['mcctrl']['module']['sha256']
 r['mcctrl_byte_identical']=True
 r['linux_formatting_context']=old['selected_linux_formatting_context']
 r['residuals']=old['residuals']
 r['status']='KNOWN_MODULE_FRAME_PATHS_NOT_INCREASED_WITH_EXPLICIT_KERNEL_RESIDUALS'
except BaseException as e:r.update(status='FAIL',error=str(e));raise
finally:
 (out/'comparison.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 print(r['status']);print({k:(v['bytes'],v['prior_bytes']) for k,v in r['chains'].items()})
