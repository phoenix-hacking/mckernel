"""Build the declared native owned startup-table stage in the bounded debug configuration.

Preserve the passing prototype, then rebuild kernel and modules with the
reviewed objtool and Linux export patches. This does not award production credit.
"""
from datetime import datetime,timezone
import hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
repo=Path('/workspace')
source=Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build=Path('/work/native-build-base-24a151fe')
evidence=Path('/work/native-startup-exact-stage-20260907-1')
prior=Path('/work/native-image-exact-stage-20260907-1')
if os.getuid()!=1000 or os.sched_getaffinity(0)!={2,3,4,5}:
 raise SystemExit('Use the fixed unprivileged four-CPU runner')
if (build/'.config').read_bytes()!=(prior/'resolved.config').read_bytes():
 raise SystemExit('Memory debug configuration differs from the tested prototype')
def identity(path):
 data=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),size=len(data))
evidence.mkdir()
phase=evidence/'build.phase'
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),configuration_scope='isolated-image-fault-injection-debug-variant',production_gate_credit=False,helper=identity(Path(__file__)))
(evidence/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
stage=source/'drivers/misc/mckernel'; module_root=build/'drivers/misc/mckernel'
try:
 phase.write_text('preserving-prototype\n')
 shutil.copytree(module_root,evidence/'prototype-module-build')
 shutil.copytree(stage,evidence/'prototype-stage')
 shutil.copyfile(Path(__file__),evidence/'build-helper.py')
 # No production source is edited in the prepared Linux tree.
 patch_paths=['host-kernel/kbuild/patches/0003-driver-core-export-device-hotplug-transactions.patch','host-kernel/kbuild/patches/0004-mm-export-memory-hotplug-read-exclusion.patch','host-kernel/rocky/patches/0024-objtool-recognize-rust-1.92-sort-and-vec-panics.patch']
 for relative in patch_paths:
  patch=repo/relative
  subprocess.run(['patch','-d',str(source),'-p1','--batch','--reverse','--dry-run','--fuzz=0','-i',str(patch)],check=True)
  shutil.copyfile(patch,evidence/patch.name)
 stage.rename(source/'drivers/misc/mckernel-startup-prototype-before-declared-20260907-1')
 phase.write_text('staging\n')
 for action in ('--stage-for-evidence','--verify-evidence-stage'):
  subprocess.run(['/usr/bin/python3',str(repo/'scripts/rocky_rust_staging.py'),'--repo',str(repo),action,str(source)],check=True)
 shutil.copytree(stage,evidence/'staged-source')
 for relative in ['scripts/rocky_rust_staging.py','scripts/native_rust_kbuild_link_closure.py','host-kernel/kbuild/stage-manifest.json','host-kernel/contracts/native-rust-unsafe-ffi-ledger-v1.json']:
  target=evidence/'repository-inputs'/relative; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(repo/relative,target)
 for label in ('kernel','module'):
  command=shlex.split((prior/(label+'-build.command')).read_text())
  (evidence/(label+'-build.command')).write_text(shlex.join(command)+'\n')
  phase.write_text('building-'+label+'\n')
  with (evidence/(label+'-build.log')).open('wb') as log:
   subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 records=['.ihk-smp-x86_64.ko.cmd','.ihk-smp-x86_64.mod.cmd','.ihk-smp-x86_64.mod.o.cmd','.ihk-smp-x86_64.o.cmd','.ihk.ko.cmd','.ihk.mod.cmd','.ihk.mod.o.cmd','.ihk.o.cmd','.ihk_smp_x86_64.o.cmd','.mcctrl.ko.cmd','.mcctrl.mod.cmd','.mcctrl.mod.o.cmd','.mcctrl.o.cmd','ihk-smp-x86_64.mod','ihk.mod','mcctrl.mod','ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']
 for name in records: shutil.copyfile(module_root/name,evidence/name)
 shutil.copytree(module_root,evidence/'module-build')
 for src,name in [(stage/'stage-lock.json','stage-lock.json'),(build/'.config','resolved.config'),(build/'arch/x86/boot/bzImage','bzImage'),(build/'Module.symvers','Module.symvers'),(build/'include/config/kernel.release','kernel.release'),(build/'rust/bindings/bindings_generated.rs','bindings_generated.rs'),(source/'tools/objtool/check.c','objtool-check.c'),(build/'tools/objtool/objtool','objtool'),(source/'mm/memory_hotplug.c','memory_hotplug.c'),(source/'mm/show_mem.c','show_mem.c')]: shutil.copyfile(src,evidence/name)
 if (evidence/'resolved.config').read_bytes()!=(prior/'resolved.config').read_bytes(): raise SystemExit('Kernel build changed the declared debug configuration')
 phase.write_text('validating-link-closure\n')
 for action in ('--output','--check-output'):
  subprocess.run(['/usr/bin/python3',str(evidence/'repository-inputs/scripts/native_rust_kbuild_link_closure.py'),'--records-dir',str(evidence),'--stage-lock',str(evidence/'stage-lock.json'),action,str(evidence/'kbuild-link-closure.json')],check=True)
 phase.write_text('complete\n')
 record.update(status='PASS',finished_utc=datetime.now(timezone.utc).isoformat(),outputs=[identity(evidence/name) for name in ['bzImage','resolved.config','stage-lock.json','kbuild-link-closure.json','ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']])
except BaseException as error:
 record.update(status='FAIL',failed_phase=phase.read_text().strip(),error=str(error),finished_utc=datetime.now(timezone.utc).isoformat());phase.write_text('failed\n')
 (evidence/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 raise
(evidence/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('NATIVE_STARTUP_EXACT_STAGE_KERNEL_MODULES_LINK_PASS',flush=True)
