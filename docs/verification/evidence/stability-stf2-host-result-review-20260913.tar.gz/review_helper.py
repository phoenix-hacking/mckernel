from pathlib import Path
import hashlib, json, re, shutil, stat, tarfile, tempfile

ROOT = Path('/home/holden/mckernel-work/scratch/stability-published-fault-control-tests-20260913-1')
REPO = Path('/home/holden/mckernel')
OUT = Path(tempfile.mkdtemp(prefix='stability-stf2-host-result-peer-20260913-'))
def ident(p, label=None):
    b=p.read_bytes()
    return {'path':str(p) if label is None else label,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
shutil.copytree(ROOT, OUT/'actual', symlinks=True)
originals=[]
for p in sorted(ROOT.rglob('*')):
    mode=p.lstat().st_mode
    if stat.S_ISDIR(mode):continue
    assert stat.S_ISREG(mode) and p.stat().st_size<=2*1024*1024,str(p)
    q=OUT/'actual'/p.relative_to(ROOT)
    a,b=ident(p),ident(q);assert a['size']==b['size'] and a['sha256']==b['sha256']
    originals.append({'original':a,'retained':str(q.relative_to(OUT))})
record=json.loads((OUT/'actual/record.json').read_text());c=record['collection']
assert record['status']=='PASS_CONNECTED_SOCKET_PUBLISHED_FAULT_CONTROL_ONLY' and type(record['cases']) is int and record['cases']==30
assert c==json.loads((OUT/'actual/collection/report.json').read_text())
assert c['status']=='COMPLETED' and type(c['raw_wait_status']) is int and c['raw_wait_status']==0 and c['cleanup_complete'] is True
assert c['descendant_records_omitted']==0 and c['descendants']==[]
assert c['payload_monotonic_started']<=c['payload_completion_observed_monotonic']<c['payload_monotonic_deadline']
assert c['payload_monotonic_deadline']-c['payload_monotonic_started']==120.0
assert c['uid']==1000 and c['gid']==1000 and c['groups']==[1000]
assert record['command']==c['argv'] and record['environment']==c['env']
for key in ['application_acceptance','transport_acceptance','guest_execution']:assert record[key] is False
streams=[]
for name in ['stdout','stderr']:
    p=OUT/'actual/collection'/(name+'.bin');i=ident(p);r=c['streams'][name]
    assert i['size']==r['artifact']['size']==r['bytes_observed']==r['bytes_retained']
    assert i['sha256']==r['artifact']['sha256'] and r['eof'] is True and r['truncated'] is False and r['discarded_observed_bytes']==0
    streams.append(i)
verified_inputs=[]
expected_hashes={
 'scripts/application-tests/published_fault_control.py':'c007abfe0d1113b473a5d2d69412f6f07c5a191d2119d962c56967789f23d047',
 'scripts/tests/test_application_published_fault_control.py':'7d9fd6de687b64556125d9dd1621c6b2308c43ef898620c493d8464cb69acf2c',
 'scripts/application-tests/supervisor.py':'8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'}
for row in record['inputs']:
    source=row['original']['path'];assert source.startswith('/workspace/')
    relative=source[len('/workspace/'):]
    expected=expected_hashes[relative]
    p=OUT/'actual'/relative;a=ident(p)
    assert a['sha256']==expected==row['original']['sha256']==row['retained']['sha256']
    assert a['size']==row['original']['size']==row['retained']['size']
    assert ident(REPO/relative)['sha256']==expected
    verified_inputs.append(a)
assert len(verified_inputs)==3
tests=(OUT/'actual/scripts/tests/test_application_published_fault_control.py').read_text()
names=re.findall(r'^    def (test_[a-z0-9_]+)\(self\):',tests,re.M)
assert len(names)==len(set(names))==30
stderr=(OUT/'actual/collection/stderr.bin').read_text()
observed=re.findall(r'^(test_[a-z0-9_]+) \(__main__\.FaultControlTests\.\1\) \.\.\. ok$',stderr,re.M)
assert sorted(observed)==sorted(names) and stderr.endswith('\nRan 30 tests in 0.594s\n\nOK\n')
stdout=(OUT/'actual/collection/stdout.bin').read_text()
case_paths={}
for line in stdout.splitlines():
    match=re.fullmatch(r'RETAINED_FAULT_CONTROL_TEST __main__\.FaultControlTests\.(test_[a-z0-9_]+) (/work/stability-published-fault-control-tests-20260913-1/tmp/stability-published-fault-control-[a-z0-9_]+)',line)
    assert match,line
    name,path=match.groups();assert name not in case_paths
    case_paths[name]=OUT/'actual'/path.split('/stability-published-fault-control-tests-20260913-1/',1)[1]
assert sorted(case_paths)==sorted(names) and len(set(case_paths.values()))==30
observations=[]
for name in sorted(case_paths):
    directory=case_paths[name];assert directory.is_dir()
    for p in sorted(directory.rglob('report.json')):
        r=json.loads(p.read_text());owner=p.parent.parent
        for flag in ['application_acceptance','transport_acceptance','qmp_provenance_verified','controller_exit_verified']:assert r[flag] is False
        rx=(p.parent/'rx.bin').read_bytes();tx=(p.parent/'tx.bin').read_bytes()
        assert len(rx)==r['rx_bytes'] and len(tx)==r['tx_bytes']
        assert hashlib.sha256(rx).hexdigest()==r['rx_sha256'] and hashlib.sha256(tx).hexdigest()==r['tx_sha256']
        assert r['socket_bytes_received']>=len(rx) and r['socket_bytes_sent']>=len(tx)
        assert r['received_raw_fully_stored'] is (r['socket_bytes_received']==len(rx))
        assert r['sent_raw_fully_stored'] is (r['socket_bytes_sent']==len(tx))
        assert (owner/'expected-rx.bin').read_bytes().startswith(rx)
        assert (owner/'peer-ack.bin').read_bytes()==tx
        calls=json.loads((owner/'callback-calls.json').read_text());assert len(calls)==r['callback_count']
        assert r['original_response_reads_allowed'] is (not r['release_possible'])
        assert all(row['original_response_reads_allowed'] is (not row['release_possible']) for row in calls)
        events=[json.loads(line) for line in (p.parent/'events.jsonl').read_text().splitlines()]
        for i,e in enumerate(events):
            if e['event']=='ack-written' and e['phase']=='ACCEPTED_RETURN':
                assert any(old['event']=='release-possible-latched' and old['sequence']==e['sequence'] for old in events[:i])
        observations.append({'test':name,'instance':str(owner.relative_to(OUT)),'report':ident(p,str(p.relative_to(OUT))),
            'raw_rx':len(rx),'raw_tx':len(tx),'rx_discarded':r['rx_discarded_bytes'],'release_possible':r['release_possible'],
            'first_failure':r['first_failure'],'events':len(events),'callbacks':len(calls)})
assert len(observations)==56
late=case_paths['test_late_failing_callback_preserves_original_error_and_overrun']/'1/capture'
r=json.loads((late/'report.json').read_text());f=r['first_failure']
assert f['error']==f['callback_error']=='RuntimeError:original distinct callback failure' and f['capture_deadline_exceeded'] is True
assert r['tx_bytes']==r['ack_count']==0
partial=case_paths['test_real_rx_write_delay_does_not_extend_partial_frame_budget']/'1/capture'
r=json.loads((partial/'report.json').read_text())
assert r['first_failure']['reason']=='partial-frame-deadline' and r['callback_count']==r['tx_bytes']==0
assert (partial/'rx.bin').read_bytes()==b'STF2 REQ '
events=[json.loads(line) for line in (partial/'events.jsonl').read_text().splitlines()]
assert events[-1]['monotonic_ns']-events[0]['monotonic_ns']>=20_000_000
for row in originals:
    assert ident(Path(row['original']['path']))==row['original']
shutil.copy2(Path(__file__),OUT/'review_helper.py')
review={'schema_version':1,'status':'PASS_INDEPENDENT_RETAINED_STF2_SOCKET_RESULTS_ONLY',
 'actual_record':ident(ROOT/'record.json'),'subject_execution_by_reviewer':False,
 'actual_test_methods':30,'retained_case_directories':30,'retained_coordinator_reports':56,
 'source_inputs':verified_inputs,'raw_collection_status':c['status'],'raw_wait_status':c['raw_wait_status'],
 'cleanup_complete':True,'collection_streams':streams,'tests':names,'instances':observations,
 'retained_inputs':originals,'source_review_publication':ident(REPO/'docs/verification/stability-stf2-host-source-review-20260913.json'),
 'checks':['Joined all 30 distinct frozen test methods to literal successful unittest lines and distinct retained case roots.','Verified original/retained/current hashes for coordinator, test and supervisor; joined actual request argv/environment and raw zero wait, on-time observation, complete EOF streams and owned cleanup.','All 56 report raw rx/tx lengths and hashes match bytes; raw tx equals actual peer-ACK capture; retained rx is a prefix of the independently sent bytes, including explicit one-byte cap loss.','All report/callback response-read flags remain consistent with release ambiguity; every retained accepted ACK event is preceded by its release latch.','Independently checked the delayed failing callback retains original RuntimeError plus overrun and sends no ACK; delayed RX storage causes partial deadline with no callback or ACK.'],
 'limitations':['No reviewer imports, tests, sockets, QMP, containers or guests. These were root-executed connected-socket infrastructure cases.','Python container interpreter identity is retained from original supervisor report but cannot be reopened at /usr/bin/python3.12 on the host mapping; no independent complete toolchain freshness claim.','Capture callbacks are synthetic; their digest and continued booleans do not establish QMP resume or physical/native ownership.','Synchronous callbacks still require the external watchdog. Actual container cleanup, native module build/stack, C controller, private ioctl, original timer, physical snapshot and mode outcome gates remain separate.'],
 'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False}
save(OUT/'review.json',review)
shutil.copytree(Path('/tmp/stability-stf2-host-result-peer-20260913-o9djac8f'),OUT/'original-metadata-failure',symlinks=True)
archive=REPO/'docs/verification/evidence/stability-stf2-host-result-review-20260913.tar.gz'
members=[]
with tarfile.open(str(archive),'x:gz') as tar:
    for p in sorted(OUT.rglob('*')):
        rel=str(p.relative_to(OUT))
        if p.is_dir():members.append({'path':rel,'type':'directory','mode':stat.S_IMODE(p.stat().st_mode)})
        else:members.append(ident(p,rel))
        tar.add(str(p),arcname=rel,recursive=False)
with tarfile.open(str(archive),'r:gz') as tar:
    found=tar.getmembers();assert len(found)==len(members)
    for member,expected in zip(found,members):
        assert member.name==expected['path']
        if expected.get('type')=='directory':
            assert member.isdir() and member.mode==expected['mode']
        else:
            assert member.isfile() and member.size==expected['size']
            assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==expected['sha256']
publication=REPO/'docs/verification/stability-stf2-host-result-review-20260913.json'
save(publication,{'schema_version':1,'status':review['status'],'review':ident(OUT/'review.json'),
 'source_retention':str(OUT),'archive':ident(archive,str(archive.relative_to(REPO))),'archive_member_count':len(members),
 'archive_members':members,'all_members_read_back_and_verified':True,'actual_record':review['actual_record'],
 'actual_test_methods':30,'coordinator_reports':56,'source_review_publication':review['source_review_publication'],
 'subject_execution_by_reviewer':False,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False,
 'limitations':review['limitations']})
print(json.dumps({'source_retention':str(OUT),'review':ident(OUT/'review.json'),'publication':ident(publication),'archive':ident(archive),'members':len(members)},indent=2))
