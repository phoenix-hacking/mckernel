#!/usr/bin/env python3
"""Independent storage-fault-v2 owner supervisor (source candidate only)."""
import argparse
import ctypes
import errno
import fcntl
import hashlib
import json
import os
import select
import signal
import stat
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OWNER = (HERE / "witness_owner.py").resolve()
PR_SET_CHILD_SUBREAPER = 36
PR_GET_CHILD_SUBREAPER = 37
PREFLIGHT_NS = 5_000_000_000
OWNER_WAIT_NS = 220_000_000_000
CLEANUP_NS = 22_000_000_000
PUBLICATION_NS = 6_000_000_000
TOTAL_NS = 248_000_000_000
PREFLIGHT_TOTAL_NS = 33_000_000_000
STREAM_LIMIT = 1 << 20

class PreflightFailure(RuntimeError):
    def __init__(self, stage, error, sentinel_pid=None):
        super().__init__(str(error) or "<empty-%s>" % type(error).__name__)
        self.stage = stage
        self.original = error
        self.sentinel_pid = sentinel_pid

def strict(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate key")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite")))

def complete_write(fd, raw):
    view = memoryview(raw)
    while view:
        try:
            count = os.write(fd, view)
        except InterruptedError:
            continue
        if count <= 0:
            raise OSError("short supervisor write")
        view = view[count:]

def stable_bytes(path, limit=1 << 26):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError("canonical supervisor input")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    primary = None
    result = None
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular supervisor input")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                raise OSError("short supervisor input")
            chunks.append(chunk); remaining -= len(chunk)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("supervisor input changed")
        result = b"".join(chunks)
    except Exception as error:
        primary = error
    try:
        os.close(fd)
    except Exception as close_error:
        if primary is None:
            raise
        primary._supervisor_secondary = [close_error]
    if primary is not None:
        raise primary
    return result

def process_identity(pid):
    raw = Path("/proc/%d/stat" % pid).read_bytes()
    close = raw.rfind(b")")
    fields = raw[close + 2:].split() if close >= 0 else []
    open_paren = raw[:close + 1].find(b"(") if close >= 0 else -1
    if open_paren < 1 or len(fields) < 20:
        raise ValueError("proc stat")
    return {"pid": int(raw[:open_paren - 1]), "ppid": int(fields[1]),
            "startticks": int(fields[19])}

def observe_identity(pid):
    now = time.monotonic_ns()
    try:
        value = process_identity(pid)
    except FileNotFoundError:
        return {"observation": "missing", "pid": pid, "ppid": None,
                "startticks": None, "monotonic_ns": now}
    except (OSError, ValueError):
        return {"observation": "error", "pid": pid, "ppid": None,
                "startticks": None, "monotonic_ns": now}
    return {"observation": "observed", "pid": value["pid"],
            "ppid": value["ppid"], "startticks": value["startticks"],
            "monotonic_ns": now}

def normalized_error(error, stage=None):
    name = type(error).__name__
    value = {"type": name, "message": str(error) or "<empty-%s>" % name,
             "errno": error.errno if isinstance(error, OSError) and
             type(error.errno) is int and error.errno > 0 else None}
    if stage is not None:
        value = {"stage": stage, **value}
    return value

def classify_owner(pid, supervisor_pid, observations, spawn_error=None,
                   preflight_failure=None):
    if preflight_failure is not None:
        return {"state": "NOT_SPAWNED", "pid": None, "ppid": None,
                "startticks": None, "spawn_error": None}
    if spawn_error is not None:
        return {"state": "SPAWN_FAILED", "pid": None, "ppid": None,
                "startticks": None, "spawn_error": normalized_error(spawn_error)}
    observed = [item for item in observations if item["observation"] == "observed"]
    if len(observations) == 2 and len(observed) == 2 and \
       observed[0]["pid"] == observed[1]["pid"] == pid and \
       observed[0]["ppid"] == observed[1]["ppid"] == supervisor_pid and \
       observed[0]["startticks"] == observed[1]["startticks"] > 0:
        return {"state": "MATCHED", "pid": pid, "ppid": supervisor_pid,
                "startticks": observed[0]["startticks"], "spawn_error": None}
    conflict = any(item["pid"] != pid or item["ppid"] != supervisor_pid
                   for item in observed)
    if len(observed) >= 2 and any((item["pid"], item["ppid"], item["startticks"]) !=
                                  (observed[0]["pid"], observed[0]["ppid"],
                                   observed[0]["startticks"])
                                  for item in observed[1:]):
        conflict = True
    state = "MISMATCH" if conflict else "UNOBSERVED"
    return {"state": state, "pid": pid, "ppid": None,
            "startticks": None, "spawn_error": None}

def set_subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) != 0:
        number = ctypes.get_errno(); raise OSError(number, os.strerror(number))
    current = ctypes.c_int(0)
    if libc.prctl(PR_GET_CHILD_SUBREAPER, ctypes.byref(current), 0, 0, 0) != 0:
        number = ctypes.get_errno(); raise OSError(number, os.strerror(number))
    if current.value != 1:
        raise RuntimeError("subreaper confirmation")

def wait_exact(pid, deadline_ns):
    while time.monotonic_ns() < deadline_ns:
        try:
            actual, raw = os.waitpid(pid, os.WNOHANG)
        except InterruptedError:
            continue
        if actual == pid:
            return raw
        time.sleep(0.001)
    raise TimeoutError("sentinel wait")

def establish_wait_authority(preflight_started_ns):
    try:
        signal.signal(signal.SIGCHLD, signal.SIG_DFL)
        if signal.getsignal(signal.SIGCHLD) is not signal.SIG_DFL:
            raise RuntimeError("SIGCHLD confirmation")
        set_subreaper()
    except Exception as error:
        raise PreflightFailure("sigchld-default", error)
    try:
        pid = os.fork()
    except Exception as error:
        raise PreflightFailure("sentinel-fork", error)
    if pid == 0:
        os._exit(73)
    try:
        raw = wait_exact(pid, preflight_started_ns + PREFLIGHT_NS)
        if raw != 73 << 8:
            raise RuntimeError("sentinel raw wait status")
    except Exception as error:
        raise PreflightFailure("sentinel-wait", error, pid)
    return {"sigchld_default": True, "sentinel_wait_passed": True,
            "sentinel_pid": pid, "sentinel_raw_wait_status": raw}

def wait_fields(raw):
    if raw is None:
        return False, None, None
    if os.WIFEXITED(raw):
        return True, os.WEXITSTATUS(raw), None
    if os.WIFSIGNALED(raw):
        return True, None, os.WTERMSIG(raw)
    raise ValueError("owner wait status")

def read_pipe(fd, retained, eof):
    while not eof:
        try:
            chunk = os.read(fd, 65536)
        except InterruptedError:
            continue
        except BlockingIOError:
            break
        if not chunk:
            return retained, True
        if len(retained) + len(chunk) > STREAM_LIMIT:
            raise ValueError("owner stream overflow")
        retained += chunk
    return retained, eof

def pump_owner(pid, stdout_fd, stderr_fd, deadline_ns):
    stdout = stderr = b""
    stdout_eof = stderr_eof = False
    raw_wait = None
    poller = select.poll()
    poller.register(stdout_fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    poller.register(stderr_fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    while time.monotonic_ns() < deadline_ns:
        if raw_wait is None:
            try:
                actual, raw = os.waitpid(pid, os.WNOHANG)
            except InterruptedError:
                actual = 0
            if actual == pid:
                raw_wait = raw
        for fd, event in poller.poll(10):
            if fd == stdout_fd:
                stdout, stdout_eof = read_pipe(fd, stdout, stdout_eof)
            elif fd == stderr_fd:
                stderr, stderr_eof = read_pipe(fd, stderr, stderr_eof)
        if raw_wait is not None and stdout_eof and stderr_eof:
            break
    return {"raw_wait_status": raw_wait, "stdout": stdout, "stderr": stderr,
            "stdout_eof": stdout_eof, "stderr_eof": stderr_eof}

def signal_error(stage, pid, startticks, sig, error, direct):
    return {"kind": "signal-error", "stage": stage, "pid": pid,
            "startticks": startticks, "signal": int(sig),
            "errno": error.errno if type(error.errno) is int and error.errno > 0
                else errno.EIO, "monotonic_ns": time.monotonic_ns(),
            "direct": direct}

def durable_file(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    try:
        complete_write(fd, raw); os.fsync(fd)
    finally:
        os.close(fd)

def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def evidence_record(root, filename):
    path = Path(root) / filename
    try:
        raw = stable_bytes(path, STREAM_LIMIT)
    except FileNotFoundError:
        return False, None
    return True, hashlib.sha256(raw).hexdigest()

def publish_result(root, stdout, stderr, result):
    root = Path(root)
    result_path = root / "supervisor-result.json"
    if result_path.exists() or result_path.is_symlink():
        raise FileExistsError("supervisor result exists")
    try:
        durable_file(root / "owner-supervisor.stdout.bin", stdout)
        durable_file(root / "owner-supervisor.stderr.bin", stderr)
        fsync_directory(root)
        raw = (json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n").encode()
        durable_file(result_path, raw)
        fsync_directory(root)
    except Exception:
        try:
            result_path.unlink()
            fsync_directory(root)
        except FileNotFoundError:
            pass
        raise

def validate_inputs(args):
    if OWNER.parent != HERE or OWNER.name != "witness_owner.py" or \
       Path(sys.executable).resolve() != Path(sys.executable):
        raise ValueError("supervisor executable binding")
    owner_raw = stable_bytes(OWNER, 1 << 20)
    if hashlib.sha256(owner_raw).hexdigest() != args.owner_sha256:
        raise ValueError("owner source hash")
    hashes = strict(stable_bytes(args.hashes, 1 << 20))
    names = {"source": args.source, "generated_source": args.generated_source,
             "header": args.header, "elf": args.elf}
    hash_names = {"source": "source_sha256", "generated_source": "generated_sha256",
                  "header": "header_sha256", "elf": "elf_sha256"}
    for name, path in names.items():
        raw = stable_bytes(path, 16 << 20 if name == "elf" else 1 << 20)
        if hashlib.sha256(raw).hexdigest() != hashes[hash_names[name]]:
            raise ValueError("supervisor input hash " + name)
    for path, size, digest in ((args.request, 406,
            "e81b38bbe6116bf1df2807fa968e12dccfd28fe8c3ad225c45f282b36cab6716"),
            (args.selected_inputs, 76,
            "6b8761a9d2094147f02b9fe2a4c709246905a04c5122d68f6b9951162e01317d"),
            (args.fixture, 27448,
            "9ad70dd23d699e72ad805f59446aec371c4e80b955056b845af921b4ce51f725")):
        raw = stable_bytes(path, size)
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("supervisor runtime input")
    return hashes

def owner_argv(args):
    return [str(Path(sys.executable).resolve()), str(OWNER),
        "--witness-root", str(args.attempt_root), "--nonce", args.nonce,
        "--selector", str(args.selector), "--hashes", str(args.hashes),
        "--source", str(args.source), "--generated-source", str(args.generated_source),
        "--header", str(args.header), "--elf", str(args.elf),
        "--request", str(args.request), "--selected-inputs", str(args.selected_inputs),
        "--fixture", str(args.fixture)]

def spawn_owner(args):
    stdout_r, stdout_w = os.pipe2(os.O_CLOEXEC | os.O_NONBLOCK)
    stderr_r, stderr_w = os.pipe2(os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        pid = os.fork()
    except Exception:
        for fd in (stdout_r, stdout_w, stderr_r, stderr_w):
            os.close(fd)
        raise
    if pid == 0:
        try:
            os.close(stdout_r); os.close(stderr_r)
            for fd in (stdout_w, stderr_w):
                flags = fcntl.fcntl(fd, fcntl.F_GETFL)
                fcntl.fcntl(fd, fcntl.F_SETFL, flags & ~os.O_NONBLOCK)
            null_fd = os.open("/dev/null", os.O_RDONLY | os.O_CLOEXEC)
            os.dup2(null_fd, 0); os.dup2(stdout_w, 1); os.dup2(stderr_w, 2)
            os.close(null_fd); os.close(stdout_w); os.close(stderr_w)
            argv = owner_argv(args)
            environment = {"LANG": "C", "LC_ALL": "C", "PATH": "/usr/bin:/bin",
                           "PYTHONDONTWRITEBYTECODE": "1"}
            os.execve(argv[0], argv, environment)
        finally:
            os._exit(127)
    os.close(stdout_w); os.close(stderr_w)
    return pid, stdout_r, stderr_r

def parser():
    value = argparse.ArgumentParser()
    value.add_argument("--attempt-root", type=Path, required=True)
    value.add_argument("--owner-sha256", required=True)
    value.add_argument("--nonce", required=True)
    value.add_argument("--selector", type=int, choices=range(7), required=True)
    value.add_argument("--hashes", type=Path, required=True)
    value.add_argument("--source", type=Path, required=True)
    value.add_argument("--generated-source", type=Path, required=True)
    value.add_argument("--header", type=Path, required=True)
    value.add_argument("--elf", type=Path, required=True)
    value.add_argument("--request", type=Path, required=True)
    value.add_argument("--selected-inputs", type=Path, required=True)
    value.add_argument("--fixture", type=Path, required=True)
    return value

def main():
    args = parser().parse_args()
    # Full orchestration is deliberately source-gated until its cleanup/result
    # controls are independently accepted. Never imply a runnable supervisor.
    try:
        validate_inputs(args)
    except Exception as error:
        print("supervisor input failure: %s: %s" %
              (type(error).__name__, str(error) or "<empty>"), file=sys.stderr)
    return 125

if __name__ == "__main__":
    raise SystemExit(main())
