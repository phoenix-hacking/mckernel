#!/usr/bin/env python3
"""Independent offline oracle for storage-fault-v2 retained evidence."""
import hashlib
import json
import os
import stat
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_SHA = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
PREFIX = bytes.fromhex("41435251303030")
PREFIX_SHA = "793665677edfa8c879c38d37c8c5300c54ff78e980eae26a96913d7aab9d8d91"
EXPECTED = {
    0: (0, "post-fork", "complete", "COMPLETED", "none", 0, 21),
    1: (256, "pre-fork", "complete", "PREPARATION_ERROR", "artifact-create", 28, 10),
    2: (256, "pre-fork", "complete", "COLLECTOR_ERROR", "artifact-write", 28, 17),
    3: (256, "post-fork", "complete", "COLLECTOR_ERROR", "artifact-fsync", 5, 21),
    4: (32000, "post-fork", "absent", None, None, 28, 16),
    5: (32000, "post-fork", "complete-undurable", "COMPLETED", "none", 0, 21),
    6: (32000, "pre-fork", "complete-undurable", "COLLECTOR_ERROR", "artifact-write", 28, 17),
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("nonfinite")))

def read(path, limit=1 << 20):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError("canonical evidence path")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular evidence")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                raise OSError("short evidence read")
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("evidence changed during read")
        return b"".join(chunks)
    finally:
        os.close(fd)

def journal(path):
    raw = read(path, 1 << 20)
    if not raw.endswith(b"\n"):
        raise ValueError("journal terminal newline")
    rows = [strict(line) for line in raw.splitlines()]
    if not rows or any(set(row) != {"packet", "receipt_monotonic_ns"}
                       for row in rows):
        raise ValueError("journal envelope")
    if any(type(row["receipt_monotonic_ns"]) is not int or
           row["receipt_monotonic_ns"] <= 0 for row in rows):
        raise ValueError("journal receipt")
    return rows

def validate_packet_order(packets, selector, nonce, hashes, expected_count):
    if len(packets) != expected_count:
        raise ValueError("witness packet count")
    for sequence, packet in enumerate(packets):
        required = {"schema_version", "nonce", "selector", "sequence", "kind",
                    "phase", "monotonic_ns", "collector_pid",
                    "collector_startticks", "source_sha256", "generated_sha256",
                    "header_sha256", "elf_sha256"}
        if not required <= set(packet):
            raise ValueError("witness fields")
        if packet["schema_version"] != 2 or packet["nonce"] != nonce or \
           packet["selector"] != selector or packet["sequence"] != sequence:
            raise ValueError("witness identity")
        if type(packet["monotonic_ns"]) is not int or packet["monotonic_ns"] <= 0:
            raise ValueError("witness monotonic")
        if packet["source_sha256"] != SOURCE_SHA:
            raise ValueError("source hash")
        for key in ("generated_sha256", "header_sha256", "elf_sha256"):
            if packet[key] != hashes[key]:
                raise ValueError("generated hash")
    if packets[0]["kind"] != "READY" or packets[0]["sequence"] != 0:
        raise ValueError("ready sequence")
    kinds = [packet["kind"] for packet in packets]
    for before in [index for index, kind in enumerate(kinds) if kind == "BEFORE"]:
        if before + 1 >= len(kinds) or kinds[before + 1] != "AFTER":
            raise ValueError("seam pairing")
        left, right = packets[before], packets[before + 1]
        if (left.get("site"), left.get("object"), left.get("occurrence")) != \
           (right.get("site"), right.get("object"), right.get("occurrence")):
            raise ValueError("seam identity")
        if left.get("return") is not None or left.get("errno_authoritative") is not False:
            raise ValueError("before result")
        returned = right.get("return")
        if type(returned) is not int or right.get("errno_authoritative") is not (returned < 0):
            raise ValueError("after result")
    if selector in (0, 3, 4, 5):
        if kinds.count("REAP") != 1 or kinds.count("EOF") != 3 or \
           kinds.count("CLEANUP_READY") != 1 or kinds.count("CLEANUP_FINAL") != 1:
            raise ValueError("collector cleanup observations")
        final = packets[kinds.index("CLEANUP_FINAL")]
        if final.get("cleanup_complete") is not True or not (
                final["cleanup_start_ns"] < final["cleanup_finished_ns"] <
                final["cleanup_deadline_ns"]):
            raise ValueError("collector cleanup result")
    else:
        if any(kind in kinds for kind in ("REAP", "EOF", "CLEANUP_READY", "CLEANUP_FINAL")):
            raise ValueError("fabricated pre-fork cleanup")

def validate(root, selector):
    if selector not in EXPECTED:
        raise ValueError("selector")
    root = Path(root).resolve()
    expected_wait, phase, report_kind, status, failure, error, count = EXPECTED[selector]
    owner = strict(read(root / "owner-result.json"))
    if owner.get("schema_version") != 2 or owner.get("selector") != selector or \
       owner.get("raw_wait_status") != expected_wait or owner.get("owner_failure") is not None:
        raise ValueError("owner result")
    if owner.get("cleanup_complete") is not True or owner.get("application_acceptance") is not False:
        raise ValueError("owner cleanup")
    nonce = owner.get("nonce")
    if type(nonce) is not str or len(nonce) != 32 or any(
            char not in "0123456789abcdef" for char in nonce):
        raise ValueError("nonce")
    rows = journal(root / "witness.jsonl")
    if rows[-1]["packet"].get("kind") != "OWNER_RESULT":
        raise ValueError("owner publication")
    packets = [row["packet"] for row in rows[:-1]]
    if any(rows[index]["receipt_monotonic_ns"] >= rows[index + 1]["receipt_monotonic_ns"]
           for index in range(len(rows) - 1)):
        raise ValueError("receipt order")
    hashes = owner.get("hashes")
    if not isinstance(hashes, dict) or set(hashes) != {
            "generated_sha256", "header_sha256", "elf_sha256"}:
        raise ValueError("owner hashes")
    validate_packet_order(packets, selector, nonce, hashes, count)
    if any(packet["phase"] != phase for packet in packets[1:]
           if packet["kind"] in ("BEFORE", "AFTER")):
        raise ValueError("selector phase")
    collection = root / "collection"
    report_path = collection / "report.json"
    if report_kind == "absent":
        if report_path.exists():
            raise ValueError("fabricated report")
    else:
        report = strict(read(report_path))
        if report.get("status") != status or report.get("first_failure") != failure or \
           report.get("first_failure_errno") != error:
            raise ValueError("report result")
    request = read(collection / "request.bin")
    if selector in (2, 6):
        if request != PREFIX or sha(request) != PREFIX_SHA:
            raise ValueError("request prefix")
    elif sha(request) != owner.get("request_artifact_sha256"):
        raise ValueError("request artifact")
    if selector in (5, 6):
        sync = [packet for packet in packets if packet.get("site") == "report-sync"]
        if len(sync) != 2 or sync[-1].get("return") != -1 or \
           sync[-1].get("errno") != 5:
            raise ValueError("report sync failure")
    return True
