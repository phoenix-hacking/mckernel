from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
out=Path('/work/stability-additional-baseline-20260913-1'); out.mkdir()
record={'status':'RUNNING','commands':[],'children':[],'started_utc':datetime.now(timezone.utc).isoformat(),'new_catalog_acceptance':False}
rows=[(['/work/run-native-ultra-signal-abi.py','1','3','3','2026091301'],'/work/native-ultra-signal-abi-guest-20260909-2026091301'),(['/work/run-native-ultra-futex.py','1','3','3','2026091301'],'/work/native-ultra-futex-guest-20260909-2026091301')]
try:
 (out/'helper.py').write_bytes(Path(__file__).read_bytes())
 for args,path in rows:
  assert not Path(path).exists(),path
  command=['python3','-B']+args
  helper=Path(args[0]);(out/helper.name).write_bytes(helper.read_bytes())
  entry={'command_argv':command,'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest()};record['commands'].append(entry)
  print('RUN',path,flush=True)
  result=subprocess.run(command,timeout=700);entry['exit_code']=result.returncode
  assert result.returncode==0,(command,result.returncode)
  child=Path(path)/'record.json';state=json.loads(child.read_text());assert state['status']=='PASS' and state['qemu_exit_code']==0
  record['children'].append({'path':str(child),'size':child.stat().st_size,'sha256':hashlib.sha256(child.read_bytes()).hexdigest(),'status':'PASS'})
 record['status']='PASS'
except BaseException as error:
 record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat()
 with (out/'record.json').open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
 print(record['status'],out,flush=True)
