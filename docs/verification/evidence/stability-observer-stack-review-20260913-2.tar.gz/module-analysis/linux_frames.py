from pathlib import Path
import ast,hashlib,json,re,subprocess
from elftools.elf.elffile import ELFFile
cap=Path('/tmp/stability-observer-stack-review-20260913-2')
source=Path('/home/holden/mckernel-work/scratch/native-build-base-24a151fe/vmlinux')
selected=json.loads((cap/'linux-symbols.json').read_text())
selected=[s for s in selected if not s['name'].startswith('__pfx_')]
inputs=cap/'linux-functions'
inputs.mkdir(exist_ok=False)
all_symbols=[]
with source.open('rb') as stream:
 elf=ELFFile(stream)
 for symbol in elf.get_section_by_name('.symtab').iter_symbols():
  if symbol['st_info']['type']=='STT_FUNC' and symbol['st_size'] and not symbol.name.startswith('__pfx_'):
   all_symbols.append({'name':symbol.name,'address':symbol['st_value'],'size':symbol['st_size'],'section_index':symbol['st_shndx']})
 for i,item in enumerate(selected):
  symbol=next(s for s in all_symbols if s['name']==item['name'])
  section=elf.get_section(symbol['section_index'])
  offset=section['sh_offset']+symbol['address']-section['sh_addr']
  stream.seek(offset);raw=stream.read(symbol['size'])
  assert len(raw)==symbol['size']
  path=inputs/(str(i)+'.bin');path.write_bytes(raw)
  argv=['/usr/bin/objdump','-D','-b','binary','-m','i386:x86-64','--adjust-vma='+hex(symbol['address']),str(path)]
  result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
  (inputs/(str(i)+'.stdout')).write_bytes(result.stdout)
  (inputs/(str(i)+'.stderr')).write_bytes(result.stderr)
  item.update(raw_sha256=hashlib.sha256(raw).hexdigest(),raw_path=str(path),elf_offset=offset,command=argv)
  text=result.stdout.decode()
  lines=['Disassembly of section .text:',f"{symbol['address']:016x} <{symbol['name']}>:"]
  lines.extend(line for line in text.splitlines() if re.match(r'^\s*[0-9a-f]+:\s+',line))
  (inputs/(str(i)+'.normalized-disassembly')).write_text('\n'.join(lines)+'\n')
# Reuse the original retained analyzer definitions, without executing its entrypoint.
tree=ast.parse(Path('/tmp/stability-observer-stack-review-inputs/audit.py').read_text())
tree.body=[node for node in tree.body if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
namespace={}
exec(compile(tree,'retained-audit-definitions','exec'),namespace)
functions=[]
for i,item in enumerate(selected):
 function=next(iter(namespace['parse_functions'](inputs/(str(i)+'.normalized-disassembly')).values()))
 functions.append({k:v for k,v in function.items() if k!='instructions'}|namespace['analyze'](function,{}))
record={'vmlinux':{'path':str(source),'size':source.stat().st_size,'sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest()},'selected_symbols':selected,'functions':functions,'all_function_symbols':all_symbols,'scope':'Exact function bytes extracted from pinned ELF and disassembled as x86-64 binary, with original virtual addresses. Entry boundaries restored from ELF symbols. Reused retained stack analyzer definitions. Full graph and dynamic edges remain incomplete.'}
(cap/'linux-analysis.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
for f in functions:
 print(hex(f['address']),f['name'],'local',f['maximum_local_stack_bytes'],'entry-inclusive',f['with_entry_return_address_bytes'],'unknown',f['unknown_stack_assignments'])
 for c in f['calls']:
  if c['target']:
   target=next((x['name'] for x in all_symbols if x['address']==c['target'][1]),'?')
  else:target='?'
  print(' ',c['address'],c['depth_before'],c['kind'],target,c['op'])
