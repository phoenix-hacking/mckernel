from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/home/holden/mckernel')
cap=Path('/home/holden/mckernel-work/scratch/stability-transport-fault-module-20260913-prepublish-hard-2')
local=Path('/tmp/stability-observer-stack-review-20260913-2')
linux=Path('/tmp/stability-observer-linux-review-20260913-2')
app=Path('/tmp/stability-observer-app-rows-20260913-1')
def ident(path):
 raw=path.read_bytes()
 return {'path':str(path),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
a=json.loads((local/'analysis.json').read_text())
fs={mod:{f['address']:f for f in v['functions']} for mod,v in a['modules'].items()}
def chain(mod,addresses,expected):
 rows=[]
 for i,address in enumerate(addresses):
  f=fs[mod][address];assert not f['unknown_stack_assignments']
  row={'function':f['name'],'address':hex(address),'entry_line':f['line'],'entry_return_bytes':8,'maximum_local_bytes':f['maximum_local_stack_bytes']}
  if i+1<len(addresses):
   edges=[c for c in f['calls'] if c['target']==['.text',addresses[i+1]]]
   assert edges and all(c['kind']=='call' for c in edges)
   row['callsites']=edges;row['counted_local_bytes']=max(c['depth_before'] for c in edges)
  else:row['counted_local_bytes']=f['maximum_local_stack_bytes']
  row['counted_bytes']=row['counted_local_bytes']+8;rows.append(row)
 total=sum(r['counted_bytes'] for r in rows);assert total==expected,(total,expected)
 return {'bytes':total,'module':mod,'rows':rows,'scope':'Known nested module frames only; no full Linux stack bound.'}
chains={
 'packet_worker_to_mailbox_copy':chain('ihk-smp-x86_64',[0x48b60,0x35db0,0x11150,0x30930,0x2ef70,0x23000,0x243b0,0x32470],6760),
 'phase_ioctl_to_mailbox_copy':chain('ihk-smp-x86_64',[0x22d0,0x4d0d0,0x3e170,0x30930,0x2ef70,0x23000,0x243b0,0x32470],7080),
 'ret_enter_hook':chain('mcctrl',[0xcf0,0x3d60,0x5b00],704),
 'ret_leave_hook':chain('mcctrl',[0xcf0,0x3d60,0x5c90],704),
 'ret_select_hook':chain('mcctrl',[0xcf0,0x2ac0,0x5e20],560)}
module_record=json.loads((cap/'record.json').read_text())
assert module_record['status']=='PASS_BUILD_ONLY'
phase_record=json.loads((cap/'phase-overlay/record.json').read_text())
assert phase_record['helper']['sha256']=='cd58971d7a810728f9426dfa10d2b661c831ecfe1328e413554632764f2d1d0d'
assert len(phase_record['stack_boundaries'])==10
l=json.loads((linux/'normalized/analysis.json').read_text())
# Alignment masks add at most15 bytes. The selected callsites precede the
# rbp-based epilogues left unresolved by the unchanged module CFG analyzer.
logging=[
 {'function':'kernel::print::call_printk -> _printk','address':'0xffffffff81765610','local_upper_bytes':0,'new_return_bytes':8,'edge':'tail jump to _printk at0xffffffff81765619; shares entry return address'},
 {'function':'_printk','address':'0xffffffff81006ff0','local_upper_bytes':103,'new_return_bytes':8,'edge':'call vprintk at0xffffffff81007048; pushrbp8 + stack80 + at most15 alignment'},
 {'function':'vprintk -> vprintk_default -> vprintk_emit','address':'0xffffffff811bcaa0','local_upper_bytes':0,'new_return_bytes':0,'edge':'ordinary vprintk path pops its temporary16 bytes before tail0xffffffff811bcafb; default tail0xffffffff811b8ce8'},
 {'function':'vprintk_emit','address':'0xffffffff811b87f0','local_upper_bytes':88,'new_return_bytes':8,'edge':'six pushes48 + stack40 at call store0xffffffff811b8920; other branch max96 is not nested here'},
 {'function':'vprintk_store','address':'0xffffffff811b7d40','local_upper_bytes':223,'new_return_bytes':8,'edge':'six pushes48 + stack160 + at most15 alignment at direct vsnprintf0xffffffff811b7ef2; later rbp epilogue is outside selected prefix'},
 {'function':'vsnprintf','address':'0xffffffff81f02850','local_upper_bytes':88,'new_return_bytes':8,'edge':'six pushes48 + stack40; pointer call0xffffffff81f02d06'},
 {'function':'pointer','address':'0xffffffff81f035a0','local_upper_bytes':79,'new_return_bytes':8,'edge':'two pushes16 + stack48 + at most15 alignment; %pA rust_fmt_argument call0xffffffff81f03cb1'},
 {'function':'rust_fmt_argument','address':'0xffffffff81766310','local_upper_bytes':72,'new_return_bytes':8,'edge':'stack72; core::fmt::write call0xffffffff8176636a'},
 {'function':'core::fmt::write','address':'0xffffffff81753f70','local_upper_bytes':88,'new_return_bytes':0,'edge':'six pushes48 + stack40; stop before dynamic trait callbacks'}]
assert sum(x['local_upper_bytes']+x['new_return_bytes'] for x in logging)==797
members={}
for prefix,directory in [('module-analysis',local),('linux-analysis',linux),('app-originals',app)]:
 for path in sorted(directory.rglob('*')):
  if path.is_file():members[prefix+'/'+str(path.relative_to(directory))]=path.read_bytes()
for path in (Path('/tmp/stability-observer-stack-review-inputs/audit.py'),root/'scripts/tests/fixtures/stability-owner-observer/smp_application.append.rs',root/'scripts/tests/test_owner_observations.py'):
 members['reviewed-sources/'+path.name]=path.read_bytes()
for path in [cap/'record.json',cap/'phase-overlay/record.json']:
 members['compiled-capture/'+str(path.relative_to(cap))]=path.read_bytes()
for path in (cap/'staged-source').rglob('*'):
 if path.is_file():members['compiled-staged-source/'+str(path.relative_to(cap/'staged-source'))]=path.read_bytes()
archive=root/'docs/verification/evidence/stability-observer-stack-review-20260913-2.tar.gz'
with archive.open('xb') as stream:
 with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 checked={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
assert checked==members
record={'schema_version':1,'record_kind':'stability-compiled-observer-stack-review','review_date':'2026-09-13','status':'MEASURED_REDUCTION_RECOMMENDS_APP_HELPER_BEFORE_GUEST','runtime_authorized':False,'application_acceptance':False,'production_gate_credit':False,'full_linux_stack_bound_verified':False,'build_record':ident(cap/'record.json'),'previous_review':ident(root/'docs/verification/stability-observer-stack-review-20260913-1.json'),'modules':{k:{field:v[field] for field in ('module','disassembly')} for k,v in a['modules'].items()},'retained_inputs':a['verified_retained_inputs'],'verified_retained_input_count':len(a['verified_retained_inputs']),'known_module_chains':chains,'comparison':{'worker_before_bytes':9416,'worker_after_bytes':6760,'worker_reduction_bytes':2656,'phase_ioctl_before_bytes':7080,'phase_ioctl_after_bytes':7080,'unchanged_mcctrl':True,'compiled_role_entry_frames':{'run':32,'pump':176,'accepted_closure':144,'metadata':2832,'zeroing':480},'role_service_boundaries':phase_record['stack_boundaries']},'linux_context':{'vmlinux':l['vmlinux'],'thread_size_bytes':16384,'configuration_reference':ident(root/'docs/verification/stability-observer-stack-review-20260913-1.json'),'direct_initial_formatting_path':logging,'direct_initial_formatting_path_upper_bytes':797,'ordinary_sysv_alignment_arithmetic_bytes':768,'known_module_prefix_plus_this_path':{'worker':6464+797,'ioctl':6784+797},'scope':'Only the selected direct initial vsnprintf formatting path through core::fmt::write. These sums stop before dynamic callback frames and do not bound every printk or kernel path. The ELF/header/config binding and partial graph limitations remain explicit.'},'residual_edges':['core::fmt::write and DebugStruct field helpers call dynamic formatting traits; known typed module frames exist but their complete nested closure is not established here.','vprintk_store also reaches printk_sprint before formatting; that wrapper and console flush/console drivers are not included in the797-byte selected prefix.','Linux ioctl syscall entry and stack switching, lock slowpaths/scheduler, IRQ/NMI/mitigation paths and RETURN backend stack remain separate residuals.','The reused module analyzer leaves 16-byte alignment and rbp epilogues explicitly unresolved; selected pre-epilogue callsites use independent bounded alignment arithmetic. do_syscall_64 additionally hits a CFG exploration limit/stack switch and has no certified bound.','No further whole-Linux certification is being attempted; parent will measure the final minimal observer and use controlled guest verification with this explicit residual claim.'],'source_review_recommendation':{'action':'Separate full App row collection/printing from nested mailbox observation using an existing noninlined helper and a fixed eight-token return.','reason':'Measured App emitter1472 remains live across mailbox emitter3760; removing that nested full-row buffer is the smallest remaining change with no heap/unsafe/owner complexity.','source_changed':True,'compiled_reduction_for_helper_verified':False,'application_header_and_app_rows_grouped_before_details':True,'mailbox_sampling_unchanged':True},'original_diagnostics':{'python_compatibility_failure':'Original linux_frames.py exits1 at hashlib.file_digest on hostPython3.9.12; original source, byte slices, disassembly and traceback preserved in archive module-analysis/. Streaming retry is separate.','first_linux_cfg_limitation':'Binary objdump branch operand presentation initially prevented CFG resolution. Original output preserved; fresh normalized analysis changes presentation only.','kernel_log_appended_under_explicit_parent_authority':True},'retention':{'archive':ident(archive),'member_count':len(members),'roundtrip_bytes_verified':True,'members':[{'name':n,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(members.items())]}}
out=root/'docs/verification/stability-observer-stack-review-20260913-2.json'
with out.open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
helper={'schema_version':1,'record_kind':'stability-app-row-stack-helper-source-review','review_date':'2026-09-13','status':'SOURCE_REVIEW_ACCEPTABLE_FOR_PARENT_PINNED_TESTS_AND_COMPILATION','compile_authorized':True,'runtime_authorized':False,'application_acceptance':False,'production_gate_credit':False,'compiled_stack_reduction_verified':False,'fixture':ident(root/'scripts/tests/fixtures/stability-owner-observer/smp_application.append.rs'),'parser_test':ident(root/'scripts/tests/test_owner_observations.py'),'unchanged_parser':ident(root/'scripts/application-tests/owner_observations.py'),'original_inputs':json.loads((app/'original-inputs.json').read_text()),'stack_review':ident(out),'independent_reviewer':'/root/application_audit','independent_review_statement':'Same single-lock Rows<App,8> snapshot/header/APP fields; noninlined helper returns only8tokens+used+complete. used stays bounded by Rows.push and overflow remains incomplete. Outer token traversal/order and release mailbox/pager preserved. Two-App test compares grouped/interleaved inventories across four phases and rejects orphan detail; acceptance remains false.','test_scope':'One new synthetic parser ordering/inventory test; reviewer and author have not run it. Parent owns the single affected19-test suite and fresh module3 compilation.','changes_in_scope':['New private verification_emit_apps returns fixed8tokens/count/completeness.','App records are grouped before details; all header/row schemas, counts, ordinals and original one-lock snapshot preserved.','Mailbox calls/workers still copied together under their original lock; no added heap, unsafe code, locks, ownership or timer change.'],'retention':ident(archive)}
hout=root/'docs/verification/stability-app-row-stack-helper-review-20260913.json'
with hout.open('x') as stream:json.dump(helper,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps({'stack_review':ident(out),'helper_review':ident(hout),'archive':ident(archive),'known_worker_bytes':6760,'known_ioctl_bytes':7080,'logging_prefix_upper_bytes':797},sort_keys=True))
