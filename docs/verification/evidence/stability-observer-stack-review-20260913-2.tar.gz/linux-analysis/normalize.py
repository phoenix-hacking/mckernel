from pathlib import Path
import ast,json,re
cap=Path('/tmp/stability-observer-linux-review-20260913-2')
old=json.loads((cap/'linux-analysis.json').read_text())
out=cap/'normalized';out.mkdir(exist_ok=False)
symbols={row['address']:row['name'] for row in old['all_function_symbols']}
tree=ast.parse(Path('/tmp/stability-observer-stack-review-inputs/audit.py').read_text())
tree.body=[node for node in tree.body if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
namespace={};exec(compile(tree,'retained-module-analyzer-definitions','exec'),namespace)
functions=[]
for i,item in enumerate(old['selected_symbols']):
 raw=(cap/'linux-functions'/(str(i)+'.normalized-disassembly')).read_text()
 def operand(match):
  addr=int(match[2],16)
  return match[1]+match[2]+' <'+symbols.get(addr,'local-or-unknown-target')+'>'
 normalized=re.sub(r'(\b(?:j[a-z]+|call[a-z]*)\s+)0x([0-9a-f]+)\b',operand,raw)
 path=out/(str(i)+'.disassembly');path.write_text(normalized)
 function=next(iter(namespace['parse_functions'](path).values()))
 result={k:v for k,v in function.items() if k!='instructions'}|namespace['analyze'](function,{})
 result['raw_elf_identity']=item
 align=[r for r in result['stack_instructions'] if r['op']=='and    $0xfffffffffffffff0,%rsp']
 other=[r for r in result['unknown_stack_assignments'] if r!='unresolved stack assignment: and    $0xfffffffffffffff0,%rsp']
 result['alignment_padding_upper_bytes']=15*len(align)
 result['local_frame_upper_bytes']=None if other else result['maximum_local_stack_bytes']+15*len(align)
 result['alignment_scope']='Each masked 16-byte downward stack alignment adds at most15 bytes. This conservative estimate does not assume ABI-entry residue; any other unresolved assignment makes the bound unavailable.'
 functions.append(result)
record={k:v for k,v in old.items() if k not in ('functions','all_function_symbols')}
record['functions']=functions
record['normalization']='Only presentation of direct j*/call* operands changed from 0xADDRESS to ADDRESS <ELF-symbol-or-placeholder>, enabling retained analyzer CFG and known-edge resolution. Raw bytes/disassembly remain separate immutable inputs.'
record['full_stack_bound_verified']=False
(out/'analysis.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
for f in functions:
 print(hex(f['address']),f['name'],'maxlocal',f['maximum_local_stack_bytes'],'padded_upper',f['local_frame_upper_bytes'],'unknown',f['unknown_stack_assignments'])
 for c in f['calls']:
  target=symbols.get(c['target'][1],'?') if c['target'] else '?'
  if target in symbols.values() and (target in ('vprintk','vprintk_emit','vprintk_default','vprintk_store','vsnprintf','pointer','rust_fmt_argument','printk_sprint','_printk','__x86_indirect_thunk_rax','__x86_indirect_thunk_rdx') or '3fmt5write' in target):
   print(' ',c['address'],c['depth_before'],c['kind'],target)
