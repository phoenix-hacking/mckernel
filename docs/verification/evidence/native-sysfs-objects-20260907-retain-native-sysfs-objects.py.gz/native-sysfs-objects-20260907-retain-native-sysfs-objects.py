from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
base = Path('/work')
out = base / ('native-sysfs-objects-retained-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[],
    production_gate_credit=False, declared_stage=False, sysfs_service_completed=False,
    mckernel_boot_proven=False, applications_tested=False)

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): checksum.update(chunk)
    return checksum.hexdigest()

def identity(path):
    return dict(path=str(path), sha256=digest(path), size=path.stat().st_size)

def checked(row):
    path = Path(row['path'])
    assert path.is_file() and path.stat().st_size == row['size'] and digest(path) == row['sha256'], row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target)
    row.update(path='docs/verification/evidence/' + name, source=str(source),
               unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

try:
    for category, attempts in [('module', range(1, 6)), ('guest', range(1, 6))]:
        for attempt in attempts:
            name = 'native-sysfs-objects-' + category + '-20260907-' + str(attempt)
            source = base / name
            captured = json.loads((source / 'record.json').read_text())
            expected = 'FAIL' if (category == 'module' and attempt == 2) or (category == 'guest' and attempt <= 3) else 'PASS'
            assert captured['status'] == expected, (name, captured['status'])
            for row in captured.get('inputs', []) + captured.get('compiler_inputs', []) + captured.get('outputs', []):
                checked(row)
            archive = out / (name + '.tar.gz')
            def filter_archive(info):
                return info if info.isfile() or info.isdir() else None
            with tarfile.open(archive, 'w:gz') as tar:
                tar.add(source, arcname=name, filter=filter_archive)
            assert archive.stat().st_size < 95 << 20
            row = identity(archive)
            row.update(path='docs/verification/evidence/' + archive.name, source=str(source))
            record['artifacts'].append(row)
            retain_gzip(source / 'record.json', name + '-record.json.gz')
            if (source / 'serial.log').exists(): retain_gzip(source / 'serial.log', name + '-serial.log.gz')
            record['captures'].append(dict(directory=name, status=captured['status'],
                source_parent=captured['source_parent'], started_utc=captured['started_utc'],
                finished_utc=captured['finished_utc'], qemu_exit_code=captured.get('qemu_exit_code')))
            print('Retained', name, captured['status'], flush=True)
    final_build = base / 'native-sysfs-objects-module-20260907-5'
    metadata = json.loads((final_build / 'record.json').read_text())
    for row in metadata['compiler_inputs']:
        relative = Path(row['path']).relative_to(final_build / 'source')
        current = repo / relative
        assert current.read_bytes() == Path(row['path']).read_bytes(), relative
        record['compiler_inputs'].append(dict(path=str(relative), size=row['size'], sha256=row['sha256']))
    record['linux_layout_values'] = metadata['layout']
    assert len(metadata['layout']) == 21
    guest = json.loads((base / 'native-sysfs-objects-guest-20260907-5/record.json').read_text())
    assert (guest['module_cycles'], guest['namespace_races'], guest['concurrent_reads'], guest['concurrent_writes']) == (2, 32, 1024, 1024)
    for attempt in [4, 5]:
        serial = (base / ('native-sysfs-objects-guest-20260907-' + str(attempt)) / 'serial.log').read_text()
        # Failed duplicate creates intentionally invoke Linux's diagnostic
        # stacks. Require those stacks to be entirely inside explicit spans.
        pieces = serial.split('MCKERNEL_SYSFS_VERIFY expected_duplicate_begin')
        assert len(pieces) == 3
        outside = pieces[0]
        for piece in pieces[1:]:
            expected, tail = piece.split('MCKERNEL_SYSFS_VERIFY expected_duplicate_end', 1)
            for name in ["'/mckernel_sysfs_verify/child'", "'/mckernel_sysfs_verify/child/value'", "'/mckernel_sysfs_verify/alias'"]:
                assert 'cannot create duplicate filename ' + name in expected, name
            outside += tail
        for bad in ['Call Trace:', 'BUG:', 'Oops:', 'WARNING:', 'Kernel panic']:
            assert bad not in outside, (attempt, bad)
        assert serial.count('retiring active=1') == 2
        assert serial.count('retired live=0 active=0') == 2
        assert serial.count('removed_at_seek=1') == 2
    for name in ['build-native-sysfs-objects.py', 'run-native-sysfs-objects-guest.py', 'retain-native-sysfs-objects.py']:
        retain_gzip(base / name, 'native-sysfs-objects-20260907-' + name + '.gz')
    for name in ['native-vdso-service-checkpoint-20260907.json', 'native-vdso-exports-checkpoint-20260907.json']:
        path = repo / 'docs/verification' / name
        row = identity(path); row['path'] = str(path.relative_to(repo)); record['references'].append(row)
    # Validate complete gzip streams and the independently retained plain
    # source/record/serial hashes before copying any archive to the repository.
    for row in record['artifacts']:
        target = out / Path(row['path']).name
        checksum = hashlib.sha256(); size = 0
        with gzip.open(target, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                checksum.update(chunk); size += len(chunk)
        if 'unpacked_size' in row:
            assert size == row['unpacked_size'] and checksum.hexdigest() == row['unpacked_sha256'], row
    subprocess.run(['git', '-C', str(repo), 'diff', '--check'], check=True)
    record.update(status='PASS', module_cycles=2, namespace_races=32,
        concurrent_reads=1024, concurrent_writes=1024, active_callback_drains=2,
        drain_milliseconds=guest['drain_milliseconds'],
        passed=[
            'The actual native Rust directory/file/link adapter compiles against the pinned kernel with 21 independent C/Rust layout values and ELF/no-SIMD checks',
            'Linux reads and writes the actual Rust callback data, preserves numeric boundaries and errors, and rejects callback byte-count overflows',
            'Failed duplicate directory/file/link publication preserves the existing objects; invalid component names are rejected before Linux mutation',
            'Parent-before-descendant retirement followed by name reuse preserves the replacement subtree',
            'Two module lifetimes complete 1024 concurrent writes and reads, 32 concurrent parent/file retirement races with 64 joined kernel threads, and namespace reuse',
            'Each module removal observes an active callback, waits for its completion, retires all Value payloads, removes the namespace and rejects seek on an already-open removed file with ENODEV',
            'All retained input/output/compiled-source hashes and complete gzip streams verify; every initial failure is preserved'],
        limitations=[
            'The current consumer is the disposable native Linux verification module; the native production SMP/mcctrl declared build graph has not integrated this source',
            'No actual McKernel SYSFS_REQ_SETUP request has been completed. OS-device binding, the native tree, topology/files, shared-buffer ownership and message adaptation remain to implement',
            'Real McKernel boot still stops at sysfs setup after the previously proven vDSO reply. Continuing runtime dispatch, remaining host services, full readiness, application launch/tests and native shutdown remain open',
            'Object callbacks must not remove themselves or ancestors, or acquire the namespace mutex used while draining their own removal',
            'Allocation-pressure fault injection and complete native OS lifecycle/restoration are not proven by this object fixture',
            'Full-suite and declared lifecycle/unsafe-FFI/license integration, full McKernel/linked-support Rust or assembly completion and independent production acceptance remain required'])
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'native-sysfs-objects-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], 'retained', len(record['artifacts']), 'native sysfs artifacts', flush=True)
