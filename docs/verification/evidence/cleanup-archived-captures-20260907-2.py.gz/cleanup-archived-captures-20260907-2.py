"""One-time, audited maintenance; never builds or runs kernel code on the host."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile

REPO = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
PLAN = WORK / 'storage-cleanup-20260907-2-plan.json'
REPORT = WORK / 'storage-cleanup-20260907-2-report.json'
BRANCH = 'refs/heads/codex/local-native-staging-repair'
KEEP = {
    'native-topology-kernel-20260907-1',
    'native-topology-module-20260907-1',
    'native-sysfs-tree-module-20260907-2',
    'native-source', 'native-build-base-24a151fe',
    'native-irq-transport-exact-stage-20260907-1',
    'native-vdso-kernel-20260907-3', 'native-sysfs-os-module-20260907-2',
    'native-ikc-prototype-20260907-9', 'native-sysfs-objects-module-20260907-5',
    'native-vdso-module-20260907-1', 'native-trampoline-region-module-20260907-3',
    'native-runtime-local-base-24a151fe', 'native-runtime-24a151fe',
    'mckernel-native-irq-images-20260907-10',
    'mckernel-native-irq-images-20260907-11',
    'mckernel-native-irq-images-20260907-13',
}


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)


def hashes(path):
    size = path.stat().st_size
    sha = hashlib.sha256()
    blob = hashlib.sha1(('blob %d\0' % size).encode())
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            sha.update(chunk)
            blob.update(chunk)
    return dict(size=size, sha256=sha.hexdigest(), git_blob=blob.hexdigest())


def entries(root):
    # Do not follow symlinks, including directory symlinks.
    yield root
    if root.is_dir() and not root.is_symlink():
        for parent, dirs, files in os.walk(root, followlinks=False):
            for name in sorted(dirs + files):
                yield Path(parent) / name


def snapshot(root):
    result = {}
    for path in entries(root):
        st = path.lstat()
        assert st.st_dev == WORK.stat().st_dev, ('cross-device', str(path))
        row = dict(mode=st.st_mode, size=st.st_size, inode=st.st_ino,
                   mtime_ns=st.st_mtime_ns, ctime_ns=st.st_ctime_ns,
                   blocks=st.st_blocks)
        if stat.S_ISLNK(st.st_mode):
            row['target'] = os.readlink(path)
        result[str(path.relative_to(root))] = row
    return result


def disk_state():
    return {str(p): dict(zip(('total', 'used', 'free'), shutil.disk_usage(p)))
            for p in (Path('/'), WORK)}


def eligible(name):
    return name not in KEEP and (
        '-guest-' in name
        or name in {'native-sysfs-objects-module-20260907-' + str(n) for n in range(1, 5)}
        or name in {'native-sysfs-os-module-20260907-1',
                    'native-sysfs-tree-module-20260907-1'})


def archive_covers(source, archive):
    before = snapshot(source)
    problems = []
    with tarfile.open(archive, 'r:gz') as tar:
        members = {}
        for member in tar.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts, member.name
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in members, ('duplicate-member', member.name)
            members[relative] = member
        for name, row in before.items():
            member = members.get(name)
            mode = row['mode']
            if member is None:
                problems.append([name, 'absent-from-archive'])
                continue
            if stat.S_IMODE(mode) != stat.S_IMODE(member.mode):
                problems.append([name, 'mode-differs'])
                continue
            if stat.S_ISDIR(mode):
                if not member.isdir(): problems.append([name, 'type-differs'])
            elif stat.S_ISLNK(mode):
                if not member.issym() or row['target'] != member.linkname:
                    problems.append([name, 'symlink-differs'])
            elif stat.S_ISREG(mode) and (member.isfile() or member.islnk()):
                sha = hashlib.sha256()
                count = 0
                with tar.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        sha.update(chunk)
                        count += len(chunk)
                current = hashes(source / name)
                if count != current['size'] or sha.hexdigest() != current['sha256']:
                    problems.append([name, 'content-differs'])
            else:
                problems.append([name, 'unsupported-type'])
    assert snapshot(source) == before, ('changed-during-audit', str(source))
    return before, problems


def audit():
    assert not PLAN.exists() and not REPORT.exists()
    head = git('rev-parse', 'HEAD').decode().strip()
    remote = git('ls-remote', 'origin', BRANCH).decode().split()[0]
    assert head == remote, ('head-not-pushed', head, remote)
    tracked = {}
    for raw in git('ls-tree', '-r', '-z', head, '--', 'docs/verification').split(b'\0'):
        if raw:
            info, path = raw.split(b'\t', 1)
            tracked[path.decode()] = info.split()[2].decode()
    checked = {}

    def committed(path, expected=None):
        rel = str(path.relative_to(REPO))
        if rel not in checked:
            assert path.is_file() and not path.is_symlink(), rel
            identity = hashes(path)
            assert identity['git_blob'] == tracked[rel], ('not-exact-HEAD', rel)
            if path.suffix == '.gz':
                with gzip.open(path, 'rb') as stream:
                    while stream.read(1 << 20): pass
            checked[rel] = identity
        identity = checked[rel]
        if expected:
            assert identity['size'] == expected['size'] and identity['sha256'] == expected['sha256'], rel
        return dict(path=rel, **identity)

    plan = dict(started_utc=now(), head=head, remote_head=remote,
                disk_before=disk_state(), protected=sorted(KEEP),
                directories=[], duplicate_files=[], skipped=[])
    artifacts = {}
    sources = {}
    for manifest in sorted((REPO / 'docs/verification').glob('*.json')):
        if str(manifest.relative_to(REPO)) not in tracked: continue
        value = json.loads(manifest.read_text())
        if not isinstance(value, dict): continue
        for row in value.get('artifacts', []):
            if not isinstance(row, dict) or not row.get('path', '').endswith('.gz'): continue
            if not row['path'].startswith('docs/verification/evidence/'): continue
            if 'size' not in row or 'sha256' not in row: continue
            artifacts.setdefault(Path(row['path']).name, []).append((manifest, row))
            source = row.get('source', '')
            if source.startswith('/work/') and source.count('/') == 2 and eligible(source[6:]) and row['path'].endswith('.tar.gz'):
                sources[source[6:]] = (manifest, row)
    for name, (manifest, row) in sorted(sources.items()):
        source = WORK / name
        if not source.is_dir() or source.is_symlink(): continue
        committed(manifest)
        archive = committed(REPO / row['path'], row)
        state, problems = archive_covers(source, REPO / row['path'])
        if problems:
            plan['skipped'].append(dict(source=str(source), reason=problems))
            print('KEEP incomplete archive', name, problems[:2], flush=True)
            continue
        plan['directories'].append(dict(source=str(source), archive=archive,
            manifest=str(manifest.relative_to(REPO)), snapshot=state,
            allocated_bytes=sum(r['blocks'] * 512 for r in state.values())))
        print('BACKED UP', name, len(state), 'entries', flush=True)
    # Remove only additional compressed copies in historical retention folders.
    # Current inputs, capture archives in Git, and the helpers themselves stay.
    for folder in sorted(WORK.iterdir()):
        if not folder.is_dir() or folder.is_symlink() or 'retained' not in folder.name: continue
        for path in sorted(folder.rglob('*.gz')):
            if not path.is_file() or path.is_symlink() or path.name not in artifacts: continue
            if any(p.is_symlink() for p in path.parents if p != WORK): continue
            identity = hashes(path)
            for manifest, row in artifacts[path.name]:
                if identity['sha256'] == row['sha256'] and identity['size'] == row['size']:
                    committed(manifest)
                    archive = committed(REPO / row['path'], row)
                    plan['duplicate_files'].append(dict(source=str(path), archive=archive,
                        snapshot=snapshot(path), allocated_bytes=path.stat().st_blocks * 512))
                    break
    plan.update(finished_utc=now(), verified_committed_files=checked)
    plan['removable_allocated_bytes'] = sum(r['allocated_bytes'] for r in plan['directories'] + plan['duplicate_files'])
    save(PLAN, plan)
    print('AUDIT COMPLETE', len(plan['directories']), 'directories', len(plan['duplicate_files']),
          'duplicate archives', plan['removable_allocated_bytes'], 'allocated bytes', flush=True)


def apply():
    assert not REPORT.exists()
    plan = json.loads(PLAN.read_text())
    assert git('rev-parse', 'HEAD').decode().strip() == plan['head']
    for rel, expected in plan['verified_committed_files'].items():
        assert hashes(REPO / rel) == expected, ('archive-changed', rel)
    targets = plan['directories'] + plan['duplicate_files']
    for row in targets:
        path = Path(row['source'])
        assert path.is_relative_to(WORK) and path != WORK and not path.is_symlink()
        assert path.relative_to(WORK).parts[0] not in KEEP
        assert snapshot(path) == row['snapshot'], ('source-changed', str(path))
    report = dict(started_utc=now(), status='running', head=plan['head'],
                  disk_before=disk_state(), removed=[])
    save(REPORT, report)
    try:
        for row in targets:
            path = Path(row['source'])
            assert snapshot(path) == row['snapshot'], ('source-changed', str(path))
            if path.is_dir(): shutil.rmtree(path)
            else: path.unlink()
            assert not path.exists(), str(path)
            report['removed'].append({k: v for k, v in row.items() if k != 'snapshot'})
            save(REPORT, report)
        report.update(status='PASS', disk_after=disk_state(),
                      removed_allocated_bytes=sum(r['allocated_bytes'] for r in targets))
    except BaseException as error:
        report.update(status='FAIL', error=str(error))
        raise
    finally:
        report['finished_utc'] = now()
        save(REPORT, report)
    print('CLEANUP COMPLETE', len(report['removed']), 'items', report['removed_allocated_bytes'],
          'allocated bytes; scratch trim still required', flush=True)


if __name__ == '__main__':
    assert os.getuid() == 1000
    assert len(sys.argv) == 2 and sys.argv[1] in ('audit', 'apply')
    (audit if sys.argv[1] == 'audit' else apply)()
