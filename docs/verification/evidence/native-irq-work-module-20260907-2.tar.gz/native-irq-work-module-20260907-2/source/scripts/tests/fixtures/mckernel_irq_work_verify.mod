/work/native-irq-work-module-20260907-2/source/scripts/tests/fixtures/mckernel_irq_work_verify.o
