from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, struct, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-irq-work-module-20260907-' + sys.argv[1])
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-startup-exact-stage-20260907-1')
assert (build / '.config').read_bytes() == (prior / 'resolved.config').read_bytes()
out.mkdir()
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), inputs=[], production_gate_credit=False, test_transport='mock boot and guest context; exported Linux irq_work_queue')
for relative in ['kernel/rust/smp_ikc.rs', 'kernel/rust/llist.rs', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs', 'scripts/tests/fixtures/mckernel_irq_work_layout.c']:
    path = out / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / relative, path)
    record['inputs'].append(identity(path))
for path in [build / '.config', build / 'Module.symvers', build / 'rust/bindings/bindings_generated.rs', source / 'include/linux/irq_work.h', source / 'include/linux/smp_types.h', source / 'kernel/irq_work.c']:
    record['inputs'].append(identity(path))
    shutil.copyfile(path, out / path.name.lstrip('.'))
shutil.copyfile(__file__, out / 'build-helper.py')
module = out / 'source/scripts/tests/fixtures'
(module / 'Kbuild').write_text("obj-m += mckernel_irq_work_verify.o\nRUSTFLAGS_mckernel_irq_work_verify.o += --cfg native_linux_irq_work_v6_12 --check-cfg='cfg(native_linux_irq_work_v6_12)'\n")
base_command = shlex.split((prior / 'module-build.command').read_text())[:-3] + ['M=' + str(module)]
commands = [base_command + ['mckernel_irq_work_layout.o'], base_command + ['modules']]
record['commands'] = commands
try:
    with (out / 'module-build.log').open('wb') as log:
        for command in commands:
            print('RUN', shlex.join(command), flush=True)
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run(['objcopy', '--dump-section', '.mckernel_irq_layout=' + str(out / 'layout.bin'), str(module / 'mckernel_irq_work_layout.o')], check=True)
    layout = list(struct.unpack('<12Q', (out / 'layout.bin').read_bytes()))
    assert layout == [32, 8, 0, 8, 12, 14, 16, 24, 4, 1, 2, 32], layout
    record['header_layout'] = layout
    for name in ['mckernel_irq_work_verify.ko', 'mckernel_irq_work_layout.o']:
        shutil.copyfile(module / name, out / name)
    record['outputs'] = [identity(out / name) for name in ['mckernel_irq_work_verify.ko', 'mckernel_irq_work_layout.o', 'layout.bin']]
    for command, filename in [(['readelf', '-h', str(out / 'mckernel_irq_work_verify.ko')], 'module-elf-header.txt'), (['nm', '-u', str(out / 'mckernel_irq_work_verify.ko')], 'module-undefined.txt')]:
        (out / filename).write_bytes(subprocess.check_output(command))
    assert '\tirq_work_queue' in (build / 'Module.symvers').read_text()
    assert ' U irq_work_queue\n' in (out / 'module-undefined.txt').read_text()
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Build status', record['status'], 'capture', out, flush=True)
    if record['status'] != 'PASS': print((out / 'module-build.log').read_text()[-18000:], flush=True)
