#!/usr/bin/env python3
"""Independent oracle for retained linux-sealed collector reports."""
import json
EXPECTED={"missing-setup":(0,"SETUP_ERROR","setup-pipe-incomplete",0,False),"partial-setup":(383,"SETUP_ERROR","setup-pipe-incomplete",0,False),"interrupt-completed-wait":(384,"INTERRUPTED","collector-interrupted",15,True)}
def validate(r,case):
    if case not in EXPECTED or not isinstance(r,dict): return False
    n,s,f,sig,ready=EXPECTED[case]
    if (r.get("kind"),r.get("schema_version"),r.get("status"),r.get("first_failure"))!=("linux-sealed-infrastructure-collection",1,s,f): return False
    if r.get("first_failure_errno")!=(4 if sig else 71) or r.get("collector_interruption_signal")!=sig: return False
    if any(r.get(k) is not False for k in ("application_acceptance","transport_acceptance","backend_enabled")): return False
    if r.get("setup_ready_record") is not ready or r.get("setup_error_record") is not False or r.get("setup_validated") is not ready: return False
    streams=r.get("streams",{}); child=r.get("linux_child") or {}; wait=child.get("wait") or {}
    if any(streams.get(k) is not True for k in ("setup_eof","stdout_eof","stderr_eof")): return False
    if child.get("raw_wait_status")!=0 or wait.get("exited") is not True or wait.get("exit_code")!=0: return False
    if r.get("cleanup_complete") is not True or r.get("group_identity_pinned") is not True: return False
    if r.get("post_exec_backing_observed") is not False: return False
    if r.get("outer_wait", {}).get("exited") is not True or r.get("outer_wait", {}).get("exit_code") != 1: return False
    words=r.get("setup_words")
    if not isinstance(words,list) or len(words)!=48 or (case!="interrupt-completed-wait" and any(words)): return False
    if case=="interrupt-completed-wait" and words[2:5]!=[1,1,0]: return False
    if case!="interrupt-completed-wait" and r.get("post_exec_backing_observed") is not False: return False
    names={a.get("attempted_name") for a in r.get("artifacts",[]) if isinstance(a,dict)}
    required={"request.bin","selected-inputs.bin","argv.nul","env.nul","events.jsonl","executable.verified.bin","stdout.bin","stderr.bin","setup.bin"}
    if names!=required: return False
    setup=next(a for a in r["artifacts"] if a.get("attempted_name")=="setup.bin")
    if not (setup.get("seen_bytes")==n and setup.get("stored_bytes")==n and setup.get("truncated") is False and setup.get("io_error") is False): return False
    if case == "interrupt-completed-wait" and r.get("devnull", {}).get("output") != "DEVNULL\\n": return False
    events = r.get("event_trace", [])
    return isinstance(events, list) and events == sorted(events, key=lambda x: x.get("monotonic_ns", -1)) and all(x.get("monotonic_ns", 0) <= r.get("deadlines", {}).get("process", 0) or x.get("name") == "cleanup-finished" for x in events)
def main():
    import argparse
    p=argparse.ArgumentParser(); p.add_argument("--record",required=True); p.add_argument("--case",required=True); a=p.parse_args(); ok=validate(json.load(open(a.record,encoding="utf-8")),a.case); print("PASS" if ok else "FAIL"); raise SystemExit(0 if ok else 1)
if __name__=="__main__": main()
