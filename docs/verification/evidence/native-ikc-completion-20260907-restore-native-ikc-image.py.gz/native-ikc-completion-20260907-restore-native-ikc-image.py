from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shlex, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
prior = Path('/work/mckernel-native-irq-images-20260907-11')
out = Path('/work/native-ikc-image-restoration-20260907-' + sys.argv[1])
out.mkdir()
build = prior / 'native-rust/kernel'
image = build / 'mckernel.img'
old = json.loads((prior / 'record.json').read_text())
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), commands=[], status='running', production_gate_credit=False)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def run(label, command):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=build, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, label
try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(image, out / 'mutated-native-binutils.img')
    expected = old['images'][2]['outputs'][0]['sha256']
    record.update(expected_sha256=expected, mutated_sha256=sha(image))
    command = shlex.split((build / 'CMakeFiles/mckernel.img.dir/link.txt').read_text())
    command[command.index('-o') + 1] = str(out / 'relinked.img')
    command = ['-Map=' + str(out / 'relinked.img.map') if item.startswith('-Map=') else item for item in command]
    run('original-link', command)
    run('original-binutils-output', ['objcopy', '--dump-section', '.note.mckernel.boot=' + str(out / 'note.bin'), str(out / 'relinked.img'), str(out / 'restored.img')])
    record.update(relinked_sha256=sha(out / 'relinked.img'), restored_sha256=sha(out / 'restored.img'))
    assert record['restored_sha256'] == expected
    shutil.copyfile(out / 'restored.img', image)
    assert sha(image) == expected
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
