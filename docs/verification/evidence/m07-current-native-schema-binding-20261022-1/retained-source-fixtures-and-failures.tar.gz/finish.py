from pathlib import Path
D=Path(__file__).parent;p=D/'bounded-correction-1/prepare_outer_diagnostic_successor.EXPERT-CORRECTION-1.py';s=p.read_text()
# Helper is shared through constructor literal and appended snapshot; avoid binder-only load dependency.
s=s.replace('a=load(acceptance)','a=json.loads(Path(acceptance).read_bytes())').replace("binding=load(paths['binding'])","binding=json.loads(paths['binding'].read_bytes())")
# The old checker requires actual physical output. This derivative explicitly checks an unresolved packet instead.
patch=''' checker=checker.replace("    physical=json.loads(Path(cfg['latest_physical']['path']).read_bytes())", "    physical_pending=cfg['latest_physical'] is None\\n    physical=None if physical_pending else json.loads(Path(cfg['latest_physical']['path']).read_bytes())")
 checker=checker.replace("    snapshot.terminal_joins(physical,b)\\n    assert physical==snapshot.checked(cfg['latest_physical'])", "    if physical_pending:\\n        assert b['physical_review'] is None and all(v is None for v in b['physical_predecessor'].values())\\n    else:\\n        snapshot.terminal_joins(physical,b)\\n        assert physical==snapshot.checked(cfg['latest_physical'])")
 checker=checker.replace("    # Invoke the real", "    # Invoke the real")
 checker=checker.replace("    before=set(D.rglob('*.PENDING-STATIC-CORRECTED'));assert not before", "    suffix='.PENDING-PHYSICAL' if physical_pending else '.PENDING-STATIC-CORRECTED'\\n    before=set(D.rglob('*'+suffix));assert not before")
 checker=checker.replace("produced=set(D.rglob('*.PENDING-STATIC-CORRECTED'))", "produced=set(D.rglob('*'+suffix))")
 checker=checker.replace(".json.PENDING-STATIC-CORRECTED'", ".json'+suffix").replace(".py.PENDING-STATIC-CORRECTED'", ".py'+suffix")
 checker=checker.replace("    for key in ('container_id','owner_nonce'):", "    for key in (() if physical_pending else ('container_id','owner_nonce')):")
 checker=checker.replace("PASS_ACTUAL_CURRENT_KIND_PENDING19_AND_CALLER_BODY_ONLY", "PASS_CURRENT_AUTHORITY_PENDING19_CALLER_BODY_NO_PHYSICAL_OR_RUNTIME_CREDIT")
'''
s=s.replace(" write(out/'check_current_whole_caller.py',checker)",patch+" write(out/'check_current_whole_caller.py',checker)")
final=D/'final-source';final.mkdir(mode=0o700);(final/p.name).write_text(s)
# Final closure consumer requires explicit genuine reviewed descriptor rather than stale literal.
f=(D/'originals/check_final_static_closure.py').read_text().replace('json,os,socket,stat,subprocess','json,os,socket,stat,subprocess,sys')
a=f.index('REVIEW=Path(');b=f.index('FIELDS=',a);f=f[:a]+"REVIEW=None\nREVIEW_SHA=None\n"+f[b:]
f=f.replace(' review=ref(REVIEW);assert review[\'sha256\']==REVIEW_SHA and review[\'bytes\']==847'," need(len(sys.argv)==4,'usage: check_final_static_closure.py GENUINE_PENDING_REVIEW SHA256 BYTES')\n review=ref(sys.argv[1]);need(review['sha256']==sys.argv[2] and review['bytes']==int(sys.argv[3]),'whole genuine independent pending review descriptor')\n authority=load(sys.argv[1]);need(authority['implementation_ownership'] is False and authority['reviewer'] and authority['decision'].startswith('PASS_'),'independent passing source/data review')")
(final/'check_final_static_closure.py').write_text(f)
