"""Actual snapshot static consumer with only unpublished-output/static-review boundaries mocked.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
"""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,os,socket,subprocess,sys
D=Path(__file__).parent;S=D/'review-ready-source/bound-runtime-source-expert-correction-1'
def forbidden(*a,**k):raise AssertionError('test prohibits root/process/socket/workload')
subprocess.Popen=forbidden;subprocess.run=forbidden;socket.socket=forbidden;os.execve=forbidden
spec=importlib.util.spec_from_file_location('actual_current_snapshot',S/'root_manual_snapshot_threads.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.checked
pending={}
for p in S.rglob('*.PENDING-PHYSICAL'):
 raw=p.read_bytes();pending[str(p).removesuffix('.PENDING-PHYSICAL')]=raw
mocked=[]
def pending_checked(row):
 if row==dict(path=None,sha256=None,bytes=None):
  mocked.append('UNAVAILABLE_INDEPENDENT_STATIC_REVIEW');return {'TEST_BOUNDARY_ONLY':True}
 if row['path'] in pending:
  raw=pending[row['path']];assert hashlib.sha256(raw).hexdigest()==row['sha256'] and len(raw)==row['bytes'];mocked.append(row['path']);return json.loads(raw)
 return original(row)
m.checked=pending_checked
b=json.loads((S/'fresh-snapshot-bindings.json.PENDING-PHYSICAL').read_bytes())
proposal,owner=m.static_joins(b);cases=['actual-complete-static-joins-current-normalization-image-only-stage-real-owner']
def refused(name,fn):
 try:fn()
 except (m.Refusal,ValueError,AssertionError,KeyError):cases.append(name);return
 raise AssertionError('missing refusal '+name)
for key in ['mandatory_consumer_review','stage_review','actual_original_preflight','actual_binding_result']:
 altered=copy.deepcopy(b);altered[key]['sha256']='0'*64;refused('changed-authority-descriptor-'+key,lambda a=altered:m.static_joins(a))
for key in ['root_owner_argv','accepted_owner_argv','inside_argv','qemu_argv']:
 altered=copy.deepcopy(b);altered[key]=altered[key]+['CHANGED'];refused('changed-'+key,lambda a=altered:m.static_joins(a))
altered=copy.deepcopy(b);altered['repaired_image_sha256']='0'*64;refused('changed-image-binding',lambda:m.static_joins(altered))
altered=copy.deepcopy(b);altered['payload_contract']={};refused('changed-payload-binding',lambda:m.static_joins(altered))
# Real source binder final mode must refuse pending physical state before producing data.
tree=ast.parse((S/'bind_numa_native_packet.py').read_text());block=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='physical_pending' for t in n.targets));i=tree.body.index(block)
segment=ast.Module(body=tree.body[i:i+2],type_ignores=[])
refused('final-binder-requires-genuine-physical',lambda:exec(compile(segment,'actual-binder-physical-guard','exec'),{'c':{'latest_physical':None},'final':True,'need':m.need}))
result=dict(status='PASS_ACTUAL_SNAPSHOT_STATIC_CONSUMER_AND_CHANGED_AUTHORITY_NEGATIVES_WITH_EXPLICIT_LATE_BOUNDARY_MOCKS',cases=cases,mocks=sorted(set(mocked)),actual_physical=None,static_review=None,snapshot=None,runtime_release=None,root_operations=0,guest_runs=0)
(D/'snapshot-static-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'cases':len(cases),'root_operations':0,'guest_runs':0}))
