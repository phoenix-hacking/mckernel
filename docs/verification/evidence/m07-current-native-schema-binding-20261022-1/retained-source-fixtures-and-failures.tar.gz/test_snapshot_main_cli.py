"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Execute unchanged script via runpy __main__; mock only root/live/physical/publication edges.
"""
from pathlib import Path
import copy,hashlib,json,os,runpy,socket,subprocess,sys,traceback
D=Path(__file__).parent;NEW=D/'cli-order-bounded-correction-1/bound-runtime-source-expert-correction-1';OLD=D/'review-ready-source/bound-runtime-source-expert-correction-1'
reports=[]
def forbidden(*a,**k):raise AssertionError('no child/socket/exec in CLI regression')
subprocess.Popen=forbidden;subprocess.run=forbidden;socket.socket=forbidden;os.execve=forbidden

def run_actual_main(root,changed=False):
 source=root/'root_manual_snapshot_threads.py';text=source.read_text();entry=next(i for i,line in enumerate(text.splitlines(),1) if line=="if __name__=='__main__':raise SystemExit(main())")
 pending={str(p).removesuffix('.PENDING-PHYSICAL'):p.read_bytes() for p in root.rglob('*.PENDING-PHYSICAL')}
 bpath=str(root/'fresh-snapshot-bindings.json');braw=pending[bpath];calls=[];edges=[];published=[]
 def install(g):
  checked=g['checked']
  def boundary_checked(row):
   if row==dict(path=None,sha256=None,bytes=None):edges.append('UNAVAILABLE_STATIC_REVIEW');return {'TEST_BOUNDARY_ONLY':True}
   if row['path']=='/TEST-BOUNDARY/current-physical.json':edges.append('UNAVAILABLE_PHYSICAL_REPORT');return {'TEST_BOUNDARY_ONLY':True}
   if row['path'] in pending:
    raw=pending[row['path']];assert hashlib.sha256(raw).hexdigest()==row['sha256'];assert 'bytes' not in row or len(raw)==row['bytes'];value=json.loads(raw)
    if row['path']==bpath:
     value['physical_review']=dict(path='/TEST-BOUNDARY/current-physical.json',sha256='0'*64,bytes=0)
     if changed:value['mandatory_consumer_review']['sha256']='0'*64
    return value
   return checked(row)
  def terminal(t,b):edges.append('PHYSICAL_TERMINAL_JOINS');assert t=={'TEST_BOUNDARY_ONLY':True}
  def collect(b,proposal,owner):edges.append('ROOT_LIVE_PROC_COMMANDS');return dict(boot_id='TEST-BOUNDARY',capacity={},mem_available_bytes=0,included_usage_percent=0,released_paths_absent={},image_id='TEST-BOUNDARY',cgroup={})
  def validate(*args):edges.append('LIVE_EDGE_VALIDATION')
  def publish(result):edges.append('ROOT_PUBLICATION');published.append(result);return dict(path='/TEST-BOUNDARY/no-output',sha256='0'*64,bytes=0)
  g.update(checked=boundary_checked,terminal_joins=terminal,collect_live=collect,validate_live=validate,publish=publish)
 def trace(frame,event,arg):
  if frame.f_code.co_filename==str(source):
   if event=='line' and frame.f_lineno==entry:install(frame.f_globals)
   if event=='call':calls.append(frame.f_code.co_name)
  return trace
 argv=sys.argv;uid,euid=os.getuid,os.geteuid;oldtrace=sys.gettrace();exc=None;code=None
 sys.argv=[str(source),'--bindings-sha256',hashlib.sha256(braw).hexdigest(),'--terminal','/TEST-BOUNDARY/current-physical.json','--terminal-sha256','0'*64]
 os.getuid=lambda:0;os.geteuid=lambda:0
 try:
  sys.settrace(trace)
  try:runpy.run_path(str(source),run_name='__main__')
  except SystemExit as e:code=e.code
  except Exception as e:exc=e;failure=traceback.format_exc()
 finally:sys.settrace(oldtrace);os.getuid=uid;os.geteuid=euid;sys.argv=argv
 record=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),entry_line=entry,main_calls=calls.count('main'),static_joins_calls=calls.count('static_joins'),normalization_calls=calls.count('accepted_current_normalization'),stage_calls=calls.count('accepted_current_stage'),code=code,exception_type=None if exc is None else type(exc).__name__,exception=None if exc is None else str(exc),mocked_edges=sorted(set(edges)),publication_calls=len(published),actual_outputs=0)
 reports.append(record)
 if exc is not None:record['traceback']=failure
 return record
old=run_actual_main(OLD);assert old['exception_type']=='NameError' and 'accepted_current_normalization' in old['exception'] and old['main_calls']==old['static_joins_calls']==1 and old['publication_calls']==0
new=run_actual_main(NEW);assert new['exception'] is None and new['code']==0 and new['main_calls']==new['static_joins_calls']==new['normalization_calls']==new['stage_calls']==1 and new['publication_calls']==1
changed=run_actual_main(NEW,True);assert changed['exception_type']=='Refusal' and changed['exception']=='input hash' and changed['publication_calls']==0
# Actual binder __main__ final path: explicitly mocked review bytes are test input;
# accepted source/normalization/parent checks remain real and null physical must refuse.
review=D/'MOCK-BOUNDARY-ONLY-review.json';review.write_text('{"TEST_BOUNDARY_ONLY":true}\n');reviewsha=hashlib.sha256(review.read_bytes()).hexdigest();argv=sys.argv;sys.argv=[str(NEW/'bind_numa_native_packet.py'),str(review),reviewsha]
before=set(NEW.rglob('*'))
try:
 try:runpy.run_path(str(NEW/'bind_numa_native_packet.py'),run_name='__main__')
 except ValueError as e:assert str(e)=='genuine independent physical acceptance required before final binding';binder=dict(result='REFUSED',message=str(e),actual_main=True,review_input='MOCK_BOUNDARY_ONLY')
 else:raise AssertionError('final physical refusal absent')
finally:sys.argv=argv
assert before==set(NEW.rglob('*'))
result=dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',status='PASS_ACTUAL_MAIN_CURRENT_AUTHORITIES_CLI_ORDER_NEGATIVE_AND_FINAL_PHYSICAL_REFUSAL_WITH_EXPLICIT_BOUNDARY_MOCKS',cases=reports,final_binder=binder,source_order_family='retained candidate NameError reproduced; one bounded correction passed',actual_physical=None,snapshot=None,runtime_release=None,root_operations=0,guest_runs=0)
(D/'snapshot-main-cli-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'cases':4,'root_operations':0,'guest_runs':0}))
