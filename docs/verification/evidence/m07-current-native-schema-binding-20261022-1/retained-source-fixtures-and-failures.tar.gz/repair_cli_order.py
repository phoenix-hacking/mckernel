from pathlib import Path
D=Path(__file__).parent;old=D/'review-ready-source';out=D/'cli-order-bounded-correction-1';out.mkdir(mode=0o700)
p=old/'prepare_outer_diagnostic_successor.EXPERT-CORRECTION-1.py';s=p.read_text();a=s.index(' snap +=');b=s.index(" write(out/'root_manual_snapshot_threads.py'",a)
oldline=s[a:b];new=oldline.replace(' snap += ', ' snapshot_helpers = ')
new += " entry=\"if __name__=='__main__':raise SystemExit(main())\"\n need(snap.count(entry)==1,'unique actual snapshot CLI entrypoint')\n snap=snap.replace(entry,snapshot_helpers+'\\n'+entry)\n"
s=s[:a]+new+s[b:];(out/p.name).write_text(s);(out/'check_final_static_closure.py').write_bytes((old/'bound-runtime-source-expert-correction-1/check_final_static_closure.py').read_bytes())
