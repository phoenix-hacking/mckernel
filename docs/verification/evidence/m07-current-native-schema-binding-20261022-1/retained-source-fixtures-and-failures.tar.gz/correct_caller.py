from pathlib import Path
import json
D=Path(__file__).parent;src=D/'final-source/prepare_outer_diagnostic_successor.EXPERT-CORRECTION-1.py';s=src.read_text()
s=s.replace(" checker=checker.replace(\"    for key in", " checker=checker.replace(\"Q/'FINAL-SEVEN-ROOT-CALL-DATA.json'+suffix\", \"Q/('FINAL-SEVEN-ROOT-CALL-DATA.json'+suffix)\").replace(\"Q/'NATIVE-COHERENT-REVIEW-PACKET.json'+suffix\", \"Q/('NATIVE-COHERENT-REVIEW-PACKET.json'+suffix)\").replace(\"Q/'FINAL-IHK-LOGGING-CHECK-CONFIG.json'+suffix\", \"Q/('FINAL-IHK-LOGGING-CHECK-CONFIG.json'+suffix)\").replace(\"Q/'root-execute-seven-1.py'+suffix\", \"Q/('root-execute-seven-1.py'+suffix)\")\n checker=checker.replace(\"    for key in")
out=D/'full-caller-bounded-correction-1';out.mkdir(mode=0o700);(out/src.name).write_text(s)
f=(D/'final-source/check_final_static_closure.py').read_text().replace("authority['decision'].startswith('PASS_')", "authority['decision']=='PASS_CURRENT_NATIVE_SCHEMA_PENDING19_SOURCE_DATA_BINDING_ONLY' and authority['findings']==[]")
(out/'check_final_static_closure.py').write_text(f)
