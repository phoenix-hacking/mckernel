from pathlib import Path
import argparse,hashlib,importlib.util,json,os,resource,shutil,subprocess
D=Path(__file__).resolve().parent
H=Path('/home/holden/mckernel-work/host-preparation/practical-create-ppd-provider-repair-20261019-1/guest-control-consumer-1/current-fullcrate-owner-1/owned_capture_helpers.py')
assert hashlib.sha256(H.read_bytes()).hexdigest()=='7834a85da04a3667b86365ec6340a55580b560248dd23fec84e673acc31bea90'
s=importlib.util.spec_from_file_location('capture',H);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
h.CENSUS_SOURCE=Path('/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/adapters/native_rust_exact_build_container_owner.py')
assert hashlib.sha256(h.CENSUS_SOURCE.read_bytes()).hexdigest()==h.CENSUS_SHA
os.sched_setaffinity(0,{6})
resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824));resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_FSIZE,(67108864,67108864));resource.setrlimit(resource.RLIMIT_NOFILE,(256,256));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
scratch=Path('/home/holden/mckernel-work/scratch')
identity=subprocess.check_output(['/usr/bin/findmnt','-n','-o','UUID',str(scratch)],text=True).strip()
assert identity=='2a5768c8-718d-4914-bdc0-6b32c5a92a52'
free={str(p):shutil.disk_usage(p).free for p in (Path('/home/holden/mckernel'),scratch)}
assert free['/home/holden/mckernel']>=16*1024**3+679477248+67108864
assert free[str(scratch)]>=12*1024**3+679477248+67108864
h.write(D/('fresh-'+__import__('sys').argv[1]+'-preflight.json'),dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',scratch_uuid=identity,free_bytes=free,aggregate_authority='Root CPU6 ordinary normalization preparation grant; no heavy operation',profile=dict(cpu=6,AS=1073741824,CPU=30,wall=35,FSIZE=67108864,NOFILE=256,CORE=0)))
ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('phase',choices=['plan','publish','normalize']);ap.add_argument('--grant');a=ap.parse_args()
C=D/('actual-'+a.phase+'-capture-1');C.mkdir(mode=0o700)
def limits():
 os.sched_setaffinity(0,{6});resource.setrlimit(resource.RLIMIT_CPU,(30,30))
command=dict(argv=['/home/holden/anaconda3/bin/python3.9','-I','-B',str(D/'prepare_remaining_normalization.py'),a.phase,*(['--grant',a.grant]if a.grant else[])],cwd=str(D))
r=h.owned_capture(command,C,35,limits,started_reader=h.process_start)
h.write(D/('actual-'+a.phase+'-result-1.json'),dict(command=command,result=r))
print(json.dumps(r,sort_keys=True))
