"""Finite paired source alias, retained-stage metadata successor and pure binding.
Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
No archive rewrites, root, Docker, backend, QEMU or guest execution.
"""
import argparse, ast, copy, hashlib, importlib.util, json, os, socket, stat, subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
C=Path('/home/holden/mckernel-work/host-preparation/M07-current-profile-next-observation-preparation-20261021-1/remaining-components-functional-case-preparation-20261022-1/joint-mpx-exact-fault-correction-1/current053d-stage-preparation-1/runtime-closure-correction-1/candidate2')
TEMPLATE_MANIFEST='/home/holden/mckernel-work/scratch/m07rm-261022-1/numa/manifest.json'
TEMPLATE_MANIFEST_SHA='c2d2ab3cb6e19d67ca3a206305540f20583e1901fd69a565c103d1d02ffcee6b'
ORIGINAL=Path('/home/holden/mckernel-work/scratch/m07fm-261022-1/numa/manifest.json')
ORIGINAL_SHA='c1fc26f82a94c702d6d90d75810c4ba89ea789d07d3a40af398aef9e576f5f9f'
A=Path('/home/holden/mckernel-work/scratch/m07fa-261022-1')
M=A/'manifest.json'
R=D/'runtime-source-1'
P=Path('/home/holden/mckernel-work/scratch/m07fp-261022-1/t')
NONCE='c463bf2d71ea43bf983e209a64d15a70'
SCOPE='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.'
IDENTITY=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
REVIEW=Path('/home/holden/mckernel-work/host-preparation/current-focused-progress-recording-20261021-1/current-normalization-review-recording-1')
REVIEWS=[(REVIEW/'M07-EXIT125-FAILURE-DIAGNOSTIC-SOURCE-ACCEPTANCE.json','1c4921a802527897e315ea724458372f78175627cd3e95d184b94616f4831c04'),(REVIEW/'M07-REMAINING-CANDIDATE2-CLOSURE-SOURCE-REVIEW.json','5be960a886d3132aa80996446da5b9489b00dacfed56b83ac78f73258862ee41')]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ident(s):return {k:getattr(s,k)for k in IDENTITY}
def read(p,limit=4<<20):
 p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  before=os.fstat(fd);assert stat.S_ISREG(before.st_mode)and before.st_size<=limit
  raw=b''
  while True:
   b=os.read(fd,min(1<<20,limit+1-len(raw)))
   if not b:break
   raw+=b;assert len(raw)<=limit
  assert ident(before)==ident(os.fstat(fd))==ident(p.lstat())and len(raw)==before.st_size
  return raw,before
 finally:os.close(fd)
def ref(p):
 raw,s=read(p);return dict(path=str(p),sha256=sha(raw),size=len(raw),mode=s.st_mode)
def serial(x):return(json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
def put(p,raw,mode=0o600):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 assert stat.S_IMODE(p.stat().st_mode)==mode
 return ref(p)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def forbid(*a,**kw):raise AssertionError('No process/socket/clock/backend in pure metadata binding')
def inputs():
 for p,h in REVIEWS:assert sha(read(p)[0])==h
 raw,_=read(ORIGINAL);assert sha(raw)==ORIGINAL_SHA
 manifest=json.loads(raw);closure=json.loads(read(C/'BOUND-RUNTIME-SOURCE-ONLY.json')[0]);overlay=json.loads(read(manifest['staging']['overlay_manifest']['path'])[0])
 assert manifest['case_id']=='vector.remaining-components-preservation'and manifest['artifacts']['payload']['sha256']=='743002457716113509fc98c8aa942fdf82139b0a2a8c40a485e0d760a727e7da'
 return manifest,closure,overlay
def paths(manifest,overlay,manifest_path,closure_root,source_paths):
 result={str(manifest_path),*source_paths}
 for table in(manifest['artifacts'].values(),manifest['modules'],manifest['staging'].values()):
  result.update(x['path']for x in table if isinstance(x,dict)and'path'in x)
 result.update(x['path']for x in overlay['sources'].values())
 roots=['/home/holden/mckernel','/home/holden/mckernel-work/scratch',str(closure_root)]
 exterior=[x for x in sorted(result)if not any(Path(x)==Path(r)or Path(r)in Path(x).parents for r in roots)]
 return dict(paths=sorted(result),readonly_roots=roots,exterior_paths=exterior)
def plan():
 m,c,o=inputs();oldroot=Path(c['owner']['path']).parent
 before=paths(m,o,ORIGINAL,oldroot,[x['path']for x in c['sources']+c['external_source_pins']])
 assert before['exterior_paths']==[m['artifacts']['payload']['path']]
 proposed=copy.deepcopy(m);proposed['artifacts']['payload']['path']=str(A/'payload');proposed['staging']['overlay_manifest']['path']=str(A/'overlay-manifest.json')
 overlay=copy.deepcopy(o);overlay['sources']['payload']['path']=str(A/'payload')
 after=paths(proposed,overlay,M,R,[str(R/Path(x['path']).name)for x in c['sources']]+[x['path']for x in c['external_source_pins']])
 assert not after['exterior_paths']
 out=dict(scope=SCOPE,status='PREPARED_ALLPATHS_AND_PAIRED_ALIAS_CONTRACT_NOT_EXECUTED',original_manifest=ref(ORIGINAL),original_payload=m['artifacts']['payload'],original_overlay_manifest=m['staging']['overlay_manifest'],before=before,after=after,alias_payload=str(A/'payload'),successor_manifest=str(M),successor_overlay_manifest=str(A/'overlay-manifest.json'),private_runtime_root=str(R),attempt_parent=str(P),nonce=NONCE,manifest_delta=['/artifacts/payload/path','/staging/overlay_manifest/path','/staging/overlay_manifest/sha256','/staging/overlay_manifest/size'],overlay_delta=['/sources/payload/path','/sources/payload/identity'],archive_rewrites=0,final_map_changes=0,profile_changes=0,typed_STOP_and_inapplicable_zero_credit_unchanged=True,required_review='Affected paired alias+metadata+bound closure+pure normalizer; exact root grant required before publish',native_credit=0)
 put(D/'ALLPATHS-AND-PAIRED-ALIAS-PLAN.json',serial(out));print(json.dumps(dict(status=out['status'],before_paths=len(before['paths']),after_paths=len(after['paths']),exterior=before['exterior_paths'])))
def authorize(path):
 g=json.loads(read(path)[0]);assert g['grantor']=='/root'and g['decision']=='EXECUTE_EXACT_REMAINING_PAIRED_ALIAS_AND_NORMALIZATION_ONCE'
 assert g['script']==ref(Path(__file__))and g['plan']==ref(D/'ALLPATHS-AND-PAIRED-ALIAS-PLAN.json')
 assert g['independent_review']is not None and g['native_credit']==0
 # Actual successor stage acceptance is supplied by root only after its reviewer joins.
 accepted=g['actual_stage_acceptance'];assert accepted=={'path': '/home/holden/mckernel-work/host-preparation/current-focused-progress-recording-20261021-1/current-normalization-review-recording-1/M07-EXIT125-DIAGNOSTIC-ACTUAL-OFFLINE-STAGE-ACCEPTANCE.json', 'sha256': '12fe49805123d231e5a95c1f79a37038116420b29d94076c12bec55bab8bcb36', 'size': 2920}
 accepted_raw,_=read(accepted['path']);assert sha(accepted_raw)==accepted['sha256'] and len(accepted_raw)==accepted['size']
 accepted_doc=json.loads(accepted_raw);assert accepted_doc['implementation_ownership'] is False and accepted_doc['reviewer']
 accepted_manifest=accepted_doc['manifest'];assert accepted_manifest['path']==str(ORIGINAL)and accepted_manifest['sha256']==ORIGINAL_SHA
 return g

def publish(grant):
 g=authorize(grant);m,c,o=inputs();original_overlay=copy.deepcopy(o);original_manifest=copy.deepcopy(m)
 assert not os.path.lexists(A)and not os.path.lexists(R)and not os.path.lexists(P.parent)
 payload,ps=read(m['artifacts']['payload']['path']);assert ref(m['artifacts']['payload']['path'])==m['artifacts']['payload']
 A.mkdir(mode=0o700);alias=A/'payload';put(alias,payload,stat.S_IMODE(ps.st_mode))
 assert ref(alias)==dict(m['artifacts']['payload'],path=str(alias))
 # Paired metadata successor preserves the provenance of the original archive.
 # Only the aliased source path+physical identity and its joined descriptor change.
 o['sources']['payload']['path']=str(alias);o['sources']['payload']['identity']=ident(alias.stat())
 overlay_ref=put(A/'overlay-manifest.json',serial(o))
 m['artifacts']['payload']=ref(alias);m['staging']['overlay_manifest']=overlay_ref
 manifest_ref=put(M,serial(m))
 assert o['final_map']==original_overlay['final_map']and o['output_identity']==original_overlay['output_identity']
 assert o['output_sha256']==original_overlay['output_sha256']and m['profile']==original_manifest['profile']and m['payload']==original_manifest['payload']
 expected=copy.deepcopy(original_manifest);expected['artifacts']['payload']=ref(alias);expected['staging']['overlay_manifest']=overlay_ref;assert m==expected
 expected_o=copy.deepcopy(original_overlay);expected_o['sources']['payload']=dict(original_overlay['sources']['payload'],path=str(alias),identity=ident(alias.stat()));assert o==expected_o
 nd=load('remaining_unchanged_strict_loader',C/'runtime-source-1/native_diagnostic.py');nd.load_manifest(str(M))
 provenance=dict(scope=SCOPE,status='PASS_BYTE_IDENTICAL_PAYLOAD_ALIAS_PAIRED_METADATA_SUCCESSOR_STRICT_LOADER_ONLY',original_manifest=ref(ORIGINAL),original_payload=original_manifest['artifacts']['payload'],original_overlay_manifest=original_manifest['staging']['overlay_manifest'],manifest=manifest_ref,payload=ref(alias),overlay_manifest=overlay_ref,unchanged_base=original_manifest['staging']['base_initramfs'],unchanged_derived=original_manifest['staging']['derived_initramfs'],archive_rewrites=0,final_map_changes=0,profile_changes=0,root_grant=ref(Path(grant)),native_credit=0,runtime_release=None)
 put(D/'ACTUAL-PAIRED-ALIAS-PROVENANCE.json',serial(provenance))
 # New coherent closure changes only location/frozen manifest/hash bindings.
 old=Path(c['owner']['path']).parent;generated={}
 for row in c['sources']:
  raw,_=read(row['path']);assert sha(raw)==row['sha256']and len(raw)==row['bytes']
  name=Path(row['path']).name
  if name=='native_diagnostic_container_owner.py':continue
  if Path(name).suffix=='.py':raw=raw.replace(str(old).encode(),str(R).encode()).replace(TEMPLATE_MANIFEST.encode(),str(M).encode()).replace(TEMPLATE_MANIFEST_SHA.encode(),manifest_ref['sha256'].encode())
  generated[name]=raw
 adapter_old=c['source_hashes'][str(old/'case_evaluator.py')]
 assert generated['native_diagnostic_runner.py'].count(adapter_old.encode())==1
 generated['native_diagnostic_runner.py']=generated['native_diagnostic_runner.py'].replace(adapter_old.encode(),sha(generated['case_evaluator.py']).encode())
 owner=read(c['owner']['path'])[0].decode().replace(str(old),str(R))
 start=owner.index('SOURCE_HASHES = ')+len('SOURCE_HASHES = ');end=owner.index('\n',start)
 hashes={str(R/name):sha(raw)for name,raw in generated.items()}
 hashes.update({x['path']:x['sha256']for x in c['external_source_pins']})
 owner=owner[:start]+repr(hashes)+owner[end:]
 generated['native_diagnostic_container_owner.py']=owner.encode()
 R.mkdir(mode=0o700)
 refs=[put(R/name,raw)for name,raw in sorted(generated.items())]
 closure=dict(scope=SCOPE,sources=refs,external_source_pins=c['external_source_pins'],source_hashes=hashes,owner=ref(R/'native_diagnostic_container_owner.py'),manifest=manifest_ref,readonly_host_roots=['/home/holden/mckernel','/home/holden/mckernel-work/scratch',str(R)],native_credit=0,execution_release=None)
 put(D/'BOUND-RUNTIME-SOURCE-ONLY.json',serial(closure))
 print(json.dumps(dict(status='PAIRED_ALIAS_AND_BOUND_CLOSURE_PREPARED_NOT_RUNTIME_RELEASED',manifest=manifest_ref,sources=len(refs),native_credit=0)))

def normalize(grant):
 authorize(grant);provenance=json.loads(read(D/'ACTUAL-PAIRED-ALIAS-PROVENANCE.json')[0]);closure=json.loads(read(D/'BOUND-RUNTIME-SOURCE-ONLY.json')[0])
 assert ref(M)==provenance['manifest']==closure['manifest']
 assert not os.path.lexists(P.parent)and not os.path.lexists(D/'ACTUAL-NATIVE-PREFLIGHT.json')
 subprocess.Popen=forbid;subprocess.run=forbid;socket.socket=forbid;os.execve=forbid
 owner=load('remaining_real_owner',R/'native_diagnostic_container_owner.py')
 nd,manifest=owner.bound_manifest(str(M),closure['manifest']['sha256'])
 runner=load('remaining_real_HERE_runner',R/'native_diagnostic_runner.py')
 assert runner._HERE==R
 diag=runner._module('remaining_real_HERE_diagnostic',R/'native_diagnostic.py')
 runner._bind_m07(diag,diag.load_manifest(str(M)),M)
 assert diag.evaluate.__module__=='m07_runner_case'
 assert owner.SELF==str(R/'native_diagnostic_container_owner.py')and owner.RUNNER==str(R/'native_diagnostic_runner.py')
 P.parent.mkdir(mode=0o700);P.mkdir(mode=0o700);owner.private_parent(str(P))
 class NoEffects:
  def call(self,*args,**kwargs):return forbid(*args,**kwargs)
 actual=owner.DiagnosticOwner(str(P),manifest=str(M),manifest_sha256=closure['manifest']['sha256'],nonce=NONCE,backend=NoEffects(),clock=forbid)
 create=actual._create_argv();inside=actual._inside_args();assert create[-len(inside):]==inside
 mounts=[create[i+1]for i,x in enumerate(create)if x=='--mount']
 expected_ro=['type=bind,src='+root+',dst='+root+',readonly'for root in closure['readonly_host_roots']]
 assert len(mounts)==4 and all(mounts.count(x)==1 for x in expected_ro)and sum(not x.endswith(',readonly')for x in mounts)==1
 overlay=json.loads(read(manifest['staging']['overlay_manifest']['path'])[0])
 allpaths=paths(manifest,overlay,M,R,[*owner.SOURCE_HASHES,owner.SELF]);assert not allpaths['exterior_paths']
 plan=json.loads(read(D/'ALLPATHS-AND-PAIRED-ALIAS-PLAN.json')[0]);assert allpaths==plan['after']
 expected=dict(owner.SOURCE_HASHES);expected[owner.SELF]=closure['owner']['sha256']
 rows=closure['sources']+[dict(x,size=x['bytes'])for x in closure['external_source_pins']]
 assert {x['path']:x['sha256']for x in rows}==expected
 fds={}
 for row in rows:
  raw,s=read(row['path']);assert sha(raw)==row['sha256']and len(raw)==row['size'];fds[row['path']]=ident(s)
 qemu=nd.expected_qemu_argv(manifest,P/('attempt-'+NONCE));qmp=str(P/('attempt-'+NONCE)/'qmp.sock')
 assert len(os.fsencode(qmp))<=107 and qemu[qemu.index('-qmp')+1]=='unix:'+qmp+',server=on,wait=off'
 assert not list(P.iterdir())and not os.path.lexists(P/('attempt-'+NONCE))
 binding=dict(manifest=closure['manifest'],attempt_parent=str(P),nonce=NONCE)
 out=dict(scope=SCOPE,status='PASS_ACTUAL_PAIRED_ALIAS_NORMALIZATION_REAL_HERE_OWNER_ALLPATHS_FD_BINDING_ONLY',binding=binding,paths=dict(attempt=str(P/('attempt-'+NONCE)),qmp_socket=qmp,qmp_socket_bytes=len(os.fsencode(qmp)),limit_bytes=107),owner_argv=['/usr/bin/python3','-B',owner.SELF,'--owner-sha256',actual.owner_sha,'--attempt-parent',str(P),'--nonce',NONCE,'--manifest',str(M),'--manifest-sha256',closure['manifest']['sha256']],container_create_argv=create,inside_owner_argv=inside,qemu_argv=qemu,runtime_source_hashes=dict(owner.SOURCE_HASHES),runtime_source_pins=rows,runtime_owner=closure['owner'],runtime_source_fd_identities=fds,parent_nine_field_identity=ident(P.stat()),consumed_paths=allpaths['paths'],readonly_roots=allpaths['readonly_roots'],source_alias_provenance=ref(D/'ACTUAL-PAIRED-ALIAS-PROVENANCE.json'),actual_fresh_HERE=True,actual_owner_runner_hash_join=True,parent_empty=True,attempt_absent=True,root_operations=0,guest_runs=0,native_credit=0,snapshot=None,runtime_release=None,publication=None)
 put(D/'ACTUAL-BINDING.json',serial(binding));put(D/'ACTUAL-NATIVE-PREFLIGHT.json',serial(out));print(json.dumps(dict(status=out['status'],paths=len(allpaths['paths']),sources=len(rows),readonly_roots=len(expected_ro),guest_runs=0)))

def main():
 ap=argparse.ArgumentParser(allow_abbrev=False);ap.add_argument('phase',choices=['plan','publish','normalize']);ap.add_argument('--grant',type=Path);a=ap.parse_args()
 assert os.getuid()==os.geteuid()==os.getgid()==os.getegid()==1000
 if a.phase=='plan':plan()
 elif a.phase=='publish':publish(a.grant)
 else:normalize(a.grant)
if __name__=='__main__':main()
