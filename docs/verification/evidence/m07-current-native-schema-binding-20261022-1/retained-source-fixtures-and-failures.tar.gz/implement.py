from pathlib import Path
import ast
D=Path(__file__).parent;O=D/'originals';S=D/'sources'
helper='''def accepted_current_normalization(acceptance, root):
    root=Path(root);a=load(acceptance)
    need(ref(acceptance)['sha256']=='675277e49541894244498e34eae7d93aab87d3e3215b53d98e565969a449becb','genuine current normalization authority')
    need(a['decision']=='PASS_ACTUAL_PAIRED_ALIAS_NORMALIZATION_BINDINGS_ONLY' and a['implementation_ownership'] is False and a['reviewer'] and a['source_review_projection_permission'] is True and a['native_permission'] is False and a['native_credit']==0 and a['runtime_release'] is None,'current bounded normalization review')
    paths={'preflight':root/'ACTUAL-NATIVE-PREFLIGHT.json','binding':root/'ACTUAL-BINDING.json','provenance':root/'ACTUAL-PAIRED-ALIAS-PROVENANCE.json','source_closure':root/'BOUND-RUNTIME-SOURCE-ONLY.json'}
    binding=load(paths['binding']);paths['manifest']=Path(binding['manifest']['path'])
    need(set(a['accepted_refs'])==set(paths),'complete current accepted reference set')
    for key,path in paths.items():
        observed=ref(path);need(a['accepted_refs'][key]==observed['sha256']+'/'+str(observed['bytes']),'current accepted whole descriptor '+key)
    need(isinstance(a['verified'],list) and len(a['verified'])==4 and all(isinstance(x,str) and x for x in a['verified']),'current review verified facts')
    return a

def accepted_current_stage(acceptance, manifest):
    need(ref(acceptance)['sha256']=='f0243ce2e3bbbd2c09de0b0b4296895aea15ff815a80db4d04f654dca2762aa5','genuine current image-only stage authority')
    a=load(acceptance);v=a['accepted_boundary']
    need(a['decision']=='PASS_ACTUAL_CBB_IMAGE_ONLY_OFFLINE_STAGE_AND_MANIFEST_ONLY' and a['implementation_ownership'] is False and a['reviewer'] and a['findings']==[],'current image-only stage review')
    need(v['members']==60 and v['unchanged_members']==59 and v['sole_changed_member']=='images/mckernel.img' and v['changed_fields']==['size','sha256'] and v['all_other_metadata_preserved'] is True and v['producer_overlay_manifest_maps_equal'] is True and v['manifest_image_base_overlay_joins_match'] is True,'exact image-only stage boundary')
    need(ref(a['manifest']['path'])==a['manifest'],'complete actual stage manifest descriptor')
    image=manifest['artifacts']['mckernel_image'];need(image['sha256']==v['image_sha256'] and image['size']==v['image_bytes'],'normalization accepted staged image joins')
    need(a['physical_acceptance'] is None and a['execution_release'] is None and a['native_credit_delta']==0,'stage grants no physical or execution authority')
    return a
'''
# Constructor remains sole producer of changed binder/snapshot and source/FD pins.
s=(O/'prepare_outer_diagnostic_successor.EXPERT-CORRECTION-1.py').read_text()
s=s.replace("D=Path(__file__).resolve().parent; R=D.parent;", "D=Path(__file__).resolve().parent; R=Path('/home/holden/mckernel-work/host-preparation/m07-sigill-image-only-stage-preparation-20261022-1/ordinary-normalization-preparation-1');")
s=s.replace('M07-EXIT125-DIAGNOSTIC-ACTUAL-PAIRED-ALIAS-NORMALIZATION-ACCEPTANCE.json','M07-SIGILL-ACTUAL-PAIRED-ALIAS-NORMALIZATION-ACCEPTANCE.json')
s=s.replace("P=Path('/home/holden/mckernel/docs/verification/evidence/current053d-m07-vector-native12-20261022-1/ROOT-MECHANICAL-ACTUAL-CURRENT-M07-NATIVE-PHYSICAL-REPORT-1.json')", "P=None # Genuine new independent physical report is a mandatory late input.")
s=s.replace('def main():',helper+'\ndef main():',1)
a=s.index(" need(ref(G)['sha256']==");b=s.index(" out=D/",a);s=s[:a]+" g=accepted_current_normalization(G,R)\n"+s[b:]
a=s.index(' roles=load(');b=s.index(" refs=[dict",a)
s=s[:a]+''' roles=load(Path('/home/holden/mckernel-work/host-preparation/M07-current-profile-next-observation-preparation-20261021-1/remaining-components-functional-case-preparation-20261022-1/joint-mpx-exact-fault-correction-1/native-125-failure-evidence-correction-1/current053d-stage-preparation-1/ordinary-normalization-runtime-integration-1/outer-runtime-preparation-1/bound-runtime-control-closure-correction-1/current-normal9-role-binding-1/CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json'))
 roles.update(physical_review=None,native_controller_source=None,native_controller_pair=None,physical_predecessor={k:None for k in ('boot_id','filesystem_uuid','container_id','owner_nonce','lease_path','common_exclusion','shared_heavy')},runtime_execution_release=None,external_latest_native_physical_review=None,external_latest_native_physical_role='PENDING_GENUINE_CURRENT_PHYSICAL_ACCEPTANCE')
 write(out/'CURRENT-NATIVE-AND-RELEASED-BUILD-ROLES.json',roles)
'''+s[b:]
s=s.replace('latest_physical=ref(P)','latest_physical=None').replace('current_native_physical=ref(P)','current_native_physical=None')
s=s.replace('M07-EXIT125-DIAGNOSTIC-ACTUAL-OFFLINE-STAGE-ACCEPTANCE.json','M07-SIGILL-SUCCESSOR-ACTUAL-IMAGE-ONLY-STAGE-ACCEPTANCE.json')
s=s.replace(" c['actual_stage_acceptance']=ref(stage_review);c['stage_manifest']=ref(load(stage_review)['manifest']['path'])", " stage=accepted_current_stage(stage_review,manifest)\n c['actual_stage_acceptance']=ref(stage_review);c['stage_manifest']=stage['manifest'];c['image_sha256']=manifest['artifacts']['mckernel_image']['sha256']")
# Modify the constructor's generated acceptance block and snapshot body directly, so next generation cannot restore stale checks.
s=s.replace("need(c['actual_preparation_acceptance']['sha256']=='5362bc7a70cfcf62a9fed0ee4e0860ab86b7c5c13f6e70934e133dedba62a10f' and accept['decision']=='PASS_ACTUAL_PAIRED_ALIAS_COHERENT_SOURCE_AND_ORDINARY_NORMALIZATION_ONLY' and accept['implementation_ownership'] is False and accept['reviewer'] and accept['findings']==[],'actual remaining normalization acceptance')", "accepted_current_normalization(A,Path(c['actual_original_preflight']['path']).parent)")
s=s.replace("original['sha256']==accept['references_relative_to_root']['ACTUAL-NATIVE-PREFLIGHT.json']['sha256'] and original['bytes']==accept['references_relative_to_root']['ACTUAL-NATIVE-PREFLIGHT.json']['bytes']", "accept['accepted_refs']['preflight']==original['sha256']+'/'+str(original['bytes'])")
a=s.index("    c=checked(b['mandatory_consumer_review']);");b=s.index("    pre=checked",a)
s=s[:a]+'''    c=accepted_current_normalization(b['mandatory_consumer_review']['path'],Path(b['actual_original_preflight']['path']).parent)
    stage=accepted_current_stage(b['stage_review']['path'],checked_manifest(b['manifest']))
'''+s[b:]
s=s.replace("b[key]['sha256']==c['references_relative_to_root'][name]['sha256'] and b[key]['bytes']==c['references_relative_to_root'][name]['bytes']", "c['accepted_refs']['preflight' if key=='actual_original_preflight' else 'binding']==b[key]['sha256']+'/'+str(b[key]['bytes'])")
# Both generated modules receive exactly the same real authority consumer; full checked_manifest handles mode/size native descriptors.
s=s.replace(" write(out/'root_manual_snapshot_threads.py',snap)", " snap=\\n" if False else " snap += '\\n'+CURRENT_AUTHORITY_HELPER+'\\ndef checked_manifest(row):\\n    raw=Path(row[\"path\"]).read_bytes();need(hashlib.sha256(raw).hexdigest()==row[\"sha256\"] and len(raw)==row.get(\"size\",row.get(\"bytes\")),\"exact native manifest descriptor\");return json.loads(raw)\\n'\n write(out/'root_manual_snapshot_threads.py',snap)")
s=s.replace(" write(out/'bind_numa_native_packet.py',binder)", " binder=binder[:binder.index(\"c=load(D/'STATIC-NONTEMPORAL-INPUTS.json')\")]+CURRENT_AUTHORITY_HELPER+'\\n'+binder[binder.index(\"c=load(D/'STATIC-NONTEMPORAL-INPUTS.json')\"):]\n binder=patch_pending_physical(binder)\n write(out/'bind_numa_native_packet.py',binder)")
# Guarded pending generation never reads old physical files or emits PASS cleanup.
s=s.replace('pins+[ref(G),ref(P),roles[\'external_latest_native_physical_review\']]','pins+[ref(G),ref(stage_review)]')
patch='''def patch_pending_physical(binder):
    start=binder.index("P=Path(c['latest_physical']['path'])")
    end=binder.index("prop=transform",start)
    binder=binder[:start]+"""physical_pending=c['latest_physical'] is None
need(not final or not physical_pending,'genuine independent physical acceptance required before final binding')
whole_ref=c['native_predecessor_binding'];need(ref(whole_ref['path'])==whole_ref,'exact distinct native/native/build role data')
roles=load(whole_ref['path']);decoderref=roles['released_record_projection_source'];predecessor=roles['physical_predecessor']
need(set(predecessor)=={'boot_id','filesystem_uuid','container_id','owner_nonce','lease_path','common_exclusion','shared_heavy'},'existing seven-field predecessor interface')
if physical_pending:
 P=None
 need(roles['physical_review'] is None and roles['native_controller_source'] is None and roles['native_controller_pair'] is None and all(v is None for v in predecessor.values()),'no fabricated physical authority in pending packet')
else:
 P=Path(c['latest_physical']['path']);need(ref(P)==c['latest_physical'] and roles['physical_review']==ref(P),'genuine latest physical report')
 spec=importlib.util.spec_from_file_location('actual_native_terminal_source',D/'root_manual_snapshot_threads.py');snapshot=importlib.util.module_from_spec(spec);spec.loader.exec_module(snapshot)
 snapshot.terminal_joins(load(P),roles)
 need(all(not os.path.lexists(predecessor[k]) for k in ['lease_path','common_exclusion','shared_heavy']),'current native ownership records absent')
def physical_ref():return dict(path=None,sha256=None,bytes=None) if physical_pending else ref(P)
"""+binder[end:]
    binder=binder.replace("terminal_cleanup_and_common_shared_release=dict(status='PASS',ref=physical_ref())","terminal_cleanup_and_common_shared_release=dict(status='PENDING_GENUINE_PHYSICAL_ACCEPTANCE' if physical_pending else 'PASS',ref=physical_ref())")
    return binder
'''
s=s.replace('def main():', 'CURRENT_AUTHORITY_HELPER='+repr(helper)+'\n'+patch+'\ndef main():',1)
(S/'prepare_outer_diagnostic_successor.EXPERT-CORRECTION-1.py').write_text(s)
ast.parse(s)
