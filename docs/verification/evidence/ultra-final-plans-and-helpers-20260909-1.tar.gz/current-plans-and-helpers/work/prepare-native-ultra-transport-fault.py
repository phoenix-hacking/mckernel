"""Prepare verification-only send/notify injection; never build/load/run here."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, os, shutil, sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
MODES={'prepublish-hard':1,'postpublish-notify':2,'recoverable-backpressure':3,'permanent-backpressure':4}
mode,attempt=sys.argv[1:];assert mode in MODES and attempt.isdecimal()
parent=Path('/work/native-ultra-module-20260909-1')
out=Path('/work/native-ultra-transport-fault-source-20260909-'+mode+'-'+attempt);out.mkdir()
record={'status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat(),'mode':mode,'mode_number':MODES[mode],'verification_only':True,'production_gate_credit':False,'actual_guest_transport_fault_verified':False,'physical_full_ring_verified':False,'parent_module':str(parent),'files':[]}
def identity(p):
 data=p.read_bytes();return {'path':str(p),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()}
try:
 shutil.copyfile(__file__,out/'helper.py')
 pr=json.loads((parent/'record.json').read_text());assert pr['status']=='PASS'
 record['parent_record']=identity(parent/'record.json')
 for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
  assert any(row==identity(parent/name) for row in pr['outputs'])
 for name in ['smp_application_syscall.rs','smp_service.rs','application_syscall.rs','smp_application.rs']:
  shutil.copyfile(parent/'staged-source'/name,out/(name+'.original'))
 record['completion_source_unchanged']=identity(out/'application_syscall.rs.original')
 p=out/'smp_application_syscall.rs.original';original=p.read_text()
 old='        call.completion.as_mut().unwrap().publish(send)?;'
 assert original.count(old)==1
 new='''        let ultra_request = call.delivery.request().clone();
        let ultra_serial = call.delivery.serial().wire();
        let ultra_eligible = !call.cancelled && !call.kernel;
        call.completion.as_mut().unwrap().publish(|packet| {
            ultra_fault_send(&ultra_request, ultra_serial, ultra_eligible, packet, send)
        })?;'''
 extension=r'''
// VERIFICATION ONLY: this appendix is absent from the production source/module.
const ULTRA_FAULT_MODE: u32 = @MODE@;
static ULTRA_FAULT_STATE: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
static ULTRA_FAULT_SINCE: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
static ULTRA_FAULT_DELIVERY: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
static ULTRA_FAULT_PID: core::sync::atomic::AtomicI32 = core::sync::atomic::AtomicI32::new(0);
static ULTRA_FAULT_REQUESTER: core::sync::atomic::AtomicI32 = core::sync::atomic::AtomicI32::new(0);
static ULTRA_FAULT_RESPONSE: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
static ULTRA_FAULT_ATTEMPTS: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
fn ultra_fault_send(request: &Request, delivery: u64, eligible: bool, packet: &[u8;128], send: impl FnOnce(&[u8;128])->Result) -> Result {
    use core::sync::atomic::Ordering;
    let args=request.arguments();
    if !eligible || request.number()!=0 || args[0]!=0 || args[2]!=16 {
        return send(packet);
    }
    let now=unsafe { kernel::bindings::ktime_get_seconds() } as u64;
    if ULTRA_FAULT_STATE.compare_exchange(0,1,Ordering::AcqRel,Ordering::Acquire).is_ok() {
        ULTRA_FAULT_SINCE.store(now,Ordering::Release);
        ULTRA_FAULT_DELIVERY.store(delivery,Ordering::Release);
        ULTRA_FAULT_PID.store(request.pid(),Ordering::Release);
        ULTRA_FAULT_REQUESTER.store(request.requester(),Ordering::Release);
        ULTRA_FAULT_RESPONSE.store(request.response(),Ordering::Release);
        kernel::pr_info!("ULTRA_TRANSPORT_FAULT selected mode={} pid={} cpu={} requester={} delivery={} response={:x} buffer={:x} bytes=16 now={}\n",ULTRA_FAULT_MODE,request.pid(),request.cpu(),request.requester(),delivery,request.response(),args[1],now);
    }
    if ULTRA_FAULT_DELIVERY.load(Ordering::Acquire)!=delivery
        || ULTRA_FAULT_PID.load(Ordering::Acquire)!=request.pid()
        || ULTRA_FAULT_REQUESTER.load(Ordering::Acquire)!=request.requester()
        || ULTRA_FAULT_RESPONSE.load(Ordering::Acquire)!=request.response() { return send(packet); }
    let attempts=ULTRA_FAULT_ATTEMPTS.fetch_add(1,Ordering::AcqRel)+1;
    match ULTRA_FAULT_MODE {
        1 => { kernel::pr_info!("ULTRA_TRANSPORT_FAULT prepublication errno=-5 attempts={}\n",attempts); Err(-5) },
        2 => { send(packet)?; ULTRA_FAULT_STATE.store(2,Ordering::Release); kernel::pr_info!("ULTRA_TRANSPORT_FAULT ring_published attempts={}\n",attempts); Ok(()) },
        3 if now.saturating_sub(ULTRA_FAULT_SINCE.load(Ordering::Acquire))>=2 => {
            send(packet)?; ULTRA_FAULT_STATE.store(3,Ordering::Release);
            kernel::pr_info!("ULTRA_TRANSPORT_FAULT backpressure_recovered attempts={} now={}\n",attempts,now); Ok(())
        },
        3 | 4 => Err(-11),
        _ => Err(-22),
    }
}
pub(crate) fn ultra_fault_notify(notify: impl FnOnce()->Result) -> Result {
    use core::sync::atomic::Ordering;
    if ULTRA_FAULT_MODE==2 && ULTRA_FAULT_STATE.compare_exchange(2,3,Ordering::AcqRel,Ordering::Acquire).is_ok() {
        kernel::pr_info!("ULTRA_TRANSPORT_FAULT notification_injected errno=-5 delivery={}\n",ULTRA_FAULT_DELIVERY.load(Ordering::Acquire));
        return Err(-5);
    }
    notify()
}
'''.replace('@MODE@',str(MODES[mode]))
 changed=original.replace(old,new)+extension
 assert changed.removesuffix(extension).replace(new,old)==original
 (out/'smp_application_syscall.rs').write_text(changed)
 service=(out/'smp_service.rs.original').read_text()
 old_notify='|| smp_ikc::notify(cpu),'
 new_notify='|| super::super::smp_application_syscall::ultra_fault_notify(|| smp_ikc::notify(cpu).map_err(|error| error.to_errno())).map_err(errno),'
 assert service.count(old_notify)==1
 changed_service=service.replace(old_notify,new_notify)
 assert changed_service.replace(new_notify,old_notify)==service
 (out/'smp_service.rs').write_text(changed_service)
 for name in ['smp_application_syscall.rs','smp_service.rs']:
  old=(out/(name+'.original')).read_text();newtext=(out/name).read_text()
  (out/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),newtext.splitlines(True),fromfile=name+'.production',tofile=name+'.verification')))
  record['files'].append({'name':name,'original':identity(out/(name+'.original')),'injected':identity(out/name),'diff':identity(out/(name+'.diff')),'inverse_patch_byte_equal':True})
 record['injection_contract']='Only targeted actual read16 send callback and separate notify callback are substituted. EAGAIN is injected runtime backpressure, not proof that the physical ring filled. No response-memory access or Completion::publish edit.'
 record['status']='PREPARED'
except BaseException as error:record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
