# Prepared Ultra image helper, 2026-09-09

Prepared only. This helper has not been executed, syntax-checked by an
interpreter, built, or used to boot a guest by its author.

Root's serialized command after its current review/checkpoint is complete:

```text
/home/holden/mckernel-work/bin/mckernel-container compat python3 -B /work/build-mckernel-native-ultra-images.py 1
```

Fresh output: `/work/mckernel-native-ultra-images-20260909-1`. Future attempts
must use a fresh positive integer. Retain the whole first failed attempt and
log the failure before any correction/retry. Source bindings check both the
copied and live selected production files at the end, so do not edit those
inputs during this serialized run.

The original `/work/build-mckernel-native-signals-images-2.py` is unchanged.
The adapted helper retains it and an exact unified adaptation diff in every
capture. All original four image configurations, four rejection checks,
source/submodule restoration and overlay checks, producer/equivalence status,
linked Rust ownership, clone3 syscall table and marker checks, signal-stack
prepare/publish checks, original sigreturn body disassembly, original output
identity and fallback checks remain in place. No old assertion was removed
or weakened. The older broad equivalence prerequisites remain explicitly
unavailable; the helper does not invent a pass for that old harness.

Additions:

* Original 37 production hashes plus the seven requested files:
  native_fault/native_futex/native_xstate, futex.rs, sched_helpers.rs, cpu.c,
  interrupt.S. Match live/source-copy identities before and after the build.
* All four profiles bind actual kernel/syscall.c, architecture syscall.c,
  cpu.c and interrupt.S compiler commands, object files and C/assembly
  dependency records. All five native macros are present exactly in the two
  native profiles and absent in fallback and legacy Rust.
* All Rust profiles require exact generated build.make dependencies for the
  ten selected Rust modules, and exclude the old futex.c/sched_helpers.c
  compilation units. Fallback requires those original C units.
* The new native functions and four fault/recovery labels exist only in the
  native images. Retain sized disassemblies of the new functions, futex value,
  timeout/retry/scheduler helpers and private futex clock bridge.
* Bind the exact checked u32-load byte sequence and its precise fault/recovery
  labels; verify exact XRSTOR instruction bytes and recovery RET. The Rust
  whitelist's ELF body must reference all four actual label addresses.
* page_fault and general_protection_exception are unsized assembly labels.
  Their next exact named entry labels bound the disassemblies. Each native
  handler must call the exact native_fault_fixup address once with the actual
  saved frame and trap 14/13, test its result and branch to register restore,
  bypassing the retained ordinary handler. Both ordinary handlers and IRETQ
  remain in every profile. No native hook is allowed in a legacy profile.
* Prove actual calls from the selected futex locked load to the checked
  primitive, and native do_fork to write_process_vm; legacy do_fork lacks that
  new call. Prove checked FP bridge calls to size/validation/MXCSR/reset/XRSTOR
  providers. A mere symbol or function-pointer constant is not accepted as
  an actual call.
* Prove the new do_signal entry-target validator call precedes the original
  stack prepare call, plus actual context/action-mask calls. The original
  prepare/publish call assertions remain unchanged.
* Preserve arch_rt_sigreturn_body_result and its original disassembly while
  requiring the native syscall to reach the new checked FP consumer and
  bad-frame bridge. An inlined or single outlined native Rust consumer is
  accepted only with actual exact-address call edges. Legacy Rust must still
  call the retained original body.

New call matching accepts an exact direct target or a movabs target followed
by the unchanged register's call (explicitly allowed tail jumps only where
the source returns that provider result). It refuses intervening branches,
calls and detected register/alias clobbers. If the pinned compiler produces a
different valid shape, preserve the failure and record an equally specific
proof before adapting the audit; never replace an actual-call assertion with
mere symbol presence. No existing check was changed for call generation.

PASS means compilation and selection only. Actual #PF/#GP recovery, timer
behavior, child TID/COW behavior, signal return and application correctness
still require the new exact image in an isolated guest. Runtime/Ultra
application acceptance fields remain false.

Image attempt 1 auditor correction: fallback and legacy Rust compiled, then
the new legacy sigreturn audit incorrectly required an out-of-line call to
`arch_rt_sigreturn_body_result`. The retained exact
`/work/mckernel-native-ultra-images-20260909-1/legacy-rust-sys_rt_sigreturn-disassembly.log`
shows LLVM inlined its complete body. The new check accepts the original
direct call when present, or requires actual exact-address calls to all nine
legacy providers (context, checked frame copy, restart syscall, signal setup,
reschedule check, signal check, FP allocation, XRSTOR and free), the existing
explicit legacy source cfg, the retained named original body's disassembly,
and absence of every new native bridge. This corrects an added auditor's
code-generation assumption; no assertion inherited from signal image 2 was
removed or weakened. Attempt 1 remains fully retained; use fresh attempt 2.

Pre-run review correction: the recovered POP_ALL_REGS entry clears
`X86_FLAGS_BASE(%rsp)`, where `X86_SREGS_BASE=0` and `X86_SREGS_SIZE=48`.
The exact expected ELF operand is therefore `$0x0,0x30(%rsp)`. The initial
draft incorrectly expected offset zero. This is an auditor ABI correction
before any image attempt, with the exact return-target proof retained.
The C `.o.d` files and assembly `depend.internal` were inspected in accepted
signal image 2: all four profiles retain those files; the C files name their
actual source paths, and the assembly record names the build-relative object
followed by a one-space-prefixed absolute source path, matching the new audit.
