# Prepared actual futex/clone guest check

Prepared only; no compilation, syntax execution, application or guest run by
the author. Root serializes the following after the baseline batch:

```text
/home/holden/mckernel-work/bin/mckernel-container native python3 -B /work/build-native-ultra-futex.py 1
/home/holden/mckernel-work/bin/mckernel-container native python3 -B /work/run-native-ultra-futex.py 1 3 1 1
```

The runner arguments are module attempt, image attempt, payload build attempt,
guest attempt. It requires every selected build record to PASS and verifies
their actual identities. Fresh output directories are
`/work/native-ultra-futex-build-20260909-1` and
`/work/native-ultra-futex-guest-20260909-1`. Preserve failed attempts unchanged
and use new positive attempt numbers after logging a failure.

The source is `scripts/tests/fixtures/native-ultra-futex.c`. Build output is a
normal dynamic x86_64 ET_EXEC, compiled with `-fno-stack-protector`; the actual
raw clone callback must contain exactly one syscall instruction and no calls,
PLT targets, FS/GS TLS accesses or stack-protector references. No application
is run on the container host. Both references execute the identical captured
binary inside the pinned Linux guest, first directly and then via mcexec.

The entire original `/work/run-native-ultra-baseline.py` threads run remains:
all eight HELLO launches, exact original thread/core assertions, both control
pointer-width probes, boot/sysfs checks, physical captures and cleanup. The
new window follows the original PASS delimiter; its original host assertions
still inspect that original prefix. The new helper captures the unmodified
baseline helper and an exact adaptation diff.

New independent result contracts cover 16 cases: mismatched WAIT EAGAIN;
zero and 10ms relative WAIT ETIMEDOUT; expired and future absolute monotonic
WAIT_BITSET ETIMEDOUT; NULL/unaligned futex words EFAULT/EINVAL; protected and
cross-page complete timespec EFAULT; negative seconds, negative/1e9 nsec
EINVAL; zero bitset EINVAL; empty and unmapped private WAKE return zero; and a
10ms WAIT while two ordinary pthreads stay runnable and periodically yield.
Elapsed bounds are 0..2s, with at least 9ms for a requested 10ms relative
wait; absolute future return may be at most 1ms before its explicit deadline.
Each side is checked independently, then exact errno/result pairs compared.

Two pthread workers each use a 256KiB stack, bounded positive work, distinct
TLS/TIDs and successful joins. A separate single shared-VM raw clone thread
uses another guarded 256KiB stack and an aligned writable TID cell initialized
to -1. Its callback records its raw gettid and the CHILD_SETTID value before
returning; parent joins the kernel-cleared cell using bounded shared futex
waits. The entry observation prevents a false pre-start join. McKernel's
existing TID pool may reuse the earlier raw child's ID for a later pthread; the runner requires every
publication/deletion lifetime with full multiplicity when that occurs.

Fixture-owned mappings/stacks remain under 1MiB, at most three application
threads are live, and the existing guest reserves 128MiB/one CPU for McKernel.
This does not assert loader virtual size or total process RSS. QEMU retains
the original 8GiB/four-vCPU Linux guest inside the four-CPU/12GiB container,
with the original 300-second external watchdog and emergency capture.

Exact stdout is `NATIVE_ULTRA_FUTEX PASS cases=16 threads=2 raw_clone=1` plus
newline, exit 37. Separate stderr contains 16 typed case lines, one pthread
line and one raw clone line. Guest byte counts and complete line replay bind
the captured per-side stdout/stderr files. Actual McKernel schedule, guest
syscall/TID records, each procfs lifetime, retirement and pager cleanup are
required. Sampled host delivery/return routes are paired without claiming
all returns are audited from the 64-delivery trace.

No fork/COW, invalid child-TID-store, robust owner-death, PI, WAKE_OP, UTI,
external-signal or realtime-clock-step capability is accepted by this test.

The final fixture buffers its bounded diagnostic stream, runs the raw child
before the runnable pthread timeout, and yields at1048576 work iterations.
This keeps required transitions within the unchanged128-event guest trace;
all16 independent errno/deadline cases and lifecycle assertions remain. The
runner retains full stderr, an exact frozen58-byte launcher startup prefix
for McKernel, and the independent18-line payload report without filtering.
