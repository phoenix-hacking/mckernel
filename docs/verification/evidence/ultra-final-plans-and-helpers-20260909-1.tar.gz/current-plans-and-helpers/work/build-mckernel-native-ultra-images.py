"""Ultra image selection audit; all original signal-image checks are retained.

Run only through the serialized compatibility container. This helper compiles
four images and audits source/compiler/ELF selection; it never boots McKernel.
"""
from datetime import datetime, timezone
from pathlib import Path
import difflib, hashlib, json, os, re, shlex, shutil, struct, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
assert len(sys.argv) == 2 and re.fullmatch(r'[1-9][0-9]*', sys.argv[1])
out = Path('/work/mckernel-native-ultra-images-20260909-' + sys.argv[1])
out.mkdir()
source = out / 'source'
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
ihk_head = subprocess.check_output(['git', '-C', str(repo / 'ihk'), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
assert shutil.disk_usage('/work').free > 3 * 1024**3
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=head, ihk_source=ihk_head,
              status='running', production_gate_credit=False, mckernel_boot_proven=False, results=[])
environment = dict(os.environ, PATH='/opt/mckernel/cargo/bin:' + os.environ['PATH'], RUSTC='/opt/mckernel/cargo/bin/rustc',
                   PYTHONDONTWRITEBYTECODE='1', MCKERNEL_RUST_EQUIV_KEEP_TMP='1')
original_helper = Path('/work/build-mckernel-native-signals-images-2.py')
ultra_inputs = ['kernel/rust/native_fault.rs', 'kernel/rust/native_futex.rs',
                'kernel/rust/native_xstate.rs', 'kernel/rust/futex.rs',
                'kernel/rust/sched_helpers.rs', 'arch/x86_64/kernel/cpu.c',
                'arch/x86_64/kernel/interrupt.S']
ultra_rust_dependencies = ['kernel/rust/lib.rs', 'kernel/rust/abi.rs',
    'kernel/rust/native_signal.rs', 'kernel/rust/native_fault.rs',
    'kernel/rust/native_futex.rs', 'kernel/rust/native_xstate.rs',
    'kernel/rust/futex.rs', 'kernel/rust/sched_helpers.rs',
    'kernel/rust/syscall_policy.rs', 'kernel/rust/x86_memory_helpers.rs']
ultra_native_functions = ['native_fault_fixup', 'native_user_read_u32_checked',
    'native_xrstor_checked', 'native_signal_entry_targets_result', 'native_signal_context_prepare_result',
    'native_signal_action_mask_result', 'native_xstate_buffer_size_result',
    'native_xstate_validate_result', 'arch_native_signal_restore_fp_bridge',
    'arch_native_signal_bad_frame_bridge', 'arch_native_signal_mxcsr_mask_bridge',
    'arch_native_signal_reset_fp_bridge']
ultra_native_labels = ['native_user_read_u32_fault', 'native_user_read_u32_recover',
                       'native_xrstor_fault', 'native_xrstor_recover']
ultra_macros = ['MCKERNEL_NATIVE_CLONE3', 'MCKERNEL_NATIVE_SIGNAL_STACK',
                'MCKERNEL_NATIVE_FAULT_FIXUP', 'MCKERNEL_NATIVE_FUTEX',
                'MCKERNEL_NATIVE_CLONE_TID']
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
def run(label, command, expected=None):
    record['phase'] = label
    (out / 'phase').write_text(label + '\n')
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=str(source) if source.exists() else str(repo), env=environment, stdout=log, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode)
    record['results'].append(row)
    save()
    if expected is None:
        assert result.returncode == 0, (label, result.returncode)
    else:
        diagnostic = ' '.join((out / (label + '.log')).read_text().split())
        assert result.returncode != 0 and ' '.join(expected.split()) in diagnostic, label

def instructions(code):
    """Parse actual objdump instruction rows, excluding labels and byte wraps."""
    rows = []
    for line in code.splitlines():
        match = re.match(r'^\s*([0-9a-f]+):\s+(.*)$', line)
        if not match:
            continue
        rest = re.sub(r'^(?:[0-9a-f]{2}\s+)+', '', match.group(2)).strip()
        decoded = re.match(r'^([a-z][a-z0-9.]*)\s*(.*)$', rest)
        if decoded and not re.fullmatch(r'[0-9a-f]{2}', decoded.group(1)):
            rows.append(dict(pc=int(match.group(1), 16),
                             mnemonic=decoded.group(1), operands=decoded.group(2)))
    return rows

def exact_calls(code, target, tail=False):
    """Require an actual exact-address call, or explicitly allowed tail jump.

    The pinned large-code-model compiler also uses movabs + register calls.
    Track only an unmodified register through a short straight-line window;
    a constant address appearing as a function-pointer argument is not a call.
    Existing signal prepare/publish checks below remain byte-for-byte intact.
    """
    rows = instructions(code)
    branches = {'call', 'callq'} | ({'jmp', 'jmpq'} if tail else set())
    hits = []
    for index, row in enumerate(rows):
        operand = re.match(r'^([0-9a-f]+)(?:\s|$)', row['operands'])
        if row['mnemonic'] in branches and operand and int(operand.group(1), 16) == target:
            hits.append(dict(kind='direct', instruction=row, target=target))
        load = re.fullmatch(r'\$0x([0-9a-f]+),(%\w+)', row['operands'])
        if row['mnemonic'] not in {'movabs', 'movabsq'} or not load or int(load.group(1), 16) != target:
            continue
        register = load.group(2)
        aliases = {'%rax': {'%rax', '%eax', '%ax', '%al', '%ah'},
                   '%rbx': {'%rbx', '%ebx', '%bx', '%bl', '%bh'},
                   '%rcx': {'%rcx', '%ecx', '%cx', '%cl', '%ch'},
                   '%rdx': {'%rdx', '%edx', '%dx', '%dl', '%dh'},
                   '%rsi': {'%rsi', '%esi', '%si', '%sil'},
                   '%rdi': {'%rdi', '%edi', '%di', '%dil'},
                   '%rbp': {'%rbp', '%ebp', '%bp', '%bpl'},
                   '%rsp': {'%rsp', '%esp', '%sp', '%spl'}}.get(
                       register, {register, register + 'd', register + 'w', register + 'b'})
        for following in rows[index + 1:index + 9]:
            if following['mnemonic'] in branches and following['operands'] == '*' + register:
                hits.append(dict(kind='movabs-register', load=row, instruction=following, target=target))
                break
            if (any(re.search(r'(?:^|,)' + re.escape(alias) + r'$', following['operands'])
                    for alias in aliases)
                    or following['mnemonic'].startswith(('call', 'j', 'ret'))
                    or following['mnemonic'].startswith(('mul', 'imul', 'div', 'idiv', 'cpuid', 'rdtsc', 'xchg'))):
                break
    return hits

def exact_address_references(code, target):
    return [row for row in instructions(code)
            if re.search(r'(?:\$0x|\b)' + format(target, 'x') + r'\b', row['operands'])]

try:
    shutil.copyfile(__file__, out / 'build-helper.py')
    shutil.copyfile(str(original_helper), str(out / 'original-signal-image-helper.py'))
    record['adaptation'] = dict(original=identity(original_helper),
        original_retained='original-signal-image-helper.py',
        patch='helper-adaptation.diff', existing_assertions_removed_or_weakened=False,
        exact_original_four_profiles_preserved=True,
        old_sigreturn_body='Retained and disassembled; native sys_rt_sigreturn now selects the checked native consumer, legacy Rust retains the original consumer',
        assembly_ranges='page_fault and general_protection_exception have unsized ELF labels; exact next named assembly entry bounds each disassembly',
        call_generation='Original prepare/publish movabs plus register-call proof is unchanged; new calls additionally allow exact direct calls or explicitly identified tail jumps')
    (out / 'helper-adaptation.diff').write_text(''.join(difflib.unified_diff(
        original_helper.read_text().splitlines(True), Path(__file__).read_text().splitlines(True),
        fromfile=str(original_helper), tofile=str(Path(__file__)))))
    run('clone-source', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo), str(source)])
    # Compile-only checkout: preserve exact restoration references before
    # avoiding redundant historical evidence. No compiler input is excluded.
    omitted = []
    listing = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-rlz', '--full-tree', head, 'docs/verification/evidence'])
    for entry in listing.split(b'\0'):
        if not entry: continue
        meta, relative = entry.split(b'\t', 1)
        mode, kind, blob, size = meta.decode().split()
        assert kind == 'blob'
        omitted.append(dict(path=os.fsdecode(relative), mode=mode, git_blob=blob, size=int(size), source_commit=head))
    record['historical_evidence_omitted'] = dict(count=len(omitted), bytes=sum(row['size'] for row in omitted), restoration_map='historical-evidence-restoration.json', scope='Compile-only source copy; exact committed blobs remain in the source Git object database')
    (out / 'historical-evidence-restoration.json').write_text(json.dumps(omitted, indent=2, sort_keys=True) + '\n')
    save()
    run('sparse-source', ['git', '-C', str(source), 'sparse-checkout', 'set', '--no-cone', '/*', '!/docs/verification/evidence/'])
    run('checkout-source', ['git', '-C', str(source), 'checkout', '--detach', head])
    run('clone-ihk', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / 'ihk'), str(source / 'ihk')])
    run('checkout-ihk', ['git', '-C', str(source / 'ihk'), 'checkout', '--detach', ihk_head])
    submodules = subprocess.check_output(['git', '-C', str(repo), 'submodule', 'status', '--recursive'], universal_newlines=True)
    record['recursive_submodules'] = submodules.splitlines()
    for index, line in enumerate(submodules.splitlines()):
        assert line.startswith(' '), line
        revision, relative = line[1:].split()[:2]
        if relative == 'ihk': continue
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        run('clone-submodule-' + str(index), ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / relative), str(target)])
        run('checkout-submodule-' + str(index), ['git', '-C', str(target), 'checkout', '--detach', revision])
    record['compiler'] = subprocess.check_output(['/opt/mckernel/cargo/bin/rustc', '--version', '--verbose'], universal_newlines=True)
    record['source_status'] = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], universal_newlines=True)
    assert record['source_status'] == ''
    changed = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', 'HEAD', '-z']).split(b'\0')
    changed += subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    record['source_overlays'] = []
    for raw in sorted(set(changed)):
        if not raw: continue
        relative = os.fsdecode(raw)
        assert not relative.startswith('docs/verification/evidence/'), 'Checkpoint evidence before building: ' + relative
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / relative, path)
        record['source_overlays'].append(identity(path))
    record['production_inputs'] = [identity(source / p) for p in ['kernel/rust/native_signal.rs', 'arch/x86_64/kernel/syscall.c', 'arch/x86_64/kernel/include/signal.h', 'kernel/rust/clone3.rs', 'kernel/syscall.c', 'arch/x86_64/kernel/include/syscall_list.h', 'kernel/rust/x86_cpu_helpers.rs', 'host-kernel/native-rust/zero_pages.rs', 'lib/page_alloc.c', 'lib/include/ihk/page_alloc.h', 'kernel/rust/syscall_policy.rs', 'kernel/rust/page_alloc.rs', 'kernel/rust/x86_memory_helpers.rs', 'kernel/CMakeLists.txt', 'kernel/rust/smp_ikc.rs', 'kernel/rust/llist.rs', 'kernel/rust/lib.rs', 'kernel/rust/init.rs', 'kernel/rust/sysfs.rs', 'kernel/rust/abi.rs', 'kernel/rust/object_helpers.rs', 'kernel/rust/host_helpers.rs', 'kernel/rust/process_helpers.rs', 'kernel/rust/lock_helpers.rs', 'kernel/rust/procfs.rs', 'kernel/rust/cls.rs', 'kernel/procfs.c', 'kernel/cls.c', 'kernel/object_helpers.c', 'kernel/include/syscall.h', 'kernel/include/object_helpers.h', 'kernel/init.c', 'scripts/tests/fixtures/mckernel_guest_sysfs.rs', 'scripts/tests/fixtures/native-guest-sysfs.c', 'lib/include/list.h', 'arch/x86_64/kernel/include/registers.h', 'arch/x86_64/kernel/include/ihk/atomic.h']]
    record['production_inputs'] += [identity(source / p) for p in ultra_inputs]
    record['ultra_live_source_bindings'] = []
    for relative in ultra_inputs + ['kernel/CMakeLists.txt', 'kernel/rust/lib.rs',
            'kernel/rust/native_signal.rs', 'kernel/rust/syscall_policy.rs',
            'arch/x86_64/kernel/syscall.c', 'kernel/syscall.c']:
        live, compiled = identity(repo / relative), identity(source / relative)
        assert (live['size'], live['sha256']) == (compiled['size'], compiled['sha256']), relative
        record['ultra_live_source_bindings'].append(dict(relative=relative, live=live, compiled=compiled))
    lib_text = (source / 'kernel/rust/lib.rs').read_text()
    for module in ['native_fault', 'native_futex', 'native_xstate', 'native_signal']:
        assert '#[cfg(native_linux_irq_work_v6_12)]\nmod ' + module + ';' in lib_text, module
    policy_text = (source / 'kernel/rust/syscall_policy.rs').read_text()
    assert '#[cfg(native_linux_irq_work_v6_12)]\n    return match crate::native_signal::sigreturn(' in policy_text
    assert '#[cfg(not(native_linux_irq_work_v6_12))]\n    arch_rt_sigreturn_body_result(' in policy_text
    run('diff-check', ['git', 'diff', '--check'])
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false', 'kernel/rust/smp_ikc.rs', 'scripts/tests/fixtures/mckernel_irq_work_compile.rs', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs', 'scripts/tests/fixtures/mckernel_guest_sysfs.rs'])
    for enabled in [False, True]:
        command = ['cc', '-E', '-dM', '-x', 'c', '-I', str(source / 'lib/include'), '-include', 'list.h']
        if enabled: command.append('-DMCKERNEL_RUST_LIST_HELPERS')
        output = subprocess.check_output(command + ['/dev/null'])
        (out / ('list-macros-rust.txt' if enabled else 'list-macros-fallback.txt')).write_bytes(output)
        for macro in [b'#define list_for_each_entry(', b'#define list_for_each_entry_safe(']:
            assert (macro in output) == (not enabled)
    run('producer-check', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_mckernel_irq_work.py', '-v', '-f'])
    # The old broad harness requires three Rust sources absent from the exact
    # pinned IHK. Preserve its failed attempt 2; do not invent that old source.
    # The preceding focused test now runs the complete, unchanged pinned C
    # producer and the retained Rust producer with the same fixture and checks
    # identical observable results, plus the native extension independently.
    missing = [p for p in ['ihk/linux/core/rust/core_helpers.rs',
                          'ihk/linux/driver/smp/rust/smp_driver_helpers.rs',
                          'ihk/linux/user/rust/ihklib_helpers.rs'] if not (source / p).is_file()]
    record['historical_equivalence'] = dict(status='prerequisites-unavailable', missing=missing,
        retained_failure='/work/mckernel-native-irq-images-20260907-2', pass_claimed=False,
        current_surface_equivalence='producer-check includes exact pinned C body and current Rust body')
    assert len(missing) == 3
    common = ['cmake', '-S', str(source), '-DCMAKE_BUILD_TYPE=Debug', '-DBUILD_TARGET=smp-x86',
              '-DKERNEL_DIR=/usr/src/kernels/4.18.0-553.159.1.el8_10.x86_64',
              '-DENABLE_PERF=ON', '-DENABLE_RUSAGE=ON', '-DENABLE_LINUX_WORK_IRQ_FOR_IKC=ON',
              '-DRUSTC=/opt/mckernel/cargo/bin/rustc', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    run('reject-invalid-abi', common + ['-B', str(out / 'invalid-abi'), '-DMCKERNEL_HOST_IRQ_ABI=invalid'], 'MCKERNEL_HOST_IRQ_ABI must be legacy or linux-6.12')
    run('reject-native-c-fallback', common + ['-B', str(out / 'invalid-native-fallback'), '-DMCKERNEL_HOST_IRQ_ABI=linux-6.12', '-DENABLE_RUST_KERNEL=OFF'], 'linux-6.12 IRQ ABI requires the x86_64 Rust kernel')
    run('reject-sysfs-legacy', common + ['-B', str(out / 'invalid-sysfs-legacy'), '-DENABLE_NATIVE_SYSFS_VERIFY=ON', '-DMCKERNEL_HOST_IRQ_ABI=legacy'], 'Native sysfs verification requires the x86_64 Rust kernel and linux-6.12 IRQ ABI')
    run('reject-sysfs-c', common + ['-B', str(out / 'invalid-sysfs-c'), '-DENABLE_NATIVE_SYSFS_VERIFY=ON', '-DMCKERNEL_HOST_IRQ_ABI=legacy', '-DENABLE_RUST_KERNEL=OFF'], 'Native sysfs verification requires the x86_64 Rust kernel and linux-6.12 IRQ ABI')
    record['images'] = []
    record['clone3_table_checks'] = []
    record['signal_stack_checks'] = []
    record['ultra_selection_checks'] = []
    for label, enabled, abi in [('fallback', 'OFF', 'legacy'), ('legacy-rust', 'ON', 'legacy'), ('native-rust', 'ON', 'linux-6.12'), ('native-sysfs-verify', 'ON', 'linux-6.12')]:
        build = out / label
        verification = label == 'native-sysfs-verify'
        profile = ['-DENABLE_NATIVE_SYSFS_VERIFY=ON'] if verification else []
        run(label + '-configure', common + ['-B', str(build), '-DCMAKE_INSTALL_PREFIX=' + str(out / (label + '-prefix')),
                '-DENABLE_RUST_KERNEL=' + enabled, '-DENABLE_RUST_IHK_MODULE_HELPERS=' + enabled,
                '-DENABLE_RUST_USER_TOOLS=' + enabled, '-DMCKERNEL_HOST_IRQ_ABI=' + abi] + profile)
        run(label + '-build', ['cmake', '--build', str(build), '--target', 'mckernel.img', '-j4'])
        image = build / 'kernel/mckernel.img'
        artifacts = [image, build / 'kernel/mckernel.img.map', build / 'CMakeCache.txt', build / 'compile_commands.json']
        (out / (label + '-elf-header.txt')).write_bytes(subprocess.check_output(['readelf', '-h', str(image)]))
        (out / (label + '-symbols.txt')).write_bytes(subprocess.check_output(['nm', '-n', str(image)]))
        header = (out / (label + '-elf-header.txt')).read_text()
        assert 'ELF64' in header and 'Advanced Micro Devices X86-64' in header and 'EXEC' in header
        symbols = (out / (label + '-symbols.txt')).read_text()
        assert ' T ihk_mc_interrupt_host\n' in symbols
        assert ('ENABLE_NATIVE_SYSFS_VERIFY:BOOL=ON' in (build / 'CMakeCache.txt').read_text()) == verification
        assert ('sysfs_verify' in symbols) == verification
        assert (b'NATIVE_GUEST_SYSFS PASS' in image.read_bytes()) == verification
        if enabled == 'ON':
            artifacts += [build / 'kernel/rust/mckernel_rust.o', build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make']
            assert 'kernel/rust/procfs.rs' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            assert not any(row['file'].endswith('/kernel/procfs.c') for row in json.loads((build / 'compile_commands.json').read_text()))
            selected = 'native_linux_irq_work_v6_12' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            assert selected == (abi == 'linux-6.12')
            assert ('--cfg native_sysfs_verify' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()) == verification
            run(label + '-linked-ownership', ['python3', str(source / 'scripts/mckernel_linked_text_ownership.py'), '--image', str(image), '--link-map', str(build / 'kernel/mckernel.img.map'), '--rust-object', str(build / 'kernel/rust/mckernel_rust.o'), '--source-commit', head, '--output', str(out / (label + '-linked-ownership.json'))])
        sized=subprocess.check_output(['nm','-S',str(image)],universal_newlines=True)
        (out/(label+'-sized-symbols.txt')).write_text(sized)
        for symbol in ['sys_mprotect','do_fork','do_signal','sys_rt_sigreturn','sys_sigaltstack'] + (['sys_clone3','native_signal_stack_prepare_result','native_signal_stack_publish_result','arch_rt_sigreturn_body_result'] if abi == 'linux-6.12' else []) + (['set_host_vma_body_result','mprotect_body_result','__ihk_numa_zero_request_packet_fill','__ihk_numa_zero_free_pages_node'] if enabled == 'ON' else []):
            matches=[line.split() for line in sized.splitlines() if line.split()[-1:]==[symbol]]
            assert len(matches)==1 and len(matches[0])==4,(symbol,matches)
            start,size=int(matches[0][0],16),int(matches[0][1],16)
            assert size>0,(symbol,size)
            run(label+'-'+symbol+'-disassembly',['objdump','-d','--start-address='+hex(start),'--stop-address='+hex(start+size),str(image)])
        symbol_map={row[-1]:(int(row[0],16),int(row[1],16)) for line in sized.splitlines() for row in [line.split()] if len(row)==4}
        all_symbols = {row[-1]: int(row[0], 16) for line in symbols.splitlines()
                       for row in [line.split()] if len(row) == 3 and re.fullmatch(r'[0-9a-f]+', row[0])}
        native=abi=='linux-6.12'
        assert ('sys_clone3' in symbol_map)==native
        data=image.read_bytes()
        assert data[:6]==b'\x7fELF\x02\x01'
        table,table_bytes=symbol_map['syscall_table'];assert table_bytes>=436*8
        phoff=struct.unpack_from('<Q',data,32)[0];entsize,entries=struct.unpack_from('<HH',data,54)
        def table_word(index):
            address=table+index*8
            for entry in range(entries):
                kind,flags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',data,phoff+entry*entsize)
                if kind==1 and vaddr<=address and address+8<=vaddr+filesz:
                    return struct.unpack_from('<Q',data,offset+address-vaddr)[0]
            raise AssertionError(('syscall table not file-backed',index,hex(address)))
        expected=symbol_map['sys_clone3'][0] if native else 0
        assert table_word(435)==expected
        assert table_word(56)==symbol_map['sys_clone'][0]
        commands=json.loads((build/'compile_commands.json').read_text())
        dispatch=[row for row in commands if row['file']==str(source/'kernel/syscall.c')];assert len(dispatch)==1
        arch_dispatch=[row for row in commands if row['file']==str(source/'arch/x86_64/kernel/syscall.c')];assert len(arch_dispatch)==1
        for row in dispatch+arch_dispatch:
            assert ('-DMCKERNEL_NATIVE_CLONE3' in row['command'])==native
        fork_code=(out/(label+'-do_fork-disassembly.log')).read_text()
        assert bool(re.search(r'\$0x1b3\b',fork_code))==native
        if enabled=='ON':assert 'kernel/rust/clone3.rs' in (build/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
        for name in ['native_signal_stack_prepare_result','native_signal_stack_publish_result']:
            assert (name in symbol_map)==native,name
            code=(out/(label+'-do_signal-disassembly.log')).read_text()
            if native:
                address=hex(symbol_map[name][0]);lines=code.splitlines()
                loads=[(i,re.search(r'\bmovabs\s+\$'+re.escape(address)+r',(%\w+)',line)) for i,line in enumerate(lines)]
                loads=[(i,m) for i,m in loads if m];assert len(loads)==1,(label,name,loads)
                index,match=loads[0];register=match[1];window=lines[index+1:index+8]
                calls=[i for i,line in enumerate(window) if re.search(r'\bcallq?\s+\*'+re.escape(register)+r'\s*$',line)]
                assert len(calls)==1,(label,name,window)
                assert not any(re.search(r','+re.escape(register)+r'\s*$',line) or re.search(r'\bcallq?\b',line) for line in window[:calls[0]]),(label,name,window)
        assert ('-DMCKERNEL_NATIVE_SIGNAL_STACK' in arch_dispatch[0]['command'])==native
        assert table_word(15)==symbol_map['sys_rt_sigreturn'][0]
        assert table_word(131)==symbol_map['sys_sigaltstack'][0]
        if enabled=='ON':assert 'kernel/rust/native_signal.rs' in (build/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()

        # Additive Ultra audit. Every preceding original profile/assertion is
        # retained, including the exact signal stack checks and old body.
        ultra = dict(profile=label, native=native, compiler_bindings=[],
                     rust_dependencies=[], calls=[], assembly_hooks=[],
                     runtime_proven=False, kernel_fault_recovery_executed=False)
        for relative in ['kernel/syscall.c', 'arch/x86_64/kernel/syscall.c',
                         'arch/x86_64/kernel/cpu.c', 'arch/x86_64/kernel/interrupt.S']:
            selected_commands = [row for row in commands if row['file'] == str(source / relative)]
            assert len(selected_commands) == 1, (label, relative, selected_commands)
            command = selected_commands[0]
            tokens = shlex.split(command['command'])
            for macro in ultra_macros:
                assert ('-D' + macro in tokens) == native, (label, relative, macro)
            assert tokens.count('-o') == 1 and tokens.count('-c') == 1, (label, relative)
            assert tokens[tokens.index('-c') + 1] == str(source / relative)
            obj = Path(command['directory']) / tokens[tokens.index('-o') + 1]
            assert obj.is_file(), (label, relative, obj)
            if relative.endswith('.S'):
                dependency = build / 'kernel/CMakeFiles/mckernel.img.dir/depend.internal'
                lines = dependency.read_text().splitlines()
                target = os.path.relpath(str(obj), str(build))
                assert any(line == target and lines[index + 1:index + 2] == [' ' + str(source / relative)]
                           for index, line in enumerate(lines)), (label, target)
            else:
                dependency = Path(str(obj) + '.d')
                assert str(source / relative) in dependency.read_text(), (label, relative, dependency)
            artifacts.extend([obj, dependency])
            ultra['compiler_bindings'].append(dict(source=identity(source / relative),
                command=command, object=identity(obj), dependency=identity(dependency), native_macros=ultra_macros))
        if enabled == 'ON':
            makefile = build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make'
            make_text = makefile.read_text()
            for relative in ultra_rust_dependencies:
                dependency_line = 'kernel/rust/mckernel_rust.o: ' + str(source / relative)
                assert dependency_line in make_text.splitlines(), (label, relative)
                ultra['rust_dependencies'].append(dict(source=identity(source / relative),
                    dependency_line=dependency_line, build_make=identity(makefile)))
            for relative in ['kernel/futex.c', 'kernel/sched_helpers.c']:
                assert not any(row['file'] == str(source / relative) for row in commands), (label, relative)
        else:
            for relative in ['kernel/futex.c', 'kernel/sched_helpers.c']:
                assert len([row for row in commands if row['file'] == str(source / relative)]) == 1, (label, relative)
        for name in ultra_native_functions + ultra_native_labels:
            assert (name in all_symbols) == native, (label, name)
        for name in ultra_native_functions:
            if native:
                assert name in symbol_map and symbol_map[name][1] > 0, (label, name)
        ultra['native_symbols'] = {name: all_symbols.get(name) for name in ultra_native_functions + ultra_native_labels}

        # Disassemble new named functions using exact sized ELF spans. The
        # retained old sigreturn body is still inspected in the original loop.
        additional = (list(ultra_native_functions) if native else []) + ['do_futex_syscall_time_bridge']
        if enabled == 'ON':
            additional += ['get_futex_value_locked', 'do_futex_body_result',
                           'futex_wait_body_result', 'timer_schedule_timeout_body_result']
            if not native:
                additional.append('arch_rt_sigreturn_body_result')
        for name in additional:
            assert name in symbol_map and symbol_map[name][1] > 0, (label, name)
            start, size = symbol_map[name]
            run(label + '-' + name + '-disassembly', ['objdump', '-d',
                '--no-show-raw-insn', '--start-address=' + hex(start),
                '--stop-address=' + hex(start + size), str(image)])

        def code_for(name):
            return (out / (label + '-' + name + '-disassembly.log')).read_text()

        def require_call(caller, callee, tail=False, exactly=None):
            hits = exact_calls(code_for(caller), all_symbols[callee], tail)
            assert hits and (exactly is None or len(hits) == exactly), (label, caller, callee, hits)
            ultra['calls'].append(dict(caller=caller, callee=callee,
                                       tail_allowed=tail, matches=hits))
            return hits

        # Assembly entry labels carry no STT_FUNC size. Exact adjacent exported
        # labels bound the two complete handlers, never an arbitrary byte count.
        for handler, end_name, trap in [('page_fault', 'general_protection_exception', 14),
                                        ('general_protection_exception', '__freeze', 13)]:
            start, end = all_symbols[handler], all_symbols[end_name]
            assert 0 < end - start < 1024, (label, handler, hex(start), hex(end))
            run(label + '-' + handler + '-disassembly', ['objdump', '-d',
                '--no-show-raw-insn', '--start-address=' + hex(start),
                '--stop-address=' + hex(end), str(image)])
            code = code_for(handler)
            rows = instructions(code)
            assert any(row['mnemonic'] == 'iretq' for row in rows), (label, handler)
            if handler == 'page_fault':
                assert any(row['mnemonic'] in {'call', 'callq'} and row['operands'] == '*%rax'
                           for row in rows), (label, handler, 'original fault handler call missing')
            else:
                require_call(handler, 'gpe_handler', exactly=1)
            hook = dict(handler=handler, start=start, end=end, end_symbol=end_name, trap=trap,
                        original_handler_retained=True, native_hook_selected=native)
            if native:
                hits = require_call(handler, 'native_fault_fixup', exactly=1)
                assert hits[0]['kind'] == 'direct', (label, handler, hits)
                call_pc = hits[0]['instruction']['pc']
                index = next(index for index, row in enumerate(rows) if row['pc'] == call_pc)
                assert rows[index - 1]['mnemonic'] in {'mov', 'movl'}
                assert rows[index - 1]['operands'] == '$0x' + format(trap, 'x') + ',%esi'
                assert rows[index - 2]['mnemonic'] in {'mov', 'movq'}
                assert rows[index - 2]['operands'] == '%rsp,%rdi'
                assert rows[index + 1]['mnemonic'] in {'test', 'testl'}
                assert rows[index + 1]['operands'] == '%eax,%eax'
                assert rows[index + 2]['mnemonic'] in {'jne', 'jnz'}
                return_pc = int(rows[index + 2]['operands'].split()[0], 16)
                assert start <= return_pc < end
                returned = next(row for row in rows if row['pc'] == return_pc)
                assert returned['mnemonic'] in {'mov', 'movq'}
                # POP_ALL_REGS clears flags after the 48-byte saved sregs.
                assert returned['operands'] == '$0x0,0x30(%rsp)'
                assert any(call_pc < row['pc'] < return_pc and row['mnemonic'] in {'call', 'callq'}
                           for row in rows), (label, handler, 'fixup must skip the retained ordinary handler')
                hook['exact_call'] = hits[0]
                hook['recovered_return_pc'] = return_pc
            else:
                assert 'native_fault_fixup' not in code, (label, handler)
            ultra['assembly_hooks'].append(hook)

        if native:
            def elf_span(address, length):
                for entry in range(entries):
                    kind, flags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack_from(
                        '<IIQQQQQQ', data, phoff + entry * entsize)
                    if kind == 1 and vaddr <= address and address + length <= vaddr + filesz:
                        return data[offset + address - vaddr:offset + address - vaddr + length]
                raise AssertionError(('ELF interval not file-backed', hex(address), length))

            read_start, read_size = symbol_map['native_user_read_u32_checked']
            read_fault, read_recover = (all_symbols['native_user_read_u32_fault'],
                                        all_symbols['native_user_read_u32_recover'])
            assert read_fault == read_start and read_recover == read_start + 6 and read_size == 7
            assert elf_span(read_start, read_size) == bytes.fromhex('8b 07 89 06 31 c0 c3')
            xr_start, xr_size = symbol_map['native_xrstor_checked']
            xr_fault, xr_recover = all_symbols['native_xrstor_fault'], all_symbols['native_xrstor_recover']
            assert xr_start < xr_fault < xr_recover < xr_start + xr_size
            assert elf_span(xr_fault, 3) == bytes.fromhex('0f ae 2f')
            assert elf_span(xr_recover, 1) == bytes.fromhex('c3')
            fixup = code_for('native_fault_fixup')
            for name in ultra_native_labels:
                assert exact_address_references(fixup, all_symbols[name]), (label, name)
            ultra['fault_instruction_bindings'] = dict(
                user_load=dict(start=read_start, fault=read_fault, recovery=read_recover,
                               bytes=elf_span(read_start, read_size).hex(), kernel_output_store_whitelisted=False),
                xrstor=dict(start=xr_start, fault=xr_fault, recovery=xr_recover,
                            bytes=elf_span(xr_start, xr_size).hex()))
            require_call('get_futex_value_locked', 'native_user_read_u32_checked', tail=True, exactly=1)
            require_call('do_fork', 'write_process_vm', exactly=1)
            for name in ['native_xstate_buffer_size_result', 'native_xstate_validate_result',
                         'arch_native_signal_mxcsr_mask_bridge', 'native_xrstor_checked',
                         'arch_native_signal_reset_fp_bridge']:
                require_call('arch_native_signal_restore_fp_bridge', name, tail=True, exactly=1)
            require_call('arch_native_signal_reset_fp_bridge', 'native_xrstor_checked', tail=True, exactly=1)
            entry = require_call('do_signal', 'native_signal_entry_targets_result', exactly=1)
            prepare = require_call('do_signal', 'native_signal_stack_prepare_result', exactly=1)
            assert entry[0]['instruction']['pc'] < prepare[0]['instruction']['pc'], label
            for name in ['native_signal_context_prepare_result', 'native_signal_action_mask_result']:
                require_call('do_signal', name, exactly=1)
            require_call('sys_rt_sigreturn', 'arch_native_signal_bad_frame_bridge', tail=True, exactly=1)

            # LLVM may inline the private native consumer or keep its single
            # local Rust function. Both require an actual call path to the
            # checked bridge; mere linkage is insufficient.
            restore_hits = exact_calls(code_for('sys_rt_sigreturn'),
                                       all_symbols['arch_native_signal_restore_fp_bridge'], tail=True)
            if restore_hits:
                require_call('sys_rt_sigreturn', 'arch_native_signal_restore_fp_bridge', tail=True)
                ultra['native_sigreturn_consumer'] = 'inlined into sys_rt_sigreturn'
            else:
                consumers = [name for name in symbol_map if 'native_signal' in name and 'sigreturn' in name]
                assert len(consumers) == 1, (label, consumers)
                consumer = consumers[0]
                start, size = symbol_map[consumer]
                run(label + '-' + consumer + '-disassembly', ['objdump', '-d',
                    '--no-show-raw-insn', '--start-address=' + hex(start),
                    '--stop-address=' + hex(start + size), str(image)])
                require_call('sys_rt_sigreturn', consumer, tail=True, exactly=1)
                require_call(consumer, 'arch_native_signal_restore_fp_bridge', tail=True, exactly=1)
                ultra['native_sigreturn_consumer'] = consumer
            assert 'arch_rt_sigreturn_body_result' in symbol_map
            assert not exact_address_references(code_for('sys_rt_sigreturn'),
                                                all_symbols['arch_rt_sigreturn_body_result']), label
            ultra['old_sigreturn_body_retained'] = symbol_map['arch_rt_sigreturn_body_result']
            ultra['old_sigreturn_body_selected_by_native_syscall'] = False
        elif enabled == 'ON':
            assert 'arch_rt_sigreturn_body_result' in symbol_map
            direct_legacy = exact_calls(code_for('sys_rt_sigreturn'),
                                        all_symbols['arch_rt_sigreturn_body_result'])
            if direct_legacy:
                require_call('sys_rt_sigreturn', 'arch_rt_sigreturn_body_result', exactly=1)
                ultra['legacy_sigreturn_consumer'] = 'exact call to retained original body'
            else:
                # Attempt 1 retained the actual optimized legacy syscall: LLVM
                # inlined the complete body, including its restart, trap and FP
                # branches. Bind every original provider call, not just a
                # linked symbol or a presumed non-inlined call edge.
                legacy_bridges = ['arch_rt_sigreturn_context_bridge',
                    'arch_copy_from_user_bridge', 'arch_rt_sigreturn_syscall_bridge',
                    'arch_rt_sigreturn_set_signal_bridge', 'check_need_resched',
                    'arch_rt_sigreturn_check_signal_bridge', 'arch_rt_sigreturn_alloc_bridge',
                    'arch_rt_sigreturn_xrstor_bridge', 'arch_rt_sigreturn_free_bridge']
                for bridge in legacy_bridges:
                    require_call('sys_rt_sigreturn', bridge)
                assert not exact_address_references(code_for('sys_rt_sigreturn'),
                                                    all_symbols['arch_rt_sigreturn_body_result'])
                assert all(name not in all_symbols for name in ultra_native_functions)
                ultra['legacy_sigreturn_consumer'] = 'original body inlined; all nine legacy provider calls bound to exact ELF targets'
                ultra['legacy_inlining_reference'] = '/work/mckernel-native-ultra-images-20260909-1/legacy-rust-sys_rt_sigreturn-disassembly.log'
            ultra['old_sigreturn_body_retained'] = symbol_map['arch_rt_sigreturn_body_result']
            ultra['old_sigreturn_body_selected_by_legacy_syscall'] = True
        if not native:
            assert not exact_calls(code_for('do_fork'), all_symbols['write_process_vm']), label
        record['ultra_selection_checks'].append(ultra)
        record['signal_stack_checks'].append(dict(profile=label,native=native,slot15=table_word(15),slot131=table_word(131),prepare=symbol_map.get('native_signal_stack_prepare_result'),publish=symbol_map.get('native_signal_stack_publish_result'),architecture_dispatch=arch_dispatch[0]))
        record['clone3_table_checks'].append(dict(profile=label,native=native,table=table,table_bytes=table_bytes,slot435=table_word(435),rust_handler=expected,existing_clone=table_word(56),native_marker_bypass=native,compiler_dispatch=dispatch[0],architecture_dispatch=arch_dispatch[0]))
        record['images'].append(dict(kind=label, host_irq_abi=abi, native_sysfs_verify=verification, outputs=[identity(path) for path in artifacts]))
        save()
    assert record['images'][1]['outputs'][0]['sha256'] != record['images'][2]['outputs'][0]['sha256']
    assert record['images'][2]['outputs'][0]['sha256'] != record['images'][3]['outputs'][0]['sha256']
    for item in record['production_inputs']:
        assert identity(Path(item['path'])) == item
    for binding in record['ultra_live_source_bindings']:
        assert identity(Path(binding['live']['path'])) == binding['live'], binding['relative']
        assert identity(Path(binding['compiled']['path'])) == binding['compiled'], binding['relative']
    assert identity(original_helper) == record['adaptation']['original']
    assert any(row['file'].endswith('/kernel/procfs.c') for row in json.loads((out / 'fallback/compile_commands.json').read_text()))
    record.update(status='PASS', phase='complete', native_zeroing_batch_compiled=True, native_host_zeroing_integrated=True, native_clone3_guest_handler_compiled=True, native_protection_invalidation_compiled=True, procfs_guest_lifetime_fixes_compiled=True, native_procfs_completion_marker_selected=True, native_retirement_query_compiled=True, procfs_service_integrated=True, mckernel_application_executed=False)
    record.update(native_fault_hooks_selected=True, native_futex_checked_load_selected=True,
                  native_xstate_checked_restore_selected=True, native_clone_tid_selection_compiled=True,
                  actual_fault_recovery_proven=False, ultra_application_acceptance=False)
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
