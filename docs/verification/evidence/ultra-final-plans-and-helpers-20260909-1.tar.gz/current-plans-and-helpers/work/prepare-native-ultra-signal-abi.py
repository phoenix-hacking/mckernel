from pathlib import Path
import hashlib
scratch=Path('/home/holden/mckernel-work/scratch')
source=scratch/'run-native-ultra-baseline.py'
original=source.read_text()
retained=scratch/'run-native-ultra-signal-abi-baseline-original.py'
assert not retained.exists()
retained.write_text(original)
s=original

def replace(old,new):
    global s
    assert s.count(old)==1,(old,s.count(old))
    s=s.replace(old,new)

replace('case, module_attempt, image_attempt, attempt = sys.argv[1:]',
        "module_attempt, image_attempt, protocol_attempt, attempt = sys.argv[1:]\ncase = 'signals'\nsignal_protocol = Path('/work/native-signal-abi-protocol-20260909-' + protocol_attempt)")
replace("out = Path('/work/native-ultra-baseline-' + case + '-guest-20260909-' + attempt)",
        "out = Path('/work/native-ultra-signal-abi-guest-20260909-' + attempt)")
replace("    shutil.copyfile(__file__, out / 'helper.py')", """    shutil.copyfile(__file__, out / 'helper.py')
    baseline_original = Path('/work/run-native-ultra-signal-abi-baseline-original.py')
    assert hashlib.sha256(baseline_original.read_bytes()).hexdigest() == '@BASELINE_HASH@'
    shutil.copyfile(baseline_original, out / 'baseline-runner-original.py')
    record['inputs'].append(identity(out / 'baseline-runner-original.py'))
    record['runner_adaptation'] = 'Complete original baseline retained; every original boot, metadata/string, HELLO and signals-core assertion applies to the exact preceding console. New signal cases have separate strict assertions. Guest fp-restart is explicitly BLOCKED, not a passing or skipped case.'
""".replace('@BASELINE_HASH@',hashlib.sha256(original.encode()).hexdigest()).rstrip())
replace("    probe = out / 'probe-source'", """    signal_record = json.loads((signal_protocol / 'record.json').read_text())
    assert signal_record['status'] == 'PASS'
    for row in signal_record['outputs']:
        assert identity(Path(row['path'])) == row
    signal_binary = signal_protocol / 'native-signal-abi'
    assert identity(signal_binary) == signal_record['binary']
    shutil.copyfile(signal_binary, root / 'bin/native-signal-abi')
    (root / 'bin/native-signal-abi').chmod(0o755)
    record['inputs'] += [identity(signal_protocol / 'record.json'), identity(signal_binary),
                         identity(signal_protocol / 'native-signal-abi.c')]
    controller_source = out / 'native-signal-controller.c'
    shutil.copyfile(repo / 'scripts/tests/fixtures/native-signal-controller.c', controller_source)
    run('signal-controller-build', ['cc', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
                                   '-Wl,-z,noexecstack', '-MD', '-MF', str(out / 'signal-controller.d'),
                                   str(controller_source), '-o', str(root / 'bin/native-signal-controller')])
    run('signal-controller-elf', ['readelf', '-h', '-l', str(root / 'bin/native-signal-controller')])
    run('signal-controller-disassembly', ['objdump', '-d', str(root / 'bin/native-signal-controller')])
    record['inputs'] += [identity(controller_source), identity(root / 'bin/native-signal-controller')]
    record['controller_compiler_dependencies'] = []
    for name in (out / 'signal-controller.d').read_text().replace('\\\\\\n', ' ').split()[1:]:
        dependency = Path(name)
        if dependency.is_absolute() and dependency.is_file():
            record['controller_compiler_dependencies'].append(identity(dependency))
    assert record['controller_compiler_dependencies']
    for row in signal_record['runtime_libraries']:
        source = Path(row['captured']['path'])
        assert identity(source) == row['captured']
        target = root / row['original']['path'].lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == source.read_bytes(), str(target)
        else:
            shutil.copyfile(source, target)
        record['inputs'].append(identity(source))
    controller_dependencies = run('signal-controller-libraries', ['ldd', str(root / 'bin/native-signal-controller')])
    assert 'not found' not in controller_dependencies
    for name in sorted(set(re.findall(r'(/[^\\s()]+)\\s+\\(0x[0-9a-f]+\\)', controller_dependencies))):
        original_path = Path(name)
        target = root / name.lstrip('/')
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == original_path.read_bytes(), name
        else:
            shutil.copyfile(original_path, target)
        record['inputs'] += [identity(original_path), identity(target)]
    probe = out / 'probe-source'""")
needle="printf '<6>NATIVE_APPLICATION_GUEST PASS application_exit=37"
extra=r'''printf '<6>NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3\\n' >/dev/kmsg
for signal_case in mask-context fp-return; do
/bin/native-signal-controller --linux-reference /bin/native-signal-abi "$signal_case"
/bin/native-signal-controller --guest /bin/mcexec /bin/native-signal-abi "$signal_case"
process_nodes=(/proc/mcos0/[0-9]*)
[ "${#process_nodes[@]}" -eq 0 ]
printf '<6>NATIVE_SIGNAL_REGISTRATIONS_CLEAR case=%s\\n' "$signal_case" >/dev/kmsg
done
/bin/native-signal-controller --linux-reference /bin/native-signal-abi fp-restart
printf '<6>NATIVE_SIGNAL_RESTART BLOCKED guest=1 reason=native_mcctrl_missing_SIG_THREAD_and_SEND_SIGNAL\\n' >/dev/kmsg
printf '<6>NATIVE_SIGNAL_ABI_COMPLETE guest_cases=2 linux_cases=3 restart_guest=BLOCKED\\n' >/dev/kmsg
'''
replace(needle,extra+needle)
replace("                    console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]", """                    full_console=serial.split('NATIVE_APPLICATION_GUEST PASS',1)[0]
                    console=full_console.split('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3',1)[0]""")
replace("            for bad in ('NATIVE_CORE FAIL',", "            for bad in ('NATIVE_SIGNAL_CONTROL FAIL', 'NATIVE_CORE FAIL',")
needle="\n                else:\n                    marker = 'NATIVE_BUILDID_GUEST PASS"
extra=r'''
                    assert full_console.count('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3') == 1
                    extra_console = full_console.split('NATIVE_SIGNAL_ABI_BEGIN guest_cases=2 linux_cases=3', 1)[1]
                    assert 'cleanup retained' not in extra_console and 'reap_retained' not in extra_console
                    case_order = re.findall(r'NATIVE_SIGNAL_BEGIN guest=(\d) case=([a-z-]+)', extra_console)
                    assert case_order == [('0','mask-context'),('1','mask-context'),('0','fp-return'),('1','fp-return'),('0','fp-restart')], case_order
                    cases = []
                    for guest, signal_case in case_order:
                        begin = 'NATIVE_SIGNAL_BEGIN guest=' + guest + ' case=' + signal_case
                        window = extra_console.split(begin,1)[1].split('NATIVE_SIGNAL_BEGIN',1)[0]
                        terminal = re.findall(r'NATIVE_SIGNAL_CONTROL PASS guest='+guest+r' case='+signal_case+r' pid=(\d+) tid=(-?\d+) raw_status=(\d+) exit=(\d+)',window)
                        assert len(terminal) == 1, (signal_case, terminal)
                        signal_pid, signal_tid, raw_status, exit_code = terminal[0]
                        assert raw_status == str(37 << 8) and exit_code == '37'
                        expected_stdout = (b'NATIVE_SIGNAL_RESTART_READY\n' if signal_case == 'fp-restart' else b'') + ('NATIVE_SIGNAL_ABI PASS '+signal_case+'\n').encode()
                        expected_stderr = b'NATIVE_SIGNAL_RESTART_HANDLED\n' if signal_case == 'fp-restart' else b''
                        for stream_name, expected in [('stdout',expected_stdout),('stderr',expected_stderr)]:
                            streams = re.findall(r'NATIVE_SIGNAL_STREAM guest='+guest+r' case='+signal_case+r' stream='+stream_name+r' bytes=(\d+) hex=([0-9a-f]*)',window)
                            assert len(streams) == 1 and int(streams[0][0]) == len(expected) and streams[0][1] == expected.hex(), (signal_case,stream_name,streams)
                        row = dict(case=signal_case, guest=guest=='1', pid=int(signal_pid), worker_tid=int(signal_tid),
                                   raw_wait_status=int(raw_status), exit_code=37, stdout_hex=expected_stdout.hex(),
                                   stderr_hex=expected_stderr.hex(), exact_streams=True)
                        if guest == '0':
                            assert not re.search(r'application SCHEDULE os=',window)
                            if signal_case == 'fp-restart':
                                blocked = re.findall(r'NATIVE_SIGNAL_BLOCKED guest=0 case=fp-restart pid='+signal_pid+r' tid='+signal_tid+r' syscall=0 0x0 (0x[0-9a-f]+) 0x1\b',window)
                                assert len(blocked) == 1 and signal_pid == signal_tid, (blocked,terminal)
                                assert 'NATIVE_SIGNAL_HANDLED_BEFORE_INPUT guest=0 case=fp-restart pid='+signal_pid+' tid='+signal_tid+' input=a5' in window
                                row.update(blocked_read_observed=True,read_buffer=blocked[0],handler_ack_before_input=True,input_hex='a5')
                            else:
                                assert signal_tid == '-1'
                            cases.append(row)
                            continue
                        assert signal_tid == '-1'
                        assert re.findall(r'application SCHEDULE os=0 generation=1 pid=(\d+) cpu=0',window) == [signal_pid]
                        for operation in ('published','deleted'):
                            assert re.findall(r'application procfs '+operation+r' os=0 generation=1 pid='+signal_pid+r' tid=(\d+)\b',window) == [signal_pid], (signal_case,operation)
                        assert len(re.findall(r'application retirement os=0 generation=1 pid='+signal_pid+r' token=\d+ errno=0\b',window)) == 1
                        assert len(re.findall(r'application_process=release os=0 generation=1 pid='+signal_pid+r' cleanup_errno=0\b',window)) == 1
                        assert 'NATIVE_SIGNAL_REGISTRATIONS_CLEAR case='+signal_case in window
                        signal_delivered = re.findall(r'application_syscall=delivered os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) number=(\d+)',window)
                        signal_returned = re.findall(r'application_syscall=returned os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) cpu=(\d+) value=(-?\d+)',window)
                        assert signal_delivered and all(item[2] == '0' for item in signal_delivered+signal_returned)
                        assert not any(item[3] in ('13','14','15','56','131','234','435') for item in signal_delivered), signal_delivered
                        writes = [item for item in signal_delivered if item[3] == '1']
                        assert len(writes) == 1 and writes[0][:3]+(str(len(expected_stdout)),) in signal_returned, (writes,signal_returned)
                        assert any(item[3] == '231' for item in signal_delivered)
                        signal_routes = re.findall(route_pattern,window)
                        for route_pid, worker, delivery, launcher_cpu, guest_cpu in signal_routes:
                            assert route_pid == signal_pid and guest_cpu == '0' and launcher_cpu != guest_cpu
                            assert len([item for item in signal_delivered if item[:3] == (worker,delivery,guest_cpu)]) == 1
                            assert len([item for item in signal_returned if item[:3] == (worker,delivery,guest_cpu)]) == 1
                        signal_invalidations = re.findall(r'host_mapping=invalidated os=0 generation=1 pid='+signal_pid+r' worker=(\d+) delivery=(\d+) value=(-?\d+) completed=(-?\d+)',window)
                        assert all(item[2:] == ('0','0') for item in signal_invalidations)
                        counts = {}; events = []
                        for match in re.finditer(r'file_pager=(create|release) handle=(\d+) references=(\d+) (shared|remaining)=(\d+)',window):
                            operation, handle, refs, label, value = match.groups(); refs=int(refs); value=int(value)
                            if operation == 'create':
                                assert label == 'shared' and value == int(counts.get(handle,0)>0)
                                assert refs == counts.get(handle,0)+1
                                counts[handle] = refs
                            else:
                                assert label == 'remaining' and 0 < refs <= counts[handle]
                                counts[handle] -= refs
                                assert counts[handle] == value
                            events.append(match.groups())
                        assert counts and all(value == 0 for value in counts.values()), (counts,events)
                        guest_log = (out/'capture-application/kmsg.txt').read_text()
                        signal_frames = re.findall(r'signal_handler pid='+signal_pid+r' tid='+signal_pid+r' sig=(\d+) handler=(0x[0-9a-f]+) restorer=(0x[0-9a-f]+) old_rip=(0x[0-9a-f]+) old_sp=(0x[0-9a-f]+) new_sp=(0x[0-9a-f]+)',guest_log)
                        signal_returns = re.findall(r'mcexec_v10: syscall return cpu=0 pid='+signal_pid+r' tid='+signal_pid+r' nr=15 ret=0x[0-9a-f]+ ret_signed=(-?\d+)\b',guest_log)
                        expected_signals = ['10','12'] if signal_case == 'mask-context' else ['10']
                        expected_returns = ['12345','12345'] if signal_case == 'mask-context' else ['0']
                        assert [item[0] for item in signal_frames] == expected_signals, signal_frames
                        assert signal_returns == expected_returns, signal_returns
                        assert 'native bad signal frame' not in guest_log
                        row.update(delivered=signal_delivered,returned=signal_returned,return_routes=signal_routes,
                                   pager_events=events,pager_remaining=counts,invalidations=signal_invalidations,
                                   frames=signal_frames,sigreturn_results=list(map(int,signal_returns)),
                                   normal_retirement=True,procfs_cleared=True,guest_fork_executed=False)
                        cases.append(row)
                    assert len({item['pid'] for item in cases}) == 5
                    assert not {item['pid'] for item in cases if item['guest']} & {item['pid'] for item in launches}
                    assert record['core_application']['pid'] not in {item['pid'] for item in cases}
                    assert 'NATIVE_SIGNAL_RESTART BLOCKED guest=1 reason=native_mcctrl_missing_SIG_THREAD_and_SEND_SIGNAL' in extra_console
                    assert 'NATIVE_SIGNAL_ABI_COMPLETE guest_cases=2 linux_cases=3 restart_guest=BLOCKED' in extra_console
                    record['signal_abi_cases'] = cases
                    record['signal_guest_restart'] = dict(status='BLOCKED',guest_executed=False,
                        reason='Selected native mcctrl lacks SIG_THREAD and SEND_SIGNAL. Unchanged launcher external-signal handler receives EINVAL and exits1.',
                        prerequisite='Max must design, implement and validate native signal forwarding with existing descriptor/packet ownership before activating the prepared controller guest fp-restart invocation.',
                        controller_prepared=True,timeout_seconds=45,expected_raw_wait_status=37<<8,
                        expected_stdout_hex=(b'NATIVE_SIGNAL_RESTART_READY\nNATIVE_SIGNAL_ABI PASS fp-restart\n').hex(),
                        expected_stderr_hex=b'NATIVE_SIGNAL_RESTART_HANDLED\n'.hex(),required_read_bytes=1,
                        required_input_hex='a5',handler_ack_before_input=True)
                    record['signal_guest_cases_passed'] = ['mask-context','fp-return']
                    record['signal_linux_cases_passed'] = ['mask-context','fp-return','fp-restart']
                    record['signal_reference_kernel'] = identity(compiled/'bzImage')
'''
replace(needle,'\n'+extra+needle)
replace("    else:\n        record['scope'] = 'Actual OS metadata", "    if mode == 'application':\n        record['scope'] = 'Two benign signal ABI guest cases (mask-context, fp-return), three same-payload references on the exact pinned Linux kernel, plus every unchanged eight-HELLO/signals-core/boot/control regression. Guest external-signal fp-restart is BLOCKED by missing native forwarding and receives no acceptance credit.'\n    else:\n        record['scope'] = 'Actual OS metadata")
(scratch/'run-native-ultra-signal-abi.py').write_text(s)
print('Prepared separate signal runner with complete baseline original; no build or guest execution.')
