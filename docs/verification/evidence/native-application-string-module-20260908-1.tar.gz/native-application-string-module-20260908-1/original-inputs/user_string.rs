// SPDX-License-Identifier: GPL-2.0
//! Shared bounded, single-pass pathname reads for native host consumers.

use kernel::{prelude::*, uaccess::UserSlice};

/// Adapt the existing image-loader loop without reading past its first NUL.
/// Returns whether a terminator was present inside the supplied capacity.
pub(super) fn read_into(argument: usize, bytes: &mut [u8]) -> Result<bool> {
    let mut reader = UserSlice::new(argument, bytes.len()).reader();
    for byte in bytes {
        *byte = reader.read::<u8>()?;
        if *byte == 0 {
            return Ok(true);
        }
    }
    Ok(false)
}

/// Adapt mcctrl_control_strncpy_from_user_body_result for current-task
/// userspace, retaining its chunking and separate descriptor/data error ABI.
pub(super) fn copy(argument: usize, compat: bool) -> Result<isize> {
    let width = if compat { 4 } else { 8 };
    let mut descriptor = [0; 32];
    UserSlice::new(argument, 4 * width)
        .reader()
        .read_slice(&mut descriptor[..4 * width])?;
    let word = |index| {
        let mut bytes = [0; 8];
        bytes[..width].copy_from_slice(&descriptor[index * width..(index + 1) * width]);
        u64::from_le_bytes(bytes) as usize
    };
    let (destination, source, count) = (word(0), word(1), word(2));
    // One initialized x86 page, outside the kernel stack. Existing source
    // consumers continue using read_into without reading past their first NUL.
    let mut buffer = Vec::with_capacity(4096, GFP_KERNEL)?;
    for _ in 0..4096 {
        buffer.push(0, GFP_KERNEL)?;
    }
    let result = (|| -> Result<usize> {
        let mut copied = 0usize;
        while copied < count {
            let length = (count - copied).min(buffer.len());
            let input = source.checked_add(copied).ok_or(EFAULT)?;
            let terminated = read_into(input, &mut buffer[..length])?;
            let bytes = if terminated {
                buffer[..length].iter().position(|&byte| byte == 0).unwrap()
            } else {
                length
            };
            let output = destination.checked_add(copied).ok_or(EFAULT)?;
            let written = bytes + usize::from(terminated);
            UserSlice::new(output, written)
                .writer()
                .write_slice(&buffer[..written])?;
            copied = copied.checked_add(bytes).ok_or(EFAULT)?;
            if terminated {
                break;
            }
        }
        Ok(copied)
    })();
    let result = result.map_or_else(|error| error.to_errno() as i64, |bytes| bytes as i64);
    descriptor[3 * width..4 * width].copy_from_slice(&result.to_le_bytes()[..width]);
    UserSlice::new(argument, 4 * width)
        .writer()
        .write_slice(&descriptor[..4 * width])?;
    Ok(0)
}
