from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-control-channels-retained-20260907-1'; out.mkdir()
def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1<<20),b''): value.update(data)
    return value.hexdigest()
record=dict(created_utc=datetime.now(timezone.utc).isoformat(),artifacts=[],captures=[],
    production_gate_credit=False, mckernel_boot_proven=False, declared_stage=False,
    mckernel_arch_entry_proven=True, initial_bidirectional_ikc_proven=True,
    control_listener_connections_proven=True, vdso_request_delivered=True, vdso_service_completed=False,
    passed=[
        'Both exact boot-layout witnesses and all three native prototype modules pass compilation and ELF/no-SIMD checks in attempt 4',
        'The existing master ring is the bounded IRQ-to-process handoff; the callback only signals and all channel allocation and routing occur in serialized BOOT process context',
        'Revision-2 master replies use the existing producer body with a nonblocking local producer claim',
        'Both ABIs across two module lifetimes pass preparation, 32 forced allocation failures, four physical captures and full unstarted memory/CPU/module restoration',
        'Actual native and compat boots each accept ports 501 and 503 using the existing listener/accept policy and generation-owned host receive pages',
        'Independent QMP captures verify all four 16 KiB regular queue mappings, disjointness, geometry, CPU/channel metadata and exact CONNECT/CONNECT_REPLY fields',
        'Master receive counters reach (2,2,2), master send counters reach (3,3,3), and the port-503 receive queue consumes its first real 128-byte SCD request',
        'McKernel reports both channels connected and sends SCD_MSG_GET_VDSO_INFO through real Linux IRQ-work',
        'The request argument lies in the assigned memory and its complete 88-byte descriptor remains busy=1 with a zeroed remainder while awaiting actual host service',
        'Incomplete BOOT remains Failed with all started owners retained; argument/resource changes, destruction and module removal remain rejected after close'],
    limitations=[
        'The first module build failed an unused retained receive-address field; the fix uses that identity in accepted-channel overlap checks rather than suppressing the warning',
        'The first actual-start capture passed queue/wire/physical checks but failed a log assertion that omitted the prefix inserted by each kprintf; its normal and emergency snapshots are retained',
        'vDSO service, subsequent sysfs/mcctrl work, full status 3 and applications remain unfinished',
        'The BOOT process services the initial connections; asynchronous runtime dispatch and native shutdown/drain/restoration remain open',
        'Current host IRQ service is pinned to Linux CPU 0; additional supported routing modes and broader workloads remain pending',
        'Declared staging, lifecycle/unsafe-FFI/license contracts and downstream source bindings remain pending for current boot/IKC sources',
        'The earlier full suite predates boot/IKC integration; the intermittent Linux idle/RCU stall and additional platform/performance capabilities remain open',
        'Full McKernel and linked-support Rust/assembly completion and independent production acceptance remain required'])

def add(path,name):
    target=out/name
    with path.open('rb') as source,target.open('xb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
            for data in iter(lambda:source.read(1<<20),b''): stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/'+name,source=str(path),size=target.stat().st_size,sha256=digest(target),unpacked_size=path.stat().st_size,unpacked_sha256=digest(path)))
for name in ['native-ikc-prototype-20260907-3','native-ikc-prototype-20260907-4',
             'native-control-guest-20260907-prepare-1',
             'native-control-guest-20260907-start-x86_64-1','native-control-guest-20260907-start-x86_64-2',
             'native-control-guest-20260907-start-i386-1']:
    path=work/name; metadata=json.loads((path/'record.json').read_text())
    assert metadata['status']==('FAIL' if name in ('native-ikc-prototype-20260907-3','native-control-guest-20260907-start-x86_64-1') else 'PASS'),name
    rows=metadata.get('inputs',[])+metadata.get('outputs',[])
    for capture in metadata.get('captures',[]): rows+=capture.get('artifacts',[])
    for row in rows:
        item=Path(row['path']); assert item.stat().st_size==row['size'] and digest(item)==row['sha256'],item
    record['captures'].append(dict(directory=name,status=metadata['status'],source_parent=metadata.get('source_parent'),started_utc=metadata.get('started_utc'),finished_utc=metadata.get('finished_utc')))
    target=out/(name+'.tar.gz')
    with tarfile.open(target,'w:gz') as archive: archive.add(path,arcname=name)
    assert target.stat().st_size < 95<<20,target
    record['artifacts'].append(dict(path='docs/verification/evidence/'+target.name,source=str(path),size=target.stat().st_size,sha256=digest(target)))
    for short in ('record.json','serial.log','debugcon.log'):
        if (path/short).exists(): add(path/short,name+'-'+short+'.gz')
for name in ('build-native-ikc-prototype.py','run-native-control-guest.py','retain-native-control-channels.py'):
    add(work/name,'native-control-channels-20260907-'+name+'.gz')
stage=work/'native-ikc-prototype-20260907-4/staged-source'
record['current_compiler_inputs']=[]
for path in sorted(stage.rglob('*')):
    if not path.is_file() or path.suffix not in ('.rs','.S'): continue
    relative='host-kernel/native-rust/'+str(path.relative_to(stage)); current=repo/relative
    row=dict(path=relative,size=current.stat().st_size,sha256=digest(current),compiler_size=path.stat().st_size,compiler_sha256=digest(path),transform='none')
    if current.read_bytes()!=path.read_bytes():
        assert path.suffix=='.rs',relative
        formatted=out/('formatted-'+path.name); formatted.write_bytes(current.read_bytes())
        command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(formatted)]
        subprocess.run(command,check=True); assert formatted.read_bytes()==path.read_bytes(),relative
        row['transform']=command[:-1]; add(current,'native-control-channels-20260907-unformatted-'+path.name+'.gz')
    record['current_compiler_inputs'].append(row)
record['current_compiler_input_count']=len(record['current_compiler_inputs'])
for relative in ('scripts/native-boot-init.sh','scripts/tests/fixtures/native-boot.c','scripts/tests/fixtures/native_smp_boot_layout.c','host-kernel/kbuild/patches/0007-rust-bindings-expose-x86-apic-driver.patch'):
    path=repo/relative; record.setdefault('source_inputs',[]).append(dict(path=relative,size=path.stat().st_size,sha256=digest(path)))
reference=repo/'docs/verification/native-ikc-completion-checkpoint-20260907.json'
record['previous_boot_reference']=dict(path=str(reference.relative_to(repo)),size=reference.stat().st_size,sha256=digest(reference))
for row in record['artifacts']:
    size=0; unpacked=hashlib.sha256()
    with gzip.open(out/Path(row['path']).name,'rb') as stream:
        for data in iter(lambda:stream.read(1<<20),b''): size+=len(data); unpacked.update(data)
    if 'unpacked_sha256' in row: assert size==row['unpacked_size'] and unpacked.hexdigest()==row['unpacked_sha256']
(out/'native-control-channels-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained and verified',len(record['artifacts']),'native control-channel artifacts; vDSO/full boot remain open',flush=True)
