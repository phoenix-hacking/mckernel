#[cfg(test)]
pub(crate) mod fixture {
    use std::ptr::NonNull;
    use std::sync::{Arc, Mutex};
    #[derive(Clone, Copy, Debug, Eq, PartialEq)]
    pub enum Event { Construct, Baseline, Release, Deferred, FinishedDrop, UnfinishedDrop, Quarantine, Deallocate }
    pub struct State { pub deferred: Vec<Box<Backing>>, pub quarantine: Vec<Box<Backing>>, pub events: Vec<Event> }
    pub struct Ledger { pub state: Mutex<State> }
    impl Ledger { pub fn new() -> Arc<Self> { Arc::new(Self { state: Mutex::new(State { deferred: Vec::with_capacity(1), quarantine: Vec::with_capacity(1), events: Vec::with_capacity(9) }) }) } pub fn record(&self,e:Event){self.state.lock().unwrap().events.push(e)} pub fn snapshot(&self)->Vec<Event>{self.state.lock().unwrap().events.clone()} pub fn drain(&self,q:bool){let b={let mut s=self.state.lock().unwrap();if q{std::mem::take(&mut s.quarantine)}else{std::mem::take(&mut s.deferred)}};let n=b.len();drop(b);for _ in 0..n{self.record(Event::Deallocate)}} }
    #[repr(align(8))] pub struct Backing { pub bytes: [u8;56] }
    pub struct TestResponseMemory { pub backing: Option<Box<Backing>>, span: NonNull<u8>, ledger: Arc<Ledger>, released: bool }
    impl TestResponseMemory { pub fn new(ledger:Arc<Ledger>)->Self{let mut b=Box::new(Backing{bytes:[0;56]});let span=NonNull::new(unsafe{b.bytes.as_mut_ptr().add(8)}).unwrap();ledger.record(Event::Construct);Self{backing:Some(b),span,ledger,released:false}} pub fn baseline(&self){self.ledger.record(Event::Baseline)} pub fn ledger(&self)->Arc<Ledger>{self.ledger.clone()} pub fn verification_owner(&self)->Option<crate::stability_observer::Claim>{Some(crate::stability_observer::Claim{os:1,generation:1,response:crate::stability_observer::Tag{index:0,serial:Some(1),physical:0x1000,end:0x1028},payload:None})} }
    unsafe impl super::super::application_syscall::ResponseMemory for TestResponseMemory { fn verification_owner(&self)->Option<crate::stability_observer::Claim>{self.verification_owner()} fn physical(&self)->u64{0x1000} fn address(&mut self)->*mut u8{self.span.as_ptr()} unsafe fn release(mut self){if self.released{return}self.released=true;self.ledger.record(Event::Release);let b=self.backing.take().unwrap();self.ledger.state.lock().unwrap().deferred.push(b);self.ledger.record(Event::Deferred)}}
    impl Drop for TestResponseMemory { fn drop(&mut self){if self.released{self.ledger.record(Event::FinishedDrop)}else{let b=self.backing.take().unwrap();self.ledger.state.lock().unwrap().quarantine.push(b);self.ledger.record(Event::UnfinishedDrop);self.ledger.record(Event::Quarantine)}} }
    pub fn request()->crate::application_syscall::Request{let mut b=[0u8;128];b[8..12].copy_from_slice(&4i32.to_le_bytes());b[32..36].copy_from_slice(&70i32.to_le_bytes());b[48..52].copy_from_slice(&70i32.to_le_bytes());b[56..64].copy_from_slice(&1u64.to_le_bytes());b[80..88].copy_from_slice(&0x2000u64.to_le_bytes());b[88..96].copy_from_slice(&16u64.to_le_bytes());b[120..128].copy_from_slice(&0x1000u64.to_le_bytes());crate::application_syscall::Request::decode(&b,1).expect("request")}
}
