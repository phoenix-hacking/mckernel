#[path = "../mode2/adapter.rs"] mod shared;
pub(crate) use shared::fixture;
