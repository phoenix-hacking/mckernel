from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
architecture, module_attempt, attempt = sys.argv[1:]
image_attempt, profile = "2", "normal"
assert profile in ('verify', 'normal')
assert architecture in ('x86_64', 'i386')
repo = Path('/workspace')
compiled = Path('/work/native-mcctrl-service-module-20260908-' + module_attempt)
substrate = Path('/work/native-sysfs-setup-module-20260907-1')
images = Path('/work/mckernel-native-sysfs-images-20260908-' + image_attempt)
out = Path('/work/native-mcctrl-service-guest-20260908-' + architecture + '-' + attempt)
out.mkdir()
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
              architecture=architecture, profile=profile, controller_abi='x86_64' if profile == 'verify' else None, inputs=[], commands=[], captures=[],
              cpuset=sorted(os.sched_getaffinity(0)), cpus=4, guest_cpus=1,
              numa_nodes=2, memory_mib=8192, container_memory_mib=12288,
              applications_tested=False, production_gate_credit=False,
              full_ready_observed=False, sysfs_service_completed=False)
process = None
stream = None
sequence = 0

def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), size=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save():
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')

def run(label, command):
    print('RUN',label,flush=True)
    with (out/(label+'.log')).open('wb') as log:
        result = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=command,exit_code=result.returncode))
    assert result.returncode == 0,(label,(out/(label+'.log')).read_text()[-10000:])

def qmp(command, arguments=None):
    global sequence
    sequence += 1
    request = dict(execute=command,id=sequence)
    if arguments is not None: request['arguments'] = arguments
    stream.write((json.dumps(request)+'\n').encode());stream.flush()
    while True:
        raw = stream.readline();assert raw,'QMP disconnected'
        result = json.loads(raw)
        if result.get('id') != sequence: continue
        assert 'error' not in result,result
        return result['return']

def dump(physical, length, target):
    assert 0 < physical < physical + length <= 256 << 30 and 0 < length <= 4 << 20
    result = qmp('human-monitor-command',dict(**{'command-line':'pmemsave 0x%x %d "%s"' % (physical,length,target)}))
    assert result == '' and target.stat().st_size == length,(result,target)
    return target.read_bytes()

def capture(serial, index, validate=True):
    pattern = r'IHK-SMP: boot prepared os=(\d+) generation=(\d+) params=([0-9a-f]+) bytes=(\d+) trampoline=([0-9a-f]+) startup=([0-9a-f]+) cpus=(\d+) numa=(\d+) chunks=(\d+) kmsg=([0-9a-f]+)'
    matches = re.findall(pattern,serial);assert matches,'No prepared boot to capture'
    values = matches[-1]
    os_id,generation = map(int,values[:2]);params=int(values[2],16);length=int(values[3]);kmsg=int(values[9],16)
    assert os_id == 0 and 7616 <= length <= 4 << 20
    target=out/('capture-'+str(index));target.mkdir()
    qmp('stop')
    try:
        data=dump(params,length,target/'params.bin')
        kmsg_data=dump(kmsg,4<<20,target/'kmsg.bin')
        (target/'registers.txt').write_text(qmp('human-monitor-command',{'command-line':'info registers -a'}))
        (target/'cpus.json').write_text(json.dumps(qmp('query-cpus-fast'),indent=2)+'\n')
        status=struct.unpack_from('<Q',data,16)[0]
        ncpus,nnodes,nchunks=struct.unpack_from('<III',data,6608)
        assert 0 < ncpus <= 512 and 0 < nnodes <= 1024 and 0 < nchunks <= 4096
        chunk_offset=7616+ncpus*16+nnodes*8
        assert chunk_offset+nchunks*24 <= len(data)
        chunks=[struct.unpack_from('<QQi4x',data,chunk_offset+i*24) for i in range(nchunks)]
        master=[]
        for offset,name in ((56,'receive'),(64,'send')):
            physical=struct.unpack_from('<Q',data,offset)[0]
            if physical:
                raw=dump(physical,4096,target/('master-'+name+'.bin'))
                master.append(dict(name=name,physical=physical,counters=list(struct.unpack_from('<4Q',raw,16))))
        pattern=(r'IHK-SMP: control accepted os=0 generation='+str(generation)+r' port=(\d+) guest_cpu=(\d+) linux_cpu=(\d+) cookie=(\d+) receive=([0-9a-f]+) send=([0-9a-f]+) bytes=(\d+) reference=(\d+) remote_cookie=([0-9a-f]+)')
        rows={}
        for values in re.findall(pattern,serial):
            names=('port','guest_cpu','linux_cpu','cookie','receive','send','bytes','reference','remote_cookie')
            row=dict(zip(names,[int(v,16 if i in (4,5,8) else 10) for i,v in enumerate(values)]))
            key=(row['port'],row['cookie']);assert key not in rows or rows[key]==row
            rows[key]=row
        queues=[]
        for row in rows.values():
            for direction in ('receive','send'):
                raw=dump(row[direction],row['bytes'],target/('control-%d-%s.bin'%(row['port'],direction)))
                queues.append(dict(port=row['port'],direction=direction,physical=row[direction],bytes=row['bytes'],
                                   header=list(struct.unpack_from('<IHHI',raw)),
                                   counters=list(struct.unpack_from('<4Q',raw,16))))
        lock,tail,capacity,head=struct.unpack_from('<4I',kmsg_data)
        assert capacity == (4<<20)-4096 and 0 <= head <= tail < capacity
        messages=kmsg_data[4096+head:4096+tail].decode(errors='replace')
        (target/'kmsg.txt').write_text(messages)
        result=dict(directory=str(target),status=status,owner=dict(slot=os_id,generation=generation),
                    chunks=chunks,master=master,queues=queues,validated=validate)
        if validate:
            assert status == 3,('Full guest readiness missing',status)
            assert (ncpus,nnodes)==(1,1)
            assert sum(end-start for start,end,node in chunks)==128<<20
            assert all(start<end and start%4096==end%4096==0 and node==0 for start,end,node in chunks)
            assert 'IHK/McKernel booted.' in messages and 'panic' not in messages.lower(),messages[-2500:]
            assert len(master)==2 and master[0]['counters']==[2,2,2,4032] and master[1]['counters']==[3,3,3,4032],master
            assert {row['port'] for row in rows.values()}=={501,503} and len(rows)==2,rows
            spans=[(row['physical'],row['physical']+4096) for row in master]
            for row in queues:
                assert row['header']==[1,row['port'],128,127],row
                read,published,reserved,maximum=row['counters']
                assert read==published==reserved and maximum==16256,row
                begin,end=row['physical'],row['physical']+row['bytes']
                assert not any(begin<stop and start<end for start,stop in spans)
                spans.append((begin,end))
                if row['direction']=='send': assert any(start<=begin<end<=stop for start,stop,node in chunks),row
                else: assert not any(begin<stop and start<end for start,stop,node in chunks),row
            meta=re.findall(r'IHK-SMP: sysfs metadata os=0 generation='+str(generation)+r' sequence=(\d+) operation=(.*?) path=(\S+) errno=(-?\d+)',serial)
            assert meta and [int(row[0]) for row in meta]==list(range(1,len(meta)+1)),meta
            if profile == 'verify':
                assert len(meta) == 52, meta
                expected_errors = [
                    ('mkdir', '/sys/test/native', -17),
                    ('unlink', '/sys', -1),
                    ('symlink', '/sys/test/native/link', -17),
                    ('lookup', '/sys/test/native/temporary/leaf', -2),
                    ('lookup', '/sys/test/native/temporary', -2),
                    ('symlink', '/sys/test/native/stale-prefix/link', -2),
                    ('lookup', '/sys/test/native/stale-prefix', -2),
                    ('create', '/sys/test/native/items/value0', -17),
                    ('lookup', '/sys/test/native/items', -2),
                ]
                actual_errors = [(kind.split()[0].lower(), path, int(error)) for _, kind, path, error in meta if int(error)]
                assert actual_errors == expected_errors, actual_errors
                assert Counter(row[1].split()[0].lower() for row in meta) == dict(create=24, mkdir=4, lookup=7, symlink=5, unlink=12)
                marker = re.findall(r'NATIVE_GUEST_SYSFS PASS metadata=(\d+) releases=(\d+) forbidden=(\d+) value_reads=(\d+) value_stores=(\d+)', messages)
                assert marker == [('37','8','0','260','256')], marker
                result['guest_fixture'] = dict(metadata=37, releases=8, forbidden_releases=0, value_reads=260, value_stores=256)
            else:
                assert len(meta) == 7 and all(int(row[3]) == 0 for row in meta), meta
                assert 'NATIVE_GUEST_SYSFS' not in messages
            ready = re.findall(r'IHK-SMP: full guest ready os=0 generation='+str(generation)+r' status=3 sysfs_requests=(\d+) continuing_workers=2', serial)
            assert ready == [str(len(meta))], ready
            counter = lambda port, direction: next(q['counters'][0] for q in queues if q['port'] == port and q['direction'] == direction)
            assert counter(503, 'receive') - counter(501, 'send') == len(meta) + 2
            result['pre_ready_callbacks'] = counter(501, 'send') if index == 0 else None
            if profile == 'verify': assert counter(501, 'send') >= 540
            assert meta[0][2]=='/sys/devices/system/cpu/num_processors',meta[0]
            result['metadata']=meta
        result['artifacts']=[identity(p) for p in sorted(target.iterdir()) if p.is_file()]
        record['captures'].append(result);save()
        print('CAPTURE',index,'status',status,'validated',validate,flush=True)
    finally:
        if validate:qmp('cont')

try:
    shutil.copyfile(__file__,out/'helper.py')
    built=json.loads((compiled/'record.json').read_text());assert built['status']=='PASS'
    for row in built['outputs']:assert identity(Path(row['path']))==row,row
    witness=json.loads((substrate/'record.json').read_text());assert witness['status']=='PASS'
    binding=substrate/'bindings_generated.rs'
    assert [r for r in witness['outputs'] if r['path']==str(binding)]==[identity(binding)]
    record['inputs'] += [identity(compiled/'record.json'),identity(substrate/'record.json'),identity(binding)]
    root=out/'root';shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'),root)
    init='''#!/bin/bash
set -euo pipefail
[ "$$" -eq 1 ] && [ "$EUID" -eq 0 ] || exit 125
export PATH=/bin:/sbin:/usr/bin:/usr/sbin LANG=C LC_ALL=C
exec </dev/console >/dev/console 2>&1
finish() { local status=$?; trap - EXIT; if [ "$status" -ne 0 ]; then printf 'NATIVE_SERVICE_GUEST FAIL status=%s\\n' "$status"; fi; /bin/dmesg || true; /poweroff; }
trap finish EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t debugfs debugfs /sys/kernel/debug
printf '7\\n' >/proc/sys/kernel/printk
read -r online </sys/devices/system/cpu/online
read -r nodes </sys/devices/system/node/online
[ "$online" = 0-3 ] && [ "$nodes" = 0-1 ]
insmod /modules/ihk.ko
insmod /modules/ihk-smp-x86_64.ko ihk_trampoline=524288
insmod /modules/mcctrl.ko
/bin/native-boot
rmmod mcctrl
/bin/native-mcctrl-service
base=/sys/class/mcos/mcos0/sys
[ "$base/bus/cpu/devices/cpu0" -ef "$base/devices/system/cpu/cpu0" ]
[ "$base/bus/cpu/drivers/processor/cpu0" -ef "$base/devices/system/cpu/cpu0" ]
printf 'NATIVE_SERVICE_GUEST PASS ready=1 cpu_links=2 restoration_proven=0 applications=0\\n'
'''
    if profile == 'verify':
        init = init.replace('/bin/native-boot\n', '/bin/native-guest-sysfs &\nhelper_pid=$!\n/bin/native-boot\nwait "$helper_pid"\n')
    (root/'init').write_text(init);(root/'init').chmod(0o755)
    run('shell-syntax',['bash','-n',str(root/'init')])
    for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko'):
        shutil.copyfile(compiled/name,root/'modules'/name);record['inputs'].append(identity(compiled/name))
    probe=out/'probe-source';probe.mkdir()
    for name in ('native-boot.c','native-os-resource-assignment.c','native-memory-reservation.c','native-cpu-reservation.c','native-mcctrl-service.c'):
        shutil.copyfile(repo/'scripts/tests/fixtures'/name,probe/name)
    states=re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);',binding.read_text());assert len(states)==1
    bits=64 if architecture=='x86_64' else 32
    run('probe-build',['cc','-m'+str(bits),'-O2','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-pie','-nostdlib','-static','-no-pie','-Wl,-e,_start','-Wl,-z,noexecstack','-DCPUHP_FAILURE_STATE='+states[0],'-DNATIVE_VDSO_REV3=1','-DNATIVE_SYSFS_OS=1','-DNATIVE_SYSFS_SETUP=1','-DNATIVE_SYSFS_SERVICE=1','-DNATIVE_MCCTRL_SERVICE=1','-DBOOT_PREPARE_ONLY=0',str(probe/'native-boot.c'),'-o',str(root/'bin/native-boot')])
    service_cmd=list(record['commands'][-1]['command'])
    service_cmd[service_cmd.index(str(probe/'native-boot.c'))]=str(probe/'native-mcctrl-service.c')
    service_cmd[-1]=str(root/'bin/native-mcctrl-service')
    run('service-probe-build',service_cmd)
    if profile == 'verify':
        controller = probe / 'native-guest-sysfs.c'
        shutil.copyfile(repo / 'scripts/tests/fixtures/native-guest-sysfs.c', controller)
        run('controller-build', ['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-pthread',str(controller),'-o',str(root/'bin/native-guest-sysfs')])
        run('controller-dependencies', ['ldd', str(root/'bin/native-guest-sysfs')])
        dependencies = (out/'controller-dependencies.log').read_text()
        assert 'libc.so.6' in dependencies and 'ld-linux-x86-64.so.2' in dependencies
        for name in ('libc.so.6','ld-linux-x86-64.so.2'):
            destination = root / 'lib64' / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(Path('/lib64') / name, destination)
            record['inputs'].append(identity(destination))
    image_record = json.loads((images/'record.json').read_text())
    assert image_record['status'] == 'PASS'
    kind = 'native-sysfs-verify' if profile == 'verify' else 'native-rust'
    selected = [row for row in image_record['images'] if row['kind'] == kind]
    assert len(selected) == 1 and selected[0]['native_sysfs_verify'] == (profile == 'verify')
    for row in selected[0]['outputs']: assert identity(Path(row['path'])) == row, row
    record['inputs'].append(identity(images/'record.json'))
    image = images / kind / 'kernel/mckernel.img'
    assert identity(image) in selected[0]['outputs']
    assert (b'NATIVE_GUEST_SYSFS PASS' in image.read_bytes()) == (profile == 'verify')
    (root/'images').mkdir();shutil.copyfile(image,root/'images/mckernel.img')
    environment=dict(os.environ,RUNTIME_EVIDENCE=str(out),INITRAMFS_ROOT=str(root))
    subprocess.run(['python3','-B','/work/write-native-cpio-spec.py'],env=environment,check=True)
    with (out/'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as target:
            generator=subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio','-t','0',str(out/'initramfs.list')],stdout=subprocess.PIPE)
            shutil.copyfileobj(generator.stdout,target);generator.stdout.close();assert generator.wait()==0
    record['inputs'] += [identity(p) for p in sorted(probe.iterdir())]
    record['inputs'] += [identity(p) for p in (image,compiled/'bzImage',root/'init',out/'initramfs.cpio.gz',Path('/work/write-native-cpio-spec.py'))]
    args=['/usr/libexec/qemu-kvm','-machine','q35','-accel','tcg,thread=multi','-cpu','max,la57=off','-smp','4,sockets=2,cores=2,threads=1','-m','8192',
          '-object','memory-backend-ram,size=4G,id=ram-node0','-object','memory-backend-ram,size=4G,id=ram-node1',
          '-numa','node,nodeid=0,cpus=0-1,memdev=ram-node0','-numa','node,nodeid=1,cpus=2-3,memdev=ram-node1',
          '-kernel',str(compiled/'bzImage'),'-initrd',str(out/'initramfs.cpio.gz'),
          '-append','console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
          '-qmp','unix:'+str(out/'qmp.sock')+',server=on,wait=off','-monitor','none','-serial','file:'+str(out/'serial.log'),
          '-debugcon','file:'+str(out/'debugcon.log'),'-global','isa-debugcon.iobase=0xe9','-display','none','-no-reboot','-no-shutdown','-nic','none']
    record['qemu_args']=args;save()
    with (out/'qemu.log').open('wb') as log:
        process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+600
        while not (out/'qmp.sock').exists():
            assert process.poll() is None and time.monotonic()<deadline;time.sleep(0.05)
        connection=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);connection.settimeout(20);connection.connect(str(out/'qmp.sock'))
        stream=connection.makefile('rwb');assert 'QMP' in json.loads(stream.readline());qmp('qmp_capabilities')
        seen=0
        while process.poll() is None:
            assert time.monotonic()<deadline,'Guest timeout'
            serial=(out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
            for bad in ('NATIVE_SERVICE_GUEST FAIL','NATIVE_GUEST_SYSFS_USER FAIL',' FAIL line=','Kernel panic','BUG:','Oops:','WARNING:','rcu_preempt detected stalls','soft lockup','hard LOCKUP','continuing service error'):
                assert bad not in serial,bad
            ready=serial.count('NATIVE_BOOT_CAPTURE '+architecture+' ready')
            if ready>seen:
                assert ready==seen+1 and ready<=2
                capture(serial,seen);seen+=1
            state=qmp('query-status')
            if state['status'] in ('shutdown','guest-panicked'):
                record['terminal_vm_state']=state
                assert 'NATIVE_SERVICE_GUEST PASS ready=1 cpu_links=2 restoration_proven=0 applications=0' in serial,state
                qmp('quit');process.wait(timeout=15);break
            time.sleep(0.1)
        assert process.returncode==0,process.returncode
    serial=(out/'serial.log').read_text(errors='replace')
    assert 'NATIVE_MCCTRL_PREREADY '+architecture+' PASS rejected=2' in serial
    marker='NATIVE_MCCTRL_SERVICE '+architecture+' PASS cycles=2 workers=8 topology_queries=1056 contexts=4 unload_vetoes=8 absent=6 unsupported=2 applications=0'
    assert marker in serial, serial[-10000:]
    # dmesg is printed once at exit, so use only the first console copy.
    before_summary=serial[:serial.index(marker)]
    assert before_summary.count('mcctrl: application_file=open os=0 generation=') == 4
    assert before_summary.count('mcctrl: application_file=close os=0 generation=') == 4
    assert before_summary.count('mcctrl: application_service=registered abi=1') == 5
    assert before_summary.count('mcctrl: application_service=unregistered abi=1') == 5
    record['mcctrl_service'] = dict(topology_queries=1056, contexts=4, workers=8, cycles=2, unload_vetoes=8, absent_rejections=6, unsupported_rejections=2, pre_ready_rejections=2, module_loads=5, module_unloads=5, application_execution=False)
    assert len(record['captures'])==2
    assert 'NATIVE_BOOT_SERVICE '+architecture+' boot_errno=0' in serial
    assert 'NATIVE_BOOT_START '+architecture+' CAPTURED ready=1 resources_retained=1' in serial
    assert 'NATIVE_SYSFS_SERVICE '+architecture+' PASS read_checks=66 store_checks=64 rounds=32' in serial
    first,last=record['captures']
    counters=lambda capture,port,direction:next(q['counters'][0] for q in capture['queues'] if q['port']==port and q['direction']==direction)
    sent=counters(last,501,'send')-counters(first,501,'send')
    received=counters(last,503,'receive')-counters(first,503,'receive')
    assert sent == received == 130, (sent, received)
    marker = 'NATIVE_GUEST_SYSFS_USER PASS special_reads=9 value_reads=260 value_stores=256 remote_releases=8 callback_errors=6 snoop_store_errors=1 full_read=4095 full_store=4096'
    if profile == 'verify':
        assert serial.count(marker) == 1
        record['actual_guest_fixture'] = dict(special_reads=9, value_reads=260, value_stores=256,
            remote_releases=8, callback_errors=6, snoop_store_errors=1, full_read=4095, full_store=4096,
            metadata_requests=52, expected_metadata_errors=9, fixture_namespace_retired=True,
            pre_ready_callback_exchanges=first['pre_ready_callbacks'])
    else:
        assert 'NATIVE_GUEST_SYSFS_USER' not in serial
    guest_log = (Path(last['directory']) / 'kmsg.txt').read_text()
    delivered = re.findall(r'NYI:store_fake_cpu_info\([^\n]*\): online 1 --> "(.*?)"', guest_log, re.S)
    assert delivered == ['0\n', '1\n'] * 32, (len(delivered), delivered[:6])
    record['guest_store_payload_checks'] = len(delivered)
    record['guest_online_store_semantics'] = 'Existing NYI callback logs input and acknowledges count without changing online or Linux CPU state'
    for row in record['inputs']:assert identity(Path(row['path']))==row,row
    record.update(status='PASS',full_ready_observed=True,boot_sysfs_sequence_completed=True,
                  boot_ioctl=0,registry_status=4,physical_status=3,read_checks=66,store_checks=64,rounds=32,
                  observed_callback_exchanges=sent,sysfs_namespace_checks=2,cpu_links=2,
                  scope='Actual native mcctrl file service, assigned-topology ioctls, concurrent attachment and module lifetime; existing normal-image boot and continuing sysfs regression. Application execution, full staging integration and shutdown remain open')
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    if stream is not None and process is not None and process.poll() is None:
        try:
            serial=(out/'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:capture(serial,'emergency',validate=False)
        except BaseException as capture_error:record['emergency_capture_error']=str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:process.wait(timeout=15)
        except subprocess.TimeoutExpired:process.kill();process.wait()
    if stream is not None:stream.close()
    record['qemu_exit_code']=None if process is None else process.returncode
    record['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    print(record['status'],out,flush=True)
