import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path

HERE = Path(__file__).resolve().parent / "fixtures/native-lifecycle-model-v1"
FILES = {"README.md", "model.rs", "reference.c", "vectors.json", "expected.json", "harness.py"}
REQUIRED = {
    "preparation-abort", "assigned-tid-abort", "late-clone-abort", "immediate-exit",
    "tid-reuse", "thread-only-exit", "last-thread-exit", "competing-group-orders",
    "inherited-status", "duplicate-terminal", "retained-thread-ref",
    "retained-process-ref", "authority-revoked",
    "ref-resurrection", "zombie-before-after-reap",
    "main-storage-held", "live-sibling-retirement", "vm-held", "launcher-loss",
    "teardown-failure", "buffer-full", "counter-overflow", "attempt-counter-overflow",
    "unfinished-reservation",
    "missing-birth", "missing-end", "active-tid-alias",
    "birth-after-runnable",
    "wrong-raw-terminal", "wrong-capture", "wrong-os-generation",
    "wrong-application", "wrong-process", "wrong-exec", "wrong-domain",
    "application-limit", "process-limit", "thread-limit",
}
RAW_ORIGINAL_REQUIRED = {
    "raw-duplicate-key", "raw-nonfinite", "raw-trailing-object",
    "raw-embedded-nul", "raw-129-operations", "raw-oversized-document",
    "raw-unknown-pool", "raw-cyclic-pool", "raw-excess-pool-args",
}
RAW_AUTHORITY_REQUIRED = {
    "raw-authority-retire-a", "raw-authority-retire-b",
    "raw-authority-retire-c", "raw-authority-retire-d",
    "raw-authority-extra-operation-field",
    "raw-authority-extra-vector-field", "raw-authority-unknown-operation",
}
RAW_WIDTH_REQUIRED = {
    "raw-pid-zero", "raw-pid-int32-overflow", "raw-pid-negative",
    "raw-pid-u64-overflow", "raw-pid-integral-float",
    "raw-pid-fractional-float", "raw-pid-boolean", "raw-pid-string",
    "raw-pid-null", "raw-tid-alloc-int32-overflow",
    "raw-tid-assign-zero", "raw-tid-assign-int32-overflow",
}
RAW_DOCUMENT_REQUIRED = {
    "raw-json-truncated", "raw-document-nonobject", "raw-top-missing-field",
    "raw-top-unknown-field", "raw-schema-version-wrong",
    "raw-schema-version-boolean", "raw-schema-version-integral-float",
    "raw-model-only-false", "raw-model-only-integer",
    "raw-corpus-complete-nonboolean", "raw-vectors-nonarray",
    "raw-vector-nonobject", "raw-vector-missing-field",
    "raw-vector-name-empty", "raw-vector-name-nonstring",
    "raw-vector-name-duplicate", "raw-coverage-nonarray",
    "raw-coverage-empty", "raw-coverage-nonstring",
    "raw-coverage-empty-string", "raw-coverage-duplicate",
    "raw-seed-unknown", "raw-seed-nonstring", "raw-operations-nonarray",
    "raw-operations-empty", "raw-operation-nonarray", "raw-operation-short",
    "raw-operation-nonstring-name", "raw-id-zero", "raw-id-gap",
}
RAW_KEY_DOMAIN_REQUIRED = {
    "raw-key-capture-zero", "raw-key-os-generation-zero",
    "raw-key-application-zero", "raw-key-process-zero", "raw-key-exec-zero",
    "raw-key-slot-negative", "raw-key-slot-u64-overflow",
    "raw-key-slot-boolean", "raw-key-slot-fractional",
    "raw-key-slot-string", "raw-key-slot-null",
    "raw-process-subject-thread-domain", "raw-thread-subject-process-domain",
    "raw-subject-null", "raw-subject-scalar", "raw-subject-short",
    "raw-subject-long", "raw-thread-parent-null", "raw-thread-parent-scalar",
    "raw-thread-parent-short", "raw-thread-parent-long",
    "raw-thread-parent-thread-domain", "raw-process-unexpected-parent",
    "raw-tid-assign-unexpected-parent", "raw-capture-subject",
    "raw-capture-parent", "raw-capacity-boolean", "raw-capacity-overflow",
    "raw-abort-stage-zero", "raw-abort-stage-overflow",
}
RAW_POOL_REQUIRED = {
    "raw-pool-map-array", "raw-pool-empty-definition-name",
    "raw-pool-reference-missing-field", "raw-pool-reference-extra-field",
    "raw-pool-reference-name-integer", "raw-pool-args-null",
    "raw-pool-required-args-omitted", "raw-pool-nonzero-arity-excess",
    "raw-pool-placeholder-negative", "raw-pool-placeholder-boolean",
    "raw-pool-placeholder-integral-float", "raw-pool-placeholder-string",
    "raw-pool-placeholder-extra-field", "raw-pool-placeholder-unbound",
    "raw-pool-unused-unknown-reference", "raw-pool-unused-self-cycle",
    "raw-pool-unused-arity-excess", "raw-pool-unused-mutual-cycle",
    "raw-pool-unused-dependency-33-leaf-first",
    "raw-pool-unused-dependency-33-root-first",
    "raw-pool-unused-syntax-depth-33", "raw-pool-expanded-byte-budget-over",
}
RAW_ENVELOPE_REQUIRED = {
    "raw-raw-invalid-nonarray", "raw-mutants-nonobject",
    "raw-nested-raw-invalid",
}
RAW_OPERATION_ARGUMENT_REQUIRED = {
    "raw-operation-id-overflow", "raw-operation-id-fractional",
    "raw-main-flag-overflow", "raw-terminal-raw-overflow",
    "raw-terminal-status-overflow", "raw-terminal-signal-overflow",
    "raw-terminal-branch-zero", "raw-terminal-branch-overflow",
    "raw-unused-p-alloc-b", "raw-unused-p-alloc-c", "raw-unused-p-alloc-d",
    "raw-unused-t-alloc-c", "raw-unused-t-alloc-d",
    "raw-unused-tid-assign-b", "raw-unused-tid-assign-c",
    "raw-unused-tid-assign-d", "raw-unused-abort-b",
    "raw-unused-abort-c", "raw-unused-abort-d",
}
RAW_REQUIRED = (RAW_ORIGINAL_REQUIRED | RAW_AUTHORITY_REQUIRED |
                RAW_WIDTH_REQUIRED | RAW_DOCUMENT_REQUIRED |
                RAW_KEY_DOMAIN_REQUIRED | RAW_POOL_REQUIRED |
                RAW_ENVELOPE_REQUIRED | RAW_OPERATION_ARGUMENT_REQUIRED)
RAW_ACCEPTED_28_TEXT_SHA256 = "ad5400098498a5805691e0017f15152f75a540812c6f6cd67fd2318c3abd39c4"

class NativeLifecycleModelSourceTests(unittest.TestCase):
    def test_exact_packet_and_labels(self):
        self.assertEqual({path.name for path in HERE.iterdir() if path.is_file()}, FILES)
        for name in ("README.md", "model.rs", "reference.c", "harness.py"):
            self.assertIn("MODEL_ONLY", (HERE / name).read_text())

    def test_python_syntax_and_named_coverage(self):
        ast.parse((HERE / "harness.py").read_text())
        vectors = json.loads((HERE / "vectors.json").read_text())
        expected = json.loads((HERE / "expected.json").read_text())
        self.assertEqual(vectors["schema_version"], 2)
        self.assertTrue(vectors["model_only"] and expected["model_only"])
        names = {vector["name"] for vector in vectors["vectors"]}
        self.assertTrue(names <= REQUIRED)
        if vectors["corpus_complete"]:
            self.assertEqual(names, REQUIRED)
        else:
            self.assertIn("immediate-exit", names)
        self.assertEqual(names, set(expected["vectors"]))
        raw_names = {record["name"] for record in vectors["raw_invalid"]}
        self.assertEqual(raw_names, RAW_REQUIRED)
        self.assertTrue(raw_names.isdisjoint(names))
        self.assertEqual(vectors["mutants"], {
            "birth-after-runnable": "birth-after-runnable",
            "early-retirement": "retained-thread-ref",
            "silent-loss": "buffer-full",
            "tid-aliasing": "active-tid-alias",
        })

    def test_separate_registries_and_no_production_wiring(self):
        rust = (HERE / "model.rs").read_text()
        cref = (HERE / "reference.c").read_text()
        for token in ("ProcessRow", "ThreadRow", "ExclusiveUnpublished", "full_key"):
            self.assertIn(token, rust)
        for token in ("process_row", "thread_row", "EXCLUSIVE_UNPUBLISHED", "full_key"):
            self.assertIn(token, cref)
        combined = rust + cref
        for forbidden in ("host_schedule_process", "do_fork", "do_exit", "runq_add_thread", "mcctrl"):
            self.assertNotIn(forbidden, combined)

class NativeLifecycleRawDecoderTests(unittest.TestCase):
    @staticmethod
    def harness_module():
        spec = importlib.util.spec_from_file_location("native_lifecycle_harness", HERE / "harness.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def decoder(raw):
        return subprocess.run(
            [sys.executable, str(HERE / "harness.py"), "--decode-raw-document"],
            input=raw, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=5, check=False,
        )

    @staticmethod
    def document(operations, pools=None):
        return {
            "schema_version": 2,
            "model_only": True,
            "corpus_complete": False,
            "pools": pools or {},
            "vectors": [{
                "name": "valid", "coverage": ["valid"],
                "event_capacity": 256, "seed": "NONE",
                "operations": operations,
            }],
            "raw_invalid": [],
            "mutants": {},
        }

    def assert_decode(self, document, code):
        raw = json.dumps(document, separators=(",", ":")).encode()
        result = self.decoder(raw)
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (code, b"", b""))

    def test_positive_decoder_boundaries(self):
        end = [1, "CAPTURE_END", None, None, 0, 0, 0, 0]
        self.assert_decode(self.document({"pool": "O"}, {"O": [end]}), 0)
        self.assert_decode(self.document({"pool": "O", "args": []}, {"O": [end]}), 0)
        self.assert_decode(self.document({"pool": "A", "args": [end]},
                                           {"A": [{"arg": 0}]}), 0)
        operations = [[index, "CAPTURE_END", None, None, 0, 0, 0, 0]
                      for index in range(1, 129)]
        self.assert_decode(self.document(operations), 0)

        process = [1, 0, 1, 1, 1, 0, 1]
        thread = [1, 0, 1, 1, 1, 1, 1]
        end = lambda index: [index, "CAPTURE_END", None, None, 0, 0, 0, 0]
        p_base = [[1, "P_ALLOC", process, None, 100, 0, 0, 0], end(2)]
        t_base = [p_base[0], [2, "T_ALLOC", thread, process, 200, 1, 0, 0], end(3)]
        a_base = [p_base[0], [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "TID_ASSIGN", thread, None, 200, 0, 0, 0], end(4)]
        f_base = [p_base[0], [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "ABORT", thread, None, 1, 0, 0, 0],
                  [4, "RETIRE_BEGIN", thread, None, 0, 0, 0, 0], end(5)]
        for base in (p_base, t_base, a_base, f_base):
            self.assert_decode(self.document(base), 0)
        for pid in (1, (1 << 31) - 1):
            operations = json.loads(json.dumps(p_base)); operations[0][4] = pid
            self.assert_decode(self.document(operations), 0)
        for tid in (0, 1, (1 << 31) - 1):
            operations = json.loads(json.dumps(t_base)); operations[1][4] = tid
            self.assert_decode(self.document(operations), 0)
        for tid in (1, (1 << 31) - 1):
            operations = json.loads(json.dumps(a_base)); operations[2][4] = tid
            self.assert_decode(self.document(operations), 0)

        def raw_positive(operations):
            document = self.document(operations)
            document["vectors"][0]["name"] = "raw-base"
            document["vectors"][0]["coverage"] = ["raw-base"]
            return document
        self.assert_decode(raw_positive([end(1)]), 0)
        complete = raw_positive([end(1)]); complete["corpus_complete"] = True
        self.assert_decode(complete, 0)
        two = raw_positive([end(1)])
        second = json.loads(json.dumps(two["vectors"][0])); second["name"] = "raw-other"
        two["vectors"].append(second)
        self.assert_decode(two, 0)
        coverage = raw_positive([end(1)])
        coverage["vectors"][0]["coverage"] = ["raw-base", "second"]
        self.assert_decode(coverage, 0)
        self.assert_decode(raw_positive([
            [1, "LAUNCHER_LOSS", None, None, 0, 0, 0, 0], end(2)]), 0)

    def test_authority_width_payloads_are_exact_single_mutations(self):
        vectors = json.loads((HERE / "vectors.json").read_text())
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        self.assertTrue(RAW_ORIGINAL_REQUIRED <= set(records))
        self.assertEqual(set(records) & (RAW_AUTHORITY_REQUIRED | RAW_WIDTH_REQUIRED),
                         RAW_AUTHORITY_REQUIRED | RAW_WIDTH_REQUIRED)

        process = [1, 0, 1, 1, 1, 0, 1]
        thread = [1, 0, 1, 1, 1, 1, 1]
        end = lambda index: [index, "CAPTURE_END", None, None, 0, 0, 0, 0]
        bases = {
            "P": [[1, "P_ALLOC", process, None, 100, 0, 0, 0], end(2)],
            "T": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 200, 1, 0, 0], end(3)],
            "A": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "TID_ASSIGN", thread, None, 200, 0, 0, 0], end(4)],
            "F": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "ABORT", thread, None, 1, 0, 0, 0],
                  [4, "RETIRE_BEGIN", thread, None, 0, 0, 0, 0], end(5)],
        }
        def raw_document(operations):
            document = self.document(operations)
            document["vectors"][0]["name"] = "raw-base"
            document["vectors"][0]["coverage"] = ["raw-base"]
            return document
        expected = {}
        for field in range(4):
            operations = json.loads(json.dumps(bases["F"])); operations[3][4 + field] = 1
            expected[f"raw-authority-retire-{'abcd'[field]}"] = raw_document(operations)
        operations = json.loads(json.dumps(bases["F"])); operations[3].append("E")
        expected["raw-authority-extra-operation-field"] = raw_document(operations)
        document = raw_document(json.loads(json.dumps(bases["F"])))
        document["vectors"][0]["authority"] = "E"
        expected["raw-authority-extra-vector-field"] = document
        operations = json.loads(json.dumps(bases["F"])); operations[3][1] = "SET_AUTHORITY"
        expected["raw-authority-unknown-operation"] = raw_document(operations)
        pid_values = [0, 1 << 31, -1, 1 << 64, 1.0, 1.5, True, "100", None]
        pid_suffixes = ["zero", "int32-overflow", "negative", "u64-overflow",
                        "integral-float", "fractional-float", "boolean", "string", "null"]
        for suffix, value in zip(pid_suffixes, pid_values):
            operations = json.loads(json.dumps(bases["P"])); operations[0][4] = value
            expected[f"raw-pid-{suffix}"] = raw_document(operations)
        operations = json.loads(json.dumps(bases["T"])); operations[1][4] = 1 << 31
        expected["raw-tid-alloc-int32-overflow"] = raw_document(operations)
        for suffix, value in (("zero", 0), ("int32-overflow", 1 << 31)):
            operations = json.loads(json.dumps(bases["A"])); operations[2][4] = value
            expected[f"raw-tid-assign-{suffix}"] = raw_document(operations)

        self.assertEqual(set(expected), RAW_AUTHORITY_REQUIRED | RAW_WIDTH_REQUIRED)
        for name, document in expected.items():
            record = records[name]
            self.assertEqual(record["source"]["inline_utf8"],
                             json.dumps(document, separators=(",", ":")))
            family = "forged-authority" if name in RAW_AUTHORITY_REQUIRED else "pid-tid-width"
            self.assertEqual(record["coverage"], [family, name])
            self.assertEqual(record["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
        authority_bool = json.loads(json.dumps(expected["raw-authority-retire-a"]))
        authority_bool["vectors"][0]["operations"][3][4] = True
        self.assertNotEqual(
            json.dumps(authority_bool, separators=(",", ":")),
            records["raw-authority-retire-a"]["source"]["inline_utf8"])
        integral_int = json.loads(json.dumps(expected["raw-pid-integral-float"]))
        integral_int["vectors"][0]["operations"][0][4] = 1
        self.assertNotEqual(
            json.dumps(integral_int, separators=(",", ":")),
            records["raw-pid-integral-float"]["source"]["inline_utf8"])

    def test_document_vector_payloads_are_exact_single_mutations(self):
        vector_text = (HERE / "vectors.json").read_bytes().decode("utf-8")
        vectors = json.loads(vector_text)
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        position = vector_text.index('"raw_invalid": [') + len('"raw_invalid": [')
        decoder = json.JSONDecoder()
        for index in range(28):
            while vector_text[position] in " \r\n\t,":
                position += 1
            if index == 0:
                accepted_start = position
            _, position = decoder.raw_decode(vector_text, position)
        accepted_bytes = vector_text[accepted_start:position].encode()
        self.assertEqual(hashlib.sha256(accepted_bytes).hexdigest(),
                         RAW_ACCEPTED_28_TEXT_SHA256)
        self.assertNotEqual(hashlib.sha256(accepted_bytes.replace(b"\n", b"\r\n", 1)).hexdigest(),
                            RAW_ACCEPTED_28_TEXT_SHA256)
        base = {
            "schema_version": 2, "model_only": True, "corpus_complete": False,
            "pools": {}, "vectors": [{
                "name": "raw-base", "coverage": ["raw-base"],
                "event_capacity": 256, "seed": "NONE",
                "operations": [[1, "CAPTURE_END", None, None, 0, 0, 0, 0]],
            }], "raw_invalid": [], "mutants": {},
        }
        expected = {}
        compact = lambda document: json.dumps(document, separators=(",", ":"))
        expected["raw-json-truncated"] = compact(base)[:-1]
        expected["raw-document-nonobject"] = "[]"
        def mutation(name, apply):
            document = json.loads(json.dumps(base)); apply(document)
            expected[name] = compact(document)
        mutation("raw-top-missing-field", lambda d: d.pop("model_only"))
        mutation("raw-top-unknown-field", lambda d: d.update(extra=0))
        mutation("raw-schema-version-wrong", lambda d: d.update(schema_version=3))
        mutation("raw-schema-version-boolean", lambda d: d.update(schema_version=True))
        mutation("raw-schema-version-integral-float", lambda d: d.update(schema_version=2.0))
        mutation("raw-model-only-false", lambda d: d.update(model_only=False))
        mutation("raw-model-only-integer", lambda d: d.update(model_only=1))
        mutation("raw-corpus-complete-nonboolean", lambda d: d.update(corpus_complete=0))
        mutation("raw-vectors-nonarray", lambda d: d.update(vectors={}))
        mutation("raw-vector-nonobject", lambda d: d.update(vectors=[None]))
        mutation("raw-vector-missing-field", lambda d: d["vectors"][0].pop("seed"))
        mutation("raw-vector-name-empty", lambda d: d["vectors"][0].update(name=""))
        mutation("raw-vector-name-nonstring", lambda d: d["vectors"][0].update(name=0))
        mutation("raw-vector-name-duplicate", lambda d: d["vectors"].append(json.loads(json.dumps(d["vectors"][0]))))
        mutation("raw-coverage-nonarray", lambda d: d["vectors"][0].update(coverage="raw-base"))
        mutation("raw-coverage-empty", lambda d: d["vectors"][0].update(coverage=[]))
        mutation("raw-coverage-nonstring", lambda d: d["vectors"][0].update(coverage=[0]))
        mutation("raw-coverage-empty-string", lambda d: d["vectors"][0].update(coverage=[""]))
        mutation("raw-coverage-duplicate", lambda d: d["vectors"][0].update(coverage=["raw-base", "raw-base"]))
        mutation("raw-seed-unknown", lambda d: d["vectors"][0].update(seed="UNKNOWN"))
        mutation("raw-seed-nonstring", lambda d: d["vectors"][0].update(seed=0))
        mutation("raw-operations-nonarray", lambda d: d["vectors"][0].update(operations=None))
        mutation("raw-operations-empty", lambda d: d["vectors"][0].update(operations=[]))
        mutation("raw-operation-nonarray", lambda d: d["vectors"][0].update(operations=[None]))
        mutation("raw-operation-short", lambda d: d["vectors"][0]["operations"][0].pop())
        mutation("raw-operation-nonstring-name", lambda d: d["vectors"][0]["operations"][0].__setitem__(1, 0))
        mutation("raw-id-zero", lambda d: d["vectors"][0]["operations"][0].__setitem__(0, 0))
        mutation("raw-id-gap", lambda d: d["vectors"][0]["operations"][0].__setitem__(0, 2))
        self.assertEqual(set(expected), RAW_DOCUMENT_REQUIRED)
        for name, raw in expected.items():
            record = records[name]
            self.assertEqual(record["source"]["inline_utf8"], raw)
            self.assertEqual(record["coverage"], ["malformed-schema", name])
            self.assertEqual(record["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
        schema_integer = expected["raw-schema-version-integral-float"].replace("2.0", "2", 1)
        self.assertNotEqual(schema_integer,
                            records["raw-schema-version-integral-float"]["source"]["inline_utf8"])

    def test_key_domain_payloads_and_positive_boundaries(self):
        vector_bytes = (HERE / "vectors.json").read_bytes()
        vector_text = vector_bytes.decode("utf-8")
        vectors = json.loads(vector_text)
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        position = vector_text.index('"raw_invalid": [') + len('"raw_invalid": [')
        decoder = json.JSONDecoder()
        for index in range(58):
            while vector_text[position] in " \r\n\t,":
                position += 1
            if index == 0:
                accepted_start = position
            _, position = decoder.raw_decode(vector_text, position)
        accepted_bytes = vector_text[accepted_start:position].encode()
        self.assertEqual(hashlib.sha256(accepted_bytes).hexdigest(),
                         "bf14431f328af1b37777352fa70a24055e7824f0b2fd721c386debb1e4c57741")
        self.assertNotEqual(hashlib.sha256(accepted_bytes.replace(b"\n", b"\r\n", 1)).hexdigest(),
                            "bf14431f328af1b37777352fa70a24055e7824f0b2fd721c386debb1e4c57741")

        process = [1, 0, 1, 1, 1, 0, 1]
        thread = [1, 0, 1, 1, 1, 1, 1]
        end = lambda index: [index, "CAPTURE_END", None, None, 0, 0, 0, 0]
        bases = {
            "P": [[1, "P_ALLOC", process, None, 100, 0, 0, 0], end(2)],
            "T": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 200, 1, 0, 0], end(3)],
            "A": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "TID_ASSIGN", thread, None, 200, 0, 0, 0], end(4)],
            "F": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "ABORT", thread, None, 1, 0, 0, 0],
                  [4, "RETIRE_BEGIN", thread, None, 0, 0, 0, 0], end(5)],
        }
        def raw_document(operations, capacity=256):
            return {
                "schema_version": 2, "model_only": True, "corpus_complete": False,
                "pools": {}, "vectors": [{
                    "name": "raw-base", "coverage": ["raw-base"],
                    "event_capacity": capacity, "seed": "NONE", "operations": operations,
                }], "raw_invalid": [], "mutants": {},
            }
        compact = lambda document: json.dumps(document, separators=(",", ":"))
        expected = {}
        zero_components = (("capture", 0), ("os-generation", 2),
                           ("application", 3), ("process", 4), ("exec", 6))
        for suffix, component in zero_components:
            operations = json.loads(json.dumps(bases["P"])); operations[0][2][component] = 0
            expected[f"raw-key-{suffix}-zero"] = ("full-key", raw_document(operations))
        slot_values = (("negative", -1), ("u64-overflow", 1 << 64),
                       ("boolean", True), ("fractional", 1.5),
                       ("string", "1"), ("null", None))
        for suffix, value in slot_values:
            operations = json.loads(json.dumps(bases["P"])); operations[0][2][1] = value
            expected[f"raw-key-slot-{suffix}"] = ("full-key", raw_document(operations))
        operations = json.loads(json.dumps(bases["P"])); operations[0][2][5] = 1
        expected["raw-process-subject-thread-domain"] = ("domain-parent-shape", raw_document(operations))
        operations = json.loads(json.dumps(bases["T"])); operations[1][2][5] = 0
        expected["raw-thread-subject-process-domain"] = ("domain-parent-shape", raw_document(operations))
        shapes = (("null", None), ("scalar", "P"),
                  ("short", [1, 0, 1, 1, 1, 0]),
                  ("long", [1, 0, 1, 1, 1, 0, 1, 1]))
        for suffix, value in shapes:
            operations = json.loads(json.dumps(bases["P"])); operations[0][2] = value
            expected[f"raw-subject-{suffix}"] = ("domain-parent-shape", raw_document(operations))
            operations = json.loads(json.dumps(bases["T"])); operations[1][3] = value
            expected[f"raw-thread-parent-{suffix}"] = ("domain-parent-shape", raw_document(operations))
        operations = json.loads(json.dumps(bases["T"])); operations[1][3][5] = 1
        expected["raw-thread-parent-thread-domain"] = ("domain-parent-shape", raw_document(operations))
        operations = json.loads(json.dumps(bases["P"])); operations[0][3] = process
        expected["raw-process-unexpected-parent"] = ("domain-parent-shape", raw_document(operations))
        operations = json.loads(json.dumps(bases["A"])); operations[2][3] = process
        expected["raw-tid-assign-unexpected-parent"] = ("domain-parent-shape", raw_document(operations))
        for suffix, field in (("subject", 2), ("parent", 3)):
            operations = json.loads(json.dumps(bases["P"])); operations[1][field] = process
            expected[f"raw-capture-{suffix}"] = ("domain-parent-shape", raw_document(operations))
        for suffix, value in (("boolean", True), ("overflow", 257)):
            expected[f"raw-capacity-{suffix}"] = ("numeric-bounds", raw_document(json.loads(json.dumps(bases["P"])), value))
        for suffix, value in (("zero", 0), ("overflow", 256)):
            operations = json.loads(json.dumps(bases["F"])); operations[2][4] = value
            expected[f"raw-abort-stage-{suffix}"] = ("numeric-bounds", raw_document(operations))
        self.assertEqual(set(expected), RAW_KEY_DOMAIN_REQUIRED)
        for name, (family, document) in expected.items():
            self.assertEqual(records[name]["source"]["inline_utf8"], compact(document))
            self.assertEqual(records[name]["coverage"], [family, name])
            self.assertEqual(records[name]["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
        bool_as_one = json.loads(json.dumps(expected["raw-key-slot-boolean"][1]))
        bool_as_one["vectors"][0]["operations"][0][2][1] = 1
        self.assertNotEqual(compact(bool_as_one),
                            records["raw-key-slot-boolean"]["source"]["inline_utf8"])

        for operations in bases.values():
            self.assert_decode(raw_document(operations), 0)
        for capacity in (0, 256):
            self.assert_decode(raw_document(json.loads(json.dumps(bases["P"])), capacity), 0)
        for stage in (1, 255):
            operations = json.loads(json.dumps(bases["F"])); operations[2][4] = stage
            self.assert_decode(raw_document(operations), 0)
        for slot in (0, (1 << 64) - 1):
            operations = json.loads(json.dumps(bases["P"])); operations[0][2][1] = slot
            self.assert_decode(raw_document(operations), 0)
        for component in (0, 2, 3, 4, 6):
            for value in (1, (1 << 64) - 1):
                operations = json.loads(json.dumps(bases["P"])); operations[0][2][component] = value
                self.assert_decode(raw_document(operations), 0)
                operations = json.loads(json.dumps(bases["T"]))
                operations[0][2][component] = value
                operations[1][2][component] = value
                operations[1][3][component] = value
                self.assert_decode(raw_document(operations), 0)
        for thread_instance in (1, (1 << 64) - 1):
            operations = json.loads(json.dumps(bases["T"])); operations[1][2][5] = thread_instance
            self.assert_decode(raw_document(operations), 0)

    def test_pool_payloads_errors_and_positive_boundaries(self):
        vector_text = (HERE / "vectors.json").read_bytes().decode("utf-8")
        vectors = json.loads(vector_text)
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        position = vector_text.index('"raw_invalid": [') + len('"raw_invalid": [')
        decoder = json.JSONDecoder()
        for index in range(88):
            while vector_text[position] in " \r\n\t,":
                position += 1
            if index == 0:
                accepted_start = position
            _, position = decoder.raw_decode(vector_text, position)
        accepted_bytes = vector_text[accepted_start:position].encode()
        accepted_hash = "40e35683740716530f59cf73e573b03c6bda7bca7d9db4b35b4e17f47fbe1834"
        self.assertEqual(hashlib.sha256(accepted_bytes).hexdigest(), accepted_hash)
        self.assertNotEqual(hashlib.sha256(accepted_bytes.replace(b"\n", b"\r\n", 1)).hexdigest(),
                            accepted_hash)

        end = [1, "CAPTURE_END", None, None, 0, 0, 0, 0]
        ordinary = [end]
        def document(pools, operations):
            return {
                "schema_version": 2, "model_only": True, "corpus_complete": False,
                "pools": pools, "vectors": [{
                    "name": "pool-base", "coverage": ["pool-base"],
                    "event_capacity": 256, "seed": "NONE", "operations": operations,
                }], "raw_invalid": [], "mutants": {},
            }
        def chain(count):
            result = {"P00": 0}
            for index in range(1, count):
                result[f"P{index:02d}"] = {"pool": f"P{index - 1:02d}"}
            return result
        def nested(depth):
            result = 0
            for _ in range(depth):
                result = [result]
            return result
        cases = {
            "raw-pool-map-array": ([], ordinary, "pools"),
            "raw-pool-empty-definition-name": ({"": 0}, ordinary, "invalid input"),
            "raw-pool-reference-missing-field": ({}, {"args": []}, "pool reference"),
            "raw-pool-reference-extra-field": ({"O": ordinary}, {"pool": "O", "extra": 0}, "pool reference"),
            "raw-pool-reference-name-integer": ({"O": ordinary}, {"pool": 0}, "pool reference"),
            "raw-pool-args-null": ({"I": {"arg": 0}}, {"pool": "I", "args": None}, "pool arity"),
            "raw-pool-required-args-omitted": ({"I": {"arg": 0}}, {"pool": "I"}, "pool arity"),
            "raw-pool-nonzero-arity-excess": ({"I": {"arg": 0}}, {"pool": "I", "args": [ordinary, ordinary]}, "pool arity"),
            "raw-pool-placeholder-negative": ({"U": {"arg": -1}}, ordinary, "placeholder"),
            "raw-pool-placeholder-boolean": ({"U": {"arg": True}}, ordinary, "placeholder"),
            "raw-pool-placeholder-integral-float": ({"U": {"arg": 0.0}}, ordinary, "placeholder"),
            "raw-pool-placeholder-string": ({"U": {"arg": "0"}}, ordinary, "placeholder"),
            "raw-pool-placeholder-extra-field": ({"U": {"arg": 0, "extra": 0}}, ordinary, "pool reference"),
            "raw-pool-placeholder-unbound": ({}, {"arg": 0}, "placeholder"),
            "raw-pool-unused-unknown-reference": ({"U": {"pool": "MISSING"}}, ordinary, "unknown pool"),
            "raw-pool-unused-self-cycle": ({"U": {"pool": "U"}}, ordinary, "pool cycle or dependency depth"),
            "raw-pool-unused-arity-excess": ({"I": {"arg": 0}, "U": {"pool": "I", "args": [ordinary, ordinary]}}, ordinary, "pool arity"),
            "raw-pool-unused-mutual-cycle": ({"A": {"pool": "B"}, "B": {"pool": "A"}}, ordinary, "pool cycle or dependency depth"),
            "raw-pool-unused-dependency-33-leaf-first": (chain(33), ordinary, "pool dependency depth"),
            "raw-pool-unused-dependency-33-root-first": (dict(reversed(list(chain(33).items()))), ordinary, "pool dependency depth"),
            "raw-pool-unused-syntax-depth-33": ({"U": nested(33)}, ordinary, "pool depth"),
            "raw-pool-expanded-byte-budget-over": ({"D": {"arg": 1}}, {"pool": "D", "args": ["x" * 174736, ordinary]}, "expanded literal budget"),
        }
        self.assertEqual(set(cases), RAW_POOL_REQUIRED)
        module = self.harness_module()
        for name, (pools, operations, message) in cases.items():
            raw = json.dumps(document(pools, operations), separators=(",", ":"))
            record = records[name]
            self.assertEqual(record["source"]["inline_utf8"], raw)
            self.assertEqual(record["coverage"], ["pool-validation", name])
            self.assertEqual(record["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
            with self.assertRaises(module.ValidationError) as raised:
                module.decode_raw_document(raw.encode())
            self.assertEqual(str(raised.exception), message)
        self.assertEqual(len(records["raw-pool-expanded-byte-budget-over"]["source"]["inline_utf8"].encode()),
                         175021)

        positives = [
            document({"O": ordinary}, {"pool": "O"}),
            document({"O": ordinary}, {"pool": "O", "args": []}),
            document({"I": {"arg": 0}, "A": {"pool": "I", "args": [{"arg": 0}]}},
                     {"pool": "A", "args": [ordinary]}),
            document({"U": {"arg": 2}}, ordinary),
            document(chain(32), ordinary),
            document(dict(reversed(list(chain(32).items()))), ordinary),
            document({"U": nested(32)}, ordinary),
            document({"D": {"arg": 1}}, {"pool": "D", "args": ["x" * 174735, ordinary]}),
        ]
        self.assertEqual(len(json.dumps(positives[-1], separators=(",", ":")).encode()), 175020)
        for positive in positives:
            self.assert_decode(positive, 0)

    def test_envelope_payloads_and_input_boundaries(self):
        vector_text = (HERE / "vectors.json").read_bytes().decode("utf-8")
        vectors = json.loads(vector_text)
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        position = vector_text.index('"raw_invalid": [') + len('"raw_invalid": [')
        decoder = json.JSONDecoder()
        for index in range(110):
            while vector_text[position] in " \r\n\t,":
                position += 1
            if index == 0:
                accepted_start = position
            _, position = decoder.raw_decode(vector_text, position)
        accepted_bytes = vector_text[accepted_start:position].encode()
        accepted_hash = "e66175e09519434778e8a91df2913cce7afc0c3eab7a0cdd49f8479069f2ccda"
        self.assertEqual(hashlib.sha256(accepted_bytes).hexdigest(), accepted_hash)
        self.assertNotEqual(hashlib.sha256(accepted_bytes.replace(b"\n", b"\r\n", 1)).hexdigest(),
                            accepted_hash)
        base = {
            "schema_version": 2, "model_only": True, "corpus_complete": False,
            "pools": {}, "vectors": [{
                "name": "raw-base", "coverage": ["raw-base"],
                "event_capacity": 256, "seed": "NONE",
                "operations": [[1, "CAPTURE_END", None, None, 0, 0, 0, 0]],
            }], "raw_invalid": [], "mutants": {},
        }
        compact = lambda document: json.dumps(document, separators=(",", ":"))
        self.assertEqual(len(compact(base).encode()), 245)
        expected = {}
        document = json.loads(json.dumps(base)); document["raw_invalid"] = {}
        expected["raw-raw-invalid-nonarray"] = (document, "raw cases")
        document = json.loads(json.dumps(base)); document["mutants"] = []
        expected["raw-mutants-nonobject"] = (document, "mutants")
        document = json.loads(json.dumps(base)); document["raw_invalid"] = [None]
        expected["raw-nested-raw-invalid"] = (document, "nested raw cases")
        self.assertEqual(set(expected), RAW_ENVELOPE_REQUIRED)
        module = self.harness_module()
        for name, (document, message) in expected.items():
            raw = compact(document)
            self.assertEqual(records[name]["source"]["inline_utf8"], raw)
            self.assertEqual(records[name]["coverage"], ["malformed-schema", name])
            self.assertEqual(records[name]["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
            with self.assertRaises(module.ValidationError) as raised:
                module.decode_raw_document(raw.encode())
            self.assertEqual(str(raised.exception), message)
        base_bytes = compact(base).encode()
        whitespace = b" \t\r\n" + base_bytes + b"\r\n\t "
        self.assertEqual(len(whitespace), 253)
        result = self.decoder(whitespace)
        self.assertEqual((result.returncode, result.stdout, result.stderr), (0, b"", b""))
        maximum = base_bytes + (b" " * 1048331)
        self.assertEqual(len(maximum), 1 << 20)
        result = self.decoder(maximum)
        self.assertEqual((result.returncode, result.stdout, result.stderr), (0, b"", b""))
        mutants = json.loads(json.dumps(base)); mutants["mutants"] = {"unused": "unresolved"}
        self.assert_decode(mutants, 0)

    def test_operation_argument_payloads_and_boundaries(self):
        vector_text = (HERE / "vectors.json").read_bytes().decode("utf-8")
        vectors = json.loads(vector_text)
        records = {record["name"]: record for record in vectors["raw_invalid"]}
        self.assertEqual(len(records), 132)
        self.assertEqual(set(records), RAW_REQUIRED)
        position = vector_text.index('"raw_invalid": [') + len('"raw_invalid": [')
        decoder = json.JSONDecoder()
        for index in range(113):
            while vector_text[position] in " \r\n\t,":
                position += 1
            if index == 0:
                accepted_start = position
            _, position = decoder.raw_decode(vector_text, position)
        accepted_bytes = vector_text[accepted_start:position].encode()
        accepted_hash = "0e0112f4463bba6f04d5b1b9ff5b8fa37f8a767bdde3f5b5dfddb92a256fb428"
        self.assertEqual(hashlib.sha256(accepted_bytes).hexdigest(), accepted_hash)
        self.assertNotEqual(hashlib.sha256(accepted_bytes.replace(b"\n", b"\r\n", 1)).hexdigest(),
                            accepted_hash)

        process = [1, 0, 1, 1, 1, 0, 1]
        thread = [1, 0, 1, 1, 1, 1, 1]
        end = lambda index: [index, "CAPTURE_END", None, None, 0, 0, 0, 0]
        bases = {
            "P": [[1, "P_ALLOC", process, None, 100, 0, 0, 0], end(2)],
            "T": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 200, 1, 0, 0], end(3)],
            "A": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "TID_ASSIGN", thread, None, 200, 0, 0, 0], end(4)],
            "F": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 0, 1, 0, 0],
                  [3, "ABORT", thread, None, 1, 0, 0, 0],
                  [4, "RETIRE_BEGIN", thread, None, 0, 0, 0, 0], end(5)],
            "H": [[1, "P_ALLOC", process, None, 100, 0, 0, 0],
                  [2, "T_ALLOC", thread, process, 200, 1, 0, 0],
                  [3, "TERMINAL", thread, None, 9472, 37, 0, 1], end(4)],
        }
        def raw_document(operations):
            return {
                "schema_version": 2, "model_only": True, "corpus_complete": False,
                "pools": {}, "vectors": [{
                    "name": "raw-base", "coverage": ["raw-base"],
                    "event_capacity": 256, "seed": "NONE", "operations": operations,
                }], "raw_invalid": [], "mutants": {},
            }
        expected = {}
        operations = json.loads(json.dumps(bases["P"])); operations[0][0] = 129
        expected["raw-operation-id-overflow"] = (operations, "integer")
        operations = json.loads(json.dumps(bases["P"])); operations[0][0] = 1.5
        expected["raw-operation-id-fractional"] = (operations, "literal type")
        operations = json.loads(json.dumps(bases["T"])); operations[1][5] = 2
        expected["raw-main-flag-overflow"] = (operations, "thread arguments")
        for suffix, field, value in (
                ("raw-overflow", 4, 1 << 32), ("status-overflow", 5, 256),
                ("signal-overflow", 6, 256), ("branch-zero", 7, 0),
                ("branch-overflow", 7, 5)):
            operations = json.loads(json.dumps(bases["H"])); operations[2][field] = value
            expected[f"raw-terminal-{suffix}"] = (operations, "integer")
        for suffix, field in (("b", 5), ("c", 6), ("d", 7)):
            operations = json.loads(json.dumps(bases["P"])); operations[0][field] = 1
            expected[f"raw-unused-p-alloc-{suffix}"] = (operations, "unused argument")
        for suffix, field in (("c", 6), ("d", 7)):
            operations = json.loads(json.dumps(bases["T"])); operations[1][field] = 1
            expected[f"raw-unused-t-alloc-{suffix}"] = (operations, "thread arguments")
        for suffix, field in (("b", 5), ("c", 6), ("d", 7)):
            operations = json.loads(json.dumps(bases["A"])); operations[2][field] = 1
            expected[f"raw-unused-tid-assign-{suffix}"] = (operations, "unused argument")
            operations = json.loads(json.dumps(bases["F"])); operations[2][field] = 1
            expected[f"raw-unused-abort-{suffix}"] = (operations, "abort arguments")
        self.assertEqual(set(expected), RAW_OPERATION_ARGUMENT_REQUIRED)
        module = self.harness_module()
        for name, (operations, message) in expected.items():
            raw = json.dumps(raw_document(operations), separators=(",", ":"))
            self.assertEqual(records[name]["source"]["inline_utf8"], raw)
            coverage = "numeric-bounds" if name in {
                "raw-operation-id-overflow", "raw-operation-id-fractional",
                "raw-main-flag-overflow", "raw-terminal-raw-overflow",
                "raw-terminal-status-overflow", "raw-terminal-signal-overflow",
                "raw-terminal-branch-zero", "raw-terminal-branch-overflow",
            } else "unused-arguments"
            self.assertEqual(records[name]["coverage"], [coverage, name])
            self.assertEqual(records[name]["expected"], {
                "stage": "harness", "exit_code": 2,
                "stdout_hex": "", "stderr_hex": "", "model_invocations": 0,
            })
            with self.assertRaises(module.ValidationError) as raised:
                module.decode_raw_document(raw.encode())
            self.assertEqual(str(raised.exception), message)

        retained_unused = records["raw-unused-p-alloc-b"]["source"]["inline_utf8"]
        for conflated in (True, 1.0):
            operations = json.loads(json.dumps(bases["P"]))
            operations[0][5] = conflated
            candidate = json.dumps(raw_document(operations), separators=(",", ":"))
            self.assertNotEqual(candidate, retained_unused)

        for operations in bases.values():
            self.assert_decode(raw_document(operations), 0)
        for flag in (0, 1):
            operations = json.loads(json.dumps(bases["T"])); operations[1][5] = flag
            self.assert_decode(raw_document(operations), 0)
        for field, values in ((4, (0, (1 << 32) - 1)), (5, (0, 255)),
                              (6, (0, 255)), (7, (1, 2, 3, 4))):
            for value in values:
                operations = json.loads(json.dumps(bases["H"])); operations[2][field] = value
                self.assert_decode(raw_document(operations), 0)

    def test_one_hundred_thirty_two_raw_rejections_without_build_inputs(self):
        result = subprocess.run(
            [sys.executable, str(HERE / "harness.py"), "--check-raw-invalid"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False,
        )
        self.assertEqual((result.returncode, result.stdout, result.stderr),
                         (0, b"", b""))

    def test_oversized_artifact_binding(self):
        vectors = json.loads((HERE / "vectors.json").read_text())
        record = next(item for item in vectors["raw_invalid"]
                      if item["name"] == "raw-oversized-document")
        description = record["source"]["artifact"]
        path = HERE.parents[3] / description["path"]
        raw = path.read_bytes()
        self.assertEqual(len(raw), description["size"])
        self.assertEqual(hashlib.sha256(raw).hexdigest(), description["sha256"])
        self.assertEqual(self.decoder(raw).returncode, 2)

    def test_artifact_metadata_path_and_symlink_rejections(self):
        module = self.harness_module()
        vectors = json.loads((HERE / "vectors.json").read_text())
        record = next(item for item in vectors["raw_invalid"]
                      if item["name"] == "raw-oversized-document")
        description = record["source"]["artifact"]
        with mock.patch.object(module.os, "open", wraps=os.open) as opener:
            retained = module.artifact_bytes(description)
        final_opens = [call for call in opener.call_args_list
                       if call.args and call.args[0] == "oversized-document.json"]
        self.assertEqual(len(final_opens), 1)
        self.assertEqual(hashlib.sha256(retained).hexdigest(), description["sha256"])
        for mutation in (
            {**description, "size": description["size"] - 1},
            {**description, "sha256": "0" * 64},
            {**description, "path": "scripts/tests/fixtures/native-lifecycle-model-v1/../outside"},
        ):
            with self.assertRaises((AssertionError, OSError)):
                module.artifact_bytes(mutation)
        raw_dir = HERE / "raw-invalid"
        with tempfile.TemporaryDirectory(dir=raw_dir) as temporary:
            link = Path(temporary) / "link"
            link.symlink_to(raw_dir / "oversized-document.json")
            relative = link.relative_to(HERE.parents[3]).as_posix()
            with self.assertRaises(OSError):
                module.artifact_bytes({**description, "path": relative})

    def test_child_timeout_and_output_are_not_rejections(self):
        module = self.harness_module()
        real_popen = subprocess.Popen
        children = []
        def capture(*args, **kwargs):
            child = real_popen(*args, **kwargs)
            children.append(child)
            return child
        with mock.patch.object(module.subprocess, "Popen", side_effect=capture):
            with self.assertRaises(AssertionError):
                module.bounded_child(
                    [sys.executable, "-c", "import time; time.sleep(10)"], b"")
            self.assertIsNotNone(children[-1].poll())
            with self.assertRaises(AssertionError):
                module.bounded_child(
                    [sys.executable, "-c", "import os; os.write(1, b'x' * 65537)"], b"")
            self.assertIsNotNone(children[-1].poll())

    def test_recursive_raw_and_build_tripwires(self):
        nested = self.document([[1, "CAPTURE_END", None, None, 0, 0, 0, 0]])
        nested["raw_invalid"] = [{
            "name": "nested", "coverage": ["nested"],
            "source": {"inline_utf8": "{}"},
            "expected": {"stage": "harness", "exit_code": 2,
                         "stdout_hex": "", "stderr_hex": "",
                         "model_invocations": 0},
        }]
        self.assert_decode(nested, 2)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "must-not-exist"
            module = self.harness_module()
            with mock.patch.object(module, "build", side_effect=RuntimeError("build called")) as build_call, \
                 mock.patch.object(module, "compiler", side_effect=RuntimeError("compiler called")) as compiler_call, \
                 mock.patch.object(module, "run", side_effect=RuntimeError("model called")) as model_call, \
                 mock.patch.object(module, "raw_child", wraps=module.raw_child) as raw_call, \
                 mock.patch.object(sys, "argv", [str(HERE / "harness.py"),
                                                  "--rustc", "/must/not/resolve/rustc",
                                                  "--cc", "/must/not/resolve/cc",
                                                  "--output", str(output)]):
                with self.assertRaises(AssertionError):
                    module.main()
                self.assertEqual(raw_call.call_count, len(RAW_REQUIRED))
                build_call.assert_not_called()
                compiler_call.assert_not_called()
                model_call.assert_not_called()
            self.assertFalse(output.exists())

if __name__ == "__main__":
    unittest.main()
