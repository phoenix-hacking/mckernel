include!("../mode2/adapter.rs");
