#[cfg(test)]
pub(crate) mod row03_row12_memory {
    use core::ptr::NonNull;
    use core::sync::atomic::{AtomicU64, Ordering};
    use std::sync::{Arc, Mutex};

    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub(crate) enum Event { Construct, Baseline, Status, Release, FinishedDrop,
        UnfinishedDrop, Quarantine, Deferred, Deallocate }
    pub(crate) struct Ledger { pub events: Mutex<Vec<Event>>, pub deallocations: AtomicU64 }
    impl Ledger { pub(crate) fn new() -> Arc<Self> { Arc::new(Self { events: Mutex::new(Vec::new()), deallocations: AtomicU64::new(0) }) }
        fn record(&self, event: Event) { self.events.lock().unwrap().push(event); }
        pub(crate) fn count(&self, event: Event) -> u64 { self.events.lock().unwrap().iter().filter(|e| **e == event).count() as u64 }
    }
    #[repr(align(8))] pub(crate) struct AlignedBacking { pub bytes: [u8; 56] }
    pub(crate) struct TestResponseMemory { backing: Option<Box<AlignedBacking>>, span: NonNull<u8>, physical: u64, ledger: Arc<Ledger>, released: bool }
    impl TestResponseMemory {
        pub(crate) fn new(physical: u64, ledger: Arc<Ledger>) -> Self { let mut b = Box::new(AlignedBacking { bytes: [0; 56] }); let span = NonNull::new(b.bytes.as_mut_ptr().wrapping_add(8)).unwrap(); ledger.record(Event::Construct); Self { backing: Some(b), span, physical, ledger, released: false } }
        pub(crate) fn baseline(&self) { self.ledger.record(Event::Baseline); }
        pub(crate) fn ledger(&self) -> &Arc<Ledger> { &self.ledger }
        pub(crate) fn drain_deferred(ledger: &Arc<Ledger>) { ledger.record(Event::Deallocate); ledger.deallocations.fetch_add(1, Ordering::AcqRel); }
        pub(crate) fn drain_quarantine(ledger: &Arc<Ledger>) { ledger.record(Event::Deallocate); ledger.deallocations.fetch_add(1, Ordering::AcqRel); }
    }
    unsafe impl super::ResponseMemory for TestResponseMemory {
        fn physical(&self) -> u64 { self.physical }
        fn address(&mut self) -> *mut u8 { self.span.as_ptr() }
        unsafe fn release(mut self) { if self.released { return; } self.released = true; self.ledger.record(Event::Release); let backing = self.backing.take(); debug_assert!(backing.is_some()); self.ledger.record(Event::Deferred); }
    }
    impl Drop for TestResponseMemory { fn drop(&mut self) { if self.released { self.ledger.record(Event::FinishedDrop); } else { let backing = self.backing.take(); debug_assert!(backing.is_some()); self.ledger.record(Event::Quarantine); self.ledger.record(Event::UnfinishedDrop); } } }
}
