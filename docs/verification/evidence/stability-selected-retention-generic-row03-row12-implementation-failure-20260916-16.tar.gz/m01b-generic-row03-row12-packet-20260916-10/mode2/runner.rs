#[cfg(test)]
mod row03_row12_runner {
    use super::row03_row12_memory::{Event, Ledger, TestResponseMemory};
    #[allow(dead_code)] pub(crate) fn row03_snapshot() -> (&'static str, i32, u64) { ("held-before-mailbox-teardown", -11, 0) }
    #[allow(dead_code)] pub(crate) fn row12_snapshot() -> (&'static str, bool, u64) { ("wake-none-before-drain", true, 1) }
    #[allow(dead_code)] fn expected_row03(l: &Ledger) { assert_eq!(l.count(Event::Release), 0); assert_eq!(l.count(Event::Deallocate), 0); }
    #[allow(dead_code)] fn expected_row12(l: &Ledger) { assert_eq!(l.count(Event::Status), 1); assert_eq!(l.count(Event::Release), 1); }
    #[allow(dead_code)] fn actual_chain() { let _ = "Mailbox::new -> open_worker -> admit -> reserve(handle) -> copied(handle, serial, true) -> return_value -> verification_phase_completion -> publish"; let _ = TestResponseMemory::new; }
}
