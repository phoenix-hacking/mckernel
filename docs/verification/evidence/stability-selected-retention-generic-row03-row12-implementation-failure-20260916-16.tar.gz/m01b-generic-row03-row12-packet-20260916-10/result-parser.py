#!/usr/bin/env python3
import json, sys
EXPECTED = {"row03": {"publish": "Err(-11)"}, "row12": {"publish": "Ok(true)"}}
def parse(path):
    with open(path, encoding="utf-8") as stream: result = json.load(stream)
    for row, expected in EXPECTED.items():
        if result.get(row, {}).get("publish") != expected["publish"]: raise SystemExit("unexpected " + row)
    return result
if __name__ == "__main__": parse(sys.argv[1])
