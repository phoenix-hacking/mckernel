"""Hash current maintenance inputs; no kernel build or execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import sys

WORK = Path('/home/holden/mckernel-work/scratch')
BEFORE = WORK / 'storage-preserved-inputs-20260908-3.json'
AFTER = WORK / 'storage-preserved-inputs-after-20260908-3.json'


def identity(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size,
                sha256=digest.hexdigest())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


assert os.getuid() == 1000 and len(sys.argv) == 2
spec = importlib.util.spec_from_file_location(
    'cleanup', WORK / 'cleanup-archived-captures-20260908-3.py')
cleanup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cleanup)
if sys.argv[1] == 'before':
    assert not BEFORE.exists() and not AFTER.exists()
    previous = json.loads((WORK / 'storage-preserved-inputs-20260908-2.json').read_text())
    paths = {Path(row['path']) for row in previous['files']}
    for name in ('native-sysfs-snoop-module-20260908-2',
                 'native-sysfs-snoop-module-20260908-3'):
        paths.update(p for p in (WORK / name).rglob('*')
                     if p.is_file() and not p.is_symlink())
    paths.update(p for p in WORK.iterdir()
                 if p.is_file() and not p.is_symlink()
                 and p.suffix in ('.py', '.sh', '.inc'))
    for name in cleanup.KEEP:
        assert (WORK / name).is_dir(), name
    backing = (WORK.parent / 'scratch.ext4').stat()
    value = dict(utc=datetime.now(timezone.utc).isoformat(),
                 files=[identity(p) for p in sorted(paths)],
                 protected=sorted(cleanup.KEEP),
                 backing_before=dict(size=backing.st_size,
                                     allocated_bytes=backing.st_blocks * 512))
    save(BEFORE, value)
    print('PRESERVATION SNAPSHOT', len(paths), 'files;', len(cleanup.KEEP), 'directories')
elif sys.argv[1] == 'after':
    assert not AFTER.exists()
    before = json.loads(BEFORE.read_text())
    for row in before['files']:
        assert identity(Path(row['path'])) == row, row['path']
    for name in before['protected']:
        assert (WORK / name).is_dir(), name
    value = dict(status='PASS', all_files_byte_identical=True,
                 checked_files=len(before['files']),
                 protected_directories=before['protected'],
                 finished_utc=datetime.now(timezone.utc).isoformat())
    save(AFTER, value)
    print('PRESERVATION PASS', value['checked_files'], 'files unchanged')
else:
    raise ValueError('expected before or after')
