from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-vdso-service-retained-20260907-1'
out.mkdir()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): value.update(data)
    return value.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def verify(row, alternate=None):
    path = Path(row['path']) if alternate is None else alternate
    assert path.stat().st_size == row['size'] and digest(path) == row['sha256'], (row, path)

record = dict(created_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], production_gate_credit=False, declared_stage=False,
    vdso_service_completed=True, mckernel_arch_entry_proven=True,
    control_listener_connections_proven=True, mckernel_boot_proven=False,
    passed=[
        'Native boot note 3 advertises the versioned descriptor independently of the existing revision-2 queue completion protocol',
        'A separate 128-byte exchange validates every request/reply field, physical page, reserved hole and one-shot release/acquire completion',
        '128 concurrent cross-page exchanges preserve canaries; malformed request bytes, stale generations, whole-extent failures, queue aliases and Linux-page overlap are rejected before writes',
        'The actual pinned Linux clock arithmetic agrees over 77,824 cases; reader tests cover coarse clocks, hardware-mode fallback, raw time, normalization and sequence retries',
        'Complete original C and production Rust mapping bodies match across 144 legacy/failure cases; native optional page combinations preserve exact addresses, holes, cache attributes and failure ordering',
        'All three McKernel images build, the actual loader parses revisions 1/2/3, and native prototype 9 builds all three host modules with exact layout/ELF/no-SIMD checks',
        'Preparation passes both user ABIs over two module lifetimes with 32 forced allocation failures, rejection of old native capabilities, four physical captures and full unstarted restoration',
        'Both actual-start ABIs complete the real vDSO response; QMP verifies Linux text/time/RNG pages, all 128 descriptor bytes, guest validation state 2, original 88-byte prefix, container size/offset and legacy local-time flags',
        'Both guests advance to a real SYSFS_REQ_SETUP packet using its separate payload ABI, with an owned request/data page and busy still set for the next host service'],
    limitations=[
        'Prototype builds 6/7 fail kernel API and unreachable-pub checks; image build 12 fails standalone slice-panic/bcmp link closure; the first startup capture misdecodes the sysfs payload. All failures and corrections are retained',
        'TCG selects VDSO_CLOCKMODE_NONE. Accelerated TSC/PV/Hyper-V operation and encrypted memory remain unverified; native high-resolution syscall fallback still depends on future complete runtime offload',
        'Supplemental application page mappings are proven through actual-body callback tests; no application process has exercised those mappings yet',
        'BOOT still returns -110/Failed and retains all started owners at the pending sysfs service. Full status 3, sysfs/mcctrl, asynchronous runtime dispatch, applications and native shutdown/restoration remain open',
        'Declared staging/lifecycle/unsafe-FFI/license bindings, current full-suite integration and independent production acceptance remain open',
        'The earlier intermittent Linux idle/RCU stall and full McKernel/linked-support Rust or assembly completion remain open'],
    source_check_binding='Exact formatted compiler inputs are retained and hash-verified for all four source checks. Attempts 1-3 also report pre-format workspace digests, whose original unformatted bytes were not all retained; no unformatted-source byte-verification claim is made. Attempt 4 additionally retains and verifies every original Rust input.')

def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''): stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name,
        source=str(path), size=target.stat().st_size, sha256=digest(target),
        unpacked_size=path.stat().st_size, unpacked_sha256=digest(path)))

captures = [('native-vdso-service-tests-20260907-' + str(i), 'PASS') for i in range(1, 5)]
captures += [('native-ikc-prototype-20260907-' + str(i), 'FAIL' if i < 8 else 'PASS') for i in range(6, 10)]
captures += [('mckernel-native-irq-images-20260907-12', 'FAIL'), ('mckernel-native-irq-images-20260907-13', 'PASS'),
    ('native-vdso-service-images-validation-20260907-1', 'PASS'),
    ('native-vdso-service-guest-20260907-prepare-1', 'PASS'),
    ('native-vdso-service-guest-20260907-start-x86_64-1', 'FAIL'),
    ('native-vdso-service-guest-20260907-start-x86_64-2', 'PASS'),
    ('native-vdso-service-guest-20260907-start-i386-1', 'PASS')]

try:
    for name, status in captures:
        path = work / name
        metadata = json.loads((path / 'record.json').read_text())
        assert metadata['status'] == status, name
        rows = metadata.get('outputs', []) + metadata.get('formatted_outputs', [])
        if name.startswith('native-vdso-service-tests-'):
            for item in metadata['inputs']:
                original = Path(item['path'])
                if original.is_relative_to(repo):
                    if name.endswith('-4'):
                        verify(item, path / 'original-inputs' / original.relative_to(repo))
                else:
                    verify(item)
        else:
            rows += metadata.get('inputs', []) + metadata.get('production_inputs', []) + metadata.get('source_overlays', [])
        for capture in metadata.get('captures', []): rows += capture.get('artifacts', [])
        for image in metadata.get('images', []): rows += image['outputs']
        for row in rows: verify(row)
        if name.startswith('native-ikc-prototype-'):
            for row in metadata['overlay']:
                relative = Path(row['path']).relative_to(work / 'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel')
                verify(row, path / 'staged-source' / relative)
        if name.startswith('native-vdso-service-guest-') and status == 'PASS':
            assert all(capture['linux_vdso']['clock_mode'] == 0 for capture in metadata['captures'])
            if metadata['mode'] != 'prepare':
                assert all(capture['linux_vdso']['service_completed'] and capture['linux_vdso']['guest_validated_state'] == 2
                           and capture['linux_vdso']['next_request']['message'] == 0x40 for capture in metadata['captures'])
        record['captures'].append(dict(directory=name, status=status, source_parent=metadata.get('source_parent'),
            started_utc=metadata.get('started_utc'), finished_utc=metadata.get('finished_utc')))
        target = out / (name + '.tar.gz')
        with tarfile.open(target, 'w:gz') as archive:
            if name.startswith('mckernel-native-irq-images-'):
                for item in sorted(path.iterdir()):
                    if item.is_file(): archive.add(item, arcname=name + '/' + item.name)
                for relative in ('kernel', 'arch', 'lib', 'cmake', 'host-kernel/native-rust', 'ihk/cokernel', 'ihk/ikc', 'ihk/include'):
                    item = path / 'source' / relative
                    if item.exists(): archive.add(item, arcname=name + '/source/' + relative)
                for relative in ('CMakeLists.txt',): archive.add(path / 'source' / relative, arcname=name + '/source/' + relative)
                for variant in ('fallback', 'legacy-rust', 'native-rust'):
                    for relative in ('kernel', 'CMakeCache.txt', 'compile_commands.json'):
                        item = path / variant / relative
                        if item.exists(): archive.add(item, arcname=name + '/' + variant + '/' + relative)
            else:
                archive.add(path, arcname=name)
        assert target.stat().st_size < 95 << 20, target
        record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name, source=str(path),
            size=target.stat().st_size, sha256=digest(target)))
        for short in ('record.json', 'serial.log', 'debugcon.log'):
            if (path / short).exists(): add(path / short, name + '-' + short + '.gz')
        print('Retained', name, status, flush=True)

    stage = work / 'native-ikc-prototype-20260907-9/staged-source'
    record['current_compiler_inputs'] = []
    for path in sorted(stage.rglob('*')):
        if not path.is_file() or path.suffix not in ('.rs', '.S'): continue
        relative = 'host-kernel/native-rust/' + str(path.relative_to(stage))
        current = repo / relative
        row = dict(path=relative, size=current.stat().st_size, sha256=digest(current),
            compiler_size=path.stat().st_size, compiler_sha256=digest(path), transform='none')
        if current.read_bytes() != path.read_bytes():
            assert path.name in ('ihk_ioctl.rs', 'os_registry.rs', 'smp_resource.rs'), relative
            formatted = out / ('formatted-' + path.name)
            formatted.write_bytes(current.read_bytes())
            command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(formatted)]
            subprocess.run(command, check=True)
            assert formatted.read_bytes() == path.read_bytes(), relative
            row['transform'] = command[:-1]
            add(current, 'native-vdso-service-20260907-unformatted-' + path.name + '.gz')
        record['current_compiler_inputs'].append(row)
    record['current_compiler_input_count'] = len(record['current_compiler_inputs'])
    images = work / 'mckernel-native-irq-images-20260907-13'
    record['native_image'] = identity(images / 'native-rust/kernel/mckernel.img')
    record['native_image'].update(note=[3, 0x00060c00, 7616, 1], entry='0xfffffffffe846c00', loaded_fnv64='aa6419ab7afa5442')
    record['source_inputs'] = []
    for relative in ('kernel/rust/lib.rs', 'kernel/rust/init.rs', 'kernel/rust/syscall_policy.rs', 'kernel/rust/native_vdso.rs',
                     'kernel/rust/x86_setup.rs', 'kernel/CMakeLists.txt', 'host-kernel/native-rust/abi/vdso.rs'):
        current = repo / relative
        assert current.read_bytes() == (images / 'source' / relative).read_bytes(), relative
        row = identity(current); row['path'] = relative
        record['source_inputs'].append(row)
    for name in ('check-native-vdso-service.py', 'build-native-vdso-prototype.py', 'build-mckernel-native-boot-note-images.py',
                 'verify-native-vdso-service-images.py', 'run-native-vdso-service-guest.py', 'retain-native-vdso-service.py'):
        add(work / name, 'native-vdso-service-20260907-' + name + '.gz')
    reference = repo / 'docs/verification/native-vdso-exports-checkpoint-20260907.json'
    record['previous_reference'] = identity(reference)
    record['previous_reference']['path'] = str(reference.relative_to(repo))
    for row in record['artifacts']:
        size, result = 0, hashlib.sha256()
        with gzip.open(out / Path(row['path']).name, 'rb') as stream:
            for data in iter(lambda: stream.read(1 << 20), b''): size += len(data); result.update(data)
        if 'unpacked_sha256' in row:
            assert size == row['unpacked_size'] and result.hexdigest() == row['unpacked_sha256']
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'native-vdso-service-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], 'retained', len(record['artifacts']), 'native vDSO service artifacts', flush=True)
