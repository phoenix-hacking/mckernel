"""Invoke only the existing affected fixture function; preserve completed positive cases."""
from pathlib import Path
import hashlib,json,sys,types
source=Path(__file__).with_name('test_whole_saved_observer.py')
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='a5f0b90cae389898a362bbe8f5d8ccf9604866a10c3371c000a12f435c8429d9'
marker=b"workspace=Path(sys.argv[1]);workspace.mkdir();checks=[]"
assert raw.count(marker)==1
prefix=raw.split(marker)[0]
m=types.ModuleType('_existing_last_negative_function');m.__file__=str(source)
exec(compile(prefix,str(source),'exec'),m.__dict__)
workspace=Path(sys.argv[1]);workspace.mkdir()
result=m.execute('missing_client_refused','missing_client')
assert result['result']=='REFUSED' and result['reason']=='exact new physical retirement record join required'
output=dict(status='PASS_AFFECTED_LAST_NEGATIVE_ONLY',count=1,checks=[result],production_sources_changed=False,root_effects=False)
(workspace/'result.json').write_text(json.dumps(output,sort_keys=True)+'\n')
print(json.dumps(dict(status=output['status'],count=1)))
