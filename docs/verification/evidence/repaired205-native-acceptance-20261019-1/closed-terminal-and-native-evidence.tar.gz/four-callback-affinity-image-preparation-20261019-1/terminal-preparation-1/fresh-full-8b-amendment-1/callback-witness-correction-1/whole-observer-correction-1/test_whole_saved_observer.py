"""Actual observer main through actual prepare_release using saved OS boundaries only."""
from pathlib import Path
import ast,base64,contextlib,copy,hashlib,io,json,os,resource,sys,types
G=Path(__file__).resolve().parent
SOURCE=G/'observe_four_leaf_image_retirement.py'
READBACK=Path('/home/holden/mckernel-work/host-preparation/four-callback-affinity-image-preparation-20261019-1/terminal-preparation-1/fresh-full-8b-amendment-1/source-generation-final-1/actual-failed-observer-readback-1/stdout')
READBACK_SHA='cc71be959de259ec283ed1a194baf9f0497e1901ce4fe30e7400504ebfcd3b8f'
raw=READBACK.read_bytes();assert len(raw)==169031 and hashlib.sha256(raw).hexdigest()==READBACK_SHA
wire=json.loads(raw);expected={'ownership.json','process-00.json'}|{f'readonly-command-{i:02d}.{suffix}' for i in range(4) for suffix in ('json','stdout','stderr')};assert len(wire['rows'])==len(expected) and {r['name'] for r in wire['rows']}==expected
bodies={}
for row in wire['rows']:
 b=base64.b64decode(row['raw_base64'],validate=True);assert len(b)==row['metadata']['size'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert row['metadata']['nlink']==1;bodies[row['name']]=b
commands=[]
for i in range(4):
 stem=f'readonly-command-{i:02d}';row=json.loads(bodies[stem+'.json']);out=bodies[stem+'.stdout'];err=bodies[stem+'.stderr'];assert row['returncode']==0 and not row['timed_out'] and row['launch_error'] is None and not err
 for name,b in [('stdout',out),('stderr',err)]:assert row[name+'_sha256']==row[name+'_retained_sha256']==hashlib.sha256(b).hexdigest() and row[name+'_observed_bytes']==row[name+'_retained_bytes']==len(b) and row[name+'_truncated'] is False
 commands.append((row,out,err))
process=json.loads(bodies['process-00.json']);ownership=json.loads(bodies['ownership.json']);ROOT_LOCK=ownership['root_lock']
class Proxy:
 def __init__(self,base,**changes):self.base=base;self.changes=changes
 def __getattr__(self,k):return self.changes[k] if k in self.changes else getattr(self.base,k)
def blocked(*args,**kwargs):raise AssertionError('unexpected live OS/tool boundary')
def load(path,name):
 m=types.ModuleType(name);m.__file__=str(path);exec(compile(path.read_bytes(),m.__file__,'exec'),m.__dict__);return m
def execute(case,mutation):
 observer=load(SOURCE,'_actual_main_saved_'+case);real_output=observer.OUTPUT;assert not real_output.exists();root=Path(sys.argv[1])/case;root.mkdir();fake_output=root/'observer-output';fixture_lock=root/'lock';fixture_lock.mkdir();lock_file=fixture_lock/Path(ROOT_LOCK['path']).name;lock_file.write_bytes(b'');lock_stat=lock_file.stat();events=[]
 observer.OUTPUT=fake_output
 observer.os=Proxy(os,getuid=lambda:0,geteuid=lambda:0)
 def limits(which,value):
  if which==resource.RLIMIT_AS:assert value==(256<<20,2<<30);resource.setrlimit(which,(256<<20,1<<30))
  else:resource.setrlimit(which,value)
 observer.resource=Proxy(resource,setrlimit=limits)
 observer.validate_observation_release=lambda *args:events.append('TEST_ONLY_RELEASE_AUTHORIZATION_BOUNDARY_STUB')
 saved_cursor=[0]
 def saved_command(argv,limit,retain,*args,**kwargs):
  if saved_cursor[0]<len(commands):
   row,out,err=commands[saved_cursor[0]];assert row['argv']==argv,'exact saved prefix command order';saved_cursor[0]+=1
  else:
   matches=[x for x in commands if x[0]['argv']==argv];assert matches,'unbound saved tool argv';row,out,err=matches[0];events.append('EXPLICIT_SAVED_API_REPLAY_FOR_FINAL_CENSUS')
  assert len(out)<=limit and not err;retain(copy.deepcopy(row),out,err);events.append('SAVED_READONLY_COMMAND');return out
 observer.observed_command=saved_command
 original_validate=observer.validate_artifact_authority
 def actual_validate(review,new_objects=None,engine=None):
  original_validate(review,new_objects,engine);events.append('ACTUAL_CANONICAL_GATE')
  original_directory=engine.directory;original_identity=engine.identity;original_observe=engine.observe_identity;original_census=engine.census;original_prepare=engine.prepare_release
  def directory(path):
   if Path(path)==engine.ROOT_LOCK.parent:return os.open(fixture_lock,os.O_RDONLY|os.O_DIRECTORY),[]
   return original_directory(path)
  engine.directory=directory
  engine.observe_identity=lambda path:copy.deepcopy(ROOT_LOCK) if Path(path)==engine.ROOT_LOCK else original_observe(path)
  engine.identity=lambda st:(27,4) if (st.st_dev,st.st_ino)==(lock_stat.st_dev,lock_stat.st_ino) else original_identity(st)
  caller=[os.getpid(),Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]]
  def saved_process():
   # Explicit TEST-ONLY adaptation of challenge/caller in a deep copy. All
   # publishers, retired owner/waiter ancestry rows and boot remain original.
   p=copy.deepcopy(process);old=p['caller'];p['challenge']=observer.NONCE;p['caller']=caller
   for snapshot in p['snapshots']:
    for row in snapshot:
     if row[0]==old[0]:row[0]=caller[0];row[2]=caller[1]
   engine.validate_process_report(p,observer.NONCE,caller);events.append('SAVED_PROCESS_QUERY_WITH_FIXTURE_CALLER');observer.store('process-%02d.json'%sum(x=='SAVED_PROCESS_QUERY_WITH_FIXTURE_CALLER' for x in events),engine.canonical(p))
  def census():engine.process_absent=saved_process;return original_census()
  engine.census=census
  def prepare(observation,commit,tree):
   result=original_prepare(observation,commit,tree);assert result['status']=='NOT_RELEASED' and result['fetched_source_verified'] is False and result['source_review'] is None and result['execution_review'] is None
   assert len(observation['client_ledger'])==8 and len(observation['selected_files'])>=len(observer.FULL_SOURCE_SHA256)+len(observer.TERMINAL_IMPORT_SHA256)
   events.append('ACTUAL_PREPARE_RELEASE');return result
  engine.prepare_release=prepare
  engine.subprocess=Proxy(engine.subprocess,run=blocked,Popen=blocked,check_output=blocked,call=blocked,check_call=blocked)
 observer.validate_artifact_authority=actual_validate
 observer.subprocess=Proxy(observer.subprocess,run=blocked,Popen=blocked,check_output=blocked,call=blocked,check_call=blocked)
 if mutation=='semantic14':observer.FULL_SOURCE_SHA256=dict(observer.FULL_SOURCE_SHA256,**observer.TERMINAL_IMPORT_SHA256)
 if mutation=='terminal_hash':observer.TERMINAL_IMPORT_SHA256=dict(observer.TERMINAL_IMPORT_SHA256);observer.TERMINAL_IMPORT_SHA256[next(iter(observer.TERMINAL_IMPORT_SHA256))]='0'*64
 if mutation=='missing_client':observer.PIDS=observer.PIDS[:-1]
 stdout=io.StringIO();reason=None
 try:
  with contextlib.redirect_stdout(stdout):observer.main(['--git-commit','a5a199d48fb3b404179e3bbac8c802a18e2597b5','--git-tree','bd58a878ba2f968054727d088facc79b8d1f7158','--observation-release','TEST_ONLY_UNISSUED_RELEASE','--observation-release-sha256','0'*64])
 except RuntimeError as exc:reason=str(exc)
 assert not real_output.exists()
 if mutation is None:
  assert reason is None and events.count('ACTUAL_PREPARE_RELEASE')==1
  metadata=json.loads((fake_output/'new-object-metadata.json').read_text());assert len(metadata['objects'])==74
  observation=json.loads((fake_output/'observation.json').read_text());selected={r['path']:r for r in observation['selected_files']};assert all(selected[p]['sha256']==h for p,h in observer.FULL_SOURCE_SHA256.items()) and len(observer.FULL_SOURCE_SHA256)==11;assert all(selected[p]['sha256']==h for p,h in observer.TERMINAL_IMPORT_SHA256.items())
  assert json.loads((fake_output/'observer-result.json').read_text())['status']=='PASS_READ_ONLY_OBSERVATION_ONLY'
 else:
  expected_reason={'semantic14':'actual full11 source roles required','terminal_hash':'selected terminal import bytes differ','missing_client':'exact new physical retirement record join required'}[mutation];assert reason==expected_reason,(case,reason);assert 'ACTUAL_PREPARE_RELEASE' not in events
 return dict(case=case,result='PASS' if mutation is None else 'REFUSED',reason=reason,actual_prepare_release_calls=events.count('ACTUAL_PREPARE_RELEASE'),saved_command_calls=events.count('SAVED_READONLY_COMMAND'),process_boundary='STUBBED_SAVED_ACTUAL_WITH_FIXTURE_CALLER',output=str(fake_output))
workspace=Path(sys.argv[1]);workspace.mkdir();checks=[]
for name,mutation in [('whole_actual_main',None),('semantic14_refused','semantic14'),('terminal_hash_refused','terminal_hash'),('missing_client_refused','missing_client')]:checks.append(execute(name,mutation))
result=dict(status='PASS_WHOLE_SAVED_ACTUAL_MAIN_AND_THREE_REFUSALS_ONLY',count=len(checks),checks=checks,root_effects=False,live_tool_invocations=0,live_process_queries=0,test_only_boundaries=['getuid/geteuid','release authorization','root-lock FD identity','saved Docker/findmnt','saved process challenge/caller'],actual_full_main=True,actual_prepare_release=True,native_acceptance=False,cleanup_authorized=False)
(workspace/'result.json').write_text(json.dumps(result,sort_keys=True)+'\n');print(json.dumps(dict(status=result['status'],count=len(checks))))
