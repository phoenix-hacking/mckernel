import argparse,fcntl,hashlib,json,os,resource,time,types
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--release',required=True);p.add_argument('--sha256',required=True);p.add_argument('--policy',required=True);p.add_argument('--policy-sha256',required=True);args=p.parse_args()
B=Path(__file__).resolve().parent;policy=Path(args.policy);assert policy.parent==B
assert hashlib.sha256(policy.read_bytes()).hexdigest()==args.policy_sha256
ops=json.loads(policy.read_bytes())['exact_operations'];assert len(ops)==2 and [op['role'] for op in ops]==['cleanup','postjoin-readback'];release=Path(args.release);raw=release.read_bytes();assert hashlib.sha256(raw).hexdigest()==args.sha256
source=B/'root-case-critical-capture-failed12.py';assert hashlib.sha256(source.read_bytes()).hexdigest()=='5c884624b748b862aa1b48a369d3ee758f311ab6c70e82f1346c93d6b478b10d'
m=types.ModuleType('_critical_capture');exec(compile(source.read_bytes(),str(source),'exec'),m.__dict__);m.a=types.SimpleNamespace(policy=str(policy));m.results=[]
os.umask(0o077);os.sched_setaffinity(0,{6});assert os.getuid()==1000 and resource.getrlimit(resource.RLIMIT_CPU)==(-1,-1)
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7bfc5687-6c04-4d15-84eb-b92ab9a55dcb'
state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_bytes());assert state.get('stop_reason') is None and state['last_rate_limits']['primary']['usedPercent']<97
capacity={}
for path,floor in [('/home/holden',17179869184),('/home/holden/mckernel-work/scratch',12884901888)]:
 v=os.statvfs(path);free=v.f_bavail*v.f_frsize;assert free>=floor+671088640;capacity[path]=free
fd=os.open('/run/lock/mckernel-development.lock',os.O_RDONLY|os.O_NOFOLLOW)
try:
 st=os.fstat(fd);assert (st.st_dev,st.st_ino)==(27,4);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(fd,fcntl.LOCK_UN)
finally:os.close(fd)
root=Path(ops[0]['status_path']).parent;root.mkdir(mode=0o700)
m.write(root/'outer-admission.json',dict(timestamp=time.time(),capacity=capacity,used_percent=state['last_rate_limits']['primary']['usedPercent'],inherited_cpu_limits=list(resource.getrlimit(resource.RLIMIT_CPU)),pid=os.getpid(),start=m.start(os.getpid()),source=m.ref(source),release=m.ref(release)))
dest=Path(ops[0]['argv'][ops[0]['argv'].index('--release')+1]);assert not dest.exists();m.put(dest,raw)
for op in ops:
 assert op['argv'].count('BIND_EXACT_INDEPENDENT_CLEANUP_RELEASE_SHA256')==1
 op['argv']=[args.sha256 if x=='BIND_EXACT_INDEPENDENT_CLEANUP_RELEASE_SHA256' else x for x in op['argv']]
 row=m.run(op)
 if op['role']=='cleanup':
  result=json.loads(Path(op['stdout_path']).read_bytes());assert result['status']=='PASS_EXECUTED' and result['terminal'] is True and result['container_absent'] is True and result['container_id']=='6f490dad40bf7de8e293762c9933bc444db19ecf01c1c57be6bd390d2da7dc5c'
  try:os.killpg(row['pid'],0)
  except ProcessLookupError:pass
  else:raise RuntimeError('cleanup group remains; no postjoin')
 if op['role']=='postjoin-readback':
  try:os.killpg(row['pid'],0)
  except ProcessLookupError:pass
  else:raise RuntimeError('postjoin group remains')
 print(json.dumps({k:row[k] for k in ['role','returncode','direct_child_joined','elapsed_seconds']}),flush=True)
m.write(root/'wholejoin.json',dict(status='PASS_TWO_DIRECT_JOINS_ONLY',results=[dict(role=r['role'],returncode=r['returncode'],direct_child_joined=r['direct_child_joined'],elapsed_seconds=r['elapsed_seconds']) for r in m.results],physical_acceptance=False))
