"""One owned, file-backed actual-caller fixture under the existing cheap profile."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

F = Path(__file__).resolve().parent
RUN = F / 'actual-publication-projection-run-1'

def metadata(path):
    s = path.stat()
    return dict(path=str(path), device=s.st_dev, inode=s.st_ino, mode=s.st_mode, uid=s.st_uid, gid=s.st_gid, nlink=s.st_nlink, size=s.st_size, mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def main():
    start = time.monotonic()
    deadline = start + 28
    assert os.sched_getaffinity(0) == {6}
    pins = json.loads((F / 'publication-projection-source-pins.json').read_bytes())
    for row in pins.values():
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
    available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    fs = os.statvfs('/home/holden/mckernel-work/scratch')
    scratch = fs.f_bavail * fs.f_frsize
    host = os.statvfs('/home/holden')
    host_free = host.f_bavail * host.f_frsize
    assert min(available, host_free) > (16 << 30) + (640 << 20) + (64 << 20)
    assert scratch > (12 << 30) + (640 << 20) + (64 << 20)
    RUN.mkdir(mode=0o700)
    argv = [sys.executable, '-I', '-B', str(F / 'emit_publication_projection.py'), '--final']
    with (RUN / 'stdout').open('xb') as stdout, (RUN / 'stderr').open('xb') as stderr:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'})
        timed_out = False
        try:
            rc = child.wait(timeout=max(0.1, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                rc = child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                rc = child.wait(timeout=1)
        stdout.flush()
        stderr.flush()
    try:
        os.killpg(child.pid, 0)
        group_absent = False
    except ProcessLookupError:
        group_absent = True
    status = dict(argv=argv, pid=child.pid, returncode=rc, direct_child_joined=True, process_group_absent=group_absent, timed_out=timed_out, elapsed_seconds=time.monotonic() - start, host_available=available, host_free=host_free, scratch_available=scratch, stdout=metadata(RUN / 'stdout'), stderr=metadata(RUN / 'stderr'), source_pins=pins, root=False)
    with (RUN / 'status.json').open('x') as stream:
        json.dump(status, stream, sort_keys=True, indent=2)
        stream.write('\n')
    print(json.dumps(dict(returncode=rc, direct_child_joined=True, process_group_absent=group_absent, elapsed_seconds=status['elapsed_seconds'], capture=str(RUN))))
    assert group_absent and not timed_out
    return rc

if __name__ == '__main__':
    sys.exit(main())
