"""Dispatcher capture/authorized data projection for the exact failed-build readonly set."""
import argparse,fcntl,hashlib,json,os,signal,stat,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--decision',required=True);p.add_argument('--decision-sha256',required=True);p.add_argument('--policy',required=True);p.add_argument('--policy-sha256',required=True);a=p.parse_args()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked(p,h):assert digest(p)==h;return json.loads(Path(p).read_text())
def canon(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def put(p,b):
 fd=os.open(str(p),os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def write(p,v):put(p,canon(v))
def ref(p):return dict(path=str(p),sha256=digest(p))
def start(pid):return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
def ident(s):return dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
d=checked(a.decision,a.decision_sha256);policy=checked(a.policy,a.policy_sha256);C=Path(__file__).resolve().parent
os.umask(0o077);os.sched_setaffinity(0,{6});assert os.getuid()==1000
for path,floor,packet in [('/home/holden',17179869184,671088640),('/home/holden/mckernel-work/scratch',12884901888,0)]:
 v=os.statvfs(path);assert v.f_bavail*v.f_frsize>=floor+packet+536870912
state=json.loads(Path('/home/holden/mckernel/.git/os-autopilot/state.json').read_text());assert state.get('stop_reason') is None and state['last_rate_limits']['primary']['usedPercent']<97
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='7bfc5687-6c04-4d15-84eb-b92ab9a55dcb'
fd=os.open('/run/lock/mckernel-development.lock',os.O_RDONLY|os.O_NOFOLLOW);s=os.fstat(fd);assert (s.st_dev,s.st_ino)==(27,4);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
closure=json.loads((C/'failure-terminal-source-closure.json').read_text())
for path,expected in closure['unchanged_accepted_import_closure'].items():assert digest(path)==expected
for r in json.loads((C/'failure-terminal-publication-allowlist.json').read_text())['rows']:assert digest(r['source'])==r['sha256']
assert d['operations']==policy['operations']
ops=policy['operations'];root=Path(ops[0]['status_path']).parent;root.mkdir(mode=0o700)
write(root/'outer-identity.json',dict(pid=os.getpid(),start=start(os.getpid()),decision=ref(a.decision),affinity=[6],dispatcher_source=ref(__file__)))
release_ref=d['exact_observer_release'];raw=Path(release_ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==release_ref['sha256'];dest=Path(ops[0]['argv'][ops[0]['argv'].index('--observation-release')+1]);put(dest,raw);assert ops[0]['argv'][ops[0]['argv'].index('--observation-release-sha256')+1]==release_ref['sha256'];results=[]
def run(op):
 argv=op['argv'];outp=Path(op['stdout_path']);errp=Path(op['stderr_path']);sp=Path(op['status_path']);write(Path(str(sp)+'.command.json'),dict(argv=argv,role=op['role'],policy=ref(a.policy)));t=time.monotonic();observer_error=None;cs=None
 with outp.open('xb') as out,errp.open('xb') as err:
  child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  try:cs=start(child.pid);write(Path(str(sp)+'.child.json'),dict(pid=child.pid,start=cs,pgid=child.pid,argv=argv))
  except BaseException as e:observer_error=repr(e)
  try:rc=child.wait(timeout=35)
  except subprocess.TimeoutExpired:
   observer_error='wall timeout; owned retirement required'
   if cs and start(child.pid)==cs:
    try:os.killpg(child.pid,signal.SIGTERM);rc=child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);rc=child.wait(timeout=5)
   else:raise RuntimeError('uncertain child identity; records retained')
  out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno());held={k:ident(os.fstat(f.fileno())) for k,f in [('stdout',out),('stderr',err)]}
 streams={}
 for k,path in [('stdout',outp),('stderr',errp)]:
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
  try:
   ss=os.fstat(fd);assert ident(ss)==held[k]==ident(os.stat(path,follow_symlinks=False));assert stat.S_ISREG(ss.st_mode) and ss.st_uid==1000 and ss.st_nlink==1 and stat.S_IMODE(ss.st_mode)==0o600 and ss.st_size<33554432
   with os.fdopen(os.dup(fd),'rb') as h:sha=hashlib.sha256(h.read()).hexdigest()
   streams[k]=dict(path=str(path),sha256=sha,metadata=ident(ss))
  finally:os.close(fd)
 row=dict(role=op['role'],argv=argv,pid=child.pid,start=cs,returncode=rc,direct_child_joined=True,observer_error=observer_error,elapsed_seconds=time.monotonic()-t,streams=streams);write(sp,row);results.append(row)
 assert rc==0 and observer_error is None and streams['stderr']['metadata']['size']==0,op['role'];return row
try:
 run(ops[0]);run(ops[1]);summary=json.loads(Path(ops[1]['stdout_path']).read_text());assert summary['status']=='PASS_EXACT_FINITE_OBSERVER_READBACK_ONLY' and summary['cleanup_authorized'] is False and summary['result']['status']=='PASS_READ_ONLY_OBSERVATION_ONLY';hashes=summary['file_sha256'];names=['observer-result.json','observation.json','cleanup-release-draft.json','new-object-metadata.json','ownership.json'];assert set(hashes)==set(names) and all(len(x)==64 and all(c in '0123456789abcdef' for c in x) for x in hashes.values());hp=Path(ops[2]['argv'][ops[2]['argv'].index('--expected-hashes')+1]);write(hp,hashes);ops[2]['argv'][-1]=digest(hp);run(ops[2])
 metadata=json.loads(Path(ops[2]['stdout_path']).read_text());assert metadata['status']=='PASS_EXACT_ORIGINAL_FIVE_FD_METADATA_ONLY' and metadata['file_sha256']==hashes and metadata['members']==5
 objects=metadata['objects'];assert len(objects)==5
 for name,obj in zip(names,objects):assert Path(obj['path']).name==name and obj['sha256']==hashes[name] and obj['uid']==obj['gid']==0 and obj['mode']=='0o600' and obj['nlink']==1 and obj['size']>0
 total=((sum(512+((x['size']+511)//512)*512 for x in objects)+1024+10239)//10240)*10240;assert total<33554432
 write(root/'whole-three-stage-result.json',dict(status='PASS_THREE_READONLY_OPERATIONS_COMPLETION_ONLY',stages=3,results=results,cleanup_authorized=False,native_acceptance=False));print('PASS three readonly stages; CPU6 released; result',root/'whole-three-stage-result.json')
except BaseException as e:
 write(root/'failure.json',dict(status='FAIL_STOP_FIRST_FAILURE_NO_REPLAY',error=repr(e),completed=len(results),results=results));print('STOP',type(e).__name__,str(e),'completed',len(results))
 if results:print(Path(ops[len(results)-1]['stderr_path']).read_text()[-1800:])
 raise
