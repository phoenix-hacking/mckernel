"""Author DATA only for the finite remaining case; no operation is executed."""
from pathlib import Path
import ast
import hashlib
import json

F = Path(__file__).resolve().parent
ROOT_READONLY = F / 'actual-root-readonly-1'
ROOT_CRITICAL = F / 'actual-root-cleanup-1'

def ref(path):
    path = Path(path)
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)

def put(name, value):
    with (F / name).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')

def transport(soft, hard, cpu, cap):
    return ['/usr/bin/taskset', '-c', '6', '/usr/bin/prlimit', '--as=' + str(soft) + ':' + str(hard), '--cpu=' + cpu, '--fsize=' + str(cap), '--core=0', '--nofile=256', '--', '/usr/bin/sudo', '-A', '/home/holden/anaconda3/bin/python3', '-I', '-B']

def main():
    tree = ast.parse((F / 'export_raw_five.py').read_text())
    assignments = {node.targets[0].id: node.value for node in tree.body if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
    names = list(ast.literal_eval(assignments['NAMES']))
    cap = ast.literal_eval(assignments['CAP'])
    output = F / 'root-observation-new205-failed-observation-1'
    command = eval(compile(ast.Expression(assignments['COMMAND']), '<fixed tar argv>', 'eval'), {'__builtins__': {}, 'str': str, 'list': list, 'OUTPUT': output, 'NAMES': names}, {})
    payload = dict(schema='mckernel.reset-image.raw-five-export-release.v1', status='NOT_RELEASED_ORIGINAL_FIVE_NOT_OBSERVED', author='/root/clone_thread_affinity_rust_repair', helper_sha256=ref(F / 'export_raw_five.py')['sha256'], summary_sha256=ref(F / 'readback_observer.py')['sha256'], output=str(output), argv=command, names=names, max_archive_bytes=cap, file_sha256=None, observer_status=None, summary_status=None, source_review=None, execution_review=None, source_publication_proof=ref(F / 'actual-fetched-source-publication-proof-1.json'))
    put('raw-five-release-payload-PREBOUND-DATA.json', payload)
    raw = dict(schema='mckernel.new205.failure-raw5-operation.v1', state='NOT_RELEASED_PREBOUND_DATA_ONLY', author='/root/clone_thread_affinity_rust_repair', argv_template=transport(1073741824, 1073741824, '30', 33554432) + [str(F / 'export_raw_five.py'), '--release', str(F / 'raw-five-export-release.json'), '--release-sha256', 'ACTUAL_INDEPENDENT_RAW5_RELEASE_SHA256'], required_uid=0, cpus=[6], jobs=1, address_space_limits_bytes=[1073741824, 1073741824], cpu_limits_seconds=[30, 30], file_limit_bytes=33554432, parent_wait_seconds=35, term_grace_seconds=5, stdout=str(ROOT_READONLY / 'raw-five-export.tar'), stderr=str(ROOT_READONLY / 'raw-five-export.stderr'), status=str(ROOT_READONLY / 'raw-five-export.status.json'), command=str(ROOT_READONLY / 'raw-five-export.command.json'), child=str(ROOT_READONLY / 'raw-five-export.child.json'), required_returncode=0, required_stderr_bytes=0, full_stream_FD_metadata_required=True, direct_join_and_group_absence_required=True, original_five_names=names, external_gate_required='Independent actual five original FDs, ordered names, full metadata/hash from distinct actual observer/summary and metadata captures; placeholders cannot execute.', raw5_payload=ref(F / 'raw-five-release-payload-PREBOUND-DATA.json'), cleanup_authority=False)
    put('raw-five-operation-PREBOUND-DATA.json', raw)
    release, result = F / 'physical-cleanup-release.json', F / 'actual-cleanup-result.json'
    marker = 'ACTUAL_INDEPENDENT_PHYSICAL_CLEANUP_RELEASE_SHA256'
    operations = [dict(role='cleanup', argv_template=transport(2147483648, 2147483648, 'unlimited:unlimited', 134217728) + [str(F / 'cleanup_failed.py'), '--execute', '--release', str(release), '--release-sha256', marker], address_space_limits_bytes=[2147483648, 2147483648], stdout=str(result), stderr=str(ROOT_CRITICAL / 'cleanup.stderr'), status=str(ROOT_CRITICAL / 'cleanup.status.json'), command=str(ROOT_CRITICAL / 'cleanup.command.json'), child=str(ROOT_CRITICAL / 'cleanup.child.json'), success_stdout_status='PASS_EXECUTED', success_stderr='empty'), dict(role='postjoin-readback', argv_template=transport(1073741824, 2147483648, 'unlimited:unlimited', 134217728) + [str(F / 'postjoin_readback.py'), str(release), marker, str(result)], address_space_limits_bytes=[1073741824, 2147483648], stdout=str(ROOT_CRITICAL / 'postjoin-readback.tar'), stderr=str(ROOT_CRITICAL / 'postjoin-readback.stderr'), status=str(ROOT_CRITICAL / 'postjoin-readback.status.json'), command=str(ROOT_CRITICAL / 'postjoin-readback.command.json'), child=str(ROOT_CRITICAL / 'postjoin-readback.child.json'), success_stderr=dict(status='PASS_CLEANUP_POSTJOIN_READBACK_ONLY', members=5, actual_object_rows=24, application_acceptance=False))]
    for operation in operations:
        operation.update(required_uid=0, cpus=[6], jobs=1, cpu_limits_seconds=[-1, -1], file_limit_bytes=134217728, parent_wait_seconds=None, wall_kill=False, signal_branch=False, required_returncode=0, direct_child_join_required=True, full_stream_FD_metadata_required=True, process_group_absent_before_successor=True)
    put('cleanup-and-postjoin-PREBOUND-DATA.json', dict(schema='mckernel.new205.failure-cleanup-postjoin-bindings.v1', status='NOT_RELEASED_PREBOUND_DATA_ONLY', author='/root/clone_thread_affinity_rust_repair', operations=operations, original_observation=None, raw_five_export=None, cleanup_payload=None, execution_review=None, canonical_cleanup_release='compact sorted UTF8 JSON NO LF; exact independent source/execution review required', expected_postjoin_members=5, expected_object_rows=24, full_failed_host_case_preserved=True, source_publication=ref(F / 'actual-fetched-source-publication-proof-1.json'), cleanup_authorized=False, physical_release=False))
    print('PREBOUND_LATE_DATA raw5=1 critical=2 original5=NOT_OBSERVED execution=0')

if __name__ == '__main__':
    main()
