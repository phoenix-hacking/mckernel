def main():
    for name in unresolved_names():
        parser.add_argument('--' + name)
