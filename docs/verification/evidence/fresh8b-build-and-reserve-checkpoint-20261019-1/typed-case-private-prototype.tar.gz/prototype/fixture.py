"""One finite offline actual-saved-record replay plus named refusals."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,socket,subprocess,sys
Q=Path(__file__).resolve().parent

def forbidden(*args,**kwargs):raise AssertionError('process/socket/legacy-engine execution forbidden')
def main():
    assert os.getuid()==os.geteuid()==1000
    spec=importlib.util.spec_from_file_location('typed_case_prototype',Q/'typed_terminal_case.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    subprocess.Popen=forbidden;os.execve=forbidden;os.system=forbidden;socket.socket=forbidden
    inputs=json.loads((Q/'saved-inputs.json').read_bytes());work=Q/'fixture-work-1';work.mkdir(mode=0o700)
    cases=module.generate(inputs);assert [case['kind'] for case in cases]==['FULL','REMAINING','FAILURE']
    assert all(case['execution_authority'] is False and case['cleanup_authority'] is False and case['artifact_acceptance'] is False for case in cases)
    assert all(case['pending'] and all(command['import_interface']['inspection']=='AST_ONLY_NOT_IMPORTED' and not command['import_interface']['case_data_parameter'] for command in case['commands']) for case in cases)
    enginepaths={command['engine']['path'] for case in cases for command in case['commands']}
    assert not any(getattr(value,'__file__',None) in enginepaths for value in sys.modules.values())
    (work/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    failures=[]
    def refuses(name,call):
        try:call()
        except module.Refusal as error:failures.append(dict(name=name,message=str(error)));return
        raise AssertionError('missing refusal: '+name)
    def changed(name,data):
        path=work/(name+'.json');path.write_text(json.dumps(data,indent=2)+'\n');return vars(module.reference(path))
    refuses('unknown_case_kind',lambda:module.build_case('SUCCESS',inputs['FULL']))
    bad=dict(inputs['FULL']['record']);bad['bytes']=True
    refuses('bool_reference_size',lambda:module.Reference.parse(bad))
    bad=dict(inputs['FULL']['record']);bad['sha256']='0'*64
    refuses('changed_source_record_hash',lambda:module.Reference.parse(bad).json())
    full=module.Reference.parse(inputs['FULL']['record']).json();changedfull=copy.deepcopy(full);changedfull['guard_argv'][changedfull['guard_argv'].index('--request-sha256')+1]='0'*64
    refuses('request_command_mismatch',lambda:module.build_case('FULL',{'record':changed('wrong-request',changedfull)}))
    sources=module.Reference.parse(full['source_map']).json();argv=list(full['guard_argv'])+['--invented-option'];pins=sources['source_sha256']
    refuses('unsupported_existing_engine_flag',lambda:module.Command.parse('guard',argv,pins))
    failure=copy.deepcopy(inputs['FAILURE']);owner=module.Reference.parse(failure['owner_receipt']).json();owner['status']='PASS';failure['owner_receipt']=changed('not-failed-owner',owner)
    refuses('success_owner_is_not_failure_case',lambda:module.build_case('FAILURE',failure))
    failure=copy.deepcopy(inputs['FAILURE']);objects=module.Reference.parse(failure['retained_objects']).json();objects.append(copy.deepcopy(objects[0]));failure['retained_objects']=changed('duplicate-pair',objects)
    refuses('duplicate_retention_pair',lambda:module.build_case('FAILURE',failure))
    failure=copy.deepcopy(inputs['FAILURE']);objects=module.Reference.parse(failure['retained_objects']).json();objects[0]['retained'].pop('ctime_ns');failure['retained_objects']=changed('missing-fd-field',objects)
    refuses('missing_engine_fd_field',lambda:module.build_case('FAILURE',failure))
    failure=copy.deepcopy(inputs['FAILURE']);record=module.Reference.parse(failure['record']).json();target=next(stage for stage in record['ordered_stages'] if 'expected_FD_cardinality' in stage);target['expected_FD_cardinality']+=2;failure['record']=changed('wrong-fd-cardinality',record)
    refuses('stale_per_case_fd_count',lambda:module.build_case('FAILURE',failure))
    failure=copy.deepcopy(inputs['FAILURE']);pub=module.Reference.parse(failure['publication_proof']).json();pub['row_count']+=1;failure['publication_proof']=changed('wrong-publication-count',pub)
    refuses('stale_publication_count',lambda:module.build_case('FAILURE',failure))
    result=dict(status='PASS_OFFLINE_SAVED_SHAPES_AND_REFUSALS_ONLY',saved_case_shapes=len(cases),refusals=failures,derived=[dict(kind=case['kind'],**case['derivations']) for case in cases],legacy_engine_imports=0,process_operations=0,socket_operations=0,execution_authority=False,known_gap='Legacy pinned engines do not expose main(case); current prototype validates/emits DATA only. A reviewed parameterized entrypoint is required before execution.')
    with (work/'result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(dict(status=result['status'],saved_case_shapes=len(cases),refusals=len(failures),legacy_engine_imports=0,execution_authority=False)))
if __name__=='__main__':main()
