"""Finite offline FULL/REMAINING/FAILURE case normalizer; never a launcher.

Existing engines are authenticated and inspected as AST, never imported or
copied. Saved source/review records remain authoritative only for their original
scope. This prototype cannot grant execution, cleanup or artifact acceptance.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import argparse,ast,hashlib,json,os,re,stat

class Refusal(ValueError): pass
def need(ok,message):
    if not ok: raise Refusal(message)
def unique(items):
    result={}
    for key,value in items:
        need(key not in result,'duplicate JSON key');result[key]=value
    return result
@dataclass(frozen=True)
class Reference:
    path:str
    sha256:str
    bytes:int
    @classmethod
    def parse(cls,row):
        need(type(row) is dict and set(row)=={'path','sha256','bytes'},'reference shape')
        need(type(row['path']) is str and Path(row['path']).is_absolute(),'absolute reference')
        need(type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']) is not None,'reference digest')
        need(type(row['bytes']) is int and row['bytes']>=0,'reference size')
        return cls(**row)
    def read(self,limit=4*1024**2):
        path=Path(self.path);need(not path.is_symlink() and path.resolve(strict=True)==path,'canonical reference')
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        with os.fdopen(fd,'rb') as f:
            before=os.fstat(f.fileno());need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size==self.bytes<=limit,'bounded regular reference')
            raw=f.read(limit+1);after=os.fstat(f.fileno())
            fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
            key=lambda value:tuple(getattr(value,k) for k in fields)
            need(key(before)==key(after)==key(path.lstat()),'reference changed')
        need(len(raw)==self.bytes and hashlib.sha256(raw).hexdigest()==self.sha256,'reference bytes/hash')
        return raw
    def json(self):return json.loads(self.read(),object_pairs_hook=unique)

def engine_descriptor(row):
    fields={'path','device','inode','uid','gid','mode','size','nlink','mtime_ns','ctime_ns','sha256'}
    need(type(row) is dict and set(row)==fields,'full engine FD fields')
    need(type(row['path']) is str and Path(row['path']).is_absolute(),'engine FD absolute path')
    need(all(type(row[key]) is int and row[key]>=0 for key in ('device','inode','uid','gid','size','nlink','mtime_ns','ctime_ns')) and row['nlink']==1,'typed engine FD integers/link')
    need(type(row['mode']) is str and re.fullmatch('0o[0-7]+',row['mode']) is not None and row['mode']==oct(int(row['mode'],8)),'typed engine FD permission mode')
    need(type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']) is not None,'engine FD digest')

def reference(path):
    p=Path(path);return Reference(str(p),hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)

def engine_interface(ref):
    tree=ast.parse(ref.read(),filename=ref.path)
    functions={node.name:dict(positional=[a.arg for a in node.args.posonlyargs+node.args.args],keyword_only=[a.arg for a in node.args.kwonlyargs],vararg=node.args.vararg.arg if node.args.vararg else None,kwarg=node.args.kwarg.arg if node.args.kwarg else None) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
    guarded_main=any(isinstance(node,ast.If) and isinstance(node.test,ast.Compare) and isinstance(node.test.left,ast.Name) and node.test.left.id=='__name__' and any(isinstance(value,ast.Constant) and value.value=='__main__' for value in node.test.comparators) for node in tree.body)
    # Some accepted dispatchers intentionally execute their module body.
    # Record that interface as non-import-callable; never import it here.
    imports=[]
    for node in tree.body:
        if isinstance(node,ast.Import):imports.extend(dict(module=item.name,names=[]) for item in node.names)
        if isinstance(node,ast.ImportFrom):imports.append(dict(module=node.module,names=[item.name for item in node.names]))
    flags=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='add_argument':
            flags.extend(arg.value for arg in node.args if isinstance(arg,ast.Constant) and isinstance(arg.value,str) and arg.value.startswith('--'))
    return dict(engine=asdict(ref),entrypoint='main' if 'main' in functions else '__main__ block (not import-callable)' if guarded_main else 'module-body CLI (not import-callable)',functions=functions,imports=imports,cli_flags=sorted(set(flags)),case_data_parameter=('main' in functions and ('case' in functions['main']['positional'] or 'case' in functions['main']['keyword_only'])),inspection='AST_ONLY_NOT_IMPORTED')

@dataclass(frozen=True)
class Command:
    role:str
    argv:tuple[str,...]
    engine:Reference
    late_parameters:tuple[str,...]
    @classmethod
    def parse(cls,role,argv,pins):
        need(type(role) is str and bool(role) and type(argv) is list and bool(argv) and all(type(x) is str and bool(x) and '\0' not in x for x in argv),'command string vector')
        scripts=[x for x in argv if x.startswith('/') and x.endswith('.py')]
        need(len(scripts)==1,'one existing script entrypoint')
        script=scripts[0];need(script in pins,'script absent from genuine source map')
        ref=reference(script);need(ref.sha256==pins[script],'pinned engine source differs')
        interface=engine_interface(ref)
        for flag in argv[argv.index(script)+1:]:
            if flag.startswith('--'):need(flag.split('=',1)[0] in interface['cli_flags'],'unknown actual engine CLI flag')
        late=tuple(x for x in argv if x.startswith(('PENDING','FINAL_','ACTUAL_')))
        return cls(role,tuple(argv),ref,late)

@dataclass(frozen=True)
class Case:
    kind:str
    record:Reference
    commands:tuple[Command,...]
    source_map:Reference|None
    derivations:dict
    pending:tuple[str,...]
    def data(self):
        return dict(schema='mckernel.offline.typed-terminal-case-prototype.v1',kind=self.kind,record=asdict(self.record),commands=[dict(role=c.role,argv=list(c.argv),engine=asdict(c.engine),late_parameters=list(c.late_parameters),import_interface=engine_interface(c.engine)) for c in self.commands],source_map=asdict(self.source_map) if self.source_map else None,derivations=self.derivations,pending=list(self.pending),execution_authority=False,cleanup_authority=False,artifact_acceptance=False)


def build_case(kind,inputs):
    need(kind in ('FULL','REMAINING','FAILURE'),'case discriminant')
    record=Reference.parse(inputs['record']);row=record.json()
    if kind in ('FULL','REMAINING'):
        source=Reference.parse(row['source_map']);sources=source.json();pins=dict(sources['source_sha256'])
        dispatcher=sources['additional_dispatcher'];pins[dispatcher['path']]=dispatcher['sha256']
        guard_key='guard_argv' if kind=='FULL' else 'actual_guard_child_argv'
        commands=tuple(Command.parse(role,row[key],pins) for role,key in (('dispatcher','dispatcher_argv'),('guard',guard_key)))
        guard=commands[1].argv
        request_path=guard[guard.index('--request')+1];request_sha=guard[guard.index('--request-sha256')+1]
        need(re.fullmatch('[0-9a-f]{64}',request_sha) is not None,'actual request digest')
        request=row['actual_request' if kind=='FULL' else 'request'];need(request['path']==request_path and request['sha256']==request_sha,'request/guard command join')
        derived=dict(source_pin_count=len(sources['source_sha256']),publication_rows=len(sources.get('publication_rows',[])),dispatcher=dispatcher,request=dict(path=request_path,sha256=request_sha),command_count=len(commands))
        pending=('genuine final one-shot release hash and independent execution authority','fresh live capacity/owner/physical-predecessor gates','legacy engines have CLI/global interfaces; no reviewed typed-case import entrypoint yet')
        return Case(kind,record,commands,source,derived,pending)
    need(set(inputs)=={'record','owner_receipt','retained_objects','original_authorities','publication_proof','helper_pins'},'failure typed input fields')
    owner=Reference.parse(inputs['owner_receipt']).json();need(owner['status']=='FAIL' and owner['exit_code']!=0 and owner['retired'] is True,'genuine completed failed owner required')
    objects=Reference.parse(inputs['retained_objects']).json();originals=Reference.parse(inputs['original_authorities']).json();publication=Reference.parse(inputs['publication_proof']).json();helpers=Reference.parse(inputs['helper_pins']).json()
    need(type(objects) is list and type(originals) is list and bool(objects),'finite actual retention lists')
    raw={(x['original']['path'],x['retained']['path']):x for x in objects}
    declared={(x['original']['path'],x['retained']):x for x in originals}
    need(len(raw)==len(objects)==len(declared)==len(originals) and set(raw)==set(declared),'actual retention cardinality/path join')
    need(len({x['original']['path'] for x in objects})==len({x['retained']['path'] for x in objects})==len(objects),'unique source/destination identities')
    need(len({x['kind'] for x in originals})==len(originals),'unique original role names')
    for key,pair in raw.items():
        need(set(pair)=={'original','retained','outside_generic_receipt_inventory'} and pair['outside_generic_receipt_inventory'] is True,'actual engine pair shape')
        engine_descriptor(pair['original']);engine_descriptor(pair['retained'])
        need(pair['original']==declared[key]['original'] and pair['original']['size']==pair['retained']['size'] and pair['original']['sha256']==pair['retained']['sha256'],'per-side original authority/retained bytes join')
    pubrows=publication['publication_rows'];need(publication['all_fetched_blobs_verified'] is True and publication['row_count']==len(pubrows)==len({x['relative'] for x in pubrows}),'actual publication cardinality')
    pins={x['source']:x['sha256'] for x in pubrows}
    for value in helpers.values():need(pins[value['path']]==value['sha256'],'helper/publication source join')
    commands=tuple(Command.parse(stage['role'],stage['argv'],pins) for stage in row['ordered_stages'])
    for stage in row['ordered_stages']:
        if 'expected_FD_cardinality' in stage:need(stage['expected_FD_cardinality']==2*len(objects),'derived actual FD cardinality')
    derived=dict(retained_pair_count=len(objects),engine_FD_count=sum(len([pair['original'],pair['retained']]) for pair in objects),publication_rows=len(pubrows),helper_pin_count=len(helpers),command_count=len(commands),failed_owner_container=owner['container_id'],failed_owner_status=owner['status'],physical_cleanup_accepted=False)
    pending=('draft observer/raw-five/cleanup stage releases remain independently required','publication proves source bytes only, not execution authority','legacy global main() interfaces require a reviewed typed-case engine entrypoint before reuse')
    return Case(kind,record,commands,None,derived,pending)

def generate(inputs):
    need(type(inputs) is dict and set(inputs)=={'FULL','REMAINING','FAILURE'},'exact finite selected cases')
    return [build_case(kind,inputs[kind]).data() for kind in ('FULL','REMAINING','FAILURE')]

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--inputs',required=True);p.add_argument('--inputs-sha256',required=True);p.add_argument('--output',required=True);args=p.parse_args()
    source=reference(args.inputs);need(source.sha256==args.inputs_sha256,'input binding digest')
    result=dict(status='VALIDATED_SAVED_CASE_SHAPES_ONLY',cases=generate(source.json()),execution_authority=False)
    with Path(args.output).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(dict(status=result['status'],cases=len(result['cases']),execution_authority=False)))
if __name__=='__main__':main()
