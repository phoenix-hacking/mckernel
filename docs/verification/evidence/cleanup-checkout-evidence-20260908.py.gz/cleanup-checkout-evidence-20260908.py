"""Delete only exact committed evidence copies from enumerated scratch checkouts."""
from pathlib import Path
import importlib.util
import json
import os
import stat
import sys

WORK = Path('/home/holden/mckernel-work/scratch')
REPO = Path('/home/holden/mckernel')
PLAN = WORK / 'storage-checkout-evidence-20260908-plan.json'
REPORT = WORK / 'storage-checkout-evidence-20260908-report.json'
AFTER = WORK / 'storage-checkout-evidence-after-trim-20260908.json'
spec = importlib.util.spec_from_file_location('storage_base', WORK / 'cleanup-archived-captures-20260908-3.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

CHECKOUTS = {
    'compat-source-checkpoint-20260907', 'compat-source-pageattrs-20260907',
    'native-cpu-validation-20260907', 'native-image-full-integration-20260907-1',
    'native-irq-transport-full-integration-20260907-1',
    'native-memory-integration-20260907', 'native-os-resource-integration-20260907',
    'native-startup-full-integration-20260907-1',
    'native-validation-cpu-effects', 'native-validation-final-20260907',
}
CHECKOUTS.update('mckernel-native-irq-images-20260907-' + str(n) for n in range(1, 14))
CHECKOUTS.update('native-image-integration-20260907-' + str(n) for n in range(1, 7))
CHECKOUTS.update('native-irq-full-integration-20260907-' + str(n) for n in range(1, 3))
CHECKOUTS.update('native-irq-transport-policy-source-20260907-' + str(n) for n in range(1, 3))
CHECKOUTS.update('native-startup-policy-source-20260907-' + str(n) for n in range(1, 9))
RETENTION = {'native-mcctrl-service-retained-20260908-1', 'native-mcctrl-service-retained-20260908-2'}
CURRENT = {
    'native-mcctrl-exec-module-20260908-1', 'native-mcctrl-exec-module-20260908-2',
    'native-mcctrl-exec-guest-20260908-x86_64-1',
    'native-mcctrl-exec-guest-20260908-x86_64-2',
    'native-mcctrl-exec-guest-20260908-x86_64-3',
    'native-mcctrl-service-module-20260908-2',
}


def allowed(path, group):
    if not path.is_relative_to(WORK) or any(p.is_symlink() for p in (path, *path.parents)):
        return False
    parts = path.relative_to(WORK).parts
    if group == 'checkout_evidence_copies':
        return (parts[0] in CHECKOUTS and (
            parts[1:4] == ('docs', 'verification', 'evidence') or
            parts[1:5] == ('source', 'docs', 'verification', 'evidence')))
    return (group == 'retention_archive_copies' and path.parent.name in RETENTION
            and path.parent.parent == WORK and path.suffix == '.gz')


def unused(path, opened):
    alias = Path('/work') / path.relative_to(WORK)
    return not base.in_use(path, opened) and not base.in_use(alias, opened)


def audit():
    assert not PLAN.exists() and not REPORT.exists()
    head = base.git('rev-parse', 'HEAD').decode().strip()
    remote = base.git('ls-remote', 'origin', base.BRANCH).decode().split()[0]
    assert head == remote and not base.git('status', '--porcelain')
    tracked = {}
    for raw in base.git('ls-tree', '-r', '-z', head, '--', 'docs/verification').split(b'\0'):
        if raw:
            info, path = raw.split(b'\t', 1)
            tracked[path.decode()] = info.split()[2].decode()
    checked = {}

    def committed(relative, expected=None):
        if relative not in checked:
            path = REPO / relative
            assert path.is_file() and not path.is_symlink()
            value = base.hashes(path)
            assert value['git_blob'] == tracked[relative], relative
            checked[relative] = value
        value = checked[relative]
        if expected:
            assert value['size'] == expected['size'] and value['sha256'] == expected['sha256'], relative
        return value

    targets, skipped = [], []

    def consider(path, relative, group):
        assert allowed(path, group), str(path)
        st = path.lstat()
        assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_uid == os.getuid()
        before = base.snapshot(path)
        if relative not in tracked:
            skipped.append(dict(path=str(path), reason='no matching path in committed evidence'))
            return
        retained = committed(relative)
        if base.hashes(path) != retained:
            skipped.append(dict(path=str(path), reason='different from current committed evidence'))
            return
        assert base.snapshot(path) == before
        targets.append(dict(path=str(path), group=group, git_path=relative,
            retained=retained, snapshot=before, allocated_bytes=st.st_blocks * 512,
            restore_mode=stat.S_IMODE(st.st_mode), restore_mtime_ns=st.st_mtime_ns))

    for name in sorted(CHECKOUTS):
        capture = WORK / name
        assert capture.is_dir() and not capture.is_symlink(), name
        for root in (capture / 'docs/verification/evidence', capture / 'source/docs/verification/evidence'):
            if not root.is_dir():
                continue
            count = len(targets)
            for path in sorted(root.rglob('*')):
                if path.is_file() and not path.is_symlink():
                    relative = 'docs/verification/evidence/' + str(path.relative_to(root))
                    consider(path, relative, 'checkout_evidence_copies')
            print('CHECKED', str(root.relative_to(WORK)), len(targets) - count, 'exact copies', flush=True)
    manifest_path = 'docs/verification/native-mcctrl-service-checkpoint-20260908.json'
    committed(manifest_path)
    manifest = json.loads((REPO / manifest_path).read_text())
    assert manifest['status'] == 'PASS'
    artifacts = {Path(row['path']).name: row for row in manifest['artifacts']}
    for name in sorted(RETENTION):
        for path in sorted((WORK / name).glob('*.gz')):
            if path.name in artifacts:
                row = artifacts[path.name]
                committed(row['path'], row)
                consider(path, row['path'], 'retention_archive_copies')
    assert len({row['path'] for row in targets}) == len(targets)

    prior = json.loads((WORK / 'storage-image-evidence-copies-20260908-plan.json').read_text())
    preserved = {Path(path) for path in prior['preserved_files']}
    # Keep every current executable attempt, including all three first failures,
    # byte-for-byte, plus every current source/compiler/image dependency.
    for name in sorted(CURRENT):
        preserved.update(p for p in base.entries(WORK / name) if p.is_file() and not p.is_symlink())
    preserved.update(p for p in WORK.iterdir() if p.is_file() and not p.is_symlink()
                     and p.suffix in ('.py', '.sh', '.inc'))
    preserved.update(REPO / p for p in (
        'kernel.log', 'scripts/tests/fixtures/native-mcctrl-exec.c',
        'docs/verification/native-application-service-plan.md'))
    assert not preserved.intersection(Path(row['path']) for row in targets)
    protected = sorted(set(prior['protected']) | CURRENT | CHECKOUTS | RETENTION)
    for name in protected:
        assert (WORK / name).is_dir(), name
    opened, inaccessible = base.visible_open_paths()
    for row in targets:
        assert unused(Path(row['path']), opened), row['path']
    plan = dict(head=head, remote_head=remote, targets=targets, skipped=skipped,
        preserved_files={str(p): base.hashes(p) for p in sorted(preserved)},
        protected=protected, verified_committed_files=checked,
        inaccessible_process_fd_directories=inaccessible,
        finished_utc=base.now(), disk_before=base.disk_state(),
        removable_allocated_bytes=sum(row['allocated_bytes'] for row in targets))
    base.save(PLAN, plan)
    print('AUDIT PASS', len(targets), 'copies;', plan['removable_allocated_bytes'],
          'allocated bytes;', len(preserved), 'preserved inputs;', len(skipped), 'kept differences', flush=True)


def verify_preserved(plan):
    for path, expected in plan['preserved_files'].items():
        assert base.hashes(Path(path)) == expected, path
    for name in plan['protected']:
        assert (WORK / name).is_dir(), name


def apply():
    assert not REPORT.exists()
    plan = json.loads(PLAN.read_text())
    assert base.git('rev-parse', 'HEAD').decode().strip() == plan['head']
    assert base.git('ls-remote', 'origin', base.BRANCH).decode().split()[0] == plan['head']
    assert not base.git('status', '--porcelain')
    for relative, expected in plan['verified_committed_files'].items():
        assert base.hashes(REPO / relative) == expected, relative
    opened, inaccessible = base.visible_open_paths()
    for row in plan['targets']:
        path = Path(row['path'])
        assert allowed(path, row['group']) and unused(path, opened), str(path)
        assert base.snapshot(path) == row['snapshot'], str(path)
    verify_preserved(plan)
    report = dict(status='running', started_utc=base.now(), head=plan['head'],
        removed=[], disk_before=base.disk_state(),
        inaccessible_process_fd_directories=inaccessible)
    base.save(REPORT, report)
    try:
        for row in plan['targets']:
            path = Path(row['path'])
            assert base.snapshot(path) == row['snapshot'], str(path)
            path.unlink()
            report['removed'].append({k: v for k, v in row.items() if k != 'snapshot'})
            if len(report['removed']) % 256 == 0:
                base.save(REPORT, report)
        verify_preserved(plan)
        assert all(not Path(row['path']).exists() for row in plan['targets'])
        report.update(status='PASS', preserved_files=len(plan['preserved_files']),
            protected_directories=plan['protected'], all_preserved_files_byte_identical=True,
            removed_allocated_bytes=sum(row['allocated_bytes'] for row in plan['targets']))
    except BaseException as error:
        report.update(status='FAIL', error=str(error))
        raise
    finally:
        report.update(finished_utc=base.now(), disk_after=base.disk_state())
        base.save(REPORT, report)
    print('CLEANUP PASS', len(report['removed']), 'copies;', report['removed_allocated_bytes'],
          'allocated bytes;', report['preserved_files'], 'inputs unchanged; trim still required', flush=True)


def after_trim():
    assert not AFTER.exists()
    plan = json.loads(PLAN.read_text())
    report = json.loads(REPORT.read_text())
    assert report['status'] == 'PASS'
    verify_preserved(plan)
    assert all(not Path(row['path']).exists() for row in plan['targets'])
    value = dict(status='PASS', finished_utc=base.now(),
        preserved_files=len(plan['preserved_files']), protected_directories=len(plan['protected']),
        all_preserved_files_byte_identical=True, disk_after=base.disk_state())
    base.save(AFTER, value)
    print(json.dumps(value, sort_keys=True), flush=True)


if __name__ == '__main__':
    assert os.getuid() == 1000 and len(sys.argv) == 2 and sys.argv[1] in ('audit', 'apply', 'after-trim')
    {'audit': audit, 'apply': apply, 'after-trim': after_trim}[sys.argv[1]]()
