/work/native-sysfs-setup-module-20260907-1/setup/source/scripts/tests/fixtures/mckernel_sysfs_setup_verify.o
