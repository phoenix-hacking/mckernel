from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re
repo=Path('/home/holden/mckernel');work=Path('/home/holden/mckernel-work/scratch')
run=json.loads((work/'native-startup-full-suite-20260907-1.json').read_text());log=(work/'native-startup-full-suite-20260907-1.log').read_text()
assert run['exit_code']==0 and not run['changed_inputs']
assert re.search(r'^Ran 2313 tests in 279\.154s$',log,re.M) and re.search(r'^OK \(skipped=71\)$',log,re.M)
evidence=json.loads((work/'native-startup-retained-evidence-checks-20260907.json').read_text());assert evidence['status']=='PASS'
artifacts=[]
for name in ('native-startup-full-suite-20260907-1.json','native-startup-full-suite-20260907-1.log','native-startup-retained-evidence-checks-20260907.json','check-native-startup-retained-evidence.py','retain-native-startup-final.py'):
 raw=(work/name).read_bytes();data=gzip.compress(raw,mtime=0);assert gzip.decompress(data)==raw
 path=repo/'docs/verification/evidence'/('native-startup-final-20260907-'+name+'.gz')
 with path.open('xb') as stream: stream.write(data)
 artifacts.append(dict(path=str(path.relative_to(repo)),size=len(data),sha256=hashlib.sha256(data).hexdigest(),uncompressed_size=len(raw),uncompressed_sha256=hashlib.sha256(raw).hexdigest()))
references=[]
for name in ('native-startup-tables-checkpoint-20260907.json','native-startup-staging-integration-20260907.json','native-startup-exact-stage-checkpoint-20260907.json','rust-consumers-startup-20260907.json'):
 path=repo/'docs/verification'/name;raw=path.read_bytes();references.append(dict(path=str(path.relative_to(repo)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
record=dict(schema_version=1,kind='native-startup-tables-full-validation-checkpoint',recorded_utc=datetime.now(timezone.utc).isoformat(),source_parent=run['source_parent'],
 full_repository_suite=dict(status='PASS',total=2313,passed=2242,skipped=71,duration_seconds=279.154,started_utc=run['started_utc'],finished_utc=run['finished_utc'],uncommitted_source_overlays=0,environment=run['environment']),
 retained_evidence=evidence,production_gate_credit=False,native_mckernel_boot_proven=False,complete_rust_unification_claimed=False,
 next_work=['Owned low-memory trampoline and exact boot parameters','Resolve the guest/Linux 6.12 IRQ-work layout and lifetime boundary','Native CPU wakeup, readiness and IKC','Native mcctrl/application verification','Complete McKernel and linked support in Rust or reviewed assembly','Independent production acceptance'],references=references,artifacts=artifacts)
with (repo/'docs/verification/native-startup-final-validation-20260907.json').open('x') as stream: stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained final suite: 2242 passed, 71 skipped; all 73 checkpoint artifacts verified')
