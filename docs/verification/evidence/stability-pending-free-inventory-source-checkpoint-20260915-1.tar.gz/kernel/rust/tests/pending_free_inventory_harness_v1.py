#!/usr/bin/env python3
"""Cheap source-bound parity checks; intentionally performs no compilation or runtime."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
RS = ROOT / "kernel/rust/tests/pending_free_inventory_vectors_v1.rs"
C = ROOT / "kernel/rust/tests/pending_free_inventory_reference_v1.c"
MODEL = ROOT / "kernel/rust/tests/pending_free_inventory_v1.rs"

def names(text):
    return re.findall(r'(?:name:\s*"([^"]+)"|\{"([^"]+)")', text)

def main():
    model = MODEL.read_text(); rust = RS.read_text(); c = C.read_text()
    required = ("DescriptorArena", "InventoryBuilder", "FrozenInventory", "resolve", "checked_add", "callback")
    assert all(x in model for x in required)
    assert "for i in 0..self.count" in model and "if self.count > MAX" in model
    rn = [a or b for a,b in names(rust)]
    cn = [a or b for a,b in names(c)]
    assert rn == cn and len(rn) == 14
    assert all(x in rust for x in ("count-zero", "capacity-zero", "foreign-address", "duplicate-address", "range-overflow"))
    assert "const unsigned vector_count" in c
    print("PASS_SOURCE_INVENTORY_PARITY|vectors=14|compile=disabled|runtime=disabled")

if __name__ == "__main__": main()
