//! Private, finite model for the pending-free inventory contract.
//! This fixture deliberately has no production imports or callbacks.

pub const MAX: usize = 8;
pub const OK: i32 = 0;
pub const EINVAL: i32 = -22;
pub const EOVERFLOW: i32 = -75;
pub const ENOSPC: i32 = -28;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Descriptor {
    pub address: u64,
    pub length: u64,
    pub generation: u32,
    pub mode: u8,
    pub next: u64,
    pub prev: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DescriptorArena { items: [Option<Descriptor>; MAX] }

impl DescriptorArena {
    pub const fn empty() -> Self { Self { items: [None; MAX] } }
    pub fn insert(&mut self, d: Descriptor) -> i32 {
        if d.address == 0 || self.items.iter().flatten().any(|x| x.address == d.address) { return EINVAL; }
        if let Some(slot) = self.items.iter_mut().find(|x| x.is_none()) { *slot = Some(d); OK } else { ENOSPC }
    }
    // Resolution is the only operation that produces a descriptor reference.
    pub fn resolve(&self, address: u64) -> Option<&Descriptor> {
        self.items.iter().flatten().find(|d| d.address == address)
    }
    pub fn count(&self) -> usize { self.items.iter().flatten().count() }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InventoryBuilder { entries: [Descriptor; MAX], count: usize, count_limit: usize, byte_limit: u64, bytes: u64 }

impl InventoryBuilder {
    pub fn reserve(count_limit: usize, byte_limit: u64) -> Result<Self, i32> {
        if count_limit > MAX { return Err(ENOSPC); }
        Ok(Self { entries: [Descriptor { address: 0, length: 0, generation: 0, mode: 0, next: 0, prev: 0 }; MAX], count: 0, count_limit, byte_limit, bytes: 0 })
    }
    pub fn push(&mut self, d: Descriptor) -> i32 {
        let end = match d.address.checked_add(d.length) { Some(v) => v, None => return EOVERFLOW };
        if d.address == 0 || d.length == 0 || end <= d.address || d.mode != 1 { return EINVAL; }
        if self.count >= self.count_limit { return ENOSPC; }
        let bytes = match self.bytes.checked_add(d.length) { Some(v) => v, None => return EOVERFLOW };
        if bytes > self.byte_limit { return ENOSPC; }
        if self.entries[..self.count].iter().any(|x| x.address == d.address || ranges_overlap(x.address, x.length, d.address, d.length)) { return EINVAL; }
        self.entries[self.count] = d; self.count += 1; self.bytes = bytes; OK
    }
    pub fn freeze(self) -> FrozenInventory { FrozenInventory { entries: self.entries, count: self.count, bytes: self.bytes } }
}

fn ranges_overlap(a: u64, al: u64, b: u64, bl: u64) -> bool {
    let ae = a.checked_add(al); let be = b.checked_add(bl);
    match (ae, be) { (Some(x), Some(y)) => a < y && b < x, _ => true }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FrozenInventory { entries: [Descriptor; MAX], count: usize, bytes: u64 }

impl FrozenInventory {
    pub fn validate(&self, arena: &DescriptorArena, generation: u32, callback: &mut impl FnMut(u64, u64)) -> i32 {
        let before = *self;
        if self.count > MAX { return EINVAL; }
        for i in 0..self.count { // count is independently bounded before indexing.
            let d = self.entries[i];
            let resolved = match arena.resolve(d.address) { Some(x) => x, None => return EINVAL };
            if resolved != &d || d.generation != generation || d.mode != 1 { return EINVAL; }
            if d.next != 0 { if arena.resolve(d.next).is_none() { return EINVAL; } }
            if d.prev != 0 { if arena.resolve(d.prev).is_none() { return EINVAL; } }
        }
        for i in 0..self.count { for j in (i + 1)..self.count {
            if ranges_overlap(self.entries[i].address, self.entries[i].length,
                              self.entries[j].address, self.entries[j].length) { return EINVAL; }
        }}
        for i in 0..self.count { callback(self.entries[i].address, self.entries[i].length); }
        assert_eq!(*self, before);
        let _ = self.bytes;
        OK
    }
}
