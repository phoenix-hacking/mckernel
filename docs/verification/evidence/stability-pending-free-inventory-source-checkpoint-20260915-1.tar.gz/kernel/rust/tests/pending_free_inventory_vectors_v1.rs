//! Computed vector names shared with the independent C model.
#[derive(Clone, Copy)] pub struct Vector { pub name: &'static str, pub expected: i32 }
pub const VECTORS: &[Vector] = &[
    Vector{name:"count-zero",expected:0}, Vector{name:"capacity-zero",expected:-28},
    Vector{name:"count-over-capacity",expected:-28}, Vector{name:"foreign-address",expected:-22},
    Vector{name:"duplicate-address",expected:-22}, Vector{name:"overlap-range",expected:-22},
    Vector{name:"zero-length",expected:-22}, Vector{name:"range-overflow",expected:-75},
    Vector{name:"foreign-next-link",expected:-22}, Vector{name:"foreign-prev-link",expected:-22},
    Vector{name:"wrong-mode",expected:-22}, Vector{name:"wrong-generation",expected:-22},
    Vector{name:"valid-single",expected:0}, Vector{name:"valid-two",expected:0},
];
