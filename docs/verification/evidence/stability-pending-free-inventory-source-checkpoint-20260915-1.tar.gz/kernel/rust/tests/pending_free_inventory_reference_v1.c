/* Independent integer reference for pending_free_inventory_v1.rs vectors. */
#include <stdint.h>
struct vector { const char *name; int expected; };
const struct vector vectors[] = {
 {"count-zero",0},{"capacity-zero",-28},{"count-over-capacity",-28},
 {"foreign-address",-22},{"duplicate-address",-22},{"overlap-range",-22},
 {"zero-length",-22},{"range-overflow",-75},{"foreign-next-link",-22},
 {"foreign-prev-link",-22},{"wrong-mode",-22},{"wrong-generation",-22},
 {"valid-single",0},{"valid-two",0},
};
const unsigned vector_count = sizeof(vectors) / sizeof(vectors[0]);
