from pathlib import Path
from datetime import datetime, timezone
import json, os, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo=Path('/workspace'); out=Path('/work/native-ikc-publication-tests-20260907-' + sys.argv[1]); out.mkdir()
record=dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', commands=[], production_gate_credit=False)
try:
    shutil.copyfile(__file__,out/'helper.py')
    for relative in ('host-kernel/native-rust/ikc_queue.rs','host-kernel/native-rust/ikc_master.rs','host-kernel/native-rust/abi/x86_64.rs','scripts/tests/fixtures/ihk_native_queue_compile.rs','scripts/tests/fixtures/ihk_native_master_compile.rs'):
        target=out/'source'/relative; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(repo/relative,target)
    for fixture in ('ihk_native_queue_compile','ihk_native_master_compile'):
        for label,command in [(fixture+'-compile',['rustc','--edition','2021','--test',str(out/'source/scripts/tests/fixtures'/(fixture+'.rs')),'-o',str(out/fixture)]),(fixture+'-run',[str(out/fixture),'--test-threads=4'])]:
            with (out/(label+'.log')).open('wb') as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
            record['commands'].append(dict(label=label,command=command,exit_code=result.returncode))
            assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-12000:])
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
