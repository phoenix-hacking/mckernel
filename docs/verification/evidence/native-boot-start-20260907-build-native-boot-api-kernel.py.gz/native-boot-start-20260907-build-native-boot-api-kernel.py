from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
out = Path('/work/native-boot-api-kernel-20260907-' + sys.argv[1])
out.mkdir()
patch = repo / 'host-kernel/kbuild/patches/0006-x86-export-owned-secondary-start-primitives.patch'
paths = ['arch/x86/include/asm/smp.h', 'arch/x86/kernel/smpboot.c', 'arch/x86/kernel/head_64.S']
assert (build / '.config').read_bytes() == (prior / 'resolved.config').read_bytes()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), commands=[], production_gate_credit=False, mckernel_boot_proven=False)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-12000:])

def body(text):
    first = text.index('int wakeup_secondary_cpu_via_init(')
    first = text.index('{', first)
    last = text.index('\n}', first) + 2
    return text[first:last].encode()

try:
    for relative in paths:
        target = out / 'before' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    for relative in ['.config', 'Module.symvers', 'arch/x86/boot/bzImage']:
        target = out / 'before' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(build / relative, target)
    shutil.copyfile(patch, out / patch.name)
    shutil.copyfile(__file__, out / 'helper.py')
    run('patch-check', ['patch', '-d', str(source), '-p1', '--batch', '--dry-run', '--fuzz=0', '-i', str(patch)])
    run('patch-apply', ['patch', '-d', str(source), '-p1', '--batch', '--fuzz=0', '-i', str(patch)])
    original = body((out / 'before/arch/x86/kernel/smpboot.c').read_text())
    actual = body((source / 'arch/x86/kernel/smpboot.c').read_text())
    assert original == actual
    record['unchanged_init_sipi_body'] = dict(bytes=len(actual), sha256=hashlib.sha256(actual).hexdigest())
    for relative in paths:
        target = out / 'after' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    command = shlex.split((prior / 'kernel-build.command').read_text())
    run('kernel-build', command)
    # This updates Module.symvers from vmlinux.symvers and keeps the previous
    # declared modules buildable against the additive exports.
    run('baseline-module-build', shlex.split((prior / 'module-build.command').read_text()))
    for relative, name in [('.config', 'resolved.config'), ('Module.symvers', 'Module.symvers'), ('arch/x86/boot/bzImage', 'bzImage'), ('rust/bindings/bindings_generated.rs', 'bindings_generated.rs')]:
        shutil.copyfile(build / relative, out / name)
    assert (out / 'resolved.config').read_bytes() == (prior / 'resolved.config').read_bytes()
    exports = (out / 'Module.symvers').read_text()
    for name in ['wakeup_secondary_cpu_via_init', 'init_top_pgt']:
        assert '\t' + name + '\tvmlinux\tEXPORT_SYMBOL_GPL\t' in exports, name
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json', 'phase')]
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
