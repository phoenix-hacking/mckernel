from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-ikc-handshake-retained-20260907-1'; out.mkdir()
def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1<<20),b''): value.update(data)
    return value.hexdigest()
record=dict(created_utc=datetime.now(timezone.utc).isoformat(),artifacts=[],captures=[],
    production_gate_credit=False, mckernel_boot_proven=False, declared_stage=False,
    mckernel_arch_entry_proven=True, initial_bidirectional_ikc_proven=True,
    passed=[
        'APIC header binding patch 0007 and pinned Linux rebuild pass; no new C function or export',
        'Both exact boot/API witnesses and all three native prototype modules pass compile and ELF/no-SIMD checks',
        'Seven existing/new queue tests and six master tests pass, including one initial publication and refusal to reuse a consumed slot',
        'SET_KARGS reuses bounded user-string reads with the retained 1024-byte read cap and 255-byte payload; both guest ABIs verify truncation, bad pointers, load preservation and preparation retirement',
        'Both ABIs across two preparation module cycles pass 32 forced allocations, four physical snapshots, exact 128 MiB per-node pool restoration and complete module/CPU restoration',
        'Both actual-start guest ABIs receive INIT_ACK on the assigned McKernel CPU and send CONNECT through real Linux IRQ-work to the pinned host CPU',
        'QMP independently verifies both master queues each consumed/published exactly one packet, INIT_ACK bytes, CONNECT wire fields, native image execution and guest kmsg acknowledgment',
        'Started resources stay retained after failed/incomplete BOOT and file close; argument/resource changes, destruction and module removal are rejected'],
    limitations=[
        'The first preparation guest failed because its cleanup assumed one exact contiguous 128 MiB chunk; the retry proves all bytes restored across multiple returned chunks and uses the unchanged exact-release API',
        'Only INIT_ACK and the first CONNECT are serviced; listener acceptance, regular channels, vDSO/sysfs/mcctrl, status 3 and applications remain open',
        'The initial publisher never reuses a slot; repeated host sends need an explicit compatible peer-consumption contract',
        'VM teardown contains live resources but does not prove native shutdown/drain/restoration',
        'Declared staging, lifecycle/unsafe-FFI/license contracts and downstream byte bindings are pending for these boot/IKC sources',
        'Earlier full suite predates boot integration; performance fields, additional APIC modes/capabilities and the earlier intermittent idle/RCU stall remain open',
        'Full McKernel and linked-support Rust/assembly completion and independent production acceptance remain required'])
def add(path,name):
    target=out/name
    with path.open('rb') as source,target.open('xb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
            for data in iter(lambda:source.read(1<<20),b''): stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/'+name,source=str(path),size=target.stat().st_size,sha256=digest(target),unpacked_size=path.stat().st_size,unpacked_sha256=digest(path)))
for name in ['native-apic-bindings-kernel-20260907-1','native-ikc-publication-tests-20260907-1','native-ikc-prototype-20260907-1',
             'native-ikc-guest-20260907-prepare-1','native-ikc-guest-20260907-prepare-2',
             'native-ikc-guest-20260907-start-x86_64-1','native-ikc-guest-20260907-start-i386-1']:
    path=work/name; metadata=json.loads((path/'record.json').read_text())
    assert metadata['status']==('FAIL' if name=='native-ikc-guest-20260907-prepare-1' else 'PASS'),name
    rows=metadata.get('inputs',[])+metadata.get('outputs',[])
    for capture in metadata.get('captures',[]): rows+=capture.get('artifacts',[])
    for row in rows:
        item=Path(row['path']); assert item.stat().st_size==row['size'] and digest(item)==row['sha256'],item
    record['captures'].append(dict(directory=name,status=metadata['status'],source_parent=metadata.get('source_parent'),started_utc=metadata.get('started_utc'),finished_utc=metadata.get('finished_utc')))
    target=out/(name+'.tar.gz')
    with tarfile.open(target,'w:gz') as archive: archive.add(path,arcname=name)
    assert target.stat().st_size < 95<<20,target
    record['artifacts'].append(dict(path='docs/verification/evidence/'+target.name,source=str(path),size=target.stat().st_size,sha256=digest(target)))
    for short in ('record.json','serial.log','debugcon.log'):
        if (path/short).exists(): add(path/short,name+'-'+short+'.gz')
for name in ('build-native-apic-bindings.py','build-native-ikc-prototype.py','check-native-ikc-publication.py','run-native-ikc-guest.py','retain-native-ikc-handshake.py'):
    add(work/name,'native-ikc-handshake-20260907-'+name+'.gz')
stage=work/'native-ikc-prototype-20260907-1/staged-source'
record['current_compiler_inputs']=[]
for path in sorted(stage.rglob('*')):
    if not path.is_file() or path.suffix not in ('.rs','.S'): continue
    relative='host-kernel/native-rust/'+str(path.relative_to(stage)); current=repo/relative
    row=dict(path=relative,size=current.stat().st_size,sha256=digest(current),compiler_size=path.stat().st_size,compiler_sha256=digest(path),transform='none')
    if current.read_bytes()!=path.read_bytes():
        assert path.suffix=='.rs',relative
        formatted=out/('formatted-'+path.name); formatted.write_bytes(current.read_bytes())
        command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(formatted)]
        subprocess.run(command,check=True); assert formatted.read_bytes()==path.read_bytes(),relative
        row['transform']=command[:-1]; add(current,'native-ikc-handshake-20260907-unformatted-'+path.name+'.gz')
    record['current_compiler_inputs'].append(row)
record['current_compiler_input_count']=len(record['current_compiler_inputs'])
for relative in ('scripts/native-boot-init.sh','scripts/tests/fixtures/native-boot.c','scripts/tests/fixtures/native_smp_boot_layout.c','host-kernel/kbuild/patches/0007-rust-bindings-expose-x86-apic-driver.patch'):
    path=repo/relative; record.setdefault('source_inputs',[]).append(dict(path=relative,size=path.stat().st_size,sha256=digest(path)))
reference=repo/'docs/verification/native-boot-start-checkpoint-20260907.json'
record['previous_boot_reference']=dict(path=str(reference.relative_to(repo)),size=reference.stat().st_size,sha256=digest(reference))
for row in record['artifacts']:
    size=0; unpacked=hashlib.sha256()
    with gzip.open(out/Path(row['path']).name,'rb') as stream:
        for data in iter(lambda:stream.read(1<<20),b''): size+=len(data); unpacked.update(data)
    if 'unpacked_sha256' in row: assert size==row['unpacked_size'] and unpacked.hexdigest()==row['unpacked_sha256']
(out/'native-ikc-handshake-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained and verified',len(record['artifacts']),'native IKC artifacts; full boot and listener services remain open',flush=True)
