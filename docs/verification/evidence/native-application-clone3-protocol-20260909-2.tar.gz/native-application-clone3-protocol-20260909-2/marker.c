#include <assert.h>
#define SYSCALL_POLICY_HELPER_SCOPE
#define CLONE_VM 0x100
#define __NR_clone3 435
SYSCALL_POLICY_HELPER_SCOPE int
clone_pthread_marker_result(int clone_flags, unsigned long newsp,
		unsigned long parent_tidptr)
{
	return (clone_flags & CLONE_VM) && newsp == parent_tidptr;
}
struct context { unsigned long number; }; struct thread { struct context *uctx; }; static unsigned long ihk_mc_syscall_number(const struct context *ctx) { return ctx->number; }
static int selected(unsigned long nr,int clone_flags,unsigned long newsp,unsigned long parent_tidptr) { struct context ctx={nr}; struct thread value={&ctx}, *old=&value; (void)old; (void)&ihk_mc_syscall_number; if (
#ifdef MCKERNEL_NATIVE_CLONE3
		ihk_mc_syscall_number(old->uctx) != __NR_clone3 &&
#endif
		clone_pthread_marker_result(clone_flags, newsp, parent_tidptr)) return 1; return 0; }
int main(void) { const int flags[]={0,0x100,0x3d0f00}; const unsigned long numbers[]={56,57,435}; const unsigned long addresses[]={0,0x200000,0x208000,~0UL}; for(unsigned f=0;f<3;f++)for(unsigned n=0;n<3;n++)for(unsigned a=0;a<4;a++)for(unsigned b=0;b<4;b++) { int expected=clone_pthread_marker_result(flags[f],addresses[a],addresses[b]);
#ifdef MCKERNEL_NATIVE_CLONE3
if(numbers[n]==435)expected=0;
#endif
assert(selected(numbers[n],flags[f],addresses[a],addresses[b])==expected); } return 0; }
