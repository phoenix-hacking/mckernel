from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work');linux=work/'native-source/linux-6.12.0-211.44.1.el10_2'
out=work/('native-application-clone3-protocol-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),inputs=[],commands=[],extracted_bodies=[],scope='Exact pinned Linux clone3 validation reference and complete native guest adapter through original Rust clone/lock/fork adapters; controlled user-copy and lifecycle providers. Actual guest pending.')
def identity(path):return dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def extract(path,pattern,name):
    data=path.read_text();match=re.search(pattern,data,re.M);assert match,name
    start=match.start();end=data.index('{',start)+1;depth=1
    while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
    body=data[start:end];record['extracted_bodies'].append(dict(source=str(path),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()));return body+'\n'
def run(label,args):
    print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode));assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-8000:])
try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['kernel/rust/lock_helpers.rs','kernel/rust/clone3.rs','kernel/rust/syscall_policy.rs','kernel/rust/lib.rs','kernel/rust/abi.rs','kernel/CMakeLists.txt','kernel/syscall.c','kernel/include/syscall.h','arch/x86_64/kernel/include/syscall_list.h','scripts/tests/fixtures/native-application-clone3.rs','scripts/tests/fixtures/native-application-clone3.c']
    for name in names:
        path=out/'original-inputs'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,path);record['inputs'].append(identity(path))
    for name in ['kernel/fork.c','include/linux/uaccess.h','include/linux/sched/task.h','include/uapi/linux/sched.h','arch/x86/entry/syscalls/syscall_64.tbl']:
        path=out/'linux-reference'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(linux/name,path);record['inputs'].append(identity(path))
    assert re.search(r'^435\s+common\s+clone3\s+sys_clone3',(out/'linux-reference/arch/x86/entry/syscalls/syscall_64.tbl').read_text(),re.M)
    for name in ['clone3.rs','abi.rs']:shutil.copyfile(out/'original-inputs/kernel/rust'/name,out/name)
    for name in ['native-application-clone3.rs','native-application-clone3.c']:shutil.copyfile(out/'original-inputs/scripts/tests/fixtures'/name,out/name)
    rust=out/'original-inputs/kernel/rust/syscall_policy.rs';data=rust.read_text();body=''
    for name in ['EFAULT']:
        match=re.search(r'^const '+name+r':[^;]+;',data,re.M);assert match;body+=match[0]+'\n'
    for name in ['ArchCloneLockFn','ArchDoForkFn']:
        match=re.search(r'^type '+name+r'\b[^;]+;',data,re.M);assert match;body+=match[0]+'\n'
    for name in ['sys_clone','sys_clone3','arch_clone_body_result']:body+=extract(rust,r'^pub unsafe extern "C" fn '+name+r'\(',name)
    locks=out/'original-inputs/kernel/rust/lock_helpers.rs'
    body+='#[repr(C, align(64))]\n'+extract(locks,r'^pub struct McsRwlockNodeIrqsave \{','McsRwlockNodeIrqsave')
    body+='const _: () = { use core::mem::{size_of,align_of,offset_of};\n'+'\n'.join(line for line in locks.read_text().splitlines() if 'assert!' in line and 'McsRwlockNodeIrqsave' in line)+'\n};\n'
    (out/'native-application-clone3-bodies.rs').write_text(body)
    sched=out/'linux-reference/include/uapi/linux/sched.h';task=out/'linux-reference/include/linux/sched/task.h';fork=out/'linux-reference/kernel/fork.c';access=out/'linux-reference/include/linux/uaccess.h'
    c='\n'.join(re.findall(r'^#define CLONE_\w+[^\n]+',sched.read_text(),re.M))+'\n'
    c+=re.search(r'^#define CLONE_LEGACY_FLAGS[^\n]+',task.read_text(),re.M)[0]+'\n'
    c+=extract(sched,r'^struct clone_args \{','clone_args')+';\n'+extract(task,r'^struct kernel_clone_args \{','kernel_clone_args')+';\n'
    for path,pattern,name in [(access,r'^static __always_inline __must_check int\ncopy_struct_from_user\(','copy_struct_from_user'),(fork,r'^noinline static int copy_clone_args_from_user\(','copy_clone_args_from_user'),(fork,r'^static inline bool clone3_stack_valid\(','clone3_stack_valid'),(fork,r'^static bool clone3_args_valid\(','clone3_args_valid')]:c+=extract(path,pattern,name)
    (out/'linux-clone3-reference.h').write_text(c)
    vectors=[];labels=[];sentinel=-9999;mask=(1<<64)-1
    base=[0x3d0f00,0,0x301234,0x302234,0,0x200000,0x8000,0x306789,0,0,0]
    def add(label,words=None,size=88,address=0x100000,readable=4096,override=sentinel,nonzero=None):
        payload=bytearray(4096);struct.pack_into('<11Q',payload,0,*(base if words is None else words))
        if nonzero is not None:payload[nonzero]=1
        vectors.append(struct.pack('<4Q',address,size,readable,override&mask)+payload);labels.append(dict(index=len(vectors)-1,label=label,size=size,address=address,readable=readable,override=override))
    for size in list(range(98))+[128,255,256,4095,4096,4097,mask]:add('version-'+str(size),size=size)
    unsupported=[7,12,17,25,26,27,28,29,30,31,32,33]
    for bit in range(64):
        words=base.copy();words[0]|=1<<bit
        if bit==32:words[0]=1<<bit
        add('flag-'+str(bit),words,override=-95 if bit in unsupported else sentinel)
    for flags in [0,0x3d0f00,0x8000]:
        for signal in list(range(71))+[255,256,1<<32,mask]:
            words=base.copy();words[0]=flags;words[4]=signal;add('signal-'+str(flags)+'-'+str(signal),words)
    for stack in [0,0xfff,0x1000,0x200000,0x800000000000-4096,0x800000000000-1,0x800000000000,mask]:
        for length in [0,1,4096,mask]:
            words=base.copy();words[5]=stack;words[6]=length;add('stack-'+str(stack)+'-'+str(length),words)
    for size in [64,80,88,89,96,128,4096]:
        for readable in [0,63,64,79,80,87,88,size-1]:add('fault-'+str(size)+'-'+str(readable),size=size,readable=readable)
    for size in [89,96,128,4096]:
        for nonzero in set([88,size-1]):add('nonzero-tail-'+str(size)+'-'+str(nonzero),size=size,nonzero=nonzero)
    for address in [0,0xfff,0x1000,0x100001,0x800000000000-88,0x800000000000-87,0x800000000000,mask]:add('arg-address-'+str(address),address=address)
    for pointer,count in [(0,1),(0x100300,0),(0x100300,1),(0x100300,32),(0x100300,33)]:
        words=base.copy();words[8]=pointer;words[9]=count;add('set-tid-'+str(count)+'-'+str(pointer),words,override=-95 if pointer and 0<count<=32 else sentinel)
    for size in [64,80,87,88,4096]:
        for cgroup in [0,2147483647,2147483648,mask]:
            words=base.copy();words[0]|=0x200000000;words[10]=cgroup;add('cgroup-'+str(size)+'-'+str(cgroup),words,size=size,override=-95 if size>=88 and cgroup<=2147483647 else sentinel)
    words=base.copy();words[0]|=0x100000000;add('clear-sighand-conflict',words)
    words=base.copy();words[3]=words[5]+words[6];add('legal-stack-parent-tid-alias',words)
    (out/'vectors.bin').write_bytes(b''.join(vectors));(out/'vectors.json').write_text(json.dumps(labels,indent=2)+'\n');record['vectors']=len(vectors)
    run('diff-check',['git','-C',str(repo),'diff','--check'])
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(out/'clone3.rs'),str(out/'native-application-clone3.rs')])
    run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(out/'native-application-clone3.c'),'-o',str(out/'c-reference')])
    run('c-reference',[str(out/'c-reference'),str(out/'vectors.bin')])
    run('rust-build',['rustc','--edition','2021','--cfg','native_linux_irq_work_v6_12','-D','warnings','--test',str(out/'native-application-clone3.rs'),'-o',str(out/'tests')])
    run('rust-tests',[str(out/'tests'),'--nocapture'])
    kernel=out/'original-inputs/kernel/syscall.c'
    condition=re.search(r'\tif \(\n#ifdef MCKERNEL_NATIVE_CLONE3\n.*?clone_pthread_marker_result\(clone_flags, newsp, parent_tidptr\)\) \{',kernel.read_text(),re.S)
    assert condition and len(condition[0])<240
    expression=condition[0].split('if (',1)[1].rsplit(') {',1)[0]
    marker='#include <assert.h>\n#define SYSCALL_POLICY_HELPER_SCOPE\n#define CLONE_VM 0x100\n#define __NR_clone3 435\n'
    marker+=extract(kernel,r'^SYSCALL_POLICY_HELPER_SCOPE int\nclone_pthread_marker_result\(','clone_pthread_marker_result')
    marker+='struct context { unsigned long number; }; struct thread { struct context *uctx; }; static unsigned long ihk_mc_syscall_number(const struct context *ctx) { return ctx->number; }\n'
    marker+='static int selected(unsigned long nr,int clone_flags,unsigned long newsp,unsigned long parent_tidptr) { struct context ctx={nr}; struct thread value={&ctx}, *old=&value; (void)old; (void)&ihk_mc_syscall_number; if ('+expression+') return 1; return 0; }\n'
    marker+='int main(void) { const int flags[]={0,0x100,0x3d0f00}; const unsigned long numbers[]={56,57,435}; const unsigned long addresses[]={0,0x200000,0x208000,~0UL}; for(unsigned f=0;f<3;f++)for(unsigned n=0;n<3;n++)for(unsigned a=0;a<4;a++)for(unsigned b=0;b<4;b++) { int expected=clone_pthread_marker_result(flags[f],addresses[a],addresses[b]);\n#ifdef MCKERNEL_NATIVE_CLONE3\nif(numbers[n]==435)expected=0;\n#endif\nassert(selected(numbers[n],flags[f],addresses[a],addresses[b])==expected); } return 0; }\n'
    (out/'marker.c').write_text(marker)
    for profile,extra in [('legacy',[]),('native',['-DMCKERNEL_NATIVE_CLONE3'])]:
        run(profile+'-marker-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror']+extra+[str(out/'marker.c'),'-o',str(out/(profile+'-marker'))])
        run(profile+'-marker',[str(out/(profile+'-marker'))])
    record['marker_vectors_per_selection']=144
    record['test_summary']=[line for line in (out/'rust-tests.log').read_text().splitlines() if line.startswith('test result:')]
    record['compiler_inputs']=[identity(out/name) for name in ['clone3.rs','abi.rs','native-application-clone3.rs','native-application-clone3-bodies.rs','native-application-clone3.c','linux-clone3-reference.h','vectors.bin','vectors.json','c-reference.log','marker.c']]
    for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
