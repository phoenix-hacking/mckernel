#!/usr/bin/env python3
"""Dispatcher-owned bounded runner for the MODEL_ONLY lifecycle packet."""
import argparse
import json
import os
import pathlib
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
MAX_JSON = 1 << 20
MAX_EXPANDED = 2 << 20
MAX_OUTPUT = 1 << 20
OPS = {
    "P_ALLOC", "T_ALLOC", "TID_ASSIGN", "BIRTH", "RUNNABLE", "REF_ADD",
    "REF_DROP", "RETIRE_BEGIN", "RETIRE_DONE", "ABORT", "TERMINAL",
    "ZOMBIE_SET", "PARENT_REAP", "VM_RELEASE", "MAIN_STORAGE_RELEASE",
    "LAUNCHER_LOSS", "CAPTURE_END", "TEARDOWN_FAIL",
}

def strict_bytes(raw):
    assert len(raw) <= MAX_JSON
    def pairs(items):
        result = {}
        for name, value in items:
            assert name not in result, "duplicate key"
            result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def strict_file(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    raw = path.read_bytes()
    assert raw.rstrip().endswith(b"}") and b"\x00" not in raw
    return strict_bytes(raw)

class ExpansionBudget:
    def __init__(self):
        self.nodes = 262144
        self.bytes = MAX_EXPANDED

    def take(self, value):
        self.nodes -= 1
        if value is None:
            cost = 4
        elif type(value) is bool:
            cost = 5
        elif type(value) is int:
            cost = len(str(value))
        elif isinstance(value, str):
            cost = 12 * len(value) + 2
        elif isinstance(value, list):
            cost = max(2, len(value) + 1)
        else:
            cost = 2
        self.bytes -= cost
        assert self.nodes >= 0 and self.bytes >= 0, "expanded literal budget"

def literal_expand(value, pools, args=(), stack=(), budget=None, depth=0):
    """Acyclic literal substitution only; no transition or arithmetic evaluation."""
    if budget is None:
        budget = ExpansionBudget()
    assert depth <= 32 and len(stack) <= 32
    budget.take(value)
    if isinstance(value, dict):
        if set(value) == {"arg"}:
            index = value["arg"]
            assert type(index) is int and 0 <= index < len(args)
            return literal_expand(args[index], {}, (), (), budget, depth + 1)
        assert set(value) in ({"pool"}, {"pool", "args"})
        name = value["pool"]
        assert isinstance(name, str) and name in pools and name not in stack
        supplied = value.get("args", [])
        assert isinstance(supplied, list)
        expanded_args = [literal_expand(item, pools, args, stack, budget, depth + 1) for item in supplied]
        return literal_expand(pools[name], pools, expanded_args, stack + (name,), budget, depth + 1)
    if isinstance(value, list):
        result = []
        for item in value:
            result.append(literal_expand(item, pools, args, stack, budget, depth + 1))
        return result
    assert value is None or type(value) in (str, int, bool)
    return value

def checked_expansion(value, pools):
    result = literal_expand(value, pools, budget=ExpansionBudget())
    assert len(json.dumps(result, separators=(",", ":")).encode()) <= MAX_EXPANDED
    return result

def integer(value, low=0, high=(1 << 64) - 1):
    assert type(value) is int and low <= value <= high
    return value

def key(value, process=False):
    assert isinstance(value, list) and len(value) == 7
    result = [integer(item) for item in value]
    assert result[0] and result[2] and result[3] and result[4] and result[6]
    assert (result[5] == 0) if process else (result[5] != 0)
    return result

def operation(raw, expected_id):
    assert isinstance(raw, list) and len(raw) == 8
    op_id, name, subject, parent, a, b, c, d = raw
    assert integer(op_id, 1, 128) == expected_id and name in OPS
    if name in ("LAUNCHER_LOSS", "CAPTURE_END"):
        assert subject is None and parent is None
        subject_wire = parent_wire = [0] * 7
    else:
        assert isinstance(subject, list) and len(subject) == 7
        process_subject = subject[5] == 0
        subject_wire = key(subject, process=process_subject)
        if name == "P_ALLOC":
            assert process_subject
            parent_wire = [0] * 7 if parent is None else key(parent, process=True)
        elif name == "T_ALLOC":
            assert not process_subject
            parent_wire = key(parent, process=True)
        else:
            assert parent is None
            parent_wire = [0] * 7
    args = [integer(item) for item in (a, b, c, d)]
    if name == "P_ALLOC":
        integer(a, 1, (1 << 31) - 1); assert b == c == d == 0
    elif name == "T_ALLOC":
        integer(a, 0, (1 << 31) - 1); assert b in (0, 1) and c == d == 0
    elif name == "TID_ASSIGN":
        integer(a, 1, (1 << 31) - 1); assert b == c == d == 0
    elif name == "ABORT":
        integer(a, 1, 255); assert b == c == d == 0
    elif name == "TERMINAL":
        integer(a, 0, (1 << 32) - 1); integer(b, 0, 255)
        integer(c, 0, 255); integer(d, 1, 4)
    else:
        assert a == b == c == d == 0
    return [op_id, name, *subject_wire, *parent_wire, *args]

def wire(vector, input_pools):
    capacity = integer(vector["event_capacity"], 0, 256)
    seed = vector["seed"]
    assert seed in ("NONE", "ATTEMPTS_MAX", "LOST_MAX", "RESERVATION_ONE")
    operations = checked_expansion(vector["operations"], input_pools)
    assert isinstance(operations, list) and 0 < len(operations) <= 128
    rows = [f"MODEL2 {capacity} {seed}"]
    for index, raw in enumerate(operations, 1):
        rows.append(" ".join(map(str, operation(raw, index))))
    return ("\n".join(rows) + "\n").encode("ascii")

def expected_rows(document, name):
    rows = checked_expansion(document["vectors"][name], document["pools"])
    assert isinstance(rows, list) and rows
    for index, row in enumerate(rows, 1):
        validate_output_row(row, index)
    return rows

def nullable_key(value, process=None):
    if value is None:
        return
    assert isinstance(value, list) and len(value) == 7
    for item in value:
        integer(item)
    if process is True:
        assert value[5] == 0
    elif process is False:
        assert value[5] != 0

def terminal(value):
    if value is None:
        return
    assert isinstance(value, list) and len(value) == 4
    integer(value[0], 0, (1 << 32) - 1)
    integer(value[1], 0, 255); integer(value[2], 0, 255); integer(value[3], 1, 4)

def process_row(row):
    assert isinstance(row, list) and len(row) == 13
    nullable_key(row[0], True); nullable_key(row[1], True)
    integer(row[2], 1, (1 << 31) - 1)
    assert row[3] in ("Allocated", "Born", "Aborted", "Terminal", "Retiring", "Retired")
    integer(row[4], 0, (1 << 32) - 1); assert row[5] in ("E", "N")
    terminal(row[6]); integer(row[7], 0, 255); nullable_key(row[8], False)
    assert type(row[9]) is type(row[10]) is type(row[11]) is bool
    if row[12] is not None:
        assert isinstance(row[12], list) and len(row[12]) == 3
        nullable_key(row[12][0], True); terminal(row[12][1]); integer(row[12][2], 0, 255)

def thread_row(row):
    assert isinstance(row, list) and len(row) == 11
    nullable_key(row[0], False); nullable_key(row[1], True)
    integer(row[2], 1, (1 << 31) - 1); integer(row[3], 0, (1 << 31) - 1)
    assert type(row[4]) is bool
    assert row[5] in ("Allocated", "Born", "Runnable", "Aborted", "Terminal", "Retiring", "Retired")
    integer(row[6], 0, (1 << 32) - 1); assert row[7] in ("E", "N")
    terminal(row[8]); integer(row[9], 0, 255)
    if row[10] is not None:
        assert isinstance(row[10], list) and len(row[10]) == 3
        nullable_key(row[10][0], False); terminal(row[10][1]); integer(row[10][2], 0, 255)

def validate_output_row(row, expected_id):
    assert isinstance(row, list) and len(row) == 6
    assert integer(row[0], 1, 128) == expected_id
    assert row[1] in ("OK", "SCHEMA", "KEY", "STATE", "IDENTITY", "REF", "BUSY", "STATUS", "LIMIT", "CLOSED")
    assert isinstance(row[2], list)
    for event in row[2]:
        assert isinstance(event, list) and len(event) == 11
        assert integer(event[0]) == 1; integer(event[1], 1); integer(event[2], 1, 128)
        assert isinstance(event[3], str) and event[3]
        nullable_key(event[4]); nullable_key(event[5], True)
        if event[6] is not None: integer(event[6], 1, (1 << 31) - 1)
        if event[7] is not None: integer(event[7], 0, (1 << 31) - 1)
        assert isinstance(event[8], list) and len(event[8]) == 5
        integer(event[8][0], 0, (1 << 32) - 1)
        for item in event[8][1:]: integer(item, 0, 255)
        assert integer(event[9]) == 1 and integer(event[10]) == event[2]
    assert isinstance(row[3], list) and isinstance(row[4], list)
    for item in row[3]: process_row(item)
    for item in row[4]: thread_row(item)
    control = row[5]
    assert isinstance(control, list) and len(control) == 7
    integer(control[0]); integer(control[1]); integer(control[2])
    assert type(control[3]) is type(control[4]) is type(control[5]) is bool
    integer(control[6])

def run(command, data):
    result = subprocess.run(command, input=data, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=10, check=False)
    assert result.returncode == 0 and not result.stderr
    assert len(result.stdout) <= MAX_OUTPUT
    rows = [strict_bytes(line) for line in result.stdout.splitlines()]
    for index, row in enumerate(rows, 1):
        validate_output_row(row, index)
    return rows

def compiler(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file()
    return str(path)

def build(args, output):
    rust, cref = output / "model-rust", output / "model-c"
    subprocess.run([compiler(args.rustc), "--edition=2021", "-Dwarnings", "-o",
                    str(rust), str(HERE / "model.rs")], check=True, timeout=60)
    subprocess.run([compiler(args.cc), "-std=c11", "-Wall", "-Wextra", "-Werror",
                    "-O2", "-o", str(cref), str(HERE / "reference.c")],
                   check=True, timeout=60)
    return rust, cref

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rustc", required=True)
    parser.add_argument("--cc", required=True)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    args = parser.parse_args()
    assert args.output.is_absolute() and not args.output.exists()
    vectors = strict_file(HERE / "vectors.json")
    expected = strict_file(HERE / "expected.json")
    assert set(vectors) == {"schema_version", "model_only", "corpus_complete", "pools", "vectors", "raw_invalid", "mutants"}
    assert set(expected) == {"schema_version", "model_only", "corpus_complete", "pools", "vectors"}
    assert vectors["schema_version"] == expected["schema_version"] == 2
    assert vectors["model_only"] is expected["model_only"] is True
    assert vectors["corpus_complete"] is expected["corpus_complete"] is True
    args.output.mkdir(mode=0o700)
    rust, cref = build(args, args.output)
    seen = set()
    for vector in vectors["vectors"]:
        assert set(vector) == {"name", "coverage", "event_capacity", "seed", "operations"}
        name = vector["name"]
        assert isinstance(name, str) and name not in seen
        assert isinstance(vector["coverage"], list) and vector["coverage"]
        seen.add(name)
        want = expected_rows(expected, name)
        rust_rows = run([str(rust)], wire(vector, vectors["pools"]))
        c_rows = run([str(cref)], wire(vector, vectors["pools"]))
        assert rust_rows == want and c_rows == want and rust_rows == c_rows
    assert seen == set(expected["vectors"])
    assert vectors["mutants"] == {
        "birth-after-runnable": "birth-after-runnable",
        "early-retirement": "retained-thread-reference",
        "silent-loss": "buffer-exhaustion-cleanup",
        "tid-aliasing": "active-tid-alias",
    }
    directory = os.open(args.output, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

if __name__ == "__main__":
    main()
