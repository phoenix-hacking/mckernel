kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o: \
 /work/mckernel-native-irq-images-20260907-13/source/lib/list.c \
 /work/mckernel-native-irq-images-20260907-13/source/lib/include/list.h
