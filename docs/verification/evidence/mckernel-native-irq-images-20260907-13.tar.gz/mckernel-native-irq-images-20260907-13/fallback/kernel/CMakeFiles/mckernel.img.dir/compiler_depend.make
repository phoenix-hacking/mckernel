# Empty compiler generated dependencies file for mckernel.img.
# This may be replaced when dependencies are built.
