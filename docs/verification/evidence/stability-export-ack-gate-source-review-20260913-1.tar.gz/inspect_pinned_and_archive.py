"""Inspect retained bytes and archive source evidence. Executes no tested code."""
from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import stat
import struct
import tarfile

REPO = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
ATTEMPT = WORK / 'stability-export-ack-gate-tests-20260913-1'
SOURCE = Path('/tmp/stability-export-ack-gate-source-u8f3m6nz')
ARCHIVE = REPO / 'docs/verification/evidence/stability-export-ack-gate-source-review-20260913-1.tar.gz'
REPORT = REPO / 'docs/verification/stability-export-ack-gate-review-20260913.json'
PEER = Path('/tmp/stability-physical-ack-independent-review-20260913-46ogngi1/review.json')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_size < 2**20, path
    raw = path.read_bytes()
    assert len(raw) == st.st_size
    return dict(path=str(path), size=len(raw), sha256=digest(raw))


def json_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def recorded_artifact(row):
    path = Path(row['path'].replace('/work/', str(WORK) + '/'))
    actual = identity(path)
    assert (actual['size'], actual['sha256']) == (row['size'], row['sha256']), path
    return actual


record = json.loads((ATTEMPT / 'record.json').read_bytes())
assert record['status'] == 'PASS_ACTUAL_RECEIVER_GATE_INFRASTRUCTURE_ONLY' and record['cases'] == 4
assert record['application_acceptance'] is record['transport_acceptance'] is record['guest_execution'] is False
collection = record['collection']
assert collection['status'] == 'COMPLETED' and collection['raw_wait_status'] == 0
assert collection['wait_status'] == {'kind': 'exited', 'code': 0}
assert collection['cleanup_complete'] is True and collection['descendants'] == []
assert collection['payload_monotonic_started'] <= collection['payload_completion_observed_monotonic'] <= collection['payload_monotonic_deadline']
bindings = [recorded_artifact(row['retained']) for row in record['inputs']]
for stream in collection['streams'].values():
    recorded_artifact(stream['artifact'])
    assert stream['eof'] is True and stream['truncated'] is False
    assert stream['bytes_observed'] == stream['bytes_retained'] == stream['artifact']['size']
    assert stream['discarded_observed_bytes'] == 0
stdout = (ATTEMPT / 'collection/stdout.bin').read_bytes()
stderr = (ATTEMPT / 'collection/stderr.bin').read_bytes()
assert stderr.startswith(b'....\n') and b'Ran 4 tests in 0.592s\n\nOK\n' in stderr
roots = sorted((ATTEMPT / 'tmp').iterdir())
assert len(roots) == 4 and all(path.is_dir() and not path.is_symlink() for path in roots)
cases = []
binary = b'\x00\xa5\xff\nSTAF0001\r\x00'
for root in roots:
    case = json.loads((root / 'case.json').read_bytes())
    result = json.loads((root / 'result-0.json').read_bytes())
    name = case['case'].split('.')[-1]
    assert name.encode() in stdout
    assert case['automatic_deletion'] is False
    assert result['error'] is None and result['worker_alive_after_bounded_join'] is False
    for row in case['inputs']:
        recorded_artifact(row)
        copied = root / ('input-' + Path(row['path']).name)
        assert identity(copied)['sha256'] == row['sha256']
    ack = (root / 'peer-ack-0.bin').read_bytes()
    assert len(ack) == result['retained_peer_ack_bytes']
    item = dict(case=name, result=identity(root / 'result-0.json'), actual_peer_ack=identity(root / 'peer-ack-0.bin'))
    if name == 'test_actual_receiver_constructor_forwards_socket_interface':
        assert result['result'] is result['finished_ns'] is None and ack == b''
        assert result['gate_pending'] is result['gate_allowed'] is False
        assert (root / 'capture/wire.bin').read_bytes() == b''
        item['verified_behavior'] = 'Actual constructor/interface test passed; no receive run or ACK claimed.'
    else:
        wire = (root / 'expected-wire.bin').read_bytes()
        assert wire == (root / 'capture/wire.bin').read_bytes()
        manifest_raw = (root / 'capture/manifest.json').read_bytes()
        manifest = json.loads(manifest_raw)
        actual = result['result']
        assert actual['manifest'] == manifest
        assert manifest['wire_bytes'] == manifest['socket_bytes_received'] == len(wire)
        assert manifest['wire_sha256'] == digest(wire) and manifest['received_raw_fully_stored'] is True
        pending = json.loads((root / 'pending-observation.json').read_bytes())
        assert pending['manifest_sha256'] == digest(manifest_raw) and pending['wire_sha256'] == digest(wire)
        assert pending['gate_allowed'] is False and pending['peer_ack_bytes_observed'] == 0
        assert pending['observed_monotonic_ns'] < actual['ack']['finished_monotonic_ns'] <= result['finished_ns']
        status, entries, content = (1, 1, len(binary)) if 'malformed_tree' in name else ((0, 3, len(binary)) if 'complete_tree' in name else (0, 0, 0))
        expected = struct.pack('<8s16sIIQQ32s32s', b'STAA0001', bytes.fromhex('0123456789abcdef0011223344556677'),
                               status, 0, content, entries, hashlib.sha256(wire).digest(), hashlib.sha256(manifest_raw).digest())
        assert len(expected) == 112 and (root / 'capture/ack.bin').read_bytes() == expected
        if 'closed_gate' in name:
            assert actual['ok'] is False and ack == b'' and actual['ack']['bytes_sent'] == 0
            assert actual['ack']['ack_complete'] is actual['ack']['within_deadline'] is False
            assert actual['ack']['error'] == 'ProtocolError:host-deadline'
            assert manifest['deadline_monotonic_ns'] - manifest['capture_started_monotonic_ns'] == 500_000_000
            assert actual['ack']['finished_monotonic_ns'] >= manifest['deadline_monotonic_ns']
            item['verified_behavior'] = 'Real 0.5-second deadline; zero actual ACK bytes, including after late gate opening.'
        else:
            assert ack == expected == (root / 'expected-ack.bin').read_bytes()
            assert actual['ack']['ack_complete'] is actual['ack']['within_deadline'] is True
            assert actual['ack']['bytes_sent'] == 112 and actual['ack']['ack_status'] == status and actual['ack']['error'] is None
            if 'complete_tree' in name:
                assert actual['ok'] is True and manifest['status'] == 'CAPTURE_COMPLETE'
                assert (root / 'capture/files/nested/bytes.bin').read_bytes() == binary
                assert (root / 'capture/files/empty').read_bytes() == b''
                fsyncs = json.loads((root / 'actual-fsync-completions.json').read_bytes())
                for path in [root / 'capture/manifest.json', root / 'capture/wire.bin', root / 'capture/files/nested/bytes.bin', root / 'capture', root]:
                    st = path.stat()
                    assert any(row['device'] == st.st_dev and row['inode'] == st.st_ino and row['completed_monotonic_ns'] <= pending['observed_monotonic_ns'] for row in fsyncs), path
                item['verified_behavior'] = 'Real fsync completions precede observed pending; exact binary/empty tree and status0 112-byte ACK after gate release.'
            else:
                assert 'malformed_tree' in name and actual['ok'] is False and manifest['status'] == 'FAIL'
                assert manifest['error'] == 'ProtocolError:final-manifest-count-mismatch'
                assert (root / 'capture/files/partial.bin').read_bytes() == binary
                item['verified_behavior'] = 'Malformed END remains failed after complete exact status1 ACK; original file/wire retained.'
        item.update(wire=identity(root / 'capture/wire.bin'), manifest=identity(root / 'capture/manifest.json'),
                    ack_status=status, actual_ack_bytes=len(ack), receiver_ok=actual['ok'])
    cases.append(item)
assert len({row['case'] for row in cases}) == 4
inspection = dict(schema_version=1, status='PASS_RETAINED_INFRASTRUCTURE_INSPECTION_ONLY',
                  pinned_record=identity(ATTEMPT / 'record.json'), retained_input_bindings=bindings,
                  collection_stdout=identity(ATTEMPT / 'collection/stdout.bin'), collection_stderr=identity(ATTEMPT / 'collection/stderr.bin'),
                  raw_wait_status=0, collector_elapsed_seconds=collection['elapsed_seconds'], unittest_reported_seconds=0.592,
                  inspected_cases=cases, reviewer_executed_tests=False, guest_execution=False,
                  application_acceptance=False, transport_acceptance=False, production_gate_credit=False)
json_new(SOURCE / 'pinned-results-inspection.json', inspection)
peer_raw = PEER.read_bytes()
assert digest(peer_raw) == '24a0ce45cda1faf63490175b8e90c25c8273f860e564f08511cdf0bcc3ff0d09'
with (SOURCE / 'independent-peer-review.json').open('xb') as stream:
    stream.write(peer_raw)

# Only this explicitly selected flat source/review tree is archived. Every
# member is read, hashed, then compared with its decompressed archived bytes.
members = []
for path in sorted(SOURCE.iterdir()):
    row = identity(path)
    assert path.name not in ('.', '..') and '/' not in path.name
    members.append(dict(name=path.name, size=row['size'], sha256=row['sha256']))
assert len(members) <= 32 and sum(row['size'] for row in members) < 2**20
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
with ARCHIVE.open('xb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for row in members:
                raw = (SOURCE / row['name']).read_bytes()
                assert len(raw) == row['size'] and digest(raw) == row['sha256']
                info = tarfile.TarInfo(row['name']); info.size = len(raw); info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                archive.addfile(info, io.BytesIO(raw))
    target.flush(); os.fsync(target.fileno())
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    archived = archive.getmembers()
    assert [row.name for row in archived] == [row['name'] for row in members]
    for entry, row in zip(archived, members):
        assert entry.isfile() and entry.size == row['size']
        with archive.extractfile(entry) as stream:
            raw = stream.read(row['size'] + 1)
        assert len(raw) == row['size'] and digest(raw) == row['sha256']
for row in members:
    assert identity(SOURCE / row['name'])['sha256'] == row['sha256']
report = dict(schema_version=1, record_kind='export_ack_gate_review', status='PASS_INFRASTRUCTURE_REVIEW_ONLY',
              created_utc=datetime.now(timezone.utc).isoformat(), source_archive=identity(ARCHIVE), archive_members=members,
              archive_member_count=len(members), archive_roundtrip_all_bytes_verified=True,
              original_source_tree=str(SOURCE), original_source_tree_preserved=True,
              source_review=identity(SOURCE / 'final-source-review.json'), independent_peer_review=identity(SOURCE / 'independent-peer-review.json'),
              independent_peer_scope='Only ack_gate_test_review section applies here; its unrelated physical oracle review grants no extra credit.',
              pinned_test_inspection=inspection, pinned_full_attempt_archive_owner='/root',
              source_fixes=['Regular retained boot-dmesg input replaces unavailable /dev/fd process substitution.',
                            'ExportAckGate forwards Receiver constructor setblocking.',
                            'Runner preserves first nonzero guest marker and detects both receiver exceptions and returned ok=false.'],
              original_guest_failure_evidence='Preserved separately by root; these synthetic results do not change that failed guest outcome.',
              reviewer_executed_tests=False, component_tests_executed_by_parent=True, guest_execution=False,
              application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
              runtime_release_authorized_by_this_record=False,
              limitations=['Four connected-socket Python infrastructure cases only; no C exporter, virtio, QMP or guest execution.',
                           'Filesystem fsync observations do not replace an independent watchdog for pathological storage blocking.',
                           'Pinned container/process provenance and full attempt archival remain parent records.',
                           'Actual guest fault control, physical ownership and final export require their separate reviewed runtime evidence.'])
json_new(REPORT, report)
print(json.dumps(dict(report=identity(REPORT), archive=identity(ARCHIVE), members=len(members),
                      inspected_cases=len(cases)), sort_keys=True))
