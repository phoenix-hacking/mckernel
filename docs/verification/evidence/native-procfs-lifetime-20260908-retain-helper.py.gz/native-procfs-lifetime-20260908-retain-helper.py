"""Retain exact guest procfs lifetime, native completion and exchange regression captures."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-procfs-lifetime-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-procfs-lifetime-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],compiler_bindings=[],
    scope='Complete selected guest Rust procfs lifetime corrections, native-only terminal reply marker and actual native Exchange acceptance, with original C references and existing image/mailbox regressions. Full image/module builds and actual native procfs service remain pending.',
    actual_guest_procfs_compiled_in_fixture=True,native_procfs_service_integrated=False,
    mckernel_application_executed=False,production_gate_credit=False,independent_acceptance=False,
    original_failures_in_this_batch=3)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-procfs-objects-checkpoint-20260908.json','native-application-mailbox-checkpoint-20260908.json']:
        path=repo/'docs/verification'/name;assert json.loads(path.read_text())['status']=='PASS'
        row=identity(path);row['path']=str(path.relative_to(repo));record['references'].append(row)
    captures=[('native-procfs-lifetime-20260908-'+str(i),'FAIL' if i<4 else 'PASS') for i in range(1,6)]
    captures += [('native-application-image-20260908-8','PASS'),('native-application-mailbox-20260908-6','PASS')]
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,complete_capture_retained=True,archive_exclusions={}))
    compiled=work/'native-procfs-lifetime-20260908-5';state=json.loads((compiled/'record.json').read_text())
    for row in state['inputs']:
        relative=Path(row['path']).relative_to(compiled/'original-inputs')
        record['compiler_bindings'].append(binding(repo/relative,compiled/'source'/relative))
    assert len(record['compiler_bindings'])==18
    record['procfs_results']={key:state[key] for key in ['tests_passed_per_profile','profiles','exact_c_answer_vectors','exact_c_backlog_vectors','queue_full_rounds_per_profile','extracted_bodies']}
    assert state['tests_passed_per_profile']==9 and state['profiles']==['legacy','native']
    for profile in state['profiles']:
        assert 'test result: ok. 9 passed; 0 failed;' in (compiled/(profile+'-rust-tests.log')).read_text()
    record['regression_results']=[]
    for name,logs in [('native-application-image-20260908-8',['protocol-tests.log','image-tests.log']),('native-application-mailbox-20260908-6',['rust-tests.log'])]:
        directory=work/name
        for log in logs:
            results=[line for line in (directory/log).read_text().splitlines() if line.startswith('test result:')]
            assert len(results)==1 and '0 failed;' in results[0]
            record['regression_results'].append(dict(capture=str(directory),log=log,result=results[0]))
        record.setdefault('shared_exchange_bindings',[]).append(binding(repo/'host-kernel/native-rust/application_rpc.rs',directory/'source/host-kernel/native-rust/application_rpc.rs'))
    references=out/'project-reference';references.mkdir()
    record['existing_source_review']=[]
    for name in ['kernel/rust/procfs.rs','kernel/rust/object_helpers.rs','kernel/rust/cls.rs','kernel/rust/host_helpers.rs','kernel/rust/lib.rs','kernel/CMakeLists.txt','kernel/procfs.c','kernel/cls.c','executer/kernel/mcctrl/ikc.c','executer/kernel/mcctrl/rust/mcctrl_helpers.rs']:
        saved=references/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,saved)
        record['existing_source_review'].append(binding(repo/name,saved))
    record['original_actual_guest_sources']=[]
    for name in ['kernel/rust/procfs.rs','kernel/rust/cls.rs','kernel/rust/lib.rs','kernel/CMakeLists.txt']:
        actual=work/'mckernel-native-sysfs-images-20260908-2/source'/name
        saved=references/'prior-actual-image'/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(actual,saved)
        assert actual.read_bytes()==saved.read_bytes()
        record['original_actual_guest_sources'].append(dict(original=identity(actual),retained=identity(saved)))
    artifact(references,'native-procfs-lifetime-20260908-project-reference.tar.gz',True)
    for name in ['test-native-procfs-lifetime.py','test-native-application-image.py','test-native-application-mailbox.py','build-mckernel-native-procfs-images.py']:
        artifact(work/name,'native-procfs-lifetime-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-procfs-lifetime-20260908-retain-helper.py.gz')
    record.update(status='PASS',complete_captures=len(captures),artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
