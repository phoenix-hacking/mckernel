#!/bin/bash
set -eu
export PATH=/bin:/sbin:/usr/bin:/usr/sbin
fail() { echo MCKERNEL_SYSFS_SETUP_GUEST_FAIL; while :; do sleep 1; done; }
trap fail EXIT
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
host_values() {
    local cpu field cache index value node
    for cpu in 0 1 2 3; do
        for field in physical_package_id core_id core_siblings thread_siblings; do
            value=$(</sys/devices/system/cpu/cpu${cpu}/topology/${field})
            printf 'SETUP_HOST cpu=%s field=%s value=%s\n' "$cpu" "$field" "$value"
        done
        for cache in /sys/devices/system/cpu/cpu${cpu}/cache/index*; do
            index=${cache##*/index}
            for field in type level coherency_line_size number_of_sets ways_of_associativity physical_line_partition size shared_cpu_map; do
                value=$(<"$cache/$field")
                printf 'SETUP_CACHE cpu=%s index=%s field=%s value=%s\n' "$cpu" "$index" "$field" "$value"
            done
        done
    done
    for node in 0 1; do
        value=$(</sys/devices/system/node/node${node}/distance)
        printf 'SETUP_NODE node=%s distance=%s\n' "$node" "$value"
    done
    test -d /sys/devices/system/cpu/cpu3/node1
    test -d /sys/devices/system/cpu/cpu1/node0
}
scan() {
    local base=$1 cycle=$2 phase=$3 path value line
    for path in "$base"/*; do
        test -e "$path" || continue
        if test -L "$path"; then
            printf 'SETUP_LINK cycle=%s phase=%s path=%s\n' "$cycle" "$phase" "${path#/sys/mckernel_sysfs_setup_verify/good}"
        elif test -d "$path"; then
            printf 'SETUP_DIR cycle=%s phase=%s path=%s\n' "$cycle" "$phase" "${path#/sys/mckernel_sysfs_setup_verify/good}"
            scan "$path" "$cycle" "$phase"
        else
            value=$(while IFS= read -r line; do printf '%s\n' "$line"; done < "$path"; printf .)
            value=${value%.}
            printf 'SETUP_FILE cycle=%s phase=%s path=%s BEGIN\n%sSETUP_FILE_END\n' "$cycle" "$phase" "${path#/sys/mckernel_sysfs_setup_verify/good}" "$value"
        fi
    done
}
check_links() {
    local base=/sys/mckernel_sysfs_setup_verify/good/sys cpu node
    test -d "$base/setup_complete"
    test ! -e "$base/test/x.dir"
    test "$base/test/L.dir" -ef "$base/test/a.dir"
    for cpu in 0 1; do
        node=$((1-cpu))
        test "$base/devices/system/cpu/cpu$cpu/node$node" -ef "$base/devices/system/node/node$node"
        test "$base/devices/system/node/node$node/cpu$cpu" -ef "$base/devices/system/cpu/cpu$cpu"
        test "$base/bus/node/devices/node$node" -ef "$base/devices/system/node/node$node"
    done
    test -d /sys/mckernel_sysfs_setup_verify/failed/sys
    test ! -e /sys/mckernel_sysfs_setup_verify/failed/sys/test
    test ! -e /sys/mckernel_sysfs_setup_verify/failed/sys/devices
    test ! -e /sys/mckernel_sysfs_setup_verify/failed/sys/setup_complete
}
host_values
for cycle in 1 2; do
    insmod /modules/mckernel_sysfs_setup_verify.ko
    check_links
    scan /sys/mckernel_sysfs_setup_verify/good "$cycle" before
    echo 0 > /sys/devices/system/cpu/cpu3/online
    echo 0 > /sys/devices/system/cpu/cpu1/online
    test "$(</sys/devices/system/cpu/cpu3/online)" = 0
    test "$(</sys/devices/system/cpu/cpu1/online)" = 0
    check_links
    scan /sys/mckernel_sysfs_setup_verify/good "$cycle" offline
    echo 1 > /sys/devices/system/cpu/cpu1/online
    echo 1 > /sys/devices/system/cpu/cpu3/online
    test "$(</sys/devices/system/cpu/cpu1/online)" = 1
    test "$(</sys/devices/system/cpu/cpu3/online)" = 1
    check_links
    scan /sys/mckernel_sysfs_setup_verify/good "$cycle" restored
    rmmod mckernel_sysfs_setup_verify
    test ! -e /sys/mckernel_sysfs_setup_verify
    printf 'MCKERNEL_SYSFS_SETUP_CYCLE_PASS=%s\n' "$cycle"
done
echo MCKERNEL_SYSFS_SETUP_GUEST_PASS
while :; do sleep 1; done
