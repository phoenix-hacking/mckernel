#!/usr/bin/env python3
"""Independent offline oracle for storage-fault-v2 retained evidence."""
import hashlib
import itertools
import json
import os
import re
import stat
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_SHA = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
PREFIX = bytes.fromhex("41435251303030")
PREFIX_SHA = "793665677edfa8c879c38d37c8c5300c54ff78e980eae26a96913d7aab9d8d91"
REQUEST_SHA = "e81b38bbe6116bf1df2807fa968e12dccfd28fe8c3ad225c45f282b36cab6716"
SELECTED_SHA = "6b8761a9d2094147f02b9fe2a4c709246905a04c5122d68f6b9951162e01317d"
FIXTURE_SHA = "9ad70dd23d699e72ad805f59446aec371c4e80b955056b845af921b4ce51f725"
EXPECTED_DESIRED = {
    "role": 1, "request_profile": 1, "uid": 0, "gid": 0, "group": 0,
    "umask": 18, "argc": 2, "envc": 0, "stdin_mode": 0,
    "case_id_hex": "696e6672617374727563747572652e636f6c6c6563746f72",
    "source_selector_hex": "2f776f726b2f63617365732f737464696e2d6465766e756c6c2f696e707574732f66697874757265",
    "cwd_hex": "2f776f726b2f63617365732f737464696e2d6465766e756c6c2f637764",
    "stdin_selector_hex": "2f6465762f6e756c6c",
    "attempt_id_hex": "b9e7824e46f727250a6a80c8fcfc9359",
    "selected_inputs_sha256": SELECTED_SHA,
}
EXPECTED = {
    0: (0, "post-fork", "complete", "COMPLETED", "none", 0, 21),
    1: (256, "pre-fork", "complete", "PREPARATION_ERROR", "artifact-create", 28, 10),
    2: (256, "pre-fork", "complete", "COLLECTOR_ERROR", "artifact-write", 28, 17),
    3: (256, "post-fork", "complete", "COLLECTOR_ERROR", "artifact-fsync", 5, 21),
    4: (32000, "post-fork", "absent", None, None, 28, 16),
    5: (32000, "post-fork", "complete-undurable", "COMPLETED", "none", 0, 21),
    6: (32000, "pre-fork", "complete-undurable", "COLLECTOR_ERROR", "artifact-write", 28, 17),
}
COUNTS = [21, 10, 17, 21, 16, 21, 17]
REPORT_KEYS = {
    "schema_version", "kind", "collector_mode", "status", "first_failure",
    "first_failure_errno", "first_failure_monotonic_ns",
    "application_acceptance", "transport_acceptance", "backend_enabled",
    "pathname_execution", "loader_closure_verified", "native_payload",
    "collector_pid", "collector_uid", "collector_euid",
    "collector_interruption_signal", "request_valid", "desired",
    "configured_execution_mechanism", "child_created", "linux_child",
    "setup_ready_record", "setup_error_record", "setup_validated",
    "setup_words", "post_exec_backing_observed",
    "post_exec_observed_monotonic_ns", "post_exec_backing",
    "subsequent_proc_exe_link_sample", "preparation_start_ns",
    "preparation_deadline_ns", "process_start_ns", "process_deadline_ns",
    "completion_observed_ns", "cleanup_start_ns", "cleanup_deadline_ns",
    "cleanup_finished_ns", "cleanup_complete", "group_identity_pinned",
    "owned_records_omitted", "owned_children", "executable", "stdin",
    "devnull_identity", "artifacts", "streams",
}
COMMON = {"schema_version", "nonce", "selector", "sequence", "kind", "phase",
          "monotonic_ns", "site", "object", "occurrence", "collector_pid",
          "collector_startticks", "source_sha256", "generated_sha256",
          "header_sha256", "elf_sha256"}
CREATE = {"dirfd", "dir_stat", "fd", "target_stat", "acquisition_id",
          "return", "errno_authoritative", "errno"}
WRITE_BEFORE = {"fd", "target_stat", "acquisition_id", "requested_bytes",
                "return", "errno_authoritative", "errno"}
WRITE_AFTER = WRITE_BEFORE | {"actual_bytes"}
IO = {"fd", "target_stat", "acquisition_id", "return",
      "errno_authoritative", "errno"}
BIND = {"acquisition_id", "old_fd", "old_stat", "new_fd", "new_stat"}
OBS = {"REAP": {"pid", "startticks", "raw_wait_status"},
       "EOF": {"closed_fd"},
       "CLEANUP_READY": {"waitid_return", "waitid_errno", "leader_reaped",
           "stdout_eof", "stderr_eof", "setup_eof"},
       "CLEANUP_FINAL": {"cleanup_start_ns", "cleanup_deadline_ns",
           "cleanup_finished_ns", "cleanup_complete", "group_pinned",
           "owned_count", "owned_records_omitted", "first_failure",
           "first_failure_errno"}}
OWNER_ERROR_KEYS = {"schema_version", "kind", "ordinal", "primary", "stage",
    "type", "message", "monotonic_ns", "packet_sequence", "packet_sha256"}
OWNER_ERROR_STAGES = {"receive", "pre-ack", "journal-packet", "release", "ack",
    "cleanup", "capture-fsync", "artifact-read", "owner-result-write",
    "journal-result", "directory-fsync"}
SUPERVISOR_KEYS = {"schema_version", "kind", "status", "owner_exit_code",
    "owner_signal", "started_ns", "finished_ns", "attempt_root",
    "owner_result_present", "owner_result_sha256", "witness_present",
    "witness_sha256", "owner_errors_present", "owner_errors_sha256",
    "owner_stdout_sha256", "owner_stderr_sha256", "owner_identity",
    "owner_identity_observations", "owner_wait_observed",
    "owner_wait_deadline_ns", "cleanup_trigger_ns",
    "supervisor_cleanup_deadline_ns", "supervisor_deadline_ns",
    "supervisor_cleanup", "sigchld_default", "sentinel_wait_passed",
    "preflight_failure", "preflight_started_ns", "sentinel_wait_deadline_ns"}

def pair(site, object_name, occurrence=1):
    return [("BEFORE", site, object_name, occurrence),
            ("AFTER", site, object_name, occurrence)]

def schedule_variants(selector):
    e, w1, w2 = pair("events-create", "events.jsonl"), \
        pair("request-write", "request.bin"), pair("request-write", "request.bin", 2)
    eb = [("BIND", "events-create", "events.jsonl", 1)]
    a, r = pair("request-sync", "request.bin"), pair("report-create", "report.json")
    rb = [("BIND", "report-create", "report.json", 1)]
    f, s = pair("report-flush", "report.json"), pair("report-sync", "report.json")
    base = {0:e+eb+w1+["O"]+a+r+rb+f+s, 1:e+r+rb+f+s,
            2:e+eb+w1+w2+a+r+rb+f+s, 3:e+eb+w1+["O"]+a+r+rb+f+s,
            4:e+eb+w1+["O"]+a+r, 5:e+eb+w1+["O"]+a+r+rb+f+s,
            6:e+eb+w1+w2+a+r+rb+f+s}[selector]
    ready = [("READY", "startup", "collector", 0)]
    if "O" not in base:
        return [ready + base]
    index = base.index("O")
    observations = [("REAP", "reap", "leader", 1),
        ("EOF", "pump", "stdout", 1), ("EOF", "pump", "stderr", 2),
        ("EOF", "pump", "setup", 3)]
    final = [("CLEANUP_READY", "cleanup", "owned-tree", 1),
             ("CLEANUP_FINAL", "cleanup", "owned-tree", 1)]
    return [ready + base[:index] + list(order) + final + base[index+1:]
            for order in itertools.permutations(observations)]

def phase_for(selector, site, kind):
    if kind == "READY" or site in ("events-create", "request-write"):
        return "pre-fork"
    if kind in OBS:
        return "post-fork"
    return "pre-fork" if selector in (1, 2, 6) else "post-fork"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("nonfinite")))

def exact_equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(
            exact_equal(left[key], right[key]) for key in left)
    if type(left) is list:
        return len(left) == len(right) and all(
            exact_equal(a, b) for a, b in zip(left, right))
    return left == right

def read(path, limit=1 << 20):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError("canonical evidence path")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular evidence")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                raise OSError("short evidence read")
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("evidence changed during read")
        return b"".join(chunks)
    finally:
        os.close(fd)

def journal(path):
    raw = read(path, 1 << 20)
    if not raw.endswith(b"\n"):
        raise ValueError("journal terminal newline")
    rows = [strict(line) for line in raw.splitlines()]
    if not rows or any(set(row) != {"packet", "receipt_monotonic_ns"}
                       for row in rows):
        raise ValueError("journal envelope")
    if any(type(row["receipt_monotonic_ns"]) is not int or
           row["receipt_monotonic_ns"] <= 0 for row in rows):
        raise ValueError("journal receipt")
    return rows

def validate_owner_errors(raw, result=None):
    if raw == b"":
        rows = []
    else:
        if not raw.endswith(b"\n"):
            raise ValueError("owner error terminal newline")
        rows = [strict(line) for line in raw.splitlines()]
    previous_ns = 0
    for index, row in enumerate(rows):
        if type(row) is not dict or set(row) != OWNER_ERROR_KEYS or \
           type(row["schema_version"]) is not int or row["schema_version"] != 2 or \
           type(row["kind"]) is not str or row["kind"] != "OWNER_ERROR" or \
           type(row["ordinal"]) is not int or row["ordinal"] != index or \
           type(row["primary"]) is not bool or row["primary"] is not (index == 0) or \
           row["stage"] not in OWNER_ERROR_STAGES or \
           type(row["type"]) is not str or not row["type"] or \
           type(row["message"]) is not str or not row["message"] or \
           type(row["monotonic_ns"]) is not int or \
           row["monotonic_ns"] <= previous_ns:
            raise ValueError("owner error record")
        if row["message"].startswith("<empty-") and \
           row["message"] != "<empty-%s>" % row["type"]:
            raise ValueError("owner error message")
        sequence = row["packet_sequence"]
        digest = row["packet_sha256"]
        if sequence is not None and (type(sequence) is not int or sequence < 0):
            raise ValueError("owner error packet sequence")
        if digest is not None and (type(digest) is not str or
                re.fullmatch(r"[0-9a-f]{64}", digest) is None):
            raise ValueError("owner error packet hash")
        previous_ns = row["monotonic_ns"]
    if result is not None:
        cutoff = result.get("result_serialized_ns")
        if type(cutoff) is not int or cutoff <= 0:
            raise ValueError("owner result serialization")
        included = [row for row in rows if row["monotonic_ns"] <= cutoff]
        expected_primary = included[0] if included else None
        if not exact_equal(result.get("owner_failure"), expected_primary) or \
           not exact_equal(result.get("secondary_failures"), included[1:]):
            raise ValueError("owner error partition")
    return rows

def cleanup_phase(value, suffix=False):
    fixed = {"term-identity-1", "term-identity-2",
             "kill-identity-1", "kill-identity-2"}
    if value in fixed:
        return True
    match = re.fullmatch(r"owned-scan-(\d+)(?:-([12]))?", value) \
        if type(value) is str else None
    return match is not None and 0 <= int(match.group(1)) <= 2047 and \
        ((match.group(2) is not None) if suffix else (match.group(2) is None))

def validate_cleanup_unresolved(values):
    if type(values) is not list:
        raise ValueError("owner cleanup unresolved")
    for value in values:
        if type(value) is not dict or type(value.get("kind")) is not str:
            raise ValueError("owner cleanup unresolved")
        kind = value["kind"]
        if kind == "identity":
            if set(value) != {"kind", "phase", "observation", "pid", "ppid",
                    "startticks", "matched", "monotonic_ns"} or \
               not cleanup_phase(value["phase"], suffix=True) or \
               value["observation"] not in ("observed", "missing", "error") or \
               type(value["pid"]) is not int or value["pid"] <= 0 or \
               type(value["matched"]) is not bool or \
               type(value["monotonic_ns"]) is not int or value["monotonic_ns"] <= 0:
                raise ValueError("owner cleanup identity")
            if value["observation"] == "observed":
                if type(value["ppid"]) is not int or value["ppid"] <= 0 or \
                   type(value["startticks"]) is not int or value["startticks"] <= 0:
                    raise ValueError("owner cleanup identity")
            elif value["ppid"] is not None or value["startticks"] is not None or \
                    value["matched"] is not False:
                raise ValueError("owner cleanup identity")
        elif kind == "deadline":
            if set(value) != {"kind", "stage", "monotonic_ns", "deadline_ns"} or \
               value["stage"] not in ("direct-wait", "term-pre-signal",
                    "kill-pre-signal", "owned-scan") or any(
                    type(value[key]) is not int or value[key] <= 0
                    for key in ("monotonic_ns", "deadline_ns")) or \
               value["monotonic_ns"] < value["deadline_ns"]:
                raise ValueError("owner cleanup deadline")
        elif kind == "signal-error":
            if set(value) != {"kind", "stage", "pid", "startticks", "signal",
                    "errno", "monotonic_ns"} or value["stage"] not in ("term", "kill") or \
               type(value["signal"]) is not int or \
               value["signal"] != (15 if value["stage"] == "term" else 9) or any(
                    type(value[key]) is not int or value[key] <= 0 for key in
                    ("pid", "startticks", "errno", "monotonic_ns")):
                raise ValueError("owner cleanup signal error")
        elif kind == "wait-timeout":
            if set(value) != {"kind", "stage", "pid", "startticks",
                    "monotonic_ns", "deadline_ns"} or \
               value["stage"] not in ("direct", "term", "kill") or \
               type(value["pid"]) is not int or value["pid"] <= 0 or \
               (value["startticks"] is not None and (type(value["startticks"]) is not int or
                    value["startticks"] <= 0)) or any(type(value[key]) is not int or
                    value[key] <= 0 for key in ("monotonic_ns", "deadline_ns")) or \
               value["monotonic_ns"] < value["deadline_ns"]:
                raise ValueError("owner cleanup wait timeout")
        elif kind == "owned":
            if set(value) != {"kind", "phase", "pid", "ppid", "startticks",
                    "monotonic_ns"} or not cleanup_phase(value["phase"]) or any(
                    type(value[key]) is not int or value[key] <= 0 for key in
                    ("pid", "ppid", "startticks", "monotonic_ns")):
                raise ValueError("owner cleanup owned")
        else:
            raise ValueError("owner cleanup unresolved kind")
    return values

def validate_events(raw, selector, collector):
    if not raw.endswith(b"\n"):
        raise ValueError("events terminal newline")
    events = [strict(line) for line in raw.splitlines()]
    schemas = {
        "collector-start": {"monotonic_ns", "event", "pid"},
        "request-rejected": {"monotonic_ns", "event", "decoder_error"},
        "child-created": {"monotonic_ns", "event", "pid", "startticks"},
        "observed-sealed-exe": {"monotonic_ns", "event", "pid"},
        "leader-waitable": {"monotonic_ns", "event", "pid"},
        "owned-kill-attempt": {"monotonic_ns", "event", "pid", "startticks"},
        "adopted-child": {"monotonic_ns", "event", "pid", "startticks"},
        "actual-reap": {"monotonic_ns", "event", "pid", "raw_wait_status"},
        "owned-group-kill-attempt": {"monotonic_ns", "event", "pgid",
                                     "leader_startticks"},
        "direct-unreaped-child-kill-without-proc-identity": {
            "monotonic_ns", "event", "pid"},
        "collector-finish": {"monotonic_ns", "event", "first_failure"},
    }
    if not events or events[0] != {"monotonic_ns": events[0].get("monotonic_ns"),
            "event": "collector-start", "pid": collector["pid"]} or \
       events[-1].get("event") != "collector-finish":
        raise ValueError("events endpoints")
    stamps = []
    for event in events:
        name = event.get("event")
        if name not in schemas or set(event) != schemas[name] or \
           type(event["monotonic_ns"]) is not int or event["monotonic_ns"] <= 0:
            raise ValueError("events schema")
        stamps.append(event["monotonic_ns"])
    if stamps != sorted(stamps) or len(set(stamps)) != len(stamps):
        raise ValueError("events order")
    expected_failure = "artifact-write" if selector in (2, 6) else "none"
    if events[-1]["first_failure"] != expected_failure:
        raise ValueError("events failure snapshot")
    return events

def validate_stat(value):
    if type(value) is not dict or set(value) != {"dev", "ino", "mode", "size"} or \
       any(type(value[key]) is not int for key in value):
        raise ValueError("witness stat")

def validate_report_stat(value):
    keys = {"device", "inode", "mode", "uid", "gid", "size", "nlink",
            "mtime_seconds", "mtime_nanoseconds", "ctime_seconds",
            "ctime_nanoseconds"}
    if type(value) is not dict or set(value) != keys or any(
            type(value[key]) is not int for key in keys):
        raise ValueError("report stat")

def validate_sink(value):
    if value is None:
        return
    keys = {"attempted_name", "created", "fd_available", "creation_errno",
            "fd_errno", "path", "limit_bytes", "seen_bytes", "stored_bytes",
            "truncated", "io_error", "sha256"}
    if type(value) is not dict or set(value) != keys or \
       type(value["attempted_name"]) is not str or \
       any(type(value[key]) is not bool for key in (
           "created", "fd_available", "truncated", "io_error")) or \
       any(type(value[key]) is not int or value[key] < 0 for key in (
           "creation_errno", "fd_errno", "limit_bytes", "seen_bytes",
           "stored_bytes")) or value["stored_bytes"] > value["seen_bytes"]:
        raise ValueError("report sink")
    if value["created"] is not (value["path"] == value["attempted_name"]) or \
       (value["path"] is not None and type(value["path"]) is not str):
        raise ValueError("report sink path")
    if value["fd_available"]:
        if type(value["sha256"]) is not str or len(value["sha256"]) != 64:
            raise ValueError("report sink hash")
    elif value["sha256"] is not None:
        raise ValueError("report sink hash")

def validate_report_source(value):
    keys = {"opened", "stable", "verified", "source_before", "source_after",
            "sealed_backing", "requested_memfd_flags", "seals", "artifact"}
    if type(value) is not dict or set(value) != keys or any(
            type(value[key]) is not bool for key in ("opened", "stable", "verified")) or \
       type(value["requested_memfd_flags"]) is not int or type(value["seals"]) is not int:
        raise ValueError("report source")
    for key in ("source_before", "source_after", "sealed_backing"):
        if value[key] is not None:
            validate_report_stat(value[key])
    validate_sink(value["artifact"])

def validate_report_process(value):
    keys = {"pid", "identity_observed", "ppid", "pgid_at_observation",
            "sid_at_observation", "startticks", "kill_sent", "reaped",
            "raw_wait_status", "wait"}
    if type(value) is not dict or set(value) != keys or any(
            type(value[key]) is not int for key in (
                "pid", "ppid", "pgid_at_observation", "sid_at_observation",
                "startticks")) or any(type(value[key]) is not bool for key in (
                    "identity_observed", "kill_sent", "reaped")):
        raise ValueError("report process")
    if value["reaped"]:
        wait = value["wait"]
        if type(value["raw_wait_status"]) is not int or type(wait) is not dict or \
           set(wait) != {"exited", "signaled", "exit_code", "signal", "core_dumped"} or \
           any(type(wait[key]) is not bool for key in (
               "exited", "signaled", "core_dumped")):
            raise ValueError("report wait")
    elif value["raw_wait_status"] is not None or value["wait"] is not None:
        raise ValueError("report wait")

def validate_packet_schema(packet):
    kind, site = packet["kind"], packet["site"]
    if kind == "READY": extras = set()
    elif kind in ("BEFORE", "AFTER") and site in ("events-create", "report-create"):
        extras = CREATE
    elif kind == "BEFORE" and site == "request-write": extras = WRITE_BEFORE
    elif kind == "AFTER" and site == "request-write": extras = WRITE_AFTER
    elif kind in ("BEFORE", "AFTER") and site in (
            "request-sync", "report-flush", "report-sync"): extras = IO
    elif kind == "BIND": extras = BIND
    elif kind in OBS: extras = OBS[kind]
    else: raise ValueError("witness kind")
    if set(packet) != COMMON | extras:
        raise ValueError("witness exact fields")
    for name in ("target_stat", "dir_stat", "old_stat", "new_stat"):
        if name in packet and packet[name] is not None: validate_stat(packet[name])
    if kind == "BEFORE" and (packet["return"] is not None or
            packet["errno_authoritative"] is not False or packet["errno"] is not None):
        raise ValueError("before result")
    if kind == "AFTER":
        result = packet["return"]
        if type(result) is not int or packet["errno_authoritative"] is not (result < 0) or \
           (result < 0 and (type(packet["errno"]) is not int or packet["errno"] <= 0)) or \
           (result >= 0 and packet["errno"] is not None):
            raise ValueError("after result")

def validate_packet_order(packets, selector, nonce, hashes, expected_count):
    if len(packets) != expected_count or expected_count != COUNTS[selector]:
        raise ValueError("witness packet count")
    signatures = []
    for sequence, packet in enumerate(packets):
        validate_packet_schema(packet)
        if type(packet["schema_version"]) is not int or type(packet["nonce"]) is not str or \
           type(packet["selector"]) is not int or type(packet["sequence"]) is not int or \
           type(packet["kind"]) is not str or packet["schema_version"] != 2 or \
           packet["nonce"] != nonce or \
           packet["selector"] != selector or packet["sequence"] != sequence:
            raise ValueError("witness identity")
        if type(packet["monotonic_ns"]) is not int or packet["monotonic_ns"] <= 0 or \
           type(packet["collector_pid"]) is not int or packet["collector_pid"] <= 0 or \
           type(packet["collector_startticks"]) is not int or packet["collector_startticks"] <= 0:
            raise ValueError("witness monotonic")
        if packet["source_sha256"] != SOURCE_SHA:
            raise ValueError("source hash")
        for key in ("generated_sha256", "header_sha256", "elf_sha256"):
            if packet[key] != hashes[key]:
                raise ValueError("generated hash")
        if packet["phase"] != phase_for(selector, packet["site"], packet["kind"]):
            raise ValueError("witness phase")
        signatures.append((packet["kind"], packet["site"], packet["object"],
                           packet["occurrence"]))
    if signatures not in schedule_variants(selector):
        raise ValueError("witness schedule")

    request_identity, request_size, report_identity, report_id = None, 0, None, None
    creates, positive_ids = {}, set()
    for packet in packets[1:]:
        kind, site = packet["kind"], packet["site"]
        if kind == "BEFORE" and site in ("events-create", "report-create"):
            if packet["fd"] is not None or packet["target_stat"] is not None or \
               packet["acquisition_id"] is not None or type(packet["dirfd"]) is not int:
                raise ValueError("create before")
            validate_stat(packet["dir_stat"])
            if not stat.S_ISDIR(packet["dir_stat"]["mode"]):
                raise ValueError("witness directory type")
        elif kind == "AFTER" and site in ("events-create", "report-create"):
            failed = (site == "events-create" and selector == 1) or \
                     (site == "report-create" and selector == 4)
            if failed:
                if (packet["return"], packet["errno"], packet["fd"],
                    packet["target_stat"], packet["acquisition_id"]) != \
                   (-1, 28, None, None, None): raise ValueError("create failure")
            else:
                if packet["return"] < 0 or packet["fd"] != packet["return"] or \
                   type(packet["acquisition_id"]) is not int or packet["acquisition_id"] <= 0:
                    raise ValueError("create success")
                validate_stat(packet["target_stat"])
                if not stat.S_ISREG(packet["target_stat"]["mode"]):
                    raise ValueError("witness target type")
                if packet["target_stat"]["size"] != 0 or \
                   packet["target_stat"]["mode"] & 0o170777 != 0o100600 or \
                   packet["acquisition_id"] in positive_ids:
                    raise ValueError("create acquisition")
                positive_ids.add(packet["acquisition_id"])
                creates[site] = packet
        elif kind == "BIND":
            create = creates.get(site)
            if not create or packet["acquisition_id"] != create["acquisition_id"] or \
               packet["old_fd"] != create["fd"]:
                raise ValueError("bind acquisition")
            if not stat.S_ISREG(packet["old_stat"]["mode"]) or \
               not stat.S_ISREG(packet["new_stat"]["mode"]):
                raise ValueError("witness target type")
            for key in ("dev", "ino", "mode"):
                if packet["old_stat"][key] != packet["new_stat"][key] or \
                   packet["old_stat"][key] != create["target_stat"][key]:
                    raise ValueError("bind identity")
            if site == "report-create":
                report_identity = (packet["new_fd"], packet["new_stat"]["dev"],
                    packet["new_stat"]["ino"], packet["new_stat"]["mode"])
                report_id = packet["acquisition_id"]
        elif site == "request-write":
            stat_value = packet["target_stat"]
            if not stat.S_ISREG(stat_value["mode"]):
                raise ValueError("witness target type")
            identity = (packet["fd"], stat_value["dev"], stat_value["ino"], stat_value["mode"])
            if packet["acquisition_id"] != 0 or (request_identity and identity != request_identity):
                raise ValueError("request acquisition")
            request_identity = identity
            occurrence = packet["occurrence"]
            injected = selector in (2, 6)
            requested = 406 if occurrence == 1 else 399
            before_size = 0 if occurrence == 1 else 7
            if packet["requested_bytes"] != requested:
                raise ValueError("request bytes")
            if kind == "BEFORE" and stat_value["size"] != before_size:
                raise ValueError("request before size")
            if kind == "AFTER":
                result = 7 if injected and occurrence == 1 else -1 if occurrence == 2 else 406
                error = 28 if result < 0 else None
                if packet["return"] != result or packet["errno"] != error or \
                   packet["actual_bytes"] != max(result, 0) or \
                   stat_value["size"] != (7 if injected else 406):
                    raise ValueError("request write result")
                request_size = stat_value["size"]
        elif site == "request-sync":
            if not stat.S_ISREG(packet["target_stat"]["mode"]):
                raise ValueError("witness target type")
            stat_value = packet["target_stat"]
            identity = (packet["fd"], stat_value["dev"], stat_value["ino"],
                        stat_value["mode"])
            if request_identity is None or identity != request_identity:
                raise ValueError("request sync identity")
            expected_result = -1 if selector in (3, 6) else 0
            if packet["acquisition_id"] != 0 or packet["target_stat"]["size"] != request_size or \
               (kind == "AFTER" and (packet["return"] != expected_result or
                packet["errno"] != (5 if expected_result < 0 else None))):
                raise ValueError("request sync result")
        elif kind == "AFTER" and site == "report-flush" and packet["return"] != 0:
            raise ValueError("report flush result")
        elif kind == "AFTER" and site == "report-sync":
            expected_result = -1 if selector in (5, 6) else 0
            if packet["return"] != expected_result or \
               packet["errno"] != (5 if expected_result < 0 else None):
                raise ValueError("report sync result")
        if site in ("report-flush", "report-sync"):
            stat_value = packet["target_stat"]
            if not stat.S_ISREG(stat_value["mode"]):
                raise ValueError("witness target type")
            identity = (packet["fd"], stat_value["dev"], stat_value["ino"], stat_value["mode"])
            if identity != report_identity or packet["acquisition_id"] != report_id:
                raise ValueError("report acquisition")
    cleanup = [packet for packet in packets if packet["kind"] == "CLEANUP_FINAL"]
    if cleanup and (cleanup[0]["cleanup_complete"] is not True or
            not cleanup[0]["cleanup_start_ns"] < cleanup[0]["cleanup_finished_ns"] <
                cleanup[0]["cleanup_deadline_ns"] or cleanup[0]["group_pinned"] is not True or
            cleanup[0]["owned_count"] != 0 or cleanup[0]["owned_records_omitted"] != 0 or
            cleanup[0]["first_failure"] != "none" or cleanup[0]["first_failure_errno"] != 0):
        raise ValueError("collector cleanup result")
    ready = [packet for packet in packets if packet["kind"] == "CLEANUP_READY"]
    if ready and (ready[0]["waitid_return"], ready[0]["waitid_errno"],
            ready[0]["leader_reaped"], ready[0]["stdout_eof"],
            ready[0]["stderr_eof"], ready[0]["setup_eof"]) != \
            (-1, 10, True, True, True, True):
        raise ValueError("collector cleanup ready")

def validate_record(record, path, limit=1 << 20, shown_path=None):
    shown_path = path if shown_path is None else shown_path
    if type(record) is not dict or set(record) != {"path", "present", "size", "sha256"} or \
       record["path"] != str(shown_path) or type(record["present"]) is not bool:
        raise ValueError("evidence record")
    if not record["present"]:
        if record["size"] is not None or record["sha256"] is not None or Path(path).exists():
            raise ValueError("evidence absence")
        return None
    raw = read(Path(path), limit)
    if type(record["size"]) is not int or record["size"] != len(raw) or \
       record["sha256"] != sha(raw):
        raise ValueError("evidence hash")
    return raw

def validate_supervisor_observation(value):
    keys = {"observation", "pid", "ppid", "startticks", "monotonic_ns"}
    if type(value) is not dict or set(value) != keys or \
       value["observation"] not in ("observed", "missing", "error") or \
       type(value["pid"]) is not int or value["pid"] <= 0 or \
       type(value["monotonic_ns"]) is not int or value["monotonic_ns"] <= 0:
        raise ValueError("supervisor identity observation")
    if value["observation"] == "observed":
        if type(value["ppid"]) is not int or value["ppid"] <= 0 or \
           type(value["startticks"]) is not int or value["startticks"] <= 0:
            raise ValueError("supervisor identity observation")
    elif value["ppid"] is not None or value["startticks"] is not None:
        raise ValueError("supervisor identity observation")

def validate_supervisor_cleanup(cleanup, owner_identity, owner_wait_deadline_ns,
                                trigger_ns, deadline_ns, finished_ns):
    if type(cleanup) is not dict or set(cleanup) != {"complete", "events", "unresolved"} or \
       type(cleanup["complete"]) is not bool or type(cleanup["events"]) is not list:
        raise ValueError("supervisor cleanup")
    unresolved = cleanup["unresolved"]
    if type(unresolved) is not list:
        raise ValueError("supervisor cleanup unresolved")
    for value in unresolved:
        if type(value) is not dict:
            raise ValueError("supervisor cleanup unresolved")
        if value.get("kind") == "signal-error":
            if set(value) != {"kind", "stage", "pid", "startticks", "signal",
                    "errno", "monotonic_ns", "direct"} or \
               value["stage"] not in ("term", "kill") or \
               type(value["pid"]) is not int or value["pid"] <= 0 or \
               type(value["direct"]) is not bool or \
               type(value["signal"]) is not int or value["signal"] != \
                    (15 if value["stage"] == "term" else 9) or \
               type(value["errno"]) is not int or value["errno"] <= 0 or \
               type(value["monotonic_ns"]) is not int or value["monotonic_ns"] <= 0 or \
               (value["startticks"] is not None and
                (type(value["startticks"]) is not int or value["startticks"] <= 0)) or \
               (value["direct"] is False and value["startticks"] is None):
                raise ValueError("supervisor cleanup signal error")
        else:
            validate_cleanup_unresolved([value])
    events = cleanup["events"]
    if any(type(event) is not dict or type(event.get("monotonic_ns")) is not int or
           not trigger_ns <= event["monotonic_ns"] <= deadline_ns
           for event in events):
        raise ValueError("supervisor cleanup event time")
    if [event["monotonic_ns"] for event in events] != sorted(
            event["monotonic_ns"] for event in events):
        raise ValueError("supervisor cleanup event order")
    owner_pid = owner_identity.get("pid")
    supervisor_pid = owner_identity.get("ppid")
    known = {owner_pid: owner_identity["startticks"]} \
        if owner_identity.get("state") == "MATCHED" else {}
    direct_waits = []
    direct_wait_seen = False
    echild_seen = False
    for index, event in enumerate(events):
        kind = event.get("kind")
        if echild_seen or (direct_wait_seen and kind == "signal" and
                event.get("direct_child") is True):
            raise ValueError("supervisor cleanup terminal order")
        if kind == "identity":
            keys = {"kind", "phase", "observation", "pid", "ppid",
                    "startticks", "matched", "monotonic_ns"}
            if set(event) != keys or type(event["matched"]) is not bool or \
               not cleanup_phase(event["phase"], suffix=True):
                raise ValueError("supervisor cleanup identity")
            validate_supervisor_observation({key: event[key] for key in
                ("observation", "pid", "ppid", "startticks", "monotonic_ns")})
            if event["observation"] != "observed" and event["matched"] is not False:
                raise ValueError("supervisor cleanup identity")
            if event["matched"] is True and index > 0:
                prior = events[index - 1]
                if prior.get("kind") == "identity" and prior.get("matched") is True and \
                   (prior.get("pid"), prior.get("ppid"), prior.get("startticks")) == \
                   (event["pid"], event["ppid"], event["startticks"]):
                    known[event["pid"]] = event["startticks"]
        elif kind == "signal":
            # Keep the supervisor signal schema distinct from owner cleanup.
            signal_keys = {"kind", "pid", "startticks", "signal", "monotonic_ns"}
            direct_signal = "direct_child" in event
            expected_keys = signal_keys | ({"direct_child"} if direct_signal else set())
            if set(event) != expected_keys or type(event["pid"]) is not int or event["pid"] <= 0 or \
               (direct_signal and event["direct_child"] is not True) or \
               type(event["signal"]) is not int or \
               event["signal"] not in (9, 15) or \
               (event["startticks"] is not None and
                (type(event["startticks"]) is not int or event["startticks"] <= 0)) or \
               (event["startticks"] is None and event["pid"] in known) or \
               (event["startticks"] is not None and
                known.get(event["pid"]) != event["startticks"]):
                raise ValueError("supervisor cleanup signal")
            if direct_signal and (event["pid"] != owner_pid or
                    event["startticks"] != owner_identity["startticks"]):
                raise ValueError("supervisor direct signal identity")
            if not direct_signal and event["startticks"] is None:
                raise ValueError("supervisor cleanup signal identity")
            if not direct_signal and event["pid"] == owner_pid:
                raise ValueError("supervisor direct signal schema")
            if not direct_signal and index < 2:
                raise ValueError("supervisor cleanup signal identity")
            if not direct_signal:
                first, second = events[index - 2:index]
                if any(value.get("kind") != "identity" or
                       value.get("matched") is not True or
                       value.get("pid") != event["pid"] or
                       value.get("ppid") != supervisor_pid or
                       value.get("startticks") != event["startticks"]
                       for value in (first, second)):
                    raise ValueError("supervisor cleanup signal identity")
        elif kind == "wait":
            if set(event) != {"kind", "pid", "startticks", "raw_wait_status",
                    "direct", "monotonic_ns"} or type(event["pid"]) is not int or \
               event["pid"] <= 0 or type(event["raw_wait_status"]) is not int or \
               type(event["direct"]) is not bool or \
               (event["startticks"] is not None and
                (type(event["startticks"]) is not int or event["startticks"] <= 0)):
                raise ValueError("supervisor cleanup wait")
            if event["direct"]:
                if event["pid"] != owner_pid or event["startticks"] != \
                        owner_identity["startticks"]:
                    raise ValueError("supervisor direct wait identity")
                direct_waits.append(event)
                direct_wait_seen = True
            elif event["startticks"] is not None and \
                    known.get(event["pid"]) != event["startticks"]:
                raise ValueError("supervisor cleanup adopted wait")
        elif kind == "owned-scan":
            if set(event) != {"kind", "monotonic_ns", "pids"} or \
               type(event["pids"]) is not list:
                raise ValueError("supervisor owned scan")
            for identity in event["pids"]:
                if type(identity) is not dict or set(identity) != {
                        "pid", "ppid", "startticks"} or \
                   identity["ppid"] != supervisor_pid or any(
                       type(identity[key]) is not int or identity[key] <= 0
                       for key in identity):
                    raise ValueError("supervisor owned scan")
                known[identity["pid"]] = identity["startticks"]
        elif kind == "echild":
            if set(event) != {"kind", "monotonic_ns", "return", "errno"} or \
               type(event["return"]) is not int or event["return"] != -1 or \
               type(event["errno"]) is not int or event["errno"] != 10:
                raise ValueError("supervisor echild")
            echild_seen = True
        else:
            raise ValueError("supervisor cleanup event")
    if cleanup["complete"]:
        if unresolved or len(events) < 3 or \
           events[-3].get("kind") != "owned-scan" or events[-3].get("pids") != [] or \
           events[-2].get("kind") != "owned-scan" or events[-2].get("pids") != [] or \
           events[-1].get("kind") != "echild":
            raise ValueError("supervisor cleanup terminal")
        if sum(event.get("kind") == "echild" for event in events) != 1:
            raise ValueError("supervisor cleanup terminal")
        if owner_pid is not None and (len(direct_waits) != 1 or
                direct_waits[0]["pid"] != owner_pid or
                direct_waits[0]["startticks"] != owner_identity["startticks"] or
                direct_waits[0]["raw_wait_status"] != 0 or
                direct_waits[0]["monotonic_ns"] > owner_wait_deadline_ns):
            raise ValueError("supervisor direct wait")
    # Cleanup failures are sticky: later empty scans/ECHILD cannot erase an
    # unresolved owner or adopted child.
    nonempty_scan = any(event.get("kind") == "owned-scan" and event.get("pids")
                        for event in events)
    if nonempty_scan and not cleanup["unresolved"]:
        raise ValueError("supervisor cleanup unresolved")
    if not cleanup["complete"] and not cleanup["unresolved"]:
        raise ValueError("supervisor cleanup unresolved")
    if finished_ns > deadline_ns:
        raise ValueError("supervisor cleanup deadline")

def validate_supervisor(root):
    raw = read(root / "supervisor-result.json", 1 << 20)
    result = strict(raw)
    if type(result) is not dict or set(result) != SUPERVISOR_KEYS or \
       type(result["schema_version"]) is not int or result["schema_version"] != 1 or \
       type(result["kind"]) is not str or result["kind"] != \
            "STORAGE_FAULT_V2_SUPERVISOR" or result["status"] != "COMPLETE" or \
       result["attempt_root"] != str(root) or result["preflight_failure"] is not None or \
       result["sigchld_default"] is not True or result["sentinel_wait_passed"] is not True:
        raise ValueError("supervisor result")
    integer_fields = ("preflight_started_ns", "sentinel_wait_deadline_ns",
        "started_ns", "owner_wait_deadline_ns", "cleanup_trigger_ns",
        "supervisor_cleanup_deadline_ns", "supervisor_deadline_ns", "finished_ns")
    if any(type(result[key]) is not int or result[key] <= 0 for key in integer_fields) or \
       result["sentinel_wait_deadline_ns"] != result["preflight_started_ns"] + 5000000000 or \
       not result["preflight_started_ns"] <= result["started_ns"] <= \
            result["sentinel_wait_deadline_ns"] or \
       result["owner_wait_deadline_ns"] != result["started_ns"] + 220000000000 or \
       result["supervisor_cleanup_deadline_ns"] != result["cleanup_trigger_ns"] + \
            22000000000 or result["supervisor_deadline_ns"] != \
            result["started_ns"] + 248000000000 or \
       not result["cleanup_trigger_ns"] <= result["finished_ns"] <= \
            result["supervisor_deadline_ns"]:
        raise ValueError("supervisor deadlines")
    identity = result["owner_identity"]
    observations = result["owner_identity_observations"]
    if type(identity) is not dict or set(identity) != {
            "state", "pid", "ppid", "startticks", "spawn_error"} or \
       identity["state"] != "MATCHED" or identity["spawn_error"] is not None or \
       any(type(identity[key]) is not int or identity[key] <= 0
           for key in ("pid", "ppid", "startticks")) or \
       type(observations) is not list or len(observations) != 2:
        raise ValueError("supervisor owner identity")
    for observation in observations:
        validate_supervisor_observation(observation)
    if any(observation["observation"] != "observed" or
           (observation["pid"], observation["ppid"], observation["startticks"]) !=
           (identity["pid"], identity["ppid"], identity["startticks"])
           for observation in observations):
        raise ValueError("supervisor owner identity")
    if result["owner_wait_observed"] is not True or \
       type(result["owner_exit_code"]) is not int or result["owner_exit_code"] != 0 or \
       result["owner_signal"] is not None:
        raise ValueError("supervisor owner wait")
    for name in ("owner_result", "witness", "owner_errors"):
        present = result[name + "_present"]
        digest = result[name + "_sha256"]
        if present is not True or type(digest) is not str or \
                re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise ValueError("supervisor evidence record")
        actual = read(root / ({"owner_result": "owner-result.json",
            "witness": "witness.jsonl", "owner_errors": "owner-errors.jsonl"}[name]),
            1 << 20)
        if sha(actual) != digest:
            raise ValueError("supervisor evidence hash")
    for name in ("stdout", "stderr"):
        digest = result["owner_" + name + "_sha256"]
        if type(digest) is not str or re.fullmatch(r"[0-9a-f]{64}", digest) is None or \
           sha(read(root / ("owner-supervisor." + name + ".bin"), 1 << 20)) != digest:
            raise ValueError("supervisor capture hash")
    if read(root / "owner-errors.jsonl", 1 << 20) != b"":
        raise ValueError("supervisor owner errors")
    validate_supervisor_cleanup(result["supervisor_cleanup"], identity,
        result["owner_wait_deadline_ns"], result["cleanup_trigger_ns"],
        result["supervisor_cleanup_deadline_ns"], result["finished_ns"])
    if result["supervisor_cleanup"]["complete"] is not True:
        raise ValueError("supervisor cleanup incomplete")
    return result

def validate_owner(root, owner, selector, expected_wait):
    exact = {"schema_version", "kind", "nonce", "selector", "argv", "owner",
        "environment", "collector", "packet_count", "hashes", "inputs",
        "runtime_inputs", "captures", "artifacts", "owner_failure",
        "secondary_failures", "result_serialized_ns", "cleanup", "backend_enabled",
        "application_acceptance", "deadlines"}
    if type(owner) is not dict or set(owner) != exact or \
       type(owner["schema_version"]) is not int or owner["schema_version"] != 2 or \
       type(owner["kind"]) is not str or owner["kind"] != "OWNER_RESULT" or \
       type(owner["selector"]) is not int or owner["selector"] != selector or \
       type(owner["result_serialized_ns"]) is not int or owner["result_serialized_ns"] <= 0 or \
       type(owner["packet_count"]) is not int or owner["packet_count"] < 0 or \
       owner["backend_enabled"] is not False or \
       owner["application_acceptance"] is not False:
        raise ValueError("owner result")
    owner_errors = validate_owner_errors(read(root / "owner-errors.jsonl"), owner)
    owner_id = owner["owner"]
    if set(owner_id) != {"pid", "startticks"} or any(
            type(owner_id[key]) is not int or owner_id[key] <= 0 for key in owner_id):
        raise ValueError("owner identity")
    collector = owner["collector"]
    if set(collector) != {"pid", "identity_observed", "ppid", "startticks",
                         "reaped", "raw_wait_status"} or \
       collector["identity_observed"] is not True or collector["reaped"] is not True or \
       collector["ppid"] != owner_id["pid"] or collector["raw_wait_status"] != expected_wait or \
       type(collector["raw_wait_status"]) is not int or \
       any(type(collector[key]) is not int or collector[key] <= 0
           for key in ("pid", "ppid", "startticks")):
        raise ValueError("collector identity")
    hashes = owner["hashes"]
    if set(hashes) != {"source_sha256", "generated_sha256", "header_sha256", "elf_sha256"} or \
       hashes["source_sha256"] != SOURCE_SHA or any(type(value) is not str or
       re.fullmatch(r"[0-9a-f]{64}", value) is None for value in hashes.values()):
        raise ValueError("owner hashes")
    inputs = owner["inputs"]
    if set(inputs) != {"source", "generated_source", "header", "elf"}:
        raise ValueError("owner inputs")
    limits = {"source": 1 << 20, "generated_source": 1 << 20,
              "header": 1 << 20, "elf": 16 << 20}
    keys = {"source": "source_sha256", "generated_source": "generated_sha256",
            "header": "header_sha256", "elf": "elf_sha256"}
    for name in inputs:
        raw = validate_record(inputs[name], Path(inputs[name]["path"]), limits[name])
        if raw is None or sha(raw) != hashes[keys[name]]:
            raise ValueError("input binding")
    runtime = owner["runtime_inputs"]
    specs = {"request": ("request.bin", 406, REQUEST_SHA),
        "selected_inputs": ("selected-inputs.json", 76, SELECTED_SHA),
        "fixture": ("fixture", 27448, FIXTURE_SHA)}
    if type(runtime) is not dict or set(runtime) != set(specs):
        raise ValueError("runtime inputs")
    retained_root = (root / "retained-inputs").resolve()
    for name, (filename, size, digest) in specs.items():
        record = runtime[name]
        destination = retained_root / filename
        if type(record) is not dict or set(record) != {
                "source_path", "destination_path", "size", "sha256"} or \
           type(record["source_path"]) is not str or \
           record["destination_path"] != str(destination) or \
           record["size"] != size or record["sha256"] != digest or \
           sha(read(destination, size)) != digest:
            raise ValueError("runtime input binding")
    if runtime["fixture"]["source_path"] != "/work/cases/stdin-devnull/inputs/fixture":
        raise ValueError("fixture source path")
    if type(owner["argv"]) is not list or not owner["argv"] or \
       any(type(value) is not str for value in owner["argv"]) or \
       owner["argv"] != [inputs["elf"]["path"],
            "--linux-sealed-infrastructure-v1",
            runtime["request"]["destination_path"],
            runtime["selected_inputs"]["destination_path"],
            str((root / "collection").resolve())]:
        raise ValueError("executed ELF path")
    expected_environment = {"LANG": "C", "LC_ALL": "C", "PATH": "/usr/bin:/bin",
        "M02_SF_NONCE": owner["nonce"], "M02_SF_SOURCE_SHA256": hashes["source_sha256"],
        "M02_SF_GENERATED_SHA256": hashes["generated_sha256"],
        "M02_SF_HEADER_SHA256": hashes["header_sha256"],
        "M02_SF_ELF_SHA256": hashes["elf_sha256"]}
    if owner["environment"] != expected_environment:
        raise ValueError("owner environment")
    captures = owner["captures"]
    if set(captures) != {"stdout", "stderr"}:
        raise ValueError("owner captures")
    for name in captures:
        raw = validate_record(captures[name], root / (name + ".bin"),
                              shown_path=name + ".bin")
        if raw != b"": raise ValueError("owner capture bytes")
    cleanup = owner["cleanup"]
    deadlines = owner["deadlines"]
    deadline_keys = {"owner_start_ns", "ready_deadline_ns",
        "release_send_start_ns", "collection_deadline_ns",
        "first_postfork_receipt_ns", "postfork_deadline_ns",
        "cleanup_trigger_ns", "cleanup_deadline_ns"}
    mandatory_deadlines = {"owner_start_ns", "ready_deadline_ns",
        "cleanup_trigger_ns", "cleanup_deadline_ns"}
    if type(deadlines) is not dict or set(deadlines) != deadline_keys or \
       any(type(deadlines[key]) is not int or deadlines[key] <= 0
           for key in mandatory_deadlines) or any(
           deadlines[key] is not None and (type(deadlines[key]) is not int or
           deadlines[key] <= 0) for key in deadline_keys - mandatory_deadlines) or \
       deadlines["ready_deadline_ns"] != deadlines["owner_start_ns"] + 10000000000 or \
       deadlines["cleanup_deadline_ns"] != deadlines["cleanup_trigger_ns"] + 22000000000:
        raise ValueError("owner deadlines")
    if deadlines["release_send_start_ns"] is None:
        if any(deadlines[key] is not None for key in ("collection_deadline_ns",
                "first_postfork_receipt_ns", "postfork_deadline_ns")):
            raise ValueError("owner release deadline")
    elif deadlines["collection_deadline_ns"] != \
            deadlines["release_send_start_ns"] + 180000000000:
        raise ValueError("owner release deadline")
    if deadlines["first_postfork_receipt_ns"] is None:
        if deadlines["postfork_deadline_ns"] is not None:
            raise ValueError("owner postfork deadline")
    elif deadlines["postfork_deadline_ns"] != min(
            deadlines["collection_deadline_ns"],
            deadlines["first_postfork_receipt_ns"] + 60000000000):
        raise ValueError("owner postfork deadline")
    if deadlines["first_postfork_receipt_ns"] is not None and \
       deadlines["release_send_start_ns"] is not None and \
       deadlines["first_postfork_receipt_ns"] <= deadlines["release_send_start_ns"]:
        raise ValueError("owner postfork receipt")
    validate_cleanup_unresolved(cleanup.get("unresolved") if
                                type(cleanup) is dict else None)
    if set(cleanup) != {"complete", "trigger_kind", "trigger_ns", "cleanup_start_ns",
            "cleanup_deadline_ns", "cleanup_finished_ns", "events", "adopted_reaps",
            "unresolved"} or cleanup["complete"] is not True or \
       cleanup["trigger_kind"] != "normal-eof" or cleanup["adopted_reaps"] != [] or \
       cleanup["unresolved"] != [] or cleanup["cleanup_deadline_ns"] != \
            cleanup["trigger_ns"] + 22000000000 or not (
            cleanup["trigger_ns"] <= cleanup["cleanup_start_ns"] <=
            cleanup["cleanup_finished_ns"] <= cleanup["cleanup_deadline_ns"]):
        raise ValueError("owner cleanup")
    if cleanup["trigger_ns"] != deadlines["cleanup_trigger_ns"] or \
       cleanup["cleanup_deadline_ns"] != deadlines["cleanup_deadline_ns"] or \
       cleanup["cleanup_finished_ns"] > owner["result_serialized_ns"]:
        raise ValueError("owner cleanup deadline join")
    events = cleanup["events"]
    if len(events) < 4 or events[-3].get("kind") != "owned-scan" or \
       events[-3].get("pids") != [] or events[-2].get("kind") != "owned-scan" or \
       events[-2].get("pids") != [] or events[-1] != {
           "kind": "echild", "monotonic_ns": events[-1].get("monotonic_ns"),
           "return": -1, "errno": 10}:
        raise ValueError("owner cleanup terminal")
    timestamps = []
    known_births = {collector["pid"]: collector["startticks"]}
    signaled_adopted, waited_adopted = set(), set()
    for event_index, event in enumerate(events):
        kind = event.get("kind")
        if kind == "identity":
            keys = {"kind", "phase", "observation", "pid", "ppid", "startticks",
                    "matched", "monotonic_ns"}
            if set(event) != keys or not cleanup_phase(event["phase"], suffix=True) or \
                    event["observation"] not in (
                    "observed", "missing", "error") or type(event["matched"]) is not bool or \
                    type(event["pid"]) is not int or event["pid"] <= 0:
                raise ValueError("owner identity event")
            if event["observation"] == "observed":
                if type(event["ppid"]) is not int or event["ppid"] <= 0 or \
                   type(event["startticks"]) is not int or event["startticks"] <= 0:
                    raise ValueError("owner identity event")
            elif event["ppid"] is not None or event["startticks"] is not None or \
                    event["matched"] is not False:
                raise ValueError("owner identity event")
            if event["observation"] == "observed" and event["matched"] is True and \
                    event_index > 0:
                previous = events[event_index - 1]
                if previous.get("kind") == "identity" and \
                   previous.get("observation") == "observed" and \
                   previous.get("matched") is True and \
                   (previous.get("pid"), previous.get("ppid"),
                    previous.get("startticks")) == \
                   (event["pid"], event["ppid"], event["startticks"]):
                    known_births[event["pid"]] = event["startticks"]
        elif kind == "signal":
            if set(event) != {"kind", "pid", "startticks", "signal", "monotonic_ns"} or \
               any(type(event[key]) is not int or event[key] <= 0 for key in
                   ("pid", "startticks", "monotonic_ns")) or \
               type(event["signal"]) is not int or event["signal"] not in (9, 15):
                raise ValueError("owner signal event")
            if event_index < 2:
                raise ValueError("owner signal identity")
            first, second = events[event_index - 2:event_index]
            expected_prefix = ("term-identity" if event["signal"] == 15 else
                               "kill-identity") if event["pid"] == collector["pid"] \
                else "owned-scan-"
            if any(item.get("kind") != "identity" or
                   item.get("observation") != "observed" or
                   item.get("matched") is not True or item.get("pid") != event["pid"] or
                   item.get("ppid") != owner_id["pid"] or
                   item.get("startticks") != event["startticks"]
                   for item in (first, second)) or \
               (expected_prefix == "owned-scan-" and not (
                    re.fullmatch(r"owned-scan-(\d+)-1", first["phase"]) and
                    second["phase"] == first["phase"][:-1] + "2")) or \
               (expected_prefix != "owned-scan-" and
                    (first["phase"] != expected_prefix + "-1" or
                     second["phase"] != expected_prefix + "-2")):
                raise ValueError("owner signal identity")
            known_births[event["pid"]] = event["startticks"]
            if event["pid"] != collector["pid"]:
                signaled_adopted.add((event["pid"], event["startticks"]))
        elif kind == "wait":
            if set(event) != {"kind", "pid", "startticks", "raw_wait_status",
                              "direct", "monotonic_ns"} or type(event["direct"]) is not bool or \
               type(event["pid"]) is not int or event["pid"] <= 0 or \
               (event["startticks"] is not None and (type(event["startticks"]) is not int or
                    event["startticks"] <= 0)) or \
               type(event["raw_wait_status"]) is not int:
                raise ValueError("owner wait event")
            if event["direct"] is False and ((event["startticks"] is None and
                    event["pid"] in known_births) or (event["startticks"] is not None and
                    known_births.get(event["pid"]) != event["startticks"])):
                raise ValueError("owner adopted wait identity")
            if event["direct"] is False and event["startticks"] is not None:
                waited_adopted.add((event["pid"], event["startticks"]))
        elif kind == "owned-scan":
            if set(event) != {"kind", "monotonic_ns", "pids"} or type(event["pids"]) is not list:
                raise ValueError("owner scan event")
            for identity in event["pids"]:
                if set(identity) != {"pid", "ppid", "startticks"} or \
                   identity["ppid"] != owner_id["pid"] or any(
                       type(identity[key]) is not int or identity[key] <= 0 for key in identity):
                    raise ValueError("owner scan identity")
                known_births[identity["pid"]] = identity["startticks"]
        elif kind == "echild":
            if set(event) != {"kind", "monotonic_ns", "return", "errno"} or \
               type(event["return"]) is not int or event["return"] != -1 or \
               type(event["errno"]) is not int or event["errno"] != 10:
                raise ValueError("owner echild event")
        else:
            raise ValueError("owner cleanup event kind")
        if type(event["monotonic_ns"]) is not int or not (
                cleanup["cleanup_start_ns"] <= event["monotonic_ns"] <=
                cleanup["cleanup_deadline_ns"]):
            raise ValueError("owner cleanup event time")
        timestamps.append(event["monotonic_ns"])
    if timestamps != sorted(timestamps):
        raise ValueError("owner cleanup event order")
    if not signaled_adopted <= waited_adopted:
        raise ValueError("owner adopted signal wait")
    waits = [event for event in events if event.get("kind") == "wait" and
             event.get("direct") is True]
    if len(waits) != 1 or waits[0].get("pid") != collector["pid"] or \
       waits[0].get("startticks") != collector["startticks"] or \
       waits[0].get("raw_wait_status") != expected_wait:
        raise ValueError("owner direct wait")
    if owner["packet_count"] != COUNTS[selector]:
        raise ValueError("owner packet count")
    if owner_errors:
        raise ValueError("owner infrastructure errors")
    return hashes, collector

_MISSING_STATUS = object()

def validate(root, selector, supervisor_raw_wait_status=_MISSING_STATUS):
    if type(supervisor_raw_wait_status) is not int or \
       supervisor_raw_wait_status != 0:
        raise ValueError("supervisor raw wait status")
    if type(selector) is not int or selector not in EXPECTED:
        raise ValueError("selector")
    root = Path(root).resolve()
    expected_wait, phase, report_kind, status, failure, error, count = EXPECTED[selector]
    supervisor = validate_supervisor(root)
    owner = strict(read(root / "owner-result.json"))
    if (owner.get("owner", {}).get("pid"), owner.get("owner", {}).get("startticks")) != \
            (supervisor["owner_identity"]["pid"],
             supervisor["owner_identity"]["startticks"]):
        raise ValueError("supervisor owner result identity")
    hashes, collector = validate_owner(root, owner, selector, expected_wait)
    nonce = owner.get("nonce")
    if type(nonce) is not str or len(nonce) != 32 or any(
            char not in "0123456789abcdef" for char in nonce):
        raise ValueError("nonce")
    rows = journal(root / "witness.jsonl")
    if not exact_equal(rows[-1]["packet"], owner):
        raise ValueError("owner publication")
    packets = [row["packet"] for row in rows[:-1]]
    validate_packet_order(packets, selector, nonce, hashes, count)
    deadlines = owner["deadlines"]
    packet_rows = rows[:-1]
    if not packet_rows or packet_rows[0]["packet"].get("kind") != "READY" or \
       packet_rows[0]["packet"].get("monotonic_ns", 0) < deadlines["owner_start_ns"] or \
       packet_rows[0]["receipt_monotonic_ns"] > deadlines["ready_deadline_ns"] or \
       deadlines["release_send_start_ns"] is None or \
       deadlines["release_send_start_ns"] < packet_rows[0]["receipt_monotonic_ns"]:
        raise ValueError("owner ready chronology")
    if any(type(row["packet"].get("monotonic_ns")) is not int or
           row["packet"]["monotonic_ns"] > row["receipt_monotonic_ns"]
           for row in packet_rows):
        raise ValueError("witness receipt chronology")
    first_postfork = next((row["receipt_monotonic_ns"] for row in packet_rows
        if row["packet"].get("phase") == "post-fork"), None)
    if first_postfork != deadlines["first_postfork_receipt_ns"]:
        raise ValueError("owner postfork receipt join")
    active_ceiling = deadlines["postfork_deadline_ns"] or \
        deadlines["collection_deadline_ns"]
    if any(row["receipt_monotonic_ns"] > active_ceiling for row in packet_rows[1:]) or \
       deadlines["cleanup_trigger_ns"] < packet_rows[-1]["receipt_monotonic_ns"] or \
       rows[-1]["receipt_monotonic_ns"] < owner["result_serialized_ns"]:
        raise ValueError("owner terminal chronology")
    if any(packet["collector_pid"] != collector["pid"] or
           packet["collector_startticks"] != collector["startticks"] for packet in packets):
        raise ValueError("collector packet identity")
    if any(rows[index]["receipt_monotonic_ns"] >= rows[index + 1]["receipt_monotonic_ns"]
           for index in range(len(rows) - 1)):
        raise ValueError("receipt order")
    collection = root / "collection"
    artifacts = owner["artifacts"]
    if set(artifacts) != {"events", "request", "report"}:
        raise ValueError("owner artifacts")
    artifact_bytes = {}
    for name, filename in (("events", "events.jsonl"), ("request", "request.bin"),
                           ("report", "report.json")):
        artifact_bytes[name] = validate_record(artifacts[name], collection / filename)
    if artifacts["events"]["present"] is (selector == 1) or \
       artifacts["request"]["present"] is (selector == 1) or \
       artifacts["report"]["present"] is (selector == 4):
        raise ValueError("artifact presence")
    events = None if selector == 1 else validate_events(
        artifact_bytes["events"], selector, collector)
    report_path = collection / "report.json"
    if report_kind == "absent":
        if report_path.exists():
            raise ValueError("fabricated report")
    else:
        report_raw = artifact_bytes["report"]
        report = strict(report_raw)
        if set(report) != REPORT_KEYS:
            raise ValueError("report fields")
        if report.get("schema_version") != 1 or \
           report.get("kind") != "linux-sealed-infrastructure-collection" or \
           report.get("collector_mode") != "linux-sealed-infrastructure-v1" or \
           report.get("status") != status or report.get("first_failure") != failure or \
           report.get("first_failure_errno") != error or \
           report.get("collector_pid") != collector["pid"] or \
           any(report.get(key) is not False for key in
               ("application_acceptance", "transport_acceptance", "backend_enabled")):
            raise ValueError("report result")
        if report["configured_execution_mechanism"] != \
                "execveat-AT_EMPTY_PATH-sealed-memfd" or \
           report["pathname_execution"] is not False or \
           report["loader_closure_verified"] is not False or \
           report["native_payload"] is not None or \
           report["collector_interruption_signal"] != 0 or \
           any(type(report[key]) is not int or report[key] < 0 for key in (
               "collector_uid", "collector_euid", "first_failure_monotonic_ns",
               "owned_records_omitted")) or type(report["owned_children"]) is not list:
            raise ValueError("report fixed fields")
        desired = report["desired"]
        desired_keys = {"role", "request_profile", "uid", "gid", "group",
            "umask", "argc", "envc", "stdin_mode", "case_id_hex",
            "source_selector_hex", "cwd_hex", "stdin_selector_hex",
            "attempt_id_hex", "selected_inputs_sha256"}
        if report["request_valid"]:
            if type(desired) is not dict or set(desired) != desired_keys or \
               any(type(desired[key]) is not int for key in (
                   "role", "request_profile", "uid", "gid", "group", "umask",
                   "argc", "envc", "stdin_mode")) or any(
                   type(desired[key]) is not str for key in desired_keys - {
                       "role", "request_profile", "uid", "gid", "group", "umask",
                       "argc", "envc", "stdin_mode"}):
                raise ValueError("report desired")
            if desired != EXPECTED_DESIRED:
                raise ValueError("report desired binding")
        elif desired is not None:
            raise ValueError("report desired")
        if type(report["setup_words"]) is not list or \
           len(report["setup_words"]) != 48 or any(
               type(value) is not int or value < 0 for value in report["setup_words"]):
            raise ValueError("report setup words")
        validate_report_source(report["executable"])
        validate_report_source(report["stdin"])
        if report["devnull_identity"] is not None:
            validate_report_stat(report["devnull_identity"])
        if type(report["artifacts"]) is not list or len(report["artifacts"]) != 10:
            raise ValueError("report artifacts")
        for sink in report["artifacts"]:
            validate_sink(sink)
        names = ["request.bin", "selected-inputs.bin", "argv.nul", "env.nul",
            "events.jsonl", "executable.verified.bin", None, "stdout.bin",
            "stderr.bin", "setup.bin"]
        limits = [65537, 4194304, 65536, 65536, 65536, 1048576, None,
                  65536, 65536, 768]
        attempted = {4} if selector == 1 else {0, 4} if selector in (2, 6) \
            else {0, 1, 2, 3, 4, 5, 7, 8, 9}
        for index, sink in enumerate(report["artifacts"]):
            if index not in attempted:
                if sink is not None:
                    raise ValueError("report artifact position")
                continue
            if sink is None or sink["attempted_name"] != names[index] or \
               sink["limit_bytes"] != limits[index]:
                raise ValueError("report artifact position")
            if sink["created"]:
                raw = read(collection / names[index], limits[index])
                if sink["stored_bytes"] != len(raw) or sink["sha256"] != sha(raw) or \
                   (not sink["io_error"] and sink["seen_bytes"] != len(raw)):
                    raise ValueError("report artifact binding")
        if selector == 1:
            events_sink = report["artifacts"][4]
            if events_sink is None or events_sink != {
                    "attempted_name": "events.jsonl", "created": False,
                    "fd_available": False, "creation_errno": 28, "fd_errno": 0,
                    "path": None, "limit_bytes": 65536, "seen_bytes": 0,
                    "stored_bytes": 0, "truncated": False, "io_error": False,
                    "sha256": None}:
                raise ValueError("report events create failure")
        if selector in (2, 6):
            request_sink = report["artifacts"][0]
            if request_sink is None or request_sink["attempted_name"] != "request.bin" or \
               request_sink["seen_bytes"] != 406 or request_sink["stored_bytes"] != 7 or \
               request_sink["truncated"] is not False or request_sink["io_error"] is not True or \
               request_sink["sha256"] != PREFIX_SHA:
                raise ValueError("report request sink")
        report_io = [packet for packet in packets if packet.get("site") in (
            "report-flush", "report-sync")]
        if any((packet["kind"] == "BEFORE" and packet["site"] == "report-flush"
                and not 0 <= packet["target_stat"]["size"] <= len(report_raw)) or
               (not (packet["kind"] == "BEFORE" and
                     packet["site"] == "report-flush") and
                packet["target_stat"]["size"] != len(report_raw))
               for packet in report_io):
            raise ValueError("report witness size")
        post = selector in (0, 3, 4, 5)
        if report.get("child_created") is not post or report.get("request_valid") is not (
                selector not in (1, 2, 6)) or report.get("cleanup_complete") is not post or \
           report.get("streams") != {"stdout_eof": post, "stderr_eof": post,
                                     "setup_eof": post}:
            raise ValueError("report lifecycle")
        if post:
            child = report.get("linux_child")
            validate_report_process(child)
            reap = next(packet for packet in packets if packet["kind"] == "REAP")
            final = next(packet for packet in packets if packet["kind"] == "CLEANUP_FINAL")
            if (child["pid"], child["startticks"], child["raw_wait_status"]) != \
                    (reap["pid"], reap["startticks"], reap["raw_wait_status"]) or \
               child["wait"] != {
                    "exited": True, "signaled": False, "exit_code": 0,
                    "signal": None, "core_dumped": False} or \
               (report["cleanup_start_ns"], report["cleanup_deadline_ns"],
                report["cleanup_finished_ns"], report["cleanup_complete"],
                report["group_identity_pinned"], report["owned_records_omitted"]) != \
               (final["cleanup_start_ns"], final["cleanup_deadline_ns"],
                final["cleanup_finished_ns"], final["cleanup_complete"],
                final["group_pinned"], final["owned_records_omitted"]):
                raise ValueError("report child cleanup")
            reaps = [event for event in events if event["event"] == "actual-reap"]
            if len(reaps) != 1 or (reaps[0]["pid"], reaps[0]["raw_wait_status"]) != \
                    (child["pid"], child["raw_wait_status"]):
                raise ValueError("report event reap")
            words = report["setup_words"]
            if report["setup_ready_record"] is not True or \
               report["setup_error_record"] is not False or \
               report["setup_validated"] is not True or words[:5] != \
                    [827081537, 1, 1, 1, 0] or \
               words[5:9] != [child["pid"], collector["pid"],
                              child["pid"], child["pid"]] or \
               words[9:15] != [0, 0, 0, 0, 1, 0] or words[15] != 0o22 or \
               words[18:21] != [report["devnull_identity"][key]
                                 for key in ("mode", "device", "inode")] or \
               words[27:30] != [report["post_exec_backing"][key]
                                 for key in ("device", "inode")] + [
                                     report["executable"]["seals"]] or \
               words[30:38] != [0, 0, 1, 1, 0, 0, 0, 1] or any(words[38:]):
                raise ValueError("report setup semantics")
            if report["post_exec_backing_observed"] is not True or not (
                    report["preparation_start_ns"] <= report["process_start_ns"] <=
                    report["post_exec_observed_monotonic_ns"] <=
                    report["completion_observed_ns"] <= report["cleanup_start_ns"] <=
                    report["cleanup_finished_ns"] <= events[-1]["monotonic_ns"]):
                raise ValueError("report lifecycle time")
            executable = report["executable"]
            if executable["opened"] is not True or executable["stable"] is not True or \
               executable["verified"] is not True or \
               executable["source_before"] != executable["source_after"] or \
               executable["sealed_backing"] != report["post_exec_backing"] or \
               executable["artifact"] is None or \
               executable["artifact"]["sha256"] != FIXTURE_SHA or \
               executable["artifact"]["seen_bytes"] != 27448 or \
               executable["artifact"]["stored_bytes"] != 27448 or \
               executable["artifact"] != report["artifacts"][5] or \
               not stat.S_ISCHR(report["devnull_identity"]["mode"]):
                raise ValueError("report executable semantics")
        elif report.get("linux_child") is not None or any(report.get(key) != 0 for key in
                ("cleanup_start_ns", "cleanup_deadline_ns", "cleanup_finished_ns")):
            raise ValueError("report prefork cleanup")
        else:
            if any(report[key] is not False for key in ("setup_ready_record",
                    "setup_error_record", "setup_validated",
                    "post_exec_backing_observed")) or any(report["setup_words"]) or \
               report["post_exec_observed_monotonic_ns"] != 0 or \
               report["post_exec_backing"] is not None:
                raise ValueError("report prefork setup")
        if report["preparation_deadline_ns"] != report["preparation_start_ns"] + \
                120000000000 or (post and report["process_deadline_ns"] !=
                report["process_start_ns"] + 10000000000):
            raise ValueError("report deadlines")
        failure_ns = report["first_failure_monotonic_ns"]
        if (failure == "none") is not (failure_ns == 0):
            raise ValueError("report failure time")
        if failure != "none":
            finish_ns = events[-1]["monotonic_ns"] if events else None
            if failure_ns <= report["preparation_start_ns"] or \
               (selector == 3 and (failure_ns <= finish_ns or
                                   failure_ns <= report["cleanup_finished_ns"])) or \
               (selector in (2, 6) and failure_ns >= finish_ns):
                raise ValueError("report failure time")
    retained_root = root / "retained-inputs"
    if sha(read(retained_root / "request.bin")) != REQUEST_SHA or \
       sha(read(retained_root / "selected-inputs.json")) != SELECTED_SHA or \
       sha(read(retained_root / "fixture")) != FIXTURE_SHA:
        raise ValueError("retained input")
    if selector == 1:
        if (collection / "request.bin").exists() or (collection / "events.jsonl").exists():
            raise ValueError("prefork artifact absence")
        return True
    request = read(collection / "request.bin")
    if selector in (2, 6):
        if request != PREFIX or sha(request) != PREFIX_SHA:
            raise ValueError("request prefix")
    elif sha(request) != REQUEST_SHA:
        raise ValueError("request artifact")
    if selector in (5, 6):
        sync = [packet for packet in packets if packet.get("site") == "report-sync"]
        if len(sync) != 2 or sync[-1].get("return") != -1 or \
           sync[-1].get("errno") != 5:
            raise ValueError("report sync failure")
    return True
