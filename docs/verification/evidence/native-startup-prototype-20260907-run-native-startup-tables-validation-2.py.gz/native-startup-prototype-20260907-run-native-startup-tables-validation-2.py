import subprocess
subprocess.run(['python3','-B','/work/check-native-startup-tables-modules-2.py'],check=True)
subprocess.run(['python3','-B','/work/run-native-startup-tables-guest.py','/work/native-startup-tables-prototype-20260907-2','/work/native-startup-tables-guest-20260907-2'],check=True)
