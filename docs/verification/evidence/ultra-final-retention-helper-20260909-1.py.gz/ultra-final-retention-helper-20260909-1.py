#!/usr/bin/env python3
"""Retain completed Ultra evidence; never builds, boots, publishes or cleans captures.

Pinned native container invocation:
  python3 -B /work/retain-native-ultra-final.py FRESH_ATTEMPT \
      /work/native-ultra-signal-abi-guest-20260909-N \
      /work/native-ultra-futex-guest-20260909-N
Root must finish and freeze those captures and the current plan before running.
The resulting checkpoint is retention success, with drafting release pending.
"""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
assert len(sys.argv) == 4 and re.fullmatch(r'[1-9][0-9]*', sys.argv[1])
repo, work = Path('/workspace'), Path('/work')
attempt = sys.argv[1]
signal_guest, futex_guest = map(Path, sys.argv[2:])
for path, prefix in [(signal_guest, 'native-ultra-signal-abi-guest-20260909-'),
                     (futex_guest, 'native-ultra-futex-guest-20260909-')]:
    assert path.parent == work and re.fullmatch(re.escape(prefix) + r'[1-9][0-9]*', path.name)
out = work / ('native-ultra-final-retained-20260909-' + attempt)
out.mkdir()
manifest = out / 'ultra-final-checkpoint-20260909.json'
compiled = work / 'native-ultra-module-20260909-1'
images = work / 'mckernel-native-ultra-images-20260909-3'
image = images / 'native-rust/kernel/mckernel.img'
launcher = work / 'native-application-launcher-20260908-2/rust/executer/user/mcexec'
core = work / 'native-application-core-build-20260908-1/native-application-core'
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], archive_bundles=[], captures=[], references=[], referenced_captures=[],
    native_compiler_bindings=[], guest_production_bindings=[], historical_restoration=[],
    helper_and_plan_bindings=[], runtime_bindings=[], commands=[],
    scope='Retained current Ultra module1/image3, selected source/compiler bindings, four original core regressions, both original control regressions and explicitly accepted benign signal/futex guests. Broader application/vector/runtime-injection tests remain unverified; drafting release requires a separate root review and verified GitHub checkpoint.',
    application_handoff_ready=False, drafting_handoff_release='PENDING_ROOT_RELEASE',
    runtime_execution_authorized=False, production_gate_credit=False,
    application_catalog_runtime_verified=False, actual_vector_runtime_verified=False,
    transport_runtime_injection_verified=False, external_signal_restart_status='BLOCKED',
    source_checkout_scope='Complete actual sparse build trees and original failed attempts are retained. Historical evidence omitted before compilation is separately mapped to exact committed Git blobs; no additional capture exclusions are introduced here.')


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())


def same(left, right):
    a, b = identity(left), identity(right)
    assert (a['size'], a['sha256']) == (b['size'], b['sha256']), (a, b)
    return dict(current=a, retained=b)


def verify(row, path=None):
    actual = identity(path if path is not None else Path(row['path']))
    assert (actual['size'], actual['sha256']) == (row['size'], row['sha256']), (row, actual)
    return actual


def save():
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    (out / 'record.json').write_bytes(manifest.read_bytes())


def check_tree(source, path):
    """Read every archived byte and check the exact live tree, modes and links."""
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen, (source, relative)
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), (source, relative)
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert stat.S_ISLNK(info.st_mode) and os.readlink(current) == member.linkname
            elif member.isfifo():
                assert stat.S_ISFIFO(info.st_mode)
            elif member.ischr() or member.isblk():
                assert (member.ischr() and stat.S_ISCHR(info.st_mode)) or (member.isblk() and stat.S_ISBLK(info.st_mode))
                assert (member.devmajor, member.devminor) == (os.major(info.st_rdev), os.minor(info.st_rdev))
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), (source, relative)
                digest, size = hashlib.sha256(), 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), (source, relative)
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected, (source, sorted(expected - seen)[:10], sorted(seen - expected)[:10])
    return len(seen)


def artifact(source, name, tree=False):
    """Create one verified gzip, or <95-MiB ordered pieces of that exact gzip."""
    staging = out / 'archive-staging'
    staging.mkdir(exist_ok=True)
    path = staging / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    members = check_tree(source, path) if tree else None
    if not tree:
        digest, size = hashlib.sha256(), 0
        with gzip.open(path, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                size += len(chunk); digest.update(chunk)
        original = identity(source)
        assert (size, digest.hexdigest()) == (original['size'], original['sha256'])
    full = identity(path)
    bundle = dict(source=str(source), archive_name=name, archive_size=full['size'],
                  archive_sha256=full['sha256'], exact_tree_members=members,
                  excludes=[], parts=[], complete_actual_capture=True)
    if full['size'] < 95 * 1024**2:
        published = out / name
        path.rename(published)
        chunks = [published]
    else:
        chunks = []
        # Each part is below the repository limit. Concatenate in this exact
        # order before gzip/tar extraction; parts are not independent gzip files.
        with path.open('rb') as stream:
            number = 1
            while True:
                chunk = stream.read(90 * 1024**2)
                if not chunk:
                    break
                published = out / (name + '.part' + str(number).zfill(3))
                with published.open('xb') as part:
                    part.write(chunk)
                chunks.append(published)
                number += 1
        digest, size = hashlib.sha256(), 0
        for part in chunks:
            with part.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1 << 20), b''):
                    digest.update(chunk); size += len(chunk)
        assert (size, digest.hexdigest()) == (full['size'], full['sha256'])
        bundle.update(restore='Concatenate parts in listed order; verify archive_size/archive_sha256, then extract the resulting gzip tar.',
                      local_full_archive=str(path), local_full_archive_publication=False)
    for part in chunks:
        row = identity(part)
        assert row['size'] < 95 * 1024**2
        row.update(path='docs/verification/evidence/' + part.name, source=str(source))
        record['artifacts'].append(row)
        bundle['parts'].append(row['path'])
    record['archive_bundles'].append(bundle)
    print('RETAINED', name, full['size'], 'parts', len(chunks), flush=True)
    save()
    return bundle


def read_record(directory, expected):
    state = json.loads((directory / 'record.json').read_text())
    assert state['status'] == expected, (str(directory), state.get('status'), expected)
    return state


def check_capture_identities(directory, state):
    """Bind saved local sources/outputs. Historical external paths stay historical."""
    checked, external = [], []
    for key in ('inputs', 'outputs', 'compiler_inputs', 'production_inputs', 'source_overlays'):
        for row in state.get(key, []):
            if not isinstance(row, dict) or not {'path', 'size', 'sha256'} <= row.keys():
                continue
            path = Path(row['path'])
            if path.is_relative_to(directory):
                verify(row)
                checked.append(row)
            else:
                # Failed attempts may name a mutable working-tree helper/source.
                # Their full original record and captured tree are preserved;
                # those historical identities must not be mislabeled current.
                external.append(dict(field=key, identity=row,
                    binding='historical external identity retained in original record; current executable/source bindings checked separately'))
    for selection in state.get('images', []):
        for row in selection.get('outputs', []):
            verify(row)
            checked.append(row)
    return dict(local_identities_verified=len(checked), historical_external_identities=external)


def historical_map(directory, state):
    omitted = state.get('historical_evidence_omitted')
    if not omitted:
        return
    path = directory / omitted['restoration_map']
    mapping = json.loads(path.read_text())
    assert len(mapping) == omitted['count'] and sum(row['size'] for row in mapping) == omitted['bytes']
    commits = {row['source_commit'] for row in mapping}
    trees = {}
    for commit in commits:
        raw = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-r', '-l', '-z', commit,
                                       '--', 'docs/verification/evidence'])
        entries = {}
        for item in raw.split(b'\0'):
            if not item:
                continue
            metadata, relative = item.split(b'\t', 1)
            mode, kind, blob, size = metadata.decode().split()
            assert kind == 'blob'
            entries[relative.decode()] = dict(mode=mode, git_blob=blob, size=int(size))
        trees[commit] = entries
    assert len({row['path'] for row in mapping}) == len(mapping)
    for row in mapping:
        assert trees[row['source_commit']][row['path']] == {key: row[key] for key in ('mode', 'git_blob', 'size')}
        assert not (directory / 'source' / row['path']).exists(), row['path']
    record['historical_restoration'].append(dict(capture=str(directory), map=identity(path),
        omitted_files=len(mapping), omitted_bytes=omitted['bytes'], commits=sorted(commits),
        verification='Every mode/blob/size/path matches git ls-tree of its exact source commit.',
        restore='Before historical evidence replay, obtain the retained repository Git objects and restore each mapped blob at source/PATH with MODE. Build-source archives are complete as actually compiled; sparse historical omissions are not new exclusions.',
        git_alternates_note='Shared checkout .git alternates can reference /workspace/.git/objects. Preserve the repository object database or reconnect these alternates when restoring; the archive is not claimed to be a standalone full-history Git clone.'))


def bind(current, saved, kind='identical current source'):
    result = same(current, saved)
    return dict(path=str(current.relative_to(repo)), size=result['current']['size'],
                sha256=result['current']['sha256'], compiler_capture=str(saved), binding=kind)


def validate_pair(directory, state, application=False):
    assert state['qemu_exit_code'] == 0 and state['status'] == 'PASS'
    args = state['qemu_args']
    assert Path(args[args.index('-kernel') + 1]) == compiled / 'bzImage'
    assert args[args.index('-smp')+1] == '4,sockets=2,cores=2,threads=1'
    assert args[args.index('-m')+1] == '8192'
    assert state['cpuset'] == [2,3,4,5] and state['guest_cpus'] == 1
    rows = []
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        rows.append(same(compiled / name, directory / 'root/modules' / name))
    rows.append(same(image, directory / 'root/images/mckernel.img'))
    for path in [compiled / 'bzImage', image, *(compiled / name for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko'))]:
        assert identity(path) in state['inputs'], (directory, path)
    if application:
        rows += [same(launcher, directory/'root/bin/mcexec'), same(core, directory/'root/bin/native-application-core')]
        assert state['mckernel_application_executed']
        assert state['native_application']['applications'] == 8
        assert state['native_application']['no_process_nodes_after_each']
        assert state['core_application']['exit_code'] == 37
        assert state['file_pager_lifetime']['all_created_handles_released']
        assert state['boot_probe_adaptation']['kernel_command_line'] == 'hidos allow_oversubscribe'
    record['runtime_bindings'].append(dict(capture=str(directory), actual_pair=rows,
        inherited_prose_note='Original control adaptation prose may name historical signal module1/image2. Verified QEMU arguments and exact module/image bytes above prove actual Ultra module1/image3; original records are preserved.'))


try:
    shutil.copyfile(__file__, out/'helper.py')
    reference = work/'retain-native-application-signals.py'
    shutil.copyfile(reference, out/'retention-reference.py')
    record['retention_reference'] = identity(out/'retention-reference.py')
    assert shutil.disk_usage(work).free > 3 * 1024**3

    # WIP archives already contain these complete attempts. Verify their bytes
    # and exact trees in place, then reference them instead of recompressing.
    prior_names = set()
    for number in (1, 2):
        path = repo/f'docs/verification/ultra-wip-checkpoint-20260909-{number}.json'
        prior = json.loads(path.read_text())
        assert prior['status'] == 'PASS'
        ref = identity(path); ref['path'] = str(path.relative_to(repo))
        record['references'].append(ref)
        for row in prior['artifacts']:
            verify(row, repo/row['path'])
        for row in prior['captures']:
            directory = Path(row['path'])
            state = read_record(directory, row['status'])
            verify(row['record'], directory/'record.json')
            matches = [item for item in prior['artifacts'] if Path(item['path']).name == directory.name+'.tar.gz']
            assert len(matches) == 1, directory
            members = check_tree(directory, repo/matches[0]['path'])
            prior_names.add(directory.name)
            record['referenced_captures'].append(dict(path=str(directory), original_status=state['status'],
                record=identity(directory/'record.json'), reference_manifest=ref['path'],
                artifact=matches[0], exact_tree_members=members, newly_archived=False))
    assert len(prior_names) == 11

    module_state = read_record(compiled, 'PASS')
    for row in module_state['outputs']:
        verify(row)
    for row in module_state['overlay']:
        relative = Path(row['path']).relative_to(work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel')
        verify(row, compiled/'staged-source'/relative)
    dependencies = '\n'.join(path.read_text() for path in (compiled/'module-build').rglob('*.cmd'))
    replay_root = out/'format-replay'
    replay_root.mkdir()
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs', '.S'):
            continue
        relative = saved.relative_to(compiled/'staged-source')
        current = repo/'host-kernel/native-rust'/relative
        assert '/work/native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel/'+str(relative) in dependencies, str(relative)
        if current.read_bytes() == saved.read_bytes():
            record['native_compiler_bindings'].append(bind(current, saved, 'identical compiler source with actual .cmd dependency'))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'), str(relative)
            replay = replay_root/relative
            replay.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(current, replay.with_suffix('.original.rs'))
            shutil.copyfile(current, replay)
            command = ['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result = subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
            replay.with_suffix('.log').write_bytes(result.stdout)
            record['commands'].append(dict(command=command,exit_code=result.returncode))
            assert result.returncode == 0 and replay.read_bytes() == saved.read_bytes(), str(current)
            row = identity(current); row['path'] = str(current.relative_to(repo))
            row.update(binding='exact pinned rustfmt replay with actual .cmd dependency',compiler_capture=str(saved),
                       formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    assert len(record['native_compiler_bindings']) == 57
    formatter = subprocess.check_output(['rustfmt','--version'],text=True)
    (replay_root/'rustfmt-version.txt').write_text(formatter)
    record['formatter'] = formatter

    image_state = read_record(images, 'PASS')
    assert len(image_state['production_inputs']) == 44
    for row in image_state['production_inputs']:
        verify(row)
        relative = Path(row['path']).relative_to(images/'source')
        record['guest_production_bindings'].append(bind(repo/relative,Path(row['path']),
            'identical current production input; detailed selected-profile compiler/dependency/ELF audits retained in image record'))
    assert len({row['path'] for row in record['guest_production_bindings']}) == 44
    for row in image_state['ultra_live_source_bindings']:
        verify(row['compiled']); verify(row['live'])
    assert {item['kind'] for item in image_state['images']} == {'fallback','legacy-rust','native-rust','native-sysfs-verify'}
    for key in ('native_fault_hooks_selected','native_futex_checked_load_selected','native_clone_tid_selection_compiled',
                'native_xstate_checked_restore_selected','native_clone3_guest_handler_compiled'):
        assert image_state[key]
    assert len(image_state['ultra_selection_checks']) == 4
    record['selected_pair'] = dict(module_record=identity(compiled/'record.json'),image_record=identity(images/'record.json'),
        linux_kernel=identity(compiled/'bzImage'),mckernel_image=identity(image),
        modules=[identity(compiled/name) for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko')],
        launcher=identity(launcher),core=identity(core),host_compiler_bindings=57,guest_production_inputs=44,
        image_profiles=[item['kind'] for item in image_state['images']],actual_fault_injection_claimed=False)

    captures = [(work/f'mckernel-native-ultra-images-20260909-{n}', status) for n,status in [(1,'FAIL'),(2,'FAIL'),(3,'PASS')]]
    captures += [(work/f'ultra-futex-clone-protocol-20260909-{suffix}', status)
                 for suffix,status in [('native-3','FAIL'),('native-4','PASS'),('compat-2','PASS')]]
    metadata = work/'ultra-test-plan-protocol-20260909-2'
    metadata_state = read_record(metadata,'PASS')
    assert metadata_state['application_tests_passed'] == 0 and not metadata_state['runtime_authorized']
    captures.append((metadata,'PASS'))
    baselines = [(work/f'native-ultra-baseline-{case}-guest-20260909-1',case)
                 for case in ('memory','files','threads','signals')]
    controls = [(work/'native-ultra-control-regression-20260909-x86_64-1','x86_64'),
                (work/'native-ultra-control-compat-20260909-i386-1','i386')]
    captures += [(directory,'PASS') for directory,_ in baselines+controls]
    for final in (signal_guest, futex_guest):
        prefix = final.name.rsplit('-',1)[0]+'-'
        last = int(final.name.rsplit('-',1)[1])
        # Every preceding attempt must be accounted for; all original failures
        # are archived in full, even when the accepted invocation is later.
        for number in range(1,last+1):
            directory = work/(prefix+str(number))
            state = json.loads((directory/'record.json').read_text())
            assert state['status'] in ('PASS','FAIL'), (directory,state.get('status'))
            assert directory != final or state['status'] == 'PASS'
            captures.append((directory,state['status']))
    # Retain the independent futex build(s) and batch orchestration, including
    # earlier failed builds. Existing WIP captures are referenced, not repeated.
    for pattern in ('native-ultra-futex-build-20260909-*','native-ultra-regression-batch-20260909-*'):
        for directory in sorted(work.glob(pattern)):
            if not directory.is_dir():
                continue
            state = json.loads((directory/'record.json').read_text())
            assert state['status'] in ('PASS','FAIL'), (directory,state.get('status'))
            captures.append((directory,state['status']))
    assert len({str(directory) for directory,_ in captures}) == len(captures)
    assert not {directory.name for directory,_ in captures} & prior_names

    record['baseline_replays'] = []
    for directory,case in baselines:
        state = read_record(directory,'PASS')
        validate_pair(directory,state,True)
        assert state['core_application']['case'] == case
        assert state['core_application']['stdout'] == 'NATIVE_CORE PASS '+case+'\n'
        if case == 'signals':
            assert state['native_signal_application']['actual_sigreturn_results'] == [0,0]
        if case == 'threads':
            assert state['native_clone3_application']['host_clone3_delegations'] == 0
            assert state['native_clone3_application']['pthread_barrier_mutex_tls_and_join_passed']
        record['baseline_replays'].append(dict(path=str(directory),case=case,hello_applications=8,core=state['core_application']))
    record['control_replays'] = []
    for directory,architecture in controls:
        state = read_record(directory,'PASS')
        validate_pair(directory,state)
        assert state['mcctrl_process']['checks'] == 153
        assert state['mcctrl_process']['physical_queue_cleanup_exchanges'] == 73
        assert not state['applications_tested']
        if architecture == 'x86_64':
            assert state['worker_reaper']['worker_threads'] == 72
            assert state['worker_reaper']['inherited_tgids'] == 4
            assert state['worker_reaper']['distinct_worker_handles'] == 72
            assert state['native_procfs']['physical_phase_totals'] == [464,465]
        record['control_replays'].append(dict(path=str(directory),architecture=architecture,
            process=state['mcctrl_process'],worker_reaper=state.get('worker_reaper'),
            native_procfs=state.get('native_procfs'),application_execution=False))

    signal_state = read_record(signal_guest,'PASS')
    validate_pair(signal_guest,signal_state,True)
    assert signal_state['signal_guest_cases_passed'] == ['mask-context','fp-return']
    assert signal_state['signal_linux_cases_passed'] == ['mask-context','fp-return','fp-restart']
    assert signal_state['signal_guest_restart']['status'] == 'BLOCKED'
    assert not signal_state['signal_guest_restart']['guest_executed']
    assert len(signal_state['signal_abi_cases']) == 5
    assert all(row['exit_code'] == 37 and row['raw_wait_status'] == (37<<8) for row in signal_state['signal_abi_cases'])
    record['ordinary_signal_abi'] = dict(path=str(signal_guest),cases=signal_state['signal_abi_cases'],
                                       external_restart=signal_state['signal_guest_restart'])
    futex_state = read_record(futex_guest,'PASS')
    validate_pair(futex_guest,futex_state,True)
    assert futex_state['native_ultra_futex_application_executed']
    result = futex_state['native_ultra_futex']
    assert result['same_guest_linux_reference'] and result['normal_retirement'] and result['no_process_nodes']
    assert result['direct_child_settid_verified'] and not result['fork_cow_verified']
    assert not result['all_host_returns_audited']
    assert len(result['sides']) == 2 and all(len(side['cases']) == 16 for side in result['sides'])
    assert all(value == 0 for value in result['pager_references_remaining'].values())
    record['ordinary_futex_abi'] = dict(path=str(futex_guest),result=result)

    # Retain the current planning surface and all new source/build/runtime
    # helpers exactly. This is source preservation, not a plan-runtime PASS.
    snapshot = out/'current-plans-and-helpers'
    snapshot.mkdir()
    paths = [repo/'AGENTS.md', repo/'goal.txt', repo/'kernel.log']
    paths += sorted((repo/'docs/verification').glob('ultra-*.md'))
    paths += [repo/'docs/verification/ultra-host-cpu-features-20260909.json']
    paths += [p for p in sorted((repo/'scripts/application-tests').rglob('*')) if p.is_file()]
    assert (repo/'scripts/application-tests/handoff-start.md').is_file()
    paths += [repo/'scripts/tests'/name for name in ['verify-native-signal-abi.py','verify-native-fault.py','run_ultra_futex_clone.py']]
    fixture_patterns = ('native-signal-*','native-xstate.rs','native-fault.rs','native-ultra-futex.c',
                        'ultra-futex-*','ultra-clone-*','native-application-transport-failure.rs')
    for pattern in fixture_patterns:
        paths += sorted((repo/'scripts/tests/fixtures').glob(pattern))
    work_names = ['build-native-ultra.py','build-mckernel-native-ultra-images.py',
        'build-mckernel-native-ultra-images.README.md','run-native-ultra-baseline.py',
        'run-native-ultra-control-regression.py','run-native-ultra-control-compat.py',
        'run-native-ultra-regressions.py','run-native-ultra-signal-abi.py',
        'run-native-ultra-signal-abi-baseline-original.py','prepare-native-ultra-signal-abi.py',
        'build-native-ultra-futex.py','run-native-ultra-futex.py','native-ultra-futex.README.md',
        'prepare-native-ultra-transport-fault.py','build-native-ultra-transport-fault.py',
        'verify-ultra-test-plan.py']
    paths += [work/name for name in work_names]
    for original in sorted(set(paths)):
        assert original.is_file(), original
        prefix = 'workspace' if original.is_relative_to(repo) else 'work'
        relative = original.relative_to(repo if prefix == 'workspace' else work)
        saved = snapshot/prefix/relative
        saved.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,saved)
        row = same(original,saved)
        record['helper_and_plan_bindings'].append(row)
    catalog = json.loads((repo/'scripts/application-tests/cases.json').read_text())
    queue = json.loads((repo/'scripts/application-tests/draft-queue.json').read_text())
    assert len(catalog['cases']) == catalog['logical_case_count'] == queue['logical_case_count']
    assert len(queue['packets']) == queue['packet_count']
    assert queue['mode'] == 'draft-only' and queue['execution_enabled'] is False
    assert metadata_state['logical_cases'] == catalog['logical_case_count']
    metadata_bindings = []
    for current in sorted((repo/'scripts/application-tests').rglob('*')):
        if current.is_file():
            saved = metadata/'application-tests'/current.relative_to(repo/'scripts/application-tests')
            metadata_bindings.append(same(current,saved))
    contexts = []
    for number in ('001','007'):
        path = metadata/('packet-'+number+'-context.json')
        context = json.loads(path.read_text())
        assert context['schema_version'] == 1
        assert context['catalog_sha256'] == identity(repo/'scripts/application-tests/cases.json')['sha256']
        assert context['packet_sha256'] == identity(repo/('scripts/application-tests/packets/packet-'+number+'.json'))['sha256']
        assert context['queue_cursor']['queue_sha256'] == identity(repo/'scripts/application-tests/draft-queue.json')['sha256']
        contexts.append(identity(path))
    record['application_plan'] = dict(catalog=identity(repo/'scripts/application-tests/cases.json'),
        queue=identity(repo/'scripts/application-tests/draft-queue.json'),logical_cases=catalog['logical_case_count'],
        draft_packets=queue['packet_count'],runtime_cases_accepted=0,vector_runtime_cases_accepted=0,
        mode='draft-only',release='PENDING_ROOT_RELEASE',plan_validation_record=identity(metadata/'record.json'),
        validated_source_bindings=metadata_bindings,bounded_contexts=contexts,
        structural_validation_only=True,context_emission_authorizes_drafting=False)

    for directory,expected in captures:
        state = read_record(directory,expected)
        verification = check_capture_identities(directory,state)
        historical_map(directory,state)
        bundle = artifact(directory,directory.name+'.tar.gz',True)
        record['captures'].append(dict(path=str(directory),original_status=expected,
            record=identity(directory/'record.json'),archive_name=bundle['archive_name'],
            identity_verification=verification,complete_actual_capture=True))
    artifact(replay_root,'ultra-final-format-replay-20260909-'+attempt+'.tar.gz',True)
    artifact(snapshot,'ultra-final-plans-and-helpers-20260909-'+attempt+'.tar.gz',True)
    artifact(out/'retention-reference.py','ultra-final-retention-reference-20260909-'+attempt+'.py.gz')
    artifact(out/'helper.py','ultra-final-retention-helper-20260909-'+attempt+'.py.gz')
    # Detect concurrent plan/source edits across retention, without modifying
    # any evidence or repository file on a mismatch.
    for row in record['helper_and_plan_bindings']:
        verify(row['current']); verify(row['retained'])
    for row in record['native_compiler_bindings']+record['guest_production_bindings']:
        verify(row,repo/row['path'])
    record.update(status='PASS',finished_utc=datetime.now(timezone.utc).isoformat(),
        new_complete_captures=len(record['captures']),referenced_complete_captures=len(record['referenced_captures']),
        original_failures_new=sum(row['original_status']=='FAIL' for row in record['captures']),
        original_failures_referenced=sum(row['original_status']=='FAIL' for row in record['referenced_captures']),
        actual_hello_applications=48,original_core_replays=6,original_control_replays=2,
        new_signal_guest_cases=2,new_futex_logical_cases=16,
        new_valid_shared_vm_child_tid_case=1,
        artifact_bytes=sum(row['size'] for row in record['artifacts']),
        verification_note='PASS means complete checked retention and the explicitly listed runtime evidence. No full-OS, catalog/vector, external restart, injected transport fault or drafting-release acceptance is asserted.')
except BaseException as error:
    record.update(status='FAIL',error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'],manifest,flush=True)
