from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-irq-work-policy-20260907-' + sys.argv[1])
out.mkdir()
inputs = ['kernel/CMakeLists.txt', 'kernel/rust/smp_ikc.rs', 'kernel/rust/llist.rs',
          'scripts/tests/fixtures/mckernel_irq_work_compile.rs', 'scripts/tests/test_mckernel_irq_work.py']
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(), inputs=[], production_gate_credit=False)
for relative in inputs:
    data = (repo / relative).read_bytes()
    path = out / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    record['inputs'].append(dict(path=relative, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
shutil.copyfile(__file__, out / 'run-helper.py')
commands = [['git', '-C', str(repo), 'diff', '--check'],
            ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false', str(out / 'source/kernel/rust/smp_ikc.rs'), str(out / 'source/scripts/tests/fixtures/mckernel_irq_work_compile.rs')],
            ['python3', '-B', '-m', 'unittest', 'discover', '-s', str(out / 'source/scripts/tests'), '-p', 'test_mckernel_irq_work.py', '-v', '-f']]
record['commands'] = commands
record['compiler'] = subprocess.check_output(['rustc', '--version', '--verbose'], text=True)
try:
    with (out / 'validation.log').open('wb') as log:
        for command in commands:
            print('RUN', command, flush=True)
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print((out / 'validation.log').read_text(), flush=True)
