"""Pinned compatibility compiler; actual McKernel image selects native Linux ABI."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, shutil, struct, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/mckernel-native-signals-images-20260909-' + sys.argv[1])
out.mkdir()
source = out / 'source'
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
ihk_head = subprocess.check_output(['git', '-C', str(repo / 'ihk'), 'rev-parse', 'HEAD'], universal_newlines=True).strip()
assert shutil.disk_usage('/work').free > 3 * 1024**3
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=head, ihk_source=ihk_head,
              status='running', production_gate_credit=False, mckernel_boot_proven=False, results=[])
environment = dict(os.environ, PATH='/opt/mckernel/cargo/bin:' + os.environ['PATH'], RUSTC='/opt/mckernel/cargo/bin/rustc',
                   PYTHONDONTWRITEBYTECODE='1', MCKERNEL_RUST_EQUIV_KEEP_TMP='1')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
def run(label, command, expected=None):
    record['phase'] = label
    (out / 'phase').write_text(label + '\n')
    save()
    print('RUN', label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=str(source) if source.exists() else str(repo), env=environment, stdout=log, stderr=subprocess.STDOUT)
    row = dict(label=label, command=command, exit_code=result.returncode)
    record['results'].append(row)
    save()
    if expected is None:
        assert result.returncode == 0, (label, result.returncode)
    else:
        diagnostic = ' '.join((out / (label + '.log')).read_text().split())
        assert result.returncode != 0 and ' '.join(expected.split()) in diagnostic, label
try:
    shutil.copyfile(__file__, out / 'build-helper.py')
    run('clone-source', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo), str(source)])
    # Compile-only checkout: preserve exact restoration references before
    # avoiding redundant historical evidence. No compiler input is excluded.
    omitted = []
    listing = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-rlz', '--full-tree', head, 'docs/verification/evidence'])
    for entry in listing.split(b'\0'):
        if not entry: continue
        meta, relative = entry.split(b'\t', 1)
        mode, kind, blob, size = meta.decode().split()
        assert kind == 'blob'
        omitted.append(dict(path=os.fsdecode(relative), mode=mode, git_blob=blob, size=int(size), source_commit=head))
    record['historical_evidence_omitted'] = dict(count=len(omitted), bytes=sum(row['size'] for row in omitted), restoration_map='historical-evidence-restoration.json', scope='Compile-only source copy; exact committed blobs remain in the source Git object database')
    (out / 'historical-evidence-restoration.json').write_text(json.dumps(omitted, indent=2, sort_keys=True) + '\n')
    save()
    run('sparse-source', ['git', '-C', str(source), 'sparse-checkout', 'set', '--no-cone', '/*', '!/docs/verification/evidence/'])
    run('checkout-source', ['git', '-C', str(source), 'checkout', '--detach', head])
    run('clone-ihk', ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / 'ihk'), str(source / 'ihk')])
    run('checkout-ihk', ['git', '-C', str(source / 'ihk'), 'checkout', '--detach', ihk_head])
    submodules = subprocess.check_output(['git', '-C', str(repo), 'submodule', 'status', '--recursive'], universal_newlines=True)
    record['recursive_submodules'] = submodules.splitlines()
    for index, line in enumerate(submodules.splitlines()):
        assert line.startswith(' '), line
        revision, relative = line[1:].split()[:2]
        if relative == 'ihk': continue
        target = source / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        run('clone-submodule-' + str(index), ['git', 'clone', '--shared', '--no-hardlinks', '--no-checkout', str(repo / relative), str(target)])
        run('checkout-submodule-' + str(index), ['git', '-C', str(target), 'checkout', '--detach', revision])
    record['compiler'] = subprocess.check_output(['/opt/mckernel/cargo/bin/rustc', '--version', '--verbose'], universal_newlines=True)
    record['source_status'] = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], universal_newlines=True)
    assert record['source_status'] == ''
    changed = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', 'HEAD', '-z']).split(b'\0')
    changed += subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    record['source_overlays'] = []
    for raw in sorted(set(changed)):
        if not raw: continue
        relative = os.fsdecode(raw)
        assert not relative.startswith('docs/verification/evidence/'), 'Checkpoint evidence before building: ' + relative
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / relative, path)
        record['source_overlays'].append(identity(path))
    record['production_inputs'] = [identity(source / p) for p in ['kernel/rust/native_signal.rs', 'arch/x86_64/kernel/syscall.c', 'arch/x86_64/kernel/include/signal.h', 'kernel/rust/clone3.rs', 'kernel/syscall.c', 'arch/x86_64/kernel/include/syscall_list.h', 'kernel/rust/x86_cpu_helpers.rs', 'host-kernel/native-rust/zero_pages.rs', 'lib/page_alloc.c', 'lib/include/ihk/page_alloc.h', 'kernel/rust/syscall_policy.rs', 'kernel/rust/page_alloc.rs', 'kernel/rust/x86_memory_helpers.rs', 'kernel/CMakeLists.txt', 'kernel/rust/smp_ikc.rs', 'kernel/rust/llist.rs', 'kernel/rust/lib.rs', 'kernel/rust/init.rs', 'kernel/rust/sysfs.rs', 'kernel/rust/abi.rs', 'kernel/rust/object_helpers.rs', 'kernel/rust/host_helpers.rs', 'kernel/rust/process_helpers.rs', 'kernel/rust/lock_helpers.rs', 'kernel/rust/procfs.rs', 'kernel/rust/cls.rs', 'kernel/procfs.c', 'kernel/cls.c', 'kernel/object_helpers.c', 'kernel/include/syscall.h', 'kernel/include/object_helpers.h', 'kernel/init.c', 'scripts/tests/fixtures/mckernel_guest_sysfs.rs', 'scripts/tests/fixtures/native-guest-sysfs.c', 'lib/include/list.h', 'arch/x86_64/kernel/include/registers.h', 'arch/x86_64/kernel/include/ihk/atomic.h']]
    run('diff-check', ['git', 'diff', '--check'])
    run('format-check', ['rustfmt', '--edition', '2021', '--check', '--config', 'skip_children=true,reorder_modules=false', 'kernel/rust/smp_ikc.rs', 'scripts/tests/fixtures/mckernel_irq_work_compile.rs', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs', 'scripts/tests/fixtures/mckernel_guest_sysfs.rs'])
    for enabled in [False, True]:
        command = ['cc', '-E', '-dM', '-x', 'c', '-I', str(source / 'lib/include'), '-include', 'list.h']
        if enabled: command.append('-DMCKERNEL_RUST_LIST_HELPERS')
        output = subprocess.check_output(command + ['/dev/null'])
        (out / ('list-macros-rust.txt' if enabled else 'list-macros-fallback.txt')).write_bytes(output)
        for macro in [b'#define list_for_each_entry(', b'#define list_for_each_entry_safe(']:
            assert (macro in output) == (not enabled)
    run('producer-check', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_mckernel_irq_work.py', '-v', '-f'])
    # The old broad harness requires three Rust sources absent from the exact
    # pinned IHK. Preserve its failed attempt 2; do not invent that old source.
    # The preceding focused test now runs the complete, unchanged pinned C
    # producer and the retained Rust producer with the same fixture and checks
    # identical observable results, plus the native extension independently.
    missing = [p for p in ['ihk/linux/core/rust/core_helpers.rs',
                          'ihk/linux/driver/smp/rust/smp_driver_helpers.rs',
                          'ihk/linux/user/rust/ihklib_helpers.rs'] if not (source / p).is_file()]
    record['historical_equivalence'] = dict(status='prerequisites-unavailable', missing=missing,
        retained_failure='/work/mckernel-native-irq-images-20260907-2', pass_claimed=False,
        current_surface_equivalence='producer-check includes exact pinned C body and current Rust body')
    assert len(missing) == 3
    common = ['cmake', '-S', str(source), '-DCMAKE_BUILD_TYPE=Debug', '-DBUILD_TARGET=smp-x86',
              '-DKERNEL_DIR=/usr/src/kernels/4.18.0-553.159.1.el8_10.x86_64',
              '-DENABLE_PERF=ON', '-DENABLE_RUSAGE=ON', '-DENABLE_LINUX_WORK_IRQ_FOR_IKC=ON',
              '-DRUSTC=/opt/mckernel/cargo/bin/rustc', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    run('reject-invalid-abi', common + ['-B', str(out / 'invalid-abi'), '-DMCKERNEL_HOST_IRQ_ABI=invalid'], 'MCKERNEL_HOST_IRQ_ABI must be legacy or linux-6.12')
    run('reject-native-c-fallback', common + ['-B', str(out / 'invalid-native-fallback'), '-DMCKERNEL_HOST_IRQ_ABI=linux-6.12', '-DENABLE_RUST_KERNEL=OFF'], 'linux-6.12 IRQ ABI requires the x86_64 Rust kernel')
    run('reject-sysfs-legacy', common + ['-B', str(out / 'invalid-sysfs-legacy'), '-DENABLE_NATIVE_SYSFS_VERIFY=ON', '-DMCKERNEL_HOST_IRQ_ABI=legacy'], 'Native sysfs verification requires the x86_64 Rust kernel and linux-6.12 IRQ ABI')
    run('reject-sysfs-c', common + ['-B', str(out / 'invalid-sysfs-c'), '-DENABLE_NATIVE_SYSFS_VERIFY=ON', '-DMCKERNEL_HOST_IRQ_ABI=legacy', '-DENABLE_RUST_KERNEL=OFF'], 'Native sysfs verification requires the x86_64 Rust kernel and linux-6.12 IRQ ABI')
    record['images'] = []
    record['clone3_table_checks'] = []
    record['signal_stack_checks'] = []
    for label, enabled, abi in [('fallback', 'OFF', 'legacy'), ('legacy-rust', 'ON', 'legacy'), ('native-rust', 'ON', 'linux-6.12'), ('native-sysfs-verify', 'ON', 'linux-6.12')]:
        build = out / label
        verification = label == 'native-sysfs-verify'
        profile = ['-DENABLE_NATIVE_SYSFS_VERIFY=ON'] if verification else []
        run(label + '-configure', common + ['-B', str(build), '-DCMAKE_INSTALL_PREFIX=' + str(out / (label + '-prefix')),
                '-DENABLE_RUST_KERNEL=' + enabled, '-DENABLE_RUST_IHK_MODULE_HELPERS=' + enabled,
                '-DENABLE_RUST_USER_TOOLS=' + enabled, '-DMCKERNEL_HOST_IRQ_ABI=' + abi] + profile)
        run(label + '-build', ['cmake', '--build', str(build), '--target', 'mckernel.img', '-j4'])
        image = build / 'kernel/mckernel.img'
        artifacts = [image, build / 'kernel/mckernel.img.map', build / 'CMakeCache.txt', build / 'compile_commands.json']
        (out / (label + '-elf-header.txt')).write_bytes(subprocess.check_output(['readelf', '-h', str(image)]))
        (out / (label + '-symbols.txt')).write_bytes(subprocess.check_output(['nm', '-n', str(image)]))
        header = (out / (label + '-elf-header.txt')).read_text()
        assert 'ELF64' in header and 'Advanced Micro Devices X86-64' in header and 'EXEC' in header
        symbols = (out / (label + '-symbols.txt')).read_text()
        assert ' T ihk_mc_interrupt_host\n' in symbols
        assert ('ENABLE_NATIVE_SYSFS_VERIFY:BOOL=ON' in (build / 'CMakeCache.txt').read_text()) == verification
        assert ('sysfs_verify' in symbols) == verification
        assert (b'NATIVE_GUEST_SYSFS PASS' in image.read_bytes()) == verification
        if enabled == 'ON':
            artifacts += [build / 'kernel/rust/mckernel_rust.o', build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make']
            assert 'kernel/rust/procfs.rs' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            assert not any(row['file'].endswith('/kernel/procfs.c') for row in json.loads((build / 'compile_commands.json').read_text()))
            selected = 'native_linux_irq_work_v6_12' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
            assert selected == (abi == 'linux-6.12')
            assert ('--cfg native_sysfs_verify' in (build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()) == verification
            run(label + '-linked-ownership', ['python3', str(source / 'scripts/mckernel_linked_text_ownership.py'), '--image', str(image), '--link-map', str(build / 'kernel/mckernel.img.map'), '--rust-object', str(build / 'kernel/rust/mckernel_rust.o'), '--source-commit', head, '--output', str(out / (label + '-linked-ownership.json'))])
        sized=subprocess.check_output(['nm','-S',str(image)],universal_newlines=True)
        (out/(label+'-sized-symbols.txt')).write_text(sized)
        for symbol in ['sys_mprotect','do_fork','do_signal','sys_rt_sigreturn','sys_sigaltstack'] + (['sys_clone3','native_signal_stack_prepare_result','native_signal_stack_publish_result','arch_rt_sigreturn_body_result'] if abi == 'linux-6.12' else []) + (['set_host_vma_body_result','mprotect_body_result','__ihk_numa_zero_request_packet_fill','__ihk_numa_zero_free_pages_node'] if enabled == 'ON' else []):
            matches=[line.split() for line in sized.splitlines() if line.split()[-1:]==[symbol]]
            assert len(matches)==1 and len(matches[0])==4,(symbol,matches)
            start,size=int(matches[0][0],16),int(matches[0][1],16)
            assert size>0,(symbol,size)
            run(label+'-'+symbol+'-disassembly',['objdump','-d','--start-address='+hex(start),'--stop-address='+hex(start+size),str(image)])
        symbol_map={row[-1]:(int(row[0],16),int(row[1],16)) for line in sized.splitlines() for row in [line.split()] if len(row)==4}
        native=abi=='linux-6.12'
        assert ('sys_clone3' in symbol_map)==native
        data=image.read_bytes()
        assert data[:6]==b'\x7fELF\x02\x01'
        table,table_bytes=symbol_map['syscall_table'];assert table_bytes>=436*8
        phoff=struct.unpack_from('<Q',data,32)[0];entsize,entries=struct.unpack_from('<HH',data,54)
        def table_word(index):
            address=table+index*8
            for entry in range(entries):
                kind,flags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',data,phoff+entry*entsize)
                if kind==1 and vaddr<=address and address+8<=vaddr+filesz:
                    return struct.unpack_from('<Q',data,offset+address-vaddr)[0]
            raise AssertionError(('syscall table not file-backed',index,hex(address)))
        expected=symbol_map['sys_clone3'][0] if native else 0
        assert table_word(435)==expected
        assert table_word(56)==symbol_map['sys_clone'][0]
        commands=json.loads((build/'compile_commands.json').read_text())
        dispatch=[row for row in commands if row['file']==str(source/'kernel/syscall.c')];assert len(dispatch)==1
        arch_dispatch=[row for row in commands if row['file']==str(source/'arch/x86_64/kernel/syscall.c')];assert len(arch_dispatch)==1
        for row in dispatch+arch_dispatch:
            assert ('-DMCKERNEL_NATIVE_CLONE3' in row['command'])==native
        fork_code=(out/(label+'-do_fork-disassembly.log')).read_text()
        assert bool(re.search(r'\$0x1b3\b',fork_code))==native
        if enabled=='ON':assert 'kernel/rust/clone3.rs' in (build/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
        for name in ['native_signal_stack_prepare_result','native_signal_stack_publish_result']:
            assert (name in symbol_map)==native,name
            code=(out/(label+'-do_signal-disassembly.log')).read_text()
            if native:
                address=hex(symbol_map[name][0]);lines=code.splitlines()
                loads=[(i,re.search(r'\bmovabs\s+\$'+re.escape(address)+r',(%\w+)',line)) for i,line in enumerate(lines)]
                loads=[(i,m) for i,m in loads if m];assert len(loads)==1,(label,name,loads)
                index,match=loads[0];register=match[1];window=lines[index+1:index+8]
                calls=[i for i,line in enumerate(window) if re.search(r'\bcallq?\s+\*'+re.escape(register)+r'\s*$',line)]
                assert len(calls)==1,(label,name,window)
                assert not any(re.search(r','+re.escape(register)+r'\s*$',line) or re.search(r'\bcallq?\b',line) for line in window[:calls[0]]),(label,name,window)
        assert ('-DMCKERNEL_NATIVE_SIGNAL_STACK' in arch_dispatch[0]['command'])==native
        assert table_word(15)==symbol_map['sys_rt_sigreturn'][0]
        assert table_word(131)==symbol_map['sys_sigaltstack'][0]
        if enabled=='ON':assert 'kernel/rust/native_signal.rs' in (build/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
        record['signal_stack_checks'].append(dict(profile=label,native=native,slot15=table_word(15),slot131=table_word(131),prepare=symbol_map.get('native_signal_stack_prepare_result'),publish=symbol_map.get('native_signal_stack_publish_result'),architecture_dispatch=arch_dispatch[0]))
        record['clone3_table_checks'].append(dict(profile=label,native=native,table=table,table_bytes=table_bytes,slot435=table_word(435),rust_handler=expected,existing_clone=table_word(56),native_marker_bypass=native,compiler_dispatch=dispatch[0],architecture_dispatch=arch_dispatch[0]))
        record['images'].append(dict(kind=label, host_irq_abi=abi, native_sysfs_verify=verification, outputs=[identity(path) for path in artifacts]))
        save()
    assert record['images'][1]['outputs'][0]['sha256'] != record['images'][2]['outputs'][0]['sha256']
    assert record['images'][2]['outputs'][0]['sha256'] != record['images'][3]['outputs'][0]['sha256']
    for item in record['production_inputs']:
        assert identity(Path(item['path'])) == item
    assert any(row['file'].endswith('/kernel/procfs.c') for row in json.loads((out / 'fallback/compile_commands.json').read_text()))
    record.update(status='PASS', phase='complete', native_zeroing_batch_compiled=True, native_host_zeroing_integrated=True, native_clone3_guest_handler_compiled=True, native_protection_invalidation_compiled=True, procfs_guest_lifetime_fixes_compiled=True, native_procfs_completion_marker_selected=True, native_retirement_query_compiled=True, procfs_service_integrated=True, mckernel_application_executed=False)
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    print('FAIL', record.get('phase'), error, flush=True)
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
