/work/mckernel-native-signals-images-20260909-2/fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-signals-images-20260909-2/fallback/tmp.resolve_MODULES_END/driver.o

