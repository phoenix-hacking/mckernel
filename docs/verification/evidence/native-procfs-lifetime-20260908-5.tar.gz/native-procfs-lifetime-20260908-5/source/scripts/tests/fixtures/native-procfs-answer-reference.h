struct ihk_ikc_packet_header {
	struct ihk_ikc_channel_desc *channel;
};
#define	SCD_MSG_PROCFS_ANSWER		0x13
#define PROCFS_NAME_MAX 768
enum mcctrl_os_cpu_operation {
	MCCTRL_OS_CPU_READ_REGISTER,
	MCCTRL_OS_CPU_WRITE_REGISTER,
	MCCTRL_OS_CPU_MAX_OP
};
struct ikc_scd_packet {
	struct ihk_ikc_packet_header header;
	int msg;
	int err;
	void *reply;
	union {
		/* for traditional SCD_MSG_* */
		struct {
			int ref;
			int osnum;
			int pid;
			unsigned long arg;
			struct syscall_request req;
			unsigned long resp_pa;
		};

		/* for SCD_MSG_SYSFS_* */
		struct {
			long sysfs_arg1;
			long sysfs_arg2;
			long sysfs_arg3;
		};

		/* SCD_MSG_WAKE_UP_SYSCALL_THREAD */
		struct {
			int ttid;
		};

		/* SCD_MSG_CPU_RW_REG */
		struct {
			unsigned long pdesc; /* Physical addr of the descriptor */
			enum mcctrl_os_cpu_operation op;
			void *resp;
		};

		/* SCD_MSG_EVENTFD */
		struct {
			int eventfd_type;
		};

		/* SCD_MSG_FUTEX_WAKE */
		struct {
			void *resp;
			int *spin_sleep; /* 1: waiting in linux_wait_event() 0: woken up by someone else */
		} futex;

		/* SCD_MSG_REMOTE_PAGE_FAULT */
		struct {
			int target_cpu;
			int fault_tid;
			unsigned long fault_address;
			unsigned long fault_reason;
		};
	};
	/* char padding[8]; */ /* We want the size to be 128 bytes */
};
struct procfs_read {
	unsigned long pbuf;	/* physical address of the host buffer (request) */
	unsigned long offset;	/* offset to read (request) */
	int count;		/* bytes to read (request) */
	int eof;		/* if eof is detected, 1 otherwise 0. (answer)*/
	int ret;		/* read bytes (answer) */
	int newcpu;		/* migrated new cpu (answer) */
	int readwrite;		/* 0:read, 1:write */
	char fname[PROCFS_NAME_MAX];	/* procfs filename (request) */
};
typedef void (*procfs_answer_send_fn_t)(void *channel,
					struct ikc_scd_packet *packet);
int procfs_answer_result(void *channel, struct ikc_scd_packet *request,
			 int err, procfs_answer_send_fn_t send_fn)
{
	struct ikc_scd_packet packet;

	if (!request || !send_fn)
		return -EINVAL;

	memset(&packet, '\0', sizeof(packet));
	packet.msg = SCD_MSG_PROCFS_ANSWER;
	packet.ref = request->ref;
	packet.arg = request->arg;
	packet.err = err;
	packet.reply = request->reply;
	packet.pid = request->pid;
	send_fn(channel, &packet);
	return 0;
}
