//! Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
//! Exact environment convenience contracts, including original allocation debt.

use core::ffi::{c_char, c_int, c_long, c_void};
use core::ptr::null_mut;

unsafe extern "C" {
    fn calloc(count: usize, size: usize) -> *mut c_void;
    fn strndup(text: *const c_char, length: usize) -> *mut c_char;
    fn strdup(text: *const c_char) -> *mut c_char;
    fn strsep(cursor: *mut *mut c_char, delimiters: *const c_char) -> *mut c_char;
    fn strcmp(first: *const c_char, second: *const c_char) -> c_int;
    fn strtol(text: *const c_char, end: *mut *mut c_char, base: c_int) -> c_long;
    fn free(pointer: *mut c_void);
    fn __errno_location() -> *mut c_int;
    fn _ihk_reserve_cpu_str(index: c_int, list: *mut c_char, error: *mut c_char) -> c_int;
    fn _ihk_reserve_mem_str(index: c_int, list: *mut c_char, error: *mut c_char) -> c_int;
    fn _ihk_os_assign_cpu_str(index: c_int, list: *mut c_char, error: *mut c_char) -> c_int;
    fn _ihk_os_set_ikc_map_str(index: c_int, list: *mut c_char, error: *mut c_char) -> c_int;
}

/// Split the original concatenated NUL-terminated environment entries.
///
/// # Safety
/// envp must supply num_env NUL-terminated strings within a readable 1MiB region.
/// On success, names_out and values_out must be writable pointer slots. Returned
/// arrays and strings use libc allocation. Original partial-failure allocations
/// and unchecked per-entry strdup failures are retained, not silently repaired.
#[no_mangle]
pub unsafe extern "C" fn parse_env(
    envp: *const c_char,
    num_env: c_int,
    names_out: *mut *mut *mut c_char,
    values_out: *mut *mut *mut c_char,
) -> c_int {
    if envp.is_null() || num_env <= 0 || num_env > 1024 {
        return -22;
    }
    // SAFETY: validated count bounds the pointer arrays; libc supplies alignment.
    let names: *mut *mut c_char = unsafe {
        calloc(core::mem::size_of::<*mut c_char>(), num_env as usize)
    }.cast();
    if names.is_null() {
        return -12;
    }
    // SAFETY: same allocation contract; first allocation is retained on failure
    // exactly as original parse_env, whose out label performs no cleanup.
    let values: *mut *mut c_char = unsafe {
        calloc(core::mem::size_of::<*mut c_char>(), num_env as usize)
    }.cast();
    if values.is_null() {
        return -12;
    }
    let mut start = 0usize;
    let mut current = 0usize;
    for i in 0..num_env as usize {
        // SAFETY: caller supplies the readable environment prefix; every prior
        // increment rejects the 1MiB boundary before the next read.
        while unsafe { envp.add(current).read() } != 0 {
            current += 1;
            if current >= 1 << 20 {
                return -22;
            }
        }
        // SAFETY: the bounded scan established the current entry's readable bytes.
        let pair = unsafe { strndup(envp.add(start), current - start) };
        if pair.is_null() {
            // SAFETY: capture libc errno immediately; no cleanup changes it.
            return unsafe { -*__errno_location() };
        }
        let mut tail = pair;
        // SAFETY: pair is writable libc storage; '=' is a fixed NUL delimiter.
        let name = unsafe { strsep(&mut tail, b"=\0".as_ptr().cast()) };
        if tail.is_null() {
            // SAFETY: strsep always returns the first live token for nonnull pair.
            if unsafe { name.read() } == 0 {
                // Original error retains pair and the partial arrays.
                return -22;
            }
            tail = b"\0".as_ptr() as *mut c_char;
        }
        // SAFETY: both strings are NUL-terminated. Original strdup failures are
        // stored unchecked; each pointer-array index is within validated count.
        unsafe {
            names.add(i).write(strdup(name));
            values.add(i).write(strdup(tail));
            free(pair.cast());
        }
        current += 1;
        if current >= 1 << 20 {
            return -22;
        }
        start = current;
    }
    // SAFETY: caller supplies the writable output slots; ownership transfers only
    // after every original range/split check succeeds.
    unsafe {
        names_out.write(names);
        values_out.write(values);
    }
    0
}

type StringOperation = unsafe extern "C" fn(c_int, *mut c_char, *mut c_char) -> c_int;

unsafe fn first(
    index: c_int,
    envp: *const c_char,
    count: c_int,
    key: &'static [u8],
    operation: StringOperation,
) -> c_int {
    let mut names = null_mut();
    let mut values = null_mut();
    // SAFETY: wrappers forward the caller's environment contract and own slots.
    let result = unsafe { parse_env(envp, count, &mut names, &mut values) };
    if result != 0 {
        return result;
    }
    for i in 0..count as usize {
        // SAFETY: successful parse populated count entries. Like C, per-entry
        // strdup OOM is not checked before strcmp; no new success claim covers UB.
        if unsafe { strcmp(names.add(i).read(), key.as_ptr().cast()) } == 0 {
            // SAFETY: operation is the matching public string helper, receives
            // its live owned value and no caller diagnostic buffer, as in C.
            return unsafe { operation(index, values.add(i).read(), null_mut()) };
        }
    }
    // The original wrappers do not free the returned arrays/entries on any path.
    0
}

/// Reserve CPUs from the first IHK_CPUS entry.
///
/// # Safety
/// envp must satisfy parse_env's input contract; libc and device providers must
/// satisfy the selected ABI. Original wrapper allocation leaks are retained.
#[no_mangle]
pub unsafe extern "C" fn ihk_reserve_cpu_str(
    index: c_int, envp: *const c_char, count: c_int,
) -> c_int {
    // SAFETY: exact key and original public operation; caller owns input lifetime.
    unsafe { first(index, envp, count, b"IHK_CPUS\0", _ihk_reserve_cpu_str) }
}

/// Reserve memory from the first IHK_MEM entry.
///
/// # Safety
/// envp must satisfy parse_env's readable input contract; selected ABI applies.
#[no_mangle]
pub unsafe extern "C" fn ihk_reserve_mem_str(
    index: c_int, envp: *const c_char, count: c_int,
) -> c_int {
    // SAFETY: exact key and original public operation, with no diagnostic output.
    unsafe { first(index, envp, count, b"IHK_MEM\0", _ihk_reserve_mem_str) }
}

/// Assign CPUs from the first IHK_CPUS entry.
///
/// # Safety
/// envp must satisfy parse_env's readable input contract; selected ABI applies.
#[no_mangle]
pub unsafe extern "C" fn ihk_os_assign_cpu_str(
    index: c_int, envp: *const c_char, count: c_int,
) -> c_int {
    // SAFETY: exact key and original operation, preserving first-match behavior.
    unsafe { first(index, envp, count, b"IHK_CPUS\0", _ihk_os_assign_cpu_str) }
}

/// Set the IKC map from the first IHK_IKC_MAP entry.
///
/// # Safety
/// envp must satisfy parse_env's readable input contract; selected ABI applies.
#[no_mangle]
pub unsafe extern "C" fn ihk_os_set_ikc_map_str(
    index: c_int, envp: *const c_char, count: c_int,
) -> c_int {
    // SAFETY: exact key and original operation; no shared parser is duplicated.
    unsafe { first(index, envp, count, b"IHK_IKC_MAP\0", _ihk_os_set_ikc_map_str) }
}

const CONFIG_KEYS: [&[u8]; 6] = [
    b"IHK_RESERVE_MEM_BALANCED_ENABLE\0",
    b"IHK_RESERVE_MEM_BALANCED_BEST_EFFORT\0",
    b"IHK_RESERVE_MEM_BALANCED_VARIANCE_LIMIT\0",
    b"IHK_RESERVE_MEM_MIN_CHUNK_SIZE\0",
    b"IHK_RESERVE_MEM_MAX_SIZE_RATIO_ALL\0",
    b"IHK_RESERVE_MEM_TIMEOUT\0",
];

/// Apply recognized policy entries in environment order, retaining C int narrowing.
///
/// # Safety
/// envp must satisfy parse_env's input contract. Callers serialize configuration
/// updates as required by the existing non-atomic public state contract.
#[no_mangle]
pub unsafe extern "C" fn ihk_reserve_mem_conf_str(
    index: c_int, envp: *const c_char, count: c_int,
) -> c_int {
    let mut names = null_mut();
    let mut values = null_mut();
    // SAFETY: caller supplies input and local pointer slots are writable.
    let result = unsafe { parse_env(envp, count, &mut names, &mut values) };
    if result != 0 {
        return result;
    }
    for i in 0..count as usize {
        for (key, text) in CONFIG_KEYS.iter().enumerate() {
            // SAFETY: successful parse provides count entries under C's original
            // allocation-success precondition; key is a static NUL string.
            if unsafe { strcmp(names.add(i).read(), text.as_ptr().cast()) } != 0 {
                continue;
            }
            let mut end = null_mut();
            // SAFETY: the selected entry is NUL-terminated; end is writable.
            let mut value = unsafe { strtol(values.add(i).read(), &mut end, 10) } as c_int;
            // SAFETY: strtol supplies a valid pointer into its original input.
            if unsafe { end.read() } != 0 {
                return -22;
            }
            // SAFETY: value is a live aligned C int; caller serializes state.
            let result = unsafe {
                super::runtime_state::ihk_reserve_mem_conf(
                    index, key as c_int, (&mut value as *mut c_int).cast(),
                )
            };
            if result != 0 {
                return result;
            }
        }
    }
    0
}

/// Set the first IHK_KARGS value, or the caller's unchanged default.
///
/// # Safety
/// envp must satisfy parse_env's input contract. The selected/default kargs must
/// satisfy ihk_os_kargs's readable string contract for the synchronous request.
#[no_mangle]
pub unsafe extern "C" fn ihk_os_kargs_str(
    index: c_int,
    envp: *const c_char,
    count: c_int,
    default_kargs: *const c_char,
) -> c_int {
    let mut names = null_mut();
    let mut values = null_mut();
    // SAFETY: caller input is forwarded unchanged and local slots are writable.
    let result = unsafe { parse_env(envp, count, &mut names, &mut values) };
    if result != 0 {
        return result;
    }
    let mut kargs = default_kargs as *mut c_char;
    for i in 0..count as usize {
        // SAFETY: successful parse produces the original valid entry pointers.
        if unsafe { strcmp(names.add(i).read(), b"IHK_KARGS\0".as_ptr().cast()) } == 0 {
            // SAFETY: index is within the populated array.
            kargs = unsafe { values.add(i).read() };
            break;
        }
    }
    // SAFETY: selected/default input remains live; original pointer is forwarded.
    unsafe { super::os_kargs::ihk_os_kargs(index, kargs) }
}
