/* Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
 * Nonshipped selected HOST ABI witness; mismatch refuses before Rust/provider execution. */
#include <sys/stat.h>
#include <stddef.h>
#include <ihk/ihklib_private.h>
_Static_assert(sizeof(struct stat)==144 && _Alignof(struct stat)==8,"HOST stat storage");
_Static_assert(_STAT_VER==1,"selected HOST x86_64 __xstat version");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ihk_os_get_status),int(*)(int)),"status");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ihk_os_kmsg),int(*)(int,char*,ssize_t)),"kmsg");
_Static_assert(__builtin_types_compatible_p(__typeof__(&ihklib_os_query_mem_sysfs),
    int(*)(int,char*,ssize_t,const char*)),"sysfs");
