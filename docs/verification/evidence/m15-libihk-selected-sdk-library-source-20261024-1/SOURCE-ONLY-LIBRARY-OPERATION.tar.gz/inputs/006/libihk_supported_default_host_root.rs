//! Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
//! Private current provider composition; actual ABI generation precedes compilation.

#[path = "../../held-OS-provider-composition-source-1/accepted_host_root.assigned_memory_dependency_join.rs"]
mod accepted_cpu_memory;

#[path = "../../os-cpu-public-source-1/ihklib_mcstat_shared_readable.rs"]
mod ihklib_mcstat;

#[path = "../../eventfd-correctness-successor-1/ihklib_eventfd.rs"]
mod owned_eventfd;

#[path = "../../../../velocity-intervention-20261024-1/m15-perf-pages-provider/ihklib_perf.rs"]
mod perf_pages;

#[path = "../../../../velocity-intervention-20261024-1/m15-dump-provider/correctness-successor-1/ihklib_dump.rs"]
mod dump_correctness;

// Existing Rust rusage layout: the paired C witness checks the actual headers.
const _: [(); 16_568] = [(); core::mem::size_of::<ihklib_mcstat::IhkOsRusage>()];

#[path = "../../../../velocity-intervention-20261023-8/m15-libihk/next-ikc-public-source-1/ihklib_cli_parsers_ikc_shared.rs"]
mod ihklib_cli_parsers;

#[path = "../../../../velocity-intervention-20261023-8/m15-libihk/next-ikc-public-source-1/ihklib_ikc.rs"]
mod ihklib_ikc;

#[path = "../../../../velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_status_kmsg.rs"]
mod ihklib_status_kmsg;

#[path = "../../../../velocity-intervention-20261023-8/m15-libihk/ihkosctl-public-providers-source-only-1/ihklib_mcstat_memory_shared_parser.rs"]
mod ihklib_mcstat_memory;

#[path = "../../runtime-state-selection-source-1/ihklib_runtime_state.rs"]
mod runtime_state;

use accepted_cpu_memory::{ihklib_device_open, IhkCpuReq};

#[path = "../../os-cpu-public-source-1/ihklib_os_cpu.rs"]
mod os_cpu;

#[path = "../../os-instance-lifecycle-source-1/ihklib_os_instance_lifecycle.rs"]
mod os_instances;

#[path = "../../os-load-boot-source-1/ihklib_os_load_boot.rs"]
mod os_load_boot;

#[path = "../../kmsg-control-source-1/ihklib_kmsg_control.rs"]
mod kmsg_control;

#[path = "../../shutdown-freeze-config-report-source-1/ihklib_shutdown_freeze.rs"]
mod shutdown_freeze;

#[path = "../../shutdown-freeze-config-report-source-1/ihklib_configuration_report.rs"]
mod configuration_report;

#[path = "../../ikc-map-kargs-source-1/ihklib_ikc_map.rs"]
mod ikc_map;

#[path = "../../ikc-map-kargs-source-1/ihklib_os_kargs.rs"]
mod os_kargs;

#[path = "../../environment-public-source-1/ihklib_environment.rs"]
mod environment;

#[path = "ihklib_raw_strings.rs"]
mod raw_strings;

#[path = "ihklib_create_os_environment.rs"]
mod create_os_environment;

#[path = "../../create-os-environment-source-1/ihklib_legacy_data.rs"]
mod legacy_data;
