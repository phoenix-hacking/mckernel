#!/usr/bin/python3
"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Private selected-SDK metadata/compiler/link driver; no devices, CLI or kernel build.
"""
from pathlib import Path
import ast, hashlib, json, os, re, resource, shlex, signal, stat, time
entered=time.monotonic()
PREP = '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/selected-SDK-library-operation-1/private-library-successor-1/selected-source-1/preparation.json'
PREP_SHA = 'e4aaa395d77b5d66e9bf69a08beb6a4f93bdd1e7693da4143e0e06a7e05377d3'
D = Path('/work/sdk70-selected-successor-1')
E = Path('/work/evidence')
def need(ok, why):
    if not ok: raise RuntimeError(why)
def digest(p):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_nlink==1,'regular singlelink source')
        value=hashlib.sha256();size=0
        for block in iter(lambda:os.read(fd,65536),b''):
            size+=len(block);need(size<=32<<20,'bounded input hash');value.update(block)
        last=os.fstat(fd);path=p.lstat()
        fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        need(size==last.st_size and all(getattr(first,k)==getattr(last,k)==getattr(path,k) for k in fields),'stable input FD')
        return value.hexdigest()
    finally:os.close(fd)
def load(ref):
    p=Path(ref['path']); need(p.is_file() and not p.is_symlink(), 'regular source')
    need(digest(p)==ref['sha256'], 'source hash '+str(p))
    return json.loads(p.read_bytes())
def positive(r):
    return r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and r['error'] is None and r['retirement_error'] is None
p=Path(PREP); need(digest(p)==PREP_SHA,'preparation')
prep=json.loads(p.read_bytes()); commands=load(prep['commands'])
need(len(commands)==15 and os.getuid()==os.getgid()==1000,'15 commands/UID')
need(os.sched_getaffinity(0)=={2,3,4,5},'accepted heavy CPUs')
for r in prep['closure']:
    q=Path(r['path']);need(q.is_file() and not q.is_symlink() and q.stat().st_size==r['bytes'] and digest(q)==r['sha256'],'source closure')
tool_aliases={}
for q,v in prep['target_tools'].items():
    target=Path(q).resolve(strict=True);need(digest(target)==v,'exact selected SDK tool/header '+q)
    tool_aliases[q]=str(target)
h=prep['capture_helper'];need(digest(h['path'])==h['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8','h990')
names={'need','write','hashed','stop','members','process_start','terminal_unreaped','wait_terminal','owned_capture'}
assign={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
nodes=[n for n in ast.parse(Path(h['path']).read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assign for t in n.targets)]
ns={'__file__':h['path']};exec(compile(ast.Module(body=nodes,type_ignores=[]),h['path'],'exec'),ns)
need(not D.exists() and not E.exists(),'fresh output')
D.mkdir(mode=0o700);E.mkdir(mode=0o700);os.chdir(D)
values=[(resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)]
def limits():
    for k,v in values:resource.setrlimit(k,(v,v))
    os.sched_setaffinity(0,{2,3,4,5})
def budget():
    c=resource.getrusage(resource.RUSAGE_SELF);k=resource.getrusage(resource.RUSAGE_CHILDREN)
    need(c.ru_utime+c.ru_stime+k.ru_utime+k.ru_stime<=60,'whole CPU')
    need(time.monotonic()-started<90,'whole wall')
    need(sum(p.stat().st_size for p in Path('/work').rglob('*') if p.is_file())<=512<<20,'output aggregate')
for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,ns['stop'])
need(time.monotonic()-entered<90,'preflight wall');started=entered;signal.setitimer(signal.ITIMER_REAL,90-(time.monotonic()-entered))
rows=[];artifacts={};native=None;cfg=None
receipt={'schema':'mckernel.sdk-library-driver-receipt.v1','status':'FAIL','commands':rows,'artifacts':artifacts,'preparation_sha256':PREP_SHA,'source_identity':prep['source_identity'],'source_sha256':{r['path']:r['sha256'] for r in prep['closure']},'native_credit':False,'default_credit':False,'CLI_executed':False,'C_runtime_TU':False,'actual_target_tools':tool_aliases}
try:
    for i,cmd in enumerate(commands):
        budget();need(not ns['stopping'],'stop latch');q=D/('%02d'%i);q.mkdir(mode=0o700)
        argv=list(cmd['argv'])
        if cmd.get('late_stat_cfg'):
            need(cfg==prep['root_stat_cfg'],'actual successful platform witness')
            argv=[cfg if a=='ACTUAL_STAT_CFG_FROM_SUCCESSFUL_SELECTED_HEADER_WITNESS' else a for a in argv]
        if cmd.get('late_native_flags'):
            need(native and argv[-1]=='ACTUAL_NATIVE_STATIC_LIBS_AFTER_RUST_COMPILE','actual compiler native flags')
            argv=argv[:-1]+native
        env=dict(cmd.get('env',{}));env['RUST_MIN_STACK']='2097152'
        for k,v in cmd.get('env',{}).items():need(Path(v).is_file() and Path(v).parent==D,'generated ABI')
        old={k:os.environ.get(k) for k in env};os.environ.update(env)
        ns['write'](q/'command.json',dict(actual_argv=argv,actual_env=env,cwd=str(D)))
        try:r=ns['owned_capture']({'argv':argv},q,90-(time.monotonic()-started),limits)
        finally:
            for k,v in old.items():
                if v is None:os.environ.pop(k,None)
                else:os.environ[k]=v
        ns['write'](q/'RESULT.json',r);rows.append({'index':i,'label':cmd['label'],'actual_argv':argv,'result':r})
        if 'artifact' in cmd and Path(cmd['artifact']).exists():
            artifacts[cmd['artifact']]=ns['hashed'](Path(cmd['artifact']),32<<20)
            ns['write'](E/('DURABLE-AFTER-%02d.json'%i),artifacts)
        need(positive(r),'first failed command '+str(i));budget()
        err=(q/'stderr').read_text();need(not err or i==9,'unexpected stderr')
        if cmd.get('generated_stdout_to'):
            raw=(q/'stdout').read_bytes();need(0<len(raw)<=1048576 and b'pub const ' in raw,'metadata only')
            t=Path(cmd['generated_stdout_to']);fd=os.open(t,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
            artifacts[str(t)]=ns['hashed'](t,1048576)
        if cmd.get('late_stat_cfg_stdout'):
            need((q/'stdout').read_bytes()==b'ihklib_stat_abi_stat\n','exact platform ABI witness')
            cfg=prep['root_stat_cfg']
        if i==9:
            matches=re.findall(r'^note: native-static-libs: (.+)$',err,re.M);need(len(matches)==1,'samecompile native flags')
            need(err.strip()=='note: native-static-libs: '+matches[0], 'unexpected compiler diagnostic')
            native=shlex.split(matches[0]);need(native and all(re.fullmatch(r'-l[A-Za-z0-9_+.-]+',a) for a in native),'native library flags only')
    observed={}
    for label,i in [('archive',11),('shared',12)]:
        txt=(D/('%02d'%i)/'stdout').read_text().splitlines();found={}
        for name in prep['functions']+prep['data']:
            hits=[r.split() for r in txt if r.split()[-1:]==[name]]
            need(len(hits)==1,'unique selected root '+name);kind=hits[0][-2]
            need(kind=='T' if name in prep['functions'] else kind in 'BDRSG','real provider '+name);found[name]=kind
        observed[label]=found
    undefined=(D/'13/stdout').read_text().split()
    need(not any(n in undefined for n in prep['functions']+prep['data']+['rust_eh_personality','rust_begin_unwind']),'unresolved Rust/API provider')
    elf=(D/'14/stdout').read_text();need(all(v in elf for v in ['ELF64','DYN','X86-64']),'actual selected ELF ABI')
    for r in prep['closure']:need(digest(r['path'])==r['sha256'],'source postflight')
    for q,target in tool_aliases.items():
        need(str(Path(q).resolve(strict=True))==target and digest(target)==prep['target_tools'][q], 'same immutable tool alias/header postflight')
    for p,a in artifacts.items():
        t=Path(p).lstat();need((t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns)==(a['device'],a['inode'],a['size'],a['mtime_ns'],a['ctime_ns']),'stable produced artifact')
    budget();receipt.update(status='PASS_SELECTED_SDK_LIBRARY_HEADERS_ARCHIVE_DSO',provider_roots=observed,native_static_libs=native,platform_cfg=cfg)
except BaseException as exc:
    receipt['error']=str(exc)
    raise
finally:
    ns['write'](E/'receipt.json',receipt);signal.setitimer(signal.ITIMER_REAL,0)
