import hashlib
import json
import pathlib
import shutil
import stat
import tarfile

base = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/home/holden/mckernel')
scratch = pathlib.Path('/home/holden/mckernel-work/scratch')
attempt = scratch / 'stability-return-poll-tests-20260913-2'
sources = {
    'independent-source-review': pathlib.Path('/tmp/stability-return-poll-independent-review-20260913-d381k1kc'),
    'original-20-vector-source': pathlib.Path('/tmp/stability-return-poll-original20-source-20260913-47wby_b4'),
    'actual-21-vector-attempt': attempt,
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def mapped(path):
    if path.startswith('/work/'):
        return scratch / path[6:]
    if path.startswith('/workspace/'):
        return repo / path[11:]
    return None

checked = []
unmapped = []

def check_identity(row):
    p = mapped(row['path'])
    if p is None:
        unmapped.append(row)
        return
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode), str(p)
    data = p.read_bytes()
    assert len(data) == row['size'] and sha(data) == row['sha256'], str(p)
    checked.append(row)

record = json.loads((attempt / 'record.json').read_bytes())
expectations = json.loads((attempt / 'poll-expectations.json').read_bytes())
review = json.loads((sources['independent-source-review'] / 'review.json').read_bytes())
assert sha((sources['independent-source-review'] / 'review.json').read_bytes()) == '353f03af4992e5236e8e0132f8887bd024c5c510d5a819285f7c6d59d4720e17'
assert record['status'] == 'PASS_ACTUAL_C_RETURN_SAMPLE_CLASSIFICATION_ONLY'
assert record['passed_cases'] == len(record['cases']) == expectations['case_count'] == 21
assert record['observe_return_state_machine_tested'] is False
for key in ('application_acceptance', 'transport_acceptance', 'production_gate_credit', 'guest_execution'):
    assert record[key] is False
for row in review['reviewed_inputs']:
    retained = sources['independent-source-review'] / row['retained']
    assert sha(retained.read_bytes()) == row['sha256'] and len(retained.read_bytes()) == row['size']
    if retained.name != 'uprotocol.h':
        assert (attempt / retained.name).read_bytes() == retained.read_bytes()
for row in record['inputs'] + record['compiler_dependencies']:
    assert row['original']['sha256'] == row['retained']['sha256']
    assert row['original']['size'] == row['retained']['size']
    check_identity(row['original'])
    check_identity(row['retained'])
for row in record['compiled_outputs'] + record['loader_dependencies']:
    check_identity(row)

expected_names = set()
kinds = {'UNKNOWN': 0, 'RET': 1, 'OTHER': 2}
stdout = b''
for expected, case in zip(expectations['cases'], record['cases']):
    assert case['expected'] == expected
    name = expected['name']
    raw_path = attempt / 'cases' / (name + '.raw')
    result_path = attempt / 'cases' / (name + '.json')
    raw = raw_path.read_bytes()
    observed = json.loads(result_path.read_bytes())
    assert raw == bytes.fromhex(expected['raw_hex'])
    assert observed == case['observed']
    assert observed['case'] == name and observed['status'] == 'PASS'
    assert observed['observed_kind'] == observed['expected_kind'] == kinds[expected['expected']]
    assert observed['error'] == expected['error']
    assert observed['application_acceptance'] is observed['transport_acceptance'] is False
    check_identity(case['raw'])
    check_identity(case['result'])
    expected_names.update((name + '.raw', name + '.json'))
    stdout += ('RETURN_POLL_CASE ' + name + ' PASS\n').encode()
assert {p.name for p in (attempt / 'cases').iterdir()} == expected_names
assert (attempt / 'poll21-collection' / 'stdout.bin').read_bytes() == stdout
assert (attempt / 'poll21-collection' / 'stderr.bin').read_bytes() == b''
assert record['cases'][13]['observed']['parsed'] == 0
assert record['cases'][13]['observed']['nr'] == -1
assert record['cases'][20]['observed']['parsed'] == 9
assert record['cases'][20]['observed']['nr'] == -1

for command in record['commands']:
    c = command['collection']
    directory = attempt / (command['label'] + '-collection')
    assert json.loads((directory / 'report.json').read_bytes()) == c
    assert c['status'] == 'COMPLETED' and c['raw_wait_status'] == 0
    assert c['cleanup_complete'] is True and c['descendant_records_omitted'] == 0
    assert c['payload_completion_observed_monotonic'] < c['payload_monotonic_deadline']
    assert c['wait_status'] == {'code': 0, 'kind': 'exited'}
    assert c['argv'] == command['argv'] and c['env'] == command['environment']
    for stream in c['streams'].values():
        check_identity(stream['artifact'])
        assert stream['eof'] is True and stream['truncated'] is False
        assert stream['discarded_observed_bytes'] == 0
        assert stream['bytes_observed'] == stream['bytes_retained'] == stream['artifact']['size']
    assert (directory / 'worker.stderr').read_bytes() == b''
    check_identity(c['executable'])
assert len(record['commands']) == 7
actual_elf = attempt / 'poll-harness.elf'
assert actual_elf.read_bytes()[:4] == b'\x7fELF'
assert record['commands'][-1]['collection']['executable']['sha256'] == sha(actual_elf.read_bytes())

def inventory(root):
    result = []
    for p in [root] + sorted(root.rglob('*')):
        s = p.lstat()
        rel = '.' if p == root else p.relative_to(root).as_posix()
        row = {'path': rel, 'mode': stat.S_IMODE(s.st_mode)}
        if stat.S_ISDIR(s.st_mode):
            row['type'] = 'directory'
        else:
            assert stat.S_ISREG(s.st_mode), str(p)
            data = p.read_bytes()
            row.update(type='file', size=len(data), sha256=sha(data))
        result.append(row)
    return result

bindings = []
for label, source in sources.items():
    before = inventory(source)
    target = base / label
    shutil.copytree(source, target, copy_function=shutil.copy2)
    assert inventory(source) == before == inventory(target)
    bindings.append({'original': str(source), 'retained': label, 'inventory': before})
helpers = base / 'invocation-helpers'
helpers.mkdir()
for name in ('check-return-poll.py', 'check-return-poll-2.py'):
    p = scratch / 'stability-20260913-1' / name
    data = p.read_bytes()
    shutil.copy2(p, helpers / name)
    assert p.read_bytes() == (helpers / name).read_bytes() == data
    bindings.append({'original': str(p), 'retained': 'invocation-helpers/' + name, 'sha256': sha(data), 'size': len(data)})

result = {
    'schema_version': 1,
    'status': 'PASS_SOURCE_REVIEW_AND_RETAINED_C_CLASSIFIER_RESULTS_ONLY',
    'source_review': review,
    'actual_result': {'path': str(attempt / 'record.json'), 'sha256': sha((attempt / 'record.json').read_bytes()), 'case_count': 21, 'command_count': 7, 'compiler_dependencies_rehashed': len(record['compiler_dependencies']), 'mapped_identities_rehashed': len(checked), 'elf_sha256': sha(actual_elf.read_bytes())},
    'result_checks': ['Exact reviewed source bytes match retained build inputs; all retained compiler dependencies and compiled outputs rehashed.', 'All 21 independent raw vectors and observed reports match, with exact 718-byte stdout, empty stderr, raw wait zero and complete bounded owned cleanup.', 'All seven original recorded command reports, stream hashes, EOFs, no truncation, raw waits and observed deadlines checked against retained files.'],
    'unmapped_original_container_identities_not_rehashed_here': unmapped,
    'original_to_retained': bindings,
    'scope': 'Source review and independent inspection of the already completed pinned C parser/classifier run. No new test, compiler, container, guest or subject-helper execution by reviewer.',
    'observe_return_state_machine_tested': False,
    'controller_live_guest_validation': False,
    'application_acceptance': False,
    'transport_acceptance': False,
    'production_gate_credit': False,
    'permanent_fault_caveat': 'Original permanent guest2 ret_left_observed and ret_left_ns are false polling observations derived from running. They remain preserved and rejected. The separately accepted narrow permanent fault uses actual native RET and later WNOWAIT plus both EOFs; this classifier result does not repair original evidence or close live controller validation.',
}
(base / 'result-review.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
entries = inventory(base)
archive = repo / 'docs/verification/evidence/stability-return-poll-independent-review-20260913.tar.gz'
publication = repo / 'docs/verification/stability-return-poll-independent-review-20260913.json'
assert not archive.exists() and not publication.exists()
with tarfile.open(archive, 'x:gz') as tar:
    for item in entries:
        p = base if item['path'] == '.' else base / item['path']
        name = base.name if item['path'] == '.' else base.name + '/' + item['path']
        tar.add(p, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(entries)
    assert len({m.name for m in members}) == len(entries)
    for row, member in zip(entries, members):
        name = base.name if row['path'] == '.' else base.name + '/' + row['path']
        assert member.name == name and member.mode == row['mode']
        if row['type'] == 'directory':
            assert member.isdir()
        else:
            assert member.isfile() and member.size == row['size']
            assert sha(tar.extractfile(member).read()) == row['sha256']
assert inventory(base) == entries
pub = {'schema_version': 1, 'status': result['status'], 'review': {'retained': base.name + '/result-review.json', 'sha256': sha((base / 'result-review.json').read_bytes())}, 'archive': {'path': str(archive.relative_to(repo)), 'sha256': sha(archive.read_bytes()), 'size': archive.stat().st_size, 'member_count': len(entries), 'all_member_bytes_types_modes_membership_verified': True}, 'members': entries, 'application_acceptance': False, 'transport_acceptance': False, 'observe_return_state_machine_tested': False, 'permanent_fault_caveat': result['permanent_fault_caveat']}
publication.write_text(json.dumps(pub, indent=2, sort_keys=True) + '\n')
print(json.dumps({'publication': str(publication), 'sha256': sha(publication.read_bytes()), 'archive': pub['archive'], 'mapped_identities': len(checked), 'unmapped_original_container_references': len(unmapped), 'review_tree': str(base)}, indent=2))
