from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shlex, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-return-poll-tests-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
              commands=[], inputs=[], compiler_dependencies=[], compiled_outputs=[], cases=[],
              application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
              guest_execution=False, scope='Twenty retained procfs and malformed/error samples through corrected actual controller parser/classifier; no controller CLI or guest execution')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    source = repo / 'scripts/tests/fixtures/stability-transport-fault/owner-return-poll-v1'
    required = {
        'poll_harness.c': '83625de45b850113f7c0e024c48fa1d90cc7895e09f1577eda5983a5715badfa',
        'controller.c': '2aa11489fc0f48041325cd90ddd0a8abfaaea16075a742f39408c3e168cdb76e',
        'phase_client.h': '03f17078369078898dfafc97b064b29a349efd6f758d9e7895f5cdb91579d9c7',
    }
    for name in (*required, 'poll-expectations.json', 'poll_cases.h', 'README.md', 'controller.original.c', 'controller.forward.patch', 'controller.inverse.patch', 'original-events.jsonl', 'original-report.json'):
        src, dst = source / name, out / name
        if name in required: assert identity(src)['sha256'] == required[name]
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    src = repo / 'scripts/application-tests/supervisor.py'
    assert identity(src)['sha256'] == '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
    shutil.copyfile(src, out / 'supervisor.py')
    record['inputs'].append(dict(original=identity(src), retained=identity(out / 'supervisor.py')))
    spec = importlib.util.spec_from_file_location('terminal_supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    def run(label, argv, timeout=120, cap=8*1024**2):
        if not Path(argv[0]).is_absolute(): argv[0] = shutil.which(argv[0], path=env['PATH'])
        record['phase'] = label; save(); print('RUN', label, flush=True)
        result = supervisor.run_supervised(argv, cwd=str(out), env=env,
            attempt_dir=str(out / (label + '-collection')), timeout_seconds=timeout,
            cleanup_timeout_seconds=15, stdout_limit_bytes=cap, stderr_limit_bytes=cap)
        record['commands'].append(dict(label=label, argv=argv, environment=env, collection=result)); save()
        assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete'], (label, result)
        return (out / (label + '-collection') / 'stdout.bin').read_text()
    run('compiler-version', ['gcc', '--version'])
    obj, elf, deps, linkmap = [out / ('poll-harness' + suffix) for suffix in ('.o', '.elf', '.d', '.map')]
    run('compile', ['gcc', '-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
        '-fno-pie', '-pthread', '-MD', '-MF', str(deps), '-I', str(repo / 'executer/include'),
        '-c', str(out / 'poll_harness.c'), '-o', str(obj)])
    run('link', ['gcc', '-no-pie', '-pthread', str(obj), '-Wl,-Map=' + str(linkmap), '-o', str(elf)])
    run('elf', ['readelf', '-h', '-l', '-d', str(elf)])
    data = run('loader-trace', ['ldd', str(elf)])
    for line in data.splitlines():
        for part in line.split():
            if part.startswith('/') and Path(part).is_file(): record.setdefault('loader_dependencies', []).append(identity(Path(part)))
    for item in shlex.split(deps.read_text().replace('\\\n', ' ').split(':', 1)[1]):
        src = Path(item)
        if not src.is_absolute(): src = out / src
        row = identity(src)
        if any(old['original'] == row for old in record['compiler_dependencies']): continue
        dst = out / 'compiler-inputs' / str(src).lstrip('/')
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)
        record['compiler_dependencies'].append(dict(original=row, retained=identity(dst)))
    record['compiled_outputs'] = [identity(p) for p in (obj, elf, deps, linkmap)]
    run('disassembly', ['objdump', '-d', str(elf)])
    expectations = json.loads((out / 'poll-expectations.json').read_text())
    assert expectations['case_count'] == len(expectations['cases']) == 20
    assert expectations['controller_sha256'] == identity(out / 'controller.c')['sha256']
    assert identity(out / 'poll-expectations.json')['sha256'] == 'bf46b22e51d2e2d576715f4dbc30de2b5897ee0a28b7d4d28a3fc24e0009fe02'
    assert identity(out / 'poll_cases.h')['sha256'] == '756dd530d437bfedf87fd711f2c6a777fcb7a4f8e1693e4b850d2e3aa1a1e6e2'
    run('poll20', [str(elf), str(out / 'cases')], timeout=10, cap=65536)
    expected_stdout = ''.join('RETURN_POLL_CASE ' + row['name'] + ' PASS\n' for row in expectations['cases']).encode()
    assert (out / 'poll20-collection/stdout.bin').read_bytes() == expected_stdout
    assert (out / 'poll20-collection/stderr.bin').read_bytes() == b''
    expected_files = {case['name'] + suffix for case in expectations['cases'] for suffix in ('.raw', '.json')}
    assert {p.name for p in (out / 'cases').iterdir()} == expected_files
    kinds = dict(UNKNOWN=0, RET=1, OTHER=2)
    for expected in expectations['cases']:
        name = expected['name']; path = out / 'cases' / (name + '.json')
        observed = json.loads(path.read_text())
        assert observed['case'] == name and observed['status'] == 'PASS'
        assert observed['error'] == expected['error']
        assert observed['expected_kind'] == observed['observed_kind'] == kinds[expected['expected']]
        assert observed['application_acceptance'] is observed['transport_acceptance'] is False
        raw = (out / 'cases' / (name + '.raw')).read_bytes()
        assert raw == bytes.fromhex(expected['raw_hex'])
        record['cases'].append(dict(expected=expected, observed=observed, result=identity(path), raw=identity(out / 'cases' / (name + '.raw')))); save()
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    for row in record['compiled_outputs'] + record['loader_dependencies']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS_ACTUAL_C_RETURN_SAMPLE_CLASSIFICATION_ONLY', passed_cases=20)
except BaseException as error:
    record.update(status='FAIL', error_type=type(error).__name__, error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save(); print(record['status'], out, flush=True)
