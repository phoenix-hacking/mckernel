from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import tarfile

REPO = Path('/home/holden/mckernel')
CAPTURE = Path('/tmp/stability-published-physical-source-20260913-nempio08')
PACK = Path(__file__).parent
EVIDENCE = REPO / 'docs/verification/evidence'
ARCHIVE = EVIDENCE / 'stability-published-physical-source-20260913-1.tar.gz'
MEMBERS = EVIDENCE / 'stability-published-physical-source-20260913-1.members.json'
PUBLICATION = REPO / 'docs/verification/stability-published-physical-source-review-20260913-1.json'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def identity(path):
    return {'path': str(path), 'size_bytes': path.stat().st_size, 'sha256': digest(path)}


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def inventory(root):
    rows = []
    for path in [root, *sorted(root.rglob('*'))]:
        info = path.lstat()
        kind = 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else None
        if kind is None:
            raise ValueError('unsupported source-capture member: ' + str(path))
        row = {'relative': str(path.relative_to(root)) if path != root else '', 'type': kind,
               'mode': stat.S_IMODE(info.st_mode), 'size_bytes': info.st_size if kind == 'file' else 0}
        if kind == 'file': row['sha256'] = digest(path)
        rows.append(row)
    return rows


PEER = Path('/tmp/stability-published-physical-independent-review-20260913-b86g2o2g')
EXPECTED_PEER = 'a51cc691921f02320911f947551ba01fea3575d11604ce89c7e2eefd30062d15'
for path in (ARCHIVE, MEMBERS, PUBLICATION, CAPTURE / 'archive-helper.py', CAPTURE / 'author-review.json', CAPTURE / PEER.name):
    if path.exists(): raise FileExistsError(path)
freeze = json.loads((CAPTURE / 'freeze.json').read_text())
for item in freeze['source_inputs']:
    for name in ('path', 'retained'):
        path = Path(item[name])
        assert path.stat().st_size == item['size_bytes'] and digest(path) == item['sha256'], str(path)
assert digest(PEER / 'review.json') == EXPECTED_PEER
peer_rows = inventory(PEER)
assert len(peer_rows) <= 512 and sum(row['size_bytes'] for row in peer_rows) <= 16 * 1024 * 1024
shutil.copytree(PEER, CAPTURE / PEER.name, copy_function=shutil.copy2)
assert inventory(PEER) == inventory(CAPTURE / PEER.name)
author = {'schema_version': 1, 'kind': 'published-physical-author-source-review',
          'status': 'PASS_SOURCE_REVIEW_ONLY_NOT_RUN', 'source_inputs': freeze['source_inputs'],
          'peer_review': identity(PEER / 'review.json'), 'peer_capture': str(PEER),
          'static_literal_review': identity(CAPTURE / 'static-literal-review.json'),
          'test_methods': freeze['test_methods'], 'test_method_count': 18,
          'test_executions': 0, 'subject_imports': 0, 'guest_executions': 0, 'physical_reads': 0,
          'application_acceptance': False, 'transport_acceptance': False,
          'production_gate_credit': False, 'base_comparator_unchanged': True,
          'acceptance_scope': 'retained-byte source comparison only; no actual capture or execution'}
save(CAPTURE / 'author-review.json', author)
shutil.copy2(Path(__file__), CAPTURE / 'archive-helper.py')
rows = inventory(CAPTURE)
assert len(rows) <= 4096 and sum(row['size_bytes'] for row in rows) <= 95 * 1024 * 1024
with ARCHIVE.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz', format=tarfile.PAX_FORMAT) as archive:
        for row in rows:
            source = CAPTURE / row['relative']
            name = 'source-capture' + ('/' + row['relative'] if row['relative'] else '')
            archive.add(source, arcname=name, recursive=False)
            row['archive_member'] = name
    output.flush(); os.fsync(output.fileno())
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(rows)
    for member, expected in zip(actual, rows):
        assert member.name == expected['archive_member']
        assert stat.S_IMODE(member.mode) == expected['mode']
        assert member.isdir() if expected['type'] == 'directory' else member.isfile()
        assert member.size == expected['size_bytes']
        if member.isfile():
            h = hashlib.sha256()
            with archive.extractfile(member) as stream:
                for chunk in iter(lambda: stream.read(1048576), b''): h.update(chunk)
            assert h.hexdigest() == expected['sha256'], member.name
assert inventory(CAPTURE) == [{key: value for key, value in row.items() if key != 'archive_member'} for row in rows]
for item in freeze['source_inputs']:
    assert Path(item['path']).stat().st_size == item['size_bytes'] and digest(Path(item['path'])) == item['sha256']
assert inventory(PEER) == inventory(CAPTURE / PEER.name)
save(MEMBERS, {'schema_version': 1, 'kind': 'complete-source-archive-members',
               'archive': identity(ARCHIVE), 'original_root': str(CAPTURE),
               'member_count': len(rows), 'all_members_verified': True, 'members': rows})
publication = {
    'schema_version': 1, 'kind': 'published-physical-source-review', 'status': 'PASS_SOURCE_REVIEW_ONLY_NOT_RUN',
    'source_inputs': [{key: value for key, value in item.items() if key != 'retained'} for item in freeze['source_inputs']],
    'documentation': identity(REPO / 'docs/verification/stability-published-physical-comparison-20260913.md'),
    'author_review': identity(CAPTURE / 'author-review.json'), 'peer_review': identity(PEER / 'review.json'),
    'archive': identity(ARCHIVE), 'members_manifest': identity(MEMBERS), 'original_capture_root': str(CAPTURE),
    'member_count': len(rows), 'all_member_types_modes_bytes_verified': True,
    'source_review_findings': [], 'base_comparator_unchanged': True,
    'supported_comparisons': ['BlockedRead_to_AcceptedReturn_prepared40_prefix', 'one_selected_wake_in_complete501_publication_interval'],
    'successful_helper_status': 'PHYSICAL_BYTES_MATCH_ONLY', 'test_method_count': 18,
    'test_executions': 0, 'subject_imports': 0, 'compiler_executions': 0, 'guest_executions': 0, 'physical_reads': 0,
    'application_acceptance': False, 'transport_acceptance': False, 'production_gate_credit': False,
    'remaining_gates': ['parent pinned18 literal tests with raw wait/streams/cleanup/evidence',
                        'actual source/image/module/request/OS-generation/queue identity joins',
                        'typed AcceptedReturn ownership and no selected-response read after possible release',
                        'actual stopped QMP captures plus verified resume and full phase timing',
                        'native RET/owner/physical/controller mode-specific review'],
}
save(PUBLICATION, publication)
save(PACK / 'result.json', {'publication': identity(PUBLICATION), 'archive': identity(ARCHIVE),
                           'members': identity(MEMBERS), 'member_count': len(rows),
                           'source_input_count': len(freeze['source_inputs'])})
print(json.dumps(json.loads((PACK / 'result.json').read_text()), indent=2))
