from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
prior = Path('/work/mckernel-native-irq-images-20260907-11')
out = Path('/work/native-ikc-completion-images-validation-20260907-' + sys.argv[1])
out.mkdir()
source = prior / 'source'
old = json.loads((prior / 'record.json').read_text())
assert old['status'] == 'PASS'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

record = dict(started_utc=datetime.now(timezone.utc).isoformat(), source_parent=old['source_parent'],
              inputs=[], commands=[], production_gate_credit=False, mckernel_boot_proven=False,
              scope='Verify image build 11 with revision-2 queue capability and retained revision-1 load compatibility')
for item in old['production_inputs'] + old['source_overlays']:
    assert identity(Path(item['path'])) == item, item
    record['inputs'].append(item)
for label in ('fallback', 'legacy-rust', 'native-rust'):
    for name in ('mckernel.img', 'mckernel.img.map'):
        record['inputs'].append(identity(prior / label / 'kernel' / name))
record['inputs'].append(identity(prior / 'native-rust/kernel/rust/mckernel_rust.o'))
shutil.copyfile(__file__, out / 'helper.py')

def run(label, command):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text())

try:
    binary = out / 'native-boot-note.bin'
    run('extract-note', ['objcopy', '--dump-section', '.note.mckernel.boot=' + str(binary), str(prior / 'native-rust/kernel/mckernel.img'), str(out / 'objcopy-output.img')])
    expected = struct.pack('<3I12s4I', 9, 16, 0x4d434b01, b'MCKERNEL' + bytes([0]) * 4, 2, 0x00060c00, 7616, 1)
    assert binary.read_bytes() == expected
    record['note'] = dict(binary=identity(binary), words=[2, 0x00060c00, 7616, 1])
    parser = out / 'parse-images.rs'
    modules = '\n'.join('#[path = "' + str(source / 'host-kernel/native-rust' / (name + '.rs')) + '"] mod ' + name + ';'
                        for name in ('ihk_mapping', 'smp_resource', 'smp_image'))
    parser.write_text('''#![allow(dead_code)]
''' + modules + '''
fn main() {
    use smp_resource::*;
    use smp_image::*;
    let owner = OsToken::test_only(0, 1).unwrap();
    let mut map = MemoryMap::<16>::new();
    let mut slots = [None; 16];
    let mut workspace = MemoryWorkspace::new(&mut slots).unwrap();
    map.insert_free(0x4000_0000, 64 << 20, 0, &mut workspace).unwrap();
    let extent = MemoryExtent::new(0x4000_0000, 64 << 20, 0, None).unwrap();
    let mut assignment = map.prepare_assign_batch(owner, &[extent], &mut workspace).unwrap();
    assignment.begin_external_effects().unwrap(); assignment.commit().unwrap();
    let layout = BootLayout::select(&map, owner).unwrap();
    for (index, path) in std::env::args().skip(1).enumerate() {
        let image = std::fs::read(&path).unwrap();
        let plan = ImagePlan::parse(&image, layout).unwrap();
        assert_eq!(plan.native_boot_abi(), if index >= 2 {
            Some(NativeBootAbi { header_bytes: 7616, performance: true, completed_queue_reads: index == 2 })
        } else { None });
        let mut memory = vec![0u8; KERNEL_WINDOW_BYTES as usize];
        for segment in plan.segments() {
            let offset = (segment.destination - layout.kernel().start()) as usize;
            memory[offset..offset + segment.file.len()].copy_from_slice(segment.file);
        }
        let checksum = memory.iter().fold(0xcbf29ce484222325u64,
            |old, byte| (old ^ *byte as u64).wrapping_mul(0x100000001b3));
        println!("IMAGE index={index} segments={} entry={:x} loaded_checksum={checksum:016x} native_abi={:?}",
                 plan.load_segments(), plan.entry(), plan.native_boot_abi());
    }
}
''')
    run('compile-parser', ['rustc', '--edition=2021', '--cfg', 'test', '-Dwarnings', str(parser), '-o', str(out / 'parse-images')])
    retained_v1 = Path('/work/mckernel-native-irq-images-20260907-10/native-rust/kernel/mckernel.img')
    record['inputs'].append(identity(retained_v1))
    run('parse-images', [str(out / 'parse-images')] + [str(prior / label / 'kernel/mckernel.img') for label in ('fallback', 'legacy-rust', 'native-rust')] + [str(retained_v1)])
    run('native-linked-ownership', ['python3', str(source / 'scripts/mckernel_linked_text_ownership.py'),
        '--image', str(prior / 'native-rust/kernel/mckernel.img'), '--link-map', str(prior / 'native-rust/kernel/mckernel.img.map'),
        '--rust-object', str(prior / 'native-rust/kernel/rust/mckernel_rust.o'), '--source-commit', old['source_parent'],
        '--output', str(out / 'native-linked-ownership.json')])
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item, item
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name != 'record.json']
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
