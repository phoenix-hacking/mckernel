"""Read-only retained data/source audit; no subject imports or subprocesses."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import stat
import struct

OUT = Path(__file__).resolve().parent
WORK = Path('/home/holden/mckernel-work/scratch')
REPO = Path('/home/holden/mckernel')
LIMIT = 128 * 1024 * 1024
verified, findings, unavailable, retained = [], [], [], {}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def path(value):
    if value.startswith('/work/'):
        return WORK / value[6:]
    if value.startswith('/workspace/'):
        return REPO / value[11:]
    return None


def identity(p):
    before = p.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= LIMIT, 'nonregular/large identity')
    digest = hashlib.sha256()
    n = 0
    with p.open('rb') as stream:
        while True:
            data = stream.read(65536)
            if not data:
                break
            n += len(data)
            require(n <= LIMIT, 'identity grew')
            digest.update(data)
    after = p.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'identity changed')
    return {'path': str(p), 'size': n, 'sha256': digest.hexdigest()}


def same(a, b):
    return all(a[k] == b[k] for k in ('size', 'sha256'))


def check(row, label, override=None):
    p = override if override is not None else path(row['path'])
    if p is None:
        unavailable.append({'label': label, 'recorded': row, 'reason': 'Pinned container path; no host substitute or container execution.'})
        return
    actual = identity(p)
    matched = same(actual, row)
    verified.append({'label': label, 'recorded': row, 'observed': actual, 'matches': matched})
    if not matched:
        findings.append(verified[-1])


def keep(p):
    key = str(p)
    if key in retained:
        return
    got = identity(p)
    require(got['size'] <= 4 * 1024 * 1024, 'retained source/record bound')
    rel = p.relative_to(WORK) if p.is_relative_to(WORK) else Path('repository') / p.relative_to(REPO)
    target = OUT / 'inputs' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, target)
    require(same(identity(target), got), 'source retention changed')
    retained[key] = {'original': got, 'retained': identity(target)}


def load(p):
    keep(p)
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'duplicate JSON key')
            result[k] = v
        return result
    return json.loads(p.read_bytes(), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


names = {
    'guest': 'stability-transport-fault-guest-20260913-permanent-backpressure-2',
    'run': 'stability-transport-fault-run-20260913-permanent-backpressure-2',
    'prepared': 'stability-fault-guest-root-20260913-permanent-backpressure-2',
    'module': 'stability-transport-fault-module-20260913-permanent-backpressure-1',
    'controller': 'stability-owner-terminal-controller-build-20260913-1',
    'payload': 'stability-runnable-thread-payload-build-20260913-1',
}
records = {name: load(WORK / directory / 'record.json') for name, directory in names.items()}
guest = WORK / names['guest']
prepared = records['prepared']
root = path(prepared['root'])
snapshots = {}
for row in records['run']['inputs']:
    check(row['retained'], 'run:retained-input')
    require(same(row['original'], row['retained']), 'run source-copy mismatch')
    snapshots[row['original']['path']] = path(row['retained']['path'])
    keep(path(row['retained']['path']))
for label in ('guest', 'prepared'):
    for row in records[label]['inputs']:
        check(row, label + ':input', snapshots.get(row['path']))
        if row['path'].endswith('/record.json') and path(row['path']) is not None:
            keep(path(row['path']))
for label in ('guest', 'run'):
    keep(WORK / names[label] / 'helper.py')
for p in sorted((guest / 'source').iterdir()):
    keep(p)
    expected = next((r for r in records['guest']['inputs'] if
                     Path(r['path']).name == p.name or p.name == 'owner-contract.json' and '/contracts/' in r['path']), None)
    require(expected is not None, 'unmapped guest source snapshot')
    check(expected, 'guest:actual-source-snapshot', p)
runner = identity(guest / 'helper.py')
require(runner['sha256'] == '35095ee65a57638c93179e20433c68ce9688978f201317a0b1cd98ab591ec50e', 'runner freeze differs')
require(identity(guest / 'source/prepare_stability_fault_guest.py')['sha256'] == '0b45f00a6ed72b8b55b25f27261650e14b32e43e398ee2005ffeb5a16ac78d82', 'preparer freeze differs')

command_checks = []
for label in ('module', 'controller', 'payload'):
    record = records[label]
    require(record['status'] == 'PASS_BUILD_ONLY', 'build is not passing')
    for command in record['commands']:
        collection = command.get('collection')
        if collection is None:
            continue
        ok = collection['status'] == 'COMPLETED' and collection['raw_wait_status'] == 0 and collection['cleanup_complete']
        command_checks.append({'build': label, 'label': command['label'], 'argv': command['argv'], 'raw_wait': collection['raw_wait_status'], 'complete_and_clean': ok})
        require(ok, 'nonpassing retained compile command')
        for stream in collection['streams'].values():
            check(stream['artifact'], label + ':command-stream')
            require(stream['eof'] and not stream['truncated'] and stream['discarded_observed_bytes'] == 0, 'incomplete compiler log')
    if label == 'module':
        continue
    for row in record['inputs']:
        check(row['retained'], label + ':retained-source')
        require(same(row['original'], row['retained']), 'compiler source-copy mismatch')
        keep(path(row['retained']['path']))
    for row in record['compiled_outputs']:
        check(row, label + ':compiled-output')
    for row in record['loader_dependencies']:
        check(row, label + ':prepared-loader', root / row['path'].lstrip('/'))
    for row in record['compiler_dependencies']:
        check(row, label + ':compiler-dependency')
require(records['controller']['controller_source']['sha256'] == '7b1115f4c744d32bb085f23b515e35bcfab4cf0efa6f2e3cb5827742876511e2', 'controller source differs')
require(records['payload']['payload_source']['sha256'] == 'dbc68dc4e981c0ed3433491747b4dcd7a031548fbd84bddbd8e98361d4681491', 'payload source differs')

module = records['module']
require(module['mode'] == 'permanent-backpressure' and module['verification_only'] and module['shared_production_trees_restored'], 'module profile differs')
compiler = {r['path']: r for r in module['compiler_inputs']}
require(len(compiler) == len(module['retained_compiler_bindings']) == 63, 'compiler binding inventory differs')
for row in module['retained_compiler_bindings']:
    check(row['retained'], 'module:actual-retained-compiler-source')
    require(same(row['retained'], compiler[row['historical_compile_path']]), 'compiler historical/retained binding differs')
    keep(path(row['retained']['path']))
for field in ('fixture_inputs', 'parent_inputs', 'compiled_modules', 'overlays'):
    for row in module[field]:
        check(row, 'module:' + field)
        if field != 'compiled_modules':
            keep(path(row['path']))
for row in (module['build_command_input'], module['parent_record']):
    check(row, 'module:parent-and-command')
    keep(path(row['path']))
for row in prepared['bindings']:
    check(row['prepared'], 'root:prepared-copy')
    for original in [row['original']] if 'original' in row else row['compiler_outputs']:
        check(original, 'root:copy-source')
        require(same(original, row['prepared']), 'root source/copy differs')
check(prepared['accepted_baseline_initramfs'], 'baseline:accepted-initramfs')


def newc(p):
    members = {}
    position = 0
    digest = hashlib.sha256()
    def take(stream, n):
        nonlocal position
        require(n <= LIMIT - position, 'newc expanded byte bound')
        raw = stream.read(n)
        require(len(raw) == n, 'newc short read')
        position += n
        digest.update(raw)
        return raw
    with gzip.open(p, 'rb') as stream:
        for unused in range(256):
            raw = take(stream, 110)
            require(raw[:6] == b'070701' and all(c in b'0123456789abcdefABCDEF' for c in raw[6:]), 'newc header')
            words = [int(raw[6 + 8*i:14 + 8*i], 16) for i in range(13)]
            mode, uid, gid, size, namesize = words[1], words[2], words[3], words[6], words[11]
            require(1 <= namesize <= 4096 and size <= 64 * 1024 * 1024, 'newc member bound')
            rawname = take(stream, namesize)
            require(rawname.endswith(b'\0') and b'\0' not in rawname[:-1], 'newc name')
            name = rawname[:-1].decode('utf8')
            require(not any(take(stream, (-position) % 4)), 'newc name padding')
            content = hashlib.sha256()
            remaining = size
            link = b''
            while remaining:
                data = take(stream, min(remaining, 65536))
                content.update(data)
                if stat.S_ISLNK(mode):
                    require(size <= 4096, 'newc symlink bound')
                    link += data
                remaining -= len(data)
            require(not any(take(stream, (-position) % 4)), 'newc data padding')
            if name == 'TRAILER!!!':
                require(size == 0, 'nonempty newc trailer')
                tail = stream.read(512)
                require(len(tail) <= 511 and not any(tail) and not stream.read(1), 'newc trailing data')
                digest.update(tail); position += len(tail)
                break
            require(name and not name.startswith('/') and all(v not in ('', '.', '..') for v in name.split('/')), 'noncanonical newc path')
            require(name not in members, 'duplicate newc path')
            row = {'path': name, 'mode': stat.S_IMODE(mode), 'uid': uid, 'gid': gid, 'native_mode': mode,
                   'size': size, 'sha256': content.hexdigest(), 'rdev_major': words[9], 'rdev_minor': words[10]}
            if stat.S_ISLNK(mode): row['target'] = link.decode('utf8')
            members[name] = row
        else:
            raise ValueError('newc member cap/no trailer')
    return members, {'decompressed_size': position, 'decompressed_sha256': digest.hexdigest()}


archive = guest / 'initramfs.cpio.gz'
members, archive_data = newc(archive)
baseline_members, baseline_archive_data = newc(path(prepared['accepted_baseline_initramfs']['path']))
require(same({'size': archive_data['decompressed_size'], 'sha256': archive_data['decompressed_sha256']}, identity(guest / 'initramfs-cpio.stdout')), 'gzip does not contain retained original newc bytes')
qemu = records['guest']['qemu_args']
require(qemu.count('-initrd') == 1 and path(qemu[qemu.index('-initrd') + 1]) == archive, 'QEMU initrd identity not joined')
require(qemu.count('-kernel') == 1 and path(qemu[qemu.index('-kernel') + 1]) == path(next(r for r in records['guest']['inputs'] if r['path'].endswith('/bzImage'))['path']), 'QEMU kernel not joined')


def archive_match(record, actual):
    if actual is None or actual['mode'] != record['mode'] or actual['uid'] != 0 or actual['gid'] != 0:
        return False
    if record['kind'] == 'file': return stat.S_ISREG(actual['native_mode']) and same(record, actual)
    if record['kind'] == 'directory': return stat.S_ISDIR(actual['native_mode']) and actual['size'] == 0
    if record['kind'] == 'symlink': return stat.S_ISLNK(actual['native_mode']) and actual['target'] == record['target']
    return False


root_checks = []
actual_paths = {str(p.relative_to(root)) for p in root.rglob('*')}
require(actual_paths == {r['path'] for r in prepared['root_inventory']}, 'prepared root has extra/missing entries')
for row in prepared['root_inventory']:
    p = root / row['path']; info = p.lstat()
    got = {'path': row['path'], 'mode': stat.S_IMODE(info.st_mode)}
    if stat.S_ISREG(info.st_mode): got.update(kind='file', **{k:v for k,v in identity(p).items() if k != 'path'})
    elif stat.S_ISDIR(info.st_mode): got.update(kind='directory')
    elif stat.S_ISLNK(info.st_mode): got.update(kind='symlink', target=os.readlink(p))
    else: got.update(kind='unsupported')
    root_ok = got == row; cpio_ok = archive_match(row, members.get(row['path']))
    root_checks.append({'recorded': row, 'actual_root_matches': root_ok, 'actual_qemu_newc_matches': cpio_ok})
    require(root_ok and cpio_ok, 'root/newc inventory differs: ' + row['path'])
for table, inventory in ((members, prepared['root_inventory']), (baseline_members, prepared['baseline_root_inventory'])):
    require(set(table) == {r['path'] for r in inventory} | {'dev/console', 'dev/null'}, 'newc member inventory has extras/omissions')
    for row in inventory:
        require(archive_match(row, table.get(row['path'])), 'accepted/archive inventory mismatch')
    for name, mode, major, minor in [('dev/console', 0o600, 5, 1), ('dev/null', 0o666, 1, 3)]:
        row = table[name]
        require(stat.S_ISCHR(row['native_mode']) and row['mode'] == mode and row['rdev_major'] == major and row['rdev_minor'] == minor and row['uid'] == row['gid'] == row['size'] == 0, 'newc device mismatch')
changes = []
for row in prepared['baseline_root_inventory']:
    current = next(v for v in prepared['root_inventory'] if v['path'] == row['path'])
    if current != row: changes.append(row['path'])
require('init' in changes and set(changes) <= {'init', 'modules/ihk.ko', 'modules/ihk-smp-x86_64.ko', 'modules/mcctrl.ko'}, 'unexpected baseline changes')
for p in [guest / 'initramfs.list', guest / 'cpio-spec-helper.py', root / 'init',
          guest / 'guest-artifacts/files/boot-identity.txt', guest / 'guest-artifacts/files/linux/argv.nul',
          guest / 'guest-artifacts/files/mckernel/argv.nul']:
    keep(p)
require(prepared['mode'] == records['guest']['mode'] == records['run']['mode'] == 'permanent-backpressure', 'mode binding differs')
require(prepared['nonce'] == records['guest']['nonce'] and prepared['payload_profile'] == 'runnable-thread-v1' and prepared['controller_profile'] == 'owner-phase-v2', 'attempt/profile binding differs')
check(records['run']['guest_record'], 'run:actual-guest-record')
check(records['run']['verification_module'], 'run:actual-module-record')
require(not findings, 'one or more recorded identities differ')
result = {'schema_version': 1, 'status': 'PASS_BOUNDED_SOURCE_BINARY_ROOT_BINDING_REVIEW_ONLY',
          'scope': 'Retained-byte/source/metadata audit only; no subject imports, tests, compilers, containers or guests. Runtime outcome/physical/owners remain Completion review.',
          'mode': 'permanent-backpressure', 'guest': names['guest'], 'runner': runner,
          'verified_identities': verified, 'root_inventory_checks': root_checks,
          'actual_qemu_newc': {'artifact': identity(archive), **archive_data, 'members': list(members.values())},
          'accepted_baseline_newc': {'artifact': identity(path(prepared['accepted_baseline_initramfs']['path'])), **baseline_archive_data, 'member_count': len(baseline_members)},
          'baseline_changed_paths': changes, 'retained_module_compiler_bindings': 63,
          'build_command_checks': command_checks, 'definite_findings': findings,
          'unavailable_container_only_inputs': unavailable, 'retained_sources_and_records': list(retained.values()),
          'complete_compiler_closure_revalidated': False, 'actual_runtime_acceptance': False,
          'application_acceptance': False, 'production_gate_credit': False}
with (OUT / 'review.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({'review': identity(OUT / 'review.json'), 'verified_identities': len(verified),
                  'root_entries': len(root_checks), 'newc_members': len(members), 'baseline_members': len(baseline_members),
                  'retained_sources_records': len(retained), 'unavailable_container_inputs': len(unavailable)}, indent=2))
