from pathlib import Path
import hashlib,json,stat,tarfile
root=Path(__file__).resolve().parent
repo=Path('/home/holden/mckernel')
archive=repo/'docs/verification/evidence/stability-permanent-backpressure-independent-review-20260913.tar.gz'
manifest=repo/'docs/verification/stability-permanent-backpressure-independent-review-20260913.json'
assert not archive.exists() and not manifest.exists()
rows=[]
for p in [root]+sorted(root.rglob('*')):
 s=p.lstat();kind='directory'if stat.S_ISDIR(s.st_mode)else'file'if stat.S_ISREG(s.st_mode)else None
 assert kind is not None,p
 rows.append(dict(member=p.relative_to(root.parent).as_posix(),kind=kind,mode=stat.S_IMODE(s.st_mode),size=s.st_size if kind=='file'else 0,sha256=hashlib.sha256(p.read_bytes()).hexdigest()if kind=='file'else None))
with tarfile.open(archive,'x:gz')as t:
 for row in rows:t.add(root.parent/row['member'],arcname=row['member'],recursive=False)
with tarfile.open(archive,'r:gz')as t:
 members=t.getmembers();assert [m.name for m in members]==[r['member']for r in rows]
 for m,row in zip(members,rows):
  assert m.mode==row['mode'] and m.size==row['size'] and (m.isdir()if row['kind']=='directory'else m.isfile())
  if m.isfile():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==row['sha256']==hashlib.sha256((root.parent/row['member']).read_bytes()).hexdigest()
assessment=json.loads((root/'assessment.json').read_bytes())
dictout=dict(schema_version=1,status=assessment['status'],permanent_backpressure_mode_verified=True,controller_infrastructure_verified=False,application_acceptance=False,whole_transport_gate_verified=False,production_gate_credit=False,physical_full_ring_verified=False,original_guest_record_sha256=assessment['guest_record_sha256'],archive=dict(path=str(archive),size=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),assessment=dict(member=root.name+'/assessment.json',sha256=hashlib.sha256((root/'assessment.json').read_bytes()).hexdigest()),all_members_bytes_types_modes_and_membership_verified=True,members=rows)
manifest.write_text(json.dumps(dictout,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(manifest=str(manifest),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),archive=dictout['archive'],members=len(rows))))
