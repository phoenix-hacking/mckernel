from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-sysfs-service-ownership-tests-20260908-' + sys.argv[1]); out.mkdir()
source = out / 'source'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', commands=[],
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    scope='Exact production extent/alias/reply bodies with a recorded setup callback; real Linux publication requires the separate guest fixture',
    production_gate_credit=False, sysfs_service_completed=False)
def identity(path):
    data=path.read_bytes(); return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def run(name,args):
    print('RUN',name,flush=True)
    with (out/(name+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=name,command=args,exit_code=result.returncode))
    assert result.returncode == 0, (name,(out/(name+'.log')).read_text()[-12000:])
def extract(path,signature):
    text=path.read_text(); start=text.index(signature); opening=text.index('{',start); depth=1; end=opening+1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}'); end+=1
    body=text[start:end]
    record.setdefault('extracted_bodies',[]).append(dict(source=str(path),signature=signature,start_byte=len(text[:start].encode()),end_byte=len(text[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
    return body
try:
    shutil.copyfile(__file__,out/'helper.py')
    inputs=['host-kernel/native-rust/'+name for name in ['abi/sysfs.rs','abi/vdso.rs','smp_resource.rs','smp_memory.rs','sysfs_setup.rs']]
    inputs.append('scripts/tests/fixtures/mckernel_native_sysfs_ownership.rs')
    for name in inputs:
        target=source/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(repo/name,target)
    record['inputs']=[identity(source/name) for name in inputs]
    generated='#![allow(dead_code)]\nextern crate self as kernel;\n'
    for name,path in [('sysfs_protocol','abi/sysfs.rs'),('vdso_protocol','abi/vdso.rs'),('smp_resource','smp_resource.rs')]:
        generated+='#[path = '+json.dumps(str(source/'host-kernel/native-rust'/path))+'] mod '+name+';\n'
    generated+='''
pub mod error {
    #[derive(Clone, Copy, Debug, Eq, PartialEq)] pub struct Error(pub i32);
    impl Error { pub fn to_errno(self) -> i32 { self.0 } }
    pub fn to_result(code: i32) -> Result<(), Error> { if code < 0 { Err(Error(code)) } else { Ok(()) } }
}
mod smp_ikc { pub const CONTROL_QUEUE_BYTES: usize = 16384; }
mod sysfs_setup {
    use super::{error::Error, smp_resource::OsToken};
    pub struct SharedData { pub owner: OsToken, pub physical: u64, pub address: u64, pub bytes: usize }
    #[derive(Default)] pub struct Service { pub data: Option<SharedData>, pub fail: Option<Error>, pub calls: usize }
    impl Service {
        pub fn setup(&mut self, data: SharedData) -> Result<usize, Error> {
            self.calls += 1;
            if self.data.is_some() { return Err(Error(-16)); }
            if let Some(error) = self.fail { return Err(error); }
            self.data = Some(data); Ok(99)
        }
'''
    generated+=extract(source/'host-kernel/native-rust/sysfs_setup.rs','pub(crate) fn overlaps(')+'\n}}\n'
    generated+='''
mod memory {
    use super::smp_resource::MemoryMap;
    type Result<T = ()> = core::result::Result<T, kernel::error::Error>;
    const EINVAL: kernel::error::Error = kernel::error::Error(-22);
    const EIO: kernel::error::Error = kernel::error::Error(-5);
    const MAX_EXTENTS: usize = 16;
    const IDENTITY_WINDOW_END: u64 = 256 << 30;
    struct FakeChannel { owner: super::smp_resource::OsToken, receive_physical: u64, send_physical: u64 }
    struct OwnedControlChannel { channel: FakeChannel }
    macro_rules! pr_info { ($($argument:tt)*) => { let _ = format_args!($($argument)*); }; }
'''
    for name in ['trait GuestExtents', 'impl<const N: usize> GuestExtents for MemoryMap<N>', 'impl GuestExtents for [MemoryExtent]', 'fn checked_guest_bytes(', 'fn reply_sysfs_setup(']:
        generated+=extract(source/'host-kernel/native-rust/smp_memory.rs',name)+'\n'
    generated+=(source/inputs[-1]).read_text()+'\n}\n'
    (out/'ownership.rs').write_text(generated)
    run('ownership-build',['rustc','--edition=2021','--test','-Dwarnings','-O',str(out/'ownership.rs'),'-o',str(out/'ownership')])
    run('ownership-tests',[str(out/'ownership'),'setup_','--test-threads=1','--nocapture'])
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error)); raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name!='record.json']
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
