#![allow(dead_code)]
extern crate self as kernel;
#[path = "/work/native-sysfs-service-ownership-tests-20260908-1/source/host-kernel/native-rust/abi/sysfs.rs"] mod sysfs_protocol;
#[path = "/work/native-sysfs-service-ownership-tests-20260908-1/source/host-kernel/native-rust/abi/vdso.rs"] mod vdso_protocol;
#[path = "/work/native-sysfs-service-ownership-tests-20260908-1/source/host-kernel/native-rust/smp_resource.rs"] mod smp_resource;

pub mod error {
    #[derive(Clone, Copy, Debug, Eq, PartialEq)] pub struct Error(pub i32);
    impl Error { pub fn to_errno(self) -> i32 { self.0 } }
    pub fn to_result(code: i32) -> Result<(), Error> { if code < 0 { Err(Error(code)) } else { Ok(()) } }
}
mod smp_ikc { pub const CONTROL_QUEUE_BYTES: usize = 16384; }
mod sysfs_setup {
    use super::{error::Error, smp_resource::OsToken};
    pub struct SharedData { pub owner: OsToken, pub physical: u64, pub address: u64, pub bytes: usize }
    #[derive(Default)] pub struct Service { pub data: Option<SharedData>, pub fail: Option<Error>, pub calls: usize }
    impl Service {
        pub fn setup(&mut self, data: SharedData) -> Result<usize, Error> {
            self.calls += 1;
            if self.data.is_some() { return Err(Error(-16)); }
            if let Some(error) = self.fail { return Err(error); }
            self.data = Some(data); Ok(99)
        }
pub(crate) fn overlaps(&self, physical: u64, bytes: usize) -> bool {
        self.data.as_ref().is_some_and(|data| {
            physical.checked_add(bytes as u64).is_none_or(|end| {
                physical < data.physical + data.bytes as u64 && data.physical < end
            })
        })
    }
}}

mod memory {
    use super::smp_resource::MemoryMap;
    type Result<T = ()> = core::result::Result<T, kernel::error::Error>;
    const EINVAL: kernel::error::Error = kernel::error::Error(-22);
    const EIO: kernel::error::Error = kernel::error::Error(-5);
    const MAX_EXTENTS: usize = 16;
    const IDENTITY_WINDOW_END: u64 = 256 << 30;
    struct FakeChannel { owner: super::smp_resource::OsToken, receive_physical: u64, send_physical: u64 }
    struct OwnedControlChannel { channel: FakeChannel }
    macro_rules! pr_info { ($($argument:tt)*) => { let _ = format_args!($($argument)*); }; }
trait GuestExtents {
    fn len(&self) -> usize;
    fn extent(&self, index: usize) -> Option<MemoryExtent>;
}
impl<const N: usize> GuestExtents for MemoryMap<N> {
    fn len(&self) -> usize {
        MemoryMap::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        MemoryMap::extent(self, index)
    }
}
impl GuestExtents for [MemoryExtent] {
    fn len(&self) -> usize {
        <[MemoryExtent]>::len(self)
    }
    fn extent(&self, index: usize) -> Option<MemoryExtent> {
        self.get(index).copied()
    }
}
fn checked_guest_bytes(
    map: &(impl GuestExtents + ?Sized),
    owner: super::smp_resource::OsToken,
    direct_map: u64,
    physical: u64,
    bytes: usize,
) -> Result<*mut u8> {
    let end = physical.checked_add(bytes as u64).ok_or(EINVAL)?;
    if physical == 0 || bytes == 0 || end > IDENTITY_WINDOW_END {
        return Err(EINVAL);
    }
    direct_map.checked_add(end - 1).ok_or(EINVAL)?;
    for index in 0..map.len() {
        let extent = map.extent(index).ok_or(EIO)?;
        if extent.owner() == Some(owner)
            && extent.start() <= physical
            && end <= extent.end().map_err(|_| EIO)?
        {
            return Ok(direct_map.checked_add(physical).ok_or(EINVAL)? as *mut u8);
        }
    }
    Err(EINVAL)
}
fn reply_sysfs_setup(
    map: &MemoryMap<MAX_EXTENTS>,
    owner: super::smp_resource::OsToken,
    direct_map: u64,
    physical: u64,
    master_receive: u64,
    master_send: u64,
    master_bytes: usize,
    channels: &[OwnedControlChannel],
    vdso_request: u64,
    service: &mut super::sysfs_setup::Service,
) -> Result {
    use super::sysfs_protocol as wire;
    let checked = |physical: u64, bytes: usize| -> Result<*mut u8> {
        let pointer = checked_guest_bytes(map, owner, direct_map, physical, bytes)?;
        let end = physical + bytes as u64;
        for (start, size) in [
            (master_receive, master_bytes),
            (master_send, master_bytes),
            (vdso_request, super::vdso_protocol::BYTES),
        ] {
            if start == 0 || physical < start + size as u64 && start < end {
                return Err(EINVAL);
            }
        }
        for entry in channels {
            if entry.channel.owner != owner {
                return Err(EIO);
            }
            for start in [entry.channel.receive_physical, entry.channel.send_physical] {
                if physical < start + super::smp_ikc::CONTROL_QUEUE_BYTES as u64 && start < end {
                    return Err(EINVAL);
                }
            }
        }
        if service.overlaps(physical, bytes) {
            return Err(EINVAL);
        }
        Ok(pointer)
    };
    if physical % 8 != 0 {
        return Err(EINVAL);
    }
    let request = checked(physical, wire::SETUP_BYTES)?;
    let outcome = (|| {
        // SAFETY: The checked complete request is disjoint from live queues
        // and retained data. Queue publication synchronizes the guest writer.
        let (buffer_physical, bytes) = unsafe { wire::read_setup(request) }
            .map_err(|code| kernel::error::to_result(code).err().unwrap_or(EIO))?;
        let buffer = checked(buffer_physical, bytes)?;
        if physical < buffer_physical + bytes as u64
            && buffer_physical < physical + wire::SETUP_BYTES as u64
        {
            return Err(EINVAL);
        }
        Ok(super::sysfs_setup::SharedData {
            owner,
            physical: buffer_physical,
            address: buffer as u64,
            bytes,
        })
    })();
    let mut buffer_physical = 0;
    let result = outcome.and_then(|data| {
        buffer_physical = data.physical;
        service.setup(data)
    });
    let error = result.as_ref().err().map_or(0, |error| error.to_errno());
    // SAFETY: Setup has stored all successful owners or drained every partial
    // publication. This is the sole responder's last request access; its peer
    // may free/reuse the request immediately after the release-store to busy.
    unsafe { wire::complete_setup(request, error) }
        .map_err(|code| kernel::error::to_result(code).err().unwrap_or(EIO))?;
    let nodes = result?;
    pr_info!("IHK-SMP: sysfs setup replied os={} generation={} request={:x} buffer={:x} bytes={} nodes={} error=0 setup_completed=1\n",
        owner.slot(), owner.generation(), physical, buffer_physical, wire::DATA_BYTES, nodes);
    Ok(())
}
// SPDX-License-Identifier: GPL-2.0-only
// Included beside the exact production setup extent/reply bodies. The service
// callback is an effect recorder; Linux publication is checked in the real guest.
use super::smp_resource::{MemoryExtent, MemoryWorkspace, OsToken};
#[repr(align(4096))]
struct GuestStorage([u8; 65536]);
fn assigned_map(owner: OsToken) -> MemoryMap<MAX_EXTENTS> {
    let mut map = MemoryMap::new();
    let mut slots = [None; MAX_EXTENTS];
    let mut workspace = MemoryWorkspace::new(&mut slots).unwrap();
    map.insert_free(0x100000, 65536, 0, &mut workspace).unwrap();
    let extent = MemoryExtent::new(0x100000, 65536, 0, None).unwrap();
    let mut transaction = map.prepare_assign_batch(owner, &[extent], &mut workspace).unwrap();
    transaction.begin_external_effects().unwrap(); transaction.commit().unwrap();
    map
}
fn request(storage: &mut GuestStorage, buffer: u64, bytes: i64) {
    storage.0.fill(0xa5);
    storage.0[0xfc0..0xfc4].copy_from_slice(&(-115_i32).to_le_bytes());
    storage.0[0xfc8..0xfd0].copy_from_slice(&buffer.to_le_bytes());
    storage.0[0xfd0..0xfd8].copy_from_slice(&bytes.to_le_bytes());
    storage.0[0xfc0 + 1052..0xfc0 + 1056].copy_from_slice(&1_i32.to_le_bytes());
}
fn response(storage: &GuestStorage, before: &[u8; 65536], error: i32) {
    let mut expected = *before;
    expected[0xfc0..0xfc4].copy_from_slice(&error.to_le_bytes());
    expected[0xfc0 + 1052..0xfc0 + 1056].fill(0);
    assert_eq!(storage.0, expected);
}

#[test]
fn setup_checks_exact_generation_whole_extents_and_every_alias_before_writes() {
    let owner = OsToken::test_only(0, 1).unwrap();
    let stale = OsToken::test_only(0, 2).unwrap();
    let map = assigned_map(owner);
    let mut storage = Box::new(GuestStorage([0; 65536]));
    let direct = storage.0.as_mut_ptr() as u64 - 0x100000;
    let channels = [OwnedControlChannel { channel: FakeChannel {
        owner, receive_physical: 0x104000, send_physical: 0x10c000 } }];
    let mut service = super::sysfs_setup::Service::default();
    request(&mut storage, 0x102000, 4096);
    let before = storage.0;
    for physical in [0, 0x100fc1, 0x10ffc0, 0x120000, u64::MAX - 63,
        0x108008, 0x109008, 0x104008, 0x107fc0, 0x10c008, 0x10a008] {
        assert_eq!(reply_sysfs_setup(&map, owner, direct, physical, 0x108000, 0x109000,
            4096, &channels, 0x10a000, &mut service), Err(EINVAL));
        assert_eq!(storage.0, before); assert_eq!(service.calls, 0);
    }
    assert_eq!(reply_sysfs_setup(&map, stale, direct, 0x100fc0, 0x108000, 0x109000,
        4096, &channels, 0x10a000, &mut service), Err(EINVAL));
    assert_eq!(reply_sysfs_setup(&map, owner, u64::MAX - 0x100000 + 16, 0x100fc0,
        0x108000, 0x109000, 4096, &channels, 0x10a000, &mut service), Err(EINVAL));
    let wrong = [OwnedControlChannel { channel: FakeChannel {
        owner: stale, receive_physical: 0x104000, send_physical: 0x10c000 } }];
    assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
        4096, &wrong, 0x10a000, &mut service), Err(EIO));
    assert_eq!(storage.0, before); assert_eq!(service.calls, 0);
    for buffer in [0, 1, 0x100000, 0x101000, 0x104000, 0x107000, 0x108000,
        0x109000, 0x10a000, 0x10c000, 0x110000, u64::MAX & !4095] {
        request(&mut storage, buffer, 4096); let before = storage.0;
        assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
            4096, &channels, 0x10a000, &mut service), Err(EINVAL));
        response(&storage, &before, -22); assert_eq!(service.calls, 0);
    }
    for bytes in [-1, 0, 1, 4095, 4097, i64::MAX] {
        request(&mut storage, 0x102000, bytes); let before = storage.0;
        assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
            4096, &channels, 0x10a000, &mut service), Err(EINVAL));
        response(&storage, &before, -22); assert_eq!(service.calls, 0);
    }
}

#[test]
fn setup_retains_data_before_acknowledgement_and_preserves_it_on_duplicate() {
    let owner = OsToken::test_only(0, 1).unwrap(); let map = assigned_map(owner);
    let mut storage = Box::new(GuestStorage([0; 65536]));
    let direct = storage.0.as_mut_ptr() as u64 - 0x100000;
    let channels = [OwnedControlChannel { channel: FakeChannel {
        owner, receive_physical: 0x104000, send_physical: 0x10c000 } }];
    let mut service = super::sysfs_setup::Service::default();
    for error in [-12, -5] {
        service.fail = Some(kernel::error::Error(error));
        request(&mut storage, 0x102000, 4096); let before = storage.0;
        assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
            4096, &channels, 0x10a000, &mut service), Err(kernel::error::Error(error)));
        response(&storage, &before, error); assert!(service.data.is_none());
    }
    service.fail = None;
    request(&mut storage, 0x102000, 4096); let before = storage.0;
    reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
        4096, &channels, 0x10a000, &mut service).unwrap();
    response(&storage, &before, 0);
    let data = service.data.as_ref().unwrap();
    assert_eq!((data.owner, data.physical, data.address, data.bytes),
        (owner, 0x102000, direct + 0x102000, 4096));
    assert_eq!(service.calls, 3);
    assert!(service.overlaps(0x102000, 4096)); assert!(!service.overlaps(0x103000, 4096));
    let before = storage.0;
    assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x102000, 0x108000, 0x109000,
        4096, &channels, 0x10a000, &mut service), Err(EINVAL));
    assert_eq!(storage.0, before); assert_eq!(service.calls, 3);
    request(&mut storage, 0x103000, 4096); let before = storage.0;
    assert_eq!(reply_sysfs_setup(&map, owner, direct, 0x100fc0, 0x108000, 0x109000,
        4096, &channels, 0x10a000, &mut service), Err(kernel::error::Error(-16)));
    response(&storage, &before, -16);
    assert_eq!(service.data.as_ref().unwrap().physical, 0x102000);
}

}
