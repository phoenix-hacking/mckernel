from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-zeroing-patch-contract-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Frozen configuration replay and additive current-patch/license inventory regressions after exact swap_remove noreturn patch registration',inputs=[],commands=[])
def identity(path):return dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['scripts/rocky_kernel_config_resolution_v2.py','scripts/rocky_kernel_license_inventory.py','scripts/tests/test_rocky_kernel_config_resolution.py','scripts/tests/test_rocky_kernel_license_inventory.py','host-kernel/rocky/patches/0025-objtool-recognize-rust-1.92-vec-swap-remove-panic.patch']
    for name in names:
        target=out/'original-inputs'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target);record['inputs'].append(identity(target))

    # These targeted config/license tests create in-repository temporary files.
    # Clone their complete code/contracts/submodules into writable scratch.
    # Runtime image archives are not inputs to either selected test module.
    origin=repo;source=out/'source'
    def setup(label,args):
        with (out/(label+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append(dict(label=label,command=args,exit_code=result.returncode));assert result.returncode==0,label
    setup('clone',['git','clone','--shared','--no-hardlinks','--no-checkout',str(origin),str(source)])
    head=record['source_parent']
    listing=subprocess.check_output(['git','-C',str(origin),'ls-tree','-rlz','--full-tree',head,'docs/verification/evidence'])
    omitted=[]
    for raw in listing.split(b'\0'):
        if not raw:continue
        meta,path=raw.split(b'\t',1);mode,kind,blob,size=meta.decode().split();assert kind=='blob'
        omitted.append(dict(path=os.fsdecode(path),mode=mode,git_blob=blob,size=int(size),source_commit=head))
    (out/'historical-evidence-restoration.json').write_text(json.dumps(omitted,indent=2,sort_keys=True)+'\n')
    record['historical_evidence_omitted']=dict(count=len(omitted),bytes=sum(row['size'] for row in omitted),restoration_map='historical-evidence-restoration.json',scope='Runtime captures not consumed by either targeted configuration/license test module; full repository suite not claimed')
    setup('sparse',['git','-C',str(source),'sparse-checkout','set','--no-cone','/*','!/docs/verification/evidence/'])
    setup('checkout',['git','-C',str(source),'checkout','--detach',head])
    for index,line in enumerate(subprocess.check_output(['git','-C',str(origin),'submodule','status','--recursive'],text=True).splitlines()):
        assert line.startswith(' '),line
        revision,relative=line[1:].split()[:2];target=source/relative;target.parent.mkdir(parents=True,exist_ok=True)
        setup('submodule-clone-'+str(index),['git','clone','--shared','--no-hardlinks','--no-checkout',str(origin/relative),str(target)])
        setup('submodule-checkout-'+str(index),['git','-C',str(target),'checkout','--detach',revision])
    changed=subprocess.check_output(['git','-C',str(origin),'diff','--name-only','HEAD','-z']).split(b'\0')
    changed+=subprocess.check_output(['git','-C',str(origin),'ls-files','--others','--exclude-standard','-z']).split(b'\0')
    record['source_overlays']=[]
    for raw in sorted(set(changed)):
        if not raw:continue
        relative=os.fsdecode(raw);assert not relative.startswith('docs/verification/evidence/')
        target=source/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin/relative,target);record['source_overlays'].append(identity(target))
    repo=source
    commands=[['git','-C',str(repo),'diff','--check'],['python3','-B','-m','unittest','scripts.tests.test_rocky_kernel_config_resolution','scripts.tests.test_rocky_kernel_license_inventory','-v','-f']]
    for index,args in enumerate(commands):
        print('RUN',index,flush=True)
        with (out/(str(index)+'.log')).open('wb') as log: result=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append(dict(command=args,exit_code=result.returncode));assert result.returncode==0,(args,(out/(str(index)+'.log')).read_text()[-6000:])
    for row in record['inputs']:assert identity(Path(row['path']))==row
    for row in record['source_overlays']:assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
