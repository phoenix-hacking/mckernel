from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/home/holden/mckernel')
cap=Path('/tmp/stability-observer-stack-boundaries-20260913-1')
previous=Path('/home/holden/mckernel-work/scratch/stability-owner-phase-source-20260913-2')
old=json.loads((previous/'record.json').read_text())
source=Path(old['source'])
argv=[sys.executable,str(root/'scripts/tests/prepare_stability_owner_phase.py'),'--source',str(source),'--output',str(cap/'overlay')]
(cap/'command.json').write_text(json.dumps(argv,indent=2)+'\n')
with (cap/'stdout.bin').open('xb') as out,(cap/'stderr.bin').open('xb') as err:
    completed=subprocess.run(argv,stdout=out,stderr=err,timeout=30,check=False)
if completed.returncode:
    raise AssertionError('generator returned '+str(completed.returncode))
record=json.loads((cap/'overlay/record.json').read_text())
assert record['status']=='PREPARED_NOT_COMPILED_NOT_EXECUTED'
assert record['compiled'] is False and record['executed'] is False
assert record['compiled_stack_bound_verified'] is False
assert len(record['stack_boundaries'])==len(set(record['stack_boundaries']))==10
assert record['unchanged_observer_module']==old['unchanged_observer_module']
comparisons=[]
for item in record['files']:
    olditem=next(x for x in old['files'] if x['name']==item['name'])
    assert item['original']==olditem['original'],item['name']
    assert item['appendix']==olditem['appendix'],item['name']
    raw=(cap/'overlay'/item['name']).read_bytes()
    count=0
    for edit in reversed(item['edits']):
        if edit['label'].startswith('verification stack boundary '):
            changed=edit['replacement'].encode()
            assert raw.count(changed)==1,edit['label']
            raw=raw.replace(changed,edit['original'].encode())
            count+=1
    assert raw==(previous/item['name']).read_bytes(),item['name']
    assert (cap/'overlay/originals'/item['name']).read_bytes()==(source/item['name']).read_bytes()
    comparisons.append({'name':item['name'],'new_attributes':count,'without_attributes_equals_previous_overlay':True})
assert sum(x['new_attributes'] for x in comparisons)==10
assert (cap/'overlay/stability_phase.rs').read_bytes()==(previous/'stability_phase.rs').read_bytes()
result={'status':'PASS_SOURCE_STAGING_ONLY','comparisons':comparisons,'new_attributes':10,'no_native_compile':True,'no_guest':True,'previous_record_sha256':hashlib.sha256((previous/'record.json').read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((root/'scripts/tests/prepare_stability_owner_phase.py').read_bytes()).hexdigest()}
(cap/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
