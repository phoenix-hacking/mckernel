from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/home/holden/mckernel')
base=Path('/tmp/stability-observer-stack-review-inputs')
cap=Path('/home/holden/mckernel-work/scratch/stability-transport-fault-module-20260913-prepublish-hard-1')
linux=Path('/home/holden/mckernel-work/scratch/native-source/linux-6.12.0-211.44.1.el10_2')
build=Path('/home/holden/mckernel-work/scratch/native-build-base-24a151fe')
analysis=json.loads((base/'analysis.json').read_text())
def ident(path):
    raw=path.read_bytes()
    return {'path':str(path),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
functions={mod:{f['address']:f for f in v['functions']} for mod,v in analysis['modules'].items()}
def chain(mod,addresses,expected):
    rows=[]
    for i,address in enumerate(addresses):
        f=functions[mod][address]
        assert not f['unknown_stack_assignments'],f['name']
        row={'function':f['name'],'address':hex(address),'entry_disassembly_line':f['line'],'maximum_local_bytes':f['maximum_local_stack_bytes'],'entry_return_address_bytes':8}
        if i+1<len(addresses):
            edges=[c for c in f['calls'] if c['target']==['.text',addresses[i+1]]]
            assert edges and all(c['kind']=='call' for c in edges)
            row['callsites']=edges
            row['counted_local_bytes']=max(c['depth_before'] for c in edges)
        else: row['counted_local_bytes']=f['maximum_local_stack_bytes']
        row['counted_bytes']=row['counted_local_bytes']+8
        rows.append(row)
    total=sum(r['counted_bytes'] for r in rows)
    assert total==expected,(total,expected)
    return {'module':mod,'counted_bytes':total,'rows':rows,'scope':'Known module frames only; Linux callers, locks, logging, formatting and interrupts are additional and unbounded by this analysis.'}
chains={
 'packet_worker_to_mailbox_copy':chain('ihk-smp-x86_64',[0x41bd0,0x2fff0,0x2e630,0x22ec0,0x24270,0x31630],9416),
 'phase_ioctl_to_mailbox_copy':chain('ihk-smp-x86_64',[0x22d0,0x4d350,0x371e0,0x2fff0,0x2e630,0x22ec0,0x24270,0x31630],7080),
 'ret_enter_hook':chain('mcctrl',[0xcf0,0x3d60,0x5b00],704),
 'ret_leave_hook':chain('mcctrl',[0xcf0,0x3d60,0x5c90],704),
 'ret_select_hook':chain('mcctrl',[0xcf0,0x2ac0,0x5e20],560),
}
config=(build/'.config').read_text()
assert 'CONFIG_PAGE_SHIFT=12\n' in config and '# CONFIG_KASAN is not set\n' in config
assert 'CONFIG_X86_64=y\n' in config and 'CONFIG_VMAP_STACK=y\n' in config
kernel_files=[build/'.config',build/'include/generated/rustc_cfg',build/'include/generated/autoconf.h',linux/'arch/x86/include/asm/page_64_types.h',linux/'arch/x86/include/asm/page_types.h',linux/'include/vdso/page.h',linux/'rust/kernel/print.rs',linux/'lib/vsprintf.c',cap/'module-build/.ihk_smp_x86_64.o.cmd',cap/'module-build/.mcctrl.o.cmd',Path('/home/holden/mckernel-work/scratch/native-irq-transport-exact-stage-20260907-1/module-build.command')]
for mod in ('ihk-smp-x86_64','mcctrl'):
    command=(cap/'module-build'/('.ihk_smp_x86_64.o.cmd' if mod=='ihk-smp-x86_64' else '.mcctrl.o.cmd')).read_text()
    assert '-Cno-redzone=y' in command and '-Copt-level=2' in command and '-Cdebuginfo=2' in command
archive=root/'docs/verification/evidence/stability-observer-stack-review-20260913-1.tar.gz'
assert not archive.exists()
members={}
for path in [base/'audit.py',base/'analysis.json',base/'output.log',Path(__file__)]:
    members['analysis/'+path.name]=path.read_bytes()
for path in kernel_files:
    members['kernel-inputs/'+str(path).removeprefix('/home/holden/mckernel-work/scratch/')]=path.read_bytes()
for path in [cap/'record.json',cap/'ihk-smp-x86_64.ko-demangled-disassembly-collection/report.json',cap/'mcctrl.ko-demangled-disassembly-collection/report.json']:
    members['compiled-capture/'+str(path.relative_to(cap))]=path.read_bytes()
for path in cap.joinpath('staged-source').glob('*.rs'):
    members['compiled-staged-source/'+path.name]=path.read_bytes()
boundary=Path('/tmp/stability-observer-stack-boundaries-20260913-1')
for path in sorted(boundary.rglob('*')):
    if path.is_file(): members['candidate-source-check/'+str(path.relative_to(boundary))]=path.read_bytes()
with archive.open('xb') as file:
    with gzip.GzipFile(filename='',fileobj=file,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    checked={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
assert checked==members
selected={}
for mod,values in analysis['modules'].items():
    selected[mod]=[f for f in values['functions'] if ('verification_' in f['name'] or 'stability_ret_' in f['name'] or 'service::run' in f['name'] or ('stability_observer' in f['name'] and ('::fmt' in f['name'] or 'Debug' in f['name'])))]
record={
 'schema_version':1,'record_kind':'stability-compiled-observer-stack-review',
 'status':'PARTIAL_STATIC_STACK_REVIEW_REQUIRES_SMALLER_CANDIDATE_AND_EXTERNAL_BUDGET',
 'review_date':'2026-09-13','build_status':'PASS_BUILD_ONLY','compile_authorized_for_measured_attribute_candidate':True,
 'runtime_authorized':False,'full_kernel_stack_bound_verified':False,'actual_guest_verified':False,'application_acceptance':False,'production_gate_credit':False,
 'build_record':ident(cap/'record.json'),'source_hook_review':ident(root/'docs/verification/stability-transport-overlay-review-20260913.json'),
 'modules':{k:{field:v[field] for field in ('module','disassembly')} for k,v in analysis['modules'].items()},
 'retained_input_identities_verified':len(analysis['verified_retained_inputs']),
 'retained_inputs':analysis['verified_retained_inputs'],
 'analysis_method':[
  'Read the retained complete objdump -Cd output and exact unrelocated ELF modules; resolve rel32 using ELF SHT_RELA and local symbols instead of treating zero-displacement printed call targets as real callees.',
  'Track push/pop, constant rsp allocation/release, frame-pointer restoration and reachable branch stack states; include 8-byte entry return addresses and actual outgoing pushes at each selected callsite.',
  'Sum only nested calls. Detail/pager/ledger domains and seven sequential ledger classes are siblings. RET ENTER and LEAVE are separate calls, and RET ioctl runs on a different thread from the packet observer.',
  'No selected function has unresolved rsp assignment in this analysis; external/dynamic callees remain open. This helper is retained inspection machinery, not a complete verified compiler stack analyzer.'
 ],
 'known_call_chains':chains,
 'thread_size_context':{'bytes':16384,'page_shift':12,'page_bytes':4096,'kasan_enabled':False,'thread_size_order':2,'vmap_stack':True,'derivation':'include/vdso/page.h PAGE_SIZE=1<<CONFIG_PAGE_SHIFT; arch/x86/include/asm/page_64_types.h THREAD_SIZE_ORDER=2+KASAN_STACK_ORDER and THREAD_SIZE=PAGE_SIZE<<THREAD_SIZE_ORDER; KASAN disabled.',
 'binding_limit':'Configuration and headers are captured from the current exact pinned Linux source/build trees named by the retained module compiler commands. This review has no separately historical kernel-config hash proving those bytes at the original kernel build.',
 'inputs':[ident(x) for x in kernel_files]},
 'open_edges':[
  'Linux kthread/ioctl entry frames, lock slow paths and scheduler calls are not included.',
  'kernel::print::call_printk invokes C _printk with %pA; Linux vsprintf calls rust_fmt_argument, which dynamically invokes core formatting and module Debug implementations. Retained module formatter frames do not bound external C/Rust formatter nesting or console handling.',
  'At mailbox printing the known worker prefix is 9120 bytes before entering call_printk; mailbox-copy chain 9416 bytes does not subsume that additional logging/formatting path.',
  'Normal error/panic paths, arbitrary interrupt/NMI interactions, mitigation thunks and deeper backend RETURN handling are not proven bounded here.',
  'A 16384-byte task stack is a total allocation, not a safe per-observer allowance; 6968 bytes remaining after the 9416-byte module prefix is arithmetic only.'
 ],
 'selected_function_frames':selected,
 'candidate':{'helper':ident(root/'scripts/tests/prepare_stability_owner_phase.py'),'source_check':json.loads((boundary/'result.json').read_text()),'attributes_only':True,'stack_boundaries':['Runtime::metadata','Runtime::zeroing','Runtime::pump','Runtime::pump_master','Runtime::pump_regular','Runtime::publish_remote','Runtime::publish_applications','Runtime::publish_syscalls','Runtime::publish_procfs','Remote::advance'],
 'reason':'The first compiled service::run frame is 3000 bytes at the observer call and contains the packet, metadata and zeroing roles. Isolate existing role entry methods and sequential fallible pump service calls; no function body, order, ownership, allocation, deadline or fault logic changes.',
 'original_compiled_capture_preserved':True,'compiled_stack_reduction_verified':False,'follow_up':'Parent rebuilds a fresh named attempt, verifies inverse production restoration, then audits actual new callsite/formatter frames before runtime.'},
 'retention':{'archive':ident(archive),'members':[{'name':n,'size':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(members.items())],'roundtrip_bytes_verified':True}
}
out=root/'docs/verification/stability-observer-stack-review-20260913-1.json'
with out.open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps({'review':ident(out),'archive':ident(archive),'known_chain_bytes':{k:v['counted_bytes'] for k,v in chains.items()},'member_count':len(members)},sort_keys=True))
