"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-zeroing-images-retained-20260909-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-zeroing-images-checkpoint-20260909.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='All four image selections with native guest atomic zeroing batches and one-way marker, preserving host-PTE invalidation. Native host zeroing integration and new guest execution remain pending.',artifacts=[],captures=[],guest_compiler_bindings=[],references=[],application_readiness_complete=False,actual_guest_pass=False,zeroing_service_integrated=False,full_capture_retention_pending=False)
try:
    shutil.copyfile(__file__,out/'helper.py')
    for attempt,expected in [(1,'PASS')]:
        directory=work/('mckernel-native-zeroing-images-20260909-'+str(attempt));state=json.loads((directory/'record.json').read_text());assert state['status']==expected
        for row in state['production_inputs']+state['source_overlays']:verify(row)
        for result in state.get('images',[]):
            for row in result['outputs']:verify(row)
        listing=subprocess.check_output(['git','-C',str(repo),'ls-tree','-rlz','--full-tree',state['source_parent'],'docs/verification/evidence'])
        restored=[]
        for raw in listing.split(b'\0'):
            if not raw:continue
            meta,path=raw.split(b'\t',1);mode,kind,blob,size=meta.decode().split();assert kind=='blob'
            restored.append(dict(path=os.fsdecode(path),mode=mode,git_blob=blob,size=int(size),source_commit=state['source_parent']))
        assert restored==json.loads((directory/'historical-evidence-restoration.json').read_text())
        assert not (directory/'source/docs/verification/evidence').exists()
        artifact(directory,directory.name+'.tar.gz',True)
        artifact(directory/'record.json',directory.name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),original_status=expected,complete_capture_retained=True,compile_only_evidence_omission=state['historical_evidence_omitted'],restoration_map_verified_against_exact_git_tree=True,record=identity(directory/'record.json')))
    images=work/'mckernel-native-zeroing-images-20260909-1';state=json.loads((images/'record.json').read_text())
    assert [row['kind'] for row in state['images']]==['fallback','legacy-rust','native-rust','native-sysfs-verify']
    record.update(images=state['images'],guest_compiler=state['compiler'],historical_equivalence=state['historical_equivalence'])
    for row in state['production_inputs']:
        saved=Path(row['path']);relative=saved.relative_to(images/'source');record['guest_compiler_bindings'].append(binding(repo/relative,saved))
    record['zeroing_binary_bindings']=[]
    record['protection_binary_bindings']=[]
    for row in state['images']:
        kind=row['kind'];build=images/kind
        if kind=='fallback':continue
        selected=(build/'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make').read_text()
        native='native_linux_irq_work_v6_12' in selected;assert native==(kind!='legacy-rust')
        assert 'kernel/rust/syscall_policy.rs' in selected
        sized=(images/(kind+'-sized-symbols.txt')).read_text()
        bridge=[line.split() for line in sized.splitlines() if line.split()[-1:]==['syscall_policy_do_syscall3_bridge']]
        assert len(bridge)==1
        disassembly=images/(kind+'-set_host_vma_body_result-disassembly.log');text=disassembly.read_text()
        if native:
            assert '$0xb,%edi' in text and '$0x'+bridge[0][0] in text
            assert '0xb8(%rbx)' in text and '$0xffffffff,0xb8(%rbx)' in text
        else:
            assert 'call' not in text and '%eax,%eax' in text
        record['protection_binary_bindings'].append(dict(kind=kind,native_invalidation_selected=native,bridge_address=bridge[0][0],disassembly=identity(disassembly),symbol_table=identity(images/(kind+'-sized-symbols.txt'))))

        producer=images/(kind+'-__ihk_numa_zero_request_packet_fill-disassembly.log')
        zeroing=images/(kind+'-__ihk_numa_zero_free_pages_node-disassembly.log')
        producer_text=producer.read_text();zeroing_text=zeroing.read_text()
        has_marker='$0x31303030425a434d' in producer_text
        assert has_marker==native
        if native:
            assert '$0x117,%r8' in producer_text and '%rax,0x50(%rdi)' in producer_text
            assert re.search(r'\bxchg\s+%rdi,0x38\(%rbx\)',zeroing_text)
            assert 'lock cmpxchg %r13,0x30(%rbx)' in zeroing_text
            assert 'lock sub %r15d,0x2c(%rbx)' in zeroing_text
        else:
            assert '$0x0,0x50(%rdi)' in producer_text
            assert not re.search(r'\bxchg\s',zeroing_text)
        commands=json.loads((build/'compile_commands.json').read_text())
        allocator=[row for row in commands if row['file'].endswith('/lib/page_alloc.c')]
        assert len(allocator)==1 and '-DMCKERNEL_RUST_PAGE_ALLOC_RBTREE' in allocator[0]['command']
        assert 'host-kernel/native-rust/zero_pages.rs' in selected
        record['zeroing_binary_bindings'].append(dict(kind=kind,native_batch_selected=native,marker='MCZB0001' if native else None,pending_head_offset=56,zeroed_head_offset=48,pending_counter_offset=44,producer=identity(producer),zeroing=identity(zeroing)))
    base=repo/'docs/verification/native-application-zeroing-checkpoint-20260909.json'
    row=identity(base);row['path']=str(base.relative_to(repo));record['references'].append(row)
    artifact(out/'helper.py','native-application-zeroing-images-20260909-retention-helper.gz')
    record.update(status='PASS',complete_captures=1,original_failures=0,artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');(out/'record.json').write_bytes(manifest.read_bytes());print(record['status'],manifest,flush=True)
