from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
out = Path('/work/native-application-final-batch-20260909-' + sys.argv[1])
out.mkdir()
shutil.copyfile(__file__, out / 'helper.py')
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', '/workspace', 'rev-parse', 'HEAD'], text=True).strip(),
              commands=[], cpuset=sorted(os.sched_getaffinity(0)))
commands = [
    ['python3', '-B', '/work/run-native-application-signals.py', 'memory', '1'],
    ['python3', '-B', '/work/run-native-application-signals.py', 'files', '1'],
    ['python3', '-B', '/work/run-native-application-signals.py', 'threads', '1'],
    ['python3', '-B', '/work/run-native-application-final-regression.py', 'x86_64', '1', '1'],
    ['python3', '-B', '/work/run-native-application-final-compat.py', 'i386', '1', '1'],
]
try:
    for index, command in enumerate(commands, 1):
        raw = Path(command[2]).read_bytes()
        (out / ('runner-' + str(index) + '.py')).write_bytes(raw)
        row = dict(command=command, helper_sha256=hashlib.sha256(raw).hexdigest(),
                   started_utc=datetime.now(timezone.utc).isoformat())
        record['commands'].append(row)
        (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
        print('RUN', index, command, flush=True)
        with (out / ('run-' + str(index) + '.log')).open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        row.update(exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
        assert result.returncode == 0, (index, command, result.returncode)
        print('PASS', index, command, flush=True)
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
