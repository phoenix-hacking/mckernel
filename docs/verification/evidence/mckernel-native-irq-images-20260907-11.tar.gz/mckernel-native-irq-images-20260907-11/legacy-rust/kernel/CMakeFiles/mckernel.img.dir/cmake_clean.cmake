file(REMOVE_RECURSE
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/context.S.o"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o.d"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/interrupt.S.o"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o.d"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o.d"
  "CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/trampoline.S.o"
  "CMakeFiles/mckernel.img.dir/mem.c.o"
  "CMakeFiles/mckernel.img.dir/mem.c.o.d"
  "CMakeFiles/mckernel.img.dir/process.c.o"
  "CMakeFiles/mckernel.img.dir/process.c.o.d"
  "CMakeFiles/mckernel.img.dir/rust/abi_checks.c.o"
  "CMakeFiles/mckernel.img.dir/rust/abi_checks.c.o.d"
  "CMakeFiles/mckernel.img.dir/syscall.c.o"
  "CMakeFiles/mckernel.img.dir/syscall.c.o.d"
  "mckernel.img"
  "mckernel.img.pdb"
  "rust/mckernel_rust.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang ASM C)
  include(CMakeFiles/mckernel.img.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
