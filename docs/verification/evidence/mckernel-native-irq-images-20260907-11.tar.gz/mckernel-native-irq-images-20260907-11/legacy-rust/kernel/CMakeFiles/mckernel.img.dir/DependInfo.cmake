
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/context.S" "/work/mckernel-native-irq-images-20260907-11/legacy-rust/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/context.S.o"
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/interrupt.S" "/work/mckernel-native-irq-images-20260907-11/legacy-rust/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/interrupt.S.o"
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/trampoline.S" "/work/mckernel-native-irq-images-20260907-11/legacy-rust/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/trampoline.S.o"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "IHK_IKC_USE_LINUX_WORK_IRQ"
  "IHK_OS_MANYCORE"
  "KERNEL_RAM_VADDR=0xfffffffffe800000"
  "MAP_KERNEL_START=0xfffffffffe800000UL"
  "MCKERNEL_RUST_ATOMIC_HELPERS"
  "MCKERNEL_RUST_BITOPS"
  "MCKERNEL_RUST_LIST_HELPERS"
  "MCKERNEL_RUST_LOCK_HELPERS"
  "MCKERNEL_RUST_MCS_RWLOCK_HELPERS"
  "MCKERNEL_RUST_MC_RWLOCK_HELPERS"
  "MCKERNEL_RUST_PTE_HELPERS"
  "MCKERNEL_RUST_REFCOUNT_HELPERS"
  "MCKERNEL_RUST_SPINLOCK_HELPERS"
  "PROFILE_ENABLE"
  "__KERNEL__"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "kernel/include"
  "/work/mckernel-native-irq-images-20260907-11/source/kernel/include"
  "kernel"
  "."
  "/work/mckernel-native-irq-images-20260907-11/source/ihk/cokernel/smp/x86_64/include"
  "/work/mckernel-native-irq-images-20260907-11/source/ihk/cokernel/smp/x86_64"
  "/work/mckernel-native-irq-images-20260907-11/source/ihk/ikc/include"
  "/work/mckernel-native-irq-images-20260907-11/source/ihk/linux/include"
  "/work/mckernel-native-irq-images-20260907-11/source/lib/include"
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/cpu.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/memory.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/syscall.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/kernel/mem.c" "kernel/CMakeFiles/mckernel.img.dir/mem.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/mem.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/kernel/process.c" "kernel/CMakeFiles/mckernel.img.dir/process.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/process.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/kernel/rust/abi_checks.c" "kernel/CMakeFiles/mckernel.img.dir/rust/abi_checks.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/rust/abi_checks.c.o.d"
  "/work/mckernel-native-irq-images-20260907-11/source/kernel/syscall.c" "kernel/CMakeFiles/mckernel.img.dir/syscall.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/syscall.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
