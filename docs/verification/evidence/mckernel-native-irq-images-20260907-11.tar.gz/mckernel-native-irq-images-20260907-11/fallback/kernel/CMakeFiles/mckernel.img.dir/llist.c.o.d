kernel/CMakeFiles/mckernel.img.dir/llist.c.o: \
 /work/mckernel-native-irq-images-20260907-11/source/kernel/llist.c \
 /work/mckernel-native-irq-images-20260907-11/source/kernel/include/llist.h \
 /work/mckernel-native-irq-images-20260907-11/source/lib/include/types.h \
 /work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/include/ihk/types.h \
 /work/mckernel-native-irq-images-20260907-11/source/kernel/include/lwk/compiler.h \
 /work/mckernel-native-irq-images-20260907-11/source/kernel/include/lwk/compiler-gcc.h \
 /work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/include/ihk/atomic.h \
 /work/mckernel-native-irq-images-20260907-11/source/arch/x86_64/kernel/include/arch/cpu.h
