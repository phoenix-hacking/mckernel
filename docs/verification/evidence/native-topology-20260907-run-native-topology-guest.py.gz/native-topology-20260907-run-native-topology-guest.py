from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, socket, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
compiled = Path('/work/native-topology-module-20260907-' + sys.argv[1])
out = Path('/work/native-topology-guest-20260907-' + sys.argv[2]); out.mkdir()
kernel = Path('/work/native-topology-kernel-20260907-1')
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', '/workspace', 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], commands=[], production_gate_credit=False, sysfs_service_completed=False,
    mckernel_boot_proven=False, declared_stage=False, cpus=4, memory_mib=8192,
    container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)))
process = None
stream = None

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command, env=None):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-6000:])

sequence = 0
def qmp(command):
    global sequence
    sequence += 1
    stream.write((json.dumps(dict(execute=command, id=sequence)) + '\n').encode()); stream.flush()
    while True:
        line = stream.readline()
        assert line, 'QMP disconnected'
        response = json.loads(line)
        if response.get('id') != sequence: continue
        assert 'error' not in response, response
        return response['return']

try:
    shutil.copyfile(__file__, out / 'helper.py')
    built = json.loads((compiled / 'record.json').read_text())
    assert built['status'] == 'PASS'
    for row in built['inputs'] + built['compiler_inputs'] + built['outputs']:
        assert identity(Path(row['path'])) == row, row
    record['inputs'] += [identity(compiled / 'record.json'), identity(kernel / 'bzImage')]
    root = out / 'root'
    base_root = Path('/work/native-runtime-local-base-24a151fe/root')
    record['inputs'] += [identity(path) for path in sorted(base_root.rglob('*')) if path.is_file()]
    shutil.copytree(base_root, root)
    copies = [(compiled / 'mckernel_topology_verify.ko', root / 'modules/mckernel_topology_verify.ko'),
              (Path('/usr/bin/sleep'), root / 'bin/sleep')]
    for source, destination in copies:
        record['inputs'].append(identity(source)); shutil.copy2(source, destination)
    (root / 'init').write_text('#!/bin/bash\nset -eu\nexport PATH=/bin:/sbin:/usr/bin:/usr/sbin\nfail() { echo MCKERNEL_TOPOLOGY_GUEST_FAIL; while :; do sleep 1; done; }\ntrap fail EXIT\nmount -t proc proc /proc\nmount -t sysfs sysfs /sys\nmount -t devtmpfs devtmpfs /dev\n\nhost_values() {\n    local phase=$1 cpu field cache index value\n    for cpu in 0 1 2 3; do\n        for field in physical_package_id core_id die_id core_siblings thread_siblings; do\n            value=$(</sys/devices/system/cpu/cpu${cpu}/topology/${field})\n            printf \'TOPOLOGY_HOST phase=%s cpu=%s field=%s value=%s\\n\' "$phase" "$cpu" "$field" "$value"\n        done\n        for cache in /sys/devices/system/cpu/cpu${cpu}/cache/index*; do\n            test -d "$cache"\n            index=${cache##*/index}\n            for field in id type level coherency_line_size number_of_sets ways_of_associativity physical_line_partition size shared_cpu_map; do\n                value=$(<"$cache/$field")\n                printf \'TOPOLOGY_CACHE phase=%s cpu=%s index=%s field=%s value=%s\\n\' "$phase" "$cpu" "$index" "$field" "$value"\n            done\n        done\n    done\n}\n\nsnapshots() {\n    local cycle=$1 phase=$2 cpu value\n    for cpu in 0 1 2 3; do\n        value=$(</sys/mckernel_topology_verify/cpu${cpu})\n        printf \'TOPOLOGY_SNAPSHOT cycle=%s phase=%s cpu=%s BEGIN\\n%s\\nTOPOLOGY_SNAPSHOT_END\\n\' "$cycle" "$phase" "$cpu" "$value"\n    done\n}\n\necho TOPOLOGY_CPUINFO_BEGIN\nwhile IFS= read -r line; do printf \'%s\\n\' "$line"; done < /proc/cpuinfo\necho TOPOLOGY_CPUINFO_END\nhost_values initial\nfor cycle in 1 2; do\n    insmod /modules/mckernel_topology_verify.ko\n    snapshots "$cycle" before\n    echo 0 > /sys/devices/system/cpu/cpu1/online\n    test "$(</sys/devices/system/cpu/cpu1/online)" = 0\n    test ! -e /sys/devices/system/cpu/cpu1/cache/index0\n    snapshots "$cycle" offline\n    for cache in /sys/devices/system/cpu/cpu0/cache/index*; do\n        index=${cache##*/index}\n        value=$(<"$cache/shared_cpu_map")\n        printf \'TOPOLOGY_OFFLINE cycle=%s cpu=0 index=%s value=%s\\n\' "$cycle" "$index" "$value"\n    done\n    for field in core_siblings thread_siblings; do\n        value=$(</sys/devices/system/cpu/cpu0/topology/$field)\n        printf \'TOPOLOGY_OFFLINE_CPU cycle=%s cpu=0 field=%s value=%s\\n\' "$cycle" "$field" "$value"\n    done\n    echo 1 > /sys/devices/system/cpu/cpu1/online\n    test "$(</sys/devices/system/cpu/cpu1/online)" = 1\n    snapshots "$cycle" restored\n    rmmod mckernel_topology_verify\n    test ! -e /sys/mckernel_topology_verify\n    printf \'MCKERNEL_TOPOLOGY_CYCLE_PASS=%s\\n\' "$cycle"\ndone\nhost_values final\necho MCKERNEL_TOPOLOGY_GUEST_PASS\nwhile :; do sleep 1; done\n')
    (root / 'init').chmod(0o755)
    run('shell-syntax', ['bash', '-n', str(root / 'init')])
    generator = Path('/work/write-native-cpio-spec.py')
    record['inputs'].append(identity(generator))
    run('initramfs-spec', ['python3', '-B', str(generator)], dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(root)))
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            creator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(creator.stdout, output); creator.stdout.close(); assert creator.wait() == 0
    record['inputs'] += [identity(out / 'initramfs.cpio.gz'), identity(root / 'init')]
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
            '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(kernel / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-display', 'none', '-no-reboot', '-no-shutdown', '-nic', 'none']
    record['qemu_args'] = args; save()
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 300
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20); connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            for bad in ['Call Trace:', 'MCKERNEL_TOPOLOGY_GUEST_FAIL', 'Assertion ', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
                assert bad not in serial, bad
            if 'MCKERNEL_TOPOLOGY_GUEST_PASS' in serial:
                qmp('quit'); process.wait(timeout=15); break
            state = qmp('query-status')
            assert state['status'] not in ('shutdown', 'guest-panicked'), state
            time.sleep(0.1)
        assert process.returncode == 0
    serial = (out / 'serial.log').read_text(errors='replace')
    assert serial.count('MCKERNEL_TOPOLOGY_VERIFY READY cpus=4 owned_snapshots=1') == 2
    assert serial.count('MCKERNEL_TOPOLOGY_CYCLE_PASS=') == 2
    cpus = {}
    cpuinfo = re.search(r'TOPOLOGY_CPUINFO_BEGIN\n(.*?)TOPOLOGY_CPUINFO_END', serial, re.S).group(1)
    for block in cpuinfo.strip().split('\n\n'):
        values = dict(line.split(':', 1) for line in block.splitlines() if ':' in line)
        values = {key.strip(): value.strip() for key, value in values.items()}
        if 'processor' in values: cpus[int(values['processor'])] = int(values['apicid'])
    assert set(cpus) == set(range(4)), cpus
    host = {}
    for phase, cpu, field, value in re.findall(r'^TOPOLOGY_HOST phase=(\w+) cpu=(\d+) field=(\w+) value=([^\n]+)$', serial, re.M):
        key = (phase, int(cpu), field); assert key not in host; host[key] = value
    caches = {}
    for phase, cpu, index, field, value in re.findall(r'^TOPOLOGY_CACHE phase=(\w+) cpu=(\d+) index=(\d+) field=(\w+) value=([^\n]+)$', serial, re.M):
        key = (phase, int(cpu), int(index), field); assert key not in caches; caches[key] = value
    assert len(host) == 2 * 4 * 5 and len(caches) > 0
    for key, value in host.items():
        if key[0] == 'initial': assert host[('final', *key[1:])] == value, key
    for key, value in caches.items():
        if key[0] == 'initial': assert caches[('final', *key[1:])] == value, key
    snapshots = {}
    for cycle, phase, cpu, value in re.findall(r'^TOPOLOGY_SNAPSHOT cycle=(\d+) phase=(\w+) cpu=(\d+) BEGIN\n(.*?)\nTOPOLOGY_SNAPSHOT_END$', serial, re.M | re.S):
        key = (int(cycle), phase, int(cpu)); assert key not in snapshots; snapshots[key] = value
    assert len(snapshots) == 2 * 3 * 4, len(snapshots)
    def bitmap(text): return int(text.replace(',', ''), 16)
    def words(values):
        assert len(values) == 8
        return sum(int(word, 16) << (64 * index) for index, word in enumerate(values))
    scalar_checks = 0; cache_count = 0
    for cycle in (1, 2):
        for cpu in range(4):
            value = snapshots[(cycle, 'before', cpu)]
            assert value == snapshots[(cycle, 'offline', cpu)] == snapshots[(cycle, 'restored', cpu)]
            assert value == snapshots[(1, 'before', cpu)]
            lines = value.splitlines(); first = lines[0].split()
            assert first[0] == 'cpu'
            actual = list(map(int, first[1:]))
            expected = [cpu, cpus[cpu]] + [int(host[('initial', cpu, field)]) for field in ('physical_package_id', 'core_id', 'die_id')]
            assert actual == expected, (cpu, actual, expected)
            assert lines[1].startswith('core ') and lines[2].startswith('thread ')
            assert words(lines[1].split()[1:]) == bitmap(host[('initial', cpu, 'core_siblings')])
            assert words(lines[2].split()[1:]) == bitmap(host[('initial', cpu, 'thread_siblings')])
            scalar_checks += 7
            seen = set()
            for line in lines[3:]:
                values = line.split(); assert values[0] == 'cache' and len(values) == 19, values
                index, cache_id, kind, level, coherency, sets, ways, partition, size, attributes = map(int, values[1:11])
                assert index not in seen; seen.add(index)
                def field(name): return caches[('initial', cpu, index, name)]
                assert cache_id == int(field('id')) and attributes & 16
                assert kind == {'Instruction': 1, 'Data': 2, 'Unified': 4}[field('type')]
                assert [level, coherency, sets, ways, partition] == [int(field(name)) for name in ('level', 'coherency_line_size', 'number_of_sets', 'ways_of_associativity', 'physical_line_partition')]
                capacity = field('size'); assert capacity.endswith('K') and size == int(capacity[:-1]) * 1024
                assert words(values[11:]) == bitmap(field('shared_cpu_map'))
                scalar_checks += 10; cache_count += 1
            expected_indices = {index for phase, cache_id, index, field in caches if phase == 'initial' and cache_id == cpu}
            assert seen == expected_indices and seen
    changes = 0; cache_observations = []
    # Pinned x86 has CONFIG_ACPI=y and use_arch_cache_info()=false. Both
    # observed leaves have CACHE_ID: Linux's sharing predicate compares IDs
    # after matching level/type. Its raw cache mask can retain an offline bit.
    assert 'CONFIG_ACPI=y\n' in (kernel / 'resolved.config').read_text()
    for cycle, cpu, index, value in re.findall(r'^TOPOLOGY_OFFLINE cycle=(\d+) cpu=(\d+) index=(\d+) value=([^\n]+)$', serial, re.M):
        cpu = int(cpu); index = int(index)
        before = bitmap(caches[('initial', cpu, index, 'shared_cpu_map')])
        after = bitmap(value)
        peers = {i for phase, c, i, field in caches if phase == 'initial' and c == 1}
        matches = any(bitmap(caches[('initial', 1, peer, 'shared_cpu_map')]) & (1 << cpu)
            and all(caches[('initial', 1, peer, field)] == caches[('initial', cpu, index, field)]
                for field in ('id', 'type', 'level')) for peer in peers)
        expected = before & ~(1 << 1) if matches else before
        assert after == expected, (cycle, index, before, after, matches)
        changes += before != after
        cache_observations.append(dict(cycle=int(cycle),cpu=cpu,index=index,before=before,after=after,matching_cache_id=matches))
    assert len(cache_observations) == 2 * len({i for phase,c,i,field in caches if phase == 'initial' and c == 0})
    core_changes = 0; core_observations = []
    for cycle, cpu, field, value in re.findall(r'^TOPOLOGY_OFFLINE_CPU cycle=(\d+) cpu=(\d+) field=(\w+) value=([^\n]+)$', serial, re.M):
        before = bitmap(host[('initial', int(cpu), field)]); after = bitmap(value)
        assert after == before & ~(1 << 1), (cycle, field, before, after)
        core_changes += before != after
        core_observations.append(dict(cycle=int(cycle),field=field,before=before,after=after))
    assert len(core_observations) == 4 and core_changes == 2, core_observations
    record.update(module_cycles=2, snapshot_cpus=4, snapshot_reads=len(snapshots),
        scalar_checks=scalar_checks, cache_leaf_checks=cache_count,
        observed_linux_cache_mask_changes=changes, linux_cache_mask_observations=cache_observations,
        observed_linux_core_mask_changes=core_changes, linux_core_mask_observations=core_observations, cpu_offline_online_cycles=2,
        snapshots_unchanged_across_offline=True, namespace_removed=True,
        independent_apic_source='/proc/cpuinfo', independent_topology_source='Linux sysfs before and after transitions')
    for row in record['inputs']: assert identity(Path(row['path'])) == row, row
    record.update(status='PASS', scope='Owned topology agrees with independent Linux values and survives CPU offline/online; native CPU-context integration and sysfs setup remain pending')
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
    if stream is not None: stream.close()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name != 'record.json']
    save(); print(record['status'], out, flush=True)
