from pathlib import Path
import os, shutil, subprocess
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo, work=Path('/workspace'),Path('/work')
out=work/'native-irq-transport-formatted-20260907-1'
out.mkdir()
source=repo/'scripts/tests/fixtures/mckernel_irq_work_verify.rs'
shutil.copyfile(source,out/source.name)
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true',str(out/source.name)],check=True)
patch=repo/'host-kernel/kbuild/patches/0005-irq-work-export-remote-queue-primitives.patch'
subprocess.run(['patch','--dry-run','--fuzz=0','-p1','-i',str(patch)],cwd=work/'native-source/linux-6.12.0-211.44.1.el10_2',check=True)
print('PASS: formatted private fixture and exact Linux patch applicability',flush=True)
