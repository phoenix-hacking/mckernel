from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-published-stage-tests-20260913-2'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(), inputs=[],
              application_acceptance=False, transport_acceptance=False, guest_execution=False)
def identity(p):
    data = p.read_bytes()
    return dict(path=str(p), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    preparation = work / 'stability-published-source-20260913-postpublish-notify-2'
    assert identity(preparation / 'record.json')['sha256'] == 'e7e2e6b8caa8e7c4deaffcbfd87f7d53bbb9b04b19dd7c574e9ace670520c0b2'
    prepared = json.loads((preparation / 'record.json').read_text())
    assert prepared['status'] == 'PREPARED_PUBLISHED_HOLD_NO_BUILD_NO_EXECUTION'
    source = preparation / 'original-rust-source'
    assert sorted(p.name for p in source.iterdir()) == sorted(row['path'] for row in prepared['original_rust_source'])
    for row in prepared['original_rust_source']:
        actual = identity(source / row['path'])
        assert (actual['size'], actual['sha256']) == (row['size'], row['sha256'])
    shutil.copyfile(preparation / 'record.json', out / 'preparation-record.json')
    record['preparation_record'] = identity(preparation / 'record.json')
    hashes = {'scripts/tests/test_stability_published_hold_stage.py': '8a30fd7e5688505e432a36b6b6ea3d52b3cd578a10823c38550f630de68573e9',
              'scripts/tests/prepare_stability_published_hold.py': '80b6b4fe90a5ac42f187f08e1056867b06776a83102cf59196011790c6b2e563',
              'scripts/application-tests/supervisor.py': '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'}
    for package in ('stability-owner-phase', 'stability-transport-fault', 'stability-published-hold-v1'):
        for item in sorted((preparation / 'source/scripts/tests/fixtures' / package).glob('*.rs')):
            name = str(item.relative_to(preparation / 'source'))
            dst = out / name; dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item, dst)
            record['inputs'].append(dict(original=identity(item), retained=identity(dst)))
    for name, digest in hashes.items():
        src = repo / name
        assert identity(src)['sha256'] == digest
        dst = out / name; dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    shutil.copyfile(out / 'scripts/application-tests/supervisor.py', out / 'supervisor.py')
    spec = importlib.util.spec_from_file_location('supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    argv = ['/usr/bin/python3', '-B', str(out / 'scripts/tests/test_stability_published_hold_stage.py')]
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'), STABILITY_PUBLISHED_HOLD_COMPOSED_SOURCE=str(source))
    record.update(command=argv, environment=env); save()
    result = supervisor.run_supervised(argv, cwd=str(out), env=env, attempt_dir=str(out / 'collection'),
        timeout_seconds=180, cleanup_timeout_seconds=15, stdout_limit_bytes=8*1024**2, stderr_limit_bytes=8*1024**2)
    record['collection'] = result; save()
    assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete']
    stderr = (out / 'collection/stderr.bin').read_text()
    assert 'Ran 18 tests' in stderr and stderr.rstrip().endswith('OK')
    for row in record['inputs']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    record.update(status='PASS_ACTUAL_COMPOSED_SOURCE_STAGING_ONLY', cases=18)
except BaseException as exc:
    record.update(status='FAIL', error_type=type(exc).__name__, error=str(exc)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save()
    print(record['status'], out, flush=True)
