# McKernel Rust Migration Agent Notes

Updated: 2026-06-02

## Active stability and complete-verification goal (2026-09-13)

The user has authorized implementation of the full stability/verification
roadmap and explicitly removed its earlier three-day deadline. The active
objective is preserved in `docs/verification/stability-goal-20260913.txt`;
the continuation entry point is `docs/verification/stability-run-20260913.md`.
This supersedes the completed Spark drafting-only phase and its model-switch
stops. Continue implementation, fixture/oracle review, infrastructure repair,
isolated validation and verified GitHub checkpoints without repeated permission.
The user requested independent review/infrastructure/defect lanes. Heavy
builds and guests remain serialized under the existing four-CPU/12-GiB limits.

Preserve all original released catalogs, packets, reports, failure evidence and
historical scores. Correct historical references through additive, source-bound
records. Prerequisite baseline, runner and transport-fault work is authorized;
new catalog execution still requires all global and case capability gates plus
a separately reviewed execution packet. Drafting or protocol-test success never
counts as application acceptance. Retain current Rust consumers and the full
Rust/assembly, native production and qualification requirements. Do not reduce
the goal to the first application subset or mark it complete at a checkpoint.

## Codex Spark goal entry point (2026-09-09)

The user requested a ready-to-run goal and reference files for Codex Spark.
The goal is `docs/verification/codex-spark-goal-20260909.md`; startup, paths,
coordination, recovery and completion are in
`docs/verification/codex-spark-runbook-20260909.md`. The active section of
`goal.txt` carries the same goal; historical sections below are not new tasks.
The Ultra handoff was announced after commit
`7b32298119df13a83240e082c275c34d184f7ccc` passed exact fetched-blob verification.
The retained proof is `docs/verification/evidence/ultra-handoff-github-verification-20260909-1.json`.
When the user starts the goal after choosing Spark or Luna, execute its bounded
drafting queue; do not stop again for an already-completed Ultra notification.
Preparing these goal documents alone does not start drafts or switch models.

Follow the runbook's narrow coordination scope for next-context emission,
crash recovery, immutable report preservation and verified GitHub checkpoints.
It clarifies existing continuation/reporting authorization; it does not enable
compilation, payload/guest execution, production repair or release-metadata edits.
The 97 released packets and all hash-bound handoff inputs stay unchanged.

## Bounded drafting release authority (2026-09-09)

The Ultra drafting release is `docs/verification/ultra-drafting-handoff-20260909.json`.
It becomes effective only with status PASS, its exact input/queue/context hashes,
and successful fetched-blob GitHub verification. Before that, continue the
remaining Ultra handoff gates; a queue review_state alone is insufficient.
After release, tell the user "We're ready to run Codex Spark" and stop for their
model switch. The user may choose Luna instead; never switch automatically.

The released next phase creates fixtures and independent oracles for273 logical
cases (56 vector cases) in97 pre-reviewed packets. Start with
`scripts/application-tests/handoff-start.md`. Supply only the active packet's
selected cases and small reviewed manifests, at most three cases at once.
Continue the reviewed queue without repeated permission, preserving immutable
reports and original failures. Runtime stays disabled until its separate
execution gates and reviewed packet version explicitly enable it. Drafting
completion is not application acceptance. Difficult/unsafe kernel defects and
preserved small candidate patches return to Max for narrow investigation.
Continue verified GitHub checkpoints about every30minutes and at coherent
milestones. The release supersedes older phase stopping instructions below.

## Active Ultra review and executor handoff (2026-09-09)

The user has switched to Ultra. Continue review, bounded correctness fixes and
isolated validation, then prepare detailed application test packets. The user
may choose Luna or Spark as the later executor; all packets must support either.
Tell the user explicitly when the handoff gates pass. Do not switch models.
The previous Max baseline is historical acceptance of its exact binaries, not
acceptance of the new working-tree changes or broader signal/futex behavior.

Review findings and prerequisite fixes are recorded under docs/verification/
ultra-*-20260909.md. The forthcoming canonical plan is
`docs/verification/ultra-application-test-plan-20260909.md`, with bounded executor
inputs in `scripts/application-tests/`. Go wide on independent tests, then send
failures and preserved candidate patches to Max for narrow investigation.
The executor may attempt a small logged candidate fix within its active packet;
never silently accept a changed kernel or weaken an oracle. Preserve original
failures and use fresh guests after a failure. Continue periodic verified GitHub
checkpoints (about30minutes), including explicit WIP saves before long runs.
This section supersedes the old instruction below to stop for the Ultra switch.

## Application baseline verified and model handoff (2026-09-09)

The Max application-baseline runtime gates and readiness audit now PASS.
Use [`docs/verification/native-application-ultra-handoff-20260909.md`](docs/verification/native-application-ultra-handoff-20260909.md)
and its readiness/final manifests as the current authority. The exact final
GitHub fetched-blob verification is required before marking the active goal
complete and notifying the user. After that verification, stop execution for
the user's switch to Astra Ultra; do not start another Max continuation.

The same signal module 1 / signal image 2 passes all four unchanged dynamic-libc
smokes: memory, files, threads/futexes and signals. Five accepted application
guests total 48 HELLO launches and five core runs. Actual launcher/worker
SIGKILL during a delegated read passes bounded retirement, procfs/process
release, 700 quiet forks reusing both old IDs three times, and eight subsequent
applications in the same OS. Both complete original control-ABI regressions
pass, including their exact physical counters, 72 independent worker reaps and
four inherited-TGID retirements. All 57 native and 37 guest compiler bindings
match the current tested sources. Complete captures, original failures, exact
helpers/commands and module/image identities remain retained.

The user controls the next model switch. Astra Ultra will review the retained
implementation/evidence, fix issues it finds and produce a concrete application
and further-verification plan. That plan needs commands, expected results,
timeouts, failure cases and required evidence. After review, the user intends
to switch to Codex Spark to implement/run that plan. Do not switch models or
start these later phases automatically. Never weaken tests to obtain a pass.

This phase proves a reproducible baseline for broader application testing.
Whole-OS production acceptance, full Rust/assembly completion, multicore/MPI,
long stress and the other documented limitations remain later obligations.
The established isolation, immediate failure logging, Rust preservation,
audited cleanup and periodic verified GitHub checkpoints still apply.
Dated implementation checkpoints below are historical; this status and the
new handoff supersede their descriptions of pending baseline work.

## Active goal and GitHub checkpoints (2026-09-07)

Resume the interrupted McKernel work: restore the existing validation
environment, continue verification, and work through the remaining native
integration and Rust/assembly completion requirements below.

The user explicitly authorizes environment setup and repair, continued
implementation, isolated guest verification, and periodic commits and pushes
to GitHub. Proceed without repeated confirmation for this work. This
authorization supersedes older per-run approval language for isolated guest
checks. Keep the established four-CPU and 12 GiB validation limits.

Preserve progress on the current working branch in `origin` after each coherent
implementation or verification checkpoint, before a long validation run, and
before ending a work session. During sustained work, aim to commit and push
new progress about every 30 minutes. Verify that GitHub contains the pushed
commit. If work is unfinished, make an explicit WIP checkpoint with the exact
checks passed, failures, and remaining work; saving it is not a production
acceptance claim. Preserve existing history and evidence.

The user also requests ongoing disk cleanup. Check host and scratch free space
between substantial validation batches. After a checkpoint is pushed, remove
obsolete expanded captures and extra archive copies only after verifying their
retained evidence against the committed hashes and checking current dependency
paths. Preserve every failed run's evidence and all active source/build/image
inputs. The mounted scratch filesystem uses a sparse backing file: run targeted
`fstrim` on `/home/holden/mckernel-work/scratch` after substantial cleanup so its
free blocks are returned to the host drive. Do not resize or delete that image.

The second cleanup checkpoint is recorded in
`docs/verification/storage-maintenance-20260907-2.json`. It removes eight more
fully archived captures and 38 duplicate archives, then trims scratch. Both
cleanups together reclaim 39.25 GiB of host allocation. All 263 checked current
input/output files remain byte-identical, including the new topology kernel
and module and the passing sysfs tree module. Historical captures can be
restored using the retained cleanup report; never reuse their attempt names.

The third cleanup checkpoint is recorded in
`docs/verification/storage-maintenance-20260907-3.json`. It removes five fully
archived sysfs captures, 29 duplicate archives and 36 user Trash entries
discarded in 2021-2024. Targeted scratch trim completes the 11.81-GiB recovery;
all three cleanups together reclaim 51.07 GiB of host allocation. All 794
checked current files and 18 dependency directories are preserved, including
`native-sysfs-setup-module-20260907-1`. Host free space is about 140 GiB and
scratch free space is about 31 GiB. Retain the compressed archive restoration
mapping; personal Trash content was discarded, with only aggregate metadata
recorded. Continue checking capacity between substantial validation batches.

The fourth cleanup checkpoint is recorded in
`docs/verification/storage-maintenance-20260908.json`. It removes six fully
archived remote-sysfs/protocol captures, 16 extra archives, and old Conda/npm
downloads and inactive browser disk caches last modified before 2026-06-01.
The measured recovery is another 5.38 GiB, including targeted scratch trim;
all four cleanups total 56.45 GiB. All 1,046 checked current files and 20
dependency directories remain intact. In particular, preserve the current
`native-sysfs-remote-module-20260907-4` and
`native-sysfs-request-tests-20260907-3` captures. Host and scratch have about
142 GiB and 31 GiB available. Committed archives preserve all removed failed
runs; the report supplies restoration paths. Current compiler/browser caches,
installed environments, personal files and recent host logs were preserved.

The fifth cleanup checkpoint, after the full-ready service evidence was pushed,
is docs/verification/storage-maintenance-20260908-2.json. Seven completed
captures and 24 duplicate archives were removed only after exact committed
archive comparisons; all failed attempts remain restorable. Targeted scratch
trim returns another 484 MiB of host allocation, for 56.92 GiB across all five
cleanups. All 1,281 checked current files and 21 dependency directories remain
intact, including native-sysfs-service-module-20260908-2. About 142 GiB remains
available on the host and 31 GiB in scratch. Preserve the current module,
kernel, image, build inputs and compressed restoration mapping. New runs must
use fresh attempt names; restore historical captures from Git when needed.

The sixth cleanup checkpoint is recorded in
`docs/verification/storage-maintenance-20260908-3.json`. Eight completed
snooping captures and 35 duplicate archives were removed after exact comparisons
with their pushed evidence. Old Coursier and Poetry download/repository caches,
unused since before 2026-06-01, were also removed. Targeted scratch trim returns
the unused blocks to the host; this pass reclaims another 1.01 GiB, totaling
57.93 GiB across all six cleanups. All 1,777 checked current files and 23 protected
dependency directories remain intact, including snooping module attempts 2 and
3. The host has about 143 GiB free, and scratch about 31 GiB. Use the retained
restoration mapping for removed captures, including failed attempts. Preserve
active compiler/browser caches, installed environments and other workspaces.
Continue checking capacity between substantial verification batches.

The seventh cleanup checkpoint is
`docs/verification/storage-maintenance-20260908-4.json`. After the actual guest
checkpoint was pushed, 2,112 mapped evidence copies in the two new image-source
checkouts and 22 extra retention archives were removed against 1,079 verified
committed files. Targeted scratch trim returns another 5.34 GiB of host allocation,
for 63.27 GiB across all seven cleanups. All 2,016 checked current files remain
byte-identical after trim, and all 25 protected directories remain present.
About 142 GiB is free on the host and 30 GiB in scratch. The source checkouts
now omit only redundant historical evidence; restore those exact Git blobs
using the actual guest manifest before historical replay. Compiler sources,
objects, images, guest captures and failed-attempt records remain intact.

The eighth cleanup checkpoint is
`docs/verification/storage-maintenance-20260908-5.json`. It removes 15,218 exact
committed evidence copies from 41 older scratch checkouts and 22 extra mcctrl
retention archives. All 780 checked retained originals match pushed Git objects;
all 2,831 checked current files remain byte-identical after deletion and targeted
trim, and all 71 protected directories remain present. The backing-file reduction
returns another 10.77 GiB of host allocation, totaling 74.04 GiB across eight
cleanups. About 152 GiB is free on the host and 40 GiB in scratch. The compressed
plan/report maps every removed copy to its exact Git blob, path, mode and timestamp.
Restore those copies before replaying historical validation that consumes the
evidence directories. All compiler sources, objects, images, current executable
attempts and original failure records remain intact. For new compile-only source
copies, avoid duplicating historical evidence when the build does not consume it;
record exact restoration references before omitting files. Full validation must
still have all of its required evidence. Continue capacity checks and GitHub
checkpoints between substantial validation batches.

The ninth cleanup checkpoint is
`docs/verification/storage-maintenance-20260908-6.json`. Fourteen completed
sysfs/mcctrl captures and 19 duplicate executable retention archives were removed
only after full comparisons against 30 verified committed originals. Every failed
run remains recoverable from its complete original archive. All 2,427 checked
current files remain byte-identical after deletion and targeted scratch trim;
all 67 protected dependency directories remain present. Actual backing-file
allocation drops another 846,270,464 bytes (807 MiB), totaling 74.83 GiB across
nine cleanups. About 152 GiB is free on the host and 40 GiB in scratch. The first
read-only audit failed on a repository path outside scratch before any deletion;
the original helper/failure and corrected attempt are retained. Recent host logs,
active caches, personal files, VM disks, other projects and Docker state remain.
Use the compressed restoration mapping before historical replay; retain the
current executable/service modules, kernel, images, compiler and setup inputs.
Continue capacity checks, avoiding redundant evidence copies, and GitHub
checkpoints between substantial verification batches.

The tenth cleanup checkpoint is
`docs/verification/storage-maintenance-20260908-7.json`. Four completed process
guest captures and 18 duplicate retention archives were removed after exact
comparisons with 19 committed originals at the verified GitHub HEAD. Both
failed guest attempts remain fully recoverable with their original evidence.
All 2,678 checked current files remain byte-identical after deletion and
targeted scratch trim, and all 69 protected directories remain present.
The backing file returns another 335,380,480 bytes (320 MiB), totaling
75.14 GiB across ten cleanups. About 152 GiB is available on the host and
40 GiB in scratch. Preserve the current native process module and application
protocol inputs, all existing compiler/image/setup dependencies, and the
compressed restoration mapping. Active caches, personal files, other projects,
VM disks and Docker state remain intact. Continue checking capacity and saving
coherent GitHub checkpoints between substantial verification batches.


The eleventh cleanup checkpoint is
`docs/verification/storage-maintenance-20260908-8.json`. Fourteen superseded
IKC prototype/completion/publication and vDSO test captures were removed only
after complete comparisons against their verified GitHub archives. All four
historical failed attempts remain fully restorable. All 4,158 checked current
files are byte-identical after deletion and targeted scratch trim; all 78
protected directories remain present. The backing file returns another
596,934,656 bytes (569 MiB), totaling 75.69 GiB across eleven cleanups.
About 152 GiB remains free on the host and 40 GiB in scratch. Preserve all
current image module attempts 1-6, image protocol attempt 1 and image guest
attempts 1-2, including the new timeout and emergency diagnostics, alongside
all previous compiler/kernel/image/setup dependencies. Restore removed older
captures from their exact committed archives before historical replay; never
reuse attempt names. Active caches, personal files, installed environments,
other projects, VM disks, recent host logs and Docker state remain intact.
Continue capacity checks and periodic GitHub checkpoints during verification.

## Current accounting and Rust preservation (2026-09-07)

Latest actual thread/futex checkpoint, 2026-09-09:
`docs/verification/native-application-threads-checkpoint-20260909.json` retains
six complete captures and three original failures. TID module 2 / clone3 image
2 passes the unchanged pthread application with full route/result auditing:
actual guest TIDs 308/310/311, 512-byte TID transfer, barrier/mutex/TLS/join,
exact stdout and exit 37, all three procfs nodes removed and full normal
retirement/pager release. Eight HELLO repeats and both metadata/string ABIs
plus continuing boot/sysfs checks pass. The existing allow_oversubscribe boot
option supports two pthreads on one McKernel CPU; original/adapted bootstrap
is retained. Per-delivery trace sampling fixes the original 64-line cutoff;
nine exact adapter tests and all three modules pass with 57 source bindings.
Signals guest 1 remains FAIL at line 142: its second handler uses the normal
stack after the first alternate-stack handler returns. Review the architecture
frame producer's saved SS_ONSTACK state, Rust sigreturn restoration and the
captured interrupted host RET. Keep original assertions/error scanning.
Use TID module 2 and clone3 image 2 as current runtime inputs; signal behavior
has not yet been edited. Three core modes are accepted. Abnormal-owner and
final current-module control regressions/replays remain pending; no Ultra
readiness or whole-OS acceptance.

Latest native running TID transfer checkpoint, 2026-09-09:
`docs/verification/native-application-tids-checkpoint-20260909.json` retains
five complete captures and the original clone3 thread guest failure. Native
clone3 reaches the existing settid path; the old prepared-image-only transfer
rejects its guest kernel TID array, giving -14 at the pthread_create check.
The new host connection preserves the unchanged launcher/TID bytes and public
descriptor, checks exact current worker/delivery/physical span, and retains
the shared payload claim through actual RET publication. All 34 mailbox,
three native user-adapter and 52 payload/zeroing/included-module tests pass.
All three native modules and 57 compiler-source bindings verify, preserving
the same three formatter replays and objtool controls. Next run TID module 1
with clone3 image 2. Enable the existing allow_oversubscribe boot option for
the original two-pthread smoke on one McKernel CPU; retain the exact original
and adapted boot probe. Memory/files are the only accepted core modes.
No actual TID-transfer, thread/futex or Ultra acceptance yet.

Latest native clone3 source/protocol checkpoint, 2026-09-09:
`docs/verification/native-application-clone3-checkpoint-20260909.json` retains
all three protocol attempts and both original fixture failures. The native
Rust clone3 adapter decodes checked versioned arguments and calls the existing
guest clone/lock/fork lifecycle; the earlier ENOSYS-only plan was never applied
and is superseded. All 524 Linux-reference argument vectors and three full
Rust tests pass, along with 144 exact C marker cases per legacy/native profile.
The original context and actual clone result are preserved. Unsupported pidfd,
set-TID, cgroup/namespace, IO and CLEAR_SIGHAND features are explicit errors.
All four image selections now pass in
`docs/verification/native-application-clone3-images-checkpoint-20260909.json`.
Native ELF table slot 435 selects the Rust handler; legacy images omit it,
and slot 56 remains the existing clone. Both exact syscall compiler paths,
native marker bypass, protection and zeroing binary checks pass. All 34 guest
sources and both complete image attempts are retained, including the original
compiler-path audit failure. Next run the unchanged pthread application with
clone3 image 2 and current host zeroing module 2. Preserve all existing images
and captures. No clone3 runtime or Ultra acceptance yet.

Latest actual application checkpoint, 2026-09-09:
`docs/verification/native-application-core-checkpoint-20260909.json` retains
fourteen complete captures, all six failures and exact current module/image
copies. Memory guest 2 and files guest 1 pass the unchanged dynamically linked
libc application, output/exit 37, scheduled cleanup, pager release and eight
HELLO repetitions each. Both metadata/string ABIs and continuing sysfs pass.
Host invalidation and nonempty zeroing now have actual runtime evidence.
Thread guest 1 remains FAIL: unsupported clone3 forwards into the Linux launcher,
returns Linux child PID 311 and crashes with exit 139. The batch stopped before
signals. The later clone3 source checkpoint supersedes the initial capability-only
proposal with an actual guest adapter to the existing clone implementation.
Next build the four images and rerun the original thread test. Do not announce Ultra
readiness until threads, signals, abnormal owners and final regressions pass.
This full checkpoint supersedes the earlier string/pager WIP retention-pending
status; their original records and all expanded attempts remain protected.

Latest native host zeroing checkpoint, 2026-09-09:
`docs/verification/native-application-zeroing-host-checkpoint-20260909.json`
retains nine complete captures and both original audit failures in 13 artifacts,
with all 57 native compiler source bindings. The separate retained
zeroing worker, same-owner extent validation and complete detached-batch ledger
are integrated. Host protocol 2 passes nine focused tests. Native module 2
builds all three modules after exact Rust 1.92 objtool noreturn patch 0025;
the unchanged failing object passes after the patch and all three unknown-callee
controls remain rejected. All 77 targeted configuration/license tests pass.
Original protocol 1, module 1 and patch-contract 1 failures remain protected.
Use `/work/native-application-zeroing-module-20260909-2` with zeroing image 1
for the next unchanged libc memory guest. Neither zeroing nor the nr-11 host
invalidation fix has passed actual guest execution yet. Keep the goal active;
all four core modes and abnormal-owner handling are still handoff requirements.

Latest native zeroing guest/protocol checkpoint, 2026-09-09:
`docs/verification/native-application-zeroing-checkpoint-20260909.json` retains
all four focused attempts, including three original harness failures. Protocol
4 passes three legacy and five native tests: 30 exact C first-fit/guard vectors,
six producer vectors, strict ordinary decoder isolation, checked geometry,
reentrant/late arrivals and three consumers with immediate reuse of 2,048
chunks. Native guest pending consumers now detach whole batches; the one-way
producer marks the contract MCZB0001. The C fallback and legacy Rust keep their
existing selection. This is guest/protocol WIP: the native host queue, bounded
mapping/ledger and third worker are not integrated yet; new image compilation
and actual unchanged libc memory execution are still required. Preserve all
current images/modules and original failure captures. No Ultra readiness.
Subsequent `native-application-zeroing-images-checkpoint-20260909.json` retains
all four successful image builds from d0451679, 30 guest source bindings and
native/legacy binary checks. Native code exchanges the pending head at offset
56, preserves the 48-byte header, publishes at offset 48 and subtracts the
captured page count at offset 44. Rust images exclude the entire C allocator;
the actual Rust object supplies every zeroing export. The unused first audit
draft was cancelled before execution and is retained with the corrected audit.
Use `/work/mckernel-native-zeroing-images-20260909-1/native-rust/kernel/mckernel.img`
after completing and building the matching native host service. These images
have not run in a guest. Host zeroing, unchanged core smokes and abnormal-owner
checks remain required before the Ultra handoff.

Latest native host invalidation/protection checkpoint, 2026-09-09:
`docs/verification/native-application-memory-checkpoint-20260909.json` retains
the exact syscall-11 begin/finish integration around existing Mirror::clear.
Thirty mailbox/protocol tests, eight exact WAIT/RET adapter tests and all three
native module builds pass. The native guest now clears cached host PTEs after
read/write/execute permission changes, including partial-range errors; four
tests pass in each legacy/native selection with an exact legacy C reference.
Original protection protocol 1 is a retained fixture-import failure. Subsequent
`native-application-memory-images-checkpoint-20260909.json` retains all three
image attempts: two diagnostic-tool failures followed by all four image
selections passing. Native disassembly proves the nr-11 offload and VM lock-flag
restoration; legacy keeps its zero return. These images have not executed in a
guest. The allocator zeroing service remains missing; source review requires
fixing concurrent pending-list consumer ownership rather than changing only
the host pop. Preserve the ordinary core application and launcher. Next
integrate zeroing safely, rebuild affected image selections, rerun the unchanged
core modes, and finish abnormal-owner/regression/evidence gates. No Ultra
readiness is claimed.

Latest native file-pager WIP, 2026-09-08:
`docs/verification/native-application-pager-wip-20260908.json` records native
regular-file CREATE/READ/WRITE, shared inode/file references, response-owned
payload claims and an OS-owned RELEASE mailbox independent of launcher/PID
lifetime. Pager protocol 2 passes all 26 tests; original protocol 1 failure is
a retained pathname-length assertion mistake. Module 1 builds all three native
modules, and a separate compiled C/Rust check binds all four Linux file-mode
masks. Original guest 1 remains FAIL: libc loads through four CREATEs sharing
one handle and 473 page reads, then executes memory operations. The first
service EINVAL is the allocator's one-way syscall 279 (requester/response zero),
which needs a separate native zeroing service before generic syscall decoding.
The capture also shows delegated munmap/host invalidation returning ENOSYS.
Neither error may be ignored even if an application returns success. No libc
core smoke or actual pager RELEASE/teardown is accepted yet. Preserve all five
new captures and prior string/core captures pending full archival. Next adapt
existing Rust zeroing and host PTE invalidation, rerun the unchanged application,
then continue the remaining readiness gates. No Ultra handoff yet.

Latest pathname-copy/application-smoke WIP, 2026-09-08:
`docs/verification/native-application-string-wip-20260908.json` records native
STRNCPY_FROM_USER in mcctrl_exec using the existing buffer and shared bounded
reader. Module 2 passes all builds after moving the mcctrl-only adapter out of
the shared SMP module; original warning failure 1 remains retained. Actual
guest 1 passes both LP64/i386 descriptors, 28 guarded data cases, eight
descriptor faults and eight unchanged HELLO/exit-37/retirement launches.
Ordinary dynamically linked libc/pthread core application build 1 passes all
four Linux reference modes. Actual memory guest 1 fails in the dynamic loader:
libc opens and reads, but missing native file-pager dispatch returns ENOSYS on
PAGER_REQ_CREATE. It exits 127 with normal scheduled retirement; no libc core
mode has passed in McKernel. See native-application-pager-review-20260908.json
and the file-pager source review in the application service plan. Keep the
ordinary dynamic application and launcher unchanged while fixing this blocker.
Preserve every new capture pending full archival; continue the four actual
core modes and abnormal-owner gates before announcing Ultra.

Latest actual application checkpoint, 2026-09-08:
`docs/verification/native-application-start-checkpoint-20260908.json` retains
21 complete captures and all six original failures, current module 5, four
rebuilt guest image profiles, 26 protocol/image tests and five exact adapter
tests. Accepted repeat guests 2 and 4 prove sixteen native ELF hello/exit-37
launches, actual WAIT/RET result 25, normal scheduled cleanup, empty process
namespaces and fresh-guest reproduction. Current i386 guest 3 and x86_64 guest
4 preserve the full original control/boot/procfs/reaper regressions. The
corrected RET adapter uses the retained guest CPU, matching the existing Rust
and C host contract, while preserving internal worker/serial/CPU validation.

Six original failures remain fully retained: one native module compile, one
protocol C cast, one final-close/reaper race, one real RET routing error and
two console marker/output interleavings. Verification markers use /dev/kmsg;
final application replay checks stdout files exactly before logging them.
No assertion was removed. Preserve module 5, image 1, return-adapter test 1,
repeat guests 2/4, current ABI guests and all active launcher/compiler inputs.
Next: actual abnormal-owner and memory/file/thread-futex/signal smokes, adding
missing native integration required by those paths. The later string checkpoint
connects STRNCPY_FROM_USER; native file paging now blocks the dynamic libc smoke.
No application-readiness, whole-OS production or Rust/assembly acceptance gate
is promoted.

Earlier native START WIP, 2026-09-08:
`docs/verification/native-application-start-wip-20260908.json` records compiled
START, trusted prepare-target validation, independent procfs TID tracking and
explicit native scheduled-retirement queries. Module 3 passes all three module
builds, with bounded live WAIT/RET tracing. Protocol 2 passes seven new exact
native dispatch/lookup/wire tests and nineteen original protocol/image tests.
Original module 1 and protocol 1 failures are retained. Actual guest images
must now be rebuilt with the native query branch, followed by original guest
regressions, unchanged mcexec hello/exit-37 and the complete readiness baseline.
No application or scheduled-runtime acceptance is claimed. Preserve every
current and failed capture; full archives remain pending at this WIP.


Latest independent reaper checkpoint, 2026-09-08:
`docs/verification/native-application-reaper-checkpoint-20260908.json` retains
passing native module 1, actual guest 3 and guest 5, and all three original
guest failures (serial marker interleaving twice, then a compiler-command bug).
Guest 5 proves 72 worker deaths/quiet-window retirements and four dead TGIDs
retiring while an inherited device binding remains open. Prior 194 root
procfs snapshots/releases and 396 idle WAIT assertions, physical image/boot
and process/sysfs regressions pass; normal poweroff and QEMU exit 0.

Independent Linux worker/TGID reaping is now implemented and guest-tested.
Scheduled McKernel retirement, START and actual application execution remain
pending. Preserve module 1, guest 5, all failed captures and current guest
image/compiler inputs. The retained manifest binds 53 native sources and 13
probe inputs; no application readiness or production acceptance is claimed.
The next work is the explicit scheduled cleanup contract and launch path.


Latest live root procfs checkpoint, 2026-09-08:
`docs/verification/native-procfs-service-checkpoint-20260908.json` retains the
connected production service, original module failures 1-2, passing module 3,
original guest accounting failure 1 and passing actual x86_64 guest 2. Root
procfs passes 194 real snapshots and 194 terminal releases, 64-slot exhaustion
and recovery, 128 repeated opens, partial/duplicate/seek and copy-fault checks.
All 388 replies validate unique tokens, zero errors and exact buffer retirement.
Existing physical boot/image/unscheduled-cleanup and idle WAIT/RET regressions
pass; QEMU exits 0 after normal poweroff. The added traffic is explicitly
verified before preserving the original application packet-count remainders.

Existing application Entries retain procfs contexts; PID/TID publication,
CREATE completion, advisory DELETE and independent namespace removal compile.
Those process paths, direct I/O, interruptions and malformed requests still need
live coverage. Scheduled cleanup and independent dead-worker reaping must be
finished before START and the unchanged launcher baseline. No application has
executed. Do not announce Ultra readiness yet. Preserve current module 3, both
new guest captures, all original failures and previous active image/compiler
inputs. The standalone service is now connected; the old temporary procfs
constructor dead-code allowance has been removed. Continue verified GitHub
checkpoints and audited disk maintenance; no formal acceptance score changes.


Latest actual procfs-image regression checkpoint, 2026-09-08:
`docs/verification/native-procfs-images-checkpoint-20260908.json` retains the
four rebuilt guest images, native module attempts 4 (original dead-code warning
failure) and 5 (PASS), final procfs lifetime fixture 6, and both real guests.
C fallback, legacy Rust, native Rust and sysfs verification image selection,
producer/configuration/ELF/linked-ownership checks pass. Source review and exact
compiler inputs prove procfs.rs is the selected Rust implementation. The native
Exchange::procfs constructor has one documented dead-code allowance while its
real service remains unconnected; request/release constants are local. All
other module warnings remain denied. Remove that allowance when connecting it.

Both guest ABIs reach physical McKernel status 3 and power off normally.
x86_64 retains 396 idle syscall-wait assertions and 47 image/memory assertions;
together the guests retain 306 process, 518 credential, 1,116 executable and
2,112 topology checks, plus 260 continuing sysfs callbacks. All original
assertions remain unchanged. Final procfs fixture source again passes nine
tests per cfg profile. Fifty-one native sources, eighteen fixture inputs,
seventeen guest probes, six module copies and both actual image copies are
bound to retained bytes. Three existing formatter differences are reproduced
with the pinned compiler's formatter. The complete image capture includes an
exact Git blob restoration map for 1,315 omitted historical evidence files
(4,156,777,159 bytes), avoiding their duplication in a compile-only checkout.

No live procfs request/release service or application instruction was exercised.
Next connect the verified VFS owner and terminal exchange to actual procfs nodes,
request-page/peer-buffer ownership, CREATE completion and advisory DELETE.
Then finish independent dead-worker reaping, scheduled cleanup and START, and
run the documented real application baseline before the Astra Ultra handoff.
The old broad-equivalence harness still lacks its recorded historical IHK
sources; do not claim that suite passed. Preserve current module attempt 5,
both procfs-image guests, procfs-image build 1 and fixture 6, plus all previous
active dependencies and original failure archives. Continue GitHub checkpoints
and audited storage maintenance; no formal gate or score is promoted.

Latest selected guest procfs lifetime checkpoint, 2026-09-08:
`docs/verification/native-procfs-lifetime-checkpoint-20260908.json` retains
seven complete captures, including the three original failures. The actual
image selects `kernel/rust/procfs.rs` and removes C procfs from its Rust build;
retain/adapt that complete Rust body. Terminal replies now follow all mapping
and process/thread/VM reference retirement. Maps/pagemap/status deferral sends
no reply, the backlog callback returns the original C retry result, and missing
tasks do not release an unacquired process reference. Preserve both C fallback
and Rust selections, including the deliberate C cleanup/ref corrections.

Both guest cfg selections pass nine tests using the complete selected Rust
body and actual answer producer. Six exact C answer vectors preserve every
legacy response byte; native Linux 6.12 replies add MCPR0001 in the otherwise
unused final eight bytes. Native Exchange requires that marker and matching
token/CPU/PID/request address before completion. Root procfs permits PID zero;
application registrations still require positive PIDs. Nine C backlog vectors,
12,288 queue-full observations per profile, and the existing 19 image/protocol
and 21 mailbox regressions pass. Eighteen compiler bindings and original actual
image sources are retained. The native exchange tests do not supply real
request-page owners or integrate the procfs service.

Next rebuild all four guest image selections and three native modules, then
connect and guest-test the actual procfs service and scheduled cleanup before
START. The new image helper records exact Git blob restoration references
before omitting historical evidence from compile-only source copies. No new
image/module build or application execution is claimed by this checkpoint.
Host/scratch have about 136/38 GiB free. Preserve all failed/current captures
and current build/image inputs; continue periodic GitHub checkpoints. Explicitly
tell the user "We're ready to switch to Astra Ultra" only after the documented
application baseline passes, then stop for the user's model switch.

Latest procfs VFS prerequisite, 2026-09-08:
`docs/verification/native-procfs-objects-checkpoint-20260908.json` retains the
new `procfs_objects.rs` owner and its actual Linux guest verification. All 27
proc_ops/inode/file/credential/configuration values match an independent C
object built against pinned Linux. Two fixture load/unload cycles pass 1,024
concurrent writes and reads, 32 namespace races/64 joined workers, copy faults,
partial I/O, failed opens, credentials, duplicate/name reuse and stale-parent
rejection. Each cycle has exactly 1,039 opens/releases/drops and no live payload
or active callback after root-first removal. Linux waits for the active read;
duplicated held fds remain safe to close after module unload. Two complete
captures, exact sources/binaries and original Linux/project references are
retained in eight artifacts. No failures occurred in this batch.

This owner is verified in a separate module; guest procfs CREATE/read/release
and production SMP selection are still pending. Before freeing native procfs
request buffers, address the original guest's ANSWER-before-unmap ordering,
including deferred backlog execution. A later same-CPU cleanup ACK in the image
fixture is an external barrier observation, not a native procfs retirement
implementation. Retain or explicitly strengthen the peer completion contract;
never infer mapping retirement merely from the current procfs ANSWER. START,
scheduled cleanup and the documented application baseline remain pending.
The user must still receive an explicit notification before the Ultra switch.


Latest native mailbox checkpoint, 2026-09-08:
`docs/verification/native-application-mailbox-checkpoint-20260908.json` retains
eleven complete captures in 29 artifacts, including the original missing-VecExt
module failure and both reproduced queue regressions. The final actual mailbox
source passes 21 tests with exact unchanged C/Rust request/completion/wake
references, owned cancellation, copy rollback, worker identity, response
quarantine, arrival order after slot reuse and cross-CPU completion progress.
All three native modules compile. The response ledger, bounded mailbox,
incoming-packet backpressure and real WAIT/RET adapters are connected to the
existing application entries and exact Linux PID/MM owners.

The current module's x86_64 guest passes 396 idle-waiter and 47 image assertions.
Its 128 interrupted WAIT calls preserve all 11,264 descriptor bytes and reuse
the same worker identity. The existing i386 interface regression also passes;
both guests retain seven physical status-3 captures, 306 process assertions,
518 credential checks, 1,116 executable checks, 2,112 topology queries and 260
continuing sysfs callbacks. Both QEMU guests finish powered off. Fifty-one
native compiler inputs, thirteen protocol inputs, seventeen guest fixtures,
six module copies and unchanged guest peers are bound to exact retained bytes.
All prior assertions and both original failures remain preserved.

No scheduled application request has been delivered. Live response claims,
successful user copyout/RET publication, procfs publication/read/release, START
and scheduled cleanup remain unverified or unconnected. Dead Linux workers
are pruned on new worker acquisition; independent reaping is still needed.
Do not reuse unscheduled-thread cleanup after START or infer application
acceptance from idle waiter tests. Continue toward the current Max readiness
criteria, then explicitly tell the user to switch to Astra Ultra and stop.
Retain current module attempt 3, both final guests and all active image/build
inputs. Host and scratch have about 145 GiB and 38 GiB free.


Syscall protocol prerequisite, 2026-09-08: eleven new tests pass against 25
exact original C/Rust declarations and bodies. Six request vectors and twelve
completion vectors agree with the existing implementations; the actual guest
Rust wake consumer accepts the new packet. Copyout/requeue and worker-token
reuse are state tests; 1,024 simulated send failures retain completion, and
256 real atomic deschedule races verify result visibility. The 4,096 concurrent
delivery/RPC tokens remain distinct. The nineteen previous protocol/image tests
pass again. All three native modules build with the new protocol selected for
compilation only; its mailbox, response-memory claims and user WAIT/RET adapters
are not connected. No new guest run or application execution is claimed.
See `docs/verification/native-application-syscall-checkpoint-20260908.json`:
four complete captures, fourteen artifacts, fifty native source bindings,
twelve syscall fixture bindings, fifteen existing image/protocol bindings,
four unchanged actual guest source bindings and seven pinned Linux reviews.
The original successful capture's generated unused-import warning is retained;
the final syscall build enforces Rust warnings and passes. Three exact formatter
replays bind the existing differently formatted native sources. Preserve
native-application-syscall-20260908-2, native-application-image-20260908-7 and
native-application-syscall-module-20260908-1 alongside the previous actual guest
module native-application-service-module-20260908-2, launcher build 2 and all
established kernel/image/compiler/setup inputs. The last real launcher still
fails at START_IMAGE after preparing its ELF. Next connect the bounded native
mailbox and incoming backpressure, exclusive response spans, referenced worker
and MM ownership, user copies/waits/returns, actual procfs and scheduled cleanup
before enabling START. All earlier application, VM, signal, fork/exec/exit,
race/fault, multi-CPU/OS, shutdown, declared integration/current full suite,
full Rust/assembly and independent acceptance requirements remain. Root and
scratch have about 149/39 GiB free. Continue audited cleanup as needed and
periodic GitHub checkpoints; no formal score or production gate changes.

Actual native launcher checkpoint, 2026-09-08: the unchanged Rust-selected
`mcexec` now prepares an ordinary ELF and reaches START_IMAGE in the real guest.
START still returns EINVAL; no application instruction has executed in McKernel.
The Linux reference prints its marker and exits 37. Actual guest kmsg confirms
the prepared ELF entry 0x40010c and one unscheduled thread; final close consumes
cleanup ACK plus exact TID-zero deletion and releases the registration.
Two concrete integration fixes are verified: OS GET_BUILDID now reuses the
existing exact IHK compatibility payload, and image validation accepts the
terminal-length encoding produced by both original C and Rust launchers.
Both metadata interfaces pass eight bounded writes and twenty copyout faults
over running and unbooted instances, including operation with mcctrl absent.
All nineteen protocol/image tests pass, retaining the original seventeen and
adding six exact C/Rust producer vectors plus terminal-length bounds coverage.
Native application-service module 2 passes both existing ABI regressions, all
47 x86_64 image assertions and seven physical status-3 captures. Both actual
launcher selections build; C fallback application execution remains untested.
See `docs/verification/native-application-launcher-checkpoint-20260908.json`:
fifteen complete captures, all seven original failures, 41 artifacts, 49 native
compiler bindings, twenty Linux probe bindings, fifteen protocol bindings,
seven launcher source bindings, all 226 actual launcher compiler dependencies,
eleven unchanged guest peer bindings and three exact formatter replays.
Source checkouts omit only mapped committed evidence archives to conserve space;
the retained captures themselves have no exclusions. Preserve
native-application-service-module-20260908-2,
native-application-image-20260908-6 and native-application-launcher-20260908-2,
alongside the established kernel/image/compiler/setup and prior active inputs.
Next implement actual START, syscall wait/return, procfs and scheduled-process
ownership, then verify application execution. All earlier signal/VM/fork/exec/
exit, fault/race, multi-CPU/OS, shutdown, source-graph/staging/lifecycle/FFI/
current-full-suite, full Rust/assembly and independent acceptance work remains
required. This is verified launcher progress, not application or production
acceptance. Continue capacity checks, audited cleanup and periodic GitHub pushes.

Native prepared-image/VM checkpoint, 2026-09-08: native module 8, image
protocol attempt 3, x86_64 image guest 4 and i386 baseline regression 1 pass.
The actual guest prepares one unscheduled thread and two image sections. All
47 image assertions pass: 12,288 transferred bytes, 16,384 explicit readback
bytes, 24,576 mirror comparison bytes, same-MM data writes and readonly-text
SIGBUS, capability restoration, bounded transfers, PTE clear/refault and
mapping-held unload vetoes. Independent capture verifies all 12,288 physical
image bytes and three page walks. Prepared cleanup retains its registration
through the matching ACK and exact advisory TID-zero deletion; a subsequent
same-CPU request supplies a handler-completion barrier. The original ABI
regressions pass again with 306 PPD checks, 518 credential checks, 1,116
executable checks, 2,112 topology queries and 260 continuing sysfs callbacks.
Seven physical ready captures pass. Seventeen state/image tests retain the
original C/guest Rust layouts and exact request/reply/deletion construction.
See `docs/verification/native-mcctrl-image-checkpoint-20260908.json`: all 16
complete captures and seven original failures, 41 artifacts, 49 native compiler
bindings, 16 Linux probe bindings, 12 protocol bindings, 11 unchanged guest peer
bindings, three exact formatter replays and 16 pinned Linux reference sources.
The fixed failures include Linux anon-inode noexec policy, PFN write-notify
return semantics and unscheduled thread deletion; none were suppressed.
Preserve native-mcctrl-image-module-20260908-8 and
native-application-image-20260908-3 alongside all existing compiler/kernel/image,
process/executable/service/snooping/setup dependencies. The i386 run verifies
existing interfaces only: compatibility image preparation remains unsupported.
No native application has executed. START, full syscall/signal/procfs service,
scheduled-thread/fork/exec/exit ownership, running-VM invalidation/pinning and
remote faults, mprotect/mremap, actual timeout/queue-full/duplicate/reuse/removal
fault injection and multi-CPU/OS operation remain required. DELETE has no wire
operation token; the retained unscheduled identity and ordered delivery do not
prove full running-task lifecycle or final allocator retirement. Continue all
declared staging/source-graph/lifecycle/FFI/current-full-suite work, full
Rust/assembly retirement, shutdown, remaining sysfs faults/races and independent
acceptance. Keep capacity checks, audited cleanup and periodic GitHub checkpoints.

Native process registration/cleanup checkpoint, 2026-09-08: module attempt 1,
protocol attempt 1, x86_64 guest attempt 3 and i386 guest attempt 1 pass. Both
interfaces verify 306 PPD assertions, 146 real registrations and matching cleanup
acknowledgements, 148 duplicate rejections, six copy faults, four explicit
unsupported mirror-VM requests, two 64-slot exhaustion/reuse phases, 138 joined
fork workers and 142 exact process-file context retirements. Independent final
queue captures show all 146 request/reply exchanges, with six physical status-3
captures. Existing executable/credential, file/topology and 260 continuing sysfs
callback regressions pass. Eight state/body tests cover the traditional protocol,
late/wrong replies and 4,096 concurrent tokens using exact guest Rust/C sources.
See `docs/verification/native-mcctrl-process-checkpoint-20260908.json`: six
complete captures, both harness failures, 18 artifacts, 46 native compiler
bindings, 14 Linux probe bindings, seven protocol bindings, four unchanged image
peer bindings, three formatter replays and four pinned Linux review sources.
Preserve `native-mcctrl-process-module-20260908-1` and
`native-application-protocol-20260908-1` as current inputs alongside the existing
kernel/image/executable/service/snooping/compiler/setup dependencies. The bounded
registration owns a cleanup reservation and exact OS/backend connection; an
unpublished loser cancels only its own reservation. Published requests outlive
a departing waiter. Real guest timeout/queue-full injection and removal races
still need coverage. Only unprepared registration is exercised: acknowledgements
precede guest terminate_host and do not prove prepared-task termination. Shared
inherited files still retain process bindings until final file close. Native
applications have not run; continue image/VM preparation, transfer/start, syscalls,
procfs and full process exit, non-null CREATE_PPD parity, same-TGID races and the
accumulated declared-stage/FFI/current full-suite integration. Full Rust/assembly,
shutdown, multi-CPU/OS, remaining sysfs faults/races and independent acceptance
remain required. Keep capacity checks and periodic GitHub checkpoints.

Native executable/credential checkpoint, 2026-09-08: production module attempt 2
and actual x86_64 guest attempt 4 / i386 attempt 1 pass. Both ABIs verify 518
current-caller credential comparisons, six user-buffer faults, 1,116 executable
file checks, six exact executable-context retirements and two four-worker phases
per ABI. Replacement rollback, write exclusion, separate/duplicate descriptors,
forked PID isolation and final file release pass. The normal-image boot/sysfs
regressions pass with four physical status-3 captures and 260 continuing callbacks;
the repeated file-service checks add 2,112 topology queries and 16 unload vetoes.
See `docs/verification/native-mcctrl-exec-checkpoint-20260908.json`: seven captures,
all four failures, 19 artifacts, 43 native compiler bindings, 12 Linux probe
bindings, three exact formatter replays and six pinned Linux review sources.
The empty-path fixture expected ENOENT incorrectly: the exact Linux open_exec
uses getname_kernel, selects cwd and rejects directory execution with EACCES.
Only that test expectation changed; the production module stayed byte-identical.
Preserve `native-mcctrl-exec-module-20260908-2` as the current input alongside the
existing kernel/image/setup and prior verified service dependencies. Native process
retirement still follows final file bindings; abrupt exit while another process
holds an inherited descriptor needs the complete PPD/process lifecycle adapter.
Native procfs publication and applications have not run. Continue per-process/VM,
image prepare/transfer/start and syscall services plus the accumulated declared
staging/FFI/current full-suite integration. Full Rust/assembly, shutdown, multi-CPU/
OS, remaining sysfs faults/races and independent acceptance remain required.

Native application service checkpoint, 2026-09-08: IHK now owns a versioned
mcctrl callback registration and lazily attached per-file context/module lease.
Ready/Running application requests run outside the file-publication and OS
operation locks. Native mcctrl GET_CPU/GET_NODES query the exact retained boot
topology and continuing-service health. Both real guest ABIs pass 2,112 topology
queries, 16 joined workers, eight context open/close pairs, ten module load/unload
cycles and 16 file-held unload vetoes. Four pre-ready, 12 absent-service and four
unsupported-image requests are rejected. Both normal-image boots and 260 continuing
sysfs callbacks pass again, with four physical status-3 captures. See
`docs/verification/native-mcctrl-service-checkpoint-20260908.json`: 14 artifacts,
both harness failures, all native/compiler bindings and three exact formatter
replays are retained. Preserve `native-mcctrl-service-module-20260908-2` as the
current three-module input, alongside the existing kernel/image/setup dependencies
and original snooping modules. The first builder's misnamed capture has an exact
relocation map; never reuse historical attempt names. Applications have not run.
Next adapt executable/credential ownership and per-process/VM/image/syscall services
from existing Rust helpers, and integrate the accumulated native stage/FFI/source
graph changes. Full-suite, shutdown, multi-CPU/OS, remaining sysfs fault/race work,
full Rust/assembly and independent production acceptance remain required.

Actual guest sysfs checkpoint, 2026-09-08: the default-OFF
ENABLE_NATIVE_SYSFS_VERIFY profile builds alongside the three normal image
profiles. Both startup ABIs pass the actual guest fixture: 104 metadata requests,
18 expected metadata errors, 18 special reads, 520 independent value reads,
512 stores, 16 exactly-once data release callbacks, full-capacity transfers and
complete fixture retirement. Both normal-image startup regressions also pass.
The four runs retain eight physical status-3 captures and 1,606 real callback
exchanges, including 520 post-ready calls and 256 independently checked online
store payloads. Applications and shutdown are still untested. The guest sample
string now passes its bytes, matching the original C instance contract. The
absent ordinary guest store retains EIO; host-local snooping retains ENOSPC.
See docs/verification/native-guest-sysfs-checkpoint-20260908.json for nine
captures, all three first failures, 22 artifacts, 32 native module source
bindings, 68 guest source bindings and 18 Linux probe source bindings. The image
archives omit only verified copies of earlier committed evidence and include
their complete restoration mapping. Preserve native-sysfs-snoop-module-20260908-3,
mckernel-native-sysfs-images-20260908-2 and the original passing image family 13,
plus the established kernel/setup/build dependencies. New runs need fresh attempt
names. Worker/queue and remaining metadata fault injection, actual removal races,
multi-CPU/multi-OS operation, native application services, application execution,
shutdown, current full-suite, full Rust/assembly and independent acceptance remain
open. No production gate is promoted by this checkpoint.

Bitmap boundary checkpoint, 2026-09-08: module attempt 3 and Linux guest
attempt 3 pass. Complete output ending exactly at its newline is accepted
without requiring a copied NUL. Both lifetimes pass 274 C format comparisons,
274 exact-capacity comparisons, 274 truncated-output rejections, two real
4,095-byte bitmap reads and two Linux ENOSPC store checks. All earlier scalar,
claim/capacity/alias and callback/mapping retirement checks pass again. Both
actual starts also pass with module 3 (attempt 2 for each ABI), including four
physical status-3 captures and 260 real callbacks. See
docs/verification/native-sysfs-snoop-boundary-checkpoint-20260908.json for 16
artifacts, 44 current source/compiler bindings, three exact format replays and
references to all earlier failures. Preserve native-sysfs-snoop-module-20260908-3
as the current module input. Its kernel/image/setup dependencies remain the
established pinned ones. The container resource limits remain unchanged.
Next exercise real guest special operations, mkdir/unlink/release and continuing
packet/metadata failure paths, then native application service integration.
Multi-CPU/multi-OS operation, applications, shutdown, current full-suite and
the full Rust/assembly and production acceptance scope remain open.

Prior snooping/mapping checkpoint, 2026-09-08: module attempt 2 builds
all three production modules and separate Rust/C verification modules. Guest
attempt 2 passes two module lifetimes: 272 exact legacy-format comparisons,
2,560 concurrent scalar reads, 128 two-task claim collisions, 66-slot request
exhaustion/reuse, alias exclusions and two real callback/mapping drains. All
six workers join and both namespaces retire. The first guest failed because
Snoop inherited EIO for absent store; the existing dispatcher requires ENOSPC.
That production override is fixed without weakening the expectation. Scalar
loads now use one aligned word and bounded strings preserve precision behavior.
Preserve native-sysfs-snoop-module-20260908-2 alongside current dependencies.
The fixture uses diagnostic extent/identity carriers and module-owned RAM;
it does not claim IHK authority or actual continuing metadata dispatch. Both
actual startups also pass with the corrected modules: BOOT=0, registry Ready=4,
four physical status-3 captures and 260 real callbacks with checked write
payloads. See docs/verification/native-sysfs-snoop-checkpoint-20260908.json:
19 artifacts, 44 current source/compiler bindings, three pinned-format replays
and the full first guest failure. Direct real-guest snooping/metadata failure
coverage remains open. The subsequent bitmap boundary checkpoint above corrects
and verifies the exact-capacity issue found in this initial source review.

Continuing service checkpoint, 2026-09-08: both actual startup interfaces now
reach full McKernel readiness. BOOT returns 0, the native registry is Ready=4,
and four independent QMP captures show physical status 3. Each one-CPU start
completes seven real metadata requests and 130 actual guest callbacks: 66 reads
and 64 writes. Both CPU symlinks resolve correctly; all queue counters drain.
The unchanged guest store_fake_cpu_info logs and acknowledges the write bytes
without changing online. All 128 payloads are independently checked in guest
kmsg; no value-mutation or CPU-hotplug credit is claimed. Applications have
not run. The earlier status-2 limits below describe historical checkpoints.

See docs/verification/native-sysfs-service-checkpoint-20260908.json: 24 retained
artifacts, 42 source/compiler bindings, three exact pinned-format replays and
all three failures. Module attempt 1 failed compilation; actual x86_64 attempt 1
used the wrong QEMU CPU/machine profile, and attempt 2 failed an incorrect
store-mutation expectation after reaching status 3. The accepted starts are
x86_64 attempt 3 and i386 attempt 1 using guest helper v3. Preserve current
native-sysfs-service-module-20260908-2 and all existing active dependencies.

smp_service.rs transfers the
published tree and channels into two retained, initially stopped kthreads,
then activates them after BOOT releases CPU/device/topology/memory guards.
The packet worker remains independent of the bounded metadata/tree worker.
sysfs_memory.rs shares the existing complete-extent address checker, claims
metadata exclusively, excludes active snooping/data/queue aliases and retires
claims before the final busy store. sysfs_snoop.rs implements the eight
existing guest snooping formats with bounded copies. Five metadata handlers
use the existing Tree and Remote owners; remote calls use port 501/CPU rank 0.
Module attempt 2 now compiles all three native modules and the remote Linux
fixture, with no SIMD/FPU use. Exact setup/extent checks pass under service
ownership attempt 1. Preparation attempt 1 passes both ABIs and two module
lifetimes, including 404 namespace checks, 32 allocation failures and four
physical captures with full unstarted restoration. Initial module attempt 1
failed allocator conversion and initializer capture; its complete artifacts
remain retained. The continuing workers now pass the actual starts above.
Next verify mkdir/unlink/remote release, all eight snooping formats, metadata
claim races, malformed mappings, queue pressure and worker allocation failures.
Scalar snooping now has the aligned-load checks above. Multi-CPU/multi-OS operation,
application execution, full shutdown, current full-suite integration and the
remaining Rust/assembly and independent acceptance checks remain required.
No production gate is promoted by this local one-CPU boot/service checkpoint.

Native remote callback checkpoint: all three native modules and the real
Linux fixture build on the pinned topology kernel. Two fixture lifetimes pass
512 concurrent write/read round trips, 1,068 exchanges with forced queue-full
retries, two interrupted-reader/late-response checks, two concurrent callback
drains, 18 remote releases, four page-boundary checks and eight error checks.
Failed duplicate creation preserves the original and does not release the
guest token. Both namespaces retire. See
`docs/verification/native-sysfs-remote-checkpoint-20260907.json`: 16 retained
artifacts, 31 source/compiler bindings and all three initial build/harness
failures. Final module attempt 4 and guest attempt 1 pass; preserve module 4
as a current verification dependency. The fixture owns its own page and uses
a diagnostic identity, not IHK authority or actual McKernel memory.
Next integrate the continuing packet pump, exclusive metadata claims, all
request handlers and special snooping. Actual boot remains at CREATE/status 2;
there is no new application or production acceptance credit.

Continuing sysfs protocol checkpoint: `abi/sysfs_request.rs` decodes all five
metadata requests into owned snapshots and publishes error/optional handle
before busy. `sysfs_rpc.rs` serializes one shared buffer with unique response
tokens and retains outstanding ownership across waiter interruption. Seven
actual-body tests pass, including 32 unchanged-C layout values, 2,560 concurrent
metadata exchanges and 4,096 responses through nine existing guest Rust bodies.
See `docs/verification/native-sysfs-request-protocol-20260907.json` for eight
artifacts and exact original/compiler bindings. Initial fixture compilation
failure and the first helper's original-source retention limitation remain
recorded. Final attempt 3 preserves and verifies both complete source sets.
The Linux `sysfs_remote.rs` adapter now passes the separate callback checkpoint
above. Next integrate the retained packet pump, metadata claims, special
snooping and actual CREATE. Both real startups still stop at CREATE/status 2;
no new guest service, application or production credit.

Native sysfs setup runtime checkpoint: both actual startup interfaces now
complete SYSFS_REQ_SETUP through the integrated topology owner and the new
kernel. Each OS exposes 52 checked files, 19 directories and four links. QMP
captures both port-503 rings progressing from vDSO through setup to the next
real SYSFS_REQ_CREATE (0x30), for /sys/devices/system/cpu/num_processors, busy=1.
Architectural status remains 2; BOOT returns -110/Failed and retains all started
owners. Full ready status 3 and applications are still unproven. Preparation
passes both ABIs over two module lifetimes with 404 namespace checks, 32 original
forced boot-allocation failures, four physical captures and full unstarted
restoration. Both starts preserve another four namespace and 60 borrowing
checks. See docs/verification/native-sysfs-setup-checkpoint-20260907.json for
15 artifacts, exact compiler bindings and the retained initial packaging error.
Next adapt continuing sysfs create/path/remote callbacks and runtime dispatch,
then application execution, shutdown and the full language/integration/
acceptance requirements. No production gate or application-test credit.

Prior sysfs setup build checkpoint: CpuContext now retains owned topology
snapshots and validates online reservations. The three native modules and
setup fixture build on the topology-export kernel. Three protocol tests pass,
including six independent C layout values and 4,096 concurrent replies. Two
actual extent/reply-body tests check exact generations, all queue/data/vDSO
aliases and error completion. The Linux fixture passes two module lifetimes,
44 topology comparisons, partial-publication rollback, 97 files/27 directories/
seven links, 582 exact file reads and four CPU offline/online cycles. All fixture
namespaces retire. See native-sysfs-setup-build-checkpoint-20260907.json in
docs/verification for 14 retained artifacts and compiler bindings. At that
checkpoint the actual OS exchange was still unverified; the subsequent runtime
checkpoint above supplies it. Neither result proves application acceptance.

Native topology producer checkpoint (2026-09-07 local date): patch 0009 adds
only the existing Linux get_cpu_cacheinfo GPL export. The kernel and three
existing native modules rebuild; generated Rust bindings and C declarations
stay unchanged. smp_topology.rs owns CPU/cache fields and masks copied under
CPU hotplug exclusion. Its disposable module passes all 45 independent C/Rust
layout values and real Linux comparisons: 376 field/mask checks, 32 cache-leaf
checks and 24 unchanged snapshot reads across two offline/online cycles and
two module lifetimes. See docs/verification/native-topology-checkpoint-20260907.json
for retained sources, inputs and both guest failures, including the recovered
failed recorder state. No production gate or actual sysfs setup is claimed.

The global native build now contains the cacheinfo-export kernel captured as
/work/native-topology-kernel-20260907-1. The snapshot module is captured as
/work/native-topology-module-20260907-1; passing guest attempt is 3. Older
/work/native-vdso-kernel-20260907-3 remains preserved for its original evidence.
Use the new kernel when importing get_cpu_cacheinfo. Integrate the owned
snapshot into CpuContext before reservation, validate new reservations against
saved identity and current online membership, and use the retained values in
the real sysfs setup tree. Linux clears core_id and core-sibling membership on
offline. This QEMU model's raw cache masks can retain offline bits because its
valid cache IDs differ; use the observed masks, not reconstructed sharing.
The new kernel still needs actual McKernel startup regressions after integration.

Native sysfs tree checkpoint (2026-09-07 local date): the native PreparedBoot
owner now contains the Rust tree, with checked nonpointer handles, bounded path
validation and iterative teardown. All three native modules and the actual
tree fixture build. Two disposable Linux module lifetimes match 60 operations
from 15 unchanged legacy C bodies, validate stale/foreign handles and protected
roots, remove a 509-level tree, and drain active callbacks before namespace
retirement. OS preparation preserves 404 namespace checks, the original 32
allocation failures, four physical captures and full resource restoration.
Both real startup interfaces preserve vDSO completion, four more namespace
checks and 60 borrowing checks. See the 21 retained artifacts in
`docs/verification/native-sysfs-tree-checkpoint-20260907.json`, including the
first fixture compiler failure. Original/compiler bytes and explicit old-source
rustfmt replays are bound; artifact hashes and complete gzip streams pass.

This closes the bounded tree adapter checks, not the sysfs setup service.
Production OS trees still contain only protected roots; actual starts remain
at architectural status 2 with SYSFS_REQ_SETUP busy=1. Next capture real CPU/cache
topology before CPU offline, adapt the existing Rust setup file sequence, own
the shared data/request buffers and complete the actual request. Keep working
toward full ready status, continuing host service, applications, shutdown and
the full Rust/assembly, declared integration and independent acceptance gates.

Native OS-device sysfs checkpoint (2026-09-07 local date): the native SMP
prototype now consumes the production directory owner and attaches `/sys`
to the actual generation-owned mcos Linux device. The additive IHK borrowing
export retains an exact-generation registry lease during its synchronous
callback, without reacquiring the backend's operation mutex. PreparedBoot
owns the child; unstarted cleanup retires it before device destruction, while
started storage retains it. No parallel device or new C implementation body.

All three native modules and the borrowing fixture build, pass no-SIMD checks
and match the independent device-layout witness (760/8/0). Both preparation
ABIs across two module lifetimes pass 404 namespace checks, minor reuse,
32 original boot allocation failures, four physical captures and full
unstarted restoration. Both actual starts add four namespace checks and
retain their roots after incomplete BOOT and refused destruction. Four
fixture lifetimes pass 60 borrowing checks, including invalid/stale identities,
exact parent names and callback errno boundaries; 20 callbacks execute.

See `docs/verification/native-sysfs-os-checkpoint-20260907.json` for 19 retained
artifacts and exact source/compiler bindings, including the initial fixture
modpost and retention failures. Older formatting differences are bound by an
exact pinned-rustfmt replay, with original and compiler bytes retained. All
capture hashes and gzip streams pass. Callback/destruction races and every
new sysfs allocation-failure point remain outside this checkpoint's coverage.

Both real McKernel starts still complete vDSO and reach architectural status 2,
then stop at SYSFS_REQ_SETUP with busy=1. The root is empty and never exposes
setup_complete. Next implement the native tree/path/handles, real topology and
setup files, shared-buffer ownership and request dispatch; then continuing
host services, full ready status and the application launcher/tests. Native
shutdown, declared staging/contracts/full-suite integration, full McKernel/
linked-support Rust or assembly completion and independent production acceptance
remain open. No full boot, application test or production gate credit.

Native sysfs object checkpoint (2026-09-07 local date): the actual Rust
directory/file/link owners now pass two disposable Linux module lifetimes.
All 21 generated layout values match an independent C witness; final module 5
passes compilation and ELF/no-SIMD checks. Rust Arc/mutex state serializes
direct parent removal against file/link operations, as required by the pinned
Linux sysfs implementation. Linux's existing target lock protects symlink
targets without taking a second Rust namespace lock.

Final guest 5 passes 1,024 concurrent writes and reads, 32 races between parent
and file retirement with 64 joined kernel threads, failed duplicate directory/
file/link publication, invalid names, replacement-tree survival, numeric/error
and callback byte-count checks. Both module removals observe an active callback
and wait for it; all Value payloads retire and the namespace disappears. The
pinned kernfs rejects seek on an already-open removed file with ENODEV.
See `docs/verification/native-sysfs-objects-checkpoint-20260907.json` for
27 hash-verified artifacts and complete gzip checks, including the static-libc
failure, two initramfs preparation/execution failures and the initial removed-
file seek expectation failure. Earlier failed attempts remain FAIL.

At that object checkpoint the consumer was the disposable verification module.
The subsequent OS-device checkpoint above attaches these owners; next adapt the existing Rust
tree, setup files/topology and request dispatch described in
`docs/verification/native-sysfs-integration-plan.md`. No actual McKernel
SYSFS_REQ_SETUP response has completed; its boot still stops at that request.
Continuing host services, full ready status, application launch/tests, native
shutdown, full Rust/assembly completion and production integration/acceptance
remain open. No production gate credit or new McKernel boot milestone.

Native vDSO service checkpoint (2026-09-07 local date): both actual-start ABIs
now complete the versioned 128-byte exchange. Independent QMP captures match
the Linux text/time/RNG pages, all descriptor bytes, guest validation state 2,
the unchanged 88-byte legacy object and its container geometry. McKernel logs
that vDSO is enabled and advances to a real SYSFS_REQ_SETUP (0x40), whose
request and data pages are captured with busy still set. The corrected capture
uses sysfs_arg1 at packet byte 24; vDSO uses the traditional argument at byte 40.
The first capture's wrong payload decoder and its emergency evidence remain
retained. BOOT still returns -110/Failed with all started owners retained;
architectural status 2 is proven, full ready status 3 is not.

The host validates the whole descriptor extent, OS generation, every active
queue and exclusion of Linux pages from all reserved McKernel memory before a
one-shot release/acquire reply. Native boot note 3 requires the new descriptor;
the queue ABI remains revision 2. The guest adds explicit generic data mappings
and reads the pinned Linux clock layout. Native clock syscalls honor Linux's
current mode and otherwise forward; legacy local-time flags remain disabled.
TCG selects VDSO_CLOCKMODE_NONE, so runtime evidence covers live/coarse time,
not accelerated TSC/PV/Hyper-V clocks or complete syscall offload.

Four source-check captures pass, including 128 concurrent cross-page exchanges,
77,824 exact Linux arithmetic comparisons, 144 original-C/Rust mapping cases,
all optional data-page sets, callback failures and actual host ownership checks.
All three images build in attempt 13, and prototype 9 builds all three native
modules with layout/ELF/no-SIMD checks. The actual image parser verifies native
revisions 1/2/3. Preparation passes both ABIs over two module lifetimes with
32 forced allocation failures, old-capability rejection and full unstarted
restoration. Native image SHA-256 is
`c37e6e7d30e09079003bcb9ed80baf27acc18f9d60d472e79826629b01a62e80`,
entry `0xfffffffffe846c00`, loaded-window FNV `aa6419ab7afa5442`.
See `docs/verification/native-vdso-service-checkpoint-20260907.json` for
47 retained artifacts, including two prototype build failures, the native
image link failure and the first startup capture failure. All artifact hashes
and gzip round trips pass; 26 final native compiler inputs and current guest
inputs are bound. The manifest distinguishes retained formatted inputs from
the incomplete original pre-format bytes in source-check attempts 1-3.

Next adapt the existing Rust sysfs service, then continuing host dispatch,
remaining mcctrl services, full status 3 and applications. Supplemental
application mappings currently have actual-body callback evidence only.
Declared staging/lifecycle/unsafe-FFI/license bindings, current full-suite
integration, native shutdown, full McKernel/linked-support Rust or assembly
completion and independent production acceptance remain open. The earlier
intermittent Linux idle/RCU stall remains unresolved. No production gate credit.

Prior native vDSO export checkpoint (2026-09-07 local date): patch 0008 builds the
pinned Linux kernel and prototype 5's three native modules. Normal C
preprocessing is unchanged. The read-only Rust fixture and independent C
witness agree on all 44 layout values and pass module ELF/no-SIMD checks.
Preparation and both actual-start guests pass, each with two fixture lifetimes
and 32 coherent time samples checked against Linux time. QMP independently
captures the Linux text/time/RNG pages, matches the live text hash and verifies
disjointness from assigned McKernel memory. The control connections and first
vDSO request still pass both ABIs with the rebuilt Linux kernel. See
`docs/verification/native-vdso-exports-checkpoint-20260907.json` for 34 retained
artifacts, including two binding failures and their generated outputs. The
final patch excludes private user-space helper headers only in Linux's existing
__BINDGEN__ mode. TCG uses VDSO_CLOCKMODE_NONE: these checks prove live data and
coarse time, not accelerated TSC operation. At that checkpoint the original
88-byte descriptor remained busy; the subsequent native service result is
recorded above and in `native-vdso-integration-plan.md`. Neither checkpoint
claims full boot, application, shutdown or production acceptance.

Native control-channel checkpoint (2026-09-07): both actual-start ABIs now
accept ports 501 and 503 and deliver McKernel's first real vDSO request over
Linux IRQ-work. Independent QMP captures verify all four regular queue
mappings, exact master packets, CPU/channel identities and disjoint ownership.
Master receive counters reach (2,2,2), send counters reach (3,3,3), and port 503
consumes SCD_MSG_GET_VDSO_INFO. The complete 88-byte descriptor is still busy
while awaiting the actual host service. Both preparation ABIs also pass over
two module lifetimes with 32 forced allocations and full unstarted restoration.
Prototype 4 builds all three modules and passes exact layout/ELF/no-SIMD checks.
See `docs/verification/native-control-channels-checkpoint-20260907.json` for
27 retained artifacts, including the initial compiler and log-capture failures.
All channel allocation and routing run in BOOT process context; the IRQ only
signals. Started owners remain retained on incomplete BOOT. Next adapt the
existing Rust vDSO service and guest consumers to the pinned Linux's generic
vDSO layout, then sysfs/mcctrl, asynchronous runtime service, full status 3 and
applications. Declared integration, native shutdown, complete Rust/assembly
ownership and independent production acceptance remain open. No gate credit.

Native queue completion checkpoint (2026-09-07): the native guest reader now
releases slots after copying or handling, with a reserved-word claim excluding
concurrent/reentrant readers. The host has a producer-only view requiring that
contract; its previous sole-consumer and initial-only interfaces are preserved.
Native boot note revision 2 advertises completed reads. Revision 1 stays
loadable but native preparation rejects it before taking startup resources.
Actual C/legacy/native sequential queue results match over 13,312 packets;
four host producers and four guest readers pass 16,384 packets through eight
slots, with paused-handler/backpressure and invalid-input coverage. Seven queue,
six master and 56 image/resource policy tests pass. All three images and native
prototype modules build. Both ABIs pass preparation over two module lifetimes
and actual initial IKC replays with independent physical captures. See
`docs/verification/native-ikc-completion-checkpoint-20260907.json` for the retained
C/PIE fixture failure, image-extraction mutation, exact-byte restoration and
passing retries. Current native image SHA is
`8c7703327cca094c7c55664bca3288aea8e300371959ad630608c9d3c92722ca`.
Runtime still sends only INIT_ACK and receives the first CONNECT; repeated
exchange is currently proven in the actual-body fixture. Next implement owned
listener acceptance, regular channels and host services, then full readiness
and applications. The boot plan records why even the port-501 Send listener
must allocate a receive queue and defer allocation outside IRQ context.
Declared integration, full Rust/assembly completion, native shutdown and
independent production acceptance remain open. No gate credit is claimed.

Initial native IKC checkpoint (2026-09-07): the new APIC binding kernel and all
three native prototype modules compile; seven queue and six master tests pass.
SET_KARGS now retains the legacy bounded read/truncation semantics and exact
OS generation. Both ABIs over two preparation cycles pass argument faults,
truncation, preparation retirement, 32 forced allocations, four physical
captures and full unstarted restoration. A cleanup fixture initially assumed a
single 128 MiB contiguous chunk; its failure is retained and the corrected
probe verifies all returned bytes/chunks before using the existing release API.
Actual native and compat starts now receive INIT_ACK on McKernel and deliver a
port-501 CONNECT back through real Linux IRQ-work. QMP confirms both queue
counter transitions and exact packet fields. See
`docs/verification/native-ikc-handshake-checkpoint-20260907.json`. Only the first
master exchange is serviced; next implement listener acceptance and regular
channels, then vDSO/sysfs/mcctrl, status 3 and applications. Repeated host sends
need a compatible guest consumption contract; the initial publisher never
reuses a slot. Started owners remain retained and native shutdown is unproven.
Declared staging/contracts/full-suite integration, full Rust/assembly ownership
and independent production acceptance remain open; no gate credit is claimed.

Native boot entry checkpoint (2026-09-07): all three refreshed images are built;
the current native image SHA is
`3eb7b36b3ef1ee069dbfdb163bff9f7a39bf828af3635417cd708a9a6f011be8`.
Patch 0006 and all three prototype native modules compile. Exact C witnesses
match both boot layouts. Preparation passes both user ABIs across two module
lifetimes, with 32 forced allocation failures, cleanup and four independent
physical captures. Actual native and compat BOOT operations now execute the
assigned McKernel AP through architectural status 2 and publish both master
queues. Captured registers resolve to the guest's `post_init` host-ack wait.
Incomplete boot remains Failed with resources retained after close; mutation,
destruction and module removal are rejected. See
`docs/verification/native-boot-start-checkpoint-20260907.json` and the boot
integration plan. The initial started capture wrongly required the temporary
startup page to survive guest allocator initialization; its failure and diagnosis
are preserved with the corrected replays. Next connect actual host IRQ/IKC
service and INIT_ACK, then finish readiness, mcctrl and applications. Declared
staging, FFI/lifecycle/license bindings, full Rust/assembly completion and
independent production acceptance remain open. No full boot or shutdown is
claimed, and the earlier full suite does not cover these boot sources.

Latest IRQ/image checkpoint (2026-09-07): the guest's existing Rust IRQ producer
now has an explicit Linux 6.12 ABI selection. Exact-header checks, C/Rust
producer equivalence, native concurrency and a native Linux module guest pass;
Linux executes 1,024 callbacks across two module cycles. C fallback, legacy
Rust and native-ABI Rust McKernel images all build after repairing the existing
fallback header consumers. The native image SHA-256 is
`fb7f5140c8a877b2f927c222332bf589ad70120849285e50b46c352bfcd79ad1`.
See `docs/verification/native-irq-work-checkpoint-20260907.json`,
`native-irq-images-checkpoint-20260907.json` and the reuse/adaptation plan.
The historical broad equivalence harness cannot replay against the pinned IHK
because three expected Rust crates are absent; its failure is preserved, with
no pass claimed. The complete touched C/Rust producer passes its direct fixture.
The new native image now passes 56 image and 56 startup-table readbacks plus
64 forced startup-allocation failures in the final guest 4. Earlier cleanup probes
miscounted free pages held in Linux's per-CPU caches; the corrected probe
includes those pages while retaining the same 4 MiB allowance. The final
cleanup measurements lose only 8-12 KiB per group of eight repeated loads.
The full suite passes 2,315 tests in 305.095 seconds: 2,244 passed, 71 skipped,
from clean source parent `0d5cd7b0`. See
`docs/verification/native-irq-final-validation-20260907.json` and the updated
Rust inventory: 139 files, 115 unchanged, 14 modified, 10 added, none removed;
all 64 core and 19 native staged files retain their consumers.
An IRQ guest repeat stalled in Linux's default-idle timer/RCU path after
512 callbacks and module drop. Subsequent poll-idle and default-idle runs
each pass 1,024 callbacks, but the intermittent stall remains unresolved.
See `docs/verification/native-irq-runtime-checkpoint-20260907.json` for
the intermediate captures. Next investigate the stall and implement owned
boot parameters/trampoline, real CPU startup and cross-kernel IRQ/IKC.
The IRQ module test uses mocked boot/guest context and a local Linux transport;
it does not prove McKernel boot. Full Rust/assembly completion remains open.

Direct transport checkpoint: the same producer/list bodies now publish into
Linux's real raised queues and deliver the APIC IRQ-work vector across CPUs.
Patch 0005 exports the existing queue and per-CPU physical translator without
changing any C function body. The rebuilt pinned kernel and verification module
pass 1,024 callbacks across three remote target CPUs and two module lifetimes,
including final drains; the original local-queue fixture also passes 1,024.
The remote module has no `irq_work_queue` import. See
`docs/verification/native-irq-transport-checkpoint-20260907.json` for 25 retained
artifacts, including the corrected compiler failure. The current workflow and
additive license inventory now include patch 0005, with their current byte
bindings refreshed. The focused coverage passes 443 runtime/workflow/FP-0006/
license checks and all 27 RS-006 checks after correcting its current workflow
test byte binding. The initial failure and passing retry are retained in
`native-irq-transport-staging-integration-20260907.json`. The fresh declared stage
now builds, passes link closure/ELF checks and repeats all 56 image plus 56
startup-table readbacks and 64 forced allocation failures. The full suite passes
2,315 tests (2,244 passed, 71 skipped) in 372.896 seconds from clean source
`772ae63d`. See `native-irq-transport-final-validation-20260907.json`: 33 earlier
artifacts reverified and 16 final artifacts retained. Mock guest context remains:
no executing McKernel CPU or IKC
handshake is claimed, and the earlier intermittent Linux idle/RCU stall is open.

Trampoline-region prototype: `native-trampoline-region-plan.md` records
why the pinned Linux's first-MiB reservation needs an explicit carve-out.
The separate Rust fixture wraps existing exported E820/resource/mapping APIs;
its exact-header witness, native module build and ELF/no-SIMD checks pass.
Normal and ordinary-reserved guests reject the page without writes. The
explicit-hole guest passes 128 repeated mapped leases, overlap rejection,
full-page readbacks and cleanup across two module lifetimes. See
`native-trampoline-region-checkpoint-20260907.json` for 17 retained artifacts.
The updated Rust inventory accounts for 140 sources: 115 unchanged, 14 modified,
11 added and none removed; all 64 core and 19 native staged files retain their
consumers. The previous full suite covers the transport checkpoint, before this
fixture addition. Next integrate the tested low-memory owner with the native
SMP OS/CPU/IRQ lifetimes, exact boot parameters and preserved startup assembly.
No Linux source change, production SMP integration, assembly execution or CPU
startup is claimed by this prerequisite.

Shared boot-code checkpoint: the low-memory owner now lives in native Rust
and its existing fixture consumes that exact body. The preserved startup and
trampoline assembly match the complete original IHK bytes before and after
module linking. All three memory-map guest modes pass again, including 128
carved-page leases and full template readbacks. See
`docs/verification/native-boot-code-checkpoint-20260907.json` for 19 artifacts
and the retained/fixed capture failure. The declared native stage still has
19 Rust sources; boot integration and actual assembly execution remain open.

Latest user clarification (2026-09-07): completing the active goal requires the
entire McKernel kernel implementation to be Rust or assembly, including its
linked support code and ABI/runtime bodies. Preserve and integrate the Rust
across all existing directories. Remaining C may serve as a temporary reference,
but cannot implement the final production McKernel. See
[`docs/verification/mckernel-rust-assembly-completion.md`](docs/verification/mckernel-rust-assembly-completion.md).
This supersedes earlier exclusions of further McKernel C conversion. The native
host-module score remains separately scoped; both integration and the kernel's
Rust/assembly completion checks are required. Rocky/Linux is still the separate
Linux control kernel, and supported application languages remain unchanged.

User-confirmed architecture: Rocky Linux runs the Linux 6.x control kernel
(the current native target is the pinned Rocky-derived Linux 6.12 build with
CONFIG_RUST). The existing Rust-heavy McKernel is the HPC co-kernel, with its
own execution environment on assigned CPUs/memory. Linux-side IHK/SMP/mcctrl
modules connect it to Linux through the existing UAPI and IKC protocols.
Preserve this division of responsibility. Linux core remains Linux; use its
existing services and Rust support. Preserve McKernel's HPC implementation.

Prioritize reuse in this order: retain working code in place; reuse existing
Linux Rust APIs; adapt or extract existing project Rust bodies; implement only
the missing integration. Share code only where ownership and execution-context
requirements match. Linux CONFIG_RUST does not supply every adapter required by
this project, so check the exact pinned kernel API before designing a new one.

Start native implementation planning with
[`docs/verification/rust-reuse-plan.md`](docs/verification/rust-reuse-plan.md)
and its revision-bound source inventory. The current source baseline contains
129 Rust files / 163,073 raw lines, including fixtures. The existing McKernel,
mcctrl helpers, and user tools are part of the implementation investment;
`host-kernel/native-rust` is only one part of it.

Before adding or replacing native behavior, identify existing Rust source paths
and symbols, their build selection, and the Linux/C-bridge dependencies that
need adaptation. Record whether each body is retained, reused, extracted,
adapted, or newly implemented, with a reason when existing Rust cannot serve.
Preserve current consumers and fallback builds. Intentional retirement needs
a replacement build/symbol path and relevant equivalence evidence. Use the
existing fixtures after checking their pinned-source prerequisites.

Report source inventory, native integration, and runtime acceptance separately.
`final-push.txt` remains the native production evidence authority; its TODO
gates do not imply that no reusable Rust exists. Historical 100% campaign
scores and the older 35-45% estimate below are not current whole-OS completion
estimates. Current linked-image language evidence is the revision-bound record
in `rust-source-retirement.txt`. No score changes follow from this inventory.

The native staging/link-closure mismatch is repaired locally. The preserved
native modules passed an isolated four-CPU unbooted OS lifecycle run; see
`docs/verification/native-hpc-worklog.md`. Next major work: finish the existing
Rust resource model's Linux CPU/memory adapter, then integrate and test resource
assignment and McKernel boot. Its additive CPU effect executor passes 38 Rust
tests and the native Kbuild/link checks. The new Linux CPU adapter also passes
a four-vCPU guest capture with native/compat rollback, online veto, resource
pinning, concurrency and two unload/reload cycles. Exact staging, the rebuilt modules
and link closure pass, followed by the same CPU tests in a two-NUMA-node guest.
Memory assignment and McKernel boot remain pending. The snapshot namespace regressions are
repaired, including the RS-006 post-close boundary. The earlier broad local suite ran
2,298 tests (2,227 passed, 71 skipped), using fixed historical RK-007 fixtures and their
original artifacts. No production gate is promoted.
The CPU checkpoint now also passes the final full repository run: 2,299 tests
in 334.363 seconds, 2,228 passed and 71 skipped; see
`docs/verification/native-cpu-checkpoint-20260907.json`. The native CPU source
and compiled artifacts remain bound separately from later build-only repairs.
Follow the user's isolated four-CPU validation boundary.

Subsequent native memory prototype (2026-09-07): the additive batch memory policy
passes 45 Rust cases and nine Python checks. The debug kernel and all three
modules build; bounded memory reservation/release and CPU regressions pass both
ABIs across two four-vCPU/two-NUMA-node module cycles, including 96 allocation
failures and existing unbooted OS lifecycle probes with a reserved memory pool.
See `docs/verification/native-memory-checkpoint-20260907.json` and the adapter
review. Exact staging/workflow/FFI and verification-binding integration remains
pending, followed by a fresh exact-stage build and guest. The prior full suite
does not cover this prototype. OS resource assignment, native McKernel boot,
workloads, Rust/assembly-only completion and production acceptance remain open.

Memory staging integration now passes 182 focused checks and a subsequent
17-test unsafe/FFI group; see
`docs/verification/native-memory-staging-integration-20260907.json` for separate
source snapshots and retained intermediate failures. The manifest, source/link
graph, lifecycle/compat dispatch and review inventory include the memory adapter.
The workflow includes patches 0004 and 0024. The declared-stage debug kernel and
all three modules now build, pass link closure, and pass the four-vCPU/two-NUMA
native/compat guest replay with both module cycles. See
`docs/verification/native-memory-exact-stage-checkpoint-20260907.json`.
Runtime/workflow and current license bindings now pass, followed by the full
repository suite: 2,301 tests in 333.823 seconds, 2,230 passed and 71 skipped.
See `docs/verification/native-memory-final-validation-20260907.json`. The later
objtool patch is byte-pinned outside the unchanged historical config replay;
unknown, altered or substituted patches remain rejected. No native McKernel boot
or production gate credit is claimed. The next implementation is described in
`docs/verification/native-os-resource-bridge-plan.md`.
The subsequent Rust inventory accounts for 131 sources: 121 unchanged, eight
modified, two added, none removed; all 64 core crate files and 15 staged native
files have matched consumers. See `docs/verification/rust-consumers-memory-20260907.json`.

Next source-bound OS resource prototype (2026-09-07): native and compat CPU/memory
assignment, queries and coupled unbooted destruction now pass the expanded
four-vCPU/two-NUMA guest across two module cycles, alongside the prior CPU/memory
regressions. See `docs/verification/native-os-resource-checkpoint-20260907.json`
and `docs/verification/native-os-resource-bridge-plan.md`. The policy has 51 Rust
tests, including 65,536 page-model cases; the complete IHK adapter mock has 47.
The v2 callback pair retains IHK leases, SMP module ownership and per-OS operation
locks. Current manifest/lifecycle/unsafe-FFI/downstream verification bindings are
still pending; the prior 2,301-test suite covers the memory checkpoint, not this
new prototype. Preserve all retained captures and finish those bindings before
an exact-stage rebuild/guest/full suite. Then proceed to image loading, AP startup,
IKC and workloads. No native McKernel boot or production gate is promoted.

The subsequent declared OS resource stage now builds and passes link closure,
followed by both native/compat guest cycles on four vCPUs and two NUMA nodes.
The current suite passes 2,305 tests in 354.989 seconds: 2,234 passed and 71 skipped.
See `docs/verification/native-os-resource-final-validation-20260907.json`.
The unsafe/FFI queue covers 145 sites across 15 native sources, preserving
all previous site IDs with independent review still pending. Historical
FP-0006 witnesses replay their unchanged source inputs in explicit private
fixtures; they do not accept the newer live source as old evidence. The
Rust inventory accounts for 131 files: 116 unchanged, 13 modified, two
added and none removed; all 64 core files retain their crate/CMake consumers.
Next: image loading, AP startup, IKC and native mcctrl execution, then
application checks; see `docs/verification/native-image-boot-plan.md`.
Native McKernel boot, full Rust/assembly completion and production
acceptance remain open. No formal score changes.

Post-crash recovery and image loading (2026-09-07): the scratch filesystem and
four-CPU/12-GiB/512-task controls are restored. Both pinned container isolation
checks and the three focused native image/OS tests pass. All ten source
overlays and five artifacts match the successful pre-crash native loader
build; fresh formatting and ELF/no-SIMD checks pass. A new four-vCPU/two-NUMA
guest passes both ABIs over two module cycles, including all 24 physical image
readbacks and the preserved CPU/memory/resource regressions. See
`docs/verification/native-image-loader-checkpoint-20260907.json` and the local
recovery note. The checkpoint retains 36 artifacts, including the interrupted
capture, build/compiler inputs, modules, guest initramfs and setup recipes.
Next integrate the loader into declared staging, lifecycle and unsafe/FFI
contracts and downstream verification bindings, then run a fresh declared-stage
build/guest/full suite. Native McKernel boot, IKC, workloads and final
Rust/assembly completion remain pending; no production gate is promoted.

## Mission

Owned startup-table prototype (2026-09-07): the corrected native module passes
the four-vCPU/two-NUMA guest over both ABIs and two reload cycles. All 56 image
and 56 table readbacks match independent models; 64 forced allocations fail
cleanly and 32 load/invalidate repetitions cover original-owner cleanup.
See `docs/verification/native-startup-tables-checkpoint-20260907.json` and the
startup-table review. The initial low-level allocator NUMA sentinel bug and
its failing guest are retained. The declared graph now has 19 native sources
and the FFI ledger preserves prior IDs across 156 sites, with independent
review pending. Complete current downstream checks and a fresh declared-stage
build/guest/full suite, then continue owned trampoline, boot parameters,
CPU wakeup and IKC. Native McKernel boot and Rust/assembly completion remain
open; no production gate or score changes.

The subsequent declared startup stage now builds the kernel and all three
modules, passes link closure and ELF/no-SIMD checks, and repeats the passing
four-vCPU/two-NUMA guest with both ABIs/cycles and all 56+56 readbacks and 64
forced allocation failures. All five kernel/config/module artifacts match
the corrected prototype. The Rust inventory accounts for 137 files, none
removed, with all 64 core files and 19 native staged files matched to consumers.
See `docs/verification/native-startup-exact-stage-checkpoint-20260907.json`.
The startup checkpoint now passes the full repository suite: 2,313 tests in
279.154 seconds, with 2,242 passed and 71 skipped, from clean source parent
938dfd92. All 73 artifacts and four references in its earlier checkpoints
pass byte/hash and gzip round-trip checks. See
`docs/verification/native-startup-final-validation-20260907.json`. Continue
the real boot path next. In particular, the preserved guest LinuxIrqWork
layout differs from Linux 6.12's __call_single_node layout; the boot plan
records this required IRQ/IKC adaptation. No McKernel CPU has started yet.

Image staging integration (2026-09-07): the recovered loader now appears in declared
staging/link closure, lifecycle and mapping-reuse contracts, and the 154-site /
18-source unsafe/FFI queue. Existing site IDs are preserved. Source, lifecycle,
mapping and loader checks have passing captures. Current workflow, license
and downstream bindings now pass the focused checks. See
`docs/verification/native-image-staging-integration-20260907.md` and its JSON
record for the precise scope and retained failures. The subsequent declared-stage
build, guest and full suite are recorded below. These local checkpoints do not
grant production credit.

The subsequent declared image stage now builds the debug kernel and all three
modules, passes link closure and ELF/no-SIMD checks, and passes both guest ABIs
over two four-vCPU/two-NUMA module cycles with all 24 physical image readbacks.
See `docs/verification/native-image-exact-stage-checkpoint-20260907.json`.
A capture-only mutable-log input issue was preserved and corrected in a second
passing guest with an explicit immutable input list and completion-time hashes.
The Rust inventory has 135 files: 116 unchanged, 13 modified, six added and none
removed from the baseline; all 64 core files and 18 native files retain their
declared consumers. Native McKernel boot and production acceptance remain open.

The complete image checkpoint now passes the full repository suite: 2,312 tests
in 402.583 seconds, with 2,241 passed and 71 skipped. See
`docs/verification/native-image-final-validation-20260907.json`. The suite used
source parent da198482 and the original historical artifact fixtures. The build
and guest remain independently bound to their compiler inputs. Next implement
native AP startup and boot using the existing guest Rust/assembly entry paths,
then IKC and native mcctrl/application work. Full Rust/assembly completion and
production acceptance remain separate open requirements; no scores are promoted.

This repository is migrating McKernel from the traditional CentOS-based
deployment to an exact Rocky Linux 10.2-derived production control-plane kernel
while porting McKernel-owned implementation logic from C to Rust. The frozen
Rocky Linux 8.10 build and runtime evidence remains the historical R0
compatibility oracle, not the native-host-module production target. The active
target is smp-x86 / x86_64. Arm64 is deferred until the x86_64 path is stable.

Focus porting effort on McKernel-owned software. Do not spend migration
iterations on externally owned or third-party software unless the change is a
small build/ABI boundary needed to keep McKernel validation working. IHK host
module conversion is now explicitly in scope; Linux kernel APIs, bundled
third-party libraries, and toolchain behavior remain interfaces to preserve.

The Rust migration is intentionally incremental:

- Keep public C headers, exported symbol names, syscall numbers, ioctl values,
  IKC packet formats, and linker-visible entry points stable.
- Introduce Rust behind existing C ABI surfaces first.
- Preserve C fallback builds throughout the migration.
- Keep allocation/free, refcount mutation, lock/list mutation, page-table
  mutation, page I/O, sysfs IKC exchange, procfs buffer mutation, and user-copy
  in C until there is direct runtime coverage for those bodies.
- Prefer large, coherent helper/lifecycle batches only when they can be built
  and equivalence-tested without weakening fallback behavior.
- Each active migration iteration should target a meaningful 3-5 percentage
  point functional ownership improvement in the subsection being worked. If
  safety, runtime coverage, or ownership boundaries prevent that, state the
  reason clearly and choose the largest safe McKernel-owned slice instead.
- Recent long-running goals are measured as aggregate functional percentage
  points across the dashboard rows, not as literal whole-tree LOC percentage.
  The requested +135 campaign target is met with verified code. Post-campaign
  work toward actual 100% completion has added +248 more verified aggregate
  points so far, but the full port is not complete. Count only verified,
  McKernel-owned movement; do not inflate percentages with external software,
  third-party code, or unverified high-risk mutation.
- `migration.txt` is the stricter x86_64 core-OS ownership tracker. It answers
  whether core McKernel C bodies have been replaced by Rust-owned core
  programs, not whether Rust helper coverage exists. Current strict x86_64
  core Rust ownership is 100% for the scoped sequencing table; C may remain for ABI shims, fallback
  scaffolding, trivial adapters, and external primitive callbacks, but Rust
  helper-only trampolines do not count as full core ownership.
- `migration.txt` also tracks the final standalone Rust target. This is
  stricter than strict core ownership: everything below the supported
  application/user-code boundary should be Rust-owned by default. Other people
  can still write C or other language code on top of McKernel, and public
  compatibility headers can remain, but the kernel/control-plane
  implementation underneath should not require McKernel-owned C execution
  bodies or C fallback implementations. Current standalone Rust readiness is
  about 40% (roughly 35-45%).
- The previous active continuation target was +50 aggregate functional points.
  Its verified movement is +50 broad dashboard points, so that continuation
  target is complete. The same work is about +53 strict-core points in
  `migration.txt`, after completing the earlier +35 continuation.
- The current requested continuation target is +50 aggregate functional
  points, not +32. The current verified movement is +50 broad dashboard
  points, and about +60 strict-core points in `migration.txt`, so this
  continuation target is complete. Older +32 references are historical 32/50
  checkpoints from a completed prior continuation, not a live goal.
- Post-+50 strict-core movement is now about +398 strict-core points after
  the broad dashboard reached its current cap. The latest verified movement
  routes Page allocator low-level registration and dispatch through Rust:
  `pa_ops` storage, tracking-init and early-invalidate callback ordering,
  allocator ops publication, aligned/default allocation dispatch, free dispatch,
  early-allocation fallback selection, and exported `___ihk_mc_*()` body
  publication. Recent verified movement also routes top-level host IKC public
  handler/wrapper sequencing through Rust: syscall packet
  cast/response-channel/current-thread dispatch, dummy packet release dispatch,
  and public IKC2Linux/IKC2McKernel init panic-on-error wrapper sequencing.
  Recent verified movement also routes the public bitmap
  `ihk_pagealloc_*()` wrapper layer through Rust: exported init failure
  logging, default init, destroy free-callback dispatch,
  alloc/reserve/free/count/query dispatch, double-free error routing, and
  zero-free begin/done logging. Recent verified movement also routes
  `set_mempolicy()` and `mbind()` body sequencing through Rust: nodemask-bit
  validation, clamp-warning dispatch, mode normalization, default-policy
  empty-mask validation, copyin fault shaping, process NUMA-mask reset,
  preferred-without-mask publication, missing-mask rejection,
  node-bound validation, valid-mask overlap detection, process-mask clearing,
  interleave-state publication, straight-map/FUGAKU gates, mbind mode/flag
  validation, address-range validation, memory-range lock/lookup ordering,
  range-policy clear/allocate/rb-clear/insert sequencing, and range-policy
  mask/policy/interleave publication. Earlier `get_mempolicy()` movement
  already covered validation, `MPOL_F_NODE`/`MPOL_F_MEMS_ALLOWED`, address
  range locking/lookup, range-policy search and unlock ordering, policy selection
  plus mode copyout, and range/process nodemask copyout. The previous verified
  movement routes `ihk_mc_pt_lookup_fault_pte()` and `lookup_node()` sequencing
  through Rust: initial PTE lookup, missing-PTE fault dispatch, retry lookup,
  recovered-PTE logging, lookup-node fault dispatch/error return,
  address-space/page-table extraction, post-fault PTE lookup, absent-PTE
  `-ENOENT` shaping, PTE physical-address extraction, and physical-to-NUMA-node
  return shaping. The earlier verified movement routes
  `query_free_mem_interrupt_handler()` sequencing through Rust:
  NUMA-node iteration, per-node free-page callback dispatch, total
  accumulation/logging, optional FUGAKU panic dispatch, `memdebug` lookup,
  kmalloc/pagealloc memcheck dispatch, page-hash count/log callback dispatch,
  and optional ATTACHED_MIC sbox scratch publication. The earlier verified
  movement routes allocator wrapper selection and free handoff through Rust:
  `mckernel_allocate_aligned_pages_node()` invalid-size/default-idle/
  current-VM/range-policy/process-policy selection, current-node publication,
  and `mckernel_free_pages()` pending-free versus allocator-free sequencing.
  Earlier verified movement routes `init_process_stack()` primary
  execution-body sequencing through Rust: stack sizing, max/min limit
  selection, AP-user policy, aligned allocation, stack zeroing, VM stack range
  creation, page-table set-range callback dispatch, auxv/argv/env stack
  layout, `saved_auxv` publication, user stack pointer/context publication,
  and VM stack bound publication. The earlier verified movement routes host
  args/envs stack-prep sequencing
  through Rust: arg/env page-count and range placement, argenv page
  allocation/physical publication, argenv memory-range creation, remote
  args/envs map/copy/unmap/TLB sequencing, local args/envs length publication,
  saved_cmdline free/alloc/copy publication, argv/env pointer fixup, vDSO
  map/clear, rprocess/rpgtable publication, and init_process_stack callback
  dispatch/error shaping. The previous verified
  movement routes host prepare-ranges ELF section-loop sequencing,
  interpreter/aout relocation, section page-span/range calculation,
  memory-range creation, user-page allocation, page-table mapping
  dispatch/failure cleanup, remote-PA and text/data/map/brk publication,
  entry/auxv/context adjustment, and data-too-large return shaping through
  Rust. The previous verified movement routes host `process_msg_prepare_process()` freeze gates, program-descriptor
  map/span validation, descriptor clone allocation/copy, main-thread creation,
  process/thread/VM metadata publication, NUMA policy publication,
  prepare-ranges dispatch, success cleanup, unmap, TLB flush, destroy, and
  error shaping through Rust. The earlier verified movement
  routes Process/VM `free_process_memory_range()` page-table free/clear
  locking, memobj ref/unref ordering, TOFU removal callback dispatch,
  final detach/straight cleanup, error-log selection, and return shaping
  through Rust. The earlier verified movement
  routes Process/VM remove-process-memory-range straight-map conversion,
  range iteration, split, XPMEM removal, and free-dispatch sequencing through
  Rust. The earlier verified movement routed Process/VM do-page-fault
  outer-body, page-fault retry/page-I/O, and populate-loop sequencing through
  Rust. Earlier verified movement routed Process/VM range lookup,
  next/previous iteration, extend-up,
  change-protection, and `access_ok()` body sequencing through Rust. The
  earlier verified movement routed XPMEM clear-PTE and process-memory-range
  removal sequencing through Rust. Earlier verified movement routed XPMEM
  detach and munmap sequencing through Rust. Earlier verified movement
  routes XPMEM access-permit release lifecycle sequencing through Rust:
  destroy-start gating, attachment-list drain, attachment ref/detach/deref
  callback ordering, final destroyed-state publication, AP hash-list unlink,
  segment AP-list unlink, segment and segment-thread-group deref callback
  ordering, AP destroyable dispatch, and already-destroying early return
  behavior. The earlier verified movement
  routes XPMEM thread-group segment-list drain sequencing through Rust:
  writer-lock acquisition, empty-list detection, first-segment selection from
  the list head, segment refcount callback ordering, unlock-before-removal,
  per-segment removal callback dispatch, deref callback ordering, relock loop
  sequencing, final unlock, and empty-list return behavior. The earlier
  verified movement routes XPMEM segment-removal lifecycle sequencing through
  Rust: destroy-start gating, segment destroy-flag publication, PTE-clear
  callback ordering, final destroyed-state publication, segment-list
  lock/unlock ordering, list unlink, destroyable/refdrop callback dispatch,
  and already-destroying early return behavior. The earlier verified movement
  routes XPMEM `close()`/`dup()`/flush lifecycle sequencing through Rust:
  duplicate data clearing and open-count increment, close open-count decrement,
  flush/partition-exit decisions, flush target-group lookup, hash-list unlink,
  destroy-flag publication, access-permit/segment release callback ordering,
  final destroyed-state publication, and destroy callback dispatch. The
  earlier verified movement routes XPMEM `open()`/`openat()` body sequencing
  through Rust: partition-init gate, Linux fd-forward result handling,
  `__xpmem_open()` callback ordering, mckfd allocation/null handling, mckfd
  zeroing and field publication, locked list-head insertion, unlock ordering,
  open-count increment, and debug-log event selection. The still earlier
  verified movement routed live mckfd syscall dispatch through Rust: `read()`,
  `ioctl()`, `fcntl()`, and `close()` locked lookup, callback-vs-forward
  selection, optional TOFU ioctl/close cleanup gates, close unlink mutation,
  close-callback dispatch, mckfd free-callback dispatch, and Linux-forward
  fallback sequencing. The still earlier verified
  movement routed a ten-slice
  syscall wrapper batch through Rust: `times()`,
  `setpgid()`, `setrlimit()`, `getrlimit()`, `prlimit64()`, `sysinfo()`,
  `get_cpu_id()`, `mlockall()`, `munlockall()`, and `getcpu()` sequencing for
  CPU-time accounting/copyout, pgid normalization/find/forward/mutation,
  prlimit argument routing, sysinfo fill/copyout, CPU/NUMA id copyout,
  mlockall policy/logging, and missing-callback error shaping. The previous
  movement routed signal and credential syscall wrapper bodies through Rust:
  `kill()`, `tgkill()`, `tkill()`, `setresuid()`, `setreuid()`, `setuid()`,
  `setfsuid()`, `setresgid()`, `setregid()`, `setgid()`, and `setfsgid()`
  validation, siginfo shaping, do-kill callback dispatch, Linux-forward
  dispatch, credential-refresh dispatch, setfsid syscall dispatch, and return
  shaping. The previous movement routed top-level `ptrace()` request/callback
  body dispatch through Rust: `PTRACE_TRACEME`, kill/continue/singlestep/syscall
  wake requests, register/fpreg/regset get/set requests, user/text peek/poke
  requests including data aliases, set-options, attach/detach,
  siginfo/eventmsg, arch fallback, and unsupported/missing-callback error
  shaping. The previous movement routed `ptrace_detach_thread()` main-body
  sequencing through Rust:
  main-thread detach gating, zombie finalization selection, tracer child-list
  detach, ptraced reparenting, report-list detach/reattach, ptrace
  cleanup/free dispatch, single-step clear, exit-signal dispatch,
  forwarded-signal siginfo construction, `do_kill()` callback sequencing,
  wake/release dispatch, and final process finalization dispatch. The previous
  syscall movement routed the outer process/thread wait scan under `do_wait()`
  through Rust:
  parent children-lock callback ordering, children-list traversal, pid/pgid
  matching, `empty` publication, zombie/candidate dispatch, ptraced-children
  empty-scan traversal, report-thread list traversal, report-thread candidate
  dispatch, regular thread-list empty-scan traversal, and offset-based C
  fallback parity. The previous syscall movement routed the process-zombie/
  reparent branch under `do_wait()` through Rust: zombie status publication,
  host-wait skip/request/log selection, parent rusage aggregation, rusage
  result fill, parent child-list detach, PID-1 reparent/list attach, child
  main-thread ptrace-detach gate, parent and child lock/unlock callback
  ordering, no-reparent unlock/detach ordering, and process release callback
  dispatch. The previous syscall movement routed wait-scan candidate
  sequencing under `do_wait()` through Rust:
  report-thread exit/no-wait/detach/release decisions, nonptraced and ptraced
  stop candidates, continued candidates, ptraced-stop miss return preservation,
  process TID rewrite, and lock/release callback ordering. The previous
  syscall movement routed top-level `do_wait()` wait-loop sequencing through
  Rust: waitqueue init/prepare/finish callback ordering, process/thread scan
  dispatch gates, no-child and `WNOHANG` result shaping, pending-signal
  interrupt return, schedule callback handoff, wake/rescan behavior, and wait
  log callback ordering. The previous scheduler movement routed `do_migrate()` scheduler
  migration-completion sequencing through Rust: migration queue traversal,
  request detach/ack gates, affinity target selection, runqueue detach/add
  with length mutation, thread CPU update, same-VM sibling scan,
  address-space CPU-set lock/update, target reschedule flag publication,
  interrupt/vector callback selection, waitqueue wake callback dispatch, lock
  ordering, and return shaping. The previous scheduler
  movement routed `sched_request_migrate()` body sequencing through Rust:
  request thread publication, target migration-queue lock callback ordering,
  waitqueue init/prepare/finish callback sequencing, migration request list
  insertion, target runqueue flag/status mutation, remote interrupt
  vector/callback selection, log callback dispatch, scheduler callback
  handoff, and validation/error shaping. The previous dump movement routed
  memory dump user-page process-hash traversal, VM/address-space/page-table
  pointer loading, null skip gates, visitor argument shaping, page-table
  visitor callback dispatch, and dispatch-count/error shaping through Rust.
  The previous dump bitmap movement routed memory dump page-set
  completion, physical-address membership checks, variable-length dump bitmap
  range clearing, user-PTE dump bitmap marking, free-chunk dump bitmap marking,
  and top-level last-CPU dump query sequencing through Rust. The previous
  allocator movement routed NUMA topology and
  allocation dispatch through Rust: allocation-attempt OOM flag
  initialization, NUMA-id bounds validation, rusage OOM callback dispatch,
  NUMA allocation callback dispatch, distance-vector bounds/null checks,
  distance-id lookup, CPU-local readiness checks, current-NUMA callback
  dispatch, and distance-ordered node pointer selection. The earlier lifecycle
  slice moved `numa_distances_init()` node-distance allocation,
  distance-matrix fill, distance/id sorting, node publication,
  allocation-failure logging, and ordered log callback sequencing. The prior
  lifecycle slice moved
  `ihk_mc_set_page_allocator()` tracking-init/early-allocator invalidation/
  `pa_ops` publication plus top-level `mem_init()` monitor, rusage, NUMA,
  allocator registration, page-fault handler publication, query-free interrupt
  registration, page-hash init, virtual-map init, demand-paging flag/log
  publication, and NUMA-distance init ordering. This latest remove-range
  movement does not add broad dashboard percentage because the Process/VM row
  is already capped at 100%.
- Mechanical LOC ownership is audit-only. Use it to find remaining C debt, not
  to score progress toward the functional 100% core-category goal.

## Safety Rules

- Do not run scripts or commands that reboot the OS or force a VM reboot.
- Treat `mcreboot.sh`, reboot advice in logs, and any host reboot command as
  unsafe unless the user explicitly approves it for that run.
- Non-reboot validation is allowed: formatting, C fallback/Rust builds,
  equivalence tests, ownership report gates, and module-load smoke tests that
  do not reboot the host.
- Stop on the first failing validation step. Record the failing command,
  environment, and short error summary in `kernel.log` before making unrelated
  changes.
- The worktree may already be dirty. Do not revert changes unless the user
  explicitly asks for that exact revert.
- QEMU boot-path setup on 2026-05-24 installed Rocky QEMU/libvirt/image/debug
  tooling and exposed `qemu-system-x86_64` through the Rocky `qemu-kvm` binary.
  Libvirt is active, and `/dev/kvm` may be visible in some command contexts,
  but QEMU boot validation should still start with TCG/software emulation
  unless KVM initialization is explicitly verified for that run. Existing
  Rocky boot scripts still rely on the mcreboot/VM path and must not be run
  without explicit approval.

## Current Rust Ownership Baseline

The dashboard below is a functional-area estimate from `overview.txt`, not a
strict line-count. It is the progress score for this goal. A conservative
mechanical LOC report remains available with `scripts/rust-ownership-report.py`
only as a debt inventory.

| Area | Rust % | Status |
| --- | ---: | --- |
| Rust build/link foundation | 95 | Rust objects build and link into `mckernel.img`; user tools link Rust helper objects; IHK Linux-module Kbuild links Rust helpers into `ihk`, `ihk-smp-x86_64`, and `mcctrl`; Rust-linked module-load smoke has passed. |
| ABI/layout foundation | 100 | Shared kernel/user structs plus private process/thread lifecycle, wait/futex, timer, x86 signal action/altstack/siginfo/signalfd layouts, x86 CPU-local page and kernel-context layouts, x86 TLS user descriptor layout, ptrace user register/fpreg/user layouts, x86 descriptor/TSS/fxsave/xsave/YMM/LWP/bound-register save-state layouts, futex hash-bucket/key/queue layouts, syscall/init/post, procfs, coredump coretable, ELF core headers/notes/prstatus/prpsinfo, `iovec`, sysinfo, time-of-day, interval-timer and profile-event layouts, CPU mapping, perf, UTI, move-pages SMP request layouts, sysfs create/mkdir/symlink/lookup/unlink/setup request layouts, sysfs ops/handle/bitmap layouts, low-level rwlock, `kref`, rbtree augmentation callbacks, ftrace branch data, memobj ops/object state, SysV shared-memory limits/info/lock-user state, XPMEM ID/hash/thread-group/segment/access-permit/partition/permission/attachment layouts, `timeval`/`rusage`, pager create/map results, memory area/node/page-allocator ops/TLB-flush/page-cache headers, CPU-local/kmalloc/backlog/SMP-call layouts, IHK monitor/register/resource, host Linux device/OS/file layouts, and IHK kmsg/event/notifier/aux-call layouts are covered for the currently scoped x86_64/Rocky ABI foundation. This closes known layout prerequisites; mutation-heavy runtime bodies still need Rust ownership. |
| Shared primitives | 100 | rbtree, llist, plist, waitqueue init/entry/list core, wake scheduling predicate, string/memory leaf helpers, numeric parsers including `skip_atoi()` format width/precision pointer advancement, `number()` sign/prefix/width/precision/padding/output orchestration for `vsnprintf()` numeric and pointer paths, `format_decode()` parsing of flags, width, precision, qualifiers, and conversion types, `string()` output formatting for `%s`, base-10 decimal formatting digit emission for `vsnprintf()`, bitops, bitmap, parse, zero-area search, and region helpers are Rust-owned. |
| x86_64 memory management | 100 | Classification, NUMA/page queries, splitability, page-attribute conversion, PTE value shaping, page-size PTE validation/value selection, early allocator arithmetic/exhaustion checks, page-table index calculation, walk-bound calculation, normal/safe page-table walk iteration, callback result folding, normal/safe visit-PTE leaf/level/root body sequencing and top-level visit-range dispatch, optional physical-address skip policy, virtual-to-physical per-level miss/walk/hit decisions and physical/size result shaping, split-large-page preparation/entry arithmetic, split-large-page source classification, child-map physical derivation, page-table publish entry shaping, source-unmap gate selection, PTE direct-store helpers, atomic child-table publication helpers, PTE clear-exchange helpers, attribute-apply mutation helpers, page-clear alignment/target selection, page-table visit/direct-walk decision policy, clear/free-range validation and large-entry action selection, clear-range old-PTE phys/fileoff/dirty classification plus flush/free/unmap action selection, clear/set range top-level validation/allocation/free/walk/flush orchestration, change-attribute leaf/large/walk action selection, set-range leaf/direct-large/allocate/busy/walk action selection, set-range mapped physical/PTE value shaping for 4 KiB/2 MiB/1 GiB entries, set-range conflict/alloc-failure/map-store-RSS/walk-failure side-effect sequencing, set-range leaf/level body orchestration, lookup-pte default size/level hit/walk/miss/shape decisions, move-PTE fileoff preflight/destination shaping/PTE phys-attr splitting, page-table destroy descend/skip policy, destroy child-table physical extraction, recursive page-table destroy/free-callback orchestration below the root, page-table root create/destroy-root lifecycle orchestration, page-table prepare-map first-level allocation/publish and last-level set-page callback orchestration, exported set-PTE body sequencing/log/panic/store orchestration, page refcount/hash lifecycle helpers, `page_map()` count increments, locked `page_unmap()` count/list deletion and lock orchestration, locked `phys_to_page()` lookup orchestration, locked `phys_to_page_insert_hash()` lookup/allocation-callback/insert orchestration, locked page-hash count-all traversal, phys-to-page hash traversal, hash insertion initialization, page-hash bucket init/count, VM range validation, memory-policy validation, selected pager/object sizing helpers, process-VM verification/page-fault/copy loop sequencing, mapped versus direct physical-copy selection, byte-copy sequencing, scalar user get/set wrappers, user string length/copy wrappers, dump-page completion/address-check/bitmap marking/query sequencing, and dump user-page process-hash traversal/page-table visitor dispatch are Rust-owned; page-table allocation/free primitives, page-fault primitive behavior, `phys_to_virt()`/`virt_to_phys()` primitive behavior, map/unmap primitive bodies, callback execution, broader page frees/RSS accounting, mapping/free rollback orchestration, page-hash spinlock/allocation primitives and logging, TLB-sensitive primitive behavior, current-thread/resource-set lookup, and C fallback scaffolding remain C. |
| Page allocator | 100 | Rbtree helper cluster, bitmap-backed no-lock allocator internals, bitmap public locked-wrapper orchestration for alloc/reserve/free/count/query/zero-free, `__ihk_pagealloc_init()` layout/allocation-callback/descriptor-init/lock-callback/tail-reservation orchestration, init layout/end/count calculation, descriptor zeroing and descriptor field initialization, tail-map reservation, destroy-page count and descriptor destroy/free-callback orchestration, exported add-free log/error/return sequencing, NUMA free/alloc helpers, public zero-free wrapper dispatch, NUMA zero-free dispatcher/all-node traversal, exported `ihk_numa_alloc_pages()` top-level allocation body sequencing, main `ihk_numa_alloc_pages()` cache-first/source-selection/fallback-to-NUMA orchestration, exported `ihk_numa_free_pages()` top-level and main CPU-cache/direct/deferred free orchestration plus post-action completion sequencing, `numa_init()` node discovery/node-field publication/memory-chunk ingestion/early-heap adjustment/free-page-or-pagealloc dispatch/rusage accounting/final-node logging sequencing, NUMA allocation-attempt OOM/bounds/callback dispatch, distance-id lookup and distance-ordered NUMA node selection, main NUMA allocation lock-callback orchestration, direct free-to-tree lock-callback orchestration, deferred-free enqueue/zero-request orchestration, free-path policy, zeroing-worker atomic increment, CPU-local cache action classification, CPU-local cache rb-tree allocation/free helper entry points, CPU-local cache alloc/free fast-path orchestration with interrupt callback ordering and result classification, CPU-local storage initialization, CPU-local variable selection, normal preempt counter updates, kmalloc chunk header initialization, sorted kmalloc free-list insertion, adjacent free-chunk consolidation, low-level `___kmalloc()` allocation body sequencing, low-level `___kfree()` current/remote free body sequencing, kmalloc remote free-list move/consolidation sequencing, public `_kmalloc()`/`_kfree()` memdebug tracking wrapper sequencing, public `_ihk_mc_alloc_aligned_pages_node()`/`_ihk_mc_free_pages()` pagealloc memdebug tracking wrapper sequencing, pagealloc/kmalloc tracking hash initialization, pagealloc/kmalloc memcheck leak-scan traversal, runcount mutation, leak-log callback sequencing, `ihk_mc_set_page_allocator()` tracking-init/early-invalidate/`pa_ops` publication, top-level `mem_init()` allocator/memory lifecycle sequencing, NUMA-distance allocation/fill/sort/log sequencing, `query_free_mem_interrupt_handler()` node iteration/total accumulation/logging/memdebug/page-hash/sbox sequencing, and Linux zero-request action selection, deferred-zero IKC packet field shaping, Linux zero-request preparation including current/idle/nohost/worker/pid checks plus packet fill and worker increment, and deferred-zero send/log callback sequencing are Rust-owned; logging/panic callbacks, pa-ops implementation callback bodies, actual allocation/free primitive side effects below the published ops callbacks, and MCS/interrupt primitives, broader allocator lifetime, IKC channel lookup, current-thread/channel lookup, actual IKC send side effects, deferred-zero worker timing, and FUGAKU debug preempt path remain C. |
| Process/VM management | 100 | Wait/clone/ptrace/VM policy, fork VM/thread metadata copy, address-space release and PID detach mutation, range-cache lookup relation plus range-cache replace/store mutation for join, free, and lookup paths, full VM range lookup traversal/cache publication, next/previous range iteration bodies, post-bounds `add_process_memory_range()` orchestration including VM range object initialization, mapping-action selection, insert/update failure cleanup, returned-range publication, and VM range-tree insertion traversal/link/color mutation, VM range end/flag commit mutation for extend-up and protection-change paths, stack-growth range-start alignment/commit mutation for the page-fault path, page-fault PTE lookup retry/log sequencing and `lookup_node()` fault/PTE/phys-to-node return sequencing, remove-range split/free preflight, remove-process-memory-range straight-map conversion/range-iteration/split/XPMEM/free dispatch sequencing, `free_process_memory_range()` page-table free/clear lock/memobj/finalize orchestration, split-range high-half field shaping and low-half end commit, join-range adjacency/object-offset validation and surviving-end commit, CPU-set fallback, mckfd decisions plus push/pop-head mutation, TID-table scan/index decisions, TID slot release/replace writes, sigpending list pop/unlink, sigcommon release-body sequencing, release_thread ref/profile/procfs/destroy/VM-release sequencing, release_process_vm ref/mckfd/free-callback/TLB/free-ranges/detach/policy-drain/final-free sequencing, process/thread list add/detach helpers, terminate child cleanup list unlink/reparent mutation helpers, thread report-list attach/detach mutation helpers, ptrace main-thread attach/detach reparent helpers, ptrace detach/wakeup state and pending-signal cleanup helpers, wait signal-flag and exit-status reap mutation helpers, terminate/wait report-thread release cleanup helpers, do-wait child/report-thread traversal and empty-scan sequencing, optional ptrace/fp cleanup gates, and lifecycle/refcount predicates are Rust-owned; VM range allocation/free callbacks, memobj refcounting, TOFU split/merge hooks, split/XPMEM primitive callbacks, page-fault range-resolution primitive behavior, page-table lookup/allocation/mapping side effects, page-table attribute mutation/free/clear, other child-list/lifetime orchestration, rusage aggregation, broad process lifetime mutation, signal forwarding, atomic refcount primitive bodies, lock/free primitive bodies, and remaining wait primitive behavior remain C. |
| Syscall core | 100 | SysV shm, prlimit, scheduler priority/policy plus scheduler syscall body sequencing, syscall/range validation, credential-refresh forwarding gates, direct ID and uid/gid leaf bodies, kill/tkill/tgkill siginfo shaping and do-kill callback sequencing, forwarded uid/gid setter Linux-forward/credential-refresh sequencing, getresuid/getresgid ordered field-read and user-copy callback sequencing, mckfd lookup/dispatch and close sequencing, memory-policy syscalls including `get_mempolicy()`, `set_mempolicy()`, and `mbind()` body sequencing, mmap/brk/mincore/mprotect policy, signal/time syscall body sequencing, ptrace/process-vm helpers, wait4/waitid/do-wait sequencing, execveat/clone/futex policy helpers, bounded wait/ptrace/termination/signal list rewiring, ptrace request/event/register/regset sequencing, getrusage body sequencing, process-exit status/siginfo classification, terminate cleanup/reparent action classification, clone spawn/TID/TLS/reparent result shaping, and ptrace detach signal-forward gates are Rust-owned; top-level syscall dispatch, actual user-copy primitive, Linux forwarding primitive bodies, locks, allocation/free primitives, architecture fp/register/regset primitives, actual process-memory read/patch primitives, signal delivery primitive behavior, rusage aggregation/traversal, CPU interrupt delivery, ptrace lookup/orchestration, scheduler migration side-effect bodies, broader scheduler/time primitive bodies, waitqueue/schedule/signal primitive behavior, and other primitive C callback implementations remain C. |
| Scheduler/timers/wait/futex | 100 | Waitqueue init/entry/list core, wake scheduling predicate, bounded runqueue/migration list rewiring plus runqueue length updates, scheduler set/get-param, set/get-scheduler, RR-interval, set-affinity, and get-affinity syscall validation/target-selection/permission-check/user-copy sequencing, scheduler migration-request body sequencing for waitq setup, request queue publication, target runqueue flag/status mutation, remote interrupt decision, log callback dispatch, schedule handoff, and waitq finish, scheduler migration-completion body sequencing for migration queue traversal, request detach/ack gates, affinity target selection, runqueue detach/add with length mutation, thread CPU update, same-VM sibling scan, address-space CPU-set update, target reschedule flag publication, interrupt dispatch, waitqueue wake, and lock ordering, timer spin-sleep/runqueue/remaining-time arithmetic, `init_timers()` list/lock initialization sequencing, `schedule_timeout()` spin-wake/runqueue/schedule-callback/spin-loop/timeout-expiry sequencing, `wake_timers_loop()` timer tick/decrement/detach/log/wakeup sequencing, `set_timer()` runqueue scan and LAPIC enable/disable decision sequencing, local interval-timer current-value subtraction, elapsed reset, enabled-state publication, and set-timer callback dispatch, futex hash-table allocation-callback/pointer-publication/table-initialization orchestration, futex hash-bucket selection with hash callback, top-level futex command dispatch/private/realtime decode, clock-realtime rejection, wait/wake/requeue/wake-op callback selection, invalid-command callback routing, futex hash-bucket table lock/list initialization, futex key matching/key preparation plus wake/requeue decision policy, futex double hash-bucket lock/unlock ordering, futex wake-list scan/key-match/bitset/limit orchestration, futex wake target orchestration, futex requeue source-list scan/key-match/wake-vs-requeue/drop-count orchestration, futex requeue key-reference callback and key-copy publication, futex wait-setup key-init/get-key/queue-lock/get-value/mismatch cleanup orchestration, futex wake-list detach and lock-pointer clear, futex requeue list move and lock-pointer publication, futex waiter plist initialization/insertion, futex wait-queue bitset/requeue/UTI initialization, key-region zeroing, hash-bucket lock-pointer publication, waiter metadata publication, self-unqueue list detach, wait-side bitset validation, wait scheduling action classification, wait-state status/spin-sleep mutation, futex post-wait success/timeout/interrupt/retry classification, futex wake target classification, Linux response-channel fallback selection, futex wake IKC packet field publication, syscall-offload scheduling decisions, and scheduler/futex/signal/timer policy helpers are Rust-owned; futex allocation/hash primitive callbacks, actual spinlock primitives, rdtsc/pause primitive behavior, LAPIC timer primitive behavior, waitqueue wake primitive behavior, IKC send and scheduler wake primitives, futex key lookup internals, key-reference implementation/lifetime, user-value load, IPIs, context switching, address translation, migration primitive callbacks, race retry, user-value comparison, `schedule()` primitive behavior, and remaining futex queue/requeue/wait side effects remain C. |
| procfs/sysfs/xpmem/file objects | 100 | XPMEM and file/dev/procfs/sysfs/pager decision-helper surface is Rust-owned through multiple batches, including live mckfd lookup/dispatch, XPMEM open/close/dup/flush lifecycle sequencing, XPMEM release/remove wrapper sequencing, XPMEM AP hash-bucket release-drain sequencing, XPMEM thread-group destroy dispatch, XPMEM access-permit release lifecycle sequencing, XPMEM segment-removal lifecycle sequencing, XPMEM thread-group segment-list drain sequencing, procfs cmdline/comm helpers, sysfs show/store/release response-body sequencing, sysfs request packet dispatch, procfs buffer allocation/init/physical-publication sequencing, `/proc/PID/mem` page-fault/translation/memory-gate/copy-loop sequencing, root `mckernel`/`stat` output, per-process `auxv`/`cmdline`/`comm` output, `/proc/PID/pagemap` value-loop sequencing, `/proc/PID/maps` line output, `/proc/PID/status` body output, and per-PID `stat` body output; this is not full subsystem ownership because allocation/free primitives outside covered mckfd allocation/free-callback dispatch, refcount mutation, lock/list primitive behavior, remap/page-table mutation, page I/O, remaining procfs request mapping/lookup/lock primitives, raw sysfs/procfs IKC send behavior, public IKC handler wrapping/logging, and user-copy remain C. |
| host/IKC/mcctrl/IHK modules | 100 | Rust helper linkage is active for `ihk`, `ihk-smp-x86_64`, and `mcctrl`; many host driver, OS/device exclusive-open refcount compare-exchange mutation, generic locked list add/delete mutation, generic list-membership traversal, generic next-entry cursor traversal for notifier/event/aux-call paths, kmsg buffer/container lifecycle mutation, kmsg container atomic count set/read/inc/dec/dec-return, reverse kmsg list lookup traversal, DMA request callback dispatch, load-file dispatch/read-loop policy, shutdown status policy, SMP, sysfs, IKC policy, and mcctrl helpers are Rust-owned, including deferred-zero worker list pop, payload clear, zeroed-list publish, atomic counter updates, top-level host SCD packet dispatcher classification/release sequencing, host prepare-process body sequencing, host prepare-ranges section/range/page-table sequencing, host args/envs stack-prep sequencing, init-stack primary execution-body sequencing, host IKC2Linux/IKC2McKernel initialization body sequencing, top-level syscall packet-handler wrapper sequencing, dummy packet-handler release sequencing, and public host IKC init panic-on-error wrapper sequencing; device allocation, memory registration, file I/O, waits/callbacks beyond the bounded dispatchers, broader IKC exchange mutation, broad allocation/lifetime ownership, and kernel object lifecycle mutation remain pending. |
| User tools | 83 | `mcstat`, `mcexec`, `ihklib`, `mcinspect`, `eclair`, and crash-extension helper surfaces are substantially Rust-owned; device I/O, ioctl handling, DWARF/BFD walking, crash command orchestration, GDB process/socket orchestration, daemon/thread/event-loop mutation, dump NMI side effects, register/memory reads, and most IHK command mutation remain C. |
| Rocky runtime integration | 82 | Rust McKernel image and focused Rocky smokes have passed in prior runs; this pass did not run boot or reboot-capable validation. Wider runtime/performance coverage remains pending. |
| arm64 | 0 | Deferred until x86_64 stabilizes. |

Honest current distance: the non-arm64 functional dashboard average is 96.7%,
while the McKernel-owned core rows in this table average 100.0%. Mechanical LOC
audit is 27.9% and is not a progress score. The functional percentages track
verified Rust-owned surfaces, and they are not a claim that mutation-heavy
kernel bodies are already fully Rust. The current total distance to 100 is 40
aggregate functional points across non-arm64 dashboard rows, or 0 points
across the McKernel-owned core rows excluding build/host/user/Rocky/arm64.

## Full-Port Tracker

`full-port.txt` is the strict whole-repo x86_64/Rocky full standalone Rust
tracker. It excludes arm64, third-party/vendor/generated code, public
compatibility headers, tests, and unavoidable assembly-adjacent code.

Use `full-port.txt` for the completed scored full-port campaign. Use
`migration.txt` for strict core sequencing history, `overview.txt` for the
functional dashboard, and `rust-source-retirement.txt` for the stricter
per-file C-source retirement inventory. The current non-arm full-port scored
tracker is 100.0% complete with 0.0% left, and the verified aggregate movement
is +611.9 / +611.9 percentage points. Do not keep adding full-port percentage
after this saturation point.

Remaining work after the scored full-port closeout is source-retirement and
default-path C-dependency cleanup outside `full-port.txt`. A C file that still
contains a McKernel-owned implementation body for fallback builds should not be
marked fully retired in `rust-source-retirement.txt`; record such work as
default-path Rust ownership in `overview.txt` or as a validated note until the
C implementation body is actually removed or reclassified by the retirement
tracker's rules.

Every full-port movement must be verified. Runtime-sensitive work must use QEMU
and virtualization tooling, preferably KVM when available and verified. Do not
use host reboot paths. Stop on first validation failure and log the failing
command, environment, and short error summary in `kernel.log`.

## Strict Core OS Rust Ownership

`migration.txt` tracks the stricter target: the x86_64 McKernel core OS should
be Rust-owned, not merely have Rust helpers around C execution bodies. Keep this
section synchronized with `migration.txt` whenever strict core ownership moves.

What counts as full core ownership:

- Rust owns the primary execution body for a core OS operation.
- Rust owns the state transition, mutation, validation, error shaping, and
  side-effect orchestration for that operation.
- C is limited to public ABI entry points, fallback scaffolding, trivial
  adapters, or calls into external primitives that are not McKernel-owned logic.

Partial credit applies when Rust owns policy or bounded mutation, but C still
performs locks, allocation/free, user-copy, page-table writes, wakeups, IKC
sends, signal delivery, or lifecycle mutation.

Do not count these as full core ownership:

- Rust functions that only call back into the old C implementation.
- C orchestration paths that call Rust helper islands while keeping the main
  McKernel-owned execution body in C.
- Layout assertions, C ABI declarations, or tests by themselves.
- New C helper logic, unless it is clearly fallback or glue used to verify and
  route Rust behavior.

Current strict x86_64 core Rust ownership is 100% for the scoped sequencing
table. This is not the standalone Rust end-state: remaining C still owns
high-risk primitive/runtime bodies such as page-table mutation primitives,
allocator lifetime primitives, syscall dispatch, raw user-copy primitive
callbacks, process lifetime primitives, page-fault primitive behavior,
scheduler wake/context behavior, futex wake/wait side effects, signal delivery,
IKC exchange, and kernel object lifecycle.

## Standalone Rust End-State

The standalone Rust goal is stricter than strict core ownership. Strict core
100% means Rust owns the McKernel core execution bodies. Standalone Rust 100%
means the default x86_64/Rocky kernel and required control-plane path can stand
as a Rust implementation below the external/user-code boundary.

What counts:

- Rust owns all McKernel-owned non-assembly implementation logic needed to boot,
  run, schedule, manage memory, service syscalls, handle waits/futexes/signals,
  exchange required IKC/control-plane messages, and shut down.
- The default build/runtime path does not need C fallback bodies for
  McKernel-owned behavior.
- C, if present, is limited to external compatibility headers, optional
  user-facing API wrappers, generated/declared ABI surfaces, third-party or
  Linux-owned interfaces, tests, and unavoidable architecture assembly.
- Rust APIs are the native internal substrate for allocation/lifetime,
  refcounting, page tables, user-copy orchestration, scheduling, object
  lifecycle, and control-plane behavior.

Do not count as standalone Rust:

- Required C fallback implementations for McKernel-owned logic.
- C wrappers that still perform primary allocation, mutation, traversal,
  user-copy, wakeup, page-table, IKC, signal, or lifecycle side effects.
- Rust helpers that only validate, shape, or call back into C-owned bodies.
- C build/link steps that are required because the implementation still lives
  in C rather than because of external ABI compatibility.

Current standalone Rust readiness is about 40% (roughly 35-45%). Keep this
lower than strict-core ownership until C fallbacks, C runtime bodies, and C
control-plane implementation dependencies stop being required by the default
OS path.

| Area | Overview % | Strict Core % | Strict Core Status |
| --- | ---: | ---: | --- |
| ABI/layout foundation | 100 | 100 | Currently complete for the scoped x86_64/Rocky ABI foundation. Rust/C assertions cover pager create/map result layouts, memory area/node/page-allocator ops/TLB-flush/page-cache headers, rusage-percpu, kmalloc metadata, SMP-call packets, backlog entries, full CPU-local storage layout, x86 CPU-local page and kernel-context layouts, x86 TLS user descriptor layout, x86 signal action/altstack/siginfo/signalfd layouts, ptrace user register/fpreg/user layouts, x86 descriptor/TSS/fxsave/xsave/YMM/LWP/bound-register save-state layouts, futex hash-bucket/key/queue layouts, syscall/init/post, procfs, coredump coretable, ELF core headers/notes/prstatus/prpsinfo, `iovec`, sysinfo, time-of-day, interval-timer and profile-event layouts, CPU mapping, perf, UTI, move-pages SMP request layouts, sysfs create/mkdir/symlink/lookup/unlink/setup request layouts, sysfs ops/handle/bitmap layouts, low-level rwlock, `kref`, rbtree augmentation callbacks, ftrace branch data, memobj ops/object state, SysV shared-memory limits/info/lock-user state, and the XPMEM ID/hash/thread-group/segment/access-permit/partition/permission/attachment object graph. This is prerequisite ownership, not runtime ownership of mutation-heavy bodies. |
| Shared primitives | 100 | 100 | Complete for the scoped x86_64/Rocky shared-primitives core. Numeric parsing, `skip_atoi()` format width/precision pointer advancement, `number()` sign/prefix/width/precision/padding/output orchestration, `format_decode()` format-token parsing, `string()` `%s` output formatting, base-10 decimal digit emission, and the main `vsnprintf()` loop orchestration are Rust-owned; public ABI wrappers, `va_arg` extraction glue, and fallback scaffolding still block standalone Rust, not this strict shared-primitives row. |
| x86_64 memory management | 100 | 100 | Page-table decisions, page-table root create/destroy-root lifecycle orchestration, page-table prepare-map orchestration, exported set-PTE body sequencing, page refcount/hash lifecycle bodies, recursive child-table destruction/free-callback orchestration, full virtual-to-physical walks, page-clear traversal, lookup-PTE body orchestration, change-attribute traversal/PTE mutation, page-table setup/allocation traversal, clear-range TLB flush-address queue mutation, old-PTE memobj-flush/free/unmap/RSS side-effect sequencing, full-span child page-table teardown/free sequencing, clear-range leaf/level/root body sequencing, set-range conflict/alloc-failure/map-store-RSS/walk-failure side-effect sequencing, set-range leaf/level body orchestration, clear/set range top-level orchestration, normal/safe visit-PTE visitor body sequencing, process-VM verification/page-fault/copy loop sequencing, mapped versus direct physical-copy selection, byte-copy sequencing, scalar user get/set wrappers, user string length/copy wrappers, dump-page completion/address-check/bitmap marking/query sequencing, and dump user-page process-hash traversal/page-table visitor dispatch moved. Page-table allocation/free primitives, old-entry page lookup/refcount primitive behavior, address-translation primitive bodies, page-fault primitive behavior, broader page frees/RSS accounting, remote TLB shootdown primitive behavior, physical/free orchestration, page-hash primitives/logging, current-thread/resource-set lookup, and fallback scaffolding remain C-owned, but the scoped x86 memory sequencing row is now strict-core complete. |
| Page allocator | 100 | 100 | Complete for the scoped Page allocator sequencing row. Bitmap, NUMA, `__ihk_pagealloc_init()` orchestration, public bitmap `ihk_pagealloc_*()` wrapper sequencing for init failure logging, default init, destroy free-callback dispatch, alloc/reserve/free/count/query dispatch, double-free error routing, and zero-free begin/done logging, exported add-free log/error/return sequencing, public zero-free wrapper dispatch, exported `ihk_numa_alloc_pages()` top-level allocation body sequencing, main `ihk_numa_alloc_pages()` cache-first/source-selection/fallback-to-NUMA orchestration, exported `ihk_numa_free_pages()` CPU-cache/direct/deferred top-level body sequencing, main `ihk_numa_free_pages()` direct-versus-deferred free orchestration, free post-action completion sequencing, allocator pa-ops/early-allocation wrappers, pending-free list mutation, free-in-allocator rbtree traversal, allocation policy loops, `mckernel_allocate_aligned_pages_node()` default/idle/current-VM/range-policy/process-policy wrapper selection, top-level `mckernel_free_pages()` pending-free versus allocator-free handoff, `query_free_mem_interrupt_handler()` node iteration/total accumulation/logging/memdebug/page-hash/sbox sequencing, `numa_init()` node discovery/node-field publication/memory-chunk ingestion/early-heap adjustment/free-page-or-pagealloc dispatch/rusage accounting/final-node logging sequencing, NUMA allocation-attempt OOM/bounds/callback dispatch, distance-id lookup and distance-ordered NUMA node selection, CPU-local storage initialization, CPU-local variable selection, normal preempt counter updates, kmalloc chunk header initialization, sorted kmalloc free-list insertion, adjacent free-chunk consolidation, low-level `___kmalloc()` allocation body sequencing, low-level `___kfree()` current/remote free body sequencing, kmalloc remote free-list move/consolidation sequencing, public `_kmalloc()`/`_kfree()` memdebug tracking wrapper sequencing, public `_ihk_mc_alloc_aligned_pages_node()`/`_ihk_mc_free_pages()` pagealloc memdebug tracking wrapper sequencing, pagealloc/kmalloc tracking hash initialization, pagealloc/kmalloc memcheck leak-scan traversal, runcount mutation, leak-log callback sequencing, `ihk_mc_set_page_allocator()` tracking-init/early-invalidate/`pa_ops` publication, top-level `mem_init()` allocator/memory lifecycle sequencing, and NUMA-distance allocation/fill/sort/log sequencing moved, but pa-ops implementation callback bodies, actual allocation/free primitive side effects below the published ops callbacks, MCS/interrupt primitive bodies, IKC channel lookup/send side effects, logging/panic primitive bodies, deferred-zero worker timing, FUGAKU debug preempt behavior, and broader allocator lifetime remain C-owned. |
| Process/VM management | 100 | 100 | Complete for the scoped Process/VM sequencing row. Many lifecycle, wait, ptrace, range, list, post-bounds add-range orchestration bodies, VM range-tree insertion traversal/link/color mutation, VM range lookup traversal/cache publication, next/previous range iteration, extend-up validation/commit, change-protection attr-delta/private-file/page-table-lock/change-attr/-ENOENT/commit sequencing, `access_ok()` initial/adjacent/permission multi-range validation, do-page-fault stack-grow/lock/exiting/lookup/access/zero-object/normal-vs-XPMEM dispatch sequencing, page-fault `-ERESTART`/page-I/O retry sequencing, populate-loop preempt/page-walk/warning sequencing, page-fault PTE lookup retry/log sequencing, `lookup_node()` page-fault/PTE-present/phys-to-node return sequencing, remove-process-memory-range straight-map conversion/range-iteration/split/XPMEM/free dispatch sequencing, `free_process_memory_range()` page-table free/clear lock/memobj/finalize orchestration, release/cleanup sequencing, sigcommon release-body sequencing, TID release/replace body sequencing, release_thread ref/profile/procfs/destroy/VM-release sequencing, release_process_vm ref/mckfd/free-callback/TLB/free-ranges/detach/policy-drain/final-free sequencing, wait-zombie child rusage aggregation/reparent/list-detach/list-attach/release sequencing, do-wait child/report-thread traversal plus empty-scan sequencing, and ptrace-detach reparent/report/cleanup/wakeup/release/finalize sequencing moved. VM range allocation/free callbacks, split/XPMEM primitive callbacks, memobj refcounting, page-fault range-resolution primitive behavior, actual page-table lookup/allocation/mapping side effects, other child-list/lifetime traversal, broad rusage traversal, broad process lifetime, signal-delivery primitives, atomic refcount primitives, lock/free primitive bodies, and wait primitive behavior remain C-owned outside this completed scoped row. |
| Syscall core | 100 | 100 | Complete for the scoped syscall sequencing row. Policy, many handler subpaths, direct ID leaf bodies, uid/gid getters and setters, mckfd lookup/dispatch, memory-policy syscalls including `get_mempolicy()`, `set_mempolicy()`, and `mbind()` body sequencing, signal/time/scheduler/wait/ptrace body sequencing, `do_wait()` traversal and result shaping, and top-level `ptrace()` request/callback body dispatch moved. Top-level syscall dispatch, actual user-copy primitive, Linux forwarding callback bodies, lock and CPU-interrupt primitive bodies, allocation/free, register/fp primitives, process-memory access, signal-delivery primitive behavior, ptrace lookup/orchestration, waitqueue/schedule/signal primitive behavior, scheduler migration side-effect bodies, broader scheduler/time primitive bodies, and other primitive C callback implementations still block standalone Rust and neighboring primitive ownership outside this completed scoped row. |
| Scheduler/timers/wait/futex | 100 | 100 | Complete for the scoped scheduler/timer/futex sequencing row. Queue/list helpers, policies, scheduler syscall validation/target-selection/permission-check/user-copy sequencing for set/get-param, set/get-scheduler, RR-interval queries, set-affinity, and get-affinity, scheduler migration-request body sequencing for waitq setup, request queue publication, target runqueue flag/status mutation, remote interrupt decision, log callback dispatch, schedule handoff, and waitq finish, scheduler migration-completion body sequencing for migration queue traversal, request detach/ack gates, affinity target selection, runqueue detach/add with length mutation, thread CPU update, same-VM sibling scan, address-space CPU-set update, target reschedule flag publication, interrupt dispatch, waitqueue wake, and lock ordering, `init_timers()` list/lock init sequencing, `schedule_timeout()` spin-wake/runqueue/schedule-callback/spin-loop/timeout-expiry sequencing, `wake_timers_loop()` timer tick/decrement/detach/log/wakeup sequencing, `set_timer()` runqueue scan and LAPIC enable/disable decision sequencing, local interval-timer current-value subtraction, elapsed reset, enabled-state publication, set-timer callback dispatch, futex table orchestration, futex bucket selection, top-level futex command dispatch, futex wake target orchestration, futex queue/unqueue/wait body sequencing, futex key construction, futex wake/requeue/wake-op return orchestration, and futex wait entry/profile sequencing moved. Actual spinlock primitives, rdtsc/pause primitive behavior, LAPIC timer primitive behavior, waitqueue wake primitive behavior, IPIs, context switching, futex key lifetime, user-value loads, allocation/hash callbacks, IKC send and scheduler wake primitives, migration primitive callbacks, race retry, `schedule()` primitive behavior, and broader wait/requeue side effects remain C-owned outside this completed scoped row. |
| procfs/sysfs/xpmem/file objects | 100 | 100 | Complete for the scoped file-object/XPMEM sequencing row. Rust now owns the procfs/sysfs data-production and request-sequencing bodies listed in `overview.txt`, live mckfd syscall lookup/dispatch plus close unlink/callback/free sequencing, XPMEM open/close/dup/flush lifecycle sequencing, XPMEM release/remove wrapper sequencing, XPMEM AP hash-bucket release-drain sequencing, XPMEM thread-group destroy dispatch, XPMEM access-permit release lifecycle sequencing, XPMEM segment-removal lifecycle sequencing, XPMEM thread-group segment-list drain sequencing, public XPMEM detach wrapper sequencing, `xpmem_vm_munmap()` begin/remove/finish sequencing, internal `xpmem_detach_att()` sequencing, XPMEM clear-PTE wrapper/range/AP/attachment traversal and unpin/lookup/munmap/VALIDPTE sequencing, and `xpmem_remove_process_memory_range()` null/destroying/full-detach/trim/split sequencing. Actual allocation/free primitives outside covered mckfd allocation/free-callback dispatch, refcount primitive behavior, lock/list primitive behavior, remove-range/free-range/page-table primitive behavior, page I/O, procfs request mapping/lookup/lock primitive behavior, raw sysfs/procfs IKC send behavior, public IKC handler wrapping/logging, and user-copy still block standalone Rust and neighboring primitive ownership outside this completed row. |
| host/IKC/mcctrl/IHK kernel paths | 100 | 100 | Complete for the scoped host/IKC/IHK sequencing row. Rust now owns the bounded IHK host DMA request callback dispatcher, the host SCD packet dispatcher body for init-channel ACK, prepare-process, schedule-process, wake-syscall-thread, remote page-fault, send-signal, procfs request/release, cleanup process/fd, debug-log, sysfs show/store/release, perf-control, CPU register, unknown-message, and packet-release sequencing, top-level syscall packet-handler wrapper sequencing for raw packet casting, response-channel callback selection, current-thread callback selection, dispatch constant shaping, dispatch call/return, and packet release, dummy packet-handler release sequencing, host `process_msg_prepare_process()` freeze-gate, descriptor map/span validation, mapping, validation, clone, main-thread creation, process/thread/VM metadata publication, NUMA policy publication, prepare-ranges dispatch, success cleanup/unmap/TLB flush, and failure destroy/free/unmap return shaping, host prepare-ranges ELF section-loop sequencing, interpreter/aout relocation, section page-span/range calculation, memory-range creation, user-page allocation, page-table mapping dispatch/failure cleanup, remote-PA and text/data/map/brk publication, entry/auxv/context adjustment, data-too-large return shaping, host args/envs stack-prep sequencing for arg/env range placement, allocation/physical publication, remote/local copy orchestration, saved_cmdline publication, argv/env pointer fixup, vDSO map/clear, rprocess/rpgtable publication, and init-stack callback dispatch, plus `init_process_stack()` primary execution-body sequencing for stack sizing/range selection, AP-user policy, allocation, zeroing, VM range creation, page-table set-range callback dispatch, auxv/argv/env layout, `saved_auxv` publication, user stack pointer publication, and VM stack bounds, plus host IKC2Linux channel-table allocation/zeroing/publication, connect-parameter shaping, retry/delay/log sequencing, channel-slot publication, current-channel callback sequencing, public IKC2Linux init panic-on-error wrapper sequencing, host IKC2McKernel parameter shaping, retry/delay/log sequencing, regular-channel callback sequencing, and public IKC2McKernel init panic-on-error wrapper sequencing. Device allocation, memory registration, file I/O, waits/callbacks beyond those bounded dispatchers, primitive callback side effects including map/unmap/copy/user-page allocation, allocation/connect/delay/current-channel/regular-channel primitive bodies, broad IKC exchange mutation, raw IKC send side effects, broad allocation/lifetime, and kernel object lifecycle remain C-owned outside this completed sequencing row. |

Latest strict-core movement for the Page allocator low-level dispatch batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: Page allocator strict
  ownership moves 99% -> 100%, because Rust now owns ten connected low-level
  allocator dispatch slices covering `pa_ops` storage, tracking-init callback
  ordering, early-invalidate callback ordering, allocator ops publication,
  aligned allocation pa-ops versus early-allocation selection, missing
  allocation-callback/null handling, default page-allocation
  alignment/node/virtual-address shaping, free-side pa-ops/null/free-callback
  selection, exported `___ihk_mc_*()` body publication from Rust, and C wrapper
  demotion to fallback/ABI scaffolding.
- Post-+50 strict-core movement is now about +398 points. C still owns C
  fallback scaffolding, pa-ops implementation callback bodies, actual
  allocation/free primitive side effects below the published ops callbacks,
  MCS/interrupt primitive bodies, current-node primitive lookup, IKC
  channel/send side effects, logging/panic primitive bodies, deferred-zero
  worker timing, FUGAKU debug preempt behavior, and broader allocator lifetime.
- Standalone Rust readiness remains about 40% because the default OS/control
  path still requires the C-owned primitive substrate and fallback pieces listed
  above.

Previous strict-core movement for the host IKC public-handler batch:

- Broad dashboard movement is 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: host/IKC/mcctrl/IHK
  kernel paths moves 99% -> 100%, because Rust now owns ten connected public
  handler/wrapper slices covering syscall packet casting, response-channel
  callback lookup, current-thread callback lookup, dispatch constant shaping,
  dispatch call/return, dummy handler packet release, public IKC2Linux init
  result-call sequencing, IKC2Linux panic-on-error behavior, public
  IKC2McKernel init result-call sequencing, and IKC2McKernel panic-on-error
  behavior.
- Post-+50 strict-core movement is now about +397 points. C still owns C
  fallback scaffolding, device allocation, memory registration, file I/O,
  primitive callback side effects including map/unmap/copy/user-page
  allocation, allocation/connect/delay/current-channel/regular-channel
  primitive bodies, raw IKC send side effects, broad IKC exchange mutation,
  broad allocation/lifetime, and kernel object lifecycle.
- Standalone Rust readiness remains about 40% because the default OS/control
  path still requires the C-owned primitive substrate listed above.

Previous strict-core movement for the pagealloc public-wrapper batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: Page allocator strict
  ownership moves 98% -> 99%, because Rust now owns ten connected public
  bitmap page-allocator wrapper slices covering exported
  `__ihk_pagealloc_init()` failure-log/status routing, `ihk_pagealloc_init()`
  default-initializer sequencing, `ihk_pagealloc_destroy()` free-callback
  dispatch, `ihk_pagealloc_alloc()` lock-node/alloc dispatch,
  `ihk_pagealloc_reserve()` lock-node/reserve dispatch,
  `ihk_pagealloc_free()` bad-address capture and double-free error callback
  routing, `ihk_pagealloc_count()` lock/count dispatch,
  `ihk_pagealloc_query_free()` lock/query dispatch,
  `__ihk_pagealloc_zero_free_pages()` begin/locked-zero/done sequencing, and
  focused public-wrapper equivalence coverage for success, invalid,
  init-fail, lock-callback, and zero-log paths.
- Post-+50 strict-core movement is now about +396 points. C still owns C
  fallback scaffolding, pa-ops primitive behavior, low-level page
  allocation/free primitive bodies, MCS/interrupt primitive bodies,
  current-node primitive lookup, IKC channel/send side effects, logging/panic
  primitive bodies, deferred-zero worker timing, FUGAKU debug preempt behavior,
  and broader allocator lifetime.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned allocator primitive substrate listed above.

Previous strict-core movement for the NUMA allocator-lifecycle batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: Page allocator strict
  ownership moves 97% -> 98%, because Rust now owns ten connected
  `numa_init()` lifecycle slices covering NUMA-node discovery, node
  id/Linux-id/type publication, allocator-list and node-distance reset
  publication, rbtree-node primitive-init callback ordering, memory-chunk
  iteration, last-early-heap start adjustment, rbtree add-free dispatch,
  legacy page-allocator init/list publication dispatch, physical-memory and
  final-node log callback sequencing, and total-memory rusage accounting.
- Post-+50 strict-core movement was about +395 points. C still owns C
  fallback scaffolding, pa-ops primitive behavior, low-level page
  allocation/free primitive bodies, MCS/interrupt primitive bodies,
  current-node primitive lookup, IKC channel/send side effects, logging/panic
  primitive bodies, deferred-zero worker timing, FUGAKU debug preempt behavior,
  and broader allocator lifetime.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned allocator primitive substrate listed above.

Previous strict-core movement for the memory-policy syscall batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%.
- Strict-core movement is about +2 verified row points: Syscall core strict
  ownership moves 98% -> 100% for the scoped sequencing row, because Rust now
  owns twenty connected `set_mempolicy()` and `mbind()` slices covering
  nodemask validation/copyin, process-mask mutation, range-policy
  lock/lookup/clear/allocate/insert/update sequencing, and policy/interleave
  publication.
- Post-+50 strict-core movement is now about +394 points. C still owns C
  fallback scaffolding, the actual user-copy primitive, memory-range
  lock/lookup primitives, range-policy tree/allocator primitives, top-level
  syscall dispatch, Linux forwarding, allocation/free, signal-delivery
  primitives, ptrace/process-memory primitives, waitqueue/schedule/signal
  behavior, and broader primitive side effects.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned syscall and primitive substrate listed above.

Previous strict-core movement for the fault/PTE lookup batch:

- Broad dashboard movement is 0 points because the Process/VM row is already
  capped at 100%.
- Strict-core movement is about +1 verified row point: Process/VM strict
  ownership moves 99% -> 100% for the scoped sequencing row, because Rust now
  owns ten connected `ihk_mc_pt_lookup_fault_pte()` and `lookup_node()` slices:
  initial PTE lookup dispatch, missing/inactive PTE classification,
  `PF_POPULATE | PF_USER` page-fault callback dispatch, retry lookup,
  recovered-PTE log dispatch, lookup-node fault error return shaping,
  address-space/page-table extraction by verified offsets, post-fault PTE
  lookup with null output pointers, missing-PTE `-ENOENT` shaping, and
  physical-to-NUMA-node return shaping.
- Post-+50 strict-core movement was about +391 points. C still owns C
  fallback scaffolding, raw page-fault behavior, actual page-table
  lookup/allocation/mapping side effects, VM range allocation/free callbacks,
  split/XPMEM primitive callbacks, memobj refcount primitives, lock/free
  primitive bodies, signal-delivery primitives, child-list/lifetime traversal,
  broad rusage traversal, and broader process lifetime.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned process/VM and page-table primitive substrate listed
  above.

Previous strict-core movement for the allocator query-free interrupt batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: Page allocator strict
  ownership moved 96% -> 97%, because Rust now owns ten connected
  `query_free_mem_interrupt_handler()` slices: NUMA-node iteration, per-node
  free-page callback dispatch, total accumulation, total free-page logging,
  optional FUGAKU panic dispatch, `memdebug` command lookup,
  `kmalloc_memcheck()` callback dispatch, `pagealloc_memcheck()` callback
  dispatch, page-hash count/log callback dispatch, and optional ATTACHED_MIC
  sbox scratch publication.
- Post-+50 strict-core movement was about +390 points. C still owns C
  fallback scaffolding, per-allocator query primitive behavior, pa-ops
  primitive behavior, low-level page allocation/free primitive bodies,
  MCS/interrupt primitive bodies, IKC channel/send side effects,
  logging/panic primitives, deferred-zero worker timing, FUGAKU debug preempt
  behavior, and broader allocator lifetime.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned primitive allocator substrate listed above.

Previous strict-core movement for the allocator policy/free-wrapper batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: Page allocator strict
  ownership moved 95% -> 96%, because Rust now owns ten connected wrapper
  slices: invalid-size rejection, not-initialized/idle fallback policy shaping,
  current-VM lookup gating, user-VA range-policy search, memory-range lookup,
  shared-memory gate selection, range-policy field selection, process-policy
  fallback selection, current-node/nr-node publication into the allocation
  policy body, and top-level `mckernel_free_pages()` virt-to-phys/
  phys-to-page/pending-free/allocator-free handoff sequencing.
- Post-+50 strict-core movement was about +389 points. C still owns C
  fallback scaffolding, pa-ops primitive behavior, low-level page
  allocation/free primitive bodies, MCS/interrupt primitive bodies,
  current-node lookup, IKC send/channel behavior, logging/panic primitives,
  deferred-zero worker timing, FUGAKU debug preempt behavior, and broader
  allocator lifetime.
- Standalone Rust readiness remains about 40% because the default OS path still
  requires the C-owned primitive allocator substrate listed above.

Previous strict-core movement for the init-stack body batch:

- Broad dashboard movement is 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement is about +1 verified row point: host/IKC/mcctrl/IHK
  kernel paths moves 98% -> 99%, because Rust now owns
  `init_process_stack()` primary execution-body sequencing: stack sizing,
  max/min limit selection, AP-user policy, aligned allocation, stack zeroing,
  VM stack range creation, page-table set-range callback dispatch, auxv/argv/env
  stack layout, `saved_auxv` publication, user stack pointer/context
  publication, and VM stack bound publication.
- Post-+50 strict-core movement was about +388 points. C still owns C
  fallback scaffolding, primitive map/unmap/copy/user-page allocation,
  mapping/thread/range primitive callbacks, raw IKC send side effects, device
  allocation, memory registration, file I/O, waits/callbacks beyond bounded
  dispatchers, broad allocation/lifetime, and kernel object lifecycle.
- Standalone Rust readiness remains about 40% because the default OS path
  still requires C fallback scaffolding and the C-owned primitive/control-plane
  substrate listed above.

Previous strict-core movement for the host args/envs stack-prep batch:

- Broad dashboard movement is 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement is about +10 verified body-slice points:
  host/IKC/mcctrl/IHK kernel paths moves 96% -> 98%, because Rust now owns
  `prepare_process_ranges_args_envs()` args/envs stack-prep sequencing:
  arg/env page-count and range placement, argenv page allocation and physical
  publication, argenv memory-range creation and error/free shaping, remote
  args map/copy/unmap/TLB sequencing, remote envs map/copy/unmap/TLB sequencing,
  local args/envs length publication, saved_cmdline free/alloc/copy publication,
  argv/env pointer fixup into process VA, vDSO map/clear and
  rprocess/rpgtable publication, and init_process_stack callback dispatch/error
  shaping.
- Post-+50 strict-core movement was about +387 points. C still owns C
  fallback scaffolding, primitive map/unmap/copy/user-page allocation and
  init_process_stack internals, mapping/thread/range primitive callbacks, raw
  IKC send side effects, device
  allocation, memory registration, file I/O, waits/callbacks beyond bounded
  dispatchers, broad allocation/lifetime, and kernel object lifecycle.
- Standalone Rust readiness remains about 40% because the default OS path
  still requires C fallback scaffolding and the C-owned primitive/control-plane
  substrate listed above.

Previous strict-core movement for the host prepare-process batch:

- Broad dashboard movement was 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement was about +12 verified body-slice points:
  host/IKC/mcctrl/IHK kernel paths moved 91% -> 94%, because Rust now owns
  `process_msg_prepare_process()` body sequencing: monitor freeze/frozen gate
  evaluation, program descriptor map-size/page-span calculation, host memory
  map/virtual map/failure cleanup, descriptor magic and section-count
  validation, descriptor clone allocation/copy, main-thread creation and
  cleanup, process PID/PGID/credential/rlimit/profile/VM metadata publication,
  NUMA bind/nodemask policy publication, prepare-ranges callback dispatch,
  success cleanup/unmap/TLB flush, and failure destroy/free/unmap return
  shaping.
- Post-+50 strict-core movement was about +367 points. C still owns C
  fallback scaffolding, mapping/thread/range primitive callbacks, raw IKC send
  side effects, device allocation, memory registration, file I/O,
  waits/callbacks beyond bounded dispatchers, broad allocation/lifetime, and
  kernel object lifecycle.
- Standalone Rust readiness remains about 40% because the default OS path
  still requires C fallback scaffolding and the C-owned primitive/control-plane
  substrate listed above.

Latest strict-core movement for the Process/VM free-range orchestration batch:

- Broad dashboard movement is 0 points because Process/VM management is already
  capped at 100%.
- Strict-core movement is about +10 verified body-slice points:
  Process/VM management moves 97% -> 99%, because Rust now owns
  `free_process_memory_range()` body sequencing: previous/next range discovery,
  page-table free/clear action planning, page-table lock/unlock callback
  ordering, memobj ref/unref ordering around free-range side effects,
  page-table free callback dispatch, page-table clear callback dispatch,
  TOFU removal callback dispatch, final range detach/straight cleanup callback
  dispatch, error log selection, and final return shaping.
- Post-+50 strict-core movement is now about +355 points. C still owns C
  fallback scaffolding, VM range allocation callbacks, split/XPMEM primitive
  callbacks, memobj refcount primitives, TOFU split/merge hooks, actual
  page-table lookup/allocation/mapping/free/clear primitive effects,
  page-fault range-resolution primitive behavior, broad process lifetime,
  rusage traversal, signal-delivery primitives, atomic refcount primitive
  behavior, lock/free primitive bodies, and wait primitive behavior.
- Standalone Rust readiness remains about 40% because the default kernel path
  still requires C fallback scaffolding and the C-owned primitive substrate
  listed above.

Previous strict-core movement for the Process/VM remove-range orchestration batch:

- Broad dashboard movement is 0 points because Process/VM management is already
  capped at 100%.
- Strict-core movement is about +10 verified body-slice points:
  Process/VM management moved 95% -> 97%, because Rust now owns
  `remove_process_memory_range()` body sequencing: straight-map conversion and
  missing-straight handling, range lookup/iteration, split-start and split-end
  callback sequencing, read-only freed publication, XPMEM removal callback
  dispatch, free callback dispatch, error log selection, and final return
  shaping.
- Post-+50 strict-core movement was about +345 points. C still owned C
  fallback scaffolding, VM range allocation/free callbacks,
  split/free/XPMEM primitive callbacks, memobj refcount primitives, TOFU hooks,
  actual page-table lookup/allocation/mapping/free/clear side effects,
  page-fault range-resolution primitive behavior, broad process lifetime,
  rusage traversal, signal-delivery primitives, atomic refcount primitive
  behavior, lock/free primitive bodies, and wait primitive behavior.

Previous strict-core movement for the Process/VM page-fault/populate batch:

- Broad dashboard movement was 0 points because Process/VM management was
  already capped at 100%.
- Strict-core movement was about +10 verified body-slice points:
  Process/VM management moved 93% -> 95%, because Rust now owns
  do-page-fault VM outer-body sequencing for stack-grow range selection,
  write/read memory-range lock decisions, exiting and out-of-range checks,
  permission checks, zero-object `PF_POPULATE` promotion, normal-vs-XPMEM
  range-fault dispatch, and unlock/return shaping. Rust also owns
  `page_fault_process_vm()` `-ERESTART` retry sequencing around preempt
  enable/disable and page-I/O callback dispatch/clear, plus
  `populate_process_memory()` preempt, per-page fault, first-error warning,
  and return sequencing.
- Post-+50 strict-core movement was about +335 points. C still owned C
  fallback scaffolding, VM range allocation/free callbacks, memobj refcount
  primitives, TOFU hooks, actual page-table lookup/allocation/mapping/free/clear
  side effects, page-fault range-resolution primitive behavior, broad process lifetime, rusage traversal,
  signal-delivery primitives, atomic refcount primitive behavior, lock/free
  primitive bodies, and wait primitive behavior.

Previous strict-core movement for the Process/VM range lookup/access/protection batch:

- Broad dashboard movement was 0 points because Process/VM management was already
  capped at 100%.
- Strict-core movement was about +10 verified body-slice points:
  Process/VM management moved 91% -> 93%, because Rust now owns VM range lookup
  body traversal, range-cache hit/store sequencing, first overlap selection,
  next/previous range iteration, extend-up validation/commit, change-protection
  new-flag calculation, attr-delta shaping, private-file writable suppression,
  page-table lock/change-attr callback sequencing, `-ENOENT` acceptance, final
  flag publication, and `access_ok()` initial-range, adjacency, permission, and
  multi-range loop validation.
- Post-+50 strict-core movement was about +325 points. C still owned C
  fallback scaffolding, VM range allocation/free callbacks, memobj refcount
  primitives, TOFU hooks, actual page-table lookup/allocation/mapping/free/clear
  side effects, page-fault range-resolution primitive behavior, broad process
  lifetime, rusage traversal, signal-delivery primitives, atomic refcount
  primitive behavior, lock/free primitive bodies, and wait primitive behavior.

Previous strict-core movement for the XPMEM clear-PTE/remove-range batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement is about +10 verified body-slice points:
  procfs/sysfs/xpmem/file objects moves 99% -> 100% for the scoped sequencing
  row, because Rust now owns XPMEM clear-PTE wrapper, segment/AP/attachment
  traversal, AP ref/unlock/clear/relock/deref sequencing, attachment
  read-lock/write-lock range calculation, unpin callback dispatch, range
  lookup, munmap callback dispatch, VALIDPTE clearing, and
  out-of-range/missing-range preservation paths. Rust also owns
  `xpmem_remove_process_memory_range()` null-private-data, already-destroying,
  full-detach, front/tail trim, middle split, private-data publication, and
  invalid-split result sequencing.
- Post-+50 strict-core movement was about +315 points. C still owns C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, remove-range/free-range/page-table
  primitive behavior, raw IKC/procfs/sysfs exchange, page I/O, user-copy, and
  broader high-risk file/object bodies.

Previous strict-core movement for the XPMEM release-management wrapper/drain batch:

- Broad dashboard movement was 0 points because the procfs/sysfs/xpmem/file
  objects row was already capped at 100%.
- Strict-core movement is about +9 verified body-slice points:
  procfs/sysfs/xpmem/file objects moved 97% -> 98%, because Rust now owns
  XPMEM release-management wrapper/drain sequencing: AP hash-bucket iteration,
  per-bucket writer-lock/unlock sequencing, empty-bucket handling, first-AP
  selection from hash-list heads, AP ref/unlock/release/deref/relock ordering,
  release/remove syscall wrapper positive-ID, owner, object-lookup, action,
  and deref sequencing, and thread-group destroyable/deref dispatch.
- Post-+50 strict-core movement was about +295 points. The remaining C-owned
  blockers were C fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, raw attachment detach internals,
  raw IKC/procfs/sysfs exchange, page I/O, user-copy, PTE-clear primitive
  behavior, and broader high-risk file/object bodies.

Previous strict-core movement for the XPMEM access-permit release batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement is about +8 verified body-slice points:
  procfs/sysfs/xpmem/file objects moves 96% -> 97%, because Rust now owns
  XPMEM access-permit release lifecycle sequencing: destroy-start gating,
  attachment-list drain, attachment ref/detach/deref callback ordering, final
  destroyed-state publication, AP hash-list unlink, segment AP-list unlink,
  segment and segment-thread-group deref callback ordering, AP destroyable
  dispatch, debug-log event selection, and already-destroying early return
  behavior.
- Post-+50 strict-core movement is now about +286 points. C still owns C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, raw attachment detach internals,
  raw IKC/procfs/sysfs exchange, page I/O, user-copy, PTE-clear primitive
  behavior, and broader high-risk file/object bodies.

Previous strict-core movement for the XPMEM segment-list drain batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement was about +5 verified body-slice points:
  procfs/sysfs/xpmem/file objects moved 95% -> 96%, because Rust now owns
  XPMEM thread-group segment-list drain sequencing: writer-lock acquisition,
  empty-list detection, first-segment selection from the list head, segment
  refcount callback ordering, unlock-before-removal, per-segment removal
  callback dispatch, deref callback ordering, relock loop sequencing, final
  unlock, debug-log event selection, and empty-list return behavior.
- Post-+50 strict-core movement was about +278 points. C still owned C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, raw IKC/procfs/sysfs exchange, page I/O,
  user-copy, PTE-clear primitive behavior, and broader high-risk file/object
  bodies.

Previous strict-core movement for the XPMEM segment-removal lifecycle batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement was about +8 verified body-slice points:
  procfs/sysfs/xpmem/file objects moved 94% -> 95%, because Rust now owns
  XPMEM segment-removal lifecycle sequencing: destroy-start gating, segment
  destroy-flag publication, PTE-clear callback ordering, final destroyed-state
  publication, segment-list lock/unlock ordering, list unlink,
  destroyable/refdrop callback dispatch, debug-log event selection, and
  already-destroying early return behavior.
- Post-+50 strict-core movement was about +273 points. C still owned C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, raw IKC/procfs/sysfs exchange, page I/O,
  user-copy, PTE-clear primitive behavior, and broader high-risk file/object
  bodies.

Previous strict-core movement for the XPMEM close/dup/flush lifecycle batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement was about +8 verified body-slice points:
  procfs/sysfs/xpmem/file objects moved 93% -> 94%, because Rust now owns
  XPMEM `close()`/`dup()`/flush lifecycle sequencing: duplicate data clearing
  and open-count increment, close open-count decrement and logging,
  flush/partition-exit decisions, flush target-group lookup under the
  partition hash-list lock, target-group list unlink, destroy-flag
  publication, access-permit and segment-release callback ordering, final
  destroyed-state publication, and destroy callback dispatch.
- Post-+50 strict-core movement was about +265 points. C still owned C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  raw refcount/list primitive behavior, raw IKC/procfs/sysfs exchange, page I/O,
  user-copy, and broader high-risk file/object bodies.

Previous strict-core movement for the XPMEM open-body batch:

- Broad dashboard movement is 0 points because the procfs/sysfs/xpmem/file
  objects row is already capped at 100%.
- Strict-core movement is about +8 verified body-slice points:
  procfs/sysfs/xpmem/file objects moves 92% -> 93%, because Rust now owns
  XPMEM `open()`/`openat()` body sequencing below the syscall pathname wrapper:
  partition-init gate, Linux fd-forward result handling, `__xpmem_open()`
  callback ordering, mckfd allocation/null handling, mckfd zeroing and
  fd/signal/data/callback publication, locked list-head insertion, unlock
  ordering, open-count increment, and debug-log event selection.
- Post-+50 strict-core movement is now about +257 points. C still owns C
  fallback scaffolding, primitive allocation/free, primitive locks and atomics,
  Linux forwarding, pathname copy/classification in the syscall wrapper, raw
  IKC/procfs/sysfs exchange, user-copy, and broader high-risk file/object
  bodies.

Previous strict-core movement for the mckfd syscall dispatch batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%, and the procfs/sysfs/xpmem/file objects row is also capped.
- Strict-core movement is about +10 verified body-slice points: Syscall core
  strict ownership moves 96% -> 97%, and procfs/sysfs/xpmem/file objects moves
  91% -> 92%, because Rust now owns live `read()`, `ioctl()`, `fcntl()`, and
  `close()` mckfd syscall body sequencing: locked lookup traversal,
  callback-vs-forward selection, optional TOFU ioctl/close cleanup gates,
  close unlink mutation, close-callback dispatch, mckfd free-callback dispatch,
  and Linux-forward fallback sequencing.
- Post-+50 strict-core movement is now about +249 points. C still owns C
  fallback scaffolding, primitive locks, Linux forwarding, XPMEM open/openat
  creation, raw allocation/free primitives, user-copy, syscall dispatch, and
  broader high-risk file/object/syscall bodies.

Previous strict-core movement for the ten-slice syscall wrapper batch:

- Broad dashboard movement was 0 points because the Syscall core row was
  already capped at 100%.
- Strict-core movement was about +10 verified body-slice points while the
  Syscall core strict ownership row moved 95% -> 96%, because Rust now owns
  `times()`, `setpgid()`, `setrlimit()`, `getrlimit()`, `prlimit64()`,
  `sysinfo()`, `get_cpu_id()`, `mlockall()`, `munlockall()`, and `getcpu()`
  wrapper-body sequencing.
- Post-+50 strict-core movement was about +239 points.

Previous strict-core movement for the signal/credential syscall wrapper batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%.
- Strict-core movement is about +10 verified body-slice points while the
  Syscall core strict ownership row moves 94% -> 95%, because Rust now owns
  the wrapper-body sequencing for `kill()`, `tgkill()`, `tkill()`,
  `setresuid()`, `setreuid()`, `setuid()`, `setfsuid()`, `setresgid()`,
  `setregid()`, `setgid()`, and `setfsgid()`: signal-target validation,
  siginfo construction, do-kill callback dispatch, Linux-forward callback
  dispatch, credential-refresh callback dispatch, setfsid syscall callback
  dispatch, return shaping, and missing-callback error shaping.
- Post-+50 strict-core movement is now about +229 points. C still owns the
  primitive bodies behind those callbacks: Linux forwarding, credential source
  refresh, actual signal delivery, user-copy, locks, allocation/free, syscall
  dispatch, default-path C fallback scaffolding, and broader high-risk syscall
  bodies.

Previous strict-core movement for the ptrace syscall request-dispatch batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%.
- Strict-core movement is about +10 verified body-slice points while the
  Syscall core strict ownership row moves 93% -> 94%, because Rust now owns
  the top-level `ptrace()` request/callback body dispatch for `PTRACE_TRACEME`,
  kill/continue/singlestep/syscall wake requests, register/fpreg/regset
  get/set requests, user/text peek/poke requests including data aliases,
  set-options, attach/detach, siginfo/eventmsg, arch fallback, and
  unsupported/missing-callback error shaping.
- Post-+50 strict-core movement is now about +219 points. C still owns the
  primitive handler bodies behind those callbacks: thread lookup/unlock,
  user-copy, register/fpreg/regset primitives, process-memory read/patch,
  signal delivery, allocation/free, default-path C fallback scaffolding, and
  broader high-risk syscall bodies.

Previous strict-core movement for the ptrace-detach body batch:

- Broad dashboard movement is 0 points because the Syscall core and Process/VM
  rows are already capped at 100%.
- Strict-core movement is about +2 points: Syscall core strict ownership moves
  92% -> 93%, and Process/VM strict ownership moves 90% -> 91%, because Rust
  now owns `ptrace_detach_thread()` main-body sequencing: main-thread detach
  gating, zombie finalization selection, tracer child-list detach, ptraced
  reparenting to the original parent, report-list detach/reattach, ptrace
  cleanup/free callback dispatch, single-step clear dispatch, exit-signal
  dispatch, forwarded-signal siginfo construction, `do_kill()` callback
  sequencing, wake/release dispatch, and final process finalization dispatch.
- Post-+50 strict-core movement is now about +209 points. C still owns
  primitive lock/list/free/wakeup/signal callback bodies, syscall dispatch,
  user-copy primitives, ptrace lookup/orchestration, default-path C fallback
  scaffolding, and broader high-risk handler bodies.

Latest strict-core movement for the wait-scan traversal syscall batch:

- Broad dashboard movement is 0 points because the Syscall core and Process/VM
  rows are already capped at 100%.
- Strict-core movement is about +3 points: Syscall core strict ownership moves
  90% -> 92%, and Process/VM strict ownership moves 89% -> 90%, because Rust
  now owns the outer process/thread wait scans under `do_wait()`: parent
  children-lock callback ordering, children-list traversal, pid/pgid matching,
  `empty` publication, process-zombie dispatch, process stopped/continued
  candidate dispatch, ptraced-children empty-scan traversal, report-thread
  list traversal, report-thread candidate dispatch, regular thread-list
  empty-scan traversal, and no-found unlock/return sequencing.
- Post-+50 strict-core movement is now about +207 points. C still owns the
  primitive lock/list/free bodies, waitqueue/schedule/signal primitive
  behavior, host wait primitive behavior, syscall dispatch, user-copy
  primitives, default-path C fallback scaffolding, and broader high-risk
  handler bodies.

Previous strict-core movement for the wait-zombie/reparent syscall batch:

- Broad dashboard movement is 0 points because the Syscall core and Process/VM
  rows are already capped at 100%.
- Strict-core movement is about +2 points: Syscall core strict ownership moves
  89% -> 90%, and Process/VM strict ownership moves 88% -> 89%, because Rust
  now owns the process-zombie branch under `do_wait()`: zombie status
  publication, host wait4 skip/request/log selection, parent rusage
  aggregation, rusage result fill, parent child-list detach, PID-1
  reparent/list attach, child main-thread ptrace-detach gate, parent and child
  lock/unlock callback ordering, no-reparent unlock/detach ordering, and
  process release callback dispatch.
- Post-+50 strict-core movement was about +204 points. C still owned
  child/thread list traversal, broader zombie scan/reparent surroundings,
  primitive lock/list/free bodies, waitqueue/schedule/signal primitive
  behavior, broader rusage traversal, release/detach primitive bodies, and
  fallback scaffolding.

Previous strict-core movement for the wait-candidate syscall batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%.
- Strict-core movement is about +1 point: Syscall core strict ownership moves
  88% -> 89% because Rust now owns the `wait_proc()`/`wait_thread()` candidate
  result sequencing under `do_wait()`: process and report-thread stopped,
  ptraced-stopped, continued, and report-thread exited candidates; ptraced
  stop miss return preservation; process TID rewrite for requested thread
  waits; report-list detach, ptrace-detach, release, reap, unlock, and found
  publication callback ordering.
- Post-+50 strict-core movement was about +202 points. C still owned
  child/thread list traversal, zombie scan/reparent behavior, primitive lock
  bodies, waitqueue/schedule/signal primitive behavior, rusage aggregation,
  release/detach primitive bodies, and fallback scaffolding.

Previous strict-core movement for the do_wait syscall batch:

- Broad dashboard movement is 0 points because the Syscall core row is already
  capped at 100%.
- Strict-core movement is about +1 point: Syscall core strict ownership moves
  87% -> 88% because Rust now owns top-level `do_wait()` wait-loop sequencing
  for waitqueue init/prepare/finish callback ordering, process/thread scan
  dispatch gates, no-child and `WNOHANG` result shaping, pending-signal
  interrupt return, schedule callback handoff, wake/rescan behavior, and wait
  log callback ordering.
- Post-+50 strict-core movement was about +201 points. C still owned
  `wait_proc()`/`wait_thread()` child/thread list traversal and mutation,
  waitqueue/schedule/signal primitive behavior, rusage aggregation,
  release/detach side effects, and fallback scaffolding.

Previous strict-core movement for the scheduler migration-completion batch:

- Broad dashboard movement is 0 points because the Scheduler/timers/wait/futex
  row is already capped at 100%.
- Strict-core movement is about +2 post-cap points: Rust now owns
  `do_migrate()` body sequencing for migration queue traversal, request
  detach and ack gates, affinity target selection, runqueue detach/add with
  length mutation, thread CPU update, same-VM sibling scan, address-space
  CPU-set lock/update, target reschedule flag publication,
  interrupt/vector callback dispatch, waitqueue wake callback dispatch, lock
  ordering, and validation/error shaping.
- Post-+50 strict-core movement was about +200 points. C still owns
  spinlock/waitqueue/interrupt/vector/log primitive bodies, CPU-local lookup
  callbacks, context switching, `schedule()` primitive behavior, and fallback
  scaffolding.

Previous strict-core movement for the scheduler migration-request batch:

- Broad dashboard movement was 0 points because the Scheduler/timers/wait/futex
  row was already capped at 100%.
- Strict-core movement was about +2 post-cap points: Rust moved
  `sched_request_migrate()` body sequencing for request thread publication,
  target migration-queue lock callback ordering, waitqueue init/prepare/finish
  callback sequencing, migration request list insertion, target runqueue
  noirq lock/unlock callback ordering, `CPU_FLAG_NEED_RESCHED` and
  `CPU_FLAG_NEED_MIGRATE` publication, `CPU_STATUS_RUNNING` publication,
  remote interrupt vector/callback selection, migration log callback dispatch,
  scheduler callback handoff, and validation/error shaping.
- Post-+50 strict-core movement was about +198 points. C still owned target
  CPU-local lookup, current-thread wait-entry construction,
  spinlock/waitqueue/interrupt/vector/schedule/log primitive bodies, actual
  migration completion in `do_migrate()`, context switching, and fallback
  scaffolding.

Previous strict-core movement for the dump user-page traversal/dispatch batch:

- Broad dashboard movement is 0 points because the x86_64 memory-management
  row is already capped at 100%.
- Strict-core movement is about +1 post-cap point: Rust now owns dump
  user-page process-hash bucket iteration, list cursor traversal, process
  recovery from `hash_list`, VM/address-space/page-table pointer loading,
  null skip gates, visitor argument shaping for `[0, USER_END)`,
  `visit_pte_range_safe()` callback dispatch, and dispatch count/error
  shaping.
- Post-+50 strict-core movement was about +196 points. C still owns current
  resource-set lookup, the page-table visitor primitive and PTE visitor body,
  low-level page/address data sources, process lifetime/list mutation, logging
  primitive behavior, and fallback scaffolding.

Previous strict-core movement for the dump bitmap/completion batch:

- Broad dashboard movement is 0 points because the x86_64 memory-management
  row is already capped at 100%.
- Strict-core movement is about +2 post-cap points: Rust now owns dump
  page-set completion publication, physical-address membership checks,
  variable-length dump bitmap range clearing, user-PTE dump bitmap marking,
  free-chunk dump bitmap marking, and top-level last-CPU dump query
  sequencing.
- Post-+50 strict-core movement is now about +195 points. C still owns process
  traversal, rb-tree primitive traversal callbacks, page-table visit callback
  invocation, low-level page/address data sources, logging primitive behavior,
  and fallback scaffolding.

Previous strict-core movement for the allocator NUMA topology/allocation batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 point: Page allocator strict ownership
  moves 94% -> 95% because Rust now owns NUMA allocation-attempt sequencing
  for OOM flag initialization, NUMA-id bounds validation, rusage OOM callback
  dispatch, and NUMA allocation callback dispatch, plus distance-id lookup and
  distance-ordered node selection for `ihk_mc_get_numa_node_by_distance()`.
- Post-+50 strict-core movement was about +193 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, logging/panic primitive behavior, current-node primitive
  lookup, deferred-zero worker timing, IKC send side effects, FUGAKU debug
  preempt behavior, broader allocator lifetime, and fallback scaffolding.

Previous strict-core movement for the allocator NUMA-distance batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 point: Page allocator strict ownership
  moves 93% -> 94% because Rust now owns `numa_distances_init()` sequencing:
  per-node distance-array allocation, allocation-failure logging, distance
  matrix fill, distance/id sorting, node publication, and ordered log callback
  dispatch.
- Post-+50 strict-core movement was about +192 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, logging/panic primitive behavior, deferred-zero worker
  timing, IKC send side effects, FUGAKU debug preempt behavior, broader
  allocator lifetime, and fallback scaffolding.

Previous strict-core movement for the allocator lifecycle/mem_init batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +1 point: Page allocator strict ownership
  moves 92% -> 93% because Rust now owns `ihk_mc_set_page_allocator()`
  tracking initialization, early-allocator invalidation, and `pa_ops`
  publication, plus top-level `mem_init()` sequencing for monitor/rusage/NUMA
  init, allocator registration, page-fault handler publication, query-free
  interrupt registration, page-hash init, virtual-map init, demand-paging
  flag/log publication, and NUMA-distance init ordering.
- Post-+50 strict-core movement was about +191 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, logging/panic primitive behavior, deferred-zero worker
  timing, IKC send side effects, FUGAKU debug preempt behavior, broader
  allocator lifetime, and fallback scaffolding.

Latest strict-core movement for the allocator tracking/lifecycle batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +2 points: Page allocator strict ownership
  moves 90% -> 92% because Rust now owns shared pagealloc/kmalloc tracking
  hash and lock initialization, pagealloc/kmalloc memcheck leak-scan traversal
  with per-entry address-list locking, current-runcount filtering, leak-count
  accumulation, runcount mutation, detail/summary log callback sequencing, and
  kmalloc remote free-list move/consolidation under the remote-list lock.
- Post-+50 strict-core movement is now about +190 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, logging/panic primitive behavior, deferred-zero worker
  timing, IKC send side effects, FUGAKU debug preempt behavior, broad
  allocator lifetime, and fallback scaffolding.

Latest strict-core movement for the pagealloc tracking wrapper batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement is about +2 points: Page allocator strict ownership
  moves 88% -> 90% because Rust now owns public
  `_ihk_mc_alloc_aligned_pages_node()`/`_ihk_mc_free_pages()` pagealloc
  memdebug tracking wrapper sequencing for no-debug/uninitialized fallback,
  allocation-site lookup/create, file-string publication, page-address entry
  publication, exact/partial/split deallocation tracking, address-entry
  rehashing, last-entry cleanup/free, invalid deallocation callback routing,
  final page-free callback sequencing, and log callback selection.
- Post-+50 strict-core movement is now about +188 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, logging/panic primitive behavior, deferred-zero worker
  timing, IKC send side effects, FUGAKU debug preempt behavior, broad
  allocator lifetime, and fallback scaffolding.

Previous strict-core movement for the kmalloc tracking wrapper batch:

- Broad dashboard movement was 0 points because the Page allocator row was
  already capped at 100%.
- Strict-core movement was about +2 points: Page allocator strict ownership
  moved 86% -> 88% because Rust owned public `_kmalloc()`/`_kfree()`
  memdebug tracking wrapper sequencing for no-debug/null fallback, allocation
  hash selection, tracking-entry lookup/create, file-string publication,
  alloc-count mutation, address-entry list/hash publication, free-side address
  lookup/detach, last-entry cleanup/free, invalid-free callback routing, and
  log callback selection.
- Post-+50 strict-core movement was about +186 points at that checkpoint.

Previous strict-core movement for the kmalloc body batch:

- Broad dashboard movement is 0 points because the Page allocator row is
  already capped at 100%.
- Strict-core movement was about +2 points: Page allocator strict ownership
  moved 84% -> 86% because Rust owned low-level `___kmalloc()` size
  alignment, free-list fit search, chunk split/refill, page-allocation callback
  ordering, interrupt save/restore callback ordering, and return shaping, plus
  low-level `___kfree()` null handling, corruption callback routing,
  current-CPU free-list insertion/consolidation, remote-CPU free-list
  publication under lock callbacks, and normal/error return shaping.
- Post-+50 strict-core movement was about +184 points. C still owns actual
  low-level page allocation/free primitive bodies, interrupt and spinlock
  primitive bodies, tracking wrappers, logging/panic primitive behavior,
  deferred-zero worker timing, IKC send side effects, FUGAKU debug preempt
  behavior, broad allocator lifetime, and fallback scaffolding.

Previous strict-core movement for the host IKC init batch:

- Broad dashboard movement is 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement was about +2 points: host/IKC/mcctrl/IHK kernel paths
  strict ownership moved 89% -> 91% because Rust owned host IKC2Linux
  channel-table allocation/zeroing/publication, connect-parameter shaping,
  retry/delay/log sequencing, channel-slot publication, current-channel
  callback sequencing, and host IKC2McKernel parameter shaping, retry/delay/log
  sequencing, and regular-channel callback sequencing.
- Post-+50 strict-core movement was about +182 points. C still owns actual
  allocation/connect/delay/log/panic/current-channel/regular-channel primitive
  bodies, raw IKC exchange side effects, broad allocation/lifetime, and
  fallback scaffolding.

Previous strict-core movement for the procfs maps/status/stat data-production batch:

- Broad dashboard movement was 0 points because the procfs/sysfs/xpmem/file-object
  row was already capped at 100%.
- Strict-core movement was about +3 points: procfs/sysfs/xpmem/file objects
  strict ownership moved 88% -> 91% because Rust owned `/proc/PID/maps`
  range traversal, path/default selection, permission character selection, and
  line output, `/proc/PID/status` locked-size traversal plus state/ID/VmLck/
  thread/mask output, and per-PID `stat` state/identity/comm/constant-field
  output.
- Post-+50 strict-core movement was about +180 points. C still owned actual
  allocation/free primitives, request map/unmap, process/thread lookup,
  memory-range locking, raw procfs IKC answer send, and fallback scaffolding
  behavior.

Previous strict-core movement for the procfs non-mem data-production batch:

- Broad dashboard movement was 0 points because the procfs/sysfs/xpmem/file-object
  row was already capped at 100%.
- Strict-core movement was about +2 points: procfs/sysfs/xpmem/file objects
  strict ownership moved 86% -> 88% because Rust now owned root `mckernel`
  version/buildid output, root `stat` CPU-line output, per-process `auxv`,
  `cmdline`, and `comm` output, and `/proc/PID/pagemap` value-loop/result
  sequencing.
- Post-+50 strict-core movement was about +177 points. C still owned actual
  allocation/free primitives, request map/unmap, process/thread lookup,
  memory-range locking, page-table primitive behavior, complex procfs
  status/stat/maps-style data production, raw IKC answer send, and fallback
  scaffolding behavior at that checkpoint.

Previous strict-core movement for the procfs mem/buffer batch:

- Broad dashboard movement was 0 points because the procfs/sysfs/xpmem/file-object
  row was already capped at 100%.
- Strict-core movement was about +2 points: procfs/sysfs/xpmem/file objects
  strict ownership moved 84% -> 86% because Rust now owns `buf_alloc()`
  allocation-callback/null/init/optional physical-publication sequencing and
  the `/proc/PID/mem` zero-length/page-fault/translation/memory-gate/phys-map/
  read-vs-write copy-loop/error-shaping body.
- Post-+50 strict-core movement was about +175 points. C still owned actual
  page allocation/free primitives, page-fault primitive behavior, page-table
  translation primitive behavior, `is_mckernel_memory()`, `phys_to_virt()`,
  `memcpy()`, request map/unmap, process/thread lookup, raw IKC answer send,
  and fallback scaffolding behavior at that checkpoint.

Previous strict-core movement for the scheduler/timer batch:

- Broad dashboard movement was 0 points because the Scheduler/timers/wait/futex
  row was already capped at 100%.
- Strict-core movement was about +3 points: Scheduler/timers/wait/futex strict
  ownership moved 97% -> 100% because Rust now owns `init_timers()` list/lock
  initialization sequencing, `schedule_timeout()` spin-wake/runqueue/schedule
  handoff/spin-loop/timeout-expiry sequencing, `wake_timers_loop()` timer
  tick/decrement/detach/log/wakeup sequencing, and `set_timer()` runqueue scan
  plus LAPIC enable/disable decision sequencing.

Previous strict-core movement for the x86 user-copy/process-VM batch:

- Broad dashboard movement is 0 points because the x86_64 memory management
  row is already capped at 100%.
- Strict-core movement is about +1 point: x86_64 memory management strict
  ownership moves 99% -> 100% because Rust now owns `verify_process_vm()`,
  `read_process_vm()`, `write_process_vm()`, `patch_process_vm()`,
  `copy_from_user()`, `copy_to_user()`, `strlen_user()`,
  `strcpy_from_user()`, `getlong_user()`, `getint_user()`,
  `setlong_user()`, and `setint_user()` sequencing behind the existing C ABI.
- C still owns current-thread lookup, page-fault primitive behavior, virtual-
  to-physical primitive behavior, map/unmap and phys-to-virt primitive bodies,
  logging callbacks, bridge glue, and fallback scaffolding.
- Validation passed the expanded x86 memory equivalence suite with
  `x86_memory_helpers ok digest=bc79db2659ab2c2a`, Rust-enabled image/module
  build, C-fallback image build, `git diff --check`, script syntax checks,
  ownership report plus dashboard consistency gate, and QEMU version/help/
  dry-run checks. No real QEMU guest boot or reboot-capable validation ran.

Previous strict-core movement for the host SCD dispatcher batch:

- Broad dashboard movement is 0 points because the host/IKC/mcctrl/IHK row is
  already capped at 100%.
- Strict-core movement is about +3 points: host/IKC/mcctrl/IHK kernel paths
  strict ownership moves 86% -> 89% because Rust now owns
  `syscall_packet_handler()` SCD message-family classification, callback
  dispatch, legacy return shaping, sysfs show/store/release argument
  extraction, unknown-message logging dispatch, and final packet release
  sequencing.
- C still owns the ABI wrapper, bridge callbacks, raw IKC send effects,
  primitive lookup/wakeup/register/debug behaviors, allocation/copy/map
  primitive bodies, broad IKC exchange mutation, and fallback scaffolding.
- Validation passed the expanded host helper equivalence suite with
  `object_helpers ok digest=46b2b56d8ab49745`, Rust-enabled image/module
  build, C-fallback image build, `git diff --check`, script syntax checks,
  ownership report plus dashboard consistency gate, and QEMU version/help/
  dry-run checks. No real QEMU guest boot or reboot-capable validation ran.

Previous strict-core movement for the itimer batch:

- Broad dashboard movement is 0 points because Syscall Core and
  Scheduler/timers/wait/futex are already capped at 100%.
- Strict-core movement is about +4 points: Syscall core strict ownership moves
  85% -> 87% and Scheduler/timers/wait/futex strict ownership moves 95% -> 97%
  because Rust now owns local `setitimer()` and `getitimer()` validation,
  ITIMER_REAL forwarding dispatch, virtual/prof old-value snapshot and copyout,
  new-value copyin, elapsed reset, enabled-state publication,
  `set_timer(0)` callback dispatch, null-old handling, and return/error
  shaping.
- C still owns syscall ABI wrappers, raw argument extraction, actual
  `copy_from_user()`/`copy_to_user()` primitive bodies, `do_syscall()`
  forwarding primitive behavior, actual `set_timer()` behavior, timer queues,
  wake/context-switch primitives, spinlocks, broader futex wait/requeue side
  effects, and fallback scaffolding.
- Validation passed the expanded syscall-policy equivalence suite with
  `syscall_policy_helpers ok digest=b445838b397f5e5c`, Rust-enabled
  image/module build, C-fallback image build, `git diff --check`, syntax
  checks over the validation scripts, ownership report plus dashboard
  consistency gate, and QEMU
  version/help/dry-run checks. No real QEMU guest boot or reboot-capable
  validation ran.

Previous strict-core movement for the scheduler affinity batch:

- Broad dashboard movement is 0 points because Syscall Core and
  Scheduler/timers/wait/futex are already capped at 100%.
- Strict-core movement is about +4 points: Syscall core strict ownership moves
  84% -> 85% and Scheduler/timers/wait/futex strict ownership moves 92% -> 95%
  because Rust now owns `sched_setaffinity()` and `sched_getaffinity()`
  validation, target selection, remote lookup/unlock ordering, permission
  gates, cpuset copyin/copyout, target-process mask intersection, thread
  affinity publication, migration callback dispatch, and return/error shaping.
- C still owns syscall ABI wrappers, raw argument extraction, actual
  `copy_from_user()`/`copy_to_user()` primitive bodies, thread
  lookup/hold/release primitive bodies, migration request side effects, and
  fallback scaffolding.
- Validation passed the expanded scheduler equivalence suite with
  `sched_helpers ok digest=91c80d48274899e5`, Rust-enabled image/module build,
  C-fallback image build, `git diff --check`, ownership report, and QEMU
  version/help/dry-run checks. No real QEMU guest boot or reboot-capable
  validation ran.

Latest strict-core movement for the rusage/CPU-time syscall batch:

- Broad dashboard movement is 0 points because Syscall Core is already capped
  at 100%.
- Strict-core movement is about +4 points: Syscall core strict ownership moves
  78% -> 82% because Rust now owns `getrusage()` validation/dispatch,
  SELF/CHILDREN/THREAD aggregation/fill/copyout sequencing, remote thread
  times-update request/interrupt sequencing, pause-callback wait loops, and
  `clock_gettime()` local/forward/thread/process CPU-time sequencing.
- C still owns syscall ABI wrappers, raw argument extraction, the actual
  `copy_to_user()` primitive, lock primitive bodies, CPU interrupt primitive
  behavior, TOD/gettime and Linux-forward callback bodies, scheduler/time
  primitive bodies, and fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `syscall_policy_helpers ok digest=67811b22d625a0cf`, Rust-enabled
  image/module builds, C-fallback image build, build-only wrapper validation,
  no-warning scans over the captured build logs, `git diff --check`, ownership
  report gates, and QEMU version/help/dry-run checks. No real QEMU guest boot
  ran.

Latest strict-core movement for the Process/VM lifecycle release batch:

- Broad dashboard movement is 0 points because Process/VM management is already
  capped at 100%.
- Strict-core movement is about +6 points: Process/VM management strict
  ownership moves 82% -> 88% because Rust now owns sigcommon release-body
  sequencing, TID release/replace body sequencing, `release_thread()`
  ref/profile/procfs/destroy/VM-release sequencing, and
  `release_process_vm()` ref/mckfd/free-callback/TLB/free-ranges/detach/
  policy-drain/final-free sequencing.
- C still owns atomic refcount primitives, spinlock primitives, actual
  allocator/free callbacks, destroy_thread and release_process bodies,
  profile/procfs/TLB/range-free primitive bodies, page-fault behavior, signal
  forwarding, rusage, broad process lifetime, and fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `process_helpers ok digest=b1b68056ccefbaac`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, ownership report gates, and QEMU
  version/help/dry-run checks. No real QEMU guest boot ran.

Latest strict-core movement for the x86 clear-range body batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +1 point: x86_64 memory management strict
  ownership moves 98% -> 99% because Rust now owns clear-range leaf/level/root
  body sequencing: leaf null-skip and PTE clear-exchange sequencing, TLB
  flush-address queue callback sequencing, old-entry action callback handoff,
  old-effect callback orchestration, split-error log/return shaping, large-page
  clear sequencing, child table translation, child-walk dispatch/error
  propagation, `-ENOENT` child-table teardown/free sequencing, root
  skip/translation/dispatch, and level-specific debug logging.
- C still owns the public ABI wrappers, old-entry page lookup/refcount primitive
  behavior, actual allocation/free and address-translation primitive bodies,
  page/RSS primitive bodies, remote TLB shootdown primitive behavior, and
  fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=67f14d5e0baf12ee`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, and QEMU version/help/dry-run checks. No
  real QEMU guest boot ran.

Latest strict-core movement for the x86 visitor-body batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +2 points: x86_64 memory management strict
  ownership moves 96% -> 98% because Rust now owns normal and safe
  `visit_pte_range()` visitor body sequencing: leaf skip/direct visitor
  callback dispatch, level direct/E2BIG retry classification, split-error
  log/return shaping, child page-table allocation/publication, existing
  child-table translation, child-walk callback dispatch, root allocation/
  translation dispatch, and top-level normal/safe visit-range walk dispatch.
- C still owns the public ABI wrappers, actual allocation/free and
  address-translation primitive bodies, page-table walk iteration callbacks,
  broader page frees/RSS accounting, TLB primitive behavior, and fallback
  scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=c701677a3fd62a6f`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, and QEMU version/help/dry-run checks. No
  real QEMU guest boot ran.

Latest strict-core movement for the x86 range-top batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +3 points: x86_64 memory management strict
  ownership moves 93% -> 96% because Rust now owns clear/set range top-level
  orchestration: clear-range bounds validation, TLB invalid-address array
  allocation/free callback sequencing, clear-range argument field publication,
  clear-range top-level `walk_pte_l4` dispatch, final remote TLB flush
  callback dispatch, set-range argument publication, set-range diff/attribute/
  pgshift/range state publication, set-range top-level `walk_pte_l4` dispatch,
  and set-range top-level walk-failure log/return shaping.
- At that checkpoint, C still owned the public ABI wrappers, actual
  allocation/free and TLB flush primitive bodies, page-table visitor
  callbacks, lower-level walk callbacks, address-translation primitive bodies,
  and fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=f60c57b101779395`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, and QEMU version/help/dry-run checks.
  Two initial validation failures were recorded in `kernel.log` and fixed
  before the clean validation pass. No real QEMU guest boot ran because no
  usable Rocky/RHEL-family qcow2 image was available from unprivileged paths.

Latest strict-core movement for the x86 set-range level-body batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +3 points: x86_64 memory management strict
  ownership moves 90% -> 93% because Rust now owns `set_range_l1/l2/l3/l4`
  leaf and level body orchestration: action dispatch, zeroed child page-table
  allocation, atomic page-table publication retry, existing child-table
  translation, child-walk callback dispatch, large-page map/store/RSS routing,
  child-walk failure shaping, and unconsumed child-table free sequencing.
- C still owns the public ABI wrappers, actual allocation/free and
  address-translation primitive bodies, child page-table walk callbacks, RSS
  primitive body, top-level `walk_pte_l4()` dispatch, and fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=a354b06dbddad942`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, and QEMU version/help/dry-run checks. No
  real QEMU guest boot ran because no usable Rocky/RHEL-family qcow2 image was
  available from unprivileged paths.

Latest strict-core movement for the x86 set-range side-effect batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +3 points: x86_64 memory management strict
  ownership moves 87% -> 90% because Rust now owns set-range existing-mapping
  conflict cleanup, page-table allocation-failure cleanup, L1/L2/L3
  map/store/RSS-accounting callback ordering, L2/L3 large-page success
  logging, and child-walk failure logging.
- C still owns actual `clear_range()` primitive effects, page-table
  allocation/publication, `virt_to_phys()`/`phys_to_virt()`, child page-table
  walk callbacks, RSS primitive body, leftover page-table free behavior, and
  fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=fd4909d0a758b83b`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation, no-warning
  scans over the captured build logs, and QEMU version/help/dry-run checks. The
  first equivalence attempt failed at the SIMD guard, was recorded in
  `kernel.log`, fixed by passing scalar values through ignored callback slots,
  checked with `objdump`, and rerun successfully. No real QEMU guest boot ran
  because no usable Rocky/RHEL-family qcow2 image was available from
  unprivileged paths.

Latest strict-core movement for the x86 clear-range side-effect batch:

- Broad dashboard movement is 0 points because x86_64 memory management is
  already capped at 100%.
- Strict-core movement is about +3 points: x86_64 memory management strict
  ownership moves 84% -> 87% because Rust now owns clear-range TLB
  flush-address queue mutation, old-PTE memobj-flush callback dispatch,
  anonymous-page free/RSS-sub callback ordering, file-backed page-unmap/free/
  rusage-sub callback ordering, XPMEM keep classification/log routing, and
  full-span L2/L3 child page-table PTE-null/free sequencing.
- C still owns actual `remote_flush_tlb_array_cpumask()`, `phys_to_virt()`,
  `ihk_mc_free_pages_user()`, `page_unmap()`, RSS primitive bodies,
  page-table walking callbacks, allocation/free primitive behavior, and
  fallback scaffolding.
- Validation passed the expanded equivalence suite with
  `x86_memory_helpers ok digest=05ab1d79d7050a92`, Rust-enabled image/module
  builds, C-fallback image build, build-only wrapper validation,
  `git diff --check`, script syntax checks, ownership-report dashboard gates,
  no-warning scans over the captured build logs, and QEMU dry-run command
  construction. No real QEMU guest boot ran because no usable Rocky/RHEL-family
  qcow2 guest image was available from unprivileged paths.

Latest strict-core movement for the revised +35 continuation:

- Broad dashboard movement is +35 verified points and the revised continuation
  target is complete.
- Strict-core movement is about +33 points because the latest bodies moved real
  page-hash, futex-table, futex-bucket, page-allocator init, allocator
  allocation-orchestration, allocator free-orchestration, futex dispatch, and
  Process/VM range-object initialization, mapping-action selection, and
  add-range orchestration into Rust rather than adding helper-only trampolines.
- Remaining work for this continuation is 0 broad dashboard points.

Latest strict-core movement for the completed prior +50 continuation:

- Broad dashboard movement is +50 verified points, so that prior +50
  continuation target is complete.
- Strict-core movement is about +53 points because Rust now owns
  `vm_range_insert()` traversal and mutation: range-tree descent, overlap
  rejection, success/overlap callback sequencing, `rb_link_node()`
  publication, and `rb_insert_color()` balancing. Rust also owns the direct
  process/thread ID leaf bodies for `getpid`, `getppid`, `gettid`,
  `set_tid_address`, `getuid`, `geteuid`, `getgid`, and `getegid`, including
  field reads and `clear_child_tid` publication. Rust also owns futex wake
  target orchestration, including mark-woken sequencing, Linux-vs-McKernel
  target selection, IKC packet fill, send callback sequencing, scheduler wake
  callback sequencing, and wake logging. Rust also owns `getresuid()` and
  `getresgid()` ordered field-read plus user-copy callback sequencing. Rust
  also owns page-allocator free post-action completion:
  direct-free success/error logging selection, deferred-free error/skip/send
  action handling, Linux zero-request send callback sequencing, and send
  success/failure logging. Rust also owns exported `ihk_numa_free_pages()`
  top-level body sequencing: CPU-cache free attempt classification, cache
  success/error log selection, direct-versus-deferred free dispatch, Linux
  zero-request send callback sequencing, final log selection, and return
  shaping. Rust also owns exported `ihk_numa_alloc_pages()` top-level
  allocation body sequencing: cache-hit logging selection, direct-allocation
  logging selection, source-aware return shaping, and exported allocation
  handoff around cache-first/source-selection/fallback-to-NUMA orchestration.
  Rust also owns exported `ihk_numa_add_free_pages()` and public
  `ihk_numa_zero_free_pages()` top-level sequencing: add-free success/error log
  selection, return shaping around the NUMA add-free mutation body, and public
  zero-free dispatch into the Rust-owned zero-list publication path.
  Rust also owns pager/memory-control ABI layout coverage for pager create/map
  results, memory area/node/page-allocator ops/TLB-flush/page-cache headers,
  plus CPU-local/rusage-percpu/kmalloc/backlog/SMP-call layout coverage. Rust
  also owns CPU-local storage initialization sequencing,
  `get_cpu_local_var()` pointer selection, normal preempt counter inc/dec,
  Rust-owned base-10 decimal digit emission for the `vsnprintf()` numeric path,
  and Rust-owned `skip_atoi()` format width/precision pointer advancement.
  Rust also owns kmalloc chunk header initialization, sorted free-list
  insertion, and adjacent free-chunk consolidation.
  Rust also owns x86 page-table root lifecycle:
  `ihk_mc_pt_create()` allocation-callback orchestration, root zeroing,
  kernel-half entry copy from `init_pt`, and `ihk_mc_pt_destroy()` root
  kernel-half clearing plus destroy-recursion callback dispatch. Rust also owns
  `ihk_mc_pt_prepare_map()` initial page-table selection, L4 range traversal,
  present-entry short-circuiting, allocation callback sequencing, L4 entry
  publication, last-level set-page callback loop sequencing, and first error
  return propagation. Rust also owns `ihk_mc_pt_set_pte()` page-size/value
  selection callback orchestration, alignment error classification,
  log-callback selection, panic-callback dispatch for invalid page sizes, PTE
  store invocation, and final return shaping. The C side keeps ABI wrappers,
  current-thread lookup, argument extraction, the actual user-copy primitive,
  actual IKC send primitive, logging/dump callbacks,
  actual allocator/free primitives, recursive child-table destruction below the
  root, and fallback implementations.

Latest strict-core movement for the active +50 continuation:

- Broad dashboard movement is +50 verified points, so the active +50
  continuation is complete.
- Strict-core movement is about +60 points because Rust now owns the central
  `number()` formatter body for `vsnprintf()` numeric and pointer paths:
  sign handling, prefix selection, width and precision adjustment, zero/space
  padding, octal/hex/decimal digit staging, bounded output writes, and returned
  pointer advancement. Rust also owns `format_decode()` parsing of literal
  spans, flags, field width, precision, qualifiers, conversion type, base,
  signedness, and width/precision continuation state. C keeps the surrounding
  `vsnprintf()` loop, va_arg extraction, string and pointer extension dispatch,
  `%n` writes, final NUL termination, and output buffer lifetime. Rust also
  owns `string()` `%s` output formatting: NULL-string substitution,
  precision-bounded length selection, left/right padding, bounded output
  writes, and returned pointer advancement.
- ABI/layout foundation strict core also moved 62% -> 66% because Rust/C now
  assert x86 signal action, altstack, `siginfo_t`, `signalfd_siginfo`, ptrace
  `user_regs_struct`, `user_fpregs_struct`, `struct user`, futex
  hash-bucket/key/queue layouts, and the key offsets needed before signal,
  ptrace, and futex body ownership can safely move.
- ABI/layout foundation strict core then moved 66% -> 70% because Rust/C now
  assert syscall/control-plane structures used by syscall setup, procfs,
  coredump, sysinfo/time publication, CPU mapping, perf control, UTI context,
  and move-pages SMP requests before those core bodies move.
- ABI/layout foundation strict core then moved 70% -> 74% because Rust/C now
  assert x86 descriptor, TSS, fxsave/xsave, YMM, LWP, and bound-register
  save-state structures used by ptrace, signal-frame FPU save/restore,
  register access, and context paths.
- ABI/layout foundation strict core then moved 74% -> 78% because Rust/C now
  assert sysfs create, mkdir, symlink, lookup, unlink, and setup request packet
  layouts used by the Rocky control-plane exchange.
- ABI/layout foundation strict core then moved 78% -> 82% because Rust/C now
  assert ELF core headers, program headers, note headers, `elf_siginfo`,
  `prstatus64_timeval`, `elf_prstatus64`, `elf_prpsinfo64`, and `iovec`
  layouts used by coredump and user-vector paths.
- ABI/layout foundation strict core then moved 82% -> 87% because Rust/C now
  assert the x86 CPU-local page, x86 kernel context, TLS `user_desc`, sysfs
  operation callbacks/handle/bitmap parameters, `itimerval`, and
  `profile_event` layouts used by CPU-local, sysfs, profiling, timer, and TLS
  paths.
- ABI/layout foundation strict core then moved 87% -> 100% because Rust/C now
  asserts low-level `ihk_rwlock`, `kref`, rbtree augmentation callbacks,
  ftrace branch-data records, `memobj_ops`, `memobj`, SysV shm limit/info and
  lock-user state, and the XPMEM ID/hash/thread-group/segment/access-permit/
  partition/permission/attachment object graph. This closes the known
  x86_64/Rocky layout prerequisite row, but XPMEM attach/detach, SysV shm
  lifetime, memobj refcounting, page I/O, ftrace accounting, rbtree mutation,
  locking primitives, allocation/free, user-copy, and object lifecycle side
  effects still need Rust runtime ownership.
- host/IKC/mcctrl/IHK kernel paths strict core moved 62% -> 63% because Rust
  now owns `ihk_dma_request()` callback dispatch for the IHK host core DMA
  request path: channel/ops validation, request callback presence gate,
  callback invocation, and `-EINVAL` shaping for the no-callback path. C keeps
  the exported ABI wrapper, fallback, and DMA provider callback body.
- Syscall core strict ownership moved 63% -> 66% because Rust now owns
  `sigaltstack()` body sequencing: optional old-stack copyout, optional
  new-stack copyin, validation, disabled-stack normalization, and thread
  `sigstack` publication. C keeps the syscall ABI wrapper, current-thread
  lookup, actual user-copy primitive callbacks, and fallback implementation.
- procfs/sysfs/xpmem/file object strict ownership moved 60% -> 64% because
  Rust now owns sysfs show/store/release response-body sequencing: default
  ssize/error shaping, optional callback dispatch, response packet msg/err/arg
  publication, send callback dispatch, and output publication. C keeps callback
  bodies, the actual `ihk_ikc_send()` primitive, logging, global buffer
  lifetime, packet-handler dispatch, allocation/free, sysfs path formatting,
  busy waits, host-side object creation, user-copy, and fallback
  implementation.
- procfs/sysfs/xpmem/file object strict ownership moved 64% -> 67% because
  Rust now owns sysfs packet dispatch for show/store/release requests:
  request-kind classification, typed callback selection, show/store/release
  callback dispatch, store-size publication from the incoming packet error
  field, and unknown-message classification. C keeps the public IKC handler
  wrapper, unknown-message logging, callback bodies, raw IKC send behavior,
  global buffer lifetime, allocation/free, sysfs path formatting, busy waits,
  host-side object creation, user-copy, and fallback implementation.
- Post-+50 strict-core movement added Syscall core 66% -> 67% because Rust now
  owns `waitid()` SIGCHLD siginfo copyout-body sequencing: eligibility,
  zeroed `siginfo_t` preparation, `si_signo`/`si_code` and child PID/status
  population, timeval-to-jiffy conversion for child utime/stime, and copyout
  callback dispatch. C keeps the syscall ABI wrapper, `do_wait()` scanning and
  sleep behavior, wait locks, status/rusage production, the actual
  `copy_to_user()` primitive, scheduler behavior, and fallback implementation.
- Post-+50 strict-core movement then added Syscall core 67% -> 69% because Rust
  now owns `wait4()` wrapper sequencing: option validation, zeroed
  `struct rusage` preparation, `do_wait()` callback invocation with `WEXITED`,
  status copyout gating, rusage copyout gating, copyout callback dispatch, and
  final return shaping. C keeps the syscall ABI wrapper, raw argument
  extraction, `do_wait()` scanning and sleep behavior, wait locks, the actual
  `copy_to_user()` primitive, scheduler behavior, and fallback implementation.
- Post-+50 strict-core movement then added Syscall core 69% -> 71% because Rust
  now owns `waitid()` wrapper sequencing: idtype-to-wait-pid validation,
  option validation, zeroed `struct rusage` preparation, `do_wait()` callback
  invocation, negative wait-result propagation, siginfo copyout dispatch, and
  final waitid return shaping. C keeps the syscall ABI wrapper, raw argument
  extraction, `do_wait()` scanning and sleep behavior, wait locks, the actual
  `copy_to_user()` primitive, scheduler behavior, and fallback implementation.
- Post-+50 strict-core movement then added Syscall core 71% -> 72% because Rust
  now owns `wait_continued()` body sequencing: continued-status publication,
  main-thread versus report-thread signal-flag reap target selection,
  continued-signal reap callback dispatch, WNOWAIT preservation through the
  existing reap helper, and process-pid versus thread-tid return selection. C
  keeps the wait list scans, wait locks, caller-side duplicate reap behavior,
  scheduler behavior, and fallback implementation.

Primary remaining C blockers for "core C replaced with Rust core":

- Page-table allocation/free primitives, broader visitor/mutation traversal
  orchestration, broader page frees/RSS accounting, remote TLB shootdown
  primitive behavior, and map/free rollback.
- Page allocator lifetime, remaining CPU-local allocator-cache ownership, allocation/free-to-
  system primitives, deferred-zero publication, and IKC-backed zeroing effects.
- Process and VM lifetime: VM range allocation/free, memobj refcounting,
  range-tree erase/removal, page-fault orchestration, child-list mutation, rusage
  aggregation, wait orchestration, signal forwarding, and release paths.
- Syscall entry/dispatch, user-copy boundaries, Linux forwarding, remaining
  high-risk handlers, and architecture register/fp/regset operations.
- Scheduler/timer/futex bodies: timer queues, wakeups, IPIs, context switching,
  futex allocation primitive callbacks, futex dispatch side-effect callback
  bodies, futex key lifetime, user-value loads, futex wait/wake/requeue side
  effects, and race retry behavior.
- Kernel-side Rocky control plane: IKC exchange mutation, callback invocation,
  waits, object allocation/free, device lifecycle, memory registration, file
  I/O, and kernel object lifecycle.

Strict tracker update rule:

- Update `overview.txt` for broad functional dashboard movement.
- Update `migration.txt` and this AGENTS section only when Rust owns more of a
  primary core body, not merely another helper called by C.
- Record C additions as glue/fallback only; do not count new C decision logic
  as Rust progress.

## Distance To 100

| Area | Current | Points To 100 |
| --- | ---: | ---: |
| Rust build/link foundation | 95 | 5 |
| ABI/layout foundation | 100 | 0 |
| Shared primitives | 100 | 0 |
| x86_64 memory management | 100 | 0 |
| Page allocator | 100 | 0 |
| Process/VM management | 100 | 0 |
| Syscall core | 100 | 0 |
| Scheduler/timers/wait/futex | 100 | 0 |
| procfs/sysfs/xpmem/file objects | 100 | 0 for helper/decision surface; mutation bodies still C |
| host/IKC/mcctrl/IHK modules | 100 | 0 |
| User tools | 83 | 17 |
| Rocky runtime integration | 82 | 18 |
| arm64 | deferred | not counted until x86_64/Rocky stabilizes |

## Latest Validated Direction

Recent completed work moved private ABI/layout and lifecycle decision helpers
into Rust. Continue from the McKernel-owned parts first:

- Process/thread lifetime layout mirrors, wait/futex support structs, IHK
  monitor/rusage/register/resource descriptors, and private host Linux
  device/OS/file object assertions compile into the relevant targets.
- Address-space release, clone VM/sighand branch decisions, initial CPU-set
  fallback, mckfd duplicate/close decisions, process/thread refcount cleanup
  gates, TID scan/index decisions, TID slot release/replace writes,
  sigpending list pop/unlink, mckfd pop-head mutation, process/thread list
  add/detach helpers, optional ptrace/fp cleanup gates, and TID-release policy
  predicates route through Rust helpers.
- Scheduler runqueue/migration list detach/add-tail primitives and paired
  runqueue length updates route through Rust helpers; C still owns locks,
  target selection, status flags, wakeups, IPIs, timers, and context switching.
- Syscall-side wait, ptrace detach/attach, clone-report, process termination,
  and signal-wait list detach/add/move primitives route through Rust helpers;
  C still owns the syscall policy, locks, reparenting decisions, signal
  delivery, wait status, user-copy, and Linux forwarding.
- Pending-signal deliverability and offloaded-syscall interrupt/terminate
  classification route through Rust helpers; C still owns traversal, lock
  mode, interrupted-flag writes, signal delivery, and termination calls.
- Ptrace wakeup request shape, resume signal source selection, event-message
  eligibility, and siginfo storage target classification route through Rust
  helpers; C still owns ptrace state writes, register and memory access,
  user-copy, allocation/free, signal delivery, and wakeups.
- Ptrace request-to-handler dispatch classification routes through Rust helpers
  for the direct McKernel ptrace cases; C still owns the handler bodies,
  register/user-memory access, user-copy, state mutation, wakeups, and
  architecture fallback execution.
- Wait/reap stopped-source selection, wait status/result ID shaping, signal flag
  clear masks, reparent/detach/release action selection, and wait4/waitid copy
  gates route through Rust helpers; C still owns locks, child-list mutation,
  rusage aggregation, ptrace detach bodies, user-copy, and Linux forwarding.
- Getrusage dispatch/update decisions, maxrss scaling, process-exit code
  decoding, SIGCHLD code selection, ptrace-vs-termsig signal selection, and
  exit-group status encoding route through Rust helpers; C still owns time
  aggregation, IPIs, signal delivery, locking, atomic status claims, and
  user-copy.
- Terminate cleanup active-thread tests, group-exit status shaping,
  report-thread release gates, and child free/reparent action classification
  route through Rust helpers; C still owns the locks, list mutation, child
  release, ptrace detach, memory cleanup, signal delivery, and scheduling.
- Terminate child cleanup now uses Rust-owned list delete-init and child
  reparent mutation helpers while C holds the existing locks and still owns
  release decisions, ptrace detach, signal delivery, and memory teardown.
- Clone spawn/TID/TLS/reparent result shaping now routes through Rust helpers:
  parent/child TID store gates, child clear-TID gates, TLS source selection,
  last-CPU placement gate, remote-spawn detection, and `CLONE_PARENT` fallback
  to pid1. C still owns the writes, allocation, locking, Linux forwarding,
  CPU assignment, process chaining, user-copy, and scheduler handoff.
- Thread report-list attach mutation for clone report-thread setup,
  `ptrace_traceme()`, and `ptrace_attach_thread()` now routes through a
  Rust-owned offset-based helper while C holds the existing locks and still
  owns `hold_thread()`, release calls, ptrace state writes, signal delivery,
  allocation/free, user-copy, Linux forwarding, CPU placement, and scheduling.
- Thread report-list detach/retarget mutation and main-thread ptrace-detach
  reparenting now route through Rust helpers while C keeps the same locks and
  still owns ptrace state reset, debug-register free, signal forwarding,
  zombie reporting, release calls, user-copy, Linux forwarding, and scheduling.
- Terminate/wait report-thread release cleanup now uses Rust helpers for
  report-list detach/clear and release-time `termsig` clearing while C still
  owns release decisions, `release_thread()`, ptrace detach bodies, locks,
  signal delivery, allocation/free, user-copy, Linux forwarding, and scheduling.
- Ptrace detach state cleanup now clears ptrace flags, saved-context-valid
  state, and the debug-register pointer in Rust, returning the old debugreg
  pointer for C to free. C still owns `kfree()`, single-step clearing, signal
  forwarding, release calls, user-copy, Linux forwarding, and scheduling.
- Wait stopped/continued signal-flag reap mutation now routes through Rust
  helpers for process and report-thread wait paths while C still owns wait
  selection, status construction, locking, rusage, user-copy, and sleep/wake.
- Wait stopped exit-status reap mutation now routes through Rust helpers for
  thread exit status, process group-exit status, and main-thread exit status
  while preserving WNOWAIT. C still owns wait-source selection, status copy,
  rusage, user-copy, locks, and waitqueue behavior.
- Ptrace wakeup saved-context clear and syscall-trace flag mutation now route
  through Rust helpers while C still owns request action selection, locks,
  single-step setup, signal construction/delivery, wakeups, and user-copy.
- Ptrace resume pending-signal take/clear now routes through Rust helpers for
  sendsig/recvsig pointers while C still copies `siginfo`, frees the pending
  object, sends the signal, and owns wakeup/user-copy behavior.
- Ptrace detach signal-forward and exit-report gates now route through Rust
  syscall policy helpers; C still owns siginfo construction, signal delivery,
  thread-exit reporting, wakeups, user-copy, and Linux forwarding.
- Ptrace attach main-thread reparent/list-add mutation now routes through Rust
  helpers while C preserves the existing parent/proc children-lock split,
  debug-register allocation, hold-thread, single-step, signal, and scheduling
  ownership.
- The latest +30 McKernel-owned lift routes five more bounded surfaces through
  Rust helpers: timer spin/runqueue/remaining-time arithmetic plus futex key
  matching, x86 PTE value shaping and page-size PTE validation/value
  selection, page-allocator init layout and tail-map reservation, address-space
  PID detach plus mckfd push-head mutation, and syscall credential-refresh
  forwarding gates. C still owns locks, allocation/free, user-copy, signal
  delivery, page-table walking/mutation, timer queues, futex wake queues,
  rusage aggregation, and scheduler/context-switch side effects.
- The latest +60 McKernel-owned lift routes eight more bounded surfaces through
  Rust helpers: waitqueue entry initialization and wake scheduling predicates,
  x86 early allocator alignment/exhaustion/next-pointer arithmetic,
  page-allocator init end/count and destroy-page count helpers, fork-time
  process VM/thread metadata copy, getpid/getppid/gettid/set_tid_address return
  shaping, procfs cmdline/comm helpers, and timer ABI layout assertions. C
  still owns locks, allocation/free, user-copy, signal delivery, page-table
  walking/mutation, timer queues, futex wake queues, rusage aggregation,
  scheduler/context-switch side effects, and procfs/sysfs buffer or IKC
  mutation.
- The latest +34 verified slice toward the requested +135 campaign routes
  futex key preparation, syscall-offload scheduling decisions, x86 page-table
  index and walk-bound arithmetic, split-large-page preparation/entry
  arithmetic, syscall requester/preempt gates, `mprotect` split/write-change
  decisions, VM range-cache/lookup relation decisions, page-allocator Linux
  zero-request action selection, and `timeval`/`rusage` ABI assertions through
  Rust helpers. C still owns locks, allocation/free, user-copy, Linux
  forwarding, page-table map/unmap mutation, signal delivery, wakeups, timer
  queues, futex queues, scheduler handoff, and broad lifetime mutation.
- The follow-up +10 verified slice toward the requested +135 campaign routes
  futex wake/requeue decision policy, x86 page-clear alignment and target
  selection, and process VM remove-range split/free preflight through Rust
  helpers. C still owns futex queue/list mutation and wakeups, page-table
  writes, range allocation/free, XPMEM removal side effects, locks, user-copy,
  Linux forwarding, and runtime orchestration.
- The latest +5 verified x86 slice toward the requested +135 campaign routes
  page-table visit/direct-walk action selection, clear/free-range validation,
  free-physical gating, and clear-range large-entry action selection through
  Rust helpers. C still owns page-table allocation and traversal side effects,
  `xchg()`/PTE writes, TLB flushes, page frees, RSS/rusage updates, memobj
  flushes, and user-copy.
- The latest +4 verified syscall slice toward the requested +135 campaign routes
  getrusage TSC-to-timespec accumulation and `struct rusage` timeval/maxrss
  result shaping through Rust helpers. C still owns thread-list traversal,
  times-update orchestration, CPU interrupts, locks, user-copy, and actual
  rusage aggregation/lifetime state.
- The latest +3 verified page-allocator slice toward the requested +135
  campaign routes CPU-local cache try/hit/free-success action classification
  through Rust helpers. C still owns interrupt masking, CPU-local rb-tree
  mutation, logging, allocator lifetime, and fallback-to-NUMA free behavior.
- The latest +4 verified x86 slice toward the requested +135 campaign routes
  page-table change-attribute leaf, large-entry, split-error, and walk action
  selection through Rust helpers. C still owns the PTE writes, lower-level page
  table walks, error logging, TLB-sensitive behavior, and user-copy.
- The latest +4 verified x86 set-range slice toward the requested +135
  campaign routes leaf apply/busy, direct large-page map, allocate-and-walk,
  busy, and lower-level walk action selection through Rust helpers. C still
  owns page-table allocation, cmpxchg, PTE writes, RSS updates, rollback
  clears, lower-level walks, TLB-sensitive behavior, and user-copy.
- The latest +4 verified x86 lookup slice toward the requested +135 campaign
  routes lookup default page-size choice, L3/L2 hit/walk/miss classification,
  L4-empty size clamping, and base/size/p2align result shaping through Rust
  helpers. C still owns page-table pointer traversal, `phys_to_virt()`, entry
  dereferences, and returned PTE pointer ownership.
- The latest +3 verified IHK slice toward the requested +135 campaign routes
  host core OS load-file dispatch, file-size validity, kernel-read failure
  classification, and read-loop continuation policy through Rust helpers. C
  still owns file I/O, memory allocation/free, load handler calls, state
  lifetime, and error cleanup.
- The latest +3 verified IHK shutdown slice toward the requested +135 campaign
  routes shutdown status-to-action policy through Rust helpers. C still owns
  waits, thaw calls, NMI fallback, notifier traversal, IKC finalization,
  shutdown callbacks, kmsg release, locks, state mutation, and cleanup.
- The latest +4 verified IHK mutation slice toward the requested +135 campaign
  routes host core kmsg buffer initialization and clear field/buffer mutation
  through Rust helpers. C still owns page allocation/free, inter-kernel lock
  acquire/release, IRQ masking, list insertion/deletion, container lifetime,
  and module lifecycle cleanup.
- The latest +3 verified IHK lifecycle mutation slice toward the requested
  +135 campaign routes kmsg container field initialization and OS container
  pointer take/clear mutation through Rust helpers. C still owns atomic
  refcount initialization, list publication/deletion, release calls, frees,
  locks, and module lifecycle cleanup.
- The latest +4 verified IHK list-publication slice toward the requested +135
  campaign routes locked `list_add_tail` publication for kmsg buffers, event
  registrations, aux-call handlers, and OS notifiers through Rust helpers. C
  still owns list traversal, list deletion, locks, refcounts, callback
  execution, object lifetime, and frees.
- The latest +4 verified IHK list-deletion slice toward the requested +135
  campaign routes locked `list_del` mutation for kmsg buffers, event cleanup,
  aux-call unregister, and OS notifier deregistration through Rust helpers. C
  still owns traversal, locks, refcounts, callback execution, object lifetime,
  and frees.
- The latest +3 verified IHK kmsg traversal slice toward the requested +135
  campaign routes reverse kmsg-buffer lookup traversal by OS index through Rust
  helpers for OS boot and device kmsg lookup. C still owns the locks, refcount
  increments, returned-pointer assignment, user-copy, error handling, and object
  lifetime.
- The latest +3 verified IHK list-membership traversal slice toward the
  requested +135 campaign routes generic forward list membership traversal
  through Rust helpers for OS notifier registration and deregistration. C still
  owns semaphore locking, callback invocation traversal, list add/delete,
  refcounts, object lifetime, and module lifecycle side effects.
- The latest +3 verified IHK next-entry traversal slice toward the requested
  +135 campaign routes generic forward cursor traversal through Rust helpers
  for OS notifier boot/shutdown callbacks, eventfd signaling traversal, and
  aux-call handler-list traversal. C still owns callback invocation, eventfd
  signaling, semaphore/spinlock coverage, handler dispatch, refcounts, user-copy,
  object lifetime, and module lifecycle side effects.
- The latest +4 verified IHK kmsg refcount slice toward the requested +135
  campaign routes kmsg container atomic count set/read/inc/dec/dec-return
  through Rust helpers with C fallbacks. At that point C still owned OS/device
  open refcount `cmpxchg`; the later post-campaign open-refcount slice moved
  that boundary. C still owns callback invocation, locks, container
  allocation/free, page allocation/free, device allocation, memory
  registration, IKC exchange, file I/O, user-copy, and broad lifetime.
- The latest +4 verified ABI/layout slice toward the requested +135 campaign
  adds Rust compile-time layout mirrors for IHK kmsg buffers, kmsg buffer
  containers, event entries, notifier ops/entries, aux-call handler entries,
  and aux-call lists. These assertions compile into the IHK helper object; C
  still owns object allocation/free, callbacks, user-copy, IKC exchange, and
  runtime lifecycle.
- The latest +3 verified page-allocator slice toward the requested +135
  campaign routes the NUMA zeroing-worker atomic increment through Rust helpers
  with equivalence coverage. C still owns the decision to request Linux zeroing,
  IKC packet construction/send, locks, interrupt masking, allocator lifetime,
  and broad zeroing side effects.
- The latest +3 verified scheduler/futex slice toward the requested +135
  campaign routes the futex wake-list detach, compiler barrier, and
  `lock_ptr` clear through Rust helpers with C fallbacks and equivalence
  coverage. C still owns the hash-bucket locks, wake policy, IKC packet
  construction/send, thread wakeup, timeout/requeue orchestration, scheduler
  handoff, and broader futex queue/list mutation.
- The latest +3 verified scheduler/futex requeue slice toward the requested
  +135 campaign routes the futex cross-bucket requeue list move and
  `lock_ptr` publication through Rust helpers with C fallbacks and equivalence
  coverage. C still owns the hash-bucket locks, key reference/lifetime updates,
  `q->key` replacement, wake policy, timeout/requeue loop orchestration,
  scheduler handoff, and broader futex queue/list mutation.
- The latest +3 verified scheduler/futex queue-metadata slice toward the
  requested +135 campaign routes queue-time futex waiter metadata publication
  through Rust helpers with C fallbacks and equivalence coverage. C still owns
  current-thread lookup, address translation, interrupt lookup, queue insertion,
  hash-bucket lock coverage, timeout/wake orchestration, and broader futex
  queue/list mutation.
- The latest +3 verified scheduler/futex unqueue slice toward the requested
  +135 campaign routes self-unqueue priority-list detach through Rust helpers
  with C fallbacks and equivalence coverage. C still owns lock-pointer reads,
  compiler barrier, race retry, hash-bucket lock/unlock, key reference dropping,
  return orchestration, and sleep/wake behavior.
- The latest +3 verified x86 memory slice toward the requested +135 campaign
  routes move-PTE file-offset rejection, mapped-destination calculation, and
  exchanged-PTE physical/attribute splitting through Rust helpers with C
  fallbacks and equivalence coverage. C still owns `pte_xchg()`,
  `ihk_mc_pt_set_range()`, page-table mutation, TLB flush behavior, logging,
  and runtime move orchestration.
- The latest +3 verified x86 clear/free-range slice toward the requested +135
  campaign routes old-PTE physical/fileoff/dirty classification plus
  flush/free/XPMEM/try-unmap action selection through Rust helpers with C
  fallbacks and equivalence coverage. C still owns `xchg()`, `phys_to_page()`,
  `memobj_flush_page()`, `page_unmap()`, actual frees, RSS updates, remote TLB
  flushes, logging, and page-table lifetime.
- The latest +3 verified x86 set-range slice toward the requested +135
  campaign routes mapped physical-address and final PTE value shaping for
  4 KiB, 2 MiB, and 1 GiB mappings through Rust helpers with C fallbacks and
  equivalence coverage. C still owns page-table allocation, compare-exchange,
  direct PTE writes, rollback, RSS updates, and runtime map orchestration.
- The latest +5 verified x86 split-large-page slice completes the requested
  +135 campaign by routing split source classification, child-map physical
  derivation, page-table publish entry shaping, and source-unmap gate selection
  through Rust helpers with C fallbacks and equivalence coverage. C still owns
  allocation, child entry writes, `page_map()`, `page_unmap()`, RSS updates,
  PTE publication, remote TLB flushing, and runtime split orchestration.
- The latest post-campaign +3 page-allocator slice routes NUMA zero-free
  dispatcher policy, explicit-node versus all-node traversal, and null-node
  stop behavior through Rust helpers with C fallbacks and equivalence coverage.
  C still owns caller timing, locks, logging, CPU-local rb-tree mutation,
  interrupt masking, allocator lifetime, IKC packet construction/send, Linux
  zero-request side effects, and broad allocator lifecycle ownership.
- The latest post-campaign +3 page-allocator packet slice routes deferred-zero
  IKC packet clearing and field shaping through Rust helpers with C fallbacks
  and equivalence coverage. C still owns request timing, current-thread lookup,
  channel selection, `ihk_ikc_send()`, logging, zeroing side effects, locks,
  CPU-local rb-tree mutation, interrupt masking, allocator lifetime, and broad
  allocator lifecycle ownership.
- The latest post-campaign +3 page-allocator CPU-cache slice routes CPU-local
  cache rb-tree allocation/free helper entry points through Rust helpers with C
  fallbacks and equivalence coverage. C still owns CPU-local variable
  selection, interrupt masking, logging, try/hit/fallback orchestration,
  allocator lifetime, IKC packet send/channel/current-thread lookup, zeroing
  side effects, locks, and broad allocator lifecycle ownership.
- The latest post-campaign +3 x86 memory slice routes direct PTE stores,
  atomic child page-table publication, PTE clear exchange, and attribute-apply
  mutation through Rust helpers with C fallbacks and equivalence coverage. C
  still owns page-table allocation/free, walk orchestration, `page_map()`,
  `page_unmap()`, actual physical frees, RSS updates, remote TLB
  flushing, logging, user-copy, and broader runtime mapping orchestration.
- The latest post-campaign +3 IHK host-core slice routes OS/device
  exclusive-open refcount compare-exchange mutation through Rust helpers with
  C fallbacks and equivalence coverage. C still owns callback invocation, file
  operation orchestration, device allocation, memory registration, file I/O,
  waits/callbacks, IKC exchange mutation, broad allocation/lifetime ownership,
  and kernel object lifecycle mutation.
- The latest post-campaign +3 scheduler/futex slice routes futex wait-state
  status/spin-sleep mutation and post-wait success/timeout/interrupt/retry
  classification through Rust helpers with C fallbacks and equivalence
  coverage. C still owns hash-bucket locking, queue orchestration,
  `schedule()`/`schedule_timeout()`, signal detection, wakeups, timer queues,
  context switching, key lifetime, race retry, and broader futex queue/list
  mutation.
- The latest post-campaign +3 scheduler/futex wake slice routes futex wake
  target classification, Linux response-channel fallback selection, and
  `SCD_MSG_FUTEX_WAKE` IKC packet field publication through Rust helpers with
  C fallbacks and equivalence coverage. C still owns queued-node detach,
  `ihk_ikc_send()`, `sched_wakeup_thread()`, channel-array access, wakeup side
  effects, IPIs, timer queues, context switching, key lifetime, race retry,
  and broader futex queue/list mutation.
- The latest post-campaign +1 mcctrl deferred-zero slice routes the
  Linux-side deferred-zero worker's lockless `to_zero_list` pop, chunk payload
  clear, `zeroed_list` publish, and zeroing-worker/page-count atomic updates
  through Rust helpers with C fallback and module-helper smoke coverage. This
  is credited as +1 rather than forcing the host/IHK row to 100 because
  memory registration, broader IKC exchange, allocation/lifetime ownership,
  callback/device/file orchestration, and module lifecycle mutation still have
  real C debt.
- The latest post-campaign +3 scheduler/futex queue-insertion slice routes
  futex waiter plist node initialization and hash-bucket queue insertion in
  `queue_me()` through Rust helpers with C fallbacks and equivalence coverage.
  C still owns hash-bucket locking, current-thread lookup, physical-address
  input gathering, timeout/wake orchestration, `schedule()`/
  `schedule_timeout()`, wakeups, IKC sends, key lifetime, and broader futex
  queue orchestration.
- The latest post-campaign +3 scheduler/futex wait-q-init slice routes
  futex wait-queue bitset/requeue/UTI initialization, key-region zeroing before
  `get_futex_key()`, and hash-bucket lock-pointer publication through Rust
  helpers with C fallbacks and direct equivalence coverage. C still owns
  hash-bucket locking, user-value comparison, key reference lifetime,
  timeout/wake orchestration, `schedule()`/`schedule_timeout()`, wakeups,
  IKC sends, address translation, race retry, and broader futex wait
  orchestration.
- The latest post-campaign +3 x86 destroy-page-table slice routes page-table
  teardown entry descend/skip policy and child page-table physical-address
  extraction through Rust helpers with C fallbacks and direct equivalence
  coverage. C still owns destroy recursion, `phys_to_virt()`, page-table
  frees, panic handling, and broader page-table lifetime orchestration.
- The latest post-campaign +3 x86 page-table walk slice routes normal and safe
  L1-L4 walk result folding through Rust helpers with C fallbacks and direct
  equivalence coverage. C still owns callback execution, page-table allocation,
  physical-address validation, traversal, splitting, `phys_to_virt()`, and all
  page-table mutation side effects.
- The latest post-campaign +3 page-allocator zero-request preparation slice
  routes deferred-free Linux zero-request preparation through Rust helpers:
  current/idle/nohost/worker/pid checks, zeroing-worker increment, and packet
  field publication. C still owns CPU-local variable selection, interrupt
  context, IKC channel selection, `ihk_ikc_send()`, logging, and broader
  allocator lifetime/fast-path orchestration.
- The latest post-campaign +3 scheduler/futex wait-scheduling slice reuses the
  Rust-owned bitset validator on the wait side and routes queued/timeout/direct
  schedule action classification in `futex_wait_queue_me()` through Rust
  helpers with C fallbacks and direct equivalence coverage. C still owns the
  `plist_node_empty()` observation, actual `schedule_timeout()`/
  `spin_sleep_or_schedule()` behavior, signal and timeout mechanics, wakeups,
  locks, timer queues, context switching, race retry, key lifetime, and broader
  futex wait orchestration.
- The latest post-campaign +3 syscall getrusage slice routes per-thread
  `times_update` mutation in the `RUSAGE_SELF` scan through Rust helpers with C
  fallbacks and direct equivalence coverage. C still owns thread-list locking,
  traversal, current/status/in-kernel observations, CPU interrupt delivery,
  TSC aggregation, rusage copyout, and user-copy behavior.
- The latest IHK SMP memory-assignment slice routes free-chunk scan decisions,
  no-chunk/all/fake-chunk action selection, and used-chunk insertion ordering
  through Rust helpers with C fallbacks and direct module-helper coverage. C
  still owns free-list traversal, kmalloc/kfree, list mutation, compound-page
  leftover handling, memory registration side effects, locks, copy_from_user,
  rollback release calls, and broad OS-memory assignment orchestration. Do not
  mark host/IHK as 100% until those remaining bodies are covered and moved.
- The latest post-campaign +3 page-allocator descriptor-init slice routes
  descriptor zeroing and descriptor field initialization in
  `__ihk_pagealloc_init()` through Rust helpers with C fallbacks and direct
  page-allocator equivalence coverage. C still owns descriptor allocation,
  `mcs_lock_init()`, exported wrapper lifetimes, lock ownership, CPU-local
  variable selection, interrupt masking, IKC send side effects, and broader
  allocator lifetime/orchestration.
- The latest post-campaign +3 syscall ptrace slice routes `ptrace_setoptions`
  option-state mutation, `ptrace_attach` traced-state publication, and
  `ptrace_geteventmsg` status validation/event-message preparation through
  Rust helpers with C fallbacks and direct syscall-policy equivalence coverage.
  C still owns tracee lookup, locks, `copy_to_user()`, signal delivery,
  register and process-memory access, ptrace handler orchestration,
  allocation/free, and Linux forwarding.
- The latest post-campaign +3 syscall ptrace siginfo slice routes
  `ptrace_getsiginfo` status validation/kernel siginfo buffer preparation and
  `ptrace_setsiginfo` pending-signal pointer publication plus sendsig/recvsig
  siginfo storage through Rust helpers with C fallbacks and direct
  syscall-policy equivalence coverage. C still owns tracee lookup, locks,
  `kmalloc()`, failure lifetime semantics, `copy_to_user()`/
  `copy_from_user()`, signal delivery, register/process-memory access, and
  broader ptrace handler orchestration.
- The latest post-campaign +3 syscall ptrace register slice routes
  `ptrace_getregs`/`ptrace_setregs` repeated register-word read/write loops and
  first-error behavior through Rust callback helpers with C fallbacks and
  direct syscall-policy equivalence coverage. C still owns tracee lookup,
  status gating, stack buffer lifetime, `copy_to_user()`/`copy_from_user()`,
  architecture `ptrace_read_user()`/`ptrace_write_user()`, debug-register
  details, and broader ptrace orchestration.
- The latest post-campaign +2 syscall ptrace text-access slice routes
  `ptrace_peektext`/`ptrace_poketext` status-gated process-memory word
  read/write callback staging through Rust helpers with C fallbacks and direct
  syscall-policy equivalence coverage. It is scored conservatively because C
  still owns tracee lookup, logging, user-copy, actual `read_process_vm()`/
  `patch_process_vm()` behavior, page-fault/mapping side effects, and broader
  ptrace orchestration.
- The latest post-campaign +3 syscall ptrace fpregs/regset slice routes
  `ptrace_getfpregs`/`ptrace_setfpregs` stopped/traced status handling and
  architecture fpregs callback dispatch through Rust helpers, and routes
  `ptrace_getregset`/`ptrace_setregset` iovec copy-in, architecture regset
  callback dispatch, and iov_len publication orchestration through Rust
  callback helpers with C fallbacks and direct syscall-policy equivalence
  coverage. C still owns tracee lookup, locks, user-copy callback bodies,
  architecture fp/register/regset primitives, signal delivery, allocation/free,
  Linux forwarding, and top-level syscall dispatch.
- The latest post-campaign +2 syscall ptrace user-word slice routes
  `ptrace_peekuser`/`ptrace_pokeuser` stopped/traced status handling and
  architecture user-area word read/write callback dispatch through Rust
  helpers with C fallbacks and direct syscall-policy equivalence coverage. It
  is scored conservatively because C still owns address validation, tracee
  lookup, `copy_to_user()` for peek results, architecture
  `ptrace_read_user()`/`ptrace_write_user()` primitives, and broader ptrace
  orchestration.
- The latest post-campaign +3 page-allocator CPU-cache slice routes CPU-local
  cache allocation/free fast-path orchestration through Rust helpers, including
  initialized/not-initialized branch handling, interrupt save/restore callback
  ordering, rb-tree allocation/free attempt, cache-hit shaping, and free
  success/failure classification. C still owns CPU-local variable selection,
  actual interrupt masking primitives, logging, non-cache locks, allocator
  lifetime, IKC send/channel selection, current-thread/channel lookup, and
  broader zero-request side effects.
- The latest post-campaign +3 scheduler/futex double-bucket slice routes
  futex double hash-bucket lock/unlock ordering through Rust helpers with C
  callback bridges and direct equivalence coverage. C still owns the actual
  spinlock primitives, hash-bucket protected list mutation, wakeups, IKC sends,
  scheduling, key lifetime, address translation, user-value comparison, race
  retry, and broader futex wake/requeue orchestration.
- The latest post-campaign +3 page-allocator locked-orchestration slice routes
  main NUMA allocation and direct free-to-tree lock/unlock callback
  orchestration through Rust helpers with direct equivalence coverage. C still
  owns the actual MCS lock primitives, logging, CPU-local variable selection,
  interrupt masking primitives, deferred-zero worker timing, IKC send/channel
  selection, current-thread/channel lookup, actual IKC send side effects, and
  broader allocator lifetime/zero-request orchestration.
- The latest post-campaign +3 page-allocator deferred-free slice routes
  deferred-free chunk enqueue plus Linux zero-request preparation orchestration
  through Rust helpers with direct equivalence coverage. C still owns
  CPU-local current/idle/channel selection, actual IKC send side effects,
  logging, interrupt context, deferred-zero worker timing, zeroed-list
  publication, and broader allocator lifetime.
- The latest post-campaign +3 scheduler/futex wake-scan slice routes
  hash-bucket wake-list scanning, key matching, optional bitset filtering,
  wake-limit handling, and wake callback ordering through Rust helpers for
  `futex_wake()` and `futex_wake_op()`. C still owns futex key lookup,
  hash-bucket locking, actual wake side effects, IKC sends, scheduler handoff,
  key references, user-value operations, address translation, and broader
  wake/requeue orchestration.
- The latest post-campaign +3 scheduler/futex requeue-loop slice routes
  source-list scanning, key matching, wake-vs-requeue selection, task/drop
  count accounting, and wake/requeue callback ordering through Rust helpers for
  `futex_requeue()`. C still owns comparison-user-value loading, hash-bucket
  locking, actual wake side effects, `requeue_futex()` key-reference and
  key-copy mutation, IKC sends, scheduler handoff, address translation, race
  retry, and broader futex wake/requeue orchestration.
- The latest post-campaign +3 scheduler/futex wait-setup slice routes
  `futex_wait_setup()` key initialization, get-key/queue-lock/user-value-load
  callback sequencing, mismatch/error cleanup, key release, and hash-bucket
  publication through Rust helpers. C still owns key lookup internals, address
  translation, page fault behavior, lock primitives, user-value load,
  key-reference lifetime, timeout/schedule behavior, wake side effects, and
  broader futex wait/retry orchestration.
- The latest post-campaign +3 x86 page-table walk slice routes normal and safe
  page-table walk iteration, callback result folding, bounds-derived entry
  selection, and optional physical-address skip policy through Rust helpers.
  C still owns visitor callback execution, table allocation/free,
  `phys_to_virt()` traversal, splitting, page/RSS accounting, page free side
  effects, mapping/free orchestration, TLB-sensitive mutation, and user-copy.
- The latest post-campaign +3 x86 virtual-to-physical slice routes per-level
  miss/walk/hit decisions plus physical-address and page-size result shaping
  for 4 KiB, 2 MiB, and 1 GiB entries through Rust helpers. C still owns
  page-table pointer traversal, `phys_to_virt()`, fault handling, page-table
  lifetime, mapping side effects, and user-copy.
- The latest post-campaign +3 process VM-range split/join slice routes
  split-range high-half field shaping, low-half end commit, join-range
  adjacency/object-offset validation, and surviving-range end commit through
  Rust helpers. C still owns page-table split/clear/free calls,
  `kmalloc()`/`kfree()`, memobj refcounting, TOFU split/merge hooks,
  rb-tree/cache mutation, XPMEM removal, and broader process lifetime/wait
  orchestration.
- The latest post-campaign +3 page allocator bitmap locked-wrapper slice
  routes bitmap allocator alloc/reserve/free/count/query/zero-free
  lock/call/unlock orchestration through Rust helpers. C still owns the actual
  MCS lock primitives, descriptor allocation/destruction, free panic/log
  policy, CPU-local selection, IKC send side effects, deferred-zero worker
  timing, zeroed-list publication, and broader allocator lifetime.
- The latest post-campaign +3 scheduler/futex hash-bucket init slice routes
  futex table lock-word and plist-head initialization through Rust helpers
  while preserving C allocation and fallback behavior. C still owns futex table
  allocation, actual spinlock primitives, wakeups, requeue key-reference
  mutation, futex key lookup internals, user-value load/comparison, IKC send
  side effects, IPIs, timer queues, context switching, address translation,
  key lifetime, race retry, schedule/schedule_timeout behavior, and remaining
  futex wake/requeue/wait side effects.
- The latest post-campaign +3 scheduler/futex requeue key-publication slice
  routes the requeue key-reference callback and `q->key` copy/publication
  through Rust helpers while preserving the C key-reference implementation and
  fallback behavior. C still owns futex table allocation, actual spinlock
  primitives, wakeups, futex key lookup internals, key-reference lifetime,
  user-value load/comparison, IKC send side effects, IPIs, timer queues,
  context switching, address translation, race retry, schedule/schedule_timeout
  behavior, and remaining futex wake/requeue/wait side effects.
- The latest post-campaign +3 page allocator destroy/free-callback slice
  routes descriptor free-page calculation, free-callback validation, and
  descriptor/free-page handoff through Rust helpers while preserving the C
  fallback. C still owns descriptor allocation, the actual
  `ihk_mc_free_pages()` implementation, logging, CPU-local selection, IKC send
  side effects, deferred-zero worker timing, zeroed-list publication, and
  broader allocator lifetime.
- The latest post-campaign +3 process VM range-cache slice routes
  range-cache retarget, clear, and store mutation for join, free, and lookup
  paths through Rust helpers while preserving the C fallback. C still owns
  rb-tree insert/erase, VM range allocation/free, page-table free/clear,
  memobj refcounting, TOFU list moves, and broader process lifetime behavior.
- The latest post-campaign +3 process VM range-commit slice routes final
  VM-range end and flag commits for extend-up and protection-change paths
  through Rust helpers while preserving the C fallback. C still owns page-table
  attribute changes, page-table free/clear, locks, memobj refcounting, TOFU
  hooks, rb-tree mutation, allocation/free, and broader lifetime behavior.
- The latest post-campaign +3 process VM stack-start slice routes
  stack-growth range-start alignment and commit in `do_page_fault_process_vm()`
  through Rust helpers while preserving the C fallback. C still owns range
  lookup, locking, access checks, page-fault handling, page allocation,
  page-table lookup and mapping, retry behavior, VM range allocation/free,
  memobj refcounting, TOFU hooks, rb-tree mutation, and broader process
  lifetime behavior.
- The latest +10 verified continuation slice toward the revised +35 goal
  routes page refcount/hash lifecycle bodies, `__ihk_pagealloc_init()`
  orchestration, and futex table allocation/publication/initialization
  orchestration through Rust helpers with C fallbacks and equivalence coverage.
  In `migration.txt` this is about +8 strict-core points because these are
  real core-body moves rather than helper-only trampolines. C still owns the
  external allocation and lock primitives, page frees, page-table mutation,
  futex wake/wait/requeue side effects, scheduler handoff, user-copy, and
  broad runtime lifetime behavior.
- The latest +5 verified continuation slice toward the revised +35 goal routes
  page-hash lock/allocation orchestration and futex hash-bucket selection
  through Rust helpers with C fallbacks and equivalence coverage. In
  `migration.txt` this adds about +5 strict-core points because Rust now owns
  the lock/unlock callback ordering around page-hash count/lookup/insert/unmap
  plus futex bucket selection, while C keeps the primitive spinlock,
  allocation, and key-hash callbacks. C still owns page-hash debug logging,
  page frees, page-table mutation, futex wake/wait/requeue side effects,
  scheduler handoff, user-copy, and broad runtime lifetime behavior.
- The latest +3 verified continuation slice toward the revised +35 goal routes
  `ihk_numa_alloc_pages()` cache-first/source-selection/fallback-to-NUMA
  orchestration through Rust helpers with C fallbacks and equivalence coverage.
  In `migration.txt` this adds about +3 strict-core points because Rust now
  owns the main allocation path's cache attempt, fallback selection, and source
  publication. C still owns CPU-local variable selection, logging, actual IRQ
  and MCS primitives, allocation/free primitives, IKC send side effects,
  zeroed-list publication, deferred-zero worker timing, and broader allocator
  lifetime.
- The latest +3 verified page-allocator free slice toward the revised +35 goal
  routes `ihk_numa_free_pages()` direct-versus-deferred free orchestration
  through Rust helpers with C fallbacks and equivalence coverage. In
  `migration.txt` this adds about +3 strict-core points because Rust now owns
  direct/free/deferred/ignored action selection and result publication for the
  post-cache free path. C still owns CPU-local current/channel selection,
  logging, actual IRQ and MCS primitives, IKC send side effects, zeroed-list
  publication, deferred-zero worker timing, and broader allocator lifetime.
- The latest +3 verified scheduler/futex dispatch slice toward the revised
  +35 goal routes top-level `futex()` command decode, private/realtime flag
  handling, clock-realtime rejection, wait/wake/requeue/wake-op callback
  selection, and invalid-command callback routing through Rust helpers with C
  fallbacks and equivalence coverage. In `migration.txt` this adds about +3
  strict-core points because Rust owns more of the primary futex syscall body
  instead of only queue/list helper islands. C still owns the dispatch
  side-effect callback bodies, actual spinlock/allocation/hash primitives,
  futex key lifetime, user-value loads, wake/requeue/wait side effects, timer
  queues, scheduler handoff, and context switching.
- The latest +3 verified Process/VM range-initialization slice toward the
  revised +35 goal routes `add_process_memory_range()` VM-range object
  initialization through Rust helpers with C fallbacks and equivalence
  coverage. In `migration.txt` this adds about +3 strict-core points because
  Rust now owns rb-node clear state, range field publication, object offset,
  page shift, private data, straight-start reset, and optional Tofu list
  initialization for the new range object. At that point C still owned allocation/free,
  range-tree insertion, memobj refcounting, page-table updates, XPMEM side
  effects, rollback, user-copy, and broader VM lifetime behavior.
- The latest +3 verified Process/VM range mapping-action slice toward the
  revised +35 goal routes `add_process_memory_range()` map/no-map action
  selection through Rust helpers with C fallbacks and equivalence coverage. In
  `migration.txt` this adds about +3 strict-core points because Rust now owns
  NOPHYS skip, remote/uncached/normal page-table update attr selection, XPMEM
  mark action, demand-paging logging action, PROT_NONE skip, and memclear
  gating. At that point C still owned range allocation/free, range-tree insertion, memobj
  refcounting, actual page-table updates, XPMEM flag mutation, memclear,
  rollback, user-copy, and broader VM lifetime behavior.
- The latest +5 verified Process/VM add-range orchestration slice completes the
  revised +35 goal by routing the post-bounds `add_process_memory_range()` body
  through a Rust orchestrator with C fallbacks and equivalence coverage. In
  `migration.txt` this adds about +5 strict-core points because Rust now owns
  allocation-callback handling, VM range initialization, insertion/update
  callback sequencing, insert/update failure cleanup, XPMEM and demand-paging
  actions, memclear callback gating, and returned-range publication. C still
  owned allocation/free callbacks, range-tree insertion/removal side effects, memobj
  refcounting, actual page-table updates, XPMEM flag mutation, memclear side
  effects, rollback side effects, user-copy, and broader VM lifetime behavior.
- The latest +2 verified Process/VM range-tree insertion slice starts the
  completed prior +50 continuation by routing `vm_range_insert()` traversal,
  overlap rejection, success/overlap callback sequencing, `rb_link_node()`
  publication, and `rb_insert_color()` balancing through Rust with C fallbacks and
  equivalence coverage. In `migration.txt` this adds about +4 strict-core
  points because Rust now owns a real VM range-tree mutation body. C still
  owns allocation/free callbacks, memobj refcounting, TOFU split/merge hooks,
  range-tree erase/removal, actual page-table updates, XPMEM flag mutation,
  memclear side effects, rollback side effects, user-copy, and broader VM
  lifetime behavior.
- The latest +2 verified syscall ID leaf-body slice brings the completed prior
  +50 continuation to +4 broad points by routing `getpid`, `getppid`, `gettid`,
  `set_tid_address`, `getuid`, `geteuid`, `getgid`, and `getegid` process/thread
  field reads plus `clear_child_tid` publication through Rust with C fallbacks
  and equivalence coverage. In `migration.txt` this adds about +2 strict-core
  points because Rust owns real syscall leaf bodies rather than return-shaping
  helpers alone. C still owns syscall ABI wrappers, current-thread lookup,
  argument extraction, top-level dispatch, user-copy, Linux forwarding, locks,
  allocation/free, signal delivery, ptrace orchestration, architecture register
  primitives, and high-risk handler bodies.
- The latest +4 verified futex wake orchestration slice brings the completed
  prior +50 continuation to +8 broad points by routing futex wake target orchestration
  through Rust with C fallbacks and equivalence coverage: mark-woken sequencing,
  Linux-vs-McKernel target selection, Linux response-channel fallback
  selection, IKC wake packet fill, IKC send callback sequencing, scheduler wake
  callback sequencing, and wake logging. In `migration.txt` this adds about +4
  strict-core points because Rust owns the wake orchestration body while C keeps
  the primitive side-effect callbacks. C still owns futex key lifetime,
  user-value loads, IKC send and scheduler wake primitives, wait/requeue side
  effects, timer queues, IPIs, context switching, race retry, and
  schedule/schedule_timeout behavior.
- The latest +3 verified syscall getresid body slice brings the completed prior
  +50 continuation to +11 broad points by routing `getresuid()` and `getresgid()`
  body sequencing through Rust with C fallbacks and equivalence coverage:
  process credential field reads, ordered `ruid/euid/suid` and `rgid/egid/sgid`
  copy sequencing, and fault short-circuit behavior through a C `copy_to_user`
  callback. In `migration.txt` this adds about +3 strict-core points because
  Rust owns real syscall body sequencing while C keeps the actual user-copy
  primitive and syscall ABI wrapper.
- The latest +3 verified page-allocator free-finish slice brings the completed
  prior +50 continuation to +14 broad points by routing `ihk_numa_free_pages()`
  post-action completion sequencing through Rust with C fallbacks and
  equivalence coverage: direct-free success/error logging selection,
  deferred-free error/skip/send action handling, Linux zero-request send
  callback sequencing, and send success/failure logging. In `migration.txt`
  this adds about +3 strict-core points because Rust owns more of the primary
  free path while C keeps CPU-local channel lookup, the actual `ihk_ikc_send()`
  primitive, and logging primitive bodies.
- The latest +3 verified x86 page-table root-lifecycle slice brings the completed
  prior +50 continuation to +17 broad points by routing `ihk_mc_pt_create()` and
  `ihk_mc_pt_destroy()` root lifecycle sequencing through Rust with C fallbacks
  and equivalence coverage: allocation-callback orchestration, new root zeroing,
  kernel-half entry copy from `init_pt`, destroy-root kernel-half clearing, and
  destroy-recursion callback dispatch. In `migration.txt` this adds about +3
  strict-core points because Rust owns a real page-table lifecycle body while C
  keeps the actual allocator/free primitives, recursive child-table destruction
  below the root, and `phys_to_virt()`.
- The latest +3 verified x86 page-table prepare-map slice brings the completed
  prior +50 continuation to +20 broad points by routing `ihk_mc_pt_prepare_map()`
  orchestration through Rust with C fallbacks and equivalence coverage: initial
  page-table selection, first-level L4 range traversal, present-entry
  short-circuiting, allocation callback sequencing, L4 entry publication,
  last-level set-page callback loop sequencing, and first error return
  propagation. In `migration.txt` this adds about +3 strict-core points because
  Rust owns a page-table preparation body while C keeps the actual allocation
  primitive, `virt_to_phys()`, and `__set_pt_page()`.
- The latest +3 verified x86 set-PTE body slice brings the completed prior +50
  continuation to +23 broad points by routing `ihk_mc_pt_set_pte()` body
  sequencing through Rust with C fallbacks and equivalence coverage:
  page-size/value selection callback orchestration, alignment error
  classification, log-callback selection, panic-callback dispatch for invalid
  page sizes, PTE store invocation, and final return shaping. In
  `migration.txt` this adds about +2 strict-core points because Rust owns an
  exported page-table mutation body while C keeps debug log wrappers, actual
  log/panic primitives, traversal, and allocation/free primitives.
- The latest +3 verified page-allocator top-level free slice brings the completed prior
  +50 continuation to +26 broad points by routing exported
  `ihk_numa_free_pages()` body sequencing through Rust with C fallbacks and
  equivalence coverage: CPU-cache free attempt classification, cache
  success/error log selection, direct-versus-deferred dispatch, Linux
  zero-request send callback sequencing, final log selection, and return
  shaping. In `migration.txt` this adds about +4 strict-core points because
  Rust owns the exported free body while C keeps CPU-local variable selection,
  actual lock/interrupt primitives, IKC channel lookup/send side effects,
  logging primitive bodies, deferred-zero worker timing, zeroed-list
  publication, and allocator lifetime.
- The latest +3 verified page-allocator top-level allocation slice brings the
  completed prior +50 continuation to +29 broad points by routing exported
  `ihk_numa_alloc_pages()` body sequencing through Rust with C fallbacks and
  equivalence coverage: cache-hit logging selection, direct-allocation logging
  selection, source-aware return shaping, and exported allocation handoff around
  cache-first/source-selection/fallback-to-NUMA orchestration. In
  `migration.txt` this adds about +3 strict-core points because Rust owns the
  exported allocation body while C keeps CPU-local variable selection, actual
  cache/tree lock primitives, `ihk_mc_alloc_pages()`, MCS/interrupt primitives,
  logging primitive bodies, allocator lifetime, zeroed-list publication timing,
  deferred-zero worker timing, and fallback implementation.
- The latest +3 verified page-allocator add/zero top-level slice brought the
  completed prior +50 continuation to a historical 32/50 broad-point checkpoint by routing exported
  `ihk_numa_add_free_pages()` and public `ihk_numa_zero_free_pages()`
  sequencing through Rust with C fallbacks and equivalence coverage: add-free
  success/error log selection, return shaping around the NUMA add-free mutation
  body, and public zero-free dispatch into the Rust-owned zero-list publication
  path. In `migration.txt` this adds about +3 strict-core points because Rust
  owns more exported allocator body sequencing while C keeps logging primitive
  bodies, actual allocation/free and lock/interrupt primitives, allocator
  lifetime, IKC send side effects, deferred-zero worker timing, broad allocator
  mutation, and fallback implementation.
- The latest +7 verified ABI/shared-primitives slice brings the active +50
  continuation to +39 broad points by adding Rust/C compile-time layout mirrors
  for pager create/map result packets plus McKernel memory area/node,
  page-allocator ops, aligned TLB-flush entry, and page-cache header structs,
  and by routing `vsnprintf()` base-10 digit emission through Rust-owned
  `put_dec_trunc`, `put_dec_full`, and `put_dec` helpers. In `migration.txt`
  this adds about +7 strict-core points because Rust now owns more prerequisite
  ABI layout and an active shared formatting primitive while C keeps variadic
  format parsing, width/sign/precision buffer policy, output orchestration, and
  broader private lifecycle layout coverage.
- The latest +7 verified CPU-local lifecycle slice brings the active +50
  continuation to +46 broad points by adding Rust/C layout mirrors for
  `rusage_percpu`, kmalloc metadata, SMP-call packets, backlog entries, and
  the full x86_64 `cpu_local_var`, and by routing CPU-local storage
  initialization, `get_cpu_local_var()` selection, and normal preempt counter
  updates through Rust with C fallbacks. In `migration.txt` this adds about +8
  strict-core points because Rust now owns a CPU-local execution/lifecycle body
  as well as the prerequisite layout, while C keeps allocation/free primitives,
  MCS/interrupt primitives, logging callbacks, IKC send side effects,
  deferred-zero worker timing, FUGAKU debug preempt behavior, and broader
  allocator lifetime/mutation.
- The latest +4 verified kmalloc/shared-parser slice completes the active +50
  continuation by routing kmalloc chunk header initialization, sorted free-list
  insertion, adjacent free-chunk consolidation, and `skip_atoi()` format
  width/precision pointer advancement through Rust with C fallbacks and
  equivalence coverage. In `migration.txt` this adds about +4 strict-core
  points because Rust now owns bounded allocator mutation and a shared parser
  body while C keeps public `kmalloc()`/`kfree()` sequencing, heap metadata
  lifetime, the surrounding variadic formatter parser, output orchestration,
  locking context, primitive allocation/free behavior, and fallback
  implementations.
- The latest +4 verified shared-formatting slice starts the active +50
  continuation by routing `number()` sign, prefix, width, precision,
  zero/space padding, octal/hex/decimal digit staging, bounded output writes,
  and returned pointer advancement through Rust with C fallbacks and expanded
  equivalence coverage. In `migration.txt` this adds about +4 strict-core
  points because Rust now owns the central numeric/pointer formatter body while
  C keeps format-token decoding, string and pointer extension dispatch, va_arg
  extraction, `%n` writes, final NUL termination, and the surrounding
  `vsnprintf()` loop.
- The latest +4 verified shared-format-decoder slice brings the active +50
  continuation to +8 broad points by routing `format_decode()` literal-span,
  flag, field-width, precision, qualifier, conversion-type, base, signedness,
  and width/precision continuation-state parsing through Rust with C fallbacks
  and equivalence coverage. In `migration.txt` this adds about +4 strict-core
  points because Rust now owns the format-token parser body while C keeps the
  surrounding `vsnprintf()` loop, va_arg extraction, string and pointer
  extension dispatch, `%n` writes, final NUL termination, and output buffer
  lifetime.
- The latest +3 verified shared-string-format slice brings the active +50
  continuation to +11 broad points and completes the broad shared-primitives
  dashboard row by routing `string()` `%s` output formatting through Rust with
  C fallbacks and equivalence coverage. In `migration.txt` this adds about +3
  strict-core points because Rust now owns NULL-string substitution,
  precision-bounded length selection, left/right padding, bounded output
  writes, and returned pointer advancement while C keeps the surrounding
  `vsnprintf()` loop, va_arg extraction, pointer extension dispatch, `%n`
  writes, final NUL termination, and output buffer lifetime.
- The previous +4 verified signal/futex/register ABI-layout slice brings the
  active +50 continuation to +15 broad points by adding Rust/C compile-time
  layout mirrors for x86 signal action, altstack, `siginfo_t`,
  `signalfd_siginfo`, ptrace `user_regs_struct`, `user_fpregs_struct`,
  `struct user`, futex hash-bucket/key/queue layouts, and the offsets that
  feed future signal, ptrace, and futex body ownership. This adds about +4
  strict-core foundation points in `migration.txt`; C still owns top-level
  syscall dispatch, user-copy, signal delivery, actual register access
  primitives, futex key lifetime, wait/wake side effects, scheduler handoff,
  lock primitives, and IKC send behavior.
- The latest +4 verified syscall/control-plane ABI-layout slice brings the
  active +50 continuation to +19 broad points by adding Rust/C compile-time
  layout mirrors for `ikc_scd_init_param`, `syscall_post`, coredump
  `coretable`, procfs request/file descriptors, `sysinfo`, `tod_data_s`, CPU
  mapping requests, perf-control descriptors, UTI attributes/context, and
  `move_pages_smp_req`. This adds about +4 strict-core foundation points in
  `migration.txt`; C still owns procfs buffer mutation, perf-control side
  effects, UTI scheduling, time publication, move-pages page-table mutation,
  CPU mapping exchange, user-copy, locks, IKC exchange, callback bodies, and
  fallback implementation.
- The latest +4 verified x86 register/FPU save-state ABI-layout slice brings
  the active +50 continuation to +23 broad points by adding Rust/C
  compile-time layout mirrors for x86 descriptor pointers, `tss64`,
  `i387_fxsave_struct`, YMM high halves, LWP save areas, bound-register state,
  `xsave_hdr_struct`, and packed/aligned `xsave_struct`. This adds about +4
  strict-core foundation points in `migration.txt`; C still owns context
  switching, ptrace register access, signal-frame FPU save/restore,
  XSAVE/XRSTOR execution, architecture trap behavior, and fallback
  implementation.
- The latest +4 verified sysfs control-plane ABI-layout slice brings the
  active +50 continuation to +27 broad points by adding Rust/C compile-time
  layout mirrors for sysfs create, mkdir, symlink, lookup, unlink, and setup
  request packets. This adds about +4 strict-core foundation points in
  `migration.txt`; C still owns sysfs allocation, path formatting, IKC sends,
  busy waits, host-side object creation, show/store callbacks, release
  handling, and fallback implementation.
- The latest +3 verified sigaltstack strict-core slice moves the
  `sigaltstack()` syscall body sequencing into Rust with C fallbacks and
  equivalence coverage: old-stack copyout, new-stack copyin, validation,
  disabled-stack normalization, and thread `sigstack` mutation. This does not
  add broad dashboard points because Syscall Core is already 100%, but it moves
  `migration.txt` Syscall Core strict ownership from 63% to 66%. C still owns
  the syscall ABI wrapper, current-thread lookup, actual user-copy primitive,
  signal delivery, top-level syscall dispatch, Linux forwarding, and fallback
  implementation.
- The latest +4 verified sysfs response-body strict-core slice moves
  show/store/release response sequencing into Rust with C fallbacks and
  equivalence coverage: default ssize/error shaping, optional callback
  dispatch, response packet msg/err/arg publication, send callback dispatch,
  and output publication. This does not add broad dashboard points because the
  procfs/sysfs/xpmem/file-object row is already 100%, but it moves
  `migration.txt` procfs/sysfs/xpmem/file object strict ownership from 60% to
  64%. C still owns callback bodies, the actual `ihk_ikc_send()` primitive,
  logging, global buffer lifetime, packet-handler dispatch, allocation/free,
  sysfs path formatting, busy waits, host-side object creation, user-copy, and
  fallback implementation.
- The latest +4 verified coredump/uio ABI-layout slice brings the active +50
  continuation to +31 broad points by adding Rust/C compile-time layout
  mirrors for ELF core headers, program headers, note headers, `elf_siginfo`,
  `prstatus64_timeval`, `elf_prstatus64`, `elf_prpsinfo64`, and `iovec`.
  This adds about +4 strict-core foundation points in `migration.txt`; C still
  owns coredump note generation, architecture register capture, process-memory
  dumping, user-vector walking, copy paths, and fallback implementation.
- The latest +3 verified sysfs packet-dispatch strict-core slice moves
  show/store/release request dispatch into Rust with C fallbacks and
  equivalence coverage: request-kind classification, typed callback selection,
  show/store/release callback dispatch, store-size publication from the
  incoming packet error field, and unknown-message classification. This does
  not add broad dashboard points because the procfs/sysfs/xpmem/file-object
  row is already 100%, but it moves `migration.txt` procfs/sysfs/xpmem/file
  object strict ownership from 64% to 67%. C still owns the public IKC handler
  wrapper, unknown-message logging, callback bodies, raw IKC send behavior,
  global buffer lifetime, allocation/free, sysfs path formatting, busy waits,
  host-side object creation, user-copy, and fallback implementation.
- The latest +5 verified x86 CPU-local/sysfs/profile ABI-layout slice brings
  the active +50 continuation to +36 broad points by adding Rust/C
  compile-time layout mirrors for the x86 CPU-local page, x86 kernel context,
  TLS `user_desc`, sysfs operation callbacks/handle/bitmap parameters,
  `itimerval`, and `profile_event`. This adds about +5 strict-core foundation
  points in `migration.txt`; C still owns CPU-local stack switching, GDT/TSS
  mutation, TLS setup, sysfs callback execution, profile accumulation, timer
  delivery, copy paths, and fallback implementation.
- The previous +13 verified XPMEM/SysV shm/memobj ABI-layout slice brought the
  active +50 continuation to +49 broad points by adding Rust/C compile-time
  layout mirrors for low-level `ihk_rwlock`, `kref`, rbtree augmentation
  callbacks, ftrace branch-data records, `memobj_ops`, `memobj`, SysV shm
  limit/info and lock-user state, and the XPMEM ID/hash/thread-group/segment/
  access-permit/partition/permission/attachment object graph. This closes the
  currently scoped x86_64/Rocky ABI/layout foundation row, but C still owns
  XPMEM attach/detach, SysV shm lifetime, memobj refcounting, page I/O,
  ftrace accounting, rbtree mutation, locking primitives, allocation/free,
  user-copy, object lifecycle side effects, and fallback implementation.
- The latest +1 verified host-core DMA request callback slice completes the
  active +50 continuation by routing `ihk_dma_request()` through Rust-owned
  channel/ops validation, request callback presence handling, callback
  invocation, and no-callback `-EINVAL` shaping. C keeps the exported ABI
  wrapper, C fallback, and DMA provider callback body.
- The latest +1 strict-core syscall slice routes `waitid()` SIGCHLD siginfo
  construction and copyout callback sequencing through Rust helpers with C
  fallbacks. C still owns `do_wait()` scanning/sleeping, wait locks, status and
  rusage production, the actual user-copy primitive, scheduler behavior, and
  fallback implementation.
- The latest +2 strict-core syscall slice routes `wait4()` wrapper sequencing
  through Rust helpers with C fallbacks. Rust owns option validation, zeroed
  rusage preparation, do-wait callback invocation, status/rusage copyout
  gating, copyout callback dispatch, and return shaping; C still owns
  `do_wait()` internals, wait locks, the actual user-copy primitive, scheduler
  behavior, and fallback implementation.
- The latest +2 strict-core syscall slice routes `waitid()` wrapper sequencing
  through Rust helpers with C fallbacks. Rust owns idtype/options validation,
  zeroed rusage preparation, do-wait callback invocation, negative-result
  propagation, siginfo copyout dispatch, and return shaping; C still owns
  `do_wait()` internals, wait locks, the actual user-copy primitive, scheduler
  behavior, and fallback implementation.
- The latest +1 strict-core syscall slice routes `wait_continued()` body
  sequencing through Rust helpers with C fallbacks. Rust owns continued-status
  publication, reap-target selection, continued-signal reap callback dispatch,
  WNOWAIT preservation through the reap helper, and pid/tid return selection; C
  still owns wait list scans, wait locks, caller-side duplicate reap behavior,
  scheduler behavior, and fallback implementation.
- IHK open/release/close/init/exit/minor-registration, register-device cleanup,
  destroy-all-OS candidate/restore, stray-kmsg trim, event-list cleanup,
  destroy callback, notifier policy decisions, and open refcount mutation
  route through Rust helpers; treat these as established boundary context while
  the remaining IHK mutation bodies are still active scope.

Latest documented validation passed:

- `rustfmt kernel/rust/abi.rs`.
- `bash -n kernel/rust/tests/run_equivalence.sh`.
- `git diff --check -- kernel/rust/abi.rs kernel/rust/abi_checks.c`.
- Rust-enabled `cmake --build /tmp/mckernel-rocky-rust --target mckernel.img -j2`.
- C-fallback `cmake --build /tmp/mckernel-rocky-c-fallback --target mckernel.img -j2`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `object_helpers ok digest=5aa2610a74119a37`.
- `python3 -m py_compile scripts/rust-ownership-report.py`.
- `scripts/rust-ownership-report.py --check-dashboard overview.txt --check-dashboard overview2.txt --top 5`.
- `git diff --check`.
- `rustfmt kernel/rust/sched_helpers.rs`.
- `rustfmt kernel/rust/x86_memory_helpers.rs`.
- `rustfmt kernel/rust/process_helpers.rs`.
- `rustfmt ihk/linux/driver/smp/rust/smp_driver_helpers.rs`.
- `rustfmt kernel/rust/page_alloc.rs`.
- `rustfmt kernel/rust/syscall_policy.rs`.
- `rustfmt kernel/rust/abi.rs kernel/rust/numparse.rs`.
- `rustfmt kernel/rust/abi.rs kernel/rust/cls_helpers.rs`.
- `rustfmt kernel/rust/mem_helpers.rs kernel/rust/numparse.rs`.
- `rustfmt kernel/rust/numparse.rs`.
- `bash -n kernel/rust/tests/run_equivalence.sh`.
- `git diff --check`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=44f8ebf6efebbadf`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=68635108100ea1c0`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=504d5b3e9c153630`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=a80ef094b43f24e8`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=34117c66f91ba2ea`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=2a415c1756979d79`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=25fb3df8ffceadbb`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=2818dd602ed5bc4c`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc ok digest=db15eec71e0aad78`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=bcb2642411511aea`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=0b3811141e0e5228`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=3b05135350df748e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=81a86d9fa4f9900f`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=68a9fbfe485ec6f0`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=91790b3aa3a68a22`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=a4fa8b1f93b2890e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=90f372a037f1fbff`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=5bf0cbacd30b645e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_helpers ok digest=83a48b282c82457c`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=cf493b9170405954`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=91790b3aa3a68a22`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_helpers ok digest=8487e6bc559e457d`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=1e4506b505343675`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=c7e535b154b79d5e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `ihk_module_helpers ok map=0000000000000018 bits=0000000000000007/0000000000000000`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=6058b8fa4f7180c7`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=78fdc3d33065184f`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=c8c7596d6bc6cb66`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=df124e68726bad52`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=010895ac2df2169d`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `process_helpers ok digest=46e57fd40b55a03e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `syscall_policy_helpers ok digest=e6e8d5fc8faaf78a`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `sched_helpers ok digest=61cc5097489f9e38`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `syscall_policy_helpers ok digest=5bc42cf54d03b151`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc ok digest=bc5add72ff7bd6de`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=b1a9ce41d6284016`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=39dcb1d0c6c1e89e`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `x86_memory_helpers ok digest=0db20cb0350e799f`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=953c73f87339c534`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=d8ba50a90955fad2`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `page_alloc_bitmap ok digest=8556bdeaa7090fa7`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `printf_decimal ok digest=31ce3c0f3ecf93c1`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `cls_helpers ok digest=3020b4b56921f7dc`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `kmalloc_helpers ok digest=54cdbef90d9c7f07`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `printf_decimal ok digest=9b42843c73ef2870`.
- `kernel/rust/tests/run_equivalence.sh` passed, including
  `printf_decimal ok digest=ba6e3675fed38849`.
- `cmake --build /tmp/mckernel-rocky-c-fallback --target mckernel.img -j2`.
- `cmake --build /tmp/mckernel-rocky-rust --target mckernel.img -j2`
  passed with the existing jobserver warning.
- `python3 -m py_compile scripts/rust-ownership-report.py`.
- `scripts/rust-ownership-report.py --check-dashboard overview.txt --check-dashboard overview2.txt --top 25`.
- QEMU setup now provides `qemu-system-x86_64` through the Rocky `qemu-kvm`
  binary and libvirt is active, but `/dev/kvm` is not exposed and no
  system-QEMU boot harness exists yet.
- `cmake --build /tmp/mckernel-rocky-c-fallback --target ihk_ko -j2`.
- `cmake --build /tmp/mckernel-rocky-rust --target ihk_ko -j2`.
- `cmake --build /tmp/mckernel-rocky-c-fallback --target mckernel.img -j2`.
- `cmake --build /tmp/mckernel-rocky-rust --target mckernel.img -j2`.

## Validation Ladder

Use staged validation and stop at the first failure:

1. Source checks: formatting, shell syntax, `git diff --check`, and targeted
   compile checks.
2. Rust/C equivalence: `kernel/rust/tests/run_equivalence.sh`.
3. C fallback build for touched surfaces.
4. Rust-enabled `mckernel.img` build.
5. IHK/module build targets such as `ihk_ko` when host-module code changes.
6. Module-load smoke only when it does not reboot the host.
7. Boot and runtime smoke tests only with explicit user approval for that run,
   because boot scripts may reboot or restart the McKernel environment.

## Next Major Work

At the start or end of every run, describe the next major set of work.

Recommended next phase after stopping the full-port goal:

- Treat `full-port.txt` as complete and stop the full-port scoring campaign.
  Future progress should be reflected outside `full-port.txt`, primarily in
  `overview.txt` for broad/default-path ownership and in
  `rust-source-retirement.txt` only when a C implementation body is actually
  retired under that tracker's definition.
- Continue batching movement at least 2 aggregate percentage points at a time
  when updating percentages. If fewer than 2 points remain in a row, state that
  explicitly and verify the final smaller closure.
- Next concrete default-path user-tools batch: route the always-built
  `sched_yield` shared library through Rust in the Rust-enabled build while
  preserving the C fallback under `ENABLE_RUST_USER_TOOLS=OFF`, then pair it
  with another built user-tool slice such as additional `mcstat` output or loop
  control shaping so the outside tracker movement is at least +2. Validate
  Rust and fallback builds plus symbol/smoke checks before updating trackers.
- Do not count QLMPI (`qlfort`, `qlmpi`, `ql_server`, `ql_talker`,
  `ql_mpiexec_*`) or UTI syscall-intercept work in the current build unless a
  configured validation tree has `ENABLE_QLMPI=ON` or `ENABLE_UTI=ON`; the
  current known Rocky build trees have both disabled.
- Good retirement/default-path candidates after the first user-tools batch are
  built user tools and host/control-plane surfaces with bounded side effects:
  `mcstat`, `mcexec`, `mcinspect`, `eclair`, `ldump2mcdump`, IHK/mcctrl path
  formatting and validation helpers, and additional host-module preflight
  decisions. Avoid deleting fallback bodies unless the fallback requirement has
  been explicitly retired or the C body is no longer McKernel-owned logic.
- Continue to keep high-risk runtime mutation in C until direct runtime
  coverage exists: allocation/free, refcount mutation, lock/list mutation,
  page-table mutation, page I/O, procfs/sysfs IKC exchange, user-copy, process
  lifetime mutation, scheduler wake/context behavior, signal delivery, memory
  registration, and broad IKC exchange side effects.
- Validation for the next batch should include targeted formatting,
  `git diff --check`, `kernel/rust/tests/run_equivalence.sh` when helper logic
  changes, Rust-enabled builds for touched targets, C-fallback builds for the
  same targets, symbol checks proving the Rust-enabled path uses Rust helpers
  and the fallback path does not, and runtime smoke only through the approved
  non-reboot QEMU/guest path.
