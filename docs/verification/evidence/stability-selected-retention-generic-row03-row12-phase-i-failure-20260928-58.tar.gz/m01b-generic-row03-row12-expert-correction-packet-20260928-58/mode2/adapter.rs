#![cfg(test)]
use crate::application_syscall::ResponseMemory;
use crate::prelude::{Vec, GFP_KERNEL};
use crate::{stability_observer as observer, stability_phase as phase};
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};
use std::sync::atomic::{AtomicU64, Ordering};

// Packet52 assertion map: Geometry::validate binds all immutable allocation,
// span, address, physical and Claim fields. State queues retain sole Boxes.
#[repr(align(8))]
pub(crate) struct AlignedBacking([u8; 56]);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Event {
    Construction, Address, PreparationBaseline, StatusStore, Send, Release,
    DeferredInsertion, FinishedDrop, UnfinishedDrop, QuarantineInsertion, Deallocation,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Geometry {
    pub allocation_bytes: usize,
    pub allocation_alignment: usize,
    pub allocation_start: usize,
    pub allocation_end: usize,
    pub span_offset: usize,
    pub span_bytes: usize,
    pub span_start: usize,
    pub span_end: usize,
    pub physical: u64,
    pub physical_end: u64,
    pub claim: observer::Claim,
}
impl Geometry {
    pub(crate) fn validate(&self) {
        assert_eq!((self.allocation_bytes, self.allocation_alignment), (56, 8));
        assert_eq!((self.span_offset, self.span_bytes), (8, 40));
        assert_ne!(self.allocation_start, 0);
        assert_eq!(self.allocation_start % 8, 0);
        assert_eq!(self.allocation_start.checked_add(56), Some(self.allocation_end));
        assert_eq!(self.allocation_start.checked_add(8), Some(self.span_start));
        assert_eq!(self.span_start.checked_add(40), Some(self.span_end));
        assert_eq!(self.span_end.checked_add(8), Some(self.allocation_end));
        assert_eq!(self.span_start % 8, 0);
        assert_eq!((self.physical, self.physical_end), (0x1000, 0x1028));
        assert_eq!(self.physical.checked_add(40), Some(self.physical_end));
        assert_eq!(self.claim, exact_claim());
    }
}
pub(crate) fn exact_claim() -> observer::Claim {
    observer::Claim {
        os: 1, generation: 1,
        response: observer::Tag { index: 0, serial: Some(1), physical: 0x1000, end: 0x1028 },
        payload: None,
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Fixture {
    pub geometry: Geometry,
    pub addresses: u64,
    pub statuses: u64,
    pub sends: u64,
    pub releases: u64,
    pub deferred_insertions: u64,
    pub finished_drops: u64,
    pub unfinished_drops: u64,
    pub quarantine_insertions: u64,
    pub deallocations: u64,
    pub deferred_length: usize,
    pub quarantine_length: usize,
    pub live_owner: bool,
    pub released: bool,
    pub prohibited_addresses: u64,
    pub duplicate_releases: u64,
    pub events: std::vec::Vec<Event>,
}
struct State {
    fixture: Option<Fixture>,
    deferred: Vec<Box<AlignedBacking>>,
    quarantine: Vec<Box<AlignedBacking>>,
}
pub(crate) struct Ledger { state: Mutex<State> }
impl Ledger {
    pub(crate) fn new() -> Arc<Self> {
        Arc::new(Self { state: Mutex::new(State {
            fixture: None,
            deferred: Vec::with_capacity(1, GFP_KERNEL).unwrap(),
            quarantine: Vec::with_capacity(1, GFP_KERNEL).unwrap(),
        }) })
    }
    pub(crate) fn snapshot(&self) -> Fixture {
        let state = self.state.lock().unwrap();
        let mut result = state.fixture.as_ref().unwrap().clone();
        result.deferred_length = state.deferred.len();
        result.quarantine_length = state.quarantine.len();
        result
    }
    pub(crate) fn baseline(&self) {
        let mut state = self.state.lock().unwrap();
        state.fixture.as_mut().unwrap().events.push(Event::PreparationBaseline);
    }
    pub(crate) fn send(&self, packet: &[u8; 128]) -> Result<(), i32> {
        // This checks the supplied actual callback packet in its entirety.
        // The two rows require zero callbacks, so no wake coverage is claimed.
        {
            let mut state = self.state.lock().unwrap();
            let f = state.fixture.as_mut().unwrap();
            f.sends += 1;
            f.events.push(Event::Send);
        }
        let mut expected = [0u8; 128];
        expected[8..12].copy_from_slice(&0x14i32.to_le_bytes());
        expected[24..28].copy_from_slice(&70i32.to_le_bytes());
        assert_eq!(packet.len(), 128);
        assert_eq!(packet, &expected);
        Ok(())
    }
    pub(crate) fn drain_deferred(&self) {
        let batch = {
            let mut state = self.state.lock().unwrap();
            std::mem::take(&mut state.deferred)
        };
        for backing in batch {
            drop(backing);
            let mut state = self.state.lock().unwrap();
            let f = state.fixture.as_mut().unwrap();
            f.deallocations += 1;
            f.events.push(Event::Deallocation);
        }
    }
    pub(crate) fn drain_quarantine(&self) {
        let batch = {
            let mut state = self.state.lock().unwrap();
            std::mem::take(&mut state.quarantine)
        };
        for backing in batch {
            drop(backing);
            let mut state = self.state.lock().unwrap();
            let f = state.fixture.as_mut().unwrap();
            f.deallocations += 1;
            f.events.push(Event::Deallocation);
        }
    }
}
pub(crate) struct TestResponseMemory {
    backing: Option<Box<AlignedBacking>>,
    ledger: Arc<Ledger>,
    claim: observer::Claim,
    released: bool,
}
impl TestResponseMemory {
    pub(crate) fn new(ledger: Arc<Ledger>) -> Self {
        let mut backing = Box::new(AlignedBacking([0; 56]));
        // Guards and span are initialized only before publication.
        backing.0[..8].fill(0xa5);
        backing.0[48..].fill(0x5a);
        let allocation_start = backing.0.as_mut_ptr() as usize;
        let geometry = Geometry {
            allocation_bytes: std::mem::size_of::<AlignedBacking>(),
            allocation_alignment: std::mem::align_of::<AlignedBacking>(),
            allocation_start,
            allocation_end: allocation_start.checked_add(56).unwrap(),
            span_offset: 8, span_bytes: 40,
            span_start: allocation_start.checked_add(8).unwrap(),
            span_end: allocation_start.checked_add(48).unwrap(),
            physical: 0x1000, physical_end: 0x1028, claim: exact_claim(),
        };
        geometry.validate();
        let mut events = std::vec::Vec::new();
        events.try_reserve_exact(16).unwrap();
        events.push(Event::Construction);
        {
            let mut state = ledger.state.lock().unwrap();
            // This ledger cannot admit a second owner or reuse its old Claim.
            assert!(state.fixture.is_none(), "second owner or reused claim");
            assert!(state.deferred.is_empty() && state.quarantine.is_empty());
            state.fixture = Some(Fixture {
                geometry, addresses: 0, statuses: 0, sends: 0, releases: 0,
                deferred_insertions: 0, finished_drops: 0, unfinished_drops: 0,
                quarantine_insertions: 0, deallocations: 0,
                deferred_length: 0, quarantine_length: 0,
                live_owner: true, released: false,
                prohibited_addresses: 0, duplicate_releases: 0, events,
            });
        }
        Self { backing: Some(backing), ledger, claim: exact_claim(), released: false }
    }
}
// SAFETY: The only constructor creates a sole aligned 56-byte allocation with
// a 40-byte response span. Ownership moves to a retained queue at release/drop;
// the queue is destroyed explicitly after all publication and scalar samples.
unsafe impl ResponseMemory for TestResponseMemory {
    fn verification_owner(&self) -> Option<observer::Claim> { Some(self.claim) }
    fn physical(&self) -> u64 { self.claim.response.physical }
    fn address(&mut self) -> *mut u8 {
        {
            let mut state = self.ledger.state.lock().unwrap();
            let f = state.fixture.as_mut().unwrap();
            if self.released || f.released || !f.live_owner || f.statuses != 0 || self.backing.is_none() {
                f.prohibited_addresses += 1;
                panic!("address requested after publication/release or without ownership");
            }
            f.addresses += 1;
            f.events.push(Event::Address);
        }
        observer::address(self.claim);
        // Only the guarded, pre-publication branch reaches this pointer access.
        unsafe { self.backing.as_mut().unwrap().0.as_mut_ptr().add(8) }
    }
    fn verification_status_store(&self) {
        let mut state = self.ledger.state.lock().unwrap();
        let f = state.fixture.as_mut().unwrap();
        assert_eq!(f.statuses, 0);
        assert!(f.live_owner && !f.released);
        f.statuses += 1;
        f.events.push(Event::StatusStore);
    }
    unsafe fn release(mut self) {
        {
            let mut state = self.ledger.state.lock().unwrap();
            let f = state.fixture.as_mut().unwrap();
            if self.released || f.released || !f.live_owner || self.backing.is_none() {
                f.duplicate_releases += 1;
                panic!("duplicate release or missing owner");
            }
            assert_eq!(f.statuses, 1);
            self.released = true;
            f.released = true;
            f.live_owner = false;
            f.releases += 1;
            f.events.push(Event::Release);
            let backing = self.backing.take().unwrap();
            state.deferred.push(backing, GFP_KERNEL).unwrap();
            let f = state.fixture.as_mut().unwrap();
            f.deferred_insertions += 1;
            f.events.push(Event::DeferredInsertion);
        }
        observer::release(self.claim);
    }
}
impl Drop for TestResponseMemory {
    fn drop(&mut self) {
        let mut state = self.ledger.state.lock().unwrap();
        if self.released {
            assert!(self.backing.is_none());
            let f = state.fixture.as_mut().unwrap();
            f.finished_drops += 1;
            f.events.push(Event::FinishedDrop);
        } else {
            let backing = self.backing.take().expect("sole unreleased backing");
            state.quarantine.push(backing, GFP_KERNEL).unwrap();
            let f = state.fixture.as_mut().unwrap();
            assert!(f.live_owner && !f.released);
            f.live_owner = false;
            f.unfinished_drops += 1;
            f.events.push(Event::UnfinishedDrop);
            f.quarantine_insertions += 1;
            f.events.push(Event::QuarantineInsertion);
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct ObserverCounters {
    pub address_calls: u64,
    pub payload_calls: u64,
    pub payload_bytes: u64,
    pub release_calls: u64,
    pub released: bool,
    pub after_release_calls: u64,
    pub duplicate_release: u64,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct PhaseState {
    pub stage: u64,
    pub accepted_sequence: u64,
    pub release_commits: u64,
    pub invalid: i32,
    pub timer: Option<u64>,
}
pub(crate) fn phase_state() -> PhaseState {
    PhaseState {
        stage: phase::stage(), accepted_sequence: phase::accepted_sequence(),
        release_commits: phase::verification_test_release_commits(),
        invalid: phase::invalid_errno(), timer: phase::timer(),
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Snapshot {
    pub fixture: Fixture,
    pub observer: ObserverCounters,
    pub phase: PhaseState,
    pub selected: observer::Selection,
}
// These strict parsers consume only actual log bytes. Missing, extra, duplicate,
// malformed and differently typed fields all fail; there is no default value.
fn fields<'a>(line: &'a str, marker: &str, keys: &[&str]) -> BTreeMap<&'a str, &'a str> {
    assert!(line.ends_with('\n'));
    assert_eq!(line.bytes().filter(|b| *b == b'\n').count(), 1);
    let mut tokens = line.trim_end_matches('\n').split(' ');
    assert_eq!(tokens.next(), Some(marker));
    let mut result = BTreeMap::new();
    for token in tokens {
        let (key, value) = token.split_once('=').expect("key=value");
        assert!(!key.is_empty() && !value.is_empty() && !value.contains('='));
        assert!(result.insert(key, value).is_none(), "duplicate field");
    }
    assert_eq!(result.len(), keys.len());
    for key in keys { assert!(result.contains_key(key), "missing field {key}"); }
    result
}
fn number(value: &str) -> u64 {
    assert!(!value.is_empty() && value.bytes().all(|b| b.is_ascii_digit()));
    let parsed = value.parse::<u64>().unwrap();
    assert_eq!(parsed.to_string(), value);
    parsed
}
fn boolean(value: &str) -> bool {
    match value { "true" => true, "false" => false, _ => panic!("invalid boolean") }
}
pub(crate) fn sample(ledger: &Arc<Ledger>, key: observer::Selection) -> Snapshot {
    static LAST_SEQUENCE: AtomicU64 = AtomicU64::new(0);
    assert_eq!(observer::selected(), Some(key));
    let cursor = crate::capture::cursor();
    // No capture or fixture lock is held across the observer calls.
    let sequence = observer::begin(observer::Phase::AcceptedReturn, key).unwrap();
    assert!(sequence > LAST_SEQUENCE.swap(sequence, Ordering::AcqRel));
    let fixture = ledger.snapshot();
    let phase = phase_state();
    let selected = observer::selected().unwrap();
    assert_eq!(selected, key);
    assert!(observer::end(sequence, true));
    let interval = crate::capture::interval(cursor);
    assert_eq!(interval.len(), 3);
    assert_eq!(interval[0], format!(
        "STABILITY_OWNER_BEGIN version=1 sequence={} phase=AcceptedReturn selection={:?} sampling=independent_domains\n",
        sequence, key));
    let counters = fields(&interval[1], "STABILITY_OWNER_COUNTERS", &[
        "version", "sequence", "selected_ledger_serial", "address_calls",
        "payload_calls", "payload_bytes", "release_calls", "released",
        "after_release_calls", "duplicate_release", "sampling",
    ]);
    assert_eq!(number(counters["version"]), 1);
    assert_eq!(number(counters["sequence"]), sequence);
    assert_eq!(counters["selected_ledger_serial"], "Some(1)");
    assert_eq!(counters["sampling"], "independent_atomics");
    let observed = ObserverCounters {
        address_calls: number(counters["address_calls"]),
        payload_calls: number(counters["payload_calls"]),
        payload_bytes: number(counters["payload_bytes"]),
        release_calls: number(counters["release_calls"]),
        released: boolean(counters["released"]),
        after_release_calls: number(counters["after_release_calls"]),
        duplicate_release: number(counters["duplicate_release"]),
    };
    let end = fields(&interval[2], "STABILITY_OWNER_END",
        &["version", "sequence", "complete", "counters_valid", "result"]);
    assert_eq!(number(end["version"]), 1);
    assert_eq!(number(end["sequence"]), sequence);
    assert!(boolean(end["complete"]));
    assert!(boolean(end["counters_valid"]));
    assert_eq!(end["result"], "COMPLETE_SNAPSHOT");
    // Sequence belongs to the fresh interval, not the behavioral no-delta tuple.
    Snapshot { fixture, observer: observed, phase, selected }
}
