#![cfg(test)]
#![allow(dead_code, unused_imports)]
extern crate self as kernel;

pub mod prelude {
    pub use crate::FallibleVec as Vec;
    pub const GFP_KERNEL: () = ();
    pub trait VecExt {}
    impl<T> VecExt for Vec<T> {}
}
#[derive(Clone, Debug)]
pub struct FallibleVec<T>(std::vec::Vec<T>);
impl<T> Default for FallibleVec<T> {
    fn default() -> Self { Self(std::vec::Vec::new()) }
}
impl<T> FallibleVec<T> {
    pub fn with_capacity(capacity: usize, _flags: ()) -> Result<Self, ()> {
        let mut values = std::vec::Vec::new();
        values.try_reserve_exact(capacity).map_err(|_| ())?;
        Ok(Self(values))
    }
    pub fn push(&mut self, value: T, _flags: ()) -> Result<(), ()> {
        self.0.try_reserve(1).map_err(|_| ())?;
        self.0.push(value);
        Ok(())
    }
}
impl<T> std::ops::Deref for FallibleVec<T> {
    type Target = std::vec::Vec<T>;
    fn deref(&self) -> &Self::Target { &self.0 }
}
impl<T> std::ops::DerefMut for FallibleVec<T> {
    fn deref_mut(&mut self) -> &mut Self::Target { &mut self.0 }
}
impl<T> IntoIterator for FallibleVec<T> {
    type Item = T;
    type IntoIter = std::vec::IntoIter<T>;
    fn into_iter(self) -> Self::IntoIter { self.0.into_iter() }
}
impl<'a, T> IntoIterator for &'a FallibleVec<T> {
    type Item = &'a T;
    type IntoIter = std::slice::Iter<'a, T>;
    fn into_iter(self) -> Self::IntoIter { self.0.iter() }
}
impl<'a, T> IntoIterator for &'a mut FallibleVec<T> {
    type Item = &'a mut T;
    type IntoIter = std::slice::IterMut<'a, T>;
    fn into_iter(self) -> Self::IntoIter { self.0.iter_mut() }
}
pub mod capture {
    use std::sync::Mutex;
    static LOG: Mutex<Vec<String>> = Mutex::new(Vec::new());
    pub fn emit(arguments: std::fmt::Arguments<'_>) {
        let rendered = arguments.to_string();
        LOG.lock().unwrap().push(rendered);
    }
    pub fn cursor() -> usize { LOG.lock().unwrap().len() }
    pub fn interval(start: usize) -> Vec<String> {
        LOG.lock().unwrap()[start..].to_vec()
    }
}
#[macro_export]
macro_rules! pr_info {
    ($($arg:tt)*) => { $crate::capture::emit(format_args!($($arg)*)) };
}
pub mod bindings {
    pub unsafe fn ktime_get() -> i64 {
        static START: std::sync::OnceLock<std::time::Instant> = std::sync::OnceLock::new();
        let elapsed = START.get_or_init(std::time::Instant::now).elapsed().as_nanos();
        i64::try_from(elapsed).unwrap().checked_add(1).unwrap()
    }
}
#[path = "source/application_rpc.rs"] mod application_rpc;
#[path = "source/application_syscall.rs"] mod application_syscall;
#[path = "source/smp_application_syscall.rs"] mod smp_application_syscall;
#[path = "source/stability_observer.rs"] mod stability_observer;
#[path = "source/stability_phase.rs"] mod stability_phase;
#[path = "adapter.rs"] mod adapter;
