import pathlib,json,hashlib,shutil,struct,stat,tarfile
base=pathlib.Path(__file__).resolve().parent; repo=pathlib.Path('/home/holden/mckernel');scratch=pathlib.Path('/home/holden/mckernel-work/scratch');attempt=scratch/'stability-published-client-tests-20260913-1';frozen=pathlib.Path('/tmp/stability-published-client-independent-review-20260913-9b9tj8f5/final-source')
def sha(b):return hashlib.sha256(b).hexdigest()
def mapped(p):
 if p.startswith('/work/'):return scratch/p[6:]
 if p.startswith('/workspace/'):return repo/p[11:]
 return None
checked=[];unmapped=[]
def ident(r):
 p=mapped(r['path'])
 if p is None:unmapped.append(r);return
 assert stat.S_ISREG(p.lstat().st_mode)
 b=p.read_bytes();assert len(b)==r['size'] and sha(b)==r['sha256'],str(p)
 checked.append(r)
r=json.loads((attempt/'record.json').read_bytes());expect=json.loads((attempt/'metadata-expectations.json').read_bytes())
assert r['status']=='PASS_PUBLISHED_CONTROLLER_BUILD_AND_CLIENT_METADATA_ONLY'
assert r['passed_cases']==len(r['cases'])==expect['case_count']==81
for name in ['application_acceptance','guest_execution','observe_return_state_machine_tested','production_gate_credit','transport_acceptance']:assert r[name] is False
for row in r['inputs']+r['compiler_dependencies']:
 assert row['original']['sha256']==row['retained']['sha256'] and row['original']['size']==row['retained']['size']
 ident(row['original']);ident(row['retained'])
for row in r['inputs']:
 name=pathlib.Path(row['retained']['path']).name
 if name!='supervisor.py':assert (attempt/name).read_bytes()==(frozen/name).read_bytes(),name
for row in r['compiled_outputs']+r['loader_dependencies']:ident(row)
for name in ['controller.elf','metadata-harness.elf']:
 b=(attempt/name).read_bytes();assert b[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',b,18)[0]==62
for command in r['commands']:
 c=command['collection'];p=attempt/(command['label']+'-collection')
 assert json.loads((p/'report.json').read_bytes())==c
 assert c['status']=='COMPLETED' and c['raw_wait_status']==0 and c['wait_status']=={'kind':'exited','code':0}
 assert c['cleanup_complete'] is True and c['descendant_records_omitted']==0
 assert c['payload_completion_observed_monotonic']<c['payload_monotonic_deadline']
 assert c['argv']==command['argv'] and c['env']==command['environment']
 for stream in c['streams'].values():
  ident(stream['artifact']);assert stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes']==0
  assert stream['bytes_observed']==stream['bytes_retained']==stream['artifact']['size']
 ident(c['executable']);assert (p/'worker.stderr').read_bytes()==b''
assert len(r['commands'])==11
assert r['commands'][-1]['collection']['executable']['sha256']==sha((attempt/'metadata-harness.elf').read_bytes())

def u64(b,o):return struct.unpack_from('<Q',b,o)[0]
def u32(b,o):return struct.unpack_from('<I',b,o)[0]
def i32(b,o):return struct.unpack_from('<i',b,o)[0]
def boolean(b,o):
 assert b[o] in (0,1)
 return bool(b[o])
def decode_identity(b):
 assert len(b)==216
 d={'os':u32(b,0),'pid':i32(b,4),'attempt':u32(b,40),'mode':u32(b,48),'key_hex':b[136:216].hex(),'capture_digest_hex':b[104:136].hex()}
 for name,o in [('generation',8),('nonce_low',16),('nonce_high',24),('sequence',32),('last_snapshot',56),('timer_seconds',64),('held_ns',72),('terminal_ns',80),('barrier_calls',88),('host_hold_calls',96)]:d[name]=u64(b,o)
 for name,o in [('selected',44),('held',45),('released',46),('release_possible',47)]:d[name]=boolean(b,o)
 return d

def decode_observation(b):
 assert len(b)==304
 d={'reply_hex':b[:256].hex(),'begin_ns':u64(b,288),'end_ns':u64(b,296)}
 for name,o in [('open_result',256),('open_errno',260),('ioctl_result',264),('ioctl_errno',268),('raw_wait',272)]:d[name]=i32(b,o)
 for name,o in [('ioctl_called',276),('response_received',277),('reaped',278),('timed_out',279),('consumed',280)]:d[name]=boolean(b,o)
 return d
names=set();summaries=[];stdout=b''
for wanted,case in zip(expect['cases'],r['cases']):
 assert case['expected']==wanted
 name=wanted['name'];p=attempt/'cases';assert name not in names;names.add(name)
 actual=json.loads((p/(name+'.result.json')).read_bytes());assert actual==case['observed']
 assert actual['status']=='PASS' and actual['actual_result']==actual['expected_result']==wanted['expected_result']
 assert actual['consumed']==actual['expected_consumed']==wanted['expected_consumed'] and actual['identity_matches'] is True
 assert actual['actual_ioctl_executed'] is actual['application_acceptance'] is actual['transport_acceptance'] is False
 assert (p/(name+'.request.bin')).read_bytes()==bytes.fromhex(wanted['request_hex'])
 assert (p/(name+'.reply.bin')).read_bytes()==bytes.fromhex(wanted['reply_hex'])
 identity=decode_identity((p/(name+'.identity.bin')).read_bytes());expected_identity=dict(wanted['expected_after']);expected_identity['attempt']=0;assert identity==expected_identity,name
 observation=decode_observation((p/(name+'.observation.bin')).read_bytes());expected_observation=dict(wanted['collection'],reply_hex=wanted['reply_hex'],consumed=wanted['expected_consumed']);assert observation==expected_observation,name
 for item in case['artifacts']:ident(item)
 summaries.append({'name':name,'complete_actual_identity':identity,'complete_actual_observation':observation,'expected_result':wanted['expected_result']})
 stdout+=('PUBLISHED_CLIENT_METADATA '+name+' PASS\n').encode()
assert {p.name for p in (attempt/'cases').iterdir()}=={n+suffix for n in names for suffix in ['.request.bin','.reply.bin','.identity.bin','.observation.bin','.result.json']}
assert (attempt/'metadata81-collection/stdout.bin').read_bytes()==stdout
assert (attempt/'metadata81-collection/stderr.bin').read_bytes()==b''

def inventory(root):
 rows=[]
 for p in [root]+sorted(root.rglob('*')):
  s=p.lstat();v={'path':'.' if p==root else p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISDIR(s.st_mode):v['type']='directory'
  else:
   assert stat.S_ISREG(s.st_mode),str(p)
   b=p.read_bytes();v.update(type='file',size=len(b),sha256=sha(b))
  rows.append(v)
 return rows
before=inventory(attempt);shutil.copytree(attempt,base/'actual-attempt',copy_function=shutil.copy2);assert inventory(attempt)==inventory(base/'actual-attempt')==before
source_review=pathlib.Path('/tmp/stability-published-client-independent-review-20260913-9b9tj8f5/review-final.json');shutil.copy2(source_review,base/'prior-source-review.json');assert sha((base/'prior-source-review.json').read_bytes())=='2632cf471801d9df7b6ef6b646f2ab80064a65faaa6074cf8fe842ad33247ee8'
review={'schema_version':1,'status':'PASS_RETAINED_CONTROLLER_BUILD_AND_ACTUAL_C_METADATA_RESULTS_ONLY','actual_record':{'path':str(attempt/'record.json'),'size':(attempt/'record.json').stat().st_size,'sha256':sha((attempt/'record.json').read_bytes())},'prior_source_review_sha256':sha(source_review.read_bytes()),'mapped_identities_rehashed':len(checked),'retained_compiler_inputs_rehashed':len(r['compiler_dependencies']),'unmapped_original_container_references_not_freshly_rehashed':unmapped,'case_count':81,'case_artifacts':405,'completed_command_count':11,'compiled_outputs':r['compiled_outputs'],'checks':['Exact final reviewed controller/header/harness/vector source bytes bind retained compiler copies and outputs. Both retained ELF files are actual little-endian ELF64 x86-64; controller built but never invoked.','All11 command reports and exact recorded stream hashes/EOF/no loss/raw waits/deadline observations/owned cleanup match retained captures.','All81 independent requests/replies and expected results/consumption match. Complete actual216-byte identity and304-byte observation structs independently decoded from source-bound native x86-64 C layouts and match every expected field. Padding is ignored, not a predicate.','Exact full stdout, empty stderr, rawwait0,81cases/405files and no missing/additional case artifacts verified.','All original attempt file bytes/types/modes/membership preserved in review copy. No test/compiler/controller/ioctl/guest run or subject import by reviewer.'],'decoded_actual_cases':summaries,'scope_limits':['Retained compiler input copies are rehashed; original unmapped container tools/headers/loader paths were not opened in a new container in this lane. No universal compiler/toolchain trust claim.','Metadata validation and standalone controller build only; no actual client child/ioctl or controller state-machine run, STF2 host/PTY/QMP integration, live owner/physical fault or application acceptance.','Original permanent fault polling defect remains preserved and is not repaired by these new source/results. Actual native RET is still required.'],'new_tests_executed_by_reviewer':False,'new_compilers_executed_by_reviewer':False,'guest_execution':False,'actual_ioctl_executed':False,'controller_main_executed':False,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False}
(base/'review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
entries=inventory(base);archive=repo/'docs/verification/evidence/stability-published-client-results-independent-review-20260913.tar.gz';pub=repo/'docs/verification/stability-published-client-results-independent-review-20260913.json';assert not archive.exists() and not pub.exists()
with tarfile.open(archive,'x:gz') as t:
 for row in entries:
  p=base if row['path']=='.' else base/row['path'];name=base.name if row['path']=='.' else base.name+'/'+row['path'];t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(entries)==len({m.name for m in members})
 for row,m in zip(entries,members):
  name=base.name if row['path']=='.' else base.name+'/'+row['path'];assert m.name==name and m.mode==row['mode']
  if row['type']=='directory':assert m.isdir()
  else:assert m.isfile() and m.size==row['size'] and sha(t.extractfile(m).read())==row['sha256']
assert inventory(base)==entries
summary={'schema_version':1,'status':review['status'],'review_sha256':sha((base/'review.json').read_bytes()),'archive':{'path':str(archive.relative_to(repo)),'size':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':len(entries),'all_bytes_types_modes_membership_verified':True},'members':entries,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False,'actual_ioctl_executed':False,'controller_main_executed':False,'guest_execution':False}
pub.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');print(json.dumps({'publication':str(pub),'sha256':sha(pub.read_bytes()),'archive':summary['archive'],'review_sha256':summary['review_sha256'],'mapped_identities':len(checked),'unmapped_original_container_references':len(unmapped)},indent=2))
