from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shlex, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-published-client-tests-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
              commands=[], inputs=[], compiler_dependencies=[], compiled_outputs=[], cases=[],
              application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
              guest_execution=False, observe_return_state_machine_tested=False, scope='Build exact published controller and actual C client metadata81; no actual ioctl/controller/guest execution or application acceptance')
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    source = repo / 'scripts/tests/fixtures/stability-transport-fault/owner-published-hold-v1'
    required = {
        'metadata_harness.c': '42fd6e18c86cde6bf63326d301128e4ba20f061cbd23341b467d5c29ecb49bcc',
        'controller.c': 'b8360dc502d53ee537e462815657d85510488a1820c10501c38cb49150b52d3c',
        'phase_client.h': '929f9fd03793f6006056219bc6d75451ed9c2e6a856a938997bbf8663b8a6e6d',
    }
    for name in (*required, 'metadata-expectations.json', 'metadata_vectors.h', 'README.md', 'controller.c.original', 'controller.c.forward.patch', 'controller.c.inverse.patch', 'phase_client.h.original', 'phase_client.h.forward.patch', 'phase_client.h.inverse.patch', 'metadata-tests.md', 'metadata-vector-generator.py', 'metadata-vector-generator.original.py'):
        src, dst = source / name, out / name
        if name in required: assert identity(src)['sha256'] == required[name]
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    src = repo / 'scripts/application-tests/supervisor.py'
    assert identity(src)['sha256'] == '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
    shutil.copyfile(src, out / 'supervisor.py')
    record['inputs'].append(dict(original=identity(src), retained=identity(out / 'supervisor.py')))
    spec = importlib.util.spec_from_file_location('terminal_supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    def run(label, argv, timeout=120, cap=8*1024**2):
        if not Path(argv[0]).is_absolute(): argv[0] = shutil.which(argv[0], path=env['PATH'])
        record['phase'] = label; save(); print('RUN', label, flush=True)
        result = supervisor.run_supervised(argv, cwd=str(out), env=env,
            attempt_dir=str(out / (label + '-collection')), timeout_seconds=timeout,
            cleanup_timeout_seconds=15, stdout_limit_bytes=cap, stderr_limit_bytes=cap)
        record['commands'].append(dict(label=label, argv=argv, environment=env, collection=result)); save()
        assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete'], (label, result)
        return (out / (label + '-collection') / 'stdout.bin').read_text()
    run('compiler-version', ['gcc', '--version'])
    obj, elf, deps, linkmap = [out / ('metadata-harness' + suffix) for suffix in ('.o', '.elf', '.d', '.map')]
    run('compile', ['gcc', '-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
        '-fno-pie', '-pthread', '-MD', '-MF', str(deps), '-I', str(repo / 'executer/include'),
        '-c', str(out / 'metadata_harness.c'), '-o', str(obj)])
    run('link', ['gcc', '-no-pie', '-pthread', str(obj), '-Wl,-Map=' + str(linkmap), '-o', str(elf)])
    run('elf', ['readelf', '-h', '-l', '-d', str(elf)])
    data = run('loader-trace', ['ldd', str(elf)])
    for line in data.splitlines():
        for part in line.split():
            if part.startswith('/') and Path(part).is_file(): record.setdefault('loader_dependencies', []).append(identity(Path(part)))
    controller_obj, controller_elf, controller_deps, controller_map = [out / ('controller' + suffix) for suffix in ('.o', '.elf', '.d', '.map')]
    run('compile-controller', ['gcc', '-std=c11', '-D_GNU_SOURCE', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
        '-fno-pie', '-pthread', '-MD', '-MF', str(controller_deps), '-I', str(repo / 'executer/include'),
        '-c', str(out / 'controller.c'), '-o', str(controller_obj)])
    run('link-controller', ['gcc', '-no-pie', '-pthread', str(controller_obj), '-Wl,-Map=' + str(controller_map), '-o', str(controller_elf)])
    run('elf-controller', ['readelf', '-h', '-l', '-d', str(controller_elf)])
    controller_loaders = run('loader-controller', ['ldd', str(controller_elf)])
    for line in controller_loaders.splitlines():
        for part in line.split():
            if part.startswith('/') and Path(part).is_file(): record['loader_dependencies'].append(identity(Path(part)))
    dependency_text = deps.read_text().split(':', 1)[1] + ' ' + controller_deps.read_text().split(':', 1)[1]
    for item in shlex.split(dependency_text.replace('\\\n', ' ')):
        src = Path(item)
        if not src.is_absolute(): src = out / src
        row = identity(src)
        if any(old['original'] == row for old in record['compiler_dependencies']): continue
        dst = out / 'compiler-inputs' / str(src).lstrip('/')
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(src, dst)
        record['compiler_dependencies'].append(dict(original=row, retained=identity(dst)))
    record['compiled_outputs'] = [identity(p) for p in (obj, elf, deps, linkmap, controller_obj, controller_elf, controller_deps, controller_map)]
    run('disassembly', ['objdump', '-d', str(elf)])
    expectations = json.loads((out / 'metadata-expectations.json').read_text())
    assert expectations['case_count'] == len(expectations['cases']) == 81
    assert identity(out / 'metadata-expectations.json')['sha256'] == '3f41c909eecefdf49ddeb6e6d2dedb06028e4c686dd98843cc2a3f35374a1101'
    assert identity(out / 'metadata_vectors.h')['sha256'] == 'e4f2e49cc885771696d7aab844566b2364bea72854b5d058258590170d07b381'
    run('metadata81', [str(elf), str(out / 'cases')], timeout=10, cap=65536)
    expected_stdout = ''.join('PUBLISHED_CLIENT_METADATA ' + row['name'] + ' PASS\n' for row in expectations['cases']).encode()
    assert (out / 'metadata81-collection/stdout.bin').read_bytes() == expected_stdout
    assert (out / 'metadata81-collection/stderr.bin').read_bytes() == b''
    expected_files = {case['name'] + suffix for case in expectations['cases'] for suffix in ('.request.bin', '.reply.bin', '.identity.bin', '.observation.bin', '.result.json')}
    assert {p.name for p in (out / 'cases').iterdir()} == expected_files
    for expected in expectations['cases']:
        name = expected['name']; path = out / 'cases' / (name + '.result.json')
        observed = json.loads(path.read_text())
        assert observed['case'] == name and observed['status'] == 'PASS'
        assert observed['actual_result'] == observed['expected_result'] == expected['expected_result']
        assert observed['consumed'] is observed['expected_consumed'] is expected['expected_consumed']
        assert observed['identity_matches'] is True and observed['actual_ioctl_executed'] is False
        assert observed['application_acceptance'] is observed['transport_acceptance'] is False
        for field in ('sequence','selected','held','release_possible','released'):
            assert observed[field] == expected['expected_after'][field]
        retained = []
        for suffix in ('.request.bin', '.reply.bin', '.identity.bin', '.observation.bin', '.result.json'):
            captured = out / 'cases' / (name + suffix)
            retained.append(identity(captured))
            if suffix in ('.request.bin', '.reply.bin'):
                assert captured.read_bytes() == bytes.fromhex(expected[suffix[1:].split('.')[0] + '_hex'])
            else: assert captured.stat().st_size > 0
        record['cases'].append(dict(expected=expected, observed=observed, artifacts=retained)); save()
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    for row in record['compiled_outputs'] + record['loader_dependencies']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS_PUBLISHED_CONTROLLER_BUILD_AND_CLIENT_METADATA_ONLY', passed_cases=81)
except BaseException as error:
    record.update(status='FAIL', error_type=type(error).__name__, error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save(); print(record['status'], out, flush=True)
