"""Standard-library bookkeeping only: preserve source-bound prototype evidence."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,tarfile
repo=Path('/home/holden/mckernel');scratch=Path('/home/holden/mckernel-work/scratch');root=repo/'docs/verification';evidence=root/'evidence';rows=[]
def digest(b): return hashlib.sha256(b).hexdigest()
def keep(name,b):
 target=evidence/('native-os-resource-20260907-'+name);data=gzip.compress(b,mtime=0) if name.endswith('.gz') else b
 if target.exists(): raise RuntimeError('Refuse overwrite '+str(target))
 target.write_bytes(data);rows.append(dict(path=str(target.relative_to(repo)),size=len(data),sha256=digest(data),uncompressed_size=len(b),uncompressed_sha256=digest(b)))
def file(name,path): keep(name,path.read_bytes())
def archive(name,entries):
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w') as output:
  for rel,path in sorted(entries):
   if path.is_symlink() or not path.is_file(): raise RuntimeError('Unsafe archive input '+str(path))
   data=path.read_bytes();item=tarfile.TarInfo(rel);item.size=len(data);item.mode=0o644;item.mtime=0;output.addfile(item,io.BytesIO(data))
 keep(name,buffer.getvalue())
for label,directory in [('policy-first-failure','native-os-resource-policy-20260907-attempt1'),('policy-batch-pass','native-os-resource-policy-20260907'),('backend-first-pass','native-os-backend-tests-20260907-attempt1-pass'),('backend-state-pass','native-os-backend-tests-20260907'),('adapter-tests-pass','native-os-resource-adapter-tests-20260907')]:
 base=scratch/directory
 for name in ['record.json','tests.log']: file(label+'-'+name+'.gz',base/name)
 entries=[]
 for group in ['host-kernel/native-rust','scripts/tests']:
  entries.extend((str(path.relative_to(base)),path) for path in (base/group).rglob('*') if path.is_file())
 archive(label+'-source.tar.gz',entries)
for label,directory in [('backend-build','native-os-backend-prototype-20260907'),('assignment-build','native-os-resource-prototype-20260907')]:
 base=scratch/directory;r=json.loads((base/'record.json').read_text());assert r['status']=='PASS'
 for name in ['record.json','module-build.log','module-build.command','build-helper.py','ihk-defined-symbols.txt']: file(label+'-'+name+'.gz',base/name)
 entries=[(str(path.relative_to(base)),path) for path in (base/'staged-source').rglob('*') if path.is_file()]
 entries.extend((str(path.relative_to(base)),path) for path in (base/'module-build').iterdir() if path.name.endswith(('.cmd','.mod','.mod.c')))
 for name in ['Module.symvers','bindings_generated.rs','.config']: entries.append((name,base/name))
 archive(label+'-source-compiler.tar.gz',entries)
 if label=='assignment-build':
  for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']: file(label+'-'+name+'.gz',base/name)
for label,directory in [('guest1','native-runtime-os-resource-prototype-20260907'),('guest2','native-runtime-os-resource-prototype2-20260907')]:
 base=scratch/directory;r=json.loads((base/'local-run.json').read_text());assert r['status']=='technical-capture-passed' and r['qemu_exit_code']==0 and not r['missing_markers'] and not r['error_markers']
 for name in ['local-run.json','serial.log','qemu.log','probe-build.log','run-helper.py']: file(label+'-'+name+'.gz',base/name)
 entries=[(str(path.relative_to(base)),path) for path in (base/'probe-source').rglob('*') if path.is_file()]
 for name in ['root/init','root/bin/native-memory-x86_64','root/bin/native-memory-i386','root/bin/mcd0-ioctl-x86_64','root/bin/mcd0-ioctl-i386']: entries.append((name,base/name))
 archive(label+'-probes.tar.gz',entries)
for name in ['run-native-os-resource-policy.py','run-native-os-backend-tests.py','run-native-os-resource-adapter-tests.py','check-native-os-resource-modules.py','native-os-resource-module-checks-20260907.json','retain-native-os-resource-evidence.py']:
 file(name+'.gz',scratch/name)
compiled=json.loads((scratch/'native-os-resource-prototype-20260907/record.json').read_text());guest=json.loads((scratch/'native-runtime-os-resource-prototype2-20260907/local-run.json').read_text())
record=dict(schema_version=1,kind='native-os-resource-assignment-prototype',recorded_utc=datetime.now(timezone.utc).isoformat(),source_parent=compiled['source_parent'],scope='prototype source overlay plus isolated four-vCPU/two-NUMA guest; current staging and authority bindings pending',production_gate_credit=False,full_repository_suite_run=False,native_mckernel_boot_proven=False,complete_rust_unification_claimed=False,policy_tests=51,adapter_mock_tests=47,python_tests=11,independent_page_model_cases=65536,build_outputs=compiled['outputs'],compiled_overlay=compiled['overlay'],guest={key:guest[key] for key in ['status','started_utc','finished_utc','cpus','numa_nodes','memory_mib','qemu_exit_code','missing_markers','error_markers','memory_assignment_proven','cpu_assignment_proven','staging_lock_refreshed']},artifacts=rows,remaining=['current staging/lifecycle/FFI and verification identity integration','fresh exact-stage module build, guest and repository suite','image loading, AP startup, IKC and basic workloads','McKernel Rust/assembly-only completion and production acceptance'])
(root/'native-os-resource-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained OS resource artifacts:',len(rows))
