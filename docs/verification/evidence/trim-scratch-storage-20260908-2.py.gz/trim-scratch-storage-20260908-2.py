"""Return unused blocks from the existing scratch image to the host drive."""
from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
import subprocess

scratch = Path('/home/holden/mckernel-work/scratch')
backing = scratch.parent / 'scratch.ext4'
report = scratch / 'storage-scratch-trim-20260908-2.json'
assert not report.exists()
assert scratch.is_mount()


def state():
    value = backing.stat()
    return dict(backing_logical_bytes=value.st_size,
                backing_allocated_bytes=value.st_blocks * 512,
                root_available_bytes=shutil.disk_usage('/').free,
                scratch_available_bytes=shutil.disk_usage(scratch).free)


before = state()
assert before['backing_logical_bytes'] == 60 * 1024**3
command = ['sudo', '-p', '[sudo] password: ', '/usr/sbin/fstrim', '-v', str(scratch)]
result = subprocess.run(command, capture_output=True, text=True)
after = state()
value = dict(finished_utc=datetime.now(timezone.utc).isoformat(),
             command=command, exit_code=result.returncode,
             stdout=result.stdout, stderr=result.stderr, before=before, after=after,
             reclaimed_backing_allocated_bytes=before['backing_allocated_bytes'] - after['backing_allocated_bytes'],
             status='PASS' if result.returncode == 0 else 'FAIL')
report.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
print(json.dumps(value, sort_keys=True), flush=True)
assert result.returncode == 0
assert scratch.is_mount() and before['backing_logical_bytes'] == after['backing_logical_bytes']
