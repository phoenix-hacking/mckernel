from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, base = Path('/workspace'), Path('/work')
out = base / ('native-topology-retained-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[], production_gate_credit=False,
    declared_stage=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    applications_tested=False, native_cpu_context_integrated=False)

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): value.update(chunk)
    return value.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def checked(row):
    assert identity(Path(row['path'])) == row, row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target); row.update(path='docs/verification/evidence/' + name,
        source=str(source), unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

try:
    shutil.copyfile(__file__, out / 'helper.py')
    captures = [('native-topology-kernel-20260907-1', 'PASS'),
                ('native-topology-module-20260907-1', 'PASS'),
                ('native-topology-guest-20260907-1', 'FAIL'),
                ('native-topology-guest-20260907-2', 'FAIL'),
                ('native-topology-guest-20260907-3', 'PASS')]
    for name, status in captures:
        source = base / name
        captured = json.loads((source / 'record.json').read_text())
        assert captured['status'] == status, (name, captured['status'])
        for field in ('inputs', 'outputs', 'compiler_inputs'):
            for row in captured.get(field, []): checked(row)
        archive = out / (name + '.tar.gz')
        with tarfile.open(archive, 'w:gz') as tar: tar.add(source, arcname=name)
        assert archive.stat().st_size < 95 << 20, name
        row = identity(archive); row.update(path='docs/verification/evidence/' + archive.name, source=str(source))
        record['artifacts'].append(row)
        retain_gzip(source / 'record.json', name + '-record.json.gz')
        if (source / 'serial.log').exists(): retain_gzip(source / 'serial.log', name + '-serial.log.gz')
        record['captures'].append(dict(directory=name, status=status,
            source_parent=captured['source_parent'], started_utc=captured['started_utc'],
            finished_utc=captured['finished_utc'], qemu_exit_code=captured.get('qemu_exit_code'),
            recovered_final_record=captured.get('recovered_final_record', False)))
        print('Retained', name, status, flush=True)
    kernel = base / captures[0][0]; module = base / captures[1][0]; guest = base / captures[-1][0]
    km = json.loads((kernel / 'record.json').read_text())
    mm = json.loads((module / 'record.json').read_text())
    gm = json.loads((guest / 'record.json').read_text())
    for row in mm['compiler_inputs']:
        saved = Path(row['path']); relative = saved.relative_to(module / 'source')
        current = repo / relative
        assert current.read_bytes() == saved.read_bytes(), str(relative)
        bound = identity(saved); bound.update(path=str(relative), compiler_capture=str(saved), binding='identical')
        record['compiler_inputs'].append(bound)
    for name, saved in [('host-kernel/kbuild/patches/0009-cacheinfo-export-existing-topology-accessor.patch', kernel / '0009-cacheinfo-export-existing-topology-accessor.patch'),
                        ('scripts/tests/fixtures/native_topology_layout.c', kernel / 'witness/native_topology_layout.c')]:
        assert (repo / name).read_bytes() == saved.read_bytes(), name
        bound = identity(saved); bound.update(path=name, compiler_capture=str(saved), binding='identical')
        record['compiler_inputs'].append(bound)
    assert km['normal_c_preprocessing_unchanged']
    assert (kernel / 'before-bindings_generated.rs').read_bytes() == (kernel / 'bindings_generated.rs').read_bytes()
    assert km['c_layout'] == mm['layout'] and len(mm['layout']) == 45
    assert gm['module_cycles'] == 2 and gm['snapshot_cpus'] == 4
    assert gm['snapshot_reads'] == 24 and gm['scalar_checks'] == 376 and gm['cache_leaf_checks'] == 32
    assert gm['cpu_offline_online_cycles'] == 2 and gm['snapshots_unchanged_across_offline'] and gm['namespace_removed']
    assert gm['observed_linux_core_mask_changes'] == 2
    assert gm['observed_linux_cache_mask_changes'] == 0
    serial = (guest / 'serial.log').read_text()
    for bad in ['Call Trace:', 'BUG:', 'Oops:', 'WARNING:', 'Kernel panic', 'GUEST_FAIL', 'rcu_preempt detected stalls']:
        assert bad not in serial, bad
    for name in ['build-native-topology-kernel.py', 'build-native-topology-module.py',
                 'run-native-topology-guest.py', 'retain-native-topology.py']:
        retain_gzip(base / name, 'native-topology-20260907-' + name + '.gz')
    for name in ['native-sysfs-tree-checkpoint-20260907.json', 'native-vdso-exports-checkpoint-20260907.json']:
        row = identity(repo / 'docs/verification' / name); row['path'] = str(Path(row['path']).relative_to(repo))
        record['references'].append(row)
    for row in record['artifacts']:
        value = hashlib.sha256(); size = 0
        with gzip.open(out / Path(row['path']).name, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                value.update(chunk); size += len(chunk)
        if 'unpacked_size' in row:
            assert size == row['unpacked_size'] and value.hexdigest() == row['unpacked_sha256'], row
    subprocess.run(['git', '-C', str(repo), 'diff', '--check'], check=True)
    record.update(status='PASS', linux_layout=mm['layout'], module_cycles=2,
        snapshot_cpus=4, snapshot_reads=24, scalar_checks=376, cache_leaf_checks=32,
        cpu_offline_online_cycles=2, observed_linux_core_mask_changes=2,
        observed_linux_cache_mask_changes=0,
        passed=[
            'Pinned Linux rebuild and the existing three native modules pass with only the existing cacheinfo accessor newly exported; topology C declarations and generated Rust bindings remain unchanged',
            'The actual Rust snapshot producer and disposable module compile, all 45 independently compiled C/Rust layout values agree, required Linux imports are present and no SIMD/FPU registers occur in module disassembly',
            'Two real Linux module lifetimes capture all four CPUs and their cache leaves into owned Rust values; 376 field/mask checks and 32 cache-leaf checks agree with independent procfs/sysfs values',
            'All 24 snapshot reads remain byte-identical before CPU1 offline, while offline and after online; Linux removes that CPU cache namespace and changes CPU0 core-sibling membership, while module removal retires the snapshot namespace',
            'Raw Linux cache masks are observed unchanged in this QEMU configuration and agree with its level/type/valid-ID sharing predicate; no fabricated shared topology replaces those values',
            'Source bytes bind to exact compiler captures, all hashes and full gzip streams verify, both initial guest failures and the recovered failed recorder state are retained'],
        limitations=[
            'The producer is consumed by the disposable fixture. Native CpuContext lifetime integration, reservation-time identity checks and use by the real sysfs setup sequence remain pending',
            'The unsafe capture boundary requires CPU hotplug exclusion and copies only online CPUs within the existing 512-CPU limit and at most 64 cache leaves; allocation failures and all hardware/hotplug variants are not covered here',
            'Snapshot validation must compare online membership without assuming cache IDs can reconstruct masks; this TCG model reports distinct valid L3 IDs for CPUs whose raw shared mask includes both',
            'Actual SYSFS_REQ_SETUP, continuing host dispatch, applications, shutdown, full Rust/assembly ownership, declared integration and independent production acceptance remain open; this new kernel has only the topology fixture guest coverage so far'])
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (out / 'native-topology-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], 'retained', len(record['artifacts']), 'topology artifacts', flush=True)
