from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-zeroing-patch-contract-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Frozen configuration replay and additive current-patch/license inventory regressions after exact swap_remove noreturn patch registration',inputs=[],commands=[])
def identity(path):return dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['scripts/rocky_kernel_config_resolution_v2.py','scripts/rocky_kernel_license_inventory.py','scripts/tests/test_rocky_kernel_config_resolution.py','scripts/tests/test_rocky_kernel_license_inventory.py','host-kernel/rocky/patches/0025-objtool-recognize-rust-1.92-vec-swap-remove-panic.patch']
    for name in names:
        target=out/'original-inputs'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target);record['inputs'].append(identity(target))
    commands=[['git','-C',str(repo),'diff','--check'],['python3','-B','-m','unittest','scripts.tests.test_rocky_kernel_config_resolution','scripts.tests.test_rocky_kernel_license_inventory','-v','-f']]
    for index,args in enumerate(commands):
        print('RUN',index,flush=True)
        with (out/(str(index)+'.log')).open('wb') as log: result=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append(dict(command=args,exit_code=result.returncode));assert result.returncode==0,(args,(out/(str(index)+'.log')).read_text()[-6000:])
    for row in record['inputs']:assert identity(Path(row['path']))==row
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name!='record.json'];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
