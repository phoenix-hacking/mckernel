"""Exercise the complete selected Rust guest procfs with controlled effects."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-procfs-lifetime-20260908-'+sys.argv[1]);out.mkdir()
source=out/'source';fixture=source/'scripts/tests/fixtures'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],extracted_bodies=[],production_gate_credit=False,mckernel_application_executed=False,scope='Full selected guest Rust procfs and object helpers with actual ABI and controlled external effects; no live procfs service or application execution')
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def run(label,args,env=None):
 print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
 with (out/(label+'.log')).open('wb') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
 assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-14000:])
def extract(path,pattern,name,prefix=''):
 data=path.read_text();match=re.search(pattern,data,re.M);assert match,name
 start=match.start();opening=data.index('{',start);end=opening+1;depth=1
 while depth:depth+=(data[end]=='{')-(data[end]=='}');end+=1
 body=data[start:end];record['extracted_bodies'].append(dict(source=str(path.relative_to(source)),name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
 return prefix+body+'\n'
try:
 shutil.copyfile(__file__,out/'helper.py')
 names=['kernel/rust/procfs.rs','kernel/rust/object_helpers.rs','kernel/rust/page_helpers.rs','kernel/rust/abi.rs','kernel/rust/lock_helpers.rs','kernel/rust/cls.rs','kernel/rust/lib.rs','kernel/CMakeLists.txt','kernel/procfs.c','kernel/cls.c','scripts/tests/fixtures/native-procfs-lifetime.rs']
 for name in names:
  for base in [out/'original-inputs',source]:
   saved=base/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,saved)
 record['inputs']=[identity(out/'original-inputs'/name) for name in names]
 shutil.copyfile(source/'kernel/rust/procfs.rs',fixture/'native-procfs-production.rs')
 (fixture/'native-procfs-lock-type.rs').write_text('use crate::abi::CULong;\n'+extract(source/'kernel/rust/lock_helpers.rs',r'^pub struct McsRwlockNodeIrqsave \{','McsRwlockNodeIrqsave','#[repr(C,align(64))]\n'))
 production=(source/'kernel/rust/procfs.rs').read_text();ftext=(fixture/'native-procfs-lifetime.rs').read_text()
 extern=production[production.index('unsafe extern "C" {'):production.index('\n#[inline(always)]')]
 stubs=[]
 for match in re.finditer(r'    fn (\w+)\s*\((.*?)\)(\s*->\s*[^;]+)?;',extern,re.S):
  name,args,result=match.groups();result=result or ''
  if name in ('kprintf','sscanf','strchr') or re.search(r'fn '+name+r'\s*\(',ftext):continue
  stubs.append('#[allow(unused_variables)]\n#[no_mangle]\npub unsafe extern "C" fn '+name+'('+args+')'+result+' { panic!("unexpected external effect: '+name+'"); }\n')
 (fixture/'native-procfs-unused-effects.rs').write_text(''.join(stubs));record['unexercised_effect_stubs']=[re.search(r'fn (\w+)',s)[1] for s in stubs]
 (fixture/'native-procfs-variadic.c').write_text('int kprintf(const char *format, ...) { (void)format; return 0; }\n')
 cbacklog=extract(source/'kernel/procfs.c',r'^static int do_procfs_backlog\(void \*arg\)\n\{','do_procfs_backlog')
 ctest='''#include <stdio.h>
#include <assert.h>
struct ikc_scd_packet { int unused; };
static int status, retry, freed;
static int _process_procfs_request(struct ikc_scd_packet *p, int *result) { (void)p; *result=retry; return status; }
static void kfree_tracked(void *p, const char *file, int line) { (void)p; (void)file; (void)line; ++freed; }
'''+cbacklog+'''int main(void) { struct ikc_scd_packet p; for (retry=0;retry<=1;++retry) for (status=-12;status<=0;status+=6) { freed=0; int result=do_procfs_backlog(&p); assert(result==retry && freed==!retry); printf("BACKLOG status=%d retry=%d returned=%d freed=%d\\n",status,retry,result,freed); } return 0; }
'''
 (fixture/'native-procfs-c-backlog.c').write_text(ctest)
 run('diff-check',['git','-C',str(repo),'diff','--check'])
 run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(fixture/'native-procfs-lifetime.rs')])
 run('c-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror',str(fixture/'native-procfs-c-backlog.c'),'-o',str(out/'c-backlog')])
 run('c-backlog',[str(out/'c-backlog')])
 run('variadic-build',['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-c',str(fixture/'native-procfs-variadic.c'),'-o',str(out/'variadic.o')])
 environment=dict(os.environ,MCKERNEL_RUST_VERSION='lifetime-fixture',MCKERNEL_RUST_BUILDID=record['source_parent'])
 run('rust-build',['rustc','--edition','2021','-D','warnings','--test',str(fixture/'native-procfs-lifetime.rs'),'-C','link-arg='+str(out/'variadic.o'),'-o',str(out/'lifetime-tests')],environment)
 run('rust-tests',[str(out/'lifetime-tests'),'--test-threads=1','--nocapture'])
 record['compiler_inputs']=[identity(p) for p in sorted(source.rglob('*')) if p.is_file()]
 for row in record['inputs']+record['compiler_inputs']:assert identity(Path(row['path']))==row
 record.update(status='PASS',tests_passed=5,actual_rust_procfs_compiled=True,actual_object_helpers_compiled=True)
except BaseException as error:record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('record.json','phase')]
 (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
