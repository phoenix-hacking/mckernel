
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/context.S" "/work/mckernel-native-irq-images-20260907-5/fallback/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/context.S.o"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/interrupt.S" "/work/mckernel-native-irq-images-20260907-5/fallback/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/interrupt.S.o"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/trampoline.S" "/work/mckernel-native-irq-images-20260907-5/fallback/kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/trampoline.S.o"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "IHK_IKC_USE_LINUX_WORK_IRQ"
  "IHK_OS_MANYCORE"
  "KERNEL_RAM_VADDR=0xfffffffffe800000"
  "MAP_KERNEL_START=0xfffffffffe800000UL"
  "PROFILE_ENABLE"
  "__KERNEL__"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "kernel/include"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/include"
  "kernel"
  "."
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/cokernel/smp/x86_64/include"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/cokernel/smp/x86_64"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/ikc/include"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/linux/include"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/include"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/coredump.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/coredump.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/coredump.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/cpu.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/cpu.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/local.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/local.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/local.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/lock.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/lock.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/lock.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/memory.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/memory_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/memory_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/mikc.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/mikc.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/mikc.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/perfctr.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/perfctr.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/perfctr.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/syscall.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/syscall.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/arch/x86_64/kernel/vsyscall.c" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/vsyscall.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/arch/x86_64/kernel/vsyscall.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/cokernel/smp/ikc.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/ikc.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/ikc.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/cokernel/smp/x86_64/dma.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/x86_64/dma.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/x86_64/dma.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/cokernel/smp/x86_64/setup.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/x86_64/setup.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/cokernel/smp/x86_64/setup.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/ikc/manycore.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/manycore.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/manycore.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/ikc/master.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/master.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/master.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/ikc/queue.c" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/queue.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/ihk/ikc/queue.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/abort.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/abort.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/abort.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/bitmap.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/bitmap.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/bitmap.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/bitops.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/bitops.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/bitops.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/list.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/page_alloc.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/page_alloc.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/page_alloc.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/string.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/string.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/string.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/lib/vsprintf.c" "kernel/CMakeFiles/mckernel.img.dir/__/lib/vsprintf.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/__/lib/vsprintf.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/ap.c" "kernel/CMakeFiles/mckernel.img.dir/ap.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/ap.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/cls.c" "kernel/CMakeFiles/mckernel.img.dir/cls.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/cls.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/copy.c" "kernel/CMakeFiles/mckernel.img.dir/copy.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/copy.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/debug.c" "kernel/CMakeFiles/mckernel.img.dir/debug.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/debug.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/devobj.c" "kernel/CMakeFiles/mckernel.img.dir/devobj.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/devobj.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/fileobj.c" "kernel/CMakeFiles/mckernel.img.dir/fileobj.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/fileobj.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/freeze.c" "kernel/CMakeFiles/mckernel.img.dir/freeze.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/freeze.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/futex.c" "kernel/CMakeFiles/mckernel.img.dir/futex.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/futex.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/gencore.c" "kernel/CMakeFiles/mckernel.img.dir/gencore.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/gencore.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/host.c" "kernel/CMakeFiles/mckernel.img.dir/host.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/host.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/host_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/host_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/host_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/hugefileobj.c" "kernel/CMakeFiles/mckernel.img.dir/hugefileobj.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/hugefileobj.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/init.c" "kernel/CMakeFiles/mckernel.img.dir/init.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/init.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/listeners.c" "kernel/CMakeFiles/mckernel.img.dir/listeners.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/listeners.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/llist.c" "kernel/CMakeFiles/mckernel.img.dir/llist.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/llist.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/lock_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/lock_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/lock_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/mem.c" "kernel/CMakeFiles/mckernel.img.dir/mem.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/mem.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/mikc.c" "kernel/CMakeFiles/mckernel.img.dir/mikc.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/mikc.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/object_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/object_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/object_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/pager.c" "kernel/CMakeFiles/mckernel.img.dir/pager.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/pager.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/plist.c" "kernel/CMakeFiles/mckernel.img.dir/plist.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/plist.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/process.c" "kernel/CMakeFiles/mckernel.img.dir/process.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/process.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/process_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/process_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/process_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/procfs.c" "kernel/CMakeFiles/mckernel.img.dir/procfs.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/procfs.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/profile.c" "kernel/CMakeFiles/mckernel.img.dir/profile.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/profile.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/rbtree.c" "kernel/CMakeFiles/mckernel.img.dir/rbtree.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/rbtree.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/sched_helpers.c" "kernel/CMakeFiles/mckernel.img.dir/sched_helpers.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/sched_helpers.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/shmobj.c" "kernel/CMakeFiles/mckernel.img.dir/shmobj.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/shmobj.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/syscall.c" "kernel/CMakeFiles/mckernel.img.dir/syscall.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/syscall.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/sysfs.c" "kernel/CMakeFiles/mckernel.img.dir/sysfs.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/sysfs.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/timer.c" "kernel/CMakeFiles/mckernel.img.dir/timer.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/timer.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/waitq.c" "kernel/CMakeFiles/mckernel.img.dir/waitq.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/waitq.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/xpmem.c" "kernel/CMakeFiles/mckernel.img.dir/xpmem.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/xpmem.c.o.d"
  "/work/mckernel-native-irq-images-20260907-5/source/kernel/zeroobj.c" "kernel/CMakeFiles/mckernel.img.dir/zeroobj.c.o" "gcc" "kernel/CMakeFiles/mckernel.img.dir/zeroobj.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
