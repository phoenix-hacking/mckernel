
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "/work/mckernel-native-irq-images-20260907-5/source/executer/user/arch/x86_64/archdep.S" "/work/mckernel-native-irq-images-20260907-5/fallback/executer/user/CMakeFiles/libmcexec.dir/arch/x86_64/archdep.S.o"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "IHK_IKC_USE_LINUX_WORK_IRQ"
  "PROFILE_ENABLE"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "executer/user"
  "."
  "/work/mckernel-native-irq-images-20260907-5/source/ihk/linux/include"
  "/work/mckernel-native-irq-images-20260907-5/source/executer/user/arch/x86_64/include"
  "/work/mckernel-native-irq-images-20260907-5/source/executer/user"
  "/work/mckernel-native-irq-images-20260907-5/source/executer/user/arch/x86_64"
  "ihk/linux/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
