"""Retain the completed local source/test checkpoint; never promote boot gates."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile

repo = Path('/home/holden/mckernel')
scratch = Path('/home/holden/mckernel-work/scratch')
out = repo / 'docs/verification/evidence'
private = scratch / 'native-os-resource-integration-20260907'
run = int(sys.argv[1])
full_name = 'native-os-resource-full-suite-20260907-' + str(run)
full = json.loads((scratch / (full_name + '.json')).read_text())
log = (scratch / (full_name + '.log')).read_text()
if full['exit_code'] != 0:
    raise SystemExit('Full suite must pass before retention')
match = re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK(?: \(skipped=(\d+)\))?', log)
if not match:
    raise SystemExit('No complete unittest success summary')
tests, skipped = int(match[1]), int(match[3] or 0)
artifacts = []

def retain(name, data):
    target = out / ('native-os-resource-final-20260907-' + name + '.gz')
    if target.exists():
        raise SystemExit('Refusing to overwrite retained artifact: ' + str(target))
    raw = gzip.compress(data, mtime=0)
    target.write_bytes(raw)
    artifacts.append(dict(path=str(target.relative_to(repo)), size=len(raw),
                          sha256=hashlib.sha256(raw).hexdigest(),
                          uncompressed_size=len(data), uncompressed_sha256=hashlib.sha256(data).hexdigest()))

for family, count in (('integration-tests', 5), ('binding-tests', 4), ('full-suite', run)):
    for index in range(1, count + 1):
        stem = 'native-os-resource-' + family + '-20260907-' + str(index)
        for suffix in ('.json', '.log'):
            retain(stem + suffix, (scratch / (stem + suffix)).read_bytes())
for name in ('run-native-os-resource-integration-tests.py', 'run-native-os-resource-binding-tests.py',
             'run-native-os-resource-full-tests.py', 'update-os-resource-bindings.py',
             'update-os-resource-witness-integration.py', 'derive-native-os-resource-contracts.py',
             'refresh-os-resource-ffi-ledger.py', 'run-native-os-resource-post-guest.py',
             'native-os-resource-post-guest-20260907.json',
             'native-os-resource-updated-ffi-ledger-20260907.changes.json',
             'inventory-rust-consumers-os-resource-20260907.py'):
    retain(name, (scratch / name).read_bytes())
for dirname in ('native-os-resource-derived-contracts-20260907',
                'native-os-resource-derived-contracts-20260907-attempt2'):
    retain(dirname + '-record.json', (scratch / dirname / 'record.json').read_bytes())
recipe = (scratch / 'run-native-os-resource-full-tests.py').read_bytes()
if hashlib.sha256(recipe).hexdigest() != full['recipe']['sha256']:
    raise SystemExit('Executed final test helper changed')

buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
    for row in full['changed_inputs']:
        relative = row['path']
        if relative.startswith('docs/verification/evidence/'):
            continue
        data = (private / relative).read_bytes()
        if len(data) != row['size'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise SystemExit('Test snapshot source changed: ' + relative)
        info = tarfile.TarInfo(relative)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
retain('tested-source-overlay.tar', buffer.getvalue())

inventory_name = 'rust-consumers-os-resource-20260907.json'
inventory = scratch / inventory_name
inventory_destination = repo / 'docs/verification' / inventory_name
if inventory_destination.exists():
    raise SystemExit('Inventory already retained')
inventory_destination.write_bytes(inventory.read_bytes())
references = []
for name in ('native-os-resource-checkpoint-20260907.json',
             'native-os-resource-exact-stage-checkpoint-20260907.json', inventory_name):
    path = repo / 'docs/verification' / name
    data = path.read_bytes()
    references.append(dict(path=str(path.relative_to(repo)), size=len(data), sha256=hashlib.sha256(data).hexdigest()))
retain('retainer.py', Path(__file__).read_bytes())
record = dict(schema_version=1, kind='native-os-resource-final-local-validation',
              recorded_utc=datetime.now(timezone.utc).isoformat(), source_parent=full['source_parent'],
              suite=dict(status='PASS', tests_run=tests, tests_passed=tests-skipped, tests_skipped=skipped,
                         seconds=float(match[2]), started_utc=full['started_utc'], finished_utc=full['finished_utc'],
                         log='docs/verification/evidence/native-os-resource-final-20260907-' + full_name + '.log.gz'),
              scope='current resource implementation and declared-stage guest; historical FP-0006 witnesses use explicit frozen source fixtures; final notes may postdate the test snapshot',
              production_gate_credit=False, native_mckernel_boot_proven=False,
              complete_rust_unification_claimed=False,
              remaining=['McKernel image loading, AP startup and boot', 'IKC, syscall forwarding and applications',
                         'McKernel Rust/assembly-only completion',
                         'current-code production capture workflows and independent acceptance review'],
              references=references, artifacts=artifacts)
destination = repo / 'docs/verification/native-os-resource-final-validation-20260907.json'
if destination.exists():
    raise SystemExit('Final validation record already exists')
destination.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained OS resource checkpoint:', tests-skipped, 'passed,', skipped, 'skipped;', len(artifacts), 'artifacts')
