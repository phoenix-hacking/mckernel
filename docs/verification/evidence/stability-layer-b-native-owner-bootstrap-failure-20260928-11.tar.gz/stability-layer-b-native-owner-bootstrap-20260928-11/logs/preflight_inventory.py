#!/usr/bin/python3
import hashlib
import json
import os
import stat
import tempfile
import time

ROOT = "/home/holden/mckernel-work/scratch/stability-layer-b-native-owner-bootstrap-20260928-11"
LOGS = ROOT + "/logs"
INCLUDE_ROOTS = (
    "/usr/lib/gcc/x86_64-linux-gnu/9/include",
    "/usr/include/x86_64-linux-gnu",
    "/usr/include",
)
SOURCE = "/home/holden/mckernel/scripts/tests/layer_b_native_owner_v1.c"
TEST = "/home/holden/mckernel/scripts/tests/test_layer_b_native_owner_source.py"
TOOLS = (
    "/usr/bin/gcc", "/usr/lib/gcc/x86_64-linux-gnu/9/cc1", "/usr/bin/as",
    "/usr/bin/env", "/usr/bin/prlimit", "/usr/bin/timeout", "/usr/bin/systemd-run",
    "/usr/bin/systemctl", "/usr/bin/journalctl", "/usr/bin/readelf", "/usr/bin/objdump",
    "/usr/bin/sleep", "/usr/bin/test", "/usr/bin/sync", "/usr/bin/mv",
)

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                return h.hexdigest()
            h.update(block)

def within(path):
    return any(path == r or path.startswith(r + "/") for r in INCLUDE_ROOTS)

def resolve(path):
    pending = os.path.abspath(path).split("/")[1:]
    current = "/"
    hops = []
    for _ in range(128):
        if not pending:
            try:
                st = os.lstat(current)
                kind = "directory" if stat.S_ISDIR(st.st_mode) else "file" if stat.S_ISREG(st.st_mode) else "other"
                return {"hops": hops, "final_path": current, "final_kind": kind, "error": None}
            except OSError as exc:
                return {"hops": hops, "final_path": current, "final_kind": None, "error": repr(exc)}
        component = pending.pop(0)
        candidate = os.path.join(current, component)
        try:
            st = os.lstat(candidate)
        except OSError as exc:
            return {"hops": hops, "final_path": candidate, "final_kind": None, "error": repr(exc)}
        if stat.S_ISLNK(st.st_mode):
            target = os.readlink(candidate)
            hops.append({"path": candidate, "target": target, "dev": st.st_dev, "ino": st.st_ino})
            replacement = target if os.path.isabs(target) else os.path.join(os.path.dirname(candidate), target)
            combined = os.path.normpath(os.path.join(replacement, *pending))
            pending = os.path.abspath(combined).split("/")[1:]
            current = "/"
        else:
            current = candidate
    return {"hops": hops, "final_path": current, "final_kind": None, "error": "symlink resolution limit"}

def identity(path):
    st = os.lstat(path)
    resolved = resolve(path)
    final = resolved["final_path"]
    record = {
        "path": path, "realpath": os.path.realpath(path), "resolution": resolved,
        "dev": st.st_dev, "ino": st.st_ino, "mode": stat.S_IMODE(st.st_mode),
        "uid": st.st_uid, "gid": st.st_gid, "size": st.st_size,
        "kind": "symlink" if stat.S_ISLNK(st.st_mode) else "file" if stat.S_ISREG(st.st_mode) else "other",
    }
    if resolved["error"] is None and os.path.isfile(final):
        record["sha256"] = sha(final)
    return record

seen = set()
entries = []
errors = []
external = []
stack = list(reversed(INCLUDE_ROOTS))
while stack:
    directory = stack.pop()
    try:
        children = sorted(os.scandir(directory), key=lambda e: e.name)
    except OSError as exc:
        errors.append({"path": directory, "error": repr(exc)})
        continue
    for child in children:
        path = child.path
        if path in seen:
            continue
        seen.add(path)
        try:
            st = os.lstat(path)
            base = {"path": path, "dev": st.st_dev, "ino": st.st_ino,
                    "mode": stat.S_IMODE(st.st_mode), "uid": st.st_uid,
                    "gid": st.st_gid, "size": st.st_size}
            if stat.S_ISLNK(st.st_mode):
                resolved = resolve(path)
                base.update({"kind": "symlink", "literal_target": os.readlink(path), "resolution": resolved})
                if resolved["error"] is None and resolved["final_kind"] == "directory" and not within(resolved["final_path"]):
                    base["classification"] = "EXCLUDED_EXTERNAL_DIRECTORY_LINK"
                    external.append(path)
                entries.append(base)
            elif stat.S_ISDIR(st.st_mode):
                base["kind"] = "directory"
                entries.append(base)
                stack.append(path)
            elif stat.S_ISREG(st.st_mode):
                base.update({"kind": "file", "realpath": os.path.realpath(path), "sha256": sha(path)})
                entries.append(base)
            else:
                base["kind"] = "other"
                entries.append(base)
        except OSError as exc:
            errors.append({"path": path, "error": repr(exc)})

entries.sort(key=lambda x: x["path"])
baseline = LOGS + "/include-baseline.jsonl"
fd, temp = tempfile.mkstemp(prefix=".include-baseline.", dir=LOGS)
with os.fdopen(fd, "w") as f:
    for item in entries:
        f.write(json.dumps(item, sort_keys=True, separators=(",", ":")) + "\n")
    f.flush(); os.fsync(f.fileno())
os.replace(temp, baseline)
report = {
    "recorded_realtime_ns": time.time_ns(), "recorded_monotonic_ns": time.monotonic_ns(),
    "roots": INCLUDE_ROOTS, "include_entries": len(entries), "errors": errors,
    "external_links": external, "source_pre": identity(SOURCE), "test_pre": identity(TEST),
    "tools": [identity(p) for p in TOOLS],
    "root_identity": identity(ROOT),
}
with open(LOGS + "/preflight.json.tmp", "w") as f:
    json.dump(report, f, sort_keys=True, indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
os.replace(LOGS + "/preflight.json.tmp", LOGS + "/preflight.json")
if errors:
    raise SystemExit("inventory errors: %r" % errors[:3])
print(json.dumps({"entries": len(entries), "external": len(external), "errors": len(errors)}, sort_keys=True))
