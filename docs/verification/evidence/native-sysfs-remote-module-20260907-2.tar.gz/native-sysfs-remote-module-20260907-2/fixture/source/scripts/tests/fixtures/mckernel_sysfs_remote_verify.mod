/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.o
