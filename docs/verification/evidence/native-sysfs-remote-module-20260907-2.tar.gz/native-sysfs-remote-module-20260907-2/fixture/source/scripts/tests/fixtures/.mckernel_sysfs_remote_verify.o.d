/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/.mckernel_sysfs_remote_verify.o.d: /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/abi/sysfs_request.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_rpc.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_remote.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.o: /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/abi/sysfs_request.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_rpc.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs /work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_remote.rs ./rust/libcore.rmeta ./rust/libkernel.rmeta ./rust/liballoc.rmeta ./rust/libcompiler_builtins.rmeta ./rust/libmacros.so ./rust/libbindings.rmeta ./rust/libuapi.rmeta ./rust/libbuild_error.rmeta

/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/mckernel_sysfs_remote_verify.rs:
/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/abi/sysfs_request.rs:
/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_rpc.rs:
/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_objects.rs:
/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_tree.rs:
/work/native-sysfs-remote-module-20260907-2/fixture/source/scripts/tests/fixtures/../../../host-kernel/native-rust/sysfs_remote.rs:
./rust/libcore.rmeta:
./rust/libkernel.rmeta:
./rust/liballoc.rmeta:
./rust/libcompiler_builtins.rmeta:
./rust/libmacros.so:
./rust/libbindings.rmeta:
./rust/libuapi.rmeta:
./rust/libbuild_error.rmeta:
