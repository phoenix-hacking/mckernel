"""Run only inside the bounded native container; preserve first failure."""
import importlib
import json
from pathlib import Path
import sys
import traceback

sys.path.insert(0, '/workspace/scripts')
out = Path('/work/native-os-resource-derived-contracts-20260907-attempt2')
out.mkdir(exist_ok=False)
record = {'command': ['python3', __file__], 'completed': []}
try:
    for module_name in ('ihk_os_registry_check', 'ihk_ioctl_dispatch_check',
                        'ihk_device_registry_check', 'ihk_os_runtime_check'):
        module = importlib.import_module(module_name)
        kwargs = {}
        if module_name == 'ihk_device_registry_check':
            kwargs['ioctl_contract_override'] = (out / 'ihk-ioctl-dispatch-foundation-v1.json').read_bytes()
        value = module.derive_contract('/workspace', **kwargs)
        contract_path = getattr(module, 'CONTRACT_PATH', None) or module.CONTRACT
        (out / Path(contract_path).name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
        record['completed'].append(contract_path)
        print('Derived', contract_path, flush=True)
    import native_rust_unsafe_ffi_ledger as ffi
    discovery = ffi.discover('/workspace')
    (out / 'ffi-discovery.json').write_text(ffi.pretty(discovery))
    print('Discovered FFI sites:', len(discovery['sites']), flush=True)
    record['exit_code'] = 0
except BaseException:
    record['exit_code'] = 1
    record['error'] = traceback.format_exc()
    raise
finally:
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
