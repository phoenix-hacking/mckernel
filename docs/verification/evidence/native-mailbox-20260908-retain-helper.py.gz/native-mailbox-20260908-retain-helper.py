"""Retain native syscall mailbox integration and idle waiter guest evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-mailbox-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-mailbox-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],
    scope='Native syscall ownership, mailbox, receive backpressure and worker WAIT/RET connected; exact-source protocol tests and real pre-START idle waiter/image regressions. No scheduled application or live request delivery.',
    native_mailbox_integrated=True,user_syscall_ioctls_integrated=True,
    live_response_claim_verified=False,live_wait_copyout_verified=False,live_syscall_completion_verified=False,
    procfs_integrated=False,start_integrated=False,scheduled_cleanup_integrated=False,
    independent_dead_worker_reaping=False,application_attempted_in_this_checkpoint=False,
    mckernel_application_executed=False,declared_stage_integrated=False,
    production_gate_credit=False,independent_acceptance=False,
    application_acceptance='FAIL: last actual launcher reached unimplemented START_IMAGE')
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-application-launcher-checkpoint-20260908.json','native-application-syscall-checkpoint-20260908.json']:
        prior_path=repo/'docs/verification'/name
        prior=json.loads(prior_path.read_text());assert prior['status']=='PASS' and not prior['mckernel_application_executed']
        reference=identity(prior_path);reference['path']=str(prior_path.relative_to(repo));record['references'].append(reference)
        if 'actual_launcher' in prior:record['last_actual_launcher']=prior['actual_launcher']
    assert record['last_actual_launcher']['reached']=='START_IMAGE'
    assert record['last_actual_launcher']['overall_result']=='FAIL'
    captures=['native-application-mailbox-20260908-'+str(i) for i in range(1,6)]
    captures+=['native-application-mailbox-module-20260908-'+str(i) for i in range(1,4)]
    captures+=['native-application-mailbox-guest-20260908-x86_64-'+str(i) for i in range(1,3)]
    captures+=['native-application-mailbox-regression-20260908-i386-1']
    failures={'native-application-mailbox-20260908-4','native-application-mailbox-module-20260908-1'}
    for name in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text())
        expected='FAIL' if name in failures else 'PASS';assert state['status']==expected,name
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        for row in state.get('overlay',[]):
            verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        for capture in state.get('captures',[]):
            for row in capture['artifacts']:verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,complete_capture_retained=True,archive_exclusions={}))

    compiled=work/'native-application-mailbox-module-20260908-3';replays=[]
    old=work/'native-application-service-module-20260908-2/staged-source';changed=[];added=[];unchanged=[]
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if not (old/relative).exists():added.append(str(relative))
        elif (old/relative).read_bytes()!=saved.read_bytes():changed.append(str(relative))
        else:unchanged.append(str(relative))
        if current.read_bytes()==saved.read_bytes():
            record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout);assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='Exact pinned rustfmt replay; original and formatted files retained',
                compiler_capture=str(saved),compiler_sha256=identity(saved)['sha256'],compiler_size=saved.stat().st_size,
                format_command=command,format_original=str(original),format_output=str(replay))
            record['native_compiler_bindings'].append(row);replays.append(str(relative))
    assert set(replays)=={'ihk_ioctl.rs','os_registry.rs','smp_resource.rs'}
    assert len(record['native_compiler_bindings'])==51
    assert set(changed)=={'abi/application.rs','application_rpc.rs','ihk_smp_x86_64.rs','mcctrl.rs','mcctrl_process.rs','smp_application.rs','smp_memory.rs','smp_service.rs','sysfs_memory.rs'}
    assert added==['application_syscall.rs','smp_application_syscall.rs'] and len(unchanged)==40
    record['native_change_scope']=dict(previous_actual_launcher_module=str(old.parent),unchanged_sources=unchanged,
        changed_sources=changed,added_sources=added,new_module_guest_tested=True)
    record['current_native_module']=str(compiled)

    protocol=work/'native-application-mailbox-20260908-5';state=json.loads((protocol/'record.json').read_text())
    rows=[]
    for row in state['inputs']:
        relative=Path(row['path']).relative_to(protocol/'original-inputs')
        rows.append(binding(repo/relative,protocol/'source'/relative))
    assert len(rows)==13;record['syscall_protocol_compiler_bindings']=rows
    for body in state['extracted_bodies']:
        raw=(protocol/'source'/body['source']).read_bytes()[body['start_byte']:body['end_byte']]
        assert hashlib.sha256(raw).hexdigest()==body['sha256'],body
    record['syscall_protocol_extracted_bodies']=state['extracted_bodies']
    assert '21 passed; 0 failed;' in (protocol/'rust-tests.log').read_text()
    assert not (protocol/'rust-build.log').read_bytes()
    assert len(state['extracted_bodies'])==25
    for key,value in [('exact_request_vectors',6),('exact_completion_vectors',14),('queue_full_retries',1024),('atomic_race_rounds',256),('concurrent_tokens',4096)]:assert state[key]==value,key
    for name in ['application_syscall.rs','smp_application_syscall.rs']:
        assert (compiled/'staged-source'/name).read_bytes()==(protocol/'source/host-kernel/native-rust'/name).read_bytes()
    record['syscall_protocol']=dict(capture=str(protocol),tests_passed=21,c_layout=state['c_layout'],
        exact_request_vectors=6,exact_completion_vectors=14,queue_full_retries=1024,atomic_race_rounds=256,
        concurrent_tokens=4096,exact_extracted_bodies=25,rust_warnings_enforced=True,
        original_failures_retained=sorted(failures),
        original_c_zero_tid_cancellation_vectors=2,native_mailbox_source_compiled=True,
        mailbox_wake_retries=1024,pending_fifo_after_reuse=True,cross_cpu_completion_progress=True,
        limitations='Actual mailbox source uses substituted allocation and retained atomic memory providers. No live IKC response claim, successful WAIT copyout, scheduled worker death or application completion was exercised.')

    record['guest_probe_bindings']=[];record['guest_module_bindings']=[];record['guest_results']=[]
    current_guests=[work/'native-application-mailbox-guest-20260908-x86_64-2',work/'native-application-mailbox-regression-20260908-i386-1']
    for directory in current_guests:
        state=json.loads((directory/'record.json').read_text())
        assert state['status']=='PASS' and state['qemu_exit_code']==0 and state['terminal_vm_state']==dict(running=False,status='shutdown')
        assert not state['applications_tested'] and state['physical_status']==3 and state['full_ready_observed']
        for saved in sorted((directory/'probe-source').iterdir()):
            current=repo/('executer/include/uprotocol.h' if saved.name=='native-image-c-abi.h' else 'scripts/tests/fixtures/'+saved.name)
            record['guest_probe_bindings'].append(binding(current,saved))
        for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:
            left,right=identity(compiled/name),identity(directory/'root/modules'/name)
            assert (left['size'],left['sha256'])==(right['size'],right['sha256'])
            record['guest_module_bindings'].append(dict(compiled=left,guest=right))
        result={key:state[key] for key in ['architecture','profile','cpuset','container_memory_mib','guest_cpus','numa_nodes','mcctrl_service','mcctrl_process','mcctrl_executable','observed_callback_exchanges','terminal_vm_state']}
        result.update(capture=str(directory),physical_status_3_captures=len(state['captures']))
        for capture in state['captures']:assert capture['validated'] and capture['status']==3
        for key in ['mcctrl_image','native_waiter']:
            if key in state:result[key]=state[key]
        record['guest_results'].append(result)
    assert len(record['guest_probe_bindings'])==17 and len(record['guest_module_bindings'])==6
    x64=record['guest_results'][0];compat=record['guest_results'][1]
    assert x64['native_waiter']==dict(checks=396,interruptions=128,untouched_bytes=11264,idle_returns_rejected=130,copy_faults=1,preprepare_rejections=2,live_syscall_delivery=False,application_execution=False)
    assert x64['mcctrl_image']['checks']==47 and not x64['mcctrl_image']['task_scheduled']
    record['current_guest_totals']=dict(physical_status_3_captures=sum(row['physical_status_3_captures'] for row in record['guest_results']),
        process_checks=sum(row['mcctrl_process']['checks'] for row in record['guest_results']),
        credential_checks=sum(row['mcctrl_executable']['credential_checks'] for row in record['guest_results']),
        executable_checks=sum(row['mcctrl_executable']['file_checks'] for row in record['guest_results']),
        topology_queries=sum(row['mcctrl_service']['topology_queries'] for row in record['guest_results']),
        continuing_sysfs_callbacks=sum(row['observed_callback_exchanges'] for row in record['guest_results']))
    assert record['current_guest_totals']==dict(physical_status_3_captures=7,process_checks=306,credential_checks=518,executable_checks=1116,topology_queries=2112,continuing_sysfs_callbacks=260)

    record['unchanged_guest_peer_bindings']=[]
    for name in ['kernel/rust/abi.rs','kernel/rust/syscall_policy.rs','kernel/rust/host_helpers.rs','kernel/syscall.c']:
        record['unchanged_guest_peer_bindings'].append(binding(repo/name,work/'mckernel-native-sysfs-images-20260908-2/source'/name))
    linux=work/'native-source/linux-6.12.0-211.44.1.el10_2';references=out/'linux-reference';references.mkdir()
    record['pinned_linux_review_sources']=[]
    for name in ['rust/kernel/sync/condvar.rs','rust/kernel/sync/lock/mutex.rs','rust/kernel/sync/arc.rs',
                 'rust/kernel/task.rs','rust/kernel/uaccess.rs','include/linux/proc_fs.h','fs/proc/inode.c',
                 'rust/kernel/alloc/vec_ext.rs','rust/kernel/alloc.rs','rust/kernel/error.rs',
                 'kernel/pid.c','include/linux/pid.h','arch/x86/include/uapi/asm/signal.h']:
        target=references/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(linux/name,target)
        assert target.read_bytes()==(linux/name).read_bytes()
        record['pinned_linux_review_sources'].append(dict(original=identity(linux/name),retained=identity(target)))
    artifact(references,'native-mailbox-20260908-linux-reference.tar.gz',True)
    artifact(out/'format-replay','native-mailbox-20260908-format-replay.tar.gz',True)
    for name in ['test-native-application-mailbox.py','build-native-application-mailbox.py','run-native-application-mailbox.py','run-native-application-mailbox-compat.py']:
        artifact(work/name,'native-mailbox-20260908-'+name+'.gz')
    artifact(out/'helper.py','native-mailbox-20260908-retain-helper.py.gz')
    record.update(status='PASS',complete_captures=11,original_failures_in_this_batch=2,
        artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],manifest,flush=True)
