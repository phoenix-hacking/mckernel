from pathlib import Path
import hashlib, json
recovery_compiled = Path('/work/native-image-loader-prototype-20260907-2')
recovery_record = json.loads((recovery_compiled / 'record.json').read_text())
assert recovery_record['status'] == 'PASS'
for recovery_row in recovery_record['overlay']:
    recovery_current = Path(recovery_row['path'])
    for recovery_path in (recovery_current, recovery_compiled / 'staged-source' / recovery_current.name):
        recovery_data = recovery_path.read_bytes()
        assert len(recovery_data) == recovery_row['size'], str(recovery_path)
        assert hashlib.sha256(recovery_data).hexdigest() == recovery_row['sha256'], str(recovery_path)
print('Verified all 10 current sources against the preserved successful native build and staged copies.', flush=True)
import hashlib,json,os,re,subprocess
from pathlib import Path
repo=Path('/workspace');compiled=Path('/work/native-image-loader-prototype-20260907-2')
if os.getuid()!=1000 or os.sched_getaffinity(0)!={2,3,4,5}: raise SystemExit('Requires fixed four-CPU runner')
subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
for name in ['ihk_smp_x86_64.rs','smp_cpu.rs','smp_memory.rs','os_runtime.rs','smp_loader.rs','smp_image.rs']:
 subprocess.run(['rustfmt','--check','--edition','2021','--config','skip_children=true,reorder_modules=false',str(repo/'host-kernel/native-rust'/name)],check=True)
record=json.loads((compiled/'record.json').read_text());assert record['status']=='PASS'
modules=[]
for row in record['outputs']:
 path=Path(row['path']);b=path.read_bytes()
 if len(b)!=row['size'] or hashlib.sha256(b).hexdigest()!=row['sha256']: raise SystemExit('Compiled artifact changed: '+str(path))
 if path.suffix!='.ko': continue
 header=subprocess.check_output(['llvm-readelf','-h',str(path)],text=True)
 if 'ELF64' not in header or 'Advanced Micro Devices X86-64' not in header: raise SystemExit('Wrong ELF architecture')
 assembly=subprocess.check_output(['llvm-objdump','-d','--no-show-raw-insn',str(path)],text=True)
 instructions=[];unexpected=[]
 for line in assembly.splitlines():
  match=re.match(r'^\s*[0-9a-f]+:\s+(.+)$',line)
  if not match: continue
  instruction=match.group(1);instructions.append(instruction);mnemonic=instruction.split()[0]
  if re.search(r'%(?:[xyz]mm[0-9]+|mm[0-7])\b',instruction) or mnemonic.startswith(('f','xsave','xrstor')) or mnemonic in ('vzeroupper','vzeroall','emms','ldmxcsr','stmxcsr'): unexpected.append(instruction)
 if unexpected: raise SystemExit('Unexpected SIMD/x87 '+repr(unexpected[:10]))
 modules.append(dict(path=str(path),sha256=row['sha256'],architecture='ELF64 x86-64',instruction_count=len(instructions),simd_x87_instructions=unexpected))
result=dict(status='PASS',modules=modules,scope='source-bound image-load prototype with isolated debug configuration',full_repository_suite_run=False,production_gate_credit=False)
Path('/work/recovery-cJDpVLRT/native-image-loader-module-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
