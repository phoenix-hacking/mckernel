savedcmd_/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o := clang -Wp,-MMD,/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/.mckernel_trampoline_region_layout.o.d -nostdinc -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include -I./arch/x86/include/generated -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include -I./include -I/work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I/work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi -I./include/generated/uapi -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h -include /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler_types.h -D__KERNEL__ --target=x86_64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -Werror=option-ignored -Werror=unused-command-line-argument -fmacro-prefix-map=/work/native-source/linux-6.12.0-211.44.1.el10_2/= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=branch -fno-jump-tables -m64 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mstack-alignment=8 -mskip-rax-setup -mtune=generic -mno-red-zone -mcmodel=kernel -Wno-sign-compare -fno-asynchronous-unwind-tables -mretpoline-external-thunk -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fstack-protector-strong -ftrivial-auto-var-init=zero -fno-stack-clash-protection -pg -mfentry -DCC_USING_NOP_MCOUNT -DCC_USING_FENTRY -falign-functions=16 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-gnu -Wno-default-const-init-unsafe -Wvla -Wno-pointer-sign -Wcast-function-type -Wno-unterminated-string-initialization -Wimplicit-fallthrough -Werror=date-time -Werror=incompatible-pointer-types -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-format-overflow -Wno-format-overflow-non-kprintf -Wno-format-truncation-non-kprintf -Wno-override-init -Wno-pointer-to-enum-cast -Wno-tautological-constant-out-of-range-compare -Wno-unaligned-access -Wno-enum-compare-conditional -Wno-enum-enum-conversion -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-sign-compare -Wno-unused-parameter -g    -DKBUILD_MODFILE='"/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout"' -DKBUILD_BASENAME='"mckernel_trampoline_region_layout"' -DKBUILD_MODNAME='"mckernel_trampoline_region_layout"' -D__KBUILD_MODNAME=mckernel_trampoline_region_layout -c -o /work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o /work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.c  

source_/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o := /work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.c

deps_/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o := \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_SIGNED_WRAP) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler_attributes.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler-clang.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/build_bug.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
    $(wildcard include/config/64BIT) \
  arch/x86/include/generated/asm/rwonce.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/rwonce.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/types.h \
  arch/x86/include/generated/uapi/asm/types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/int-ll64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/int-ll64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/bitsperlong.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/posix_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/stddef.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/stddef.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/posix_types_64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/posix_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/io.h \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/HAS_IOPORT_MAP) \
    $(wildcard include/config/PCI) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/sizes.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/const.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/stringify.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/objtool_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/annotate.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
    $(wildcard include/config/SMP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/once_lite.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/stdarg.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kern_levels.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/ratelimit_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/bits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/overflow.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/limits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/limits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/limits.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/param.h \
  arch/x86/include/generated/uapi/asm/param.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/param.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/spinlock_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/qrwlock_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/byteorder.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/byteorder/little_endian.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/byteorder/little_endian.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/swab.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/swab.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/swab.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/byteorder/generic.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/dynamic_debug.h \
    $(wildcard include/config/JUMP_LABEL) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/jump_label.h \
    $(wildcard include/config/HAVE_JUMP_LABEL_HACK) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/extable_fixup_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/nops.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/err.h \
  arch/x86/include/generated/uapi/asm/errno.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/errno.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/errno-base.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/io.h \
    $(wildcard include/config/PARAVIRT) \
    $(wildcard include/config/MTRR) \
    $(wildcard include/config/X86_PAT) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/args.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/array_size.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/errno.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/errno.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/string.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/string.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/KMSAN) \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/fortify-string.h \
    $(wildcard include/config/CC_HAS_KASAN_MEMINTRINSIC_PREFIX) \
    $(wildcard include/config/GENERIC_ENTRY) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bitfield.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/typecheck.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/mem_encrypt.h \
    $(wildcard include/config/X86_MEM_ENCRYPT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/DYNAMIC_MEMORY_LAYOUT) \
    $(wildcard include/config/X86_5LEVEL) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/cpufeatures.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/required-features.h \
    $(wildcard include/config/X86_MINIMUM_CPU_FAMILY) \
    $(wildcard include/config/MATH_EMULATION) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/X86_CMPXCHG64) \
    $(wildcard include/config/X86_CMOV) \
    $(wildcard include/config/X86_P6_NOP) \
    $(wildcard include/config/MATOM) \
    $(wildcard include/config/PARAVIRT_XXL) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/disabled-features.h \
    $(wildcard include/config/X86_UMIP) \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/MITIGATION_PAGE_TABLE_ISOLATION) \
    $(wildcard include/config/MITIGATION_CALL_DEPTH_TRACKING) \
    $(wildcard include/config/ADDRESS_MASKING) \
    $(wildcard include/config/INTEL_IOMMU_SVM) \
    $(wildcard include/config/X86_SGX) \
    $(wildcard include/config/XEN_PV) \
    $(wildcard include/config/INTEL_TDX_GUEST) \
    $(wildcard include/config/X86_USER_SHADOW_STACK) \
    $(wildcard include/config/X86_FRED) \
    $(wildcard include/config/KVM_AMD_SEV) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kmsan-checks.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/range.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
    $(wildcard include/config/SPARSEMEM) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/pfn.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/getorder.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bitops.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/kernel.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/sysinfo.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/generic-non-atomic.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/barrier.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/barrier.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/bitops.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/rmwcc.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/sched.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/arch_hweight.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/const_hweight.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/instrumented-atomic.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/instrumented.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/instrumented-lock.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/le.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/bitops/ext2-atomic-setbit.h \
  arch/x86/include/generated/asm/early_ioremap.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/GENERIC_EARLY_IOREMAP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PROC_FS) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/sparsemem.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/shared/io.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/special_insns.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/VM86) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/processor-flags.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/irqflags.h \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/irqflags_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/cleanup.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/irqflags.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CALL_THUNKS_DEBUG) \
    $(wildcard include/config/MITIGATION_IBPB_ENTRY) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/static_key.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/msr-index.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/unwind_hints.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/orc_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/X86_64_SMP) \
    $(wildcard include/config/CC_HAS_NAMED_AS) \
    $(wildcard include/config/USE_X86_SEG_SUPPORT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/percpu.h \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/current.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/cache.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/asm-offsets.h \
  include/generated/asm-offsets.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/GEN-for-each-reg.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/segment.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/ZERO_CALL_USED_REGS) \
    $(wildcard include/config/PARAVIRT_DEBUG) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/desc_defs.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
    $(wildcard include/config/RHEL_DIFFERENCES) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/align.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/vdso/align.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/container_of.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/hex.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/kstrtox.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/math.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/div64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/div64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/minmax.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/sprintf.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/instruction_pointer.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/wordpart.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bitmap.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/find.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/bitmap-str.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/cpumask_types.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/atomic.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/atomic.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/cmpxchg.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/cmpxchg_64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/atomic64_64.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/atomic/atomic-long.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/atomic/atomic-instrumented.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/gfp_types.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
    $(wildcard include/config/SLAB_OBJ_EXT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/numa.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/nodemask_types.h \
    $(wildcard include/config/NODES_SHIFT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/list.h \
    $(wildcard include/config/LIST_HARDENED) \
    $(wildcard include/config/DEBUG_LIST) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/random.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/ioctl.h \
  arch/x86/include/generated/uapi/asm/ioctl.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/ioctl.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/asm-generic/ioctl.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/irqnr.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/irqnr.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/prandom.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/once.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/frame.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/io.h \
    $(wildcard include/config/GENERIC_IOMAP) \
    $(wildcard include/config/TRACE_MMIO_ACCESS) \
    $(wildcard include/config/GENERIC_IOREMAP) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/iomap.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/NO_GENERIC_PCI_IOPORT_MAP) \
    $(wildcard include/config/GENERIC_PCI_IOMAP) \
  arch/x86/include/generated/asm/mmiowb.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/logic_pio.h \
    $(wildcard include/config/INDIRECT_PIO) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/fwnode.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/ioport.h \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/e820/api.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/e820/types.h \
    $(wildcard include/config/X86_PMEM_LEGACY) \
    $(wildcard include/config/INTEL_TXT) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/bootparam.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/setup_data.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/setup_data.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/screen_info.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/screen_info.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/apm_bios.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/apm_bios.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/linux/edd.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/linux/edd.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/asm/ist.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/arch/x86/include/uapi/asm/ist.h \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/video/edid.h \
    $(wildcard include/config/FIRMWARE_EDID) \
  /work/native-source/linux-6.12.0-211.44.1.el10_2/include/uapi/video/edid.h \

/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o: $(deps_/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o)

$(deps_/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_layout.o):
