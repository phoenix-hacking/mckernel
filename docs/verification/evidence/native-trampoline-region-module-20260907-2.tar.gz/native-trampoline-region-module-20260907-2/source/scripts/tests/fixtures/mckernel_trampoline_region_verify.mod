/work/native-trampoline-region-module-20260907-2/source/scripts/tests/fixtures/mckernel_trampoline_region_verify.o
