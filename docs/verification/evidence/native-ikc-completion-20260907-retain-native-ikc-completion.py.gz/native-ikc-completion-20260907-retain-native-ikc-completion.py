from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'native-ikc-completion-retained-20260907-1'
out.mkdir()
def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            value.update(data)
    return value.hexdigest()
def verify(row):
    path = Path(row['path'])
    assert path.stat().st_size == row['size'] and digest(path) == row['sha256'], path
record = dict(created_utc=datetime.now(timezone.utc).isoformat(), artifacts=[], captures=[],
    production_gate_credit=False, mckernel_boot_proven=False, declared_stage=False,
    native_queue_completion_proven=True, mckernel_arch_entry_proven=True,
    initial_bidirectional_ikc_proven=True,
    passed=[
        'Actual complete C, legacy Rust and native Rust queue bodies match over 13,312 sequential packets (digest 5d3367a006a52b85)',
        'Four host producers and four actual guest readers exchange 16,384 unique complete packets through eight slots',
        'A paused borrowed-packet handler preserves its slot through 1,024 rejected writes, rejects reentrant consumption and permits 256 subsequent slot reuses',
        'Native queue validation rejects corrupt counters, invalid geometry and overlapping output while releasing every reader claim',
        'Seven host queue, six master and 56 image/resource policy cases pass',
        'Fallback, legacy Rust and native Rust McKernel images build on the pinned compatibility compiler; IRQ producer equivalence and queue peer checks also pass there',
        'Native boot note revision 2 advertises completed reads; the actual parser accepts all three images and retains revision-1 load compatibility',
        'The image rewritten by the original note-extraction fixture is preserved; original compiler inputs and compatibility binutils reproduce its exact recorded SHA before restoration',
        'The fixed extraction writes a separate output and passes final input identity checks with native binutils',
        'All three native prototype modules and both exact boot layout witnesses build and pass ELF/no-SIMD checks',
        'Both preparation ABIs across two module lifetimes reject legacy and revision-1 native boot before startup, pass 32 forced allocations and four physical captures, then restore all CPU/memory/module owners',
        'Both actual-start ABIs execute the refreshed native image and exchange INIT_ACK/CONNECT through the real APIC and Linux IRQ-work paths',
        'QMP independently verifies code/CR3, exact queue counters and packet bytes, guest kmsg acknowledgment and retained started owners'],
    limitations=[
        'The first peer fixture failed C/PIE linking because its object omitted PIC; preserved attempt 1 and corrected attempt 2 are separate captures',
        'The first independent image verifier rewrote the input ELF through objcopy; its failure and the exact-byte restoration are preserved separately',
        'Repeated peer slot reuse is proven in the actual-body fixture; runtime boot still sends only INIT_ACK and captures the first CONNECT',
        'Listener acceptance, owned regular channels, vDSO/sysfs/mcctrl, full status 3 and applications remain open',
        'Started resources remain retained; VM termination is containment, not native shutdown/drain/restoration proof',
        'Declared staging, lifecycle/unsafe-FFI/license contracts and downstream source bindings are pending for current boot/IKC sources',
        'The earlier full suite predates boot/IKC integration; the earlier intermittent Linux idle/RCU stall, performance capabilities and other APIC modes remain open',
        'Full McKernel and linked-support Rust/assembly completion and independent production acceptance remain required'])
def add(path, name):
    target = out / name
    with path.open('rb') as source, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            for data in iter(lambda: source.read(1 << 20), b''):
                stream.write(data)
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name, source=str(path),
        size=target.stat().st_size, sha256=digest(target), unpacked_size=path.stat().st_size, unpacked_sha256=digest(path)))

names = [
    ('native-ikc-completion-tests-20260907-1', 'FAIL'),
    ('native-ikc-completion-tests-20260907-2', 'PASS'),
    ('mckernel-native-irq-images-20260907-11', 'PASS'),
    ('native-ikc-completion-images-validation-20260907-1', 'FAIL'),
    ('native-ikc-image-restoration-20260907-1', 'PASS'),
    ('native-ikc-completion-images-validation-20260907-2', 'PASS'),
    ('native-ikc-prototype-20260907-2', 'PASS'),
    ('native-ikc-guest-20260907-prepare-3', 'PASS'),
    ('native-ikc-guest-20260907-start-x86_64-2', 'PASS'),
    ('native-ikc-guest-20260907-start-i386-2', 'PASS'),
]
for name, status in names:
    path = work / name
    metadata = json.loads((path / 'record.json').read_text())
    assert metadata['status'] == status, name
    rows = metadata.get('inputs', []) + metadata.get('outputs', []) + metadata.get('compiled_sources', [])
    for capture in metadata.get('captures', []):
        rows += capture.get('artifacts', [])
    for image in metadata.get('images', []):
        rows += image['outputs']
    for row in rows:
        verify(row)
    record['captures'].append(dict(directory=name, status=status, source_parent=metadata.get('source_parent'),
        started_utc=metadata.get('started_utc'), finished_utc=metadata.get('finished_utc')))
    target = out / (name + '.tar.gz')
    with tarfile.open(target, 'w:gz') as archive:
        if name.startswith('mckernel-native-irq-images-'):
            # Retain compiler outputs, build recipes/logs and the actual guest
            # source trees, excluding the shared Git object database and old
            # verification archives copied by the source checkout.
            for item in sorted(path.iterdir()):
                if item.is_file():
                    archive.add(item, arcname=name + '/' + item.name)
            for relative in ('kernel', 'arch', 'lib', 'cmake', 'ihk/cokernel', 'ihk/ikc', 'ihk/include'):
                item = path / 'source' / relative
                if item.exists():
                    archive.add(item, arcname=name + '/source/' + relative)
            for relative in ('CMakeLists.txt', 'scripts/tests/test_mckernel_ikc_queue.py', 'scripts/tests/fixtures/mckernel_ikc_queue_compile.rs'):
                archive.add(path / 'source' / relative, arcname=name + '/source/' + relative)
            for variant in ('fallback', 'legacy-rust', 'native-rust'):
                for relative in ('kernel', 'CMakeCache.txt', 'compile_commands.json'):
                    archive.add(path / variant / relative, arcname=name + '/' + variant + '/' + relative)
        else:
            archive.add(path, arcname=name)
    assert target.stat().st_size < 95 << 20, target
    record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name, source=str(path),
        size=target.stat().st_size, sha256=digest(target)))
    for short in ('record.json', 'serial.log', 'debugcon.log'):
        if (path / short).exists():
            add(path / short, name + '-' + short + '.gz')
    print('Retained', name, status, flush=True)

stage = work / 'native-ikc-prototype-20260907-2/staged-source'
record['current_compiler_inputs'] = []
for path in sorted(stage.rglob('*')):
    if not path.is_file() or path.suffix not in ('.rs', '.S'):
        continue
    relative = 'host-kernel/native-rust/' + str(path.relative_to(stage))
    current = repo / relative
    row = dict(path=relative, size=current.stat().st_size, sha256=digest(current),
        compiler_size=path.stat().st_size, compiler_sha256=digest(path), transform='none')
    if current.read_bytes() != path.read_bytes():
        assert path.suffix == '.rs', relative
        formatted = out / ('formatted-' + path.name)
        formatted.write_bytes(current.read_bytes())
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(formatted)]
        subprocess.run(command, check=True)
        assert formatted.read_bytes() == path.read_bytes(), relative
        row['transform'] = command[:-1]
        add(current, 'native-ikc-completion-20260907-unformatted-' + path.name + '.gz')
    record['current_compiler_inputs'].append(row)
record['current_compiler_input_count'] = len(record['current_compiler_inputs'])
for name in ('check-native-ikc-completion.py', 'build-mckernel-native-boot-note-images.py',
             'verify-native-ikc-completion-images.py', 'restore-native-ikc-image.py',
             'build-native-ikc-prototype.py', 'run-native-ikc-guest.py', 'retain-native-ikc-completion.py'):
    add(work / name, 'native-ikc-completion-20260907-' + name + '.gz')
record['source_inputs'] = []
for relative in ('kernel/rust/ikc_queue.rs', 'kernel/rust/x86_setup.rs',
                 'scripts/tests/test_mckernel_ikc_queue.py', 'scripts/tests/fixtures/mckernel_ikc_queue_compile.rs',
                 'scripts/tests/fixtures/ihk_smp_image_compile.rs', 'scripts/native-boot-init.sh', 'scripts/tests/fixtures/native-boot.c'):
    path = repo / relative
    record['source_inputs'].append(dict(path=relative, size=path.stat().st_size, sha256=digest(path)))
    if relative.startswith('kernel/'):
        assert path.read_bytes() == (work / 'mckernel-native-irq-images-20260907-11/source' / relative).read_bytes()
reference = repo / 'docs/verification/native-ikc-handshake-checkpoint-20260907.json'
record['previous_reference'] = dict(path=str(reference.relative_to(repo)), size=reference.stat().st_size, sha256=digest(reference))
for row in record['artifacts']:
    count, unpacked = 0, hashlib.sha256()
    with gzip.open(out / Path(row['path']).name, 'rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            count += len(data)
            unpacked.update(data)
    if 'unpacked_sha256' in row:
        assert count == row['unpacked_size'] and unpacked.hexdigest() == row['unpacked_sha256']
record['status'] = 'PASS'
(out / 'native-ikc-completion-checkpoint-20260907.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained and verified', len(record['artifacts']), 'artifacts and', record['current_compiler_input_count'], 'module inputs', flush=True)
