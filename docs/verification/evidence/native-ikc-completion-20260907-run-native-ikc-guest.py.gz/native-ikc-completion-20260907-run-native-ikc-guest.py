from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, socket, struct, subprocess, sys, time

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
mode, module_attempt, attempt = sys.argv[1:]
assert mode in ('prepare', 'start-x86_64', 'start-i386')
repo = Path('/workspace')
compiled = Path('/work/native-ikc-prototype-20260907-' + module_attempt)
out = Path('/work/native-ikc-guest-20260907-' + mode + '-' + attempt)
images = Path('/work/mckernel-native-irq-images-20260907-11')
templates = Path('/work/native-trampoline-region-module-20260907-3')
built = json.loads((compiled / 'record.json').read_text())
assert built['status'] == 'PASS'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

for item in built['outputs']:
    assert identity(Path(item['path'])) == item, item
out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running', mode=mode,
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              inputs=[identity(compiled / 'record.json')], commands=[], captures=[],
              cpus=4, numa_nodes=2, memory_mib=8192, container_memory_mib=12288, cpuset=sorted(os.sched_getaffinity(0)),
              production_gate_credit=False, mckernel_boot_proven=False, declared_stage=False)
process = None
stream = None

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode))
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-12000:])

sequence = 0
def qmp(command, arguments=None):
    global sequence
    sequence += 1
    request = dict(execute=command, id=sequence)
    if arguments is not None: request['arguments'] = arguments
    stream.write((json.dumps(request) + '\n').encode()); stream.flush()
    while True:
        line = stream.readline()
        if not line: raise RuntimeError('QMP disconnected')
        result = json.loads(line)
        if result.get('id') != sequence: continue
        assert 'error' not in result, result
        return result['return']

def dump(physical, length, path):
    assert 0 <= physical < physical + length <= 256 << 30 and 0 < length <= 4 << 20
    response = qmp('human-monitor-command', {'command-line': 'pmemsave 0x%x %d "%s"' % (physical, length, path)})
    assert response == '', response
    assert path.stat().st_size == length
    return path.read_bytes()

def capture(serial, index, validate=True, resume=True):
    matches = re.findall(r'IHK-SMP: boot prepared os=(\d+) generation=(\d+) params=([0-9a-f]+) bytes=(\d+) trampoline=([0-9a-f]+) startup=([0-9a-f]+) cpus=(\d+) numa=(\d+) chunks=(\d+) kmsg=([0-9a-f]+)', serial)
    assert matches, 'No complete native preparation record'
    os_id, generation, params, length, trampoline, startup, cpus, nodes, chunks, kmsg = matches[-1]
    assert int(os_id) == 0
    params, trampoline, startup, kmsg = (int(value, 16) for value in (params, trampoline, startup, kmsg))
    length, cpus, nodes, chunks = (int(value) for value in (length, cpus, nodes, chunks))
    assert 7616 <= length <= 4 << 20 and trampoline == 0x80000
    target = out / ('capture-' + str(index)); target.mkdir()
    qmp('stop')
    try:
        data = dump(params, length, target / 'params.bin')
        low = dump(trampoline, 4096, target / 'trampoline.bin')
        startup_data = dump(startup, 4096, target / 'startup.bin')
        kmsg_data = dump(kmsg, 4 << 20, target / 'kmsg.bin')
        dump_count = struct.unpack_from('<I', data, 6636)[0]
        dump_bytes, dump_physical = struct.unpack_from('<QQ', data, 6640)
        dump_data = dump(dump_physical, dump_bytes, target / 'dump.bin')
        (target / 'registers.txt').write_text(qmp('human-monitor-command', {'command-line': 'info registers -a'}))
        (target / 'cpus.json').write_text(json.dumps(qmp('query-cpus-fast'), indent=2) + '\n')
        if mode != 'prepare' and validate:
            for offset, name in ((56, 'receive'), (64, 'send')):
                physical = struct.unpack_from('<Q', data, offset)[0]
                if physical:
                    dump(physical, 4096, target / ('queue-' + name + '.bin'))
    finally:
        if resume:
            qmp('cont')
    if not validate:
        record['emergency_capture'] = dict(directory=str(target),
            status=struct.unpack_from('<Q', data, 16)[0],
            artifacts=[identity(path) for path in sorted(target.iterdir()) if path.is_file()])
        save()
        print('Retained emergency boot capture', target, flush=True)
        return
    u64 = lambda offset: struct.unpack_from('<Q', data, offset)[0]
    u32 = lambda offset: struct.unpack_from('<I', data, offset)[0]
    assert u32(24) == length and (u64(40), u64(48)) == (kmsg, 4 << 20)
    assert (u32(6604), u32(6608), u32(6612), u32(6616), u32(6620)) == (4, cpus, nodes, chunks, 0)
    assert u32(4296) == 0xf6 and u64(4288) >= 0xffff800000000000
    assert struct.unpack_from('<4I', data, 4300) == (0, 1, 2, 3)
    assert all(struct.unpack_from('<4Q', data, 192))
    assert u64(128) % 4096 == 0 and u64(128) != 0 and u64(152) < 1 << 32
    assert u64(160) > 0 and u64(168) > 0 and 0 <= u64(184) < 1_000_000_000
    cpu_rows = [struct.unpack_from('<4i', data, 7616 + rank * 16) for rank in range(cpus)]
    node_offset = 7616 + cpus * 16
    node_rows = [struct.unpack_from('<2i', data, node_offset + rank * 8) for rank in range(nodes)]
    expected_cpus = [(1, 3, 3, 0), (0, 1, 1, 0)] if mode == 'prepare' else [(0, 1, 1, 0)]
    assert cpu_rows == expected_cpus, cpu_rows
    assert node_rows == ([(1, 0), (1, 1)] if mode == 'prepare' else [(1, 0)])
    chunk_offset = node_offset + nodes * 8
    chunk_rows = [struct.unpack_from('<QQi4x', data, chunk_offset + rank * 24) for rank in range(chunks)]
    assert all(start < end and start % 4096 == end % 4096 == 0 for start, end, node in chunk_rows)
    assert sum(end - start for start, end, node in chunk_rows) == (64 if mode == 'prepare' else 128) << 20
    assert all(node == (1 if mode == 'prepare' else 0) for start, end, node in chunk_rows)
    assert (u64(0), u64(8)) == (min(row[0] for row in chunk_rows), max(row[1] for row in chunk_rows))
    assert dump_count == chunks
    distance_offset = chunk_offset + chunks * 24
    distances = list(struct.unpack_from('<' + str(nodes * nodes) + 'I', data, distance_offset))
    assert all(distances[i * nodes + i] == 10 for i in range(nodes))
    assert all(distance >= 10 for distance in distances)
    if mode == 'prepare':
        root, stack, image_physical, actual_trampoline, entry = struct.unpack_from('<5Q', startup_data, 16)
        assert root == u64(152) and actual_trampoline == trampoline and entry >= 0xfffffffffe800000
        original_startup = bytearray((templates / 'native-startup.bin').read_bytes())
        struct.pack_into('<5Q', original_startup, 16, root, stack, image_physical, trampoline, entry)
        assert startup_data == bytes(original_startup) + bytes(4096 - len(original_startup))
        assert u64(16) == u64(56) == u64(64) == 0
        assert data[6348:6604] == b'y' * 255 + b'\0'
        original_low = bytearray((templates / 'native-trampoline.bin').read_bytes())
        struct.pack_into('<4Q', original_low, 8, root, startup, stack, params)
        assert low == original_low
        cursor = 0
        for start, end, node in chunk_rows:
            pages = (end - start) // 4096
            words = (pages + 63) // 64
            assert struct.unpack_from('<2Q', dump_data, cursor) == (start, words)
            for word in range(words):
                expected = (1 << min(64, pages - word * 64)) - 1
                assert struct.unpack_from('<Q', dump_data, cursor + 16 + word * 8)[0] == expected
            cursor += 16 + words * 8
        assert not any(dump_data[cursor:])
    else:
        assert u64(16) >= 2, ('McKernel did not reach architectural readiness', u64(16))
        # arch_start moves to STACK before allocator initialization. The existing
        # mem_numa_init_body_result / __ihk_numa_add_free_pages then clears and
        # reuses the startup page. Complete immutable-byte comparison belongs
        # to preparation; inspect the executing AP's actual image/CR3 here.
        root, actual_startup, stack, actual_params = struct.unpack_from('<4Q', low, 8)
        assert (root, actual_startup, actual_params) == (u64(152), startup, params)
        assert stack == u64(32) - 4096
        image_rows = re.findall(r'IHK-SMP: startup tables os=0 generation=' + generation + r' root=([0-9a-f]+) image=([0-9a-f]+)', serial)
        assert len(image_rows) == 1 and int(image_rows[0][0], 16) == root
        image_physical = int(image_rows[0][1], 16)
        assert any(start <= image_physical < image_physical + (8 << 20) <= end for start, end, node in chunk_rows)
        registers = (target / 'registers.txt').read_text().split('CPU#1\n')[1].split('CPU#2\n')[0]
        ip = int(re.search(r'RIP=([0-9a-f]+)', registers)[1], 16)
        cr3 = int(re.search(r'CR3=([0-9a-f]+)', registers)[1], 16)
        assert 0xfffffffffe800000 <= ip < 0xfffffffffe900000
        assert any(start <= cr3 < cr3 + 4096 <= end for start, end, node in chunk_rows)
        symbol = subprocess.check_output(['addr2line', '-e', str(images / 'native-rust/kernel/mckernel.img'), '-f', '-C', hex(ip)], text=True)
        (target / 'ap-symbol.txt').write_text(symbol)
        assert symbol.splitlines()[0] != '??', symbol
        assert data[6348:6604] == b'hidos' + bytes(251)
        for queue in (u64(56), u64(64)):
            assert queue % 4096 == 0 and any(start <= queue < queue + 4096 <= end for start, end, node in chunk_rows), queue
        for name in ('receive', 'send'):
            queue_data = (target / ('queue-' + name + '.bin')).read_bytes()
            assert struct.unpack_from('<IHHI', queue_data) == (0, 0, 56, 72)
            assert struct.unpack_from('<4Q', queue_data, 16) == (1, 1, 1, 4032)
        incoming = (target / 'queue-receive.bin').read_bytes()
        outgoing = (target / 'queue-send.bin').read_bytes()
        assert struct.unpack_from('<I', outgoing, 72)[0] == 0x10203010
        assert 'IHK-SMP: guest CONNECT os=0' in serial
        connection = re.search(r'IHK-SMP: guest CONNECT os=0 generation=\d+ irq_events=(\d+) packets=1 port=(\d+) packet_size=(\d+) receive=([0-9a-f]+) send=([0-9a-f]+) cookie=([0-9a-f]+) magic=(-?\d+) cpu=(-?\d+)', serial)
        assert connection and int(connection[1]) >= 1
        wire = struct.unpack_from('<7Q', incoming, 64)
        assert wire[2] == (int(connection[3]) << 32) | int(connection[2])
        assert wire[3:6] == tuple(int(connection[i], 16) for i in (4, 5, 6))
        assert wire[6] == ((int(connection[8]) & 0xffffffff) << 32) | (int(connection[7]) & 0xffffffff)
        lock, tail, capacity, head = struct.unpack_from('<4I', kmsg_data)
        assert capacity == (4 << 20) - 4096 and 0 <= head <= tail < capacity
        message = kmsg_data[4096 + head:4096 + tail].decode(errors='replace')
        (target / 'kmsg.txt').write_text(message)
        assert 'IHK/McKernel started.' in message and 'BSP: booted 0 AP CPUs' in message
        assert 'panic' not in message.lower()
        assert 'Master channel init acked.' in message
    result = dict(directory=str(target), os_generation=int(generation), status=u64(16), cpu_rows=cpu_rows,
                  node_rows=node_rows, chunks=chunk_rows, distances=distances, params_physical=params,
                  startup_physical=startup, image_physical=image_physical, root_physical=root,
                  kmsg_physical=kmsg, queue_receive=u64(56), queue_send=u64(64),
                  artifacts=[identity(path) for path in sorted(target.iterdir()) if path.is_file()])
    record['captures'].append(result); save()
    print('Captured and checked', target, 'guest status', u64(16), flush=True)

try:
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copytree(Path('/work/native-runtime-local-base-24a151fe/root'), out / 'root')
    shutil.copyfile(repo / 'scripts/native-boot-init.sh', out / 'root/init')
    (out / 'root/init').chmod(0o755)
    (out / 'root/boot-mode').write_text(mode + '\n')
    run('shell-syntax', ['bash', '-n', str(out / 'root/init')])
    for name in ['ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko']:
        shutil.copyfile(compiled / name, out / 'root/modules' / name)
    probe = out / 'probe-source'; probe.mkdir()
    for name in ['native-boot.c', 'native-os-resource-assignment.c', 'native-memory-reservation.c', 'native-cpu-reservation.c']:
        shutil.copyfile(repo / 'scripts/tests/fixtures' / name, probe / name)
    states = re.findall(r'pub const cpuhp_state_CPUHP_AP_ACTIVE: cpuhp_state = ([0-9]+);', (compiled / 'bindings_generated.rs').read_text())
    assert len(states) == 1
    for bits, architecture in [(64, 'x86_64'), (32, 'i386')]:
        command = ['cc', '-m' + str(bits), '-O2', '-Wall', '-Wextra', '-Werror', '-ffreestanding', '-fno-builtin', '-fno-stack-protector', '-fno-pie', '-nostdlib', '-static', '-no-pie', '-Wl,-e,_start', '-Wl,-z,noexecstack', '-DCPUHP_FAILURE_STATE=' + states[0], '-DBOOT_PREPARE_ONLY=' + str(int(mode == 'prepare')), str(probe / 'native-boot.c'), '-o', str(out / 'root/bin' / ('native-boot-' + architecture))]
        run('probe-build-' + architecture, command)
    image_dir = out / 'root/images'; image_dir.mkdir()
    for variant, filename in [('native-rust', 'mckernel.img'), ('legacy-rust', 'legacy.img')]:
        shutil.copyfile(images / variant / 'kernel/mckernel.img', image_dir / filename)
    old_image = Path('/work/mckernel-native-irq-images-20260907-10/native-rust/kernel/mckernel.img')
    record['inputs'].append(identity(old_image))
    shutil.copyfile(old_image, image_dir / 'native-v1.img')
    environment = dict(os.environ, RUNTIME_EVIDENCE=str(out), INITRAMFS_ROOT=str(out / 'root'))
    subprocess.run(['python3', '-B', '/work/write-native-cpio-spec.py'], env=environment, check=True)
    with (out / 'initramfs.cpio.gz').open('wb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            creator = subprocess.Popen(['/work/native-runtime-24a151fe/gen_init_cpio', '-t', '0', str(out / 'initramfs.list')], stdout=subprocess.PIPE)
            shutil.copyfileobj(creator.stdout, output); creator.stdout.close(); assert creator.wait() == 0
    args = ['/usr/libexec/qemu-kvm', '-machine', 'q35', '-accel', 'tcg,thread=multi', '-cpu', 'max,la57=off',
            '-smp', '4,sockets=2,cores=2,threads=1', '-m', '8192',
            '-object', 'memory-backend-ram,size=4G,id=ram-node0', '-object', 'memory-backend-ram,size=4G,id=ram-node1',
            '-numa', 'node,nodeid=0,cpus=0-1,memdev=ram-node0', '-numa', 'node,nodeid=1,cpus=2-3,memdev=ram-node1',
            '-kernel', str(compiled / 'bzImage'), '-initrd', str(out / 'initramfs.cpio.gz'),
            '-append', 'console=ttyS0,115200n8 rdinit=/init nokaslr panic=-1 memmap=4K%0x80000-1',
            '-qmp', 'unix:' + str(out / 'qmp.sock') + ',server=on,wait=off', '-monitor', 'none',
            '-serial', 'file:' + str(out / 'serial.log'), '-debugcon', 'file:' + str(out / 'debugcon.log'),
            '-global', 'isa-debugcon.iobase=0xe9', '-display', 'none', '-no-reboot', '-nic', 'none']
    if mode != 'prepare':
        args += ['-no-shutdown']
    record['qemu_args'] = args
    record['inputs'] += [identity(path) for path in [compiled / 'bzImage', out / 'initramfs.cpio.gz', templates / 'native-startup.bin', templates / 'native-trampoline.bin']]
    record['inputs'] += [identity(path) for path in sorted(probe.iterdir())]
    save()
    with (out / 'qemu.log').open('wb') as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 600
        while not (out / 'qmp.sock').exists():
            assert process.poll() is None and time.monotonic() < deadline
            time.sleep(0.05)
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        connection.settimeout(20); connection.connect(str(out / 'qmp.sock'))
        stream = connection.makefile('rwb')
        assert 'QMP' in json.loads(stream.readline())
        qmp('qmp_capabilities')
        seen = 0
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Guest timeout'
            serial = (out / 'serial.log').read_text(errors='replace') if (out / 'serial.log').exists() else ''
            if mode != 'prepare':
                vm_state = qmp('query-status')
                if vm_state['status'] in ('shutdown', 'guest-panicked'):
                    record['terminal_vm_state'] = vm_state
                    assert 'NATIVE_BOOT_GUEST START_CAPTURE incomplete=1 restoration_proven=0' in serial, vm_state
                    qmp('quit')
                    process.wait(timeout=15)
                    break
            for bad in ['NATIVE_BOOT_GUEST FAIL', ' FAIL line=', 'Kernel panic', 'BUG:', 'Oops:', 'WARNING:', 'rcu_preempt detected stalls', 'soft lockup', 'hard LOCKUP']:
                assert bad not in serial, bad
            ready = len(re.findall(r'NATIVE_BOOT_CAPTURE (?:x86_64|i386) ready', serial))
            if ready > seen:
                assert ready == seen + 1
                capture(serial, seen); seen += 1
            time.sleep(0.1)
        assert process.returncode == 0, process.returncode
    serial = (out / 'serial.log').read_text(errors='replace')
    if mode == 'prepare':
        assert 'NATIVE_BOOT_GUEST PREPARATION PASS' in serial
        assert len(record['captures']) == 4
        for architecture in ('x86_64', 'i386'):
            assert serial.count('NATIVE_BOOT_PREPARATION ' + architecture + ' PASS cycles=8 failures=8 exclusive=1 restored=1') == 2
        assert 'IHK-SMP: CPU start ' not in serial
    else:
        assert 'NATIVE_BOOT_GUEST START_CAPTURE incomplete=1 restoration_proven=0' in serial
        assert len(record['captures']) == 1
        assert 'IHK-SMP: CPU start os=0' in serial
        assert 'IHK-SMP: guest boot progress os=0' in serial
    for item in record['inputs']:
        assert identity(Path(item['path'])) == item, item
    record.update(status='PASS', scope=('Unstarted preparation, independent physical snapshots and resource restoration' if mode == 'prepare' else 'Actual INIT_ACK delivery, guest CONNECT via real Linux IRQ-work, queue readback and failed-boot retention; listener/full boot pending'))
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    if mode != 'prepare' and stream is not None and process is not None and process.poll() is None:
        try:
            serial = (out / 'serial.log').read_text(errors='replace')
            if 'IHK-SMP: boot prepared os=0' in serial:
                capture(serial, 'emergency', validate=False, resume=False)
        except BaseException as capture_error:
            record['emergency_capture_error'] = str(capture_error)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired: process.kill(); process.wait()
    if stream is not None: stream.close()
    record['qemu_exit_code'] = None if process is None else process.returncode
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(record['status'], out, flush=True)
