"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-signals-retained-20260909-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-signals-checkpoint-20260909.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Unchanged actual McKernel signals application PASS with repeated alternate stack, actual sigreturns and host returns, full normal cleanup and original boot/continuing/HELLO checks. All four core categories have separate accepted inputs; abnormal-owner and final current-pair replay/control gates remain pending.',artifacts=[],captures=[],native_compiler_bindings=[],source_bindings=[],references=[],application_readiness_complete=False,actual_signals_guest_pass=True)
captures=[('native-application-signals-module-20260909-1','PASS'),('native-application-signals-signals-guest-20260909-1','PASS')]
try:
    shutil.copyfile(__file__,out/'helper.py')
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,(name,state['status'])
        for key in ['inputs','outputs','compiler_inputs']:
            for row in state.get(key,[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        artifact(directory,name+'.tar.gz',True)
        record['captures'].append(dict(name=name,original_status=expected,record=identity(directory/'record.json')))
    compiled=work/'native-application-signals-module-20260909-1'
    dependencies='\n'.join(path.read_text() for path in (compiled/'module-build').rglob('*.cmd'))
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert '/work/native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel/'+str(relative) in dependencies,str(relative)
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout);assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo));row.update(binding='exact pinned rustfmt replay',compiler_capture=str(saved),formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    assert len(record['native_compiler_bindings'])==57
    artifact(out/'format-replay','native-application-signals-20260909-format-replay.tar.gz',True)
    for relative,saved in [
        ('host-kernel/native-rust/mcctrl_process.rs','native-application-trace-adapter-20260909-2/original-inputs/host-kernel/native-rust/mcctrl_process.rs'),
        ('scripts/tests/fixtures/native-application-return-adapter.rs','native-application-trace-adapter-20260909-2/native-application-return-adapter.rs'),
        ('scripts/tests/fixtures/native-application-core.c','native-application-core-build-20260908-1/native-application-core.c'),
        ('host-kernel/native-rust/smp_application.rs','native-application-committed-return-20260909-2/original-inputs/host-kernel/native-rust/smp_application.rs')]:
        record['source_bindings'].append(binding(repo/relative,work/saved))
    checks=work/'native-application-zeroing-objtool-checks-20260909-1'
    assert (checks/'check-after.c').read_bytes()==(work/'native-source/linux-6.12.0-211.44.1.el10_2/tools/objtool/check.c').read_bytes()
    assert (checks/'objtool-after').read_bytes()==(work/'native-build-base-24a151fe/tools/objtool/objtool').read_bytes()
    record['current_objtool_matches_retained_zeroing_controls']=True
    guest=work/'native-application-signals-signals-guest-20260909-1';state=json.loads((guest/'record.json').read_text())
    assert state['status']=='PASS' and state['qemu_exit_code']==0
    assert state['core_application']['case']=='signals' and state['core_application']['exit_code']==37 and state['core_application']['stdout']=='NATIVE_CORE PASS signals\n'
    assert state['native_application']['applications']==8 and state['native_application']['no_process_nodes_after_each']
    assert state['native_signal_application']['actual_sigreturn_results']==[0,0]
    assert state['native_signal_application']['blocked_pending_unblocked_and_repeated_altstack_assertions_passed']
    assert state['native_signal_application']['interrupted_host_return_errors']==0
    assert state['file_pager_lifetime']['all_created_handles_released']
    for name in ['native_application','core_application','native_signal_application','native_signal_stack_image_selection','allocator_zeroing','host_invalidations','file_pager_lifetime','native_string_copy','boot_probe_adaptation']:record[name]=state[name]
    assert state['boot_probe_adaptation']['kernel_command_line']=='hidos allow_oversubscribe'
    for saved in (guest/'boot-probe-original').iterdir():
        if saved.name=='native-boot.c':
            a=saved.read_text();b=(guest/'boot-probe-source'/saved.name).read_text();assert a.count('(long)"hidos"')==1 and b==a.replace('(long)"hidos"','(long)"hidos allow_oversubscribe"')
        else:assert saved.read_bytes()==(guest/'boot-probe-source'/saved.name).read_bytes()
    assert (guest/'root/images/mckernel.img').read_bytes()==(work/'mckernel-native-signals-images-20260909-2/native-rust/kernel/mckernel.img').read_bytes()
    for name in ['ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko']:assert (guest/'root/modules'/name).read_bytes()==(compiled/name).read_bytes()
    assert (guest/'root/bin/mcexec').read_bytes()==(work/'native-application-launcher-20260908-2/rust/executer/user/mcexec').read_bytes()
    assert (guest/'root/bin/native-application-core').read_bytes()==(work/'native-application-core-build-20260908-1/native-application-core').read_bytes()
    serial=(guest/'serial.log').read_text();kmsg=(guest/'capture-application/kmsg.txt').read_text()
    assert 'ret: ' not in serial and 'NATIVE_CORE FAIL' not in serial
    pid=str(state['core_application']['pid'])
    frames=re.findall(r'signal_handler pid='+pid+r' tid='+pid+r' sig=10 handler=(0x[0-9a-f]+) restorer=(0x[0-9a-f]+) old_rip=(0x[0-9a-f]+) old_sp=(0x[0-9a-f]+) new_sp=(0x[0-9a-f]+)',kmsg)
    assert frames==[tuple(row) for row in state['native_signal_application']['frames']]
    assert len(frames)==2 and frames[0][4]==frames[1][4]
    for relative in ['docs/verification/native-application-signals-images-checkpoint-20260909.json','docs/verification/native-application-signals-protocol-checkpoint-20260909.json','docs/verification/native-application-threads-checkpoint-20260909.json','docs/verification/native-application-core-checkpoint-20260909.json','docs/verification/native-application-zeroing-host-checkpoint-20260909.json']:
        row=identity(repo/relative);row['path']=relative;record['references'].append(row)
    artifact(out/'helper.py','native-application-signals-20260909-retention-helper.gz')
    record.update(status='PASS',complete_captures=2,original_failures=0,native_modules=3,artifact_bytes=sum(row['size'] for row in record['artifacts']))
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');(out/'record.json').write_bytes(manifest.read_bytes());print(record['status'],manifest,flush=True)
