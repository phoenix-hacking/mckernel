#!/usr/bin/python3
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

REPO = Path("/home/holden/mckernel")
SUPERVISOR = REPO / "scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/supervisor_host38.py"
ATTEMPT = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-run-20260915-1-outer")
INVOCATION = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-run-20260915-1-invocation.json")
RESULT = Path("/home/holden/mckernel-work/scratch/stability-linux-adverse-run-20260915-1-outer-result.json")
ARGV = [
    "/usr/bin/python3", "-I", "-B",
    str(REPO / "scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/adverse-v1/root_orchestrator.py"),
    "--packet", str(REPO / "scripts/tests/fixtures/application-collector-v1/linux-sealed-v1/adverse-v1/packet.json"),
    "--build-record", "/home/holden/mckernel-work/scratch/stability-linux-adverse-build-20260915-1/profile/work/build/build-record.json",
    "--attempt-root", "/home/holden/mckernel-work/scratch/stability-linux-adverse-run-20260915-1",
]
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "TZ": "UTC"}


def write_new(path, value):
    descriptor = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}


write_new(INVOCATION, {
    "schema_version": 1,
    "status": "PREPARED_BEFORE_LAUNCH",
    "prepared_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "argv": ARGV,
    "cwd": str(REPO),
    "env": ENV,
    "timeout_seconds": 420,
    "cleanup_timeout_seconds": 30,
    "stdout_limit_bytes": 16777216,
    "stderr_limit_bytes": 16777216,
    "supervisor": identity(SUPERVISOR),
})

spec = importlib.util.spec_from_file_location("accepted_supervisor_host38", str(SUPERVISOR))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = module.run_supervised(
    ARGV,
    cwd=str(REPO),
    env=ENV,
    attempt_dir=str(ATTEMPT),
    timeout_seconds=420,
    cleanup_timeout_seconds=30,
    stdout_limit_bytes=16777216,
    stderr_limit_bytes=16777216,
)
write_new(RESULT, {
    "schema_version": 1,
    "status": "OUTER_SUPERVISOR_RETURNED",
    "returned_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "report": report,
})
print(json.dumps(report, sort_keys=True))
if report.get("status") != "COMPLETED" or report.get("raw_wait_status") != 0:
    sys.exit(1)
