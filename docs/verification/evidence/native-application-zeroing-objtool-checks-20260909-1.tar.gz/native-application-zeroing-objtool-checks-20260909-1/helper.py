"""Retained real object, exact objtool flags, positive and unknown-callee controls."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shlex,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work');source=work/'native-source/linux-6.12.0-211.44.1.el10_2';build=work/'native-build-base-24a151fe'
out=work/('native-application-zeroing-objtool-checks-20260909-'+sys.argv[1]);out.mkdir()
review=work/'native-application-zeroing-objtool-review-20260909-1';failed=work/'native-application-zeroing-module-diagnosis-20260909-1/failed-module-build'
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],checks=[],files=[],scope='Actual objtool before/after exact Rust noreturn adaptation; unchanged emitted module and unknown-symbol negatives. No kernel runtime acceptance.')
def identity(path):return dict(path=str(path),size=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def run(label,args):
    print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
    with (out/(label+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=result.returncode))
    assert result.returncode==0,(label,(out/(label+'.log')).read_text()[-8000:])
try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['objtool-before','check-before.c','vec-mod.rs','alloc-symbols.txt','rustc-version.txt','alloc-command.txt']:
        shutil.copyfile(review/name,out/name)
    (out/'objtool-before').chmod(0o755)
    assert (source/'tools/objtool/check.c').read_bytes()==(out/'check-before.c').read_bytes()
    obj=failed/'ihk_smp_x86_64.o';shutil.copyfile(obj,out/'original.o')
    patch=repo/'host-kernel/rocky/patches/0025-objtool-recognize-rust-1.92-vec-swap-remove-panic.patch';shutil.copyfile(patch,out/patch.name)
    saved=(failed/'.ihk-smp-x86_64.o.cmd').read_text().splitlines()[0];(out/'objtool-command.txt').write_text(saved+'\n')
    arguments=shlex.split(saved.split(';',1)[1]);assert arguments[0]=='./tools/objtool/objtool';flags=arguments[1:-1]
    symbols=subprocess.check_output(['nm','-u',str(obj)],text=True).splitlines();panics=[line.split()[-1] for line in symbols if 'E11swap_remove13assert_failed' in line];assert len(panics)==1
    record['panic_symbol']=panics[0]
    assert panics[0] in (out/'alloc-symbols.txt').read_text()
    text=(out/'vec-mod.rs').read_text();start=text.index('pub fn swap_remove(');end=text.index('\n    }',start)+6
    assert re.search(r'fn assert_failed\(index: usize, len: usize\) -> !',text[start:end])
    def check(label,tool,rename,expected):
        raw=out/(label+'.raw.o');shutil.copyfile(obj,raw)
        if rename:run(label+'-rename',['llvm-objcopy','--redefine-sym',panics[0]+'='+rename,str(raw)])
        linked=out/(label+'.o');run(label+'-link',['ld.lld','-m','elf_x86_64','-z','noexecstack','-r','-o',str(linked),str(raw)])
        before=identity(linked);command=[str(tool)]+flags+[str(linked)]
        result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (out/(label+'.log')).write_text(result.stdout);failures=result.stdout.count('falls through to next function')
        record['checks'].append(dict(label=label,command=command,before=before,after=identity(linked),exit_code=result.returncode,expected_failures=expected,actual_failures=failures))
        assert failures==expected and (result.returncode!=0)==(expected!=0),(label,result.stdout)
    check('before',out/'objtool-before',None,2)
    run('apply-check',['git','-C',str(source),'apply','--check',str(patch)])
    run('apply',['git','-C',str(source),'apply',str(patch)])
    base=shlex.split((work/'native-irq-transport-exact-stage-20260907-1/module-build.command').read_text())
    assert all(name.endswith('.ko') for name in base[-3:])
    run('objtool-build',base[:-3]+['tools/objtool'])
    shutil.copyfile(build/'tools/objtool/objtool',out/'objtool-after');(out/'objtool-after').chmod(0o755)
    shutil.copyfile(source/'tools/objtool/check.c',out/'check-after.c')
    check('after',out/'objtool-after',None,0)
    check('unknown-suffix',out/'objtool-after',panics[0]+'_unknown_callee',2)
    check('wrong-function',out/'objtool-after',panics[0].replace('swap_remove','swap_return'),2)
    check('not-rust',out/'objtool-after',panics[0][2:],2)
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['files']=[identity(path) for path in sorted(out.iterdir()) if path.is_file() and path.name not in ('record.json','phase')]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
