from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, subprocess
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
base = Path('/work/native-irq-transport-declared-validation-20260907-1')
base.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), results=[],
              source_parent=subprocess.check_output(['git', '-C', '/workspace', 'rev-parse', 'HEAD'], text=True).strip(),
              recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), production_gate_credit=False)
commands = [
    ['python3', '-B', '/work/build-native-irq-transport-exact-stage.py'],
    ['python3', '-B', '/work/check-native-irq-transport-exact-stage-modules.py'],
    ['python3', '-B', '/work/run-native-irq-image-load-guest.py', '/work/native-irq-transport-exact-stage-20260907-1', '/work/native-irq-transport-image-guest-20260907-1'],
    ['python3', '-B', '/work/run-native-irq-transport-full-tests.py', '1'],
]
for index, command in enumerate(commands):
    print('Starting declared transport validation step', index, command, flush=True)
    with (base / ('step-' + str(index) + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd='/workspace', stdout=log, stderr=subprocess.STDOUT)
    record['results'].append(dict(command=command, exit_code=result.returncode))
    record['updated_utc'] = datetime.now(timezone.utc).isoformat()
    record['exit_code'] = result.returncode
    (base / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print('Completed declared transport validation step', index, 'exit', result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
