from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-fault-guest-preparation-20260913-5'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(), inputs=[],
              application_acceptance=False, transport_acceptance=False, guest_execution=False)
def identity(p):
    data = p.read_bytes()
    return dict(path=str(p), size=len(data), sha256=hashlib.sha256(data).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    hashes = {'scripts/tests/prepare_stability_fault_guest.py':'6b7135c77f1c9bc5f82c5de3626aad1f86b72e5b72b9d803e99f32bc615ad67f','scripts/application-tests/supervisor.py':'8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'}
    for name, digest in hashes.items():
        src = repo / name
        assert identity(src)['sha256'] == digest
        dst = out / name; dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        record['inputs'].append(dict(original=identity(src), retained=identity(dst)))
    shutil.copyfile(out / 'scripts/application-tests/supervisor.py', out / 'supervisor.py')
    spec = importlib.util.spec_from_file_location('supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    argv = ['/usr/bin/python3', '-B', str(out / 'scripts/tests/prepare_stability_fault_guest.py'), '--module', '/work/stability-transport-fault-module-20260913-prepublish-hard-3', '--mode', 'prepublish-hard', '--payload-profile', 'runnable-thread-v1', '--controller-profile', 'owner-phase-v2', '--nonce', '96898e84a003ee0f44cd3d8ca2d42748', '--output', '/work/stability-fault-guest-root-20260913-prepublish-hard-5']
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    record.update(command=argv, environment=env); save()
    result = supervisor.run_supervised(argv, cwd=str(out), env=env, attempt_dir=str(out / 'collection'),
        timeout_seconds=120, cleanup_timeout_seconds=15, stdout_limit_bytes=8*1024**2, stderr_limit_bytes=8*1024**2)
    record['collection'] = result; save()
    assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete']
    prepared = json.loads((work / 'stability-fault-guest-root-20260913-prepublish-hard-5/record.json').read_text())
    assert prepared['status'] == 'PREPARED_NOT_EXECUTED'
    record['prepared_record'] = identity(work / 'stability-fault-guest-root-20260913-prepublish-hard-5/record.json')
    for row in record['inputs']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    record.update(status='PASS_PREPARED_NO_GUEST_EXECUTION')
except BaseException as exc:
    record.update(status='FAIL', error_type=type(exc).__name__, error=str(exc)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save()
    print(record['status'], out, flush=True)
