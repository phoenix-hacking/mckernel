/work/native-vdso-module-20260907-1/source/scripts/tests/fixtures/mckernel_vdso_verify.o
