from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shlex, shutil, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
build = Path('/work/native-build-base-24a151fe')
kernel = Path('/work/native-vdso-kernel-20260907-3')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
out = Path('/work/native-vdso-module-20260907-' + sys.argv[1]); out.mkdir()
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    inputs=[], commands=[], production_gate_credit=False, vdso_service_completed=False)

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), size=len(data), sha256=hashlib.sha256(data).hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-5000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    for current, retained in [(build / '.config', kernel / 'resolved.config'),
                              (build / 'Module.symvers', kernel / 'Module.symvers'),
                              (build / 'rust/bindings/bindings_generated.rs', kernel / 'bindings_generated.rs')]:
        assert current.read_bytes() == retained.read_bytes(), current
        record['inputs'].append(identity(retained))
    module = out / 'source/scripts/tests/fixtures'; module.mkdir(parents=True)
    fixture = repo / 'scripts/tests/fixtures/mckernel_vdso_verify.rs'
    shutil.copyfile(fixture, module / fixture.name)
    record['repository_input'] = identity(fixture)
    shutil.copyfile(__file__, out / 'helper.py')
    (module / 'Kbuild').write_text('obj-m += mckernel_vdso_verify.o\n')
    run('format', ['rustfmt', '--edition', '2021', str(module / fixture.name)])
    record['inputs'].append(identity(module / fixture.name))
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('module-build', base + ['M=' + str(module), 'modules'])
    compiled = out / 'mckernel_vdso_verify.ko'
    shutil.copyfile(module / compiled.name, compiled)
    run('layout-extract', ['objcopy', '--dump-section', '.mckernel_native_vdso_layout=' + str(out / 'rust-layout.bin'),
                          str(compiled), str(out / 'layout-copy.ko')])
    assert (out / 'rust-layout.bin').read_bytes() == (kernel / 'native-vdso-layout.bin').read_bytes()
    record['inputs'].append(identity(kernel / 'native-vdso-layout.bin'))
    record['c_and_rust_layout_values'] = 44
    for tool, name in [(['nm', '-u'], 'undefined.txt'), (['objdump', '-d'], 'disassembly.txt'),
                       (['readelf', '-h'], 'elf-header.txt')]:
        (out / name).write_bytes(subprocess.check_output(tool + [str(compiled)]))
    symbols = (out / 'undefined.txt').read_text()
    for name in ('vdso_image_64', 'vdso_k_time_data', 'vdso_k_rng_data', 'ktime_get_real_seconds', 'msleep'):
        assert ' U ' + name + '\n' in symbols, name
    assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|mm[0-7])\b', (out / 'disassembly.txt').read_text())
    assert 'ELF64' in (out / 'elf-header.txt').read_text()
    for row in record['inputs']: assert identity(Path(row['path'])) == row, row
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                         if path.is_file() and path.name not in ('record.json', 'phase')]
    save(); print(record['status'], out, flush=True)
