struct remote_snooping_param {
	ihk_device_t dev;
	int nbits;
	int size;
	long phys;
	void *ptr;
};
static inline int
bitmap_scnprintf(char *buf, unsigned buflen, const unsigned long *maskp, int nmaskbits)
{
	return scnprintf(buf, buflen, "%*pb\n", nmaskbits, maskp);
}
static inline int
bitmap_scnlistprintf(char *buf, unsigned buflen, const unsigned long *maskp, int nmaskbits)
{
	return scnprintf(buf, buflen, "%*pbl\n", nmaskbits, maskp);
}
static ssize_t snooping_remote_show_d32(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%d\n", *(int *)p->ptr);
}
static ssize_t snooping_remote_show_d64(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%ld\n", *(long *)p->ptr);
}
static ssize_t snooping_remote_show_u32(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%u\n", *(unsigned *)p->ptr);
}
static ssize_t snooping_remote_show_u64(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%lu\n", *(unsigned long *)p->ptr);
}
static ssize_t snooping_remote_show_s(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%.*s\n", (int)p->size, (char *)p->ptr);
}
static ssize_t snooping_remote_show_pbl(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return bitmap_scnlistprintf(buf, bufsize, p->ptr, p->nbits);
}
static ssize_t snooping_remote_show_pb(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return bitmap_scnprintf(buf, bufsize, p->ptr, p->nbits);
}
static ssize_t snooping_remote_show_u32K(struct sysfsm_ops *ops, void *instance, void *buf, size_t bufsize)
{
	struct sysfsm_node *np = instance;
	struct remote_snooping_param *p = (void *)np->client_instance;

	return sprintf(buf, "%uK\n", (*(unsigned *)p->ptr >> 10));
}
