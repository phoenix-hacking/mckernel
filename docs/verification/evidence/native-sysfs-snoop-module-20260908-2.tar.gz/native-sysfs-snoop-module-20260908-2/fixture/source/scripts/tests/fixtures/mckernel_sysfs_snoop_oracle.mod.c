#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.arch = MODULE_ARCH_INIT,
};

KSYMTAB_FUNC(mckernel_sysfs_snoop_oracle, "_gpl", "");

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "F686CEC9ADB0E06F353283A");
MODULE_INFO(rhelversion, "10.2");
