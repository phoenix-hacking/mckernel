from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shlex,shutil
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo,work=Path('/workspace'),Path('/work');out=work/'stability-guest-collection-build-20260913-2';out.mkdir();(out/'tmp').mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],compiler_dependencies=[],compiled_outputs=[],application_acceptance=False,transport_acceptance=False,production_gate_credit=False,scope='Compile guarded artifact exporter, reuse exact owner utility ELFs from failed build1, execute synthetic phase metadata and retained receiver tests; no guest/device/payload execution')
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 assert shutil.disk_usage(work).free>3*1024**3
 shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(repo/'scripts/application-tests/supervisor.py',out/'supervisor.py')
 spec=importlib.util.spec_from_file_location('supervisor',out/'supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(out/'tmp'))
 def run(label,argv,timeout=120):
  if not Path(argv[0]).is_absolute():argv[0]=shutil.which(argv[0],path=env['PATH'])
  record['phase']=label;save();print('RUN',label,flush=True)
  result=supervisor.run_supervised(argv,cwd=str(out),env=env,attempt_dir=str(out/(label+'-collection')),timeout_seconds=timeout,cleanup_timeout_seconds=15,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['raw_wait_status']==0 and result['cleanup_complete'],(label,result['status'],result['wait_status'])
  return (out/(label+'-collection')/'stdout.bin').read_text()
 owner=repo/'scripts/tests/fixtures/stability-transport-fault/owner-phase-v1'
 for name in ['controller.c','phase_client.h','after_hello.c','phase_metadata_harness.c','README.md','controller.original.c','controller.forward.patch','controller.inverse.patch']:
  p=owner/name;q=out/'owner-phase'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);record['inputs'].append(dict(original=identity(p),retained=identity(q)))
 p=repo/'scripts/tests/fixtures/stability-artifact-export/exporter.c';q=out/'exporter.c';shutil.copyfile(p,q);record['inputs'].append(dict(original=identity(p),retained=identity(q)))
 prior=work/'stability-guest-collection-build-20260913-1'
 prior_record=json.loads((prior/'record.json').read_text());assert prior_record['status']=='FAIL' and prior_record['phase']=='artifact-exporter-compile'
 record['prior_attempt_record']=identity(prior/'record.json')
 for row in prior_record['compiled_outputs']:
  assert identity(Path(row['path']))==row
 record['reused_compiled_outputs']=prior_record['compiled_outputs']
 for row in prior_record['inputs']:
  if '/owner-phase/' in row['retained']['path']:
   assert identity(Path(row['retained']['path']))==row['retained']
   assert identity(out/'owner-phase'/Path(row['retained']['path']).name)['sha256']==row['retained']['sha256']
 fixture=repo/'scripts/tests/fixtures/stability-artifact-export'
 for name in ['receiver.py','test_receiver.py','protocol.md']:
  src=fixture/name;dst=out/name;shutil.copyfile(src,dst);record['inputs'].append(dict(original=identity(src),retained=identity(dst)))
 assert identity(out/'exporter.c')['sha256']=='af85d0c692a1df677c2df7c9cbb5ee85fcf8b7dc31d2b14527675a3dc903fb6c'
 assert identity(out/'receiver.py')['sha256']=='aa9e165044e9567c992a0354dacdc49b884794b31841a3871d977eeae9c8c5d9'
 assert identity(out/'test_receiver.py')['sha256']=='741476fb5962132dd2c4964909ae843dd69ebfa8879300e8e98890296ea0b9ce'
 assert identity(out/'owner-phase/phase_client.h')['sha256']=='03f17078369078898dfafc97b064b29a349efd6f758d9e7895f5cdb91579d9c7'
 record['native_phase_record']=identity(work/'stability-transport-fault-module-20260913-prepublish-hard-2/record.json')
 run('compiler-version',['gcc','--version'])
 for label,p in [('artifact-exporter',out/'exporter.c')]:
  obj=out/(label+'.o');elf=out/(label+'.elf');deps=out/(label+'.d')
  run(label+'-compile',['gcc','-std=c11','-D_GNU_SOURCE','-O2','-g','-Wall','-Wextra','-Werror','-fno-pie','-pthread','-MD','-MF',str(deps),'-I',str(repo/'executer/include'),'-c',str(p),'-o',str(obj)])
  run(label+'-link',['gcc','-no-pie','-pthread',str(obj),'-Wl,-Map='+str(out/(label+'.map')),'-o',str(elf)])
  run(label+'-elf',['readelf','-h','-l','-d',str(elf)])
  data=run(label+'-loader-trace',['ldd',str(elf)])
  for line in data.splitlines():
   for part in line.split():
    if part.startswith('/') and Path(part).is_file():record.setdefault('loader_dependencies',[]).append(identity(Path(part)))
  deptext=deps.read_text().replace('\\\n',' ');_,items=deptext.split(':',1)
  for item in shlex.split(items):
   p=Path(item)
   if not p.is_absolute():p=out/p
   row=identity(p)
   if row not in record['compiler_dependencies']:record['compiler_dependencies'].append(row)
  record['compiled_outputs'] += [identity(p) for p in (obj,elf,deps,out/(label+'.map'))]
 result=run('phase-metadata-tests',[str(prior/'phase-metadata.elf')]);record['phase_metadata_stdout']=result
 observed=json.loads(result);assert observed['status']=='PASS' and observed['failures']==0 and observed['scope']=='synthetic-owner-phase-metadata-only'
 run('artifact-receiver-tests',['python3','-B',str(out/'test_receiver.py')],timeout=120)
 for row in record['inputs']:
  assert identity(Path(row['original']['path']))==row['original'] and identity(Path(row['retained']['path']))==row['retained']
 record.update(status='PASS_BUILD_AND_SYNTHETIC_COLLECTION_TESTS_ONLY',guest_execution=False,controller_executed=False,exporter_executed=False,payload_executed=False)
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
