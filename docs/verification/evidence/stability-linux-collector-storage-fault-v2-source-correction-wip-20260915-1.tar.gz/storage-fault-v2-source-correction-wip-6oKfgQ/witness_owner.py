#!/usr/bin/env python3
"""Direct, durable owner for the storage-fault-v2 collector (not a release)."""
import argparse
import ctypes
import errno
import hashlib
import json
import os
import select
import signal
import socket
import stat
import time
from pathlib import Path

WITNESS_FD = 198
PACKET_MAX = 4096
PACKET_LIMIT = 32
ACK_SECONDS = 2
OUTER_CLEANUP_SECONDS = 22
PR_SET_CHILD_SUBREAPER = 36

def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("nonfinite")))

def process_identity(pid):
    raw = Path("/proc/%d/stat" % pid).read_bytes()
    close = raw.rfind(b")")
    if close < 0:
        raise ValueError("proc stat")
    prefix = raw[:close + 1]
    open_paren = prefix.find(b"(")
    fields = raw[close + 2:].split()
    if open_paren < 1 or len(fields) < 20:
        raise ValueError("proc stat")
    return {"pid": int(prefix[:open_paren - 1]), "ppid": int(fields[1]),
            "startticks": int(fields[19])}

def complete_write(fd, raw):
    view = memoryview(raw)
    while view:
        try:
            count = os.write(fd, view)
        except InterruptedError:
            continue
        if count <= 0:
            raise OSError("short durable write")
        view = view[count:]

def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

class DurableJournal:
    def __init__(self, root):
        self.root = Path(root)
        if self.root.exists():
            raise FileExistsError("witness root exists")
        self.root.mkdir(mode=0o700)
        self.fd = os.open(self.root / "witness.jsonl",
                          os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC,
                          0o600)
        fsync_directory(self.root.parent)

    def append(self, packet, receipt_ns):
        record = json.dumps({"packet": packet, "receipt_monotonic_ns": receipt_ns},
                            sort_keys=True, separators=(",", ":")).encode() + b"\n"
        complete_write(self.fd, record)
        os.fsync(self.fd)
        fsync_directory(self.root)

    def close(self):
        if self.fd >= 0:
            os.close(self.fd)
            self.fd = -1

def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))

def matching_identity(pid, expected, parent_pid):
    try:
        current = process_identity(pid)
    except (OSError, ValueError):
        return False
    return current == {"pid": pid, "ppid": parent_pid,
                       "startticks": expected["startticks"]}

def wait_direct(pid, deadline):
    while time.monotonic() < deadline:
        try:
            actual, raw = os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            return {"pid": pid, "raw_wait_status": None, "already_reaped": True}
        if actual == pid:
            return {"pid": pid, "raw_wait_status": raw, "already_reaped": False}
        time.sleep(0.01)
    return None

def bounded_cleanup(pid, identity, owner_pid, start):
    events = []
    first = wait_direct(pid, start + 16)
    if first is not None:
        events.append({"kind": "collector-wait", **first})
        return events, True
    for sig, delay in ((signal.SIGTERM, 1), (signal.SIGKILL, 5)):
        if not matching_identity(pid, identity, owner_pid):
            events.append({"kind": "identity-mismatch", "pid": pid,
                           "signal": int(sig)})
            return events, False
        os.kill(pid, sig)
        events.append({"kind": "signal", "pid": pid, "signal": int(sig)})
        waited = wait_direct(pid, min(start + OUTER_CLEANUP_SECONDS,
                                      time.monotonic() + delay))
        if waited is not None:
            events.append({"kind": "collector-wait", **waited})
            return events, True
    return events, False

def receive(endpoint, deadline):
    poller = select.poll()
    poller.register(endpoint.fileno(), select.POLLIN | select.POLLHUP | select.POLLERR)
    remaining = deadline - time.monotonic()
    if remaining <= 0 or not poller.poll(max(1, int(remaining * 1000))):
        raise TimeoutError("witness packet timeout")
    raw = endpoint.recv(PACKET_MAX + 1)
    if not raw:
        return None
    if len(raw) > PACKET_MAX:
        raise ValueError("oversized witness packet")
    return strict_json(raw)

def validate_common(packet, nonce, selector, sequence, hashes):
    required = {"schema_version", "nonce", "selector", "sequence", "kind",
                "phase", "monotonic_ns", "collector_pid", "collector_startticks",
                "source_sha256", "generated_sha256", "header_sha256", "elf_sha256"}
    if not required <= set(packet):
        raise ValueError("witness fields")
    if packet["schema_version"] != 2 or packet["nonce"] != nonce or \
       packet["selector"] != selector or packet["sequence"] != sequence:
        raise ValueError("witness identity")
    if type(packet["monotonic_ns"]) is not int or packet["monotonic_ns"] <= 0:
        raise ValueError("witness time")
    for key, value in hashes.items():
        if packet[key] != value:
            raise ValueError("witness hash")

def launch(argv, environment, witness_root, nonce, selector, hashes):
    if len(nonce) != 32 or any(char not in "0123456789abcdef" for char in nonce):
        raise ValueError("nonce")
    subreaper()
    journal = DurableJournal(witness_root)
    parent_endpoint, child_endpoint = socket.socketpair(
        socket.AF_UNIX, socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC)
    owner_pid = os.getpid()
    pid = os.fork()
    if pid == 0:
        try:
            parent_endpoint.close()
            os.dup2(child_endpoint.fileno(), WITNESS_FD, inheritable=True)
            child_endpoint.close()
            child_environment = dict(environment)
            child_environment.update({"M02_SF_NONCE": nonce,
                "M02_SF_SOURCE_SHA256": hashes["source_sha256"],
                "M02_SF_GENERATED_SHA256": hashes["generated_sha256"],
                "M02_SF_HEADER_SHA256": hashes["header_sha256"],
                "M02_SF_ELF_SHA256": hashes["elf_sha256"]})
            os.execve(argv[0], argv, child_environment)
        finally:
            os._exit(127)
    child_endpoint.close()
    identity = process_identity(pid)
    if identity["ppid"] != owner_pid:
        raise RuntimeError("collector parent identity")
    packets, owner_failure, raw_wait = [], None, None
    started = time.monotonic()
    try:
        sequence = 0
        while len(packets) <= PACKET_LIMIT:
            packet = receive(parent_endpoint, started + OUTER_CLEANUP_SECONDS)
            if packet is None:
                break
            if len(packets) == PACKET_LIMIT:
                raise ValueError("witness packet limit")
            validate_common(packet, nonce, selector, sequence, hashes)
            if packet["collector_pid"] != pid or \
               packet["collector_startticks"] != identity["startticks"]:
                raise ValueError("collector witness identity")
            journal.append(packet, time.monotonic_ns())
            packets.append(packet)
            if sequence == 0:
                if packet["kind"] != "READY" or not matching_identity(
                        pid, identity, owner_pid):
                    raise ValueError("ready identity")
                parent_endpoint.sendall(("RELEASE %s\n" % nonce).encode())
            else:
                parent_endpoint.sendall(("ACK %s %d\n" % (nonce, sequence)).encode())
            sequence += 1
        waited = wait_direct(pid, started + OUTER_CLEANUP_SECONDS)
        if waited is not None:
            raw_wait = waited["raw_wait_status"]
    except Exception as error:
        owner_failure = {"type": type(error).__name__, "message": str(error)}
    finally:
        parent_endpoint.close()
        cleanup, complete = bounded_cleanup(pid, identity, owner_pid, started)
        result = {"schema_version": 2, "selector": selector, "nonce": nonce,
                  "collector_pid": pid, "collector_startticks": identity["startticks"],
                  "raw_wait_status": raw_wait, "packets": len(packets),
                  "owner_failure": owner_failure, "cleanup_events": cleanup,
                  "cleanup_complete": complete, "backend_enabled": False,
                  "application_acceptance": False}
        journal.append({"kind": "OWNER_RESULT", **result}, time.monotonic_ns())
        journal.close()
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--witness-root", type=Path, required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--selector", type=int, choices=range(7), required=True)
    parser.add_argument("--hashes", type=Path, required=True)
    parser.add_argument("argv", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.argv:
        raise SystemExit("collector argv required")
    hashes = strict_json(args.hashes.read_bytes())
    result = launch(args.argv, dict(os.environ), args.witness_root, args.nonce,
                    args.selector, hashes)
    print(json.dumps(result, sort_keys=True))

if __name__ == "__main__":
    main()
